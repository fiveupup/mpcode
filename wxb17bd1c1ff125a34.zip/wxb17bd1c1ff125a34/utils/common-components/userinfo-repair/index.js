require("../../../@babel/runtime/helpers/Objectvalues"), require("../../../@babel/runtime/helpers/Arrayincludes"), 
(global.webpackJsonp = global.webpackJsonp || []).push([ [ "utils/common-components/userinfo-repair/index" ], {
    "65bf": function(e, t, n) {
        n.d(t, "b", function() {
            return r;
        }), n.d(t, "c", function() {
            return o;
        }), n.d(t, "a", function() {});
        var r = function() {
            var e = this, t = (e.$createElement, e._self._c, e.__map(e.userInfoItemList, function(t, n) {
                return {
                    $orig: e.__get_orig(t),
                    g0: [ "text", "nickname" ].includes(t.type)
                };
            }));
            e.$mp.data = Object.assign({}, {
                $root: {
                    l0: t
                }
            });
        }, o = [];
    },
    a1f4: function(e, t, n) {},
    b1f7: function(e, t, n) {
        n.r(t);
        var r = n("65bf"), o = n("cd89");
        for (var i in o) [ "default" ].indexOf(i) < 0 && function(e) {
            n.d(t, e, function() {
                return o[e];
            });
        }(i);
        n("c6082");
        var a = n("f0c5"), c = Object(a.a)(o.default, r.b, r.c, !1, null, "3177e8e1", null, !1, r.a, void 0);
        t.default = c.exports;
    },
    c6082: function(e, t, n) {
        var r = n("a1f4");
        n.n(r).a;
    },
    cc17: function(e, t, n) {
        var r = n("4ea4");
        Object.defineProperty(t, "__esModule", {
            value: !0
        }), t.default = void 0;
        var o = r(n("2eee")), i = r(n("9523")), a = r(n("448a")), c = r(n("c973")), s = r(n("ce99")), u = (r(n("de41")), 
        n("c174")), l = n("6b44"), p = n("386d");
        function f(e, t) {
            var n = Object.keys(e);
            if (Object.getOwnPropertySymbols) {
                var r = Object.getOwnPropertySymbols(e);
                t && (r = r.filter(function(t) {
                    return Object.getOwnPropertyDescriptor(e, t).enumerable;
                })), n.push.apply(n, r);
            }
            return n;
        }
        function d(e) {
            for (var t = 1; t < arguments.length; t++) {
                var n = null != arguments[t] ? arguments[t] : {};
                t % 2 ? f(Object(n), !0).forEach(function(t) {
                    (0, i.default)(e, t, n[t]);
                }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(n)) : f(Object(n)).forEach(function(t) {
                    Object.defineProperty(e, t, Object.getOwnPropertyDescriptor(n, t));
                });
            }
            return e;
        }
        function m(e, t) {
            (null == t || t > e.length) && (t = e.length);
            for (var n = 0, r = new Array(t); n < t; n++) r[n] = e[n];
            return r;
        }
        var b = Object.values({
            name: "name",
            nickName: "nick_name",
            mobile: "mobile",
            university: "university_id",
            department: "department",
            identity: "identity",
            gender: "gender",
            category: "category",
            politics: "politics"
        }), h = [ {
            label: "男",
            value: "1",
            prop: "male"
        }, {
            label: "女",
            value: "2",
            prop: "female"
        } ], v = [ {
            label: "老师",
            value: "2",
            prop: "teacher"
        }, {
            label: "学生",
            value: "3",
            prop: "student"
        }, {
            label: "其他",
            value: "99",
            prop: "other"
        } ], y = [ {
            label: "共产党员",
            value: "1",
            prop: "partyMember"
        }, {
            label: "共青团员",
            value: "2",
            prop: "leagueMember"
        }, {
            label: "人民群众",
            value: "3",
            prop: "people"
        }, {
            label: "其他",
            value: "99",
            prop: "otherPolitic"
        } ], g = {
            components: {
                UserinfoInput: function() {
                    n.e("utils/common-components/userinfo-repair/components/userinfo-input").then(function() {
                        return resolve(n("925b"));
                    }.bind(null, n)).catch(n.oe);
                },
                UserinfoRadios: function() {
                    n.e("utils/common-components/userinfo-repair/components/userinfo-radios").then(function() {
                        return resolve(n("0357"));
                    }.bind(null, n)).catch(n.oe);
                },
                UserinfoSchool: function() {
                    n.e("utils/common-components/userinfo-repair/components/userinfo-school").then(function() {
                        return resolve(n("a59e"));
                    }.bind(null, n)).catch(n.oe);
                }
            },
            props: {
                userInfo: {
                    type: Object,
                    default: function() {
                        var e = {};
                        return b.forEach(function(t) {
                            e[t] = null;
                        }), e;
                    }
                },
                needRepairInfo: {
                    type: Object
                }
            },
            data: function() {
                return {
                    originUserInfoItemList: [ {
                        titleIcon: "".concat("https://univs-sishi-1256833609.file.myqcloud.com/resource", "/t1-1.png"),
                        placeholder: "请输入姓名",
                        prop: "name",
                        type: "text",
                        required: !0,
                        disabled: !0
                    }, {
                        titleIcon: "".concat("https://univs-sishi-1256833609.file.myqcloud.com/resource", "/t1@2x.png"),
                        placeholder: "请输入昵称",
                        prop: "nick_name",
                        type: "nickname",
                        required: !0,
                        disabled: !0
                    }, {
                        titleIcon: "".concat("https://univs-sishi-1256833609.file.myqcloud.com/resource", "/t3@2x.png"),
                        placeholder: "请输入学校名称",
                        prop: "university_id",
                        type: "school",
                        required: !0,
                        disabled: !0
                    }, {
                        titleIcon: "".concat("https://univs-sishi-1256833609.file.myqcloud.com/resource", "/t4@2x.png"),
                        placeholder: "请输入学院",
                        prop: "department",
                        type: "text",
                        required: !1,
                        disabled: !0
                    }, {
                        titleIcon: "".concat("https://univs-sishi-1256833609.file.myqcloud.com/resource", "/tz2@2x.png"),
                        placeholder: "请输入学号",
                        prop: "identity",
                        type: "text",
                        required: !1,
                        disabled: !0
                    }, {
                        titleIcon: "".concat("https://univs-sishi-1256833609.file.myqcloud.com/resource", "/tz1@2x.png"),
                        placeholder: "请选择性别",
                        prop: "gender",
                        type: "radio",
                        required: !1,
                        disabled: !0,
                        options: h
                    }, {
                        titleIcon: "".concat("https://univs-sishi-1256833609.file.myqcloud.com/resource", "/t5@2x.png"),
                        placeholder: "请选择身份",
                        prop: "category",
                        type: "radio",
                        required: !1,
                        disabled: !0,
                        options: v
                    }, {
                        titleIcon: "".concat("https://univs-sishi-1256833609.file.myqcloud.com/resource", "/t6@2x.png"),
                        placeholder: "请选择政治面貌",
                        prop: "politics",
                        type: "radio",
                        required: !1,
                        disabled: !0,
                        options: y
                    } ],
                    submitInfo: {
                        name: "",
                        mobile: "",
                        university_id: "",
                        department: "",
                        category: "",
                        politics: "",
                        identity: "",
                        gender: ""
                    },
                    university_value: "",
                    userInfoEnter: {},
                    isDisabled: !1,
                    infoErrorMsg: "",
                    toView: "scrollTop",
                    schoolsData: [],
                    schoolsDataMap: {},
                    catchtouchmove: !1,
                    identityIsChoose: !1,
                    politicsIsChoose: !1,
                    genderIsChoose: !1,
                    university_id_temp: null
                };
            },
            computed: {
                buttonStyle: function() {
                    var e = this.isDisabled, t = e ? "#BBBBBB" : "#FFFFFF";
                    return "background-color: ".concat(e ? "#EEEEEE" : "#2542E7", "; color: ").concat(t, ";");
                },
                userInfoItemList: function() {
                    var e = this.submitInfo;
                    return this.originUserInfoItemList.filter(function(t) {
                        return t.prop in e;
                    });
                }
            },
            created: function() {
                var e = this;
                this.university_id_temp = this.userInfo.university_id;
                var t = this.originUserInfoItemList, n = this.needRepairInfo;
                t.forEach(function(t) {
                    var r = t.prop, o = e.userInfo[r];
                    o = o && "None" !== o ? o : "", n ? (t.required = 1 === n[t.prop], r in n ? e.submitInfo[r] = o : e.$delete(e.submitInfo, r), 
                    t.disabled = !1) : (e.submitInfo[r] = o, t.disabled = !(!o || 99 === o || 100 === o));
                });
            },
            methods: {
                showErrorMessage: function(e) {
                    var t = this;
                    return (0, c.default)(o.default.mark(function n() {
                        return o.default.wrap(function(n) {
                            for (;;) switch (n.prev = n.next) {
                              case 0:
                                t.infoErrorMsg = e, t.notify();

                              case 2:
                              case "end":
                                return n.stop();
                            }
                        }, n);
                    }))();
                },
                validate: function() {
                    var e, t = this, n = this.userInfoItemList.filter(function(e) {
                        return e.required;
                    }).map(function(e) {
                        return {
                            validator: function() {
                                return !t.submitInfo[e.prop];
                            },
                            message: e.placeholder
                        };
                    }), r = [].concat((0, a.default)(n), [ {
                        validator: function() {
                            return t.submitInfo.name && !(0, u.checkUserName)(t.submitInfo.name);
                        },
                        message: "昵称请使用英文，数字，下划线，人名分隔符、中文"
                    }, {
                        validator: function() {
                            return t.university_value && !Object.keys(t.schoolsDataMap).includes(t.university_value);
                        },
                        message: "请输入正确的学校名称"
                    }, {
                        validator: function() {
                            return t.submitInfo.identity && !(0, u.checkNumber)(t.submitInfo.identity);
                        },
                        message: "学号请使用数字"
                    } ]), o = this.showErrorMessage, i = function(e, t) {
                        var n = "undefined" != typeof Symbol && e[Symbol.iterator] || e["@@iterator"];
                        if (!n) {
                            if (Array.isArray(e) || (n = function(e, t) {
                                if (e) {
                                    if ("string" == typeof e) return m(e, t);
                                    var n = Object.prototype.toString.call(e).slice(8, -1);
                                    return "Object" === n && e.constructor && (n = e.constructor.name), "Map" === n || "Set" === n ? Array.from(e) : "Arguments" === n || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n) ? m(e, t) : void 0;
                                }
                            }(e)) || t && e && "number" == typeof e.length) {
                                n && (e = n);
                                var r = 0, o = function() {};
                                return {
                                    s: o,
                                    n: function() {
                                        return r >= e.length ? {
                                            done: !0
                                        } : {
                                            done: !1,
                                            value: e[r++]
                                        };
                                    },
                                    e: function(e) {
                                        throw e;
                                    },
                                    f: o
                                };
                            }
                            throw new TypeError("Invalid attempt to iterate non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.");
                        }
                        var i, a = !0, c = !1;
                        return {
                            s: function() {
                                n = n.call(e);
                            },
                            n: function() {
                                var e = n.next();
                                return a = e.done, e;
                            },
                            e: function(e) {
                                c = !0, i = e;
                            },
                            f: function() {
                                try {
                                    a || null == n.return || n.return();
                                } finally {
                                    if (c) throw i;
                                }
                            }
                        };
                    }(r);
                    try {
                        for (i.s(); !(e = i.n()).done; ) {
                            var c = e.value, s = c.validator, l = c.message;
                            if (s()) return o(l), !1;
                        }
                    } catch (e) {
                        i.e(e);
                    } finally {
                        i.f();
                    }
                    return !0;
                },
                submit: function() {
                    var e = this;
                    return (0, c.default)(o.default.mark(function t() {
                        var n, r, i;
                        return o.default.wrap(function(t) {
                            for (;;) switch (t.prev = t.next) {
                              case 0:
                                if (e.validate()) {
                                    t.next = 3;
                                    break;
                                }
                                return t.abrupt("return", !1);

                              case 3:
                                for (r in n = d(d(d({}, e.userInfo), e.submitInfo), {}, {
                                    need_save: !0
                                })) n[r] || delete n[r];
                                return t.next = 7, (0, l.commitUserInfo)(n);

                              case 7:
                                if (0 !== (i = t.sent).data.code) {
                                    t.next = 14;
                                    break;
                                }
                                return t.next = 11, (0, p.getAndSetUserInfo)();

                              case 11:
                                e.$emit("close", !1), t.next = 15;
                                break;

                              case 14:
                                e.showErrorMessage(i.data.msg);

                              case 15:
                              case "end":
                                return t.stop();
                            }
                        }, t);
                    }))();
                },
                notify: function() {
                    (0, s.default)({
                        type: "warning",
                        message: this.infoErrorMsg,
                        top: 82,
                        duration: 1500,
                        background: "#FFEAEA",
                        color: "#FF5065"
                    });
                }
            }
        };
        t.default = g;
    },
    cd89: function(e, t, n) {
        n.r(t);
        var r = n("cc17"), o = n.n(r);
        for (var i in r) [ "default" ].indexOf(i) < 0 && function(e) {
            n.d(t, e, function() {
                return r[e];
            });
        }(i);
        t.default = o.a;
    }
} ]), (global.webpackJsonp = global.webpackJsonp || []).push([ "utils/common-components/userinfo-repair/index-create-component", {
    "utils/common-components/userinfo-repair/index-create-component": function(e, t, n) {
        n("543d").createComponent(n("b1f7"));
    }
}, [ [ "utils/common-components/userinfo-repair/index-create-component" ] ] ]);