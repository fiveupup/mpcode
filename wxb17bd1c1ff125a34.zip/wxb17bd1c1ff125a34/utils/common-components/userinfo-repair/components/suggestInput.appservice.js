$gwx_XC_21=function(_,_v,_n,_p,_s,_wp,_wl,$gwn,$gwl,$gwh,wh,$gstack,$gwrt,gra,grb,TestTest,wfor,_ca,_da,_r,_rz,_o,_oz,_1,_1z,_2,_2z,_m,_mz,nv_getDate,nv_getRegExp,nv_console,nv_parseInt,nv_parseFloat,nv_isNaN,nv_isFinite,nv_decodeURI,nv_decodeURIComponent,nv_encodeURI,nv_encodeURIComponent,$gdc,nv_JSON,_af,_gv,_ai,_grp,_gd,_gapi,$ixc,_ic,_w,_ev,_tsd){return function(path,global){
if(typeof global==='undefined'){if (typeof __GWX_GLOBAL__==='undefined')global={};else global=__GWX_GLOBAL__;}if(typeof __WXML_GLOBAL__ === 'undefined') {__WXML_GLOBAL__={};
}__WXML_GLOBAL__.modules = __WXML_GLOBAL__.modules || {};
var e_={}
if(typeof(global.entrys)==='undefined')global.entrys={};e_=global.entrys;
var d_={}
if(typeof(global.defines)==='undefined')global.defines={};d_=global.defines;
var f_={}
if(typeof(global.modules)==='undefined')global.modules={};f_=global.modules || {};
var p_={}
__WXML_GLOBAL__.ops_cached = __WXML_GLOBAL__.ops_cached || {}
__WXML_GLOBAL__.ops_set = __WXML_GLOBAL__.ops_set || {};
__WXML_GLOBAL__.ops_init = __WXML_GLOBAL__.ops_init || {};
var z=__WXML_GLOBAL__.ops_set.$gwx_XC_21 || [];
function gz$gwx_XC_21_1(){
if( __WXML_GLOBAL__.ops_cached.$gwx_XC_21_1)return __WXML_GLOBAL__.ops_cached.$gwx_XC_21_1
__WXML_GLOBAL__.ops_cached.$gwx_XC_21_1=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
Z([[7],[3,'isHaveKeywords']])
})(__WXML_GLOBAL__.ops_cached.$gwx_XC_21_1);return __WXML_GLOBAL__.ops_cached.$gwx_XC_21_1
}
__WXML_GLOBAL__.ops_set.$gwx_XC_21=z;
__WXML_GLOBAL__.ops_init.$gwx_XC_21=true;
var x=['./utils/common-components/userinfo-repair/components/suggestInput.wxml'];d_[x[0]]={}
var m0=function(e,s,r,gg){
var z=gz$gwx_XC_21_1()
var oTE=_v()
_(r,oTE)
if(_oz(z,0,e,s,gg)){oTE.wxVkey=1
}
oTE.wxXCkey=1
return r
}
e_[x[0]]={f:m0,j:[],i:[],ti:[],ic:[]}
if(path&&e_[path]){
return function(env,dd,global){$gwxc=0;var root={"tag":"wx-page"};root.children=[]
;g="$gwx_XC_21";var main=e_[path].f
if (typeof global==="undefined")global={};global.f=$gdc(f_[path],"",1);
try{
main(env,{},root,global);
_tsd(root)
}catch(err){
console.log(err)
}
;g="";
return root;
}
}
}
}(__g.a,__g.b,__g.c,__g.d,__g.e,__g.f,__g.g,__g.h,__g.i,__g.j,__g.k,__g.l,__g.m,__g.n,__g.o,__g.p,__g.q,__g.r,__g.s,__g.t,__g.u,__g.v,__g.w,__g.x,__g.y,__g.z,__g.A,__g.B,__g.C,__g.D,__g.E,__g.F,__g.G,__g.H,__g.I,__g.J,__g.K,__g.L,__g.M,__g.N,__g.O,__g.P,__g.Q,__g.R,__g.S,__g.T,__g.U,__g.V,__g.W,__g.X,__g.Y,__g.Z,__g.aa);if(__vd_version_info__.delayedGwx||false)$gwx_XC_21();	if (__vd_version_info__.delayedGwx) __wxAppCode__['utils/common-components/userinfo-repair/components/suggestInput.wxml'] = [$gwx_XC_21, './utils/common-components/userinfo-repair/components/suggestInput.wxml'];else __wxAppCode__['utils/common-components/userinfo-repair/components/suggestInput.wxml'] = $gwx_XC_21( './utils/common-components/userinfo-repair/components/suggestInput.wxml' );
	;__wxRoute = "utils/common-components/userinfo-repair/components/suggestInput";__wxRouteBegin = true;__wxAppCurrentFile__="utils/common-components/userinfo-repair/components/suggestInput.js";define("utils/common-components/userinfo-repair/components/suggestInput.js",function(require,module,exports,window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){
"use strict";(global.webpackJsonp=global.webpackJsonp||[]).push([["utils/common-components/userinfo-repair/components/suggestInput"],{2828:function(e,t,n){n.d(t,"b",(function(){return o})),n.d(t,"c",(function(){return u})),n.d(t,"a",(function(){}));var o=function(){this.$createElement;this._self._c},u=[]},"37a0":function(e,t,n){var o=n("9581");n.n(o).a},"4e82":function(e,t,n){n.r(t);var o=n("5069"),u=n.n(o);for(var a in o)["default"].indexOf(a)<0&&function(e){n.d(t,e,(function(){return o[e]}))}(a);t.default=u.a},5069:function(e,t,n){Object.defineProperty(t,"__esModule",{value:!0}),t.default=void 0;var o={name:"SuggestInput",props:{schoolsData:{type:Array,default:function(){}},enterValue:{type:String,default:""}},data:function(){return{autoCompleteReslut:[],isHaveKeywords:!1}},methods:{suggestList:function(){var e=this;this.$nextTick((function(){if(0===e.enterValue.length)return e.autoCompleteReslut=[],e.isHaveKeywords=!1,void e.$emit("stopSroll",!1);e.autoCompleteReslut=[],e.schoolsData.forEach((function(t){var n=t.value.indexOf(e.enterValue);n>-1&&(t.front=t.value.slice(0,n),t.middle=t.value.slice(n,n+e.enterValue.length),t.end=t.value.slice(n+e.enterValue.length),e.autoCompleteReslut.push(t)),e.isHaveKeywords=!0}))}))},closeList:function(){var e=this;setTimeout((function(){e.autoCompleteReslut=[],e.isHaveKeywords=!1}),120)},chooseSchool:function(e){this.$emit("getEnterValye",e.univercityID,e.value)}}};t.default=o},"75fb":function(e,t,n){n.r(t);var o=n("2828"),u=n("4e82");for(var a in u)["default"].indexOf(a)<0&&function(e){n.d(t,e,(function(){return u[e]}))}(a);n("37a0");var s=n("f0c5"),i=Object(s.a)(u.default,o.b,o.c,!1,null,"84c3e55c",null,!1,o.a,void 0);t.default=i.exports},9581:function(e,t,n){}}]),(global.webpackJsonp=global.webpackJsonp||[]).push(["utils/common-components/userinfo-repair/components/suggestInput-create-component",{"utils/common-components/userinfo-repair/components/suggestInput-create-component":function(e,t,n){n("543d").createComponent(n("75fb"))}},[["utils/common-components/userinfo-repair/components/suggestInput-create-component"]]]);
},{isPage:false,isComponent:true,currentFile:'utils/common-components/userinfo-repair/components/suggestInput.js'});require("utils/common-components/userinfo-repair/components/suggestInput.js");