$gwx_XC_19=function(_,_v,_n,_p,_s,_wp,_wl,$gwn,$gwl,$gwh,wh,$gstack,$gwrt,gra,grb,TestTest,wfor,_ca,_da,_r,_rz,_o,_oz,_1,_1z,_2,_2z,_m,_mz,nv_getDate,nv_getRegExp,nv_console,nv_parseInt,nv_parseFloat,nv_isNaN,nv_isFinite,nv_decodeURI,nv_decodeURIComponent,nv_encodeURI,nv_encodeURIComponent,$gdc,nv_JSON,_af,_gv,_ai,_grp,_gd,_gapi,$ixc,_ic,_w,_ev,_tsd){return function(path,global){
if(typeof global==='undefined'){if (typeof __GWX_GLOBAL__==='undefined')global={};else global=__GWX_GLOBAL__;}if(typeof __WXML_GLOBAL__ === 'undefined') {__WXML_GLOBAL__={};
}__WXML_GLOBAL__.modules = __WXML_GLOBAL__.modules || {};
var e_={}
if(typeof(global.entrys)==='undefined')global.entrys={};e_=global.entrys;
var d_={}
if(typeof(global.defines)==='undefined')global.defines={};d_=global.defines;
var f_={}
if(typeof(global.modules)==='undefined')global.modules={};f_=global.modules || {};
var p_={}
__WXML_GLOBAL__.ops_cached = __WXML_GLOBAL__.ops_cached || {}
__WXML_GLOBAL__.ops_set = __WXML_GLOBAL__.ops_set || {};
__WXML_GLOBAL__.ops_init = __WXML_GLOBAL__.ops_init || {};
var z=__WXML_GLOBAL__.ops_set.$gwx_XC_19 || [];
function gz$gwx_XC_19_1(){
if( __WXML_GLOBAL__.ops_cached.$gwx_XC_19_1)return __WXML_GLOBAL__.ops_cached.$gwx_XC_19_1
__WXML_GLOBAL__.ops_cached.$gwx_XC_19_1=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
Z([[4],[[5],[[5],[[5],[1,'uni-navbar']],[1,'data-v-b871d3c0']],[[2,'?:'],[[7],[3,'dark']],[1,'uni-dark'],[1,'']]]])
Z([[4],[[5],[[5],[[5],[[5],[[5],[1,'uni-navbar__content']],[1,'data-v-b871d3c0']],[[2,'?:'],[[7],[3,'fixed']],[1,'uni-navbar--fixed'],[1,'']]],[[2,'?:'],[[7],[3,'shadow']],[1,'uni-navbar--shadow'],[1,'']]],[[2,'?:'],[[7],[3,'border']],[1,'uni-navbar--border'],[1,'']]]])
Z([[2,'+'],[[2,'+'],[1,'background-color:'],[[7],[3,'themeBgColor']]],[1,';']])
Z([[7],[3,'statusBar']])
Z([3,'__l'])
Z([3,'data-v-b871d3c0'])
Z([3,'784be54e-1'])
Z([3,'uni-navbar__header data-v-b871d3c0'])
Z([[2,'+'],[[2,'+'],[[2,'+'],[[2,'+'],[1,'color:'],[[7],[3,'themeColor']]],[1,';']],[[2,'+'],[[2,'+'],[1,'background-color:'],[[7],[3,'themeBgColor']]],[1,';']]],[[2,'+'],[[2,'+'],[1,'height:'],[[7],[3,'navbarHeight']]],[1,';']]])
Z([3,'__e'])
Z([3,'uni-navbar__header-btns uni-navbar__header-btns-left data-v-b871d3c0'])
Z([[4],[[5],[[4],[[5],[[5],[1,'tap']],[[4],[[5],[[4],[[5],[[5],[1,'onClickLeft']],[[4],[[5],[1,'$event']]]]]]]]]]])
Z([[2,'+'],[[2,'+'],[1,'width:'],[[7],[3,'leftIconWidth']]],[1,';']])
Z([[7],[3,'homePage']])
Z(z[9])
Z([3,'uni-navbar__header-container  data-v-b871d3c0'])
Z([[4],[[5],[[4],[[5],[[5],[1,'tap']],[[4],[[5],[[4],[[5],[[5],[1,'onClickTitle']],[[4],[[5],[1,'$event']]]]]]]]]]])
Z([[6],[[7],[3,'$slots']],[3,'default']])
Z([[2,'>'],[[6],[[7],[3,'$root']],[3,'g0']],[1,0]])
Z(z[9])
Z([3,'uni-navbar__header-btns uni-navbar__header-btns-right data-v-b871d3c0'])
Z([[4],[[5],[[4],[[5],[[5],[1,'tap']],[[4],[[5],[[4],[[5],[[5],[1,'onClickRight']],[[4],[[5],[1,'$event']]]]]]]]]]])
Z([[2,'+'],[[2,'+'],[1,'width:'],[[7],[3,'rightIconWidth']]],[1,';']])
Z([[6],[[7],[3,'$slots']],[3,'right']])
Z([3,'right'])
Z([[6],[[7],[3,'$root']],[3,'g1']])
Z(z[4])
Z(z[5])
Z([[7],[3,'themeColor']])
Z([3,'22'])
Z([[7],[3,'rightIcon']])
Z([3,'784be54e-2'])
Z([[6],[[7],[3,'$root']],[3,'g2']])
Z([[7],[3,'fixed']])
Z(z[3])
Z(z[4])
Z(z[5])
Z([3,'784be54e-3'])
})(__WXML_GLOBAL__.ops_cached.$gwx_XC_19_1);return __WXML_GLOBAL__.ops_cached.$gwx_XC_19_1
}
__WXML_GLOBAL__.ops_set.$gwx_XC_19=z;
__WXML_GLOBAL__.ops_init.$gwx_XC_19=true;
var x=['./uni_modules/uni-nav-bar/components/uni-nav-bar/uni-nav-bar.wxml'];d_[x[0]]={}
var m0=function(e,s,r,gg){
var z=gz$gwx_XC_19_1()
var b7D=_n('view')
_rz(z,b7D,'class',0,e,s,gg)
var x9D=_mz(z,'view',['class',1,'style',1],[],e,s,gg)
var o0D=_v()
_(x9D,o0D)
if(_oz(z,3,e,s,gg)){o0D.wxVkey=1
var fAE=_mz(z,'status-bar',['bind:__l',4,'class',1,'vueId',2],[],e,s,gg)
_(o0D,fAE)
}
var cBE=_mz(z,'view',['class',7,'style',1],[],e,s,gg)
var hCE=_mz(z,'view',['bindtap',9,'class',1,'data-event-opts',2,'style',3],[],e,s,gg)
var oDE=_v()
_(hCE,oDE)
if(_oz(z,13,e,s,gg)){oDE.wxVkey=1
}
oDE.wxXCkey=1
_(cBE,hCE)
var cEE=_mz(z,'view',['bindtap',14,'class',1,'data-event-opts',2],[],e,s,gg)
var oFE=_v()
_(cEE,oFE)
if(_oz(z,17,e,s,gg)){oFE.wxVkey=1
var lGE=_n('slot')
_(oFE,lGE)
}
else{oFE.wxVkey=2
var aHE=_v()
_(oFE,aHE)
if(_oz(z,18,e,s,gg)){aHE.wxVkey=1
}
aHE.wxXCkey=1
}
oFE.wxXCkey=1
_(cBE,cEE)
var tIE=_mz(z,'view',['bindtap',19,'class',1,'data-event-opts',2,'style',3],[],e,s,gg)
var eJE=_v()
_(tIE,eJE)
if(_oz(z,23,e,s,gg)){eJE.wxVkey=1
var bKE=_n('slot')
_rz(z,bKE,'name',24,e,s,gg)
_(eJE,bKE)
}
else{eJE.wxVkey=2
var oLE=_v()
_(eJE,oLE)
if(_oz(z,25,e,s,gg)){oLE.wxVkey=1
var oNE=_mz(z,'uni-icons',['bind:__l',26,'class',1,'color',2,'size',3,'type',4,'vueId',5],[],e,s,gg)
_(oLE,oNE)
}
var xME=_v()
_(eJE,xME)
if(_oz(z,32,e,s,gg)){xME.wxVkey=1
}
oLE.wxXCkey=1
oLE.wxXCkey=3
xME.wxXCkey=1
}
eJE.wxXCkey=1
eJE.wxXCkey=3
_(cBE,tIE)
_(x9D,cBE)
o0D.wxXCkey=1
o0D.wxXCkey=3
_(b7D,x9D)
var o8D=_v()
_(b7D,o8D)
if(_oz(z,33,e,s,gg)){o8D.wxVkey=1
var fOE=_v()
_(o8D,fOE)
if(_oz(z,34,e,s,gg)){fOE.wxVkey=1
var cPE=_mz(z,'status-bar',['bind:__l',35,'class',1,'vueId',2],[],e,s,gg)
_(fOE,cPE)
}
fOE.wxXCkey=1
fOE.wxXCkey=3
}
o8D.wxXCkey=1
o8D.wxXCkey=3
_(r,b7D)
return r
}
e_[x[0]]={f:m0,j:[],i:[],ti:[],ic:[]}
if(path&&e_[path]){
return function(env,dd,global){$gwxc=0;var root={"tag":"wx-page"};root.children=[]
;g="$gwx_XC_19";var main=e_[path].f
if (typeof global==="undefined")global={};global.f=$gdc(f_[path],"",1);
try{
main(env,{},root,global);
_tsd(root)
}catch(err){
console.log(err)
}
;g="";
return root;
}
}
}
}(__g.a,__g.b,__g.c,__g.d,__g.e,__g.f,__g.g,__g.h,__g.i,__g.j,__g.k,__g.l,__g.m,__g.n,__g.o,__g.p,__g.q,__g.r,__g.s,__g.t,__g.u,__g.v,__g.w,__g.x,__g.y,__g.z,__g.A,__g.B,__g.C,__g.D,__g.E,__g.F,__g.G,__g.H,__g.I,__g.J,__g.K,__g.L,__g.M,__g.N,__g.O,__g.P,__g.Q,__g.R,__g.S,__g.T,__g.U,__g.V,__g.W,__g.X,__g.Y,__g.Z,__g.aa);if(__vd_version_info__.delayedGwx||false)$gwx_XC_19();	if (__vd_version_info__.delayedGwx) __wxAppCode__['uni_modules/uni-nav-bar/components/uni-nav-bar/uni-nav-bar.wxml'] = [$gwx_XC_19, './uni_modules/uni-nav-bar/components/uni-nav-bar/uni-nav-bar.wxml'];else __wxAppCode__['uni_modules/uni-nav-bar/components/uni-nav-bar/uni-nav-bar.wxml'] = $gwx_XC_19( './uni_modules/uni-nav-bar/components/uni-nav-bar/uni-nav-bar.wxml' );
	;__wxRoute = "uni_modules/uni-nav-bar/components/uni-nav-bar/uni-nav-bar";__wxRouteBegin = true;__wxAppCurrentFile__="uni_modules/uni-nav-bar/components/uni-nav-bar/uni-nav-bar.js";define("uni_modules/uni-nav-bar/components/uni-nav-bar/uni-nav-bar.js",function(require,module,exports,window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){
"use strict";(global.webpackJsonp=global.webpackJsonp||[]).push([["uni_modules/uni-nav-bar/components/uni-nav-bar/uni-nav-bar"],{1039:function(t,n,e){(function(t){Object.defineProperty(n,"__esModule",{value:!0}),n.default=void 0;var i=function(t){return"number"==typeof t?t+"px":t},o={name:"UniNavBar",data:function(){return{homeImage:"".concat("https://univs-sishi-1256833609.file.myqcloud.com/resource","/Home@2x.png"),fanhuiImage:"".concat("https://univs-sishi-1256833609.file.myqcloud.com/resource","/fanhui@2x.png")}},components:{statusBar:function(){e.e("uni_modules/uni-nav-bar/components/uni-nav-bar/uni-status-bar").then(function(){return resolve(e("1712"))}.bind(null,e)).catch(e.oe)}},emits:["clickLeft","clickRight","clickTitle"],props:{dark:{type:Boolean,default:!1},title:{type:String,default:""},leftText:{type:String,default:""},rightText:{type:String,default:""},leftIcon:{type:String,default:""},rightIcon:{type:String,default:""},fixed:{type:[Boolean,String],default:!1},color:{type:String,default:""},backgroundColor:{type:String,default:"unset"},statusBar:{type:[Boolean,String],default:!1},shadow:{type:[Boolean,String],default:!1},border:{type:[Boolean,String],default:!0},height:{type:[Number,String],default:40},positionTop:{type:Number,default:20},homePage:{type:[Boolean,String],default:!1},leftWidth:{type:[Number,String],default:60},rightWidth:{type:[Number,String],default:60}},computed:{themeBgColor:function(){return this.dark?this.backgroundColor?this.backgroundColor:this.dark?"#333":"#FFF":this.backgroundColor||"#FFF"},themeColor:function(){return this.dark?this.color?this.color:this.dark?"#fff":"#333":this.color||"#333"},navbarHeight:function(){return i(this.height)},leftIconWidth:function(){return i(this.leftWidth)},rightIconWidth:function(){return i(this.rightWidth)},getTop:function(){return i(this.positionTop)}},mounted:function(){t.report&&""!==this.title&&t.report("title",this.title)},methods:{onClickLeft:function(){if(this.homePage){for(var n=0,e=getCurrentPages(),i=e[e.length-1],o=e.length-1;o>=0;o--){if(e[o].route!=i.route)break;n++}t.navigateBack({delta:n})}},onClickRight:function(){this.$emit("clickRight")},onClickTitle:function(){this.$emit("clickTitle")}}};n.default=o}).call(this,e("543d").default)},"26b0":function(t,n,e){e.r(n);var i=e("5c71"),o=e("c760");for(var r in o)["default"].indexOf(r)<0&&function(t){e.d(n,t,(function(){return o[t]}))}(r);e("7ecf");var u=e("f0c5"),a=Object(u.a)(o.default,i.b,i.c,!1,null,"b871d3c0",null,!1,i.a,void 0);n.default=a.exports},"5c71":function(t,n,e){e.d(n,"b",(function(){return o})),e.d(n,"c",(function(){return r})),e.d(n,"a",(function(){return i}));var i={uniIcons:function(){return Promise.all([e.e("common/vendor"),e.e("uni_modules/uni-icons/components/uni-icons/uni-icons")]).then(e.bind(null,"ca9f"))}},o=function(){this.$createElement;var t=(this._self._c,this.title.length),n=this.rightIcon.length,e=this.rightText.length&&!this.rightIcon.length;this.$mp.data=Object.assign({},{$root:{g0:t,g1:n,g2:e}})},r=[]},"7ecf":function(t,n,e){var i=e("9b13");e.n(i).a},"9b13":function(t,n,e){},c760:function(t,n,e){e.r(n);var i=e("1039"),o=e.n(i);for(var r in i)["default"].indexOf(r)<0&&function(t){e.d(n,t,(function(){return i[t]}))}(r);n.default=o.a}}]),(global.webpackJsonp=global.webpackJsonp||[]).push(["uni_modules/uni-nav-bar/components/uni-nav-bar/uni-nav-bar-create-component",{"uni_modules/uni-nav-bar/components/uni-nav-bar/uni-nav-bar-create-component":function(t,n,e){e("543d").createComponent(e("26b0"))}},[["uni_modules/uni-nav-bar/components/uni-nav-bar/uni-nav-bar-create-component"]]]);
},{isPage:false,isComponent:true,currentFile:'uni_modules/uni-nav-bar/components/uni-nav-bar/uni-nav-bar.js'});require("uni_modules/uni-nav-bar/components/uni-nav-bar/uni-nav-bar.js");