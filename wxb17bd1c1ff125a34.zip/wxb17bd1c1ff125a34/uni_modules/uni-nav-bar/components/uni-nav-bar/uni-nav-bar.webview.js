$gwx_XC_19=function(_,_v,_n,_p,_s,_wp,_wl,$gwn,$gwl,$gwh,wh,$gstack,$gwrt,gra,grb,TestTest,wfor,_ca,_da,_r,_rz,_o,_oz,_1,_1z,_2,_2z,_m,_mz,nv_getDate,nv_getRegExp,nv_console,nv_parseInt,nv_parseFloat,nv_isNaN,nv_isFinite,nv_decodeURI,nv_decodeURIComponent,nv_encodeURI,nv_encodeURIComponent,$gdc,nv_JSON,_af,_gv,_ai,_grp,_gd,_gapi,$ixc,_ic,_w,_ev,_tsd){return function(path,global){
if(typeof global==='undefined'){if (typeof __GWX_GLOBAL__==='undefined')global={};else global=__GWX_GLOBAL__;}if(typeof __WXML_GLOBAL__ === 'undefined') {__WXML_GLOBAL__={};
}__WXML_GLOBAL__.modules = __WXML_GLOBAL__.modules || {};
var e_={}
if(typeof(global.entrys)==='undefined')global.entrys={};e_=global.entrys;
var d_={}
if(typeof(global.defines)==='undefined')global.defines={};d_=global.defines;
var f_={}
if(typeof(global.modules)==='undefined')global.modules={};f_=global.modules || {};
var p_={}
__WXML_GLOBAL__.ops_cached = __WXML_GLOBAL__.ops_cached || {}
__WXML_GLOBAL__.ops_set = __WXML_GLOBAL__.ops_set || {};
__WXML_GLOBAL__.ops_init = __WXML_GLOBAL__.ops_init || {};
var z=__WXML_GLOBAL__.ops_set.$gwx_XC_19 || [];
function gz$gwx_XC_19_1(){
if( __WXML_GLOBAL__.ops_cached.$gwx_XC_19_1)return __WXML_GLOBAL__.ops_cached.$gwx_XC_19_1
__WXML_GLOBAL__.ops_cached.$gwx_XC_19_1=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
Z([[4],[[5],[[5],[[5],[1,'uni-navbar']],[1,'data-v-b871d3c0']],[[2,'?:'],[[7],[3,'dark']],[1,'uni-dark'],[1,'']]]])
Z([[4],[[5],[[5],[[5],[[5],[[5],[1,'uni-navbar__content']],[1,'data-v-b871d3c0']],[[2,'?:'],[[7],[3,'fixed']],[1,'uni-navbar--fixed'],[1,'']]],[[2,'?:'],[[7],[3,'shadow']],[1,'uni-navbar--shadow'],[1,'']]],[[2,'?:'],[[7],[3,'border']],[1,'uni-navbar--border'],[1,'']]]])
Z([[2,'+'],[[2,'+'],[1,'background-color:'],[[7],[3,'themeBgColor']]],[1,';']])
Z([[7],[3,'statusBar']])
Z([3,'__l'])
Z([3,'data-v-b871d3c0'])
Z([3,'784be54e-1'])
Z([3,'uni-navbar__header data-v-b871d3c0'])
Z([[2,'+'],[[2,'+'],[[2,'+'],[[2,'+'],[1,'color:'],[[7],[3,'themeColor']]],[1,';']],[[2,'+'],[[2,'+'],[1,'background-color:'],[[7],[3,'themeBgColor']]],[1,';']]],[[2,'+'],[[2,'+'],[1,'height:'],[[7],[3,'navbarHeight']]],[1,';']]])
Z([3,'__e'])
Z([3,'uni-navbar__header-btns uni-navbar__header-btns-left data-v-b871d3c0'])
Z([[4],[[5],[[4],[[5],[[5],[1,'tap']],[[4],[[5],[[4],[[5],[[5],[1,'onClickLeft']],[[4],[[5],[1,'$event']]]]]]]]]]])
Z([[2,'+'],[[2,'+'],[1,'width:'],[[7],[3,'leftIconWidth']]],[1,';']])
Z([3,'left__image data-v-b871d3c0'])
Z([[7],[3,'homePage']])
Z([3,'back__image data-v-b871d3c0'])
Z([[7],[3,'fanhuiImage']])
Z(z[9])
Z([3,'uni-navbar__header-container  data-v-b871d3c0'])
Z([[4],[[5],[[4],[[5],[[5],[1,'tap']],[[4],[[5],[[4],[[5],[[5],[1,'onClickTitle']],[[4],[[5],[1,'$event']]]]]]]]]]])
Z([[6],[[7],[3,'$slots']],[3,'default']])
Z([[2,'>'],[[6],[[7],[3,'$root']],[3,'g0']],[1,0]])
Z([3,'uni-navbar__header-container-inner data-v-b871d3c0'])
Z([3,'uni-nav-bar-text uni-ellipsis-1 data-v-b871d3c0'])
Z([[2,'+'],[[2,'+'],[1,'color:'],[[7],[3,'themeColor']]],[1,';']])
Z([a,[[7],[3,'title']]])
Z(z[9])
Z([3,'uni-navbar__header-btns uni-navbar__header-btns-right data-v-b871d3c0'])
Z([[4],[[5],[[4],[[5],[[5],[1,'tap']],[[4],[[5],[[4],[[5],[[5],[1,'onClickRight']],[[4],[[5],[1,'$event']]]]]]]]]]])
Z([[2,'+'],[[2,'+'],[1,'width:'],[[7],[3,'rightIconWidth']]],[1,';']])
Z([[6],[[7],[3,'$slots']],[3,'right']])
Z([3,'right'])
Z([[6],[[7],[3,'$root']],[3,'g1']])
Z(z[5])
Z(z[4])
Z(z[5])
Z([[7],[3,'themeColor']])
Z([3,'22'])
Z([[7],[3,'rightIcon']])
Z([3,'784be54e-2'])
Z([[6],[[7],[3,'$root']],[3,'g2']])
Z([3,'uni-navbar-btn-text data-v-b871d3c0'])
Z([3,'uni-nav-bar-right-text data-v-b871d3c0'])
Z(z[24])
Z([a,[[7],[3,'rightText']]])
Z([[7],[3,'fixed']])
Z([3,'uni-navbar__placeholder data-v-b871d3c0'])
Z(z[3])
Z(z[4])
Z(z[5])
Z([3,'784be54e-3'])
Z([3,'uni-navbar__placeholder-view data-v-b871d3c0'])
Z([[2,'+'],[[2,'+'],[1,'height:'],[[7],[3,'navbarHeight']]],[1,';']])
})(__WXML_GLOBAL__.ops_cached.$gwx_XC_19_1);return __WXML_GLOBAL__.ops_cached.$gwx_XC_19_1
}
__WXML_GLOBAL__.ops_set.$gwx_XC_19=z;
__WXML_GLOBAL__.ops_init.$gwx_XC_19=true;
var x=['./uni_modules/uni-nav-bar/components/uni-nav-bar/uni-nav-bar.wxml'];d_[x[0]]={}
var m0=function(e,s,r,gg){
var z=gz$gwx_XC_19_1()
var oLT=_n('view')
_rz(z,oLT,'class',0,e,s,gg)
var aNT=_mz(z,'view',['class',1,'style',1],[],e,s,gg)
var tOT=_v()
_(aNT,tOT)
if(_oz(z,3,e,s,gg)){tOT.wxVkey=1
var ePT=_mz(z,'status-bar',['bind:__l',4,'class',1,'vueId',2],[],e,s,gg)
_(tOT,ePT)
}
var bQT=_mz(z,'view',['class',7,'style',1],[],e,s,gg)
var oRT=_mz(z,'view',['bindtap',9,'class',1,'data-event-opts',2,'style',3],[],e,s,gg)
var xST=_n('view')
_rz(z,xST,'class',13,e,s,gg)
var oTT=_v()
_(xST,oTT)
if(_oz(z,14,e,s,gg)){oTT.wxVkey=1
var fUT=_mz(z,'image',['mode',-1,'class',15,'src',1],[],e,s,gg)
_(oTT,fUT)
}
oTT.wxXCkey=1
_(oRT,xST)
_(bQT,oRT)
var cVT=_mz(z,'view',['bindtap',17,'class',1,'data-event-opts',2],[],e,s,gg)
var hWT=_v()
_(cVT,hWT)
if(_oz(z,20,e,s,gg)){hWT.wxVkey=1
var oXT=_n('slot')
_(hWT,oXT)
}
else{hWT.wxVkey=2
var cYT=_v()
_(hWT,cYT)
if(_oz(z,21,e,s,gg)){cYT.wxVkey=1
var oZT=_n('view')
_rz(z,oZT,'class',22,e,s,gg)
var l1T=_mz(z,'text',['class',23,'style',1],[],e,s,gg)
var a2T=_oz(z,25,e,s,gg)
_(l1T,a2T)
_(oZT,l1T)
_(cYT,oZT)
}
cYT.wxXCkey=1
}
hWT.wxXCkey=1
_(bQT,cVT)
var t3T=_mz(z,'view',['bindtap',26,'class',1,'data-event-opts',2,'style',3],[],e,s,gg)
var e4T=_v()
_(t3T,e4T)
if(_oz(z,30,e,s,gg)){e4T.wxVkey=1
var b5T=_n('slot')
_rz(z,b5T,'name',31,e,s,gg)
_(e4T,b5T)
}
else{e4T.wxVkey=2
var o6T=_v()
_(e4T,o6T)
if(_oz(z,32,e,s,gg)){o6T.wxVkey=1
var o8T=_n('view')
_rz(z,o8T,'class',33,e,s,gg)
var f9T=_mz(z,'uni-icons',['bind:__l',34,'class',1,'color',2,'size',3,'type',4,'vueId',5],[],e,s,gg)
_(o8T,f9T)
_(o6T,o8T)
}
var x7T=_v()
_(e4T,x7T)
if(_oz(z,40,e,s,gg)){x7T.wxVkey=1
var c0T=_n('view')
_rz(z,c0T,'class',41,e,s,gg)
var hAU=_mz(z,'text',['class',42,'style',1],[],e,s,gg)
var oBU=_oz(z,44,e,s,gg)
_(hAU,oBU)
_(c0T,hAU)
_(x7T,c0T)
}
o6T.wxXCkey=1
o6T.wxXCkey=3
x7T.wxXCkey=1
}
e4T.wxXCkey=1
e4T.wxXCkey=3
_(bQT,t3T)
_(aNT,bQT)
tOT.wxXCkey=1
tOT.wxXCkey=3
_(oLT,aNT)
var lMT=_v()
_(oLT,lMT)
if(_oz(z,45,e,s,gg)){lMT.wxVkey=1
var cCU=_n('view')
_rz(z,cCU,'class',46,e,s,gg)
var oDU=_v()
_(cCU,oDU)
if(_oz(z,47,e,s,gg)){oDU.wxVkey=1
var lEU=_mz(z,'status-bar',['bind:__l',48,'class',1,'vueId',2],[],e,s,gg)
_(oDU,lEU)
}
var aFU=_mz(z,'view',['class',51,'style',1],[],e,s,gg)
_(cCU,aFU)
oDU.wxXCkey=1
oDU.wxXCkey=3
_(lMT,cCU)
}
lMT.wxXCkey=1
lMT.wxXCkey=3
_(r,oLT)
return r
}
e_[x[0]]={f:m0,j:[],i:[],ti:[],ic:[]}
if(path&&e_[path]){
outerGlobal.__wxml_comp_version__=0.02
return function(env,dd,global){$gwxc=0;var root={"tag":"wx-page"};root.children=[]
;g="$gwx_XC_19";var main=e_[path].f
if (typeof global==="undefined")global={};global.f=$gdc(f_[path],"",1);
if(typeof(outerGlobal.__webview_engine_version__)!='undefined'&&outerGlobal.__webview_engine_version__+1e-6>=0.02+1e-6&&outerGlobal.__mergeData__)
{
env=outerGlobal.__mergeData__(env,dd);
}
try{
main(env,{},root,global);
_tsd(root)
if(typeof(outerGlobal.__webview_engine_version__)=='undefined'|| outerGlobal.__webview_engine_version__+1e-6<0.01+1e-6){return _ev(root);}
}catch(err){
console.log(err)
}
;g="";
return root;
}
}
}
}(__g.a,__g.b,__g.c,__g.d,__g.e,__g.f,__g.g,__g.h,__g.i,__g.j,__g.k,__g.l,__g.m,__g.n,__g.o,__g.p,__g.q,__g.r,__g.s,__g.t,__g.u,__g.v,__g.w,__g.x,__g.y,__g.z,__g.A,__g.B,__g.C,__g.D,__g.E,__g.F,__g.G,__g.H,__g.I,__g.J,__g.K,__g.L,__g.M,__g.N,__g.O,__g.P,__g.Q,__g.R,__g.S,__g.T,__g.U,__g.V,__g.W,__g.X,__g.Y,__g.Z,__g.aa);if(__vd_version_info__.delayedGwx||false)$gwx_XC_19();	if (__vd_version_info__.delayedGwx) __wxAppCode__['uni_modules/uni-nav-bar/components/uni-nav-bar/uni-nav-bar.wxml'] = [$gwx_XC_19, './uni_modules/uni-nav-bar/components/uni-nav-bar/uni-nav-bar.wxml'];else __wxAppCode__['uni_modules/uni-nav-bar/components/uni-nav-bar/uni-nav-bar.wxml'] = $gwx_XC_19( './uni_modules/uni-nav-bar/components/uni-nav-bar/uni-nav-bar.wxml' );
	
var noCss=typeof __vd_version_info__!=='undefined'&&__vd_version_info__.noCss===true;if(!noCss){__wxAppCode__['uni_modules/uni-nav-bar/components/uni-nav-bar/uni-nav-bar.wxss'] = setCssToHead([".",[1],"uni-nav-bar-text.",[1],"data-v-b871d3c0{font-size:14px}\n.",[1],"uni-nav-bar-right-text.",[1],"data-v-b871d3c0{font-size:12px}\n.",[1],"uni-navbar__content.",[1],"data-v-b871d3c0{background-color:initial;position:relative}\n.",[1],"uni-navbar-btn-text.",[1],"data-v-b871d3c0{-webkit-align-items:center;align-items:center;display:-webkit-flex;display:flex;-webkit-flex-direction:column;flex-direction:column;-webkit-justify-content:flex-start;justify-content:flex-start;line-height:12px}\n.",[1],"uni-navbar__header.",[1],"data-v-b871d3c0{font-size:12px;height:44px;padding:0 10px;position:absolute;top:calc(25px * 2 - 6px);width:100%;z-index:100}\n.",[1],"uni-navbar__header-btns.",[1],"data-v-b871d3c0,.",[1],"uni-navbar__header.",[1],"data-v-b871d3c0{display:-webkit-flex;display:flex;-webkit-flex-direction:row;flex-direction:row}\n.",[1],"uni-navbar__header-btns.",[1],"data-v-b871d3c0{-webkit-align-items:center;align-items:center;-webkit-flex-wrap:nowrap;flex-wrap:nowrap;-webkit-justify-content:center;justify-content:center;overflow:hidden;width:",[0,120],"}\n.",[1],"uni-navbar__header-btns-left.",[1],"data-v-b871d3c0{-webkit-align-items:center;align-items:center;display:-webkit-flex;display:flex;-webkit-justify-content:flex-start;justify-content:flex-start;width:",[0,120],"}\n.",[1],"uni-navbar__header-btns-right.",[1],"data-v-b871d3c0{-webkit-align-items:center;align-items:center;display:-webkit-flex;display:flex;-webkit-flex-direction:row;flex-direction:row;-webkit-justify-content:flex-end;justify-content:flex-end}\n.",[1],"uni-navbar__header-container.",[1],"data-v-b871d3c0{display:-webkit-flex;display:flex;-webkit-flex:1;flex:1;overflow:hidden;padding:0 10px}\n.",[1],"uni-navbar__header-container-inner.",[1],"data-v-b871d3c0{-webkit-align-items:center;align-items:center;display:-webkit-flex;display:flex;-webkit-flex:1;flex:1;-webkit-flex-direction:row;flex-direction:row;font-size:12px;-webkit-justify-content:center;justify-content:center;overflow:hidden}\n.",[1],"uni-navbar__placeholder-view.",[1],"data-v-b871d3c0{height:44px}\n.",[1],"uni-navbar--fixed.",[1],"data-v-b871d3c0{left:0;position:fixed;right:0;z-index:998}\n.",[1],"uni-navbar--shadow.",[1],"data-v-b871d3c0{box-shadow:0 1px 6px #ccc}\n.",[1],"uni-ellipsis-1.",[1],"data-v-b871d3c0{overflow:hidden;text-overflow:ellipsis;white-space:nowrap}\n.",[1],"left__image.",[1],"data-v-b871d3c0{-webkit-align-items:center;align-items:center;display:-webkit-flex;display:flex;height:100%;width:100%}\n.",[1],"left__image .",[1],"__image.",[1],"data-v-b871d3c0{background-color:#fff;background-size:100% 100%;border-radius:",[0,28],";height:",[0,56],";width:",[0,56],"}\n.",[1],"left__image .",[1],"back__image.",[1],"data-v-b871d3c0{background-size:100% 100%;background:rgba(0,0,0,.4);border-radius:",[0,28],";height:",[0,56],";width:",[0,56],"}\n",],undefined,{path:"./uni_modules/uni-nav-bar/components/uni-nav-bar/uni-nav-bar.wxss"});
}