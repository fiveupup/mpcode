(global.webpackJsonp = global.webpackJsonp || []).push([ [ "uni_modules/uni-nav-bar/components/uni-nav-bar/uni-nav-bar" ], {
    1039: function(t, n, e) {
        (function(t) {
            Object.defineProperty(n, "__esModule", {
                value: !0
            }), n.default = void 0;
            var i = function(t) {
                return "number" == typeof t ? t + "px" : t;
            }, o = {
                name: "UniNavBar",
                data: function() {
                    return {
                        homeImage: "".concat("https://univs-sishi-1256833609.file.myqcloud.com/resource", "/Home@2x.png"),
                        fanhuiImage: "".concat("https://univs-sishi-1256833609.file.myqcloud.com/resource", "/fanhui@2x.png")
                    };
                },
                components: {
                    statusBar: function() {
                        e.e("uni_modules/uni-nav-bar/components/uni-nav-bar/uni-status-bar").then(function() {
                            return resolve(e("1712"));
                        }.bind(null, e)).catch(e.oe);
                    }
                },
                emits: [ "clickLeft", "clickRight", "clickTitle" ],
                props: {
                    dark: {
                        type: Boolean,
                        default: !1
                    },
                    title: {
                        type: String,
                        default: ""
                    },
                    leftText: {
                        type: String,
                        default: ""
                    },
                    rightText: {
                        type: String,
                        default: ""
                    },
                    leftIcon: {
                        type: String,
                        default: ""
                    },
                    rightIcon: {
                        type: String,
                        default: ""
                    },
                    fixed: {
                        type: [ Boolean, String ],
                        default: !1
                    },
                    color: {
                        type: String,
                        default: ""
                    },
                    backgroundColor: {
                        type: String,
                        default: "unset"
                    },
                    statusBar: {
                        type: [ Boolean, String ],
                        default: !1
                    },
                    shadow: {
                        type: [ Boolean, String ],
                        default: !1
                    },
                    border: {
                        type: [ Boolean, String ],
                        default: !0
                    },
                    height: {
                        type: [ Number, String ],
                        default: 40
                    },
                    positionTop: {
                        type: Number,
                        default: 20
                    },
                    homePage: {
                        type: [ Boolean, String ],
                        default: !1
                    },
                    leftWidth: {
                        type: [ Number, String ],
                        default: 60
                    },
                    rightWidth: {
                        type: [ Number, String ],
                        default: 60
                    }
                },
                computed: {
                    themeBgColor: function() {
                        return this.dark ? this.backgroundColor ? this.backgroundColor : this.dark ? "#333" : "#FFF" : this.backgroundColor || "#FFF";
                    },
                    themeColor: function() {
                        return this.dark ? this.color ? this.color : this.dark ? "#fff" : "#333" : this.color || "#333";
                    },
                    navbarHeight: function() {
                        return i(this.height);
                    },
                    leftIconWidth: function() {
                        return i(this.leftWidth);
                    },
                    rightIconWidth: function() {
                        return i(this.rightWidth);
                    },
                    getTop: function() {
                        return i(this.positionTop);
                    }
                },
                mounted: function() {
                    t.report && "" !== this.title && t.report("title", this.title);
                },
                methods: {
                    onClickLeft: function() {
                        if (this.homePage) {
                            for (var n = 0, e = getCurrentPages(), i = e[e.length - 1], o = e.length - 1; o >= 0; o--) {
                                if (e[o].route != i.route) break;
                                n++;
                            }
                            t.navigateBack({
                                delta: n
                            });
                        }
                    },
                    onClickRight: function() {
                        this.$emit("clickRight");
                    },
                    onClickTitle: function() {
                        this.$emit("clickTitle");
                    }
                }
            };
            n.default = o;
        }).call(this, e("543d").default);
    },
    "26b0": function(t, n, e) {
        e.r(n);
        var i = e("5c71"), o = e("c760");
        for (var r in o) [ "default" ].indexOf(r) < 0 && function(t) {
            e.d(n, t, function() {
                return o[t];
            });
        }(r);
        e("7ecf");
        var u = e("f0c5"), a = Object(u.a)(o.default, i.b, i.c, !1, null, "b871d3c0", null, !1, i.a, void 0);
        n.default = a.exports;
    },
    "5c71": function(t, n, e) {
        e.d(n, "b", function() {
            return o;
        }), e.d(n, "c", function() {
            return r;
        }), e.d(n, "a", function() {
            return i;
        });
        var i = {
            uniIcons: function() {
                return Promise.all([ e.e("common/vendor"), e.e("uni_modules/uni-icons/components/uni-icons/uni-icons") ]).then(e.bind(null, "ca9f"));
            }
        }, o = function() {
            this.$createElement;
            var t = (this._self._c, this.title.length), n = this.rightIcon.length, e = this.rightText.length && !this.rightIcon.length;
            this.$mp.data = Object.assign({}, {
                $root: {
                    g0: t,
                    g1: n,
                    g2: e
                }
            });
        }, r = [];
    },
    "7ecf": function(t, n, e) {
        var i = e("9b13");
        e.n(i).a;
    },
    "9b13": function(t, n, e) {},
    c760: function(t, n, e) {
        e.r(n);
        var i = e("1039"), o = e.n(i);
        for (var r in i) [ "default" ].indexOf(r) < 0 && function(t) {
            e.d(n, t, function() {
                return i[t];
            });
        }(r);
        n.default = o.a;
    }
} ]), (global.webpackJsonp = global.webpackJsonp || []).push([ "uni_modules/uni-nav-bar/components/uni-nav-bar/uni-nav-bar-create-component", {
    "uni_modules/uni-nav-bar/components/uni-nav-bar/uni-nav-bar-create-component": function(t, n, e) {
        e("543d").createComponent(e("26b0"));
    }
}, [ [ "uni_modules/uni-nav-bar/components/uni-nav-bar/uni-nav-bar-create-component" ] ] ]);