$gwx_XC_17=function(_,_v,_n,_p,_s,_wp,_wl,$gwn,$gwl,$gwh,wh,$gstack,$gwrt,gra,grb,TestTest,wfor,_ca,_da,_r,_rz,_o,_oz,_1,_1z,_2,_2z,_m,_mz,nv_getDate,nv_getRegExp,nv_console,nv_parseInt,nv_parseFloat,nv_isNaN,nv_isFinite,nv_decodeURI,nv_decodeURIComponent,nv_encodeURI,nv_encodeURIComponent,$gdc,nv_JSON,_af,_gv,_ai,_grp,_gd,_gapi,$ixc,_ic,_w,_ev,_tsd){return function(path,global){
if(typeof global==='undefined'){if (typeof __GWX_GLOBAL__==='undefined')global={};else global=__GWX_GLOBAL__;}if(typeof __WXML_GLOBAL__ === 'undefined') {__WXML_GLOBAL__={};
}__WXML_GLOBAL__.modules = __WXML_GLOBAL__.modules || {};
var e_={}
if(typeof(global.entrys)==='undefined')global.entrys={};e_=global.entrys;
var d_={}
if(typeof(global.defines)==='undefined')global.defines={};d_=global.defines;
var f_={}
if(typeof(global.modules)==='undefined')global.modules={};f_=global.modules || {};
var p_={}
__WXML_GLOBAL__.ops_cached = __WXML_GLOBAL__.ops_cached || {}
__WXML_GLOBAL__.ops_set = __WXML_GLOBAL__.ops_set || {};
__WXML_GLOBAL__.ops_init = __WXML_GLOBAL__.ops_init || {};
var z=__WXML_GLOBAL__.ops_set.$gwx_XC_17 || [];
function gz$gwx_XC_17_1(){
if( __WXML_GLOBAL__.ops_cached.$gwx_XC_17_1)return __WXML_GLOBAL__.ops_cached.$gwx_XC_17_1
__WXML_GLOBAL__.ops_cached.$gwx_XC_17_1=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
Z([[7],[3,'show']])
Z([3,'__e'])
Z(z[1])
Z([3,'previewImage data-v-0f74a4f6'])
Z([[4],[[5],[[5],[[4],[[5],[[5],[1,'tap']],[[4],[[5],[[4],[[5],[[5],[1,'close']],[[4],[[5],[1,'$event']]]]]]]]]],[[4],[[5],[[5],[1,'touchmove']],[[4],[[5],[[4],[[5],[[5],[1,'']],[[4],[[5],[1,'$event']]]]]]]]]]])
Z([[2,'+'],[[2,'+'],[1,'background-color:'],[[2,'+'],[[2,'+'],[1,'rgba(0,0,0,'],[[7],[3,'opacity']]],[1,')']]],[1,';']])
Z(z[1])
Z([[7],[3,'circular']])
Z([3,'swiper data-v-0f74a4f6'])
Z([[7],[3,'index']])
Z([[4],[[5],[[4],[[5],[[5],[1,'change']],[[4],[[5],[[4],[[5],[[5],[1,'swiperChange']],[[4],[[5],[1,'$event']]]]]]]]]]])
Z([[7],[3,'swiper']])
Z([3,'i'])
Z([3,'img'])
Z([[7],[3,'imgs']])
Z(z[12])
Z([3,'data-v-0f74a4f6'])
Z([[7],[3,'i']])
Z([3,'marea data-v-0f74a4f6'])
Z([1,true])
Z(z[1])
Z(z[1])
Z([3,'mview data-v-0f74a4f6'])
Z([3,'90'])
Z([[4],[[5],[[5],[[4],[[5],[[5],[1,'scale']],[[4],[[5],[[4],[[5],[[5],[1,'onScale']],[[4],[[5],[1,'$event']]]]]]]]]],[[4],[[5],[[5],[1,'change']],[[4],[[5],[[4],[[5],[[5],[1,'movableChange']],[[4],[[5],[1,'$event']]]]]]]]]]])
Z([3,'all'])
Z([3,'2'])
Z([[2,'+'],[1,'movable-view-'],[[7],[3,'i']]])
Z(z[19])
Z([1,false])
Z([3,'true'])
Z([3,'4'])
Z([3,'1'])
Z([[7],[3,'scale']])
Z(z[1])
Z(z[1])
Z(z[1])
Z([3,'image data-v-0f74a4f6'])
Z([[4],[[5],[[5],[[5],[[4],[[5],[[5],[1,'touchmove']],[[4],[[5],[[4],[[5],[[5],[1,'handletouchmove']],[[4],[[5],[1,'$event']]]]]]]]]],[[4],[[5],[[5],[1,'touchstart']],[[4],[[5],[[4],[[5],[[5],[1,'handletouchstart']],[[4],[[5],[1,'$event']]]]]]]]]],[[4],[[5],[[5],[1,'touchend']],[[4],[[5],[[4],[[5],[[5],[1,'handletouchend']],[[4],[[5],[1,'$event']]]]]]]]]]])
Z(z[17])
Z([[7],[3,'img']])
Z([[2,'+'],[1,'image-'],[[7],[3,'i']]])
Z([3,'widthFix'])
Z(z[40])
Z([[2,'+'],[[2,'+'],[1,'transform:'],[[2,'+'],[[2,'+'],[1,'rotateZ('],[[7],[3,'deg']]],[1,'deg)']]],[1,';']])
Z([[2,'>'],[[6],[[7],[3,'$root']],[3,'g0']],[1,0]])
Z([3,'page data-v-0f74a4f6'])
Z([3,'text data-v-0f74a4f6'])
Z([a,[[2,'+'],[[2,'+'],[[2,'+'],[[7],[3,'index']],[1,1]],[1,' / ']],[[6],[[7],[3,'$root']],[3,'g1']]]])
Z([[7],[3,'saveBtn']])
Z(z[1])
Z([3,'save data-v-0f74a4f6'])
Z([[4],[[5],[[4],[[5],[[5],[1,'tap']],[[4],[[5],[[4],[[5],[[5],[1,'save']],[[4],[[5],[1,'$event']]]]]]]]]]])
Z([3,'save__image data-v-0f74a4f6'])
Z([[7],[3,'downLoadImage']])
Z(z[47])
Z([3,'保存至相册'])
Z([[7],[3,'rotateBtn']])
Z(z[1])
Z([3,'rotate data-v-0f74a4f6'])
Z([[4],[[5],[[4],[[5],[[5],[1,'tap']],[[4],[[5],[[4],[[5],[[5],[1,'rotate']],[[4],[[5],[1,'$event']]]]]]]]]]])
Z(z[47])
Z([3,'旋转'])
Z([[6],[[7],[3,'$root']],[3,'g2']])
Z([3,'desc data-v-0f74a4f6'])
Z([a,[[6],[[7],[3,'descs']],[[7],[3,'index']]]])
})(__WXML_GLOBAL__.ops_cached.$gwx_XC_17_1);return __WXML_GLOBAL__.ops_cached.$gwx_XC_17_1
}
__WXML_GLOBAL__.ops_set.$gwx_XC_17=z;
__WXML_GLOBAL__.ops_init.$gwx_XC_17=true;
var x=['./uni_modules/kxj-previewImage/kxj-previewImage.wxml'];d_[x[0]]={}
var m0=function(e,s,r,gg){
var z=gz$gwx_XC_17_1()
var cPS=_v()
_(r,cPS)
if(_oz(z,0,e,s,gg)){cPS.wxVkey=1
var hQS=_mz(z,'view',['bindtap',1,'catchtouchmove',1,'class',2,'data-event-opts',3,'style',4],[],e,s,gg)
var aVS=_mz(z,'swiper',['bindchange',6,'circular',1,'class',2,'current',3,'data-event-opts',4,'disableTouch',5],[],e,s,gg)
var tWS=_v()
_(aVS,tWS)
var eXS=function(oZS,bYS,x1S,gg){
var f3S=_mz(z,'swiper-item',['class',16,'id',1],[],oZS,bYS,gg)
var c4S=_mz(z,'movable-area',['class',18,'scaleArea',1],[],oZS,bYS,gg)
var h5S=_mz(z,'movable-view',['bindchange',20,'bindscale',1,'class',2,'damping',3,'data-event-opts',4,'direction',5,'friction',6,'id',7,'inertia',8,'outOfBounds',9,'scale',10,'scaleMax',11,'scaleMin',12,'scaleValue',13],[],oZS,bYS,gg)
var o6S=_mz(z,'image',['bindtouchend',34,'bindtouchmove',1,'bindtouchstart',2,'class',3,'data-event-opts',4,'data-index',5,'data-src',6,'id',7,'mode',8,'src',9,'style',10],[],oZS,bYS,gg)
_(h5S,o6S)
_(c4S,h5S)
_(f3S,c4S)
_(x1S,f3S)
return x1S
}
tWS.wxXCkey=2
_2z(z,14,eXS,e,s,gg,tWS,'img','i','i')
_(hQS,aVS)
var oRS=_v()
_(hQS,oRS)
if(_oz(z,45,e,s,gg)){oRS.wxVkey=1
var c7S=_n('view')
_rz(z,c7S,'class',46,e,s,gg)
var o8S=_n('text')
_rz(z,o8S,'class',47,e,s,gg)
var l9S=_oz(z,48,e,s,gg)
_(o8S,l9S)
_(c7S,o8S)
_(oRS,c7S)
}
var cSS=_v()
_(hQS,cSS)
if(_oz(z,49,e,s,gg)){cSS.wxVkey=1
var a0S=_mz(z,'view',['catchtap',50,'class',1,'data-event-opts',2],[],e,s,gg)
var tAT=_mz(z,'image',['mode',-1,'class',53,'src',1],[],e,s,gg)
_(a0S,tAT)
var eBT=_n('text')
_rz(z,eBT,'class',55,e,s,gg)
var bCT=_oz(z,56,e,s,gg)
_(eBT,bCT)
_(a0S,eBT)
_(cSS,a0S)
}
var oTS=_v()
_(hQS,oTS)
if(_oz(z,57,e,s,gg)){oTS.wxVkey=1
var oDT=_mz(z,'view',['catchtap',58,'class',1,'data-event-opts',2],[],e,s,gg)
var xET=_n('text')
_rz(z,xET,'class',61,e,s,gg)
var oFT=_oz(z,62,e,s,gg)
_(xET,oFT)
_(oDT,xET)
_(oTS,oDT)
}
var lUS=_v()
_(hQS,lUS)
if(_oz(z,63,e,s,gg)){lUS.wxVkey=1
var fGT=_n('view')
_rz(z,fGT,'class',64,e,s,gg)
var cHT=_oz(z,65,e,s,gg)
_(fGT,cHT)
_(lUS,fGT)
}
oRS.wxXCkey=1
cSS.wxXCkey=1
oTS.wxXCkey=1
lUS.wxXCkey=1
_(cPS,hQS)
}
cPS.wxXCkey=1
return r
}
e_[x[0]]={f:m0,j:[],i:[],ti:[],ic:[]}
if(path&&e_[path]){
outerGlobal.__wxml_comp_version__=0.02
return function(env,dd,global){$gwxc=0;var root={"tag":"wx-page"};root.children=[]
;g="$gwx_XC_17";var main=e_[path].f
if (typeof global==="undefined")global={};global.f=$gdc(f_[path],"",1);
if(typeof(outerGlobal.__webview_engine_version__)!='undefined'&&outerGlobal.__webview_engine_version__+1e-6>=0.02+1e-6&&outerGlobal.__mergeData__)
{
env=outerGlobal.__mergeData__(env,dd);
}
try{
main(env,{},root,global);
_tsd(root)
if(typeof(outerGlobal.__webview_engine_version__)=='undefined'|| outerGlobal.__webview_engine_version__+1e-6<0.01+1e-6){return _ev(root);}
}catch(err){
console.log(err)
}
;g="";
return root;
}
}
}
}(__g.a,__g.b,__g.c,__g.d,__g.e,__g.f,__g.g,__g.h,__g.i,__g.j,__g.k,__g.l,__g.m,__g.n,__g.o,__g.p,__g.q,__g.r,__g.s,__g.t,__g.u,__g.v,__g.w,__g.x,__g.y,__g.z,__g.A,__g.B,__g.C,__g.D,__g.E,__g.F,__g.G,__g.H,__g.I,__g.J,__g.K,__g.L,__g.M,__g.N,__g.O,__g.P,__g.Q,__g.R,__g.S,__g.T,__g.U,__g.V,__g.W,__g.X,__g.Y,__g.Z,__g.aa);if(__vd_version_info__.delayedGwx||false)$gwx_XC_17();	if (__vd_version_info__.delayedGwx) __wxAppCode__['uni_modules/kxj-previewImage/kxj-previewImage.wxml'] = [$gwx_XC_17, './uni_modules/kxj-previewImage/kxj-previewImage.wxml'];else __wxAppCode__['uni_modules/kxj-previewImage/kxj-previewImage.wxml'] = $gwx_XC_17( './uni_modules/kxj-previewImage/kxj-previewImage.wxml' );
	
var noCss=typeof __vd_version_info__!=='undefined'&&__vd_version_info__.noCss===true;if(!noCss){__wxAppCode__['uni_modules/kxj-previewImage/kxj-previewImage.wxss'] = setCssToHead([".",[1],"previewImage.",[1],"data-v-0f74a4f6{background-color:#000;height:100%;left:0;position:fixed;top:0;-webkit-user-select:none;user-select:none;width:100%;z-index:999}\n.",[1],"previewImage .",[1],"swiper.",[1],"data-v-0f74a4f6{height:100%;width:100%}\n.",[1],"previewImage .",[1],"swiper .",[1],"marea.",[1],"data-v-0f74a4f6{height:100%;overflow:hidden;position:fixed;width:100%}\n.",[1],"previewImage .",[1],"swiper .",[1],"marea .",[1],"mview.",[1],"data-v-0f74a4f6{-webkit-align-items:center;align-items:center;display:-webkit-flex;display:flex;height:auto;-webkit-justify-content:center;justify-content:center;min-height:100%;width:100%}\n.",[1],"previewImage .",[1],"swiper .",[1],"marea .",[1],"mview .",[1],"image.",[1],"data-v-0f74a4f6{width:100%}\n.",[1],"previewImage .",[1],"page.",[1],"data-v-0f74a4f6{bottom:",[0,20],";position:absolute;text-align:center;width:100%}\n.",[1],"previewImage .",[1],"page .",[1],"text.",[1],"data-v-0f74a4f6{background-color:rgba(0,0,0,.5);border-radius:",[0,20],";color:#fff;font-size:",[0,26],";padding:",[0,3]," ",[0,16],";-webkit-user-select:none;user-select:none}\n.",[1],"previewImage .",[1],"save.",[1],"data-v-0f74a4f6{-webkit-align-items:center;align-items:center;background:linear-gradient(180deg,#4c77f5,#2542e7);border-radius:",[0,40],";bottom:",[0,120],";box-shadow:0 ",[0,2]," ",[0,8]," 0 rgba(90,115,255,.54);display:-webkit-flex;display:flex;height:",[0,80],";-webkit-justify-content:center;justify-content:center;left:50%;position:absolute;-webkit-transform:translateX(-50%);transform:translateX(-50%);width:",[0,282],"}\n.",[1],"previewImage .",[1],"save .",[1],"save__image.",[1],"data-v-0f74a4f6{background-size:100% 100%;height:",[0,36],";margin-right:",[0,12],";margin-top:",[0,4],";width:",[0,36],"}\n.",[1],"previewImage .",[1],"save .",[1],"text.",[1],"data-v-0f74a4f6{color:#fff;font-family:PingFangSC-Semibold,PingFang SC;font-size:",[0,28],";font-weight:600;-webkit-user-select:none;user-select:none}\n.",[1],"previewImage .",[1],"save .",[1],"text.",[1],"data-v-0f74a4f6:active{background-color:hsla(0,0%,39%,.5)}\n.",[1],"previewImage .",[1],"rotate.",[1],"data-v-0f74a4f6{bottom:",[0,10],";height:",[0,56],";padding:",[0,10],";position:absolute;right:",[0,10],";text-align:center;width:",[0,120],"}\n.",[1],"previewImage .",[1],"rotate .",[1],"text.",[1],"data-v-0f74a4f6{background-color:rgba(0,0,0,.5);border:",[0,1]," solid #f1f1f1;border-radius:",[0,20],";color:#fff;font-size:",[0,30],";padding:",[0,6]," ",[0,22],";-webkit-user-select:none;user-select:none}\n.",[1],"previewImage .",[1],"rotate .",[1],"text.",[1],"data-v-0f74a4f6:active{background-color:hsla(0,0%,39%,.5)}\n.",[1],"previewImage .",[1],"desc.",[1],"data-v-0f74a4f6{background-color:rgba(0,0,0,.5);color:#fff;font-size:",[0,28],";letter-spacing:",[0,3],";overflow:hidden;padding:",[0,5]," ",[0,10],";position:absolute;text-align:center;text-overflow:ellipsis;top:0;-webkit-user-select:none;user-select:none;white-space:nowrap;width:100%}\n",],undefined,{path:"./uni_modules/kxj-previewImage/kxj-previewImage.wxss"});
}