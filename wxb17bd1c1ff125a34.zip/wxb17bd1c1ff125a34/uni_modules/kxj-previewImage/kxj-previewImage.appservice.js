$gwx_XC_17=function(_,_v,_n,_p,_s,_wp,_wl,$gwn,$gwl,$gwh,wh,$gstack,$gwrt,gra,grb,TestTest,wfor,_ca,_da,_r,_rz,_o,_oz,_1,_1z,_2,_2z,_m,_mz,nv_getDate,nv_getRegExp,nv_console,nv_parseInt,nv_parseFloat,nv_isNaN,nv_isFinite,nv_decodeURI,nv_decodeURIComponent,nv_encodeURI,nv_encodeURIComponent,$gdc,nv_JSON,_af,_gv,_ai,_grp,_gd,_gapi,$ixc,_ic,_w,_ev,_tsd){return function(path,global){
if(typeof global==='undefined'){if (typeof __GWX_GLOBAL__==='undefined')global={};else global=__GWX_GLOBAL__;}if(typeof __WXML_GLOBAL__ === 'undefined') {__WXML_GLOBAL__={};
}__WXML_GLOBAL__.modules = __WXML_GLOBAL__.modules || {};
var e_={}
if(typeof(global.entrys)==='undefined')global.entrys={};e_=global.entrys;
var d_={}
if(typeof(global.defines)==='undefined')global.defines={};d_=global.defines;
var f_={}
if(typeof(global.modules)==='undefined')global.modules={};f_=global.modules || {};
var p_={}
__WXML_GLOBAL__.ops_cached = __WXML_GLOBAL__.ops_cached || {}
__WXML_GLOBAL__.ops_set = __WXML_GLOBAL__.ops_set || {};
__WXML_GLOBAL__.ops_init = __WXML_GLOBAL__.ops_init || {};
var z=__WXML_GLOBAL__.ops_set.$gwx_XC_17 || [];
function gz$gwx_XC_17_1(){
if( __WXML_GLOBAL__.ops_cached.$gwx_XC_17_1)return __WXML_GLOBAL__.ops_cached.$gwx_XC_17_1
__WXML_GLOBAL__.ops_cached.$gwx_XC_17_1=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
Z([[7],[3,'show']])
Z([3,'__e'])
Z(z[1])
Z([3,'previewImage data-v-0f74a4f6'])
Z([[4],[[5],[[5],[[4],[[5],[[5],[1,'tap']],[[4],[[5],[[4],[[5],[[5],[1,'close']],[[4],[[5],[1,'$event']]]]]]]]]],[[4],[[5],[[5],[1,'touchmove']],[[4],[[5],[[4],[[5],[[5],[1,'']],[[4],[[5],[1,'$event']]]]]]]]]]])
Z([[2,'+'],[[2,'+'],[1,'background-color:'],[[2,'+'],[[2,'+'],[1,'rgba(0,0,0,'],[[7],[3,'opacity']]],[1,')']]],[1,';']])
Z([[2,'>'],[[6],[[7],[3,'$root']],[3,'g0']],[1,0]])
Z([[7],[3,'saveBtn']])
Z([[7],[3,'rotateBtn']])
Z([[6],[[7],[3,'$root']],[3,'g2']])
})(__WXML_GLOBAL__.ops_cached.$gwx_XC_17_1);return __WXML_GLOBAL__.ops_cached.$gwx_XC_17_1
}
__WXML_GLOBAL__.ops_set.$gwx_XC_17=z;
__WXML_GLOBAL__.ops_init.$gwx_XC_17=true;
var x=['./uni_modules/kxj-previewImage/kxj-previewImage.wxml'];d_[x[0]]={}
var m0=function(e,s,r,gg){
var z=gz$gwx_XC_17_1()
var hYD=_v()
_(r,hYD)
if(_oz(z,0,e,s,gg)){hYD.wxVkey=1
var oZD=_mz(z,'view',['bindtap',1,'catchtouchmove',1,'class',2,'data-event-opts',3,'style',4],[],e,s,gg)
var c1D=_v()
_(oZD,c1D)
if(_oz(z,6,e,s,gg)){c1D.wxVkey=1
}
var o2D=_v()
_(oZD,o2D)
if(_oz(z,7,e,s,gg)){o2D.wxVkey=1
}
var l3D=_v()
_(oZD,l3D)
if(_oz(z,8,e,s,gg)){l3D.wxVkey=1
}
var a4D=_v()
_(oZD,a4D)
if(_oz(z,9,e,s,gg)){a4D.wxVkey=1
}
c1D.wxXCkey=1
o2D.wxXCkey=1
l3D.wxXCkey=1
a4D.wxXCkey=1
_(hYD,oZD)
}
hYD.wxXCkey=1
return r
}
e_[x[0]]={f:m0,j:[],i:[],ti:[],ic:[]}
if(path&&e_[path]){
return function(env,dd,global){$gwxc=0;var root={"tag":"wx-page"};root.children=[]
;g="$gwx_XC_17";var main=e_[path].f
if (typeof global==="undefined")global={};global.f=$gdc(f_[path],"",1);
try{
main(env,{},root,global);
_tsd(root)
}catch(err){
console.log(err)
}
;g="";
return root;
}
}
}
}(__g.a,__g.b,__g.c,__g.d,__g.e,__g.f,__g.g,__g.h,__g.i,__g.j,__g.k,__g.l,__g.m,__g.n,__g.o,__g.p,__g.q,__g.r,__g.s,__g.t,__g.u,__g.v,__g.w,__g.x,__g.y,__g.z,__g.A,__g.B,__g.C,__g.D,__g.E,__g.F,__g.G,__g.H,__g.I,__g.J,__g.K,__g.L,__g.M,__g.N,__g.O,__g.P,__g.Q,__g.R,__g.S,__g.T,__g.U,__g.V,__g.W,__g.X,__g.Y,__g.Z,__g.aa);if(__vd_version_info__.delayedGwx||false)$gwx_XC_17();	if (__vd_version_info__.delayedGwx) __wxAppCode__['uni_modules/kxj-previewImage/kxj-previewImage.wxml'] = [$gwx_XC_17, './uni_modules/kxj-previewImage/kxj-previewImage.wxml'];else __wxAppCode__['uni_modules/kxj-previewImage/kxj-previewImage.wxml'] = $gwx_XC_17( './uni_modules/kxj-previewImage/kxj-previewImage.wxml' );
	;__wxRoute = "uni_modules/kxj-previewImage/kxj-previewImage";__wxRouteBegin = true;__wxAppCurrentFile__="uni_modules/kxj-previewImage/kxj-previewImage.js";define("uni_modules/kxj-previewImage/kxj-previewImage.js",function(require,module,exports,window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){
"use strict";(global.webpackJsonp=global.webpackJsonp||[]).push([["uni_modules/kxj-previewImage/kxj-previewImage"],{3219:function(e,t,n){n.d(t,"b",(function(){return i})),n.d(t,"c",(function(){return o})),n.d(t,"a",(function(){}));var i=function(){var e=this,t=(e.$createElement,e._self._c,e.show?e.imgs.length:null),n=e.show&&t>0?e.imgs.length:null,i=e.show?e.descs.length>0&&e.descs.length==e.imgs.length&&e.descs[e.index].length>0:null;e.$mp.data=Object.assign({},{$root:{g0:t,g1:n,g2:i}})},o=[]},"4ebc":function(e,t,n){n.r(t);var i=n("3219"),o=n("af96");for(var s in o)["default"].indexOf(s)<0&&function(e){n.d(t,e,(function(){return o[e]}))}(s);n("53d5");var a=n("f0c5"),c=Object(a.a)(o.default,i.b,i.c,!1,null,"0f74a4f6",null,!1,i.a,void 0);t.default=c.exports},"53d5":function(e,t,n){var i=n("8f37");n.n(i).a},"8f37":function(e,t,n){},af96:function(e,t,n){n.r(t);var i=n("ce54"),o=n.n(i);for(var s in i)["default"].indexOf(s)<0&&function(e){n.d(t,e,(function(){return i[e]}))}(s);t.default=o.a},ce54:function(e,t,n){(function(e){Object.defineProperty(t,"__esModule",{value:!0}),t.default=void 0;var n={name:"ksj-previewImage",props:{imgs:{type:Array,required:!0,default:function(){return[]}},descs:{type:Array,required:!1,default:function(){return[]}},opacity:{type:Number,default:.6},saveBtn:{type:Boolean,default:!0},rotateBtn:{type:Boolean,default:!0},circular:{type:Boolean,default:!1}},data:function(){return{swiper:!1,show:!1,index:0,deg:0,time:0,interval:1e3,scale:1,downLoadImage:"".concat("https://univs-sishi-1256833609.file.myqcloud.com/resource","/xiazai@2x.png")}},methods:{onScale:function(e){},handletouchstart:function(e){var t=this;return 1!=e.touches.length||(this.time=setTimeout((function(){t.onLongPress(e)}),this.interval)),!1},handletouchend:function(){return clearTimeout(this.time),this.time,!1},handletouchmove:function(){clearTimeout(this.time),this.time=0},onLongPress:function(e){var t={src:e.currentTarget.dataset.src,index:e.currentTarget.dataset.index};this.$emit("longPress",t)},swiperChange:function(e){this.index=e.target.current,this.$nextTick((function(){this.scale=1}))},movableChange:function(e){},save:function(t){console.log(t);var n=this,i=this.imgs[this.index];e.authorize({scope:"scope.writePhotosAlbum",success:function(){console.log("kxj-previewImage:允许储存"),n.downloadImg(i)}})},downloadImg:function(t){e.showLoading({title:"大图提取中"}),e.downloadFile({url:t,success:function(t){console.log("kxj-previewImage:下载成功"),e.hideLoading(),e.saveImageToPhotosAlbum({filePath:t.tempFilePath,success:function(){e.showToast({title:"已保存至相册",duration:1e3})}})},fail:function(){e.hideLoading(),e.showToast({title:"图片下载失败",icon:"none",duration:1e3})}})},rotate:function(e){this.deg=270==this.deg?0:this.deg+90},open:function(e){if(null!==e&&""!==e){if(isNaN(e))-1===this.imgs.indexOf(e)?(this.imgs=[e],this.index=0,console.log("kxj-previewImage:未在图片地址数组中找到传入的图片，已为你自动打开单张预览模式")):this.index=this.imgs.indexOf(e);else e>=this.imgs.length?console.log("kxj-previewImage:打开参数无效"):this.index=e;this.show=!0}else console.log("kxj-previewImage:打开参数无效")},close:function(e){this.show=!1,this.index=0,this.deg=0,this.time=0,this.interval=1e3,this.scale=1}}};t.default=n}).call(this,n("543d").default)}}]),(global.webpackJsonp=global.webpackJsonp||[]).push(["uni_modules/kxj-previewImage/kxj-previewImage-create-component",{"uni_modules/kxj-previewImage/kxj-previewImage-create-component":function(e,t,n){n("543d").createComponent(n("4ebc"))}},[["uni_modules/kxj-previewImage/kxj-previewImage-create-component"]]]);
},{isPage:false,isComponent:true,currentFile:'uni_modules/kxj-previewImage/kxj-previewImage.js'});require("uni_modules/kxj-previewImage/kxj-previewImage.js");