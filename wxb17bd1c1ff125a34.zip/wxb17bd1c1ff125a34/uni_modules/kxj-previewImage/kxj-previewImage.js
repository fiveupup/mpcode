(global.webpackJsonp = global.webpackJsonp || []).push([ [ "uni_modules/kxj-previewImage/kxj-previewImage" ], {
    3219: function(e, t, n) {
        n.d(t, "b", function() {
            return i;
        }), n.d(t, "c", function() {
            return o;
        }), n.d(t, "a", function() {});
        var i = function() {
            var e = this, t = (e.$createElement, e._self._c, e.show ? e.imgs.length : null), n = e.show && t > 0 ? e.imgs.length : null, i = e.show ? e.descs.length > 0 && e.descs.length == e.imgs.length && e.descs[e.index].length > 0 : null;
            e.$mp.data = Object.assign({}, {
                $root: {
                    g0: t,
                    g1: n,
                    g2: i
                }
            });
        }, o = [];
    },
    "4ebc": function(e, t, n) {
        n.r(t);
        var i = n("3219"), o = n("af96");
        for (var s in o) [ "default" ].indexOf(s) < 0 && function(e) {
            n.d(t, e, function() {
                return o[e];
            });
        }(s);
        n("53d5");
        var a = n("f0c5"), c = Object(a.a)(o.default, i.b, i.c, !1, null, "0f74a4f6", null, !1, i.a, void 0);
        t.default = c.exports;
    },
    "53d5": function(e, t, n) {
        var i = n("8f37");
        n.n(i).a;
    },
    "8f37": function(e, t, n) {},
    af96: function(e, t, n) {
        n.r(t);
        var i = n("ce54"), o = n.n(i);
        for (var s in i) [ "default" ].indexOf(s) < 0 && function(e) {
            n.d(t, e, function() {
                return i[e];
            });
        }(s);
        t.default = o.a;
    },
    ce54: function(e, t, n) {
        (function(e) {
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = void 0;
            var n = {
                name: "ksj-previewImage",
                props: {
                    imgs: {
                        type: Array,
                        required: !0,
                        default: function() {
                            return [];
                        }
                    },
                    descs: {
                        type: Array,
                        required: !1,
                        default: function() {
                            return [];
                        }
                    },
                    opacity: {
                        type: Number,
                        default: .6
                    },
                    saveBtn: {
                        type: Boolean,
                        default: !0
                    },
                    rotateBtn: {
                        type: Boolean,
                        default: !0
                    },
                    circular: {
                        type: Boolean,
                        default: !1
                    }
                },
                data: function() {
                    return {
                        swiper: !1,
                        show: !1,
                        index: 0,
                        deg: 0,
                        time: 0,
                        interval: 1e3,
                        scale: 1,
                        downLoadImage: "".concat("https://univs-sishi-1256833609.file.myqcloud.com/resource", "/xiazai@2x.png")
                    };
                },
                methods: {
                    onScale: function(e) {},
                    handletouchstart: function(e) {
                        var t = this;
                        return 1 != e.touches.length || (this.time = setTimeout(function() {
                            t.onLongPress(e);
                        }, this.interval)), !1;
                    },
                    handletouchend: function() {
                        return clearTimeout(this.time), this.time, !1;
                    },
                    handletouchmove: function() {
                        clearTimeout(this.time), this.time = 0;
                    },
                    onLongPress: function(e) {
                        var t = {
                            src: e.currentTarget.dataset.src,
                            index: e.currentTarget.dataset.index
                        };
                        this.$emit("longPress", t);
                    },
                    swiperChange: function(e) {
                        this.index = e.target.current, this.$nextTick(function() {
                            this.scale = 1;
                        });
                    },
                    movableChange: function(e) {},
                    save: function(t) {
                        console.log(t);
                        var n = this, i = this.imgs[this.index];
                        e.authorize({
                            scope: "scope.writePhotosAlbum",
                            success: function() {
                                console.log("kxj-previewImage:允许储存"), n.downloadImg(i);
                            }
                        });
                    },
                    downloadImg: function(t) {
                        e.showLoading({
                            title: "大图提取中"
                        }), e.downloadFile({
                            url: t,
                            success: function(t) {
                                console.log("kxj-previewImage:下载成功"), e.hideLoading(), e.saveImageToPhotosAlbum({
                                    filePath: t.tempFilePath,
                                    success: function() {
                                        e.showToast({
                                            title: "已保存至相册",
                                            duration: 1e3
                                        });
                                    }
                                });
                            },
                            fail: function() {
                                e.hideLoading(), e.showToast({
                                    title: "图片下载失败",
                                    icon: "none",
                                    duration: 1e3
                                });
                            }
                        });
                    },
                    rotate: function(e) {
                        this.deg = 270 == this.deg ? 0 : this.deg + 90;
                    },
                    open: function(e) {
                        if (null !== e && "" !== e) {
                            if (isNaN(e)) -1 === this.imgs.indexOf(e) ? (this.imgs = [ e ], this.index = 0, 
                            console.log("kxj-previewImage:未在图片地址数组中找到传入的图片，已为你自动打开单张预览模式")) : this.index = this.imgs.indexOf(e); else e >= this.imgs.length ? console.log("kxj-previewImage:打开参数无效") : this.index = e;
                            this.show = !0;
                        } else console.log("kxj-previewImage:打开参数无效");
                    },
                    close: function(e) {
                        this.show = !1, this.index = 0, this.deg = 0, this.time = 0, this.interval = 1e3, 
                        this.scale = 1;
                    }
                }
            };
            t.default = n;
        }).call(this, n("543d").default);
    }
} ]), (global.webpackJsonp = global.webpackJsonp || []).push([ "uni_modules/kxj-previewImage/kxj-previewImage-create-component", {
    "uni_modules/kxj-previewImage/kxj-previewImage-create-component": function(e, t, n) {
        n("543d").createComponent(n("4ebc"));
    }
}, [ [ "uni_modules/kxj-previewImage/kxj-previewImage-create-component" ] ] ]);