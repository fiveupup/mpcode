$gwx_XC_8=function(_,_v,_n,_p,_s,_wp,_wl,$gwn,$gwl,$gwh,wh,$gstack,$gwrt,gra,grb,TestTest,wfor,_ca,_da,_r,_rz,_o,_oz,_1,_1z,_2,_2z,_m,_mz,nv_getDate,nv_getRegExp,nv_console,nv_parseInt,nv_parseFloat,nv_isNaN,nv_isFinite,nv_decodeURI,nv_decodeURIComponent,nv_encodeURI,nv_encodeURIComponent,$gdc,nv_JSON,_af,_gv,_ai,_grp,_gd,_gapi,$ixc,_ic,_w,_ev,_tsd){return function(path,global){
if(typeof global==='undefined'){if (typeof __GWX_GLOBAL__==='undefined')global={};else global=__GWX_GLOBAL__;}if(typeof __WXML_GLOBAL__ === 'undefined') {__WXML_GLOBAL__={};
}__WXML_GLOBAL__.modules = __WXML_GLOBAL__.modules || {};
var e_={}
if(typeof(global.entrys)==='undefined')global.entrys={};e_=global.entrys;
var d_={}
if(typeof(global.defines)==='undefined')global.defines={};d_=global.defines;
var f_={}
if(typeof(global.modules)==='undefined')global.modules={};f_=global.modules || {};
var p_={}
__WXML_GLOBAL__.ops_cached = __WXML_GLOBAL__.ops_cached || {}
__WXML_GLOBAL__.ops_set = __WXML_GLOBAL__.ops_set || {};
__WXML_GLOBAL__.ops_init = __WXML_GLOBAL__.ops_init || {};
var z=__WXML_GLOBAL__.ops_set.$gwx_XC_8 || [];
function gz$gwx_XC_8_1(){
if( __WXML_GLOBAL__.ops_cached.$gwx_XC_8_1)return __WXML_GLOBAL__.ops_cached.$gwx_XC_8_1
__WXML_GLOBAL__.ops_cached.$gwx_XC_8_1=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
Z([3,'gjs-activity data-v-6d4bfa32'])
Z([3,'__l'])
Z([3,'data-v-6d4bfa32'])
Z([1,false])
Z([3,'08f9d0db-1'])
Z(z[1])
Z(z[2])
Z([3,'wx'])
Z([3,'van-notify'])
Z([3,'08f9d0db-2'])
Z(z[1])
Z(z[2])
Z(z[7])
Z([3,'van-dialog'])
Z([3,'08f9d0db-3'])
Z([3,'gjs-homepagebg_body data-v-6d4bfa32'])
Z([[7],[3,'register']])
Z([3,'borad data-v-6d4bfa32'])
Z([[7],[3,'isProtocolShow']])
Z(z[1])
Z([3,'__e'])
Z(z[2])
Z([[4],[[5],[[4],[[5],[[5],[1,'^changeStates']],[[4],[[5],[[4],[[5],[1,'changeStates']]]]]]]]])
Z([3,'08f9d0db-4'])
Z([[7],[3,'isUserinfoRepairShow']])
Z(z[1])
Z(z[20])
Z(z[2])
Z([[4],[[5],[[4],[[5],[[5],[1,'^close']],[[4],[[5],[[4],[[5],[1,'closeUserinfoRepair']]]]]]]]])
Z([[7],[3,'needRepairInfo']])
Z([3,'08f9d0db-5'])
Z([3,'main_contet data-v-6d4bfa32'])
Z([[6],[[7],[3,'$root']],[3,'g0']])
Z([[2,'>'],[[6],[[7],[3,'$root']],[3,'g1']],[1,0]])
Z(z[1])
Z([3,'campus_activity data-v-6d4bfa32'])
Z([[7],[3,'personalActivities']])
Z([[2,'+'],[[2,'+'],[1,'display:'],[[2,'?:'],[[7],[3,'isCampus']],[1,'block'],[1,'none']]],[1,';']])
Z([3,'08f9d0db-6'])
Z([[2,'>'],[[6],[[7],[3,'$root']],[3,'g2']],[1,0]])
Z(z[1])
Z(z[20])
Z([3,'extend_father data-v-6d4bfa32'])
Z([[4],[[5],[[4],[[5],[[5],[1,'^goRegister']],[[4],[[5],[[4],[[5],[1,'goRegister']]]]]]]]])
Z([[7],[3,'isCampus']])
Z([[7],[3,'publicActivities']])
Z([[2,'+'],[[2,'+'],[1,'display:'],[[2,'?:'],[[7],[3,'isActivities']],[1,'block'],[1,'none']]],[1,';']])
Z([3,'08f9d0db-7'])
})(__WXML_GLOBAL__.ops_cached.$gwx_XC_8_1);return __WXML_GLOBAL__.ops_cached.$gwx_XC_8_1
}
__WXML_GLOBAL__.ops_set.$gwx_XC_8=z;
__WXML_GLOBAL__.ops_init.$gwx_XC_8=true;
var x=['./pages/activity/index.wxml'];d_[x[0]]={}
var m0=function(e,s,r,gg){
var z=gz$gwx_XC_8_1()
var bUB=_n('view')
_rz(z,bUB,'class',0,e,s,gg)
var oVB=_mz(z,'uni-nav-bar',['bind:__l',1,'class',1,'statusBar',2,'vueId',3],[],e,s,gg)
_(bUB,oVB)
var xWB=_mz(z,'van-notify',['bind:__l',5,'class',1,'data-com-type',2,'id',3,'vueId',4],[],e,s,gg)
_(bUB,xWB)
var oXB=_mz(z,'van-dialog',['bind:__l',10,'class',1,'data-com-type',2,'id',3,'vueId',4],[],e,s,gg)
_(bUB,oXB)
var fYB=_n('view')
_rz(z,fYB,'class',15,e,s,gg)
var cZB=_v()
_(fYB,cZB)
if(_oz(z,16,e,s,gg)){cZB.wxVkey=1
var h1B=_n('view')
_rz(z,h1B,'class',17,e,s,gg)
var o2B=_v()
_(h1B,o2B)
if(_oz(z,18,e,s,gg)){o2B.wxVkey=1
var c3B=_mz(z,'protocol',['bind:__l',19,'bind:changeStates',1,'class',2,'data-event-opts',3,'vueId',4],[],e,s,gg)
_(o2B,c3B)
}
else{o2B.wxVkey=2
var o4B=_v()
_(o2B,o4B)
if(_oz(z,24,e,s,gg)){o4B.wxVkey=1
var l5B=_mz(z,'userinfo-repair',['bind:__l',25,'bind:close',1,'class',2,'data-event-opts',3,'needRepairInfo',4,'vueId',5],[],e,s,gg)
_(o4B,l5B)
}
o4B.wxXCkey=1
o4B.wxXCkey=3
}
o2B.wxXCkey=1
o2B.wxXCkey=3
o2B.wxXCkey=3
_(cZB,h1B)
}
var a6B=_n('view')
_rz(z,a6B,'class',31,e,s,gg)
var t7B=_v()
_(a6B,t7B)
if(_oz(z,32,e,s,gg)){t7B.wxVkey=1
}
var e8B=_v()
_(a6B,e8B)
if(_oz(z,33,e,s,gg)){e8B.wxVkey=1
var o0B=_mz(z,'campus-activity-list',['bind:__l',34,'class',1,'personalActivities',2,'style',3,'vueId',4],[],e,s,gg)
_(e8B,o0B)
}
var b9B=_v()
_(a6B,b9B)
if(_oz(z,39,e,s,gg)){b9B.wxVkey=1
var xAC=_mz(z,'activity-list',['bind:__l',40,'bind:goRegister',1,'class',2,'data-event-opts',3,'isCampus',4,'publicActivities',5,'style',6,'vueId',7],[],e,s,gg)
_(b9B,xAC)
}
t7B.wxXCkey=1
e8B.wxXCkey=1
e8B.wxXCkey=3
b9B.wxXCkey=1
b9B.wxXCkey=3
_(fYB,a6B)
cZB.wxXCkey=1
cZB.wxXCkey=3
_(bUB,fYB)
_(r,bUB)
return r
}
e_[x[0]]={f:m0,j:[],i:[],ti:[],ic:[]}
if(path&&e_[path]){
return function(env,dd,global){$gwxc=0;var root={"tag":"wx-page"};root.children=[]
;g="$gwx_XC_8";var main=e_[path].f
if (typeof global==="undefined")global={};global.f=$gdc(f_[path],"",1);
try{
main(env,{},root,global);
_tsd(root)
}catch(err){
console.log(err)
}
;g="";
return root;
}
}
}
}(__g.a,__g.b,__g.c,__g.d,__g.e,__g.f,__g.g,__g.h,__g.i,__g.j,__g.k,__g.l,__g.m,__g.n,__g.o,__g.p,__g.q,__g.r,__g.s,__g.t,__g.u,__g.v,__g.w,__g.x,__g.y,__g.z,__g.A,__g.B,__g.C,__g.D,__g.E,__g.F,__g.G,__g.H,__g.I,__g.J,__g.K,__g.L,__g.M,__g.N,__g.O,__g.P,__g.Q,__g.R,__g.S,__g.T,__g.U,__g.V,__g.W,__g.X,__g.Y,__g.Z,__g.aa);if(__vd_version_info__.delayedGwx||false)$gwx_XC_8();	if (__vd_version_info__.delayedGwx) __wxAppCode__['pages/activity/index.wxml'] = [$gwx_XC_8, './pages/activity/index.wxml'];else __wxAppCode__['pages/activity/index.wxml'] = $gwx_XC_8( './pages/activity/index.wxml' );
	;__wxRoute = "pages/activity/index";__wxRouteBegin = true;__wxAppCurrentFile__="pages/activity/index.js";define("pages/activity/index.js",function(require,module,exports,window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){
"use strict";(global.webpackJsonp=global.webpackJsonp||[]).push([["pages/activity/index"],{"23ed":function(t,e,n){n.r(e);var i=n("ebc9"),r=n("f19d");for(var c in r)["default"].indexOf(c)<0&&function(t){n.d(e,t,(function(){return r[t]}))}(c);n("dc65");var a=n("f0c5"),o=Object(a.a)(r.default,i.b,i.c,!1,null,"6d4bfa32",null,!1,i.a,void 0);e.default=o.exports},"56c3":function(t,e,n){},a4e0:function(t,e,n){(function(t){var i=n("4ea4");Object.defineProperty(e,"__esModule",{value:!0}),e.default=void 0;var r=i(n("2eee")),c=i(n("9523")),a=i(n("c973")),o=n("6b44"),s=n("386d"),u=n("185a");function f(t,e){var n=Object.keys(t);if(Object.getOwnPropertySymbols){var i=Object.getOwnPropertySymbols(t);e&&(i=i.filter((function(e){return Object.getOwnPropertyDescriptor(t,e).enumerable}))),n.push.apply(n,i)}return n}function l(t){for(var e=1;e<arguments.length;e++){var n=null!=arguments[e]?arguments[e]:{};e%2?f(Object(n),!0).forEach((function(e){(0,c.default)(t,e,n[e])})):Object.getOwnPropertyDescriptors?Object.defineProperties(t,Object.getOwnPropertyDescriptors(n)):f(Object(n)).forEach((function(e){Object.defineProperty(t,e,Object.getOwnPropertyDescriptor(n,e))}))}return t}var d={name:"Activity",components:{ActivityList:function(){Promise.all([n.e("common/vendor"),n.e("pages/activity/components/ActivityList")]).then(function(){return resolve(n("65ca"))}.bind(null,n)).catch(n.oe)},CampusActivityList:function(){n.e("pages/activity/components/CampusActivityList").then(function(){return resolve(n("d5a2"))}.bind(null,n)).catch(n.oe)},UserinfoRepair:function(){Promise.all([n.e("common/vendor"),n.e("utils/common-components/userinfo-repair/index")]).then(function(){return resolve(n("b1f7"))}.bind(null,n)).catch(n.oe)},Protocol:function(){n.e("pages/activity/components/Protocol").then(function(){return resolve(n("0765"))}.bind(null,n)).catch(n.oe)},uniNavBar:function(){n.e("uni_modules/uni-nav-bar/components/uni-nav-bar/uni-nav-bar").then(function(){return resolve(n("26b0"))}.bind(null,n)).catch(n.oe)}},onPullDownRefresh:function(){var e=this;return(0,a.default)(r.default.mark((function n(){return r.default.wrap((function(n){for(;;)switch(n.prev=n.next){case 0:if(!e.isPerfect){n.next=4;break}return n.next=3,e.getActivityList();case 3:setTimeout((function(){t.stopPullDownRefresh()}),1e3);case 4:case"end":return n.stop()}}),n)})))()},onShow:function(){t.removeStorageSync("oragnizer")},created:function(){var t=this;return(0,a.default)(r.default.mark((function e(){return r.default.wrap((function(e){for(;;)switch(e.prev=e.next){case 0:return e.next=2,t.getActivityList();case 2:case"end":return e.stop()}}),e)})))()},data:function(){return{personnalImage:"".concat("https://univs-sishi-1256833609.file.myqcloud.com/resource","/geren@2x.png"),certificateImage:"".concat("https://univs-sishi-1256833609.file.myqcloud.com/resource","/zhengshu.png"),zanwuImage:"".concat("https://univs-sishi-1256833609.file.myqcloud.com/resource","/zanwu@2x.png"),isActivities:!0,isCampus:!0,publicActivities:[],personalActivities:[],mantleStates:1,defaultImages:[{id:1,title_file:"".concat("https://univs-sishi-1256833609.file.myqcloud.com/resource","/default1.jpg"),title:"中国大学生在线知识问答平台"},{id:2,title_file:"".concat("https://univs-sishi-1256833609.file.myqcloud.com/resource","/default2.jpg"),title:"读书只是竞答"},{id:3,title_file:"".concat("https://univs-sishi-1256833609.file.myqcloud.com/resource","/default3.jpg"),title:"“大学阅读·阅读大学”读书知识问答"},{id:4,title_file:"".concat("https://univs-sishi-1256833609.file.myqcloud.com/resource","/default4.jpg"),title:"大学阅读·阅读大学读书知识问答"}],needRepairInfo:{name:1,nick_name:1,university_id:1,politics:1}}},computed:l(l({},(0,n("26cb").mapState)(["register","isPerfect","userInfo"])),{},{buttonText:function(){return this.isPerfect?"个人中心":"立即登录"},isProtocolShow:function(){return 1===this.mantleStates},isUserinfoRepairShow:function(){return 2===this.mantleStates}}),methods:{getActivityList:function(){var t=this;return(0,a.default)(r.default.mark((function e(){var n,i;return r.default.wrap((function(e){for(;;)switch(e.prev=e.next){case 0:return t.publicActivities=[],t.personalActivities=[],e.next=4,(0,o.getActivities)();case 4:n=e.sent,0===(i=n.data).code&&(i.data.public.forEach((function(e){t.publicActivities.push(Object.freeze(new u.PublicActivity(e)))})),i.data.personal.forEach((function(e){t.personalActivities.push(Object.freeze(new u.PublicActivity(e)))})),0===t.publicActivities.length?t.isActivities=!1:t.isActivities=!0,0===t.personalActivities.length?t.isCampus=!1:t.isCampus=!0);case 7:case"end":return e.stop()}}),e)})))()},changeStates:function(){1===this.mantleStates?this.mantleStates=2:2===this.mantleStates&&(this.mantleStates=3)},goNextPage:function(e){var n=this;return(0,a.default)(r.default.mark((function i(){var c;return r.default.wrap((function(i){for(;;)switch(i.prev=i.next){case 0:if(c=function(){t.navigateTo({url:e})},!n.isPerfect){i.next=5;break}c(),i.next=7;break;case 5:return i.next=7,(0,s.enter)(c);case 7:case"end":return i.stop()}}),i)})))()},goToPersonCenter:function(){var t=this;return(0,a.default)(r.default.mark((function e(){return r.default.wrap((function(e){for(;;)switch(e.prev=e.next){case 0:t.goNextPage("/pages/private-info/personalInfo");case 1:case"end":return e.stop()}}),e)})))()},goRegister:function(t){var e=this;return(0,a.default)(r.default.mark((function n(){return r.default.wrap((function(n){for(;;)switch(n.prev=n.next){case 0:e.goNextPage(t);case 1:case"end":return n.stop()}}),n)})))()},goToCertificate:function(){var t=this;return(0,a.default)(r.default.mark((function e(){return r.default.wrap((function(e){for(;;)switch(e.prev=e.next){case 0:t.goNextPage("/pages/private-info/certificate");case 1:case"end":return e.stop()}}),e)})))()},closeUserinfoRepair:function(){this.$store.commit("setIsPerfect",!0),this.$store.commit("setRegister",!1)}}};e.default=d}).call(this,n("543d").default)},dc65:function(t,e,n){var i=n("56c3");n.n(i).a},dde2:function(t,e,n){(function(t,e){var i=n("4ea4");n("bcdf"),i(n("66fd"));var r=i(n("23ed"));t.__webpack_require_UNI_MP_PLUGIN__=n,e(r.default)}).call(this,n("bc2e").default,n("543d").createPage)},ebc9:function(t,e,n){n.d(e,"b",(function(){return i})),n.d(e,"c",(function(){return r})),n.d(e,"a",(function(){}));var i=function(){this.$createElement;var t=(this._self._c,0===this.publicActivities.length&&0===this.personalActivities.length),e=this.personalActivities.length,n=this.publicActivities.length;this.$mp.data=Object.assign({},{$root:{g0:t,g1:e,g2:n}})},r=[]},f19d:function(t,e,n){n.r(e);var i=n("a4e0"),r=n.n(i);for(var c in i)["default"].indexOf(c)<0&&function(t){n.d(e,t,(function(){return i[t]}))}(c);e.default=r.a}},[["dde2","common/runtime","common/vendor"]]]);
},{isPage:true,isComponent:true,currentFile:'pages/activity/index.js'});require("pages/activity/index.js");