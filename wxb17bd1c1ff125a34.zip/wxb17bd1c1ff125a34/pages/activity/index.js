(global.webpackJsonp = global.webpackJsonp || []).push([ [ "pages/activity/index" ], {
    "23ed": function(t, e, n) {
        n.r(e);
        var i = n("ebc9"), r = n("f19d");
        for (var c in r) [ "default" ].indexOf(c) < 0 && function(t) {
            n.d(e, t, function() {
                return r[t];
            });
        }(c);
        n("dc65");
        var a = n("f0c5"), o = Object(a.a)(r.default, i.b, i.c, !1, null, "6d4bfa32", null, !1, i.a, void 0);
        e.default = o.exports;
    },
    "56c3": function(t, e, n) {},
    a4e0: function(t, e, n) {
        (function(t) {
            var i = n("4ea4");
            Object.defineProperty(e, "__esModule", {
                value: !0
            }), e.default = void 0;
            var r = i(n("2eee")), c = i(n("9523")), a = i(n("c973")), o = n("6b44"), s = n("386d"), u = n("185a");
            function f(t, e) {
                var n = Object.keys(t);
                if (Object.getOwnPropertySymbols) {
                    var i = Object.getOwnPropertySymbols(t);
                    e && (i = i.filter(function(e) {
                        return Object.getOwnPropertyDescriptor(t, e).enumerable;
                    })), n.push.apply(n, i);
                }
                return n;
            }
            function l(t) {
                for (var e = 1; e < arguments.length; e++) {
                    var n = null != arguments[e] ? arguments[e] : {};
                    e % 2 ? f(Object(n), !0).forEach(function(e) {
                        (0, c.default)(t, e, n[e]);
                    }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(t, Object.getOwnPropertyDescriptors(n)) : f(Object(n)).forEach(function(e) {
                        Object.defineProperty(t, e, Object.getOwnPropertyDescriptor(n, e));
                    });
                }
                return t;
            }
            var d = {
                name: "Activity",
                components: {
                    ActivityList: function() {
                        Promise.all([ n.e("common/vendor"), n.e("pages/activity/components/ActivityList") ]).then(function() {
                            return resolve(n("65ca"));
                        }.bind(null, n)).catch(n.oe);
                    },
                    CampusActivityList: function() {
                        n.e("pages/activity/components/CampusActivityList").then(function() {
                            return resolve(n("d5a2"));
                        }.bind(null, n)).catch(n.oe);
                    },
                    UserinfoRepair: function() {
                        Promise.all([ n.e("common/vendor"), n.e("utils/common-components/userinfo-repair/index") ]).then(function() {
                            return resolve(n("b1f7"));
                        }.bind(null, n)).catch(n.oe);
                    },
                    Protocol: function() {
                        n.e("pages/activity/components/Protocol").then(function() {
                            return resolve(n("0765"));
                        }.bind(null, n)).catch(n.oe);
                    },
                    uniNavBar: function() {
                        n.e("uni_modules/uni-nav-bar/components/uni-nav-bar/uni-nav-bar").then(function() {
                            return resolve(n("26b0"));
                        }.bind(null, n)).catch(n.oe);
                    }
                },
                onPullDownRefresh: function() {
                    var e = this;
                    return (0, a.default)(r.default.mark(function n() {
                        return r.default.wrap(function(n) {
                            for (;;) switch (n.prev = n.next) {
                              case 0:
                                if (!e.isPerfect) {
                                    n.next = 4;
                                    break;
                                }
                                return n.next = 3, e.getActivityList();

                              case 3:
                                setTimeout(function() {
                                    t.stopPullDownRefresh();
                                }, 1e3);

                              case 4:
                              case "end":
                                return n.stop();
                            }
                        }, n);
                    }))();
                },
                onShow: function() {
                    t.removeStorageSync("oragnizer");
                },
                created: function() {
                    var t = this;
                    return (0, a.default)(r.default.mark(function e() {
                        return r.default.wrap(function(e) {
                            for (;;) switch (e.prev = e.next) {
                              case 0:
                                return e.next = 2, t.getActivityList();

                              case 2:
                              case "end":
                                return e.stop();
                            }
                        }, e);
                    }))();
                },
                data: function() {
                    return {
                        personnalImage: "".concat("https://univs-sishi-1256833609.file.myqcloud.com/resource", "/geren@2x.png"),
                        certificateImage: "".concat("https://univs-sishi-1256833609.file.myqcloud.com/resource", "/zhengshu.png"),
                        zanwuImage: "".concat("https://univs-sishi-1256833609.file.myqcloud.com/resource", "/zanwu@2x.png"),
                        isActivities: !0,
                        isCampus: !0,
                        publicActivities: [],
                        personalActivities: [],
                        mantleStates: 1,
                        defaultImages: [ {
                            id: 1,
                            title_file: "".concat("https://univs-sishi-1256833609.file.myqcloud.com/resource", "/default1.jpg"),
                            title: "中国大学生在线知识问答平台"
                        }, {
                            id: 2,
                            title_file: "".concat("https://univs-sishi-1256833609.file.myqcloud.com/resource", "/default2.jpg"),
                            title: "读书只是竞答"
                        }, {
                            id: 3,
                            title_file: "".concat("https://univs-sishi-1256833609.file.myqcloud.com/resource", "/default3.jpg"),
                            title: "“大学阅读·阅读大学”读书知识问答"
                        }, {
                            id: 4,
                            title_file: "".concat("https://univs-sishi-1256833609.file.myqcloud.com/resource", "/default4.jpg"),
                            title: "大学阅读·阅读大学读书知识问答"
                        } ],
                        needRepairInfo: {
                            name: 1,
                            nick_name: 1,
                            university_id: 1,
                            politics: 1
                        }
                    };
                },
                computed: l(l({}, (0, n("26cb").mapState)([ "register", "isPerfect", "userInfo" ])), {}, {
                    buttonText: function() {
                        return this.isPerfect ? "个人中心" : "立即登录";
                    },
                    isProtocolShow: function() {
                        return 1 === this.mantleStates;
                    },
                    isUserinfoRepairShow: function() {
                        return 2 === this.mantleStates;
                    }
                }),
                methods: {
                    getActivityList: function() {
                        var t = this;
                        return (0, a.default)(r.default.mark(function e() {
                            var n, i;
                            return r.default.wrap(function(e) {
                                for (;;) switch (e.prev = e.next) {
                                  case 0:
                                    return t.publicActivities = [], t.personalActivities = [], e.next = 4, (0, o.getActivities)();

                                  case 4:
                                    n = e.sent, 0 === (i = n.data).code && (i.data.public.forEach(function(e) {
                                        t.publicActivities.push(Object.freeze(new u.PublicActivity(e)));
                                    }), i.data.personal.forEach(function(e) {
                                        t.personalActivities.push(Object.freeze(new u.PublicActivity(e)));
                                    }), 0 === t.publicActivities.length ? t.isActivities = !1 : t.isActivities = !0, 
                                    0 === t.personalActivities.length ? t.isCampus = !1 : t.isCampus = !0);

                                  case 7:
                                  case "end":
                                    return e.stop();
                                }
                            }, e);
                        }))();
                    },
                    changeStates: function() {
                        1 === this.mantleStates ? this.mantleStates = 2 : 2 === this.mantleStates && (this.mantleStates = 3);
                    },
                    goNextPage: function(e) {
                        var n = this;
                        return (0, a.default)(r.default.mark(function i() {
                            var c;
                            return r.default.wrap(function(i) {
                                for (;;) switch (i.prev = i.next) {
                                  case 0:
                                    if (c = function() {
                                        t.navigateTo({
                                            url: e
                                        });
                                    }, !n.isPerfect) {
                                        i.next = 5;
                                        break;
                                    }
                                    c(), i.next = 7;
                                    break;

                                  case 5:
                                    return i.next = 7, (0, s.enter)(c);

                                  case 7:
                                  case "end":
                                    return i.stop();
                                }
                            }, i);
                        }))();
                    },
                    goToPersonCenter: function() {
                        var t = this;
                        return (0, a.default)(r.default.mark(function e() {
                            return r.default.wrap(function(e) {
                                for (;;) switch (e.prev = e.next) {
                                  case 0:
                                    t.goNextPage("/pages/private-info/personalInfo");

                                  case 1:
                                  case "end":
                                    return e.stop();
                                }
                            }, e);
                        }))();
                    },
                    goRegister: function(t) {
                        var e = this;
                        return (0, a.default)(r.default.mark(function n() {
                            return r.default.wrap(function(n) {
                                for (;;) switch (n.prev = n.next) {
                                  case 0:
                                    e.goNextPage(t);

                                  case 1:
                                  case "end":
                                    return n.stop();
                                }
                            }, n);
                        }))();
                    },
                    goToCertificate: function() {
                        var t = this;
                        return (0, a.default)(r.default.mark(function e() {
                            return r.default.wrap(function(e) {
                                for (;;) switch (e.prev = e.next) {
                                  case 0:
                                    t.goNextPage("/pages/private-info/certificate");

                                  case 1:
                                  case "end":
                                    return e.stop();
                                }
                            }, e);
                        }))();
                    },
                    closeUserinfoRepair: function() {
                        this.$store.commit("setIsPerfect", !0), this.$store.commit("setRegister", !1);
                    }
                }
            };
            e.default = d;
        }).call(this, n("543d").default);
    },
    dc65: function(t, e, n) {
        var i = n("56c3");
        n.n(i).a;
    },
    dde2: function(t, e, n) {
        (function(t, e) {
            var i = n("4ea4");
            n("bcdf"), i(n("66fd"));
            var r = i(n("23ed"));
            t.__webpack_require_UNI_MP_PLUGIN__ = n, e(r.default);
        }).call(this, n("bc2e").default, n("543d").createPage);
    },
    ebc9: function(t, e, n) {
        n.d(e, "b", function() {
            return i;
        }), n.d(e, "c", function() {
            return r;
        }), n.d(e, "a", function() {});
        var i = function() {
            this.$createElement;
            var t = (this._self._c, 0 === this.publicActivities.length && 0 === this.personalActivities.length), e = this.personalActivities.length, n = this.publicActivities.length;
            this.$mp.data = Object.assign({}, {
                $root: {
                    g0: t,
                    g1: e,
                    g2: n
                }
            });
        }, r = [];
    },
    f19d: function(t, e, n) {
        n.r(e);
        var i = n("a4e0"), r = n.n(i);
        for (var c in i) [ "default" ].indexOf(c) < 0 && function(t) {
            n.d(e, t, function() {
                return i[t];
            });
        }(c);
        e.default = r.a;
    }
}, [ [ "dde2", "common/runtime", "common/vendor" ] ] ]);