$gwx_XC_0=function(_,_v,_n,_p,_s,_wp,_wl,$gwn,$gwl,$gwh,wh,$gstack,$gwrt,gra,grb,TestTest,wfor,_ca,_da,_r,_rz,_o,_oz,_1,_1z,_2,_2z,_m,_mz,nv_getDate,nv_getRegExp,nv_console,nv_parseInt,nv_parseFloat,nv_isNaN,nv_isFinite,nv_decodeURI,nv_decodeURIComponent,nv_encodeURI,nv_encodeURIComponent,$gdc,nv_JSON,_af,_gv,_ai,_grp,_gd,_gapi,$ixc,_ic,_w,_ev,_tsd){return function(path,global){
if(typeof global==='undefined'){if (typeof __GWX_GLOBAL__==='undefined')global={};else global=__GWX_GLOBAL__;}if(typeof __WXML_GLOBAL__ === 'undefined') {__WXML_GLOBAL__={};
}__WXML_GLOBAL__.modules = __WXML_GLOBAL__.modules || {};
var e_={}
if(typeof(global.entrys)==='undefined')global.entrys={};e_=global.entrys;
var d_={}
if(typeof(global.defines)==='undefined')global.defines={};d_=global.defines;
var f_={}
if(typeof(global.modules)==='undefined')global.modules={};f_=global.modules || {};
var p_={}
__WXML_GLOBAL__.ops_cached = __WXML_GLOBAL__.ops_cached || {}
__WXML_GLOBAL__.ops_set = __WXML_GLOBAL__.ops_set || {};
__WXML_GLOBAL__.ops_init = __WXML_GLOBAL__.ops_init || {};
var z=__WXML_GLOBAL__.ops_set.$gwx_XC_0 || [];
function gz$gwx_XC_0_1(){
if( __WXML_GLOBAL__.ops_cached.$gwx_XC_0_1)return __WXML_GLOBAL__.ops_cached.$gwx_XC_0_1
__WXML_GLOBAL__.ops_cached.$gwx_XC_0_1=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
})(__WXML_GLOBAL__.ops_cached.$gwx_XC_0_1);return __WXML_GLOBAL__.ops_cached.$gwx_XC_0_1
}
__WXML_GLOBAL__.ops_set.$gwx_XC_0=z;
__WXML_GLOBAL__.ops_init.$gwx_XC_0=true;
var x=['./pages/activity/components/ActivityList.wxml'];d_[x[0]]={}
var m0=function(e,s,r,gg){
var z=gz$gwx_XC_0_1()
return r
}
e_[x[0]]={f:m0,j:[],i:[],ti:[],ic:[]}
if(path&&e_[path]){
return function(env,dd,global){$gwxc=0;var root={"tag":"wx-page"};root.children=[]
;g="$gwx_XC_0";var main=e_[path].f
if (typeof global==="undefined")global={};global.f=$gdc(f_[path],"",1);
try{
main(env,{},root,global);
_tsd(root)
}catch(err){
console.log(err)
}
;g="";
return root;
}
}
}
}(__g.a,__g.b,__g.c,__g.d,__g.e,__g.f,__g.g,__g.h,__g.i,__g.j,__g.k,__g.l,__g.m,__g.n,__g.o,__g.p,__g.q,__g.r,__g.s,__g.t,__g.u,__g.v,__g.w,__g.x,__g.y,__g.z,__g.A,__g.B,__g.C,__g.D,__g.E,__g.F,__g.G,__g.H,__g.I,__g.J,__g.K,__g.L,__g.M,__g.N,__g.O,__g.P,__g.Q,__g.R,__g.S,__g.T,__g.U,__g.V,__g.W,__g.X,__g.Y,__g.Z,__g.aa);if(__vd_version_info__.delayedGwx||false)$gwx_XC_0();	if (__vd_version_info__.delayedGwx) __wxAppCode__['pages/activity/components/ActivityList.wxml'] = [$gwx_XC_0, './pages/activity/components/ActivityList.wxml'];else __wxAppCode__['pages/activity/components/ActivityList.wxml'] = $gwx_XC_0( './pages/activity/components/ActivityList.wxml' );
	;__wxRoute = "pages/activity/components/ActivityList";__wxRouteBegin = true;__wxAppCurrentFile__="pages/activity/components/ActivityList.js";define("pages/activity/components/ActivityList.js",function(require,module,exports,window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){
"use strict";(global.webpackJsonp=global.webpackJsonp||[]).push([["pages/activity/components/ActivityList"],{"13f1":function(t,e,n){var r=n("fdc0");n.n(r).a},"1c0a":function(t,e,n){n.d(e,"b",(function(){return r})),n.d(e,"c",(function(){return i})),n.d(e,"a",(function(){}));var r=function(){this.$createElement;this._self._c},i=[]},"65ca":function(t,e,n){n.r(e);var r=n("1c0a"),i=n("9b45");for(var c in i)["default"].indexOf(c)<0&&function(t){n.d(e,t,(function(){return i[t]}))}(c);n("13f1");var o=n("f0c5"),a=Object(o.a)(i.default,r.b,r.c,!1,null,"73c448e9",null,!1,r.a,void 0);e.default=a.exports},"9b45":function(t,e,n){n.r(e);var r=n("c6f7"),i=n.n(r);for(var c in r)["default"].indexOf(c)<0&&function(t){n.d(e,t,(function(){return r[t]}))}(c);e.default=i.a},c6f7:function(t,e,n){(function(t){var r=n("4ea4");Object.defineProperty(e,"__esModule",{value:!0}),e.default=void 0;var i=r(n("9523")),c=r(n("ce99")),o=n("26cb"),a=n("be7c");function s(t,e){var n=Object.keys(t);if(Object.getOwnPropertySymbols){var r=Object.getOwnPropertySymbols(t);e&&(r=r.filter((function(e){return Object.getOwnPropertyDescriptor(t,e).enumerable}))),n.push.apply(n,r)}return n}var u={data:function(){return{infoErrorMsg:"请先点击登录并完善个人信息后参与活动",activityImage:"".concat("https://univs-sishi-1256833609.file.myqcloud.com/resource","/tb2.png"),pageInfo:{paging:!0,items_per_page:10,current_page_num:1},loadMore:"",args:{activityTarget:!1,id:""},clickButtom:"activity"}},props:{isCampus:{type:Boolean,default:!0},publicActivities:{type:Array,default:function(){}}},computed:function(t){for(var e=1;e<arguments.length;e++){var n=null!=arguments[e]?arguments[e]:{};e%2?s(Object(n),!0).forEach((function(e){(0,i.default)(t,e,n[e])})):Object.getOwnPropertyDescriptors?Object.defineProperties(t,Object.getOwnPropertyDescriptors(n)):s(Object(n)).forEach((function(e){Object.defineProperty(t,e,Object.getOwnPropertyDescriptor(n,e))}))}return t}({mobileType:function(){var e=t.getSystemInfoSync();return/iPhone/i.test(e.model)?"IOS":"Android"}},(0,o.mapState)(["isPerfect"])),methods:{enterActivityMode:function(e){var n=this.isPerfect,r=e.category,i=e.id,c=e.referUrl,o=e.organizer_id,s=e.mOverview,u=r===a.ACTIVITY_TYPE.refer?"/pages/questionnaire/exam?src=".concat(c):"/pages/activity/modes?id=".concat(i);t.setStorageSync("oragnizer",o),this.$store.commit("setMOverviewText",s),n?t.navigateTo({url:u}):this.$emit("goRegister",u)},notify:function(){(0,c.default)({type:"warning",message:this.infoErrorMsg,top:82,duration:2500,background:"#FFEAEA",color:"#FF5065"})}}};e.default=u}).call(this,n("543d").default)},fdc0:function(t,e,n){}}]),(global.webpackJsonp=global.webpackJsonp||[]).push(["pages/activity/components/ActivityList-create-component",{"pages/activity/components/ActivityList-create-component":function(t,e,n){n("543d").createComponent(n("65ca"))}},[["pages/activity/components/ActivityList-create-component"]]]);
},{isPage:false,isComponent:true,currentFile:'pages/activity/components/ActivityList.js'});require("pages/activity/components/ActivityList.js");