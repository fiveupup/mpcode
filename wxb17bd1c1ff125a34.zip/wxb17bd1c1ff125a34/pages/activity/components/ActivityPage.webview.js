$gwx_XC_1=function(_,_v,_n,_p,_s,_wp,_wl,$gwn,$gwl,$gwh,wh,$gstack,$gwrt,gra,grb,TestTest,wfor,_ca,_da,_r,_rz,_o,_oz,_1,_1z,_2,_2z,_m,_mz,nv_getDate,nv_getRegExp,nv_console,nv_parseInt,nv_parseFloat,nv_isNaN,nv_isFinite,nv_decodeURI,nv_decodeURIComponent,nv_encodeURI,nv_encodeURIComponent,$gdc,nv_JSON,_af,_gv,_ai,_grp,_gd,_gapi,$ixc,_ic,_w,_ev,_tsd){return function(path,global){
if(typeof global==='undefined'){if (typeof __GWX_GLOBAL__==='undefined')global={};else global=__GWX_GLOBAL__;}if(typeof __WXML_GLOBAL__ === 'undefined') {__WXML_GLOBAL__={};
}__WXML_GLOBAL__.modules = __WXML_GLOBAL__.modules || {};
var e_={}
if(typeof(global.entrys)==='undefined')global.entrys={};e_=global.entrys;
var d_={}
if(typeof(global.defines)==='undefined')global.defines={};d_=global.defines;
var f_={}
if(typeof(global.modules)==='undefined')global.modules={};f_=global.modules || {};
var p_={}
__WXML_GLOBAL__.ops_cached = __WXML_GLOBAL__.ops_cached || {}
__WXML_GLOBAL__.ops_set = __WXML_GLOBAL__.ops_set || {};
__WXML_GLOBAL__.ops_init = __WXML_GLOBAL__.ops_init || {};
var z=__WXML_GLOBAL__.ops_set.$gwx_XC_1 || [];
function gz$gwx_XC_1_1(){
if( __WXML_GLOBAL__.ops_cached.$gwx_XC_1_1)return __WXML_GLOBAL__.ops_cached.$gwx_XC_1_1
__WXML_GLOBAL__.ops_cached.$gwx_XC_1_1=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
Z([[6],[[7],[3,'activity']],[3,'styleType']])
Z([[4],[[5],[[5],[[5],[1,'data-v-a8642cec']],[1,'activity-page']],[[2,'+'],[1,'style'],[[6],[[7],[3,'activity']],[3,'styleType']]]]])
Z([3,'__l'])
Z([3,'data-v-a8642cec'])
Z([1,true])
Z(z[4])
Z([3,'5ad69e56-1'])
Z([3,'activity-page-header data-v-a8642cec'])
Z([3,'activity-page-image data-v-a8642cec'])
Z([3,'_img data-v-a8642cec'])
Z([[6],[[7],[3,'activity']],[3,'bgImage']])
Z([3,'activity-page-title data-v-a8642cec'])
Z([a,[[2,'+'],[[2,'+'],[1,''],[[6],[[7],[3,'activity']],[3,'title']]],[1,'']]])
Z(z[2])
Z(z[3])
Z([3,'5ad69e56-2'])
Z([[4],[[5],[[5],[[5],[1,'activity-page-body']],[1,'data-v-a8642cec']],[[7],[3,'bodyClass']]]])
Z([[6],[[7],[3,'activity']],[3,'sponsor']])
Z([3,'activity-page-footer data-v-a8642cec'])
Z([a,[[2,'+'],[[2,'+'],[1,''],[[6],[[7],[3,'activity']],[3,'sponsor']]],[1,'']]])
})(__WXML_GLOBAL__.ops_cached.$gwx_XC_1_1);return __WXML_GLOBAL__.ops_cached.$gwx_XC_1_1
}
__WXML_GLOBAL__.ops_set.$gwx_XC_1=z;
__WXML_GLOBAL__.ops_init.$gwx_XC_1=true;
var x=['./pages/activity/components/ActivityPage.wxml'];d_[x[0]]={}
var m0=function(e,s,r,gg){
var z=gz$gwx_XC_1_1()
var oV=_v()
_(r,oV)
if(_oz(z,0,e,s,gg)){oV.wxVkey=1
var cW=_n('view')
_rz(z,cW,'class',1,e,s,gg)
var oX=_mz(z,'uni-nav-bar',['bind:__l',2,'class',1,'homePage',2,'statusBar',3,'vueId',4],[],e,s,gg)
_(cW,oX)
var lY=_n('view')
_rz(z,lY,'class',7,e,s,gg)
var aZ=_n('view')
_rz(z,aZ,'class',8,e,s,gg)
var t1=_mz(z,'image',['class',9,'src',1],[],e,s,gg)
_(aZ,t1)
_(lY,aZ)
var e2=_n('view')
_rz(z,e2,'class',11,e,s,gg)
var b3=_oz(z,12,e,s,gg)
_(e2,b3)
_(lY,e2)
var o4=_mz(z,'person-center',['bind:__l',13,'class',1,'vueId',2],[],e,s,gg)
_(lY,o4)
_(cW,lY)
var x5=_n('view')
_rz(z,x5,'class',16,e,s,gg)
var f7=_n('slot')
_(x5,f7)
var o6=_v()
_(x5,o6)
if(_oz(z,17,e,s,gg)){o6.wxVkey=1
var c8=_n('view')
_rz(z,c8,'class',18,e,s,gg)
var h9=_oz(z,19,e,s,gg)
_(c8,h9)
_(o6,c8)
}
o6.wxXCkey=1
_(cW,x5)
_(oV,cW)
}
oV.wxXCkey=1
oV.wxXCkey=3
return r
}
e_[x[0]]={f:m0,j:[],i:[],ti:[],ic:[]}
if(path&&e_[path]){
outerGlobal.__wxml_comp_version__=0.02
return function(env,dd,global){$gwxc=0;var root={"tag":"wx-page"};root.children=[]
;g="$gwx_XC_1";var main=e_[path].f
if (typeof global==="undefined")global={};global.f=$gdc(f_[path],"",1);
if(typeof(outerGlobal.__webview_engine_version__)!='undefined'&&outerGlobal.__webview_engine_version__+1e-6>=0.02+1e-6&&outerGlobal.__mergeData__)
{
env=outerGlobal.__mergeData__(env,dd);
}
try{
main(env,{},root,global);
_tsd(root)
if(typeof(outerGlobal.__webview_engine_version__)=='undefined'|| outerGlobal.__webview_engine_version__+1e-6<0.01+1e-6){return _ev(root);}
}catch(err){
console.log(err)
}
;g="";
return root;
}
}
}
}(__g.a,__g.b,__g.c,__g.d,__g.e,__g.f,__g.g,__g.h,__g.i,__g.j,__g.k,__g.l,__g.m,__g.n,__g.o,__g.p,__g.q,__g.r,__g.s,__g.t,__g.u,__g.v,__g.w,__g.x,__g.y,__g.z,__g.A,__g.B,__g.C,__g.D,__g.E,__g.F,__g.G,__g.H,__g.I,__g.J,__g.K,__g.L,__g.M,__g.N,__g.O,__g.P,__g.Q,__g.R,__g.S,__g.T,__g.U,__g.V,__g.W,__g.X,__g.Y,__g.Z,__g.aa);if(__vd_version_info__.delayedGwx||false)$gwx_XC_1();	if (__vd_version_info__.delayedGwx) __wxAppCode__['pages/activity/components/ActivityPage.wxml'] = [$gwx_XC_1, './pages/activity/components/ActivityPage.wxml'];else __wxAppCode__['pages/activity/components/ActivityPage.wxml'] = $gwx_XC_1( './pages/activity/components/ActivityPage.wxml' );
	
var noCss=typeof __vd_version_info__!=='undefined'&&__vd_version_info__.noCss===true;if(!noCss){__wxAppCode__['pages/activity/components/ActivityPage.wxss'] = setCssToHead([".",[1],"activity-page.",[1],"style1 .",[1],"activity-page-header.",[1],"data-v-a8642cec{position:relative}\n.",[1],"activity-page.",[1],"style1 .",[1],"activity-page-header .",[1],"activity-page-image.",[1],"data-v-a8642cec{height:",[0,640],";width:100%}\n.",[1],"activity-page.",[1],"style1 .",[1],"activity-page-header .",[1],"activity-page-image .",[1],"_img.",[1],"data-v-a8642cec{height:100%;width:100%}\n.",[1],"activity-page.",[1],"style1 .",[1],"activity-page-header .",[1],"activity-page-title.",[1],"data-v-a8642cec{background:linear-gradient(270deg,transparent,rgba(0,0,0,.6));border-radius:0 0 ",[0,4]," 0;bottom:",[0,118],";color:#fff;display:inline-block;font-size:",[0,30],";height:",[0,68],";left:0;line-height:",[0,68],";max-width:",[0,600],";min-width:",[0,200],";overflow:hidden;padding:0 ",[0,24],";position:absolute;text-overflow:ellipsis;white-space:nowrap}\n.",[1],"activity-page.",[1],"style1 .",[1],"activity-page-body.",[1],"data-v-a8642cec{background:#fff;border-radius:0 ",[0,120]," 0 0;left:0;min-height:calc(100vh - ",[0,522],");padding-bottom:",[0,88],";position:absolute;top:",[0,522],";width:100%}\n.",[1],"activity-page.",[1],"style1 .",[1],"activity-page-footer.",[1],"data-v-a8642cec{bottom:0;color:#000;font-size:",[0,28],";font-weight:400;left:0;padding:",[0,24]," 0;position:absolute;text-align:center;width:100%}\n.",[1],"activity-page.",[1],"style2.",[1],"data-v-a8642cec{background:url(https://univs-sishi-1256833609.file.myqcloud.com/resource/style2/bg1@2x.png);background-attachment:fixed;background-size:100% 100%;height:100vh;overflow:auto;position:fixed;width:100vw}\n.",[1],"activity-page.",[1],"style2 .",[1],"activity-page-header.",[1],"data-v-a8642cec{overflow:hidden;position:relative}\n.",[1],"activity-page.",[1],"style2 .",[1],"activity-page-header .",[1],"activity-page-image.",[1],"data-v-a8642cec{background:#fff;border:",[0,4]," solid #1236bd;border-radius:",[0,20],";height:",[0,618],";margin:",[0,134]," auto 0;padding:",[0,36]," ",[0,24]," ",[0,26],";position:relative;width:",[0,702],"}\n.",[1],"activity-page.",[1],"style2 .",[1],"activity-page-header .",[1],"activity-page-image .",[1],"_img.",[1],"data-v-a8642cec{border-radius:",[0,10],";height:100%;width:100%}\n.",[1],"activity-page.",[1],"style2 .",[1],"activity-page-header .",[1],"activity-page-image.",[1],"data-v-a8642cec::before{background-image:url(https://univs-sishi-1256833609.file.myqcloud.com/resource/style2/Dtu@2x.png);background-size:100% 100%;content:\x22\x22;height:",[0,40],";left:",[0,24],";position:absolute;top:",[0,-20],";width:",[0,618],"}\n.",[1],"activity-page.",[1],"style2 .",[1],"activity-page-header .",[1],"activity-page-title.",[1],"data-v-a8642cec{background:linear-gradient(270deg,rgba(0,0,0,.8),transparent);border-radius:0;bottom:",[0,154],";color:#fff;font-size:",[0,30],";font-weight:600;height:",[0,68],";line-height:",[0,68],";overflow:hidden;padding:0 ",[0,36],";position:absolute;right:",[0,51],";text-align:right;text-overflow:ellipsis;white-space:nowrap;width:",[0,654],"}\n.",[1],"activity-page.",[1],"style2 .",[1],"activity-page-body.",[1],"data-v-a8642cec{left:0;min-height:calc(100vh - ",[0,565],");padding-bottom:",[0,88],";position:absolute;top:",[0,565],";width:100%}\n.",[1],"activity-page.",[1],"style2 .",[1],"activity-page-body.",[1],"is-rank.",[1],"data-v-a8642cec,.",[1],"activity-page.",[1],"style2 .",[1],"activity-page-body.",[1],"is-rule.",[1],"data-v-a8642cec{background:#fff;border:",[0,4]," solid #1236bd;border-radius:20px;border-radius:0 0 ",[0,20]," ",[0,20],";border-top:0;left:0;margin:",[0,-154]," ",[0,26]," ",[0,24],";min-height:calc(100vh - ",[0,630],");overflow:hidden;position:relative;top:0;width:calc(100% - ",[0,50],")}\n.",[1],"activity-page.",[1],"style2 .",[1],"activity-page-footer.",[1],"data-v-a8642cec{bottom:0;color:#fff;font-size:",[0,28],";font-weight:400;left:0;padding:",[0,24]," 0;position:absolute;text-align:center;width:100%}\n",],undefined,{path:"./pages/activity/components/ActivityPage.wxss"});
}