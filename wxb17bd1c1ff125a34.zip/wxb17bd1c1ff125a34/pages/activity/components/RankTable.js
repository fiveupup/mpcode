(global.webpackJsonp = global.webpackJsonp || []).push([ [ "pages/activity/components/RankTable" ], {
    "3e52": function(t, n, e) {
        e.r(n);
        var a = e("75f6"), o = e.n(a);
        for (var i in a) [ "default" ].indexOf(i) < 0 && function(t) {
            e.d(n, t, function() {
                return a[t];
            });
        }(i);
        n.default = o.a;
    },
    "450b": function(t, n, e) {
        e.d(n, "b", function() {
            return a;
        }), e.d(n, "c", function() {
            return o;
        }), e.d(n, "a", function() {});
        var a = function() {
            this.$createElement;
            var t = (this._self._c, this.data.length);
            this.$mp.data = Object.assign({}, {
                $root: {
                    g0: t
                }
            });
        }, o = [];
    },
    "5b7c": function(t, n, e) {
        e.r(n);
        var a = e("450b"), o = e("3e52");
        for (var i in o) [ "default" ].indexOf(i) < 0 && function(t) {
            e.d(n, t, function() {
                return o[t];
            });
        }(i);
        e("e2be");
        var c = e("f0c5"), u = Object(c.a)(o.default, a.b, a.c, !1, null, "6d2600ab", null, !1, a.a, void 0);
        n.default = u.exports;
    },
    "75f6": function(t, n, e) {
        (function(t) {
            Object.defineProperty(n, "__esModule", {
                value: !0
            }), n.default = void 0;
            var e = {
                data: function() {
                    return {
                        clientHeight: null,
                        tableMainTop: null
                    };
                },
                props: {
                    columns: {
                        type: Array,
                        default: function() {
                            return [];
                        }
                    },
                    data: {
                        type: Array,
                        default: function() {
                            return [];
                        }
                    }
                },
                onReady: function() {},
                mounted: function() {
                    this.getMainTop(), this.getClientHeight();
                },
                methods: {
                    getMainTop: function() {
                        var n = this;
                        t.createSelectorQuery().in(this).select("#tableMain").boundingClientRect(function(t) {
                            n.tableMainTop = t.top;
                        }).exec();
                    },
                    getClientHeight: function() {
                        var n = this;
                        t.getSystemInfo({
                            success: function(t) {
                                n.clientHeight = t.windowHeight;
                            }
                        });
                    }
                }
            };
            n.default = e;
        }).call(this, e("543d").default);
    },
    7640: function(t, n, e) {},
    e2be: function(t, n, e) {
        var a = e("7640");
        e.n(a).a;
    }
} ]), (global.webpackJsonp = global.webpackJsonp || []).push([ "pages/activity/components/RankTable-create-component", {
    "pages/activity/components/RankTable-create-component": function(t, n, e) {
        e("543d").createComponent(e("5b7c"));
    }
}, [ [ "pages/activity/components/RankTable-create-component" ] ] ]);