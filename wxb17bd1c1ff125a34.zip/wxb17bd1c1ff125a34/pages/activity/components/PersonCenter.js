(global.webpackJsonp = global.webpackJsonp || []).push([ [ "pages/activity/components/PersonCenter" ], {
    "0085": function(e, t, n) {
        n.r(t);
        var r = n("f5a5"), o = n.n(r);
        for (var a in r) [ "default" ].indexOf(a) < 0 && function(e) {
            n.d(t, e, function() {
                return r[e];
            });
        }(a);
        t.default = o.a;
    },
    "1d58": function(e, t, n) {},
    "3aff": function(e, t, n) {
        n.r(t);
        var r = n("ace5"), o = n("0085");
        for (var a in o) [ "default" ].indexOf(a) < 0 && function(e) {
            n.d(t, e, function() {
                return o[e];
            });
        }(a);
        n("5c47");
        var c = n("f0c5"), u = Object(c.a)(o.default, r.b, r.c, !1, null, null, null, !1, r.a, void 0);
        t.default = u.exports;
    },
    "5c47": function(e, t, n) {
        var r = n("1d58");
        n.n(r).a;
    },
    ace5: function(e, t, n) {
        n.d(t, "b", function() {
            return r;
        }), n.d(t, "c", function() {
            return o;
        }), n.d(t, "a", function() {});
        var r = function() {
            this.$createElement;
            this._self._c;
        }, o = [];
    },
    f5a5: function(e, t, n) {
        (function(e) {
            var r = n("4ea4");
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = void 0;
            var o = r(n("2eee")), a = r(n("c973")), c = r(n("9523")), u = n("386d");
            function f(e, t) {
                var n = Object.keys(e);
                if (Object.getOwnPropertySymbols) {
                    var r = Object.getOwnPropertySymbols(e);
                    t && (r = r.filter(function(t) {
                        return Object.getOwnPropertyDescriptor(e, t).enumerable;
                    })), n.push.apply(n, r);
                }
                return n;
            }
            function i(e) {
                for (var t = 1; t < arguments.length; t++) {
                    var n = null != arguments[t] ? arguments[t] : {};
                    t % 2 ? f(Object(n), !0).forEach(function(t) {
                        (0, c.default)(e, t, n[t]);
                    }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(n)) : f(Object(n)).forEach(function(t) {
                        Object.defineProperty(e, t, Object.getOwnPropertyDescriptor(n, t));
                    });
                }
                return e;
            }
            var s = {
                name: "PersonCenter",
                data: function() {
                    return {
                        url: "/pages/private-info/personalInfo"
                    };
                },
                computed: i(i({}, (0, n("26cb").mapState)([ "isPerfect", "userInfo" ])), {}, {
                    buttonText: function() {
                        return this.isPerfect ? "个人中心" : "立即登录";
                    },
                    avatar: function() {
                        return this.userInfo.avatar;
                    }
                }),
                methods: {
                    goToPersonCenter: function() {
                        var t = this;
                        return (0, a.default)(o.default.mark(function n() {
                            var r, a;
                            return o.default.wrap(function(n) {
                                for (;;) switch (n.prev = n.next) {
                                  case 0:
                                    if (r = t.isPerfect, a = t.url, !r) {
                                        n.next = 5;
                                        break;
                                    }
                                    e.navigateTo({
                                        url: a
                                    }), n.next = 7;
                                    break;

                                  case 5:
                                    return n.next = 7, (0, u.enter)();

                                  case 7:
                                  case "end":
                                    return n.stop();
                                }
                            }, n);
                        }))();
                    }
                }
            };
            t.default = s;
        }).call(this, n("543d").default);
    }
} ]), (global.webpackJsonp = global.webpackJsonp || []).push([ "pages/activity/components/PersonCenter-create-component", {
    "pages/activity/components/PersonCenter-create-component": function(e, t, n) {
        n("543d").createComponent(n("3aff"));
    }
}, [ [ "pages/activity/components/PersonCenter-create-component" ] ] ]);