$gwx_XC_5=function(_,_v,_n,_p,_s,_wp,_wl,$gwn,$gwl,$gwh,wh,$gstack,$gwrt,gra,grb,TestTest,wfor,_ca,_da,_r,_rz,_o,_oz,_1,_1z,_2,_2z,_m,_mz,nv_getDate,nv_getRegExp,nv_console,nv_parseInt,nv_parseFloat,nv_isNaN,nv_isFinite,nv_decodeURI,nv_decodeURIComponent,nv_encodeURI,nv_encodeURIComponent,$gdc,nv_JSON,_af,_gv,_ai,_grp,_gd,_gapi,$ixc,_ic,_w,_ev,_tsd){return function(path,global){
if(typeof global==='undefined'){if (typeof __GWX_GLOBAL__==='undefined')global={};else global=__GWX_GLOBAL__;}if(typeof __WXML_GLOBAL__ === 'undefined') {__WXML_GLOBAL__={};
}__WXML_GLOBAL__.modules = __WXML_GLOBAL__.modules || {};
var e_={}
if(typeof(global.entrys)==='undefined')global.entrys={};e_=global.entrys;
var d_={}
if(typeof(global.defines)==='undefined')global.defines={};d_=global.defines;
var f_={}
if(typeof(global.modules)==='undefined')global.modules={};f_=global.modules || {};
var p_={}
__WXML_GLOBAL__.ops_cached = __WXML_GLOBAL__.ops_cached || {}
__WXML_GLOBAL__.ops_set = __WXML_GLOBAL__.ops_set || {};
__WXML_GLOBAL__.ops_init = __WXML_GLOBAL__.ops_init || {};
var z=__WXML_GLOBAL__.ops_set.$gwx_XC_5 || [];
function gz$gwx_XC_5_1(){
if( __WXML_GLOBAL__.ops_cached.$gwx_XC_5_1)return __WXML_GLOBAL__.ops_cached.$gwx_XC_5_1
__WXML_GLOBAL__.ops_cached.$gwx_XC_5_1=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
})(__WXML_GLOBAL__.ops_cached.$gwx_XC_5_1);return __WXML_GLOBAL__.ops_cached.$gwx_XC_5_1
}
__WXML_GLOBAL__.ops_set.$gwx_XC_5=z;
__WXML_GLOBAL__.ops_init.$gwx_XC_5=true;
var x=['./pages/activity/components/PersonCenter.wxml'];d_[x[0]]={}
var m0=function(e,s,r,gg){
var z=gz$gwx_XC_5_1()
return r
}
e_[x[0]]={f:m0,j:[],i:[],ti:[],ic:[]}
if(path&&e_[path]){
return function(env,dd,global){$gwxc=0;var root={"tag":"wx-page"};root.children=[]
;g="$gwx_XC_5";var main=e_[path].f
if (typeof global==="undefined")global={};global.f=$gdc(f_[path],"",1);
try{
main(env,{},root,global);
_tsd(root)
}catch(err){
console.log(err)
}
;g="";
return root;
}
}
}
}(__g.a,__g.b,__g.c,__g.d,__g.e,__g.f,__g.g,__g.h,__g.i,__g.j,__g.k,__g.l,__g.m,__g.n,__g.o,__g.p,__g.q,__g.r,__g.s,__g.t,__g.u,__g.v,__g.w,__g.x,__g.y,__g.z,__g.A,__g.B,__g.C,__g.D,__g.E,__g.F,__g.G,__g.H,__g.I,__g.J,__g.K,__g.L,__g.M,__g.N,__g.O,__g.P,__g.Q,__g.R,__g.S,__g.T,__g.U,__g.V,__g.W,__g.X,__g.Y,__g.Z,__g.aa);if(__vd_version_info__.delayedGwx||false)$gwx_XC_5();	if (__vd_version_info__.delayedGwx) __wxAppCode__['pages/activity/components/PersonCenter.wxml'] = [$gwx_XC_5, './pages/activity/components/PersonCenter.wxml'];else __wxAppCode__['pages/activity/components/PersonCenter.wxml'] = $gwx_XC_5( './pages/activity/components/PersonCenter.wxml' );
	;__wxRoute = "pages/activity/components/PersonCenter";__wxRouteBegin = true;__wxAppCurrentFile__="pages/activity/components/PersonCenter.js";define("pages/activity/components/PersonCenter.js",function(require,module,exports,window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){
"use strict";(global.webpackJsonp=global.webpackJsonp||[]).push([["pages/activity/components/PersonCenter"],{"0085":function(e,t,n){n.r(t);var r=n("f5a5"),o=n.n(r);for(var a in r)["default"].indexOf(a)<0&&function(e){n.d(t,e,(function(){return r[e]}))}(a);t.default=o.a},"1d58":function(e,t,n){},"3aff":function(e,t,n){n.r(t);var r=n("ace5"),o=n("0085");for(var a in o)["default"].indexOf(a)<0&&function(e){n.d(t,e,(function(){return o[e]}))}(a);n("5c47");var c=n("f0c5"),u=Object(c.a)(o.default,r.b,r.c,!1,null,null,null,!1,r.a,void 0);t.default=u.exports},"5c47":function(e,t,n){var r=n("1d58");n.n(r).a},ace5:function(e,t,n){n.d(t,"b",(function(){return r})),n.d(t,"c",(function(){return o})),n.d(t,"a",(function(){}));var r=function(){this.$createElement;this._self._c},o=[]},f5a5:function(e,t,n){(function(e){var r=n("4ea4");Object.defineProperty(t,"__esModule",{value:!0}),t.default=void 0;var o=r(n("2eee")),a=r(n("c973")),c=r(n("9523")),u=n("386d");function f(e,t){var n=Object.keys(e);if(Object.getOwnPropertySymbols){var r=Object.getOwnPropertySymbols(e);t&&(r=r.filter((function(t){return Object.getOwnPropertyDescriptor(e,t).enumerable}))),n.push.apply(n,r)}return n}function i(e){for(var t=1;t<arguments.length;t++){var n=null!=arguments[t]?arguments[t]:{};t%2?f(Object(n),!0).forEach((function(t){(0,c.default)(e,t,n[t])})):Object.getOwnPropertyDescriptors?Object.defineProperties(e,Object.getOwnPropertyDescriptors(n)):f(Object(n)).forEach((function(t){Object.defineProperty(e,t,Object.getOwnPropertyDescriptor(n,t))}))}return e}var s={name:"PersonCenter",data:function(){return{url:"/pages/private-info/personalInfo"}},computed:i(i({},(0,n("26cb").mapState)(["isPerfect","userInfo"])),{},{buttonText:function(){return this.isPerfect?"个人中心":"立即登录"},avatar:function(){return this.userInfo.avatar}}),methods:{goToPersonCenter:function(){var t=this;return(0,a.default)(o.default.mark((function n(){var r,a;return o.default.wrap((function(n){for(;;)switch(n.prev=n.next){case 0:if(r=t.isPerfect,a=t.url,!r){n.next=5;break}e.navigateTo({url:a}),n.next=7;break;case 5:return n.next=7,(0,u.enter)();case 7:case"end":return n.stop()}}),n)})))()}}};t.default=s}).call(this,n("543d").default)}}]),(global.webpackJsonp=global.webpackJsonp||[]).push(["pages/activity/components/PersonCenter-create-component",{"pages/activity/components/PersonCenter-create-component":function(e,t,n){n("543d").createComponent(n("3aff"))}},[["pages/activity/components/PersonCenter-create-component"]]]);
},{isPage:false,isComponent:true,currentFile:'pages/activity/components/PersonCenter.js'});require("pages/activity/components/PersonCenter.js");