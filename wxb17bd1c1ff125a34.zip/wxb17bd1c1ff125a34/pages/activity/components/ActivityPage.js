(global.webpackJsonp = global.webpackJsonp || []).push([ [ "pages/activity/components/ActivityPage" ], {
    "4df6": function(e, t, n) {},
    "6bcb": function(e, t, n) {
        var r = n("4df6");
        n.n(r).a;
    },
    b055: function(e, t, n) {
        n.r(t);
        var r = n("f4fc"), a = n.n(r);
        for (var c in r) [ "default" ].indexOf(c) < 0 && function(e) {
            n.d(t, e, function() {
                return r[e];
            });
        }(c);
        t.default = a.a;
    },
    ba1e: function(e, t, n) {
        n.d(t, "b", function() {
            return r;
        }), n.d(t, "c", function() {
            return a;
        }), n.d(t, "a", function() {});
        var r = function() {
            this.$createElement;
            this._self._c;
        }, a = [];
    },
    ebcf: function(e, t, n) {
        n.r(t);
        var r = n("ba1e"), a = n("b055");
        for (var c in a) [ "default" ].indexOf(c) < 0 && function(e) {
            n.d(t, e, function() {
                return a[e];
            });
        }(c);
        n("6bcb");
        var i = n("f0c5"), o = Object(i.a)(a.default, r.b, r.c, !1, null, "a8642cec", null, !1, r.a, void 0);
        t.default = o.exports;
    },
    f4fc: function(e, t, n) {
        (function(e) {
            var r = n("4ea4");
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = void 0;
            var a = r(n("2eee")), c = r(n("c973")), i = r(n("9523")), o = n("6b44"), u = n("185a"), f = n("26cb"), s = r(n("ce99"));
            function p(e, t) {
                var n = Object.keys(e);
                if (Object.getOwnPropertySymbols) {
                    var r = Object.getOwnPropertySymbols(e);
                    t && (r = r.filter(function(t) {
                        return Object.getOwnPropertyDescriptor(e, t).enumerable;
                    })), n.push.apply(n, r);
                }
                return n;
            }
            function d(e) {
                for (var t = 1; t < arguments.length; t++) {
                    var n = null != arguments[t] ? arguments[t] : {};
                    t % 2 ? p(Object(n), !0).forEach(function(t) {
                        (0, i.default)(e, t, n[t]);
                    }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(n)) : p(Object(n)).forEach(function(t) {
                        Object.defineProperty(e, t, Object.getOwnPropertyDescriptor(n, t));
                    });
                }
                return e;
            }
            var l = {
                name: "ActivityPage",
                components: {
                    UniNavBar: function() {
                        n.e("uni_modules/uni-nav-bar/components/uni-nav-bar/uni-nav-bar").then(function() {
                            return resolve(n("26b0"));
                        }.bind(null, n)).catch(n.oe);
                    },
                    PersonCenter: function() {
                        n.e("pages/activity/components/PersonCenter").then(function() {
                            return resolve(n("3aff"));
                        }.bind(null, n)).catch(n.oe);
                    }
                },
                emits: [ "load" ],
                props: {
                    activityId: {
                        required: !0,
                        type: String
                    },
                    bodyClass: {
                        required: !1,
                        type: String,
                        default: ""
                    },
                    preview: {
                        required: !0,
                        type: Boolean,
                        default: !1
                    }
                },
                computed: d({}, (0, f.mapState)([ "activity" ])),
                created: function() {
                    var e = this;
                    return (0, c.default)(a.default.mark(function t() {
                        return a.default.wrap(function(t) {
                            for (;;) switch (t.prev = t.next) {
                              case 0:
                                return t.next = 2, e.getActivity();

                              case 2:
                              case "end":
                                return t.stop();
                            }
                        }, t);
                    }))();
                },
                methods: {
                    getActivity: function() {
                        var e = this;
                        return (0, c.default)(a.default.mark(function t() {
                            var n, r, c, i, o;
                            return a.default.wrap(function(t) {
                                for (;;) switch (t.prev = t.next) {
                                  case 0:
                                    if (n = e.activityId, r = e.activity, c = e.preview, r && n === r.id && !c && r.preview === c) {
                                        t.next = 9;
                                        break;
                                    }
                                    return t.next = 4, e.getActivityDetail(n, c);

                                  case 4:
                                    if (i = t.sent) {
                                        t.next = 7;
                                        break;
                                    }
                                    return t.abrupt("return");

                                  case 7:
                                    o = new u.Activity(i), e.$store.commit("setActivity", o);

                                  case 9:
                                    e.$emit("load", e.activity);

                                  case 10:
                                  case "end":
                                    return t.stop();
                                }
                            }, t);
                        }))();
                    },
                    getActivityDetail: function(t, n) {
                        return (0, c.default)(a.default.mark(function r() {
                            var c, i;
                            return a.default.wrap(function(r) {
                                for (;;) switch (r.prev = r.next) {
                                  case 0:
                                    return c = {
                                        id: t,
                                        preview: n
                                    }, r.next = 3, (0, o.getActivityDetail)(c);

                                  case 3:
                                    if (0 === (i = r.sent).data.code) {
                                        r.next = 8;
                                        break;
                                    }
                                    return (0, s.default)({
                                        type: "primary",
                                        message: "获取活动失败",
                                        top: 82,
                                        duration: 1500,
                                        background: "#FFEAEA",
                                        color: "#FF5065"
                                    }), e.navigateTo({
                                        url: "/pages/activity/index"
                                    }), r.abrupt("return");

                                  case 8:
                                    return r.abrupt("return", d(d({}, i.data.data), {}, {
                                        preview: n
                                    }));

                                  case 9:
                                  case "end":
                                    return r.stop();
                                }
                            }, r);
                        }))();
                    }
                }
            };
            t.default = l;
        }).call(this, n("543d").default);
    }
} ]), (global.webpackJsonp = global.webpackJsonp || []).push([ "pages/activity/components/ActivityPage-create-component", {
    "pages/activity/components/ActivityPage-create-component": function(e, t, n) {
        n("543d").createComponent(n("ebcf"));
    }
}, [ [ "pages/activity/components/ActivityPage-create-component" ] ] ]);