$gwx_XC_1=function(_,_v,_n,_p,_s,_wp,_wl,$gwn,$gwl,$gwh,wh,$gstack,$gwrt,gra,grb,TestTest,wfor,_ca,_da,_r,_rz,_o,_oz,_1,_1z,_2,_2z,_m,_mz,nv_getDate,nv_getRegExp,nv_console,nv_parseInt,nv_parseFloat,nv_isNaN,nv_isFinite,nv_decodeURI,nv_decodeURIComponent,nv_encodeURI,nv_encodeURIComponent,$gdc,nv_JSON,_af,_gv,_ai,_grp,_gd,_gapi,$ixc,_ic,_w,_ev,_tsd){return function(path,global){
if(typeof global==='undefined'){if (typeof __GWX_GLOBAL__==='undefined')global={};else global=__GWX_GLOBAL__;}if(typeof __WXML_GLOBAL__ === 'undefined') {__WXML_GLOBAL__={};
}__WXML_GLOBAL__.modules = __WXML_GLOBAL__.modules || {};
var e_={}
if(typeof(global.entrys)==='undefined')global.entrys={};e_=global.entrys;
var d_={}
if(typeof(global.defines)==='undefined')global.defines={};d_=global.defines;
var f_={}
if(typeof(global.modules)==='undefined')global.modules={};f_=global.modules || {};
var p_={}
__WXML_GLOBAL__.ops_cached = __WXML_GLOBAL__.ops_cached || {}
__WXML_GLOBAL__.ops_set = __WXML_GLOBAL__.ops_set || {};
__WXML_GLOBAL__.ops_init = __WXML_GLOBAL__.ops_init || {};
var z=__WXML_GLOBAL__.ops_set.$gwx_XC_1 || [];
function gz$gwx_XC_1_1(){
if( __WXML_GLOBAL__.ops_cached.$gwx_XC_1_1)return __WXML_GLOBAL__.ops_cached.$gwx_XC_1_1
__WXML_GLOBAL__.ops_cached.$gwx_XC_1_1=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
Z([[6],[[7],[3,'activity']],[3,'styleType']])
Z([[4],[[5],[[5],[[5],[1,'data-v-a8642cec']],[1,'activity-page']],[[2,'+'],[1,'style'],[[6],[[7],[3,'activity']],[3,'styleType']]]]])
Z([3,'__l'])
Z([3,'data-v-a8642cec'])
Z([1,true])
Z(z[4])
Z([3,'5ad69e56-1'])
Z(z[2])
Z(z[3])
Z([3,'5ad69e56-2'])
Z([[4],[[5],[[5],[[5],[1,'activity-page-body']],[1,'data-v-a8642cec']],[[7],[3,'bodyClass']]]])
Z([[6],[[7],[3,'activity']],[3,'sponsor']])
})(__WXML_GLOBAL__.ops_cached.$gwx_XC_1_1);return __WXML_GLOBAL__.ops_cached.$gwx_XC_1_1
}
__WXML_GLOBAL__.ops_set.$gwx_XC_1=z;
__WXML_GLOBAL__.ops_init.$gwx_XC_1=true;
var x=['./pages/activity/components/ActivityPage.wxml'];d_[x[0]]={}
var m0=function(e,s,r,gg){
var z=gz$gwx_XC_1_1()
var xC=_v()
_(r,xC)
if(_oz(z,0,e,s,gg)){xC.wxVkey=1
var oD=_n('view')
_rz(z,oD,'class',1,e,s,gg)
var fE=_mz(z,'uni-nav-bar',['bind:__l',2,'class',1,'homePage',2,'statusBar',3,'vueId',4],[],e,s,gg)
_(oD,fE)
var cF=_mz(z,'person-center',['bind:__l',7,'class',1,'vueId',2],[],e,s,gg)
_(oD,cF)
var hG=_n('view')
_rz(z,hG,'class',10,e,s,gg)
var cI=_n('slot')
_(hG,cI)
var oH=_v()
_(hG,oH)
if(_oz(z,11,e,s,gg)){oH.wxVkey=1
}
oH.wxXCkey=1
_(oD,hG)
_(xC,oD)
}
xC.wxXCkey=1
xC.wxXCkey=3
return r
}
e_[x[0]]={f:m0,j:[],i:[],ti:[],ic:[]}
if(path&&e_[path]){
return function(env,dd,global){$gwxc=0;var root={"tag":"wx-page"};root.children=[]
;g="$gwx_XC_1";var main=e_[path].f
if (typeof global==="undefined")global={};global.f=$gdc(f_[path],"",1);
try{
main(env,{},root,global);
_tsd(root)
}catch(err){
console.log(err)
}
;g="";
return root;
}
}
}
}(__g.a,__g.b,__g.c,__g.d,__g.e,__g.f,__g.g,__g.h,__g.i,__g.j,__g.k,__g.l,__g.m,__g.n,__g.o,__g.p,__g.q,__g.r,__g.s,__g.t,__g.u,__g.v,__g.w,__g.x,__g.y,__g.z,__g.A,__g.B,__g.C,__g.D,__g.E,__g.F,__g.G,__g.H,__g.I,__g.J,__g.K,__g.L,__g.M,__g.N,__g.O,__g.P,__g.Q,__g.R,__g.S,__g.T,__g.U,__g.V,__g.W,__g.X,__g.Y,__g.Z,__g.aa);if(__vd_version_info__.delayedGwx||false)$gwx_XC_1();	if (__vd_version_info__.delayedGwx) __wxAppCode__['pages/activity/components/ActivityPage.wxml'] = [$gwx_XC_1, './pages/activity/components/ActivityPage.wxml'];else __wxAppCode__['pages/activity/components/ActivityPage.wxml'] = $gwx_XC_1( './pages/activity/components/ActivityPage.wxml' );
	;__wxRoute = "pages/activity/components/ActivityPage";__wxRouteBegin = true;__wxAppCurrentFile__="pages/activity/components/ActivityPage.js";define("pages/activity/components/ActivityPage.js",function(require,module,exports,window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){
"use strict";(global.webpackJsonp=global.webpackJsonp||[]).push([["pages/activity/components/ActivityPage"],{"4df6":function(e,t,n){},"6bcb":function(e,t,n){var r=n("4df6");n.n(r).a},b055:function(e,t,n){n.r(t);var r=n("f4fc"),a=n.n(r);for(var c in r)["default"].indexOf(c)<0&&function(e){n.d(t,e,(function(){return r[e]}))}(c);t.default=a.a},ba1e:function(e,t,n){n.d(t,"b",(function(){return r})),n.d(t,"c",(function(){return a})),n.d(t,"a",(function(){}));var r=function(){this.$createElement;this._self._c},a=[]},ebcf:function(e,t,n){n.r(t);var r=n("ba1e"),a=n("b055");for(var c in a)["default"].indexOf(c)<0&&function(e){n.d(t,e,(function(){return a[e]}))}(c);n("6bcb");var i=n("f0c5"),o=Object(i.a)(a.default,r.b,r.c,!1,null,"a8642cec",null,!1,r.a,void 0);t.default=o.exports},f4fc:function(e,t,n){(function(e){var r=n("4ea4");Object.defineProperty(t,"__esModule",{value:!0}),t.default=void 0;var a=r(n("2eee")),c=r(n("c973")),i=r(n("9523")),o=n("6b44"),u=n("185a"),f=n("26cb"),s=r(n("ce99"));function p(e,t){var n=Object.keys(e);if(Object.getOwnPropertySymbols){var r=Object.getOwnPropertySymbols(e);t&&(r=r.filter((function(t){return Object.getOwnPropertyDescriptor(e,t).enumerable}))),n.push.apply(n,r)}return n}function d(e){for(var t=1;t<arguments.length;t++){var n=null!=arguments[t]?arguments[t]:{};t%2?p(Object(n),!0).forEach((function(t){(0,i.default)(e,t,n[t])})):Object.getOwnPropertyDescriptors?Object.defineProperties(e,Object.getOwnPropertyDescriptors(n)):p(Object(n)).forEach((function(t){Object.defineProperty(e,t,Object.getOwnPropertyDescriptor(n,t))}))}return e}var l={name:"ActivityPage",components:{UniNavBar:function(){n.e("uni_modules/uni-nav-bar/components/uni-nav-bar/uni-nav-bar").then(function(){return resolve(n("26b0"))}.bind(null,n)).catch(n.oe)},PersonCenter:function(){n.e("pages/activity/components/PersonCenter").then(function(){return resolve(n("3aff"))}.bind(null,n)).catch(n.oe)}},emits:["load"],props:{activityId:{required:!0,type:String},bodyClass:{required:!1,type:String,default:""},preview:{required:!0,type:Boolean,default:!1}},computed:d({},(0,f.mapState)(["activity"])),created:function(){var e=this;return(0,c.default)(a.default.mark((function t(){return a.default.wrap((function(t){for(;;)switch(t.prev=t.next){case 0:return t.next=2,e.getActivity();case 2:case"end":return t.stop()}}),t)})))()},methods:{getActivity:function(){var e=this;return(0,c.default)(a.default.mark((function t(){var n,r,c,i,o;return a.default.wrap((function(t){for(;;)switch(t.prev=t.next){case 0:if(n=e.activityId,r=e.activity,c=e.preview,r&&n===r.id&&!c&&r.preview===c){t.next=9;break}return t.next=4,e.getActivityDetail(n,c);case 4:if(i=t.sent){t.next=7;break}return t.abrupt("return");case 7:o=new u.Activity(i),e.$store.commit("setActivity",o);case 9:e.$emit("load",e.activity);case 10:case"end":return t.stop()}}),t)})))()},getActivityDetail:function(t,n){return(0,c.default)(a.default.mark((function r(){var c,i;return a.default.wrap((function(r){for(;;)switch(r.prev=r.next){case 0:return c={id:t,preview:n},r.next=3,(0,o.getActivityDetail)(c);case 3:if(0===(i=r.sent).data.code){r.next=8;break}return(0,s.default)({type:"primary",message:"获取活动失败",top:82,duration:1500,background:"#FFEAEA",color:"#FF5065"}),e.navigateTo({url:"/pages/activity/index"}),r.abrupt("return");case 8:return r.abrupt("return",d(d({},i.data.data),{},{preview:n}));case 9:case"end":return r.stop()}}),r)})))()}}};t.default=l}).call(this,n("543d").default)}}]),(global.webpackJsonp=global.webpackJsonp||[]).push(["pages/activity/components/ActivityPage-create-component",{"pages/activity/components/ActivityPage-create-component":function(e,t,n){n("543d").createComponent(n("ebcf"))}},[["pages/activity/components/ActivityPage-create-component"]]]);
},{isPage:false,isComponent:true,currentFile:'pages/activity/components/ActivityPage.js'});require("pages/activity/components/ActivityPage.js");