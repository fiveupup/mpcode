require("../../@babel/runtime/helpers/Arrayincludes"), (global.webpackJsonp = global.webpackJsonp || []).push([ [ "pages/activity/modes" ], {
    "0d70": function(e, t, n) {},
    1345: function(e, t, n) {
        (function(e) {
            var r = n("4ea4");
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = void 0;
            var a = r(n("2eee")), i = r(n("448a")), o = r(n("c973")), c = r(n("9523")), u = n("6b44"), s = n("26cb"), f = n("be7c"), d = n("185a"), l = r(n("ce99")), p = n("386d");
            function v(e, t) {
                var n = Object.keys(e);
                if (Object.getOwnPropertySymbols) {
                    var r = Object.getOwnPropertySymbols(e);
                    t && (r = r.filter(function(t) {
                        return Object.getOwnPropertyDescriptor(e, t).enumerable;
                    })), n.push.apply(n, r);
                }
                return n;
            }
            function m(e) {
                for (var t = 1; t < arguments.length; t++) {
                    var n = null != arguments[t] ? arguments[t] : {};
                    t % 2 ? v(Object(n), !0).forEach(function(t) {
                        (0, c.default)(e, t, n[t]);
                    }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(n)) : v(Object(n)).forEach(function(t) {
                        Object.defineProperty(e, t, Object.getOwnPropertyDescriptor(n, t));
                    });
                }
                return e;
            }
            var h = {
                name: "ActivityMode",
                components: {
                    ActivityPage: function() {
                        Promise.all([ n.e("common/vendor"), n.e("pages/activity/components/ActivityPage") ]).then(function() {
                            return resolve(n("ebcf"));
                        }.bind(null, n)).catch(n.oe);
                    },
                    ModeList: function() {
                        n.e("pages/activity/components/ModeList").then(function() {
                            return resolve(n("bc7b"));
                        }.bind(null, n)).catch(n.oe);
                    },
                    Protocol: function() {
                        n.e("pages/activity/components/Protocol").then(function() {
                            return resolve(n("0765"));
                        }.bind(null, n)).catch(n.oe);
                    },
                    GeneralView: function() {
                        n.e("pages/activity/components/GeneralView").then(function() {
                            return resolve(n("fe79"));
                        }.bind(null, n)).catch(n.oe);
                    },
                    UserinfoRepair: function() {
                        Promise.all([ n.e("common/vendor"), n.e("utils/common-components/userinfo-repair/index") ]).then(function() {
                            return resolve(n("b1f7"));
                        }.bind(null, n)).catch(n.oe);
                    }
                },
                data: function() {
                    var e;
                    return e = {
                        activityId: "",
                        activity: {},
                        modes: [],
                        userInfo: {},
                        mantleStates: 1
                    }, (0, c.default)(e, "userInfo", {}), (0, c.default)(e, "isShowPartLoginInfo", !1), 
                    (0, c.default)(e, "isShowWritePart", !1), (0, c.default)(e, "needRepairInfo", {}), 
                    (0, c.default)(e, "submitToExamInfo", null), (0, c.default)(e, "eaxmUrl", ""), (0, 
                    c.default)(e, "isTest", !1), e;
                },
                provide: function() {
                    var e = this;
                    return {
                        isShowPartLoginInfoPro: function() {
                            return e.isShowPartLoginInfo;
                        },
                        activityParent: function() {
                            return e;
                        }
                    };
                },
                computed: m(m({}, (0, s.mapState)([ "showGeneral", "register", "mOverviewText" ])), {}, {
                    isProtocolShow: function() {
                        return 1 === this.mantleStates;
                    },
                    isUserinfoRepairShow: function() {
                        return 2 === this.mantleStates;
                    }
                }),
                onLoad: function(e) {
                    var t = this;
                    return (0, o.default)(a.default.mark(function n() {
                        return a.default.wrap(function(n) {
                            for (;;) switch (n.prev = n.next) {
                              case 0:
                                t.isTest = !!e.preview && JSON.parse(e.preview), t.activityId = e.id, t.$store.commit("setShowGeneral", !0);

                              case 3:
                              case "end":
                                return n.stop();
                            }
                        }, n);
                    }))();
                },
                onShow: function() {
                    var e = this;
                    return (0, o.default)(a.default.mark(function t() {
                        var n;
                        return a.default.wrap(function(t) {
                            for (;;) switch (t.prev = t.next) {
                              case 0:
                                e.activity && e.activity.id && (n = e.activity, e.getActivityModes(n));

                              case 1:
                              case "end":
                                return t.stop();
                            }
                        }, t);
                    }))();
                },
                methods: {
                    handleActivityPageLoad: function(e) {
                        this.activity = e, this.getActivityModes(e);
                    },
                    getActivityModes: function(e) {
                        var t = this;
                        return (0, o.default)(a.default.mark(function n() {
                            var r, o, c, s, p, v, m, h, b, y, w, g, P, I, O, x;
                            return a.default.wrap(function(n) {
                                for (;;) switch (n.prev = n.next) {
                                  case 0:
                                    if (e.id) {
                                        n.next = 2;
                                        break;
                                    }
                                    return n.abrupt("return");

                                  case 2:
                                    return t.modes = [], r = {
                                        activity_id: e.id,
                                        preview: t.isTest
                                    }, n.next = 6, (0, u.getActivityModes)(r);

                                  case 6:
                                    if (0 === (o = n.sent).data.code) {
                                        n.next = 10;
                                        break;
                                    }
                                    return (0, l.default)({
                                        type: "primary",
                                        message: "获取模式失败",
                                        top: 82,
                                        duration: 1500,
                                        background: "#FFEAEA",
                                        color: "#FF5065"
                                    }), n.abrupt("return");

                                  case 10:
                                    c = o.data.data, s = e.category, p = c.need_field, v = c.field_conf, m = c.modes, 
                                    h = c.times, b = c.finished, y = c.is_team, w = c.is_passed, p && (t.needRepairInfo = {}, 
                                    Object.keys(v).forEach(function(e) {
                                        t.needRepairInfo[e] = v[e];
                                    })), g = [ f.ACTIVITY_TYPE.teamPk, f.ACTIVITY_TYPE.personalPk ].includes(s), P = t.isTest, 
                                    g ? (x = m.map(function(t) {
                                        var n = t.id, r = t.mode, a = t.title, i = t.status;
                                        return new d.Mode({
                                            activity: e,
                                            id: n,
                                            title: a,
                                            category: s,
                                            mode: r,
                                            needField: p,
                                            fieldConf: v,
                                            finished: b,
                                            status: i,
                                            isTeam: y,
                                            isTest: P
                                        });
                                    }), (O = t.modes).push.apply(O, (0, i.default)(x))) : (I = new d.Mode({
                                        activity: e,
                                        title: e.title,
                                        category: s,
                                        needField: p,
                                        fieldConf: v,
                                        finished: b,
                                        times: h,
                                        isPassed: w,
                                        isTest: P
                                    }), t.modes.push(I));

                                  case 17:
                                  case "end":
                                    return n.stop();
                                }
                            }, n);
                        }))();
                    },
                    openInfoRepair: function(e) {
                        var t = this;
                        return (0, o.default)(a.default.mark(function n() {
                            var r, i;
                            return a.default.wrap(function(n) {
                                for (;;) switch (n.prev = n.next) {
                                  case 0:
                                    return n.next = 2, t.getPersonalInfo();

                                  case 2:
                                    n.t0 = a.default.keys(t.needRepairInfo);

                                  case 3:
                                    if ((n.t1 = n.t0()).done) {
                                        n.next = 11;
                                        break;
                                    }
                                    if (r = n.t1.value, i = t.userInfo[r], ![ "category", "politics" ].includes(r) || ![ 99, 100 ].includes(i)) {
                                        n.next = 8;
                                        break;
                                    }
                                    return n.abrupt("continue", 3);

                                  case 8:
                                    i && delete t.needRepairInfo[r], n.next = 3;
                                    break;

                                  case 11:
                                    t.submitToExamInfo = e, t.isShowWritePart = !0;

                                  case 13:
                                  case "end":
                                    return n.stop();
                                }
                            }, n);
                        }))();
                    },
                    closePersonalRepair: function() {
                        var t = this;
                        return (0, o.default)(a.default.mark(function n() {
                            var r, i;
                            return a.default.wrap(function(n) {
                                for (;;) switch (n.prev = n.next) {
                                  case 0:
                                    t.isShowWritePart = !1, r = t.submitToExamInfo, i = r.targetUrl, e.navigateTo({
                                        url: i
                                    });

                                  case 4:
                                  case "end":
                                    return n.stop();
                                }
                            }, n);
                        }))();
                    },
                    getPersonalInfo: function() {
                        var e = this;
                        return (0, o.default)(a.default.mark(function t() {
                            return a.default.wrap(function(t) {
                                for (;;) switch (t.prev = t.next) {
                                  case 0:
                                    return t.next = 2, (0, p.getAndSetUserInfo)();

                                  case 2:
                                    e.userInfo = t.sent;

                                  case 3:
                                  case "end":
                                    return t.stop();
                                }
                            }, t);
                        }))();
                    },
                    changeStates: function() {
                        1 === this.mantleStates ? this.mantleStates = 2 : 2 === this.mantleStates && (this.mantleStates = 3);
                    }
                }
            };
            t.default = h;
        }).call(this, n("543d").default);
    },
    "167e": function(e, t, n) {
        (function(e, t) {
            var r = n("4ea4");
            n("bcdf"), r(n("66fd"));
            var a = r(n("864c"));
            e.__webpack_require_UNI_MP_PLUGIN__ = n, t(a.default);
        }).call(this, n("bc2e").default, n("543d").createPage);
    },
    "28b3": function(e, t, n) {
        n.d(t, "b", function() {
            return r;
        }), n.d(t, "c", function() {
            return a;
        }), n.d(t, "a", function() {});
        var r = function() {
            this.$createElement;
            this._self._c;
        }, a = [];
    },
    "53ff": function(e, t, n) {
        n.r(t);
        var r = n("1345"), a = n.n(r);
        for (var i in r) [ "default" ].indexOf(i) < 0 && function(e) {
            n.d(t, e, function() {
                return r[e];
            });
        }(i);
        t.default = a.a;
    },
    7859: function(e, t, n) {
        var r = n("0d70");
        n.n(r).a;
    },
    "864c": function(e, t, n) {
        n.r(t);
        var r = n("28b3"), a = n("53ff");
        for (var i in a) [ "default" ].indexOf(i) < 0 && function(e) {
            n.d(t, e, function() {
                return a[e];
            });
        }(i);
        n("7859");
        var o = n("f0c5"), c = Object(o.a)(a.default, r.b, r.c, !1, null, "6e2cbbee", null, !1, r.a, void 0);
        t.default = c.exports;
    }
}, [ [ "167e", "common/runtime", "common/vendor" ] ] ]);