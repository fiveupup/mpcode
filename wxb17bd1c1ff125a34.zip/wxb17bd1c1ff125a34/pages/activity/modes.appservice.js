$gwx_XC_9=function(_,_v,_n,_p,_s,_wp,_wl,$gwn,$gwl,$gwh,wh,$gstack,$gwrt,gra,grb,TestTest,wfor,_ca,_da,_r,_rz,_o,_oz,_1,_1z,_2,_2z,_m,_mz,nv_getDate,nv_getRegExp,nv_console,nv_parseInt,nv_parseFloat,nv_isNaN,nv_isFinite,nv_decodeURI,nv_decodeURIComponent,nv_encodeURI,nv_encodeURIComponent,$gdc,nv_JSON,_af,_gv,_ai,_grp,_gd,_gapi,$ixc,_ic,_w,_ev,_tsd){return function(path,global){
if(typeof global==='undefined'){if (typeof __GWX_GLOBAL__==='undefined')global={};else global=__GWX_GLOBAL__;}if(typeof __WXML_GLOBAL__ === 'undefined') {__WXML_GLOBAL__={};
}__WXML_GLOBAL__.modules = __WXML_GLOBAL__.modules || {};
var e_={}
if(typeof(global.entrys)==='undefined')global.entrys={};e_=global.entrys;
var d_={}
if(typeof(global.defines)==='undefined')global.defines={};d_=global.defines;
var f_={}
if(typeof(global.modules)==='undefined')global.modules={};f_=global.modules || {};
var p_={}
__WXML_GLOBAL__.ops_cached = __WXML_GLOBAL__.ops_cached || {}
__WXML_GLOBAL__.ops_set = __WXML_GLOBAL__.ops_set || {};
__WXML_GLOBAL__.ops_init = __WXML_GLOBAL__.ops_init || {};
var z=__WXML_GLOBAL__.ops_set.$gwx_XC_9 || [];
function gz$gwx_XC_9_1(){
if( __WXML_GLOBAL__.ops_cached.$gwx_XC_9_1)return __WXML_GLOBAL__.ops_cached.$gwx_XC_9_1
__WXML_GLOBAL__.ops_cached.$gwx_XC_9_1=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
Z([[7],[3,'activityId']])
Z(z[0])
Z([3,'__l'])
Z([3,'__e'])
Z([3,'data-v-6e2cbbee'])
Z([[4],[[5],[[4],[[5],[[5],[1,'^load']],[[4],[[5],[[4],[[5],[1,'handleActivityPageLoad']]]]]]]]])
Z([[7],[3,'isTest']])
Z([3,'65dbc93d-1'])
Z([[4],[[5],[1,'default']]])
Z(z[2])
Z(z[4])
Z([3,'wx'])
Z([3,'van-notify'])
Z([[2,'+'],[[2,'+'],[1,'65dbc93d-2'],[1,',']],[1,'65dbc93d-1']])
Z([[7],[3,'showGeneral']])
Z(z[2])
Z(z[4])
Z([[6],[[7],[3,'activity']],[3,'overview']])
Z([[2,'+'],[[2,'+'],[1,'65dbc93d-3'],[1,',']],[1,'65dbc93d-1']])
Z([[7],[3,'activity']])
Z(z[2])
Z(z[4])
Z([[7],[3,'modes']])
Z([[2,'+'],[[2,'+'],[1,'65dbc93d-4'],[1,',']],[1,'65dbc93d-1']])
Z([[7],[3,'register']])
Z([3,'borad data-v-6e2cbbee'])
Z([[7],[3,'isProtocolShow']])
Z(z[2])
Z(z[3])
Z(z[4])
Z([[4],[[5],[[4],[[5],[[5],[1,'^changeStates']],[[4],[[5],[[4],[[5],[1,'changeStates']]]]]]]]])
Z([[2,'+'],[[2,'+'],[1,'65dbc93d-5'],[1,',']],[1,'65dbc93d-1']])
Z([[7],[3,'isUserinfoRepairShow']])
Z(z[2])
Z(z[4])
Z([[7],[3,'userInfo']])
Z([[2,'+'],[[2,'+'],[1,'65dbc93d-6'],[1,',']],[1,'65dbc93d-1']])
Z([[7],[3,'isShowWritePart']])
Z(z[2])
Z(z[3])
Z(z[4])
Z([[4],[[5],[[4],[[5],[[5],[1,'^close']],[[4],[[5],[[4],[[5],[1,'closePersonalRepair']]]]]]]]])
Z([[7],[3,'needRepairInfo']])
Z(z[35])
Z([[2,'+'],[[2,'+'],[1,'65dbc93d-7'],[1,',']],[1,'65dbc93d-1']])
})(__WXML_GLOBAL__.ops_cached.$gwx_XC_9_1);return __WXML_GLOBAL__.ops_cached.$gwx_XC_9_1
}
__WXML_GLOBAL__.ops_set.$gwx_XC_9=z;
__WXML_GLOBAL__.ops_init.$gwx_XC_9=true;
var x=['./pages/activity/modes.wxml'];d_[x[0]]={}
var m0=function(e,s,r,gg){
var z=gz$gwx_XC_9_1()
var fCC=_v()
_(r,fCC)
if(_oz(z,0,e,s,gg)){fCC.wxVkey=1
var cDC=_mz(z,'activity-page',['activityId',1,'bind:__l',1,'bind:load',2,'class',3,'data-event-opts',4,'preview',5,'vueId',6,'vueSlots',7],[],e,s,gg)
var oHC=_mz(z,'van-notify',['bind:__l',9,'class',1,'data-com-type',2,'id',3,'vueId',4],[],e,s,gg)
_(cDC,oHC)
var hEC=_v()
_(cDC,hEC)
if(_oz(z,14,e,s,gg)){hEC.wxVkey=1
var lIC=_mz(z,'general-view',['bind:__l',15,'class',1,'data',2,'vueId',3],[],e,s,gg)
_(hEC,lIC)
}
var aJC=_mz(z,'mode-list',['activity',19,'bind:__l',1,'class',2,'modes',3,'vueId',4],[],e,s,gg)
_(cDC,aJC)
var oFC=_v()
_(cDC,oFC)
if(_oz(z,24,e,s,gg)){oFC.wxVkey=1
var tKC=_n('view')
_rz(z,tKC,'class',25,e,s,gg)
var eLC=_v()
_(tKC,eLC)
if(_oz(z,26,e,s,gg)){eLC.wxVkey=1
var bMC=_mz(z,'protocol',['bind:__l',27,'bind:changeStates',1,'class',2,'data-event-opts',3,'vueId',4],[],e,s,gg)
_(eLC,bMC)
}
else{eLC.wxVkey=2
var oNC=_v()
_(eLC,oNC)
if(_oz(z,32,e,s,gg)){oNC.wxVkey=1
var xOC=_mz(z,'userinfo-repair',['bind:__l',33,'class',1,'userInfo',2,'vueId',3],[],e,s,gg)
_(oNC,xOC)
}
oNC.wxXCkey=1
oNC.wxXCkey=3
}
eLC.wxXCkey=1
eLC.wxXCkey=3
eLC.wxXCkey=3
_(oFC,tKC)
}
var cGC=_v()
_(cDC,cGC)
if(_oz(z,37,e,s,gg)){cGC.wxVkey=1
var oPC=_mz(z,'userinfo-repair',['bind:__l',38,'bind:close',1,'class',2,'data-event-opts',3,'needRepairInfo',4,'userInfo',5,'vueId',6],[],e,s,gg)
_(cGC,oPC)
}
hEC.wxXCkey=1
hEC.wxXCkey=3
oFC.wxXCkey=1
oFC.wxXCkey=3
cGC.wxXCkey=1
cGC.wxXCkey=3
_(fCC,cDC)
}
fCC.wxXCkey=1
fCC.wxXCkey=3
return r
}
e_[x[0]]={f:m0,j:[],i:[],ti:[],ic:[]}
if(path&&e_[path]){
return function(env,dd,global){$gwxc=0;var root={"tag":"wx-page"};root.children=[]
;g="$gwx_XC_9";var main=e_[path].f
if (typeof global==="undefined")global={};global.f=$gdc(f_[path],"",1);
try{
main(env,{},root,global);
_tsd(root)
}catch(err){
console.log(err)
}
;g="";
return root;
}
}
}
}(__g.a,__g.b,__g.c,__g.d,__g.e,__g.f,__g.g,__g.h,__g.i,__g.j,__g.k,__g.l,__g.m,__g.n,__g.o,__g.p,__g.q,__g.r,__g.s,__g.t,__g.u,__g.v,__g.w,__g.x,__g.y,__g.z,__g.A,__g.B,__g.C,__g.D,__g.E,__g.F,__g.G,__g.H,__g.I,__g.J,__g.K,__g.L,__g.M,__g.N,__g.O,__g.P,__g.Q,__g.R,__g.S,__g.T,__g.U,__g.V,__g.W,__g.X,__g.Y,__g.Z,__g.aa);if(__vd_version_info__.delayedGwx||false)$gwx_XC_9();	if (__vd_version_info__.delayedGwx) __wxAppCode__['pages/activity/modes.wxml'] = [$gwx_XC_9, './pages/activity/modes.wxml'];else __wxAppCode__['pages/activity/modes.wxml'] = $gwx_XC_9( './pages/activity/modes.wxml' );
	;__wxRoute = "pages/activity/modes";__wxRouteBegin = true;__wxAppCurrentFile__="pages/activity/modes.js";define("pages/activity/modes.js",function(require,module,exports,window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){
"use strict";require("../../@babel/runtime/helpers/Arrayincludes"),(global.webpackJsonp=global.webpackJsonp||[]).push([["pages/activity/modes"],{"0d70":function(e,t,n){},1345:function(e,t,n){(function(e){var r=n("4ea4");Object.defineProperty(t,"__esModule",{value:!0}),t.default=void 0;var a=r(n("2eee")),i=r(n("448a")),o=r(n("c973")),c=r(n("9523")),u=n("6b44"),s=n("26cb"),f=n("be7c"),d=n("185a"),l=r(n("ce99")),p=n("386d");function v(e,t){var n=Object.keys(e);if(Object.getOwnPropertySymbols){var r=Object.getOwnPropertySymbols(e);t&&(r=r.filter((function(t){return Object.getOwnPropertyDescriptor(e,t).enumerable}))),n.push.apply(n,r)}return n}function m(e){for(var t=1;t<arguments.length;t++){var n=null!=arguments[t]?arguments[t]:{};t%2?v(Object(n),!0).forEach((function(t){(0,c.default)(e,t,n[t])})):Object.getOwnPropertyDescriptors?Object.defineProperties(e,Object.getOwnPropertyDescriptors(n)):v(Object(n)).forEach((function(t){Object.defineProperty(e,t,Object.getOwnPropertyDescriptor(n,t))}))}return e}var h={name:"ActivityMode",components:{ActivityPage:function(){Promise.all([n.e("common/vendor"),n.e("pages/activity/components/ActivityPage")]).then(function(){return resolve(n("ebcf"))}.bind(null,n)).catch(n.oe)},ModeList:function(){n.e("pages/activity/components/ModeList").then(function(){return resolve(n("bc7b"))}.bind(null,n)).catch(n.oe)},Protocol:function(){n.e("pages/activity/components/Protocol").then(function(){return resolve(n("0765"))}.bind(null,n)).catch(n.oe)},GeneralView:function(){n.e("pages/activity/components/GeneralView").then(function(){return resolve(n("fe79"))}.bind(null,n)).catch(n.oe)},UserinfoRepair:function(){Promise.all([n.e("common/vendor"),n.e("utils/common-components/userinfo-repair/index")]).then(function(){return resolve(n("b1f7"))}.bind(null,n)).catch(n.oe)}},data:function(){var e;return e={activityId:"",activity:{},modes:[],userInfo:{},mantleStates:1},(0,c.default)(e,"userInfo",{}),(0,c.default)(e,"isShowPartLoginInfo",!1),(0,c.default)(e,"isShowWritePart",!1),(0,c.default)(e,"needRepairInfo",{}),(0,c.default)(e,"submitToExamInfo",null),(0,c.default)(e,"eaxmUrl",""),(0,c.default)(e,"isTest",!1),e},provide:function(){var e=this;return{isShowPartLoginInfoPro:function(){return e.isShowPartLoginInfo},activityParent:function(){return e}}},computed:m(m({},(0,s.mapState)(["showGeneral","register","mOverviewText"])),{},{isProtocolShow:function(){return 1===this.mantleStates},isUserinfoRepairShow:function(){return 2===this.mantleStates}}),onLoad:function(e){var t=this;return(0,o.default)(a.default.mark((function n(){return a.default.wrap((function(n){for(;;)switch(n.prev=n.next){case 0:t.isTest=!!e.preview&&JSON.parse(e.preview),t.activityId=e.id,t.$store.commit("setShowGeneral",!0);case 3:case"end":return n.stop()}}),n)})))()},onShow:function(){var e=this;return(0,o.default)(a.default.mark((function t(){var n;return a.default.wrap((function(t){for(;;)switch(t.prev=t.next){case 0:e.activity&&e.activity.id&&(n=e.activity,e.getActivityModes(n));case 1:case"end":return t.stop()}}),t)})))()},methods:{handleActivityPageLoad:function(e){this.activity=e,this.getActivityModes(e)},getActivityModes:function(e){var t=this;return(0,o.default)(a.default.mark((function n(){var r,o,c,s,p,v,m,h,b,y,w,g,P,I,O,x;return a.default.wrap((function(n){for(;;)switch(n.prev=n.next){case 0:if(e.id){n.next=2;break}return n.abrupt("return");case 2:return t.modes=[],r={activity_id:e.id,preview:t.isTest},n.next=6,(0,u.getActivityModes)(r);case 6:if(0===(o=n.sent).data.code){n.next=10;break}return(0,l.default)({type:"primary",message:"获取模式失败",top:82,duration:1500,background:"#FFEAEA",color:"#FF5065"}),n.abrupt("return");case 10:c=o.data.data,s=e.category,p=c.need_field,v=c.field_conf,m=c.modes,h=c.times,b=c.finished,y=c.is_team,w=c.is_passed,p&&(t.needRepairInfo={},Object.keys(v).forEach((function(e){t.needRepairInfo[e]=v[e]}))),g=[f.ACTIVITY_TYPE.teamPk,f.ACTIVITY_TYPE.personalPk].includes(s),P=t.isTest,g?(x=m.map((function(t){var n=t.id,r=t.mode,a=t.title,i=t.status;return new d.Mode({activity:e,id:n,title:a,category:s,mode:r,needField:p,fieldConf:v,finished:b,status:i,isTeam:y,isTest:P})})),(O=t.modes).push.apply(O,(0,i.default)(x))):(I=new d.Mode({activity:e,title:e.title,category:s,needField:p,fieldConf:v,finished:b,times:h,isPassed:w,isTest:P}),t.modes.push(I));case 17:case"end":return n.stop()}}),n)})))()},openInfoRepair:function(e){var t=this;return(0,o.default)(a.default.mark((function n(){var r,i;return a.default.wrap((function(n){for(;;)switch(n.prev=n.next){case 0:return n.next=2,t.getPersonalInfo();case 2:n.t0=a.default.keys(t.needRepairInfo);case 3:if((n.t1=n.t0()).done){n.next=11;break}if(r=n.t1.value,i=t.userInfo[r],!["category","politics"].includes(r)||![99,100].includes(i)){n.next=8;break}return n.abrupt("continue",3);case 8:i&&delete t.needRepairInfo[r],n.next=3;break;case 11:t.submitToExamInfo=e,t.isShowWritePart=!0;case 13:case"end":return n.stop()}}),n)})))()},closePersonalRepair:function(){var t=this;return(0,o.default)(a.default.mark((function n(){var r,i;return a.default.wrap((function(n){for(;;)switch(n.prev=n.next){case 0:t.isShowWritePart=!1,r=t.submitToExamInfo,i=r.targetUrl,e.navigateTo({url:i});case 4:case"end":return n.stop()}}),n)})))()},getPersonalInfo:function(){var e=this;return(0,o.default)(a.default.mark((function t(){return a.default.wrap((function(t){for(;;)switch(t.prev=t.next){case 0:return t.next=2,(0,p.getAndSetUserInfo)();case 2:e.userInfo=t.sent;case 3:case"end":return t.stop()}}),t)})))()},changeStates:function(){1===this.mantleStates?this.mantleStates=2:2===this.mantleStates&&(this.mantleStates=3)}}};t.default=h}).call(this,n("543d").default)},"167e":function(e,t,n){(function(e,t){var r=n("4ea4");n("bcdf"),r(n("66fd"));var a=r(n("864c"));e.__webpack_require_UNI_MP_PLUGIN__=n,t(a.default)}).call(this,n("bc2e").default,n("543d").createPage)},"28b3":function(e,t,n){n.d(t,"b",(function(){return r})),n.d(t,"c",(function(){return a})),n.d(t,"a",(function(){}));var r=function(){this.$createElement;this._self._c},a=[]},"53ff":function(e,t,n){n.r(t);var r=n("1345"),a=n.n(r);for(var i in r)["default"].indexOf(i)<0&&function(e){n.d(t,e,(function(){return r[e]}))}(i);t.default=a.a},7859:function(e,t,n){var r=n("0d70");n.n(r).a},"864c":function(e,t,n){n.r(t);var r=n("28b3"),a=n("53ff");for(var i in a)["default"].indexOf(i)<0&&function(e){n.d(t,e,(function(){return a[e]}))}(i);n("7859");var o=n("f0c5"),c=Object(o.a)(a.default,r.b,r.c,!1,null,"6e2cbbee",null,!1,r.a,void 0);t.default=c.exports}},[["167e","common/runtime","common/vendor"]]]);
},{isPage:true,isComponent:true,currentFile:'pages/activity/modes.js'});require("pages/activity/modes.js");