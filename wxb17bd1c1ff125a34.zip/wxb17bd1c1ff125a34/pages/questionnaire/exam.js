(global.webpackJsonp = global.webpackJsonp || []).push([ [ "pages/questionnaire/exam" ], {
    "26d1": function(n, e, t) {
        t.r(e);
        var a = t("39ad"), c = t("c5b6");
        for (var o in c) [ "default" ].indexOf(o) < 0 && function(n) {
            t.d(e, n, function() {
                return c[n];
            });
        }(o);
        var u = t("f0c5"), r = Object(u.a)(c.default, a.b, a.c, !1, null, null, null, !1, a.a, void 0);
        e.default = r.exports;
    },
    "39ad": function(n, e, t) {
        t.d(e, "b", function() {
            return a;
        }), t.d(e, "c", function() {
            return c;
        }), t.d(e, "a", function() {});
        var a = function() {
            this.$createElement;
            this._self._c;
        }, c = [];
    },
    6511: function(n, e, t) {
        (function(n) {
            Object.defineProperty(e, "__esModule", {
                value: !0
            }), e.default = void 0;
            var t = {
                name: "ExamPage",
                data: function() {
                    return {
                        modeSrc: ""
                    };
                },
                onLoad: function(e) {
                    var t = n.getStorageSync("authorization");
                    this.modeSrc = e.src + "?token=".concat(t), console.log(this.modeSrc);
                }
            };
            e.default = t;
        }).call(this, t("543d").default);
    },
    c5b6: function(n, e, t) {
        t.r(e);
        var a = t("6511"), c = t.n(a);
        for (var o in a) [ "default" ].indexOf(o) < 0 && function(n) {
            t.d(e, n, function() {
                return a[n];
            });
        }(o);
        e.default = c.a;
    },
    c973e: function(n, e, t) {
        (function(n, e) {
            var a = t("4ea4");
            t("bcdf"), a(t("66fd"));
            var c = a(t("26d1"));
            n.__webpack_require_UNI_MP_PLUGIN__ = t, e(c.default);
        }).call(this, t("bc2e").default, t("543d").createPage);
    }
}, [ [ "c973e", "common/runtime", "common/vendor" ] ] ]);