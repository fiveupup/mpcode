(global.webpackJsonp = global.webpackJsonp || []).push([ [ "pages/way/index" ], {
    "1bd8": function(n, t, e) {},
    5937: function(n, t, e) {
        (function(n, t) {
            var o = e("4ea4");
            e("bcdf"), o(e("66fd"));
            var a = o(e("988c"));
            n.__webpack_require_UNI_MP_PLUGIN__ = e, t(a.default);
        }).call(this, e("bc2e").default, e("543d").createPage);
    },
    "79eb": function(n, t, e) {
        var o = e("1bd8");
        e.n(o).a;
    },
    "7fc1": function(n, t, e) {
        e.r(t);
        var o = e("e9c7"), a = e.n(o);
        for (var i in o) [ "default" ].indexOf(i) < 0 && function(n) {
            e.d(t, n, function() {
                return o[n];
            });
        }(i);
        t.default = a.a;
    },
    9709: function(n, t, e) {
        e.d(t, "b", function() {
            return o;
        }), e.d(t, "c", function() {
            return a;
        }), e.d(t, "a", function() {});
        var o = function() {
            this.$createElement;
            this._self._c;
        }, a = [];
    },
    "988c": function(n, t, e) {
        e.r(t);
        var o = e("9709"), a = e("7fc1");
        for (var i in a) [ "default" ].indexOf(i) < 0 && function(n) {
            e.d(t, n, function() {
                return a[n];
            });
        }(i);
        e("79eb");
        var c = e("f0c5"), r = Object(c.a)(a.default, o.b, o.c, !1, null, "3c9749a4", null, !1, o.a, void 0);
        t.default = r.exports;
    },
    e9c7: function(n, t, e) {
        (function(n) {
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = void 0;
            var o = {
                components: {
                    UniNavBar: function() {
                        e.e("uni_modules/uni-nav-bar/components/uni-nav-bar/uni-nav-bar").then(function() {
                            return resolve(e("26b0"));
                        }.bind(null, e)).catch(e.oe);
                    }
                },
                data: function() {
                    var n = this;
                    return {
                        wayOptions: [ {
                            label: "个人模式",
                            prop: "person",
                            value: 1,
                            isShow: function() {
                                return n.mode && "4" !== n.mode.toString();
                            }
                        }, {
                            label: "团体模式",
                            prop: "team",
                            value: 2,
                            isShow: function() {
                                return n.mode && n.isTeam;
                            }
                        } ],
                        modeUrl: "",
                        activityId: "",
                        mode: "",
                        modeId: "",
                        isTeam: "",
                        way: ""
                    };
                },
                onLoad: function(n) {
                    for (var t in n) if (t in this) try {
                        this[t] = JSON.parse(n[t]);
                    } catch (e) {
                        this[t] = n[t];
                    }
                },
                computed: {
                    computedWayOptions: function() {
                        return this.wayOptions.filter(function(n) {
                            return n.isShow();
                        });
                    },
                    backgroundClass: function() {
                        return "is-".concat({
                            1: "normal",
                            2: "time",
                            3: "ten",
                            4: "pk"
                        }[this.mode]);
                    }
                },
                methods: {
                    selectWay: function(n) {
                        this.way = n, this.enterExam();
                    },
                    enterExam: function() {
                        var t = "".concat(this.modeUrl, "/").concat(this.activityId, "/").concat(this.mode, "/").concat(this.way, "/").concat(this.modeId);
                        console.log(t), n.redirectTo({
                            url: "/pages/questionnaire/exam?src=".concat(t)
                        });
                    }
                }
            };
            t.default = o;
        }).call(this, e("543d").default);
    }
}, [ [ "5937", "common/runtime", "common/vendor" ] ] ]);