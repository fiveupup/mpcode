$gwx_XC_5=function(_,_v,_n,_p,_s,_wp,_wl,$gwn,$gwl,$gwh,wh,$gstack,$gwrt,gra,grb,TestTest,wfor,_ca,_da,_r,_rz,_o,_oz,_1,_1z,_2,_2z,_m,_mz,nv_getDate,nv_getRegExp,nv_console,nv_parseInt,nv_parseFloat,nv_isNaN,nv_isFinite,nv_decodeURI,nv_decodeURIComponent,nv_encodeURI,nv_encodeURIComponent,$gdc,nv_JSON,_af,_gv,_ai,_grp,_gd,_gapi,$ixc,_ic,_w,_ev,_tsd){return function(path,global){
if(typeof global==='undefined'){if (typeof __GWX_GLOBAL__==='undefined')global={};else global=__GWX_GLOBAL__;}if(typeof __WXML_GLOBAL__ === 'undefined') {__WXML_GLOBAL__={};
}__WXML_GLOBAL__.modules = __WXML_GLOBAL__.modules || {};
var e_={}
if(typeof(global.entrys)==='undefined')global.entrys={};e_=global.entrys;
var d_={}
if(typeof(global.defines)==='undefined')global.defines={};d_=global.defines;
var f_={}
if(typeof(global.modules)==='undefined')global.modules={};f_=global.modules || {};
var p_={}
__WXML_GLOBAL__.ops_cached = __WXML_GLOBAL__.ops_cached || {}
__WXML_GLOBAL__.ops_set = __WXML_GLOBAL__.ops_set || {};
__WXML_GLOBAL__.ops_init = __WXML_GLOBAL__.ops_init || {};
var z=__WXML_GLOBAL__.ops_set.$gwx_XC_5 || [];
function gz$gwx_XC_5_1(){
if( __WXML_GLOBAL__.ops_cached.$gwx_XC_5_1)return __WXML_GLOBAL__.ops_cached.$gwx_XC_5_1
__WXML_GLOBAL__.ops_cached.$gwx_XC_5_1=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
Z([[2,'!'],[[7],[3,'showList']]])
Z([3,'search-wrap'])
Z([[2,'!'],[[7],[3,'inputValue']]])
Z([[7],[3,'inputValue']])
Z([[2,'=='],[[6],[[7],[3,'tiList']],[3,'length']],[1,0]])
Z([[2,'&&'],[[7],[3,'list']],[[2,'>'],[[6],[[7],[3,'list']],[3,'length']],[1,0]]])
Z([[2,'&&'],[[2,'=='],[[6],[[7],[3,'list']],[3,'length']],[1,0]],[[2,'=='],[[6],[[7],[3,'testList']],[3,'length']],[1,0]]])
})(__WXML_GLOBAL__.ops_cached.$gwx_XC_5_1);return __WXML_GLOBAL__.ops_cached.$gwx_XC_5_1
}
__WXML_GLOBAL__.ops_set.$gwx_XC_5=z;
__WXML_GLOBAL__.ops_init.$gwx_XC_5=true;
var x=['./pages/errorList/errorList.wxml'];d_[x[0]]={}
var m0=function(e,s,r,gg){
var z=gz$gwx_XC_5_1()
var bGB=_n('scroll-view')
_rz(z,bGB,'hidden',0,e,s,gg)
var fKB=_n('view')
_rz(z,fKB,'class',1,e,s,gg)
var cLB=_v()
_(fKB,cLB)
if(_oz(z,2,e,s,gg)){cLB.wxVkey=1
}
var hMB=_v()
_(fKB,hMB)
if(_oz(z,3,e,s,gg)){hMB.wxVkey=1
}
cLB.wxXCkey=1
hMB.wxXCkey=1
_(bGB,fKB)
var oHB=_v()
_(bGB,oHB)
if(_oz(z,4,e,s,gg)){oHB.wxVkey=1
}
var xIB=_v()
_(bGB,xIB)
if(_oz(z,5,e,s,gg)){xIB.wxVkey=1
}
var oJB=_v()
_(bGB,oJB)
if(_oz(z,6,e,s,gg)){oJB.wxVkey=1
}
oHB.wxXCkey=1
xIB.wxXCkey=1
oJB.wxXCkey=1
_(r,bGB)
return r
}
e_[x[0]]={f:m0,j:[],i:[],ti:[],ic:[]}
if(path&&e_[path]){
return function(env,dd,global){$gwxc=0;var root={"tag":"wx-page"};root.children=[]
;g="$gwx_XC_5";var main=e_[path].f
if (typeof global==="undefined")global={};global.f=$gdc(f_[path],"",1);
try{
main(env,{},root,global);
_tsd(root)
}catch(err){
console.log(err)
}
;g="";
return root;
}
}
}
}(__g.a,__g.b,__g.c,__g.d,__g.e,__g.f,__g.g,__g.h,__g.i,__g.j,__g.k,__g.l,__g.m,__g.n,__g.o,__g.p,__g.q,__g.r,__g.s,__g.t,__g.u,__g.v,__g.w,__g.x,__g.y,__g.z,__g.A,__g.B,__g.C,__g.D,__g.E,__g.F,__g.G,__g.H,__g.I,__g.J,__g.K,__g.L,__g.M,__g.N,__g.O,__g.P,__g.Q,__g.R,__g.S,__g.T,__g.U,__g.V,__g.W,__g.X,__g.Y,__g.Z,__g.aa);if(__vd_version_info__.delayedGwx||false)$gwx_XC_5();	if (__vd_version_info__.delayedGwx) __wxAppCode__['pages/errorList/errorList.wxml'] = [$gwx_XC_5, './pages/errorList/errorList.wxml'];else __wxAppCode__['pages/errorList/errorList.wxml'] = $gwx_XC_5( './pages/errorList/errorList.wxml' );
	;__wxRoute = "pages/errorList/errorList";__wxRouteBegin = true;__wxAppCurrentFile__="pages/errorList/errorList.js";define("pages/errorList/errorList.js",function(require,module,exports,window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){
"use strict";var t=wx.cloud.database(),e=getApp();Page({data:{showList:!1,loadingHidden:!1},onShow:function(){var e=this,a=t.command.aggregate;t.collection("tiku_errors").aggregate().group({_id:"$type",num:a.sum(1)}).end().then((function(t){console.log("",t),e.setData({list:t.list})})),t.collection("tiku_test_errors").aggregate().group({_id:"$testId",num:a.sum(1)}).sort({_id:-1}).end().then((function(t){console.log("",t),e.setData({testList:t.list})})),this.data.flag||(this.setData({scwidth:this.data.scwidth+3,flag:!0}),this.data.scwidth<100?setTimeout((function(){e.actionDack()}),100):this.setData({scwidth:0}))},goQuestionList:function(t){wx.navigateTo({url:"/pages/errorTypeList/errorTypeList?type="+t.currentTarget.dataset.type})},goTestQuestionList:function(t){wx.navigateTo({url:"/pages/testErrorTypeList/testErrorTypeList?type="+t.currentTarget.dataset.type})},goHome:function(){wx.switchTab({url:"/pages/home/home"})},onShareTimeline:function(){return{title:"练习错题集",imageUrl:"https://636c-cloud1-8gs7t7f49b4c97d8-1309642353.tcb.qcloud.la/cloudbase-cms/upload/2022-04-24/euhb16l1ane9x0h0m9q7r12rchk95or3_.png"}},toSearch:function(){wx.navigateTo({url:"/pages/errorList/errorList"})},onLoad:function(t){var e=this;setTimeout((function(){e.setData({showList:!0,loadingHidden:!0})}),1500)},getValue:function(t){console.log(t.detail.value);var e=t.detail.value;this.setData({inputValue:e})},getValue1:function(t){console.log(t.detail.value);t.detail.value;this.setData({inputValue1:kjdhksdjfgh})},search:function(){var t=this;wx.cloud.database().collection("tiku_questions").where({title:wx.cloud.database().RegExp({regexp:this.data.inputValue,options:"i"})}).get().then((function(e){console.log(e),t.setData({tiList:e.data})}))},shanchu:function(){var t=this;wx.cloud.database().collection("tiku_questions").where({title:wx.cloud.database().RegExp({regexp:"清空搜索栏 无",options:"i"})}).get().then((function(e){console.log(e),t.setData({tiList:e.data,shuru:null,inputValue:null})}))},toDetail:function(t){if(e.globalData.userInfo.name){console.log(t.currentTarget.dataset.id);var a=t.currentTarget.dataset.id;wx.navigateTo({url:"/pages/sousuo/sousuo?id="+a})}else wx.switchTab({url:"/pages/me/me",success:function(t){wx.showToast({icon:"none",title:"请先登录认证"})}})}});
},{isPage:true,isComponent:true,currentFile:'pages/errorList/errorList.js'});require("pages/errorList/errorList.js");