var t = wx.cloud.database(), e = getApp();

Page({
    data: {
        showList: !1,
        loadingHidden: !1
    },
    onShow: function() {
        var e = this, a = t.command.aggregate;
        t.collection("tiku_errors").aggregate().group({
            _id: "$type",
            num: a.sum(1)
        }).end().then(function(t) {
            console.log("", t), e.setData({
                list: t.list
            });
        }), t.collection("tiku_test_errors").aggregate().group({
            _id: "$testId",
            num: a.sum(1)
        }).sort({
            _id: -1
        }).end().then(function(t) {
            console.log("", t), e.setData({
                testList: t.list
            });
        }), this.data.flag || (this.setData({
            scwidth: this.data.scwidth + 3,
            flag: !0
        }), this.data.scwidth < 100 ? setTimeout(function() {
            e.actionDack();
        }, 100) : this.setData({
            scwidth: 0
        }));
    },
    goQuestionList: function(t) {
        wx.navigateTo({
            url: "/pages/errorTypeList/errorTypeList?type=" + t.currentTarget.dataset.type
        });
    },
    goTestQuestionList: function(t) {
        wx.navigateTo({
            url: "/pages/testErrorTypeList/testErrorTypeList?type=" + t.currentTarget.dataset.type
        });
    },
    goHome: function() {
        wx.switchTab({
            url: "/pages/home/home"
        });
    },
    onShareTimeline: function() {
        return {
            title: "练习错题集",
            imageUrl: "https://636c-cloud1-8gs7t7f49b4c97d8-1309642353.tcb.qcloud.la/cloudbase-cms/upload/2022-04-24/euhb16l1ane9x0h0m9q7r12rchk95or3_.png"
        };
    },
    toSearch: function() {
        wx.navigateTo({
            url: "/pages/errorList/errorList"
        });
    },
    onLoad: function(t) {
        var e = this;
        setTimeout(function() {
            e.setData({
                showList: !0,
                loadingHidden: !0
            });
        }, 1500);
    },
    getValue: function(t) {
        console.log(t.detail.value);
        var e = t.detail.value;
        this.setData({
            inputValue: e
        });
    },
    getValue1: function(t) {
        console.log(t.detail.value);
        t.detail.value;
        this.setData({
            inputValue1: kjdhksdjfgh
        });
    },
    search: function() {
        var t = this;
        wx.cloud.database().collection("tiku_questions").where({
            title: wx.cloud.database().RegExp({
                regexp: this.data.inputValue,
                options: "i"
            })
        }).get().then(function(e) {
            console.log(e), t.setData({
                tiList: e.data
            });
        });
    },
    shanchu: function() {
        var t = this;
        wx.cloud.database().collection("tiku_questions").where({
            title: wx.cloud.database().RegExp({
                regexp: "清空搜索栏 无",
                options: "i"
            })
        }).get().then(function(e) {
            console.log(e), t.setData({
                tiList: e.data,
                shuru: null,
                inputValue: null
            });
        });
    },
    toDetail: function(t) {
        if (e.globalData.userInfo.name) {
            console.log(t.currentTarget.dataset.id);
            var a = t.currentTarget.dataset.id;
            wx.navigateTo({
                url: "/pages/sousuo/sousuo?id=" + a
            });
        } else wx.switchTab({
            url: "/pages/me/me",
            success: function(t) {
                wx.showToast({
                    icon: "none",
                    title: "请先登录认证"
                });
            }
        });
    }
});