$gwx_XC_5=function(_,_v,_n,_p,_s,_wp,_wl,$gwn,$gwl,$gwh,wh,$gstack,$gwrt,gra,grb,TestTest,wfor,_ca,_da,_r,_rz,_o,_oz,_1,_1z,_2,_2z,_m,_mz,nv_getDate,nv_getRegExp,nv_console,nv_parseInt,nv_parseFloat,nv_isNaN,nv_isFinite,nv_decodeURI,nv_decodeURIComponent,nv_encodeURI,nv_encodeURIComponent,$gdc,nv_JSON,_af,_gv,_ai,_grp,_gd,_gapi,$ixc,_ic,_w,_ev,_tsd){return function(path,global){
if(typeof global==='undefined'){if (typeof __GWX_GLOBAL__==='undefined')global={};else global=__GWX_GLOBAL__;}if(typeof __WXML_GLOBAL__ === 'undefined') {__WXML_GLOBAL__={};
}__WXML_GLOBAL__.modules = __WXML_GLOBAL__.modules || {};
var e_={}
if(typeof(global.entrys)==='undefined')global.entrys={};e_=global.entrys;
var d_={}
if(typeof(global.defines)==='undefined')global.defines={};d_=global.defines;
var f_={}
if(typeof(global.modules)==='undefined')global.modules={};f_=global.modules || {};
var p_={}
__WXML_GLOBAL__.ops_cached = __WXML_GLOBAL__.ops_cached || {}
__WXML_GLOBAL__.ops_set = __WXML_GLOBAL__.ops_set || {};
__WXML_GLOBAL__.ops_init = __WXML_GLOBAL__.ops_init || {};
var z=__WXML_GLOBAL__.ops_set.$gwx_XC_5 || [];
function gz$gwx_XC_5_1(){
if( __WXML_GLOBAL__.ops_cached.$gwx_XC_5_1)return __WXML_GLOBAL__.ops_cached.$gwx_XC_5_1
__WXML_GLOBAL__.ops_cached.$gwx_XC_5_1=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
Z([3,'progress'])
Z([[7],[3,'loadingHidden']])
Z([3,'top:0px;'])
Z([3,'load_circle1'])
Z(z[1])
Z([3,'load_circle'])
Z([[2,'!'],[[7],[3,'showList']]])
Z([3,'search-wrap'])
Z([3,'search'])
Z([3,'getValue'])
Z([3,'send'])
Z([3,'搜索题目关键词 例：古典主义 '])
Z([3,'text'])
Z([[7],[3,'shuru']])
Z([[2,'!'],[[7],[3,'inputValue']]])
Z([3,'fdj'])
Z([3,'/images/fangdajing.png'])
Z([[7],[3,'inputValue']])
Z([3,'shanchu'])
Z([3,'fdjk'])
Z([3,'/images/shanchu.png'])
Z([3,'main-admin'])
Z([3,'list'])
Z([[7],[3,'tiList']])
Z([3,'item shadow'])
Z([3,'toDetail'])
Z([3,'good-box'])
Z([[6],[[7],[3,'item']],[3,'_id']])
Z([3,'kobai'])
Z([3,'h'])
Z([3,'corner-right-top text-bold number'])
Z([a,[[2,'+'],[[7],[3,'index']],[1,1]]])
Z([3,' '])
Z([a,[[6],[[7],[3,'item']],[3,'title']]])
Z(z[28])
Z(z[29])
Z([[2,'=='],[[6],[[7],[3,'tiList']],[3,'length']],[1,0]])
Z([3,' color:#656565;display:flex; justify-content: center;margin-block-end:40rpx;'])
Z([3,'🐷 ：没找到，换个词试试'])
Z([[2,'&&'],[[7],[3,'list']],[[2,'>'],[[6],[[7],[3,'list']],[3,'length']],[1,0]]])
Z([3,'top-zxlx'])
Z([3,'top3'])
Z([3,'red-block'])
Z([3,'/images/mine-head.png'])
Z([3,' 练习错题集：'])
Z([3,'top0'])
Z([3,'中国美术史（上）'])
Z([3,'goQuestionList'])
Z([3,'recommend-top-item1'])
Z(z[46])
Z([3,'zxlximage'])
Z([3,'https://636c-cloud1-8gs7t7f49b4c97d8-1309642353.tcb.qcloud.la/cloudbase-cms/upload/2022-05-27/1cn2vsnxgw4eb0zgbwh02alfx9xn9ijm_.png'])
Z(z[47])
Z(z[48])
Z([3,'中国美术史（下）'])
Z(z[50])
Z([3,'https://636c-cloud1-8gs7t7f49b4c97d8-1309642353.tcb.qcloud.la/cloudbase-cms/upload/2022-04-25/urw4zdrv9phexqqcclppkwp6d7gqy4zv_.png'])
Z(z[45])
Z(z[47])
Z(z[48])
Z([3,'外国美术史（上）'])
Z(z[50])
Z([3,'https://636c-cloud1-8gs7t7f49b4c97d8-1309642353.tcb.qcloud.la/cloudbase-cms/upload/2022-05-27/ng8p06ylaugxcn5ur45pcmh5apw2mdss_.png'])
Z(z[47])
Z(z[48])
Z([3,'外国美术史（下）'])
Z(z[50])
Z([3,'https://636c-cloud1-8gs7t7f49b4c97d8-1309642353.tcb.qcloud.la/cloudbase-cms/upload/2022-05-27/p24oqocs8lk693qtxcs29qyhwdpaadc0_.png'])
Z(z[45])
Z(z[47])
Z(z[48])
Z([3,'世界设计史（上）'])
Z(z[50])
Z([3,'https://636c-cloud1-8gs7t7f49b4c97d8-1309642353.tcb.qcloud.la/cloudbase-cms/upload/2022-05-27/5cc2cuj7gilwkpul8333oa2dcfpsdw1c_.png'])
Z(z[47])
Z(z[48])
Z([3,'世界设计史（下）'])
Z(z[50])
Z([3,'https://636c-cloud1-8gs7t7f49b4c97d8-1309642353.tcb.qcloud.la/cloudbase-cms/upload/2022-05-27/6jdqev3waiswlgwtpjcqjoh64nh6q3zx_.png'])
Z([[2,'&&'],[[2,'=='],[[6],[[7],[3,'list']],[3,'length']],[1,0]],[[2,'=='],[[6],[[7],[3,'testList']],[3,'length']],[1,0]]])
Z([3,'goHome'])
Z([3,'nothing'])
Z([3,' 没有错题啦\n'])
})(__WXML_GLOBAL__.ops_cached.$gwx_XC_5_1);return __WXML_GLOBAL__.ops_cached.$gwx_XC_5_1
}
__WXML_GLOBAL__.ops_set.$gwx_XC_5=z;
__WXML_GLOBAL__.ops_init.$gwx_XC_5=true;
var x=['./pages/errorList/errorList.wxml'];d_[x[0]]={}
var m0=function(e,s,r,gg){
var z=gz$gwx_XC_5_1()
var x3J=_mz(z,'view',['class',0,'hidden',1,'style',1],[],e,s,gg)
_(r,x3J)
var o4J=_mz(z,'view',['class',3,'hidden',1],[],e,s,gg)
var f5J=_n('view')
_rz(z,f5J,'class',5,e,s,gg)
_(o4J,f5J)
_(r,o4J)
var c6J=_n('scroll-view')
_rz(z,c6J,'hidden',6,e,s,gg)
var o0J=_n('view')
_rz(z,o0J,'class',7,e,s,gg)
var tCK=_mz(z,'input',['bindconfirm',8,'bindinput',1,'confirmType',2,'placeholder',3,'type',4,'value',5],[],e,s,gg)
_(o0J,tCK)
var lAK=_v()
_(o0J,lAK)
if(_oz(z,14,e,s,gg)){lAK.wxVkey=1
var eDK=_mz(z,'image',['class',15,'src',1],[],e,s,gg)
_(lAK,eDK)
}
var aBK=_v()
_(o0J,aBK)
if(_oz(z,17,e,s,gg)){aBK.wxVkey=1
var bEK=_mz(z,'image',['bindtap',18,'class',1,'src',2],[],e,s,gg)
_(aBK,bEK)
}
lAK.wxXCkey=1
aBK.wxXCkey=1
_(c6J,o0J)
var oFK=_n('view')
_rz(z,oFK,'class',21,e,s,gg)
var xGK=_n('view')
_rz(z,xGK,'class',22,e,s,gg)
var oHK=_v()
_(xGK,oHK)
var fIK=function(hKK,cJK,oLK,gg){
var oNK=_n('view')
_rz(z,oNK,'class',24,hKK,cJK,gg)
var lOK=_mz(z,'view',['bindtap',25,'class',1,'data-id',2],[],hKK,cJK,gg)
var aPK=_n('view')
_rz(z,aPK,'class',28,hKK,cJK,gg)
var tQK=_oz(z,29,hKK,cJK,gg)
_(aPK,tQK)
_(lOK,aPK)
var eRK=_n('view')
_rz(z,eRK,'class',30,hKK,cJK,gg)
var bSK=_oz(z,31,hKK,cJK,gg)
_(eRK,bSK)
_(lOK,eRK)
var oTK=_n('view')
_rz(z,oTK,'class',32,hKK,cJK,gg)
var xUK=_oz(z,33,hKK,cJK,gg)
_(oTK,xUK)
_(lOK,oTK)
var oVK=_n('view')
_rz(z,oVK,'class',34,hKK,cJK,gg)
var fWK=_oz(z,35,hKK,cJK,gg)
_(oVK,fWK)
_(lOK,oVK)
_(oNK,lOK)
_(oLK,oNK)
return oLK
}
oHK.wxXCkey=2
_2z(z,23,fIK,e,s,gg,oHK,'item','index','')
_(oFK,xGK)
_(c6J,oFK)
var h7J=_v()
_(c6J,h7J)
if(_oz(z,36,e,s,gg)){h7J.wxVkey=1
var cXK=_n('view')
_rz(z,cXK,'style',37,e,s,gg)
var hYK=_oz(z,38,e,s,gg)
_(cXK,hYK)
_(h7J,cXK)
}
var o8J=_v()
_(c6J,o8J)
if(_oz(z,39,e,s,gg)){o8J.wxVkey=1
var oZK=_n('view')
_rz(z,oZK,'class',40,e,s,gg)
var c1K=_n('view')
_rz(z,c1K,'class',41,e,s,gg)
var o2K=_n('view')
var l3K=_mz(z,'image',['class',42,'src',1],[],e,s,gg)
_(o2K,l3K)
var a4K=_n('text')
var t5K=_oz(z,44,e,s,gg)
_(a4K,t5K)
_(o2K,a4K)
_(c1K,o2K)
_(oZK,c1K)
_(o8J,oZK)
}
var e6K=_n('view')
var b7K=_mz(z,'view',['class',45,'data-type',1],[],e,s,gg)
var o8K=_mz(z,'view',['bindtap',47,'class',1,'data-type',2],[],e,s,gg)
var x9K=_mz(z,'image',['class',50,'src',1],[],e,s,gg)
_(o8K,x9K)
_(b7K,o8K)
var o0K=_mz(z,'view',['bindtap',52,'class',1,'data-type',2],[],e,s,gg)
var fAL=_mz(z,'image',['class',55,'src',1],[],e,s,gg)
_(o0K,fAL)
_(b7K,o0K)
_(e6K,b7K)
_(c6J,e6K)
var cBL=_n('view')
_rz(z,cBL,'class',57,e,s,gg)
var hCL=_mz(z,'view',['bindtap',58,'class',1,'data-type',2],[],e,s,gg)
var oDL=_mz(z,'image',['class',61,'src',1],[],e,s,gg)
_(hCL,oDL)
_(cBL,hCL)
var cEL=_mz(z,'view',['bindtap',63,'class',1,'data-type',2],[],e,s,gg)
var oFL=_mz(z,'image',['class',66,'src',1],[],e,s,gg)
_(cEL,oFL)
_(cBL,cEL)
_(c6J,cBL)
var lGL=_n('view')
_rz(z,lGL,'class',68,e,s,gg)
var aHL=_mz(z,'view',['bindtap',69,'class',1,'data-type',2],[],e,s,gg)
var tIL=_mz(z,'image',['class',72,'src',1],[],e,s,gg)
_(aHL,tIL)
_(lGL,aHL)
var eJL=_mz(z,'view',['bindtap',74,'class',1,'data-type',2],[],e,s,gg)
var bKL=_mz(z,'image',['class',77,'src',1],[],e,s,gg)
_(eJL,bKL)
_(lGL,eJL)
_(c6J,lGL)
var c9J=_v()
_(c6J,c9J)
if(_oz(z,79,e,s,gg)){c9J.wxVkey=1
var oLL=_mz(z,'view',['bindtap',80,'class',1],[],e,s,gg)
var xML=_oz(z,82,e,s,gg)
_(oLL,xML)
_(c9J,oLL)
}
h7J.wxXCkey=1
o8J.wxXCkey=1
c9J.wxXCkey=1
_(r,c6J)
return r
}
e_[x[0]]={f:m0,j:[],i:[],ti:[],ic:[]}
if(path&&e_[path]){
outerGlobal.__wxml_comp_version__=0.02
return function(env,dd,global){$gwxc=0;var root={"tag":"wx-page"};root.children=[]
;g="$gwx_XC_5";var main=e_[path].f
if (typeof global==="undefined")global={};global.f=$gdc(f_[path],"",1);
if(typeof(outerGlobal.__webview_engine_version__)!='undefined'&&outerGlobal.__webview_engine_version__+1e-6>=0.02+1e-6&&outerGlobal.__mergeData__)
{
env=outerGlobal.__mergeData__(env,dd);
}
try{
main(env,{},root,global);
_tsd(root)
if(typeof(outerGlobal.__webview_engine_version__)=='undefined'|| outerGlobal.__webview_engine_version__+1e-6<0.01+1e-6){return _ev(root);}
}catch(err){
console.log(err)
}
;g="";
return root;
}
}
}
}(__g.a,__g.b,__g.c,__g.d,__g.e,__g.f,__g.g,__g.h,__g.i,__g.j,__g.k,__g.l,__g.m,__g.n,__g.o,__g.p,__g.q,__g.r,__g.s,__g.t,__g.u,__g.v,__g.w,__g.x,__g.y,__g.z,__g.A,__g.B,__g.C,__g.D,__g.E,__g.F,__g.G,__g.H,__g.I,__g.J,__g.K,__g.L,__g.M,__g.N,__g.O,__g.P,__g.Q,__g.R,__g.S,__g.T,__g.U,__g.V,__g.W,__g.X,__g.Y,__g.Z,__g.aa);if(__vd_version_info__.delayedGwx||false)$gwx_XC_5();	if (__vd_version_info__.delayedGwx) __wxAppCode__['pages/errorList/errorList.wxml'] = [$gwx_XC_5, './pages/errorList/errorList.wxml'];else __wxAppCode__['pages/errorList/errorList.wxml'] = $gwx_XC_5( './pages/errorList/errorList.wxml' );
	
var noCss=typeof __vd_version_info__!=='undefined'&&__vd_version_info__.noCss===true;if(!noCss){__wxAppCode__['pages/errorList/errorList.wxss'] = setCssToHead(["body{background-color:#ecf0f1;height:100%}\n.",[1],"item_root{display:-webkit-flex;display:flex;-webkit-flex-wrap:wrap;flex-wrap:wrap;-webkit-justify-content:flex-start;justify-content:flex-start;padding:",[0,20],"}\n.",[1],"nothing{border-radius:",[0,50],";color:#000;margin:",[0,60],";padding:",[0,20],";text-align:center}\n.",[1],"title{font-size:",[0,40],";font-weight:550;margin:",[0,40]," ",[0,20]," ",[0,20],"}\n.",[1],"search-wrap{border:1px solid#aaa;border-radius:20px;height:30px;margin:20px;width:40}\n.",[1],"search-box,.",[1],"search-wrap{-webkit-align-items:center;align-items:center;display:-webkit-flex;display:flex;-webkit-flex-direction:row;flex-direction:row;-webkit-justify-content:space-between;justify-content:space-between}\n.",[1],"search-box{background-color:#fff;border:",[0,1]," solid #e6e6e6;padding:0 ",[0,20],"}\n.",[1],"search-img{background-color:#fff;height:",[0,50],";width:",[0,50],"}\n.",[1],"input-cell{background-color:#fff;padding:",[0,20],";width:",[0,60],"}\n.",[1],"good-box{background-color:#fff;border:",[0,4]," solid #fff;border-radius:",[0,24],";box-sizing:border-box;color:#777;display:-webkit-flex;display:flex;-webkit-flex-direction:column;flex-direction:column;-webkit-justify-content:space-between;justify-content:space-between;margin:",[0,10]," ",[0,30],";padding:",[0,10]," ",[0,30]," ",[0,30],";width:94%}\n.",[1],"text-boldnumber{min-width:",[0,50],";padding-left:",[0,10],";padding-right:",[0,10],";width:unset}\n.",[1],"good-img{height:",[0,150],";margin-right:",[0,20],";width:",[0,150],"}\n.",[1],"right-bottom-box{-webkit-flex-direction:row;flex-direction:row;width:",[0,500],"}\n.",[1],"right-bottom-box,.",[1],"right-box{display:-webkit-flex;display:flex;-webkit-justify-content:space-between;justify-content:space-between}\n.",[1],"right-box{-webkit-flex-direction:column;flex-direction:column;padding:",[0,10]," 0}\n.",[1],"price{color:red;font-size:",[0,36],"}\n.",[1],"tag{color:#ddd}\n.",[1],"searchboxicon{margin-right:12px}\nwx-input{font-size:12px;margin-left:12px;width:85%}\n.",[1],"red-block{height:",[0,24],";position:relative;width:",[0,10],"}\n.",[1],"top-zxlx{-webkit-justify-content:center;justify-content:center;margin:",[0,15],"}\n.",[1],"top-zxlx,.",[1],"top3{display:-webkit-flex;display:flex}\n.",[1],"top3{border-radius:",[0,15],";color:#747474;font-size:",[0,35],";-webkit-justify-content:space-between;justify-content:space-between;line-height:",[0,10],";margin:",[0,10],";width:90%}\n.",[1],"top0{display:-webkit-flex;display:flex;-webkit-justify-content:center;justify-content:center;margin:",[0,15],"}\n.",[1],"recommend-top-item1{background:#fcfcfc;border-radius:12px;border-radius:",[0,24],";box-shadow:0 ",[0,4]," ",[0,8]," 0 rgba(0,0,0,.06);-webkit-justify-content:space-between;justify-content:space-between;margin:0 auto ",[0,24],";overflow:hidden}\n.",[1],"recommend-top-item1,.",[1],"zxlximage{display:-webkit-flex;display:flex;height:",[0,200],";width:",[0,350],"}\n.",[1],"zxlximage{-webkit-flex-direction:row;flex-direction:row;font-size:12px;-webkit-justify-content:center;justify-content:center;padding-bottom:12px}\n.",[1],"fdj{height:",[0,40],";width:",[0,40],"}\n.",[1],"fdjk{height:",[0,60],";width:",[0,60],"}\n@-webkit-keyframes fadeIn{100%{opacity:0}\n100%{opacity:1}\n}@keyframes fadeIn{100%{opacity:0}\n100%{opacity:1}\n}.",[1],"progress-spinner{border-color:orange;display:block;position:absolute;right:",[0,10],";top:",[0,10],";z-index:2000}\n.",[1],"progress-spinner::after{-webkit-animation:load-spinner .4s linear infinite;animation:load-spinner .4s linear infinite;border:",[0,4]," solid transparent;border-left-color:inherit;border-radius:50%;border-top-color:inherit;box-sizing:border-box;content:\x22\x22;display:block;height:",[0,24],";width:",[0,24],"}\n@-webkit-keyframes load-spinner{0%{-webkit-transform:rotate(0);transform:rotate(0)}\n100%{-webkit-transform:rotate(1turn);transform:rotate(1turn)}\n}@keyframes load-spinner{0%{-webkit-transform:rotate(0);transform:rotate(0)}\n100%{-webkit-transform:rotate(1turn);transform:rotate(1turn)}\n}.",[1],"load_circle1{-webkit-align-items:center;align-items:center;display:-webkit-flex;display:flex;-webkit-flex-direction:row;flex-direction:row;height:100%;-webkit-justify-content:center;justify-content:center;vertical-align:center}\n.",[1],"load_circle{-webkit-animation:circle-ani 1s linear infinite;animation:circle-ani 1s linear infinite;border:",[0,4]," solid rgba(0,0,0,.25);border-radius:30%;height:",[0,100],";margin:60px auto;position:relative;width:",[0,100],"}\n@-webkit-keyframes circle-ani{0%{-webkit-transform:rotate(0);transform:rotate(0)}\n100%{-webkit-transform:rotate(359deg);transform:rotate(359deg)}\n}@keyframes circle-ani{0%{-webkit-transform:rotate(0);transform:rotate(0)}\n100%{-webkit-transform:rotate(359deg);transform:rotate(359deg)}\n}.",[1],"main-admin .",[1],"list .",[1],"item{background-color:#fff;border-radius:",[0,20],";box-shadow:0 ",[0,4]," ",[0,8]," 0 rgba(0,0,0,.06);box-sizing:border-box;display:-webkit-flex;display:flex;-webkit-flex-direction:column;flex-direction:column;-webkit-justify-content:space-between;justify-content:space-between;margin:",[0,10]," ",[0,30]," ",[0,10]," ",[0,20],";position:relative;width:94%}\n.",[1],"main-admin .",[1],"list .",[1],"item .",[1],"corner-right-bottom,.",[1],"main-admin .",[1],"list .",[1],"item .",[1],"corner-right-top{background-color:#f2f2f2;border-radius:0 ",[0,20]," 0 ",[0,20],";color:#aaa;font-size:",[0,24],";height:",[0,60],";line-height:",[0,60],";position:absolute;right:0;text-align:center;top:0;width:",[0,80],"}\n.",[1],"main-admin .",[1],"list .",[1],"item .",[1],"corner-right-top.",[1],"number{min-width:",[0,50],";padding-left:",[0,10],";padding-right:",[0,10],";width:unset}\n.",[1],"kobai{color:#fff}\n",],"Some selectors are not allowed in component wxss, including tag name selectors, ID selectors, and attribute selectors.(./pages/errorList/errorList.wxss:1:1677)",{path:"./pages/errorList/errorList.wxss"});
}