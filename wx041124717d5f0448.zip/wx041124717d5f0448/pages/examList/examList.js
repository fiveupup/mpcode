var t = wx.cloud.database();

Page({
    onLoad: function(e) {
        var a = this;
        console.log("", e.type), wx.setNavigationBarTitle({
            title: e.type + "模拟考试"
        }), this.setData({
            type: e.type
        });
        var o = t.command.aggregate;
        t.collection("tiku_exams").aggregate().match({
            type: e.type
        }).group({
            _id: "$type2",
            num: o.sum(1)
        }).end().then(function(t) {
            console.log("", t), a.setData({
                list: t.list
            });
        });
    },
    goDetail: function(t) {
        var e = this.data.type, a = t.currentTarget.dataset.type2;
        wx.navigateTo({
            url: "/pages/test/test?type1=" + e + "&type2=" + a
        });
    }
});