$gwx_XC_7=function(_,_v,_n,_p,_s,_wp,_wl,$gwn,$gwl,$gwh,wh,$gstack,$gwrt,gra,grb,TestTest,wfor,_ca,_da,_r,_rz,_o,_oz,_1,_1z,_2,_2z,_m,_mz,nv_getDate,nv_getRegExp,nv_console,nv_parseInt,nv_parseFloat,nv_isNaN,nv_isFinite,nv_decodeURI,nv_decodeURIComponent,nv_encodeURI,nv_encodeURIComponent,$gdc,nv_JSON,_af,_gv,_ai,_grp,_gd,_gapi,$ixc,_ic,_w,_ev,_tsd){return function(path,global){
if(typeof global==='undefined'){if (typeof __GWX_GLOBAL__==='undefined')global={};else global=__GWX_GLOBAL__;}if(typeof __WXML_GLOBAL__ === 'undefined') {__WXML_GLOBAL__={};
}__WXML_GLOBAL__.modules = __WXML_GLOBAL__.modules || {};
var e_={}
if(typeof(global.entrys)==='undefined')global.entrys={};e_=global.entrys;
var d_={}
if(typeof(global.defines)==='undefined')global.defines={};d_=global.defines;
var f_={}
if(typeof(global.modules)==='undefined')global.modules={};f_=global.modules || {};
var p_={}
__WXML_GLOBAL__.ops_cached = __WXML_GLOBAL__.ops_cached || {}
__WXML_GLOBAL__.ops_set = __WXML_GLOBAL__.ops_set || {};
__WXML_GLOBAL__.ops_init = __WXML_GLOBAL__.ops_init || {};
var z=__WXML_GLOBAL__.ops_set.$gwx_XC_7 || [];
function gz$gwx_XC_7_1(){
if( __WXML_GLOBAL__.ops_cached.$gwx_XC_7_1)return __WXML_GLOBAL__.ops_cached.$gwx_XC_7_1
__WXML_GLOBAL__.ops_cached.$gwx_XC_7_1=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
Z([3,'tip'])
Z([a,[[7],[3,'type']],[3,'错题']])
Z([[2,'!='],[[6],[[7],[3,'liet']],[3,'num']],[1,0]])
Z([[7],[3,'list']])
Z([3,'index'])
Z([3,'goDetail'])
Z([3,'item'])
Z([[6],[[7],[3,'item']],[3,'_id']])
Z([3,'type'])
Z([3,'/images/mine-head.png'])
Z([a,[3,' '],[[6],[[7],[3,'item']],[3,'_id']],[3,'('],[[6],[[7],[3,'item']],[3,'num']],[3,'道题)']])
Z([3,'btn'])
Z([3,'去复习  \x3e'])
Z([3,'btn1'])
})(__WXML_GLOBAL__.ops_cached.$gwx_XC_7_1);return __WXML_GLOBAL__.ops_cached.$gwx_XC_7_1
}
__WXML_GLOBAL__.ops_set.$gwx_XC_7=z;
__WXML_GLOBAL__.ops_init.$gwx_XC_7=true;
var x=['./pages/errorTypeList/errorTypeList.wxml'];d_[x[0]]={}
var m0=function(e,s,r,gg){
var z=gz$gwx_XC_7_1()
var oBO=_n('view')
_rz(z,oBO,'class',0,e,s,gg)
var xCO=_oz(z,1,e,s,gg)
_(oBO,xCO)
_(r,oBO)
var bAO=_v()
_(r,bAO)
if(_oz(z,2,e,s,gg)){bAO.wxVkey=1
var oDO=_n('view')
var fEO=_v()
_(oDO,fEO)
var cFO=function(oHO,hGO,cIO,gg){
var lKO=_mz(z,'view',['bindtap',5,'class',1,'data-type2',2],[],oHO,hGO,gg)
var aLO=_n('view')
var tMO=_mz(z,'image',['class',8,'src',1],[],oHO,hGO,gg)
_(aLO,tMO)
var eNO=_n('text')
var bOO=_oz(z,10,oHO,hGO,gg)
_(eNO,bOO)
_(aLO,eNO)
_(lKO,aLO)
var oPO=_n('text')
_rz(z,oPO,'class',11,oHO,hGO,gg)
var xQO=_oz(z,12,oHO,hGO,gg)
_(oPO,xQO)
var oRO=_n('text')
_rz(z,oRO,'class',13,oHO,hGO,gg)
_(oPO,oRO)
_(lKO,oPO)
_(cIO,lKO)
return cIO
}
fEO.wxXCkey=2
_2z(z,3,cFO,e,s,gg,fEO,'item','index','index')
_(bAO,oDO)
}
bAO.wxXCkey=1
return r
}
e_[x[0]]={f:m0,j:[],i:[],ti:[],ic:[]}
if(path&&e_[path]){
outerGlobal.__wxml_comp_version__=0.02
return function(env,dd,global){$gwxc=0;var root={"tag":"wx-page"};root.children=[]
;g="$gwx_XC_7";var main=e_[path].f
if (typeof global==="undefined")global={};global.f=$gdc(f_[path],"",1);
if(typeof(outerGlobal.__webview_engine_version__)!='undefined'&&outerGlobal.__webview_engine_version__+1e-6>=0.02+1e-6&&outerGlobal.__mergeData__)
{
env=outerGlobal.__mergeData__(env,dd);
}
try{
main(env,{},root,global);
_tsd(root)
if(typeof(outerGlobal.__webview_engine_version__)=='undefined'|| outerGlobal.__webview_engine_version__+1e-6<0.01+1e-6){return _ev(root);}
}catch(err){
console.log(err)
}
;g="";
return root;
}
}
}
}(__g.a,__g.b,__g.c,__g.d,__g.e,__g.f,__g.g,__g.h,__g.i,__g.j,__g.k,__g.l,__g.m,__g.n,__g.o,__g.p,__g.q,__g.r,__g.s,__g.t,__g.u,__g.v,__g.w,__g.x,__g.y,__g.z,__g.A,__g.B,__g.C,__g.D,__g.E,__g.F,__g.G,__g.H,__g.I,__g.J,__g.K,__g.L,__g.M,__g.N,__g.O,__g.P,__g.Q,__g.R,__g.S,__g.T,__g.U,__g.V,__g.W,__g.X,__g.Y,__g.Z,__g.aa);if(__vd_version_info__.delayedGwx||false)$gwx_XC_7();	if (__vd_version_info__.delayedGwx) __wxAppCode__['pages/errorTypeList/errorTypeList.wxml'] = [$gwx_XC_7, './pages/errorTypeList/errorTypeList.wxml'];else __wxAppCode__['pages/errorTypeList/errorTypeList.wxml'] = $gwx_XC_7( './pages/errorTypeList/errorTypeList.wxml' );
	
var noCss=typeof __vd_version_info__!=='undefined'&&__vd_version_info__.noCss===true;if(!noCss){__wxAppCode__['pages/errorTypeList/errorTypeList.wxss'] = setCssToHead([".",[1],"tip{color:#ff5850;font-size:",[0,48],";margin:",[0,40],"}\n.",[1],"item{border-bottom:1px solid #e9e9e9;display:-webkit-flex;display:flex;-webkit-flex:1;flex:1;font-size:",[0,28],";-webkit-justify-content:space-between;justify-content:space-between;margin:",[0,10]," ",[0,30],";padding:",[0,20]," ",[0,10]," ",[0,20]," ",[0,20],"}\n.",[1],"btn{color:#ff5850;padding:",[0,5]," ",[0,20],"}\n.",[1],"type{height:",[0,24],";position:relative;width:",[0,10],"}\n",],undefined,{path:"./pages/errorTypeList/errorTypeList.wxss"});
}