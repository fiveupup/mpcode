var t = wx.cloud.database();

Page({
    onLoad: function(t) {
        console.log("一级题目类型", t.type), wx.setNavigationBarTitle({
            title: ""
        }), this.setData({
            type: t.type
        });
    },
    onShow: function() {
        var e = this, a = t.command.aggregate;
        t.collection("tiku_errors").aggregate().match({
            type: this.data.type
        }).group({
            _id: "$type2",
            num: a.sum(1)
        }).end().then(function(t) {
            console.log("", t), e.setData({
                list: t.list
            });
        });
    },
    goDetail: function(t) {
        var e = this.data.type, a = t.currentTarget.dataset.type2;
        wx.navigateTo({
            url: "/pages/errorQuestions/errorQuestions?type1=" + e + "&type2=" + a
        });
    },
    onShareTimeline: function() {
        return {
            title: "天美史论1000题",
            imageUrl: "https://636c-cloud1-8gs7t7f49b4c97d8-1309642353.tcb.qcloud.la/cloudbase-cms/upload/2022-04-24/euhb16l1ane9x0h0m9q7r12rchk95or3_.png"
        };
    }
});