$gwx_XC_12=function(_,_v,_n,_p,_s,_wp,_wl,$gwn,$gwl,$gwh,wh,$gstack,$gwrt,gra,grb,TestTest,wfor,_ca,_da,_r,_rz,_o,_oz,_1,_1z,_2,_2z,_m,_mz,nv_getDate,nv_getRegExp,nv_console,nv_parseInt,nv_parseFloat,nv_isNaN,nv_isFinite,nv_decodeURI,nv_decodeURIComponent,nv_encodeURI,nv_encodeURIComponent,$gdc,nv_JSON,_af,_gv,_ai,_grp,_gd,_gapi,$ixc,_ic,_w,_ev,_tsd){return function(path,global){
if(typeof global==='undefined'){if (typeof __GWX_GLOBAL__==='undefined')global={};else global=__GWX_GLOBAL__;}if(typeof __WXML_GLOBAL__ === 'undefined') {__WXML_GLOBAL__={};
}__WXML_GLOBAL__.modules = __WXML_GLOBAL__.modules || {};
var e_={}
if(typeof(global.entrys)==='undefined')global.entrys={};e_=global.entrys;
var d_={}
if(typeof(global.defines)==='undefined')global.defines={};d_=global.defines;
var f_={}
if(typeof(global.modules)==='undefined')global.modules={};f_=global.modules || {};
var p_={}
__WXML_GLOBAL__.ops_cached = __WXML_GLOBAL__.ops_cached || {}
__WXML_GLOBAL__.ops_set = __WXML_GLOBAL__.ops_set || {};
__WXML_GLOBAL__.ops_init = __WXML_GLOBAL__.ops_init || {};
var z=__WXML_GLOBAL__.ops_set.$gwx_XC_12 || [];
function gz$gwx_XC_12_1(){
if( __WXML_GLOBAL__.ops_cached.$gwx_XC_12_1)return __WXML_GLOBAL__.ops_cached.$gwx_XC_12_1
__WXML_GLOBAL__.ops_cached.$gwx_XC_12_1=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
Z([[2,'&&'],[[7],[3,'userInfo']],[[6],[[7],[3,'userInfo']],[3,'avatarUrl']]])
Z([[2,'!'],[[2,'&&'],[[7],[3,'userInfo']],[[6],[[7],[3,'userInfo']],[3,'avatarUrl']]]])
Z([3,'beijin1'])
Z([[7],[3,'showAdmin']])
Z([[2,'&&'],[[7],[3,'userInfo']],[[6],[[7],[3,'userInfo']],[3,'avatarUrl']]])
Z(z[0])
})(__WXML_GLOBAL__.ops_cached.$gwx_XC_12_1);return __WXML_GLOBAL__.ops_cached.$gwx_XC_12_1
}
__WXML_GLOBAL__.ops_set.$gwx_XC_12=z;
__WXML_GLOBAL__.ops_init.$gwx_XC_12=true;
var x=['./pages/me/me.wxml'];d_[x[0]]={}
var m0=function(e,s,r,gg){
var z=gz$gwx_XC_12_1()
var l5B=_v()
_(r,l5B)
if(_oz(z,0,e,s,gg)){l5B.wxVkey=1
}
var a6B=_v()
_(r,a6B)
if(_oz(z,1,e,s,gg)){a6B.wxVkey=1
}
var e8B=_n('view')
_rz(z,e8B,'class',2,e,s,gg)
var b9B=_v()
_(e8B,b9B)
if(_oz(z,3,e,s,gg)){b9B.wxVkey=1
}
var o0B=_v()
_(e8B,o0B)
if(_oz(z,4,e,s,gg)){o0B.wxVkey=1
}
b9B.wxXCkey=1
o0B.wxXCkey=1
_(r,e8B)
var t7B=_v()
_(r,t7B)
if(_oz(z,5,e,s,gg)){t7B.wxVkey=1
}
l5B.wxXCkey=1
a6B.wxXCkey=1
t7B.wxXCkey=1
return r
}
e_[x[0]]={f:m0,j:[],i:[],ti:[],ic:[]}
if(path&&e_[path]){
return function(env,dd,global){$gwxc=0;var root={"tag":"wx-page"};root.children=[]
;g="$gwx_XC_12";var main=e_[path].f
if (typeof global==="undefined")global={};global.f=$gdc(f_[path],"",1);
try{
main(env,{},root,global);
_tsd(root)
}catch(err){
console.log(err)
}
;g="";
return root;
}
}
}
}(__g.a,__g.b,__g.c,__g.d,__g.e,__g.f,__g.g,__g.h,__g.i,__g.j,__g.k,__g.l,__g.m,__g.n,__g.o,__g.p,__g.q,__g.r,__g.s,__g.t,__g.u,__g.v,__g.w,__g.x,__g.y,__g.z,__g.A,__g.B,__g.C,__g.D,__g.E,__g.F,__g.G,__g.H,__g.I,__g.J,__g.K,__g.L,__g.M,__g.N,__g.O,__g.P,__g.Q,__g.R,__g.S,__g.T,__g.U,__g.V,__g.W,__g.X,__g.Y,__g.Z,__g.aa);if(__vd_version_info__.delayedGwx||false)$gwx_XC_12();	if (__vd_version_info__.delayedGwx) __wxAppCode__['pages/me/me.wxml'] = [$gwx_XC_12, './pages/me/me.wxml'];else __wxAppCode__['pages/me/me.wxml'] = $gwx_XC_12( './pages/me/me.wxml' );
	;__wxRoute = "pages/me/me";__wxRouteBegin = true;__wxAppCurrentFile__="pages/me/me.js";define("pages/me/me.js",function(require,module,exports,window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){
"use strict";var a=getApp(),o=wx.cloud.database().collection("tiku_users");wx.cloud.database().collection("author");Page({data:{userInfo:null,showAdmin:!1},getAdmin:function(){var a=this;wx.cloud.callFunction({name:"getOpenid",complete:function(o){var e=o.result.openid;wx.cloud.database().collection("author").get().then((function(o){var n=o.data[0]._openid;e===n?a.setData({showAdmin:!0}):a.setData({showAdmin:!1})}))}})},onLoad:function(a){this.getAdmin()},onShow:function(o){var e=a.globalData.userInfo;console.log("",e),e&&e.nickName?this.setData({userInfo:e}):this.setData({userInfo:wx.getStorageSync("user")}),this.getScore(),this.getUserInfo()},getUserInfo:function(){var e=this;console.log(a.globalData.openid),o.doc(a.globalData.openid).get().then((function(a){console.log("",a),e.setData({user:a.data})}))},getScore:function(){var o=this;wx.cloud.database().collection("tiku_users").doc(a.globalData.openid).get().then((function(a){if(a&&a.data&&a.data.score>0){var e=a.data.score;console.log("",e),o.setData({score:e})}})).catch((function(a){console.log("")}))},getUserProfile:function(){var o=this;wx.getUserProfile({desc:"用于完善学员资料",success:function(e){console.log("",e);var n=e.userInfo;a.globalData.userInfo.nickName=n.nickName,a.globalData.userInfo.avatarUrl=n.avatarUrl,a._saveUserInfo(a.globalData.userInfo),o.setData({userInfo:a.globalData.userInfo}),wx.navigateTo({url:"/pages/change/change"})},fail:function(a){console.log("",a)}})},guanliyuan:function(){wx.navigateTo({url:"/pages/ccadmin/ccadmin"})},tuichu:function(){wx.setStorageSync("user",{}),a.globalData.userInfo={},this.setData({userInfo:{}})},goqiandao:function(){wx.navigateTo({url:"/pages/qiandao/qiandao"})},goRanking:function(){wx.navigateTo({url:"/pages/ranking/ranking"})},goMyError:function(){wx.switchTab({url:"/pages/errorList/errorList"})},change:function(){wx.navigateTo({url:"/pages/change/change"})},goMyCollect:function(){wx.navigateTo({url:"/pages/me/meCollect/myCollect"})},onShareTimeline:function(){return{title:"天美史论1000题",imageUrl:"https://636c-cloud1-8gs7t7f49b4c97d8-1309642353.tcb.qcloud.la/cloudbase-cms/upload/2022-04-24/euhb16l1ane9x0h0m9q7r12rchk95or3_.png"}}});
},{isPage:true,isComponent:true,currentFile:'pages/me/me.js'});require("pages/me/me.js");