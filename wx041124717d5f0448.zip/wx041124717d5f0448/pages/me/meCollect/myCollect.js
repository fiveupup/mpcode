var t = require("../../../@babel/runtime/helpers/regeneratorRuntime"), e = require("../../../@babel/runtime/helpers/asyncToGenerator");

getApp(), wx.cloud.database().command;

Page({
    data: {
        item: "",
        startX: 0,
        startY: 0
    },
    onLoad: function() {
        var a = this;
        return e(t().mark(function e() {
            var c, r, s, o, n;
            return t().wrap(function(t) {
                for (;;) switch (t.prev = t.next) {
                  case 0:
                    return c = wx.cloud.database(), t.next = 3, c.collection("tiku_collects").count();

                  case 3:
                    r = (r = t.sent).total, s = [], o = 0;

                  case 7:
                    if (!(o < r)) {
                        t.next = 15;
                        break;
                    }
                    return t.next = 10, c.collection("tiku_collects").skip(o).get();

                  case 10:
                    n = t.sent, s = s.concat(n.data);

                  case 12:
                    o += 20, t.next = 7;
                    break;

                  case 15:
                    console.log("", s), a.setData({
                        records: s
                    });

                  case 17:
                  case "end":
                    return t.stop();
                }
            }, e);
        }))();
    },
    touchstart: function(t) {
        this.data.records.forEach(function(t, e) {
            t.isTouchMove && (t.isTouchMove = !1);
        }), this.setData({
            startX: t.changedTouches[0].clientX,
            startY: t.changedTouches[0].clientY,
            records: this.data.records
        });
    },
    touchmove: function(t) {
        var e = t.currentTarget.dataset.index, a = this.data.startX, c = this.data.startY, r = t.changedTouches[0].clientX, s = t.changedTouches[0].clientY, o = this.angle({
            X: a,
            Y: c
        }, {
            X: r,
            Y: s
        });
        this.data.records.forEach(function(t, c) {
            t.isTouchMove = !1, Math.abs(o) > 30 || c == e && (t.isTouchMove = !(r > a));
        }), this.setData({
            records: this.data.records
        });
    },
    angle: function(t, e) {
        var a = e.X - t.X, c = e.Y - t.Y;
        return 360 * Math.atan(c / a) / (2 * Math.PI);
    },
    del: function(t) {
        var e = t.currentTarget.dataset.id;
        console.log("hahaha ", e), wx.cloud.database().collection("tiku_collects").doc(e).remove({
            success: function(t) {
                console.log("", t);
            },
            fail: function(t) {
                console.log("", t);
            }
        }), this.data.records.splice(t.currentTarget.dataset.index, 1), this.setData({
            records: this.data.records
        });
    },
    toTiDetail: function(t) {
        console.log(t.currentTarget.dataset.id);
        var e = t.currentTarget.dataset.id;
        wx.navigateTo({
            url: "/pages/shouchangxiangqin/shouchangxiangqin?id=" + e
        });
    }
});