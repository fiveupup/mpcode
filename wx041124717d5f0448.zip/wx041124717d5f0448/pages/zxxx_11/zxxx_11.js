Page({
    data: {},
    onLoad: function(o) {
        console.log(o.id), this.tozxxx_11(o.id);
    },
    tozxxx_11: function(o) {
        var t = this;
        wx.cloud.database().collection("zxxx_").doc(o).get({
            success: function(o) {
                console.log(o), t.setData({
                    banner: o.data
                });
            }
        });
    }
});