$gwx_XC_3=function(_,_v,_n,_p,_s,_wp,_wl,$gwn,$gwl,$gwh,wh,$gstack,$gwrt,gra,grb,TestTest,wfor,_ca,_da,_r,_rz,_o,_oz,_1,_1z,_2,_2z,_m,_mz,nv_getDate,nv_getRegExp,nv_console,nv_parseInt,nv_parseFloat,nv_isNaN,nv_isFinite,nv_decodeURI,nv_decodeURIComponent,nv_encodeURI,nv_encodeURIComponent,$gdc,nv_JSON,_af,_gv,_ai,_grp,_gd,_gapi,$ixc,_ic,_w,_ev,_tsd){return function(path,global){
if(typeof global==='undefined'){if (typeof __GWX_GLOBAL__==='undefined')global={};else global=__GWX_GLOBAL__;}if(typeof __WXML_GLOBAL__ === 'undefined') {__WXML_GLOBAL__={};
}__WXML_GLOBAL__.modules = __WXML_GLOBAL__.modules || {};
var e_={}
if(typeof(global.entrys)==='undefined')global.entrys={};e_=global.entrys;
var d_={}
if(typeof(global.defines)==='undefined')global.defines={};d_=global.defines;
var f_={}
if(typeof(global.modules)==='undefined')global.modules={};f_=global.modules || {};
var p_={}
__WXML_GLOBAL__.ops_cached = __WXML_GLOBAL__.ops_cached || {}
__WXML_GLOBAL__.ops_set = __WXML_GLOBAL__.ops_set || {};
__WXML_GLOBAL__.ops_init = __WXML_GLOBAL__.ops_init || {};
var z=__WXML_GLOBAL__.ops_set.$gwx_XC_3 || [];
function gz$gwx_XC_3_1(){
if( __WXML_GLOBAL__.ops_cached.$gwx_XC_3_1)return __WXML_GLOBAL__.ops_cached.$gwx_XC_3_1
__WXML_GLOBAL__.ops_cached.$gwx_XC_3_1=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
Z([[7],[3,'tiList']])
Z([3,''])
Z([3,'good-box'])
Z([[6],[[7],[3,'item']],[3,'_id']])
Z([3,'formReset'])
Z([3,'formSubmit1'])
Z([3,'tijiao'])
Z([[2,'!'],[[7],[3,'switchAllChecked']]])
Z([[7],[3,'switchAllChecked']])
Z(z[4])
Z([3,'formSubmit'])
Z(z[6])
Z([[2,'!'],[[6],[[7],[3,'item']],[3,'limit']]])
Z([[6],[[7],[3,'item']],[3,'limit']])
})(__WXML_GLOBAL__.ops_cached.$gwx_XC_3_1);return __WXML_GLOBAL__.ops_cached.$gwx_XC_3_1
}
__WXML_GLOBAL__.ops_set.$gwx_XC_3=z;
__WXML_GLOBAL__.ops_init.$gwx_XC_3=true;
var x=['./pages/ccadminuser/ccadminuser.wxml'];d_[x[0]]={}
var m0=function(e,s,r,gg){
var z=gz$gwx_XC_3_1()
var oX=_v()
_(r,oX)
var lY=function(t1,aZ,e2,gg){
var o4=_mz(z,'view',['bindtap',1,'class',1,'data-id',2],[],t1,aZ,gg)
var x5=_mz(z,'form',['catchreset',4,'catchsubmit',1],[],t1,aZ,gg)
var o6=_n('view')
_rz(z,o6,'class',6,t1,aZ,gg)
var f7=_v()
_(o6,f7)
if(_oz(z,7,t1,aZ,gg)){f7.wxVkey=1
}
var c8=_v()
_(o6,c8)
if(_oz(z,8,t1,aZ,gg)){c8.wxVkey=1
}
f7.wxXCkey=1
c8.wxXCkey=1
_(x5,o6)
_(o4,x5)
var h9=_mz(z,'form',['catchreset',9,'catchsubmit',1],[],t1,aZ,gg)
var o0=_n('view')
_rz(z,o0,'class',11,t1,aZ,gg)
var cAB=_v()
_(o0,cAB)
if(_oz(z,12,t1,aZ,gg)){cAB.wxVkey=1
}
var oBB=_v()
_(o0,oBB)
if(_oz(z,13,t1,aZ,gg)){oBB.wxVkey=1
}
cAB.wxXCkey=1
oBB.wxXCkey=1
_(h9,o0)
_(o4,h9)
_(e2,o4)
return e2
}
oX.wxXCkey=2
_2z(z,0,lY,e,s,gg,oX,'item','index','')
return r
}
e_[x[0]]={f:m0,j:[],i:[],ti:[],ic:[]}
if(path&&e_[path]){
return function(env,dd,global){$gwxc=0;var root={"tag":"wx-page"};root.children=[]
;g="$gwx_XC_3";var main=e_[path].f
if (typeof global==="undefined")global={};global.f=$gdc(f_[path],"",1);
try{
main(env,{},root,global);
_tsd(root)
}catch(err){
console.log(err)
}
;g="";
return root;
}
}
}
}(__g.a,__g.b,__g.c,__g.d,__g.e,__g.f,__g.g,__g.h,__g.i,__g.j,__g.k,__g.l,__g.m,__g.n,__g.o,__g.p,__g.q,__g.r,__g.s,__g.t,__g.u,__g.v,__g.w,__g.x,__g.y,__g.z,__g.A,__g.B,__g.C,__g.D,__g.E,__g.F,__g.G,__g.H,__g.I,__g.J,__g.K,__g.L,__g.M,__g.N,__g.O,__g.P,__g.Q,__g.R,__g.S,__g.T,__g.U,__g.V,__g.W,__g.X,__g.Y,__g.Z,__g.aa);if(__vd_version_info__.delayedGwx||false)$gwx_XC_3();	if (__vd_version_info__.delayedGwx) __wxAppCode__['pages/ccadminuser/ccadminuser.wxml'] = [$gwx_XC_3, './pages/ccadminuser/ccadminuser.wxml'];else __wxAppCode__['pages/ccadminuser/ccadminuser.wxml'] = $gwx_XC_3( './pages/ccadminuser/ccadminuser.wxml' );
	;__wxRoute = "pages/ccadminuser/ccadminuser";__wxRouteBegin = true;__wxAppCurrentFile__="pages/ccadminuser/ccadminuser.js";define("pages/ccadminuser/ccadminuser.js",function(require,module,exports,window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){
"use strict";var e=wx.cloud.database(),t=(getApp(),wx.cloud.database().collection("tiku_users"));Page({data:{switchAllChecked:!1},getValue:function(e){console.log(e.detail.value);var t=e.detail.value;this.setData({inputValue:t})},remove:function(t){var o=t.currentTarget.dataset.openid;e.command;wx.cloud.database().collection("tiku_users").doc(o).remove().then((function(e){console.log(e),wx.showToast({title:"取消成功"})}))},search:function(){var t=this;this.setData({switchAllChecked:!1});var o=e.command;wx.cloud.database().collection("tiku_users").where(o.or([{name:wx.cloud.database().RegExp({regexp:this.data.inputValue,options:"i"})},{phone:wx.cloud.database().RegExp({regexp:this.data.inputValue,options:"i"})},{nickName:wx.cloud.database().RegExp({regexp:this.data.inputValue,options:"i"})},{limit:wx.cloud.database().RegExp({regexp:this.data.inputValue,options:"i"})},{baokaotime:wx.cloud.database().RegExp({regexp:this.data.inputValue,options:"i"})}])).get().then((function(e){console.log(e),t.setData({tiList:e.data})}))},formSubmit:function(e){this.setData({switchAllChecked:!1});var o=e.detail.value;console.log(o),o.limit?o.limit&&t.doc(o.openid).update({data:{useless:"无用项目"}}).then((function(o){wx.showModal({title:"提示",content:"确定恢复使用？",success:function(o){if(o.confirm){var a=e.detail.value;t.doc(a.openid).update({data:{limit:""}}),console.log(""),wx.showToast({title:"已恢复"})}else o.cancel&&console.log("")}})})):t.doc(o.openid).update({data:{useless:"无用项目"}}).then((function(o){wx.showModal({title:"提示",content:"确定禁止该用户使用？",success:function(o){if(o.confirm){var a=e.detail.value;t.doc(a.openid).update({data:{limit:"限制"}}),console.log(""),wx.showToast({title:"已禁止"})}else o.cancel&&console.log("")}})}))},change:function(e){this.setData({switchAllChecked:!0})},formSubmit1:function(e){var o=e.detail.value;console.log(o),o.name?o.phone?o&&t.doc(o.openid).update({data:{useless:"无用项目"}}).then((function(e){wx.showModal({title:"提示",content:"确定提交？",success:function(e){e.confirm?(t.doc(o.openid).update({data:{name:o.name,phone:o.phone,openid:o.openid,zhuanye:o.zhuanye}}),console.log(""),wx.showToast({title:"已提交"})):e.cancel&&console.log("")}})})):wx.showToast({icon:"none",title:"请填写电话"}):wx.showToast({icon:"none",title:"请填写姓名"})}});
},{isPage:true,isComponent:true,currentFile:'pages/ccadminuser/ccadminuser.js'});require("pages/ccadminuser/ccadminuser.js");