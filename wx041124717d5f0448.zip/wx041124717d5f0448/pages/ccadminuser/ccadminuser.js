var e = wx.cloud.database(), t = (getApp(), wx.cloud.database().collection("tiku_users"));

Page({
    data: {
        switchAllChecked: !1
    },
    getValue: function(e) {
        console.log(e.detail.value);
        var t = e.detail.value;
        this.setData({
            inputValue: t
        });
    },
    remove: function(t) {
        var o = t.currentTarget.dataset.openid;
        e.command;
        wx.cloud.database().collection("tiku_users").doc(o).remove().then(function(e) {
            console.log(e), wx.showToast({
                title: "取消成功"
            });
        });
    },
    search: function() {
        var t = this;
        this.setData({
            switchAllChecked: !1
        });
        var o = e.command;
        wx.cloud.database().collection("tiku_users").where(o.or([ {
            name: wx.cloud.database().RegExp({
                regexp: this.data.inputValue,
                options: "i"
            })
        }, {
            phone: wx.cloud.database().RegExp({
                regexp: this.data.inputValue,
                options: "i"
            })
        }, {
            nickName: wx.cloud.database().RegExp({
                regexp: this.data.inputValue,
                options: "i"
            })
        }, {
            limit: wx.cloud.database().RegExp({
                regexp: this.data.inputValue,
                options: "i"
            })
        }, {
            baokaotime: wx.cloud.database().RegExp({
                regexp: this.data.inputValue,
                options: "i"
            })
        } ])).get().then(function(e) {
            console.log(e), t.setData({
                tiList: e.data
            });
        });
    },
    formSubmit: function(e) {
        this.setData({
            switchAllChecked: !1
        });
        var o = e.detail.value;
        console.log(o), o.limit ? o.limit && t.doc(o.openid).update({
            data: {
                useless: "无用项目"
            }
        }).then(function(o) {
            wx.showModal({
                title: "提示",
                content: "确定恢复使用？",
                success: function(o) {
                    if (o.confirm) {
                        var a = e.detail.value;
                        t.doc(a.openid).update({
                            data: {
                                limit: ""
                            }
                        }), console.log(""), wx.showToast({
                            title: "已恢复"
                        });
                    } else o.cancel && console.log("");
                }
            });
        }) : t.doc(o.openid).update({
            data: {
                useless: "无用项目"
            }
        }).then(function(o) {
            wx.showModal({
                title: "提示",
                content: "确定禁止该用户使用？",
                success: function(o) {
                    if (o.confirm) {
                        var a = e.detail.value;
                        t.doc(a.openid).update({
                            data: {
                                limit: "限制"
                            }
                        }), console.log(""), wx.showToast({
                            title: "已禁止"
                        });
                    } else o.cancel && console.log("");
                }
            });
        });
    },
    change: function(e) {
        this.setData({
            switchAllChecked: !0
        });
    },
    formSubmit1: function(e) {
        var o = e.detail.value;
        console.log(o), o.name ? o.phone ? o && t.doc(o.openid).update({
            data: {
                useless: "无用项目"
            }
        }).then(function(e) {
            wx.showModal({
                title: "提示",
                content: "确定提交？",
                success: function(e) {
                    e.confirm ? (t.doc(o.openid).update({
                        data: {
                            name: o.name,
                            phone: o.phone,
                            openid: o.openid,
                            zhuanye: o.zhuanye
                        }
                    }), console.log(""), wx.showToast({
                        title: "已提交"
                    })) : e.cancel && console.log("");
                }
            });
        }) : wx.showToast({
            icon: "none",
            title: "请填写电话"
        }) : wx.showToast({
            icon: "none",
            title: "请填写姓名"
        });
    }
});