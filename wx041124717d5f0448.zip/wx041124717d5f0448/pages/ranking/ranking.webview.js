$gwx_XC_17=function(_,_v,_n,_p,_s,_wp,_wl,$gwn,$gwl,$gwh,wh,$gstack,$gwrt,gra,grb,TestTest,wfor,_ca,_da,_r,_rz,_o,_oz,_1,_1z,_2,_2z,_m,_mz,nv_getDate,nv_getRegExp,nv_console,nv_parseInt,nv_parseFloat,nv_isNaN,nv_isFinite,nv_decodeURI,nv_decodeURIComponent,nv_encodeURI,nv_encodeURIComponent,$gdc,nv_JSON,_af,_gv,_ai,_grp,_gd,_gapi,$ixc,_ic,_w,_ev,_tsd){return function(path,global){
if(typeof global==='undefined'){if (typeof __GWX_GLOBAL__==='undefined')global={};else global=__GWX_GLOBAL__;}if(typeof __WXML_GLOBAL__ === 'undefined') {__WXML_GLOBAL__={};
}__WXML_GLOBAL__.modules = __WXML_GLOBAL__.modules || {};
var e_={}
if(typeof(global.entrys)==='undefined')global.entrys={};e_=global.entrys;
var d_={}
if(typeof(global.defines)==='undefined')global.defines={};d_=global.defines;
var f_={}
if(typeof(global.modules)==='undefined')global.modules={};f_=global.modules || {};
var p_={}
__WXML_GLOBAL__.ops_cached = __WXML_GLOBAL__.ops_cached || {}
__WXML_GLOBAL__.ops_set = __WXML_GLOBAL__.ops_set || {};
__WXML_GLOBAL__.ops_init = __WXML_GLOBAL__.ops_init || {};
var z=__WXML_GLOBAL__.ops_set.$gwx_XC_17 || [];
function gz$gwx_XC_17_1(){
if( __WXML_GLOBAL__.ops_cached.$gwx_XC_17_1)return __WXML_GLOBAL__.ops_cached.$gwx_XC_17_1
__WXML_GLOBAL__.ops_cached.$gwx_XC_17_1=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
Z([3,'tip'])
Z([3,'24届刷题榜'])
Z([3,'beijin1'])
Z([[7],[3,'userList']])
Z([3,'index'])
Z([a,[3,'item_root '],[[2,'?:'],[[2,'=='],[[7],[3,'index']],[1,0]],[1,'red'],[1,'']]])
Z([3,'left '])
Z([3,'a111'])
Z([a,[[2,'+'],[[7],[3,'index']],[1,1]],[3,'. ']])
Z([3,'face'])
Z([[6],[[7],[3,'item']],[3,'avatarUrl']])
Z([[2,'!='],[[6],[[7],[3,'item']],[3,'nickName']],[1,'微信用户']])
Z([3,'a1112 '])
Z([a,[[6],[[7],[3,'item']],[3,'nickName']]])
Z([3,''])
Z(z[12])
Z([a,[[6],[[7],[3,'item']],[3,'name']]])
Z([3,'a1113'])
Z([a,[[2,'?:'],[[6],[[7],[3,'item']],[3,'score']],[[6],[[7],[3,'item']],[3,'score']],[1,0]],[3,'分']])
Z([3,'dibu1'])
Z([3,'---'])
Z([[7],[3,'list1']])
Z(z[4])
Z([3,'dibu'])
Z([3,'截止目前'])
Z([3,'dibu2'])
Z([a,[3,' '],[[2,'+'],[[6],[[7],[3,'item']],[3,'num']],[1,8000]]])
Z([3,' 名用户使用过'])
Z([3,'my_item11'])
Z([3,'top_root'])
Z([3,'goQuestions'])
Z([3,'top_btn'])
Z([3,'马上刷题，Go!'])
Z(z[19])
Z([a,z[24],[[6],[[7],[3,'item']],[3,'list']],[3,'名用户使用过']])
Z([3,'item_root'])
Z([[7],[3,'list']])
Z(z[4])
})(__WXML_GLOBAL__.ops_cached.$gwx_XC_17_1);return __WXML_GLOBAL__.ops_cached.$gwx_XC_17_1
}
__WXML_GLOBAL__.ops_set.$gwx_XC_17=z;
__WXML_GLOBAL__.ops_init.$gwx_XC_17=true;
var x=['./pages/ranking/ranking.wxml'];d_[x[0]]={}
var m0=function(e,s,r,gg){
var z=gz$gwx_XC_17_1()
var cY1=_n('view')
var oZ1=_n('view')
_rz(z,oZ1,'class',0,e,s,gg)
var l11=_oz(z,1,e,s,gg)
_(oZ1,l11)
_(cY1,oZ1)
var a21=_n('view')
_rz(z,a21,'class',2,e,s,gg)
var t31=_v()
_(a21,t31)
var e41=function(o61,b51,x71,gg){
var f91=_n('view')
_rz(z,f91,'class',5,o61,b51,gg)
var c01=_n('view')
_rz(z,c01,'class',6,o61,b51,gg)
var oB2=_n('text')
_rz(z,oB2,'class',7,o61,b51,gg)
var cC2=_oz(z,8,o61,b51,gg)
_(oB2,cC2)
_(c01,oB2)
var oD2=_mz(z,'image',['class',9,'src',1],[],o61,b51,gg)
_(c01,oD2)
var hA2=_v()
_(c01,hA2)
if(_oz(z,11,o61,b51,gg)){hA2.wxVkey=1
var lE2=_n('text')
_rz(z,lE2,'class',12,o61,b51,gg)
var aF2=_oz(z,13,o61,b51,gg)
_(lE2,aF2)
_(hA2,lE2)
}
else{hA2.wxVkey=2
var tG2=_n('text')
_rz(z,tG2,'class',15,o61,b51,gg)
var eH2=_oz(z,16,o61,b51,gg)
_(tG2,eH2)
_(hA2,tG2)
}
hA2.wxXCkey=1
_(f91,c01)
var bI2=_n('text')
_rz(z,bI2,'class',17,o61,b51,gg)
var oJ2=_oz(z,18,o61,b51,gg)
_(bI2,oJ2)
_(f91,bI2)
_(x71,f91)
return x71
}
t31.wxXCkey=2
_2z(z,3,e41,e,s,gg,t31,'item','index','index')
var xK2=_n('text')
_rz(z,xK2,'class',19,e,s,gg)
var oL2=_oz(z,20,e,s,gg)
_(xK2,oL2)
_(a21,xK2)
var fM2=_v()
_(a21,fM2)
var cN2=function(oP2,hO2,cQ2,gg){
var lS2=_n('view')
_rz(z,lS2,'class',23,oP2,hO2,gg)
var aT2=_oz(z,24,oP2,hO2,gg)
_(lS2,aT2)
var tU2=_n('text')
_rz(z,tU2,'class',25,oP2,hO2,gg)
var eV2=_oz(z,26,oP2,hO2,gg)
_(tU2,eV2)
_(lS2,tU2)
var bW2=_oz(z,27,oP2,hO2,gg)
_(lS2,bW2)
_(cQ2,lS2)
return cQ2
}
fM2.wxXCkey=2
_2z(z,21,cN2,e,s,gg,fM2,'item','index','index')
var oX2=_n('view')
_rz(z,oX2,'class',28,e,s,gg)
_(a21,oX2)
_(cY1,a21)
_(r,cY1)
var xY2=_n('view')
_rz(z,xY2,'class',29,e,s,gg)
var oZ2=_mz(z,'view',['bindtap',30,'class',1],[],e,s,gg)
var f12=_oz(z,32,e,s,gg)
_(oZ2,f12)
_(xY2,oZ2)
_(r,xY2)
var c22=_n('text')
_rz(z,c22,'class',33,e,s,gg)
var h32=_oz(z,34,e,s,gg)
_(c22,h32)
_(r,c22)
var o42=_n('view')
_rz(z,o42,'class',35,e,s,gg)
var c52=_v()
_(o42,c52)
var o62=function(a82,l72,t92,gg){
return t92
}
c52.wxXCkey=2
_2z(z,36,o62,e,s,gg,c52,'item','index','index')
_(r,o42)
return r
}
e_[x[0]]={f:m0,j:[],i:[],ti:[],ic:[]}
if(path&&e_[path]){
outerGlobal.__wxml_comp_version__=0.02
return function(env,dd,global){$gwxc=0;var root={"tag":"wx-page"};root.children=[]
;g="$gwx_XC_17";var main=e_[path].f
if (typeof global==="undefined")global={};global.f=$gdc(f_[path],"",1);
if(typeof(outerGlobal.__webview_engine_version__)!='undefined'&&outerGlobal.__webview_engine_version__+1e-6>=0.02+1e-6&&outerGlobal.__mergeData__)
{
env=outerGlobal.__mergeData__(env,dd);
}
try{
main(env,{},root,global);
_tsd(root)
if(typeof(outerGlobal.__webview_engine_version__)=='undefined'|| outerGlobal.__webview_engine_version__+1e-6<0.01+1e-6){return _ev(root);}
}catch(err){
console.log(err)
}
;g="";
return root;
}
}
}
}(__g.a,__g.b,__g.c,__g.d,__g.e,__g.f,__g.g,__g.h,__g.i,__g.j,__g.k,__g.l,__g.m,__g.n,__g.o,__g.p,__g.q,__g.r,__g.s,__g.t,__g.u,__g.v,__g.w,__g.x,__g.y,__g.z,__g.A,__g.B,__g.C,__g.D,__g.E,__g.F,__g.G,__g.H,__g.I,__g.J,__g.K,__g.L,__g.M,__g.N,__g.O,__g.P,__g.Q,__g.R,__g.S,__g.T,__g.U,__g.V,__g.W,__g.X,__g.Y,__g.Z,__g.aa);if(__vd_version_info__.delayedGwx||false)$gwx_XC_17();	if (__vd_version_info__.delayedGwx) __wxAppCode__['pages/ranking/ranking.wxml'] = [$gwx_XC_17, './pages/ranking/ranking.wxml'];else __wxAppCode__['pages/ranking/ranking.wxml'] = $gwx_XC_17( './pages/ranking/ranking.wxml' );
	
var noCss=typeof __vd_version_info__!=='undefined'&&__vd_version_info__.noCss===true;if(!noCss){__wxAppCode__['pages/ranking/ranking.wxss'] = setCssToHead([".",[1],"top_root{display:-webkit-flex;display:flex;-webkit-justify-content:center;justify-content:center;margin-top:",[0,60],"}\n.",[1],"beijin1{background:#fff;border-radius:",[0,24],";box-shadow:0 ",[0,4]," ",[0,8]," 0 rgba(0,0,0,.06);margin:0 auto ",[0,24],";overflow:hidden;width:",[0,690],"}\n.",[1],"top_btn{border:",[0,2]," solid #a11;border-radius:",[0,50],";color:#b81919;height:",[0,80],";line-height:",[0,80],";margin:",[0,20],";width:",[0,500],"}\n.",[1],"tip,.",[1],"top_btn{text-align:center}\n.",[1],"tip{color:#cc0f0f;font-size:",[0,46],";margin:",[0,40]," ",[0,20],"}\n.",[1],"red{color:red;color:grey}\n.",[1],"item_root{-webkit-align-items:center;align-items:center;border-bottom:1px solid #dcdcdc;display:-webkit-flex;display:flex;font-size:",[0,32],";-webkit-justify-content:space-between;justify-content:space-between;margin:",[0,20],";padding:",[0,20]," 0}\n.",[1],"face{border-radius:50%;height:",[0,60],";margin-left:",[0,20],";margin-right:",[0,20],";width:",[0,60],"}\n.",[1],"left{-webkit-align-items:center;align-items:center;display:-webkit-flex;display:flex;-webkit-flex-direction:row;flex-direction:row}\n.",[1],"dibu{color:#979797}\n.",[1],"dibu,.",[1],"dibu1{display:-webkit-flex;display:flex;font-size:",[0,24],";height:",[0,60],";-webkit-justify-content:center;justify-content:center}\n.",[1],"dibu1{color:#fff}\n.",[1],"a111{color:#504f4f}\n.",[1],"a111,.",[1],"a1112{font-size:",[0,30],"}\n.",[1],"a1112{color:#797979}\n.",[1],"a1113{font-size:",[0,30],"}\n.",[1],"a1113,.",[1],"dibu2{color:#cc0f0f}\n",],undefined,{path:"./pages/ranking/ranking.wxss"});
}