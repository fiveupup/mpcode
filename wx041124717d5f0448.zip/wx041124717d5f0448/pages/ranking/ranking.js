var t = wx.cloud.database(), e = getApp();

Page({
    onShow: function() {
        var t = this;
        wx.cloud.database().collection("tiku_users").orderBy("score", "desc").get().then(function(e) {
            console.log("", e.data), t.setData({
                userList: e.data
            });
        });
    },
    onLoad: function() {
        var e = this, o = t.command.aggregate;
        t.collection("tiku_users").aggregate().group({
            _id: "$id",
            num: o.sum(1)
        }).end().then(function(t) {
            console.log("", t), e.setData({
                list1: t.list
            });
        });
    },
    goQuestions: function() {
        e.globalData.userInfo && e.globalData.userInfo.name ? wx.switchTab({
            url: "/pages/home/home"
        }) : wx.showModal({
            title: "请先注册",
            content: "注册用户后才可以参与积分排名",
            success: function(t) {
                t.confirm && wx.navigateTo({
                    url: "/pages/change/change"
                });
            }
        });
    },
    onShareAppMessage: function() {
        return {
            title: " ",
            imageUrl: "https://636c-cloud1-8gs7t7f49b4c97d8-1309642353.tcb.qcloud.la/cloudbase-cms/upload/2022-04-24/m936jjv23g0npx2c20s0ldtsgtupfnin_.png"
        };
    },
    onShareTimeline: function() {
        return {
            title: "每天一遍，轻松过线",
            imageUrl: "https://636c-cloud1-8gs7t7f49b4c97d8-1309642353.tcb.qcloud.la/cloudbase-cms/upload/2022-04-24/euhb16l1ane9x0h0m9q7r12rchk95or3_.png"
        };
    }
});