var t = wx.cloud.database(), e = getApp();

Page({
    onLoad: function(t) {
        var a = this;
        wx.cloud.database().collection("tiku_test_results").where({
            testId: t.type,
            _openid: e.globalData.openid
        }).get().then(function(t) {
            console.log(t), a.setData({
                testResult: t.data[0]
            });
        }), wx.setNavigationBarTitle({
            title: t.type + "错题"
        }), this.setData({
            type: t.type
        });
    },
    onShow: function() {
        var e = this;
        console.log("", this.data.type);
        var a = t.command.aggregate;
        t.collection("tiku_test_errors").aggregate().match({
            testId: this.data.type
        }).group({
            _id: "$type2",
            num: a.sum(1)
        }).end().then(function(t) {
            console.log("", t), e.setData({
                list: t.list
            });
        });
    },
    goDetail: function(t) {
        var e = this.data.type, a = t.currentTarget.dataset.type2;
        wx.navigateTo({
            url: "/pages/testErrorQuestions/testErrorQuestions?type1=" + e + "&type2=" + a
        });
    }
});