var t = require("../../@babel/runtime/helpers/objectSpread2"), e = getApp(), a = wx.cloud.database(), o = a.collection("tiku_questions"), s = (wx.cloud.database().collection("tiku_questions"), 
a.collection("ms_sjlx2")), i = a.command, n = [];

Page({
    data: {
        errorOptions: [],
        showAnswer: !1,
        percent: 0,
        total: 0,
        isSelect: !1,
        subject: null,
        userSelect: "",
        userScore: 0,
        totalScore: -1,
        totalError: 0,
        current: 1,
        isShowConfirm: !1,
        shoucang: !1
    },
    onLoad: function(t) {
        this.shuiji(t);
    },
    shuiji: function(t) {
        var a = this;
        if (1 == (i = e.globalData.xztype)) var i = !0; else if (0 == i) i = !1;
        console.log("", t), t.type1 && t.type2 ? (wx.setNavigationBarTitle({
            title: t.type2 + "答题"
        }), o.where({
            type: t.type1,
            type2: t.type2
        }).get().then(function(t) {
            console.log("", t);
            var e = (n = t.data)[0];
            console.log("subject", e), a.setData({
                xztype: i,
                subject: e,
                total: n.length
            });
        })) : (wx.setNavigationBarTitle({
            title: "随机答题"
        }), s.aggregate().sample({
            size: e.globalData.randomNum
        }).end().then(function(t) {
            console.log("", t);
            var e = (n = t.list)[0];
            a.setData({
                xztype: i,
                subject: e,
                total: n.length
            });
        })), console.log(e.globalData.userInfo);
    },
    selectClick: function(t) {
        console.log(t.detail.value), this.setData({
            userSelect: t.detail.value
        });
    },
    submhfghit: function() {
        this.setData({
            showAnswer: !1
        });
        var t = this.data.userSelect;
        if (!t || t.length < 1) wx.showToast({
            icon: "none",
            title: "请做选择"
        }); else {
            var e = this.data.current;
            if (this.setData({
                percent: (e / n.length * 100).toFixed(1)
            }), console.log("用户选项", t), console.log("正确答案", this.data.subject.answer), t instanceof Array && (console.log("是数组"), 
            t = t.sort().toString()), this.data.subject.answer == t) console.log("用户答对了第" + e + "道题"), 
            this.setData({
                userScore: this.data.userScore + 1
            }); else {
                var o = this.data.subject;
                o.userSelect = t, this.data.errorOptions.push(o);
                var s = {};
                Object.assign(s, o), delete s._id;
                var i = wx.getStorageSync("user") || {};
                s.nickName = i && i.nickName ? i.nickName : "未登陆用户", console.log("临时错题", s), a.collection("tiku_errors").add({
                    data: s
                }).then(function(t) {
                    console.log("添加错题到数据库", t);
                }), console.log("错题", o);
            }
            if (e + 1 > n.length) {
                var l = this.data.userScore;
                return console.log("用户一共答对了" + l + "道题"), console.log("用户错题集", this.data.errorOptions), 
                this.setData({
                    totalScore: l,
                    totalError: this.data.errorOptions.length,
                    hideButton: !0
                }), wx.showToast({
                    icon: "none",
                    title: "已经最后一道啦"
                }), void this.addScore(l);
            }
            var c = n[e];
            this.setData({
                userSelect: "",
                subject: c,
                current: e + 1,
                isSelect: !1
            });
        }
    },
    seeEdfhdrror: function() {
        console.log("点击了查看错题集"), wx.switchTab({
            url: "/pages/errorList/errorList"
        });
    },
    addScohhjre: function(t) {
        e.globalData.userInfo && e.globalData.userInfo.name && (console.log(t), a.collection("tiku_users").doc(e.globalData.openid).update({
            data: {
                score: i.inc(t)
            }
        }).then(function(t) {
            wx.showToast({
                title: "积分生效"
            });
        }));
    },
    okjkj: function() {
        var t = this.data.userSelect;
        !t || t.length < 1 ? wx.showToast({
            icon: "none",
            title: "请做选择"
        }) : this.setData({
            showAnswer: !0
        });
    },
    collehshhct: function() {
        var e = this;
        wx.cloud.database().collection("tiku_collects").add({
            data: t({}, this.data.subject)
        }).then(function(t) {
            wx.showToast({
                title: "收藏成功"
            });
        }).catch(function(t) {
            console.log(t), wx.cloud.database().collection("tiku_collects").doc(e.data.subject._id).remove().then(function(t) {
                console.log(t), wx.showToast({
                    title: "取消成功"
                });
            });
        });
    },
    submit: function() {
        wx.showLoading({
            title: "加载中...",
            mask: !0
        });
        var t = e.globalData.xztype;
        this.setData({
            showAnswer: !1
        });
        var o = this.data.userSelect, s = this.data.current;
        if (this.setData({
            percent: (s / n.length * 100).toFixed(1)
        }), console.log("", o), console.log("", this.data.subject.answer), o instanceof Array) console.log(""), 
        o = o; else if (this.data.subject.answer == o) console.log("" + s), this.setData({
            userScore: this.data.userScore + 1
        }); else if (this.data.subject.answer == !o || 0 == o.length) console.log("" + s), 
        this.setData({
            userScore: this.data.userScore + 0
        }); else {
            var i = this.data.subject;
            i.userSelect = o, this.data.errorOptions.push(i);
            var l = {};
            Object.assign(l, i), delete l._id;
            var c = wx.getStorageSync("user") || {};
            l.nickName = c && c.nickName ? c.nickName : "未登陆用户", console.log("", l), a.collection("tiku_errors").add({
                data: l
            }).then(function(t) {
                console.log("", t);
            }), console.log("", i);
        }
        if (s + 1 > n.length) {
            var r = this.data.userScore;
            return console.log("" + r), console.log("", this.data.errorOptions), this.setData({
                totalScore: r,
                totalError: this.data.errorOptions.length,
                hideButton: !0
            }), wx.showToast({
                icon: "none",
                title: "已经最后一道啦"
            }), void this.addScore(r);
        }
        var u = n[s];
        if (0 == t) {
            var h = this;
            setTimeout(function() {
                wx.hideLoading(), h.setData({
                    userSelect: "",
                    subject: u,
                    current: s + 1,
                    isSelect: !1
                });
            }, 4e3);
        } else {
            h = this;
            wx.hideLoading(), h.setData({
                userSelect: "",
                subject: u,
                current: s + 1,
                isSelect: !1
            });
        }
    },
    seeError: function() {
        console.log(""), wx.switchTab({
            url: "/pages/errorList/errorList"
        });
    },
    addScore: function(t) {
        e.globalData.userInfo && e.globalData.userInfo.name && (console.log(t), a.collection("tiku_users").doc(e.globalData.openid).update({
            data: {
                score: i.inc(t)
            }
        }).then(function(t) {
            wx.showToast({
                title: "积分生效"
            });
        }));
    },
    addScoreok: function() {
        if (0 == e.globalData.xztype) {
            wx.showLoading({
                title: "加载中...",
                mask: !0
            });
            var t = this.data.userSelect;
            if (!t || t.length < 1) return void wx.showToast({
                icon: "none",
                title: "请做选择"
            });
            var a = this;
            setTimeout(function() {
                wx.hideLoading(), a.setData({
                    showAnswer: !0
                });
            }, 4e3);
        } else {
            var o = this.data.userSelect;
            if (!o || o.length < 1) return void wx.showToast({
                icon: "none",
                title: "请做选择"
            });
            (a = this).setData({
                showAnswer: !0
            });
        }
    },
    previewImg: function(t) {
        var e = t.currentTarget.dataset.tp;
        wx.previewImage({
            urls: e
        });
    },
    baocuoanniu: function() {
        this.setData({
            isShowConfirm: !0
        });
    },
    getValue: function(t) {
        console.log(t.detail.value);
        var e = t.detail.value;
        this.setData({
            inputValue: e
        });
    },
    selectClick11: function(t) {
        console.log(t.detail.value), this.setData({
            jiucuo: t.detail.value
        });
    },
    formSubmit1: function(t) {
        var e = this, a = t.detail.value;
        wx.cloud.database().collection("tiku_questions").doc(this.data.subject._id).update({
            data: {
                tikuerrors: a.tikuerrors
            }
        }).then(function(t) {
            wx.showToast({
                title: "反馈成功"
            }), e.setData({
                showModalStatus: !1
            });
        });
    },
    collect: function() {
        var t = this;
        wx.cloud.database().collection("tiku_collects").add({
            data: {
                title: this.data.subject.title,
                image: this.data.subject.image,
                explain: this.data.subject.explain,
                answer: this.data.subject.answer,
                optionA: this.data.subject.optionA,
                optionB: this.data.subject.optionB,
                optionC: this.data.subject.optionC,
                optionD: this.data.subject.optionD,
                type: this.data.subject.type,
                type2: this.data.subject.type2
            }
        }).then(function(e) {
            t.setData({
                shoucang: !0
            }), wx.showToast({
                title: "收藏成功"
            });
        });
    },
    collectoff: function() {
        var t = this;
        wx.cloud.database().collection("tiku_collects").where({
            title: wx.cloud.database().RegExp({
                regexp: this.data.subject.title,
                options: "i"
            })
        }).get().then(function(e) {
            console.log("😄嘻嘻哈哈", e);
            var a = e.data[0]._id;
            wx.cloud.database().collection("tiku_collects").doc(a).remove().then(function(e) {
                t.setData({
                    shoucang: !1
                }), console.log(e), wx.showToast({
                    title: "取消成功"
                });
            });
        });
    },
    clickme: function() {
        this.showModal();
    },
    showModal: function() {
        var t = wx.createAnimation({
            duration: 200,
            timingFunction: "linear",
            delay: 0
        });
        this.animation = t, t.translateY(300).step(), this.setData({
            animationData: t.export(),
            showModalStatus: !0
        }), setTimeout(function() {
            t.translateY(0).step(), this.setData({
                animationData: t.export()
            });
        }.bind(this), 200);
    },
    hideModal: function() {
        var t = wx.createAnimation({
            duration: 200,
            timingFunction: "linear",
            delay: 0
        });
        this.animation = t, t.translateY(300).step(), this.setData({
            animationData: t.export()
        }), setTimeout(function() {
            t.translateY(0).step(), this.setData({
                animationData: t.export(),
                showModalStatus: !1
            });
        }.bind(this), 200);
    },
    onShareAppMessage: function() {
        return {
            title: " ",
            imageUrl: "https://636c-cloud1-8gs7t7f49b4c97d8-1309642353.tcb.qcloud.la/cloudbase-cms/upload/2022-04-24/m936jjv23g0npx2c20s0ldtsgtupfnin_.png"
        };
    },
    onShareTimeline: function() {
        return {
            title: "每天一遍，轻松过线",
            imageUrl: "https://636c-cloud1-8gs7t7f49b4c97d8-1309642353.tcb.qcloud.la/cloudbase-cms/upload/2022-04-24/euhb16l1ane9x0h0m9q7r12rchk95or3_.png"
        };
    }
});