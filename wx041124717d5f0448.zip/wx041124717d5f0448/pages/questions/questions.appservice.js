$gwx_XC_16=function(_,_v,_n,_p,_s,_wp,_wl,$gwn,$gwl,$gwh,wh,$gstack,$gwrt,gra,grb,TestTest,wfor,_ca,_da,_r,_rz,_o,_oz,_1,_1z,_2,_2z,_m,_mz,nv_getDate,nv_getRegExp,nv_console,nv_parseInt,nv_parseFloat,nv_isNaN,nv_isFinite,nv_decodeURI,nv_decodeURIComponent,nv_encodeURI,nv_encodeURIComponent,$gdc,nv_JSON,_af,_gv,_ai,_grp,_gd,_gapi,$ixc,_ic,_w,_ev,_tsd){return function(path,global){
if(typeof global==='undefined'){if (typeof __GWX_GLOBAL__==='undefined')global={};else global=__GWX_GLOBAL__;}if(typeof __WXML_GLOBAL__ === 'undefined') {__WXML_GLOBAL__={};
}__WXML_GLOBAL__.modules = __WXML_GLOBAL__.modules || {};
var e_={}
if(typeof(global.entrys)==='undefined')global.entrys={};e_=global.entrys;
var d_={}
if(typeof(global.defines)==='undefined')global.defines={};d_=global.defines;
var f_={}
if(typeof(global.modules)==='undefined')global.modules={};f_=global.modules || {};
var p_={}
__WXML_GLOBAL__.ops_cached = __WXML_GLOBAL__.ops_cached || {}
__WXML_GLOBAL__.ops_set = __WXML_GLOBAL__.ops_set || {};
__WXML_GLOBAL__.ops_init = __WXML_GLOBAL__.ops_init || {};
var z=__WXML_GLOBAL__.ops_set.$gwx_XC_16 || [];
function gz$gwx_XC_16_1(){
if( __WXML_GLOBAL__.ops_cached.$gwx_XC_16_1)return __WXML_GLOBAL__.ops_cached.$gwx_XC_16_1
__WXML_GLOBAL__.ops_cached.$gwx_XC_16_1=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
Z([[7],[3,'xztype']])
Z([[6],[[7],[3,'subject']],[3,'image']])
Z(z[0])
Z([3,'selectClick'])
Z([3,'anniu'])
Z([[6],[[7],[3,'subject']],[3,'optionC']])
Z([[6],[[7],[3,'subject']],[3,'optionD']])
Z(z[3])
Z(z[5])
Z(z[6])
Z([[7],[3,'showAnswer']])
Z([3,'answer-title'])
Z([[2,'!'],[[7],[3,'shoucang']]])
Z([[7],[3,'shoucang']])
Z([3,'collectoff'])
Z(z[13])
Z([[2,'>'],[[7],[3,'totalScore']],[[2,'-'],[1,1]]])
Z([[2,'>'],[[7],[3,'totalError']],[1,0]])
Z([[7],[3,'showModalStatus']])
Z(z[18])
})(__WXML_GLOBAL__.ops_cached.$gwx_XC_16_1);return __WXML_GLOBAL__.ops_cached.$gwx_XC_16_1
}
__WXML_GLOBAL__.ops_set.$gwx_XC_16=z;
__WXML_GLOBAL__.ops_init.$gwx_XC_16=true;
var x=['./pages/questions/questions.wxml'];d_[x[0]]={}
var m0=function(e,s,r,gg){
var z=gz$gwx_XC_16_1()
var oPC=_v()
_(r,oPC)
if(_oz(z,0,e,s,gg)){oPC.wxVkey=1
var oVC=_v()
_(oPC,oVC)
if(_oz(z,1,e,s,gg)){oVC.wxVkey=1
}
oVC.wxXCkey=1
}
var fQC=_v()
_(r,fQC)
if(_oz(z,2,e,s,gg)){fQC.wxVkey=1
var lWC=_mz(z,'radio-group',['bindchange',3,'class',1],[],e,s,gg)
var aXC=_v()
_(lWC,aXC)
if(_oz(z,5,e,s,gg)){aXC.wxVkey=1
}
var tYC=_v()
_(lWC,tYC)
if(_oz(z,6,e,s,gg)){tYC.wxVkey=1
}
aXC.wxXCkey=1
tYC.wxXCkey=1
_(fQC,lWC)
}
else{fQC.wxVkey=2
var eZC=_n('checkbox-group')
_rz(z,eZC,'bindchange',7,e,s,gg)
var b1C=_v()
_(eZC,b1C)
if(_oz(z,8,e,s,gg)){b1C.wxVkey=1
}
var o2C=_v()
_(eZC,o2C)
if(_oz(z,9,e,s,gg)){o2C.wxVkey=1
}
b1C.wxXCkey=1
o2C.wxXCkey=1
_(fQC,eZC)
}
var cRC=_v()
_(r,cRC)
if(_oz(z,10,e,s,gg)){cRC.wxVkey=1
var x3C=_n('view')
_rz(z,x3C,'class',11,e,s,gg)
var o4C=_v()
_(x3C,o4C)
if(_oz(z,12,e,s,gg)){o4C.wxVkey=1
}
var f5C=_v()
_(x3C,f5C)
if(_oz(z,13,e,s,gg)){f5C.wxVkey=1
var c6C=_n('view')
_rz(z,c6C,'bindtap',14,e,s,gg)
var h7C=_v()
_(c6C,h7C)
if(_oz(z,15,e,s,gg)){h7C.wxVkey=1
}
h7C.wxXCkey=1
_(f5C,c6C)
}
o4C.wxXCkey=1
f5C.wxXCkey=1
_(cRC,x3C)
}
var hSC=_v()
_(r,hSC)
if(_oz(z,16,e,s,gg)){hSC.wxVkey=1
var o8C=_v()
_(hSC,o8C)
if(_oz(z,17,e,s,gg)){o8C.wxVkey=1
}
o8C.wxXCkey=1
}
var oTC=_v()
_(r,oTC)
if(_oz(z,18,e,s,gg)){oTC.wxVkey=1
}
var cUC=_v()
_(r,cUC)
if(_oz(z,19,e,s,gg)){cUC.wxVkey=1
}
oPC.wxXCkey=1
fQC.wxXCkey=1
cRC.wxXCkey=1
hSC.wxXCkey=1
oTC.wxXCkey=1
cUC.wxXCkey=1
return r
}
e_[x[0]]={f:m0,j:[],i:[],ti:[],ic:[]}
if(path&&e_[path]){
return function(env,dd,global){$gwxc=0;var root={"tag":"wx-page"};root.children=[]
;g="$gwx_XC_16";var main=e_[path].f
if (typeof global==="undefined")global={};global.f=$gdc(f_[path],"",1);
try{
main(env,{},root,global);
_tsd(root)
}catch(err){
console.log(err)
}
;g="";
return root;
}
}
}
}(__g.a,__g.b,__g.c,__g.d,__g.e,__g.f,__g.g,__g.h,__g.i,__g.j,__g.k,__g.l,__g.m,__g.n,__g.o,__g.p,__g.q,__g.r,__g.s,__g.t,__g.u,__g.v,__g.w,__g.x,__g.y,__g.z,__g.A,__g.B,__g.C,__g.D,__g.E,__g.F,__g.G,__g.H,__g.I,__g.J,__g.K,__g.L,__g.M,__g.N,__g.O,__g.P,__g.Q,__g.R,__g.S,__g.T,__g.U,__g.V,__g.W,__g.X,__g.Y,__g.Z,__g.aa);if(__vd_version_info__.delayedGwx||false)$gwx_XC_16();	if (__vd_version_info__.delayedGwx) __wxAppCode__['pages/questions/questions.wxml'] = [$gwx_XC_16, './pages/questions/questions.wxml'];else __wxAppCode__['pages/questions/questions.wxml'] = $gwx_XC_16( './pages/questions/questions.wxml' );
	;__wxRoute = "pages/questions/questions";__wxRouteBegin = true;__wxAppCurrentFile__="pages/questions/questions.js";define("pages/questions/questions.js",function(require,module,exports,window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){
"use strict";var t=require("../../@babel/runtime/helpers/objectSpread2"),e=getApp(),a=wx.cloud.database(),o=a.collection("tiku_questions"),s=(wx.cloud.database().collection("tiku_questions"),a.collection("ms_sjlx2")),i=a.command,n=[];Page({data:{errorOptions:[],showAnswer:!1,percent:0,total:0,isSelect:!1,subject:null,userSelect:"",userScore:0,totalScore:-1,totalError:0,current:1,isShowConfirm:!1,shoucang:!1},onLoad:function(t){this.shuiji(t)},shuiji:function(t){var a=this;if(1==(i=e.globalData.xztype))var i=!0;else if(0==i)i=!1;console.log("",t),t.type1&&t.type2?(wx.setNavigationBarTitle({title:t.type2+"答题"}),o.where({type:t.type1,type2:t.type2}).get().then((function(t){console.log("",t);var e=(n=t.data)[0];console.log("subject",e),a.setData({xztype:i,subject:e,total:n.length})}))):(wx.setNavigationBarTitle({title:"随机答题"}),s.aggregate().sample({size:e.globalData.randomNum}).end().then((function(t){console.log("",t);var e=(n=t.list)[0];a.setData({xztype:i,subject:e,total:n.length})}))),console.log(e.globalData.userInfo)},selectClick:function(t){console.log(t.detail.value),this.setData({userSelect:t.detail.value})},submhfghit:function(){this.setData({showAnswer:!1});var t=this.data.userSelect;if(!t||t.length<1)wx.showToast({icon:"none",title:"请做选择"});else{var e=this.data.current;if(this.setData({percent:(e/n.length*100).toFixed(1)}),console.log("用户选项",t),console.log("正确答案",this.data.subject.answer),t instanceof Array&&(console.log("是数组"),t=t.sort().toString()),this.data.subject.answer==t)console.log("用户答对了第"+e+"道题"),this.setData({userScore:this.data.userScore+1});else{var o=this.data.subject;o.userSelect=t,this.data.errorOptions.push(o);var s={};Object.assign(s,o),delete s._id;var i=wx.getStorageSync("user")||{};s.nickName=i&&i.nickName?i.nickName:"未登陆用户",console.log("临时错题",s),a.collection("tiku_errors").add({data:s}).then((function(t){console.log("添加错题到数据库",t)})),console.log("错题",o)}if(e+1>n.length){var l=this.data.userScore;return console.log("用户一共答对了"+l+"道题"),console.log("用户错题集",this.data.errorOptions),this.setData({totalScore:l,totalError:this.data.errorOptions.length,hideButton:!0}),wx.showToast({icon:"none",title:"已经最后一道啦"}),void this.addScore(l)}var c=n[e];this.setData({userSelect:"",subject:c,current:e+1,isSelect:!1})}},seeEdfhdrror:function(){console.log("点击了查看错题集"),wx.switchTab({url:"/pages/errorList/errorList"})},addScohhjre:function(t){e.globalData.userInfo&&e.globalData.userInfo.name&&(console.log(t),a.collection("tiku_users").doc(e.globalData.openid).update({data:{score:i.inc(t)}}).then((function(t){wx.showToast({title:"积分生效"})})))},okjkj:function(){var t=this.data.userSelect;!t||t.length<1?wx.showToast({icon:"none",title:"请做选择"}):this.setData({showAnswer:!0})},collehshhct:function(){var e=this;wx.cloud.database().collection("tiku_collects").add({data:t({},this.data.subject)}).then((function(t){wx.showToast({title:"收藏成功"})})).catch((function(t){console.log(t),wx.cloud.database().collection("tiku_collects").doc(e.data.subject._id).remove().then((function(t){console.log(t),wx.showToast({title:"取消成功"})}))}))},submit:function(){wx.showLoading({title:"加载中...",mask:!0});var t=e.globalData.xztype;this.setData({showAnswer:!1});var o=this.data.userSelect,s=this.data.current;if(this.setData({percent:(s/n.length*100).toFixed(1)}),console.log("",o),console.log("",this.data.subject.answer),o instanceof Array)console.log(""),o=o;else if(this.data.subject.answer==o)console.log(""+s),this.setData({userScore:this.data.userScore+1});else if(this.data.subject.answer==!o||0==o.length)console.log(""+s),this.setData({userScore:this.data.userScore+0});else{var i=this.data.subject;i.userSelect=o,this.data.errorOptions.push(i);var l={};Object.assign(l,i),delete l._id;var c=wx.getStorageSync("user")||{};l.nickName=c&&c.nickName?c.nickName:"未登陆用户",console.log("",l),a.collection("tiku_errors").add({data:l}).then((function(t){console.log("",t)})),console.log("",i)}if(s+1>n.length){var r=this.data.userScore;return console.log(""+r),console.log("",this.data.errorOptions),this.setData({totalScore:r,totalError:this.data.errorOptions.length,hideButton:!0}),wx.showToast({icon:"none",title:"已经最后一道啦"}),void this.addScore(r)}var u=n[s];if(0==t){var h=this;setTimeout((function(){wx.hideLoading(),h.setData({userSelect:"",subject:u,current:s+1,isSelect:!1})}),4e3)}else{h=this;wx.hideLoading(),h.setData({userSelect:"",subject:u,current:s+1,isSelect:!1})}},seeError:function(){console.log(""),wx.switchTab({url:"/pages/errorList/errorList"})},addScore:function(t){e.globalData.userInfo&&e.globalData.userInfo.name&&(console.log(t),a.collection("tiku_users").doc(e.globalData.openid).update({data:{score:i.inc(t)}}).then((function(t){wx.showToast({title:"积分生效"})})))},addScoreok:function(){if(0==e.globalData.xztype){wx.showLoading({title:"加载中...",mask:!0});var t=this.data.userSelect;if(!t||t.length<1)return void wx.showToast({icon:"none",title:"请做选择"});var a=this;setTimeout((function(){wx.hideLoading(),a.setData({showAnswer:!0})}),4e3)}else{var o=this.data.userSelect;if(!o||o.length<1)return void wx.showToast({icon:"none",title:"请做选择"});(a=this).setData({showAnswer:!0})}},previewImg:function(t){var e=t.currentTarget.dataset.tp;wx.previewImage({urls:e})},baocuoanniu:function(){this.setData({isShowConfirm:!0})},getValue:function(t){console.log(t.detail.value);var e=t.detail.value;this.setData({inputValue:e})},selectClick11:function(t){console.log(t.detail.value),this.setData({jiucuo:t.detail.value})},formSubmit1:function(t){var e=this,a=t.detail.value;wx.cloud.database().collection("tiku_questions").doc(this.data.subject._id).update({data:{tikuerrors:a.tikuerrors}}).then((function(t){wx.showToast({title:"反馈成功"}),e.setData({showModalStatus:!1})}))},collect:function(){var t=this;wx.cloud.database().collection("tiku_collects").add({data:{title:this.data.subject.title,image:this.data.subject.image,explain:this.data.subject.explain,answer:this.data.subject.answer,optionA:this.data.subject.optionA,optionB:this.data.subject.optionB,optionC:this.data.subject.optionC,optionD:this.data.subject.optionD,type:this.data.subject.type,type2:this.data.subject.type2}}).then((function(e){t.setData({shoucang:!0}),wx.showToast({title:"收藏成功"})}))},collectoff:function(){var t=this;wx.cloud.database().collection("tiku_collects").where({title:wx.cloud.database().RegExp({regexp:this.data.subject.title,options:"i"})}).get().then((function(e){console.log("😄嘻嘻哈哈",e);var a=e.data[0]._id;wx.cloud.database().collection("tiku_collects").doc(a).remove().then((function(e){t.setData({shoucang:!1}),console.log(e),wx.showToast({title:"取消成功"})}))}))},clickme:function(){this.showModal()},showModal:function(){var t=wx.createAnimation({duration:200,timingFunction:"linear",delay:0});this.animation=t,t.translateY(300).step(),this.setData({animationData:t.export(),showModalStatus:!0}),setTimeout(function(){t.translateY(0).step(),this.setData({animationData:t.export()})}.bind(this),200)},hideModal:function(){var t=wx.createAnimation({duration:200,timingFunction:"linear",delay:0});this.animation=t,t.translateY(300).step(),this.setData({animationData:t.export()}),setTimeout(function(){t.translateY(0).step(),this.setData({animationData:t.export(),showModalStatus:!1})}.bind(this),200)},onShareAppMessage:function(){return{title:" ",imageUrl:"https://636c-cloud1-8gs7t7f49b4c97d8-1309642353.tcb.qcloud.la/cloudbase-cms/upload/2022-04-24/m936jjv23g0npx2c20s0ldtsgtupfnin_.png"}},onShareTimeline:function(){return{title:"每天一遍，轻松过线",imageUrl:"https://636c-cloud1-8gs7t7f49b4c97d8-1309642353.tcb.qcloud.la/cloudbase-cms/upload/2022-04-24/euhb16l1ane9x0h0m9q7r12rchk95or3_.png"}}});
},{isPage:true,isComponent:true,currentFile:'pages/questions/questions.js'});require("pages/questions/questions.js");