$gwx_XC_4=function(_,_v,_n,_p,_s,_wp,_wl,$gwn,$gwl,$gwh,wh,$gstack,$gwrt,gra,grb,TestTest,wfor,_ca,_da,_r,_rz,_o,_oz,_1,_1z,_2,_2z,_m,_mz,nv_getDate,nv_getRegExp,nv_console,nv_parseInt,nv_parseFloat,nv_isNaN,nv_isFinite,nv_decodeURI,nv_decodeURIComponent,nv_encodeURI,nv_encodeURIComponent,$gdc,nv_JSON,_af,_gv,_ai,_grp,_gd,_gapi,$ixc,_ic,_w,_ev,_tsd){return function(path,global){
if(typeof global==='undefined'){if (typeof __GWX_GLOBAL__==='undefined')global={};else global=__GWX_GLOBAL__;}if(typeof __WXML_GLOBAL__ === 'undefined') {__WXML_GLOBAL__={};
}__WXML_GLOBAL__.modules = __WXML_GLOBAL__.modules || {};
var e_={}
if(typeof(global.entrys)==='undefined')global.entrys={};e_=global.entrys;
var d_={}
if(typeof(global.defines)==='undefined')global.defines={};d_=global.defines;
var f_={}
if(typeof(global.modules)==='undefined')global.modules={};f_=global.modules || {};
var p_={}
__WXML_GLOBAL__.ops_cached = __WXML_GLOBAL__.ops_cached || {}
__WXML_GLOBAL__.ops_set = __WXML_GLOBAL__.ops_set || {};
__WXML_GLOBAL__.ops_init = __WXML_GLOBAL__.ops_init || {};
var z=__WXML_GLOBAL__.ops_set.$gwx_XC_4 || [];
function gz$gwx_XC_4_1(){
if( __WXML_GLOBAL__.ops_cached.$gwx_XC_4_1)return __WXML_GLOBAL__.ops_cached.$gwx_XC_4_1
__WXML_GLOBAL__.ops_cached.$gwx_XC_4_1=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
Z([3,'onChooseAvatar'])
Z([3,'buttonavatar'])
Z([3,'chooseAvatar'])
Z([[2,'&&'],[[7],[3,'userInfo']],[[6],[[7],[3,'userInfo']],[3,'avatarUrl']]])
})(__WXML_GLOBAL__.ops_cached.$gwx_XC_4_1);return __WXML_GLOBAL__.ops_cached.$gwx_XC_4_1
}
__WXML_GLOBAL__.ops_set.$gwx_XC_4=z;
__WXML_GLOBAL__.ops_init.$gwx_XC_4=true;
var x=['./pages/change/change.wxml'];d_[x[0]]={}
var m0=function(e,s,r,gg){
var z=gz$gwx_XC_4_1()
var aDB=_mz(z,'button',['bind:chooseavatar',0,'class',1,'openType',1],[],e,s,gg)
var tEB=_v()
_(aDB,tEB)
if(_oz(z,3,e,s,gg)){tEB.wxVkey=1
}
tEB.wxXCkey=1
_(r,aDB)
return r
}
e_[x[0]]={f:m0,j:[],i:[],ti:[],ic:[]}
if(path&&e_[path]){
return function(env,dd,global){$gwxc=0;var root={"tag":"wx-page"};root.children=[]
;g="$gwx_XC_4";var main=e_[path].f
if (typeof global==="undefined")global={};global.f=$gdc(f_[path],"",1);
try{
main(env,{},root,global);
_tsd(root)
}catch(err){
console.log(err)
}
;g="";
return root;
}
}
}
}(__g.a,__g.b,__g.c,__g.d,__g.e,__g.f,__g.g,__g.h,__g.i,__g.j,__g.k,__g.l,__g.m,__g.n,__g.o,__g.p,__g.q,__g.r,__g.s,__g.t,__g.u,__g.v,__g.w,__g.x,__g.y,__g.z,__g.A,__g.B,__g.C,__g.D,__g.E,__g.F,__g.G,__g.H,__g.I,__g.J,__g.K,__g.L,__g.M,__g.N,__g.O,__g.P,__g.Q,__g.R,__g.S,__g.T,__g.U,__g.V,__g.W,__g.X,__g.Y,__g.Z,__g.aa);if(__vd_version_info__.delayedGwx||false)$gwx_XC_4();	if (__vd_version_info__.delayedGwx) __wxAppCode__['pages/change/change.wxml'] = [$gwx_XC_4, './pages/change/change.wxml'];else __wxAppCode__['pages/change/change.wxml'] = $gwx_XC_4( './pages/change/change.wxml' );
	;__wxRoute = "pages/change/change";__wxRouteBegin = true;__wxAppCurrentFile__="pages/change/change.js";define("pages/change/change.js",function(require,module,exports,window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){
"use strict";var a,t=require("../../@babel/runtime/helpers/defineProperty"),o=getApp(),e=wx.cloud.database().collection("tiku_users"),n="";Page((t(a={data:{baokaotime:"2023届",avatarUrl:"https://mmbiz.qpic.cn/mmbiz/icTdbqWNOwNRna42FI242Lcia07jQodd2FJGIYQfG0LAJGFxM4FbnQP6yfMxBgJ0F3YRqJCJ1aPAK2dQagdusBZg/0",userInfo:null},onChooseAvatar:function(a){var t=a.detail.avatarUrl;this.setData({avatarUrl:t,"userInfo.avatarUrl":t}),console.log(this.data.avatarUrl,n),this.upload(t)},upload:function(a){e.doc(n).update({data:{"userInfo.avatarUrl":a}}).then((function(a){wx.showToast({title:"添加成功",icon:"success",duration:2e3})}))},onShow:function(a){var t=o.globalData.userInfo;console.log("",t),t&&t.nickName?this.setData({userInfo:t}):this.setData({userInfo:wx.getStorageSync("user")})}},"data",{user:null}),t(a,"onLoad",(function(a){console.log("",o.globalData.openid),n=o.globalData.openid,this.getUserInfo()})),t(a,"getUserInfo",(function(){var a=this;e.doc(n).get().then((function(t){console.log("",t),a.setData({user:t.data})})).catch((function(t){wx.showToast({icon:"error",title:"还未注册用户"}),console.log(""),a.setData({user:null})}))})),t(a,"formSubmit",(function(a){var t=this,l=a.detail.value,r=a.detail.value.phone,i=o.globalData.userInfo;console.log(l),"https://thirdwx.qlogo.cn/mmopen/vi_32/POgEwh4mIHO4nibH0KlMECNjjGxQUq24ZEaGT4poC6icRiccVGKSyXwibcPq4BWmiaIGuG1icwxaQX6grC9VemZoJ8rg/132"==i.avatarUrl?wx.showToast({icon:"none",title:"请选择头像"}):l.name?r?l.zhuanye?(this.data.user&&this.data.user.name?e.doc(n).update({data:{name:l.name,phone:l.phone,zhuanye:l.zhuanye,nickName:l.name,avatarUrl:o.globalData.userInfo.avatarUrl,limit:l.limit,baokaotime:"2024届"}}).then((function(a){o.globalData.userInfo.nickName=l.name,t.savaStudent(l),wx.showToast({title:"更新成功"})})):e.add({data:{_id:n,name:l.name,limit:l.limit,phone:l.phone,zhuanye:l.zhuanye,nickName:l.name,baokaotime:"2024届",avatarUrl:o.globalData.userInfo.avatarUrl,score:0,isAuth:0}}).then((function(a){o.globalData.userInfo.nickName=l.name,t.savaStudent(l),wx.showToast({title:"提交成功"})})),o.globalData.userInfo.nickName=l.name,wx.switchTab({url:"/pages/home/home"})):wx.showToast({icon:"none",title:"专业"}):wx.showToast({icon:"none",title:"请填写电话"}):wx.showToast({icon:"none",title:"请填写姓名"})})),t(a,"savaStudent",(function(a){o.globalData.userInfo.limit=a.limit,o.globalData.userInfo.name=a.name,o.globalData.userInfo.score=a.score,o.globalData.userInfo.zhuanye=a.zhuanye,o.globalData.userInfo.xuehao=a.xuehao,o.globalData.userInfo.kahao=a.kahao,o.globalData.userInfo.yuanxi=a.yuanxi,o._saveUserInfo(o.globalData.userInfo)})),t(a,"data",{multiArray:[["国画学院","造型学院","设计类","实验学院","理论类"],["花鸟","山水","人物","书法","修复坚定"]],multiIndex:[0,0],arrColumn0:["花鸟","山水","人物","书法","修复坚定"],arrColumn1:["油画","版画","壁画","雕塑","造型基础"],arrColumn2:["视觉传达","工艺美术","设计基础","室内设计","环境设计","公共艺术","服装设计","染织设计","产品设计"],arrColumn3:["综合艺术","跨媒体","动画","摄影","数字媒体"],arrColumn4:["艺术学理论","艺术设计学"]}),t(a,"PickerChange",(function(a){var t=a.detail.value;this.setData({multiIndex:t}),console.log(this.data.multiArray[0][t[0]],this.data.multiArray[1][t[1]],this.data.multiArray[2][t[2]],this.data.multiArray[3][t[3]],this.data.multiArray[4][t[4]])})),t(a,"PickerColumnChange",(function(a){var t=a.detail,o=this.data.multiArray;0==t.column&&0==t.value&&(o[1]=this.data.arrColumn0),0==t.column&&1==t.value&&(o[1]=this.data.arrColumn1),0==t.column&&2==t.value&&(o[1]=this.data.arrColumn2),0==t.column&&3==t.value&&(o[1]=this.data.arrColumn3),0==t.column&&4==t.value&&(o[1]=this.data.arrColumn4),this.setData({multiArray:o})})),a));
},{isPage:true,isComponent:true,currentFile:'pages/change/change.js'});require("pages/change/change.js");