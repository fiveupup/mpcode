$gwx_XC_4=function(_,_v,_n,_p,_s,_wp,_wl,$gwn,$gwl,$gwh,wh,$gstack,$gwrt,gra,grb,TestTest,wfor,_ca,_da,_r,_rz,_o,_oz,_1,_1z,_2,_2z,_m,_mz,nv_getDate,nv_getRegExp,nv_console,nv_parseInt,nv_parseFloat,nv_isNaN,nv_isFinite,nv_decodeURI,nv_decodeURIComponent,nv_encodeURI,nv_encodeURIComponent,$gdc,nv_JSON,_af,_gv,_ai,_grp,_gd,_gapi,$ixc,_ic,_w,_ev,_tsd){return function(path,global){
if(typeof global==='undefined'){if (typeof __GWX_GLOBAL__==='undefined')global={};else global=__GWX_GLOBAL__;}if(typeof __WXML_GLOBAL__ === 'undefined') {__WXML_GLOBAL__={};
}__WXML_GLOBAL__.modules = __WXML_GLOBAL__.modules || {};
var e_={}
if(typeof(global.entrys)==='undefined')global.entrys={};e_=global.entrys;
var d_={}
if(typeof(global.defines)==='undefined')global.defines={};d_=global.defines;
var f_={}
if(typeof(global.modules)==='undefined')global.modules={};f_=global.modules || {};
var p_={}
__WXML_GLOBAL__.ops_cached = __WXML_GLOBAL__.ops_cached || {}
__WXML_GLOBAL__.ops_set = __WXML_GLOBAL__.ops_set || {};
__WXML_GLOBAL__.ops_init = __WXML_GLOBAL__.ops_init || {};
var z=__WXML_GLOBAL__.ops_set.$gwx_XC_4 || [];
function gz$gwx_XC_4_1(){
if( __WXML_GLOBAL__.ops_cached.$gwx_XC_4_1)return __WXML_GLOBAL__.ops_cached.$gwx_XC_4_1
__WXML_GLOBAL__.ops_cached.$gwx_XC_4_1=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
Z([3,'onChooseAvatar'])
Z([3,'buttonavatar'])
Z([3,'chooseAvatar'])
Z([[2,'&&'],[[7],[3,'userInfo']],[[6],[[7],[3,'userInfo']],[3,'avatarUrl']]])
Z([3,'header'])
Z([3,'userinfo-avatar'])
Z([[6],[[7],[3,'userInfo']],[3,'avatarUrl']])
Z([3,'userinfo-nickname'])
Z([a,[[6],[[7],[3,'userInfo']],[3,'nickName']]])
Z([3,'beijin1'])
Z([3,'formReset'])
Z([3,'formSubmit'])
Z([3,'tip'])
Z([3,'tip1'])
Z([3,'*'])
Z([3,'姓名'])
Z([3,'name'])
Z([3,'请输入用户名'])
Z([3,'nickname'])
Z([[6],[[7],[3,'user']],[3,'name']])
Z(z[12])
Z(z[13])
Z(z[14])
Z([3,'电话'])
Z([3,'phone'])
Z([3,'请输入电话'])
Z([3,'number'])
Z([[6],[[7],[3,'user']],[3,'phone']])
Z(z[12])
Z([3,'tip2'])
Z(z[14])
Z([3,'专业'])
Z([3,'input1'])
Z([3,'PickerChange'])
Z([3,'PickerColumnChange'])
Z([3,'multiSelector'])
Z([[7],[3,'multiArray']])
Z([[6],[[7],[3,'user']],[3,'zhuanye']])
Z([a,[[6],[[6],[[7],[3,'multiArray']],[1,0]],[[6],[[7],[3,'multiIndex']],[1,0]]],[3,'-'],[[6],[[6],[[7],[3,'multiArray']],[1,1]],[[6],[[7],[3,'multiIndex']],[1,1]]],[3,' ']])
Z([3,'input2'])
Z([3,'zhuanye'])
Z([a,[3,' '],[[6],[[6],[[7],[3,'multiArray']],[1,0]],[[6],[[7],[3,'multiIndex']],[1,0]]],[3,'-'],[[6],[[6],[[7],[3,'multiArray']],[1,1]],[[6],[[7],[3,'multiIndex']],[1,1]]],[3,'    ']])
Z([3,'tijiao'])
Z([3,'button1'])
Z([3,'submit'])
Z([3,'提交'])
})(__WXML_GLOBAL__.ops_cached.$gwx_XC_4_1);return __WXML_GLOBAL__.ops_cached.$gwx_XC_4_1
}
__WXML_GLOBAL__.ops_set.$gwx_XC_4=z;
__WXML_GLOBAL__.ops_init.$gwx_XC_4=true;
var x=['./pages/change/change.wxml'];d_[x[0]]={}
var m0=function(e,s,r,gg){
var z=gz$gwx_XC_4_1()
var t7I=_mz(z,'button',['bind:chooseavatar',0,'class',1,'openType',1],[],e,s,gg)
var e8I=_v()
_(t7I,e8I)
if(_oz(z,3,e,s,gg)){e8I.wxVkey=1
var b9I=_n('view')
_rz(z,b9I,'class',4,e,s,gg)
var o0I=_mz(z,'image',['class',5,'src',1],[],e,s,gg)
_(b9I,o0I)
var xAJ=_n('text')
_rz(z,xAJ,'class',7,e,s,gg)
var oBJ=_oz(z,8,e,s,gg)
_(xAJ,oBJ)
_(b9I,xAJ)
_(e8I,b9I)
}
e8I.wxXCkey=1
_(r,t7I)
var fCJ=_n('view')
_rz(z,fCJ,'class',9,e,s,gg)
var cDJ=_mz(z,'form',['catchreset',10,'catchsubmit',1],[],e,s,gg)
var hEJ=_n('text')
_rz(z,hEJ,'class',12,e,s,gg)
var oFJ=_n('text')
_rz(z,oFJ,'class',13,e,s,gg)
var cGJ=_oz(z,14,e,s,gg)
_(oFJ,cGJ)
_(hEJ,oFJ)
var oHJ=_oz(z,15,e,s,gg)
_(hEJ,oHJ)
_(cDJ,hEJ)
var lIJ=_mz(z,'input',['name',16,'placeholder',1,'type',2,'value',3],[],e,s,gg)
_(cDJ,lIJ)
var aJJ=_n('view')
var tKJ=_n('text')
_rz(z,tKJ,'class',20,e,s,gg)
var eLJ=_n('text')
_rz(z,eLJ,'class',21,e,s,gg)
var bMJ=_oz(z,22,e,s,gg)
_(eLJ,bMJ)
_(tKJ,eLJ)
var oNJ=_oz(z,23,e,s,gg)
_(tKJ,oNJ)
_(aJJ,tKJ)
var xOJ=_mz(z,'input',['name',24,'placeholder',1,'type',2,'value',3],[],e,s,gg)
_(aJJ,xOJ)
_(cDJ,aJJ)
var oPJ=_n('view')
var fQJ=_n('text')
_rz(z,fQJ,'class',28,e,s,gg)
var cRJ=_n('text')
_rz(z,cRJ,'class',29,e,s,gg)
var hSJ=_oz(z,30,e,s,gg)
_(cRJ,hSJ)
_(fQJ,cRJ)
var oTJ=_oz(z,31,e,s,gg)
_(fQJ,oTJ)
_(oPJ,fQJ)
_(cDJ,oPJ)
var cUJ=_n('view')
_rz(z,cUJ,'class',32,e,s,gg)
var oVJ=_mz(z,'picker',['bindchange',33,'bindcolumnchange',1,'mode',2,'range',3,'value',4],[],e,s,gg)
var lWJ=_oz(z,38,e,s,gg)
_(oVJ,lWJ)
_(cUJ,oVJ)
_(cDJ,cUJ)
var aXJ=_mz(z,'input',['class',39,'name',1,'value',2],[],e,s,gg)
_(cDJ,aXJ)
var tYJ=_n('view')
_rz(z,tYJ,'class',42,e,s,gg)
var eZJ=_mz(z,'button',['class',43,'formType',1],[],e,s,gg)
var b1J=_oz(z,45,e,s,gg)
_(eZJ,b1J)
_(tYJ,eZJ)
_(cDJ,tYJ)
_(fCJ,cDJ)
_(r,fCJ)
return r
}
e_[x[0]]={f:m0,j:[],i:[],ti:[],ic:[]}
if(path&&e_[path]){
outerGlobal.__wxml_comp_version__=0.02
return function(env,dd,global){$gwxc=0;var root={"tag":"wx-page"};root.children=[]
;g="$gwx_XC_4";var main=e_[path].f
if (typeof global==="undefined")global={};global.f=$gdc(f_[path],"",1);
if(typeof(outerGlobal.__webview_engine_version__)!='undefined'&&outerGlobal.__webview_engine_version__+1e-6>=0.02+1e-6&&outerGlobal.__mergeData__)
{
env=outerGlobal.__mergeData__(env,dd);
}
try{
main(env,{},root,global);
_tsd(root)
if(typeof(outerGlobal.__webview_engine_version__)=='undefined'|| outerGlobal.__webview_engine_version__+1e-6<0.01+1e-6){return _ev(root);}
}catch(err){
console.log(err)
}
;g="";
return root;
}
}
}
}(__g.a,__g.b,__g.c,__g.d,__g.e,__g.f,__g.g,__g.h,__g.i,__g.j,__g.k,__g.l,__g.m,__g.n,__g.o,__g.p,__g.q,__g.r,__g.s,__g.t,__g.u,__g.v,__g.w,__g.x,__g.y,__g.z,__g.A,__g.B,__g.C,__g.D,__g.E,__g.F,__g.G,__g.H,__g.I,__g.J,__g.K,__g.L,__g.M,__g.N,__g.O,__g.P,__g.Q,__g.R,__g.S,__g.T,__g.U,__g.V,__g.W,__g.X,__g.Y,__g.Z,__g.aa);if(__vd_version_info__.delayedGwx||false)$gwx_XC_4();	if (__vd_version_info__.delayedGwx) __wxAppCode__['pages/change/change.wxml'] = [$gwx_XC_4, './pages/change/change.wxml'];else __wxAppCode__['pages/change/change.wxml'] = $gwx_XC_4( './pages/change/change.wxml' );
	
var noCss=typeof __vd_version_info__!=='undefined'&&__vd_version_info__.noCss===true;if(!noCss){__wxAppCode__['pages/change/change.wxss'] = setCssToHead(["body{margin-top:",[0,20],"}\n.",[1],"buttonavatar{-webkit-margin-after:",[0,50],";background:#fff;height:auto;margin-block-end:",[0,50],";width:auto}\n.",[1],"beijin1{background:#fff;border-radius:",[0,24],";box-shadow:0 ",[0,4]," ",[0,8]," 0 rgba(0,0,0,.06);margin:0 auto ",[0,24],";overflow:hidden;width:",[0,690],"}\nwx-input{border:1px solid gray;border-radius:",[0,10],";margin:",[0,30]," ",[0,40],";padding:",[0,20]," ",[0,10],"}\n.",[1],"zhuangyezujian{display:-webkit-flex;display:flex;-webkit-justify-content:space-between;justify-content:space-between}\n.",[1],"input1{border:1px solid gray;border-radius:",[0,10],";margin:",[0,30]," ",[0,40],";padding:",[0,20]," ",[0,10],"}\n.",[1],"input2{border:1px solid #fff;color:#fff;font-size:",[0,2],";height:",[0,1],";width:",[0,1],"}\n.",[1],"qsl{width:100%}\n.",[1],"qsl,.",[1],"qsl1{border:1px solid #fff;height:100%}\n.",[1],"qsl1{width:50%}\n.",[1],"tip{color:gray;margin:",[0,20]," ",[0,40],"}\n.",[1],"tip1,.",[1],"tip2{color:#a11}\n.",[1],"button1{border:",[0,2]," solid #a11;border-radius:",[0,50],";color:#b81919;height:",[0,80],";line-height:",[0,80],";margin:",[0,20],";text-align:center;width:",[0,500],"}\n.",[1],"red-block{height:",[0,24],";position:relative;width:",[0,40],"}\n.",[1],"tijiao{-webkit-align-items:center;align-items:center;display:-webkit-flex;display:flex;-webkit-justify-content:center;justify-content:center}\n.",[1],"tip.",[1],"writebg{height:100%;left:0;position:absolute;top:0;width:100%;z-index:1}\n.",[1],"header{-webkit-align-items:center;align-items:center;background:#fff;display:-webkit-flex;display:flex;-webkit-flex-direction:column;flex-direction:column;margin:0 auto ",[0,24],";overflow:hidden;width:100%;width:",[0,690],"}\n.",[1],"userinfo-avatar{-webkit-margin-before:10px;border-radius:",[0,128],";height:",[0,150],";margin-block-start:10px;width:",[0,150],"}\n.",[1],"userinfo-nickname{color:gray;font-size:",[0,38],";margin-top:",[0,20],"}\n",],"Some selectors are not allowed in component wxss, including tag name selectors, ID selectors, and attribute selectors.(./pages/change/change.wxss:1:261)",{path:"./pages/change/change.wxss"});
}