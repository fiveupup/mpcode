var t = require("../../../@babel/runtime/helpers/defineProperty");

Page({
    data: {},
    onLoad: function(r) {
        console.log(r), this.setData(t({
            totalScore: r.totalScore,
            totalError: r.totalError,
            testTimeMin: r.testTimeMin,
            testTimeSec: r.testTimeSec
        }, "totalError", r.totalError));
    },
    seeError: function() {
        console.log(""), wx.switchTab({
            url: "/pages/errorList/errorList"
        });
    }
});