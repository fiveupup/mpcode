$gwx_XC_20=function(_,_v,_n,_p,_s,_wp,_wl,$gwn,$gwl,$gwh,wh,$gstack,$gwrt,gra,grb,TestTest,wfor,_ca,_da,_r,_rz,_o,_oz,_1,_1z,_2,_2z,_m,_mz,nv_getDate,nv_getRegExp,nv_console,nv_parseInt,nv_parseFloat,nv_isNaN,nv_isFinite,nv_decodeURI,nv_decodeURIComponent,nv_encodeURI,nv_encodeURIComponent,$gdc,nv_JSON,_af,_gv,_ai,_grp,_gd,_gapi,$ixc,_ic,_w,_ev,_tsd){return function(path,global){
if(typeof global==='undefined'){if (typeof __GWX_GLOBAL__==='undefined')global={};else global=__GWX_GLOBAL__;}if(typeof __WXML_GLOBAL__ === 'undefined') {__WXML_GLOBAL__={};
}__WXML_GLOBAL__.modules = __WXML_GLOBAL__.modules || {};
var e_={}
if(typeof(global.entrys)==='undefined')global.entrys={};e_=global.entrys;
var d_={}
if(typeof(global.defines)==='undefined')global.defines={};d_=global.defines;
var f_={}
if(typeof(global.modules)==='undefined')global.modules={};f_=global.modules || {};
var p_={}
__WXML_GLOBAL__.ops_cached = __WXML_GLOBAL__.ops_cached || {}
__WXML_GLOBAL__.ops_set = __WXML_GLOBAL__.ops_set || {};
__WXML_GLOBAL__.ops_init = __WXML_GLOBAL__.ops_init || {};
var z=__WXML_GLOBAL__.ops_set.$gwx_XC_20 || [];
function gz$gwx_XC_20_1(){
if( __WXML_GLOBAL__.ops_cached.$gwx_XC_20_1)return __WXML_GLOBAL__.ops_cached.$gwx_XC_20_1
__WXML_GLOBAL__.ops_cached.$gwx_XC_20_1=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
Z([[2,'=='],[[6],[[6],[[7],[3,'subject']],[3,'answer']],[3,'length']],[1,1]])
Z([3,'selectClick'])
Z([[6],[[7],[3,'subject']],[3,'optionC']])
Z([[6],[[7],[3,'subject']],[3,'optionD']])
Z(z[1])
Z(z[2])
Z(z[3])
Z([[7],[3,'showAnswer']])
})(__WXML_GLOBAL__.ops_cached.$gwx_XC_20_1);return __WXML_GLOBAL__.ops_cached.$gwx_XC_20_1
}
__WXML_GLOBAL__.ops_set.$gwx_XC_20=z;
__WXML_GLOBAL__.ops_init.$gwx_XC_20=true;
var x=['./pages/test/test.wxml'];d_[x[0]]={}
var m0=function(e,s,r,gg){
var z=gz$gwx_XC_20_1()
var t5D=_v()
_(r,t5D)
if(_oz(z,0,e,s,gg)){t5D.wxVkey=1
var b7D=_n('radio-group')
_rz(z,b7D,'bindchange',1,e,s,gg)
var o8D=_v()
_(b7D,o8D)
if(_oz(z,2,e,s,gg)){o8D.wxVkey=1
}
var x9D=_v()
_(b7D,x9D)
if(_oz(z,3,e,s,gg)){x9D.wxVkey=1
}
o8D.wxXCkey=1
x9D.wxXCkey=1
_(t5D,b7D)
}
else{t5D.wxVkey=2
var o0D=_n('checkbox-group')
_rz(z,o0D,'bindchange',4,e,s,gg)
var fAE=_v()
_(o0D,fAE)
if(_oz(z,5,e,s,gg)){fAE.wxVkey=1
}
var cBE=_v()
_(o0D,cBE)
if(_oz(z,6,e,s,gg)){cBE.wxVkey=1
}
fAE.wxXCkey=1
cBE.wxXCkey=1
_(t5D,o0D)
}
var e6D=_v()
_(r,e6D)
if(_oz(z,7,e,s,gg)){e6D.wxVkey=1
}
t5D.wxXCkey=1
e6D.wxXCkey=1
return r
}
e_[x[0]]={f:m0,j:[],i:[],ti:[],ic:[]}
if(path&&e_[path]){
return function(env,dd,global){$gwxc=0;var root={"tag":"wx-page"};root.children=[]
;g="$gwx_XC_20";var main=e_[path].f
if (typeof global==="undefined")global={};global.f=$gdc(f_[path],"",1);
try{
main(env,{},root,global);
_tsd(root)
}catch(err){
console.log(err)
}
;g="";
return root;
}
}
}
}(__g.a,__g.b,__g.c,__g.d,__g.e,__g.f,__g.g,__g.h,__g.i,__g.j,__g.k,__g.l,__g.m,__g.n,__g.o,__g.p,__g.q,__g.r,__g.s,__g.t,__g.u,__g.v,__g.w,__g.x,__g.y,__g.z,__g.A,__g.B,__g.C,__g.D,__g.E,__g.F,__g.G,__g.H,__g.I,__g.J,__g.K,__g.L,__g.M,__g.N,__g.O,__g.P,__g.Q,__g.R,__g.S,__g.T,__g.U,__g.V,__g.W,__g.X,__g.Y,__g.Z,__g.aa);if(__vd_version_info__.delayedGwx||false)$gwx_XC_20();	if (__vd_version_info__.delayedGwx) __wxAppCode__['pages/test/test.wxml'] = [$gwx_XC_20, './pages/test/test.wxml'];else __wxAppCode__['pages/test/test.wxml'] = $gwx_XC_20( './pages/test/test.wxml' );
	;__wxRoute = "pages/test/test";__wxRouteBegin = true;__wxAppCurrentFile__="pages/test/test.js";define("pages/test/test.js",function(require,module,exports,window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){
"use strict";var t=getApp(),e=wx.cloud.database(),a=e.collection("tiku_exams"),s=require("../../utils/util"),o=e.command,i=[];Page({data:{hour:"00",minute:"00",second:"00",showScore:!1,testTime:0,errorOptions:[],showAnswer:!1,percent:0,total:0,isSelect:!1,subject:null,userSelect:"",userScore:0,totalScore:0,totalError:0,current:1},onLoad:function(e){var o=this;this.time60(),console.log("",e),e.type1&&e.type2?(wx.setNavigationBarTitle({title:e.type2+"答题"}),a.where({type:e.type1,type2:e.type2}).get().then((function(t){console.log("",t);var e=(i=t.data)[0];console.log("",e),o.setData({subject:e,total:i.length}),o.setData({testId:s.formatTime(new Date)+o.data.subject.type+"考试"})}))):(wx.setNavigationBarTitle({title:"随机答题"}),a.aggregate().sample({size:t.globalData.randomNum}).end().then((function(t){console.log("",t);var e=(i=t.list)[0];o.setData({subject:e,total:i.length}),o.setData({testId:s.formatTime(new Date)+o.data.subject.type+"考试"})}))),t.globalData.userInfo&&t.globalData.userInfo.name||wx.showModal({title:"需要参加积分排名吗？",content:"只有授权登陆并注册用户后才可以参与积分排名，取消后本次答题不计入积分排行里",success:function(t){t.confirm&&wx.switchTab({url:"/pages/me/me"})}})},selectClick:function(t){console.log(t.detail.value),this.setData({userSelect:t.detail.value})},submit:function(){this.setData({showAnswer:!1});var t=this.data.userSelect;if(!t||t.length<1)wx.showToast({icon:"none",title:"请做选择"});else{var a=this.data.current;if(this.setData({percent:(a/i.length*100).toFixed(1)}),console.log("",t),console.log("",this.data.subject.answer),t instanceof Array&&(console.log(""),t=t.sort().toString()),this.data.subject.answer==t)console.log(""+a),this.setData({userScore:this.data.userScore+1});else{var s=this.data.subject;s.userSelect=t,this.data.errorOptions.push(s);var o={};Object.assign(o,s),delete o._id;var n=wx.getStorageSync("user")||{};o.nickName=n&&n.nickName?n.nickName:"未登陆用户",console.log("",o),o.testId=this.data.testId,e.collection("tiku_test_errors").add({data:o}).then((function(t){console.log("",t)})),console.log("",s)}if(a+1>i.length){var r=this.data.userScore;return console.log(""+r),console.log("",this.data.errorOptions),this.setData({totalScore:r,totalError:this.data.errorOptions.length,hideButton:!0}),void wx.showToast({icon:"none",title:"已经最后一道啦"})}var l=i[a];this.setData({userSelect:"",subject:l,current:a+1,isSelect:!1})}},seeError:function(){console.log(""),wx.switchTab({url:"/pages/errorList/errorList"})},addScore:function(a){t.globalData.userInfo&&t.globalData.userInfo.name&&e.collection("tiku_users").doc(t.globalData.openid).update({data:{score:o.inc(a)}}).then((function(t){wx.showToast({title:"积分生效"})}))},ok:function(){var t=this.data.userSelect;!t||t.length<1?wx.showToast({icon:"none",title:"请做选择"}):this.setData({showAnswer:!0})},testEnd:function(){var e=this,a=this.data.userSelect;!a||a.length<1?wx.showToast({icon:"none",title:"请做选择"}):(wx.showLoading({title:"提交中",mask:!0}),this.setData({showScore:!0,testTimeMin:this.data.testTimeMin,testTimeSec:this.data.testTimeSec}),this.addScore(this.data.totalScore),clearInterval(this.data.timeInterval),wx.cloud.database().collection("tiku_test_results").add({data:{faceImg:t.globalData.userInfo.avatarUrl,nickName:t.globalData.userInfo.nickName,testId:this.data.testId,time:this.data.testTimeMin+"分"+this.data.testTimeSec+"秒",totalError:this.data.totalError,total:this.data.total}}).then((function(t){wx.hideLoading({success:function(t){wx.showToast({title:"成功"}),wx.redirectTo({url:"/pages/test/testResult/testResult?totalError="+e.data.totalError+"&testTimeMin="+e.data.testTimeMin+"&testTimeSec="+e.data.testTimeSec+"&totalScore="+e.data.totalScore})}})})))},time60:function(){var t=this,e=new Date;e.setMinutes(e.getMinutes()+90);var a=s.formatTime(e);console.log(a);var o=setInterval((function(){var e=new Date(a)-new Date;t.setData({hour:parseInt(e/60/1e3/60),minute:parseInt(e/60/1e3)-60*parseInt(e/60/1e3/60),second:parseInt(e/1e3)-60*(parseInt(e/60/1e3)-60*parseInt(e/60/1e3/60))-60*parseInt(e/60/1e3/60)*60}),t.setData({testTime:t.data.testTime+1}),t.setData({testTime:t.data.testTime,testTimeMin:parseInt(t.data.testTime/60),testTimeSec:t.data.testTime-60*t.data.testTimeMin})}),1e3);this.setData({timeInterval:o})}});
},{isPage:true,isComponent:true,currentFile:'pages/test/test.js'});require("pages/test/test.js");