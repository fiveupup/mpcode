var t = getApp(), e = wx.cloud.database(), a = e.collection("tiku_exams"), s = require("../../utils/util"), o = e.command, i = [];

Page({
    data: {
        hour: "00",
        minute: "00",
        second: "00",
        showScore: !1,
        testTime: 0,
        errorOptions: [],
        showAnswer: !1,
        percent: 0,
        total: 0,
        isSelect: !1,
        subject: null,
        userSelect: "",
        userScore: 0,
        totalScore: 0,
        totalError: 0,
        current: 1
    },
    onLoad: function(e) {
        var o = this;
        this.time60(), console.log("", e), e.type1 && e.type2 ? (wx.setNavigationBarTitle({
            title: e.type2 + "答题"
        }), a.where({
            type: e.type1,
            type2: e.type2
        }).get().then(function(t) {
            console.log("", t);
            var e = (i = t.data)[0];
            console.log("", e), o.setData({
                subject: e,
                total: i.length
            }), o.setData({
                testId: s.formatTime(new Date()) + o.data.subject.type + "考试"
            });
        })) : (wx.setNavigationBarTitle({
            title: "随机答题"
        }), a.aggregate().sample({
            size: t.globalData.randomNum
        }).end().then(function(t) {
            console.log("", t);
            var e = (i = t.list)[0];
            o.setData({
                subject: e,
                total: i.length
            }), o.setData({
                testId: s.formatTime(new Date()) + o.data.subject.type + "考试"
            });
        })), t.globalData.userInfo && t.globalData.userInfo.name || wx.showModal({
            title: "需要参加积分排名吗？",
            content: "只有授权登陆并注册用户后才可以参与积分排名，取消后本次答题不计入积分排行里",
            success: function(t) {
                t.confirm && wx.switchTab({
                    url: "/pages/me/me"
                });
            }
        });
    },
    selectClick: function(t) {
        console.log(t.detail.value), this.setData({
            userSelect: t.detail.value
        });
    },
    submit: function() {
        this.setData({
            showAnswer: !1
        });
        var t = this.data.userSelect;
        if (!t || t.length < 1) wx.showToast({
            icon: "none",
            title: "请做选择"
        }); else {
            var a = this.data.current;
            if (this.setData({
                percent: (a / i.length * 100).toFixed(1)
            }), console.log("", t), console.log("", this.data.subject.answer), t instanceof Array && (console.log(""), 
            t = t.sort().toString()), this.data.subject.answer == t) console.log("" + a), this.setData({
                userScore: this.data.userScore + 1
            }); else {
                var s = this.data.subject;
                s.userSelect = t, this.data.errorOptions.push(s);
                var o = {};
                Object.assign(o, s), delete o._id;
                var n = wx.getStorageSync("user") || {};
                o.nickName = n && n.nickName ? n.nickName : "未登陆用户", console.log("", o), o.testId = this.data.testId, 
                e.collection("tiku_test_errors").add({
                    data: o
                }).then(function(t) {
                    console.log("", t);
                }), console.log("", s);
            }
            if (a + 1 > i.length) {
                var r = this.data.userScore;
                return console.log("" + r), console.log("", this.data.errorOptions), this.setData({
                    totalScore: r,
                    totalError: this.data.errorOptions.length,
                    hideButton: !0
                }), void wx.showToast({
                    icon: "none",
                    title: "已经最后一道啦"
                });
            }
            var l = i[a];
            this.setData({
                userSelect: "",
                subject: l,
                current: a + 1,
                isSelect: !1
            });
        }
    },
    seeError: function() {
        console.log(""), wx.switchTab({
            url: "/pages/errorList/errorList"
        });
    },
    addScore: function(a) {
        t.globalData.userInfo && t.globalData.userInfo.name && e.collection("tiku_users").doc(t.globalData.openid).update({
            data: {
                score: o.inc(a)
            }
        }).then(function(t) {
            wx.showToast({
                title: "积分生效"
            });
        });
    },
    ok: function() {
        var t = this.data.userSelect;
        !t || t.length < 1 ? wx.showToast({
            icon: "none",
            title: "请做选择"
        }) : this.setData({
            showAnswer: !0
        });
    },
    testEnd: function() {
        var e = this, a = this.data.userSelect;
        !a || a.length < 1 ? wx.showToast({
            icon: "none",
            title: "请做选择"
        }) : (wx.showLoading({
            title: "提交中",
            mask: !0
        }), this.setData({
            showScore: !0,
            testTimeMin: this.data.testTimeMin,
            testTimeSec: this.data.testTimeSec
        }), this.addScore(this.data.totalScore), clearInterval(this.data.timeInterval), 
        wx.cloud.database().collection("tiku_test_results").add({
            data: {
                faceImg: t.globalData.userInfo.avatarUrl,
                nickName: t.globalData.userInfo.nickName,
                testId: this.data.testId,
                time: this.data.testTimeMin + "分" + this.data.testTimeSec + "秒",
                totalError: this.data.totalError,
                total: this.data.total
            }
        }).then(function(t) {
            wx.hideLoading({
                success: function(t) {
                    wx.showToast({
                        title: "成功"
                    }), wx.redirectTo({
                        url: "/pages/test/testResult/testResult?totalError=" + e.data.totalError + "&testTimeMin=" + e.data.testTimeMin + "&testTimeSec=" + e.data.testTimeSec + "&totalScore=" + e.data.totalScore
                    });
                }
            });
        }));
    },
    time60: function() {
        var t = this, e = new Date();
        e.setMinutes(e.getMinutes() + 90);
        var a = s.formatTime(e);
        console.log(a);
        var o = setInterval(function() {
            var e = new Date(a) - new Date();
            t.setData({
                hour: parseInt(e / 60 / 1e3 / 60),
                minute: parseInt(e / 60 / 1e3) - 60 * parseInt(e / 60 / 1e3 / 60),
                second: parseInt(e / 1e3) - 60 * (parseInt(e / 60 / 1e3) - 60 * parseInt(e / 60 / 1e3 / 60)) - 60 * parseInt(e / 60 / 1e3 / 60) * 60
            }), t.setData({
                testTime: t.data.testTime + 1
            }), t.setData({
                testTime: t.data.testTime,
                testTimeMin: parseInt(t.data.testTime / 60),
                testTimeSec: t.data.testTime - 60 * t.data.testTimeMin
            });
        }, 1e3);
        this.setData({
            timeInterval: o
        });
    }
});