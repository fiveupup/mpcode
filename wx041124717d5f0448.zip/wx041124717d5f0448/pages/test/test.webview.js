$gwx_XC_20=function(_,_v,_n,_p,_s,_wp,_wl,$gwn,$gwl,$gwh,wh,$gstack,$gwrt,gra,grb,TestTest,wfor,_ca,_da,_r,_rz,_o,_oz,_1,_1z,_2,_2z,_m,_mz,nv_getDate,nv_getRegExp,nv_console,nv_parseInt,nv_parseFloat,nv_isNaN,nv_isFinite,nv_decodeURI,nv_decodeURIComponent,nv_encodeURI,nv_encodeURIComponent,$gdc,nv_JSON,_af,_gv,_ai,_grp,_gd,_gapi,$ixc,_ic,_w,_ev,_tsd){return function(path,global){
if(typeof global==='undefined'){if (typeof __GWX_GLOBAL__==='undefined')global={};else global=__GWX_GLOBAL__;}if(typeof __WXML_GLOBAL__ === 'undefined') {__WXML_GLOBAL__={};
}__WXML_GLOBAL__.modules = __WXML_GLOBAL__.modules || {};
var e_={}
if(typeof(global.entrys)==='undefined')global.entrys={};e_=global.entrys;
var d_={}
if(typeof(global.defines)==='undefined')global.defines={};d_=global.defines;
var f_={}
if(typeof(global.modules)==='undefined')global.modules={};f_=global.modules || {};
var p_={}
__WXML_GLOBAL__.ops_cached = __WXML_GLOBAL__.ops_cached || {}
__WXML_GLOBAL__.ops_set = __WXML_GLOBAL__.ops_set || {};
__WXML_GLOBAL__.ops_init = __WXML_GLOBAL__.ops_init || {};
var z=__WXML_GLOBAL__.ops_set.$gwx_XC_20 || [];
function gz$gwx_XC_20_1(){
if( __WXML_GLOBAL__.ops_cached.$gwx_XC_20_1)return __WXML_GLOBAL__.ops_cached.$gwx_XC_20_1
__WXML_GLOBAL__.ops_cached.$gwx_XC_20_1=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
Z([3,'tip'])
Z([a,[3,'第'],[[7],[3,'current']],[3,'题/共'],[[7],[3,'total']],[3,'题']])
Z([3,'time'])
Z([a,[3,'剩余时间：'],[[7],[3,'hour']],[3,':'],[[7],[3,'minute']],[3,':'],[[7],[3,'second']]])
Z([3,'30'])
Z([3,'pro'])
Z([[7],[3,'percent']])
Z([3,'10'])
Z([3,'type'])
Z([3,' 题型： '])
Z([[2,'=='],[[6],[[6],[[7],[3,'subject']],[3,'answer']],[3,'length']],[1,1]])
Z([3,'单选/判断题'])
Z([[2,'>'],[[6],[[6],[[7],[3,'subject']],[3,'answer']],[3,'length']],[1,1]])
Z([3,'多选题'])
Z([3,'ti-type'])
Z([a,[3,'类型：'],[[6],[[7],[3,'subject']],[3,'type2']]])
Z([3,'ti-title'])
Z([a,[3,'题目：'],[[6],[[7],[3,'subject']],[3,'title']]])
Z(z[10])
Z([3,'selectClick'])
Z([3,'item'])
Z([[7],[3,'isSelect']])
Z([3,'A'])
Z([a,[3,'A:'],[[6],[[7],[3,'subject']],[3,'optionA']]])
Z(z[20])
Z(z[21])
Z([3,'B'])
Z([a,[3,'B:'],[[6],[[7],[3,'subject']],[3,'optionB']]])
Z([[6],[[7],[3,'subject']],[3,'optionC']])
Z(z[20])
Z(z[21])
Z([3,'C'])
Z([a,[3,'C:'],[[6],[[7],[3,'subject']],[3,'optionC']]])
Z([[6],[[7],[3,'subject']],[3,'optionD']])
Z(z[20])
Z(z[21])
Z([3,'D'])
Z([a,[3,'D:'],[[6],[[7],[3,'subject']],[3,'optionD']]])
Z(z[19])
Z(z[20])
Z(z[21])
Z(z[22])
Z([a,z[23][1],z[23][2]])
Z(z[20])
Z(z[21])
Z(z[26])
Z([a,z[27][1],z[27][2]])
Z(z[28])
Z(z[20])
Z(z[21])
Z(z[31])
Z([a,z[32][1],z[32][2]])
Z(z[33])
Z(z[20])
Z(z[21])
Z(z[36])
Z([a,z[37][1],z[37][2]])
Z([[7],[3,'showAnswer']])
Z([3,'ok'])
Z([3,'你的答案：'])
Z([[7],[3,'userSelect']])
Z([a,[[7],[3,'item']],[3,'  ']])
Z(z[58])
Z([3,'正确答案：'])
Z([[6],[[7],[3,'subject']],[3,'answer']])
Z([a,z[61][1],z[61][2]])
Z(z[58])
Z([3,'解析：'])
Z([a,[[6],[[7],[3,'subject']],[3,'explain']]])
Z([3,'submit'])
Z([3,'but'])
Z([[7],[3,'hideButton']])
Z([3,'primary'])
Z([3,'下一题'])
Z([3,'testEnd'])
Z(z[70])
Z([3,'提交'])
})(__WXML_GLOBAL__.ops_cached.$gwx_XC_20_1);return __WXML_GLOBAL__.ops_cached.$gwx_XC_20_1
}
__WXML_GLOBAL__.ops_set.$gwx_XC_20=z;
__WXML_GLOBAL__.ops_init.$gwx_XC_20=true;
var x=['./pages/test/test.wxml'];d_[x[0]]={}
var m0=function(e,s,r,gg){
var z=gz$gwx_XC_20_1()
var a89=_n('view')
_rz(z,a89,'class',0,e,s,gg)
var t99=_oz(z,1,e,s,gg)
_(a89,t99)
_(r,a89)
var e09=_n('view')
_rz(z,e09,'class',2,e,s,gg)
var bA0=_oz(z,3,e,s,gg)
_(e09,bA0)
_(r,e09)
var oB0=_mz(z,'progress',['showInfo',-1,'borderRadius',4,'class',1,'percent',2,'strokeWidth',3],[],e,s,gg)
_(r,oB0)
var xC0=_n('view')
_rz(z,xC0,'class',8,e,s,gg)
var fE0=_oz(z,9,e,s,gg)
_(xC0,fE0)
var oD0=_v()
_(xC0,oD0)
if(_oz(z,10,e,s,gg)){oD0.wxVkey=1
var cF0=_n('text')
var hG0=_oz(z,11,e,s,gg)
_(cF0,hG0)
_(oD0,cF0)
}
else if(_oz(z,12,e,s,gg)){oD0.wxVkey=2
var oH0=_n('text')
var cI0=_oz(z,13,e,s,gg)
_(oH0,cI0)
_(oD0,oH0)
}
oD0.wxXCkey=1
_(r,xC0)
var oJ0=_n('view')
_rz(z,oJ0,'class',14,e,s,gg)
var lK0=_oz(z,15,e,s,gg)
_(oJ0,lK0)
_(r,oJ0)
var aL0=_n('view')
_rz(z,aL0,'class',16,e,s,gg)
var tM0=_oz(z,17,e,s,gg)
_(aL0,tM0)
_(r,aL0)
var o69=_v()
_(r,o69)
if(_oz(z,18,e,s,gg)){o69.wxVkey=1
var eN0=_n('radio-group')
_rz(z,eN0,'bindchange',19,e,s,gg)
var xQ0=_n('view')
_rz(z,xQ0,'class',20,e,s,gg)
var oR0=_mz(z,'radio',['checked',21,'value',1],[],e,s,gg)
_(xQ0,oR0)
var fS0=_n('text')
var cT0=_oz(z,23,e,s,gg)
_(fS0,cT0)
_(xQ0,fS0)
_(eN0,xQ0)
var hU0=_n('view')
_rz(z,hU0,'class',24,e,s,gg)
var oV0=_mz(z,'radio',['checked',25,'value',1],[],e,s,gg)
_(hU0,oV0)
var cW0=_n('text')
var oX0=_oz(z,27,e,s,gg)
_(cW0,oX0)
_(hU0,cW0)
_(eN0,hU0)
var bO0=_v()
_(eN0,bO0)
if(_oz(z,28,e,s,gg)){bO0.wxVkey=1
var lY0=_n('view')
_rz(z,lY0,'class',29,e,s,gg)
var aZ0=_mz(z,'radio',['checked',30,'value',1],[],e,s,gg)
_(lY0,aZ0)
var t10=_n('text')
var e20=_oz(z,32,e,s,gg)
_(t10,e20)
_(lY0,t10)
_(bO0,lY0)
}
var oP0=_v()
_(eN0,oP0)
if(_oz(z,33,e,s,gg)){oP0.wxVkey=1
var b30=_n('view')
_rz(z,b30,'class',34,e,s,gg)
var o40=_mz(z,'radio',['checked',35,'value',1],[],e,s,gg)
_(b30,o40)
var x50=_n('text')
var o60=_oz(z,37,e,s,gg)
_(x50,o60)
_(b30,x50)
_(oP0,b30)
}
bO0.wxXCkey=1
oP0.wxXCkey=1
_(o69,eN0)
}
else{o69.wxVkey=2
var f70=_n('checkbox-group')
_rz(z,f70,'bindchange',38,e,s,gg)
var o00=_n('view')
_rz(z,o00,'class',39,e,s,gg)
var cAAB=_mz(z,'checkbox',['checked',40,'value',1],[],e,s,gg)
_(o00,cAAB)
var oBAB=_n('text')
var lCAB=_oz(z,42,e,s,gg)
_(oBAB,lCAB)
_(o00,oBAB)
_(f70,o00)
var aDAB=_n('view')
_rz(z,aDAB,'class',43,e,s,gg)
var tEAB=_mz(z,'checkbox',['checked',44,'value',1],[],e,s,gg)
_(aDAB,tEAB)
var eFAB=_n('text')
var bGAB=_oz(z,46,e,s,gg)
_(eFAB,bGAB)
_(aDAB,eFAB)
_(f70,aDAB)
var c80=_v()
_(f70,c80)
if(_oz(z,47,e,s,gg)){c80.wxVkey=1
var oHAB=_n('view')
_rz(z,oHAB,'class',48,e,s,gg)
var xIAB=_mz(z,'checkbox',['checked',49,'value',1],[],e,s,gg)
_(oHAB,xIAB)
var oJAB=_n('text')
var fKAB=_oz(z,51,e,s,gg)
_(oJAB,fKAB)
_(oHAB,oJAB)
_(c80,oHAB)
}
var h90=_v()
_(f70,h90)
if(_oz(z,52,e,s,gg)){h90.wxVkey=1
var cLAB=_n('view')
_rz(z,cLAB,'class',53,e,s,gg)
var hMAB=_mz(z,'checkbox',['checked',54,'value',1],[],e,s,gg)
_(cLAB,hMAB)
var oNAB=_n('text')
var cOAB=_oz(z,56,e,s,gg)
_(oNAB,cOAB)
_(cLAB,oNAB)
_(h90,cLAB)
}
c80.wxXCkey=1
h90.wxXCkey=1
_(o69,f70)
}
var l79=_v()
_(r,l79)
if(_oz(z,57,e,s,gg)){l79.wxVkey=1
var oPAB=_n('view')
_rz(z,oPAB,'class',58,e,s,gg)
var lQAB=_n('view')
var aRAB=_oz(z,59,e,s,gg)
_(lQAB,aRAB)
_(oPAB,lQAB)
var tSAB=_v()
_(oPAB,tSAB)
var eTAB=function(oVAB,bUAB,xWAB,gg){
var fYAB=_n('text')
var cZAB=_oz(z,61,oVAB,bUAB,gg)
_(fYAB,cZAB)
_(xWAB,fYAB)
return xWAB
}
tSAB.wxXCkey=2
_2z(z,60,eTAB,e,s,gg,tSAB,'item','index','')
_(l79,oPAB)
var h1AB=_n('view')
_rz(z,h1AB,'class',62,e,s,gg)
var o2AB=_n('view')
var c3AB=_oz(z,63,e,s,gg)
_(o2AB,c3AB)
_(h1AB,o2AB)
var o4AB=_v()
_(h1AB,o4AB)
var l5AB=function(t7AB,a6AB,e8AB,gg){
var o0AB=_n('text')
var xABB=_oz(z,65,t7AB,a6AB,gg)
_(o0AB,xABB)
_(e8AB,o0AB)
return e8AB
}
o4AB.wxXCkey=2
_2z(z,64,l5AB,e,s,gg,o4AB,'item','index','')
_(l79,h1AB)
var oBBB=_n('view')
_rz(z,oBBB,'class',66,e,s,gg)
var fCBB=_n('view')
var cDBB=_oz(z,67,e,s,gg)
_(fCBB,cDBB)
_(oBBB,fCBB)
var hEBB=_n('view')
var oFBB=_oz(z,68,e,s,gg)
_(hEBB,oFBB)
_(oBBB,hEBB)
_(l79,oBBB)
}
var cGBB=_mz(z,'button',['bindtap',69,'class',1,'hidden',2,'type',3],[],e,s,gg)
var oHBB=_oz(z,73,e,s,gg)
_(cGBB,oHBB)
_(r,cGBB)
var lIBB=_mz(z,'button',['bindtap',74,'class',1],[],e,s,gg)
var aJBB=_oz(z,76,e,s,gg)
_(lIBB,aJBB)
_(r,lIBB)
o69.wxXCkey=1
l79.wxXCkey=1
return r
}
e_[x[0]]={f:m0,j:[],i:[],ti:[],ic:[]}
if(path&&e_[path]){
outerGlobal.__wxml_comp_version__=0.02
return function(env,dd,global){$gwxc=0;var root={"tag":"wx-page"};root.children=[]
;g="$gwx_XC_20";var main=e_[path].f
if (typeof global==="undefined")global={};global.f=$gdc(f_[path],"",1);
if(typeof(outerGlobal.__webview_engine_version__)!='undefined'&&outerGlobal.__webview_engine_version__+1e-6>=0.02+1e-6&&outerGlobal.__mergeData__)
{
env=outerGlobal.__mergeData__(env,dd);
}
try{
main(env,{},root,global);
_tsd(root)
if(typeof(outerGlobal.__webview_engine_version__)=='undefined'|| outerGlobal.__webview_engine_version__+1e-6<0.01+1e-6){return _ev(root);}
}catch(err){
console.log(err)
}
;g="";
return root;
}
}
}
}(__g.a,__g.b,__g.c,__g.d,__g.e,__g.f,__g.g,__g.h,__g.i,__g.j,__g.k,__g.l,__g.m,__g.n,__g.o,__g.p,__g.q,__g.r,__g.s,__g.t,__g.u,__g.v,__g.w,__g.x,__g.y,__g.z,__g.A,__g.B,__g.C,__g.D,__g.E,__g.F,__g.G,__g.H,__g.I,__g.J,__g.K,__g.L,__g.M,__g.N,__g.O,__g.P,__g.Q,__g.R,__g.S,__g.T,__g.U,__g.V,__g.W,__g.X,__g.Y,__g.Z,__g.aa);if(__vd_version_info__.delayedGwx||false)$gwx_XC_20();	if (__vd_version_info__.delayedGwx) __wxAppCode__['pages/test/test.wxml'] = [$gwx_XC_20, './pages/test/test.wxml'];else __wxAppCode__['pages/test/test.wxml'] = $gwx_XC_20( './pages/test/test.wxml' );
	
var noCss=typeof __vd_version_info__!=='undefined'&&__vd_version_info__.noCss===true;if(!noCss){__wxAppCode__['pages/test/test.wxss'] = setCssToHead([".",[1],"tip{margin:",[0,30],";text-align:center}\n.",[1],"tip,.",[1],"type{color:red;font-size:",[0,30],"}\n.",[1],"ti-title,.",[1],"ti-type,.",[1],"type{margin-bottom:",[0,20],";margin-left:",[0,20],"}\n.",[1],"ti-title{font-size:",[0,40],";font-weight:550}\n.",[1],"item{margin:",[0,25],"}\n.",[1],"pro{margin:",[0,20],"}\n.",[1],"but{margin:",[0,40],"}\n.",[1],"ok{margin:",[0,20],"}\n.",[1],"time{margin:",[0,20]," 0;text-align:center}\n.",[1],"result,.",[1],"time{font-size:",[0,40],"}\n.",[1],"result{margin:",[0,40]," ",[0,20],"}\n",],undefined,{path:"./pages/test/test.wxss"});
}