var a = wx.cloud.database(), n = getApp();

wx.cloud.database().collection("tiku_users");

Page({
    onLoad: function() {
        var e = this, t = a.command.aggregate;
        a.collection("tiku_users").aggregate().group({
            _id: "$id",
            num: t.sum(1)
        }).end().then(function(a) {
            console.log("", a), e.setData({
                list1: a.list
            });
        });
        var s = n.globalData.userInfo;
        console.log("", s), this.setData({
            userInfo: s
        });
    },
    ccadmin: function() {
        wx.navigateTo({
            url: "/pages/administrators/administrators"
        });
    },
    ccadminuser: function() {
        wx.navigateTo({
            url: "/pages/ccadminuser/ccadminuser"
        });
    },
    adminbanners: function() {
        wx.navigateTo({
            url: "/pages/adminbanners/adminbanners"
        });
    }
});