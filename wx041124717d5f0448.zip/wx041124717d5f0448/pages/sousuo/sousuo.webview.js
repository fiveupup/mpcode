$gwx_XC_19=function(_,_v,_n,_p,_s,_wp,_wl,$gwn,$gwl,$gwh,wh,$gstack,$gwrt,gra,grb,TestTest,wfor,_ca,_da,_r,_rz,_o,_oz,_1,_1z,_2,_2z,_m,_mz,nv_getDate,nv_getRegExp,nv_console,nv_parseInt,nv_parseFloat,nv_isNaN,nv_isFinite,nv_decodeURI,nv_decodeURIComponent,nv_encodeURI,nv_encodeURIComponent,$gdc,nv_JSON,_af,_gv,_ai,_grp,_gd,_gapi,$ixc,_ic,_w,_ev,_tsd){return function(path,global){
if(typeof global==='undefined'){if (typeof __GWX_GLOBAL__==='undefined')global={};else global=__GWX_GLOBAL__;}if(typeof __WXML_GLOBAL__ === 'undefined') {__WXML_GLOBAL__={};
}__WXML_GLOBAL__.modules = __WXML_GLOBAL__.modules || {};
var e_={}
if(typeof(global.entrys)==='undefined')global.entrys={};e_=global.entrys;
var d_={}
if(typeof(global.defines)==='undefined')global.defines={};d_=global.defines;
var f_={}
if(typeof(global.modules)==='undefined')global.modules={};f_=global.modules || {};
var p_={}
__WXML_GLOBAL__.ops_cached = __WXML_GLOBAL__.ops_cached || {}
__WXML_GLOBAL__.ops_set = __WXML_GLOBAL__.ops_set || {};
__WXML_GLOBAL__.ops_init = __WXML_GLOBAL__.ops_init || {};
var z=__WXML_GLOBAL__.ops_set.$gwx_XC_19 || [];
function gz$gwx_XC_19_1(){
if( __WXML_GLOBAL__.ops_cached.$gwx_XC_19_1)return __WXML_GLOBAL__.ops_cached.$gwx_XC_19_1
__WXML_GLOBAL__.ops_cached.$gwx_XC_19_1=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
Z([3,''])
Z([3,'date'])
Z([3,'liangtou'])
Z([3,'type'])
Z([3,'red-block'])
Z([3,'/images/mine-head.png'])
Z([[2,'=='],[[6],[[6],[[7],[3,'subject']],[3,'answer']],[3,'length']],[1,1]])
Z([3,' 单选题'])
Z([[2,'>'],[[6],[[6],[[7],[3,'subject']],[3,'answer']],[3,'length']],[1,1]])
Z([3,'多选题'])
Z([3,'questionView'])
Z([3,'headView'])
Z([3,'countView'])
Z([3,'prev'])
Z([[2,'>'],[[7],[3,'totalScore']],[[2,'-'],[1,1]]])
Z([3,'/images/icon_one.png'])
Z([3,'/images/icon_prev.png'])
Z([3,'process'])
Z([a,[[6],[[7],[3,'subject']],[3,'type']],[3,'/'],[[6],[[7],[3,'subject']],[3,'type2']]])
Z(z[13])
Z([3,'/images/icon_next.png'])
Z([3,'image1 '])
Z([[6],[[7],[3,'subject']],[3,'image']])
Z([3,'previewImg'])
Z([3,'image2'])
Z([[4],[[5],[[6],[[7],[3,'subject']],[3,'image']]]])
Z(z[22])
Z([3,'ti-title'])
Z([a,[[6],[[7],[3,'subject']],[3,'title']]])
Z(z[6])
Z([3,'selectClick'])
Z([3,'anniu'])
Z([3,'item'])
Z([[7],[3,'isSelect']])
Z(z[0])
Z([3,'A'])
Z([a,[[6],[[7],[3,'subject']],[3,'optionA']]])
Z(z[32])
Z(z[33])
Z([3,'B'])
Z([a,[3,'  '],[[6],[[7],[3,'subject']],[3,'optionB']]])
Z([[6],[[7],[3,'subject']],[3,'optionC']])
Z(z[32])
Z(z[33])
Z([3,'C'])
Z([a,z[40][1],[[6],[[7],[3,'subject']],[3,'optionC']]])
Z([[6],[[7],[3,'subject']],[3,'optionD']])
Z(z[32])
Z(z[33])
Z([3,'D'])
Z([a,z[40][1],[[6],[[7],[3,'subject']],[3,'optionD']]])
Z(z[30])
Z(z[32])
Z(z[33])
Z(z[35])
Z([a,[3,'A:'],z[36][1]])
Z(z[32])
Z(z[33])
Z(z[39])
Z([a,[3,'B:'],z[40][2]])
Z(z[41])
Z(z[32])
Z(z[33])
Z(z[44])
Z([a,[3,'C:'],z[45][2]])
Z(z[46])
Z(z[32])
Z(z[33])
Z(z[49])
Z([a,[3,'D:'],z[50][2]])
Z([3,'ok'])
Z([3,'but'])
Z([[7],[3,'showAnswer']])
Z([3,'查看答案和解析'])
Z(z[72])
Z([3,'answer-jiexi'])
Z(z[70])
Z([3,'你的答案：'])
Z([[7],[3,'userSelect']])
Z([[2,'=='],[[7],[3,'userSelect']],[[6],[[7],[3,'subject']],[3,'answer']]])
Z([3,'daan1'])
Z([a,[[7],[3,'item']],[3,' ✅']])
Z([3,'daan2'])
Z([a,z[81][1],[3,' ❌']])
Z(z[70])
Z([3,'answer-title'])
Z([[6],[[7],[3,'subject']],[3,'answer']])
Z([3,' 正确答案：'])
Z(z[80])
Z([a,z[81][1],z[40][1]])
Z([3,'collect'])
Z([[2,'!'],[[7],[3,'shoucang']]])
Z([3,'jiucuo'])
Z([3,'cloud://cloud1-8gs7t7f49b4c97d8.636c-cloud1-8gs7t7f49b4c97d8-1309642353/cloudbase-cms/upload/2022-06-07/图标/收藏.png'])
Z([[7],[3,'shoucang']])
Z(z[92])
Z([3,'cloud://cloud1-8gs7t7f49b4c97d8.636c-cloud1-8gs7t7f49b4c97d8-1309642353/cloudbase-cms/upload/2022-06-07/图标/已收藏.png'])
Z(z[70])
Z([a,[[6],[[7],[3,'subject']],[3,'explain']]])
Z(z[14])
Z([3,'result'])
Z([a,[3,'获得积分：'],[[7],[3,'totalScore']]])
Z([a,[3,' 您答错了'],[[7],[3,'totalError']],[3,'道题， ']])
Z([[2,'>'],[[7],[3,'totalError']],[1,0]])
Z([3,'seeError'])
Z([3,'to-error'])
Z([3,'点击查看您的错题集'])
Z([3,'dibu1'])
Z([3,'截止目前1433名用户使用过'])
Z(z[107])
Z(z[108])
})(__WXML_GLOBAL__.ops_cached.$gwx_XC_19_1);return __WXML_GLOBAL__.ops_cached.$gwx_XC_19_1
}
__WXML_GLOBAL__.ops_set.$gwx_XC_19=z;
__WXML_GLOBAL__.ops_init.$gwx_XC_19=true;
var x=['./pages/sousuo/sousuo.wxml'];d_[x[0]]={}
var m0=function(e,s,r,gg){
var z=gz$gwx_XC_19_1()
var oT6=_mz(z,'view',['bindtap',0,'class',1],[],e,s,gg)
var xU6=_n('view')
_(oT6,xU6)
var oV6=_n('view')
_(oT6,oV6)
_(r,oT6)
var fW6=_n('view')
_rz(z,fW6,'class',2,e,s,gg)
var cX6=_n('view')
_rz(z,cX6,'class',3,e,s,gg)
var oZ6=_mz(z,'image',['class',4,'src',1],[],e,s,gg)
_(cX6,oZ6)
var hY6=_v()
_(cX6,hY6)
if(_oz(z,6,e,s,gg)){hY6.wxVkey=1
var c16=_n('text')
var o26=_oz(z,7,e,s,gg)
_(c16,o26)
_(hY6,c16)
}
else if(_oz(z,8,e,s,gg)){hY6.wxVkey=2
var l36=_n('text')
var a46=_oz(z,9,e,s,gg)
_(l36,a46)
_(hY6,l36)
}
hY6.wxXCkey=1
_(fW6,cX6)
var t56=_n('view')
_rz(z,t56,'class',10,e,s,gg)
var e66=_n('view')
_rz(z,e66,'class',11,e,s,gg)
var b76=_n('view')
_rz(z,b76,'class',12,e,s,gg)
var o86=_n('view')
_rz(z,o86,'class',13,e,s,gg)
var x96=_v()
_(o86,x96)
if(_oz(z,14,e,s,gg)){x96.wxVkey=1
var o06=_n('image')
_rz(z,o06,'src',15,e,s,gg)
_(x96,o06)
}
else{x96.wxVkey=2
var fA7=_n('image')
_rz(z,fA7,'src',16,e,s,gg)
_(x96,fA7)
}
x96.wxXCkey=1
_(b76,o86)
var cB7=_n('view')
_rz(z,cB7,'class',17,e,s,gg)
var hC7=_oz(z,18,e,s,gg)
_(cB7,hC7)
_(b76,cB7)
var oD7=_n('view')
_rz(z,oD7,'class',19,e,s,gg)
var cE7=_n('image')
_rz(z,cE7,'src',20,e,s,gg)
_(oD7,cE7)
_(b76,oD7)
_(e66,b76)
_(t56,e66)
_(fW6,t56)
_(r,fW6)
var oF7=_n('view')
_rz(z,oF7,'class',21,e,s,gg)
var lG7=_v()
_(oF7,lG7)
if(_oz(z,22,e,s,gg)){lG7.wxVkey=1
var aH7=_mz(z,'image',['bindtap',23,'class',1,'data-tp',2,'src',3],[],e,s,gg)
_(lG7,aH7)
}
lG7.wxXCkey=1
_(r,oF7)
var tI7=_n('view')
_rz(z,tI7,'class',27,e,s,gg)
var eJ7=_oz(z,28,e,s,gg)
_(tI7,eJ7)
_(r,tI7)
var tQ6=_v()
_(r,tQ6)
if(_oz(z,29,e,s,gg)){tQ6.wxVkey=1
var bK7=_mz(z,'radio-group',['bindchange',30,'class',1],[],e,s,gg)
var oL7=_n('label')
var xM7=_n('view')
_rz(z,xM7,'class',32,e,s,gg)
var oN7=_mz(z,'radio',['checked',33,'class',1,'value',2],[],e,s,gg)
_(xM7,oN7)
var fO7=_n('text')
var cP7=_oz(z,36,e,s,gg)
_(fO7,cP7)
_(xM7,fO7)
_(oL7,xM7)
_(bK7,oL7)
var hQ7=_n('label')
var oR7=_n('view')
_rz(z,oR7,'class',37,e,s,gg)
var cS7=_mz(z,'radio',['checked',38,'value',1],[],e,s,gg)
_(oR7,cS7)
var oT7=_n('text')
var lU7=_oz(z,40,e,s,gg)
_(oT7,lU7)
_(oR7,oT7)
_(hQ7,oR7)
_(bK7,hQ7)
var aV7=_n('label')
var tW7=_v()
_(aV7,tW7)
if(_oz(z,41,e,s,gg)){tW7.wxVkey=1
var eX7=_n('view')
_rz(z,eX7,'class',42,e,s,gg)
var bY7=_mz(z,'radio',['checked',43,'value',1],[],e,s,gg)
_(eX7,bY7)
var oZ7=_n('text')
var x17=_oz(z,45,e,s,gg)
_(oZ7,x17)
_(eX7,oZ7)
_(tW7,eX7)
}
tW7.wxXCkey=1
_(bK7,aV7)
var o27=_n('label')
var f37=_v()
_(o27,f37)
if(_oz(z,46,e,s,gg)){f37.wxVkey=1
var c47=_n('view')
_rz(z,c47,'class',47,e,s,gg)
var h57=_mz(z,'radio',['checked',48,'value',1],[],e,s,gg)
_(c47,h57)
var o67=_n('text')
var c77=_oz(z,50,e,s,gg)
_(o67,c77)
_(c47,o67)
_(f37,c47)
}
f37.wxXCkey=1
_(bK7,o27)
_(tQ6,bK7)
}
else{tQ6.wxVkey=2
var o87=_n('checkbox-group')
_rz(z,o87,'bindchange',51,e,s,gg)
var tA8=_n('view')
_rz(z,tA8,'class',52,e,s,gg)
var eB8=_mz(z,'checkbox',['checked',53,'value',1],[],e,s,gg)
_(tA8,eB8)
var bC8=_n('text')
var oD8=_oz(z,55,e,s,gg)
_(bC8,oD8)
_(tA8,bC8)
_(o87,tA8)
var xE8=_n('view')
_rz(z,xE8,'class',56,e,s,gg)
var oF8=_mz(z,'checkbox',['checked',57,'value',1],[],e,s,gg)
_(xE8,oF8)
var fG8=_n('text')
var cH8=_oz(z,59,e,s,gg)
_(fG8,cH8)
_(xE8,fG8)
_(o87,xE8)
var l97=_v()
_(o87,l97)
if(_oz(z,60,e,s,gg)){l97.wxVkey=1
var hI8=_n('view')
_rz(z,hI8,'class',61,e,s,gg)
var oJ8=_mz(z,'checkbox',['checked',62,'value',1],[],e,s,gg)
_(hI8,oJ8)
var cK8=_n('text')
var oL8=_oz(z,64,e,s,gg)
_(cK8,oL8)
_(hI8,cK8)
_(l97,hI8)
}
var a07=_v()
_(o87,a07)
if(_oz(z,65,e,s,gg)){a07.wxVkey=1
var lM8=_n('view')
_rz(z,lM8,'class',66,e,s,gg)
var aN8=_mz(z,'checkbox',['checked',67,'value',1],[],e,s,gg)
_(lM8,aN8)
var tO8=_n('text')
var eP8=_oz(z,69,e,s,gg)
_(tO8,eP8)
_(lM8,tO8)
_(a07,lM8)
}
l97.wxXCkey=1
a07.wxXCkey=1
_(tQ6,o87)
}
var bQ8=_mz(z,'button',['bindtap',70,'class',1,'hidden',2],[],e,s,gg)
var oR8=_oz(z,73,e,s,gg)
_(bQ8,oR8)
_(r,bQ8)
var eR6=_v()
_(r,eR6)
if(_oz(z,74,e,s,gg)){eR6.wxVkey=1
var xS8=_n('view')
_rz(z,xS8,'class',75,e,s,gg)
var oT8=_n('view')
_rz(z,oT8,'class',76,e,s,gg)
var fU8=_n('view')
var cV8=_n('text')
var hW8=_oz(z,77,e,s,gg)
_(cV8,hW8)
_(fU8,cV8)
var oX8=_v()
_(fU8,oX8)
var cY8=function(l18,oZ8,a28,gg){
var e48=_v()
_(a28,e48)
if(_oz(z,79,l18,oZ8,gg)){e48.wxVkey=1
var b58=_n('text')
_rz(z,b58,'class',80,l18,oZ8,gg)
var o68=_oz(z,81,l18,oZ8,gg)
_(b58,o68)
_(e48,b58)
}
else{e48.wxVkey=2
var x78=_n('text')
_rz(z,x78,'class',82,l18,oZ8,gg)
var o88=_oz(z,83,l18,oZ8,gg)
_(x78,o88)
_(e48,x78)
}
e48.wxXCkey=1
return a28
}
oX8.wxXCkey=2
_2z(z,78,cY8,e,s,gg,oX8,'item','index','')
_(oT8,fU8)
_(xS8,oT8)
var f98=_n('view')
_rz(z,f98,'class',84,e,s,gg)
var c08=_n('view')
_rz(z,c08,'class',85,e,s,gg)
var hA9=_n('view')
var oB9=_v()
_(hA9,oB9)
var cC9=function(lE9,oD9,aF9,gg){
var eH9=_n('text')
var bI9=_oz(z,87,lE9,oD9,gg)
_(eH9,bI9)
_(aF9,eH9)
var oJ9=_n('text')
_rz(z,oJ9,'class',88,lE9,oD9,gg)
var xK9=_oz(z,89,lE9,oD9,gg)
_(oJ9,xK9)
_(aF9,oJ9)
return aF9
}
oB9.wxXCkey=2
_2z(z,86,cC9,e,s,gg,oB9,'item','index','')
_(c08,hA9)
var oL9=_n('view')
_rz(z,oL9,'bindtap',90,e,s,gg)
var fM9=_v()
_(oL9,fM9)
if(_oz(z,91,e,s,gg)){fM9.wxVkey=1
var hO9=_mz(z,'image',['class',92,'src',1],[],e,s,gg)
_(fM9,hO9)
}
var cN9=_v()
_(oL9,cN9)
if(_oz(z,94,e,s,gg)){cN9.wxVkey=1
var oP9=_mz(z,'image',['class',95,'src',1],[],e,s,gg)
_(cN9,oP9)
}
fM9.wxXCkey=1
cN9.wxXCkey=1
_(c08,oL9)
_(f98,c08)
var cQ9=_n('view')
_rz(z,cQ9,'class',97,e,s,gg)
var oR9=_n('view')
var lS9=_oz(z,98,e,s,gg)
_(oR9,lS9)
_(cQ9,oR9)
_(f98,cQ9)
_(xS8,f98)
_(eR6,xS8)
}
var bS6=_v()
_(r,bS6)
if(_oz(z,99,e,s,gg)){bS6.wxVkey=1
var aT9=_n('view')
_rz(z,aT9,'class',100,e,s,gg)
var eV9=_n('view')
var bW9=_oz(z,101,e,s,gg)
_(eV9,bW9)
_(aT9,eV9)
var oX9=_oz(z,102,e,s,gg)
_(aT9,oX9)
var tU9=_v()
_(aT9,tU9)
if(_oz(z,103,e,s,gg)){tU9.wxVkey=1
var xY9=_mz(z,'text',['bindtap',104,'class',1],[],e,s,gg)
var oZ9=_oz(z,106,e,s,gg)
_(xY9,oZ9)
_(tU9,xY9)
}
tU9.wxXCkey=1
_(bS6,aT9)
}
var f19=_n('text')
_rz(z,f19,'class',107,e,s,gg)
var c29=_oz(z,108,e,s,gg)
_(f19,c29)
_(r,f19)
var h39=_n('text')
_rz(z,h39,'class',109,e,s,gg)
var o49=_oz(z,110,e,s,gg)
_(h39,o49)
_(r,h39)
tQ6.wxXCkey=1
eR6.wxXCkey=1
bS6.wxXCkey=1
return r
}
e_[x[0]]={f:m0,j:[],i:[],ti:[],ic:[]}
if(path&&e_[path]){
outerGlobal.__wxml_comp_version__=0.02
return function(env,dd,global){$gwxc=0;var root={"tag":"wx-page"};root.children=[]
;g="$gwx_XC_19";var main=e_[path].f
if (typeof global==="undefined")global={};global.f=$gdc(f_[path],"",1);
if(typeof(outerGlobal.__webview_engine_version__)!='undefined'&&outerGlobal.__webview_engine_version__+1e-6>=0.02+1e-6&&outerGlobal.__mergeData__)
{
env=outerGlobal.__mergeData__(env,dd);
}
try{
main(env,{},root,global);
_tsd(root)
if(typeof(outerGlobal.__webview_engine_version__)=='undefined'|| outerGlobal.__webview_engine_version__+1e-6<0.01+1e-6){return _ev(root);}
}catch(err){
console.log(err)
}
;g="";
return root;
}
}
}
}(__g.a,__g.b,__g.c,__g.d,__g.e,__g.f,__g.g,__g.h,__g.i,__g.j,__g.k,__g.l,__g.m,__g.n,__g.o,__g.p,__g.q,__g.r,__g.s,__g.t,__g.u,__g.v,__g.w,__g.x,__g.y,__g.z,__g.A,__g.B,__g.C,__g.D,__g.E,__g.F,__g.G,__g.H,__g.I,__g.J,__g.K,__g.L,__g.M,__g.N,__g.O,__g.P,__g.Q,__g.R,__g.S,__g.T,__g.U,__g.V,__g.W,__g.X,__g.Y,__g.Z,__g.aa);if(__vd_version_info__.delayedGwx||false)$gwx_XC_19();	if (__vd_version_info__.delayedGwx) __wxAppCode__['pages/sousuo/sousuo.wxml'] = [$gwx_XC_19, './pages/sousuo/sousuo.wxml'];else __wxAppCode__['pages/sousuo/sousuo.wxml'] = $gwx_XC_19( './pages/sousuo/sousuo.wxml' );
	
var noCss=typeof __vd_version_info__!=='undefined'&&__vd_version_info__.noCss===true;if(!noCss){__wxAppCode__['pages/sousuo/sousuo.wxss'] = setCssToHead([".",[1],"tip{margin:0 ",[0,20],";text-align:center}\n.",[1],"tip,.",[1],"type{color:red;font-size:",[0,30],"}\n.",[1],"type{margin-bottom:",[0,20],";margin-left:",[0,20],"}\n.",[1],"ti-type{font-size:",[0,30],";margin-bottom:",[0,20],"}\n.",[1],"ti-title,.",[1],"ti-type{color:#000;font-family:PingFangSC-Medium,PingFang SC;font-weight:500;padding:0 ",[0,48],"}\n.",[1],"ti-title{font-size:",[0,32],";line-height:",[0,70],";margin-bottom:",[0,40],";margin-top:",[0,24],"}\n.",[1],"item{background:#fff;border-bottom:1px solid #e9e9e9;display:-webkit-flex;display:flex;font-size:",[0,30],";height:",[0,40],";margin:",[0,10],";padding:",[0,25],";width:80%}\n.",[1],"anniu{font-size:rpx;margin-left:",[0,10],";padding:0 10px;width:100%}\n.",[1],"anniu2{text-align:right}\n.",[1],"pro{margin:",[0,20],"}\n.",[1],"but{margin:",[0,50]," ",[0,40],"}\n.",[1],"ok,.",[1],"result{color:#727272;font-size:",[0,30],"}\n.",[1],"result{margin:",[0,80]," ",[0,40],"}\n.",[1],"answer-title{display:-webkit-flex;display:flex;-webkit-justify-content:space-between;justify-content:space-between;margin:",[0,10]," ",[0,0],"}\n.",[1],"to-error{color:red}\n.",[1],"answer-jiexi1{-webkit-justify-content:space-evenly;justify-content:space-evenly;vertical-align:middle}\n.",[1],"answer-jiexi{background-color:#fff;box-shadow:",[0,0]," ",[0,0]," ",[0,12]," ",[0,0]," rgba(0,0,0,.09);margin:",[0,50]," ",[0,40],";padding:",[0,36],"!important}\n.",[1],"date{background:-webkit-linear-gradient(left,#fff,#fff);border-radius:",[0,15],";color:#fff;display:-webkit-flex;display:flex;-webkit-flex-direction:row;flex-direction:row;font-size:",[0,25],";height:",[0,50],";line-height:",[0,50],";margin:",[0,31],";width:",[0,690],"}\n.",[1],"red-block{height:",[0,24],";position:relative;width:",[0,10],"}\n.",[1],"questionView .",[1],"headView{-webkit-align-items:center;align-items:center;display:-webkit-flex;display:flex;padding-left:",[0,36],";padding-right:",[0,30],"}\n.",[1],"questionView .",[1],"headView .",[1],"red-block{height:",[0,24],";margin-right:",[0,8],";position:relative;width:",[0,10],"}\n.",[1],"image1{display:-webkit-flex;display:flex;-webkit-justify-content:center;justify-content:center}\n.",[1],"image2{background:#fff;border-radius:",[0,14],";box-shadow:0 ",[0,4]," ",[0,8]," 0 rgba(0,0,0,.06);height:200px;margin:0 auto ",[0,24],";overflow:hidden;width:87%}\n.",[1],"questionView .",[1],"headView .",[1],"queType{color:#000;-webkit-flex:1;flex:1;font-family:PingFangSC-Medium,PingFang SC;font-size:",[0,28],";font-weight:500;height:",[0,40],";line-height:",[0,40],"}\n.",[1],"questionView .",[1],"headView .",[1],"countView{color:rgba(0,0,0,.5);display:-webkit-inline-flex;display:inline-flex;font-family:PingFangSC-Regular,PingFang SC;font-size:",[0,20],";font-weight:400;height:",[0,40],";line-height:",[0,40],";text-align:right}\n.",[1],"questionView .",[1],"headView .",[1],"countView .",[1],"prev{font-size:0;height:",[0,30],";line-height:",[0,40],";width:",[0,30],"}\n.",[1],"questionView .",[1],"headView .",[1],"countView .",[1],"prev wx-image{display:inline-block;height:",[0,30],";vertical-align:middle;width:",[0,30],"}\n.",[1],"questionView .",[1],"headView .",[1],"countView .",[1],"process{margin:0 ",[0,20],"}\n.",[1],"questionView .",[1],"headView .",[1],"countView .",[1],"next{font-size:0;height:",[0,30],";line-height:",[0,40],";width:",[0,30],"}\n.",[1],"daan1{color:#00d836}\n.",[1],"daan2{color:red}\n.",[1],"liangtou{border:",[0,1]," solid #fff;display:-webkit-flex;display:flex;height:",[0,60],";-webkit-justify-content:space-between;justify-content:space-between;padding:0 10px;vertical-align:middle}\nwx-radio .",[1],"wx-radio-input{background:none;border:",[0,4]," solid #8c8c8c;border-radius:50%;height:",[0,25],";width:",[0,25],"}\nwx-radio .",[1],"wx-radio-input.",[1],"wx-radio-input-checked{background-color:#fff!important;border:",[0,4]," solid #8c8c8c!important}\nwx-radio .",[1],"wx-radio-input.",[1],"wx-radio-input-checked::before{background:#8c8c8c;border-radius:50%;content:\x22\x22;height:80%;transform:translate(-50%,-50%) scale(1);-webkit-transform:translate(-50%,-50%) scale(1);width:80%}\n.",[1],"dibu1{color:#fff;display:-webkit-flex;display:flex;font-size:",[0,24],";height:",[0,60],";-webkit-justify-content:center;justify-content:center}\n.",[1],"jiucuo{height:",[0,50],";position:relative;width:",[0,100],"}\n",],"Some selectors are not allowed in component wxss, including tag name selectors, ID selectors, and attribute selectors.(./pages/sousuo/sousuo.wxss:1:3070)",{path:"./pages/sousuo/sousuo.wxss"});
}