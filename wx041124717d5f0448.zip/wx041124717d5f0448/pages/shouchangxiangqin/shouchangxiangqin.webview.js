$gwx_XC_18=function(_,_v,_n,_p,_s,_wp,_wl,$gwn,$gwl,$gwh,wh,$gstack,$gwrt,gra,grb,TestTest,wfor,_ca,_da,_r,_rz,_o,_oz,_1,_1z,_2,_2z,_m,_mz,nv_getDate,nv_getRegExp,nv_console,nv_parseInt,nv_parseFloat,nv_isNaN,nv_isFinite,nv_decodeURI,nv_decodeURIComponent,nv_encodeURI,nv_encodeURIComponent,$gdc,nv_JSON,_af,_gv,_ai,_grp,_gd,_gapi,$ixc,_ic,_w,_ev,_tsd){return function(path,global){
if(typeof global==='undefined'){if (typeof __GWX_GLOBAL__==='undefined')global={};else global=__GWX_GLOBAL__;}if(typeof __WXML_GLOBAL__ === 'undefined') {__WXML_GLOBAL__={};
}__WXML_GLOBAL__.modules = __WXML_GLOBAL__.modules || {};
var e_={}
if(typeof(global.entrys)==='undefined')global.entrys={};e_=global.entrys;
var d_={}
if(typeof(global.defines)==='undefined')global.defines={};d_=global.defines;
var f_={}
if(typeof(global.modules)==='undefined')global.modules={};f_=global.modules || {};
var p_={}
__WXML_GLOBAL__.ops_cached = __WXML_GLOBAL__.ops_cached || {}
__WXML_GLOBAL__.ops_set = __WXML_GLOBAL__.ops_set || {};
__WXML_GLOBAL__.ops_init = __WXML_GLOBAL__.ops_init || {};
var z=__WXML_GLOBAL__.ops_set.$gwx_XC_18 || [];
function gz$gwx_XC_18_1(){
if( __WXML_GLOBAL__.ops_cached.$gwx_XC_18_1)return __WXML_GLOBAL__.ops_cached.$gwx_XC_18_1
__WXML_GLOBAL__.ops_cached.$gwx_XC_18_1=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
Z([3,''])
Z([3,'date'])
Z([3,'liangtou'])
Z([3,'type'])
Z([3,'red-block'])
Z([3,'/images/mine-head.png'])
Z([[2,'=='],[[6],[[6],[[7],[3,'subject']],[3,'answer']],[3,'length']],[1,1]])
Z([3,' 单选题'])
Z([[2,'>'],[[6],[[6],[[7],[3,'subject']],[3,'answer']],[3,'length']],[1,1]])
Z([3,'多选题'])
Z([3,'questionView'])
Z([3,'headView'])
Z([3,'countView'])
Z([3,'prev'])
Z([[2,'>'],[[7],[3,'totalScore']],[[2,'-'],[1,1]]])
Z([3,'/images/icon_one.png'])
Z([3,'/images/icon_prev.png'])
Z([3,'process'])
Z([a,[[6],[[7],[3,'subject']],[3,'type']],[3,'/'],[[6],[[7],[3,'subject']],[3,'type2']]])
Z(z[13])
Z([3,'/images/icon_next.png'])
Z([3,'image1 '])
Z([[6],[[7],[3,'subject']],[3,'image']])
Z([3,'previewImg'])
Z([3,'image2'])
Z([[4],[[5],[[6],[[7],[3,'subject']],[3,'image']]]])
Z(z[22])
Z([3,'ti-title'])
Z([a,[[6],[[7],[3,'subject']],[3,'title']]])
Z(z[6])
Z([3,'selectClick'])
Z([3,'anniu'])
Z([3,'item'])
Z([[7],[3,'isSelect']])
Z(z[0])
Z([3,'A'])
Z([a,[[6],[[7],[3,'subject']],[3,'optionA']]])
Z(z[32])
Z(z[33])
Z([3,'B'])
Z([a,[3,'  '],[[6],[[7],[3,'subject']],[3,'optionB']]])
Z([[6],[[7],[3,'subject']],[3,'optionC']])
Z(z[32])
Z(z[33])
Z([3,'C'])
Z([a,z[40][1],[[6],[[7],[3,'subject']],[3,'optionC']]])
Z([[6],[[7],[3,'subject']],[3,'optionD']])
Z(z[32])
Z(z[33])
Z([3,'D'])
Z([a,z[40][1],[[6],[[7],[3,'subject']],[3,'optionD']]])
Z(z[30])
Z(z[32])
Z(z[33])
Z(z[35])
Z([a,[3,'A:'],z[36][1]])
Z(z[32])
Z(z[33])
Z(z[39])
Z([a,[3,'B:'],z[40][2]])
Z(z[41])
Z(z[32])
Z(z[33])
Z(z[44])
Z([a,[3,'C:'],z[45][2]])
Z(z[46])
Z(z[32])
Z(z[33])
Z(z[49])
Z([a,[3,'D:'],z[50][2]])
Z([3,'ok'])
Z([3,'but'])
Z([[7],[3,'showAnswer']])
Z([3,'查看答案和解析'])
Z(z[72])
Z([3,'answer-jiexi'])
Z(z[70])
Z([3,'你的答案：'])
Z([[7],[3,'userSelect']])
Z([[2,'=='],[[7],[3,'userSelect']],[[6],[[7],[3,'subject']],[3,'answer']]])
Z([3,'daan1'])
Z([a,[[7],[3,'item']],[3,' ✅']])
Z([3,'daan2'])
Z([a,z[81][1],[3,' ❌']])
Z(z[70])
Z([3,'answer-title'])
Z([[6],[[7],[3,'subject']],[3,'answer']])
Z([3,' 正确答案：'])
Z(z[80])
Z([a,z[81][1],z[40][1]])
Z([3,'collect'])
Z([[2,'!'],[[7],[3,'shoucang']]])
Z([3,'jiucuo'])
Z([3,'cloud://cloud1-8gs7t7f49b4c97d8.636c-cloud1-8gs7t7f49b4c97d8-1309642353/cloudbase-cms/upload/2022-06-07/图标/收藏.png'])
Z([[7],[3,'shoucang']])
Z(z[92])
Z([3,'cloud://cloud1-8gs7t7f49b4c97d8.636c-cloud1-8gs7t7f49b4c97d8-1309642353/cloudbase-cms/upload/2022-06-07/图标/已收藏.png'])
Z(z[70])
Z([a,[[6],[[7],[3,'subject']],[3,'explain']]])
Z(z[14])
Z([3,'result'])
Z([a,[3,'获得积分：'],[[7],[3,'totalScore']]])
Z([a,[3,' 您答错了'],[[7],[3,'totalError']],[3,'道题， ']])
Z([[2,'>'],[[7],[3,'totalError']],[1,0]])
Z([3,'seeError'])
Z([3,'to-error'])
Z([3,'点击查看您的错题集'])
Z([3,'dibu1'])
Z([3,'截止目前1433名用户使用过'])
Z(z[107])
Z(z[108])
})(__WXML_GLOBAL__.ops_cached.$gwx_XC_18_1);return __WXML_GLOBAL__.ops_cached.$gwx_XC_18_1
}
__WXML_GLOBAL__.ops_set.$gwx_XC_18=z;
__WXML_GLOBAL__.ops_init.$gwx_XC_18=true;
var x=['./pages/shouchangxiangqin/shouchangxiangqin.wxml'];d_[x[0]]={}
var m0=function(e,s,r,gg){
var z=gz$gwx_XC_18_1()
var fE3=_mz(z,'view',['bindtap',0,'class',1],[],e,s,gg)
var cF3=_n('view')
_(fE3,cF3)
var hG3=_n('view')
_(fE3,hG3)
_(r,fE3)
var oH3=_n('view')
_rz(z,oH3,'class',2,e,s,gg)
var cI3=_n('view')
_rz(z,cI3,'class',3,e,s,gg)
var lK3=_mz(z,'image',['class',4,'src',1],[],e,s,gg)
_(cI3,lK3)
var oJ3=_v()
_(cI3,oJ3)
if(_oz(z,6,e,s,gg)){oJ3.wxVkey=1
var aL3=_n('text')
var tM3=_oz(z,7,e,s,gg)
_(aL3,tM3)
_(oJ3,aL3)
}
else if(_oz(z,8,e,s,gg)){oJ3.wxVkey=2
var eN3=_n('text')
var bO3=_oz(z,9,e,s,gg)
_(eN3,bO3)
_(oJ3,eN3)
}
oJ3.wxXCkey=1
_(oH3,cI3)
var oP3=_n('view')
_rz(z,oP3,'class',10,e,s,gg)
var xQ3=_n('view')
_rz(z,xQ3,'class',11,e,s,gg)
var oR3=_n('view')
_rz(z,oR3,'class',12,e,s,gg)
var fS3=_n('view')
_rz(z,fS3,'class',13,e,s,gg)
var cT3=_v()
_(fS3,cT3)
if(_oz(z,14,e,s,gg)){cT3.wxVkey=1
var hU3=_n('image')
_rz(z,hU3,'src',15,e,s,gg)
_(cT3,hU3)
}
else{cT3.wxVkey=2
var oV3=_n('image')
_rz(z,oV3,'src',16,e,s,gg)
_(cT3,oV3)
}
cT3.wxXCkey=1
_(oR3,fS3)
var cW3=_n('view')
_rz(z,cW3,'class',17,e,s,gg)
var oX3=_oz(z,18,e,s,gg)
_(cW3,oX3)
_(oR3,cW3)
var lY3=_n('view')
_rz(z,lY3,'class',19,e,s,gg)
var aZ3=_n('image')
_rz(z,aZ3,'src',20,e,s,gg)
_(lY3,aZ3)
_(oR3,lY3)
_(xQ3,oR3)
_(oP3,xQ3)
_(oH3,oP3)
_(r,oH3)
var t13=_n('view')
_rz(z,t13,'class',21,e,s,gg)
var e23=_v()
_(t13,e23)
if(_oz(z,22,e,s,gg)){e23.wxVkey=1
var b33=_mz(z,'image',['bindtap',23,'class',1,'data-tp',2,'src',3],[],e,s,gg)
_(e23,b33)
}
e23.wxXCkey=1
_(r,t13)
var o43=_n('view')
_rz(z,o43,'class',27,e,s,gg)
var x53=_oz(z,28,e,s,gg)
_(o43,x53)
_(r,o43)
var oB3=_v()
_(r,oB3)
if(_oz(z,29,e,s,gg)){oB3.wxVkey=1
var o63=_mz(z,'radio-group',['bindchange',30,'class',1],[],e,s,gg)
var f73=_n('label')
var c83=_n('view')
_rz(z,c83,'class',32,e,s,gg)
var h93=_mz(z,'radio',['checked',33,'class',1,'value',2],[],e,s,gg)
_(c83,h93)
var o03=_n('text')
var cA4=_oz(z,36,e,s,gg)
_(o03,cA4)
_(c83,o03)
_(f73,c83)
_(o63,f73)
var oB4=_n('label')
var lC4=_n('view')
_rz(z,lC4,'class',37,e,s,gg)
var aD4=_mz(z,'radio',['checked',38,'value',1],[],e,s,gg)
_(lC4,aD4)
var tE4=_n('text')
var eF4=_oz(z,40,e,s,gg)
_(tE4,eF4)
_(lC4,tE4)
_(oB4,lC4)
_(o63,oB4)
var bG4=_n('label')
var oH4=_v()
_(bG4,oH4)
if(_oz(z,41,e,s,gg)){oH4.wxVkey=1
var xI4=_n('view')
_rz(z,xI4,'class',42,e,s,gg)
var oJ4=_mz(z,'radio',['checked',43,'value',1],[],e,s,gg)
_(xI4,oJ4)
var fK4=_n('text')
var cL4=_oz(z,45,e,s,gg)
_(fK4,cL4)
_(xI4,fK4)
_(oH4,xI4)
}
oH4.wxXCkey=1
_(o63,bG4)
var hM4=_n('label')
var oN4=_v()
_(hM4,oN4)
if(_oz(z,46,e,s,gg)){oN4.wxVkey=1
var cO4=_n('view')
_rz(z,cO4,'class',47,e,s,gg)
var oP4=_mz(z,'radio',['checked',48,'value',1],[],e,s,gg)
_(cO4,oP4)
var lQ4=_n('text')
var aR4=_oz(z,50,e,s,gg)
_(lQ4,aR4)
_(cO4,lQ4)
_(oN4,cO4)
}
oN4.wxXCkey=1
_(o63,hM4)
_(oB3,o63)
}
else{oB3.wxVkey=2
var tS4=_n('checkbox-group')
_rz(z,tS4,'bindchange',51,e,s,gg)
var oV4=_n('view')
_rz(z,oV4,'class',52,e,s,gg)
var xW4=_mz(z,'checkbox',['checked',53,'value',1],[],e,s,gg)
_(oV4,xW4)
var oX4=_n('text')
var fY4=_oz(z,55,e,s,gg)
_(oX4,fY4)
_(oV4,oX4)
_(tS4,oV4)
var cZ4=_n('view')
_rz(z,cZ4,'class',56,e,s,gg)
var h14=_mz(z,'checkbox',['checked',57,'value',1],[],e,s,gg)
_(cZ4,h14)
var o24=_n('text')
var c34=_oz(z,59,e,s,gg)
_(o24,c34)
_(cZ4,o24)
_(tS4,cZ4)
var eT4=_v()
_(tS4,eT4)
if(_oz(z,60,e,s,gg)){eT4.wxVkey=1
var o44=_n('view')
_rz(z,o44,'class',61,e,s,gg)
var l54=_mz(z,'checkbox',['checked',62,'value',1],[],e,s,gg)
_(o44,l54)
var a64=_n('text')
var t74=_oz(z,64,e,s,gg)
_(a64,t74)
_(o44,a64)
_(eT4,o44)
}
var bU4=_v()
_(tS4,bU4)
if(_oz(z,65,e,s,gg)){bU4.wxVkey=1
var e84=_n('view')
_rz(z,e84,'class',66,e,s,gg)
var b94=_mz(z,'checkbox',['checked',67,'value',1],[],e,s,gg)
_(e84,b94)
var o04=_n('text')
var xA5=_oz(z,69,e,s,gg)
_(o04,xA5)
_(e84,o04)
_(bU4,e84)
}
eT4.wxXCkey=1
bU4.wxXCkey=1
_(oB3,tS4)
}
var oB5=_mz(z,'button',['bindtap',70,'class',1,'hidden',2],[],e,s,gg)
var fC5=_oz(z,73,e,s,gg)
_(oB5,fC5)
_(r,oB5)
var xC3=_v()
_(r,xC3)
if(_oz(z,74,e,s,gg)){xC3.wxVkey=1
var cD5=_n('view')
_rz(z,cD5,'class',75,e,s,gg)
var hE5=_n('view')
_rz(z,hE5,'class',76,e,s,gg)
var oF5=_n('view')
var cG5=_n('text')
var oH5=_oz(z,77,e,s,gg)
_(cG5,oH5)
_(oF5,cG5)
var lI5=_v()
_(oF5,lI5)
var aJ5=function(eL5,tK5,bM5,gg){
var xO5=_v()
_(bM5,xO5)
if(_oz(z,79,eL5,tK5,gg)){xO5.wxVkey=1
var oP5=_n('text')
_rz(z,oP5,'class',80,eL5,tK5,gg)
var fQ5=_oz(z,81,eL5,tK5,gg)
_(oP5,fQ5)
_(xO5,oP5)
}
else{xO5.wxVkey=2
var cR5=_n('text')
_rz(z,cR5,'class',82,eL5,tK5,gg)
var hS5=_oz(z,83,eL5,tK5,gg)
_(cR5,hS5)
_(xO5,cR5)
}
xO5.wxXCkey=1
return bM5
}
lI5.wxXCkey=2
_2z(z,78,aJ5,e,s,gg,lI5,'item','index','')
_(hE5,oF5)
_(cD5,hE5)
var oT5=_n('view')
_rz(z,oT5,'class',84,e,s,gg)
var cU5=_n('view')
_rz(z,cU5,'class',85,e,s,gg)
var oV5=_n('view')
var lW5=_v()
_(oV5,lW5)
var aX5=function(eZ5,tY5,b15,gg){
var x35=_n('text')
var o45=_oz(z,87,eZ5,tY5,gg)
_(x35,o45)
_(b15,x35)
var f55=_n('text')
_rz(z,f55,'class',88,eZ5,tY5,gg)
var c65=_oz(z,89,eZ5,tY5,gg)
_(f55,c65)
_(b15,f55)
return b15
}
lW5.wxXCkey=2
_2z(z,86,aX5,e,s,gg,lW5,'item','index','')
_(cU5,oV5)
var h75=_n('view')
_rz(z,h75,'bindtap',90,e,s,gg)
var o85=_v()
_(h75,o85)
if(_oz(z,91,e,s,gg)){o85.wxVkey=1
var o05=_mz(z,'image',['class',92,'src',1],[],e,s,gg)
_(o85,o05)
}
var c95=_v()
_(h75,c95)
if(_oz(z,94,e,s,gg)){c95.wxVkey=1
var lA6=_mz(z,'image',['class',95,'src',1],[],e,s,gg)
_(c95,lA6)
}
o85.wxXCkey=1
c95.wxXCkey=1
_(cU5,h75)
_(oT5,cU5)
var aB6=_n('view')
_rz(z,aB6,'class',97,e,s,gg)
var tC6=_n('view')
var eD6=_oz(z,98,e,s,gg)
_(tC6,eD6)
_(aB6,tC6)
_(oT5,aB6)
_(cD5,oT5)
_(xC3,cD5)
}
var oD3=_v()
_(r,oD3)
if(_oz(z,99,e,s,gg)){oD3.wxVkey=1
var bE6=_n('view')
_rz(z,bE6,'class',100,e,s,gg)
var xG6=_n('view')
var oH6=_oz(z,101,e,s,gg)
_(xG6,oH6)
_(bE6,xG6)
var fI6=_oz(z,102,e,s,gg)
_(bE6,fI6)
var oF6=_v()
_(bE6,oF6)
if(_oz(z,103,e,s,gg)){oF6.wxVkey=1
var cJ6=_mz(z,'text',['bindtap',104,'class',1],[],e,s,gg)
var hK6=_oz(z,106,e,s,gg)
_(cJ6,hK6)
_(oF6,cJ6)
}
oF6.wxXCkey=1
_(oD3,bE6)
}
var oL6=_n('text')
_rz(z,oL6,'class',107,e,s,gg)
var cM6=_oz(z,108,e,s,gg)
_(oL6,cM6)
_(r,oL6)
var oN6=_n('text')
_rz(z,oN6,'class',109,e,s,gg)
var lO6=_oz(z,110,e,s,gg)
_(oN6,lO6)
_(r,oN6)
oB3.wxXCkey=1
xC3.wxXCkey=1
oD3.wxXCkey=1
return r
}
e_[x[0]]={f:m0,j:[],i:[],ti:[],ic:[]}
if(path&&e_[path]){
outerGlobal.__wxml_comp_version__=0.02
return function(env,dd,global){$gwxc=0;var root={"tag":"wx-page"};root.children=[]
;g="$gwx_XC_18";var main=e_[path].f
if (typeof global==="undefined")global={};global.f=$gdc(f_[path],"",1);
if(typeof(outerGlobal.__webview_engine_version__)!='undefined'&&outerGlobal.__webview_engine_version__+1e-6>=0.02+1e-6&&outerGlobal.__mergeData__)
{
env=outerGlobal.__mergeData__(env,dd);
}
try{
main(env,{},root,global);
_tsd(root)
if(typeof(outerGlobal.__webview_engine_version__)=='undefined'|| outerGlobal.__webview_engine_version__+1e-6<0.01+1e-6){return _ev(root);}
}catch(err){
console.log(err)
}
;g="";
return root;
}
}
}
}(__g.a,__g.b,__g.c,__g.d,__g.e,__g.f,__g.g,__g.h,__g.i,__g.j,__g.k,__g.l,__g.m,__g.n,__g.o,__g.p,__g.q,__g.r,__g.s,__g.t,__g.u,__g.v,__g.w,__g.x,__g.y,__g.z,__g.A,__g.B,__g.C,__g.D,__g.E,__g.F,__g.G,__g.H,__g.I,__g.J,__g.K,__g.L,__g.M,__g.N,__g.O,__g.P,__g.Q,__g.R,__g.S,__g.T,__g.U,__g.V,__g.W,__g.X,__g.Y,__g.Z,__g.aa);if(__vd_version_info__.delayedGwx||false)$gwx_XC_18();	if (__vd_version_info__.delayedGwx) __wxAppCode__['pages/shouchangxiangqin/shouchangxiangqin.wxml'] = [$gwx_XC_18, './pages/shouchangxiangqin/shouchangxiangqin.wxml'];else __wxAppCode__['pages/shouchangxiangqin/shouchangxiangqin.wxml'] = $gwx_XC_18( './pages/shouchangxiangqin/shouchangxiangqin.wxml' );
	
var noCss=typeof __vd_version_info__!=='undefined'&&__vd_version_info__.noCss===true;if(!noCss){__wxAppCode__['pages/shouchangxiangqin/shouchangxiangqin.wxss'] = setCssToHead([".",[1],"tip{margin:0 ",[0,20],";text-align:center}\n.",[1],"tip,.",[1],"type{color:red;font-size:",[0,30],"}\n.",[1],"type{margin-bottom:",[0,20],";margin-left:",[0,20],"}\n.",[1],"ti-type{font-size:",[0,30],";margin-bottom:",[0,20],"}\n.",[1],"ti-title,.",[1],"ti-type{color:#000;font-family:PingFangSC-Medium,PingFang SC;font-weight:500;padding:0 ",[0,48],"}\n.",[1],"ti-title{font-size:",[0,32],";line-height:",[0,70],";margin-bottom:",[0,40],";margin-top:",[0,24],"}\n.",[1],"item{background:#fff;border-bottom:1px solid #e9e9e9;display:-webkit-flex;display:flex;font-size:",[0,30],";height:",[0,40],";margin:",[0,10],";padding:",[0,25],";width:80%}\n.",[1],"anniu{font-size:rpx;margin-left:",[0,10],";padding:0 10px;width:100%}\n.",[1],"anniu2{text-align:right}\n.",[1],"pro{margin:",[0,20],"}\n.",[1],"but{margin:",[0,50]," ",[0,40],"}\n.",[1],"ok,.",[1],"result{color:#727272;font-size:",[0,30],"}\n.",[1],"result{margin:",[0,80]," ",[0,40],"}\n.",[1],"answer-title{display:-webkit-flex;display:flex;-webkit-justify-content:space-between;justify-content:space-between;margin:",[0,10]," ",[0,0],"}\n.",[1],"to-error{color:red}\n.",[1],"answer-jiexi1{-webkit-justify-content:space-evenly;justify-content:space-evenly;vertical-align:middle}\n.",[1],"answer-jiexi{background-color:#fff;box-shadow:",[0,0]," ",[0,0]," ",[0,12]," ",[0,0]," rgba(0,0,0,.09);margin:",[0,50]," ",[0,40],";padding:",[0,36],"!important}\n.",[1],"date{background:-webkit-linear-gradient(left,#fff,#fff);border-radius:",[0,15],";color:#fff;display:-webkit-flex;display:flex;-webkit-flex-direction:row;flex-direction:row;font-size:",[0,25],";height:",[0,50],";line-height:",[0,50],";margin:",[0,31],";width:",[0,690],"}\n.",[1],"red-block{height:",[0,24],";position:relative;width:",[0,10],"}\n.",[1],"questionView .",[1],"headView{-webkit-align-items:center;align-items:center;display:-webkit-flex;display:flex;padding-left:",[0,36],";padding-right:",[0,30],"}\n.",[1],"questionView .",[1],"headView .",[1],"red-block{height:",[0,24],";margin-right:",[0,8],";position:relative;width:",[0,10],"}\n.",[1],"image1{display:-webkit-flex;display:flex;-webkit-justify-content:center;justify-content:center}\n.",[1],"image2{background:#fff;border-radius:",[0,14],";box-shadow:0 ",[0,4]," ",[0,8]," 0 rgba(0,0,0,.06);height:200px;margin:0 auto ",[0,24],";overflow:hidden;width:87%}\n.",[1],"questionView .",[1],"headView .",[1],"queType{color:#000;-webkit-flex:1;flex:1;font-family:PingFangSC-Medium,PingFang SC;font-size:",[0,28],";font-weight:500;height:",[0,40],";line-height:",[0,40],"}\n.",[1],"questionView .",[1],"headView .",[1],"countView{color:rgba(0,0,0,.5);display:-webkit-inline-flex;display:inline-flex;font-family:PingFangSC-Regular,PingFang SC;font-size:",[0,20],";font-weight:400;height:",[0,40],";line-height:",[0,40],";text-align:right}\n.",[1],"questionView .",[1],"headView .",[1],"countView .",[1],"prev{font-size:0;height:",[0,30],";line-height:",[0,40],";width:",[0,30],"}\n.",[1],"questionView .",[1],"headView .",[1],"countView .",[1],"prev wx-image{display:inline-block;height:",[0,30],";vertical-align:middle;width:",[0,30],"}\n.",[1],"questionView .",[1],"headView .",[1],"countView .",[1],"process{margin:0 ",[0,20],"}\n.",[1],"questionView .",[1],"headView .",[1],"countView .",[1],"next{font-size:0;height:",[0,30],";line-height:",[0,40],";width:",[0,30],"}\n.",[1],"daan1{color:#00d836}\n.",[1],"daan2{color:red}\n.",[1],"liangtou{border:",[0,1]," solid #fff;display:-webkit-flex;display:flex;height:",[0,60],";-webkit-justify-content:space-between;justify-content:space-between;padding:0 10px;vertical-align:middle}\nwx-radio .",[1],"wx-radio-input{background:none;border:",[0,4]," solid #8c8c8c;border-radius:50%;height:",[0,25],";width:",[0,25],"}\nwx-radio .",[1],"wx-radio-input.",[1],"wx-radio-input-checked{background-color:#fff!important;border:",[0,4]," solid #8c8c8c!important}\nwx-radio .",[1],"wx-radio-input.",[1],"wx-radio-input-checked::before{background:#8c8c8c;border-radius:50%;content:\x22\x22;height:80%;transform:translate(-50%,-50%) scale(1);-webkit-transform:translate(-50%,-50%) scale(1);width:80%}\n.",[1],"dibu1{color:#fff;display:-webkit-flex;display:flex;font-size:",[0,24],";height:",[0,60],";-webkit-justify-content:center;justify-content:center}\n.",[1],"jiucuo{height:",[0,50],";position:relative;width:",[0,100],"}\n",],"Some selectors are not allowed in component wxss, including tag name selectors, ID selectors, and attribute selectors.(./pages/shouchangxiangqin/shouchangxiangqin.wxss:1:3070)",{path:"./pages/shouchangxiangqin/shouchangxiangqin.wxss"});
}