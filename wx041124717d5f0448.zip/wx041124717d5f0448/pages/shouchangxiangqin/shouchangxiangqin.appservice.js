$gwx_XC_18=function(_,_v,_n,_p,_s,_wp,_wl,$gwn,$gwl,$gwh,wh,$gstack,$gwrt,gra,grb,TestTest,wfor,_ca,_da,_r,_rz,_o,_oz,_1,_1z,_2,_2z,_m,_mz,nv_getDate,nv_getRegExp,nv_console,nv_parseInt,nv_parseFloat,nv_isNaN,nv_isFinite,nv_decodeURI,nv_decodeURIComponent,nv_encodeURI,nv_encodeURIComponent,$gdc,nv_JSON,_af,_gv,_ai,_grp,_gd,_gapi,$ixc,_ic,_w,_ev,_tsd){return function(path,global){
if(typeof global==='undefined'){if (typeof __GWX_GLOBAL__==='undefined')global={};else global=__GWX_GLOBAL__;}if(typeof __WXML_GLOBAL__ === 'undefined') {__WXML_GLOBAL__={};
}__WXML_GLOBAL__.modules = __WXML_GLOBAL__.modules || {};
var e_={}
if(typeof(global.entrys)==='undefined')global.entrys={};e_=global.entrys;
var d_={}
if(typeof(global.defines)==='undefined')global.defines={};d_=global.defines;
var f_={}
if(typeof(global.modules)==='undefined')global.modules={};f_=global.modules || {};
var p_={}
__WXML_GLOBAL__.ops_cached = __WXML_GLOBAL__.ops_cached || {}
__WXML_GLOBAL__.ops_set = __WXML_GLOBAL__.ops_set || {};
__WXML_GLOBAL__.ops_init = __WXML_GLOBAL__.ops_init || {};
var z=__WXML_GLOBAL__.ops_set.$gwx_XC_18 || [];
function gz$gwx_XC_18_1(){
if( __WXML_GLOBAL__.ops_cached.$gwx_XC_18_1)return __WXML_GLOBAL__.ops_cached.$gwx_XC_18_1
__WXML_GLOBAL__.ops_cached.$gwx_XC_18_1=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
Z([[6],[[7],[3,'subject']],[3,'image']])
Z([[2,'=='],[[6],[[6],[[7],[3,'subject']],[3,'answer']],[3,'length']],[1,1]])
Z([3,'selectClick'])
Z([3,'anniu'])
Z([[6],[[7],[3,'subject']],[3,'optionC']])
Z([[6],[[7],[3,'subject']],[3,'optionD']])
Z(z[2])
Z(z[4])
Z(z[5])
Z([[7],[3,'showAnswer']])
Z([3,'collect'])
Z([[2,'!'],[[7],[3,'shoucang']]])
Z([[7],[3,'shoucang']])
Z([[2,'>'],[[7],[3,'totalScore']],[[2,'-'],[1,1]]])
Z([[2,'>'],[[7],[3,'totalError']],[1,0]])
})(__WXML_GLOBAL__.ops_cached.$gwx_XC_18_1);return __WXML_GLOBAL__.ops_cached.$gwx_XC_18_1
}
__WXML_GLOBAL__.ops_set.$gwx_XC_18=z;
__WXML_GLOBAL__.ops_init.$gwx_XC_18=true;
var x=['./pages/shouchangxiangqin/shouchangxiangqin.wxml'];d_[x[0]]={}
var m0=function(e,s,r,gg){
var z=gz$gwx_XC_18_1()
var lAD=_v()
_(r,lAD)
if(_oz(z,0,e,s,gg)){lAD.wxVkey=1
}
var aBD=_v()
_(r,aBD)
if(_oz(z,1,e,s,gg)){aBD.wxVkey=1
var bED=_mz(z,'radio-group',['bindchange',2,'class',1],[],e,s,gg)
var oFD=_v()
_(bED,oFD)
if(_oz(z,4,e,s,gg)){oFD.wxVkey=1
}
var xGD=_v()
_(bED,xGD)
if(_oz(z,5,e,s,gg)){xGD.wxVkey=1
}
oFD.wxXCkey=1
xGD.wxXCkey=1
_(aBD,bED)
}
else{aBD.wxVkey=2
var oHD=_n('checkbox-group')
_rz(z,oHD,'bindchange',6,e,s,gg)
var fID=_v()
_(oHD,fID)
if(_oz(z,7,e,s,gg)){fID.wxVkey=1
}
var cJD=_v()
_(oHD,cJD)
if(_oz(z,8,e,s,gg)){cJD.wxVkey=1
}
fID.wxXCkey=1
cJD.wxXCkey=1
_(aBD,oHD)
}
var tCD=_v()
_(r,tCD)
if(_oz(z,9,e,s,gg)){tCD.wxVkey=1
var hKD=_n('view')
_rz(z,hKD,'bindtap',10,e,s,gg)
var oLD=_v()
_(hKD,oLD)
if(_oz(z,11,e,s,gg)){oLD.wxVkey=1
}
var cMD=_v()
_(hKD,cMD)
if(_oz(z,12,e,s,gg)){cMD.wxVkey=1
}
oLD.wxXCkey=1
cMD.wxXCkey=1
_(tCD,hKD)
}
var eDD=_v()
_(r,eDD)
if(_oz(z,13,e,s,gg)){eDD.wxVkey=1
var oND=_v()
_(eDD,oND)
if(_oz(z,14,e,s,gg)){oND.wxVkey=1
}
oND.wxXCkey=1
}
lAD.wxXCkey=1
aBD.wxXCkey=1
tCD.wxXCkey=1
eDD.wxXCkey=1
return r
}
e_[x[0]]={f:m0,j:[],i:[],ti:[],ic:[]}
if(path&&e_[path]){
return function(env,dd,global){$gwxc=0;var root={"tag":"wx-page"};root.children=[]
;g="$gwx_XC_18";var main=e_[path].f
if (typeof global==="undefined")global={};global.f=$gdc(f_[path],"",1);
try{
main(env,{},root,global);
_tsd(root)
}catch(err){
console.log(err)
}
;g="";
return root;
}
}
}
}(__g.a,__g.b,__g.c,__g.d,__g.e,__g.f,__g.g,__g.h,__g.i,__g.j,__g.k,__g.l,__g.m,__g.n,__g.o,__g.p,__g.q,__g.r,__g.s,__g.t,__g.u,__g.v,__g.w,__g.x,__g.y,__g.z,__g.A,__g.B,__g.C,__g.D,__g.E,__g.F,__g.G,__g.H,__g.I,__g.J,__g.K,__g.L,__g.M,__g.N,__g.O,__g.P,__g.Q,__g.R,__g.S,__g.T,__g.U,__g.V,__g.W,__g.X,__g.Y,__g.Z,__g.aa);if(__vd_version_info__.delayedGwx||false)$gwx_XC_18();	if (__vd_version_info__.delayedGwx) __wxAppCode__['pages/shouchangxiangqin/shouchangxiangqin.wxml'] = [$gwx_XC_18, './pages/shouchangxiangqin/shouchangxiangqin.wxml'];else __wxAppCode__['pages/shouchangxiangqin/shouchangxiangqin.wxml'] = $gwx_XC_18( './pages/shouchangxiangqin/shouchangxiangqin.wxml' );
	;__wxRoute = "pages/shouchangxiangqin/shouchangxiangqin";__wxRouteBegin = true;__wxAppCurrentFile__="pages/shouchangxiangqin/shouchangxiangqin.js";define("pages/shouchangxiangqin/shouchangxiangqin.js",function(require,module,exports,window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){
"use strict";var t=require("../../@babel/runtime/helpers/objectSpread2"),e=getApp(),o=wx.cloud.database(),a=o.collection("tiku_collects"),s=o.command,c=[];Page({data:{errorOptions:[],showAnswer:!1,percent:0,total:0,isSelect:!1,subject:null,userSelect:"",userScore:0,totalScore:-1,totalError:0,current:1},onLoad:function(t){var e=this;console.log("",t),a.doc(t.id).get().then((function(t){console.log("",t),e.setData({subject:t.data})}))},selectClick:function(t){console.log(t.detail.value),this.setData({userSelect:t.detail.value})},submit:function(){this.setData({showAnswer:!1});var t=this.data.userSelect;if(!t||t.length<1)wx.showToast({icon:"none",title:"请做选择"});else{var e=this.data.current;if(this.setData({percent:(e/c.length*100).toFixed(1)}),console.log("",t),console.log("",this.data.subject.answer),t instanceof Array&&(console.log(""),t=t.sort().toString()),this.data.subject.answer==t)console.log(""+e),this.setData({userScore:this.data.userScore+1});else{var a=this.data.subject;a.userSelect=t,this.data.errorOptions.push(a);var s={};Object.assign(s,a),delete s._id;var n=wx.getStorageSync("user")||{};s.nickName=n&&n.nickName?n.nickName:"未登陆用户",console.log("",s),o.collection("tiku_errors").add({data:s}).then((function(t){console.log("",t)})),console.log("",a)}if(e+1>c.length){var l=this.data.userScore;return console.log(""+l),console.log("",this.data.errorOptions),this.setData({totalScore:l,totalError:this.data.errorOptions.length,hideButton:!0}),wx.showToast({icon:"none",title:"已经最后一道啦"}),void this.addScore(l)}var r=c[e];this.setData({userSelect:"",subject:r,current:e+1,isSelect:!1})}},seeError:function(){console.log(""),wx.switchTab({url:"/pages/errorList/errorList"})},collect:function(){var e=this;wx.cloud.database().collection("tiku_collects").add({data:t({},this.data.subject)}).then((function(t){e.setData({shoucang:!0}),wx.showToast({title:"收藏成功"})})).catch((function(t){console.log(t),wx.cloud.database().collection("tiku_collects").doc(e.data.subject._id).remove().then((function(t){e.setData({shoucang:!1}),console.log(t),wx.showToast({title:"取消成功"})}))}))},addScore:function(t){e.globalData.userInfo&&e.globalData.userInfo.name&&(console.log(t),o.collection("tiku_users").doc(e.globalData.openid).update({data:{score:s.inc(t)}}).then((function(t){wx.showToast({title:"积分生效"})})))},ok:function(){var t=this,e=this.data.userSelect;!e||e.length<1?wx.showToast({icon:"none",title:"请做选择"}):(this.setData({showAnswer:!0}),wx.cloud.database().collection("tiku_collects").where({_id:wx.cloud.database().RegExp({regexp:this.data.subject._id,options:"i"})}).get().then((function(e){console.log("😄嘻嘻哈哈",e),console.log("😄嘻嘻哈哈",e);var o=e.data[0],a=t.data.subject;console.log("😄嘻嘻哈哈",o),console.log("😄嘻嘻哈哈",a),(a=o)?t.setData({shoucang:!0}):t.setData({shoucang:!1})})))},previewImg:function(t){var e=t.currentTarget.dataset.tp;wx.previewImage({urls:e})}});
},{isPage:true,isComponent:true,currentFile:'pages/shouchangxiangqin/shouchangxiangqin.js'});require("pages/shouchangxiangqin/shouchangxiangqin.js");