var t = require("../../@babel/runtime/helpers/objectSpread2"), e = getApp(), o = wx.cloud.database(), a = o.collection("tiku_collects"), s = o.command, c = [];

Page({
    data: {
        errorOptions: [],
        showAnswer: !1,
        percent: 0,
        total: 0,
        isSelect: !1,
        subject: null,
        userSelect: "",
        userScore: 0,
        totalScore: -1,
        totalError: 0,
        current: 1
    },
    onLoad: function(t) {
        var e = this;
        console.log("", t), a.doc(t.id).get().then(function(t) {
            console.log("", t), e.setData({
                subject: t.data
            });
        });
    },
    selectClick: function(t) {
        console.log(t.detail.value), this.setData({
            userSelect: t.detail.value
        });
    },
    submit: function() {
        this.setData({
            showAnswer: !1
        });
        var t = this.data.userSelect;
        if (!t || t.length < 1) wx.showToast({
            icon: "none",
            title: "请做选择"
        }); else {
            var e = this.data.current;
            if (this.setData({
                percent: (e / c.length * 100).toFixed(1)
            }), console.log("", t), console.log("", this.data.subject.answer), t instanceof Array && (console.log(""), 
            t = t.sort().toString()), this.data.subject.answer == t) console.log("" + e), this.setData({
                userScore: this.data.userScore + 1
            }); else {
                var a = this.data.subject;
                a.userSelect = t, this.data.errorOptions.push(a);
                var s = {};
                Object.assign(s, a), delete s._id;
                var n = wx.getStorageSync("user") || {};
                s.nickName = n && n.nickName ? n.nickName : "未登陆用户", console.log("", s), o.collection("tiku_errors").add({
                    data: s
                }).then(function(t) {
                    console.log("", t);
                }), console.log("", a);
            }
            if (e + 1 > c.length) {
                var l = this.data.userScore;
                return console.log("" + l), console.log("", this.data.errorOptions), this.setData({
                    totalScore: l,
                    totalError: this.data.errorOptions.length,
                    hideButton: !0
                }), wx.showToast({
                    icon: "none",
                    title: "已经最后一道啦"
                }), void this.addScore(l);
            }
            var r = c[e];
            this.setData({
                userSelect: "",
                subject: r,
                current: e + 1,
                isSelect: !1
            });
        }
    },
    seeError: function() {
        console.log(""), wx.switchTab({
            url: "/pages/errorList/errorList"
        });
    },
    collect: function() {
        var e = this;
        wx.cloud.database().collection("tiku_collects").add({
            data: t({}, this.data.subject)
        }).then(function(t) {
            e.setData({
                shoucang: !0
            }), wx.showToast({
                title: "收藏成功"
            });
        }).catch(function(t) {
            console.log(t), wx.cloud.database().collection("tiku_collects").doc(e.data.subject._id).remove().then(function(t) {
                e.setData({
                    shoucang: !1
                }), console.log(t), wx.showToast({
                    title: "取消成功"
                });
            });
        });
    },
    addScore: function(t) {
        e.globalData.userInfo && e.globalData.userInfo.name && (console.log(t), o.collection("tiku_users").doc(e.globalData.openid).update({
            data: {
                score: s.inc(t)
            }
        }).then(function(t) {
            wx.showToast({
                title: "积分生效"
            });
        }));
    },
    ok: function() {
        var t = this, e = this.data.userSelect;
        !e || e.length < 1 ? wx.showToast({
            icon: "none",
            title: "请做选择"
        }) : (this.setData({
            showAnswer: !0
        }), wx.cloud.database().collection("tiku_collects").where({
            _id: wx.cloud.database().RegExp({
                regexp: this.data.subject._id,
                options: "i"
            })
        }).get().then(function(e) {
            console.log("😄嘻嘻哈哈", e), console.log("😄嘻嘻哈哈", e);
            var o = e.data[0], a = t.data.subject;
            console.log("😄嘻嘻哈哈", o), console.log("😄嘻嘻哈哈", a), (a = o) ? t.setData({
                shoucang: !0
            }) : t.setData({
                shoucang: !1
            });
        }));
    },
    previewImg: function(t) {
        var e = t.currentTarget.dataset.tp;
        wx.previewImage({
            urls: e
        });
    }
});