var t = wx.cloud.database(), e = getApp();

Page({
    data: {
        topImgs: [ {
            url: "/images/dili.png",
            type: "地理"
        }, {
            url: "/images/lishi.png",
            type: "历史"
        } ]
    },
    onLoad: function() {},
    onShow: function() {
        var e = this, a = t.command.aggregate;
        t.collection("tiku_exams").aggregate().group({
            _id: "$type",
            num: a.sum(1)
        }).end().then(function(t) {
            console.log("", t), e.setData({
                list: t.list
            });
        });
    },
    goQuestionList: function(t) {
        e.globalData.userInfo.name ? wx.navigateTo({
            url: "/pages/examList/examList?type=" + t.currentTarget.dataset.type
        }) : wx.switchTab({
            url: "/pages/me/me",
            success: function(t) {
                wx.showToast({
                    icon: "none",
                    title: "请先登录认证"
                });
            }
        });
    },
    goRandom: function() {
        e.globalData.userInfo.name ? wx.navigateTo({
            url: "/pages/questions/questions"
        }) : wx.switchTab({
            url: "/pages/me/me",
            success: function(t) {
                wx.showToast({
                    icon: "none",
                    title: "请先登录认证"
                });
            }
        });
    }
});