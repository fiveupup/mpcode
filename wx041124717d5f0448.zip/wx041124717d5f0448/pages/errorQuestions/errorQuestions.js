getApp();

var t = wx.cloud.database(), a = null, e = [];

Page({
    data: {
        total: 0,
        current: 0
    },
    onLoad: function(t) {
        a = t, this.getData();
    },
    getData: function() {
        var o = this;
        t.collection("tiku_errors").where({
            type: a.type1,
            type2: a.type2
        }).get().then(function(t) {
            e = t.data, console.log("", e);
            var a = e[0];
            console.log("", a), o.setData({
                current: 0,
                subject: a,
                total: e.length
            });
        });
    },
    pre: function() {
        var t = this.data.current;
        t <= 0 ? wx.showToast({
            icon: "error",
            title: "已是第一道"
        }) : (t -= 1, this.setData({
            current: t,
            subject: e[t]
        }));
    },
    next: function() {
        var t = this.data.current;
        t >= e.length - 1 ? wx.showToast({
            icon: "error",
            title: "已是最后一道"
        }) : (t += 1, this.setData({
            current: t,
            subject: e[t]
        }));
    },
    removeError: function(a) {
        var e = this, o = a.currentTarget.dataset.subject._id;
        t.collection("tiku_errors").doc(o).remove().then(function(t) {
            console.log("", t), t.stats && t.stats.removed > 0 ? (wx.showToast({
                title: "删除成功"
            }), e.getData()) : wx.showToast({
                icon: "error",
                title: "网络不给力"
            });
        });
    },
    getValue: function(t) {
        console.log(t.detail.value);
        var a = t.detail.value;
        this.setData({
            inputValue: a
        });
    },
    baocuoanniu: function() {
        this.setData({
            isShowConfirm: !0
        });
    },
    selectClick11: function(t) {
        console.log(t.detail.value), this.setData({
            jiucuo: t.detail.value
        });
    },
    formSubmit1: function(t) {
        var a = this, e = t.detail.value;
        console.log(this.data.subject._id), wx.cloud.database().collection("tiku_errors").doc(this.data.subject._id).update({
            data: {
                tikuerrors: e.tikuerrors
            }
        }).then(function(t) {
            wx.showToast({
                title: "反馈成功"
            }), a.setData({
                showModalStatus: !1
            });
        });
    },
    clickme: function() {
        this.showModal();
    },
    showModal: function() {
        var t = wx.createAnimation({
            duration: 200,
            timingFunction: "linear",
            delay: 0
        });
        this.animation = t, t.translateY(300).step(), this.setData({
            animationData: t.export(),
            showModalStatus: !0
        }), setTimeout(function() {
            t.translateY(0).step(), this.setData({
                animationData: t.export()
            });
        }.bind(this), 200);
    },
    hideModal: function() {
        var t = wx.createAnimation({
            duration: 200,
            timingFunction: "linear",
            delay: 0
        });
        this.animation = t, t.translateY(300).step(), this.setData({
            animationData: t.export()
        }), setTimeout(function() {
            t.translateY(0).step(), this.setData({
                animationData: t.export(),
                showModalStatus: !1
            });
        }.bind(this), 200);
    },
    previewImg: function(t) {
        var a = t.currentTarget.dataset.tp;
        wx.previewImage({
            urls: a
        });
    },
    onShareTimeline: function() {
        return {
            title: "天美史论1000题",
            imageUrl: "https://636c-cloud1-8gs7t7f49b4c97d8-1309642353.tcb.qcloud.la/cloudbase-cms/upload/2022-04-24/euhb16l1ane9x0h0m9q7r12rchk95or3_.png"
        };
    }
});