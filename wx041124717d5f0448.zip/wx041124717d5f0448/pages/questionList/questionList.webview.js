$gwx_XC_15=function(_,_v,_n,_p,_s,_wp,_wl,$gwn,$gwl,$gwh,wh,$gstack,$gwrt,gra,grb,TestTest,wfor,_ca,_da,_r,_rz,_o,_oz,_1,_1z,_2,_2z,_m,_mz,nv_getDate,nv_getRegExp,nv_console,nv_parseInt,nv_parseFloat,nv_isNaN,nv_isFinite,nv_decodeURI,nv_decodeURIComponent,nv_encodeURI,nv_encodeURIComponent,$gdc,nv_JSON,_af,_gv,_ai,_grp,_gd,_gapi,$ixc,_ic,_w,_ev,_tsd){return function(path,global){
if(typeof global==='undefined'){if (typeof __GWX_GLOBAL__==='undefined')global={};else global=__GWX_GLOBAL__;}if(typeof __WXML_GLOBAL__ === 'undefined') {__WXML_GLOBAL__={};
}__WXML_GLOBAL__.modules = __WXML_GLOBAL__.modules || {};
var e_={}
if(typeof(global.entrys)==='undefined')global.entrys={};e_=global.entrys;
var d_={}
if(typeof(global.defines)==='undefined')global.defines={};d_=global.defines;
var f_={}
if(typeof(global.modules)==='undefined')global.modules={};f_=global.modules || {};
var p_={}
__WXML_GLOBAL__.ops_cached = __WXML_GLOBAL__.ops_cached || {}
__WXML_GLOBAL__.ops_set = __WXML_GLOBAL__.ops_set || {};
__WXML_GLOBAL__.ops_init = __WXML_GLOBAL__.ops_init || {};
var z=__WXML_GLOBAL__.ops_set.$gwx_XC_15 || [];
function gz$gwx_XC_15_1(){
if( __WXML_GLOBAL__.ops_cached.$gwx_XC_15_1)return __WXML_GLOBAL__.ops_cached.$gwx_XC_15_1
__WXML_GLOBAL__.ops_cached.$gwx_XC_15_1=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
Z([3,'#fff'])
Z([3,'__l'])
Z(z[0])
Z([3,'-1'])
Z([1,false])
Z([3,'585bbb2e-1'])
Z([[4],[[5],[1,'default']]])
Z([3,'myPage'])
Z([[2,'+'],[[2,'+'],[[2,'+'],[[2,'+'],[[2,'+'],[1,'overflow-x:'],[1,'hidden']],[1,';']],[1,'overflow-y:']],[[2,'?:'],[[7],[3,'isShowTips']],[1,'auto'],[1,'scroll']]],[1,';']])
Z([3,'headView'])
Z([[2,'=='],[[7],[3,'type']],[1,'中国美术史（上）']])
Z([3,'https://636c-cloud1-8gs7t7f49b4c97d8-1309642353.tcb.qcloud.la/cloudbase-cms/upload/2022-04-26/gl8kudsol2kkeo5xng68dc43bpu0o6mc_.gif'])
Z([3,'width:750rpx;height:530rpx;'])
Z([[2,'=='],[[7],[3,'type']],[1,'中国美术史（下）']])
Z([3,'https://636c-cloud1-8gs7t7f49b4c97d8-1309642353.tcb.qcloud.la/cloudbase-cms/upload/2022-04-26/tmmmr1lnhxin49assbzo9gcsdzeaxa1r_.gif'])
Z(z[12])
Z([[2,'=='],[[7],[3,'type']],[1,'外国美术史（上）']])
Z([3,'https://636c-cloud1-8gs7t7f49b4c97d8-1309642353.tcb.qcloud.la/cloudbase-cms/upload/2022-04-26/l04v2lw7cvteghmpnqt2subnq0vpv703_.gif'])
Z(z[12])
Z([[2,'=='],[[7],[3,'type']],[1,'外国美术史（下）']])
Z([3,'https://636c-cloud1-8gs7t7f49b4c97d8-1309642353.tcb.qcloud.la/cloudbase-cms/upload/2022-04-26/0y3a7bor5a9ju3j29oko9ma2b2fz1fn8_.gif'])
Z(z[12])
Z([[2,'=='],[[7],[3,'type']],[1,'世界设计史（上）']])
Z([3,'https://636c-cloud1-8gs7t7f49b4c97d8-1309642353.tcb.qcloud.la/cloudbase-cms/upload/2022-04-26/luc8d6nuf47pyr9mygp80rthpnbol8k3_.gif'])
Z(z[12])
Z([[2,'=='],[[7],[3,'type']],[1,'世界设计史（下）']])
Z([3,'https://636c-cloud1-8gs7t7f49b4c97d8-1309642353.tcb.qcloud.la/cloudbase-cms/upload/2022-04-26/czu8h6m24jfqu5afd4a1u6jq7qa5rbmw_.gif'])
Z(z[12])
Z([3,'scoreView'])
Z([3,'baseProgress'])
Z([3,'subjectName'])
Z([a,[[7],[3,'type']]])
Z([3,'top0'])
Z([[7],[3,'list']])
Z([3,'index'])
Z([3,'goDetail'])
Z([3,'item'])
Z([[6],[[7],[3,'item']],[3,'_id']])
Z([3,'type'])
Z([3,'/images/mine-head.png'])
Z([a,[3,' '],[[6],[[7],[3,'item']],[3,'_id']],[3,'('],[[6],[[7],[3,'item']],[3,'num']],[3,'道题)']])
Z([3,'btn'])
Z([3,'去答题  \x3e'])
Z([3,'btn1'])
Z([3,'dibu1'])
Z([3,'---'])
Z(z[44])
Z([3,'hhh '])
Z([3,'dibu'])
Z([3,'题库持续更新中'])
})(__WXML_GLOBAL__.ops_cached.$gwx_XC_15_1);return __WXML_GLOBAL__.ops_cached.$gwx_XC_15_1
}
__WXML_GLOBAL__.ops_set.$gwx_XC_15=z;
__WXML_GLOBAL__.ops_init.$gwx_XC_15=true;
var x=['./pages/questionList/questionList.wxml'];d_[x[0]]={}
var m0=function(e,s,r,gg){
var z=gz$gwx_XC_15_1()
var oBV=_mz(z,'top-navbar',['bg',0,'bind:__l',1,'iconColor',1,'paddingTop',2,'tabbarBg',3,'vueId',4,'vueSlots',5],[],e,s,gg)
var xCV=_mz(z,'view',['class',7,'style',1],[],e,s,gg)
var oDV=_n('view')
_rz(z,oDV,'class',9,e,s,gg)
var fEV=_v()
_(oDV,fEV)
if(_oz(z,10,e,s,gg)){fEV.wxVkey=1
var lKV=_mz(z,'image',['src',11,'style',1],[],e,s,gg)
_(fEV,lKV)
}
var cFV=_v()
_(oDV,cFV)
if(_oz(z,13,e,s,gg)){cFV.wxVkey=1
var aLV=_mz(z,'image',['src',14,'style',1],[],e,s,gg)
_(cFV,aLV)
}
var hGV=_v()
_(oDV,hGV)
if(_oz(z,16,e,s,gg)){hGV.wxVkey=1
var tMV=_mz(z,'image',['src',17,'style',1],[],e,s,gg)
_(hGV,tMV)
}
var oHV=_v()
_(oDV,oHV)
if(_oz(z,19,e,s,gg)){oHV.wxVkey=1
var eNV=_mz(z,'image',['src',20,'style',1],[],e,s,gg)
_(oHV,eNV)
}
var cIV=_v()
_(oDV,cIV)
if(_oz(z,22,e,s,gg)){cIV.wxVkey=1
var bOV=_mz(z,'image',['src',23,'style',1],[],e,s,gg)
_(cIV,bOV)
}
var oJV=_v()
_(oDV,oJV)
if(_oz(z,25,e,s,gg)){oJV.wxVkey=1
var oPV=_mz(z,'image',['src',26,'style',1],[],e,s,gg)
_(oJV,oPV)
}
fEV.wxXCkey=1
cFV.wxXCkey=1
hGV.wxXCkey=1
oHV.wxXCkey=1
cIV.wxXCkey=1
oJV.wxXCkey=1
_(xCV,oDV)
var xQV=_n('view')
_rz(z,xQV,'class',28,e,s,gg)
var oRV=_n('view')
_rz(z,oRV,'class',29,e,s,gg)
var fSV=_n('view')
_rz(z,fSV,'class',30,e,s,gg)
var cTV=_oz(z,31,e,s,gg)
_(fSV,cTV)
_(oRV,fSV)
var hUV=_n('view')
_rz(z,hUV,'class',32,e,s,gg)
var oVV=_v()
_(hUV,oVV)
var cWV=function(lYV,oXV,aZV,gg){
var e2V=_mz(z,'view',['bindtap',35,'class',1,'data-type2',2],[],lYV,oXV,gg)
var b3V=_n('view')
var o4V=_mz(z,'image',['class',38,'src',1],[],lYV,oXV,gg)
_(b3V,o4V)
var x5V=_n('text')
var o6V=_oz(z,40,lYV,oXV,gg)
_(x5V,o6V)
_(b3V,x5V)
_(e2V,b3V)
var f7V=_n('text')
_rz(z,f7V,'class',41,lYV,oXV,gg)
var c8V=_oz(z,42,lYV,oXV,gg)
_(f7V,c8V)
var h9V=_n('text')
_rz(z,h9V,'class',43,lYV,oXV,gg)
_(f7V,h9V)
_(e2V,f7V)
_(aZV,e2V)
return aZV
}
oVV.wxXCkey=2
_2z(z,33,cWV,e,s,gg,oVV,'item','index','index')
var o0V=_n('view')
_rz(z,o0V,'class',44,e,s,gg)
var cAW=_oz(z,45,e,s,gg)
_(o0V,cAW)
_(hUV,o0V)
var oBW=_n('text')
_rz(z,oBW,'class',46,e,s,gg)
var lCW=_oz(z,47,e,s,gg)
_(oBW,lCW)
_(hUV,oBW)
var aDW=_n('text')
_rz(z,aDW,'class',48,e,s,gg)
var tEW=_oz(z,49,e,s,gg)
_(aDW,tEW)
_(hUV,aDW)
_(oRV,hUV)
_(xQV,oRV)
_(xCV,xQV)
_(oBV,xCV)
_(r,oBV)
return r
}
e_[x[0]]={f:m0,j:[],i:[],ti:[],ic:[]}
if(path&&e_[path]){
outerGlobal.__wxml_comp_version__=0.02
return function(env,dd,global){$gwxc=0;var root={"tag":"wx-page"};root.children=[]
;g="$gwx_XC_15";var main=e_[path].f
if (typeof global==="undefined")global={};global.f=$gdc(f_[path],"",1);
if(typeof(outerGlobal.__webview_engine_version__)!='undefined'&&outerGlobal.__webview_engine_version__+1e-6>=0.02+1e-6&&outerGlobal.__mergeData__)
{
env=outerGlobal.__mergeData__(env,dd);
}
try{
main(env,{},root,global);
_tsd(root)
if(typeof(outerGlobal.__webview_engine_version__)=='undefined'|| outerGlobal.__webview_engine_version__+1e-6<0.01+1e-6){return _ev(root);}
}catch(err){
console.log(err)
}
;g="";
return root;
}
}
}
}(__g.a,__g.b,__g.c,__g.d,__g.e,__g.f,__g.g,__g.h,__g.i,__g.j,__g.k,__g.l,__g.m,__g.n,__g.o,__g.p,__g.q,__g.r,__g.s,__g.t,__g.u,__g.v,__g.w,__g.x,__g.y,__g.z,__g.A,__g.B,__g.C,__g.D,__g.E,__g.F,__g.G,__g.H,__g.I,__g.J,__g.K,__g.L,__g.M,__g.N,__g.O,__g.P,__g.Q,__g.R,__g.S,__g.T,__g.U,__g.V,__g.W,__g.X,__g.Y,__g.Z,__g.aa);if(__vd_version_info__.delayedGwx||false)$gwx_XC_15();	if (__vd_version_info__.delayedGwx) __wxAppCode__['pages/questionList/questionList.wxml'] = [$gwx_XC_15, './pages/questionList/questionList.wxml'];else __wxAppCode__['pages/questionList/questionList.wxml'] = $gwx_XC_15( './pages/questionList/questionList.wxml' );
	
var noCss=typeof __vd_version_info__!=='undefined'&&__vd_version_info__.noCss===true;if(!noCss){__wxAppCode__['pages/questionList/questionList.wxss'] = setCssToHead(["body{background-color:#fbfbfb;overflow:auto}\n.",[1],"tip{color:#ff5850;font-size:",[0,48],";margin:",[0,40],"}\n.",[1],"item{border-bottom:1px solid #e9e9e9;display:-webkit-flex;display:flex;-webkit-flex:1;flex:1;font-size:",[0,28],";-webkit-justify-content:space-between;justify-content:space-between;margin:",[0,10]," ",[0,30],";padding:",[0,20]," ",[0,10]," ",[0,20]," ",[0,20],"}\n.",[1],"btn{color:#ff5850;padding:",[0,5]," ",[0,20],"}\n.",[1],"btn,.",[1],"btn1{border:1px solid #fff}\n.",[1],"btn1{color:#fff;padding:",[0,5],"}\n.",[1],"type{height:",[0,24],";position:relative;width:",[0,10],"}\n.",[1],"headView{height:",[0,500],"}\n.",[1],"scoreView{background:#fff;border-top-left-radius:",[0,24],";border-top-right-radius:",[0,24],";display:-webkit-flex;display:flex;-webkit-flex-direction:column;flex-direction:column;height:",[0,1780],";overflow:hidden;position:relative;top:",[0,-30],";z-index:200}\n.",[1],"baseProgress{border-bottom:",[0,1]," solid rgba(0,0,0,.1);display:inline-table;height:",[0,226],";padding:0 ",[0,48],";position:relative;width:100%}\n.",[1],"baseProgress .",[1],"subjectName{color:rgba(0,0,0,.8);font-family:PingFangSC-Semibold,PingFang SC;font-size:",[0,44],";font-weight:600;height:",[0,60],";line-height:",[0,60],";margin-bottom:",[0,24],";margin-top:",[0,48],"}\n.",[1],"baseProgress .",[1],"u-active{background:linear-gradient(270deg,#ed3535,#f7cccc)}\n.",[1],"baseProgress .",[1],"tips{color:#352026;font-family:PingFangSC-Regular,PingFang SC;font-size:",[0,18],";font-weight:400;height:",[0,26],";letter-spacing:",[0,0],";line-height:",[0,26],";margin-top:",[0,12],";opacity:.7}\n.",[1],"top{display:-webkit-flex;display:flex;-webkit-justify-content:center;justify-content:center;line-height:",[0,160],";margin:",[0,5],"}\n.",[1],"dibu{color:#979797;font-size:",[0,24],";height:",[0,60],"}\n.",[1],"dibu1{color:#fff}\n",],"Some selectors are not allowed in component wxss, including tag name selectors, ID selectors, and attribute selectors.(./pages/questionList/questionList.wxss:1:1)",{path:"./pages/questionList/questionList.wxss"});
}