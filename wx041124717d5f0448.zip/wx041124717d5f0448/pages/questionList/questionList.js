var e = wx.cloud.database();

getApp();

Page({
    onLoad: function(t) {
        var a = this;
        console.log("", t.type), wx.setNavigationBarTitle({
            title: t.type + "题"
        }), a.setData({
            type: t.type
        });
        var s = e.command.aggregate;
        e.collection("tiku_questions").aggregate().match({
            type: t.type
        }).group({
            _id: "$type2",
            num: s.sum(1)
        }).sort({
            _id: 1
        }).end().then(function(e) {
            console.log("", e), e.list.forEach(function(e) {
                var t = e._id.replace("第", "").replace("组", "");
                t.length > 2 && (t = t.replace("十", ""));
                var s = t.split(""), r = a.tran(s);
                e.sort = r;
            }), e.list.sort(function(e, t) {
                return e.sort - t.sort;
            }), console.log(e.list), a.setData({
                list: e.list
            });
        });
    },
    tran: function(e) {
        var t = "";
        if (e.length > 0) for (var a = 0; a < e.length; a++) {
            var s = e[a];
            if (0 == a && "十" == s && 1 == e.length) t += "10"; else if (0 == a && "十" == s && e.length > 1) t += "1"; else switch (s) {
              case "十":
                t += "0";
                break;

              case "九":
                t += "9";
                break;

              case "八":
                t += "8";
                break;

              case "七":
                t += "7";
                break;

              case "六":
                t += "6";
                break;

              case "五":
                t += "5";
                break;

              case "四":
                t += "4";
                break;

              case "三":
                t += "3";
                break;

              case "二":
                t += "2";
                break;

              case "一":
                t += "1";
            }
        }
        return t;
    },
    goDetail: function(e) {
        var t = this.data.type, a = e.currentTarget.dataset.type2;
        wx.navigateTo({
            url: "/pages/questions/questions?type1=" + t + "&type2=" + a
        });
    },
    onShareAppMessage: function() {
        return {
            title: " ",
            imageUrl: "https://636c-cloud1-8gs7t7f49b4c97d8-1309642353.tcb.qcloud.la/cloudbase-cms/upload/2022-04-24/m936jjv23g0npx2c20s0ldtsgtupfnin_.png"
        };
    },
    onShareTimeline: function() {
        return {
            title: "每天一遍，轻松过线",
            imageUrl: "https://636c-cloud1-8gs7t7f49b4c97d8-1309642353.tcb.qcloud.la/cloudbase-cms/upload/2022-04-24/euhb16l1ane9x0h0m9q7r12rchk95or3_.png"
        };
    }
});