var o = wx.cloud.database(), e = (getApp(), wx.cloud.database().collection("vipauthor"));

Page({
    getValue: function(o) {
        console.log(o.detail.value);
        var e = o.detail.value;
        this.setData({
            inputValue: e
        });
    },
    search: function() {
        var o = this;
        wx.cloud.database().collection("tiku_users").where({
            name: wx.cloud.database().RegExp({
                regexp: this.data.inputValue,
                options: "i"
            })
        }).get().then(function(e) {
            console.log(e), o.setData({
                tiList: e.data
            });
        });
    },
    DeleteSubmit: function(e) {
        var t = e.detail.value;
        console.log(t), o.collection("tiku_users").doc(t.openid).remove({
            complete: function(o) {
                that.setData({
                    finished: !0
                });
            },
            success: function(o) {
                console.log(" ", o), that.setData({
                    opResult2: "已成功删除上面的记录。"
                });
            },
            fail: function(o) {
                wx.showToast({
                    icon: "none",
                    title: "删除记录失败"
                }), console.error("", o);
            }
        });
    },
    formSubmit: function(o) {
        var t = o.detail.value;
        console.log(t), t.name ? t.phone ? t.openid ? e.add({
            data: {
                name: t.name,
                phone: t.phone,
                openid: t.openid
            }
        }).then(function(o) {
            wx.showModal({
                title: "提示",
                content: "确定提交为会员？",
                success: function(o) {
                    o.confirm ? (console.log(""), wx.showToast({
                        title: "提交成功"
                    })) : o.cancel && console.log("");
                }
            });
        }) : wx.showToast({
            icon: "none",
            title: "用户openid"
        }) : wx.showToast({
            icon: "none",
            title: "请填写电话"
        }) : wx.showToast({
            icon: "none",
            title: "请填写姓名"
        });
    }
});