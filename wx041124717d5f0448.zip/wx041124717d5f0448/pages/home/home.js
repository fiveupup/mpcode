var t, e = require("../../@babel/runtime/helpers/defineProperty"), a = getApp();

wx.cloud.database().collection("author");

Page((e(t = {
    data: {
        showList: !1,
        showAdmin1: !1,
        scwidth: 0,
        flag: !1,
        loadingHidden: !1
    },
    getAdmin: function() {
        var t = this;
        wx.cloud.callFunction({
            name: "getOpenid",
            complete: function(e) {
                var a = e.result.openid;
                wx.cloud.database().collection("author").get().then(function(e) {
                    var n = e.data[0]._openid;
                    a === n ? t.setData({
                        showAdmin: !0
                    }) : t.setData({
                        showAdmin: !1
                    });
                });
            }
        });
    },
    qiandao: function() {
        wx.navigateTo({
            url: "/pages/qiandao/qiandao"
        });
    },
    getCurrentDate: function() {
        var t = new Date(), e = t.getDay(), a = new Array("星期日", "星期一", "星期二", "星期三", "星期四", "星期五", "星期六")[e];
        this.setData({
            week: a,
            month: t.getMonth() + 1,
            day: t.getDate()
        });
    },
    getBannerList: function() {
        var t = this;
        wx.cloud.database().collection("tiku_banners").orderBy("sort", "desc").get({
            success: function(e) {
                console.log(e), t.setData({
                    bannerList: e.data
                });
            }
        });
    },
    getCurrentDate303: function() {
        var t = new Date(), e = t.getDay(), a = new Array("星期日", "星期一", "星期二", "星期三", "星期四", "星期五", "星期六")[e];
        this.setData({
            week: a,
            month: t.getMonth() + 1,
            day: t.getDate()
        });
    },
    getBannerLis0t44: function() {
        var t = this;
        wx.cloud.database().collection("tiku_banners").orderBy("sort", "desc").get({
            success: function(e) {
                console.log(e), t.setData({
                    bannerList: e.data
                });
            }
        });
    },
    toBannerD00etail66: function(t) {
        wx.navigateTo({
            url: "/pages/home/bannerDetail/bannerDetail?id=" + t.currentTarget.dataset.id
        });
    },
    goQuesti9onList88: function(t) {
        a.globalData.userInfo.name ? wx.navigateTo({
            url: "/pages/questionList/questionList?type=" + t.currentTarget.dataset.type
        }) : wx.switchTab({
            url: "/pages/me/me",
            success: function(t) {
                wx.showToast({
                    icon: "none",
                    title: "请先登录认证"
                });
            }
        });
    },
    onSub9scribe088: function(t) {
        var e = t.currentTarget.dataset.item;
        wx.requestSubscribeMessage({
            tmplIds: [ "qL1BuG1fSl95882p8PY1lsSuQK6SIwigj5IgbVXFQk8" ],
            success: function(t) {
                "requestSubscribeMessage:ok" === t.errMsg && wx.cloud.callFunction({
                    name: "subscribe",
                    data: {
                        data: e,
                        templateId: "qL1BuG1fSl95882p8PY1lsSuQK6SIwigj5IgbVXFQk8"
                    }
                }).then(function() {
                    wx.showToast({
                        title: "订阅成功",
                        icon: "success",
                        duration: 2e3
                    });
                }).catch(function() {
                    wx.showToast({
                        title: "订阅失败",
                        icon: "success",
                        duration: 2e3
                    });
                });
            }
        });
    },
    goRa99ndom64: function() {
        a.globalData.userInfo.name ? wx.navigateTo({
            url: "/pages/questions/questions"
        }) : wx.switchTab({
            url: "/pages/me/me",
            success: function(t) {
                wx.showToast({
                    icon: "none",
                    title: "请先登录认证"
                });
            }
        });
    },
    toSear88ch467: function() {
        wx.navigateTo({
            url: "/pages/home/search/search"
        });
    },
    onTabItemTap: function(t) {
        var e = Date.parse(new Date()), a = this.data, n = a.clickTabTime, o = a.goodsListScrollTop;
        n && e - n < 2e3 && 0 != o ? wx.pageScrollTo ? wx.pageScrollTo({
            scrollTop: 0
        }) : wx.showModal({
            title: "提示",
            content: "当前微信版本过低，无法使用该功能，请升级到最新微信版本后重试。"
        }) : this.setData({
            clickTabTime: e
        });
    },
    toBannerDetail: function(t) {
        wx.navigateTo({
            url: "/pages/home/bannerDetail/bannerDetail?id=" + t.currentTarget.dataset.id
        });
    }
}, "data", {
    day: "",
    hour: "",
    minute: "",
    second: ""
}), e(t, "onLoad", function(t) {
    var e = this, a = +new Date("2024/12/23 00:00:00");
    setInterval(this.countDown, 1e3, a);
    this.getCurrentDate(), this.getBannerList(), setTimeout(function() {
        e.setData({
            showList: !0,
            loadingHidden: !0
        });
    }, 1500);
}), e(t, "countDown", function(t) {
    var e = t - +new Date();
    this.setData({
        day: Math.floor(e / 864e5) + "",
        hour: Math.floor(e / 36e5 % 24) + "时",
        minute: Math.floor(e / 6e4 % 60) + "分",
        second: Math.floor(e / 1e3 % 60) + "秒"
    }), this.data.day <= 0 && this.data.hour <= 0 && this.data.minute <= 0 && this.data.second <= 0 && (this.setData({
        day: 0,
        hour: 0,
        minute: 0,
        second: 0
    }), clearInterval(timer));
}), e(t, "goQuestionList", function(t) {
    a.globalData.userInfo.name ? a.globalData.userInfo.limit ? wx.switchTab({
        url: "/pages/me/me",
        success: function(t) {
            wx.showToast({
                icon: "none",
                title: ""
            });
        }
    }) : wx.navigateTo({
        url: "/pages/questionList/questionList?type=" + t.currentTarget.dataset.type
    }) : wx.switchTab({
        url: "/pages/me/me",
        success: function(t) {
            wx.showToast({
                icon: "none",
                title: "请先登录认证"
            });
        }
    });
}), e(t, "toAAAA", function(t) {
    a.globalData.userInfo.name ? wx.navigateTo({
        url: "/pages/aaaa/aaaa"
    }) : wx.switchTab({
        url: "/pages/me/me",
        success: function(t) {
            wx.showToast({
                icon: "none",
                title: "请先登录认证"
            });
        }
    });
}), e(t, "goRandom", function() {
    a.globalData.userInfo.name ? wx.navigateTo({
        url: "/pages/questions/questions"
    }) : wx.switchTab({
        url: "/pages/me/me",
        success: function(t) {
            wx.showToast({
                icon: "none",
                title: "请先登录认证"
            });
        }
    });
}), e(t, "onShareAppMessage", function() {
    return {
        title: " ",
        imageUrl: "https://636c-cloud1-8gs7t7f49b4c97d8-1309642353.tcb.qcloud.la/cloudbase-cms/upload/2022-04-24/m936jjv23g0npx2c20s0ldtsgtupfnin_.png"
    };
}), e(t, "onShareTimeline", function() {
    return {
        title: "每天一遍，轻松过线",
        imageUrl: "https://636c-cloud1-8gs7t7f49b4c97d8-1309642353.tcb.qcloud.la/cloudbase-cms/upload/2022-04-24/euhb16l1ane9x0h0m9q7r12rchk95or3_.png"
    };
}), t));