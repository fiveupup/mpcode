Page({
    data: {},
    onLoad: function(t) {
        console.log(t.id), this.getBannerDetail(t.id);
    },
    getBannerDetail: function(t) {
        var e = this;
        wx.cloud.database().collection("tiku_banners").doc(t).get({
            success: function(t) {
                console.log(t), e.setData({
                    banner: t.data
                });
            }
        });
    },
    onShareTimeline: function() {
        return {
            title: "天美史论1000题",
            imageUrl: "https://636c-cloud1-8gs7t7f49b4c97d8-1309642353.tcb.qcloud.la/cloudbase-cms/upload/2022-04-24/euhb16l1ane9x0h0m9q7r12rchk95or3_.png"
        };
    }
});