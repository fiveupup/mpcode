var t = getApp(), e = wx.cloud.database(), o = e.collection("tiku_questions"), a = (wx.cloud.database().collection("tiku_questions"), 
e.collection("sj_sjlx1")), s = e.command, n = [];

Page({
    data: {
        errorOptions: [],
        showAnswer: !1,
        percent: 0,
        total: 0,
        isSelect: !1,
        subject: null,
        userSelect: "",
        userScore: 0,
        totalScore: -1,
        totalError: 0,
        current: 1,
        isShowConfirm: !1,
        shoucang: !1
    },
    onLoad: function(e) {
        var s = this;
        if (1 == (l = t.globalData.xztype)) var l = !0; else if (0 == l) l = !1;
        console.log("", e), e.type1 && e.type2 ? (wx.setNavigationBarTitle({
            title: e.type2 + "答题"
        }), o.where({
            type: e.type1,
            type2: e.type2
        }).get().then(function(t) {
            console.log("", t);
            var e = (n = t.data)[0];
            console.log("", e), s.setData({
                subject: e,
                xztype: l,
                total: n.length
            });
        })) : (wx.setNavigationBarTitle({
            title: "随机答题"
        }), a.aggregate().sample({
            size: t.globalData.randomNum
        }).end().then(function(t) {
            console.log("", t);
            var e = (n = t.list)[0];
            s.setData({
                subject: e,
                xztype: l,
                total: n.length
            });
        })), console.log(t.globalData.userInfo), console.log(t.globalData.userInfo), console.log(t.globalData.userInfo), 
        console.log(t.globalData.userInfo), console.log(t.globalData.userInfo), console.log(t.globalData.userInfo), 
        console.log(t.globalData.userInfo), console.log(t.globalData.userInfo), console.log(t.globalData.userInfo), 
        console.log(t.globalData.userInfo), console.log(t.globalData.userInfo), console.log(t.globalData.userInfo);
    },
    selectClick: function(t) {
        console.log(t.detail.value), this.setData({
            userSelect: t.detail.value
        });
    },
    submit: function() {
        this.setData({
            showAnswer: !1
        });
        var t = this.data.userSelect, o = this.data.current;
        if (this.setData({
            percent: (o / n.length * 100).toFixed(1)
        }), console.log("", t), console.log("", this.data.subject.answer), t instanceof Array) console.log(""), 
        t = t.sort().toString(); else if (this.data.subject.answer == t) console.log("" + o), 
        this.setData({
            userScore: this.data.userScore + 1
        }); else if (this.data.subject.answer == !t || 0 == t.length) console.log("" + o), 
        this.setData({
            userScore: this.data.userScore + 0
        }); else {
            var a = this.data.subject;
            a.userSelect = t, this.data.errorOptions.push(a);
            var s = {};
            Object.assign(s, a), delete s._id;
            var l = wx.getStorageSync("user") || {};
            s.nickName = l && l.nickName ? l.nickName : "未登陆用户", console.log("", s), e.collection("tiku_errors").add({
                data: s
            }).then(function(t) {
                console.log("", t);
            }), console.log("", a);
        }
        if (o + 1 > n.length) {
            var i = this.data.userScore;
            return console.log("" + i), console.log("", this.data.errorOptions), this.setData({
                totalScore: i,
                totalError: this.data.errorOptions.length,
                hideButton: !0
            }), wx.showToast({
                icon: "none",
                title: "已经最后一道啦"
            }), void this.addScore(i);
        }
        var c = n[o];
        this.setData({
            userSelect: "",
            subject: c,
            current: o + 1,
            isSelect: !1
        });
    },
    seeError: function() {
        console.log(""), wx.switchTab({
            url: "/pages/errorList/errorList"
        });
    },
    addScore: function(o) {
        t.globalData.userInfo && t.globalData.userInfo.name && (console.log(o), e.collection("tiku_users").doc(t.globalData.openid).update({
            data: {
                score: s.inc(o)
            }
        }).then(function(t) {
            wx.showToast({
                title: "积分生效"
            });
        }));
    },
    addScoreok: function() {
        if (0 == t.globalData.xztype) {
            wx.showLoading({
                title: "加载中...",
                mask: !0
            });
            var e = this.data.userSelect;
            if (!e || e.length < 1) return void wx.showToast({
                icon: "none",
                title: "请做选择"
            });
            var o = this;
            setTimeout(function() {
                wx.hideLoading(), o.setData({
                    showAnswer: !0
                });
            }, 4e3);
        } else {
            var a = this.data.userSelect;
            if (!a || a.length < 1) return void wx.showToast({
                icon: "none",
                title: "请做选择"
            });
            (o = this).setData({
                showAnswer: !0
            });
        }
    },
    previewImg: function(t) {
        var e = t.currentTarget.dataset.tp;
        wx.previewImage({
            urls: e
        });
    },
    baocuoanniu: function() {
        this.setData({
            isShowConfirm: !0
        });
    },
    getValue: function(t) {
        console.log(t.detail.value);
        var e = t.detail.value;
        this.setData({
            inputValue: e
        });
    },
    selectClick11: function(t) {
        console.log(t.detail.value), this.setData({
            jiucuo: t.detail.value
        });
    },
    formSubmit1: function(t) {
        var e = this, o = detail.value;
        wx.cloud.database().collection("tiku_questions").doc(this.data.subject._id).update({
            data: {
                tikuerrors: o.tikuerrors
            }
        }).then(function(t) {
            wx.showToast({
                title: "反馈成功"
            }), e.setData({
                showModalStatus: !1
            });
        });
    },
    collect: function() {
        var t = this;
        wx.cloud.database().collection("tiku_collects").add({
            data: {
                title: this.data.subject.title,
                image: this.data.subject.image,
                explain: this.data.subject.explain,
                answer: this.data.subject.answer,
                optionA: this.data.subject.optionA,
                optionB: this.data.subject.optionB,
                optionC: this.data.subject.optionC,
                optionD: this.data.subject.optionD,
                type: this.data.subject.type,
                type2: this.data.subject.type2
            }
        }).then(function(e) {
            t.setData({
                shoucang: !0
            }), wx.showToast({
                title: "收藏成功"
            });
        });
    },
    collectoff: function() {
        var t = this;
        wx.cloud.database().collection("tiku_collects").where({
            title: wx.cloud.database().RegExp({
                regexp: this.data.subject.title,
                options: "i"
            })
        }).get().then(function(e) {
            console.log("", e);
            var o = e.data[0]._id;
            wx.cloud.database().collection("tiku_collects").doc(o).remove().then(function(e) {
                t.setData({
                    shoucang: !1
                }), console.log(e), wx.showToast({
                    title: "取消成功"
                });
            });
        });
    },
    clickme: function() {
        this.showModal();
    },
    showModal: function() {
        var t = wx.createAnimation({
            duration: 200,
            timingFunction: "linear",
            delay: 0
        });
        this.animation = t, t.translateY(300).step(), this.setData({
            animationData: t.export(),
            showModalStatus: !0
        }), setTimeout(function() {
            t.translateY(0).step(), this.setData({
                animationData: t.export()
            });
        }.bind(this), 200);
    },
    hideModal: function() {
        var t = wx.createAnimation({
            duration: 200,
            timingFunction: "linear",
            delay: 0
        });
        this.animation = t, t.translateY(300).step(), this.setData({
            animationData: t.export()
        }), setTimeout(function() {
            t.translateY(0).step(), this.setData({
                animationData: t.export(),
                showModalStatus: !1
            });
        }.bind(this), 200);
    },
    onShareAppMessage: function() {
        return {
            title: " ",
            imageUrl: "https://636c-cloud1-8gs7t7f49b4c97d8-1309642353.tcb.qcloud.la/cloudbase-cms/upload/2022-04-24/m936jjv23g0npx2c20s0ldtsgtupfnin_.png"
        };
    },
    onShareTimeline: function() {
        return {
            title: "每天一遍，轻松过线",
            imageUrl: "https://636c-cloud1-8gs7t7f49b4c97d8-1309642353.tcb.qcloud.la/cloudbase-cms/upload/2022-04-24/euhb16l1ane9x0h0m9q7r12rchk95or3_.png"
        };
    }
});