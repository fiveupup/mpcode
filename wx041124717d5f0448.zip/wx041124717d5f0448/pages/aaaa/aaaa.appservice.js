$gwx_XC_0=function(_,_v,_n,_p,_s,_wp,_wl,$gwn,$gwl,$gwh,wh,$gstack,$gwrt,gra,grb,TestTest,wfor,_ca,_da,_r,_rz,_o,_oz,_1,_1z,_2,_2z,_m,_mz,nv_getDate,nv_getRegExp,nv_console,nv_parseInt,nv_parseFloat,nv_isNaN,nv_isFinite,nv_decodeURI,nv_decodeURIComponent,nv_encodeURI,nv_encodeURIComponent,$gdc,nv_JSON,_af,_gv,_ai,_grp,_gd,_gapi,$ixc,_ic,_w,_ev,_tsd){return function(path,global){
if(typeof global==='undefined'){if (typeof __GWX_GLOBAL__==='undefined')global={};else global=__GWX_GLOBAL__;}if(typeof __WXML_GLOBAL__ === 'undefined') {__WXML_GLOBAL__={};
}__WXML_GLOBAL__.modules = __WXML_GLOBAL__.modules || {};
var e_={}
if(typeof(global.entrys)==='undefined')global.entrys={};e_=global.entrys;
var d_={}
if(typeof(global.defines)==='undefined')global.defines={};d_=global.defines;
var f_={}
if(typeof(global.modules)==='undefined')global.modules={};f_=global.modules || {};
var p_={}
__WXML_GLOBAL__.ops_cached = __WXML_GLOBAL__.ops_cached || {}
__WXML_GLOBAL__.ops_set = __WXML_GLOBAL__.ops_set || {};
__WXML_GLOBAL__.ops_init = __WXML_GLOBAL__.ops_init || {};
var z=__WXML_GLOBAL__.ops_set.$gwx_XC_0 || [];
function gz$gwx_XC_0_1(){
if( __WXML_GLOBAL__.ops_cached.$gwx_XC_0_1)return __WXML_GLOBAL__.ops_cached.$gwx_XC_0_1
__WXML_GLOBAL__.ops_cached.$gwx_XC_0_1=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
Z([[7],[3,'xztype']])
Z([[6],[[7],[3,'subject']],[3,'image']])
Z(z[0])
Z([3,'selectClick'])
Z([3,'anniu'])
Z([[6],[[7],[3,'subject']],[3,'optionC']])
Z([[6],[[7],[3,'subject']],[3,'optionD']])
Z(z[3])
Z(z[5])
Z(z[6])
Z([[7],[3,'showAnswer']])
Z([3,'answer-title'])
Z([[2,'!'],[[7],[3,'shoucang']]])
Z([[7],[3,'shoucang']])
Z([3,'collectoff'])
Z(z[13])
Z([[2,'>'],[[7],[3,'totalScore']],[[2,'-'],[1,1]]])
Z([[2,'>'],[[7],[3,'totalError']],[1,0]])
Z([[7],[3,'showModalStatus']])
Z(z[18])
})(__WXML_GLOBAL__.ops_cached.$gwx_XC_0_1);return __WXML_GLOBAL__.ops_cached.$gwx_XC_0_1
}
__WXML_GLOBAL__.ops_set.$gwx_XC_0=z;
__WXML_GLOBAL__.ops_init.$gwx_XC_0=true;
var x=['./pages/aaaa/aaaa.wxml'];d_[x[0]]={}
var m0=function(e,s,r,gg){
var z=gz$gwx_XC_0_1()
var oB=_v()
_(r,oB)
if(_oz(z,0,e,s,gg)){oB.wxVkey=1
var oH=_v()
_(oB,oH)
if(_oz(z,1,e,s,gg)){oH.wxVkey=1
}
oH.wxXCkey=1
}
var xC=_v()
_(r,xC)
if(_oz(z,2,e,s,gg)){xC.wxVkey=1
var cI=_mz(z,'radio-group',['bindchange',3,'class',1],[],e,s,gg)
var oJ=_v()
_(cI,oJ)
if(_oz(z,5,e,s,gg)){oJ.wxVkey=1
}
var lK=_v()
_(cI,lK)
if(_oz(z,6,e,s,gg)){lK.wxVkey=1
}
oJ.wxXCkey=1
lK.wxXCkey=1
_(xC,cI)
}
else{xC.wxVkey=2
var aL=_n('checkbox-group')
_rz(z,aL,'bindchange',7,e,s,gg)
var tM=_v()
_(aL,tM)
if(_oz(z,8,e,s,gg)){tM.wxVkey=1
}
var eN=_v()
_(aL,eN)
if(_oz(z,9,e,s,gg)){eN.wxVkey=1
}
tM.wxXCkey=1
eN.wxXCkey=1
_(xC,aL)
}
var oD=_v()
_(r,oD)
if(_oz(z,10,e,s,gg)){oD.wxVkey=1
var bO=_n('view')
_rz(z,bO,'class',11,e,s,gg)
var oP=_v()
_(bO,oP)
if(_oz(z,12,e,s,gg)){oP.wxVkey=1
}
var xQ=_v()
_(bO,xQ)
if(_oz(z,13,e,s,gg)){xQ.wxVkey=1
var oR=_n('view')
_rz(z,oR,'bindtap',14,e,s,gg)
var fS=_v()
_(oR,fS)
if(_oz(z,15,e,s,gg)){fS.wxVkey=1
}
fS.wxXCkey=1
_(xQ,oR)
}
oP.wxXCkey=1
xQ.wxXCkey=1
_(oD,bO)
}
var fE=_v()
_(r,fE)
if(_oz(z,16,e,s,gg)){fE.wxVkey=1
var cT=_v()
_(fE,cT)
if(_oz(z,17,e,s,gg)){cT.wxVkey=1
}
cT.wxXCkey=1
}
var cF=_v()
_(r,cF)
if(_oz(z,18,e,s,gg)){cF.wxVkey=1
}
var hG=_v()
_(r,hG)
if(_oz(z,19,e,s,gg)){hG.wxVkey=1
}
oB.wxXCkey=1
xC.wxXCkey=1
oD.wxXCkey=1
fE.wxXCkey=1
cF.wxXCkey=1
hG.wxXCkey=1
return r
}
e_[x[0]]={f:m0,j:[],i:[],ti:[],ic:[]}
if(path&&e_[path]){
return function(env,dd,global){$gwxc=0;var root={"tag":"wx-page"};root.children=[]
;g="$gwx_XC_0";var main=e_[path].f
if (typeof global==="undefined")global={};global.f=$gdc(f_[path],"",1);
try{
main(env,{},root,global);
_tsd(root)
}catch(err){
console.log(err)
}
;g="";
return root;
}
}
}
}(__g.a,__g.b,__g.c,__g.d,__g.e,__g.f,__g.g,__g.h,__g.i,__g.j,__g.k,__g.l,__g.m,__g.n,__g.o,__g.p,__g.q,__g.r,__g.s,__g.t,__g.u,__g.v,__g.w,__g.x,__g.y,__g.z,__g.A,__g.B,__g.C,__g.D,__g.E,__g.F,__g.G,__g.H,__g.I,__g.J,__g.K,__g.L,__g.M,__g.N,__g.O,__g.P,__g.Q,__g.R,__g.S,__g.T,__g.U,__g.V,__g.W,__g.X,__g.Y,__g.Z,__g.aa);if(__vd_version_info__.delayedGwx||false)$gwx_XC_0();	if (__vd_version_info__.delayedGwx) __wxAppCode__['pages/aaaa/aaaa.wxml'] = [$gwx_XC_0, './pages/aaaa/aaaa.wxml'];else __wxAppCode__['pages/aaaa/aaaa.wxml'] = $gwx_XC_0( './pages/aaaa/aaaa.wxml' );
	;__wxRoute = "pages/aaaa/aaaa";__wxRouteBegin = true;__wxAppCurrentFile__="pages/aaaa/aaaa.js";define("pages/aaaa/aaaa.js",function(require,module,exports,window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){
"use strict";var t=getApp(),e=wx.cloud.database(),o=e.collection("tiku_questions"),a=(wx.cloud.database().collection("tiku_questions"),e.collection("sj_sjlx1")),s=e.command,n=[];Page({data:{errorOptions:[],showAnswer:!1,percent:0,total:0,isSelect:!1,subject:null,userSelect:"",userScore:0,totalScore:-1,totalError:0,current:1,isShowConfirm:!1,shoucang:!1},onLoad:function(e){var s=this;if(1==(l=t.globalData.xztype))var l=!0;else if(0==l)l=!1;console.log("",e),e.type1&&e.type2?(wx.setNavigationBarTitle({title:e.type2+"答题"}),o.where({type:e.type1,type2:e.type2}).get().then((function(t){console.log("",t);var e=(n=t.data)[0];console.log("",e),s.setData({subject:e,xztype:l,total:n.length})}))):(wx.setNavigationBarTitle({title:"随机答题"}),a.aggregate().sample({size:t.globalData.randomNum}).end().then((function(t){console.log("",t);var e=(n=t.list)[0];s.setData({subject:e,xztype:l,total:n.length})}))),console.log(t.globalData.userInfo),console.log(t.globalData.userInfo),console.log(t.globalData.userInfo),console.log(t.globalData.userInfo),console.log(t.globalData.userInfo),console.log(t.globalData.userInfo),console.log(t.globalData.userInfo),console.log(t.globalData.userInfo),console.log(t.globalData.userInfo),console.log(t.globalData.userInfo),console.log(t.globalData.userInfo),console.log(t.globalData.userInfo)},selectClick:function(t){console.log(t.detail.value),this.setData({userSelect:t.detail.value})},submit:function(){this.setData({showAnswer:!1});var t=this.data.userSelect,o=this.data.current;if(this.setData({percent:(o/n.length*100).toFixed(1)}),console.log("",t),console.log("",this.data.subject.answer),t instanceof Array)console.log(""),t=t.sort().toString();else if(this.data.subject.answer==t)console.log(""+o),this.setData({userScore:this.data.userScore+1});else if(this.data.subject.answer==!t||0==t.length)console.log(""+o),this.setData({userScore:this.data.userScore+0});else{var a=this.data.subject;a.userSelect=t,this.data.errorOptions.push(a);var s={};Object.assign(s,a),delete s._id;var l=wx.getStorageSync("user")||{};s.nickName=l&&l.nickName?l.nickName:"未登陆用户",console.log("",s),e.collection("tiku_errors").add({data:s}).then((function(t){console.log("",t)})),console.log("",a)}if(o+1>n.length){var i=this.data.userScore;return console.log(""+i),console.log("",this.data.errorOptions),this.setData({totalScore:i,totalError:this.data.errorOptions.length,hideButton:!0}),wx.showToast({icon:"none",title:"已经最后一道啦"}),void this.addScore(i)}var c=n[o];this.setData({userSelect:"",subject:c,current:o+1,isSelect:!1})},seeError:function(){console.log(""),wx.switchTab({url:"/pages/errorList/errorList"})},addScore:function(o){t.globalData.userInfo&&t.globalData.userInfo.name&&(console.log(o),e.collection("tiku_users").doc(t.globalData.openid).update({data:{score:s.inc(o)}}).then((function(t){wx.showToast({title:"积分生效"})})))},addScoreok:function(){if(0==t.globalData.xztype){wx.showLoading({title:"加载中...",mask:!0});var e=this.data.userSelect;if(!e||e.length<1)return void wx.showToast({icon:"none",title:"请做选择"});var o=this;setTimeout((function(){wx.hideLoading(),o.setData({showAnswer:!0})}),4e3)}else{var a=this.data.userSelect;if(!a||a.length<1)return void wx.showToast({icon:"none",title:"请做选择"});(o=this).setData({showAnswer:!0})}},previewImg:function(t){var e=t.currentTarget.dataset.tp;wx.previewImage({urls:e})},baocuoanniu:function(){this.setData({isShowConfirm:!0})},getValue:function(t){console.log(t.detail.value);var e=t.detail.value;this.setData({inputValue:e})},selectClick11:function(t){console.log(t.detail.value),this.setData({jiucuo:t.detail.value})},formSubmit1:function(t){var e=this,o=detail.value;wx.cloud.database().collection("tiku_questions").doc(this.data.subject._id).update({data:{tikuerrors:o.tikuerrors}}).then((function(t){wx.showToast({title:"反馈成功"}),e.setData({showModalStatus:!1})}))},collect:function(){var t=this;wx.cloud.database().collection("tiku_collects").add({data:{title:this.data.subject.title,image:this.data.subject.image,explain:this.data.subject.explain,answer:this.data.subject.answer,optionA:this.data.subject.optionA,optionB:this.data.subject.optionB,optionC:this.data.subject.optionC,optionD:this.data.subject.optionD,type:this.data.subject.type,type2:this.data.subject.type2}}).then((function(e){t.setData({shoucang:!0}),wx.showToast({title:"收藏成功"})}))},collectoff:function(){var t=this;wx.cloud.database().collection("tiku_collects").where({title:wx.cloud.database().RegExp({regexp:this.data.subject.title,options:"i"})}).get().then((function(e){console.log("",e);var o=e.data[0]._id;wx.cloud.database().collection("tiku_collects").doc(o).remove().then((function(e){t.setData({shoucang:!1}),console.log(e),wx.showToast({title:"取消成功"})}))}))},clickme:function(){this.showModal()},showModal:function(){var t=wx.createAnimation({duration:200,timingFunction:"linear",delay:0});this.animation=t,t.translateY(300).step(),this.setData({animationData:t.export(),showModalStatus:!0}),setTimeout(function(){t.translateY(0).step(),this.setData({animationData:t.export()})}.bind(this),200)},hideModal:function(){var t=wx.createAnimation({duration:200,timingFunction:"linear",delay:0});this.animation=t,t.translateY(300).step(),this.setData({animationData:t.export()}),setTimeout(function(){t.translateY(0).step(),this.setData({animationData:t.export(),showModalStatus:!1})}.bind(this),200)},onShareAppMessage:function(){return{title:" ",imageUrl:"https://636c-cloud1-8gs7t7f49b4c97d8-1309642353.tcb.qcloud.la/cloudbase-cms/upload/2022-04-24/m936jjv23g0npx2c20s0ldtsgtupfnin_.png"}},onShareTimeline:function(){return{title:"每天一遍，轻松过线",imageUrl:"https://636c-cloud1-8gs7t7f49b4c97d8-1309642353.tcb.qcloud.la/cloudbase-cms/upload/2022-04-24/euhb16l1ane9x0h0m9q7r12rchk95or3_.png"}}});
},{isPage:true,isComponent:true,currentFile:'pages/aaaa/aaaa.js'});require("pages/aaaa/aaaa.js");