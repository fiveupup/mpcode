$gwx_XC_22=function(_,_v,_n,_p,_s,_wp,_wl,$gwn,$gwl,$gwh,wh,$gstack,$gwrt,gra,grb,TestTest,wfor,_ca,_da,_r,_rz,_o,_oz,_1,_1z,_2,_2z,_m,_mz,nv_getDate,nv_getRegExp,nv_console,nv_parseInt,nv_parseFloat,nv_isNaN,nv_isFinite,nv_decodeURI,nv_decodeURIComponent,nv_encodeURI,nv_encodeURIComponent,$gdc,nv_JSON,_af,_gv,_ai,_grp,_gd,_gapi,$ixc,_ic,_w,_ev,_tsd){return function(path,global){
if(typeof global==='undefined'){if (typeof __GWX_GLOBAL__==='undefined')global={};else global=__GWX_GLOBAL__;}if(typeof __WXML_GLOBAL__ === 'undefined') {__WXML_GLOBAL__={};
}__WXML_GLOBAL__.modules = __WXML_GLOBAL__.modules || {};
var e_={}
if(typeof(global.entrys)==='undefined')global.entrys={};e_=global.entrys;
var d_={}
if(typeof(global.defines)==='undefined')global.defines={};d_=global.defines;
var f_={}
if(typeof(global.modules)==='undefined')global.modules={};f_=global.modules || {};
var p_={}
__WXML_GLOBAL__.ops_cached = __WXML_GLOBAL__.ops_cached || {}
__WXML_GLOBAL__.ops_set = __WXML_GLOBAL__.ops_set || {};
__WXML_GLOBAL__.ops_init = __WXML_GLOBAL__.ops_init || {};
var z=__WXML_GLOBAL__.ops_set.$gwx_XC_22 || [];
function gz$gwx_XC_22_1(){
if( __WXML_GLOBAL__.ops_cached.$gwx_XC_22_1)return __WXML_GLOBAL__.ops_cached.$gwx_XC_22_1
__WXML_GLOBAL__.ops_cached.$gwx_XC_22_1=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
Z([[2,'>'],[[7],[3,'total']],[1,0]])
Z([3,'tip'])
Z([a,[3,'第'],[[2,'+'],[[7],[3,'current']],[1,1]],[3,'题/共'],[[7],[3,'total']],[3,'道错题']])
Z([3,'type'])
Z([a,[3,'类型：'],[[6],[[7],[3,'subject']],[3,'type2']]])
Z([3,'ti-title'])
Z([a,[3,'题目：'],[[6],[[7],[3,'subject']],[3,'title']]])
Z([3,'item'])
Z([[2,'?:'],[[2,'=='],[[6],[[7],[3,'subject']],[3,'userSelect']],[1,'A']],[1,'red'],[1,'']])
Z([a,[3,'A:'],[[6],[[7],[3,'subject']],[3,'optionA']]])
Z(z[7])
Z([[2,'?:'],[[2,'=='],[[6],[[7],[3,'subject']],[3,'userSelect']],[1,'B']],[1,'red'],[1,'']])
Z([a,[3,'B:'],[[6],[[7],[3,'subject']],[3,'optionB']]])
Z([[6],[[7],[3,'subject']],[3,'optionC']])
Z(z[7])
Z([[2,'?:'],[[2,'=='],[[6],[[7],[3,'subject']],[3,'userSelect']],[1,'C']],[1,'red'],[1,'']])
Z([a,[3,'C:'],[[6],[[7],[3,'subject']],[3,'optionC']]])
Z([[6],[[7],[3,'subject']],[3,'optionD']])
Z(z[7])
Z([[2,'?:'],[[2,'=='],[[6],[[7],[3,'subject']],[3,'userSelect']],[1,'D']],[1,'red'],[1,'']])
Z([a,[3,'D:'],[[6],[[7],[3,'subject']],[3,'optionD']]])
Z([3,'rigth_option'])
Z([3,'正确答案是： '])
Z([[6],[[7],[3,'subject']],[3,'answer']])
Z([a,[[7],[3,'item']]])
Z([3,'use-choose'])
Z([a,[3,' 您的选择是：'],[[6],[[7],[3,'subject']],[3,'userSelect']],[3,' ']])
Z([[6],[[7],[3,'subject']],[3,'explain']])
Z([3,'ti-answer'])
Z([3,'解析：'])
Z([a,[[6],[[7],[3,'subject']],[3,'explain']]])
Z([3,'btn_root'])
Z([3,'pre'])
Z([3,'mini'])
Z([3,'primary'])
Z([3,'上一个错题'])
Z([3,'next'])
Z(z[33])
Z(z[34])
Z([3,'下一个错题'])
Z([3,'removeError'])
Z([[7],[3,'subject']])
Z([3,'删除当前错题'])
Z([3,'text-align:center;margin:60rpx'])
Z([3,' 真棒，没有错题啦\n'])
})(__WXML_GLOBAL__.ops_cached.$gwx_XC_22_1);return __WXML_GLOBAL__.ops_cached.$gwx_XC_22_1
}
__WXML_GLOBAL__.ops_set.$gwx_XC_22=z;
__WXML_GLOBAL__.ops_init.$gwx_XC_22=true;
var x=['./pages/testErrorQuestions/testErrorQuestions.wxml'];d_[x[0]]={}
var m0=function(e,s,r,gg){
var z=gz$gwx_XC_22_1()
var cUBB=_v()
_(r,cUBB)
if(_oz(z,0,e,s,gg)){cUBB.wxVkey=1
var oVBB=_n('view')
var eZBB=_n('view')
_rz(z,eZBB,'class',1,e,s,gg)
var b1BB=_oz(z,2,e,s,gg)
_(eZBB,b1BB)
_(oVBB,eZBB)
var o2BB=_n('view')
_rz(z,o2BB,'class',3,e,s,gg)
var x3BB=_oz(z,4,e,s,gg)
_(o2BB,x3BB)
_(oVBB,o2BB)
var o4BB=_n('view')
_rz(z,o4BB,'class',5,e,s,gg)
var f5BB=_oz(z,6,e,s,gg)
_(o4BB,f5BB)
_(oVBB,o4BB)
var c6BB=_n('view')
_rz(z,c6BB,'class',7,e,s,gg)
var h7BB=_n('text')
_rz(z,h7BB,'class',8,e,s,gg)
var o8BB=_oz(z,9,e,s,gg)
_(h7BB,o8BB)
_(c6BB,h7BB)
_(oVBB,c6BB)
var c9BB=_n('view')
_rz(z,c9BB,'class',10,e,s,gg)
var o0BB=_n('text')
_rz(z,o0BB,'class',11,e,s,gg)
var lACB=_oz(z,12,e,s,gg)
_(o0BB,lACB)
_(c9BB,o0BB)
_(oVBB,c9BB)
var lWBB=_v()
_(oVBB,lWBB)
if(_oz(z,13,e,s,gg)){lWBB.wxVkey=1
var aBCB=_n('view')
_rz(z,aBCB,'class',14,e,s,gg)
var tCCB=_n('text')
_rz(z,tCCB,'class',15,e,s,gg)
var eDCB=_oz(z,16,e,s,gg)
_(tCCB,eDCB)
_(aBCB,tCCB)
_(lWBB,aBCB)
}
var aXBB=_v()
_(oVBB,aXBB)
if(_oz(z,17,e,s,gg)){aXBB.wxVkey=1
var bECB=_n('view')
_rz(z,bECB,'class',18,e,s,gg)
var oFCB=_n('text')
_rz(z,oFCB,'class',19,e,s,gg)
var xGCB=_oz(z,20,e,s,gg)
_(oFCB,xGCB)
_(bECB,oFCB)
_(aXBB,bECB)
}
var oHCB=_n('view')
_rz(z,oHCB,'class',21,e,s,gg)
var fICB=_oz(z,22,e,s,gg)
_(oHCB,fICB)
var cJCB=_v()
_(oHCB,cJCB)
var hKCB=function(cMCB,oLCB,oNCB,gg){
var aPCB=_n('text')
var tQCB=_oz(z,24,cMCB,oLCB,gg)
_(aPCB,tQCB)
_(oNCB,aPCB)
return oNCB
}
cJCB.wxXCkey=2
_2z(z,23,hKCB,e,s,gg,cJCB,'item','index','')
_(oVBB,oHCB)
var eRCB=_n('view')
_rz(z,eRCB,'class',25,e,s,gg)
var bSCB=_oz(z,26,e,s,gg)
_(eRCB,bSCB)
_(oVBB,eRCB)
var tYBB=_v()
_(oVBB,tYBB)
if(_oz(z,27,e,s,gg)){tYBB.wxVkey=1
var oTCB=_n('view')
_rz(z,oTCB,'class',28,e,s,gg)
var xUCB=_n('text')
var oVCB=_oz(z,29,e,s,gg)
_(xUCB,oVCB)
_(oTCB,xUCB)
var fWCB=_n('view')
var cXCB=_oz(z,30,e,s,gg)
_(fWCB,cXCB)
_(oTCB,fWCB)
_(tYBB,oTCB)
}
var hYCB=_n('view')
_rz(z,hYCB,'class',31,e,s,gg)
var oZCB=_mz(z,'button',['bindtap',32,'size',1,'type',2],[],e,s,gg)
var c1CB=_oz(z,35,e,s,gg)
_(oZCB,c1CB)
_(hYCB,oZCB)
var o2CB=_mz(z,'button',['bindtap',36,'size',1,'type',2],[],e,s,gg)
var l3CB=_oz(z,39,e,s,gg)
_(o2CB,l3CB)
_(hYCB,o2CB)
_(oVBB,hYCB)
var a4CB=_mz(z,'button',['bindtap',40,'data-subject',1],[],e,s,gg)
var t5CB=_oz(z,42,e,s,gg)
_(a4CB,t5CB)
_(oVBB,a4CB)
lWBB.wxXCkey=1
aXBB.wxXCkey=1
tYBB.wxXCkey=1
_(cUBB,oVBB)
}
else{cUBB.wxVkey=2
var e6CB=_n('view')
_rz(z,e6CB,'style',43,e,s,gg)
var b7CB=_oz(z,44,e,s,gg)
_(e6CB,b7CB)
_(cUBB,e6CB)
}
cUBB.wxXCkey=1
return r
}
e_[x[0]]={f:m0,j:[],i:[],ti:[],ic:[]}
if(path&&e_[path]){
outerGlobal.__wxml_comp_version__=0.02
return function(env,dd,global){$gwxc=0;var root={"tag":"wx-page"};root.children=[]
;g="$gwx_XC_22";var main=e_[path].f
if (typeof global==="undefined")global={};global.f=$gdc(f_[path],"",1);
if(typeof(outerGlobal.__webview_engine_version__)!='undefined'&&outerGlobal.__webview_engine_version__+1e-6>=0.02+1e-6&&outerGlobal.__mergeData__)
{
env=outerGlobal.__mergeData__(env,dd);
}
try{
main(env,{},root,global);
_tsd(root)
if(typeof(outerGlobal.__webview_engine_version__)=='undefined'|| outerGlobal.__webview_engine_version__+1e-6<0.01+1e-6){return _ev(root);}
}catch(err){
console.log(err)
}
;g="";
return root;
}
}
}
}(__g.a,__g.b,__g.c,__g.d,__g.e,__g.f,__g.g,__g.h,__g.i,__g.j,__g.k,__g.l,__g.m,__g.n,__g.o,__g.p,__g.q,__g.r,__g.s,__g.t,__g.u,__g.v,__g.w,__g.x,__g.y,__g.z,__g.A,__g.B,__g.C,__g.D,__g.E,__g.F,__g.G,__g.H,__g.I,__g.J,__g.K,__g.L,__g.M,__g.N,__g.O,__g.P,__g.Q,__g.R,__g.S,__g.T,__g.U,__g.V,__g.W,__g.X,__g.Y,__g.Z,__g.aa);if(__vd_version_info__.delayedGwx||false)$gwx_XC_22();	if (__vd_version_info__.delayedGwx) __wxAppCode__['pages/testErrorQuestions/testErrorQuestions.wxml'] = [$gwx_XC_22, './pages/testErrorQuestions/testErrorQuestions.wxml'];else __wxAppCode__['pages/testErrorQuestions/testErrorQuestions.wxml'] = $gwx_XC_22( './pages/testErrorQuestions/testErrorQuestions.wxml' );
	
var noCss=typeof __vd_version_info__!=='undefined'&&__vd_version_info__.noCss===true;if(!noCss){__wxAppCode__['pages/testErrorQuestions/testErrorQuestions.wxss'] = setCssToHead([".",[1],"tip{color:red;font-size:",[0,42],";margin:",[0,30],";text-align:center}\n.",[1],"type{color:red;margin-bottom:",[0,20],"}\n.",[1],"ti-title,.",[1],"type{margin-left:",[0,20],"}\n.",[1],"ti-title{font-size:",[0,40],";margin-top:",[0,20],"}\n.",[1],"item{margin:",[0,20],"}\n.",[1],"red{color:red}\n.",[1],"use-choose{color:red;margin-left:",[0,20],"}\n.",[1],"rigth_option{color:green;font-size:",[0,32],";margin-bottom:",[0,20],"}\n.",[1],"rigth_option,.",[1],"ti-answer{margin-left:",[0,20],";margin-top:",[0,40],"}\n.",[1],"btn_root{display:-webkit-flex;display:flex;-webkit-justify-content:space-between;justify-content:space-between;padding:",[0,40],"}\n",],undefined,{path:"./pages/testErrorQuestions/testErrorQuestions.wxss"});
}