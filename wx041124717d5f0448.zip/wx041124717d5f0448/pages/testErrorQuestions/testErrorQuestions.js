getApp();

var t = wx.cloud.database(), e = null, o = [];

Page({
    data: {
        total: 0,
        current: 0
    },
    onLoad: function(t) {
        e = t, this.getData();
    },
    getData: function() {
        var r = this;
        t.collection("tiku_test_errors").where({
            testId: e.type1
        }).get().then(function(t) {
            o = t.data, console.log("", o);
            var e = o[0];
            console.log("", e), r.setData({
                current: 0,
                subject: e,
                total: o.length
            });
        });
    },
    pre: function() {
        var t = this.data.current;
        t <= 0 ? wx.showToast({
            icon: "error",
            title: "已是第一道"
        }) : (t -= 1, this.setData({
            current: t,
            subject: o[t]
        }));
    },
    next: function() {
        var t = this.data.current;
        t >= o.length - 1 ? wx.showToast({
            icon: "error",
            title: "已是最后一道"
        }) : (t += 1, this.setData({
            current: t,
            subject: o[t]
        }));
    },
    removeError: function(e) {
        var o = this, r = e.currentTarget.dataset.subject._id;
        t.collection("tiku_test_errors").doc(r).remove().then(function(t) {
            console.log("", t), t.stats && t.stats.removed > 0 ? (wx.showToast({
                title: "删除成功"
            }), o.getData()) : wx.showToast({
                icon: "error",
                title: "网络不给力"
            });
        });
    }
});