var t, a = require("../../@babel/runtime/helpers/defineProperty"), e = 0, o = getApp(), n = wx.cloud.database().collection("tiku_users");

Page((a(t = {
    data: {
        userInfo: null
    },
    onShow: function(t) {
        var a = o.globalData.userInfo;
        console.log("", a), a && a.nickName ? this.setData({
            userInfo: a
        }) : this.setData({
            userInfo: wx.getStorageSync("user")
        }), this.getScore(), this.getUserInfo();
    },
    getUserInfo: function() {
        var t = this;
        console.log(o.globalData.openid), n.doc(o.globalData.openid).get().then(function(a) {
            console.log("", a), t.setData({
                user: a.data
            });
        });
    },
    getScore: function() {
        var t = this;
        wx.cloud.database().collection("tiku_users").doc(o.globalData.openid).get().then(function(a) {
            if (a && a.data && a.data.score > 0) {
                var e = a.data.score;
                console.log("", e), t.setData({
                    score: e
                });
            }
        }).catch(function(t) {
            console.log("");
        });
    }
}, "data", {
    data_arr: [ "日", "一", "二", "三", "四", "五", "六" ],
    year: "",
    month: "",
    today: [],
    num: 0,
    qiandao: !1,
    nowlist: []
}), a(t, "qiandao", function() {
    var t = this, a = wx.getStorageSync("day"), s = new Date().getDate();
    if (a != s) {
        wx.showToast({
            title: "签到成功积分+1",
            duration: 2e3
        }), e++;
        var r = this.data.today;
        r.push({
            today: s
        }), this.setData({
            num: e,
            today: r,
            qiandao: !0
        }), wx.cloud.database().collection("tiku_users").doc(o.globalData.openid).get().then(function(a) {
            if (a && a.data && a.data.score > 0) {
                var e = a.data.score;
                console.log("", e), t.setData({
                    score: e + 1
                }), n.doc(o.globalData.openid).update({
                    data: {
                        score: e + 1
                    }
                });
            }
        }), wx.setStorageSync("day", new Date().getDate()), wx.setStorageSync("month", new Date().getMonth() + 1), 
        wx.setStorageSync("num", this.data.num);
    } else this.setData({
        qiandao: !0
    }), wx.showToast({
        title: "已签到过",
        icon: "error",
        duration: 2e3
    });
}), a(t, "onLoad", function(t) {
    var a = wx.getStorageSync("num"), e = (wx.getStorageSync("day"), this.data.nowlist), o = new Date().getDate();
    e.push({
        today: o
    }), this.setData({
        num: a,
        today: e
    });
    var n = new Date(), s = n.getFullYear(), r = n.getMonth() + 1;
    this.setData({
        year: s,
        month: r
    }), this.showCalendar();
}), a(t, "showCalendar", function() {
    var t = this.data, a = t.year, e = t.month, o = new Date(a, e, 0).getDate(), n = new Date(a + "/" + e + "/1").getDay();
    this.setData({
        currentMonthDays: o,
        startWeek: n
    });
}), a(t, "bindPreMonth", function() {
    var t = this.data, a = t.year, e = t.month;
    e - 1 >= 1 ? e -= 1 : (e = 12, a -= 1), this.setData({
        month: e,
        year: a
    }), this.showCalendar();
}), a(t, "bindNextMonth", function() {
    var t = this.data, a = t.year, e = t.month;
    e + 1 <= 12 ? e += 1 : (e = 1, a += 1), this.setData({
        month: e,
        year: a
    }), this.showCalendar();
}), t));