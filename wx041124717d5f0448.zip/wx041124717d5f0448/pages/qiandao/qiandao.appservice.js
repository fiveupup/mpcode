$gwx_XC_14=function(_,_v,_n,_p,_s,_wp,_wl,$gwn,$gwl,$gwh,wh,$gstack,$gwrt,gra,grb,TestTest,wfor,_ca,_da,_r,_rz,_o,_oz,_1,_1z,_2,_2z,_m,_mz,nv_getDate,nv_getRegExp,nv_console,nv_parseInt,nv_parseFloat,nv_isNaN,nv_isFinite,nv_decodeURI,nv_decodeURIComponent,nv_encodeURI,nv_encodeURIComponent,$gdc,nv_JSON,_af,_gv,_ai,_grp,_gd,_gapi,$ixc,_ic,_w,_ev,_tsd){return function(path,global){
if(typeof global==='undefined'){if (typeof __GWX_GLOBAL__==='undefined')global={};else global=__GWX_GLOBAL__;}if(typeof __WXML_GLOBAL__ === 'undefined') {__WXML_GLOBAL__={};
}__WXML_GLOBAL__.modules = __WXML_GLOBAL__.modules || {};
var e_={}
if(typeof(global.entrys)==='undefined')global.entrys={};e_=global.entrys;
var d_={}
if(typeof(global.defines)==='undefined')global.defines={};d_=global.defines;
var f_={}
if(typeof(global.modules)==='undefined')global.modules={};f_=global.modules || {};
var p_={}
__WXML_GLOBAL__.ops_cached = __WXML_GLOBAL__.ops_cached || {}
__WXML_GLOBAL__.ops_set = __WXML_GLOBAL__.ops_set || {};
__WXML_GLOBAL__.ops_init = __WXML_GLOBAL__.ops_init || {};
var z=__WXML_GLOBAL__.ops_set.$gwx_XC_14 || [];
function gz$gwx_XC_14_1(){
if( __WXML_GLOBAL__.ops_cached.$gwx_XC_14_1)return __WXML_GLOBAL__.ops_cached.$gwx_XC_14_1
__WXML_GLOBAL__.ops_cached.$gwx_XC_14_1=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
Z([[2,'&&'],[[7],[3,'userInfo']],[[6],[[7],[3,'userInfo']],[3,'avatarUrl']]])
Z([[2,'=='],[[7],[3,'m']],[[7],[3,'time']]])
Z([[7],[3,'qiandao']])
})(__WXML_GLOBAL__.ops_cached.$gwx_XC_14_1);return __WXML_GLOBAL__.ops_cached.$gwx_XC_14_1
}
__WXML_GLOBAL__.ops_set.$gwx_XC_14=z;
__WXML_GLOBAL__.ops_init.$gwx_XC_14=true;
var x=['./pages/qiandao/qiandao.wxml'];d_[x[0]]={}
var m0=function(e,s,r,gg){
var z=gz$gwx_XC_14_1()
var fCC=_v()
_(r,fCC)
if(_oz(z,0,e,s,gg)){fCC.wxVkey=1
}
var cDC=_v()
_(r,cDC)
if(_oz(z,1,e,s,gg)){cDC.wxVkey=1
}
var hEC=_v()
_(r,hEC)
if(_oz(z,2,e,s,gg)){hEC.wxVkey=1
}
fCC.wxXCkey=1
cDC.wxXCkey=1
hEC.wxXCkey=1
return r
}
e_[x[0]]={f:m0,j:[],i:[],ti:[],ic:[]}
if(path&&e_[path]){
return function(env,dd,global){$gwxc=0;var root={"tag":"wx-page"};root.children=[]
;g="$gwx_XC_14";var main=e_[path].f
if (typeof global==="undefined")global={};global.f=$gdc(f_[path],"",1);
try{
main(env,{},root,global);
_tsd(root)
}catch(err){
console.log(err)
}
;g="";
return root;
}
}
}
}(__g.a,__g.b,__g.c,__g.d,__g.e,__g.f,__g.g,__g.h,__g.i,__g.j,__g.k,__g.l,__g.m,__g.n,__g.o,__g.p,__g.q,__g.r,__g.s,__g.t,__g.u,__g.v,__g.w,__g.x,__g.y,__g.z,__g.A,__g.B,__g.C,__g.D,__g.E,__g.F,__g.G,__g.H,__g.I,__g.J,__g.K,__g.L,__g.M,__g.N,__g.O,__g.P,__g.Q,__g.R,__g.S,__g.T,__g.U,__g.V,__g.W,__g.X,__g.Y,__g.Z,__g.aa);if(__vd_version_info__.delayedGwx||false)$gwx_XC_14();	if (__vd_version_info__.delayedGwx) __wxAppCode__['pages/qiandao/qiandao.wxml'] = [$gwx_XC_14, './pages/qiandao/qiandao.wxml'];else __wxAppCode__['pages/qiandao/qiandao.wxml'] = $gwx_XC_14( './pages/qiandao/qiandao.wxml' );
	;__wxRoute = "pages/qiandao/qiandao";__wxRouteBegin = true;__wxAppCurrentFile__="pages/qiandao/qiandao.js";define("pages/qiandao/qiandao.js",function(require,module,exports,window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){
"use strict";var t,a=require("../../@babel/runtime/helpers/defineProperty"),e=0,o=getApp(),n=wx.cloud.database().collection("tiku_users");Page((a(t={data:{userInfo:null},onShow:function(t){var a=o.globalData.userInfo;console.log("",a),a&&a.nickName?this.setData({userInfo:a}):this.setData({userInfo:wx.getStorageSync("user")}),this.getScore(),this.getUserInfo()},getUserInfo:function(){var t=this;console.log(o.globalData.openid),n.doc(o.globalData.openid).get().then((function(a){console.log("",a),t.setData({user:a.data})}))},getScore:function(){var t=this;wx.cloud.database().collection("tiku_users").doc(o.globalData.openid).get().then((function(a){if(a&&a.data&&a.data.score>0){var e=a.data.score;console.log("",e),t.setData({score:e})}})).catch((function(t){console.log("")}))}},"data",{data_arr:["日","一","二","三","四","五","六"],year:"",month:"",today:[],num:0,qiandao:!1,nowlist:[]}),a(t,"qiandao",(function(){var t=this,a=wx.getStorageSync("day"),s=(new Date).getDate();if(a!=s){wx.showToast({title:"签到成功积分+1",duration:2e3}),e++;var r=this.data.today;r.push({today:s}),this.setData({num:e,today:r,qiandao:!0}),wx.cloud.database().collection("tiku_users").doc(o.globalData.openid).get().then((function(a){if(a&&a.data&&a.data.score>0){var e=a.data.score;console.log("",e),t.setData({score:e+1}),n.doc(o.globalData.openid).update({data:{score:e+1}})}})),wx.setStorageSync("day",(new Date).getDate()),wx.setStorageSync("month",(new Date).getMonth()+1),wx.setStorageSync("num",this.data.num)}else this.setData({qiandao:!0}),wx.showToast({title:"已签到过",icon:"error",duration:2e3})})),a(t,"onLoad",(function(t){var a=wx.getStorageSync("num"),e=(wx.getStorageSync("day"),this.data.nowlist),o=(new Date).getDate();e.push({today:o}),this.setData({num:a,today:e});var n=new Date,s=n.getFullYear(),r=n.getMonth()+1;this.setData({year:s,month:r}),this.showCalendar()})),a(t,"showCalendar",(function(){var t=this.data,a=t.year,e=t.month,o=new Date(a,e,0).getDate(),n=new Date(a+"/"+e+"/1").getDay();this.setData({currentMonthDays:o,startWeek:n})})),a(t,"bindPreMonth",(function(){var t=this.data,a=t.year,e=t.month;e-1>=1?e-=1:(e=12,a-=1),this.setData({month:e,year:a}),this.showCalendar()})),a(t,"bindNextMonth",(function(){var t=this.data,a=t.year,e=t.month;e+1<=12?e+=1:(e=1,a+=1),this.setData({month:e,year:a}),this.showCalendar()})),t));
},{isPage:true,isComponent:true,currentFile:'pages/qiandao/qiandao.js'});require("pages/qiandao/qiandao.js");