var __wxAppData=__wxAppData||{};var __wxAppCode__=__wxAppCode__||{};var global=global||{};var __WXML_GLOBAL__=__WXML_GLOBAL__||{entrys:{},defines:{},modules:{},ops:[],wxs_nf_init:undefined,total_ops:0};var Component=Component||function(){};var definePlugin=definePlugin||function(){};var requirePlugin=requirePlugin||function(){};var Behavior=Behavior||function(){};var __vd_version_info__=__vd_version_info__||{};var __GWX_GLOBAL__=__GWX_GLOBAL__||{};if(this&&this.__g===undefined)Object.defineProperty(this,"__g",{configurable:false,enumerable:false,writable:false,value:function(){function D(e,t){if(typeof t!="undefined")e.children.push(t)}function S(e){if(typeof e!="undefined")return{tag:"virtual",wxKey:e,children:[]};return{tag:"virtual",children:[]}}function v(e){$gwxc++;if($gwxc>=16e3){throw"Dom limit exceeded, please check if there's any mistake you've made."}return{tag:"wx-"+e,attr:{},children:[],n:[],raw:{},generics:{}}}function e(e,t){t&&e.properities.push(t)}function t(e,t,r){return typeof e[r]!="undefined"?e[r]:t[r]}function u(e){console.warn("WXMLRT_"+g+":"+e)}function r(e,t){u(t+":-1:-1:-1: Template `"+e+"` is being called recursively, will be stop.")}var s=console.warn;var n=console.log;function o(){function e(){}e.prototype={hn:function(e,t){if(typeof e=="object"){var r=0;var n=false,o=false;for(var a in e){n=n|a==="__value__";o=o|a==="__wxspec__";r++;if(r>2)break}return r==2&&n&&o&&(t||e.__wxspec__!=="m"||this.hn(e.__value__)==="h")?"h":"n"}return"n"},nh:function(e,t){return{__value__:e,__wxspec__:t?t:true}},rv:function(e){return this.hn(e,true)==="n"?e:this.rv(e.__value__)},hm:function(e){if(typeof e=="object"){var t=0;var r=false,n=false;for(var o in e){r=r|o==="__value__";n=n|o==="__wxspec__";t++;if(t>2)break}return t==2&&r&&n&&(e.__wxspec__==="m"||this.hm(e.__value__))}return false}};return new e}var A=o();function T(e){var t=e.split("\n "+" "+" "+" ");for(var r=0;r<t.length;++r){if(0==r)continue;if(")"===t[r][t[r].length-1])t[r]=t[r].replace(/\s\(.*\)$/,"");else t[r]="at anonymous function"}return t.join("\n "+" "+" "+" ")}function a(M){function m(e,t,r,n,o){var a=false;var i=e[0][1];var p,u,l,f,v,c;switch(i){case"?:":p=x(e[1],t,r,n,o,a);l=M&&A.hn(p)==="h";f=A.rv(p)?x(e[2],t,r,n,o,a):x(e[3],t,r,n,o,a);f=l&&A.hn(f)==="n"?A.nh(f,"c"):f;return f;break;case"&&":p=x(e[1],t,r,n,o,a);l=M&&A.hn(p)==="h";f=A.rv(p)?x(e[2],t,r,n,o,a):A.rv(p);f=l&&A.hn(f)==="n"?A.nh(f,"c"):f;return f;break;case"||":p=x(e[1],t,r,n,o,a);l=M&&A.hn(p)==="h";f=A.rv(p)?A.rv(p):x(e[2],t,r,n,o,a);f=l&&A.hn(f)==="n"?A.nh(f,"c"):f;return f;break;case"+":case"*":case"/":case"%":case"|":case"^":case"&":case"===":case"==":case"!=":case"!==":case">=":case"<=":case">":case"<":case"<<":case">>":p=x(e[1],t,r,n,o,a);u=x(e[2],t,r,n,o,a);l=M&&(A.hn(p)==="h"||A.hn(u)==="h");switch(i){case"+":f=A.rv(p)+A.rv(u);break;case"*":f=A.rv(p)*A.rv(u);break;case"/":f=A.rv(p)/A.rv(u);break;case"%":f=A.rv(p)%A.rv(u);break;case"|":f=A.rv(p)|A.rv(u);break;case"^":f=A.rv(p)^A.rv(u);break;case"&":f=A.rv(p)&A.rv(u);break;case"===":f=A.rv(p)===A.rv(u);break;case"==":f=A.rv(p)==A.rv(u);break;case"!=":f=A.rv(p)!=A.rv(u);break;case"!==":f=A.rv(p)!==A.rv(u);break;case">=":f=A.rv(p)>=A.rv(u);break;case"<=":f=A.rv(p)<=A.rv(u);break;case">":f=A.rv(p)>A.rv(u);break;case"<":f=A.rv(p)<A.rv(u);break;case"<<":f=A.rv(p)<<A.rv(u);break;case">>":f=A.rv(p)>>A.rv(u);break;default:break}return l?A.nh(f,"c"):f;break;case"-":p=e.length===3?x(e[1],t,r,n,o,a):0;u=e.length===3?x(e[2],t,r,n,o,a):x(e[1],t,r,n,o,a);l=M&&(A.hn(p)==="h"||A.hn(u)==="h");f=l?A.rv(p)-A.rv(u):p-u;return l?A.nh(f,"c"):f;break;case"!":p=x(e[1],t,r,n,o,a);l=M&&A.hn(p)=="h";f=!A.rv(p);return l?A.nh(f,"c"):f;case"~":p=x(e[1],t,r,n,o,a);l=M&&A.hn(p)=="h";f=~A.rv(p);return l?A.nh(f,"c"):f;default:s("unrecognized op"+i)}}function x(e,t,r,n,o,a){var i=e[0];var p=false;if(typeof a!=="undefined")o.ap=a;if(typeof i==="object"){var u=i[0];var l,f,v,c,s,y,b,d,h,_,g;switch(u){case 2:return m(e,t,r,n,o);break;case 4:return x(e[1],t,r,n,o,p);break;case 5:switch(e.length){case 2:l=x(e[1],t,r,n,o,p);return M?[l]:[A.rv(l)];return[l];break;case 1:return[];break;default:l=x(e[1],t,r,n,o,p);v=x(e[2],t,r,n,o,p);l.push(M?v:A.rv(v));return l;break}break;case 6:l=x(e[1],t,r,n,o);var w=o.ap;h=A.hn(l)==="h";f=h?A.rv(l):l;o.is_affected|=h;if(M){if(f===null||typeof f==="undefined"){return h?A.nh(undefined,"e"):undefined}v=x(e[2],t,r,n,o,p);_=A.hn(v)==="h";c=_?A.rv(v):v;o.ap=w;o.is_affected|=_;if(c===null||typeof c==="undefined"||c==="__proto__"||c==="prototype"||c==="caller"){return h||_?A.nh(undefined,"e"):undefined}y=f[c];if(typeof y==="function"&&!w)y=undefined;g=A.hn(y)==="h";o.is_affected|=g;return h||_?g?y:A.nh(y,"e"):y}else{if(f===null||typeof f==="undefined"){return undefined}v=x(e[2],t,r,n,o,p);_=A.hn(v)==="h";c=_?A.rv(v):v;o.ap=w;o.is_affected|=_;if(c===null||typeof c==="undefined"||c==="__proto__"||c==="prototype"||c==="caller"){return undefined}y=f[c];if(typeof y==="function"&&!w)y=undefined;g=A.hn(y)==="h";o.is_affected|=g;return g?A.rv(y):y}case 7:switch(e[1][0]){case 11:o.is_affected|=A.hn(n)==="h";return n;case 3:b=A.rv(r);d=A.rv(t);v=e[1][1];if(n&&n.f&&n.f.hasOwnProperty(v)){l=n.f;o.ap=true}else{l=b&&b.hasOwnProperty(v)?r:d&&d.hasOwnProperty(v)?t:undefined}if(M){if(l){h=A.hn(l)==="h";f=h?A.rv(l):l;y=f[v];g=A.hn(y)==="h";o.is_affected|=h||g;y=h&&!g?A.nh(y,"e"):y;return y}}else{if(l){h=A.hn(l)==="h";f=h?A.rv(l):l;y=f[v];g=A.hn(y)==="h";o.is_affected|=h||g;return A.rv(y)}}return undefined}break;case 8:l={};l[e[1]]=x(e[2],t,r,n,o,p);return l;break;case 9:l=x(e[1],t,r,n,o,p);v=x(e[2],t,r,n,o,p);function O(e,t,r){var n,o;h=A.hn(e)==="h";_=A.hn(t)==="h";f=A.rv(e);c=A.rv(t);for(var a in c){if(r||!f.hasOwnProperty(a)){f[a]=M?_?A.nh(c[a],"e"):c[a]:A.rv(c[a])}}return e}var s=l;var j=true;if(typeof e[1][0]==="object"&&e[1][0][0]===10){l=v;v=s;j=false}if(typeof e[1][0]==="object"&&e[1][0][0]===10){var P={};return O(O(P,l,j),v,j)}else return O(l,v,j);break;case 10:l=x(e[1],t,r,n,o,p);l=M?l:A.rv(l);return l;break;case 12:var P;l=x(e[1],t,r,n,o);if(!o.ap){return M&&A.hn(l)==="h"?A.nh(P,"f"):P}var w=o.ap;v=x(e[2],t,r,n,o,p);o.ap=w;h=A.hn(l)==="h";_=N(v);f=A.rv(l);c=A.rv(v);snap_bb=K(c,"nv_");try{P=typeof f==="function"?K(f.apply(null,snap_bb)):undefined}catch(t){t.message=t.message.replace(/nv_/g,"");t.stack=t.stack.substring(0,t.stack.indexOf("\n",t.stack.lastIndexOf("at nv_")));t.stack=t.stack.replace(/\snv_/g," ");t.stack=T(t.stack);if(n.debugInfo){t.stack+="\n "+" "+" "+" at "+n.debugInfo[0]+":"+n.debugInfo[1]+":"+n.debugInfo[2];console.error(t)}P=undefined}return M&&(_||h)?A.nh(P,"f"):P}}else{if(i===3||i===1)return e[1];else if(i===11){var l="";for(var D=1;D<e.length;D++){var S=A.rv(x(e[D],t,r,n,o,p));l+=typeof S==="undefined"?"":S}return l}}}function e(e,t,r,n,o,a){if(e[0]=="11182016"){n.debugInfo=e[2];return x(e[1],t,r,n,o,a)}else{n.debugInfo=null;return x(e,t,r,n,o,a)}}return e}var f=a(true);var c=a(false);function i(e,t,r,n,o,a,i,p){{var u={is_affected:false};var l=f(t,r,n,o,u);if(JSON.stringify(l)!=JSON.stringify(a)||u.is_affected!=p){console.warn("A. "+e+" get result "+JSON.stringify(l)+", "+u.is_affected+", but "+JSON.stringify(a)+", "+p+" is expected")}}{var u={is_affected:false};var l=c(t,r,n,o,u);if(JSON.stringify(l)!=JSON.stringify(i)||u.is_affected!=p){console.warn("B. "+e+" get result "+JSON.stringify(l)+", "+u.is_affected+", but "+JSON.stringify(i)+", "+p+" is expected")}}}function y(e,t,r,n,o,a,i,p,u){var l=A.hn(e)==="n";var f=A.rv(n);var v=f.hasOwnProperty(i);var c=f.hasOwnProperty(p);var s=f[i];var y=f[p];var b=Object.prototype.toString.call(A.rv(e));var d=b[8];if(d==="N"&&b[10]==="l")d="X";var h;if(l){if(d==="A"){var _;for(var g=0;g<e.length;g++){f[i]=e[g];f[p]=l?g:A.nh(g,"h");_=A.rv(e[g]);var w=u&&_?u==="*this"?_:A.rv(_[u]):undefined;h=S(w);D(a,h);t(r,f,h,o)}}else if(d==="O"){var g=0;var _;for(var O in e){f[i]=e[O];f[p]=l?O:A.nh(O,"h");_=A.rv(e[O]);var w=u&&_?u==="*this"?_:A.rv(_[u]):undefined;h=S(w);D(a,h);t(r,f,h,o);g++}}else if(d==="S"){for(var g=0;g<e.length;g++){f[i]=e[g];f[p]=l?g:A.nh(g,"h");h=S(e[g]+g);D(a,h);t(r,f,h,o)}}else if(d==="N"){for(var g=0;g<e;g++){f[i]=g;f[p]=l?g:A.nh(g,"h");h=S(g);D(a,h);t(r,f,h,o)}}else{}}else{var j=A.rv(e);var _,P;if(d==="A"){for(var g=0;g<j.length;g++){P=j[g];P=A.hn(P)==="n"?A.nh(P,"h"):P;_=A.rv(P);f[i]=P;f[p]=l?g:A.nh(g,"h");var w=u&&_?u==="*this"?_:A.rv(_[u]):undefined;h=S(w);D(a,h);t(r,f,h,o)}}else if(d==="O"){var g=0;for(var O in j){P=j[O];P=A.hn(P)==="n"?A.nh(P,"h"):P;_=A.rv(P);f[i]=P;f[p]=l?O:A.nh(O,"h");var w=u&&_?u==="*this"?_:A.rv(_[u]):undefined;h=S(w);D(a,h);t(r,f,h,o);g++}}else if(d==="S"){for(var g=0;g<j.length;g++){P=A.nh(j[g],"h");f[i]=P;f[p]=l?g:A.nh(g,"h");h=S(e[g]+g);D(a,h);t(r,f,h,o)}}else if(d==="N"){for(var g=0;g<j;g++){P=A.nh(g,"h");f[i]=P;f[p]=l?g:A.nh(g,"h");h=S(g);D(a,h);t(r,f,h,o)}}else{}}if(v){f[i]=s}else{delete f[i]}if(c){f[p]=y}else{delete f[p]}}function N(e){if(A.hn(e)=="h")return true;if(typeof e!=="object")return false;for(var t in e){if(e.hasOwnProperty(t)){if(N(e[t]))return true}}return false}function b(e,t,r,n,o){var a=false;var i=K(n,"",2);if(o.ap&&i&&i.constructor===Function){t="$wxs:"+t;e.attr["$gdc"]=K}if(o.is_affected||N(n)){e.n.push(t);e.raw[t]=n}e.attr[t]=i}function d(e,t,r,n,o,a){a.opindex=r;var i={},p;var u=c(z[r],n,o,a,i);b(e,t,r,u,i)}function h(e,t,r,n,o,a,i){i.opindex=n;var p={},u;var l=c(e[n],o,a,i,p);b(t,r,n,l,p)}function p(e,t,r,n){n.opindex=e;var o={};var a=c(z[e],t,r,n,o);return a&&a.constructor===Function?undefined:a}function l(e,t,r,n,o){o.opindex=t;var a={};var i=c(e[t],r,n,o,a);return i&&i.constructor===Function?undefined:i}function _(e,t,r,n,o){var o=o||{};n.opindex=e;return f(z[e],t,r,n,o)}function w(e,t,r,n,o,a){var a=a||{};o.opindex=t;return f(e[t],r,n,o,a)}function O(e,t,r,n,o,a,i,p,u){var l={};var f=_(e,r,n,o);y(f,t,r,n,o,a,i,p,u)}function j(e,t,r,n,o,a,i,p,u,l){var f={};var v=w(e,t,n,o,a);y(v,r,n,o,a,i,p,u,l)}function P(e,t,r,n,o,a){var i=v(e);var p=0;for(var u=0;u<t.length;u+=2){if(p+t[u+1]<0){i.attr[t[u]]=true}else{d(i,t[u],p+t[u+1],n,o,a);if(p===0)p=t[u+1]}}for(var u=0;u<r.length;u+=2){if(p+r[u+1]<0){i.generics[r[u]]=""}else{var l=c(z[p+r[u+1]],n,o,a);if(l!="")l="wx-"+l;i.generics[r[u]]=l;if(p===0)p=r[u+1]}}return i}function M(e,t,r,n,o,a,i){var p=v(t);var u=0;for(var l=0;l<r.length;l+=2){if(u+r[l+1]<0){p.attr[r[l]]=true}else{h(e,p,r[l],u+r[l+1],o,a,i);if(u===0)u=r[l+1]}}for(var l=0;l<n.length;l+=2){if(u+n[l+1]<0){p.generics[n[l]]=""}else{var f=c(e[u+n[l+1]],o,a,i);if(f!="")f="wx-"+f;p.generics[n[l]]=f;if(u===0)u=n[l+1]}}return p}var m=function(){if(typeof __WXML_GLOBAL__==="undefined"||undefined===__WXML_GLOBAL__.wxs_nf_init){x();C();k();U();I();L();E();R();F()}if(typeof __WXML_GLOBAL__!=="undefined")__WXML_GLOBAL__.wxs_nf_init=true};var x=function(){Object.defineProperty(Object.prototype,"nv_constructor",{writable:true,value:"Object"});Object.defineProperty(Object.prototype,"nv_toString",{writable:true,value:function(){return"[object Object]"}})};var C=function(){Object.defineProperty(Function.prototype,"nv_constructor",{writable:true,value:"Function"});Object.defineProperty(Function.prototype,"nv_length",{get:function(){return this.length},set:function(){}});Object.defineProperty(Function.prototype,"nv_toString",{writable:true,value:function(){return"[function Function]"}})};var k=function(){Object.defineProperty(Array.prototype,"nv_toString",{writable:true,value:function(){return this.nv_join()}});Object.defineProperty(Array.prototype,"nv_join",{writable:true,value:function(e){e=undefined==e?",":e;var t="";for(var r=0;r<this.length;++r){if(0!=r)t+=e;if(null==this[r]||undefined==this[r])t+="";else if(typeof this[r]=="function")t+=this[r].nv_toString();else if(typeof this[r]=="object"&&this[r].nv_constructor==="Array")t+=this[r].nv_join();else t+=this[r].toString()}return t}});Object.defineProperty(Array.prototype,"nv_constructor",{writable:true,value:"Array"});Object.defineProperty(Array.prototype,"nv_concat",{writable:true,value:Array.prototype.concat});Object.defineProperty(Array.prototype,"nv_pop",{writable:true,value:Array.prototype.pop});Object.defineProperty(Array.prototype,"nv_push",{writable:true,value:Array.prototype.push});Object.defineProperty(Array.prototype,"nv_reverse",{writable:true,value:Array.prototype.reverse});Object.defineProperty(Array.prototype,"nv_shift",{writable:true,value:Array.prototype.shift});Object.defineProperty(Array.prototype,"nv_slice",{writable:true,value:Array.prototype.slice});Object.defineProperty(Array.prototype,"nv_sort",{writable:true,value:Array.prototype.sort});Object.defineProperty(Array.prototype,"nv_splice",{writable:true,value:Array.prototype.splice});Object.defineProperty(Array.prototype,"nv_unshift",{writable:true,value:Array.prototype.unshift});Object.defineProperty(Array.prototype,"nv_indexOf",{writable:true,value:Array.prototype.indexOf});Object.defineProperty(Array.prototype,"nv_lastIndexOf",{writable:true,value:Array.prototype.lastIndexOf});Object.defineProperty(Array.prototype,"nv_every",{writable:true,value:Array.prototype.every});Object.defineProperty(Array.prototype,"nv_some",{writable:true,value:Array.prototype.some});Object.defineProperty(Array.prototype,"nv_forEach",{writable:true,value:Array.prototype.forEach});Object.defineProperty(Array.prototype,"nv_map",{writable:true,value:Array.prototype.map});Object.defineProperty(Array.prototype,"nv_filter",{writable:true,value:Array.prototype.filter});Object.defineProperty(Array.prototype,"nv_reduce",{writable:true,value:Array.prototype.reduce});Object.defineProperty(Array.prototype,"nv_reduceRight",{writable:true,value:Array.prototype.reduceRight});Object.defineProperty(Array.prototype,"nv_length",{get:function(){return this.length},set:function(e){this.length=e}})};var U=function(){Object.defineProperty(String.prototype,"nv_constructor",{writable:true,value:"String"});Object.defineProperty(String.prototype,"nv_toString",{writable:true,value:String.prototype.toString});Object.defineProperty(String.prototype,"nv_valueOf",{writable:true,value:String.prototype.valueOf});Object.defineProperty(String.prototype,"nv_charAt",{writable:true,value:String.prototype.charAt});Object.defineProperty(String.prototype,"nv_charCodeAt",{writable:true,value:String.prototype.charCodeAt});Object.defineProperty(String.prototype,"nv_concat",{writable:true,value:String.prototype.concat});Object.defineProperty(String.prototype,"nv_indexOf",{writable:true,value:String.prototype.indexOf});Object.defineProperty(String.prototype,"nv_lastIndexOf",{writable:true,value:String.prototype.lastIndexOf});Object.defineProperty(String.prototype,"nv_localeCompare",{writable:true,value:String.prototype.localeCompare});Object.defineProperty(String.prototype,"nv_match",{writable:true,value:String.prototype.match});Object.defineProperty(String.prototype,"nv_replace",{writable:true,value:String.prototype.replace});Object.defineProperty(String.prototype,"nv_search",{writable:true,value:String.prototype.search});Object.defineProperty(String.prototype,"nv_slice",{writable:true,value:String.prototype.slice});Object.defineProperty(String.prototype,"nv_split",{writable:true,value:String.prototype.split});Object.defineProperty(String.prototype,"nv_substring",{writable:true,value:String.prototype.substring});Object.defineProperty(String.prototype,"nv_toLowerCase",{writable:true,value:String.prototype.toLowerCase});Object.defineProperty(String.prototype,"nv_toLocaleLowerCase",{writable:true,value:String.prototype.toLocaleLowerCase});Object.defineProperty(String.prototype,"nv_toUpperCase",{writable:true,value:String.prototype.toUpperCase});Object.defineProperty(String.prototype,"nv_toLocaleUpperCase",{writable:true,value:String.prototype.toLocaleUpperCase});Object.defineProperty(String.prototype,"nv_trim",{writable:true,value:String.prototype.trim});Object.defineProperty(String.prototype,"nv_length",{get:function(){return this.length},set:function(e){this.length=e}})};var I=function(){Object.defineProperty(Boolean.prototype,"nv_constructor",{writable:true,value:"Boolean"});Object.defineProperty(Boolean.prototype,"nv_toString",{writable:true,value:Boolean.prototype.toString});Object.defineProperty(Boolean.prototype,"nv_valueOf",{writable:true,value:Boolean.prototype.valueOf})};var L=function(){Object.defineProperty(Number,"nv_MAX_VALUE",{writable:false,value:Number.MAX_VALUE});Object.defineProperty(Number,"nv_MIN_VALUE",{writable:false,value:Number.MIN_VALUE});Object.defineProperty(Number,"nv_NEGATIVE_INFINITY",{writable:false,value:Number.NEGATIVE_INFINITY});Object.defineProperty(Number,"nv_POSITIVE_INFINITY",{writable:false,value:Number.POSITIVE_INFINITY});Object.defineProperty(Number.prototype,"nv_constructor",{writable:true,value:"Number"});Object.defineProperty(Number.prototype,"nv_toString",{writable:true,value:Number.prototype.toString});Object.defineProperty(Number.prototype,"nv_toLocaleString",{writable:true,value:Number.prototype.toLocaleString});Object.defineProperty(Number.prototype,"nv_valueOf",{writable:true,value:Number.prototype.valueOf});Object.defineProperty(Number.prototype,"nv_toFixed",{writable:true,value:Number.prototype.toFixed});Object.defineProperty(Number.prototype,"nv_toExponential",{writable:true,value:Number.prototype.toExponential});Object.defineProperty(Number.prototype,"nv_toPrecision",{writable:true,value:Number.prototype.toPrecision})};var E=function(){Object.defineProperty(Math,"nv_E",{writable:false,value:Math.E});Object.defineProperty(Math,"nv_LN10",{writable:false,value:Math.LN10});Object.defineProperty(Math,"nv_LN2",{writable:false,value:Math.LN2});Object.defineProperty(Math,"nv_LOG2E",{writable:false,value:Math.LOG2E});Object.defineProperty(Math,"nv_LOG10E",{writable:false,value:Math.LOG10E});Object.defineProperty(Math,"nv_PI",{writable:false,value:Math.PI});Object.defineProperty(Math,"nv_SQRT1_2",{writable:false,value:Math.SQRT1_2});Object.defineProperty(Math,"nv_SQRT2",{writable:false,value:Math.SQRT2});Object.defineProperty(Math,"nv_abs",{writable:false,value:Math.abs});Object.defineProperty(Math,"nv_acos",{writable:false,value:Math.acos});Object.defineProperty(Math,"nv_asin",{writable:false,value:Math.asin});Object.defineProperty(Math,"nv_atan",{writable:false,value:Math.atan});Object.defineProperty(Math,"nv_atan2",{writable:false,value:Math.atan2});Object.defineProperty(Math,"nv_ceil",{writable:false,value:Math.ceil});Object.defineProperty(Math,"nv_cos",{writable:false,value:Math.cos});Object.defineProperty(Math,"nv_exp",{writable:false,value:Math.exp});Object.defineProperty(Math,"nv_floor",{writable:false,value:Math.floor});Object.defineProperty(Math,"nv_log",{writable:false,value:Math.log});Object.defineProperty(Math,"nv_max",{writable:false,value:Math.max});Object.defineProperty(Math,"nv_min",{writable:false,value:Math.min});Object.defineProperty(Math,"nv_pow",{writable:false,value:Math.pow});Object.defineProperty(Math,"nv_random",{writable:false,value:Math.random});Object.defineProperty(Math,"nv_round",{writable:false,value:Math.round});Object.defineProperty(Math,"nv_sin",{writable:false,value:Math.sin});Object.defineProperty(Math,"nv_sqrt",{writable:false,value:Math.sqrt});Object.defineProperty(Math,"nv_tan",{writable:false,value:Math.tan})};var R=function(){Object.defineProperty(Date.prototype,"nv_constructor",{writable:true,value:"Date"});Object.defineProperty(Date,"nv_parse",{writable:true,value:Date.parse});Object.defineProperty(Date,"nv_UTC",{writable:true,value:Date.UTC});Object.defineProperty(Date,"nv_now",{writable:true,value:Date.now});Object.defineProperty(Date.prototype,"nv_toString",{writable:true,value:Date.prototype.toString});Object.defineProperty(Date.prototype,"nv_toDateString",{writable:true,value:Date.prototype.toDateString});Object.defineProperty(Date.prototype,"nv_toTimeString",{writable:true,value:Date.prototype.toTimeString});Object.defineProperty(Date.prototype,"nv_toLocaleString",{writable:true,value:Date.prototype.toLocaleString});Object.defineProperty(Date.prototype,"nv_toLocaleDateString",{writable:true,value:Date.prototype.toLocaleDateString});Object.defineProperty(Date.prototype,"nv_toLocaleTimeString",{writable:true,value:Date.prototype.toLocaleTimeString});Object.defineProperty(Date.prototype,"nv_valueOf",{writable:true,value:Date.prototype.valueOf});Object.defineProperty(Date.prototype,"nv_getTime",{writable:true,value:Date.prototype.getTime});Object.defineProperty(Date.prototype,"nv_getFullYear",{writable:true,value:Date.prototype.getFullYear});Object.defineProperty(Date.prototype,"nv_getUTCFullYear",{writable:true,value:Date.prototype.getUTCFullYear});Object.defineProperty(Date.prototype,"nv_getMonth",{writable:true,value:Date.prototype.getMonth});Object.defineProperty(Date.prototype,"nv_getUTCMonth",{writable:true,value:Date.prototype.getUTCMonth});Object.defineProperty(Date.prototype,"nv_getDate",{writable:true,value:Date.prototype.getDate});Object.defineProperty(Date.prototype,"nv_getUTCDate",{writable:true,value:Date.prototype.getUTCDate});Object.defineProperty(Date.prototype,"nv_getDay",{writable:true,value:Date.prototype.getDay});Object.defineProperty(Date.prototype,"nv_getUTCDay",{writable:true,value:Date.prototype.getUTCDay});Object.defineProperty(Date.prototype,"nv_getHours",{writable:true,value:Date.prototype.getHours});Object.defineProperty(Date.prototype,"nv_getUTCHours",{writable:true,value:Date.prototype.getUTCHours});Object.defineProperty(Date.prototype,"nv_getMinutes",{writable:true,value:Date.prototype.getMinutes});Object.defineProperty(Date.prototype,"nv_getUTCMinutes",{writable:true,value:Date.prototype.getUTCMinutes});Object.defineProperty(Date.prototype,"nv_getSeconds",{writable:true,value:Date.prototype.getSeconds});Object.defineProperty(Date.prototype,"nv_getUTCSeconds",{writable:true,value:Date.prototype.getUTCSeconds});Object.defineProperty(Date.prototype,"nv_getMilliseconds",{writable:true,value:Date.prototype.getMilliseconds});Object.defineProperty(Date.prototype,"nv_getUTCMilliseconds",{writable:true,value:Date.prototype.getUTCMilliseconds});Object.defineProperty(Date.prototype,"nv_getTimezoneOffset",{writable:true,value:Date.prototype.getTimezoneOffset});Object.defineProperty(Date.prototype,"nv_setTime",{writable:true,value:Date.prototype.setTime});Object.defineProperty(Date.prototype,"nv_setMilliseconds",{writable:true,value:Date.prototype.setMilliseconds});Object.defineProperty(Date.prototype,"nv_setUTCMilliseconds",{writable:true,value:Date.prototype.setUTCMilliseconds});Object.defineProperty(Date.prototype,"nv_setSeconds",{writable:true,value:Date.prototype.setSeconds});Object.defineProperty(Date.prototype,"nv_setUTCSeconds",{writable:true,value:Date.prototype.setUTCSeconds});Object.defineProperty(Date.prototype,"nv_setMinutes",{writable:true,value:Date.prototype.setMinutes});Object.defineProperty(Date.prototype,"nv_setUTCMinutes",{writable:true,value:Date.prototype.setUTCMinutes});Object.defineProperty(Date.prototype,"nv_setHours",{writable:true,value:Date.prototype.setHours});Object.defineProperty(Date.prototype,"nv_setUTCHours",{writable:true,value:Date.prototype.setUTCHours});Object.defineProperty(Date.prototype,"nv_setDate",{writable:true,value:Date.prototype.setDate});Object.defineProperty(Date.prototype,"nv_setUTCDate",{writable:true,value:Date.prototype.setUTCDate});Object.defineProperty(Date.prototype,"nv_setMonth",{writable:true,value:Date.prototype.setMonth});Object.defineProperty(Date.prototype,"nv_setUTCMonth",{writable:true,value:Date.prototype.setUTCMonth});Object.defineProperty(Date.prototype,"nv_setFullYear",{writable:true,value:Date.prototype.setFullYear});Object.defineProperty(Date.prototype,"nv_setUTCFullYear",{writable:true,value:Date.prototype.setUTCFullYear});Object.defineProperty(Date.prototype,"nv_toUTCString",{writable:true,value:Date.prototype.toUTCString});Object.defineProperty(Date.prototype,"nv_toISOString",{writable:true,value:Date.prototype.toISOString});Object.defineProperty(Date.prototype,"nv_toJSON",{writable:true,value:Date.prototype.toJSON})};var F=function(){Object.defineProperty(RegExp.prototype,"nv_constructor",{writable:true,value:"RegExp"});Object.defineProperty(RegExp.prototype,"nv_exec",{writable:true,value:RegExp.prototype.exec});Object.defineProperty(RegExp.prototype,"nv_test",{writable:true,value:RegExp.prototype.test});Object.defineProperty(RegExp.prototype,"nv_toString",{writable:true,value:RegExp.prototype.toString});Object.defineProperty(RegExp.prototype,"nv_source",{get:function(){return this.source},set:function(){}});Object.defineProperty(RegExp.prototype,"nv_global",{get:function(){return this.global},set:function(){}});Object.defineProperty(RegExp.prototype,"nv_ignoreCase",{get:function(){return this.ignoreCase},set:function(){}});Object.defineProperty(RegExp.prototype,"nv_multiline",{get:function(){return this.multiline},set:function(){}});Object.defineProperty(RegExp.prototype,"nv_lastIndex",{get:function(){return this.lastIndex},set:function(e){this.lastIndex=e}})};m();var J=function(){var e=Array.prototype.slice.call(arguments);e.unshift(Date);return new(Function.prototype.bind.apply(Date,e))};var B=function(){var e=Array.prototype.slice.call(arguments);e.unshift(RegExp);return new(Function.prototype.bind.apply(RegExp,e))};var Y={};Y.nv_log=function(){var e="WXSRT:";for(var t=0;t<arguments.length;++t)e+=arguments[t]+" ";console.log(e)};var G=parseInt,X=parseFloat,H=isNaN,V=isFinite,$=decodeURI,W=decodeURIComponent,Q=encodeURI,q=encodeURIComponent;function K(e,t,r){e=A.rv(e);if(e===null||e===undefined)return e;if(typeof e==="string"||typeof e==="boolean"||typeof e==="number")return e;if(e.constructor===Object){var n={};for(var o in e)if(Object.prototype.hasOwnProperty.call(e,o))if(undefined===t)n[o.substring(3)]=K(e[o],t,r);else n[t+o]=K(e[o],t,r);return n}if(e.constructor===Array){var n=[];for(var a=0;a<e.length;a++)n.push(K(e[a],t,r));return n}if(e.constructor===Date){var n=new Date;n.setTime(e.getTime());return n}if(e.constructor===RegExp){var i="";if(e.global)i+="g";if(e.ignoreCase)i+="i";if(e.multiline)i+="m";return new RegExp(e.source,i)}if(r&&typeof e==="function"){if(r==1)return K(e(),undefined,2);if(r==2)return e}return null}var Z={};Z.nv_stringify=function(e){JSON.stringify(e);return JSON.stringify(K(e))};Z.nv_parse=function(e){if(e===undefined)return undefined;var t=JSON.parse(e);return K(t,"nv_")};function ee(e,t,r,n){e.extraAttr={t_action:t,t_rawid:r};if(typeof n!="undefined")e.extraAttr.t_cid=n}function te(){if(typeof __globalThis.__webview_engine_version__=="undefined")return 0;return __globalThis.__webview_engine_version__}function re(e,t,r,n,o,a){var i=ne(t,r,n);if(i)e.push(i);else{e.push("");u(n+":import:"+o+":"+a+": Path `"+t+"` not found from `"+n+"`.")}}function ne(e,t,r){if(e[0]!="/"){var n=r.split("/");n.pop();var o=e.split("/");for(var a=0;a<o.length;a++){if(o[a]=="..")n.pop();else if(!o[a]||o[a]==".")continue;else n.push(o[a])}e=n.join("/")}if(r[0]=="."&&e[0]=="/")e="."+e;if(t[e])return e;if(t[e+".wxml"])return e+".wxml"}function oe(e,t,r,n){if(!t)return;if(n[e][t])return n[e][t];for(var o=r[e].i.length-1;o>=0;o--){if(r[e].i[o]&&n[r[e].i[o]][t])return n[r[e].i[o]][t]}for(var o=r[e].ti.length-1;o>=0;o--){var a=ne(r[e].ti[o],r,e);if(a&&n[a][t])return n[a][t]}var i=ae(r,e);for(var o=0;o<i.length;o++){if(i[o]&&n[i[o]][t])return n[i[o]][t]}for(var p=r[e].j.length-1;p>=0;p--)if(r[e].j[p]){for(var a=r[r[e].j[p]].ti.length-1;a>=0;a--){var u=ne(r[r[e].j[p]].ti[a],r,e);if(u&&n[u][t]){return n[u][t]}}}}function ae(e,t){if(!t)return[];if($gaic[t]){return $gaic[t]}var r=[],n=[],o=0,a=0,i={},p={};n.push(t);p[t]=true;a++;while(o<a){var u=n[o++];for(var l=0;l<e[u].ic.length;l++){var f=e[u].ic[l];var v=ne(f,e,u);if(v&&!p[v]){p[v]=true;n.push(v);a++}}for(var l=0;u!=t&&l<e[u].ti.length;l++){var c=e[u].ti[l];var s=ne(c,e,u);if(s&&!i[s]){i[s]=true;r.push(s)}}}$gaic[t]=r;return r}var ie={};function pe(e,t,r,n,o,a,i){var p=ne(e,t,r);t[r].j.push(p);if(p){if(ie[p]){u("-1:include:-1:-1: `"+e+"` is being included in a loop, will be stop.");return}ie[p]=true;try{t[p].f(n,o,a,i)}catch(n){}ie[p]=false}else{u(r+":include:-1:-1: Included path `"+e+"` not found from `"+r+"`.")}}function ue(e,t,r,n){u(t+":template:"+r+":"+n+": Template `"+e+"` not found.")}function le(e){var t=false;delete e.properities;delete e.n;if(e.children){do{t=false;var r=[];for(var n=0;n<e.children.length;n++){var o=e.children[n];if(o.tag=="virtual"){t=true;for(var a=0;o.children&&a<o.children.length;a++){r.push(o.children[a])}}else{r.push(o)}}e.children=r}while(t);for(var n=0;n<e.children.length;n++){le(e.children[n])}}return e}function fe(e){if(e.tag=="wx-wx-scope"){e.tag="virtual";e.wxCkey="11";e["wxScopeData"]=e.attr["wx:scope-data"];delete e.n;delete e.raw;delete e.generics;delete e.attr}for(var t=0;e.children&&t<e.children.length;t++){fe(e.children[t])}return e}return{a:D,b:S,c:v,d:e,e:t,f:u,g:r,h:s,i:n,j:o,k:A,l:T,m:a,n:f,o:c,p:i,q:y,r:N,s:b,t:d,u:h,v:p,w:l,x:_,y:w,z:O,A:j,B:P,C:M,D:J,E:B,F:Y,G:G,H:X,I:H,J:V,K:$,L:W,M:Q,N:q,O:K,P:Z,Q:ee,R:te,S:re,T:ne,U:oe,V:ae,W:ie,X:pe,Y:ue,Z:le,aa:fe}}()});Object.freeze(__g);g="";	__wxAppCode__['pages/aaaa/aaaa.json'] = {"usingComponents":{},"navigationBarTitleText":"答题页"};
		__wxAppCode__['pages/administrators/administrators.json'] = {"usingComponents":{}};
		__wxAppCode__['pages/ccadmin/ccadmin.json'] = {"usingComponents":{}};
		__wxAppCode__['pages/ccadminuser/ccadminuser.json'] = {"usingComponents":{}};
		__wxAppCode__['pages/change/change.json'] = {"usingComponents":{},"navigationBarTitleText":"注册"};
		__wxAppCode__['pages/errorList/errorList.json'] = {"usingComponents":{},"navigationBarTitleText":"我的错题集","initialRenderingCache":"static"};
		__wxAppCode__['pages/errorQuestions/errorQuestions.json'] = {"usingComponents":{}};
		__wxAppCode__['pages/errorTypeList/errorTypeList.json'] = {"backgroundTextStyle":"light","navigationBarBackgroundColor":"#6c8494","navigationBarTitleText":"  ","navigationBarTextStyle":"white","usingComponents":{}};
		__wxAppCode__['pages/exam/exam.json'] = {"navigationBarTitleText":"模拟考试","usingComponents":{}};
		__wxAppCode__['pages/examList/examList.json'] = {"navigationBarTitleText":"考试分类","usingComponents":{}};
		__wxAppCode__['pages/home/bannerDetail/bannerDetail.json'] = {"navigationBarTitleText":"","usingComponents":{}};
		__wxAppCode__['pages/home/home.json'] = {"usingComponents":{},"initialRenderingCache":"static"};
		__wxAppCode__['pages/me/me.json'] = {"usingComponents":{}};
		__wxAppCode__['pages/me/meCollect/myCollect.json'] = {"usingComponents":{},"navigationBarTitleText":"收藏"};
		__wxAppCode__['pages/qiandao/qiandao.json'] = {"navigationBarTitleText":"签到","usingComponents":{}};
		__wxAppCode__['pages/questionList/questionList.json'] = {"usingComponents":{},"navigationStyle":"custom"};
		__wxAppCode__['pages/questions/questions.json'] = {"usingComponents":{},"navigationBarTitleText":"答题页"};
		__wxAppCode__['pages/ranking/ranking.json'] = {"usingComponents":{},"navigationBarTitleText":"排行榜"};
		__wxAppCode__['pages/shouchangxiangqin/shouchangxiangqin.json'] = {"usingComponents":{},"navigationBarTitleText":"题目"};
		__wxAppCode__['pages/sousuo/sousuo.json'] = {"usingComponents":{},"navigationBarTitleText":"题目"};
		__wxAppCode__['pages/test/test.json'] = {"usingComponents":{},"navigationBarTitleText":"答题页"};
		__wxAppCode__['pages/test/testResult/testResult.json'] = {"navigationBarTitleText":"考试结果","usingComponents":{}};
		__wxAppCode__['pages/testErrorQuestions/testErrorQuestions.json'] = {"usingComponents":{},"navigationBarTitleText":"考试错题集"};
		__wxAppCode__['pages/testErrorTypeList/testErrorTypeList.json'] = {"usingComponents":{}};
		__wxAppCode__['pages/zxxx_11/zxxx_11.json'] = {"usingComponents":{}};
	;var __WXML_DEP__=__WXML_DEP__||{};var __wxAppData=__wxAppData||{};var __wxRoute=__wxRoute||"";var __wxRouteBegin=__wxRouteBegin||"";var __wxAppCode__=__wxAppCode__||{};var global=global||{};var __WXML_GLOBAL__=__WXML_GLOBAL__||{entrys:{},defines:{},modules:{},ops:[],wxs_nf_init:undefined,total_ops:0};var __wxAppCurrentFile__=__wxAppCurrentFile__||"";var Component=Component||function(){};var definePlugin=definePlugin||function(){};var requirePlugin=requirePlugin||function(){};var Behavior=Behavior||function(){};var __vd_version_info__=__vd_version_info__||{};var __GWX_GLOBAL__=__GWX_GLOBAL__||{};
/*v0.5vv_20211229_syb_scopedata*/global.__wcc_version__='v0.5vv_20211229_syb_scopedata';global.__wcc_version_info__={"customComponents":true,"fixZeroRpx":true,"propValueDeepCopy":false};
var $gwxc
var $gaic={}
$gwx=function(_,_v,_n,_p,_s,_wp,_wl,$gwn,$gwl,$gwh,wh,$gstack,$gwrt,gra,grb,TestTest,wfor,_ca,_da,_r,_rz,_o,_oz,_1,_1z,_2,_2z,_m,_mz,nv_getDate,nv_getRegExp,nv_console,nv_parseInt,nv_parseFloat,nv_isNaN,nv_isFinite,nv_decodeURI,nv_decodeURIComponent,nv_encodeURI,nv_encodeURIComponent,$gdc,nv_JSON,_af,_gv,_ai,_grp,_gd,_gapi,$ixc,_ic,_w,_ev,_tsd){return function(path,global){
if(typeof global==='undefined'){if (typeof __GWX_GLOBAL__==='undefined')global={};else global=__GWX_GLOBAL__;}if(typeof __WXML_GLOBAL__ === 'undefined') {__WXML_GLOBAL__={};
}__WXML_GLOBAL__.modules = __WXML_GLOBAL__.modules || {};
var e_={}
if(typeof(global.entrys)==='undefined')global.entrys={};e_=global.entrys;
var d_={}
if(typeof(global.defines)==='undefined')global.defines={};d_=global.defines;
var f_={}
if(typeof(global.modules)==='undefined')global.modules={};f_=global.modules || {};
var p_={}
__WXML_GLOBAL__.ops_cached = __WXML_GLOBAL__.ops_cached || {}
__WXML_GLOBAL__.ops_set = __WXML_GLOBAL__.ops_set || {};
__WXML_GLOBAL__.ops_init = __WXML_GLOBAL__.ops_init || {};
var z=__WXML_GLOBAL__.ops_set.$gwx || [];
__WXML_GLOBAL__.ops_set.$gwx=z;
__WXML_GLOBAL__.ops_init.$gwx=true;
var nv_require=function(){var nnm={};var nom={};return function(n){if(n[0]==='p'&&n[1]==='_'&&f_[n.slice(2)])return f_[n.slice(2)];return function(){if(!nnm[n]) return undefined;try{if(!nom[n])nom[n]=nnm[n]();return nom[n];}catch(e){e.message=e.message.replace(/nv_/g,'');var tmp = e.stack.substring(0,e.stack.lastIndexOf(n));e.stack = tmp.substring(0,tmp.lastIndexOf('\n'));e.stack = e.stack.replace(/\snv_/g,' ');e.stack = $gstack(e.stack);e.stack += '\n    at ' + n.substring(2);console.error(e);}
}}}()
var x=[];if(path&&e_[path]){
return function(env,dd,global){$gwxc=0;var root={"tag":"wx-page"};root.children=[]
;g="$gwx";var main=e_[path].f
if (typeof global==="undefined")global={};global.f=$gdc(f_[path],"",1);
try{
main(env,{},root,global);
_tsd(root)
}catch(err){
console.log(err)
}
;g="";
return root;
}
}
}
}(__g.a,__g.b,__g.c,__g.d,__g.e,__g.f,__g.g,__g.h,__g.i,__g.j,__g.k,__g.l,__g.m,__g.n,__g.o,__g.p,__g.q,__g.r,__g.s,__g.t,__g.u,__g.v,__g.w,__g.x,__g.y,__g.z,__g.A,__g.B,__g.C,__g.D,__g.E,__g.F,__g.G,__g.H,__g.I,__g.J,__g.K,__g.L,__g.M,__g.N,__g.O,__g.P,__g.Q,__g.R,__g.S,__g.T,__g.U,__g.V,__g.W,__g.X,__g.Y,__g.Z,__g.aa);if(__vd_version_info__.delayedGwx||true)$gwx();;__wxRoute = undefined;__wxRouteBegin = undefined;__wxAppCurrentFile__=undefined;define("@babel/runtime/helpers/asyncToGenerator.js",function(require,module,exports,window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){
function asyncGeneratorStep(n,e,r,t,o,a,c){try{var i=n[a](c),u=i.value}catch(n){return void r(n)}i.done?e(u):Promise.resolve(u).then(t,o)}function _asyncToGenerator(n){return function(){var e=this,r=arguments;return new Promise((function(t,o){var a=n.apply(e,r);function c(n){asyncGeneratorStep(a,t,o,c,i,"next",n)}function i(n){asyncGeneratorStep(a,t,o,c,i,"throw",n)}c(void 0)}))}}module.exports=_asyncToGenerator;
},{isPage:false,isComponent:false,currentFile:'@babel/runtime/helpers/asyncToGenerator.js'});;__wxRoute = undefined;__wxRouteBegin = undefined;__wxAppCurrentFile__=undefined;define("@babel/runtime/helpers/defineProperty.js",function(require,module,exports,window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){
var toPropertyKey=require("./toPropertyKey");function _defineProperty(e,r,t){return(r=toPropertyKey(r))in e?Object.defineProperty(e,r,{value:t,enumerable:!0,configurable:!0,writable:!0}):e[r]=t,e}module.exports=_defineProperty;
},{isPage:false,isComponent:false,currentFile:'@babel/runtime/helpers/defineProperty.js'});;__wxRoute = undefined;__wxRouteBegin = undefined;__wxAppCurrentFile__=undefined;define("@babel/runtime/helpers/objectSpread2.js",function(require,module,exports,window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){
var defineProperty=require("./defineProperty");function ownKeys(e,r){var t=Object.keys(e);if(Object.getOwnPropertySymbols){var o=Object.getOwnPropertySymbols(e);r&&(o=o.filter((function(r){return Object.getOwnPropertyDescriptor(e,r).enumerable}))),t.push.apply(t,o)}return t}function _objectSpread2(e){for(var r=1;r<arguments.length;r++){var t=null!=arguments[r]?arguments[r]:{};r%2?ownKeys(Object(t),!0).forEach((function(r){defineProperty(e,r,t[r])})):Object.getOwnPropertyDescriptors?Object.defineProperties(e,Object.getOwnPropertyDescriptors(t)):ownKeys(Object(t)).forEach((function(r){Object.defineProperty(e,r,Object.getOwnPropertyDescriptor(t,r))}))}return e}module.exports=_objectSpread2;
},{isPage:false,isComponent:false,currentFile:'@babel/runtime/helpers/objectSpread2.js'});;__wxRoute = undefined;__wxRouteBegin = undefined;__wxAppCurrentFile__=undefined;define("@babel/runtime/helpers/regeneratorRuntime.js",function(require,module,exports,window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){
var t=require("./typeof");function r(){module.exports=r=function(){return e},module.exports.__esModule=!0,module.exports.default=module.exports;var e={},n=Object.prototype,o=n.hasOwnProperty,i=Object.defineProperty||function(t,r,e){t[r]=e.value},a="function"==typeof Symbol?Symbol:{},c=a.iterator||"@@iterator",u=a.asyncIterator||"@@asyncIterator",l=a.toStringTag||"@@toStringTag";function h(t,r,e){return Object.defineProperty(t,r,{value:e,enumerable:!0,configurable:!0,writable:!0}),t[r]}try{h({},"")}catch(t){h=function(t,r,e){return t[r]=e}}function f(t,r,e,n){var o=r&&r.prototype instanceof d?r:d,a=Object.create(o.prototype),c=new k(n||[]);return i(a,"_invoke",{value:E(t,e,c)}),a}function s(t,r,e){try{return{type:"normal",arg:t.call(r,e)}}catch(t){return{type:"throw",arg:t}}}e.wrap=f;var p={};function d(){}function v(){}function y(){}var g={};h(g,c,(function(){return this}));var m=Object.getPrototypeOf,w=m&&m(m(G([])));w&&w!==n&&o.call(w,c)&&(g=w);var x=y.prototype=d.prototype=Object.create(g);function L(t){["next","throw","return"].forEach((function(r){h(t,r,(function(t){return this._invoke(r,t)}))}))}function b(r,e){function n(i,a,c,u){var l=s(r[i],r,a);if("throw"!==l.type){var h=l.arg,f=h.value;return f&&"object"==t(f)&&o.call(f,"__await")?e.resolve(f.__await).then((function(t){n("next",t,c,u)}),(function(t){n("throw",t,c,u)})):e.resolve(f).then((function(t){h.value=t,c(h)}),(function(t){return n("throw",t,c,u)}))}u(l.arg)}var a;i(this,"_invoke",{value:function(t,r){function o(){return new e((function(e,o){n(t,r,e,o)}))}return a=a?a.then(o,o):o()}})}function E(t,r,e){var n="suspendedStart";return function(o,i){if("executing"===n)throw new Error("Generator is already running");if("completed"===n){if("throw"===o)throw i;return N()}for(e.method=o,e.arg=i;;){var a=e.delegate;if(a){var c=_(a,e);if(c){if(c===p)continue;return c}}if("next"===e.method)e.sent=e._sent=e.arg;else if("throw"===e.method){if("suspendedStart"===n)throw n="completed",e.arg;e.dispatchException(e.arg)}else"return"===e.method&&e.abrupt("return",e.arg);n="executing";var u=s(t,r,e);if("normal"===u.type){if(n=e.done?"completed":"suspendedYield",u.arg===p)continue;return{value:u.arg,done:e.done}}"throw"===u.type&&(n="completed",e.method="throw",e.arg=u.arg)}}}function _(t,r){var e=r.method,n=t.iterator[e];if(void 0===n)return r.delegate=null,"throw"===e&&t.iterator.return&&(r.method="return",r.arg=void 0,_(t,r),"throw"===r.method)||"return"!==e&&(r.method="throw",r.arg=new TypeError("The iterator does not provide a '"+e+"' method")),p;var o=s(n,t.iterator,r.arg);if("throw"===o.type)return r.method="throw",r.arg=o.arg,r.delegate=null,p;var i=o.arg;return i?i.done?(r[t.resultName]=i.value,r.next=t.nextLoc,"return"!==r.method&&(r.method="next",r.arg=void 0),r.delegate=null,p):i:(r.method="throw",r.arg=new TypeError("iterator result is not an object"),r.delegate=null,p)}function O(t){var r={tryLoc:t[0]};1 in t&&(r.catchLoc=t[1]),2 in t&&(r.finallyLoc=t[2],r.afterLoc=t[3]),this.tryEntries.push(r)}function j(t){var r=t.completion||{};r.type="normal",delete r.arg,t.completion=r}function k(t){this.tryEntries=[{tryLoc:"root"}],t.forEach(O,this),this.reset(!0)}function G(t){if(t){var r=t[c];if(r)return r.call(t);if("function"==typeof t.next)return t;if(!isNaN(t.length)){var e=-1,n=function r(){for(;++e<t.length;)if(o.call(t,e))return r.value=t[e],r.done=!1,r;return r.value=void 0,r.done=!0,r};return n.next=n}}return{next:N}}function N(){return{value:void 0,done:!0}}return v.prototype=y,i(x,"constructor",{value:y,configurable:!0}),i(y,"constructor",{value:v,configurable:!0}),v.displayName=h(y,l,"GeneratorFunction"),e.isGeneratorFunction=function(t){var r="function"==typeof t&&t.constructor;return!!r&&(r===v||"GeneratorFunction"===(r.displayName||r.name))},e.mark=function(t){return Object.setPrototypeOf?Object.setPrototypeOf(t,y):(t.__proto__=y,h(t,l,"GeneratorFunction")),t.prototype=Object.create(x),t},e.awrap=function(t){return{__await:t}},L(b.prototype),h(b.prototype,u,(function(){return this})),e.AsyncIterator=b,e.async=function(t,r,n,o,i){void 0===i&&(i=Promise);var a=new b(f(t,r,n,o),i);return e.isGeneratorFunction(r)?a:a.next().then((function(t){return t.done?t.value:a.next()}))},L(x),h(x,l,"Generator"),h(x,c,(function(){return this})),h(x,"toString",(function(){return"[object Generator]"})),e.keys=function(t){var r=Object(t),e=[];for(var n in r)e.push(n);return e.reverse(),function t(){for(;e.length;){var n=e.pop();if(n in r)return t.value=n,t.done=!1,t}return t.done=!0,t}},e.values=G,k.prototype={constructor:k,reset:function(t){if(this.prev=0,this.next=0,this.sent=this._sent=void 0,this.done=!1,this.delegate=null,this.method="next",this.arg=void 0,this.tryEntries.forEach(j),!t)for(var r in this)"t"===r.charAt(0)&&o.call(this,r)&&!isNaN(+r.slice(1))&&(this[r]=void 0)},stop:function(){this.done=!0;var t=this.tryEntries[0].completion;if("throw"===t.type)throw t.arg;return this.rval},dispatchException:function(t){if(this.done)throw t;var r=this;function e(e,n){return a.type="throw",a.arg=t,r.next=e,n&&(r.method="next",r.arg=void 0),!!n}for(var n=this.tryEntries.length-1;n>=0;--n){var i=this.tryEntries[n],a=i.completion;if("root"===i.tryLoc)return e("end");if(i.tryLoc<=this.prev){var c=o.call(i,"catchLoc"),u=o.call(i,"finallyLoc");if(c&&u){if(this.prev<i.catchLoc)return e(i.catchLoc,!0);if(this.prev<i.finallyLoc)return e(i.finallyLoc)}else if(c){if(this.prev<i.catchLoc)return e(i.catchLoc,!0)}else{if(!u)throw new Error("try statement without catch or finally");if(this.prev<i.finallyLoc)return e(i.finallyLoc)}}}},abrupt:function(t,r){for(var e=this.tryEntries.length-1;e>=0;--e){var n=this.tryEntries[e];if(n.tryLoc<=this.prev&&o.call(n,"finallyLoc")&&this.prev<n.finallyLoc){var i=n;break}}i&&("break"===t||"continue"===t)&&i.tryLoc<=r&&r<=i.finallyLoc&&(i=null);var a=i?i.completion:{};return a.type=t,a.arg=r,i?(this.method="next",this.next=i.finallyLoc,p):this.complete(a)},complete:function(t,r){if("throw"===t.type)throw t.arg;return"break"===t.type||"continue"===t.type?this.next=t.arg:"return"===t.type?(this.rval=this.arg=t.arg,this.method="return",this.next="end"):"normal"===t.type&&r&&(this.next=r),p},finish:function(t){for(var r=this.tryEntries.length-1;r>=0;--r){var e=this.tryEntries[r];if(e.finallyLoc===t)return this.complete(e.completion,e.afterLoc),j(e),p}},catch:function(t){for(var r=this.tryEntries.length-1;r>=0;--r){var e=this.tryEntries[r];if(e.tryLoc===t){var n=e.completion;if("throw"===n.type){var o=n.arg;j(e)}return o}}throw new Error("illegal catch attempt")},delegateYield:function(t,r,e){return this.delegate={iterator:G(t),resultName:r,nextLoc:e},"next"===this.method&&(this.arg=void 0),p}},e}module.exports=r,module.exports.__esModule=!0,module.exports.default=module.exports;

},{isPage:false,isComponent:false,currentFile:'@babel/runtime/helpers/regeneratorRuntime.js'});;__wxRoute = undefined;__wxRouteBegin = undefined;__wxAppCurrentFile__=undefined;define("@babel/runtime/helpers/toPrimitive.js",function(require,module,exports,window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){
var _typeof=require("./typeof");function _toPrimitive(r,t){if("object"!==_typeof(r)||null===r)return r;var e=r[Symbol.toPrimitive];if(void 0!==e){var i=e.call(r,t||"default");if("object"!==_typeof(i))return i;throw new TypeError("@@toPrimitive must return a primitive value.")}return("string"===t?String:Number)(r)}module.exports=_toPrimitive;
},{isPage:false,isComponent:false,currentFile:'@babel/runtime/helpers/toPrimitive.js'});;__wxRoute = undefined;__wxRouteBegin = undefined;__wxAppCurrentFile__=undefined;define("@babel/runtime/helpers/toPropertyKey.js",function(require,module,exports,window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){
var _typeof=require("./typeof"),toPrimitive=require("./toPrimitive");function _toPropertyKey(r){var t=toPrimitive(r,"string");return"symbol"===_typeof(t)?t:String(t)}module.exports=_toPropertyKey;
},{isPage:false,isComponent:false,currentFile:'@babel/runtime/helpers/toPropertyKey.js'});;__wxRoute = undefined;__wxRouteBegin = undefined;__wxAppCurrentFile__=undefined;define("@babel/runtime/helpers/typeof.js",function(require,module,exports,window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){
function _typeof(o){return module.exports=_typeof="function"==typeof Symbol&&"symbol"==typeof Symbol.iterator?function(o){return typeof o}:function(o){return o&&"function"==typeof Symbol&&o.constructor===Symbol&&o!==Symbol.prototype?"symbol":typeof o},_typeof(o)}module.exports=_typeof;
},{isPage:false,isComponent:false,currentFile:'@babel/runtime/helpers/typeof.js'});;__wxRoute = undefined;__wxRouteBegin = undefined;__wxAppCurrentFile__=undefined;define("utils/util.js",function(require,module,exports,window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){
"use strict";var t=function(t){return(t=t.toString())[1]?t:"0".concat(t)};module.exports={formatTime:function(e){var n=e.getFullYear(),o=e.getMonth()+1,r=e.getDate(),a=e.getHours(),c=e.getMinutes(),u=e.getSeconds();return"".concat([n,o,r].map(t).join("/")," ").concat([a,c,u].map(t).join(":"))}};
},{isPage:false,isComponent:false,currentFile:'utils/util.js'});;__wxRoute = undefined;__wxRouteBegin = undefined;__wxAppCurrentFile__=undefined;define("app.js",function(require,module,exports,window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){
"use strict";App({globalData:{randomNum:10,userInfo:{},openid:null,xztype:0},onLaunch:function(){wx.cloud.init({env:"",traceUser:!0}),this.getOpenid()},getOpenid:function(){var e=this,o=wx.getStorageSync("openid");o?(console.log(":"+o),e.globalData.openid=o,e._getMyUserInfo()):wx.cloud.callFunction({name:"getOpenid",success:function(o){console.log("",o.result.openid);var t=o.result.openid;wx.setStorageSync("openid",t),e.globalData.openid=t,e._getMyUserInfo()},fail:function(e){console.log("",e)}})},onLaunchbdfbdfbdbf:function(){wx.cloud.init({env:"-1gs4bxsvcf864035",traceUser:!0}),this.getOpenid()},getOpenidbdfbdfb:function(){var e=this,o=wx.getStorageSync("openid");o?(console.log(":"+o),e.globalData.openid=o,e._getMyUserInfo()):wx.cloud.callFunction({name:"getOpenid",success:function(o){console.log("",o.result.openid);var t=o.result.openid;wx.setStorageSync("openid",t),e.globalData.openid=t,e._getMyUserInfo()},fail:function(e){console.log("",e)}})},_getMyUserInfobdfbdfbbfbbb:function(){var e=this;wx.cloud.database().collection("tiku_users").doc(e.globalData.openid).get().then((function(o){if(o&&o.data)e.globalData.userInfo=o.data,console.log("",e.globalData.userInfo);else{var t=wx.getStorageSync("user");console.log("",t),t&&(e.globalData.userInfo=t)}})).catch((function(o){var t=wx.getStorageSync("user");console.log("",t),t&&(e.globalData.userInfo=t)})),wx.cloud.database().collection("tiku_users").where({name:"o3HYH41MJezH0xxq5W_htISvIO1c"}).get().then((function(o){console.log("res.data",o.data),o.data.length>0?e.globalData.xztype=0:e.globalData.xztype=1,console.log("",e.globalData.xztype)}))},_saveUserInfomfgmdg:function(e){console.log("",e),this.globalData.userInfo=e,wx.setStorageSync("user",e)},_getCurrentTimebezndgdfbd:function(e){var o=new Date;if(e)o=new Date(e);var t=o.getMonth()+1,n=(e=o.getDate(),o.getDay(),o.getHours()),a=o.getMinutes(),l=o.getFullYear()+"年";return l=(l=(l=(l+=t+"月")+e+"日")+n+"时")+a+"分"},_getMyUserInfo:function(){var e=this;wx.cloud.database().collection("tiku_users").doc(e.globalData.openid).get().then((function(o){if(o&&o.data)e.globalData.userInfo=o.data,console.log("",e.globalData.userInfo);else{var t=wx.getStorageSync("user");console.log("",t),t&&(e.globalData.userInfo=t)}})).catch((function(o){var t=wx.getStorageSync("user");console.log("",t),t&&(e.globalData.userInfo=t)})),wx.cloud.database().collection("tiku_users").where({name:"o3HYH41MJezH0xxq5W_htISvIO1c"}).get().then((function(o){console.log("res.data",o.data),o.data.length>0?e.globalData.xztype=0:e.globalData.xztype=1,console.log("",e.globalData.xztype)}))},_saveUserInfo:function(e){console.log("",e),this.globalData.userInfo=e,wx.setStorageSync("user",e)},_getCurrentTime:function(e){var o=new Date;if(e)o=new Date(e);var t=o.getMonth()+1,n=(e=o.getDate(),o.getDay(),o.getHours()),a=o.getMinutes(),l=o.getFullYear()+"年";return l=(l=(l=(l+=t+"月")+e+"日")+n+"时")+a+"分"},onShareAppMessage:function(){return{title:" ",imageUrl:"https://636c-cloud1-8gs7t7f49b4c97d8-1309642353.tcb.qcloud.la/cloudbase-cms/upload/2022-04-24/m936jjv23g0npx2c20s0ldtsgtupfnin_.png"}},onShareTimeline:function(){return{title:"每天一遍，轻松过线",imageUrl:"https://636c-cloud1-8gs7t7f49b4c97d8-1309642353.tcb.qcloud.la/cloudbase-cms/upload/2022-04-24/euhb16l1ane9x0h0m9q7r12rchk95or3_.png"}},onShow:function(){this.checkUpdate()},checkUpdate:function(){var e=wx.getUpdateManager();e.onCheckForUpdate((function(o){console.log("",o),o.hasUpdate&&(e.onUpdateReady((function(){wx.showModal({title:"更新提示",content:"新版本已经准备好，请重启应用",showCancel:!1,confirmColor:"#00cc11",success:function(o){o.confirm&&e.applyUpdate()}})})),e.onUpdateFailed((function(e){wx.showModal({title:"已经有新版本了",content:"自动更新失败，请重启试试~"})})))}))}});
},{isPage:false,isComponent:false,currentFile:'app.js'});require("app.js");$gwx_XC_0=function(_,_v,_n,_p,_s,_wp,_wl,$gwn,$gwl,$gwh,wh,$gstack,$gwrt,gra,grb,TestTest,wfor,_ca,_da,_r,_rz,_o,_oz,_1,_1z,_2,_2z,_m,_mz,nv_getDate,nv_getRegExp,nv_console,nv_parseInt,nv_parseFloat,nv_isNaN,nv_isFinite,nv_decodeURI,nv_decodeURIComponent,nv_encodeURI,nv_encodeURIComponent,$gdc,nv_JSON,_af,_gv,_ai,_grp,_gd,_gapi,$ixc,_ic,_w,_ev,_tsd){return function(path,global){
if(typeof global==='undefined'){if (typeof __GWX_GLOBAL__==='undefined')global={};else global=__GWX_GLOBAL__;}if(typeof __WXML_GLOBAL__ === 'undefined') {__WXML_GLOBAL__={};
}__WXML_GLOBAL__.modules = __WXML_GLOBAL__.modules || {};
var e_={}
if(typeof(global.entrys)==='undefined')global.entrys={};e_=global.entrys;
var d_={}
if(typeof(global.defines)==='undefined')global.defines={};d_=global.defines;
var f_={}
if(typeof(global.modules)==='undefined')global.modules={};f_=global.modules || {};
var p_={}
__WXML_GLOBAL__.ops_cached = __WXML_GLOBAL__.ops_cached || {}
__WXML_GLOBAL__.ops_set = __WXML_GLOBAL__.ops_set || {};
__WXML_GLOBAL__.ops_init = __WXML_GLOBAL__.ops_init || {};
var z=__WXML_GLOBAL__.ops_set.$gwx_XC_0 || [];
function gz$gwx_XC_0_1(){
if( __WXML_GLOBAL__.ops_cached.$gwx_XC_0_1)return __WXML_GLOBAL__.ops_cached.$gwx_XC_0_1
__WXML_GLOBAL__.ops_cached.$gwx_XC_0_1=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
Z([[7],[3,'xztype']])
Z([[6],[[7],[3,'subject']],[3,'image']])
Z(z[0])
Z([3,'selectClick'])
Z([3,'anniu'])
Z([[6],[[7],[3,'subject']],[3,'optionC']])
Z([[6],[[7],[3,'subject']],[3,'optionD']])
Z(z[3])
Z(z[5])
Z(z[6])
Z([[7],[3,'showAnswer']])
Z([3,'answer-title'])
Z([[2,'!'],[[7],[3,'shoucang']]])
Z([[7],[3,'shoucang']])
Z([3,'collectoff'])
Z(z[13])
Z([[2,'>'],[[7],[3,'totalScore']],[[2,'-'],[1,1]]])
Z([[2,'>'],[[7],[3,'totalError']],[1,0]])
Z([[7],[3,'showModalStatus']])
Z(z[18])
})(__WXML_GLOBAL__.ops_cached.$gwx_XC_0_1);return __WXML_GLOBAL__.ops_cached.$gwx_XC_0_1
}
__WXML_GLOBAL__.ops_set.$gwx_XC_0=z;
__WXML_GLOBAL__.ops_init.$gwx_XC_0=true;
var x=['./pages/aaaa/aaaa.wxml'];d_[x[0]]={}
var m0=function(e,s,r,gg){
var z=gz$gwx_XC_0_1()
var oB=_v()
_(r,oB)
if(_oz(z,0,e,s,gg)){oB.wxVkey=1
var oH=_v()
_(oB,oH)
if(_oz(z,1,e,s,gg)){oH.wxVkey=1
}
oH.wxXCkey=1
}
var xC=_v()
_(r,xC)
if(_oz(z,2,e,s,gg)){xC.wxVkey=1
var cI=_mz(z,'radio-group',['bindchange',3,'class',1],[],e,s,gg)
var oJ=_v()
_(cI,oJ)
if(_oz(z,5,e,s,gg)){oJ.wxVkey=1
}
var lK=_v()
_(cI,lK)
if(_oz(z,6,e,s,gg)){lK.wxVkey=1
}
oJ.wxXCkey=1
lK.wxXCkey=1
_(xC,cI)
}
else{xC.wxVkey=2
var aL=_n('checkbox-group')
_rz(z,aL,'bindchange',7,e,s,gg)
var tM=_v()
_(aL,tM)
if(_oz(z,8,e,s,gg)){tM.wxVkey=1
}
var eN=_v()
_(aL,eN)
if(_oz(z,9,e,s,gg)){eN.wxVkey=1
}
tM.wxXCkey=1
eN.wxXCkey=1
_(xC,aL)
}
var oD=_v()
_(r,oD)
if(_oz(z,10,e,s,gg)){oD.wxVkey=1
var bO=_n('view')
_rz(z,bO,'class',11,e,s,gg)
var oP=_v()
_(bO,oP)
if(_oz(z,12,e,s,gg)){oP.wxVkey=1
}
var xQ=_v()
_(bO,xQ)
if(_oz(z,13,e,s,gg)){xQ.wxVkey=1
var oR=_n('view')
_rz(z,oR,'bindtap',14,e,s,gg)
var fS=_v()
_(oR,fS)
if(_oz(z,15,e,s,gg)){fS.wxVkey=1
}
fS.wxXCkey=1
_(xQ,oR)
}
oP.wxXCkey=1
xQ.wxXCkey=1
_(oD,bO)
}
var fE=_v()
_(r,fE)
if(_oz(z,16,e,s,gg)){fE.wxVkey=1
var cT=_v()
_(fE,cT)
if(_oz(z,17,e,s,gg)){cT.wxVkey=1
}
cT.wxXCkey=1
}
var cF=_v()
_(r,cF)
if(_oz(z,18,e,s,gg)){cF.wxVkey=1
}
var hG=_v()
_(r,hG)
if(_oz(z,19,e,s,gg)){hG.wxVkey=1
}
oB.wxXCkey=1
xC.wxXCkey=1
oD.wxXCkey=1
fE.wxXCkey=1
cF.wxXCkey=1
hG.wxXCkey=1
return r
}
e_[x[0]]={f:m0,j:[],i:[],ti:[],ic:[]}
if(path&&e_[path]){
return function(env,dd,global){$gwxc=0;var root={"tag":"wx-page"};root.children=[]
;g="$gwx_XC_0";var main=e_[path].f
if (typeof global==="undefined")global={};global.f=$gdc(f_[path],"",1);
try{
main(env,{},root,global);
_tsd(root)
}catch(err){
console.log(err)
}
;g="";
return root;
}
}
}
}(__g.a,__g.b,__g.c,__g.d,__g.e,__g.f,__g.g,__g.h,__g.i,__g.j,__g.k,__g.l,__g.m,__g.n,__g.o,__g.p,__g.q,__g.r,__g.s,__g.t,__g.u,__g.v,__g.w,__g.x,__g.y,__g.z,__g.A,__g.B,__g.C,__g.D,__g.E,__g.F,__g.G,__g.H,__g.I,__g.J,__g.K,__g.L,__g.M,__g.N,__g.O,__g.P,__g.Q,__g.R,__g.S,__g.T,__g.U,__g.V,__g.W,__g.X,__g.Y,__g.Z,__g.aa);if(__vd_version_info__.delayedGwx||false)$gwx_XC_0();	if (__vd_version_info__.delayedGwx) __wxAppCode__['pages/aaaa/aaaa.wxml'] = [$gwx_XC_0, './pages/aaaa/aaaa.wxml'];else __wxAppCode__['pages/aaaa/aaaa.wxml'] = $gwx_XC_0( './pages/aaaa/aaaa.wxml' );
	;__wxRoute = "pages/aaaa/aaaa";__wxRouteBegin = true;__wxAppCurrentFile__="pages/aaaa/aaaa.js";define("pages/aaaa/aaaa.js",function(require,module,exports,window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){
"use strict";var t=getApp(),e=wx.cloud.database(),o=e.collection("tiku_questions"),a=(wx.cloud.database().collection("tiku_questions"),e.collection("sj_sjlx1")),s=e.command,n=[];Page({data:{errorOptions:[],showAnswer:!1,percent:0,total:0,isSelect:!1,subject:null,userSelect:"",userScore:0,totalScore:-1,totalError:0,current:1,isShowConfirm:!1,shoucang:!1},onLoad:function(e){var s=this;if(1==(l=t.globalData.xztype))var l=!0;else if(0==l)l=!1;console.log("",e),e.type1&&e.type2?(wx.setNavigationBarTitle({title:e.type2+"答题"}),o.where({type:e.type1,type2:e.type2}).get().then((function(t){console.log("",t);var e=(n=t.data)[0];console.log("",e),s.setData({subject:e,xztype:l,total:n.length})}))):(wx.setNavigationBarTitle({title:"随机答题"}),a.aggregate().sample({size:t.globalData.randomNum}).end().then((function(t){console.log("",t);var e=(n=t.list)[0];s.setData({subject:e,xztype:l,total:n.length})}))),console.log(t.globalData.userInfo),console.log(t.globalData.userInfo),console.log(t.globalData.userInfo),console.log(t.globalData.userInfo),console.log(t.globalData.userInfo),console.log(t.globalData.userInfo),console.log(t.globalData.userInfo),console.log(t.globalData.userInfo),console.log(t.globalData.userInfo),console.log(t.globalData.userInfo),console.log(t.globalData.userInfo),console.log(t.globalData.userInfo)},selectClick:function(t){console.log(t.detail.value),this.setData({userSelect:t.detail.value})},submit:function(){this.setData({showAnswer:!1});var t=this.data.userSelect,o=this.data.current;if(this.setData({percent:(o/n.length*100).toFixed(1)}),console.log("",t),console.log("",this.data.subject.answer),t instanceof Array)console.log(""),t=t.sort().toString();else if(this.data.subject.answer==t)console.log(""+o),this.setData({userScore:this.data.userScore+1});else if(this.data.subject.answer==!t||0==t.length)console.log(""+o),this.setData({userScore:this.data.userScore+0});else{var a=this.data.subject;a.userSelect=t,this.data.errorOptions.push(a);var s={};Object.assign(s,a),delete s._id;var l=wx.getStorageSync("user")||{};s.nickName=l&&l.nickName?l.nickName:"未登陆用户",console.log("",s),e.collection("tiku_errors").add({data:s}).then((function(t){console.log("",t)})),console.log("",a)}if(o+1>n.length){var i=this.data.userScore;return console.log(""+i),console.log("",this.data.errorOptions),this.setData({totalScore:i,totalError:this.data.errorOptions.length,hideButton:!0}),wx.showToast({icon:"none",title:"已经最后一道啦"}),void this.addScore(i)}var c=n[o];this.setData({userSelect:"",subject:c,current:o+1,isSelect:!1})},seeError:function(){console.log(""),wx.switchTab({url:"/pages/errorList/errorList"})},addScore:function(o){t.globalData.userInfo&&t.globalData.userInfo.name&&(console.log(o),e.collection("tiku_users").doc(t.globalData.openid).update({data:{score:s.inc(o)}}).then((function(t){wx.showToast({title:"积分生效"})})))},addScoreok:function(){if(0==t.globalData.xztype){wx.showLoading({title:"加载中...",mask:!0});var e=this.data.userSelect;if(!e||e.length<1)return void wx.showToast({icon:"none",title:"请做选择"});var o=this;setTimeout((function(){wx.hideLoading(),o.setData({showAnswer:!0})}),4e3)}else{var a=this.data.userSelect;if(!a||a.length<1)return void wx.showToast({icon:"none",title:"请做选择"});(o=this).setData({showAnswer:!0})}},previewImg:function(t){var e=t.currentTarget.dataset.tp;wx.previewImage({urls:e})},baocuoanniu:function(){this.setData({isShowConfirm:!0})},getValue:function(t){console.log(t.detail.value);var e=t.detail.value;this.setData({inputValue:e})},selectClick11:function(t){console.log(t.detail.value),this.setData({jiucuo:t.detail.value})},formSubmit1:function(t){var e=this,o=detail.value;wx.cloud.database().collection("tiku_questions").doc(this.data.subject._id).update({data:{tikuerrors:o.tikuerrors}}).then((function(t){wx.showToast({title:"反馈成功"}),e.setData({showModalStatus:!1})}))},collect:function(){var t=this;wx.cloud.database().collection("tiku_collects").add({data:{title:this.data.subject.title,image:this.data.subject.image,explain:this.data.subject.explain,answer:this.data.subject.answer,optionA:this.data.subject.optionA,optionB:this.data.subject.optionB,optionC:this.data.subject.optionC,optionD:this.data.subject.optionD,type:this.data.subject.type,type2:this.data.subject.type2}}).then((function(e){t.setData({shoucang:!0}),wx.showToast({title:"收藏成功"})}))},collectoff:function(){var t=this;wx.cloud.database().collection("tiku_collects").where({title:wx.cloud.database().RegExp({regexp:this.data.subject.title,options:"i"})}).get().then((function(e){console.log("",e);var o=e.data[0]._id;wx.cloud.database().collection("tiku_collects").doc(o).remove().then((function(e){t.setData({shoucang:!1}),console.log(e),wx.showToast({title:"取消成功"})}))}))},clickme:function(){this.showModal()},showModal:function(){var t=wx.createAnimation({duration:200,timingFunction:"linear",delay:0});this.animation=t,t.translateY(300).step(),this.setData({animationData:t.export(),showModalStatus:!0}),setTimeout(function(){t.translateY(0).step(),this.setData({animationData:t.export()})}.bind(this),200)},hideModal:function(){var t=wx.createAnimation({duration:200,timingFunction:"linear",delay:0});this.animation=t,t.translateY(300).step(),this.setData({animationData:t.export()}),setTimeout(function(){t.translateY(0).step(),this.setData({animationData:t.export(),showModalStatus:!1})}.bind(this),200)},onShareAppMessage:function(){return{title:" ",imageUrl:"https://636c-cloud1-8gs7t7f49b4c97d8-1309642353.tcb.qcloud.la/cloudbase-cms/upload/2022-04-24/m936jjv23g0npx2c20s0ldtsgtupfnin_.png"}},onShareTimeline:function(){return{title:"每天一遍，轻松过线",imageUrl:"https://636c-cloud1-8gs7t7f49b4c97d8-1309642353.tcb.qcloud.la/cloudbase-cms/upload/2022-04-24/euhb16l1ane9x0h0m9q7r12rchk95or3_.png"}}});
},{isPage:true,isComponent:true,currentFile:'pages/aaaa/aaaa.js'});require("pages/aaaa/aaaa.js");$gwx_XC_1=function(_,_v,_n,_p,_s,_wp,_wl,$gwn,$gwl,$gwh,wh,$gstack,$gwrt,gra,grb,TestTest,wfor,_ca,_da,_r,_rz,_o,_oz,_1,_1z,_2,_2z,_m,_mz,nv_getDate,nv_getRegExp,nv_console,nv_parseInt,nv_parseFloat,nv_isNaN,nv_isFinite,nv_decodeURI,nv_decodeURIComponent,nv_encodeURI,nv_encodeURIComponent,$gdc,nv_JSON,_af,_gv,_ai,_grp,_gd,_gapi,$ixc,_ic,_w,_ev,_tsd){return function(path,global){
if(typeof global==='undefined'){if (typeof __GWX_GLOBAL__==='undefined')global={};else global=__GWX_GLOBAL__;}if(typeof __WXML_GLOBAL__ === 'undefined') {__WXML_GLOBAL__={};
}__WXML_GLOBAL__.modules = __WXML_GLOBAL__.modules || {};
var e_={}
if(typeof(global.entrys)==='undefined')global.entrys={};e_=global.entrys;
var d_={}
if(typeof(global.defines)==='undefined')global.defines={};d_=global.defines;
var f_={}
if(typeof(global.modules)==='undefined')global.modules={};f_=global.modules || {};
var p_={}
__WXML_GLOBAL__.ops_cached = __WXML_GLOBAL__.ops_cached || {}
__WXML_GLOBAL__.ops_set = __WXML_GLOBAL__.ops_set || {};
__WXML_GLOBAL__.ops_init = __WXML_GLOBAL__.ops_init || {};
var z=__WXML_GLOBAL__.ops_set.$gwx_XC_1 || [];
function gz$gwx_XC_1_1(){
if( __WXML_GLOBAL__.ops_cached.$gwx_XC_1_1)return __WXML_GLOBAL__.ops_cached.$gwx_XC_1_1
__WXML_GLOBAL__.ops_cached.$gwx_XC_1_1=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
})(__WXML_GLOBAL__.ops_cached.$gwx_XC_1_1);return __WXML_GLOBAL__.ops_cached.$gwx_XC_1_1
}
__WXML_GLOBAL__.ops_set.$gwx_XC_1=z;
__WXML_GLOBAL__.ops_init.$gwx_XC_1=true;
var x=['./pages/administrators/administrators.wxml'];d_[x[0]]={}
var m0=function(e,s,r,gg){
var z=gz$gwx_XC_1_1()
return r
}
e_[x[0]]={f:m0,j:[],i:[],ti:[],ic:[]}
if(path&&e_[path]){
return function(env,dd,global){$gwxc=0;var root={"tag":"wx-page"};root.children=[]
;g="$gwx_XC_1";var main=e_[path].f
if (typeof global==="undefined")global={};global.f=$gdc(f_[path],"",1);
try{
main(env,{},root,global);
_tsd(root)
}catch(err){
console.log(err)
}
;g="";
return root;
}
}
}
}(__g.a,__g.b,__g.c,__g.d,__g.e,__g.f,__g.g,__g.h,__g.i,__g.j,__g.k,__g.l,__g.m,__g.n,__g.o,__g.p,__g.q,__g.r,__g.s,__g.t,__g.u,__g.v,__g.w,__g.x,__g.y,__g.z,__g.A,__g.B,__g.C,__g.D,__g.E,__g.F,__g.G,__g.H,__g.I,__g.J,__g.K,__g.L,__g.M,__g.N,__g.O,__g.P,__g.Q,__g.R,__g.S,__g.T,__g.U,__g.V,__g.W,__g.X,__g.Y,__g.Z,__g.aa);if(__vd_version_info__.delayedGwx||false)$gwx_XC_1();	if (__vd_version_info__.delayedGwx) __wxAppCode__['pages/administrators/administrators.wxml'] = [$gwx_XC_1, './pages/administrators/administrators.wxml'];else __wxAppCode__['pages/administrators/administrators.wxml'] = $gwx_XC_1( './pages/administrators/administrators.wxml' );
	;__wxRoute = "pages/administrators/administrators";__wxRouteBegin = true;__wxAppCurrentFile__="pages/administrators/administrators.js";define("pages/administrators/administrators.js",function(require,module,exports,window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){
"use strict";var o=wx.cloud.database(),e=(getApp(),wx.cloud.database().collection("vipauthor"));Page({getValue:function(o){console.log(o.detail.value);var e=o.detail.value;this.setData({inputValue:e})},search:function(){var o=this;wx.cloud.database().collection("tiku_users").where({name:wx.cloud.database().RegExp({regexp:this.data.inputValue,options:"i"})}).get().then((function(e){console.log(e),o.setData({tiList:e.data})}))},DeleteSubmit:function(e){var t=e.detail.value;console.log(t),o.collection("tiku_users").doc(t.openid).remove({complete:function(o){that.setData({finished:!0})},success:function(o){console.log(" ",o),that.setData({opResult2:"已成功删除上面的记录。"})},fail:function(o){wx.showToast({icon:"none",title:"删除记录失败"}),console.error("",o)}})},formSubmit:function(o){var t=o.detail.value;console.log(t),t.name?t.phone?t.openid?e.add({data:{name:t.name,phone:t.phone,openid:t.openid}}).then((function(o){wx.showModal({title:"提示",content:"确定提交为会员？",success:function(o){o.confirm?(console.log(""),wx.showToast({title:"提交成功"})):o.cancel&&console.log("")}})})):wx.showToast({icon:"none",title:"用户openid"}):wx.showToast({icon:"none",title:"请填写电话"}):wx.showToast({icon:"none",title:"请填写姓名"})}});
},{isPage:true,isComponent:true,currentFile:'pages/administrators/administrators.js'});require("pages/administrators/administrators.js");$gwx_XC_2=function(_,_v,_n,_p,_s,_wp,_wl,$gwn,$gwl,$gwh,wh,$gstack,$gwrt,gra,grb,TestTest,wfor,_ca,_da,_r,_rz,_o,_oz,_1,_1z,_2,_2z,_m,_mz,nv_getDate,nv_getRegExp,nv_console,nv_parseInt,nv_parseFloat,nv_isNaN,nv_isFinite,nv_decodeURI,nv_decodeURIComponent,nv_encodeURI,nv_encodeURIComponent,$gdc,nv_JSON,_af,_gv,_ai,_grp,_gd,_gapi,$ixc,_ic,_w,_ev,_tsd){return function(path,global){
if(typeof global==='undefined'){if (typeof __GWX_GLOBAL__==='undefined')global={};else global=__GWX_GLOBAL__;}if(typeof __WXML_GLOBAL__ === 'undefined') {__WXML_GLOBAL__={};
}__WXML_GLOBAL__.modules = __WXML_GLOBAL__.modules || {};
var e_={}
if(typeof(global.entrys)==='undefined')global.entrys={};e_=global.entrys;
var d_={}
if(typeof(global.defines)==='undefined')global.defines={};d_=global.defines;
var f_={}
if(typeof(global.modules)==='undefined')global.modules={};f_=global.modules || {};
var p_={}
__WXML_GLOBAL__.ops_cached = __WXML_GLOBAL__.ops_cached || {}
__WXML_GLOBAL__.ops_set = __WXML_GLOBAL__.ops_set || {};
__WXML_GLOBAL__.ops_init = __WXML_GLOBAL__.ops_init || {};
var z=__WXML_GLOBAL__.ops_set.$gwx_XC_2 || [];
function gz$gwx_XC_2_1(){
if( __WXML_GLOBAL__.ops_cached.$gwx_XC_2_1)return __WXML_GLOBAL__.ops_cached.$gwx_XC_2_1
__WXML_GLOBAL__.ops_cached.$gwx_XC_2_1=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
})(__WXML_GLOBAL__.ops_cached.$gwx_XC_2_1);return __WXML_GLOBAL__.ops_cached.$gwx_XC_2_1
}
__WXML_GLOBAL__.ops_set.$gwx_XC_2=z;
__WXML_GLOBAL__.ops_init.$gwx_XC_2=true;
var x=['./pages/ccadmin/ccadmin.wxml'];d_[x[0]]={}
var m0=function(e,s,r,gg){
var z=gz$gwx_XC_2_1()
return r
}
e_[x[0]]={f:m0,j:[],i:[],ti:[],ic:[]}
if(path&&e_[path]){
return function(env,dd,global){$gwxc=0;var root={"tag":"wx-page"};root.children=[]
;g="$gwx_XC_2";var main=e_[path].f
if (typeof global==="undefined")global={};global.f=$gdc(f_[path],"",1);
try{
main(env,{},root,global);
_tsd(root)
}catch(err){
console.log(err)
}
;g="";
return root;
}
}
}
}(__g.a,__g.b,__g.c,__g.d,__g.e,__g.f,__g.g,__g.h,__g.i,__g.j,__g.k,__g.l,__g.m,__g.n,__g.o,__g.p,__g.q,__g.r,__g.s,__g.t,__g.u,__g.v,__g.w,__g.x,__g.y,__g.z,__g.A,__g.B,__g.C,__g.D,__g.E,__g.F,__g.G,__g.H,__g.I,__g.J,__g.K,__g.L,__g.M,__g.N,__g.O,__g.P,__g.Q,__g.R,__g.S,__g.T,__g.U,__g.V,__g.W,__g.X,__g.Y,__g.Z,__g.aa);if(__vd_version_info__.delayedGwx||false)$gwx_XC_2();	if (__vd_version_info__.delayedGwx) __wxAppCode__['pages/ccadmin/ccadmin.wxml'] = [$gwx_XC_2, './pages/ccadmin/ccadmin.wxml'];else __wxAppCode__['pages/ccadmin/ccadmin.wxml'] = $gwx_XC_2( './pages/ccadmin/ccadmin.wxml' );
	;__wxRoute = "pages/ccadmin/ccadmin";__wxRouteBegin = true;__wxAppCurrentFile__="pages/ccadmin/ccadmin.js";define("pages/ccadmin/ccadmin.js",function(require,module,exports,window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){
"use strict";var a=wx.cloud.database(),n=getApp();wx.cloud.database().collection("tiku_users");Page({onLoad:function(){var e=this,t=a.command.aggregate;a.collection("tiku_users").aggregate().group({_id:"$id",num:t.sum(1)}).end().then((function(a){console.log("",a),e.setData({list1:a.list})}));var s=n.globalData.userInfo;console.log("",s),this.setData({userInfo:s})},ccadmin:function(){wx.navigateTo({url:"/pages/administrators/administrators"})},ccadminuser:function(){wx.navigateTo({url:"/pages/ccadminuser/ccadminuser"})},adminbanners:function(){wx.navigateTo({url:"/pages/adminbanners/adminbanners"})}});
},{isPage:true,isComponent:true,currentFile:'pages/ccadmin/ccadmin.js'});require("pages/ccadmin/ccadmin.js");$gwx_XC_3=function(_,_v,_n,_p,_s,_wp,_wl,$gwn,$gwl,$gwh,wh,$gstack,$gwrt,gra,grb,TestTest,wfor,_ca,_da,_r,_rz,_o,_oz,_1,_1z,_2,_2z,_m,_mz,nv_getDate,nv_getRegExp,nv_console,nv_parseInt,nv_parseFloat,nv_isNaN,nv_isFinite,nv_decodeURI,nv_decodeURIComponent,nv_encodeURI,nv_encodeURIComponent,$gdc,nv_JSON,_af,_gv,_ai,_grp,_gd,_gapi,$ixc,_ic,_w,_ev,_tsd){return function(path,global){
if(typeof global==='undefined'){if (typeof __GWX_GLOBAL__==='undefined')global={};else global=__GWX_GLOBAL__;}if(typeof __WXML_GLOBAL__ === 'undefined') {__WXML_GLOBAL__={};
}__WXML_GLOBAL__.modules = __WXML_GLOBAL__.modules || {};
var e_={}
if(typeof(global.entrys)==='undefined')global.entrys={};e_=global.entrys;
var d_={}
if(typeof(global.defines)==='undefined')global.defines={};d_=global.defines;
var f_={}
if(typeof(global.modules)==='undefined')global.modules={};f_=global.modules || {};
var p_={}
__WXML_GLOBAL__.ops_cached = __WXML_GLOBAL__.ops_cached || {}
__WXML_GLOBAL__.ops_set = __WXML_GLOBAL__.ops_set || {};
__WXML_GLOBAL__.ops_init = __WXML_GLOBAL__.ops_init || {};
var z=__WXML_GLOBAL__.ops_set.$gwx_XC_3 || [];
function gz$gwx_XC_3_1(){
if( __WXML_GLOBAL__.ops_cached.$gwx_XC_3_1)return __WXML_GLOBAL__.ops_cached.$gwx_XC_3_1
__WXML_GLOBAL__.ops_cached.$gwx_XC_3_1=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
Z([[7],[3,'tiList']])
Z([3,''])
Z([3,'good-box'])
Z([[6],[[7],[3,'item']],[3,'_id']])
Z([3,'formReset'])
Z([3,'formSubmit1'])
Z([3,'tijiao'])
Z([[2,'!'],[[7],[3,'switchAllChecked']]])
Z([[7],[3,'switchAllChecked']])
Z(z[4])
Z([3,'formSubmit'])
Z(z[6])
Z([[2,'!'],[[6],[[7],[3,'item']],[3,'limit']]])
Z([[6],[[7],[3,'item']],[3,'limit']])
})(__WXML_GLOBAL__.ops_cached.$gwx_XC_3_1);return __WXML_GLOBAL__.ops_cached.$gwx_XC_3_1
}
__WXML_GLOBAL__.ops_set.$gwx_XC_3=z;
__WXML_GLOBAL__.ops_init.$gwx_XC_3=true;
var x=['./pages/ccadminuser/ccadminuser.wxml'];d_[x[0]]={}
var m0=function(e,s,r,gg){
var z=gz$gwx_XC_3_1()
var oX=_v()
_(r,oX)
var lY=function(t1,aZ,e2,gg){
var o4=_mz(z,'view',['bindtap',1,'class',1,'data-id',2],[],t1,aZ,gg)
var x5=_mz(z,'form',['catchreset',4,'catchsubmit',1],[],t1,aZ,gg)
var o6=_n('view')
_rz(z,o6,'class',6,t1,aZ,gg)
var f7=_v()
_(o6,f7)
if(_oz(z,7,t1,aZ,gg)){f7.wxVkey=1
}
var c8=_v()
_(o6,c8)
if(_oz(z,8,t1,aZ,gg)){c8.wxVkey=1
}
f7.wxXCkey=1
c8.wxXCkey=1
_(x5,o6)
_(o4,x5)
var h9=_mz(z,'form',['catchreset',9,'catchsubmit',1],[],t1,aZ,gg)
var o0=_n('view')
_rz(z,o0,'class',11,t1,aZ,gg)
var cAB=_v()
_(o0,cAB)
if(_oz(z,12,t1,aZ,gg)){cAB.wxVkey=1
}
var oBB=_v()
_(o0,oBB)
if(_oz(z,13,t1,aZ,gg)){oBB.wxVkey=1
}
cAB.wxXCkey=1
oBB.wxXCkey=1
_(h9,o0)
_(o4,h9)
_(e2,o4)
return e2
}
oX.wxXCkey=2
_2z(z,0,lY,e,s,gg,oX,'item','index','')
return r
}
e_[x[0]]={f:m0,j:[],i:[],ti:[],ic:[]}
if(path&&e_[path]){
return function(env,dd,global){$gwxc=0;var root={"tag":"wx-page"};root.children=[]
;g="$gwx_XC_3";var main=e_[path].f
if (typeof global==="undefined")global={};global.f=$gdc(f_[path],"",1);
try{
main(env,{},root,global);
_tsd(root)
}catch(err){
console.log(err)
}
;g="";
return root;
}
}
}
}(__g.a,__g.b,__g.c,__g.d,__g.e,__g.f,__g.g,__g.h,__g.i,__g.j,__g.k,__g.l,__g.m,__g.n,__g.o,__g.p,__g.q,__g.r,__g.s,__g.t,__g.u,__g.v,__g.w,__g.x,__g.y,__g.z,__g.A,__g.B,__g.C,__g.D,__g.E,__g.F,__g.G,__g.H,__g.I,__g.J,__g.K,__g.L,__g.M,__g.N,__g.O,__g.P,__g.Q,__g.R,__g.S,__g.T,__g.U,__g.V,__g.W,__g.X,__g.Y,__g.Z,__g.aa);if(__vd_version_info__.delayedGwx||false)$gwx_XC_3();	if (__vd_version_info__.delayedGwx) __wxAppCode__['pages/ccadminuser/ccadminuser.wxml'] = [$gwx_XC_3, './pages/ccadminuser/ccadminuser.wxml'];else __wxAppCode__['pages/ccadminuser/ccadminuser.wxml'] = $gwx_XC_3( './pages/ccadminuser/ccadminuser.wxml' );
	;__wxRoute = "pages/ccadminuser/ccadminuser";__wxRouteBegin = true;__wxAppCurrentFile__="pages/ccadminuser/ccadminuser.js";define("pages/ccadminuser/ccadminuser.js",function(require,module,exports,window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){
"use strict";var e=wx.cloud.database(),t=(getApp(),wx.cloud.database().collection("tiku_users"));Page({data:{switchAllChecked:!1},getValue:function(e){console.log(e.detail.value);var t=e.detail.value;this.setData({inputValue:t})},remove:function(t){var o=t.currentTarget.dataset.openid;e.command;wx.cloud.database().collection("tiku_users").doc(o).remove().then((function(e){console.log(e),wx.showToast({title:"取消成功"})}))},search:function(){var t=this;this.setData({switchAllChecked:!1});var o=e.command;wx.cloud.database().collection("tiku_users").where(o.or([{name:wx.cloud.database().RegExp({regexp:this.data.inputValue,options:"i"})},{phone:wx.cloud.database().RegExp({regexp:this.data.inputValue,options:"i"})},{nickName:wx.cloud.database().RegExp({regexp:this.data.inputValue,options:"i"})},{limit:wx.cloud.database().RegExp({regexp:this.data.inputValue,options:"i"})},{baokaotime:wx.cloud.database().RegExp({regexp:this.data.inputValue,options:"i"})}])).get().then((function(e){console.log(e),t.setData({tiList:e.data})}))},formSubmit:function(e){this.setData({switchAllChecked:!1});var o=e.detail.value;console.log(o),o.limit?o.limit&&t.doc(o.openid).update({data:{useless:"无用项目"}}).then((function(o){wx.showModal({title:"提示",content:"确定恢复使用？",success:function(o){if(o.confirm){var a=e.detail.value;t.doc(a.openid).update({data:{limit:""}}),console.log(""),wx.showToast({title:"已恢复"})}else o.cancel&&console.log("")}})})):t.doc(o.openid).update({data:{useless:"无用项目"}}).then((function(o){wx.showModal({title:"提示",content:"确定禁止该用户使用？",success:function(o){if(o.confirm){var a=e.detail.value;t.doc(a.openid).update({data:{limit:"限制"}}),console.log(""),wx.showToast({title:"已禁止"})}else o.cancel&&console.log("")}})}))},change:function(e){this.setData({switchAllChecked:!0})},formSubmit1:function(e){var o=e.detail.value;console.log(o),o.name?o.phone?o&&t.doc(o.openid).update({data:{useless:"无用项目"}}).then((function(e){wx.showModal({title:"提示",content:"确定提交？",success:function(e){e.confirm?(t.doc(o.openid).update({data:{name:o.name,phone:o.phone,openid:o.openid,zhuanye:o.zhuanye}}),console.log(""),wx.showToast({title:"已提交"})):e.cancel&&console.log("")}})})):wx.showToast({icon:"none",title:"请填写电话"}):wx.showToast({icon:"none",title:"请填写姓名"})}});
},{isPage:true,isComponent:true,currentFile:'pages/ccadminuser/ccadminuser.js'});require("pages/ccadminuser/ccadminuser.js");$gwx_XC_4=function(_,_v,_n,_p,_s,_wp,_wl,$gwn,$gwl,$gwh,wh,$gstack,$gwrt,gra,grb,TestTest,wfor,_ca,_da,_r,_rz,_o,_oz,_1,_1z,_2,_2z,_m,_mz,nv_getDate,nv_getRegExp,nv_console,nv_parseInt,nv_parseFloat,nv_isNaN,nv_isFinite,nv_decodeURI,nv_decodeURIComponent,nv_encodeURI,nv_encodeURIComponent,$gdc,nv_JSON,_af,_gv,_ai,_grp,_gd,_gapi,$ixc,_ic,_w,_ev,_tsd){return function(path,global){
if(typeof global==='undefined'){if (typeof __GWX_GLOBAL__==='undefined')global={};else global=__GWX_GLOBAL__;}if(typeof __WXML_GLOBAL__ === 'undefined') {__WXML_GLOBAL__={};
}__WXML_GLOBAL__.modules = __WXML_GLOBAL__.modules || {};
var e_={}
if(typeof(global.entrys)==='undefined')global.entrys={};e_=global.entrys;
var d_={}
if(typeof(global.defines)==='undefined')global.defines={};d_=global.defines;
var f_={}
if(typeof(global.modules)==='undefined')global.modules={};f_=global.modules || {};
var p_={}
__WXML_GLOBAL__.ops_cached = __WXML_GLOBAL__.ops_cached || {}
__WXML_GLOBAL__.ops_set = __WXML_GLOBAL__.ops_set || {};
__WXML_GLOBAL__.ops_init = __WXML_GLOBAL__.ops_init || {};
var z=__WXML_GLOBAL__.ops_set.$gwx_XC_4 || [];
function gz$gwx_XC_4_1(){
if( __WXML_GLOBAL__.ops_cached.$gwx_XC_4_1)return __WXML_GLOBAL__.ops_cached.$gwx_XC_4_1
__WXML_GLOBAL__.ops_cached.$gwx_XC_4_1=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
Z([3,'onChooseAvatar'])
Z([3,'buttonavatar'])
Z([3,'chooseAvatar'])
Z([[2,'&&'],[[7],[3,'userInfo']],[[6],[[7],[3,'userInfo']],[3,'avatarUrl']]])
})(__WXML_GLOBAL__.ops_cached.$gwx_XC_4_1);return __WXML_GLOBAL__.ops_cached.$gwx_XC_4_1
}
__WXML_GLOBAL__.ops_set.$gwx_XC_4=z;
__WXML_GLOBAL__.ops_init.$gwx_XC_4=true;
var x=['./pages/change/change.wxml'];d_[x[0]]={}
var m0=function(e,s,r,gg){
var z=gz$gwx_XC_4_1()
var aDB=_mz(z,'button',['bind:chooseavatar',0,'class',1,'openType',1],[],e,s,gg)
var tEB=_v()
_(aDB,tEB)
if(_oz(z,3,e,s,gg)){tEB.wxVkey=1
}
tEB.wxXCkey=1
_(r,aDB)
return r
}
e_[x[0]]={f:m0,j:[],i:[],ti:[],ic:[]}
if(path&&e_[path]){
return function(env,dd,global){$gwxc=0;var root={"tag":"wx-page"};root.children=[]
;g="$gwx_XC_4";var main=e_[path].f
if (typeof global==="undefined")global={};global.f=$gdc(f_[path],"",1);
try{
main(env,{},root,global);
_tsd(root)
}catch(err){
console.log(err)
}
;g="";
return root;
}
}
}
}(__g.a,__g.b,__g.c,__g.d,__g.e,__g.f,__g.g,__g.h,__g.i,__g.j,__g.k,__g.l,__g.m,__g.n,__g.o,__g.p,__g.q,__g.r,__g.s,__g.t,__g.u,__g.v,__g.w,__g.x,__g.y,__g.z,__g.A,__g.B,__g.C,__g.D,__g.E,__g.F,__g.G,__g.H,__g.I,__g.J,__g.K,__g.L,__g.M,__g.N,__g.O,__g.P,__g.Q,__g.R,__g.S,__g.T,__g.U,__g.V,__g.W,__g.X,__g.Y,__g.Z,__g.aa);if(__vd_version_info__.delayedGwx||false)$gwx_XC_4();	if (__vd_version_info__.delayedGwx) __wxAppCode__['pages/change/change.wxml'] = [$gwx_XC_4, './pages/change/change.wxml'];else __wxAppCode__['pages/change/change.wxml'] = $gwx_XC_4( './pages/change/change.wxml' );
	;__wxRoute = "pages/change/change";__wxRouteBegin = true;__wxAppCurrentFile__="pages/change/change.js";define("pages/change/change.js",function(require,module,exports,window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){
"use strict";var a,t=require("../../@babel/runtime/helpers/defineProperty"),o=getApp(),e=wx.cloud.database().collection("tiku_users"),n="";Page((t(a={data:{baokaotime:"2023届",avatarUrl:"https://mmbiz.qpic.cn/mmbiz/icTdbqWNOwNRna42FI242Lcia07jQodd2FJGIYQfG0LAJGFxM4FbnQP6yfMxBgJ0F3YRqJCJ1aPAK2dQagdusBZg/0",userInfo:null},onChooseAvatar:function(a){var t=a.detail.avatarUrl;this.setData({avatarUrl:t,"userInfo.avatarUrl":t}),console.log(this.data.avatarUrl,n),this.upload(t)},upload:function(a){e.doc(n).update({data:{"userInfo.avatarUrl":a}}).then((function(a){wx.showToast({title:"添加成功",icon:"success",duration:2e3})}))},onShow:function(a){var t=o.globalData.userInfo;console.log("",t),t&&t.nickName?this.setData({userInfo:t}):this.setData({userInfo:wx.getStorageSync("user")})}},"data",{user:null}),t(a,"onLoad",(function(a){console.log("",o.globalData.openid),n=o.globalData.openid,this.getUserInfo()})),t(a,"getUserInfo",(function(){var a=this;e.doc(n).get().then((function(t){console.log("",t),a.setData({user:t.data})})).catch((function(t){wx.showToast({icon:"error",title:"还未注册用户"}),console.log(""),a.setData({user:null})}))})),t(a,"formSubmit",(function(a){var t=this,l=a.detail.value,r=a.detail.value.phone,i=o.globalData.userInfo;console.log(l),"https://thirdwx.qlogo.cn/mmopen/vi_32/POgEwh4mIHO4nibH0KlMECNjjGxQUq24ZEaGT4poC6icRiccVGKSyXwibcPq4BWmiaIGuG1icwxaQX6grC9VemZoJ8rg/132"==i.avatarUrl?wx.showToast({icon:"none",title:"请选择头像"}):l.name?r?l.zhuanye?(this.data.user&&this.data.user.name?e.doc(n).update({data:{name:l.name,phone:l.phone,zhuanye:l.zhuanye,nickName:l.name,avatarUrl:o.globalData.userInfo.avatarUrl,limit:l.limit,baokaotime:"2024届"}}).then((function(a){o.globalData.userInfo.nickName=l.name,t.savaStudent(l),wx.showToast({title:"更新成功"})})):e.add({data:{_id:n,name:l.name,limit:l.limit,phone:l.phone,zhuanye:l.zhuanye,nickName:l.name,baokaotime:"2024届",avatarUrl:o.globalData.userInfo.avatarUrl,score:0,isAuth:0}}).then((function(a){o.globalData.userInfo.nickName=l.name,t.savaStudent(l),wx.showToast({title:"提交成功"})})),o.globalData.userInfo.nickName=l.name,wx.switchTab({url:"/pages/home/home"})):wx.showToast({icon:"none",title:"专业"}):wx.showToast({icon:"none",title:"请填写电话"}):wx.showToast({icon:"none",title:"请填写姓名"})})),t(a,"savaStudent",(function(a){o.globalData.userInfo.limit=a.limit,o.globalData.userInfo.name=a.name,o.globalData.userInfo.score=a.score,o.globalData.userInfo.zhuanye=a.zhuanye,o.globalData.userInfo.xuehao=a.xuehao,o.globalData.userInfo.kahao=a.kahao,o.globalData.userInfo.yuanxi=a.yuanxi,o._saveUserInfo(o.globalData.userInfo)})),t(a,"data",{multiArray:[["国画学院","造型学院","设计类","实验学院","理论类"],["花鸟","山水","人物","书法","修复坚定"]],multiIndex:[0,0],arrColumn0:["花鸟","山水","人物","书法","修复坚定"],arrColumn1:["油画","版画","壁画","雕塑","造型基础"],arrColumn2:["视觉传达","工艺美术","设计基础","室内设计","环境设计","公共艺术","服装设计","染织设计","产品设计"],arrColumn3:["综合艺术","跨媒体","动画","摄影","数字媒体"],arrColumn4:["艺术学理论","艺术设计学"]}),t(a,"PickerChange",(function(a){var t=a.detail.value;this.setData({multiIndex:t}),console.log(this.data.multiArray[0][t[0]],this.data.multiArray[1][t[1]],this.data.multiArray[2][t[2]],this.data.multiArray[3][t[3]],this.data.multiArray[4][t[4]])})),t(a,"PickerColumnChange",(function(a){var t=a.detail,o=this.data.multiArray;0==t.column&&0==t.value&&(o[1]=this.data.arrColumn0),0==t.column&&1==t.value&&(o[1]=this.data.arrColumn1),0==t.column&&2==t.value&&(o[1]=this.data.arrColumn2),0==t.column&&3==t.value&&(o[1]=this.data.arrColumn3),0==t.column&&4==t.value&&(o[1]=this.data.arrColumn4),this.setData({multiArray:o})})),a));
},{isPage:true,isComponent:true,currentFile:'pages/change/change.js'});require("pages/change/change.js");$gwx_XC_5=function(_,_v,_n,_p,_s,_wp,_wl,$gwn,$gwl,$gwh,wh,$gstack,$gwrt,gra,grb,TestTest,wfor,_ca,_da,_r,_rz,_o,_oz,_1,_1z,_2,_2z,_m,_mz,nv_getDate,nv_getRegExp,nv_console,nv_parseInt,nv_parseFloat,nv_isNaN,nv_isFinite,nv_decodeURI,nv_decodeURIComponent,nv_encodeURI,nv_encodeURIComponent,$gdc,nv_JSON,_af,_gv,_ai,_grp,_gd,_gapi,$ixc,_ic,_w,_ev,_tsd){return function(path,global){
if(typeof global==='undefined'){if (typeof __GWX_GLOBAL__==='undefined')global={};else global=__GWX_GLOBAL__;}if(typeof __WXML_GLOBAL__ === 'undefined') {__WXML_GLOBAL__={};
}__WXML_GLOBAL__.modules = __WXML_GLOBAL__.modules || {};
var e_={}
if(typeof(global.entrys)==='undefined')global.entrys={};e_=global.entrys;
var d_={}
if(typeof(global.defines)==='undefined')global.defines={};d_=global.defines;
var f_={}
if(typeof(global.modules)==='undefined')global.modules={};f_=global.modules || {};
var p_={}
__WXML_GLOBAL__.ops_cached = __WXML_GLOBAL__.ops_cached || {}
__WXML_GLOBAL__.ops_set = __WXML_GLOBAL__.ops_set || {};
__WXML_GLOBAL__.ops_init = __WXML_GLOBAL__.ops_init || {};
var z=__WXML_GLOBAL__.ops_set.$gwx_XC_5 || [];
function gz$gwx_XC_5_1(){
if( __WXML_GLOBAL__.ops_cached.$gwx_XC_5_1)return __WXML_GLOBAL__.ops_cached.$gwx_XC_5_1
__WXML_GLOBAL__.ops_cached.$gwx_XC_5_1=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
Z([[2,'!'],[[7],[3,'showList']]])
Z([3,'search-wrap'])
Z([[2,'!'],[[7],[3,'inputValue']]])
Z([[7],[3,'inputValue']])
Z([[2,'=='],[[6],[[7],[3,'tiList']],[3,'length']],[1,0]])
Z([[2,'&&'],[[7],[3,'list']],[[2,'>'],[[6],[[7],[3,'list']],[3,'length']],[1,0]]])
Z([[2,'&&'],[[2,'=='],[[6],[[7],[3,'list']],[3,'length']],[1,0]],[[2,'=='],[[6],[[7],[3,'testList']],[3,'length']],[1,0]]])
})(__WXML_GLOBAL__.ops_cached.$gwx_XC_5_1);return __WXML_GLOBAL__.ops_cached.$gwx_XC_5_1
}
__WXML_GLOBAL__.ops_set.$gwx_XC_5=z;
__WXML_GLOBAL__.ops_init.$gwx_XC_5=true;
var x=['./pages/errorList/errorList.wxml'];d_[x[0]]={}
var m0=function(e,s,r,gg){
var z=gz$gwx_XC_5_1()
var bGB=_n('scroll-view')
_rz(z,bGB,'hidden',0,e,s,gg)
var fKB=_n('view')
_rz(z,fKB,'class',1,e,s,gg)
var cLB=_v()
_(fKB,cLB)
if(_oz(z,2,e,s,gg)){cLB.wxVkey=1
}
var hMB=_v()
_(fKB,hMB)
if(_oz(z,3,e,s,gg)){hMB.wxVkey=1
}
cLB.wxXCkey=1
hMB.wxXCkey=1
_(bGB,fKB)
var oHB=_v()
_(bGB,oHB)
if(_oz(z,4,e,s,gg)){oHB.wxVkey=1
}
var xIB=_v()
_(bGB,xIB)
if(_oz(z,5,e,s,gg)){xIB.wxVkey=1
}
var oJB=_v()
_(bGB,oJB)
if(_oz(z,6,e,s,gg)){oJB.wxVkey=1
}
oHB.wxXCkey=1
xIB.wxXCkey=1
oJB.wxXCkey=1
_(r,bGB)
return r
}
e_[x[0]]={f:m0,j:[],i:[],ti:[],ic:[]}
if(path&&e_[path]){
return function(env,dd,global){$gwxc=0;var root={"tag":"wx-page"};root.children=[]
;g="$gwx_XC_5";var main=e_[path].f
if (typeof global==="undefined")global={};global.f=$gdc(f_[path],"",1);
try{
main(env,{},root,global);
_tsd(root)
}catch(err){
console.log(err)
}
;g="";
return root;
}
}
}
}(__g.a,__g.b,__g.c,__g.d,__g.e,__g.f,__g.g,__g.h,__g.i,__g.j,__g.k,__g.l,__g.m,__g.n,__g.o,__g.p,__g.q,__g.r,__g.s,__g.t,__g.u,__g.v,__g.w,__g.x,__g.y,__g.z,__g.A,__g.B,__g.C,__g.D,__g.E,__g.F,__g.G,__g.H,__g.I,__g.J,__g.K,__g.L,__g.M,__g.N,__g.O,__g.P,__g.Q,__g.R,__g.S,__g.T,__g.U,__g.V,__g.W,__g.X,__g.Y,__g.Z,__g.aa);if(__vd_version_info__.delayedGwx||false)$gwx_XC_5();	if (__vd_version_info__.delayedGwx) __wxAppCode__['pages/errorList/errorList.wxml'] = [$gwx_XC_5, './pages/errorList/errorList.wxml'];else __wxAppCode__['pages/errorList/errorList.wxml'] = $gwx_XC_5( './pages/errorList/errorList.wxml' );
	;__wxRoute = "pages/errorList/errorList";__wxRouteBegin = true;__wxAppCurrentFile__="pages/errorList/errorList.js";define("pages/errorList/errorList.js",function(require,module,exports,window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){
"use strict";var t=wx.cloud.database(),e=getApp();Page({data:{showList:!1,loadingHidden:!1},onShow:function(){var e=this,a=t.command.aggregate;t.collection("tiku_errors").aggregate().group({_id:"$type",num:a.sum(1)}).end().then((function(t){console.log("",t),e.setData({list:t.list})})),t.collection("tiku_test_errors").aggregate().group({_id:"$testId",num:a.sum(1)}).sort({_id:-1}).end().then((function(t){console.log("",t),e.setData({testList:t.list})})),this.data.flag||(this.setData({scwidth:this.data.scwidth+3,flag:!0}),this.data.scwidth<100?setTimeout((function(){e.actionDack()}),100):this.setData({scwidth:0}))},goQuestionList:function(t){wx.navigateTo({url:"/pages/errorTypeList/errorTypeList?type="+t.currentTarget.dataset.type})},goTestQuestionList:function(t){wx.navigateTo({url:"/pages/testErrorTypeList/testErrorTypeList?type="+t.currentTarget.dataset.type})},goHome:function(){wx.switchTab({url:"/pages/home/home"})},onShareTimeline:function(){return{title:"练习错题集",imageUrl:"https://636c-cloud1-8gs7t7f49b4c97d8-1309642353.tcb.qcloud.la/cloudbase-cms/upload/2022-04-24/euhb16l1ane9x0h0m9q7r12rchk95or3_.png"}},toSearch:function(){wx.navigateTo({url:"/pages/errorList/errorList"})},onLoad:function(t){var e=this;setTimeout((function(){e.setData({showList:!0,loadingHidden:!0})}),1500)},getValue:function(t){console.log(t.detail.value);var e=t.detail.value;this.setData({inputValue:e})},getValue1:function(t){console.log(t.detail.value);t.detail.value;this.setData({inputValue1:kjdhksdjfgh})},search:function(){var t=this;wx.cloud.database().collection("tiku_questions").where({title:wx.cloud.database().RegExp({regexp:this.data.inputValue,options:"i"})}).get().then((function(e){console.log(e),t.setData({tiList:e.data})}))},shanchu:function(){var t=this;wx.cloud.database().collection("tiku_questions").where({title:wx.cloud.database().RegExp({regexp:"清空搜索栏 无",options:"i"})}).get().then((function(e){console.log(e),t.setData({tiList:e.data,shuru:null,inputValue:null})}))},toDetail:function(t){if(e.globalData.userInfo.name){console.log(t.currentTarget.dataset.id);var a=t.currentTarget.dataset.id;wx.navigateTo({url:"/pages/sousuo/sousuo?id="+a})}else wx.switchTab({url:"/pages/me/me",success:function(t){wx.showToast({icon:"none",title:"请先登录认证"})}})}});
},{isPage:true,isComponent:true,currentFile:'pages/errorList/errorList.js'});require("pages/errorList/errorList.js");$gwx_XC_6=function(_,_v,_n,_p,_s,_wp,_wl,$gwn,$gwl,$gwh,wh,$gstack,$gwrt,gra,grb,TestTest,wfor,_ca,_da,_r,_rz,_o,_oz,_1,_1z,_2,_2z,_m,_mz,nv_getDate,nv_getRegExp,nv_console,nv_parseInt,nv_parseFloat,nv_isNaN,nv_isFinite,nv_decodeURI,nv_decodeURIComponent,nv_encodeURI,nv_encodeURIComponent,$gdc,nv_JSON,_af,_gv,_ai,_grp,_gd,_gapi,$ixc,_ic,_w,_ev,_tsd){return function(path,global){
if(typeof global==='undefined'){if (typeof __GWX_GLOBAL__==='undefined')global={};else global=__GWX_GLOBAL__;}if(typeof __WXML_GLOBAL__ === 'undefined') {__WXML_GLOBAL__={};
}__WXML_GLOBAL__.modules = __WXML_GLOBAL__.modules || {};
var e_={}
if(typeof(global.entrys)==='undefined')global.entrys={};e_=global.entrys;
var d_={}
if(typeof(global.defines)==='undefined')global.defines={};d_=global.defines;
var f_={}
if(typeof(global.modules)==='undefined')global.modules={};f_=global.modules || {};
var p_={}
__WXML_GLOBAL__.ops_cached = __WXML_GLOBAL__.ops_cached || {}
__WXML_GLOBAL__.ops_set = __WXML_GLOBAL__.ops_set || {};
__WXML_GLOBAL__.ops_init = __WXML_GLOBAL__.ops_init || {};
var z=__WXML_GLOBAL__.ops_set.$gwx_XC_6 || [];
function gz$gwx_XC_6_1(){
if( __WXML_GLOBAL__.ops_cached.$gwx_XC_6_1)return __WXML_GLOBAL__.ops_cached.$gwx_XC_6_1
__WXML_GLOBAL__.ops_cached.$gwx_XC_6_1=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
Z([[2,'>'],[[7],[3,'total']],[1,0]])
Z([[6],[[7],[3,'subject']],[3,'image']])
Z([[6],[[7],[3,'subject']],[3,'optionC']])
Z([[6],[[7],[3,'subject']],[3,'optionD']])
Z([[6],[[7],[3,'subject']],[3,'explain']])
Z([[7],[3,'showModalStatus']])
Z(z[5])
})(__WXML_GLOBAL__.ops_cached.$gwx_XC_6_1);return __WXML_GLOBAL__.ops_cached.$gwx_XC_6_1
}
__WXML_GLOBAL__.ops_set.$gwx_XC_6=z;
__WXML_GLOBAL__.ops_init.$gwx_XC_6=true;
var x=['./pages/errorQuestions/errorQuestions.wxml'];d_[x[0]]={}
var m0=function(e,s,r,gg){
var z=gz$gwx_XC_6_1()
var cOB=_v()
_(r,cOB)
if(_oz(z,0,e,s,gg)){cOB.wxVkey=1
var aRB=_n('view')
var tSB=_v()
_(aRB,tSB)
if(_oz(z,1,e,s,gg)){tSB.wxVkey=1
}
var bUB=_n('view')
var oVB=_v()
_(bUB,oVB)
if(_oz(z,2,e,s,gg)){oVB.wxVkey=1
}
var xWB=_v()
_(bUB,xWB)
if(_oz(z,3,e,s,gg)){xWB.wxVkey=1
}
oVB.wxXCkey=1
xWB.wxXCkey=1
_(aRB,bUB)
var eTB=_v()
_(aRB,eTB)
if(_oz(z,4,e,s,gg)){eTB.wxVkey=1
}
tSB.wxXCkey=1
eTB.wxXCkey=1
_(cOB,aRB)
}
else{cOB.wxVkey=2
}
var oPB=_v()
_(r,oPB)
if(_oz(z,5,e,s,gg)){oPB.wxVkey=1
}
var lQB=_v()
_(r,lQB)
if(_oz(z,6,e,s,gg)){lQB.wxVkey=1
}
cOB.wxXCkey=1
oPB.wxXCkey=1
lQB.wxXCkey=1
return r
}
e_[x[0]]={f:m0,j:[],i:[],ti:[],ic:[]}
if(path&&e_[path]){
return function(env,dd,global){$gwxc=0;var root={"tag":"wx-page"};root.children=[]
;g="$gwx_XC_6";var main=e_[path].f
if (typeof global==="undefined")global={};global.f=$gdc(f_[path],"",1);
try{
main(env,{},root,global);
_tsd(root)
}catch(err){
console.log(err)
}
;g="";
return root;
}
}
}
}(__g.a,__g.b,__g.c,__g.d,__g.e,__g.f,__g.g,__g.h,__g.i,__g.j,__g.k,__g.l,__g.m,__g.n,__g.o,__g.p,__g.q,__g.r,__g.s,__g.t,__g.u,__g.v,__g.w,__g.x,__g.y,__g.z,__g.A,__g.B,__g.C,__g.D,__g.E,__g.F,__g.G,__g.H,__g.I,__g.J,__g.K,__g.L,__g.M,__g.N,__g.O,__g.P,__g.Q,__g.R,__g.S,__g.T,__g.U,__g.V,__g.W,__g.X,__g.Y,__g.Z,__g.aa);if(__vd_version_info__.delayedGwx||false)$gwx_XC_6();	if (__vd_version_info__.delayedGwx) __wxAppCode__['pages/errorQuestions/errorQuestions.wxml'] = [$gwx_XC_6, './pages/errorQuestions/errorQuestions.wxml'];else __wxAppCode__['pages/errorQuestions/errorQuestions.wxml'] = $gwx_XC_6( './pages/errorQuestions/errorQuestions.wxml' );
	;__wxRoute = "pages/errorQuestions/errorQuestions";__wxRouteBegin = true;__wxAppCurrentFile__="pages/errorQuestions/errorQuestions.js";define("pages/errorQuestions/errorQuestions.js",function(require,module,exports,window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){
"use strict";getApp();var t=wx.cloud.database(),a=null,e=[];Page({data:{total:0,current:0},onLoad:function(t){a=t,this.getData()},getData:function(){var o=this;t.collection("tiku_errors").where({type:a.type1,type2:a.type2}).get().then((function(t){e=t.data,console.log("",e);var a=e[0];console.log("",a),o.setData({current:0,subject:a,total:e.length})}))},pre:function(){var t=this.data.current;t<=0?wx.showToast({icon:"error",title:"已是第一道"}):(t-=1,this.setData({current:t,subject:e[t]}))},next:function(){var t=this.data.current;t>=e.length-1?wx.showToast({icon:"error",title:"已是最后一道"}):(t+=1,this.setData({current:t,subject:e[t]}))},removeError:function(a){var e=this,o=a.currentTarget.dataset.subject._id;t.collection("tiku_errors").doc(o).remove().then((function(t){console.log("",t),t.stats&&t.stats.removed>0?(wx.showToast({title:"删除成功"}),e.getData()):wx.showToast({icon:"error",title:"网络不给力"})}))},getValue:function(t){console.log(t.detail.value);var a=t.detail.value;this.setData({inputValue:a})},baocuoanniu:function(){this.setData({isShowConfirm:!0})},selectClick11:function(t){console.log(t.detail.value),this.setData({jiucuo:t.detail.value})},formSubmit1:function(t){var a=this,e=t.detail.value;console.log(this.data.subject._id),wx.cloud.database().collection("tiku_errors").doc(this.data.subject._id).update({data:{tikuerrors:e.tikuerrors}}).then((function(t){wx.showToast({title:"反馈成功"}),a.setData({showModalStatus:!1})}))},clickme:function(){this.showModal()},showModal:function(){var t=wx.createAnimation({duration:200,timingFunction:"linear",delay:0});this.animation=t,t.translateY(300).step(),this.setData({animationData:t.export(),showModalStatus:!0}),setTimeout(function(){t.translateY(0).step(),this.setData({animationData:t.export()})}.bind(this),200)},hideModal:function(){var t=wx.createAnimation({duration:200,timingFunction:"linear",delay:0});this.animation=t,t.translateY(300).step(),this.setData({animationData:t.export()}),setTimeout(function(){t.translateY(0).step(),this.setData({animationData:t.export(),showModalStatus:!1})}.bind(this),200)},previewImg:function(t){var a=t.currentTarget.dataset.tp;wx.previewImage({urls:a})},onShareTimeline:function(){return{title:"天美史论1000题",imageUrl:"https://636c-cloud1-8gs7t7f49b4c97d8-1309642353.tcb.qcloud.la/cloudbase-cms/upload/2022-04-24/euhb16l1ane9x0h0m9q7r12rchk95or3_.png"}}});
},{isPage:true,isComponent:true,currentFile:'pages/errorQuestions/errorQuestions.js'});require("pages/errorQuestions/errorQuestions.js");$gwx_XC_7=function(_,_v,_n,_p,_s,_wp,_wl,$gwn,$gwl,$gwh,wh,$gstack,$gwrt,gra,grb,TestTest,wfor,_ca,_da,_r,_rz,_o,_oz,_1,_1z,_2,_2z,_m,_mz,nv_getDate,nv_getRegExp,nv_console,nv_parseInt,nv_parseFloat,nv_isNaN,nv_isFinite,nv_decodeURI,nv_decodeURIComponent,nv_encodeURI,nv_encodeURIComponent,$gdc,nv_JSON,_af,_gv,_ai,_grp,_gd,_gapi,$ixc,_ic,_w,_ev,_tsd){return function(path,global){
if(typeof global==='undefined'){if (typeof __GWX_GLOBAL__==='undefined')global={};else global=__GWX_GLOBAL__;}if(typeof __WXML_GLOBAL__ === 'undefined') {__WXML_GLOBAL__={};
}__WXML_GLOBAL__.modules = __WXML_GLOBAL__.modules || {};
var e_={}
if(typeof(global.entrys)==='undefined')global.entrys={};e_=global.entrys;
var d_={}
if(typeof(global.defines)==='undefined')global.defines={};d_=global.defines;
var f_={}
if(typeof(global.modules)==='undefined')global.modules={};f_=global.modules || {};
var p_={}
__WXML_GLOBAL__.ops_cached = __WXML_GLOBAL__.ops_cached || {}
__WXML_GLOBAL__.ops_set = __WXML_GLOBAL__.ops_set || {};
__WXML_GLOBAL__.ops_init = __WXML_GLOBAL__.ops_init || {};
var z=__WXML_GLOBAL__.ops_set.$gwx_XC_7 || [];
function gz$gwx_XC_7_1(){
if( __WXML_GLOBAL__.ops_cached.$gwx_XC_7_1)return __WXML_GLOBAL__.ops_cached.$gwx_XC_7_1
__WXML_GLOBAL__.ops_cached.$gwx_XC_7_1=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
Z([[2,'!='],[[6],[[7],[3,'liet']],[3,'num']],[1,0]])
})(__WXML_GLOBAL__.ops_cached.$gwx_XC_7_1);return __WXML_GLOBAL__.ops_cached.$gwx_XC_7_1
}
__WXML_GLOBAL__.ops_set.$gwx_XC_7=z;
__WXML_GLOBAL__.ops_init.$gwx_XC_7=true;
var x=['./pages/errorTypeList/errorTypeList.wxml'];d_[x[0]]={}
var m0=function(e,s,r,gg){
var z=gz$gwx_XC_7_1()
var fYB=_v()
_(r,fYB)
if(_oz(z,0,e,s,gg)){fYB.wxVkey=1
}
fYB.wxXCkey=1
return r
}
e_[x[0]]={f:m0,j:[],i:[],ti:[],ic:[]}
if(path&&e_[path]){
return function(env,dd,global){$gwxc=0;var root={"tag":"wx-page"};root.children=[]
;g="$gwx_XC_7";var main=e_[path].f
if (typeof global==="undefined")global={};global.f=$gdc(f_[path],"",1);
try{
main(env,{},root,global);
_tsd(root)
}catch(err){
console.log(err)
}
;g="";
return root;
}
}
}
}(__g.a,__g.b,__g.c,__g.d,__g.e,__g.f,__g.g,__g.h,__g.i,__g.j,__g.k,__g.l,__g.m,__g.n,__g.o,__g.p,__g.q,__g.r,__g.s,__g.t,__g.u,__g.v,__g.w,__g.x,__g.y,__g.z,__g.A,__g.B,__g.C,__g.D,__g.E,__g.F,__g.G,__g.H,__g.I,__g.J,__g.K,__g.L,__g.M,__g.N,__g.O,__g.P,__g.Q,__g.R,__g.S,__g.T,__g.U,__g.V,__g.W,__g.X,__g.Y,__g.Z,__g.aa);if(__vd_version_info__.delayedGwx||false)$gwx_XC_7();	if (__vd_version_info__.delayedGwx) __wxAppCode__['pages/errorTypeList/errorTypeList.wxml'] = [$gwx_XC_7, './pages/errorTypeList/errorTypeList.wxml'];else __wxAppCode__['pages/errorTypeList/errorTypeList.wxml'] = $gwx_XC_7( './pages/errorTypeList/errorTypeList.wxml' );
	;__wxRoute = "pages/errorTypeList/errorTypeList";__wxRouteBegin = true;__wxAppCurrentFile__="pages/errorTypeList/errorTypeList.js";define("pages/errorTypeList/errorTypeList.js",function(require,module,exports,window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){
"use strict";var t=wx.cloud.database();Page({onLoad:function(t){console.log("一级题目类型",t.type),wx.setNavigationBarTitle({title:""}),this.setData({type:t.type})},onShow:function(){var e=this,a=t.command.aggregate;t.collection("tiku_errors").aggregate().match({type:this.data.type}).group({_id:"$type2",num:a.sum(1)}).end().then((function(t){console.log("",t),e.setData({list:t.list})}))},goDetail:function(t){var e=this.data.type,a=t.currentTarget.dataset.type2;wx.navigateTo({url:"/pages/errorQuestions/errorQuestions?type1="+e+"&type2="+a})},onShareTimeline:function(){return{title:"天美史论1000题",imageUrl:"https://636c-cloud1-8gs7t7f49b4c97d8-1309642353.tcb.qcloud.la/cloudbase-cms/upload/2022-04-24/euhb16l1ane9x0h0m9q7r12rchk95or3_.png"}}});
},{isPage:true,isComponent:true,currentFile:'pages/errorTypeList/errorTypeList.js'});require("pages/errorTypeList/errorTypeList.js");$gwx_XC_8=function(_,_v,_n,_p,_s,_wp,_wl,$gwn,$gwl,$gwh,wh,$gstack,$gwrt,gra,grb,TestTest,wfor,_ca,_da,_r,_rz,_o,_oz,_1,_1z,_2,_2z,_m,_mz,nv_getDate,nv_getRegExp,nv_console,nv_parseInt,nv_parseFloat,nv_isNaN,nv_isFinite,nv_decodeURI,nv_decodeURIComponent,nv_encodeURI,nv_encodeURIComponent,$gdc,nv_JSON,_af,_gv,_ai,_grp,_gd,_gapi,$ixc,_ic,_w,_ev,_tsd){return function(path,global){
if(typeof global==='undefined'){if (typeof __GWX_GLOBAL__==='undefined')global={};else global=__GWX_GLOBAL__;}if(typeof __WXML_GLOBAL__ === 'undefined') {__WXML_GLOBAL__={};
}__WXML_GLOBAL__.modules = __WXML_GLOBAL__.modules || {};
var e_={}
if(typeof(global.entrys)==='undefined')global.entrys={};e_=global.entrys;
var d_={}
if(typeof(global.defines)==='undefined')global.defines={};d_=global.defines;
var f_={}
if(typeof(global.modules)==='undefined')global.modules={};f_=global.modules || {};
var p_={}
__WXML_GLOBAL__.ops_cached = __WXML_GLOBAL__.ops_cached || {}
__WXML_GLOBAL__.ops_set = __WXML_GLOBAL__.ops_set || {};
__WXML_GLOBAL__.ops_init = __WXML_GLOBAL__.ops_init || {};
var z=__WXML_GLOBAL__.ops_set.$gwx_XC_8 || [];
function gz$gwx_XC_8_1(){
if( __WXML_GLOBAL__.ops_cached.$gwx_XC_8_1)return __WXML_GLOBAL__.ops_cached.$gwx_XC_8_1
__WXML_GLOBAL__.ops_cached.$gwx_XC_8_1=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
})(__WXML_GLOBAL__.ops_cached.$gwx_XC_8_1);return __WXML_GLOBAL__.ops_cached.$gwx_XC_8_1
}
__WXML_GLOBAL__.ops_set.$gwx_XC_8=z;
__WXML_GLOBAL__.ops_init.$gwx_XC_8=true;
var x=['./pages/exam/exam.wxml'];d_[x[0]]={}
var m0=function(e,s,r,gg){
var z=gz$gwx_XC_8_1()
return r
}
e_[x[0]]={f:m0,j:[],i:[],ti:[],ic:[]}
if(path&&e_[path]){
return function(env,dd,global){$gwxc=0;var root={"tag":"wx-page"};root.children=[]
;g="$gwx_XC_8";var main=e_[path].f
if (typeof global==="undefined")global={};global.f=$gdc(f_[path],"",1);
try{
main(env,{},root,global);
_tsd(root)
}catch(err){
console.log(err)
}
;g="";
return root;
}
}
}
}(__g.a,__g.b,__g.c,__g.d,__g.e,__g.f,__g.g,__g.h,__g.i,__g.j,__g.k,__g.l,__g.m,__g.n,__g.o,__g.p,__g.q,__g.r,__g.s,__g.t,__g.u,__g.v,__g.w,__g.x,__g.y,__g.z,__g.A,__g.B,__g.C,__g.D,__g.E,__g.F,__g.G,__g.H,__g.I,__g.J,__g.K,__g.L,__g.M,__g.N,__g.O,__g.P,__g.Q,__g.R,__g.S,__g.T,__g.U,__g.V,__g.W,__g.X,__g.Y,__g.Z,__g.aa);if(__vd_version_info__.delayedGwx||false)$gwx_XC_8();	if (__vd_version_info__.delayedGwx) __wxAppCode__['pages/exam/exam.wxml'] = [$gwx_XC_8, './pages/exam/exam.wxml'];else __wxAppCode__['pages/exam/exam.wxml'] = $gwx_XC_8( './pages/exam/exam.wxml' );
	;__wxRoute = "pages/exam/exam";__wxRouteBegin = true;__wxAppCurrentFile__="pages/exam/exam.js";define("pages/exam/exam.js",function(require,module,exports,window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){
"use strict";var t=wx.cloud.database(),e=getApp();Page({data:{topImgs:[{url:"/images/dili.png",type:"地理"},{url:"/images/lishi.png",type:"历史"}]},onLoad:function(){},onShow:function(){var e=this,a=t.command.aggregate;t.collection("tiku_exams").aggregate().group({_id:"$type",num:a.sum(1)}).end().then((function(t){console.log("",t),e.setData({list:t.list})}))},goQuestionList:function(t){e.globalData.userInfo.name?wx.navigateTo({url:"/pages/examList/examList?type="+t.currentTarget.dataset.type}):wx.switchTab({url:"/pages/me/me",success:function(t){wx.showToast({icon:"none",title:"请先登录认证"})}})},goRandom:function(){e.globalData.userInfo.name?wx.navigateTo({url:"/pages/questions/questions"}):wx.switchTab({url:"/pages/me/me",success:function(t){wx.showToast({icon:"none",title:"请先登录认证"})}})}});
},{isPage:true,isComponent:true,currentFile:'pages/exam/exam.js'});require("pages/exam/exam.js");$gwx_XC_9=function(_,_v,_n,_p,_s,_wp,_wl,$gwn,$gwl,$gwh,wh,$gstack,$gwrt,gra,grb,TestTest,wfor,_ca,_da,_r,_rz,_o,_oz,_1,_1z,_2,_2z,_m,_mz,nv_getDate,nv_getRegExp,nv_console,nv_parseInt,nv_parseFloat,nv_isNaN,nv_isFinite,nv_decodeURI,nv_decodeURIComponent,nv_encodeURI,nv_encodeURIComponent,$gdc,nv_JSON,_af,_gv,_ai,_grp,_gd,_gapi,$ixc,_ic,_w,_ev,_tsd){return function(path,global){
if(typeof global==='undefined'){if (typeof __GWX_GLOBAL__==='undefined')global={};else global=__GWX_GLOBAL__;}if(typeof __WXML_GLOBAL__ === 'undefined') {__WXML_GLOBAL__={};
}__WXML_GLOBAL__.modules = __WXML_GLOBAL__.modules || {};
var e_={}
if(typeof(global.entrys)==='undefined')global.entrys={};e_=global.entrys;
var d_={}
if(typeof(global.defines)==='undefined')global.defines={};d_=global.defines;
var f_={}
if(typeof(global.modules)==='undefined')global.modules={};f_=global.modules || {};
var p_={}
__WXML_GLOBAL__.ops_cached = __WXML_GLOBAL__.ops_cached || {}
__WXML_GLOBAL__.ops_set = __WXML_GLOBAL__.ops_set || {};
__WXML_GLOBAL__.ops_init = __WXML_GLOBAL__.ops_init || {};
var z=__WXML_GLOBAL__.ops_set.$gwx_XC_9 || [];
function gz$gwx_XC_9_1(){
if( __WXML_GLOBAL__.ops_cached.$gwx_XC_9_1)return __WXML_GLOBAL__.ops_cached.$gwx_XC_9_1
__WXML_GLOBAL__.ops_cached.$gwx_XC_9_1=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
})(__WXML_GLOBAL__.ops_cached.$gwx_XC_9_1);return __WXML_GLOBAL__.ops_cached.$gwx_XC_9_1
}
__WXML_GLOBAL__.ops_set.$gwx_XC_9=z;
__WXML_GLOBAL__.ops_init.$gwx_XC_9=true;
var x=['./pages/examList/examList.wxml'];d_[x[0]]={}
var m0=function(e,s,r,gg){
var z=gz$gwx_XC_9_1()
return r
}
e_[x[0]]={f:m0,j:[],i:[],ti:[],ic:[]}
if(path&&e_[path]){
return function(env,dd,global){$gwxc=0;var root={"tag":"wx-page"};root.children=[]
;g="$gwx_XC_9";var main=e_[path].f
if (typeof global==="undefined")global={};global.f=$gdc(f_[path],"",1);
try{
main(env,{},root,global);
_tsd(root)
}catch(err){
console.log(err)
}
;g="";
return root;
}
}
}
}(__g.a,__g.b,__g.c,__g.d,__g.e,__g.f,__g.g,__g.h,__g.i,__g.j,__g.k,__g.l,__g.m,__g.n,__g.o,__g.p,__g.q,__g.r,__g.s,__g.t,__g.u,__g.v,__g.w,__g.x,__g.y,__g.z,__g.A,__g.B,__g.C,__g.D,__g.E,__g.F,__g.G,__g.H,__g.I,__g.J,__g.K,__g.L,__g.M,__g.N,__g.O,__g.P,__g.Q,__g.R,__g.S,__g.T,__g.U,__g.V,__g.W,__g.X,__g.Y,__g.Z,__g.aa);if(__vd_version_info__.delayedGwx||false)$gwx_XC_9();	if (__vd_version_info__.delayedGwx) __wxAppCode__['pages/examList/examList.wxml'] = [$gwx_XC_9, './pages/examList/examList.wxml'];else __wxAppCode__['pages/examList/examList.wxml'] = $gwx_XC_9( './pages/examList/examList.wxml' );
	;__wxRoute = "pages/examList/examList";__wxRouteBegin = true;__wxAppCurrentFile__="pages/examList/examList.js";define("pages/examList/examList.js",function(require,module,exports,window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){
"use strict";var t=wx.cloud.database();Page({onLoad:function(e){var a=this;console.log("",e.type),wx.setNavigationBarTitle({title:e.type+"模拟考试"}),this.setData({type:e.type});var o=t.command.aggregate;t.collection("tiku_exams").aggregate().match({type:e.type}).group({_id:"$type2",num:o.sum(1)}).end().then((function(t){console.log("",t),a.setData({list:t.list})}))},goDetail:function(t){var e=this.data.type,a=t.currentTarget.dataset.type2;wx.navigateTo({url:"/pages/test/test?type1="+e+"&type2="+a})}});
},{isPage:true,isComponent:true,currentFile:'pages/examList/examList.js'});require("pages/examList/examList.js");$gwx_XC_10=function(_,_v,_n,_p,_s,_wp,_wl,$gwn,$gwl,$gwh,wh,$gstack,$gwrt,gra,grb,TestTest,wfor,_ca,_da,_r,_rz,_o,_oz,_1,_1z,_2,_2z,_m,_mz,nv_getDate,nv_getRegExp,nv_console,nv_parseInt,nv_parseFloat,nv_isNaN,nv_isFinite,nv_decodeURI,nv_decodeURIComponent,nv_encodeURI,nv_encodeURIComponent,$gdc,nv_JSON,_af,_gv,_ai,_grp,_gd,_gapi,$ixc,_ic,_w,_ev,_tsd){return function(path,global){
if(typeof global==='undefined'){if (typeof __GWX_GLOBAL__==='undefined')global={};else global=__GWX_GLOBAL__;}if(typeof __WXML_GLOBAL__ === 'undefined') {__WXML_GLOBAL__={};
}__WXML_GLOBAL__.modules = __WXML_GLOBAL__.modules || {};
var e_={}
if(typeof(global.entrys)==='undefined')global.entrys={};e_=global.entrys;
var d_={}
if(typeof(global.defines)==='undefined')global.defines={};d_=global.defines;
var f_={}
if(typeof(global.modules)==='undefined')global.modules={};f_=global.modules || {};
var p_={}
__WXML_GLOBAL__.ops_cached = __WXML_GLOBAL__.ops_cached || {}
__WXML_GLOBAL__.ops_set = __WXML_GLOBAL__.ops_set || {};
__WXML_GLOBAL__.ops_init = __WXML_GLOBAL__.ops_init || {};
var z=__WXML_GLOBAL__.ops_set.$gwx_XC_10 || [];
function gz$gwx_XC_10_1(){
if( __WXML_GLOBAL__.ops_cached.$gwx_XC_10_1)return __WXML_GLOBAL__.ops_cached.$gwx_XC_10_1
__WXML_GLOBAL__.ops_cached.$gwx_XC_10_1=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
})(__WXML_GLOBAL__.ops_cached.$gwx_XC_10_1);return __WXML_GLOBAL__.ops_cached.$gwx_XC_10_1
}
__WXML_GLOBAL__.ops_set.$gwx_XC_10=z;
__WXML_GLOBAL__.ops_init.$gwx_XC_10=true;
var x=['./pages/home/bannerDetail/bannerDetail.wxml'];d_[x[0]]={}
var m0=function(e,s,r,gg){
var z=gz$gwx_XC_10_1()
return r
}
e_[x[0]]={f:m0,j:[],i:[],ti:[],ic:[]}
if(path&&e_[path]){
return function(env,dd,global){$gwxc=0;var root={"tag":"wx-page"};root.children=[]
;g="$gwx_XC_10";var main=e_[path].f
if (typeof global==="undefined")global={};global.f=$gdc(f_[path],"",1);
try{
main(env,{},root,global);
_tsd(root)
}catch(err){
console.log(err)
}
;g="";
return root;
}
}
}
}(__g.a,__g.b,__g.c,__g.d,__g.e,__g.f,__g.g,__g.h,__g.i,__g.j,__g.k,__g.l,__g.m,__g.n,__g.o,__g.p,__g.q,__g.r,__g.s,__g.t,__g.u,__g.v,__g.w,__g.x,__g.y,__g.z,__g.A,__g.B,__g.C,__g.D,__g.E,__g.F,__g.G,__g.H,__g.I,__g.J,__g.K,__g.L,__g.M,__g.N,__g.O,__g.P,__g.Q,__g.R,__g.S,__g.T,__g.U,__g.V,__g.W,__g.X,__g.Y,__g.Z,__g.aa);if(__vd_version_info__.delayedGwx||false)$gwx_XC_10();	if (__vd_version_info__.delayedGwx) __wxAppCode__['pages/home/bannerDetail/bannerDetail.wxml'] = [$gwx_XC_10, './pages/home/bannerDetail/bannerDetail.wxml'];else __wxAppCode__['pages/home/bannerDetail/bannerDetail.wxml'] = $gwx_XC_10( './pages/home/bannerDetail/bannerDetail.wxml' );
	;__wxRoute = "pages/home/bannerDetail/bannerDetail";__wxRouteBegin = true;__wxAppCurrentFile__="pages/home/bannerDetail/bannerDetail.js";define("pages/home/bannerDetail/bannerDetail.js",function(require,module,exports,window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){
"use strict";Page({data:{},onLoad:function(t){console.log(t.id),this.getBannerDetail(t.id)},getBannerDetail:function(t){var e=this;wx.cloud.database().collection("tiku_banners").doc(t).get({success:function(t){console.log(t),e.setData({banner:t.data})}})},onShareTimeline:function(){return{title:"天美史论1000题",imageUrl:"https://636c-cloud1-8gs7t7f49b4c97d8-1309642353.tcb.qcloud.la/cloudbase-cms/upload/2022-04-24/euhb16l1ane9x0h0m9q7r12rchk95or3_.png"}}});
},{isPage:true,isComponent:true,currentFile:'pages/home/bannerDetail/bannerDetail.js'});require("pages/home/bannerDetail/bannerDetail.js");$gwx_XC_11=function(_,_v,_n,_p,_s,_wp,_wl,$gwn,$gwl,$gwh,wh,$gstack,$gwrt,gra,grb,TestTest,wfor,_ca,_da,_r,_rz,_o,_oz,_1,_1z,_2,_2z,_m,_mz,nv_getDate,nv_getRegExp,nv_console,nv_parseInt,nv_parseFloat,nv_isNaN,nv_isFinite,nv_decodeURI,nv_decodeURIComponent,nv_encodeURI,nv_encodeURIComponent,$gdc,nv_JSON,_af,_gv,_ai,_grp,_gd,_gapi,$ixc,_ic,_w,_ev,_tsd){return function(path,global){
if(typeof global==='undefined'){if (typeof __GWX_GLOBAL__==='undefined')global={};else global=__GWX_GLOBAL__;}if(typeof __WXML_GLOBAL__ === 'undefined') {__WXML_GLOBAL__={};
}__WXML_GLOBAL__.modules = __WXML_GLOBAL__.modules || {};
var e_={}
if(typeof(global.entrys)==='undefined')global.entrys={};e_=global.entrys;
var d_={}
if(typeof(global.defines)==='undefined')global.defines={};d_=global.defines;
var f_={}
if(typeof(global.modules)==='undefined')global.modules={};f_=global.modules || {};
var p_={}
__WXML_GLOBAL__.ops_cached = __WXML_GLOBAL__.ops_cached || {}
__WXML_GLOBAL__.ops_set = __WXML_GLOBAL__.ops_set || {};
__WXML_GLOBAL__.ops_init = __WXML_GLOBAL__.ops_init || {};
var z=__WXML_GLOBAL__.ops_set.$gwx_XC_11 || [];
function gz$gwx_XC_11_1(){
if( __WXML_GLOBAL__.ops_cached.$gwx_XC_11_1)return __WXML_GLOBAL__.ops_cached.$gwx_XC_11_1
__WXML_GLOBAL__.ops_cached.$gwx_XC_11_1=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
})(__WXML_GLOBAL__.ops_cached.$gwx_XC_11_1);return __WXML_GLOBAL__.ops_cached.$gwx_XC_11_1
}
__WXML_GLOBAL__.ops_set.$gwx_XC_11=z;
__WXML_GLOBAL__.ops_init.$gwx_XC_11=true;
var x=['./pages/home/home.wxml'];d_[x[0]]={}
var m0=function(e,s,r,gg){
var z=gz$gwx_XC_11_1()
return r
}
e_[x[0]]={f:m0,j:[],i:[],ti:[],ic:[]}
if(path&&e_[path]){
return function(env,dd,global){$gwxc=0;var root={"tag":"wx-page"};root.children=[]
;g="$gwx_XC_11";var main=e_[path].f
if (typeof global==="undefined")global={};global.f=$gdc(f_[path],"",1);
try{
main(env,{},root,global);
_tsd(root)
}catch(err){
console.log(err)
}
;g="";
return root;
}
}
}
}(__g.a,__g.b,__g.c,__g.d,__g.e,__g.f,__g.g,__g.h,__g.i,__g.j,__g.k,__g.l,__g.m,__g.n,__g.o,__g.p,__g.q,__g.r,__g.s,__g.t,__g.u,__g.v,__g.w,__g.x,__g.y,__g.z,__g.A,__g.B,__g.C,__g.D,__g.E,__g.F,__g.G,__g.H,__g.I,__g.J,__g.K,__g.L,__g.M,__g.N,__g.O,__g.P,__g.Q,__g.R,__g.S,__g.T,__g.U,__g.V,__g.W,__g.X,__g.Y,__g.Z,__g.aa);if(__vd_version_info__.delayedGwx||false)$gwx_XC_11();	if (__vd_version_info__.delayedGwx) __wxAppCode__['pages/home/home.wxml'] = [$gwx_XC_11, './pages/home/home.wxml'];else __wxAppCode__['pages/home/home.wxml'] = $gwx_XC_11( './pages/home/home.wxml' );
	;__wxRoute = "pages/home/home";__wxRouteBegin = true;__wxAppCurrentFile__="pages/home/home.js";define("pages/home/home.js",function(require,module,exports,window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){
"use strict";var t,e=require("../../@babel/runtime/helpers/defineProperty"),a=getApp();wx.cloud.database().collection("author");Page((e(t={data:{showList:!1,showAdmin1:!1,scwidth:0,flag:!1,loadingHidden:!1},getAdmin:function(){var t=this;wx.cloud.callFunction({name:"getOpenid",complete:function(e){var a=e.result.openid;wx.cloud.database().collection("author").get().then((function(e){var n=e.data[0]._openid;a===n?t.setData({showAdmin:!0}):t.setData({showAdmin:!1})}))}})},qiandao:function(){wx.navigateTo({url:"/pages/qiandao/qiandao"})},getCurrentDate:function(){var t=new Date,e=t.getDay(),a=new Array("星期日","星期一","星期二","星期三","星期四","星期五","星期六")[e];this.setData({week:a,month:t.getMonth()+1,day:t.getDate()})},getBannerList:function(){var t=this;wx.cloud.database().collection("tiku_banners").orderBy("sort","desc").get({success:function(e){console.log(e),t.setData({bannerList:e.data})}})},getCurrentDate303:function(){var t=new Date,e=t.getDay(),a=new Array("星期日","星期一","星期二","星期三","星期四","星期五","星期六")[e];this.setData({week:a,month:t.getMonth()+1,day:t.getDate()})},getBannerLis0t44:function(){var t=this;wx.cloud.database().collection("tiku_banners").orderBy("sort","desc").get({success:function(e){console.log(e),t.setData({bannerList:e.data})}})},toBannerD00etail66:function(t){wx.navigateTo({url:"/pages/home/bannerDetail/bannerDetail?id="+t.currentTarget.dataset.id})},goQuesti9onList88:function(t){a.globalData.userInfo.name?wx.navigateTo({url:"/pages/questionList/questionList?type="+t.currentTarget.dataset.type}):wx.switchTab({url:"/pages/me/me",success:function(t){wx.showToast({icon:"none",title:"请先登录认证"})}})},onSub9scribe088:function(t){var e=t.currentTarget.dataset.item;wx.requestSubscribeMessage({tmplIds:["qL1BuG1fSl95882p8PY1lsSuQK6SIwigj5IgbVXFQk8"],success:function(t){"requestSubscribeMessage:ok"===t.errMsg&&wx.cloud.callFunction({name:"subscribe",data:{data:e,templateId:"qL1BuG1fSl95882p8PY1lsSuQK6SIwigj5IgbVXFQk8"}}).then((function(){wx.showToast({title:"订阅成功",icon:"success",duration:2e3})})).catch((function(){wx.showToast({title:"订阅失败",icon:"success",duration:2e3})}))}})},goRa99ndom64:function(){a.globalData.userInfo.name?wx.navigateTo({url:"/pages/questions/questions"}):wx.switchTab({url:"/pages/me/me",success:function(t){wx.showToast({icon:"none",title:"请先登录认证"})}})},toSear88ch467:function(){wx.navigateTo({url:"/pages/home/search/search"})},onTabItemTap:function(t){var e=Date.parse(new Date),a=this.data,n=a.clickTabTime,o=a.goodsListScrollTop;n&&e-n<2e3&&0!=o?wx.pageScrollTo?wx.pageScrollTo({scrollTop:0}):wx.showModal({title:"提示",content:"当前微信版本过低，无法使用该功能，请升级到最新微信版本后重试。"}):this.setData({clickTabTime:e})},toBannerDetail:function(t){wx.navigateTo({url:"/pages/home/bannerDetail/bannerDetail?id="+t.currentTarget.dataset.id})}},"data",{day:"",hour:"",minute:"",second:""}),e(t,"onLoad",(function(t){var e=this,a=+new Date("2024/12/23 00:00:00");setInterval(this.countDown,1e3,a);this.getCurrentDate(),this.getBannerList(),setTimeout((function(){e.setData({showList:!0,loadingHidden:!0})}),1500)})),e(t,"countDown",(function(t){var e=t-+new Date;this.setData({day:Math.floor(e/864e5)+"",hour:Math.floor(e/36e5%24)+"时",minute:Math.floor(e/6e4%60)+"分",second:Math.floor(e/1e3%60)+"秒"}),this.data.day<=0&&this.data.hour<=0&&this.data.minute<=0&&this.data.second<=0&&(this.setData({day:0,hour:0,minute:0,second:0}),clearInterval(timer))})),e(t,"goQuestionList",(function(t){a.globalData.userInfo.name?a.globalData.userInfo.limit?wx.switchTab({url:"/pages/me/me",success:function(t){wx.showToast({icon:"none",title:""})}}):wx.navigateTo({url:"/pages/questionList/questionList?type="+t.currentTarget.dataset.type}):wx.switchTab({url:"/pages/me/me",success:function(t){wx.showToast({icon:"none",title:"请先登录认证"})}})})),e(t,"toAAAA",(function(t){a.globalData.userInfo.name?wx.navigateTo({url:"/pages/aaaa/aaaa"}):wx.switchTab({url:"/pages/me/me",success:function(t){wx.showToast({icon:"none",title:"请先登录认证"})}})})),e(t,"goRandom",(function(){a.globalData.userInfo.name?wx.navigateTo({url:"/pages/questions/questions"}):wx.switchTab({url:"/pages/me/me",success:function(t){wx.showToast({icon:"none",title:"请先登录认证"})}})})),e(t,"onShareAppMessage",(function(){return{title:" ",imageUrl:"https://636c-cloud1-8gs7t7f49b4c97d8-1309642353.tcb.qcloud.la/cloudbase-cms/upload/2022-04-24/m936jjv23g0npx2c20s0ldtsgtupfnin_.png"}})),e(t,"onShareTimeline",(function(){return{title:"每天一遍，轻松过线",imageUrl:"https://636c-cloud1-8gs7t7f49b4c97d8-1309642353.tcb.qcloud.la/cloudbase-cms/upload/2022-04-24/euhb16l1ane9x0h0m9q7r12rchk95or3_.png"}})),t));
},{isPage:true,isComponent:true,currentFile:'pages/home/home.js'});require("pages/home/home.js");$gwx_XC_12=function(_,_v,_n,_p,_s,_wp,_wl,$gwn,$gwl,$gwh,wh,$gstack,$gwrt,gra,grb,TestTest,wfor,_ca,_da,_r,_rz,_o,_oz,_1,_1z,_2,_2z,_m,_mz,nv_getDate,nv_getRegExp,nv_console,nv_parseInt,nv_parseFloat,nv_isNaN,nv_isFinite,nv_decodeURI,nv_decodeURIComponent,nv_encodeURI,nv_encodeURIComponent,$gdc,nv_JSON,_af,_gv,_ai,_grp,_gd,_gapi,$ixc,_ic,_w,_ev,_tsd){return function(path,global){
if(typeof global==='undefined'){if (typeof __GWX_GLOBAL__==='undefined')global={};else global=__GWX_GLOBAL__;}if(typeof __WXML_GLOBAL__ === 'undefined') {__WXML_GLOBAL__={};
}__WXML_GLOBAL__.modules = __WXML_GLOBAL__.modules || {};
var e_={}
if(typeof(global.entrys)==='undefined')global.entrys={};e_=global.entrys;
var d_={}
if(typeof(global.defines)==='undefined')global.defines={};d_=global.defines;
var f_={}
if(typeof(global.modules)==='undefined')global.modules={};f_=global.modules || {};
var p_={}
__WXML_GLOBAL__.ops_cached = __WXML_GLOBAL__.ops_cached || {}
__WXML_GLOBAL__.ops_set = __WXML_GLOBAL__.ops_set || {};
__WXML_GLOBAL__.ops_init = __WXML_GLOBAL__.ops_init || {};
var z=__WXML_GLOBAL__.ops_set.$gwx_XC_12 || [];
function gz$gwx_XC_12_1(){
if( __WXML_GLOBAL__.ops_cached.$gwx_XC_12_1)return __WXML_GLOBAL__.ops_cached.$gwx_XC_12_1
__WXML_GLOBAL__.ops_cached.$gwx_XC_12_1=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
Z([[2,'&&'],[[7],[3,'userInfo']],[[6],[[7],[3,'userInfo']],[3,'avatarUrl']]])
Z([[2,'!'],[[2,'&&'],[[7],[3,'userInfo']],[[6],[[7],[3,'userInfo']],[3,'avatarUrl']]]])
Z([3,'beijin1'])
Z([[7],[3,'showAdmin']])
Z([[2,'&&'],[[7],[3,'userInfo']],[[6],[[7],[3,'userInfo']],[3,'avatarUrl']]])
Z(z[0])
})(__WXML_GLOBAL__.ops_cached.$gwx_XC_12_1);return __WXML_GLOBAL__.ops_cached.$gwx_XC_12_1
}
__WXML_GLOBAL__.ops_set.$gwx_XC_12=z;
__WXML_GLOBAL__.ops_init.$gwx_XC_12=true;
var x=['./pages/me/me.wxml'];d_[x[0]]={}
var m0=function(e,s,r,gg){
var z=gz$gwx_XC_12_1()
var l5B=_v()
_(r,l5B)
if(_oz(z,0,e,s,gg)){l5B.wxVkey=1
}
var a6B=_v()
_(r,a6B)
if(_oz(z,1,e,s,gg)){a6B.wxVkey=1
}
var e8B=_n('view')
_rz(z,e8B,'class',2,e,s,gg)
var b9B=_v()
_(e8B,b9B)
if(_oz(z,3,e,s,gg)){b9B.wxVkey=1
}
var o0B=_v()
_(e8B,o0B)
if(_oz(z,4,e,s,gg)){o0B.wxVkey=1
}
b9B.wxXCkey=1
o0B.wxXCkey=1
_(r,e8B)
var t7B=_v()
_(r,t7B)
if(_oz(z,5,e,s,gg)){t7B.wxVkey=1
}
l5B.wxXCkey=1
a6B.wxXCkey=1
t7B.wxXCkey=1
return r
}
e_[x[0]]={f:m0,j:[],i:[],ti:[],ic:[]}
if(path&&e_[path]){
return function(env,dd,global){$gwxc=0;var root={"tag":"wx-page"};root.children=[]
;g="$gwx_XC_12";var main=e_[path].f
if (typeof global==="undefined")global={};global.f=$gdc(f_[path],"",1);
try{
main(env,{},root,global);
_tsd(root)
}catch(err){
console.log(err)
}
;g="";
return root;
}
}
}
}(__g.a,__g.b,__g.c,__g.d,__g.e,__g.f,__g.g,__g.h,__g.i,__g.j,__g.k,__g.l,__g.m,__g.n,__g.o,__g.p,__g.q,__g.r,__g.s,__g.t,__g.u,__g.v,__g.w,__g.x,__g.y,__g.z,__g.A,__g.B,__g.C,__g.D,__g.E,__g.F,__g.G,__g.H,__g.I,__g.J,__g.K,__g.L,__g.M,__g.N,__g.O,__g.P,__g.Q,__g.R,__g.S,__g.T,__g.U,__g.V,__g.W,__g.X,__g.Y,__g.Z,__g.aa);if(__vd_version_info__.delayedGwx||false)$gwx_XC_12();	if (__vd_version_info__.delayedGwx) __wxAppCode__['pages/me/me.wxml'] = [$gwx_XC_12, './pages/me/me.wxml'];else __wxAppCode__['pages/me/me.wxml'] = $gwx_XC_12( './pages/me/me.wxml' );
	;__wxRoute = "pages/me/me";__wxRouteBegin = true;__wxAppCurrentFile__="pages/me/me.js";define("pages/me/me.js",function(require,module,exports,window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){
"use strict";var a=getApp(),o=wx.cloud.database().collection("tiku_users");wx.cloud.database().collection("author");Page({data:{userInfo:null,showAdmin:!1},getAdmin:function(){var a=this;wx.cloud.callFunction({name:"getOpenid",complete:function(o){var e=o.result.openid;wx.cloud.database().collection("author").get().then((function(o){var n=o.data[0]._openid;e===n?a.setData({showAdmin:!0}):a.setData({showAdmin:!1})}))}})},onLoad:function(a){this.getAdmin()},onShow:function(o){var e=a.globalData.userInfo;console.log("",e),e&&e.nickName?this.setData({userInfo:e}):this.setData({userInfo:wx.getStorageSync("user")}),this.getScore(),this.getUserInfo()},getUserInfo:function(){var e=this;console.log(a.globalData.openid),o.doc(a.globalData.openid).get().then((function(a){console.log("",a),e.setData({user:a.data})}))},getScore:function(){var o=this;wx.cloud.database().collection("tiku_users").doc(a.globalData.openid).get().then((function(a){if(a&&a.data&&a.data.score>0){var e=a.data.score;console.log("",e),o.setData({score:e})}})).catch((function(a){console.log("")}))},getUserProfile:function(){var o=this;wx.getUserProfile({desc:"用于完善学员资料",success:function(e){console.log("",e);var n=e.userInfo;a.globalData.userInfo.nickName=n.nickName,a.globalData.userInfo.avatarUrl=n.avatarUrl,a._saveUserInfo(a.globalData.userInfo),o.setData({userInfo:a.globalData.userInfo}),wx.navigateTo({url:"/pages/change/change"})},fail:function(a){console.log("",a)}})},guanliyuan:function(){wx.navigateTo({url:"/pages/ccadmin/ccadmin"})},tuichu:function(){wx.setStorageSync("user",{}),a.globalData.userInfo={},this.setData({userInfo:{}})},goqiandao:function(){wx.navigateTo({url:"/pages/qiandao/qiandao"})},goRanking:function(){wx.navigateTo({url:"/pages/ranking/ranking"})},goMyError:function(){wx.switchTab({url:"/pages/errorList/errorList"})},change:function(){wx.navigateTo({url:"/pages/change/change"})},goMyCollect:function(){wx.navigateTo({url:"/pages/me/meCollect/myCollect"})},onShareTimeline:function(){return{title:"天美史论1000题",imageUrl:"https://636c-cloud1-8gs7t7f49b4c97d8-1309642353.tcb.qcloud.la/cloudbase-cms/upload/2022-04-24/euhb16l1ane9x0h0m9q7r12rchk95or3_.png"}}});
},{isPage:true,isComponent:true,currentFile:'pages/me/me.js'});require("pages/me/me.js");$gwx_XC_13=function(_,_v,_n,_p,_s,_wp,_wl,$gwn,$gwl,$gwh,wh,$gstack,$gwrt,gra,grb,TestTest,wfor,_ca,_da,_r,_rz,_o,_oz,_1,_1z,_2,_2z,_m,_mz,nv_getDate,nv_getRegExp,nv_console,nv_parseInt,nv_parseFloat,nv_isNaN,nv_isFinite,nv_decodeURI,nv_decodeURIComponent,nv_encodeURI,nv_encodeURIComponent,$gdc,nv_JSON,_af,_gv,_ai,_grp,_gd,_gapi,$ixc,_ic,_w,_ev,_tsd){return function(path,global){
if(typeof global==='undefined'){if (typeof __GWX_GLOBAL__==='undefined')global={};else global=__GWX_GLOBAL__;}if(typeof __WXML_GLOBAL__ === 'undefined') {__WXML_GLOBAL__={};
}__WXML_GLOBAL__.modules = __WXML_GLOBAL__.modules || {};
var e_={}
if(typeof(global.entrys)==='undefined')global.entrys={};e_=global.entrys;
var d_={}
if(typeof(global.defines)==='undefined')global.defines={};d_=global.defines;
var f_={}
if(typeof(global.modules)==='undefined')global.modules={};f_=global.modules || {};
var p_={}
__WXML_GLOBAL__.ops_cached = __WXML_GLOBAL__.ops_cached || {}
__WXML_GLOBAL__.ops_set = __WXML_GLOBAL__.ops_set || {};
__WXML_GLOBAL__.ops_init = __WXML_GLOBAL__.ops_init || {};
var z=__WXML_GLOBAL__.ops_set.$gwx_XC_13 || [];
function gz$gwx_XC_13_1(){
if( __WXML_GLOBAL__.ops_cached.$gwx_XC_13_1)return __WXML_GLOBAL__.ops_cached.$gwx_XC_13_1
__WXML_GLOBAL__.ops_cached.$gwx_XC_13_1=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
})(__WXML_GLOBAL__.ops_cached.$gwx_XC_13_1);return __WXML_GLOBAL__.ops_cached.$gwx_XC_13_1
}
__WXML_GLOBAL__.ops_set.$gwx_XC_13=z;
__WXML_GLOBAL__.ops_init.$gwx_XC_13=true;
var x=['./pages/me/meCollect/myCollect.wxml'];d_[x[0]]={}
var m0=function(e,s,r,gg){
var z=gz$gwx_XC_13_1()
return r
}
e_[x[0]]={f:m0,j:[],i:[],ti:[],ic:[]}
if(path&&e_[path]){
return function(env,dd,global){$gwxc=0;var root={"tag":"wx-page"};root.children=[]
;g="$gwx_XC_13";var main=e_[path].f
if (typeof global==="undefined")global={};global.f=$gdc(f_[path],"",1);
try{
main(env,{},root,global);
_tsd(root)
}catch(err){
console.log(err)
}
;g="";
return root;
}
}
}
}(__g.a,__g.b,__g.c,__g.d,__g.e,__g.f,__g.g,__g.h,__g.i,__g.j,__g.k,__g.l,__g.m,__g.n,__g.o,__g.p,__g.q,__g.r,__g.s,__g.t,__g.u,__g.v,__g.w,__g.x,__g.y,__g.z,__g.A,__g.B,__g.C,__g.D,__g.E,__g.F,__g.G,__g.H,__g.I,__g.J,__g.K,__g.L,__g.M,__g.N,__g.O,__g.P,__g.Q,__g.R,__g.S,__g.T,__g.U,__g.V,__g.W,__g.X,__g.Y,__g.Z,__g.aa);if(__vd_version_info__.delayedGwx||false)$gwx_XC_13();	if (__vd_version_info__.delayedGwx) __wxAppCode__['pages/me/meCollect/myCollect.wxml'] = [$gwx_XC_13, './pages/me/meCollect/myCollect.wxml'];else __wxAppCode__['pages/me/meCollect/myCollect.wxml'] = $gwx_XC_13( './pages/me/meCollect/myCollect.wxml' );
	;__wxRoute = "pages/me/meCollect/myCollect";__wxRouteBegin = true;__wxAppCurrentFile__="pages/me/meCollect/myCollect.js";define("pages/me/meCollect/myCollect.js",function(require,module,exports,window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){
"use strict";var t=require("../../../@babel/runtime/helpers/regeneratorRuntime"),e=require("../../../@babel/runtime/helpers/asyncToGenerator");getApp(),wx.cloud.database().command;Page({data:{item:"",startX:0,startY:0},onLoad:function(){var a=this;return e(t().mark((function e(){var c,r,s,o,n;return t().wrap((function(t){for(;;)switch(t.prev=t.next){case 0:return c=wx.cloud.database(),t.next=3,c.collection("tiku_collects").count();case 3:r=(r=t.sent).total,s=[],o=0;case 7:if(!(o<r)){t.next=15;break}return t.next=10,c.collection("tiku_collects").skip(o).get();case 10:n=t.sent,s=s.concat(n.data);case 12:o+=20,t.next=7;break;case 15:console.log("",s),a.setData({records:s});case 17:case"end":return t.stop()}}),e)})))()},touchstart:function(t){this.data.records.forEach((function(t,e){t.isTouchMove&&(t.isTouchMove=!1)})),this.setData({startX:t.changedTouches[0].clientX,startY:t.changedTouches[0].clientY,records:this.data.records})},touchmove:function(t){var e=t.currentTarget.dataset.index,a=this.data.startX,c=this.data.startY,r=t.changedTouches[0].clientX,s=t.changedTouches[0].clientY,o=this.angle({X:a,Y:c},{X:r,Y:s});this.data.records.forEach((function(t,c){t.isTouchMove=!1,Math.abs(o)>30||c==e&&(t.isTouchMove=!(r>a))})),this.setData({records:this.data.records})},angle:function(t,e){var a=e.X-t.X,c=e.Y-t.Y;return 360*Math.atan(c/a)/(2*Math.PI)},del:function(t){var e=t.currentTarget.dataset.id;console.log("hahaha ",e),wx.cloud.database().collection("tiku_collects").doc(e).remove({success:function(t){console.log("",t)},fail:function(t){console.log("",t)}}),this.data.records.splice(t.currentTarget.dataset.index,1),this.setData({records:this.data.records})},toTiDetail:function(t){console.log(t.currentTarget.dataset.id);var e=t.currentTarget.dataset.id;wx.navigateTo({url:"/pages/shouchangxiangqin/shouchangxiangqin?id="+e})}});
},{isPage:true,isComponent:true,currentFile:'pages/me/meCollect/myCollect.js'});require("pages/me/meCollect/myCollect.js");$gwx_XC_14=function(_,_v,_n,_p,_s,_wp,_wl,$gwn,$gwl,$gwh,wh,$gstack,$gwrt,gra,grb,TestTest,wfor,_ca,_da,_r,_rz,_o,_oz,_1,_1z,_2,_2z,_m,_mz,nv_getDate,nv_getRegExp,nv_console,nv_parseInt,nv_parseFloat,nv_isNaN,nv_isFinite,nv_decodeURI,nv_decodeURIComponent,nv_encodeURI,nv_encodeURIComponent,$gdc,nv_JSON,_af,_gv,_ai,_grp,_gd,_gapi,$ixc,_ic,_w,_ev,_tsd){return function(path,global){
if(typeof global==='undefined'){if (typeof __GWX_GLOBAL__==='undefined')global={};else global=__GWX_GLOBAL__;}if(typeof __WXML_GLOBAL__ === 'undefined') {__WXML_GLOBAL__={};
}__WXML_GLOBAL__.modules = __WXML_GLOBAL__.modules || {};
var e_={}
if(typeof(global.entrys)==='undefined')global.entrys={};e_=global.entrys;
var d_={}
if(typeof(global.defines)==='undefined')global.defines={};d_=global.defines;
var f_={}
if(typeof(global.modules)==='undefined')global.modules={};f_=global.modules || {};
var p_={}
__WXML_GLOBAL__.ops_cached = __WXML_GLOBAL__.ops_cached || {}
__WXML_GLOBAL__.ops_set = __WXML_GLOBAL__.ops_set || {};
__WXML_GLOBAL__.ops_init = __WXML_GLOBAL__.ops_init || {};
var z=__WXML_GLOBAL__.ops_set.$gwx_XC_14 || [];
function gz$gwx_XC_14_1(){
if( __WXML_GLOBAL__.ops_cached.$gwx_XC_14_1)return __WXML_GLOBAL__.ops_cached.$gwx_XC_14_1
__WXML_GLOBAL__.ops_cached.$gwx_XC_14_1=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
Z([[2,'&&'],[[7],[3,'userInfo']],[[6],[[7],[3,'userInfo']],[3,'avatarUrl']]])
Z([[2,'=='],[[7],[3,'m']],[[7],[3,'time']]])
Z([[7],[3,'qiandao']])
})(__WXML_GLOBAL__.ops_cached.$gwx_XC_14_1);return __WXML_GLOBAL__.ops_cached.$gwx_XC_14_1
}
__WXML_GLOBAL__.ops_set.$gwx_XC_14=z;
__WXML_GLOBAL__.ops_init.$gwx_XC_14=true;
var x=['./pages/qiandao/qiandao.wxml'];d_[x[0]]={}
var m0=function(e,s,r,gg){
var z=gz$gwx_XC_14_1()
var fCC=_v()
_(r,fCC)
if(_oz(z,0,e,s,gg)){fCC.wxVkey=1
}
var cDC=_v()
_(r,cDC)
if(_oz(z,1,e,s,gg)){cDC.wxVkey=1
}
var hEC=_v()
_(r,hEC)
if(_oz(z,2,e,s,gg)){hEC.wxVkey=1
}
fCC.wxXCkey=1
cDC.wxXCkey=1
hEC.wxXCkey=1
return r
}
e_[x[0]]={f:m0,j:[],i:[],ti:[],ic:[]}
if(path&&e_[path]){
return function(env,dd,global){$gwxc=0;var root={"tag":"wx-page"};root.children=[]
;g="$gwx_XC_14";var main=e_[path].f
if (typeof global==="undefined")global={};global.f=$gdc(f_[path],"",1);
try{
main(env,{},root,global);
_tsd(root)
}catch(err){
console.log(err)
}
;g="";
return root;
}
}
}
}(__g.a,__g.b,__g.c,__g.d,__g.e,__g.f,__g.g,__g.h,__g.i,__g.j,__g.k,__g.l,__g.m,__g.n,__g.o,__g.p,__g.q,__g.r,__g.s,__g.t,__g.u,__g.v,__g.w,__g.x,__g.y,__g.z,__g.A,__g.B,__g.C,__g.D,__g.E,__g.F,__g.G,__g.H,__g.I,__g.J,__g.K,__g.L,__g.M,__g.N,__g.O,__g.P,__g.Q,__g.R,__g.S,__g.T,__g.U,__g.V,__g.W,__g.X,__g.Y,__g.Z,__g.aa);if(__vd_version_info__.delayedGwx||false)$gwx_XC_14();	if (__vd_version_info__.delayedGwx) __wxAppCode__['pages/qiandao/qiandao.wxml'] = [$gwx_XC_14, './pages/qiandao/qiandao.wxml'];else __wxAppCode__['pages/qiandao/qiandao.wxml'] = $gwx_XC_14( './pages/qiandao/qiandao.wxml' );
	;__wxRoute = "pages/qiandao/qiandao";__wxRouteBegin = true;__wxAppCurrentFile__="pages/qiandao/qiandao.js";define("pages/qiandao/qiandao.js",function(require,module,exports,window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){
"use strict";var t,a=require("../../@babel/runtime/helpers/defineProperty"),e=0,o=getApp(),n=wx.cloud.database().collection("tiku_users");Page((a(t={data:{userInfo:null},onShow:function(t){var a=o.globalData.userInfo;console.log("",a),a&&a.nickName?this.setData({userInfo:a}):this.setData({userInfo:wx.getStorageSync("user")}),this.getScore(),this.getUserInfo()},getUserInfo:function(){var t=this;console.log(o.globalData.openid),n.doc(o.globalData.openid).get().then((function(a){console.log("",a),t.setData({user:a.data})}))},getScore:function(){var t=this;wx.cloud.database().collection("tiku_users").doc(o.globalData.openid).get().then((function(a){if(a&&a.data&&a.data.score>0){var e=a.data.score;console.log("",e),t.setData({score:e})}})).catch((function(t){console.log("")}))}},"data",{data_arr:["日","一","二","三","四","五","六"],year:"",month:"",today:[],num:0,qiandao:!1,nowlist:[]}),a(t,"qiandao",(function(){var t=this,a=wx.getStorageSync("day"),s=(new Date).getDate();if(a!=s){wx.showToast({title:"签到成功积分+1",duration:2e3}),e++;var r=this.data.today;r.push({today:s}),this.setData({num:e,today:r,qiandao:!0}),wx.cloud.database().collection("tiku_users").doc(o.globalData.openid).get().then((function(a){if(a&&a.data&&a.data.score>0){var e=a.data.score;console.log("",e),t.setData({score:e+1}),n.doc(o.globalData.openid).update({data:{score:e+1}})}})),wx.setStorageSync("day",(new Date).getDate()),wx.setStorageSync("month",(new Date).getMonth()+1),wx.setStorageSync("num",this.data.num)}else this.setData({qiandao:!0}),wx.showToast({title:"已签到过",icon:"error",duration:2e3})})),a(t,"onLoad",(function(t){var a=wx.getStorageSync("num"),e=(wx.getStorageSync("day"),this.data.nowlist),o=(new Date).getDate();e.push({today:o}),this.setData({num:a,today:e});var n=new Date,s=n.getFullYear(),r=n.getMonth()+1;this.setData({year:s,month:r}),this.showCalendar()})),a(t,"showCalendar",(function(){var t=this.data,a=t.year,e=t.month,o=new Date(a,e,0).getDate(),n=new Date(a+"/"+e+"/1").getDay();this.setData({currentMonthDays:o,startWeek:n})})),a(t,"bindPreMonth",(function(){var t=this.data,a=t.year,e=t.month;e-1>=1?e-=1:(e=12,a-=1),this.setData({month:e,year:a}),this.showCalendar()})),a(t,"bindNextMonth",(function(){var t=this.data,a=t.year,e=t.month;e+1<=12?e+=1:(e=1,a+=1),this.setData({month:e,year:a}),this.showCalendar()})),t));
},{isPage:true,isComponent:true,currentFile:'pages/qiandao/qiandao.js'});require("pages/qiandao/qiandao.js");$gwx_XC_15=function(_,_v,_n,_p,_s,_wp,_wl,$gwn,$gwl,$gwh,wh,$gstack,$gwrt,gra,grb,TestTest,wfor,_ca,_da,_r,_rz,_o,_oz,_1,_1z,_2,_2z,_m,_mz,nv_getDate,nv_getRegExp,nv_console,nv_parseInt,nv_parseFloat,nv_isNaN,nv_isFinite,nv_decodeURI,nv_decodeURIComponent,nv_encodeURI,nv_encodeURIComponent,$gdc,nv_JSON,_af,_gv,_ai,_grp,_gd,_gapi,$ixc,_ic,_w,_ev,_tsd){return function(path,global){
if(typeof global==='undefined'){if (typeof __GWX_GLOBAL__==='undefined')global={};else global=__GWX_GLOBAL__;}if(typeof __WXML_GLOBAL__ === 'undefined') {__WXML_GLOBAL__={};
}__WXML_GLOBAL__.modules = __WXML_GLOBAL__.modules || {};
var e_={}
if(typeof(global.entrys)==='undefined')global.entrys={};e_=global.entrys;
var d_={}
if(typeof(global.defines)==='undefined')global.defines={};d_=global.defines;
var f_={}
if(typeof(global.modules)==='undefined')global.modules={};f_=global.modules || {};
var p_={}
__WXML_GLOBAL__.ops_cached = __WXML_GLOBAL__.ops_cached || {}
__WXML_GLOBAL__.ops_set = __WXML_GLOBAL__.ops_set || {};
__WXML_GLOBAL__.ops_init = __WXML_GLOBAL__.ops_init || {};
var z=__WXML_GLOBAL__.ops_set.$gwx_XC_15 || [];
function gz$gwx_XC_15_1(){
if( __WXML_GLOBAL__.ops_cached.$gwx_XC_15_1)return __WXML_GLOBAL__.ops_cached.$gwx_XC_15_1
__WXML_GLOBAL__.ops_cached.$gwx_XC_15_1=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
Z([3,'#fff'])
Z([3,'__l'])
Z(z[0])
Z([3,'-1'])
Z([1,false])
Z([3,'585bbb2e-1'])
Z([[4],[[5],[1,'default']]])
Z([3,'headView'])
Z([[2,'=='],[[7],[3,'type']],[1,'中国美术史（上）']])
Z([[2,'=='],[[7],[3,'type']],[1,'中国美术史（下）']])
Z([[2,'=='],[[7],[3,'type']],[1,'外国美术史（上）']])
Z([[2,'=='],[[7],[3,'type']],[1,'外国美术史（下）']])
Z([[2,'=='],[[7],[3,'type']],[1,'世界设计史（上）']])
Z([[2,'=='],[[7],[3,'type']],[1,'世界设计史（下）']])
})(__WXML_GLOBAL__.ops_cached.$gwx_XC_15_1);return __WXML_GLOBAL__.ops_cached.$gwx_XC_15_1
}
__WXML_GLOBAL__.ops_set.$gwx_XC_15=z;
__WXML_GLOBAL__.ops_init.$gwx_XC_15=true;
var x=['./pages/questionList/questionList.wxml'];d_[x[0]]={}
var m0=function(e,s,r,gg){
var z=gz$gwx_XC_15_1()
var cGC=_mz(z,'top-navbar',['bg',0,'bind:__l',1,'iconColor',1,'paddingTop',2,'tabbarBg',3,'vueId',4,'vueSlots',5],[],e,s,gg)
var oHC=_n('view')
_rz(z,oHC,'class',7,e,s,gg)
var lIC=_v()
_(oHC,lIC)
if(_oz(z,8,e,s,gg)){lIC.wxVkey=1
}
var aJC=_v()
_(oHC,aJC)
if(_oz(z,9,e,s,gg)){aJC.wxVkey=1
}
var tKC=_v()
_(oHC,tKC)
if(_oz(z,10,e,s,gg)){tKC.wxVkey=1
}
var eLC=_v()
_(oHC,eLC)
if(_oz(z,11,e,s,gg)){eLC.wxVkey=1
}
var bMC=_v()
_(oHC,bMC)
if(_oz(z,12,e,s,gg)){bMC.wxVkey=1
}
var oNC=_v()
_(oHC,oNC)
if(_oz(z,13,e,s,gg)){oNC.wxVkey=1
}
lIC.wxXCkey=1
aJC.wxXCkey=1
tKC.wxXCkey=1
eLC.wxXCkey=1
bMC.wxXCkey=1
oNC.wxXCkey=1
_(cGC,oHC)
_(r,cGC)
return r
}
e_[x[0]]={f:m0,j:[],i:[],ti:[],ic:[]}
if(path&&e_[path]){
return function(env,dd,global){$gwxc=0;var root={"tag":"wx-page"};root.children=[]
;g="$gwx_XC_15";var main=e_[path].f
if (typeof global==="undefined")global={};global.f=$gdc(f_[path],"",1);
try{
main(env,{},root,global);
_tsd(root)
}catch(err){
console.log(err)
}
;g="";
return root;
}
}
}
}(__g.a,__g.b,__g.c,__g.d,__g.e,__g.f,__g.g,__g.h,__g.i,__g.j,__g.k,__g.l,__g.m,__g.n,__g.o,__g.p,__g.q,__g.r,__g.s,__g.t,__g.u,__g.v,__g.w,__g.x,__g.y,__g.z,__g.A,__g.B,__g.C,__g.D,__g.E,__g.F,__g.G,__g.H,__g.I,__g.J,__g.K,__g.L,__g.M,__g.N,__g.O,__g.P,__g.Q,__g.R,__g.S,__g.T,__g.U,__g.V,__g.W,__g.X,__g.Y,__g.Z,__g.aa);if(__vd_version_info__.delayedGwx||false)$gwx_XC_15();	if (__vd_version_info__.delayedGwx) __wxAppCode__['pages/questionList/questionList.wxml'] = [$gwx_XC_15, './pages/questionList/questionList.wxml'];else __wxAppCode__['pages/questionList/questionList.wxml'] = $gwx_XC_15( './pages/questionList/questionList.wxml' );
	;__wxRoute = "pages/questionList/questionList";__wxRouteBegin = true;__wxAppCurrentFile__="pages/questionList/questionList.js";define("pages/questionList/questionList.js",function(require,module,exports,window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){
"use strict";var e=wx.cloud.database();getApp();Page({onLoad:function(t){var a=this;console.log("",t.type),wx.setNavigationBarTitle({title:t.type+"题"}),a.setData({type:t.type});var s=e.command.aggregate;e.collection("tiku_questions").aggregate().match({type:t.type}).group({_id:"$type2",num:s.sum(1)}).sort({_id:1}).end().then((function(e){console.log("",e),e.list.forEach((function(e){var t=e._id.replace("第","").replace("组","");t.length>2&&(t=t.replace("十",""));var s=t.split(""),r=a.tran(s);e.sort=r})),e.list.sort((function(e,t){return e.sort-t.sort})),console.log(e.list),a.setData({list:e.list})}))},tran:function(e){var t="";if(e.length>0)for(var a=0;a<e.length;a++){var s=e[a];if(0==a&&"十"==s&&1==e.length)t+="10";else if(0==a&&"十"==s&&e.length>1)t+="1";else switch(s){case"十":t+="0";break;case"九":t+="9";break;case"八":t+="8";break;case"七":t+="7";break;case"六":t+="6";break;case"五":t+="5";break;case"四":t+="4";break;case"三":t+="3";break;case"二":t+="2";break;case"一":t+="1"}}return t},goDetail:function(e){var t=this.data.type,a=e.currentTarget.dataset.type2;wx.navigateTo({url:"/pages/questions/questions?type1="+t+"&type2="+a})},onShareAppMessage:function(){return{title:" ",imageUrl:"https://636c-cloud1-8gs7t7f49b4c97d8-1309642353.tcb.qcloud.la/cloudbase-cms/upload/2022-04-24/m936jjv23g0npx2c20s0ldtsgtupfnin_.png"}},onShareTimeline:function(){return{title:"每天一遍，轻松过线",imageUrl:"https://636c-cloud1-8gs7t7f49b4c97d8-1309642353.tcb.qcloud.la/cloudbase-cms/upload/2022-04-24/euhb16l1ane9x0h0m9q7r12rchk95or3_.png"}}});
},{isPage:true,isComponent:true,currentFile:'pages/questionList/questionList.js'});require("pages/questionList/questionList.js");$gwx_XC_16=function(_,_v,_n,_p,_s,_wp,_wl,$gwn,$gwl,$gwh,wh,$gstack,$gwrt,gra,grb,TestTest,wfor,_ca,_da,_r,_rz,_o,_oz,_1,_1z,_2,_2z,_m,_mz,nv_getDate,nv_getRegExp,nv_console,nv_parseInt,nv_parseFloat,nv_isNaN,nv_isFinite,nv_decodeURI,nv_decodeURIComponent,nv_encodeURI,nv_encodeURIComponent,$gdc,nv_JSON,_af,_gv,_ai,_grp,_gd,_gapi,$ixc,_ic,_w,_ev,_tsd){return function(path,global){
if(typeof global==='undefined'){if (typeof __GWX_GLOBAL__==='undefined')global={};else global=__GWX_GLOBAL__;}if(typeof __WXML_GLOBAL__ === 'undefined') {__WXML_GLOBAL__={};
}__WXML_GLOBAL__.modules = __WXML_GLOBAL__.modules || {};
var e_={}
if(typeof(global.entrys)==='undefined')global.entrys={};e_=global.entrys;
var d_={}
if(typeof(global.defines)==='undefined')global.defines={};d_=global.defines;
var f_={}
if(typeof(global.modules)==='undefined')global.modules={};f_=global.modules || {};
var p_={}
__WXML_GLOBAL__.ops_cached = __WXML_GLOBAL__.ops_cached || {}
__WXML_GLOBAL__.ops_set = __WXML_GLOBAL__.ops_set || {};
__WXML_GLOBAL__.ops_init = __WXML_GLOBAL__.ops_init || {};
var z=__WXML_GLOBAL__.ops_set.$gwx_XC_16 || [];
function gz$gwx_XC_16_1(){
if( __WXML_GLOBAL__.ops_cached.$gwx_XC_16_1)return __WXML_GLOBAL__.ops_cached.$gwx_XC_16_1
__WXML_GLOBAL__.ops_cached.$gwx_XC_16_1=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
Z([[7],[3,'xztype']])
Z([[6],[[7],[3,'subject']],[3,'image']])
Z(z[0])
Z([3,'selectClick'])
Z([3,'anniu'])
Z([[6],[[7],[3,'subject']],[3,'optionC']])
Z([[6],[[7],[3,'subject']],[3,'optionD']])
Z(z[3])
Z(z[5])
Z(z[6])
Z([[7],[3,'showAnswer']])
Z([3,'answer-title'])
Z([[2,'!'],[[7],[3,'shoucang']]])
Z([[7],[3,'shoucang']])
Z([3,'collectoff'])
Z(z[13])
Z([[2,'>'],[[7],[3,'totalScore']],[[2,'-'],[1,1]]])
Z([[2,'>'],[[7],[3,'totalError']],[1,0]])
Z([[7],[3,'showModalStatus']])
Z(z[18])
})(__WXML_GLOBAL__.ops_cached.$gwx_XC_16_1);return __WXML_GLOBAL__.ops_cached.$gwx_XC_16_1
}
__WXML_GLOBAL__.ops_set.$gwx_XC_16=z;
__WXML_GLOBAL__.ops_init.$gwx_XC_16=true;
var x=['./pages/questions/questions.wxml'];d_[x[0]]={}
var m0=function(e,s,r,gg){
var z=gz$gwx_XC_16_1()
var oPC=_v()
_(r,oPC)
if(_oz(z,0,e,s,gg)){oPC.wxVkey=1
var oVC=_v()
_(oPC,oVC)
if(_oz(z,1,e,s,gg)){oVC.wxVkey=1
}
oVC.wxXCkey=1
}
var fQC=_v()
_(r,fQC)
if(_oz(z,2,e,s,gg)){fQC.wxVkey=1
var lWC=_mz(z,'radio-group',['bindchange',3,'class',1],[],e,s,gg)
var aXC=_v()
_(lWC,aXC)
if(_oz(z,5,e,s,gg)){aXC.wxVkey=1
}
var tYC=_v()
_(lWC,tYC)
if(_oz(z,6,e,s,gg)){tYC.wxVkey=1
}
aXC.wxXCkey=1
tYC.wxXCkey=1
_(fQC,lWC)
}
else{fQC.wxVkey=2
var eZC=_n('checkbox-group')
_rz(z,eZC,'bindchange',7,e,s,gg)
var b1C=_v()
_(eZC,b1C)
if(_oz(z,8,e,s,gg)){b1C.wxVkey=1
}
var o2C=_v()
_(eZC,o2C)
if(_oz(z,9,e,s,gg)){o2C.wxVkey=1
}
b1C.wxXCkey=1
o2C.wxXCkey=1
_(fQC,eZC)
}
var cRC=_v()
_(r,cRC)
if(_oz(z,10,e,s,gg)){cRC.wxVkey=1
var x3C=_n('view')
_rz(z,x3C,'class',11,e,s,gg)
var o4C=_v()
_(x3C,o4C)
if(_oz(z,12,e,s,gg)){o4C.wxVkey=1
}
var f5C=_v()
_(x3C,f5C)
if(_oz(z,13,e,s,gg)){f5C.wxVkey=1
var c6C=_n('view')
_rz(z,c6C,'bindtap',14,e,s,gg)
var h7C=_v()
_(c6C,h7C)
if(_oz(z,15,e,s,gg)){h7C.wxVkey=1
}
h7C.wxXCkey=1
_(f5C,c6C)
}
o4C.wxXCkey=1
f5C.wxXCkey=1
_(cRC,x3C)
}
var hSC=_v()
_(r,hSC)
if(_oz(z,16,e,s,gg)){hSC.wxVkey=1
var o8C=_v()
_(hSC,o8C)
if(_oz(z,17,e,s,gg)){o8C.wxVkey=1
}
o8C.wxXCkey=1
}
var oTC=_v()
_(r,oTC)
if(_oz(z,18,e,s,gg)){oTC.wxVkey=1
}
var cUC=_v()
_(r,cUC)
if(_oz(z,19,e,s,gg)){cUC.wxVkey=1
}
oPC.wxXCkey=1
fQC.wxXCkey=1
cRC.wxXCkey=1
hSC.wxXCkey=1
oTC.wxXCkey=1
cUC.wxXCkey=1
return r
}
e_[x[0]]={f:m0,j:[],i:[],ti:[],ic:[]}
if(path&&e_[path]){
return function(env,dd,global){$gwxc=0;var root={"tag":"wx-page"};root.children=[]
;g="$gwx_XC_16";var main=e_[path].f
if (typeof global==="undefined")global={};global.f=$gdc(f_[path],"",1);
try{
main(env,{},root,global);
_tsd(root)
}catch(err){
console.log(err)
}
;g="";
return root;
}
}
}
}(__g.a,__g.b,__g.c,__g.d,__g.e,__g.f,__g.g,__g.h,__g.i,__g.j,__g.k,__g.l,__g.m,__g.n,__g.o,__g.p,__g.q,__g.r,__g.s,__g.t,__g.u,__g.v,__g.w,__g.x,__g.y,__g.z,__g.A,__g.B,__g.C,__g.D,__g.E,__g.F,__g.G,__g.H,__g.I,__g.J,__g.K,__g.L,__g.M,__g.N,__g.O,__g.P,__g.Q,__g.R,__g.S,__g.T,__g.U,__g.V,__g.W,__g.X,__g.Y,__g.Z,__g.aa);if(__vd_version_info__.delayedGwx||false)$gwx_XC_16();	if (__vd_version_info__.delayedGwx) __wxAppCode__['pages/questions/questions.wxml'] = [$gwx_XC_16, './pages/questions/questions.wxml'];else __wxAppCode__['pages/questions/questions.wxml'] = $gwx_XC_16( './pages/questions/questions.wxml' );
	;__wxRoute = "pages/questions/questions";__wxRouteBegin = true;__wxAppCurrentFile__="pages/questions/questions.js";define("pages/questions/questions.js",function(require,module,exports,window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){
"use strict";var t=require("../../@babel/runtime/helpers/objectSpread2"),e=getApp(),a=wx.cloud.database(),o=a.collection("tiku_questions"),s=(wx.cloud.database().collection("tiku_questions"),a.collection("ms_sjlx2")),i=a.command,n=[];Page({data:{errorOptions:[],showAnswer:!1,percent:0,total:0,isSelect:!1,subject:null,userSelect:"",userScore:0,totalScore:-1,totalError:0,current:1,isShowConfirm:!1,shoucang:!1},onLoad:function(t){this.shuiji(t)},shuiji:function(t){var a=this;if(1==(i=e.globalData.xztype))var i=!0;else if(0==i)i=!1;console.log("",t),t.type1&&t.type2?(wx.setNavigationBarTitle({title:t.type2+"答题"}),o.where({type:t.type1,type2:t.type2}).get().then((function(t){console.log("",t);var e=(n=t.data)[0];console.log("subject",e),a.setData({xztype:i,subject:e,total:n.length})}))):(wx.setNavigationBarTitle({title:"随机答题"}),s.aggregate().sample({size:e.globalData.randomNum}).end().then((function(t){console.log("",t);var e=(n=t.list)[0];a.setData({xztype:i,subject:e,total:n.length})}))),console.log(e.globalData.userInfo)},selectClick:function(t){console.log(t.detail.value),this.setData({userSelect:t.detail.value})},submhfghit:function(){this.setData({showAnswer:!1});var t=this.data.userSelect;if(!t||t.length<1)wx.showToast({icon:"none",title:"请做选择"});else{var e=this.data.current;if(this.setData({percent:(e/n.length*100).toFixed(1)}),console.log("用户选项",t),console.log("正确答案",this.data.subject.answer),t instanceof Array&&(console.log("是数组"),t=t.sort().toString()),this.data.subject.answer==t)console.log("用户答对了第"+e+"道题"),this.setData({userScore:this.data.userScore+1});else{var o=this.data.subject;o.userSelect=t,this.data.errorOptions.push(o);var s={};Object.assign(s,o),delete s._id;var i=wx.getStorageSync("user")||{};s.nickName=i&&i.nickName?i.nickName:"未登陆用户",console.log("临时错题",s),a.collection("tiku_errors").add({data:s}).then((function(t){console.log("添加错题到数据库",t)})),console.log("错题",o)}if(e+1>n.length){var l=this.data.userScore;return console.log("用户一共答对了"+l+"道题"),console.log("用户错题集",this.data.errorOptions),this.setData({totalScore:l,totalError:this.data.errorOptions.length,hideButton:!0}),wx.showToast({icon:"none",title:"已经最后一道啦"}),void this.addScore(l)}var c=n[e];this.setData({userSelect:"",subject:c,current:e+1,isSelect:!1})}},seeEdfhdrror:function(){console.log("点击了查看错题集"),wx.switchTab({url:"/pages/errorList/errorList"})},addScohhjre:function(t){e.globalData.userInfo&&e.globalData.userInfo.name&&(console.log(t),a.collection("tiku_users").doc(e.globalData.openid).update({data:{score:i.inc(t)}}).then((function(t){wx.showToast({title:"积分生效"})})))},okjkj:function(){var t=this.data.userSelect;!t||t.length<1?wx.showToast({icon:"none",title:"请做选择"}):this.setData({showAnswer:!0})},collehshhct:function(){var e=this;wx.cloud.database().collection("tiku_collects").add({data:t({},this.data.subject)}).then((function(t){wx.showToast({title:"收藏成功"})})).catch((function(t){console.log(t),wx.cloud.database().collection("tiku_collects").doc(e.data.subject._id).remove().then((function(t){console.log(t),wx.showToast({title:"取消成功"})}))}))},submit:function(){wx.showLoading({title:"加载中...",mask:!0});var t=e.globalData.xztype;this.setData({showAnswer:!1});var o=this.data.userSelect,s=this.data.current;if(this.setData({percent:(s/n.length*100).toFixed(1)}),console.log("",o),console.log("",this.data.subject.answer),o instanceof Array)console.log(""),o=o;else if(this.data.subject.answer==o)console.log(""+s),this.setData({userScore:this.data.userScore+1});else if(this.data.subject.answer==!o||0==o.length)console.log(""+s),this.setData({userScore:this.data.userScore+0});else{var i=this.data.subject;i.userSelect=o,this.data.errorOptions.push(i);var l={};Object.assign(l,i),delete l._id;var c=wx.getStorageSync("user")||{};l.nickName=c&&c.nickName?c.nickName:"未登陆用户",console.log("",l),a.collection("tiku_errors").add({data:l}).then((function(t){console.log("",t)})),console.log("",i)}if(s+1>n.length){var r=this.data.userScore;return console.log(""+r),console.log("",this.data.errorOptions),this.setData({totalScore:r,totalError:this.data.errorOptions.length,hideButton:!0}),wx.showToast({icon:"none",title:"已经最后一道啦"}),void this.addScore(r)}var u=n[s];if(0==t){var h=this;setTimeout((function(){wx.hideLoading(),h.setData({userSelect:"",subject:u,current:s+1,isSelect:!1})}),4e3)}else{h=this;wx.hideLoading(),h.setData({userSelect:"",subject:u,current:s+1,isSelect:!1})}},seeError:function(){console.log(""),wx.switchTab({url:"/pages/errorList/errorList"})},addScore:function(t){e.globalData.userInfo&&e.globalData.userInfo.name&&(console.log(t),a.collection("tiku_users").doc(e.globalData.openid).update({data:{score:i.inc(t)}}).then((function(t){wx.showToast({title:"积分生效"})})))},addScoreok:function(){if(0==e.globalData.xztype){wx.showLoading({title:"加载中...",mask:!0});var t=this.data.userSelect;if(!t||t.length<1)return void wx.showToast({icon:"none",title:"请做选择"});var a=this;setTimeout((function(){wx.hideLoading(),a.setData({showAnswer:!0})}),4e3)}else{var o=this.data.userSelect;if(!o||o.length<1)return void wx.showToast({icon:"none",title:"请做选择"});(a=this).setData({showAnswer:!0})}},previewImg:function(t){var e=t.currentTarget.dataset.tp;wx.previewImage({urls:e})},baocuoanniu:function(){this.setData({isShowConfirm:!0})},getValue:function(t){console.log(t.detail.value);var e=t.detail.value;this.setData({inputValue:e})},selectClick11:function(t){console.log(t.detail.value),this.setData({jiucuo:t.detail.value})},formSubmit1:function(t){var e=this,a=t.detail.value;wx.cloud.database().collection("tiku_questions").doc(this.data.subject._id).update({data:{tikuerrors:a.tikuerrors}}).then((function(t){wx.showToast({title:"反馈成功"}),e.setData({showModalStatus:!1})}))},collect:function(){var t=this;wx.cloud.database().collection("tiku_collects").add({data:{title:this.data.subject.title,image:this.data.subject.image,explain:this.data.subject.explain,answer:this.data.subject.answer,optionA:this.data.subject.optionA,optionB:this.data.subject.optionB,optionC:this.data.subject.optionC,optionD:this.data.subject.optionD,type:this.data.subject.type,type2:this.data.subject.type2}}).then((function(e){t.setData({shoucang:!0}),wx.showToast({title:"收藏成功"})}))},collectoff:function(){var t=this;wx.cloud.database().collection("tiku_collects").where({title:wx.cloud.database().RegExp({regexp:this.data.subject.title,options:"i"})}).get().then((function(e){console.log("😄嘻嘻哈哈",e);var a=e.data[0]._id;wx.cloud.database().collection("tiku_collects").doc(a).remove().then((function(e){t.setData({shoucang:!1}),console.log(e),wx.showToast({title:"取消成功"})}))}))},clickme:function(){this.showModal()},showModal:function(){var t=wx.createAnimation({duration:200,timingFunction:"linear",delay:0});this.animation=t,t.translateY(300).step(),this.setData({animationData:t.export(),showModalStatus:!0}),setTimeout(function(){t.translateY(0).step(),this.setData({animationData:t.export()})}.bind(this),200)},hideModal:function(){var t=wx.createAnimation({duration:200,timingFunction:"linear",delay:0});this.animation=t,t.translateY(300).step(),this.setData({animationData:t.export()}),setTimeout(function(){t.translateY(0).step(),this.setData({animationData:t.export(),showModalStatus:!1})}.bind(this),200)},onShareAppMessage:function(){return{title:" ",imageUrl:"https://636c-cloud1-8gs7t7f49b4c97d8-1309642353.tcb.qcloud.la/cloudbase-cms/upload/2022-04-24/m936jjv23g0npx2c20s0ldtsgtupfnin_.png"}},onShareTimeline:function(){return{title:"每天一遍，轻松过线",imageUrl:"https://636c-cloud1-8gs7t7f49b4c97d8-1309642353.tcb.qcloud.la/cloudbase-cms/upload/2022-04-24/euhb16l1ane9x0h0m9q7r12rchk95or3_.png"}}});
},{isPage:true,isComponent:true,currentFile:'pages/questions/questions.js'});require("pages/questions/questions.js");$gwx_XC_17=function(_,_v,_n,_p,_s,_wp,_wl,$gwn,$gwl,$gwh,wh,$gstack,$gwrt,gra,grb,TestTest,wfor,_ca,_da,_r,_rz,_o,_oz,_1,_1z,_2,_2z,_m,_mz,nv_getDate,nv_getRegExp,nv_console,nv_parseInt,nv_parseFloat,nv_isNaN,nv_isFinite,nv_decodeURI,nv_decodeURIComponent,nv_encodeURI,nv_encodeURIComponent,$gdc,nv_JSON,_af,_gv,_ai,_grp,_gd,_gapi,$ixc,_ic,_w,_ev,_tsd){return function(path,global){
if(typeof global==='undefined'){if (typeof __GWX_GLOBAL__==='undefined')global={};else global=__GWX_GLOBAL__;}if(typeof __WXML_GLOBAL__ === 'undefined') {__WXML_GLOBAL__={};
}__WXML_GLOBAL__.modules = __WXML_GLOBAL__.modules || {};
var e_={}
if(typeof(global.entrys)==='undefined')global.entrys={};e_=global.entrys;
var d_={}
if(typeof(global.defines)==='undefined')global.defines={};d_=global.defines;
var f_={}
if(typeof(global.modules)==='undefined')global.modules={};f_=global.modules || {};
var p_={}
__WXML_GLOBAL__.ops_cached = __WXML_GLOBAL__.ops_cached || {}
__WXML_GLOBAL__.ops_set = __WXML_GLOBAL__.ops_set || {};
__WXML_GLOBAL__.ops_init = __WXML_GLOBAL__.ops_init || {};
var z=__WXML_GLOBAL__.ops_set.$gwx_XC_17 || [];
function gz$gwx_XC_17_1(){
if( __WXML_GLOBAL__.ops_cached.$gwx_XC_17_1)return __WXML_GLOBAL__.ops_cached.$gwx_XC_17_1
__WXML_GLOBAL__.ops_cached.$gwx_XC_17_1=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
})(__WXML_GLOBAL__.ops_cached.$gwx_XC_17_1);return __WXML_GLOBAL__.ops_cached.$gwx_XC_17_1
}
__WXML_GLOBAL__.ops_set.$gwx_XC_17=z;
__WXML_GLOBAL__.ops_init.$gwx_XC_17=true;
var x=['./pages/ranking/ranking.wxml'];d_[x[0]]={}
var m0=function(e,s,r,gg){
var z=gz$gwx_XC_17_1()
return r
}
e_[x[0]]={f:m0,j:[],i:[],ti:[],ic:[]}
if(path&&e_[path]){
return function(env,dd,global){$gwxc=0;var root={"tag":"wx-page"};root.children=[]
;g="$gwx_XC_17";var main=e_[path].f
if (typeof global==="undefined")global={};global.f=$gdc(f_[path],"",1);
try{
main(env,{},root,global);
_tsd(root)
}catch(err){
console.log(err)
}
;g="";
return root;
}
}
}
}(__g.a,__g.b,__g.c,__g.d,__g.e,__g.f,__g.g,__g.h,__g.i,__g.j,__g.k,__g.l,__g.m,__g.n,__g.o,__g.p,__g.q,__g.r,__g.s,__g.t,__g.u,__g.v,__g.w,__g.x,__g.y,__g.z,__g.A,__g.B,__g.C,__g.D,__g.E,__g.F,__g.G,__g.H,__g.I,__g.J,__g.K,__g.L,__g.M,__g.N,__g.O,__g.P,__g.Q,__g.R,__g.S,__g.T,__g.U,__g.V,__g.W,__g.X,__g.Y,__g.Z,__g.aa);if(__vd_version_info__.delayedGwx||false)$gwx_XC_17();	if (__vd_version_info__.delayedGwx) __wxAppCode__['pages/ranking/ranking.wxml'] = [$gwx_XC_17, './pages/ranking/ranking.wxml'];else __wxAppCode__['pages/ranking/ranking.wxml'] = $gwx_XC_17( './pages/ranking/ranking.wxml' );
	;__wxRoute = "pages/ranking/ranking";__wxRouteBegin = true;__wxAppCurrentFile__="pages/ranking/ranking.js";define("pages/ranking/ranking.js",function(require,module,exports,window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){
"use strict";var t=wx.cloud.database(),e=getApp();Page({onShow:function(){var t=this;wx.cloud.database().collection("tiku_users").orderBy("score","desc").get().then((function(e){console.log("",e.data),t.setData({userList:e.data})}))},onLoad:function(){var e=this,o=t.command.aggregate;t.collection("tiku_users").aggregate().group({_id:"$id",num:o.sum(1)}).end().then((function(t){console.log("",t),e.setData({list1:t.list})}))},goQuestions:function(){e.globalData.userInfo&&e.globalData.userInfo.name?wx.switchTab({url:"/pages/home/home"}):wx.showModal({title:"请先注册",content:"注册用户后才可以参与积分排名",success:function(t){t.confirm&&wx.navigateTo({url:"/pages/change/change"})}})},onShareAppMessage:function(){return{title:" ",imageUrl:"https://636c-cloud1-8gs7t7f49b4c97d8-1309642353.tcb.qcloud.la/cloudbase-cms/upload/2022-04-24/m936jjv23g0npx2c20s0ldtsgtupfnin_.png"}},onShareTimeline:function(){return{title:"每天一遍，轻松过线",imageUrl:"https://636c-cloud1-8gs7t7f49b4c97d8-1309642353.tcb.qcloud.la/cloudbase-cms/upload/2022-04-24/euhb16l1ane9x0h0m9q7r12rchk95or3_.png"}}});
},{isPage:true,isComponent:true,currentFile:'pages/ranking/ranking.js'});require("pages/ranking/ranking.js");$gwx_XC_18=function(_,_v,_n,_p,_s,_wp,_wl,$gwn,$gwl,$gwh,wh,$gstack,$gwrt,gra,grb,TestTest,wfor,_ca,_da,_r,_rz,_o,_oz,_1,_1z,_2,_2z,_m,_mz,nv_getDate,nv_getRegExp,nv_console,nv_parseInt,nv_parseFloat,nv_isNaN,nv_isFinite,nv_decodeURI,nv_decodeURIComponent,nv_encodeURI,nv_encodeURIComponent,$gdc,nv_JSON,_af,_gv,_ai,_grp,_gd,_gapi,$ixc,_ic,_w,_ev,_tsd){return function(path,global){
if(typeof global==='undefined'){if (typeof __GWX_GLOBAL__==='undefined')global={};else global=__GWX_GLOBAL__;}if(typeof __WXML_GLOBAL__ === 'undefined') {__WXML_GLOBAL__={};
}__WXML_GLOBAL__.modules = __WXML_GLOBAL__.modules || {};
var e_={}
if(typeof(global.entrys)==='undefined')global.entrys={};e_=global.entrys;
var d_={}
if(typeof(global.defines)==='undefined')global.defines={};d_=global.defines;
var f_={}
if(typeof(global.modules)==='undefined')global.modules={};f_=global.modules || {};
var p_={}
__WXML_GLOBAL__.ops_cached = __WXML_GLOBAL__.ops_cached || {}
__WXML_GLOBAL__.ops_set = __WXML_GLOBAL__.ops_set || {};
__WXML_GLOBAL__.ops_init = __WXML_GLOBAL__.ops_init || {};
var z=__WXML_GLOBAL__.ops_set.$gwx_XC_18 || [];
function gz$gwx_XC_18_1(){
if( __WXML_GLOBAL__.ops_cached.$gwx_XC_18_1)return __WXML_GLOBAL__.ops_cached.$gwx_XC_18_1
__WXML_GLOBAL__.ops_cached.$gwx_XC_18_1=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
Z([[6],[[7],[3,'subject']],[3,'image']])
Z([[2,'=='],[[6],[[6],[[7],[3,'subject']],[3,'answer']],[3,'length']],[1,1]])
Z([3,'selectClick'])
Z([3,'anniu'])
Z([[6],[[7],[3,'subject']],[3,'optionC']])
Z([[6],[[7],[3,'subject']],[3,'optionD']])
Z(z[2])
Z(z[4])
Z(z[5])
Z([[7],[3,'showAnswer']])
Z([3,'collect'])
Z([[2,'!'],[[7],[3,'shoucang']]])
Z([[7],[3,'shoucang']])
Z([[2,'>'],[[7],[3,'totalScore']],[[2,'-'],[1,1]]])
Z([[2,'>'],[[7],[3,'totalError']],[1,0]])
})(__WXML_GLOBAL__.ops_cached.$gwx_XC_18_1);return __WXML_GLOBAL__.ops_cached.$gwx_XC_18_1
}
__WXML_GLOBAL__.ops_set.$gwx_XC_18=z;
__WXML_GLOBAL__.ops_init.$gwx_XC_18=true;
var x=['./pages/shouchangxiangqin/shouchangxiangqin.wxml'];d_[x[0]]={}
var m0=function(e,s,r,gg){
var z=gz$gwx_XC_18_1()
var lAD=_v()
_(r,lAD)
if(_oz(z,0,e,s,gg)){lAD.wxVkey=1
}
var aBD=_v()
_(r,aBD)
if(_oz(z,1,e,s,gg)){aBD.wxVkey=1
var bED=_mz(z,'radio-group',['bindchange',2,'class',1],[],e,s,gg)
var oFD=_v()
_(bED,oFD)
if(_oz(z,4,e,s,gg)){oFD.wxVkey=1
}
var xGD=_v()
_(bED,xGD)
if(_oz(z,5,e,s,gg)){xGD.wxVkey=1
}
oFD.wxXCkey=1
xGD.wxXCkey=1
_(aBD,bED)
}
else{aBD.wxVkey=2
var oHD=_n('checkbox-group')
_rz(z,oHD,'bindchange',6,e,s,gg)
var fID=_v()
_(oHD,fID)
if(_oz(z,7,e,s,gg)){fID.wxVkey=1
}
var cJD=_v()
_(oHD,cJD)
if(_oz(z,8,e,s,gg)){cJD.wxVkey=1
}
fID.wxXCkey=1
cJD.wxXCkey=1
_(aBD,oHD)
}
var tCD=_v()
_(r,tCD)
if(_oz(z,9,e,s,gg)){tCD.wxVkey=1
var hKD=_n('view')
_rz(z,hKD,'bindtap',10,e,s,gg)
var oLD=_v()
_(hKD,oLD)
if(_oz(z,11,e,s,gg)){oLD.wxVkey=1
}
var cMD=_v()
_(hKD,cMD)
if(_oz(z,12,e,s,gg)){cMD.wxVkey=1
}
oLD.wxXCkey=1
cMD.wxXCkey=1
_(tCD,hKD)
}
var eDD=_v()
_(r,eDD)
if(_oz(z,13,e,s,gg)){eDD.wxVkey=1
var oND=_v()
_(eDD,oND)
if(_oz(z,14,e,s,gg)){oND.wxVkey=1
}
oND.wxXCkey=1
}
lAD.wxXCkey=1
aBD.wxXCkey=1
tCD.wxXCkey=1
eDD.wxXCkey=1
return r
}
e_[x[0]]={f:m0,j:[],i:[],ti:[],ic:[]}
if(path&&e_[path]){
return function(env,dd,global){$gwxc=0;var root={"tag":"wx-page"};root.children=[]
;g="$gwx_XC_18";var main=e_[path].f
if (typeof global==="undefined")global={};global.f=$gdc(f_[path],"",1);
try{
main(env,{},root,global);
_tsd(root)
}catch(err){
console.log(err)
}
;g="";
return root;
}
}
}
}(__g.a,__g.b,__g.c,__g.d,__g.e,__g.f,__g.g,__g.h,__g.i,__g.j,__g.k,__g.l,__g.m,__g.n,__g.o,__g.p,__g.q,__g.r,__g.s,__g.t,__g.u,__g.v,__g.w,__g.x,__g.y,__g.z,__g.A,__g.B,__g.C,__g.D,__g.E,__g.F,__g.G,__g.H,__g.I,__g.J,__g.K,__g.L,__g.M,__g.N,__g.O,__g.P,__g.Q,__g.R,__g.S,__g.T,__g.U,__g.V,__g.W,__g.X,__g.Y,__g.Z,__g.aa);if(__vd_version_info__.delayedGwx||false)$gwx_XC_18();	if (__vd_version_info__.delayedGwx) __wxAppCode__['pages/shouchangxiangqin/shouchangxiangqin.wxml'] = [$gwx_XC_18, './pages/shouchangxiangqin/shouchangxiangqin.wxml'];else __wxAppCode__['pages/shouchangxiangqin/shouchangxiangqin.wxml'] = $gwx_XC_18( './pages/shouchangxiangqin/shouchangxiangqin.wxml' );
	;__wxRoute = "pages/shouchangxiangqin/shouchangxiangqin";__wxRouteBegin = true;__wxAppCurrentFile__="pages/shouchangxiangqin/shouchangxiangqin.js";define("pages/shouchangxiangqin/shouchangxiangqin.js",function(require,module,exports,window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){
"use strict";var t=require("../../@babel/runtime/helpers/objectSpread2"),e=getApp(),o=wx.cloud.database(),a=o.collection("tiku_collects"),s=o.command,c=[];Page({data:{errorOptions:[],showAnswer:!1,percent:0,total:0,isSelect:!1,subject:null,userSelect:"",userScore:0,totalScore:-1,totalError:0,current:1},onLoad:function(t){var e=this;console.log("",t),a.doc(t.id).get().then((function(t){console.log("",t),e.setData({subject:t.data})}))},selectClick:function(t){console.log(t.detail.value),this.setData({userSelect:t.detail.value})},submit:function(){this.setData({showAnswer:!1});var t=this.data.userSelect;if(!t||t.length<1)wx.showToast({icon:"none",title:"请做选择"});else{var e=this.data.current;if(this.setData({percent:(e/c.length*100).toFixed(1)}),console.log("",t),console.log("",this.data.subject.answer),t instanceof Array&&(console.log(""),t=t.sort().toString()),this.data.subject.answer==t)console.log(""+e),this.setData({userScore:this.data.userScore+1});else{var a=this.data.subject;a.userSelect=t,this.data.errorOptions.push(a);var s={};Object.assign(s,a),delete s._id;var n=wx.getStorageSync("user")||{};s.nickName=n&&n.nickName?n.nickName:"未登陆用户",console.log("",s),o.collection("tiku_errors").add({data:s}).then((function(t){console.log("",t)})),console.log("",a)}if(e+1>c.length){var l=this.data.userScore;return console.log(""+l),console.log("",this.data.errorOptions),this.setData({totalScore:l,totalError:this.data.errorOptions.length,hideButton:!0}),wx.showToast({icon:"none",title:"已经最后一道啦"}),void this.addScore(l)}var r=c[e];this.setData({userSelect:"",subject:r,current:e+1,isSelect:!1})}},seeError:function(){console.log(""),wx.switchTab({url:"/pages/errorList/errorList"})},collect:function(){var e=this;wx.cloud.database().collection("tiku_collects").add({data:t({},this.data.subject)}).then((function(t){e.setData({shoucang:!0}),wx.showToast({title:"收藏成功"})})).catch((function(t){console.log(t),wx.cloud.database().collection("tiku_collects").doc(e.data.subject._id).remove().then((function(t){e.setData({shoucang:!1}),console.log(t),wx.showToast({title:"取消成功"})}))}))},addScore:function(t){e.globalData.userInfo&&e.globalData.userInfo.name&&(console.log(t),o.collection("tiku_users").doc(e.globalData.openid).update({data:{score:s.inc(t)}}).then((function(t){wx.showToast({title:"积分生效"})})))},ok:function(){var t=this,e=this.data.userSelect;!e||e.length<1?wx.showToast({icon:"none",title:"请做选择"}):(this.setData({showAnswer:!0}),wx.cloud.database().collection("tiku_collects").where({_id:wx.cloud.database().RegExp({regexp:this.data.subject._id,options:"i"})}).get().then((function(e){console.log("😄嘻嘻哈哈",e),console.log("😄嘻嘻哈哈",e);var o=e.data[0],a=t.data.subject;console.log("😄嘻嘻哈哈",o),console.log("😄嘻嘻哈哈",a),(a=o)?t.setData({shoucang:!0}):t.setData({shoucang:!1})})))},previewImg:function(t){var e=t.currentTarget.dataset.tp;wx.previewImage({urls:e})}});
},{isPage:true,isComponent:true,currentFile:'pages/shouchangxiangqin/shouchangxiangqin.js'});require("pages/shouchangxiangqin/shouchangxiangqin.js");$gwx_XC_19=function(_,_v,_n,_p,_s,_wp,_wl,$gwn,$gwl,$gwh,wh,$gstack,$gwrt,gra,grb,TestTest,wfor,_ca,_da,_r,_rz,_o,_oz,_1,_1z,_2,_2z,_m,_mz,nv_getDate,nv_getRegExp,nv_console,nv_parseInt,nv_parseFloat,nv_isNaN,nv_isFinite,nv_decodeURI,nv_decodeURIComponent,nv_encodeURI,nv_encodeURIComponent,$gdc,nv_JSON,_af,_gv,_ai,_grp,_gd,_gapi,$ixc,_ic,_w,_ev,_tsd){return function(path,global){
if(typeof global==='undefined'){if (typeof __GWX_GLOBAL__==='undefined')global={};else global=__GWX_GLOBAL__;}if(typeof __WXML_GLOBAL__ === 'undefined') {__WXML_GLOBAL__={};
}__WXML_GLOBAL__.modules = __WXML_GLOBAL__.modules || {};
var e_={}
if(typeof(global.entrys)==='undefined')global.entrys={};e_=global.entrys;
var d_={}
if(typeof(global.defines)==='undefined')global.defines={};d_=global.defines;
var f_={}
if(typeof(global.modules)==='undefined')global.modules={};f_=global.modules || {};
var p_={}
__WXML_GLOBAL__.ops_cached = __WXML_GLOBAL__.ops_cached || {}
__WXML_GLOBAL__.ops_set = __WXML_GLOBAL__.ops_set || {};
__WXML_GLOBAL__.ops_init = __WXML_GLOBAL__.ops_init || {};
var z=__WXML_GLOBAL__.ops_set.$gwx_XC_19 || [];
function gz$gwx_XC_19_1(){
if( __WXML_GLOBAL__.ops_cached.$gwx_XC_19_1)return __WXML_GLOBAL__.ops_cached.$gwx_XC_19_1
__WXML_GLOBAL__.ops_cached.$gwx_XC_19_1=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
Z([[6],[[7],[3,'subject']],[3,'image']])
Z([[2,'=='],[[6],[[6],[[7],[3,'subject']],[3,'answer']],[3,'length']],[1,1]])
Z([3,'selectClick'])
Z([3,'anniu'])
Z([[6],[[7],[3,'subject']],[3,'optionC']])
Z([[6],[[7],[3,'subject']],[3,'optionD']])
Z(z[2])
Z(z[4])
Z(z[5])
Z([[7],[3,'showAnswer']])
Z([3,'collect'])
Z([[2,'!'],[[7],[3,'shoucang']]])
Z([[7],[3,'shoucang']])
Z([[2,'>'],[[7],[3,'totalScore']],[[2,'-'],[1,1]]])
Z([[2,'>'],[[7],[3,'totalError']],[1,0]])
})(__WXML_GLOBAL__.ops_cached.$gwx_XC_19_1);return __WXML_GLOBAL__.ops_cached.$gwx_XC_19_1
}
__WXML_GLOBAL__.ops_set.$gwx_XC_19=z;
__WXML_GLOBAL__.ops_init.$gwx_XC_19=true;
var x=['./pages/sousuo/sousuo.wxml'];d_[x[0]]={}
var m0=function(e,s,r,gg){
var z=gz$gwx_XC_19_1()
var aPD=_v()
_(r,aPD)
if(_oz(z,0,e,s,gg)){aPD.wxVkey=1
}
var tQD=_v()
_(r,tQD)
if(_oz(z,1,e,s,gg)){tQD.wxVkey=1
var oTD=_mz(z,'radio-group',['bindchange',2,'class',1],[],e,s,gg)
var xUD=_v()
_(oTD,xUD)
if(_oz(z,4,e,s,gg)){xUD.wxVkey=1
}
var oVD=_v()
_(oTD,oVD)
if(_oz(z,5,e,s,gg)){oVD.wxVkey=1
}
xUD.wxXCkey=1
oVD.wxXCkey=1
_(tQD,oTD)
}
else{tQD.wxVkey=2
var fWD=_n('checkbox-group')
_rz(z,fWD,'bindchange',6,e,s,gg)
var cXD=_v()
_(fWD,cXD)
if(_oz(z,7,e,s,gg)){cXD.wxVkey=1
}
var hYD=_v()
_(fWD,hYD)
if(_oz(z,8,e,s,gg)){hYD.wxVkey=1
}
cXD.wxXCkey=1
hYD.wxXCkey=1
_(tQD,fWD)
}
var eRD=_v()
_(r,eRD)
if(_oz(z,9,e,s,gg)){eRD.wxVkey=1
var oZD=_n('view')
_rz(z,oZD,'bindtap',10,e,s,gg)
var c1D=_v()
_(oZD,c1D)
if(_oz(z,11,e,s,gg)){c1D.wxVkey=1
}
var o2D=_v()
_(oZD,o2D)
if(_oz(z,12,e,s,gg)){o2D.wxVkey=1
}
c1D.wxXCkey=1
o2D.wxXCkey=1
_(eRD,oZD)
}
var bSD=_v()
_(r,bSD)
if(_oz(z,13,e,s,gg)){bSD.wxVkey=1
var l3D=_v()
_(bSD,l3D)
if(_oz(z,14,e,s,gg)){l3D.wxVkey=1
}
l3D.wxXCkey=1
}
aPD.wxXCkey=1
tQD.wxXCkey=1
eRD.wxXCkey=1
bSD.wxXCkey=1
return r
}
e_[x[0]]={f:m0,j:[],i:[],ti:[],ic:[]}
if(path&&e_[path]){
return function(env,dd,global){$gwxc=0;var root={"tag":"wx-page"};root.children=[]
;g="$gwx_XC_19";var main=e_[path].f
if (typeof global==="undefined")global={};global.f=$gdc(f_[path],"",1);
try{
main(env,{},root,global);
_tsd(root)
}catch(err){
console.log(err)
}
;g="";
return root;
}
}
}
}(__g.a,__g.b,__g.c,__g.d,__g.e,__g.f,__g.g,__g.h,__g.i,__g.j,__g.k,__g.l,__g.m,__g.n,__g.o,__g.p,__g.q,__g.r,__g.s,__g.t,__g.u,__g.v,__g.w,__g.x,__g.y,__g.z,__g.A,__g.B,__g.C,__g.D,__g.E,__g.F,__g.G,__g.H,__g.I,__g.J,__g.K,__g.L,__g.M,__g.N,__g.O,__g.P,__g.Q,__g.R,__g.S,__g.T,__g.U,__g.V,__g.W,__g.X,__g.Y,__g.Z,__g.aa);if(__vd_version_info__.delayedGwx||false)$gwx_XC_19();	if (__vd_version_info__.delayedGwx) __wxAppCode__['pages/sousuo/sousuo.wxml'] = [$gwx_XC_19, './pages/sousuo/sousuo.wxml'];else __wxAppCode__['pages/sousuo/sousuo.wxml'] = $gwx_XC_19( './pages/sousuo/sousuo.wxml' );
	;__wxRoute = "pages/sousuo/sousuo";__wxRouteBegin = true;__wxAppCurrentFile__="pages/sousuo/sousuo.js";define("pages/sousuo/sousuo.js",function(require,module,exports,window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){
"use strict";var t=require("../../@babel/runtime/helpers/objectSpread2"),e=getApp(),o=wx.cloud.database(),a=o.collection("tiku_questions"),s=o.command,c=[];Page({data:{errorOptions:[],item:"",showAnswer:!1,percent:0,total:0,isSelect:!1,subject:null,userSelect:"",userScore:0,totalScore:-1,totalError:0,current:1},onLoad:function(t){var e=this;console.log("",t),a.doc(t.id).get().then((function(t){console.log("",t),e.setData({subject:t.data})}))},selectClick:function(t){console.log(t.detail.value),this.setData({userSelect:t.detail.value})},submit:function(){this.setData({showAnswer:!1});var t=this.data.userSelect;if(!t||t.length<1)wx.showToast({icon:"none",title:"请做选择"});else{var e=this.data.current;if(this.setData({percent:(e/c.length*100).toFixed(1)}),console.log("",t),console.log("",this.data.subject.answer),t instanceof Array&&(console.log(""),t=t.sort().toString()),this.data.subject.answer==t)console.log(""+e),this.setData({userScore:this.data.userScore+1});else{var a=this.data.subject;a.userSelect=t,this.data.errorOptions.push(a);var s={};Object.assign(s,a),delete s._id;var n=wx.getStorageSync("user")||{};s.nickName=n&&n.nickName?n.nickName:"未登陆用户",console.log("",s),o.collection("tiku_errors").add({data:s}).then((function(t){console.log("",t)})),console.log("",a)}if(e+1>c.length){var l=this.data.userScore;return console.log(""+l),console.log("",this.data.errorOptions),this.setData({totalScore:l,totalError:this.data.errorOptions.length,hideButton:!0}),wx.showToast({icon:"none",title:"已经最后一道啦"}),void this.addScore(l)}var r=c[e];this.setData({userSelect:"",subject:r,current:e+1,isSelect:!1})}},seeError:function(){console.log(""),wx.switchTab({url:"/pages/errorList/errorList"})},collect:function(){var e=this;wx.cloud.database().collection("tiku_collects").add({data:t({},this.data.subject)}).then((function(t){e.setData({shoucang:!0}),wx.showToast({title:"收藏成功"})})).catch((function(t){console.log(t),wx.cloud.database().collection("tiku_collects").doc(e.data.subject._id).remove().then((function(t){e.setData({shoucang:!1}),console.log(t),wx.showToast({title:"取消成功"})}))}))},previewImg:function(t){var e=t.currentTarget.dataset.tp;wx.previewImage({urls:e})},addScore:function(t){e.globalData.userInfo&&e.globalData.userInfo.name&&(console.log(t),o.collection("tiku_users").doc(e.globalData.openid).update({data:{score:s.inc(t)}}).then((function(t){wx.showToast({title:"积分生效"})})))},ok:function(){var t=this,e=this.data.userSelect;!e||e.length<1?wx.showToast({icon:"none",title:"请做选择"}):(this.setData({showAnswer:!0}),wx.cloud.database().collection("tiku_collects").where({_id:wx.cloud.database().RegExp({regexp:this.data.subject._id,options:"i"})}).get().then((function(e){console.log("😄嘻嘻哈哈",e),console.log("😄嘻嘻哈哈",e);var o=e.data[0],a=t.data.subject;console.log("😄嘻嘻哈哈",o),console.log("😄嘻嘻哈哈",a),(a=o)?t.setData({shoucang:!0}):t.setData({shoucang:!1})})))}});
},{isPage:true,isComponent:true,currentFile:'pages/sousuo/sousuo.js'});require("pages/sousuo/sousuo.js");$gwx_XC_20=function(_,_v,_n,_p,_s,_wp,_wl,$gwn,$gwl,$gwh,wh,$gstack,$gwrt,gra,grb,TestTest,wfor,_ca,_da,_r,_rz,_o,_oz,_1,_1z,_2,_2z,_m,_mz,nv_getDate,nv_getRegExp,nv_console,nv_parseInt,nv_parseFloat,nv_isNaN,nv_isFinite,nv_decodeURI,nv_decodeURIComponent,nv_encodeURI,nv_encodeURIComponent,$gdc,nv_JSON,_af,_gv,_ai,_grp,_gd,_gapi,$ixc,_ic,_w,_ev,_tsd){return function(path,global){
if(typeof global==='undefined'){if (typeof __GWX_GLOBAL__==='undefined')global={};else global=__GWX_GLOBAL__;}if(typeof __WXML_GLOBAL__ === 'undefined') {__WXML_GLOBAL__={};
}__WXML_GLOBAL__.modules = __WXML_GLOBAL__.modules || {};
var e_={}
if(typeof(global.entrys)==='undefined')global.entrys={};e_=global.entrys;
var d_={}
if(typeof(global.defines)==='undefined')global.defines={};d_=global.defines;
var f_={}
if(typeof(global.modules)==='undefined')global.modules={};f_=global.modules || {};
var p_={}
__WXML_GLOBAL__.ops_cached = __WXML_GLOBAL__.ops_cached || {}
__WXML_GLOBAL__.ops_set = __WXML_GLOBAL__.ops_set || {};
__WXML_GLOBAL__.ops_init = __WXML_GLOBAL__.ops_init || {};
var z=__WXML_GLOBAL__.ops_set.$gwx_XC_20 || [];
function gz$gwx_XC_20_1(){
if( __WXML_GLOBAL__.ops_cached.$gwx_XC_20_1)return __WXML_GLOBAL__.ops_cached.$gwx_XC_20_1
__WXML_GLOBAL__.ops_cached.$gwx_XC_20_1=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
Z([[2,'=='],[[6],[[6],[[7],[3,'subject']],[3,'answer']],[3,'length']],[1,1]])
Z([3,'selectClick'])
Z([[6],[[7],[3,'subject']],[3,'optionC']])
Z([[6],[[7],[3,'subject']],[3,'optionD']])
Z(z[1])
Z(z[2])
Z(z[3])
Z([[7],[3,'showAnswer']])
})(__WXML_GLOBAL__.ops_cached.$gwx_XC_20_1);return __WXML_GLOBAL__.ops_cached.$gwx_XC_20_1
}
__WXML_GLOBAL__.ops_set.$gwx_XC_20=z;
__WXML_GLOBAL__.ops_init.$gwx_XC_20=true;
var x=['./pages/test/test.wxml'];d_[x[0]]={}
var m0=function(e,s,r,gg){
var z=gz$gwx_XC_20_1()
var t5D=_v()
_(r,t5D)
if(_oz(z,0,e,s,gg)){t5D.wxVkey=1
var b7D=_n('radio-group')
_rz(z,b7D,'bindchange',1,e,s,gg)
var o8D=_v()
_(b7D,o8D)
if(_oz(z,2,e,s,gg)){o8D.wxVkey=1
}
var x9D=_v()
_(b7D,x9D)
if(_oz(z,3,e,s,gg)){x9D.wxVkey=1
}
o8D.wxXCkey=1
x9D.wxXCkey=1
_(t5D,b7D)
}
else{t5D.wxVkey=2
var o0D=_n('checkbox-group')
_rz(z,o0D,'bindchange',4,e,s,gg)
var fAE=_v()
_(o0D,fAE)
if(_oz(z,5,e,s,gg)){fAE.wxVkey=1
}
var cBE=_v()
_(o0D,cBE)
if(_oz(z,6,e,s,gg)){cBE.wxVkey=1
}
fAE.wxXCkey=1
cBE.wxXCkey=1
_(t5D,o0D)
}
var e6D=_v()
_(r,e6D)
if(_oz(z,7,e,s,gg)){e6D.wxVkey=1
}
t5D.wxXCkey=1
e6D.wxXCkey=1
return r
}
e_[x[0]]={f:m0,j:[],i:[],ti:[],ic:[]}
if(path&&e_[path]){
return function(env,dd,global){$gwxc=0;var root={"tag":"wx-page"};root.children=[]
;g="$gwx_XC_20";var main=e_[path].f
if (typeof global==="undefined")global={};global.f=$gdc(f_[path],"",1);
try{
main(env,{},root,global);
_tsd(root)
}catch(err){
console.log(err)
}
;g="";
return root;
}
}
}
}(__g.a,__g.b,__g.c,__g.d,__g.e,__g.f,__g.g,__g.h,__g.i,__g.j,__g.k,__g.l,__g.m,__g.n,__g.o,__g.p,__g.q,__g.r,__g.s,__g.t,__g.u,__g.v,__g.w,__g.x,__g.y,__g.z,__g.A,__g.B,__g.C,__g.D,__g.E,__g.F,__g.G,__g.H,__g.I,__g.J,__g.K,__g.L,__g.M,__g.N,__g.O,__g.P,__g.Q,__g.R,__g.S,__g.T,__g.U,__g.V,__g.W,__g.X,__g.Y,__g.Z,__g.aa);if(__vd_version_info__.delayedGwx||false)$gwx_XC_20();	if (__vd_version_info__.delayedGwx) __wxAppCode__['pages/test/test.wxml'] = [$gwx_XC_20, './pages/test/test.wxml'];else __wxAppCode__['pages/test/test.wxml'] = $gwx_XC_20( './pages/test/test.wxml' );
	;__wxRoute = "pages/test/test";__wxRouteBegin = true;__wxAppCurrentFile__="pages/test/test.js";define("pages/test/test.js",function(require,module,exports,window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){
"use strict";var t=getApp(),e=wx.cloud.database(),a=e.collection("tiku_exams"),s=require("../../utils/util"),o=e.command,i=[];Page({data:{hour:"00",minute:"00",second:"00",showScore:!1,testTime:0,errorOptions:[],showAnswer:!1,percent:0,total:0,isSelect:!1,subject:null,userSelect:"",userScore:0,totalScore:0,totalError:0,current:1},onLoad:function(e){var o=this;this.time60(),console.log("",e),e.type1&&e.type2?(wx.setNavigationBarTitle({title:e.type2+"答题"}),a.where({type:e.type1,type2:e.type2}).get().then((function(t){console.log("",t);var e=(i=t.data)[0];console.log("",e),o.setData({subject:e,total:i.length}),o.setData({testId:s.formatTime(new Date)+o.data.subject.type+"考试"})}))):(wx.setNavigationBarTitle({title:"随机答题"}),a.aggregate().sample({size:t.globalData.randomNum}).end().then((function(t){console.log("",t);var e=(i=t.list)[0];o.setData({subject:e,total:i.length}),o.setData({testId:s.formatTime(new Date)+o.data.subject.type+"考试"})}))),t.globalData.userInfo&&t.globalData.userInfo.name||wx.showModal({title:"需要参加积分排名吗？",content:"只有授权登陆并注册用户后才可以参与积分排名，取消后本次答题不计入积分排行里",success:function(t){t.confirm&&wx.switchTab({url:"/pages/me/me"})}})},selectClick:function(t){console.log(t.detail.value),this.setData({userSelect:t.detail.value})},submit:function(){this.setData({showAnswer:!1});var t=this.data.userSelect;if(!t||t.length<1)wx.showToast({icon:"none",title:"请做选择"});else{var a=this.data.current;if(this.setData({percent:(a/i.length*100).toFixed(1)}),console.log("",t),console.log("",this.data.subject.answer),t instanceof Array&&(console.log(""),t=t.sort().toString()),this.data.subject.answer==t)console.log(""+a),this.setData({userScore:this.data.userScore+1});else{var s=this.data.subject;s.userSelect=t,this.data.errorOptions.push(s);var o={};Object.assign(o,s),delete o._id;var n=wx.getStorageSync("user")||{};o.nickName=n&&n.nickName?n.nickName:"未登陆用户",console.log("",o),o.testId=this.data.testId,e.collection("tiku_test_errors").add({data:o}).then((function(t){console.log("",t)})),console.log("",s)}if(a+1>i.length){var r=this.data.userScore;return console.log(""+r),console.log("",this.data.errorOptions),this.setData({totalScore:r,totalError:this.data.errorOptions.length,hideButton:!0}),void wx.showToast({icon:"none",title:"已经最后一道啦"})}var l=i[a];this.setData({userSelect:"",subject:l,current:a+1,isSelect:!1})}},seeError:function(){console.log(""),wx.switchTab({url:"/pages/errorList/errorList"})},addScore:function(a){t.globalData.userInfo&&t.globalData.userInfo.name&&e.collection("tiku_users").doc(t.globalData.openid).update({data:{score:o.inc(a)}}).then((function(t){wx.showToast({title:"积分生效"})}))},ok:function(){var t=this.data.userSelect;!t||t.length<1?wx.showToast({icon:"none",title:"请做选择"}):this.setData({showAnswer:!0})},testEnd:function(){var e=this,a=this.data.userSelect;!a||a.length<1?wx.showToast({icon:"none",title:"请做选择"}):(wx.showLoading({title:"提交中",mask:!0}),this.setData({showScore:!0,testTimeMin:this.data.testTimeMin,testTimeSec:this.data.testTimeSec}),this.addScore(this.data.totalScore),clearInterval(this.data.timeInterval),wx.cloud.database().collection("tiku_test_results").add({data:{faceImg:t.globalData.userInfo.avatarUrl,nickName:t.globalData.userInfo.nickName,testId:this.data.testId,time:this.data.testTimeMin+"分"+this.data.testTimeSec+"秒",totalError:this.data.totalError,total:this.data.total}}).then((function(t){wx.hideLoading({success:function(t){wx.showToast({title:"成功"}),wx.redirectTo({url:"/pages/test/testResult/testResult?totalError="+e.data.totalError+"&testTimeMin="+e.data.testTimeMin+"&testTimeSec="+e.data.testTimeSec+"&totalScore="+e.data.totalScore})}})})))},time60:function(){var t=this,e=new Date;e.setMinutes(e.getMinutes()+90);var a=s.formatTime(e);console.log(a);var o=setInterval((function(){var e=new Date(a)-new Date;t.setData({hour:parseInt(e/60/1e3/60),minute:parseInt(e/60/1e3)-60*parseInt(e/60/1e3/60),second:parseInt(e/1e3)-60*(parseInt(e/60/1e3)-60*parseInt(e/60/1e3/60))-60*parseInt(e/60/1e3/60)*60}),t.setData({testTime:t.data.testTime+1}),t.setData({testTime:t.data.testTime,testTimeMin:parseInt(t.data.testTime/60),testTimeSec:t.data.testTime-60*t.data.testTimeMin})}),1e3);this.setData({timeInterval:o})}});
},{isPage:true,isComponent:true,currentFile:'pages/test/test.js'});require("pages/test/test.js");$gwx_XC_21=function(_,_v,_n,_p,_s,_wp,_wl,$gwn,$gwl,$gwh,wh,$gstack,$gwrt,gra,grb,TestTest,wfor,_ca,_da,_r,_rz,_o,_oz,_1,_1z,_2,_2z,_m,_mz,nv_getDate,nv_getRegExp,nv_console,nv_parseInt,nv_parseFloat,nv_isNaN,nv_isFinite,nv_decodeURI,nv_decodeURIComponent,nv_encodeURI,nv_encodeURIComponent,$gdc,nv_JSON,_af,_gv,_ai,_grp,_gd,_gapi,$ixc,_ic,_w,_ev,_tsd){return function(path,global){
if(typeof global==='undefined'){if (typeof __GWX_GLOBAL__==='undefined')global={};else global=__GWX_GLOBAL__;}if(typeof __WXML_GLOBAL__ === 'undefined') {__WXML_GLOBAL__={};
}__WXML_GLOBAL__.modules = __WXML_GLOBAL__.modules || {};
var e_={}
if(typeof(global.entrys)==='undefined')global.entrys={};e_=global.entrys;
var d_={}
if(typeof(global.defines)==='undefined')global.defines={};d_=global.defines;
var f_={}
if(typeof(global.modules)==='undefined')global.modules={};f_=global.modules || {};
var p_={}
__WXML_GLOBAL__.ops_cached = __WXML_GLOBAL__.ops_cached || {}
__WXML_GLOBAL__.ops_set = __WXML_GLOBAL__.ops_set || {};
__WXML_GLOBAL__.ops_init = __WXML_GLOBAL__.ops_init || {};
var z=__WXML_GLOBAL__.ops_set.$gwx_XC_21 || [];
function gz$gwx_XC_21_1(){
if( __WXML_GLOBAL__.ops_cached.$gwx_XC_21_1)return __WXML_GLOBAL__.ops_cached.$gwx_XC_21_1
__WXML_GLOBAL__.ops_cached.$gwx_XC_21_1=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
Z([[2,'>'],[[7],[3,'totalError']],[1,0]])
})(__WXML_GLOBAL__.ops_cached.$gwx_XC_21_1);return __WXML_GLOBAL__.ops_cached.$gwx_XC_21_1
}
__WXML_GLOBAL__.ops_set.$gwx_XC_21=z;
__WXML_GLOBAL__.ops_init.$gwx_XC_21=true;
var x=['./pages/test/testResult/testResult.wxml'];d_[x[0]]={}
var m0=function(e,s,r,gg){
var z=gz$gwx_XC_21_1()
var oDE=_v()
_(r,oDE)
if(_oz(z,0,e,s,gg)){oDE.wxVkey=1
}
oDE.wxXCkey=1
return r
}
e_[x[0]]={f:m0,j:[],i:[],ti:[],ic:[]}
if(path&&e_[path]){
return function(env,dd,global){$gwxc=0;var root={"tag":"wx-page"};root.children=[]
;g="$gwx_XC_21";var main=e_[path].f
if (typeof global==="undefined")global={};global.f=$gdc(f_[path],"",1);
try{
main(env,{},root,global);
_tsd(root)
}catch(err){
console.log(err)
}
;g="";
return root;
}
}
}
}(__g.a,__g.b,__g.c,__g.d,__g.e,__g.f,__g.g,__g.h,__g.i,__g.j,__g.k,__g.l,__g.m,__g.n,__g.o,__g.p,__g.q,__g.r,__g.s,__g.t,__g.u,__g.v,__g.w,__g.x,__g.y,__g.z,__g.A,__g.B,__g.C,__g.D,__g.E,__g.F,__g.G,__g.H,__g.I,__g.J,__g.K,__g.L,__g.M,__g.N,__g.O,__g.P,__g.Q,__g.R,__g.S,__g.T,__g.U,__g.V,__g.W,__g.X,__g.Y,__g.Z,__g.aa);if(__vd_version_info__.delayedGwx||false)$gwx_XC_21();	if (__vd_version_info__.delayedGwx) __wxAppCode__['pages/test/testResult/testResult.wxml'] = [$gwx_XC_21, './pages/test/testResult/testResult.wxml'];else __wxAppCode__['pages/test/testResult/testResult.wxml'] = $gwx_XC_21( './pages/test/testResult/testResult.wxml' );
	;__wxRoute = "pages/test/testResult/testResult";__wxRouteBegin = true;__wxAppCurrentFile__="pages/test/testResult/testResult.js";define("pages/test/testResult/testResult.js",function(require,module,exports,window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){
"use strict";var t=require("../../../@babel/runtime/helpers/defineProperty");Page({data:{},onLoad:function(r){console.log(r),this.setData(t({totalScore:r.totalScore,totalError:r.totalError,testTimeMin:r.testTimeMin,testTimeSec:r.testTimeSec},"totalError",r.totalError))},seeError:function(){console.log(""),wx.switchTab({url:"/pages/errorList/errorList"})}});
},{isPage:true,isComponent:true,currentFile:'pages/test/testResult/testResult.js'});require("pages/test/testResult/testResult.js");$gwx_XC_22=function(_,_v,_n,_p,_s,_wp,_wl,$gwn,$gwl,$gwh,wh,$gstack,$gwrt,gra,grb,TestTest,wfor,_ca,_da,_r,_rz,_o,_oz,_1,_1z,_2,_2z,_m,_mz,nv_getDate,nv_getRegExp,nv_console,nv_parseInt,nv_parseFloat,nv_isNaN,nv_isFinite,nv_decodeURI,nv_decodeURIComponent,nv_encodeURI,nv_encodeURIComponent,$gdc,nv_JSON,_af,_gv,_ai,_grp,_gd,_gapi,$ixc,_ic,_w,_ev,_tsd){return function(path,global){
if(typeof global==='undefined'){if (typeof __GWX_GLOBAL__==='undefined')global={};else global=__GWX_GLOBAL__;}if(typeof __WXML_GLOBAL__ === 'undefined') {__WXML_GLOBAL__={};
}__WXML_GLOBAL__.modules = __WXML_GLOBAL__.modules || {};
var e_={}
if(typeof(global.entrys)==='undefined')global.entrys={};e_=global.entrys;
var d_={}
if(typeof(global.defines)==='undefined')global.defines={};d_=global.defines;
var f_={}
if(typeof(global.modules)==='undefined')global.modules={};f_=global.modules || {};
var p_={}
__WXML_GLOBAL__.ops_cached = __WXML_GLOBAL__.ops_cached || {}
__WXML_GLOBAL__.ops_set = __WXML_GLOBAL__.ops_set || {};
__WXML_GLOBAL__.ops_init = __WXML_GLOBAL__.ops_init || {};
var z=__WXML_GLOBAL__.ops_set.$gwx_XC_22 || [];
function gz$gwx_XC_22_1(){
if( __WXML_GLOBAL__.ops_cached.$gwx_XC_22_1)return __WXML_GLOBAL__.ops_cached.$gwx_XC_22_1
__WXML_GLOBAL__.ops_cached.$gwx_XC_22_1=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
Z([[2,'>'],[[7],[3,'total']],[1,0]])
Z([[6],[[7],[3,'subject']],[3,'optionC']])
Z([[6],[[7],[3,'subject']],[3,'optionD']])
Z([[6],[[7],[3,'subject']],[3,'explain']])
})(__WXML_GLOBAL__.ops_cached.$gwx_XC_22_1);return __WXML_GLOBAL__.ops_cached.$gwx_XC_22_1
}
__WXML_GLOBAL__.ops_set.$gwx_XC_22=z;
__WXML_GLOBAL__.ops_init.$gwx_XC_22=true;
var x=['./pages/testErrorQuestions/testErrorQuestions.wxml'];d_[x[0]]={}
var m0=function(e,s,r,gg){
var z=gz$gwx_XC_22_1()
var oFE=_v()
_(r,oFE)
if(_oz(z,0,e,s,gg)){oFE.wxVkey=1
var lGE=_n('view')
var aHE=_v()
_(lGE,aHE)
if(_oz(z,1,e,s,gg)){aHE.wxVkey=1
}
var tIE=_v()
_(lGE,tIE)
if(_oz(z,2,e,s,gg)){tIE.wxVkey=1
}
var eJE=_v()
_(lGE,eJE)
if(_oz(z,3,e,s,gg)){eJE.wxVkey=1
}
aHE.wxXCkey=1
tIE.wxXCkey=1
eJE.wxXCkey=1
_(oFE,lGE)
}
else{oFE.wxVkey=2
}
oFE.wxXCkey=1
return r
}
e_[x[0]]={f:m0,j:[],i:[],ti:[],ic:[]}
if(path&&e_[path]){
return function(env,dd,global){$gwxc=0;var root={"tag":"wx-page"};root.children=[]
;g="$gwx_XC_22";var main=e_[path].f
if (typeof global==="undefined")global={};global.f=$gdc(f_[path],"",1);
try{
main(env,{},root,global);
_tsd(root)
}catch(err){
console.log(err)
}
;g="";
return root;
}
}
}
}(__g.a,__g.b,__g.c,__g.d,__g.e,__g.f,__g.g,__g.h,__g.i,__g.j,__g.k,__g.l,__g.m,__g.n,__g.o,__g.p,__g.q,__g.r,__g.s,__g.t,__g.u,__g.v,__g.w,__g.x,__g.y,__g.z,__g.A,__g.B,__g.C,__g.D,__g.E,__g.F,__g.G,__g.H,__g.I,__g.J,__g.K,__g.L,__g.M,__g.N,__g.O,__g.P,__g.Q,__g.R,__g.S,__g.T,__g.U,__g.V,__g.W,__g.X,__g.Y,__g.Z,__g.aa);if(__vd_version_info__.delayedGwx||false)$gwx_XC_22();	if (__vd_version_info__.delayedGwx) __wxAppCode__['pages/testErrorQuestions/testErrorQuestions.wxml'] = [$gwx_XC_22, './pages/testErrorQuestions/testErrorQuestions.wxml'];else __wxAppCode__['pages/testErrorQuestions/testErrorQuestions.wxml'] = $gwx_XC_22( './pages/testErrorQuestions/testErrorQuestions.wxml' );
	;__wxRoute = "pages/testErrorQuestions/testErrorQuestions";__wxRouteBegin = true;__wxAppCurrentFile__="pages/testErrorQuestions/testErrorQuestions.js";define("pages/testErrorQuestions/testErrorQuestions.js",function(require,module,exports,window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){
"use strict";getApp();var t=wx.cloud.database(),e=null,o=[];Page({data:{total:0,current:0},onLoad:function(t){e=t,this.getData()},getData:function(){var r=this;t.collection("tiku_test_errors").where({testId:e.type1}).get().then((function(t){o=t.data,console.log("",o);var e=o[0];console.log("",e),r.setData({current:0,subject:e,total:o.length})}))},pre:function(){var t=this.data.current;t<=0?wx.showToast({icon:"error",title:"已是第一道"}):(t-=1,this.setData({current:t,subject:o[t]}))},next:function(){var t=this.data.current;t>=o.length-1?wx.showToast({icon:"error",title:"已是最后一道"}):(t+=1,this.setData({current:t,subject:o[t]}))},removeError:function(e){var o=this,r=e.currentTarget.dataset.subject._id;t.collection("tiku_test_errors").doc(r).remove().then((function(t){console.log("",t),t.stats&&t.stats.removed>0?(wx.showToast({title:"删除成功"}),o.getData()):wx.showToast({icon:"error",title:"网络不给力"})}))}});
},{isPage:true,isComponent:true,currentFile:'pages/testErrorQuestions/testErrorQuestions.js'});require("pages/testErrorQuestions/testErrorQuestions.js");$gwx_XC_23=function(_,_v,_n,_p,_s,_wp,_wl,$gwn,$gwl,$gwh,wh,$gstack,$gwrt,gra,grb,TestTest,wfor,_ca,_da,_r,_rz,_o,_oz,_1,_1z,_2,_2z,_m,_mz,nv_getDate,nv_getRegExp,nv_console,nv_parseInt,nv_parseFloat,nv_isNaN,nv_isFinite,nv_decodeURI,nv_decodeURIComponent,nv_encodeURI,nv_encodeURIComponent,$gdc,nv_JSON,_af,_gv,_ai,_grp,_gd,_gapi,$ixc,_ic,_w,_ev,_tsd){return function(path,global){
if(typeof global==='undefined'){if (typeof __GWX_GLOBAL__==='undefined')global={};else global=__GWX_GLOBAL__;}if(typeof __WXML_GLOBAL__ === 'undefined') {__WXML_GLOBAL__={};
}__WXML_GLOBAL__.modules = __WXML_GLOBAL__.modules || {};
var e_={}
if(typeof(global.entrys)==='undefined')global.entrys={};e_=global.entrys;
var d_={}
if(typeof(global.defines)==='undefined')global.defines={};d_=global.defines;
var f_={}
if(typeof(global.modules)==='undefined')global.modules={};f_=global.modules || {};
var p_={}
__WXML_GLOBAL__.ops_cached = __WXML_GLOBAL__.ops_cached || {}
__WXML_GLOBAL__.ops_set = __WXML_GLOBAL__.ops_set || {};
__WXML_GLOBAL__.ops_init = __WXML_GLOBAL__.ops_init || {};
var z=__WXML_GLOBAL__.ops_set.$gwx_XC_23 || [];
function gz$gwx_XC_23_1(){
if( __WXML_GLOBAL__.ops_cached.$gwx_XC_23_1)return __WXML_GLOBAL__.ops_cached.$gwx_XC_23_1
__WXML_GLOBAL__.ops_cached.$gwx_XC_23_1=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
})(__WXML_GLOBAL__.ops_cached.$gwx_XC_23_1);return __WXML_GLOBAL__.ops_cached.$gwx_XC_23_1
}
__WXML_GLOBAL__.ops_set.$gwx_XC_23=z;
__WXML_GLOBAL__.ops_init.$gwx_XC_23=true;
var x=['./pages/testErrorTypeList/testErrorTypeList.wxml'];d_[x[0]]={}
var m0=function(e,s,r,gg){
var z=gz$gwx_XC_23_1()
return r
}
e_[x[0]]={f:m0,j:[],i:[],ti:[],ic:[]}
if(path&&e_[path]){
return function(env,dd,global){$gwxc=0;var root={"tag":"wx-page"};root.children=[]
;g="$gwx_XC_23";var main=e_[path].f
if (typeof global==="undefined")global={};global.f=$gdc(f_[path],"",1);
try{
main(env,{},root,global);
_tsd(root)
}catch(err){
console.log(err)
}
;g="";
return root;
}
}
}
}(__g.a,__g.b,__g.c,__g.d,__g.e,__g.f,__g.g,__g.h,__g.i,__g.j,__g.k,__g.l,__g.m,__g.n,__g.o,__g.p,__g.q,__g.r,__g.s,__g.t,__g.u,__g.v,__g.w,__g.x,__g.y,__g.z,__g.A,__g.B,__g.C,__g.D,__g.E,__g.F,__g.G,__g.H,__g.I,__g.J,__g.K,__g.L,__g.M,__g.N,__g.O,__g.P,__g.Q,__g.R,__g.S,__g.T,__g.U,__g.V,__g.W,__g.X,__g.Y,__g.Z,__g.aa);if(__vd_version_info__.delayedGwx||false)$gwx_XC_23();	if (__vd_version_info__.delayedGwx) __wxAppCode__['pages/testErrorTypeList/testErrorTypeList.wxml'] = [$gwx_XC_23, './pages/testErrorTypeList/testErrorTypeList.wxml'];else __wxAppCode__['pages/testErrorTypeList/testErrorTypeList.wxml'] = $gwx_XC_23( './pages/testErrorTypeList/testErrorTypeList.wxml' );
	;__wxRoute = "pages/testErrorTypeList/testErrorTypeList";__wxRouteBegin = true;__wxAppCurrentFile__="pages/testErrorTypeList/testErrorTypeList.js";define("pages/testErrorTypeList/testErrorTypeList.js",function(require,module,exports,window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){
"use strict";var t=wx.cloud.database(),e=getApp();Page({onLoad:function(t){var a=this;wx.cloud.database().collection("tiku_test_results").where({testId:t.type,_openid:e.globalData.openid}).get().then((function(t){console.log(t),a.setData({testResult:t.data[0]})})),wx.setNavigationBarTitle({title:t.type+"错题"}),this.setData({type:t.type})},onShow:function(){var e=this;console.log("",this.data.type);var a=t.command.aggregate;t.collection("tiku_test_errors").aggregate().match({testId:this.data.type}).group({_id:"$type2",num:a.sum(1)}).end().then((function(t){console.log("",t),e.setData({list:t.list})}))},goDetail:function(t){var e=this.data.type,a=t.currentTarget.dataset.type2;wx.navigateTo({url:"/pages/testErrorQuestions/testErrorQuestions?type1="+e+"&type2="+a})}});
},{isPage:true,isComponent:true,currentFile:'pages/testErrorTypeList/testErrorTypeList.js'});require("pages/testErrorTypeList/testErrorTypeList.js");$gwx_XC_24=function(_,_v,_n,_p,_s,_wp,_wl,$gwn,$gwl,$gwh,wh,$gstack,$gwrt,gra,grb,TestTest,wfor,_ca,_da,_r,_rz,_o,_oz,_1,_1z,_2,_2z,_m,_mz,nv_getDate,nv_getRegExp,nv_console,nv_parseInt,nv_parseFloat,nv_isNaN,nv_isFinite,nv_decodeURI,nv_decodeURIComponent,nv_encodeURI,nv_encodeURIComponent,$gdc,nv_JSON,_af,_gv,_ai,_grp,_gd,_gapi,$ixc,_ic,_w,_ev,_tsd){return function(path,global){
if(typeof global==='undefined'){if (typeof __GWX_GLOBAL__==='undefined')global={};else global=__GWX_GLOBAL__;}if(typeof __WXML_GLOBAL__ === 'undefined') {__WXML_GLOBAL__={};
}__WXML_GLOBAL__.modules = __WXML_GLOBAL__.modules || {};
var e_={}
if(typeof(global.entrys)==='undefined')global.entrys={};e_=global.entrys;
var d_={}
if(typeof(global.defines)==='undefined')global.defines={};d_=global.defines;
var f_={}
if(typeof(global.modules)==='undefined')global.modules={};f_=global.modules || {};
var p_={}
__WXML_GLOBAL__.ops_cached = __WXML_GLOBAL__.ops_cached || {}
__WXML_GLOBAL__.ops_set = __WXML_GLOBAL__.ops_set || {};
__WXML_GLOBAL__.ops_init = __WXML_GLOBAL__.ops_init || {};
var z=__WXML_GLOBAL__.ops_set.$gwx_XC_24 || [];
function gz$gwx_XC_24_1(){
if( __WXML_GLOBAL__.ops_cached.$gwx_XC_24_1)return __WXML_GLOBAL__.ops_cached.$gwx_XC_24_1
__WXML_GLOBAL__.ops_cached.$gwx_XC_24_1=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
})(__WXML_GLOBAL__.ops_cached.$gwx_XC_24_1);return __WXML_GLOBAL__.ops_cached.$gwx_XC_24_1
}
__WXML_GLOBAL__.ops_set.$gwx_XC_24=z;
__WXML_GLOBAL__.ops_init.$gwx_XC_24=true;
var x=['./pages/zxxx_11/zxxx_11.wxml'];d_[x[0]]={}
var m0=function(e,s,r,gg){
var z=gz$gwx_XC_24_1()
return r
}
e_[x[0]]={f:m0,j:[],i:[],ti:[],ic:[]}
if(path&&e_[path]){
return function(env,dd,global){$gwxc=0;var root={"tag":"wx-page"};root.children=[]
;g="$gwx_XC_24";var main=e_[path].f
if (typeof global==="undefined")global={};global.f=$gdc(f_[path],"",1);
try{
main(env,{},root,global);
_tsd(root)
}catch(err){
console.log(err)
}
;g="";
return root;
}
}
}
}(__g.a,__g.b,__g.c,__g.d,__g.e,__g.f,__g.g,__g.h,__g.i,__g.j,__g.k,__g.l,__g.m,__g.n,__g.o,__g.p,__g.q,__g.r,__g.s,__g.t,__g.u,__g.v,__g.w,__g.x,__g.y,__g.z,__g.A,__g.B,__g.C,__g.D,__g.E,__g.F,__g.G,__g.H,__g.I,__g.J,__g.K,__g.L,__g.M,__g.N,__g.O,__g.P,__g.Q,__g.R,__g.S,__g.T,__g.U,__g.V,__g.W,__g.X,__g.Y,__g.Z,__g.aa);if(__vd_version_info__.delayedGwx||false)$gwx_XC_24();	if (__vd_version_info__.delayedGwx) __wxAppCode__['pages/zxxx_11/zxxx_11.wxml'] = [$gwx_XC_24, './pages/zxxx_11/zxxx_11.wxml'];else __wxAppCode__['pages/zxxx_11/zxxx_11.wxml'] = $gwx_XC_24( './pages/zxxx_11/zxxx_11.wxml' );
	;__wxRoute = "pages/zxxx_11/zxxx_11";__wxRouteBegin = true;__wxAppCurrentFile__="pages/zxxx_11/zxxx_11.js";define("pages/zxxx_11/zxxx_11.js",function(require,module,exports,window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){
"use strict";Page({data:{},onLoad:function(o){console.log(o.id),this.tozxxx_11(o.id)},tozxxx_11:function(o){var t=this;wx.cloud.database().collection("zxxx_").doc(o).get({success:function(o){console.log(o),t.setData({banner:o.data})}})}});
},{isPage:true,isComponent:true,currentFile:'pages/zxxx_11/zxxx_11.js'});require("pages/zxxx_11/zxxx_11.js");