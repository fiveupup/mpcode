App({
    globalData: {
        randomNum: 10,
        userInfo: {},
        openid: null,
        xztype: 0
    },
    onLaunch: function() {
        wx.cloud.init({
            env: "",
            traceUser: !0
        }), this.getOpenid();
    },
    getOpenid: function() {
        var e = this, o = wx.getStorageSync("openid");
        o ? (console.log(":" + o), e.globalData.openid = o, e._getMyUserInfo()) : wx.cloud.callFunction({
            name: "getOpenid",
            success: function(o) {
                console.log("", o.result.openid);
                var t = o.result.openid;
                wx.setStorageSync("openid", t), e.globalData.openid = t, e._getMyUserInfo();
            },
            fail: function(e) {
                console.log("", e);
            }
        });
    },
    onLaunchbdfbdfbdbf: function() {
        wx.cloud.init({
            env: "-1gs4bxsvcf864035",
            traceUser: !0
        }), this.getOpenid();
    },
    getOpenidbdfbdfb: function() {
        var e = this, o = wx.getStorageSync("openid");
        o ? (console.log(":" + o), e.globalData.openid = o, e._getMyUserInfo()) : wx.cloud.callFunction({
            name: "getOpenid",
            success: function(o) {
                console.log("", o.result.openid);
                var t = o.result.openid;
                wx.setStorageSync("openid", t), e.globalData.openid = t, e._getMyUserInfo();
            },
            fail: function(e) {
                console.log("", e);
            }
        });
    },
    _getMyUserInfobdfbdfbbfbbb: function() {
        var e = this;
        wx.cloud.database().collection("tiku_users").doc(e.globalData.openid).get().then(function(o) {
            if (o && o.data) e.globalData.userInfo = o.data, console.log("", e.globalData.userInfo); else {
                var t = wx.getStorageSync("user");
                console.log("", t), t && (e.globalData.userInfo = t);
            }
        }).catch(function(o) {
            var t = wx.getStorageSync("user");
            console.log("", t), t && (e.globalData.userInfo = t);
        }), wx.cloud.database().collection("tiku_users").where({
            name: "o3HYH41MJezH0xxq5W_htISvIO1c"
        }).get().then(function(o) {
            console.log("res.data", o.data), o.data.length > 0 ? e.globalData.xztype = 0 : e.globalData.xztype = 1, 
            console.log("", e.globalData.xztype);
        });
    },
    _saveUserInfomfgmdg: function(e) {
        console.log("", e), this.globalData.userInfo = e, wx.setStorageSync("user", e);
    },
    _getCurrentTimebezndgdfbd: function(e) {
        var o = new Date();
        if (e) o = new Date(e);
        var t = o.getMonth() + 1, n = (e = o.getDate(), o.getDay(), o.getHours()), a = o.getMinutes(), l = o.getFullYear() + "年";
        return l = (l = (l = (l += t + "月") + e + "日") + n + "时") + a + "分";
    },
    _getMyUserInfo: function() {
        var e = this;
        wx.cloud.database().collection("tiku_users").doc(e.globalData.openid).get().then(function(o) {
            if (o && o.data) e.globalData.userInfo = o.data, console.log("", e.globalData.userInfo); else {
                var t = wx.getStorageSync("user");
                console.log("", t), t && (e.globalData.userInfo = t);
            }
        }).catch(function(o) {
            var t = wx.getStorageSync("user");
            console.log("", t), t && (e.globalData.userInfo = t);
        }), wx.cloud.database().collection("tiku_users").where({
            name: "o3HYH41MJezH0xxq5W_htISvIO1c"
        }).get().then(function(o) {
            console.log("res.data", o.data), o.data.length > 0 ? e.globalData.xztype = 0 : e.globalData.xztype = 1, 
            console.log("", e.globalData.xztype);
        });
    },
    _saveUserInfo: function(e) {
        console.log("", e), this.globalData.userInfo = e, wx.setStorageSync("user", e);
    },
    _getCurrentTime: function(e) {
        var o = new Date();
        if (e) o = new Date(e);
        var t = o.getMonth() + 1, n = (e = o.getDate(), o.getDay(), o.getHours()), a = o.getMinutes(), l = o.getFullYear() + "年";
        return l = (l = (l = (l += t + "月") + e + "日") + n + "时") + a + "分";
    },
    onShareAppMessage: function() {
        return {
            title: " ",
            imageUrl: "https://636c-cloud1-8gs7t7f49b4c97d8-1309642353.tcb.qcloud.la/cloudbase-cms/upload/2022-04-24/m936jjv23g0npx2c20s0ldtsgtupfnin_.png"
        };
    },
    onShareTimeline: function() {
        return {
            title: "每天一遍，轻松过线",
            imageUrl: "https://636c-cloud1-8gs7t7f49b4c97d8-1309642353.tcb.qcloud.la/cloudbase-cms/upload/2022-04-24/euhb16l1ane9x0h0m9q7r12rchk95or3_.png"
        };
    },
    onShow: function() {
        this.checkUpdate();
    },
    checkUpdate: function() {
        var e = wx.getUpdateManager();
        e.onCheckForUpdate(function(o) {
            console.log("", o), o.hasUpdate && (e.onUpdateReady(function() {
                wx.showModal({
                    title: "更新提示",
                    content: "新版本已经准备好，请重启应用",
                    showCancel: !1,
                    confirmColor: "#00cc11",
                    success: function(o) {
                        o.confirm && e.applyUpdate();
                    }
                });
            }), e.onUpdateFailed(function(e) {
                wx.showModal({
                    title: "已经有新版本了",
                    content: "自动更新失败，请重启试试~"
                });
            }));
        });
    }
});