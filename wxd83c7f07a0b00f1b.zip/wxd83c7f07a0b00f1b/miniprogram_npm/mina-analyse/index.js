var t, e, n = require("../../@babel/runtime/helpers/typeof");

module.exports = (t = {}, e = function(e, r) {
    if (!t[e]) return require(r);
    if (!t[e].status) {
        var o = t[e].m;
        o._exports = o._tempexports;
        var i = Object.getOwnPropertyDescriptor(o, "exports");
        i && i.configurable && Object.defineProperty(o, "exports", {
            set: function(t) {
                "object" === n(t) && t !== o._exports && (o._exports.__proto__ = t.__proto__, Object.keys(t).forEach(function(e) {
                    o._exports[e] = t[e];
                })), o._tempexports = t;
            },
            get: function() {
                return o._tempexports;
            }
        }), t[e].status = 1, t[e].func(t[e].req, o, o.exports);
    }
    return t[e].m.exports;
}, function(e, n, r) {
    t[e] = {
        status: 0,
        func: n,
        req: r,
        m: {
            exports: {},
            _tempexports: {}
        }
    };
}(1700120110430, function(t, e, r) {
    var o, i;
    o = window, i = function() {
        return function(t) {
            var e = {};
            function r(n) {
                if (e[n]) return e[n].exports;
                var o = e[n] = {
                    i: n,
                    l: !1,
                    exports: {}
                };
                return t[n].call(o.exports, o, o.exports, r), o.l = !0, o.exports;
            }
            return r.m = t, r.c = e, r.d = function(t, e, n) {
                r.o(t, e) || Object.defineProperty(t, e, {
                    enumerable: !0,
                    get: n
                });
            }, r.r = function(t) {
                "undefined" != typeof Symbol && Symbol.toStringTag && Object.defineProperty(t, Symbol.toStringTag, {
                    value: "Module"
                }), Object.defineProperty(t, "__esModule", {
                    value: !0
                });
            }, r.t = function(t, e) {
                if (1 & e && (t = r(t)), 8 & e) return t;
                if (4 & e && "object" == n(t) && t && t.__esModule) return t;
                var o = Object.create(null);
                if (r.r(o), Object.defineProperty(o, "default", {
                    enumerable: !0,
                    value: t
                }), 2 & e && "string" != typeof t) for (var i in t) r.d(o, i, function(e) {
                    return t[e];
                }.bind(null, i));
                return o;
            }, r.n = function(t) {
                var e = t && t.__esModule ? function() {
                    return t.default;
                } : function() {
                    return t;
                };
                return r.d(e, "a", e), e;
            }, r.o = function(t, e) {
                return Object.prototype.hasOwnProperty.call(t, e);
            }, r.p = "", r(r.s = 0);
        }([ function(t, e, n) {
            Object.defineProperty(e, "__esModule", {
                value: !0
            }), e.init = function(t) {
                if (!t) throw new Error("init miss config");
                if (!t.name) throw new Error("init miss config.name");
                if (!t.id) throw new Error("init miss config.id: UA-xxx-x");
                if (!t.version) throw new Error("init miss config.version");
                return t.enableScreenView && (f = t.enableScreenView), c = r.GoogleAnalytics.getInstance().setAppName(t.name).setAppVersion(t.version).newTracker(t.id), 
                t.proxy && c.setTrackerServer(t.proxy), c;
            }, e.getTracker = function() {
                return c;
            }, e.setUid = function(t) {
                if (!c) return console.warn("setUid: tracker not inited");
                t && c.set("&uid", t);
            }, e.isExternal = g, e.screenView = m, e.event = function(t, e, n) {
                var r = arguments.length > 3 && void 0 !== arguments[3] ? arguments[3] : [], o = arguments.length > 4 && void 0 !== arguments[4] ? arguments[4] : [];
                if (!c) return console.warn("report: tracker not inited");
                try {
                    var u = new a.EventBuilder().setCategory(t).setAction(e).setLabel(n);
                    r.forEach(function(t) {
                        u.setCustomDimension(t.index, t.value);
                    }), o.forEach(function(t) {
                        u.setCustomMetric(t.index, t.value);
                    });
                    var p = (0, s.getCurrentPage)();
                    return p && (0, i.default)(u, p.gaOptions || {}), u;
                } catch (t) {
                    console.error(t);
                }
            }, e.report = function(t, e, n) {
                if (!c) return console.warn("report: tracker not inited");
                try {
                    if (e) {
                        var r = function(t) {
                            var e = [];
                            for (var n in t) t.hasOwnProperty(n) && e.push(t[n]);
                            return e;
                        }(e).join("_"), o = new a.EventBuilder().setCategory(t).setAction("click").setValue(1).setLabel(r).build(), u = (0, 
                        s.getCurrentPage)();
                        u && (0, i.default)(o, u.gaOptions || {}), c.send(o);
                    }
                    !n && wx.reportAnalytics && wx.reportAnalytics(t, e || {});
                } catch (t) {
                    console.error(t);
                }
            }, e.GA = void 0;
            var r = function(t) {
                if (t && t.__esModule) return t;
                var e = {};
                if (null != t) for (var n in t) if (Object.prototype.hasOwnProperty.call(t, n)) {
                    var r = Object.defineProperty && Object.getOwnPropertyDescriptor ? Object.getOwnPropertyDescriptor(t, n) : {};
                    r.get || r.set ? Object.defineProperty(e, n, r) : e[n] = t[n];
                }
                return e.default = t, e;
            }(n(1)), o = u(n(2)), i = u(n(4)), s = n(5);
            function u(t) {
                return t && t.__esModule ? t : {
                    default: t
                };
            }
            var c, a = r.HitBuilders, p = null, h = "", f = !1;
            function l(t) {
                if (!c) return console.warn("onPageLoad: tracker not inited");
                try {
                    var e = (0, s.getCurrentPage)();
                    if (!e) return console.warn("onPageLoad: page not found");
                    var n = h;
                    t || (t = e.options || {});
                    var r = "", u = g(), a = (f = {}, p && (p.scene && (f.scene = p.scene), p.referrerInfo.appid && (f.appid = p.referrerInfo.appid)), 
                    p = null, f);
                    t.scene && (e.options = t = (0, s.decodeScene)(t.scene)), t.f && (a.f = t.f), u ? r = "external_channel" : n ? (a = (0, 
                    i.default)({}, (0, o.default)(n, "options", {}), a), r = n.route) : r = "unknow", 
                    r = r + "?" + (0, s.queryString)(a), h = e, e.gaOptions || (e.gaOptions = {}), e.gaOptions.referer || (e.gaOptions.referer = r);
                } catch (t) {
                    console.error(t);
                }
                var f;
            }
            function d() {
                return !!f && ("function" == typeof f ? f((0, s.getCurrentPage)()) : !!f);
            }
            var y = r;
            function g() {
                return !!(0, o.default)(p, "scene", !1);
            }
            function m(t, e) {
                if (!c) return console.warn("screenView: tracker not inited");
                try {
                    var n = getCurrentPages(), r = n[n.length - 1];
                    if (!r) return console.warn("screenView: page not found");
                    var u = r.options;
                    e && (0, i.default)(u, e);
                    var p = (0, o.default)(t, "params", null);
                    p && (0, i.default)(u, p);
                    var h = (0, s.queryString)(u), f = r.route + (h ? "?" + h : "");
                    c.setScreenName(f);
                    var l = new a.ScreenViewBuilder(), d = (0, o.default)(t, "dimensions", null);
                    d && d.forEach(function(t, e) {
                        l = l.setCustomDimension(e + 1, t);
                    });
                    var y = l.build();
                    (0, i.default)(y, r.gaOptions || {}), c.send(y);
                } catch (t) {
                    console.error(t);
                }
            }
            e.GA = y;
            var v = App;
            App.nocode || (App = function(t) {
                var e = t.onLaunch, n = t.onShow;
                return t.onLaunch = function(t) {
                    !function(t) {
                        if (!c) return console.warn("onAppLaunch: tracker not inited");
                        if (!t) return console.warn("onAppLaunch: miss options");
                        if (!t.scene) return console.warn("onAppLaunch: launch options miss scene");
                        try {
                            var e = r.CampaignParams.buildFromWeappScene(t.scene).toUrl();
                            c.setCampaignParamsOnNextHit(e);
                        } catch (t) {
                            console.error(t);
                        }
                    }(t), e && e.call(this, t || {});
                }, t.onShow = function(t) {
                    !function(t) {
                        c ? t ? p = t : console.warn("onAppShow: miss options") : console.warn("onAppShow: tracker not inited");
                    }(t), n && n.call(this, t || {});
                }, v(t);
            }, App.nocode = "tech");
            var _ = Page;
            Page.nocode || (Page = function(t) {
                var e = t.onLoad, n = t.onShow;
                return t.onLoad = function(t) {
                    l(t || {}), e && e.call(this, t || {});
                }, t.onShow = function(t) {
                    var e = (0, s.getCurrentPage)();
                    e && (h = e), d() && m(), n && n.call(this, t || {});
                }, _(t);
            }, Page.nocode = "tech");
            var x = Component;
            Component.nocode || (Component = function(t) {
                var e = (0, o.default)(t, "methods.onLoad", null), n = (0, o.default)(t, "methods.onShow", null);
                return e && (t.methods.onLoad = function(t) {
                    l(t), e && e.call(this, t || {});
                }), n && (t.methods.onShow = function(t) {
                    d() && m(), n && n.call(this, t || {});
                }), x.call(this, t);
            }, Component.nocode = "tech");
        }, function(t, e) {
            function r(t) {
                this.app = t, this.systemInfo = v(), this.trackers = [], this.appName = "Mini Program", 
                this.appVersion = "unknow", this.log = !0;
                var e = wx.getStorageSync("_ga_cid") || !1;
                e || (e = "xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx".replace(/[xy]/g, function(t) {
                    var e = 16 * Math.random() | 0;
                    return ("x" == t ? e : 3 & e | 8).toString(16);
                }), wx.setStorageSync("_ga_cid", e)), this.cid = e, this.userAgent = function(t) {
                    var e = t.system.toLowerCase().indexOf("android") > -1, n = !e && -1 == t.model.toLowerCase().indexOf("iphone");
                    return e ? "Mozilla/5.0 (Linux; U; " + t.system + "; " + t.model + " Build/000000) AppleWebKit/537.36 (KHTML, like Gecko)Version/4.0 Chrome/49.0.0.0 Mobile Safari/537.36 MicroMessenger/" + t.version : n ? "Mozilla/5.0 (iPad; CPU OS " + t.system.replace(/^.*?([0-9.]+).*?$/, function(t, e) {
                        return e;
                    }).replace(/\./g, "_") + " like Mac OS X) AppleWebKit/534.46 (KHTML, like Gecko) Mobile/10A406 MicroMessenger/" + t.version : "Mozilla/5.0 (iPhone; CPU iPhone OS " + t.system.replace(/^.*?([0-9.]+).*?$/, function(t, e) {
                        return e;
                    }).replace(/\./g, "_") + " like Mac OS X) AppleWebKit/602.3.12 (KHTML, like Gecko) Mobile/14C92 MicroMessenger/" + t.version;
                }(this.systemInfo);
                var n = this.systemInfo.pixelRatio;
                this.sr = function(t, e, n) {
                    return !(n.system.toLowerCase().indexOf("android") > -1) && n.model.toLowerCase().indexOf("iphone"), 
                    [ t, e ].join("x");
                }(Math.round(this.systemInfo.windowWidth * n), Math.round(this.systemInfo.windowHeight * n), this.systemInfo), 
                this.vp = [ this.systemInfo.windowWidth, this.systemInfo.windowHeight ].map(function(t) {
                    return t;
                }).join("x");
            }
            function o(t) {
                return String(t).replace(/^&/, "");
            }
            function i(t, e) {
                this.ga = t, this.trackerServer = "https://www.google-analytics.com", this.hit = {
                    tid: e || "",
                    cd: ""
                }, this.next_hit = {}, this.sending = !1, this.send_queue = [];
            }
            function s() {
                this.hit = {
                    t: "screenview",
                    ni: 0
                }, this.custom_dimensions = [], this.custom_metrics = [], this.next_impression_index = 1, 
                this.impression_product_list = {}, this.next_product_index = 1, this.next_promotion_index = 1;
            }
            function u(t, e, n) {
                t.hit[e] == n && delete t.hit[e];
            }
            function c() {
                s.call(this), this.setHitType("screenview");
            }
            function a() {
                s.call(this), this.setHitType("event"), this.setAll({
                    ec: "",
                    ea: "",
                    el: "",
                    ev: 0
                });
            }
            function p() {
                s.call(this), this.setHitType("social"), this.setAll({
                    sn: "",
                    sa: "",
                    st: ""
                });
            }
            function h() {
                s.call(this), this.setHitType("exception"), this.setAll({
                    exd: "",
                    exf: 1
                });
            }
            function f() {
                s.call(this), this.setHitType("timing"), this.setAll({
                    utc: "",
                    utv: "",
                    utt: 0,
                    utl: ""
                });
            }
            function l() {
                this.hit = {};
            }
            function d() {
                this.hit = {};
            }
            function y(t) {
                this.hit = {
                    pa: t
                };
            }
            function g() {
                this.params = {}, this.params_map = {
                    utm_source: "cs",
                    utm_medium: "cm",
                    utm_term: "ck",
                    utm_content: "cc",
                    utm_campaign: "cn",
                    gclid: "gclid"
                };
            }
            function m(t) {
                var e = g.parseFromUrl(t), n = e.params_map, r = {};
                for (var o in e.params) r[n[o]] = e.params[o];
                return r;
            }
            r.prototype.setAppName = function(t) {
                return this.appName = t, this;
            }, r.prototype.setAppVersion = function(t) {
                return this.appVersion = t, this;
            }, r.prototype.getDefaultTracker = function() {
                return this.trackers[0];
            }, r.prototype.newTracker = function(t) {
                var e = new i(this, t);
                return this.trackers.push(e), e;
            }, r.prototype.setLog = function(t) {
                return this.log = !!t, this;
            }, i.prototype.setTrackerServer = function(t) {
                return this.trackerServer = t, this;
            }, i.prototype.get = function(t) {
                return this.hit[o(t)];
            }, i.prototype.set = function(t, e) {
                return this.hit[o(t)] = e, this;
            }, i.prototype.setAnonymizeIp = function(t) {
                return this.set("aip", t ? 1 : 0);
            }, i.prototype.setAppId = function(t) {
                return this.set("aid", t);
            }, i.prototype.setAppInstallerId = function(t) {
                return this.set("aiid", t);
            }, i.prototype.setAppName = function(t) {
                return this.set("an", t);
            }, i.prototype.setAppVersion = function(t) {
                return this.set("av", t);
            }, i.prototype.setCampaignParamsOnNextHit = function(t) {
                var e = m(t);
                for (var n in this.next_hit = {}, e) this.next_hit[n] = e[n];
                return this;
            }, i.prototype.setClientId = function(t) {
                return this.set("cid", t);
            }, i.prototype.setEncoding = function(t) {
                return this.set("de", t);
            }, i.prototype.setLanguage = function(t) {
                return this.set("ul", t);
            }, i.prototype.setLocation = function(t) {
                return this.set("geoid", t);
            }, i.prototype.setScreenColors = function(t) {
                return this.set("sd", t);
            }, i.prototype.setScreenName = function(t) {
                return this.set("cd", t);
            }, i.prototype.setScreenResolution = function(t, e) {
                return this.set("sr", [ t, e ].join("x"));
            }, i.prototype.setViewportSize = function(t) {
                return this.set("vp", t);
            }, i.prototype.send = function(t) {
                return this.send_queue_push(this.ga, t), this;
            }, i.prototype.send_queue_push = function(t, e) {
                var n = this, r = {
                    v: 1,
                    cid: t.cid,
                    ds: "app",
                    ul: t.systemInfo.language,
                    de: "UTF-8",
                    sd: "24-bit",
                    je: 0,
                    an: t.appName,
                    av: t.appVersion,
                    sr: t.sr,
                    vp: t.vp,
                    ua: t.userAgent
                };
                for (var o in n.hit) r[o] = n.hit[o];
                for (var o in n.next_hit) r[o] = n.next_hit[o];
                for (var o in n.next_hit = {}, e) r[o] = e[o];
                this.ga.log && console.log([ "ga.queue.push", r ]), this.send_queue.push([ r, new Date() ]), 
                this._do_send();
            }, i.prototype._do_send = function() {
                if (!this.sending) if (this.send_queue.length <= 0) this.sending = !1; else {
                    this.sending = !0;
                    for (var t = this, e = function(t) {
                        var e = [];
                        for (var n in t) e.push([ encodeURIComponent(n), encodeURIComponent(t[n]) ].join("="));
                        return e.join("&");
                    }, n = []; this.send_queue.length > 0; ) {
                        var r = this.send_queue[0], o = r[0];
                        o.qt = new Date().getTime() - r[1].getTime(), o.z = Math.floor(2147483648 * Math.random());
                        var i = e(o), s = n.map(function(t) {
                            return t.length;
                        }).reduce(function(t, e) {
                            return t + e;
                        }, 0), u = i.length;
                        if ((s + u > 16384 || u > 8192 || n.length >= 20) && n.length > 0) break;
                        n.push(i), this.send_queue.shift(), this.ga.log && console.log([ "ga.queue.presend[" + (n.length - 1) + "]", o ]);
                    }
                    var c = n.join("\r\n"), a = this.trackerServer + "/collect";
                    n.length > 1 ? (this.ga.log && console.log([ "ga.queue.send.batch", c ]), a = this.trackerServer + "/batch") : this.ga.log && console.log([ "ga.queue.send.collect", c ]), 
                    wx.request({
                        url: a,
                        data: c,
                        method: "POST",
                        header: {
                            "content-type": "text/plain"
                        },
                        success: function(e) {
                            t.ga.log && console.log([ "ga:success", e ]);
                        },
                        fail: function(e) {
                            t.ga.log && console.log([ "ga:failed", e ]);
                        },
                        complete: function() {
                            t.sending = !1, setTimeout(function() {
                                t._do_send();
                            }, 0);
                        }
                    });
                }
            }, s.prototype.get = function(t) {
                return this.hit[o(t)];
            }, s.prototype.set = function(t, e) {
                return this.hit[o(t)] = e, this;
            }, s.prototype.setAll = function(t) {
                for (var e in t) this.set(e, t[e]);
                return this;
            }, s.prototype.addImpression = function(t, e) {
                this.impression_product_list[e] || (this.impression_product_list[e] = [ this.next_impression_index, 1 ], 
                this.set("il" + this.next_impression_index + "nm", e), this.next_impression_index++);
                var n = this.impression_product_list[e][0], r = this.impression_product_list[e][1];
                for (var o in t.hit) this.set("il" + n + "pi" + r + o, t.hit[o]);
                return this.impression_product_list[e][1] = r + 1, this;
            }, s.prototype.addProduct = function(t) {
                var e = this.next_product_index;
                for (var n in t.hit) this.set("pr" + e + n, t.hit[n]);
                return this.next_product_index++, this;
            }, s.prototype.addPromotion = function(t) {
                var e = this.next_promotion_index;
                for (var n in t.hit) this.set("promo" + e + n, t.hit[n]);
                return this.next_promotion_index++, this;
            }, s.prototype.setProductAction = function(t) {
                for (var e in t.hit) this.set(e, t.hit[e]);
                return this;
            }, s.prototype.setPromotionAction = function(t) {
                return this.set("promoa", t);
            }, s.prototype.setCampaignParamsFromUrl = function(t) {
                var e = m(t);
                return this.setAll(e);
            }, s.prototype.setCustomDimension = function(t, e) {
                return this.custom_dimensions.push([ t, e ]), this;
            }, s.prototype.setCustomMetric = function(t, e) {
                return this.custom_metrics.push([ t, e ]), this;
            }, s.prototype.setNewSession = function() {
                return this.hit.sc = "start", this;
            }, s.prototype.setEndSession = function() {
                return this.hit.sc = "end", this;
            }, s.prototype.setNonInteraction = function(t) {
                return this.hit.ni = t ? 1 : 0, this;
            }, s.prototype.setHitType = function(t) {
                return this.hit.t = t, this;
            }, s.prototype.build = function() {
                var t, e = this, n = [];
                for (var r in 0 == this.hit.ni && n.push("ni"), this.hit) r.match(/^(cd|cm)\d+$/) && n.push(r);
                n.map(function(t) {
                    delete e.hit[t];
                });
                var o = this.custom_dimensions, i = this.custom_metrics;
                for (t = 0; t < o.length; t++) {
                    var s = o[t];
                    this.hit["cd" + s[0]] = s[1];
                }
                for (t = 0; t < i.length; t++) {
                    var u = i[t];
                    this.hit["cm" + u[0]] = u[1];
                }
                return this.hit;
            }, c.prototype = Object.create(s.prototype), c.prototype.constructor = c, a.prototype = Object.create(s.prototype), 
            a.prototype.constructor = a, a.prototype.setCategory = function(t) {
                return this.set("ec", t);
            }, a.prototype.setAction = function(t) {
                return this.set("ea", t);
            }, a.prototype.setLabel = function(t) {
                return this.set("el", t);
            }, a.prototype.setValue = function(t) {
                return this.set("ev", t);
            }, a.prototype.build = function() {
                return u(this, "ev", 0), u(this, "el", ""), s.prototype.build.apply(this, arguments);
            }, p.prototype = Object.create(s.prototype), p.prototype.constructor = p, p.prototype.setNetwork = function(t) {
                return this.set("sn", t);
            }, p.prototype.setAction = function(t) {
                return this.set("sa", t);
            }, p.prototype.setTarget = function(t) {
                return this.set("st", t);
            }, p.prototype.build = function() {
                return u(this, "st", ""), s.prototype.build.apply(this, arguments);
            }, h.prototype = Object.create(s.prototype), h.prototype.constructor = h, h.prototype.setDescription = function(t) {
                return this.set("exd", t);
            }, h.prototype.setFatal = function(t) {
                return this.set("exf", t ? 1 : 0);
            }, f.prototype = Object.create(s.prototype), f.prototype.constructor = f, f.prototype.setCategory = function(t) {
                return this.set("utc", t);
            }, f.prototype.setVariable = function(t) {
                return this.set("utv", t);
            }, f.prototype.setValue = function(t) {
                return this.set("utt", t);
            }, f.prototype.setLabel = function(t) {
                return this.set("utl", t);
            }, f.prototype.build = function() {
                return u(this, "utl", ""), s.prototype.build.apply(this, arguments);
            }, l.prototype.setBrand = function(t) {
                return this.hit.br = t, this;
            }, l.prototype.setCategory = function(t) {
                return this.hit.ca = t, this;
            }, l.prototype.setCouponCode = function(t) {
                return this.hit.cc = t, this;
            }, l.prototype.setCustomDimension = function(t, e) {
                return this.hit["cd" + t] = e, this;
            }, l.prototype.setCustomMetric = function(t, e) {
                return this.hit["cm" + t] = e, this;
            }, l.prototype.setId = function(t) {
                return this.hit.id = t, this;
            }, l.prototype.setName = function(t) {
                return this.hit.nm = t, this;
            }, l.prototype.setPosition = function(t) {
                return this.hit.ps = t, this;
            }, l.prototype.setPrice = function(t) {
                return this.hit.pr = t, this;
            }, l.prototype.setQuantity = function(t) {
                return this.hit.qt = t, this;
            }, l.prototype.setVariant = function(t) {
                return this.hit.va = t, this;
            }, d.ACTION_CLICK = "click", d.ACTION_VIEW = "view", d.prototype.setCreative = function(t) {
                return this.hit.cr = t, this;
            }, d.prototype.setId = function(t) {
                return this.hit.id = t, this;
            }, d.prototype.setName = function(t) {
                return this.hit.nm = t, this;
            }, d.prototype.setPosition = function(t) {
                return this.hit.ps = t, this;
            }, y.ACTION_ADD = "add", y.ACTION_CHECKOUT = "checkout", y.ACTION_CHECKOUT_OPTION = "checkout_option", 
            y.ACTION_CLICK = "click", y.ACTION_DETAIL = "detail", y.ACTION_PURCHASE = "purchase", 
            y.ACTION_REFUND = "refund", y.ACTION_REMOVE = "remove", y.prototype.setCheckoutOptions = function(t) {
                return this.hit.col = t, this;
            }, y.prototype.setCheckoutStep = function(t) {
                return this.hit.cos = t, this;
            }, y.prototype.setProductActionList = function(t) {
                return this.hit.pal = t, this;
            }, y.prototype.setProductListSource = function(t) {
                return this.hit.pls = t, this;
            }, y.prototype.setTransactionAffiliation = function(t) {
                return this.hit.ta = t, this;
            }, y.prototype.setTransactionCouponCode = function(t) {
                return this.hit.tcc = t, this;
            }, y.prototype.setTransactionId = function(t) {
                return this.hit.ti = t, this;
            }, y.prototype.setTransactionRevenue = function(t) {
                return this.hit.tr = t, this;
            }, y.prototype.setTransactionShipping = function(t) {
                return this.hit.ts = t, this;
            }, y.prototype.setTransactionTax = function(t) {
                return this.hit.tt = t, this;
            }, g.prototype.set = function(t, e) {
                return t in this.params_map && (this.params[t] = e), this;
            }, g.prototype.toUrl = function() {
                var t = [];
                for (var e in this.params) t.push([ encodeURIComponent(e), encodeURIComponent(this.params[e]) ].join("="));
                return "https://example.com?" + t.join("&");
            }, g.parseFromPageOptions = function(t, e) {
                t = t || {}, e = e || {};
                var n = new g();
                for (var r in t) {
                    var o = t[r];
                    r in e && (r = e[r]), (r.match(/^utm_/) || "gclid" == r) && n.set(r, o);
                }
                return n;
            }, g.buildFromWeappScene = function(t) {
                var e = {
                    1001: "发现栏小程序主入口",
                    1005: "顶部搜索框的搜索结果页",
                    1006: "发现栏小程序主入口搜索框的搜索结果页",
                    1007: "单人聊天会话中的小程序消息卡片",
                    1008: "群聊会话中的小程序消息卡片",
                    1011: "扫描二维码",
                    1012: "长按图片识别二维码",
                    1013: "手机相册选取二维码",
                    1014: "小程序模版消息",
                    1017: "前往体验版的入口页",
                    1019: "微信钱包",
                    1020: "公众号profile页相关小程序列表",
                    1022: "聊天顶部置顶小程序入口",
                    1023: "安卓系统桌面图标",
                    1024: "小程序profile页",
                    1025: "扫描一维码",
                    1026: "附近小程序列表",
                    1027: "顶部搜索框搜索结果页“使用过的小程序”列表",
                    1028: "我的卡包",
                    1029: "卡券详情页",
                    1030: "自动化测试下打开小程序",
                    1031: "长按图片识别一维码",
                    1032: "手机相册选取一维码",
                    1034: "微信支付完成页",
                    1035: "公众号自定义菜单",
                    1036: "App 分享消息卡片",
                    1037: "小程序打开小程序",
                    1038: "从另一个小程序返回",
                    1039: "摇电视",
                    1042: "添加好友搜索框的搜索结果页",
                    1043: "公众号模板消息",
                    1044: "带shareTicket的小程序消息卡片",
                    1045: "朋友圈广告",
                    1046: "朋友圈广告详情页",
                    1047: "扫描小程序码",
                    1048: "长按图片识别小程序码",
                    1049: "手机相册选取小程序码",
                    1052: "卡券的适用门店列表",
                    1053: "搜一搜的结果页",
                    1054: "顶部搜索框小程序快捷入口",
                    1056: "音乐播放器菜单",
                    1057: "钱包中的银行卡详情页",
                    1058: "公众号文章",
                    1059: "体验版小程序绑定邀请页",
                    1064: "微信连Wifi状态栏",
                    1067: "公众号文章广告",
                    1068: "附近小程序列表广告",
                    1069: "移动应用",
                    1071: "钱包中的银行卡列表页",
                    1072: "二维码收款页面",
                    1073: "客服消息列表下发的小程序消息卡片",
                    1074: "公众号会话下发的小程序消息卡片",
                    1077: "摇周边",
                    1078: "连Wi-Fi成功页",
                    1079: "微信游戏中心",
                    1081: "客服消息下发的文字链",
                    1082: "公众号会话下发的文字链",
                    1084: "朋友圈广告原生页",
                    1089: "微信聊天主界面下拉",
                    1090: "长按小程序右上角菜单唤出最近使用历史",
                    1091: "公众号文章商品卡片",
                    1092: "城市服务入口",
                    1095: "小程序广告组件",
                    1096: "聊天记录",
                    1097: "微信支付签约页",
                    1099: "页面内嵌插件",
                    1102: "公众号 profile 页服务预览"
                }, n = new g();
                return t in e ? (n.set("utm_source", "小程序场景"), n.set("utm_medium", t + ":" + e[t])) : t && (n.set("utm_source", "小程序场景"), 
                n.set("utm_medium", t + ":")), n;
            }, g.parseFromUrl = function(t) {
                var e = t.replace(/^[^?]+\?/, ""), n = new g(), r = n.params_map;
                return e.split("&").map(function(t) {
                    var e = t.split("="), o = decodeURIComponent(e[0]);
                    if (2 == e.length && "" !== e[1] && r[o]) {
                        var i = decodeURIComponent(e[1]);
                        n.set(o, i);
                    }
                }), n;
            };
            var v = function() {
                return "object" == ("undefined" == typeof wx ? "undefined" : n(wx)) && "function" == typeof wx.getSystemInfoSync ? wx.getSystemInfoSync() : {
                    brand: "unknow",
                    screenWidth: 0,
                    screenHeight: 0,
                    windowWidth: 0,
                    windowHeight: 0,
                    pixelRatio: 1,
                    language: "zh_CN",
                    system: "unknow",
                    model: "unknow",
                    version: "unknow",
                    platform: "unknow",
                    fontSizeSetting: 0,
                    SDKVersion: "unknow"
                };
            };
            t.exports = {
                GoogleAnalytics: {
                    getInstance: function(t) {
                        return (t = t || {}).defaultGoogleAnalyticsInstance || (t.defaultGoogleAnalyticsInstance = new r(t)), 
                        t.defaultGoogleAnalyticsInstance;
                    }
                },
                HitBuilders: {
                    HitBuilder: s,
                    ScreenViewBuilder: c,
                    EventBuilder: a,
                    SocialBuilder: p,
                    ExceptionBuilder: h,
                    TimingBuilder: f
                },
                Product: l,
                ProductAction: y,
                Promotion: d,
                CampaignParams: g
            };
        }, function(t, e, r) {
            (function(e) {
                var r, o = "__lodash_hash_undefined__", i = /\.|\[(?:[^[\]]*|(["'])(?:(?!\1)[^\\]|\\.)*?\1)\]/, s = /^\w*$/, u = /^\./, c = /[^.[\]]+|\[(?:(-?\d+(?:\.\d+)?)|(["'])((?:(?!\2)[^\\]|\\.)*?)\2)\]|(?=(?:\.|\[\])(?:\.|\[\]|$))/g, a = /\\(\\)?/g, p = /^\[object .+?Constructor\]$/, h = "object" == n(e) && e && e.Object === Object && e, f = "object" == ("undefined" == typeof self ? "undefined" : n(self)) && self && self.Object === Object && self, l = h || f || Function("return this")(), d = Array.prototype, y = Function.prototype, g = Object.prototype, m = l["__core-js_shared__"], v = (r = /[^.]+$/.exec(m && m.keys && m.keys.IE_PROTO || "")) ? "Symbol(src)_1." + r : "", _ = y.toString, x = g.hasOwnProperty, w = g.toString, b = RegExp("^" + _.call(x).replace(/[\\^$.*+?()[\]{}|]/g, "\\$&").replace(/hasOwnProperty|(function).*?(?=\\\()| for .+?(?=\\\])/g, "$1.*?") + "$"), O = l.Symbol, C = d.splice, A = N(l, "Map"), S = N(Object, "create"), j = O ? O.prototype : void 0, P = j ? j.toString : void 0;
                function I(t) {
                    var e = -1, n = t ? t.length : 0;
                    for (this.clear(); ++e < n; ) {
                        var r = t[e];
                        this.set(r[0], r[1]);
                    }
                }
                function k(t) {
                    var e = -1, n = t ? t.length : 0;
                    for (this.clear(); ++e < n; ) {
                        var r = t[e];
                        this.set(r[0], r[1]);
                    }
                }
                function T(t) {
                    var e = -1, n = t ? t.length : 0;
                    for (this.clear(); ++e < n; ) {
                        var r = t[e];
                        this.set(r[0], r[1]);
                    }
                }
                function M(t, e) {
                    for (var n, r, o = t.length; o--; ) if ((n = t[o][0]) === (r = e) || n != n && r != r) return o;
                    return -1;
                }
                function L(t, e) {
                    var r, o, i = t.__data__;
                    return ("string" == (o = n(r = e)) || "number" == o || "symbol" == o || "boolean" == o ? "__proto__" !== r : null === r) ? i["string" == typeof e ? "string" : "hash"] : i.map;
                }
                function N(t, e) {
                    var n = function(t, e) {
                        return null == t ? void 0 : t[e];
                    }(t, e);
                    return function(t) {
                        return !(!H(t) || (e = t, v && v in e)) && (function(t) {
                            var e = H(t) ? w.call(t) : "";
                            return "[object Function]" == e || "[object GeneratorFunction]" == e;
                        }(t) || function(t) {
                            var e = !1;
                            if (null != t && "function" != typeof t.toString) try {
                                e = !!(t + "");
                            } catch (t) {}
                            return e;
                        }(t) ? b : p).test(function(t) {
                            if (null != t) {
                                try {
                                    return _.call(t);
                                } catch (t) {}
                                try {
                                    return t + "";
                                } catch (t) {}
                            }
                            return "";
                        }(t));
                        var e;
                    }(n) ? n : void 0;
                }
                I.prototype.clear = function() {
                    this.__data__ = S ? S(null) : {};
                }, I.prototype.delete = function(t) {
                    return this.has(t) && delete this.__data__[t];
                }, I.prototype.get = function(t) {
                    var e = this.__data__;
                    if (S) {
                        var n = e[t];
                        return n === o ? void 0 : n;
                    }
                    return x.call(e, t) ? e[t] : void 0;
                }, I.prototype.has = function(t) {
                    var e = this.__data__;
                    return S ? void 0 !== e[t] : x.call(e, t);
                }, I.prototype.set = function(t, e) {
                    return this.__data__[t] = S && void 0 === e ? o : e, this;
                }, k.prototype.clear = function() {
                    this.__data__ = [];
                }, k.prototype.delete = function(t) {
                    var e = this.__data__, n = M(e, t);
                    return !(n < 0 || (n == e.length - 1 ? e.pop() : C.call(e, n, 1), 0));
                }, k.prototype.get = function(t) {
                    var e = this.__data__, n = M(e, t);
                    return n < 0 ? void 0 : e[n][1];
                }, k.prototype.has = function(t) {
                    return M(this.__data__, t) > -1;
                }, k.prototype.set = function(t, e) {
                    var n = this.__data__, r = M(n, t);
                    return r < 0 ? n.push([ t, e ]) : n[r][1] = e, this;
                }, T.prototype.clear = function() {
                    this.__data__ = {
                        hash: new I(),
                        map: new (A || k)(),
                        string: new I()
                    };
                }, T.prototype.delete = function(t) {
                    return L(this, t).delete(t);
                }, T.prototype.get = function(t) {
                    return L(this, t).get(t);
                }, T.prototype.has = function(t) {
                    return L(this, t).has(t);
                }, T.prototype.set = function(t, e) {
                    return L(this, t).set(t, e), this;
                };
                var E = V(function(t) {
                    var e;
                    t = null == (e = t) ? "" : function(t) {
                        if ("string" == typeof t) return t;
                        if (F(t)) return P ? P.call(t) : "";
                        var e = t + "";
                        return "0" == e && 1 / t == -1 / 0 ? "-0" : e;
                    }(e);
                    var n = [];
                    return u.test(t) && n.push(""), t.replace(c, function(t, e, r, o) {
                        n.push(r ? o.replace(a, "$1") : e || t);
                    }), n;
                });
                function U(t) {
                    if ("string" == typeof t || F(t)) return t;
                    var e = t + "";
                    return "0" == e && 1 / t == -1 / 0 ? "-0" : e;
                }
                function V(t, e) {
                    if ("function" != typeof t || e && "function" != typeof e) throw new TypeError("Expected a function");
                    var n = function n() {
                        var r = arguments, o = e ? e.apply(this, r) : r[0], i = n.cache;
                        if (i.has(o)) return i.get(o);
                        var s = t.apply(this, r);
                        return n.cache = i.set(o, s), s;
                    };
                    return n.cache = new (V.Cache || T)(), n;
                }
                V.Cache = T;
                var q = Array.isArray;
                function H(t) {
                    var e = n(t);
                    return !!t && ("object" == e || "function" == e);
                }
                function F(t) {
                    return "symbol" == n(t) || function(t) {
                        return !!t && "object" == n(t);
                    }(t) && "[object Symbol]" == w.call(t);
                }
                t.exports = function(t, e, r) {
                    var o = null == t ? void 0 : function(t, e) {
                        for (var r, o = 0, u = (e = function(t, e) {
                            if (q(t)) return !1;
                            var r = n(t);
                            return !("number" != r && "symbol" != r && "boolean" != r && null != t && !F(t)) || s.test(t) || !i.test(t) || null != e && t in Object(e);
                        }(e, t) ? [ e ] : q(r = e) ? r : E(r)).length; null != t && o < u; ) t = t[U(e[o++])];
                        return o && o == u ? t : void 0;
                    }(t, e);
                    return void 0 === o ? r : o;
                };
            }).call(this, r(3));
        }, function(t, e) {
            var r;
            r = function() {
                return this;
            }();
            try {
                r = r || new Function("return this")();
            } catch (t) {
                "object" == ("undefined" == typeof window ? "undefined" : n(window)) && (r = window);
            }
            t.exports = r;
        }, function(t, e) {
            var r = 9007199254740991, o = /^(?:0|[1-9]\d*)$/;
            function i(t, e, n) {
                switch (n.length) {
                  case 0:
                    return t.call(e);

                  case 1:
                    return t.call(e, n[0]);

                  case 2:
                    return t.call(e, n[0], n[1]);

                  case 3:
                    return t.call(e, n[0], n[1], n[2]);
                }
                return t.apply(e, n);
            }
            var s, u, c = Object.prototype, a = c.hasOwnProperty, p = c.toString, h = c.propertyIsEnumerable, f = (s = Object.keys, 
            u = Object, function(t) {
                return s(u(t));
            }), l = Math.max, d = !h.call({
                valueOf: 1
            }, "valueOf");
            function y(t, e, n) {
                var r = t[e];
                a.call(t, e) && v(r, n) && (void 0 !== n || e in t) || (t[e] = n);
            }
            function g(t, e) {
                return !!(e = null == e ? r : e) && ("number" == typeof t || o.test(t)) && t > -1 && t % 1 == 0 && t < e;
            }
            function m(t) {
                var e = t && t.constructor;
                return t === ("function" == typeof e && e.prototype || c);
            }
            function v(t, e) {
                return t === e || t != t && e != e;
            }
            var _ = Array.isArray;
            function x(t) {
                return null != t && function(t) {
                    return "number" == typeof t && t > -1 && t % 1 == 0 && t <= r;
                }(t.length) && !function(t) {
                    var e = w(t) ? p.call(t) : "";
                    return "[object Function]" == e || "[object GeneratorFunction]" == e;
                }(t);
            }
            function w(t) {
                var e = n(t);
                return !!t && ("object" == e || "function" == e);
            }
            var b, O = (b = function(t, e) {
                if (d || m(e) || x(e)) !function(t, e, n, r) {
                    n || (n = {});
                    for (var o = -1, i = e.length; ++o < i; ) {
                        var s = e[o];
                        y(n, s, t[s]);
                    }
                }(e, function(t) {
                    return x(t) ? function(t, e) {
                        var r = _(t) || function(t) {
                            return function(t) {
                                return function(t) {
                                    return !!t && "object" == n(t);
                                }(t) && x(t);
                            }(t) && a.call(t, "callee") && (!h.call(t, "callee") || "[object Arguments]" == p.call(t));
                        }(t) ? function(t, e) {
                            for (var n = -1, r = Array(t); ++n < t; ) r[n] = e(n);
                            return r;
                        }(t.length, String) : [], o = r.length, i = !!o;
                        for (var s in t) !e && !a.call(t, s) || i && ("length" == s || g(s, o)) || r.push(s);
                        return r;
                    }(t) : function(t) {
                        if (!m(t)) return f(t);
                        var e = [];
                        for (var n in Object(t)) a.call(t, n) && "constructor" != n && e.push(n);
                        return e;
                    }(t);
                }(e), t); else for (var r in e) a.call(e, r) && y(t, r, e[r]);
            }, function(t, e) {
                return e = l(void 0 === e ? t.length - 1 : e, 0), function() {
                    for (var n = arguments, r = -1, o = l(n.length - e, 0), s = Array(o); ++r < o; ) s[r] = n[e + r];
                    r = -1;
                    for (var u = Array(e + 1); ++r < e; ) u[r] = n[r];
                    return u[e] = s, i(t, this, u);
                };
            }(function(t, e) {
                var r = -1, o = e.length, i = o > 1 ? e[o - 1] : void 0, s = o > 2 ? e[2] : void 0;
                for (i = b.length > 3 && "function" == typeof i ? (o--, i) : void 0, s && function(t, e, r) {
                    if (!w(r)) return !1;
                    var o = n(e);
                    return !!("number" == o ? x(r) && g(e, r.length) : "string" == o && e in r) && v(r[e], t);
                }(e[0], e[1], s) && (i = o < 3 ? void 0 : i, o = 1), t = Object(t); ++r < o; ) {
                    var u = e[r];
                    u && b(t, u);
                }
                return t;
            }));
            t.exports = O;
        }, function(t, e, n) {
            Object.defineProperty(e, "__esModule", {
                value: !0
            }), e.queryString = function(t) {
                var e = [];
                for (var n in t) t.hasOwnProperty(n) && e.push("".concat(n, "=").concat(encodeURIComponent(t[n])));
                return e.join("&");
            }, e.decodeScene = function(t) {
                t = decodeURIComponent(t);
                var e = {}, n = t.split("&").filter(function(t) {
                    if (/[^=]+=[^=]+/.test(t)) {
                        var n = t.split("=");
                        return e[n[0]] = n[1], !1;
                    }
                    return !0;
                }).join("&");
                return t && (e.scene = n), e;
            }, e.getCurrentPage = function() {
                try {
                    var t = getCurrentPages();
                    return t[t.length - 1];
                } catch (t) {
                    return console.warn("get current page fail", t), null;
                }
            }, e.getPrevPage = function() {
                try {
                    var t = getCurrentPages();
                    return t[t.length - 2];
                } catch (t) {
                    return console.warn("get prev page fail", t), null;
                }
            };
        } ]);
    }, "object" == n(r) && "object" == n(e) ? e.exports = i() : "function" == typeof define && define.amd ? define([], i) : "object" == n(r) ? r.NocodeAnalyse = i() : o.NocodeAnalyse = i();
}, function(t) {
    return e({}[t], t);
}), e(1700120110430));