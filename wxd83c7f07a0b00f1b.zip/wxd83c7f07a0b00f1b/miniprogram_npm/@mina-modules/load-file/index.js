var e = require("../../../@babel/runtime/helpers/regeneratorRuntime");

!function() {
    var t = {
        n: function(e) {
            var n = e && e.__esModule ? function() {
                return e.default;
            } : function() {
                return e;
            };
            return t.d(n, {
                a: n
            }), n;
        },
        d: function(e, n) {
            for (var r in n) t.o(n, r) && !t.o(e, r) && Object.defineProperty(e, r, {
                enumerable: !0,
                get: n[r]
            });
        },
        o: function(e, t) {
            return Object.prototype.hasOwnProperty.call(e, t);
        },
        r: function(e) {
            "undefined" != typeof Symbol && Symbol.toStringTag && Object.defineProperty(e, Symbol.toStringTag, {
                value: "Module"
            }), Object.defineProperty(e, "__esModule", {
                value: !0
            });
        }
    }, n = {};
    t.r(n), t.d(n, {
        default: function() {
            return s;
        }
    });
    var r = require("md5"), a = t.n(r);
    function o(e, t, n, r, a, o, c) {
        try {
            var u = e[o](c), i = u.value;
        } catch (e) {
            return void n(e);
        }
        u.done ? t(i) : Promise.resolve(i).then(r, a);
    }
    function c(e) {
        return function() {
            var t = this, n = arguments;
            return new Promise(function(r, a) {
                var c = e.apply(t, n);
                function u(e) {
                    o(c, r, a, u, i, "next", e);
                }
                function i(e) {
                    o(c, r, a, u, i, "throw", e);
                }
                u(void 0);
            });
        };
    }
    function u(e, t, n, r) {
        return new Promise(function(a, o) {
            wx.getFileSystemManager().readFile({
                filePath: e,
                encoding: "base64",
                success: function(c) {
                    wx.loadFontFace({
                        family: t,
                        source: 'url("data:font/ttf;charset=utf-8;base64,'.concat(c.data, '")'),
                        global: !0,
                        desc: n,
                        scopes: r,
                        success: function() {
                            a(e);
                        },
                        fail: function() {
                            o("加载字体文件失败");
                        }
                    });
                },
                fail: function() {
                    o("读取字体文件失败");
                }
            });
        });
    }
    function i(t, n, r, a, o) {
        return new Promise(function(i, s) {
            wx.downloadFile({
                url: t,
                success: function(t) {
                    var f;
                    200 === t.statusCode ? wx.getFileSystemManager().saveFile({
                        tempFilePath: t.tempFilePath,
                        filePath: n,
                        success: (f = c(e().mark(function t() {
                            return e().wrap(function(e) {
                                for (;;) switch (e.prev = e.next) {
                                  case 0:
                                    if (!r) {
                                        e.next = 9;
                                        break;
                                    }
                                    return e.prev = 1, e.next = 4, u(n, r, a, o);

                                  case 4:
                                    e.next = 9;
                                    break;

                                  case 6:
                                    return e.prev = 6, e.t0 = e.catch(1), e.abrupt("return", s(e.t0));

                                  case 9:
                                    i(n);

                                  case 10:
                                  case "end":
                                    return e.stop();
                                }
                            }, t, null, [ [ 1, 6 ] ]);
                        })), function() {
                            return f.apply(this, arguments);
                        })
                    }) : s("下载文件失败");
                },
                fail: function(e) {
                    s(e);
                }
            });
        });
    }
    function s(t) {
        var n = t.url, r = t.fontFamily, o = void 0 === r ? "" : r, s = t.fontDesc, f = t.fontScopes, l = t.success, p = void 0 === l ? function() {} : l, d = t.fail, v = void 0 === d ? function() {} : d, h = t.complete, m = void 0 === h ? function() {} : h;
        if (!n) throw new Error("参数 options 对象未包含 url");
        var w = a()(n), b = "".concat(wx.env.USER_DATA_PATH, "/").concat(w);
        return new Promise(function(t, r) {
            var a, l;
            wx.getFileSystemManager().access({
                path: b,
                success: (l = c(e().mark(function n() {
                    return e().wrap(function(e) {
                        for (;;) switch (e.prev = e.next) {
                          case 0:
                            if (!o) {
                                e.next = 12;
                                break;
                            }
                            return e.prev = 1, e.next = 4, u(b, o, s, f);

                          case 4:
                            e.next = 12;
                            break;

                          case 6:
                            return e.prev = 6, e.t0 = e.catch(1), r(e.t0), v(e.t0), m(e.t0), e.abrupt("return");

                          case 12:
                            t(b), p({
                                filePath: b
                            }), m({
                                filePath: b
                            });

                          case 15:
                          case "end":
                            return e.stop();
                        }
                    }, n, null, [ [ 1, 6 ] ]);
                })), function() {
                    return l.apply(this, arguments);
                }),
                fail: (a = c(e().mark(function r() {
                    return e().wrap(function(e) {
                        for (;;) switch (e.prev = e.next) {
                          case 0:
                            return e.prev = 0, e.t0 = t, e.next = 4, i(n, b, o, s, f);

                          case 4:
                            e.t1 = e.sent, (0, e.t0)(e.t1), p({
                                filePath: b
                            }), m({
                                filePath: b
                            }), e.next = 15;
                            break;

                          case 10:
                            e.prev = 10, e.t2 = e.catch(0), t(n), v(e.t2), m({
                                filePath: n,
                                error: e.t2
                            });

                          case 15:
                          case "end":
                            return e.stop();
                        }
                    }, r, null, [ [ 0, 10 ] ]);
                })), function() {
                    return a.apply(this, arguments);
                })
            });
        });
    }
    module.exports = n;
}();