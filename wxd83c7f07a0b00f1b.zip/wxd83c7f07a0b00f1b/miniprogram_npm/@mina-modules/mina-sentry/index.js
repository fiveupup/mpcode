var t = require("../../../@babel/runtime/helpers/typeof");

module.exports = function(e) {
    var r = {};
    function n(t) {
        if (r[t]) return r[t].exports;
        var i = r[t] = {
            i: t,
            l: !1,
            exports: {}
        };
        return e[t].call(i.exports, i, i.exports, n), i.l = !0, i.exports;
    }
    return n.m = e, n.c = r, n.d = function(t, e, r) {
        n.o(t, e) || Object.defineProperty(t, e, {
            enumerable: !0,
            get: r
        });
    }, n.r = function(t) {
        "undefined" != typeof Symbol && Symbol.toStringTag && Object.defineProperty(t, Symbol.toStringTag, {
            value: "Module"
        }), Object.defineProperty(t, "__esModule", {
            value: !0
        });
    }, n.t = function(e, r) {
        if (1 & r && (e = n(e)), 8 & r) return e;
        if (4 & r && "object" === t(e) && e && e.__esModule) return e;
        var i = Object.create(null);
        if (n.r(i), Object.defineProperty(i, "default", {
            enumerable: !0,
            value: e
        }), 2 & r && "string" != typeof e) for (var o in e) n.d(i, o, function(t) {
            return e[t];
        }.bind(null, o));
        return i;
    }, n.n = function(t) {
        var e = t && t.__esModule ? function() {
            return t.default;
        } : function() {
            return t;
        };
        return n.d(e, "a", e), e;
    }, n.o = function(t, e) {
        return Object.prototype.hasOwnProperty.call(t, e);
    }, n.p = "", n(n.s = 0);
}([ function(t, e, r) {
    e.__esModule = !0, e.init = function(t) {
        var e = arguments.length > 1 && void 0 !== arguments[1] && arguments[1], r = wx.getAccountInfoSync(), n = r.miniProgram.envVersion, i = r.miniProgram.version;
        o.default.config(t, {
            environment: e ? "trial" : n,
            release: i
        }).install(), a = !0;
    }, e.info = function() {
        var t;
        (t = console).info.apply(t, arguments), s.info.apply(l, arguments), l.info.apply(l, arguments);
    }, e.error = function() {
        var t;
        if ((t = console).error.apply(t, arguments), !a) return void console.error("请先调初始化函数！");
        1 === arguments.length ? "string" == typeof arguments[0] || arguments[0] instanceof Error ? o.default.captureException(new Error(arguments[0]), {
            level: "error"
        }) : o.default.captureException(new Error(JSON.stringify(arguments[0])), {
            level: "error"
        }) : o.default.captureException(new Error(JSON.stringify(arguments)), {
            level: "error"
        });
        s.error.apply(l, arguments), l.log.apply(l, arguments);
    };
    var n, i = r(1), o = (n = i) && n.__esModule ? n : {
        default: n
    };
    var a = !1;
    var s = wx.getRealtimeLogManager(), l = wx.getLogManager({
        level: 0
    });
}, function(e, r, n) {
    e.exports = function t(e, r, n) {
        function i(a, s) {
            if (!r[a]) {
                if (!e[a]) {
                    if (o) return o(a, !0);
                    var l = new Error("Cannot find module '" + a + "'");
                    throw l.code = "MODULE_NOT_FOUND", l;
                }
                var c = r[a] = {
                    exports: {}
                };
                e[a][0].call(c.exports, function(t) {
                    var r = e[a][1][t];
                    return i(r || t);
                }, c, c.exports, t, e, r, n);
            }
            return r[a].exports;
        }
        for (var o = !1, a = 0; a < n.length; a++) i(n[a]);
        return i;
    }({
        1: [ function(t, e, r) {
            function n(t) {
                this.name = "RavenConfigError", this.message = t;
            }
            n.prototype = new Error(), n.prototype.constructor = n, e.exports = n;
        }, {} ],
        2: [ function(t, e, r) {
            e.exports = {
                wrapMethod: function(t, e, r) {
                    var n = t[e], i = t;
                    if (e in t) {
                        var o = "warn" === e ? "warning" : e;
                        t[e] = function() {
                            var t = [].slice.call(arguments), a = "" + t.join(" "), s = {
                                level: o,
                                logger: "console",
                                extra: {
                                    arguments: t
                                }
                            };
                            "assert" === e ? !1 === t[0] && (a = "Assertion failed: " + (t.slice(1).join(" ") || "console.assert"), 
                            s.extra.arguments = t.slice(1), r && r(a, s)) : r && r(a, s), n && Function.apply.call(n, i, t);
                        };
                    }
                }
            };
        }, {} ],
        3: [ function(e, r, n) {
            (function(n) {
                var i = e("../vendor/TraceKit/tracekit"), o = e("../vendor/json-stringify-safe/stringify"), a = e("./configError"), s = e("./utils"), l = s.isError, c = s.isObject, u = e("./console").wrapMethod, f = "source protocol user pass host port path".split(" "), p = /^(?:(\w+):)?\/\/(?:(\w+)(:\w+)?@)?([\w\.-]+)(?::(\d+))?(\/.*)/;
                function h() {
                    return +new Date();
                }
                var g = "undefined" != typeof window ? window : void 0 !== n ? n : "undefined" != typeof self ? self : {}, d = g.document, _ = g.navigator;
                function v(t, e) {
                    return x(e) ? function(r) {
                        return e(r, t);
                    } : e;
                }
                function m() {
                    for (var e in this._hasJSON = !("object" !== ("undefined" == typeof JSON ? "undefined" : t(JSON)) || !JSON.stringify), 
                    this._hasDocument = !y(d), this._hasNavigator = !y(_), this._lastCapturedException = null, 
                    this._lastData = null, this._lastEventId = null, this._globalServer = null, this._globalKey = null, 
                    this._globalProject = null, this._globalContext = {}, this._globalOptions = {
                        logger: "javascript",
                        ignoreErrors: [],
                        ignoreUrls: [],
                        whitelistUrls: [],
                        includePaths: [],
                        crossOrigin: "anonymous",
                        collectWindowErrors: !0,
                        maxMessageLength: 0,
                        maxUrlLength: 250,
                        stackTraceLimit: 50,
                        autoBreadcrumbs: !0,
                        instrument: !0,
                        sampleRate: 1
                    }, this._ignoreOnError = 0, this._isRavenInstalled = !1, this._originalErrorStackTraceLimit = Error.stackTraceLimit, 
                    this._originalConsole = g.console || {}, this._originalConsoleMethods = {}, this._plugins = [], 
                    this._startTime = h(), this._wrappedBuiltIns = [], this._breadcrumbs = [], this._lastCapturedEvent = null, 
                    this._keypressTimeout, this._location = g.location, this._lastHref = this._location && this._location.href, 
                    this._resetBackoff(), this._originalConsole) this._originalConsoleMethods[e] = this._originalConsole[e];
                }
                m.prototype = {
                    VERSION: "0.0.7",
                    debug: !1,
                    TraceKit: i,
                    config: function(t, e) {
                        var r = this;
                        if (r._globalServer) return this._logDebug("error", "Error: Raven has already been configured"), 
                        r;
                        if (!t) return r;
                        var n = r._globalOptions;
                        e && E(e, function(t, e) {
                            "tags" === t || "extra" === t || "user" === t ? r._globalContext[t] = e : n[t] = e;
                        }), r.setDSN(t), n.ignoreErrors.push(/^Script error\.?$/), n.ignoreErrors.push(/^Javascript error: Script error\.? on line 0$/), 
                        n.ignoreErrors = j(n.ignoreErrors), n.ignoreUrls = !!n.ignoreUrls.length && j(n.ignoreUrls), 
                        n.whitelistUrls = !!n.whitelistUrls.length && j(n.whitelistUrls), n.includePaths = j(n.includePaths), 
                        n.maxBreadcrumbs = Math.max(0, Math.min(n.maxBreadcrumbs || 100, 100));
                        var o = {
                            xhr: !1,
                            console: !0,
                            dom: !1,
                            location: !1
                        }, a = n.autoBreadcrumbs;
                        "[object Object]" === {}.toString.call(a) ? a = O(o, a) : !1 !== a && (a = o), n.autoBreadcrumbs = a;
                        var s = {
                            tryCatch: !0
                        }, l = n.instrument;
                        return "[object Object]" === {}.toString.call(l) ? l = O(s, l) : !1 !== l && (l = s), 
                        n.instrument = l, i.collectWindowErrors = !!n.collectWindowErrors, r;
                    },
                    install: function() {
                        var t = this;
                        return t.isSetup() && !t._isRavenInstalled && (i.report.subscribe(function() {
                            t._handleOnErrorStackInfo.apply(t, arguments);
                        }), t._globalOptions.instrument && t._globalOptions.instrument.tryCatch && t._instrumentTryCatch(), 
                        t._globalOptions.autoBreadcrumbs && t._instrumentBreadcrumbs(), t._drainPlugins(), 
                        this.installWeapp(), t._isRavenInstalled = !0), Error.stackTraceLimit = t._globalOptions.stackTraceLimit, 
                        this;
                    },
                    installWeapp: function() {
                        var t = this;
                        wx.getSystemInfo({
                            success: function(e) {
                                t.setTagsContext({
                                    device: e.model,
                                    system: e.system,
                                    WXversion: e.version,
                                    SDKversion: e.SDKVersion
                                });
                            }
                        }), wx.getNetworkType({
                            success: function(e) {
                                t.setTagsContext({
                                    network: e.networkType
                                });
                            }
                        });
                    },
                    setDSN: function(t) {
                        var e = this._parseDSN(t), r = e.path.lastIndexOf("/"), n = e.path.substr(1, r);
                        this._dsn = t, this._globalKey = e.user, this._globalSecret = e.pass && e.pass.substr(1), 
                        this._globalProject = e.path.substr(r + 1), this._globalServer = this._getGlobalServer(e), 
                        this._globalEndpoint = this._globalServer + "/" + n + "api/" + this._globalProject + "/store/", 
                        this._resetBackoff();
                    },
                    context: function(t, e, r) {
                        return x(t) && (r = e || [], e = t, t = void 0), this.wrap(t, e).apply(this, r);
                    },
                    wrap: function(t, e, r) {
                        var n = this;
                        if (y(e) && !x(t)) return t;
                        if (x(t) && (e = t, t = void 0), !x(e)) return e;
                        try {
                            if (e.__raven__) return e;
                            if (e.__raven_wrapper__) return e.__raven_wrapper__;
                        } catch (t) {
                            return e;
                        }
                        function i() {
                            var i = [], o = arguments.length, a = !t || t && !1 !== t.deep;
                            for (r && x(r) && r.apply(this, arguments); o--; ) i[o] = a ? n.wrap(t, arguments[o]) : arguments[o];
                            try {
                                return e.apply(this, i);
                            } catch (e) {
                                throw n._ignoreNextOnError(), n.captureException(e, t), e;
                            }
                        }
                        for (var o in e) C(e, o) && (i[o] = e[o]);
                        return i.prototype = e.prototype, e.__raven_wrapper__ = i, i.__raven__ = !0, i.__inner__ = e, 
                        i;
                    },
                    uninstall: function() {
                        return i.report.uninstall(), this._restoreBuiltIns(), Error.stackTraceLimit = this._originalErrorStackTraceLimit, 
                        this._isRavenInstalled = !1, this;
                    },
                    captureException: function(t, e) {
                        if ("[object String]" === Object.prototype.toString.call(t) && -1 !== t.indexOf("thirdScriptError")) {
                            var r = t.split("\n");
                            (t = new Error(r[1])).name = r[0], r.shift(), r.shift(), t.stack = r.join("\n");
                        }
                        if (!l(t)) return this.captureMessage(t, O({
                            trimHeadFrames: 1,
                            stacktrace: !0
                        }, e));
                        this._lastCapturedException = t;
                        try {
                            var n = i.computeStackTrace(t);
                            this._handleStackInfo(n, e);
                        } catch (e) {
                            if (t !== e) throw e;
                        }
                        return this;
                    },
                    captureMessage: function(t, e) {
                        if (!this._globalOptions.ignoreErrors.test || !this._globalOptions.ignoreErrors.test(t)) {
                            var r = O({
                                message: t + ""
                            }, e = e || {});
                            if (this._globalOptions.stacktrace || e && e.stacktrace) {
                                var n;
                                try {
                                    throw new Error(t);
                                } catch (t) {
                                    n = t;
                                }
                                n.name = null, e = O({
                                    fingerprint: t,
                                    trimHeadFrames: (e.trimHeadFrames || 0) + 1
                                }, e);
                                var o = i.computeStackTrace(n), a = this._prepareFrames(o, e);
                                r.stacktrace = {
                                    frames: a.reverse()
                                };
                            }
                            return this._send(r), this;
                        }
                    },
                    captureBreadcrumb: function(t) {
                        var e = O({
                            timestamp: h() / 1e3
                        }, t);
                        if (x(this._globalOptions.breadcrumbCallback)) {
                            var r = this._globalOptions.breadcrumbCallback(e);
                            if (c(r) && !k(r)) e = r; else if (!1 === r) return this;
                        }
                        return this._breadcrumbs.push(e), this._breadcrumbs.length > this._globalOptions.maxBreadcrumbs && this._breadcrumbs.shift(), 
                        this;
                    },
                    addPlugin: function(t) {
                        var e = [].slice.call(arguments, 1);
                        return this._plugins.push([ t, e ]), this._isRavenInstalled && this._drainPlugins(), 
                        this;
                    },
                    setUserContext: function(t) {
                        return this._globalContext.user = t, this;
                    },
                    setExtraContext: function(t) {
                        return this._mergeContext("extra", t), this;
                    },
                    setTagsContext: function(t) {
                        return this._mergeContext("tags", t), this;
                    },
                    clearContext: function() {
                        return this._globalContext = {}, this;
                    },
                    getContext: function() {
                        return JSON.parse(o(this._globalContext));
                    },
                    setEnvironment: function(t) {
                        return this._globalOptions.environment = t, this;
                    },
                    setRelease: function(t) {
                        return this._globalOptions.release = t, this;
                    },
                    setDataCallback: function(t) {
                        var e = this._globalOptions.dataCallback;
                        return this._globalOptions.dataCallback = v(e, t), this;
                    },
                    setBreadcrumbCallback: function(t) {
                        var e = this._globalOptions.breadcrumbCallback;
                        return this._globalOptions.breadcrumbCallback = v(e, t), this;
                    },
                    setShouldSendCallback: function(t) {
                        var e = this._globalOptions.shouldSendCallback;
                        return this._globalOptions.shouldSendCallback = v(e, t), this;
                    },
                    setTransport: function(t) {
                        return this._globalOptions.transport = t, this;
                    },
                    lastException: function() {
                        return this._lastCapturedException;
                    },
                    lastEventId: function() {
                        return this._lastEventId;
                    },
                    isSetup: function() {
                        return !(!this._hasJSON || !this._globalServer && (this.ravenNotConfiguredError || (this.ravenNotConfiguredError = !0, 
                        this._logDebug("error", "Error: Raven has not been configured.")), 1));
                    },
                    afterLoad: function() {
                        var t = g.RavenConfig;
                        t && this.config(t.dsn, t.config).install();
                    },
                    _ignoreNextOnError: function() {
                        var t = this;
                        this._ignoreOnError += 1, setTimeout(function() {
                            t._ignoreOnError -= 1;
                        });
                    },
                    _triggerEvent: function(t, e) {
                        var r, n;
                        if (this._hasDocument) {
                            for (n in e = e || {}, t = "raven" + t.substr(0, 1).toUpperCase() + t.substr(1), 
                            d.createEvent ? (r = d.createEvent("HTMLEvents")).initEvent(t, !0, !0) : (r = d.createEventObject()).eventType = t, 
                            e) C(e, n) && (r[n] = e[n]);
                            if (d.createEvent) d.dispatchEvent(r); else try {
                                d.fireEvent("on" + r.eventType.toLowerCase(), r);
                            } catch (t) {}
                        }
                    },
                    _captureUrlChange: function(t, e) {
                        var r = T(this._location.href), n = T(e), i = T(t);
                        this._lastHref = e, r.protocol === n.protocol && r.host === n.host && (e = n.relative), 
                        r.protocol === i.protocol && r.host === i.host && (t = i.relative), this.captureBreadcrumb({
                            category: "navigation",
                            data: {
                                to: e,
                                from: t
                            }
                        });
                    },
                    _instrumentTryCatch: function() {
                        var t = this, e = t._wrappedBuiltIns;
                        function r(e) {
                            return function(r, n) {
                                for (var i = new Array(arguments.length), o = 0; o < i.length; ++o) i[o] = arguments[o];
                                var a = i[0];
                                return x(a) && (i[0] = t.wrap(a)), e.apply ? e.apply(this, i) : e(i[0], i[1]);
                            };
                        }
                        P(g, "setTimeout", r, e), P(g, "setInterval", r, e), g.requestAnimationFrame && P(g, "requestAnimationFrame", function(e) {
                            return function(r) {
                                return e(t.wrap(r));
                            };
                        }, e);
                    },
                    _instrumentBreadcrumbs: function() {
                        var t = this, e = this._globalOptions.autoBreadcrumbs, r = t._wrappedBuiltIns, n = g.chrome, i = !(n && n.app && n.app.runtime) && g.history && history.pushState;
                        if (e.location && i) {
                            var o = g.onpopstate;
                            g.onpopstate = function() {
                                var e = t._location.href;
                                if (t._captureUrlChange(t._lastHref, e), o) return o.apply(this, arguments);
                            }, P(history, "pushState", function(e) {
                                return function() {
                                    var r = arguments.length > 2 ? arguments[2] : void 0;
                                    return r && t._captureUrlChange(t._lastHref, r + ""), e.apply(this, arguments);
                                };
                            }, r);
                        }
                        if (e.console && console && console.log) {
                            var a = function(e, r) {
                                t.captureBreadcrumb({
                                    message: e,
                                    level: r.level,
                                    category: "console"
                                });
                            };
                            E([ "debug", "info", "warn", "error", "log" ], function(t, e) {
                                u(console, e, a);
                            });
                        }
                    },
                    _restoreBuiltIns: function() {
                        for (var t; this._wrappedBuiltIns.length; ) {
                            var e = (t = this._wrappedBuiltIns.shift())[0], r = t[1], n = t[2];
                            e[r] = n;
                        }
                    },
                    _drainPlugins: function() {
                        var t = this;
                        E(this._plugins, function(e, r) {
                            var n = r[0], i = r[1];
                            n.apply(t, [ t ].concat(i));
                        });
                    },
                    _parseDSN: function(t) {
                        var e = p.exec(t), r = {}, n = 7;
                        try {
                            for (;n--; ) r[f[n]] = e[n] || "";
                        } catch (e) {
                            throw new a("Invalid DSN: " + t);
                        }
                        if (r.pass && !this._globalOptions.allowSecretKey) throw new a("Do not specify your secret key in the DSN. See: http://bit.ly/raven-secret-key");
                        return r;
                    },
                    _getGlobalServer: function(t) {
                        var e = "//" + t.host + (t.port ? ":" + t.port : "");
                        return t.protocol && (e = t.protocol + ":" + e), e;
                    },
                    _handleOnErrorStackInfo: function() {
                        this._ignoreOnError || this._handleStackInfo.apply(this, arguments);
                    },
                    _handleStackInfo: function(t, e) {
                        var r = this._prepareFrames(t, e);
                        this._triggerEvent("handle", {
                            stackInfo: t,
                            options: e
                        }), this._processException(t.name, t.message, t.url, t.lineno, r, e);
                    },
                    _prepareFrames: function(t, e) {
                        var r = this, n = [];
                        if (t.stack && t.stack.length && (E(t.stack, function(e, i) {
                            var o = r._normalizeFrame(i, t.url);
                            o && n.push(o);
                        }), e && e.trimHeadFrames)) for (var i = 0; i < e.trimHeadFrames && i < n.length; i++) n[i].in_app = !1;
                        return n = n.slice(0, this._globalOptions.stackTraceLimit);
                    },
                    _normalizeFrame: function(t, e) {
                        var r = {
                            filename: t.url,
                            lineno: t.line,
                            colno: t.column,
                            function: t.func || "?"
                        };
                        return t.url || (r.filename = e), r.in_app = !(this._globalOptions.includePaths.test && !this._globalOptions.includePaths.test(r.filename) || /(Raven|TraceKit)\./.test(r.function) || /raven\.(min\.)?js$/.test(r.filename)), 
                        r;
                    },
                    _processException: function(t, e, r, n, i, o) {
                        var a;
                        if ((!this._globalOptions.ignoreErrors.test || !this._globalOptions.ignoreErrors.test(e)) && (e += "", 
                        i && i.length ? (r = i[0].filename || r, i.reverse(), a = {
                            frames: i
                        }) : r && (a = {
                            frames: [ {
                                filename: r,
                                lineno: n,
                                in_app: !0
                            } ]
                        }), (!this._globalOptions.ignoreUrls.test || !this._globalOptions.ignoreUrls.test(r)) && (!this._globalOptions.whitelistUrls.test || this._globalOptions.whitelistUrls.test(r)))) {
                            var s = O({
                                exception: {
                                    values: [ {
                                        type: t,
                                        value: e,
                                        stacktrace: a
                                    } ]
                                },
                                culprit: r
                            }, o);
                            this._send(s);
                        }
                    },
                    _trimPacket: function(t) {
                        var e = this._globalOptions.maxMessageLength;
                        if (t.message && (t.message = S(t.message, e)), t.exception) {
                            var r = t.exception.values[0];
                            r.value = S(r.value, e);
                        }
                        var n = t.request;
                        return n && (n.url && (n.url = S(n.url, this._globalOptions.maxUrlLength)), n.Referer && (n.Referer = S(n.Referer, this._globalOptions.maxUrlLength))), 
                        t.breadcrumbs && t.breadcrumbs.values && this._trimBreadcrumbs(t.breadcrumbs), t;
                    },
                    _trimBreadcrumbs: function(t) {
                        for (var e, r, n, i = [ "to", "from", "url" ], o = 0; o < t.values.length; ++o) if ((r = t.values[o]).hasOwnProperty("data") && c(r.data) && (s = r.data, 
                        !Object.isFrozen || !Object.isFrozen(s))) {
                            n = O({}, r.data);
                            for (var a = 0; a < i.length; ++a) e = i[a], n.hasOwnProperty(e) && n[e] && (n[e] = S(n[e], this._globalOptions.maxUrlLength));
                            t.values[o].data = n;
                        }
                        var s;
                    },
                    _getHttpData: function() {
                        var t = {
                            headers: {
                                "User-Agent": "weapp"
                            }
                        }, e = getCurrentPages();
                        return e && e.length && (t.url = e[e.length - 1].route), t;
                    },
                    _resetBackoff: function() {
                        this._backoffDuration = 0, this._backoffStart = null;
                    },
                    _shouldBackoff: function() {
                        return this._backoffDuration && h() - this._backoffStart < this._backoffDuration;
                    },
                    _isRepeatData: function(t) {
                        var e, r, n = this._lastData;
                        return !(!n || t.message !== n.message || t.culprit !== n.culprit) && (t.stacktrace || n.stacktrace ? I(t.stacktrace, n.stacktrace) : !t.exception && !n.exception || (e = t.exception, 
                        r = n.exception, !U(e, r) && (e = e.values[0], r = r.values[0], e.type === r.type && e.value === r.value && I(e.stacktrace, r.stacktrace))));
                    },
                    _setBackoffState: function(t) {
                        if (!this._shouldBackoff()) {
                            var e = t.status;
                            if (400 === e || 401 === e || 429 === e) {
                                var r;
                                try {
                                    r = t.getResponseHeader("Retry-After"), r = 1e3 * parseInt(r, 10);
                                } catch (t) {}
                                this._backoffDuration = r || 2 * this._backoffDuration || 1e3, this._backoffStart = h();
                            }
                        }
                    },
                    _send: function(t) {
                        var e = this._globalOptions, r = {
                            project: this._globalProject,
                            logger: e.logger,
                            platform: "javascript"
                        }, n = this._getHttpData();
                        n && (r.request = n), t.trimHeadFrames && delete t.trimHeadFrames, (t = O(r, t)).tags = O(O({}, this._globalContext.tags), t.tags), 
                        t.extra = O(O({}, this._globalContext.extra), t.extra), t.extra["session:duration"] = h() - this._startTime, 
                        this._breadcrumbs && this._breadcrumbs.length > 0 && (t.breadcrumbs = {
                            values: [].slice.call(this._breadcrumbs, 0)
                        }), k(t.tags) && delete t.tags, this._globalContext.user && (t.user = this._globalContext.user), 
                        e.environment && (t.environment = e.environment), e.release && (t.release = e.release), 
                        e.serverName && (t.server_name = e.serverName), x(e.dataCallback) && (t = e.dataCallback(t) || t), 
                        t && !k(t) && (x(e.shouldSendCallback) && !e.shouldSendCallback(t) || (this._shouldBackoff() ? this._logDebug("warn", "Raven dropped error due to backoff: ", t) : "number" == typeof e.sampleRate ? Math.random() < e.sampleRate && this._sendProcessedPayload(t) : this._sendProcessedPayload(t)));
                    },
                    _getUuid: function() {
                        return D();
                    },
                    _sendProcessedPayload: function(t, e) {
                        var r = this, n = this._globalOptions;
                        if (this.isSetup()) if (t = this._trimPacket(t), this._globalOptions.allowDuplicates || !this._isRepeatData(t)) {
                            this._lastEventId = t.event_id || (t.event_id = this._getUuid()), this._lastData = t, 
                            this._logDebug("debug", "Raven about to send:", t);
                            var i = {
                                sentry_version: "7",
                                sentry_client: "raven-weapp/" + this.VERSION,
                                sentry_key: this._globalKey
                            };
                            this._globalSecret && (i.sentry_secret = this._globalSecret);
                            var o = t.exception && t.exception.values[0];
                            this.captureBreadcrumb({
                                category: "sentry",
                                message: o ? (o.type ? o.type + ": " : "") + o.value : t.message,
                                event_id: t.event_id,
                                level: t.level || "error"
                            });
                            var a = this._globalEndpoint;
                            (n.transport || this._makeRequest).call(this, {
                                url: a,
                                auth: i,
                                data: t,
                                options: n,
                                onSuccess: function() {
                                    r._resetBackoff(), r._triggerEvent("success", {
                                        data: t,
                                        src: a
                                    }), e && e();
                                },
                                onError: function(n) {
                                    r._logDebug("error", "Raven transport failed to send: ", n), n.request && r._setBackoffState(n.request), 
                                    r._triggerEvent("failure", {
                                        data: t,
                                        src: a
                                    }), n = n || new Error("Raven send failed (no additional details provided)"), e && e(n);
                                }
                            });
                        } else this._logDebug("warn", "Raven dropped repeat event: ", t);
                    },
                    _makeRequest: function(t) {
                        "release" !== this._globalOptions.environment && "trial" !== this._globalOptions.environment || wx.request({
                            url: t.url + "?" + R(t.auth),
                            method: "POST",
                            header: {
                                "content-type": "text/plain;charset=UTF-8"
                            },
                            data: o(t.data),
                            success: function() {
                                t.onSuccess && t.onSuccess();
                            },
                            fail: function(e) {
                                t.onError && t.onError(e);
                            }
                        });
                    },
                    _logDebug: function(t) {
                        this._originalConsoleMethods[t] && this.debug && Function.apply.call(this._originalConsoleMethods[t], this._originalConsole, [].slice.call(arguments, 1));
                    },
                    _mergeContext: function(t, e) {
                        y(e) ? delete this._globalContext[t] : this._globalContext[t] = O(this._globalContext[t] || {}, e);
                    }
                };
                var b = Object.prototype;
                function y(t) {
                    return void 0 === t;
                }
                function x(t) {
                    return "function" == typeof t;
                }
                function w(t) {
                    return "[object String]" === b.toString.call(t);
                }
                function k(t) {
                    for (var e in t) return !1;
                    return !0;
                }
                function E(t, e) {
                    var r, n;
                    if (y(t.length)) for (r in t) C(t, r) && e.call(null, r, t[r]); else if (n = t.length) for (r = 0; r < n; r++) e.call(null, r, t[r]);
                }
                function O(t, e) {
                    return e ? (E(e, function(e, r) {
                        t[e] = r;
                    }), t) : t;
                }
                function S(t, e) {
                    return !e || t.length <= e ? t : t.substr(0, e) + "…";
                }
                function C(t, e) {
                    return b.hasOwnProperty.call(t, e);
                }
                function j(t) {
                    for (var e, r = [], n = 0, i = t.length; n < i; n++) w(e = t[n]) ? r.push(e.replace(/([.*+?^=!:${}()|\[\]\/\\])/g, "\\$1")) : e && e.source && r.push(e.source);
                    return new RegExp(r.join("|"), "i");
                }
                function R(t) {
                    var e = [];
                    return E(t, function(t, r) {
                        e.push(encodeURIComponent(t) + "=" + encodeURIComponent(r));
                    }), e.join("&");
                }
                function T(t) {
                    var e = t.match(/^(([^:\/?#]+):)?(\/\/([^\/?#]*))?([^?#]*)(\?([^#]*))?(#(.*))?$/);
                    if (!e) return {};
                    var r = e[6] || "", n = e[8] || "";
                    return {
                        protocol: e[2],
                        host: e[4],
                        path: e[5],
                        relative: e[5] + r + n
                    };
                }
                function D() {
                    var t = g.crypto || g.msCrypto;
                    if (!y(t) && t.getRandomValues) {
                        var e = new Uint16Array(8);
                        t.getRandomValues(e), e[3] = 4095 & e[3] | 16384, e[4] = 16383 & e[4] | 32768;
                        var r = function(t) {
                            for (var e = t.toString(16); e.length < 4; ) e = "0" + e;
                            return e;
                        };
                        return r(e[0]) + r(e[1]) + r(e[2]) + r(e[3]) + r(e[4]) + r(e[5]) + r(e[6]) + r(e[7]);
                    }
                    return "xxxxxxxxxxxx4xxxyxxxxxxxxxxxxxxx".replace(/[xy]/g, function(t) {
                        var e = 16 * Math.random() | 0;
                        return ("x" === t ? e : 3 & e | 8).toString(16);
                    });
                }
                function U(t, e) {
                    return !!(!!t ^ !!e);
                }
                function I(t, e) {
                    if (U(t, e)) return !1;
                    var r, n, i = t.frames, o = e.frames;
                    if (i.length !== o.length) return !1;
                    for (var a = 0; a < i.length; a++) if (r = i[a], n = o[a], r.filename !== n.filename || r.lineno !== n.lineno || r.colno !== n.colno || r.function !== n.function) return !1;
                    return !0;
                }
                function P(t, e, r, n) {
                    var i = t[e];
                    t[e] = r(i), n && n.push([ t, e, i ]);
                }
                "undefined" != typeof __DEV__ && __DEV__ && (m.utils = {
                    isUndefined: y,
                    isFunction: x,
                    isString: w,
                    isObject: c,
                    isEmptyObject: k,
                    isError: l,
                    each: E,
                    objectMerge: O,
                    truncate: S,
                    hasKey: C,
                    joinRegExp: j,
                    urlencode: R,
                    uuid4: D,
                    parseUrl: T,
                    fill: P
                }), m.prototype.setUser = m.prototype.setUserContext, m.prototype.setReleaseContext = m.prototype.setRelease, 
                r.exports = m;
            }).call(this, "undefined" != typeof global ? global : "undefined" != typeof self ? self : "undefined" != typeof window ? window : {});
        }, {
            "../vendor/TraceKit/tracekit": 6,
            "../vendor/json-stringify-safe/stringify": 7,
            "./configError": 1,
            "./console": 2,
            "./utils": 5
        } ],
        4: [ function(t, e, r) {
            (function(r) {
                var n = t("./raven"), i = "undefined" != typeof window ? window : void 0 !== r ? r : "undefined" != typeof self ? self : {}, o = i.Raven, a = new n();
                a.noConflict = function() {
                    return i.Raven = o, a;
                }, a.afterLoad(), e.exports = a;
            }).call(this, "undefined" != typeof global ? global : "undefined" != typeof self ? self : "undefined" != typeof window ? window : {});
        }, {
            "./raven": 3
        } ],
        5: [ function(e, r, n) {
            r.exports = {
                isObject: function(e) {
                    return "object" === t(e) && null !== e;
                },
                isError: function(t) {
                    switch (Object.prototype.toString.call(t)) {
                      case "[object Error]":
                      case "[object Exception]":
                      case "[object DOMException]":
                        return !0;

                      default:
                        return t instanceof Error;
                    }
                },
                wrappedCallback: function(t) {
                    return function(e, r) {
                        var n = t(e) || e;
                        return r && r(n) || n;
                    };
                }
            };
        }, {} ],
        6: [ function(t, e, r) {
            (function(r) {
                var n = t("../../src/utils"), i = {
                    collectWindowErrors: !0,
                    debug: !1
                }, o = "undefined" != typeof window ? window : void 0 !== r ? r : "undefined" != typeof self ? self : {}, a = [].slice, s = /^(?:[Uu]ncaught (?:exception: )?)?(?:((?:Eval|Internal|Range|Reference|Syntax|Type|URI|)Error): )?(.*)$/, l = function() {
                    var t = getCurrentPages();
                    return t && t.length ? t[t.length - 1].route : "";
                };
                i.report = function() {
                    var t, e, r = [], c = null, u = null, f = null;
                    function p(t, e) {
                        var n = null;
                        if (!e || i.collectWindowErrors) {
                            for (var o in r) if (r.hasOwnProperty(o)) try {
                                r[o].apply(null, [ t ].concat(a.call(arguments, 2)));
                            } catch (t) {
                                n = t;
                            }
                            if (n) throw n;
                        }
                    }
                    function h(e, r, o, a, c) {
                        if (f) i.computeStackTrace.augmentStackTraceWithInitialElement(f, r, o, e), g(); else if (c && n.isError(c)) p(i.computeStackTrace(c), !0); else {
                            var u, h = {
                                url: r,
                                line: o,
                                column: a
                            }, d = void 0, _ = e;
                            "[object String]" === {}.toString.call(e) && (u = e.match(s)) && (d = u[1], _ = u[2]), 
                            h.func = "?", p({
                                name: d,
                                message: _,
                                url: l(),
                                stack: [ h ]
                            }, !0);
                        }
                        return !!t && t.apply(this, arguments);
                    }
                    function g() {
                        var t = f, e = c;
                        c = null, f = null, u = null, p.apply(null, [ t, !1 ].concat(e));
                    }
                    function d(t, e) {
                        var r = a.call(arguments, 1);
                        if (f) {
                            if (u === t) return;
                            g();
                        }
                        var n = i.computeStackTrace(t);
                        if (f = n, u = t, c = r, setTimeout(function() {
                            u === t && g();
                        }, n.incomplete ? 2e3 : 0), !1 !== e) throw t;
                    }
                    return d.subscribe = function(n) {
                        e || (t = o.onerror, o.onerror = h, e = !0), r.push(n);
                    }, d.unsubscribe = function(t) {
                        for (var e = r.length - 1; e >= 0; --e) r[e] === t && r.splice(e, 1);
                    }, d.uninstall = function() {
                        e && (o.onerror = t, e = !1, t = void 0), r = [];
                    }, d;
                }(), i.computeStackTrace = function() {
                    function t(t) {
                        if (void 0 !== t.stack && t.stack) {
                            for (var e, r, n, i = /^\s*at (.*?) ?\(((?:file|https?|blob|chrome-extension|native|eval|webpack|<anonymous>|\/).*?)(?::(\d+))?(?::(\d+))?\)?\s*$/i, o = /\((\S*)(?::(\d+))(?::(\d+))\)/, a = t.stack.split("\n"), s = [], c = (/^(.*) is undefined$/.exec(t.message), 
                            0), u = a.length; c < u; ++c) if (r = i.exec(a[c])) {
                                var f = r[2] && 0 === r[2].indexOf("native");
                                r[2] && 0 === r[2].indexOf("eval") && (e = o.exec(r[2])) && (r[2] = e[1], r[3] = e[2], 
                                r[4] = e[3]), !(n = {
                                    url: f ? null : r[2],
                                    func: r[1] || "?",
                                    args: f ? [ r[2] ] : [],
                                    line: r[3] ? +r[3] : null,
                                    column: r[4] ? +r[4] : null
                                }).func && n.line && (n.func = "?"), s.push(n);
                            }
                            return s.length ? {
                                name: t.name,
                                message: t.message,
                                url: l(),
                                stack: s
                            } : null;
                        }
                    }
                    function e(t, e, r, n) {
                        var i = {
                            url: e,
                            line: r
                        };
                        if (i.url && i.line) {
                            if (t.incomplete = !1, i.func || (i.func = "?"), t.stack.length > 0 && t.stack[0].url === i.url) {
                                if (t.stack[0].line === i.line) return !1;
                                if (!t.stack[0].line && t.stack[0].func === i.func) return t.stack[0].line = i.line, 
                                !1;
                            }
                            return t.stack.unshift(i), t.partial = !0, !0;
                        }
                        return t.incomplete = !0, !1;
                    }
                    function r(t, o) {
                        for (var a, s, c = /function\s+([_$a-zA-Z\xA0-\uFFFF][_$a-zA-Z0-9\xA0-\uFFFF]*)?\s*\(/i, u = [], f = {}, p = !1, h = r.caller; h && !p; h = h.caller) if (h !== n && h !== i.report) {
                            if (s = {
                                url: null,
                                func: "?",
                                line: null,
                                column: null
                            }, h.name ? s.func = h.name : (a = c.exec(h.toString())) && (s.func = a[1]), void 0 === s.func) try {
                                s.func = a.input.substring(0, a.input.indexOf("{"));
                            } catch (t) {}
                            f["" + h] ? p = !0 : f["" + h] = !0, u.push(s);
                        }
                        o && u.splice(0, o);
                        var g = {
                            name: t.name,
                            message: t.message,
                            url: l(),
                            stack: u
                        };
                        return e(g, t.sourceURL || t.fileName, t.line || t.lineNumber, t.message || t.description), 
                        g;
                    }
                    function n(e, n) {
                        var o = null;
                        n = null == n ? 0 : +n;
                        try {
                            if (o = t(e)) return o;
                        } catch (t) {
                            if (i.debug) throw t;
                        }
                        try {
                            if (o = r(e, n + 1)) return o;
                        } catch (t) {
                            if (i.debug) throw t;
                        }
                        return {
                            name: e.name,
                            message: e.message,
                            url: l()
                        };
                    }
                    return n.augmentStackTraceWithInitialElement = e, n.computeStackTraceFromStackProp = t, 
                    n;
                }(), e.exports = i;
            }).call(this, "undefined" != typeof global ? global : "undefined" != typeof self ? self : "undefined" != typeof window ? window : {});
        }, {
            "../../src/utils": 5
        } ],
        7: [ function(t, e, r) {
            function n(t, e) {
                for (var r = 0; r < t.length; ++r) if (t[r] === e) return r;
                return -1;
            }
            function i(t, e) {
                var r = [], i = [];
                return null == e && (e = function(t, e) {
                    return r[0] === e ? "[Circular ~]" : "[Circular ~." + i.slice(0, n(r, e)).join(".") + "]";
                }), function(o, a) {
                    if (r.length > 0) {
                        var s = n(r, this);
                        ~s ? r.splice(s + 1) : r.push(this), ~s ? i.splice(s, 1 / 0, o) : i.push(o), ~n(r, a) && (a = e.call(this, o, a));
                    } else r.push(a);
                    return null == t ? a : t.call(this, o, a);
                };
            }
            (e.exports = function(t, e, r, n) {
                return JSON.stringify(t, i(e, n), r);
            }).getSerialize = i;
        }, {} ]
    }, {}, [ 4 ])(4);
} ]);