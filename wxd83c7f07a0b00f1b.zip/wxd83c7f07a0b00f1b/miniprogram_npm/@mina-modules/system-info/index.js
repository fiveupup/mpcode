require("../../../@babel/runtime/helpers/Arrayincludes");

var e = require("../../../@babel/runtime/helpers/typeof");

!function() {
    var r = {
        d: function(e, t) {
            for (var n in t) r.o(t, n) && !r.o(e, n) && Object.defineProperty(e, n, {
                enumerable: !0,
                get: t[n]
            });
        },
        o: function(e, r) {
            return Object.prototype.hasOwnProperty.call(e, r);
        },
        r: function(e) {
            "undefined" != typeof Symbol && Symbol.toStringTag && Object.defineProperty(e, Symbol.toStringTag, {
                value: "Module"
            }), Object.defineProperty(e, "__esModule", {
                value: !0
            });
        }
    }, t = {};
    function n(e, r) {
        var t = Object.keys(e);
        if (Object.getOwnPropertySymbols) {
            var n = Object.getOwnPropertySymbols(e);
            r && (n = n.filter(function(r) {
                return Object.getOwnPropertyDescriptor(e, r).enumerable;
            })), t.push.apply(t, n);
        }
        return t;
    }
    function o(e) {
        for (var r = 1; r < arguments.length; r++) {
            var t = null != arguments[r] ? arguments[r] : {};
            r % 2 ? n(Object(t), !0).forEach(function(r) {
                i(e, r, t[r]);
            }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(t)) : n(Object(t)).forEach(function(r) {
                Object.defineProperty(e, r, Object.getOwnPropertyDescriptor(t, r));
            });
        }
        return e;
    }
    function i(r, t, n) {
        return (t = function(r) {
            var t = function(r, t) {
                if ("object" !== e(r) || null === r) return r;
                var n = r[Symbol.toPrimitive];
                if (void 0 !== n) {
                    var o = n.call(r, t || "default");
                    if ("object" !== e(o)) return o;
                    throw new TypeError("@@toPrimitive must return a primitive value.");
                }
                return ("string" === t ? String : Number)(r);
            }(r, "string");
            return "symbol" === e(t) ? t : String(t);
        }(t)) in r ? Object.defineProperty(r, t, {
            value: n,
            enumerable: !0,
            configurable: !0,
            writable: !0
        }) : r[t] = n, r;
    }
    r.r(t), r.d(t, {
        getSysInfo: function() {
            return u;
        }
    });
    var a = {
        navBarHeight: 0,
        isReady: !1,
        isCustomNavBar: !0,
        IPX: !1
    };
    function u() {
        var e = !(arguments.length > 0 && void 0 !== arguments[0]) || arguments[0];
        if (a.isReady) return a;
        var r = wx.getSystemInfoSync(), t = !!(r.platform.toLowerCase().search("ios") + 1) || !!(r.platform.toLowerCase().search("devtools") + 1);
        return (a = o(o(o({}, a), r), {}, {
            statusBarHeight: s(r)
        })).isCustomNavBar = e, a.isPromiseApi = c(a.SDKVersion, "2.12.0") > -1, a.navBarHeight = a.isCustomNavBar ? a.statusBarHeight + 44 : 0, 
        a.iOS = t, a.IPX = a.statusBarHeight > 40 && t, a.android = "android" === a.platform, 
        a.isReady = !0, a;
    }
    function s(e) {
        return [ "mac", "windows" ].includes(e.platform) ? 0 : e.statusBarHeight || 20;
    }
    function c(e, r) {
        if (!e || !r) return 0;
        e = e.split("."), r = r.split(".");
        for (var t = Math.max(e.length, r.length), n = 0; n < t; n++) {
            var o = parseInt(e[n] || "0"), i = parseInt(r[n] || "0");
            if (o !== i) return o > i ? 1 : -1;
        }
        return 0;
    }
    module.exports = t;
}();