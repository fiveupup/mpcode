require("../../@babel/runtime/helpers/Objectentries");

var e = require("../../@babel/runtime/helpers/typeof");

Object.defineProperty(exports, "__esModule", {
    value: !0
});

var t = function(e, n) {
    return (t = Object.setPrototypeOf || {
        __proto__: []
    } instanceof Array && function(e, t) {
        e.__proto__ = t;
    } || function(e, t) {
        for (var n in t) t.hasOwnProperty(n) && (e[n] = t[n]);
    })(e, n);
};

function n(e, n) {
    function r() {
        this.constructor = e;
    }
    t(e, n), e.prototype = null === n ? Object.create(n) : (r.prototype = n.prototype, 
    new r());
}

var r = function() {
    return (r = Object.assign || function(e) {
        for (var t, n = 1, r = arguments.length; n < r; n++) for (var o in t = arguments[n]) Object.prototype.hasOwnProperty.call(t, o) && (e[o] = t[o]);
        return e;
    }).apply(this, arguments);
};

function o(e, t) {
    var n = "function" == typeof Symbol && e[Symbol.iterator];
    if (!n) return e;
    var r, o, i = n.call(e), a = [];
    try {
        for (;(void 0 === t || 0 < t--) && !(r = i.next()).done; ) a.push(r.value);
    } catch (e) {
        o = {
            error: e
        };
    } finally {
        try {
            r && !r.done && (n = i.return) && n.call(i);
        } finally {
            if (o) throw o.error;
        }
    }
    return a;
}

function i() {
    for (var e = [], t = 0; t < arguments.length; t++) e = e.concat(o(arguments[t]));
    return e;
}

var a = [], s = (Object.freeze(a), {});

function u() {
    return "undefined" != typeof window ? window : global;
}

function c() {
    return ++je.mobxGuid;
}

function l(e) {
    throw p(!1, e), "X";
}

function p(e, t) {
    if (!e) throw new Error("[mobx] " + (t || "An invariant failed, however the error is obfuscated because this is an production build."));
}

Object.freeze(s);

function f(e) {
    var t = !1;
    return function() {
        if (!t) return t = !0, e.apply(this, arguments);
    };
}

var h = function() {};

function d(t) {
    return null !== t && "object" == e(t);
}

function v(t) {
    return null !== t && "object" == e(t) && ((t = Object.getPrototypeOf(t)) === Object.prototype || null === t);
}

function y(e, t, n) {
    Object.defineProperty(e, t, {
        enumerable: !1,
        writable: !0,
        configurable: !0,
        value: n
    });
}

function b(e, t, n) {
    Object.defineProperty(e, t, {
        enumerable: !1,
        writable: !1,
        configurable: !0,
        value: n
    });
}

function m(e, t) {
    var n = "isMobX" + e;
    return t.prototype[n] = !0, function(e) {
        return d(e) && !0 === e[n];
    };
}

function g(e) {
    return void 0 !== u().Map && e instanceof u().Map;
}

function x(e) {
    return e instanceof Set;
}

function _(e) {
    for (var t = []; ;) {
        var n = e.next();
        if (n.done) break;
        t.push(n.value);
    }
    return t;
}

function O() {
    return "function" == typeof Symbol && Symbol.toPrimitive || "@@toPrimitive";
}

function w(t) {
    return null === t ? null : "object" == e(t) ? "" + t : t;
}

function S() {
    return "function" == typeof Symbol && Symbol.iterator || "@@iterator";
}

function A(e, t) {
    b(e, S(), t);
}

function E(e) {
    return e[S()] = j, e;
}

function D() {
    return "function" == typeof Symbol && Symbol.toStringTag || "@@toStringTag";
}

function j() {
    return this;
}

var k = function() {
    function e(e) {
        void 0 === e && (e = "Atom@" + c()), this.name = e, this.isPendingUnobservation = !1, 
        this.isBeingObserved = !1, this.observers = [], this.observersIndexes = {}, this.diffValue = 0, 
        this.lastAccessedBy = 0, this.lowestObserverState = exports.IDerivationState.NOT_TRACKING;
    }
    return e.prototype.onBecomeUnobserved = function() {}, e.prototype.onBecomeObserved = function() {}, 
    e.prototype.reportObserved = function() {
        return Ne(this);
    }, e.prototype.reportChanged = function() {
        Ce(), function(e) {
            if (e.lowestObserverState !== exports.IDerivationState.STALE) {
                e.lowestObserverState = exports.IDerivationState.STALE;
                for (var t = e.observers, n = t.length; n--; ) {
                    var r = t[n];
                    r.dependenciesState === exports.IDerivationState.UP_TO_DATE && (r.isTracing !== pe.NONE && Re(r, e), 
                    r.onBecomeStale()), r.dependenciesState = exports.IDerivationState.STALE;
                }
            }
        }(this), Ve();
    }, e.prototype.toString = function() {
        return this.name;
    }, e;
}(), T = m("Atom", k);

function I(e, t, n) {
    return void 0 === t && (t = h), void 0 === n && (n = h), tt(e = new k(e), t), nt(e, n), 
    e;
}

function C(e, t) {
    return e === t;
}

var V = {
    identity: C,
    structural: function(e, t) {
        return on(e, t);
    },
    default: function(e, t) {
        return function(e, t) {
            return "number" == typeof e && "number" == typeof t && isNaN(e) && isNaN(t);
        }(e, t) || C(e, t);
    }
}, N = {}, R = {};

function P(e, t) {
    var n = t ? N : R;
    return n[e] || (n[e] = {
        configurable: !0,
        enumerable: t,
        get: function() {
            return L(this), this[e];
        },
        set: function(t) {
            L(this), this[e] = t;
        }
    });
}

function L(e) {
    if (!0 !== e.__mobxDidRunLazyInitializers) {
        var t = e.__mobxDecorators;
        if (t) for (var n in y(e, "__mobxDidRunLazyInitializers", !0), t) (n = t[n]).propertyCreator(e, n.prop, n.descriptor, n.decoratorTarget, n.decoratorArguments);
    }
}

function B(e, t) {
    return function() {
        function n(n, i, a, s) {
            return !0 === s ? (t(n, i, a, n, o), null) : (Object.prototype.hasOwnProperty.call(n, "__mobxDecorators") || (s = n.__mobxDecorators, 
            y(n, "__mobxDecorators", r({}, s))), n.__mobxDecorators[i] = {
                prop: i,
                propertyCreator: t,
                descriptor: a,
                decoratorTarget: n,
                decoratorArguments: o
            }, P(i, e));
        }
        var o;
        return $(arguments) ? (o = a, n.apply(null, arguments)) : (o = Array.prototype.slice.call(arguments), 
        n);
    };
}

function $(e) {
    return (2 === e.length || 3 === e.length) && "string" == typeof e[1] || 4 === e.length && !0 === e[3];
}

function M(e, t, n) {
    return ft(e) ? e : Array.isArray(e) ? Q.array(e, {
        name: n
    }) : v(e) ? Q.object(e, void 0, {
        name: n
    }) : g(e) ? Q.map(e, {
        name: n
    }) : x(e) ? Q.set(e, {
        name: n
    }) : e;
}

function U(e) {
    return e;
}

function G(e) {
    var t = B(!0, function(t, n, r, o, i) {
        Jt(t, n, r ? r.initializer ? r.initializer.call(t) : r.value : void 0, e);
    });
    return t.enhancer = e, t;
}

var H = {
    deep: !0,
    name: void 0,
    defaultDecorator: void 0
}, K = {
    deep: !1,
    name: void 0,
    defaultDecorator: void 0
};

function z(e) {
    return null == e ? H : "string" == typeof e ? {
        name: e,
        deep: !0
    } : e;
}

function W(e) {
    return e.defaultDecorator ? e.defaultDecorator.enhancer : !1 === e.deep ? U : M;
}

Object.freeze(H), Object.freeze(K);

var q = G(M), J = G(function(e, t, n) {
    return null == e || Zt(e) || Bt(e) || Gt(e) || zt(e) ? e : Array.isArray(e) ? Q.array(e, {
        name: n,
        deep: !1
    }) : v(e) ? Q.object(e, void 0, {
        name: n,
        deep: !1
    }) : g(e) ? Q.map(e, {
        name: n,
        deep: !1
    }) : x(e) ? Q.set(e, {
        name: n,
        deep: !1
    }) : l(!1);
}), X = G(U), Y = G(function(e, t, n) {
    return on(e, t) ? t : e;
});

var F = {
    box: function(e, t) {
        return 2 < arguments.length && Z("box"), t = z(t), new ue(e, W(t), t.name, !0, t.equals);
    },
    shallowBox: function(e, t) {
        return 2 < arguments.length && Z("shallowBox"), Q.box(e, {
            name: t,
            deep: !1
        });
    },
    array: function(e, t) {
        return 2 < arguments.length && Z("array"), t = z(t), new Ct(e, W(t), t.name);
    },
    shallowArray: function(e, t) {
        return 2 < arguments.length && Z("shallowArray"), Q.array(e, {
            name: t,
            deep: !1
        });
    },
    map: function(e, t) {
        return 2 < arguments.length && Z("map"), t = z(t), new Mt(e, W(t), t.name);
    },
    shallowMap: function(e, t) {
        return 2 < arguments.length && Z("shallowMap"), Q.map(e, {
            name: t,
            deep: !1
        });
    },
    set: function(e, t) {
        return 2 < arguments.length && Z("set"), t = z(t), new Kt(e, W(t), t.name);
    },
    object: function(e, t, n) {
        return "string" == typeof t && Z("object"), ot({}, e, t, z(n));
    },
    shallowObject: function(e, t) {
        return "string" == typeof t && Z("shallowObject"), Q.object(e, {}, {
            name: t,
            deep: !1
        });
    },
    ref: X,
    shallow: J,
    deep: q,
    struct: Y
}, Q = function(e, t, n) {
    return "string" == typeof t ? q.apply(null, arguments) : ft(e) ? e : (n = v(e) ? Q.object(e, t, n) : Array.isArray(e) ? Q.array(e, t) : g(e) ? Q.map(e, t) : x(e) ? Q.set(e, t) : e) !== e ? n : void l(!1);
};

function Z(e) {
    l("Expected one or two arguments to observable." + e + ". Did you accidentally try to use observable." + e + " as decorator?");
}

Object.keys(F).forEach(function(e) {
    return Q[e] = F[e];
});

var ee = B(!1, function(e, t, n, o, i) {
    var a = n.get;
    n = n.set, i = i[0] || {};
    !function(e, t, n) {
        var r = qt(e);
        n.name = r.name + "." + t, n.context = e, r.values[t] = new le(n), Object.defineProperty(e, t, function(e) {
            return Yt[e] || (Yt[e] = {
                configurable: je.computedConfigurable,
                enumerable: !1,
                get: function() {
                    return Ft(this).read(this, e);
                },
                set: function(t) {
                    Ft(this).write(this, e, t);
                }
            });
        }(t));
    }(e, t, r({
        get: a,
        set: n
    }, i));
}), te = ee({
    equals: V.structural
}), ne = function(t, n, r) {
    if ("string" == typeof n) return ee.apply(null, arguments);
    if (null !== t && "object" == e(t) && 1 === arguments.length) return ee.apply(null, arguments);
    var o = "object" == e(n) ? n : {};
    return o.get = t, o.set = "function" == typeof n ? n : o.set, o.name = o.name || t.name || "", 
    new le(o);
};

function re(e, t) {
    function n() {
        return oe(e, t, this, arguments);
    }
    return n.isMobxAction = !0, n;
}

function oe(e, t, n, r) {
    e = function(e, t, n, r) {
        var o = Ue() && !!e, i = 0;
        if (o) {
            i = Date.now();
            var a = r && r.length || 0, s = new Array(a);
            if (0 < a) for (var u = 0; u < a; u++) s[u] = r[u];
            He({
                type: "action",
                name: e,
                object: n,
                arguments: s
            });
        }
        return e = _e(), Ce(), {
            prevDerivation: e,
            prevAllowStateChanges: ae(!0),
            notifySpy: o,
            startTime: i
        };
    }(e, 0, n, r);
    var o = !0;
    try {
        var i = t.apply(n, r);
        o = !1;
        return i;
    } finally {
        o ? (je.suppressReactionErrors = o, ie(e), je.suppressReactionErrors = !1) : ie(e);
    }
}

function ie(e) {
    se(e.prevAllowStateChanges), Ve(), Oe(e.prevDerivation), e.notifySpy && ze({
        time: Date.now() - e.startTime
    });
}

function ae(e) {
    var t = je.allowStateChanges;
    return je.allowStateChanges = e, t;
}

function se(e) {
    je.allowStateChanges = e;
}

ne.struct = te;

var ue = function(e) {
    function t(t, n, r, o, i) {
        void 0 === r && (r = "ObservableValue@" + c()), void 0 === o && (o = !0), void 0 === i && (i = V.default);
        var a = e.call(this, r) || this;
        return a.enhancer = n, a.name = r, a.equals = i, a.hasUnreportedChange = !1, a.value = n(t, void 0, r), 
        o && Ue() && Ge({
            type: "create",
            name: a.name,
            newValue: "" + a.value
        }), a;
    }
    return n(t, e), t.prototype.dehanceValue = function(e) {
        return void 0 !== this.dehancer ? this.dehancer(e) : e;
    }, t.prototype.set = function(e) {
        var t, n = this.value;
        (e = this.prepareNewValue(e)) !== je.UNCHANGED && ((t = Ue()) && He({
            type: "update",
            name: this.name,
            newValue: e,
            oldValue: n
        }), this.setNewValue(e), t && ze());
    }, t.prototype.prepareNewValue = function(e) {
        if (be(this), Ot(this)) {
            var t = St(this, {
                object: this,
                type: "update",
                newValue: e
            });
            if (!t) return je.UNCHANGED;
            e = t.newValue;
        }
        return e = this.enhancer(e, this.value, this.name), this.equals(this.value, e) ? je.UNCHANGED : e;
    }, t.prototype.setNewValue = function(e) {
        var t = this.value;
        this.value = e, this.reportChanged(), At(this) && Dt(this, {
            type: "update",
            object: this,
            newValue: e,
            oldValue: t
        });
    }, t.prototype.get = function() {
        return this.reportObserved(), this.dehanceValue(this.value);
    }, t.prototype.intercept = function(e) {
        return wt(this, e);
    }, t.prototype.observe = function(e, t) {
        return t && e({
            object: this,
            type: "update",
            newValue: this.value,
            oldValue: void 0
        }), Et(this, e);
    }, t.prototype.toJSON = function() {
        return this.get();
    }, t.prototype.toString = function() {
        return this.name + "[" + this.value + "]";
    }, t.prototype.valueOf = function() {
        return w(this.get());
    }, t;
}(k), ce = (ue.prototype[O()] = ue.prototype.valueOf, m("ObservableValue", ue)), le = function() {
    function e(e) {
        this.dependenciesState = exports.IDerivationState.NOT_TRACKING, this.observing = [], 
        this.newObserving = null, this.isBeingObserved = !1, this.isPendingUnobservation = !1, 
        this.observers = [], this.observersIndexes = {}, this.diffValue = 0, this.runId = 0, 
        this.lastAccessedBy = 0, this.lowestObserverState = exports.IDerivationState.UP_TO_DATE, 
        this.unboundDepsCount = 0, this.__mapid = "#" + c(), this.value = new de(null), 
        this.isComputing = !1, this.isRunningSetter = !1, this.isTracing = pe.NONE, this.derivation = e.get, 
        this.name = e.name || "ComputedValue@" + c(), e.set && (this.setter = re(this.name + "-setter", e.set)), 
        this.equals = e.equals || (e.compareStructural || e.struct ? V.structural : V.default), 
        this.scope = e.context, this.requiresReaction = !!e.requiresReaction, this.keepAlive = !!e.keepAlive;
    }
    return e.prototype.onBecomeStale = function() {
        !function(e) {
            if (e.lowestObserverState === exports.IDerivationState.UP_TO_DATE) {
                e.lowestObserverState = exports.IDerivationState.POSSIBLY_STALE;
                for (var t = e.observers, n = t.length; n--; ) {
                    var r = t[n];
                    r.dependenciesState === exports.IDerivationState.UP_TO_DATE && (r.dependenciesState = exports.IDerivationState.POSSIBLY_STALE, 
                    r.isTracing !== pe.NONE && Re(r, e), r.onBecomeStale());
                }
            }
        }(this);
    }, e.prototype.onBecomeUnobserved = function() {}, e.prototype.onBecomeObserved = function() {}, 
    e.prototype.get = function() {
        this.isComputing && l("Cycle detected in computation " + this.name + ": " + this.derivation), 
        0 !== je.inBatch || 0 !== this.observers.length || this.keepAlive ? (Ne(this), ye(this) && this.trackAndCompute() && function(e) {
            if (e.lowestObserverState !== exports.IDerivationState.STALE) {
                e.lowestObserverState = exports.IDerivationState.STALE;
                for (var t = e.observers, n = t.length; n--; ) {
                    var r = t[n];
                    r.dependenciesState === exports.IDerivationState.POSSIBLY_STALE ? r.dependenciesState = exports.IDerivationState.STALE : r.dependenciesState === exports.IDerivationState.UP_TO_DATE && (e.lowestObserverState = exports.IDerivationState.UP_TO_DATE);
                }
            }
        }(this)) : ye(this) && (this.warnAboutUntrackedRead(), Ce(), this.value = this.computeValue(!1), 
        Ve());
        var e = this.value;
        if (ve(e)) throw e.cause;
        return e;
    }, e.prototype.peek = function() {
        var e = this.computeValue(!1);
        if (ve(e)) throw e.cause;
        return e;
    }, e.prototype.set = function(e) {
        if (this.setter) {
            p(!this.isRunningSetter, "The setter of computed value '" + this.name + "' is trying to update itself. Did you intend to update an _observable_ value, instead of the computed property?"), 
            this.isRunningSetter = !0;
            try {
                this.setter.call(this.scope, e);
            } finally {
                this.isRunningSetter = !1;
            }
        } else p(!1, !1);
    }, e.prototype.trackAndCompute = function() {
        Ue() && Ge({
            object: this.scope,
            type: "compute",
            name: this.name
        });
        var e = this.value, t = this.dependenciesState === exports.IDerivationState.NOT_TRACKING, n = this.computeValue(!0);
        return (t = t || ve(e) || ve(n) || !this.equals(e, n)) && (this.value = n), t;
    }, e.prototype.computeValue = function(e) {
        var t;
        if (this.isComputing = !0, je.computationDepth++, e) t = me(this, this.derivation, this.scope); else if (!0 === je.disableErrorBoundaries) t = this.derivation.call(this.scope); else try {
            t = this.derivation.call(this.scope);
        } catch (e) {
            t = new de(e);
        }
        return je.computationDepth--, this.isComputing = !1, t;
    }, e.prototype.suspend = function() {
        this.keepAlive || (ge(this), this.value = void 0);
    }, e.prototype.observe = function(e, t) {
        var n = this, r = !0, o = void 0;
        return Qe(function() {
            var i, a = n.get();
            r && !t || (i = _e(), e({
                type: "update",
                object: n,
                newValue: a,
                oldValue: o
            }), Oe(i)), r = !1, o = a;
        });
    }, e.prototype.warnAboutUntrackedRead = function() {}, e.prototype.toJSON = function() {
        return this.get();
    }, e.prototype.toString = function() {
        return this.name + "[" + this.derivation.toString() + "]";
    }, e.prototype.valueOf = function() {
        return w(this.get());
    }, e;
}();

le.prototype[O()] = le.prototype.valueOf;

var pe, fe, he = m("ComputedValue", le), de = ((fe = exports.IDerivationState || (exports.IDerivationState = {}))[fe.NOT_TRACKING = -1] = "NOT_TRACKING", 
fe[fe.UP_TO_DATE = 0] = "UP_TO_DATE", fe[fe.POSSIBLY_STALE = 1] = "POSSIBLY_STALE", 
fe[fe.STALE = 2] = "STALE", function(e) {
    e[e.NONE = 0] = "NONE", e[e.LOG = 1] = "LOG", e[e.BREAK = 2] = "BREAK";
}(pe = pe || {}), function(e) {
    this.cause = e;
});

function ve(e) {
    return e instanceof de;
}

function ye(e) {
    switch (e.dependenciesState) {
      case exports.IDerivationState.UP_TO_DATE:
        return !1;

      case exports.IDerivationState.NOT_TRACKING:
      case exports.IDerivationState.STALE:
        return !0;

      case exports.IDerivationState.POSSIBLY_STALE:
        for (var t = _e(), n = e.observing, r = n.length, o = 0; o < r; o++) {
            var i = n[o];
            if (he(i)) {
                if (je.disableErrorBoundaries) i.get(); else try {
                    i.get();
                } catch (e) {
                    return Oe(t), !0;
                }
                if (e.dependenciesState === exports.IDerivationState.STALE) return Oe(t), !0;
            }
        }
        return we(e), Oe(t), !1;
    }
}

function be(e) {
    e = 0 < e.observers.length, 0 < je.computationDepth && e && l(!1), je.allowStateChanges || !e && "strict" !== je.enforceActions || l(!1);
}

function me(e, t, n) {
    we(e), e.newObserving = new Array(e.observing.length + 100), e.unboundDepsCount = 0, 
    e.runId = ++je.runId;
    var r, o = je.trackingDerivation;
    if (je.trackingDerivation = e, !0 === je.disableErrorBoundaries) r = t.call(n); else try {
        r = t.call(n);
    } catch (e) {
        r = new de(e);
    }
    return je.trackingDerivation = o, function(e) {
        for (var t, n = e.observing, r = e.observing = e.newObserving, o = exports.IDerivationState.UP_TO_DATE, i = 0, a = e.unboundDepsCount, s = 0; s < a; s++) 0 === (t = r[s]).diffValue && (t.diffValue = 1, 
        i !== s && (r[i] = t), i++), t.dependenciesState > o && (o = t.dependenciesState);
        for (r.length = i, e.newObserving = null, a = n.length; a--; ) 0 === (t = n[a]).diffValue && Te(t, e), 
        t.diffValue = 0;
        for (;i--; ) 1 === (t = r[i]).diffValue && (t.diffValue = 0, ke(t, e));
        o !== exports.IDerivationState.UP_TO_DATE && (e.dependenciesState = o, e.onBecomeStale());
    }(e), r;
}

function ge(e) {
    var t = e.observing;
    e.observing = [];
    for (var n = t.length; n--; ) Te(t[n], e);
    e.dependenciesState = exports.IDerivationState.NOT_TRACKING;
}

function xe(e) {
    var t = _e();
    e = e();
    return Oe(t), e;
}

function _e() {
    var e = je.trackingDerivation;
    return je.trackingDerivation = null, e;
}

function Oe(e) {
    je.trackingDerivation = e;
}

function we(e) {
    if (e.dependenciesState !== exports.IDerivationState.UP_TO_DATE) {
        e.dependenciesState = exports.IDerivationState.UP_TO_DATE;
        for (var t = e.observing, n = t.length; n--; ) t[n].lowestObserverState = exports.IDerivationState.UP_TO_DATE;
    }
}

var Se = [ "mobxGuid", "spyListeners", "enforceActions", "computedRequiresReaction", "disableErrorBoundaries", "runId", "UNCHANGED" ], Ae = function() {
    this.version = 5, this.UNCHANGED = {}, this.trackingDerivation = null, this.computationDepth = 0, 
    this.runId = 0, this.mobxGuid = 0, this.inBatch = 0, this.pendingUnobservations = [], 
    this.pendingReactions = [], this.isRunningReactions = !1, this.allowStateChanges = !0, 
    this.enforceActions = !1, this.spyListeners = [], this.globalReactionErrorHandlers = [], 
    this.computedRequiresReaction = !1, this.computedConfigurable = !1, this.disableErrorBoundaries = !1, 
    this.suppressReactionErrors = !1;
}, Ee = !0, De = !1, je = function() {
    var e = u();
    return 0 < e.__mobxInstanceCount && !e.__mobxGlobals && (Ee = !1), (Ee = (!e.__mobxGlobals || e.__mobxGlobals.version === new Ae().version) && Ee) ? e.__mobxGlobals ? (e.__mobxInstanceCount += 1, 
    e.__mobxGlobals.UNCHANGED || (e.__mobxGlobals.UNCHANGED = {}), e.__mobxGlobals) : (e.__mobxInstanceCount = 1, 
    e.__mobxGlobals = new Ae()) : (setTimeout(function() {
        De || l("There are multiple, different versions of MobX active. Make sure MobX is loaded only once or use `configure({ isolateGlobalState: true })`");
    }, 1), new Ae());
}();

function ke(e, t) {
    var n = e.observers.length;
    n && (e.observersIndexes[t.__mapid] = n), e.observers[n] = t, e.lowestObserverState > t.dependenciesState && (e.lowestObserverState = t.dependenciesState);
}

function Te(e, t) {
    var n, r, o;
    1 === e.observers.length ? (e.observers.length = 0, Ie(e)) : (n = e.observers, e = e.observersIndexes, 
    (r = n.pop()) !== t && ((o = e[t.__mapid] || 0) ? e[r.__mapid] = o : delete e[r.__mapid], 
    n[o] = r), delete e[t.__mapid]);
}

function Ie(e) {
    !1 === e.isPendingUnobservation && (e.isPendingUnobservation = !0, je.pendingUnobservations.push(e));
}

function Ce() {
    je.inBatch++;
}

function Ve() {
    if (0 == --je.inBatch) {
        Be();
        for (var e = je.pendingUnobservations, t = 0; t < e.length; t++) {
            var n = e[t];
            n.isPendingUnobservation = !1, 0 === n.observers.length && (n.isBeingObserved && (n.isBeingObserved = !1, 
            n.onBecomeUnobserved()), n instanceof le && n.suspend());
        }
        je.pendingUnobservations = [];
    }
}

function Ne(e) {
    var t = je.trackingDerivation;
    return null !== t ? (t.runId !== e.lastAccessedBy && (e.lastAccessedBy = t.runId, 
    (t.newObserving[t.unboundDepsCount++] = e).isBeingObserved || (e.isBeingObserved = !0, 
    e.onBecomeObserved())), !0) : (0 === e.observers.length && 0 < je.inBatch && Ie(e), 
    !1);
}

function Re(e, t) {
    var n;
    console.log("[mobx.trace] '" + e.name + "' is invalidated due to a change in: '" + t.name + "'"), 
    e.isTracing === pe.BREAK && (n = [], function e(t, n, r) {
        1e3 <= n.length ? n.push("(and many more)") : (n.push("" + new Array(r).join("\t") + t.name), 
        t.dependencies && t.dependencies.forEach(function(t) {
            return e(t, n, r + 1);
        }));
    }(it(e), n, 1), new Function("debugger;\n/*\nTracing '" + e.name + "'\n\nYou are entering this break point because derivation '" + e.name + "' is being traced and '" + t.name + "' is now forcing it to update.\nJust follow the stacktrace you should now see in the devtools to see precisely what piece of your code is causing this update\nThe stackframe you are looking for is at least ~6-8 stack-frames up.\n\n" + (e instanceof le ? e.derivation.toString().replace(/[*]\//g, "/") : "") + "\n\nThe dependencies for this derivation are:\n\n" + n.join("\n") + "\n*/\n    ")());
}

var Pe = function() {
    function e(e, t, n) {
        void 0 === e && (e = "Reaction@" + c()), this.name = e, this.onInvalidate = t, this.errorHandler = n, 
        this.observing = [], this.newObserving = [], this.dependenciesState = exports.IDerivationState.NOT_TRACKING, 
        this.diffValue = 0, this.runId = 0, this.unboundDepsCount = 0, this.__mapid = "#" + c(), 
        this.isDisposed = !1, this._isScheduled = !1, this._isTrackPending = !1, this._isRunning = !1, 
        this.isTracing = pe.NONE;
    }
    return e.prototype.onBecomeStale = function() {
        this.schedule();
    }, e.prototype.schedule = function() {
        this._isScheduled || (this._isScheduled = !0, je.pendingReactions.push(this), Be());
    }, e.prototype.isScheduled = function() {
        return this._isScheduled;
    }, e.prototype.runReaction = function() {
        if (!this.isDisposed) {
            if (Ce(), this._isScheduled = !1, ye(this)) {
                this._isTrackPending = !0;
                try {
                    this.onInvalidate(), this._isTrackPending && Ue() && Ge({
                        name: this.name,
                        type: "scheduled-reaction"
                    });
                } catch (e) {
                    this.reportExceptionInDerivation(e);
                }
            }
            Ve();
        }
    }, e.prototype.track = function(e) {
        Ce();
        var t, n = Ue();
        n && (t = Date.now(), He({
            name: this.name,
            type: "reaction"
        })), this._isRunning = !0, e = me(this, e, void 0);
        this._isRunning = !1, this._isTrackPending = !1, this.isDisposed && ge(this), ve(e) && this.reportExceptionInDerivation(e.cause), 
        n && ze({
            time: Date.now() - t
        }), Ve();
    }, e.prototype.reportExceptionInDerivation = function(e) {
        var t = this;
        if (this.errorHandler) this.errorHandler(e, this); else {
            if (je.disableErrorBoundaries) throw e;
            var n = "[mobx] Encountered an uncaught exception that was thrown by a reaction or observer component, in: '" + this + "'";
            je.suppressReactionErrors ? console.warn("[mobx] (error in reaction '" + this.name + "' suppressed, fix error of causing action below)") : console.error(n, e), 
            Ue() && Ge({
                type: "error",
                name: this.name,
                message: n,
                error: "" + e
            }), je.globalReactionErrorHandlers.forEach(function(n) {
                return n(e, t);
            });
        }
    }, e.prototype.dispose = function() {
        this.isDisposed || (this.isDisposed = !0, this._isRunning || (Ce(), ge(this), Ve()));
    }, e.prototype.getDisposer = function() {
        var e = this.dispose.bind(this);
        return e.$mobx = this, e;
    }, e.prototype.toString = function() {
        return "Reaction[" + this.name + "]";
    }, e.prototype.trace = function(e) {
        bt(this, e = void 0 !== e && e);
    }, e;
}();

var Le = function(e) {
    return e();
};

function Be() {
    0 < je.inBatch || je.isRunningReactions || Le($e);
}

function $e() {
    je.isRunningReactions = !0;
    for (var e = je.pendingReactions, t = 0; 0 < e.length; ) {
        100 == ++t && (console.error("Reaction doesn't converge to a stable state after 100 iterations. Probably there is a cycle in the reactive function: " + e[0]), 
        e.splice(0));
        for (var n = e.splice(0), r = 0, o = n.length; r < o; r++) n[r].runReaction();
    }
    je.isRunningReactions = !1;
}

var Me = m("Reaction", Pe);

function Ue() {
    return !!je.spyListeners.length;
}

function Ge(e) {
    if (je.spyListeners.length) for (var t = je.spyListeners, n = 0, r = t.length; n < r; n++) t[n](e);
}

function He(e) {
    Ge(r({}, e, {
        spyReportStart: !0
    }));
}

var Ke = {
    spyReportEnd: !0
};

function ze(e) {
    Ge(e ? r({}, e, {
        spyReportEnd: !0
    }) : Ke);
}

function We(e) {
    return je.spyListeners.push(e), f(function() {
        je.spyListeners = je.spyListeners.filter(function(t) {
            return t !== e;
        });
    });
}

function qe() {
    l(!1);
}

function Je(e) {
    return function(t, n, r) {
        if (r) {
            if (r.value) return {
                value: re(e, r.value),
                enumerable: !1,
                configurable: !0,
                writable: !0
            };
            var o = r.initializer;
            return {
                enumerable: !1,
                configurable: !0,
                writable: !0,
                initializer: function() {
                    return re(e, o.call(this));
                }
            };
        }
        return Xe(e).apply(this, arguments);
    };
}

function Xe(e) {
    return function(t, n, r) {
        Object.defineProperty(t, n, {
            configurable: !0,
            enumerable: !1,
            get: function() {},
            set: function(t) {
                y(this, n, Ye(e, t));
            }
        });
    };
}

var Ye = function(e, t, n, r) {
    return 1 === arguments.length && "function" == typeof e ? re(e.name || "<unnamed action>", e) : 2 === arguments.length && "function" == typeof t ? re(e, t) : 1 === arguments.length && "string" == typeof e ? Je(e) : !0 !== r ? Je(t).apply(null, arguments) : void (e[t] = re(e.name || t, n.value));
};

function Fe(e, t, n) {
    y(e, t, re(t, n.bind(e)));
}

function Qe(e, t) {
    var n, r, o, i = (t = void 0 === t ? s : t) && t.name || e.name || "Autorun@" + c();
    function a() {
        e(o);
    }
    return (o = t.scheduler || t.delay ? (n = et(t), r = !1, new Pe(i, function() {
        r || (r = !0, n(function() {
            r = !1, o.isDisposed || o.track(a);
        }));
    }, t.onError)) : new Pe(i, function() {
        this.track(a);
    }, t.onError)).schedule(), o.getDisposer();
}

Ye.bound = function(e, t, n, r) {
    return !0 === r ? (Fe(e, t, n.value), null) : n ? {
        configurable: !0,
        enumerable: !1,
        get: function() {
            return Fe(this, t, n.value || n.initializer.call(this)), this[t];
        },
        set: qe
    } : {
        enumerable: !1,
        configurable: !0,
        set: function(e) {
            Fe(this, t, e);
        },
        get: function() {}
    };
};

var Ze = function(e) {
    return e();
};

function et(e) {
    return e.scheduler || (e.delay ? function(t) {
        return setTimeout(t, e.delay);
    } : Ze);
}

function tt(e, t, n) {
    return rt("onBecomeObserved", e, t, n);
}

function nt(e, t, n) {
    return rt("onBecomeUnobserved", e, t, n);
}

function rt(e, t, n, r) {
    var o = "string" == typeof n ? en(t, n) : en(t), i = "string" == typeof n ? r : n, a = o[e];
    return "function" != typeof a ? l(!1) : (o[e] = function() {
        a.call(this), i.call(this);
    }, function() {
        o[e] = a;
    });
}

function ot(e, t, n, r) {
    var o = (r = z(r)).defaultDecorator || (!1 === r.deep ? X : q);
    L(e), qt(e, r.name, o.enhancer), Ce();
    try {
        for (var i in t) {
            var a = Object.getOwnPropertyDescriptor(t, i), s = (n && i in n ? n[i] : a.get ? ee : o)(e, i, a, !0);
            s && Object.defineProperty(e, i, s);
        }
    } finally {
        Ve();
    }
    return e;
}

function it(e, t) {
    return at(en(e, t));
}

function at(e) {
    var t = {
        name: e.name
    };
    return e.observing && 0 < e.observing.length && (t.dependencies = function(e) {
        var t = [];
        return e.forEach(function(e) {
            -1 === t.indexOf(e) && t.push(e);
        }), t;
    }(e.observing).map(at)), t;
}

function st(e) {
    var t = {
        name: e.name
    };
    return function(e) {
        return e.observers && 0 < e.observers.length;
    }(e) && (t.observers = function(e) {
        return e.observers;
    }(e).map(st)), t;
}

var ut = 0;

function ct(e) {
    "function" == typeof e.cancel && e.cancel();
}

function lt(e, t) {
    return null != e && (void 0 === t ? he(e) : !1 !== Zt(e) && !!e.$mobx.values[t] && (e = en(e, t), 
    he(e)));
}

function pt(e, t) {
    return null != e && (void 0 !== t ? !!Zt(e) && (n = e.$mobx).values && !!n.values[t] : Zt(e) || !!e.$mobx || T(e) || Me(e) || he(e));
    var n;
}

function ft(e) {
    return 1 !== arguments.length && l(!1), pt(e);
}

function ht(e) {
    return Zt(e) ? e.$mobx.getKeys() : Gt(e) ? e._keys.slice() : zt(e) ? _(e.keys()) : Bt(e) ? e.map(function(e, t) {
        return t;
    }) : l(!1);
}

function dt(e, t) {
    var n;
    return Zt(e) ? ((n = tn(e)).getKeys(), !!n.values[t]) : Gt(e) || zt(e) ? e.has(t) : Bt(e) ? 0 <= t && t < e.length : l(!1);
}

var vt = {
    detectCycles: !0,
    exportMapsAsObjects: !0,
    recurseEverything: !1
};

function yt(e, t, n, r) {
    return r.detectCycles && e.set(t, n), n;
}

function bt() {
    for (var e = [], t = 0; t < arguments.length; t++) e[t] = arguments[t];
    var n = !1, r = ("boolean" == typeof e[e.length - 1] && (n = e.pop()), mt(e));
    if (!r) return l(!1);
    r.isTracing === pe.NONE && console.log("[mobx.trace] '" + r.name + "' tracing enabled"), 
    r.isTracing = n ? pe.BREAK : pe.LOG;
}

function mt(e) {
    switch (e.length) {
      case 0:
        return je.trackingDerivation;

      case 1:
        return en(e[0]);

      case 2:
        return en(e[0], e[1]);
    }
}

function gt(e, t) {
    void 0 === t && (t = void 0), Ce();
    try {
        return e.apply(t);
    } finally {
        Ve();
    }
}

function xt(e, t, n) {
    "number" == typeof n.timeout && (r = setTimeout(function() {
        if (!i.$mobx.isDisposed) {
            i();
            var e = new Error("WHEN_TIMEOUT");
            if (!n.onError) throw e;
            n.onError(e);
        }
    }, n.timeout)), n.name = n.name || "When@" + c();
    var r, o = re(n.name + "-effect", t), i = Qe(function(t) {
        e() && (t.dispose(), r && clearTimeout(r), o());
    }, n);
    return i;
}

function _t(e, t) {
    var n, o = new Promise(function(o, i) {
        var a = xt(e, o, r({}, t, {
            onError: i
        }));
        n = function() {
            a(), i("WHEN_CANCELLED");
        };
    });
    return o.cancel = n, o;
}

function Ot(e) {
    return void 0 !== e.interceptors && 0 < e.interceptors.length;
}

function wt(e, t) {
    var n = e.interceptors || (e.interceptors = []);
    return n.push(t), f(function() {
        var e = n.indexOf(t);
        -1 !== e && n.splice(e, 1);
    });
}

function St(e, t) {
    var n = _e();
    try {
        var r = e.interceptors;
        if (r) for (var o = 0, i = r.length; o < i && (p(!(t = r[o](t)) || t.type, "Intercept handlers should return nothing or a change object"), 
        t); o++) ;
        return t;
    } finally {
        Oe(n);
    }
}

function At(e) {
    return void 0 !== e.changeListeners && 0 < e.changeListeners.length;
}

function Et(e, t) {
    var n = e.changeListeners || (e.changeListeners = []);
    return n.push(t), f(function() {
        var e = n.indexOf(t);
        -1 !== e && n.splice(e, 1);
    });
}

function Dt(e, t) {
    var n = _e(), r = e.changeListeners;
    if (r) {
        for (var o = 0, i = (r = r.slice()).length; o < i; o++) r[o](t);
        Oe(n);
    }
}

var jt = function() {
    var e = !1, t = {};
    return Object.defineProperty(t, "0", {
        set: function() {
            e = !0;
        }
    }), !(Object.create(t)[0] = 1) === e;
}(), kt = 0, Tt = function() {};

(function(e, t) {
    void 0 !== Object.setPrototypeOf ? Object.setPrototypeOf(e.prototype, t) : void 0 !== e.prototype.__proto__ ? e.prototype.__proto__ = t : e.prototype = t;
})(Tt, Array.prototype), Object.isFrozen(Array) && [ "constructor", "push", "shift", "concat", "pop", "unshift", "replace", "find", "findIndex", "splice", "reverse", "sort" ].forEach(function(e) {
    Object.defineProperty(Tt.prototype, e, {
        configurable: !0,
        writable: !0,
        value: Array.prototype[e]
    });
});

var It = function() {
    function e(e, t, n, r) {
        this.array = n, this.owned = r, this.values = [], this.lastKnownLength = 0, this.atom = new k(e || "ObservableArray@" + c()), 
        this.enhancer = function(n, r) {
            return t(n, r, e + "[..]");
        };
    }
    return e.prototype.dehanceValue = function(e) {
        return void 0 !== this.dehancer ? this.dehancer(e) : e;
    }, e.prototype.dehanceValues = function(e) {
        return void 0 !== this.dehancer && 0 < e.length ? e.map(this.dehancer) : e;
    }, e.prototype.intercept = function(e) {
        return wt(this, e);
    }, e.prototype.observe = function(e, t) {
        return (t = void 0 !== t && t) && e({
            object: this.array,
            type: "splice",
            index: 0,
            added: this.values.slice(),
            addedCount: this.values.length,
            removed: [],
            removedCount: 0
        }), Et(this, e);
    }, e.prototype.getArrayLength = function() {
        return this.atom.reportObserved(), this.values.length;
    }, e.prototype.setArrayLength = function(e) {
        if ("number" != typeof e || e < 0) throw new Error("[mobx.array] Out of range: " + e);
        var t = this.values.length;
        if (e !== t) if (t < e) {
            for (var n = new Array(e - t), r = 0; r < e - t; r++) n[r] = void 0;
            this.spliceWithArray(t, 0, n);
        } else this.spliceWithArray(e, t - e);
    }, e.prototype.updateArrayLength = function(e, t) {
        if (e !== this.lastKnownLength) throw new Error("[mobx] Modification exception: the internal structure of an observable array was changed. Did you use peek() to change it?");
        this.lastKnownLength += t, 0 < t && kt < e + t + 1 && Pt(e + t + 1);
    }, e.prototype.spliceWithArray = function(e, t, n) {
        var r = this, o = (be(this.atom), this.values.length);
        if (void 0 === e ? e = 0 : o < e ? e = o : e < 0 && (e = Math.max(0, o + e)), t = 1 === arguments.length ? o - e : null == t ? 0 : Math.max(0, Math.min(t, o - e)), 
        void 0 === n && (n = a), Ot(this)) {
            var i = St(this, {
                object: this.array,
                type: "splice",
                index: e,
                removedCount: t,
                added: n
            });
            if (!i) return a;
            t = i.removedCount, n = i.added;
        }
        return i = (n = 0 === n.length ? n : n.map(function(e) {
            return r.enhancer(e, void 0);
        })).length - t, this.updateArrayLength(o, i), o = this.spliceItemsIntoValues(e, t, n), 
        0 === t && 0 === n.length || this.notifyArraySplice(e, n, o), this.dehanceValues(o);
    }, e.prototype.spliceItemsIntoValues = function(e, t, n) {
        if (n.length < 1e4) return (r = this.values).splice.apply(r, i([ e, t ], n));
        var r = this.values.slice(e, e + t);
        return this.values = this.values.slice(0, e).concat(n, this.values.slice(e + t)), 
        r;
    }, e.prototype.notifyArrayChildUpdate = function(e, t, n) {
        var o = !this.owned && Ue(), i = At(this);
        e = i || o ? {
            object: this.array,
            type: "update",
            index: e,
            newValue: t,
            oldValue: n
        } : null;
        o && He(r({}, e, {
            name: this.atom.name
        })), this.atom.reportChanged(), i && Dt(this, e), o && ze();
    }, e.prototype.notifyArraySplice = function(e, t, n) {
        var o = !this.owned && Ue(), i = At(this);
        e = i || o ? {
            object: this.array,
            type: "splice",
            index: e,
            removed: n,
            added: t,
            removedCount: n.length,
            addedCount: t.length
        } : null;
        o && He(r({}, e, {
            name: this.atom.name
        })), this.atom.reportChanged(), i && Dt(this, e), o && ze();
    }, e;
}(), Ct = function(e) {
    function t(t, n, r, o) {
        void 0 === r && (r = "ObservableArray@" + c()), void 0 === o && (o = !1);
        var i = e.call(this) || this;
        return b(i, "$mobx", r = new It(r, n, i, o)), t && t.length && (n = ae(!0), i.spliceWithArray(0, 0, t), 
        se(n)), jt && Object.defineProperty(r.array, "0", Vt), i;
    }
    return n(t, e), t.prototype.intercept = function(e) {
        return this.$mobx.intercept(e);
    }, t.prototype.observe = function(e, t) {
        return this.$mobx.observe(e, t = void 0 !== t && t);
    }, t.prototype.clear = function() {
        return this.splice(0);
    }, t.prototype.concat = function() {
        for (var e = [], t = 0; t < arguments.length; t++) e[t] = arguments[t];
        return this.$mobx.atom.reportObserved(), Array.prototype.concat.apply(this.peek(), e.map(function(e) {
            return Bt(e) ? e.peek() : e;
        }));
    }, t.prototype.replace = function(e) {
        return this.$mobx.spliceWithArray(0, this.$mobx.values.length, e);
    }, t.prototype.toJS = function() {
        return this.slice();
    }, t.prototype.toJSON = function() {
        return this.toJS();
    }, t.prototype.peek = function() {
        return this.$mobx.atom.reportObserved(), this.$mobx.dehanceValues(this.$mobx.values);
    }, t.prototype.find = function(e, t, n) {
        return void 0 === n && (n = 0), -1 === (n = this.findIndex.apply(this, arguments)) ? void 0 : this.get(n);
    }, t.prototype.findIndex = function(e, t, n) {
        void 0 === n && (n = 0);
        for (var r = this.peek(), o = r.length, i = n; i < o; i++) if (e.call(t, r[i], i, this)) return i;
        return -1;
    }, t.prototype.splice = function(e, t) {
        for (var n = [], r = 2; r < arguments.length; r++) n[r - 2] = arguments[r];
        switch (arguments.length) {
          case 0:
            return [];

          case 1:
            return this.$mobx.spliceWithArray(e);

          case 2:
            return this.$mobx.spliceWithArray(e, t);
        }
        return this.$mobx.spliceWithArray(e, t, n);
    }, t.prototype.spliceWithArray = function(e, t, n) {
        return this.$mobx.spliceWithArray(e, t, n);
    }, t.prototype.push = function() {
        for (var e = [], t = 0; t < arguments.length; t++) e[t] = arguments[t];
        var n = this.$mobx;
        return n.spliceWithArray(n.values.length, 0, e), n.values.length;
    }, t.prototype.pop = function() {
        return this.splice(Math.max(this.$mobx.values.length - 1, 0), 1)[0];
    }, t.prototype.shift = function() {
        return this.splice(0, 1)[0];
    }, t.prototype.unshift = function() {
        for (var e = [], t = 0; t < arguments.length; t++) e[t] = arguments[t];
        var n = this.$mobx;
        return n.spliceWithArray(0, 0, e), n.values.length;
    }, t.prototype.reverse = function() {
        var e = this.slice();
        return e.reverse.apply(e, arguments);
    }, t.prototype.sort = function(e) {
        var t = this.slice();
        return t.sort.apply(t, arguments);
    }, t.prototype.remove = function(e) {
        return -1 < (e = this.$mobx.dehanceValues(this.$mobx.values).indexOf(e)) && (this.splice(e, 1), 
        !0);
    }, t.prototype.move = function(e, t) {
        function n(e) {
            if (e < 0) throw new Error("[mobx.array] Index out of bounds: " + e + " is negative");
            var t = this.$mobx.values.length;
            if (t <= e) throw new Error("[mobx.array] Index out of bounds: " + e + " is not smaller than " + t);
        }
        var r;
        n.call(this, e), n.call(this, t), e !== t && (r = this.$mobx.values, t = e < t ? i(r.slice(0, e), r.slice(e + 1, t + 1), [ r[e] ], r.slice(t + 1)) : i(r.slice(0, t), [ r[e] ], r.slice(t, e), r.slice(e + 1)), 
        this.replace(t));
    }, t.prototype.get = function(e) {
        var t = this.$mobx;
        if (t) {
            if (e < t.values.length) return t.atom.reportObserved(), t.dehanceValue(t.values[e]);
            console.warn("[mobx.array] Attempt to read an array index (" + e + ") that is out of bounds (" + t.values.length + "). Please check length first. Out of bound indices will not be tracked by MobX");
        }
    }, t.prototype.set = function(e, t) {
        var n = this.$mobx, r = n.values;
        if (e < r.length) {
            be(n.atom);
            var o = r[e];
            if (Ot(n)) {
                var i = St(n, {
                    type: "update",
                    object: this,
                    index: e,
                    newValue: t
                });
                if (!i) return;
                t = i.newValue;
            }
            (t = n.enhancer(t, o)) !== o && (r[e] = t, n.notifyArrayChildUpdate(e, t, o));
        } else {
            if (e !== r.length) throw new Error("[mobx.array] Index out of bounds, " + e + " is larger than " + r.length);
            n.spliceWithArray(e, 0, [ t ]);
        }
    }, t;
}(Tt), Vt = (A(Ct.prototype, function() {
    this.$mobx.atom.reportObserved();
    var e = this, t = 0;
    return E({
        next: function() {
            return t < e.length ? {
                value: e[t++],
                done: !1
            } : {
                done: !0,
                value: void 0
            };
        }
    });
}), Object.defineProperty(Ct.prototype, "length", {
    enumerable: !1,
    configurable: !0,
    get: function() {
        return this.$mobx.getArrayLength();
    },
    set: function(e) {
        this.$mobx.setArrayLength(e);
    }
}), y(Ct.prototype, D(), "Array"), [ "every", "filter", "forEach", "indexOf", "join", "lastIndexOf", "map", "reduce", "reduceRight", "slice", "some", "toString", "toLocaleString" ].forEach(function(e) {
    var t = Array.prototype[e];
    p("function" == typeof t, "Base function not defined on Array prototype: '" + e + "'"), 
    y(Ct.prototype, e, function() {
        return t.apply(this.peek(), arguments);
    });
}), function(e, t) {
    for (var n = 0; n < t.length; n++) y(e, t[n], e[t[n]]);
}(Ct.prototype, [ "constructor", "intercept", "observe", "clear", "concat", "get", "replace", "toJS", "toJSON", "peek", "find", "findIndex", "splice", "spliceWithArray", "push", "pop", "set", "shift", "unshift", "reverse", "sort", "remove", "move", "toString", "toLocaleString" ]), 
Nt(0));

function Nt(e) {
    return {
        enumerable: !1,
        configurable: !1,
        get: function() {
            return this.get(e);
        },
        set: function(t) {
            this.set(e, t);
        }
    };
}

function Rt(e) {
    Object.defineProperty(Ct.prototype, "" + e, Nt(e));
}

function Pt(e) {
    for (var t = kt; t < e; t++) Rt(t);
    kt = e;
}

Pt(1e3);

var Lt = m("ObservableArrayAdministration", It);

function Bt(e) {
    return d(e) && Lt(e.$mobx);
}

var $t = {}, Mt = function() {
    function t(e, t, n) {
        if (void 0 === t && (t = M), void 0 === n && (n = "ObservableMap@" + c()), this.enhancer = t, 
        this.name = n, this.$mobx = $t, this._keys = new Ct(void 0, U, this.name + ".keys()", !0), 
        "function" != typeof Map) throw new Error("mobx.map requires Map polyfill for the current browser. Check babel-polyfill or core-js/es6/map.js");
        this._data = new Map(), this._hasMap = new Map(), this.merge(e);
    }
    return t.prototype._has = function(e) {
        return this._data.has(e);
    }, t.prototype.has = function(e) {
        var t = this;
        if (!je.trackingDerivation) return this._has(e);
        var n, r = this._hasMap.get(e);
        return r || (n = r = new ue(this._has(e), U, this.name + "." + Ut(e) + "?", !1), 
        this._hasMap.set(e, n), nt(n, function() {
            return t._hasMap.delete(e);
        })), r.get();
    }, t.prototype.set = function(e, t) {
        var n = this._has(e);
        if (Ot(this)) {
            var r = St(this, {
                type: n ? "update" : "add",
                object: this,
                newValue: t,
                name: e
            });
            if (!r) return this;
            t = r.newValue;
        }
        return n ? this._updateValue(e, t) : this._addValue(e, t), this;
    }, t.prototype.delete = function(e) {
        var t, n, o, i = this;
        return !(Ot(this) && !(o = St(this, {
            type: "delete",
            object: this,
            name: e
        })) || !this._has(e) || (t = Ue(), o = (n = At(this)) || t ? {
            type: "delete",
            object: this,
            oldValue: this._data.get(e).value,
            name: e
        } : null, t && He(r({}, o, {
            name: this.name,
            key: e
        })), gt(function() {
            i._keys.remove(e), i._updateHasMapEntry(e, !1), i._data.get(e).setNewValue(void 0), 
            i._data.delete(e);
        }), n && Dt(this, o), t && ze(), 0));
    }, t.prototype._updateHasMapEntry = function(e, t) {
        (e = this._hasMap.get(e)) && e.setNewValue(t);
    }, t.prototype._updateValue = function(e, t) {
        var n, o, i, a = this._data.get(e);
        (t = a.prepareNewValue(t)) !== je.UNCHANGED && (n = Ue(), i = (o = At(this)) || n ? {
            type: "update",
            object: this,
            oldValue: a.value,
            name: e,
            newValue: t
        } : null, n && He(r({}, i, {
            name: this.name,
            key: e
        })), a.setNewValue(t), o && Dt(this, i), n && ze());
    }, t.prototype._addValue = function(e, t) {
        var n = this, o = (gt(function() {
            var r = new ue(t, n.enhancer, n.name + "." + Ut(e), !1);
            n._data.set(e, r), t = r.value, n._updateHasMapEntry(e, !0), n._keys.push(e);
        }), Ue()), i = At(this), a = i || o ? {
            type: "add",
            object: this,
            name: e,
            newValue: t
        } : null;
        o && He(r({}, a, {
            name: this.name,
            key: e
        })), i && Dt(this, a), o && ze();
    }, t.prototype.get = function(e) {
        return this.has(e) ? this.dehanceValue(this._data.get(e).get()) : this.dehanceValue(void 0);
    }, t.prototype.dehanceValue = function(e) {
        return void 0 !== this.dehancer ? this.dehancer(e) : e;
    }, t.prototype.keys = function() {
        return this._keys[S()]();
    }, t.prototype.values = function() {
        var e = this, t = 0;
        return E({
            next: function() {
                return t < e._keys.length ? {
                    value: e.get(e._keys[t++]),
                    done: !1
                } : {
                    value: void 0,
                    done: !0
                };
            }
        });
    }, t.prototype.entries = function() {
        var e = this, t = 0;
        return E({
            next: function() {
                var n;
                return t < e._keys.length ? {
                    value: [ n = e._keys[t++], e.get(n) ],
                    done: !1
                } : {
                    done: !0
                };
            }
        });
    }, t.prototype.forEach = function(e, t) {
        var n = this;
        this._keys.forEach(function(r) {
            return e.call(t, n.get(r), r, n);
        });
    }, t.prototype.merge = function(e) {
        var t = this;
        return Gt(e) && (e = e.toJS()), gt(function() {
            v(e) ? Object.keys(e).forEach(function(n) {
                return t.set(n, e[n]);
            }) : Array.isArray(e) ? e.forEach(function(e) {
                var n = (e = o(e, 2))[0];
                e = e[1];
                return t.set(n, e);
            }) : g(e) ? e.constructor !== Map ? l("Cannot initialize from classes that inherit from Map: " + e.constructor.name) : e.forEach(function(e, n) {
                return t.set(n, e);
            }) : null != e && l("Cannot initialize map from " + e);
        }), this;
    }, t.prototype.clear = function() {
        var e = this;
        gt(function() {
            xe(function() {
                e._keys.slice().forEach(function(t) {
                    return e.delete(t);
                });
            });
        });
    }, t.prototype.replace = function(e) {
        var t = this;
        return gt(function() {
            for (var n = function(e) {
                return g(e) || Gt(e) ? e : Array.isArray(e) ? new Map(e) : v(e) ? new Map(Object.entries(e)) : l("Cannot convert to map from '" + e + "'");
            }(e), r = t._keys, o = Array.from(n.keys()), i = !1, a = 0; a < r.length; a++) {
                var s = r[a];
                r.length === o.length && s !== o[a] && (i = !0), n.has(s) || (i = !0, t.delete(s));
            }
            n.forEach(function(e, n) {
                t._data.has(n) || (i = !0), t.set(n, e);
            }), i && t._keys.replace(o);
        }), this;
    }, Object.defineProperty(t.prototype, "size", {
        get: function() {
            return this._keys.length;
        },
        enumerable: !0,
        configurable: !0
    }), t.prototype.toPOJO = function() {
        var t = this, n = {};
        return this._keys.forEach(function(r) {
            return n["symbol" == e(r) ? r : Ut(r)] = t.get(r);
        }), n;
    }, t.prototype.toJS = function() {
        var e = this, t = new Map();
        return this._keys.forEach(function(n) {
            return t.set(n, e.get(n));
        }), t;
    }, t.prototype.toJSON = function() {
        return this.toPOJO();
    }, t.prototype.toString = function() {
        var e = this;
        return this.name + "[{ " + this._keys.map(function(t) {
            return Ut(t) + ": " + e.get(t);
        }).join(", ") + " }]";
    }, t.prototype.observe = function(e, t) {
        return Et(this, e);
    }, t.prototype.intercept = function(e) {
        return wt(this, e);
    }, t;
}();

function Ut(e) {
    return (e && e.toString ? e : new String(e)).toString();
}

A(Mt.prototype, function() {
    return this.entries();
}), b(Mt.prototype, D(), "Map");

var Gt = m("ObservableMap", Mt), Ht = {}, Kt = function() {
    function e(e, t, n) {
        if (void 0 === t && (t = M), void 0 === n && (n = "ObservableSet@" + c()), this.name = n, 
        this.$mobx = Ht, this._data = new Set(), this._atom = I(this.name), "function" != typeof Set) throw new Error("mobx.set requires Set polyfill for the current browser. Check babel-polyfill or core-js/es6/set.js");
        this.enhancer = function(e, r) {
            return t(e, r, n);
        }, e && this.replace(e);
    }
    return e.prototype.dehanceValue = function(e) {
        return void 0 !== this.dehancer ? this.dehancer(e) : e;
    }, e.prototype.clear = function() {
        var e = this;
        gt(function() {
            xe(function() {
                e._data.forEach(function(t) {
                    e.delete(t);
                });
            });
        });
    }, e.prototype.forEach = function(e, t) {
        var n = this;
        this._data.forEach(function(r) {
            e.call(t, r, r, n);
        });
    }, Object.defineProperty(e.prototype, "size", {
        get: function() {
            return this._atom.reportObserved(), this._data.size;
        },
        enumerable: !0,
        configurable: !0
    }), e.prototype.add = function(e) {
        var t, n, r, o = this;
        return be(this._atom), Ot(this) && !(r = St(this, {
            type: "add",
            object: this,
            newValue: e
        })) || this.has(e) || (gt(function() {
            o._data.add(o.enhancer(e, void 0)), o._atom.reportChanged();
        }), t = Ue(), r = (n = At(this)) || t ? {
            type: "add",
            object: this,
            newValue: e
        } : null, n && Dt(this, r)), this;
    }, e.prototype.delete = function(e) {
        var t, n, r, o = this;
        return !(Ot(this) && !(r = St(this, {
            type: "delete",
            object: this,
            oldValue: e
        })) || !this.has(e) || (t = Ue(), r = (n = At(this)) || t ? {
            type: "delete",
            object: this,
            oldValue: e
        } : null, gt(function() {
            o._atom.reportChanged(), o._data.delete(e);
        }), n && Dt(this, r), 0));
    }, e.prototype.has = function(e) {
        return this._atom.reportObserved(), this._data.has(this.dehanceValue(e));
    }, e.prototype.entries = function() {
        var e = 0, t = _(this.keys()), n = _(this.values());
        return E({
            next: function() {
                var r = e;
                return e += 1, r < n.length ? {
                    value: [ t[r], n[r] ],
                    done: !1
                } : {
                    done: !0
                };
            }
        });
    }, e.prototype.keys = function() {
        return this.values();
    }, e.prototype.values = function() {
        this._atom.reportObserved();
        var e, t = this, n = 0;
        return void 0 !== this._data.values ? e = _(this._data.values()) : (e = [], this._data.forEach(function(t) {
            return e.push(t);
        })), E({
            next: function() {
                return n < e.length ? {
                    value: t.dehanceValue(e[n++]),
                    done: !1
                } : {
                    done: !0
                };
            }
        });
    }, e.prototype.replace = function(e) {
        var t = this;
        return zt(e) && (e = e.toJS()), gt(function() {
            Array.isArray(e) || x(e) ? (t.clear(), e.forEach(function(e) {
                return t.add(e);
            })) : null != e && l("Cannot initialize set from " + e);
        }), this;
    }, e.prototype.observe = function(e, t) {
        return Et(this, e);
    }, e.prototype.intercept = function(e) {
        return wt(this, e);
    }, e.prototype.toJS = function() {
        return new Set(this);
    }, e.prototype.toString = function() {
        return this.name + "[ " + _(this.keys()).join(", ") + " ]";
    }, e;
}(), zt = (A(Kt.prototype, function() {
    return this.values();
}), b(Kt.prototype, D(), "Set"), m("ObservableSet", Kt)), Wt = function() {
    function e(e, t, n) {
        this.target = e, this.name = t, this.defaultEnhancer = n, this.values = {};
    }
    return e.prototype.read = function(e, t) {
        if (this.target === e || (this.illegalAccess(e, t), this.values[t])) return this.values[t].get();
    }, e.prototype.write = function(e, t, n) {
        var o, i, a, s = this.target;
        if (s !== e && this.illegalAccess(e, t), (e = this.values[t]) instanceof le) e.set(n); else {
            if (Ot(this)) {
                if (!(a = St(this, {
                    type: "update",
                    object: s,
                    name: t,
                    newValue: n
                }))) return;
                n = a.newValue;
            }
            (n = e.prepareNewValue(n)) !== je.UNCHANGED && (o = At(this), i = Ue(), a = o || i ? {
                type: "update",
                object: s,
                oldValue: e.value,
                name: t,
                newValue: n
            } : null, i && He(r({}, a, {
                name: this.name,
                key: t
            })), e.setNewValue(n), o && Dt(this, a), i && ze());
        }
    }, e.prototype.remove = function(e) {
        if (this.values[e]) {
            var t = this.target;
            if (!Ot(this) || (a = St(this, {
                object: t,
                name: e,
                type: "remove"
            }))) try {
                Ce();
                var n = At(this), o = Ue(), i = this.values[e].get(), a = (this.keys && this.keys.remove(e), 
                delete this.values[e], delete this.target[e], n || o ? {
                    type: "remove",
                    object: t,
                    oldValue: i,
                    name: e
                } : null);
                o && He(r({}, a, {
                    name: this.name,
                    key: e
                })), n && Dt(this, a), o && ze();
            } finally {
                Ve();
            }
        }
    }, e.prototype.illegalAccess = function(e, t) {
        console.warn("Property '" + t + "' of '" + e + "' was accessed through the prototype chain. Use 'decorate' instead to declare the prop or access it statically through it's owner");
    }, e.prototype.observe = function(e, t) {
        return Et(this, e);
    }, e.prototype.intercept = function(e) {
        return wt(this, e);
    }, e.prototype.getKeys = function() {
        var e = this;
        return void 0 === this.keys && (this.keys = new Ct(Object.keys(this.values).filter(function(t) {
            return e.values[t] instanceof ue;
        }), U, "keys(" + this.name + ")", !0)), this.keys.slice();
    }, e;
}();

function qt(e, t, n) {
    return void 0 === t && (t = ""), void 0 === n && (n = M), e.$mobx || (t = (t = v(e) ? t : (e.constructor.name || "ObservableObject") + "@" + c()) || "ObservableObject@" + c(), 
    b(e, "$mobx", e = new Wt(e, t, n)), e);
}

function Jt(e, t, n, o) {
    var i = qt(e);
    if (Ot(i)) {
        var a = St(i, {
            object: e,
            name: t,
            type: "add",
            newValue: n
        });
        if (!a) return;
        n = a.newValue;
    }
    n = (i.values[t] = new ue(n, o, i.name + "." + t, !1)).value, Object.defineProperty(e, t, function(e) {
        return Xt[e] || (Xt[e] = {
            configurable: !0,
            enumerable: !0,
            get: function() {
                return this.$mobx.read(this, e);
            },
            set: function(t) {
                this.$mobx.write(this, e, t);
            }
        });
    }(t)), i.keys && i.keys.push(t), function(e, t, n, o) {
        var i = At(e), a = Ue();
        t = i || a ? {
            type: "add",
            object: t,
            name: n,
            newValue: o
        } : null;
        a && He(r({}, t, {
            name: e.name,
            key: n
        })), i && Dt(e, t), a && ze();
    }(i, e, t, n);
}

var Xt = Object.create(null), Yt = Object.create(null);

function Ft(e) {
    return e.$mobx || (L(e), e.$mobx);
}

var Qt = m("ObservableObjectAdministration", Wt);

function Zt(e) {
    return !!d(e) && (L(e), Qt(e.$mobx));
}

function en(t, n) {
    if ("object" == e(t) && null !== t) {
        if (Bt(t)) return void 0 !== n && l(!1), t.$mobx.atom;
        if (zt(t)) return t.$mobx;
        var r, o;
        if (Gt(t)) return r = t, void 0 === n ? en(r._keys) : ((o = r._data.get(n) || r._hasMap.get(n)) || l(!1), 
        o);
        if (L(t), n && !t.$mobx && t[n], Zt(t)) return n ? ((o = t.$mobx.values[n]) || l(!1), 
        o) : l(!1);
        if (T(t) || he(t) || Me(t)) return t;
    } else if ("function" == typeof t && Me(t.$mobx)) return t.$mobx;
    return l(!1);
}

function tn(e, t) {
    return e || l("Expecting some object"), void 0 !== t ? tn(en(e, t)) : T(e) || he(e) || Me(e) || Gt(e) || zt(e) ? e : (L(e), 
    e.$mobx || void l(!1));
}

function nn(e, t) {
    return (void 0 !== t ? en(e, t) : (Zt(e) || Gt(e) || zt(e) ? tn : en)(e)).name;
}

var rn = Object.prototype.toString;

function on(e, t) {
    return an(e, t);
}

function an(t, n, r, o) {
    if (t === n) return 0 !== t || 1 / t == 1 / n;
    if (null == t || null == n) return !1;
    if (t != t) return n != n;
    var i = e(t);
    return ("function" == i || "object" == i || "object" == e(n)) && function(t, n, r, o) {
        t = sn(t), n = sn(n);
        var i = rn.call(t);
        if (i !== rn.call(n)) return !1;
        switch (i) {
          case "[object RegExp]":
          case "[object String]":
            return "" + t == "" + n;

          case "[object Number]":
            return +t != +t ? +n != +n : 0 == +t ? 1 / +t == 1 / n : +t == +n;

          case "[object Date]":
          case "[object Boolean]":
            return +t == +n;

          case "[object Symbol]":
            return "undefined" != typeof Symbol && Symbol.valueOf.call(t) === Symbol.valueOf.call(n);
        }
        if (!(i = "[object Array]" === i)) {
            if ("object" != e(t) || "object" != e(n)) return !1;
            var a = t.constructor, s = n.constructor;
            if (a !== s && !("function" == typeof a && a instanceof a && "function" == typeof s && s instanceof s) && "constructor" in t && "constructor" in n) return !1;
        }
        o = o || [];
        for (var u = (r = r || []).length; u--; ) if (r[u] === t) return o[u] === n;
        if (r.push(t), o.push(n), i) {
            if ((u = t.length) !== n.length) return !1;
            for (;u--; ) if (!an(t[u], n[u], r, o)) return !1;
        } else {
            var c, l = Object.keys(t);
            u = l.length;
            if (Object.keys(n).length !== u) return !1;
            for (;u--; ) if (!un(n, c = l[u]) || !an(t[c], n[c], r, o)) return !1;
        }
        return r.pop(), o.pop(), !0;
    }(t, n, r, o);
}

function sn(e) {
    return Bt(e) ? e.peek() : g(e) || Gt(e) || x(e) || zt(e) ? _(e.entries()) : e;
}

function un(e, t) {
    return Object.prototype.hasOwnProperty.call(e, t);
}

"object" == ("undefined" == typeof __MOBX_DEVTOOLS_GLOBAL_HOOK__ ? "undefined" : e(__MOBX_DEVTOOLS_GLOBAL_HOOK__)) && __MOBX_DEVTOOLS_GLOBAL_HOOK__.injectMobx({
    spy: We,
    extras: {
        getDebugName: nn
    },
    $mobx: "$mobx"
}), exports.$mobx = "$mobx", exports.ObservableMap = Mt, exports.ObservableSet = Kt, 
exports.Reaction = Pe, exports._allowStateChanges = function(e, t) {
    var n;
    e = ae(e);
    try {
        n = t();
    } finally {
        se(e);
    }
    return n;
}, exports._allowStateChangesInsideComputed = function(e) {
    var t, n = je.computationDepth;
    je.computationDepth = 0;
    try {
        t = e();
    } finally {
        je.computationDepth = n;
    }
    return t;
}, exports._getAdministration = tn, exports._getGlobalState = function() {
    return je;
}, exports._interceptReads = function(e, t, n) {
    var r;
    if (Gt(e) || Bt(e) || ce(e)) r = tn(e); else {
        if (!Zt(e)) return l(!1);
        if ("string" != typeof t) return l(!1);
        r = tn(e, t);
    }
    return void 0 !== r.dehancer ? l(!1) : (r.dehancer = "function" == typeof t ? t : n, 
    function() {
        r.dehancer = void 0;
    });
}, exports._isComputingDerivation = function() {
    return null !== je.trackingDerivation;
}, exports._resetGlobalState = function() {
    var e, t = new Ae();
    for (e in t) -1 === Se.indexOf(e) && (je[e] = t[e]);
    je.allowStateChanges = !je.enforceActions;
}, exports.action = Ye, exports.autorun = Qe, exports.comparer = V, exports.computed = ne, 
exports.configure = function(e) {
    var t = e.enforceActions, n = e.computedRequiresReaction, r = e.computedConfigurable, o = e.disableErrorBoundaries, i = e.arrayBuffer, a = e.reactionScheduler;
    if (!0 === e.isolateGlobalState && ((je.pendingReactions.length || je.inBatch || je.isRunningReactions) && l("isolateGlobalState should be called before MobX is running any reactions"), 
    De = !0, Ee && (0 == --u().__mobxInstanceCount && (u().__mobxGlobals = void 0), 
    je = new Ae())), void 0 !== t) {
        var s = void 0;
        switch (t) {
          case !0:
          case "observed":
            s = !0;
            break;

          case !1:
          case "never":
            s = !1;
            break;

          case "strict":
          case "always":
            s = "strict";
            break;

          default:
            l("Invalid value for 'enforceActions': '" + t + "', expected 'never', 'always' or 'observed'");
        }
        je.enforceActions = s, je.allowStateChanges = !0 !== s && "strict" !== s;
    }
    void 0 !== n && (je.computedRequiresReaction = !!n), void 0 !== r && (je.computedConfigurable = !!r), 
    void 0 !== o && (!0 === o && console.warn("WARNING: Debug feature only. MobX will NOT recover from errors if this is on."), 
    je.disableErrorBoundaries = !!o), "number" == typeof i && Pt(i), a && function(e) {
        var t = Le;
        Le = function(n) {
            return e(function() {
                return t(n);
            });
        };
    }(a);
}, exports.createAtom = I, exports.decorate = function(e, t) {
    var n, r = "function" == typeof e ? e.prototype : e;
    for (n in t) !function(e) {
        var n = t[e], o = (Array.isArray(n) || (n = [ n ]), Object.getOwnPropertyDescriptor(r, e));
        (n = n.reduce(function(t, n) {
            return n(r, e, t);
        }, o)) && Object.defineProperty(r, e, n);
    }(n);
    return e;
}, exports.entries = function(e) {
    return Zt(e) ? ht(e).map(function(t) {
        return [ t, e[t] ];
    }) : Gt(e) ? ht(e).map(function(t) {
        return [ t, e.get(t) ];
    }) : zt(e) ? _(e.entries()) : Bt(e) ? e.map(function(e, t) {
        return [ t, e ];
    }) : l(!1);
}, exports.extendObservable = ot, exports.extendShallowObservable = function(e, t, n) {
    return ot(e, t, n, K);
}, exports.flow = function(e) {
    1 !== arguments.length && l("Flow expects one 1 argument and cannot be used as decorator");
    var t = e.name || "<unnamed flow>";
    return function() {
        var n, r = arguments, o = ++ut, i = Ye(t + " - runid: " + o + " - init", e).apply(this, r), a = void 0;
        return (r = new Promise(function(e, r) {
            var s = 0;
            function u(e) {
                var n;
                a = void 0;
                try {
                    n = Ye(t + " - runid: " + o + " - yield " + s++, i.next).call(i, e);
                } catch (e) {
                    return r(e);
                }
                l(n);
            }
            function c(e) {
                var n;
                a = void 0;
                try {
                    n = Ye(t + " - runid: " + o + " - yield " + s++, i.throw).call(i, e);
                } catch (e) {
                    return r(e);
                }
                l(n);
            }
            function l(t) {
                if (!t || "function" != typeof t.then) return t.done ? e(t.value) : (a = Promise.resolve(t.value)).then(u, c);
                t.then(l, r);
            }
            n = r, u(void 0);
        })).cancel = Ye(t + " - runid: " + o + " - cancel", function() {
            try {
                a && ct(a);
                var e = i.return(), t = Promise.resolve(e.value);
                t.then(h, h), ct(t), n(new Error("FLOW_CANCELLED"));
            } catch (e) {
                n(e);
            }
        }), r;
    };
}, exports.get = function(e, t) {
    if (dt(e, t)) return Zt(e) ? e[t] : Gt(e) ? e.get(t) : Bt(e) ? e[t] : l(!1);
}, exports.getAtom = en, exports.getDebugName = nn, exports.getDependencyTree = it, 
exports.getObserverTree = function(e, t) {
    return st(en(e, t));
}, exports.has = dt, exports.intercept = function(e, t, n) {
    return "function" == typeof n ? function(e, t, n) {
        return tn(e, t).intercept(n);
    }(e, t, n) : function(e, t) {
        return tn(e).intercept(t);
    }(e, t);
}, exports.isAction = function(e) {
    return "function" == typeof e && !0 === e.isMobxAction;
}, exports.isArrayLike = function(e) {
    return Array.isArray(e) || Bt(e);
}, exports.isBoxedObservable = ce, exports.isComputed = function(e) {
    return 1 < arguments.length ? l(!1) : lt(e);
}, exports.isComputedProp = function(e, t) {
    return "string" != typeof t ? l(!1) : lt(e, t);
}, exports.isObservable = ft, exports.isObservableArray = Bt, exports.isObservableMap = Gt, 
exports.isObservableObject = Zt, exports.isObservableProp = function(e, t) {
    return "string" != typeof t ? l(!1) : pt(e, t);
}, exports.isObservableSet = zt, exports.keys = ht, exports.observable = Q, exports.observe = function(e, t, n, r) {
    return "function" == typeof n ? function(e, t, n, r) {
        return tn(e, t).observe(n, r);
    }(e, t, n, r) : function(e, t, n) {
        return tn(e).observe(t, n);
    }(e, t, n);
}, exports.onBecomeObserved = tt, exports.onBecomeUnobserved = nt, exports.onReactionError = function(e) {
    return je.globalReactionErrorHandlers.push(e), function() {
        var t = je.globalReactionErrorHandlers.indexOf(e);
        0 <= t && je.globalReactionErrorHandlers.splice(t, 1);
    };
}, exports.reaction = function(e, t, n) {
    "boolean" == typeof (n = void 0 === n ? s : n) && (n = {
        fireImmediately: n
    });
    var r, o = n.name || "Reaction@" + c(), i = Ye(o, n.onError ? function(e, t) {
        return function() {
            try {
                return t.apply(this, arguments);
            } catch (t) {
                e.call(this, t);
            }
        };
    }(n.onError, t) : t), a = !n.scheduler && !n.delay, u = et(n), l = !0, p = !1, f = n.compareStructural ? V.structural : n.equals || V.default, h = new Pe(o, function() {
        l || a ? d() : p || (p = !0, u(d));
    }, n.onError);
    function d() {
        var t;
        p = !1, h.isDisposed || (t = !1, h.track(function() {
            var n = e(h);
            t = l || !f(r, n), r = n;
        }), l && n.fireImmediately && i(r, h), l || !0 !== t || i(r, h), l = l && !1);
    }
    return h.schedule(), h.getDisposer();
}, exports.remove = function(e, t) {
    if (Zt(e)) e.$mobx.remove(t); else if (Gt(e)) e.delete(t); else if (zt(e)) e.delete(t); else {
        if (!Bt(e)) return l(!1);
        p(0 <= (t = "number" != typeof t ? parseInt(t, 10) : t), "Not a valid index: '" + t + "'"), 
        e.splice(t, 1);
    }
}, exports.runInAction = function(e, t) {
    return oe("string" == typeof e ? e : e.name || "<unnamed action>", "function" == typeof e ? e : t, this, void 0);
}, exports.set = function e(t, n, r) {
    if (2 !== arguments.length || zt(t)) if (Zt(t)) {
        var o = t.$mobx;
        o.values[n] ? o.write(t, n, r) : Jt(t, n, r, o.defaultEnhancer);
    } else if (Gt(t)) t.set(n, r); else if (zt(t)) t.add(n); else {
        if (!Bt(t)) return l(!1);
        p(0 <= (n = "number" != typeof n ? parseInt(n, 10) : n), "Not a valid index: '" + n + "'"), 
        Ce(), n >= t.length && (t.length = n + 1), t[n] = r, Ve();
    } else {
        Ce();
        var i = n;
        try {
            for (var a in i) e(t, a, i[a]);
        } finally {
            Ve();
        }
    }
}, exports.spy = We, exports.toJS = function(t, n) {
    var r;
    return (n = (n = "boolean" == typeof n ? {
        detectCycles: n
    } : n) || vt).detectCycles = void 0 === n.detectCycles ? !0 === n.recurseEverything : !0 === n.detectCycles, 
    function t(n, r, o) {
        if (!r.recurseEverything && !ft(n)) return n;
        if ("object" != e(n)) return n;
        if (null === n) return null;
        if (n instanceof Date) return n;
        if (ce(n)) return t(n.get(), r, o);
        if (ft(n) && ht(n), !0 === r.detectCycles && null !== n && o.has(n)) return o.get(n);
        if (Bt(n) || Array.isArray(n)) {
            var i = yt(o, n, [], r), a = n.map(function(e) {
                return t(e, r, o);
            });
            i.length = a.length;
            for (var s = 0, u = a.length; s < u; s++) i[s] = a[s];
            return i;
        }
        if (zt(n) || Object.getPrototypeOf(n) === Set.prototype) {
            var c;
            if (!1 === r.exportMapsAsObjects) return c = yt(o, n, new Set(), r), n.forEach(function(e) {
                c.add(t(e, r, o));
            }), c;
            var l = yt(o, n, [], r);
            return n.forEach(function(e) {
                l.push(t(e, r, o));
            }), l;
        }
        if (Gt(n) || Object.getPrototypeOf(n) === Map.prototype) {
            var p;
            if (!1 === r.exportMapsAsObjects) return p = yt(o, n, new Map(), r), n.forEach(function(e, n) {
                p.set(n, t(e, r, o));
            }), p;
            var f = yt(o, n, {}, r);
            return n.forEach(function(e, n) {
                f[n] = t(e, r, o);
            }), f;
        }
        var h, d = yt(o, n, {}, r);
        for (h in n) d[h] = t(n[h], r, o);
        return d;
    }(t, n, r = n.detectCycles ? new Map() : r);
}, exports.trace = bt, exports.transaction = gt, exports.untracked = xe, exports.values = function(e) {
    return Zt(e) ? ht(e).map(function(t) {
        return e[t];
    }) : Gt(e) ? ht(e).map(function(t) {
        return e.get(t);
    }) : zt(e) ? _(e.values()) : Bt(e) ? e.slice() : l(!1);
}, exports.when = function(t, n, r) {
    return 1 === arguments.length || n && "object" == e(n) ? _t(t, n) : xt(t, n, r || {});
};