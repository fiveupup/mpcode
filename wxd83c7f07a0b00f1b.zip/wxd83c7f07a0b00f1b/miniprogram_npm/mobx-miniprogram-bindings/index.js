var n = require("../../@babel/runtime/helpers/typeof");

module.exports = function(i) {
    var r = {};
    function o(n) {
        if (r[n]) return r[n].exports;
        var t = r[n] = {
            i: n,
            l: !1,
            exports: {}
        };
        return i[n].call(t.exports, t, t.exports, o), t.l = !0, t.exports;
    }
    return o.m = i, o.c = r, o.d = function(n, i, r) {
        o.o(n, i) || Object.defineProperty(n, i, {
            enumerable: !0,
            get: r
        });
    }, o.r = function(n) {
        "undefined" != typeof Symbol && Symbol.toStringTag && Object.defineProperty(n, Symbol.toStringTag, {
            value: "Module"
        }), Object.defineProperty(n, "__esModule", {
            value: !0
        });
    }, o.t = function(i, r) {
        if (1 & r && (i = o(i)), 8 & r) return i;
        if (4 & r && "object" === n(i) && i && i.__esModule) return i;
        var t = Object.create(null);
        if (o.r(t), Object.defineProperty(t, "default", {
            enumerable: !0,
            value: i
        }), 2 & r && "string" != typeof i) for (var e in i) o.d(t, e, function(n) {
            return i[n];
        }.bind(null, e));
        return t;
    }, o.n = function(n) {
        var i = n && n.__esModule ? function() {
            return n.default;
        } : function() {
            return n;
        };
        return o.d(i, "a", i), i;
    }, o.o = function(n, i) {
        return Object.prototype.hasOwnProperty.call(n, i);
    }, o.p = "", o(o.s = 0);
}([ function(i, r, o) {
    r.__esModule = !0, r.storeBindingsBehavior = void 0;
    var t = "function" == typeof Symbol && "symbol" === n(Symbol.iterator) ? function(i) {
        return n(i);
    } : function(i) {
        return i && "function" == typeof Symbol && i.constructor === Symbol && i !== Symbol.prototype ? "symbol" : n(i);
    };
    r.createStoreBindings = function(n, i) {
        return u(n, i), f(n, i);
    };
    var e = o(1);
    function u(n, i) {
        var r = i.store, o = i.actions;
        if (o) {
            if (void 0 === r) throw new Error("[mobx-miniprogram] no store specified");
            o instanceof Array ? o.forEach(function(i) {
                n[i] = function() {
                    return r[i].apply(r, arguments);
                };
            }) : "object" === (void 0 === o ? "undefined" : t(o)) && Object.keys(o).forEach(function(i) {
                var t = o[i];
                if ("string" != typeof i && "number" != typeof i) throw new Error("[mobx-miniprogram] unrecognized field definition");
                n[i] = function() {
                    return r[t].apply(r, arguments);
                };
            });
        }
    }
    function f(n, i) {
        var r = i.store, o = i.fields, u = null;
        function f() {
            if (null !== u) {
                var i = u;
                u = null, n.setData(i);
            }
        }
        function a(n, i) {
            u || (u = {}, wx.nextTick(f)), u[n] = i;
        }
        var s = [];
        if (o instanceof Array) {
            if (void 0 === r) throw new Error("[mobx-miniprogram] no store specified");
            s = o.map(function(n) {
                return (0, e.reaction)(function() {
                    return r[n];
                }, function(i) {
                    a(n, i);
                }, {
                    fireImmediately: !0
                });
            });
        } else "object" === (void 0 === o ? "undefined" : t(o)) && o && (s = Object.keys(o).map(function(i) {
            var t = o[i];
            if ("function" == typeof t) return (0, e.reaction)(function() {
                return t.call(n, r);
            }, function(n) {
                a(i, n);
            }, {
                fireImmediately: !0
            });
            if ("string" != typeof i && "number" != typeof i) throw new Error("[mobx-miniprogram] unrecognized field definition");
            if (void 0 === r) throw new Error("[mobx-miniprogram] no store specified");
            return (0, e.reaction)(function() {
                return r[t];
            }, function(n) {
                a(String(i), n);
            }, {
                fireImmediately: !0
            });
        }));
        return {
            updateStoreBindings: f,
            destroyStoreBindings: function() {
                s.forEach(function(n) {
                    return n();
                });
            }
        };
    }
    r.storeBindingsBehavior = Behavior({
        definitionFilter: function(n) {
            n.methods || (n.methods = {});
            var i = n.storeBindings;
            n.methods._mobxMiniprogramBindings = function() {
                return i;
            }, i && (Array.isArray(i) ? i.forEach(function(i) {
                u(n.methods, i);
            }) : u(n.methods, i));
        },
        attached: function() {
            if ("function" == typeof this._mobxMiniprogramBindings) {
                var n = this._mobxMiniprogramBindings();
                if (n) if (Array.isArray(n)) {
                    var i = this;
                    this._mobxMiniprogramBindings = n.map(function(n) {
                        return f(i, n);
                    });
                } else this._mobxMiniprogramBindings = f(this, n); else this._mobxMiniprogramBindings = null;
            }
        },
        detached: function() {
            this._mobxMiniprogramBindings && (Array.isArray(this._mobxMiniprogramBindings) ? this._mobxMiniprogramBindings.forEach(function(n) {
                n.destroyStoreBindings();
            }) : this._mobxMiniprogramBindings.destroyStoreBindings());
        },
        methods: {
            updateStoreBindings: function() {
                this._mobxMiniprogramBindings && "function" != typeof this._mobxMiniprogramBindings && (Array.isArray(this._mobxMiniprogramBindings) ? this._mobxMiniprogramBindings.forEach(function(n) {
                    n.updateStoreBindings();
                }) : this._mobxMiniprogramBindings.updateStoreBindings());
            }
        }
    });
}, function(n, i) {
    n.exports = require("mobx-miniprogram");
} ]);