!function() {
    var o, t = new Set(), n = new Set();
    wx.onNeedPrivacyAuthorization && wx.onNeedPrivacyAuthorization(function(t) {
        console.log("触发 onNeedPrivacyAuthorization"), "function" == typeof o && o(t);
    });
    var e = function(o) {
        n.forEach(function(t) {
            o !== t && t();
        });
    };
    Component({
        properties: {
            customStyle: String,
            coverStyle: String
        },
        data: {
            title: "用户隐私保护提示",
            desc1: "感谢你使用本小程序，你使用本小程序前应当阅读并同意",
            urlTitle: "《用户隐私保护指引》",
            desc2: "当你点击同意并开始使用产品服务时，即表示你已理解并同意该条款内容，该条款将对你产生法律约束力。如你拒绝，将无法正常使用小程序。",
            innerShow: !1,
            height: 0
        },
        lifetimes: {
            attached: function() {
                var i = this, c = function() {
                    i.disPopUp();
                };
                o = function(o) {
                    t.add(o), i.popUp(), e(c);
                }, this.closePopUp = c, n.add(this.closePopUp);
            },
            detached: function() {
                n.delete(this.closePopUp);
            }
        },
        pageLifetimes: {
            show: function() {
                var n = this;
                this.closePopUp && (o = function(o) {
                    t.add(o), n.popUp(), e(n.closePopUp);
                });
            }
        },
        methods: {
            handleAgree: function() {
                this.disPopUp(), t.forEach(function(o) {
                    o({
                        event: "agree",
                        buttonId: "agree-btn"
                    });
                }), t.clear();
            },
            handleDisagree: function() {
                this.disPopUp(), t.forEach(function(o) {
                    o({
                        event: "disagree"
                    });
                }), t.clear();
            },
            popUp: function() {
                !1 === this.data.innerShow && this.setData({
                    innerShow: !0
                });
            },
            disPopUp: function() {
                !0 === this.data.innerShow && this.setData({
                    innerShow: !1
                });
            },
            openPrivacyContract: function() {
                wx.openPrivacyContract({
                    success: function() {
                        console.log("openPrivacyContract success");
                    },
                    fail: function(o) {
                        console.error("openPrivacyContract fail", o);
                    }
                });
            }
        }
    }), module.exports = {};
}();