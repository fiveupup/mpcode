var t = require("../../../@babel/runtime/helpers/typeof");

module.exports = function(e) {
    var r = {};
    function n(t) {
        if (r[t]) return r[t].exports;
        var i = r[t] = {
            i: t,
            l: !1,
            exports: {}
        };
        return e[t].call(i.exports, i, i.exports, n), i.l = !0, i.exports;
    }
    return n.m = e, n.c = r, n.d = function(t, e, r) {
        n.o(t, e) || Object.defineProperty(t, e, {
            enumerable: !0,
            get: r
        });
    }, n.r = function(t) {
        "undefined" != typeof Symbol && Symbol.toStringTag && Object.defineProperty(t, Symbol.toStringTag, {
            value: "Module"
        }), Object.defineProperty(t, "__esModule", {
            value: !0
        });
    }, n.t = function(e, r) {
        if (1 & r && (e = n(e)), 8 & r) return e;
        if (4 & r && "object" === t(e) && e && e.__esModule) return e;
        var i = Object.create(null);
        if (n.r(i), Object.defineProperty(i, "default", {
            enumerable: !0,
            value: e
        }), 2 & r && "string" != typeof e) for (var o in e) n.d(i, o, function(t) {
            return e[t];
        }.bind(null, o));
        return i;
    }, n.n = function(t) {
        var e = t && t.__esModule ? function() {
            return t.default;
        } : function() {
            return t;
        };
        return n.d(e, "a", e), e;
    }, n.o = function(t, e) {
        return Object.prototype.hasOwnProperty.call(t, e);
    }, n.p = "", n(n.s = 0);
}([ function(t, e) {
    Component({
        properties: {
            visible: Boolean,
            duration: {
                value: 200,
                type: Number
            },
            opacity: {
                value: .25,
                type: Number
            },
            customStyle: String,
            coverStyle: String
        },
        data: {
            isExist: !1,
            animation: ""
        },
        timer: null,
        observers: {
            visible: function(t) {
                var e = this;
                clearTimeout(this.timer), !0 === t ? this.setData({
                    isExist: !0,
                    animation: "in"
                }) : (this.setData({
                    animation: "out"
                }), this.timer = setTimeout(function() {
                    e.setData({
                        isExist: !1
                    });
                }, this.data.duration));
            }
        },
        methods: {
            noop: function() {},
            onClose: function() {
                this.triggerEvent("close"), this.triggerEvent("hide");
            }
        }
    });
} ]);