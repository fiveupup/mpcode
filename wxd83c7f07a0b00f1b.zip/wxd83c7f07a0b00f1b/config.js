Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.default = void 0, require("@babel/runtime/helpers/Arrayincludes");

var e, t = (e = require("./version")) && e.__esModule ? e : {
    default: e
};

var r = wx.getAccountInfoSync(), a = [ "trial", "develop" ].includes(r.miniProgram.envVersion), n = {
    API_HOST: a ? "https://api-pre.readhub.cn/mina_v2" : "https://api.readhub.cn/mina_v2",
    COMMON_API_HOST: a ? "https://api-pre.readhub.cn" : "https://api.readhub.cn",
    NOCODE_API_HOST: "https://nocode.com/api",
    VERSION: t.default,
    SESSION_KEY: "SESSION_3",
    USER_STORAGE_KEY: "USER_2",
    USER_KEY: "USER_KEY_3",
    APP_SETTING_KEY: "appSetting",
    GA: {
        name: "Readhub-Mina",
        id: "UA-90430221-3",
        proxy: "https://readhub-ga.nocode.com",
        web: "https://readhub.cn"
    },
    dsn: "https://f66156f257724ef7b0603e56ef1a8152@sentry2.nocode.com/15"
};

exports.default = n;