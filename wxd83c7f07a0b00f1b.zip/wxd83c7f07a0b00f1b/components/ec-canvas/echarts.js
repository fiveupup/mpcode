var t = require("../../@babel/runtime/helpers/typeof");

!function(e, n) {
    "object" == ("undefined" == typeof exports ? "undefined" : t(exports)) && "undefined" != typeof module ? n(exports) : "function" == typeof define && define.amd ? define([ "exports" ], n) : n((void 0).echarts = {});
}(0, function(e) {
    function n(t, e) {
        "createCanvas" === t && (zh = null), Eh[t] = e;
    }
    function i(e) {
        if (null == e || "object" != t(e)) return e;
        var n = e, r = Ch.call(e);
        if ("[object Array]" === r) {
            if (!B(e)) {
                n = [];
                for (var o = 0, a = e.length; a > o; o++) n[o] = i(e[o]);
            }
        } else if (Th[r]) {
            if (!B(e)) {
                var s = e.constructor;
                if (e.constructor.from) n = s.from(e); else {
                    n = new s(e.length);
                    for (o = 0, a = e.length; a > o; o++) n[o] = i(e[o]);
                }
            }
        } else if (!Ih[r] && !B(e) && !I(e)) for (var l in n = {}, e) e.hasOwnProperty(l) && (n[l] = i(e[l]));
        return n;
    }
    function r(t, e, n) {
        if (!b(e) || !b(t)) return n ? i(e) : t;
        for (var o in e) if (e.hasOwnProperty(o)) {
            var a = t[o], s = e[o];
            !b(s) || !b(a) || _(s) || _(a) || I(s) || I(a) || S(s) || S(a) || B(s) || B(a) ? !n && o in t || (t[o] = i(e[o])) : r(a, s, n);
        }
        return t;
    }
    function o(t, e) {
        for (var n = t[0], i = 1, o = t.length; o > i; i++) n = r(n, t[i], e);
        return n;
    }
    function a(t, e) {
        for (var n in e) e.hasOwnProperty(n) && (t[n] = e[n]);
        return t;
    }
    function s(t, e, n) {
        for (var i in e) e.hasOwnProperty(i) && (n ? null != e[i] : null == t[i]) && (t[i] = e[i]);
        return t;
    }
    function l() {
        return zh || (zh = Bh().getContext("2d")), zh;
    }
    function h(t, e) {
        if (t) {
            if (t.indexOf) return t.indexOf(e);
            for (var n = 0, i = t.length; i > n; n++) if (t[n] === e) return n;
        }
        return -1;
    }
    function u(t, e) {
        function n() {}
        var i = t.prototype;
        for (var r in n.prototype = e.prototype, t.prototype = new n(), i) i.hasOwnProperty(r) && (t.prototype[r] = i[r]);
        t.prototype.constructor = t, t.superClass = e;
    }
    function c(t, e, n) {
        s(t = "prototype" in t ? t.prototype : t, e = "prototype" in e ? e.prototype : e, n);
    }
    function d(t) {
        return t ? "string" != typeof t && "number" == typeof t.length : void 0;
    }
    function f(t, e, n) {
        if (t && e) if (t.forEach && t.forEach === Dh) t.forEach(e, n); else if (t.length === +t.length) for (var i = 0, r = t.length; r > i; i++) e.call(n, t[i], i, t); else for (var o in t) t.hasOwnProperty(o) && e.call(n, t[o], o, t);
    }
    function p(t, e, n) {
        if (t && e) {
            if (t.map && t.map === Lh) return t.map(e, n);
            for (var i = [], r = 0, o = t.length; o > r; r++) i.push(e.call(n, t[r], r, t));
            return i;
        }
    }
    function g(t, e, n, i) {
        if (t && e) {
            if (t.reduce && t.reduce === Oh) return t.reduce(e, n, i);
            for (var r = 0, o = t.length; o > r; r++) n = e.call(i, n, t[r], r, t);
            return n;
        }
    }
    function v(t, e, n) {
        if (t && e) {
            if (t.filter && t.filter === kh) return t.filter(e, n);
            for (var i = [], r = 0, o = t.length; o > r; r++) e.call(n, t[r], r, t) && i.push(t[r]);
            return i;
        }
    }
    function m(t, e) {
        var n = Ph.call(arguments, 2);
        return function() {
            return t.apply(e, n.concat(Ph.call(arguments)));
        };
    }
    function y(t) {
        var e = Ph.call(arguments, 1);
        return function() {
            return t.apply(this, e.concat(Ph.call(arguments)));
        };
    }
    function _(t) {
        return "[object Array]" === Ch.call(t);
    }
    function x(t) {
        return "function" == typeof t;
    }
    function w(t) {
        return "[object String]" === Ch.call(t);
    }
    function b(e) {
        var n = t(e);
        return "function" === n || !!e && "object" === n;
    }
    function S(t) {
        return !!Ih[Ch.call(t)];
    }
    function M(t) {
        return !!Th[Ch.call(t)];
    }
    function I(e) {
        return "object" == t(e) && "number" == typeof e.nodeType && "object" == t(e.ownerDocument);
    }
    function T(t) {
        return t != t;
    }
    function C() {
        for (var t = 0, e = arguments.length; e > t; t++) if (null != arguments[t]) return arguments[t];
    }
    function A(t, e) {
        return null != t ? t : e;
    }
    function D(t, e, n) {
        return null != t ? t : null != e ? e : n;
    }
    function k() {
        return Function.call.apply(Ph, arguments);
    }
    function P(t) {
        if ("number" == typeof t) return [ t, t, t, t ];
        var e = t.length;
        return 2 === e ? [ t[0], t[1], t[0], t[1] ] : 3 === e ? [ t[0], t[1], t[2], t[1] ] : t;
    }
    function L(t, e) {
        if (!t) throw new Error(e);
    }
    function O(t) {
        return null == t ? null : "function" == typeof t.trim ? t.trim() : t.replace(/^[\s\uFEFF\xA0]+|[\s\uFEFF\xA0]+$/g, "");
    }
    function E(t) {
        t[Nh] = !0;
    }
    function B(t) {
        return t[Nh];
    }
    function z(t) {
        function e(t, e) {
            n ? i.set(t, e) : i.set(e, t);
        }
        var n = _(t);
        this.data = {};
        var i = this;
        t instanceof z ? t.each(e) : t && f(t, e);
    }
    function N(t) {
        return new z(t);
    }
    function R() {}
    function F(t, e) {
        var n = new Fh(2);
        return null == t && (t = 0), null == e && (e = 0), n[0] = t, n[1] = e, n;
    }
    function V(t, e) {
        return t[0] = e[0], t[1] = e[1], t;
    }
    function H(t) {
        var e = new Fh(2);
        return e[0] = t[0], e[1] = t[1], e;
    }
    function G(t, e, n) {
        return t[0] = e[0] + n[0], t[1] = e[1] + n[1], t;
    }
    function W(t, e, n, i) {
        return t[0] = e[0] + n[0] * i, t[1] = e[1] + n[1] * i, t;
    }
    function X(t, e, n) {
        return t[0] = e[0] - n[0], t[1] = e[1] - n[1], t;
    }
    function U(t) {
        return Math.sqrt(Y(t));
    }
    function Y(t) {
        return t[0] * t[0] + t[1] * t[1];
    }
    function q(t, e, n) {
        return t[0] = e[0] * n, t[1] = e[1] * n, t;
    }
    function j(t, e) {
        var n = U(e);
        return 0 === n ? (t[0] = 0, t[1] = 0) : (t[0] = e[0] / n, t[1] = e[1] / n), t;
    }
    function Z(t, e) {
        return Math.sqrt((t[0] - e[0]) * (t[0] - e[0]) + (t[1] - e[1]) * (t[1] - e[1]));
    }
    function K(t, e) {
        return (t[0] - e[0]) * (t[0] - e[0]) + (t[1] - e[1]) * (t[1] - e[1]);
    }
    function $(t, e, n) {
        var i = e[0], r = e[1];
        return t[0] = n[0] * i + n[2] * r + n[4], t[1] = n[1] * i + n[3] * r + n[5], t;
    }
    function Q(t, e, n) {
        return t[0] = Math.min(e[0], n[0]), t[1] = Math.min(e[1], n[1]), t;
    }
    function J(t, e, n) {
        return t[0] = Math.max(e[0], n[0]), t[1] = Math.max(e[1], n[1]), t;
    }
    function tt() {
        this.on("mousedown", this._dragStart, this), this.on("mousemove", this._drag, this), 
        this.on("mouseup", this._dragEnd, this);
    }
    function et(t, e) {
        return {
            target: t,
            topTarget: e && e.topTarget
        };
    }
    function nt(t, e, n, i, r, o) {
        var a = t._$handlers;
        if ("function" == typeof n && (r = i, i = n, n = null), !i || !e) return t;
        n = function(t, e) {
            var n = t._$eventProcessor;
            return null != e && n && n.normalizeQuery && (e = n.normalizeQuery(e)), e;
        }(t, n), a[e] || (a[e] = []);
        for (var s = 0; s < a[e].length; s++) if (a[e][s].h === i) return t;
        var l = {
            h: i,
            one: o,
            query: n,
            ctx: r || t,
            callAtLast: i.zrEventfulCallAtLast
        }, h = a[e].length - 1, u = a[e][h];
        return u && u.callAtLast ? a[e].splice(h, 0, l) : a[e].push(l), t;
    }
    function it(t, e, n, i, r, o) {
        var a = i + "-" + r, s = t.length;
        if (o.hasOwnProperty(a)) return o[a];
        if (1 === e) {
            var l = Math.round(Math.log((1 << s) - 1 & ~r) / qh);
            return t[n][l];
        }
        for (var h = i | 1 << n, u = n + 1; i & 1 << u; ) u++;
        for (var c = 0, d = 0, f = 0; s > d; d++) {
            var p = 1 << d;
            p & r || (c += (f % 2 ? -1 : 1) * t[n][d] * it(t, e - 1, u, h, r | p, o), f++);
        }
        return o[a] = c, c;
    }
    function rt(t, e) {
        var n = [ [ t[0], t[1], 1, 0, 0, 0, -e[0] * t[0], -e[0] * t[1] ], [ 0, 0, 0, t[0], t[1], 1, -e[1] * t[0], -e[1] * t[1] ], [ t[2], t[3], 1, 0, 0, 0, -e[2] * t[2], -e[2] * t[3] ], [ 0, 0, 0, t[2], t[3], 1, -e[3] * t[2], -e[3] * t[3] ], [ t[4], t[5], 1, 0, 0, 0, -e[4] * t[4], -e[4] * t[5] ], [ 0, 0, 0, t[4], t[5], 1, -e[5] * t[4], -e[5] * t[5] ], [ t[6], t[7], 1, 0, 0, 0, -e[6] * t[6], -e[6] * t[7] ], [ 0, 0, 0, t[6], t[7], 1, -e[7] * t[6], -e[7] * t[7] ] ], i = {}, r = it(n, 8, 0, 0, 0, i);
        if (0 !== r) {
            for (var o = [], a = 0; 8 > a; a++) for (var s = 0; 8 > s; s++) null == o[s] && (o[s] = 0), 
            o[s] += ((a + s) % 2 ? -1 : 1) * it(n, 7, 0 === a ? 1 : 0, 1 << a, 1 << s, i) / r * e[a];
            return function(t, e, n) {
                var i = e * o[6] + n * o[7] + 1;
                t[0] = (e * o[0] + n * o[1] + o[2]) / i, t[1] = (e * o[3] + n * o[4] + o[5]) / i;
            };
        }
    }
    function ot(t, e, n, i, r) {
        if (e.getBoundingClientRect && Mh.domSupported && !at(e)) {
            var o = e[jh] || (e[jh] = {}), a = function(t, e, n) {
                for (var i = n ? "invTrans" : "trans", r = e[i], o = e.srcCoords, a = !0, s = [], l = [], h = 0; 4 > h; h++) {
                    var u = t[h].getBoundingClientRect(), c = 2 * h, d = u.left, f = u.top;
                    s.push(d, f), a = a && o && d === o[c] && f === o[c + 1], l.push(t[h].offsetLeft, t[h].offsetTop);
                }
                return a && r ? r : (e.srcCoords = s, e[i] = n ? rt(l, s) : rt(s, l));
            }(function(t, e) {
                var n = e.markers;
                if (n) return n;
                n = e.markers = [];
                for (var i = [ "left", "right" ], r = [ "top", "bottom" ], o = 0; 4 > o; o++) {
                    var a = document.createElement("div"), s = a.style, l = o % 2, h = (o >> 1) % 2;
                    s.cssText = [ "position: absolute", "visibility: hidden", "padding: 0", "margin: 0", "border-width: 0", "user-select: none", "width:0", "height:0", i[l] + ":0", r[h] + ":0", i[1 - l] + ":auto", r[1 - h] + ":auto", "" ].join("!important;"), 
                    t.appendChild(a), n.push(a);
                }
                return n;
            }(e, o), o, r);
            if (a) return a(t, n, i), !0;
        }
        return !1;
    }
    function at(t) {
        return "CANVAS" === t.nodeName.toUpperCase();
    }
    function st(t, e, n, i) {
        return n = n || {}, i || !Mh.canvasSupported ? lt(t, e, n) : Mh.browser.firefox && null != e.layerX && e.layerX !== e.offsetX ? (n.zrX = e.layerX, 
        n.zrY = e.layerY) : null != e.offsetX ? (n.zrX = e.offsetX, n.zrY = e.offsetY) : lt(t, e, n), 
        n;
    }
    function lt(t, e, n) {
        if (Mh.domSupported && t.getBoundingClientRect) {
            var i = e.clientX, r = e.clientY;
            if (at(t)) {
                var o = t.getBoundingClientRect();
                return n.zrX = i - o.left, void (n.zrY = r - o.top);
            }
            if (ot(Qh, t, i, r)) return n.zrX = Qh[0], void (n.zrY = Qh[1]);
        }
        n.zrX = n.zrY = 0;
    }
    function ht(t) {
        return t || window.event;
    }
    function ut(t, e, n) {
        if (null != (e = ht(e)).zrX) return e;
        var i = e.type;
        if (i && i.indexOf("touch") >= 0) {
            var r = "touchend" !== i ? e.targetTouches[0] : e.changedTouches[0];
            r && st(t, r, e, n);
        } else st(t, e, e, n), e.zrDelta = e.wheelDelta ? e.wheelDelta / 120 : -(e.detail || 0) / 3;
        var o = e.button;
        return null == e.which && void 0 !== o && $h.test(e.type) && (e.which = 1 & o ? 1 : 2 & o ? 3 : 4 & o ? 2 : 0), 
        e;
    }
    function ct(t, e, n, i) {
        Kh ? t.removeEventListener(e, n, i) : t.detachEvent("on" + e, n);
    }
    function dt(t) {
        var e = t[1][0] - t[0][0], n = t[1][1] - t[0][1];
        return Math.sqrt(e * e + n * n);
    }
    function ft() {
        Jh(this.event);
    }
    function pt() {}
    function gt(t, e, n) {
        if (t[t.rectHover ? "rectContain" : "contain"](e, n)) {
            for (var i, r = t; r; ) {
                if (r.clipPath && !r.clipPath.contain(e, n)) return !1;
                r.silent && (i = !0), r = r.parent;
            }
            return !i || nu;
        }
        return !1;
    }
    function vt(t, e, n) {
        var i = t.painter;
        return 0 > e || e > i.getWidth() || 0 > n || n > i.getHeight();
    }
    function mt() {
        var t = new ou(6);
        return yt(t), t;
    }
    function yt(t) {
        return t[0] = 1, t[1] = 0, t[2] = 0, t[3] = 1, t[4] = 0, t[5] = 0, t;
    }
    function _t(t, e) {
        return t[0] = e[0], t[1] = e[1], t[2] = e[2], t[3] = e[3], t[4] = e[4], t[5] = e[5], 
        t;
    }
    function xt(t, e, n) {
        var i = e[0] * n[0] + e[2] * n[1], r = e[1] * n[0] + e[3] * n[1], o = e[0] * n[2] + e[2] * n[3], a = e[1] * n[2] + e[3] * n[3], s = e[0] * n[4] + e[2] * n[5] + e[4], l = e[1] * n[4] + e[3] * n[5] + e[5];
        return t[0] = i, t[1] = r, t[2] = o, t[3] = a, t[4] = s, t[5] = l, t;
    }
    function wt(t, e, n) {
        return t[0] = e[0], t[1] = e[1], t[2] = e[2], t[3] = e[3], t[4] = e[4] + n[0], t[5] = e[5] + n[1], 
        t;
    }
    function bt(t, e, n) {
        var i = e[0], r = e[2], o = e[4], a = e[1], s = e[3], l = e[5], h = Math.sin(n), u = Math.cos(n);
        return t[0] = i * u + a * h, t[1] = -i * h + a * u, t[2] = r * u + s * h, t[3] = -r * h + u * s, 
        t[4] = u * o + h * l, t[5] = u * l - h * o, t;
    }
    function St(t, e, n) {
        var i = n[0], r = n[1];
        return t[0] = e[0] * i, t[1] = e[1] * r, t[2] = e[2] * i, t[3] = e[3] * r, t[4] = e[4] * i, 
        t[5] = e[5] * r, t;
    }
    function Mt(t, e) {
        var n = e[0], i = e[2], r = e[4], o = e[1], a = e[3], s = e[5], l = n * a - o * i;
        return l ? (l = 1 / l, t[0] = a * l, t[1] = -o * l, t[2] = -i * l, t[3] = n * l, 
        t[4] = (i * s - a * r) * l, t[5] = (o * r - n * s) * l, t) : null;
    }
    function It(t) {
        return t > lu || -lu > t;
    }
    function Tt(t) {
        this._target = t.target, this._life = t.life || 1e3, this._delay = t.delay || 0, 
        this._initialized = !1, this.loop = null != t.loop && t.loop, this.gap = t.gap || 0, 
        this.easing = t.easing || "Linear", this.onframe = t.onframe, this.ondestroy = t.ondestroy, 
        this.onrestart = t.onrestart, this._pausedTime = 0, this._paused = !1;
    }
    function Ct(t) {
        return 0 > (t = Math.round(t)) ? 0 : t > 255 ? 255 : t;
    }
    function At(t) {
        return 0 > t ? 0 : t > 1 ? 1 : t;
    }
    function Dt(t) {
        return Ct(t.length && "%" === t.charAt(t.length - 1) ? parseFloat(t) / 100 * 255 : parseInt(t, 10));
    }
    function kt(t) {
        return At(t.length && "%" === t.charAt(t.length - 1) ? parseFloat(t) / 100 : parseFloat(t));
    }
    function Pt(t, e, n) {
        return 0 > n ? n += 1 : n > 1 && (n -= 1), 1 > 6 * n ? t + (e - t) * n * 6 : 1 > 2 * n ? e : 2 > 3 * n ? t + (e - t) * (2 / 3 - n) * 6 : t;
    }
    function Lt(t, e, n) {
        return t + (e - t) * n;
    }
    function Ot(t, e, n, i, r) {
        return t[0] = e, t[1] = n, t[2] = i, t[3] = r, t;
    }
    function Et(t, e) {
        return t[0] = e[0], t[1] = e[1], t[2] = e[2], t[3] = e[3], t;
    }
    function Bt(t, e) {
        bu && Et(bu, e), bu = wu.put(t, bu || e.slice());
    }
    function zt(t, e) {
        if (t) {
            e = e || [];
            var n = wu.get(t);
            if (n) return Et(e, n);
            var i = (t += "").replace(/ /g, "").toLowerCase();
            if (i in xu) return Et(e, xu[i]), Bt(t, e), e;
            if ("#" !== i.charAt(0)) {
                var r = i.indexOf("("), o = i.indexOf(")");
                if (-1 !== r && o + 1 === i.length) {
                    var a = i.substr(0, r), s = i.substr(r + 1, o - (r + 1)).split(","), l = 1;
                    switch (a) {
                      case "rgba":
                        if (4 !== s.length) return void Ot(e, 0, 0, 0, 1);
                        l = kt(s.pop());

                      case "rgb":
                        return 3 !== s.length ? void Ot(e, 0, 0, 0, 1) : (Ot(e, Dt(s[0]), Dt(s[1]), Dt(s[2]), l), 
                        Bt(t, e), e);

                      case "hsla":
                        return 4 !== s.length ? void Ot(e, 0, 0, 0, 1) : (s[3] = kt(s[3]), Nt(s, e), Bt(t, e), 
                        e);

                      case "hsl":
                        return 3 !== s.length ? void Ot(e, 0, 0, 0, 1) : (Nt(s, e), Bt(t, e), e);

                      default:
                        return;
                    }
                }
                Ot(e, 0, 0, 0, 1);
            } else {
                var h;
                if (4 === i.length) return (h = parseInt(i.substr(1), 16)) >= 0 && 4095 >= h ? (Ot(e, (3840 & h) >> 4 | (3840 & h) >> 8, 240 & h | (240 & h) >> 4, 15 & h | (15 & h) << 4, 1), 
                Bt(t, e), e) : void Ot(e, 0, 0, 0, 1);
                if (7 === i.length) return (h = parseInt(i.substr(1), 16)) >= 0 && 16777215 >= h ? (Ot(e, (16711680 & h) >> 16, (65280 & h) >> 8, 255 & h, 1), 
                Bt(t, e), e) : void Ot(e, 0, 0, 0, 1);
            }
        }
    }
    function Nt(t, e) {
        var n = (parseFloat(t[0]) % 360 + 360) % 360 / 360, i = kt(t[1]), r = kt(t[2]), o = .5 >= r ? r * (i + 1) : r + i - r * i, a = 2 * r - o;
        return Ot(e = e || [], Ct(255 * Pt(a, o, n + 1 / 3)), Ct(255 * Pt(a, o, n)), Ct(255 * Pt(a, o, n - 1 / 3)), 1), 
        4 === t.length && (e[3] = t[3]), e;
    }
    function Rt(t, e) {
        var n = zt(t);
        if (n) {
            for (var i = 0; 3 > i; i++) n[i] = 0 > e ? n[i] * (1 - e) | 0 : (255 - n[i]) * e + n[i] | 0, 
            n[i] > 255 ? n[i] = 255 : t[i] < 0 && (n[i] = 0);
            return Gt(n, 4 === n.length ? "rgba" : "rgb");
        }
    }
    function Ft(t) {
        var e = zt(t);
        return e ? ((1 << 24) + (e[0] << 16) + (e[1] << 8) + +e[2]).toString(16).slice(1) : void 0;
    }
    function Vt(t, e, n) {
        if (e && e.length && t >= 0 && 1 >= t) {
            n = n || [];
            var i = t * (e.length - 1), r = Math.floor(i), o = Math.ceil(i), a = e[r], s = e[o], l = i - r;
            return n[0] = Ct(Lt(a[0], s[0], l)), n[1] = Ct(Lt(a[1], s[1], l)), n[2] = Ct(Lt(a[2], s[2], l)), 
            n[3] = At(Lt(a[3], s[3], l)), n;
        }
    }
    function Ht(t, e, n) {
        if (e && e.length && t >= 0 && 1 >= t) {
            var i = t * (e.length - 1), r = Math.floor(i), o = Math.ceil(i), a = zt(e[r]), s = zt(e[o]), l = i - r, h = Gt([ Ct(Lt(a[0], s[0], l)), Ct(Lt(a[1], s[1], l)), Ct(Lt(a[2], s[2], l)), At(Lt(a[3], s[3], l)) ], "rgba");
            return n ? {
                color: h,
                leftIndex: r,
                rightIndex: o,
                value: i
            } : h;
        }
    }
    function Gt(t, e) {
        if (t && t.length) {
            var n = t[0] + "," + t[1] + "," + t[2];
            return ("rgba" === e || "hsva" === e || "hsla" === e) && (n += "," + t[3]), e + "(" + n + ")";
        }
    }
    function Wt(t, e) {
        return t[e];
    }
    function Xt(t, e, n) {
        t[e] = n;
    }
    function Ut(t, e, n) {
        return (e - t) * n + t;
    }
    function Yt(t, e, n) {
        return n > .5 ? e : t;
    }
    function qt(t, e, n, i, r) {
        var o = t.length;
        if (1 === r) for (var a = 0; o > a; a++) i[a] = Ut(t[a], e[a], n); else {
            var s = o && t[0].length;
            for (a = 0; o > a; a++) for (var l = 0; s > l; l++) i[a][l] = Ut(t[a][l], e[a][l], n);
        }
    }
    function jt(t, e, n) {
        var i = t.length, r = e.length;
        if (i !== r) if (i > r) t.length = r; else for (var o = i; r > o; o++) t.push(1 === n ? e[o] : Tu.call(e[o]));
        var a = t[0] && t[0].length;
        for (o = 0; o < t.length; o++) if (1 === n) isNaN(t[o]) && (t[o] = e[o]); else for (var s = 0; a > s; s++) isNaN(t[o][s]) && (t[o][s] = e[o][s]);
    }
    function Zt(t, e, n) {
        if (t === e) return !0;
        var i = t.length;
        if (i !== e.length) return !1;
        if (1 === n) {
            for (var r = 0; i > r; r++) if (t[r] !== e[r]) return !1;
        } else {
            var o = t[0].length;
            for (r = 0; i > r; r++) for (var a = 0; o > a; a++) if (t[r][a] !== e[r][a]) return !1;
        }
        return !0;
    }
    function Kt(t, e, n, i, r, o, a, s, l) {
        var h = t.length;
        if (1 === l) for (var u = 0; h > u; u++) s[u] = $t(t[u], e[u], n[u], i[u], r, o, a); else {
            var c = t[0].length;
            for (u = 0; h > u; u++) for (var d = 0; c > d; d++) s[u][d] = $t(t[u][d], e[u][d], n[u][d], i[u][d], r, o, a);
        }
    }
    function $t(t, e, n, i, r, o, a) {
        var s = .5 * (n - t), l = .5 * (i - e);
        return (2 * (e - n) + s + l) * a + (-3 * (e - n) - 2 * s - l) * o + s * r + e;
    }
    function Qt(t) {
        if (d(t)) {
            var e = t.length;
            if (d(t[0])) {
                for (var n = [], i = 0; e > i; i++) n.push(Tu.call(t[i]));
                return n;
            }
            return Tu.call(t);
        }
        return t;
    }
    function Jt(t) {
        return t[0] = Math.floor(t[0]), t[1] = Math.floor(t[1]), t[2] = Math.floor(t[2]), 
        "rgba(" + t.join(",") + ")";
    }
    function te(t, e, n, i, r, o) {
        var a = t._getter, s = t._setter, l = "spline" === e, h = i.length;
        if (h) {
            var u, c = d(i[0].value), f = !1, p = !1, g = c ? function(t) {
                var e = t[t.length - 1].value;
                return d(e && e[0]) ? 2 : 1;
            }(i) : 0;
            i.sort(function(t, e) {
                return t.time - e.time;
            }), u = i[h - 1].time;
            for (var v = [], m = [], y = i[0].value, _ = !0, x = 0; h > x; x++) {
                v.push(i[x].time / u);
                var w = i[x].value;
                if (c && Zt(w, y, g) || !c && w === y || (_ = !1), y = w, "string" == typeof w) {
                    var b = zt(w);
                    b ? (w = b, f = !0) : p = !0;
                }
                m.push(w);
            }
            if (o || !_) {
                var S = m[h - 1];
                for (x = 0; h - 1 > x; x++) c ? jt(m[x], S, g) : !isNaN(m[x]) || isNaN(S) || p || f || (m[x] = S);
                c && jt(a(t._target, r), S, g);
                var M, I, T, C, A, D = 0, k = 0;
                if (f) var P = [ 0, 0, 0, 0 ];
                var L = new Tt({
                    target: t._target,
                    life: u,
                    loop: t._loop,
                    delay: t._delay,
                    onframe: function(t, e) {
                        var n;
                        if (0 > e) n = 0; else if (k > e) {
                            for (n = Math.min(D + 1, h - 1); n >= 0 && !(v[n] <= e); n--) ;
                            n = Math.min(n, h - 2);
                        } else {
                            for (n = D; h > n && !(v[n] > e); n++) ;
                            n = Math.min(n - 1, h - 2);
                        }
                        D = n, k = e;
                        var i = v[n + 1] - v[n];
                        if (0 !== i) if (M = (e - v[n]) / i, l) if (T = m[n], I = m[0 === n ? n : n - 1], 
                        C = m[n > h - 2 ? h - 1 : n + 1], A = m[n > h - 3 ? h - 1 : n + 2], c) Kt(I, T, C, A, M, M * M, M * M * M, a(t, r), g); else {
                            if (f) o = Kt(I, T, C, A, M, M * M, M * M * M, P, 1), o = Jt(P); else {
                                if (p) return Yt(T, C, M);
                                o = $t(I, T, C, A, M, M * M, M * M * M);
                            }
                            s(t, r, o);
                        } else if (c) qt(m[n], m[n + 1], M, a(t, r), g); else {
                            var o;
                            if (f) qt(m[n], m[n + 1], M, P, 1), o = Jt(P); else {
                                if (p) return Yt(m[n], m[n + 1], M);
                                o = Ut(m[n], m[n + 1], M);
                            }
                            s(t, r, o);
                        }
                    },
                    ondestroy: n
                });
                return e && "spline" !== e && (L.easing = e), L;
            }
        }
    }
    function ee(t, e, n, i, r, o, a, s) {
        function l() {
            --u || o && o();
        }
        w(i) ? (o = r, r = i, i = 0) : x(r) ? (o = r, r = "linear", i = 0) : x(i) ? (o = i, 
        i = 0) : x(n) ? (o = n, n = 500) : n || (n = 500), t.stopAnimation(), function t(e, n, i, r, o, a, s) {
            var l = {}, h = 0;
            for (var u in r) r.hasOwnProperty(u) && (null != i[u] ? b(r[u]) && !d(r[u]) ? t(e, n ? n + "." + u : u, i[u], r[u], o, a, s) : (s ? (l[u] = i[u], 
            ne(e, n, u, r[u])) : l[u] = r[u], h++) : null == r[u] || s || ne(e, n, u, r[u]));
            h > 0 && e.animate(n, !1).when(null == o ? 500 : o, l).delay(a || 0);
        }(t, "", t, e, n, i, s);
        var h = t.animators.slice(), u = h.length;
        u || o && o();
        for (var c = 0; c < h.length; c++) h[c].done(l).start(r, a);
    }
    function ne(t, e, n, i) {
        if (e) {
            var r = {};
            r[e] = {}, r[e][n] = i, t.attr(r);
        } else t.attr(n, i);
    }
    function ie(t, e, n, i) {
        0 > n && (t += n, n = -n), 0 > i && (e += i, i = -i), this.x = t, this.y = e, this.width = n, 
        this.height = i;
    }
    function re(t, e, n, i) {
        var r = e + 1;
        if (r === n) return 1;
        if (i(t[r++], t[e]) < 0) {
            for (;n > r && i(t[r], t[r - 1]) < 0; ) r++;
            !function(t, e, n) {
                for (n--; n > e; ) {
                    var i = t[e];
                    t[e++] = t[n], t[n--] = i;
                }
            }(t, e, r);
        } else for (;n > r && i(t[r], t[r - 1]) >= 0; ) r++;
        return r - e;
    }
    function oe(t, e, n, i, r) {
        for (i === e && i++; n > i; i++) {
            for (var o, a = t[i], s = e, l = i; l > s; ) r(a, t[o = s + l >>> 1]) < 0 ? l = o : s = o + 1;
            var h = i - s;
            switch (h) {
              case 3:
                t[s + 3] = t[s + 2];

              case 2:
                t[s + 2] = t[s + 1];

              case 1:
                t[s + 1] = t[s];
                break;

              default:
                for (;h > 0; ) t[s + h] = t[s + h - 1], h--;
            }
            t[s] = a;
        }
    }
    function ae(t, e, n, i, r, o) {
        var a = 0, s = 0, l = 1;
        if (o(t, e[n + r]) > 0) {
            for (s = i - r; s > l && o(t, e[n + r + l]) > 0; ) a = l, 0 >= (l = 1 + (l << 1)) && (l = s);
            l > s && (l = s), a += r, l += r;
        } else {
            for (s = r + 1; s > l && o(t, e[n + r - l]) <= 0; ) a = l, 0 >= (l = 1 + (l << 1)) && (l = s);
            l > s && (l = s);
            var h = a;
            a = r - l, l = r - h;
        }
        for (a++; l > a; ) {
            var u = a + (l - a >>> 1);
            o(t, e[n + u]) > 0 ? a = u + 1 : l = u;
        }
        return l;
    }
    function se(t, e, n, i, r, o) {
        var a = 0, s = 0, l = 1;
        if (o(t, e[n + r]) < 0) {
            for (s = r + 1; s > l && o(t, e[n + r - l]) < 0; ) a = l, 0 >= (l = 1 + (l << 1)) && (l = s);
            l > s && (l = s);
            var h = a;
            a = r - l, l = r - h;
        } else {
            for (s = i - r; s > l && o(t, e[n + r + l]) >= 0; ) a = l, 0 >= (l = 1 + (l << 1)) && (l = s);
            l > s && (l = s), a += r, l += r;
        }
        for (a++; l > a; ) {
            var u = a + (l - a >>> 1);
            o(t, e[n + u]) < 0 ? l = u : a = u + 1;
        }
        return l;
    }
    function le(t, e) {
        function n(n) {
            var s = o[n], h = a[n], u = o[n + 1], c = a[n + 1];
            a[n] = h + c, n === l - 3 && (o[n + 1] = o[n + 2], a[n + 1] = a[n + 2]), l--;
            var d = se(t[u], t, s, h, 0, e);
            s += d, 0 !== (h -= d) && (0 !== (c = ae(t[s + h - 1], t, u, c, c - 1, e)) && (c >= h ? i(s, h, u, c) : r(s, h, u, c)));
        }
        function i(n, i, r, o) {
            var a = 0;
            for (a = 0; i > a; a++) h[a] = t[n + a];
            var l = 0, u = r, c = n;
            if (t[c++] = t[u++], 0 != --o) {
                if (1 === i) {
                    for (a = 0; o > a; a++) t[c + a] = t[u + a];
                    return void (t[c + o] = h[l]);
                }
                for (var d, f, p, g = s; ;) {
                    d = 0, f = 0, p = !1;
                    do {
                        if (e(t[u], h[l]) < 0) {
                            if (t[c++] = t[u++], f++, d = 0, 0 == --o) {
                                p = !0;
                                break;
                            }
                        } else if (t[c++] = h[l++], d++, f = 0, 1 == --i) {
                            p = !0;
                            break;
                        }
                    } while (g > (d | f));
                    if (p) break;
                    do {
                        if (0 !== (d = se(t[u], h, l, i, 0, e))) {
                            for (a = 0; d > a; a++) t[c + a] = h[l + a];
                            if (c += d, l += d, 1 >= (i -= d)) {
                                p = !0;
                                break;
                            }
                        }
                        if (t[c++] = t[u++], 0 == --o) {
                            p = !0;
                            break;
                        }
                        if (0 !== (f = ae(h[l], t, u, o, 0, e))) {
                            for (a = 0; f > a; a++) t[c + a] = t[u + a];
                            if (c += f, u += f, 0 === (o -= f)) {
                                p = !0;
                                break;
                            }
                        }
                        if (t[c++] = h[l++], 1 == --i) {
                            p = !0;
                            break;
                        }
                        g--;
                    } while (d >= Fu || f >= Fu);
                    if (p) break;
                    0 > g && (g = 0), g += 2;
                }
                if (1 > (s = g) && (s = 1), 1 === i) {
                    for (a = 0; o > a; a++) t[c + a] = t[u + a];
                    t[c + o] = h[l];
                } else {
                    if (0 === i) throw new Error();
                    for (a = 0; i > a; a++) t[c + a] = h[l + a];
                }
            } else for (a = 0; i > a; a++) t[c + a] = h[l + a];
        }
        function r(n, i, r, o) {
            var a = 0;
            for (a = 0; o > a; a++) h[a] = t[r + a];
            var l = n + i - 1, u = o - 1, c = r + o - 1, d = 0, f = 0;
            if (t[c--] = t[l--], 0 != --i) {
                if (1 === o) {
                    for (f = (c -= i) + 1, d = (l -= i) + 1, a = i - 1; a >= 0; a--) t[f + a] = t[d + a];
                    return void (t[c] = h[u]);
                }
                for (var p = s; ;) {
                    var g = 0, v = 0, m = !1;
                    do {
                        if (e(h[u], t[l]) < 0) {
                            if (t[c--] = t[l--], g++, v = 0, 0 == --i) {
                                m = !0;
                                break;
                            }
                        } else if (t[c--] = h[u--], v++, g = 0, 1 == --o) {
                            m = !0;
                            break;
                        }
                    } while (p > (g | v));
                    if (m) break;
                    do {
                        if (0 !== (g = i - se(h[u], t, n, i, i - 1, e))) {
                            for (i -= g, f = (c -= g) + 1, d = (l -= g) + 1, a = g - 1; a >= 0; a--) t[f + a] = t[d + a];
                            if (0 === i) {
                                m = !0;
                                break;
                            }
                        }
                        if (t[c--] = h[u--], 1 == --o) {
                            m = !0;
                            break;
                        }
                        if (0 !== (v = o - ae(t[l], h, 0, o, o - 1, e))) {
                            for (o -= v, f = (c -= v) + 1, d = (u -= v) + 1, a = 0; v > a; a++) t[f + a] = h[d + a];
                            if (1 >= o) {
                                m = !0;
                                break;
                            }
                        }
                        if (t[c--] = t[l--], 0 == --i) {
                            m = !0;
                            break;
                        }
                        p--;
                    } while (g >= Fu || v >= Fu);
                    if (m) break;
                    0 > p && (p = 0), p += 2;
                }
                if (1 > (s = p) && (s = 1), 1 === o) {
                    for (f = (c -= i) + 1, d = (l -= i) + 1, a = i - 1; a >= 0; a--) t[f + a] = t[d + a];
                    t[c] = h[u];
                } else {
                    if (0 === o) throw new Error();
                    for (d = c - (o - 1), a = 0; o > a; a++) t[d + a] = h[a];
                }
            } else for (d = c - (o - 1), a = 0; o > a; a++) t[d + a] = h[a];
        }
        var o, a, s = Fu, l = 0, h = [];
        o = [], a = [], this.mergeRuns = function() {
            for (;l > 1; ) {
                var t = l - 2;
                if (t >= 1 && a[t - 1] <= a[t] + a[t + 1] || t >= 2 && a[t - 2] <= a[t] + a[t - 1]) a[t - 1] < a[t + 1] && t--; else if (a[t] > a[t + 1]) break;
                n(t);
            }
        }, this.forceMergeRuns = function() {
            for (;l > 1; ) {
                var t = l - 2;
                t > 0 && a[t - 1] < a[t + 1] && t--, n(t);
            }
        }, this.pushRun = function(t, e) {
            o[l] = t, a[l] = e, l += 1;
        };
    }
    function he(t, e, n, i) {
        n || (n = 0), i || (i = t.length);
        var r = i - n;
        if (!(2 > r)) {
            var o = 0;
            if (Ru > r) return void oe(t, n, i, n + (o = re(t, n, i, e)), e);
            var a = new le(t, e), s = function(t) {
                for (var e = 0; t >= Ru; ) e |= 1 & t, t >>= 1;
                return t + e;
            }(r);
            do {
                if (s > (o = re(t, n, i, e))) {
                    var l = r;
                    l > s && (l = s), oe(t, n, n + l, n + o, e), o = l;
                }
                a.pushRun(n, o), a.mergeRuns(), r -= o, n += o;
            } while (0 !== r);
            a.forceMergeRuns();
        }
    }
    function ue(t, e) {
        return t.zlevel === e.zlevel ? t.z === e.z ? t.z2 - e.z2 : t.z - e.z : t.zlevel - e.zlevel;
    }
    function ce(t, e, n) {
        var i = null == e.x ? 0 : e.x, r = null == e.x2 ? 1 : e.x2, o = null == e.y ? 0 : e.y, a = null == e.y2 ? 0 : e.y2;
        return e.global || (i = i * n.width + n.x, r = r * n.width + n.x, o = o * n.height + n.y, 
        a = a * n.height + n.y), i = isNaN(i) ? 0 : i, r = isNaN(r) ? 1 : r, o = isNaN(o) ? 0 : o, 
        a = isNaN(a) ? 0 : a, t.createLinearGradient(i, o, r, a);
    }
    function de(t, e, n) {
        var i = n.width, r = n.height, o = Math.min(i, r), a = null == e.x ? .5 : e.x, s = null == e.y ? .5 : e.y, l = null == e.r ? .5 : e.r;
        return e.global || (a = a * i + n.x, s = s * r + n.y, l *= o), t.createRadialGradient(a, s, 0, a, s, l);
    }
    function fe() {
        return !1;
    }
    function pe(t, e, n) {
        var i = Bh(), r = e.getWidth(), o = e.getHeight(), a = i.style;
        return a && (a.position = "absolute", a.left = 0, a.top = 0, a.width = r + "px", 
        a.height = o + "px", i.setAttribute("data-zr-dom-id", t)), i.width = r * n, i.height = o * n, 
        i;
    }
    function ge(t) {
        if ("string" == typeof t) {
            var e = Ju.get(t);
            return e && e.image;
        }
        return t;
    }
    function ve(t, e, n, i, r) {
        if (t) {
            if ("string" == typeof t) {
                if (e && e.__zrImageSrc === t || !n) return e;
                var o = Ju.get(t), a = {
                    hostEl: n,
                    cb: i,
                    cbPayload: r
                };
                return o ? !ye(e = o.image) && o.pending.push(a) : ((e = new Image()).onload = e.onerror = me, 
                Ju.put(t, e.__cachedImgObj = {
                    image: e,
                    pending: [ a ]
                }), e.src = e.__zrImageSrc = t), e;
            }
            return t;
        }
        return e;
    }
    function me() {
        var t = this.__cachedImgObj;
        this.onload = this.onerror = this.__cachedImgObj = null;
        for (var e = 0; e < t.pending.length; e++) {
            var n = t.pending[e], i = n.cb;
            i && i(this, n.cbPayload), n.hostEl.dirty();
        }
        t.pending.length = 0;
    }
    function ye(t) {
        return t && t.width && t.height;
    }
    function _e(t, e) {
        var n = t + ":" + (e = e || rc);
        if (tc[n]) return tc[n];
        for (var i = (t + "").split("\n"), r = 0, o = 0, a = i.length; a > o; o++) r = Math.max(De(i[o], e).width, r);
        return ec > nc && (ec = 0, tc = {}), ec++, tc[n] = r, r;
    }
    function xe(t, e, n, i, r, o, a, s) {
        return a ? function(t, e, n, i, r, o, a, s) {
            var l = Pe(t, {
                rich: a,
                truncate: s,
                font: e,
                textAlign: n,
                textPadding: r,
                textLineHeight: o
            }), h = l.outerWidth, u = l.outerHeight, c = we(0, h, n), d = be(0, u, i);
            return new ie(c, d, h, u);
        }(t, e, n, i, r, o, a, s) : function(t, e, n, i, r, o, a) {
            var s = ke(t, e, r, o, a), l = _e(t, e);
            r && (l += r[1] + r[3]);
            var h = s.outerHeight, u = we(0, l, n), c = be(0, h, i), d = new ie(u, c, l, h);
            return d.lineHeight = s.lineHeight, d;
        }(t, e, n, i, r, o, s);
    }
    function we(t, e, n) {
        return "right" === n ? t -= e : "center" === n && (t -= e / 2), t;
    }
    function be(t, e, n) {
        return "middle" === n ? t -= e / 2 : "bottom" === n && (t -= e), t;
    }
    function Se(t, e, n) {
        var i = e.textPosition, r = e.textDistance, o = n.x, a = n.y;
        r = r || 0;
        var s = n.height, l = n.width, h = s / 2, u = "left", c = "top";
        switch (i) {
          case "left":
            o -= r, a += h, u = "right", c = "middle";
            break;

          case "right":
            o += r + l, a += h, c = "middle";
            break;

          case "top":
            o += l / 2, a -= r, u = "center", c = "bottom";
            break;

          case "bottom":
            o += l / 2, a += s + r, u = "center";
            break;

          case "inside":
            o += l / 2, a += h, u = "center", c = "middle";
            break;

          case "insideLeft":
            o += r, a += h, c = "middle";
            break;

          case "insideRight":
            o += l - r, a += h, u = "right", c = "middle";
            break;

          case "insideTop":
            o += l / 2, a += r, u = "center";
            break;

          case "insideBottom":
            o += l / 2, a += s - r, u = "center", c = "bottom";
            break;

          case "insideTopLeft":
            o += r, a += r;
            break;

          case "insideTopRight":
            o += l - r, a += r, u = "right";
            break;

          case "insideBottomLeft":
            o += r, a += s - r, c = "bottom";
            break;

          case "insideBottomRight":
            o += l - r, a += s - r, u = "right", c = "bottom";
        }
        return (t = t || {}).x = o, t.y = a, t.textAlign = u, t.textVerticalAlign = c, t;
    }
    function Me(t, e, n, i, r) {
        if (!e) return "";
        var o = (t + "").split("\n");
        r = Ie(e, n, i, r);
        for (var a = 0, s = o.length; s > a; a++) o[a] = Te(o[a], r);
        return o.join("\n");
    }
    function Ie(t, e, n, i) {
        (i = a({}, i)).font = e;
        n = A(n, "...");
        i.maxIterations = A(i.maxIterations, 2);
        var r = i.minChar = A(i.minChar, 0);
        i.cnCharWidth = _e("国", e);
        var o = i.ascCharWidth = _e("a", e);
        i.placeholder = A(i.placeholder, "");
        for (var s = t = Math.max(0, t - 1), l = 0; r > l && s >= o; l++) s -= o;
        var h = _e(n, e);
        return h > s && (n = "", h = 0), s = t - h, i.ellipsis = n, i.ellipsisWidth = h, 
        i.contentWidth = s, i.containerWidth = t, i;
    }
    function Te(t, e) {
        var n = e.containerWidth, i = e.font, r = e.contentWidth;
        if (!n) return "";
        var o = _e(t, i);
        if (n >= o) return t;
        for (var a = 0; ;a++) {
            if (r >= o || a >= e.maxIterations) {
                t += e.ellipsis;
                break;
            }
            var s = 0 === a ? Ce(t, r, e.ascCharWidth, e.cnCharWidth) : o > 0 ? Math.floor(t.length * r / o) : 0;
            o = _e(t = t.substr(0, s), i);
        }
        return "" === t && (t = e.placeholder), t;
    }
    function Ce(t, e, n, i) {
        for (var r = 0, o = 0, a = t.length; a > o && e > r; o++) {
            var s = t.charCodeAt(o);
            r += s >= 0 && 127 >= s ? n : i;
        }
        return o;
    }
    function Ae(t) {
        return _e("国", t);
    }
    function De(t, e) {
        return oc.measureText(t, e);
    }
    function ke(t, e, n, i, r) {
        null != t && (t += "");
        var o = A(i, Ae(e)), a = t ? t.split("\n") : [], s = a.length * o, l = s, h = !0;
        if (n && (l += n[0] + n[2]), t && r) {
            h = !1;
            var u = r.outerHeight, c = r.outerWidth;
            if (null != u && l > u) t = "", a = []; else if (null != c) for (var d = Ie(c - (n ? n[1] + n[3] : 0), e, r.ellipsis, {
                minChar: r.minChar,
                placeholder: r.placeholder
            }), f = 0, p = a.length; p > f; f++) a[f] = Te(a[f], d);
        }
        return {
            lines: a,
            height: s,
            outerHeight: l,
            lineHeight: o,
            canCacheByTextString: h
        };
    }
    function Pe(t, e) {
        var n = {
            lines: [],
            width: 0,
            height: 0
        };
        if (null != t && (t += ""), !t) return n;
        for (var i, r = ic.lastIndex = 0; null != (i = ic.exec(t)); ) {
            var o = i.index;
            o > r && Le(n, t.substring(r, o)), Le(n, i[2], i[1]), r = ic.lastIndex;
        }
        r < t.length && Le(n, t.substring(r, t.length));
        var a = n.lines, s = 0, l = 0, h = [], u = e.textPadding, c = e.truncate, d = c && c.outerWidth, f = c && c.outerHeight;
        u && (null != d && (d -= u[1] + u[3]), null != f && (f -= u[0] + u[2]));
        for (var p = 0; p < a.length; p++) {
            for (var g = a[p], v = 0, m = 0, y = 0; y < g.tokens.length; y++) {
                var _ = (P = g.tokens[y]).styleName && e.rich[P.styleName] || {}, x = P.textPadding = _.textPadding, w = P.font = _.font || e.font, b = P.textHeight = A(_.textHeight, Ae(w));
                if (x && (b += x[0] + x[2]), P.height = b, P.lineHeight = D(_.textLineHeight, e.textLineHeight, b), 
                P.textAlign = _ && _.textAlign || e.textAlign, P.textVerticalAlign = _ && _.textVerticalAlign || "middle", 
                null != f && s + P.lineHeight > f) return {
                    lines: [],
                    width: 0,
                    height: 0
                };
                P.textWidth = _e(P.text, w);
                var S = _.textWidth, M = null == S || "auto" === S;
                if ("string" == typeof S && "%" === S.charAt(S.length - 1)) P.percentWidth = S, 
                h.push(P), S = 0; else {
                    if (M) {
                        S = P.textWidth;
                        var I = _.textBackgroundColor, T = I && I.image;
                        T && (ye(T = ge(T)) && (S = Math.max(S, T.width * b / T.height)));
                    }
                    var C = x ? x[1] + x[3] : 0;
                    S += C;
                    var k = null != d ? d - m : null;
                    null != k && S > k && (!M || C > k ? (P.text = "", P.textWidth = S = 0) : (P.text = Me(P.text, k - C, w, c.ellipsis, {
                        minChar: c.minChar
                    }), P.textWidth = _e(P.text, w), S = P.textWidth + C));
                }
                m += P.width = S, _ && (v = Math.max(v, P.lineHeight));
            }
            g.width = m, g.lineHeight = v, s += v, l = Math.max(l, m);
        }
        n.outerWidth = n.width = A(e.textWidth, l), n.outerHeight = n.height = A(e.textHeight, s), 
        u && (n.outerWidth += u[1] + u[3], n.outerHeight += u[0] + u[2]);
        for (p = 0; p < h.length; p++) {
            var P, L = (P = h[p]).percentWidth;
            P.width = parseInt(L, 10) / 100 * l;
        }
        return n;
    }
    function Le(t, e, n) {
        for (var i = "" === e, r = e.split("\n"), o = t.lines, a = 0; a < r.length; a++) {
            var s = r[a], l = {
                styleName: n,
                text: s,
                isLineHolder: !s && !i
            };
            if (a) o.push({
                tokens: [ l ]
            }); else {
                var h = (o[o.length - 1] || (o[0] = {
                    tokens: []
                })).tokens, u = h.length;
                1 === u && h[0].isLineHolder ? h[0] = l : (s || !u || i) && h.push(l);
            }
        }
    }
    function Oe(t, e) {
        var n, i, r, o, a, s = e.x, l = e.y, h = e.width, u = e.height, c = e.r;
        0 > h && (s += h, h = -h), 0 > u && (l += u, u = -u), "number" == typeof c ? n = i = r = o = c : c instanceof Array ? 1 === c.length ? n = i = r = o = c[0] : 2 === c.length ? (n = r = c[0], 
        i = o = c[1]) : 3 === c.length ? (n = c[0], i = o = c[1], r = c[2]) : (n = c[0], 
        i = c[1], r = c[2], o = c[3]) : n = i = r = o = 0, n + i > h && (n *= h / (a = n + i), 
        i *= h / a), r + o > h && (r *= h / (a = r + o), o *= h / a), i + r > u && (i *= u / (a = i + r), 
        r *= u / a), n + o > u && (n *= u / (a = n + o), o *= u / a), t.moveTo(s + n, l), 
        t.lineTo(s + h - i, l), 0 !== i && t.arc(s + h - i, l + i, i, -Math.PI / 2, 0), 
        t.lineTo(s + h, l + u - r), 0 !== r && t.arc(s + h - r, l + u - r, r, 0, Math.PI / 2), 
        t.lineTo(s + o, l + u), 0 !== o && t.arc(s + o, l + u - o, o, Math.PI / 2, Math.PI), 
        t.lineTo(s, l + n), 0 !== n && t.arc(s + n, l + n, n, Math.PI, 1.5 * Math.PI);
    }
    function Ee(t) {
        return Be(t), f(t.rich, Be), t;
    }
    function Be(t) {
        if (t) {
            t.font = function(t) {
                var e = (t.fontSize || t.fontFamily) && [ t.fontStyle, t.fontWeight, (t.fontSize || 12) + "px", t.fontFamily || "sans-serif" ].join(" ");
                return e && O(e) || t.textFont || t.font;
            }(t);
            var e = t.textAlign;
            "middle" === e && (e = "center"), t.textAlign = null == e || sc[e] ? e : "left";
            var n = t.textVerticalAlign || t.textBaseline;
            "center" === n && (n = "middle"), t.textVerticalAlign = null == n || lc[n] ? n : "top", 
            t.textPadding && (t.textPadding = P(t.textPadding));
        }
    }
    function ze(t, e, n, i, r, o) {
        i.rich ? function(t, e, n, i, r, o) {
            o !== Xu && (e.__attrCachedBy = Wu.NONE);
            var a = t.__textCotentBlock;
            (!a || t.__dirtyText) && (a = t.__textCotentBlock = Pe(n, i)), function(t, e, n, i, r) {
                var o = n.width, a = n.outerWidth, s = n.outerHeight, l = i.textPadding, h = Ge(cc, t, i, r), u = h.baseX, c = h.baseY, d = h.textAlign, f = h.textVerticalAlign;
                Ne(e, i, r, u, c);
                var p = we(u, a, d), g = be(c, s, f), v = p, m = g;
                l && (v += l[3], m += l[0]);
                var y = v + o;
                Fe(i) && Ve(t, e, i, p, g, a, s);
                for (var _ = 0; _ < n.lines.length; _++) {
                    for (var x, w = n.lines[_], b = w.tokens, S = b.length, M = w.lineHeight, I = w.width, T = 0, C = v, A = y, D = S - 1; S > T && (!(x = b[T]).textAlign || "left" === x.textAlign); ) Re(t, e, x, i, M, m, C, "left"), 
                    I -= x.width, C += x.width, T++;
                    for (;D >= 0 && "right" === (x = b[D]).textAlign; ) Re(t, e, x, i, M, m, A, "right"), 
                    I -= x.width, A -= x.width, D--;
                    for (C += (o - (C - v) - (y - A) - I) / 2; D >= T; ) x = b[T], Re(t, e, x, i, M, m, C + x.width / 2, "center"), 
                    C += x.width, T++;
                    m += M;
                }
            }(t, e, a, i, r);
        }(t, e, n, i, r, o) : function(t, e, n, i, r, o) {
            var a, s = Fe(i), l = !1, h = e.__attrCachedBy === Wu.PLAIN_TEXT;
            o !== Xu ? (o && (a = o.style, l = !s && h && a), e.__attrCachedBy = s ? Wu.NONE : Wu.PLAIN_TEXT) : h && (e.__attrCachedBy = Wu.NONE);
            var u = i.font || ac;
            l && u === (a.font || ac) || (e.font = u);
            var c = t.__computedFont;
            t.__styleFont !== u && (t.__styleFont = u, c = t.__computedFont = e.font);
            var d = i.textPadding, f = i.textLineHeight, p = t.__textCotentBlock;
            (!p || t.__dirtyText) && (p = t.__textCotentBlock = ke(n, c, d, f, i.truncate));
            var g = p.outerHeight, v = p.lines, m = p.lineHeight, y = Ge(cc, t, i, r), _ = y.baseX, x = y.baseY, w = y.textAlign || "left", b = y.textVerticalAlign;
            Ne(e, i, r, _, x);
            var S = be(x, g, b), M = _, I = S;
            if (s || d) {
                var T = _e(n, c);
                d && (T += d[1] + d[3]);
                var C = we(_, T, w);
                s && Ve(t, e, i, C, S, T, g), d && (M = qe(_, w, d), I += d[0]);
            }
            e.textAlign = w, e.textBaseline = "middle", e.globalAlpha = i.opacity || 1;
            for (var A = 0; A < hc.length; A++) {
                var D = hc[A], k = D[0], P = D[1], L = i[k];
                l && L === a[k] || (e[P] = Gu(e, P, L || D[2]));
            }
            I += m / 2;
            var O = i.textStrokeWidth, E = l ? a.textStrokeWidth : null, B = !l || O !== E, z = !l || B || i.textStroke !== a.textStroke, N = Xe(i.textStroke, O), R = Ue(i.textFill);
            if (N && (B && (e.lineWidth = O), z && (e.strokeStyle = N)), R && (l && i.textFill === a.textFill || (e.fillStyle = R)), 
            1 === v.length) N && e.strokeText(v[0], M, I), R && e.fillText(v[0], M, I); else for (A = 0; A < v.length; A++) N && e.strokeText(v[A], M, I), 
            R && e.fillText(v[A], M, I), I += m;
        }(t, e, n, i, r, o);
    }
    function Ne(t, e, n, i, r) {
        if (n && e.textRotation) {
            var o = e.textOrigin;
            "center" === o ? (i = n.width / 2 + n.x, r = n.height / 2 + n.y) : o && (i = o[0] + n.x, 
            r = o[1] + n.y), t.translate(i, r), t.rotate(-e.textRotation), t.translate(-i, -r);
        }
    }
    function Re(t, e, n, i, r, o, a, s) {
        var l = i.rich[n.styleName] || {};
        l.text = n.text;
        var h = n.textVerticalAlign, u = o + r / 2;
        "top" === h ? u = o + n.height / 2 : "bottom" === h && (u = o + r - n.height / 2), 
        !n.isLineHolder && Fe(l) && Ve(t, e, l, "right" === s ? a - n.width : "center" === s ? a - n.width / 2 : a, u - n.height / 2, n.width, n.height);
        var c = n.textPadding;
        c && (a = qe(a, s, c), u -= n.height / 2 - c[2] - n.textHeight / 2), We(e, "shadowBlur", D(l.textShadowBlur, i.textShadowBlur, 0)), 
        We(e, "shadowColor", l.textShadowColor || i.textShadowColor || "transparent"), We(e, "shadowOffsetX", D(l.textShadowOffsetX, i.textShadowOffsetX, 0)), 
        We(e, "shadowOffsetY", D(l.textShadowOffsetY, i.textShadowOffsetY, 0)), We(e, "textAlign", s), 
        We(e, "textBaseline", "middle"), We(e, "font", n.font || ac);
        var d = Xe(l.textStroke || i.textStroke, p), f = Ue(l.textFill || i.textFill), p = A(l.textStrokeWidth, i.textStrokeWidth);
        d && (We(e, "lineWidth", p), We(e, "strokeStyle", d), e.strokeText(n.text, a, u)), 
        f && (We(e, "fillStyle", f), e.fillText(n.text, a, u));
    }
    function Fe(t) {
        return !!(t.textBackgroundColor || t.textBorderWidth && t.textBorderColor);
    }
    function Ve(t, e, n, i, r, o, a) {
        var s = n.textBackgroundColor, l = n.textBorderWidth, h = n.textBorderColor, u = w(s);
        if (We(e, "shadowBlur", n.textBoxShadowBlur || 0), We(e, "shadowColor", n.textBoxShadowColor || "transparent"), 
        We(e, "shadowOffsetX", n.textBoxShadowOffsetX || 0), We(e, "shadowOffsetY", n.textBoxShadowOffsetY || 0), 
        u || l && h) {
            e.beginPath();
            var c = n.textBorderRadius;
            c ? Oe(e, {
                x: i,
                y: r,
                width: o,
                height: a,
                r: c
            }) : e.rect(i, r, o, a), e.closePath();
        }
        if (u) if (We(e, "fillStyle", s), null != n.fillOpacity) {
            var d = e.globalAlpha;
            e.globalAlpha = n.fillOpacity * n.opacity, e.fill(), e.globalAlpha = d;
        } else e.fill(); else if (b(s)) {
            var f = s.image;
            (f = ve(f, null, t, He, s)) && ye(f) && e.drawImage(f, i, r, o, a);
        }
        if (l && h) if (We(e, "lineWidth", l), We(e, "strokeStyle", h), null != n.strokeOpacity) {
            d = e.globalAlpha;
            e.globalAlpha = n.strokeOpacity * n.opacity, e.stroke(), e.globalAlpha = d;
        } else e.stroke();
    }
    function He(t, e) {
        e.image = t;
    }
    function Ge(t, e, n, i) {
        var r = n.x || 0, o = n.y || 0, a = n.textAlign, s = n.textVerticalAlign;
        if (i) {
            var l = n.textPosition;
            if (l instanceof Array) r = i.x + Ye(l[0], i.width), o = i.y + Ye(l[1], i.height); else {
                var h = e && e.calculateTextPosition ? e.calculateTextPosition(uc, n, i) : Se(uc, n, i);
                r = h.x, o = h.y, a = a || h.textAlign, s = s || h.textVerticalAlign;
            }
            var u = n.textOffset;
            u && (r += u[0], o += u[1]);
        }
        return (t = t || {}).baseX = r, t.baseY = o, t.textAlign = a, t.textVerticalAlign = s, 
        t;
    }
    function We(t, e, n) {
        return t[e] = Gu(t, e, n), t[e];
    }
    function Xe(t, e) {
        return null == t || 0 >= e || "transparent" === t || "none" === t ? null : t.image || t.colorStops ? "#000" : t;
    }
    function Ue(t) {
        return null == t || "none" === t ? null : t.image || t.colorStops ? "#000" : t;
    }
    function Ye(t, e) {
        return "string" == typeof t ? t.lastIndexOf("%") >= 0 ? parseFloat(t) / 100 * e : parseFloat(t) : t;
    }
    function qe(t, e, n) {
        return "right" === e ? t - n[1] : "center" === e ? t + n[3] / 2 - n[1] / 2 : t + n[3];
    }
    function je(t, e) {
        return null != t && (t || e.textBackgroundColor || e.textBorderWidth && e.textBorderColor || e.textPadding);
    }
    function Ze(t) {
        for (var e in t = t || {}, Ou.call(this, t), t) t.hasOwnProperty(e) && "style" !== e && (this[e] = t[e]);
        this.style = new Yu(t.style, this), this._rect = null, this.__clipPaths = null;
    }
    function Ke(t) {
        Ze.call(this, t);
    }
    function $e(t) {
        return parseInt(t, 10);
    }
    function Qe(t) {
        return "mousewheel" === t && Mh.browser.firefox ? "DOMMouseScroll" : t;
    }
    function Je(t) {
        var e = t.pointerType;
        return "pen" === e || "touch" === e;
    }
    function tn(t) {
        t && (t.zrByTouch = !0);
    }
    function en(t, e) {
        for (var n = e, i = !1; n && 9 !== n.nodeType && !(i = n.domBelongToZr || n !== e && n === t.painterRoot); ) n = n.parentNode;
        return i;
    }
    function nn(t, e) {
        this.type = e.type, this.target = this.currentTarget = t.dom, this.pointerType = e.pointerType, 
        this.clientX = e.clientX, this.clientY = e.clientY;
    }
    function rn(t, e) {
        var n = e.domHandlers;
        Mh.pointerEventsSupported ? f(xc.pointer, function(i) {
            an(e, i, function(e) {
                n[i].call(t, e);
            });
        }) : (Mh.touchEventsSupported && f(xc.touch, function(i) {
            an(e, i, function(r) {
                n[i].call(t, r), function(t) {
                    t.touching = !0, null != t.touchTimer && (clearTimeout(t.touchTimer), t.touchTimer = null), 
                    t.touchTimer = setTimeout(function() {
                        t.touching = !1, t.touchTimer = null;
                    }, 700);
                }(e);
            });
        }), f(xc.mouse, function(i) {
            an(e, i, function(r) {
                r = ht(r), e.touching || n[i].call(t, r);
            });
        }));
    }
    function on(t, e) {
        function n(n) {
            an(e, n, function(i) {
                i = ht(i), en(t, i.target) || (i = function(t, e) {
                    return ut(t.dom, new nn(t, e), !0);
                }(t, i), e.domHandlers[n].call(t, i));
            }, {
                capture: !0
            });
        }
        Mh.pointerEventsSupported ? f(wc.pointer, n) : Mh.touchEventsSupported || f(wc.mouse, n);
    }
    function an(t, e, n, i) {
        t.mounted[e] = n, t.listenerOpts[e] = i, function(t, e, n, i) {
            Kh ? t.addEventListener(e, n, i) : t.attachEvent("on" + e, n);
        }(t.domTarget, Qe(e), n, i);
    }
    function sn(t) {
        var e = t.mounted;
        for (var n in e) e.hasOwnProperty(n) && ct(t.domTarget, Qe(n), e[n], t.listenerOpts[n]);
        t.mounted = {};
    }
    function ln(t, e) {
        if (t._mayPointerCapture = null, _c && t._pointerCapturing ^ e) {
            t._pointerCapturing = e;
            var n = t._globalHandlerScope;
            e ? on(t, n) : sn(n);
        }
    }
    function hn(t, e) {
        this.domTarget = t, this.domHandlers = e, this.mounted = {}, this.listenerOpts = {}, 
        this.touchTimer = null, this.touching = !1;
    }
    function un(t, e) {
        Yh.call(this), this.dom = t, this.painterRoot = e, this._localHandlerScope = new hn(t, Sc), 
        _c && (this._globalHandlerScope = new hn(document, Mc)), this._pointerCapturing = !1, 
        this._mayPointerCapture = null, rn(this, this._localHandlerScope);
    }
    function cn(t, e) {
        var n = new kc(Sh(), t, e);
        return Ac[n.id] = n, n;
    }
    function dn(t) {
        return t instanceof Array ? t : null == t ? [] : [ t ];
    }
    function fn(t, e, n) {
        if (t) {
            t[e] = t[e] || {}, t.emphasis = t.emphasis || {}, t.emphasis[e] = t.emphasis[e] || {};
            for (var i = 0, r = n.length; r > i; i++) {
                var o = n[i];
                !t.emphasis[e].hasOwnProperty(o) && t[e].hasOwnProperty(o) && (t.emphasis[e][o] = t[e][o]);
            }
        }
    }
    function pn(t) {
        return !Oc(t) || Ec(t) || t instanceof Date ? t : t.value;
    }
    function gn(t, e) {
        e = (e || []).slice();
        var n = p(t || [], function(t) {
            return {
                exist: t
            };
        });
        return Lc(e, function(t, i) {
            if (Oc(t)) {
                for (var r = 0; r < n.length; r++) if (!n[r].option && null != t.id && n[r].exist.id === t.id + "") return n[r].option = t, 
                void (e[i] = null);
                for (r = 0; r < n.length; r++) {
                    var o = n[r].exist;
                    if (!(n[r].option || null != o.id && null != t.id || null == t.name || mn(t) || mn(o) || o.name !== t.name + "")) return n[r].option = t, 
                    void (e[i] = null);
                }
            }
        }), Lc(e, function(t) {
            if (Oc(t)) {
                for (var e = 0; e < n.length; e++) {
                    var i = n[e].exist;
                    if (!n[e].option && !mn(i) && null == t.id) {
                        n[e].option = t;
                        break;
                    }
                }
                e >= n.length && n.push({
                    option: t
                });
            }
        }), n;
    }
    function vn(t) {
        var e = t.name;
        return !(!e || !e.indexOf(Bc));
    }
    function mn(t) {
        return Oc(t) && t.id && 0 === (t.id + "").indexOf("\0_ec_\0");
    }
    function yn(t, e) {
        return null != e.dataIndexInside ? e.dataIndexInside : null != e.dataIndex ? _(e.dataIndex) ? p(e.dataIndex, function(e) {
            return t.indexOfRawIndex(e);
        }) : t.indexOfRawIndex(e.dataIndex) : null != e.name ? _(e.name) ? p(e.name, function(e) {
            return t.indexOfName(e);
        }) : t.indexOfName(e.name) : void 0;
    }
    function _n() {
        var t = "__\0ec_inner_" + Nc++ + "_" + Math.random().toFixed(5);
        return function(e) {
            return e[t] || (e[t] = {});
        };
    }
    function xn(t, e, n) {
        if (w(e)) {
            var i = {};
            i[e + "Index"] = 0, e = i;
        }
        var r = n && n.defaultMainType;
        !r || wn(e, r + "Index") || wn(e, r + "Id") || wn(e, r + "Name") || (e[r + "Index"] = 0);
        var o = {};
        return Lc(e, function(i, r) {
            i = e[r];
            if ("dataIndex" !== r && "dataIndexInside" !== r) {
                var a = r.match(/^(\w+)(Index|Id|Name)$/) || [], s = a[1], l = (a[2] || "").toLowerCase();
                if (!(!s || !l || null == i || "index" === l && "none" === i || n && n.includeMainTypes && h(n.includeMainTypes, s) < 0)) {
                    var u = {
                        mainType: s
                    };
                    ("index" !== l || "all" !== i) && (u[l] = i);
                    var c = t.queryComponents(u);
                    o[s + "Models"] = c, o[s + "Model"] = c[0];
                }
            } else o[r] = i;
        }), o;
    }
    function wn(t, e) {
        return t && t.hasOwnProperty(e);
    }
    function bn(t, e, n) {
        t.setAttribute ? t.setAttribute(e, n) : t[e] = n;
    }
    function Sn(t) {
        return "auto" === t ? Mh.domSupported ? "html" : "richText" : t || "html";
    }
    function Mn(t) {
        var e = {
            main: "",
            sub: ""
        };
        return t && (t = t.split(Rc), e.main = t[0] || "", e.sub = t[1] || ""), e;
    }
    function In(t, e) {
        t.$constructor = t, t.extend = function(t) {
            wh && f(e, function(e) {
                t[e] || console.warn("Method `" + e + "` should be implemented" + (t.type ? " in " + t.type : "") + ".");
            });
            var n = this, i = function() {
                t.$constructor ? t.$constructor.apply(this, arguments) : n.apply(this, arguments);
            };
            return a(i.prototype, t), i.extend = this.extend, i.superCall = Cn, i.superApply = An, 
            u(i, this), i.superClass = n, i;
        };
    }
    function Tn(t) {
        var e = [ "__\0is_clz", Vc++, Math.random().toFixed(3) ].join("_");
        t.prototype[e] = !0, wh && L(!t.isInstance, 'The method "is" can not be defined.'), 
        t.isInstance = function(t) {
            return !(!t || !t[e]);
        };
    }
    function Cn(t, e) {
        var n = k(arguments, 2);
        return this.superClass.prototype[e].apply(t, n);
    }
    function An(t, e, n) {
        return this.superClass.prototype[e].apply(t, n);
    }
    function Dn(t, e) {
        e = e || {};
        var n = {};
        if (t.registerClass = function(t, e) {
            if (e) if (function(t) {
                L(/^[a-zA-Z0-9_]+([.][a-zA-Z0-9_]+)?$/.test(t), 'componentType "' + t + '" illegal');
            }(e), (e = Mn(e)).sub) {
                if (e.sub !== Fc) ((function(t) {
                    var e = n[t.main];
                    return e && e[Fc] || ((e = n[t.main] = {})[Fc] = !0), e;
                })(e))[e.sub] = t;
            } else wh && n[e.main] && console.warn(e.main + " exists."), n[e.main] = t;
            return t;
        }, t.getClass = function(t, e, i) {
            var r = n[t];
            if (r && r[Fc] && (r = e ? r[e] : null), i && !r) throw new Error(e ? "Component " + t + "." + (e || "") + " not exists. Load it first." : t + ".type should be specified.");
            return r;
        }, t.getClassesByMainType = function(t) {
            t = Mn(t);
            var e = [], i = n[t.main];
            return i && i[Fc] ? f(i, function(t, n) {
                n !== Fc && e.push(t);
            }) : e.push(i), e;
        }, t.hasClass = function(t) {
            return t = Mn(t), !!n[t.main];
        }, t.getAllClassMainTypes = function() {
            var t = [];
            return f(n, function(e, n) {
                t.push(n);
            }), t;
        }, t.hasSubTypes = function(t) {
            t = Mn(t);
            var e = n[t.main];
            return e && e[Fc];
        }, t.parseClassType = Mn, e.registerWhenExtend) {
            var i = t.extend;
            i && (t.extend = function(e) {
                var n = i.call(this, e);
                return t.registerClass(n, e.type);
            });
        }
        return t;
    }
    function kn(t) {
        return t > -jc && jc > t;
    }
    function Pn(t) {
        return t > jc || -jc > t;
    }
    function Ln(t, e, n, i, r) {
        var o = 1 - r;
        return o * o * (o * t + 3 * r * e) + r * r * (r * i + 3 * o * n);
    }
    function On(t, e, n, i, r) {
        var o = 1 - r;
        return 3 * (((e - t) * o + 2 * (n - e) * r) * o + (i - n) * r * r);
    }
    function En(t, e, n, i, r) {
        var o = 6 * n - 12 * e + 6 * t, a = 9 * e + 3 * i - 3 * t - 9 * n, s = 3 * e - 3 * t, l = 0;
        if (kn(a)) {
            if (Pn(o)) (u = -s / o) >= 0 && 1 >= u && (r[l++] = u);
        } else {
            var h = o * o - 4 * a * s;
            if (kn(h)) r[0] = -o / (2 * a); else if (h > 0) {
                var u, c = qc(h), d = (-o - c) / (2 * a);
                (u = (-o + c) / (2 * a)) >= 0 && 1 >= u && (r[l++] = u), d >= 0 && 1 >= d && (r[l++] = d);
            }
        }
        return l;
    }
    function Bn(t, e, n, i, r, o) {
        var a = (e - t) * r + t, s = (n - e) * r + e, l = (i - n) * r + n, h = (s - a) * r + a, u = (l - s) * r + s, c = (u - h) * r + h;
        o[0] = t, o[1] = a, o[2] = h, o[3] = c, o[4] = c, o[5] = u, o[6] = l, o[7] = i;
    }
    function zn(t, e, n, i) {
        var r = 1 - i;
        return r * (r * t + 2 * i * e) + i * i * n;
    }
    function Nn(t, e, n, i) {
        return 2 * ((1 - i) * (e - t) + i * (n - e));
    }
    function Rn(t, e, n) {
        var i = t + n - 2 * e;
        return 0 === i ? .5 : (t - e) / i;
    }
    function Fn(t, e, n, i, r) {
        var o = (e - t) * i + t, a = (n - e) * i + e, s = (a - o) * i + o;
        r[0] = t, r[1] = o, r[2] = s, r[3] = s, r[4] = a, r[5] = n;
    }
    function Vn(t, e, n) {
        if (0 !== t.length) {
            var i, r = t[0], o = r[0], a = r[0], s = r[1], l = r[1];
            for (i = 1; i < t.length; i++) r = t[i], o = ed(o, r[0]), a = nd(a, r[0]), s = ed(s, r[1]), 
            l = nd(l, r[1]);
            e[0] = o, e[1] = s, n[0] = a, n[1] = l;
        }
    }
    function Hn(t, e, n, i, r, o) {
        r[0] = ed(t, n), r[1] = ed(e, i), o[0] = nd(t, n), o[1] = nd(e, i);
    }
    function Gn(t, e, n, i, r, o, a, s, l, h) {
        var u, c = En, d = Ln, f = c(t, n, r, a, hd);
        for (l[0] = 1 / 0, l[1] = 1 / 0, h[0] = -1 / 0, h[1] = -1 / 0, u = 0; f > u; u++) {
            var p = d(t, n, r, a, hd[u]);
            l[0] = ed(p, l[0]), h[0] = nd(p, h[0]);
        }
        for (f = c(e, i, o, s, ud), u = 0; f > u; u++) {
            var g = d(e, i, o, s, ud[u]);
            l[1] = ed(g, l[1]), h[1] = nd(g, h[1]);
        }
        l[0] = ed(t, l[0]), h[0] = nd(t, h[0]), l[0] = ed(a, l[0]), h[0] = nd(a, h[0]), 
        l[1] = ed(e, l[1]), h[1] = nd(e, h[1]), l[1] = ed(s, l[1]), h[1] = nd(s, h[1]);
    }
    function Wn(t, e, n, i, r, o, a, s) {
        var l = Rn, h = zn, u = nd(ed(l(t, n, r), 1), 0), c = nd(ed(l(e, i, o), 1), 0), d = h(t, n, r, u), f = h(e, i, o, c);
        a[0] = ed(t, r, d), a[1] = ed(e, o, f), s[0] = nd(t, r, d), s[1] = nd(e, o, f);
    }
    function Xn(t, e, n, i, r, o, a, s, l) {
        var h = Q, u = J, c = Math.abs(r - o);
        if (1e-4 > c % od && c > 1e-4) return s[0] = t - n, s[1] = e - i, l[0] = t + n, 
        void (l[1] = e + i);
        if (ad[0] = rd(r) * n + t, ad[1] = id(r) * i + e, sd[0] = rd(o) * n + t, sd[1] = id(o) * i + e, 
        h(s, ad, sd), u(l, ad, sd), 0 > (r %= od) && (r += od), 0 > (o %= od) && (o += od), 
        r > o && !a ? o += od : o > r && a && (r += od), a) {
            var d = o;
            o = r, r = d;
        }
        for (var f = 0; o > f; f += Math.PI / 2) f > r && (ld[0] = rd(f) * n + t, ld[1] = id(f) * i + e, 
        h(s, ld, s), u(l, ld, l));
    }
    function Un(t, e, n, i, r, o, a) {
        if (0 === r) return !1;
        var s, l = r;
        if (a > e + l && a > i + l || e - l > a && i - l > a || o > t + l && o > n + l || t - l > o && n - l > o) return !1;
        if (t === n) return Math.abs(o - t) <= l / 2;
        var h = (s = (e - i) / (t - n)) * o - a + (t * i - n * e) / (t - n);
        return l / 2 * l / 2 >= h * h / (s * s + 1);
    }
    function Yn(t, e, n, i, r, o, a, s, l, h, u) {
        if (0 === l) return !1;
        var c = l;
        if (u > e + c && u > i + c && u > o + c && u > s + c || e - c > u && i - c > u && o - c > u && s - c > u || h > t + c && h > n + c && h > r + c && h > a + c || t - c > h && n - c > h && r - c > h && a - c > h) return !1;
        var d = function(t, e, n, i, r, o, a, s, l, h, u) {
            var c, d, f, p, g, v = .005, m = 1 / 0;
            Qc[0] = l, Qc[1] = h;
            for (var y = 0; 1 > y; y += .05) Jc[0] = Ln(t, n, r, a, y), Jc[1] = Ln(e, i, o, s, y), 
            m > (p = Wh(Qc, Jc)) && (c = y, m = p);
            m = 1 / 0;
            for (var _ = 0; 32 > _ && !(Zc > v); _++) d = c - v, f = c + v, Jc[0] = Ln(t, n, r, a, d), 
            Jc[1] = Ln(e, i, o, s, d), p = Wh(Jc, Qc), d >= 0 && m > p ? (c = d, m = p) : (td[0] = Ln(t, n, r, a, f), 
            td[1] = Ln(e, i, o, s, f), g = Wh(td, Qc), 1 >= f && m > g ? (c = f, m = g) : v *= .5);
            return u && (u[0] = Ln(t, n, r, a, c), u[1] = Ln(e, i, o, s, c)), qc(m);
        }(t, e, n, i, r, o, a, s, h, u, null);
        return c / 2 >= d;
    }
    function qn(t, e, n, i, r, o, a, s, l) {
        if (0 === a) return !1;
        var h = a;
        if (l > e + h && l > i + h && l > o + h || e - h > l && i - h > l && o - h > l || s > t + h && s > n + h && s > r + h || t - h > s && n - h > s && r - h > s) return !1;
        var u = function(t, e, n, i, r, o, a, s, l) {
            var h, u = .005, c = 1 / 0;
            Qc[0] = a, Qc[1] = s;
            for (var d = 0; 1 > d; d += .05) {
                Jc[0] = zn(t, n, r, d), Jc[1] = zn(e, i, o, d), c > (v = Wh(Qc, Jc)) && (h = d, 
                c = v);
            }
            c = 1 / 0;
            for (var f = 0; 32 > f && !(Zc > u); f++) {
                var p = h - u, g = h + u;
                Jc[0] = zn(t, n, r, p), Jc[1] = zn(e, i, o, p);
                var v = Wh(Jc, Qc);
                if (p >= 0 && c > v) h = p, c = v; else {
                    td[0] = zn(t, n, r, g), td[1] = zn(e, i, o, g);
                    var m = Wh(td, Qc);
                    1 >= g && c > m ? (h = g, c = m) : u *= .5;
                }
            }
            return l && (l[0] = zn(t, n, r, h), l[1] = zn(e, i, o, h)), qc(c);
        }(t, e, n, i, r, o, s, l, null);
        return h / 2 >= u;
    }
    function jn(t) {
        return 0 > (t %= Md) && (t += Md), t;
    }
    function Zn(t, e, n, i, r, o, a, s, l) {
        if (0 === a) return !1;
        var h = a;
        s -= t, l -= e;
        var u = Math.sqrt(s * s + l * l);
        if (u - h > n || n > u + h) return !1;
        if (Math.abs(i - r) % Id < 1e-4) return !0;
        if (o) {
            var c = i;
            i = jn(r), r = jn(c);
        } else i = jn(i), r = jn(r);
        i > r && (r += Id);
        var d = Math.atan2(l, s);
        return 0 > d && (d += Id), d >= i && r >= d || d + Id >= i && r >= d + Id;
    }
    function Kn(t, e, n, i, r, o) {
        if (o > e && o > i || e > o && i > o) return 0;
        if (i === e) return 0;
        var a = e > i ? 1 : -1, s = (o - e) / (i - e);
        (1 === s || 0 === s) && (a = e > i ? .5 : -.5);
        var l = s * (n - t) + t;
        return l === r ? 1 / 0 : l > r ? a : 0;
    }
    function $n() {
        var t = kd[0];
        kd[0] = kd[1], kd[1] = t;
    }
    function Qn(t, e, n, i, r, o, a, s, l, h) {
        if (h > e && h > i && h > o && h > s || e > h && i > h && o > h && s > h) return 0;
        var u = function(t, e, n, i, r, o) {
            var a = i + 3 * (e - n) - t, s = 3 * (n - 2 * e + t), l = 3 * (e - t), h = t - r, u = s * s - 3 * a * l, c = s * l - 9 * a * h, d = l * l - 3 * s * h, f = 0;
            if (kn(u) && kn(c)) {
                if (kn(s)) o[0] = 0; else (M = -l / s) >= 0 && 1 >= M && (o[f++] = M);
            } else {
                var p = c * c - 4 * u * d;
                if (kn(p)) {
                    var g = c / u, v = -g / 2;
                    (M = -s / a + g) >= 0 && 1 >= M && (o[f++] = M), v >= 0 && 1 >= v && (o[f++] = v);
                } else if (p > 0) {
                    var m = qc(p), y = u * s + 1.5 * a * (-c + m), _ = u * s + 1.5 * a * (-c - m);
                    (M = (-s - ((y = 0 > y ? -Yc(-y, $c) : Yc(y, $c)) + (_ = 0 > _ ? -Yc(-_, $c) : Yc(_, $c)))) / (3 * a)) >= 0 && 1 >= M && (o[f++] = M);
                } else {
                    var x = (2 * u * s - 3 * a * c) / (2 * qc(u * u * u)), w = Math.acos(x) / 3, b = qc(u), S = Math.cos(w), M = (-s - 2 * b * S) / (3 * a), I = (v = (-s + b * (S + Kc * Math.sin(w))) / (3 * a), 
                    (-s + b * (S - Kc * Math.sin(w))) / (3 * a));
                    M >= 0 && 1 >= M && (o[f++] = M), v >= 0 && 1 >= v && (o[f++] = v), I >= 0 && 1 >= I && (o[f++] = I);
                }
            }
            return f;
        }(e, i, o, s, h, Dd);
        if (0 === u) return 0;
        for (var c, d, f = 0, p = -1, g = 0; u > g; g++) {
            var v = Dd[g], m = 0 === v || 1 === v ? .5 : 1;
            l > Ln(t, n, r, a, v) || (0 > p && (p = En(e, i, o, s, kd), kd[1] < kd[0] && p > 1 && $n(), 
            c = Ln(e, i, o, s, kd[0]), p > 1 && (d = Ln(e, i, o, s, kd[1]))), f += 2 === p ? v < kd[0] ? e > c ? m : -m : v < kd[1] ? c > d ? m : -m : d > s ? m : -m : v < kd[0] ? e > c ? m : -m : c > s ? m : -m);
        }
        return f;
    }
    function Jn(t, e, n, i, r, o, a, s) {
        if (s > e && s > i && s > o || e > s && i > s && o > s) return 0;
        var l = function(t, e, n, i, r) {
            var o = t - 2 * e + n, a = 2 * (e - t), s = t - i, l = 0;
            if (kn(o)) {
                if (Pn(a)) (u = -s / a) >= 0 && 1 >= u && (r[l++] = u);
            } else {
                var h = a * a - 4 * o * s;
                if (kn(h)) (u = -a / (2 * o)) >= 0 && 1 >= u && (r[l++] = u); else if (h > 0) {
                    var u, c = qc(h), d = (-a - c) / (2 * o);
                    (u = (-a + c) / (2 * o)) >= 0 && 1 >= u && (r[l++] = u), d >= 0 && 1 >= d && (r[l++] = d);
                }
            }
            return l;
        }(e, i, o, s, Dd);
        if (0 === l) return 0;
        var h = Rn(e, i, o);
        if (h >= 0 && 1 >= h) {
            for (var u = 0, c = zn(e, i, o, h), d = 0; l > d; d++) {
                var f = 0 === Dd[d] || 1 === Dd[d] ? .5 : 1;
                a > zn(t, n, r, Dd[d]) || (u += Dd[d] < h ? e > c ? f : -f : c > o ? f : -f);
            }
            return u;
        }
        f = 0 === Dd[0] || 1 === Dd[0] ? .5 : 1;
        return a > zn(t, n, r, Dd[0]) ? 0 : e > o ? f : -f;
    }
    function ti(t, e, n, i, r, o, a, s) {
        if ((s -= e) > n || -n > s) return 0;
        var l = Math.sqrt(n * n - s * s);
        Dd[0] = -l, Dd[1] = l;
        var h = Math.abs(i - r);
        if (1e-4 > h) return 0;
        if (1e-4 > h % Cd) {
            i = 0, r = Cd;
            var u = o ? 1 : -1;
            return a >= Dd[0] + t && a <= Dd[1] + t ? u : 0;
        }
        if (o) {
            l = i;
            i = jn(r), r = jn(l);
        } else i = jn(i), r = jn(r);
        i > r && (r += Cd);
        for (var c = 0, d = 0; 2 > d; d++) {
            var f = Dd[d];
            if (f + t > a) {
                var p = Math.atan2(s, f);
                u = o ? 1 : -1;
                0 > p && (p = Cd + p), (p >= i && r >= p || p + Cd >= i && r >= p + Cd) && (p > Math.PI / 2 && p < 1.5 * Math.PI && (u = -u), 
                c += u);
            }
        }
        return c;
    }
    function ei(t, e, n, i, r) {
        for (var o = 0, a = 0, s = 0, l = 0, h = 0, u = 0; u < t.length; ) {
            var c = t[u++];
            switch (c === Td.M && u > 1 && (n || (o += Kn(a, s, l, h, i, r))), 1 === u && (l = a = t[u], 
            h = s = t[u + 1]), c) {
              case Td.M:
                a = l = t[u++], s = h = t[u++];
                break;

              case Td.L:
                if (n) {
                    if (Un(a, s, t[u], t[u + 1], e, i, r)) return !0;
                } else o += Kn(a, s, t[u], t[u + 1], i, r) || 0;
                a = t[u++], s = t[u++];
                break;

              case Td.C:
                if (n) {
                    if (Yn(a, s, t[u++], t[u++], t[u++], t[u++], t[u], t[u + 1], e, i, r)) return !0;
                } else o += Qn(a, s, t[u++], t[u++], t[u++], t[u++], t[u], t[u + 1], i, r) || 0;
                a = t[u++], s = t[u++];
                break;

              case Td.Q:
                if (n) {
                    if (qn(a, s, t[u++], t[u++], t[u], t[u + 1], e, i, r)) return !0;
                } else o += Jn(a, s, t[u++], t[u++], t[u], t[u + 1], i, r) || 0;
                a = t[u++], s = t[u++];
                break;

              case Td.A:
                var d = t[u++], f = t[u++], p = t[u++], g = t[u++], v = t[u++], m = t[u++];
                u += 1;
                var y = 1 - t[u++], _ = Math.cos(v) * p + d, x = Math.sin(v) * g + f;
                u > 1 ? o += Kn(a, s, _, x, i, r) : (l = _, h = x);
                var w = (i - d) * g / p + d;
                if (n) {
                    if (Zn(d, f, g, v, v + m, y, e, w, r)) return !0;
                } else o += ti(d, f, g, v, v + m, y, w, r);
                a = Math.cos(v + m) * p + d, s = Math.sin(v + m) * g + f;
                break;

              case Td.R:
                l = a = t[u++], h = s = t[u++];
                _ = l + t[u++], x = h + t[u++];
                if (n) {
                    if (Un(l, h, _, h, e, i, r) || Un(_, h, _, x, e, i, r) || Un(_, x, l, x, e, i, r) || Un(l, x, l, h, e, i, r)) return !0;
                } else o += Kn(_, h, _, x, i, r), o += Kn(l, x, l, h, i, r);
                break;

              case Td.Z:
                if (n) {
                    if (Un(a, s, l, h, e, i, r)) return !0;
                } else o += Kn(a, s, l, h, i, r);
                a = l, s = h;
            }
        }
        return n || function(t, e) {
            return Math.abs(t - e) < Ad;
        }(s, h) || (o += Kn(a, s, l, h, i, r) || 0), 0 !== o;
    }
    function ni(t) {
        Ze.call(this, t), this.path = null;
    }
    function ii(t, e, n, i, r, o, a, s, l, h, u) {
        var c = l * (Gd / 180), d = Hd(c) * (t - n) / 2 + Vd(c) * (e - i) / 2, f = -1 * Vd(c) * (t - n) / 2 + Hd(c) * (e - i) / 2, p = d * d / (a * a) + f * f / (s * s);
        p > 1 && (a *= Fd(p), s *= Fd(p));
        var g = (r === o ? -1 : 1) * Fd((a * a * s * s - a * a * f * f - s * s * d * d) / (a * a * f * f + s * s * d * d)) || 0, v = g * a * f / s, m = g * -s * d / a, y = (t + n) / 2 + Hd(c) * v - Vd(c) * m, _ = (e + i) / 2 + Vd(c) * v + Hd(c) * m, x = Ud([ 1, 0 ], [ (d - v) / a, (f - m) / s ]), w = [ (d - v) / a, (f - m) / s ], b = [ (-1 * d - v) / a, (-1 * f - m) / s ], S = Ud(w, b);
        Xd(w, b) <= -1 && (S = Gd), Xd(w, b) >= 1 && (S = 0), 0 === o && S > 0 && (S -= 2 * Gd), 
        1 === o && 0 > S && (S += 2 * Gd), u.addData(h, y, _, a, s, x, S, c, o);
    }
    function ri(t, e) {
        var n = function(t) {
            if (!t) return new Sd();
            for (var e, n = 0, i = 0, r = n, o = i, a = new Sd(), s = Sd.CMD, l = t.match(Yd), h = 0; h < l.length; h++) {
                for (var u, c = l[h], d = c.charAt(0), f = c.match(qd) || [], p = f.length, g = 0; p > g; g++) f[g] = parseFloat(f[g]);
                for (var v = 0; p > v; ) {
                    var m, y, _, x, w, b, S, M = n, I = i;
                    switch (d) {
                      case "l":
                        n += f[v++], i += f[v++], u = s.L, a.addData(u, n, i);
                        break;

                      case "L":
                        n = f[v++], i = f[v++], u = s.L, a.addData(u, n, i);
                        break;

                      case "m":
                        n += f[v++], i += f[v++], u = s.M, a.addData(u, n, i), r = n, o = i, d = "l";
                        break;

                      case "M":
                        n = f[v++], i = f[v++], u = s.M, a.addData(u, n, i), r = n, o = i, d = "L";
                        break;

                      case "h":
                        n += f[v++], u = s.L, a.addData(u, n, i);
                        break;

                      case "H":
                        n = f[v++], u = s.L, a.addData(u, n, i);
                        break;

                      case "v":
                        i += f[v++], u = s.L, a.addData(u, n, i);
                        break;

                      case "V":
                        i = f[v++], u = s.L, a.addData(u, n, i);
                        break;

                      case "C":
                        u = s.C, a.addData(u, f[v++], f[v++], f[v++], f[v++], f[v++], f[v++]), n = f[v - 2], 
                        i = f[v - 1];
                        break;

                      case "c":
                        u = s.C, a.addData(u, f[v++] + n, f[v++] + i, f[v++] + n, f[v++] + i, f[v++] + n, f[v++] + i), 
                        n += f[v - 2], i += f[v - 1];
                        break;

                      case "S":
                        m = n, y = i;
                        var T = a.len(), C = a.data;
                        e === s.C && (m += n - C[T - 4], y += i - C[T - 3]), u = s.C, M = f[v++], I = f[v++], 
                        n = f[v++], i = f[v++], a.addData(u, m, y, M, I, n, i);
                        break;

                      case "s":
                        m = n, y = i;
                        T = a.len(), C = a.data;
                        e === s.C && (m += n - C[T - 4], y += i - C[T - 3]), u = s.C, M = n + f[v++], I = i + f[v++], 
                        n += f[v++], i += f[v++], a.addData(u, m, y, M, I, n, i);
                        break;

                      case "Q":
                        M = f[v++], I = f[v++], n = f[v++], i = f[v++], u = s.Q, a.addData(u, M, I, n, i);
                        break;

                      case "q":
                        M = f[v++] + n, I = f[v++] + i, n += f[v++], i += f[v++], u = s.Q, a.addData(u, M, I, n, i);
                        break;

                      case "T":
                        m = n, y = i;
                        T = a.len(), C = a.data;
                        e === s.Q && (m += n - C[T - 4], y += i - C[T - 3]), n = f[v++], i = f[v++], u = s.Q, 
                        a.addData(u, m, y, n, i);
                        break;

                      case "t":
                        m = n, y = i;
                        T = a.len(), C = a.data;
                        e === s.Q && (m += n - C[T - 4], y += i - C[T - 3]), n += f[v++], i += f[v++], u = s.Q, 
                        a.addData(u, m, y, n, i);
                        break;

                      case "A":
                        _ = f[v++], x = f[v++], w = f[v++], b = f[v++], S = f[v++], ii(M = n, I = i, n = f[v++], i = f[v++], b, S, _, x, w, u = s.A, a);
                        break;

                      case "a":
                        _ = f[v++], x = f[v++], w = f[v++], b = f[v++], S = f[v++], ii(M = n, I = i, n += f[v++], i += f[v++], b, S, _, x, w, u = s.A, a);
                    }
                }
                ("z" === d || "Z" === d) && (u = s.Z, a.addData(u), n = r, i = o), e = u;
            }
            return a.toStatic(), a;
        }(t);
        return (e = e || {}).buildPath = function(t) {
            if (t.setData) {
                t.setData(n.data), (e = t.getContext()) && t.rebuildPath(e);
            } else {
                var e = t;
                n.rebuildPath(e);
            }
        }, e.applyTransform = function(t) {
            Rd(n, t), this.dirty(!0);
        }, e;
    }
    function oi(t, e) {
        return new ni(ri(t, e));
    }
    function ai(t, e, n, i, r, o, a) {
        var s = .5 * (n - t), l = .5 * (i - e);
        return (2 * (e - n) + s + l) * a + (-3 * (e - n) - 2 * s - l) * o + s * r + e;
    }
    function si(t, e, n) {
        var i = e.points, r = e.smooth;
        if (i && i.length >= 2) {
            if (r && "spline" !== r) {
                var o = ef(i, r, n, e.smoothConstraint);
                t.moveTo(i[0][0], i[0][1]);
                for (var a = i.length, s = 0; (n ? a : a - 1) > s; s++) {
                    var l = o[2 * s], h = o[2 * s + 1], u = i[(s + 1) % a];
                    t.bezierCurveTo(l[0], l[1], h[0], h[1], u[0], u[1]);
                }
            } else {
                "spline" === r && (i = tf(i, n)), t.moveTo(i[0][0], i[0][1]);
                s = 1;
                for (var c = i.length; c > s; s++) t.lineTo(i[s][0], i[s][1]);
            }
            n && t.closePath();
        }
    }
    function li(t, e, n) {
        if (e) {
            var i = e.x1, r = e.x2, o = e.y1, a = e.y2;
            t.x1 = i, t.x2 = r, t.y1 = o, t.y2 = a;
            var s = n && n.lineWidth;
            s && (of(2 * i) === of(2 * r) && (t.x1 = t.x2 = ui(i, s, !0)), of(2 * o) === of(2 * a) && (t.y1 = t.y2 = ui(o, s, !0)));
        }
    }
    function hi(t, e, n) {
        if (e) {
            var i = e.x, r = e.y, o = e.width, a = e.height;
            t.x = i, t.y = r, t.width = o, t.height = a;
            var s = n && n.lineWidth;
            s && (t.x = ui(i, s, !0), t.y = ui(r, s, !0), t.width = Math.max(ui(i + o, s, !1) - t.x, 0 === o ? 0 : 1), 
            t.height = Math.max(ui(r + a, s, !1) - t.y, 0 === a ? 0 : 1));
        }
    }
    function ui(t, e, n) {
        if (!e) return t;
        var i = of(2 * t);
        return (i + of(e)) % 2 == 0 ? i / 2 : (i + (n ? 1 : -1)) / 2;
    }
    function ci(t, e, n) {
        var i = t.cpx2, r = t.cpy2;
        return null === i || null === r ? [ (n ? On : Ln)(t.x1, t.cpx1, t.cpx2, t.x2, e), (n ? On : Ln)(t.y1, t.cpy1, t.cpy2, t.y2, e) ] : [ (n ? Nn : zn)(t.x1, t.cpx1, t.x2, e), (n ? Nn : zn)(t.y1, t.cpy1, t.y2, e) ];
    }
    function di(t) {
        Ze.call(this, t), this._displayables = [], this._temporaryDisplayables = [], this._cursor = 0, 
        this.notClear = !0;
    }
    function fi(t) {
        return ni.extend(t);
    }
    function pi(t, e) {
        Tf[t] = e;
    }
    function gi(t, e, n, i) {
        var r = oi(t, e);
        return n && ("center" === i && (n = mi(n, r.getBoundingRect())), yi(r, n)), r;
    }
    function vi(t, e, n) {
        var i = new Ke({
            style: {
                image: t,
                x: e.x,
                y: e.y,
                width: e.width,
                height: e.height
            },
            onload: function(t) {
                if ("center" === n) {
                    var r = {
                        width: t.width,
                        height: t.height
                    };
                    i.setStyle(mi(e, r));
                }
            }
        });
        return i;
    }
    function mi(t, e) {
        var n, i = e.width / e.height, r = t.height * i;
        return r <= t.width ? n = t.height : n = (r = t.width) / i, {
            x: t.x + t.width / 2 - r / 2,
            y: t.y + t.height / 2 - n / 2,
            width: r,
            height: n
        };
    }
    function yi(t, e) {
        if (t.applyTransform) {
            var n = t.getBoundingRect().calculateTransform(e);
            t.applyTransform(n);
        }
    }
    function _i(t) {
        return null != t && "none" !== t;
    }
    function xi(t) {
        var e = t.__hoverStl;
        if (e && !t.__highlighted) {
            var n = t.__zr, i = t.useHoverLayer && n && "canvas" === n.painter.type;
            if (t.__highlighted = i ? "layer" : "plain", !(t.isGroup || !n && t.useHoverLayer)) {
                var r = t, o = t.style;
                i && (o = (r = n.addHover(t)).style), Vi(o), i || function(t) {
                    if (t.__hoverStlDirty) {
                        t.__hoverStlDirty = !1;
                        var e = t.__hoverStl;
                        if (!e) return void (t.__cachedNormalStl = t.__cachedNormalZ2 = null);
                        var n = t.__cachedNormalStl = {};
                        t.__cachedNormalZ2 = t.z2;
                        var i = t.style;
                        for (var r in e) null != e[r] && (n[r] = i[r]);
                        n.fill = i.fill, n.stroke = i.stroke;
                    }
                }(r), o.extendFrom(e), wi(o, e, "fill"), wi(o, e, "stroke"), Fi(o), i || (t.dirty(!1), 
                t.z2 += wf);
            }
        }
    }
    function wi(t, e, n) {
        !_i(e[n]) && _i(t[n]) && (t[n] = function(t) {
            if ("string" != typeof t) return t;
            var e = Df.get(t);
            return e || (e = Rt(t, -.1), 1e4 > kf && (Df.set(t, e), kf++)), e;
        }(t[n]));
    }
    function bi(t) {
        var e = t.__highlighted;
        if (e && (t.__highlighted = !1, !t.isGroup)) if ("layer" === e) t.__zr && t.__zr.removeHover(t); else {
            var n = t.style, i = t.__cachedNormalStl;
            i && (Vi(n), t.setStyle(i), Fi(n));
            var r = t.__cachedNormalZ2;
            null != r && t.z2 - r === wf && (t.z2 = r);
        }
    }
    function Si(t, e, n) {
        var i, r = Sf, o = Sf;
        t.__highlighted && (r = bf, i = !0), e(t, n), t.__highlighted && (o = bf, i = !0), 
        t.isGroup && t.traverse(function(t) {
            !t.isGroup && e(t, n);
        }), i && t.__highDownOnUpdate && t.__highDownOnUpdate(r, o);
    }
    function Mi(t, e) {
        e = t.__hoverStl = !1 !== e && (t.hoverStyle || e || {}), t.__hoverStlDirty = !0, 
        t.__highlighted && (t.__cachedNormalStl = null, bi(t), xi(t));
    }
    function Ii(t) {
        !Di(this, t) && !this.__highByOuter && Si(this, xi);
    }
    function Ti(t) {
        !Di(this, t) && !this.__highByOuter && Si(this, bi);
    }
    function Ci(t) {
        this.__highByOuter |= 1 << (t || 0), Si(this, xi);
    }
    function Ai(t) {
        !(this.__highByOuter &= ~(1 << (t || 0))) && Si(this, bi);
    }
    function Di(t, e) {
        return t.__highDownSilentOnTouch && e.zrByTouch;
    }
    function ki(t, e) {
        Pi(t, !0), Si(t, Mi, e);
    }
    function Pi(t, e) {
        var n = !1 === e;
        if (t.__highDownSilentOnTouch = t.highDownSilentOnTouch, t.__highDownOnUpdate = t.highDownOnUpdate, 
        !n || t.__highDownDispatcher) {
            var i = n ? "off" : "on";
            t[i]("mouseover", Ii)[i]("mouseout", Ti), t[i]("emphasis", Ci)[i]("normal", Ai), 
            t.__highByOuter = t.__highByOuter || 0, t.__highDownDispatcher = !n;
        }
    }
    function Li(t) {
        return !(!t || !t.__highDownDispatcher);
    }
    function Oi(t) {
        var e = If[t];
        return null == e && 32 >= Mf && (e = If[t] = Mf++), e;
    }
    function Ei(t, e, n, i, r, o, a) {
        var s, l = (r = r || xf).labelFetcher, h = r.labelDataIndex, u = r.labelDimIndex, c = r.labelProp, d = n.getShallow("show"), f = i.getShallow("show");
        (d || f) && (l && (s = l.getFormattedLabel(h, "normal", null, u, c)), null == s && (s = x(r.defaultText) ? r.defaultText(h, r) : r.defaultText));
        var p = d ? s : null, g = f ? A(l ? l.getFormattedLabel(h, "emphasis", null, u, c) : null, s) : null;
        (null != p || null != g) && (Bi(t, n, o, r), Bi(e, i, a, r, !0)), t.text = p, e.text = g;
    }
    function Bi(t, e, n, i, r) {
        return zi(t, e, i, r), n && a(t, n), t;
    }
    function zi(t, e, n, i) {
        if ((n = n || xf).isRectText) {
            var r;
            n.getTextPosition ? r = n.getTextPosition(e, i) : "outside" === (r = e.getShallow("position") || (i ? null : "inside")) && (r = "top"), 
            t.textPosition = r, t.textOffset = e.getShallow("offset");
            var o = e.getShallow("rotate");
            null != o && (o *= Math.PI / 180), t.textRotation = o, t.textDistance = A(e.getShallow("distance"), i ? null : 5);
        }
        var a, s = e.ecModel, l = s && s.option.textStyle, h = function(t) {
            for (var e; t && t !== t.ecModel; ) {
                var n = (t.option || xf).rich;
                if (n) for (var i in e = e || {}, n) n.hasOwnProperty(i) && (e[i] = 1);
                t = t.parentModel;
            }
            return e;
        }(e);
        if (h) for (var u in a = {}, h) if (h.hasOwnProperty(u)) {
            var c = e.getModel([ "rich", u ]);
            Ni(a[u] = {}, c, l, n, i);
        }
        return t.rich = a, Ni(t, e, l, n, i, !0), n.forceRich && !n.textStyle && (n.textStyle = {}), 
        t;
    }
    function Ni(t, e, n, i, r, o) {
        n = !r && n || xf, t.textFill = Ri(e.getShallow("color"), i) || n.color, t.textStroke = Ri(e.getShallow("textBorderColor"), i) || n.textBorderColor, 
        t.textStrokeWidth = A(e.getShallow("textBorderWidth"), n.textBorderWidth), r || (o && (t.insideRollbackOpt = i, 
        Fi(t)), null == t.textFill && (t.textFill = i.autoColor)), t.fontStyle = e.getShallow("fontStyle") || n.fontStyle, 
        t.fontWeight = e.getShallow("fontWeight") || n.fontWeight, t.fontSize = e.getShallow("fontSize") || n.fontSize, 
        t.fontFamily = e.getShallow("fontFamily") || n.fontFamily, t.textAlign = e.getShallow("align"), 
        t.textVerticalAlign = e.getShallow("verticalAlign") || e.getShallow("baseline"), 
        t.textLineHeight = e.getShallow("lineHeight"), t.textWidth = e.getShallow("width"), 
        t.textHeight = e.getShallow("height"), t.textTag = e.getShallow("tag"), o && i.disableBox || (t.textBackgroundColor = Ri(e.getShallow("backgroundColor"), i), 
        t.textPadding = e.getShallow("padding"), t.textBorderColor = Ri(e.getShallow("borderColor"), i), 
        t.textBorderWidth = e.getShallow("borderWidth"), t.textBorderRadius = e.getShallow("borderRadius"), 
        t.textBoxShadowColor = e.getShallow("shadowColor"), t.textBoxShadowBlur = e.getShallow("shadowBlur"), 
        t.textBoxShadowOffsetX = e.getShallow("shadowOffsetX"), t.textBoxShadowOffsetY = e.getShallow("shadowOffsetY")), 
        t.textShadowColor = e.getShallow("textShadowColor") || n.textShadowColor, t.textShadowBlur = e.getShallow("textShadowBlur") || n.textShadowBlur, 
        t.textShadowOffsetX = e.getShallow("textShadowOffsetX") || n.textShadowOffsetX, 
        t.textShadowOffsetY = e.getShallow("textShadowOffsetY") || n.textShadowOffsetY;
    }
    function Ri(t, e) {
        return "auto" !== t ? t : e && e.autoColor ? e.autoColor : null;
    }
    function Fi(t) {
        var e, n = t.textPosition, i = t.insideRollbackOpt;
        if (i && null == t.textFill) {
            var r = i.autoColor, o = i.isRectText, a = i.useInsideStyle, s = !1 !== a && (!0 === a || o && n && "string" == typeof n && n.indexOf("inside") >= 0), l = !s && null != r;
            (s || l) && (e = {
                textFill: t.textFill,
                textStroke: t.textStroke,
                textStrokeWidth: t.textStrokeWidth
            }), s && (t.textFill = "#fff", null == t.textStroke && (t.textStroke = r, null == t.textStrokeWidth && (t.textStrokeWidth = 2))), 
            l && (t.textFill = r);
        }
        t.insideRollback = e;
    }
    function Vi(t) {
        var e = t.insideRollback;
        e && (t.textFill = e.textFill, t.textStroke = e.textStroke, t.textStrokeWidth = e.textStrokeWidth, 
        t.insideRollback = null);
    }
    function Hi(t, e) {
        var n = e && e.getModel("textStyle");
        return O([ t.fontStyle || n && n.getShallow("fontStyle") || "", t.fontWeight || n && n.getShallow("fontWeight") || "", (t.fontSize || n && n.getShallow("fontSize") || 12) + "px", t.fontFamily || n && n.getShallow("fontFamily") || "sans-serif" ].join(" "));
    }
    function Gi(t, e, n, i, r, o) {
        if ("function" == typeof r && (o = r, r = null), i && i.isAnimationEnabled()) {
            var a = t ? "Update" : "", s = i.getShallow("animationDuration" + a), l = i.getShallow("animationEasing" + a), h = i.getShallow("animationDelay" + a);
            "function" == typeof h && (h = h(r, i.getAnimationDelayParams ? i.getAnimationDelayParams(e, r) : null)), 
            "function" == typeof s && (s = s(r)), s > 0 ? e.animateTo(n, s, h || 0, l, o, !!o) : (e.stopAnimation(), 
            e.attr(n), o && o());
        } else e.stopAnimation(), e.attr(n), o && o();
    }
    function Wi(t, e, n, i, r) {
        Gi(!0, t, e, n, i, r);
    }
    function Xi(t, e, n, i, r) {
        Gi(!1, t, e, n, i, r);
    }
    function Ui(t, e, n) {
        return e && !d(e) && (e = hu.getLocalTransform(e)), n && (e = Mt([], e)), $([], t, e);
    }
    function Yi(t, e, n) {
        function i(t) {
            var e = {
                position: H(t.position),
                rotation: t.rotation
            };
            return t.shape && (e.shape = a({}, t.shape)), e;
        }
        if (t && e) {
            var r = function(t) {
                var e = {};
                return t.traverse(function(t) {
                    !t.isGroup && t.anid && (e[t.anid] = t);
                }), e;
            }(t);
            e.traverse(function(t) {
                if (!t.isGroup && t.anid) {
                    var e = r[t.anid];
                    if (e) {
                        var o = i(t);
                        t.attr(i(e)), Wi(t, o, n, t.dataIndex);
                    }
                }
            });
        }
    }
    function qi(t, e, n) {
        var i = (e = a({
            rectHover: !0
        }, e)).style = {
            strokeNoScale: !0
        };
        return n = n || {
            x: -1,
            y: -1,
            width: 2,
            height: 2
        }, t ? 0 === t.indexOf("image://") ? (i.image = t.slice(8), s(i, n), new Ke(e)) : gi(t.replace("path://", ""), e, n, "center") : void 0;
    }
    function ji(t, e, n, i, r, o, a, s) {
        var l = n - t, h = i - e, u = a - r, c = s - o, d = Zi(u, c, l, h);
        if (function(t) {
            return 1e-6 >= t && t >= -1e-6;
        }(d)) return !1;
        var f = t - r, p = e - o, g = Zi(f, p, l, h) / d;
        if (0 > g || g > 1) return !1;
        var v = Zi(f, p, u, c) / d;
        return !(0 > v || v > 1);
    }
    function Zi(t, e, n, i) {
        return t * i - n * e;
    }
    function Ki(t, e, n) {
        this.parentModel = e, this.ecModel = n, this.option = t;
    }
    function $i(e, n, i) {
        for (var r = 0; r < n.length && (!n[r] || null != (e = e && "object" == t(e) ? e[n[r]] : null)); r++) ;
        return null == e && i && (e = i.get(n)), e;
    }
    function Qi(t, e) {
        var n = Nf(t).getParent;
        return n ? n.call(t, e) : t.parentModel;
    }
    function Ji(t) {
        return [ t || "", Rf++, Math.random().toFixed(5) ].join("_");
    }
    function tr(t, e, n, i) {
        var r = e[1] - e[0], o = n[1] - n[0];
        if (0 === r) return 0 === o ? n[0] : (n[0] + n[1]) / 2;
        if (i) if (r > 0) {
            if (t <= e[0]) return n[0];
            if (t >= e[1]) return n[1];
        } else {
            if (t >= e[0]) return n[0];
            if (t <= e[1]) return n[1];
        } else {
            if (t === e[0]) return n[0];
            if (t === e[1]) return n[1];
        }
        return (t - e[0]) / r * o + n[0];
    }
    function er(t, e) {
        switch (t) {
          case "center":
          case "middle":
            t = "50%";
            break;

          case "left":
          case "top":
            t = "0%";
            break;

          case "right":
          case "bottom":
            t = "100%";
        }
        return "string" == typeof t ? function(t) {
            return t.replace(/^\s+|\s+$/g, "");
        }(t).match(/%$/) ? parseFloat(t) / 100 * e : parseFloat(t) : null == t ? NaN : +t;
    }
    function nr(t, e, n) {
        return null == e && (e = 10), e = Math.min(Math.max(0, e), 20), t = (+t).toFixed(e), 
        n ? t : +t;
    }
    function ir(t) {
        var e = t.toString(), n = e.indexOf("e");
        if (n > 0) {
            var i = +e.slice(n + 1);
            return 0 > i ? -i : 0;
        }
        var r = e.indexOf(".");
        return 0 > r ? 0 : e.length - 1 - r;
    }
    function rr(t, e) {
        var n = Math.log, i = Math.LN10, r = Math.floor(n(t[1] - t[0]) / i), o = Math.round(n(Math.abs(e[1] - e[0])) / i), a = Math.min(Math.max(-r + o, 0), 20);
        return isFinite(a) ? a : 20;
    }
    function or(t, e, n) {
        if (!t[e]) return 0;
        var i = g(t, function(t, e) {
            return t + (isNaN(e) ? 0 : e);
        }, 0);
        if (0 === i) return 0;
        for (var r = Math.pow(10, n), o = p(t, function(t) {
            return (isNaN(t) ? 0 : t) / i * r * 100;
        }), a = 100 * r, s = p(o, function(t) {
            return Math.floor(t);
        }), l = g(s, function(t, e) {
            return t + e;
        }, 0), h = p(o, function(t, e) {
            return t - s[e];
        }); a > l; ) {
            for (var u = Number.NEGATIVE_INFINITY, c = null, d = 0, f = h.length; f > d; ++d) h[d] > u && (u = h[d], 
            c = d);
            ++s[c], h[c] = 0, ++l;
        }
        return s[e] / r;
    }
    function ar(t) {
        var e = 2 * Math.PI;
        return (t % e + e) % e;
    }
    function sr(t) {
        return t > -Ff && Ff > t;
    }
    function lr(t) {
        if (t instanceof Date) return t;
        if ("string" == typeof t) {
            var e = Vf.exec(t);
            if (!e) return new Date(NaN);
            if (e[8]) {
                var n = +e[4] || 0;
                return "Z" !== e[8].toUpperCase() && (n -= e[8].slice(0, 3)), new Date(Date.UTC(+e[1], +(e[2] || 1) - 1, +e[3] || 1, n, +(e[5] || 0), +e[6] || 0, +e[7] || 0));
            }
            return new Date(+e[1], +(e[2] || 1) - 1, +e[3] || 1, +e[4] || 0, +(e[5] || 0), +e[6] || 0, +e[7] || 0);
        }
        return new Date(null == t ? NaN : Math.round(t));
    }
    function hr(t) {
        return Math.pow(10, ur(t));
    }
    function ur(t) {
        if (0 === t) return 0;
        var e = Math.floor(Math.log(t) / Math.LN10);
        return t / Math.pow(10, e) >= 10 && e++, e;
    }
    function cr(t, e) {
        var n = ur(t), i = Math.pow(10, n), r = t / i;
        return t = (e ? 1.5 > r ? 1 : 2.5 > r ? 2 : 4 > r ? 3 : 7 > r ? 5 : 10 : 1 > r ? 1 : 2 > r ? 2 : 3 > r ? 3 : 5 > r ? 5 : 10) * i, 
        n >= -20 ? +t.toFixed(0 > n ? -n : 0) : t;
    }
    function dr(t) {
        return isNaN(t) ? "-" : (t = (t + "").split("."))[0].replace(/(\d{1,3})(?=(?:\d{3})+(?!\d))/g, "$1,") + (t.length > 1 ? "." + t[1] : "");
    }
    function fr(t, e) {
        return t = (t || "").toLowerCase().replace(/-(.)/g, function(t, e) {
            return e.toUpperCase();
        }), e && t && (t = t.charAt(0).toUpperCase() + t.slice(1)), t;
    }
    function pr(t) {
        return null == t ? "" : (t + "").replace(Wf, function(t, e) {
            return Xf[e];
        });
    }
    function gr(t, e, n) {
        _(e) || (e = [ e ]);
        var i = e.length;
        if (!i) return "";
        for (var r = e[0].$vars || [], o = 0; o < r.length; o++) {
            var a = Uf[o];
            t = t.replace(Yf(a), Yf(a, 0));
        }
        for (var s = 0; i > s; s++) for (var l = 0; l < r.length; l++) {
            var h = e[s][r[l]];
            t = t.replace(Yf(Uf[l], s), n ? pr(h) : h);
        }
        return t;
    }
    function vr(t, e) {
        var n = (t = w(t) ? {
            color: t,
            extraCssText: e
        } : t || {}).color, i = t.type, r = (e = t.extraCssText, t.renderMode || "html"), o = t.markerId || "X";
        return n ? "html" === r ? "subItem" === i ? '<span style="display:inline-block;vertical-align:middle;margin-right:8px;margin-left:3px;border-radius:4px;width:4px;height:4px;background-color:' + pr(n) + ";" + (e || "") + '"></span>' : '<span style="display:inline-block;margin-right:5px;border-radius:10px;width:10px;height:10px;background-color:' + pr(n) + ";" + (e || "") + '"></span>' : {
            renderMode: r,
            content: "{marker" + o + "|}  ",
            style: {
                color: n
            }
        } : "";
    }
    function mr(t, e) {
        return "0000".substr(0, e - (t += "").length) + t;
    }
    function yr(t, e, n) {
        ("week" === t || "month" === t || "quarter" === t || "half-year" === t || "year" === t) && (t = "MM-dd\nyyyy");
        var i = lr(e), r = n ? "UTC" : "", o = i["get" + r + "FullYear"](), a = i["get" + r + "Month"]() + 1, s = i["get" + r + "Date"](), l = i["get" + r + "Hours"](), h = i["get" + r + "Minutes"](), u = i["get" + r + "Seconds"](), c = i["get" + r + "Milliseconds"]();
        return t.replace("MM", mr(a, 2)).replace("M", a).replace("yyyy", o).replace("yy", o % 100).replace("dd", mr(s, 2)).replace("d", s).replace("hh", mr(l, 2)).replace("h", l).replace("mm", mr(h, 2)).replace("m", h).replace("ss", mr(u, 2)).replace("s", u).replace("SSS", mr(c, 3));
    }
    function _r(t, e) {
        if ("_blank" === e || "blank" === e) {
            var n = window.open();
            n.opener = null, n.location = t;
        } else window.open(t, e);
    }
    function xr(t, e, n, i, r) {
        var o = 0, a = 0;
        null == i && (i = 1 / 0), null == r && (r = 1 / 0);
        var s = 0;
        e.eachChild(function(l, h) {
            var u, c, d = l.position, f = l.getBoundingRect(), p = e.childAt(h + 1), g = p && p.getBoundingRect();
            if ("horizontal" === t) {
                var v = f.width + (g ? -g.x + f.x : 0);
                (u = o + v) > i || l.newline ? (o = 0, u = v, a += s + n, s = f.height) : s = Math.max(s, f.height);
            } else {
                var m = f.height + (g ? -g.y + f.y : 0);
                (c = a + m) > r || l.newline ? (o += s + n, a = 0, c = m, s = f.width) : s = Math.max(s, f.width);
            }
            l.newline || (d[0] = o, d[1] = a, "horizontal" === t ? o = u + n : a = c + n);
        });
    }
    function wr(t, e, n) {
        n = Gf(n || 0);
        var i = e.width, r = e.height, o = er(t.left, i), a = er(t.top, r), s = er(t.right, i), l = er(t.bottom, r), h = er(t.width, i), u = er(t.height, r), c = n[2] + n[0], d = n[1] + n[3], f = t.aspect;
        switch (isNaN(h) && (h = i - s - d - o), isNaN(u) && (u = r - l - c - a), null != f && (isNaN(h) && isNaN(u) && (f > i / r ? h = .8 * i : u = .8 * r), 
        isNaN(h) && (h = f * u), isNaN(u) && (u = h / f)), isNaN(o) && (o = i - s - h - d), 
        isNaN(a) && (a = r - l - u - c), t.left || t.right) {
          case "center":
            o = i / 2 - h / 2 - n[3];
            break;

          case "right":
            o = i - h - d;
        }
        switch (t.top || t.bottom) {
          case "middle":
          case "center":
            a = r / 2 - u / 2 - n[0];
            break;

          case "bottom":
            a = r - u - c;
        }
        o = o || 0, a = a || 0, isNaN(h) && (h = i - d - o - (s || 0)), isNaN(u) && (u = r - c - a - (l || 0));
        var p = new ie(o + n[3], a + n[0], h, u);
        return p.margin = n, p;
    }
    function br(t, e, n) {
        function i(n, i) {
            var a = {}, l = 0, h = {}, u = 0;
            if (Zf(n, function(e) {
                h[e] = t[e];
            }), Zf(n, function(t) {
                r(e, t) && (a[t] = h[t] = e[t]), o(a, t) && l++, o(h, t) && u++;
            }), s[i]) return o(e, n[1]) ? h[n[2]] = null : o(e, n[2]) && (h[n[1]] = null), h;
            if (2 !== u && l) {
                if (l >= 2) return a;
                for (var c = 0; c < n.length; c++) {
                    var d = n[c];
                    if (!r(a, d) && r(t, d)) {
                        a[d] = t[d];
                        break;
                    }
                }
                return a;
            }
            return h;
        }
        function r(t, e) {
            return t.hasOwnProperty(e);
        }
        function o(t, e) {
            return null != t[e] && "auto" !== t[e];
        }
        function a(t, e, n) {
            Zf(t, function(t) {
                e[t] = n[t];
            });
        }
        !b(n) && (n = {});
        var s = n.ignoreSize;
        !_(s) && (s = [ s, s ]);
        var l = i($f[0], 0), h = i($f[1], 1);
        a($f[0], t, l), a($f[1], t, h);
    }
    function Sr(t) {
        return function(t, e) {
            return e && t && Zf(Kf, function(n) {
                e.hasOwnProperty(n) && (t[n] = e[n]);
            }), t;
        }({}, t);
    }
    function Mr(t) {
        this.fromDataset = t.fromDataset, this.data = t.data || (t.sourceFormat === hp ? {} : []), 
        this.sourceFormat = t.sourceFormat || up, this.seriesLayoutBy = t.seriesLayoutBy || dp, 
        this.dimensionsDefine = t.dimensionsDefine, this.encodeDefine = t.encodeDefine && N(t.encodeDefine), 
        this.startIndex = t.startIndex || 0, this.dimensionsDetectCount = t.dimensionsDetectCount;
    }
    function Ir(t) {
        var e = t.option, n = e.data, i = M(n) ? cp : ap, r = !1, o = e.seriesLayoutBy, a = e.sourceHeader, s = e.dimensions, l = kr(t);
        if (l) {
            var h = l.option;
            n = h.source, i = gp(l).sourceFormat, r = !0, o = o || h.seriesLayoutBy, null == a && (a = h.sourceHeader), 
            s = s || h.dimensions;
        }
        var u = function(t, e, n, i, r) {
            if (!t) return {
                dimensionsDefine: Tr(r)
            };
            var o, a;
            if (e === sp) "auto" === i || null == i ? Cr(function(t) {
                null != t && "-" !== t && (w(t) ? null == a && (a = 1) : a = 0);
            }, n, t, 10) : a = i ? 1 : 0, r || 1 !== a || (r = [], Cr(function(t, e) {
                r[e] = null != t ? t : "";
            }, n, t)), o = r ? r.length : n === fp ? t.length : t[0] ? t[0].length : null; else if (e === lp) r || (r = function(t) {
                for (var e, n = 0; n < t.length && !(e = t[n++]); ) ;
                if (e) {
                    var i = [];
                    return f(e, function(t, e) {
                        i.push(e);
                    }), i;
                }
            }(t)); else if (e === hp) r || (r = [], f(t, function(t, e) {
                r.push(e);
            })); else if (e === ap) {
                var s = pn(t[0]);
                o = _(s) && s.length || 1;
            } else e === cp && wh && L(!!r, "dimensions must be given if data is TypedArray.");
            return {
                startIndex: a,
                dimensionsDefine: Tr(r),
                dimensionsDetectCount: o
            };
        }(n, i, o, a, s);
        gp(t).source = new Mr({
            data: n,
            fromDataset: r,
            seriesLayoutBy: o,
            sourceFormat: i,
            dimensionsDefine: u.dimensionsDefine,
            startIndex: u.startIndex,
            dimensionsDetectCount: u.dimensionsDetectCount,
            encodeDefine: e.encode
        });
    }
    function Tr(t) {
        if (t) {
            var e = N();
            return p(t, function(t) {
                if (null == (t = a({}, b(t) ? t : {
                    name: t
                })).name) return t;
                t.name += "", null == t.displayName && (t.displayName = t.name);
                var n = e.get(t.name);
                return n ? t.name += "-" + n.count++ : e.set(t.name, {
                    count: 1
                }), t;
            });
        }
    }
    function Cr(t, e, n, i) {
        if (null == i && (i = 1 / 0), e === fp) for (var r = 0; r < n.length && i > r; r++) t(n[r] ? n[r][0] : null, r); else {
            var o = n[0] || [];
            for (r = 0; r < o.length && i > r; r++) t(o[r], r);
        }
    }
    function Ar(t, e, n) {
        function i(t, e, n) {
            for (var i = 0; n > i; i++) t.push(e + i);
        }
        function r(t) {
            var e = t.dimsDef;
            return e ? e.length : 1;
        }
        var o = {}, a = kr(e);
        if (!a || !t) return o;
        var s, l, h = [], u = [], c = e.ecModel, d = gp(c).datasetMap, p = a.uid + "_" + n.seriesLayoutBy;
        f(t = t.slice(), function(e, n) {
            !b(e) && (t[n] = {
                name: e
            }), "ordinal" === e.type && null == s && (s = n, l = r(t[n])), o[e.name] = [];
        });
        var g = d.get(p) || d.set(p, {
            categoryWayDim: l,
            valueWayDim: 0
        });
        return f(t, function(t, e) {
            var n = t.name, a = r(t);
            if (null == s) {
                var l = g.valueWayDim;
                i(o[n], l, a), i(u, l, a), g.valueWayDim += a;
            } else if (s === e) i(o[n], 0, a), i(h, 0, a); else {
                l = g.categoryWayDim;
                i(o[n], l, a), i(u, l, a), g.categoryWayDim += a;
            }
        }), h.length && (o.itemName = h), u.length && (o.seriesName = u), o;
    }
    function Dr(t, e, n) {
        var i = {};
        if (!kr(t)) return i;
        var r, o = e.sourceFormat, a = e.dimensionsDefine;
        (o === lp || o === hp) && f(a, function(t, e) {
            "name" === (b(t) ? t.name : t) && (r = e);
        });
        var s = function() {
            function t(t) {
                return null != t.v && null != t.n;
            }
            for (var i = {}, s = {}, l = [], h = 0, u = Math.min(5, n); u > h; h++) {
                var c = Lr(e.data, o, e.seriesLayoutBy, a, e.startIndex, h);
                l.push(c);
                var d = c === pp.Not;
                if (d && null == i.v && h !== r && (i.v = h), (null == i.n || i.n === i.v || !d && l[i.n] === pp.Not) && (i.n = h), 
                t(i) && l[i.n] !== pp.Not) return i;
                d || (c === pp.Might && null == s.v && h !== r && (s.v = h), (null == s.n || s.n === s.v) && (s.n = h));
            }
            return t(i) ? i : t(s) ? s : null;
        }();
        if (s) {
            i.value = s.v;
            var l = null != r ? r : s.n;
            i.itemName = [ l ], i.seriesName = [ l ];
        }
        return i;
    }
    function kr(t) {
        var e = t.option;
        return e.data ? void 0 : t.ecModel.getComponent("dataset", e.datasetIndex || 0);
    }
    function Pr(t, e) {
        return Lr(t.data, t.sourceFormat, t.seriesLayoutBy, t.dimensionsDefine, t.startIndex, e);
    }
    function Lr(t, e, n, i, r, o) {
        function a(t) {
            var e = w(t);
            return null != t && isFinite(t) && "" !== t ? e ? pp.Might : pp.Not : e && "-" !== t ? pp.Must : void 0;
        }
        var s, l, h;
        if (M(t)) return pp.Not;
        if (i) {
            var u = i[o];
            b(u) ? (l = u.name, h = u.type) : w(u) && (l = u);
        }
        if (null != h) return "ordinal" === h ? pp.Must : pp.Not;
        if (e === sp) if (n === fp) {
            for (var c = t[o], d = 0; d < (c || []).length && 5 > d; d++) if (null != (s = a(c[r + d]))) return s;
        } else for (d = 0; d < t.length && 5 > d; d++) {
            var f = t[r + d];
            if (f && null != (s = a(f[o]))) return s;
        } else if (e === lp) {
            if (!l) return pp.Not;
            for (d = 0; d < t.length && 5 > d; d++) {
                if ((p = t[d]) && null != (s = a(p[l]))) return s;
            }
        } else if (e === hp) {
            if (!l) return pp.Not;
            if (!(c = t[l]) || M(c)) return pp.Not;
            for (d = 0; d < c.length && 5 > d; d++) if (null != (s = a(c[d]))) return s;
        } else if (e === ap) for (d = 0; d < t.length && 5 > d; d++) {
            var p, g = pn(p = t[d]);
            if (!_(g)) return pp.Not;
            if (null != (s = a(g[o]))) return s;
        }
        return pp.Not;
    }
    function Or(e) {
        e = e, this.option = {}, this.option[vp] = 1, this._componentsMap = N({
            series: []
        }), this._seriesIndices, this._seriesIndicesMap, function(e, n) {
            var o = e.color && !e.colorLayer;
            f(n, function(n, a) {
                "colorLayer" === a && o || ep.hasClass(a) || ("object" == t(n) ? e[a] = e[a] ? r(e[a], n, !1) : i(n) : null == e[a] && (e[a] = n));
            });
        }(e, this._theme.option), r(e, ip, !1), this.mergeOption(e);
    }
    function Er(t, e) {
        t._seriesIndicesMap = N(t._seriesIndices = p(e, function(t) {
            return t.componentIndex;
        }) || []);
    }
    function Br(t, e) {
        return e.hasOwnProperty("subType") ? v(t, function(t) {
            return t.subType === e.subType;
        }) : t;
    }
    function zr(t) {
        if (wh && !t._seriesIndices) throw new Error("Option should contains series.");
    }
    function Nr(t) {
        f(yp, function(e) {
            this[e] = m(t[e], t);
        }, this);
    }
    function Rr() {
        this._coordinateSystems = [];
    }
    function Fr(t) {
        this._api = t, this._timelineOptions = [], this._mediaList = [], this._mediaDefault, 
        this._currentMediaIndices = [], this._optionBackup, this._newBaseOption;
    }
    function Vr(t, e, n) {
        var i, r, o = [], a = [], s = t.timeline;
        if (t.baseOption && (r = t.baseOption), (s || t.options) && (r = r || {}, o = (t.options || []).slice()), 
        t.media) {
            r = r || {};
            var l = t.media;
            xp(l, function(t) {
                t && t.option && (t.query ? a.push(t) : i || (i = t));
            });
        }
        return r || (r = t), r.timeline || (r.timeline = s), xp([ r ].concat(o).concat(p(a, function(t) {
            return t.option;
        })), function(t) {
            xp(e, function(e) {
                e(t, n);
            });
        }), {
            baseOption: r,
            timelineOptions: o,
            mediaDefault: i,
            mediaList: a
        };
    }
    function Hr(t, e, n) {
        var i = {
            width: e,
            height: n,
            aspectratio: e / n
        }, r = !0;
        return f(t, function(t, e) {
            var n = e.match(Mp);
            if (n && n[1] && n[2]) {
                var o = n[1], a = n[2].toLowerCase();
                (function(t, e, n) {
                    return "min" === n ? t >= e : "max" === n ? e >= t : t === e;
                })(i[a], t, o) || (r = !1);
            }
        }), r;
    }
    function Gr(t) {
        var e = t && t.itemStyle;
        if (e) for (var n = 0, i = Cp.length; i > n; n++) {
            var o = Cp[n], a = e.normal, s = e.emphasis;
            a && a[o] && (t[o] = t[o] || {}, t[o].normal ? r(t[o].normal, a[o]) : t[o].normal = a[o], 
            a[o] = null), s && s[o] && (t[o] = t[o] || {}, t[o].emphasis ? r(t[o].emphasis, s[o]) : t[o].emphasis = s[o], 
            s[o] = null);
        }
    }
    function Wr(t, e, n) {
        if (t && t[e] && (t[e].normal || t[e].emphasis)) {
            var i = t[e].normal, r = t[e].emphasis;
            i && (n ? (t[e].normal = t[e].emphasis = null, s(t[e], i)) : t[e] = i), r && (t.emphasis = t.emphasis || {}, 
            t.emphasis[e] = r);
        }
    }
    function Xr(t) {
        Wr(t, "itemStyle"), Wr(t, "lineStyle"), Wr(t, "areaStyle"), Wr(t, "label"), Wr(t, "labelLine"), 
        Wr(t, "upperLabel"), Wr(t, "edgeLabel");
    }
    function Ur(t, e) {
        var n = Tp(t) && t[e], i = Tp(n) && n.textStyle;
        if (i) for (var r = 0, o = zc.length; o > r; r++) {
            e = zc[r];
            i.hasOwnProperty(e) && (n[e] = i[e]);
        }
    }
    function Yr(t) {
        t && (Xr(t), Ur(t, "label"), t.emphasis && Ur(t.emphasis, "label"));
    }
    function qr(t) {
        return _(t) ? t : t ? [ t ] : [];
    }
    function jr(t) {
        return (_(t) ? t[0] : t) || {};
    }
    function Zr(t) {
        f(Dp, function(e) {
            e[0] in t && !(e[1] in t) && (t[e[1]] = t[e[0]]);
        });
    }
    function Kr(t) {
        f(t, function(e, n) {
            var i = [], r = [ NaN, NaN ], o = [ e.stackResultDimension, e.stackedOverDimension ], a = e.data, s = e.isStackedByIndex, l = a.map(o, function(o, l, h) {
                var u, c, d = a.get(e.stackedDimension, h);
                if (isNaN(d)) return r;
                s ? c = a.getRawIndex(h) : u = a.get(e.stackedByDimension, h);
                for (var f = NaN, p = n - 1; p >= 0; p--) {
                    var g = t[p];
                    if (s || (c = g.data.rawIndexOf(g.stackedByDimension, u)), c >= 0) {
                        var v = g.data.getByRawIndex(g.stackResultDimension, c);
                        if (d >= 0 && v > 0 || 0 >= d && 0 > v) {
                            d += v, f = v;
                            break;
                        }
                    }
                }
                return i[0] = d, i[1] = f, i;
            });
            a.hostModel.setData(l), e.data = l;
        });
    }
    function $r(t, e) {
        Mr.isInstance(t) || (t = Mr.seriesDataToSource(t)), this._source = t;
        var n = this._data = t.data, i = t.sourceFormat;
        if (i === cp) {
            if (wh && null == e) throw new Error("Typed array data must specify dimension size");
            this._offset = 0, this._dimSize = e, this._data = n;
        }
        var r = Op[i === sp ? i + "_" + t.seriesLayoutBy : i];
        wh && L(r, "Invalide sourceFormat: " + i), a(this, r);
    }
    function Qr() {
        return this._data.length;
    }
    function Jr(t) {
        return this._data[t];
    }
    function to(t) {
        for (var e = 0; e < t.length; e++) this._data.push(t[e]);
    }
    function eo(t, e, n) {
        return null != n ? t[n] : t;
    }
    function no(t, e, n, i) {
        return io(t[i], this._dimensionInfos[e]);
    }
    function io(t, e) {
        var n = e && e.type;
        if ("ordinal" === n) {
            var i = e && e.ordinalMeta;
            return i ? i.parseAndCollect(t) : t;
        }
        return "time" === n && "number" != typeof t && null != t && "-" !== t && (t = +lr(t)), 
        null == t || "" === t ? NaN : +t;
    }
    function ro(t, e, n) {
        if (t) {
            var i = t.getRawDataItem(e);
            if (null != i) {
                var r, o, a = t.getProvider().getSource().sourceFormat, s = t.getDimensionInfo(n);
                return s && (r = s.name, o = s.index), Ep[a](i, e, o, r);
            }
        }
    }
    function oo(t, e, n) {
        if (t) {
            var i = t.getProvider().getSource().sourceFormat;
            if (i === ap || i === lp) {
                var r = t.getRawDataItem(e);
                return i !== ap || b(r) || (r = null), r ? r[n] : void 0;
            }
        }
    }
    function ao(t) {
        return new so(t);
    }
    function so(t) {
        t = t || {}, this._reset = t.reset, this._plan = t.plan, this._count = t.count, 
        this._onDirty = t.onDirty, this._dirty = !0, this.context;
    }
    function lo(t, e, n, i, r, o) {
        Fp.reset(n, i, r, o), t._callingProgress = e, t._callingProgress({
            start: n,
            end: i,
            count: i - n,
            next: Fp.next
        }, t.context);
    }
    function ho(t) {
        var e = t.name;
        vn(t) || (t.name = function(t) {
            var e = t.getRawData(), n = e.mapDimension("seriesName", !0), i = [];
            return f(n, function(t) {
                var n = e.getDimensionInfo(t);
                n.displayName && i.push(n.displayName);
            }), i.join(" ");
        }(t) || e);
    }
    function uo(t) {
        return t.model.getRawData().count();
    }
    function co(t) {
        var e = t.model;
        return e.setData(e.getRawData().cloneShallow()), fo;
    }
    function fo(t, e) {
        e.outputData && t.end > e.outputData.count() && e.model.getRawData().cloneShallow(e.outputData);
    }
    function po(t, e) {
        f(t.CHANGABLE_METHODS, function(n) {
            t.wrapMethod(n, y(go, e));
        });
    }
    function go(t) {
        var e = vo(t);
        e && e.setOutputEnd(this.count());
    }
    function vo(t) {
        var e = (t.ecModel || {}).scheduler, n = e && e.getPipeline(t.uid);
        if (n) {
            var i = n.currentTask;
            if (i) {
                var r = i.agentStubMap;
                r && (i = r.get(t.uid));
            }
            return i;
        }
    }
    function mo() {
        this.group = new Nu(), this.uid = Ji("viewChart"), this.renderTask = ao({
            plan: xo,
            reset: wo
        }), this.renderTask.context = {
            view: this
        };
    }
    function yo(t, e, n) {
        if (t && (t.trigger(e, n), t.isGroup && !Li(t))) for (var i = 0, r = t.childCount(); r > i; i++) yo(t.childAt(i), e, n);
    }
    function _o(t, e, n) {
        var i = yn(t, e), r = e && null != e.highlightKey ? Oi(e.highlightKey) : null;
        null != i ? f(dn(i), function(e) {
            yo(t.getItemGraphicEl(e), n, r);
        }) : t.eachItemGraphicEl(function(t) {
            yo(t, n, r);
        });
    }
    function xo(t) {
        return Yp(t.model);
    }
    function wo(t) {
        var e = t.model, n = t.ecModel, i = t.api, r = t.payload, o = e.pipelineContext.progressiveRender, a = t.view, s = r && Up(r).updateMethod, l = o ? "incrementalPrepareRender" : s && a[s] ? s : "render";
        return "render" !== l && a[l](e, n, i, r), jp[l];
    }
    function bo(t, e, n) {
        function i() {
            u = new Date().getTime(), c = null, t.apply(a, s || []);
        }
        var r, o, a, s, l, h = 0, u = 0, c = null;
        e = e || 0;
        var d = function() {
            r = new Date().getTime(), a = this, s = arguments;
            var t = l || e, d = l || n;
            l = null, o = r - (d ? h : u) - t, clearTimeout(c), d ? c = setTimeout(i, t) : o >= 0 ? i() : c = setTimeout(i, -o), 
            h = r;
        };
        return d.clear = function() {
            c && (clearTimeout(c), c = null);
        }, d.debounceNextCall = function(t) {
            l = t;
        }, d;
    }
    function So(t, e, n, i) {
        this.ecInstance = t, this.api = e, this.unfinished;
        n = this._dataProcessorHandlers = n.slice(), i = this._visualHandlers = i.slice();
        this._allHandlers = n.concat(i), this._stageTaskMap = N();
    }
    function Mo(t, e, n, i, r) {
        function o(t, e) {
            return t.setDirty && (!t.dirtyMap || t.dirtyMap.get(e.__pipeline.id));
        }
        var a;
        r = r || {}, f(e, function(e) {
            if (!r.visualType || r.visualType === e.visualType) {
                var s = t._stageTaskMap.get(e.uid), l = s.seriesTaskMap, h = s.overallTask;
                if (h) {
                    var u, c = h.agentStubMap;
                    c.each(function(t) {
                        o(r, t) && (t.dirty(), u = !0);
                    }), u && h.dirty(), ig(h, i);
                    var d = t.getPerformArgs(h, r.block);
                    c.each(function(t) {
                        t.perform(d);
                    }), a |= h.perform(d);
                } else l && l.each(function(s) {
                    o(r, s) && s.dirty();
                    var l = t.getPerformArgs(s, r.block);
                    l.skip = !e.performRawSeries && n.isSeriesFiltered(s.context.model), ig(s, i), a |= s.perform(l);
                });
            }
        }), t.unfinished |= a;
    }
    function Io(t) {
        t.overallReset(t.ecModel, t.api, t.payload);
    }
    function To(t) {
        return t.overallProgress && Co;
    }
    function Co() {
        this.agent.dirty(), this.getDownstream().dirty();
    }
    function Ao() {
        this.agent && this.agent.dirty();
    }
    function Do(t) {
        return t.plan && t.plan(t.model, t.ecModel, t.api, t.payload);
    }
    function ko(t) {
        t.useClearVisual && t.data.clearAllVisual();
        var e = t.resetDefines = dn(t.reset(t.model, t.ecModel, t.api, t.payload));
        return e.length > 1 ? p(e, function(t, e) {
            return Po(e);
        }) : rg;
    }
    function Po(t) {
        return function(e, n) {
            var i = n.data, r = n.resetDefines[t];
            if (r && r.dataEach) for (var o = e.start; o < e.end; o++) r.dataEach(i, o); else r && r.progress && r.progress(e, i);
        };
    }
    function Lo(t) {
        return t.data.count();
    }
    function Oo(t, e, n) {
        var i = e.uid, r = t._pipelineMap.get(i);
        !r.head && (r.head = n), r.tail && r.tail.pipe(n), r.tail = n, n.__idxInPipeline = r.count++, 
        n.__pipeline = r;
    }
    function Eo(t) {
        og = null;
        try {
            t(ag, sg);
        } catch (t) {}
        return og;
    }
    function Bo(t, e) {
        for (var n in e.prototype) t[n] = R;
    }
    function zo(t) {
        w(t) && (t = new DOMParser().parseFromString(t, "text/xml"));
        for (9 === t.nodeType && (t = t.firstChild); "svg" !== t.nodeName.toLowerCase() || 1 !== t.nodeType; ) t = t.nextSibling;
        return t;
    }
    function No() {
        this._defs = {}, this._root = null, this._isDefine = !1, this._isText = !1;
    }
    function Ro(t, e) {
        t && t.__inheritedStyle && (e.__inheritedStyle || (e.__inheritedStyle = {}), s(e.__inheritedStyle, t.__inheritedStyle));
    }
    function Fo(t) {
        for (var e = O(t).split(gg), n = [], i = 0; i < e.length; i += 2) {
            var r = parseFloat(e[i]), o = parseFloat(e[i + 1]);
            n.push([ r, o ]);
        }
        return n;
    }
    function Vo(t, e, n, i) {
        var r = e.__inheritedStyle || {}, o = "text" === e.type;
        if (1 === t.nodeType && (function(t, e) {
            var n = t.getAttribute("transform");
            if (n) {
                n = n.replace(/,/g, " ");
                var i = null, r = [];
                n.replace(xg, function(t, e, n) {
                    r.push(e, n);
                });
                for (var o = r.length - 1; o > 0; o -= 2) {
                    var a = r[o], s = r[o - 1];
                    switch (i = i || mt(), s) {
                      case "translate":
                        a = O(a).split(gg), wt(i, i, [ parseFloat(a[0]), parseFloat(a[1] || 0) ]);
                        break;

                      case "scale":
                        a = O(a).split(gg), St(i, i, [ parseFloat(a[0]), parseFloat(a[1] || a[0]) ]);
                        break;

                      case "rotate":
                        a = O(a).split(gg), bt(i, i, parseFloat(a[0]));
                        break;

                      case "skew":
                        a = O(a).split(gg), console.warn("Skew transform is not supported yet");
                        break;

                      case "matrix":
                        a = O(a).split(gg);
                        i[0] = parseFloat(a[0]), i[1] = parseFloat(a[1]), i[2] = parseFloat(a[2]), i[3] = parseFloat(a[3]), 
                        i[4] = parseFloat(a[4]), i[5] = parseFloat(a[5]);
                    }
                }
                e.setLocalTransform(i);
            }
        }(t, e), a(r, function(t) {
            var e = t.getAttribute("style"), n = {};
            if (!e) return n;
            var i, r = {};
            for (wg.lastIndex = 0; null != (i = wg.exec(e)); ) r[i[1]] = i[2];
            for (var o in yg) yg.hasOwnProperty(o) && null != r[o] && (n[yg[o]] = r[o]);
            return n;
        }(t)), !i)) for (var s in yg) if (yg.hasOwnProperty(s)) {
            var l = t.getAttribute(s);
            null != l && (r[yg[s]] = l);
        }
        var h = o ? "textFill" : "fill", u = o ? "textStroke" : "stroke";
        e.style = e.style || new Yu();
        var c = e.style;
        null != r.fill && c.set(h, Ho(r.fill, n)), null != r.stroke && c.set(u, Ho(r.stroke, n)), 
        f([ "lineWidth", "opacity", "fillOpacity", "strokeOpacity", "miterLimit", "fontSize" ], function(t) {
            var e = "lineWidth" === t && o ? "textStrokeWidth" : t;
            null != r[t] && c.set(e, parseFloat(r[t]));
        }), r.textBaseline && "auto" !== r.textBaseline || (r.textBaseline = "alphabetic"), 
        "alphabetic" === r.textBaseline && (r.textBaseline = "bottom"), "start" === r.textAlign && (r.textAlign = "left"), 
        "end" === r.textAlign && (r.textAlign = "right"), f([ "lineDashOffset", "lineCap", "lineJoin", "fontWeight", "fontFamily", "fontStyle", "textAlign", "textBaseline" ], function(t) {
            null != r[t] && c.set(t, r[t]);
        }), r.lineDash && (e.style.lineDash = O(r.lineDash).split(gg)), c[u] && "none" !== c[u] && (e[u] = !0), 
        e.__inheritedStyle = r;
    }
    function Ho(t, e) {
        var n = e && t && t.match(_g);
        return n ? e[O(n[1])] : t;
    }
    function Go(t, e) {
        return function(n, i, r) {
            return !e && this._disposed ? void ia(this.id) : (n = n && n.toLowerCase(), void Yh.prototype[t].call(this, n, i, r));
        };
    }
    function Wo() {
        Yh.call(this);
    }
    function Xo(t, e, n) {
        function r(t, e) {
            return t.__prio - e.__prio;
        }
        n = n || {}, "string" == typeof e && (e = jg[e]), this.id, this.group, this._dom = t;
        var o = "canvas";
        wh && (o = ("undefined" == typeof window ? global : window).__ECHARTS__DEFAULT__RENDERER__ || o);
        var a = this._zr = cn(t, {
            renderer: n.renderer || o,
            devicePixelRatio: n.devicePixelRatio,
            width: n.width,
            height: n.height
        });
        this._throttledZrFlush = bo(m(a.flush, a), 17), (e = i(e)) && Pp(e, !0), this._theme = e, 
        this._chartsViews = [], this._chartsMap = {}, this._componentsViews = [], this._componentsMap = {}, 
        this._coordSysMgr = new Rr();
        var s = this._api = oa(this);
        he(qg, r), he(Xg, r), this._scheduler = new So(this, s, Xg, qg), Yh.call(this, this._ecEventProcessor = new aa()), 
        this._messageCenter = new Wo(), this._initEvents(), this.resize = m(this.resize, this), 
        this._pendingActions = [], a.animation.on("frame", this._onframe, this), function(t, e) {
            t.on("rendered", function() {
                e.trigger("rendered"), !t.animation.isFinished() || e[Ng] || e._scheduler.unfinished || e._pendingActions.length || e.trigger("finished");
            });
        }(a, this), E(this);
    }
    function Uo(t, e, n) {
        if (this._disposed) ia(this.id); else {
            var i, r = this._model, o = this._coordSysMgr.getCoordinateSystems();
            e = xn(r, e);
            for (var a = 0; a < o.length; a++) {
                var s = o[a];
                if (s[t] && null != (i = s[t](r, e, n))) return i;
            }
            wh && console.warn("No coordinate system that supports " + t + " found by the given finder.");
        }
    }
    function Yo(t) {
        var e = t._model, n = t._scheduler;
        n.restorePipelines(e), n.prepareStageTasks(), Qo(t, "component", e, n), Qo(t, "chart", e, n), 
        n.plan();
    }
    function qo(t, e, n, i, r) {
        function o(i) {
            i && i.__alive && i[e] && i[e](i.__model, a, t._api, n);
        }
        var a = t._model;
        if (i) {
            var s = {};
            s[i + "Id"] = n[i + "Id"], s[i + "Index"] = n[i + "Index"], s[i + "Name"] = n[i + "Name"];
            var l = {
                mainType: i,
                query: s
            };
            r && (l.subType = r);
            var h = n.excludeSeriesId;
            null != h && (h = N(dn(h))), a && a.eachComponent(l, function(e) {
                h && null != h.get(e.id) || o(t["series" === i ? "_chartsMap" : "_componentsMap"][e.__viewId]);
            }, t);
        } else Tg(t._componentsViews.concat(t._chartsViews), o);
    }
    function jo(t, e) {
        var n = t._chartsMap, i = t._scheduler;
        e.eachSeries(function(t) {
            i.updateStreamModes(t, n[t.__viewId]);
        });
    }
    function Zo(t, e) {
        var n = t.type, i = t.escapeConnect, r = Gg[n], o = r.actionInfo, l = (o.update || "update").split(":"), h = l.pop();
        l = null != l[0] && Dg(l[0]), this[zg] = !0;
        var u = [ t ], c = !1;
        t.batch && (c = !0, u = p(t.batch, function(e) {
            return (e = s(a({}, e), t)).batch = null, e;
        }));
        var d, f = [], g = "highlight" === n || "downplay" === n;
        Tg(u, function(t) {
            (d = (d = r.action(t, this._model, this._api)) || a({}, t)).type = o.event || d.type, 
            f.push(d), g ? qo(this, h, t, "series") : l && qo(this, h, t, l.main, l.sub);
        }, this), "none" === h || g || l || (this[Ng] ? (Yo(this), Vg.update.call(this, t), 
        this[Ng] = !1) : Vg[h].call(this, t)), d = c ? {
            type: o.event || n,
            escapeConnect: i,
            batch: f
        } : f[0], this[zg] = !1, !e && this._messageCenter.trigger(d.type, d);
    }
    function Ko(t) {
        for (var e = this._pendingActions; e.length; ) {
            var n = e.shift();
            Zo.call(this, n, t);
        }
    }
    function $o(t) {
        !t && this.trigger("updated");
    }
    function Qo(t, e, n, i) {
        function r(t) {
            var e = "_ec_" + t.id + "_" + t.type, r = s[e];
            if (!r) {
                var u = Dg(t.type), c = o ? Gp.getClass(u.main, u.sub) : mo.getClass(u.sub);
                wh && Ig(c, u.sub + " does not exist."), (r = new c()).init(n, h), s[e] = r, a.push(r), 
                l.add(r.group);
            }
            t.__viewId = r.__id = e, r.__alive = !0, r.__model = t, r.group.__ecComponentInfo = {
                mainType: t.mainType,
                index: t.componentIndex
            }, !o && i.prepareView(r, t, n, h);
        }
        for (var o = "component" === e, a = o ? t._componentsViews : t._chartsViews, s = o ? t._componentsMap : t._chartsMap, l = t._zr, h = t._api, u = 0; u < a.length; u++) a[u].__alive = !1;
        o ? n.eachComponent(function(t, e) {
            "series" !== t && r(e);
        }) : n.eachSeries(r);
        for (u = 0; u < a.length; ) {
            var c = a[u];
            c.__alive ? u++ : (!o && c.renderTask.dispose(), l.remove(c.group), c.dispose(n, h), 
            a.splice(u, 1), delete s[c.__id], c.__id = c.group.__ecComponentInfo = null);
        }
    }
    function Jo(t) {
        t.clearColorPalette(), t.eachSeries(function(t) {
            t.clearColorPalette();
        });
    }
    function ta(t, e, n, i) {
        (function(t, e, n, i, r) {
            Tg(r || t._componentsViews, function(t) {
                var r = t.__model;
                t.render(r, e, n, i), ra(r, t);
            });
        })(t, e, n, i), Tg(t._chartsViews, function(t) {
            t.__alive = !1;
        }), ea(t, e, n, i), Tg(t._chartsViews, function(t) {
            t.__alive || t.remove(e, n);
        });
    }
    function ea(t, e, n, i, r) {
        var o, a = t._scheduler;
        e.eachSeries(function(e) {
            var n = t._chartsMap[e.__viewId];
            n.__alive = !0;
            var s = n.renderTask;
            a.updatePayload(s, i), r && r.get(e.uid) && s.dirty(), o |= s.perform(a.getPerformArgs(s)), 
            n.group.silent = !!e.get("silent"), ra(e, n), function(t, e) {
                var n = t.get("blendMode") || null;
                wh && !Mh.canvasSupported && n && "source-over" !== n && console.warn("Only canvas support blendMode"), 
                e.group.traverse(function(t) {
                    t.isGroup || t.style.blend !== n && t.setStyle("blend", n), t.eachPendingDisplayable && t.eachPendingDisplayable(function(t) {
                        t.setStyle("blend", n);
                    });
                });
            }(e, n);
        }), a.unfinished |= o, function(t, e) {
            var n = t._zr.storage, i = 0;
            n.traverse(function() {
                i++;
            }), i > e.get("hoverLayerThreshold") && !Mh.node && e.eachSeries(function(e) {
                if (!e.preventUsingHoverLayer) {
                    var n = t._chartsMap[e.__viewId];
                    n.__alive && n.group.traverse(function(t) {
                        t.useHoverLayer = !0;
                    });
                }
            });
        }(t, e), tg(t._zr.dom, e);
    }
    function na(t, e) {
        Tg(Yg, function(n) {
            n(t, e);
        });
    }
    function ia(t) {
        wh && console.warn("Instance " + t + " has been disposed");
    }
    function ra(t, e) {
        var n = t.get("z"), i = t.get("zlevel");
        e.group.traverse(function(t) {
            "group" !== t.type && (null != n && (t.z = n), null != i && (t.zlevel = i));
        });
    }
    function oa(t) {
        var e = t._coordSysMgr;
        return a(new Nr(t), {
            getCoordinateSystems: m(e.getCoordinateSystems, e),
            getComponentByElement: function(e) {
                for (;e; ) {
                    var n = e.__ecComponentInfo;
                    if (null != n) return t._model.getComponent(n.mainType, n.index);
                    e = e.parent;
                }
            }
        });
    }
    function aa() {
        this.eventInfo;
    }
    function sa(t) {
        $g[t] = !1;
    }
    function la(t) {
        return Kg[function(t, e) {
            return t.getAttribute ? t.getAttribute(e) : t[e];
        }(t, tv)];
    }
    function ha(t, e) {
        jg[t] = e;
    }
    function ua(t) {
        Ug.push(t);
    }
    function ca(t, e) {
        ga(Xg, t, e, Lg);
    }
    function da(t, e, n) {
        "function" == typeof e && (n = e, e = "");
        var i = Ag(t) ? t.type : [ t, t = {
            event: e
        } ][0];
        t.event = (t.event || i).toLowerCase(), e = t.event, Ig(Rg.test(i) && Rg.test(e)), 
        Gg[i] || (Gg[i] = {
            action: n,
            actionInfo: t
        }), Wg[e] = i;
    }
    function fa(t, e) {
        ga(qg, t, e, Og, "layout");
    }
    function pa(t, e) {
        ga(qg, t, e, Eg, "visual");
    }
    function ga(t, e, n, i, r) {
        if ((Cg(e) || Ag(e)) && (n = e, e = i), wh) {
            if (isNaN(e) || null == e) throw new Error("Illegal priority");
            Tg(t, function(t) {
                Ig(t.__raw !== n);
            });
        }
        var o = So.wrapStageHandler(n, r);
        return o.__prio = e, o.__raw = n, t.push(o), o;
    }
    function va(t, e) {
        Zg[t] = e;
    }
    function ma(t) {
        return ep.extend(t);
    }
    function ya(t) {
        return Gp.extend(t);
    }
    function _a(t) {
        return Hp.extend(t);
    }
    function xa(t) {
        return mo.extend(t);
    }
    function wa(t) {
        return t;
    }
    function ba(t, e, n, i, r) {
        this._old = t, this._new = e, this._oldKeyGetter = n || wa, this._newKeyGetter = i || wa, 
        this.context = r;
    }
    function Sa(t, e, n, i, r) {
        for (var o = 0; o < t.length; o++) {
            var a = "_ec_" + r[i](t[o], o), s = e[a];
            null == s ? (n.push(a), e[a] = o) : (s.length || (e[a] = s = [ s ]), s.push(o));
        }
    }
    function Ma(t, e) {
        return t.hasOwnProperty(e) || (t[e] = []), t[e];
    }
    function Ia(t) {
        null != t && a(this, t), this.otherDims = {};
    }
    function Ta(t) {
        return t._rawCount > 65535 ? lv : uv;
    }
    function Ca(t) {
        var e = t.constructor;
        return e === Array ? t.slice() : new e(t);
    }
    function Aa(t, e) {
        f(cv.concat(e.__wrappedMethods || []), function(n) {
            e.hasOwnProperty(n) && (t[n] = e[n]);
        }), t.__wrappedMethods = e.__wrappedMethods, f(dv, function(n) {
            t[n] = i(e[n]);
        }), t._calculationInfo = a(e._calculationInfo);
    }
    function Da(t, e, n, i, r) {
        var o = sv[e.type], a = i - 1, s = e.name, l = t[s][a];
        if (l && l.length < n) {
            for (var h = new o(Math.min(r - a * n, n)), u = 0; u < l.length; u++) h[u] = l[u];
            t[s][a] = h;
        }
        for (var c = i * n; r > c; c += n) t[s].push(new o(Math.min(r - c, n)));
    }
    function ka(t) {
        var e = t._invertedIndicesMap;
        f(e, function(n, i) {
            var r = t._dimensionInfos[i].ordinalMeta;
            if (r) {
                n = e[i] = new hv(r.categories.length);
                for (var o = 0; o < n.length; o++) n[o] = ov;
                for (o = 0; o < t._count; o++) n[t.get(i, o)] = o;
            }
        });
    }
    function Pa(t, e, n) {
        var i;
        if (null != e) {
            var r = t._chunkSize, o = Math.floor(n / r), a = n % r, s = t.dimensions[e], l = t._storage[s][o];
            if (l) {
                i = l[a];
                var h = t._dimensionInfos[s].ordinalMeta;
                h && h.categories.length && (i = h.categories[i]);
            }
        }
        return i;
    }
    function La(t) {
        return t;
    }
    function Oa(t) {
        return t < this._count && t >= 0 ? this._indices[t] : -1;
    }
    function Ea(t, e) {
        var n = t._idList[e];
        return null == n && (n = Pa(t, t._idDimIdx, e)), null == n && (n = av + e), n;
    }
    function Ba(t) {
        return _(t) || (t = [ t ]), t;
    }
    function za(t, e) {
        for (var n = 0; n < e.length; n++) t._dimensionInfos[e[n]] || console.error("Unkown dimension " + e[n]);
    }
    function Na(t, e) {
        var n = t.dimensions, i = new fv(p(n, t.getDimensionInfo, t), t.hostModel);
        Aa(i, t);
        for (var r = i._storage = {}, o = t._storage, a = 0; a < n.length; a++) {
            var s = n[a];
            o[s] && (h(e, s) >= 0 ? (r[s] = Ra(o[s]), i._rawExtent[s] = [ 1 / 0, -1 / 0 ], i._extent[s] = null) : r[s] = o[s]);
        }
        return i;
    }
    function Ra(t) {
        for (var e = new Array(t.length), n = 0; n < t.length; n++) e[n] = Ca(t[n]);
        return e;
    }
    function Fa(t, e, n) {
        function r(t, e, n) {
            null != nv.get(e) ? t.otherDims[e] = n : (t.coordDim = e, t.coordDimIndex = n, h.set(e, !0));
        }
        Mr.isInstance(e) || (e = Mr.seriesDataToSource(e)), n = n || {}, t = (t || []).slice();
        for (var o = (n.dimsDef || []).slice(), l = N(), h = N(), u = [], c = function(t, e, n, i) {
            var r = Math.max(t.dimensionsDetectCount || 1, e.length, n.length, i || 0);
            return f(e, function(t) {
                var e = t.dimsDef;
                e && (r = Math.max(r, e.length));
            }), r;
        }(e, t, o, n.dimCount), d = 0; c > d; d++) {
            var p = o[d] = a({}, b(o[d]) ? o[d] : {
                name: o[d]
            }), g = p.name, v = u[d] = new Ia();
            null != g && null == l.get(g) && (v.name = v.displayName = g, l.set(g, d)), null != p.type && (v.type = p.type), 
            null != p.displayName && (v.displayName = p.displayName);
        }
        var m = n.encodeDef;
        !m && n.encodeDefaulter && (m = n.encodeDefaulter(e, c)), (m = N(m)).each(function(t, e) {
            if (1 === (t = dn(t).slice()).length && !w(t[0]) && t[0] < 0) m.set(e, !1); else {
                var n = m.set(e, []);
                f(t, function(t, i) {
                    w(t) && (t = l.get(t)), null != t && c > t && (n[i] = t, r(u[t], e, i));
                });
            }
        });
        var y = 0;
        f(t, function(t) {
            var e, n, o;
            if (w(t)) e = t, t = {}; else {
                e = t.name;
                var a = t.ordinalMeta;
                t.ordinalMeta = null, (t = i(t)).ordinalMeta = a, n = t.dimsDef, o = t.otherDims, 
                t.name = t.coordDim = t.coordDimIndex = t.dimsDef = t.otherDims = null;
            }
            if (!1 !== (l = m.get(e))) {
                var l;
                if (!(l = dn(l)).length) for (var h = 0; h < (n && n.length || 1); h++) {
                    for (;y < u.length && null != u[y].coordDim; ) y++;
                    y < u.length && l.push(y++);
                }
                f(l, function(i, a) {
                    var l = u[i];
                    if (r(s(l, t), e, a), null == l.name && n) {
                        var h = n[a];
                        !b(h) && (h = {
                            name: h
                        }), l.name = l.displayName = h.name, l.defaultTooltip = h.defaultTooltip;
                    }
                    o && s(l.otherDims, o);
                });
            }
        });
        var _ = n.generateCoord, x = n.generateCoordCount, S = null != x;
        x = _ ? x || 1 : 0;
        for (var M = _ || "value", I = 0; c > I; I++) {
            null == (v = u[I] = u[I] || new Ia()).coordDim && (v.coordDim = Va(M, h, S), v.coordDimIndex = 0, 
            (!_ || 0 >= x) && (v.isExtraCoord = !0), x--), null == v.name && (v.name = Va(v.coordDim, l)), 
            null != v.type || Pr(e, I, v.name) !== pp.Must && (!v.isExtraCoord || null == v.otherDims.itemName && null == v.otherDims.seriesName) || (v.type = "ordinal");
        }
        return u;
    }
    function Va(t, e, n) {
        if (n || null != e.get(t)) {
            for (var i = 0; null != e.get(t + i); ) i++;
            t += i;
        }
        return e.set(t, !0), t;
    }
    function Ha(t) {
        this.coordSysName = t, this.coordSysDims = [], this.axisMap = N(), this.categoryAxisMap = N(), 
        this.firstCategoryDimIndex = null;
    }
    function Ga(t) {
        return "category" === t.get("type");
    }
    function Wa(t, e, n) {
        var i, r, o, a, s = (n = n || {}).byIndex, l = n.stackedCoordDimension, h = !(!t || !t.get("stack"));
        if (f(e, function(t, n) {
            w(t) && (e[n] = t = {
                name: t
            }), h && !t.isExtraCoord && (s || i || !t.ordinalMeta || (i = t), r || "ordinal" === t.type || "time" === t.type || l && l !== t.coordDim || (r = t));
        }), !r || s || i || (s = !0), r) {
            o = "__\0ecstackresult", a = "__\0ecstackedover", i && (i.createInvertedIndices = !0);
            var u = r.coordDim, c = r.type, d = 0;
            f(e, function(t) {
                t.coordDim === u && d++;
            }), e.push({
                name: o,
                coordDim: u,
                coordDimIndex: d,
                type: c,
                isExtraCoord: !0,
                isCalculationCoord: !0
            }), d++, e.push({
                name: a,
                coordDim: a,
                coordDimIndex: d,
                type: c,
                isExtraCoord: !0,
                isCalculationCoord: !0
            });
        }
        return {
            stackedDimension: r && r.name,
            stackedByDimension: i && i.name,
            isStackedByIndex: s,
            stackedOverDimension: a,
            stackResultDimension: o
        };
    }
    function Xa(t, e) {
        return !!e && e === t.getCalculationInfo("stackedDimension");
    }
    function Ua(t, e) {
        return Xa(t, e) ? t.getCalculationInfo("stackResultDimension") : e;
    }
    function Ya(t, e, n) {
        n = n || {}, Mr.isInstance(t) || (t = Mr.seriesDataToSource(t));
        var i, r = e.get("coordinateSystem"), o = Rr.get(r), a = function(t) {
            var e = t.get("coordinateSystem"), n = new Ha(e), i = mv[e];
            return i ? (i(t, n, n.axisMap, n.categoryAxisMap), n) : void 0;
        }(e);
        a && (i = p(a.coordSysDims, function(t) {
            var e = {
                name: t
            }, n = a.axisMap.get(t);
            if (n) {
                var i = n.get("type");
                e.type = function(t) {
                    return "category" === t ? "ordinal" : "time" === t ? "time" : "float";
                }(i);
            }
            return e;
        })), i || (i = o && (o.getDimensionsInfo ? o.getDimensionsInfo() : o.dimensions.slice()) || [ "x", "y" ]);
        var s, l, h = vv(t, {
            coordDimensions: i,
            generateCoord: n.generateCoord,
            encodeDefaulter: n.useEncodeDefaulter ? y(Ar, i, e) : null
        });
        a && f(h, function(t, e) {
            var n = t.coordDim, i = a.categoryAxisMap.get(n);
            i && (null == s && (s = e), t.ordinalMeta = i.getOrdinalMeta()), null != t.otherDims.itemName && (l = !0);
        }), l || null == s || (h[s].otherDims.itemName = 0);
        var u = Wa(e, h), c = new fv(h, e);
        c.setCalculationInfo(u);
        var d = null != s && function(t) {
            if (t.sourceFormat === ap) {
                var e = function(t) {
                    for (var e = 0; e < t.length && null == t[e]; ) e++;
                    return t[e];
                }(t.data || []);
                return null != e && !_(pn(e));
            }
        }(t) ? function(t, e, n, i) {
            return i === s ? n : this.defaultDimValueGetter(t, e, n, i);
        } : null;
        return c.hasItemOption = !1, c.initData(t, null, d), c;
    }
    function qa(t) {
        this._setting = t || {}, this._extent = [ 1 / 0, -1 / 0 ], this._interval = 0, this.init && this.init.apply(this, arguments);
    }
    function ja(t) {
        this.categories = t.categories || [], this._needCollect = t.needCollect, this._deduplication = t.deduplication, 
        this._map;
    }
    function Za(t) {
        return t._map || (t._map = N(t.categories));
    }
    function Ka(t) {
        return b(t) && null != t.value ? t.value : t + "";
    }
    function $a(t) {
        return ir(t) + 2;
    }
    function Qa(t, e, n) {
        t[e] = Math.max(Math.min(t[e], n[1]), n[0]);
    }
    function Ja(t, e) {
        !isFinite(t[0]) && (t[0] = e[0]), !isFinite(t[1]) && (t[1] = e[1]), Qa(t, 0, e), 
        Qa(t, 1, e), t[0] > t[1] && (t[0] = t[1]);
    }
    function ts(t) {
        return t.get("stack") || Mv + t.seriesIndex;
    }
    function es(t) {
        return t.dim + t.index;
    }
    function ns(t, e) {
        var n = [];
        return e.eachSeriesByType(t, function(t) {
            os(t) && !as(t) && n.push(t);
        }), n;
    }
    function is(t) {
        var e = function(t) {
            var e = {};
            f(t, function(t) {
                var n = t.coordinateSystem.getBaseAxis();
                if ("time" === n.type || "value" === n.type) for (var i = t.getData(), r = n.dim + "_" + n.index, o = i.mapDimension(n.dim), a = 0, s = i.count(); s > a; ++a) {
                    var l = i.get(o, a);
                    e[r] ? e[r].push(l) : e[r] = [ l ];
                }
            });
            var n = [];
            for (var i in e) if (e.hasOwnProperty(i)) {
                var r = e[i];
                if (r) {
                    r.sort(function(t, e) {
                        return t - e;
                    });
                    for (var o = null, a = 1; a < r.length; ++a) {
                        var s = r[a] - r[a - 1];
                        s > 0 && (o = null === o ? s : Math.min(o, s));
                    }
                    n[i] = o;
                }
            }
            return n;
        }(t), n = [];
        return f(t, function(t) {
            var i, r = t.coordinateSystem.getBaseAxis(), o = r.getExtent();
            if ("category" === r.type) i = r.getBandWidth(); else if ("value" === r.type || "time" === r.type) {
                var a = r.dim + "_" + r.index, s = e[a], l = Math.abs(o[1] - o[0]), h = r.scale.getExtent(), u = Math.abs(h[1] - h[0]);
                i = s ? l / u * s : l;
            } else {
                var c = t.getData();
                i = Math.abs(o[1] - o[0]) / c.count();
            }
            var d = er(t.get("barWidth"), i), f = er(t.get("barMaxWidth"), i), p = er(t.get("barMinWidth") || 1, i), g = t.get("barGap"), v = t.get("barCategoryGap");
            n.push({
                bandWidth: i,
                barWidth: d,
                barMaxWidth: f,
                barMinWidth: p,
                barGap: g,
                barCategoryGap: v,
                axisKey: es(r),
                stackId: ts(t)
            });
        }), function(t) {
            var e = {};
            f(t, function(t) {
                var n = t.axisKey, i = t.bandWidth, r = e[n] || {
                    bandWidth: i,
                    remainedWidth: i,
                    autoWidthCount: 0,
                    categoryGap: "20%",
                    gap: "30%",
                    stacks: {}
                }, o = r.stacks;
                e[n] = r;
                var a = t.stackId;
                o[a] || r.autoWidthCount++, o[a] = o[a] || {
                    width: 0,
                    maxWidth: 0
                };
                var s = t.barWidth;
                s && !o[a].width && (o[a].width = s, s = Math.min(r.remainedWidth, s), r.remainedWidth -= s);
                var l = t.barMaxWidth;
                l && (o[a].maxWidth = l);
                var h = t.barMinWidth;
                h && (o[a].minWidth = h);
                var u = t.barGap;
                null != u && (r.gap = u);
                var c = t.barCategoryGap;
                null != c && (r.categoryGap = c);
            });
            var n = {};
            return f(e, function(t, e) {
                n[e] = {};
                var i = t.stacks, r = t.bandWidth, o = er(t.categoryGap, r), a = er(t.gap, 1), s = t.remainedWidth, l = t.autoWidthCount, h = (s - o) / (l + (l - 1) * a);
                h = Math.max(h, 0), f(i, function(t) {
                    var e = t.maxWidth, n = t.minWidth;
                    if (t.width) {
                        var i = t.width;
                        e && (i = Math.min(i, e)), n && (i = Math.max(i, n)), t.width = i, s -= i + a * i, 
                        l--;
                    } else {
                        i = h;
                        e && i > e && (i = Math.min(e, s)), n && n > i && (i = n), i !== h && (t.width = i, 
                        s -= i + a * i, l--);
                    }
                }), h = (s - o) / (l + (l - 1) * a), h = Math.max(h, 0);
                var u, c = 0;
                f(i, function(t) {
                    t.width || (t.width = h), u = t, c += t.width * (1 + a);
                }), u && (c -= u.width * a);
                var d = -c / 2;
                f(i, function(t, i) {
                    n[e][i] = n[e][i] || {
                        bandWidth: r,
                        offset: d,
                        width: t.width
                    }, d += t.width * (1 + a);
                });
            }), n;
        }(n);
    }
    function rs(t, e, n) {
        if (t && e) {
            var i = t[es(e)];
            return null != i && null != n && (i = i[ts(n)]), i;
        }
    }
    function os(t) {
        return t.coordinateSystem && "cartesian2d" === t.coordinateSystem.type;
    }
    function as(t) {
        return t.pipelineContext && t.pipelineContext.large;
    }
    function ss(t, e) {
        return e.toGlobalCoord(e.dataToCoord("log" === e.type ? 1 : 0));
    }
    function ls(t, e) {
        return Fv(t, Rv(e));
    }
    function hs(t, e) {
        var n, i, r, o = t.type, a = e.getMin(), s = e.getMax(), l = t.getExtent();
        "ordinal" === o ? n = e.getCategories().length : (_(i = e.get("boundaryGap")) || (i = [ i || 0, i || 0 ]), 
        "boolean" == typeof i[0] && (wh && console.warn('Boolean type for boundaryGap is only allowed for ordinal axis. Please use string in percentage instead, e.g., "20%". Currently, boundaryGap is set to be 0.'), 
        i = [ 0, 0 ]), i[0] = er(i[0], 1), i[1] = er(i[1], 1), r = l[1] - l[0] || Math.abs(l[0])), 
        "dataMin" === a ? a = l[0] : "function" == typeof a && (a = a({
            min: l[0],
            max: l[1]
        })), "dataMax" === s ? s = l[1] : "function" == typeof s && (s = s({
            min: l[0],
            max: l[1]
        }));
        var h = null != a, u = null != s;
        null == a && (a = "ordinal" === o ? n ? 0 : NaN : l[0] - i[0] * r), null == s && (s = "ordinal" === o ? n ? n - 1 : NaN : l[1] + i[1] * r), 
        (null == a || !isFinite(a)) && (a = NaN), (null == s || !isFinite(s)) && (s = NaN), 
        t.setBlank(T(a) || T(s) || "ordinal" === o && !t.getOrdinalMeta().categories.length), 
        e.getNeedCrossZero() && (a > 0 && s > 0 && !h && (a = 0), 0 > a && 0 > s && !u && (s = 0));
        var c = e.ecModel;
        if (c && "time" === o) {
            var d, p = ns("bar", c);
            if (f(p, function(t) {
                d |= t.getBaseAxis() === e.axis;
            }), d) {
                var g = is(p), v = function(t, e, n, i) {
                    var r = n.axis.getExtent(), o = r[1] - r[0], a = rs(i, n.axis);
                    if (void 0 === a) return {
                        min: t,
                        max: e
                    };
                    var s = 1 / 0;
                    f(a, function(t) {
                        s = Math.min(t.offset, s);
                    });
                    var l = -1 / 0;
                    f(a, function(t) {
                        l = Math.max(t.offset + t.width, l);
                    }), s = Math.abs(s), l = Math.abs(l);
                    var h = s + l, u = e - t, c = u / (1 - (s + l) / o) - u;
                    return {
                        min: t -= c * (s / h),
                        max: e += c * (l / h)
                    };
                }(a, s, e, g);
                a = v.min, s = v.max;
            }
        }
        return {
            extent: [ a, s ],
            fixMin: h,
            fixMax: u
        };
    }
    function us(t, e) {
        var n = hs(t, e), i = n.extent, r = e.get("splitNumber");
        "log" === t.type && (t.base = e.get("logBase"));
        var o = t.type;
        t.setExtent(i[0], i[1]), t.niceExtent({
            splitNumber: r,
            fixMin: n.fixMin,
            fixMax: n.fixMax,
            minInterval: "interval" === o || "time" === o ? e.get("minInterval") : null,
            maxInterval: "interval" === o || "time" === o ? e.get("maxInterval") : null
        });
        var a = e.get("interval");
        null != a && t.setInterval && t.setInterval(a);
    }
    function cs(t, e) {
        if (e = e || t.get("type")) switch (e) {
          case "category":
            return new xv(t.getOrdinalMeta ? t.getOrdinalMeta() : t.getCategories(), [ 1 / 0, -1 / 0 ]);

          case "value":
            return new Sv();

          default:
            return (qa.getClass(e) || Sv).create(t);
        }
    }
    function ds(t) {
        var e = t.getLabelModel().get("formatter"), n = "category" === t.type ? t.scale.getExtent()[0] : null;
        return "string" == typeof e ? e = function(e) {
            return function(n) {
                return n = t.scale.getLabel(n), e.replace("{value}", null != n ? n : "");
            };
        }(e) : "function" == typeof e ? function(i, r) {
            return null != n && (r = i - n), e(fs(t, i), r);
        } : function(e) {
            return t.scale.getLabel(e);
        };
    }
    function fs(t, e) {
        return "category" === t.type ? t.scale.getLabel(e) : e;
    }
    function ps(t, e) {
        var n = e * Math.PI / 180, i = t.plain(), r = i.width, o = i.height, a = r * Math.abs(Math.cos(n)) + Math.abs(o * Math.sin(n)), s = r * Math.abs(Math.sin(n)) + Math.abs(o * Math.cos(n));
        return new ie(i.x, i.y, a, s);
    }
    function gs(t) {
        var e = t.get("interval");
        return null == e ? "auto" : e;
    }
    function vs(t) {
        return "category" === t.type && 0 === gs(t.getLabelModel());
    }
    function ms(t, e) {
        if ("image" !== this.type) {
            var n = this.style, i = this.shape;
            i && "line" === i.symbolType ? n.stroke = t : this.__isEmptyBrush ? (n.stroke = t, 
            n.fill = e || "#fff") : (n.fill && (n.fill = t), n.stroke && (n.stroke = t)), this.dirty(!1);
        }
    }
    function ys(t, e, n, i, r, o, a) {
        var s, l = 0 === t.indexOf("empty");
        return l && (t = t.substr(5, 1).toLowerCase() + t.substr(6)), (s = 0 === t.indexOf("image://") ? vi(t.slice(8), new ie(e, n, i, r), a ? "center" : "cover") : 0 === t.indexOf("path://") ? gi(t.slice(7), {}, new ie(e, n, i, r), a ? "center" : "cover") : new Qv({
            shape: {
                symbolType: t,
                x: e,
                y: n,
                width: i,
                height: r
            }
        })).__isEmptyBrush = l, s.setColor = ms, s.setColor(o), s;
    }
    function _s(t, e) {
        return Math.abs(t - e) < em;
    }
    function xs(t, e, n) {
        var i = 0, r = t[0];
        if (!r) return !1;
        for (var o = 1; o < t.length; o++) {
            var a = t[o];
            i += Kn(r[0], r[1], a[0], a[1], e, n), r = a;
        }
        var s = t[0];
        return _s(r[0], s[0]) && _s(r[1], s[1]) || (i += Kn(r[0], r[1], s[0], s[1], e, n)), 
        0 !== i;
    }
    function ws(t, e, n) {
        if (this.name = t, this.geometries = e, n) n = [ n[0], n[1] ]; else {
            var i = this.getBoundingRect();
            n = [ i.x + i.width / 2, i.y + i.height / 2 ];
        }
        this.center = n;
    }
    function bs(t, e, n) {
        for (var i = [], r = e[0], o = e[1], a = 0; a < t.length; a += 2) {
            var s = t.charCodeAt(a) - 64, l = t.charCodeAt(a + 1) - 64;
            s = s >> 1 ^ -(1 & s), l = l >> 1 ^ -(1 & l), r = s += r, o = l += o, i.push([ s / n, l / n ]);
        }
        return i;
    }
    function Ss(t) {
        return "category" === t.type ? function(t) {
            var e = t.getLabelModel(), n = Is(t, e);
            return !e.get("show") || t.scale.isBlank() ? {
                labels: [],
                labelCategoryInterval: n.labelCategoryInterval
            } : n;
        }(t) : function(t) {
            var e = t.scale.getTicks(), n = ds(t);
            return {
                labels: p(e, function(e, i) {
                    return {
                        formattedLabel: n(e, i),
                        rawLabel: t.scale.getLabel(e),
                        tickValue: e
                    };
                })
            };
        }(t);
    }
    function Ms(t, e) {
        return "category" === t.type ? function(t, e) {
            var n, i, r = Ts(t, "ticks"), o = gs(e), a = Cs(r, o);
            if (a) return a;
            if ((!e.get("show") || t.scale.isBlank()) && (n = []), x(o)) n = ks(t, o, !0); else if ("auto" === o) {
                var s = Is(t, t.getLabelModel());
                i = s.labelCategoryInterval, n = p(s.labels, function(t) {
                    return t.tickValue;
                });
            } else n = Ds(t, i = o, !0);
            return As(r, o, {
                ticks: n,
                tickCategoryInterval: i
            });
        }(t, e) : {
            ticks: t.scale.getTicks()
        };
    }
    function Is(t, e) {
        var n, i, r = Ts(t, "labels"), o = gs(e), a = Cs(r, o);
        return a || (x(o) ? n = ks(t, o) : (i = "auto" === o ? function(t) {
            var e = im(t).autoInterval;
            return null != e ? e : im(t).autoInterval = t.calculateCategoryInterval();
        }(t) : o, n = Ds(t, i)), As(r, o, {
            labels: n,
            labelCategoryInterval: i
        }));
    }
    function Ts(t, e) {
        return im(t)[e] || (im(t)[e] = []);
    }
    function Cs(t, e) {
        for (var n = 0; n < t.length; n++) if (t[n].key === e) return t[n].value;
    }
    function As(t, e, n) {
        return t.push({
            key: e,
            value: n
        }), n;
    }
    function Ds(t, e, n) {
        function i(t) {
            l.push(n ? t : {
                formattedLabel: r(t),
                rawLabel: o.getLabel(t),
                tickValue: t
            });
        }
        var r = ds(t), o = t.scale, a = o.getExtent(), s = t.getLabelModel(), l = [], h = Math.max((e || 0) + 1, 1), u = a[0], c = o.count();
        0 !== u && h > 1 && c / h > 2 && (u = Math.round(Math.ceil(u / h) * h));
        var d = vs(t), f = s.get("showMinLabel") || d, p = s.get("showMaxLabel") || d;
        f && u !== a[0] && i(a[0]);
        for (var g = u; g <= a[1]; g += h) i(g);
        return p && g - h !== a[1] && i(a[1]), l;
    }
    function ks(t, e, n) {
        var i = t.scale, r = ds(t), o = [];
        return f(i.getTicks(), function(t) {
            var a = i.getLabel(t);
            e(t, a) && o.push(n ? t : {
                formattedLabel: r(t),
                rawLabel: a,
                tickValue: t
            });
        }), o;
    }
    function Ps(t, e) {
        var n = (t[1] - t[0]) / e / 2;
        t[0] += n, t[1] -= n;
    }
    function Ls(t) {
        return this._axes[t];
    }
    function Os(t) {
        hm.call(this, t);
    }
    function Es(t, e) {
        return e.type || (e.data ? "category" : "value");
    }
    function Bs(t, e) {
        return t.getCoordSysModel() === e;
    }
    function zs(t, e, n) {
        this._coordsMap = {}, this._coordsList = [], this._axesMap = {}, this._axesList = [], 
        this._initCartesian(t, e, n), this.model = t;
    }
    function Ns(t, e, n, i) {
        function r(t) {
            return t.dim + "_" + t.index;
        }
        n.getAxesOnZeroOf = function() {
            return o ? [ o ] : [];
        };
        var o, a = t[e], s = n.model, l = s.get("axisLine.onZero"), h = s.get("axisLine.onZeroAxisIndex");
        if (l) {
            if (null != h) Rs(a[h]) && (o = a[h]); else for (var u in a) if (a.hasOwnProperty(u) && Rs(a[u]) && !i[r(a[u])]) {
                o = a[u];
                break;
            }
            o && (i[r(o)] = !0);
        }
    }
    function Rs(t) {
        return t && "category" !== t.type && "time" !== t.type && function(t) {
            var e = t.scale.getExtent(), n = e[0], i = e[1];
            return !(n > 0 && i > 0 || 0 > n && 0 > i);
        }(t);
    }
    function Fs(t) {
        return p(ym, function(e) {
            var n = t.getReferringComponents(e)[0];
            if (wh && !n) throw new Error(e + ' "' + C(t.get(e + "Index"), t.get(e + "Id"), 0) + '" not found');
            return n;
        });
    }
    function Vs(t) {
        return "cartesian2d" === t.get("coordinateSystem");
    }
    function Hs(t, e) {
        var n = t.mapDimension("defaultedLabel", !0), i = n.length;
        if (1 === i) return ro(t, e, n[0]);
        if (i) {
            for (var r = [], o = 0; o < n.length; o++) {
                var a = ro(t, e, n[o]);
                r.push(a);
            }
            return r.join(" ");
        }
    }
    function Gs(t, e) {
        "outside" === t.textPosition && (t.textPosition = e);
    }
    function Ws(t, e, n) {
        var i = t.getArea(), r = t.getBaseAxis().isHorizontal(), o = i.x, a = i.y, s = i.width, l = i.height, h = n.get("lineStyle.width") || 2;
        o -= h / 2, a -= h / 2, s += h, l += h, o = Math.floor(o), s = Math.round(s);
        var u = new sf({
            shape: {
                x: o,
                y: a,
                width: s,
                height: l
            }
        });
        return e && (u.shape[r ? "width" : "height"] = 0, Xi(u, {
            shape: {
                width: s,
                height: l
            }
        }, n)), u;
    }
    function Xs(t, e, n) {
        var i = t.getArea(), r = new Qd({
            shape: {
                cx: nr(t.cx, 1),
                cy: nr(t.cy, 1),
                r0: nr(i.r0, 1),
                r: nr(i.r, 1),
                startAngle: i.startAngle,
                endAngle: i.endAngle,
                clockwise: i.clockwise
            }
        });
        return e && (r.shape.endAngle = i.startAngle, Xi(r, {
            shape: {
                endAngle: i.endAngle
            }
        }, n)), r;
    }
    function Us(t, e, n) {
        n.style.text = null, Wi(n, {
            shape: {
                width: 0
            }
        }, e, t, function() {
            n.parent && n.parent.remove(n);
        });
    }
    function Ys(t, e, n) {
        n.style.text = null, Wi(n, {
            shape: {
                r: n.shape.r0
            }
        }, e, t, function() {
            n.parent && n.parent.remove(n);
        });
    }
    function qs(t) {
        return null != t.startAngle && null != t.endAngle && t.startAngle === t.endAngle;
    }
    function js(t, e, n, i, r, o, a, l) {
        var h = e.getItemVisual(n, "color"), u = e.getItemVisual(n, "opacity"), c = e.getVisual("borderColor"), d = i.getModel("itemStyle"), f = i.getModel("emphasis.itemStyle").getBarItemStyle();
        l || t.setShape("r", d.get("barBorderRadius") || 0), t.useStyle(s({
            stroke: qs(r) ? "none" : c,
            fill: qs(r) ? "none" : h,
            opacity: u
        }, d.getBarItemStyle()));
        var p = i.getShallow("cursor");
        p && t.attr("cursor", p);
        a ? r.height : r.width;
        l || function(t, e, n, i, r, o) {
            Ei(t, e, n.getModel("label"), n.getModel("emphasis.label"), {
                labelFetcher: r,
                labelDataIndex: o,
                defaultText: Hs(r.getData(), o),
                isRectText: !0,
                autoColor: i
            }), Gs(t), Gs(e);
        }(t.style, f, i, h, o, n), qs(r) && (f.fill = f.stroke = "none"), ki(t, f);
    }
    function Zs(t, e, n) {
        var i = t.getData(), r = [], o = i.getLayout("valueAxisHorizontal") ? 1 : 0;
        r[1 - o] = i.getLayout("valueAxisStart");
        var a = i.getLayout("largeDataIndices"), s = i.getLayout("barWidth"), l = t.getModel("backgroundStyle");
        if (t.get("showBackground", !0)) {
            var h = i.getLayout("largeBackgroundPoints"), u = [];
            u[1 - o] = i.getLayout("backgroundStart");
            var c = new Dm({
                shape: {
                    points: h
                },
                incremental: !!n,
                __startPoint: u,
                __baseDimIdx: o,
                __largeDataIndices: a,
                __barWidth: s,
                silent: !0,
                z2: 0
            });
            (function(t, e, n) {
                var i = e.get("borderColor") || e.get("color"), r = e.getItemStyle([ "color", "borderColor" ]);
                t.useStyle(r), t.style.fill = null, t.style.stroke = i, t.style.lineWidth = n.getLayout("barWidth");
            })(c, l, i), e.add(c);
        }
        var d = new Dm({
            shape: {
                points: i.getLayout("largePoints")
            },
            incremental: !!n,
            __startPoint: r,
            __baseDimIdx: o,
            __largeDataIndices: a,
            __barWidth: s
        });
        e.add(d), function(t, e, n) {
            var i = n.getVisual("borderColor") || n.getVisual("color"), r = e.getModel("itemStyle").getItemStyle([ "color", "borderColor" ]);
            t.useStyle(r), t.style.fill = null, t.style.stroke = i, t.style.lineWidth = n.getLayout("barWidth");
        }(d, t, i), d.seriesIndex = t.seriesIndex, t.get("silent") || (d.on("mousedown", km), 
        d.on("mousemove", km));
    }
    function Ks(t, e, n) {
        var i, r = "polar" === n.type;
        return i = r ? n.getArea() : n.grid.getRect(), r ? {
            cx: i.cx,
            cy: i.cy,
            r0: t ? i.r0 : e.r0,
            r: t ? i.r : e.r,
            startAngle: t ? e.startAngle : 0,
            endAngle: t ? e.endAngle : 2 * Math.PI
        } : {
            x: t ? e.x : i.x,
            y: t ? i.y : e.y,
            width: t ? e.width : i.width,
            height: t ? i.height : e.height
        };
    }
    function $s(t) {
        t && (t.ignore = !0);
    }
    function Qs(t, e) {
        var n = t && t.getBoundingRect().clone(), i = e && e.getBoundingRect().clone();
        if (n && i) {
            var r = yt([]);
            return bt(r, r, -t.rotation), n.applyTransform(xt([], r, t.getLocalTransform())), 
            i.applyTransform(xt([], r, e.getLocalTransform())), n.intersect(i);
        }
    }
    function Js(t) {
        return "middle" === t || "center" === t;
    }
    function tl(t, e, n, i, r) {
        for (var o = [], a = [], s = [], l = 0; l < t.length; l++) {
            var h = t[l].coord;
            a[0] = h, a[1] = 0, s[0] = h, s[1] = n, e && ($(a, a, e), $(s, s, e));
            var u = new hf({
                anid: r + "_" + t[l].tickValue,
                subPixelOptimize: !0,
                shape: {
                    x1: a[0],
                    y1: a[1],
                    x2: s[0],
                    y2: s[1]
                },
                style: i,
                z2: 2,
                silent: !0
            });
            o.push(u);
        }
        return o;
    }
    function el(t, e) {
        var n = {
            axesInfo: {},
            seriesInvolved: !1,
            coordSysAxesInfo: {},
            coordSysMap: {}
        };
        return function(t, e, n) {
            var i = e.getComponent("tooltip"), r = e.getComponent("axisPointer"), o = r.get("link", !0) || [], a = [];
            Nm(n.getCoordinateSystems(), function(n) {
                function s(i, s, l) {
                    var c = l.model.getModel("axisPointer", r), d = c.get("show");
                    if (d && ("auto" !== d || i || al(c))) {
                        null == s && (s = c.get("triggerTooltip"));
                        var f = (c = i ? nl(l, u, r, e, i, s) : c).get("snap"), p = sl(l.model), g = s || f || "category" === l.type, v = t.axesInfo[p] = {
                            key: p,
                            axis: l,
                            coordSys: n,
                            axisPointerModel: c,
                            triggerTooltip: s,
                            involveSeries: g,
                            snap: f,
                            useHandle: al(c),
                            seriesModels: []
                        };
                        h[p] = v, t.seriesInvolved |= g;
                        var m = function(t, e) {
                            for (var n = e.model, i = e.dim, r = 0; r < t.length; r++) {
                                var o = t[r] || {};
                                if (il(o[i + "AxisId"], n.id) || il(o[i + "AxisIndex"], n.componentIndex) || il(o[i + "AxisName"], n.name)) return r;
                            }
                        }(o, l);
                        if (null != m) {
                            var y = a[m] || (a[m] = {
                                axesInfo: {}
                            });
                            y.axesInfo[p] = v, y.mapper = o[m].mapper, v.linkGroup = y;
                        }
                    }
                }
                if (n.axisPointerEnabled) {
                    var l = sl(n.model), h = t.coordSysAxesInfo[l] = {};
                    t.coordSysMap[l] = n;
                    var u = n.model.getModel("tooltip", i);
                    if (Nm(n.getAxes(), Rm(s, !1, null)), n.getTooltipAxes && i && u.get("show")) {
                        var c = "axis" === u.get("trigger"), d = "cross" === u.get("axisPointer.type"), f = n.getTooltipAxes(u.get("axisPointer.axis"));
                        (c || d) && Nm(f.baseAxes, Rm(s, !d || "cross", c)), d && Nm(f.otherAxes, Rm(s, "cross", !1));
                    }
                }
            });
        }(n, t, e), n.seriesInvolved && function(t, e) {
            e.eachSeries(function(e) {
                var n = e.coordinateSystem, i = e.get("tooltip.trigger", !0), r = e.get("tooltip.show", !0);
                n && "none" !== i && !1 !== i && "item" !== i && !1 !== r && !1 !== e.get("axisPointer.show", !0) && Nm(t.coordSysAxesInfo[sl(n.model)], function(t) {
                    var i = t.axis;
                    n.getAxis(i.dim) === i && (t.seriesModels.push(e), null == t.seriesDataCount && (t.seriesDataCount = 0), 
                    t.seriesDataCount += e.getData().count());
                });
            }, this);
        }(n, t), n;
    }
    function nl(t, e, n, r, o, a) {
        var l = e.getModel("axisPointer"), h = {};
        Nm([ "type", "snap", "lineStyle", "shadowStyle", "label", "animation", "animationDurationUpdate", "animationEasingUpdate", "z" ], function(t) {
            h[t] = i(l.get(t));
        }), h.snap = "category" !== t.type && !!a, "cross" === l.get("type") && (h.type = "line");
        var u = h.label || (h.label = {});
        if (null == u.show && (u.show = !1), "cross" === o) {
            var c = l.get("label.show");
            if (u.show = null == c || c, !a) {
                var d = h.lineStyle = l.get("crossStyle");
                d && s(u, d.textStyle);
            }
        }
        return t.model.getModel("axisPointer", new Ki(h, n, r));
    }
    function il(t, e) {
        return "all" === t || _(t) && h(t, e) >= 0 || t === e;
    }
    function rl(t) {
        var e = ol(t);
        if (e) {
            var n = e.axisPointerModel, i = e.axis.scale, r = n.option, o = n.get("status"), a = n.get("value");
            null != a && (a = i.parse(a));
            var s = al(n);
            null == o && (r.status = s ? "show" : "hide");
            var l = i.getExtent().slice();
            l[0] > l[1] && l.reverse(), (null == a || a > l[1]) && (a = l[1]), a < l[0] && (a = l[0]), 
            r.value = a, s && (r.status = e.axis.scale.isBlank() ? "hide" : "show");
        }
    }
    function ol(t) {
        var e = (t.ecModel.getComponent("axisPointer") || {}).coordSysAxesInfo;
        return e && e.axesInfo[sl(t)];
    }
    function al(t) {
        return !!t.get("handle.show");
    }
    function sl(t) {
        return t.type + "||" + t.id;
    }
    function ll(t, e, n, i, r, o) {
        var a = Fm.getAxisPointerClass(t.axisPointerClass);
        if (a) {
            var s = function(t) {
                var e = ol(t);
                return e && e.axisPointerModel;
            }(e);
            s ? (t._axisPointer || (t._axisPointer = new a())).render(e, s, i, o) : hl(t, i);
        }
    }
    function hl(t, e, n) {
        var i = t._axisPointer;
        i && i.dispose(e, n), t._axisPointer = null;
    }
    function ul(t, e, n) {
        n = n || {};
        var i = t.coordinateSystem, r = e.axis, o = {}, a = r.getAxesOnZeroOf()[0], s = r.position, l = a ? "onZero" : s, h = r.dim, u = i.getRect(), c = [ u.x, u.x + u.width, u.y, u.y + u.height ], d = {
            left: 0,
            right: 1,
            top: 0,
            bottom: 1,
            onZero: 2
        }, f = e.get("offset") || 0, p = "x" === h ? [ c[2] - f, c[3] + f ] : [ c[0] - f, c[1] + f ];
        if (a) {
            var g = a.toGlobalCoord(a.dataToCoord(0));
            p[d.onZero] = Math.max(Math.min(g, p[1]), p[0]);
        }
        o.position = [ "y" === h ? p[d[l]] : c[0], "x" === h ? p[d[l]] : c[3] ], o.rotation = Math.PI / 2 * ("x" === h ? 0 : 1);
        o.labelDirection = o.tickDirection = o.nameDirection = {
            top: -1,
            bottom: 1,
            left: -1,
            right: 1
        }[s], o.labelOffset = a ? p[d[s]] - p[d.onZero] : 0, e.get("axisTick.inside") && (o.tickDirection = -o.tickDirection), 
        C(n.labelInside, e.get("axisLabel.inside")) && (o.labelDirection = -o.labelDirection);
        var v = e.get("axisLabel.rotate");
        return o.labelRotate = "top" === l ? -v : v, o.z2 = 1, o;
    }
    function cl(t, e, n) {
        Nu.call(this), this.updateData(t, e, n);
    }
    function dl(t) {
        return [ t[0] / 2, t[1] / 2 ];
    }
    function fl(t, e) {
        this.parent.drift(t, e);
    }
    function pl(t, e) {
        if (!this.incremental && !this.useHoverLayer) if ("emphasis" === e) {
            var n = this.__symbolOriginalScale, i = n[1] / n[0], r = {
                scale: [ Math.max(1.1 * n[0], n[0] + 3), Math.max(1.1 * n[1], n[1] + 3 * i) ]
            };
            this.animateTo(r, 400, "elasticOut");
        } else "normal" === e && this.animateTo({
            scale: this.__symbolOriginalScale
        }, 400, "elasticOut");
    }
    function gl(t) {
        this.group = new Nu(), this._symbolCtor = t || cl;
    }
    function vl(t, e, n, i) {
        return !(!e || isNaN(e[0]) || isNaN(e[1]) || i.isIgnore && i.isIgnore(n) || i.clipShape && !i.clipShape.contain(e[0], e[1]) || "none" === t.getItemVisual(n, "symbol"));
    }
    function ml(t) {
        return null == t || b(t) || (t = {
            isIgnore: t
        }), t || {};
    }
    function yl(t) {
        var e = t.hostModel;
        return {
            itemStyle: e.getModel("itemStyle").getItemStyle([ "color" ]),
            hoverItemStyle: e.getModel("emphasis.itemStyle").getItemStyle(),
            symbolRotate: e.get("symbolRotate"),
            symbolOffset: e.get("symbolOffset"),
            hoverAnimation: e.get("hoverAnimation"),
            labelModel: e.getModel("label"),
            hoverLabelModel: e.getModel("emphasis.label"),
            cursorStyle: e.get("cursor")
        };
    }
    function _l(t, e, n) {
        var i, r = t.getBaseAxis(), o = t.getOtherAxis(r), a = function(t, e) {
            var n = 0, i = t.scale.getExtent();
            return "start" === e ? n = i[0] : "end" === e ? n = i[1] : i[0] > 0 ? n = i[0] : i[1] < 0 && (n = i[1]), 
            n;
        }(o, n), s = r.dim, l = o.dim, h = e.mapDimension(l), u = e.mapDimension(s), c = "x" === l || "radius" === l ? 1 : 0, d = p(t.dimensions, function(t) {
            return e.mapDimension(t);
        }), f = e.getCalculationInfo("stackResultDimension");
        return (i |= Xa(e, d[0])) && (d[0] = f), (i |= Xa(e, d[1])) && (d[1] = f), {
            dataDimsForPoint: d,
            valueStart: a,
            valueAxisDim: l,
            baseAxisDim: s,
            stacked: !!i,
            valueDim: h,
            baseDim: u,
            baseDataOffset: c,
            stackedOverDimension: e.getCalculationInfo("stackedOverDimension")
        };
    }
    function xl(t, e, n, i) {
        var r = NaN;
        t.stacked && (r = n.get(n.getCalculationInfo("stackedOverDimension"), i)), isNaN(r) && (r = t.valueStart);
        var o = t.baseDataOffset, a = [];
        return a[o] = n.get(t.baseDim, i), a[1 - o] = r, e.dataToPoint(a);
    }
    function wl(t) {
        return isNaN(t[0]) || isNaN(t[1]);
    }
    function bl(t, e, n, i, r, o, a, s, l, h) {
        return "none" !== h && h ? Sl.apply(this, arguments) : Ml.apply(this, arguments);
    }
    function Sl(t, e, n, i, r, o, a, s, l, h, u) {
        for (var c = 0, d = n, f = 0; i > f; f++) {
            var p = e[d];
            if (d >= r || 0 > d) break;
            if (wl(p)) {
                if (u) {
                    d += o;
                    continue;
                }
                break;
            }
            if (d === n) t[o > 0 ? "moveTo" : "lineTo"](p[0], p[1]); else if (l > 0) {
                var g = e[c], v = "y" === h ? 1 : 0, m = (p[v] - g[v]) * l;
                ty(ny, g), ny[v] = g[v] + m, ty(iy, p), iy[v] = p[v] - m, t.bezierCurveTo(ny[0], ny[1], iy[0], iy[1], p[0], p[1]);
            } else t.lineTo(p[0], p[1]);
            c = d, d += o;
        }
        return f;
    }
    function Ml(t, e, n, i, r, o, a, s, l, h, u) {
        for (var c = 0, d = n, f = 0; i > f; f++) {
            var p = e[d];
            if (d >= r || 0 > d) break;
            if (wl(p)) {
                if (u) {
                    d += o;
                    continue;
                }
                break;
            }
            if (d === n) t[o > 0 ? "moveTo" : "lineTo"](p[0], p[1]), ty(ny, p); else if (l > 0) {
                var g = d + o, v = e[g];
                if (u) for (;v && wl(e[g]); ) v = e[g += o];
                var m = .5, y = e[c];
                if (!(v = e[g]) || wl(v)) ty(iy, p); else {
                    var _, x;
                    if (wl(v) && !u && (v = p), X(ey, v, y), "x" === h || "y" === h) {
                        var w = "x" === h ? 0 : 1;
                        _ = Math.abs(p[w] - y[w]), x = Math.abs(p[w] - v[w]);
                    } else _ = Gh(p, y), x = Gh(p, v);
                    Jm(iy, p, ey, -l * (1 - (m = x / (x + _))));
                }
                $m(ny, ny, s), Qm(ny, ny, a), $m(iy, iy, s), Qm(iy, iy, a), t.bezierCurveTo(ny[0], ny[1], iy[0], iy[1], p[0], p[1]), 
                Jm(ny, p, ey, l * m);
            } else t.lineTo(p[0], p[1]);
            c = d, d += o;
        }
        return f;
    }
    function Il(t, e) {
        var n = [ 1 / 0, 1 / 0 ], i = [ -1 / 0, -1 / 0 ];
        if (e) for (var r = 0; r < t.length; r++) {
            var o = t[r];
            o[0] < n[0] && (n[0] = o[0]), o[1] < n[1] && (n[1] = o[1]), o[0] > i[0] && (i[0] = o[0]), 
            o[1] > i[1] && (i[1] = o[1]);
        }
        return {
            min: e ? n : i,
            max: e ? i : n
        };
    }
    function Tl(t, e) {
        if (t.length === e.length) {
            for (var n = 0; n < t.length; n++) {
                var i = t[n], r = e[n];
                if (i[0] !== r[0] || i[1] !== r[1]) return;
            }
            return !0;
        }
    }
    function Cl(t, e) {
        var n = [], i = [], r = [], o = [];
        return Vn(t, n, i), Vn(e, r, o), Math.max(Math.abs(n[0] - r[0]), Math.abs(n[1] - r[1]), Math.abs(i[0] - o[0]), Math.abs(i[1] - o[1]));
    }
    function Al(t) {
        return "number" == typeof t ? t : t ? .5 : 0;
    }
    function Dl(t, e, n) {
        for (var i = e.getBaseAxis(), r = "x" === i.dim || "radius" === i.dim ? 0 : 1, o = [], a = 0; a < t.length - 1; a++) {
            var s = t[a + 1], l = t[a];
            o.push(l);
            var h = [];
            switch (n) {
              case "end":
                h[r] = s[r], h[1 - r] = l[1 - r], o.push(h);
                break;

              case "middle":
                var u = (l[r] + s[r]) / 2, c = [];
                h[r] = c[r] = u, h[1 - r] = l[1 - r], c[1 - r] = s[1 - r], o.push(h), o.push(c);
                break;

              default:
                h[r] = l[r], h[1 - r] = s[1 - r], o.push(h);
            }
        }
        return t[a] && o.push(t[a]), o;
    }
    function kl(t, e) {
        var n = t.getVisual("visualMeta");
        if (n && n.length && t.count()) {
            if ("cartesian2d" !== e.type) return void (wh && console.warn("Visual map on line style is only supported on cartesian2d."));
            for (var i, r, o = n.length - 1; o >= 0; o--) {
                var a = n[o].dimension, s = t.dimensions[a], l = t.getDimensionInfo(s);
                if ("x" === (i = l && l.coordDim) || "y" === i) {
                    r = n[o];
                    break;
                }
            }
            if (!r) return void (wh && console.warn("Visual map on line style only support x or y dimension."));
            var h = e.getAxis(i), u = p(r.stops, function(t) {
                return {
                    coord: h.toGlobalCoord(h.dataToCoord(t.value)),
                    color: t.color
                };
            }), c = u.length, d = r.outerColors.slice();
            c && u[0].coord > u[c - 1].coord && (u.reverse(), d.reverse());
            var g = u[0].coord - 10, v = u[c - 1].coord + 10, m = v - g;
            if (.001 > m) return "transparent";
            f(u, function(t) {
                t.offset = (t.coord - g) / m;
            }), u.push({
                offset: c ? u[c - 1].offset : .5,
                color: d[1] || "transparent"
            }), u.unshift({
                offset: c ? u[0].offset : .5,
                color: d[0] || "transparent"
            });
            var y = new gf(0, 0, 0, 0, u, !0);
            return y[i] = g, y[i + "2"] = v, y;
        }
    }
    function Pl(t, e, n) {
        var i = t.get("showAllSymbol"), r = "auto" === i;
        if (!i || r) {
            var o = n.getAxesByScale("ordinal")[0];
            if (o && (!r || !function(t, e) {
                var n = t.getExtent(), i = Math.abs(n[1] - n[0]) / t.scale.count();
                isNaN(i) && (i = 0);
                for (var r = e.count(), o = Math.max(1, Math.round(r / 5)), a = 0; r > a; a += o) if (1.5 * cl.getSymbolSize(e, a)[t.isHorizontal() ? 1 : 0] > i) return !1;
                return !0;
            }(o, e))) {
                var a = e.mapDimension(o.dim), s = {};
                return f(o.getViewLabels(), function(t) {
                    s[t.tickValue] = 1;
                }), function(t) {
                    return !s.hasOwnProperty(e.get(a, t));
                };
            }
        }
    }
    function Ll(t, e, n) {
        if ("cartesian2d" === t.type) {
            var i = t.getBaseAxis().isHorizontal(), r = Ws(t, e, n);
            if (!n.get("clip", !0)) {
                var o = r.shape, a = Math.max(o.width, o.height);
                i ? (o.y -= a, o.height += 2 * a) : (o.x -= a, o.width += 2 * a);
            }
            return r;
        }
        return Xs(t, e, n);
    }
    function Ol(t, e) {
        this.getAllNames = function() {
            var t = e();
            return t.mapArray(t.getName);
        }, this.containName = function(t) {
            return e().indexOfName(t) >= 0;
        }, this.indexOfName = function(e) {
            return t().indexOfName(e);
        }, this.getItemVisual = function(e, n) {
            return t().getItemVisual(e, n);
        };
    }
    function El(t, e, n, i) {
        var r = e.getData(), o = this.dataIndex, a = r.getName(o), s = e.get("selectedOffset");
        i.dispatchAction({
            type: "pieToggleSelect",
            from: t,
            name: a,
            seriesId: e.id
        }), r.each(function(t) {
            Bl(r.getItemGraphicEl(t), r.getItemLayout(t), e.isSelected(r.getName(t)), s, n);
        });
    }
    function Bl(t, e, n, i, r) {
        var o = (e.startAngle + e.endAngle) / 2, a = n ? i : 0, s = [ Math.cos(o) * a, Math.sin(o) * a ];
        r ? t.animate().when(200, {
            position: s
        }).start("bounceOut") : t.attr("position", s);
    }
    function zl(t, e) {
        Nu.call(this);
        var n = new Qd({
            z2: 2
        }), i = new rf(), r = new jd();
        this.add(n), this.add(i), this.add(r), this.updateData(t, e, !0);
    }
    function Nl(t, e, n, i, r, o, a, s, l, h) {
        function u(e, n, i) {
            for (var r = e; n > r && !(t[r].y + i > l + a); r++) if (t[r].y += i, r > e && n > r + 1 && t[r + 1].y > t[r].y + t[r].height) return void c(r, i / 2);
            c(n - 1, i / 2);
        }
        function c(e, n) {
            for (var i = e; i >= 0 && !(t[i].y - n < l) && (t[i].y -= n, !(i > 0 && t[i].y > t[i - 1].y + t[i - 1].height)); i--) ;
        }
        function d(t, e, n, i, r, o) {
            for (var a = e ? Number.MAX_VALUE : 0, s = 0, l = t.length; l > s; s++) if ("none" === t[s].labelAlignTo) {
                var h = Math.abs(t[s].y - i), u = t[s].len, c = t[s].len2, d = r + u > h ? Math.sqrt((r + u + c) * (r + u + c) - h * h) : Math.abs(t[s].x - n);
                e && d >= a && (d = a - 10), !e && a >= d && (d = a + 10), t[s].x = n + d * o, a = d;
            }
        }
        t.sort(function(t, e) {
            return t.y - e.y;
        });
        for (var f, p = 0, g = t.length, v = [], m = [], y = 0; g > y; y++) {
            if ("outer" === t[y].position && "labelLine" === t[y].labelAlignTo) {
                var _ = t[y].x - h;
                t[y].linePoints[1][0] += _, t[y].x = h;
            }
            0 > (f = t[y].y - p) && u(y, g, -f), p = t[y].y + t[y].height;
        }
        0 > a - p && c(g - 1, p - a);
        for (y = 0; g > y; y++) t[y].y >= n ? m.push(t[y]) : v.push(t[y]);
        d(v, !1, e, n, i, r), d(m, !0, e, n, i, r);
    }
    function Rl(t) {
        return "center" === t.position;
    }
    function Fl(t, e, n) {
        var i, r = {}, o = "toggleSelected" === t;
        return n.eachComponent("legend", function(n) {
            o && null != i ? n[i ? "select" : "unSelect"](e.name) : "allSelect" === t || "inverseSelect" === t ? n[t]() : (n[t](e.name), 
            i = n.isSelected(e.name)), f(n.getData(), function(t) {
                var e = t.get("name");
                if ("\n" !== e && "" !== e) {
                    var i = n.isSelected(e);
                    r[e] = r.hasOwnProperty(e) ? r[e] && i : i;
                }
            });
        }), "allSelect" === t || "inverseSelect" === t ? {
            selected: r
        } : {
            name: e.name,
            selected: r
        };
    }
    function Vl(t, e, n, i, r, o) {
        var a;
        return "line" !== e && e.indexOf("empty") < 0 ? (a = n.getItemStyle(), t.style.stroke = i, 
        o || (a.stroke = r)) : a = n.getItemStyle([ "borderWidth", "borderColor" ]), t.setStyle(a);
    }
    function Hl(t, e, n, i) {
        Wl(t, e, n, i), n.dispatchAction({
            type: "legendToggleSelect",
            name: null != t ? t : e
        }), Gl(t, e, n, i);
    }
    function Gl(t, e, n, i) {
        var r = n.getZr().storage.getDisplayList()[0];
        r && r.useHoverLayer || n.dispatchAction({
            type: "highlight",
            seriesName: t,
            name: e,
            excludeSeriesId: i
        });
    }
    function Wl(t, e, n, i) {
        var r = n.getZr().storage.getDisplayList()[0];
        r && r.useHoverLayer || n.dispatchAction({
            type: "downplay",
            seriesName: t,
            name: e,
            excludeSeriesId: i
        });
    }
    function Xl(t, e, n) {
        var i = [ 1, 1 ];
        i[t.getOrient().index] = 0, br(e, n, {
            type: "box",
            ignoreSize: i
        });
    }
    function Ul(t, e, n, i, r) {
        var o = t.axis;
        if (!o.scale.isBlank() && o.containData(e)) {
            if (!t.involveSeries) return void n.showPointer(t, e);
            var s = function(t, e) {
                var n = e.axis, i = n.dim, r = t, o = [], a = Number.MAX_VALUE, s = -1;
                return Dy(e.seriesModels, function(e) {
                    var l, h, u = e.getData().mapDimension(i, !0);
                    if (e.getAxisTooltipData) {
                        var c = e.getAxisTooltipData(u, t, n);
                        h = c.dataIndices, l = c.nestestValue;
                    } else {
                        if (!(h = e.getData().indicesOfNearest(u[0], t, "category" === n.type ? .5 : null)).length) return;
                        l = e.getData().get(u[0], h[0]);
                    }
                    if (null != l && isFinite(l)) {
                        var d = t - l, f = Math.abs(d);
                        a >= f && ((a > f || d >= 0 && 0 > s) && (a = f, s = d, r = l, o.length = 0), Dy(h, function(t) {
                            o.push({
                                seriesIndex: e.seriesIndex,
                                dataIndexInside: t,
                                dataIndex: e.getData().getRawIndex(t)
                            });
                        }));
                    }
                }), {
                    payloadBatch: o,
                    snapToValue: r
                };
            }(e, t), l = s.payloadBatch, h = s.snapToValue;
            l[0] && null == r.seriesIndex && a(r, l[0]), !i && t.snap && o.containData(h) && null != h && (e = h), 
            n.showPointer(t, e, l, r), n.showTooltip(t, s, h);
        }
    }
    function Yl(t, e, n, i) {
        t[e.key] = {
            value: n,
            payloadBatch: i
        };
    }
    function ql(t, e, n, i) {
        var r = n.payloadBatch, o = e.axis, a = o.model, s = e.axisPointerModel;
        if (e.triggerTooltip && r.length) {
            var l = e.coordSys.model, h = sl(l), u = t.map[h];
            u || (u = t.map[h] = {
                coordSysId: l.id,
                coordSysIndex: l.componentIndex,
                coordSysType: l.type,
                coordSysMainType: l.mainType,
                dataByAxis: []
            }, t.list.push(u)), u.dataByAxis.push({
                axisDim: o.dim,
                axisIndex: a.componentIndex,
                axisType: a.type,
                axisId: a.id,
                value: i,
                valueLabelOpt: {
                    precision: s.get("label.precision"),
                    formatter: s.get("label.formatter")
                },
                seriesDataIndices: r.slice()
            });
        }
    }
    function jl(t, e, n) {
        var i = n.getZr(), r = "axisPointerLastHighlights", o = Py(i)[r] || {}, a = Py(i)[r] = {};
        Dy(t, function(t) {
            var e = t.axisPointerModel.option;
            "show" === e.status && Dy(e.seriesDataIndices, function(t) {
                var e = t.seriesIndex + " | " + t.dataIndex;
                a[e] = t;
            });
        });
        var s = [], l = [];
        f(o, function(t, e) {
            !a[e] && l.push(t);
        }), f(a, function(t, e) {
            !o[e] && s.push(t);
        }), l.length && n.dispatchAction({
            type: "downplay",
            escapeConnect: !0,
            batch: l
        }), s.length && n.dispatchAction({
            type: "highlight",
            escapeConnect: !0,
            batch: s
        });
    }
    function Zl(t) {
        var e = t.axis.model, n = {}, i = n.axisDim = t.axis.dim;
        return n.axisIndex = n[i + "AxisIndex"] = e.componentIndex, n.axisName = n[i + "AxisName"] = e.name, 
        n.axisId = n[i + "AxisId"] = e.id, n;
    }
    function Kl(t) {
        return !t || null == t[0] || isNaN(t[0]) || null == t[1] || isNaN(t[1]);
    }
    function $l(t, e, n) {
        if (!Mh.node) {
            var i = e.getZr();
            Ly(i).records || (Ly(i).records = {}), function(t, e) {
                function n(n, i) {
                    t.on(n, function(n) {
                        var r = function(t) {
                            var e = {
                                showTip: [],
                                hideTip: []
                            };
                            return {
                                dispatchAction: function n(i) {
                                    var r = e[i.type];
                                    r ? r.push(i) : (i.dispatchAction = n, t.dispatchAction(i));
                                },
                                pendings: e
                            };
                        }(e);
                        Oy(Ly(t).records, function(t) {
                            t && i(t, n, r.dispatchAction);
                        }), function(t, e) {
                            var n, i = t.showTip.length, r = t.hideTip.length;
                            i ? n = t.showTip[i - 1] : r && (n = t.hideTip[r - 1]), n && (n.dispatchAction = null, 
                            e.dispatchAction(n));
                        }(r.pendings, e);
                    });
                }
                Ly(t).initialized || (Ly(t).initialized = !0, n("click", y(Jl, "click")), n("mousemove", y(Jl, "mousemove")), 
                n("globalout", Ql));
            }(i, e), (Ly(i).records[t] || (Ly(i).records[t] = {})).handler = n;
        }
    }
    function Ql(t, e, n) {
        t.handler("leave", null, n);
    }
    function Jl(t, e, n, i) {
        e.handler(t, n, i);
    }
    function th(t, e) {
        if (!Mh.node) {
            var n = e.getZr();
            (Ly(n).records || {})[t] && (Ly(n).records[t] = null);
        }
    }
    function eh() {}
    function nh(t, e, n, i) {
        (function t(e, n) {
            if (b(e) && b(n)) {
                var i = !0;
                return f(n, function(n, r) {
                    i = i && t(e[r], n);
                }), !!i;
            }
            return e === n;
        })(By(n).lastProp, i) || (By(n).lastProp = i, e ? Wi(n, i, t) : (n.stopAnimation(), 
        n.attr(i)));
    }
    function ih(t, e) {
        t[e.get("label.show") ? "show" : "hide"]();
    }
    function rh(t) {
        return {
            position: t.position.slice(),
            rotation: t.rotation || 0
        };
    }
    function oh(t, e, n) {
        var i = e.get("z"), r = e.get("zlevel");
        t && t.traverse(function(t) {
            "group" !== t.type && (null != i && (t.z = i), null != r && (t.zlevel = r), t.silent = n);
        });
    }
    function ah(t, e, n, i, r) {
        var o = sh(n.get("value"), e.axis, e.ecModel, n.get("seriesDataIndices"), {
            precision: n.get("label.precision"),
            formatter: n.get("label.formatter")
        }), a = n.getModel("label"), s = Gf(a.get("padding") || 0), l = a.getFont(), h = xe(o, l), u = r.position, c = h.width + s[1] + s[3], d = h.height + s[0] + s[2], f = r.align;
        "right" === f && (u[0] -= c), "center" === f && (u[0] -= c / 2);
        var p = r.verticalAlign;
        "bottom" === p && (u[1] -= d), "middle" === p && (u[1] -= d / 2), function(t, e, n, i) {
            var r = i.getWidth(), o = i.getHeight();
            t[0] = Math.min(t[0] + e, r) - e, t[1] = Math.min(t[1] + n, o) - n, t[0] = Math.max(t[0], 0), 
            t[1] = Math.max(t[1], 0);
        }(u, c, d, i);
        var g = a.get("backgroundColor");
        g && "auto" !== g || (g = e.get("axisLine.lineStyle.color")), t.label = {
            shape: {
                x: 0,
                y: 0,
                width: c,
                height: d,
                r: a.get("borderRadius")
            },
            position: u.slice(),
            style: {
                text: o,
                textFont: l,
                textFill: a.getTextColor(),
                textPosition: "inside",
                textPadding: s,
                fill: g,
                stroke: a.get("borderColor") || "transparent",
                lineWidth: a.get("borderWidth") || 0,
                shadowBlur: a.get("shadowBlur"),
                shadowColor: a.get("shadowColor"),
                shadowOffsetX: a.get("shadowOffsetX"),
                shadowOffsetY: a.get("shadowOffsetY")
            },
            z2: 10
        };
    }
    function sh(t, e, n, i, r) {
        t = e.scale.parse(t);
        var o = e.scale.getLabel(t, {
            precision: r.precision
        }), a = r.formatter;
        if (a) {
            var s = {
                value: fs(e, t),
                axisDimension: e.dim,
                axisIndex: e.index,
                seriesData: []
            };
            f(i, function(t) {
                var e = n.getSeriesByIndex(t.seriesIndex), i = t.dataIndexInside, r = e && e.getDataParams(i);
                r && s.seriesData.push(r);
            }), w(a) ? o = a.replace("{value}", o) : x(a) && (o = a(s));
        }
        return o;
    }
    function lh(t, e, n) {
        var i = mt();
        return bt(i, i, n.rotation), wt(i, i, n.position), Ui([ t.dataToCoord(e), (n.labelOffset || 0) + (n.labelDirection || 1) * (n.labelMargin || 0) ], i);
    }
    function hh(t, e, n) {
        return {
            x: t[n = n || 0],
            y: t[1 - n],
            width: e[n],
            height: e[1 - n]
        };
    }
    function uh(t, e) {
        var n = {};
        return n[e.dim + "AxisIndex"] = e.index, t.getCartesian(n);
    }
    function ch(t) {
        return "x" === t.dim ? 0 : 1;
    }
    function dh(t) {
        var e = [], n = t.get("transitionDuration"), i = t.get("backgroundColor"), r = t.getModel("textStyle"), o = t.get("padding");
        return n && e.push(function(t) {
            var e = "cubic-bezier(0.23, 1, 0.32, 1)", n = "left " + t + "s " + e + ",top " + t + "s " + e;
            return p(Gy, function(t) {
                return t + "transition:" + n;
            }).join(";");
        }(n)), i && (Mh.canvasSupported ? e.push("background-Color:" + i) : (e.push("background-Color:#" + Ft(i)), 
        e.push("filter:alpha(opacity=70)"))), Vy([ "width", "color", "radius" ], function(n) {
            var i = "border-" + n, r = Hy(i), o = t.get(r);
            null != o && e.push(i + ":" + o + ("color" === n ? "" : "px"));
        }), e.push(function(t) {
            var e = [], n = t.get("fontSize"), i = t.getTextColor();
            i && e.push("color:" + i), e.push("font:" + t.getFont());
            var r = t.get("lineHeight");
            null == r && (r = Math.round(3 * n / 2)), n && e.push("line-height:" + r + "px");
            var o = t.get("textShadowColor"), a = t.get("textShadowBlur") || 0, s = t.get("textShadowOffsetX") || 0, l = t.get("textShadowOffsetY") || 0;
            return a && e.push("text-shadow:" + s + "px " + l + "px " + a + "px " + o), Vy([ "decoration", "align" ], function(n) {
                var i = t.get(n);
                i && e.push("text-" + n + ":" + i);
            }), e.join(";");
        }(r)), null != o && e.push("padding:" + Gf(o).join("px ") + "px"), e.join(";") + ";";
    }
    function fh(t, e, n, i, r) {
        var o = e && e.painter;
        if (n) {
            var a = o && o.getViewportRoot();
            a && function(t, e, n, i, r) {
                ot(Zh, e, i, r, !0) && ot(t, n, Zh[0], Zh[1]);
            }(t, a, document.body, i, r);
        } else {
            t[0] = i, t[1] = r;
            var s = o && o.getViewportRootOffset();
            s && (t[0] += s.offsetLeft, t[1] += s.offsetTop);
        }
        t[2] = t[0] / e.getWidth(), t[3] = t[1] / e.getHeight();
    }
    function ph(t, e, n) {
        if (Mh.wxa) return null;
        var i = document.createElement("div");
        i.domBelongToZr = !0, this.el = i;
        var r = this._zr = e.getZr(), o = this._appendToBody = n && n.appendToBody;
        this._styleCoord = [ 0, 0, 0, 0 ], fh(this._styleCoord, r, o, e.getWidth() / 2, e.getHeight() / 2), 
        o ? document.body.appendChild(i) : t.appendChild(i), this._container = t, this._show = !1, 
        this._hideTimeout;
        var a = this;
        i.onmouseenter = function() {
            a._enterable && (clearTimeout(a._hideTimeout), a._show = !0), a._inContent = !0;
        }, i.onmousemove = function(t) {
            if (t = t || window.event, !a._enterable) {
                var e = r.handler;
                ut(r.painter.getViewportRoot(), t, !0), e.dispatch("mousemove", t);
            }
        }, i.onmouseleave = function() {
            a._enterable && a._show && a.hideLater(a._hideDelay), a._inContent = !1;
        };
    }
    function gh(t, e, n, i) {
        t[0] = n, t[1] = i, t[2] = t[0] / e.getWidth(), t[3] = t[1] / e.getHeight();
    }
    function vh(t) {
        var e = this._zr = t.getZr();
        this._styleCoord = [ 0, 0, 0, 0 ], gh(this._styleCoord, e, t.getWidth() / 2, t.getHeight() / 2), 
        this._show = !1, this._hideTimeout;
    }
    function mh(t) {
        for (var e = t.pop(); t.length; ) {
            var n = t.pop();
            n && (Ki.isInstance(n) && (n = n.get("tooltip", !0)), "string" == typeof n && (n = {
                formatter: n
            }), e = new Ki(n, e, e.ecModel));
        }
        return e;
    }
    function yh(t, e) {
        return t.dispatchAction || m(e.dispatchAction, e);
    }
    function _h(t) {
        return "center" === t || "middle" === t;
    }
    var xh;
    "undefined" != typeof window ? xh = window.__DEV__ : "undefined" != typeof global && (xh = global.__DEV__), 
    void 0 === xh && (xh = !0);
    var wh = xh, bh = 2311, Sh = function() {
        return bh++;
    }, Mh = "object" == ("undefined" == typeof wx ? "undefined" : t(wx)) && "function" == typeof wx.getSystemInfoSync ? {
        browser: {},
        os: {},
        node: !1,
        wxa: !0,
        canvasSupported: !0,
        svgSupported: !1,
        touchEventsSupported: !0,
        domSupported: !1
    } : "undefined" == typeof document && "undefined" != typeof self ? {
        browser: {},
        os: {},
        node: !1,
        worker: !0,
        canvasSupported: !0,
        domSupported: !1
    } : "undefined" == typeof navigator ? {
        browser: {},
        os: {},
        node: !0,
        worker: !1,
        canvasSupported: !0,
        svgSupported: !0,
        domSupported: !1
    } : function(t) {
        var e = {}, n = t.match(/Firefox\/([\d.]+)/), i = t.match(/MSIE\s([\d.]+)/) || t.match(/Trident\/.+?rv:(([\d.]+))/), r = t.match(/Edge\/([\d.]+)/), o = /micromessenger/i.test(t);
        return n && (e.firefox = !0, e.version = n[1]), i && (e.ie = !0, e.version = i[1]), 
        r && (e.edge = !0, e.version = r[1]), o && (e.weChat = !0), {
            browser: e,
            os: {},
            node: !1,
            canvasSupported: !!document.createElement("canvas").getContext,
            svgSupported: "undefined" != typeof SVGRect,
            touchEventsSupported: "ontouchstart" in window && !e.ie && !e.edge,
            pointerEventsSupported: "onpointerdown" in window && (e.edge || e.ie && e.version >= 11),
            domSupported: "undefined" != typeof document
        };
    }(navigator.userAgent), Ih = {
        "[object Function]": 1,
        "[object RegExp]": 1,
        "[object Date]": 1,
        "[object Error]": 1,
        "[object CanvasGradient]": 1,
        "[object CanvasPattern]": 1,
        "[object Image]": 1,
        "[object Canvas]": 1
    }, Th = {
        "[object Int8Array]": 1,
        "[object Uint8Array]": 1,
        "[object Uint8ClampedArray]": 1,
        "[object Int16Array]": 1,
        "[object Uint16Array]": 1,
        "[object Int32Array]": 1,
        "[object Uint32Array]": 1,
        "[object Float32Array]": 1,
        "[object Float64Array]": 1
    }, Ch = Object.prototype.toString, Ah = Array.prototype, Dh = Ah.forEach, kh = Ah.filter, Ph = Ah.slice, Lh = Ah.map, Oh = Ah.reduce, Eh = {}, Bh = function() {
        return Eh.createCanvas();
    };
    Eh.createCanvas = function() {
        return document.createElement("canvas");
    };
    var zh, Nh = "__ec_primitive__";
    z.prototype = {
        constructor: z,
        get: function(t) {
            return this.data.hasOwnProperty(t) ? this.data[t] : null;
        },
        set: function(t, e) {
            return this.data[t] = e;
        },
        each: function(t, e) {
            for (var n in void 0 !== e && (t = m(t, e)), this.data) this.data.hasOwnProperty(n) && t(this.data[n], n);
        },
        removeKey: function(t) {
            delete this.data[t];
        }
    };
    var Rh = (Object.freeze || Object)({
        $override: n,
        clone: i,
        merge: r,
        mergeAll: o,
        extend: a,
        defaults: s,
        createCanvas: Bh,
        getContext: l,
        indexOf: h,
        inherits: u,
        mixin: c,
        isArrayLike: d,
        each: f,
        map: p,
        reduce: g,
        filter: v,
        find: function(t, e, n) {
            if (t && e) for (var i = 0, r = t.length; r > i; i++) if (e.call(n, t[i], i, t)) return t[i];
        },
        bind: m,
        curry: y,
        isArray: _,
        isFunction: x,
        isString: w,
        isObject: b,
        isBuiltInObject: S,
        isTypedArray: M,
        isDom: I,
        eqNaN: T,
        retrieve: C,
        retrieve2: A,
        retrieve3: D,
        slice: k,
        normalizeCssArray: P,
        assert: L,
        trim: O,
        setAsPrimitive: E,
        isPrimitive: B,
        createHashMap: N,
        concatArray: function(t, e) {
            for (var n = new t.constructor(t.length + e.length), i = 0; i < t.length; i++) n[i] = t[i];
            var r = t.length;
            for (i = 0; i < e.length; i++) n[i + r] = e[i];
            return n;
        },
        noop: R
    }), Fh = "undefined" == typeof Float32Array ? Array : Float32Array, Vh = U, Hh = Y, Gh = Z, Wh = K, Xh = (Object.freeze || Object)({
        create: F,
        copy: V,
        clone: H,
        set: function(t, e, n) {
            return t[0] = e, t[1] = n, t;
        },
        add: G,
        scaleAndAdd: W,
        sub: X,
        len: U,
        length: Vh,
        lenSquare: Y,
        lengthSquare: Hh,
        mul: function(t, e, n) {
            return t[0] = e[0] * n[0], t[1] = e[1] * n[1], t;
        },
        div: function(t, e, n) {
            return t[0] = e[0] / n[0], t[1] = e[1] / n[1], t;
        },
        dot: function(t, e) {
            return t[0] * e[0] + t[1] * e[1];
        },
        scale: q,
        normalize: j,
        distance: Z,
        dist: Gh,
        distanceSquare: K,
        distSquare: Wh,
        negate: function(t, e) {
            return t[0] = -e[0], t[1] = -e[1], t;
        },
        lerp: function(t, e, n, i) {
            return t[0] = e[0] + i * (n[0] - e[0]), t[1] = e[1] + i * (n[1] - e[1]), t;
        },
        applyTransform: $,
        min: Q,
        max: J
    });
    tt.prototype = {
        constructor: tt,
        _dragStart: function(t) {
            for (var e = t.target; e && !e.draggable; ) e = e.parent;
            e && (this._draggingTarget = e, e.dragging = !0, this._x = t.offsetX, this._y = t.offsetY, 
            this.dispatchToElement(et(e, t), "dragstart", t.event));
        },
        _drag: function(t) {
            var e = this._draggingTarget;
            if (e) {
                var n = t.offsetX, i = t.offsetY, r = n - this._x, o = i - this._y;
                this._x = n, this._y = i, e.drift(r, o, t), this.dispatchToElement(et(e, t), "drag", t.event);
                var a = this.findHover(n, i, e).target, s = this._dropTarget;
                this._dropTarget = a, e !== a && (s && a !== s && this.dispatchToElement(et(s, t), "dragleave", t.event), 
                a && a !== s && this.dispatchToElement(et(a, t), "dragenter", t.event));
            }
        },
        _dragEnd: function(t) {
            var e = this._draggingTarget;
            e && (e.dragging = !1), this.dispatchToElement(et(e, t), "dragend", t.event), this._dropTarget && this.dispatchToElement(et(this._dropTarget, t), "drop", t.event), 
            this._draggingTarget = null, this._dropTarget = null;
        }
    };
    var Uh = Array.prototype.slice, Yh = function(t) {
        this._$handlers = {}, this._$eventProcessor = t;
    };
    Yh.prototype = {
        constructor: Yh,
        one: function(t, e, n, i) {
            return nt(this, t, e, n, i, !0);
        },
        on: function(t, e, n, i) {
            return nt(this, t, e, n, i, !1);
        },
        isSilent: function(t) {
            var e = this._$handlers;
            return !e[t] || !e[t].length;
        },
        off: function(t, e) {
            var n = this._$handlers;
            if (!t) return this._$handlers = {}, this;
            if (e) {
                if (n[t]) {
                    for (var i = [], r = 0, o = n[t].length; o > r; r++) n[t][r].h !== e && i.push(n[t][r]);
                    n[t] = i;
                }
                n[t] && 0 === n[t].length && delete n[t];
            } else delete n[t];
            return this;
        },
        trigger: function(t) {
            var e = this._$handlers[t], n = this._$eventProcessor;
            if (e) {
                var i = arguments, r = i.length;
                r > 3 && (i = Uh.call(i, 1));
                for (var o = e.length, a = 0; o > a; ) {
                    var s = e[a];
                    if (n && n.filter && null != s.query && !n.filter(t, s.query)) a++; else {
                        switch (r) {
                          case 1:
                            s.h.call(s.ctx);
                            break;

                          case 2:
                            s.h.call(s.ctx, i[1]);
                            break;

                          case 3:
                            s.h.call(s.ctx, i[1], i[2]);
                            break;

                          default:
                            s.h.apply(s.ctx, i);
                        }
                        s.one ? (e.splice(a, 1), o--) : a++;
                    }
                }
            }
            return n && n.afterTrigger && n.afterTrigger(t), this;
        },
        triggerWithContext: function(t) {
            var e = this._$handlers[t], n = this._$eventProcessor;
            if (e) {
                var i = arguments, r = i.length;
                r > 4 && (i = Uh.call(i, 1, i.length - 1));
                for (var o = i[i.length - 1], a = e.length, s = 0; a > s; ) {
                    var l = e[s];
                    if (n && n.filter && null != l.query && !n.filter(t, l.query)) s++; else {
                        switch (r) {
                          case 1:
                            l.h.call(o);
                            break;

                          case 2:
                            l.h.call(o, i[1]);
                            break;

                          case 3:
                            l.h.call(o, i[1], i[2]);
                            break;

                          default:
                            l.h.apply(o, i);
                        }
                        l.one ? (e.splice(s, 1), a--) : s++;
                    }
                }
            }
            return n && n.afterTrigger && n.afterTrigger(t), this;
        }
    };
    var qh = Math.log(2), jh = "___zrEVENTSAVED", Zh = [], Kh = "undefined" != typeof window && !!window.addEventListener, $h = /^(?:mouse|pointer|contextmenu|drag|drop)|click/, Qh = [], Jh = Kh ? function(t) {
        t.preventDefault(), t.stopPropagation(), t.cancelBubble = !0;
    } : function(t) {
        t.returnValue = !1, t.cancelBubble = !0;
    }, tu = function() {
        this._track = [];
    };
    tu.prototype = {
        constructor: tu,
        recognize: function(t, e, n) {
            return this._doTrack(t, e, n), this._recognize(t);
        },
        clear: function() {
            return this._track.length = 0, this;
        },
        _doTrack: function(t, e, n) {
            var i = t.touches;
            if (i) {
                for (var r = {
                    points: [],
                    touches: [],
                    target: e,
                    event: t
                }, o = 0, a = i.length; a > o; o++) {
                    var s = i[o], l = st(n, s, {});
                    r.points.push([ l.zrX, l.zrY ]), r.touches.push(s);
                }
                this._track.push(r);
            }
        },
        _recognize: function(t) {
            for (var e in eu) if (eu.hasOwnProperty(e)) {
                var n = eu[e](this._track, t);
                if (n) return n;
            }
        }
    };
    var eu = {
        pinch: function(t, e) {
            var n = t.length;
            if (n) {
                var i = (t[n - 1] || {}).points, r = (t[n - 2] || {}).points || i;
                if (r && r.length > 1 && i && i.length > 1) {
                    var o = dt(i) / dt(r);
                    !isFinite(o) && (o = 1), e.pinchScale = o;
                    var a = function(t) {
                        return [ (t[0][0] + t[1][0]) / 2, (t[0][1] + t[1][1]) / 2 ];
                    }(i);
                    return e.pinchX = a[0], e.pinchY = a[1], {
                        type: "pinch",
                        target: t[0].target,
                        event: e
                    };
                }
            }
        }
    }, nu = "silent";
    pt.prototype.dispose = function() {};
    var iu = [ "click", "dblclick", "mousewheel", "mouseout", "mouseup", "mousedown", "mousemove", "contextmenu" ], ru = function(t, e, n, i) {
        Yh.call(this), this.storage = t, this.painter = e, this.painterRoot = i, n = n || new pt(), 
        this.proxy = null, this._hovered = {}, this._lastTouchMoment, this._lastX, this._lastY, 
        this._gestureMgr, tt.call(this), this.setHandlerProxy(n);
    };
    ru.prototype = {
        constructor: ru,
        setHandlerProxy: function(t) {
            this.proxy && this.proxy.dispose(), t && (f(iu, function(e) {
                t.on && t.on(e, this[e], this);
            }, this), t.handler = this), this.proxy = t;
        },
        mousemove: function(t) {
            var e = t.zrX, n = t.zrY, i = vt(this, e, n), r = this._hovered, o = r.target;
            o && !o.__zr && (o = (r = this.findHover(r.x, r.y)).target);
            var a = this._hovered = i ? {
                x: e,
                y: n
            } : this.findHover(e, n), s = a.target, l = this.proxy;
            l.setCursor && l.setCursor(s ? s.cursor : "default"), o && s !== o && this.dispatchToElement(r, "mouseout", t), 
            this.dispatchToElement(a, "mousemove", t), s && s !== o && this.dispatchToElement(a, "mouseover", t);
        },
        mouseout: function(t) {
            var e = t.zrEventControl, n = t.zrIsToLocalDOM;
            "only_globalout" !== e && this.dispatchToElement(this._hovered, "mouseout", t), 
            "no_globalout" !== e && !n && this.trigger("globalout", {
                type: "globalout",
                event: t
            });
        },
        resize: function() {
            this._hovered = {};
        },
        dispatch: function(t, e) {
            var n = this[t];
            n && n.call(this, e);
        },
        dispose: function() {
            this.proxy.dispose(), this.storage = this.proxy = this.painter = null;
        },
        setCursorStyle: function(t) {
            var e = this.proxy;
            e.setCursor && e.setCursor(t);
        },
        dispatchToElement: function(t, e, n) {
            var i = (t = t || {}).target;
            if (!i || !i.silent) {
                for (var r = "on" + e, o = function(t, e, n) {
                    return {
                        type: t,
                        event: n,
                        target: e.target,
                        topTarget: e.topTarget,
                        cancelBubble: !1,
                        offsetX: n.zrX,
                        offsetY: n.zrY,
                        gestureEvent: n.gestureEvent,
                        pinchX: n.pinchX,
                        pinchY: n.pinchY,
                        pinchScale: n.pinchScale,
                        wheelDelta: n.zrDelta,
                        zrByTouch: n.zrByTouch,
                        which: n.which,
                        stop: ft
                    };
                }(e, t, n); i && (i[r] && (o.cancelBubble = i[r].call(i, o)), i.trigger(e, o), i = i.parent, 
                !o.cancelBubble); ) ;
                o.cancelBubble || (this.trigger(e, o), this.painter && this.painter.eachOtherLayer(function(t) {
                    "function" == typeof t[r] && t[r].call(t, o), t.trigger && t.trigger(e, o);
                }));
            }
        },
        findHover: function(t, e, n) {
            for (var i = this.storage.getDisplayList(), r = {
                x: t,
                y: e
            }, o = i.length - 1; o >= 0; o--) {
                var a;
                if (i[o] !== n && !i[o].ignore && (a = gt(i[o], t, e)) && (!r.topTarget && (r.topTarget = i[o]), 
                a !== nu)) {
                    r.target = i[o];
                    break;
                }
            }
            return r;
        },
        processGesture: function(t, e) {
            this._gestureMgr || (this._gestureMgr = new tu());
            var n = this._gestureMgr;
            "start" === e && n.clear();
            var i = n.recognize(t, this.findHover(t.zrX, t.zrY, null).target, this.proxy.dom);
            if ("end" === e && n.clear(), i) {
                var r = i.type;
                t.gestureEvent = r, this.dispatchToElement({
                    target: i.target
                }, r, i.event);
            }
        }
    }, f([ "click", "mousedown", "mouseup", "mousewheel", "dblclick", "contextmenu" ], function(t) {
        ru.prototype[t] = function(e) {
            var n, i, r = e.zrX, o = e.zrY, a = vt(this, r, o);
            if ("mouseup" === t && a || (i = (n = this.findHover(r, o)).target), "mousedown" === t) this._downEl = i, 
            this._downPoint = [ e.zrX, e.zrY ], this._upEl = i; else if ("mouseup" === t) this._upEl = i; else if ("click" === t) {
                if (this._downEl !== this._upEl || !this._downPoint || Gh(this._downPoint, [ e.zrX, e.zrY ]) > 4) return;
                this._downPoint = null;
            }
            this.dispatchToElement(n, t, e);
        };
    }), c(ru, Yh), c(ru, tt);
    var ou = "undefined" == typeof Float32Array ? Array : Float32Array, au = (Object.freeze || Object)({
        create: mt,
        identity: yt,
        copy: _t,
        mul: xt,
        translate: wt,
        rotate: bt,
        scale: St,
        invert: Mt,
        clone: function(t) {
            var e = mt();
            return _t(e, t), e;
        }
    }), su = yt, lu = 5e-5, hu = function(t) {
        (t = t || {}).position || (this.position = [ 0, 0 ]), null == t.rotation && (this.rotation = 0), 
        t.scale || (this.scale = [ 1, 1 ]), this.origin = this.origin || null;
    }, uu = hu.prototype;
    uu.transform = null, uu.needLocalTransform = function() {
        return It(this.rotation) || It(this.position[0]) || It(this.position[1]) || It(this.scale[0] - 1) || It(this.scale[1] - 1);
    };
    var cu = [];
    uu.updateTransform = function() {
        var t = this.parent, e = t && t.transform, n = this.needLocalTransform(), i = this.transform;
        if (n || e) {
            i = i || mt(), n ? this.getLocalTransform(i) : su(i), e && (n ? xt(i, t.transform, i) : _t(i, t.transform)), 
            this.transform = i;
            var r = this.globalScaleRatio;
            if (null != r && 1 !== r) {
                this.getGlobalScale(cu);
                var o = cu[0] < 0 ? -1 : 1, a = cu[1] < 0 ? -1 : 1, s = ((cu[0] - o) * r + o) / cu[0] || 0, l = ((cu[1] - a) * r + a) / cu[1] || 0;
                i[0] *= s, i[1] *= s, i[2] *= l, i[3] *= l;
            }
            this.invTransform = this.invTransform || mt(), Mt(this.invTransform, i);
        } else i && su(i);
    }, uu.getLocalTransform = function(t) {
        return hu.getLocalTransform(this, t);
    }, uu.setTransform = function(t) {
        var e = this.transform, n = t.dpr || 1;
        e ? t.setTransform(n * e[0], n * e[1], n * e[2], n * e[3], n * e[4], n * e[5]) : t.setTransform(n, 0, 0, n, 0, 0);
    }, uu.restoreTransform = function(t) {
        var e = t.dpr || 1;
        t.setTransform(e, 0, 0, e, 0, 0);
    };
    var du = [], fu = mt();
    uu.setLocalTransform = function(t) {
        if (t) {
            var e = t[0] * t[0] + t[1] * t[1], n = t[2] * t[2] + t[3] * t[3], i = this.position, r = this.scale;
            It(e - 1) && (e = Math.sqrt(e)), It(n - 1) && (n = Math.sqrt(n)), t[0] < 0 && (e = -e), 
            t[3] < 0 && (n = -n), i[0] = t[4], i[1] = t[5], r[0] = e, r[1] = n, this.rotation = Math.atan2(-t[1] / n, t[0] / e);
        }
    }, uu.decomposeTransform = function() {
        if (this.transform) {
            var t = this.parent, e = this.transform;
            t && t.transform && (xt(du, t.invTransform, e), e = du);
            var n = this.origin;
            n && (n[0] || n[1]) && (fu[4] = n[0], fu[5] = n[1], xt(du, e, fu), du[4] -= n[0], 
            du[5] -= n[1], e = du), this.setLocalTransform(e);
        }
    }, uu.getGlobalScale = function(t) {
        var e = this.transform;
        return t = t || [], e ? (t[0] = Math.sqrt(e[0] * e[0] + e[1] * e[1]), t[1] = Math.sqrt(e[2] * e[2] + e[3] * e[3]), 
        e[0] < 0 && (t[0] = -t[0]), e[3] < 0 && (t[1] = -t[1]), t) : (t[0] = 1, t[1] = 1, 
        t);
    }, uu.transformCoordToLocal = function(t, e) {
        var n = [ t, e ], i = this.invTransform;
        return i && $(n, n, i), n;
    }, uu.transformCoordToGlobal = function(t, e) {
        var n = [ t, e ], i = this.transform;
        return i && $(n, n, i), n;
    }, hu.getLocalTransform = function(t, e) {
        su(e = e || []);
        var n = t.origin, i = t.scale || [ 1, 1 ], r = t.rotation || 0, o = t.position || [ 0, 0 ];
        return n && (e[4] -= n[0], e[5] -= n[1]), St(e, e, i), r && bt(e, e, r), n && (e[4] += n[0], 
        e[5] += n[1]), e[4] += o[0], e[5] += o[1], e;
    };
    var pu = {
        linear: function(t) {
            return t;
        },
        quadraticIn: function(t) {
            return t * t;
        },
        quadraticOut: function(t) {
            return t * (2 - t);
        },
        quadraticInOut: function(t) {
            return (t *= 2) < 1 ? .5 * t * t : -.5 * (--t * (t - 2) - 1);
        },
        cubicIn: function(t) {
            return t * t * t;
        },
        cubicOut: function(t) {
            return --t * t * t + 1;
        },
        cubicInOut: function(t) {
            return (t *= 2) < 1 ? .5 * t * t * t : .5 * ((t -= 2) * t * t + 2);
        },
        quarticIn: function(t) {
            return t * t * t * t;
        },
        quarticOut: function(t) {
            return 1 - --t * t * t * t;
        },
        quarticInOut: function(t) {
            return (t *= 2) < 1 ? .5 * t * t * t * t : -.5 * ((t -= 2) * t * t * t - 2);
        },
        quinticIn: function(t) {
            return t * t * t * t * t;
        },
        quinticOut: function(t) {
            return --t * t * t * t * t + 1;
        },
        quinticInOut: function(t) {
            return (t *= 2) < 1 ? .5 * t * t * t * t * t : .5 * ((t -= 2) * t * t * t * t + 2);
        },
        sinusoidalIn: function(t) {
            return 1 - Math.cos(t * Math.PI / 2);
        },
        sinusoidalOut: function(t) {
            return Math.sin(t * Math.PI / 2);
        },
        sinusoidalInOut: function(t) {
            return .5 * (1 - Math.cos(Math.PI * t));
        },
        exponentialIn: function(t) {
            return 0 === t ? 0 : Math.pow(1024, t - 1);
        },
        exponentialOut: function(t) {
            return 1 === t ? 1 : 1 - Math.pow(2, -10 * t);
        },
        exponentialInOut: function(t) {
            return 0 === t ? 0 : 1 === t ? 1 : (t *= 2) < 1 ? .5 * Math.pow(1024, t - 1) : .5 * (2 - Math.pow(2, -10 * (t - 1)));
        },
        circularIn: function(t) {
            return 1 - Math.sqrt(1 - t * t);
        },
        circularOut: function(t) {
            return Math.sqrt(1 - --t * t);
        },
        circularInOut: function(t) {
            return (t *= 2) < 1 ? -.5 * (Math.sqrt(1 - t * t) - 1) : .5 * (Math.sqrt(1 - (t -= 2) * t) + 1);
        },
        elasticIn: function(t) {
            var e, n = .1;
            return 0 === t ? 0 : 1 === t ? 1 : (!n || 1 > n ? (n = 1, e = .1) : e = .4 * Math.asin(1 / n) / (2 * Math.PI), 
            -n * Math.pow(2, 10 * (t -= 1)) * Math.sin(2 * (t - e) * Math.PI / .4));
        },
        elasticOut: function(t) {
            var e, n = .1;
            return 0 === t ? 0 : 1 === t ? 1 : (!n || 1 > n ? (n = 1, e = .1) : e = .4 * Math.asin(1 / n) / (2 * Math.PI), 
            n * Math.pow(2, -10 * t) * Math.sin(2 * (t - e) * Math.PI / .4) + 1);
        },
        elasticInOut: function(t) {
            var e, n = .1, i = .4;
            return 0 === t ? 0 : 1 === t ? 1 : (!n || 1 > n ? (n = 1, e = .1) : e = i * Math.asin(1 / n) / (2 * Math.PI), 
            (t *= 2) < 1 ? -.5 * n * Math.pow(2, 10 * (t -= 1)) * Math.sin(2 * (t - e) * Math.PI / i) : n * Math.pow(2, -10 * (t -= 1)) * Math.sin(2 * (t - e) * Math.PI / i) * .5 + 1);
        },
        backIn: function(t) {
            var e = 1.70158;
            return t * t * ((e + 1) * t - e);
        },
        backOut: function(t) {
            var e = 1.70158;
            return --t * t * ((e + 1) * t + e) + 1;
        },
        backInOut: function(t) {
            var e = 2.5949095;
            return (t *= 2) < 1 ? .5 * t * t * ((e + 1) * t - e) : .5 * ((t -= 2) * t * ((e + 1) * t + e) + 2);
        },
        bounceIn: function(t) {
            return 1 - pu.bounceOut(1 - t);
        },
        bounceOut: function(t) {
            return 1 / 2.75 > t ? 7.5625 * t * t : 2 / 2.75 > t ? 7.5625 * (t -= 1.5 / 2.75) * t + .75 : 2.5 / 2.75 > t ? 7.5625 * (t -= 2.25 / 2.75) * t + .9375 : 7.5625 * (t -= 2.625 / 2.75) * t + .984375;
        },
        bounceInOut: function(t) {
            return .5 > t ? .5 * pu.bounceIn(2 * t) : .5 * pu.bounceOut(2 * t - 1) + .5;
        }
    };
    Tt.prototype = {
        constructor: Tt,
        step: function(t, e) {
            if (this._initialized || (this._startTime = t + this._delay, this._initialized = !0), 
            this._paused) this._pausedTime += e; else {
                var n = (t - this._startTime - this._pausedTime) / this._life;
                if (!(0 > n)) {
                    n = Math.min(n, 1);
                    var i = this.easing, r = "string" == typeof i ? pu[i] : i, o = "function" == typeof r ? r(n) : n;
                    return this.fire("frame", o), 1 === n ? this.loop ? (this.restart(t), "restart") : (this._needsRemove = !0, 
                    "destroy") : null;
                }
            }
        },
        restart: function(t) {
            var e = (t - this._startTime - this._pausedTime) % this._life;
            this._startTime = t - e + this.gap, this._pausedTime = 0, this._needsRemove = !1;
        },
        fire: function(t, e) {
            this[t = "on" + t] && this[t](this._target, e);
        },
        pause: function() {
            this._paused = !0;
        },
        resume: function() {
            this._paused = !1;
        }
    };
    var gu = function() {
        this.head = null, this.tail = null, this._len = 0;
    }, vu = gu.prototype;
    vu.insert = function(t) {
        var e = new mu(t);
        return this.insertEntry(e), e;
    }, vu.insertEntry = function(t) {
        this.head ? (this.tail.next = t, t.prev = this.tail, t.next = null, this.tail = t) : this.head = this.tail = t, 
        this._len++;
    }, vu.remove = function(t) {
        var e = t.prev, n = t.next;
        e ? e.next = n : this.head = n, n ? n.prev = e : this.tail = e, t.next = t.prev = null, 
        this._len--;
    }, vu.len = function() {
        return this._len;
    }, vu.clear = function() {
        this.head = this.tail = null, this._len = 0;
    };
    var mu = function(t) {
        this.value = t, this.next, this.prev;
    }, yu = function(t) {
        this._list = new gu(), this._map = {}, this._maxSize = t || 10, this._lastRemovedEntry = null;
    }, _u = yu.prototype;
    _u.put = function(t, e) {
        var n = this._list, i = this._map, r = null;
        if (null == i[t]) {
            var o = n.len(), a = this._lastRemovedEntry;
            if (o >= this._maxSize && o > 0) {
                var s = n.head;
                n.remove(s), delete i[s.key], r = s.value, this._lastRemovedEntry = s;
            }
            a ? a.value = e : a = new mu(e), a.key = t, n.insertEntry(a), i[t] = a;
        }
        return r;
    }, _u.get = function(t) {
        var e = this._map[t], n = this._list;
        return null != e ? (e !== n.tail && (n.remove(e), n.insertEntry(e)), e.value) : void 0;
    }, _u.clear = function() {
        this._list.clear(), this._map = {};
    };
    var xu = {
        transparent: [ 0, 0, 0, 0 ],
        aliceblue: [ 240, 248, 255, 1 ],
        antiquewhite: [ 250, 235, 215, 1 ],
        aqua: [ 0, 255, 255, 1 ],
        aquamarine: [ 127, 255, 212, 1 ],
        azure: [ 240, 255, 255, 1 ],
        beige: [ 245, 245, 220, 1 ],
        bisque: [ 255, 228, 196, 1 ],
        black: [ 0, 0, 0, 1 ],
        blanchedalmond: [ 255, 235, 205, 1 ],
        blue: [ 0, 0, 255, 1 ],
        blueviolet: [ 138, 43, 226, 1 ],
        brown: [ 165, 42, 42, 1 ],
        burlywood: [ 222, 184, 135, 1 ],
        cadetblue: [ 95, 158, 160, 1 ],
        chartreuse: [ 127, 255, 0, 1 ],
        chocolate: [ 210, 105, 30, 1 ],
        coral: [ 255, 127, 80, 1 ],
        cornflowerblue: [ 100, 149, 237, 1 ],
        cornsilk: [ 255, 248, 220, 1 ],
        crimson: [ 220, 20, 60, 1 ],
        cyan: [ 0, 255, 255, 1 ],
        darkblue: [ 0, 0, 139, 1 ],
        darkcyan: [ 0, 139, 139, 1 ],
        darkgoldenrod: [ 184, 134, 11, 1 ],
        darkgray: [ 169, 169, 169, 1 ],
        darkgreen: [ 0, 100, 0, 1 ],
        darkgrey: [ 169, 169, 169, 1 ],
        darkkhaki: [ 189, 183, 107, 1 ],
        darkmagenta: [ 139, 0, 139, 1 ],
        darkolivegreen: [ 85, 107, 47, 1 ],
        darkorange: [ 255, 140, 0, 1 ],
        darkorchid: [ 153, 50, 204, 1 ],
        darkred: [ 139, 0, 0, 1 ],
        darksalmon: [ 233, 150, 122, 1 ],
        darkseagreen: [ 143, 188, 143, 1 ],
        darkslateblue: [ 72, 61, 139, 1 ],
        darkslategray: [ 47, 79, 79, 1 ],
        darkslategrey: [ 47, 79, 79, 1 ],
        darkturquoise: [ 0, 206, 209, 1 ],
        darkviolet: [ 148, 0, 211, 1 ],
        deeppink: [ 255, 20, 147, 1 ],
        deepskyblue: [ 0, 191, 255, 1 ],
        dimgray: [ 105, 105, 105, 1 ],
        dimgrey: [ 105, 105, 105, 1 ],
        dodgerblue: [ 30, 144, 255, 1 ],
        firebrick: [ 178, 34, 34, 1 ],
        floralwhite: [ 255, 250, 240, 1 ],
        forestgreen: [ 34, 139, 34, 1 ],
        fuchsia: [ 255, 0, 255, 1 ],
        gainsboro: [ 220, 220, 220, 1 ],
        ghostwhite: [ 248, 248, 255, 1 ],
        gold: [ 255, 215, 0, 1 ],
        goldenrod: [ 218, 165, 32, 1 ],
        gray: [ 128, 128, 128, 1 ],
        green: [ 0, 128, 0, 1 ],
        greenyellow: [ 173, 255, 47, 1 ],
        grey: [ 128, 128, 128, 1 ],
        honeydew: [ 240, 255, 240, 1 ],
        hotpink: [ 255, 105, 180, 1 ],
        indianred: [ 205, 92, 92, 1 ],
        indigo: [ 75, 0, 130, 1 ],
        ivory: [ 255, 255, 240, 1 ],
        khaki: [ 240, 230, 140, 1 ],
        lavender: [ 230, 230, 250, 1 ],
        lavenderblush: [ 255, 240, 245, 1 ],
        lawngreen: [ 124, 252, 0, 1 ],
        lemonchiffon: [ 255, 250, 205, 1 ],
        lightblue: [ 173, 216, 230, 1 ],
        lightcoral: [ 240, 128, 128, 1 ],
        lightcyan: [ 224, 255, 255, 1 ],
        lightgoldenrodyellow: [ 250, 250, 210, 1 ],
        lightgray: [ 211, 211, 211, 1 ],
        lightgreen: [ 144, 238, 144, 1 ],
        lightgrey: [ 211, 211, 211, 1 ],
        lightpink: [ 255, 182, 193, 1 ],
        lightsalmon: [ 255, 160, 122, 1 ],
        lightseagreen: [ 32, 178, 170, 1 ],
        lightskyblue: [ 135, 206, 250, 1 ],
        lightslategray: [ 119, 136, 153, 1 ],
        lightslategrey: [ 119, 136, 153, 1 ],
        lightsteelblue: [ 176, 196, 222, 1 ],
        lightyellow: [ 255, 255, 224, 1 ],
        lime: [ 0, 255, 0, 1 ],
        limegreen: [ 50, 205, 50, 1 ],
        linen: [ 250, 240, 230, 1 ],
        magenta: [ 255, 0, 255, 1 ],
        maroon: [ 128, 0, 0, 1 ],
        mediumaquamarine: [ 102, 205, 170, 1 ],
        mediumblue: [ 0, 0, 205, 1 ],
        mediumorchid: [ 186, 85, 211, 1 ],
        mediumpurple: [ 147, 112, 219, 1 ],
        mediumseagreen: [ 60, 179, 113, 1 ],
        mediumslateblue: [ 123, 104, 238, 1 ],
        mediumspringgreen: [ 0, 250, 154, 1 ],
        mediumturquoise: [ 72, 209, 204, 1 ],
        mediumvioletred: [ 199, 21, 133, 1 ],
        midnightblue: [ 25, 25, 112, 1 ],
        mintcream: [ 245, 255, 250, 1 ],
        mistyrose: [ 255, 228, 225, 1 ],
        moccasin: [ 255, 228, 181, 1 ],
        navajowhite: [ 255, 222, 173, 1 ],
        navy: [ 0, 0, 128, 1 ],
        oldlace: [ 253, 245, 230, 1 ],
        olive: [ 128, 128, 0, 1 ],
        olivedrab: [ 107, 142, 35, 1 ],
        orange: [ 255, 165, 0, 1 ],
        orangered: [ 255, 69, 0, 1 ],
        orchid: [ 218, 112, 214, 1 ],
        palegoldenrod: [ 238, 232, 170, 1 ],
        palegreen: [ 152, 251, 152, 1 ],
        paleturquoise: [ 175, 238, 238, 1 ],
        palevioletred: [ 219, 112, 147, 1 ],
        papayawhip: [ 255, 239, 213, 1 ],
        peachpuff: [ 255, 218, 185, 1 ],
        peru: [ 205, 133, 63, 1 ],
        pink: [ 255, 192, 203, 1 ],
        plum: [ 221, 160, 221, 1 ],
        powderblue: [ 176, 224, 230, 1 ],
        purple: [ 128, 0, 128, 1 ],
        red: [ 255, 0, 0, 1 ],
        rosybrown: [ 188, 143, 143, 1 ],
        royalblue: [ 65, 105, 225, 1 ],
        saddlebrown: [ 139, 69, 19, 1 ],
        salmon: [ 250, 128, 114, 1 ],
        sandybrown: [ 244, 164, 96, 1 ],
        seagreen: [ 46, 139, 87, 1 ],
        seashell: [ 255, 245, 238, 1 ],
        sienna: [ 160, 82, 45, 1 ],
        silver: [ 192, 192, 192, 1 ],
        skyblue: [ 135, 206, 235, 1 ],
        slateblue: [ 106, 90, 205, 1 ],
        slategray: [ 112, 128, 144, 1 ],
        slategrey: [ 112, 128, 144, 1 ],
        snow: [ 255, 250, 250, 1 ],
        springgreen: [ 0, 255, 127, 1 ],
        steelblue: [ 70, 130, 180, 1 ],
        tan: [ 210, 180, 140, 1 ],
        teal: [ 0, 128, 128, 1 ],
        thistle: [ 216, 191, 216, 1 ],
        tomato: [ 255, 99, 71, 1 ],
        turquoise: [ 64, 224, 208, 1 ],
        violet: [ 238, 130, 238, 1 ],
        wheat: [ 245, 222, 179, 1 ],
        white: [ 255, 255, 255, 1 ],
        whitesmoke: [ 245, 245, 245, 1 ],
        yellow: [ 255, 255, 0, 1 ],
        yellowgreen: [ 154, 205, 50, 1 ]
    }, wu = new yu(20), bu = null, Su = Vt, Mu = Ht, Iu = (Object.freeze || Object)({
        parse: zt,
        lift: Rt,
        toHex: Ft,
        fastLerp: Vt,
        fastMapToColor: Su,
        lerp: Ht,
        mapToColor: Mu,
        modifyHSL: function(t, e, n, i) {
            return (t = zt(t)) ? (t = function(t) {
                if (t) {
                    var e, n, i = t[0] / 255, r = t[1] / 255, o = t[2] / 255, a = Math.min(i, r, o), s = Math.max(i, r, o), l = s - a, h = (s + a) / 2;
                    if (0 === l) e = 0, n = 0; else {
                        n = .5 > h ? l / (s + a) : l / (2 - s - a);
                        var u = ((s - i) / 6 + l / 2) / l, c = ((s - r) / 6 + l / 2) / l, d = ((s - o) / 6 + l / 2) / l;
                        i === s ? e = d - c : r === s ? e = 1 / 3 + u - d : o === s && (e = 2 / 3 + c - u), 
                        0 > e && (e += 1), e > 1 && (e -= 1);
                    }
                    var f = [ 360 * e, n, h ];
                    return null != t[3] && f.push(t[3]), f;
                }
            }(t), null != e && (t[0] = function(t) {
                return 0 > (t = Math.round(t)) ? 0 : t > 360 ? 360 : t;
            }(e)), null != n && (t[1] = kt(n)), null != i && (t[2] = kt(i)), Gt(Nt(t), "rgba")) : void 0;
        },
        modifyAlpha: function(t, e) {
            return (t = zt(t)) && null != e ? (t[3] = At(e), Gt(t, "rgba")) : void 0;
        },
        stringify: Gt
    }), Tu = Array.prototype.slice, Cu = function(t, e, n, i) {
        this._tracks = {}, this._target = t, this._loop = e || !1, this._getter = n || Wt, 
        this._setter = i || Xt, this._clipCount = 0, this._delay = 0, this._doneList = [], 
        this._onframeList = [], this._clipList = [];
    };
    Cu.prototype = {
        when: function(t, e) {
            var n = this._tracks;
            for (var i in e) if (e.hasOwnProperty(i)) {
                if (!n[i]) {
                    n[i] = [];
                    var r = this._getter(this._target, i);
                    if (null == r) continue;
                    0 !== t && n[i].push({
                        time: 0,
                        value: Qt(r)
                    });
                }
                n[i].push({
                    time: t,
                    value: e[i]
                });
            }
            return this;
        },
        during: function(t) {
            return this._onframeList.push(t), this;
        },
        pause: function() {
            for (var t = 0; t < this._clipList.length; t++) this._clipList[t].pause();
            this._paused = !0;
        },
        resume: function() {
            for (var t = 0; t < this._clipList.length; t++) this._clipList[t].resume();
            this._paused = !1;
        },
        isPaused: function() {
            return !!this._paused;
        },
        _doneCallback: function() {
            this._tracks = {}, this._clipList.length = 0;
            for (var t = this._doneList, e = t.length, n = 0; e > n; n++) t[n].call(this);
        },
        start: function(t, e) {
            var n, i = this, r = 0, o = function() {
                --r || i._doneCallback();
            };
            for (var a in this._tracks) if (this._tracks.hasOwnProperty(a)) {
                var s = te(this, t, o, this._tracks[a], a, e);
                s && (this._clipList.push(s), r++, this.animation && this.animation.addClip(s), 
                n = s);
            }
            if (n) {
                var l = n.onframe;
                n.onframe = function(t, e) {
                    l(t, e);
                    for (var n = 0; n < i._onframeList.length; n++) i._onframeList[n](t, e);
                };
            }
            return r || this._doneCallback(), this;
        },
        stop: function(t) {
            for (var e = this._clipList, n = this.animation, i = 0; i < e.length; i++) {
                var r = e[i];
                t && r.onframe(this._target, 1), n && n.removeClip(r);
            }
            e.length = 0;
        },
        delay: function(t) {
            return this._delay = t, this;
        },
        done: function(t) {
            return t && this._doneList.push(t), this;
        },
        getClips: function() {
            return this._clipList;
        }
    };
    var Au = 1;
    "undefined" != typeof window && (Au = Math.max(window.devicePixelRatio || 1, 1));
    var Du = Au, ku = function() {}, Pu = ku, Lu = function() {
        this.animators = [];
    };
    Lu.prototype = {
        constructor: Lu,
        animate: function(t, e) {
            var n, i = !1, r = this, o = this.__zr;
            if (t) {
                var a = t.split("."), s = r;
                i = "shape" === a[0];
                for (var l = 0, u = a.length; u > l; l++) s && (s = s[a[l]]);
                s && (n = s);
            } else n = r;
            if (n) {
                var c = r.animators, d = new Cu(n, e);
                return d.during(function() {
                    r.dirty(i);
                }).done(function() {
                    c.splice(h(c, d), 1);
                }), c.push(d), o && o.animation.addAnimator(d), d;
            }
            Pu('Property "' + t + '" is not existed in element ' + r.id);
        },
        stopAnimation: function(t) {
            for (var e = this.animators, n = e.length, i = 0; n > i; i++) e[i].stop(t);
            return e.length = 0, this;
        },
        animateTo: function(t, e, n, i, r, o) {
            ee(this, t, e, n, i, r, o);
        },
        animateFrom: function(t, e, n, i, r, o) {
            ee(this, t, e, n, i, r, o, !0);
        }
    };
    var Ou = function(t) {
        hu.call(this, t), Yh.call(this, t), Lu.call(this, t), this.id = t.id || Sh();
    };
    Ou.prototype = {
        type: "element",
        name: "",
        __zr: null,
        ignore: !1,
        clipPath: null,
        isGroup: !1,
        drift: function(t, e) {
            switch (this.draggable) {
              case "horizontal":
                e = 0;
                break;

              case "vertical":
                t = 0;
            }
            var n = this.transform;
            n || (n = this.transform = [ 1, 0, 0, 1, 0, 0 ]), n[4] += t, n[5] += e, this.decomposeTransform(), 
            this.dirty(!1);
        },
        beforeUpdate: function() {},
        afterUpdate: function() {},
        update: function() {
            this.updateTransform();
        },
        traverse: function() {},
        attrKV: function(t, e) {
            if ("position" === t || "scale" === t || "origin" === t) {
                if (e) {
                    var n = this[t];
                    n || (n = this[t] = []), n[0] = e[0], n[1] = e[1];
                }
            } else this[t] = e;
        },
        hide: function() {
            this.ignore = !0, this.__zr && this.__zr.refresh();
        },
        show: function() {
            this.ignore = !1, this.__zr && this.__zr.refresh();
        },
        attr: function(t, e) {
            if ("string" == typeof t) this.attrKV(t, e); else if (b(t)) for (var n in t) t.hasOwnProperty(n) && this.attrKV(n, t[n]);
            return this.dirty(!1), this;
        },
        setClipPath: function(t) {
            var e = this.__zr;
            e && t.addSelfToZr(e), this.clipPath && this.clipPath !== t && this.removeClipPath(), 
            this.clipPath = t, t.__zr = e, t.__clipTarget = this, this.dirty(!1);
        },
        removeClipPath: function() {
            var t = this.clipPath;
            t && (t.__zr && t.removeSelfFromZr(t.__zr), t.__zr = null, t.__clipTarget = null, 
            this.clipPath = null, this.dirty(!1));
        },
        addSelfToZr: function(t) {
            this.__zr = t;
            var e = this.animators;
            if (e) for (var n = 0; n < e.length; n++) t.animation.addAnimator(e[n]);
            this.clipPath && this.clipPath.addSelfToZr(t);
        },
        removeSelfFromZr: function(t) {
            this.__zr = null;
            var e = this.animators;
            if (e) for (var n = 0; n < e.length; n++) t.animation.removeAnimator(e[n]);
            this.clipPath && this.clipPath.removeSelfFromZr(t);
        }
    }, c(Ou, Lu), c(Ou, hu), c(Ou, Yh);
    var Eu = $, Bu = Math.min, zu = Math.max;
    ie.prototype = {
        constructor: ie,
        union: function(t) {
            var e = Bu(t.x, this.x), n = Bu(t.y, this.y);
            this.width = zu(t.x + t.width, this.x + this.width) - e, this.height = zu(t.y + t.height, this.y + this.height) - n, 
            this.x = e, this.y = n;
        },
        applyTransform: function() {
            var t = [], e = [], n = [], i = [];
            return function(r) {
                if (r) {
                    t[0] = n[0] = this.x, t[1] = i[1] = this.y, e[0] = i[0] = this.x + this.width, e[1] = n[1] = this.y + this.height, 
                    Eu(t, t, r), Eu(e, e, r), Eu(n, n, r), Eu(i, i, r), this.x = Bu(t[0], e[0], n[0], i[0]), 
                    this.y = Bu(t[1], e[1], n[1], i[1]);
                    var o = zu(t[0], e[0], n[0], i[0]), a = zu(t[1], e[1], n[1], i[1]);
                    this.width = o - this.x, this.height = a - this.y;
                }
            };
        }(),
        calculateTransform: function(t) {
            var e = this, n = t.width / e.width, i = t.height / e.height, r = mt();
            return wt(r, r, [ -e.x, -e.y ]), St(r, r, [ n, i ]), wt(r, r, [ t.x, t.y ]), r;
        },
        intersect: function(t) {
            if (!t) return !1;
            t instanceof ie || (t = ie.create(t));
            var e = this, n = e.x, i = e.x + e.width, r = e.y, o = e.y + e.height, a = t.x, s = t.x + t.width, l = t.y, h = t.y + t.height;
            return !(a > i || n > s || l > o || r > h);
        },
        contain: function(t, e) {
            var n = this;
            return t >= n.x && t <= n.x + n.width && e >= n.y && e <= n.y + n.height;
        },
        clone: function() {
            return new ie(this.x, this.y, this.width, this.height);
        },
        copy: function(t) {
            this.x = t.x, this.y = t.y, this.width = t.width, this.height = t.height;
        },
        plain: function() {
            return {
                x: this.x,
                y: this.y,
                width: this.width,
                height: this.height
            };
        }
    }, ie.create = function(t) {
        return new ie(t.x, t.y, t.width, t.height);
    };
    var Nu = function(t) {
        for (var e in t = t || {}, Ou.call(this, t), t) t.hasOwnProperty(e) && (this[e] = t[e]);
        this._children = [], this.__storage = null, this.__dirty = !0;
    };
    Nu.prototype = {
        constructor: Nu,
        isGroup: !0,
        type: "group",
        silent: !1,
        children: function() {
            return this._children.slice();
        },
        childAt: function(t) {
            return this._children[t];
        },
        childOfName: function(t) {
            for (var e = this._children, n = 0; n < e.length; n++) if (e[n].name === t) return e[n];
        },
        childCount: function() {
            return this._children.length;
        },
        add: function(t) {
            return t && t !== this && t.parent !== this && (this._children.push(t), this._doAdd(t)), 
            this;
        },
        addBefore: function(t, e) {
            if (t && t !== this && t.parent !== this && e && e.parent === this) {
                var n = this._children, i = n.indexOf(e);
                i >= 0 && (n.splice(i, 0, t), this._doAdd(t));
            }
            return this;
        },
        _doAdd: function(t) {
            t.parent && t.parent.remove(t), t.parent = this;
            var e = this.__storage, n = this.__zr;
            e && e !== t.__storage && (e.addToStorage(t), t instanceof Nu && t.addChildrenToStorage(e)), 
            n && n.refresh();
        },
        remove: function(t) {
            var e = this.__zr, n = this.__storage, i = this._children, r = h(i, t);
            return 0 > r || (i.splice(r, 1), t.parent = null, n && (n.delFromStorage(t), t instanceof Nu && t.delChildrenFromStorage(n)), 
            e && e.refresh()), this;
        },
        removeAll: function() {
            var t, e, n = this._children, i = this.__storage;
            for (e = 0; e < n.length; e++) t = n[e], i && (i.delFromStorage(t), t instanceof Nu && t.delChildrenFromStorage(i)), 
            t.parent = null;
            return n.length = 0, this;
        },
        eachChild: function(t, e) {
            for (var n = this._children, i = 0; i < n.length; i++) {
                var r = n[i];
                t.call(e, r, i);
            }
            return this;
        },
        traverse: function(t, e) {
            for (var n = 0; n < this._children.length; n++) {
                var i = this._children[n];
                t.call(e, i), "group" === i.type && i.traverse(t, e);
            }
            return this;
        },
        addChildrenToStorage: function(t) {
            for (var e = 0; e < this._children.length; e++) {
                var n = this._children[e];
                t.addToStorage(n), n instanceof Nu && n.addChildrenToStorage(t);
            }
        },
        delChildrenFromStorage: function(t) {
            for (var e = 0; e < this._children.length; e++) {
                var n = this._children[e];
                t.delFromStorage(n), n instanceof Nu && n.delChildrenFromStorage(t);
            }
        },
        dirty: function() {
            return this.__dirty = !0, this.__zr && this.__zr.refresh(), this;
        },
        getBoundingRect: function(t) {
            for (var e = null, n = new ie(0, 0, 0, 0), i = t || this._children, r = [], o = 0; o < i.length; o++) {
                var a = i[o];
                if (!a.ignore && !a.invisible) {
                    var s = a.getBoundingRect(), l = a.getLocalTransform(r);
                    l ? (n.copy(s), n.applyTransform(l), (e = e || n.clone()).union(n)) : (e = e || s.clone()).union(s);
                }
            }
            return e || n;
        }
    }, u(Nu, Ou);
    var Ru = 32, Fu = 7, Vu = function() {
        this._roots = [], this._displayList = [], this._displayListLen = 0;
    };
    Vu.prototype = {
        constructor: Vu,
        traverse: function(t, e) {
            for (var n = 0; n < this._roots.length; n++) this._roots[n].traverse(t, e);
        },
        getDisplayList: function(t, e) {
            return e = e || !1, t && this.updateDisplayList(e), this._displayList;
        },
        updateDisplayList: function(t) {
            this._displayListLen = 0;
            for (var e = this._roots, n = this._displayList, i = 0, r = e.length; r > i; i++) this._updateAndAddDisplayable(e[i], null, t);
            n.length = this._displayListLen, Mh.canvasSupported && he(n, ue);
        },
        _updateAndAddDisplayable: function(t, e, n) {
            if (!t.ignore || n) {
                t.beforeUpdate(), t.__dirty && t.update(), t.afterUpdate();
                var i = t.clipPath;
                if (i) {
                    e = e ? e.slice() : [];
                    for (var r = i, o = t; r; ) r.parent = o, r.updateTransform(), e.push(r), o = r, 
                    r = r.clipPath;
                }
                if (t.isGroup) {
                    for (var a = t._children, s = 0; s < a.length; s++) {
                        var l = a[s];
                        t.__dirty && (l.__dirty = !0), this._updateAndAddDisplayable(l, e, n);
                    }
                    t.__dirty = !1;
                } else t.__clipPaths = e, this._displayList[this._displayListLen++] = t;
            }
        },
        addRoot: function(t) {
            t.__storage !== this && (t instanceof Nu && t.addChildrenToStorage(this), this.addToStorage(t), 
            this._roots.push(t));
        },
        delRoot: function(t) {
            if (null == t) {
                for (var e = 0; e < this._roots.length; e++) {
                    var n = this._roots[e];
                    n instanceof Nu && n.delChildrenFromStorage(this);
                }
                return this._roots = [], this._displayList = [], void (this._displayListLen = 0);
            }
            if (t instanceof Array) {
                e = 0;
                for (var i = t.length; i > e; e++) this.delRoot(t[e]);
            } else {
                var r = h(this._roots, t);
                r >= 0 && (this.delFromStorage(t), this._roots.splice(r, 1), t instanceof Nu && t.delChildrenFromStorage(this));
            }
        },
        addToStorage: function(t) {
            return t && (t.__storage = this, t.dirty(!1)), this;
        },
        delFromStorage: function(t) {
            return t && (t.__storage = null), this;
        },
        dispose: function() {
            this._renderList = this._roots = null;
        },
        displayableSortFunc: ue
    };
    var Hu = {
        shadowBlur: 1,
        shadowOffsetX: 1,
        shadowOffsetY: 1,
        textShadowBlur: 1,
        textShadowOffsetX: 1,
        textShadowOffsetY: 1,
        textBoxShadowBlur: 1,
        textBoxShadowOffsetX: 1,
        textBoxShadowOffsetY: 1
    }, Gu = function(t, e, n) {
        return Hu.hasOwnProperty(e) ? n *= t.dpr : n;
    }, Wu = {
        NONE: 0,
        STYLE_BIND: 1,
        PLAIN_TEXT: 2
    }, Xu = 9, Uu = [ [ "shadowBlur", 0 ], [ "shadowOffsetX", 0 ], [ "shadowOffsetY", 0 ], [ "shadowColor", "#000" ], [ "lineCap", "butt" ], [ "lineJoin", "miter" ], [ "miterLimit", 10 ] ], Yu = function(t) {
        this.extendFrom(t, !1);
    };
    Yu.prototype = {
        constructor: Yu,
        fill: "#000",
        stroke: null,
        opacity: 1,
        fillOpacity: null,
        strokeOpacity: null,
        lineDash: null,
        lineDashOffset: 0,
        shadowBlur: 0,
        shadowOffsetX: 0,
        shadowOffsetY: 0,
        lineWidth: 1,
        strokeNoScale: !1,
        text: null,
        font: null,
        textFont: null,
        fontStyle: null,
        fontWeight: null,
        fontSize: null,
        fontFamily: null,
        textTag: null,
        textFill: "#000",
        textStroke: null,
        textWidth: null,
        textHeight: null,
        textStrokeWidth: 0,
        textLineHeight: null,
        textPosition: "inside",
        textRect: null,
        textOffset: null,
        textAlign: null,
        textVerticalAlign: null,
        textDistance: 5,
        textShadowColor: "transparent",
        textShadowBlur: 0,
        textShadowOffsetX: 0,
        textShadowOffsetY: 0,
        textBoxShadowColor: "transparent",
        textBoxShadowBlur: 0,
        textBoxShadowOffsetX: 0,
        textBoxShadowOffsetY: 0,
        transformText: !1,
        textRotation: 0,
        textOrigin: null,
        textBackgroundColor: null,
        textBorderColor: null,
        textBorderWidth: 0,
        textBorderRadius: 0,
        textPadding: null,
        rich: null,
        truncate: null,
        blend: null,
        bind: function(t, e, n) {
            var i = this, r = n && n.style, o = !r || t.__attrCachedBy !== Wu.STYLE_BIND;
            t.__attrCachedBy = Wu.STYLE_BIND;
            for (var a = 0; a < Uu.length; a++) {
                var s = Uu[a], l = s[0];
                (o || i[l] !== r[l]) && (t[l] = Gu(t, l, i[l] || s[1]));
            }
            if ((o || i.fill !== r.fill) && (t.fillStyle = i.fill), (o || i.stroke !== r.stroke) && (t.strokeStyle = i.stroke), 
            (o || i.opacity !== r.opacity) && (t.globalAlpha = null == i.opacity ? 1 : i.opacity), 
            (o || i.blend !== r.blend) && (t.globalCompositeOperation = i.blend || "source-over"), 
            this.hasStroke()) {
                var h = i.lineWidth;
                t.lineWidth = h / (this.strokeNoScale && e && e.getLineScale ? e.getLineScale() : 1);
            }
        },
        hasFill: function() {
            var t = this.fill;
            return null != t && "none" !== t;
        },
        hasStroke: function() {
            var t = this.stroke;
            return null != t && "none" !== t && this.lineWidth > 0;
        },
        extendFrom: function(t, e) {
            if (t) for (var n in t) !t.hasOwnProperty(n) || !0 !== e && (!1 === e ? this.hasOwnProperty(n) : null == t[n]) || (this[n] = t[n]);
        },
        set: function(t, e) {
            "string" == typeof t ? this[t] = e : this.extendFrom(t, !0);
        },
        clone: function() {
            var t = new this.constructor();
            return t.extendFrom(this, !0), t;
        },
        getGradient: function(t, e, n) {
            for (var i = ("radial" === e.type ? de : ce)(t, e, n), r = e.colorStops, o = 0; o < r.length; o++) i.addColorStop(r[o].offset, r[o].color);
            return i;
        }
    };
    for (var qu = Yu.prototype, ju = 0; ju < Uu.length; ju++) {
        var Zu = Uu[ju];
        Zu[0] in qu || (qu[Zu[0]] = Zu[1]);
    }
    Yu.getGradient = qu.getGradient;
    var Ku = function(t, e) {
        this.image = t, this.repeat = e, this.type = "pattern";
    };
    Ku.prototype.getCanvasPattern = function(t) {
        return t.createPattern(this.image, this.repeat || "repeat");
    };
    var $u = function(t, e, n) {
        var i;
        n = n || Du, "string" == typeof t ? i = pe(t, e, n) : b(t) && (t = (i = t).id), 
        this.id = t, this.dom = i;
        var r = i.style;
        r && (i.onselectstart = fe, r["-webkit-user-select"] = "none", r["user-select"] = "none", 
        r["-webkit-touch-callout"] = "none", r["-webkit-tap-highlight-color"] = "rgba(0,0,0,0)", 
        r.padding = 0, r.margin = 0, r["border-width"] = 0), this.domBack = null, this.ctxBack = null, 
        this.painter = e, this.config = null, this.clearColor = 0, this.motionBlur = !1, 
        this.lastFrameAlpha = .7, this.dpr = n;
    };
    $u.prototype = {
        constructor: $u,
        __dirty: !0,
        __used: !1,
        __drawIndex: 0,
        __startIndex: 0,
        __endIndex: 0,
        incremental: !1,
        getElementCount: function() {
            return this.__endIndex - this.__startIndex;
        },
        initContext: function() {
            this.ctx = this.dom.getContext("2d"), this.ctx.dpr = this.dpr;
        },
        createBackBuffer: function() {
            var t = this.dpr;
            this.domBack = pe("back-" + this.id, this.painter, t), this.ctxBack = this.domBack.getContext("2d"), 
            1 !== t && this.ctxBack.scale(t, t);
        },
        resize: function(t, e) {
            var n = this.dpr, i = this.dom, r = i.style, o = this.domBack;
            r && (r.width = t + "px", r.height = e + "px"), i.width = t * n, i.height = e * n, 
            o && (o.width = t * n, o.height = e * n, 1 !== n && this.ctxBack.scale(n, n));
        },
        clear: function(t, e) {
            var n, i = this.dom, r = this.ctx, o = i.width, a = i.height, s = (e = e || this.clearColor, 
            this.motionBlur && !t), l = this.lastFrameAlpha, h = this.dpr;
            (s && (this.domBack || this.createBackBuffer(), this.ctxBack.globalCompositeOperation = "copy", 
            this.ctxBack.drawImage(i, 0, 0, o / h, a / h)), r.clearRect(0, 0, o, a), e && "transparent" !== e) && (e.colorStops ? (n = e.__canvasGradient || Yu.getGradient(r, e, {
                x: 0,
                y: 0,
                width: o,
                height: a
            }), e.__canvasGradient = n) : e.image && (n = Ku.prototype.getCanvasPattern.call(e, r)), 
            r.save(), r.fillStyle = n || e, r.fillRect(0, 0, o, a), r.restore());
            if (s) {
                var u = this.domBack;
                r.save(), r.globalAlpha = l, r.drawImage(u, 0, 0, o, a), r.restore();
            }
        }
    };
    var Qu = "undefined" != typeof window && (window.requestAnimationFrame && window.requestAnimationFrame.bind(window) || window.msRequestAnimationFrame && window.msRequestAnimationFrame.bind(window) || window.mozRequestAnimationFrame || window.webkitRequestAnimationFrame) || function(t) {
        setTimeout(t, 16);
    }, Ju = new yu(50), tc = {}, ec = 0, nc = 5e3, ic = /\{([a-zA-Z0-9_]+)\|([^}]*)\}/g, rc = "12px sans-serif", oc = {
        measureText: function(t, e) {
            var n = l();
            return n.font = e || rc, n.measureText(t);
        }
    }, ac = rc, sc = {
        left: 1,
        right: 1,
        center: 1
    }, lc = {
        top: 1,
        bottom: 1,
        middle: 1
    }, hc = [ [ "textShadowBlur", "shadowBlur", 0 ], [ "textShadowOffsetX", "shadowOffsetX", 0 ], [ "textShadowOffsetY", "shadowOffsetY", 0 ], [ "textShadowColor", "shadowColor", "transparent" ] ], uc = {}, cc = {}, dc = new ie(), fc = function() {};
    fc.prototype = {
        constructor: fc,
        drawRectText: function(t, e) {
            var n = this.style;
            e = n.textRect || e, this.__dirty && Ee(n);
            var i = n.text;
            if (null != i && (i += ""), je(i, n)) {
                t.save();
                var r = this.transform;
                n.transformText ? this.setTransform(t) : r && (dc.copy(e), dc.applyTransform(r), 
                e = dc), ze(this, t, i, n, e, Xu), t.restore();
            }
        }
    }, Ze.prototype = {
        constructor: Ze,
        type: "displayable",
        __dirty: !0,
        invisible: !1,
        z: 0,
        z2: 0,
        zlevel: 0,
        draggable: !1,
        dragging: !1,
        silent: !1,
        culling: !1,
        cursor: "pointer",
        rectHover: !1,
        progressive: !1,
        incremental: !1,
        globalScaleRatio: 1,
        beforeBrush: function() {},
        afterBrush: function() {},
        brush: function() {},
        getBoundingRect: function() {},
        contain: function(t, e) {
            return this.rectContain(t, e);
        },
        traverse: function(t, e) {
            t.call(e, this);
        },
        rectContain: function(t, e) {
            var n = this.transformCoordToLocal(t, e);
            return this.getBoundingRect().contain(n[0], n[1]);
        },
        dirty: function() {
            this.__dirty = this.__dirtyText = !0, this._rect = null, this.__zr && this.__zr.refresh();
        },
        animateStyle: function(t) {
            return this.animate("style", t);
        },
        attrKV: function(t, e) {
            "style" !== t ? Ou.prototype.attrKV.call(this, t, e) : this.style.set(e);
        },
        setStyle: function(t, e) {
            return this.style.set(t, e), this.dirty(!1), this;
        },
        useStyle: function(t) {
            return this.style = new Yu(t, this), this.dirty(!1), this;
        },
        calculateTextPosition: null
    }, u(Ze, Ou), c(Ze, fc), Ke.prototype = {
        constructor: Ke,
        type: "image",
        brush: function(t, e) {
            var n = this.style, i = n.image;
            n.bind(t, this, e);
            var r = this._image = ve(i, this._image, this, this.onload);
            if (r && ye(r)) {
                var o = n.x || 0, a = n.y || 0, s = n.width, l = n.height, h = r.width / r.height;
                if (null == s && null != l ? s = l * h : null == l && null != s ? l = s / h : null == s && null == l && (s = r.width, 
                l = r.height), this.setTransform(t), n.sWidth && n.sHeight) {
                    var u = n.sx || 0, c = n.sy || 0;
                    t.drawImage(r, u, c, n.sWidth, n.sHeight, o, a, s, l);
                } else if (n.sx && n.sy) {
                    var d = s - (u = n.sx), f = l - (c = n.sy);
                    t.drawImage(r, u, c, d, f, o, a, s, l);
                } else t.drawImage(r, o, a, s, l);
                null != n.text && (this.restoreTransform(t), this.drawRectText(t, this.getBoundingRect()));
            }
        },
        getBoundingRect: function() {
            var t = this.style;
            return this._rect || (this._rect = new ie(t.x || 0, t.y || 0, t.width || 0, t.height || 0)), 
            this._rect;
        }
    }, u(Ke, Ze);
    var pc = 314159, gc = new ie(0, 0, 0, 0), vc = new ie(0, 0, 0, 0), mc = function(t, e, n) {
        this.type = "canvas";
        var i = !t.nodeName || "CANVAS" === t.nodeName.toUpperCase();
        this._opts = n = a({}, n || {}), this.dpr = n.devicePixelRatio || Du, this._singleCanvas = i, 
        this.root = t;
        var r = t.style;
        r && (r["-webkit-tap-highlight-color"] = "transparent", r["-webkit-user-select"] = r["user-select"] = r["-webkit-touch-callout"] = "none", 
        t.innerHTML = ""), this.storage = e;
        var o = this._zlevelList = [], s = this._layers = {};
        if (this._layerConfig = {}, this._needsManuallyCompositing = !1, i) {
            var l = t.width, h = t.height;
            null != n.width && (l = n.width), null != n.height && (h = n.height), this.dpr = n.devicePixelRatio || 1, 
            t.width = l * this.dpr, t.height = h * this.dpr, this._width = l, this._height = h;
            var u = new $u(t, this, this.dpr);
            u.__builtin__ = !0, u.initContext(), s[pc] = u, u.zlevel = pc, o.push(pc), this._domRoot = t;
        } else {
            this._width = this._getSize(0), this._height = this._getSize(1);
            var c = this._domRoot = function(t, e) {
                var n = document.createElement("div");
                return n.style.cssText = [ "position:relative", "width:" + t + "px", "height:" + e + "px", "padding:0", "margin:0", "border-width:0" ].join(";") + ";", 
                n;
            }(this._width, this._height);
            t.appendChild(c);
        }
        this._hoverlayer = null, this._hoverElements = [];
    };
    mc.prototype = {
        constructor: mc,
        getType: function() {
            return "canvas";
        },
        isSingleCanvas: function() {
            return this._singleCanvas;
        },
        getViewportRoot: function() {
            return this._domRoot;
        },
        getViewportRootOffset: function() {
            var t = this.getViewportRoot();
            return t ? {
                offsetLeft: t.offsetLeft || 0,
                offsetTop: t.offsetTop || 0
            } : void 0;
        },
        refresh: function(t) {
            var e = this.storage.getDisplayList(!0), n = this._zlevelList;
            this._redrawId = Math.random(), this._paintList(e, t, this._redrawId);
            for (var i = 0; i < n.length; i++) {
                var r = n[i], o = this._layers[r];
                if (!o.__builtin__ && o.refresh) {
                    var a = 0 === i ? this._backgroundColor : null;
                    o.refresh(a);
                }
            }
            return this.refreshHover(), this;
        },
        addHover: function(t, e) {
            if (!t.__hoverMir) {
                var n = new t.constructor({
                    style: t.style,
                    shape: t.shape,
                    z: t.z,
                    z2: t.z2,
                    silent: t.silent
                });
                return n.__from = t, t.__hoverMir = n, e && n.setStyle(e), this._hoverElements.push(n), 
                n;
            }
        },
        removeHover: function(t) {
            var e = t.__hoverMir, n = this._hoverElements, i = h(n, e);
            i >= 0 && n.splice(i, 1), t.__hoverMir = null;
        },
        clearHover: function() {
            for (var t = this._hoverElements, e = 0; e < t.length; e++) {
                var n = t[e].__from;
                n && (n.__hoverMir = null);
            }
            t.length = 0;
        },
        refreshHover: function() {
            var t = this._hoverElements, e = t.length, n = this._hoverlayer;
            if (n && n.clear(), e) {
                he(t, this.storage.displayableSortFunc), n || (n = this._hoverlayer = this.getLayer(1e5));
                var i = {};
                n.ctx.save();
                for (var r = 0; e > r; ) {
                    var o = t[r], a = o.__from;
                    a && a.__zr ? (r++, a.invisible || (o.transform = a.transform, o.invTransform = a.invTransform, 
                    o.__clipPaths = a.__clipPaths, this._doPaintEl(o, n, !0, i))) : (t.splice(r, 1), 
                    a.__hoverMir = null, e--);
                }
                n.ctx.restore();
            }
        },
        getHoverLayer: function() {
            return this.getLayer(1e5);
        },
        _paintList: function(t, e, n) {
            if (this._redrawId === n) {
                e = e || !1, this._updateLayerStatus(t);
                var i = this._doPaintList(t, e);
                if (this._needsManuallyCompositing && this._compositeManually(), !i) {
                    var r = this;
                    Qu(function() {
                        r._paintList(t, e, n);
                    });
                }
            }
        },
        _compositeManually: function() {
            var t = this.getLayer(pc).ctx, e = this._domRoot.width, n = this._domRoot.height;
            t.clearRect(0, 0, e, n), this.eachBuiltinLayer(function(i) {
                i.virtual && t.drawImage(i.dom, 0, 0, e, n);
            });
        },
        _doPaintList: function(t, e) {
            for (var n = [], i = 0; i < this._zlevelList.length; i++) {
                var r = this._zlevelList[i];
                (s = this._layers[r]).__builtin__ && s !== this._hoverlayer && (s.__dirty || e) && n.push(s);
            }
            for (var o = !0, a = 0; a < n.length; a++) {
                var s, l = (s = n[a]).ctx, h = {};
                l.save();
                var u = e ? s.__startIndex : s.__drawIndex, c = !e && s.incremental && Date.now, d = c && Date.now(), p = s.zlevel === this._zlevelList[0] ? this._backgroundColor : null;
                if (s.__startIndex === s.__endIndex) s.clear(!1, p); else if (u === s.__startIndex) {
                    var g = t[u];
                    g.incremental && g.notClear && !e || s.clear(!1, p);
                }
                -1 === u && (console.error("For some unknown reason. drawIndex is -1"), u = s.__startIndex);
                for (var v = u; v < s.__endIndex; v++) {
                    var m = t[v];
                    if (this._doPaintEl(m, s, e, h), m.__dirty = m.__dirtyText = !1, c) if (Date.now() - d > 15) break;
                }
                s.__drawIndex = v, s.__drawIndex < s.__endIndex && (o = !1), h.prevElClipPaths && l.restore(), 
                l.restore();
            }
            return Mh.wxa && f(this._layers, function(t) {
                t && t.ctx && t.ctx.draw && t.ctx.draw();
            }), o;
        },
        _doPaintEl: function(t, e, n, i) {
            var r = e.ctx, o = t.transform;
            if (!(!e.__dirty && !n || t.invisible || 0 === t.style.opacity || o && !o[0] && !o[3] || t.culling && function(t, e, n) {
                return gc.copy(t.getBoundingRect()), t.transform && gc.applyTransform(t.transform), 
                vc.width = e, vc.height = n, !gc.intersect(vc);
            }(t, this._width, this._height))) {
                var a = t.__clipPaths, s = i.prevElClipPaths;
                (!s || function(t, e) {
                    if (t === e) return !1;
                    if (!t || !e || t.length !== e.length) return !0;
                    for (var n = 0; n < t.length; n++) if (t[n] !== e[n]) return !0;
                    return !1;
                }(a, s)) && (s && (r.restore(), i.prevElClipPaths = null, i.prevEl = null), a && (r.save(), 
                function(t, e) {
                    for (var n = 0; n < t.length; n++) {
                        var i = t[n];
                        i.setTransform(e), e.beginPath(), i.buildPath(e, i.shape), e.clip(), i.restoreTransform(e);
                    }
                }(a, r), i.prevElClipPaths = a)), t.beforeBrush && t.beforeBrush(r), t.brush(r, i.prevEl || null), 
                i.prevEl = t, t.afterBrush && t.afterBrush(r);
            }
        },
        getLayer: function(t, e) {
            this._singleCanvas && !this._needsManuallyCompositing && (t = pc);
            var n = this._layers[t];
            return n || ((n = new $u("zr_" + t, this, this.dpr)).zlevel = t, n.__builtin__ = !0, 
            this._layerConfig[t] ? r(n, this._layerConfig[t], !0) : this._layerConfig[t - .01] && r(n, this._layerConfig[t - .01], !0), 
            e && (n.virtual = e), this.insertLayer(t, n), n.initContext()), n;
        },
        insertLayer: function(t, e) {
            var n = this._layers, i = this._zlevelList, r = i.length, o = null, a = -1, s = this._domRoot;
            if (n[t]) Pu("ZLevel " + t + " has been used already"); else if (function(t) {
                return !!t && (!!t.__builtin__ || "function" == typeof t.resize && "function" == typeof t.refresh);
            }(e)) {
                if (r > 0 && t > i[0]) {
                    for (a = 0; r - 1 > a && !(i[a] < t && i[a + 1] > t); a++) ;
                    o = n[i[a]];
                }
                if (i.splice(a + 1, 0, t), n[t] = e, !e.virtual) if (o) {
                    var l = o.dom;
                    l.nextSibling ? s.insertBefore(e.dom, l.nextSibling) : s.appendChild(e.dom);
                } else s.firstChild ? s.insertBefore(e.dom, s.firstChild) : s.appendChild(e.dom);
            } else Pu("Layer of zlevel " + t + " is not valid");
        },
        eachLayer: function(t, e) {
            var n, i, r = this._zlevelList;
            for (i = 0; i < r.length; i++) n = r[i], t.call(e, this._layers[n], n);
        },
        eachBuiltinLayer: function(t, e) {
            var n, i, r, o = this._zlevelList;
            for (r = 0; r < o.length; r++) i = o[r], (n = this._layers[i]).__builtin__ && t.call(e, n, i);
        },
        eachOtherLayer: function(t, e) {
            var n, i, r, o = this._zlevelList;
            for (r = 0; r < o.length; r++) i = o[r], (n = this._layers[i]).__builtin__ || t.call(e, n, i);
        },
        getLayers: function() {
            return this._layers;
        },
        _updateLayerStatus: function(t) {
            function e(t) {
                r && (r.__endIndex !== t && (r.__dirty = !0), r.__endIndex = t);
            }
            if (this.eachBuiltinLayer(function(t) {
                t.__dirty = t.__used = !1;
            }), this._singleCanvas) for (var n = 1; n < t.length; n++) {
                if ((s = t[n]).zlevel !== t[n - 1].zlevel || s.incremental) {
                    this._needsManuallyCompositing = !0;
                    break;
                }
            }
            var i, r = null, o = 0;
            for (n = 0; n < t.length; n++) {
                var a, s, l = (s = t[n]).zlevel;
                i !== l && (i = l, o = 0), s.incremental ? ((a = this.getLayer(l + .001, this._needsManuallyCompositing)).incremental = !0, 
                o = 1) : a = this.getLayer(l + (o > 0 ? .01 : 0), this._needsManuallyCompositing), 
                a.__builtin__ || Pu("ZLevel " + l + " has been used by unkown layer " + a.id), a !== r && (a.__used = !0, 
                a.__startIndex !== n && (a.__dirty = !0), a.__startIndex = n, a.__drawIndex = a.incremental ? -1 : n, 
                e(n), r = a), s.__dirty && (a.__dirty = !0, a.incremental && a.__drawIndex < 0 && (a.__drawIndex = n));
            }
            e(n), this.eachBuiltinLayer(function(t) {
                !t.__used && t.getElementCount() > 0 && (t.__dirty = !0, t.__startIndex = t.__endIndex = t.__drawIndex = 0), 
                t.__dirty && t.__drawIndex < 0 && (t.__drawIndex = t.__startIndex);
            });
        },
        clear: function() {
            return this.eachBuiltinLayer(this._clearLayer), this;
        },
        _clearLayer: function(t) {
            t.clear();
        },
        setBackgroundColor: function(t) {
            this._backgroundColor = t;
        },
        configLayer: function(t, e) {
            if (e) {
                var n = this._layerConfig;
                n[t] ? r(n[t], e, !0) : n[t] = e;
                for (var i = 0; i < this._zlevelList.length; i++) {
                    var o = this._zlevelList[i];
                    if (o === t || o === t + .01) r(this._layers[o], n[t], !0);
                }
            }
        },
        delLayer: function(t) {
            var e = this._layers, n = this._zlevelList, i = e[t];
            i && (i.dom.parentNode.removeChild(i.dom), delete e[t], n.splice(h(n, t), 1));
        },
        resize: function(t, e) {
            if (this._domRoot.style) {
                var n = this._domRoot;
                n.style.display = "none";
                var i = this._opts;
                if (null != t && (i.width = t), null != e && (i.height = e), t = this._getSize(0), 
                e = this._getSize(1), n.style.display = "", this._width !== t || e !== this._height) {
                    for (var r in n.style.width = t + "px", n.style.height = e + "px", this._layers) this._layers.hasOwnProperty(r) && this._layers[r].resize(t, e);
                    f(this._progressiveLayers, function(n) {
                        n.resize(t, e);
                    }), this.refresh(!0);
                }
                this._width = t, this._height = e;
            } else {
                if (null == t || null == e) return;
                this._width = t, this._height = e, this.getLayer(pc).resize(t, e);
            }
            return this;
        },
        clearLayer: function(t) {
            var e = this._layers[t];
            e && e.clear();
        },
        dispose: function() {
            this.root.innerHTML = "", this.root = this.storage = this._domRoot = this._layers = null;
        },
        getRenderedCanvas: function(t) {
            if (t = t || {}, this._singleCanvas && !this._compositeManually) return this._layers[pc].dom;
            var e = new $u("image", this, t.pixelRatio || this.dpr);
            if (e.initContext(), e.clear(!1, t.backgroundColor || this._backgroundColor), t.pixelRatio <= this.dpr) {
                this.refresh();
                var n = e.dom.width, i = e.dom.height, r = e.ctx;
                this.eachLayer(function(t) {
                    t.__builtin__ ? r.drawImage(t.dom, 0, 0, n, i) : t.renderToCanvas && (e.ctx.save(), 
                    t.renderToCanvas(e.ctx), e.ctx.restore());
                });
            } else for (var o = {}, a = this.storage.getDisplayList(!0), s = 0; s < a.length; s++) {
                var l = a[s];
                this._doPaintEl(l, e, !0, o);
            }
            return e.dom;
        },
        getWidth: function() {
            return this._width;
        },
        getHeight: function() {
            return this._height;
        },
        _getSize: function(t) {
            var e = this._opts, n = [ "width", "height" ][t], i = [ "clientWidth", "clientHeight" ][t], r = [ "paddingLeft", "paddingTop" ][t], o = [ "paddingRight", "paddingBottom" ][t];
            if (null != e[n] && "auto" !== e[n]) return parseFloat(e[n]);
            var a = this.root, s = document.defaultView.getComputedStyle(a);
            return (a[i] || $e(s[n]) || $e(a.style[n])) - ($e(s[r]) || 0) - ($e(s[o]) || 0) | 0;
        },
        pathToImage: function(t, e) {
            e = e || this.dpr;
            var n = document.createElement("canvas"), i = n.getContext("2d"), r = t.getBoundingRect(), o = t.style, a = o.shadowBlur * e, s = o.shadowOffsetX * e, l = o.shadowOffsetY * e, h = o.hasStroke() ? o.lineWidth : 0, u = Math.max(h / 2, -s + a), c = Math.max(h / 2, s + a), d = Math.max(h / 2, -l + a), f = Math.max(h / 2, l + a), p = r.width + u + c, g = r.height + d + f;
            n.width = p * e, n.height = g * e, i.scale(e, e), i.clearRect(0, 0, p, g), i.dpr = e;
            var v = {
                position: t.position,
                rotation: t.rotation,
                scale: t.scale
            };
            t.position = [ u - r.x, d - r.y ], t.rotation = 0, t.scale = [ 1, 1 ], t.updateTransform(), 
            t && t.brush(i);
            var m = new Ke({
                style: {
                    x: 0,
                    y: 0,
                    image: n
                }
            });
            return null != v.position && (m.position = t.position = v.position), null != v.rotation && (m.rotation = t.rotation = v.rotation), 
            null != v.scale && (m.scale = t.scale = v.scale), m;
        }
    };
    var yc = function(t) {
        t = t || {}, this.stage = t.stage || {}, this.onframe = t.onframe || function() {}, 
        this._clips = [], this._running = !1, this._time, this._pausedTime, this._pauseStart, 
        this._paused = !1, Yh.call(this);
    };
    yc.prototype = {
        constructor: yc,
        addClip: function(t) {
            this._clips.push(t);
        },
        addAnimator: function(t) {
            t.animation = this;
            for (var e = t.getClips(), n = 0; n < e.length; n++) this.addClip(e[n]);
        },
        removeClip: function(t) {
            var e = h(this._clips, t);
            e >= 0 && this._clips.splice(e, 1);
        },
        removeAnimator: function(t) {
            for (var e = t.getClips(), n = 0; n < e.length; n++) this.removeClip(e[n]);
            t.animation = null;
        },
        _update: function() {
            for (var t = new Date().getTime() - this._pausedTime, e = t - this._time, n = this._clips, i = n.length, r = [], o = [], a = 0; i > a; a++) {
                var s = n[a], l = s.step(t, e);
                l && (r.push(l), o.push(s));
            }
            for (a = 0; i > a; ) n[a]._needsRemove ? (n[a] = n[i - 1], n.pop(), i--) : a++;
            i = r.length;
            for (a = 0; i > a; a++) o[a].fire(r[a]);
            this._time = t, this.onframe(e), this.trigger("frame", e), this.stage.update && this.stage.update();
        },
        _startLoop: function() {
            var t = this;
            this._running = !0, Qu(function e() {
                t._running && (Qu(e), !t._paused && t._update());
            });
        },
        start: function() {
            this._time = new Date().getTime(), this._pausedTime = 0, this._startLoop();
        },
        stop: function() {
            this._running = !1;
        },
        pause: function() {
            this._paused || (this._pauseStart = new Date().getTime(), this._paused = !0);
        },
        resume: function() {
            this._paused && (this._pausedTime += new Date().getTime() - this._pauseStart, this._paused = !1);
        },
        clear: function() {
            this._clips = [];
        },
        isFinished: function() {
            return !this._clips.length;
        },
        animate: function(t, e) {
            var n = new Cu(t, (e = e || {}).loop, e.getter, e.setter);
            return this.addAnimator(n), n;
        }
    }, c(yc, Yh);
    var _c = Mh.domSupported, xc = function() {
        var t = [ "click", "dblclick", "mousewheel", "mouseout", "mouseup", "mousedown", "mousemove", "contextmenu" ], e = {
            pointerdown: 1,
            pointerup: 1,
            pointermove: 1,
            pointerout: 1
        }, n = p(t, function(t) {
            var n = t.replace("mouse", "pointer");
            return e.hasOwnProperty(n) ? n : t;
        });
        return {
            mouse: t,
            touch: [ "touchstart", "touchend", "touchmove" ],
            pointer: n
        };
    }(), wc = {
        mouse: [ "mousemove", "mouseup" ],
        pointer: [ "pointermove", "pointerup" ]
    }, bc = nn.prototype;
    bc.stopPropagation = bc.stopImmediatePropagation = bc.preventDefault = R;
    var Sc = {
        mousedown: function(t) {
            t = ut(this.dom, t), this._mayPointerCapture = [ t.zrX, t.zrY ], this.trigger("mousedown", t);
        },
        mousemove: function(t) {
            t = ut(this.dom, t);
            var e = this._mayPointerCapture;
            !e || t.zrX === e[0] && t.zrY === e[1] || ln(this, !0), this.trigger("mousemove", t);
        },
        mouseup: function(t) {
            t = ut(this.dom, t), ln(this, !1), this.trigger("mouseup", t);
        },
        mouseout: function(t) {
            t = ut(this.dom, t), this._pointerCapturing && (t.zrEventControl = "no_globalout");
            var e = t.toElement || t.relatedTarget;
            t.zrIsToLocalDOM = en(this, e), this.trigger("mouseout", t);
        },
        touchstart: function(t) {
            tn(t = ut(this.dom, t)), this._lastTouchMoment = new Date(), this.handler.processGesture(t, "start"), 
            Sc.mousemove.call(this, t), Sc.mousedown.call(this, t);
        },
        touchmove: function(t) {
            tn(t = ut(this.dom, t)), this.handler.processGesture(t, "change"), Sc.mousemove.call(this, t);
        },
        touchend: function(t) {
            tn(t = ut(this.dom, t)), this.handler.processGesture(t, "end"), Sc.mouseup.call(this, t), 
            +new Date() - this._lastTouchMoment < 300 && Sc.click.call(this, t);
        },
        pointerdown: function(t) {
            Sc.mousedown.call(this, t);
        },
        pointermove: function(t) {
            Je(t) || Sc.mousemove.call(this, t);
        },
        pointerup: function(t) {
            Sc.mouseup.call(this, t);
        },
        pointerout: function(t) {
            Je(t) || Sc.mouseout.call(this, t);
        }
    };
    f([ "click", "mousewheel", "dblclick", "contextmenu" ], function(t) {
        Sc[t] = function(e) {
            e = ut(this.dom, e), this.trigger(t, e);
        };
    });
    var Mc = {
        pointermove: function(t) {
            Je(t) || Mc.mousemove.call(this, t);
        },
        pointerup: function(t) {
            Mc.mouseup.call(this, t);
        },
        mousemove: function(t) {
            this.trigger("mousemove", t);
        },
        mouseup: function(t) {
            var e = this._pointerCapturing;
            ln(this, !1), this.trigger("mouseup", t), e && (t.zrEventControl = "only_globalout", 
            this.trigger("mouseout", t));
        }
    }, Ic = un.prototype;
    Ic.dispose = function() {
        sn(this._localHandlerScope), _c && sn(this._globalHandlerScope);
    }, Ic.setCursor = function(t) {
        this.dom.style && (this.dom.style.cursor = t || "default");
    }, c(un, Yh);
    var Tc = !Mh.canvasSupported, Cc = {
        canvas: mc
    }, Ac = {}, Dc = "4.3.2", kc = function(t, e, n) {
        n = n || {}, this.dom = e, this.id = t;
        var i = this, r = new Vu(), o = n.renderer;
        if (Tc) {
            if (!Cc.vml) throw new Error("You need to require 'zrender/vml/vml' to support IE8");
            o = "vml";
        } else o && Cc[o] || (o = "canvas");
        var a = new Cc[o](e, r, n, t);
        this.storage = r, this.painter = a;
        var s = Mh.node || Mh.worker ? null : new un(a.getViewportRoot(), a.root);
        this.handler = new ru(r, a, s, a.root), this.animation = new yc({
            stage: {
                update: m(this.flush, this)
            }
        }), this.animation.start(), this._needsRefresh;
        var l = r.delFromStorage, h = r.addToStorage;
        r.delFromStorage = function(t) {
            l.call(r, t), t && t.removeSelfFromZr(i);
        }, r.addToStorage = function(t) {
            h.call(r, t), t.addSelfToZr(i);
        };
    };
    kc.prototype = {
        constructor: kc,
        getId: function() {
            return this.id;
        },
        add: function(t) {
            this.storage.addRoot(t), this._needsRefresh = !0;
        },
        remove: function(t) {
            this.storage.delRoot(t), this._needsRefresh = !0;
        },
        configLayer: function(t, e) {
            this.painter.configLayer && this.painter.configLayer(t, e), this._needsRefresh = !0;
        },
        setBackgroundColor: function(t) {
            this.painter.setBackgroundColor && this.painter.setBackgroundColor(t), this._needsRefresh = !0;
        },
        refreshImmediately: function() {
            this._needsRefresh = this._needsRefreshHover = !1, this.painter.refresh(), this._needsRefresh = this._needsRefreshHover = !1;
        },
        refresh: function() {
            this._needsRefresh = !0;
        },
        flush: function() {
            var t;
            this._needsRefresh && (t = !0, this.refreshImmediately()), this._needsRefreshHover && (t = !0, 
            this.refreshHoverImmediately()), t && this.trigger("rendered");
        },
        addHover: function(t, e) {
            if (this.painter.addHover) {
                var n = this.painter.addHover(t, e);
                return this.refreshHover(), n;
            }
        },
        removeHover: function(t) {
            this.painter.removeHover && (this.painter.removeHover(t), this.refreshHover());
        },
        clearHover: function() {
            this.painter.clearHover && (this.painter.clearHover(), this.refreshHover());
        },
        refreshHover: function() {
            this._needsRefreshHover = !0;
        },
        refreshHoverImmediately: function() {
            this._needsRefreshHover = !1, this.painter.refreshHover && this.painter.refreshHover();
        },
        resize: function(t) {
            t = t || {}, this.painter.resize(t.width, t.height), this.handler.resize();
        },
        clearAnimation: function() {
            this.animation.clear();
        },
        getWidth: function() {
            return this.painter.getWidth();
        },
        getHeight: function() {
            return this.painter.getHeight();
        },
        pathToImage: function(t, e) {
            return this.painter.pathToImage(t, e);
        },
        setCursorStyle: function(t) {
            this.handler.setCursorStyle(t);
        },
        findHover: function(t, e) {
            return this.handler.findHover(t, e);
        },
        on: function(t, e, n) {
            this.handler.on(t, e, n);
        },
        off: function(t, e) {
            this.handler.off(t, e);
        },
        trigger: function(t, e) {
            this.handler.trigger(t, e);
        },
        clear: function() {
            this.storage.delRoot(), this.painter.clear();
        },
        dispose: function() {
            this.animation.stop(), this.clear(), this.storage.dispose(), this.painter.dispose(), 
            this.handler.dispose(), this.animation = this.storage = this.painter = this.handler = null, 
            function(t) {
                delete Ac[t];
            }(this.id);
        }
    };
    var Pc = (Object.freeze || Object)({
        version: Dc,
        init: cn,
        dispose: function(t) {
            if (t) t.dispose(); else {
                for (var e in Ac) Ac.hasOwnProperty(e) && Ac[e].dispose();
                Ac = {};
            }
            return this;
        },
        getInstance: function(t) {
            return Ac[t];
        },
        registerPainter: function(t, e) {
            Cc[t] = e;
        }
    }), Lc = f, Oc = b, Ec = _, Bc = "series\0", zc = [ "fontStyle", "fontWeight", "fontSize", "fontFamily", "rich", "tag", "color", "textBorderColor", "textBorderWidth", "width", "height", "lineHeight", "align", "verticalAlign", "baseline", "shadowColor", "shadowBlur", "shadowOffsetX", "shadowOffsetY", "textShadowColor", "textShadowBlur", "textShadowOffsetX", "textShadowOffsetY", "backgroundColor", "borderColor", "borderWidth", "borderRadius", "padding" ], Nc = 0, Rc = ".", Fc = "___EC__COMPONENT__CONTAINER___", Vc = 0, Hc = function(t) {
        for (var e = 0; e < t.length; e++) t[e][1] || (t[e][1] = t[e][0]);
        return function(e, n, i) {
            for (var r = {}, o = 0; o < t.length; o++) {
                var a = t[o][1];
                if (!(n && h(n, a) >= 0 || i && h(i, a) < 0)) {
                    var s = e.getShallow(a);
                    null != s && (r[t[o][0]] = s);
                }
            }
            return r;
        };
    }, Gc = Hc([ [ "lineWidth", "width" ], [ "stroke", "color" ], [ "opacity" ], [ "shadowBlur" ], [ "shadowOffsetX" ], [ "shadowOffsetY" ], [ "shadowColor" ] ]), Wc = {
        getLineStyle: function(t) {
            var e = Gc(this, t);
            return e.lineDash = this.getLineDash(e.lineWidth), e;
        },
        getLineDash: function(t) {
            null == t && (t = 1);
            var e = this.get("type"), n = Math.max(t, 2), i = 4 * t;
            return "solid" !== e && null != e && ("dashed" === e ? [ i, i ] : [ n, n ]);
        }
    }, Xc = Hc([ [ "fill", "color" ], [ "shadowBlur" ], [ "shadowOffsetX" ], [ "shadowOffsetY" ], [ "opacity" ], [ "shadowColor" ] ]), Uc = {
        getAreaStyle: function(t, e) {
            return Xc(this, t, e);
        }
    }, Yc = Math.pow, qc = Math.sqrt, jc = 1e-8, Zc = 1e-4, Kc = qc(3), $c = 1 / 3, Qc = F(), Jc = F(), td = F(), ed = Math.min, nd = Math.max, id = Math.sin, rd = Math.cos, od = 2 * Math.PI, ad = F(), sd = F(), ld = F(), hd = [], ud = [], cd = {
        M: 1,
        L: 2,
        C: 3,
        Q: 4,
        A: 5,
        Z: 6,
        R: 7
    }, dd = [], fd = [], pd = [], gd = [], vd = Math.min, md = Math.max, yd = Math.cos, _d = Math.sin, xd = Math.sqrt, wd = Math.abs, bd = "undefined" != typeof Float32Array, Sd = function(t) {
        this._saveData = !t, this._saveData && (this.data = []), this._ctx = null;
    };
    Sd.prototype = {
        constructor: Sd,
        _xi: 0,
        _yi: 0,
        _x0: 0,
        _y0: 0,
        _ux: 0,
        _uy: 0,
        _len: 0,
        _lineDash: null,
        _dashOffset: 0,
        _dashIdx: 0,
        _dashSum: 0,
        setScale: function(t, e, n) {
            n = n || 0, this._ux = wd(n / Du / t) || 0, this._uy = wd(n / Du / e) || 0;
        },
        getContext: function() {
            return this._ctx;
        },
        beginPath: function(t) {
            return this._ctx = t, t && t.beginPath(), t && (this.dpr = t.dpr), this._saveData && (this._len = 0), 
            this._lineDash && (this._lineDash = null, this._dashOffset = 0), this;
        },
        moveTo: function(t, e) {
            return this.addData(cd.M, t, e), this._ctx && this._ctx.moveTo(t, e), this._x0 = t, 
            this._y0 = e, this._xi = t, this._yi = e, this;
        },
        lineTo: function(t, e) {
            var n = wd(t - this._xi) > this._ux || wd(e - this._yi) > this._uy || this._len < 5;
            return this.addData(cd.L, t, e), this._ctx && n && (this._needsDash() ? this._dashedLineTo(t, e) : this._ctx.lineTo(t, e)), 
            n && (this._xi = t, this._yi = e), this;
        },
        bezierCurveTo: function(t, e, n, i, r, o) {
            return this.addData(cd.C, t, e, n, i, r, o), this._ctx && (this._needsDash() ? this._dashedBezierTo(t, e, n, i, r, o) : this._ctx.bezierCurveTo(t, e, n, i, r, o)), 
            this._xi = r, this._yi = o, this;
        },
        quadraticCurveTo: function(t, e, n, i) {
            return this.addData(cd.Q, t, e, n, i), this._ctx && (this._needsDash() ? this._dashedQuadraticTo(t, e, n, i) : this._ctx.quadraticCurveTo(t, e, n, i)), 
            this._xi = n, this._yi = i, this;
        },
        arc: function(t, e, n, i, r, o) {
            return this.addData(cd.A, t, e, n, n, i, r - i, 0, o ? 0 : 1), this._ctx && this._ctx.arc(t, e, n, i, r, o), 
            this._xi = yd(r) * n + t, this._yi = _d(r) * n + e, this;
        },
        arcTo: function(t, e, n, i, r) {
            return this._ctx && this._ctx.arcTo(t, e, n, i, r), this;
        },
        rect: function(t, e, n, i) {
            return this._ctx && this._ctx.rect(t, e, n, i), this.addData(cd.R, t, e, n, i), 
            this;
        },
        closePath: function() {
            this.addData(cd.Z);
            var t = this._ctx, e = this._x0, n = this._y0;
            return t && (this._needsDash() && this._dashedLineTo(e, n), t.closePath()), this._xi = e, 
            this._yi = n, this;
        },
        fill: function(t) {
            t && t.fill(), this.toStatic();
        },
        stroke: function(t) {
            t && t.stroke(), this.toStatic();
        },
        setLineDash: function(t) {
            if (t instanceof Array) {
                this._lineDash = t, this._dashIdx = 0;
                for (var e = 0, n = 0; n < t.length; n++) e += t[n];
                this._dashSum = e;
            }
            return this;
        },
        setLineDashOffset: function(t) {
            return this._dashOffset = t, this;
        },
        len: function() {
            return this._len;
        },
        setData: function(t) {
            var e = t.length;
            this.data && this.data.length === e || !bd || (this.data = new Float32Array(e));
            for (var n = 0; e > n; n++) this.data[n] = t[n];
            this._len = e;
        },
        appendPath: function(t) {
            t instanceof Array || (t = [ t ]);
            for (var e = t.length, n = 0, i = this._len, r = 0; e > r; r++) n += t[r].len();
            bd && this.data instanceof Float32Array && (this.data = new Float32Array(i + n));
            for (r = 0; e > r; r++) for (var o = t[r].data, a = 0; a < o.length; a++) this.data[i++] = o[a];
            this._len = i;
        },
        addData: function(t) {
            if (this._saveData) {
                var e = this.data;
                this._len + arguments.length > e.length && (this._expandData(), e = this.data);
                for (var n = 0; n < arguments.length; n++) e[this._len++] = arguments[n];
                this._prevCmd = t;
            }
        },
        _expandData: function() {
            if (!(this.data instanceof Array)) {
                for (var t = [], e = 0; e < this._len; e++) t[e] = this.data[e];
                this.data = t;
            }
        },
        _needsDash: function() {
            return this._lineDash;
        },
        _dashedLineTo: function(t, e) {
            var n, i, r = this._dashSum, o = this._dashOffset, a = this._lineDash, s = this._ctx, l = this._xi, h = this._yi, u = t - l, c = e - h, d = xd(u * u + c * c), f = l, p = h, g = a.length;
            for (0 > o && (o = r + o), f -= (o %= r) * (u /= d), p -= o * (c /= d); u > 0 && t >= f || 0 > u && f >= t || 0 === u && (c > 0 && e >= p || 0 > c && p >= e); ) f += u * (n = a[i = this._dashIdx]), 
            p += c * n, this._dashIdx = (i + 1) % g, u > 0 && l > f || 0 > u && f > l || c > 0 && h > p || 0 > c && p > h || s[i % 2 ? "moveTo" : "lineTo"](u >= 0 ? vd(f, t) : md(f, t), c >= 0 ? vd(p, e) : md(p, e));
            u = f - t, c = p - e, this._dashOffset = -xd(u * u + c * c);
        },
        _dashedBezierTo: function(t, e, n, i, r, o) {
            var a, s, l, h, u, c = this._dashSum, d = this._dashOffset, f = this._lineDash, p = this._ctx, g = this._xi, v = this._yi, m = Ln, y = 0, _ = this._dashIdx, x = f.length, w = 0;
            for (0 > d && (d = c + d), d %= c, a = 0; 1 > a; a += .1) s = m(g, t, n, r, a + .1) - m(g, t, n, r, a), 
            l = m(v, e, i, o, a + .1) - m(v, e, i, o, a), y += xd(s * s + l * l);
            for (;x > _ && !((w += f[_]) > d); _++) ;
            for (a = (w - d) / y; 1 >= a; ) h = m(g, t, n, r, a), u = m(v, e, i, o, a), _ % 2 ? p.moveTo(h, u) : p.lineTo(h, u), 
            a += f[_] / y, _ = (_ + 1) % x;
            _ % 2 != 0 && p.lineTo(r, o), s = r - h, l = o - u, this._dashOffset = -xd(s * s + l * l);
        },
        _dashedQuadraticTo: function(t, e, n, i) {
            var r = n, o = i;
            n = (n + 2 * t) / 3, i = (i + 2 * e) / 3, t = (this._xi + 2 * t) / 3, e = (this._yi + 2 * e) / 3, 
            this._dashedBezierTo(t, e, n, i, r, o);
        },
        toStatic: function() {
            var t = this.data;
            t instanceof Array && (t.length = this._len, bd && (this.data = new Float32Array(t)));
        },
        getBoundingRect: function() {
            dd[0] = dd[1] = pd[0] = pd[1] = Number.MAX_VALUE, fd[0] = fd[1] = gd[0] = gd[1] = -Number.MAX_VALUE;
            for (var t = this.data, e = 0, n = 0, i = 0, r = 0, o = 0; o < t.length; ) {
                var a = t[o++];
                switch (1 === o && (i = e = t[o], r = n = t[o + 1]), a) {
                  case cd.M:
                    e = i = t[o++], n = r = t[o++], pd[0] = i, pd[1] = r, gd[0] = i, gd[1] = r;
                    break;

                  case cd.L:
                    Hn(e, n, t[o], t[o + 1], pd, gd), e = t[o++], n = t[o++];
                    break;

                  case cd.C:
                    Gn(e, n, t[o++], t[o++], t[o++], t[o++], t[o], t[o + 1], pd, gd), e = t[o++], n = t[o++];
                    break;

                  case cd.Q:
                    Wn(e, n, t[o++], t[o++], t[o], t[o + 1], pd, gd), e = t[o++], n = t[o++];
                    break;

                  case cd.A:
                    var s = t[o++], l = t[o++], h = t[o++], u = t[o++], c = t[o++], d = t[o++] + c;
                    o += 1;
                    var f = 1 - t[o++];
                    1 === o && (i = yd(c) * h + s, r = _d(c) * u + l), Xn(s, l, h, u, c, d, f, pd, gd), 
                    e = yd(d) * h + s, n = _d(d) * u + l;
                    break;

                  case cd.R:
                    Hn(i = e = t[o++], r = n = t[o++], i + t[o++], r + t[o++], pd, gd);
                    break;

                  case cd.Z:
                    e = i, n = r;
                }
                Q(dd, dd, pd), J(fd, fd, gd);
            }
            return 0 === o && (dd[0] = dd[1] = fd[0] = fd[1] = 0), new ie(dd[0], dd[1], fd[0] - dd[0], fd[1] - dd[1]);
        },
        rebuildPath: function(t) {
            for (var e, n, i, r, o, a, s = this.data, l = this._ux, h = this._uy, u = this._len, c = 0; u > c; ) {
                var d = s[c++];
                switch (1 === c && (e = i = s[c], n = r = s[c + 1]), d) {
                  case cd.M:
                    e = i = s[c++], n = r = s[c++], t.moveTo(i, r);
                    break;

                  case cd.L:
                    o = s[c++], a = s[c++], (wd(o - i) > l || wd(a - r) > h || c === u - 1) && (t.lineTo(o, a), 
                    i = o, r = a);
                    break;

                  case cd.C:
                    t.bezierCurveTo(s[c++], s[c++], s[c++], s[c++], s[c++], s[c++]), i = s[c - 2], r = s[c - 1];
                    break;

                  case cd.Q:
                    t.quadraticCurveTo(s[c++], s[c++], s[c++], s[c++]), i = s[c - 2], r = s[c - 1];
                    break;

                  case cd.A:
                    var f = s[c++], p = s[c++], g = s[c++], v = s[c++], m = s[c++], y = s[c++], _ = s[c++], x = s[c++], w = g > v ? g : v, b = g > v ? 1 : g / v, S = g > v ? v / g : 1, M = m + y;
                    Math.abs(g - v) > .001 ? (t.translate(f, p), t.rotate(_), t.scale(b, S), t.arc(0, 0, w, m, M, 1 - x), 
                    t.scale(1 / b, 1 / S), t.rotate(-_), t.translate(-f, -p)) : t.arc(f, p, w, m, M, 1 - x), 
                    1 === c && (e = yd(m) * g + f, n = _d(m) * v + p), i = yd(M) * g + f, r = _d(M) * v + p;
                    break;

                  case cd.R:
                    e = i = s[c], n = r = s[c + 1], t.rect(s[c++], s[c++], s[c++], s[c++]);
                    break;

                  case cd.Z:
                    t.closePath(), i = e, r = n;
                }
            }
        }
    }, Sd.CMD = cd;
    var Md = 2 * Math.PI, Id = 2 * Math.PI, Td = Sd.CMD, Cd = 2 * Math.PI, Ad = 1e-4, Dd = [ -1, -1, -1 ], kd = [ -1, -1 ], Pd = Ku.prototype.getCanvasPattern, Ld = Math.abs, Od = new Sd(!0);
    ni.prototype = {
        constructor: ni,
        type: "path",
        __dirtyPath: !0,
        strokeContainThreshold: 5,
        segmentIgnoreThreshold: 0,
        subPixelOptimize: !1,
        brush: function(t, e) {
            var n, i = this.style, r = this.path || Od, o = i.hasStroke(), a = i.hasFill(), s = i.fill, l = i.stroke, h = a && !!s.colorStops, u = o && !!l.colorStops, c = a && !!s.image, d = o && !!l.image;
            (i.bind(t, this, e), this.setTransform(t), this.__dirty) && (h && (n = n || this.getBoundingRect(), 
            this._fillGradient = i.getGradient(t, s, n)), u && (n = n || this.getBoundingRect(), 
            this._strokeGradient = i.getGradient(t, l, n)));
            h ? t.fillStyle = this._fillGradient : c && (t.fillStyle = Pd.call(s, t)), u ? t.strokeStyle = this._strokeGradient : d && (t.strokeStyle = Pd.call(l, t));
            var f = i.lineDash, p = i.lineDashOffset, g = !!t.setLineDash, v = this.getGlobalScale();
            if (r.setScale(v[0], v[1], this.segmentIgnoreThreshold), this.__dirtyPath || f && !g && o ? (r.beginPath(t), 
            f && !g && (r.setLineDash(f), r.setLineDashOffset(p)), this.buildPath(r, this.shape, !1), 
            this.path && (this.__dirtyPath = !1)) : (t.beginPath(), this.path.rebuildPath(t)), 
            a) if (null != i.fillOpacity) {
                var m = t.globalAlpha;
                t.globalAlpha = i.fillOpacity * i.opacity, r.fill(t), t.globalAlpha = m;
            } else r.fill(t);
            if (f && g && (t.setLineDash(f), t.lineDashOffset = p), o) if (null != i.strokeOpacity) {
                m = t.globalAlpha;
                t.globalAlpha = i.strokeOpacity * i.opacity, r.stroke(t), t.globalAlpha = m;
            } else r.stroke(t);
            f && g && t.setLineDash([]), null != i.text && (this.restoreTransform(t), this.drawRectText(t, this.getBoundingRect()));
        },
        buildPath: function() {},
        createPathProxy: function() {
            this.path = new Sd();
        },
        getBoundingRect: function() {
            var t = this._rect, e = this.style, n = !t;
            if (n) {
                var i = this.path;
                i || (i = this.path = new Sd()), this.__dirtyPath && (i.beginPath(), this.buildPath(i, this.shape, !1)), 
                t = i.getBoundingRect();
            }
            if (this._rect = t, e.hasStroke()) {
                var r = this._rectWithStroke || (this._rectWithStroke = t.clone());
                if (this.__dirty || n) {
                    r.copy(t);
                    var o = e.lineWidth, a = e.strokeNoScale ? this.getLineScale() : 1;
                    e.hasFill() || (o = Math.max(o, this.strokeContainThreshold || 4)), a > 1e-10 && (r.width += o / a, 
                    r.height += o / a, r.x -= o / a / 2, r.y -= o / a / 2);
                }
                return r;
            }
            return t;
        },
        contain: function(t, e) {
            var n = this.transformCoordToLocal(t, e), i = this.getBoundingRect(), r = this.style;
            if (t = n[0], e = n[1], i.contain(t, e)) {
                var o = this.path.data;
                if (r.hasStroke()) {
                    var a = r.lineWidth, s = r.strokeNoScale ? this.getLineScale() : 1;
                    if (s > 1e-10 && (r.hasFill() || (a = Math.max(a, this.strokeContainThreshold)), 
                    function(t, e, n, i) {
                        return ei(t, e, !0, n, i);
                    }(o, a / s, t, e))) return !0;
                }
                if (r.hasFill()) return function(t, e, n) {
                    return ei(t, 0, !1, e, n);
                }(o, t, e);
            }
            return !1;
        },
        dirty: function(t) {
            null == t && (t = !0), t && (this.__dirtyPath = t, this._rect = null), this.__dirty = this.__dirtyText = !0, 
            this.__zr && this.__zr.refresh(), this.__clipTarget && this.__clipTarget.dirty();
        },
        animateShape: function(t) {
            return this.animate("shape", t);
        },
        attrKV: function(t, e) {
            "shape" === t ? (this.setShape(e), this.__dirtyPath = !0, this._rect = null) : Ze.prototype.attrKV.call(this, t, e);
        },
        setShape: function(t, e) {
            var n = this.shape;
            if (n) {
                if (b(t)) for (var i in t) t.hasOwnProperty(i) && (n[i] = t[i]); else n[t] = e;
                this.dirty(!0);
            }
            return this;
        },
        getLineScale: function() {
            var t = this.transform;
            return t && Ld(t[0] - 1) > 1e-10 && Ld(t[3] - 1) > 1e-10 ? Math.sqrt(Ld(t[0] * t[3] - t[2] * t[1])) : 1;
        }
    }, ni.extend = function(t) {
        var e = function(e) {
            ni.call(this, e), t.style && this.style.extendFrom(t.style, !1);
            var n = t.shape;
            if (n) {
                this.shape = this.shape || {};
                var i = this.shape;
                for (var r in n) !i.hasOwnProperty(r) && n.hasOwnProperty(r) && (i[r] = n[r]);
            }
            t.init && t.init.call(this, e);
        };
        for (var n in u(e, ni), t) "style" !== n && "shape" !== n && (e.prototype[n] = t[n]);
        return e;
    }, u(ni, Ze);
    var Ed = Sd.CMD, Bd = [ [], [], [] ], zd = Math.sqrt, Nd = Math.atan2, Rd = function(t, e) {
        var n, i, r, o, a, s = t.data, l = Ed.M, h = Ed.C, u = Ed.L, c = Ed.R, d = Ed.A, f = Ed.Q;
        for (r = 0, o = 0; r < s.length; ) {
            switch (n = s[r++], o = r, i = 0, n) {
              case l:
              case u:
                i = 1;
                break;

              case h:
                i = 3;
                break;

              case f:
                i = 2;
                break;

              case d:
                var p = e[4], g = e[5], v = zd(e[0] * e[0] + e[1] * e[1]), m = zd(e[2] * e[2] + e[3] * e[3]), y = Nd(-e[1] / m, e[0] / v);
                s[r] *= v, s[r++] += p, s[r] *= m, s[r++] += g, s[r++] *= v, s[r++] *= m, s[r++] += y, 
                s[r++] += y, o = r += 2;
                break;

              case c:
                _[0] = s[r++], _[1] = s[r++], $(_, _, e), s[o++] = _[0], s[o++] = _[1], _[0] += s[r++], 
                _[1] += s[r++], $(_, _, e), s[o++] = _[0], s[o++] = _[1];
            }
            for (a = 0; i > a; a++) {
                var _;
                (_ = Bd[a])[0] = s[r++], _[1] = s[r++], $(_, _, e), s[o++] = _[0], s[o++] = _[1];
            }
        }
    }, Fd = Math.sqrt, Vd = Math.sin, Hd = Math.cos, Gd = Math.PI, Wd = function(t) {
        return Math.sqrt(t[0] * t[0] + t[1] * t[1]);
    }, Xd = function(t, e) {
        return (t[0] * e[0] + t[1] * e[1]) / (Wd(t) * Wd(e));
    }, Ud = function(t, e) {
        return (t[0] * e[1] < t[1] * e[0] ? -1 : 1) * Math.acos(Xd(t, e));
    }, Yd = /([mlvhzcqtsa])([^mlvhzcqtsa]*)/gi, qd = /-?([0-9]*\.)?[0-9]+([eE]-?[0-9]+)?/g, jd = function(t) {
        Ze.call(this, t);
    };
    jd.prototype = {
        constructor: jd,
        type: "text",
        brush: function(t, e) {
            var n = this.style;
            this.__dirty && Ee(n), n.fill = n.stroke = n.shadowBlur = n.shadowColor = n.shadowOffsetX = n.shadowOffsetY = null;
            var i = n.text;
            return null != i && (i += ""), je(i, n) ? (this.setTransform(t), ze(this, t, i, n, null, e), 
            void this.restoreTransform(t)) : void (t.__attrCachedBy = Wu.NONE);
        },
        getBoundingRect: function() {
            var t = this.style;
            if (this.__dirty && Ee(t), !this._rect) {
                var e = t.text;
                null != e ? e += "" : e = "";
                var n = xe(t.text + "", t.font, t.textAlign, t.textVerticalAlign, t.textPadding, t.textLineHeight, t.rich);
                if (n.x += t.x || 0, n.y += t.y || 0, Xe(t.textStroke, t.textStrokeWidth)) {
                    var i = t.textStrokeWidth;
                    n.x -= i / 2, n.y -= i / 2, n.width += i, n.height += i;
                }
                this._rect = n;
            }
            return this._rect;
        }
    }, u(jd, Ze);
    var Zd = ni.extend({
        type: "circle",
        shape: {
            cx: 0,
            cy: 0,
            r: 0
        },
        buildPath: function(t, e, n) {
            n && t.moveTo(e.cx + e.r, e.cy), t.arc(e.cx, e.cy, e.r, 0, 2 * Math.PI, !0);
        }
    }), Kd = [ [ "shadowBlur", 0 ], [ "shadowColor", "#000" ], [ "shadowOffsetX", 0 ], [ "shadowOffsetY", 0 ] ], $d = function(t) {
        return Mh.browser.ie && Mh.browser.version >= 11 ? function() {
            var e, n = this.__clipPaths, i = this.style;
            if (n) for (var r = 0; r < n.length; r++) {
                var o = n[r], a = o && o.shape, s = o && o.type;
                if (a && ("sector" === s && a.startAngle === a.endAngle || "rect" === s && (!a.width || !a.height))) {
                    for (var l = 0; l < Kd.length; l++) Kd[l][2] = i[Kd[l][0]], i[Kd[l][0]] = Kd[l][1];
                    e = !0;
                    break;
                }
            }
            if (t.apply(this, arguments), e) for (l = 0; l < Kd.length; l++) i[Kd[l][0]] = Kd[l][2];
        } : t;
    }, Qd = ni.extend({
        type: "sector",
        shape: {
            cx: 0,
            cy: 0,
            r0: 0,
            r: 0,
            startAngle: 0,
            endAngle: 2 * Math.PI,
            clockwise: !0
        },
        brush: $d(ni.prototype.brush),
        buildPath: function(t, e) {
            var n = e.cx, i = e.cy, r = Math.max(e.r0 || 0, 0), o = Math.max(e.r, 0), a = e.startAngle, s = e.endAngle, l = e.clockwise, h = Math.cos(a), u = Math.sin(a);
            t.moveTo(h * r + n, u * r + i), t.lineTo(h * o + n, u * o + i), t.arc(n, i, o, a, s, !l), 
            t.lineTo(Math.cos(s) * r + n, Math.sin(s) * r + i), 0 !== r && t.arc(n, i, r, s, a, l), 
            t.closePath();
        }
    }), Jd = ni.extend({
        type: "ring",
        shape: {
            cx: 0,
            cy: 0,
            r: 0,
            r0: 0
        },
        buildPath: function(t, e) {
            var n = e.cx, i = e.cy, r = 2 * Math.PI;
            t.moveTo(n + e.r, i), t.arc(n, i, e.r, 0, r, !1), t.moveTo(n + e.r0, i), t.arc(n, i, e.r0, 0, r, !0);
        }
    }), tf = function(t, e) {
        for (var n = t.length, i = [], r = 0, o = 1; n > o; o++) r += Z(t[o - 1], t[o]);
        var a = r / 2;
        a = n > a ? n : a;
        for (o = 0; a > o; o++) {
            var s, l, h, u = o / (a - 1) * (e ? n : n - 1), c = Math.floor(u), d = u - c, f = t[c % n];
            e ? (s = t[(c - 1 + n) % n], l = t[(c + 1) % n], h = t[(c + 2) % n]) : (s = t[0 === c ? c : c - 1], 
            l = t[c > n - 2 ? n - 1 : c + 1], h = t[c > n - 3 ? n - 1 : c + 2]);
            var p = d * d, g = d * p;
            i.push([ ai(s[0], f[0], l[0], h[0], d, p, g), ai(s[1], f[1], l[1], h[1], d, p, g) ]);
        }
        return i;
    }, ef = function(t, e, n, i) {
        var r, o, a, s, l = [], h = [], u = [], c = [];
        if (i) {
            a = [ 1 / 0, 1 / 0 ], s = [ -1 / 0, -1 / 0 ];
            for (var d = 0, f = t.length; f > d; d++) Q(a, a, t[d]), J(s, s, t[d]);
            Q(a, a, i[0]), J(s, s, i[1]);
        }
        for (d = 0, f = t.length; f > d; d++) {
            var p = t[d];
            if (n) r = t[d ? d - 1 : f - 1], o = t[(d + 1) % f]; else {
                if (0 === d || d === f - 1) {
                    l.push(H(t[d]));
                    continue;
                }
                r = t[d - 1], o = t[d + 1];
            }
            X(h, o, r), q(h, h, e);
            var g = Z(p, r), v = Z(p, o), m = g + v;
            0 !== m && (g /= m, v /= m), q(u, h, -g), q(c, h, v);
            var y = G([], p, u), _ = G([], p, c);
            i && (J(y, y, a), Q(y, y, s), J(_, _, a), Q(_, _, s)), l.push(y), l.push(_);
        }
        return n && l.push(l.shift()), l;
    }, nf = ni.extend({
        type: "polygon",
        shape: {
            points: null,
            smooth: !1,
            smoothConstraint: null
        },
        buildPath: function(t, e) {
            si(t, e, !0);
        }
    }), rf = ni.extend({
        type: "polyline",
        shape: {
            points: null,
            smooth: !1,
            smoothConstraint: null
        },
        style: {
            stroke: "#000",
            fill: null
        },
        buildPath: function(t, e) {
            si(t, e, !1);
        }
    }), of = Math.round, af = {}, sf = ni.extend({
        type: "rect",
        shape: {
            r: 0,
            x: 0,
            y: 0,
            width: 0,
            height: 0
        },
        buildPath: function(t, e) {
            var n, i, r, o;
            this.subPixelOptimize ? (hi(af, e, this.style), n = af.x, i = af.y, r = af.width, 
            o = af.height, af.r = e.r, e = af) : (n = e.x, i = e.y, r = e.width, o = e.height), 
            e.r ? Oe(t, e) : t.rect(n, i, r, o), t.closePath();
        }
    }), lf = {}, hf = ni.extend({
        type: "line",
        shape: {
            x1: 0,
            y1: 0,
            x2: 0,
            y2: 0,
            percent: 1
        },
        style: {
            stroke: "#000",
            fill: null
        },
        buildPath: function(t, e) {
            var n, i, r, o;
            this.subPixelOptimize ? (li(lf, e, this.style), n = lf.x1, i = lf.y1, r = lf.x2, 
            o = lf.y2) : (n = e.x1, i = e.y1, r = e.x2, o = e.y2);
            var a = e.percent;
            0 !== a && (t.moveTo(n, i), 1 > a && (r = n * (1 - a) + r * a, o = i * (1 - a) + o * a), 
            t.lineTo(r, o));
        },
        pointAt: function(t) {
            var e = this.shape;
            return [ e.x1 * (1 - t) + e.x2 * t, e.y1 * (1 - t) + e.y2 * t ];
        }
    }), uf = [], cf = ni.extend({
        type: "bezier-curve",
        shape: {
            x1: 0,
            y1: 0,
            x2: 0,
            y2: 0,
            cpx1: 0,
            cpy1: 0,
            percent: 1
        },
        style: {
            stroke: "#000",
            fill: null
        },
        buildPath: function(t, e) {
            var n = e.x1, i = e.y1, r = e.x2, o = e.y2, a = e.cpx1, s = e.cpy1, l = e.cpx2, h = e.cpy2, u = e.percent;
            0 !== u && (t.moveTo(n, i), null == l || null == h ? (1 > u && (Fn(n, a, r, u, uf), 
            a = uf[1], r = uf[2], Fn(i, s, o, u, uf), s = uf[1], o = uf[2]), t.quadraticCurveTo(a, s, r, o)) : (1 > u && (Bn(n, a, l, r, u, uf), 
            a = uf[1], l = uf[2], r = uf[3], Bn(i, s, h, o, u, uf), s = uf[1], h = uf[2], o = uf[3]), 
            t.bezierCurveTo(a, s, l, h, r, o)));
        },
        pointAt: function(t) {
            return ci(this.shape, t, !1);
        },
        tangentAt: function(t) {
            var e = ci(this.shape, t, !0);
            return j(e, e);
        }
    }), df = ni.extend({
        type: "arc",
        shape: {
            cx: 0,
            cy: 0,
            r: 0,
            startAngle: 0,
            endAngle: 2 * Math.PI,
            clockwise: !0
        },
        style: {
            stroke: "#000",
            fill: null
        },
        buildPath: function(t, e) {
            var n = e.cx, i = e.cy, r = Math.max(e.r, 0), o = e.startAngle, a = e.endAngle, s = e.clockwise, l = Math.cos(o), h = Math.sin(o);
            t.moveTo(l * r + n, h * r + i), t.arc(n, i, r, o, a, !s);
        }
    }), ff = ni.extend({
        type: "compound",
        shape: {
            paths: null
        },
        _updatePathDirty: function() {
            for (var t = this.__dirtyPath, e = this.shape.paths, n = 0; n < e.length; n++) t = t || e[n].__dirtyPath;
            this.__dirtyPath = t, this.__dirty = this.__dirty || t;
        },
        beforeBrush: function() {
            this._updatePathDirty();
            for (var t = this.shape.paths || [], e = this.getGlobalScale(), n = 0; n < t.length; n++) t[n].path || t[n].createPathProxy(), 
            t[n].path.setScale(e[0], e[1], t[n].segmentIgnoreThreshold);
        },
        buildPath: function(t, e) {
            for (var n = e.paths || [], i = 0; i < n.length; i++) n[i].buildPath(t, n[i].shape, !0);
        },
        afterBrush: function() {
            for (var t = this.shape.paths || [], e = 0; e < t.length; e++) t[e].__dirtyPath = !1;
        },
        getBoundingRect: function() {
            return this._updatePathDirty(), ni.prototype.getBoundingRect.call(this);
        }
    }), pf = function(t) {
        this.colorStops = t || [];
    };
    pf.prototype = {
        constructor: pf,
        addColorStop: function(t, e) {
            this.colorStops.push({
                offset: t,
                color: e
            });
        }
    };
    var gf = function(t, e, n, i, r, o) {
        this.x = null == t ? 0 : t, this.y = null == e ? 0 : e, this.x2 = null == n ? 1 : n, 
        this.y2 = null == i ? 0 : i, this.type = "linear", this.global = o || !1, pf.call(this, r);
    };
    gf.prototype = {
        constructor: gf
    }, u(gf, pf);
    var vf = function(t, e, n, i, r) {
        this.x = null == t ? .5 : t, this.y = null == e ? .5 : e, this.r = null == n ? .5 : n, 
        this.type = "radial", this.global = r || !1, pf.call(this, i);
    };
    vf.prototype = {
        constructor: vf
    }, u(vf, pf), di.prototype.incremental = !0, di.prototype.clearDisplaybles = function() {
        this._displayables = [], this._temporaryDisplayables = [], this._cursor = 0, this.dirty(), 
        this.notClear = !1;
    }, di.prototype.addDisplayable = function(t, e) {
        e ? this._temporaryDisplayables.push(t) : this._displayables.push(t), this.dirty();
    }, di.prototype.addDisplayables = function(t, e) {
        e = e || !1;
        for (var n = 0; n < t.length; n++) this.addDisplayable(t[n], e);
    }, di.prototype.eachPendingDisplayable = function(t) {
        for (var e = this._cursor; e < this._displayables.length; e++) t && t(this._displayables[e]);
        for (e = 0; e < this._temporaryDisplayables.length; e++) t && t(this._temporaryDisplayables[e]);
    }, di.prototype.update = function() {
        this.updateTransform();
        for (var t = this._cursor; t < this._displayables.length; t++) {
            (e = this._displayables[t]).parent = this, e.update(), e.parent = null;
        }
        for (t = 0; t < this._temporaryDisplayables.length; t++) {
            var e;
            (e = this._temporaryDisplayables[t]).parent = this, e.update(), e.parent = null;
        }
    }, di.prototype.brush = function(t) {
        for (var e = this._cursor; e < this._displayables.length; e++) {
            (n = this._displayables[e]).beforeBrush && n.beforeBrush(t), n.brush(t, e === this._cursor ? null : this._displayables[e - 1]), 
            n.afterBrush && n.afterBrush(t);
        }
        this._cursor = e;
        for (e = 0; e < this._temporaryDisplayables.length; e++) {
            var n;
            (n = this._temporaryDisplayables[e]).beforeBrush && n.beforeBrush(t), n.brush(t, 0 === e ? null : this._temporaryDisplayables[e - 1]), 
            n.afterBrush && n.afterBrush(t);
        }
        this._temporaryDisplayables = [], this.notClear = !0;
    };
    var mf = [];
    di.prototype.getBoundingRect = function() {
        if (!this._rect) {
            for (var t = new ie(1 / 0, 1 / 0, -1 / 0, -1 / 0), e = 0; e < this._displayables.length; e++) {
                var n = this._displayables[e], i = n.getBoundingRect().clone();
                n.needLocalTransform() && i.applyTransform(n.getLocalTransform(mf)), t.union(i);
            }
            this._rect = t;
        }
        return this._rect;
    }, di.prototype.contain = function(t, e) {
        var n = this.transformCoordToLocal(t, e);
        if (this.getBoundingRect().contain(n[0], n[1])) for (var i = 0; i < this._displayables.length; i++) {
            if (this._displayables[i].contain(t, e)) return !0;
        }
        return !1;
    }, u(di, Ze);
    var yf = Math.max, _f = Math.min, xf = {}, wf = 1, bf = "emphasis", Sf = "normal", Mf = 1, If = {}, Tf = {}, Cf = function(t, e) {
        for (var n = [], i = t.length, r = 0; i > r; r++) {
            var o = t[r];
            o.path || o.createPathProxy(), o.__dirtyPath && o.buildPath(o.path, o.shape, !0), 
            n.push(o.path);
        }
        var a = new ni(e);
        return a.createPathProxy(), a.buildPath = function(t) {
            t.appendPath(n);
            var e = t.getContext();
            e && t.rebuildPath(e);
        }, a;
    }, Af = ui, Df = N(), kf = 0;
    pi("circle", Zd), pi("sector", Qd), pi("ring", Jd), pi("polygon", nf), pi("polyline", rf), 
    pi("rect", sf), pi("line", hf), pi("bezierCurve", cf), pi("arc", df);
    var Pf = (Object.freeze || Object)({
        Z2_EMPHASIS_LIFT: wf,
        CACHED_LABEL_STYLE_PROPERTIES: {
            color: "textFill",
            textBorderColor: "textStroke",
            textBorderWidth: "textStrokeWidth"
        },
        extendShape: fi,
        extendPath: function(t, e) {
            return function(t, e) {
                return ni.extend(ri(t, e));
            }(t, e);
        },
        registerShape: pi,
        getShapeClass: function(t) {
            return Tf.hasOwnProperty(t) ? Tf[t] : void 0;
        },
        makePath: gi,
        makeImage: vi,
        mergePath: Cf,
        resizePath: yi,
        subPixelOptimizeLine: function(t) {
            return li(t.shape, t.shape, t.style), t;
        },
        subPixelOptimizeRect: function(t) {
            return hi(t.shape, t.shape, t.style), t;
        },
        subPixelOptimize: Af,
        setElementHoverStyle: Mi,
        setHoverStyle: ki,
        setAsHighDownDispatcher: Pi,
        isHighDownDispatcher: Li,
        getHighlightDigit: Oi,
        setLabelStyle: Ei,
        modifyLabelStyle: function(t, e, n) {
            var i = t.style;
            e && (Vi(i), t.setStyle(e), Fi(i)), i = t.__hoverStl, n && i && (Vi(i), a(i, n), 
            Fi(i));
        },
        setTextStyle: Bi,
        setText: function(t, e, n) {
            var i, r = {
                isRectText: !0
            };
            !1 === n ? i = !0 : r.autoColor = n, zi(t, e, r, i);
        },
        getFont: Hi,
        updateProps: Wi,
        initProps: Xi,
        getTransform: function(t, e) {
            for (var n = yt([]); t && t !== e; ) xt(n, t.getLocalTransform(), n), t = t.parent;
            return n;
        },
        applyTransform: Ui,
        transformDirection: function(t, e, n) {
            var i = 0 === e[4] || 0 === e[5] || 0 === e[0] ? 1 : Math.abs(2 * e[4] / e[0]), r = 0 === e[4] || 0 === e[5] || 0 === e[2] ? 1 : Math.abs(2 * e[4] / e[2]), o = [ "left" === t ? -i : "right" === t ? i : 0, "top" === t ? -r : "bottom" === t ? r : 0 ];
            return o = Ui(o, e, n), Math.abs(o[0]) > Math.abs(o[1]) ? o[0] > 0 ? "right" : "left" : o[1] > 0 ? "bottom" : "top";
        },
        groupTransition: Yi,
        clipPointsByRect: function(t, e) {
            return p(t, function(t) {
                var n = t[0];
                n = yf(n, e.x), n = _f(n, e.x + e.width);
                var i = t[1];
                return i = yf(i, e.y), [ n, i = _f(i, e.y + e.height) ];
            });
        },
        clipRectByRect: function(t, e) {
            var n = yf(t.x, e.x), i = _f(t.x + t.width, e.x + e.width), r = yf(t.y, e.y), o = _f(t.y + t.height, e.y + e.height);
            return i >= n && o >= r ? {
                x: n,
                y: r,
                width: i - n,
                height: o - r
            } : void 0;
        },
        createIcon: qi,
        linePolygonIntersect: function(t, e, n, i, r) {
            for (var o = 0, a = r[r.length - 1]; o < r.length; o++) {
                var s = r[o];
                if (ji(t, e, n, i, s[0], s[1], a[0], a[1])) return !0;
                a = s;
            }
        },
        lineLineIntersect: ji,
        Group: Nu,
        Image: Ke,
        Text: jd,
        Circle: Zd,
        Sector: Qd,
        Ring: Jd,
        Polygon: nf,
        Polyline: rf,
        Rect: sf,
        Line: hf,
        BezierCurve: cf,
        Arc: df,
        IncrementalDisplayable: di,
        CompoundPath: ff,
        LinearGradient: gf,
        RadialGradient: vf,
        BoundingRect: ie
    }), Lf = [ "textStyle", "color" ], Of = {
        getTextColor: function(t) {
            var e = this.ecModel;
            return this.getShallow("color") || (!t && e ? e.get(Lf) : null);
        },
        getFont: function() {
            return Hi({
                fontStyle: this.getShallow("fontStyle"),
                fontWeight: this.getShallow("fontWeight"),
                fontSize: this.getShallow("fontSize"),
                fontFamily: this.getShallow("fontFamily")
            }, this.ecModel);
        },
        getTextRect: function(t) {
            return xe(t, this.getFont(), this.getShallow("align"), this.getShallow("verticalAlign") || this.getShallow("baseline"), this.getShallow("padding"), this.getShallow("lineHeight"), this.getShallow("rich"), this.getShallow("truncateText"));
        }
    }, Ef = Hc([ [ "fill", "color" ], [ "stroke", "borderColor" ], [ "lineWidth", "borderWidth" ], [ "opacity" ], [ "shadowBlur" ], [ "shadowOffsetX" ], [ "shadowOffsetY" ], [ "shadowColor" ], [ "textPosition" ], [ "textAlign" ] ]), Bf = {
        getItemStyle: function(t, e) {
            var n = Ef(this, t, e), i = this.getBorderLineDash();
            return i && (n.lineDash = i), n;
        },
        getBorderLineDash: function() {
            var t = this.get("borderType");
            return "solid" === t || null == t ? null : "dashed" === t ? [ 5, 5 ] : [ 1, 1 ];
        }
    }, zf = c, Nf = _n();
    Ki.prototype = {
        constructor: Ki,
        init: null,
        mergeOption: function(t) {
            r(this.option, t, !0);
        },
        get: function(t, e) {
            return null == t ? this.option : $i(this.option, this.parsePath(t), !e && Qi(this, t));
        },
        getShallow: function(t, e) {
            var n = this.option, i = null == n ? n : n[t], r = !e && Qi(this, t);
            return null == i && r && (i = r.getShallow(t)), i;
        },
        getModel: function(t, e) {
            var n;
            return new Ki(null == t ? this.option : $i(this.option, t = this.parsePath(t)), e = e || (n = Qi(this, t)) && n.getModel(t), this.ecModel);
        },
        isEmpty: function() {
            return null == this.option;
        },
        restoreData: function() {},
        clone: function() {
            return new (0, this.constructor)(i(this.option));
        },
        setReadOnly: function() {},
        parsePath: function(t) {
            return "string" == typeof t && (t = t.split(".")), t;
        },
        customizeGetParent: function(t) {
            Nf(this).getParent = t;
        },
        isAnimationEnabled: function() {
            if (!Mh.node) {
                if (null != this.option.animation) return !!this.option.animation;
                if (this.parentModel) return this.parentModel.isAnimationEnabled();
            }
        }
    }, In(Ki), Tn(Ki), zf(Ki, Wc), zf(Ki, Uc), zf(Ki, Of), zf(Ki, Bf);
    var Rf = 0, Ff = 1e-4, Vf = /^(?:(\d{4})(?:[-\/](\d{1,2})(?:[-\/](\d{1,2})(?:[T ](\d{1,2})(?::(\d\d)(?::(\d\d)(?:[.,](\d+))?)?)?(Z|[\+\-]\d\d:?\d\d)?)?)?)?)?$/, Hf = (Object.freeze || Object)({
        linearMap: tr,
        parsePercent: er,
        round: nr,
        asc: function(t) {
            return t.sort(function(t, e) {
                return t - e;
            }), t;
        },
        getPrecision: function(t) {
            if (t = +t, isNaN(t)) return 0;
            for (var e = 1, n = 0; Math.round(t * e) / e !== t; ) e *= 10, n++;
            return n;
        },
        getPrecisionSafe: ir,
        getPixelPrecision: rr,
        getPercentWithPrecision: or,
        MAX_SAFE_INTEGER: 9007199254740991,
        remRadian: ar,
        isRadianAroundZero: sr,
        parseDate: lr,
        quantity: hr,
        quantityExponent: ur,
        nice: cr,
        quantile: function(t, e) {
            var n = (t.length - 1) * e + 1, i = Math.floor(n), r = +t[i - 1], o = n - i;
            return o ? r + o * (t[i] - r) : r;
        },
        reformIntervals: function(t) {
            t.sort(function(t, e) {
                return function t(e, n, i) {
                    return e.interval[i] < n.interval[i] || e.interval[i] === n.interval[i] && (e.close[i] - n.close[i] == (i ? -1 : 1) || !i && t(e, n, 1));
                }(t, e, 0) ? -1 : 1;
            });
            for (var e = -1 / 0, n = 1, i = 0; i < t.length; ) {
                for (var r = t[i].interval, o = t[i].close, a = 0; 2 > a; a++) r[a] <= e && (r[a] = e, 
                o[a] = a ? 1 : 1 - n), e = r[a], n = o[a];
                r[0] === r[1] && o[0] * o[1] != 1 ? t.splice(i, 1) : i++;
            }
            return t;
        },
        isNumeric: function(t) {
            return t - parseFloat(t) >= 0;
        }
    }), Gf = P, Wf = /([&<>"'])/g, Xf = {
        "&": "&amp;",
        "<": "&lt;",
        ">": "&gt;",
        '"': "&quot;",
        "'": "&#39;"
    }, Uf = [ "a", "b", "c", "d", "e", "f", "g" ], Yf = function(t, e) {
        return "{" + t + (null == e ? "" : e) + "}";
    }, qf = Me, jf = (Object.freeze || Object)({
        addCommas: dr,
        toCamelCase: fr,
        normalizeCssArray: Gf,
        encodeHTML: pr,
        formatTpl: gr,
        formatTplSimple: function(t, e, n) {
            return f(e, function(e, i) {
                t = t.replace("{" + i + "}", n ? pr(e) : e);
            }), t;
        },
        getTooltipMarker: vr,
        formatTime: yr,
        capitalFirst: function(t) {
            return t ? t.charAt(0).toUpperCase() + t.substr(1) : t;
        },
        truncateText: qf,
        getTextBoundingRect: function(t) {
            return xe(t.text, t.font, t.textAlign, t.textVerticalAlign, t.textPadding, t.textLineHeight, t.rich, t.truncate);
        },
        getTextRect: function(t, e, n, i, r, o, a, s) {
            return xe(t, e, n, i, r, s, o, a);
        },
        windowOpen: _r
    }), Zf = f, Kf = [ "left", "right", "top", "bottom", "width", "height" ], $f = [ [ "width", "left", "right" ], [ "height", "top", "bottom" ] ], Qf = xr, Jf = (y(xr, "vertical"), 
    y(xr, "horizontal"), {
        getBoxLayoutParams: function() {
            return {
                left: this.get("left"),
                top: this.get("top"),
                right: this.get("right"),
                bottom: this.get("bottom"),
                width: this.get("width"),
                height: this.get("height")
            };
        }
    }), tp = _n(), ep = Ki.extend({
        type: "component",
        id: "",
        name: "",
        mainType: "",
        subType: "",
        componentIndex: 0,
        defaultOption: null,
        ecModel: null,
        dependentModels: [],
        uid: null,
        layoutMode: null,
        $constructor: function(t, e, n, i) {
            Ki.call(this, t, e, n, i), this.uid = Ji("ec_cpt_model");
        },
        init: function(t, e, n) {
            this.mergeDefaultAndTheme(t, n);
        },
        mergeDefaultAndTheme: function(t, e) {
            var n = this.layoutMode, i = n ? Sr(t) : {};
            r(t, e.getTheme().get(this.mainType)), r(t, this.getDefaultOption()), n && br(t, i, n);
        },
        mergeOption: function(t) {
            r(this.option, t, !0);
            var e = this.layoutMode;
            e && br(this.option, t, e);
        },
        optionUpdated: function() {},
        getDefaultOption: function() {
            var t = tp(this);
            if (!t.defaultOption) {
                for (var e = [], n = this.constructor; n; ) {
                    var i = n.prototype.defaultOption;
                    i && e.push(i), n = n.superClass;
                }
                for (var o = {}, a = e.length - 1; a >= 0; a--) o = r(o, e[a], !0);
                t.defaultOption = o;
            }
            return t.defaultOption;
        },
        getReferringComponents: function(t) {
            return this.ecModel.queryComponents({
                mainType: t,
                index: this.get(t + "Index", !0),
                id: this.get(t + "Id", !0)
            });
        }
    });
    Dn(ep, {
        registerWhenExtend: !0
    }), function(t) {
        var e = {};
        t.registerSubTypeDefaulter = function(t, n) {
            t = Mn(t), e[t.main] = n;
        }, t.determineSubType = function(n, i) {
            var r = i.type;
            if (!r) {
                var o = Mn(n).main;
                t.hasSubTypes(n) && e[o] && (r = e[o](i));
            }
            return r;
        };
    }(ep), function(t, e) {
        function n(t) {
            var n = {}, r = [];
            return f(t, function(o) {
                var a = i(n, o), s = function(t, e) {
                    var n = [];
                    return f(t, function(t) {
                        h(e, t) >= 0 && n.push(t);
                    }), n;
                }(a.originalDeps = e(o), t);
                a.entryCount = s.length, 0 === a.entryCount && r.push(o), f(s, function(t) {
                    h(a.predecessor, t) < 0 && a.predecessor.push(t);
                    var e = i(n, t);
                    h(e.successor, t) < 0 && e.successor.push(o);
                });
            }), {
                graph: n,
                noEntryList: r
            };
        }
        function i(t, e) {
            return t[e] || (t[e] = {
                predecessor: [],
                successor: []
            }), t[e];
        }
        t.topologicalTravel = function(t, e, i, r) {
            function o(t) {
                l[t].entryCount--, 0 === l[t].entryCount && h.push(t);
            }
            function a(t) {
                u[t] = !0, o(t);
            }
            if (t.length) {
                var s = n(e), l = s.graph, h = s.noEntryList, u = {};
                for (f(t, function(t) {
                    u[t] = !0;
                }); h.length; ) {
                    var c = h.pop(), d = l[c], p = !!u[c];
                    p && (i.call(r, c, d.originalDeps.slice()), delete u[c]), f(d.successor, p ? a : o);
                }
                f(u, function() {
                    throw new Error("Circle dependency may exists");
                });
            }
        };
    }(ep, function(t) {
        var e = [];
        return f(ep.getClassesByMainType(t), function(t) {
            e = e.concat(t.prototype.dependencies || []);
        }), e = p(e, function(t) {
            return Mn(t).main;
        }), "dataset" !== t && h(e, "dataset") <= 0 && e.unshift("dataset"), e;
    }), c(ep, Jf);
    var np = "";
    "undefined" != typeof navigator && (np = navigator.platform || "");
    var ip = {
        color: [ "#c23531", "#2f4554", "#61a0a8", "#d48265", "#91c7ae", "#749f83", "#ca8622", "#bda29a", "#6e7074", "#546570", "#c4ccd3" ],
        gradientColor: [ "#f6efa6", "#d88273", "#bf444c" ],
        textStyle: {
            fontFamily: np.match(/^Win/) ? "Microsoft YaHei" : "sans-serif",
            fontSize: 12,
            fontStyle: "normal",
            fontWeight: "normal"
        },
        blendMode: null,
        animation: "auto",
        animationDuration: 1e3,
        animationDurationUpdate: 300,
        animationEasing: "exponentialOut",
        animationEasingUpdate: "cubicOut",
        animationThreshold: 2e3,
        progressiveThreshold: 3e3,
        progressive: 400,
        hoverLayerThreshold: 3e3,
        useUTC: !1
    }, rp = _n(), op = {
        clearColorPalette: function() {
            rp(this).colorIdx = 0, rp(this).colorNameMap = {};
        },
        getColorFromPalette: function(t, e, n) {
            var i = rp(e = e || this), r = i.colorIdx || 0, o = i.colorNameMap = i.colorNameMap || {};
            if (o.hasOwnProperty(t)) return o[t];
            var a = dn(this.get("color", !0)), s = this.get("colorLayer", !0), l = null != n && s ? function(t, e) {
                for (var n = t.length, i = 0; n > i; i++) if (t[i].length > e) return t[i];
                return t[n - 1];
            }(s, n) : a;
            if ((l = l || a) && l.length) {
                var h = l[r];
                return t && (o[t] = h), i.colorIdx = (r + 1) % l.length, h;
            }
        }
    }, ap = "original", sp = "arrayRows", lp = "objectRows", hp = "keyedColumns", up = "unknown", cp = "typedArray", dp = "column", fp = "row";
    Mr.seriesDataToSource = function(t) {
        return new Mr({
            data: t,
            sourceFormat: M(t) ? cp : ap,
            fromDataset: !1
        });
    }, Tn(Mr);
    var pp = {
        Must: 1,
        Might: 2,
        Not: 3
    }, gp = _n(), vp = "\0_ec_inner", mp = Ki.extend({
        init: function(t, e, n, i) {
            n = n || {}, this.option = null, this._theme = new Ki(n), this._optionManager = i;
        },
        setOption: function(t, e) {
            L(!(vp in t), "please use chart.getOption()"), this._optionManager.setOption(t, e), 
            this.resetOption(null);
        },
        resetOption: function(t) {
            var e = !1, n = this._optionManager;
            if (!t || "recreate" === t) {
                var i = n.mountOption("recreate" === t);
                this.option && "recreate" !== t ? (this.restoreData(), this.mergeOption(i)) : Or.call(this, i), 
                e = !0;
            }
            if (("timeline" === t || "media" === t) && this.restoreData(), !t || "recreate" === t || "timeline" === t) {
                var r = n.getTimelineOption(this);
                r && (this.mergeOption(r), e = !0);
            }
            if (!t || "recreate" === t || "media" === t) {
                var o = n.getMediaOption(this, this._api);
                o.length && f(o, function(t) {
                    this.mergeOption(t, e = !0);
                }, this);
            }
            return e;
        },
        mergeOption: function(t) {
            var e = this.option, n = this._componentsMap, o = [];
            (function(t) {
                gp(t).datasetMap = N();
            })(this), f(t, function(t, n) {
                null != t && (ep.hasClass(n) ? n && o.push(n) : e[n] = null == e[n] ? i(t) : r(e[n], t, !0));
            }), ep.topologicalTravel(o, ep.getAllClassMainTypes(), function(i, r) {
                var o = dn(t[i]), s = gn(n.get(i), o);
                (function(t) {
                    var e = N();
                    Lc(t, function(t) {
                        var n = t.exist;
                        n && e.set(n.id, t);
                    }), Lc(t, function(t) {
                        var n = t.option;
                        L(!n || null == n.id || !e.get(n.id) || e.get(n.id) === t, "id duplicates: " + (n && n.id)), 
                        n && null != n.id && e.set(n.id, t), !t.keyInfo && (t.keyInfo = {});
                    }), Lc(t, function(t, n) {
                        var i = t.exist, r = t.option, o = t.keyInfo;
                        if (Oc(r)) {
                            if (o.name = null != r.name ? r.name + "" : i ? i.name : Bc + n, i) o.id = i.id; else if (null != r.id) o.id = r.id + ""; else {
                                var a = 0;
                                do {
                                    o.id = "\0" + o.name + "\0" + a++;
                                } while (e.get(o.id));
                            }
                            e.set(o.id, t);
                        }
                    });
                })(s), f(s, function(t) {
                    var e = t.option;
                    b(e) && (t.keyInfo.mainType = i, t.keyInfo.subType = function(t, e, n) {
                        return e.type ? e.type : n ? n.subType : ep.determineSubType(t, e);
                    }(i, e, t.exist));
                });
                var l = function(t, e) {
                    _(e) || (e = e ? [ e ] : []);
                    var n = {};
                    return f(e, function(e) {
                        n[e] = (t.get(e) || []).slice();
                    }), n;
                }(n, r);
                e[i] = [], n.set(i, []), f(s, function(t, r) {
                    var o = t.exist, s = t.option;
                    if (L(b(s) || o, "Empty component definition"), s) {
                        var h = ep.getClass(i, t.keyInfo.subType, !0);
                        if (o && o.constructor === h) o.name = t.keyInfo.name, o.mergeOption(s, this), o.optionUpdated(s, !1); else {
                            var u = a({
                                dependentModels: l,
                                componentIndex: r
                            }, t.keyInfo);
                            a(o = new h(s, this, this, u), u), o.init(s, this, this, u), o.optionUpdated(null, !0);
                        }
                    } else o.mergeOption({}, this), o.optionUpdated({}, !1);
                    n.get(i)[r] = o, e[i][r] = o.option;
                }, this), "series" === i && Er(this, n.get("series"));
            }, this), this._seriesIndicesMap = N(this._seriesIndices = this._seriesIndices || []);
        },
        getOption: function() {
            var t = i(this.option);
            return f(t, function(e, n) {
                if (ep.hasClass(n)) {
                    for (var i = (e = dn(e)).length - 1; i >= 0; i--) mn(e[i]) && e.splice(i, 1);
                    t[n] = e;
                }
            }), delete t[vp], t;
        },
        getTheme: function() {
            return this._theme;
        },
        getComponent: function(t, e) {
            var n = this._componentsMap.get(t);
            return n ? n[e || 0] : void 0;
        },
        queryComponents: function(t) {
            var e = t.mainType;
            if (!e) return [];
            var n, i = t.index, r = t.id, o = t.name, a = this._componentsMap.get(e);
            if (!a || !a.length) return [];
            if (null != i) _(i) || (i = [ i ]), n = v(p(i, function(t) {
                return a[t];
            }), function(t) {
                return !!t;
            }); else if (null != r) {
                var s = _(r);
                n = v(a, function(t) {
                    return s && h(r, t.id) >= 0 || !s && t.id === r;
                });
            } else if (null != o) {
                var l = _(o);
                n = v(a, function(t) {
                    return l && h(o, t.name) >= 0 || !l && t.name === o;
                });
            } else n = a.slice();
            return Br(n, t);
        },
        findComponents: function(t) {
            var e = t.query, n = t.mainType, i = function(t) {
                var e = n + "Index", i = n + "Id", r = n + "Name";
                return !t || null == t[e] && null == t[i] && null == t[r] ? null : {
                    mainType: n,
                    index: t[e],
                    id: t[i],
                    name: t[r]
                };
            }(e);
            return function(e) {
                return t.filter ? v(e, t.filter) : e;
            }(Br(i ? this.queryComponents(i) : this._componentsMap.get(n), t));
        },
        eachComponent: function(t, e, n) {
            var i = this._componentsMap;
            if ("function" == typeof t) n = e, e = t, i.each(function(t, i) {
                f(t, function(t, r) {
                    e.call(n, i, t, r);
                });
            }); else if (w(t)) f(i.get(t), e, n); else if (b(t)) {
                f(this.findComponents(t), e, n);
            }
        },
        getSeriesByName: function(t) {
            return v(this._componentsMap.get("series"), function(e) {
                return e.name === t;
            });
        },
        getSeriesByIndex: function(t) {
            return this._componentsMap.get("series")[t];
        },
        getSeriesByType: function(t) {
            return v(this._componentsMap.get("series"), function(e) {
                return e.subType === t;
            });
        },
        getSeries: function() {
            return this._componentsMap.get("series").slice();
        },
        getSeriesCount: function() {
            return this._componentsMap.get("series").length;
        },
        eachSeries: function(t, e) {
            zr(this), f(this._seriesIndices, function(n) {
                var i = this._componentsMap.get("series")[n];
                t.call(e, i, n);
            }, this);
        },
        eachRawSeries: function(t, e) {
            f(this._componentsMap.get("series"), t, e);
        },
        eachSeriesByType: function(t, e, n) {
            zr(this), f(this._seriesIndices, function(i) {
                var r = this._componentsMap.get("series")[i];
                r.subType === t && e.call(n, r, i);
            }, this);
        },
        eachRawSeriesByType: function(t, e, n) {
            return f(this.getSeriesByType(t), e, n);
        },
        isSeriesFiltered: function(t) {
            return zr(this), null == this._seriesIndicesMap.get(t.componentIndex);
        },
        getCurrentSeriesIndices: function() {
            return (this._seriesIndices || []).slice();
        },
        filterSeries: function(t, e) {
            zr(this), Er(this, v(this._componentsMap.get("series"), t, e));
        },
        restoreData: function(t) {
            var e = this._componentsMap;
            Er(this, e.get("series"));
            var n = [];
            e.each(function(t, e) {
                n.push(e);
            }), ep.topologicalTravel(n, ep.getAllClassMainTypes(), function(n) {
                f(e.get(n), function(e) {
                    ("series" !== n || !function(t, e) {
                        if (e) {
                            var n = e.seiresIndex, i = e.seriesId, r = e.seriesName;
                            return null != n && t.componentIndex !== n || null != i && t.id !== i || null != r && t.name !== r;
                        }
                    }(e, t)) && e.restoreData();
                });
            });
        }
    });
    c(mp, op);
    var yp = [ "getDom", "getZr", "getWidth", "getHeight", "getDevicePixelRatio", "dispatchAction", "isDisposed", "on", "off", "getDataURL", "getConnectedDataURL", "getModel", "getOption", "getViewOfComponentModel", "getViewOfSeriesModel" ], _p = {};
    Rr.prototype = {
        constructor: Rr,
        create: function(t, e) {
            var n = [];
            f(_p, function(i) {
                var r = i.create(t, e);
                n = n.concat(r || []);
            }), this._coordinateSystems = n;
        },
        update: function(t, e) {
            f(this._coordinateSystems, function(n) {
                n.update && n.update(t, e);
            });
        },
        getCoordinateSystems: function() {
            return this._coordinateSystems.slice();
        }
    }, Rr.register = function(t, e) {
        _p[t] = e;
    }, Rr.get = function(t) {
        return _p[t];
    };
    var xp = f, wp = i, bp = p, Sp = r, Mp = /^(min|max)?(.+)$/;
    Fr.prototype = {
        constructor: Fr,
        setOption: function(t, e) {
            t && f(dn(t.series), function(t) {
                t && t.data && M(t.data) && E(t.data);
            }), t = wp(t);
            var n = this._optionBackup, i = Vr.call(this, t, e, !n);
            this._newBaseOption = i.baseOption, n ? (function(t, e) {
                xp(e = e || {}, function(e, n) {
                    if (null != e) {
                        var i = t[n];
                        if (ep.hasClass(n)) {
                            e = dn(e);
                            var r = gn(i = dn(i), e);
                            t[n] = bp(r, function(t) {
                                return t.option && t.exist ? Sp(t.exist, t.option, !0) : t.exist || t.option;
                            });
                        } else t[n] = Sp(i, e, !0);
                    }
                });
            }(n.baseOption, i.baseOption), i.timelineOptions.length && (n.timelineOptions = i.timelineOptions), 
            i.mediaList.length && (n.mediaList = i.mediaList), i.mediaDefault && (n.mediaDefault = i.mediaDefault)) : this._optionBackup = i;
        },
        mountOption: function(t) {
            var e = this._optionBackup;
            return this._timelineOptions = bp(e.timelineOptions, wp), this._mediaList = bp(e.mediaList, wp), 
            this._mediaDefault = wp(e.mediaDefault), this._currentMediaIndices = [], wp(t ? e.baseOption : this._newBaseOption);
        },
        getTimelineOption: function(t) {
            var e, n = this._timelineOptions;
            if (n.length) {
                var i = t.getComponent("timeline");
                i && (e = wp(n[i.getCurrentIndex()], !0));
            }
            return e;
        },
        getMediaOption: function() {
            var t = this._api.getWidth(), e = this._api.getHeight(), n = this._mediaList, i = this._mediaDefault, r = [], o = [];
            if (!n.length && !i) return o;
            for (var a = 0, s = n.length; s > a; a++) Hr(n[a].query, t, e) && r.push(a);
            return !r.length && i && (r = [ -1 ]), r.length && !function(t, e) {
                return t.join(",") === e.join(",");
            }(r, this._currentMediaIndices) && (o = bp(r, function(t) {
                return wp(-1 === t ? i.option : n[t].option);
            })), this._currentMediaIndices = r, o;
        }
    };
    var Ip = f, Tp = b, Cp = [ "areaStyle", "lineStyle", "nodeStyle", "linkStyle", "chordStyle", "label", "labelLine" ], Ap = function(t, e) {
        Ip(qr(t.series), function(t) {
            Tp(t) && function(t) {
                if (Tp(t)) {
                    Gr(t), Xr(t), Ur(t, "label"), Ur(t, "upperLabel"), Ur(t, "edgeLabel"), t.emphasis && (Ur(t.emphasis, "label"), 
                    Ur(t.emphasis, "upperLabel"), Ur(t.emphasis, "edgeLabel")), (n = t.markPoint) && (Gr(n), 
                    Yr(n)), (i = t.markLine) && (Gr(i), Yr(i));
                    var e = t.markArea;
                    e && Yr(e);
                    var n, i, r = t.data;
                    if ("graph" === t.type) {
                        r = r || t.nodes;
                        var o = t.links || t.edges;
                        if (o && !M(o)) for (var a = 0; a < o.length; a++) Yr(o[a]);
                        f(t.categories, function(t) {
                            Xr(t);
                        });
                    }
                    if (r && !M(r)) for (a = 0; a < r.length; a++) Yr(r[a]);
                    if ((n = t.markPoint) && n.data) {
                        var s = n.data;
                        for (a = 0; a < s.length; a++) Yr(s[a]);
                    }
                    if ((i = t.markLine) && i.data) {
                        var l = i.data;
                        for (a = 0; a < l.length; a++) _(l[a]) ? (Yr(l[a][0]), Yr(l[a][1])) : Yr(l[a]);
                    }
                    "gauge" === t.type ? (Ur(t, "axisLabel"), Ur(t, "title"), Ur(t, "detail")) : "treemap" === t.type ? (Wr(t.breadcrumb, "itemStyle"), 
                    f(t.levels, function(t) {
                        Xr(t);
                    })) : "tree" === t.type && Xr(t.leaves);
                }
            }(t);
        });
        var n = [ "xAxis", "yAxis", "radiusAxis", "angleAxis", "singleAxis", "parallelAxis", "radar" ];
        e && n.push("valueAxis", "categoryAxis", "logAxis", "timeAxis"), Ip(n, function(e) {
            Ip(qr(t[e]), function(t) {
                t && (Ur(t, "axisLabel"), Ur(t.axisPointer, "label"));
            });
        }), Ip(qr(t.parallel), function(t) {
            var e = t && t.parallelAxisDefault;
            Ur(e, "axisLabel"), Ur(e && e.axisPointer, "label");
        }), Ip(qr(t.calendar), function(t) {
            Wr(t, "itemStyle"), Ur(t, "dayLabel"), Ur(t, "monthLabel"), Ur(t, "yearLabel");
        }), Ip(qr(t.radar), function(t) {
            Ur(t, "name");
        }), Ip(qr(t.geo), function(t) {
            Tp(t) && (Yr(t), Ip(qr(t.regions), function(t) {
                Yr(t);
            }));
        }), Ip(qr(t.timeline), function(t) {
            Yr(t), Wr(t, "label"), Wr(t, "itemStyle"), Wr(t, "controlStyle", !0);
            var e = t.data;
            _(e) && f(e, function(t) {
                b(t) && (Wr(t, "label"), Wr(t, "itemStyle"));
            });
        }), Ip(qr(t.toolbox), function(t) {
            Wr(t, "iconStyle"), Ip(t.feature, function(t) {
                Wr(t, "iconStyle");
            });
        }), Ur(jr(t.axisPointer), "label"), Ur(jr(t.tooltip).axisPointer, "label");
    }, Dp = [ [ "x", "left" ], [ "y", "top" ], [ "x2", "right" ], [ "y2", "bottom" ] ], kp = [ "grid", "geo", "parallel", "legend", "toolbox", "title", "visualMap", "dataZoom", "timeline" ], Pp = function(t, e) {
        Ap(t, e), t.series = dn(t.series), f(t.series, function(t) {
            if (b(t)) {
                var e = t.type;
                if ("line" === e) null != t.clipOverflow && (t.clip = t.clipOverflow); else if ("pie" === e || "gauge" === e) null != t.clockWise && (t.clockwise = t.clockWise); else if ("gauge" === e) {
                    var n = function(t, e) {
                        e = e.split(",");
                        for (var n = t, i = 0; i < e.length && null != (n = n && n[e[i]]); i++) ;
                        return n;
                    }(t, "pointer.color");
                    null != n && function(t, e, n, i) {
                        e = e.split(",");
                        for (var r, o = t, a = 0; a < e.length - 1; a++) null == o[r = e[a]] && (o[r] = {}), 
                        o = o[r];
                        (i || null == o[e[a]]) && (o[e[a]] = n);
                    }(t, "itemStyle.color", n);
                }
                Zr(t);
            }
        }), t.dataRange && (t.visualMap = t.dataRange), f(kp, function(e) {
            var n = t[e];
            n && (_(n) || (n = [ n ]), f(n, function(t) {
                Zr(t);
            }));
        });
    }, Lp = $r.prototype;
    Lp.pure = !1, Lp.persistent = !0, Lp.getSource = function() {
        return this._source;
    };
    var Op = {
        arrayRows_column: {
            pure: !0,
            count: function() {
                return Math.max(0, this._data.length - this._source.startIndex);
            },
            getItem: function(t) {
                return this._data[t + this._source.startIndex];
            },
            appendData: to
        },
        arrayRows_row: {
            pure: !0,
            count: function() {
                var t = this._data[0];
                return t ? Math.max(0, t.length - this._source.startIndex) : 0;
            },
            getItem: function(t) {
                t += this._source.startIndex;
                for (var e = [], n = this._data, i = 0; i < n.length; i++) {
                    var r = n[i];
                    e.push(r ? r[t] : null);
                }
                return e;
            },
            appendData: function() {
                throw new Error('Do not support appendData when set seriesLayoutBy: "row".');
            }
        },
        objectRows: {
            pure: !0,
            count: Qr,
            getItem: Jr,
            appendData: to
        },
        keyedColumns: {
            pure: !0,
            count: function() {
                var t = this._source.dimensionsDefine[0].name, e = this._data[t];
                return e ? e.length : 0;
            },
            getItem: function(t) {
                for (var e = [], n = this._source.dimensionsDefine, i = 0; i < n.length; i++) {
                    var r = this._data[n[i].name];
                    e.push(r ? r[t] : null);
                }
                return e;
            },
            appendData: function(t) {
                var e = this._data;
                f(t, function(t, n) {
                    for (var i = e[n] || (e[n] = []), r = 0; r < (t || []).length; r++) i.push(t[r]);
                });
            }
        },
        original: {
            count: Qr,
            getItem: Jr,
            appendData: to
        },
        typedArray: {
            persistent: !1,
            pure: !0,
            count: function() {
                return this._data ? this._data.length / this._dimSize : 0;
            },
            getItem: function(t, e) {
                t -= this._offset, e = e || [];
                for (var n = this._dimSize * t, i = 0; i < this._dimSize; i++) e[i] = this._data[n + i];
                return e;
            },
            appendData: function(t) {
                wh && L(M(t), "Added data must be TypedArray if data in initialization is TypedArray"), 
                this._data = t;
            },
            clean: function() {
                this._offset += this.count(), this._data = null;
            }
        }
    }, Ep = {
        arrayRows: eo,
        objectRows: function(t, e, n, i) {
            return null != n ? t[i] : t;
        },
        keyedColumns: eo,
        original: function(t, e, n) {
            var i = pn(t);
            return null != n && i instanceof Array ? i[n] : i;
        },
        typedArray: eo
    }, Bp = {
        arrayRows: no,
        objectRows: function(t, e) {
            return io(t[e], this._dimensionInfos[e]);
        },
        keyedColumns: no,
        original: function(t, e, n, i) {
            var r = t && (null == t.value ? t : t.value);
            return !this._rawData.pure && function(t) {
                return Oc(t) && !(t instanceof Array);
            }(t) && (this.hasItemOption = !0), io(r instanceof Array ? r[i] : r, this._dimensionInfos[e]);
        },
        typedArray: function(t, e, n, i) {
            return t[i];
        }
    }, zp = /\{@(.+?)\}/g, Np = {
        getDataParams: function(t, e) {
            var n = this.getData(e), i = this.getRawValue(t, e), r = n.getRawIndex(t), o = n.getName(t), a = n.getRawDataItem(t), s = n.getItemVisual(t, "color"), l = n.getItemVisual(t, "borderColor"), h = this.ecModel.getComponent("tooltip"), u = Sn(h && h.get("renderMode")), c = this.mainType, d = "series" === c, f = n.userOutput;
            return {
                componentType: c,
                componentSubType: this.subType,
                componentIndex: this.componentIndex,
                seriesType: d ? this.subType : null,
                seriesIndex: this.seriesIndex,
                seriesId: d ? this.id : null,
                seriesName: d ? this.name : null,
                name: o,
                dataIndex: r,
                data: a,
                dataType: e,
                value: i,
                color: s,
                borderColor: l,
                dimensionNames: f ? f.dimensionNames : null,
                encode: f ? f.encode : null,
                marker: vr({
                    color: s,
                    renderMode: u
                }),
                $vars: [ "seriesName", "name", "value" ]
            };
        },
        getFormattedLabel: function(t, e, n, i, r) {
            e = e || "normal";
            var o = this.getData(n), a = o.getItemModel(t), s = this.getDataParams(t, n);
            null != i && s.value instanceof Array && (s.value = s.value[i]);
            var l = a.get("normal" === e ? [ r || "label", "formatter" ] : [ e, r || "label", "formatter" ]);
            return "function" == typeof l ? (s.status = e, s.dimensionIndex = i, l(s)) : "string" == typeof l ? gr(l, s).replace(zp, function(e, n) {
                var i = n.length;
                return "[" === n.charAt(0) && "]" === n.charAt(i - 1) && (n = +n.slice(1, i - 1)), 
                ro(o, t, n);
            }) : void 0;
        },
        getRawValue: function(t, e) {
            return ro(this.getData(e), t);
        },
        formatTooltip: function() {}
    }, Rp = so.prototype;
    Rp.perform = function(t) {
        function e(t) {
            return !(t >= 1) && (t = 1), t;
        }
        var n, i = this._upstream, r = t && t.skip;
        if (this._dirty && i) {
            var o = this.context;
            o.data = o.outputData = i.context.outputData;
        }
        this.__pipeline && (this.__pipeline.currentTask = this), this._plan && !r && (n = this._plan(this.context));
        var a, s = e(this._modBy), l = this._modDataCount || 0, h = e(t && t.modBy), u = t && t.modDataCount || 0;
        (s !== h || l !== u) && (n = "reset"), (this._dirty || "reset" === n) && (this._dirty = !1, 
        a = function(t, e) {
            var n, i;
            t._dueIndex = t._outputDueEnd = t._dueEnd = 0, t._settedOutputEnd = null, !e && t._reset && ((n = t._reset(t.context)) && n.progress && (i = n.forceFirstProgress, 
            n = n.progress), _(n) && !n.length && (n = null)), t._progress = n, t._modBy = t._modDataCount = null;
            var r = t._downstream;
            return r && r.dirty(), i;
        }(this, r)), this._modBy = h, this._modDataCount = u;
        var c = t && t.step;
        if (i ? (wh && L(null != i._outputDueEnd), this._dueEnd = i._outputDueEnd) : (wh && L(!this._progress || this._count), 
        this._dueEnd = this._count ? this._count(this.context) : 1 / 0), this._progress) {
            var d = this._dueIndex, f = Math.min(null != c ? this._dueIndex + c : 1 / 0, this._dueEnd);
            if (!r && (a || f > d)) {
                var p = this._progress;
                if (_(p)) for (var g = 0; g < p.length; g++) lo(this, p[g], d, f, h, u); else lo(this, p, d, f, h, u);
            }
            this._dueIndex = f;
            var v = null != this._settedOutputEnd ? this._settedOutputEnd : f;
            wh && L(v >= this._outputDueEnd), this._outputDueEnd = v;
        } else this._dueIndex = this._outputDueEnd = null != this._settedOutputEnd ? this._settedOutputEnd : this._dueEnd;
        return this.unfinished();
    };
    var Fp = function() {
        function t() {
            return n > i ? i++ : null;
        }
        function e() {
            var t = i % a * r + Math.ceil(i / a), e = i >= n ? null : o > t ? t : i;
            return i++, e;
        }
        var n, i, r, o, a, s = {
            reset: function(l, h, u, c) {
                i = l, n = h, r = u, o = c, a = Math.ceil(o / r), s.next = r > 1 && o > 0 ? e : t;
            }
        };
        return s;
    }();
    Rp.dirty = function() {
        this._dirty = !0, this._onDirty && this._onDirty(this.context);
    }, Rp.unfinished = function() {
        return this._progress && this._dueIndex < this._dueEnd;
    }, Rp.pipe = function(t) {
        wh && L(t && !t._disposed && t !== this), (this._downstream !== t || this._dirty) && (this._downstream = t, 
        t._upstream = this, t.dirty());
    }, Rp.dispose = function() {
        this._disposed || (this._upstream && (this._upstream._downstream = null), this._downstream && (this._downstream._upstream = null), 
        this._dirty = !1, this._disposed = !0);
    }, Rp.getUpstream = function() {
        return this._upstream;
    }, Rp.getDownstream = function() {
        return this._downstream;
    }, Rp.setOutputEnd = function(t) {
        this._outputDueEnd = this._settedOutputEnd = t;
    };
    var Vp = _n(), Hp = ep.extend({
        type: "series.__base__",
        seriesIndex: 0,
        coordinateSystem: null,
        defaultOption: null,
        legendVisualProvider: null,
        visualColorAccessPath: "itemStyle.color",
        visualBorderColorAccessPath: "itemStyle.borderColor",
        layoutMode: null,
        init: function(t, e, n) {
            this.seriesIndex = this.componentIndex, this.dataTask = ao({
                count: uo,
                reset: co
            }), this.dataTask.context = {
                model: this
            }, this.mergeDefaultAndTheme(t, n), Ir(this);
            var i = this.getInitialData(t, n);
            po(i, this), this.dataTask.context.data = i, wh && L(i, "getInitialData returned invalid data."), 
            Vp(this).dataBeforeProcessed = i, ho(this);
        },
        mergeDefaultAndTheme: function(t, e) {
            var n = this.layoutMode, i = n ? Sr(t) : {}, o = this.subType;
            ep.hasClass(o) && (o += "Series"), r(t, e.getTheme().get(this.subType)), r(t, this.getDefaultOption()), 
            fn(t, "label", [ "show" ]), this.fillDataTextStyle(t.data), n && br(t, i, n);
        },
        mergeOption: function(t, e) {
            t = r(this.option, t, !0), this.fillDataTextStyle(t.data);
            var n = this.layoutMode;
            n && br(this.option, t, n), Ir(this);
            var i = this.getInitialData(t, e);
            po(i, this), this.dataTask.dirty(), this.dataTask.context.data = i, Vp(this).dataBeforeProcessed = i, 
            ho(this);
        },
        fillDataTextStyle: function(t) {
            if (t && !M(t)) for (var e = [ "show" ], n = 0; n < t.length; n++) t[n] && t[n].label && fn(t[n], "label", e);
        },
        getInitialData: function() {},
        appendData: function(t) {
            this.getRawData().appendData(t.data);
        },
        getData: function(t) {
            var e = vo(this);
            if (e) {
                var n = e.context.data;
                return null == t ? n : n.getLinkedData(t);
            }
            return Vp(this).data;
        },
        setData: function(t) {
            var e = vo(this);
            if (e) {
                var n = e.context;
                n.data !== t && e.modifyOutputEnd && e.setOutputEnd(t.count()), n.outputData = t, 
                e !== this.dataTask && (n.data = t);
            }
            Vp(this).data = t;
        },
        getSource: function() {
            return function(t) {
                return gp(t).source;
            }(this);
        },
        getRawData: function() {
            return Vp(this).dataBeforeProcessed;
        },
        getBaseAxis: function() {
            var t = this.coordinateSystem;
            return t && t.getBaseAxis && t.getBaseAxis();
        },
        formatTooltip: function(t, e, n, i) {
            var r = this, o = "html" === (i = i || "html") ? "<br/>" : "\n", a = "richText" === i, s = {}, l = 0, h = this.getData(), u = h.mapDimension("defaultedTooltip", !0), c = u.length, d = this.getRawValue(t), p = _(d), v = h.getItemVisual(t, "color");
            b(v) && v.colorStops && (v = (v.colorStops[0] || {}).color), v = v || "transparent";
            var m = (c > 1 || p && !c ? function(n) {
                function o(t, n) {
                    var o = h.getDimensionInfo(n);
                    if (o && !1 !== o.otherDims.tooltip) {
                        var u = o.type, f = "sub" + r.seriesIndex + "at" + l, p = vr({
                            color: v,
                            type: "subItem",
                            renderMode: i,
                            markerId: f
                        }), g = "string" == typeof p ? p : p.content, m = (c ? g + pr(o.displayName || "-") + ": " : "") + pr("ordinal" === u ? t + "" : "time" === u ? e ? "" : yr("yyyy/MM/dd hh:mm:ss", t) : dr(t));
                        m && d.push(m), a && (s[f] = v, ++l);
                    }
                }
                var c = g(n, function(t, e, n) {
                    var i = h.getDimensionInfo(n);
                    return t | (i && !1 !== i.tooltip && null != i.displayName);
                }, 0), d = [];
                u.length ? f(u, function(e) {
                    o(ro(h, t, e), e);
                }) : f(n, o);
                var p = c ? a ? "\n" : "<br/>" : "", m = p + d.join(p || ", ");
                return {
                    renderMode: i,
                    content: m,
                    style: s
                };
            }(d) : function(t) {
                return {
                    renderMode: i,
                    content: pr(dr(t)),
                    style: s
                };
            }(c ? ro(h, t, u[0]) : p ? d[0] : d)).content, y = r.seriesIndex + "at" + l, x = vr({
                color: v,
                type: "item",
                renderMode: i,
                markerId: y
            });
            s[y] = v, ++l;
            var w = h.getName(t), S = this.name;
            vn(this) || (S = ""), S = S ? pr(S) + (e ? ": " : o) : "";
            var M = "string" == typeof x ? x : x.content;
            return {
                html: e ? M + S + m : S + M + (w ? pr(w) + ": " + m : m),
                markers: s
            };
        },
        isAnimationEnabled: function() {
            if (Mh.node) return !1;
            var t = this.getShallow("animation");
            return t && this.getData().count() > this.getShallow("animationThreshold") && (t = !1), 
            t;
        },
        restoreData: function() {
            this.dataTask.dirty();
        },
        getColorFromPalette: function(t, e, n) {
            var i = this.ecModel, r = op.getColorFromPalette.call(this, t, e, n);
            return r || (r = i.getColorFromPalette(t, e, n)), r;
        },
        coordDimToDataDim: function(t) {
            return this.getRawData().mapDimension(t, !0);
        },
        getProgressive: function() {
            return this.get("progressive");
        },
        getProgressiveThreshold: function() {
            return this.get("progressiveThreshold");
        },
        getAxisTooltipData: null,
        getTooltipPosition: null,
        pipeTask: null,
        preventIncremental: null,
        pipelineContext: null
    });
    c(Hp, Np), c(Hp, op);
    var Gp = function() {
        this.group = new Nu(), this.uid = Ji("viewComponent");
    };
    Gp.prototype = {
        constructor: Gp,
        init: function() {},
        render: function() {},
        dispose: function() {},
        filterForExposedEvent: null
    };
    var Wp = Gp.prototype;
    Wp.updateView = Wp.updateLayout = Wp.updateVisual = function() {}, In(Gp), Dn(Gp, {
        registerWhenExtend: !0
    });
    var Xp = function() {
        var t = _n();
        return function(e) {
            var n = t(e), i = e.pipelineContext, r = n.large, o = n.progressiveRender, a = n.large = i && i.large, s = n.progressiveRender = i && i.progressiveRender;
            return !!(r ^ a || o ^ s) && "reset";
        };
    }, Up = _n(), Yp = Xp();
    mo.prototype = {
        type: "chart",
        init: function() {},
        render: function() {},
        highlight: function(t, e, n, i) {
            _o(t.getData(), i, "emphasis");
        },
        downplay: function(t, e, n, i) {
            _o(t.getData(), i, "normal");
        },
        remove: function() {
            this.group.removeAll();
        },
        dispose: function() {},
        incrementalPrepareRender: null,
        incrementalRender: null,
        updateTransform: null,
        filterForExposedEvent: null
    };
    var qp = mo.prototype;
    qp.updateView = qp.updateLayout = qp.updateVisual = function(t, e, n, i) {
        this.render(t, e, n, i);
    }, In(mo, [ "dispose" ]), Dn(mo, {
        registerWhenExtend: !0
    }), mo.markUpdateMethod = function(t, e) {
        Up(t).updateMethod = e;
    };
    var jp = {
        incrementalPrepareRender: {
            progress: function(t, e) {
                e.view.incrementalRender(t, e.model, e.ecModel, e.api, e.payload);
            }
        },
        render: {
            forceFirstProgress: !0,
            progress: function(t, e) {
                e.view.render(e.model, e.ecModel, e.api, e.payload);
            }
        }
    }, Zp = "\0__throttleOriginMethod", Kp = "\0__throttleRate", $p = "\0__throttleType", Qp = {
        createOnAllSeries: !0,
        performRawSeries: !0,
        reset: function(t, e) {
            var n = t.getData(), i = (t.visualColorAccessPath || "itemStyle.color").split("."), r = t.get(i), o = !x(r) || r instanceof pf ? null : r;
            (!r || o) && (r = t.getColorFromPalette(t.name, null, e.getSeriesCount())), n.setVisual("color", r);
            var a = (t.visualBorderColorAccessPath || "itemStyle.borderColor").split("."), s = t.get(a);
            if (n.setVisual("borderColor", s), !e.isSeriesFiltered(t)) {
                o && n.each(function(e) {
                    n.setItemVisual(e, "color", o(t.getDataParams(e)));
                });
                return {
                    dataEach: n.hasItemOption ? function(t, e) {
                        var n = t.getItemModel(e), r = n.get(i, !0), o = n.get(a, !0);
                        null != r && t.setItemVisual(e, "color", r), null != o && t.setItemVisual(e, "borderColor", o);
                    } : null
                };
            }
        }
    }, Jp = {
        legend: {
            selector: {
                all: "全选",
                inverse: "反选"
            }
        },
        toolbox: {
            brush: {
                title: {
                    rect: "矩形选择",
                    polygon: "圈选",
                    lineX: "横向选择",
                    lineY: "纵向选择",
                    keep: "保持选择",
                    clear: "清除选择"
                }
            },
            dataView: {
                title: "数据视图",
                lang: [ "数据视图", "关闭", "刷新" ]
            },
            dataZoom: {
                title: {
                    zoom: "区域缩放",
                    back: "区域缩放还原"
                }
            },
            magicType: {
                title: {
                    line: "切换为折线图",
                    bar: "切换为柱状图",
                    stack: "切换为堆叠",
                    tiled: "切换为平铺"
                }
            },
            restore: {
                title: "还原"
            },
            saveAsImage: {
                title: "保存为图片",
                lang: [ "右键另存为图片" ]
            }
        },
        series: {
            typeNames: {
                pie: "饼图",
                bar: "柱状图",
                line: "折线图",
                scatter: "散点图",
                effectScatter: "涟漪散点图",
                radar: "雷达图",
                tree: "树图",
                treemap: "矩形树图",
                boxplot: "箱型图",
                candlestick: "K线图",
                k: "K线图",
                heatmap: "热力图",
                map: "地图",
                parallel: "平行坐标图",
                lines: "线图",
                graph: "关系图",
                sankey: "桑基图",
                funnel: "漏斗图",
                gauge: "仪表盘图",
                pictorialBar: "象形柱图",
                themeRiver: "主题河流图",
                sunburst: "旭日图"
            }
        },
        aria: {
            general: {
                withTitle: "这是一个关于“{title}”的图表。",
                withoutTitle: "这是一个图表，"
            },
            series: {
                single: {
                    prefix: "",
                    withName: "图表类型是{seriesType}，表示{seriesName}。",
                    withoutName: "图表类型是{seriesType}。"
                },
                multiple: {
                    prefix: "它由{seriesCount}个图表系列组成。",
                    withName: "第{seriesId}个系列是一个表示{seriesName}的{seriesType}，",
                    withoutName: "第{seriesId}个系列是一个{seriesType}，",
                    separator: {
                        middle: "；",
                        end: "。"
                    }
                }
            },
            data: {
                allData: "其数据是——",
                partialData: "其中，前{displayCnt}项是——",
                withName: "{name}的数据是{value}",
                withoutName: "{value}",
                separator: {
                    middle: "，",
                    end: ""
                }
            }
        }
    }, tg = function(t, e) {
        function n(t, e) {
            if ("string" != typeof t) return t;
            var n = t;
            return f(e, function(t, e) {
                n = n.replace(new RegExp("\\{\\s*" + e + "\\s*\\}", "g"), t);
            }), n;
        }
        function i(t) {
            var e = o.get(t);
            if (null == e) {
                for (var n = t.split("."), i = Jp.aria, r = 0; r < n.length; ++r) i = i[n[r]];
                return i;
            }
            return e;
        }
        function r(t) {
            return Jp.series.typeNames[t] || "自定义图";
        }
        var o = e.getModel("aria");
        if (o.get("show")) {
            if (o.get("description")) return void t.setAttribute("aria-label", o.get("description"));
            var a = 0;
            e.eachSeries(function() {
                ++a;
            }, this);
            var s, l = o.get("data.maxCount") || 10, h = o.get("series.maxCount") || 10, u = Math.min(a, h);
            if (!(1 > a)) {
                var c = function() {
                    var t = e.getModel("title").option;
                    return t && t.length && (t = t[0]), t && t.text;
                }();
                s = c ? n(i("general.withTitle"), {
                    title: c
                }) : i("general.withoutTitle");
                var d = [];
                s += n(i(a > 1 ? "series.multiple.prefix" : "series.single.prefix"), {
                    seriesCount: a
                }), e.eachSeries(function(t, e) {
                    if (u > e) {
                        var o, s = t.get("name"), h = "series." + (a > 1 ? "multiple" : "single") + ".";
                        o = n(o = i(s ? h + "withName" : h + "withoutName"), {
                            seriesId: t.seriesIndex,
                            seriesName: t.get("name"),
                            seriesType: r(t.subType)
                        });
                        var c = t.getData();
                        window.data = c, o += c.count() > l ? n(i("data.partialData"), {
                            displayCnt: l
                        }) : i("data.allData");
                        for (var f = [], p = 0; p < c.count(); p++) if (l > p) {
                            var g = c.getName(p), v = ro(c, p);
                            f.push(n(i(g ? "data.withName" : "data.withoutName"), {
                                name: g,
                                value: v
                            }));
                        }
                        o += f.join(i("data.separator.middle")) + i("data.separator.end"), d.push(o);
                    }
                }), s += d.join(i("series.multiple.separator.middle")) + i("series.multiple.separator.end"), 
                t.setAttribute("aria-label", s);
            }
        }
    }, eg = Math.PI, ng = So.prototype;
    ng.restoreData = function(t, e) {
        t.restoreData(e), this._stageTaskMap.each(function(t) {
            var e = t.overallTask;
            e && e.dirty();
        });
    }, ng.getPerformArgs = function(t, e) {
        if (t.__pipeline) {
            var n = this._pipelineMap.get(t.__pipeline.id), i = n.context, r = !e && n.progressiveEnabled && (!i || i.progressiveRender) && t.__idxInPipeline > n.blockIndex ? n.step : null, o = i && i.modDataCount;
            return {
                step: r,
                modBy: null != o ? Math.ceil(o / r) : null,
                modDataCount: o
            };
        }
    }, ng.getPipeline = function(t) {
        return this._pipelineMap.get(t);
    }, ng.updateStreamModes = function(t, e) {
        var n = this._pipelineMap.get(t.uid), i = t.getData().count(), r = n.progressiveEnabled && e.incrementalPrepareRender && i >= n.threshold, o = t.get("large") && i >= t.get("largeThreshold"), a = "mod" === t.get("progressiveChunkMode") ? i : null;
        t.pipelineContext = n.context = {
            progressiveRender: r,
            modDataCount: a,
            large: o
        };
    }, ng.restorePipelines = function(t) {
        var e = this, n = e._pipelineMap = N();
        t.eachSeries(function(t) {
            var i = t.getProgressive(), r = t.uid;
            n.set(r, {
                id: r,
                head: null,
                tail: null,
                threshold: t.getProgressiveThreshold(),
                progressiveEnabled: i && !(t.preventIncremental && t.preventIncremental()),
                blockIndex: -1,
                step: Math.round(i || 700),
                count: 0
            }), Oo(e, t, t.dataTask);
        });
    }, ng.prepareStageTasks = function() {
        var t = this._stageTaskMap, e = this.ecInstance.getModel(), n = this.api;
        f(this._allHandlers, function(i) {
            var r = t.get(i.uid) || t.set(i.uid, []);
            i.reset && function(t, e, n, i, r) {
                function o(n) {
                    var o = n.uid, s = a.get(o) || a.set(o, ao({
                        plan: Do,
                        reset: ko,
                        count: Lo
                    }));
                    s.context = {
                        model: n,
                        ecModel: i,
                        api: r,
                        useClearVisual: e.isVisual && !e.isLayout,
                        plan: e.plan,
                        reset: e.reset,
                        scheduler: t
                    }, Oo(t, n, s);
                }
                var a = n.seriesTaskMap || (n.seriesTaskMap = N()), s = e.seriesType, l = e.getTargetSeries;
                e.createOnAllSeries ? i.eachRawSeries(o) : s ? i.eachRawSeriesByType(s, o) : l && l(i, r).each(o);
                var h = t._pipelineMap;
                a.each(function(t, e) {
                    h.get(e) || (t.dispose(), a.removeKey(e));
                });
            }(this, i, r, e, n), i.overallReset && function(t, e, n, i, r) {
                function o(e) {
                    var n = e.uid, i = s.get(n);
                    i || (i = s.set(n, ao({
                        reset: To,
                        onDirty: Ao
                    })), a.dirty()), i.context = {
                        model: e,
                        overallProgress: u,
                        modifyOutputEnd: c
                    }, i.agent = a, i.__block = u, Oo(t, e, i);
                }
                var a = n.overallTask = n.overallTask || ao({
                    reset: Io
                });
                a.context = {
                    ecModel: i,
                    api: r,
                    overallReset: e.overallReset,
                    scheduler: t
                };
                var s = a.agentStubMap = a.agentStubMap || N(), l = e.seriesType, h = e.getTargetSeries, u = !0, c = e.modifyOutputEnd;
                l ? i.eachRawSeriesByType(l, o) : h ? h(i, r).each(o) : (u = !1, f(i.getSeries(), o));
                var d = t._pipelineMap;
                s.each(function(t, e) {
                    d.get(e) || (t.dispose(), a.dirty(), s.removeKey(e));
                });
            }(this, i, r, e, n);
        }, this);
    }, ng.prepareView = function(t, e, n, i) {
        var r = t.renderTask, o = r.context;
        o.model = e, o.ecModel = n, o.api = i, r.__block = !t.incrementalPrepareRender, 
        Oo(this, e, r);
    }, ng.performDataProcessorTasks = function(t, e) {
        Mo(this, this._dataProcessorHandlers, t, e, {
            block: !0
        });
    }, ng.performVisualTasks = function(t, e, n) {
        Mo(this, this._visualHandlers, t, e, n);
    }, ng.performSeriesTasks = function(t) {
        var e;
        t.eachSeries(function(t) {
            e |= t.dataTask.perform();
        }), this.unfinished |= e;
    }, ng.plan = function() {
        this._pipelineMap.each(function(t) {
            var e = t.tail;
            do {
                if (e.__block) {
                    t.blockIndex = e.__idxInPipeline;
                    break;
                }
                e = e.getUpstream();
            } while (e);
        });
    };
    var ig = ng.updatePayload = function(t, e) {
        "remain" !== e && (t.context.payload = e);
    }, rg = Po(0);
    So.wrapStageHandler = function(t, e) {
        return x(t) && (t = {
            overallReset: t,
            seriesType: Eo(t)
        }), t.uid = Ji("stageHandler"), e && (t.visualType = e), t;
    };
    var og, ag = {}, sg = {};
    Bo(ag, mp), Bo(sg, Nr), ag.eachSeriesByType = ag.eachRawSeriesByType = function(t) {
        og = t;
    }, ag.eachComponent = function(t) {
        "series" === t.mainType && t.subType && (og = t.subType);
    };
    var lg = [ "#37A2DA", "#32C5E9", "#67E0E3", "#9FE6B8", "#FFDB5C", "#ff9f7f", "#fb7293", "#E062AE", "#E690D1", "#e7bcf3", "#9d96f5", "#8378EA", "#96BFFF" ], hg = {
        color: lg,
        colorLayer: [ [ "#37A2DA", "#ffd85c", "#fd7b5f" ], [ "#37A2DA", "#67E0E3", "#FFDB5C", "#ff9f7f", "#E062AE", "#9d96f5" ], [ "#37A2DA", "#32C5E9", "#9FE6B8", "#FFDB5C", "#ff9f7f", "#fb7293", "#e7bcf3", "#8378EA", "#96BFFF" ], lg ]
    }, ug = "#eee", cg = function() {
        return {
            axisLine: {
                lineStyle: {
                    color: ug
                }
            },
            axisTick: {
                lineStyle: {
                    color: ug
                }
            },
            axisLabel: {
                textStyle: {
                    color: ug
                }
            },
            splitLine: {
                lineStyle: {
                    type: "dashed",
                    color: "#aaa"
                }
            },
            splitArea: {
                areaStyle: {
                    color: ug
                }
            }
        };
    }, dg = [ "#dd6b66", "#759aa0", "#e69d87", "#8dc1a9", "#ea7e53", "#eedd78", "#73a373", "#73b9bc", "#7289ab", "#91ca8c", "#f49f42" ], fg = {
        color: dg,
        backgroundColor: "#333",
        tooltip: {
            axisPointer: {
                lineStyle: {
                    color: ug
                },
                crossStyle: {
                    color: ug
                },
                label: {
                    color: "#000"
                }
            }
        },
        legend: {
            textStyle: {
                color: ug
            }
        },
        textStyle: {
            color: ug
        },
        title: {
            textStyle: {
                color: ug
            }
        },
        toolbox: {
            iconStyle: {
                normal: {
                    borderColor: ug
                }
            }
        },
        dataZoom: {
            textStyle: {
                color: ug
            }
        },
        visualMap: {
            textStyle: {
                color: ug
            }
        },
        timeline: {
            lineStyle: {
                color: ug
            },
            itemStyle: {
                normal: {
                    color: dg[1]
                }
            },
            label: {
                normal: {
                    textStyle: {
                        color: ug
                    }
                }
            },
            controlStyle: {
                normal: {
                    color: ug,
                    borderColor: ug
                }
            }
        },
        timeAxis: cg(),
        logAxis: cg(),
        valueAxis: cg(),
        categoryAxis: cg(),
        line: {
            symbol: "circle"
        },
        graph: {
            color: dg
        },
        gauge: {
            title: {
                textStyle: {
                    color: ug
                }
            }
        },
        candlestick: {
            itemStyle: {
                normal: {
                    color: "#FD1050",
                    color0: "#0CF49B",
                    borderColor: "#FD1050",
                    borderColor0: "#0CF49B"
                }
            }
        }
    };
    fg.categoryAxis.splitLine.show = !1, ep.extend({
        type: "dataset",
        defaultOption: {
            seriesLayoutBy: dp,
            sourceHeader: null,
            dimensions: null,
            source: null
        },
        optionUpdated: function() {
            !function(t) {
                var e = t.option.source, n = up;
                if (M(e)) n = cp; else if (_(e)) {
                    0 === e.length && (n = sp);
                    for (var i = 0, r = e.length; r > i; i++) {
                        var o = e[i];
                        if (null != o) {
                            if (_(o)) {
                                n = sp;
                                break;
                            }
                            if (b(o)) {
                                n = lp;
                                break;
                            }
                        }
                    }
                } else if (b(e)) {
                    for (var a in e) if (e.hasOwnProperty(a) && d(e[a])) {
                        n = hp;
                        break;
                    }
                } else if (null != e) throw new Error("Invalid data");
                gp(t).sourceFormat = n;
            }(this);
        }
    }), Gp.extend({
        type: "dataset"
    });
    var pg = ni.extend({
        type: "ellipse",
        shape: {
            cx: 0,
            cy: 0,
            rx: 0,
            ry: 0
        },
        buildPath: function(t, e) {
            var n = .5522848, i = e.cx, r = e.cy, o = e.rx, a = e.ry, s = o * n, l = a * n;
            t.moveTo(i - o, r), t.bezierCurveTo(i - o, r - l, i - s, r - a, i, r - a), t.bezierCurveTo(i + s, r - a, i + o, r - l, i + o, r), 
            t.bezierCurveTo(i + o, r + l, i + s, r + a, i, r + a), t.bezierCurveTo(i - s, r + a, i - o, r + l, i - o, r), 
            t.closePath();
        }
    }), gg = /[\s,]+/;
    No.prototype.parse = function(t, e) {
        e = e || {};
        var n = zo(t);
        if (!n) throw new Error("Illegal svg");
        var i = new Nu();
        this._root = i;
        var r, o, a = n.getAttribute("viewBox") || "", s = parseFloat(n.getAttribute("width") || e.width), l = parseFloat(n.getAttribute("height") || e.height);
        isNaN(s) && (s = null), isNaN(l) && (l = null), Vo(n, i, null, !0);
        for (var h = n.firstChild; h; ) this._parseNode(h, i), h = h.nextSibling;
        if (a) {
            var u = O(a).split(gg);
            u.length >= 4 && (r = {
                x: parseFloat(u[0] || 0),
                y: parseFloat(u[1] || 0),
                width: parseFloat(u[2]),
                height: parseFloat(u[3])
            });
        }
        if (r && null != s && null != l && (o = function(t, e, n) {
            var i = e / t.width, r = n / t.height, o = Math.min(i, r);
            return {
                scale: [ o, o ],
                position: [ -(t.x + t.width / 2) * o + e / 2, -(t.y + t.height / 2) * o + n / 2 ]
            };
        }(r, s, l), !e.ignoreViewBox)) {
            var c = i;
            (i = new Nu()).add(c), c.scale = o.scale.slice(), c.position = o.position.slice();
        }
        return e.ignoreRootClip || null == s || null == l || i.setClipPath(new sf({
            shape: {
                x: 0,
                y: 0,
                width: s,
                height: l
            }
        })), {
            root: i,
            width: s,
            height: l,
            viewBoxRect: r,
            viewBoxTransform: o
        };
    }, No.prototype._parseNode = function(t, e) {
        var n, i, r = t.nodeName.toLowerCase();
        if ("defs" === r ? this._isDefine = !0 : "text" === r && (this._isText = !0), this._isDefine) {
            if (i = mg[r]) {
                var o = i.call(this, t), a = t.getAttribute("id");
                a && (this._defs[a] = o);
            }
        } else (i = vg[r]) && (n = i.call(this, t, e), e.add(n));
        for (var s = t.firstChild; s; ) 1 === s.nodeType && this._parseNode(s, n), 3 === s.nodeType && this._isText && this._parseText(s, n), 
        s = s.nextSibling;
        "defs" === r ? this._isDefine = !1 : "text" === r && (this._isText = !1);
    }, No.prototype._parseText = function(t, e) {
        if (1 === t.nodeType) {
            var n = t.getAttribute("dx") || 0, i = t.getAttribute("dy") || 0;
            this._textX += parseFloat(n), this._textY += parseFloat(i);
        }
        var r = new jd({
            style: {
                text: t.textContent,
                transformText: !0
            },
            position: [ this._textX || 0, this._textY || 0 ]
        });
        Ro(e, r), Vo(t, r, this._defs);
        var o = r.style.fontSize;
        o && 9 > o && (r.style.fontSize = 9, r.scale = r.scale || [ 1, 1 ], r.scale[0] *= o / 9, 
        r.scale[1] *= o / 9);
        var a = r.getBoundingRect();
        return this._textX += a.width, e.add(r), r;
    };
    var vg = {
        g: function(t, e) {
            var n = new Nu();
            return Ro(e, n), Vo(t, n, this._defs), n;
        },
        rect: function(t, e) {
            var n = new sf();
            return Ro(e, n), Vo(t, n, this._defs), n.setShape({
                x: parseFloat(t.getAttribute("x") || 0),
                y: parseFloat(t.getAttribute("y") || 0),
                width: parseFloat(t.getAttribute("width") || 0),
                height: parseFloat(t.getAttribute("height") || 0)
            }), n;
        },
        circle: function(t, e) {
            var n = new Zd();
            return Ro(e, n), Vo(t, n, this._defs), n.setShape({
                cx: parseFloat(t.getAttribute("cx") || 0),
                cy: parseFloat(t.getAttribute("cy") || 0),
                r: parseFloat(t.getAttribute("r") || 0)
            }), n;
        },
        line: function(t, e) {
            var n = new hf();
            return Ro(e, n), Vo(t, n, this._defs), n.setShape({
                x1: parseFloat(t.getAttribute("x1") || 0),
                y1: parseFloat(t.getAttribute("y1") || 0),
                x2: parseFloat(t.getAttribute("x2") || 0),
                y2: parseFloat(t.getAttribute("y2") || 0)
            }), n;
        },
        ellipse: function(t, e) {
            var n = new pg();
            return Ro(e, n), Vo(t, n, this._defs), n.setShape({
                cx: parseFloat(t.getAttribute("cx") || 0),
                cy: parseFloat(t.getAttribute("cy") || 0),
                rx: parseFloat(t.getAttribute("rx") || 0),
                ry: parseFloat(t.getAttribute("ry") || 0)
            }), n;
        },
        polygon: function(t, e) {
            var n = t.getAttribute("points");
            n && (n = Fo(n));
            var i = new nf({
                shape: {
                    points: n || []
                }
            });
            return Ro(e, i), Vo(t, i, this._defs), i;
        },
        polyline: function(t, e) {
            var n = new ni();
            Ro(e, n), Vo(t, n, this._defs);
            var i = t.getAttribute("points");
            return i && (i = Fo(i)), new rf({
                shape: {
                    points: i || []
                }
            });
        },
        image: function(t, e) {
            var n = new Ke();
            return Ro(e, n), Vo(t, n, this._defs), n.setStyle({
                image: t.getAttribute("xlink:href"),
                x: t.getAttribute("x"),
                y: t.getAttribute("y"),
                width: t.getAttribute("width"),
                height: t.getAttribute("height")
            }), n;
        },
        text: function(t, e) {
            var n = t.getAttribute("x") || 0, i = t.getAttribute("y") || 0, r = t.getAttribute("dx") || 0, o = t.getAttribute("dy") || 0;
            this._textX = parseFloat(n) + parseFloat(r), this._textY = parseFloat(i) + parseFloat(o);
            var a = new Nu();
            return Ro(e, a), Vo(t, a, this._defs), a;
        },
        tspan: function(t, e) {
            var n = t.getAttribute("x"), i = t.getAttribute("y");
            null != n && (this._textX = parseFloat(n)), null != i && (this._textY = parseFloat(i));
            var r = t.getAttribute("dx") || 0, o = t.getAttribute("dy") || 0, a = new Nu();
            return Ro(e, a), Vo(t, a, this._defs), this._textX += r, this._textY += o, a;
        },
        path: function(t, e) {
            var n = oi(t.getAttribute("d") || "");
            return Ro(e, n), Vo(t, n, this._defs), n;
        }
    }, mg = {
        lineargradient: function(t) {
            var e = parseInt(t.getAttribute("x1") || 0, 10), n = parseInt(t.getAttribute("y1") || 0, 10), i = parseInt(t.getAttribute("x2") || 10, 10), r = parseInt(t.getAttribute("y2") || 0, 10), o = new gf(e, n, i, r);
            return function(t, e) {
                for (var n = t.firstChild; n; ) {
                    if (1 === n.nodeType) {
                        var i = n.getAttribute("offset");
                        i = i.indexOf("%") > 0 ? parseInt(i, 10) / 100 : i ? parseFloat(i) : 0;
                        var r = n.getAttribute("stop-color") || "#000000";
                        e.addColorStop(i, r);
                    }
                    n = n.nextSibling;
                }
            }(t, o), o;
        },
        radialgradient: function() {}
    }, yg = {
        fill: "fill",
        stroke: "stroke",
        "stroke-width": "lineWidth",
        opacity: "opacity",
        "fill-opacity": "fillOpacity",
        "stroke-opacity": "strokeOpacity",
        "stroke-dasharray": "lineDash",
        "stroke-dashoffset": "lineDashOffset",
        "stroke-linecap": "lineCap",
        "stroke-linejoin": "lineJoin",
        "stroke-miterlimit": "miterLimit",
        "font-family": "fontFamily",
        "font-size": "fontSize",
        "font-style": "fontStyle",
        "font-weight": "fontWeight",
        "text-align": "textAlign",
        "alignment-baseline": "textBaseline"
    }, _g = /url\(\s*#(.*?)\)/, xg = /(translate|scale|rotate|skewX|skewY|matrix)\(([\-\s0-9\.e,]*)\)/g, wg = /([^\s:;]+)\s*:\s*([^:;]+)/g, bg = N(), Sg = {
        registerMap: function(t, e, n) {
            var i;
            return _(e) ? i = e : e.svg ? i = [ {
                type: "svg",
                source: e.svg,
                specialAreas: e.specialAreas
            } ] : (e.geoJson && !e.features && (n = e.specialAreas, e = e.geoJson), i = [ {
                type: "geoJSON",
                source: e,
                specialAreas: n
            } ]), f(i, function(t) {
                var e = t.type;
                "geoJson" === e && (e = t.type = "geoJSON");
                var n = Mg[e];
                wh && L(n, "Illegal map type: " + e), n(t);
            }), bg.set(t, i);
        },
        retrieveMap: function(t) {
            return bg.get(t);
        }
    }, Mg = {
        geoJSON: function(t) {
            var e = t.source;
            t.geoJSON = w(e) ? "undefined" != typeof JSON && JSON.parse ? JSON.parse(e) : new Function("return (" + e + ");")() : e;
        },
        svg: function(t) {
            t.svgXML = zo(t.source);
        }
    }, Ig = L, Tg = f, Cg = x, Ag = b, Dg = ep.parseClassType, kg = "4.9.0", Pg = {
        zrender: "4.3.2"
    }, Lg = 1e3, Og = 1e3, Eg = 3e3, Bg = {
        PROCESSOR: {
            FILTER: Lg,
            SERIES_FILTER: 800,
            STATISTIC: 5e3
        },
        VISUAL: {
            LAYOUT: Og,
            PROGRESSIVE_LAYOUT: 1100,
            GLOBAL: 2e3,
            CHART: Eg,
            POST_CHART_LAYOUT: 3500,
            COMPONENT: 4e3,
            BRUSH: 5e3
        }
    }, zg = "__flagInMainProcess", Ng = "__optionUpdated", Rg = /^[a-zA-Z0-9_]+$/;
    Wo.prototype.on = Go("on", !0), Wo.prototype.off = Go("off", !0), Wo.prototype.one = Go("one", !0), 
    c(Wo, Yh);
    var Fg = Xo.prototype;
    Fg._onframe = function() {
        if (!this._disposed) {
            var t = this._scheduler;
            if (this[Ng]) {
                var e = this[Ng].silent;
                this[zg] = !0, Yo(this), Vg.update.call(this), this[zg] = !1, this[Ng] = !1, Ko.call(this, e), 
                $o.call(this, e);
            } else if (t.unfinished) {
                var n = 1, i = this._model;
                this._api;
                t.unfinished = !1;
                do {
                    var r = +new Date();
                    t.performSeriesTasks(i), t.performDataProcessorTasks(i), jo(this, i), t.performVisualTasks(i), 
                    ea(this, this._model, 0, "remain"), n -= +new Date() - r;
                } while (n > 0 && t.unfinished);
                t.unfinished || this._zr.flush();
            }
        }
    }, Fg.getDom = function() {
        return this._dom;
    }, Fg.getZr = function() {
        return this._zr;
    }, Fg.setOption = function(t, e, n) {
        if (wh && Ig(!this[zg], "`setOption` should not be called during main process."), 
        this._disposed) ia(this.id); else {
            var i;
            if (Ag(e) && (n = e.lazyUpdate, i = e.silent, e = e.notMerge), this[zg] = !0, !this._model || e) {
                var r = new Fr(this._api), o = this._theme, a = this._model = new mp();
                a.scheduler = this._scheduler, a.init(null, null, o, r);
            }
            this._model.setOption(t, Ug), n ? (this[Ng] = {
                silent: i
            }, this[zg] = !1) : (Yo(this), Vg.update.call(this), this._zr.flush(), this[Ng] = !1, 
            this[zg] = !1, Ko.call(this, i), $o.call(this, i));
        }
    }, Fg.setTheme = function() {
        console.error("ECharts#setTheme() is DEPRECATED in ECharts 3.0");
    }, Fg.getModel = function() {
        return this._model;
    }, Fg.getOption = function() {
        return this._model && this._model.getOption();
    }, Fg.getWidth = function() {
        return this._zr.getWidth();
    }, Fg.getHeight = function() {
        return this._zr.getHeight();
    }, Fg.getDevicePixelRatio = function() {
        return this._zr.painter.dpr || window.devicePixelRatio || 1;
    }, Fg.getRenderedCanvas = function(t) {
        if (Mh.canvasSupported) return (t = t || {}).pixelRatio = t.pixelRatio || 1, t.backgroundColor = t.backgroundColor || this._model.get("backgroundColor"), 
        this._zr.painter.getRenderedCanvas(t);
    }, Fg.getSvgDataURL = function() {
        if (Mh.svgSupported) {
            var t = this._zr;
            return f(t.storage.getDisplayList(), function(t) {
                t.stopAnimation(!0);
            }), t.painter.toDataURL();
        }
    }, Fg.getDataURL = function(t) {
        if (!this._disposed) {
            var e = (t = t || {}).excludeComponents, n = this._model, i = [], r = this;
            Tg(e, function(t) {
                n.eachComponent({
                    mainType: t
                }, function(t) {
                    var e = r._componentsMap[t.__viewId];
                    e.group.ignore || (i.push(e), e.group.ignore = !0);
                });
            });
            var o = "svg" === this._zr.painter.getType() ? this.getSvgDataURL() : this.getRenderedCanvas(t).toDataURL("image/" + (t && t.type || "png"));
            return Tg(i, function(t) {
                t.group.ignore = !1;
            }), o;
        }
        ia(this.id);
    }, Fg.getConnectedDataURL = function(t) {
        if (this._disposed) ia(this.id); else if (Mh.canvasSupported) {
            var e = "svg" === t.type, n = this.group, r = Math.min, o = Math.max, a = 1 / 0;
            if ($g[n]) {
                var s = a, l = a, h = -a, u = -a, c = [], d = t && t.pixelRatio || 1;
                f(Kg, function(a) {
                    if (a.group === n) {
                        var d = e ? a.getZr().painter.getSvgDom().innerHTML : a.getRenderedCanvas(i(t)), f = a.getDom().getBoundingClientRect();
                        s = r(f.left, s), l = r(f.top, l), h = o(f.right, h), u = o(f.bottom, u), c.push({
                            dom: d,
                            left: f.left,
                            top: f.top
                        });
                    }
                });
                var p = (h *= d) - (s *= d), g = (u *= d) - (l *= d), v = Bh(), m = cn(v, {
                    renderer: e ? "svg" : "canvas"
                });
                if (m.resize({
                    width: p,
                    height: g
                }), e) {
                    var y = "";
                    return Tg(c, function(t) {
                        var e = t.left - s, n = t.top - l;
                        y += '<g transform="translate(' + e + "," + n + ')">' + t.dom + "</g>";
                    }), m.painter.getSvgRoot().innerHTML = y, t.connectedBackgroundColor && m.painter.setBackgroundColor(t.connectedBackgroundColor), 
                    m.refreshImmediately(), m.painter.toDataURL();
                }
                return t.connectedBackgroundColor && m.add(new sf({
                    shape: {
                        x: 0,
                        y: 0,
                        width: p,
                        height: g
                    },
                    style: {
                        fill: t.connectedBackgroundColor
                    }
                })), Tg(c, function(t) {
                    var e = new Ke({
                        style: {
                            x: t.left * d - s,
                            y: t.top * d - l,
                            image: t.dom
                        }
                    });
                    m.add(e);
                }), m.refreshImmediately(), v.toDataURL("image/" + (t && t.type || "png"));
            }
            return this.getDataURL(t);
        }
    }, Fg.convertToPixel = y(Uo, "convertToPixel"), Fg.convertFromPixel = y(Uo, "convertFromPixel"), 
    Fg.containPixel = function(t, e) {
        var n;
        if (!this._disposed) return f(t = xn(this._model, t), function(t, i) {
            i.indexOf("Models") >= 0 && f(t, function(t) {
                var r = t.coordinateSystem;
                if (r && r.containPoint) n |= !!r.containPoint(e); else if ("seriesModels" === i) {
                    var o = this._chartsMap[t.__viewId];
                    o && o.containPoint ? n |= o.containPoint(e, t) : wh && console.warn(i + ": " + (o ? "The found component do not support containPoint." : "No view mapping to the found component."));
                } else wh && console.warn(i + ": containPoint is not supported");
            }, this);
        }, this), !!n;
        ia(this.id);
    }, Fg.getVisual = function(t, e) {
        var n = (t = xn(this._model, t, {
            defaultMainType: "series"
        })).seriesModel;
        wh && (n || console.warn("There is no specified seires model"));
        var i = n.getData(), r = t.hasOwnProperty("dataIndexInside") ? t.dataIndexInside : t.hasOwnProperty("dataIndex") ? i.indexOfRawIndex(t.dataIndex) : null;
        return null != r ? i.getItemVisual(r, e) : i.getVisual(e);
    }, Fg.getViewOfComponentModel = function(t) {
        return this._componentsMap[t.__viewId];
    }, Fg.getViewOfSeriesModel = function(t) {
        return this._chartsMap[t.__viewId];
    };
    var Vg = {
        prepareAndUpdate: function(t) {
            Yo(this), Vg.update.call(this, t);
        },
        update: function(t) {
            var e = this._model, n = this._api, i = this._zr, r = this._coordSysMgr, o = this._scheduler;
            if (e) {
                o.restoreData(e, t), o.performSeriesTasks(e), r.create(e, n), o.performDataProcessorTasks(e, t), 
                jo(this, e), r.update(e, n), Jo(e), o.performVisualTasks(e, t), ta(this, e, n, t);
                var a = e.get("backgroundColor") || "transparent";
                if (Mh.canvasSupported) i.setBackgroundColor(a); else {
                    var s = zt(a);
                    a = Gt(s, "rgb"), 0 === s[3] && (a = "transparent");
                }
                na(e, n);
            }
        },
        updateTransform: function(t) {
            var e = this._model, n = this, i = this._api;
            if (e) {
                var r = [];
                e.eachComponent(function(o, a) {
                    var s = n.getViewOfComponentModel(a);
                    if (s && s.__alive) if (s.updateTransform) {
                        var l = s.updateTransform(a, e, i, t);
                        l && l.update && r.push(s);
                    } else r.push(s);
                });
                var o = N();
                e.eachSeries(function(r) {
                    var a = n._chartsMap[r.__viewId];
                    if (a.updateTransform) {
                        var s = a.updateTransform(r, e, i, t);
                        s && s.update && o.set(r.uid, 1);
                    } else o.set(r.uid, 1);
                }), Jo(e), this._scheduler.performVisualTasks(e, t, {
                    setDirty: !0,
                    dirtyMap: o
                }), ea(n, e, 0, t, o), na(e, this._api);
            }
        },
        updateView: function(t) {
            var e = this._model;
            e && (mo.markUpdateMethod(t, "updateView"), Jo(e), this._scheduler.performVisualTasks(e, t, {
                setDirty: !0
            }), ta(this, this._model, this._api, t), na(e, this._api));
        },
        updateVisual: function(t) {
            Vg.update.call(this, t);
        },
        updateLayout: function(t) {
            Vg.update.call(this, t);
        }
    };
    Fg.resize = function(t) {
        if (wh && Ig(!this[zg], "`resize` should not be called during main process."), this._disposed) ia(this.id); else {
            this._zr.resize(t);
            var e = this._model;
            if (this._loadingFX && this._loadingFX.resize(), e) {
                var n = e.resetOption("media"), i = t && t.silent;
                this[zg] = !0, n && Yo(this), Vg.update.call(this), this[zg] = !1, Ko.call(this, i), 
                $o.call(this, i);
            }
        }
    }, Fg.showLoading = function(t, e) {
        if (this._disposed) ia(this.id); else if (Ag(t) && (e = t, t = ""), t = t || "default", 
        this.hideLoading(), Zg[t]) {
            var n = Zg[t](this._api, e), i = this._zr;
            this._loadingFX = n, i.add(n);
        } else wh && console.warn("Loading effects " + t + " not exists.");
    }, Fg.hideLoading = function() {
        return this._disposed ? void ia(this.id) : (this._loadingFX && this._zr.remove(this._loadingFX), 
        void (this._loadingFX = null));
    }, Fg.makeActionFromEvent = function(t) {
        var e = a({}, t);
        return e.type = Wg[t.type], e;
    }, Fg.dispatchAction = function(t, e) {
        if (this._disposed) ia(this.id); else if (Ag(e) || (e = {
            silent: !!e
        }), Gg[t.type] && this._model) {
            if (this[zg]) return void this._pendingActions.push(t);
            Zo.call(this, t, e.silent), e.flush ? this._zr.flush(!0) : !1 !== e.flush && Mh.browser.weChat && this._throttledZrFlush(), 
            Ko.call(this, e.silent), $o.call(this, e.silent);
        }
    }, Fg.appendData = function(t) {
        if (this._disposed) ia(this.id); else {
            var e = t.seriesIndex, n = this.getModel().getSeriesByIndex(e);
            wh && Ig(t.data && n), n.appendData(t), this._scheduler.unfinished = !0;
        }
    }, Fg.on = Go("on", !1), Fg.off = Go("off", !1), Fg.one = Go("one", !1);
    var Hg = [ "click", "dblclick", "mouseover", "mouseout", "mousemove", "mousedown", "mouseup", "globalout", "contextmenu" ];
    Fg._initEvents = function() {
        Tg(Hg, function(t) {
            var e = function(e) {
                var n, i = this.getModel(), r = e.target, o = "globalout" === t;
                if (o) n = {}; else if (r && null != r.dataIndex) {
                    var s = r.dataModel || i.getSeriesByIndex(r.seriesIndex);
                    n = s && s.getDataParams(r.dataIndex, r.dataType, r) || {};
                } else r && r.eventData && (n = a({}, r.eventData));
                if (n) {
                    var l = n.componentType, h = n.componentIndex;
                    ("markLine" === l || "markPoint" === l || "markArea" === l) && (l = "series", h = n.seriesIndex);
                    var u = l && null != h && i.getComponent(l, h), c = u && this["series" === u.mainType ? "_chartsMap" : "_componentsMap"][u.__viewId];
                    wh && (o || u && c || console.warn("model or view can not be found by params")), 
                    n.event = e, n.type = t, this._ecEventProcessor.eventInfo = {
                        targetEl: r,
                        packedEvent: n,
                        model: u,
                        view: c
                    }, this.trigger(t, n);
                }
            };
            e.zrEventfulCallAtLast = !0, this._zr.on(t, e, this);
        }, this), Tg(Wg, function(t, e) {
            this._messageCenter.on(e, function(t) {
                this.trigger(e, t);
            }, this);
        }, this);
    }, Fg.isDisposed = function() {
        return this._disposed;
    }, Fg.clear = function() {
        return this._disposed ? void ia(this.id) : void this.setOption({
            series: []
        }, !0);
    }, Fg.dispose = function() {
        if (this._disposed) ia(this.id); else {
            this._disposed = !0, bn(this.getDom(), tv, "");
            var t = this._api, e = this._model;
            Tg(this._componentsViews, function(n) {
                n.dispose(e, t);
            }), Tg(this._chartsViews, function(n) {
                n.dispose(e, t);
            }), this._zr.dispose(), delete Kg[this.id];
        }
    }, c(Xo, Yh), aa.prototype = {
        constructor: aa,
        normalizeQuery: function(t) {
            var e = {}, n = {}, i = {};
            if (w(t)) {
                var r = Dg(t);
                e.mainType = r.main || null, e.subType = r.sub || null;
            } else {
                var o = [ "Index", "Name", "Id" ], a = {
                    name: 1,
                    dataIndex: 1,
                    dataType: 1
                };
                f(t, function(t, r) {
                    for (var s = !1, l = 0; l < o.length; l++) {
                        var h = o[l], u = r.lastIndexOf(h);
                        if (u > 0 && u === r.length - h.length) {
                            var c = r.slice(0, u);
                            "data" !== c && (e.mainType = c, e[h.toLowerCase()] = t, s = !0);
                        }
                    }
                    a.hasOwnProperty(r) && (n[r] = t, s = !0), s || (i[r] = t);
                });
            }
            return {
                cptQuery: e,
                dataQuery: n,
                otherQuery: i
            };
        },
        filter: function(t, e) {
            function n(t, e, n, i) {
                return null == t[n] || e[i || n] === t[n];
            }
            var i = this.eventInfo;
            if (!i) return !0;
            var r = i.targetEl, o = i.packedEvent, a = i.model, s = i.view;
            if (!a || !s) return !0;
            var l = e.cptQuery, h = e.dataQuery;
            return n(l, a, "mainType") && n(l, a, "subType") && n(l, a, "index", "componentIndex") && n(l, a, "name") && n(l, a, "id") && n(h, o, "name") && n(h, o, "dataIndex") && n(h, o, "dataType") && (!s.filterForExposedEvent || s.filterForExposedEvent(t, e.otherQuery, r, o));
        },
        afterTrigger: function() {
            this.eventInfo = null;
        }
    };
    var Gg = {}, Wg = {}, Xg = [], Ug = [], Yg = [], qg = [], jg = {}, Zg = {}, Kg = {}, $g = {}, Qg = new Date() - 0, Jg = new Date() - 0, tv = "_echarts_instance_", ev = sa;
    pa(2e3, Qp), ua(Pp), ca(900, function(t) {
        var e = N();
        t.eachSeries(function(t) {
            var n = t.get("stack");
            if (n) {
                var i = e.get(n) || e.set(n, []), r = t.getData(), o = {
                    stackResultDimension: r.getCalculationInfo("stackResultDimension"),
                    stackedOverDimension: r.getCalculationInfo("stackedOverDimension"),
                    stackedDimension: r.getCalculationInfo("stackedDimension"),
                    stackedByDimension: r.getCalculationInfo("stackedByDimension"),
                    isStackedByIndex: r.getCalculationInfo("isStackedByIndex"),
                    data: r,
                    seriesModel: t
                };
                if (!o.stackedDimension || !o.isStackedByIndex && !o.stackedByDimension) return;
                i.length && r.setCalculationInfo("stackedOnSeries", i[i.length - 1].seriesModel), 
                i.push(o);
            }
        }), e.each(Kr);
    }), va("default", function(t, e) {
        s(e = e || {}, {
            text: "loading",
            textColor: "#000",
            fontSize: "12px",
            maskColor: "rgba(255, 255, 255, 0.8)",
            showSpinner: !0,
            color: "#c23531",
            spinnerRadius: 10,
            lineWidth: 5,
            zlevel: 0
        });
        var n = new Nu(), i = new sf({
            style: {
                fill: e.maskColor
            },
            zlevel: e.zlevel,
            z: 1e4
        });
        n.add(i);
        var r = e.fontSize + " sans-serif", o = new sf({
            style: {
                fill: "none",
                text: e.text,
                font: r,
                textPosition: "right",
                textDistance: 10,
                textFill: e.textColor
            },
            zlevel: e.zlevel,
            z: 10001
        });
        if (n.add(o), e.showSpinner) {
            var a = new df({
                shape: {
                    startAngle: -eg / 2,
                    endAngle: -eg / 2 + .1,
                    r: e.spinnerRadius
                },
                style: {
                    stroke: e.color,
                    lineCap: "round",
                    lineWidth: e.lineWidth
                },
                zlevel: e.zlevel,
                z: 10001
            });
            a.animateShape(!0).when(1e3, {
                endAngle: 3 * eg / 2
            }).start("circularInOut"), a.animateShape(!0).when(1e3, {
                startAngle: 3 * eg / 2
            }).delay(300).start("circularInOut"), n.add(a);
        }
        return n.resize = function() {
            var n = _e(e.text, r), s = e.showSpinner ? e.spinnerRadius : 0, l = (t.getWidth() - 2 * s - (e.showSpinner && n ? 10 : 0) - n) / 2 - (e.showSpinner ? 0 : n / 2), h = t.getHeight() / 2;
            e.showSpinner && a.setShape({
                cx: l,
                cy: h
            }), o.setShape({
                x: l - s,
                y: h - s,
                width: 2 * s,
                height: 2 * s
            }), i.setShape({
                x: 0,
                y: 0,
                width: t.getWidth(),
                height: t.getHeight()
            });
        }, n.resize(), n;
    }), da({
        type: "highlight",
        event: "highlight",
        update: "highlight"
    }, R), da({
        type: "downplay",
        event: "downplay",
        update: "downplay"
    }, R), ha("light", hg), ha("dark", fg);
    ba.prototype = {
        constructor: ba,
        add: function(t) {
            return this._add = t, this;
        },
        update: function(t) {
            return this._update = t, this;
        },
        remove: function(t) {
            return this._remove = t, this;
        },
        execute: function() {
            var t = this._old, e = this._new, n = {}, i = [], r = [];
            for (Sa(t, {}, i, "_oldKeyGetter", this), Sa(e, n, r, "_newKeyGetter", this), o = 0; o < t.length; o++) {
                if (null != (s = n[a = i[o]])) (h = s.length) ? (1 === h && (n[a] = null), s = s.shift()) : n[a] = null, 
                this._update && this._update(s, o); else this._remove && this._remove(o);
            }
            for (var o = 0; o < r.length; o++) {
                var a = r[o];
                if (n.hasOwnProperty(a)) {
                    var s;
                    if (null == (s = n[a])) continue;
                    if (s.length) for (var l = 0, h = s.length; h > l; l++) this._add && this._add(s[l]); else this._add && this._add(s);
                }
            }
        }
    };
    var nv = N([ "tooltip", "label", "itemName", "itemId", "seriesName" ]), iv = b, rv = "undefined", ov = -1, av = "e\0\0", sv = {
        float: ("undefined" == typeof Float64Array ? "undefined" : t(Float64Array)) === rv ? Array : Float64Array,
        int: ("undefined" == typeof Int32Array ? "undefined" : t(Int32Array)) === rv ? Array : Int32Array,
        ordinal: Array,
        number: Array,
        time: Array
    }, lv = ("undefined" == typeof Uint32Array ? "undefined" : t(Uint32Array)) === rv ? Array : Uint32Array, hv = ("undefined" == typeof Int32Array ? "undefined" : t(Int32Array)) === rv ? Array : Int32Array, uv = ("undefined" == typeof Uint16Array ? "undefined" : t(Uint16Array)) === rv ? Array : Uint16Array, cv = [ "hasItemOption", "_nameList", "_idList", "_invertedIndicesMap", "_rawData", "_chunkSize", "_chunkCount", "_dimValueGetter", "_count", "_rawCount", "_nameDimIdx", "_idDimIdx" ], dv = [ "_extent", "_approximateExtent", "_rawExtent" ], fv = function(t, e) {
        t = t || [ "x", "y" ];
        for (var n = {}, i = [], r = {}, o = 0; o < t.length; o++) {
            var a = t[o];
            w(a) ? a = new Ia({
                name: a
            }) : a instanceof Ia || (a = new Ia(a));
            var s = a.name;
            a.type = a.type || "float", a.coordDim || (a.coordDim = s, a.coordDimIndex = 0), 
            a.otherDims = a.otherDims || {}, i.push(s), n[s] = a, a.index = o, a.createInvertedIndices && (r[s] = []);
        }
        this.dimensions = i, this._dimensionInfos = n, this.hostModel = e, this.dataType, 
        this._indices = null, this._count = 0, this._rawCount = 0, this._storage = {}, this._nameList = [], 
        this._idList = [], this._optionModels = [], this._visual = {}, this._layout = {}, 
        this._itemVisuals = [], this.hasItemVisual = {}, this._itemLayouts = [], this._graphicEls = [], 
        this._chunkSize = 1e5, this._chunkCount = 0, this._rawData, this._rawExtent = {}, 
        this._extent = {}, this._approximateExtent = {}, this._dimensionsSummary = function(t) {
            var e = {}, n = e.encode = {}, i = N(), r = [], o = [], a = e.userOutput = {
                dimensionNames: t.dimensions.slice(),
                encode: {}
            };
            f(t.dimensions, function(e) {
                var s = t.getDimensionInfo(e), l = s.coordDim;
                if (l) {
                    wh && L(null == nv.get(l));
                    var h = s.coordDimIndex;
                    Ma(n, l)[h] = e, s.isExtraCoord || (i.set(l, 1), function(t) {
                        return !("ordinal" === t || "time" === t);
                    }(s.type) && (r[0] = e), Ma(a.encode, l)[h] = s.index), s.defaultTooltip && o.push(e);
                }
                nv.each(function(t, e) {
                    var i = Ma(n, e), r = s.otherDims[e];
                    null != r && !1 !== r && (i[r] = s.name);
                });
            });
            var s = [], l = {};
            i.each(function(t, e) {
                var i = n[e];
                l[e] = i[0], s = s.concat(i);
            }), e.dataDimsOnCoord = s, e.encodeFirstDimNotExtra = l;
            var h = n.label;
            h && h.length && (r = h.slice());
            var u = n.tooltip;
            return u && u.length ? o = u.slice() : o.length || (o = r.slice()), n.defaultedLabel = r, 
            n.defaultedTooltip = o, e;
        }(this), this._invertedIndicesMap = r, this._calculationInfo = {}, this.userOutput = this._dimensionsSummary.userOutput;
    }, pv = fv.prototype;
    pv.type = "list", pv.hasItemOption = !0, pv.getDimension = function(t) {
        return ("number" == typeof t || !isNaN(t) && !this._dimensionInfos.hasOwnProperty(t)) && (t = this.dimensions[t]), 
        t;
    }, pv.getDimensionInfo = function(t) {
        return this._dimensionInfos[this.getDimension(t)];
    }, pv.getDimensionsOnCoord = function() {
        return this._dimensionsSummary.dataDimsOnCoord.slice();
    }, pv.mapDimension = function(t, e) {
        var n = this._dimensionsSummary;
        if (null == e) return n.encodeFirstDimNotExtra[t];
        var i = n.encode[t];
        return !0 === e ? (i || []).slice() : i && i[e];
    }, pv.initData = function(t, e, n) {
        var i = Mr.isInstance(t) || d(t);
        if (i && (t = new $r(t, this.dimensions.length)), wh && !i && ("function" != typeof t.getItem || "function" != typeof t.count)) throw new Error("Inavlid data provider.");
        this._rawData = t, this._storage = {}, this._indices = null, this._nameList = e || [], 
        this._idList = [], this._nameRepeatCount = {}, n || (this.hasItemOption = !1), this.defaultDimValueGetter = Bp[this._rawData.getSource().sourceFormat], 
        this._dimValueGetter = n = n || this.defaultDimValueGetter, this._dimValueGetterArrayRows = Bp.arrayRows, 
        this._rawExtent = {}, this._initDataFromProvider(0, t.count()), t.pure && (this.hasItemOption = !1);
    }, pv.getProvider = function() {
        return this._rawData;
    }, pv.appendData = function(t) {
        wh && L(!this._indices, "appendData can only be called on raw data.");
        var e = this._rawData, n = this.count();
        e.appendData(t);
        var i = e.count();
        e.persistent || (i += n), this._initDataFromProvider(n, i);
    }, pv.appendValues = function(t, e) {
        for (var n = this._chunkSize, i = this._storage, r = this.dimensions, o = r.length, a = this._rawExtent, s = this.count(), l = s + Math.max(t.length, e ? e.length : 0), h = this._chunkCount, u = 0; o > u; u++) {
            a[m = r[u]] || (a[m] = [ 1 / 0, -1 / 0 ]), i[m] || (i[m] = []), Da(i, this._dimensionInfos[m], n, h, l), 
            this._chunkCount = i[m].length;
        }
        for (var c = new Array(o), d = s; l > d; d++) {
            for (var f = d - s, p = Math.floor(d / n), g = d % n, v = 0; o > v; v++) {
                var m = r[v], y = this._dimValueGetterArrayRows(t[f] || c, m, f, v);
                i[m][p][g] = y;
                var _ = a[m];
                y < _[0] && (_[0] = y), y > _[1] && (_[1] = y);
            }
            e && (this._nameList[d] = e[f]);
        }
        this._rawCount = this._count = l, this._extent = {}, ka(this);
    }, pv._initDataFromProvider = function(t, e) {
        if (!(t >= e)) {
            for (var n, i = this._chunkSize, r = this._rawData, o = this._storage, a = this.dimensions, s = a.length, l = this._dimensionInfos, h = this._nameList, u = this._idList, c = this._rawExtent, d = this._nameRepeatCount = {}, f = this._chunkCount, p = 0; s > p; p++) {
                c[w = a[p]] || (c[w] = [ 1 / 0, -1 / 0 ]);
                var g = l[w];
                0 === g.otherDims.itemName && (n = this._nameDimIdx = p), 0 === g.otherDims.itemId && (this._idDimIdx = p), 
                o[w] || (o[w] = []), Da(o, g, i, f, e), this._chunkCount = o[w].length;
            }
            for (var v = new Array(s), m = t; e > m; m++) {
                v = r.getItem(m, v);
                for (var y = Math.floor(m / i), _ = m % i, x = 0; s > x; x++) {
                    var w, b = o[w = a[x]][y], S = this._dimValueGetter(v, w, m, x);
                    b[_] = S;
                    var M = c[w];
                    S < M[0] && (M[0] = S), S > M[1] && (M[1] = S);
                }
                if (!r.pure) {
                    var I = h[m];
                    if (v && null == I) if (null != v.name) h[m] = I = v.name; else if (null != n) {
                        var T = a[n], C = o[T][y];
                        if (C) {
                            I = C[_];
                            var A = l[T].ordinalMeta;
                            A && A.categories.length && (I = A.categories[I]);
                        }
                    }
                    var D = null == v ? null : v.id;
                    null == D && null != I && (d[I] = d[I] || 0, D = I, d[I] > 0 && (D += "__ec__" + d[I]), 
                    d[I]++), null != D && (u[m] = D);
                }
            }
            !r.persistent && r.clean && r.clean(), this._rawCount = this._count = e, this._extent = {}, 
            ka(this);
        }
    }, pv.count = function() {
        return this._count;
    }, pv.getIndices = function() {
        var t = this._indices;
        if (t) {
            var e = t.constructor, n = this._count;
            if (e === Array) {
                r = new e(n);
                for (var i = 0; n > i; i++) r[i] = t[i];
            } else r = new e(t.buffer, 0, n);
        } else {
            var r = new (e = Ta(this))(this.count());
            for (i = 0; i < r.length; i++) r[i] = i;
        }
        return r;
    }, pv.get = function(t, e) {
        if (!(e >= 0 && e < this._count)) return NaN;
        var n = this._storage;
        if (!n[t]) return NaN;
        e = this.getRawIndex(e);
        var i = Math.floor(e / this._chunkSize), r = e % this._chunkSize;
        return n[t][i][r];
    }, pv.getByRawIndex = function(t, e) {
        if (!(e >= 0 && e < this._rawCount)) return NaN;
        var n = this._storage[t];
        if (!n) return NaN;
        var i = Math.floor(e / this._chunkSize), r = e % this._chunkSize;
        return n[i][r];
    }, pv._getFast = function(t, e) {
        var n = Math.floor(e / this._chunkSize), i = e % this._chunkSize;
        return this._storage[t][n][i];
    }, pv.getValues = function(t, e) {
        var n = [];
        _(t) || (e = t, t = this.dimensions);
        for (var i = 0, r = t.length; r > i; i++) n.push(this.get(t[i], e));
        return n;
    }, pv.hasValue = function(t) {
        for (var e = this._dimensionsSummary.dataDimsOnCoord, n = 0, i = e.length; i > n; n++) if (isNaN(this.get(e[n], t))) return !1;
        return !0;
    }, pv.getDataExtent = function(t) {
        t = this.getDimension(t);
        var e = [ 1 / 0, -1 / 0 ];
        if (!this._storage[t]) return e;
        var n, i = this.count();
        if (!this._indices) return this._rawExtent[t].slice();
        if (n = this._extent[t]) return n.slice();
        for (var r = (n = e)[0], o = n[1], a = 0; i > a; a++) {
            var s = this._getFast(t, this.getRawIndex(a));
            r > s && (r = s), s > o && (o = s);
        }
        return n = [ r, o ], this._extent[t] = n, n;
    }, pv.getApproximateExtent = function(t) {
        return t = this.getDimension(t), this._approximateExtent[t] || this.getDataExtent(t);
    }, pv.setApproximateExtent = function(t, e) {
        e = this.getDimension(e), this._approximateExtent[e] = t.slice();
    }, pv.getCalculationInfo = function(t) {
        return this._calculationInfo[t];
    }, pv.setCalculationInfo = function(t, e) {
        iv(t) ? a(this._calculationInfo, t) : this._calculationInfo[t] = e;
    }, pv.getSum = function(t) {
        var e = 0;
        if (this._storage[t]) for (var n = 0, i = this.count(); i > n; n++) {
            var r = this.get(t, n);
            isNaN(r) || (e += r);
        }
        return e;
    }, pv.getMedian = function(t) {
        var e = [];
        this.each(t, function(t) {
            isNaN(t) || e.push(t);
        });
        var n = [].concat(e).sort(function(t, e) {
            return t - e;
        }), i = this.count();
        return 0 === i ? 0 : i % 2 == 1 ? n[(i - 1) / 2] : (n[i / 2] + n[i / 2 - 1]) / 2;
    }, pv.rawIndexOf = function(t, e) {
        var n = t && this._invertedIndicesMap[t];
        if (wh && !n) throw new Error("Do not supported yet");
        var i = n[e];
        return null == i || isNaN(i) ? ov : i;
    }, pv.indexOfName = function(t) {
        for (var e = 0, n = this.count(); n > e; e++) if (this.getName(e) === t) return e;
        return -1;
    }, pv.indexOfRawIndex = function(t) {
        if (t >= this._rawCount || 0 > t) return -1;
        if (!this._indices) return t;
        var e = this._indices, n = e[t];
        if (null != n && n < this._count && n === t) return t;
        for (var i = 0, r = this._count - 1; r >= i; ) {
            var o = (i + r) / 2 | 0;
            if (e[o] < t) i = o + 1; else {
                if (!(e[o] > t)) return o;
                r = o - 1;
            }
        }
        return -1;
    }, pv.indicesOfNearest = function(t, e, n) {
        var i = [];
        if (!this._storage[t]) return i;
        null == n && (n = 1 / 0);
        for (var r = 1 / 0, o = -1, a = 0, s = 0, l = this.count(); l > s; s++) {
            var h = e - this.get(t, s), u = Math.abs(h);
            n >= u && ((r > u || u === r && h >= 0 && 0 > o) && (r = u, o = h, a = 0), h === o && (i[a++] = s));
        }
        return i.length = a, i;
    }, pv.getRawIndex = La, pv.getRawDataItem = function(t) {
        if (this._rawData.persistent) return this._rawData.getItem(this.getRawIndex(t));
        for (var e = [], n = 0; n < this.dimensions.length; n++) {
            var i = this.dimensions[n];
            e.push(this.get(i, t));
        }
        return e;
    }, pv.getName = function(t) {
        var e = this.getRawIndex(t);
        return this._nameList[e] || Pa(this, this._nameDimIdx, e) || "";
    }, pv.getId = function(t) {
        return Ea(this, this.getRawIndex(t));
    }, pv.each = function(t, e, n, i) {
        if (this._count) {
            "function" == typeof t && (i = n, n = e, e = t, t = []), n = n || i || this, t = p(Ba(t), this.getDimension, this), 
            wh && za(this, t);
            for (var r = t.length, o = 0; o < this.count(); o++) switch (r) {
              case 0:
                e.call(n, o);
                break;

              case 1:
                e.call(n, this.get(t[0], o), o);
                break;

              case 2:
                e.call(n, this.get(t[0], o), this.get(t[1], o), o);
                break;

              default:
                for (var a = 0, s = []; r > a; a++) s[a] = this.get(t[a], o);
                s[a] = o, e.apply(n, s);
            }
        }
    }, pv.filterSelf = function(t, e, n, i) {
        if (this._count) {
            "function" == typeof t && (i = n, n = e, e = t, t = []), n = n || i || this, t = p(Ba(t), this.getDimension, this), 
            wh && za(this, t);
            for (var r = this.count(), o = new (Ta(this))(r), a = [], s = t.length, l = 0, h = t[0], u = 0; r > u; u++) {
                var c, d = this.getRawIndex(u);
                if (0 === s) c = e.call(n, u); else if (1 === s) {
                    var f = this._getFast(h, d);
                    c = e.call(n, f, u);
                } else {
                    for (var g = 0; s > g; g++) a[g] = this._getFast(h, d);
                    a[g] = u, c = e.apply(n, a);
                }
                c && (o[l++] = d);
            }
            return r > l && (this._indices = o), this._count = l, this._extent = {}, this.getRawIndex = this._indices ? Oa : La, 
            this;
        }
    }, pv.selectRange = function(t) {
        if (this._count) {
            var e = [];
            for (var n in t) t.hasOwnProperty(n) && e.push(n);
            wh && za(this, e);
            var i = e.length;
            if (i) {
                var r = this.count(), o = new (Ta(this))(r), a = 0, s = e[0], l = t[s][0], h = t[s][1], u = !1;
                if (!this._indices) {
                    var c = 0;
                    if (1 === i) {
                        for (var d = this._storage[e[0]], f = 0; f < this._chunkCount; f++) for (var p = d[f], g = Math.min(this._count - f * this._chunkSize, this._chunkSize), v = 0; g > v; v++) {
                            ((w = p[v]) >= l && h >= w || isNaN(w)) && (o[a++] = c), c++;
                        }
                        u = !0;
                    } else if (2 === i) {
                        d = this._storage[s];
                        var m = this._storage[e[1]], y = t[e[1]][0], _ = t[e[1]][1];
                        for (f = 0; f < this._chunkCount; f++) {
                            p = d[f];
                            var x = m[f];
                            for (g = Math.min(this._count - f * this._chunkSize, this._chunkSize), v = 0; g > v; v++) {
                                var w = p[v], b = x[v];
                                (w >= l && h >= w || isNaN(w)) && (b >= y && _ >= b || isNaN(b)) && (o[a++] = c), 
                                c++;
                            }
                        }
                        u = !0;
                    }
                }
                if (!u) if (1 === i) for (v = 0; r > v; v++) {
                    var S = this.getRawIndex(v);
                    ((w = this._getFast(s, S)) >= l && h >= w || isNaN(w)) && (o[a++] = S);
                } else for (v = 0; r > v; v++) {
                    var M = !0;
                    for (S = this.getRawIndex(v), f = 0; i > f; f++) {
                        var I = e[f];
                        ((w = this._getFast(n, S)) < t[I][0] || w > t[I][1]) && (M = !1);
                    }
                    M && (o[a++] = this.getRawIndex(v));
                }
                return r > a && (this._indices = o), this._count = a, this._extent = {}, this.getRawIndex = this._indices ? Oa : La, 
                this;
            }
        }
    }, pv.mapArray = function(t, e, n, i) {
        "function" == typeof t && (i = n, n = e, e = t, t = []), n = n || i || this;
        var r = [];
        return this.each(t, function() {
            r.push(e && e.apply(this, arguments));
        }, n), r;
    }, pv.map = function(e, n, i, r) {
        i = i || r || this, e = p(Ba(e), this.getDimension, this), wh && za(this, e);
        var o = Na(this, e);
        o._indices = this._indices, o.getRawIndex = o._indices ? Oa : La;
        for (var a = o._storage, s = [], l = this._chunkSize, h = e.length, u = this.count(), c = [], d = o._rawExtent, f = 0; u > f; f++) {
            for (var g = 0; h > g; g++) c[g] = this.get(e[g], f);
            c[h] = f;
            var v = n && n.apply(i, c);
            if (null != v) {
                "object" != t(v) && (s[0] = v, v = s);
                for (var m = this.getRawIndex(f), y = Math.floor(m / l), _ = m % l, x = 0; x < v.length; x++) {
                    var w = e[x], b = v[x], S = d[w], M = a[w];
                    M && (M[y][_] = b), b < S[0] && (S[0] = b), b > S[1] && (S[1] = b);
                }
            }
        }
        return o;
    }, pv.downSample = function(t, e, n, i) {
        for (var r = Na(this, [ t ]), o = r._storage, a = [], s = Math.floor(1 / e), l = o[t], h = this.count(), u = this._chunkSize, c = r._rawExtent[t], d = new (Ta(this))(h), f = 0, p = 0; h > p; p += s) {
            s > h - p && (s = h - p, a.length = s);
            for (var g = 0; s > g; g++) {
                var v = this.getRawIndex(p + g), m = Math.floor(v / u), y = v % u;
                a[g] = l[m][y];
            }
            var _ = n(a), x = this.getRawIndex(Math.min(p + i(a, _) || 0, h - 1)), w = x % u;
            l[Math.floor(x / u)][w] = _, _ < c[0] && (c[0] = _), _ > c[1] && (c[1] = _), d[f++] = x;
        }
        return r._count = f, r._indices = d, r.getRawIndex = Oa, r;
    }, pv.getItemModel = function(t) {
        var e = this.hostModel;
        return new Ki(this.getRawDataItem(t), e, e && e.ecModel);
    }, pv.diff = function(t) {
        var e = this;
        return new ba(t ? t.getIndices() : [], this.getIndices(), function(e) {
            return Ea(t, e);
        }, function(t) {
            return Ea(e, t);
        });
    }, pv.getVisual = function(t) {
        var e = this._visual;
        return e && e[t];
    }, pv.setVisual = function(t, e) {
        if (iv(t)) for (var n in t) t.hasOwnProperty(n) && this.setVisual(n, t[n]); else this._visual = this._visual || {}, 
        this._visual[t] = e;
    }, pv.setLayout = function(t, e) {
        if (iv(t)) for (var n in t) t.hasOwnProperty(n) && this.setLayout(n, t[n]); else this._layout[t] = e;
    }, pv.getLayout = function(t) {
        return this._layout[t];
    }, pv.getItemLayout = function(t) {
        return this._itemLayouts[t];
    }, pv.setItemLayout = function(t, e, n) {
        this._itemLayouts[t] = n ? a(this._itemLayouts[t] || {}, e) : e;
    }, pv.clearItemLayouts = function() {
        this._itemLayouts.length = 0;
    }, pv.getItemVisual = function(t, e, n) {
        var i = this._itemVisuals[t], r = i && i[e];
        return null != r || n ? r : this.getVisual(e);
    }, pv.setItemVisual = function(t, e, n) {
        var i = this._itemVisuals[t] || {}, r = this.hasItemVisual;
        if (this._itemVisuals[t] = i, iv(e)) for (var o in e) e.hasOwnProperty(o) && (i[o] = e[o], 
        r[o] = !0); else i[e] = n, r[e] = !0;
    }, pv.clearAllVisual = function() {
        this._visual = {}, this._itemVisuals = [], this.hasItemVisual = {};
    };
    var gv = function(t) {
        t.seriesIndex = this.seriesIndex, t.dataIndex = this.dataIndex, t.dataType = this.dataType;
    };
    pv.setItemGraphicEl = function(t, e) {
        var n = this.hostModel;
        e && (e.dataIndex = t, e.dataType = this.dataType, e.seriesIndex = n && n.seriesIndex, 
        "group" === e.type && e.traverse(gv, e)), this._graphicEls[t] = e;
    }, pv.getItemGraphicEl = function(t) {
        return this._graphicEls[t];
    }, pv.eachItemGraphicEl = function(t, e) {
        f(this._graphicEls, function(n, i) {
            n && t && t.call(e, n, i);
        });
    }, pv.cloneShallow = function(t) {
        if (!t) {
            var e = p(this.dimensions, this.getDimensionInfo, this);
            t = new fv(e, this.hostModel);
        }
        if (t._storage = this._storage, Aa(t, this), this._indices) {
            var n = this._indices.constructor;
            t._indices = new n(this._indices);
        } else t._indices = null;
        return t.getRawIndex = t._indices ? Oa : La, t;
    }, pv.wrapMethod = function(t, e) {
        var n = this[t];
        "function" == typeof n && (this.__wrappedMethods = this.__wrappedMethods || [], 
        this.__wrappedMethods.push(t), this[t] = function() {
            var t = n.apply(this, arguments);
            return e.apply(this, [ t ].concat(k(arguments)));
        });
    }, pv.TRANSFERABLE_METHODS = [ "cloneShallow", "downSample", "map" ], pv.CHANGABLE_METHODS = [ "filterSelf", "selectRange" ];
    var vv = function(t, e) {
        return Fa((e = e || {}).coordDimensions || [], t, {
            dimsDef: e.dimensionsDefine || t.dimensionsDefine,
            encodeDef: e.encodeDefine || t.encodeDefine,
            dimCount: e.dimensionsCount,
            encodeDefaulter: e.encodeDefaulter,
            generateCoord: e.generateCoord,
            generateCoordCount: e.generateCoordCount
        });
    }, mv = {
        cartesian2d: function(t, e, n, i) {
            var r = t.getReferringComponents("xAxis")[0], o = t.getReferringComponents("yAxis")[0];
            if (wh) {
                if (!r) throw new Error('xAxis "' + C(t.get("xAxisIndex"), t.get("xAxisId"), 0) + '" not found');
                if (!o) throw new Error('yAxis "' + C(t.get("xAxisIndex"), t.get("yAxisId"), 0) + '" not found');
            }
            e.coordSysDims = [ "x", "y" ], n.set("x", r), n.set("y", o), Ga(r) && (i.set("x", r), 
            e.firstCategoryDimIndex = 0), Ga(o) && (i.set("y", o), e.firstCategoryDimIndex, 
            e.firstCategoryDimIndex = 1);
        },
        singleAxis: function(t, e, n, i) {
            var r = t.getReferringComponents("singleAxis")[0];
            if (wh && !r) throw new Error("singleAxis should be specified.");
            e.coordSysDims = [ "single" ], n.set("single", r), Ga(r) && (i.set("single", r), 
            e.firstCategoryDimIndex = 0);
        },
        polar: function(t, e, n, i) {
            var r = t.getReferringComponents("polar")[0], o = r.findAxisModel("radiusAxis"), a = r.findAxisModel("angleAxis");
            if (wh) {
                if (!a) throw new Error("angleAxis option not found");
                if (!o) throw new Error("radiusAxis option not found");
            }
            e.coordSysDims = [ "radius", "angle" ], n.set("radius", o), n.set("angle", a), Ga(o) && (i.set("radius", o), 
            e.firstCategoryDimIndex = 0), Ga(a) && (i.set("angle", a), null == e.firstCategoryDimIndex && (e.firstCategoryDimIndex = 1));
        },
        geo: function(t, e) {
            e.coordSysDims = [ "lng", "lat" ];
        },
        parallel: function(t, e, n, i) {
            var r = t.ecModel, o = r.getComponent("parallel", t.get("parallelIndex")), a = e.coordSysDims = o.dimensions.slice();
            f(o.parallelAxisIndex, function(t, o) {
                var s = r.getComponent("parallelAxis", t), l = a[o];
                n.set(l, s), Ga(s) && null == e.firstCategoryDimIndex && (i.set(l, s), e.firstCategoryDimIndex = o);
            });
        }
    };
    qa.prototype.parse = function(t) {
        return t;
    }, qa.prototype.getSetting = function(t) {
        return this._setting[t];
    }, qa.prototype.contain = function(t) {
        var e = this._extent;
        return t >= e[0] && t <= e[1];
    }, qa.prototype.normalize = function(t) {
        var e = this._extent;
        return e[1] === e[0] ? .5 : (t - e[0]) / (e[1] - e[0]);
    }, qa.prototype.scale = function(t) {
        var e = this._extent;
        return t * (e[1] - e[0]) + e[0];
    }, qa.prototype.unionExtent = function(t) {
        var e = this._extent;
        t[0] < e[0] && (e[0] = t[0]), t[1] > e[1] && (e[1] = t[1]);
    }, qa.prototype.unionExtentFromData = function(t, e) {
        this.unionExtent(t.getApproximateExtent(e));
    }, qa.prototype.getExtent = function() {
        return this._extent.slice();
    }, qa.prototype.setExtent = function(t, e) {
        var n = this._extent;
        isNaN(t) || (n[0] = t), isNaN(e) || (n[1] = e);
    }, qa.prototype.isBlank = function() {
        return this._isBlank;
    }, qa.prototype.setBlank = function(t) {
        this._isBlank = t;
    }, qa.prototype.getLabel = null, In(qa), Dn(qa, {
        registerWhenExtend: !0
    }), ja.createByAxisModel = function(t) {
        var e = t.option, n = e.data, i = n && p(n, Ka);
        return new ja({
            categories: i,
            needCollect: !i,
            deduplication: !1 !== e.dedplication
        });
    };
    var yv = ja.prototype;
    yv.getOrdinal = function(t) {
        return Za(this).get(t);
    }, yv.parseAndCollect = function(t) {
        var e, n = this._needCollect;
        if ("string" != typeof t && !n) return t;
        if (n && !this._deduplication) return e = this.categories.length, this.categories[e] = t, 
        e;
        var i = Za(this);
        return null == (e = i.get(t)) && (n ? (e = this.categories.length, this.categories[e] = t, 
        i.set(t, e)) : e = NaN), e;
    };
    var _v = qa.prototype, xv = qa.extend({
        type: "ordinal",
        init: function(t, e) {
            (!t || _(t)) && (t = new ja({
                categories: t
            })), this._ordinalMeta = t, this._extent = e || [ 0, t.categories.length - 1 ];
        },
        parse: function(t) {
            return "string" == typeof t ? this._ordinalMeta.getOrdinal(t) : Math.round(t);
        },
        contain: function(t) {
            return t = this.parse(t), _v.contain.call(this, t) && null != this._ordinalMeta.categories[t];
        },
        normalize: function(t) {
            return _v.normalize.call(this, this.parse(t));
        },
        scale: function(t) {
            return Math.round(_v.scale.call(this, t));
        },
        getTicks: function() {
            for (var t = [], e = this._extent, n = e[0]; n <= e[1]; ) t.push(n), n++;
            return t;
        },
        getLabel: function(t) {
            return this.isBlank() ? void 0 : this._ordinalMeta.categories[t];
        },
        count: function() {
            return this._extent[1] - this._extent[0] + 1;
        },
        unionExtentFromData: function(t, e) {
            this.unionExtent(t.getApproximateExtent(e));
        },
        getOrdinalMeta: function() {
            return this._ordinalMeta;
        },
        niceTicks: R,
        niceExtent: R
    });
    xv.create = function() {
        return new xv();
    };
    var wv = nr, bv = nr, Sv = qa.extend({
        type: "interval",
        _interval: 0,
        _intervalPrecision: 2,
        setExtent: function(t, e) {
            var n = this._extent;
            isNaN(t) || (n[0] = parseFloat(t)), isNaN(e) || (n[1] = parseFloat(e));
        },
        unionExtent: function(t) {
            var e = this._extent;
            t[0] < e[0] && (e[0] = t[0]), t[1] > e[1] && (e[1] = t[1]), Sv.prototype.setExtent.call(this, e[0], e[1]);
        },
        getInterval: function() {
            return this._interval;
        },
        setInterval: function(t) {
            this._interval = t, this._niceExtent = this._extent.slice(), this._intervalPrecision = $a(t);
        },
        getTicks: function(t) {
            var e = this._interval, n = this._extent, i = this._niceExtent, r = this._intervalPrecision, o = [];
            if (!e) return o;
            n[0] < i[0] && o.push(t ? bv(i[0] - e, r) : n[0]);
            for (var a = i[0]; a <= i[1] && (o.push(a), (a = bv(a + e, r)) !== o[o.length - 1]); ) if (o.length > 1e4) return [];
            var s = o.length ? o[o.length - 1] : i[1];
            return n[1] > s && o.push(t ? bv(s + e, r) : n[1]), o;
        },
        getMinorTicks: function(t) {
            for (var e = this.getTicks(!0), n = [], i = this.getExtent(), r = 1; r < e.length; r++) {
                for (var o = e[r], a = e[r - 1], s = 0, l = [], h = (o - a) / t; t - 1 > s; ) {
                    var u = nr(a + (s + 1) * h);
                    u > i[0] && u < i[1] && l.push(u), s++;
                }
                n.push(l);
            }
            return n;
        },
        getLabel: function(t, e) {
            if (null == t) return "";
            var n = e && e.precision;
            return null == n ? n = ir(t) || 0 : "auto" === n && (n = this._intervalPrecision), 
            dr(t = bv(t, n, !0));
        },
        niceTicks: function(t, e, n) {
            t = t || 5;
            var i = this._extent, r = i[1] - i[0];
            if (isFinite(r)) {
                0 > r && (r = -r, i.reverse());
                var o = function(t, e, n, i) {
                    var r = {}, o = t[1] - t[0], a = r.interval = cr(o / e, !0);
                    null != n && n > a && (a = r.interval = n), null != i && a > i && (a = r.interval = i);
                    var s = r.intervalPrecision = $a(a);
                    return Ja(r.niceTickExtent = [ wv(Math.ceil(t[0] / a) * a, s), wv(Math.floor(t[1] / a) * a, s) ], t), 
                    r;
                }(i, t, e, n);
                this._intervalPrecision = o.intervalPrecision, this._interval = o.interval, this._niceExtent = o.niceTickExtent;
            }
        },
        niceExtent: function(t) {
            var e = this._extent;
            if (e[0] === e[1]) if (0 !== e[0]) {
                var n = e[0];
                t.fixMax || (e[1] += n / 2), e[0] -= n / 2;
            } else e[1] = 1;
            var i = e[1] - e[0];
            isFinite(i) || (e[0] = 0, e[1] = 1), this.niceTicks(t.splitNumber, t.minInterval, t.maxInterval);
            var r = this._interval;
            t.fixMin || (e[0] = bv(Math.floor(e[0] / r) * r)), t.fixMax || (e[1] = bv(Math.ceil(e[1] / r) * r));
        }
    });
    Sv.create = function() {
        return new Sv();
    };
    var Mv = "__ec_stack_", Iv = "undefined" != typeof Float32Array ? Float32Array : Array, Tv = {
        seriesType: "bar",
        plan: Xp(),
        reset: function(t) {
            if (os(t) && as(t)) {
                var e = t.getData(), n = t.coordinateSystem, i = n.grid.getRect(), r = n.getBaseAxis(), o = n.getOtherAxis(r), a = e.mapDimension(o.dim), s = e.mapDimension(r.dim), l = o.isHorizontal(), h = l ? 0 : 1, u = rs(is([ t ]), r, t).width;
                return u > .5 || (u = .5), {
                    progress: function(t, e) {
                        for (var r, c = t.count, d = new Iv(2 * c), f = new Iv(2 * c), p = new Iv(c), g = [], v = [], m = 0, y = 0; null != (r = t.next()); ) v[h] = e.get(a, r), 
                        v[1 - h] = e.get(s, r), g = n.dataToPoint(v, null, g), f[m] = l ? i.x + i.width : g[0], 
                        d[m++] = g[0], f[m] = l ? g[1] : i.y + i.height, d[m++] = g[1], p[y++] = r;
                        e.setLayout({
                            largePoints: d,
                            largeDataIndices: p,
                            largeBackgroundPoints: f,
                            barWidth: u,
                            valueAxisStart: ss(0, o),
                            backgroundStart: l ? i.x : i.y,
                            valueAxisHorizontal: l
                        });
                    }
                };
            }
        }
    }, Cv = Sv.prototype, Av = Math.ceil, Dv = Math.floor, kv = 1e3, Pv = 6e4, Lv = 60 * Pv, Ov = 24 * Lv, Ev = Sv.extend({
        type: "time",
        getLabel: function(t) {
            var e = this._stepLvl, n = new Date(t);
            return yr(e[0], n, this.getSetting("useUTC"));
        },
        niceExtent: function(t) {
            var e = this._extent;
            if (e[0] === e[1] && (e[0] -= Ov, e[1] += Ov), e[1] === -1 / 0 && 1 / 0 === e[0]) {
                var n = new Date();
                e[1] = +new Date(n.getFullYear(), n.getMonth(), n.getDate()), e[0] = e[1] - Ov;
            }
            this.niceTicks(t.splitNumber, t.minInterval, t.maxInterval);
            var i = this._interval;
            t.fixMin || (e[0] = nr(Dv(e[0] / i) * i)), t.fixMax || (e[1] = nr(Av(e[1] / i) * i));
        },
        niceTicks: function(t, e, n) {
            t = t || 10;
            var i = this._extent, r = i[1] - i[0], o = r / t;
            null != e && e > o && (o = e), null != n && o > n && (o = n);
            var a = Bv.length, s = function(t, e, n, i) {
                for (;i > n; ) {
                    var r = n + i >>> 1;
                    t[r][1] < e ? n = r + 1 : i = r;
                }
                return n;
            }(Bv, o, 0, a), l = Bv[Math.min(s, a - 1)], h = l[1];
            "year" === l[0] && (h *= cr(r / h / t, !0));
            var u = this.getSetting("useUTC") ? 0 : 60 * new Date(+i[0] || +i[1]).getTimezoneOffset() * 1e3, c = [ Math.round(Av((i[0] - u) / h) * h + u), Math.round(Dv((i[1] - u) / h) * h + u) ];
            Ja(c, i), this._stepLvl = l, this._interval = h, this._niceExtent = c;
        },
        parse: function(t) {
            return +lr(t);
        }
    });
    f([ "contain", "normalize" ], function(t) {
        Ev.prototype[t] = function(e) {
            return Cv[t].call(this, this.parse(e));
        };
    });
    var Bv = [ [ "hh:mm:ss", kv ], [ "hh:mm:ss", 5e3 ], [ "hh:mm:ss", 1e4 ], [ "hh:mm:ss", 15e3 ], [ "hh:mm:ss", 3e4 ], [ "hh:mm\nMM-dd", Pv ], [ "hh:mm\nMM-dd", 5 * Pv ], [ "hh:mm\nMM-dd", 10 * Pv ], [ "hh:mm\nMM-dd", 15 * Pv ], [ "hh:mm\nMM-dd", 30 * Pv ], [ "hh:mm\nMM-dd", Lv ], [ "hh:mm\nMM-dd", 2 * Lv ], [ "hh:mm\nMM-dd", 6 * Lv ], [ "hh:mm\nMM-dd", 12 * Lv ], [ "MM-dd\nyyyy", Ov ], [ "MM-dd\nyyyy", 2 * Ov ], [ "MM-dd\nyyyy", 3 * Ov ], [ "MM-dd\nyyyy", 4 * Ov ], [ "MM-dd\nyyyy", 5 * Ov ], [ "MM-dd\nyyyy", 6 * Ov ], [ "week", 7 * Ov ], [ "MM-dd\nyyyy", 10 * Ov ], [ "week", 14 * Ov ], [ "week", 21 * Ov ], [ "month", 31 * Ov ], [ "week", 42 * Ov ], [ "month", 62 * Ov ], [ "week", 70 * Ov ], [ "quarter", 95 * Ov ], [ "month", 31 * Ov * 4 ], [ "month", 31 * Ov * 5 ], [ "half-year", 380 * Ov / 2 ], [ "month", 31 * Ov * 8 ], [ "month", 31 * Ov * 10 ], [ "year", 380 * Ov ] ];
    Ev.create = function(t) {
        return new Ev({
            useUTC: t.ecModel.get("useUTC")
        });
    };
    var zv = qa.prototype, Nv = Sv.prototype, Rv = ir, Fv = nr, Vv = Math.floor, Hv = Math.ceil, Gv = Math.pow, Wv = Math.log, Xv = qa.extend({
        type: "log",
        base: 10,
        $constructor: function() {
            qa.apply(this, arguments), this._originalScale = new Sv();
        },
        getTicks: function(t) {
            var e = this._originalScale, n = this._extent, i = e.getExtent();
            return p(Nv.getTicks.call(this, t), function(t) {
                var r = nr(Gv(this.base, t));
                return r = t === n[0] && e.__fixMin ? ls(r, i[0]) : r, t === n[1] && e.__fixMax ? ls(r, i[1]) : r;
            }, this);
        },
        getMinorTicks: Nv.getMinorTicks,
        getLabel: Nv.getLabel,
        scale: function(t) {
            return t = zv.scale.call(this, t), Gv(this.base, t);
        },
        setExtent: function(t, e) {
            var n = this.base;
            t = Wv(t) / Wv(n), e = Wv(e) / Wv(n), Nv.setExtent.call(this, t, e);
        },
        getExtent: function() {
            var t = this.base, e = zv.getExtent.call(this);
            e[0] = Gv(t, e[0]), e[1] = Gv(t, e[1]);
            var n = this._originalScale, i = n.getExtent();
            return n.__fixMin && (e[0] = ls(e[0], i[0])), n.__fixMax && (e[1] = ls(e[1], i[1])), 
            e;
        },
        unionExtent: function(t) {
            this._originalScale.unionExtent(t);
            var e = this.base;
            t[0] = Wv(t[0]) / Wv(e), t[1] = Wv(t[1]) / Wv(e), zv.unionExtent.call(this, t);
        },
        unionExtentFromData: function(t, e) {
            this.unionExtent(t.getApproximateExtent(e));
        },
        niceTicks: function(t) {
            t = t || 10;
            var e = this._extent, n = e[1] - e[0];
            if (!(1 / 0 === n || 0 >= n)) {
                var i = hr(n);
                for (.5 >= t / n * i && (i *= 10); !isNaN(i) && Math.abs(i) < 1 && Math.abs(i) > 0; ) i *= 10;
                var r = [ nr(Hv(e[0] / i) * i), nr(Vv(e[1] / i) * i) ];
                this._interval = i, this._niceExtent = r;
            }
        },
        niceExtent: function(t) {
            Nv.niceExtent.call(this, t);
            var e = this._originalScale;
            e.__fixMin = t.fixMin, e.__fixMax = t.fixMax;
        }
    });
    f([ "contain", "normalize" ], function(t) {
        Xv.prototype[t] = function(e) {
            return e = Wv(e) / Wv(this.base), zv[t].call(this, e);
        };
    }), Xv.create = function() {
        return new Xv();
    };
    var Uv = {
        getMin: function(t) {
            var e = this.option, n = t || null == e.rangeStart ? e.min : e.rangeStart;
            return this.axis && null != n && "dataMin" !== n && "function" != typeof n && !T(n) && (n = this.axis.scale.parse(n)), 
            n;
        },
        getMax: function(t) {
            var e = this.option, n = t || null == e.rangeEnd ? e.max : e.rangeEnd;
            return this.axis && null != n && "dataMax" !== n && "function" != typeof n && !T(n) && (n = this.axis.scale.parse(n)), 
            n;
        },
        getNeedCrossZero: function() {
            var t = this.option;
            return null == t.rangeStart && null == t.rangeEnd && !t.scale;
        },
        getCoordSysModel: R,
        setRange: function(t, e) {
            this.option.rangeStart = t, this.option.rangeEnd = e;
        },
        resetRange: function() {
            this.option.rangeStart = this.option.rangeEnd = null;
        }
    }, Yv = fi({
        type: "triangle",
        shape: {
            cx: 0,
            cy: 0,
            width: 0,
            height: 0
        },
        buildPath: function(t, e) {
            var n = e.cx, i = e.cy, r = e.width / 2, o = e.height / 2;
            t.moveTo(n, i - o), t.lineTo(n + r, i + o), t.lineTo(n - r, i + o), t.closePath();
        }
    }), qv = fi({
        type: "diamond",
        shape: {
            cx: 0,
            cy: 0,
            width: 0,
            height: 0
        },
        buildPath: function(t, e) {
            var n = e.cx, i = e.cy, r = e.width / 2, o = e.height / 2;
            t.moveTo(n, i - o), t.lineTo(n + r, i), t.lineTo(n, i + o), t.lineTo(n - r, i), 
            t.closePath();
        }
    }), jv = fi({
        type: "pin",
        shape: {
            x: 0,
            y: 0,
            width: 0,
            height: 0
        },
        buildPath: function(t, e) {
            var n = e.x, i = e.y, r = e.width / 5 * 3, o = Math.max(r, e.height), a = r / 2, s = a * a / (o - a), l = i - o + a + s, h = Math.asin(s / a), u = Math.cos(h) * a, c = Math.sin(h), d = Math.cos(h), f = .6 * a, p = .7 * a;
            t.moveTo(n - u, l + s), t.arc(n, l, a, Math.PI - h, 2 * Math.PI + h), t.bezierCurveTo(n + u - c * f, l + s + d * f, n, i - p, n, i), 
            t.bezierCurveTo(n, i - p, n - u + c * f, l + s + d * f, n - u, l + s), t.closePath();
        }
    }), Zv = fi({
        type: "arrow",
        shape: {
            x: 0,
            y: 0,
            width: 0,
            height: 0
        },
        buildPath: function(t, e) {
            var n = e.height, i = e.width, r = e.x, o = e.y, a = i / 3 * 2;
            t.moveTo(r, o), t.lineTo(r + a, o + n), t.lineTo(r, o + n / 4 * 3), t.lineTo(r - a, o + n), 
            t.lineTo(r, o), t.closePath();
        }
    }), Kv = {
        line: function(t, e, n, i, r) {
            r.x1 = t, r.y1 = e + i / 2, r.x2 = t + n, r.y2 = e + i / 2;
        },
        rect: function(t, e, n, i, r) {
            r.x = t, r.y = e, r.width = n, r.height = i;
        },
        roundRect: function(t, e, n, i, r) {
            r.x = t, r.y = e, r.width = n, r.height = i, r.r = Math.min(n, i) / 4;
        },
        square: function(t, e, n, i, r) {
            var o = Math.min(n, i);
            r.x = t, r.y = e, r.width = o, r.height = o;
        },
        circle: function(t, e, n, i, r) {
            r.cx = t + n / 2, r.cy = e + i / 2, r.r = Math.min(n, i) / 2;
        },
        diamond: function(t, e, n, i, r) {
            r.cx = t + n / 2, r.cy = e + i / 2, r.width = n, r.height = i;
        },
        pin: function(t, e, n, i, r) {
            r.x = t + n / 2, r.y = e + i / 2, r.width = n, r.height = i;
        },
        arrow: function(t, e, n, i, r) {
            r.x = t + n / 2, r.y = e + i / 2, r.width = n, r.height = i;
        },
        triangle: function(t, e, n, i, r) {
            r.cx = t + n / 2, r.cy = e + i / 2, r.width = n, r.height = i;
        }
    }, $v = {};
    f({
        line: hf,
        rect: sf,
        roundRect: sf,
        square: sf,
        circle: Zd,
        diamond: qv,
        pin: jv,
        arrow: Zv,
        triangle: Yv
    }, function(t, e) {
        $v[e] = new t();
    });
    var Qv = fi({
        type: "symbol",
        shape: {
            symbolType: "",
            x: 0,
            y: 0,
            width: 0,
            height: 0
        },
        calculateTextPosition: function(t, e, n) {
            var i = Se(t, e, n), r = this.shape;
            return r && "pin" === r.symbolType && "inside" === e.textPosition && (i.y = n.y + .4 * n.height), 
            i;
        },
        buildPath: function(t, e, n) {
            var i = e.symbolType;
            if ("none" !== i) {
                var r = $v[i];
                r || (r = $v[i = "rect"]), Kv[i](e.x, e.y, e.width, e.height, r.shape), r.buildPath(t, r.shape, n);
            }
        }
    }), Jv = {
        isDimensionStacked: Xa,
        enableDataStack: Wa,
        getStackedDimension: Ua
    }, tm = (Object.freeze || Object)({
        createList: function(t) {
            return Ya(t.getSource(), t);
        },
        getLayoutRect: wr,
        dataStack: Jv,
        createScale: function(t, e) {
            var n = e;
            Ki.isInstance(e) || c(n = new Ki(e), Uv);
            var i = cs(n);
            return i.setExtent(t[0], t[1]), us(i, n), i;
        },
        mixinAxisModelCommonMethods: function(t) {
            c(t, Uv);
        },
        completeDimensions: Fa,
        createDimensions: vv,
        createSymbol: ys
    }), em = 1e-8;
    ws.prototype = {
        constructor: ws,
        properties: null,
        getBoundingRect: function() {
            var t = this._rect;
            if (t) return t;
            for (var e = Number.MAX_VALUE, n = [ e, e ], i = [ -e, -e ], r = [], o = [], a = this.geometries, s = 0; s < a.length; s++) if ("polygon" === a[s].type) {
                Vn(a[s].exterior, r, o), Q(n, n, r), J(i, i, o);
            }
            return 0 === s && (n[0] = n[1] = i[0] = i[1] = 0), this._rect = new ie(n[0], n[1], i[0] - n[0], i[1] - n[1]);
        },
        contain: function(t) {
            var e = this.getBoundingRect(), n = this.geometries;
            if (!e.contain(t[0], t[1])) return !1;
            t: for (var i = 0, r = n.length; r > i; i++) if ("polygon" === n[i].type) {
                var o = n[i].exterior, a = n[i].interiors;
                if (xs(o, t[0], t[1])) {
                    for (var s = 0; s < (a ? a.length : 0); s++) if (xs(a[s])) continue t;
                    return !0;
                }
            }
            return !1;
        },
        transformTo: function(t, e, n, i) {
            var r = this.getBoundingRect(), o = r.width / r.height;
            n ? i || (i = n / o) : n = o * i;
            for (var a = new ie(t, e, n, i), s = r.calculateTransform(a), l = this.geometries, h = 0; h < l.length; h++) if ("polygon" === l[h].type) {
                for (var u = l[h].exterior, c = l[h].interiors, d = 0; d < u.length; d++) $(u[d], u[d], s);
                for (var f = 0; f < (c ? c.length : 0); f++) for (d = 0; d < c[f].length; d++) $(c[f][d], c[f][d], s);
            }
            (r = this._rect).copy(a), this.center = [ r.x + r.width / 2, r.y + r.height / 2 ];
        },
        cloneShallow: function(t) {
            null == t && (t = this.name);
            var e = new ws(t, this.geometries, this.center);
            return e._rect = this._rect, e.transformTo = null, e;
        }
    };
    var nm = function(t, e) {
        return function(t) {
            if (!t.UTF8Encoding) return t;
            var e = t.UTF8Scale;
            null == e && (e = 1024);
            for (var n = t.features, i = 0; i < n.length; i++) for (var r = n[i].geometry, o = r.coordinates, a = r.encodeOffsets, s = 0; s < o.length; s++) {
                var l = o[s];
                if ("Polygon" === r.type) o[s] = bs(l, a[s], e); else if ("MultiPolygon" === r.type) for (var h = 0; h < l.length; h++) {
                    var u = l[h];
                    l[h] = bs(u, a[s][h], e);
                }
            }
            t.UTF8Encoding = !1;
        }(t), p(v(t.features, function(t) {
            return t.geometry && t.properties && t.geometry.coordinates.length > 0;
        }), function(t) {
            var n = t.properties, i = t.geometry, r = i.coordinates, o = [];
            "Polygon" === i.type && o.push({
                type: "polygon",
                exterior: r[0],
                interiors: r.slice(1)
            }), "MultiPolygon" === i.type && f(r, function(t) {
                t[0] && o.push({
                    type: "polygon",
                    exterior: t[0],
                    interiors: t.slice(1)
                });
            });
            var a = new ws(n[e || "name"], o, n.cp);
            return a.properties = n, a;
        });
    }, im = _n(), rm = [ 0, 1 ], om = function(t, e, n) {
        this.dim = t, this.scale = e, this._extent = n || [ 0, 0 ], this.inverse = !1, this.onBand = !1;
    };
    om.prototype = {
        constructor: om,
        contain: function(t) {
            var e = this._extent, n = Math.min(e[0], e[1]), i = Math.max(e[0], e[1]);
            return t >= n && i >= t;
        },
        containData: function(t) {
            return this.scale.contain(t);
        },
        getExtent: function() {
            return this._extent.slice();
        },
        getPixelPrecision: function(t) {
            return rr(t || this.scale.getExtent(), this._extent);
        },
        setExtent: function(t, e) {
            var n = this._extent;
            n[0] = t, n[1] = e;
        },
        dataToCoord: function(t, e) {
            var n = this._extent, i = this.scale;
            return t = i.normalize(t), this.onBand && "ordinal" === i.type && Ps(n = n.slice(), i.count()), 
            tr(t, rm, n, e);
        },
        coordToData: function(t, e) {
            var n = this._extent, i = this.scale;
            this.onBand && "ordinal" === i.type && Ps(n = n.slice(), i.count());
            var r = tr(t, n, rm, e);
            return this.scale.scale(r);
        },
        pointToData: function() {},
        getTicksCoords: function(t) {
            var e = (t = t || {}).tickModel || this.getTickModel(), n = p(Ms(this, e).ticks, function(t) {
                return {
                    coord: this.dataToCoord(t),
                    tickValue: t
                };
            }, this);
            return function(t, e, n, i) {
                function r(t, e) {
                    return t = nr(t), e = nr(e), c ? t > e : e > t;
                }
                var o = e.length;
                if (t.onBand && !n && o) {
                    var a, s, l = t.getExtent();
                    if (1 === o) e[0].coord = l[0], a = e[1] = {
                        coord: l[0]
                    }; else {
                        var h = e[o - 1].tickValue - e[0].tickValue, u = (e[o - 1].coord - e[0].coord) / h;
                        f(e, function(t) {
                            t.coord -= u / 2;
                        }), s = 1 + t.scale.getExtent()[1] - e[o - 1].tickValue, a = {
                            coord: e[o - 1].coord + u * s
                        }, e.push(a);
                    }
                    var c = l[0] > l[1];
                    r(e[0].coord, l[0]) && (i ? e[0].coord = l[0] : e.shift()), i && r(l[0], e[0].coord) && e.unshift({
                        coord: l[0]
                    }), r(l[1], a.coord) && (i ? a.coord = l[1] : e.pop()), i && r(a.coord, l[1]) && e.push({
                        coord: l[1]
                    });
                }
            }(this, n, e.get("alignWithLabel"), t.clamp), n;
        },
        getMinorTicksCoords: function() {
            if ("ordinal" === this.scale.type) return [];
            var t = this.model.getModel("minorTick").get("splitNumber");
            return t > 0 && 100 > t || (t = 5), p(this.scale.getMinorTicks(t), function(t) {
                return p(t, function(t) {
                    return {
                        coord: this.dataToCoord(t),
                        tickValue: t
                    };
                }, this);
            }, this);
        },
        getViewLabels: function() {
            return Ss(this).labels;
        },
        getLabelModel: function() {
            return this.model.getModel("axisLabel");
        },
        getTickModel: function() {
            return this.model.getModel("axisTick");
        },
        getBandWidth: function() {
            var t = this._extent, e = this.scale.getExtent(), n = e[1] - e[0] + (this.onBand ? 1 : 0);
            0 === n && (n = 1);
            var i = Math.abs(t[1] - t[0]);
            return Math.abs(i) / n;
        },
        isHorizontal: null,
        getRotate: null,
        calculateCategoryInterval: function() {
            return function(t) {
                var e = function(t) {
                    var e = t.getLabelModel();
                    return {
                        axisRotate: t.getRotate ? t.getRotate() : t.isHorizontal && !t.isHorizontal() ? 90 : 0,
                        labelRotate: e.get("rotate") || 0,
                        font: e.getFont()
                    };
                }(t), n = ds(t), i = (e.axisRotate - e.labelRotate) / 180 * Math.PI, r = t.scale, o = r.getExtent(), a = r.count();
                if (o[1] - o[0] < 1) return 0;
                var s = 1;
                a > 40 && (s = Math.max(1, Math.floor(a / 40)));
                for (var l = o[0], h = t.dataToCoord(l + 1) - t.dataToCoord(l), u = Math.abs(h * Math.cos(i)), c = Math.abs(h * Math.sin(i)), d = 0, f = 0; l <= o[1]; l += s) {
                    var p, g, v = xe(n(l), e.font, "center", "top");
                    p = 1.3 * v.width, g = 1.3 * v.height, d = Math.max(d, p, 7), f = Math.max(f, g, 7);
                }
                var m = d / u, y = f / c;
                isNaN(m) && (m = 1 / 0), isNaN(y) && (y = 1 / 0);
                var _ = Math.max(0, Math.floor(Math.min(m, y))), x = im(t.model), w = t.getExtent(), b = x.lastAutoInterval, S = x.lastTickCount;
                return null != b && null != S && Math.abs(b - _) <= 1 && Math.abs(S - a) <= 1 && b > _ && x.axisExtend0 === w[0] && x.axisExtend1 === w[1] ? _ = b : (x.lastTickCount = a, 
                x.lastAutoInterval = _, x.axisExtend0 = w[0], x.axisExtend1 = w[1]), _;
            }(this);
        }
    };
    var am = nm, sm = {};
    f([ "map", "each", "filter", "indexOf", "inherits", "reduce", "filter", "bind", "curry", "isArray", "isString", "isObject", "isFunction", "extend", "defaults", "clone", "merge" ], function(t) {
        sm[t] = Rh[t];
    });
    var lm = {};
    f([ "extendShape", "extendPath", "makePath", "makeImage", "mergePath", "resizePath", "createIcon", "setHoverStyle", "setLabelStyle", "setTextStyle", "setText", "getFont", "updateProps", "initProps", "getTransform", "clipPointsByRect", "clipRectByRect", "registerShape", "getShapeClass", "Group", "Image", "Text", "Circle", "Sector", "Ring", "Polygon", "Polyline", "Rect", "Line", "BezierCurve", "Arc", "IncrementalDisplayable", "CompoundPath", "LinearGradient", "RadialGradient", "BoundingRect" ], function(t) {
        lm[t] = Pf[t];
    });
    var hm = function(t) {
        this._axes = {}, this._dimList = [], this.name = t || "";
    };
    hm.prototype = {
        constructor: hm,
        type: "cartesian",
        getAxis: function(t) {
            return this._axes[t];
        },
        getAxes: function() {
            return p(this._dimList, Ls, this);
        },
        getAxesByScale: function(t) {
            return t = t.toLowerCase(), v(this.getAxes(), function(e) {
                return e.scale.type === t;
            });
        },
        addAxis: function(t) {
            var e = t.dim;
            this._axes[e] = t, this._dimList.push(e);
        },
        dataToCoord: function(t) {
            return this._dataCoordConvert(t, "dataToCoord");
        },
        coordToData: function(t) {
            return this._dataCoordConvert(t, "coordToData");
        },
        _dataCoordConvert: function(t, e) {
            for (var n = this._dimList, i = t instanceof Array ? [] : {}, r = 0; r < n.length; r++) {
                var o = n[r], a = this._axes[o];
                i[o] = a[e](t[o]);
            }
            return i;
        }
    }, Os.prototype = {
        constructor: Os,
        type: "cartesian2d",
        dimensions: [ "x", "y" ],
        getBaseAxis: function() {
            return this.getAxesByScale("ordinal")[0] || this.getAxesByScale("time")[0] || this.getAxis("x");
        },
        containPoint: function(t) {
            var e = this.getAxis("x"), n = this.getAxis("y");
            return e.contain(e.toLocalCoord(t[0])) && n.contain(n.toLocalCoord(t[1]));
        },
        containData: function(t) {
            return this.getAxis("x").containData(t[0]) && this.getAxis("y").containData(t[1]);
        },
        dataToPoint: function(t, e, n) {
            var i = this.getAxis("x"), r = this.getAxis("y");
            return (n = n || [])[0] = i.toGlobalCoord(i.dataToCoord(t[0])), n[1] = r.toGlobalCoord(r.dataToCoord(t[1])), 
            n;
        },
        clampData: function(t, e) {
            var n = this.getAxis("x").scale, i = this.getAxis("y").scale, r = n.getExtent(), o = i.getExtent(), a = n.parse(t[0]), s = i.parse(t[1]);
            return (e = e || [])[0] = Math.min(Math.max(Math.min(r[0], r[1]), a), Math.max(r[0], r[1])), 
            e[1] = Math.min(Math.max(Math.min(o[0], o[1]), s), Math.max(o[0], o[1])), e;
        },
        pointToData: function(t, e) {
            var n = this.getAxis("x"), i = this.getAxis("y");
            return (e = e || [])[0] = n.coordToData(n.toLocalCoord(t[0])), e[1] = i.coordToData(i.toLocalCoord(t[1])), 
            e;
        },
        getOtherAxis: function(t) {
            return this.getAxis("x" === t.dim ? "y" : "x");
        },
        getArea: function() {
            var t = this.getAxis("x").getGlobalExtent(), e = this.getAxis("y").getGlobalExtent(), n = Math.min(t[0], t[1]), i = Math.min(e[0], e[1]);
            return new ie(n, i, Math.max(t[0], t[1]) - n, Math.max(e[0], e[1]) - i);
        }
    }, u(Os, hm);
    var um = function(t, e, n, i, r) {
        om.call(this, t, e, n), this.type = i || "value", this.position = r || "bottom";
    };
    um.prototype = {
        constructor: um,
        index: 0,
        getAxesOnZeroOf: null,
        model: null,
        isHorizontal: function() {
            var t = this.position;
            return "top" === t || "bottom" === t;
        },
        getGlobalExtent: function(t) {
            var e = this.getExtent();
            return e[0] = this.toGlobalCoord(e[0]), e[1] = this.toGlobalCoord(e[1]), t && e[0] > e[1] && e.reverse(), 
            e;
        },
        getOtherAxis: function() {
            this.grid.getOtherAxis();
        },
        pointToData: function(t, e) {
            return this.coordToData(this.toLocalCoord(t["x" === this.dim ? 0 : 1]), e);
        },
        toLocalCoord: null,
        toGlobalCoord: null
    }, u(um, om);
    var cm = {
        show: !0,
        zlevel: 0,
        z: 0,
        inverse: !1,
        name: "",
        nameLocation: "end",
        nameRotate: null,
        nameTruncate: {
            maxWidth: null,
            ellipsis: "...",
            placeholder: "."
        },
        nameTextStyle: {},
        nameGap: 15,
        silent: !1,
        triggerEvent: !1,
        tooltip: {
            show: !1
        },
        axisPointer: {},
        axisLine: {
            show: !0,
            onZero: !0,
            onZeroAxisIndex: null,
            lineStyle: {
                color: "#333",
                width: 1,
                type: "solid"
            },
            symbol: [ "none", "none" ],
            symbolSize: [ 10, 15 ]
        },
        axisTick: {
            show: !0,
            inside: !1,
            length: 5,
            lineStyle: {
                width: 1
            }
        },
        axisLabel: {
            show: !0,
            inside: !1,
            rotate: 0,
            showMinLabel: null,
            showMaxLabel: null,
            margin: 8,
            fontSize: 12
        },
        splitLine: {
            show: !0,
            lineStyle: {
                color: [ "#ccc" ],
                width: 1,
                type: "solid"
            }
        },
        splitArea: {
            show: !1,
            areaStyle: {
                color: [ "rgba(250,250,250,0.3)", "rgba(200,200,200,0.3)" ]
            }
        }
    }, dm = {};
    dm.categoryAxis = r({
        boundaryGap: !0,
        deduplication: null,
        splitLine: {
            show: !1
        },
        axisTick: {
            alignWithLabel: !1,
            interval: "auto"
        },
        axisLabel: {
            interval: "auto"
        }
    }, cm), dm.valueAxis = r({
        boundaryGap: [ 0, 0 ],
        splitNumber: 5,
        minorTick: {
            show: !1,
            splitNumber: 5,
            length: 3,
            lineStyle: {}
        },
        minorSplitLine: {
            show: !1,
            lineStyle: {
                color: "#eee",
                width: 1
            }
        }
    }, cm), dm.timeAxis = s({
        scale: !0,
        min: "dataMin",
        max: "dataMax"
    }, dm.valueAxis), dm.logAxis = s({
        scale: !0,
        logBase: 10
    }, dm.valueAxis);
    var fm = [ "value", "category", "time", "log" ], pm = function(t, e, n, i) {
        f(fm, function(a) {
            e.extend({
                type: t + "Axis." + a,
                mergeDefaultAndTheme: function(e, i) {
                    var o = this.layoutMode, s = o ? Sr(e) : {};
                    r(e, i.getTheme().get(a + "Axis")), r(e, this.getDefaultOption()), e.type = n(t, e), 
                    o && br(e, s, o);
                },
                optionUpdated: function() {
                    "category" === this.option.type && (this.__ordinalMeta = ja.createByAxisModel(this));
                },
                getCategories: function(t) {
                    var e = this.option;
                    return "category" === e.type ? t ? e.data : this.__ordinalMeta.categories : void 0;
                },
                getOrdinalMeta: function() {
                    return this.__ordinalMeta;
                },
                defaultOption: o([ {}, dm[a + "Axis"], i ], !0)
            });
        }), ep.registerSubTypeDefaulter(t + "Axis", y(n, t));
    }, gm = ep.extend({
        type: "cartesian2dAxis",
        axis: null,
        init: function() {
            gm.superApply(this, "init", arguments), this.resetRange();
        },
        mergeOption: function() {
            gm.superApply(this, "mergeOption", arguments), this.resetRange();
        },
        restoreData: function() {
            gm.superApply(this, "restoreData", arguments), this.resetRange();
        },
        getCoordSysModel: function() {
            return this.ecModel.queryComponents({
                mainType: "grid",
                index: this.option.gridIndex,
                id: this.option.gridId
            })[0];
        }
    });
    r(gm.prototype, Uv);
    var vm = {
        offset: 0
    };
    pm("x", gm, Es, vm), pm("y", gm, Es, vm), ep.extend({
        type: "grid",
        dependencies: [ "xAxis", "yAxis" ],
        layoutMode: "box",
        coordinateSystem: null,
        defaultOption: {
            show: !1,
            zlevel: 0,
            z: 0,
            left: "10%",
            top: 60,
            right: "10%",
            bottom: 60,
            containLabel: !1,
            backgroundColor: "rgba(0,0,0,0)",
            borderWidth: 1,
            borderColor: "#ccc"
        }
    });
    var mm = zs.prototype;
    mm.type = "grid", mm.axisPointerEnabled = !0, mm.getRect = function() {
        return this._rect;
    }, mm.update = function(t, e) {
        var n = this._axesMap;
        this._updateScale(t, this.model), f(n.x, function(t) {
            us(t.scale, t.model);
        }), f(n.y, function(t) {
            us(t.scale, t.model);
        });
        var i = {};
        f(n.x, function(t) {
            Ns(n, "y", t, i);
        }), f(n.y, function(t) {
            Ns(n, "x", t, i);
        }), this.resize(this.model, e);
    }, mm.resize = function(t, e, n) {
        function i() {
            f(o, function(t) {
                var e = t.isHorizontal(), n = e ? [ 0, r.width ] : [ 0, r.height ], i = t.inverse ? 1 : 0;
                t.setExtent(n[i], n[1 - i]), function(t, e) {
                    var n = t.getExtent(), i = n[0] + n[1];
                    t.toGlobalCoord = "x" === t.dim ? function(t) {
                        return t + e;
                    } : function(t) {
                        return i - t + e;
                    }, t.toLocalCoord = "x" === t.dim ? function(t) {
                        return t - e;
                    } : function(t) {
                        return i - t + e;
                    };
                }(t, e ? r.x : r.y);
            });
        }
        var r = wr(t.getBoxLayoutParams(), {
            width: e.getWidth(),
            height: e.getHeight()
        });
        this._rect = r;
        var o = this._axesList;
        i(), !n && t.get("containLabel") && (f(o, function(t) {
            if (!t.model.get("axisLabel.inside")) {
                var e = function(t) {
                    var e = t.model, n = t.scale;
                    if (e.get("axisLabel.show") && !n.isBlank()) {
                        var i, r, o = "category" === t.type, a = n.getExtent();
                        o ? r = n.count() : r = (i = n.getTicks()).length;
                        var s, l = t.getLabelModel(), h = ds(t), u = 1;
                        r > 40 && (u = Math.ceil(r / 40));
                        for (var c = 0; r > c; c += u) {
                            var d = h(i ? i[c] : a[0] + c), f = ps(l.getTextRect(d), l.get("rotate") || 0);
                            s ? s.union(f) : s = f;
                        }
                        return s;
                    }
                }(t);
                if (e) {
                    var n = t.isHorizontal() ? "height" : "width", i = t.model.get("axisLabel.margin");
                    r[n] -= e[n] + i, "top" === t.position ? r.y += e.height + i : "left" === t.position && (r.x += e.width + i);
                }
            }
        }), i());
    }, mm.getAxis = function(t, e) {
        var n = this._axesMap[t];
        if (null != n) {
            if (null == e) for (var i in n) if (n.hasOwnProperty(i)) return n[i];
            return n[e];
        }
    }, mm.getAxes = function() {
        return this._axesList.slice();
    }, mm.getCartesian = function(t, e) {
        if (null != t && null != e) {
            var n = "x" + t + "y" + e;
            return this._coordsMap[n];
        }
        b(t) && (e = t.yAxisIndex, t = t.xAxisIndex);
        for (var i = 0, r = this._coordsList; i < r.length; i++) if (r[i].getAxis("x").index === t || r[i].getAxis("y").index === e) return r[i];
    }, mm.getCartesians = function() {
        return this._coordsList.slice();
    }, mm.convertToPixel = function(t, e, n) {
        var i = this._findConvertTarget(t, e);
        return i.cartesian ? i.cartesian.dataToPoint(n) : i.axis ? i.axis.toGlobalCoord(i.axis.dataToCoord(n)) : null;
    }, mm.convertFromPixel = function(t, e, n) {
        var i = this._findConvertTarget(t, e);
        return i.cartesian ? i.cartesian.pointToData(n) : i.axis ? i.axis.coordToData(i.axis.toLocalCoord(n)) : null;
    }, mm._findConvertTarget = function(t, e) {
        var n, i, r = e.seriesModel, o = e.xAxisModel || r && r.getReferringComponents("xAxis")[0], a = e.yAxisModel || r && r.getReferringComponents("yAxis")[0], s = e.gridModel, l = this._coordsList;
        if (r) h(l, n = r.coordinateSystem) < 0 && (n = null); else if (o && a) n = this.getCartesian(o.componentIndex, a.componentIndex); else if (o) i = this.getAxis("x", o.componentIndex); else if (a) i = this.getAxis("y", a.componentIndex); else if (s) {
            s.coordinateSystem === this && (n = this._coordsList[0]);
        }
        return {
            cartesian: n,
            axis: i
        };
    }, mm.containPoint = function(t) {
        var e = this._coordsList[0];
        return e ? e.containPoint(t) : void 0;
    }, mm._initCartesian = function(t, e) {
        function n(e) {
            return function(n, a) {
                if (Bs(n, t)) {
                    var s = n.get("position");
                    "x" === e ? "top" !== s && "bottom" !== s && (s = i.bottom ? "top" : "bottom") : "left" !== s && "right" !== s && (s = i.left ? "right" : "left"), 
                    i[s] = !0;
                    var l = new um(e, cs(n), [ 0, 0 ], n.get("type"), s), h = "category" === l.type;
                    l.onBand = h && n.get("boundaryGap"), l.inverse = n.get("inverse"), n.axis = l, 
                    l.model = n, l.grid = this, l.index = a, this._axesList.push(l), r[e][a] = l, o[e]++;
                }
            };
        }
        var i = {
            left: !1,
            right: !1,
            top: !1,
            bottom: !1
        }, r = {
            x: {},
            y: {}
        }, o = {
            x: 0,
            y: 0
        };
        return e.eachComponent("xAxis", n("x"), this), e.eachComponent("yAxis", n("y"), this), 
        o.x && o.y ? (this._axesMap = r, void f(r.x, function(e, n) {
            f(r.y, function(i, r) {
                var o = "x" + n + "y" + r, a = new Os(o);
                a.grid = this, a.model = t, this._coordsMap[o] = a, this._coordsList.push(a), a.addAxis(e), 
                a.addAxis(i);
            }, this);
        }, this)) : (this._axesMap = {}, void (this._axesList = []));
    }, mm._updateScale = function(t, e) {
        function n(t, e) {
            f(t.mapDimension(e.dim, !0), function(n) {
                e.scale.unionExtentFromData(t, Ua(t, n));
            });
        }
        f(this._axesList, function(t) {
            t.scale.setExtent(1 / 0, -1 / 0);
        }), t.eachSeries(function(t) {
            if (Vs(t)) {
                var i = Fs(t), r = i[0], o = i[1];
                if (!Bs(r, e) || !Bs(o, e)) return;
                var a = this.getCartesian(r.componentIndex, o.componentIndex), s = t.getData(), l = a.getAxis("x"), h = a.getAxis("y");
                "list" === s.type && (n(s, l), n(s, h));
            }
        }, this);
    }, mm.getTooltipAxes = function(t) {
        var e = [], n = [];
        return f(this.getCartesians(), function(i) {
            var r = null != t && "auto" !== t ? i.getAxis(t) : i.getBaseAxis(), o = i.getOtherAxis(r);
            h(e, r) < 0 && e.push(r), h(n, o) < 0 && n.push(o);
        }), {
            baseAxes: e,
            otherAxes: n
        };
    };
    var ym = [ "xAxis", "yAxis" ];
    zs.create = function(t, e) {
        var n = [];
        return t.eachComponent("grid", function(i, r) {
            var o = new zs(i, t, e);
            o.name = "grid_" + r, o.resize(i, e, !0), i.coordinateSystem = o, n.push(o);
        }), t.eachSeries(function(t) {
            if (Vs(t)) {
                var e = Fs(t), n = e[0], i = e[1], r = n.getCoordSysModel();
                if (wh) {
                    if (!r) throw new Error('Grid "' + C(n.get("gridIndex"), n.get("gridId"), 0) + '" not found');
                    if (n.getCoordSysModel() !== i.getCoordSysModel()) throw new Error("xAxis and yAxis must use the same grid");
                }
                var o = r.coordinateSystem;
                t.coordinateSystem = o.getCartesian(n.componentIndex, i.componentIndex);
            }
        }), n;
    }, zs.dimensions = zs.prototype.dimensions = Os.prototype.dimensions, Rr.register("cartesian2d", zs), 
    Hp.extend({
        type: "series.__base_bar__",
        getInitialData: function() {
            return Ya(this.getSource(), this, {
                useEncodeDefaulter: !0
            });
        },
        getMarkerPosition: function(t) {
            var e = this.coordinateSystem;
            if (e) {
                var n = e.dataToPoint(e.clampData(t)), i = this.getData(), r = i.getLayout("offset"), o = i.getLayout("size");
                return n[e.getBaseAxis().isHorizontal() ? 0 : 1] += r + o / 2, n;
            }
            return [ NaN, NaN ];
        },
        defaultOption: {
            zlevel: 0,
            z: 2,
            coordinateSystem: "cartesian2d",
            legendHoverLink: !0,
            barMinHeight: 0,
            barMinAngle: 0,
            large: !1,
            largeThreshold: 400,
            progressive: 3e3,
            progressiveChunkMode: "mod",
            itemStyle: {},
            emphasis: {}
        }
    }).extend({
        type: "series.bar",
        dependencies: [ "grid", "polar" ],
        brushSelector: "rect",
        getProgressive: function() {
            return !!this.get("large") && this.get("progressive");
        },
        getProgressiveThreshold: function() {
            var t = this.get("progressiveThreshold"), e = this.get("largeThreshold");
            return e > t && (t = e), t;
        },
        defaultOption: {
            clip: !0,
            roundCap: !1,
            showBackground: !1,
            backgroundStyle: {
                color: "rgba(180, 180, 180, 0.2)",
                borderColor: null,
                borderWidth: 0,
                borderType: "solid",
                borderRadius: 0,
                shadowBlur: 0,
                shadowColor: null,
                shadowOffsetX: 0,
                shadowOffsetY: 0,
                opacity: 1
            }
        }
    });
    var _m = Hc([ [ "fill", "color" ], [ "stroke", "borderColor" ], [ "lineWidth", "borderWidth" ], [ "stroke", "barBorderColor" ], [ "lineWidth", "barBorderWidth" ], [ "opacity" ], [ "shadowBlur" ], [ "shadowOffsetX" ], [ "shadowOffsetY" ], [ "shadowColor" ] ]), xm = {
        getBarItemStyle: function(t) {
            var e = _m(this, t);
            if (this.getBorderLineDash) {
                var n = this.getBorderLineDash();
                n && (e.lineDash = n);
            }
            return e;
        }
    }, wm = fi({
        type: "sausage",
        shape: {
            cx: 0,
            cy: 0,
            r0: 0,
            r: 0,
            startAngle: 0,
            endAngle: 2 * Math.PI,
            clockwise: !0
        },
        buildPath: function(t, e) {
            var n = e.cx, i = e.cy, r = Math.max(e.r0 || 0, 0), o = Math.max(e.r, 0), a = .5 * (o - r), s = r + a, l = e.startAngle, h = e.endAngle, u = e.clockwise, c = Math.cos(l), d = Math.sin(l), f = Math.cos(h), p = Math.sin(h);
            (u ? h - l < 2 * Math.PI : l - h < 2 * Math.PI) && (t.moveTo(c * r + n, d * r + i), 
            t.arc(c * s + n, d * s + i, a, -Math.PI + l, l, !u)), t.arc(n, i, o, l, h, !u), 
            t.moveTo(f * o + n, p * o + i), t.arc(f * s + n, p * s + i, a, h - 2 * Math.PI, h - Math.PI, !u), 
            0 !== r && (t.arc(n, i, r, h, l, u), t.moveTo(c * r + n, p * r + i)), t.closePath();
        }
    }), bm = [ "itemStyle", "barBorderWidth" ], Sm = [ 0, 0 ];
    a(Ki.prototype, xm), xa({
        type: "bar",
        render: function(t, e, n) {
            this._updateDrawMode(t);
            var i = t.get("coordinateSystem");
            return "cartesian2d" === i || "polar" === i ? this._isLargeDraw ? this._renderLarge(t, e, n) : this._renderNormal(t, e, n) : wh && console.warn("Only cartesian2d and polar supported for bar."), 
            this.group;
        },
        incrementalPrepareRender: function(t) {
            this._clear(), this._updateDrawMode(t);
        },
        incrementalRender: function(t, e) {
            this._incrementalRenderLarge(t, e);
        },
        _updateDrawMode: function(t) {
            var e = t.pipelineContext.large;
            (null == this._isLargeDraw || e ^ this._isLargeDraw) && (this._isLargeDraw = e, 
            this._clear());
        },
        _renderNormal: function(t) {
            var e, n = this.group, i = t.getData(), r = this._data, o = t.coordinateSystem, a = o.getBaseAxis();
            "cartesian2d" === o.type ? e = a.isHorizontal() : "polar" === o.type && (e = "angle" === a.dim);
            var s = t.isAnimationEnabled() ? t : null, l = t.get("clip", !0), h = function(t, e) {
                var n = t.getArea && t.getArea();
                if ("cartesian2d" === t.type) {
                    var i = t.getBaseAxis();
                    if ("category" !== i.type || !i.onBand) {
                        var r = e.getLayout("bandWidth");
                        i.isHorizontal() ? (n.x -= r, n.width += 2 * r) : (n.y -= r, n.height += 2 * r);
                    }
                }
                return n;
            }(o, i);
            n.removeClipPath();
            var u = t.get("roundCap", !0), c = t.get("showBackground", !0), d = t.getModel("backgroundStyle"), f = d.get("barBorderRadius") || 0, p = [], g = this._backgroundEls || [], v = function(t) {
                var n = Am[o.type](i, t), r = function(t, e, n) {
                    return new ("polar" === t.type ? Qd : sf)({
                        shape: Ks(e, n, t),
                        silent: !0,
                        z2: 0
                    });
                }(o, e, n);
                return r.useStyle(d.getBarItemStyle()), "cartesian2d" === o.type && r.setShape("r", f), 
                p[t] = r, r;
            };
            i.diff(r).add(function(r) {
                var a = i.getItemModel(r), d = Am[o.type](i, r, a);
                if (c && v(r), i.hasValue(r)) {
                    if (l) if (Tm[o.type](h, d)) return void n.remove(f);
                    var f = Cm[o.type](r, d, e, s, !1, u);
                    i.setItemGraphicEl(r, f), n.add(f), js(f, i, r, a, d, t, e, "polar" === o.type);
                }
            }).update(function(a, m) {
                var y = i.getItemModel(a), _ = Am[o.type](i, a, y);
                if (c) {
                    var x;
                    0 === g.length ? x = v(m) : ((x = g[m]).useStyle(d.getBarItemStyle()), "cartesian2d" === o.type && x.setShape("r", f), 
                    p[a] = x);
                    var w = Am[o.type](i, a);
                    Wi(x, {
                        shape: Ks(e, w, o)
                    }, s, a);
                }
                var b = r.getItemGraphicEl(m);
                if (i.hasValue(a)) {
                    if (l) if (Tm[o.type](h, _)) return void n.remove(b);
                    b ? Wi(b, {
                        shape: _
                    }, s, a) : b = Cm[o.type](a, _, e, s, !0, u), i.setItemGraphicEl(a, b), n.add(b), 
                    js(b, i, a, y, _, t, e, "polar" === o.type);
                } else n.remove(b);
            }).remove(function(t) {
                var e = r.getItemGraphicEl(t);
                "cartesian2d" === o.type ? e && Us(t, s, e) : e && Ys(t, s, e);
            }).execute();
            var m = this._backgroundGroup || (this._backgroundGroup = new Nu());
            m.removeAll();
            for (var y = 0; y < p.length; ++y) m.add(p[y]);
            n.add(m), this._backgroundEls = p, this._data = i;
        },
        _renderLarge: function(t) {
            this._clear(), Zs(t, this.group);
            var e = t.get("clip", !0) ? function(t, e, n) {
                return t ? "polar" === t.type ? Xs(t, e, n) : "cartesian2d" === t.type ? Ws(t, e, n) : null : null;
            }(t.coordinateSystem, !1, t) : null;
            e ? this.group.setClipPath(e) : this.group.removeClipPath();
        },
        _incrementalRenderLarge: function(t, e) {
            this._removeBackground(), Zs(e, this.group, !0);
        },
        dispose: R,
        remove: function(t) {
            this._clear(t);
        },
        _clear: function(t) {
            var e = this.group, n = this._data;
            t && t.get("animation") && n && !this._isLargeDraw ? (this._removeBackground(), 
            this._backgroundEls = [], n.eachItemGraphicEl(function(e) {
                "sector" === e.type ? Ys(e.dataIndex, t, e) : Us(e.dataIndex, t, e);
            })) : e.removeAll(), this._data = null;
        },
        _removeBackground: function() {
            this.group.remove(this._backgroundGroup), this._backgroundGroup = null;
        }
    });
    var Mm = Math.max, Im = Math.min, Tm = {
        cartesian2d: function(t, e) {
            var n = e.width < 0 ? -1 : 1, i = e.height < 0 ? -1 : 1;
            0 > n && (e.x += e.width, e.width = -e.width), 0 > i && (e.y += e.height, e.height = -e.height);
            var r = Mm(e.x, t.x), o = Im(e.x + e.width, t.x + t.width), a = Mm(e.y, t.y), s = Im(e.y + e.height, t.y + t.height);
            e.x = r, e.y = a, e.width = o - r, e.height = s - a;
            var l = e.width < 0 || e.height < 0;
            return 0 > n && (e.x += e.width, e.width = -e.width), 0 > i && (e.y += e.height, 
            e.height = -e.height), l;
        },
        polar: function(t, e) {
            var n = e.r0 <= e.r ? 1 : -1;
            if (0 > n) {
                var i = e.r;
                e.r = e.r0, e.r0 = i;
            }
            i = Im(e.r, t.r);
            var r = Mm(e.r0, t.r0);
            e.r = i, e.r0 = r;
            var o = 0 > i - r;
            if (0 > n) {
                i = e.r;
                e.r = e.r0, e.r0 = i;
            }
            return o;
        }
    }, Cm = {
        cartesian2d: function(t, e, n, i, r) {
            var o = new sf({
                shape: a({}, e),
                z2: 1
            });
            if (o.name = "item", i) {
                var s = n ? "height" : "width", l = {};
                o.shape[s] = 0, l[s] = e[s], Pf[r ? "updateProps" : "initProps"](o, {
                    shape: l
                }, i, t);
            }
            return o;
        },
        polar: function(t, e, n, i, r, o) {
            var a = e.startAngle < e.endAngle, l = new (!n && o ? wm : Qd)({
                shape: s({
                    clockwise: a
                }, e),
                z2: 1
            });
            if (l.name = "item", i) {
                var h = n ? "r" : "endAngle", u = {};
                l.shape[h] = n ? 0 : e.startAngle, u[h] = e[h], Pf[r ? "updateProps" : "initProps"](l, {
                    shape: u
                }, i, t);
            }
            return l;
        }
    }, Am = {
        cartesian2d: function(t, e, n) {
            var i = t.getItemLayout(e), r = n ? function(t, e) {
                var n = t.get(bm) || 0, i = isNaN(e.width) ? Number.MAX_VALUE : Math.abs(e.width), r = isNaN(e.height) ? Number.MAX_VALUE : Math.abs(e.height);
                return Math.min(n, i, r);
            }(n, i) : 0, o = i.width > 0 ? 1 : -1, a = i.height > 0 ? 1 : -1;
            return {
                x: i.x + o * r / 2,
                y: i.y + a * r / 2,
                width: i.width - o * r,
                height: i.height - a * r
            };
        },
        polar: function(t, e) {
            var n = t.getItemLayout(e);
            return {
                cx: n.cx,
                cy: n.cy,
                r0: n.r0,
                r: n.r,
                startAngle: n.startAngle,
                endAngle: n.endAngle
            };
        }
    }, Dm = ni.extend({
        type: "largeBar",
        shape: {
            points: []
        },
        buildPath: function(t, e) {
            for (var n = e.points, i = this.__startPoint, r = this.__baseDimIdx, o = 0; o < n.length; o += 2) i[r] = n[o + r], 
            t.moveTo(i[0], i[1]), t.lineTo(n[o], n[o + 1]);
        }
    }), km = bo(function(t) {
        var e = function(t, e, n) {
            var i = t.__baseDimIdx, r = 1 - i, o = t.shape.points, a = t.__largeDataIndices, s = Math.abs(t.__barWidth / 2), l = t.__startPoint[r];
            Sm[0] = e, Sm[1] = n;
            for (var h = Sm[i], u = Sm[1 - i], c = h - s, d = h + s, f = 0, p = o.length / 2; p > f; f++) {
                var g = 2 * f, v = o[g + i], m = o[g + r];
                if (v >= c && d >= v && (m >= l ? u >= l && m >= u : u >= m && l >= u)) return a[f];
            }
            return -1;
        }(this, t.offsetX, t.offsetY);
        this.dataIndex = e >= 0 ? e : null;
    }, 30, !1), Pm = Math.PI, Lm = function(t, e) {
        this.opt = e, this.axisModel = t, s(e, {
            labelOffset: 0,
            nameDirection: 1,
            tickDirection: 1,
            labelDirection: 1,
            silent: !0
        }), this.group = new Nu();
        var n = new Nu({
            position: e.position.slice(),
            rotation: e.rotation
        });
        n.updateTransform(), this._transform = n.transform, this._dumbGroup = n;
    };
    Lm.prototype = {
        constructor: Lm,
        hasBuilder: function(t) {
            return !!Om[t];
        },
        add: function(t) {
            Om[t].call(this);
        },
        getGroup: function() {
            return this.group;
        }
    };
    var Om = {
        axisLine: function() {
            var t = this.opt, e = this.axisModel;
            if (e.get("axisLine.show")) {
                var n = this.axisModel.axis.getExtent(), i = this._transform, r = [ n[0], 0 ], o = [ n[1], 0 ];
                i && ($(r, r, i), $(o, o, i));
                var s = a({
                    lineCap: "round"
                }, e.getModel("axisLine.lineStyle").getLineStyle());
                this.group.add(new hf({
                    anid: "line",
                    subPixelOptimize: !0,
                    shape: {
                        x1: r[0],
                        y1: r[1],
                        x2: o[0],
                        y2: o[1]
                    },
                    style: s,
                    strokeContainThreshold: t.strokeContainThreshold || 5,
                    silent: !0,
                    z2: 1
                }));
                var l = e.get("axisLine.symbol"), h = e.get("axisLine.symbolSize"), u = e.get("axisLine.symbolOffset") || 0;
                if ("number" == typeof u && (u = [ u, u ]), null != l) {
                    "string" == typeof l && (l = [ l, l ]), ("string" == typeof h || "number" == typeof h) && (h = [ h, h ]);
                    var c = h[0], d = h[1];
                    f([ {
                        rotate: t.rotation + Math.PI / 2,
                        offset: u[0],
                        r: 0
                    }, {
                        rotate: t.rotation - Math.PI / 2,
                        offset: u[1],
                        r: Math.sqrt((r[0] - o[0]) * (r[0] - o[0]) + (r[1] - o[1]) * (r[1] - o[1]))
                    } ], function(e, n) {
                        if ("none" !== l[n] && null != l[n]) {
                            var i = ys(l[n], -c / 2, -d / 2, c, d, s.stroke, !0), o = e.r + e.offset, a = [ r[0] + o * Math.cos(t.rotation), r[1] - o * Math.sin(t.rotation) ];
                            i.attr({
                                rotation: e.rotate,
                                position: a,
                                silent: !0,
                                z2: 11
                            }), this.group.add(i);
                        }
                    }, this);
                }
            }
        },
        axisTickLabel: function() {
            var t = this.axisModel, e = this.opt, n = function(t, e, n) {
                var i = e.axis, r = e.getModel("axisTick");
                if (r.get("show") && !i.scale.isBlank()) {
                    for (var o = r.getModel("lineStyle"), a = n.tickDirection * r.get("length"), l = tl(i.getTicksCoords(), t._transform, a, s(o.getLineStyle(), {
                        stroke: e.get("axisLine.lineStyle.color")
                    }), "ticks"), h = 0; h < l.length; h++) t.group.add(l[h]);
                    return l;
                }
            }(this, t, e), i = function(t, e, n) {
                var i = e.axis;
                if (C(n.axisLabelShow, e.get("axisLabel.show")) && !i.scale.isBlank()) {
                    var r = e.getModel("axisLabel"), o = r.get("margin"), a = i.getViewLabels(), s = (C(n.labelRotate, r.get("rotate")) || 0) * Pm / 180, l = Bm(n.rotation, s, n.labelDirection), h = e.getCategories && e.getCategories(!0), u = [], c = zm(e), d = e.get("triggerEvent");
                    return f(a, function(a, s) {
                        var f = a.tickValue, p = a.formattedLabel, g = a.rawLabel, v = r;
                        h && h[f] && h[f].textStyle && (v = new Ki(h[f].textStyle, r, e.ecModel));
                        var m = v.getTextColor() || e.get("axisLine.lineStyle.color"), y = [ i.dataToCoord(f), n.labelOffset + n.labelDirection * o ], _ = new jd({
                            anid: "label_" + f,
                            position: y,
                            rotation: l.rotation,
                            silent: c,
                            z2: 10
                        });
                        Bi(_.style, v, {
                            text: p,
                            textAlign: v.getShallow("align", !0) || l.textAlign,
                            textVerticalAlign: v.getShallow("verticalAlign", !0) || v.getShallow("baseline", !0) || l.textVerticalAlign,
                            textFill: "function" == typeof m ? m("category" === i.type ? g : "value" === i.type ? f + "" : f, s) : m
                        }), d && (_.eventData = Em(e), _.eventData.targetType = "axisLabel", _.eventData.value = g), 
                        t._dumbGroup.add(_), _.updateTransform(), u.push(_), t.group.add(_), _.decomposeTransform();
                    }), u;
                }
            }(this, t, e);
            (function(t, e, n) {
                if (!vs(t.axis)) {
                    var i = t.get("axisLabel.showMinLabel"), r = t.get("axisLabel.showMaxLabel");
                    n = n || [];
                    var o = (e = e || [])[0], a = e[1], s = e[e.length - 1], l = e[e.length - 2], h = n[0], u = n[1], c = n[n.length - 1], d = n[n.length - 2];
                    !1 === i ? ($s(o), $s(h)) : Qs(o, a) && (i ? ($s(a), $s(u)) : ($s(o), $s(h))), !1 === r ? ($s(s), 
                    $s(c)) : Qs(l, s) && (r ? ($s(l), $s(d)) : ($s(s), $s(c)));
                }
            })(t, i, n), function(t, e, n) {
                var i = e.axis, r = e.getModel("minorTick");
                if (r.get("show") && !i.scale.isBlank()) {
                    var o = i.getMinorTicksCoords();
                    if (o.length) for (var a = r.getModel("lineStyle"), l = n.tickDirection * r.get("length"), h = s(a.getLineStyle(), s(e.getModel("axisTick").getLineStyle(), {
                        stroke: e.get("axisLine.lineStyle.color")
                    })), u = 0; u < o.length; u++) for (var c = tl(o[u], t._transform, l, h, "minorticks_" + u), d = 0; d < c.length; d++) t.group.add(c[d]);
                }
            }(this, t, e);
        },
        axisName: function() {
            var t = this.opt, e = this.axisModel, n = C(t.axisName, e.get("name"));
            if (n) {
                var i, r, o = e.get("nameLocation"), s = t.nameDirection, l = e.getModel("nameTextStyle"), h = e.get("nameGap") || 0, u = this.axisModel.axis.getExtent(), c = u[0] > u[1] ? -1 : 1, d = [ "start" === o ? u[0] - c * h : "end" === o ? u[1] + c * h : (u[0] + u[1]) / 2, Js(o) ? t.labelOffset + s * h : 0 ], f = e.get("nameRotate");
                null != f && (f = f * Pm / 180), Js(o) ? i = Bm(t.rotation, null != f ? f : t.rotation, s) : (i = function(t, e, n, i) {
                    var r, o, a = ar(n - t.rotation), s = i[0] > i[1], l = "start" === e && !s || "start" !== e && s;
                    return sr(a - Pm / 2) ? (o = l ? "bottom" : "top", r = "center") : sr(a - 1.5 * Pm) ? (o = l ? "top" : "bottom", 
                    r = "center") : (o = "middle", r = 1.5 * Pm > a && a > Pm / 2 ? l ? "left" : "right" : l ? "right" : "left"), 
                    {
                        rotation: a,
                        textAlign: r,
                        textVerticalAlign: o
                    };
                }(t, o, f || 0, u), null != (r = t.axisNameAvailableWidth) && (r = Math.abs(r / Math.sin(i.rotation)), 
                !isFinite(r) && (r = null)));
                var p = l.getFont(), g = e.get("nameTruncate", !0) || {}, v = g.ellipsis, m = C(t.nameTruncateMaxWidth, g.maxWidth, r), y = null != v && null != m ? qf(n, m, p, v, {
                    minChar: 2,
                    placeholder: g.placeholder
                }) : n, _ = e.get("tooltip", !0), x = e.mainType, w = {
                    componentType: x,
                    name: n,
                    $vars: [ "name" ]
                };
                w[x + "Index"] = e.componentIndex;
                var b = new jd({
                    anid: "name",
                    __fullText: n,
                    __truncatedText: y,
                    position: d,
                    rotation: i.rotation,
                    silent: zm(e),
                    z2: 1,
                    tooltip: _ && _.show ? a({
                        content: n,
                        formatter: function() {
                            return n;
                        },
                        formatterParams: w
                    }, _) : null
                });
                Bi(b.style, l, {
                    text: y,
                    textFont: p,
                    textFill: l.getTextColor() || e.get("axisLine.lineStyle.color"),
                    textAlign: l.get("align") || i.textAlign,
                    textVerticalAlign: l.get("verticalAlign") || i.textVerticalAlign
                }), e.get("triggerEvent") && (b.eventData = Em(e), b.eventData.targetType = "axisName", 
                b.eventData.name = n), this._dumbGroup.add(b), b.updateTransform(), this.group.add(b), 
                b.decomposeTransform();
            }
        }
    }, Em = Lm.makeAxisEventDataBase = function(t) {
        var e = {
            componentType: t.mainType,
            componentIndex: t.componentIndex
        };
        return e[t.mainType + "Index"] = t.componentIndex, e;
    }, Bm = Lm.innerTextLayout = function(t, e, n) {
        var i, r, o = ar(e - t);
        return sr(o) ? (r = n > 0 ? "top" : "bottom", i = "center") : sr(o - Pm) ? (r = n > 0 ? "bottom" : "top", 
        i = "center") : (r = "middle", i = o > 0 && Pm > o ? n > 0 ? "right" : "left" : n > 0 ? "left" : "right"), 
        {
            rotation: o,
            textAlign: i,
            textVerticalAlign: r
        };
    }, zm = Lm.isLabelSilent = function(t) {
        var e = t.get("tooltip");
        return t.get("silent") || !(t.get("triggerEvent") || e && e.show);
    }, Nm = f, Rm = y, Fm = ya({
        type: "axis",
        _axisPointer: null,
        axisPointerClass: null,
        render: function(t, e, n, i) {
            this.axisPointerClass && rl(t), Fm.superApply(this, "render", arguments), ll(this, t, 0, n, 0, !0);
        },
        updateAxisPointer: function(t, e, n, i) {
            ll(this, t, 0, n, 0, !1);
        },
        remove: function(t, e) {
            var n = this._axisPointer;
            n && n.remove(e), Fm.superApply(this, "remove", arguments);
        },
        dispose: function(t, e) {
            hl(this, e), Fm.superApply(this, "dispose", arguments);
        }
    }), Vm = [];
    Fm.registerAxisPointerClass = function(t, e) {
        if (wh && Vm[t]) throw new Error("axisPointer " + t + " exists");
        Vm[t] = e;
    }, Fm.getAxisPointerClass = function(t) {
        return t && Vm[t];
    };
    var Hm = [ "axisLine", "axisTickLabel", "axisName" ], Gm = [ "splitArea", "splitLine", "minorSplitLine" ], Wm = Fm.extend({
        type: "cartesianAxis",
        axisPointerClass: "CartesianAxisPointer",
        render: function(t, e, n, i) {
            this.group.removeAll();
            var r = this._axisGroup;
            if (this._axisGroup = new Nu(), this.group.add(this._axisGroup), t.get("show")) {
                var o = t.getCoordSysModel(), a = ul(o, t), s = new Lm(t, a);
                f(Hm, s.add, s), this._axisGroup.add(s.getGroup()), f(Gm, function(e) {
                    t.get(e + ".show") && this["_" + e](t, o);
                }, this), Yi(r, this._axisGroup, t), Wm.superCall(this, "render", t, e, n, i);
            }
        },
        remove: function() {
            !function(t) {
                t.__splitAreaColors = null;
            }(this);
        },
        _splitLine: function(t, e) {
            var n = t.axis;
            if (!n.scale.isBlank()) {
                var i = t.getModel("splitLine"), r = i.getModel("lineStyle"), o = r.get("color");
                o = _(o) ? o : [ o ];
                for (var a = e.coordinateSystem.getRect(), l = n.isHorizontal(), h = 0, u = n.getTicksCoords({
                    tickModel: i
                }), c = [], d = [], f = r.getLineStyle(), p = 0; p < u.length; p++) {
                    var g = n.toGlobalCoord(u[p].coord);
                    l ? (c[0] = g, c[1] = a.y, d[0] = g, d[1] = a.y + a.height) : (c[0] = a.x, c[1] = g, 
                    d[0] = a.x + a.width, d[1] = g);
                    var v = h++ % o.length, m = u[p].tickValue;
                    this._axisGroup.add(new hf({
                        anid: null != m ? "line_" + u[p].tickValue : null,
                        subPixelOptimize: !0,
                        shape: {
                            x1: c[0],
                            y1: c[1],
                            x2: d[0],
                            y2: d[1]
                        },
                        style: s({
                            stroke: o[v]
                        }, f),
                        silent: !0
                    }));
                }
            }
        },
        _minorSplitLine: function(t, e) {
            var n = t.axis, i = t.getModel("minorSplitLine").getModel("lineStyle"), r = e.coordinateSystem.getRect(), o = n.isHorizontal(), a = n.getMinorTicksCoords();
            if (a.length) for (var s = [], l = [], h = i.getLineStyle(), u = 0; u < a.length; u++) for (var c = 0; c < a[u].length; c++) {
                var d = n.toGlobalCoord(a[u][c].coord);
                o ? (s[0] = d, s[1] = r.y, l[0] = d, l[1] = r.y + r.height) : (s[0] = r.x, s[1] = d, 
                l[0] = r.x + r.width, l[1] = d), this._axisGroup.add(new hf({
                    anid: "minor_line_" + a[u][c].tickValue,
                    subPixelOptimize: !0,
                    shape: {
                        x1: s[0],
                        y1: s[1],
                        x2: l[0],
                        y2: l[1]
                    },
                    style: h,
                    silent: !0
                }));
            }
        },
        _splitArea: function(t, e) {
            !function(t, e, n, i) {
                var r = n.axis;
                if (!r.scale.isBlank()) {
                    var o = n.getModel("splitArea"), a = o.getModel("areaStyle"), l = a.get("color"), h = i.coordinateSystem.getRect(), u = r.getTicksCoords({
                        tickModel: o,
                        clamp: !0
                    });
                    if (u.length) {
                        var c = l.length, d = t.__splitAreaColors, f = N(), p = 0;
                        if (d) for (var g = 0; g < u.length; g++) {
                            var v = d.get(u[g].tickValue);
                            if (null != v) {
                                p = (v + (c - 1) * g) % c;
                                break;
                            }
                        }
                        var m = r.toGlobalCoord(u[0].coord), y = a.getAreaStyle();
                        l = _(l) ? l : [ l ];
                        for (g = 1; g < u.length; g++) {
                            var x, w, b, S, M = r.toGlobalCoord(u[g].coord);
                            r.isHorizontal() ? (x = m, w = h.y, b = M - x, S = h.height, m = x + b) : (x = h.x, 
                            w = m, b = h.width, m = w + (S = M - w));
                            var I = u[g - 1].tickValue;
                            null != I && f.set(I, p), e.add(new sf({
                                anid: null != I ? "area_" + I : null,
                                shape: {
                                    x: x,
                                    y: w,
                                    width: b,
                                    height: S
                                },
                                style: s({
                                    fill: l[p]
                                }, y),
                                silent: !0
                            })), p = (p + 1) % c;
                        }
                        t.__splitAreaColors = f;
                    }
                }
            }(this, this._axisGroup, t, e);
        }
    });
    Wm.extend({
        type: "xAxis"
    }), Wm.extend({
        type: "yAxis"
    }), ya({
        type: "grid",
        render: function(t) {
            this.group.removeAll(), t.get("show") && this.group.add(new sf({
                shape: t.coordinateSystem.getRect(),
                style: s({
                    fill: t.get("backgroundColor")
                }, t.getItemStyle()),
                silent: !0,
                z2: -1
            }));
        }
    }), ua(function(t) {
        t.xAxis && t.yAxis && !t.grid && (t.grid = {});
    }), fa(Bg.VISUAL.LAYOUT, y(function(t, e) {
        var n = ns(t, e), i = is(n), r = {};
        f(n, function(t) {
            var e = t.getData(), n = t.coordinateSystem, o = n.getBaseAxis(), a = ts(t), s = i[es(o)][a], l = s.offset, h = s.width, u = n.getOtherAxis(o), c = t.get("barMinHeight") || 0;
            r[a] = r[a] || [], e.setLayout({
                bandWidth: s.bandWidth,
                offset: l,
                size: h
            });
            for (var d = e.mapDimension(u.dim), f = e.mapDimension(o.dim), p = Xa(e, d), g = u.isHorizontal(), v = ss(o, u), m = 0, y = e.count(); y > m; m++) {
                var _, x, w, b, S, M = e.get(d, m), I = e.get(f, m), T = M >= 0 ? "p" : "n", C = v;
                if (p && (r[a][I] || (r[a][I] = {
                    p: v,
                    n: v
                }), C = r[a][I][T]), g) _ = C, x = (S = n.dataToPoint([ M, I ]))[1] + l, w = S[0] - v, 
                b = h, Math.abs(w) < c && (w = (0 > w ? -1 : 1) * c), isNaN(w) || p && (r[a][I][T] += w); else _ = (S = n.dataToPoint([ I, M ]))[0] + l, 
                x = C, w = h, b = S[1] - v, Math.abs(b) < c && (b = (0 >= b ? -1 : 1) * c), isNaN(b) || p && (r[a][I][T] += b);
                e.setItemLayout(m, {
                    x: _,
                    y: x,
                    width: w,
                    height: b
                });
            }
        }, this);
    }, "bar")), fa(Bg.VISUAL.PROGRESSIVE_LAYOUT, Tv), pa({
        seriesType: "bar",
        reset: function(t) {
            t.getData().setVisual("legendSymbol", "roundRect");
        }
    }), Hp.extend({
        type: "series.line",
        dependencies: [ "grid", "polar" ],
        getInitialData: function(t) {
            if (wh) {
                var e = t.coordinateSystem;
                if ("polar" !== e && "cartesian2d" !== e) throw new Error("Line not support coordinateSystem besides cartesian and polar");
            }
            return Ya(this.getSource(), this, {
                useEncodeDefaulter: !0
            });
        },
        defaultOption: {
            zlevel: 0,
            z: 2,
            coordinateSystem: "cartesian2d",
            legendHoverLink: !0,
            hoverAnimation: !0,
            clip: !0,
            label: {
                position: "top"
            },
            lineStyle: {
                width: 2,
                type: "solid"
            },
            step: !1,
            smooth: !1,
            smoothMonotone: null,
            symbol: "emptyCircle",
            symbolSize: 4,
            symbolRotate: null,
            showSymbol: !0,
            showAllSymbol: "auto",
            connectNulls: !1,
            sampling: "none",
            animationEasing: "linear",
            progressive: 0,
            hoverLayerThreshold: 1 / 0
        }
    });
    var Xm = cl.prototype, Um = cl.getSymbolSize = function(t, e) {
        var n = t.getItemVisual(e, "symbolSize");
        return n instanceof Array ? n.slice() : [ +n, +n ];
    };
    Xm._createSymbol = function(t, e, n, i, r) {
        this.removeAll();
        var o = ys(t, -1, -1, 2, 2, e.getItemVisual(n, "color"), r);
        o.attr({
            z2: 100,
            culling: !0,
            scale: dl(i)
        }), o.drift = fl, this._symbolType = t, this.add(o);
    }, Xm.stopSymbolAnimation = function(t) {
        this.childAt(0).stopAnimation(t);
    }, Xm.getSymbolPath = function() {
        return this.childAt(0);
    }, Xm.getScale = function() {
        return this.childAt(0).scale;
    }, Xm.highlight = function() {
        this.childAt(0).trigger("emphasis");
    }, Xm.downplay = function() {
        this.childAt(0).trigger("normal");
    }, Xm.setZ = function(t, e) {
        var n = this.childAt(0);
        n.zlevel = t, n.z = e;
    }, Xm.setDraggable = function(t) {
        var e = this.childAt(0);
        e.draggable = t, e.cursor = t ? "move" : e.cursor;
    }, Xm.updateData = function(t, e, n) {
        this.silent = !1;
        var i = t.getItemVisual(e, "symbol") || "circle", r = t.hostModel, o = Um(t, e), a = i !== this._symbolType;
        if (a) {
            var s = t.getItemVisual(e, "symbolKeepAspect");
            this._createSymbol(i, t, e, o, s);
        } else {
            (l = this.childAt(0)).silent = !1, Wi(l, {
                scale: dl(o)
            }, r, e);
        }
        if (this._updateCommon(t, e, o, n), a) {
            var l = this.childAt(0), h = n && n.fadeIn, u = {
                scale: l.scale.slice()
            };
            h && (u.style = {
                opacity: l.style.opacity
            }), l.scale = [ 0, 0 ], h && (l.style.opacity = 0), Xi(l, u, r, e);
        }
        this._seriesModel = r;
    };
    var Ym = [ "itemStyle" ], qm = [ "emphasis", "itemStyle" ], jm = [ "label" ], Zm = [ "emphasis", "label" ];
    Xm._updateCommon = function(t, e, n, i) {
        var r = this.childAt(0), o = t.hostModel, s = t.getItemVisual(e, "color");
        "image" !== r.type ? r.useStyle({
            strokeNoScale: !0
        }) : r.setStyle({
            opacity: 1,
            shadowBlur: null,
            shadowOffsetX: null,
            shadowOffsetY: null,
            shadowColor: null
        });
        var l = i && i.itemStyle, h = i && i.hoverItemStyle, u = i && i.symbolOffset, c = i && i.labelModel, d = i && i.hoverLabelModel, f = i && i.hoverAnimation, p = i && i.cursorStyle;
        if (!i || t.hasItemOption) {
            var g = i && i.itemModel ? i.itemModel : t.getItemModel(e);
            l = g.getModel(Ym).getItemStyle([ "color" ]), h = g.getModel(qm).getItemStyle(), 
            u = g.getShallow("symbolOffset"), c = g.getModel(jm), d = g.getModel(Zm), f = g.getShallow("hoverAnimation"), 
            p = g.getShallow("cursor");
        } else h = a({}, h);
        var v = r.style, m = t.getItemVisual(e, "symbolRotate");
        r.attr("rotation", (m || 0) * Math.PI / 180 || 0), u && r.attr("position", [ er(u[0], n[0]), er(u[1], n[1]) ]), 
        p && r.attr("cursor", p), r.setColor(s, i && i.symbolInnerColor), r.setStyle(l);
        var y = t.getItemVisual(e, "opacity");
        null != y && (v.opacity = y);
        var _ = t.getItemVisual(e, "liftZ"), x = r.__z2Origin;
        null != _ ? null == x && (r.__z2Origin = r.z2, r.z2 += _) : null != x && (r.z2 = x, 
        r.__z2Origin = null);
        var w = i && i.useNameLabel;
        Ei(v, h, c, d, {
            labelFetcher: o,
            labelDataIndex: e,
            defaultText: function(e) {
                return w ? t.getName(e) : Hs(t, e);
            },
            isRectText: !0,
            autoColor: s
        }), r.__symbolOriginalScale = dl(n), r.hoverStyle = h, r.highDownOnUpdate = f && o.isAnimationEnabled() ? pl : null, 
        ki(r);
    }, Xm.fadeOut = function(t, e) {
        var n = this.childAt(0);
        this.silent = n.silent = !0, !(e && e.keepLabel) && (n.style.text = null), Wi(n, {
            style: {
                opacity: 0
            },
            scale: [ 0, 0 ]
        }, this._seriesModel, this.dataIndex, t);
    }, u(cl, Nu);
    var Km = gl.prototype;
    Km.updateData = function(t, e) {
        e = ml(e);
        var n = this.group, i = t.hostModel, r = this._data, o = this._symbolCtor, a = yl(t);
        r || n.removeAll(), t.diff(r).add(function(i) {
            var r = t.getItemLayout(i);
            if (vl(t, r, i, e)) {
                var s = new o(t, i, a);
                s.attr("position", r), t.setItemGraphicEl(i, s), n.add(s);
            }
        }).update(function(s, l) {
            var h = r.getItemGraphicEl(l), u = t.getItemLayout(s);
            return vl(t, u, s, e) ? (h ? (h.updateData(t, s, a), Wi(h, {
                position: u
            }, i)) : (h = new o(t, s)).attr("position", u), n.add(h), void t.setItemGraphicEl(s, h)) : void n.remove(h);
        }).remove(function(t) {
            var e = r.getItemGraphicEl(t);
            e && e.fadeOut(function() {
                n.remove(e);
            });
        }).execute(), this._data = t;
    }, Km.isPersistent = function() {
        return !0;
    }, Km.updateLayout = function() {
        var t = this._data;
        t && t.eachItemGraphicEl(function(e, n) {
            var i = t.getItemLayout(n);
            e.attr("position", i);
        });
    }, Km.incrementalPrepareUpdate = function(t) {
        this._seriesScope = yl(t), this._data = null, this.group.removeAll();
    }, Km.incrementalUpdate = function(t, e, n) {
        function i(t) {
            t.isGroup || (t.incremental = t.useHoverLayer = !0);
        }
        n = ml(n);
        for (var r = t.start; r < t.end; r++) {
            var o = e.getItemLayout(r);
            if (vl(e, o, r, n)) {
                var a = new this._symbolCtor(e, r, this._seriesScope);
                a.traverse(i), a.attr("position", o), this.group.add(a), e.setItemGraphicEl(r, a);
            }
        }
    }, Km.remove = function(t) {
        var e = this.group, n = this._data;
        n && t ? n.eachItemGraphicEl(function(t) {
            t.fadeOut(function() {
                e.remove(t);
            });
        }) : e.removeAll();
    };
    var $m = Q, Qm = J, Jm = W, ty = V, ey = [], ny = [], iy = [], ry = ni.extend({
        type: "ec-polyline",
        shape: {
            points: [],
            smooth: 0,
            smoothConstraint: !0,
            smoothMonotone: null,
            connectNulls: !1
        },
        style: {
            fill: null,
            stroke: "#000"
        },
        brush: $d(ni.prototype.brush),
        buildPath: function(t, e) {
            var n = e.points, i = 0, r = n.length, o = Il(n, e.smoothConstraint);
            if (e.connectNulls) {
                for (;r > 0 && wl(n[r - 1]); r--) ;
                for (;r > i && wl(n[i]); i++) ;
            }
            for (;r > i; ) i += bl(t, n, i, r, r, 1, o.min, o.max, e.smooth, e.smoothMonotone, e.connectNulls) + 1;
        }
    }), oy = ni.extend({
        type: "ec-polygon",
        shape: {
            points: [],
            stackedOnPoints: [],
            smooth: 0,
            stackedOnSmooth: 0,
            smoothConstraint: !0,
            smoothMonotone: null,
            connectNulls: !1
        },
        brush: $d(ni.prototype.brush),
        buildPath: function(t, e) {
            var n = e.points, i = e.stackedOnPoints, r = 0, o = n.length, a = e.smoothMonotone, s = Il(n, e.smoothConstraint), l = Il(i, e.smoothConstraint);
            if (e.connectNulls) {
                for (;o > 0 && wl(n[o - 1]); o--) ;
                for (;o > r && wl(n[r]); r++) ;
            }
            for (;o > r; ) {
                var h = bl(t, n, r, o, o, 1, s.min, s.max, e.smooth, a, e.connectNulls);
                bl(t, i, r + h - 1, h, o, -1, l.min, l.max, e.stackedOnSmooth, a, e.connectNulls), 
                r += h + 1, t.closePath();
            }
        }
    });
    mo.extend({
        type: "line",
        init: function() {
            var t = new Nu(), e = new gl();
            this.group.add(e.group), this._symbolDraw = e, this._lineGroup = t;
        },
        render: function(t, e, n) {
            var i = t.coordinateSystem, r = this.group, o = t.getData(), a = t.getModel("lineStyle"), l = t.getModel("areaStyle"), h = o.mapArray(o.getItemLayout), u = "polar" === i.type, c = this._coordSys, d = this._symbolDraw, f = this._polyline, p = this._polygon, g = this._lineGroup, v = t.get("animation"), m = !l.isEmpty(), y = l.get("origin"), _ = function(t, e, n) {
                if (!n.valueDim) return [];
                for (var i = [], r = 0, o = e.count(); o > r; r++) i.push(xl(n, t, e, r));
                return i;
            }(i, o, _l(i, o, y)), x = t.get("showSymbol"), w = x && !u && Pl(t, o, i), b = this._data;
            b && b.eachItemGraphicEl(function(t, e) {
                t.__temp && (r.remove(t), b.setItemGraphicEl(e, null));
            }), x || d.remove(), r.add(g);
            var S, M = !u && t.get("step");
            i && i.getArea && t.get("clip", !0) && (null != (S = i.getArea()).width ? (S.x -= .1, 
            S.y -= .1, S.width += .2, S.height += .2) : S.r0 && (S.r0 -= .5, S.r1 += .5)), this._clipShapeForSymbol = S, 
            f && c.type === i.type && M === this._step ? (m && !p ? p = this._newPolygon(h, _, i, v) : p && !m && (g.remove(p), 
            p = this._polygon = null), g.setClipPath(Ll(i, !1, t)), x && d.updateData(o, {
                isIgnore: w,
                clipShape: S
            }), o.eachItemGraphicEl(function(t) {
                t.stopAnimation(!0);
            }), Tl(this._stackedOnPoints, _) && Tl(this._points, h) || (v ? this._updateAnimation(o, _, i, n, M, y) : (M && (h = Dl(h, i, M), 
            _ = Dl(_, i, M)), f.setShape({
                points: h
            }), p && p.setShape({
                points: h,
                stackedOnPoints: _
            })))) : (x && d.updateData(o, {
                isIgnore: w,
                clipShape: S
            }), M && (h = Dl(h, i, M), _ = Dl(_, i, M)), f = this._newPolyline(h, i, v), m && (p = this._newPolygon(h, _, i, v)), 
            g.setClipPath(Ll(i, !0, t)));
            var I = kl(o, i) || o.getVisual("color");
            f.useStyle(s(a.getLineStyle(), {
                fill: "none",
                stroke: I,
                lineJoin: "bevel"
            }));
            var T = t.get("smooth");
            if (T = Al(t.get("smooth")), f.setShape({
                smooth: T,
                smoothMonotone: t.get("smoothMonotone"),
                connectNulls: t.get("connectNulls")
            }), p) {
                var C = o.getCalculationInfo("stackedOnSeries"), A = 0;
                p.useStyle(s(l.getAreaStyle(), {
                    fill: I,
                    opacity: .7,
                    lineJoin: "bevel"
                })), C && (A = Al(C.get("smooth"))), p.setShape({
                    smooth: T,
                    stackedOnSmooth: A,
                    smoothMonotone: t.get("smoothMonotone"),
                    connectNulls: t.get("connectNulls")
                });
            }
            this._data = o, this._coordSys = i, this._stackedOnPoints = _, this._points = h, 
            this._step = M, this._valueOrigin = y;
        },
        dispose: function() {},
        highlight: function(t, e, n, i) {
            var r = t.getData(), o = yn(r, i);
            if (!(o instanceof Array) && null != o && o >= 0) {
                var a = r.getItemGraphicEl(o);
                if (!a) {
                    var s = r.getItemLayout(o);
                    if (!s) return;
                    if (this._clipShapeForSymbol && !this._clipShapeForSymbol.contain(s[0], s[1])) return;
                    (a = new cl(r, o)).position = s, a.setZ(t.get("zlevel"), t.get("z")), a.ignore = isNaN(s[0]) || isNaN(s[1]), 
                    a.__temp = !0, r.setItemGraphicEl(o, a), a.stopSymbolAnimation(!0), this.group.add(a);
                }
                a.highlight();
            } else mo.prototype.highlight.call(this, t, e, n, i);
        },
        downplay: function(t, e, n, i) {
            var r = t.getData(), o = yn(r, i);
            if (null != o && o >= 0) {
                var a = r.getItemGraphicEl(o);
                a && (a.__temp ? (r.setItemGraphicEl(o, null), this.group.remove(a)) : a.downplay());
            } else mo.prototype.downplay.call(this, t, e, n, i);
        },
        _newPolyline: function(t) {
            var e = this._polyline;
            return e && this._lineGroup.remove(e), e = new ry({
                shape: {
                    points: t
                },
                silent: !0,
                z2: 10
            }), this._lineGroup.add(e), this._polyline = e, e;
        },
        _newPolygon: function(t, e) {
            var n = this._polygon;
            return n && this._lineGroup.remove(n), n = new oy({
                shape: {
                    points: t,
                    stackedOnPoints: e
                },
                silent: !0
            }), this._lineGroup.add(n), this._polygon = n, n;
        },
        _updateAnimation: function(t, e, n, i, r, o) {
            var a = this._polyline, s = this._polygon, l = t.hostModel, h = function(t, e, n, i, r, o, a, s) {
                for (var l = function(t, e) {
                    var n = [];
                    return e.diff(t).add(function(t) {
                        n.push({
                            cmd: "+",
                            idx: t
                        });
                    }).update(function(t, e) {
                        n.push({
                            cmd: "=",
                            idx: e,
                            idx1: t
                        });
                    }).remove(function(t) {
                        n.push({
                            cmd: "-",
                            idx: t
                        });
                    }).execute(), n;
                }(t, e), h = [], u = [], c = [], d = [], f = [], p = [], g = [], v = _l(r, e, a), m = _l(o, t, s), y = 0; y < l.length; y++) {
                    var _ = l[y], x = !0;
                    switch (_.cmd) {
                      case "=":
                        var w = t.getItemLayout(_.idx), b = e.getItemLayout(_.idx1);
                        (isNaN(w[0]) || isNaN(w[1])) && (w = b.slice()), h.push(w), u.push(b), c.push(n[_.idx]), 
                        d.push(i[_.idx1]), g.push(e.getRawIndex(_.idx1));
                        break;

                      case "+":
                        var S = _.idx;
                        h.push(r.dataToPoint([ e.get(v.dataDimsForPoint[0], S), e.get(v.dataDimsForPoint[1], S) ])), 
                        u.push(e.getItemLayout(S).slice()), c.push(xl(v, r, e, S)), d.push(i[S]), g.push(e.getRawIndex(S));
                        break;

                      case "-":
                        S = _.idx;
                        var M = t.getRawIndex(S);
                        M !== S ? (h.push(t.getItemLayout(S)), u.push(o.dataToPoint([ t.get(m.dataDimsForPoint[0], S), t.get(m.dataDimsForPoint[1], S) ])), 
                        c.push(n[S]), d.push(xl(m, o, t, S)), g.push(M)) : x = !1;
                    }
                    x && (f.push(_), p.push(p.length));
                }
                p.sort(function(t, e) {
                    return g[t] - g[e];
                });
                var I = [], T = [], C = [], A = [], D = [];
                for (y = 0; y < p.length; y++) {
                    S = p[y];
                    I[y] = h[S], T[y] = u[S], C[y] = c[S], A[y] = d[S], D[y] = f[S];
                }
                return {
                    current: I,
                    next: T,
                    stackedOnCurrent: C,
                    stackedOnNext: A,
                    status: D
                };
            }(this._data, t, this._stackedOnPoints, e, this._coordSys, n, this._valueOrigin, o), u = h.current, c = h.stackedOnCurrent, d = h.next, f = h.stackedOnNext;
            if (r && (u = Dl(h.current, n, r), c = Dl(h.stackedOnCurrent, n, r), d = Dl(h.next, n, r), 
            f = Dl(h.stackedOnNext, n, r)), Cl(u, d) > 3e3 || s && Cl(c, f) > 3e3) return a.setShape({
                points: d
            }), void (s && s.setShape({
                points: d,
                stackedOnPoints: f
            }));
            a.shape.__points = h.current, a.shape.points = u, Wi(a, {
                shape: {
                    points: d
                }
            }, l), s && (s.setShape({
                points: u,
                stackedOnPoints: c
            }), Wi(s, {
                shape: {
                    points: d,
                    stackedOnPoints: f
                }
            }, l));
            for (var p = [], g = h.status, v = 0; v < g.length; v++) {
                if ("=" === g[v].cmd) {
                    var m = t.getItemGraphicEl(g[v].idx1);
                    m && p.push({
                        el: m,
                        ptIdx: v
                    });
                }
            }
            a.animators && a.animators.length && a.animators[0].during(function() {
                for (var t = 0; t < p.length; t++) {
                    p[t].el.attr("position", a.shape.__points[p[t].ptIdx]);
                }
            });
        },
        remove: function() {
            var t = this.group, e = this._data;
            this._lineGroup.removeAll(), this._symbolDraw.remove(!0), e && e.eachItemGraphicEl(function(n, i) {
                n.__temp && (t.remove(n), e.setItemGraphicEl(i, null));
            }), this._polyline = this._polygon = this._coordSys = this._points = this._stackedOnPoints = this._data = null;
        }
    });
    var ay = {
        average: function(t) {
            for (var e = 0, n = 0, i = 0; i < t.length; i++) isNaN(t[i]) || (e += t[i], n++);
            return 0 === n ? NaN : e / n;
        },
        sum: function(t) {
            for (var e = 0, n = 0; n < t.length; n++) e += t[n] || 0;
            return e;
        },
        max: function(t) {
            for (var e = -1 / 0, n = 0; n < t.length; n++) t[n] > e && (e = t[n]);
            return isFinite(e) ? e : NaN;
        },
        min: function(t) {
            for (var e = 1 / 0, n = 0; n < t.length; n++) t[n] < e && (e = t[n]);
            return isFinite(e) ? e : NaN;
        },
        nearest: function(t) {
            return t[0];
        }
    }, sy = function(t) {
        return Math.round(t.length / 2);
    };
    pa(function(t, e, n) {
        return {
            seriesType: t,
            performRawSeries: !0,
            reset: function(t, i) {
                var r = t.getData(), o = t.get("symbol"), a = t.get("symbolSize"), s = t.get("symbolKeepAspect"), l = t.get("symbolRotate"), h = x(o), u = x(a), c = x(l), d = h || u || c, f = !h && o ? o : e, p = u ? null : a;
                return r.setVisual({
                    legendSymbol: n || f,
                    symbol: f,
                    symbolSize: p,
                    symbolKeepAspect: s,
                    symbolRotate: l
                }), i.isSeriesFiltered(t) ? void 0 : {
                    dataEach: r.hasItemOption || d ? function(e, n) {
                        if (d) {
                            var i = t.getRawValue(n), r = t.getDataParams(n);
                            h && e.setItemVisual(n, "symbol", o(i, r)), u && e.setItemVisual(n, "symbolSize", a(i, r)), 
                            c && e.setItemVisual(n, "symbolRotate", l(i, r));
                        }
                        if (e.hasItemOption) {
                            var s = e.getItemModel(n), f = s.getShallow("symbol", !0), p = s.getShallow("symbolSize", !0), g = s.getShallow("symbolRotate", !0), v = s.getShallow("symbolKeepAspect", !0);
                            null != f && e.setItemVisual(n, "symbol", f), null != p && e.setItemVisual(n, "symbolSize", p), 
                            null != g && e.setItemVisual(n, "symbolRotate", g), null != v && e.setItemVisual(n, "symbolKeepAspect", v);
                        }
                    } : null
                };
            }
        };
    }("line", "circle", "line")), fa(function(t) {
        return {
            seriesType: t,
            plan: Xp(),
            reset: function(t) {
                var e = t.getData(), n = t.coordinateSystem, i = t.pipelineContext.large;
                if (n) {
                    var r = p(n.dimensions, function(t) {
                        return e.mapDimension(t);
                    }).slice(0, 2), o = r.length, a = e.getCalculationInfo("stackResultDimension");
                    return Xa(e, r[0]) && (r[0] = a), Xa(e, r[1]) && (r[1] = a), o && {
                        progress: function(t, e) {
                            for (var a = t.end - t.start, s = i && new Float32Array(a * o), l = t.start, h = 0, u = [], c = []; l < t.end; l++) {
                                var d;
                                if (1 === o) {
                                    var f = e.get(r[0], l);
                                    d = !isNaN(f) && n.dataToPoint(f, null, c);
                                } else {
                                    f = u[0] = e.get(r[0], l);
                                    var p = u[1] = e.get(r[1], l);
                                    d = !isNaN(f) && !isNaN(p) && n.dataToPoint(u, null, c);
                                }
                                i ? (s[h++] = d ? d[0] : NaN, s[h++] = d ? d[1] : NaN) : e.setItemLayout(l, d && d.slice() || [ NaN, NaN ]);
                            }
                            i && e.setLayout("symbolPoints", s);
                        }
                    };
                }
            }
        };
    }("line")), ca(Bg.PROCESSOR.STATISTIC, function(t) {
        return {
            seriesType: t,
            modifyOutputEnd: !0,
            reset: function(t) {
                var e = t.getData(), n = t.get("sampling"), i = t.coordinateSystem;
                if ("cartesian2d" === i.type && n) {
                    var r, o = i.getBaseAxis(), a = i.getOtherAxis(o), s = o.getExtent(), l = Math.abs(s[1] - s[0]), h = Math.round(e.count() / l);
                    if (h > 1) "string" == typeof n ? r = ay[n] : "function" == typeof n && (r = n), 
                    r && t.setData(e.downSample(e.mapDimension(a.dim), 1 / h, r, sy));
                }
            }
        };
    }("line"));
    var ly = {
        updateSelectedMap: function(t) {
            this._targetList = _(t) ? t.slice() : [], this._selectTargetMap = g(t || [], function(t, e) {
                return t.set(e.name, e), t;
            }, N());
        },
        select: function(t, e) {
            var n = null != e ? this._targetList[e] : this._selectTargetMap.get(t);
            "single" === this.get("selectedMode") && this._selectTargetMap.each(function(t) {
                t.selected = !1;
            }), n && (n.selected = !0);
        },
        unSelect: function(t, e) {
            var n = null != e ? this._targetList[e] : this._selectTargetMap.get(t);
            n && (n.selected = !1);
        },
        toggleSelected: function(t, e) {
            var n = null != e ? this._targetList[e] : this._selectTargetMap.get(t);
            return null != n ? (this[n.selected ? "unSelect" : "select"](t, e), n.selected) : void 0;
        },
        isSelected: function(t, e) {
            var n = null != e ? this._targetList[e] : this._selectTargetMap.get(t);
            return n && n.selected;
        }
    }, hy = _a({
        type: "series.pie",
        init: function(t) {
            hy.superApply(this, "init", arguments), this.legendVisualProvider = new Ol(m(this.getData, this), m(this.getRawData, this)), 
            this.updateSelectedMap(this._createSelectableList()), this._defaultLabelLine(t);
        },
        mergeOption: function(t) {
            hy.superCall(this, "mergeOption", t), this.updateSelectedMap(this._createSelectableList());
        },
        getInitialData: function() {
            return function(t, e, n) {
                e = _(e) && {
                    coordDimensions: e
                } || a({}, e);
                var i = t.getSource(), r = vv(i, e), o = new fv(r, t);
                return o.initData(i, n), o;
            }(this, {
                coordDimensions: [ "value" ],
                encodeDefaulter: y(Dr, this)
            });
        },
        _createSelectableList: function() {
            for (var t = this.getRawData(), e = t.mapDimension("value"), n = [], i = 0, r = t.count(); r > i; i++) n.push({
                name: t.getName(i),
                value: t.get(e, i),
                selected: oo(t, i, "selected")
            });
            return n;
        },
        getDataParams: function(t) {
            var e = this.getData(), n = hy.superCall(this, "getDataParams", t), i = [];
            return e.each(e.mapDimension("value"), function(t) {
                i.push(t);
            }), n.percent = or(i, t, e.hostModel.get("percentPrecision")), n.$vars.push("percent"), 
            n;
        },
        _defaultLabelLine: function(t) {
            fn(t, "labelLine", [ "show" ]);
            var e = t.labelLine, n = t.emphasis.labelLine;
            e.show = e.show && t.label.show, n.show = n.show && t.emphasis.label.show;
        },
        defaultOption: {
            zlevel: 0,
            z: 2,
            legendHoverLink: !0,
            hoverAnimation: !0,
            center: [ "50%", "50%" ],
            radius: [ 0, "75%" ],
            clockwise: !0,
            startAngle: 90,
            minAngle: 0,
            minShowLabelAngle: 0,
            selectedOffset: 10,
            hoverOffset: 10,
            avoidLabelOverlap: !0,
            percentPrecision: 2,
            stillShowZeroSum: !0,
            left: 0,
            top: 0,
            right: 0,
            bottom: 0,
            width: null,
            height: null,
            label: {
                rotate: !1,
                show: !0,
                position: "outer",
                alignTo: "none",
                margin: "25%",
                bleedMargin: 10,
                distanceToLabelLine: 5
            },
            labelLine: {
                show: !0,
                length: 15,
                length2: 15,
                smooth: !1,
                lineStyle: {
                    width: 1,
                    type: "solid"
                }
            },
            itemStyle: {
                borderWidth: 1
            },
            animationType: "expansion",
            animationTypeUpdate: "transition",
            animationEasing: "cubicOut"
        }
    });
    c(hy, ly);
    var uy = zl.prototype;
    uy.updateData = function(t, e, n) {
        var i = this.childAt(0), r = this.childAt(1), o = this.childAt(2), l = t.hostModel, h = t.getItemModel(e), u = t.getItemLayout(e), c = a({}, u);
        c.label = null;
        var d = l.getShallow("animationTypeUpdate");
        n ? (i.setShape(c), "scale" === l.getShallow("animationType") ? (i.shape.r = u.r0, 
        Xi(i, {
            shape: {
                r: u.r
            }
        }, l, e)) : (i.shape.endAngle = u.startAngle, Wi(i, {
            shape: {
                endAngle: u.endAngle
            }
        }, l, e))) : "expansion" === d ? i.setShape(c) : Wi(i, {
            shape: c
        }, l, e);
        var f = t.getItemVisual(e, "color");
        i.useStyle(s({
            lineJoin: "bevel",
            fill: f
        }, h.getModel("itemStyle").getItemStyle())), i.hoverStyle = h.getModel("emphasis.itemStyle").getItemStyle();
        var p = h.getShallow("cursor");
        p && i.attr("cursor", p), Bl(this, t.getItemLayout(e), l.isSelected(t.getName(e)), l.get("selectedOffset"), l.get("animation"));
        var g = !n && "transition" === d;
        this._updateLabel(t, e, g), this.highDownOnUpdate = l.get("silent") ? null : function(t, e) {
            var n = l.isAnimationEnabled() && h.get("hoverAnimation");
            "emphasis" === e ? (r.ignore = r.hoverIgnore, o.ignore = o.hoverIgnore, n && (i.stopAnimation(!0), 
            i.animateTo({
                shape: {
                    r: u.r + l.get("hoverOffset")
                }
            }, 300, "elasticOut"))) : (r.ignore = r.normalIgnore, o.ignore = o.normalIgnore, 
            n && (i.stopAnimation(!0), i.animateTo({
                shape: {
                    r: u.r
                }
            }, 300, "elasticOut")));
        }, ki(this);
    }, uy._updateLabel = function(t, e, n) {
        var i = this.childAt(1), r = this.childAt(2), o = t.hostModel, a = t.getItemModel(e), s = t.getItemLayout(e).label, l = t.getItemVisual(e, "color");
        if (!s || isNaN(s.x) || isNaN(s.y)) r.ignore = r.normalIgnore = r.hoverIgnore = i.ignore = i.normalIgnore = i.hoverIgnore = !0; else {
            var h = {
                points: s.linePoints || [ [ s.x, s.y ], [ s.x, s.y ], [ s.x, s.y ] ]
            }, u = {
                x: s.x,
                y: s.y
            };
            n ? (Wi(i, {
                shape: h
            }, o, e), Wi(r, {
                style: u
            }, o, e)) : (i.attr({
                shape: h
            }), r.attr({
                style: u
            })), r.attr({
                rotation: s.rotation,
                origin: [ s.x, s.y ],
                z2: 10
            });
            var c = a.getModel("label"), d = a.getModel("emphasis.label"), f = a.getModel("labelLine"), p = a.getModel("emphasis.labelLine");
            l = t.getItemVisual(e, "color");
            Ei(r.style, r.hoverStyle = {}, c, d, {
                labelFetcher: t.hostModel,
                labelDataIndex: e,
                defaultText: s.text,
                autoColor: l,
                useInsideStyle: !!s.inside
            }, {
                textAlign: s.textAlign,
                textVerticalAlign: s.verticalAlign,
                opacity: t.getItemVisual(e, "opacity")
            }), r.ignore = r.normalIgnore = !c.get("show"), r.hoverIgnore = !d.get("show"), 
            i.ignore = i.normalIgnore = !f.get("show"), i.hoverIgnore = !p.get("show"), i.setStyle({
                stroke: l,
                opacity: t.getItemVisual(e, "opacity")
            }), i.setStyle(f.getModel("lineStyle").getLineStyle()), i.hoverStyle = p.getModel("lineStyle").getLineStyle();
            var g = f.get("smooth");
            g && !0 === g && (g = .4), i.setShape({
                smooth: g
            });
        }
    }, u(zl, Nu);
    var cy = (mo.extend({
        type: "pie",
        init: function() {
            var t = new Nu();
            this._sectorGroup = t;
        },
        render: function(t, e, n, i) {
            if (!i || i.from !== this.uid) {
                var r = t.getData(), o = this._data, a = this.group, s = e.get("animation"), l = !o, h = t.get("animationType"), u = t.get("animationTypeUpdate"), c = y(El, this.uid, t, s, n), d = t.get("selectedMode");
                if (r.diff(o).add(function(t) {
                    var e = new zl(r, t);
                    l && "scale" !== h && e.eachChild(function(t) {
                        t.stopAnimation(!0);
                    }), d && e.on("click", c), r.setItemGraphicEl(t, e), a.add(e);
                }).update(function(t, e) {
                    var n = o.getItemGraphicEl(e);
                    l || "transition" === u || n.eachChild(function(t) {
                        t.stopAnimation(!0);
                    }), n.updateData(r, t), n.off("click"), d && n.on("click", c), a.add(n), r.setItemGraphicEl(t, n);
                }).remove(function(t) {
                    var e = o.getItemGraphicEl(t);
                    a.remove(e);
                }).execute(), s && r.count() > 0 && (l ? "scale" !== h : "transition" !== u)) {
                    for (var f = r.getItemLayout(0), p = 1; isNaN(f.startAngle) && p < r.count(); ++p) f = r.getItemLayout(p);
                    var g = Math.max(n.getWidth(), n.getHeight()) / 2, v = m(a.removeClipPath, a);
                    a.setClipPath(this._createClipPath(f.cx, f.cy, g, f.startAngle, f.clockwise, v, t, l));
                } else a.removeClipPath();
                this._data = r;
            }
        },
        dispose: function() {},
        _createClipPath: function(t, e, n, i, r, o, a, s) {
            var l = new Qd({
                shape: {
                    cx: t,
                    cy: e,
                    r0: 0,
                    r: n,
                    startAngle: i,
                    endAngle: i,
                    clockwise: r
                }
            });
            return (s ? Xi : Wi)(l, {
                shape: {
                    endAngle: i + (r ? 1 : -1) * Math.PI * 2
                }
            }, a, o), l;
        },
        containPoint: function(t, e) {
            var n = e.getData().getItemLayout(0);
            if (n) {
                var i = t[0] - n.cx, r = t[1] - n.cy, o = Math.sqrt(i * i + r * r);
                return o <= n.r && o >= n.r0;
            }
        }
    }), function(t, e) {
        f(e, function(e) {
            e.update = "updateView", da(e, function(n, i) {
                var r = {};
                return i.eachComponent({
                    mainType: "series",
                    subType: t,
                    query: n
                }, function(t) {
                    t[e.method] && t[e.method](n.name, n.dataIndex);
                    var i = t.getData();
                    i.each(function(e) {
                        var n = i.getName(e);
                        r[n] = t.isSelected(n) || !1;
                    });
                }), {
                    name: n.name,
                    selected: r,
                    seriesId: n.seriesId
                };
            });
        });
    }), dy = Math.PI / 180, fy = function(t, e, n, i, r, o) {
        var a, s, l = t.getData(), h = [], u = !1, c = (t.get("minShowLabelAngle") || 0) * dy;
        l.each(function(i) {
            var o = l.getItemLayout(i), d = l.getItemModel(i), f = d.getModel("label"), p = f.get("position") || d.get("emphasis.label.position"), g = f.get("distanceToLabelLine"), v = f.get("alignTo"), m = er(f.get("margin"), n), y = f.get("bleedMargin"), _ = f.getFont(), x = d.getModel("labelLine"), w = x.get("length");
            w = er(w, n);
            var b = x.get("length2");
            if (b = er(b, n), !(o.angle < c)) {
                var S, M, I, T, C = (o.startAngle + o.endAngle) / 2, A = Math.cos(C), D = Math.sin(C);
                a = o.cx, s = o.cy;
                var k = t.getFormattedLabel(i, "normal") || l.getName(i), P = xe(k, _, T, "top"), L = "inside" === p || "inner" === p;
                if ("center" === p) S = o.cx, M = o.cy, T = "center"; else {
                    var O = (L ? (o.r + o.r0) / 2 * A : o.r * A) + a, E = (L ? (o.r + o.r0) / 2 * D : o.r * D) + s;
                    if (S = O + 3 * A, M = E + 3 * D, !L) {
                        var B = O + A * (w + e - o.r), z = E + D * (w + e - o.r), N = B + (0 > A ? -1 : 1) * b;
                        S = "edge" === v ? 0 > A ? r + m : r + n - m : N + (0 > A ? -g : g), M = z, I = [ [ O, E ], [ B, z ], [ N, z ] ];
                    }
                    T = L ? "center" : "edge" === v ? A > 0 ? "right" : "left" : A > 0 ? "left" : "right";
                }
                var R, F = f.get("rotate");
                R = "number" == typeof F ? F * (Math.PI / 180) : F ? 0 > A ? -C + Math.PI : -C : 0, 
                u = !!R, o.label = {
                    x: S,
                    y: M,
                    position: p,
                    height: P.height,
                    len: w,
                    len2: b,
                    linePoints: I,
                    textAlign: T,
                    verticalAlign: "middle",
                    rotation: R,
                    inside: L,
                    labelDistance: g,
                    labelAlignTo: v,
                    labelMargin: m,
                    bleedMargin: y,
                    textRect: P,
                    text: k,
                    font: _
                }, L || h.push(o.label);
            }
        }), !u && t.get("avoidLabelOverlap") && function(t, e, n, i, r, o, a, s) {
            for (var l = [], h = [], u = Number.MAX_VALUE, c = -Number.MAX_VALUE, d = 0; d < t.length; d++) Rl(t[d]) || (t[d].x < e ? (u = Math.min(u, t[d].x), 
            l.push(t[d])) : (c = Math.max(c, t[d].x), h.push(t[d])));
            for (Nl(h, e, n, i, 1, 0, o, 0, s, c), Nl(l, e, n, i, -1, 0, o, 0, s, u), d = 0; d < t.length; d++) {
                var f = t[d];
                if (!Rl(f)) {
                    var p = f.linePoints;
                    if (p) {
                        var g, v = "edge" === f.labelAlignTo, m = f.textRect.width;
                        (g = v ? f.x < e ? p[2][0] - f.labelDistance - a - f.labelMargin : a + r - f.labelMargin - p[2][0] - f.labelDistance : f.x < e ? f.x - a - f.bleedMargin : a + r - f.x - f.bleedMargin) < f.textRect.width && (f.text = Me(f.text, g, f.font), 
                        "edge" === f.labelAlignTo && (m = _e(f.text, f.font)));
                        var y = p[1][0] - p[2][0];
                        v ? p[2][0] = f.x < e ? a + f.labelMargin + m + f.labelDistance : a + r - f.labelMargin - m - f.labelDistance : (p[2][0] = f.x < e ? f.x + f.labelDistance : f.x - f.labelDistance, 
                        p[1][0] = p[2][0] + y), p[1][1] = p[2][1] = f.y;
                    }
                }
            }
        }(h, a, s, e, n, i, r, o);
    }, py = 2 * Math.PI, gy = Math.PI / 180;
    cy("pie", [ {
        type: "pieToggleSelect",
        event: "pieselectchanged",
        method: "toggleSelected"
    }, {
        type: "pieSelect",
        event: "pieselected",
        method: "select"
    }, {
        type: "pieUnSelect",
        event: "pieunselected",
        method: "unSelect"
    } ]), pa(function(t) {
        return {
            getTargetSeries: function(e) {
                var n = {}, i = N();
                return e.eachSeriesByType(t, function(t) {
                    t.__paletteScope = n, i.set(t.uid, t);
                }), i;
            },
            reset: function(t) {
                var e = t.getRawData(), n = {}, i = t.getData();
                i.each(function(t) {
                    var e = i.getRawIndex(t);
                    n[e] = t;
                }), e.each(function(r) {
                    var o, a = n[r], s = null != a && i.getItemVisual(a, "color", !0), l = null != a && i.getItemVisual(a, "borderColor", !0);
                    if (s && l || (o = e.getItemModel(r)), !s) {
                        var h = o.get("itemStyle.color") || t.getColorFromPalette(e.getName(r) || r + "", t.__paletteScope, e.count());
                        null != a && i.setItemVisual(a, "color", h);
                    }
                    if (!l) {
                        var u = o.get("itemStyle.borderColor");
                        null != a && i.setItemVisual(a, "borderColor", u);
                    }
                });
            }
        };
    }("pie")), fa(y(function(t, e, n) {
        e.eachSeriesByType(t, function(t) {
            var e = t.getData(), i = e.mapDimension("value"), r = function(t, e) {
                return wr(t.getBoxLayoutParams(), {
                    width: e.getWidth(),
                    height: e.getHeight()
                });
            }(t, n), o = t.get("center"), a = t.get("radius");
            _(a) || (a = [ 0, a ]), _(o) || (o = [ o, o ]);
            var s = er(r.width, n.getWidth()), l = er(r.height, n.getHeight()), h = Math.min(s, l), u = er(o[0], s) + r.x, c = er(o[1], l) + r.y, d = er(a[0], h / 2), f = er(a[1], h / 2), p = -t.get("startAngle") * gy, g = t.get("minAngle") * gy, v = 0;
            e.each(i, function(t) {
                !isNaN(t) && v++;
            });
            var m = e.getSum(i), y = Math.PI / (m || v) * 2, x = t.get("clockwise"), w = t.get("roseType"), b = t.get("stillShowZeroSum"), S = e.getDataExtent(i);
            S[0] = 0;
            var M = py, I = 0, T = p, C = x ? 1 : -1;
            if (e.each(i, function(t, n) {
                var i;
                if (isNaN(t)) e.setItemLayout(n, {
                    angle: NaN,
                    startAngle: NaN,
                    endAngle: NaN,
                    clockwise: x,
                    cx: u,
                    cy: c,
                    r0: d,
                    r: w ? NaN : f,
                    viewRect: r
                }); else {
                    g > (i = "area" !== w ? 0 === m && b ? y : t * y : py / v) ? (i = g, M -= g) : I += t;
                    var o = T + C * i;
                    e.setItemLayout(n, {
                        angle: i,
                        startAngle: T,
                        endAngle: o,
                        clockwise: x,
                        cx: u,
                        cy: c,
                        r0: d,
                        r: w ? tr(t, S, [ d, f ]) : f,
                        viewRect: r
                    }), T = o;
                }
            }), py > M && v) if (.001 >= M) {
                var A = py / v;
                e.each(i, function(t, n) {
                    if (!isNaN(t)) {
                        var i = e.getItemLayout(n);
                        i.angle = A, i.startAngle = p + C * n * A, i.endAngle = p + C * (n + 1) * A;
                    }
                });
            } else y = M / I, T = p, e.each(i, function(t, n) {
                if (!isNaN(t)) {
                    var i = e.getItemLayout(n), r = i.angle === g ? g : t * y;
                    i.startAngle = T, i.endAngle = T + C * r, T += C * r;
                }
            });
            fy(t, f, r.width, r.height, r.x, r.y);
        });
    }, "pie")), ca(function(t) {
        return {
            seriesType: t,
            reset: function(t, e) {
                var n = e.findComponents({
                    mainType: "legend"
                });
                if (n && n.length) {
                    var i = t.getData();
                    i.filterSelf(function(t) {
                        for (var e = i.getName(t), r = 0; r < n.length; r++) if (!n[r].isSelected(e)) return !1;
                        return !0;
                    });
                }
            }
        };
    }("pie")), ma({
        type: "title",
        layoutMode: {
            type: "box",
            ignoreSize: !0
        },
        defaultOption: {
            zlevel: 0,
            z: 6,
            show: !0,
            text: "",
            target: "blank",
            subtext: "",
            subtarget: "blank",
            left: 0,
            top: 0,
            backgroundColor: "rgba(0,0,0,0)",
            borderColor: "#ccc",
            borderWidth: 0,
            padding: 5,
            itemGap: 10,
            textStyle: {
                fontSize: 18,
                fontWeight: "bolder",
                color: "#333"
            },
            subtextStyle: {
                color: "#aaa"
            }
        }
    }), ya({
        type: "title",
        render: function(t, e, n) {
            if (this.group.removeAll(), t.get("show")) {
                var i = this.group, r = t.getModel("textStyle"), o = t.getModel("subtextStyle"), a = t.get("textAlign"), s = A(t.get("textBaseline"), t.get("textVerticalAlign")), l = new jd({
                    style: Bi({}, r, {
                        text: t.get("text"),
                        textFill: r.getTextColor()
                    }, {
                        disableBox: !0
                    }),
                    z2: 10
                }), h = l.getBoundingRect(), u = t.get("subtext"), c = new jd({
                    style: Bi({}, o, {
                        text: u,
                        textFill: o.getTextColor(),
                        y: h.height + t.get("itemGap"),
                        textVerticalAlign: "top"
                    }, {
                        disableBox: !0
                    }),
                    z2: 10
                }), d = t.get("link"), f = t.get("sublink"), p = t.get("triggerEvent", !0);
                l.silent = !d && !p, c.silent = !f && !p, d && l.on("click", function() {
                    _r(d, "_" + t.get("target"));
                }), f && c.on("click", function() {
                    _r(f, "_" + t.get("subtarget"));
                }), l.eventData = c.eventData = p ? {
                    componentType: "title",
                    componentIndex: t.componentIndex
                } : null, i.add(l), u && i.add(c);
                var g = i.getBoundingRect(), v = t.getBoxLayoutParams();
                v.width = g.width, v.height = g.height;
                var m = wr(v, {
                    width: n.getWidth(),
                    height: n.getHeight()
                }, t.get("padding"));
                a || ("middle" === (a = t.get("left") || t.get("right")) && (a = "center"), "right" === a ? m.x += m.width : "center" === a && (m.x += m.width / 2)), 
                s || ("center" === (s = t.get("top") || t.get("bottom")) && (s = "middle"), "bottom" === s ? m.y += m.height : "middle" === s && (m.y += m.height / 2), 
                s = s || "top"), i.attr("position", [ m.x, m.y ]);
                var y = {
                    textAlign: a,
                    textVerticalAlign: s
                };
                l.setStyle(y), c.setStyle(y), g = i.getBoundingRect();
                var _ = m.margin, x = t.getItemStyle([ "color", "opacity" ]);
                x.fill = t.get("backgroundColor");
                var w = new sf({
                    shape: {
                        x: g.x - _[3],
                        y: g.y - _[0],
                        width: g.width + _[1] + _[3],
                        height: g.height + _[0] + _[2],
                        r: t.get("borderRadius")
                    },
                    style: x,
                    subPixelOptimize: !0,
                    silent: !0
                });
                i.add(w);
            }
        }
    });
    var vy = Jp.legend.selector, my = {
        all: {
            type: "all",
            title: i(vy.all)
        },
        inverse: {
            type: "inverse",
            title: i(vy.inverse)
        }
    }, yy = ma({
        type: "legend.plain",
        dependencies: [ "series" ],
        layoutMode: {
            type: "box",
            ignoreSize: !0
        },
        init: function(t, e, n) {
            this.mergeDefaultAndTheme(t, n), t.selected = t.selected || {}, this._updateSelector(t);
        },
        mergeOption: function(t) {
            yy.superCall(this, "mergeOption", t), this._updateSelector(t);
        },
        _updateSelector: function(t) {
            var e = t.selector;
            !0 === e && (e = t.selector = [ "all", "inverse" ]), _(e) && f(e, function(t, n) {
                w(t) && (t = {
                    type: t
                }), e[n] = r(t, my[t.type]);
            });
        },
        optionUpdated: function() {
            this._updateData(this.ecModel);
            var t = this._data;
            if (t[0] && "single" === this.get("selectedMode")) {
                for (var e = !1, n = 0; n < t.length; n++) {
                    var i = t[n].get("name");
                    if (this.isSelected(i)) {
                        this.select(i), e = !0;
                        break;
                    }
                }
                !e && this.select(t[0].get("name"));
            }
        },
        _updateData: function(t) {
            var e = [], n = [];
            t.eachRawSeries(function(i) {
                var r, o = i.name;
                if (n.push(o), i.legendVisualProvider) {
                    var a = i.legendVisualProvider.getAllNames();
                    t.isSeriesFiltered(i) || (n = n.concat(a)), a.length ? e = e.concat(a) : r = !0;
                } else r = !0;
                r && vn(i) && e.push(i.name);
            }), this._availableNames = n;
            var i = p(this.get("data") || e, function(t) {
                return ("string" == typeof t || "number" == typeof t) && (t = {
                    name: t
                }), new Ki(t, this, this.ecModel);
            }, this);
            this._data = i;
        },
        getData: function() {
            return this._data;
        },
        select: function(t) {
            var e = this.option.selected;
            "single" === this.get("selectedMode") && f(this._data, function(t) {
                e[t.get("name")] = !1;
            });
            e[t] = !0;
        },
        unSelect: function(t) {
            "single" !== this.get("selectedMode") && (this.option.selected[t] = !1);
        },
        toggleSelected: function(t) {
            var e = this.option.selected;
            e.hasOwnProperty(t) || (e[t] = !0), this[e[t] ? "unSelect" : "select"](t);
        },
        allSelect: function() {
            var t = this._data, e = this.option.selected;
            f(t, function(t) {
                e[t.get("name", !0)] = !0;
            });
        },
        inverseSelect: function() {
            var t = this._data, e = this.option.selected;
            f(t, function(t) {
                var n = t.get("name", !0);
                e.hasOwnProperty(n) || (e[n] = !0), e[n] = !e[n];
            });
        },
        isSelected: function(t) {
            var e = this.option.selected;
            return !(e.hasOwnProperty(t) && !e[t]) && h(this._availableNames, t) >= 0;
        },
        getOrient: function() {
            return "vertical" === this.get("orient") ? {
                index: 1,
                name: "vertical"
            } : {
                index: 0,
                name: "horizontal"
            };
        },
        defaultOption: {
            zlevel: 0,
            z: 4,
            show: !0,
            orient: "horizontal",
            left: "center",
            top: 0,
            align: "auto",
            backgroundColor: "rgba(0,0,0,0)",
            borderColor: "#ccc",
            borderRadius: 0,
            borderWidth: 0,
            padding: 5,
            itemGap: 10,
            itemWidth: 25,
            itemHeight: 14,
            inactiveColor: "#ccc",
            inactiveBorderColor: "#ccc",
            itemStyle: {
                borderWidth: 0
            },
            textStyle: {
                color: "#333"
            },
            selectedMode: !0,
            selector: !1,
            selectorLabel: {
                show: !0,
                borderRadius: 10,
                padding: [ 3, 5, 3, 5 ],
                fontSize: 12,
                fontFamily: " sans-serif",
                color: "#666",
                borderWidth: 1,
                borderColor: "#666"
            },
            emphasis: {
                selectorLabel: {
                    show: !0,
                    color: "#eee",
                    backgroundColor: "#666"
                }
            },
            selectorPosition: "auto",
            selectorItemGap: 7,
            selectorButtonGap: 10,
            tooltip: {
                show: !1
            }
        }
    });
    da("legendToggleSelect", "legendselectchanged", y(Fl, "toggleSelected")), da("legendAllSelect", "legendselectall", y(Fl, "allSelect")), 
    da("legendInverseSelect", "legendinverseselect", y(Fl, "inverseSelect")), da("legendSelect", "legendselected", y(Fl, "select")), 
    da("legendUnSelect", "legendunselected", y(Fl, "unSelect"));
    var _y = y, xy = f, wy = Nu, by = ya({
        type: "legend.plain",
        newlineDisabled: !1,
        init: function() {
            this.group.add(this._contentGroup = new wy()), this._backgroundEl, this.group.add(this._selectorGroup = new wy()), 
            this._isFirstRender = !0;
        },
        getContentGroup: function() {
            return this._contentGroup;
        },
        getSelectorGroup: function() {
            return this._selectorGroup;
        },
        render: function(t, e, n) {
            var i = this._isFirstRender;
            if (this._isFirstRender = !1, this.resetInner(), t.get("show", !0)) {
                var r = t.get("align"), o = t.get("orient");
                r && "auto" !== r || (r = "right" === t.get("left") && "vertical" === o ? "right" : "left");
                var a = t.get("selector", !0), l = t.get("selectorPosition", !0);
                !a || l && "auto" !== l || (l = "horizontal" === o ? "end" : "start"), this.renderInner(r, t, e, n, a, o, l);
                var h = t.getBoxLayoutParams(), u = {
                    width: n.getWidth(),
                    height: n.getHeight()
                }, c = t.get("padding"), d = wr(h, u, c), f = this.layoutInner(t, r, d, i, a, l), p = wr(s({
                    width: f.width,
                    height: f.height
                }, h), u, c);
                this.group.attr("position", [ p.x - f.x, p.y - f.y ]), this.group.add(this._backgroundEl = function(t, e) {
                    var n = Gf(e.get("padding")), i = e.getItemStyle([ "color", "opacity" ]);
                    return i.fill = e.get("backgroundColor"), t = new sf({
                        shape: {
                            x: t.x - n[3],
                            y: t.y - n[0],
                            width: t.width + n[1] + n[3],
                            height: t.height + n[0] + n[2],
                            r: e.get("borderRadius")
                        },
                        style: i,
                        silent: !0,
                        z2: -1
                    });
                }(f, t));
            }
        },
        resetInner: function() {
            this.getContentGroup().removeAll(), this._backgroundEl && this.group.remove(this._backgroundEl), 
            this.getSelectorGroup().removeAll();
        },
        renderInner: function(t, e, n, i, r, o, a) {
            var s = this.getContentGroup(), l = N(), h = e.get("selectedMode"), u = [];
            n.eachRawSeries(function(t) {
                !t.get("legendHoverLink") && u.push(t.id);
            }), xy(e.getData(), function(r, o) {
                var a = r.get("name");
                if (this.newlineDisabled || "" !== a && "\n" !== a) {
                    var c = n.getSeriesByName(a)[0];
                    if (!l.get(a)) {
                        if (c) {
                            var d = c.getData(), f = d.getVisual("color"), p = d.getVisual("borderColor");
                            "function" == typeof f && (f = f(c.getDataParams(0))), "function" == typeof p && (p = p(c.getDataParams(0)));
                            var g = d.getVisual("legendSymbol") || "roundRect", v = d.getVisual("symbol");
                            this._createItem(a, o, r, e, g, v, t, f, p, h).on("click", _y(Hl, a, null, i, u)).on("mouseover", _y(Gl, c.name, null, i, u)).on("mouseout", _y(Wl, c.name, null, i, u)), 
                            l.set(a, !0);
                        } else n.eachRawSeries(function(n) {
                            if (!l.get(a) && n.legendVisualProvider) {
                                var s = n.legendVisualProvider;
                                if (!s.containName(a)) return;
                                var c = s.indexOfName(a), d = s.getItemVisual(c, "color"), f = s.getItemVisual(c, "borderColor");
                                this._createItem(a, o, r, e, "roundRect", null, t, d, f, h).on("click", _y(Hl, null, a, i, u)).on("mouseover", _y(Gl, null, a, i, u)).on("mouseout", _y(Wl, null, a, i, u)), 
                                l.set(a, !0);
                            }
                        }, this);
                        wh && (l.get(a) || console.warn(a + " series not exists. Legend data should be same with series name or data name."));
                    }
                } else s.add(new wy({
                    newline: !0
                }));
            }, this), r && this._createSelector(r, e, i, o, a);
        },
        _createSelector: function(t, e, n) {
            var i = this.getSelectorGroup();
            xy(t, function(t) {
                !function(t) {
                    var r = t.type, o = new jd({
                        style: {
                            x: 0,
                            y: 0,
                            align: "center",
                            verticalAlign: "middle"
                        },
                        onclick: function() {
                            n.dispatchAction({
                                type: "all" === r ? "legendAllSelect" : "legendInverseSelect"
                            });
                        }
                    });
                    i.add(o);
                    var a = e.getModel("selectorLabel"), s = e.getModel("emphasis.selectorLabel");
                    Ei(o.style, o.hoverStyle = {}, a, s, {
                        defaultText: t.title,
                        isRectText: !1
                    }), ki(o);
                }(t);
            });
        },
        _createItem: function(t, e, n, i, r, o, s, l, h, u) {
            var c = i.get("itemWidth"), d = i.get("itemHeight"), f = i.get("inactiveColor"), p = i.get("inactiveBorderColor"), g = i.get("symbolKeepAspect"), v = i.getModel("itemStyle"), m = i.isSelected(t), y = new wy(), _ = n.getModel("textStyle"), x = n.get("icon"), w = n.getModel("tooltip"), b = w.parentModel, S = ys(r = x || r, 0, 0, c, d, m ? l : f, null == g || g);
            if (y.add(Vl(S, r, v, h, p, m)), !x && o && (o !== r || "none" === o)) {
                var M = .8 * d;
                "none" === o && (o = "circle");
                var I = ys(o, (c - M) / 2, (d - M) / 2, M, M, m ? l : f, null == g || g);
                y.add(Vl(I, o, v, h, p, m));
            }
            var T = "left" === s ? c + 5 : -5, C = s, A = i.get("formatter"), D = t;
            "string" == typeof A && A ? D = A.replace("{name}", null != t ? t : "") : "function" == typeof A && (D = A(t)), 
            y.add(new jd({
                style: Bi({}, _, {
                    text: D,
                    x: T,
                    y: d / 2,
                    textFill: m ? _.getTextColor() : f,
                    textAlign: C,
                    textVerticalAlign: "middle"
                })
            }));
            var k = new sf({
                shape: y.getBoundingRect(),
                invisible: !0,
                tooltip: w.get("show") ? a({
                    content: t,
                    formatter: b.get("formatter", !0) || function() {
                        return t;
                    },
                    formatterParams: {
                        componentType: "legend",
                        legendIndex: i.componentIndex,
                        name: t,
                        $vars: [ "name" ]
                    }
                }, w.option) : null
            });
            return y.add(k), y.eachChild(function(t) {
                t.silent = !0;
            }), k.silent = !u, this.getContentGroup().add(y), ki(y), y.__legendDataIndex = e, 
            y;
        },
        layoutInner: function(t, e, n, i, r, o) {
            var a = this.getContentGroup(), s = this.getSelectorGroup();
            Qf(t.get("orient"), a, t.get("itemGap"), n.width, n.height);
            var l = a.getBoundingRect(), h = [ -l.x, -l.y ];
            if (r) {
                Qf("horizontal", s, t.get("selectorItemGap", !0));
                var u = s.getBoundingRect(), c = [ -u.x, -u.y ], d = t.get("selectorButtonGap", !0), f = t.getOrient().index, p = 0 === f ? "width" : "height", g = 0 === f ? "height" : "width", v = 0 === f ? "y" : "x";
                "end" === o ? c[f] += l[p] + d : h[f] += u[p] + d, c[1 - f] += l[g] / 2 - u[g] / 2, 
                s.attr("position", c), a.attr("position", h);
                var m = {
                    x: 0,
                    y: 0
                };
                return m[p] = l[p] + d + u[p], m[g] = Math.max(l[g], u[g]), m[v] = Math.min(0, u[v] + c[1 - f]), 
                m;
            }
            return a.attr("position", h), this.group.getBoundingRect();
        },
        remove: function() {
            this.getContentGroup().removeAll(), this._isFirstRender = !0;
        }
    });
    ca(Bg.PROCESSOR.SERIES_FILTER, function(t) {
        var e = t.findComponents({
            mainType: "legend"
        });
        e && e.length && t.filterSeries(function(t) {
            for (var n = 0; n < e.length; n++) if (!e[n].isSelected(t.name)) return !1;
            return !0;
        });
    }), ep.registerSubTypeDefaulter("legend", function() {
        return "plain";
    });
    var Sy = yy.extend({
        type: "legend.scroll",
        setScrollDataIndex: function(t) {
            this.option.scrollDataIndex = t;
        },
        defaultOption: {
            scrollDataIndex: 0,
            pageButtonItemGap: 5,
            pageButtonGap: null,
            pageButtonPosition: "end",
            pageFormatter: "{current}/{total}",
            pageIcons: {
                horizontal: [ "M0,0L12,-10L12,10z", "M0,0L-12,-10L-12,10z" ],
                vertical: [ "M0,0L20,0L10,-20z", "M0,0L20,0L10,20z" ]
            },
            pageIconColor: "#2f4554",
            pageIconInactiveColor: "#aaa",
            pageIconSize: 15,
            pageTextStyle: {
                color: "#333"
            },
            animationDurationUpdate: 800
        },
        init: function(t, e, n, i) {
            var r = Sr(t);
            Sy.superCall(this, "init", t, e, n, i), Xl(this, t, r);
        },
        mergeOption: function(t, e) {
            Sy.superCall(this, "mergeOption", t, e), Xl(this, this.option, t);
        }
    }), My = Nu, Iy = [ "width", "height" ], Ty = [ "x", "y" ], Cy = by.extend({
        type: "legend.scroll",
        newlineDisabled: !0,
        init: function() {
            Cy.superCall(this, "init"), this._currentIndex = 0, this.group.add(this._containerGroup = new My()), 
            this._containerGroup.add(this.getContentGroup()), this.group.add(this._controllerGroup = new My()), 
            this._showController;
        },
        resetInner: function() {
            Cy.superCall(this, "resetInner"), this._controllerGroup.removeAll(), this._containerGroup.removeClipPath(), 
            this._containerGroup.__rectSize = null;
        },
        renderInner: function(t, e, n, i, r, o, a) {
            function s(t, n) {
                var r = t + "DataIndex", o = qi(e.get("pageIcons", !0)[e.getOrient().name][n], {
                    onclick: m(l._pageGo, l, r, e, i)
                }, {
                    x: -u[0] / 2,
                    y: -u[1] / 2,
                    width: u[0],
                    height: u[1]
                });
                o.name = t, h.add(o);
            }
            var l = this;
            Cy.superCall(this, "renderInner", t, e, n, i, r, o, a);
            var h = this._controllerGroup, u = e.get("pageIconSize", !0);
            _(u) || (u = [ u, u ]), s("pagePrev", 0);
            var c = e.getModel("pageTextStyle");
            h.add(new jd({
                name: "pageText",
                style: {
                    textFill: c.getTextColor(),
                    font: c.getFont(),
                    textVerticalAlign: "middle",
                    textAlign: "center"
                },
                silent: !0
            })), s("pageNext", 1);
        },
        layoutInner: function(t, e, n, r, o, a) {
            var s = this.getSelectorGroup(), l = t.getOrient().index, h = Iy[l], u = Ty[l], c = Iy[1 - l], d = Ty[1 - l];
            o && Qf("horizontal", s, t.get("selectorItemGap", !0));
            var f = t.get("selectorButtonGap", !0), p = s.getBoundingRect(), g = [ -p.x, -p.y ], v = i(n);
            o && (v[h] = n[h] - p[h] - f);
            var m = this._layoutContentAndController(t, r, v, l, h, c, d);
            if (o) {
                if ("end" === a) g[l] += m[h] + f; else {
                    var y = p[h] + f;
                    g[l] -= y, m[u] -= y;
                }
                m[h] += p[h] + f, g[1 - l] += m[d] + m[c] / 2 - p[c] / 2, m[c] = Math.max(m[c], p[c]), 
                m[d] = Math.min(m[d], p[d] + g[1 - l]), s.attr("position", g);
            }
            return m;
        },
        _layoutContentAndController: function(t, e, n, i, r, o, a) {
            var s = this.getContentGroup(), l = this._containerGroup, h = this._controllerGroup;
            Qf(t.get("orient"), s, t.get("itemGap"), i ? n.width : null, i ? null : n.height), 
            Qf("horizontal", h, t.get("pageButtonItemGap", !0));
            var u = s.getBoundingRect(), c = h.getBoundingRect(), d = this._showController = u[r] > n[r], f = [ -u.x, -u.y ];
            e || (f[i] = s.position[i]);
            var p = [ 0, 0 ], g = [ -c.x, -c.y ], v = A(t.get("pageButtonGap", !0), t.get("itemGap", !0));
            d && ("end" === t.get("pageButtonPosition", !0) ? g[i] += n[r] - c[r] : p[i] += c[r] + v);
            g[1 - i] += u[o] / 2 - c[o] / 2, s.attr("position", f), l.attr("position", p), h.attr("position", g);
            var m = {
                x: 0,
                y: 0
            };
            if (m[r] = d ? n[r] : u[r], m[o] = Math.max(u[o], c[o]), m[a] = Math.min(0, c[a] + g[1 - i]), 
            l.__rectSize = n[r], d) {
                var y = {
                    x: 0,
                    y: 0
                };
                y[r] = Math.max(n[r] - c[r] - v, 0), y[o] = m[o], l.setClipPath(new sf({
                    shape: y
                })), l.__rectSize = y[r];
            } else h.eachChild(function(t) {
                t.attr({
                    invisible: !0,
                    silent: !0
                });
            });
            var _ = this._getPageInfo(t);
            return null != _.pageIndex && Wi(s, {
                position: _.contentPosition
            }, !!d && t), this._updatePageInfoView(t, _), m;
        },
        _pageGo: function(t, e, n) {
            var i = this._getPageInfo(e)[t];
            null != i && n.dispatchAction({
                type: "legendScroll",
                scrollDataIndex: i,
                legendId: e.id
            });
        },
        _updatePageInfoView: function(t, e) {
            var n = this._controllerGroup;
            f([ "pagePrev", "pageNext" ], function(i) {
                var r = null != e[i + "DataIndex"], o = n.childOfName(i);
                o && (o.setStyle("fill", r ? t.get("pageIconColor", !0) : t.get("pageIconInactiveColor", !0)), 
                o.cursor = r ? "pointer" : "default");
            });
            var i = n.childOfName("pageText"), r = t.get("pageFormatter"), o = e.pageIndex, a = null != o ? o + 1 : 0, s = e.pageCount;
            i && r && i.setStyle("text", w(r) ? r.replace("{current}", a).replace("{total}", s) : r({
                current: a,
                total: s
            }));
        },
        _getPageInfo: function(t) {
            function e(t) {
                if (t) {
                    var e = t.getBoundingRect(), n = e[l] + t.position[a];
                    return {
                        s: n,
                        e: n + e[s],
                        i: t.__legendDataIndex
                    };
                }
            }
            function n(t, e) {
                return t.e >= e && t.s <= e + o;
            }
            var i = t.get("scrollDataIndex", !0), r = this.getContentGroup(), o = this._containerGroup.__rectSize, a = t.getOrient().index, s = Iy[a], l = Ty[a], h = this._findTargetItemIndex(i), u = r.children(), c = u[h], d = u.length, f = d ? 1 : 0, p = {
                contentPosition: r.position.slice(),
                pageCount: f,
                pageIndex: f - 1,
                pagePrevDataIndex: null,
                pageNextDataIndex: null
            };
            if (!c) return p;
            var g = e(c);
            p.contentPosition[a] = -g.s;
            for (var v = h + 1, m = g, y = g, _ = null; d >= v; ++v) (!(_ = e(u[v])) && y.e > m.s + o || _ && !n(_, m.s)) && ((m = y.i > m.i ? y : _) && (null == p.pageNextDataIndex && (p.pageNextDataIndex = m.i), 
            ++p.pageCount)), y = _;
            for (v = h - 1, m = g, y = g, _ = null; v >= -1; --v) (_ = e(u[v])) && n(y, _.s) || !(m.i < y.i) || (y = m, 
            null == p.pagePrevDataIndex && (p.pagePrevDataIndex = m.i), ++p.pageCount, ++p.pageIndex), 
            m = _;
            return p;
        },
        _findTargetItemIndex: function(t) {
            return this._showController ? (this.getContentGroup().eachChild(function(i, r) {
                var o = i.__legendDataIndex;
                null == n && null != o && (n = r), o === t && (e = r);
            }), null != e ? e : n) : 0;
            var e, n;
        }
    });
    da("legendScroll", "legendscroll", function(t, e) {
        var n = t.scrollDataIndex;
        null != n && e.eachComponent({
            mainType: "legend",
            subType: "scroll",
            query: t
        }, function(t) {
            t.setScrollDataIndex(n);
        });
    });
    var Ay = function(t, e) {
        var n, i = [], r = t.seriesIndex;
        if (null == r || !(n = e.getSeriesByIndex(r))) return {
            point: []
        };
        var o = n.getData(), a = yn(o, t);
        if (null == a || 0 > a || _(a)) return {
            point: []
        };
        var s = o.getItemGraphicEl(a), l = n.coordinateSystem;
        if (n.getTooltipPosition) i = n.getTooltipPosition(a) || []; else if (l && l.dataToPoint) i = l.dataToPoint(o.getValues(p(l.dimensions, function(t) {
            return o.mapDimension(t);
        }), a, !0)) || []; else if (s) {
            var h = s.getBoundingRect().clone();
            h.applyTransform(s.transform), i = [ h.x + h.width / 2, h.y + h.height / 2 ];
        }
        return {
            point: i,
            el: s
        };
    }, Dy = f, ky = y, Py = _n(), Ly = (ma({
        type: "axisPointer",
        coordSysAxesInfo: null,
        defaultOption: {
            show: "auto",
            triggerOn: null,
            zlevel: 0,
            z: 50,
            type: "line",
            snap: !1,
            triggerTooltip: !0,
            value: null,
            status: null,
            link: [],
            animation: null,
            animationDurationUpdate: 200,
            lineStyle: {
                color: "#aaa",
                width: 1,
                type: "solid"
            },
            shadowStyle: {
                color: "rgba(150,150,150,0.3)"
            },
            label: {
                show: !0,
                formatter: null,
                precision: "auto",
                margin: 3,
                color: "#fff",
                padding: [ 5, 7, 5, 7 ],
                backgroundColor: "auto",
                borderColor: null,
                borderWidth: 0,
                shadowBlur: 3,
                shadowColor: "#aaa"
            },
            handle: {
                show: !1,
                icon: "M10.7,11.9v-1.3H9.3v1.3c-4.9,0.3-8.8,4.4-8.8,9.4c0,5,3.9,9.1,8.8,9.4h1.3c4.9-0.3,8.8-4.4,8.8-9.4C19.5,16.3,15.6,12.2,10.7,11.9z M13.3,24.4H6.7v-1.2h6.6z M13.3,22H6.7v-1.2h6.6z M13.3,19.6H6.7v-1.2h6.6z",
                size: 45,
                margin: 50,
                color: "#333",
                shadowBlur: 3,
                shadowColor: "#aaa",
                shadowOffsetX: 0,
                shadowOffsetY: 2,
                throttle: 40
            }
        }
    }), _n()), Oy = f, Ey = ya({
        type: "axisPointer",
        render: function(t, e, n) {
            var i = e.getComponent("tooltip"), r = t.get("triggerOn") || i && i.get("triggerOn") || "mousemove|click";
            $l("axisPointer", n, function(t, e, n) {
                "none" !== r && ("leave" === t || r.indexOf(t) >= 0) && n({
                    type: "updateAxisPointer",
                    currTrigger: t,
                    x: e && e.offsetX,
                    y: e && e.offsetY
                });
            });
        },
        remove: function(t, e) {
            th(e.getZr(), "axisPointer"), Ey.superApply(this._model, "remove", arguments);
        },
        dispose: function(t, e) {
            th("axisPointer", e), Ey.superApply(this._model, "dispose", arguments);
        }
    }), By = _n(), zy = i, Ny = m;
    eh.prototype = {
        _group: null,
        _lastGraphicKey: null,
        _handle: null,
        _dragging: !1,
        _lastValue: null,
        _lastStatus: null,
        _payloadInfo: null,
        animationThreshold: 15,
        render: function(t, e, n, i) {
            var r = e.get("value"), o = e.get("status");
            if (this._axisModel = t, this._axisPointerModel = e, this._api = n, i || this._lastValue !== r || this._lastStatus !== o) {
                this._lastValue = r, this._lastStatus = o;
                var a = this._group, s = this._handle;
                if (!o || "hide" === o) return a && a.hide(), void (s && s.hide());
                a && a.show(), s && s.show();
                var l = {};
                this.makeElOption(l, r, t, e, n);
                var h = l.graphicKey;
                h !== this._lastGraphicKey && this.clear(n), this._lastGraphicKey = h;
                var u = this._moveAnimation = this.determineAnimation(t, e);
                if (a) {
                    var c = y(nh, e, u);
                    this.updatePointerEl(a, l, c, e), this.updateLabelEl(a, l, c, e);
                } else a = this._group = new Nu(), this.createPointerEl(a, l, t, e), this.createLabelEl(a, l, t, e), 
                n.getZr().add(a);
                oh(a, e, !0), this._renderHandle(r);
            }
        },
        remove: function(t) {
            this.clear(t);
        },
        dispose: function(t) {
            this.clear(t);
        },
        determineAnimation: function(t, e) {
            var n = e.get("animation"), i = t.axis, r = "category" === i.type, o = e.get("snap");
            if (!o && !r) return !1;
            if ("auto" === n || null == n) {
                var a = this.animationThreshold;
                if (r && i.getBandWidth() > a) return !0;
                if (o) {
                    var s = ol(t).seriesDataCount, l = i.getExtent();
                    return Math.abs(l[0] - l[1]) / s > a;
                }
                return !1;
            }
            return !0 === n;
        },
        makeElOption: function() {},
        createPointerEl: function(t, e) {
            var n = e.pointer;
            if (n) {
                var i = By(t).pointerEl = new Pf[n.type](zy(e.pointer));
                t.add(i);
            }
        },
        createLabelEl: function(t, e, n, i) {
            if (e.label) {
                var r = By(t).labelEl = new sf(zy(e.label));
                t.add(r), ih(r, i);
            }
        },
        updatePointerEl: function(t, e, n) {
            var i = By(t).pointerEl;
            i && e.pointer && (i.setStyle(e.pointer.style), n(i, {
                shape: e.pointer.shape
            }));
        },
        updateLabelEl: function(t, e, n, i) {
            var r = By(t).labelEl;
            r && (r.setStyle(e.label.style), n(r, {
                shape: e.label.shape,
                position: e.label.position
            }), ih(r, i));
        },
        _renderHandle: function(t) {
            if (!this._dragging && this.updateHandleTransform) {
                var e, n = this._axisPointerModel, i = this._api.getZr(), r = this._handle, o = n.getModel("handle"), a = n.get("status");
                if (!o.get("show") || !a || "hide" === a) return r && i.remove(r), void (this._handle = null);
                this._handle || (e = !0, r = this._handle = qi(o.get("icon"), {
                    cursor: "move",
                    draggable: !0,
                    onmousemove: function(t) {
                        Jh(t.event);
                    },
                    onmousedown: Ny(this._onHandleDragMove, this, 0, 0),
                    drift: Ny(this._onHandleDragMove, this),
                    ondragend: Ny(this._onHandleDragEnd, this)
                }), i.add(r)), oh(r, n, !1);
                r.setStyle(o.getItemStyle(null, [ "color", "borderColor", "borderWidth", "opacity", "shadowColor", "shadowBlur", "shadowOffsetX", "shadowOffsetY" ]));
                var s = o.get("size");
                _(s) || (s = [ s, s ]), r.attr("scale", [ s[0] / 2, s[1] / 2 ]), function(t, e, n, i) {
                    var r = t[e];
                    if (r) {
                        var o = r[Zp] || r, a = r[$p];
                        if (r[Kp] !== n || a !== i) {
                            if (null == n || !i) return t[e] = o;
                            (r = t[e] = bo(o, n, "debounce" === i))[Zp] = o, r[$p] = i, r[Kp] = n;
                        }
                    }
                }(this, "_doDispatchAxisPointer", o.get("throttle") || 0, "fixRate"), this._moveHandleToValue(t, e);
            }
        },
        _moveHandleToValue: function(t, e) {
            nh(this._axisPointerModel, !e && this._moveAnimation, this._handle, rh(this.getHandleTransform(t, this._axisModel, this._axisPointerModel)));
        },
        _onHandleDragMove: function(t, e) {
            var n = this._handle;
            if (n) {
                this._dragging = !0;
                var i = this.updateHandleTransform(rh(n), [ t, e ], this._axisModel, this._axisPointerModel);
                this._payloadInfo = i, n.stopAnimation(), n.attr(rh(i)), By(n).lastProp = null, 
                this._doDispatchAxisPointer();
            }
        },
        _doDispatchAxisPointer: function() {
            if (this._handle) {
                var t = this._payloadInfo, e = this._axisModel;
                this._api.dispatchAction({
                    type: "updateAxisPointer",
                    x: t.cursorPoint[0],
                    y: t.cursorPoint[1],
                    tooltipOption: t.tooltipOption,
                    axesInfo: [ {
                        axisDim: e.axis.dim,
                        axisIndex: e.componentIndex
                    } ]
                });
            }
        },
        _onHandleDragEnd: function() {
            if (this._dragging = !1, this._handle) {
                var t = this._axisPointerModel.get("value");
                this._moveHandleToValue(t), this._api.dispatchAction({
                    type: "hideTip"
                });
            }
        },
        getHandleTransform: null,
        updateHandleTransform: null,
        clear: function(t) {
            this._lastValue = null, this._lastStatus = null;
            var e = t.getZr(), n = this._group, i = this._handle;
            e && n && (this._lastGraphicKey = null, n && e.remove(n), i && e.remove(i), this._group = null, 
            this._handle = null, this._payloadInfo = null);
        },
        doClear: function() {},
        buildLabel: function(t, e, n) {
            return {
                x: t[n = n || 0],
                y: t[1 - n],
                width: e[n],
                height: e[1 - n]
            };
        }
    }, eh.prototype.constructor = eh, In(eh);
    var Ry = eh.extend({
        makeElOption: function(t, e, n, i, r) {
            var o = n.axis, a = o.grid, s = i.get("type"), l = uh(a, o).getOtherAxis(o).getGlobalExtent(), h = o.toGlobalCoord(o.dataToCoord(e, !0));
            if (s && "none" !== s) {
                var u = function(t) {
                    var e, n = t.get("type"), i = t.getModel(n + "Style");
                    return "line" === n ? (e = i.getLineStyle()).fill = null : "shadow" === n && ((e = i.getAreaStyle()).stroke = null), 
                    e;
                }(i), c = Fy[s](o, h, l);
                c.style = u, t.graphicKey = c.type, t.pointer = c;
            }
            !function(t, e, n, i, r, o) {
                var a = Lm.innerTextLayout(n.rotation, 0, n.labelDirection);
                n.labelMargin = r.get("label.margin"), ah(e, i, r, o, {
                    position: lh(i.axis, t, n),
                    align: a.textAlign,
                    verticalAlign: a.textVerticalAlign
                });
            }(e, t, ul(a.model, n), n, i, r);
        },
        getHandleTransform: function(t, e, n) {
            var i = ul(e.axis.grid.model, e, {
                labelInside: !1
            });
            return i.labelMargin = n.get("handle.margin"), {
                position: lh(e.axis, t, i),
                rotation: i.rotation + (i.labelDirection < 0 ? Math.PI : 0)
            };
        },
        updateHandleTransform: function(t, e, n) {
            var i = n.axis, r = i.grid, o = i.getGlobalExtent(!0), a = uh(r, i).getOtherAxis(i).getGlobalExtent(), s = "x" === i.dim ? 0 : 1, l = t.position;
            l[s] += e[s], l[s] = Math.min(o[1], l[s]), l[s] = Math.max(o[0], l[s]);
            var h = (a[1] + a[0]) / 2, u = [ h, h ];
            u[s] = l[s];
            return {
                position: l,
                rotation: t.rotation,
                cursorPoint: u,
                tooltipOption: [ {
                    verticalAlign: "middle"
                }, {
                    align: "center"
                } ][s]
            };
        }
    }), Fy = {
        line: function(t, e, n) {
            return {
                type: "Line",
                subPixelOptimize: !0,
                shape: function(t, e, n) {
                    return {
                        x1: t[n = n || 0],
                        y1: t[1 - n],
                        x2: e[n],
                        y2: e[1 - n]
                    };
                }([ e, n[0] ], [ e, n[1] ], ch(t))
            };
        },
        shadow: function(t, e, n) {
            var i = Math.max(1, t.getBandWidth()), r = n[1] - n[0];
            return {
                type: "Rect",
                shape: hh([ e - i / 2, n[0] ], [ i, r ], ch(t))
            };
        }
    };
    Fm.registerAxisPointerClass("CartesianAxisPointer", Ry), ua(function(t) {
        if (t) {
            (!t.axisPointer || 0 === t.axisPointer.length) && (t.axisPointer = {});
            var e = t.axisPointer.link;
            e && !_(e) && (t.axisPointer.link = [ e ]);
        }
    }), ca(Bg.PROCESSOR.STATISTIC, function(t, e) {
        t.getComponent("axisPointer").coordSysAxesInfo = el(t, e);
    }), da({
        type: "updateAxisPointer",
        event: "updateAxisPointer",
        update: ":updateAxisPointer"
    }, function(t, e, n) {
        var i = t.currTrigger, r = [ t.x, t.y ], o = t, a = t.dispatchAction || m(n.dispatchAction, n), s = e.getComponent("axisPointer").coordSysAxesInfo;
        if (s) {
            Kl(r) && (r = Ay({
                seriesIndex: o.seriesIndex,
                dataIndex: o.dataIndex
            }, e).point);
            var l = Kl(r), h = o.axesInfo, u = s.axesInfo, c = "leave" === i || Kl(r), d = {}, f = {}, p = {
                list: [],
                map: {}
            }, g = {
                showPointer: ky(Yl, f),
                showTooltip: ky(ql, p)
            };
            Dy(s.coordSysMap, function(t, e) {
                var n = l || t.containPoint(r);
                Dy(s.coordSysAxesInfo[e], function(t) {
                    var e = t.axis, i = function(t, e) {
                        for (var n = 0; n < (t || []).length; n++) {
                            var i = t[n];
                            if (e.axis.dim === i.axisDim && e.axis.model.componentIndex === i.axisIndex) return i;
                        }
                    }(h, t);
                    if (!c && n && (!h || i)) {
                        var o = i && i.value;
                        null != o || l || (o = e.pointToData(r)), null != o && Ul(t, o, g, !1, d);
                    }
                });
            });
            var v = {};
            return Dy(u, function(t, e) {
                var n = t.linkGroup;
                n && !f[e] && Dy(n.axesInfo, function(e, i) {
                    var r = f[i];
                    if (e !== t && r) {
                        var o = r.value;
                        n.mapper && (o = t.axis.scale.parse(n.mapper(o, Zl(e), Zl(t)))), v[t.key] = o;
                    }
                });
            }), Dy(v, function(t, e) {
                Ul(u[e], t, g, !0, d);
            }), function(t, e, n) {
                var i = n.axesInfo = [];
                Dy(e, function(e, n) {
                    var r = e.axisPointerModel.option, o = t[n];
                    o ? (!e.useHandle && (r.status = "show"), r.value = o.value, r.seriesDataIndices = (o.payloadBatch || []).slice()) : !e.useHandle && (r.status = "hide"), 
                    "show" === r.status && i.push({
                        axisDim: e.axis.dim,
                        axisIndex: e.axis.model.componentIndex,
                        value: r.value
                    });
                });
            }(f, u, d), function(t, e, n, i) {
                if (!Kl(e) && t.list.length) {
                    var r = ((t.list[0].dataByAxis[0] || {}).seriesDataIndices || [])[0] || {};
                    i({
                        type: "showTip",
                        escapeConnect: !0,
                        x: e[0],
                        y: e[1],
                        tooltipOption: n.tooltipOption,
                        position: n.position,
                        dataIndexInside: r.dataIndexInside,
                        dataIndex: r.dataIndex,
                        seriesIndex: r.seriesIndex,
                        dataByCoordSys: t.list
                    });
                } else i({
                    type: "hideTip"
                });
            }(p, r, t, a), jl(u, 0, n), d;
        }
    }), ma({
        type: "tooltip",
        dependencies: [ "axisPointer" ],
        defaultOption: {
            zlevel: 0,
            z: 60,
            show: !0,
            showContent: !0,
            trigger: "item",
            triggerOn: "mousemove|click",
            alwaysShowContent: !1,
            displayMode: "single",
            renderMode: "auto",
            confine: !1,
            showDelay: 0,
            hideDelay: 100,
            transitionDuration: .4,
            enterable: !1,
            backgroundColor: "rgba(50,50,50,0.7)",
            borderColor: "#333",
            borderRadius: 4,
            borderWidth: 0,
            padding: 5,
            extraCssText: "",
            axisPointer: {
                type: "line",
                axis: "auto",
                animation: "auto",
                animationDurationUpdate: 200,
                animationEasingUpdate: "exponentialOut",
                crossStyle: {
                    color: "#999",
                    width: 1,
                    type: "dashed",
                    textStyle: {}
                }
            },
            textStyle: {
                color: "#fff",
                fontSize: 14
            }
        }
    });
    var Vy = f, Hy = fr, Gy = [ "", "-webkit-", "-moz-", "-o-" ];
    ph.prototype = {
        constructor: ph,
        _enterable: !0,
        update: function(t) {
            var e = this._container, n = e.currentStyle || document.defaultView.getComputedStyle(e), i = e.style;
            "absolute" !== i.position && "absolute" !== n.position && (i.position = "relative"), 
            t.get("alwaysShowContent") && this._moveTooltipIfResized();
        },
        _moveTooltipIfResized: function() {
            var t = this._styleCoord[2], e = this._styleCoord[3], n = t * this._zr.getWidth(), i = e * this._zr.getHeight();
            this.moveTo(n, i);
        },
        show: function(t) {
            clearTimeout(this._hideTimeout);
            var e = this.el, n = this._styleCoord;
            e.style.cssText = "position:absolute;display:block;border-style:solid;white-space:nowrap;z-index:9999999;" + dh(t) + ";left:" + n[0] + "px;top:" + n[1] + "px;" + (t.get("extraCssText") || ""), 
            e.style.display = e.innerHTML ? "block" : "none", e.style.pointerEvents = this._enterable ? "auto" : "none", 
            this._show = !0;
        },
        setContent: function(t) {
            this.el.innerHTML = null == t ? "" : t;
        },
        setEnterable: function(t) {
            this._enterable = t;
        },
        getSize: function() {
            var t = this.el;
            return [ t.clientWidth, t.clientHeight ];
        },
        moveTo: function(t, e) {
            var n = this._styleCoord;
            fh(n, this._zr, this._appendToBody, t, e);
            var i = this.el.style;
            i.left = n[0] + "px", i.top = n[1] + "px";
        },
        hide: function() {
            this.el.style.display = "none", this._show = !1;
        },
        hideLater: function(t) {
            !this._show || this._inContent && this._enterable || (t ? (this._hideDelay = t, 
            this._show = !1, this._hideTimeout = setTimeout(m(this.hide, this), t)) : this.hide());
        },
        isShow: function() {
            return this._show;
        },
        dispose: function() {
            this.el.parentNode.removeChild(this.el);
        },
        getOuterSize: function() {
            var t = this.el.clientWidth, e = this.el.clientHeight;
            if (document.defaultView && document.defaultView.getComputedStyle) {
                var n = document.defaultView.getComputedStyle(this.el);
                n && (t += parseInt(n.borderLeftWidth, 10) + parseInt(n.borderRightWidth, 10), e += parseInt(n.borderTopWidth, 10) + parseInt(n.borderBottomWidth, 10));
            }
            return {
                width: t,
                height: e
            };
        }
    }, vh.prototype = {
        constructor: vh,
        _enterable: !0,
        update: function(t) {
            t.get("alwaysShowContent") && this._moveTooltipIfResized();
        },
        _moveTooltipIfResized: function() {
            var t = this._styleCoord[2], e = this._styleCoord[3], n = t * this._zr.getWidth(), i = e * this._zr.getHeight();
            this.moveTo(n, i);
        },
        show: function() {
            this._hideTimeout && clearTimeout(this._hideTimeout), this.el.attr("show", !0), 
            this._show = !0;
        },
        setContent: function(t, e, n) {
            this.el && this._zr.remove(this.el);
            for (var i = {}, r = t, o = "{marker", a = r.indexOf(o); a >= 0; ) {
                var s = r.indexOf("|}"), l = r.substr(a + o.length, s - a - o.length);
                i["marker" + l] = l.indexOf("sub") > -1 ? {
                    textWidth: 4,
                    textHeight: 4,
                    textBorderRadius: 2,
                    textBackgroundColor: e[l],
                    textOffset: [ 3, 0 ]
                } : {
                    textWidth: 10,
                    textHeight: 10,
                    textBorderRadius: 5,
                    textBackgroundColor: e[l]
                }, a = (r = r.substr(s + 1)).indexOf("{marker");
            }
            var h = n.getModel("textStyle"), u = h.get("fontSize"), c = n.get("textLineHeight");
            null == c && (c = Math.round(3 * u / 2)), this.el = new jd({
                style: Bi({}, h, {
                    rich: i,
                    text: t,
                    textBackgroundColor: n.get("backgroundColor"),
                    textBorderRadius: n.get("borderRadius"),
                    textFill: n.get("textStyle.color"),
                    textPadding: n.get("padding"),
                    textLineHeight: c
                }),
                z: n.get("z")
            }), this._zr.add(this.el);
            var d = this;
            this.el.on("mouseover", function() {
                d._enterable && (clearTimeout(d._hideTimeout), d._show = !0), d._inContent = !0;
            }), this.el.on("mouseout", function() {
                d._enterable && d._show && d.hideLater(d._hideDelay), d._inContent = !1;
            });
        },
        setEnterable: function(t) {
            this._enterable = t;
        },
        getSize: function() {
            var t = this.el.getBoundingRect();
            return [ t.width, t.height ];
        },
        moveTo: function(t, e) {
            if (this.el) {
                var n = this._styleCoord;
                gh(n, this._zr, t, e), this.el.attr("position", [ n[0], n[1] ]);
            }
        },
        hide: function() {
            this.el && this.el.hide(), this._show = !1;
        },
        hideLater: function(t) {
            !this._show || this._inContent && this._enterable || (t ? (this._hideDelay = t, 
            this._show = !1, this._hideTimeout = setTimeout(m(this.hide, this), t)) : this.hide());
        },
        isShow: function() {
            return this._show;
        },
        dispose: function() {
            clearTimeout(this._hideTimeout), this.el && this._zr.remove(this.el);
        },
        getOuterSize: function() {
            var t = this.getSize();
            return {
                width: t[0],
                height: t[1]
            };
        }
    };
    var Wy = m, Xy = f, Uy = er, Yy = new sf({
        shape: {
            x: -1,
            y: -1,
            width: 2,
            height: 2
        }
    });
    ya({
        type: "tooltip",
        init: function(t, e) {
            if (!Mh.node) {
                var n, i = t.getComponent("tooltip"), r = i.get("renderMode");
                this._renderMode = Sn(r), "html" === this._renderMode ? (n = new ph(e.getDom(), e, {
                    appendToBody: i.get("appendToBody", !0)
                }), this._newLine = "<br/>") : (n = new vh(e), this._newLine = "\n"), this._tooltipContent = n;
            }
        },
        render: function(t, e, n) {
            if (!Mh.node) {
                this.group.removeAll(), this._tooltipModel = t, this._ecModel = e, this._api = n, 
                this._lastDataByCoordSys = null, this._alwaysShowContent = t.get("alwaysShowContent");
                var i = this._tooltipContent;
                i.update(t), i.setEnterable(t.get("enterable")), this._initGlobalListener(), this._keepShow();
            }
        },
        _initGlobalListener: function() {
            var t = this._tooltipModel.get("triggerOn");
            $l("itemTooltip", this._api, Wy(function(e, n, i) {
                "none" !== t && (t.indexOf(e) >= 0 ? this._tryShow(n, i) : "leave" === e && this._hide(i));
            }, this));
        },
        _keepShow: function() {
            var t = this._tooltipModel, e = this._ecModel, n = this._api;
            if (null != this._lastX && null != this._lastY && "none" !== t.get("triggerOn")) {
                var i = this;
                clearTimeout(this._refreshUpdateTimeout), this._refreshUpdateTimeout = setTimeout(function() {
                    !n.isDisposed() && i.manuallyShowTip(t, e, n, {
                        x: i._lastX,
                        y: i._lastY
                    });
                });
            }
        },
        manuallyShowTip: function(t, e, n, i) {
            if (i.from !== this.uid && !Mh.node) {
                var r = yh(i, n);
                this._ticket = "";
                var o = i.dataByCoordSys;
                if (i.tooltip && null != i.x && null != i.y) {
                    var a = Yy;
                    a.position = [ i.x, i.y ], a.update(), a.tooltip = i.tooltip, this._tryShow({
                        offsetX: i.x,
                        offsetY: i.y,
                        target: a
                    }, r);
                } else if (o) this._tryShow({
                    offsetX: i.x,
                    offsetY: i.y,
                    position: i.position,
                    dataByCoordSys: i.dataByCoordSys,
                    tooltipOption: i.tooltipOption
                }, r); else if (null != i.seriesIndex) {
                    if (this._manuallyAxisShowTip(t, e, n, i)) return;
                    var s = Ay(i, e), l = s.point[0], h = s.point[1];
                    null != l && null != h && this._tryShow({
                        offsetX: l,
                        offsetY: h,
                        position: i.position,
                        target: s.el
                    }, r);
                } else null != i.x && null != i.y && (n.dispatchAction({
                    type: "updateAxisPointer",
                    x: i.x,
                    y: i.y
                }), this._tryShow({
                    offsetX: i.x,
                    offsetY: i.y,
                    position: i.position,
                    target: n.getZr().findHover(i.x, i.y).target
                }, r));
            }
        },
        manuallyHideTip: function(t, e, n, i) {
            var r = this._tooltipContent;
            !this._alwaysShowContent && this._tooltipModel && r.hideLater(this._tooltipModel.get("hideDelay")), 
            this._lastX = this._lastY = null, i.from !== this.uid && this._hide(yh(i, n));
        },
        _manuallyAxisShowTip: function(t, e, n, i) {
            var r = i.seriesIndex, o = i.dataIndex, a = e.getComponent("axisPointer").coordSysAxesInfo;
            if (null != r && null != o && null != a) {
                var s = e.getSeriesByIndex(r);
                if (s) if ("axis" === (t = mh([ s.getData().getItemModel(o), s, (s.coordinateSystem || {}).model, t ])).get("trigger")) return n.dispatchAction({
                    type: "updateAxisPointer",
                    seriesIndex: r,
                    dataIndex: o,
                    position: i.position
                }), !0;
            }
        },
        _tryShow: function(t, e) {
            var n = t.target;
            if (this._tooltipModel) {
                this._lastX = t.offsetX, this._lastY = t.offsetY;
                var i = t.dataByCoordSys;
                i && i.length ? this._showAxisTooltip(i, t) : n && null != n.dataIndex ? (this._lastDataByCoordSys = null, 
                this._showSeriesItemTooltip(t, n, e)) : n && n.tooltip ? (this._lastDataByCoordSys = null, 
                this._showComponentItemTooltip(t, n, e)) : (this._lastDataByCoordSys = null, this._hide(e));
            }
        },
        _showOrMove: function(t, e) {
            var n = t.get("showDelay");
            e = m(e, this), clearTimeout(this._showTimout), n > 0 ? this._showTimout = setTimeout(e, n) : e();
        },
        _showAxisTooltip: function(t, e) {
            var n = this._ecModel, i = this._tooltipModel, o = [ e.offsetX, e.offsetY ], a = [], s = [], l = mh([ e.tooltipOption, i ]), h = this._renderMode, u = this._newLine, c = {};
            Xy(t, function(t) {
                Xy(t.dataByAxis, function(t) {
                    var e = n.getComponent(t.axisDim + "Axis", t.axisIndex), i = t.value, o = [];
                    if (e && null != i) {
                        var l = sh(i, e.axis, n, t.seriesDataIndices, t.valueLabelOpt);
                        f(t.seriesDataIndices, function(a) {
                            var u = n.getSeriesByIndex(a.seriesIndex), d = a.dataIndexInside, f = u && u.getDataParams(d);
                            if (f.axisDim = t.axisDim, f.axisIndex = t.axisIndex, f.axisType = t.axisType, f.axisId = t.axisId, 
                            f.axisValue = fs(e.axis, i), f.axisValueLabel = l, f) {
                                s.push(f);
                                var p, g = u.formatTooltip(d, !0, null, h);
                                if (b(g)) {
                                    p = g.html;
                                    var v = g.markers;
                                    r(c, v);
                                } else p = g;
                                o.push(p);
                            }
                        });
                        var d = l;
                        a.push("html" !== h ? o.join(u) : (d ? pr(d) + u : "") + o.join(u));
                    }
                });
            }, this), a.reverse(), a = a.join(this._newLine + this._newLine);
            var d = e.position;
            this._showOrMove(l, function() {
                this._updateContentNotChangedOnAxis(t) ? this._updatePosition(l, d, o[0], o[1], this._tooltipContent, s) : this._showTooltipContent(l, a, s, Math.random(), o[0], o[1], d, void 0, c);
            });
        },
        _showSeriesItemTooltip: function(t, e, n) {
            var i = this._ecModel, r = e.seriesIndex, o = i.getSeriesByIndex(r), a = e.dataModel || o, s = e.dataIndex, l = e.dataType, h = a.getData(l), u = mh([ h.getItemModel(s), a, o && (o.coordinateSystem || {}).model, this._tooltipModel ]), c = u.get("trigger");
            if (null == c || "item" === c) {
                var d, f, p = a.getDataParams(s, l), g = a.formatTooltip(s, !1, l, this._renderMode);
                b(g) ? (d = g.html, f = g.markers) : (d = g, f = null);
                var v = "item_" + a.name + "_" + s;
                this._showOrMove(u, function() {
                    this._showTooltipContent(u, d, p, v, t.offsetX, t.offsetY, t.position, t.target, f);
                }), n({
                    type: "showTip",
                    dataIndexInside: s,
                    dataIndex: h.getRawIndex(s),
                    seriesIndex: r,
                    from: this.uid
                });
            }
        },
        _showComponentItemTooltip: function(t, e, n) {
            var i = e.tooltip;
            if ("string" == typeof i) {
                i = {
                    content: i,
                    formatter: i
                };
            }
            var r = new Ki(i, this._tooltipModel, this._ecModel), o = r.get("content"), a = Math.random();
            this._showOrMove(r, function() {
                this._showTooltipContent(r, o, r.get("formatterParams") || {}, a, t.offsetX, t.offsetY, t.position, e);
            }), n({
                type: "showTip",
                from: this.uid
            });
        },
        _showTooltipContent: function(t, e, n, i, r, o, a, s, l) {
            if (this._ticket = "", t.get("showContent") && t.get("show")) {
                var h = this._tooltipContent, u = t.get("formatter");
                a = a || t.get("position");
                var c = e;
                if (u && "string" == typeof u) c = gr(u, n, !0); else if ("function" == typeof u) {
                    var d = Wy(function(e, i) {
                        e === this._ticket && (h.setContent(i, l, t), this._updatePosition(t, a, r, o, h, n, s));
                    }, this);
                    this._ticket = i, c = u(n, i, d);
                }
                h.setContent(c, l, t), h.show(t), this._updatePosition(t, a, r, o, h, n, s);
            }
        },
        _updatePosition: function(t, e, n, i, r, o, a) {
            var s = this._api.getWidth(), l = this._api.getHeight();
            e = e || t.get("position");
            var h = r.getSize(), u = t.get("align"), c = t.get("verticalAlign"), d = a && a.getBoundingRect().clone();
            if (a && d.applyTransform(a.transform), "function" == typeof e && (e = e([ n, i ], o, r.el, d, {
                viewSize: [ s, l ],
                contentSize: h.slice()
            })), _(e)) n = Uy(e[0], s), i = Uy(e[1], l); else if (b(e)) {
                e.width = h[0], e.height = h[1];
                var f = wr(e, {
                    width: s,
                    height: l
                });
                n = f.x, i = f.y, u = null, c = null;
            } else if ("string" == typeof e && a) {
                n = (p = function(t, e, n) {
                    var i = n[0], r = n[1], o = 0, a = 0, s = e.width, l = e.height;
                    switch (t) {
                      case "inside":
                        o = e.x + s / 2 - i / 2, a = e.y + l / 2 - r / 2;
                        break;

                      case "top":
                        o = e.x + s / 2 - i / 2, a = e.y - r - 5;
                        break;

                      case "bottom":
                        o = e.x + s / 2 - i / 2, a = e.y + l + 5;
                        break;

                      case "left":
                        o = e.x - i - 5, a = e.y + l / 2 - r / 2;
                        break;

                      case "right":
                        o = e.x + s + 5, a = e.y + l / 2 - r / 2;
                    }
                    return [ o, a ];
                }(e, d, h))[0], i = p[1];
            } else {
                var p = function(t, e, n, i, r, o, a) {
                    var s = n.getOuterSize(), l = s.width, h = s.height;
                    return null != o && (t + l + o > i ? t -= l + o : t += o), null != a && (e + h + a > r ? e -= h + a : e += a), 
                    [ t, e ];
                }(n, i, r, s, l, u ? null : 20, c ? null : 20);
                n = p[0], i = p[1];
            }
            if (u && (n -= _h(u) ? h[0] / 2 : "right" === u ? h[0] : 0), c && (i -= _h(c) ? h[1] / 2 : "bottom" === c ? h[1] : 0), 
            t.get("confine")) {
                p = function(t, e, n, i, r) {
                    var o = n.getOuterSize(), a = o.width, s = o.height;
                    return t = Math.min(t + a, i) - a, e = Math.min(e + s, r) - s, [ t = Math.max(t, 0), e = Math.max(e, 0) ];
                }(n, i, r, s, l);
                n = p[0], i = p[1];
            }
            r.moveTo(n, i);
        },
        _updateContentNotChangedOnAxis: function(t) {
            var e = this._lastDataByCoordSys, n = !!e && e.length === t.length;
            return n && Xy(e, function(e, i) {
                var r = e.dataByAxis || {}, o = (t[i] || {}).dataByAxis || [];
                (n &= r.length === o.length) && Xy(r, function(t, e) {
                    var i = o[e] || {}, r = t.seriesDataIndices || [], a = i.seriesDataIndices || [];
                    (n &= t.value === i.value && t.axisType === i.axisType && t.axisId === i.axisId && r.length === a.length) && Xy(r, function(t, e) {
                        var i = a[e];
                        n &= t.seriesIndex === i.seriesIndex && t.dataIndex === i.dataIndex;
                    });
                });
            }), this._lastDataByCoordSys = t, !!n;
        },
        _hide: function(t) {
            this._lastDataByCoordSys = null, t({
                type: "hideTip",
                from: this.uid
            });
        },
        dispose: function(t, e) {
            Mh.node || (this._tooltipContent.dispose(), th("itemTooltip", e));
        }
    }), da({
        type: "showTip",
        event: "showTip",
        update: "tooltip:manuallyShowTip"
    }, function() {}), da({
        type: "hideTip",
        event: "hideTip",
        update: "tooltip:manuallyHideTip"
    }, function() {}), e.version = kg, e.dependencies = Pg, e.PRIORITY = Bg, e.init = function(t, e, n) {
        if (wh) {
            if (Dc.replace(".", "") - 0 < Pg.zrender.replace(".", "") - 0) throw new Error("zrender/src " + Dc + " is too old for ECharts " + kg + ". Current version need ZRender " + Pg.zrender + "+");
            if (!t) throw new Error("Initialize failed: invalid dom.");
        }
        var i = la(t);
        if (i) return wh && console.warn("There is a chart instance already initialized on the dom."), 
        i;
        wh && (!I(t) || "CANVAS" === t.nodeName.toUpperCase() || (t.clientWidth || n && null != n.width) && (t.clientHeight || n && null != n.height) || console.warn("Can't get DOM width or height. Please check dom.clientWidth and dom.clientHeight. They should not be 0.For example, you may need to call this in the callback of window.onload."));
        var r = new Xo(t, e, n);
        return r.id = "ec_" + Qg++, Kg[r.id] = r, bn(t, tv, r.id), function(t) {
            function e(t, e) {
                for (var i = 0; i < t.length; i++) {
                    t[i][n] = e;
                }
            }
            var n = "__connectUpdateStatus";
            Tg(Wg, function(i, r) {
                t._messageCenter.on(r, function(i) {
                    if ($g[t.group] && 0 !== t[n]) {
                        if (i && i.escapeConnect) return;
                        var r = t.makeActionFromEvent(i), o = [];
                        Tg(Kg, function(e) {
                            e !== t && e.group === t.group && o.push(e);
                        }), e(o, 0), Tg(o, function(t) {
                            1 !== t[n] && t.dispatchAction(r);
                        }), e(o, 2);
                    }
                });
            });
        }(r), r;
    }, e.connect = function(t) {
        if (_(t)) {
            var e = t;
            t = null, Tg(e, function(e) {
                null != e.group && (t = e.group);
            }), t = t || "g_" + Jg++, Tg(e, function(e) {
                e.group = t;
            });
        }
        return $g[t] = !0, t;
    }, e.disConnect = sa, e.disconnect = ev, e.dispose = function(t) {
        "string" == typeof t ? t = Kg[t] : t instanceof Xo || (t = la(t)), t instanceof Xo && !t.isDisposed() && t.dispose();
    }, e.getInstanceByDom = la, e.getInstanceById = function(t) {
        return Kg[t];
    }, e.registerTheme = ha, e.registerPreprocessor = ua, e.registerProcessor = ca, 
    e.registerPostUpdate = function(t) {
        Yg.push(t);
    }, e.registerAction = da, e.registerCoordinateSystem = function(t, e) {
        Rr.register(t, e);
    }, e.getCoordinateSystemDimensions = function(t) {
        var e = Rr.get(t);
        return e ? e.getDimensionsInfo ? e.getDimensionsInfo() : e.dimensions.slice() : void 0;
    }, e.registerLayout = fa, e.registerVisual = pa, e.registerLoading = va, e.extendComponentModel = ma, 
    e.extendComponentView = ya, e.extendSeriesModel = _a, e.extendChartView = xa, e.setCanvasCreator = function(t) {
        n("createCanvas", t);
    }, e.registerMap = function(t, e, n) {
        Sg.registerMap(t, e, n);
    }, e.getMap = function(t) {
        var e = Sg.retrieveMap(t);
        return e && e[0] && {
            geoJson: e[0].geoJSON,
            specialAreas: e[0].specialAreas
        };
    }, e.dataTool = {}, e.zrender = Pc, e.number = Hf, e.format = jf, e.throttle = bo, 
    e.helper = tm, e.matrix = au, e.vector = Xh, e.color = Iu, e.parseGeoJSON = nm, 
    e.parseGeoJson = am, e.util = sm, e.graphic = lm, e.List = fv, e.Model = Ki, e.Axis = om, 
    e.env = Mh;
});