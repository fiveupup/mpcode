var e, t, a, n = require("../../@babel/runtime/helpers/regeneratorRuntime"), r = require("../../@babel/runtime/helpers/asyncToGenerator"), c = (e = require("./wx-canvas")) && e.__esModule ? e : {
    default: e
}, i = function(e, t) {
    if (!t && e && e.__esModule) return e;
    if (null === e || "object" != typeof e && "function" != typeof e) return {
        default: e
    };
    var a = o(t);
    if (a && a.has(e)) return a.get(e);
    var n = {}, r = Object.defineProperty && Object.getOwnPropertyDescriptor;
    for (var c in e) if ("default" !== c && Object.prototype.hasOwnProperty.call(e, c)) {
        var i = r ? Object.getOwnPropertyDescriptor(e, c) : null;
        i && (i.get || i.set) ? Object.defineProperty(n, c, i) : n[c] = e[c];
    }
    n.default = e, a && a.set(e, n);
    return n;
}(require("./echarts")), s = require("../../utils/tools");

function o(e) {
    if ("function" != typeof WeakMap) return null;
    var t = new WeakMap(), a = new WeakMap();
    return (o = function(e) {
        return e ? a : t;
    })(e);
}

function h(e) {
    for (var t = 0; t < e.touches.length; ++t) {
        var a = e.touches[t];
        a.offsetX = a.x, a.offsetY = a.y;
    }
    return e;
}

Component({
    properties: {
        canvasId: {
            type: String,
            value: "ec-canvas"
        },
        ec: {
            type: Object
        },
        forceUseOldCanvas: {
            type: Boolean,
            value: !1
        },
        width: {
            type: Number,
            value: 0
        },
        height: {
            type: Number,
            value: 0
        },
        styles: {
            type: String,
            value: ""
        }
    },
    data: {
        isUseNewCanvas: !1
    },
    ready: function() {
        this.data.ec ? this.data.ec.lazyLoad || this.init() : console.warn('组件需绑定 ec 变量，例：<ec-canvas id="mychart-dom-bar" canvas-id="mychart-bar" ec="{{ ec }}"></ec-canvas>');
    },
    methods: {
        init: (a = r(n().mark(function e(t) {
            var a, r, c, i = this;
            return n().wrap(function(e) {
                for (;;) switch (e.prev = e.next) {
                  case 0:
                    return a = (0, s.isSdkGreaterThan)("2.9.0"), r = this.data.forceUseOldCanvas, c = a && !r, 
                    e.next = 5, new Promise(function(e) {
                        i.setData({
                            isUseNewCanvas: c
                        }, e);
                    });

                  case 5:
                    if (r && a && console.warn("开发者强制使用旧canvas,建议关闭"), !c) {
                        e.next = 10;
                        break;
                    }
                    this.initByNewWay(t), e.next = 18;
                    break;

                  case 10:
                    if ((0, s.isSdkGreaterThan)("1.9.91")) {
                        e.next = 16;
                        break;
                    }
                    return console.error("微信基础库版本过低，需大于等于 1.9.91。参见：https://github.com/ecomfe/echarts-for-weixin#%E5%BE%AE%E4%BF%A1%E7%89%88%E6%9C%AC%E8%A6%81%E6%B1%82"), 
                    e.abrupt("return");

                  case 16:
                    console.warn("建议将微信基础库调整大于等于2.9.0版本。升级后绘图将有更好性能"), this.initByOldWay(t);

                  case 18:
                  case "end":
                    return e.stop();
                }
            }, e, this);
        })), function(e) {
            return a.apply(this, arguments);
        }),
        initByOldWay: function(e) {
            var a = this;
            t = wx.createCanvasContext(this.data.canvasId, this);
            var n = new c.default(t, this.data.canvasId, !1);
            i.setCanvasCreator(function() {
                return n;
            });
            wx.createSelectorQuery().in(this).select(".ec-canvas").boundingClientRect(function(t) {
                "function" == typeof e ? a.chart = e(n, t.width, t.height, 1) : a.data.ec && "function" == typeof a.data.ec.onInit ? a.chart = a.data.ec.onInit(n, t.width, t.height, 1) : a.triggerEvent("init", {
                    canvas: n,
                    width: t.width,
                    height: t.height,
                    canvasDpr: 1
                });
            }).exec();
        },
        initByNewWay: function(e) {
            var t = this;
            wx.createSelectorQuery().in(this).select(".ec-canvas").fields({
                node: !0,
                size: !0
            }).exec(function(a) {
                var n = a[0].node;
                t.canvasNode = n;
                var r = wx.getSystemInfoSync().pixelRatio, s = a[0].width, o = a[0].height, h = n.getContext("2d"), u = new c.default(h, t.data.canvasId, !0, n);
                i.setCanvasCreator(function() {
                    return u;
                }), "function" == typeof e ? t.chart = e(u, s, o, r) : t.data.ec && "function" == typeof t.data.ec.onInit ? t.chart = t.data.ec.onInit(u, s, o, r) : t.triggerEvent("init", {
                    canvas: u,
                    width: s,
                    height: o,
                    dpr: r
                });
            });
        },
        canvasToTempFilePath: function(e) {
            var a = this;
            this.data.isUseNewCanvas ? wx.createSelectorQuery().in(this).select(".ec-canvas").fields({
                node: !0,
                size: !0
            }).exec(function(t) {
                var a = t[0].node;
                e.canvas = a, wx.canvasToTempFilePath(e);
            }) : (e.canvasId || (e.canvasId = this.data.canvasId), t.draw(!0, function() {
                wx.canvasToTempFilePath(e, a);
            }));
        },
        touchStart: function(e) {
            if (this.chart && e.touches.length > 0) {
                var t = e.touches[0], a = this.chart.getZr().handler;
                a.dispatch("mousedown", {
                    zrX: t.x,
                    zrY: t.y
                }), a.dispatch("mousemove", {
                    zrX: t.x,
                    zrY: t.y
                }), a.processGesture(h(e), "start");
            }
        },
        touchMove: function(e) {
            if (this.chart && e.touches.length > 0) {
                var t = e.touches[0], a = this.chart.getZr().handler;
                a.dispatch("mousemove", {
                    zrX: t.x,
                    zrY: t.y
                }), a.processGesture(h(e), "change");
            }
        },
        touchEnd: function(e) {
            if (this.chart) {
                var t = e.changedTouches ? e.changedTouches[0] : {}, a = this.chart.getZr().handler;
                a.dispatch("mouseup", {
                    zrX: t.x,
                    zrY: t.y
                }), a.dispatch("click", {
                    zrX: t.x,
                    zrY: t.y
                }), a.processGesture(h(e), "end");
            }
        }
    }
});