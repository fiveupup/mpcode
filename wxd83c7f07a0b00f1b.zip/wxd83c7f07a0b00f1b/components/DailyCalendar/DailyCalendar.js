var e = require("../../@babel/runtime/helpers/regeneratorRuntime"), t = require("../../@babel/runtime/helpers/asyncToGenerator"), a = u(require("dayjs")), n = require("../../utils/functional"), r = require("../../service/reminder"), i = require("mobx-miniprogram-bindings"), s = u(require("../../store/app")), c = require("../../service/user"), l = require("../../service/analyse"), d = u(require("../../config")), o = require("../../service/subscribe");

function u(e) {
    return e && e.__esModule ? e : {
        default: e
    };
}

for (var h = [], f = 0; f <= 23; f++) h.push("".concat(f, ":00"));

var m;

function p() {
    (0, l.eventGa)("flow_guide_daily_send", "show"), wx.showModal({
        content: "未关注 Readhub 服务号，无法开启每日通知",
        confirmText: "去关注",
        confirmColor: "#0DAC5D",
        success: function(e) {
            e.confirm && ((0, l.eventGa)("flow_guide_daily_send_click", "click"), wx.navigateTo({
                url: "/pages/webview?url=".concat(encodeURIComponent("https://mp.weixin.qq.com/s/_U6Icv_5_NyXeOv5zhV0nQ"))
            }));
        }
    });
}

Component({
    properties: {
        theme: {
            type: String,
            value: "default"
        }
    },
    data: {
        userDailyRemindHour: "8:00",
        userDailyRemindItems: h,
        calDateCursor: null,
        calLoading: !1,
        remindTipSeted: !1,
        scrollId: "",
        hasSubscribeOfficial: !1,
        enableDailyMessage: !1,
        total: "",
        tipHidden: !!wx.getStorageSync("addOneTipHidden")
    },
    behaviors: [ i.storeBindingsBehavior ],
    storeBindings: {
        store: s.default,
        fields: [ "subscribeState" ]
    },
    lifetimes: {
        attached: function() {
            var e = this;
            this.calendar = this.getCalendar(), this.renderCalendar(), setTimeout(function() {
                e.addObserver();
            }, 100);
        }
    },
    methods: {
        addObserver: function() {
            var e = this;
            this.data.calData.forEach(function(t, a) {
                e.createIntersectionObserver().relativeToViewport({
                    bottom: 0
                }).observe("#month-".concat(a), function(t) {
                    var a = t.dataset.index, n = e.data.calData.slice(a, a + 3), r = [];
                    if (!n[0] || !n[0]._remindFetching && !n[0]._remindFetched) {
                        for (var i = 0, s = n.length; i < s; i++) n[i]._remindFetching || n[i]._remindFetched || (n[i]._remindFetching = !0, 
                        r.push(n[i]));
                        e.fetchRelateData(r);
                    }
                });
            });
        },
        toggleSub: (0, n.singleExec)(t(e().mark(function t() {
            return e().wrap(function(e) {
                for (;;) switch (e.prev = e.next) {
                  case 0:
                    if (!this.data.subscribeState.daily) {
                        e.next = 6;
                        break;
                    }
                    return e.next = 4, (0, c.unsubscribe)(1);

                  case 4:
                    e.next = 8;
                    break;

                  case 6:
                    return e.next = 8, (0, c.subscribe)(1);

                  case 8:
                  case "end":
                    return e.stop();
                }
            }, t, this);
        }))),
        toggleDailyMessage: (0, n.singleExec)(t(e().mark(function t() {
            return e().wrap(function(e) {
                for (;;) switch (e.prev = e.next) {
                  case 0:
                    if (this.data.enableDailyMessage || this.data.hasSubscribeOfficial) {
                        e.next = 3;
                        break;
                    }
                    return (0, l.eventGa)("daily_send_open", "click"), e.abrupt("return", p());

                  case 3:
                    (0, l.eventGa)("daily_send_close", "click"), wx.showModal({
                        title: "提示",
                        content: "关注服务号即自动开启每日通知。早报将优先推送小程序通知，小程序通知次数需要点击 +1 手动增加，次数用完后将使用服务号推送通知。为避免无法接收订阅通知，建议保持关注服务号。",
                        confirmText: "知道了",
                        showCancel: !1
                    });

                  case 5:
                  case "end":
                    return e.stop();
                }
            }, t, this);
        }))),
        updateDailyMessage: function() {
            var a = this;
            return t(e().mark(function t() {
                var n, i, s, c;
                return e().wrap(function(e) {
                    for (;;) switch (e.prev = e.next) {
                      case 0:
                        return e.next = 2, (0, r.getReminderConfig)();

                      case 2:
                        c = e.sent, a.setData({
                            enableDailyMessage: !(null === (n = c.data) || void 0 === n || null === (i = n.items) || void 0 === i || null === (s = i[0]) || void 0 === s || !s.planMode)
                        });

                      case 4:
                      case "end":
                        return e.stop();
                    }
                }, t);
            }))();
        },
        fetchRelateData: function(n) {
            var i = this;
            return t(e().mark(function t() {
                var s, c, l;
                return e().wrap(function(e) {
                    for (;;) switch (e.prev = e.next) {
                      case 0:
                        if (e.prev = 0, 0 !== n.length) {
                            e.next = 3;
                            break;
                        }
                        return e.abrupt("return");

                      case 3:
                        return s = n[0].month, c = (0, a.default)(n[n.length - 1].month).endOf("month").toISOString(), 
                        e.next = 7, Promise.all([ (0, r.getReminderList)({
                            type: 3,
                            page: 1,
                            size: 100,
                            date_range: 4,
                            st: s,
                            et: c
                        }) ]);

                      case 7:
                        e.sent[0].data.items.forEach(function(e) {
                            var t = i.calendar.find(e.reminderTime);
                            t && (t.hasRemind = !0);
                        }), n.forEach(function(e) {
                            e._remindFetching = !1, e._remindFetched = !0;
                        }), i.data.remindTipSeted || (i.setData({
                            remindTipSeted: !0
                        }), l = 0, i.calendar.walkCal(n, function(e) {
                            return !!(!e.hasRemind && e.isAvaliable && "empty" !== e.type && ++l > 3 && (0, 
                            a.default)(e.date).isoWeekday() < 5);
                        })), i.renderCalendar(), e.next = 18;
                        break;

                      case 14:
                        e.prev = 14, e.t0 = e.catch(0), console.error(e.t0), n.forEach(function(e) {
                            e._remindFetching = !1;
                        });

                      case 18:
                      case "end":
                        return e.stop();
                    }
                }, t, null, [ [ 0, 14 ] ]);
            }))();
        },
        renderCalendar: function() {
            var e = this.calendar, t = e.calData, n = e.calHeader, r = t.findIndex(function(e) {
                return e.isCurrentMonth;
            }), i = t.slice(r, r + 12), s = this.calendar.findPostion((0, a.default)().toISOString());
            i[0]._hide_remind_row_when_less = s.row, this.setData({
                calData: i,
                calHeader: n
            });
        },
        getCalendar: function() {
            return getApp().globalData.calendar;
        },
        onBellAnimateEnd: function(e) {
            var t = e.currentTarget.dataset, a = t.month, n = t.row, r = t.index;
            this.data.calData[a].rows[n][r].animateBell = !1, this.renderCalendar();
        },
        createCalReminder: (m = t(e().mark(function t(n, i, s) {
            var c, l, d, o;
            return e().wrap(function(e) {
                for (;;) switch (e.prev = e.next) {
                  case 0:
                    return c = this.data, l = c.userDailyRemindHour, c.calData, d = parseInt(l.split(":")[0]), 
                    e.next = 4, (0, r.createReminder)({
                        type: 3,
                        reminder_time: (0, a.default)(n).startOf("day").add(d, "hour").toISOString()
                    });

                  case 4:
                    return (o = e.sent.data.items[0]) && this._attachRemindTocal([ o ], i, s), this.renderCalendar(), 
                    e.abrupt("return", o);

                  case 8:
                  case "end":
                    return e.stop();
                }
            }, t, this);
        })), function(e, t, a) {
            return m.apply(this, arguments);
        }),
        onTapCalCell: (0, n.singleExec)(function() {
            var a = t(e().mark(function t(a) {
                var n, r, i, s, c, d, o;
                return e().wrap(function(e) {
                    for (;;) switch (e.prev = e.next) {
                      case 0:
                        if (this.data.subscribeState.daily) {
                            e.next = 2;
                            break;
                        }
                        return e.abrupt("return", wx.showToast({
                            title: "请先开启订阅",
                            icon: "none"
                        }));

                      case 2:
                        if (n = a.currentTarget.dataset, r = n.month, i = n.row, s = n.index, c = this.data.calData, 
                        (d = c[r].rows[i][s]).isAvaliable && !d.hasRemind) {
                            e.next = 7;
                            break;
                        }
                        return e.abrupt("return");

                      case 7:
                        return (0, l.eventGa)("popup_sub_date_click", "", new Date(d.date).toLocaleString()), 
                        d.loading = !0, this.renderCalendar(), e.prev = 10, o = this.selectComponent(".subscribe"), 
                        e.next = 14, o.auth([ "DAILY" ]);

                      case 14:
                        if (1 !== e.sent.accept_tmpl_id.length) {
                            e.next = 18;
                            break;
                        }
                        return e.next = 18, this.createCalReminder(d.date, !0);

                      case 18:
                        e.next = 23;
                        break;

                      case 20:
                        e.prev = 20, e.t0 = e.catch(10), console.error(e.t0);

                      case 23:
                        return e.prev = 23, d.loading = !1, this.renderCalendar(), e.finish(23);

                      case 27:
                      case "end":
                        return e.stop();
                    }
                }, t, this, [ [ 10, 20, 23, 27 ] ]);
            }));
            return function(e) {
                return a.apply(this, arguments);
            };
        }()),
        getNextCalRemindAvaliableCell: function() {
            var e;
            return this.calendar.walkCal(function(t, a, n) {
                !n._remindFetched || "day" !== t.type || !t.isAvaliable || t.hasRemind || t.isToday || e || (e = t);
            }), e;
        },
        addNextRemindAvaliableDayRemindWithoutAuth: function() {
            var a = this;
            return t(e().mark(function t() {
                var n;
                return e().wrap(function(e) {
                    for (;;) switch (e.prev = e.next) {
                      case 0:
                        if (n = a.getNextCalRemindAvaliableCell(), e.prev = 1, n) {
                            e.next = 6;
                            break;
                        }
                        return e.next = 5, a.loadMoreCalData();

                      case 5:
                        n = a.getNextCalRemindAvaliableCell();

                      case 6:
                        if (!n) {
                            e.next = 11;
                            break;
                        }
                        return n.loading = !0, a.renderCalendar(), e.next = 11, a.createCalReminder(n.date, !0, !0);

                      case 11:
                        return e.prev = 11, n && (n.loading = !1, a.renderCalendar()), e.finish(11);

                      case 14:
                      case "end":
                        return e.stop();
                    }
                }, t, null, [ [ 1, , 11, 14 ] ]);
            }))();
        },
        addNextRemindAvaliableDayRemindWithReport: function() {
            (0, l.eventGa)("popup_sub_date_click"), wx.setStorage({
                key: "addOneTipHidden",
                data: !0
            }), this.setData({
                tipHidden: !0
            }), this.addNextRemindAvaliableDayRemind();
        },
        addNextRemindAvaliableDayRemind: (0, n.singleExec)(t(e().mark(function t() {
            var a, n, r;
            return e().wrap(function(e) {
                for (;;) switch (e.prev = e.next) {
                  case 0:
                    if (a = this.getNextCalRemindAvaliableCell(), console.log("getNextCalRemindAvaliableCell", a), 
                    a) {
                        e.next = 6;
                        break;
                    }
                    return e.next = 5, this.loadMoreCalData();

                  case 5:
                    a = this.getNextCalRemindAvaliableCell();

                  case 6:
                    return a && (a.loading = !0, this.renderCalendar()), e.prev = 7, n = this.selectComponent(".subscribe"), 
                    e.next = 11, n.auth([ "DAILY" ]);

                  case 11:
                    if (r = e.sent, !a || 1 !== r.accept_tmpl_id.length) {
                        e.next = 16;
                        break;
                    }
                    return e.next = 15, this.createCalReminder(a.date, !0, !0);

                  case 15:
                    this.updateTotal();

                  case 16:
                    return e.prev = 16, a && (a.loading = !1, this.renderCalendar()), e.finish(16);

                  case 19:
                  case "end":
                    return e.stop();
                }
            }, t, this, [ [ 7, , 16, 19 ] ]);
        }))),
        isNextDayRemindSet: function() {
            var e = !1;
            return this.calendar.walkCal(function(t) {
                "day" === t.type && (0, a.default)(t.date).isSame((0, a.default)().add(1, "day"), "date") && (e = t.hasRemind);
            }), e;
        },
        loadMoreCalData: (0, n.singleExec)(t(e().mark(function t() {
            var a, n, r, i;
            return e().wrap(function(e) {
                for (;;) switch (e.prev = e.next) {
                  case 0:
                    a = this.data.calData, n = [], r = 0, i = a.length;

                  case 3:
                    if (!(r < i)) {
                        e.next = 10;
                        break;
                    }
                    if (!(n.length >= 3)) {
                        e.next = 6;
                        break;
                    }
                    return e.abrupt("break", 10);

                  case 6:
                    a[r]._remindFetching || a[r]._remindFetched || (a[r]._remindFetching = !0, n.push(a[r]));

                  case 7:
                    r++, e.next = 3;
                    break;

                  case 10:
                    return e.next = 12, this.fetchRelateData(n);

                  case 12:
                  case "end":
                    return e.stop();
                }
            }, t, this);
        }))),
        _attachRemindTocal: function(e, t, a) {
            var n, r = this;
            0 !== e.length && (e.forEach(function(i, s) {
                var c = r.calendar.findPostion(i.reminderTime);
                if (c) {
                    var l = r.calendar.calData[c.month], d = l.rows[c.row][c.column];
                    d && (d.hasRemind = !0, d.animateBell = !!t, a && s === e.length - 1 && (n = "scroll-" + (Math.random() + 1).toString(36).substring(7), 
                    l.scrollId = n));
                }
            }), n && setTimeout(function() {
                r.setData({
                    scrollId: n
                });
            }, 50));
        },
        onTapCover: function() {
            this.triggerEvent("close");
        },
        hide: function() {
            this.selectComponent(".dialog").hide();
        },
        updateTotal: function() {
            var a = this;
            return t(e().mark(function t() {
                var n, r, i, s;
                return e().wrap(function(e) {
                    for (;;) switch (e.prev = e.next) {
                      case 0:
                        return e.next = 2, (0, o.fetchSubscribeTemplates)([ 3 ]);

                      case 2:
                        s = e.sent, a.setData({
                            total: (null === (n = s.data) || void 0 === n || null === (r = n.items) || void 0 === r || null === (i = r[0]) || void 0 === i ? void 0 : i.c) || ""
                        });

                      case 4:
                      case "end":
                        return e.stop();
                    }
                }, t);
            }))();
        },
        show: function(e) {
            var t = wx.getStorageSync(d.default.USER_KEY);
            this.updateTotal(), this.updateDailyMessage(), this.setData({
                hasSubscribeOfficial: !!t.officialAccountSubscribed
            }), this.selectComponent(".dialog").show(e);
        }
    }
});