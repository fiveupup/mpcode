var e = require("../../@babel/runtime/helpers/regeneratorRuntime"), r = require("../../@babel/runtime/helpers/asyncToGenerator"), t = require("../../service/user"), n = require("@mina-modules/mina-sentry");

function a(e) {
    return e.nickName ? !!e.avatarUrl || (wx.showToast({
        title: "请设置头像",
        icon: "none"
    }), !1) : (wx.showToast({
        title: "请输入昵称",
        icon: "none"
    }), !1);
}

Component({
    properties: {
        nickName: String,
        avatar: String
    },
    data: {
        visible: !1
    },
    methods: {
        getUserProfile: function() {
            var t = this;
            return r(e().mark(function r() {
                var n, a;
                return e().wrap(function(e) {
                    for (;;) switch (e.prev = e.next) {
                      case 0:
                        if (r = "2.27.1", !(function(e, r) {
                            e = e.split("."), r = r.split(".");
                            var t = Math.max(e.length, r.length);
                            for (;e.length < t; ) e.push("0");
                            for (;r.length < t; ) r.push("0");
                            for (var n = 0; n < t; n++) {
                                var a = parseInt(e[n]), s = parseInt(r[n]);
                                if (a > s) return 1;
                                if (a < s) return -1;
                            }
                            return 0;
                        }(wx.getSystemInfoSync().SDKVersion, r) >= 0)) {
                            e.next = 3;
                            break;
                        }
                        return t.setData({
                            visible: !0
                        }), e.abrupt("return", null);

                      case 3:
                        return e.next = 5, wx.getUserProfile({
                            lang: "zh_CN",
                            desc: "授权用户昵称、头像"
                        });

                      case 5:
                        return n = e.sent, a = n.userInfo, e.abrupt("return", a);

                      case 8:
                      case "end":
                        return e.stop();
                    }
                    var r;
                }, r);
            }))();
        },
        onClose: function() {
            this.setData({
                visible: !1
            }), this.triggerEvent("close");
        },
        onChooseAvatar: function(t) {
            var n = this;
            return r(e().mark(function r() {
                var a, s, i, o, c, u;
                return e().wrap(function(e) {
                    for (;;) switch (e.prev = e.next) {
                      case 0:
                        return a = t.detail.avatarUrl, e.next = 3, wx.getImageInfo({
                            src: a
                        });

                      case 3:
                        if (s = e.sent, i = s.width, o = s.height, i === o) {
                            e.next = 12;
                            break;
                        }
                        return e.next = 9, new Promise(function(e, r) {
                            wx.cropImage({
                                src: a,
                                cropScale: "1:1",
                                success: e,
                                fail: r
                            });
                        });

                      case 9:
                        c = e.sent, u = c.tempFilePath, a = u;

                      case 12:
                        n.setData({
                            avatar: a
                        });

                      case 13:
                      case "end":
                        return e.stop();
                    }
                }, r);
            }))();
        },
        onChangeNickName: function(e) {
            this.setData({
                nickName: e.detail.value
            });
        },
        onSubmit: function() {
            var s = this;
            return r(e().mark(function r() {
                var i, o, c, u, l;
                return e().wrap(function(e) {
                    for (;;) switch (e.prev = e.next) {
                      case 0:
                        if (a(i = {
                            avatarUrl: s.data.avatar,
                            nickName: s.data.nickName
                        })) {
                            e.next = 3;
                            break;
                        }
                        return e.abrupt("return");

                      case 3:
                        if (e.prev = 3, wx.showLoading(), !/^wxfile:/.test(i.avatarUrl)) {
                            e.next = 16;
                            break;
                        }
                        return e.next = 8, wx.compressImage({
                            src: i.avatarUrl,
                            compressedWidth: 132,
                            compressedHeight: 132
                        });

                      case 8:
                        return o = e.sent, c = o.tempFilePath, e.next = 12, (0, t.uploadUserAvatar)(c);

                      case 12:
                        u = e.sent, l = u.url, u.isChecked && (i.avatarUrl = l);

                      case 16:
                        wx.hideLoading(), s.triggerEvent("userprofile", {
                            userInfo: i
                        }), s.onClose(), e.next = 25;
                        break;

                      case 21:
                        e.prev = 21, e.t0 = e.catch(3), (0, n.error)(e.t0), wx.showToast({
                            title: "授权失败",
                            icon: "none"
                        });

                      case 25:
                      case "end":
                        return e.stop();
                    }
                }, r, null, [ [ 3, 21 ] ]);
            }))();
        }
    }
});