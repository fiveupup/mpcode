!function(t, r) {
    if (!r && t && t.__esModule) return t;
    if (null === t || "object" != typeof t && "function" != typeof t) return {
        default: t
    };
    var n = e(r);
    if (n && n.has(t)) return n.get(t);
    var a = {}, o = Object.defineProperty && Object.getOwnPropertyDescriptor;
    for (var u in t) if ("default" !== u && Object.prototype.hasOwnProperty.call(t, u)) {
        var i = o ? Object.getOwnPropertyDescriptor(t, u) : null;
        i && (i.get || i.set) ? Object.defineProperty(a, u, i) : a[u] = t[u];
    }
    a.default = t, n && n.set(t, a);
}(require("../../utils/lodash"));

function e(t) {
    if ("function" != typeof WeakMap) return null;
    var r = new WeakMap(), n = new WeakMap();
    return (e = function(e) {
        return e ? n : r;
    })(t);
}

Component({
    externalClasses: [ "custom-class" ],
    properties: {
        theme: String,
        entityList: {
            type: Array,
            value: []
        },
        tagList: {
            type: Array,
            value: []
        }
    }
});