!function(t, n) {
    if (!n && t && t.__esModule) return t;
    if (null === t || "object" != typeof t && "function" != typeof t) return {
        default: t
    };
    var r = e(n);
    if (r && r.has(t)) return r.get(t);
    var o = {}, u = Object.defineProperty && Object.getOwnPropertyDescriptor;
    for (var i in t) if ("default" !== i && Object.prototype.hasOwnProperty.call(t, i)) {
        var f = u ? Object.getOwnPropertyDescriptor(t, i) : null;
        f && (f.get || f.set) ? Object.defineProperty(o, i, f) : o[i] = t[i];
    }
    o.default = t, r && r.set(t, o);
}(require("../../utils/lodash"));

function e(t) {
    if ("function" != typeof WeakMap) return null;
    var n = new WeakMap(), r = new WeakMap();
    return (e = function(e) {
        return e ? r : n;
    })(t);
}

Component({
    data: {
        authed: !0
    },
    methods: {
        show: function() {},
        hide: function() {},
        needLogin: function() {
            return !1;
        }
    }
});