Component({
    data: {
        isShow: !1
    },
    methods: {
        catchTap: function() {},
        hide: function() {
            this.setData({
                isShow: !1
            }), this.triggerEvent("hide");
        },
        show: function() {
            this.setData({
                isShow: !0
            });
        },
        goToSub: function() {
            this.hide(), wx.setStorage({
                key: "subDailyIfOfficialSubed",
                data: !0
            }), wx.navigateTo({
                url: "/pages/webview?url=".concat(encodeURIComponent("https://mp.weixin.qq.com/s/-gYRc6wByv5VyP8LiW_NUg"))
            });
        },
        copy: function() {
            wx.setClipboardData({
                data: "Readhub",
                success: function() {
                    wx.showToast({
                        title: "已复制",
                        icon: "none",
                        duration: 500
                    });
                }
            }), this.hide();
        }
    }
});