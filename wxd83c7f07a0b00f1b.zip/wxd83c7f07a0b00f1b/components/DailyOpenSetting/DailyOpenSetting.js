var e, t = require("mobx-miniprogram-bindings"), i = (e = require("../../store/app")) && e.__esModule ? e : {
    default: e
}, s = require("../../service/analyse");

Component({
    data: {
        forceHide: !1
    },
    behaviors: [ t.storeBindingsBehavior ],
    storeBindings: {
        store: i.default,
        fields: [ "subscribeState", "isDailyReject" ],
        actions: {}
    },
    lifetimes: {
        ready: function() {
            var e = getApp().temp("daily_close_time"), t = !1;
            e && Date.now() - e < 6048e5 && (t = !0), console.log("daily open setting forceHide", t), 
            this.setData({
                forceHide: t
            });
        }
    },
    methods: {
        close: function() {
            getApp().temp("daily_close_time", Date.now()), this.setData({
                forceHide: !0
            });
        },
        checkAndShowNotice: function() {
            var e = getApp().getSubscribeTemplatesByName([ "DAILY" ]);
            e[0] && (e[0].c >= 7 || (console.log("isDailyReject", i.default.isDailyReject), 
            !i.default.isDailyReject && this.data.subscribeState.daily && this.selectComponent(".subscribeMessage").showNotice("DAILY", "RENEW", "submessage_daily_authorize")));
        },
        tryOpenSetting: function() {
            var e = this;
            (0, s.report)("submessage_reject_notice"), wx.showModal({
                title: "提示",
                content: "请到小程序设置页面打开相关授权",
                success: function(t) {
                    t.confirm && ((0, s.report)("submessage_reject_authorize"), wx.openSetting({
                        withSubscriptions: !0,
                        success: function(t) {
                            t.authSetting && (i.default.changeMinaSetting(t), setTimeout(function() {
                                e.checkAndShowNotice();
                            }, 350));
                        }
                    }));
                }
            });
        }
    }
});