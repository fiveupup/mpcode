var e = require("../../@babel/runtime/helpers/slicedToArray"), t = require("../../libs/audioManager"), a = s(require("dayjs")), i = s(require("../../libs/duration")), r = require("../../service/analyse"), n = require("../../utils/cache");

function s(e) {
    return e && e.__esModule ? e : {
        default: e
    };
}

var u = [ 1, 1.25, 1.5, 2 ];

function o(e, t, a) {
    return e <= t ? 0 : e >= t + a ? 100 : (e - t) / a * 100;
}

a.default.extend(i.default), Component({
    properties: {
        item: Object,
        theme: String
    },
    data: {
        widthPercentage: 0,
        isPause: !0,
        isHover: !1,
        duration: "",
        currentTime: "",
        rate: 0
    },
    observers: {
        item: function(e) {
            e.audioFile && ((0, r.report)("daily_voice_show", {
                label: (0, n.getGlobalFlag)()
            }), (0, n.getGlobalFlag)("2"), this.setData({
                currentTime: "00:00",
                duration: e.audioFileDuration
            }));
        }
    },
    manager: null,
    methods: {
        stepSeek: function(e, t, i, r) {
            var n = a.default.duration({
                minutes: e,
                seconds: t
            }).add(i, "seconds").format("mm:ss"), s = function(e, t) {
                if (e <= 0) return 0;
                if (e >= t) return 100;
                return e / t * 100;
            }(60 * e + t + i, r), u = this.manager.duration * s / 100;
            this.setData({
                currentTime: n,
                widthPercentage: s
            }), this.manager.seek(u);
        },
        onBackward: function() {
            var t = this.data.currentTime.split(":"), a = e(t, 2), i = a[0], r = a[1], n = this.data.duration.split(":"), s = e(n, 2), u = s[0], o = s[1];
            60 * Number(i) + Number(r) + -15 < 0 || this.stepSeek(Number(i), Number(r), -15, 60 * Number(u) + Number(o));
        },
        onForward: function() {
            var t = this.data.currentTime.split(":"), a = e(t, 2), i = a[0], r = a[1], n = this.data.duration.split(":"), s = e(n, 2), u = s[0], o = s[1], d = 60 * Number(i) + Number(r) + 15, h = 60 * Number(u) + Number(o);
            d > h || this.stepSeek(Number(i), Number(r), 15, h);
        },
        onChangeRate: function() {
            var e = (this.data.rate + 1) % u.length;
            this.manager.setPlaybackRate(u[e]), this.setData({
                rate: e
            });
        },
        initManager: function() {
            this.manager || (this.manager = t.AudioManager.getInstance(this.data.item.audioFile, this.syncStatus.bind(this), !1), 
            this.manager.duration && this.manager.watch());
        },
        onStart: function() {
            (0, r.report)("daily_voice_click"), this.setData({
                isHover: !0
            }), this.initManager(), this.manager.watchOff();
        },
        onMove: function(e) {
            var t = o(e.changedTouches[0].pageX, this.left, this.width), i = this.manager.duration * t / 100, r = a.default.duration(1e3 * i).format("mm:ss");
            this.setData({
                currentTime: r,
                widthPercentage: t
            });
        },
        onEnd: function(e) {
            var t = o(e.changedTouches[0].pageX, this.left, this.width), i = this.manager.duration * t / 100, r = a.default.duration(1e3 * i).format("mm:ss");
            this.setData({
                currentTime: r,
                widthPercentage: t,
                isHover: !1
            }), this.manager.seek(i);
        },
        onPlay: function() {
            (0, r.report)("daily_voice_click"), this.data.widthPercentage < 1 && (0, r.report)("voice_play", {
                label: this.data.item.audioFile
            }), console.log("audio play"), this.initManager(), this.manager.isEnd() ? this.manager.replay() : this.manager.play(), 
            this.setData({
                isPause: !1
            });
        },
        onPause: function() {
            (0, r.report)("daily_voice_click"), console.log("audio pause"), this.initManager(), 
            this.manager.pause(), this.setData({
                isPause: !0
            });
        },
        syncStatus: function(e) {
            var t = a.default.duration(1e3 * e.duration || 0).format("mm:ss"), i = a.default.duration(1e3 * e.currentTime || 0).format("mm:ss"), r = e.currentTime / e.duration * 100, n = e.paused, s = u.indexOf(this.manager.getPlaybackRate() || 1);
            this.setData({
                duration: t,
                currentTime: i,
                widthPercentage: r,
                isPause: n,
                rate: s
            });
        }
    },
    lifetimes: {
        detached: function() {
            var e;
            null === (e = this.manager) || void 0 === e || e.watchOff();
        },
        attached: function() {
            var e = this;
            this.manager && (this.manager.updateSyncStatus(this.syncStatus.bind(this)), this.manager.watch()), 
            this.createSelectorQuery().select(".progressBar").boundingClientRect().exec(function(t) {
                t[0] && (e.left = t[0].left, e.width = t[0].width);
            });
        }
    }
});