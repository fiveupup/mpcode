var e = require("../../../@babel/runtime/helpers/regeneratorRuntime"), t = require("../../../@babel/runtime/helpers/asyncToGenerator"), n = require("../../../service/pro");

Component({
    data: {
        image: "",
        imageLoaded: !1
    },
    properties: {
        theme: {
            type: String,
            value: ""
        },
        desc: {
            type: String,
            value: ""
        }
    },
    methods: {
        onImageLoaded: function() {
            this.setData({
                imageLoaded: !0
            });
        },
        show: function() {
            var r = this;
            return t(e().mark(function t() {
                var a;
                return e().wrap(function(e) {
                    for (;;) switch (e.prev = e.next) {
                      case 0:
                        if (a = r.data.image) {
                            e.next = 7;
                            break;
                        }
                        return wx.showLoading(), e.next = 5, (0, n.getProInviteImage)();

                      case 5:
                        a = e.sent, wx.hideLoading();

                      case 7:
                        if (a) {
                            e.next = 9;
                            break;
                        }
                        return e.abrupt("return", wx.showToast({
                            title: "分享图生成失败",
                            icon: "none"
                        }));

                      case 9:
                        r.setData({
                            image: a
                        }, function() {
                            r.selectComponent(".dialog").show();
                        });

                      case 10:
                      case "end":
                        return e.stop();
                    }
                }, t);
            }))();
        },
        hide: function() {
            this.selectComponent(".dialog").hide();
        }
    }
});