var e, r = require("../../../@babel/runtime/helpers/regeneratorRuntime"), t = require("../../../@babel/runtime/helpers/asyncToGenerator"), n = function(e, r) {
    if (!r && e && e.__esModule) return e;
    if (null === e || "object" != typeof e && "function" != typeof e) return {
        default: e
    };
    var t = p(r);
    if (t && t.has(e)) return t.get(e);
    var n = {}, i = Object.defineProperty && Object.getOwnPropertyDescriptor;
    for (var a in e) if ("default" !== a && Object.prototype.hasOwnProperty.call(e, a)) {
        var s = i ? Object.getOwnPropertyDescriptor(e, a) : null;
        s && (s.get || s.set) ? Object.defineProperty(n, a, s) : n[a] = e[a];
    }
    n.default = e, t && t.set(e, n);
    return n;
}(require("../../../utils/lodash")), i = (e = require("../../../store/app")) && e.__esModule ? e : {
    default: e
}, a = require("../../../service/user"), s = require("../../../utils/functional"), o = require("../../../service/pro"), u = require("../../../utils/mina"), c = require("../../../service/promotion");

function p(e) {
    if ("function" != typeof WeakMap) return null;
    var r = new WeakMap(), t = new WeakMap();
    return (p = function(e) {
        return e ? t : r;
    })(e);
}

Component({
    data: {
        sub: null,
        isIOS: (0, u.isIOS)(),
        freeVipInfo: null,
        canJoinFree: !0
    },
    properties: {
        theme: {
            type: String,
            value: ""
        }
    },
    methods: {
        fetchFreeVipInfo: function() {
            var e = this;
            return t(r().mark(function t() {
                var i, a, s;
                return r().wrap(function(r) {
                    for (;;) switch (r.prev = r.next) {
                      case 0:
                        return r.prev = 0, r.next = 3, (0, c.getFreeVipInfo)();

                      case 3:
                        i = r.sent, a = n.get(i, "data.items[0]", null), s = !0, !a.hasJoin && a.newUser || (s = !1), 
                        e.setData({
                            freeVipInfo: a,
                            canJoinFree: s
                        }), r.next = 14;
                        break;

                      case 10:
                        r.prev = 10, r.t0 = r.catch(0), console.error(r.t0), e.setData({
                            freeVipInfo: null
                        });

                      case 14:
                      case "end":
                        return r.stop();
                    }
                }, t, null, [ [ 0, 10 ] ]);
            }))();
        },
        entitySubscribe: (0, s.singleExec)(function() {
            var e = t(r().mark(function e(t) {
                var a, s;
                return r().wrap(function(e) {
                    for (;;) switch (e.prev = e.next) {
                      case 0:
                        if (e.prev = 0, !(a = this.data.sub)) {
                            e.next = 11;
                            break;
                        }
                        return e.next = 5, (0, o.subscribeEntity)(a);

                      case 5:
                        if ((s = e.sent).subscription) {
                            e.next = 8;
                            break;
                        }
                        throw new Error("订阅失败");

                      case 8:
                        n.assign(a, s.subscription), i.default.addProSub(a), this.triggerEvent("subed", a);

                      case 11:
                        e.next = 16;
                        break;

                      case 13:
                        e.prev = 13, e.t0 = e.catch(0), console.error(e.t0);

                      case 16:
                      case "end":
                        return e.stop();
                    }
                }, e, this, [ [ 0, 13 ] ]);
            }));
            return function(r) {
                return e.apply(this, arguments);
            };
        }()),
        payAndSubscribe: (0, s.singleExec)(t(r().mark(function e() {
            var t, s, o;
            return r().wrap(function(e) {
                for (;;) switch (e.prev = e.next) {
                  case 0:
                    if (!(0, u.isSinglePageMode)()) {
                        e.next = 2;
                        break;
                    }
                    return e.abrupt("return", wx.showToast({
                        title: "请前往小程序使用完整服务",
                        icon: "none"
                    }));

                  case 2:
                    if (wx.showLoading(), !this.data.freeVipInfo || !this.data.canJoinFree) {
                        e.next = 13;
                        break;
                    }
                    return e.next = 6, (0, c.joinFreeVip)();

                  case 6:
                    if (t = e.sent, n.get(t, "data.items[0]")) {
                        e.next = 11;
                        break;
                    }
                    throw this.fetchFreeVipInfo(), new Error("免费试订失败");

                  case 11:
                    e.next = 17;
                    break;

                  case 13:
                    return e.next = 15, (0, a.pay)("mina_pro_content");

                  case 15:
                    s = e.sent, console.log(s);

                  case 17:
                    return (o = i.default.userInfo).isVip = !0, i.default.changeUserInfo(o), e.next = 22, 
                    getApp().getUserSubscription();

                  case 22:
                    return e.next = 24, this.entitySubscribe();

                  case 24:
                    this.triggerEvent("joinSuccess", {
                        isEnterSearch: !1
                    }), wx.hideLoading(), this.hide();

                  case 27:
                  case "end":
                    return e.stop();
                }
            }, e, this);
        }))),
        show: function(e) {
            getApp()._sub = e || null, wx.navigateTo({
                url: "/pages/pro/join"
            });
        },
        hide: function() {
            this.selectComponent(".dialog").hide();
        }
    }
});