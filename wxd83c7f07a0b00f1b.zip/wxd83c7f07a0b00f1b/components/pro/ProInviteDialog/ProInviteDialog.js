var e = require("../../../utils/tools"), t = require("../../../service/analyse");

Component({
    data: {
        path: ""
    },
    properties: {
        theme: {
            type: String,
            value: ""
        }
    },
    lifetimes: {
        ready: function() {
            var t = getCurrentPages(), i = t[t.length - 1], n = i.options, o = (0, e.queryString)(n), s = "/" + i.route + (o ? "?" + o + "&func_subscribe_entrance=invite_subscribe" : "?func_subscribe_entrance=invite_subscribe");
            this.setData({
                path: s
            });
        }
    },
    methods: {
        show: function(e) {
            this.showImage();
        },
        onHide: function() {
            (0, t.report)("invite_pop_close");
        },
        hide: function() {
            this.selectComponent(".dialog").hide();
        },
        onContact: function() {
            (0, t.report)("invite_pop_click"), this.hide();
        },
        showImage: function() {
            (0, t.report)("invite_pop_click"), this.hide(), this.selectComponent(".invite-image").show();
        }
    }
});