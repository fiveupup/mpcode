var e = require("../../../utils/tools"), t = require("../../../service/analyse");

Component({
    data: {
        path: "/pages/pro/subscription?func_subscribe_entrance=invite_subscribe"
    },
    properties: {
        theme: {
            type: String,
            value: ""
        }
    },
    externalClasses: [ "custom-class" ],
    lifetimes: {
        ready: function() {
            var t = getCurrentPages(), s = t[t.length - 1], i = s.options, r = (0, e.queryString)(i), n = "/" + s.route + (r ? "?" + r + "&func_subscribe_entrance=invite_subscribe" : "?func_subscribe_entrance=invite_subscribe");
            this.setData({
                path: n
            });
        }
    },
    methods: {
        onTap: function() {
            (0, t.report)("pro_invite");
        },
        showImage: function() {
            (0, t.report)("pro_invite"), this.selectComponent(".invite-image").show();
        }
    }
});