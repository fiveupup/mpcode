var e = require("../../service/analyse");

Component({
    properties: {
        theme: String
    },
    methods: {
        onReport: function() {
            (0, e.report)("daily_middle_assistant_qr_click");
        }
    }
});