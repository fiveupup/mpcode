var e = require("../../@babel/runtime/helpers/slicedToArray");

Component({
    externalClasses: [ "class" ],
    options: {
        multipleSlots: !0
    },
    data: {
        isEllipsis: !1
    },
    properties: {
        content: {
            type: String,
            value: ""
        },
        lines: {
            type: Number,
            value: 0
        }
    },
    observers: {
        "content, lines": function(t, i) {
            var n = this;
            wx.nextTick(function() {
                wx.createSelectorQuery().in(n).selectAll(".clamp, .content").boundingClientRect(function(t) {
                    var i = e(t, 2), s = i[0], l = i[1];
                    n.setData({
                        isEllipsis: l.height > s.height
                    });
                }).exec();
            });
        }
    }
});