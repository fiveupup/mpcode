var e = require("../../@babel/runtime/helpers/regeneratorRuntime"), t = require("../../@babel/runtime/helpers/asyncToGenerator"), n = require("../../service/news"), r = require("../../service/analyse");

Component({
    properties: {
        uid: String,
        theme: String
    },
    data: {
        items: []
    },
    methods: {
        onClick: function() {
            (0, r.eventGa)("news_extension_click", "click");
        },
        onFooterShow: function() {
            (0, r.eventGa)("news_extension_show", "show");
        }
    },
    lifetimes: {
        attached: function() {
            var r = this;
            return t(e().mark(function t() {
                var i;
                return e().wrap(function(e) {
                    for (;;) switch (e.prev = e.next) {
                      case 0:
                        return e.next = 2, (0, n.fetchRelatedTopics)(r.data.uid);

                      case 2:
                        i = e.sent, r.setData({
                            items: i
                        });

                      case 4:
                      case "end":
                        return e.stop();
                    }
                }, t);
            }))();
        }
    }
});