var e = require("../../@babel/runtime/helpers/regeneratorRuntime"), t = require("../../@babel/runtime/helpers/asyncToGenerator"), i = require("mobx-miniprogram-bindings"), n = o(require("../../store/app")), r = require("../../service/analyse"), a = o(require("../../config"));

function o(e) {
    return e && e.__esModule ? e : {
        default: e
    };
}

Component({
    properties: {
        theme: {
            type: String,
            value: "default"
        }
    },
    data: {
        activeType: "NEWS_UPDATE",
        hasSubscribeOfficial: !1,
        tipHidden: !!wx.getStorageSync("addOneTipHidden")
    },
    behaviors: [ i.storeBindingsBehavior ],
    storeBindings: {
        store: n.default,
        fields: [ "templates", "subscribeState" ]
    },
    methods: {
        onCheckSubscribeOfficial: function() {
            if (this.data.hasSubscribeOfficial) return (0, r.eventGa)("popup_prosub_open_v1", "click"), 
            wx.showToast({
                title: "已开启"
            });
            (0, r.eventGa)("flow_guide_daily_send", "show"), wx.showModal({
                content: "关注 Readhub 服务号，即可通过服务号长期接收订阅通知。",
                confirmText: "去关注",
                confirmColor: "#0DAC5D",
                success: function(e) {
                    e.confirm && ((0, r.eventGa)("flow_guide_daily_send_click", "click"), wx.navigateTo({
                        url: "/pages/webview?url=".concat(encodeURIComponent("https://mp.weixin.qq.com/s/_U6Icv_5_NyXeOv5zhV0nQ"))
                    }));
                }
            });
        },
        noticeAuth: function() {
            var i = this;
            return t(e().mark(function t() {
                var n, a, o;
                return e().wrap(function(e) {
                    for (;;) switch (e.prev = e.next) {
                      case 0:
                        return (0, r.eventGa)("popup_prosub_click_v1", "click"), wx.setStorage({
                            key: "addOneTipHidden",
                            data: !0
                        }), i.setData({
                            tipHidden: !0
                        }), n = [ i.data.activeType ], "RENEW", (a = getApp().getSubscribeTemplatesByName([ "RENEW" ]))[0] && !a[0].c && n.push("RENEW"), 
                        o = i.selectComponent(".subscribe"), e.next = 10, o.auth(n, !1, !0, !0);

                      case 10:
                      case "end":
                        return e.stop();
                    }
                }, t);
            }))();
        },
        hide: function() {
            this.selectComponent(".dialog").hide();
        },
        show: function(e) {
            (0, r.eventGa)("popup_prosub_show_v1", "show");
            var t = wx.getStorageSync(a.default.USER_KEY);
            this.setData({
                hasSubscribeOfficial: !!t.officialAccountSubscribed
            }), this.selectComponent(".dialog").show(e);
        }
    }
});