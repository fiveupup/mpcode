var e = require("../../@babel/runtime/helpers/regeneratorRuntime"), t = require("../../@babel/runtime/helpers/asyncToGenerator"), r = require("../../service/app"), n = require("../../utils/functional");

Component({
    data: {
        payed: !1,
        list: [ {
            icn: "https://resource.nocode.com/readhub/pic-cola@3x.png",
            desc: "赏可乐 ¥2.8",
            amount: 280
        }, {
            icn: "https://resource.nocode.com/readhub/pic-icecream@3x.png",
            desc: "冰激凌 ¥8.8",
            amount: 880
        }, {
            icn: "https://resource.nocode.com/readhub/pic-milktea@3x.png",
            desc: "送奶茶 ¥18",
            amount: 1800
        }, {
            icn: "https://resource.nocode.com/readhub/pic-coffee@3x.png",
            desc: "请咖啡 ¥38",
            amount: 3800
        } ]
    },
    methods: {
        show: function() {
            this.selectComponent(".dialog").show();
        },
        hide: function() {
            this.setData({
                payed: !1
            }), this.selectComponent(".dialog").hide();
        },
        reward: (0, n.singleExec)(function() {
            var n = t(e().mark(function t(n) {
                var a, o, s, i;
                return e().wrap(function(e) {
                    for (;;) switch (e.prev = e.next) {
                      case 0:
                        return e.prev = 0, a = n.currentTarget.dataset.index, o = this.data.list[a], e.next = 5, 
                        (0, r.payReward)({
                            open_id: getApp().globalData.userInfo.openId,
                            price: o.amount
                        });

                      case 5:
                        return s = e.sent, wx.showLoading(), (i = s.data.items[0].requestInfo).timeStamp = "" + i.timeStamp, 
                        e.next = 11, wx.requestPayment(i);

                      case 11:
                        wx.hideLoading(), this.setData({
                            payed: !0
                        }), this.triggerEvent("reward"), e.next = 23;
                        break;

                      case 16:
                        if (e.prev = 16, e.t0 = e.catch(0), console.error(e.t0), wx.hideLoading(), "requestPayment:fail cancel" !== e.t0.errMsg) {
                            e.next = 22;
                            break;
                        }
                        return e.abrupt("return");

                      case 22:
                        wx.showToast({
                            title: e.t0.message,
                            icon: "none"
                        });

                      case 23:
                      case "end":
                        return e.stop();
                    }
                }, t, this, [ [ 0, 16 ] ]);
            }));
            return function(e) {
                return n.apply(this, arguments);
            };
        }())
    }
});