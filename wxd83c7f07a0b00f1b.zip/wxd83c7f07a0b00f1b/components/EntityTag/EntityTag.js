Component({
    properties: {
        theme: String,
        active: Boolean,
        customStyle: String
    }
});