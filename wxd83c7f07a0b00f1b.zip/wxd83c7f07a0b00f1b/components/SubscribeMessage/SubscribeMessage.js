var e = require("../../@babel/runtime/helpers/toConsumableArray"), t = require("../../@babel/runtime/helpers/regeneratorRuntime"), r = require("../../@babel/runtime/helpers/asyncToGenerator"), n = require("../../service/subscribe"), a = require("../../utils/functional"), i = require("mobx-miniprogram-bindings"), s = p(require("../../store/app")), c = p(require("../../behavior/computed")), u = require("../../service/analyse");

function p(e) {
    return e && e.__esModule ? e : {
        default: e
    };
}

Component({
    data: {
        showTip: !1,
        activeType: "NEWS_UPDATE",
        subType: "",
        titles: [ "避免无法收到订阅通知", "请增加订阅次数" ],
        tip: "开启通知，接收推送"
    },
    behaviors: [ i.storeBindingsBehavior, c.default ],
    storeBindings: {
        store: s.default,
        fields: [ "theme", "templates", "userInfo" ],
        actions: {
            changeTemplates: "changeTemplates"
        }
    },
    properties: {
        header: {
            type: Array,
            value: null,
            observer: function(e) {
                e && e.length > 0 && this.setData({
                    titles: e
                });
            }
        }
    },
    computed: {
        barStyle: function() {
            var e = this;
            if (!this.data.activeType || !this.data.templates) return "";
            var t = this.data.templates.find(function(t) {
                return t.typeName === e.data.activeType;
            });
            return t ? "width: ".concat(100 - Math.min(Math.ceil(100 * t.c / 180), 100), "%;") : "";
        }
    },
    methods: {
        noticeAuth: (0, a.singleExec)(r(t().mark(function e() {
            var r, n, a;
            return t().wrap(function(e) {
                for (;;) switch (e.prev = e.next) {
                  case 0:
                    return r = [ this.data.activeType ], this.data.subType && (n = getApp().getSubscribeTemplatesByName([ this.data.subType ]))[0] && !n[0].c && r.push(this.data.subType), 
                    e.next = 4, this.auth(r, !1, !0, !0);

                  case 4:
                    a = e.sent, "DAILY" === this.data.activeType && 1 === a.accept_tmpl_id.length && this.triggerEvent("createRemind");

                  case 6:
                  case "end":
                    return e.stop();
                }
            }, e, this);
        }))),
        checkAndShowNotice: function(e) {},
        authAfterSubscribe: (0, a.singleExec)(r(t().mark(function e() {
            var r, n;
            return t().wrap(function(e) {
                for (;;) switch (e.prev = e.next) {
                  case 0:
                    return r = [ "NEWS_UPDATE" ], (n = getApp().getSubscribeTemplatesByName([ "RENEW" ]))[0] && !n[0].c && r.push("RENEW"), 
                    e.next = 5, this.auth(r);

                  case 5:
                    return e.abrupt("return", e.sent);

                  case 6:
                  case "end":
                    return e.stop();
                }
            }, e, this);
        }))),
        authAfterSubscribeDaily: (0, a.singleExec)(r(t().mark(function e() {
            var r, n;
            return t().wrap(function(e) {
                for (;;) switch (e.prev = e.next) {
                  case 0:
                    return r = [ "DAILY" ], (n = getApp().getSubscribeTemplatesByName([ "RENEW" ]))[0] && !n[0].c && r.push("RENEW"), 
                    e.next = 5, this.auth(r);

                  case 5:
                    return e.abrupt("return", e.sent);

                  case 6:
                  case "end":
                    return e.stop();
                }
            }, e, this);
        }))),
        onNoticeHide: function() {
            this.setData({
                reportName: ""
            });
        },
        showNotice: function(e, t, r) {
            var n = this;
            console.log("showNotice", e, t), this.setData({
                activeType: e,
                subType: t || "",
                reportName: r || ""
            }, function() {
                n.selectComponent(".dialog").show();
            });
        },
        auth: (0, a.singleExec)(function() {
            var a = r(t().mark(function r(a, i, c, p) {
                var o, h, l, m, f, b, d, g, y, v, N, T, x, S, w, E, A = this;
                return t().wrap(function(t) {
                    for (;;) switch (t.prev = t.next) {
                      case 0:
                        return this.data.reportName && (0, u.report)(this.data.reportName), o = getApp().getSubscribeTemplatesByName(a), 
                        h = s.default.templates, l = [], m = [], f = [], b = [], t.next = 9, getApp().getMinaSetting();

                      case 9:
                        if (d = t.sent, console.log("setting", d), g = !0, y = !0, d && d.subscriptionsSetting && (d.subscriptionsSetting.mainSwitch ? d.subscriptionsSetting.itemSettings && h.forEach(function(e) {
                            var t = d.subscriptionsSetting.itemSettings[e.tmplId];
                            t && "accept" !== t && m.push(e.tmplId), a.indexOf(e.typeName) > -1 && t && (g = !1, 
                            "accept" === t ? f.push(e.typeName) : "ban" !== t && "reject" !== t || b.push(e.typeName));
                        }) : (g = !1, y = !1, m = o.map(function(e) {
                            return e.tmplId;
                        }))), console.log("showTip", g, "slient", i, "current_accept_ids", f, "types", a, "ban_tmpl_id", m), 
                        !i) {
                            t.next = 22;
                            break;
                        }
                        if (!g) {
                            t.next = 18;
                            break;
                        }
                        return t.abrupt("return");

                      case 18:
                        if (0 !== f.length) {
                            t.next = 20;
                            break;
                        }
                        return t.abrupt("return");

                      case 20:
                        a = f, o = getApp().getSubscribeTemplatesByName(f);

                      case 22:
                        if (g || !(b.length > 0) && y || !p) {
                            t.next = 24;
                            break;
                        }
                        return t.abrupt("return", wx.showModal({
                            title: "提示",
                            content: "需要授权订阅消息，请到小程序设置页面打开相关授权",
                            success: function(e) {
                                e.confirm && wx.openSetting();
                            }
                        }));

                      case 24:
                        return f.length > 0 && (f.forEach(function(e) {
                            var t = h.find(function(t) {
                                return t.typeName === e;
                            });
                            t && (t.c = t.c + 1);
                        }), this.changeTemplates(e(h))), this._timer = setTimeout(function() {
                            A.setData({
                                showTip: g,
                                tip: "开启通知，接收推送"
                            });
                        }, 400), t.next = 28, (0, n.authSubscribeMesssage)(o.map(function(e) {
                            return e.tmplId;
                        }));

                      case 28:
                        if (v = t.sent, clearTimeout(this._timer), this.setData({
                            showTip: !1
                        }), console.log("authResult", v), N = v[0], T = v[1], N || o.forEach(function(e) {
                            "accept" === T[e.tmplId] && l.push(e.tmplId);
                        }), !(l.length > 0 || m.length > 0)) {
                            t.next = 47;
                            break;
                        }
                        return t.prev = 36, t.next = 39, (0, n.updateSubscribeMessage)({
                            accept_tmpl_id: l,
                            ban_tmpl_id: m
                        });

                      case 39:
                        t.sent.data.items.forEach(function(e) {
                            var t = h.find(function(t) {
                                return t.tmplId === e.id;
                            });
                            t && t.c < e.c && (t.c = e.c);
                        }), this.changeTemplates(e(h)), t.next = 47;
                        break;

                      case 44:
                        t.prev = 44, t.t0 = t.catch(36), console.error(t.t0);

                      case 47:
                        if (x = {
                            error: N,
                            accept_tmpl_id: l
                        }, c) {
                            t.next = 54;
                            break;
                        }
                        if (this.data.templates.find(function(e) {
                            return e.typeName === a[0];
                        }), 0 !== (S = (this.data.templates || []).filter(function(e) {
                            return a.indexOf(e.typeName) > -1;
                        })).length) {
                            t.next = 53;
                            break;
                        }
                        return t.abrupt("return", x);

                      case 53:
                        getApp().temp("showSubscribeNoticeAfterSub") ? (N || l.length !== a.length) && (E = S.filter(function(e) {
                            return 0 === e.c;
                        })).length > 0 && this.showNotice(E[0].typeName) : (getApp().temp("showSubscribeNoticeAfterSub", !0), 
                        (w = S.filter(function(e) {
                            return e.c < 7;
                        })).length > 0 && this.showNotice(w[0].typeName));

                      case 54:
                        return t.abrupt("return", x);

                      case 55:
                      case "end":
                        return t.stop();
                    }
                }, r, this, [ [ 36, 44 ] ]);
            }));
            return function(e, t, r, n) {
                return a.apply(this, arguments);
            };
        }())
    }
});