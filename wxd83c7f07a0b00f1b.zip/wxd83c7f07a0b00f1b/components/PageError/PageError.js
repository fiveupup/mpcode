var e, t = require("../../utils/mina"), r = require("mobx-miniprogram-bindings"), i = (e = require("../../store/app")) && e.__esModule ? e : {
    default: e
};

var s = (0, t.getSystemInfo)();

Component({
    data: {
        loadingStyle: "height: ".concat(s.windowHeight - 44 - s.statusBarHeight, "px;")
    },
    externalClasses: [ "custom-class" ],
    behaviors: [ r.storeBindingsBehavior ],
    storeBindings: {
        store: i.default,
        fields: [ "theme" ]
    },
    properties: {
        error: {
            type: String,
            value: ""
        },
        style: {
            type: String,
            value: "",
            observer: function(e) {
                e && this.setData({
                    loadingStyle: e
                });
            }
        }
    },
    methods: {
        reload: function() {
            this.triggerEvent("reload");
        }
    }
});