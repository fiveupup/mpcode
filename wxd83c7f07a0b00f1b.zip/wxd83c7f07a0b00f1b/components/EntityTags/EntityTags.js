var t, e = o(require("../../service/pro")), r = (t = require("../../behavior/store")) && t.__esModule ? t : {
    default: t
}, n = o(require("../../utils/lodash")), i = require("miniprogram-computed"), a = require("../../utils/entity");

function u(t) {
    if ("function" != typeof WeakMap) return null;
    var e = new WeakMap(), r = new WeakMap();
    return (u = function(t) {
        return t ? r : e;
    })(t);
}

function o(t, e) {
    if (!e && t && t.__esModule) return t;
    if (null === t || "object" != typeof t && "function" != typeof t) return {
        default: t
    };
    var r = u(e);
    if (r && r.has(t)) return r.get(t);
    var n = {}, i = Object.defineProperty && Object.getOwnPropertyDescriptor;
    for (var a in t) if ("default" !== a && Object.prototype.hasOwnProperty.call(t, a)) {
        var o = i ? Object.getOwnPropertyDescriptor(t, a) : null;
        o && (o.get || o.set) ? Object.defineProperty(n, a, o) : n[a] = t[a];
    }
    return n.default = t, r && r.set(t, n), n;
}

(0, i.ComponentWithComputed)({
    behaviors: [ (0, r.default)([ "theme", "pro" ]) ],
    properties: {
        type: {
            type: String,
            value: ""
        },
        entityList: {
            type: Array,
            value: []
        },
        tagList: {
            type: Array,
            value: []
        },
        highlightUnSubedItem: {
            type: Boolean,
            value: !0
        },
        tagStyle: {
            type: String,
            value: ""
        },
        gapX: {
            type: String,
            value: "3px"
        },
        gapY: {
            type: String,
            value: "3px"
        },
        nowrap: {
            type: Boolean,
            value: !1
        }
    },
    computed: {
        list: function(t) {
            var r = [], i = n.get(t.pro, "subList", []), a = t.tagList || [], u = t.entityList || [], o = t.highlightUnSubedItem, p = function(t) {
                return !i.find(function(e) {
                    return e.key === t;
                });
            };
            return 0 !== u.length && u.forEach(function(t) {
                r.push({
                    active: o && p(t.entityId),
                    key: t.entityId,
                    type: e.SUB_TYPES.entity,
                    content: t.entityName
                });
            }), 0 !== a.length && a.forEach(function(t) {
                r.push({
                    active: o && p(t.uid),
                    key: t.uid,
                    type: e.SUB_TYPES.tag,
                    content: t.name
                });
            }), r.filter(function(t) {
                return t.active;
            }).concat(r.filter(function(t) {
                return !t.active;
            }));
        }
    },
    data: {
        scrollStyle: "height: 64px;"
    },
    methods: {
        onClickTag: function(t) {
            var e = t.currentTarget.dataset.item;
            (0, a.navigatoEntity)({
                id: e.key,
                type: e.type,
                tab: this.data.type
            }), this.triggerEvent("taptag", t.currentTarget.dataset.item, {
                bubbles: !0,
                composed: !0
            });
        }
    }
});