var t = require("../../@babel/runtime/helpers/regeneratorRuntime"), e = require("../../@babel/runtime/helpers/asyncToGenerator"), n = require("../../service/search"), a = require("../../constant");

Component({
    properties: {
        visible: Boolean,
        query: String,
        type: Number,
        path: String
    },
    data: {
        text: ""
    },
    observers: {
        "query,type,path": function(t, e, n) {
            this.setData({
                text: "内容：".concat(t, "\n位置：").concat(a.feedbackType[e] || "", "\n路径：").concat(n, "\n")
            });
        }
    },
    methods: {
        onSubmit: function() {
            var a = this;
            return e(t().mark(function e() {
                return t().wrap(function(t) {
                    for (;;) switch (t.prev = t.next) {
                      case 0:
                        if (a.data.text.trim()) {
                            t.next = 2;
                            break;
                        }
                        return t.abrupt("return");

                      case 2:
                        return wx.showToast({
                            title: "提交成功",
                            icon: "none"
                        }), t.next = 5, (0, n.submitFeedback)(a.data.text, a.data.type);

                      case 5:
                        a.onClose();

                      case 6:
                      case "end":
                        return t.stop();
                    }
                }, e);
            }))();
        },
        onInput: function(t) {
            var e = t.detail.value;
            this.setData({
                text: e
            });
        },
        onClose: function() {
            this.triggerEvent("close"), this.setData({
                text: "内容：".concat(this.data.query, "\n位置：").concat(a.feedbackType[this.data.type], "\n路径：").concat(this.data.path, "\n")
            });
        }
    }
});