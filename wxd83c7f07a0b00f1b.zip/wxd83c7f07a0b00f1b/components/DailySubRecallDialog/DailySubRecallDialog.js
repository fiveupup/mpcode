var e = require("../../@babel/runtime/helpers/regeneratorRuntime"), t = require("../../@babel/runtime/helpers/asyncToGenerator"), r = require("../../service/recall"), n = require("mobx-miniprogram-bindings"), i = l(require("../../store/app")), a = l(require("../../behavior/computed")), o = require("../../service/analyse"), s = function(e, t) {
    if (!t && e && e.__esModule) return e;
    if (null === e || "object" != typeof e && "function" != typeof e) return {
        default: e
    };
    var r = d(t);
    if (r && r.has(e)) return r.get(e);
    var n = {}, i = Object.defineProperty && Object.getOwnPropertyDescriptor;
    for (var a in e) if ("default" !== a && Object.prototype.hasOwnProperty.call(e, a)) {
        var o = i ? Object.getOwnPropertyDescriptor(e, a) : null;
        o && (o.get || o.set) ? Object.defineProperty(n, a, o) : n[a] = e[a];
    }
    n.default = e, r && r.set(e, n);
    return n;
}(require("../../service/user")), u = l(require("dayjs")), c = require("../../service/constant");

function d(e) {
    if ("function" != typeof WeakMap) return null;
    var t = new WeakMap(), r = new WeakMap();
    return (d = function(e) {
        return e ? r : t;
    })(e);
}

function l(e) {
    return e && e.__esModule ? e : {
        default: e
    };
}

Component({
    properties: {
        reachBottom: {
            type: Boolean,
            value: !1,
            observer: function() {
                this.check();
            }
        },
        wordCount: {
            type: Number,
            value: 0,
            observer: function(e) {
                var t = this;
                e && (console.log("wordCount", e), this.timer = setTimeout(function() {
                    t.setData({
                        isReadEnd: !0
                    }, function() {
                        t.check();
                    });
                }, e / 520 * 6e4));
            }
        }
    },
    data: {
        isReadEnd: !1
    },
    lifetimes: {
        detached: function() {
            this.timer && clearTimeout(this.timer);
        }
    },
    computed: {
        onInited: function() {
            this.data.inited && this.check();
        }
    },
    behaviors: [ n.storeBindingsBehavior, a.default ],
    storeBindings: {
        store: i.default,
        fields: [ "inited" ]
    },
    methods: {
        check: function() {
            if (this.data.inited && (this.properties.reachBottom || this.data.isReadEnd)) {
                var e = (0, r.isNewDailyUserFromSearch)(), t = getApp().temp(c.DAILY_RECALL_DIALOG_VIEW);
                t && (0, u.default)(new Date(t.date)).isSame((0, u.default)(), "date") || e && ((0, 
                o.report)("mengbandingyue_show"), getApp().temp(c.DAILY_RECALL_DIALOG_VIEW, {
                    date: Date.now()
                }), this.selectComponent(".dialog").show());
            }
        },
        onHide: function(e) {
            "element" === e.detail.from && (0, o.report)("mengbandingyue_close");
        },
        goToDaily: function() {
            var r = this;
            return t(e().mark(function t() {
                var n, i;
                return e().wrap(function(e) {
                    for (;;) switch (e.prev = e.next) {
                      case 0:
                        return (0, o.report)("mengbandingyue_click"), r.selectComponent(".dialog").hide(), 
                        wx.navigateTo({
                            url: "/pages/daily?apply=true"
                        }), e.next = 5, r.selectComponent(".subscribeMessage").auth([ "DAILY" ], !1, !0);

                      case 5:
                        if (!((n = e.sent) && n.accept_tmpl_id.length > 0)) {
                            e.next = 13;
                            break;
                        }
                        return e.next = 9, s.subscribe(1);

                      case 9:
                        if (!(i = r.selectComponent("#dailyCalender"))) {
                            e.next = 13;
                            break;
                        }
                        return e.next = 13, i.addNextRemindAvaliableDayRemindWithoutAuth();

                      case 13:
                      case "end":
                        return e.stop();
                    }
                }, t);
            }))();
        }
    }
});