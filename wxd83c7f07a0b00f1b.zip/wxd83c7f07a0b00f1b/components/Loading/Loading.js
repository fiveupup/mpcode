var e, t = require("../../utils/mina"), i = require("mobx-miniprogram-bindings"), s = (e = require("../../store/app")) && e.__esModule ? e : {
    default: e
};

var r = (0, t.getSystemInfo)();

Component({
    externalClasses: [ "custom-class" ],
    behaviors: [ i.storeBindingsBehavior ],
    storeBindings: {
        store: s.default,
        fields: [ "theme" ]
    },
    properties: {
        loadingStyle: {
            type: String,
            value: "height: ".concat(r.windowHeight - 44 - r.statusBarHeight, "px;")
        }
    },
    data: {
        initTheme: s.default.theme
    }
});