var e, t = require("../../service/analyse"), r = function(e, t) {
    if (!t && e && e.__esModule) return e;
    if (null === e || "object" != typeof e && "function" != typeof e) return {
        default: e
    };
    var r = n(t);
    if (r && r.has(e)) return r.get(e);
    var i = {}, o = Object.defineProperty && Object.getOwnPropertyDescriptor;
    for (var s in e) if ("default" !== s && Object.prototype.hasOwnProperty.call(e, s)) {
        var a = o ? Object.getOwnPropertyDescriptor(e, s) : null;
        a && (a.get || a.set) ? Object.defineProperty(i, s, a) : i[s] = e[s];
    }
    i.default = e, r && r.set(e, i);
    return i;
}(require("../../utils/lodash")), i = require("mobx-miniprogram-bindings"), o = (e = require("../../store/app")) && e.__esModule ? e : {
    default: e
};

function n(e) {
    if ("function" != typeof WeakMap) return null;
    var t = new WeakMap(), r = new WeakMap();
    return (n = function(e) {
        return e ? r : t;
    })(e);
}

Component({
    data: {
        needIndent: !1,
        descriptionText: ""
    },
    properties: {
        item: {
            type: Object,
            value: null,
            observer: function(e) {
                if (e) {
                    var t = "";
                    if ("ad" === e.type && (t = e.appData.description, !/招股书/.test(t))) {
                        var i = /^(.*?)。/.exec(t);
                        i && i.length > 1 && (t = "".concat(i[0], "..."));
                    }
                    this.setData({
                        needIndent: /[《「]/.test(r.get(e, "title[0]", "")),
                        descriptionText: t
                    });
                }
            }
        },
        isAndroid: {
            type: Boolean,
            value: !1
        },
        detailMode: {
            type: Boolean,
            value: !0
        },
        theme: {
            type: String,
            value: "normal"
        }
    },
    behaviors: [ i.storeBindingsBehavior ],
    storeBindings: {
        store: o.default,
        fields: [ "showAd", "userInfo" ]
    },
    methods: {
        showTopicOpt: function() {
            this.triggerEvent("topic", {
                id: this.properties.item.id
            });
        },
        showSponsorOpt: function() {
            this.triggerEvent("ad");
        },
        goToSponsor: function() {
            wx.navigateTo({
                url: "/pages/sponsor/detail?sponsor=".concat(encodeURIComponent(this.properties.item.english_name))
            });
        },
        genSponsorShareImage: function() {
            (0, t.report)("ad_click", {
                id: this.properties.item.sponsorName
            }), wx.navigateTo({
                url: "/pages/share_image?type=sponsor&id=".concat(this.properties.item.id, "&index=").concat(this.properties.item.sindex, "&name=").concat(this.properties.item.sponsorName)
            });
        },
        tapAd: function() {
            this.properties.item.appId && (0, t.report)("list_ad");
        }
    }
});