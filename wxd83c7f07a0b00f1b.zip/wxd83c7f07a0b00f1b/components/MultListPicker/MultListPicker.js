var e = function(e, r) {
    if (!r && e && e.__esModule) return e;
    if (null === e || "object" != typeof e && "function" != typeof e) return {
        default: e
    };
    var i = t(r);
    if (i && i.has(e)) return i.get(e);
    var n = {}, o = Object.defineProperty && Object.getOwnPropertyDescriptor;
    for (var s in e) if ("default" !== s && Object.prototype.hasOwnProperty.call(e, s)) {
        var a = o ? Object.getOwnPropertyDescriptor(e, s) : null;
        a && (a.get || a.set) ? Object.defineProperty(n, s, a) : n[s] = e[s];
    }
    n.default = e, i && i.set(e, n);
    return n;
}(require("../../utils/lodash"));

function t(e) {
    if ("function" != typeof WeakMap) return null;
    var r = new WeakMap(), i = new WeakMap();
    return (t = function(e) {
        return e ? i : r;
    })(e);
}

Component({
    data: {
        content: null,
        scrollTop: -1,
        tabs: [],
        indexs: []
    },
    properties: {
        theme: {
            type: String,
            value: "default"
        },
        list: {
            type: Array,
            value: [],
            observer: function(e) {
                this.layout(e, this.properties.selected);
            }
        },
        selected: {
            type: Array,
            value: [],
            observer: function(e) {
                this.layout(this.properties.list, e);
            }
        },
        title: {
            type: String,
            value: "请选择"
        }
    },
    methods: {
        layout: function() {
            for (var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : [], t = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : [], r = [], i = [], n = -1, o = e, s = o[0]; s; ) {
                s = null, n++, r.push(o.map(function(e) {
                    return {
                        id: e.id,
                        name: e.name
                    };
                }));
                var a = t[n];
                void 0 === a && (a = o[n].id), i.push(a);
                for (var u = 0, l = o.length; u < l; u++) if (o[u].id === a) {
                    s = (o = o[u].data || [])[0];
                    break;
                }
            }
            this.setData({
                tabs: r,
                indexs: i
            });
        },
        chooseTab: function(t) {
            var r = this, i = t.currentTarget.dataset, n = i.tab, o = i.index, s = i.id, a = this.data.indexs, u = this.data.tabs;
            a[n] = s;
            for (var l = !0, c = 0, p = a.length; c < p; c++) c > n && (a[c] = "", l = !1);
            a.length > 1 && e.isEqual(a.slice(0, -1), this.properties.selected.slice(0, -1)) && (a = this.properties.selected), 
            this.setData({
                indexs: a
            }, function() {
                l || r.layout(r.properties.list, a);
            }), l && (this.hide(), setTimeout(function() {
                r.triggerEvent("choose", {
                    indexs: a,
                    value: u[n][o]
                });
            }, 400));
        },
        touchmove: function() {
            return !0;
        },
        hide: function() {
            this.selectComponent("#picker").hide();
        },
        show: function() {
            this.selectComponent("#picker").show();
        }
    }
});