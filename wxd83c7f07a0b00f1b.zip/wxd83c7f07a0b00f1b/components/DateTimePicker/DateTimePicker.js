var t, e = (t = require("dayjs")) && t.__esModule ? t : {
    default: t
};

var r = require("../../libs/duration");

function i(t, r) {
    var i = [];
    if (!t || !r) throw new Error("require start and end");
    for (var a = (0, e.default)(t).add(-1, "minute"); a <= r; ) i.push(a), a = (0, e.default)(a).add(1, "days");
    return i;
}

function a(t) {
    return t.map(function(t) {
        if ("string" == typeof t) return t;
        var r = function(t) {
            var r, i = (0, e.default)(), a = e.default.duration(t.diff(i.startOf("day"))), s = Math.floor(a.asDays());
            return i.isSame(t, "day") ? r = "(今天)" : s > 0 && (r = [ "", "(明天)", "(后天)", "" ][s] || ""), 
            r;
        }(t);
        return t.format("M月D日 ddd ".concat(r));
    });
}

function s(t) {
    return 1 === (t = "" + t).length && (t = "0" + t), t;
}

function n() {
    for (var t = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : 5, e = [], r = 0; r < 60; ) e.push(s(r)), 
    r += t;
    return e;
}

function u() {
    for (var t = [], e = 0; e < 24; ) t.push(s(e)), e += 1;
    return t;
}

e.default.extend(r), Component({
    data: {
        minutes: n(),
        hours: u(),
        days: a(i((0, e.default)(), (0, e.default)().add(7, "days"))),
        value: [ 0, 0, 0 ]
    },
    properties: {
        isProSub: Boolean,
        custom: {
            type: Array,
            value: [],
            observer: function(t, e) {
                this.render();
            }
        },
        defaultCustomIndex: {
            type: Number,
            value: 0
        },
        default: {
            type: String,
            value: "",
            observer: function(t) {
                this.render(!0), this.triggerEvent("datetimechange", this.getDatetime());
            }
        },
        start: {
            type: String,
            value: "",
            observer: function(t) {
                this.render();
            }
        },
        end: {
            type: String,
            value: "",
            observer: function(t) {
                this.render();
            }
        },
        theme: {
            type: String,
            value: ""
        }
    },
    ready: function() {
        this.render(!0), this.triggerEvent("datetimechange", this.getDatetime());
    },
    methods: {
        onSave: function() {
            this.triggerEvent("datetimechangesave", this.getDatetime());
        },
        onEnd: function() {
            this.triggerEvent("datetimechangeend");
        },
        onStart: function() {
            this.triggerEvent("datetimechangestart");
        },
        genDays: function() {
            var t = (0, e.default)();
            if (this.properties.start) {
                var r = (0, e.default)(this.properties.start);
                r.isValid() && (t = r);
            }
            var a = (0, e.default)(t).add(7, "days");
            if (this.properties.end) {
                var s = (0, e.default)(this.properties.end);
                s.isValid() && s >= t && (a = s);
            }
            return i(t, a);
        },
        render: function(t) {
            var r = this.genDays(), i = a(r), s = this.data.value;
            this.properties.custom && this.properties.custom.length > 0 && i.unshift("推荐设置");
            var o = n(), h = u();
            if (0 === s[0] && this.properties.custom && this.properties.custom.length > 0 && (o = this.properties.custom, 
            h = []), t) {
                var d = this.properties.default || (this.properties.custom ? this.properties.custom[this.properties.defaultCustomIndex || 0] : "") || (0, 
                e.default)().toISOString();
                if (d) {
                    var f = (0, e.default)(d);
                    if (this.data.isProSub || f.isValid() && f >= r[0] && f <= r[r.length - 1]) {
                        o = n(), h = u();
                        for (var l = f.hour(), p = f.minute(), v = 0, m = 0, g = r.length; m < g; m++) if (f.isSame(r[m], "day")) {
                            v = m;
                            break;
                        }
                        this.properties.custom && this.properties.custom.length > 0 ? s[0] = v + 1 : s[0] = v, 
                        s[1] = l;
                        for (var c = 0, y = n(), D = 0, S = y.length; D < S && (c = D, !(p <= parseInt(y[c]))); D++) ;
                        s[2] = c;
                    } else {
                        var b = (this.properties.custom || []).indexOf(d);
                        b > -1 && (s[0] = 0, s[1] = 0, s[2] = b);
                    }
                }
            }
            this.setData({
                days: i,
                minutes: o,
                hours: h
            }), this.setData({
                value: s
            });
        },
        getDatetime: function() {
            var t, e = this.data.value, r = this.data.days[e[0]], i = this.data.hours[e[1]], a = this.data.minutes[e[2]], s = "datetime";
            if ("推荐设置" === r) s = "custom", t = a; else {
                var n = e[0];
                this.properties.custom && this.properties.custom.length > 0 && (n -= 1), t = (t = (t = (t = this.genDays()[n]).set("hour", parseInt(i))).set("minute", parseInt(a))).toISOString();
            }
            return {
                type: s,
                value: t
            };
        },
        onDatetimeChange: function(t) {
            var r = t.detail.value;
            !this._value || 0 !== this._value[0] && 0 !== r[0] || this._value[0] === r[0] || (r[1] = 0, 
            r[2] = 0);
            var i = 0;
            if (this.properties.custom && this.properties.custom.length > 0 && (i = 1), !(this.data.isProSub || r[0] !== i || this._value && this._value[0] === i)) {
                for (var a = (0, e.default)(), s = a.hour(), u = a.minute(), o = 0, h = n(), d = h.length; o < d && !(u <= parseInt(h[o])); o++) ;
                r[1] = s, r[2] = o;
            }
            this._value = r, this.setData({
                value: r
            }), this.render(), this.setData({
                value: r
            }), this.triggerEvent("datetimechange", this.getDatetime());
        }
    }
});