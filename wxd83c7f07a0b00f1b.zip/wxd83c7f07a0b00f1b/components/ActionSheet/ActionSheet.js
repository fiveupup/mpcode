var e, t = require("mobx-miniprogram-bindings"), i = (e = require("../../store/app")) && e.__esModule ? e : {
    default: e
};

Component({
    data: {
        actionSheetStyle: "z-index: -1; opacity: 0;",
        showed: !1
    },
    properties: {
        items: {
            type: Array,
            value: [],
            observer: function() {
                this.refresh();
            }
        }
    },
    behaviors: [ t.storeBindingsBehavior ],
    storeBindings: {
        store: i.default,
        fields: [ "theme" ]
    },
    methods: {
        touchmove: function() {
            return !1;
        },
        show: function() {
            this.refresh(!0), this.triggerEvent("actionsheetshow", {
                id: this.properties.name
            }, {
                bubbles: !0,
                composed: !0
            });
        },
        hide: function() {
            this.refresh(!1), this.triggerEvent("actionsheethide", {
                id: this.properties.name
            }, {
                bubbles: !0,
                composed: !0
            });
        },
        choose: function(e) {
            var t = e.currentTarget.dataset.index;
            this.triggerEvent("choose", {
                item: this.properties.items[t],
                index: t
            }), this.properties.items[t].disable || (this.triggerEvent("actionsheethide", {
                id: this.properties.name
            }, {
                bubbles: !0,
                composed: !0
            }), this.refresh(!1));
        },
        refresh: function(e) {
            var t = "", i = this.data.showed;
            void 0 !== e && (i = e), t = i ? "bottom: 0px;" : "bottom: -345px;", this.setData({
                actionSheetStyle: t,
                showed: i
            });
        }
    }
});