var e = require("../../utils/mina"), t = require("../../utils/tools"), a = require("../../service/analyse"), i = u(require("../../config")), n = require("mobx-miniprogram-bindings"), o = u(require("../../store/app")), r = require("../../service/user"), s = u(require("dayjs")), l = u(require("../../behavior/computed"));

function u(e) {
    return e && e.__esModule ? e : {
        default: e
    };
}

var c = (0, e.getSystemInfo)();

Component({
    data: {
        isSupportCustomNavigationBar: !0,
        statusBarHeight: c.statusBarHeight,
        actionsheetList: [ {
            label: "分享给微信好友",
            openType: "share"
        }, {
            label: "生成分享图片"
        } ],
        isShowBack: !1,
        initTheme: o.default.theme,
        managerBoxType: "",
        systemInfo: c,
        bodyStyle: "",
        canShowRipple: !1
    },
    behaviors: [ n.storeBindingsBehavior, l.default ],
    externalClasses: [ "custom-class" ],
    storeBindings: {
        store: o.default,
        fields: [ "theme", "userInfo", "subscribeState" ],
        actions: {
            changeTheme: "changeTheme"
        }
    },
    lifetimes: {
        attached: function() {
            var e = getCurrentPages();
            if (e[e.length - 1]) {
                var t = e.length > 1, a = getApp().temp("rippleProfile"), i = !1;
                a && (0, s.default)(a.date).isSame((0, s.default)(), "day") || (i = !0), this.setData({
                    isShowBack: t,
                    canShowRipple: i
                });
            }
        }
    },
    properties: {
        isWhiteTheme: Boolean,
        isShowUser: Boolean,
        isShowShare: Boolean,
        isShowHome: Boolean,
        customClass: {
            type: String,
            value: ""
        },
        title: {
            type: String,
            value: ""
        },
        stitle: {
            type: String,
            value: ""
        },
        pageStyle: {
            type: String,
            value: ""
        },
        navBarStyle: {
            type: String,
            value: ""
        },
        navigationStyle: {
            type: String,
            value: ""
        },
        backIcon: {
            type: String,
            value: "/images/icn_back@3x.png"
        },
        loading: {
            type: Boolean,
            value: !1
        },
        appSetting: {
            type: Object,
            value: null
        },
        forcetheme: {
            type: String,
            value: ""
        },
        overflow: {
            type: Boolean,
            value: !1,
            observer: function(e, t) {
                if (void 0 === t || t !== e) if (e) {
                    var a = 20;
                    c.statusBarHeight && (a = c.statusBarHeight);
                    var i = c.screenHeight - a - 44;
                    this.setData({
                        bodyStyle: "overflow: scroll; height: ".concat(i, "px; -webkit-overflow-scrolling: touch;")
                    });
                } else this.setData({
                    bodyStyle: ""
                });
            }
        }
    },
    methods: {
        tapProfile: function() {
            if (this.data.userInfo.avatar && !this.data.subscribeState.subscribOfficiaAccount && this.data.canShowRipple) {
                getApp().temp("rippleProfile", {
                    date: new Date().toISOString()
                });
                var e = getCurrentPages(), t = e[e.length - 1];
                t ? t.route.indexOf("pages/detail") > -1 ? (0, a.report)("flow_guide_avatar_animation_topic_click") : t.route.indexOf("pages/news/detail") > -1 ? (0, 
                a.report)("flow_guide_avatar_animation_news_click") : t.route.indexOf("pages/daily") > -1 ? (0, 
                a.report)("flow_guide_avatar_animation_daily_click") : (0, a.report)("flow_guide_avatar_animation_click") : (0, 
                a.report)("flow_guide_avatar_animation_click"), this.setData({
                    canShowRipple: !1
                });
            }
        },
        getLoginManager: function() {
            return this.selectComponent("#loginDialog");
        },
        onPopupBoxHide: function() {
            this.setData({
                managerBoxType: ""
            });
        },
        onPageInput: function(e) {
            this.redirectPage = e.detail.value;
        },
        redirectToPage: function() {
            var e = this.redirectPage.trim();
            e && ("/" !== e[0] && (e = "/" + e), wx.navigateTo({
                url: e,
                fail: function() {
                    wx.showToast({
                        title: "路径不存在",
                        icon: "none"
                    });
                }
            }));
        },
        onThemeChange: function(e) {
            this.changeTheme(e.detail.value ? "dark" : "normal");
        },
        tapTitle: function() {
            this.triggerEvent("tapTitle");
        },
        navigateBack: function() {
            wx.navigateBack();
        },
        navigateHome: function() {
            wx.reLaunch({
                url: "/pages/index"
            });
        },
        shareApp: function() {
            this.triggerEvent("shareApp");
        },
        nocode: function() {
            var e = this, a = getCurrentPages(), n = a[a.length - 1], o = n.options, s = (0, 
            t.queryString)(o), l = n.route + (s ? "?" + s : ""), u = [ "Version: ".concat(i.default.VERSION), "".concat(l), "小程序页面跳转" ];
            (0, r.isManager)() && u.push("调试配置"), wx.showActionSheet({
                itemList: u,
                success: function(t) {
                    0 === t.tapIndex ? e.setData({
                        managerBoxType: "system"
                    }, function() {
                        e.selectComponent("#managerBoxId").show();
                    }) : 1 === t.tapIndex ? wx.setClipboardData({
                        data: l,
                        success: function() {
                            wx.showToast({
                                title: "路径已复制",
                                icon: "none"
                            });
                        }
                    }) : 2 === t.tapIndex ? e.setData({
                        managerBoxType: "redirect"
                    }, function() {
                        e.selectComponent("#managerBoxId").show();
                    }) : 3 === t.tapIndex && wx.navigateTo({
                        url: "/pages/cfg"
                    });
                }
            });
        }
    }
});