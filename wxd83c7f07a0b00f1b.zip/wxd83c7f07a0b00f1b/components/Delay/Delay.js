Component({
    properties: {
        t: Number
    },
    data: {
        visible: !1
    },
    detached: function() {
        clearTimeout(this._timer);
    },
    attached: function() {
        var t = this, e = this.data.t;
        e && (this._timer = setTimeout(function() {
            t.setData({
                visible: !0
            });
        }, e));
    }
});