var e = require("../../service/analyse");

Component({
    properties: {
        theme: String
    },
    methods: {
        onPreview: function() {
            (0, e.report)("index_middle_assistant_qr_click"), wx.previewImage({
                urls: [ "https://resource.nocode.com/readhub/assistant.png" ]
            });
        }
    }
});