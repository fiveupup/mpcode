var t = require("../../@babel/runtime/helpers/regeneratorRuntime"), e = require("../../@babel/runtime/helpers/asyncToGenerator"), a = require("../../service/giftCard"), n = "toPay", r = "toView", i = "toSend", s = {
    visible: !1,
    tips: [ "购买须知：", "1. 每次最多可购买 30 张包年卡", "2. 每位好友每次只能领 1 张", "3. 购买后可在 365 天内转赠给好友，超过期限将自动失效", "4. 购买后仅可用于赠送，不支持自己领取", "5. 包年卡购买后不支持退款" ].join("\n"),
    state: n,
    count: 1,
    price: 9900,
    item: {}
};

Component({
    data: s,
    methods: {
        onPay: function() {
            var n = this;
            return e(t().mark(function e() {
                var i, s;
                return t().wrap(function(t) {
                    for (;;) switch (t.prev = t.next) {
                      case 0:
                        return t.next = 2, (0, a.createGiftCard)({
                            count: n.data.count,
                            price: n.data.price
                        });

                      case 2:
                        return i = t.sent, t.next = 5, (0, a.fetchCardByOrder)(i);

                      case 5:
                        s = t.sent, n.setData({
                            item: s,
                            state: r
                        });

                      case 7:
                      case "end":
                        return t.stop();
                    }
                }, e);
            }))();
        },
        onInput: function(t) {
            var e = t.detail.value;
            this.setData({
                count: e
            });
        },
        onBlur: function(t) {
            var e = t.detail.value;
            this.setData({
                count: Math.max(Math.min(+e || 1, 30), 1)
            });
        },
        onSub: function() {
            var t = Math.max(this.data.count - 1, 1);
            this.setData({
                count: t
            });
        },
        onAdd: function() {
            var t = Math.min(this.data.count + 1, 30);
            this.setData({
                count: t
            });
        },
        show: function(n) {
            var r = this;
            return e(t().mark(function e() {
                var s, c;
                return t().wrap(function(t) {
                    for (;;) switch (t.prev = t.next) {
                      case 0:
                        if (!n) {
                            t.next = 7;
                            break;
                        }
                        return t.next = 3, (0, a.fetchCardByUid)(n);

                      case 3:
                        s = t.sent, r.setData({
                            item: s,
                            state: i
                        }), t.next = 11;
                        break;

                      case 7:
                        return t.next = 9, (0, a.fetchYearCardPrice)();

                      case 9:
                        c = t.sent, r.setData({
                            price: c
                        });

                      case 11:
                        r.setData({
                            visible: !0
                        });

                      case 12:
                      case "end":
                        return t.stop();
                    }
                }, e);
            }))();
        },
        onClose: function() {
            this.setData(s);
        }
    }
});