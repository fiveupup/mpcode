!function(e, t) {
    if (!t && e && e.__esModule) return e;
    if (null === e || "object" != typeof e && "function" != typeof e) return {
        default: e
    };
    var r = i(t);
    if (r && r.has(e)) return r.get(e);
    var o = {}, n = Object.defineProperty && Object.getOwnPropertyDescriptor;
    for (var s in e) if ("default" !== s && Object.prototype.hasOwnProperty.call(e, s)) {
        var a = n ? Object.getOwnPropertyDescriptor(e, s) : null;
        a && (a.get || a.set) ? Object.defineProperty(o, s, a) : o[s] = e[s];
    }
    o.default = e, r && r.set(e, o);
}(require("../../utils/lodash"));

var e, t = require("mobx-miniprogram-bindings"), r = (e = require("../../store/app")) && e.__esModule ? e : {
    default: e
}, o = require("../../service/analyse");

function i(e) {
    if ("function" != typeof WeakMap) return null;
    var t = new WeakMap(), r = new WeakMap();
    return (i = function(e) {
        return e ? r : t;
    })(e);
}

Component({
    data: {},
    properties: {
        theme: {
            type: String,
            value: "default"
        }
    },
    behaviors: [ t.storeBindingsBehavior ],
    storeBindings: {
        store: r.default,
        fields: [ "showAd", "userInfo" ],
        actions: {
            toggleAd: "toggleAd"
        }
    },
    methods: {
        hide: function() {
            this.selectComponent(".dialog").hide();
        },
        show: function() {
            (0, o.report)("ad_more"), this.selectComponent(".dialog").show();
        },
        hideAd: function() {
            (0, o.report)("ad_hide"), this.data.userInfo.isVip ? this.toggleAd(!1) : wx.navigateTo({
                url: "/pages/pro/join?opt=closeAd"
            }), this.hide();
        },
        beSponsor: function() {
            (0, o.report)("ad_sponsor"), this.hide();
        }
    }
});