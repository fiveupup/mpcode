var e, t = require("../../@babel/runtime/helpers/regeneratorRuntime"), r = require("../../@babel/runtime/helpers/asyncToGenerator"), n = require("../../utils/functional"), s = require("../../service/app"), o = require("mobx-miniprogram-bindings"), a = (e = require("../../store/app")) && e.__esModule ? e : {
    default: e
};

var i = wx.getSystemInfoSync();

Component({
    data: {
        isShow: !1,
        customStyle: "top: ".concat(i.statusBarHeight - 5, "px;"),
        code: ""
    },
    behaviors: [ o.storeBindingsBehavior ],
    storeBindings: {
        store: a.default,
        fields: [ "userInfo" ],
        actions: {}
    },
    methods: {
        noop: function() {},
        show: function(e) {
            this.setData({
                isShow: !0,
                code: e
            });
        },
        hide: function() {
            this.setData({
                isShow: !1
            });
        },
        onNewUpdateUserProfile: function(e) {
            return r(t().mark(function r() {
                var n;
                return t().wrap(function(t) {
                    for (;;) switch (t.prev = t.next) {
                      case 0:
                        return n = e.detail.userInfo, t.next = 3, getApp().updateUserInfo(n);

                      case 3:
                      case "end":
                        return t.stop();
                    }
                }, r);
            }))();
        },
        auth: (0, n.singleExec)(r(t().mark(function e() {
            var r, n, o;
            return t().wrap(function(e) {
                for (;;) switch (e.prev = e.next) {
                  case 0:
                    if ((r = getApp().globalData.userInfo.nickname) && "微信用户" !== r) {
                        e.next = 8;
                        break;
                    }
                    return e.next = 4, null === (n = this.selectComponent("#user-data-views")) || void 0 === n ? void 0 : n.getUserProfile();

                  case 4:
                    if (!(o = e.sent)) {
                        e.next = 8;
                        break;
                    }
                    return e.next = 8, getApp().updateUserInfo(o);

                  case 8:
                    return e.next = 10, (0, s.browserCodeBind)(this.data.code);

                  case 10:
                    if (!e.sent.data.error) {
                        e.next = 13;
                        break;
                    }
                    throw new Error("授权失败");

                  case 13:
                    this.setData({
                        isShow: !1
                    }), wx.showToast({
                        title: "已登录",
                        icon: "success"
                    });

                  case 15:
                  case "end":
                    return e.stop();
                }
            }, e, this);
        })))
    }
});