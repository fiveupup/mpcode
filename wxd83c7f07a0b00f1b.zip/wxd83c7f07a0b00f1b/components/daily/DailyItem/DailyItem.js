var e = require("../../../service/analyse");

Component({
    properties: {
        index: Number,
        size: String,
        item: {
            type: Object,
            value: null
        },
        theme: {
            type: String,
            value: ""
        },
        enableNavigation: {
            type: Boolean,
            value: !0
        },
        enableCopyTitle: {
            type: Boolean,
            value: !1
        }
    },
    methods: {
        copyTitle: function() {
            this.properties.enableCopyTitle && wx.setClipboardData({
                data: this.properties.item.title,
                success: function(e) {
                    wx.showToast({
                        title: "已复制",
                        icon: "none"
                    });
                }
            });
        },
        toDetail: function() {
            if (this.properties.enableNavigation) {
                this.selectComponent(".subscribeMessage").auth([ "DAILY" ], !0);
                var t = this.properties.item;
                (0, e.report)("daily_title");
                var i, a = "";
                switch (t.type) {
                  case 1:
                    a = "/pages/news/detail?id=".concat(t.uid), i = "news";
                    break;

                  case 2:
                    a = "/pages/detail?id=".concat(t.uid), i = "topic";
                }
                a && wx.navigateTo({
                    url: a,
                    success: function() {
                        (0, e.report)("daily_".concat(i, "_title"));
                    }
                });
            }
        }
    }
});