var t, e = (t = require("dayjs")) && t.__esModule ? t : {
    default: t
};

Component({
    data: {
        month: "",
        week: "",
        day: "",
        date: ""
    },
    properties: {
        ts: String,
        size: String,
        theme: String,
        components: {
            type: Array,
            value: [ "date" ]
        }
    },
    observers: {
        ts: function(t) {
            var a = t || Math.trunc(Date.now() / 1e3);
            this.setData({
                month: e.default.unix(a).format("MMMM"),
                week: e.default.unix(a).format("dddd"),
                day: e.default.unix(a).format("DD"),
                date: e.default.unix(a).format("YYYY.MM.DD")
            });
        }
    }
});