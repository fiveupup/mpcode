Component({
    properties: {
        top: Number,
        bottom: Number,
        left: Number,
        right: Number
    },
    attached: function() {
        var t = this, e = this.properties, i = e.top, o = e.bottom, r = e.left, n = e.right, c = wx.createIntersectionObserver(this).relativeToViewport({
            top: i,
            bottom: o,
            left: r,
            right: n
        });
        c.observe(".item", function(e) {
            t.triggerEvent("change", e), e.intersectionRatio > 0 ? t.triggerEvent("show", e) : t.triggerEvent("hide", e);
        }), this.disconnect = function() {
            c.disconnect();
        };
    },
    detached: function() {
        var t;
        null === (t = this.disconnect) || void 0 === t || t.call(this);
    }
});