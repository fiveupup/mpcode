var e = require("../../@babel/runtime/helpers/regeneratorRuntime"), t = require("../../@babel/runtime/helpers/asyncToGenerator"), r = require("../../utils/functional"), n = p(require("../../utils/lodash")), i = c(require("../../store/app")), o = require("mobx-miniprogram-bindings"), s = p(require("../../service/pro")), a = c(require("../../behavior/computed")), u = require("../../service/analyse");

function c(e) {
    return e && e.__esModule ? e : {
        default: e
    };
}

function l(e) {
    if ("function" != typeof WeakMap) return null;
    var t = new WeakMap(), r = new WeakMap();
    return (l = function(e) {
        return e ? r : t;
    })(e);
}

function p(e, t) {
    if (!t && e && e.__esModule) return e;
    if (null === e || "object" != typeof e && "function" != typeof e) return {
        default: e
    };
    var r = l(t);
    if (r && r.has(e)) return r.get(e);
    var n = {}, i = Object.defineProperty && Object.getOwnPropertyDescriptor;
    for (var o in e) if ("default" !== o && Object.prototype.hasOwnProperty.call(e, o)) {
        var s = i ? Object.getOwnPropertyDescriptor(e, o) : null;
        s && (s.get || s.set) ? Object.defineProperty(n, o, s) : n[o] = e[o];
    }
    return n.default = e, r && r.set(e, n), n;
}

Component({
    properties: {
        visible: Boolean,
        entity: Object,
        list: Array
    },
    behaviors: [ o.storeBindingsBehavior, a.default ],
    storeBindings: {
        store: i.default,
        fields: [ "theme", "pro" ]
    },
    computed: {
        subItem: function() {
            var e = this.data.entity, t = null == e ? void 0 : e.id, r = n.get(this.data.pro, "subList", []).find(function(e) {
                return e.key === t;
            });
            return {
                subed: !!r,
                key: t,
                type: s.SUB_TYPES.entity,
                content: null == e ? void 0 : e.name,
                uid: null == r ? void 0 : r.uid
            };
        }
    },
    methods: {
        entitySubscribe: (0, r.singleExec)(t(e().mark(function t() {
            var r, o;
            return e().wrap(function(e) {
                for (;;) switch (e.prev = e.next) {
                  case 0:
                    if ((0, u.report)("subscribebar_add"), (r = this.data.subItem).subed) {
                        e.next = 19;
                        break;
                    }
                    if (!this.selectComponent(".loginDialog").needLogin()) {
                        e.next = 5;
                        break;
                    }
                    return e.abrupt("return", this.selectComponent(".loginDialog").show());

                  case 5:
                    if (i.default.userInfo.isVip) {
                        e.next = 7;
                        break;
                    }
                    return e.abrupt("return", this.selectComponent(".joinProDialog").show(r));

                  case 7:
                    return wx.showLoading(), e.next = 10, s.subscribeEntity(r);

                  case 10:
                    if ((o = e.sent).subscription) {
                        e.next = 13;
                        break;
                    }
                    throw new Error("订阅失败");

                  case 13:
                    n.assign(r, o.subscription), i.default.addProSub(r), wx.hideLoading(), this.selectComponent(".subscribeMessage").authAfterSubscribe(), 
                    e.next = 22;
                    break;

                  case 19:
                    if (i.default.userInfo.isVip) {
                        e.next = 21;
                        break;
                    }
                    return e.abrupt("return", this.selectComponent(".joinProDialog").show());

                  case 21:
                    wx.navigateTo({
                        url: "/pages/pro/subscription_manage"
                    });

                  case 22:
                  case "end":
                    return e.stop();
                }
            }, t, this);
        })), {
            onError: function(e) {
                e.message.indexOf("32") > -1 && setTimeout(function() {
                    wx.navigateTo({
                        url: "/pages/pro/subscription_manage"
                    });
                }, 250);
            }
        }),
        onClose: function() {
            this.triggerEvent("close");
        },
        onClick: function(e) {
            (0, u.report)("detal_list_report");
            var t = e.currentTarget.dataset.id;
            wx.navigateTo({
                url: "/pages/listing_documents/file?id=".concat(t)
            });
        }
    }
});