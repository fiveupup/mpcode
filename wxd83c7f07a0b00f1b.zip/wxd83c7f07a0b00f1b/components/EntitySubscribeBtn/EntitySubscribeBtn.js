var e = require("../../@babel/runtime/helpers/regeneratorRuntime"), t = require("../../@babel/runtime/helpers/asyncToGenerator"), r = require("../../@babel/runtime/helpers/objectSpread2"), n = require("mobx-miniprogram-bindings"), i = b(require("../../store/app")), s = b(require("../../behavior/computed")), o = require("../../utils/lodash"), u = require("../../utils/functional"), a = function(e, t) {
    if (!t && e && e.__esModule) return e;
    if (null === e || "object" != typeof e && "function" != typeof e) return {
        default: e
    };
    var r = c(t);
    if (r && r.has(e)) return r.get(e);
    var n = {}, i = Object.defineProperty && Object.getOwnPropertyDescriptor;
    for (var s in e) if ("default" !== s && Object.prototype.hasOwnProperty.call(e, s)) {
        var o = i ? Object.getOwnPropertyDescriptor(e, s) : null;
        o && (o.get || o.set) ? Object.defineProperty(n, s, o) : n[s] = e[s];
    }
    n.default = e, r && r.set(e, n);
    return n;
}(require("../../service/pro")), p = require("../../service/analyse");

function c(e) {
    if ("function" != typeof WeakMap) return null;
    var t = new WeakMap(), r = new WeakMap();
    return (c = function(e) {
        return e ? r : t;
    })(e);
}

function b(e) {
    return e && e.__esModule ? e : {
        default: e
    };
}

Component({
    properties: {
        entity: {
            type: Object,
            value: null
        },
        from: {
            type: String,
            value: ""
        },
        styleType: {
            type: String,
            value: "default"
        }
    },
    externalClasses: [ "custom-class" ],
    computed: {
        subed: function() {
            var e = (0, o.get)(this.properties.entity, "key");
            if (!e) return !1;
            var t = (0, o.get)(this.data.pro, "subList", []).find(function(t) {
                return t.key === e;
            });
            return !!t && r({}, t);
        }
    },
    behaviors: [ n.storeBindingsBehavior, s.default ],
    storeBindings: {
        store: i.default,
        fields: [ "pro", "theme" ]
    },
    methods: {
        entitySubscribe: (0, u.singleExec)(t(e().mark(function t() {
            var r, n;
            return e().wrap(function(e) {
                for (;;) switch (e.prev = e.next) {
                  case 0:
                    if (!this.selectComponent(".login-dialog").needLogin()) {
                        e.next = 2;
                        break;
                    }
                    return e.abrupt("return", this.selectComponent(".login-dialog").show());

                  case 2:
                    if (this.properties.entity) {
                        e.next = 4;
                        break;
                    }
                    return e.abrupt("return");

                  case 4:
                    if (i.default.userInfo.isVip) {
                        e.next = 6;
                        break;
                    }
                    return e.abrupt("return", this.selectComponent(".joinProDialog").show(this.properties.entity));

                  case 6:
                    return r = this.properties.entity, wx.showLoading(), e.next = 10, a.subscribeEntity(r);

                  case 10:
                    if ((n = e.sent).subscription) {
                        e.next = 13;
                        break;
                    }
                    throw new Error("订阅失败");

                  case 13:
                    (0, o.assign)(r, n.subscription), i.default.addProSub(r), "subscription_manage" === this.properties.from && (0, 
                    p.report)("pro_subscribe"), wx.hideLoading(), this.selectComponent("#subscribeMessage").authAfterSubscribe(), 
                    this.triggerEvent("subed", {
                        entity: r
                    });

                  case 19:
                  case "end":
                    return e.stop();
                }
            }, t, this);
        }))),
        afterJoinPro: function() {
            "search" === this.properties.from && wx.navigateTo({
                url: "/pages/pro/subscription"
            });
        },
        entityUnSubscribe: (0, u.singleExec)(t(e().mark(function t() {
            return e().wrap(function(e) {
                for (;;) switch (e.prev = e.next) {
                  case 0:
                    if (this.data.subed) {
                        e.next = 2;
                        break;
                    }
                    return e.abrupt("return");

                  case 2:
                    return wx.showLoading(), e.next = 5, a.unSubscribeEntity(this.data.subed.uid);

                  case 5:
                    i.default.removeProSub(this.data.subed), wx.hideLoading();

                  case 7:
                  case "end":
                    return e.stop();
                }
            }, t, this);
        })))
    }
});