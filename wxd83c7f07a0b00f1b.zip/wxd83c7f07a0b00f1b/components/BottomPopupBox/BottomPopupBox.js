Component({
    data: {
        popupBoxShow: !1,
        animate: !1,
        hideAnimate: !1
    },
    externalClasses: [ "custom-popup-box" ],
    properties: {
        showClose: {
            type: Boolean,
            value: !0
        },
        disableClose: {
            type: Boolean,
            value: !1
        },
        id: {
            type: String,
            value: "default"
        },
        customStyle: {
            type: String,
            value: ""
        },
        theme: {
            type: String,
            value: ""
        }
    },
    methods: {
        touchmove: function() {
            return !0;
        },
        hide: function(e) {
            var t = this;
            this.properties.disableClose && !0 !== e ? this.triggerEvent("popupboxhidecapture", {
                id: this.properties.id
            }, {
                bubbles: !0,
                composed: !0
            }) : this.data.popupBoxShow && this.setData({
                animate: !1,
                hideAnimate: !0
            }, function() {
                t.timer = setTimeout(function() {
                    t.setData({
                        animate: !1,
                        hideAnimate: !1,
                        popupBoxShow: !1,
                        zIndex: -10
                    }), t.triggerEvent("popupboxhide", {
                        id: t.properties.id
                    }, {
                        bubbles: !0,
                        composed: !0
                    });
                }, 250);
            });
        },
        show: function() {
            var e = this, t = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {};
            this.data.popupBoxShow || (this.setData({
                popupBoxShow: !0,
                hideAnimate: !1,
                zIndex: t.zIndex || 998
            }, function() {
                setTimeout(function() {
                    e.setData({
                        animate: !0
                    });
                }, 20);
            }), this.triggerEvent("popupboxshow", {
                id: this.properties.id
            }, {
                bubbles: !0,
                composed: !0
            }));
        }
    }
});