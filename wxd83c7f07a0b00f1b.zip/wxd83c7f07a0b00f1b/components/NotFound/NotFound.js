var e, i = require("../../utils/mina"), t = require("mobx-miniprogram-bindings"), r = (e = require("../../store/app")) && e.__esModule ? e : {
    default: e
};

var a = (0, i.getSystemInfo)();

Component({
    data: {
        loadingStyle: "height: ".concat(a.windowHeight - 44 - a.statusBarHeight, "px;"),
        initTheme: r.default.theme
    },
    behaviors: [ t.storeBindingsBehavior ],
    storeBindings: {
        store: r.default,
        fields: [ "theme" ]
    }
});