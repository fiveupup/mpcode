var e = require("../../@babel/runtime/helpers/regeneratorRuntime"), t = require("../../@babel/runtime/helpers/asyncToGenerator"), r = require("../../service/topic");

Component({
    properties: {
        theme: String
    },
    data: {
        ts: Date.now().toString().slice(0, 10),
        dailyItems: []
    },
    attached: function() {
        var a = this;
        return t(e().mark(function t() {
            var n, i;
            return e().wrap(function(e) {
                for (;;) switch (e.prev = e.next) {
                  case 0:
                    return n = a.properties.ts, e.next = 3, (0, r.getDaily)(n);

                  case 3:
                    i = e.sent, a.setData({
                        dailyItems: i.data.items.filter(function(e) {
                            return 3 !== e.type;
                        }).slice(0, 3)
                    });

                  case 5:
                  case "end":
                    return e.stop();
                }
            }, t);
        }))();
    },
    methods: {
        goToDaily: function() {
            wx.navigateTo({
                url: "/pages/daily"
            });
        }
    }
});