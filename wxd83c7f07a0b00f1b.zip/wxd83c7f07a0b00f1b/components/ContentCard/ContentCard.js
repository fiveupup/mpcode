Component({
    properties: {
        content: {
            type: Object,
            value: null
        },
        theme: {
            type: String,
            value: "normal"
        }
    },
    methods: {
        goToDetail: function() {
            var t = this.properties.content;
            wx.navigateTo({
                url: "/pages/detail?id=".concat(t.id)
            });
        }
    }
});