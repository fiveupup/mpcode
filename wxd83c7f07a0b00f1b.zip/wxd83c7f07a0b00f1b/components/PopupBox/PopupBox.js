var t = (0, require("../../utils/mina").getSystemInfo)();

Component({
    data: {
        popupBoxShow: !1,
        contentStyle: "width: ".concat(t.windowWidth - 80, "px;"),
        animate: !1
    },
    externalClasses: [ "custom-popup-box" ],
    properties: {
        showClose: {
            type: Boolean,
            value: !0
        },
        disableClose: {
            type: Boolean,
            value: !1
        },
        id: {
            type: String,
            value: "default"
        },
        customStyle: {
            type: String,
            value: ""
        },
        theme: {
            type: String,
            value: ""
        }
    },
    methods: {
        touchmove: function() {
            return !0;
        },
        _hide: function() {
            var t = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {};
            this.properties.disableClose ? this.triggerEvent("popupboxhidecapture", {
                id: this.properties.id
            }, {
                bubbles: !0,
                composed: !0
            }) : this.data.popupBoxShow && (this.setData({
                popupBoxShow: !1,
                animate: !1
            }), this.triggerEvent("popupboxhide", {
                id: this.properties.id,
                from: t.target ? "element" : "program"
            }, {
                bubbles: !0,
                composed: !0
            }));
        },
        hide: function() {
            var t = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {};
            this.data.popupBoxShow && (this.setData({
                popupBoxShow: !1,
                animate: !1
            }), this.triggerEvent("popupboxhide", {
                id: this.properties.id,
                from: t.target ? "element" : "program"
            }, {
                bubbles: !0,
                composed: !0
            }));
        },
        show: function() {
            var t = this;
            this.data.popupBoxShow || (this.setData({
                popupBoxShow: !0
            }, function() {
                setTimeout(function() {
                    t.setData({
                        animate: !0
                    });
                }, 20);
            }), this.triggerEvent("popupboxshow", {
                id: this.properties.id
            }, {
                bubbles: !0,
                composed: !0
            }));
        }
    }
});