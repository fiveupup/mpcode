var t, e = (t = require("../../behavior/store")) && t.__esModule ? t : {
    default: t
};

function r(t) {
    var e = {
        a: {
            dark: "color: #d0d0d0"
        },
        p: {
            all: "margin-bottom: 27px;",
            dark: "color: #d0d0d0"
        },
        img: {
            all: "margin-bottom: 27px"
        },
        li: {
            all: "margin-bottom: 17px"
        }
    }, r = {};
    for (var a in e) {
        var i = e[a], n = i.all, o = i.dark, l = i.light;
        r[a] = [ n, "dark" === t ? o : l ].join(";");
    }
    return r;
}

Component({
    behaviors: [ (0, e.default)([ "theme" ]) ],
    properties: {
        content: String
    },
    data: {
        theme: "",
        html: "",
        tagStyle: {}
    },
    observers: {
        "content, theme": function(t, e) {
            var a = this;
            this.setData({
                html: ""
            }), wx.nextTick(function() {
                a.setData({
                    tagStyle: r(e),
                    html: t
                });
            });
        }
    },
    methods: {
        onLinkTap: function(t) {
            this.triggerEvent("linktap", {
                href: t.detail.href.trim(),
                text: t.detail.innerText.trim()
            });
        },
        onImgTap: function(t) {
            this.triggerEvent("imgtap", t.detail);
        }
    }
});