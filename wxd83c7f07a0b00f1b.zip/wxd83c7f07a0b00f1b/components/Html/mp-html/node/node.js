function t(i) {
    return (t = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(t) {
        return typeof t;
    } : function(t) {
        return t && "function" == typeof Symbol && t.constructor === Symbol && t !== Symbol.prototype ? "symbol" : typeof t;
    })(i);
}

function i(t, i, e) {
    return (i = r(i)) in t ? Object.defineProperty(t, i, {
        value: e,
        enumerable: !0,
        configurable: !0,
        writable: !0
    }) : t[i] = e, t;
}

function r(i) {
    var r = function(i, r) {
        if ("object" !== t(i) || null === i) return i;
        var e = i[Symbol.toPrimitive];
        if (void 0 !== e) {
            var o = e.call(i, r || "default");
            if ("object" !== t(o)) return o;
            throw new TypeError("@@toPrimitive must return a primitive value.");
        }
        return ("string" === r ? String : Number)(i);
    }(i, "string");
    return "symbol" === t(r) ? r : String(r);
}

Component({
    data: {
        ctrl: {},
        isiOS: wx.getSystemInfoSync().system.includes("iOS")
    },
    properties: {
        childs: Array,
        opts: Array
    },
    options: {
        addGlobalClass: !0
    },
    attached: function() {
        this.triggerEvent("add", this, {
            bubbles: !0,
            composed: !0
        });
    },
    methods: {
        noop: function() {},
        getNode: function(t) {
            try {
                for (var i = t.split("_"), r = this.data.childs[i[0]], e = 1; e < i.length; e++) r = r.children[i[e]];
                return r;
            } catch (t) {
                return {
                    text: "",
                    attrs: {},
                    children: []
                };
            }
        },
        play: function(t) {
            if (this.root.triggerEvent("play"), this.root.data.pauseVideo) {
                for (var i = !1, r = t.target.id, e = this.root._videos.length; e--; ) this.root._videos[e].id === r ? i = !0 : this.root._videos[e].pause();
                if (!i) {
                    var o = wx.createVideoContext(r, this);
                    o.id = r, this.root.playbackRate && o.playbackRate(this.root.playbackRate), this.root._videos.push(o);
                }
            }
        },
        imgTap: function(t) {
            var i = this.getNode(t.target.dataset.i);
            if (i.a) return this.linkTap(i.a);
            if (!i.attrs.ignore && (this.root.triggerEvent("imgtap", i.attrs), this.root.data.previewImg)) {
                var r = this.root.imgList[i.i];
                wx.previewImage({
                    showmenu: this.root.data.showImgMenu,
                    current: r,
                    urls: this.root.imgList
                });
            }
        },
        imgLoad: function(t) {
            var r, e = t.target.dataset.i;
            this.getNode(e).w ? (this.data.opts[1] && !this.data.ctrl[e] || -1 === this.data.ctrl[e]) && (r = 1) : r = t.detail.width, 
            r && this.setData(i({}, "ctrl." + e, r)), this.checkReady();
        },
        checkReady: function() {
            var t = this;
            this.root.data.lazyLoad || (this.root.imgList._unloadimgs -= 1, this.root.imgList._unloadimgs || setTimeout(function() {
                t.root.getRect().then(function(i) {
                    t.root.triggerEvent("ready", i);
                }).catch(function() {
                    t.root.triggerEvent("ready", {});
                });
            }, 350));
        },
        linkTap: function(t) {
            var i = t.currentTarget ? this.getNode(t.currentTarget.dataset.i) : {}, r = i.attrs || t, e = r.href;
            this.root.triggerEvent("linktap", Object.assign({
                innerText: this.root.getText(i.children || [])
            }, r)), e && ("#" === e[0] ? this.root.navigateTo(e.substring(1)).catch(function() {}) : e.split("?")[0].includes("://") ? this.root.data.copyLink && wx.setClipboardData({
                data: e,
                success: function() {
                    return wx.showToast({
                        title: "链接已复制"
                    });
                }
            }) : wx.navigateTo({
                url: e,
                fail: function() {
                    wx.switchTab({
                        url: e,
                        fail: function() {}
                    });
                }
            }));
        },
        mediaError: function(t) {
            var r = t.target.dataset.i, e = this.getNode(r);
            if ("video" === e.name || "audio" === e.name) {
                var o = (this.data.ctrl[r] || 0) + 1;
                if (o > e.src.length && (o = 0), o < e.src.length) return this.setData(i({}, "ctrl." + r, o));
            } else "img" === e.name && (this.data.opts[2] && this.setData(i({}, "ctrl." + r, -1)), 
            this.checkReady());
            this.root && this.root.triggerEvent("error", {
                source: e.name,
                attrs: e.attrs,
                errMsg: t.detail.errMsg
            });
        }
    }
});