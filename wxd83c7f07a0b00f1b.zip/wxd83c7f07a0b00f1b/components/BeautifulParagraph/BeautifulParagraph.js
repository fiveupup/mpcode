var e = require("../../utils/mina"), t = require("../../utils/tools"), r = require("../../utils/lodash"), s = (0, 
e.isPcPlatform)();

Component({
    data: {
        needJustify: !1,
        summaryWords: [],
        paragraphs: [],
        isInPc: s,
        processing: !0,
        needIndent: !1
    },
    injectConfig: {
        skip_track_methods: !0
    },
    properties: {
        maxLines: Number,
        content: {
            type: String,
            value: "",
            observer: function(e, t) {
                e && /[《「]/.test(e[0]) && this.setData({
                    needIndent: !0
                }), t && e && t !== e && this.formatSummary();
            }
        },
        measure: {
            type: Number,
            value: 18
        },
        keys: {
            type: Array,
            value: []
        },
        dateKeys: {
            type: Array,
            value: []
        },
        stockKeys: {
            type: Array,
            value: [],
            observer: function(e) {
                this.formatSummaryNoReCompute();
            }
        },
        theme: {
            type: String,
            value: "normal"
        },
        dateSetedKeys: {
            type: Array,
            value: []
        }
    },
    lifetimes: {
        ready: function() {
            this.formatSummary();
        }
    },
    methods: {
        processDateKeys: function(e) {
            var t = this;
            return (this.properties.dateKeys.length > 0 || this.properties.stockKeys.length > 0) && e.forEach(function(e) {
                "key" === e.type && t.properties.dateKeys.indexOf(e.text) > -1 ? (e.type = "key date", 
                e.isDate = !0) : t.properties.stockKeys.indexOf(e.text) > -1 && (e.type = "key stock");
            }), e;
        },
        onLongpressText: function(e) {
            var t = e.currentTarget.dataset, r = t.type, s = void 0 === r ? "" : r, a = t.text;
            s.indexOf(!1) && this.triggerEvent("keyLongpress", {
                key: a
            });
        },
        onTapText: function(e) {
            var t = e.currentTarget.dataset, r = t.type, s = void 0 === r ? "" : r, a = t.text;
            "key date" === s ? this.triggerEvent("dateTap", {
                key: a.replace("📅 ", "")
            }) : "key stock" === s ? this.triggerEvent("stockTap", {
                key: a
            }) : s.indexOf("key") > -1 && this.triggerEvent("keyTap", {
                key: a
            });
        },
        formatSummaryNoReCompute: function() {
            var e = this, t = this.data, r = t.summaryWords, s = t.paragraphs;
            s.length > 0 ? (s = s.map(function(t) {
                return e.processDateKeys(t);
            }), this.setData({
                paragraphs: s
            })) : r.length > 0 && (r = this.processDateKeys(r), this.setData({
                summaryWords: r
            }));
        },
        formatSummary: function() {
            var e, s = this;
            this.setData({
                needJustify: !1,
                summaryWords: [],
                paragraphs: [],
                processing: !0
            }, function() {
                var a = s.createSelectorQuery();
                a.select(".bp").boundingClientRect(), a.exec(function(a) {
                    if (a[0]) {
                        e = a[0].width;
                        var n = s.properties.content;
                        if (n) {
                            var i = s.processDateKeys((0, t.splitCJKWord)(n, (0, r.cloneDeep)(s.properties.keys)));
                            s.setData({
                                summaryWords: i,
                                needJustify: !1
                            }, function() {
                                var a = [], o = s.createSelectorQuery();
                                o.selectAll(".flag").boundingClientRect(), o.exec(function(o) {
                                    var p = o[0];
                                    if (!p) return s.setData({
                                        processing: !1
                                    });
                                    for (var u = p.length, y = null, c = null, d = !0, m = [], f = 0; f < u; f++) f % 2 != 0 ? (c = p[f], 
                                    y.top !== c.top && e - y.left > s.properties.measure && (d = !1, a.push(+y.dataset.index))) : y = p[f];
                                    if (a.length > 0) {
                                        var l = "";
                                        i.forEach(function(e, t) {
                                            if (a.indexOf(t) > -1) return m.push(l), void (l = "");
                                            l += e.text || "";
                                        }), l && (m.push(l), l = "");
                                    }
                                    var h = (0, r.cloneDeep)(s.properties.keys), g = (0, r.cloneDeep)(s.properties.keys);
                                    s.setData({
                                        processing: !1,
                                        needJustify: d,
                                        summaryWords: s.processDateKeys((0, t.splitPunctuationWord)(n, h)),
                                        paragraphs: m.map(function(e) {
                                            return s.processDateKeys((0, t.splitPunctuationWord)(e, g));
                                        })
                                    });
                                });
                            });
                        }
                    } else s.setData({
                        processing: !1
                    });
                });
            });
        }
    }
});