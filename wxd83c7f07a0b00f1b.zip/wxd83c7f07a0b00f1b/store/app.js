Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.default = void 0;

var e = require("../@babel/runtime/helpers/objectSpread2"), t = require("mobx-miniprogram"), i = o(require("dayjs")), s = o(require("../config")), n = o(require("../utils/logger"));

function o(e) {
    return e && e.__esModule ? e : {
        default: e
    };
}

var a = wx.getSystemInfoSync(), c = (0, t.observable)({
    theme: "normal",
    themeMode: "system",
    isHideSummary: !1,
    showAd: !0,
    inited: !1,
    templates: [],
    setting: {
        isIOS: a.system.indexOf("iOS") > -1
    },
    searchSetting: {
        hideRecommend: !1,
        searchHistory: []
    },
    minaSetting: {
        authSetting: {},
        subscriptionsSetting: {
            mainSwitch: !0
        }
    },
    isDailyReject: !1,
    subscribeState: {
        daily: !1,
        subscribOfficiaAccount: !0,
        weekly: !1
    },
    userInfo: {
        isVip: !1
    },
    pro: {
        subList: []
    },
    changeInit: (0, t.action)(function(e) {
        console.log("change init", e), this.inited = e;
    }),
    changeSearchSetting: (0, t.action)(function(t) {
        console.log("change search setting", t), this.searchSetting = e(e({}, this.searchSetting), t), 
        this._saveAppConfig();
    }),
    changeMinaSetting: (0, t.action)(function(t) {
        console.log("change mina setting", t), this.minaSetting = e(e({}, this.minaSetting), t);
        var i = this.templates.find(function(e) {
            return "DAILY" === e.typeName;
        });
        if (i) {
            var s = this.minaSetting.subscriptionsSetting, n = !1;
            s.mainSwitch || (n = !0), s.itemSettings && "reject" === s.itemSettings[i.tmplId] && (n = !0), 
            this.isDailyReject = n, console.log("change isDailyReject", n);
        }
    }),
    changeSetting: (0, t.action)(function(t) {
        console.log("change setting", t), this.setting = e(e({}, this.setting), t), this._saveAppConfig();
    }),
    changeTemplates: (0, t.action)(function(e) {
        console.log("change templates", e), this.templates = e;
    }),
    toggleAd: (0, t.action)(function(e) {
        console.log("toggle ad", e), this.showAd = e, this._saveAppConfig();
    }),
    addProSub: (0, t.action)(function(e) {
        console.log("add pro sub", e);
        var t = this.pro.subList || [];
        t.find(function(t) {
            return t.uid === e.uid;
        }) || (e.subed = !0, t.unshift(e), this.pro = {
            subList: t
        }, console.log("add pro sub success"));
    }),
    removeProSub: (0, t.action)(function(e) {
        console.log("remove pro sub", e);
        var t = this.pro.subList || [], i = t.findIndex(function(t) {
            return t.uid === e.uid;
        });
        i > -1 && (t.splice(i, 1), this.pro = {
            subList: t
        }, console.log("remove pro sub success"));
    }),
    changeUserInfo: (0, t.action)(function(t) {
        n.default.log("change user info state:", t), void 0 === t.isVip && (t.isVip = !1), 
        getApp().globalData.inited && !this.userInfo.isVip && t.isVip && getApp().getUserSubscription();
        var s = e(e({}, this.userInfo), t);
        s.vipExpiredAt ? (s.isVipExpired = new Date() > new Date(s.vipExpiredAt), s.vipExpiredAtDisplay = (0, 
        i.default)(s.vipExpiredAt).format("YYYY.MM.DD")) : (delete s.isVipExpired, delete s.vipExpiredAtDisplay), 
        this.userInfo = s;
    }),
    changeSubscribeState: (0, t.action)(function(t) {
        n.default.log("change subscribe state:", t), this.subscribeState = e(e({}, this.subscribeState), t);
    }),
    changeTheme: (0, t.action)(function(e) {
        n.default.log("change theme: ".concat(this.theme, " -> ").concat(e)), this.theme !== e && (this.theme = e, 
        this._saveAppConfig());
    }),
    changeThemeMode: (0, t.action)(function(e) {
        var t = !(arguments.length > 1 && void 0 !== arguments[1]) || arguments[1];
        n.default.log("change theme mode: ".concat(this.themeMode, " -> ").concat(e)), this.themeMode = e;
        var i = wx.getSystemInfoSync().theme;
        "light" === i && (i = "normal"), i ? "system" === e && this.changeTheme(i) : (this.themeMode = "manual", 
        t || wx.showToast({
            title: "微信版本过低，请升级微信",
            icon: "none"
        })), this._saveAppConfig();
    }),
    toggleHideSummary: (0, t.action)(function(e) {
        n.default.log("toggle hide summary: ".concat(this.isHideSummary, " -> ").concat(e)), 
        this.isHideSummary !== e && (this.isHideSummary = e, this._saveAppConfig());
    }),
    _saveAppConfig: function() {
        wx.setStorage({
            key: s.default.APP_SETTING_KEY,
            data: {
                isHideSummary: this.isHideSummary,
                theme: this.theme,
                themeMode: this.themeMode,
                showAd: this.showAd,
                setting: this.setting,
                searchSetting: this.searchSetting
            }
        });
    }
});

exports.default = c;