Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.CustomScreenView = function(t, r) {
    if ((0, n.isWechatCrawler)()) return;
    e.screenView(t, r || {});
}, exports.eventGa = f, exports.getTracker = p, exports.pageView = function(e) {
    var r = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : "";
    if ((0, n.isWechatCrawler)()) return;
    var i = p();
    if (i) {
        var o = new v().setDocumentLocationURL(t.default.GA.web || "").setDocumentHostName(t.default.GA.web || "").setDocumentPath(e).setDocumentTitle(r).build(), u = getCurrentPages(), a = u[u.length - 1];
        a && Object.assign(o, a.gaOptions || {}), i.send(o);
    }
}, exports.report = function(t) {
    var r = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {};
    if ((0, n.isWechatCrawler)()) return;
    console.info("analyse report ".concat(t), r), e.report(t, r);
}, exports.reportListResultShow = function(t, r) {
    if ((0, n.isWechatCrawler)()) return;
    if (!t) return;
    var i = r.map(function(e) {
        return e.unique_id || e.uniqueId;
    }).join("_"), o = e.event("list_result_show", "show", i, [ {
        index: u,
        value: t
    } ], [ {
        index: a,
        value: 1
    } ]);
    (o = o.build()).cd = t, p().send(o);
}, exports.reportSearchEmpty = function(e) {
    if ((0, n.isWechatCrawler)()) return;
    if (!e) return;
    f("list_result_0query", "search", decodeURIComponent(e));
}, exports.reportSearchEvent = function(e) {
    if ((0, n.isWechatCrawler)()) return;
    if (!e) return;
    f("search", "minarequest", decodeURIComponent(e));
}, exports.reportSearchResultClick = function(t, r, i) {
    if ((0, n.isWechatCrawler)()) return;
    if (!t) return;
    var o = [ {
        index: u,
        value: t
    } ], a = [ {
        index: s,
        value: 1
    }, {
        index: c,
        value: i
    } ], l = e.event("list_result_click", "click", "".concat(r.unique_id, "_").concat(i), o, a);
    (l = l.build()).cd = t, p().send(l);
}, exports.searchEntityQuery = function(e) {
    return e.id ? "q=e_".concat(e.text || e.name, "_").concat(e.id, "_").concat(e.type) : "q=k_".concat(e.text || e.name || e.keyword);
}, exports.setDimensions = g, exports.setDimensionsMetrics = w, exports.setMetrics = y, 
exports.setUid = function(t) {
    e.setUid(t);
}, exports.socialGA = function(e, t) {
    var n = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : "", i = arguments.length > 3 ? arguments[3] : void 0, o = arguments.length > 4 ? arguments[4] : void 0;
    r.default.log("socialGA", e, t, n);
    var u = new d().setNetwork(e).setAction(t).setTarget(n);
    i && i.length && w(u, i, o);
    var a = u.build();
    p().send(a);
};

var e = function(e, t) {
    if (!t && e && e.__esModule) return e;
    if (null === e || "object" != typeof e && "function" != typeof e) return {
        default: e
    };
    var r = o(t);
    if (r && r.has(e)) return r.get(e);
    var n = {}, i = Object.defineProperty && Object.getOwnPropertyDescriptor;
    for (var u in e) if ("default" !== u && Object.prototype.hasOwnProperty.call(e, u)) {
        var a = i ? Object.getOwnPropertyDescriptor(e, u) : null;
        a && (a.get || a.set) ? Object.defineProperty(n, u, a) : n[u] = e[u];
    }
    n.default = e, r && r.set(e, n);
    return n;
}(require("mina-analyse")), t = i(require("../config")), r = i(require("../utils/logger")), n = require("../utils/mina");

function i(e) {
    return e && e.__esModule ? e : {
        default: e
    };
}

function o(e) {
    if ("function" != typeof WeakMap) return null;
    var t = new WeakMap(), r = new WeakMap();
    return (o = function(e) {
        return e ? r : t;
    })(e);
}

var u = 1, a = 1, s = 2, c = 3, l = e.GA, d = l.HitBuilders.SocialBuilder;

function p() {
    return e.getTracker();
}

function f(t) {
    var r = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : "", i = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : "";
    if (!(0, n.isWechatCrawler)()) {
        var o = e.event(t, r, i);
        o = o.build(), p().send(o);
    }
}

e.init({
    name: t.default.GA.name,
    id: t.default.GA.id,
    version: t.default.VERSION,
    proxy: t.default.GA.proxy,
    enableScreenView: function() {
        return !1;
    }
});

var h = l.HitBuilders.HitBuilder;

function v() {
    h.call(this), this.setHitType("pageview"), this.setAll({
        dl: "",
        dh: "",
        dp: "",
        dt: "Readhub 小程序",
        ds: "web"
    });
}

function g(e) {
    var t = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : [];
    e && t && t.length > 0 && t.forEach(function(t) {
        e.setCustomDimension(t.index, t.value);
    });
}

function y(e) {
    var t = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : [];
    t && t.length > 0 && t.forEach(function(t) {
        e.setCustomMetric(t.index, t.value);
    });
}

function w(e) {
    var t = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : [], r = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : [];
    g(e, t), y(e, r);
}

v.prototype = Object.create(h.prototype), v.prototype.constructor = v, v.prototype.setDocumentLocationURL = function(e) {
    return this.set("dl", e);
}, v.prototype.setDocumentHostName = function(e) {
    return this.set("dh", e);
}, v.prototype.setDocumentPath = function(e) {
    return this.set("dp", e);
}, v.prototype.setDocumentTitle = function(e) {
    return this.set("dt", e);
}, v.prototype.build = function() {
    return h.prototype.build.apply(this, arguments);
};