Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.getBalance = function() {
    return i.apply(this, arguments);
}, exports.getTransactionRecords = function() {
    return c.apply(this, arguments);
}, exports.withdraw = function(t) {
    return o.apply(this, arguments);
};

var t = require("../@babel/runtime/helpers/regeneratorRuntime"), e = require("../@babel/runtime/helpers/asyncToGenerator"), r = u(require("../utils/request")), a = u(require("../config")), n = u(require("dayjs"));

function u(t) {
    return t && t.__esModule ? t : {
        default: t
    };
}

function i() {
    return (i = e(t().mark(function e() {
        return t().wrap(function(t) {
            for (;;) switch (t.prev = t.next) {
              case 0:
                return t.abrupt("return", (0, r.default)({
                    url: "".concat(a.default.COMMON_API_HOST, "/wallet/balance")
                }));

              case 1:
              case "end":
                return t.stop();
            }
        }, e);
    }))).apply(this, arguments);
}

function c() {
    return (c = e(t().mark(function e() {
        var u, i, c = arguments;
        return t().wrap(function(t) {
            for (;;) switch (t.prev = t.next) {
              case 0:
                return u = c.length > 0 && void 0 !== c[0] ? c[0] : 1, i = c.length > 1 && void 0 !== c[1] ? c[1] : 10, 
                t.abrupt("return", (0, r.default)({
                    url: "".concat(a.default.COMMON_API_HOST, "/wallet/transaction/list?page=").concat(u, "&size=").concat(i)
                }).then(function(t) {
                    return (t.data.items || []).forEach(function(t) {
                        t.transactionDate && ((0, n.default)(t.transactionDate).isSame((0, n.default)(), "year") ? t.transactionDateDisplay = (0, 
                        n.default)(t.transactionDate).format("MM 月 DD 日 HH:mm") : t.transactionDateDisplay = (0, 
                        n.default)(t.transactionDate).format("YYYY 年 MM 月 DD 日 HH:mm"));
                    }), t;
                }));

              case 3:
              case "end":
                return t.stop();
            }
        }, e);
    }))).apply(this, arguments);
}

function o() {
    return (o = e(t().mark(function e(n) {
        return t().wrap(function(t) {
            for (;;) switch (t.prev = t.next) {
              case 0:
                return t.abrupt("return", (0, r.default)({
                    url: "".concat(a.default.COMMON_API_HOST, "/pay_withdraw/withdraw/wx"),
                    method: "POST",
                    data: {
                        price: n
                    }
                }));

              case 1:
              case "end":
                return t.stop();
            }
        }, e);
    }))).apply(this, arguments);
}