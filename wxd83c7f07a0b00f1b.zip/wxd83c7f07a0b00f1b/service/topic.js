Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.fetchMinaCode = function(t) {
    return O.apply(this, arguments);
}, exports.getDaily = function(t, e) {
    return T.apply(this, arguments);
}, exports.getEntityShareImage = function(t, e) {
    return x.apply(this, arguments);
}, exports.getEntityTimelineShareImage = function(t, e) {
    return b.apply(this, arguments);
}, exports.getTagShareImage = function(t, e) {
    return I.apply(this, arguments);
}, exports.getTagTimelineShareImage = function(t, e) {
    return A.apply(this, arguments);
}, exports.getTimeline = function(t) {
    return w.apply(this, arguments);
}, exports.getTopic = function(t) {
    return _.apply(this, arguments);
}, exports.getTopics = function(t, e) {
    return m.apply(this, arguments);
}, exports.topicOfficialShareImage = function(t, e) {
    return g.apply(this, arguments);
}, exports.topicsProcess = f;

var t = require("../@babel/runtime/helpers/regeneratorRuntime"), e = require("../@babel/runtime/helpers/asyncToGenerator"), r = p(require("../config")), n = require("../utils/format"), a = p(require("../utils/mergeNews")), i = p(require("../utils/request")), u = p(require("./ad")), c = p(require("../store/app")), o = require("./analyse"), s = require("../utils/tools"), l = p(require("lodash"));

function p(t) {
    return t && t.__esModule ? t : {
        default: t
    };
}

function f(t, e, r) {
    t.forEach(function(t) {
        (r || "topic" === t.type) && (t.originTitle = t.title, t.relate = (0, n.sitesInfo)(t.newsArray), 
        t.title = (0, n.newsTitleFormat)(t.title), t.summary = (0, n.newsTitleFormat)(t.summary), 
        t.needIndent = "「" === t.title[0], t.timeline && t.timeline.topics && t.timeline.topics.forEach(function(t) {
            t.displayDateTime = (0, n.absoluteDatetime)(t.publishDate), t.title = (0, n.newsTitleFormat)(t.title);
        }), e && t.newsArray && (t.mergedNews = (0, a.default)(t.newsArray), t.mergedNews.forEach(function(t) {
            t.title = (0, n.newsTitleFormat)(t.title);
        })));
    });
}

var d = 1;

function m() {
    return (m = e(t().mark(function e(n, a) {
        var s, l, p, m;
        return t().wrap(function(t) {
            for (;;) switch (t.prev = t.next) {
              case 0:
                return t.prev = 0, s = !a, a = a ? "".concat(r.default.API_HOST).concat(a) : "".concat(r.default.API_HOST, "/topic/list?type=").concat(n), 
                t.next = 5, (0, i.default)({
                    url: a,
                    method: "GET"
                });

              case 5:
                return (l = t.sent).data.forEach(function(t) {
                    t.appId && !t.id && (t.id = t.appId + d++);
                }), f(l.data), !c.default.showAd && c.default.userInfo.isVip || (p = u.default.genAd && u.default.genAd(), 
                console.log("show ad", p), p && (p.type = "sponsor", l.data.push(p), (0, o.report)("ad_show", {
                    id: p.name
                }))), s && (m = {
                    type: "wecomGroup"
                }, l.data.splice(5, 0, m)), t.abrupt("return", l);

              case 13:
                return t.prev = 13, t.t0 = t.catch(0), t.abrupt("return", {
                    data: []
                });

              case 16:
              case "end":
                return t.stop();
            }
        }, e, null, [ [ 0, 13 ] ]);
    }))).apply(this, arguments);
}

function y(t) {
    return l.default.map(t, function(t) {
        return {
            createdAt: t.createdAt,
            publishDate: t.publishDate,
            displayDateTime: (0, n.absoluteDatetime)(t.publishDate),
            id: t.uid,
            title: (0, n.newsTitleFormat)(t.title)
        };
    });
}

function h(t) {
    var e, r;
    return {
        createdAt: t.createdAt,
        entityTopics: l.default.map(t.entityList, function(t) {
            return {
                entityId: t.uid,
                entityName: t.name,
                entityType: t.type,
                nerName: t.nerName,
                hasStock: t.hasStock
            };
        }),
        eventData: {
            result: l.default.map(t.eventList, function(t) {
                return {
                    entityId: t.entityId,
                    entityName: t.entityName,
                    entityType: t.entityType,
                    eventType: t.eventType,
                    eventTypeLabel: t.eventNameDisplay
                };
            })
        },
        hasInstantView: t.hasView,
        id: t.uid,
        itemId: t.itemId,
        instantViewNewsId: t.viewNewsId,
        newsArray: l.default.map(t.newsAggList, function(t) {
            return {
                hasInstantView: t.hasView,
                id: t.uid,
                siteName: t.siteNameDisplay,
                statementType: t.statementType,
                title: t.title,
                url: t.url
            };
        }),
        publishDate: t.publishDate,
        summary: t.summary,
        tags: l.default.map(t.tagList, function(t) {
            return {
                uid: t.uid,
                name: t.name
            };
        }),
        timeline: {
            commonEntities: null == t || null === (e = t.timeline) || void 0 === e ? void 0 : e.commonEntityList,
            topics: y(null == t || null === (r = t.timeline) || void 0 === r ? void 0 : r.topics)
        },
        timelineId: t.timelineId,
        title: t.title
    };
}

function _() {
    return (_ = e(t().mark(function e(n) {
        var a, u, c, o, s;
        return t().wrap(function(t) {
            for (;;) switch (t.prev = t.next) {
              case 0:
                return c = "".concat(r.default.COMMON_API_HOST, "/topic/detail?uid=").concat(n), 
                t.next = 3, (0, i.default)({
                    url: c,
                    method: "GET"
                });

              case 3:
                return o = t.sent, (s = h(null == o || null === (a = o.data) || void 0 === a || null === (u = a.items) || void 0 === u ? void 0 : u[0])) && f([ s ], !0, !0), 
                t.abrupt("return", s);

              case 7:
              case "end":
                return t.stop();
            }
        }, e);
    }))).apply(this, arguments);
}

function v(t) {
    var e, r;
    return {
        title: null == t || null === (e = t.self) || void 0 === e ? void 0 : e.title,
        topicTitle: null == t || null === (r = t.self) || void 0 === r ? void 0 : r.topicTitle,
        topics: y(t.items)
    };
}

function w() {
    return (w = e(t().mark(function e(n) {
        var a, u, c;
        return t().wrap(function(t) {
            for (;;) switch (t.prev = t.next) {
              case 0:
                return a = "".concat(r.default.COMMON_API_HOST, "/topic/timeline/list?topic_uid=").concat(n), 
                t.next = 3, (0, i.default)({
                    url: a,
                    method: "GET"
                });

              case 3:
                return u = t.sent, c = v(u.data || {}), t.abrupt("return", c);

              case 6:
              case "end":
                return t.stop();
            }
        }, e);
    }))).apply(this, arguments);
}

function T() {
    return (T = e(t().mark(function e(a, u) {
        var c, o, l;
        return t().wrap(function(t) {
            for (;;) switch (t.prev = t.next) {
              case 0:
                return c = {}, a && (c.ts = a), u && (c._refresh_ = "_refresh_"), o = "".concat(r.default.COMMON_API_HOST, "/daily?").concat((0, 
                s.queryString)(c)), t.next = 6, (0, i.default)({
                    url: o
                });

              case 6:
                return (l = t.sent).data.items.forEach(function(t) {
                    t.title = (0, n.newsTitleFormat)(t.title);
                }), t.abrupt("return", l);

              case 9:
              case "end":
                return t.stop();
            }
        }, e);
    }))).apply(this, arguments);
}

function g() {
    return (g = e(t().mark(function e(n, a) {
        var u;
        return t().wrap(function(t) {
            for (;;) switch (t.prev = t.next) {
              case 0:
                return u = "".concat(r.default.API_HOST, "/topic/").concat(n, "/image_brief"), a && (u += "?_force_=_force_"), 
                t.next = 4, (0, i.default)({
                    url: u
                });

              case 4:
                return t.abrupt("return", t.sent);

              case 5:
              case "end":
                return t.stop();
            }
        }, e);
    }))).apply(this, arguments);
}

function x() {
    return (x = e(t().mark(function e(n, a) {
        var u;
        return t().wrap(function(t) {
            for (;;) switch (t.prev = t.next) {
              case 0:
                return u = "".concat(r.default.API_HOST, "/entity/").concat(n, "/image"), a && (u += "?_force_=_force_"), 
                t.next = 4, (0, i.default)({
                    url: u
                });

              case 4:
                return t.abrupt("return", t.sent);

              case 5:
              case "end":
                return t.stop();
            }
        }, e);
    }))).apply(this, arguments);
}

function I() {
    return (I = e(t().mark(function e(n, a) {
        var u;
        return t().wrap(function(t) {
            for (;;) switch (t.prev = t.next) {
              case 0:
                return u = "".concat(r.default.API_HOST, "/tag/").concat(n, "/image"), a && (u += "?_force_=_force_"), 
                t.next = 4, (0, i.default)({
                    url: u
                });

              case 4:
                return t.abrupt("return", t.sent);

              case 5:
              case "end":
                return t.stop();
            }
        }, e);
    }))).apply(this, arguments);
}

function b() {
    return (b = e(t().mark(function e(n, a) {
        var u;
        return t().wrap(function(t) {
            for (;;) switch (t.prev = t.next) {
              case 0:
                return u = "".concat(r.default.API_HOST, "/entity/").concat(n, "/image_brief"), 
                a && (u += "?_force_=_force_"), t.next = 4, (0, i.default)({
                    url: u
                });

              case 4:
                return t.abrupt("return", t.sent);

              case 5:
              case "end":
                return t.stop();
            }
        }, e);
    }))).apply(this, arguments);
}

function A() {
    return (A = e(t().mark(function e(n, a) {
        var u;
        return t().wrap(function(t) {
            for (;;) switch (t.prev = t.next) {
              case 0:
                return u = "".concat(r.default.API_HOST, "/tag/").concat(n, "/image_brief"), a && (u += "?_force_=_force_"), 
                t.next = 4, (0, i.default)({
                    url: u
                });

              case 4:
                return t.abrupt("return", t.sent);

              case 5:
              case "end":
                return t.stop();
            }
        }, e);
    }))).apply(this, arguments);
}

function O() {
    return (O = e(t().mark(function e(n) {
        var a, u, c, o;
        return t().wrap(function(t) {
            for (;;) switch (t.prev = t.next) {
              case 0:
                return t.next = 2, (0, i.default)({
                    url: "".concat(r.default.COMMON_API_HOST, "/topic/detail/qrcode_min_program?uid=").concat(n)
                });

              case 2:
                return o = t.sent, t.abrupt("return", (null == o || null === (a = o.data) || void 0 === a || null === (u = a.items) || void 0 === u || null === (c = u[0]) || void 0 === c ? void 0 : c.url) || "");

              case 4:
              case "end":
                return t.stop();
            }
        }, e);
    }))).apply(this, arguments);
}