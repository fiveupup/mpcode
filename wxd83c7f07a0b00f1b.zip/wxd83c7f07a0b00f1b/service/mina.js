Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.authSubscribeMesssage = function(r) {
    return new Promise(function(t, s) {
        var o, i = Object.prototype.toString.call(r);
        if ("[object Array]" === i) o = r; else {
            if ("[object String]" !== i) return s(new Error("templateIds type error"));
            o = [ r ];
        }
        console.log("authSubscribeMesssage", o), wx.requestSubscribeMessage && "mac" !== e.platform ? wx.requestSubscribeMessage({
            tmplIds: o,
            success: function(e) {
                return "requestSubscribeMessage:ok" !== e.errMsg ? t([ new Error(e.errMsg), {} ]) : t([ null, e || {} ]);
            },
            fail: function(e) {
                t([ new Error(e.errMsg), {} ]);
            }
        }) : t([ new Error("不支持 requestSubscribeMessage"), {} ]);
    });
}, exports.toShareEntityInOfficial = function(e) {
    wx.navigateTo({
        url: "/pages/share_official?type=entity&id=".concat(e)
    });
}, exports.toShareTagInOfficial = function(e) {
    wx.navigateTo({
        url: "/pages/share_official?type=tag&id=".concat(e)
    });
}, exports.toShareTopicInOfficial = function(e, r) {
    r && (getApp()._tempTopic = r);
    wx.navigateTo({
        url: "/pages/share_official?type=topic&id=".concat(e)
    });
};

var e = (0, require("@mina-modules/system-info").getSysInfo)();