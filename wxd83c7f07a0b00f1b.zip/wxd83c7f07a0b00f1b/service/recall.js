Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.isNewDailyUserFromSearch = function() {
    var e = wx.getEnterOptionsSync().scene;
    if (-1 === [ 1005, 1053 ].indexOf(e) && !r.default.userInfo.manager) return !1;
    if (r.default.subscribeState.daily) return !1;
    return !0;
};

var e, r = (e = require("../store/app")) && e.__esModule ? e : {
    default: e
};