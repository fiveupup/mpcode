Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.authUserInfo = function() {
    return m.apply(this, arguments);
}, exports.checkSubscribe = function() {
    return h.apply(this, arguments);
}, exports.getDailyImage = function(e, t) {
    return v.apply(this, arguments);
}, exports.getUserProfile = function() {
    return l.apply(this, arguments);
}, exports.isManager = function() {
    return !!getApp().globalData.userInfo.manager;
}, exports.needAuthUserInfo = function() {
    return !!getApp().globalData.userInfo.updateProfile;
}, exports.needLogin = function() {
    return y.apply(this, arguments);
}, exports.pay = function(e) {
    return g.apply(this, arguments);
}, exports.payPro = function(e) {
    return S.apply(this, arguments);
}, exports.payProContact = function(e) {
    return P.apply(this, arguments);
}, exports.subscribe = function(e) {
    return b.apply(this, arguments);
}, exports.unsubscribe = function(e) {
    return w.apply(this, arguments);
}, exports.updateUserInfo = function(e, t) {
    return x.apply(this, arguments);
}, exports.updateWechatUserInfo = function(e) {
    return d.apply(this, arguments);
}, exports.uploadUserAvatar = function(e) {
    return f.apply(this, arguments);
};

var e = require("../@babel/runtime/helpers/regeneratorRuntime"), t = require("../@babel/runtime/helpers/asyncToGenerator"), r = p(require("../config")), n = function(e, t) {
    if (!t && e && e.__esModule) return e;
    if (null === e || "object" != typeof e && "function" != typeof e) return {
        default: e
    };
    var r = i(t);
    if (r && r.has(e)) return r.get(e);
    var n = {}, a = Object.defineProperty && Object.getOwnPropertyDescriptor;
    for (var u in e) if ("default" !== u && Object.prototype.hasOwnProperty.call(e, u)) {
        var o = a ? Object.getOwnPropertyDescriptor(e, u) : null;
        o && (o.get || o.set) ? Object.defineProperty(n, u, o) : n[u] = e[u];
    }
    n.default = e, r && r.set(e, n);
    return n;
}(require("../utils/lodash")), a = p(require("../utils/request")), u = require("../utils/mina"), o = p(require("../store/app")), s = require("../service/pro"), c = p(require("dayjs"));

function i(e) {
    if ("function" != typeof WeakMap) return null;
    var t = new WeakMap(), r = new WeakMap();
    return (i = function(e) {
        return e ? r : t;
    })(e);
}

function p(e) {
    return e && e.__esModule ? e : {
        default: e
    };
}

function f() {
    return (f = t(e().mark(function t(n) {
        var u, o, s, c, i, p, f, l, d, x, h, b;
        return e().wrap(function(e) {
            for (;;) switch (e.prev = e.next) {
              case 0:
                return e.next = 2, (0, a.default)({
                    url: "".concat(r.default.COMMON_API_HOST, "/readhub_resource/pre_upload/avatar"),
                    header: {
                        "x-oss-object-acl": "public-read"
                    },
                    method: "POST",
                    data: {
                        ext: "jpeg"
                    }
                });

              case 2:
                return d = e.sent.data.items[0], x = {}, e.prev = 4, e.next = 7, wx.getStorage({
                    key: r.default.USER_KEY
                });

              case 7:
                x = e.sent.data, e.next = 12;
                break;

              case 10:
                e.prev = 10, e.t0 = e.catch(4);

              case 12:
                return h = "", x.token && (h = "Bearer ".concat(x.token)), e.next = 16, new Promise(function(e, t) {
                    wx.uploadFile({
                        url: d.url,
                        filePath: n,
                        header: {
                            "x-oss-object-acl": "public-read",
                            Authorization: h
                        },
                        name: "file",
                        formData: d.params,
                        success: function(t) {
                            e(t.data);
                        },
                        fail: function(e) {
                            t(e);
                        }
                    });
                });

              case 16:
                return "string" == typeof (b = e.sent) && (b = JSON.parse(b)), e.abrupt("return", {
                    url: null === (u = b) || void 0 === u || null === (o = u.data) || void 0 === o || null === (s = o.items) || void 0 === s || null === (c = s[0]) || void 0 === c ? void 0 : c.url,
                    isChecked: null === (i = b) || void 0 === i || null === (p = i.data) || void 0 === p || null === (f = p.items) || void 0 === f || null === (l = f[0]) || void 0 === l ? void 0 : l.greenCheckPass
                });

              case 19:
              case "end":
                return e.stop();
            }
        }, t, null, [ [ 4, 10 ] ]);
    }))).apply(this, arguments);
}

function l() {
    return (l = t(e().mark(function t() {
        var n, o, s;
        return e().wrap(function(e) {
            for (;;) switch (e.prev = e.next) {
              case 0:
                if (!(0, u.isSinglePageMode)()) {
                    e.next = 2;
                    break;
                }
                return e.abrupt("return", {});

              case 2:
                return e.next = 4, (0, a.default)({
                    url: "".concat(r.default.COMMON_API_HOST, "/account/profile/detail")
                });

              case 4:
                return s = e.sent, e.abrupt("return", null == s || null === (n = s.data) || void 0 === n || null === (o = n.items) || void 0 === o ? void 0 : o[0]);

              case 6:
              case "end":
                return e.stop();
            }
        }, t);
    }))).apply(this, arguments);
}

function d() {
    return (d = t(e().mark(function t(n) {
        var u, o;
        return e().wrap(function(e) {
            for (;;) switch (e.prev = e.next) {
              case 0:
                return u = "".concat(r.default.COMMON_API_HOST, "/account/profile"), e.next = 3, 
                (0, a.default)({
                    url: u,
                    method: "POST",
                    data: n
                });

              case 3:
                return o = e.sent, e.abrupt("return", o);

              case 5:
              case "end":
                return e.stop();
            }
        }, t);
    }))).apply(this, arguments);
}

function x() {
    return (x = t(e().mark(function t(n, u) {
        var o, s;
        return e().wrap(function(e) {
            for (;;) switch (e.prev = e.next) {
              case 0:
                return o = "".concat(r.default.API_HOST, "/profile"), e.next = 3, (0, a.default)({
                    url: o,
                    method: "POST",
                    data: {
                        encrypted_data: n,
                        iv: u
                    }
                });

              case 3:
                return s = e.sent, e.abrupt("return", s);

              case 5:
              case "end":
                return e.stop();
            }
        }, t);
    }))).apply(this, arguments);
}

function h() {
    return (h = t(e().mark(function t() {
        var n;
        return e().wrap(function(e) {
            for (;;) switch (e.prev = e.next) {
              case 0:
                if (!(0, u.isSinglePageMode)()) {
                    e.next = 2;
                    break;
                }
                return e.abrupt("return", {
                    daily: !1,
                    subscribOfficiaAccount: !1,
                    weekly: !1
                });

              case 2:
                return n = "".concat(r.default.API_HOST, "/subscribe"), e.abrupt("return", (0, a.default)({
                    url: n
                }));

              case 4:
              case "end":
                return e.stop();
            }
        }, t);
    }))).apply(this, arguments);
}

function b() {
    return (b = t(e().mark(function t(n) {
        var s, i, p;
        return e().wrap(function(e) {
            for (;;) switch (e.prev = e.next) {
              case 0:
                if (!(0, u.isSinglePageMode)()) {
                    e.next = 2;
                    break;
                }
                return e.abrupt("return", wx.showToast({
                    title: "请前往小程序使用完整服务",
                    icon: "none"
                }));

              case 2:
                return s = {
                    stype: n,
                    reminder_time: (0, c.default)().startOf("day").add(8, "hour").toISOString()
                }, i = "".concat(r.default.API_HOST, "/subscribe"), e.next = 6, (0, a.default)({
                    url: i,
                    method: "POST",
                    data: s
                });

              case 6:
                return p = e.sent, o.default.changeSubscribeState({
                    daily: !0
                }), e.abrupt("return", p);

              case 9:
              case "end":
                return e.stop();
            }
        }, t);
    }))).apply(this, arguments);
}

function w() {
    return (w = t(e().mark(function t(n) {
        var s, c;
        return e().wrap(function(e) {
            for (;;) switch (e.prev = e.next) {
              case 0:
                if (!(0, u.isSinglePageMode)()) {
                    e.next = 2;
                    break;
                }
                return e.abrupt("return", wx.showToast({
                    title: "请前往小程序使用完整服务",
                    icon: "none"
                }));

              case 2:
                return s = "".concat(r.default.API_HOST, "/subscribe"), e.next = 5, (0, a.default)({
                    url: s,
                    method: "DELETE",
                    data: {
                        stype: n
                    }
                });

              case 5:
                return c = e.sent, o.default.changeSubscribeState({
                    daily: !1
                }), e.abrupt("return", c);

              case 8:
              case "end":
                return e.stop();
            }
        }, t);
    }))).apply(this, arguments);
}

function v() {
    return (v = t(e().mark(function t(n, u) {
        var o;
        return e().wrap(function(e) {
            for (;;) switch (e.prev = e.next) {
              case 0:
                return o = "".concat(r.default.COMMON_API_HOST, "/mina_v2/daily/image_v2?ts=").concat(n), 
                u && (o += "&_force_=_force_"), e.abrupt("return", (0, a.default)({
                    url: o
                }));

              case 3:
              case "end":
                return e.stop();
            }
        }, t);
    }))).apply(this, arguments);
}

function y() {
    return (y = t(e().mark(function t() {
        var n;
        return e().wrap(function(e) {
            for (;;) switch (e.prev = e.next) {
              case 0:
                return e.prev = 0, e.next = 3, wx.getStorage({
                    key: r.default.SESSION_KEY
                });

              case 3:
                if ((n = e.sent).data && n.data.token && !(Date.now() - n.data.time > 216e5)) {
                    e.next = 7;
                    break;
                }
                return console.log("need login"), e.abrupt("return", !0);

              case 7:
                return e.next = 9, wx.checkSession();

              case 9:
                return console.log("need not login"), e.abrupt("return", !1);

              case 13:
                return e.prev = 13, e.t0 = e.catch(0), console.log("need login"), e.abrupt("return", !0);

              case 17:
              case "end":
                return e.stop();
            }
        }, t, null, [ [ 0, 13 ] ]);
    }))).apply(this, arguments);
}

function m() {
    return (m = t(e().mark(function t() {
        var r;
        return e().wrap(function(e) {
            for (;;) switch (e.prev = e.next) {
              case 0:
                if (wx.getUserProfile) {
                    e.next = 2;
                    break;
                }
                return e.abrupt("return", !1);

              case 2:
                return e.next = 4, new Promise(function(e) {
                    wx.getUserProfile({
                        lang: "zh_CN",
                        desc: "授权用户昵称、头像",
                        success: function(t) {
                            e(t.userInfo);
                        },
                        fail: function(t) {
                            console.log(t), e(null);
                        }
                    });
                });

              case 4:
                if (!(r = e.sent)) {
                    e.next = 8;
                    break;
                }
                return e.next = 8, getApp().updateUserInfo(r);

              case 8:
                return e.abrupt("return", !0);

              case 9:
              case "end":
                return e.stop();
            }
        }, t);
    }))).apply(this, arguments);
}

function g() {
    return (g = t(e().mark(function t(n) {
        var u, o, s;
        return e().wrap(function(e) {
            for (;;) switch (e.prev = e.next) {
              case 0:
                return e.next = 2, (0, a.default)({
                    url: "".concat(r.default.API_HOST, "/payment?source=").concat(n),
                    method: "GET"
                });

              case 2:
                return u = e.sent, (o = u.requestInfo).timeStamp = "" + o.timeStamp, e.next = 7, 
                wx.requestPayment(o);

              case 7:
                return s = e.sent, e.next = 10, new Promise(function(e) {
                    setTimeout(e, 1e3);
                });

              case 10:
                return e.abrupt("return", s);

              case 11:
              case "end":
                return e.stop();
            }
        }, t);
    }))).apply(this, arguments);
}

function S() {
    return (S = t(e().mark(function t(u) {
        var o, s, c, i;
        return e().wrap(function(e) {
            for (;;) switch (e.prev = e.next) {
              case 0:
                return o = getApp().globalData.userInfo, n.get(o, "isBeta") && (u.price = 1), e.next = 4, 
                (0, a.default)({
                    url: "".concat(r.default.COMMON_API_HOST, "/pay/readhub_pro_subscribe/wx"),
                    method: "POST",
                    data: u
                });

              case 4:
                return s = e.sent.data.items[0], (c = s.requestInfo).timeStamp = "" + c.timeStamp, 
                e.next = 9, wx.requestPayment(c);

              case 9:
                return i = e.sent, e.next = 12, new Promise(function(e) {
                    setTimeout(e, 1e3);
                });

              case 12:
                return e.abrupt("return", i);

              case 13:
              case "end":
                return e.stop();
            }
        }, t);
    }))).apply(this, arguments);
}

function P() {
    return (P = t(e().mark(function u(o) {
        var c, i, p;
        return e().wrap(function(u) {
            for (;;) switch (u.prev = u.next) {
              case 0:
                return c = {
                    type: o
                }, i = getApp().globalData.userInfo, n.get(i, "isBeta") && (c.price = 1), u.next = 5, 
                (0, a.default)({
                    url: "".concat(r.default.COMMON_API_HOST, "/pay_readhub/contract/wx"),
                    method: "POST",
                    data: c
                });

              case 5:
                return p = u.sent.data.items[0], u.next = 8, new Promise(function(r, n) {
                    console.log("payment", p);
                    var a, u = p.appId;
                    wx.navigateToMiniProgram({
                        appId: u,
                        path: p.path,
                        extraData: p.extraData,
                        success: (a = t(e().mark(function a() {
                            var u, o;
                            return e().wrap(function(a) {
                                for (;;) switch (a.prev = a.next) {
                                  case 0:
                                    o = function() {
                                        return (o = t(e().mark(function t(a) {
                                            var o, c, i, p;
                                            return e().wrap(function(e) {
                                                for (;;) switch (e.prev = e.next) {
                                                  case 0:
                                                    if (o = a.referrerInfo, c = o.appId, i = o.extraData, 1038 === a.scene) {
                                                        e.next = 3;
                                                        break;
                                                    }
                                                    return e.abrupt("return");

                                                  case 3:
                                                    if ("wxbd687630cd02ce1d" === c) {
                                                        e.next = 5;
                                                        break;
                                                    }
                                                    return e.abrupt("return");

                                                  case 5:
                                                    if (void 0 !== i) {
                                                        e.next = 21;
                                                        break;
                                                    }
                                                    return e.prev = 6, e.next = 9, (0, s.syncProContact)();

                                                  case 9:
                                                    p = e.sent.data.items[0], e.next = 15;
                                                    break;

                                                  case 12:
                                                    e.prev = 12, e.t0 = e.catch(6), console.error(e.t0);

                                                  case 15:
                                                    if (wx.offAppShow(u), !p || 2 !== p.state) {
                                                        e.next = 20;
                                                        break;
                                                    }
                                                    return e.abrupt("return", r(!0));

                                                  case 20:
                                                    return e.abrupt("return", n(new Error("签约失败")));

                                                  case 21:
                                                    if ("SUCCESS" != i.return_code) {
                                                        e.next = 26;
                                                        break;
                                                    }
                                                    return wx.offAppShow(u), e.abrupt("return", r(!0));

                                                  case 26:
                                                    return wx.offAppShow(u), e.abrupt("return", n(new Error("已取消")));

                                                  case 28:
                                                  case "end":
                                                    return e.stop();
                                                }
                                            }, t, null, [ [ 6, 12 ] ]);
                                        }))).apply(this, arguments);
                                    }, u = function(e) {
                                        return o.apply(this, arguments);
                                    }, wx.onAppShow(u);

                                  case 3:
                                  case "end":
                                    return a.stop();
                                }
                            }, a);
                        })), function() {
                            return a.apply(this, arguments);
                        }),
                        fail: function(e) {
                            n(e);
                        }
                    });
                });

              case 8:
              case "end":
                return u.stop();
            }
        }, u);
    }))).apply(this, arguments);
}