Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.createStokeFileMap = function(t) {
    return S.apply(this, arguments);
}, exports.fetchRelationStockFiles = function(t) {
    return g.apply(this, arguments);
}, exports.formatFinance = function() {
    var t = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {};
    return {
        id: t.uniqueId,
        company: t.company,
        finance: t.title,
        exchangeDisplay: t.exchange,
        date: t.publishDate,
        genYear: (0, u.default)(t.publishDate).get("year"),
        dateDisplay: (0, u.default)(t.publishDate).format("YYYY.MM.DD")
    };
}, exports.getFileSearchImage = function(t) {
    return k.apply(this, arguments);
}, exports.getFinanceRelation = function(t) {
    return h.apply(this, arguments);
}, exports.getRecommends = function() {
    return v.apply(this, arguments);
}, exports.getShareImage = function(t, e) {
    return O.apply(this, arguments);
}, exports.getStockFile = function(t) {
    return d.apply(this, arguments);
}, exports.getStockIndex = function() {
    return D.apply(this, arguments);
}, exports.getStockList = function() {
    return I.apply(this, arguments);
}, exports.getStockSearchList = function(t, e, n) {
    return F.apply(this, arguments);
}, exports.getStokeFileDownloadUrl = function(t) {
    return w.apply(this, arguments);
}, exports.getStokeFileMap = function(t) {
    return M.apply(this, arguments);
}, exports.processFileItem = f, exports.saveRecommends = function() {
    return x.apply(this, arguments);
}, exports.updateStokeFileMap = function(t, e) {
    return b.apply(this, arguments);
};

var t = require("../@babel/runtime/helpers/objectSpread2"), e = require("../@babel/runtime/helpers/regeneratorRuntime"), n = require("../@babel/runtime/helpers/asyncToGenerator"), r = p(require("../utils/request")), a = p(require("../config")), u = p(require("dayjs")), i = require("../utils/format"), o = require("../utils/date"), c = require("../utils/tools"), s = p(require("../libs/utc")), l = p(require("lodash"));

function p(t) {
    return t && t.__esModule ? t : {
        default: t
    };
}

function f(t) {
    t && t.fileNameDisplay && (t.fileNameDisplay = t.fileNameDisplay.replace(/[.。]pdf\s*$/gi, ""));
}

function d() {
    return (d = n(e().mark(function t(n) {
        return e().wrap(function(t) {
            for (;;) switch (t.prev = t.next) {
              case 0:
                return t.abrupt("return", (0, r.default)({
                    url: "".concat(a.default.COMMON_API_HOST, "/stock_file/detail?id=").concat(n)
                }).then(function(t) {
                    return f(t.data.items[0]), t;
                }));

              case 1:
              case "end":
                return t.stop();
            }
        }, t);
    }))).apply(this, arguments);
}

function m() {
    var t = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {};
    return {
        relatedEvent: l.default.map(t.topicInfoRelatedList, function(t) {
            return {
                id: t.uid,
                title: (0, i.newsTitleFormat)(t.title),
                date: (0, o.relativeDatetime)(t.publishDate)
            };
        }),
        latestTopic: l.default.map(t.topicInfoLatestList, function(t) {
            return {
                id: t.uid,
                title: (0, i.newsTitleFormat)(t.title),
                date: (0, o.relativeDatetime)(t.publishDate)
            };
        })
    };
}

function h() {
    return (h = n(e().mark(function t(n) {
        return e().wrap(function(t) {
            for (;;) switch (t.prev = t.next) {
              case 0:
                return t.abrupt("return", (0, r.default)({
                    url: "".concat(a.default.COMMON_API_HOST, "/stock_file/detail/related?id=").concat(n)
                }).then(function(t) {
                    return m(t.data.items[0]);
                }));

              case 1:
              case "end":
                return t.stop();
            }
        }, t);
    }))).apply(this, arguments);
}

function y(t) {
    return (0, u.default)(t).isSame((0, u.default)(), "year") ? (0, u.default)(t).format("M 月 DD 日") : (0, 
    u.default)(t).format("YYYY 年 M 月 DD 日");
}

function _() {
    var t = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : [];
    return t.map(function(t) {
        return {
            id: t.uniqueId,
            titleDisplay: t.titleDisplay,
            exchangeDisplay: t.exchangeDisplay,
            date: y(t.publishDate)
        };
    });
}

function g() {
    return (g = n(e().mark(function t(n) {
        return e().wrap(function(t) {
            for (;;) switch (t.prev = t.next) {
              case 0:
                return t.abrupt("return", (0, r.default)({
                    url: "".concat(a.default.COMMON_API_HOST, "/stock_file/detail/related/company_latest_list?entity_id=").concat(n)
                }).then(function(t) {
                    return _(t.data.items);
                }));

              case 1:
              case "end":
                return t.stop();
            }
        }, t);
    }))).apply(this, arguments);
}

function O() {
    return (O = n(e().mark(function t(n, u) {
        var i;
        return e().wrap(function(t) {
            for (;;) switch (t.prev = t.next) {
              case 0:
                return i = "".concat(a.default.COMMON_API_HOST, "/stock_file/detail/image?id=").concat(n), 
                u && (i += "&_force_=_force_"), t.abrupt("return", (0, r.default)({
                    url: i
                }));

              case 3:
              case "end":
                return t.stop();
            }
        }, t);
    }))).apply(this, arguments);
}

function k() {
    return (k = n(e().mark(function t(n) {
        var u, i, o, s, l, p, f, d, m = arguments;
        return e().wrap(function(t) {
            for (;;) switch (t.prev = t.next) {
              case 0:
                return u = m.length > 1 && void 0 !== m[1] && m[1], i = n.query, o = n.type, s = n.exchange, 
                l = n.date_range, p = n.agg, f = {}, i && (f.query = encodeURIComponent(i)), o && (f.type = o), 
                s && (f.exchange = s), 999 !== l && (f.date_range = l), u && (f._force_ = "_force_"), 
                f.agg = p, console.log("🚀 ~ file: stock.js ~ line 56 ~ getFileSearchImage ~ qs", f), 
                d = "".concat(a.default.COMMON_API_HOST, "/stock_file/search/image?").concat((0, 
                c.queryString)(f)), t.abrupt("return", (0, r.default)({
                    url: d
                }));

              case 12:
              case "end":
                return t.stop();
            }
        }, t);
    }))).apply(this, arguments);
}

function v() {
    return (v = n(e().mark(function t() {
        var n, u = arguments;
        return e().wrap(function(t) {
            for (;;) switch (t.prev = t.next) {
              case 0:
                return n = u.length > 0 && void 0 !== u[0] ? u[0] : 1, t.abrupt("return", (0, r.default)({
                    url: "".concat(a.default.COMMON_API_HOST, "/stock_file/search_key/recommend/list?type=").concat(n)
                }).then(function(t) {
                    return (t.data.items || []).forEach(function(t) {
                        t.displayDate = (0, i.stockDateDisplay)(t.publishDate), f(t);
                    }), t;
                }));

              case 2:
              case "end":
                return t.stop();
            }
        }, t);
    }))).apply(this, arguments);
}

function x() {
    return (x = n(e().mark(function t() {
        var n, u, i = arguments;
        return e().wrap(function(t) {
            for (;;) switch (t.prev = t.next) {
              case 0:
                return n = i.length > 0 && void 0 !== i[0] ? i[0] : [], u = i.length > 1 && void 0 !== i[1] ? i[1] : 1, 
                t.abrupt("return", (0, r.default)({
                    url: "".concat(a.default.COMMON_API_HOST, "/stock_file/search_key/recommend"),
                    method: "POST",
                    data: {
                        values: n,
                        type: u
                    }
                }));

              case 3:
              case "end":
                return t.stop();
            }
        }, t);
    }))).apply(this, arguments);
}

function M() {
    return (M = n(e().mark(function t(n) {
        return e().wrap(function(t) {
            for (;;) switch (t.prev = t.next) {
              case 0:
                return t.abrupt("return", (0, r.default)({
                    url: "".concat(a.default.COMMON_API_HOST, "/stock_file/mapping?stock_file_id=").concat(n)
                }));

              case 1:
              case "end":
                return t.stop();
            }
        }, t);
    }))).apply(this, arguments);
}

function S() {
    return (S = n(e().mark(function t(n) {
        return e().wrap(function(t) {
            for (;;) switch (t.prev = t.next) {
              case 0:
                return t.abrupt("return", (0, r.default)({
                    url: "".concat(a.default.COMMON_API_HOST, "/stock_file/mapping/create?stock_file_id=").concat(n),
                    method: "POST",
                    data: {
                        stock_file_id: n
                    }
                }));

              case 1:
              case "end":
                return t.stop();
            }
        }, t);
    }))).apply(this, arguments);
}

function b() {
    return (b = n(e().mark(function t(n, u) {
        return e().wrap(function(t) {
            for (;;) switch (t.prev = t.next) {
              case 0:
                return console.log(u), t.abrupt("return", (0, r.default)({
                    url: "".concat(a.default.COMMON_API_HOST, "/stock_file/mapping/patch?stock_file_id=").concat(n),
                    method: "POST",
                    data: u
                }));

              case 2:
              case "end":
                return t.stop();
            }
        }, t);
    }))).apply(this, arguments);
}

function w() {
    return (w = n(e().mark(function t(n) {
        return e().wrap(function(t) {
            for (;;) switch (t.prev = t.next) {
              case 0:
                return t.abrupt("return", (0, r.default)({
                    url: "".concat(a.default.COMMON_API_HOST, "/stock_file/url?id=").concat(n)
                }));

              case 1:
              case "end":
                return t.stop();
            }
        }, t);
    }))).apply(this, arguments);
}

function D() {
    return (D = n(e().mark(function n() {
        var u, o, c, s, p;
        return e().wrap(function(e) {
            for (;;) switch (e.prev = e.next) {
              case 0:
                return e.next = 2, (0, r.default)({
                    url: "".concat(a.default.COMMON_API_HOST, "/stock_file/mina/index")
                });

              case 2:
                return u = e.sent, o = u.data, c = o.entityList, s = o.financialList, p = o.ipoList, 
                e.abrupt("return", {
                    entityList: l.default.map(c, function(e) {
                        return t(t({}, e), {}, {
                            name: (0, i.commonFormat)(e.name)
                        });
                    }),
                    financialList: l.default.map(s, function(e) {
                        return t(t({}, e), {}, {
                            title: (0, i.commonFormat)(e.title),
                            company: (0, i.commonFormat)(e.company)
                        });
                    }),
                    ipoList: l.default.map(p, function(e) {
                        return t(t({}, e), {}, {
                            title: (0, i.commonFormat)(e.title),
                            company: (0, i.commonFormat)(e.company)
                        });
                    })
                });

              case 5:
              case "end":
                return e.stop();
            }
        }, n);
    }))).apply(this, arguments);
}

function I() {
    return (I = n(e().mark(function n() {
        var u, o, s, p, f = arguments;
        return e().wrap(function(e) {
            for (;;) switch (e.prev = e.next) {
              case 0:
                return u = f.length > 0 && void 0 !== f[0] ? f[0] : 3, o = f.length > 1 ? f[1] : void 0, 
                s = f.length > 2 && void 0 !== f[2] ? f[2] : 10, e.next = 5, (0, r.default)({
                    url: "".concat(a.default.COMMON_API_HOST, "/stock_file/list?").concat((0, c.queryString)({
                        max_id: o,
                        type: u,
                        size: s
                    }))
                });

              case 5:
                return p = e.sent, e.abrupt("return", {
                    items: l.default.map(p.data.items, function(e) {
                        return t(t({}, e), {}, {
                            title: (0, i.commonFormat)(e.title),
                            company: (0, i.commonFormat)(e.company)
                        });
                    })
                });

              case 7:
              case "end":
                return e.stop();
            }
        }, n);
    }))).apply(this, arguments);
}

function F() {
    return (F = n(e().mark(function n(u, o, s) {
        var p, f, d, m, h = arguments;
        return e().wrap(function(e) {
            for (;;) switch (e.prev = e.next) {
              case 0:
                return f = h.length > 3 && void 0 !== h[3] ? h[3] : 1, d = h.length > 4 && void 0 !== h[4] ? h[4] : 10, 
                e.next = 4, (0, r.default)({
                    url: "".concat(a.default.COMMON_API_HOST, "/search/stock?").concat((0, c.queryString)({
                        entity_id: s,
                        type: u,
                        query: o,
                        page: f,
                        size: d
                    }))
                });

              case 4:
                return m = e.sent, e.abrupt("return", {
                    subSuggest: null === (p = m.data.self) || void 0 === p ? void 0 : p.subSuggest,
                    items: l.default.map(m.data.items, function(e) {
                        return t(t({}, e), {}, {
                            title: (0, i.commonFormat)(e.title),
                            company: (0, i.commonFormat)(e.company)
                        });
                    })
                });

              case 6:
              case "end":
                return e.stop();
            }
        }, n);
    }))).apply(this, arguments);
}

u.default.extend(s.default);