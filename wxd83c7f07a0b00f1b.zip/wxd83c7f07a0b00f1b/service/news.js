Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.extractByUrl = function() {
    return s.apply(this, arguments);
}, exports.extractNewsShareImage = function(t) {
    return l.apply(this, arguments);
}, exports.fetchMinaCode = function(t) {
    return f.apply(this, arguments);
}, exports.fetchNewsDetail = function(t) {
    return h.apply(this, arguments);
}, exports.fetchNewsDetailLegacy = function(t) {
    return v.apply(this, arguments);
}, exports.fetchRelatedTopics = function(t) {
    return d.apply(this, arguments);
};

var t = require("../@babel/runtime/helpers/regeneratorRuntime"), e = require("../@babel/runtime/helpers/createForOfIteratorHelper"), r = require("../@babel/runtime/helpers/asyncToGenerator"), n = o(require("../utils/request")), a = o(require("../config")), u = require("../utils/tools"), i = require("../utils/format"), c = require("../utils/date");

function o(t) {
    return t && t.__esModule ? t : {
        default: t
    };
}

function s() {
    return (s = r(t().mark(function e() {
        var r, i = arguments;
        return t().wrap(function(t) {
            for (;;) switch (t.prev = t.next) {
              case 0:
                return r = i.length > 0 && void 0 !== i[0] ? i[0] : {}, t.abrupt("return", (0, n.default)({
                    url: "".concat(a.default.COMMON_API_HOST, "/news/extract/by_url?").concat((0, u.queryString)(r))
                }));

              case 2:
              case "end":
                return t.stop();
            }
        }, e);
    }))).apply(this, arguments);
}

function l() {
    return (l = r(t().mark(function e(r) {
        return t().wrap(function(t) {
            for (;;) switch (t.prev = t.next) {
              case 0:
                return t.abrupt("return", (0, n.default)({
                    url: "".concat(a.default.COMMON_API_HOST, "/news/extract/image?").concat((0, u.queryString)(r))
                }));

              case 1:
              case "end":
                return t.stop();
            }
        }, e);
    }))).apply(this, arguments);
}

function p(t) {
    var e, r;
    return (null == t || null === (e = t.data) || void 0 === e || null === (r = e.items) || void 0 === r ? void 0 : r.map(function(t) {
        return {
            id: null == t ? void 0 : t.uid,
            title: (0, i.ncFormat)(null == t ? void 0 : t.title),
            summary: (0, i.ncFormat)(null == t ? void 0 : t.summary),
            siteCount: null == t ? void 0 : t.siteCount,
            createAt: t.createdAt,
            publishDate: t.publishDate,
            relativeDatetime: (0, c.relativeDatetime)(t.publishDate)
        };
    })) || [];
}

function d() {
    return (d = r(t().mark(function e(r) {
        var i;
        return t().wrap(function(t) {
            for (;;) switch (t.prev = t.next) {
              case 0:
                return i = {
                    news_uid: r
                }, t.t0 = p, t.next = 4, (0, n.default)({
                    url: "".concat(a.default.COMMON_API_HOST, "/news/related_topic?").concat((0, u.queryString)(i))
                });

              case 4:
                return t.t1 = t.sent, t.abrupt("return", (0, t.t0)(t.t1));

              case 6:
              case "end":
                return t.stop();
            }
        }, e);
    }))).apply(this, arguments);
}

function f() {
    return (f = r(t().mark(function e(r) {
        var u, i, c, o;
        return t().wrap(function(t) {
            for (;;) switch (t.prev = t.next) {
              case 0:
                return t.next = 2, (0, n.default)({
                    url: "".concat(a.default.COMMON_API_HOST, "/news/detail/qrcode_min_program?uid=").concat(r)
                });

              case 2:
                return o = t.sent, t.abrupt("return", (null == o || null === (u = o.data) || void 0 === u || null === (i = u.items) || void 0 === i || null === (c = i[0]) || void 0 === c ? void 0 : c.url) || "");

              case 4:
              case "end":
                return t.stop();
            }
        }, e);
    }))).apply(this, arguments);
}

function h() {
    return (h = r(t().mark(function e(r) {
        var u, c, o, s, l;
        return t().wrap(function(t) {
            for (;;) switch (t.prev = t.next) {
              case 0:
                return t.next = 2, (0, n.default)({
                    url: "".concat(a.default.API_HOST, "/news/").concat(r, "/content")
                });

              case 2:
                return u = t.sent, c = u.data || {}, o = c.nelData || [], s = o.map(function(t) {
                    return {
                        text: t.nerName,
                        id: t.entityId
                    };
                }), l = m(l = (0, i.toHtml)(c.body), s), t.abrupt("return", {
                    id: r,
                    itemId: c.itemId,
                    title: (0, i.ncFormat)(c.title),
                    date: c.date,
                    meta: c.meta,
                    body: c.body,
                    tags: c.tags,
                    entitys: o,
                    html: l
                });

              case 9:
              case "end":
                return t.stop();
            }
        }, e);
    }))).apply(this, arguments);
}

function m(t) {
    var r = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : [];
    if (r.length) {
        var n, a = e(r);
        try {
            for (a.s(); !(n = a.n()).done; ) {
                var u = n.value;
                t = t.replace(u.text, '<a href="'.concat(u.id, '">').concat(u.text, "</a>"));
            }
        } catch (t) {
            a.e(t);
        } finally {
            a.f();
        }
    }
    return t;
}

function v() {
    return (v = r(t().mark(function e(r) {
        var n, a;
        return t().wrap(function(t) {
            for (;;) switch (t.prev = t.next) {
              case 0:
                return n = new wx.cloud.Cloud({
                    resourceAppid: "wx50d5f3f54db5e32d",
                    resourceEnv: "readhub-8gufm1r48be6c421"
                }), t.next = 3, n.init();

              case 3:
                return t.next = 5, n.callFunction({
                    name: "readhub_news",
                    data: {
                        id: r
                    }
                });

              case 5:
                return a = t.sent, t.abrupt("return", a.result);

              case 7:
              case "end":
                return t.stop();
            }
        }, e);
    }))).apply(this, arguments);
}