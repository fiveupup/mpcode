Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.createGiftCard = function(t) {
    return i.apply(this, arguments);
}, exports.fetchCardByOrder = function(t) {
    return l.apply(this, arguments);
}, exports.fetchCardByUid = function(t) {
    return d.apply(this, arguments);
}, exports.fetchCardList = function(t) {
    return c.apply(this, arguments);
}, exports.fetchYearCardPrice = function() {
    return v.apply(this, arguments);
}, exports.receiveCard = function(t) {
    return f.apply(this, arguments);
};

var t = require("../@babel/runtime/helpers/regeneratorRuntime"), e = require("../@babel/runtime/helpers/asyncToGenerator"), r = u(require("../utils/request")), n = u(require("../config")), a = u(require("lodash"));

function u(t) {
    return t && t.__esModule ? t : {
        default: t
    };
}

function i() {
    return (i = e(t().mark(function e(a) {
        var u, i, o, c, s, d, l, p, f;
        return t().wrap(function(t) {
            for (;;) switch (t.prev = t.next) {
              case 0:
                return t.next = 2, (0, r.default)({
                    url: "".concat(n.default.COMMON_API_HOST, "/pay_readhub/gift_card"),
                    method: "POST",
                    data: {
                        trade_type: 0,
                        count: a.count,
                        price: a.price,
                        type: "3004"
                    }
                });

              case 2:
                return p = t.sent, f = null == p || null === (u = p.data) || void 0 === u || null === (i = u.items) || void 0 === i || null === (o = i[0]) || void 0 === o ? void 0 : o.requestInfo, 
                t.next = 6, wx.requestPayment(f);

              case 6:
                return "requestPayment:ok" !== t.sent.errMsg && wx.showToast({
                    title: "支付失败",
                    icon: "none"
                }), t.next = 10, new Promise(function(t) {
                    setTimeout(t, 1e3);
                });

              case 10:
                return t.abrupt("return", null == p || null === (c = p.data) || void 0 === c || null === (s = c.items) || void 0 === s || null === (d = s[0]) || void 0 === d || null === (l = d.order) || void 0 === l ? void 0 : l.id);

              case 11:
              case "end":
                return t.stop();
            }
        }, e);
    }))).apply(this, arguments);
}

function o() {
    var t, e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {}, r = arguments.length > 1 ? arguments[1] : void 0;
    return {
        unusedCount: null === (t = e.self) || void 0 === t ? void 0 : t.underusedGiftCardCount,
        list: a.default.map(e.items, s),
        hasMore: e.totalPages > r
    };
}

function c() {
    return (c = e(t().mark(function e(a) {
        var u;
        return t().wrap(function(t) {
            for (;;) switch (t.prev = t.next) {
              case 0:
                return t.next = 2, (0, r.default)({
                    url: "".concat(n.default.COMMON_API_HOST, "/gift_card/list?page=").concat(a, "&size=20")
                });

              case 2:
                return u = t.sent, t.abrupt("return", o(u.data, a));

              case 4:
              case "end":
                return t.stop();
            }
        }, e);
    }))).apply(this, arguments);
}

function s() {
    var t, e, r = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {};
    return {
        id: r.uid,
        total: r.totalQuantity,
        remain: r.remainingQuantity,
        start: r.startTime,
        end: r.endTime,
        nickname: r.nickname,
        state: null === (t = r.giftCardRecipient) || void 0 === t ? void 0 : t.state,
        userId: null === (e = r.giftCardRecipient) || void 0 === e ? void 0 : e.userUid
    };
}

function d() {
    return (d = e(t().mark(function e(a) {
        var u, i, o;
        return t().wrap(function(t) {
            for (;;) switch (t.prev = t.next) {
              case 0:
                return t.next = 2, (0, r.default)({
                    url: "".concat(n.default.COMMON_API_HOST, "/gift_card/detail?uid=").concat(a)
                });

              case 2:
                return o = t.sent, t.abrupt("return", s(null == o || null === (u = o.data) || void 0 === u || null === (i = u.items) || void 0 === i ? void 0 : i[0]));

              case 4:
              case "end":
                return t.stop();
            }
        }, e);
    }))).apply(this, arguments);
}

function l() {
    return (l = e(t().mark(function e(a) {
        var u, i, o;
        return t().wrap(function(t) {
            for (;;) switch (t.prev = t.next) {
              case 0:
                return t.next = 2, (0, r.default)({
                    url: "".concat(n.default.COMMON_API_HOST, "/gift_card/detail?order_id=").concat(a)
                });

              case 2:
                return o = t.sent, t.abrupt("return", s(null == o || null === (u = o.data) || void 0 === u || null === (i = u.items) || void 0 === i ? void 0 : i[0]));

              case 4:
              case "end":
                return t.stop();
            }
        }, e);
    }))).apply(this, arguments);
}

function p() {
    var t = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {};
    return {
        id: t.giftCardUid,
        state: t.state
    };
}

function f() {
    return (f = e(t().mark(function e(a) {
        var u, i, o, c;
        return t().wrap(function(t) {
            for (;;) switch (t.prev = t.next) {
              case 0:
                return o = "".concat(n.default.COMMON_API_HOST, "/gift_card/receive"), t.next = 3, 
                (0, r.default)({
                    url: o,
                    method: "POST",
                    data: {
                        uid: a
                    }
                });

              case 3:
                if (!(c = t.sent).error) {
                    t.next = 6;
                    break;
                }
                throw new Error(c.error.message);

              case 6:
                return t.abrupt("return", p(null == c || null === (u = c.data) || void 0 === u || null === (i = u.items) || void 0 === i ? void 0 : i[0]));

              case 7:
              case "end":
                return t.stop();
            }
        }, e);
    }))).apply(this, arguments);
}

function v() {
    return (v = e(t().mark(function e() {
        var a, u, i, o;
        return t().wrap(function(t) {
            for (;;) switch (t.prev = t.next) {
              case 0:
                return t.next = 2, (0, r.default)({
                    url: "".concat(n.default.COMMON_API_HOST, "/pay_readhub/payment/product_config?type=3004")
                });

              case 2:
                return o = t.sent, t.abrupt("return", null == o || null === (a = o.data) || void 0 === a || null === (u = a.items) || void 0 === u || null === (i = u[0]) || void 0 === i ? void 0 : i.price);

              case 4:
              case "end":
                return t.stop();
            }
        }, e);
    }))).apply(this, arguments);
}