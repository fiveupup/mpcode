Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.getFreeVipInfo = function() {
    return i.apply(this, arguments);
}, exports.joinFreeVip = function() {
    return o.apply(this, arguments);
};

var e = require("../@babel/runtime/helpers/regeneratorRuntime"), r = require("../@babel/runtime/helpers/asyncToGenerator"), t = u(require("../config")), n = u(require("../utils/request"));

function u(e) {
    return e && e.__esModule ? e : {
        default: e
    };
}

function o() {
    return (o = r(e().mark(function r() {
        var u, o;
        return e().wrap(function(e) {
            for (;;) switch (e.prev = e.next) {
              case 0:
                return u = "".concat(t.default.COMMON_API_HOST, "/promotion/free_vip/join"), e.next = 3, 
                (0, n.default)({
                    url: u,
                    method: "POST"
                });

              case 3:
                return o = e.sent, e.abrupt("return", o);

              case 5:
              case "end":
                return e.stop();
            }
        }, r);
    }))).apply(this, arguments);
}

function i() {
    return (i = r(e().mark(function r() {
        var u, o;
        return e().wrap(function(e) {
            for (;;) switch (e.prev = e.next) {
              case 0:
                return u = "".concat(t.default.COMMON_API_HOST, "/promotion/free_vip/info"), e.next = 3, 
                (0, n.default)({
                    url: u
                });

              case 3:
                return o = e.sent, e.abrupt("return", o);

              case 5:
              case "end":
                return e.stop();
            }
        }, r);
    }))).apply(this, arguments);
}