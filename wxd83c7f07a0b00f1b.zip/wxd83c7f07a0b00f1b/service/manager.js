Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.cancelVip = function() {
    return s.apply(this, arguments);
}, exports.getFeedbackMessages = function(e) {
    return o.apply(this, arguments);
}, exports.replyFeedbackMessage = function(e) {
    return c.apply(this, arguments);
};

var e, r = require("../@babel/runtime/helpers/regeneratorRuntime"), t = require("../@babel/runtime/helpers/asyncToGenerator"), n = function(e, r) {
    if (!r && e && e.__esModule) return e;
    if (null === e || "object" != typeof e && "function" != typeof e) return {
        default: e
    };
    var t = a(r);
    if (t && t.has(e)) return t.get(e);
    var n = {}, u = Object.defineProperty && Object.getOwnPropertyDescriptor;
    for (var s in e) if ("default" !== s && Object.prototype.hasOwnProperty.call(e, s)) {
        var o = u ? Object.getOwnPropertyDescriptor(e, s) : null;
        o && (o.get || o.set) ? Object.defineProperty(n, s, o) : n[s] = e[s];
    }
    n.default = e, t && t.set(e, n);
    return n;
}(require("../utils/request")), u = (e = require("../config")) && e.__esModule ? e : {
    default: e
};

function a(e) {
    if ("function" != typeof WeakMap) return null;
    var r = new WeakMap(), t = new WeakMap();
    return (a = function(e) {
        return e ? t : r;
    })(e);
}

function s() {
    return (s = t(r().mark(function e() {
        return r().wrap(function(e) {
            for (;;) switch (e.prev = e.next) {
              case 0:
                return e.abrupt("return", (0, n.default)({
                    url: "".concat(u.default.COMMON_API_HOST, "/account/reset/vip"),
                    method: "POST"
                }));

              case 1:
              case "end":
                return e.stop();
            }
        }, e);
    }))).apply(this, arguments);
}

function o() {
    return (o = t(r().mark(function e(t) {
        return r().wrap(function(e) {
            for (;;) switch (e.prev = e.next) {
              case 0:
                return e.abrupt("return", (0, n.cloudRequest)("admin_feedback", {
                    method: "get_user_messages",
                    query: {
                        cursor: t
                    }
                }));

              case 1:
              case "end":
                return e.stop();
            }
        }, e);
    }))).apply(this, arguments);
}

function c() {
    return (c = t(r().mark(function e(t) {
        return r().wrap(function(e) {
            for (;;) switch (e.prev = e.next) {
              case 0:
                return e.abrupt("return", (0, n.cloudRequest)("admin_feedback", {
                    method: "reply_user_messages",
                    message: t
                }));

              case 1:
              case "end":
                return e.stop();
            }
        }, e);
    }))).apply(this, arguments);
}