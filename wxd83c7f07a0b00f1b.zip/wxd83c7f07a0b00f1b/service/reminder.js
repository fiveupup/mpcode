Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.createReminder = function(r) {
    return (0, e.default)({
        url: "".concat(t.default.COMMON_API_HOST, "/reminder_plan/create"),
        method: "POST",
        data: r
    });
}, exports.getReminderConfig = function() {
    return (0, e.default)({
        url: "".concat(t.default.COMMON_API_HOST, "/reminder_plan/config/detail?type=3")
    });
}, exports.getReminderList = function(n) {
    return (0, e.default)({
        url: "".concat(t.default.COMMON_API_HOST, "/reminder_plan/list?").concat((0, r.queryString)(n))
    });
}, exports.updateReminder = function(r) {
    return (0, e.default)({
        url: "".concat(t.default.COMMON_API_HOST, "/reminder_plan/config"),
        method: "POST",
        data: {
            type: 3,
            reminder_time: (0, n.default)().startOf("day").add(8, "hour").toISOString(),
            plan_mode: r
        }
    });
};

var e = u(require("../utils/request")), t = u(require("../config")), r = require("../utils/tools"), n = u(require("dayjs"));

function u(e) {
    return e && e.__esModule ? e : {
        default: e
    };
}