Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.exchangeCode = function(e) {
    return l.apply(this, arguments);
}, exports.getDetail = function(e) {
    return c.apply(this, arguments);
};

var e = require("../@babel/runtime/helpers/regeneratorRuntime"), t = require("../@babel/runtime/helpers/asyncToGenerator"), r = a(require("../config")), n = a(require("../utils/request")), u = require("@mina-modules/mina-sentry");

function a(e) {
    return e && e.__esModule ? e : {
        default: e
    };
}

function i(e) {
    var t, r;
    return {
        startTime: e.startTime,
        endTime: e.endTime,
        state: null == e || null === (t = e.giftCardRecipient) || void 0 === t ? void 0 : t.state,
        userId: null == e || null === (r = e.giftCardRecipient) || void 0 === r ? void 0 : r.userUid
    };
}

function c() {
    return (c = t(e().mark(function t(a) {
        var c, o, l, s;
        return e().wrap(function(e) {
            for (;;) switch (e.prev = e.next) {
              case 0:
                return e.prev = 0, l = "".concat(r.default.COMMON_API_HOST, "/gift_card/detail?code=").concat(a), 
                e.next = 4, (0, n.default)({
                    url: l
                });

              case 4:
                return s = e.sent, e.abrupt("return", i((null == s || null === (c = s.data) || void 0 === c || null === (o = c.items) || void 0 === o ? void 0 : o[0]) || {}));

              case 8:
                throw e.prev = 8, e.t0 = e.catch(0), (0, u.error)("exchange service getDetail", e.t0), 
                e.t0;

              case 12:
              case "end":
                return e.stop();
            }
        }, t, null, [ [ 0, 8 ] ]);
    }))).apply(this, arguments);
}

function o(e) {
    return {
        state: e.state
    };
}

function l() {
    return (l = t(e().mark(function t(a) {
        var i, c, l, s;
        return e().wrap(function(e) {
            for (;;) switch (e.prev = e.next) {
              case 0:
                return e.prev = 0, l = "".concat(r.default.COMMON_API_HOST, "/gift_card/receive"), 
                e.next = 4, (0, n.default)({
                    url: l,
                    method: "POST",
                    data: {
                        code: a
                    }
                });

              case 4:
                return s = e.sent, e.abrupt("return", o((null == s || null === (i = s.data) || void 0 === i || null === (c = i.items) || void 0 === c ? void 0 : c[0]) || {}));

              case 8:
                throw e.prev = 8, e.t0 = e.catch(0), (0, u.error)("exchange service exchangeCode", e.t0), 
                e.t0;

              case 12:
              case "end":
                return e.stop();
            }
        }, t, null, [ [ 0, 8 ] ]);
    }))).apply(this, arguments);
}