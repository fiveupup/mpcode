Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.entitySuggest = function(e) {
    return s.apply(this, arguments);
}, exports.getSearchParams = function(e) {
    return f.apply(this, arguments);
}, exports.getSearchShareCard = function(e, t) {
    return p.apply(this, arguments);
}, exports.getSearchShareTimeline = function(e, t) {
    return l.apply(this, arguments);
}, exports.searchCompanyStockFile = function(e) {
    var t = e.page, n = void 0 === t ? 1 : t, i = e.size, o = void 0 === i ? 20 : i, s = e.query, p = e.type, l = e.exchange, f = e.date_range, d = e.agg, h = {
        page: n,
        size: o
    };
    s && (h.query = encodeURIComponent(s));
    p && (h.type = p);
    l && (h.exchange = l);
    999 !== f && (h.date_range = f);
    h.agg = d ? 1 : 0;
    var m = "https://search.readhub.cn/api/company/stock_file?".concat((0, a.queryString)(h));
    return (0, r.default)({
        url: m
    }).then(function(e) {
        return e.data.items.forEach(function(e) {
            (0, c.processFileItem)((0, u.get)(e, "newsList[0]"));
        }), e;
    });
}, exports.searchNews = function(e) {
    var t = e.page, a = void 0 === t ? 1 : t, u = e.size, c = void 0 === u ? 20 : u, o = e.keyword, s = e.entity_id, p = void 0 === s ? "" : s, l = "".concat(i.default.COMMON_API_HOST, "/search/topic?page=").concat(a, "&size=").concat(c, "&query=").concat(encodeURIComponent(o), "&entity_id=").concat(p);
    return (0, r.default)({
        url: l
    }).then(function(e) {
        return e.data.items = e.data.items.map(function(e) {
            var t;
            return (t = {
                displayCreatedAt: (0, n.searchAbsoluteDatetime)(e.publishDate),
                id: e.uid,
                relate: e.siteCount > 1 ? "".concat(e.siteNameDisplay, " 等 ").concat(e.siteCount, " 家媒体") : e.siteNameDisplay,
                summary: (0, n.newsTitleFormat)(e.summary),
                title: (0, n.newsTitleFormat)(e.title)
            }).needIndent = "「" === t.title[0], t;
        }), e;
    });
}, exports.submitFeedback = function(e, t) {
    return d.apply(this, arguments);
};

var e = require("../@babel/runtime/helpers/regeneratorRuntime"), t = require("../@babel/runtime/helpers/asyncToGenerator"), r = o(require("../utils/request")), n = require("../utils/format"), a = require("../utils/tools"), u = require("../utils/lodash"), c = require("./stock"), i = o(require("../config"));

function o(e) {
    return e && e.__esModule ? e : {
        default: e
    };
}

function s() {
    return (s = t(e().mark(function t(a) {
        return e().wrap(function(e) {
            for (;;) switch (e.prev = e.next) {
              case 0:
                return e.abrupt("return", (0, r.default)({
                    url: "".concat(i.default.COMMON_API_HOST, "/tmt_entity/suggest?q=").concat(a)
                }).then(function(e) {
                    return (0, u.get)(e, "data", []).forEach(function(e) {
                        e.text = e.entityName, e.entityName = (0, n.newsTitleFormat)(e.entityName);
                    }), e;
                }));

              case 1:
              case "end":
                return e.stop();
            }
        }, t);
    }))).apply(this, arguments);
}

function p() {
    return (p = t(e().mark(function t(n, a) {
        var u;
        return e().wrap(function(e) {
            for (;;) switch (e.prev = e.next) {
              case 0:
                return u = "".concat(i.default.COMMON_API_HOST, "/search/image_brief?query=").concat(n), 
                a && (u += "&_force_=_force_"), e.next = 4, (0, r.default)({
                    url: u
                });

              case 4:
                return e.abrupt("return", e.sent);

              case 5:
              case "end":
                return e.stop();
            }
        }, t);
    }))).apply(this, arguments);
}

function l() {
    return (l = t(e().mark(function t(n, a) {
        var u;
        return e().wrap(function(e) {
            for (;;) switch (e.prev = e.next) {
              case 0:
                return u = "".concat(i.default.COMMON_API_HOST, "/search/image?type=all&query=").concat(n), 
                a && (u += "&_force_=_force_"), e.next = 4, (0, r.default)({
                    url: u
                });

              case 4:
                return e.abrupt("return", e.sent);

              case 5:
              case "end":
                return e.stop();
            }
        }, t);
    }))).apply(this, arguments);
}

function f() {
    return (f = t(e().mark(function t(n) {
        return e().wrap(function(e) {
            for (;;) switch (e.prev = e.next) {
              case 0:
                return e.abrupt("return", (0, r.default)({
                    url: "".concat(i.default.COMMON_API_HOST, "/parameter_compression/detail?uid=").concat(n)
                }));

              case 1:
              case "end":
                return e.stop();
            }
        }, t);
    }))).apply(this, arguments);
}

function d() {
    return (d = t(e().mark(function t(n, a) {
        return e().wrap(function(e) {
            for (;;) switch (e.prev = e.next) {
              case 0:
                return e.abrupt("return", (0, r.default)({
                    url: "".concat(i.default.COMMON_API_HOST, "/feedback/create"),
                    method: "POST",
                    data: {
                        content: n,
                        type: a
                    }
                }));

              case 1:
              case "end":
                return e.stop();
            }
        }, t);
    }))).apply(this, arguments);
}