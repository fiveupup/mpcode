Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.getLinkMeta = function(e) {
    return a.apply(this, arguments);
};

var e = require("../@babel/runtime/helpers/regeneratorRuntime"), r = require("../@babel/runtime/helpers/asyncToGenerator"), t = u(require("../config")), n = u(require("../utils/request"));

function u(e) {
    return e && e.__esModule ? e : {
        default: e
    };
}

function a() {
    return (a = r(e().mark(function r(u) {
        var a, i;
        return e().wrap(function(e) {
            for (;;) switch (e.prev = e.next) {
              case 0:
                return a = "".concat(t.default.NOCODE_API_HOST, "/link_meta?url=").concat(u), e.next = 3, 
                (0, n.default)({
                    url: a
                });

              case 3:
                return i = e.sent, e.abrupt("return", i);

              case 5:
              case "end":
                return e.stop();
            }
        }, r);
    }))).apply(this, arguments);
}