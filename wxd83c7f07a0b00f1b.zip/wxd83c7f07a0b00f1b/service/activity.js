Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.create = function(e) {
    return c.apply(this, arguments);
}, exports.getActivityShareImage = function(e, t) {
    return s.apply(this, arguments);
}, exports.update = function(e, t) {
    return o.apply(this, arguments);
}, exports.uploadFile = function(e, t) {
    return i.apply(this, arguments);
};

var e = require("../@babel/runtime/helpers/objectSpread2"), t = require("../@babel/runtime/helpers/regeneratorRuntime"), r = require("../@babel/runtime/helpers/asyncToGenerator"), n = u(require("../utils/request")), a = u(require("../config"));

function u(e) {
    return e && e.__esModule ? e : {
        default: e
    };
}

function c() {
    return (c = r(t().mark(function e(r) {
        return t().wrap(function(e) {
            for (;;) switch (e.prev = e.next) {
              case 0:
                return e.abrupt("return", (0, n.default)({
                    url: "".concat(a.default.COMMON_API_HOST, "/operation_event/create"),
                    method: "POST",
                    data: r
                }));

              case 1:
              case "end":
                return e.stop();
            }
        }, e);
    }))).apply(this, arguments);
}

function o() {
    return (o = r(t().mark(function r(u, c) {
        var o;
        return t().wrap(function(t) {
            for (;;) switch (t.prev = t.next) {
              case 0:
                return o = e(e({}, c), {}, {
                    uid: u
                }), t.abrupt("return", (0, n.default)({
                    url: "".concat(a.default.COMMON_API_HOST, "/operation_event/patch"),
                    method: "POST",
                    data: o
                }));

              case 2:
              case "end":
                return t.stop();
            }
        }, r);
    }))).apply(this, arguments);
}

function i() {
    return (i = r(t().mark(function e(r, u) {
        var c, o, i, s;
        return t().wrap(function(e) {
            for (;;) switch (e.prev = e.next) {
              case 0:
                return e.next = 2, (0, n.default)({
                    url: "".concat(a.default.COMMON_API_HOST, "/readhub_resource/pre_upload/operation_event"),
                    header: {
                        "x-oss-object-acl": "public-read"
                    },
                    method: "POST",
                    data: {
                        ext: u
                    }
                });

              case 2:
                return c = e.sent.data.items[0], o = {}, e.prev = 4, e.next = 7, wx.getStorage({
                    key: a.default.USER_KEY
                });

              case 7:
                o = e.sent.data, e.next = 12;
                break;

              case 10:
                e.prev = 10, e.t0 = e.catch(4);

              case 12:
                return i = "", o.token && (i = "Bearer ".concat(o.token)), e.next = 16, new Promise(function(e, t) {
                    wx.uploadFile({
                        url: c.url,
                        filePath: r,
                        header: {
                            "x-oss-object-acl": "public-read",
                            Authorization: i
                        },
                        name: "file",
                        formData: c.params,
                        success: function(t) {
                            e(t.data);
                        },
                        fail: function(e) {
                            t(e);
                        }
                    });
                });

              case 16:
                return "string" == typeof (s = e.sent) && (s = JSON.parse(s)), e.abrupt("return", s.data.items[0].url);

              case 19:
              case "end":
                return e.stop();
            }
        }, e, null, [ [ 4, 10 ] ]);
    }))).apply(this, arguments);
}

function s() {
    return (s = r(t().mark(function e(r, u) {
        var c;
        return t().wrap(function(e) {
            for (;;) switch (e.prev = e.next) {
              case 0:
                return c = "".concat(a.default.COMMON_API_HOST, "/operation_event/detail/image?id=").concat(r), 
                u && (c += "&_force_=_force_"), e.next = 4, (0, n.default)({
                    url: c
                });

              case 4:
                return e.abrupt("return", e.sent);

              case 5:
              case "end":
                return e.stop();
            }
        }, e);
    }))).apply(this, arguments);
}