Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.getRewardList = function() {
    return a.apply(this, arguments);
};

var e = require("../@babel/runtime/helpers/regeneratorRuntime"), r = require("../@babel/runtime/helpers/asyncToGenerator"), t = u(require("../utils/request")), n = u(require("../config"));

function u(e) {
    return e && e.__esModule ? e : {
        default: e
    };
}

function a() {
    return (a = r(e().mark(function r() {
        var u, a, i = arguments;
        return e().wrap(function(e) {
            for (;;) switch (e.prev = e.next) {
              case 0:
                return u = i.length > 0 && void 0 !== i[0] ? i[0] : 1, a = i.length > 1 && void 0 !== i[1] ? i[1] : 14, 
                e.abrupt("return", (0, t.default)({
                    url: "".concat(n.default.COMMON_API_HOST, "/reward/list?page=").concat(u, "&size=").concat(a)
                }));

              case 3:
              case "end":
                return e.stop();
            }
        }, r);
    }))).apply(this, arguments);
}