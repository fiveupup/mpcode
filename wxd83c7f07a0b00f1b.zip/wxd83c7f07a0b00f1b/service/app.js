Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.browserCodeBind = function(e) {
    return a.apply(this, arguments);
}, exports.codeLogin = function(e) {
    return o.apply(this, arguments);
}, exports.needLogin = function() {
    return c.apply(this, arguments);
}, exports.payReward = function(e) {
    return s.apply(this, arguments);
};

var e = require("../@babel/runtime/helpers/regeneratorRuntime"), r = require("../@babel/runtime/helpers/asyncToGenerator"), t = u(require("../config")), n = u(require("../utils/request"));

function u(e) {
    return e && e.__esModule ? e : {
        default: e
    };
}

function a() {
    return (a = r(e().mark(function r(u) {
        return e().wrap(function(e) {
            for (;;) switch (e.prev = e.next) {
              case 0:
                return e.next = 2, (0, n.default)({
                    url: "".concat(t.default.COMMON_API_HOST, "/account/browser_code_bind"),
                    method: "POST",
                    data: {
                        code: u
                    }
                });

              case 2:
                return e.abrupt("return", e.sent);

              case 3:
              case "end":
                return e.stop();
            }
        }, r);
    }))).apply(this, arguments);
}

function o() {
    return (o = r(e().mark(function r(u) {
        var a, o;
        return e().wrap(function(e) {
            for (;;) switch (e.prev = e.next) {
              case 0:
                return a = "".concat(t.default.COMMON_API_HOST, "/account/login_wx_mini"), e.next = 3, 
                (0, n.default)({
                    url: a,
                    method: "POST",
                    data: {
                        code: u
                    }
                });

              case 3:
                return o = e.sent, e.abrupt("return", o);

              case 5:
              case "end":
                return e.stop();
            }
        }, r);
    }))).apply(this, arguments);
}

function c() {
    return (c = r(e().mark(function r() {
        var n;
        return e().wrap(function(e) {
            for (;;) switch (e.prev = e.next) {
              case 0:
                return e.prev = 0, e.next = 3, wx.getStorage({
                    key: t.default.USER_KEY
                });

              case 3:
                if ((n = e.sent.data) && (n.nonce || n.token)) {
                    e.next = 7;
                    break;
                }
                return console.log("need login"), e.abrupt("return", !0);

              case 7:
                return e.next = 9, wx.checkSession();

              case 9:
                return console.log("need not login"), e.abrupt("return", !1);

              case 13:
                return e.prev = 13, e.t0 = e.catch(0), console.log("need login"), e.abrupt("return", !0);

              case 17:
              case "end":
                return e.stop();
            }
        }, r, null, [ [ 0, 13 ] ]);
    }))).apply(this, arguments);
}

function s() {
    return (s = r(e().mark(function r(u) {
        var a, o;
        return e().wrap(function(e) {
            for (;;) switch (e.prev = e.next) {
              case 0:
                return a = "".concat(t.default.COMMON_API_HOST, "/pay/reward/wx"), e.next = 3, (0, 
                n.default)({
                    url: a,
                    method: "POST",
                    data: u
                });

              case 3:
                return o = e.sent, e.abrupt("return", o);

              case 5:
              case "end":
                return e.stop();
            }
        }, r);
    }))).apply(this, arguments);
}