Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.getEntityFinance = function(e, t) {
    return c.apply(this, arguments);
}, exports.getEntityNotice = function(e, t) {
    return s.apply(this, arguments);
}, exports.getEntityTopics = function(e, r) {
    var a = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : 1, o = arguments.length > 3 && void 0 !== arguments[3] ? arguments[3] : 10, c = function() {
        var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {};
        return (0, n.default)({
            url: "".concat(i.default.COMMON_API_HOST, "/topic/list_pro?").concat((0, u.queryString)(t({
                page: a,
                size: o
            }, e)))
        });
    };
    if ("10" === e) return c({
        entity_id: r
    });
    if ("22" === e) return c({
        tag_id: r
    });
    throw new Error("invalid type");
}, exports.getRecentRecommendEntities = function() {
    return o.apply(this, arguments);
};

var e = require("../@babel/runtime/helpers/regeneratorRuntime"), t = require("../@babel/runtime/helpers/objectSpread2"), r = require("../@babel/runtime/helpers/asyncToGenerator"), n = a(require("../utils/request")), i = a(require("../config")), u = require("../utils/tools");

function a(e) {
    return e && e.__esModule ? e : {
        default: e
    };
}

function o() {
    return (o = r(e().mark(function t() {
        return e().wrap(function(e) {
            for (;;) switch (e.prev = e.next) {
              case 0:
                return e.abrupt("return", (0, n.default)({
                    url: "".concat(i.default.COMMON_API_HOST, "/entity_recommend/config")
                }));

              case 1:
              case "end":
                return e.stop();
            }
        }, t);
    }))).apply(this, arguments);
}

function c() {
    return (c = r(e().mark(function t(r, a) {
        var o, c, s = arguments;
        return e().wrap(function(e) {
            for (;;) switch (e.prev = e.next) {
              case 0:
                return o = s.length > 2 && void 0 !== s[2] ? s[2] : 20, c = "".concat(i.default.COMMON_API_HOST, "/stock_file/company_latest_list?").concat((0, 
                u.queryString)({
                    entity_id: r,
                    type: 1,
                    page: a,
                    size: o
                })), e.abrupt("return", (0, n.default)({
                    url: c
                }));

              case 3:
              case "end":
                return e.stop();
            }
        }, t);
    }))).apply(this, arguments);
}

function s() {
    return (s = r(e().mark(function t(r, a) {
        var o, c, s = arguments;
        return e().wrap(function(e) {
            for (;;) switch (e.prev = e.next) {
              case 0:
                return o = s.length > 2 && void 0 !== s[2] ? s[2] : 20, c = "".concat(i.default.COMMON_API_HOST, "/stock_file/company_latest_list?").concat((0, 
                u.queryString)({
                    entity_id: r,
                    type: 3,
                    page: a,
                    size: o
                })), e.abrupt("return", (0, n.default)({
                    url: c
                }));

              case 3:
              case "end":
                return e.stop();
            }
        }, t);
    }))).apply(this, arguments);
}