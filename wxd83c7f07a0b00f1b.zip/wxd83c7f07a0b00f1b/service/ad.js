Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.default = void 0, exports.getCDNAds = d;

var e, t = require("../@babel/runtime/helpers/createForOfIteratorHelper"), r = require("../@babel/runtime/helpers/objectSpread2"), n = require("../@babel/runtime/helpers/regeneratorRuntime"), a = require("../@babel/runtime/helpers/asyncToGenerator"), s = (e = require("../config")) && e.__esModule ? e : {
    default: e
}, o = l(require("../utils/request")), i = l(require("../utils/lodash"));

function u(e) {
    if ("function" != typeof WeakMap) return null;
    var t = new WeakMap(), r = new WeakMap();
    return (u = function(e) {
        return e ? r : t;
    })(e);
}

function l(e, t) {
    if (!t && e && e.__esModule) return e;
    if (null === e || "object" != typeof e && "function" != typeof e) return {
        default: e
    };
    var r = u(t);
    if (r && r.has(e)) return r.get(e);
    var n = {}, a = Object.defineProperty && Object.getOwnPropertyDescriptor;
    for (var s in e) if ("default" !== s && Object.prototype.hasOwnProperty.call(e, s)) {
        var o = a ? Object.getOwnPropertyDescriptor(e, s) : null;
        o && (o.get || o.set) ? Object.defineProperty(n, s, o) : n[s] = e[s];
    }
    return n.default = e, r && r.set(e, n), n;
}

var c = [];

function d() {
    return f.apply(this, arguments);
}

function f() {
    return (f = a(n().mark(function e() {
        return n().wrap(function(e) {
            for (;;) switch (e.prev = e.next) {
              case 0:
                return e.prev = 0, e.abrupt("return", (0, o.cloudRequest)("sponsor").then(function(e) {
                    return console.log("fetch ads success", e), e.map(function(e, t) {
                        return e.id = t + 1, e.name = e.Name, e.slogan = e.mina_desc.split("\n"), e;
                    });
                }));

              case 4:
                return e.prev = 4, e.t0 = e.catch(0), console.error(e.t0), e.abrupt("return", []);

              case 8:
              case "end":
                return e.stop();
            }
        }, e, null, [ [ 0, 4 ] ]);
    }))).apply(this, arguments);
}

var p, h, g = {
    getShareImage: (h = a(n().mark(function e(t, r) {
        var a;
        return n().wrap(function(e) {
            for (;;) switch (e.prev = e.next) {
              case 0:
                return a = "".concat(s.default.COMMON_API_HOST, "/ads/image"), r && (a += "?_force_=_force_"), 
                e.next = 4, (0, o.default)({
                    url: a,
                    method: "POST",
                    data: {
                        title: decodeURIComponent(t.title),
                        desc: decodeURIComponent(t.desc),
                        link: decodeURIComponent(t.link)
                    }
                });

              case 4:
                return e.abrupt("return", e.sent.data.items[0].url);

              case 5:
              case "end":
                return e.stop();
            }
        }, e);
    })), function(e, t) {
        return h.apply(this, arguments);
    }),
    getAds: (p = a(n().mark(function e(t) {
        var r;
        return n().wrap(function(e) {
            for (;;) switch (e.prev = e.next) {
              case 0:
                return e.next = 2, d();

              case 2:
                r = e.sent, this._ads = r, this.ads = r.filter(function(e) {
                    return e.visiable;
                }), this._ready = !0, this.mobileAds = r.filter(function(e) {
                    return e.slogan && e.slogan.length > 0 && e.visiable;
                }), this.indexs = t || i.shuffle(i.range(this.mobileAds.length)), this.genAd = this.generate();

              case 9:
              case "end":
                return e.stop();
            }
        }, e, this);
    })), function(e) {
        return p.apply(this, arguments);
    }),
    refreshAd: function() {
        this.mobileAds && (this.indexs = i.shuffle(i.range(this.mobileAds.length)), this.genAd = this.generate());
    },
    ads: [],
    indexs: [],
    _ready: !1,
    isReady: function() {
        return this._ready;
    },
    randomValue: Math.random(),
    generate: function() {
        var e = this, t = this.mobileAds, n = [].concat(this.indexs);
        return function() {
            var a = n.shift();
            if (!isNaN(a) && a >= 0) {
                -1 === c.indexOf(a) && c.push(a);
                var s = t[a];
                if (s && s.slogan && s.slogan.length) {
                    var o = Math.floor(e.randomValue * s.slogan.length), u = i.get(s, "slogan[".concat(o, "].text"), s.slogan[o]), l = i.get(s, "slogan[".concat(o, "].url"), s.url);
                    return r(r({}, s), {}, {
                        url: l,
                        desc: u,
                        sindex: o,
                        sponsorName: s.name
                    });
                }
                var d = Math.floor(e.randomValue * s.slogan.length);
                return r(r({}, s), {}, {
                    desc: s.slogan[d],
                    sindex: d,
                    sponsorName: s.name
                });
            }
            return null;
        };
    },
    getAll: function() {
        var e, n, a = [], s = t(this.ads);
        try {
            for (s.s(); !(n = s.n()).done; ) {
                e = n.value;
                var o = Math.floor(this.randomValue * e.slogan.length);
                a.push(r(r({}, e), {}, {
                    desc: e.slogan[o]
                }));
            }
        } catch (e) {
            s.e(e);
        } finally {
            s.f();
        }
        return a;
    }
};

exports.default = g;