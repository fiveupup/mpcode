Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.SUB_TYPES = void 0, exports.getNotificationTime = function() {
    return g.apply(this, arguments);
}, exports.getPayContactList = function() {
    return v.apply(this, arguments);
}, exports.getProInviteImage = function() {
    return l.apply(this, arguments);
}, exports.getProMetrics = function() {
    return T.apply(this, arguments);
}, exports.getTagTopics = function(t, e) {
    return k.apply(this, arguments);
}, exports.getUserSubscription = function() {
    return f.apply(this, arguments);
}, exports.getUserSubscriptionRecommand = function() {
    return O.apply(this, arguments);
}, exports.getUserSubscriptionUpdates = function() {
    return I.apply(this, arguments);
}, exports.stopProContact = function(t) {
    return P.apply(this, arguments);
}, exports.subscribeEntity = function(t) {
    return m.apply(this, arguments);
}, exports.subscribeEntitys = h, exports.syncProContact = function() {
    return M.apply(this, arguments);
}, exports.unSubscribeEntity = function(t) {
    return b.apply(this, arguments);
}, exports.updateNotificationTime = function(t) {
    return _.apply(this, arguments);
};

var t = require("../@babel/runtime/helpers/regeneratorRuntime"), e = require("../@babel/runtime/helpers/asyncToGenerator"), r = p(require("../utils/request")), n = p(require("../config")), a = require("../utils/format"), u = require("../utils/tools"), i = function(t, e) {
    if (!e && t && t.__esModule) return t;
    if (null === t || "object" != typeof t && "function" != typeof t) return {
        default: t
    };
    var r = s(e);
    if (r && r.has(t)) return r.get(t);
    var n = {}, a = Object.defineProperty && Object.getOwnPropertyDescriptor;
    for (var u in t) if ("default" !== u && Object.prototype.hasOwnProperty.call(t, u)) {
        var i = a ? Object.getOwnPropertyDescriptor(t, u) : null;
        i && (i.get || i.set) ? Object.defineProperty(n, u, i) : n[u] = t[u];
    }
    n.default = t, r && r.set(t, n);
    return n;
}(require("lodash")), o = p(require("../store/app")), c = (require("./stock"), p(require("dayjs")));

function s(t) {
    if ("function" != typeof WeakMap) return null;
    var e = new WeakMap(), r = new WeakMap();
    return (s = function(t) {
        return t ? r : e;
    })(t);
}

function p(t) {
    return t && t.__esModule ? t : {
        default: t
    };
}

function l() {
    return (l = e(t().mark(function e() {
        var a, u;
        return t().wrap(function(t) {
            for (;;) switch (t.prev = t.next) {
              case 0:
                return t.prev = 0, t.next = 3, (0, r.default)({
                    url: "".concat(n.default.COMMON_API_HOST, "/invite/code")
                });

              case 3:
                return a = t.sent.data.items[0].code, t.next = 6, (0, r.default)({
                    url: "".concat(n.default.COMMON_API_HOST, "/invite/code/image?code=").concat(a)
                });

              case 6:
                return u = t.sent.data.items[0].url, t.abrupt("return", u);

              case 10:
                return t.prev = 10, t.t0 = t.catch(0), console.error(t.t0), t.abrupt("return", "");

              case 14:
              case "end":
                return t.stop();
            }
        }, e, null, [ [ 0, 10 ] ]);
    }))).apply(this, arguments);
}

function f() {
    return (f = e(t().mark(function e() {
        return t().wrap(function(t) {
            for (;;) switch (t.prev = t.next) {
              case 0:
                return t.abrupt("return", (0, r.default)({
                    url: "".concat(n.default.COMMON_API_HOST, "/subscribe/list?page=1&size=100")
                }));

              case 1:
              case "end":
                return t.stop();
            }
        }, e);
    }))).apply(this, arguments);
}

var d = {
    entity: 10,
    timeline: 21,
    tag: 22
};

function m() {
    return (m = e(t().mark(function e(r) {
        var n;
        return t().wrap(function(t) {
            for (;;) switch (t.prev = t.next) {
              case 0:
                if (console.log("subscribeEntity", r), "string" != typeof r) {
                    t.next = 7;
                    break;
                }
                return t.next = 4, h(null, [ r ]);

              case 4:
                n = t.sent, t.next = 16;
                break;

              case 7:
                if (r.type !== d.timeline || !r.uid) {
                    t.next = 13;
                    break;
                }
                return t.next = 10, h(null, [ r.uid ]);

              case 10:
                n = t.sent, t.next = 16;
                break;

              case 13:
                return t.next = 15, h([ r ]);

              case 15:
                n = t.sent;

              case 16:
                return t.abrupt("return", {
                    subscription: n.data.items[0]
                });

              case 17:
              case "end":
                return t.stop();
            }
        }, e);
    }))).apply(this, arguments);
}

function h() {
    return y.apply(this, arguments);
}

function y() {
    return (y = e(t().mark(function e() {
        var a, u, i, c, s = arguments;
        return t().wrap(function(t) {
            for (;;) switch (t.prev = t.next) {
              case 0:
                if (a = s.length > 0 && void 0 !== s[0] ? s[0] : [], u = s.length > 1 && void 0 !== s[1] ? s[1] : [], 
                console.log("subscribeEntitys", a, u), a = a || [], "[object Array]" === Object.prototype.toString.call(a) || (a = [ a ]), 
                i = a.length + u.length, !(o.default.pro.subList.length >= 100 - i + 1)) {
                    t.next = 12;
                    break;
                }
                throw wx.showToast({
                    title: "最多订阅 100 个",
                    icon: "none"
                }), "pages/pro/subscription_manage" !== (c = getCurrentPages())[c.length - 1].route && setTimeout(function() {
                    wx.navigateTo({
                        url: "/pages/pro/subscription_manage"
                    });
                }, 1300), new Error("");

              case 12:
                return t.abrupt("return", (0, r.default)({
                    url: "".concat(n.default.COMMON_API_HOST, "/subscribe"),
                    method: "POST",
                    data: {
                        sub_list: a,
                        uid: u
                    }
                }));

              case 13:
              case "end":
                return t.stop();
            }
        }, e);
    }))).apply(this, arguments);
}

function b() {
    return (b = e(t().mark(function e(a) {
        return t().wrap(function(t) {
            for (;;) switch (t.prev = t.next) {
              case 0:
                return "[object Array]" === Object.prototype.toString.call(a) || (a = [ a ]), t.abrupt("return", (0, 
                r.default)({
                    url: "".concat(n.default.COMMON_API_HOST, "/unsubscribe"),
                    method: "POST",
                    data: {
                        uid: a
                    }
                }));

              case 3:
              case "end":
                return t.stop();
            }
        }, e);
    }))).apply(this, arguments);
}

function O() {
    return (O = e(t().mark(function e() {
        return t().wrap(function(t) {
            for (;;) switch (t.prev = t.next) {
              case 0:
                return t.abrupt("return", (0, r.default)({
                    url: "".concat(n.default.COMMON_API_HOST, "/subscribe_recommend/config?size=100")
                }).then(function(t) {
                    return {
                        data: t.data.items[0].subList
                    };
                }));

              case 1:
              case "end":
                return t.stop();
            }
        }, e);
    }))).apply(this, arguments);
}

function g() {
    return (g = e(t().mark(function e() {
        return t().wrap(function(t) {
            for (;;) switch (t.prev = t.next) {
              case 0:
                return t.abrupt("return", (0, r.default)({
                    url: "".concat(n.default.COMMON_API_HOST, "/reminder_plan/config/detail?type=2")
                }).then(function(t) {
                    var e, r, n;
                    return (null === (e = t.data) || void 0 === e || null === (r = e.items) || void 0 === r || null === (n = r[0]) || void 0 === n ? void 0 : n.reminderTime) || (0, 
                    c.default)().toISOString();
                }));

              case 1:
              case "end":
                return t.stop();
            }
        }, e);
    }))).apply(this, arguments);
}

function _() {
    return (_ = e(t().mark(function e(a) {
        return t().wrap(function(t) {
            for (;;) switch (t.prev = t.next) {
              case 0:
                return t.abrupt("return", (0, r.default)({
                    url: "".concat(n.default.COMMON_API_HOST, "/reminder_plan/config"),
                    method: "POST",
                    data: {
                        type: 2,
                        reminder_time: a
                    }
                }));

              case 1:
              case "end":
                return t.stop();
            }
        }, e);
    }))).apply(this, arguments);
}

function v() {
    return (v = e(t().mark(function e() {
        var a, i = arguments;
        return t().wrap(function(t) {
            for (;;) switch (t.prev = t.next) {
              case 0:
                return a = i.length > 0 && void 0 !== i[0] ? i[0] : {
                    page: 1,
                    size: 1
                }, t.abrupt("return", (0, r.default)({
                    url: "".concat(n.default.COMMON_API_HOST, "/pay_readhub/contract/list?").concat((0, 
                    u.queryString)(a))
                }));

              case 2:
              case "end":
                return t.stop();
            }
        }, e);
    }))).apply(this, arguments);
}

function x(t) {
    for (var e = 1; 10 * e < t && e < 1e4; ) e *= 10;
    return "".concat(t - t % e, "+");
}

function w(t) {
    var e, r;
    return i.map(null == t || null === (e = t.data) || void 0 === e || null === (r = e.items) || void 0 === r ? void 0 : r[0].metricList, function(t) {
        return {
            name: t.name,
            count: x(t.count)
        };
    });
}

function T() {
    return (T = e(t().mark(function e() {
        var a;
        return t().wrap(function(t) {
            for (;;) switch (t.prev = t.next) {
              case 0:
                return t.next = 2, (0, r.default)({
                    url: "".concat(n.default.COMMON_API_HOST, "/pro/metrics")
                });

              case 2:
                return a = t.sent, t.abrupt("return", w(a));

              case 4:
              case "end":
                return t.stop();
            }
        }, e);
    }))).apply(this, arguments);
}

function M() {
    return (M = e(t().mark(function e() {
        return t().wrap(function(t) {
            for (;;) switch (t.prev = t.next) {
              case 0:
                return t.abrupt("return", (0, r.default)({
                    url: "".concat(n.default.COMMON_API_HOST, "/pay_readhub/contract/sync"),
                    method: "POST",
                    data: {}
                }));

              case 1:
              case "end":
                return t.stop();
            }
        }, e);
    }))).apply(this, arguments);
}

function P() {
    return (P = e(t().mark(function e(a) {
        return t().wrap(function(t) {
            for (;;) switch (t.prev = t.next) {
              case 0:
                return t.abrupt("return", (0, r.default)({
                    url: "".concat(n.default.COMMON_API_HOST, "/pay_readhub/contract/delete"),
                    method: "POST",
                    data: {
                        uid: a
                    }
                }));

              case 1:
              case "end":
                return t.stop();
            }
        }, e);
    }))).apply(this, arguments);
}

function S(t) {
    t = t.data;
    var e = {};
    e.data = t.items, e.entity = i.get(t, "self.entityList[0]") || i.get(t, "self.tagList[0]");
    var r = i.get(t, "totalPages", 0), u = i.get(t, "pageIndex", 0);
    return u >= r || t.items.length < i.get(t, "itemsPerPage", 0) ? i.set(e, "links.next", "") : i.set(e, "links.next", "".concat(n.default.COMMON_API_HOST, "/topic/list_pro?entity_id=").concat(e.entity.uid, "&page=").concat(u + 1, "&size=").concat(20)), 
    e.total = i.get(t, "totalItems", 0), e.data && e.data.forEach(function(t) {
        t.title = (0, a.newsTitleFormat)(t.title), t.summary = (0, a.newsTitleFormat)(t.summary), 
        t.relate = t.siteNameDisplay, t.needIndent = "「" === t.title[0], t.siteCount && (t.relate = "".concat(t.relate, " 等 ").concat(t.siteCount, " 家媒体报道")), 
        t.id = t.uid, t.type = "topic";
    }), e;
}

function k() {
    return (k = e(t().mark(function e(a, u) {
        var i, o, c, s = arguments;
        return t().wrap(function(t) {
            for (;;) switch (t.prev = t.next) {
              case 0:
                return i = !(s.length > 2 && void 0 !== s[2]) || s[2], o = i ? 20 : 3, (c = u) || (c = "".concat(n.default.COMMON_API_HOST, "/topic/list_pro?tag_id=").concat(a, "&page=1&size=").concat(o)), 
                t.abrupt("return", (0, r.default)({
                    url: c
                }).then(function(t) {
                    return S(t);
                }));

              case 5:
              case "end":
                return t.stop();
            }
        }, e);
    }))).apply(this, arguments);
}

function I() {
    return (I = e(t().mark(function e() {
        return t().wrap(function(t) {
            for (;;) switch (t.prev = t.next) {
              case 0:
                return t.abrupt("return", (0, r.default)({
                    url: "".concat(n.default.COMMON_API_HOST, "/subscribe/render_list")
                }).then(function(t) {
                    var e = t.data.items || [];
                    return e.forEach(function(t) {
                        t.content = (0, a.newsTitleFormat)(t.content), t.topicInfos && t.topicInfos.forEach(function(t) {
                            t.title = (0, a.newsTitleFormat)(t.title), t.summary = (0, a.newsTitleFormat)(t.summary), 
                            t.displayDate = (0, a.newsTitleFormat)((0, a.absoluteDatetime)(t.publishDate)), 
                            t.desc = t.siteNameDisplay, t.needIndent = "「" === t.title[0], t.siteCount && (t.desc = "".concat(t.siteNameDisplay, " 等 ").concat(t.siteCount, " 家媒体报道"));
                        }), t.stockFiles && (t.stockFiles = t.stockFiles.map(function(t) {
                            return {
                                id: t.uniqueId,
                                company: (0, a.newsTitleFormat)(t.company),
                                finance: (0, a.newsTitleFormat)(t.title),
                                exchangeDisplay: t.exchange,
                                date: t.publishDate,
                                dateDisplay: (0, a.newsTitleFormat)((0, a.absoluteDatetime)(t.publishDate))
                            };
                        }));
                    }), e;
                }));

              case 1:
              case "end":
                return t.stop();
            }
        }, e);
    }))).apply(this, arguments);
}

exports.SUB_TYPES = d;