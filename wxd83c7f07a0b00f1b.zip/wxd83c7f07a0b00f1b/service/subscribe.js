Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.authSubscribeMesssage = function(e) {
    return new Promise(function(r, t) {
        var n, u = Object.prototype.toString.call(e);
        if ("[object Array]" === u) n = e; else {
            if ("[object String]" !== u) return t(new Error("templateIds type error"));
            n = [ e ];
        }
        console.log("authSubscribeMesssage", n), wx.requestSubscribeMessage && "mac" !== s.platform ? wx.requestSubscribeMessage({
            tmplIds: n,
            success: function(e) {
                return "requestSubscribeMessage:ok" !== e.errMsg ? r([ new Error(e.errMsg), {} ]) : r([ null, e || {} ]);
            },
            fail: function(e) {
                r([ new Error(e.errMsg), {} ]);
            }
        }) : r([ new Error("不支持 requestSubscribeMessage"), {} ]);
    });
}, exports.cleanSubscribeMessages = function(e) {
    return c.apply(this, arguments);
}, exports.fetchSubscribeTemplates = function() {
    return a.apply(this, arguments);
}, exports.updateSubscribeMessage = function(e) {
    return i.apply(this, arguments);
};

var e = require("../@babel/runtime/helpers/regeneratorRuntime"), r = require("../@babel/runtime/helpers/asyncToGenerator"), t = u(require("../utils/request")), n = u(require("../config"));

function u(e) {
    return e && e.__esModule ? e : {
        default: e
    };
}

var s = (0, require("@mina-modules/system-info").getSysInfo)();

function a() {
    return (a = r(e().mark(function r() {
        var u, s, a = arguments;
        return e().wrap(function(e) {
            for (;;) switch (e.prev = e.next) {
              case 0:
                return u = a.length > 0 && void 0 !== a[0] ? a[0] : [ 0, 1, 2, 3, 5 ], s = u.map(function(e) {
                    return "type=".concat(e);
                }).join("&"), e.abrupt("return", (0, t.default)({
                    url: "".concat(n.default.COMMON_API_HOST, "/readhub_msg/ticket/template_id/wx_mini?").concat(s),
                    method: "GET"
                }));

              case 3:
              case "end":
                return e.stop();
            }
        }, r);
    }))).apply(this, arguments);
}

function i() {
    return (i = r(e().mark(function r(u) {
        return e().wrap(function(e) {
            for (;;) switch (e.prev = e.next) {
              case 0:
                return e.abrupt("return", (0, t.default)({
                    url: "".concat(n.default.COMMON_API_HOST, "/readhub_msg/ticket/wx_mini"),
                    method: "POST",
                    data: u
                }));

              case 1:
              case "end":
                return e.stop();
            }
        }, r);
    }))).apply(this, arguments);
}

function c() {
    return (c = r(e().mark(function r(u) {
        return e().wrap(function(e) {
            for (;;) switch (e.prev = e.next) {
              case 0:
                return e.abrupt("return", (0, t.default)({
                    url: "".concat(n.default.COMMON_API_HOST, "/readhub_msg/ticket/template_id/clean/wx_mini"),
                    method: "POST",
                    data: {
                        tmpl_id: u
                    }
                }));

              case 1:
              case "end":
                return e.stop();
            }
        }, r);
    }))).apply(this, arguments);
}