Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.getIndustry = function(r) {
    return i.apply(this, arguments);
}, exports.getJob = function(r) {
    return c.apply(this, arguments);
}, exports.getRankHistory = function(r) {
    return o.apply(this, arguments);
}, exports.getSalaryHistory = function(r) {
    return s.apply(this, arguments);
};

var r = require("../@babel/runtime/helpers/regeneratorRuntime"), t = require("../@babel/runtime/helpers/asyncToGenerator"), e = a(require("../utils/request")), n = a(require("../config")), u = require("../utils/tools");

function a(r) {
    return r && r.__esModule ? r : {
        default: r
    };
}

function c() {
    return (c = t(r().mark(function t(a) {
        return r().wrap(function(r) {
            for (;;) switch (r.prev = r.next) {
              case 0:
                return r.abrupt("return", (0, e.default)({
                    url: "".concat(n.default.API_HOST, "/recruit/job?").concat((0, u.queryString)({
                        term_id: a || ""
                    }))
                }));

              case 1:
              case "end":
                return r.stop();
            }
        }, t);
    }))).apply(this, arguments);
}

function i() {
    return (i = t(r().mark(function t(a) {
        return r().wrap(function(r) {
            for (;;) switch (r.prev = r.next) {
              case 0:
                return r.abrupt("return", (0, e.default)({
                    url: "".concat(n.default.API_HOST, "/recruit/industry?").concat((0, u.queryString)({
                        term_id: a || ""
                    }))
                }));

              case 1:
              case "end":
                return r.stop();
            }
        }, t);
    }))).apply(this, arguments);
}

function o() {
    return (o = t(r().mark(function t(u) {
        return r().wrap(function(r) {
            for (;;) switch (r.prev = r.next) {
              case 0:
                return r.abrupt("return", (0, e.default)({
                    url: "".concat(n.default.API_HOST, "/recruit/rank"),
                    method: "POST",
                    data: u
                }));

              case 1:
              case "end":
                return r.stop();
            }
        }, t);
    }))).apply(this, arguments);
}

function s() {
    return (s = t(r().mark(function t(u) {
        return r().wrap(function(r) {
            for (;;) switch (r.prev = r.next) {
              case 0:
                return r.abrupt("return", (0, e.default)({
                    url: "".concat(n.default.API_HOST, "/recruit/salary"),
                    method: "POST",
                    data: u
                }));

              case 1:
              case "end":
                return r.stop();
            }
        }, t);
    }))).apply(this, arguments);
}