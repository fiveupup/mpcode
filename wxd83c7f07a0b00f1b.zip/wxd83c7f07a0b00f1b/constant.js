Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.htmlRegex = exports.feedbackType = void 0;

exports.htmlRegex = /https?:\/\/(www\.)?[-a-zA-Z0-9@:%._\+~#=]{1,256}\.[a-zA-Z0-9()]{1,6}\b([-a-zA-Z0-9()@:%_\+.~#?&//=]*)/i;

var e = function(e) {
    return e[e["看财报"] = 1] = "看财报", e[e["招股书"] = 2] = "招股书", e[e["搜索全部"] = 3] = "搜索全部", 
    e[e["搜索话题"] = 4] = "搜索话题", e;
}({});

exports.feedbackType = e;