Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.absoluteDatetime = function(e) {
    var r = (0, t.default)();
    e = (0, t.default)(e);
    var n = r.toDate().getTime() - e.toDate().getTime();
    if (n < 36e5) {
        var o = Math.floor(n / 6e4);
        return 0 === o ? "刚刚" : o < 0 ? "".concat(Math.abs(o)) + " 分钟前" : o + " 分钟前";
    }
    return r.isSame(e, "day") ? Math.floor(n / 36e5) + " 小时前" : r.isSame(e, "year") ? e.format("MM月DD日") : e.format("YYYY年MM月DD日");
}, exports.commonFormat = i, exports.escape = function(e) {
    return e && s.test(e) ? e.replace(c, p) : e;
}, Object.defineProperty(exports, "htmlFormat", {
    enumerable: !0,
    get: function() {
        return n.htmlFormat;
    }
}), exports.ncFormat = f, exports.newsTitleFormat = function(e) {
    return i(e);
}, exports.searchAbsoluteDatetime = function(e) {
    var r = (0, t.default)();
    e = (0, t.default)(e);
    var n = r.toDate().getTime() - e.toDate().getTime();
    if (n < 36e5) {
        var o = Math.floor(n / 6e4);
        return 0 === o ? "刚刚" : o + " 分钟前";
    }
    return r.isSame(e, "day") ? Math.floor(n / 36e5) + " 小时前" : r.isSame(e, "year") ? e.format("MM-DD") : e.format("YYYY-MM-DD");
}, exports.sitesInfo = function() {
    var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : [], t = r.uniq(e.map(function(e) {
        return e.siteName;
    }));
    if (0 === t.length) return "";
    var n = t.length, o = t[0];
    return n > 1 ? "".concat(o, " 等 ").concat(n, " 家媒体报道") : "".concat(o, " 报道");
}, exports.stockDateDisplay = function(e) {
    return e = (0, t.default)(e), (0, t.default)().isSame(e, "year") ? e.format("MM.DD") : e.format("YYYY.MM.DD");
}, Object.defineProperty(exports, "toHtml", {
    enumerable: !0,
    get: function() {
        return n.toHtml;
    }
});

var e = a(require("../libs/pangu")), t = a(require("dayjs")), r = function(e, t) {
    if (!t && e && e.__esModule) return e;
    if (null === e || "object" != typeof e && "function" != typeof e) return {
        default: e
    };
    var r = o(t);
    if (r && r.has(e)) return r.get(e);
    var n = {}, a = Object.defineProperty && Object.getOwnPropertyDescriptor;
    for (var u in e) if ("default" !== u && Object.prototype.hasOwnProperty.call(e, u)) {
        var f = a ? Object.getOwnPropertyDescriptor(e, u) : null;
        f && (f.get || f.set) ? Object.defineProperty(n, u, f) : n[u] = e[u];
    }
    n.default = e, r && r.set(e, n);
    return n;
}(require("./lodash")), n = require("./html");

function o(e) {
    if ("function" != typeof WeakMap) return null;
    var t = new WeakMap(), r = new WeakMap();
    return (o = function(e) {
        return e ? r : t;
    })(e);
}

function a(e) {
    return e && e.__esModule ? e : {
        default: e
    };
}

var u = new e.default();

function f(e) {
    return u.formatText(e);
}

function i(e) {
    return f(e);
}

var l, c = /[&<>'']/g, s = RegExp(c.source), p = (l = {
    "&": "&amp;",
    "<": "&lt;",
    ">": "&gt;",
    '"': "&quot;",
    "'": "&#39;"
}, function(e) {
    return null == l ? void 0 : l[e];
});