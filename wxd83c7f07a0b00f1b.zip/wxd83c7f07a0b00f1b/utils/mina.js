Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.downloadAndSaveImageToAlbum = function(e) {
    return i.apply(this, arguments);
}, exports.getSystemInfo = function() {
    return s = wx.getSystemInfoSync();
}, exports.isIOS = function() {
    return o.default.setting.isIOS;
}, exports.isInTimeLine = function() {
    try {
        return 1154 === wx.getLaunchOptionsSync().scene;
    } catch (e) {
        return !1;
    }
}, exports.isPcPlatform = function() {
    return [ "mac", "windows" ].indexOf(s.platform) > -1 && "2.12.1" === s.SDKVersion;
}, exports.isSinglePageMode = function() {
    return 1154 === n.get(getApp().globalData.launchOptions, "scene");
}, exports.isWechatCrawler = function() {
    return 1129 === n.get(getApp().globalData.launchOptions, "scene");
}, exports.setBackgroundColor = function(e, t) {
    (0, a.report)("theme", {
        label: e
    });
    var r = t || {
        dark: "#111111",
        light: "#ffffff"
    };
    wx.setBackgroundColor && wx.setBackgroundColor({
        backgroundColor: "dark" === e ? r.dark : r.light,
        backgroundColorTop: "dark" === e ? r.dark : r.light,
        backgroundColorBottom: "dark" === e ? r.dark : r.light
    }), wx.setBackgroundTextStyle && wx.setBackgroundTextStyle({
        textStyle: "dark" === e ? "light" : "dark"
    });
};

var e, t = require("../@babel/runtime/helpers/regeneratorRuntime"), r = require("../@babel/runtime/helpers/asyncToGenerator"), n = function(e, t) {
    if (!t && e && e.__esModule) return e;
    if (null === e || "object" != typeof e && "function" != typeof e) return {
        default: e
    };
    var r = u(t);
    if (r && r.has(e)) return r.get(e);
    var n = {}, o = Object.defineProperty && Object.getOwnPropertyDescriptor;
    for (var a in e) if ("default" !== a && Object.prototype.hasOwnProperty.call(e, a)) {
        var s = o ? Object.getOwnPropertyDescriptor(e, a) : null;
        s && (s.get || s.set) ? Object.defineProperty(n, a, s) : n[a] = e[a];
    }
    n.default = e, r && r.set(e, n);
    return n;
}(require("./lodash")), o = (e = require("../store/app")) && e.__esModule ? e : {
    default: e
}, a = require("../service/analyse");

function u(e) {
    if ("function" != typeof WeakMap) return null;
    var t = new WeakMap(), r = new WeakMap();
    return (u = function(e) {
        return e ? r : t;
    })(e);
}

var s = wx.getSystemInfoSync();

function i() {
    return (i = r(t().mark(function e(r) {
        var n;
        return t().wrap(function(e) {
            for (;;) switch (e.prev = e.next) {
              case 0:
                return console.log("download and save url", r), e.prev = 1, e.next = 4, wx.getSetting();

              case 4:
                if (e.sent.authSetting["scope.writePhotosAlbum"]) {
                    e.next = 12;
                    break;
                }
                return e.next = 8, new Promise(function(e) {
                    wx.authorize({
                        scope: "scope.writePhotosAlbum",
                        success: function() {
                            e(!0);
                        },
                        fail: function() {
                            e(!1);
                        }
                    });
                });

              case 8:
                if (e.sent) {
                    e.next = 12;
                    break;
                }
                return wx.showModal({
                    title: "提示",
                    content: "需要获取相册访问权限，请到小程序设置页面打开授权",
                    success: function(e) {
                        e.confirm && wx.openSetting({});
                    }
                }), e.abrupt("return");

              case 12:
                if (0 !== r.indexOf("http")) {
                    e.next = 21;
                    break;
                }
                return e.next = 15, new Promise(function(e, t) {
                    wx.downloadFile({
                        url: r,
                        success: e,
                        fail: t
                    });
                });

              case 15:
                if ((n = e.sent).tempFilePath) {
                    e.next = 18;
                    break;
                }
                throw new Error("下载图片失败");

              case 18:
                r = n.tempFilePath, e.next = 24;
                break;

              case 21:
                return e.next = 23, wx.getImageInfo({
                    src: r
                });

              case 23:
                r = e.sent.path;

              case 24:
                return e.next = 26, wx.saveImageToPhotosAlbum({
                    filePath: r
                });

              case 26:
                return e.abrupt("return", !0);

              case 29:
                return e.prev = 29, e.t0 = e.catch(1), console.error(e.t0), wx.showToast({
                    title: "保存失败",
                    icon: "none"
                }), e.abrupt("return", !1);

              case 34:
              case "end":
                return e.stop();
            }
        }, e, null, [ [ 1, 29 ] ]);
    }))).apply(this, arguments);
}