Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.default = void 0;

var e = require("../@babel/runtime/helpers/createForOfIteratorHelper");

var r = function(r, t) {
    function i(t) {
        var i, a = e(r);
        try {
            for (a.s(); !(i = a.n()).done; ) {
                var l = i.value;
                if (l.id.toString() === t) return l;
            }
        } catch (e) {
            a.e(e);
        } finally {
            a.f();
        }
        return null;
    }
    if (!r || r.length <= 1) return r;
    var a, l, n = [], u = -1, o = [], f = e(r);
    try {
        for (f.s(); !(l = f.n()).done; ) if ((a = l.value).id) if (a.duplicateId) if (u < 0 && (u = a.duplicateId), 
        a.duplicateId === u) o.push(a.id.toString()); else {
            if (0 === o.length) {
                u = a.duplicateId;
                continue;
            }
            n.push(o), u = a.duplicateId, o = [ a.id.toString() ];
        } else n.push([ a.id.toString() ]);
    } catch (e) {
        f.e(e);
    } finally {
        f.f();
    }
    o.length > 0 && n.push(o);
    for (var s = [], d = 0, c = n; d < c.length; d++) {
        var p = c[d];
        if (p) {
            var v = i(p[0]);
            if (v) {
                var h, y = [], g = e(p);
                try {
                    for (g.s(); !(h = g.n()).done; ) {
                        var m = i(h.value);
                        if (m && m.siteName) {
                            var b = m.siteName;
                            if ("微信公众号" === b && (b = m.authorName), y.length >= 3) {
                                !0, y.push("more");
                                break;
                            }
                            var I, S = !1, x = e(y);
                            try {
                                for (x.s(); !(I = x.n()).done; ) {
                                    if (I.value.source === b) {
                                        S = !0;
                                        break;
                                    }
                                }
                            } catch (e) {
                                x.e(e);
                            } finally {
                                x.f();
                            }
                            if (S) continue;
                            var N = m.url;
                            t && m.mobileUrl && (N = m.mobileUrl), y.push({
                                source: b,
                                url: N
                            });
                        }
                    }
                } catch (e) {
                    g.e(e);
                } finally {
                    g.f();
                }
                v.sites = y, v.displaySites = y.map(function(e) {
                    return e.source;
                }).join(" / "), s.push(v);
            }
        }
    }
    return s;
};

exports.default = r;