Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.openFile = function(o) {
    if ((0, e.isInTimeLine)()) return void wx.showToast({
        title: "请前往小程序内查看",
        icon: "none"
    });
    if (!o.cdnUrl) return void wx.setClipboardData({
        data: o.sourceUrl,
        success: function() {
            wx.showModal({
                title: "",
                content: "已复制文件链接，请粘贴至浏览器打开并查看文件",
                showCancel: !1,
                confirmText: "知道了"
            });
        }
    });
    var t = o.cdnUrl, n = o.company + o.title;
    if (t.match(/\.pdf$/)) return void wx.navigateTo({
        url: "/pages/tools/pdf/reader?file=".concat(encodeURIComponent(t), "&title=").concat(encodeURIComponent(n), "&fid=").concat(o.uniqueId)
    });
    if (t.match(/\.html?$/)) return void wx.navigateTo({
        url: "/pages/webview?url=".concat(encodeURIComponent(t), "&title=").concat(encodeURIComponent(n), "&share=false")
    });
};

var e = require("./mina");