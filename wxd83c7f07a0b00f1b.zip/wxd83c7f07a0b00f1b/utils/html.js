Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.htmlFormat = a, exports.toHtml = function(e) {
    var r = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {
        link: !1,
        header: !1,
        code: !1
    };
    n.use({
        renderer: {
            heading: function(e) {
                return r.header ? "<h".concat(this.level, ">").concat(e, "</h").concat(this.level, ">") : "<p>".concat(e, "</p>");
            },
            link: function(e, t, n) {
                return r.link ? '<a href="'.concat(e, '" alt="').concat(t, ">").concat(n, "</a>") : '<span style="word-break: break-all;">'.concat(n, "</span>");
            },
            code: function(e) {
                return r.code ? "<pre><code>".concat(e, "</code></pre>") : "<p>".concat(e, "</p>");
            }
        }
    });
    var t = n(e, {
        headerIds: !1
    });
    return a(t);
};

var e, r = require("../@babel/runtime/helpers/slicedToArray");

var t = new (((e = require("../libs/pangu")) && e.__esModule ? e : {
    default: e
}).default)(), n = require("../libs/marked");

function a(e) {
    for (var n, a = new RegExp(">(.*?)<", "g"); null !== (n = a.exec(e)); ) {
        var c = r(n, 2), o = (c[0], c[1]);
        e = e.replace(o, t.formatText(o));
    }
    return e;
}