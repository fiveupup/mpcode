Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.relativeDatetime = function(e) {
    var r = (0, t.default)(), a = function(e) {
        var t = e.clone().startOf("day"), r = e.clone().subtract(1, "days").startOf("day"), a = e.clone().subtract(2, "days").startOf("day"), s = e.clone().subtract(7, "days").startOf("day");
        function i(e) {
            return e.isAfter(s);
        }
        return {
            isToday: function(e) {
                return e.isSame(t, "d");
            },
            isYesterday: function(e) {
                return e.isSame(r, "d");
            },
            isTheDayBeforeYesterday: function(e) {
                return e.isSame(a, "d");
            },
            isWithinAWeek: i,
            isTwoWeeksOrMore: function(e) {
                return !i(e);
            }
        };
    }(r);
    e = (0, t.default)(e);
    var s = r.toDate().getTime() - e.toDate().getTime();
    if (s < 36e5) {
        var i = Math.floor(Math.abs(s / 6e4));
        return 0 === i ? "刚刚" : i + " 分钟前";
    }
    return a.isToday(e) ? Math.round(s / 36e5) + " 小时前" : a.isYesterday(e) ? "昨天" : a.isTheDayBeforeYesterday(e) ? "前天" : r.isSame(e, "year") ? e.format("M 月 D 日") : e.format("YYYY 年 M 月 D 日");
};

var e, t = (e = require("dayjs")) && e.__esModule ? e : {
    default: e
};