Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.cloudRequest = function(e, r) {
    return s.apply(this, arguments);
}, exports.default = function(e) {
    return i.apply(this, arguments);
};

var e, r = require("../@babel/runtime/helpers/regeneratorRuntime"), t = require("../@babel/runtime/helpers/asyncToGenerator"), n = (e = require("../config")) && e.__esModule ? e : {
    default: e
}, a = require("./mina"), u = function(e, r) {
    if (!r && e && e.__esModule) return e;
    if (null === e || "object" != typeof e && "function" != typeof e) return {
        default: e
    };
    var t = o(r);
    if (t && t.has(e)) return t.get(e);
    var n = {}, a = Object.defineProperty && Object.getOwnPropertyDescriptor;
    for (var u in e) if ("default" !== u && Object.prototype.hasOwnProperty.call(e, u)) {
        var c = a ? Object.getOwnPropertyDescriptor(e, u) : null;
        c && (c.get || c.set) ? Object.defineProperty(n, u, c) : n[u] = e[u];
    }
    n.default = e, t && t.set(e, n);
    return n;
}(require("./lodash"));

function o(e) {
    if ("function" != typeof WeakMap) return null;
    var r = new WeakMap(), t = new WeakMap();
    return (o = function(e) {
        return e ? t : r;
    })(e);
}

var c = 0;

function s() {
    return (s = t(r().mark(function e(t, n) {
        var a;
        return r().wrap(function(e) {
            for (;;) switch (e.prev = e.next) {
              case 0:
                return a = new wx.cloud.Cloud({
                    resourceAppid: "wx50d5f3f54db5e32d",
                    resourceEnv: "readhub-8gufm1r48be6c421"
                }), e.next = 3, a.init();

              case 3:
                return e.abrupt("return", new Promise(function(e, r) {
                    a.callFunction({
                        name: "readhub_" + t,
                        data: n
                    }).then(function(t) {
                        if (console.log(t), t.result.error) return console.warn("cloudRequest fail", t), 
                        r(new Error(t.result.error));
                        e(t.result.data);
                    }).catch(r);
                }));

              case 4:
              case "end":
                return e.stop();
            }
        }, e);
    }))).apply(this, arguments);
}

function i() {
    return (i = t(r().mark(function e(o) {
        var s, i;
        return r().wrap(function(e) {
            for (;;) switch (e.prev = e.next) {
              case 0:
                return s = {}, e.prev = 1, e.next = 4, wx.getStorage({
                    key: n.default.USER_KEY
                });

              case 4:
                s = e.sent.data, e.next = 9;
                break;

              case 7:
                e.prev = 7, e.t0 = e.catch(1);

              case 9:
                return i = "", s.token && (i = "Bearer ".concat(s.token)), (0, a.isSinglePageMode)() && (i = ""), 
                e.abrupt("return", new Promise(function(e, a) {
                    o.header = Object.assign({
                        Authorization: i,
                        version: n.default.VERSION
                    }, o.header || {});
                    var s = o.success, f = o.fail, l = new Date().getTime();
                    o.success = function() {
                        var i = t(r().mark(function t(i) {
                            return r().wrap(function(r) {
                                for (;;) switch (r.prev = r.next) {
                                  case 0:
                                    if (i.statusCode, console.debug("".concat(new Date().toLocaleString(), " ").concat(o.url, " request success after ").concat(new Date().getTime() - l, " ms:"), i), 
                                    r.prev = 1, s && s(i), 401 !== i.statusCode) {
                                        r.next = 15;
                                        break;
                                    }
                                    if (wx.removeStorageSync(n.default.SESSION_KEY), wx.removeStorageSync(n.default.USER_STORAGE_KEY), 
                                    wx.removeStorageSync(n.default.USER_KEY), getApp().globalData.userInfo = {}, 0 !== c) {
                                        r.next = 14;
                                        break;
                                    }
                                    return c++, r.next = 12, getApp().appLogin(!0);

                                  case 12:
                                    r.next = 15;
                                    break;

                                  case 14:
                                    return r.abrupt("return", a(new Error("认证失败")));

                                  case 15:
                                    if (!i.data.error || !i.data.error.message) {
                                        r.next = 19;
                                        break;
                                    }
                                    return r.abrupt("return", a(new Error(i.data.error.message)));

                                  case 19:
                                    if (!i.data.error) {
                                        r.next = 23;
                                        break;
                                    }
                                    return r.abrupt("return", a(new Error(i.data.error)));

                                  case 23:
                                    if (!i.data.errors) {
                                        r.next = 27;
                                        break;
                                    }
                                    return r.abrupt("return", a(new Error(u.get(i, "data.errors[0].message", "请求失败"))));

                                  case 27:
                                    if (200 === i.statusCode) {
                                        r.next = 31;
                                        break;
                                    }
                                    return r.abrupt("return", a(new Error("请求失败")));

                                  case 31:
                                    return c = 0, r.abrupt("return", e(i.data));

                                  case 33:
                                    r.next = 38;
                                    break;

                                  case 35:
                                    r.prev = 35, r.t0 = r.catch(1), a(r.t0);

                                  case 38:
                                  case "end":
                                    return r.stop();
                                }
                            }, t, null, [ [ 1, 35 ] ]);
                        }));
                        return function(e) {
                            return i.apply(this, arguments);
                        };
                    }(), o.fail = function(e) {
                        console.debug("".concat(new Date().toLocaleString(), " ").concat(o.url, " request fail after ").concat(new Date().getTime() - l, " ms:"), e.errMsg), 
                        f && f(e), e.errorType = "network", a(e);
                    }, console.debug("".concat(new Date().toLocaleString(), " ").concat(o.url, " request begin:"), o), 
                    wx.request(o);
                }));

              case 14:
              case "end":
                return e.stop();
            }
        }, e, null, [ [ 1, 7 ] ]);
    }))).apply(this, arguments);
}