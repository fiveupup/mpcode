Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.hasMoreItems = function(e) {
    return !!e.currentItemCount && e.currentItemCount === e.itemsPerPage;
};