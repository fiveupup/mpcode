Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.add = function(e) {
    console.log("add read history: ", e), a.push({
        t: Date.now(),
        d: e
    }), a = a.filter(function(e) {
        return (0, t.default)(e.t).add(3, "days") > (0, t.default)();
    }), wx.setStorage({
        key: r,
        data: a.slice(-50)
    });
}, exports.getHistoryCount = function() {
    return a.length;
};

var e, t = (e = require("dayjs")) && e.__esModule ? e : {
    default: e
};

var r = "readhub_history", a = [];

try {
    a = wx.getStorageSync(r) || [];
} catch (e) {}