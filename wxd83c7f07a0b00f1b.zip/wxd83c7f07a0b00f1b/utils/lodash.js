Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.assign = function(r, t) {
    Object.assign(r, t);
}, exports.chunk = function(t, e) {
    return t.reduce(function(t, n, o) {
        return o % e == 0 ? [].concat(r(t), [ [ n ] ]) : [].concat(r(t.slice(0, -1)), [ [].concat(r(t.slice(-1)[0]), [ n ]) ]);
    }, []);
}, exports.cloneDeep = void 0, exports.entries = function(r) {
    var t = Object.keys(r), e = t.length, n = new Array(e);
    for (;e--; ) n[e] = [ t[e], r[t[e]] ];
    return n;
}, exports.get = function(r, t, e) {
    var n = function(e) {
        return String.prototype.split.call(t, e).filter(Boolean).reduce(function(r, t) {
            return null != r ? r[t] : r;
        }, r);
    }, o = n(/[,[\]]+?/) || n(/[,[\].]+?/);
    return void 0 === o || o === r ? e : o;
}, exports.isEmpty = void 0, exports.isEqual = function(r, t) {
    return JSON.stringify(r) === JSON.stringify(t);
}, exports.isString = function(r) {
    if (r && "string" == typeof r.valueOf()) return !0;
    return !1;
}, exports.omit = function(r, e) {
    var n = t(r);
    return e.forEach(function(r) {
        delete n[r];
    }), n;
}, exports.range = function(r) {
    return Array.from({
        length: r
    }, function(r, t) {
        return t;
    });
}, exports.set = exports.sample = void 0, exports.shuffle = function(r) {
    for (var t = r.length - 1; t > 0; t--) {
        var e = Math.floor(Math.random() * (t + 1)), n = [ r[e], r[t] ];
        r[t] = n[0], r[e] = n[1];
    }
    return r;
}, exports.sortBy = void 0, exports.uniq = function(t) {
    return r(new Set(t));
}, exports.values = function(r) {
    var t, e = [];
    for (t in r) Object.prototype.hasOwnProperty.call(r, t) && e.push(r[t]);
    return e;
};

var r = require("../@babel/runtime/helpers/toConsumableArray");

exports.set = function(r, t, e) {
    return Object(r) !== r || (Array.isArray(t) || (t = t.toString().match(/[^.[\]]+/g) || []), 
    t.slice(0, -1).reduce(function(r, e, n) {
        return Object(r[e]) === r[e] ? r[e] : r[e] = Math.abs(t[n + 1]) >> 0 == +t[n + 1] ? [] : {};
    }, r)[t[t.length - 1]] = e), r;
};

var t = function(r) {
    return JSON.parse(JSON.stringify(r));
};

exports.cloneDeep = t;

exports.sample = function(r) {
    var t = null == r ? 0 : r.length;
    return t ? r[Math.floor(Math.random() * t)] : void 0;
};

exports.isEmpty = function(r) {
    return !r || (Array.isArray && Array.isArray(r) ? 0 === r.length : 0 === Object.keys(r).length);
};

exports.sortBy = function(r) {
    return function(t, e) {
        return t[r] > e[r] ? 1 : e[r] > t[r] ? -1 : 0;
    };
};