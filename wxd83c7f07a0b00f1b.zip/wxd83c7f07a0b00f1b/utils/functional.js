Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.singleExec = function(e) {
    var a = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {}, s = !1;
    return function() {
        var o = t(r().mark(function t() {
            var o, u, i, c, l, p = arguments;
            return r().wrap(function(r) {
                for (;;) switch (r.prev = r.next) {
                  case 0:
                    if (!s) {
                        r.next = 2;
                        break;
                    }
                    return r.abrupt("return");

                  case 2:
                    for (s = !0, r.prev = 3, o = p.length, u = new Array(o), i = 0; i < o; i++) u[i] = p[i];
                    return r.next = 7, e.apply(this, u);

                  case 7:
                    return c = r.sent, a.onSuccess && a.onSuccess.call(this), r.abrupt("return", c);

                  case 12:
                    r.prev = 12, r.t0 = r.catch(3), n.default.error(r.t0), (l = r.t0.message || r.t0.errMsg) && wx.hideLoading(), 
                    !a.ignoreErrorToast && "requestPayment:fail cancel" !== l && l && wx.showToast({
                        title: l,
                        icon: "none"
                    }), a.onError && a.onError.call(this, r.t0);

                  case 19:
                    return r.prev = 19, s = !1, a.onComplete && a.onComplete.call(this), r.finish(19);

                  case 23:
                  case "end":
                    return r.stop();
                }
            }, t, this, [ [ 3, 12, 19, 23 ] ]);
        }));
        return function() {
            return o.apply(this, arguments);
        };
    }();
};

var e, r = require("../@babel/runtime/helpers/regeneratorRuntime"), t = require("../@babel/runtime/helpers/asyncToGenerator"), n = (e = require("./logger")) && e.__esModule ? e : {
    default: e
};