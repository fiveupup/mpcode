Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.compact = function(e, t) {
    if ("number" == typeof t || !0 === t || !o.isEmpty(t) || "function" == typeof (null == t ? void 0 : t.then)) return r({}, e, t);
    return {};
}, exports.compareVersion = p, exports.decodeOptions = function() {
    var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {};
    Object.keys(e).forEach(function(t) {
        e[t] && "string" == typeof e[t] && (e[t] = decodeURIComponent(e[t]));
    });
}, exports.decodeScene = function(e) {
    try {
        var t = (e = decodeURIComponent(e)).split("&"), n = {};
        return t.forEach(function(e) {
            var t = e.split("=");
            2 === t.length && (n[t[0]] = decodeURIComponent(t[1]));
        }), n;
    } catch (e) {
        return null;
    }
}, exports.getActionSheet = function(e) {
    return e.map(function(e) {
        return c[e];
    });
}, exports.getCurrentPage = f, exports.getCurrentPagePath = function() {
    var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {}, t = f(), r = t.route, o = t.options;
    return "/".concat(r, "?").concat(a(n(n({}, o), e)));
}, exports.isSdkGreaterThan = function(e) {
    return p(wx.getSystemInfoSync().SDKVersion, e) >= 0;
}, exports.navigateTo = function(e) {
    var t = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {}, n = getCurrentPages(), r = n.length, o = n.findIndex(function(t) {
        var n = a(t.options);
        return "/".concat(t.route).concat(n && "?" + n) === e.url;
    });
    if (o > -1) {
        var u = r - o - 1;
        if (0 === u) return wx.showToast({
            title: "已在跳转页面",
            icon: "none"
        });
        if (t.navBackIfEqual) return wx.navigateBack({
            delta: u
        });
    }
    if (r >= 10) return wx.redirectTo(e);
    return wx.navigateTo(e);
}, exports.queryString = a, exports.queryStringWithoutDecode = function(e) {
    var t = [];
    for (var n in e) Object.prototype.hasOwnProperty.call(e, n) && void 0 !== e[n] && t.push("".concat(n, "=").concat(encodeURIComponent(e[n])));
    return t.join("&");
}, exports.splitCJKWord = function(e) {
    var t = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : [], n = "([^\\u2e80-\\u2eff\\u2f00-\\u2fdf\\u3040-\\u309f\\u30a0-\\u30fa\\u30fc-\\u30ff\\u3100-\\u312f\\u3200-\\u32ff\\u3400-\\u4dbf\\u4e00-\\u9fff\\uf900-\\ufaff\\s-,，、。?？!！;；:：>》」）】]+)", r = "(".concat(t.join("|"), ")"), o = n;
    t.length > 0 && (o = "".concat(r, "|") + n);
    var u, i = new RegExp(r), a = new RegExp(o, "g"), c = [], f = 0, p = [];
    do {
        u = a.exec(e);
        var s = void 0, l = void 0;
        if (u ? (s = e.slice(f, u.index), l = u[0]) : s = e.slice(f), s && (c.push({
            text: s,
            type: "cjk"
        }), f += s.length), l) {
            var h = c[c.length - 1], d = !1;
            if (h && " " === h.text[h.text.length - 1] && (d = !0), -1 === p.indexOf(l) && t.indexOf(l) > -1) {
                var g = t.indexOf(l);
                g > -1 && t.splice(g, 1), p.push(l), c.push({
                    text: "",
                    type: "flag",
                    needHideAfterJustify: d
                }), c.push({
                    text: l,
                    type: "key"
                }), c.push({
                    text: "",
                    type: "flag"
                });
            } else if (i.test(l)) {
                var x = c[c.length - 1];
                x && "cjk" === x.type ? x.text += l : c.push({
                    text: l,
                    type: "cjk"
                });
            } else c.push({
                text: "",
                type: "flag",
                needHideAfterJustify: d
            }), c.push({
                text: l,
                type: "ncjk"
            }), c.push({
                text: "",
                type: "flag"
            });
            f += l.length;
        }
    } while (u);
    return c;
}, exports.splitPunctuationWord = function(e) {
    var t = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : [], n = i, r = "(".concat(t.join("|"), ")");
    t.length > 0 && (n = "".concat(r, "|") + i);
    var o = new RegExp(i), u = new RegExp(n), a = [], c = [];
    return (e || "").split(u).filter(function(e) {
        return !!e;
    }).forEach(function(e) {
        if (-1 === a.indexOf(e) && t.indexOf(e) > -1) {
            var n = t.indexOf(e);
            n > -1 && t.splice(n, 1), a.push(e), c.push({
                text: e,
                type: "key"
            });
        } else if (o.test(e)) c.push({
            text: e,
            type: "pct"
        }); else {
            var r = c[c.length - 1];
            r && !r.type ? r.text += e : c.push({
                text: e
            });
        }
    }), c;
}, exports.textLen = function(e) {
    for (var t = 0, n = 0, r = e.length; n < r; n++) /[\u0000-\u00FF]/.test(e[n]) ? t += .5 : t++;
    return t;
}, exports.throttle = function(e, t, n) {
    var r, o = null;
    return function() {
        var u = this, i = arguments, a = +new Date();
        clearTimeout(o), r || (r = a), a - r >= n ? (e.apply(u, i), r = a) : o = setTimeout(function() {
            e.apply(u, i);
        }, t);
    };
}, exports.withErrorCatch = function(e) {
    return s.apply(this, arguments);
};

var e = require("../@babel/runtime/helpers/regeneratorRuntime"), t = require("../@babel/runtime/helpers/asyncToGenerator"), n = require("../@babel/runtime/helpers/objectSpread2"), r = require("../@babel/runtime/helpers/defineProperty"), o = function(e, t) {
    if (!t && e && e.__esModule) return e;
    if (null === e || "object" != typeof e && "function" != typeof e) return {
        default: e
    };
    var n = u(t);
    if (n && n.has(e)) return n.get(e);
    var r = {}, o = Object.defineProperty && Object.getOwnPropertyDescriptor;
    for (var i in e) if ("default" !== i && Object.prototype.hasOwnProperty.call(e, i)) {
        var a = o ? Object.getOwnPropertyDescriptor(e, i) : null;
        a && (a.get || a.set) ? Object.defineProperty(r, i, a) : r[i] = e[i];
    }
    r.default = e, n && n.set(e, r);
    return r;
}(require("lodash"));

function u(e) {
    if ("function" != typeof WeakMap) return null;
    var t = new WeakMap(), n = new WeakMap();
    return (u = function(e) {
        return e ? n : t;
    })(e);
}

var i = "([\\u2e80-\\u2eff\\u2f00-\\u2fdf\\u3040-\\u309f\\u30a0-\\u30fa\\u30fc-\\u30ff\\u3100-\\u312f\\u3200-\\u32ff\\u3400-\\u4dbf\\u4e00-\\u9fff\\uf900-\\ufaff][,，、。?？!！;；:：>》」）】@#\\$%~\\^&\\*\\/])";

function a(e) {
    var t = [];
    for (var n in e) Object.prototype.hasOwnProperty.call(e, n) && void 0 !== e[n] && t.push("".concat(n, "=").concat(encodeURIComponent(decodeURIComponent(e[n]))));
    return t.join("&");
}

var c = {
    wechat: {
        label: "发送给朋友",
        openType: "share",
        id: "wechat",
        icon: "/images/icon-share-py@3x.png"
    },
    mudslide: {
        label: "生成分享图",
        id: "mudslide",
        icon: "/images/icon-share-pyq@3x.png"
    },
    image: {
        label: "保存分享图",
        id: "image",
        icon: "/images/icon-share-pyq@3x.png"
    },
    official: {
        label: "嵌入公众号",
        id: "official",
        icon: "/images/icon-share-gzh@3x.png"
    },
    copy: {
        label: "复制链接",
        id: "copy",
        icon: "/images/icon-share-link@3x.png"
    },
    copyDailyLink: {
        label: "复制日报链接",
        id: "copyDailyLink",
        icon: "/images/icon-share-link@3x.png"
    }
};

function f() {
    var e = getCurrentPages();
    return e[e.length - 1];
}

function p(e, t) {
    e = e.split("."), t = t.split(".");
    for (var n = Math.max(e.length, t.length); e.length < n; ) e.push("0");
    for (;t.length < n; ) t.push("0");
    for (var r = 0; r < n; r++) {
        var o = parseInt(e[r]), u = parseInt(t[r]);
        if (o > u) return 1;
        if (o < u) return -1;
    }
    return 0;
}

function s() {
    return (s = t(e().mark(function t(n) {
        var r;
        return e().wrap(function(e) {
            for (;;) switch (e.prev = e.next) {
              case 0:
                return e.prev = 0, e.next = 3, n;

              case 3:
                return r = e.sent, e.abrupt("return", [ null, r ]);

              case 7:
                return e.prev = 7, e.t0 = e.catch(0), e.abrupt("return", [ new Error((null === e.t0 || void 0 === e.t0 ? void 0 : e.t0.message) || (null === e.t0 || void 0 === e.t0 ? void 0 : e.t0.errMsg) || e.t0), null ]);

              case 10:
              case "end":
                return e.stop();
            }
        }, t, null, [ [ 0, 7 ] ]);
    }))).apply(this, arguments);
}