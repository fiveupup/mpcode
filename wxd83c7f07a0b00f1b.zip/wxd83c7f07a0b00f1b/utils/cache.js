function e(e, t) {
    wx.setStorage({
        key: e,
        data: t
    });
}

Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.getGlobalFlag = function(e) {
    e && ("0" === e ? t = e : t += e);
    return t;
}, exports.getStorage = function(e) {
    return wx.getStorageSync(e);
}, exports.getTempStorage = function(e) {
    var t = wx.getStorageSync(e);
    return wx.removeStorage({
        key: e
    }), t;
}, exports.setStorage = function(t, r) {
    e(t, r);
}, exports.setTempStorage = e;

var t = "";