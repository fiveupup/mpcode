Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.default = exports.WxLogger = void 0;

var e = wx.getRealtimeLogManager && wx.getRealtimeLogManager(), o = e;

exports.WxLogger = o;

var r = {
    info: function() {
        var o;
        (o = console).log.apply(o, arguments), e && e.info.apply(e, arguments);
    },
    log: function() {
        var o;
        (o = console).log.apply(o, arguments), e && e.info.apply(e, arguments);
    },
    error: function() {
        var o;
        (o = console).error.apply(o, arguments), e && e.error.apply(e, arguments);
    }
};

exports.default = r;