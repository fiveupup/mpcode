Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.default = void 0;

var e, t = require("../@babel/runtime/helpers/classCallCheck"), r = require("../@babel/runtime/helpers/createClass"), a = (e = require("dayjs")) && e.__esModule ? e : {
    default: e
};

a.default.locale("zh-cn");

var n = function() {
    for (var e, t = [ "今天", "昨天" ], r = 2, n = (0, a.default)(); r <= 6; r++) e = (0, 
    a.default)().subtract(r, "day"), n.isSame(e, "week") ? t.push(e.format("ddd")) : t.push("上" + e.format("ddd"));
    return t.push("更早"), t;
}();

function u(e) {
    var t = (0, a.default)().endOf("day");
    return Math.floor((t - (0, a.default)(e)) / 864e5);
}

var s = function() {
    function e() {
        t(this, e), this.lastIndex = 0;
    }
    return r(e, [ {
        key: "processStock",
        value: function(e) {
            var t = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : [];
            return e.sort(function(e, t) {
                return t.genYear - e.genYear;
            }), e.forEach(function(e) {
                var r = "".concat(e.genYear, " 年"), a = t.find(function(e) {
                    return e.name === r;
                });
                a ? a.list.push(e) : t.push({
                    name: r,
                    list: [ e ]
                });
            }), t;
        }
    }, {
        key: "processTopics",
        value: function(e) {
            var t = this, r = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : [], a = [];
            n.forEach(function(e, t) {
                a[t] || (a[t] = []);
            }), r.forEach(function(e, t) {
                a[t] = e.list;
            }), e.forEach(function(e) {
                if ("topic" !== e.type) {
                    var r = t.lastIndex || 0, s = n[r];
                    if (s) e.name = s, a[r] && a[r].push(e); else {
                        var i = a[a.length - 1];
                        i && i.push(e);
                    }
                } else {
                    var l = u(e.publishDate);
                    if (t.lastIndex = l, e.up && (l = 0), l > -1) {
                        var o = n[l];
                        if (o) e.name = o, a[l] && a[l].push(e); else a[a.length - 1].push(e);
                    }
                }
            });
            var s = [];
            return a.forEach(function(e, t) {
                var r = {
                    name: "",
                    list: e,
                    isFresh: t < 2,
                    isEmpty: 0 === e.length
                };
                r.name = n[t], s.push(r);
            }), s;
        }
    } ]), e;
}();

exports.default = s;