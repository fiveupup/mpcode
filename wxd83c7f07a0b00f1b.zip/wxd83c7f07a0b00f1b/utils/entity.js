Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.navigatoEntity = function(e) {
    wx.navigateTo({
        url: "/pages/pro/entity_topics?".concat((0, t.queryString)(e))
    });
};

var t = require("./tools");