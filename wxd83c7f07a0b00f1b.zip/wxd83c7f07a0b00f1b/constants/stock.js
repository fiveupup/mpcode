Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.STOCK_FILE_TYPE = void 0;

var e = function(e) {
    return e[e.FS = 1] = "FS", e[e.IPO = 2] = "IPO", e;
}({});

exports.STOCK_FILE_TYPE = e;