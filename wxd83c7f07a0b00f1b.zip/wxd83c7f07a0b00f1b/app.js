var e = require("@babel/runtime/helpers/regeneratorRuntime"), t = require("@babel/runtime/helpers/asyncToGenerator");

require("./libs/lodash-inject");

var r = S(require("./config"));

require("./libs/moment-zh-cn");

var n = S(require("./store/app")), a = w(require("./utils/lodash")), i = w(require("./utils/logger")), s = w(require("./service/user")), o = w(require("./service/app")), u = S(require("./service/ad")), c = require("./service/analyse"), l = require("./utils/mina"), f = require("./utils/tools"), g = require("./service/pro"), p = require("./service/subscribe"), d = require("./libs/lru"), b = require("./libs/calendar"), h = S(require("dayjs")), m = require("@mina-modules/mina-sentry"), v = S(require("@mina-modules/load-file"));

function x(e) {
    if ("function" != typeof WeakMap) return null;
    var t = new WeakMap(), r = new WeakMap();
    return (x = function(e) {
        return e ? r : t;
    })(e);
}

function w(e, t) {
    if (!t && e && e.__esModule) return e;
    if (null === e || "object" != typeof e && "function" != typeof e) return {
        default: e
    };
    var r = x(t);
    if (r && r.has(e)) return r.get(e);
    var n = {}, a = Object.defineProperty && Object.getOwnPropertyDescriptor;
    for (var i in e) if ("default" !== i && Object.prototype.hasOwnProperty.call(e, i)) {
        var s = a ? Object.getOwnPropertyDescriptor(e, i) : null;
        s && (s.get || s.set) ? Object.defineProperty(n, i, s) : n[i] = e[i];
    }
    return n.default = e, r && r.set(e, n), n;
}

function S(e) {
    return e && e.__esModule ? e : {
        default: e
    };
}

var k = new b.Calendar({
    processCell: function(e) {
        return e.isHistory = (0, h.default)(e.date).isBefore((0, h.default)()), e;
    }
});

k.loadMoreCalDataNext(12);

var y = new d.LRUMap(100), D = wx.getStorageSync("temp") || {};

App({
    globalData: {
        enableShowManageSubscriptionTips: !0,
        inited: !1,
        launchOptions: {},
        showOptions: {},
        userInfo: {},
        ads: [],
        temp: D,
        isFirstVisit: !1,
        calendar: k
    },
    injectConfig: {
        skip_track_methods: [ "isFirstVisit" ]
    },
    cache: y,
    _files: {},
    tempFile: function(e, t) {
        var r = Object.keys(this._files);
        if (t) {
            if (200 !== t.statusCode) return;
            return r.length > 8 && delete this._files[r[0]], void (this._files[e] = t);
        }
        var n = this._files[e];
        if (n) return new Promise(function(e) {
            wx.getFileInfo({
                filePath: n.tempFilePath,
                success: function(t) {
                    t.size ? (console.log("get temp file success", n), e(n)) : e(null);
                },
                fail: function() {
                    e(null);
                }
            });
        });
    },
    onPageNotFound: function(e) {
        var t = e.path, r = e.query;
        "/" !== t[0] && (t = "/" + t), wx.redirectTo({
            url: "".concat(t, "?").concat((0, f.queryString)(r))
        });
    },
    onError: function(e) {
        (0, m.error)(e);
    },
    onUnhandledRejection: function(e) {
        var t = e.reason;
        (0, m.error)(t);
    },
    onLaunch: function(e) {
        console.log("onLaunch", e), (0, m.init)(r.default.dsn), this.globalData.launchOptions = e, 
        this.globalData.isFirstVisit = !this.globalData.temp.visited, this.temp("visited", !0), 
        wx.cloud.init(), (0, v.default)({
            url: "https://auction-cdn.nocode.com/nc-symbol.ttf?t=9",
            fontFamily: "nc-symbol",
            success: i.default.log,
            fail: i.default.log
        }), (0, v.default)({
            url: "https://readhub-oss.nocode.com/font/DINCond-Medium.ttf",
            fontFamily: "DINCond",
            success: i.default.log,
            fail: i.default.log
        }), wx.getSystemInfo({
            success: i.default.info
        });
    },
    onShow: function(e) {
        console.log("onShow", e), this.globalData.showOptions = e, this.globalData.inited && "system" === n.default.themeMode && n.default.changeThemeMode("system"), 
        this.globalData.inited && (this.checkDailySubscribe(), this.getUserProfile(), this.getUserSubscription(), 
        this.fetchSubscribeTemplate(), this.getMinaSetting());
    },
    getMinaSetting: function() {
        return t(e().mark(function t() {
            var r;
            return e().wrap(function(e) {
                for (;;) switch (e.prev = e.next) {
                  case 0:
                    return e.prev = 0, e.next = 3, new Promise(function(e, t) {
                        wx.getSetting({
                            withSubscriptions: !0,
                            success: e,
                            fail: t
                        });
                    });

                  case 3:
                    if (!(r = e.sent).authSetting) {
                        e.next = 7;
                        break;
                    }
                    return n.default.changeMinaSetting(r), e.abrupt("return", r);

                  case 7:
                    return e.abrupt("return", n.default.minaSetting);

                  case 10:
                    return e.prev = 10, e.t0 = e.catch(0), console.error(e.t0), e.abrupt("return", n.default.minaSetting);

                  case 14:
                  case "end":
                    return e.stop();
                }
            }, t, null, [ [ 0, 10 ] ]);
        }))();
    },
    isFirstVisit: function() {
        return this.globalData.isFirstVisit;
    },
    updateUserInfo: function(i) {
        var o = this;
        return t(e().mark(function t() {
            var u, c;
            return e().wrap(function(e) {
                for (;;) switch (e.prev = e.next) {
                  case 0:
                    return e.next = 2, s.updateWechatUserInfo(i);

                  case 2:
                    if (u = e.sent, !(c = a.get(u, "data.items[0]"))) {
                        e.next = 9;
                        break;
                    }
                    return o.globalData.userInfo = Object.assign({}, o.globalData.userInfo, c), e.next = 8, 
                    wx.setStorage({
                        key: r.default.USER_KEY,
                        data: o.globalData.userInfo
                    });

                  case 8:
                    n.default.changeUserInfo(o.globalData.userInfo);

                  case 9:
                  case "end":
                    return e.stop();
                }
            }, t);
        }))();
    },
    appLogin: function(a) {
        var s = this;
        return t(e().mark(function t() {
            var u, c, l, f, g;
            return e().wrap(function(e) {
                for (;;) switch (e.prev = e.next) {
                  case 0:
                    return e.next = 2, o.needLogin();

                  case 2:
                    if (u = e.sent, !a && !u) {
                        e.next = 21;
                        break;
                    }
                    return i.default.info("wechat login"), e.next = 7, new Promise(function(e, t) {
                        wx.login({
                            success: e,
                            fail: t
                        });
                    });

                  case 7:
                    return c = e.sent, i.default.info("wxloginInfo", c), l = c.code, e.next = 12, o.codeLogin(l);

                  case 12:
                    return (f = e.sent)._updateTime = Date.now(), s.globalData.userInfo = f, i.default.log("loginInfo", f), 
                    n.default.changeUserInfo(f), e.next = 19, wx.setStorage({
                        key: r.default.USER_KEY,
                        data: f
                    });

                  case 19:
                    e.next = 32;
                    break;

                  case 21:
                    return e.prev = 21, e.next = 24, wx.getStorage({
                        key: r.default.USER_KEY
                    });

                  case 24:
                    (g = e.sent.data) && (s.globalData.userInfo = g), i.default.log("loginInfo", g), 
                    e.next = 32;
                    break;

                  case 29:
                    e.prev = 29, e.t0 = e.catch(21), console.error(e.t0);

                  case 32:
                    i.default.log("app login success");

                  case 33:
                  case "end":
                    return e.stop();
                }
            }, t, null, [ [ 21, 29 ] ]);
        }))();
    },
    fetchSubscribeTemplate: function() {
        return t(e().mark(function t() {
            var r;
            return e().wrap(function(e) {
                for (;;) switch (e.prev = e.next) {
                  case 0:
                    return e.next = 2, (0, p.fetchSubscribeTemplates)();

                  case 2:
                    return r = e.sent.data.items, n.default.changeTemplates(r), e.abrupt("return", r);

                  case 5:
                  case "end":
                    return e.stop();
                }
            }, t);
        }))();
    },
    getSubscribeTemplatesByName: function() {
        var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : [], t = [];
        return e.forEach(function(e) {
            var r = n.default.templates.find(function(t) {
                return t.typeName === e;
            });
            r ? t.push(r) : console.warn("template ".concat(e, " not found"));
        }), t;
    },
    checkDailySubscribe: function() {
        var r = this;
        return t(e().mark(function a() {
            var o;
            return e().wrap(function(a) {
                for (;;) switch (a.prev = a.next) {
                  case 0:
                    if (a.prev = 0, !(0, l.isSinglePageMode)()) {
                        a.next = 4;
                        break;
                    }
                    return console.log("isSinglePageMode skip"), a.abrupt("return");

                  case 4:
                    return console.log("checkSubscribe"), a.next = 7, s.checkSubscribe();

                  case 7:
                    o = a.sent, n.default.subscribeState = o, r.globalData.subscribeState = o, wx.getStorage({
                        key: "subDailyIfOfficialSubed",
                        success: function() {
                            var r = t(e().mark(function t(r) {
                                return e().wrap(function(e) {
                                    for (;;) switch (e.prev = e.next) {
                                      case 0:
                                        if (console.log("subDailyIfOfficialSubed", r), wx.removeStorage({
                                            key: "subDailyIfOfficialSubed"
                                        }), !r.data) {
                                            e.next = 7;
                                            break;
                                        }
                                        return e.next = 6, s.subscribe(1);

                                      case 6:
                                        n.default.subscribeState.daily = !0;

                                      case 7:
                                      case "end":
                                        return e.stop();
                                    }
                                }, t);
                            }));
                            return function(e) {
                                return r.apply(this, arguments);
                            };
                        }()
                    }), a.next = 16;
                    break;

                  case 13:
                    a.prev = 13, a.t0 = a.catch(0), i.default.error(a.t0);

                  case 16:
                  case "end":
                    return a.stop();
                }
            }, a, null, [ [ 0, 13 ] ]);
        }))();
    },
    getUserProfile: function() {
        var a = this;
        return t(e().mark(function t() {
            var i;
            return e().wrap(function(e) {
                for (;;) switch (e.prev = e.next) {
                  case 0:
                    return e.next = 2, s.getUserProfile();

                  case 2:
                    return (i = e.sent).isVip = !!i.isVip, i.nick_name && (i.nickname = i.nick_name), 
                    a.globalData.userInfo = Object.assign({}, a.globalData.userInfo, i), e.next = 8, 
                    wx.setStorage({
                        key: r.default.USER_KEY,
                        data: a.globalData.userInfo
                    });

                  case 8:
                    n.default.changeUserInfo(a.globalData.userInfo), (i.user_id || i.uid) && (0, c.setUid)(i.user_id || i.uid);

                  case 10:
                  case "end":
                    return e.stop();
                }
            }, t);
        }))();
    },
    temp: function(e, t) {
        if (void 0 === t) return this.globalData.temp[e];
        this.globalData.temp[e] = t, wx.setStorage({
            key: "temp",
            data: this.globalData.temp
        });
    },
    getUserSubscription: function() {
        return t(e().mark(function t() {
            var r;
            return e().wrap(function(e) {
                for (;;) switch (e.prev = e.next) {
                  case 0:
                    if (e.prev = 0, !(0, l.isSinglePageMode)()) {
                        e.next = 4;
                        break;
                    }
                    return console.log("isSinglePageMode skip"), e.abrupt("return");

                  case 4:
                    return e.next = 6, (0, g.getUserSubscription)();

                  case 6:
                    r = e.sent.data.items, n.default.pro = {
                        subList: r
                    }, e.next = 13;
                    break;

                  case 10:
                    e.prev = 10, e.t0 = e.catch(0), console.error(e.t0);

                  case 13:
                  case "end":
                    return e.stop();
                }
            }, t, null, [ [ 0, 10 ] ]);
        }))();
    },
    logPageInfo: function() {
        try {
            var e = getCurrentPages(), t = e[e.length - 1];
            (0, l.isWechatCrawler)() && (console.log("Wechat Crawler visit"), i.WxLogger && t && i.WxLogger.setFilterMsg("wx_crawler: ".concat(t.route, "?").concat((0, 
            f.queryString)(t.options))), wx.reportMonitor && wx.reportMonitor("0", 1), t && i.default.log("current page: ".concat(t.route, "?").concat((0, 
            f.queryString)(t.options))));
        } catch (e) {
            console.error(e);
        }
    },
    fetchAds: function() {
        return t(e().mark(function t() {
            return e().wrap(function(e) {
                for (;;) switch (e.prev = e.next) {
                  case 0:
                    return e.prev = 0, e.next = 3, u.default.getAds();

                  case 3:
                    e.next = 8;
                    break;

                  case 5:
                    e.prev = 5, e.t0 = e.catch(0), console.error(e.t0);

                  case 8:
                  case "end":
                    return e.stop();
                }
            }, t, null, [ [ 0, 5 ] ]);
        }))();
    },
    asyncInitAfterLogin: function() {
        var r = this;
        return t(e().mark(function t() {
            return e().wrap(function(e) {
                for (;;) switch (e.prev = e.next) {
                  case 0:
                    return e.next = 2, Promise.all([ r.getUserProfile(!0), r.fetchAds(), r.fetchSubscribeTemplate() ]);

                  case 2:
                    return e.next = 4, r.getMinaSetting();

                  case 4:
                    return e.next = 6, r.checkDailySubscribe();

                  case 6:
                    return e.next = 8, r.getUserSubscription();

                  case 8:
                    r.globalData.inited = !0, n.default.changeInit(!0), i.default.log("app inited");

                  case 11:
                  case "end":
                    return e.stop();
                }
            }, t);
        }))();
    },
    appInit: function() {
        var a = this;
        return t(e().mark(function t() {
            var s;
            return e().wrap(function(e) {
                for (;;) switch (e.prev = e.next) {
                  case 0:
                    if (i.default.info("app start init", (0, l.isSinglePageMode)()), a.logPageInfo(), 
                    !(a.globalData.inited && a.globalData.userInfo && a.globalData.userInfo.user_id)) {
                        e.next = 4;
                        break;
                    }
                    return e.abrupt("return", !0);

                  case 4:
                    if ((0, l.isWechatCrawler)()) {
                        e.next = 16;
                        break;
                    }
                    return e.prev = 5, e.next = 8, wx.getStorage({
                        key: r.default.APP_SETTING_KEY
                    });

                  case 8:
                    s = e.sent.data, i.default.info("appSetting", s), s && (Object.assign(n.default, s), 
                    s.themeMode && n.default.changeThemeMode(s.themeMode)), e.next = 16;
                    break;

                  case 13:
                    e.prev = 13, e.t0 = e.catch(5), n.default.changeThemeMode("system");

                  case 16:
                    return e.prev = 16, e.next = 19, a.appLogin();

                  case 19:
                    e.next = 24;
                    break;

                  case 21:
                    e.prev = 21, e.t1 = e.catch(16), i.default.error(e.t1);

                  case 24:
                    a.asyncInitAfterLogin();

                  case 25:
                  case "end":
                    return e.stop();
                }
            }, t, null, [ [ 5, 13 ], [ 16, 21 ] ]);
        }))();
    }
});