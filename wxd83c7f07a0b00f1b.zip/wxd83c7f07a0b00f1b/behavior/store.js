Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.default = function(e) {
    return Behavior({
        behaviors: [ r.storeBindingsBehavior ],
        storeBindings: {
            store: i.default,
            fields: [].concat(e)
        }
    });
};

var e, r = require("mobx-miniprogram-bindings"), i = (e = require("../store/app")) && e.__esModule ? e : {
    default: e
};