Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.default = void 0;

var e, t = require("mobx-miniprogram-bindings"), i = (e = require("../store/app")) && e.__esModule ? e : {
    default: e
};

var r = Behavior({
    lifetimes: {
        created: function() {
            this.__themeBehavior__ = (0, t.createStoreBindings)(this, {
                store: i.default,
                fields: [ "theme" ]
            });
        },
        detached: function() {
            this.__themeBehavior__.destroyStoreBindings();
        }
    }
});

exports.default = r;