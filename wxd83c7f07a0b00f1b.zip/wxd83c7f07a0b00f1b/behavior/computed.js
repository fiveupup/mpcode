var t = require("../@babel/runtime/helpers/typeof");

module.exports = function(e) {
    function o(t) {
        if (r[t]) return r[t].exports;
        var n = r[t] = {
            i: t,
            l: !1,
            exports: {}
        };
        return e[t].call(n.exports, n, n.exports, o), n.l = !0, n.exports;
    }
    var r = {};
    return o.m = e, o.c = r, o.d = function(t, e, r) {
        o.o(t, e) || Object.defineProperty(t, e, {
            enumerable: !0,
            get: r
        });
    }, o.r = function(t) {
        "undefined" != typeof Symbol && Symbol.toStringTag && Object.defineProperty(t, Symbol.toStringTag, {
            value: "Module"
        }), Object.defineProperty(t, "__esModule", {
            value: !0
        });
    }, o.t = function(e, r) {
        if (1 & r && (e = o(e)), 8 & r) return e;
        if (4 & r && "object" == t(e) && e && e.__esModule) return e;
        var n = Object.create(null);
        if (o.r(n), Object.defineProperty(n, "default", {
            enumerable: !0,
            value: e
        }), 2 & r && "string" != typeof e) for (var i in e) o.d(n, i, function(t) {
            return e[t];
        }.bind(null, i));
        return n;
    }, o.n = function(t) {
        var e = t && t.__esModule ? function() {
            return t.default;
        } : function() {
            return t;
        };
        return o.d(e, "a", e), e;
    }, o.o = function(t, e) {
        return Object.prototype.hasOwnProperty.call(t, e);
    }, o.p = "", o(o.s = 0);
}([ function(e, o, r) {
    var n = "function" == typeof Symbol && "symbol" == t(Symbol.iterator) ? function(e) {
        return t(e);
    } : function(e) {
        return e && "function" == typeof Symbol && e.constructor === Symbol && e !== Symbol.prototype ? "symbol" : t(e);
    };
    e.exports = Behavior({
        lifetimes: {
            created: function() {
                this._computedCache = {}, this._originalSetData = this.setData, this.setData = this._setData, 
                this._doingSetData = !1, this._doingSetProps = !1;
            }
        },
        definitionFilter: function(t) {
            var e = t.computed || {}, o = Object.keys(e), r = t.properties || {}, i = Object.keys(r), a = function(t) {
                for (var r = {}, n = t._computedCache || t.data, i = 0, a = o.length; i < a; i++) {
                    var s = o[i], l = e[s];
                    if ("function" == typeof l) {
                        var u = l.call(t);
                        n[s] !== u && (r[s] = u, n[s] = u);
                    }
                }
                return r;
            };
            !function() {
                t.data = t.data || {};
                var e = t.data, o = Object.prototype.hasOwnProperty;
                i.length && Object.keys(r).forEach(function(t) {
                    var i = r[t], s = void 0;
                    null === i || i === Number || i === String || i === Boolean || i === Object || i === Array ? r[t] = {
                        type: i
                    } : "object" === (void 0 === i ? "undefined" : n(i)) && (o.call(i, "value") && (e[t] = i.value), 
                    o.call(i, "observer") && "function" == typeof i.observer && (s = i.observer)), r[t].observer = function() {
                        for (var t = this._originalSetData, e = arguments.length, o = Array(e), r = 0; r < e; r++) o[r] = arguments[r];
                        if (this._doingSetProps) s && s.apply(this, o); else if (this._doingSetData) console.warn("can't call setData in computed getter function!"); else {
                            this._doingSetData = !0;
                            var n = a(this);
                            t.call(this, n), this._doingSetData = !1, s && s.apply(this, o);
                        }
                    };
                }), a(t);
            }(), t.methods = t.methods || {}, t.methods._setData = function(t, o) {
                var r = this._originalSetData;
                if (this._doingSetData) console.warn("can't call setData in computed getter function!"); else {
                    this._doingSetData = !0;
                    for (var n = Object.keys(t), s = 0, l = n.length; s < l; s++) {
                        var u = n[s];
                        e[u] && delete t[u], !this._doingSetProps && i.indexOf(u) >= 0 && (this._doingSetProps = !0);
                    }
                    r.call(this, t, o);
                    var c = a(this);
                    r.call(this, c), this._doingSetData = !1, this._doingSetProps = !1;
                }
            };
        }
    });
} ]);