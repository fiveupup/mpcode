var e, t = require("../@babel/runtime/helpers/createForOfIteratorHelper"), i = require("../@babel/runtime/helpers/regeneratorRuntime"), n = require("../@babel/runtime/helpers/asyncToGenerator"), r = require("mobx-miniprogram-bindings"), a = T(require("../utils/logger")), o = require("../utils/functional"), s = require("../utils/tools"), c = require("../utils/mina"), u = require("../utils/format"), l = require("../utils/date"), p = S(require("../utils/readHistory")), d = S(require("lodash")), h = require("../service/user"), f = require("../service/mina"), g = require("../service/analyse"), m = require("../service/topic"), w = T(require("../config")), b = T(require("../behavior/computed")), v = T(require("../store/app")), y = S(require("../service/pro"));

function x(e) {
    if ("function" != typeof WeakMap) return null;
    var t = new WeakMap(), i = new WeakMap();
    return (x = function(e) {
        return e ? i : t;
    })(e);
}

function S(e, t) {
    if (!t && e && e.__esModule) return e;
    if (null === e || "object" != typeof e && "function" != typeof e) return {
        default: e
    };
    var i = x(t);
    if (i && i.has(e)) return i.get(e);
    var n = {}, r = Object.defineProperty && Object.getOwnPropertyDescriptor;
    for (var a in e) if ("default" !== a && Object.prototype.hasOwnProperty.call(e, a)) {
        var o = r ? Object.getOwnPropertyDescriptor(e, a) : null;
        o && (o.get || o.set) ? Object.defineProperty(n, a, o) : n[a] = e[a];
    }
    return n.default = e, i && i.set(e, n), n;
}

function T(e) {
    return e && e.__esModule ? e : {
        default: e
    };
}

Page({
    data: {
        stockEntity: {},
        stockFiles: [],
        isEntityStockFileVisible: !1,
        inited: !1,
        error: "",
        containerStyle: "",
        options: {},
        navigationBarTitleText: "话题详情",
        stitle: "话题详情",
        topic: null,
        newsTitleStyle: "",
        showAllNews: !1,
        contentStyle: "",
        actionsheetList: (0, s.getActionSheet)([ "wechat", "mudslide", "official", "copy" ]),
        topicEditShow: !1,
        initTheme: v.default.theme,
        tempLoading: !0,
        entitys: [],
        topicDate: "",
        showedNews: [],
        entityBoomState: "",
        reachBottom: !1,
        wordCount: 0
    },
    behaviors: [ b.default ],
    computed: {
        timelineTitle: function() {
            var e = this.data.topic;
            return e && d.isEmpty(d.get(e.timeline, "commonEntities")) ? "相关事件" : "事件追踪";
        },
        subItem: function() {
            var e, t = this, i = d.get(this.data.pro, "subList", []).find(function(e) {
                var i;
                return e.key === (null === (i = t.data.topic) || void 0 === i ? void 0 : i.timelineId) && e.type === y.SUB_TYPES.timeline;
            });
            return {
                key: null === (e = this.data.topic) || void 0 === e ? void 0 : e.id,
                type: y.SUB_TYPES.timeline,
                content: d.get(this.data.topic, "originTitle", ""),
                subed: !!i,
                uid: null == i ? void 0 : i.uid
            };
        }
    },
    showFeedback: function() {
        wx.previewImage({
            urls: [ "https://resource.nocode.com/readhub/assistant.png" ]
        });
    },
    entitySubscribe: (0, o.singleExec)(n(i().mark(function e() {
        var t, n;
        return i().wrap(function(e) {
            for (;;) switch (e.prev = e.next) {
              case 0:
                if ((0, g.report)("subscribebar_event"), (t = this.data.subItem).subed) {
                    e.next = 19;
                    break;
                }
                if (!this.selectComponent(".loginDialog").needLogin()) {
                    e.next = 5;
                    break;
                }
                return e.abrupt("return", this.selectComponent(".loginDialog").show());

              case 5:
                if (v.default.userInfo.isVip) {
                    e.next = 7;
                    break;
                }
                return e.abrupt("return", this.selectComponent(".joinProDialog").show(t));

              case 7:
                return wx.showLoading(), e.next = 10, y.subscribeEntity(t);

              case 10:
                if ((n = e.sent).subscription) {
                    e.next = 13;
                    break;
                }
                throw new Error("订阅失败");

              case 13:
                d.assign(t, n.subscription), v.default.addProSub(t), wx.hideLoading(), this.selectComponent("#subscribeMessage").authAfterSubscribe(), 
                e.next = 22;
                break;

              case 19:
                if (v.default.userInfo.isVip) {
                    e.next = 21;
                    break;
                }
                return e.abrupt("return", this.selectComponent(".joinProDialog").show());

              case 21:
                wx.navigateTo({
                    url: "/pages/pro/subscription_manage"
                });

              case 22:
              case "end":
                return e.stop();
            }
        }, e, this);
    })), {
        onError: function(e) {
            e.message.indexOf("32") > -1 && setTimeout(function() {
                wx.navigateTo({
                    url: "/pages/pro/subscription_manage"
                });
            }, 250);
        }
    }),
    hideEntityStockFile: function() {
        this.setData({
            isEntityStockFileVisible: !1
        });
    },
    getShowedNews: function() {
        var e = this.data, t = e.topic, i = e.showAllNews;
        return t && t.mergedNews ? i ? t.mergedNews : t.mergedNews.slice(0, 3) : [];
    },
    onNavTopicEvents: function() {
        getApp()._tempTopic = this.data.topic, (0, g.report)("timeline_all");
    },
    onServiceFollowHide: function() {},
    goToEdit: function() {
        var e = this.data.topic, t = "https://dataengine.nocode.com/medical_base/kg/".concat(e.itemId);
        wx.navigateTo({
            url: "/pages/webview?url=".concat(encodeURIComponent(t))
        });
    },
    subscribe: (0, o.singleExec)(n(i().mark(function e() {
        var t, n;
        return i().wrap(function(e) {
            for (;;) switch (e.prev = e.next) {
              case 0:
                if (!this.selectComponent("#layout").getLoginManager().needLogin()) {
                    e.next = 3;
                    break;
                }
                return this.selectComponent("#layout").getLoginManager().show(), e.abrupt("return", !1);

              case 3:
                if (e.prev = 3, !(t = this.data.subscribed)) {
                    e.next = 11;
                    break;
                }
                return e.next = 8, (0, h.unsubscribe)(1);

              case 8:
                n = e.sent, e.next = 14;
                break;

              case 11:
                return e.next = 13, (0, h.subscribe)(1);

              case 13:
                n = e.sent;

              case 14:
                if (!n.error) {
                    e.next = 16;
                    break;
                }
                return e.abrupt("return", wx.showToast({
                    title: n.error.message,
                    icon: "none"
                }));

              case 16:
                return t ? wx.showToast({
                    title: "已取消订阅",
                    icon: "none"
                }) : wx.showToast({
                    title: "已订阅，将于明早发送",
                    icon: "none"
                }), e.abrupt("return", !0);

              case 20:
                e.prev = 20, e.t0 = e.catch(3), a.default.error(e.t0);

              case 23:
              case "end":
                return e.stop();
            }
        }, e, this, [ [ 3, 20 ] ]);
    }))),
    goToTopic: function(e) {
        (0, g.report)("detal_list_topic"), this.selectComponent("#subscribeMessage").auth([ "NEWS_UPDATE", "DAILY", "RENEW" ], !0);
        var t = e.currentTarget.dataset.id;
        (0, s.navigateTo)({
            url: "/pages/detail?id=".concat(t)
        });
    },
    chooseActionSheet: function(e) {
        var t = e.detail.item, i = this.data.topic, n = i.id;
        "mudslide" === t.id ? this.genShareImage(n) : "copy" === t.id ? this.setClipboard(n) : "timeline" === t.id ? this.showTimelineTip() : "official" === t.id && (0, 
        f.toShareTopicInOfficial)(n, i);
    },
    share: function() {
        (0, g.report)("detail_share"), this.selectComponent(".actionsheet").show();
    },
    collectTemplete: function() {
        (0, g.report)("detal_list_news"), this.selectComponent("#subscribeMessage").auth([ "NEWS_UPDATE", "DAILY", "RENEW" ], !0);
    },
    onTapTag: function() {
        (0, g.report)("tag_click");
    },
    onTapQrcode: function() {
        (0, g.report)("qr_view");
    },
    toggleNews: function() {
        var e = this;
        this.setData({
            showAllNews: !0
        }, function() {
            e.setData({
                showedNews: e.getShowedNews()
            });
        });
    },
    showTimelineTip: function() {
        this.selectComponent("#timeShareTip").show();
    },
    submitCrawlerPages: function() {
        try {
            if ((0, c.isWechatCrawler)()) return;
            var e = this.data.topic;
            if (!e) return;
            var t = [ {
                path: "pages/detail",
                query: "id=".concat(e.id)
            } ];
            (e.newsArray || []).forEach(function(e) {
                e.hasInstantView && t.push({
                    path: "pages/news/detail",
                    query: "id=".concat(e.id, "&type=n")
                });
            });
        } catch (e) {
            console.error(e);
        }
    },
    genShareImage: function() {
        var e = this;
        return n(i().mark(function t() {
            var n;
            return i().wrap(function(t) {
                for (;;) switch (t.prev = t.next) {
                  case 0:
                    return t.prev = 0, (0, g.report)("share_circle"), t.next = 4, (0, m.fetchMinaCode)(e.data.topic.id);

                  case 4:
                    n = t.sent, wx.navigateTo({
                        url: "/pages/tools/nishiliu/custom?".concat((0, s.queryStringWithoutDecode)({
                            title: e.data.topic.title,
                            name: "Readhub",
                            qrcode: n
                        }))
                    }), t.next = 11;
                    break;

                  case 8:
                    t.prev = 8, t.t0 = t.catch(0), a.default.log(t.t0);

                  case 11:
                  case "end":
                    return t.stop();
                }
            }, t, null, [ [ 0, 8 ] ]);
        }))();
    },
    setClipboard: function() {
        var e = this.data, t = e.options, i = e.topic;
        wx.setClipboardData({
            data: "https://readhub.cn/topic/".concat(t.id, "?from=mp"),
            success: function() {
                (0, g.report)("click_url", {
                    title: i.title
                }), wx.showToast({
                    title: "链接已复制",
                    icon: "none",
                    duration: 500
                });
            }
        });
    },
    onShareAppMessage: function() {
        var e = this.data.topic;
        if (e) {
            var t = "".concat(w.default.API_HOST, "/topic/").concat(e.id, "/cover.png?t=").concat(w.default.VERSION);
            return {
                title: " ",
                path: "/pages/detail?id=".concat(e.id),
                imageUrl: t,
                success: function() {
                    a.default.log("share success");
                },
                error: function() {
                    a.default.log("share error");
                }
            };
        }
    },
    onShareTimeline: function() {
        return {
            title: this.data.topic.title,
            query: "id=".concat(this.data.topic.id)
        };
    },
    reload: function() {
        var e = this;
        return n(i().mark(function t() {
            return i().wrap(function(t) {
                for (;;) switch (t.prev = t.next) {
                  case 0:
                    return e.setData({
                        inited: !1
                    }), t.prev = 1, t.next = 4, e.refreshPage();

                  case 4:
                    t.next = 9;
                    break;

                  case 6:
                    t.prev = 6, t.t0 = t.catch(1), e.setData({
                        error: t.t0.message
                    });

                  case 9:
                    return t.prev = 9, e.setData({
                        inited: !0
                    }), t.finish(9);

                  case 12:
                  case "end":
                    return t.stop();
                }
            }, t, null, [ [ 1, 6, 9, 12 ] ]);
        }))();
    },
    onEntityBoomEnterIn: function() {
        this.setData({
            entityBoomState: "enter-in"
        });
    },
    onEntityBoomLeaveOut: function() {
        this.setData({
            entityBoomState: "leave-out"
        });
    },
    onReachBottom: function() {
        this.setData({
            reachBottom: !0
        });
    },
    onPageAnimationEnd: function() {
        console.log("onPageAnimationEnd", this.data.entityBoomState), "leave-out" === this.data.entityBoomState && this.setData({
            entityBoomState: ""
        });
    },
    onEntityTap: function(e) {
        var i = e.detail.key;
        if ((0, g.report)("abstract_blue"), i) {
            (0, g.report)("tap_entity", {
                value: i
            });
            var n = function(e, i) {
                var n, r = t(e);
                try {
                    for (r.s(); !(n = r.n()).done; ) {
                        var a = n.value;
                        if ((0, u.ncFormat)(a.entityName) === i) return a.entityId;
                    }
                } catch (e) {
                    r.e(e);
                } finally {
                    r.f();
                }
                return "";
            }(this.data.topic.entityTopics, i);
            wx.navigateTo({
                url: "/pages/pro/entity_topics?id=".concat(n)
            });
        }
    },
    refreshPage: (e = n(i().mark(function e() {
        var t, n, r, a, o, s, p, d, f = this;
        return i().wrap(function(e) {
            for (;;) switch (e.prev = e.next) {
              case 0:
                return e.next = 2, getApp().appInit();

              case 2:
                return t = this.data.options, n = (0, h.isManager)(), e.next = 6, (0, m.getTopic)(t.id);

              case 6:
                r = e.sent, a = (r.entityTopics || []).filter(function(e) {
                    return e.hasStock;
                }).map(function(e) {
                    return (0, u.ncFormat)(e.entityName);
                }), this.setData({
                    wordCount: (r.summary + r.title).length,
                    topicDate: (0, l.relativeDatetime)(r.publishDate),
                    topic: r,
                    topicEditShow: n,
                    error: "",
                    stitle: r.title,
                    entitys: a.sort(function(e, t) {
                        return t.length - e.length;
                    })
                }, function() {
                    f.setData({
                        showedNews: f.getShowedNews()
                    });
                }), wx.setNavigationBarTitle({
                    title: r.title
                }), o = (0, c.getSystemInfo)(), s = "width: ".concat(o.windowWidth - 64, "px;"), 
                p = o.windowHeight - 64, o.statusBarHeight && (p = o.windowHeight - 44 - o.statusBarHeight), 
                d = "min-height: ".concat(p, "px;"), this.setData({
                    newsTitleStyle: s,
                    contentStyle: d
                });

              case 16:
              case "end":
                return e.stop();
            }
        }, e, this);
    })), function() {
        return e.apply(this, arguments);
    }),
    onShow: function() {
        var e = this;
        return n(i().mark(function t() {
            return i().wrap(function(t) {
                for (;;) switch (t.prev = t.next) {
                  case 0:
                    if (e.data.inited) {
                        t.next = 2;
                        break;
                    }
                    return t.abrupt("return");

                  case 2:
                    return t.prev = 2, t.next = 5, e.refreshPage();

                  case 5:
                    (0, c.setBackgroundColor)(v.default.theme, {
                        dark: "#191919",
                        light: "#ffffff"
                    }), t.next = 11;
                    break;

                  case 8:
                    t.prev = 8, t.t0 = t.catch(2), a.default.error(t.t0);

                  case 11:
                  case "end":
                    return t.stop();
                }
            }, t, null, [ [ 2, 8 ] ]);
        }))();
    },
    checkScrollToTimeline: function() {
        "tl" === this.options.f && wx.pageScrollTo({
            selector: ".topic-timeline",
            duration: 300
        });
    },
    onUnload: function() {
        this.storeBindings && this.storeBindings.destroyStoreBindings();
    },
    onLoad: function(e) {
        var t = this;
        return n(i().mark(function n() {
            var o, u, l, d;
            return i().wrap(function(i) {
                for (;;) switch (i.prev = i.next) {
                  case 0:
                    return o = "", i.prev = 1, e.scene && (u = (0, s.decodeScene)(e.scene), Object.assign(e, u)), 
                    l = (0, c.getSystemInfo)(), t.systemInfo = l, d = l.windowHeight - 44, l.statusBarHeight ? d -= l.statusBarHeight : d -= 20, 
                    p.add({
                        id: e.id
                    }), t.storeBindings = (0, r.createStoreBindings)(t, {
                        store: v.default,
                        fields: [ "subscribeState", "theme", "pro", "isDailyReject" ]
                    }), t.setData({
                        options: e,
                        containerStyle: "height: ".concat(d, "px;")
                    }), i.next = 12, t.refreshPage();

                  case 12:
                    t.submitCrawlerPages(), (0, c.setBackgroundColor)(v.default.theme, {
                        dark: "#191919",
                        light: "#ffffff"
                    }), (0, g.CustomScreenView)(), t.selectComponent("#subscribeMessage").checkAndShowNotice("NEWS_UPDATE"), 
                    i.next = 22;
                    break;

                  case 18:
                    i.prev = 18, i.t0 = i.catch(1), a.default.error(i.t0), o = i.t0.message;

                  case 22:
                    return i.prev = 22, t.setData({
                        error: o,
                        inited: !0
                    }), setTimeout(function() {
                        t.setData({
                            tempLoading: !1
                        }), wx.nextTick(function() {
                            t.checkScrollToTimeline();
                        });
                    }, 200), i.finish(22);

                  case 26:
                  case "end":
                    return i.stop();
                }
            }, n, null, [ [ 1, 18, 22, 26 ] ]);
        }))();
    }
});