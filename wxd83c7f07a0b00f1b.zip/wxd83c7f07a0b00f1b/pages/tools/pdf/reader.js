var e = require("../../../@babel/runtime/helpers/regeneratorRuntime"), t = require("../../../@babel/runtime/helpers/typeof"), r = require("../../../@babel/runtime/helpers/asyncToGenerator"), n = function(e, t) {
    if (!t && e && e.__esModule) return e;
    if (null === e || "object" != typeof e && "function" != typeof e) return {
        default: e
    };
    var r = c(t);
    if (r && r.has(e)) return r.get(e);
    var n = {}, a = Object.defineProperty && Object.getOwnPropertyDescriptor;
    for (var o in e) if ("default" !== o && Object.prototype.hasOwnProperty.call(e, o)) {
        var i = a ? Object.getOwnPropertyDescriptor(e, o) : null;
        i && (i.get || i.set) ? Object.defineProperty(n, o, i) : n[o] = e[o];
    }
    n.default = e, r && r.set(e, n);
    return n;
}(require("../../../utils/lodash")), a = require("../../../utils/functional"), o = require("../../../utils/tools"), i = require("../../../utils/mina"), s = require("../../../service/stock");

function c(e) {
    if ("function" != typeof WeakMap) return null;
    var t = new WeakMap(), r = new WeakMap();
    return (c = function(e) {
        return e ? r : t;
    })(e);
}

Page({
    data: {
        navigationTitle: "PDF 阅读器",
        inited: !1,
        error: "",
        containerStyle: "",
        options: {}
    },
    reload: function() {
        this.setData({
            inited: !1
        }), this.refreshPage();
    },
    refreshPage: (0, a.singleExec)(r(e().mark(function r() {
        var a, i, c, u, l, p;
        return e().wrap(function(e) {
            for (;;) switch (e.prev = e.next) {
              case 0:
                return e.next = 2, getApp().appInit();

              case 2:
                if (a = this.data.options.file ? decodeURIComponent(this.data.options.file) : "", 
                !((i = a.indexOf("?")) > -1)) {
                    e.next = 13;
                    break;
                }
                if (c = a.slice(i + 1), console.log(c), !((u = (0, o.decodeScene)(c)).Expires && u.fid && new Date(1e3 * parseFloat(u.Expires)) >= new Date())) {
                    e.next = 13;
                    break;
                }
                return e.next = 11, (0, s.getStokeFileDownloadUrl)(u.fid);

              case 11:
                l = e.sent, a = n.get(l, "data.items[0].url", "");

              case 13:
                p = "https://resource.nocode.com/assets/pdf_reader/generic-legacy/web/viewer.html?t=".concat(parseInt(Date.now() / 3e4)), 
                this.data.options.title && (p += "&title=".concat(this.data.options.title)), a && (p += "&file=".concat(encodeURIComponent(a))), 
                console.log("file", t(a)), console.log("view", p), this.setData({
                    error: "",
                    url: p
                });

              case 19:
              case "end":
                return e.stop();
            }
        }, r, this);
    })), {
        onError: function(e) {
            throw e;
        }
    }),
    onShareAppMessage: function() {
        return {
            title: this.data.navigationTitle,
            path: "/pages/tools/pdf/reader?".concat((0, o.queryString)(this.data.options)),
            success: function() {
                console.log("share success");
            },
            error: function() {
                console.log("share error");
            }
        };
    },
    onShow: function() {
        var t = this;
        return r(e().mark(function r() {
            return e().wrap(function(e) {
                for (;;) switch (e.prev = e.next) {
                  case 0:
                    if (t.data.inited) {
                        e.next = 2;
                        break;
                    }
                    return e.abrupt("return");

                  case 2:
                    return e.prev = 2, e.next = 5, t.refreshPage();

                  case 5:
                    e.next = 10;
                    break;

                  case 7:
                    e.prev = 7, e.t0 = e.catch(2), console.error(e.t0);

                  case 10:
                  case "end":
                    return e.stop();
                }
            }, r, null, [ [ 2, 7 ] ]);
        }))();
    },
    onLoad: function(t) {
        var a = this;
        return r(e().mark(function r() {
            var s, c, u, l;
            return e().wrap(function(e) {
                for (;;) switch (e.prev = e.next) {
                  case 0:
                    return s = "", e.prev = 1, t.scene && (c = (0, o.decodeScene)(t.scene), n.assign(t, c)), 
                    u = (0, i.getSystemInfo)(), l = u.windowHeight - 44, u.statusBarHeight ? l -= u.statusBarHeight : l -= 20, 
                    "false" === t.share ? wx.hideShareMenu && wx.hideShareMenu() : wx.showShareMenu && wx.showShareMenu(), 
                    e.next = 9, new Promise(function(e) {
                        a.setData({
                            options: t,
                            navigationTitle: decodeURIComponent(t.title || "PDF 阅读器"),
                            containerStyle: "height: ".concat(l, "px;")
                        }, e);
                    });

                  case 9:
                    return e.next = 11, a.refreshPage();

                  case 11:
                    e.next = 16;
                    break;

                  case 13:
                    e.prev = 13, e.t0 = e.catch(1), s = e.t0.message;

                  case 16:
                    return e.prev = 16, a.setData({
                        error: s,
                        inited: !0
                    }), e.finish(16);

                  case 19:
                  case "end":
                    return e.stop();
                }
            }, r, null, [ [ 1, 13, 16, 19 ] ]);
        }))();
    }
});