var e = require("../@babel/runtime/helpers/regeneratorRuntime"), t = require("../@babel/runtime/helpers/asyncToGenerator"), r = function(e, t) {
    if (!t && e && e.__esModule) return e;
    if (null === e || "object" != typeof e && "function" != typeof e) return {
        default: e
    };
    var r = o(t);
    if (r && r.has(e)) return r.get(e);
    var n = {}, a = Object.defineProperty && Object.getOwnPropertyDescriptor;
    for (var i in e) if ("default" !== i && Object.prototype.hasOwnProperty.call(e, i)) {
        var s = a ? Object.getOwnPropertyDescriptor(e, i) : null;
        s && (s.get || s.set) ? Object.defineProperty(n, i, s) : n[i] = e[i];
    }
    n.default = e, r && r.set(e, n);
    return n;
}(require("../utils/lodash")), n = require("../utils/functional"), a = require("../utils/tools"), i = require("../utils/mina");

function o(e) {
    if ("function" != typeof WeakMap) return null;
    var t = new WeakMap(), r = new WeakMap();
    return (o = function(e) {
        return e ? r : t;
    })(e);
}

Page({
    data: {
        navigationTitle: "Readhub",
        inited: !1,
        error: "",
        containerStyle: "",
        options: {}
    },
    reload: function() {
        this.setData({
            inited: !1
        }), this.refreshPage();
    },
    refreshPage: (0, n.singleExec)(t(e().mark(function t() {
        var r, n, a, o;
        return e().wrap(function(e) {
            for (;;) switch (e.prev = e.next) {
              case 0:
                return e.next = 2, getApp().appInit();

              case 2:
                if (r = (0, i.getSystemInfo)(), n = 20, r.statusBarHeight && (n = r.statusBarHeight), 
                a = decodeURIComponent(this.data.options.url), o = a.indexOf("?") > -1 ? "&" : "?", 
                a += o + "height=".concat(n, "&type=1"), console.log("view", a), a) {
                    e.next = 11;
                    break;
                }
                return e.abrupt("return", wx.navigateBack());

              case 11:
                this.setData({
                    error: "",
                    url: a
                });

              case 12:
              case "end":
                return e.stop();
            }
        }, t, this);
    })), {
        onError: function(e) {
            throw e;
        }
    }),
    onShareAppMessage: function() {
        return {
            title: this.data.options.title ? decodeURIComponent(this.data.options.title) : " ",
            path: "/pages/webview?".concat((0, a.queryString)(this.data.options))
        };
    },
    onShow: function() {
        var r = this;
        return t(e().mark(function t() {
            return e().wrap(function(e) {
                for (;;) switch (e.prev = e.next) {
                  case 0:
                    if (r.data.inited) {
                        e.next = 2;
                        break;
                    }
                    return e.abrupt("return");

                  case 2:
                    return e.prev = 2, e.next = 5, r.refreshPage();

                  case 5:
                    e.next = 10;
                    break;

                  case 7:
                    e.prev = 7, e.t0 = e.catch(2), console.error(e.t0);

                  case 10:
                  case "end":
                    return e.stop();
                }
            }, t, null, [ [ 2, 7 ] ]);
        }))();
    },
    onLoad: function(n) {
        var o = this;
        return t(e().mark(function t() {
            var s, u, c, p;
            return e().wrap(function(e) {
                for (;;) switch (e.prev = e.next) {
                  case 0:
                    return s = "", e.prev = 1, n.scene && (u = (0, a.decodeScene)(n.scene), r.assign(n, u)), 
                    c = (0, i.getSystemInfo)(), p = c.windowHeight - 44, c.statusBarHeight ? p -= c.statusBarHeight : p -= 20, 
                    e.next = 8, new Promise(function(e) {
                        o.setData({
                            options: n,
                            navigationTitle: decodeURIComponent(n.title || "Readhub"),
                            containerStyle: "height: ".concat(p, "px;")
                        }, e);
                    });

                  case 8:
                    return e.next = 10, o.refreshPage();

                  case 10:
                    e.next = 15;
                    break;

                  case 12:
                    e.prev = 12, e.t0 = e.catch(1), s = e.t0.message;

                  case 15:
                    return e.prev = 15, o.setData({
                        error: s,
                        inited: !0
                    }), e.finish(15);

                  case 18:
                  case "end":
                    return e.stop();
                }
            }, t, null, [ [ 1, 12, 15, 18 ] ]);
        }))();
    }
});