var e = require("../../@babel/runtime/helpers/regeneratorRuntime"), t = require("../../@babel/runtime/helpers/asyncToGenerator"), n = function(e, t) {
    if (!t && e && e.__esModule) return e;
    if (null === e || "object" != typeof e && "function" != typeof e) return {
        default: e
    };
    var n = f(t);
    if (n && n.has(e)) return n.get(e);
    var r = {}, a = Object.defineProperty && Object.getOwnPropertyDescriptor;
    for (var i in e) if ("default" !== i && Object.prototype.hasOwnProperty.call(e, i)) {
        var s = a ? Object.getOwnPropertyDescriptor(e, i) : null;
        s && (s.get || s.set) ? Object.defineProperty(r, i, s) : r[i] = e[i];
    }
    r.default = e, n && n.set(e, r);
    return r;
}(require("../../utils/lodash")), r = require("../../utils/functional"), a = require("../../utils/tools"), i = require("../../utils/mina"), s = require("../../service/analyse"), o = require("mobx-miniprogram-bindings"), c = h(require("../../store/app")), u = h(require("../../utils/logger")), l = require("../../utils/date"), d = require("../../service/user"), p = require("../../service/news");

function h(e) {
    return e && e.__esModule ? e : {
        default: e
    };
}

function f(e) {
    if ("function" != typeof WeakMap) return null;
    var t = new WeakMap(), n = new WeakMap();
    return (f = function(e) {
        return e ? n : t;
    })(e);
}

function g(e) {
    if (e.text) return e.text.length;
    if (e.children) {
        var t = 0;
        return e.children.forEach(function(e) {
            t += g(e);
        }), t;
    }
    return 0;
}

Page({
    data: {
        navigationTitle: "资讯详情",
        stitle: "资讯详情",
        navigationStyle: "background: #ffffff",
        inited: !1,
        error: "",
        containerStyle: "",
        options: {},
        news: null,
        initTheme: c.default.theme,
        tempLoading: !0,
        isCrawler: !1,
        date: "",
        entitys: [],
        entityKeys: [],
        isButtomDailyTipShow: !1,
        isManager: !1,
        stockKeys: [],
        entityBoomState: "",
        actionsheetList: (0, a.getActionSheet)([ "wechat", "mudslide" ]),
        reachBottom: !1,
        wordCount: 0,
        entityBarAnimatedClass: "slide-in"
    },
    onReport: function() {
        (0, s.report)("news_middle_assistant_qr_click");
    },
    reload: function() {
        var n = this;
        return t(e().mark(function t() {
            return e().wrap(function(e) {
                for (;;) switch (e.prev = e.next) {
                  case 0:
                    return n.setData({
                        inited: !1
                    }), e.prev = 1, e.next = 4, n.refreshPage();

                  case 4:
                    return e.prev = 4, n.setData({
                        inited: !0
                    }), e.finish(4);

                  case 7:
                  case "end":
                    return e.stop();
                }
            }, t, null, [ [ 1, , 4, 7 ] ]);
        }))();
    },
    onReachBottom: function() {
        this.setData({
            reachBottom: !0
        });
    },
    onPageAnimationEnd: function() {
        "leave-out" === this.data.entityBoomState && this.setData({
            entityBoomState: ""
        });
    },
    onEntityBoomEnterIn: function() {
        this.setData({
            entityBoomState: "enter-in"
        });
    },
    onEntityBoomLeaveOut: function() {
        this.setData({
            entityBoomState: "leave-out"
        });
    },
    onEntityTagsVisibleChange: function(e) {
        var t = e.detail;
        if (t.boundingClientRect.top <= 0) return this.setData({
            entityBarAnimatedClass: "slide-out"
        });
        this.setData({
            entityBarAnimatedClass: t.intersectionRatio > 0 ? "slide-out" : "slide-in"
        });
    },
    onShare: function() {
        this.selectComponent(".actionsheet").show();
    },
    chooseActionSheet: function(n) {
        var r = this;
        return t(e().mark(function t() {
            var i;
            return e().wrap(function(e) {
                for (;;) switch (e.prev = e.next) {
                  case 0:
                    if ("mudslide" !== n.detail.item.id) {
                        e.next = 6;
                        break;
                    }
                    return e.next = 4, (0, p.fetchMinaCode)(r.data.news.id);

                  case 4:
                    i = e.sent, wx.navigateTo({
                        url: "/pages/tools/nishiliu/custom?".concat((0, a.queryStringWithoutDecode)({
                            title: r.data.news.title,
                            name: "Readhub",
                            qrcode: i
                        }))
                    });

                  case 6:
                  case "end":
                    return e.stop();
                }
            }, t);
        }))();
    },
    refreshPage: (0, r.singleExec)(t(e().mark(function t() {
        var n, r, a, s, o, c, u = this;
        return e().wrap(function(e) {
            for (;;) switch (e.prev = e.next) {
              case 0:
                return e.next = 2, getApp().appInit();

              case 2:
                return e.next = 4, (0, p.fetchNewsDetail)(this.data.options.id);

              case 4:
                if ((n = e.sent).title) {
                    e.next = 9;
                    break;
                }
                throw this.setData({
                    error: "内容已下架"
                }), setTimeout(function() {
                    1 === getCurrentPages().length ? wx.reLaunch({
                        url: "/pages/index"
                    }) : wx.navigateBack();
                }, 1e3), new Error("内容已下架");

              case 9:
                wx.setNavigationBarTitle({
                    title: n.title
                }), r = "", a = n.title.length, s = 0, o = n.body.length;

              case 13:
                if (!(s < o)) {
                    e.next = 22;
                    break;
                }
                if ("img" !== (c = n.body[s]).name || !c.attrs.src) {
                    e.next = 18;
                    break;
                }
                return r = c.attrs.src, e.abrupt("break", 22);

              case 18:
                a += g(c);

              case 19:
                s++, e.next = 13;
                break;

              case 22:
                this.setData({
                    wordCount: a,
                    error: "",
                    news: n,
                    stitle: n.title,
                    date: n.date ? (0, l.relativeDatetime)(n.date) : "",
                    entitys: n.entitys,
                    entityKeys: n.entitys.map(function(e) {
                        return e.entityName;
                    }).sort(function(e, t) {
                        return t.length - e.length;
                    }),
                    isCrawler: (0, i.isWechatCrawler)(),
                    cover: r,
                    isManager: (0, d.isManager)(),
                    tags: n.tags
                }), (0, i.isSinglePageMode)() || setTimeout(function() {
                    u.showSubscribeIfNeed();
                }, 250);

              case 24:
              case "end":
                return e.stop();
            }
        }, t, this);
    })), {
        ignoreErrorToast: !0,
        onError: function(e) {
            throw e;
        }
    }),
    subscribe: (0, r.singleExec)(t(e().mark(function t() {
        var n, r;
        return e().wrap(function(e) {
            for (;;) switch (e.prev = e.next) {
              case 0:
                if (!this.selectComponent("#layout").getLoginManager().needLogin()) {
                    e.next = 3;
                    break;
                }
                return this.selectComponent("#layout").getLoginManager().show(), e.abrupt("return", !1);

              case 3:
                return e.prev = 3, e.next = 6, (0, d.subscribe)(1);

              case 6:
                if (!(n = e.sent).error) {
                    e.next = 9;
                    break;
                }
                return e.abrupt("return", wx.showToast({
                    title: n.error.message,
                    icon: "none"
                }));

              case 9:
                if (!(r = this.selectComponent("#dailyCalender"))) {
                    e.next = 13;
                    break;
                }
                return e.next = 13, r.addNextRemindAvaliableDayRemind();

              case 13:
                return e.abrupt("return", !0);

              case 16:
                e.prev = 16, e.t0 = e.catch(3), u.default.error(e.t0);

              case 19:
              case "end":
                return e.stop();
            }
        }, t, this, [ [ 3, 16 ] ]);
    }))),
    subscribeFromDailyTip: (0, r.singleExec)(t(e().mark(function t() {
        return e().wrap(function(e) {
            for (;;) switch (e.prev = e.next) {
              case 0:
                return (0, s.report)("dailysubscribe_ad_click"), e.next = 3, this.subscribe();

              case 3:
                e.sent && (this.setData({
                    isButtomDailyTipShow: !1
                }), wx.navigateTo({
                    url: "/pages/daily"
                }));

              case 5:
              case "end":
                return e.stop();
            }
        }, t, this);
    }))),
    showAdminOpt: function() {
        var e = "https://dataengine.nocode.com/medical_base/kg/".concat(this.data.news.itemId);
        wx.navigateTo({
            url: "/pages/webview?url=".concat(encodeURIComponent(e))
        });
    },
    hideBottomDailyTip: function() {
        getApp().temp("subscribe_tip_tap_close", !0), (0, s.report)("dailysubscribe_ad_close"), 
        this.setData({
            isButtomDailyTipShow: !1
        });
    },
    onLinkTap: function(e) {
        var t = e.detail.text;
        t && wx.navigateTo({
            url: "/pages/search/search?query=".concat(t)
        });
    },
    onEntityTap: function(e) {
        var t = e.detail.key;
        t && wx.navigateTo({
            url: "/pages/search/search?query=".concat(t)
        });
    },
    onEntityTagTap: function(e) {
        (0, s.report)(e.currentTarget.dataset.event);
    },
    onDailyCardTap: function() {
        (0, s.report)("newsdetail_daily_click");
    },
    onShareAppMessage: function(e) {
        var t = "";
        return (0, i.isWechatCrawler)() && (t = this.data.cover || "/images/readhub-logo.png"), 
        console.log("/pages/index?nav=".concat(encodeURIComponent("/pages/news/detail"), "&id=").concat(this.data.options.id, "&type=").concat(this.data.options.type || "tn")), 
        {
            title: "button" === e.from ? "" : this.data.news.title,
            imageUrl: t,
            path: "/pages/index?nav=".concat(encodeURIComponent("/pages/news/detail"), "&id=").concat(this.data.options.id, "&type=").concat(this.data.options.type || "tn"),
            success: function() {
                u.default.log("share success");
            },
            error: function() {
                u.default.log("share error");
            }
        };
    },
    onShareTimeline: function() {
        return {
            title: this.data.news.title,
            query: "id=".concat(this.data.news.id, "&type=").concat(this.data.options.type || "tn")
        };
    },
    previewImage: function(e) {
        var t = e.currentTarget.dataset.src;
        wx.previewImage({
            urls: [ t ]
        });
    },
    onShow: function() {
        var n = this;
        return t(e().mark(function t() {
            return e().wrap(function(e) {
                for (;;) switch (e.prev = e.next) {
                  case 0:
                    if (n.data.inited) {
                        e.next = 2;
                        break;
                    }
                    return e.abrupt("return");

                  case 2:
                    n.showSubscribeIfNeed();

                  case 3:
                  case "end":
                    return e.stop();
                }
            }, t);
        }))();
    },
    showSubscribeIfNeed: function() {
        var n = this;
        return t(e().mark(function t() {
            var r, a, i, o, c, u;
            return e().wrap(function(e) {
                for (;;) switch (e.prev = e.next) {
                  case 0:
                    r = n.data.subscribeState, a = wx.getEnterOptionsSync(), i = a.scene, o = [ 1005, 1053 ], 
                    r.daily || -1 !== o.indexOf(i) ? n.setData({
                        isButtomDailyTipShow: !1
                    }) : (c = getApp().temp("subscribe_tip_show"), u = !1, getApp().isFirstVisit() && !getApp().temp("subscribe_tip_tap_close") ? u = !0 : getApp().temp("subscribe_tip_tap_close") && c ? Date.now() - c.date > 6048e5 && (u = !0) : u = !0, 
                    u ? n.data.isButtomDailyTipShow || (getApp().temp("subscribe_tip_show", {
                        date: Date.now()
                    }), (0, s.report)("dailysubscribe_ad_show"), n.setData({
                        isButtomDailyTipShow: !0
                    })) : n.setData({
                        isButtomDailyTipShow: !1
                    }));

                  case 5:
                  case "end":
                    return e.stop();
                }
            }, t);
        }))();
    },
    onUnload: function() {
        this.storeBindings && this.storeBindings.destroyStoreBindings();
    },
    onLoad: function(r) {
        var l = this;
        return t(e().mark(function t() {
            var d, p, h, f;
            return e().wrap(function(e) {
                for (;;) switch (e.prev = e.next) {
                  case 0:
                    return d = "", e.prev = 1, r.scene && (p = (0, a.decodeScene)(r.scene), n.assign(r, p)), 
                    h = (0, i.getSystemInfo)(), f = h.windowHeight - 44, h.statusBarHeight ? f -= h.statusBarHeight : f -= 20, 
                    l.storeBindings = (0, o.createStoreBindings)(l, {
                        store: c.default,
                        fields: [ "theme", "subscribeState" ]
                    }), l.setData({
                        options: r,
                        containerStyle: "height: ".concat(f, "px;"),
                        containerHeight: f
                    }), e.next = 10, l.refreshPage();

                  case 10:
                    (0, i.setBackgroundColor)(c.default.theme, {
                        dark: "#191919",
                        light: "#ffffff"
                    }), (0, s.CustomScreenView)(), e.next = 18;
                    break;

                  case 14:
                    e.prev = 14, e.t0 = e.catch(1), u.default.error(e.t0), d = e.t0.message;

                  case 18:
                    return e.prev = 18, l.setData({
                        error: d,
                        inited: !0
                    }, function() {
                        setTimeout(function() {
                            l.setData({
                                tempLoading: !1
                            });
                        }, 200);
                    }), e.finish(18);

                  case 21:
                  case "end":
                    return e.stop();
                }
            }, t, null, [ [ 1, 14, 18, 21 ] ]);
        }))();
    }
});