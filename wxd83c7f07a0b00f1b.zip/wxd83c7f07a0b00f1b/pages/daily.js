var e = require("../@babel/runtime/helpers/regeneratorRuntime"), t = require("../@babel/runtime/helpers/asyncToGenerator"), n = function(e, t) {
    if (!t && e && e.__esModule) return e;
    if (null === e || "object" != typeof e && "function" != typeof e) return {
        default: e
    };
    var n = v(t);
    if (n && n.has(e)) return n.get(e);
    var r = {}, a = Object.defineProperty && Object.getOwnPropertyDescriptor;
    for (var i in e) if ("default" !== i && Object.prototype.hasOwnProperty.call(e, i)) {
        var s = a ? Object.getOwnPropertyDescriptor(e, i) : null;
        s && (s.get || s.set) ? Object.defineProperty(r, i, s) : r[i] = e[i];
    }
    r.default = e, n && n.set(e, r);
    return r;
}(require("../utils/lodash")), r = require("../utils/functional"), a = require("../utils/tools"), i = require("../utils/mina"), s = require("../service/analyse"), o = require("../service/topic"), c = require("../service/user"), u = require("mobx-miniprogram-bindings"), l = m(require("../store/app")), p = m(require("dayjs")), d = m(require("../behavior/computed")), f = require("../service/constant"), h = require("../service/promotion"), g = require("../service/reminder"), w = m(require("../config")), b = require("../utils/cache");

function m(e) {
    return e && e.__esModule ? e : {
        default: e
    };
}

function v(e) {
    if ("function" != typeof WeakMap) return null;
    var t = new WeakMap(), n = new WeakMap();
    return (v = function(e) {
        return e ? n : t;
    })(e);
}

function x() {
    return "" + new Date().getFullYear() + new Date().getMonth();
}

var y = getApp();

Page({
    data: {
        isShowTips: !0,
        hasSubscribeOfficial: !1,
        navigationTitle: "早报订阅",
        inited: !1,
        error: "",
        containerStyle: "",
        options: {},
        shareImage: "",
        list: [],
        audioConfig: {},
        actionsheetList: (0, a.getActionSheet)([ "wechat", "image", "copyDailyLink" ]),
        initTheme: l.default.theme,
        proDesc: "",
        forceHidePro: !1,
        showProGuide: !1,
        noticeBarStyle: "",
        isManager: !1,
        isLoadingAd: !1
    },
    behaviors: [ d.default ],
    computed: {
        showPro: function() {
            return this.data.showProGuide && !this.data.forceHidePro;
        }
    },
    onHideTips: function() {
        y.globalData.enableShowManageSubscriptionTips = !1, this.setData({
            isShowTips: !1
        });
    },
    tryOpenSetting: function() {
        var e = this;
        (0, s.report)("submessage_reject_notice"), wx.showModal({
            title: "提示",
            content: "请到小程序设置页面打开相关授权",
            success: function(t) {
                t.confirm && ((0, s.report)("submessage_reject_authorize"), wx.openSetting({
                    withSubscriptions: !0,
                    success: function(t) {
                        t.authSetting && (l.default.changeMinaSetting(t), setTimeout(function() {
                            e.checkAndShowNotice(!0);
                        }, 350));
                    }
                }));
            }
        });
    },
    unsubscribe: (0, r.singleExec)(t(e().mark(function t() {
        return e().wrap(function(e) {
            for (;;) switch (e.prev = e.next) {
              case 0:
                return e.next = 2, (0, c.unsubscribe)(1);

              case 2:
                wx.showToast({
                    title: "已取消订阅",
                    icon: "none"
                });

              case 3:
              case "end":
                return e.stop();
            }
        }, t);
    }))),
    subscribe: (0, r.singleExec)(t(e().mark(function t() {
        var n;
        return e().wrap(function(e) {
            for (;;) switch (e.prev = e.next) {
              case 0:
                if (!this.selectComponent("#layout").getLoginManager().needLogin()) {
                    e.next = 2;
                    break;
                }
                return e.abrupt("return", this.selectComponent("#layout").getLoginManager().show());

              case 2:
                return e.next = 4, (0, c.subscribe)(1);

              case 4:
                if (this.manageRemind(), !(n = this.selectComponent("#dailyCalender"))) {
                    e.next = 9;
                    break;
                }
                return e.next = 9, n.addNextRemindAvaliableDayRemind();

              case 9:
              case "end":
                return e.stop();
            }
        }, t, this);
    }))),
    share: function() {
        this.selectComponent(".actionsheet").show();
    },
    onContact: function() {
        wx.previewImage({
            urls: [ "https://resource.nocode.com/readhub/assistant2.png" ]
        });
    },
    checkAndShowNotice: function(n) {
        var r = this;
        return t(e().mark(function t() {
            var a, i, s, o, c;
            return e().wrap(function(e) {
                for (;;) switch (e.prev = e.next) {
                  case 0:
                    if (n) {
                        e.next = 4;
                        break;
                    }
                    if (1 === getCurrentPages().length) {
                        e.next = 4;
                        break;
                    }
                    return e.abrupt("return");

                  case 4:
                    if ((o = getApp().getSubscribeTemplatesByName([ "DAILY" ]))[0]) {
                        e.next = 7;
                        break;
                    }
                    return e.abrupt("return");

                  case 7:
                    if (!(o[0].c >= 7)) {
                        e.next = 9;
                        break;
                    }
                    return e.abrupt("return");

                  case 9:
                    return e.next = 11, (0, g.getReminderConfig)();

                  case 11:
                    if (c = e.sent, !!(null === (a = c.data) || void 0 === a || null === (i = a.items) || void 0 === i || null === (s = i[0]) || void 0 === s || !s.planMode)) {
                        e.next = 15;
                        break;
                    }
                    return e.abrupt("return");

                  case 15:
                    !r.data.isDailyReject && r.data.subscribeState.daily && r.manageRemind();

                  case 16:
                  case "end":
                    return e.stop();
                }
            }, t);
        }))();
    },
    chooseActionSheet: function(e) {
        var t = e.detail.item;
        "image" === t.id ? ((0, s.report)("share_savepic"), wx.navigateTo({
            url: "/pages/share_image?ts=".concat(this.data.options.ts, "&type=daily")
        })) : "copyDailyLink" === t.id && wx.setClipboardData({
            data: "https://readhub.cn/daily/".concat((0, p.default)().unix(), "?from=mp"),
            success: function() {
                wx.showToast({
                    title: "链接已复制",
                    icon: "none"
                });
            }
        });
    },
    onToDailyEditor: function() {
        wx.navigateTo({
            url: "/pages/webview?url=".concat(encodeURIComponent("https://dataengine.nocode.com/medical_base/readhub/daily"))
        });
    },
    goToSubscribeOfficialAccount: function() {
        (0, s.report)("flow_guide_click"), wx.navigateTo({
            url: "/pages/webview?url=".concat(encodeURIComponent("https://mp.weixin.qq.com/s/_U6Icv_5_NyXeOv5zhV0nQ"))
        });
    },
    reload: function() {
        var n = this;
        return t(e().mark(function t() {
            return e().wrap(function(e) {
                for (;;) switch (e.prev = e.next) {
                  case 0:
                    return n.setData({
                        inited: !1
                    }), e.prev = 1, e.next = 4, n.refreshPage();

                  case 4:
                    e.next = 9;
                    break;

                  case 6:
                    e.prev = 6, e.t0 = e.catch(1), n.setData({
                        error: e.t0.message
                    });

                  case 9:
                    return e.prev = 9, n.setData({
                        inited: !0
                    }), e.finish(9);

                  case 12:
                  case "end":
                    return e.stop();
                }
            }, t, null, [ [ 1, 6, 9, 12 ] ]);
        }))();
    },
    reloadAd: function() {
        var e = this;
        this.setData({
            isLoadingAd: !0
        }), wx.nextTick(function() {
            e.setData({
                isLoadingAd: !1
            });
        });
    },
    onPullDownRefresh: (0, r.singleExec)(t(e().mark(function t() {
        return e().wrap(function(e) {
            for (;;) switch (e.prev = e.next) {
              case 0:
                if ((0, c.isManager)()) {
                    e.next = 2;
                    break;
                }
                return e.abrupt("return");

              case 2:
                return e.next = 4, this.refreshPage(!0);

              case 4:
              case "end":
                return e.stop();
            }
        }, t, this);
    })), {
        onComplete: function() {
            wx.stopPullDownRefresh();
        }
    }),
    refreshPage: (0, r.singleExec)(function() {
        var r = t(e().mark(function t(r) {
            var a, i, u, l, p, d;
            return e().wrap(function(e) {
                for (;;) switch (e.prev = e.next) {
                  case 0:
                    return e.next = 2, getApp().appInit();

                  case 2:
                    return e.next = 4, (0, o.getDaily)(this.data.options.ts || "", !!r);

                  case 4:
                    return a = e.sent.data, i = a.self, u = a.items, (0, b.getGlobalFlag)("0"), l = [], 
                    p = [], u.forEach(function(e) {
                        3 === e.type ? p.push(e) : l.push(e);
                    }), n.isEmpty(i.audioFile) || ((0, s.report)("success_api_voice", {
                        label: (0, b.getGlobalFlag)()
                    }), (0, b.getGlobalFlag)("1")), e.next = 14, y.getUserProfile();

                  case 14:
                    d = wx.getStorageSync(w.default.USER_KEY), this.setData({
                        hasSubscribeOfficial: !!d.officialAccountSubscribed,
                        stockList: p,
                        error: "",
                        audioConfig: i,
                        list: l,
                        isManager: (0, c.isManager)()
                    });

                  case 16:
                  case "end":
                    return e.stop();
                }
            }, t, this);
        }));
        return function(e) {
            return r.apply(this, arguments);
        };
    }(), {
        onError: function(e) {
            throw e;
        }
    }),
    closeProSubscribe: function() {
        (0, s.report)("dailyad_close"), this.setData({
            forceHidePro: !0
        });
    },
    onProGuideClick: function() {
        (0, s.report)("dailyad_click");
    },
    onShareTimeline: function() {
        var e = this.data.options.ts;
        return {
            title: "Readhub 每日早报",
            query: "ts=".concat(e)
        };
    },
    manageRemind: function() {
        (0, s.eventGa)("popup_sub_date_show"), this.selectComponent("#dailyCalender").show({
            zIndex: 2e3
        });
    },
    onShareAppMessage: function() {
        var e = this.data.options.ts;
        return {
            title: "",
            path: "/pages/daily?ts=".concat(e)
        };
    },
    onShow: function() {
        var n = this;
        return t(e().mark(function t() {
            return e().wrap(function(e) {
                for (;;) switch (e.prev = e.next) {
                  case 0:
                    if (n.data.inited) {
                        e.next = 2;
                        break;
                    }
                    return e.abrupt("return");

                  case 2:
                    return e.prev = 2, e.next = 5, n.refreshPage();

                  case 5:
                    l.default.userInfo.isVip && n.setData({
                        showProGuide: !1
                    }), e.next = 11;
                    break;

                  case 8:
                    e.prev = 8, e.t0 = e.catch(2), console.error(e.t0);

                  case 11:
                  case "end":
                    return e.stop();
                }
            }, t, null, [ [ 2, 8 ] ]);
        }))();
    },
    onHide: function() {
        var e = this;
        setTimeout(function() {
            e.reloadAd();
        }, 250);
    },
    onUnload: function() {
        this.storeBindings && this.storeBindings.destroyStoreBindings();
    },
    onLoad: function(r) {
        var o = this;
        return t(e().mark(function t() {
            var c, p, d, g, w, b, m, v, D;
            return e().wrap(function(e) {
                for (;;) switch (e.prev = e.next) {
                  case 0:
                    return o.setData({
                        isShowTips: y.globalData.enableShowManageSubscriptionTips
                    }), c = "", e.prev = 2, r.scene && (p = (0, a.decodeScene)(r.scene), n.assign(r, p)), 
                    r.ts || (r.ts = parseInt(Date.now() / 1e3)), d = (0, i.getSystemInfo)(), g = d.windowHeight - 44, 
                    d.statusBarHeight ? g -= d.statusBarHeight : g -= 20, o.storeBindings = (0, u.createStoreBindings)(o, {
                        store: l.default,
                        fields: [ "subscribeState", "theme", "userInfo", "templates", "isDailyReject" ]
                    }), getApp().temp(f.DAILY_PAGE_VIEW, {
                        date: Date.now()
                    }), e.prev = 10, e.next = 13, wx.getStorage({
                        key: "daily_pro_view"
                    });

                  case 13:
                    b = e.sent, w = b.data, e.next = 21;
                    break;

                  case 17:
                    e.prev = 17, e.t0 = e.catch(10), w = {
                        id: x(),
                        count: 0,
                        lastDay: -1
                    }, wx.setStorage({
                        key: "daily_pro_view",
                        data: w
                    });

                  case 21:
                    return e.next = 23, new Promise(function(e) {
                        o.setData({
                            options: r,
                            containerStyle: "height: ".concat(g, "px;"),
                            noticeBarStyle: "top: ".concat(44 + d.statusBarHeight || 20, "px;")
                        }, e);
                    });

                  case 23:
                    return e.next = 25, o.refreshPage();

                  case 25:
                    if (o.selectComponent("#dailyCalender").loadMoreCalData(), (0, i.setBackgroundColor)(l.default.theme, {
                        dark: "#191919",
                        light: "#ffffff"
                    }), !w || l.default.userInfo.isVip || !(w.id === x() && w.count < 2 || w.id !== x())) {
                        e.next = 39;
                        break;
                    }
                    return w.id !== x() && (w = {
                        id: x(),
                        count: 1,
                        lastDay: new Date().getDate()
                    }, wx.setStorage({
                        key: "daily_pro_view",
                        data: w
                    })), w.lastDay !== new Date().getDate() && (w.count++, w.lastDay = new Date().getDate(), 
                    wx.setStorage({
                        key: "daily_pro_view",
                        data: w
                    })), (0, s.report)("dailyad_show"), e.next = 34, (0, h.getFreeVipInfo)();

                  case 34:
                    m = e.sent, v = n.get(m, "data.items[0]", null), D = !0, !v.hasJoin && v.newUser || (D = !1), 
                    o.setData({
                        showProGuide: !0,
                        proDesc: D ? "新用户首月免费体验" : "更专业的科技领域信息订阅"
                    });

                  case 39:
                    (0, s.CustomScreenView)(), o.checkAndShowNotice(), e.next = 47;
                    break;

                  case 43:
                    e.prev = 43, e.t1 = e.catch(2), console.error(e.t1), c = e.t1.message;

                  case 47:
                    return e.prev = 47, o.setData({
                        error: c,
                        inited: !0
                    }), e.finish(47);

                  case 50:
                  case "end":
                    return e.stop();
                }
            }, t, null, [ [ 2, 43, 47, 50 ], [ 10, 17 ] ]);
        }))();
    }
});