var e = require("../@babel/runtime/helpers/regeneratorRuntime"), t = require("../@babel/runtime/helpers/asyncToGenerator"), r = v(require("dayjs")), i = x(require("../utils/lodash")), n = require("../utils/functional"), s = require("../utils/tools"), a = v(require("../utils/topicListProcess")), o = require("../utils/mina"), c = require("mobx-miniprogram-bindings"), u = v(require("../behavior/computed")), p = v(require("../store/app")), d = x(require("../service/topic")), l = x(require("../service/user")), h = require("../service/analyse"), f = v(require("../service/ad")), g = require("../service/mina"), m = v(require("../config")), b = v(require("../utils/logger")), w = require("../service/constant");

function T(e) {
    if ("function" != typeof WeakMap) return null;
    var t = new WeakMap(), r = new WeakMap();
    return (T = function(e) {
        return e ? r : t;
    })(e);
}

function x(e, t) {
    if (!t && e && e.__esModule) return e;
    if (null === e || "object" != typeof e && "function" != typeof e) return {
        default: e
    };
    var r = T(t);
    if (r && r.has(e)) return r.get(e);
    var i = {}, n = Object.defineProperty && Object.getOwnPropertyDescriptor;
    for (var s in e) if ("default" !== s && Object.prototype.hasOwnProperty.call(e, s)) {
        var a = n ? Object.getOwnPropertyDescriptor(e, s) : null;
        a && (a.get || a.set) ? Object.defineProperty(i, s, a) : i[s] = e[s];
    }
    return i.default = e, r && r.set(e, i), i;
}

function v(e) {
    return e && e.__esModule ? e : {
        default: e
    };
}

Page({
    data: {
        navigationTitle: "Readhub",
        inited: !1,
        error: "",
        containerStyle: "",
        options: {},
        groups: [],
        showedGroups: [],
        refreshTriggerd: !1,
        toView: "",
        actionsheetList: [],
        initTheme: p.default.theme,
        tempLoading: !0,
        isButtomDailyTipShow: !1,
        ipoNames: [],
        swiperDuration: 300,
        swiperInterval: 2500,
        isShowDailyTip: !1,
        isFirstVisitIndexPageToday: !1,
        tempSubscribed: !1,
        animateHideTempSubBtn: !1,
        isShowTempSubBtn: !1,
        isAdError: !1
    },
    behaviors: [ u.default ],
    computed: {
        isShowProXuding: function() {
            return i.get(this.data, "userInfo.isVipExpired", !1) && !getApp().temp(w.INDEX_XUNDIN_CLICKED);
        },
        isShowDailyRedDot: function() {
            var e = getApp().temp(w.DAILY_PAGE_VIEW);
            return this.data.isFirstVisitIndexPageToday && !(e && (0, r.default)(new Date(e.date)).isSame((0, 
            r.default)(), "date"));
        }
    },
    onAdError: function() {
        this.setData({
            isAdError: !0
        });
    },
    showAdOptions: function() {
        this.selectComponent(".adOptions").show();
    },
    swiperTouchStart: function() {
        var e = this;
        this._swiperTimer = setTimeout(function() {
            e.setData({
                swiperInterval: 50,
                swiperDuration: 50
            });
        }, 350);
    },
    swiperTouchEnd: function() {
        clearTimeout(this._swiperTimer), this.setData({
            swiperInterval: 2500,
            swiperDuration: 300
        });
    },
    scrollTop: function() {
        var e = this;
        this.setData({
            toView: "top-indiactor"
        }, function() {
            e.setData({
                toView: ""
            });
        });
    },
    showSubscribeIfNeed: function() {
        var r = this;
        return t(e().mark(function t() {
            var i, n;
            return e().wrap(function(e) {
                for (;;) switch (e.prev = e.next) {
                  case 0:
                    r.data.subscribeState.daily ? r.setData({
                        isButtomDailyTipShow: !1
                    }) : (i = getApp().temp("subscribe_tip_show"), n = !1, getApp().isFirstVisit() && !getApp().temp("subscribe_tip_tap_close") ? n = !0 : getApp().temp("subscribe_tip_tap_close") && i ? Date.now() - i.date > 6048e5 && (n = !0) : n = !0, 
                    n ? r.data.isButtomDailyTipShow || (getApp().temp("subscribe_tip_show", {
                        date: Date.now()
                    }), (0, h.report)("dailysubscribe_ad_show"), r.setData({
                        isButtomDailyTipShow: !0
                    })) : r.setData({
                        isButtomDailyTipShow: !1
                    }));

                  case 2:
                  case "end":
                    return e.stop();
                }
            }, t);
        }))();
    },
    unsubscribe: (0, n.singleExec)(t(e().mark(function t() {
        return e().wrap(function(e) {
            for (;;) switch (e.prev = e.next) {
              case 0:
                return e.next = 2, l.unsubscribe(1);

              case 2:
                wx.showToast({
                    title: "已取消订阅",
                    icon: "none"
                });

              case 3:
              case "end":
                return e.stop();
            }
        }, t);
    }))),
    navToDaily: function() {
        (0, h.report)("dailysubscribe_text_browse");
    },
    goToDaily: (0, n.singleExec)(t(e().mark(function t() {
        var r;
        return e().wrap(function(e) {
            for (;;) switch (e.prev = e.next) {
              case 0:
                if ((0, h.report)("index_daily"), r = getApp().getSubscribeTemplatesByName([ "DAILY" ]), 
                this.data.subscribeState.daily && !(r[0] && r[0].c <= 3)) {
                    e.next = 5;
                    break;
                }
                return e.next = 5, this.subscribe();

              case 5:
                wx.navigateTo({
                    url: "/pages/daily"
                });

              case 6:
              case "end":
                return e.stop();
            }
        }, t, this);
    }))),
    subscribeNextDaily: (0, n.singleExec)(t(e().mark(function t() {
        var r;
        return e().wrap(function(e) {
            for (;;) switch (e.prev = e.next) {
              case 0:
                return getApp().temp(w.INDEX_TEMP_SUB_BTN_VIEW, {
                    date: Date.now()
                }), e.next = 3, this.subscribe();

              case 3:
                r = e.sent, this.setData({
                    tempSubscribed: r,
                    animateHideTempSubBtn: !0
                });

              case 5:
              case "end":
                return e.stop();
            }
        }, t, this);
    }))),
    subscribe: (0, n.singleExec)(t(e().mark(function t() {
        var r, i;
        return e().wrap(function(e) {
            for (;;) switch (e.prev = e.next) {
              case 0:
                if (!this.selectComponent("#layout").getLoginManager().needLogin()) {
                    e.next = 3;
                    break;
                }
                return this.selectComponent("#layout").getLoginManager().show(), e.abrupt("return", !1);

              case 3:
                return e.next = 5, this.selectComponent("#subscribeMessage").auth([ "DAILY" ], !1, !0);

              case 5:
                if (!((r = e.sent) && r.accept_tmpl_id.length > 0)) {
                    e.next = 14;
                    break;
                }
                return e.next = 9, l.subscribe(1);

              case 9:
                if (!(i = this.selectComponent("#dailyCalender"))) {
                    e.next = 13;
                    break;
                }
                return e.next = 13, i.addNextRemindAvaliableDayRemindWithoutAuth();

              case 13:
                return e.abrupt("return", !0);

              case 14:
                return e.abrupt("return", !1);

              case 15:
              case "end":
                return e.stop();
            }
        }, t, this);
    }))),
    subscribeFromDailyTip: (0, n.singleExec)(t(e().mark(function t() {
        return e().wrap(function(e) {
            for (;;) switch (e.prev = e.next) {
              case 0:
                return (0, h.report)("dailysubscribe_ad_click"), e.next = 3, this.subscribe();

              case 3:
                this.setData({
                    isButtomDailyTipShow: !1
                }), wx.navigateTo({
                    url: "/pages/daily"
                });

              case 5:
              case "end":
                return e.stop();
            }
        }, t, this);
    }))),
    hideBottomDailyTip: function() {
        getApp().temp("subscribe_tip_tap_close", !0), (0, h.report)("dailysubscribe_ad_close"), 
        this.setData({
            isButtomDailyTipShow: !1
        });
    },
    disableTouch: function() {},
    getRecommends: function(e) {
        function t() {
            return e.apply(this, arguments);
        }
        return t.toString = function() {
            return e.toString();
        }, t;
    }(function() {
        var r = this;
        return t(e().mark(function t() {
            var n, a;
            return e().wrap(function(e) {
                for (;;) switch (e.prev = e.next) {
                  case 0:
                    return e.prev = 0, e.next = 3, getRecommends();

                  case 3:
                    n = e.sent.data.items, a = n.filter(function(e) {
                        return (0, s.textLen)(e.companyNameFull) <= 8;
                    }).map(function(e) {
                        return e.companyNameFull;
                    }), i.shuffle(a), a.unshift("IPO 招股书"), r.setData({
                        ipoNames: a
                    }), console.log("ipoNames", a), e.next = 14;
                    break;

                  case 11:
                    e.prev = 11, e.t0 = e.catch(0), console.error(e.t0);

                  case 14:
                  case "end":
                    return e.stop();
                }
            }, t, null, [ [ 0, 11 ] ]);
        }))();
    }),
    reload: function() {
        var r = this;
        return t(e().mark(function t() {
            return e().wrap(function(e) {
                for (;;) switch (e.prev = e.next) {
                  case 0:
                    return r.setData({
                        inited: !1
                    }), e.prev = 1, e.next = 4, r.refreshPage();

                  case 4:
                    e.next = 9;
                    break;

                  case 6:
                    e.prev = 6, e.t0 = e.catch(1), r.setData({
                        error: e.t0.message
                    });

                  case 9:
                    return e.prev = 9, r.setData({
                        inited: !0
                    }), e.finish(9);

                  case 12:
                  case "end":
                    return e.stop();
                }
            }, t, null, [ [ 1, 6, 9, 12 ] ]);
        }))();
    },
    loadMore: (0, n.singleExec)(t(e().mark(function t() {
        var r, n, s, a, o;
        return e().wrap(function(e) {
            for (;;) switch (e.prev = e.next) {
              case 0:
                if (r = this.data, n = r.next, s = r.groups, n) {
                    e.next = 3;
                    break;
                }
                return e.abrupt("return");

              case 3:
                return e.next = 5, d.getTopics("day", n);

              case 5:
                a = e.sent, o = this.topicListProcess.processTopics(a.data, s), this.setData({
                    next: i.get(a, "links.next", ""),
                    groups: o,
                    showedGroups: (o || []).filter(function(e) {
                        return !e.isEmpty;
                    })
                });

              case 8:
              case "end":
                return e.stop();
            }
        }, t, this);
    })), {
        ignoreErrorToast: !0
    }),
    refreshPage: (0, n.singleExec)(t(e().mark(function t() {
        var r, n, s = this;
        return e().wrap(function(e) {
            for (;;) switch (e.prev = e.next) {
              case 0:
                return e.next = 2, getApp().appInit();

              case 2:
                return f.default.refreshAd(), this.topicListProcess = new a.default(), e.next = 6, 
                d.getTopics("day");

              case 6:
                r = e.sent, n = this.topicListProcess.processTopics(r.data), this.setData({
                    error: "",
                    next: i.get(r, "links.next", ""),
                    groups: n,
                    showedGroups: (n || []).filter(function(e) {
                        return !e.isEmpty;
                    })
                }), (0, o.isSinglePageMode)() || setTimeout(function() {
                    s.showSubscribeIfNeed();
                }, 5e3);

              case 10:
              case "end":
                return e.stop();
            }
        }, t, this);
    })), {
        onError: function(e) {
            throw e;
        },
        onComplete: function() {
            this.setData({
                refreshTriggerd: !1
            });
        }
    }),
    onCardTap: function(e) {
        var t = e.currentTarget.dataset.item;
        "sponsor" === t.type ? (0, h.report)("ad_sponsor_click", {
            name: t.sponsorName
        }) : (0, h.report)("click_card_daylist", {
            title: t.title
        }), this.selectComponent("#subscribeMessage").auth([ "NEWS_UPDATE", "DAILY", "RENEW" ], !0);
    },
    onActionSheetHide: function() {
        var e = this;
        setTimeout(function() {
            e.shareId = null;
        }, 100);
    },
    chooseActionSheet: function(e) {
        var t = e.detail.item, r = this.shareId;
        "mudslide" === t.id ? this.genMudslideImage(r) : "copy" === t.id ? this.setClipboard(r, t.title) : "timeline" === t.id ? this.showTimelineTip() : "official" === t.id && (0, 
        g.toShareTopicInOfficial)(r, t);
    },
    goToSearch: function() {
        (0, h.report)("index_search");
    },
    showTimelineTip: function() {},
    genMudslideImage: function(r) {
        return t(e().mark(function t() {
            var i, n;
            return e().wrap(function(e) {
                for (;;) switch (e.prev = e.next) {
                  case 0:
                    if (r) {
                        e.next = 2;
                        break;
                    }
                    return e.abrupt("return", wx.navigateTo({
                        url: "/pages/share_image?image=".concat(encodeURIComponent("/images/share-timeline.png"))
                    }));

                  case 2:
                    return (0, h.report)("share_circle"), e.next = 5, d.getTopic(r);

                  case 5:
                    return i = e.sent, e.next = 8, (0, d.fetchMinaCode)(r);

                  case 8:
                    n = e.sent, wx.navigateTo({
                        url: "/pages/tools/nishiliu/custom?".concat((0, s.queryStringWithoutDecode)({
                            title: i.title,
                            name: "Readhub",
                            qrcode: n
                        }))
                    });

                  case 10:
                  case "end":
                    return e.stop();
                }
            }, t);
        }))();
    },
    setClipboard: function(e, t) {
        wx.setClipboardData({
            data: "https://readhub.cn/topic/".concat(e, "?from=mp"),
            success: function() {
                (0, h.report)("click_url", {
                    title: t
                }), wx.showToast({
                    title: "链接已复制",
                    icon: "none",
                    duration: 500
                });
            }
        });
    },
    onShareTopic: function(e) {
        var t = this;
        this.shareId = e.detail.id, this.setData({
            actionsheetList: (0, s.getActionSheet)([ "wechat", "mudslide", "official", "copy" ])
        }, function() {
            t.selectComponent(".actionsheet").show();
        });
    },
    onShareTimeline: function() {
        return {
            title: "Readhub：科技新闻阅读，每天 3 分钟"
        };
    },
    onShareAppMessage: function() {
        if (this.shareId) {
            var e = "".concat(m.default.API_HOST, "/topic/").concat(this.shareId, "/cover.png?t=").concat(m.default.VERSION);
            return b.default.log("share url", e), {
                title: "",
                path: "/pages/detail?id=".concat(this.shareId),
                imageUrl: e,
                success: function() {
                    b.default.log("share success");
                },
                error: function() {
                    b.default.log("share error");
                }
            };
        }
        return {
            title: "科技新闻阅读，每天 3 分钟",
            path: "/pages/index?type=".concat("card"),
            imageUrl: "https://cdn.readhub.cn/mina/share-to-friend.png",
            success: function() {
                b.default.log("share success");
            },
            error: function() {
                b.default.log("share error");
            }
        };
    },
    isShowTempSubBtn: function() {
        var e = getApp().temp(w.INDEX_TEMP_SUB_BTN_VIEW), t = e && (0, r.default)(e.date).isSame((0, 
        r.default)(), "date"), i = getApp().getSubscribeTemplatesByName([ "DAILY" ]);
        return !t && i[0] && i[0].c <= 3;
    },
    goToPro: function() {
        if ((0, h.report)("index_pro"), this.data.isShowProXuding && getApp().temp(w.INDEX_XUNDIN_CLICKED, !0), 
        this.selectComponent("#layout").getLoginManager().needLogin()) return this.selectComponent("#layout").getLoginManager().show(), 
        !1;
        this.data.userInfo.isVip ? wx.navigateTo({
            url: "/pages/pro/subscription"
        }) : wx.navigateTo({
            url: "/pages/pro/join"
        });
    },
    showDailyTip: function() {
        var e = this;
        getApp().temp("index_daily_tip") || (getApp().temp("index_daily_tip", 1), this.setData({
            isShowDailyTip: !0
        }, function() {
            setTimeout(function() {
                e.setData({
                    isShowDailyTip: !1
                });
            }, 6e3);
        }));
    },
    goToNishiliu: function() {
        (0, h.report)("index_nishiliu");
    },
    goToRecruit: function() {
        (0, h.report)("index_caibao_ipo");
    },
    isFirstVisitToday: function() {
        var e = getApp().temp(w.INDEX_PAGE_VIEW);
        return !e || !(0, r.default)(e.date).isSame((0, r.default)(), "date");
    },
    onShow: function() {
        var r = this;
        return t(e().mark(function t() {
            return e().wrap(function(e) {
                for (;;) switch (e.prev = e.next) {
                  case 0:
                    if (r._swiperTimer && clearTimeout(r._swiperTimer), r.data.inited) {
                        e.next = 3;
                        break;
                    }
                    return e.abrupt("return");

                  case 3:
                    (0, o.setBackgroundColor)(p.default.theme, {
                        dark: "#191919",
                        light: "#ffffff"
                    });

                  case 4:
                  case "end":
                    return e.stop();
                }
            }, t);
        }))();
    },
    onUnload: function() {
        this.storeBindings && this.storeBindings.destroyStoreBindings();
    },
    onLoad: function(r) {
        var n = this;
        return t(e().mark(function t() {
            var a, u, d, l, f;
            return e().wrap(function(e) {
                for (;;) switch (e.prev = e.next) {
                  case 0:
                    return a = "", e.prev = 1, r.scene && (u = (0, s.decodeScene)(r.scene), i.assign(r, u)), 
                    (0, s.decodeOptions)(r), d = (0, o.getSystemInfo)(), n.systemInfo = d, l = d.windowHeight - 44, 
                    d.statusBarHeight ? l -= d.statusBarHeight : l -= 20, n.storeBindings = (0, c.createStoreBindings)(n, {
                        store: p.default,
                        fields: [ "subscribeState", "isHideSummary", "theme", "userInfo" ]
                    }), e.next = 11, new Promise(function(e) {
                        n.setData({
                            options: r,
                            containerStyle: "height: ".concat(l, "px;"),
                            isFirstVisitIndexPageToday: n.isFirstVisitToday()
                        }, e);
                    });

                  case 11:
                    return e.next = 13, n.refreshPage();

                  case 13:
                    r.code && setTimeout(function() {
                        n.selectComponent("#authPanel").show(r.code);
                    }, 200), (0, o.setBackgroundColor)(p.default.theme, {
                        dark: "#191919",
                        light: "#ffffff"
                    }), (0, h.CustomScreenView)(), getApp().temp(w.INDEX_PAGE_VIEW, {
                        date: Date.now()
                    }), r.nav ? (delete (f = Object.assign({}, r)).nav, wx.navigateTo({
                        url: "".concat(decodeURIComponent(r.nav), "?").concat((0, s.queryString)(f))
                    })) : r.search && wx.navigateTo({
                        url: "/pages/search/search?query=".concat(encodeURIComponent(r.search))
                    }), e.next = 24;
                    break;

                  case 20:
                    e.prev = 20, e.t0 = e.catch(1), a = e.t0.message, b.default.error(e.t0);

                  case 24:
                    return e.prev = 24, n.setData({
                        error: a,
                        inited: !0,
                        isShowTempSubBtn: n.isShowTempSubBtn()
                    }, function() {
                        setTimeout(function() {
                            n.setData({
                                tempLoading: !1
                            });
                        }, 200);
                    }), e.finish(24);

                  case 27:
                  case "end":
                    return e.stop();
                }
            }, t, null, [ [ 1, 20, 24, 27 ] ]);
        }))();
    }
});