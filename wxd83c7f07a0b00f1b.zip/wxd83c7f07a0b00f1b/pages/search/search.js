var e = require("../../@babel/runtime/helpers/objectSpread2"), t = require("../../@babel/runtime/helpers/regeneratorRuntime"), a = require("../../@babel/runtime/helpers/asyncToGenerator"), r = function(e, t) {
    if (!t && e && e.__esModule) return e;
    if (null === e || "object" != typeof e && "function" != typeof e) return {
        default: e
    };
    var a = f(t);
    if (a && a.has(e)) return a.get(e);
    var r = {}, s = Object.defineProperty && Object.getOwnPropertyDescriptor;
    for (var n in e) if ("default" !== n && Object.prototype.hasOwnProperty.call(e, n)) {
        var i = s ? Object.getOwnPropertyDescriptor(e, n) : null;
        i && (i.get || i.set) ? Object.defineProperty(r, n, i) : r[n] = e[n];
    }
    r.default = e, a && a.set(e, r);
    return r;
}(require("../../utils/lodash")), s = require("../../utils/tools"), n = require("../../utils/mina"), i = require("../../service/user"), c = require("../../service/analyse"), u = require("mobx-miniprogram-bindings"), o = require("../../utils/functional"), h = p(require("../../store/app")), g = p(require("../../utils/logger")), l = require("../../service/entity"), d = require("../../service/search");

function p(e) {
    return e && e.__esModule ? e : {
        default: e
    };
}

function f(e) {
    if ("function" != typeof WeakMap) return null;
    var t = new WeakMap(), a = new WeakMap();
    return (f = function(e) {
        return e ? a : t;
    })(e);
}

var S, m = {
    page: 1,
    size: 10,
    keyword: "",
    searchErrorMsg: ""
}, y = wx.getSystemInfoSync();

function v(e, t) {
    return e.split(new RegExp("(:?".concat(t, ")"), "ig")).filter(function(e) {
        return !!e;
    }).map(function(e) {
        return t.toLowerCase().trim() === e.toLowerCase().trim() ? {
            text: e,
            highlight: !0
        } : {
            text: e
        };
    });
}

Page({
    data: {
        navigationTitle: "Readhub 搜索",
        resultStyle: "height: calc(100vh - 45px);",
        initTheme: h.default.theme,
        isManager: !1,
        autoFocus: !1,
        isEnterSearch: !1,
        inputValue: "",
        inputFocus: !1,
        searchResultStyle: "height: ".concat(y.windowHeight - 45 - 44 - (y.statusBarHeight || 20), "px;"),
        scrollTop: 0,
        searchSuggests: [],
        isFetchingSuggest: !1,
        searchResults: [],
        isSearching: !1,
        isSearchingMore: !1,
        searchOptions: m,
        isSearchResultLoadEnd: !1,
        defaultInput: "",
        recommendEntityList: [],
        edit_sub_list: [],
        actionsheetList: (0, s.getActionSheet)([ "wechat", "image" ])
    },
    toggleRecommendVisiable: function() {
        var e = this.data.searchSetting;
        e.hideRecommend ? (0, c.report)("search_entrance") : (0, c.report)("search_explorehide"), 
        this.changeSearchSetting({
            hideRecommend: !e.hideRecommend
        });
    },
    removeTag: function(e) {
        var t = e.currentTarget.dataset.index, a = this.data.edit_sub_list;
        a.splice(t, 1), this.setData({
            edit_sub_list: a
        });
    },
    addTag: function() {
        var e = this.data.entitySuggestions, t = this.data.edit_sub_list;
        t.find(function(t) {
            return t.key === e.key;
        }) || t.push(r.omit(e, [ "uid" ])), this.setData({
            edit_sub_list: t
        });
    },
    tapEntityRecommend: function(e) {
        var t = this;
        (0, c.report)("search_explore");
        var a = e.currentTarget.dataset.index, r = this.data.recommendEntityList[+a];
        if (r) {
            var s = r.entityName;
            this.setData({
                inputValue: s,
                inputFocus: !1,
                defaultInput: s,
                isEnterSearch: !0
            }, function() {
                t.search(s, r);
            });
        }
    },
    tapSearchHistory: function(e) {
        var t = this;
        (0, c.report)("search_history");
        var a = e.currentTarget.dataset.index, r = this.data.searchSetting.searchHistory[+a];
        if (r) {
            var s = r.keyword;
            this.setData({
                inputValue: s,
                inputFocus: !1,
                defaultInput: s,
                isEnterSearch: !0
            }, function() {
                t.search(s, r.entity);
            });
        }
    },
    clearSearchHistoty: function() {
        (0, c.report)("search_historyclear"), this.changeSearchSetting({
            searchHistory: []
        });
    },
    addSearchHistory: function(e, t) {
        try {
            if (!this.data.searchSetting) return;
            var a = this.data.searchSetting.searchHistory || [], r = a.findIndex(function(t) {
                return t.keyword === e;
            });
            -1 !== r && a.splice(r, 1), a.unshift({
                keyword: e,
                entity: t
            }), this.changeSearchSetting({
                searchHistory: a.slice(0, 10)
            });
        } catch (e) {
            console.error("addSearchHistory fail", e);
        }
    },
    cleanSearch: function() {
        this.cleanSearchSuggests(), this.clearSearchResult(), this.setData({
            searchOptions: m
        });
    },
    cleanSearchSuggests: function() {
        this._fetchSuggestTimer && clearTimeout(this._fetchSuggestTimer), this.setData({
            searchSuggests: [],
            isFetchingSuggest: !1
        }), this._rCount = (this._rCount || 0) + 1;
    },
    clearSearchResult: function() {
        this.setData({
            searchResults: [],
            isSearching: !1,
            isSearchingMore: !1
        }), this._lastSearchOptions = {};
    },
    loadMoreNews: (0, o.singleExec)(a(t().mark(function e() {
        var a, s;
        return t().wrap(function(e) {
            for (;;) switch (e.prev = e.next) {
              case 0:
                if (!this.data.isSearchResultLoadEnd) {
                    e.next = 2;
                    break;
                }
                return e.abrupt("return");

              case 2:
                return (a = r.cloneDeep(this.data.searchOptions)).page++, this._lastSearchOptions = a, 
                this.setData({
                    isSearchingMore: !0
                }), e.next = 8, (0, d.searchNews)(a);

              case 8:
                if (s = e.sent.data, r.isEqual(a, this._lastSearchOptions)) {
                    e.next = 11;
                    break;
                }
                return e.abrupt("return");

              case 11:
                this.setData({
                    searchResults: this.data.searchResults.concat(s.items),
                    isSearchingMore: !1,
                    searchOptions: a,
                    isSearchResultLoadEnd: s.pageIndex >= s.totalPages
                });

              case 12:
              case "end":
                return e.stop();
            }
        }, e, this);
    })), {
        ignoreErrorToast: !0,
        onError: function() {
            this.setData({
                isSearchingMore: !1
            });
        }
    }),
    fetchCardImage: function(e) {
        var r = this;
        return a(t().mark(function a() {
            var s;
            return t().wrap(function(t) {
                for (;;) switch (t.prev = t.next) {
                  case 0:
                    if (t.prev = 0, e.keyword) {
                        t.next = 3;
                        break;
                    }
                    return t.abrupt("return", r.setData({
                        cardImage: ""
                    }));

                  case 3:
                    return t.next = 5, (0, d.getSearchShareCard)(e.keyword);

                  case 5:
                    s = t.sent.data.items[0].url, r.setData({
                        cardImage: s
                    }), t.next = 13;
                    break;

                  case 9:
                    t.prev = 9, t.t0 = t.catch(0), console.error(t.t0), r.setData({
                        cardImage: ""
                    });

                  case 13:
                  case "end":
                    return t.stop();
                }
            }, a, null, [ [ 0, 9 ] ]);
        }))();
    },
    searchNews: (S = a(t().mark(function e(a, s) {
        var n, i, u;
        return t().wrap(function(e) {
            for (;;) switch (e.prev = e.next) {
              case 0:
                if (console.log("searchNews", a, s), n = {
                    page: 1,
                    size: 10,
                    keyword: a
                }, s && s.entityId && (n.entity_id = s.entityId), this._lastSearchOptions = n, this.setData({
                    isSearching: !0,
                    isSearchResultLoadEnd: !1,
                    searchResults: [],
                    searchOptions: n,
                    searchErrorMsg: ""
                }), e.prev = 5, a) {
                    e.next = 9;
                    break;
                }
                return this.setData({
                    isSearching: !1
                }), e.abrupt("return");

              case 9:
                return this.addSearchHistory(a, s), (0, c.pageView)("/search?query=".concat(a, "&sc=mina")), 
                (0, c.reportSearchEvent)(a), e.next = 14, (0, d.searchNews)(n);

              case 14:
                return i = e.sent, e.next = 17, this.fetchCardImage(n);

              case 17:
                if (u = i.data, r.isEqual(n, this._lastSearchOptions)) {
                    e.next = 20;
                    break;
                }
                return e.abrupt("return");

              case 20:
                this.setData({
                    searchResults: u.items,
                    isSearching: !1,
                    searchOptions: n,
                    entitySuggestions: r.get(u, "self.subSuggest", null),
                    isSearchResultLoadEnd: !u.totalPages || u.pageIndex >= u.totalPages,
                    searchErrorMsg: i.error_msg || ""
                }), e.next = 29;
                break;

              case 23:
                if (e.prev = 23, e.t0 = e.catch(5), console.error(e.t0), r.isEqual(n, this._lastSearchOptions)) {
                    e.next = 28;
                    break;
                }
                return e.abrupt("return");

              case 28:
                this.setData({
                    isSearching: !1
                });

              case 29:
              case "end":
                return e.stop();
            }
        }, e, this, [ [ 5, 23 ] ]);
    })), function(e, t) {
        return S.apply(this, arguments);
    }),
    fetchSearchSuggest: function(s) {
        var n = this;
        this._lastKeyword = s, this._fetchSuggestTimer && clearTimeout(this._fetchSuggestTimer), 
        s ? this._fetchSuggestTimer = setTimeout(a(t().mark(function a() {
            var i, c, u;
            return t().wrap(function(t) {
                for (;;) switch (t.prev = t.next) {
                  case 0:
                    return n.setData({
                        isFetchingSuggest: !0
                    }), i = (n._rCount || 0) + 1, n._rCount = i, t.prev = 3, t.next = 6, (0, d.entitySuggest)(s);

                  case 6:
                    if (c = t.sent, n._lastKeyword === s) {
                        t.next = 9;
                        break;
                    }
                    return t.abrupt("return");

                  case 9:
                    u = (u = r.get(c, "data", [])).map(function(t) {
                        var a = v(t.entityName, s);
                        return e(e({}, t), {}, {
                            views: a
                        });
                    }), i === n._rCount && n.setData({
                        searchSuggests: u,
                        isFetchingSuggest: !1
                    }), t.next = 18;
                    break;

                  case 14:
                    t.prev = 14, t.t0 = t.catch(3), console.error(t.t0), n.setData({
                        searchSuggests: [],
                        isFetchingSuggest: !1
                    });

                  case 18:
                  case "end":
                    return t.stop();
                }
            }, a, null, [ [ 3, 14 ] ]);
        })), 150) : this.setData({
            isFetchingSuggest: !1,
            searchSuggests: []
        });
    },
    onTapEntitySub: function() {
        (0, c.report)("search_subscribe");
    },
    navBack: function() {
        wx.navigateBack();
    },
    scrollTop: function() {
        this.setData({
            scrollTop: 0
        });
    },
    loadMore: function() {
        this.loadMoreNews();
    },
    onInputBlur: function() {
        this.setData({
            inputFocus: !1
        });
    },
    search: function(e, t) {
        this.setData({
            inputValue: e
        }), this.cleanSearchSuggests(), this.searchNews(e, t);
    },
    onInputConfirm: function() {
        var e = this;
        this.setData({
            inputValue: this._value
        }), setTimeout(function() {
            e.search(e.data.inputValue);
        }, 0);
    },
    chooseSuggest: (0, o.singleExec)(function(e) {
        var t = this, a = e.currentTarget.dataset, r = a.keyword, s = a.index, n = this.data.searchSuggests[s];
        this.setData({
            inputValue: r,
            inputFocus: !1,
            defaultInput: r
        }, function() {
            t.search(r, n);
        });
    }),
    onUserInput: function(e) {
        this._value = e.detail.value, this.setData({
            inputValue: e.detail.value
        }), this.fetchSearchSuggest(e.detail.value);
    },
    cleanInput: function() {
        var e = this;
        setTimeout(function() {
            e._value = "", e.cleanSearch(), e.setData({
                inputValue: "",
                defaultInput: "",
                isSearching: !1,
                inputFocus: !0
            });
        }, 100);
    },
    cancelChange: function() {
        this.cleanSearchSuggests(), this.setData({
            isEnterSearch: !0,
            inputFocus: !1,
            inputValue: this.data.searchOptions.keyword,
            defaultInput: this.data.searchOptions.keyword
        });
    },
    leaveSearch: function() {
        this.setData({
            isEnterSearch: !1,
            inputFocus: !1,
            inputValue: ""
        }), this.cleanSearch();
    },
    enterSearch: function() {
        this.triggerEvent("searchStateChange", {
            isEnterSearch: !0
        }), this.setData({
            isEnterSearch: !0
        });
    },
    onInputFocus: function() {
        this._value = this.data.inputValue, this.enterSearch(), this.setData({
            inputFocus: !0
        });
    },
    fetchEntityRecommend: function() {
        var e = this;
        return a(t().mark(function a() {
            var r;
            return t().wrap(function(t) {
                for (;;) switch (t.prev = t.next) {
                  case 0:
                    return t.prev = 0, t.next = 3, (0, l.getRecentRecommendEntities)();

                  case 3:
                    r = t.sent.data.items[0].entityList, e.setData({
                        recommendEntityList: r
                    }), t.next = 10;
                    break;

                  case 7:
                    t.prev = 7, t.t0 = t.catch(0), console.error("fetchEntityRecommend fail", t.t0);

                  case 10:
                  case "end":
                    return t.stop();
                }
            }, a, null, [ [ 0, 7 ] ]);
        }))();
    },
    chooseActionSheet: function(e) {
        if ("image" === e.detail.item.id) {
            var t = this.data.searchOptions;
            wx.navigateTo({
                url: "/pages/share_image?type=search&id=".concat(encodeURIComponent(t.keyword))
            });
        }
    },
    onShare: function() {
        this.selectComponent(".actionsheet").show();
    },
    onShareAppMessage: function() {
        var e = (this.data.inputValue || "").replace(/^\s+|\s+$/g, ""), t = "Readhub 搜索";
        e && (t = "".concat(e, " - Readhub 搜索"));
        var a = {
            title: t,
            path: "/pages/index?search=".concat(encodeURIComponent(e))
        };
        return e && this.data.cardImage && (a.imageUrl = this.data.cardImage, a.title = " "), 
        a;
    },
    onShareTimeline: function() {
        var e = (this.data.inputValue || "").replace(/^\s+|\s+$/g, ""), t = "Readhub 搜索";
        return e && (t = "".concat(e, " 即时搜索")), {
            title: t,
            query: "query=".concat(e)
        };
    },
    goToWxSearch: function() {
        var e = "/pages/manage/wechat_search_effects";
        try {
            var t = (this.data.inputValue || "").replace(/^\s+|\s+$/g, "");
            t && (e += "?keyword=".concat(t));
        } catch (e) {}
        wx.navigateTo({
            url: e
        });
    },
    onUnload: function() {
        this.storeBindings && this.storeBindings.destroyStoreBindings();
    },
    onLoad: function(e) {
        var o = this;
        return a(t().mark(function a() {
            var l, p, f;
            return t().wrap(function(t) {
                for (;;) switch (t.prev = t.next) {
                  case 0:
                    return t.prev = 0, e.scene && (l = (0, s.decodeScene)(e.scene), r.assign(e, l)), 
                    (0, s.decodeOptions)(e), o.options = e, o.storeBindings = (0, u.createStoreBindings)(o, {
                        store: h.default,
                        fields: [ "theme", "searchSetting" ],
                        actions: {
                            changeSearchSetting: "changeSearchSetting"
                        }
                    }), t.next = 7, getApp().appInit();

                  case 7:
                    if (!e.id) {
                        t.next = 13;
                        break;
                    }
                    return t.next = 10, (0, d.getSearchParams)(e.id);

                  case 10:
                    p = t.sent, (f = JSON.parse(r.get(p, "data.items[0].content", "{}"))).query && (e.query = f.query);

                  case 13:
                    o.fetchEntityRecommend(), o.setData({
                        isManager: (0, i.isManager)(),
                        options: e,
                        edit_sub_list: getApp().addTags || []
                    }), (0, n.setBackgroundColor)(h.default.theme), (0, c.CustomScreenView)(), void 0 !== o.options.query && (o.options.query ? (o.setData({
                        defaultInput: o.options.query
                    }), o.enterSearch()) : o.onInputFocus(), o.search(decodeURIComponent(o.options.query))), 
                    o.options.focus && o.onInputFocus(), t.next = 24;
                    break;

                  case 21:
                    t.prev = 21, t.t0 = t.catch(0), g.default.error(t.t0);

                  case 24:
                  case "end":
                    return t.stop();
                }
            }, a, null, [ [ 0, 21 ] ]);
        }))();
    }
});