var e = require("../../@babel/runtime/helpers/regeneratorRuntime"), t = require("../../@babel/runtime/helpers/asyncToGenerator"), r = function(e, t) {
    if (!t && e && e.__esModule) return e;
    if (null === e || "object" != typeof e && "function" != typeof e) return {
        default: e
    };
    var r = h(t);
    if (r && r.has(e)) return r.get(e);
    var n = {}, a = Object.defineProperty && Object.getOwnPropertyDescriptor;
    for (var i in e) if ("default" !== i && Object.prototype.hasOwnProperty.call(e, i)) {
        var s = a ? Object.getOwnPropertyDescriptor(e, i) : null;
        s && (s.get || s.set) ? Object.defineProperty(n, i, s) : n[i] = e[i];
    }
    n.default = e, r && r.set(e, n);
    return n;
}(require("../../utils/lodash")), n = require("../../utils/functional"), a = require("../../utils/tools"), i = require("../../utils/mina"), s = require("mobx-miniprogram-bindings"), o = f(require("../../store/app")), u = f(require("../../utils/logger")), c = require("../../service/analyse");

function f(e) {
    return e && e.__esModule ? e : {
        default: e
    };
}

function h(e) {
    if ("function" != typeof WeakMap) return null;
    var t = new WeakMap(), r = new WeakMap();
    return (h = function(e) {
        return e ? r : t;
    })(e);
}

Page({
    data: {
        navigationTitle: "深色模式",
        inited: !1,
        error: "",
        containerStyle: "",
        options: {},
        initTheme: o.default.theme
    },
    onSystemModeChange: function(e) {
        this.changeThemeMode(e.detail.value ? "system" : "manual", !1);
    },
    changeTheme: function(e) {
        var t = e.currentTarget.dataset.theme;
        this.changeAppTheme(t);
    },
    reload: function() {
        this.setData({
            inited: !1
        }), this.refreshPage();
    },
    refreshPage: (0, n.singleExec)(t(e().mark(function t() {
        return e().wrap(function(e) {
            for (;;) switch (e.prev = e.next) {
              case 0:
                return e.next = 2, getApp().appInit();

              case 2:
                this.setData({
                    error: ""
                });

              case 3:
              case "end":
                return e.stop();
            }
        }, t, this);
    })), {
        onError: function(e) {
            throw e;
        }
    }),
    onShow: function() {
        var r = this;
        return t(e().mark(function t() {
            return e().wrap(function(e) {
                for (;;) switch (e.prev = e.next) {
                  case 0:
                    if (r.data.inited) {
                        e.next = 2;
                        break;
                    }
                    return e.abrupt("return");

                  case 2:
                    return e.prev = 2, e.next = 5, r.refreshPage();

                  case 5:
                    e.next = 10;
                    break;

                  case 7:
                    e.prev = 7, e.t0 = e.catch(2), u.default.error(e.t0);

                  case 10:
                  case "end":
                    return e.stop();
                }
            }, t, null, [ [ 2, 7 ] ]);
        }))();
    },
    onUnload: function() {
        this.storeBindings && this.storeBindings.destroyStoreBindings();
    },
    onLoad: function(n) {
        var u = this;
        return t(e().mark(function t() {
            var f, h, l, d;
            return e().wrap(function(e) {
                for (;;) switch (e.prev = e.next) {
                  case 0:
                    return f = "", e.prev = 1, n.scene && (h = (0, a.decodeScene)(n.scene), r.assign(n, h)), 
                    (0, a.decodeOptions)(n), l = (0, i.getSystemInfo)(), d = l.windowHeight - 44, l.statusBarHeight ? d -= l.statusBarHeight : d -= 20, 
                    u.storeBindings = (0, s.createStoreBindings)(u, {
                        store: o.default,
                        fields: [ "theme", "themeMode" ],
                        actions: {
                            changeThemeMode: "changeThemeMode",
                            changeAppTheme: "changeTheme"
                        }
                    }), e.next = 10, new Promise(function(e) {
                        u.setData({
                            options: n,
                            containerStyle: "height: ".concat(d, "px;")
                        }, e);
                    });

                  case 10:
                    return e.next = 12, u.refreshPage();

                  case 12:
                    (0, c.CustomScreenView)(), (0, i.setBackgroundColor)(o.default.theme, {
                        dark: "#111111",
                        light: "#f5f5f5"
                    }), e.next = 19;
                    break;

                  case 16:
                    e.prev = 16, e.t0 = e.catch(1), f = e.t0.message;

                  case 19:
                    return e.prev = 19, u.setData({
                        error: f,
                        inited: !0
                    }), e.finish(19);

                  case 22:
                  case "end":
                    return e.stop();
                }
            }, t, null, [ [ 1, 16, 19, 22 ] ]);
        }))();
    }
});