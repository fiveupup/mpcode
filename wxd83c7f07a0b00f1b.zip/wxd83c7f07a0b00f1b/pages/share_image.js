var e = require("../@babel/runtime/helpers/regeneratorRuntime"), t = require("../@babel/runtime/helpers/asyncToGenerator"), r = b(require("../utils/lodash")), n = require("../utils/functional"), a = require("../utils/tools"), i = require("../utils/mina"), s = require("../service/analyse"), u = require("../service/user"), o = require("../service/topic"), c = m(require("../service/ad")), f = require("mobx-miniprogram-bindings"), d = m(require("../store/app")), p = m(require("../utils/logger")), l = b(require("../service/stock")), h = require("../service/activity"), g = require("../service/search");

function m(e) {
    return e && e.__esModule ? e : {
        default: e
    };
}

function x(e) {
    if ("function" != typeof WeakMap) return null;
    var t = new WeakMap(), r = new WeakMap();
    return (x = function(e) {
        return e ? r : t;
    })(e);
}

function b(e, t) {
    if (!t && e && e.__esModule) return e;
    if (null === e || "object" != typeof e && "function" != typeof e) return {
        default: e
    };
    var r = x(t);
    if (r && r.has(e)) return r.get(e);
    var n = {}, a = Object.defineProperty && Object.getOwnPropertyDescriptor;
    for (var i in e) if ("default" !== i && Object.prototype.hasOwnProperty.call(e, i)) {
        var s = a ? Object.getOwnPropertyDescriptor(e, i) : null;
        s && (s.get || s.set) ? Object.defineProperty(n, i, s) : n[i] = e[i];
    }
    return n.default = e, r && r.set(e, n), n;
}

Page({
    data: {
        navigationTitle: "Readhub",
        inited: !1,
        error: "",
        containerStyle: "",
        options: {},
        shareImages: [],
        imageIndex: 0,
        refreshTriggerd: !1
    },
    reload: function() {
        var r = this;
        return t(e().mark(function t() {
            return e().wrap(function(e) {
                for (;;) switch (e.prev = e.next) {
                  case 0:
                    return r.setData({
                        inited: !1
                    }), e.prev = 1, e.next = 4, r.refreshPage();

                  case 4:
                    return e.prev = 4, r.setData({
                        inited: !0
                    }), e.finish(4);

                  case 7:
                  case "end":
                    return e.stop();
                }
            }, t, null, [ [ 1, , 4, 7 ] ]);
        }))();
    },
    onSwiperChange: function(e) {
        this.setData({
            imageIndex: e.detail.current
        });
    },
    saveImage: (0, n.singleExec)(t(e().mark(function t() {
        var r, n, a, u;
        return e().wrap(function(e) {
            for (;;) switch (e.prev = e.next) {
              case 0:
                if (r = this.data, n = r.shareImages, a = r.imageIndex, 0 !== n.length) {
                    e.next = 3;
                    break;
                }
                return e.abrupt("return");

              case 3:
                return "sponsor" === this.data.options.type ? (0, s.report)("ad_savepic", {
                    id: this.data.options.name
                }) : (0, s.report)("share_savepic"), wx.showLoading(), e.next = 7, (0, i.downloadAndSaveImageToAlbum)(n[a]);

              case 7:
                u = e.sent, wx.hideLoading(), u && wx.showToast({
                    title: "已保存",
                    icon: "none"
                });

              case 10:
              case "end":
                return e.stop();
            }
        }, t, this);
    })), {
        onError: function() {
            wx.hideLoading();
        }
    }),
    forceRefreshPage: (0, n.singleExec)(t(e().mark(function t() {
        return e().wrap(function(e) {
            for (;;) switch (e.prev = e.next) {
              case 0:
                if (!(0, u.isManager)()) {
                    e.next = 5;
                    break;
                }
                return e.next = 3, this.refreshPage(!0);

              case 3:
                e.next = 6;
                break;

              case 5:
                this.setData({
                    refreshTriggerd: !1
                });

              case 6:
              case "end":
                return e.stop();
            }
        }, t, this);
    }))),
    refreshPage: (0, n.singleExec)(function() {
        var r = t(e().mark(function t(r) {
            var n, a, i, s, f, p, m, x, b, k, v, y, w, _;
            return e().wrap(function(e) {
                for (;;) switch (e.prev = e.next) {
                  case 0:
                    return e.next = 2, getApp().appInit();

                  case 2:
                    if (!(n = this.data.options).image) {
                        e.next = 7;
                        break;
                    }
                    a = [ decodeURIComponent(n.image) ], e.next = 68;
                    break;

                  case 7:
                    if ("entity" !== n.type) {
                        e.next = 14;
                        break;
                    }
                    return e.next = 10, (0, o.getEntityShareImage)(n.id, r);

                  case 10:
                    i = e.sent, a = i.data.items.filter(function(e) {
                        return !!e.url;
                    }).map(function(e) {
                        return e.url;
                    }), e.next = 68;
                    break;

                  case 14:
                    if ("activity" !== n.type) {
                        e.next = 21;
                        break;
                    }
                    return e.next = 17, (0, h.getActivityShareImage)(n.id, r);

                  case 17:
                    s = e.sent, a = s.data.items.filter(function(e) {
                        return !!e.url;
                    }).map(function(e) {
                        return e.url;
                    }), e.next = 68;
                    break;

                  case 21:
                    if ("search" !== n.type) {
                        e.next = 29;
                        break;
                    }
                    return f = decodeURIComponent(n.id), e.next = 25, (0, g.getSearchShareTimeline)(f, r);

                  case 25:
                    p = e.sent, a = p.data.items.filter(function(e) {
                        return !!e.url;
                    }).map(function(e) {
                        return e.url;
                    }), e.next = 68;
                    break;

                  case 29:
                    if ("file_search" !== n.type) {
                        e.next = 38;
                        break;
                    }
                    if (!(m = getApp().globalData._tempSearchOptions)) {
                        e.next = 36;
                        break;
                    }
                    return e.next = 34, l.getFileSearchImage(m, r);

                  case 34:
                    x = e.sent, a = x.data.items.filter(function(e) {
                        return !!e.url;
                    }).map(function(e) {
                        return e.url;
                    });

                  case 36:
                    e.next = 68;
                    break;

                  case 38:
                    if ("tag" !== n.type) {
                        e.next = 47;
                        break;
                    }
                    return e.next = 41, (0, o.getTagShareImage)(n.id, r);

                  case 41:
                    b = e.sent, k = {
                        "readhub/mina_entity": 1,
                        "readhub/mina_entity_dark": 2
                    }, "dark" === d.default.theme && (k = {
                        "readhub/mina_entity_dark": 1,
                        "readhub/mina_entity": 2
                    }), a = b.data.items.filter(function(e) {
                        return !!e.url;
                    }).sort(function(e, t) {
                        var r = k[e.id], n = k[t.id];
                        return r && n ? r - n : 0;
                    }).map(function(e) {
                        return e.url;
                    }), e.next = 68;
                    break;

                  case 47:
                    if ("daily" !== n.type) {
                        e.next = 54;
                        break;
                    }
                    return e.next = 50, (0, u.getDailyImage)(n.ts, r);

                  case 50:
                    v = e.sent.data.items[0].url, a = [ v ], e.next = 68;
                    break;

                  case 54:
                    if ("sponsor" !== n.type) {
                        e.next = 61;
                        break;
                    }
                    return e.next = 57, c.default.getShareImage(n, r);

                  case 57:
                    y = e.sent, a = [ y ], e.next = 68;
                    break;

                  case 61:
                    if ("stock_file" !== n.type) {
                        e.next = 68;
                        break;
                    }
                    return e.next = 64, l.getShareImage(n.id, r);

                  case 64:
                    w = e.sent, _ = {
                        "readhub/mina_stock_timeline": 1,
                        "readhub/mina_stock_timeline_dark": 2
                    }, "dark" === d.default.theme && (_ = {
                        "readhub/mina_stock_timeline_dark": 1,
                        "readhub/mina_stock_timeline": 2
                    }), a = w.data.items.filter(function(e) {
                        return !!e.url;
                    }).sort(function(e, t) {
                        var r = _[e.id], n = _[t.id];
                        return r && n ? r - n : 0;
                    }).map(function(e) {
                        return e.url;
                    });

                  case 68:
                    this.setData({
                        shareImages: a,
                        error: ""
                    });

                  case 69:
                  case "end":
                    return e.stop();
                }
            }, t, this);
        }));
        return function(e) {
            return r.apply(this, arguments);
        };
    }(), {
        onError: function(e) {
            throw e;
        },
        onComplete: function() {
            var e = this;
            setTimeout(function() {
                e.setData({
                    refreshTriggerd: !1
                });
            }, 200);
        }
    }),
    onShow: function() {
        var r = this;
        return t(e().mark(function t() {
            return e().wrap(function(e) {
                for (;;) switch (e.prev = e.next) {
                  case 0:
                    if (r.data.inited) {
                        e.next = 2;
                        break;
                    }
                    return e.abrupt("return");

                  case 2:
                    return e.prev = 2, e.next = 5, r.refreshPage();

                  case 5:
                    e.next = 10;
                    break;

                  case 7:
                    e.prev = 7, e.t0 = e.catch(2), p.default.error(e.t0);

                  case 10:
                  case "end":
                    return e.stop();
                }
            }, t, null, [ [ 2, 7 ] ]);
        }))();
    },
    onUnload: function() {
        this.storeBindings && this.storeBindings.destroyStoreBindings();
    },
    onLoad: function(n) {
        var u = this;
        return t(e().mark(function t() {
            var o, c, p, l;
            return e().wrap(function(e) {
                for (;;) switch (e.prev = e.next) {
                  case 0:
                    return o = "", e.prev = 1, n.scene && (c = (0, a.decodeScene)(n.scene), r.assign(n, c)), 
                    p = (0, i.getSystemInfo)(), l = p.windowHeight - 44, p.statusBarHeight ? l -= p.statusBarHeight : l -= 20, 
                    u.storeBindings = (0, f.createStoreBindings)(u, {
                        store: d.default,
                        fields: [ "theme" ]
                    }), e.next = 9, new Promise(function(e) {
                        u.setData({
                            options: n,
                            containerStyle: "height: ".concat(l, "px;")
                        }, e);
                    });

                  case 9:
                    return e.next = 11, u.refreshPage();

                  case 11:
                    (0, s.CustomScreenView)(), e.next = 17;
                    break;

                  case 14:
                    e.prev = 14, e.t0 = e.catch(1), o = e.t0.message;

                  case 17:
                    return e.prev = 17, u.setData({
                        error: o,
                        inited: !0
                    }), e.finish(17);

                  case 20:
                  case "end":
                    return e.stop();
                }
            }, t, null, [ [ 1, 14, 17, 20 ] ]);
        }))();
    }
});