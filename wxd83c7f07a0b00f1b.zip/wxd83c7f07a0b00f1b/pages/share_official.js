var e, t = require("../@babel/runtime/helpers/regeneratorRuntime"), r = require("../@babel/runtime/helpers/asyncToGenerator"), a = function(e, t) {
    if (!t && e && e.__esModule) return e;
    if (null === e || "object" != typeof e && "function" != typeof e) return {
        default: e
    };
    var r = f(t);
    if (r && r.has(e)) return r.get(e);
    var a = {}, n = Object.defineProperty && Object.getOwnPropertyDescriptor;
    for (var i in e) if ("default" !== i && Object.prototype.hasOwnProperty.call(e, i)) {
        var s = n ? Object.getOwnPropertyDescriptor(e, i) : null;
        s && (s.get || s.set) ? Object.defineProperty(a, i, s) : a[i] = e[i];
    }
    a.default = e, r && r.set(e, a);
    return a;
}(require("../utils/lodash")), n = require("../utils/functional"), i = require("../utils/tools"), s = require("../utils/mina"), o = require("mobx-miniprogram-bindings"), c = (e = require("../store/app")) && e.__esModule ? e : {
    default: e
}, u = require("../service/user"), p = require("../service/topic"), d = require("../service/analyse");

function f(e) {
    if ("function" != typeof WeakMap) return null;
    var t = new WeakMap(), r = new WeakMap();
    return (f = function(e) {
        return e ? r : t;
    })(e);
}

Page({
    data: {
        navigationTitle: "嵌入公众号",
        inited: !1,
        error: "",
        containerStyle: "",
        options: {},
        initTheme: c.default.theme,
        path: "",
        shareImage: "",
        shareImageLoaded: !1
    },
    reload: function() {
        this.setData({
            inited: !1
        }), this.refreshPage();
    },
    refreshPage: (0, n.singleExec)(r(t().mark(function e() {
        var r, n, i, s, o, c, u;
        return t().wrap(function(e) {
            for (;;) switch (e.prev = e.next) {
              case 0:
                return e.next = 2, getApp().appInit();

              case 2:
                if (r = this.data.options, s = "", "topic" !== r.type) {
                    e.next = 18;
                    break;
                }
                if (n = getApp()._tempTopic, getApp()._tempTopic = null, n) {
                    e.next = 11;
                    break;
                }
                return e.next = 10, (0, p.getTopic)(r.id);

              case 10:
                n = e.sent;

              case 11:
                return i = "pages/detail?id=".concat(r.id), e.next = 14, (0, p.topicOfficialShareImage)(r.id);

              case 14:
                o = e.sent.data, s = a.get(o, "items[0].url", ""), e.next = 32;
                break;

              case 18:
                if ("entity" !== r.type) {
                    e.next = 26;
                    break;
                }
                return e.next = 21, (0, p.getEntityTimelineShareImage)(r.id);

              case 21:
                c = e.sent.data, i = "pages/pro/entity_topics?id=".concat(r.id, "&type=10"), s = a.get(c, "items[0].url", ""), 
                e.next = 32;
                break;

              case 26:
                if ("tag" !== r.type) {
                    e.next = 32;
                    break;
                }
                return e.next = 29, (0, p.getTagTimelineShareImage)(r.id);

              case 29:
                u = e.sent.data, i = "pages/pro/entity_topics?id=".concat(r.id, "&type=22"), s = a.get(u, "items[0].url", "");

              case 32:
                this.setData({
                    error: "",
                    path: i,
                    shareImage: s
                });

              case 33:
              case "end":
                return e.stop();
            }
        }, e, this);
    })), {
        onError: function(e) {
            throw e;
        }
    }),
    onShow: function() {
        var e = this;
        return r(t().mark(function r() {
            return t().wrap(function(t) {
                for (;;) switch (t.prev = t.next) {
                  case 0:
                    if (e.data.inited) {
                        t.next = 2;
                        break;
                    }
                    return t.abrupt("return");

                  case 2:
                    return t.prev = 2, t.next = 5, e.refreshPage();

                  case 5:
                    t.next = 10;
                    break;

                  case 7:
                    t.prev = 7, t.t0 = t.catch(2), console.error(t.t0);

                  case 10:
                  case "end":
                    return t.stop();
                }
            }, r, null, [ [ 2, 7 ] ]);
        }))();
    },
    saveImage: (0, n.singleExec)(r(t().mark(function e() {
        var r;
        return t().wrap(function(e) {
            for (;;) switch (e.prev = e.next) {
              case 0:
                if (this.data.shareImage) {
                    e.next = 2;
                    break;
                }
                return e.abrupt("return");

              case 2:
                return wx.showLoading(), e.next = 5, (0, s.downloadAndSaveImageToAlbum)(this.data.shareImage);

              case 5:
                r = e.sent, wx.hideLoading(), r && wx.showToast({
                    title: "已保存",
                    icon: "none"
                });

              case 8:
              case "end":
                return e.stop();
            }
        }, e, this);
    })), {
        onError: function() {
            wx.hideLoading();
        }
    }),
    copyValue: function(e) {
        var t = e.currentTarget.dataset.value;
        wx.setClipboardData({
            data: t,
            success: function() {
                wx.showToast({
                    title: "已复制",
                    icon: "none"
                });
            }
        });
    },
    onShareImageLoad: function() {
        this.setData({
            shareImageLoaded: !0
        });
    },
    onPullDownRefresh: (0, n.singleExec)(r(t().mark(function e() {
        var r, n, i, s, o, c, d;
        return t().wrap(function(e) {
            for (;;) switch (e.prev = e.next) {
              case 0:
                if ((0, u.isManager)()) {
                    e.next = 2;
                    break;
                }
                return e.abrupt("return");

              case 2:
                if ("topic" !== (r = this.data.options).type) {
                    e.next = 11;
                    break;
                }
                return e.next = 6, (0, p.topicOfficialShareImage)(r.id, !0);

              case 6:
                n = e.sent.data, i = a.get(n, "items[0].url", ""), this.setData({
                    shareImage: i
                }), e.next = 25;
                break;

              case 11:
                if ("entity" !== r.type) {
                    e.next = 19;
                    break;
                }
                return e.next = 14, (0, p.getEntityTimelineShareImage)(r.id, !0);

              case 14:
                s = e.sent.data, o = a.get(s, "items[0].url", ""), this.setData({
                    shareImage: o
                }), e.next = 25;
                break;

              case 19:
                if ("tag" !== r.type) {
                    e.next = 25;
                    break;
                }
                return e.next = 22, (0, p.getTagTimelineShareImage)(r.id, !0);

              case 22:
                c = e.sent.data, d = a.get(c, "items[0].url", ""), this.setData({
                    shareImage: d
                });

              case 25:
              case "end":
                return e.stop();
            }
        }, e, this);
    })), {
        onComplete: function() {
            wx.stopPullDownRefresh();
        }
    }),
    copyAppidAndPath: function() {
        wx.setClipboardData({
            data: "wxd83c7f07a0b00f1b\n".concat(this.data.path),
            success: function() {
                wx.showToast({
                    title: "已复制",
                    icon: "none"
                });
            }
        });
    },
    onUnload: function() {
        this.storeBindings && this.storeBindings.destroyStoreBindings();
    },
    onLoad: function(e) {
        var n = this;
        return r(t().mark(function r() {
            var u, p, f, h;
            return t().wrap(function(t) {
                for (;;) switch (t.prev = t.next) {
                  case 0:
                    return u = "", t.prev = 1, e.scene && (p = (0, i.decodeScene)(e.scene), a.assign(e, p)), 
                    f = (0, s.getSystemInfo)(), h = f.windowHeight - 44 - (f.statusBarHeight || 20), 
                    n.storeBindings = (0, o.createStoreBindings)(n, {
                        store: c.default,
                        fields: [ "theme" ]
                    }), t.next = 8, new Promise(function(t) {
                        n.setData({
                            options: e,
                            containerStyle: "min-height: ".concat(h, "px;")
                        }, t);
                    });

                  case 8:
                    return t.next = 10, n.refreshPage();

                  case 10:
                    (0, d.CustomScreenView)(), (0, s.setBackgroundColor)(c.default.theme, {
                        dark: "#111111",
                        light: "#ffffff"
                    }), t.next = 17;
                    break;

                  case 14:
                    t.prev = 14, t.t0 = t.catch(1), u = t.t0.message;

                  case 17:
                    return t.prev = 17, n.setData({
                        error: u,
                        inited: !0
                    }), t.finish(17);

                  case 20:
                  case "end":
                    return t.stop();
                }
            }, r, null, [ [ 1, 14, 17, 20 ] ]);
        }))();
    }
});