var e, t = require("../@babel/runtime/helpers/regeneratorRuntime"), r = require("../@babel/runtime/helpers/asyncToGenerator"), n = function(e, t) {
    if (!t && e && e.__esModule) return e;
    if (null === e || "object" != typeof e && "function" != typeof e) return {
        default: e
    };
    var r = l(t);
    if (r && r.has(e)) return r.get(e);
    var n = {}, a = Object.defineProperty && Object.getOwnPropertyDescriptor;
    for (var i in e) if ("default" !== i && Object.prototype.hasOwnProperty.call(e, i)) {
        var o = a ? Object.getOwnPropertyDescriptor(e, i) : null;
        o && (o.get || o.set) ? Object.defineProperty(n, i, o) : n[i] = e[i];
    }
    n.default = e, r && r.set(e, n);
    return n;
}(require("../utils/lodash")), a = require("../utils/functional"), i = require("../utils/tools"), o = require("../utils/mina"), s = require("../service/analyse"), c = require("mobx-miniprogram-bindings"), u = (e = require("../store/app")) && e.__esModule ? e : {
    default: e
}, f = require("../service/wallet"), p = require("../service/user"), h = (require("../constant"), 
require("../service/giftCard"));

function l(e) {
    if ("function" != typeof WeakMap) return null;
    var t = new WeakMap(), r = new WeakMap();
    return (l = function(e) {
        return e ? r : t;
    })(e);
}

Page({
    data: {
        navigationTitle: "Readhub",
        inited: !1,
        error: "",
        containerStyle: "",
        options: {},
        initTheme: u.default.theme,
        isIOS: (0, o.isIOS)(),
        balance: 0,
        isManager: !1,
        actionsheetList: (0, i.getActionSheet)([ "wechat", "image" ]),
        supportGetUserProfile: !!wx.getUserProfile
    },
    getUserProfile: (0, a.singleExec)(r(t().mark(function e() {
        var r, n;
        return t().wrap(function(e) {
            for (;;) switch (e.prev = e.next) {
              case 0:
                return e.next = 2, null === (r = this.selectComponent("#user-data-views")) || void 0 === r ? void 0 : r.getUserProfile();

              case 2:
                if (!(n = e.sent)) {
                    e.next = 8;
                    break;
                }
                return e.next = 6, getApp().updateUserInfo(n);

              case 6:
                return e.next = 8, this.refreshPage();

              case 8:
              case "end":
                return e.stop();
            }
        }, e, this);
    }))),
    onPrivacyPolicy: function() {
        wx.openPrivacyContract ? wx.openPrivacyContract() : wx.showToast({
            title: "微信版本过低，请升级微信到最新版本。",
            icon: "none",
            duration: 3e3
        });
    },
    onNewUpdateUserProfile: function(e) {
        var n = this;
        return r(t().mark(function r() {
            var a;
            return t().wrap(function(t) {
                for (;;) switch (t.prev = t.next) {
                  case 0:
                    return a = e.detail.userInfo, t.next = 3, getApp().updateUserInfo(a);

                  case 3:
                    return t.next = 5, n.refreshPage();

                  case 5:
                  case "end":
                    return t.stop();
                }
            }, r);
        }))();
    },
    onGetUserInfo: function(e) {
        var n = this;
        return r(t().mark(function r() {
            var a;
            return t().wrap(function(t) {
                for (;;) switch (t.prev = t.next) {
                  case 0:
                    return a = e.detail.userInfo, t.next = 3, getApp().updateUserInfo(a);

                  case 3:
                    return t.next = 5, n.refreshPage();

                  case 5:
                  case "end":
                    return t.stop();
                }
            }, r);
        }))();
    },
    onActionSheetHide: function() {
        wx.hideShareMenu && wx.hideShareMenu();
    },
    chooseActionSheet: function(e) {
        "image" === e.detail.item.id && wx.navigateTo({
            url: "/pages/share_image?image=".concat(encodeURIComponent("/images/share-timeline.png"))
        });
    },
    onShareAppMessage: function() {
        return {
            title: "科技新闻阅读，每天 3 分钟",
            path: "/pages/index",
            imageUrl: "https://cdn.readhub.cn/mina/share-to-friend.png",
            success: function() {
                logger.log("share success");
            },
            error: function() {
                logger.log("share error");
            }
        };
    },
    onShareApp: function() {
        wx.showShareMenu && wx.showShareMenu(), this.selectComponent(".actionsheet").show();
    },
    goToJoinPro: function() {
        var e = this.selectComponent("#layout").getLoginManager();
        if (e.needLogin()) return e.show();
        wx.navigateTo({
            url: "/pages/pro/join"
        });
    },
    reload: function() {
        var e = this;
        return r(t().mark(function r() {
            return t().wrap(function(t) {
                for (;;) switch (t.prev = t.next) {
                  case 0:
                    return e.setData({
                        inited: !1
                    }), t.prev = 1, t.next = 4, e.refreshPage();

                  case 4:
                    return t.prev = 4, e.setData({
                        inited: !0
                    }), t.finish(4);

                  case 7:
                  case "end":
                    return t.stop();
                }
            }, r, null, [ [ 1, , 4, 7 ] ]);
        }))();
    },
    fetchCardList: function() {
        var e = this;
        return r(t().mark(function r() {
            var n, a;
            return t().wrap(function(t) {
                for (;;) switch (t.prev = t.next) {
                  case 0:
                    return t.next = 2, (0, h.fetchCardList)(1);

                  case 2:
                    (n = t.sent).list.length && (a = {
                        count: n.unusedCount
                    }, e.setData({
                        yearCard: a
                    }));

                  case 4:
                  case "end":
                    return t.stop();
                }
            }, r);
        }))();
    },
    fetchBalance: function() {
        var e = this;
        return r(t().mark(function r() {
            var n;
            return t().wrap(function(t) {
                for (;;) switch (t.prev = t.next) {
                  case 0:
                    return t.prev = 0, t.next = 3, (0, f.getBalance)();

                  case 3:
                    n = t.sent, e.setData({
                        balance: n.data.items[0] ? n.data.items[0].balance : 0
                    }), t.next = 10;
                    break;

                  case 7:
                    t.prev = 7, t.t0 = t.catch(0), console.error(t.t0);

                  case 10:
                  case "end":
                    return t.stop();
                }
            }, r, null, [ [ 0, 7 ] ]);
        }))();
    },
    goToPro: function() {
        var e = this.selectComponent("#layout").getLoginManager();
        if (e.needLogin()) return e.show();
        this.data.userInfo.isVip ? wx.navigateTo({
            url: "/pages/pro/subscription"
        }) : wx.navigateTo({
            url: "/pages/pro/join"
        }), (0, s.report)("Subscribe", {
            label: "Feat_button"
        });
    },
    goToSubscribeOfficialAccount: function() {
        (0, s.report)("flow_guide_click"), wx.navigateTo({
            url: "/pages/webview?url=".concat(encodeURIComponent("https://mp.weixin.qq.com/s/_U6Icv_5_NyXeOv5zhV0nQ"))
        });
    },
    refreshPage: (0, a.singleExec)(r(t().mark(function e() {
        return t().wrap(function(e) {
            for (;;) switch (e.prev = e.next) {
              case 0:
                return e.next = 2, getApp().appInit();

              case 2:
                this.fetchBalance(), this.fetchCardList(), this.setData({
                    error: "",
                    isManager: (0, p.isManager)()
                });

              case 5:
              case "end":
                return e.stop();
            }
        }, e, this);
    })), {
        onError: function(e) {
            throw e;
        }
    }),
    onShow: function() {
        var e = this;
        return r(t().mark(function r() {
            return t().wrap(function(t) {
                for (;;) switch (t.prev = t.next) {
                  case 0:
                    if (e.data.inited) {
                        t.next = 2;
                        break;
                    }
                    return t.abrupt("return");

                  case 2:
                    return t.prev = 2, t.next = 5, e.refreshPage();

                  case 5:
                    t.next = 10;
                    break;

                  case 7:
                    t.prev = 7, t.t0 = t.catch(2), console.error(t.t0);

                  case 10:
                  case "end":
                    return t.stop();
                }
            }, r, null, [ [ 2, 7 ] ]);
        }))();
    },
    goToBalance: function() {
        var e = this.selectComponent("#layout").getLoginManager();
        if (e.needLogin()) return e.show();
        wx.navigateTo({
            url: "/pages/user/balance"
        });
    },
    goToLabFeedback: function() {
        wx.navigateTo({
            url: "/pages/manage/feedback"
        });
    },
    onSummaryVisibleChange: function(e) {
        this.toggleHideSummary(e.detail.value);
    },
    onUnload: function() {
        this.storeBindings && this.storeBindings.destroyStoreBindings();
    },
    onLoad: function(e) {
        var a = this;
        return r(t().mark(function r() {
            var f, p, h, l;
            return t().wrap(function(t) {
                for (;;) switch (t.prev = t.next) {
                  case 0:
                    return f = "", t.prev = 1, e.scene && (p = (0, i.decodeScene)(e.scene), n.assign(e, p)), 
                    (0, i.decodeOptions)(e), h = (0, o.getSystemInfo)(), l = h.windowHeight - 44 - (h.statusBarHeight || 20), 
                    a.storeBindings = (0, c.createStoreBindings)(a, {
                        store: u.default,
                        fields: [ "theme", "userInfo", "pro", "isHideSummary", "themeMode", "subscribeState" ],
                        actions: {
                            changeTheme: "changeTheme",
                            toggleHideSummary: "toggleHideSummary"
                        }
                    }), wx.hideShareMenu && wx.hideShareMenu(), t.next = 10, new Promise(function(t) {
                        a.setData({
                            options: e,
                            containerStyle: "min-height: ".concat(l, "px;")
                        }, t);
                    });

                  case 10:
                    return t.next = 12, a.refreshPage();

                  case 12:
                    (0, s.CustomScreenView)(), t.next = 18;
                    break;

                  case 15:
                    t.prev = 15, t.t0 = t.catch(1), f = t.t0.message;

                  case 18:
                    return t.prev = 18, a.setData({
                        error: f,
                        inited: !0
                    }), t.finish(18);

                  case 21:
                  case "end":
                    return t.stop();
                }
            }, r, null, [ [ 1, 15, 18, 21 ] ]);
        }))();
    }
});