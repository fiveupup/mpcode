var e = require("../../@babel/runtime/helpers/regeneratorRuntime"), t = require("../../@babel/runtime/helpers/asyncToGenerator"), n = function(e, t) {
    if (!t && e && e.__esModule) return e;
    if (null === e || "object" != typeof e && "function" != typeof e) return {
        default: e
    };
    var n = d(t);
    if (n && n.has(e)) return n.get(e);
    var r = {}, a = Object.defineProperty && Object.getOwnPropertyDescriptor;
    for (var o in e) if ("default" !== o && Object.prototype.hasOwnProperty.call(e, o)) {
        var s = a ? Object.getOwnPropertyDescriptor(e, o) : null;
        s && (s.get || s.set) ? Object.defineProperty(r, o, s) : r[o] = e[o];
    }
    r.default = e, n && n.set(e, r);
    return r;
}(require("../../utils/lodash")), r = require("../../utils/functional"), a = require("../../utils/tools"), o = require("../../utils/mina"), s = require("../../service/analyse"), i = require("mobx-miniprogram-bindings"), c = p(require("../../store/app")), u = p(require("../../service/ad"));

function p(e) {
    return e && e.__esModule ? e : {
        default: e
    };
}

function d(e) {
    if ("function" != typeof WeakMap) return null;
    var t = new WeakMap(), n = new WeakMap();
    return (d = function(e) {
        return e ? n : t;
    })(e);
}

Page({
    data: {
        navigationTitle: "Readhub 赞助商",
        inited: !1,
        error: "",
        containerStyle: "",
        options: {},
        initTheme: c.default.theme,
        sponsor: null,
        actionsheetList: (0, a.getActionSheet)([ "wechat", "image" ])
    },
    chooseActionSheet: function(e) {
        var t = e.detail.item;
        if ("image" === t.id) {
            var n = this.data.sponsor;
            if (!n) return;
            var r = n.slogan[Math.floor(Math.random() * n.slogan.length)];
            wx.navigateTo({
                url: "/pages/share_image?type=sponsor&title=".concat(encodeURIComponent(n.Name), "&desc=").concat(encodeURIComponent(r), "&link=").concat(encodeURIComponent("pages/sponsor/detail?sponsor=" + n.english_name))
            });
        } else "copy" === t.id && wx.setClipboardData({
            data: decodeURIComponent(t.url),
            success: function() {
                wx.showToast({
                    title: "链接已复制",
                    icon: "none"
                });
            }
        });
    },
    getLink: function(e) {
        var t = this;
        e.currentTarget.dataset.report && (0, s.report)(e.currentTarget.dataset.report);
        var n = e.currentTarget.dataset, r = n.id, o = n.url, i = (0, a.getActionSheet)([ "copy" ])[0];
        i.url = o, this.setData({
            actionsheetList: [ i, {
                id: "kefu",
                label: "客服消息打开",
                kefuData: {
                    title: "",
                    path: "/pages/sponsor/detail?sponsor=".concat(r, "&func_echo=").concat(o),
                    image: "/images/contact-send.png",
                    session: ""
                },
                icon: "/images/icon-share-py@3x.png"
            } ]
        }, function() {
            t.selectComponent(".actionsheet").show();
        });
    },
    share: function() {
        var e = this;
        this.setData({
            actionsheetList: (0, a.getActionSheet)([ "wechat", "image" ])
        }, function() {
            e.selectComponent(".actionsheet").show();
        });
    },
    beSponsor: function() {
        (0, s.report)("ad_sponsor");
    },
    onUserAction: function(e) {
        var t = e.currentTarget.dataset, n = t.type, r = t.path, a = t.appid;
        e.currentTarget.dataset.report && (0, s.report)(e.currentTarget.dataset.report), 
        "mina" === n && wx.navigateToMiniProgram({
            appId: a,
            path: r || ""
        });
    },
    navToOfficial: function(e) {
        var t = e.currentTarget.dataset.url;
        (0, s.report)("sponsor_gzh"), wx.navigateTo({
            url: "/pages/webview?url=".concat(encodeURIComponent(t))
        });
    },
    onShareTimeline: function() {
        return {
            title: this.data.sponsor ? "Readhub 年度赞助商：".concat(this.data.sponsor.Name) : "Readhub 年度赞助商",
            query: this.data.sponsor ? "sponsor=".concat(this.data.sponsor.english_name) : ""
        };
    },
    onShareAppMessage: function() {
        var e = this.data.sponsor;
        return {
            title: "Readhub 年度赞助商",
            path: "/pages/sponsor/detail?sponsor=".concat(e.english_name),
            success: function() {
                logger.log("share success");
            },
            error: function() {
                logger.log("share error");
            }
        };
    },
    reload: function() {
        var n = this;
        return t(e().mark(function t() {
            return e().wrap(function(e) {
                for (;;) switch (e.prev = e.next) {
                  case 0:
                    return n.setData({
                        inited: !1
                    }), e.prev = 1, e.next = 4, n.refreshPage();

                  case 4:
                    return e.prev = 4, n.setData({
                        inited: !0
                    }), e.finish(4);

                  case 7:
                  case "end":
                    return e.stop();
                }
            }, t, null, [ [ 1, , 4, 7 ] ]);
        }))();
    },
    refreshPage: (0, r.singleExec)(t(e().mark(function t() {
        var n, r;
        return e().wrap(function(e) {
            for (;;) switch (e.prev = e.next) {
              case 0:
                return e.next = 2, getApp().appInit();

              case 2:
                if (0 !== u.default._ads.length) {
                    e.next = 5;
                    break;
                }
                return e.next = 5, u.default.getAds();

              case 5:
                if (n = decodeURIComponent(this.data.options.sponsor), r = u.default._ads.find(function(e) {
                    return e.english_name === n;
                })) {
                    e.next = 9;
                    break;
                }
                throw new Error("赞助商不存在");

              case 9:
                this.setData({
                    error: "",
                    sponsor: r
                });

              case 10:
              case "end":
                return e.stop();
            }
        }, t, this);
    })), {
        onError: function(e) {
            throw e;
        }
    }),
    onShow: function() {
        var n = this;
        return t(e().mark(function t() {
            return e().wrap(function(e) {
                for (;;) switch (e.prev = e.next) {
                  case 0:
                    if (n.data.inited) {
                        e.next = 2;
                        break;
                    }
                    return e.abrupt("return");

                  case 2:
                    return e.prev = 2, e.next = 5, n.refreshPage();

                  case 5:
                    e.next = 10;
                    break;

                  case 7:
                    e.prev = 7, e.t0 = e.catch(2), console.error(e.t0);

                  case 10:
                  case "end":
                    return e.stop();
                }
            }, t, null, [ [ 2, 7 ] ]);
        }))();
    },
    onUnload: function() {
        this.storeBindings && this.storeBindings.destroyStoreBindings();
    },
    onLoad: function(r) {
        var u = this;
        return t(e().mark(function t() {
            var p, d, h, l;
            return e().wrap(function(e) {
                for (;;) switch (e.prev = e.next) {
                  case 0:
                    return p = "", e.prev = 1, r.scene && (d = (0, a.decodeScene)(r.scene), n.assign(r, d)), 
                    (0, a.decodeOptions)(r), h = (0, o.getSystemInfo)(), l = h.windowHeight - 44 - (h.statusBarHeight || 20), 
                    u.storeBindings = (0, i.createStoreBindings)(u, {
                        store: c.default,
                        fields: [ "theme" ]
                    }), e.next = 9, new Promise(function(e) {
                        u.setData({
                            options: r,
                            containerStyle: "min-height: ".concat(l, "px;")
                        }, e);
                    });

                  case 9:
                    return e.next = 11, u.refreshPage();

                  case 11:
                    (0, s.CustomScreenView)(), e.next = 17;
                    break;

                  case 14:
                    e.prev = 14, e.t0 = e.catch(1), p = e.t0.message;

                  case 17:
                    return e.prev = 17, u.setData({
                        error: p,
                        inited: !0
                    }), e.finish(17);

                  case 20:
                  case "end":
                    return e.stop();
                }
            }, t, null, [ [ 1, 14, 17, 20 ] ]);
        }))();
    }
});