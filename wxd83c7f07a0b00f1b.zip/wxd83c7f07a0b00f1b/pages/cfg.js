var e, t = require("../@babel/runtime/helpers/regeneratorRuntime"), r = require("../@babel/runtime/helpers/asyncToGenerator"), n = function(e, t) {
    if (!t && e && e.__esModule) return e;
    if (null === e || "object" != typeof e && "function" != typeof e) return {
        default: e
    };
    var r = g(t);
    if (r && r.has(e)) return r.get(e);
    var n = {}, a = Object.defineProperty && Object.getOwnPropertyDescriptor;
    for (var i in e) if ("default" !== i && Object.prototype.hasOwnProperty.call(e, i)) {
        var s = a ? Object.getOwnPropertyDescriptor(e, i) : null;
        s && (s.get || s.set) ? Object.defineProperty(n, i, s) : n[i] = e[i];
    }
    n.default = e, r && r.set(e, n);
    return n;
}(require("../utils/lodash")), a = require("../utils/functional"), i = require("../utils/tools"), s = require("../utils/mina"), o = require("mobx-miniprogram-bindings"), c = (e = require("../store/app")) && e.__esModule ? e : {
    default: e
}, u = require("../service/subscribe"), f = require("../service/manager");

function g(e) {
    if ("function" != typeof WeakMap) return null;
    var t = new WeakMap(), r = new WeakMap();
    return (g = function(e) {
        return e ? r : t;
    })(e);
}

Page({
    data: {
        navigationTitle: "配置",
        inited: !1,
        error: "",
        containerStyle: "",
        options: {},
        initTheme: c.default.theme,
        storageDesc: "",
        storageKeys: []
    },
    onDebugChange: function(e) {
        wx.setEnableDebug({
            enableDebug: e.detail.value
        });
    },
    cancelVip: (0, a.singleExec)(r(t().mark(function e() {
        return t().wrap(function(e) {
            for (;;) switch (e.prev = e.next) {
              case 0:
                return wx.showLoading(), e.next = 3, (0, f.cancelVip)();

              case 3:
                return e.next = 5, getApp().getUserProfile();

              case 5:
                wx.hideLoading(), wx.showToast({
                    title: "已取消",
                    icon: "none"
                });

              case 7:
              case "end":
                return e.stop();
            }
        }, e);
    }))),
    onIOSChange: function(e) {
        this.changeSetting({
            isIOS: e.detail.value
        });
    },
    cleanTemplate: (0, a.singleExec)(function() {
        var e = r(t().mark(function e(r) {
            var n;
            return t().wrap(function(e) {
                for (;;) switch (e.prev = e.next) {
                  case 0:
                    return n = r.currentTarget.dataset.id, wx.showLoading(), e.next = 4, (0, u.cleanSubscribeMessages)([ n ]);

                  case 4:
                    return e.next = 6, getApp().fetchSubscribeTemplate();

                  case 6:
                    wx.hideLoading();

                  case 7:
                  case "end":
                    return e.stop();
                }
            }, e);
        }));
        return function(t) {
            return e.apply(this, arguments);
        };
    }()),
    copyStorageValue: function(e) {
        var t = e.currentTarget.dataset.key, r = wx.getStorageSync(t);
        wx.setClipboardData({
            data: JSON.stringify(r),
            success: function(e) {
                wx.showToast({
                    title: "已复制",
                    icon: "none"
                });
            }
        });
    },
    getStorageInfo: function() {
        var e = wx.getStorageInfoSync();
        this.setData({
            storageDesc: "".concat(e.currentSize, "KB/").concat(e.limitSize, "KB"),
            storageKeys: e.keys
        });
    },
    cleanStorage: function() {
        wx.clearStorageSync(), this.getStorageInfo();
    },
    cleanStorageKey: function(e) {
        var t = e.currentTarget.dataset.key;
        wx.removeStorageSync(t), this.getStorageInfo();
    },
    reload: function() {
        var e = this;
        return r(t().mark(function r() {
            return t().wrap(function(t) {
                for (;;) switch (t.prev = t.next) {
                  case 0:
                    return e.setData({
                        inited: !1
                    }), t.prev = 1, t.next = 4, e.refreshPage();

                  case 4:
                    return t.prev = 4, e.setData({
                        inited: !0
                    }), t.finish(4);

                  case 7:
                  case "end":
                    return t.stop();
                }
            }, r, null, [ [ 1, , 4, 7 ] ]);
        }))();
    },
    refreshPage: (0, a.singleExec)(r(t().mark(function e() {
        return t().wrap(function(e) {
            for (;;) switch (e.prev = e.next) {
              case 0:
                return e.next = 2, getApp().appInit();

              case 2:
                this.getStorageInfo(), this.setData({
                    error: "",
                    systemInfo: (0, s.getSystemInfo)()
                });

              case 4:
              case "end":
                return e.stop();
            }
        }, e, this);
    })), {
        onError: function(e) {
            throw e;
        }
    }),
    onShow: function() {
        var e = this;
        return r(t().mark(function r() {
            return t().wrap(function(t) {
                for (;;) switch (t.prev = t.next) {
                  case 0:
                    if (e.data.inited) {
                        t.next = 2;
                        break;
                    }
                    return t.abrupt("return");

                  case 2:
                    return t.prev = 2, t.next = 5, e.refreshPage();

                  case 5:
                    t.next = 10;
                    break;

                  case 7:
                    t.prev = 7, t.t0 = t.catch(2), console.error(t.t0);

                  case 10:
                  case "end":
                    return t.stop();
                }
            }, r, null, [ [ 2, 7 ] ]);
        }))();
    },
    onUnload: function() {
        this.storeBindings && this.storeBindings.destroyStoreBindings();
    },
    authTemplate: (0, a.singleExec)(function() {
        var e = r(t().mark(function e(r) {
            var n;
            return t().wrap(function(e) {
                for (;;) switch (e.prev = e.next) {
                  case 0:
                    return n = r.currentTarget.dataset.type, e.next = 3, this.selectComponent("#subscribeMessage").auth([ n ]);

                  case 3:
                  case "end":
                    return e.stop();
                }
            }, e, this);
        }));
        return function(t) {
            return e.apply(this, arguments);
        };
    }()),
    onLoad: function(e) {
        var a = this;
        return r(t().mark(function r() {
            var u, f, g, p;
            return t().wrap(function(t) {
                for (;;) switch (t.prev = t.next) {
                  case 0:
                    return u = "", t.prev = 1, e.scene && (f = (0, i.decodeScene)(e.scene), n.assign(e, f)), 
                    (0, i.decodeOptions)(e), g = (0, s.getSystemInfo)(), p = g.windowHeight - 44 - (g.statusBarHeight || 20), 
                    a.storeBindings = (0, o.createStoreBindings)(a, {
                        store: c.default,
                        fields: [ "theme", "setting", "templates", "userInfo" ],
                        actions: {
                            changeSetting: "changeSetting"
                        }
                    }), wx.hideShareMenu && wx.hideShareMenu(), t.next = 10, new Promise(function(t) {
                        a.setData({
                            options: e,
                            containerStyle: "min-height: ".concat(p, "px;")
                        }, t);
                    });

                  case 10:
                    return t.next = 12, a.refreshPage();

                  case 12:
                    t.next = 17;
                    break;

                  case 14:
                    t.prev = 14, t.t0 = t.catch(1), u = t.t0.message;

                  case 17:
                    return t.prev = 17, a.setData({
                        error: u,
                        inited: !0
                    }), t.finish(17);

                  case 20:
                  case "end":
                    return t.stop();
                }
            }, r, null, [ [ 1, 14, 17, 20 ] ]);
        }))();
    }
});