var e = require("../../@babel/runtime/helpers/slicedToArray");

Page({
    onLoad: function(r) {
        var a = decodeURIComponent(r.q);
        /readhub.cn\/pro/.test(a) && function(r) {
            var a = r.split("?"), u = e(a, 2)[1].split("&").reduce(function(r, a) {
                var u = a.split("="), c = e(u, 2), d = c[0], t = c[1];
                return r[d] = t, r;
            }, {});
            if ("duku" === u.f) return c = u.code, void wx.redirectTo({
                url: "/subpackages/exchange/duku/duku?code=".concat(c)
            });
            var c;
            if ("readhub_year" === u.f) return d = u.id, void wx.redirectTo({
                url: "/subpackages/exchange/readhub_year/readhub_year?id=".concat(d)
            });
            var d;
        }(a);
    }
});