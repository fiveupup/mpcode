(global["webpackJsonp"] = global["webpackJsonp"] || []).push([ [ "uni_modules/almost-lottery/components/almost-lottery/almost-lottery" ], {
    /***/ 247: 
    /*!********************************************************************************************************!*\
  !*** /Users/feajun/riqianguan/uni_modules/almost-lottery/components/almost-lottery/almost-lottery.vue ***!
  \********************************************************************************************************/
    /*! no static exports found */
    /***/ function(module, __webpack_exports__, __webpack_require__) {
        "use strict";
        __webpack_require__.r(__webpack_exports__);
        /* harmony import */        var _almost_lottery_vue_vue_type_template_id_34b92f46_scoped_true___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./almost-lottery.vue?vue&type=template&id=34b92f46&scoped=true& */ 248);
        /* harmony import */        var _almost_lottery_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./almost-lottery.vue?vue&type=script&lang=js& */ 250);
        /* harmony reexport (unknown) */        for (var __WEBPACK_IMPORT_KEY__ in _almost_lottery_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__) if ([ "default" ].indexOf(__WEBPACK_IMPORT_KEY__) < 0) (function(key) {
            __webpack_require__.d(__webpack_exports__, key, function() {
                return _almost_lottery_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__[key];
            });
        })(__WEBPACK_IMPORT_KEY__);
        /* harmony import */        var _almost_lottery_vue_vue_type_style_index_0_id_34b92f46_lang_scss_scoped_true___WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./almost-lottery.vue?vue&type=style&index=0&id=34b92f46&lang=scss&scoped=true& */ 252);
        /* harmony import */        var _Applications_HBuilderX_app_Contents_HBuilderX_plugins_uniapp_cli_node_modules_dcloudio_vue_cli_plugin_uni_packages_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../../../../../../Applications/HBuilderX.app/Contents/HBuilderX/plugins/uniapp-cli/node_modules/@dcloudio/vue-cli-plugin-uni/packages/vue-loader/lib/runtime/componentNormalizer.js */ 32);
        var renderjs
        /* normalize component */;
        var component = Object(_Applications_HBuilderX_app_Contents_HBuilderX_plugins_uniapp_cli_node_modules_dcloudio_vue_cli_plugin_uni_packages_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_3__["default"])(_almost_lottery_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__["default"], _almost_lottery_vue_vue_type_template_id_34b92f46_scoped_true___WEBPACK_IMPORTED_MODULE_0__["render"], _almost_lottery_vue_vue_type_template_id_34b92f46_scoped_true___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"], false, null, "34b92f46", null, false, _almost_lottery_vue_vue_type_template_id_34b92f46_scoped_true___WEBPACK_IMPORTED_MODULE_0__["components"], renderjs);
        component.options.__file = "uni_modules/almost-lottery/components/almost-lottery/almost-lottery.vue"
        /* harmony default export */;
        __webpack_exports__["default"] = component.exports;
        /***/    },
    /***/ 248: 
    /*!***************************************************************************************************************************************************!*\
  !*** /Users/feajun/riqianguan/uni_modules/almost-lottery/components/almost-lottery/almost-lottery.vue?vue&type=template&id=34b92f46&scoped=true& ***!
  \***************************************************************************************************************************************************/
    /*! exports provided: render, staticRenderFns, recyclableRender, components */
    /***/ function(module, __webpack_exports__, __webpack_require__) {
        "use strict";
        __webpack_require__.r(__webpack_exports__);
        /* harmony import */        var _Applications_HBuilderX_app_Contents_HBuilderX_plugins_uniapp_cli_node_modules_dcloudio_vue_cli_plugin_uni_packages_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_Applications_HBuilderX_app_Contents_HBuilderX_plugins_uniapp_cli_node_modules_dcloudio_vue_cli_plugin_uni_packages_webpack_preprocess_loader_index_js_ref_17_0_Applications_HBuilderX_app_Contents_HBuilderX_plugins_uniapp_cli_node_modules_dcloudio_webpack_uni_mp_loader_lib_template_js_Applications_HBuilderX_app_Contents_HBuilderX_plugins_uniapp_cli_node_modules_dcloudio_vue_cli_plugin_uni_packages_webpack_uni_app_loader_page_meta_js_Applications_HBuilderX_app_Contents_HBuilderX_plugins_uniapp_cli_node_modules_dcloudio_vue_cli_plugin_uni_packages_vue_loader_lib_index_js_vue_loader_options_Applications_HBuilderX_app_Contents_HBuilderX_plugins_uniapp_cli_node_modules_dcloudio_webpack_uni_mp_loader_lib_style_js_almost_lottery_vue_vue_type_template_id_34b92f46_scoped_true___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../../../Applications/HBuilderX.app/Contents/HBuilderX/plugins/uniapp-cli/node_modules/@dcloudio/vue-cli-plugin-uni/packages/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!../../../../../../../Applications/HBuilderX.app/Contents/HBuilderX/plugins/uniapp-cli/node_modules/@dcloudio/vue-cli-plugin-uni/packages/webpack-preprocess-loader??ref--17-0!../../../../../../../Applications/HBuilderX.app/Contents/HBuilderX/plugins/uniapp-cli/node_modules/@dcloudio/webpack-uni-mp-loader/lib/template.js!../../../../../../../Applications/HBuilderX.app/Contents/HBuilderX/plugins/uniapp-cli/node_modules/@dcloudio/vue-cli-plugin-uni/packages/webpack-uni-app-loader/page-meta.js!../../../../../../../Applications/HBuilderX.app/Contents/HBuilderX/plugins/uniapp-cli/node_modules/@dcloudio/vue-cli-plugin-uni/packages/vue-loader/lib??vue-loader-options!../../../../../../../Applications/HBuilderX.app/Contents/HBuilderX/plugins/uniapp-cli/node_modules/@dcloudio/webpack-uni-mp-loader/lib/style.js!./almost-lottery.vue?vue&type=template&id=34b92f46&scoped=true& */ 249);
        /* harmony reexport (safe) */        __webpack_require__.d(__webpack_exports__, "render", function() {
            return _Applications_HBuilderX_app_Contents_HBuilderX_plugins_uniapp_cli_node_modules_dcloudio_vue_cli_plugin_uni_packages_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_Applications_HBuilderX_app_Contents_HBuilderX_plugins_uniapp_cli_node_modules_dcloudio_vue_cli_plugin_uni_packages_webpack_preprocess_loader_index_js_ref_17_0_Applications_HBuilderX_app_Contents_HBuilderX_plugins_uniapp_cli_node_modules_dcloudio_webpack_uni_mp_loader_lib_template_js_Applications_HBuilderX_app_Contents_HBuilderX_plugins_uniapp_cli_node_modules_dcloudio_vue_cli_plugin_uni_packages_webpack_uni_app_loader_page_meta_js_Applications_HBuilderX_app_Contents_HBuilderX_plugins_uniapp_cli_node_modules_dcloudio_vue_cli_plugin_uni_packages_vue_loader_lib_index_js_vue_loader_options_Applications_HBuilderX_app_Contents_HBuilderX_plugins_uniapp_cli_node_modules_dcloudio_webpack_uni_mp_loader_lib_style_js_almost_lottery_vue_vue_type_template_id_34b92f46_scoped_true___WEBPACK_IMPORTED_MODULE_0__["render"];
        });
        /* harmony reexport (safe) */        __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() {
            return _Applications_HBuilderX_app_Contents_HBuilderX_plugins_uniapp_cli_node_modules_dcloudio_vue_cli_plugin_uni_packages_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_Applications_HBuilderX_app_Contents_HBuilderX_plugins_uniapp_cli_node_modules_dcloudio_vue_cli_plugin_uni_packages_webpack_preprocess_loader_index_js_ref_17_0_Applications_HBuilderX_app_Contents_HBuilderX_plugins_uniapp_cli_node_modules_dcloudio_webpack_uni_mp_loader_lib_template_js_Applications_HBuilderX_app_Contents_HBuilderX_plugins_uniapp_cli_node_modules_dcloudio_vue_cli_plugin_uni_packages_webpack_uni_app_loader_page_meta_js_Applications_HBuilderX_app_Contents_HBuilderX_plugins_uniapp_cli_node_modules_dcloudio_vue_cli_plugin_uni_packages_vue_loader_lib_index_js_vue_loader_options_Applications_HBuilderX_app_Contents_HBuilderX_plugins_uniapp_cli_node_modules_dcloudio_webpack_uni_mp_loader_lib_style_js_almost_lottery_vue_vue_type_template_id_34b92f46_scoped_true___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"];
        });
        /* harmony reexport (safe) */        __webpack_require__.d(__webpack_exports__, "recyclableRender", function() {
            return _Applications_HBuilderX_app_Contents_HBuilderX_plugins_uniapp_cli_node_modules_dcloudio_vue_cli_plugin_uni_packages_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_Applications_HBuilderX_app_Contents_HBuilderX_plugins_uniapp_cli_node_modules_dcloudio_vue_cli_plugin_uni_packages_webpack_preprocess_loader_index_js_ref_17_0_Applications_HBuilderX_app_Contents_HBuilderX_plugins_uniapp_cli_node_modules_dcloudio_webpack_uni_mp_loader_lib_template_js_Applications_HBuilderX_app_Contents_HBuilderX_plugins_uniapp_cli_node_modules_dcloudio_vue_cli_plugin_uni_packages_webpack_uni_app_loader_page_meta_js_Applications_HBuilderX_app_Contents_HBuilderX_plugins_uniapp_cli_node_modules_dcloudio_vue_cli_plugin_uni_packages_vue_loader_lib_index_js_vue_loader_options_Applications_HBuilderX_app_Contents_HBuilderX_plugins_uniapp_cli_node_modules_dcloudio_webpack_uni_mp_loader_lib_style_js_almost_lottery_vue_vue_type_template_id_34b92f46_scoped_true___WEBPACK_IMPORTED_MODULE_0__["recyclableRender"];
        });
        /* harmony reexport (safe) */        __webpack_require__.d(__webpack_exports__, "components", function() {
            return _Applications_HBuilderX_app_Contents_HBuilderX_plugins_uniapp_cli_node_modules_dcloudio_vue_cli_plugin_uni_packages_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_Applications_HBuilderX_app_Contents_HBuilderX_plugins_uniapp_cli_node_modules_dcloudio_vue_cli_plugin_uni_packages_webpack_preprocess_loader_index_js_ref_17_0_Applications_HBuilderX_app_Contents_HBuilderX_plugins_uniapp_cli_node_modules_dcloudio_webpack_uni_mp_loader_lib_template_js_Applications_HBuilderX_app_Contents_HBuilderX_plugins_uniapp_cli_node_modules_dcloudio_vue_cli_plugin_uni_packages_webpack_uni_app_loader_page_meta_js_Applications_HBuilderX_app_Contents_HBuilderX_plugins_uniapp_cli_node_modules_dcloudio_vue_cli_plugin_uni_packages_vue_loader_lib_index_js_vue_loader_options_Applications_HBuilderX_app_Contents_HBuilderX_plugins_uniapp_cli_node_modules_dcloudio_webpack_uni_mp_loader_lib_style_js_almost_lottery_vue_vue_type_template_id_34b92f46_scoped_true___WEBPACK_IMPORTED_MODULE_0__["components"];
        });
        /***/    },
    /***/ 249: 
    /*!***************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/@dcloudio/vue-cli-plugin-uni/packages/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/@dcloudio/vue-cli-plugin-uni/packages/webpack-preprocess-loader??ref--17-0!./node_modules/@dcloudio/webpack-uni-mp-loader/lib/template.js!./node_modules/@dcloudio/vue-cli-plugin-uni/packages/webpack-uni-app-loader/page-meta.js!./node_modules/@dcloudio/vue-cli-plugin-uni/packages/vue-loader/lib??vue-loader-options!./node_modules/@dcloudio/webpack-uni-mp-loader/lib/style.js!/Users/feajun/riqianguan/uni_modules/almost-lottery/components/almost-lottery/almost-lottery.vue?vue&type=template&id=34b92f46&scoped=true& ***!
  \***************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
    /*! exports provided: render, staticRenderFns, recyclableRender, components */
    /***/ function(module, __webpack_exports__, __webpack_require__) {
        "use strict";
        __webpack_require__.r(__webpack_exports__);
        /* harmony export (binding) */        __webpack_require__.d(__webpack_exports__, "render", function() {
            return render;
        });
        /* harmony export (binding) */        __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() {
            return staticRenderFns;
        });
        /* harmony export (binding) */        __webpack_require__.d(__webpack_exports__, "recyclableRender", function() {
            return recyclableRender;
        });
        /* harmony export (binding) */        __webpack_require__.d(__webpack_exports__, "components", function() {
            return components;
        });
        var components;
        var render = function() {
            var _vm = this;
            var _h = _vm.$createElement;
            var _c = _vm._self._c || _h;
        };
        var recyclableRender = false;
        var staticRenderFns = [];
        render._withStripped = true
        /***/;
    },
    /***/ 250: 
    /*!*********************************************************************************************************************************!*\
  !*** /Users/feajun/riqianguan/uni_modules/almost-lottery/components/almost-lottery/almost-lottery.vue?vue&type=script&lang=js& ***!
  \*********************************************************************************************************************************/
    /*! no static exports found */
    /***/ function(module, __webpack_exports__, __webpack_require__) {
        "use strict";
        __webpack_require__.r(__webpack_exports__);
        /* harmony import */        var _Applications_HBuilderX_app_Contents_HBuilderX_plugins_uniapp_cli_node_modules_babel_loader_lib_index_js_Applications_HBuilderX_app_Contents_HBuilderX_plugins_uniapp_cli_node_modules_dcloudio_vue_cli_plugin_uni_packages_webpack_preprocess_loader_index_js_ref_13_1_Applications_HBuilderX_app_Contents_HBuilderX_plugins_uniapp_cli_node_modules_dcloudio_webpack_uni_mp_loader_lib_script_js_Applications_HBuilderX_app_Contents_HBuilderX_plugins_uniapp_cli_node_modules_dcloudio_vue_cli_plugin_uni_packages_vue_loader_lib_index_js_vue_loader_options_Applications_HBuilderX_app_Contents_HBuilderX_plugins_uniapp_cli_node_modules_dcloudio_webpack_uni_mp_loader_lib_style_js_almost_lottery_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../../../Applications/HBuilderX.app/Contents/HBuilderX/plugins/uniapp-cli/node_modules/babel-loader/lib!../../../../../../../Applications/HBuilderX.app/Contents/HBuilderX/plugins/uniapp-cli/node_modules/@dcloudio/vue-cli-plugin-uni/packages/webpack-preprocess-loader??ref--13-1!../../../../../../../Applications/HBuilderX.app/Contents/HBuilderX/plugins/uniapp-cli/node_modules/@dcloudio/webpack-uni-mp-loader/lib/script.js!../../../../../../../Applications/HBuilderX.app/Contents/HBuilderX/plugins/uniapp-cli/node_modules/@dcloudio/vue-cli-plugin-uni/packages/vue-loader/lib??vue-loader-options!../../../../../../../Applications/HBuilderX.app/Contents/HBuilderX/plugins/uniapp-cli/node_modules/@dcloudio/webpack-uni-mp-loader/lib/style.js!./almost-lottery.vue?vue&type=script&lang=js& */ 251);
        /* harmony import */        var _Applications_HBuilderX_app_Contents_HBuilderX_plugins_uniapp_cli_node_modules_babel_loader_lib_index_js_Applications_HBuilderX_app_Contents_HBuilderX_plugins_uniapp_cli_node_modules_dcloudio_vue_cli_plugin_uni_packages_webpack_preprocess_loader_index_js_ref_13_1_Applications_HBuilderX_app_Contents_HBuilderX_plugins_uniapp_cli_node_modules_dcloudio_webpack_uni_mp_loader_lib_script_js_Applications_HBuilderX_app_Contents_HBuilderX_plugins_uniapp_cli_node_modules_dcloudio_vue_cli_plugin_uni_packages_vue_loader_lib_index_js_vue_loader_options_Applications_HBuilderX_app_Contents_HBuilderX_plugins_uniapp_cli_node_modules_dcloudio_webpack_uni_mp_loader_lib_style_js_almost_lottery_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0___default = /* */ __webpack_require__.n(_Applications_HBuilderX_app_Contents_HBuilderX_plugins_uniapp_cli_node_modules_babel_loader_lib_index_js_Applications_HBuilderX_app_Contents_HBuilderX_plugins_uniapp_cli_node_modules_dcloudio_vue_cli_plugin_uni_packages_webpack_preprocess_loader_index_js_ref_13_1_Applications_HBuilderX_app_Contents_HBuilderX_plugins_uniapp_cli_node_modules_dcloudio_webpack_uni_mp_loader_lib_script_js_Applications_HBuilderX_app_Contents_HBuilderX_plugins_uniapp_cli_node_modules_dcloudio_vue_cli_plugin_uni_packages_vue_loader_lib_index_js_vue_loader_options_Applications_HBuilderX_app_Contents_HBuilderX_plugins_uniapp_cli_node_modules_dcloudio_webpack_uni_mp_loader_lib_style_js_almost_lottery_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__);
        /* harmony reexport (unknown) */        for (var __WEBPACK_IMPORT_KEY__ in _Applications_HBuilderX_app_Contents_HBuilderX_plugins_uniapp_cli_node_modules_babel_loader_lib_index_js_Applications_HBuilderX_app_Contents_HBuilderX_plugins_uniapp_cli_node_modules_dcloudio_vue_cli_plugin_uni_packages_webpack_preprocess_loader_index_js_ref_13_1_Applications_HBuilderX_app_Contents_HBuilderX_plugins_uniapp_cli_node_modules_dcloudio_webpack_uni_mp_loader_lib_script_js_Applications_HBuilderX_app_Contents_HBuilderX_plugins_uniapp_cli_node_modules_dcloudio_vue_cli_plugin_uni_packages_vue_loader_lib_index_js_vue_loader_options_Applications_HBuilderX_app_Contents_HBuilderX_plugins_uniapp_cli_node_modules_dcloudio_webpack_uni_mp_loader_lib_style_js_almost_lottery_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__) if ([ "default" ].indexOf(__WEBPACK_IMPORT_KEY__) < 0) (function(key) {
            __webpack_require__.d(__webpack_exports__, key, function() {
                return _Applications_HBuilderX_app_Contents_HBuilderX_plugins_uniapp_cli_node_modules_babel_loader_lib_index_js_Applications_HBuilderX_app_Contents_HBuilderX_plugins_uniapp_cli_node_modules_dcloudio_vue_cli_plugin_uni_packages_webpack_preprocess_loader_index_js_ref_13_1_Applications_HBuilderX_app_Contents_HBuilderX_plugins_uniapp_cli_node_modules_dcloudio_webpack_uni_mp_loader_lib_script_js_Applications_HBuilderX_app_Contents_HBuilderX_plugins_uniapp_cli_node_modules_dcloudio_vue_cli_plugin_uni_packages_vue_loader_lib_index_js_vue_loader_options_Applications_HBuilderX_app_Contents_HBuilderX_plugins_uniapp_cli_node_modules_dcloudio_webpack_uni_mp_loader_lib_style_js_almost_lottery_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__[key];
            });
        })(__WEBPACK_IMPORT_KEY__);
        /* harmony default export */        __webpack_exports__["default"] = _Applications_HBuilderX_app_Contents_HBuilderX_plugins_uniapp_cli_node_modules_babel_loader_lib_index_js_Applications_HBuilderX_app_Contents_HBuilderX_plugins_uniapp_cli_node_modules_dcloudio_vue_cli_plugin_uni_packages_webpack_preprocess_loader_index_js_ref_13_1_Applications_HBuilderX_app_Contents_HBuilderX_plugins_uniapp_cli_node_modules_dcloudio_webpack_uni_mp_loader_lib_script_js_Applications_HBuilderX_app_Contents_HBuilderX_plugins_uniapp_cli_node_modules_dcloudio_vue_cli_plugin_uni_packages_vue_loader_lib_index_js_vue_loader_options_Applications_HBuilderX_app_Contents_HBuilderX_plugins_uniapp_cli_node_modules_dcloudio_webpack_uni_mp_loader_lib_style_js_almost_lottery_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0___default.a;
        /***/    },
    /***/ 251: 
    /*!****************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/babel-loader/lib!./node_modules/@dcloudio/vue-cli-plugin-uni/packages/webpack-preprocess-loader??ref--13-1!./node_modules/@dcloudio/webpack-uni-mp-loader/lib/script.js!./node_modules/@dcloudio/vue-cli-plugin-uni/packages/vue-loader/lib??vue-loader-options!./node_modules/@dcloudio/webpack-uni-mp-loader/lib/style.js!/Users/feajun/riqianguan/uni_modules/almost-lottery/components/almost-lottery/almost-lottery.vue?vue&type=script&lang=js& ***!
  \****************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
    /*! no static exports found */
    /***/ function(module, exports, __webpack_require__) {
        "use strict";
        /* WEBPACK VAR INJECTION */
        /* WEBPACK VAR INJECTION */        
        /* WEBPACK VAR INJECTION */
        /* WEBPACK VAR INJECTION */ (function(uni) {
            var _interopRequireDefault = __webpack_require__(/*! @babel/runtime/helpers/interopRequireDefault */ 4);
            Object.defineProperty(exports, "__esModule", {
                value: true
            });
            exports.default = void 0;
            var _regenerator = _interopRequireDefault(__webpack_require__(/*! @babel/runtime/regenerator */ 55));
            var _asyncToGenerator2 = _interopRequireDefault(__webpack_require__(/*! @babel/runtime/helpers/asyncToGenerator */ 57));
            var _almostUtils = __webpack_require__(/*! @/uni_modules/almost-lottery/utils/almost-utils.js */ 211);
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
                        var _default2 = {
                name: "AlmostLottery",
                props: {
                    // 设计稿的像素比基准值
                    pixelRatio: {
                        type: Number,
                        default: 2
                    },
                    // canvas 标识
                    canvasId: {
                        type: String,
                        default: "almostLottery"
                    },
                    // 渲染延迟
                    renderDelay: {
                        type: Number,
                        default: 0
                    },
                    // 抽奖转盘的整体尺寸
                    lotterySize: {
                        type: Number,
                        default: 600
                    },
                    // 抽奖按钮的尺寸
                    actionSize: {
                        type: Number,
                        default: 200
                    },
                    // canvas边缘距离转盘边缘的距离
                    canvasMarginOutside: {
                        type: Number,
                        default: 90
                    },
                    // 奖品列表
                    prizeList: {
                        type: Array,
                        required: true,
                        validator: function validator(value) {
                            return value.length > 1;
                        }
                    },
                    // 中奖奖品在列表中的下标
                    prizeIndex: {
                        type: Number,
                        required: true
                    },
                    // 奖品区块对应背景颜色
                    colors: {
                        type: Array,
                        default: function _default() {
                            return [ "#FFFFFF", "#FFBF05" ];
                        }
                    },
                    // 转盘外环背景图
                    lotteryBg: {
                        type: String,
                        default: "/uni_modules/almost-lottery/static/almost-lottery/almost-lottery__bg2x.png"
                    },
                    // 抽奖按钮背景图
                    actionBg: {
                        type: String,
                        default: "/uni_modules/almost-lottery/static/almost-lottery/almost-lottery__action2x.png"
                    },
                    // 是否绘制奖品名称
                    prizeNameDrawed: {
                        type: Boolean,
                        default: true
                    },
                    // 是否开启奖品区块描边
                    stroked: {
                        type: Boolean,
                        default: false
                    },
                    // 描边颜色
                    strokeColor: {
                        type: String,
                        default: "#FFBF05"
                    },
                    // 旋转的类型
                    rotateType: {
                        type: String,
                        default: "roulette"
                    },
                    // 是否开启自转
                    selfRotaty: {
                        type: Boolean,
                        default: false
                    },
                    // 自转时，最少转多少毫秒
                    selfTime: {
                        type: Number,
                        default: 1e3
                    },
                    // 旋转动画时间 单位s
                    duration: {
                        type: Number,
                        default: 8
                    },
                    // 旋转的圈数
                    ringCount: {
                        type: Number,
                        default: 8
                    },
                    // 指针位置
                    pointerPosition: {
                        type: String,
                        default: "edge",
                        validator: function validator(value) {
                            return value === "edge" || value === "middle";
                        }
                    },
                    // 文字方向
                    strDirection: {
                        type: String,
                        default: "horizontal",
                        validator: function validator(value) {
                            return value === "horizontal" || value === "vertical";
                        }
                    },
                    // 字体颜色
                    strFontColors: {
                        type: Array,
                        default: function _default() {
                            return [ "#FFBF05", "#FFFFFF" ];
                        }
                    },
                    // 文字的大小
                    strFontSize: {
                        type: Number,
                        default: 24
                    },
                    // 奖品文字距离边缘的距离
                    strMarginOutside: {
                        type: Number,
                        default: 0
                    },
                    // 奖品图片距离奖品文字的距离
                    imgMarginStr: {
                        type: Number,
                        default: 60
                    },
                    // 奖品文字多行情况下的行高
                    strLineHeight: {
                        type: Number,
                        default: 1.2
                    },
                    // 奖品文字总长度限制
                    strMaxLen: {
                        type: Number,
                        default: 12
                    },
                    // 奖品文字多行情况下第一行文字长度
                    strLineLen: {
                        type: Number,
                        default: 6
                    },
                    // 奖品图片的宽
                    imgWidth: {
                        type: Number,
                        default: 50
                    },
                    // 奖品图片的高
                    imgHeight: {
                        type: Number,
                        default: 50
                    },
                    // 是否绘制奖品图片
                    imgDrawed: {
                        type: Boolean,
                        default: true
                    },
                    // 奖品图片是否裁切为圆形
                    imgCircled: {
                        type: Boolean,
                        default: false
                    },
                    // 转盘绘制成功的提示
                    successMsg: {
                        type: String,
                        default: "奖品准备就绪，快来参与抽奖吧"
                    },
                    // 转盘绘制失败的提示
                    failMsg: {
                        type: String,
                        default: "奖品仍在准备中，请稍后再来..."
                    },
                    // 是否开启画板的缓存
                    canvasCached: {
                        type: Boolean,
                        default: false
                    },
                    // 转动之前
                    drawStartBefore: {
                        type: Function,
                        default: function _default() {
                            return true;
                        }
                    }
                },
                data: function data() {
                    return {
                        // 画板className
                        className: "almost-lottery__canvas",
                        // 高清固定 2 倍，不再从 system 中动态获取，因为 h5、app-vue 中单个尺寸过大时存在 iOS/Safari 无法绘制的问题，且 2 倍基本也可以解决模糊的问题
                        systemPixelRatio: 2,
                        // 抽奖转盘的整体px尺寸
                        lotteryPxSize: 0,
                        // 画板的px尺寸
                        canvasImgPxSize: 0,
                        // 抽奖按钮的px尺寸
                        actionPxSize: 0,
                        // 奖品文字距离转盘边缘的距离
                        strMarginPxOutside: 0,
                        // 奖品图片相对奖品文字的距离
                        imgMarginPxStr: 0,
                        // 奖品图片的宽、高
                        imgPxWidth: 0,
                        imgPxHeight: 0,
                        // 画板导出的图片
                        lotteryImg: "",
                        // 旋转到奖品目标需要的角度
                        targetAngle: 0,
                        targetActionAngle: 0,
                        // 配合自转使用
                        selfRotated: false,
                        selfRotatyStartTime: null,
                        // 是否正在旋转
                        isRotate: false,
                        // 当前停留在那个奖品的序号
                        stayIndex: 0,
                        // 当前中奖奖品的序号
                        targetIndex: 0,
                        // 是否存在可用的缓存转盘图
                        isCacheImg: false,
                        oldLotteryImg: "",
                        // 解决 app 不支持 measureText 的问题
                        // app 已在 2.9.3 的版本中提供了对 measureText 的支持，将在后续版本逐渐稳定后移除相关兼容代码
                        measureText: ""
                    };
                },
                computed: {
                    // 高清尺寸
                    higtCanvasSize: function higtCanvasSize() {
                        return this.canvasImgPxSize * this.systemPixelRatio;
                    },
                    // 高清字体
                    higtFontSize: function higtFontSize() {
                        return Math.round(this.strFontSize / this.pixelRatio) * this.systemPixelRatio;
                    },
                    // 高清行高
                    higtHeightMultiple: function higtHeightMultiple() {
                        return Math.round(this.strFontSize / this.pixelRatio) * this.strLineHeight * this.systemPixelRatio;
                    },
                    canvasImgToLeftPx: function canvasImgToLeftPx() {
                        return (this.lotteryPxSize - this.canvasImgPxSize) / 2;
                    },
                    actionBgToLeftPx: function actionBgToLeftPx() {
                        return (this.lotteryPxSize - this.actionPxSize) / 2;
                    },
                    // 根据奖品列表计算 canvas 旋转角度
                    canvasAngle: function canvasAngle() {
                        var result = 0;
                        var prizeCount = this.prizeList.length;
                        var prizeClip = 360 / prizeCount;
                        var diffNum = 90 / prizeClip;
                        if (this.pointerPosition === "edge" || this.rotateType === "pointer") {
                            result = -(prizeClip * diffNum);
                        } else {
                            result = -(prizeClip * diffNum + prizeClip / 2);
                        }
                        return result;
                    },
                    actionAngle: function actionAngle() {
                        return 0;
                    },
                    // 外圆的半径
                    outsideRadius: function outsideRadius() {
                        return this.higtCanvasSize / 2;
                    },
                    // 内圆的半径
                    insideRadius: function insideRadius() {
                        return 20 * this.systemPixelRatio;
                    },
                    // 文字距离边缘的距离
                    textRadius: function textRadius() {
                        return this.strMarginPxOutside * this.systemPixelRatio || this.higtFontSize / 2;
                    },
                    // 根据画板的宽度计算奖品文字与中心点的距离
                    textDistance: function textDistance() {
                        var textZeroY = Math.round(this.outsideRadius - this.insideRadius / 2);
                        return textZeroY - this.textRadius;
                    },
                    // 旋转动画时间 单位 s
                    transitionDuration: function transitionDuration() {
                        return this.selfRotaty ? 2 : this.duration;
                    }
                },
                watch: {
                    // 监听获奖序号的变动
                    prizeIndex: function prizeIndex(newVal, oldVal) {
                        var _this = this;
                        if (newVal > -1) {
                            console.log(newVal);
                            if (this.selfRotaty) {
                                var diffTime = Date.now() - this.selfRotatyStartTime;
                                var timeDelay = diffTime < this.selfTime ? this.selfTime : 0;
                                setTimeout(function() {
                                    _this.selfRotated = false;
                                    _this.targetIndex = newVal;
                                    _this.onRotateStart();
                                }, timeDelay);
                            } else {
                                setTimeout(function() {
                                    _this.targetIndex = newVal;
                                    _this.onRotateStart();
                                }, 0);
                            }
                        } else {
                            console.info("旋转结束，prizeIndex 已重置");
                        }
                    }
                },
                methods: {
                    // 开始旋转
                    onRotateStart: function onRotateStart() {
                        var _this2 = this;
                        // 奖品总数
                                                if (!this.selfRotaty) {
                            if (this.isRotate) return;
                            this.isRotate = true;
                        }
                        var prizeCount = this.prizeList.length;
                        var baseAngle = 360 / prizeCount;
                        var angles = 0;
                        var ringCount = this.selfRotaty ? 1 : this.ringCount;
                        if (this.rotateType === "pointer") {
                            if (this.targetActionAngle === 0) {
                                // 第一次旋转
                                angles = (this.targetIndex - this.stayIndex) * baseAngle + baseAngle / 2 - this.actionAngle;
                            } else {
                                // 后续旋转
                                // 后续继续旋转 就只需要计算停留的位置与目标位置的角度
                                angles = (this.targetIndex - this.stayIndex) * baseAngle;
                            }
                            // 更新目前序号
                                                        this.stayIndex = this.targetIndex;
                            // 转 8 圈，圈数越多，转的越快
                                                        this.targetActionAngle += angles + 360 * ringCount;
                            // console.log('targetActionAngle', this.targetActionAngle)
                                                } else {
                            if (this.targetAngle === 0) {
                                // 第一次旋转
                                // 因为第一个奖品是从0°开始的，即水平向右方向
                                // 第一次旋转角度 = 270度 - (停留的序号-目标序号) * 每个奖品区间角度 - 每个奖品区间角度的一半 - canvas自身旋转的度数
                                angles = 270 - (this.targetIndex - this.stayIndex) * baseAngle - baseAngle / 2 - this.canvasAngle;
                            } else {
                                // 后续旋转
                                // 后续继续旋转 就只需要计算停留的位置与目标位置的角度
                                angles = -(this.targetIndex - this.stayIndex) * baseAngle;
                            }
                            // 更新目前序号
                                                        this.stayIndex = this.targetIndex;
                            // 转 8 圈，圈数越多，转的越快
                                                        this.targetAngle += angles + 360 * ringCount;
                        }
                        // 计算转盘结束的时间，预加一些延迟确保转盘停止后触发结束事件
                                                var endTime = this.selfRotaty ? 0 : this.transitionDuration * 1e3 + 100;
                        var endTimer = setTimeout(function() {
                            clearTimeout(endTimer);
                            endTimer = null;
                            _this2.isRotate = false;
                            _this2.$emit("draw-end");
                        }, endTime);
                        var resetPrizeTimer = setTimeout(function() {
                            clearTimeout(resetPrizeTimer);
                            resetPrizeTimer = null;
                            // 每次抽奖结束后都要重置父级组件的 prizeIndex
                                                        _this2.$emit("reset-index");
                        }, endTime + 50);
                    },
                    // 点击 开始抽奖 按钮
                    handleActionStart: function handleActionStart() {
                        if (!this.lotteryImg) return;
                        if (this.isRotate) return;
                        if (!this.drawStartBefore()) return;
                        var ringDuration = (this.duration / this.ringCount).toFixed(1);
                        if (ringDuration >= 2.5) {
                            console.warn("当前每一圈的旋转可能过慢，请检查 duration 和 ringCount 这 2 个参数是否设置合理");
                        } else if (ringDuration < 1) {
                            console.warn("当前每一圈的旋转可能过快，请检查 duration 和 ringCount 这 2 个参数是否设置合理");
                        }
                        if (this.selfRotaty) {
                            this.isRotate = true;
                            this.selfRotated = true;
                            this.selfRotatyStartTime = Date.now();
                        }
                        this.$emit("draw-start");
                    },
                    // 渲染转盘
                    onCreateCanvas: function onCreateCanvas() {
                        var _this3 = this;
                        return (0, _asyncToGenerator2.default)(/* */ _regenerator.default.mark(function _callee() {
                            var canvasId, ctx, canvasW, canvasH, prizeCount, baseAngle, i, prizeItem, angle, translateX, translateY, rewardName, realLen, isLineBreak, textCount, tempTxt, rewardNames, j, _j, tempStrSize, tempStrWidth, textWidth, _tempStrWidth, _tempStrSize, _tempStrWidth2, _textWidth, _tempStrWidth3, _rewardNames, _j2, _tempStrSize2, _tempStrWidth4, _textWidth2, _tempStrWidth5, reg, platformTips, res, tempFilePath, prizeImageX, prizeImageY, prizeImageW, prizeImageH;
                            return _regenerator.default.wrap(function _callee$(_context) {
                                while (1) {
                                    switch (_context.prev = _context.next) {
                                      case 0:
                                        // 获取 canvas 画布
                                        canvasId = _this3.canvasId;
                                        ctx = uni.createCanvasContext(canvasId, _this3);
                                        // canvas 的宽高
                                                                                canvasW = _this3.higtCanvasSize;
                                        canvasH = _this3.higtCanvasSize;
                                        // 根据奖品个数计算 角度
                                                                                prizeCount = _this3.prizeList.length;
                                        baseAngle = Math.PI * 2 / prizeCount;
                                        // 设置字体
                                                                                ctx.setFontSize(_this3.higtFontSize);
                                        // 注意，开始画的位置是从0°角的位置开始画的。也就是水平向右的方向。
                                        // 画具体内容
                                                                                i = 0;

                                      case 8:
                                        if (!(i < prizeCount)) {
                                            _context.next = 118;
                                            break;
                                        }
                                        prizeItem = _this3.prizeList[i];
                                        // 当前角度
                                                                                angle = i * baseAngle;
                                        // 保存当前画布的状态
                                                                                ctx.save();
                                        // x => 圆弧对应的圆心横坐标 x
                                        // y => 圆弧对应的圆心横坐标 y
                                        // radius => 圆弧的半径大小
                                        // startAngle => 圆弧开始的角度，单位是弧度
                                        // endAngle => 圆弧结束的角度，单位是弧度
                                        // anticlockwise(可选) => 绘制方向，true 为逆时针，false 为顺时针
                                                                                ctx.beginPath();
                                        // 外圆
                                                                                ctx.arc(canvasW * .5, canvasH * .5, _this3.outsideRadius, angle, angle + baseAngle, false);
                                        // 内圆
                                                                                ctx.arc(canvasW * .5, canvasH * .5, _this3.insideRadius, angle + baseAngle, angle, true);
                                        // 每个奖品区块背景填充颜色
                                                                                if (_this3.colors.length === 2) {
                                            ctx.setFillStyle(_this3.colors[i % 2]);
                                        } else {
                                            ctx.setFillStyle(_this3.colors[i]);
                                        }
                                        // 填充颜色
                                                                                ctx.fill();
                                        // 开启描边
                                                                                if (_this3.stroked) {
                                            // 设置描边颜色
                                            ctx.setStrokeStyle("".concat(_this3.strokeColor));
                                            // 描边
                                                                                        ctx.stroke();
                                        }
                                        // 开始绘制奖品内容
                                        // 重新映射画布上的 (0,0) 位置
                                                                                translateX = canvasW * .5 + Math.cos(angle + baseAngle / 2) * _this3.textDistance;
                                        translateY = canvasH * .5 + Math.sin(angle + baseAngle / 2) * _this3.textDistance;
                                        ctx.translate(translateX, translateY);
                                        // 绘制奖品名称
                                                                                rewardName = _this3.strLimit(prizeItem.prizeName);
                                        // 设置文字颜色
                                                                                if (_this3.strFontColors.length === 1) {
                                            ctx.setFillStyle(_this3.strFontColors[0]);
                                        } else if (_this3.strFontColors.length === 2) {
                                            ctx.setFillStyle(_this3.strFontColors[i % 2]);
                                        } else {
                                            ctx.setFillStyle(_this3.strFontColors[i]);
                                        }
                                        // rotate方法旋转当前的绘图，因为文字是和当前扇形中心线垂直的
                                                                                ctx.rotate(angle + baseAngle / 2 + Math.PI / 2);
                                        // 设置文本位置并处理换行
                                                                                if (!(_this3.strDirection === "horizontal")) {
                                            _context.next = 70;
                                            break;
                                        }
                                        if (!(rewardName && _this3.prizeNameDrawed)) {
                                            _context.next = 68;
                                            break;
                                        }
                                        realLen = (0, _almostUtils.clacTextLen)(rewardName).realLen;
                                        isLineBreak = realLen > _this3.strLineLen;
                                        if (!isLineBreak) {
                                            _context.next = 54;
                                            break;
                                        }
                                        // 获得多行文本数组
                                                                                textCount = 0;
                                        tempTxt = "";
                                        rewardNames = [];
                                        for (j = 0; j < rewardName.length; j++) {
                                            textCount += (0, _almostUtils.clacTextLen)(rewardName[j]).byteLen;
                                            tempTxt += rewardName[j];
                                            if (textCount >= _this3.strLineLen * 2) {
                                                rewardNames.push(tempTxt);
                                                textCount = 0;
                                                tempTxt = "";
                                            } else {
                                                if (rewardName.length - 1 === j) {
                                                    rewardNames.push(tempTxt);
                                                    textCount = 0;
                                                    tempTxt = "";
                                                }
                                            }
                                        }
                                        // 循环文本数组，计算每一行的文本宽度
                                                                                _j = 0;

                                      case 34:
                                        if (!(_j < rewardNames.length)) {
                                            _context.next = 52;
                                            break;
                                        }
                                        if (!(ctx.measureText && ctx.measureText(rewardNames[_j]).width > 0)) {
                                            _context.next = 41;
                                            break;
                                        }
                                        // 文本的宽度信息
                                                                                tempStrSize = ctx.measureText(rewardNames[_j]);
                                        tempStrWidth = -(tempStrSize.width / 2).toFixed(2);
                                        ctx.fillText(rewardNames[_j], tempStrWidth, _j * _this3.higtHeightMultiple);
                                        _context.next = 49;
                                        break;

                                      case 41:
                                        _this3.measureText = rewardNames[_j];
                                        // 等待页面重新渲染
                                                                                _context.next = 44;
                                        return _this3.$nextTick();

                                      case 44:
                                        _context.next = 46;
                                        return _this3.getTextWidth();

                                      case 46:
                                        textWidth = _context.sent;
                                        _tempStrWidth = -(textWidth / 2).toFixed(2);
                                        ctx.fillText(rewardNames[_j], _tempStrWidth, _j * _this3.higtHeightMultiple);

                                        // console.log(rewardNames[j], textWidth, j)
                                                                              case 49:
                                        _j++;
                                        _context.next = 34;
                                        break;

                                      case 52:
                                        _context.next = 68;
                                        break;

                                      case 54:
                                        if (!(ctx.measureText && ctx.measureText(rewardName).width > 0)) {
                                            _context.next = 60;
                                            break;
                                        }
                                        // 文本的宽度信息
                                                                                _tempStrSize = ctx.measureText(rewardName);
                                        _tempStrWidth2 = -(_tempStrSize.width / 2).toFixed(2);
                                        ctx.fillText(rewardName, _tempStrWidth2, 0);
                                        _context.next = 68;
                                        break;

                                      case 60:
                                        _this3.measureText = rewardName;
                                        // 等待页面重新渲染
                                                                                _context.next = 63;
                                        return _this3.$nextTick();

                                      case 63:
                                        _context.next = 65;
                                        return _this3.getTextWidth();

                                      case 65:
                                        _textWidth = _context.sent;
                                        _tempStrWidth3 = -(_textWidth / 2).toFixed(2);
                                        ctx.fillText(rewardName, _tempStrWidth3, 0);

                                      case 68:
                                        _context.next = 90;
                                        break;

                                      case 70:
                                        _rewardNames = rewardName.split("");
                                        _j2 = 0;

                                      case 72:
                                        if (!(_j2 < _rewardNames.length)) {
                                            _context.next = 90;
                                            break;
                                        }
                                        if (!(ctx.measureText && ctx.measureText(_rewardNames[_j2]).width > 0)) {
                                            _context.next = 79;
                                            break;
                                        }
                                        // 文本的宽度信息
                                                                                _tempStrSize2 = ctx.measureText(_rewardNames[_j2]);
                                        _tempStrWidth4 = -(_tempStrSize2.width / 2).toFixed(2);
                                        ctx.fillText(_rewardNames[_j2], _tempStrWidth4, _j2 * _this3.higtHeightMultiple);
                                        _context.next = 87;
                                        break;

                                      case 79:
                                        _this3.measureText = _rewardNames[_j2];
                                        // 等待页面重新渲染
                                                                                _context.next = 82;
                                        return _this3.$nextTick();

                                      case 82:
                                        _context.next = 84;
                                        return _this3.getTextWidth();

                                      case 84:
                                        _textWidth2 = _context.sent;
                                        _tempStrWidth5 = -(_textWidth2 / 2).toFixed(2);
                                        ctx.fillText(_rewardNames[_j2], _tempStrWidth5, _j2 * _this3.higtHeightMultiple);

                                        // console.log(rewardNames[j], textWidth, i)
                                                                              case 87:
                                        _j2++;
                                        _context.next = 72;
                                        break;

                                      case 90:
                                        if (!(_this3.imgDrawed && prizeItem.prizeImage && _this3.strDirection !== "vertical")) {
                                            _context.next = 114;
                                            break;
                                        }
                                        // App-Android平台 系统 webview 更新到 Chrome84+ 后 canvas 组件绘制本地图像 uni.canvasToTempFilePath 会报错
                                        // 统一将图片处理成 base64
                                        // https://ask.dcloud.net.cn/question/103303
                                                                                reg = /^(https|http)/g;
                                        // 处理远程图片
                                                                                if (!reg.test(prizeItem.prizeImage)) {
                                            _context.next = 103;
                                            break;
                                        }
                                        platformTips = "";
                                        platformTips = "需要处理好下载域名的白名单问题，";
                                        console.warn("###当前数据列表中的奖品图片为网络图片，".concat(platformTips, "开始尝试下载图片...###"));
                                        _context.next = 98;
                                        return (0, _almostUtils.downloadFile)(prizeItem.prizeImage);

                                      case 98:
                                        res = _context.sent;
                                        console.log("处理远程图片", res);
                                        if (res.ok) {
                                            tempFilePath = res.tempFilePath;
                                            prizeItem.prizeImage = tempFilePath;
                                        } else {
                                            _this3.handlePrizeImgSuc({
                                                ok: false,
                                                data: res.data,
                                                msg: res.msg
                                            });
                                        }
                                        _context.next = 109;
                                        break;

                                      case 103:
                                        if (!(prizeItem.prizeImage.indexOf(";base64,") !== -1)) {
                                            _context.next = 109;
                                            break;
                                        }
                                        console.log("开始处理BASE64图片", prizeItem.prizeImage);
                                        _context.next = 107;
                                        return (0, _almostUtils.base64ToPath)(prizeItem.prizeImage);

                                      case 107:
                                        prizeItem.prizeImage = _context.sent;
                                        console.log("处理BASE64图片完成", prizeItem.prizeImage);

                                      case 109:
                                        prizeImageX = -(_this3.imgPxWidth * _this3.systemPixelRatio / 2);
                                        prizeImageY = _this3.imgMarginPxStr * _this3.systemPixelRatio;
                                        prizeImageW = _this3.imgPxWidth * _this3.systemPixelRatio;
                                        prizeImageH = _this3.imgPxHeight * _this3.systemPixelRatio;
                                        if (_this3.imgCircled) {
                                            // 重新设置每个圆形的背景色
                                            if (_this3.colors.length === 2) {
                                                ctx.setFillStyle(_this3.colors[i % 2]);
                                            } else {
                                                ctx.setFillStyle(_this3.colors[i]);
                                            }
                                            (0, _almostUtils.circleImg)(ctx, prizeItem.prizeImage, prizeImageX, prizeImageY, prizeImageW, prizeImageH);
                                        } else {
                                            ctx.drawImage(prizeItem.prizeImage, prizeImageX, prizeImageY, prizeImageW, prizeImageH);
                                        }

                                      case 114:
                                        ctx.restore();

                                      case 115:
                                        i++;
                                        _context.next = 8;
                                        break;

                                      case 118:
                                        // 保存绘图并导出图片
                                        ctx.draw(true, function() {
                                            var drawTimer = setTimeout(function() {
                                                clearTimeout(drawTimer);
                                                drawTimer = null;
                                                uni.canvasToTempFilePath({
                                                    canvasId: _this3.canvasId,
                                                    destWidth: _this3.higtCanvasSize,
                                                    destHeight: _this3.higtCanvasSize,
                                                    success: function success(res) {
                                                        // 在 H5 平台下，tempFilePath 为 base64
                                                        // console.log(res.tempFilePath)
                                                        _this3.handlePrizeImg({
                                                            ok: true,
                                                            data: res.tempFilePath,
                                                            msg: "画布导出生成图片成功"
                                                        });
                                                    },
                                                    fail: function fail(err) {
                                                        _this3.handlePrizeImg({
                                                            ok: false,
                                                            data: err,
                                                            msg: "画布导出生成图片失败"
                                                        });
                                                    }
                                                }, _this3);
                                            }, 500);
                                        });

                                      case 119:
                                      case "end":
                                        return _context.stop();
                                    }
                                }
                            }, _callee);
                        }))();
                    },
                    // 处理导出的图片
                    handlePrizeImg: function handlePrizeImg(res) {
                        var _this4 = this;
                        if (res.ok) {
                            var data = res.data;
                            if (!this.canvasCached) {
                                this.lotteryImg = data;
                                this.handlePrizeImgSuc(res);
                                return;
                            }
                            if (this.isCacheImg) {
                                uni.getSavedFileList({
                                    success: function success(sucRes) {
                                        var fileList = sucRes.fileList;
                                        // console.log('getSavedFileList Cached', fileList)
                                                                                var cached = false;
                                        if (fileList.length) {
                                            for (var i = 0; i < fileList.length; i++) {
                                                var item = fileList[i];
                                                if (item.filePath === data) {
                                                    cached = true;
                                                    _this4.lotteryImg = data;
                                                    console.info("经查，本地缓存中存在的转盘图可用，本次将不再绘制转盘");
                                                    _this4.handlePrizeImgSuc(res);
                                                    break;
                                                }
                                            }
                                        }
                                        if (!cached) {
                                            console.info("经查，本地缓存中存在的转盘图不可用，需要重新初始化转盘绘制");
                                            _this4.initCanvasDraw();
                                        }
                                    },
                                    fail: function fail(err) {
                                        _this4.initCanvasDraw();
                                    }
                                });
                            } else {
                                uni.saveFile({
                                    tempFilePath: data,
                                    success: function success(sucRes) {
                                        var filePath = sucRes.savedFilePath;
                                        // console.log('saveFile', filePath)
                                                                                (0, _almostUtils.setStore)("".concat(_this4.canvasId, "LotteryImg"), filePath);
                                        _this4.lotteryImg = filePath;
                                        _this4.handlePrizeImgSuc({
                                            ok: true,
                                            data: filePath,
                                            msg: "画布导出生成图片成功"
                                        });
                                    },
                                    fail: function fail(err) {
                                        _this4.handlePrizeImg({
                                            ok: false,
                                            data: err,
                                            msg: "画布导出生成图片失败"
                                        });
                                    }
                                });
                            }
                        } else {
                            console.error(res.msg, res);
                            console.error("###当前为小程序端，下载网络图片需要配置域名白名单###");
                        }
                    },
                    // 处理图片完成
                    handlePrizeImgSuc: function handlePrizeImgSuc(res) {
                        this.$emit("finish", {
                            ok: res.ok,
                            data: res.data,
                            msg: res.ok ? this.successMsg : this.failMsg
                        });
                    },
                    // 兼容 app 端不支持 ctx.measureText
                    // 已知问题：初始绘制时，低端安卓机 平均耗时 2s
                    // hbx 2.8.12+ 已在 app 端支持
                    getTextWidth: function getTextWidth() {
                        console.warn("正在采用兼容方式获取文本的 size 信息");
                        var query = uni.createSelectorQuery().in(this);
                        var nodesRef = query.select(".almost-lottery__measureText");
                        return new Promise(function(resolve, reject) {
                            nodesRef.fields({
                                size: true
                            }, function(res) {
                                resolve(res.width);
                            }).exec();
                        });
                    },
                    // 处理文字溢出
                    strLimit: function strLimit(value) {
                        var maxLength = this.strMaxLen;
                        if (!value || !maxLength) return value;
                        return (0, _almostUtils.clacTextLen)(value).realLen > maxLength ? value.slice(0, maxLength - 1) + ".." : value;
                    },
                    // 检查本地缓存中是否存在转盘图
                    checkCacheImg: function checkCacheImg() {
                        console.log("检查本地缓存中是否存在转盘图");
                        // 检查是否已有缓存的转盘图
                        // 检查是否与本次奖品数据相同
                                                this.oldLotteryImg = (0, _almostUtils.getStore)("".concat(this.canvasId, "LotteryImg"));
                        var oldPrizeList = (0, _almostUtils.getStore)("".concat(this.canvasId, "PrizeList"));
                        var newPrizeList = JSON.stringify(this.prizeList);
                        if (this.oldLotteryImg) {
                            console.log("经查，本地缓存中存在转盘图 => ".concat(this.oldLotteryImg, "，继续判断这张缓存图是否可用"));
                            if (oldPrizeList === newPrizeList) {
                                this.isCacheImg = true;
                                console.log("缓存图可用");
                                this.handlePrizeImg({
                                    ok: true,
                                    data: this.oldLotteryImg,
                                    msg: "画布导出生成图片成功"
                                });
                                return;
                            }
                        }
                        this.initCanvasDraw();
                    },
                    // 初始化绘制
                    initCanvasDraw: function initCanvasDraw() {
                        console.log("开始初始化转盘绘制");
                        this.isCacheImg = false;
                        this.lotteryImg = "";
                        (0, _almostUtils.clearStore)("".concat(this.canvasId, "LotteryImg"));
                        (0, _almostUtils.setStore)("".concat(this.canvasId, "PrizeList"), this.prizeList);
                        this.onCreateCanvas();
                    },
                    // 预处理初始化
                    beforeInit: function beforeInit() {
                        var _this5 = this;
                        return (0, _asyncToGenerator2.default)(/* */ _regenerator.default.mark(function _callee2() {
                            var query, lotterySize, actionSize, strMarginSize, imgMarginStr, imgSize, stoTimer;
                            return _regenerator.default.wrap(function _callee2$(_context2) {
                                while (1) {
                                    switch (_context2.prev = _context2.next) {
                                      case 0:
                                        query = uni.createSelectorQuery().in(_this5);
                                        // 处理 rpx 自适应尺寸
                                                                                _context2.next = 3;
                                        return new Promise(function(resolve) {
                                            query.select(".almost-lottery__wrap").boundingClientRect(function(rects) {
                                                resolve(rects);
                                                // console.log('处理 lottery rpx 的自适应', rects)
                                                                                        }).exec();
                                        });

                                      case 3:
                                        lotterySize = _context2.sent;
                                        _context2.next = 6;
                                        return new Promise(function(resolve) {
                                            query.select(".lottery-action").boundingClientRect(function(rects) {
                                                resolve(rects);
                                                // console.log('处理 action rpx 的自适应', rects)
                                                                                        }).exec();
                                        });

                                      case 6:
                                        actionSize = _context2.sent;
                                        _context2.next = 9;
                                        return new Promise(function(resolve) {
                                            query.select(".str-margin-outside").boundingClientRect(function(rects) {
                                                resolve(rects);
                                                // console.log('处理 str-margin-outside rpx 的自适应', rects)
                                                                                        }).exec();
                                        });

                                      case 9:
                                        strMarginSize = _context2.sent;
                                        _context2.next = 12;
                                        return new Promise(function(resolve) {
                                            query.select(".img-margin-str").boundingClientRect(function(rects) {
                                                resolve(rects);
                                                // console.log('处理 img-margin-str rpx 的自适应', rects)
                                                                                        }).exec();
                                        });

                                      case 12:
                                        imgMarginStr = _context2.sent;
                                        _context2.next = 15;
                                        return new Promise(function(resolve) {
                                            query.select(".img-size").boundingClientRect(function(rects) {
                                                resolve(rects);
                                                // console.log('处理 img-size rpx 的自适应', rects)
                                                                                        }).exec();
                                        });

                                      case 15:
                                        imgSize = _context2.sent;
                                        _this5.lotteryPxSize = Math.floor(lotterySize.width);
                                        _this5.canvasImgPxSize = _this5.lotteryPxSize - Math.floor(actionSize.left) + Math.floor(lotterySize.left);
                                        _this5.actionPxSize = Math.floor(actionSize.width);
                                        _this5.strMarginPxOutside = Math.floor(strMarginSize.left) - Math.floor(lotterySize.left);
                                        _this5.imgMarginPxStr = Math.floor(imgMarginStr.left) - Math.floor(lotterySize.left);
                                        _this5.imgPxWidth = Math.floor(imgSize.width);
                                        _this5.imgPxHeight = Math.floor(imgSize.height);
                                        // console.log(this.lotteryPxSize, this.canvasImgPxSize, this.actionPxSize)
                                                                                stoTimer = setTimeout(function() {
                                            clearTimeout(stoTimer);
                                            stoTimer = null;
                                            // 判断画板是否设置缓存
                                                                                        if (_this5.canvasCached) {
                                                _this5.checkCacheImg();
                                            } else {
                                                _this5.initCanvasDraw();
                                            }
                                        }, 50);

                                      case 24:
                                      case "end":
                                        return _context2.stop();
                                    }
                                }
                            }, _callee2);
                        }))();
                    }
                },
                mounted: function mounted() {
                    var _this6 = this;
                    this.$nextTick(function() {
                        var delay = 50 + _this6.renderDelay;
                        var stoTimer = setTimeout(function() {
                            clearTimeout(stoTimer);
                            stoTimer = null;
                            _this6.beforeInit();
                        }, delay);
                    });
                }
            };
            exports.default = _default2;
            /* WEBPACK VAR INJECTION */        }).call(this, __webpack_require__(/*! ./node_modules/@dcloudio/uni-mp-weixin/dist/index.js */ 2)["default"])
        /***/;
    },
    /***/ 252: 
    /*!******************************************************************************************************************************************************************!*\
  !*** /Users/feajun/riqianguan/uni_modules/almost-lottery/components/almost-lottery/almost-lottery.vue?vue&type=style&index=0&id=34b92f46&lang=scss&scoped=true& ***!
  \******************************************************************************************************************************************************************/
    /*! no static exports found */
    /***/ function(module, __webpack_exports__, __webpack_require__) {
        "use strict";
        __webpack_require__.r(__webpack_exports__);
        /* harmony import */        var _Applications_HBuilderX_app_Contents_HBuilderX_plugins_uniapp_cli_node_modules_mini_css_extract_plugin_dist_loader_js_ref_8_oneOf_1_0_Applications_HBuilderX_app_Contents_HBuilderX_plugins_uniapp_cli_node_modules_css_loader_dist_cjs_js_ref_8_oneOf_1_1_Applications_HBuilderX_app_Contents_HBuilderX_plugins_uniapp_cli_node_modules_dcloudio_vue_cli_plugin_uni_packages_vue_loader_lib_loaders_stylePostLoader_js_Applications_HBuilderX_app_Contents_HBuilderX_plugins_uniapp_cli_node_modules_dcloudio_vue_cli_plugin_uni_packages_webpack_preprocess_loader_index_js_ref_8_oneOf_1_2_Applications_HBuilderX_app_Contents_HBuilderX_plugins_uniapp_cli_node_modules_postcss_loader_src_index_js_ref_8_oneOf_1_3_Applications_HBuilderX_app_Contents_HBuilderX_plugins_uniapp_cli_node_modules_dcloudio_vue_cli_plugin_uni_packages_sass_loader_dist_cjs_js_ref_8_oneOf_1_4_Applications_HBuilderX_app_Contents_HBuilderX_plugins_uniapp_cli_node_modules_dcloudio_vue_cli_plugin_uni_packages_webpack_preprocess_loader_index_js_ref_8_oneOf_1_5_Applications_HBuilderX_app_Contents_HBuilderX_plugins_uniapp_cli_node_modules_dcloudio_vue_cli_plugin_uni_packages_vue_loader_lib_index_js_vue_loader_options_Applications_HBuilderX_app_Contents_HBuilderX_plugins_uniapp_cli_node_modules_dcloudio_webpack_uni_mp_loader_lib_style_js_almost_lottery_vue_vue_type_style_index_0_id_34b92f46_lang_scss_scoped_true___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../../../Applications/HBuilderX.app/Contents/HBuilderX/plugins/uniapp-cli/node_modules/mini-css-extract-plugin/dist/loader.js??ref--8-oneOf-1-0!../../../../../../../Applications/HBuilderX.app/Contents/HBuilderX/plugins/uniapp-cli/node_modules/css-loader/dist/cjs.js??ref--8-oneOf-1-1!../../../../../../../Applications/HBuilderX.app/Contents/HBuilderX/plugins/uniapp-cli/node_modules/@dcloudio/vue-cli-plugin-uni/packages/vue-loader/lib/loaders/stylePostLoader.js!../../../../../../../Applications/HBuilderX.app/Contents/HBuilderX/plugins/uniapp-cli/node_modules/@dcloudio/vue-cli-plugin-uni/packages/webpack-preprocess-loader??ref--8-oneOf-1-2!../../../../../../../Applications/HBuilderX.app/Contents/HBuilderX/plugins/uniapp-cli/node_modules/postcss-loader/src??ref--8-oneOf-1-3!../../../../../../../Applications/HBuilderX.app/Contents/HBuilderX/plugins/uniapp-cli/node_modules/@dcloudio/vue-cli-plugin-uni/packages/sass-loader/dist/cjs.js??ref--8-oneOf-1-4!../../../../../../../Applications/HBuilderX.app/Contents/HBuilderX/plugins/uniapp-cli/node_modules/@dcloudio/vue-cli-plugin-uni/packages/webpack-preprocess-loader??ref--8-oneOf-1-5!../../../../../../../Applications/HBuilderX.app/Contents/HBuilderX/plugins/uniapp-cli/node_modules/@dcloudio/vue-cli-plugin-uni/packages/vue-loader/lib??vue-loader-options!../../../../../../../Applications/HBuilderX.app/Contents/HBuilderX/plugins/uniapp-cli/node_modules/@dcloudio/webpack-uni-mp-loader/lib/style.js!./almost-lottery.vue?vue&type=style&index=0&id=34b92f46&lang=scss&scoped=true& */ 253);
        /* harmony import */        var _Applications_HBuilderX_app_Contents_HBuilderX_plugins_uniapp_cli_node_modules_mini_css_extract_plugin_dist_loader_js_ref_8_oneOf_1_0_Applications_HBuilderX_app_Contents_HBuilderX_plugins_uniapp_cli_node_modules_css_loader_dist_cjs_js_ref_8_oneOf_1_1_Applications_HBuilderX_app_Contents_HBuilderX_plugins_uniapp_cli_node_modules_dcloudio_vue_cli_plugin_uni_packages_vue_loader_lib_loaders_stylePostLoader_js_Applications_HBuilderX_app_Contents_HBuilderX_plugins_uniapp_cli_node_modules_dcloudio_vue_cli_plugin_uni_packages_webpack_preprocess_loader_index_js_ref_8_oneOf_1_2_Applications_HBuilderX_app_Contents_HBuilderX_plugins_uniapp_cli_node_modules_postcss_loader_src_index_js_ref_8_oneOf_1_3_Applications_HBuilderX_app_Contents_HBuilderX_plugins_uniapp_cli_node_modules_dcloudio_vue_cli_plugin_uni_packages_sass_loader_dist_cjs_js_ref_8_oneOf_1_4_Applications_HBuilderX_app_Contents_HBuilderX_plugins_uniapp_cli_node_modules_dcloudio_vue_cli_plugin_uni_packages_webpack_preprocess_loader_index_js_ref_8_oneOf_1_5_Applications_HBuilderX_app_Contents_HBuilderX_plugins_uniapp_cli_node_modules_dcloudio_vue_cli_plugin_uni_packages_vue_loader_lib_index_js_vue_loader_options_Applications_HBuilderX_app_Contents_HBuilderX_plugins_uniapp_cli_node_modules_dcloudio_webpack_uni_mp_loader_lib_style_js_almost_lottery_vue_vue_type_style_index_0_id_34b92f46_lang_scss_scoped_true___WEBPACK_IMPORTED_MODULE_0___default = /* */ __webpack_require__.n(_Applications_HBuilderX_app_Contents_HBuilderX_plugins_uniapp_cli_node_modules_mini_css_extract_plugin_dist_loader_js_ref_8_oneOf_1_0_Applications_HBuilderX_app_Contents_HBuilderX_plugins_uniapp_cli_node_modules_css_loader_dist_cjs_js_ref_8_oneOf_1_1_Applications_HBuilderX_app_Contents_HBuilderX_plugins_uniapp_cli_node_modules_dcloudio_vue_cli_plugin_uni_packages_vue_loader_lib_loaders_stylePostLoader_js_Applications_HBuilderX_app_Contents_HBuilderX_plugins_uniapp_cli_node_modules_dcloudio_vue_cli_plugin_uni_packages_webpack_preprocess_loader_index_js_ref_8_oneOf_1_2_Applications_HBuilderX_app_Contents_HBuilderX_plugins_uniapp_cli_node_modules_postcss_loader_src_index_js_ref_8_oneOf_1_3_Applications_HBuilderX_app_Contents_HBuilderX_plugins_uniapp_cli_node_modules_dcloudio_vue_cli_plugin_uni_packages_sass_loader_dist_cjs_js_ref_8_oneOf_1_4_Applications_HBuilderX_app_Contents_HBuilderX_plugins_uniapp_cli_node_modules_dcloudio_vue_cli_plugin_uni_packages_webpack_preprocess_loader_index_js_ref_8_oneOf_1_5_Applications_HBuilderX_app_Contents_HBuilderX_plugins_uniapp_cli_node_modules_dcloudio_vue_cli_plugin_uni_packages_vue_loader_lib_index_js_vue_loader_options_Applications_HBuilderX_app_Contents_HBuilderX_plugins_uniapp_cli_node_modules_dcloudio_webpack_uni_mp_loader_lib_style_js_almost_lottery_vue_vue_type_style_index_0_id_34b92f46_lang_scss_scoped_true___WEBPACK_IMPORTED_MODULE_0__);
        /* harmony reexport (unknown) */        for (var __WEBPACK_IMPORT_KEY__ in _Applications_HBuilderX_app_Contents_HBuilderX_plugins_uniapp_cli_node_modules_mini_css_extract_plugin_dist_loader_js_ref_8_oneOf_1_0_Applications_HBuilderX_app_Contents_HBuilderX_plugins_uniapp_cli_node_modules_css_loader_dist_cjs_js_ref_8_oneOf_1_1_Applications_HBuilderX_app_Contents_HBuilderX_plugins_uniapp_cli_node_modules_dcloudio_vue_cli_plugin_uni_packages_vue_loader_lib_loaders_stylePostLoader_js_Applications_HBuilderX_app_Contents_HBuilderX_plugins_uniapp_cli_node_modules_dcloudio_vue_cli_plugin_uni_packages_webpack_preprocess_loader_index_js_ref_8_oneOf_1_2_Applications_HBuilderX_app_Contents_HBuilderX_plugins_uniapp_cli_node_modules_postcss_loader_src_index_js_ref_8_oneOf_1_3_Applications_HBuilderX_app_Contents_HBuilderX_plugins_uniapp_cli_node_modules_dcloudio_vue_cli_plugin_uni_packages_sass_loader_dist_cjs_js_ref_8_oneOf_1_4_Applications_HBuilderX_app_Contents_HBuilderX_plugins_uniapp_cli_node_modules_dcloudio_vue_cli_plugin_uni_packages_webpack_preprocess_loader_index_js_ref_8_oneOf_1_5_Applications_HBuilderX_app_Contents_HBuilderX_plugins_uniapp_cli_node_modules_dcloudio_vue_cli_plugin_uni_packages_vue_loader_lib_index_js_vue_loader_options_Applications_HBuilderX_app_Contents_HBuilderX_plugins_uniapp_cli_node_modules_dcloudio_webpack_uni_mp_loader_lib_style_js_almost_lottery_vue_vue_type_style_index_0_id_34b92f46_lang_scss_scoped_true___WEBPACK_IMPORTED_MODULE_0__) if ([ "default" ].indexOf(__WEBPACK_IMPORT_KEY__) < 0) (function(key) {
            __webpack_require__.d(__webpack_exports__, key, function() {
                return _Applications_HBuilderX_app_Contents_HBuilderX_plugins_uniapp_cli_node_modules_mini_css_extract_plugin_dist_loader_js_ref_8_oneOf_1_0_Applications_HBuilderX_app_Contents_HBuilderX_plugins_uniapp_cli_node_modules_css_loader_dist_cjs_js_ref_8_oneOf_1_1_Applications_HBuilderX_app_Contents_HBuilderX_plugins_uniapp_cli_node_modules_dcloudio_vue_cli_plugin_uni_packages_vue_loader_lib_loaders_stylePostLoader_js_Applications_HBuilderX_app_Contents_HBuilderX_plugins_uniapp_cli_node_modules_dcloudio_vue_cli_plugin_uni_packages_webpack_preprocess_loader_index_js_ref_8_oneOf_1_2_Applications_HBuilderX_app_Contents_HBuilderX_plugins_uniapp_cli_node_modules_postcss_loader_src_index_js_ref_8_oneOf_1_3_Applications_HBuilderX_app_Contents_HBuilderX_plugins_uniapp_cli_node_modules_dcloudio_vue_cli_plugin_uni_packages_sass_loader_dist_cjs_js_ref_8_oneOf_1_4_Applications_HBuilderX_app_Contents_HBuilderX_plugins_uniapp_cli_node_modules_dcloudio_vue_cli_plugin_uni_packages_webpack_preprocess_loader_index_js_ref_8_oneOf_1_5_Applications_HBuilderX_app_Contents_HBuilderX_plugins_uniapp_cli_node_modules_dcloudio_vue_cli_plugin_uni_packages_vue_loader_lib_index_js_vue_loader_options_Applications_HBuilderX_app_Contents_HBuilderX_plugins_uniapp_cli_node_modules_dcloudio_webpack_uni_mp_loader_lib_style_js_almost_lottery_vue_vue_type_style_index_0_id_34b92f46_lang_scss_scoped_true___WEBPACK_IMPORTED_MODULE_0__[key];
            });
        })(__WEBPACK_IMPORT_KEY__);
        /* harmony default export */        __webpack_exports__["default"] = _Applications_HBuilderX_app_Contents_HBuilderX_plugins_uniapp_cli_node_modules_mini_css_extract_plugin_dist_loader_js_ref_8_oneOf_1_0_Applications_HBuilderX_app_Contents_HBuilderX_plugins_uniapp_cli_node_modules_css_loader_dist_cjs_js_ref_8_oneOf_1_1_Applications_HBuilderX_app_Contents_HBuilderX_plugins_uniapp_cli_node_modules_dcloudio_vue_cli_plugin_uni_packages_vue_loader_lib_loaders_stylePostLoader_js_Applications_HBuilderX_app_Contents_HBuilderX_plugins_uniapp_cli_node_modules_dcloudio_vue_cli_plugin_uni_packages_webpack_preprocess_loader_index_js_ref_8_oneOf_1_2_Applications_HBuilderX_app_Contents_HBuilderX_plugins_uniapp_cli_node_modules_postcss_loader_src_index_js_ref_8_oneOf_1_3_Applications_HBuilderX_app_Contents_HBuilderX_plugins_uniapp_cli_node_modules_dcloudio_vue_cli_plugin_uni_packages_sass_loader_dist_cjs_js_ref_8_oneOf_1_4_Applications_HBuilderX_app_Contents_HBuilderX_plugins_uniapp_cli_node_modules_dcloudio_vue_cli_plugin_uni_packages_webpack_preprocess_loader_index_js_ref_8_oneOf_1_5_Applications_HBuilderX_app_Contents_HBuilderX_plugins_uniapp_cli_node_modules_dcloudio_vue_cli_plugin_uni_packages_vue_loader_lib_index_js_vue_loader_options_Applications_HBuilderX_app_Contents_HBuilderX_plugins_uniapp_cli_node_modules_dcloudio_webpack_uni_mp_loader_lib_style_js_almost_lottery_vue_vue_type_style_index_0_id_34b92f46_lang_scss_scoped_true___WEBPACK_IMPORTED_MODULE_0___default.a;
        /***/    },
    /***/ 253: 
    /*!**********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/mini-css-extract-plugin/dist/loader.js??ref--8-oneOf-1-0!./node_modules/css-loader/dist/cjs.js??ref--8-oneOf-1-1!./node_modules/@dcloudio/vue-cli-plugin-uni/packages/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/@dcloudio/vue-cli-plugin-uni/packages/webpack-preprocess-loader??ref--8-oneOf-1-2!./node_modules/postcss-loader/src??ref--8-oneOf-1-3!./node_modules/@dcloudio/vue-cli-plugin-uni/packages/sass-loader/dist/cjs.js??ref--8-oneOf-1-4!./node_modules/@dcloudio/vue-cli-plugin-uni/packages/webpack-preprocess-loader??ref--8-oneOf-1-5!./node_modules/@dcloudio/vue-cli-plugin-uni/packages/vue-loader/lib??vue-loader-options!./node_modules/@dcloudio/webpack-uni-mp-loader/lib/style.js!/Users/feajun/riqianguan/uni_modules/almost-lottery/components/almost-lottery/almost-lottery.vue?vue&type=style&index=0&id=34b92f46&lang=scss&scoped=true& ***!
  \**********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
    /*! no static exports found */
    /***/ function(module, exports, __webpack_require__) {
        // extracted by mini-css-extract-plugin
        if (false) {
            var cssReload;
        }
        /***/    }
} ]);

//# sourceMappingURL=../../../../../.sourcemap/mp-weixin/uni_modules/almost-lottery/components/almost-lottery/almost-lottery.js.map
//# sourceMappingURL=../../../../../.sourcemap/mp-weixin/uni_modules/almost-lottery/components/almost-lottery/almost-lottery.js.map
(global["webpackJsonp"] = global["webpackJsonp"] || []).push([ "uni_modules/almost-lottery/components/almost-lottery/almost-lottery-create-component", {
    "uni_modules/almost-lottery/components/almost-lottery/almost-lottery-create-component": function(module, exports, __webpack_require__) {
        __webpack_require__("2")["createComponent"](__webpack_require__(247));
    }
}, [ [ "uni_modules/almost-lottery/components/almost-lottery/almost-lottery-create-component" ] ] ]);