var globalThis = this, self = this;module.exports =
require("../../_commons/0.js")([
{
"ids": [3],
"modules":{

/***/ "./node_modules/@mpflow/webpack-plugin/lib/loaders/page-loader.js?appContext=src%2Fplugin&outputPath=components%2Ftest%2Ftest!./src/plugin/components/test/test.ts":
/*!*************************************************************************************************************************************************************************!*\
  !*** ./node_modules/@mpflow/webpack-plugin/lib/loaders/page-loader.js?appContext=src%2Fplugin&outputPath=components%2Ftest%2Ftest!./src/plugin/components/test/test.ts ***!
  \*************************************************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__(/*! ./test.ts */ "./src/plugin/components/test/test.ts")

/***/ }),

/***/ "./src/plugin/components/test/test.ts":
/*!********************************************!*\
  !*** ./src/plugin/components/test/test.ts ***!
  \********************************************/
/*! no static exports found */
/***/ (function(module, exports) {

Component({
  data: {},
  methods: {
    attached: function attached() {
      // console.log('attached')
    }
  }
});

/***/ })

},
"entries": [["./node_modules/@mpflow/webpack-plugin/lib/loaders/page-loader.js?appContext=src%2Fplugin&outputPath=components%2Ftest%2Ftest!./src/plugin/components/test/test.ts",0]]
},
]);