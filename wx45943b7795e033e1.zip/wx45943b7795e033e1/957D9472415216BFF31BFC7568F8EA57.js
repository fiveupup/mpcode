var t = Behavior({
    lifetimes: {
        attached: function() {
            var t, n, e, u, o, r, i = getCurrentPages().pop();
            i.$bus || (i.$bus = (e = {}, u = [], r = [], {
                store: n = {
                    data: t = {},
                    get: function(n) {
                        return n ? t[n] : t;
                    },
                    set: function(n, e) {
                        t[n] = e;
                    },
                    remove: function(n) {
                        delete t[n];
                    },
                    init: function(n) {
                        Object.assign(t, n);
                    }
                },
                event: o = {
                    on: function(t, n) {
                        e[t] || (e[t] = []), e[t].push(n);
                    },
                    off: function(t, n) {
                        e[t] && (e[t] = n ? e[t].filter(function(t) {
                            return t !== n;
                        }) : []);
                    },
                    emit: function(t) {
                        for (var n = arguments.length, u = new Array(n > 1 ? n - 1 : 0), o = 1; o < n; o++) u[o - 1] = arguments[o];
                        e[t] && e[t].forEach(function(t) {
                            return t.apply(void 0, u);
                        });
                    },
                    export: function(t, n) {
                        u.push({
                            key: t,
                            fn: n
                        });
                    },
                    call: function(t) {
                        var n = u.find(function(n) {
                            return n.key === t;
                        });
                        if (n) {
                            for (var e = arguments.length, o = new Array(e > 1 ? e - 1 : 0), r = 1; r < e; r++) o[r - 1] = arguments[r];
                            return n.fn.apply(n, o);
                        }
                        console.error("没有找到".concat(t, "对应的函数"));
                    }
                },
                get: n.get,
                set: n.set,
                emit: o.emit,
                on: o.on,
                setTimeout: function() {
                    var t = setTimeout.apply(null, arguments);
                    return r.push(t), t;
                },
                clearTimeout: function() {
                    r.forEach(function(t) {
                        return clearTimeout(t);
                    });
                },
                sleep: function(t) {
                    return new Promise(function(n) {
                        setTimeout(n, t);
                    });
                }
            }), i.store && i.store.constructor === Function && i.$bus.store.init(i.store()), 
            wx.$bus = i.$bus), this.$bus = i.$bus;
        },
        detached: function() {
            this.$bus.clearTimeout(), this.$bus = null;
        }
    }
});

wx.Bus = t;