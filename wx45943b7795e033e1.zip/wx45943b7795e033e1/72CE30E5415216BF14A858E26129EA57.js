var e = require("@babel/runtime/helpers/interopRequireDefault.js")(require("@babel/runtime/regenerator.js")), t = require("@babel/runtime/helpers/asyncToGenerator.js"), r = require("557F3602415216BF33195E05F196EA57.js"), n = r.hosts, o = r.env, u = getApp(), a = {
    req: function(r, a, i) {
        var s = arguments.length > 3 && void 0 !== arguments[3] ? arguments[3] : {};
        u || (u = getApp());
        var c = 0, f = function(e, t, n, o) {
            try {
                u.addEvent({
                    id: "request",
                    type: e,
                    code: t,
                    status: n,
                    c0: c,
                    path: r,
                    msg: JSON.stringify(o)
                });
            } catch (e) {}
        };
        return new Promise(function(g, p) {
            var d = c > 0 ? "重试" : "请求";
            !function l() {
                var x;
                s.token = wx.getStorageSync("token"), wx.request({
                    url: n[o].api + r,
                    data: a,
                    method: i,
                    header: s,
                    timeout: 15e3,
                    success: (x = t(e.default.mark(function t(r) {
                        return e.default.wrap(function(e) {
                            for (;;) switch (e.prev = e.next) {
                              case 0:
                                if (401 !== r.statusCode && 403 !== r.statusCode) {
                                    e.next = 18;
                                    break;
                                }
                                if (f(d, r.statusCode, "error", ""), 401 !== r.statusCode) {
                                    e.next = 12;
                                    break;
                                }
                                if (!(c > 3)) {
                                    e.next = 7;
                                    break;
                                }
                                return wx.showModel({
                                    title: "登录失效",
                                    content: "请截图并联系客服"
                                }), p(r.data), e.abrupt("return");

                              case 7:
                                return c++, e.next = 10, u.wxLogin();

                              case 10:
                                return l(), e.abrupt("return");

                              case 12:
                                if (403 !== r.statusCode) {
                                    e.next = 18;
                                    break;
                                }
                                if (wx.getStorageSync("token")) {
                                    e.next = 18;
                                    break;
                                }
                                return e.next = 16, u.wxLogin();

                              case 16:
                                return l(), e.abrupt("return");

                              case 18:
                                g(r.data);

                              case 19:
                              case "end":
                                return e.stop();
                            }
                        }, t);
                    })), function(e) {
                        return x.apply(this, arguments);
                    }),
                    fail: function(e) {
                        if (c < 3) return l(), void c++;
                        console.log("request fail", e), f(d, e.code, "error", e), p(e);
                    }
                });
            }();
        });
    },
    get: function(e, t) {
        return this.req(e, "", "get", t);
    },
    post: function(e, t, r) {
        return this.req(e, t, "post", r);
    }
};

module.exports = {
    request: a,
    login: function(e) {
        return a.post("/login", e);
    },
    getConfig: function() {
        return a.get("/getConfig");
    },
    getTTS: function(e) {
        var t = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : 1001;
        return a.post("/v2/tts", {
            text: e,
            voice_type: t
        });
    }
};