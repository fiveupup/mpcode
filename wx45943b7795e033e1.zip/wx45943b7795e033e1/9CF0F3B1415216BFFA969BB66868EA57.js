module.exports = Behavior({
    behaviors: [ wx.Bus ],
    data: {},
    methods: {
        initBlack: function() {
            this.cacheKey = "zp_".concat(this.$bus.get("zpInfo").id), this.blackItems = wx.getStorageSync(this.cacheKey) || [], 
            this.blackItems = this.blackItems.filter(function(t) {
                return t;
            }), this.$bus.store.set("blackItemsId", this.blackItems), console.log("初始化转盘黑名单", this.blackItems), 
            this.blackItems.length >= 0 && this.$bus.event.call("summarize_bar:updateCount", this.blackItems.length);
        },
        clearBlack: function() {
            wx.removeStorageSync(this.cacheKey), this.blackItems = [], this.$bus.store.set("blackItemsId", this.blackItems), 
            this.$bus.event.call("summarize_bar:updateCount", this.blackItems.length);
        },
        addBlack: function(t) {
            var e = this.$bus.get("zpInfo");
            e.settings && e.settings.no_repeat && (this.blackItems.push(t.id), wx.setStorageSync(this.cacheKey, this.blackItems), 
            this.$bus.event.call("summarize_bar:updateCount", this.blackItems.length));
        },
        removeBlack: function(t) {
            var e = this.blackItems.findIndex(function(e) {
                return e.id === t.id;
            });
            e > -1 && (this.blackItems.splice(e, 1), wx.setStorageSync(this.cacheKey, this.blackItems), 
            this.$bus.event.call("summarize_bar:updateCount", this.blackItems.length));
        },
        getBlackLength: function() {
            return this.blackItems.length;
        },
        checkIsInBlack: function(t) {
            return !!t && this.blackItems.includes(t.id);
        }
    },
    lifetimes: {
        attached: function() {
            var t = this;
            this.$bus.event.on("page:zpInfoLoaded", this.initBlack.bind(this)), this.$bus.event.on("page:recoveryZp", this.clearBlack.bind(this)), 
            this.$bus.event.on("zhuanpan:stop", function(e) {
                t.addBlack(e);
            }), this.$bus.event.export("black:addBlack", this.addBlack.bind(this)), this.$bus.event.export("black:removeBlack", this.removeBlack.bind(this)), 
            this.$bus.event.export("black:getBlackLength", this.getBlackLength.bind(this)), 
            this.$bus.event.export("black:checkIsInBlack", this.checkIsInBlack.bind(this)), 
            this.$bus.event.export("black:clearBlack", this.clearBlack.bind(this)), this.$bus.event.export("black:initBlack", this.initBlack.bind(this)), 
            this.$bus.event.export("black:getBlackItemsIndex", function(e) {
                var s = [];
                return t.blackItems.forEach(function(t) {
                    e[t] && s.push(e[t].index);
                }), s;
            });
        }
    }
});