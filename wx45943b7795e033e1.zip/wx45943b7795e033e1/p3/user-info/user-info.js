var e = require("../../@babel/runtime/helpers/interopRequireDefault")(require("../../@babel/runtime/regenerator")), t = require("../../@babel/runtime/helpers/asyncToGenerator"), r = require("../../E36C2C77415216BF850A44701BF6EA57.js"), a = r.getUploadToken, n = r.updateAvatar, o = r.updateUserInfo, u = getApp();

Page({
    data: {
        userInfo: {}
    },
    showAvatar: function() {
        var e = "http://pan.jialidun.vip/".concat(this.data.userInfo.wx_avatar, "?imageMogr2/thumbnail/500x");
        console.log("imgUrl", e), wx.previewImage({
            urls: [ e ]
        });
    },
    onLoad: function(e) {
        this.getUserInfo();
    },
    onChooseAvatar: function(r) {
        var o = this;
        return t(e.default.mark(function s() {
            var i, c, l, f;
            return e.default.wrap(function(s) {
                for (;;) switch (s.prev = s.next) {
                  case 0:
                    return i = r.detail.avatarUrl, c = Math.random().toString(36).substr(2), l = "avatars/".concat(c, ".png"), 
                    s.next = 5, a({
                        key: l
                    });

                  case 5:
                    f = s.sent, wx.uploadFile({
                        url: "https://upload-z1.qiniup.com",
                        filePath: i,
                        name: "file",
                        formData: {
                            key: l,
                            token: f.data
                        },
                        success: function() {
                            var r = t(e.default.mark(function t() {
                                var r;
                                return e.default.wrap(function(e) {
                                    for (;;) switch (e.prev = e.next) {
                                      case 0:
                                        return console.log("上传成功", r), e.next = 3, n({
                                            avatar: l
                                        });

                                      case 3:
                                        r = e.sent, wx.showToast({
                                            title: "头像修改成功"
                                        }), wx.removeStorageSync("userInfo"), u.globalData.userInfo = null, o.getUserInfo();

                                      case 8:
                                      case "end":
                                        return e.stop();
                                    }
                                }, t);
                            }));
                            return function() {
                                return r.apply(this, arguments);
                            };
                        }(),
                        fail: function(e) {
                            console.log("上传失败", e);
                        }
                    });

                  case 7:
                  case "end":
                    return s.stop();
                }
            }, s);
        }))();
    },
    getUserInfo: function(r) {
        var a = this;
        return t(e.default.mark(function t() {
            var r;
            return e.default.wrap(function(e) {
                for (;;) switch (e.prev = e.next) {
                  case 0:
                    return e.next = 2, u.getUser();

                  case 2:
                    r = e.sent, a.setData({
                        userInfo: r
                    });

                  case 4:
                  case "end":
                    return e.stop();
                }
            }, t);
        }))();
    },
    onInputChange: function(r) {
        var a = this;
        return t(e.default.mark(function t() {
            var n;
            return e.default.wrap(function(e) {
                for (;;) switch (e.prev = e.next) {
                  case 0:
                    if (n = r.detail.value, console.log(n), n !== a.data.userInfo.wx_name) {
                        e.next = 4;
                        break;
                    }
                    return e.abrupt("return");

                  case 4:
                    return e.next = 6, o({
                        wx_name: n
                    });

                  case 6:
                    0 === e.sent.code && (wx.showToast({
                        title: "修改成功"
                    }), wx.removeStorageSync("userInfo"), u.globalData.userInfo = null, a.getUserInfo());

                  case 8:
                  case "end":
                    return e.stop();
                }
            }, t);
        }))();
    }
});