$gwx_XC_32=function(_,_v,_n,_p,_s,_wp,_wl,$gwn,$gwl,$gwh,wh,$gstack,$gwrt,gra,grb,TestTest,wfor,_ca,_da,_r,_rz,_o,_oz,_1,_1z,_2,_2z,_m,_mz,nv_getDate,nv_getRegExp,nv_console,nv_parseInt,nv_parseFloat,nv_isNaN,nv_isFinite,nv_decodeURI,nv_decodeURIComponent,nv_encodeURI,nv_encodeURIComponent,$gdc,nv_JSON,_af,_gv,_ai,_grp,_gd,_gapi,$ixc,_ic,_w,_ev,_tsd){return function(path,global){
if(typeof global==='undefined'){if (typeof __GWX_GLOBAL__==='undefined')global={};else global=__GWX_GLOBAL__;}if(typeof __WXML_GLOBAL__ === 'undefined') {__WXML_GLOBAL__={};
}__WXML_GLOBAL__.modules = __WXML_GLOBAL__.modules || {};
var e_={}
if(typeof(global.entrys)==='undefined')global.entrys={};e_=global.entrys;
var d_={}
if(typeof(global.defines)==='undefined')global.defines={};d_=global.defines;
var f_={}
if(typeof(global.modules)==='undefined')global.modules={};f_=global.modules || {};
var p_={}
__WXML_GLOBAL__.ops_cached = __WXML_GLOBAL__.ops_cached || {}
__WXML_GLOBAL__.ops_set = __WXML_GLOBAL__.ops_set || {};
__WXML_GLOBAL__.ops_init = __WXML_GLOBAL__.ops_init || {};
var z=__WXML_GLOBAL__.ops_set.$gwx_XC_32 || [];
function gz$gwx_XC_32_1(){
if( __WXML_GLOBAL__.ops_cached.$gwx_XC_32_1)return __WXML_GLOBAL__.ops_cached.$gwx_XC_32_1
__WXML_GLOBAL__.ops_cached.$gwx_XC_32_1=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
Z([3,'onChooseAvatar'])
Z([3,'item item-btn'])
Z([3,'chooseAvatar'])
Z([3,'plain'])
Z([3,'ml3'])
Z([3,'arrow'])
})(__WXML_GLOBAL__.ops_cached.$gwx_XC_32_1);return __WXML_GLOBAL__.ops_cached.$gwx_XC_32_1
}
__WXML_GLOBAL__.ops_set.$gwx_XC_32=z;
__WXML_GLOBAL__.ops_init.$gwx_XC_32=true;
var x=['./p3/user-info/user-info.wxml'];d_[x[0]]={}
var m0=function(e,s,r,gg){
var z=gz$gwx_XC_32_1()
var oDH=_mz(z,'button',['bind:chooseavatar',0,'class',1,'openType',1,'type',2],[],e,s,gg)
var fEH=_mz(z,'van-icon',['class',4,'name',1],[],e,s,gg)
_(oDH,fEH)
_(r,oDH)
return r
}
e_[x[0]]={f:m0,j:[],i:[],ti:[],ic:[]}
if(path&&e_[path]){
return function(env,dd,global){$gwxc=0;var root={"tag":"wx-page"};root.children=[]
;g="$gwx_XC_32";var main=e_[path].f
if (typeof global==="undefined")global={};global.f=$gdc(f_[path],"",1);
try{
main(env,{},root,global);
_tsd(root)
}catch(err){
console.log(err)
}
;g="";
return root;
}
}
}
}(__g.a,__g.b,__g.c,__g.d,__g.e,__g.f,__g.g,__g.h,__g.i,__g.j,__g.k,__g.l,__g.m,__g.n,__g.o,__g.p,__g.q,__g.r,__g.s,__g.t,__g.u,__g.v,__g.w,__g.x,__g.y,__g.z,__g.A,__g.B,__g.C,__g.D,__g.E,__g.F,__g.G,__g.H,__g.I,__g.J,__g.K,__g.L,__g.M,__g.N,__g.O,__g.P,__g.Q,__g.R,__g.S,__g.T,__g.U,__g.V,__g.W,__g.X,__g.Y,__g.Z,__g.aa);if(__vd_version_info__.delayedGwx||false)$gwx_XC_32();	if (__vd_version_info__.delayedGwx) __wxAppCode__['p3/user-info/user-info.wxml'] = [$gwx_XC_32, './p3/user-info/user-info.wxml'];else __wxAppCode__['p3/user-info/user-info.wxml'] = $gwx_XC_32( './p3/user-info/user-info.wxml' );
	;__wxRoute = "p3/user-info/user-info";__wxRouteBegin = true;__wxAppCurrentFile__="p3/user-info/user-info.js";define("p3/user-info/user-info.js",function(require,module,exports,window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){
"use strict";var e=require("../../@babel/runtime/helpers/interopRequireDefault")(require("../../@babel/runtime/regenerator")),t=require("../../@babel/runtime/helpers/asyncToGenerator"),r=require("../../E36C2C77415216BF850A44701BF6EA57.js"),a=r.getUploadToken,n=r.updateAvatar,o=r.updateUserInfo,u=getApp();Page({data:{userInfo:{}},showAvatar:function(){var e="http://pan.jialidun.vip/".concat(this.data.userInfo.wx_avatar,"?imageMogr2/thumbnail/500x");console.log("imgUrl",e),wx.previewImage({urls:[e]})},onLoad:function(e){this.getUserInfo()},onChooseAvatar:function(r){var o=this;return t(e.default.mark((function s(){var i,c,l,f;return e.default.wrap((function(s){for(;;)switch(s.prev=s.next){case 0:return i=r.detail.avatarUrl,c=Math.random().toString(36).substr(2),l="avatars/".concat(c,".png"),s.next=5,a({key:l});case 5:f=s.sent,wx.uploadFile({url:"https://upload-z1.qiniup.com",filePath:i,name:"file",formData:{key:l,token:f.data},success:function(){var r=t(e.default.mark((function t(){var r;return e.default.wrap((function(e){for(;;)switch(e.prev=e.next){case 0:return console.log("上传成功",r),e.next=3,n({avatar:l});case 3:r=e.sent,wx.showToast({title:"头像修改成功"}),wx.removeStorageSync("userInfo"),u.globalData.userInfo=null,o.getUserInfo();case 8:case"end":return e.stop()}}),t)})));return function(){return r.apply(this,arguments)}}(),fail:function(e){console.log("上传失败",e)}});case 7:case"end":return s.stop()}}),s)})))()},getUserInfo:function(r){var a=this;return t(e.default.mark((function t(){var r;return e.default.wrap((function(e){for(;;)switch(e.prev=e.next){case 0:return e.next=2,u.getUser();case 2:r=e.sent,a.setData({userInfo:r});case 4:case"end":return e.stop()}}),t)})))()},onInputChange:function(r){var a=this;return t(e.default.mark((function t(){var n;return e.default.wrap((function(e){for(;;)switch(e.prev=e.next){case 0:if(n=r.detail.value,console.log(n),n!==a.data.userInfo.wx_name){e.next=4;break}return e.abrupt("return");case 4:return e.next=6,o({wx_name:n});case 6:0===e.sent.code&&(wx.showToast({title:"修改成功"}),wx.removeStorageSync("userInfo"),u.globalData.userInfo=null,a.getUserInfo());case 8:case"end":return e.stop()}}),t)})))()}});
},{isPage:true,isComponent:true,currentFile:'p3/user-info/user-info.js'});require("p3/user-info/user-info.js");