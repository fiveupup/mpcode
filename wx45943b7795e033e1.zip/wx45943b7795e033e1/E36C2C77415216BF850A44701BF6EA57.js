var e = require("72CE30E5415216BF14A858E26129EA57.js").request;

module.exports = {
    getUploadToken: function(t) {
        return e.post("/v2/qiniu/getUploadToken", t);
    },
    updateAvatar: function(t) {
        return e.post("/v2/user/updateUserAvatar", t);
    },
    updateUserInfo: function(t) {
        return e.post("/v2/user/updateUserInfo", t);
    },
    getUser: function() {
        return e.post("/v2/getUser");
    }
};