var e = require("@babel/runtime/helpers/interopRequireDefault.js")(require("@babel/runtime/regenerator.js")), t = require("@babel/runtime/helpers/asyncToGenerator.js"), n = require("8A51F322415216BFEC379B250C07EA57.js");

module.exports = Behavior({
    behaviors: [ wx.Bus ],
    properties: {},
    data: {},
    methods: {
        updateMain: function(e) {
            var t = getCurrentPages();
            if (!(t.length < 2)) {
                var n = t[t.length - 2], i = n.data.list, a = i.find(function(t) {
                    return t.id === e.id;
                });
                a && (a.title = e.title, n.setData({
                    list: i
                }));
            }
        },
        tapMore: function() {
            this.checkZpIsReady() && this.$bus.event.call("more:showMore");
        },
        saveZp: function() {
            var i = this;
            return t(e.default.mark(function t() {
                var a, s;
                return e.default.wrap(function(e) {
                    for (;;) switch (e.prev = e.next) {
                      case 0:
                        return a = i.$bus.get("zpInfo"), e.next = 3, n.copy(a.id);

                      case 3:
                        0 == (s = e.sent).code && (wx.showToast({
                            title: "已保存到我的转盘",
                            icon: "none"
                        }), i.initZp(s.data));

                      case 5:
                      case "end":
                        return e.stop();
                    }
                }, t);
            }))();
        },
        showSaveZp: function() {
            var e = this;
            wx.showModal({
                title: "提示",
                content: "保存后，你可以自由编辑当前转盘，在首页【我的转盘】可以找到当前转盘",
                confirm: "保存",
                cancel: "取消",
                success: function(t) {
                    t.confirm && e.saveZp();
                }
            });
        },
        tapEdit: function() {
            wx.navigateTo({
                url: "/pages/zhuanpan/edit/edit?type=edit&id=".concat(this.$bus.store.get("zpInfo").id)
            });
        }
    },
    lifetimes: {
        attached: function() {
            var e = this;
            this.$bus.event.on("edit:saveSuccess", function(t) {
                var n = t.zpInfo;
                n.title !== e.$bus.store.get("zpInfo").title && wx.nextTick(function() {
                    e.updateMain(n);
                }), e.initZp(n);
            }), this.$bus.event.on("zhuanpan:start", function() {
                e.setData({
                    zpState: 2
                });
            }), this.$bus.event.on("zhuanpan:stop", function(t) {
                e.setData({
                    zpState: 1
                });
            }), this.$bus.event.export("page:updateRecordsTimes", function() {
                var t = e.$bus.get("zpInfo");
                e.getZPRecordsTimes(t);
            });
        }
    }
});