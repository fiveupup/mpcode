module.exports = {
    checkIsInBlack: function(n, e) {
        return 0 !== e.length && !!e.find(function(e) {
            return e.index === n.index;
        });
    }
};