var e = require("@babel/runtime/helpers/defineProperty.js");

module.exports = Behavior({
    behaviors: [ wx.Bus ],
    properties: {},
    lifetimes: {
        attached: function() {
            var t = this;
            this.$bus.event.export("page:setColor", function(i) {
                var o = i.color, r = i.index;
                t.setData(e({}, "zp_info.items_obj[".concat(r, "].color"), o));
            }), this.$bus.on("loading:hide", function(e) {
                1 === e.status && wx.navigateBack();
            });
        }
    }
});