module.exports = {
    hosts: {
        production: {
            api: "https://app02.a1.jialidun.vip",
            cdn: "https://app02.a1.jialidun.vip"
        },
        dev: {
            api: "https://dev-api.example.com",
            cdn: "https://dev-cdn.example.com"
        },
        local: {
            api: "http://localhost:3002",
            cdn: "http://localhost:3001"
        }
    },
    env: "production"
};