require("@babel/runtime/helpers/Arrayincludes.js");

getApp(), require("99A2A570415216BFFFC4CD77E7C6EA57.js").checkIsInBlack;

module.exports = Behavior({
    behaviors: [ wx.Bus ],
    data: {
        style: ""
    },
    lifetimes: {
        detached: function() {
            console.log("control detached"), this.clearTimer();
        },
        attached: function() {
            this.$bus.event.on("page:zpInfoLoaded", this.resetZp.bind(this)), this.$bus.on("page:recoveryZp", this.recoveryZp.bind(this));
        }
    },
    methods: {
        recoveryZp: function() {
            var t = this.$bus.get("showItems");
            t.forEach(function(t) {
                t.status = 0;
            }), this.setData({
                showItems: t
            });
        },
        resetZp: function() {
            console.log("resetZp"), this.state = "stopped", this.lastTurn = 0, this.result = "", 
            this.turnId = Math.floor(1e3 * Math.random()), this.setData({
                style: ""
            });
        },
        clearTimer: function() {
            this.timer && (clearTimeout(this.timer), this.timer = null);
        },
        checkLeftTimes: function() {
            this.$bus.store.get("shouldSaveResult") && (console.log("检查次数", this.$bus.store.get("recordsTimes"), this.$bus.store.get("zpInfo").share_settings.p_times), 
            this.$bus.store.get("recordsTimes") >= this.$bus.store.get("zpInfo").share_settings.p_times && (console.log("您的数已用完"), 
            wx.showToast({
                title: "您的数已用完",
                icon: "none"
            })));
        },
        start: function() {
            var t = this;
            this.checkLeftTimes(), this.clearTimer(), this.turnId = Math.floor(1e3 * Math.random());
            var s = this.$bus.get("showItems");
            if (s.forEach(function(t) {
                t.status = 0;
            }), this.setData({
                showItems: s
            }), this.$bus.get("blackItemsId").length !== s.length) {
                this.$bus.set("state", "running"), this.$bus.emit("zhuanpan:start");
                var e = this.$bus.store.get("allWeightItems"), i = e, n = this.$bus.store.get("realItems"), o = this.$bus.event.call("black:getBlackItemsIndex", this.$bus.get("item_map"));
                console.log("blackItemsIndex", o), o.length > 0 && (i = e.filter(function(t) {
                    return !o.includes(t);
                }), console.log("过滤黑名单", i));
                var r = i[Math.floor(Math.random() * i.length)];
                if (n[r]) {
                    this.currentTurn = 3 + (n[r].startDeg + n[r].deg / 2) / 360 + (1 - this.lastTurn % 1);
                    var h, a = this.lastTurn;
                    this.lastTurn += this.currentTurn, this.result = n[r], this.$bus.store.get("zpInfo").settings && this.$bus.store.get("zpInfo").settings.seconds && (h = this.$bus.store.get("zpInfo").settings.seconds);
                    var u = h ? 1e3 * h : 1e3 * this.currentTurn, l = "transform: rotate(".concat(a + this.currentTurn, "turn);transition: all ").concat(u, "ms cubic-bezier(0, 0.55, 0.45, 1);");
                    this.setData({
                        style: l
                    });
                    var c = Date.now(), g = this.turnId;
                    !function s() {
                        if (t.$bus) {
                            var i = Date.now() - c;
                            if (!(i >= u)) {
                                if (g !== t.turnId) return wx.vibrateShort(), void (t.notShowResult = !0);
                                var o, r = 360 * (o = i / u, Math.sqrt(1 - Math.pow(o - 1, 2)) * t.currentTurn) + a % 1 * 360;
                                r %= 360, r = (r -= n[0].deg / 2) < 0 ? r + 360 : r;
                                var h = Math.ceil(r / 360 * e.length) % e.length, l = n[e[h]], m = t.$bus.store.get("zpInfo");
                                m.settings && m.settings.hide_weight && (h = Math.ceil(r / 360 * m.items_obj.length) % m.items_obj.length, 
                                l = m.items_obj[h]), t.notShowResult ? t.$bus.emit("zhuanpan:step", {
                                    text: "??"
                                }) : t.$bus.emit("zhuanpan:step", l), t.timer = setTimeout(function() {
                                    s();
                                }, 120);
                            }
                        }
                    }();
                }
            } else this.$bus.event.call("black:clearBlack");
        },
        shotResult: function() {
            var t = this.$bus.get("result");
            console.log(t);
            var s = this.$bus.get("showItems");
            s.forEach(function(s) {
                s.index === t.index ? s.status = 0 : s.status = -1;
            }), this.setData({
                showItems: s
            });
        },
        onZpStopped: function(t) {
            this.notShowResult = !1, this.$bus.set("state", "stopped"), this.$bus.set("result", this.result), 
            this.$bus.emit("zhuanpan:stop", this.result), this.shotResult();
        },
        longtap: function(t) {
            wx.vibrateLong(), this.start();
        }
    }
});