var e = require("@babel/runtime/helpers/interopRequireDefault.js")(require("@babel/runtime/regenerator.js")), r = require("@babel/runtime/helpers/asyncToGenerator.js"), t = require("72CE30E5415216BF14A858E26129EA57.js"), n = t.checkMsg, a = t.getConfig, u = function() {
    var t = r(e.default.mark(function r(t) {
        var a;
        return e.default.wrap(function(e) {
            for (;;) switch (e.prev = e.next) {
              case 0:
                return e.next = 2, n(t);

              case 2:
                if (0 == (a = e.sent).code) {
                    e.next = 5;
                    break;
                }
                return e.abrupt("return", -1);

              case 5:
                if (!a.data.result || "pass" != a.data.result.suggest) {
                    e.next = 7;
                    break;
                }
                return e.abrupt("return", 1);

              case 7:
                return e.abrupt("return", 0);

              case 8:
              case "end":
                return e.stop();
            }
        }, r);
    }));
    return function(e) {
        return t.apply(this, arguments);
    };
}();

function s() {
    return (s = r(e.default.mark(function r() {
        var t;
        return e.default.wrap(function(e) {
            for (;;) switch (e.prev = e.next) {
              case 0:
                return e.next = 2, a();

              case 2:
                0 == (t = e.sent).code && (console.log("加载配置成功", t), wx.setStorageSync("config", t.data));

              case 4:
              case "end":
                return e.stop();
            }
        }, r);
    }))).apply(this, arguments);
}

module.exports = {
    checkMsgPass: u,
    loadConfig: function() {
        return s.apply(this, arguments);
    }
};