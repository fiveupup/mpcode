var e = require("@babel/runtime/helpers/interopRequireDefault"), t = require("@babel/runtime/helpers/createForOfIteratorHelper"), o = require("@babel/runtime/helpers/objectSpread2"), n = e(require("@babel/runtime/regenerator")), a = require("@babel/runtime/helpers/asyncToGenerator"), r = require("72CE30E5415216BF14A858E26129EA57.js").login, s = require("E36C2C77415216BF850A44701BF6EA57.js").getUser, i = (require("957D9472415216BFF31BFC7568F8EA57.js"), 
require("60E11BA5415216BF068773A28F29EA57.js"));

App({
    onLaunch: function(e) {
        var t = this;
        return a(n.default.mark(function o() {
            var a, r, s, c;
            return n.default.wrap(function(o) {
                for (;;) switch (o.prev = o.next) {
                  case 0:
                    console.log("启动参数", e), a = e.scene, e.query && (r = e.query, s = r.top_c, c = r.sub_c, 
                    t.globalData.top_c = s, t.globalData.sub_c = c), t.globalData.scene = a, t.globalData.deviceInfo = wx.getSystemInfoSync(), 
                    i.loadConfig();

                  case 6:
                  case "end":
                    return o.stop();
                }
            }, o);
        }))();
    },
    globalData: {
        userInfo: null,
        settings: {}
    },
    initLogin: function() {
        var e = this;
        return a(n.default.mark(function t() {
            return n.default.wrap(function(t) {
                for (;;) switch (t.prev = t.next) {
                  case 0:
                    if (console.log("--登录--"), t.prev = 1, wx.getStorageSync("token")) {
                        t.next = 7;
                        break;
                    }
                    return console.log("用户未登录"), t.abrupt("return", e.wxLogin());

                  case 7:
                    return e.globalData.userInfo = wx.getStorageSync("userInfo"), e.globalData.openid = wx.getStorageSync("openid"), 
                    t.abrupt("return", !0);

                  case 10:
                    t.next = 16;
                    break;

                  case 12:
                    return t.prev = 12, t.t0 = t.catch(1), console.log("检查登录异常了"), t.abrupt("return", !1);

                  case 16:
                  case "end":
                    return t.stop();
                }
            }, t, null, [ [ 1, 12 ] ]);
        }))();
    },
    wxLogin: function() {
        var e = this, t = this.globalData.deviceInfo, s = t.brand, i = t.system, c = t.platform, l = t.version, u = t.model, g = {
            scene: this.globalData.scene,
            sub_c: this.globalData.sub_c,
            top_c: this.globalData.top_c,
            brand: s,
            system: i,
            platform: c,
            model: u,
            version: l
        };
        return new Promise(function(t, s) {
            var i;
            wx.login({
                success: (i = a(n.default.mark(function a(i) {
                    var c, l, u, d, f, p;
                    return n.default.wrap(function(n) {
                        for (;;) switch (n.prev = n.next) {
                          case 0:
                            return c = i.code, n.next = 3, r(o({
                                code: c
                            }, g));

                          case 3:
                            0 == (l = n.sent).code ? (console.log("登录成功", l), u = l.data, d = u.openid, f = u.token, 
                            p = u.user, e.globalData.userInfo = p, e.globalData.openid = d, wx.setStorageSync("token", f), 
                            wx.setStorageSync("openid", d), wx.setStorageSync("userInfo", p), t(!0)) : (console.log("登录失败", l), 
                            s(!1));

                          case 5:
                          case "end":
                            return n.stop();
                        }
                    }, a);
                })), function(e) {
                    return i.apply(this, arguments);
                })
            });
        });
    },
    getUser: function() {
        var e = this;
        return a(n.default.mark(function t() {
            var o, a;
            return n.default.wrap(function(t) {
                for (;;) switch (t.prev = t.next) {
                  case 0:
                    if (!e.globalData.userInfo) {
                        t.next = 2;
                        break;
                    }
                    return t.abrupt("return", e.globalData.userInfo);

                  case 2:
                    if (!(o = wx.getStorageSync("userInfo"))) {
                        t.next = 6;
                        break;
                    }
                    return e.globalData.userInfo = o, t.abrupt("return", o);

                  case 6:
                    return t.next = 8, s();

                  case 8:
                    if (0 !== (a = t.sent).code) {
                        t.next = 15;
                        break;
                    }
                    return e.globalData.userInfo = a.data, wx.setStorageSync("userInfo", a.data), t.abrupt("return", a.data);

                  case 15:
                    return t.abrupt("return", null);

                  case 16:
                  case "end":
                    return t.stop();
                }
            }, t);
        }))();
    },
    getAd: function() {},
    getSettings: function() {},
    pushLog: function() {
        console.log("开始上传埋点");
        var e = wx.getStorageSync("logs") || [], o = wx.getStorageSync("openid"), n = wx.getStorageSync("unionid"), a = wx.getAccountInfoSync().miniProgram;
        if (!(e.length < 1)) {
            var r, s = t(e);
            try {
                for (s.s(); !(r = s.n()).done; ) {
                    var i = r.value;
                    i.openid = o, i.unionid = n, i.appid = a.appId, i.version = a.version, i.scene = this.globalData.scene, 
                    i.top_c = this.globalData.top_c, i.sub_c = this.globalData.sub_c, this.globalData.userInfo && (i.ftop_c = this.globalData.userInfo.top_c, 
                    i.fsub_c = this.globalData.userInfo.sub_c);
                }
            } catch (e) {
                s.e(e);
            } finally {
                s.f();
            }
            wx.request({
                url: "https://a.jialidun.vip/logs",
                method: "POST",
                data: e,
                success: function(e) {
                    console.log("上传埋点成功", e), wx.setStorageSync("logs", []);
                },
                fail: function(e) {
                    console.log("上传埋点失败", e);
                }
            });
        }
    },
    addEvent: function(e) {
        console.log("====addEvent 添加埋点===="), console.log(e), console.log("========");
        try {
            var t = o({}, e);
            delete t.id, wx.reportEvent(e.id, t);
        } catch (e) {
            console.error("埋点异常", e);
        }
    },
    addLog: function(e) {
        e.ts = new Date().toLocaleString(), console.log("====addLog 添加埋点===="), console.log(e), 
        console.log("========");
        var t = wx.getStorageSync("logs") || [];
        t.push(e), wx.setStorageSync("logs", t);
    },
    onHide: function() {
        console.log("onHide"), this.addLog({
            id: "onHide",
            duration: Date.now() - this.globalData.start_ts
        }), this.pushLog();
    },
    onError: function(e) {
        console.log("onError", e), this.addLog({
            id: "onError",
            msg: e
        }), this.pushLog();
    },
    loadMini: function() {
        if (console.log("加载半屏"), wx.openEmbeddedMiniProgram && wx.getStorageSync("config").showMiniAd) {
            var e = wx.getStorageSync("didiTs");
            if (!e || e <= Date.now()) {
                this.addLog({
                    id: "loadMiniAd",
                    type: "didi"
                });
                return wx.openEmbeddedMiniProgram({
                    appId: "wxaf35009675aa0b2a",
                    path: "/pages/index/index?scene=DegbZQn&source_id=1"
                }), void wx.setStorageSync("didiTs", new Date().setHours(0, 0, 0, 0) + 864e5);
            }
            this.addLog({
                id: "loadMiniAd"
            }), wx.openEmbeddedMiniProgram({
                appId: "wxece3a9a4c82f58c9",
                path: "commercialize/pages/taoke-guide/index?scene=78a98a9b2d544d18bd2b52f5276c0467"
            });
        }
    }
});