var e = require("@babel/runtime/helpers/interopRequireDefault.js")(require("@babel/runtime/regenerator.js")), t = require("@babel/runtime/helpers/asyncToGenerator.js"), r = require("72CE30E5415216BF14A858E26129EA57.js").request;

function n() {
    return (n = t(e.default.mark(function t(n) {
        var s;
        return e.default.wrap(function(e) {
            for (;;) switch (e.prev = e.next) {
              case 0:
                return e.prev = 0, e.next = 3, r.post("/v2/checkMsg", {
                    msg: n
                });

              case 3:
                if (0 !== (s = e.sent).code || "pass" !== s.data.result.suggest) {
                    e.next = 6;
                    break;
                }
                return e.abrupt("return", !0);

              case 6:
                e.next = 10;
                break;

              case 8:
                e.prev = 8, e.t0 = e.catch(0);

              case 10:
                return e.abrupt("return", !1);

              case 11:
              case "end":
                return e.stop();
            }
        }, t, null, [ [ 0, 8 ] ]);
    }))).apply(this, arguments);
}

function s() {
    return (s = t(e.default.mark(function t(n) {
        return e.default.wrap(function(e) {
            for (;;) switch (e.prev = e.next) {
              case 0:
                return e.abrupt("return", r.post("/v2/draws/copy", {
                    id: n
                }));

              case 1:
              case "end":
                return e.stop();
            }
        }, t);
    }))).apply(this, arguments);
}

module.exports = {
    list: function(e) {
        return r.post("/v2/draws/list2", {
            offset: e
        });
    },
    findOneById: function(e) {
        return r.post("/v2/draws/findOneById", {
            id: e
        });
    },
    deleteOneById: function(e) {
        return r.post("/v2/draws/deleteOneById", {
            id: e
        });
    },
    updateOne: function(e) {
        return r.post("/v2/draws/updateOne", e);
    },
    checkMsg: function(e) {
        return n.apply(this, arguments);
    },
    copy: function(e) {
        return s.apply(this, arguments);
    },
    createZpRecord: function(e) {
        return r.post("/v2/draws_result/create", e);
    },
    MyZPRecordsCount: function(e) {
        return r.post("/v2/draws_result/userRecordsCount", e);
    },
    MyZPRecords: function(e) {
        return r.post("/v2/draws_result/userRecords", e);
    },
    allRecords: function(e) {
        return r.post("/v2/draws_result/all", e);
    },
    delRecord: function(e) {
        return r.post("/v2/draws_result/deleteOneById", e);
    },
    UpdateShareSettings: function(e) {
        return r.post("/v2/draws/UpdateShareSettings", e);
    },
    loadTemplates: function(e) {
        return r.post("/templates/list", e);
    },
    addToHot: function(e) {
        return r.post("/templates/storeByDrawId", {
            drawId: e
        });
    },
    getTemplateById: function(e) {
        return r.post("/templates/getOne", {
            id: e
        });
    }
};