var t = require("@babel/runtime/helpers/interopRequireDefault.js")(require("@babel/runtime/regenerator.js")), e = require("@babel/runtime/helpers/asyncToGenerator.js"), a = require("72CE30E5415216BF14A858E26129EA57.js").getTTS;

module.exports = Behavior({
    behaviors: [ wx.Bus ],
    properties: {},
    data: {
        audioCtx: {
            audio: null
        },
        audioIndex: 0
    },
    methods: {
        playAudio: function() {
            this.data.audioCtx.audio.seek(0), this.data.audioCtx.audio.play();
        }
    },
    lifetimes: {
        attached: function() {
            var i = this;
            this.data.audioCtx.audio || (this.data.audioCtx.audio = wx.createInnerAudioContext(), 
            this.data.audioCtx.audio.src = "http://pan00.jialidun.vip/audio/win.mp3", this.data.audioCtx.audio.volume = .8), 
            this.$bus.event.on("zhuanpan:stop", function() {
                var u = e(t.default.mark(function e(u) {
                    var r, s;
                    return t.default.wrap(function(t) {
                        for (;;) switch (t.prev = t.next) {
                          case 0:
                            if (!i.$bus.get("settings").sound) {
                                t.next = 13;
                                break;
                            }
                            if (i.playAudio(), "none" !== i.$bus.get("settings").speaker) {
                                t.next = 4;
                                break;
                            }
                            return t.abrupt("return");

                          case 4:
                            return t.next = 6, a(u.text, i.$bus.get("settings").speaker || 1);

                          case 6:
                            if (0 === (r = t.sent).code) {
                                t.next = 9;
                                break;
                            }
                            return t.abrupt("return");

                          case 9:
                            s = r.data, i.ttsAudio || (i.ttsAudio = wx.createInnerAudioContext()), i.ttsAudio.src = s, 
                            i.ttsAudio.play();

                          case 13:
                          case "end":
                            return t.stop();
                        }
                    }, e);
                }));
                return function(t) {
                    return u.apply(this, arguments);
                };
            }());
        },
        ready: function() {
            console.log("result ready"), this.ttsAudio || (this.ttsAudio = wx.createInnerAudioContext());
        },
        detached: function() {
            this.$bus && (this.$bus.event.off("zhuanpan:stop"), this.ttsAudio && this.ttsAudio.destroy());
        }
    }
});