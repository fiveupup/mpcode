module.exports = {
    sensitiveHash: function(r) {
        for (var t = 0, e = 0; e < r.length; e++) {
            t = (t << 5) - t + r.charCodeAt(e), t |= 0;
        }
        for (var o = "", s = 0; s < 8; s++) {
            o += "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789".charAt(63 & t), 
            t >>= 6;
        }
        return o;
    }
};