Component({
    properties: {
        all_num: {
            type: Number
        },
        item: {
            type: Object,
            observer: function(t) {
                if (t) {
                    var e = {
                        color: t.color,
                        text: t.text.length > 15 ? t.text.substring(0, 15) + "..." : t.text,
                        all_deg: t.deg,
                        deg: t.deg > 180 ? [ t.deg / 2, t.deg / 2 ] : [ t.deg ],
                        text_class: "",
                        bg_class: ""
                    };
                    -1 === t.status ? (e.text_class = "text-blur", e.bg_class = "bg-blur") : -2 === t.status ? (e.color = "#333", 
                    e.text_class = "text-blur") : 0 === t.status && (e.color = t.color, e.text_class = "", 
                    e.bg_class = ""), this.setData(e);
                }
            }
        },
        radius: {
            type: Number
        }
    },
    data: {
        color: "#000",
        all_deg: 30,
        deg: [ 30 ],
        text: "👌🏻",
        text_class: "",
        bg_class: ""
    },
    methods: {}
});