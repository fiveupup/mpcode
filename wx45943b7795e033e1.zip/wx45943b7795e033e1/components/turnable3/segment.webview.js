$gwx_XC_6=function(_,_v,_n,_p,_s,_wp,_wl,$gwn,$gwl,$gwh,wh,$gstack,$gwrt,gra,grb,TestTest,wfor,_ca,_da,_r,_rz,_o,_oz,_1,_1z,_2,_2z,_m,_mz,nv_getDate,nv_getRegExp,nv_console,nv_parseInt,nv_parseFloat,nv_isNaN,nv_isFinite,nv_decodeURI,nv_decodeURIComponent,nv_encodeURI,nv_encodeURIComponent,$gdc,nv_JSON,_af,_gv,_ai,_grp,_gd,_gapi,$ixc,_ic,_w,_ev,_tsd){return function(path,global){
if(typeof global==='undefined'){if (typeof __GWX_GLOBAL__==='undefined')global={};else global=__GWX_GLOBAL__;}if(typeof __WXML_GLOBAL__ === 'undefined') {__WXML_GLOBAL__={};
}__WXML_GLOBAL__.modules = __WXML_GLOBAL__.modules || {};
var e_={}
if(typeof(global.entrys)==='undefined')global.entrys={};e_=global.entrys;
var d_={}
if(typeof(global.defines)==='undefined')global.defines={};d_=global.defines;
var f_={}
if(typeof(global.modules)==='undefined')global.modules={};f_=global.modules || {};
var p_={}
__WXML_GLOBAL__.ops_cached = __WXML_GLOBAL__.ops_cached || {}
__WXML_GLOBAL__.ops_set = __WXML_GLOBAL__.ops_set || {};
__WXML_GLOBAL__.ops_init = __WXML_GLOBAL__.ops_init || {};
var z=__WXML_GLOBAL__.ops_set.$gwx_XC_6 || [];
function gz$gwx_XC_6_1(){
if( __WXML_GLOBAL__.ops_cached.$gwx_XC_6_1)return __WXML_GLOBAL__.ops_cached.$gwx_XC_6_1
__WXML_GLOBAL__.ops_cached.$gwx_XC_6_1=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
Z([3,'wrap'])
Z([a,[3,'transform:rotate('],[[6],[[7],[3,'item']],[3,'startDeg']],[3,'deg);']])
Z([[7],[3,'deg']])
Z([3,'index'])
Z([3,'item'])
Z([a,[3,'left:'],[[7],[3,'radius']],[3,'px;width:'],[[7],[3,'radius']],[3,'px;height:'],[[2,'*'],[1,2],[[7],[3,'radius']]],[3,'px;border-radius:0 '],[[7],[3,'radius']],[3,'px '],[[7],[3,'radius']],[3,'px 0;transform:rotate('],[[2,'*'],[[7],[3,'item']],[[7],[3,'index']]],z[1][3]])
Z([a,[3,'filter '],[[7],[3,'bg_class']]])
Z([a,[3,'transform:rotate(-'],[[2,'-'],[1,180],[[7],[3,'item']]],[3,'deg);background:'],[[7],[3,'color']],[3,';']])
Z([3,'text-wrap'])
Z([a,z[5][1],[1,0],z[5][3],z[5][6],z[5][5],z[5][6],z[5][7],z[5][2],z[5][9],z[5][2],z[5][11],[[2,'/'],[[7],[3,'all_deg']],[1,2]],[3,'deg)']])
Z([a,[3,'text '],[[7],[3,'text_class']]])
Z([a,[3,'font-size:'],[[12],[[6],[[7],[3,'tools']],[3,'getFontSize']],[[5],[[5],[[5],[[7],[3,'radius']]],[[7],[3,'text']]],[[7],[3,'all_num']]]],[3,'px']])
Z([a,[[7],[3,'text']]])
})(__WXML_GLOBAL__.ops_cached.$gwx_XC_6_1);return __WXML_GLOBAL__.ops_cached.$gwx_XC_6_1
}
__WXML_GLOBAL__.ops_set.$gwx_XC_6=z;
__WXML_GLOBAL__.ops_init.$gwx_XC_6=true;
var x=['./components/turnable3/segment.wxml'];d_[x[0]]={}
var m0=function(e,s,r,gg){
var z=gz$gwx_XC_6_1()
var lIC=_mz(z,'view',['class',0,'style',1],[],e,s,gg)
var aJC=_v()
_(lIC,aJC)
var tKC=function(bMC,eLC,oNC,gg){
var oPC=_mz(z,'view',['class',4,'style',1],[],bMC,eLC,gg)
var fQC=_mz(z,'view',['class',6,'style',1],[],bMC,eLC,gg)
_(oPC,fQC)
_(oNC,oPC)
return oNC
}
aJC.wxXCkey=2
_2z(z,2,tKC,e,s,gg,aJC,'item','index','index')
var cRC=_mz(z,'view',['class',8,'style',1],[],e,s,gg)
var hSC=_mz(z,'view',['class',10,'style',1],[],e,s,gg)
var oTC=_oz(z,12,e,s,gg)
_(hSC,oTC)
_(cRC,hSC)
_(lIC,cRC)
_(r,lIC)
return r
}
e_[x[0]]={f:m0,j:[],i:[],ti:[],ic:[]}
if(path&&e_[path]){
outerGlobal.__wxml_comp_version__=0.02
return function(env,dd,global){$gwxc=0;var root={"tag":"wx-page"};root.children=[]
;g="$gwx_XC_6";var main=e_[path].f
if (typeof global==="undefined")global={};global.f=$gdc(f_[path],"",1);
if(typeof(outerGlobal.__webview_engine_version__)!='undefined'&&outerGlobal.__webview_engine_version__+1e-6>=0.02+1e-6&&outerGlobal.__mergeData__)
{
env=outerGlobal.__mergeData__(env,dd);
}
try{
main(env,{},root,global);
_tsd(root)
if(typeof(outerGlobal.__webview_engine_version__)=='undefined'|| outerGlobal.__webview_engine_version__+1e-6<0.01+1e-6){return _ev(root);}
}catch(err){
console.log(err)
}
;g="";
return root;
}
}
}
}(__g.a,__g.b,__g.c,__g.d,__g.e,__g.f,__g.g,__g.h,__g.i,__g.j,__g.k,__g.l,__g.m,__g.n,__g.o,__g.p,__g.q,__g.r,__g.s,__g.t,__g.u,__g.v,__g.w,__g.x,__g.y,__g.z,__g.A,__g.B,__g.C,__g.D,__g.E,__g.F,__g.G,__g.H,__g.I,__g.J,__g.K,__g.L,__g.M,__g.N,__g.O,__g.P,__g.Q,__g.R,__g.S,__g.T,__g.U,__g.V,__g.W,__g.X,__g.Y,__g.Z,__g.aa);if(__vd_version_info__.delayedGwx||false)$gwx_XC_6();	if (__vd_version_info__.delayedGwx) __wxAppCode__['components/turnable3/segment.wxml'] = [$gwx_XC_6, './components/turnable3/segment.wxml'];else __wxAppCode__['components/turnable3/segment.wxml'] = $gwx_XC_6( './components/turnable3/segment.wxml' );
	
var noCss=typeof __vd_version_info__!=='undefined'&&__vd_version_info__.noCss===true;if(!noCss){__wxAppCode__['components/turnable3/segment.wxss'] = setCssToHead([".",[1],"wrap{height:100%;position:absolute;width:100%}\n.",[1],"item{overflow:hidden}\n.",[1],"filter,.",[1],"item{position:absolute;-webkit-transform-origin:left center;transform-origin:left center}\n.",[1],"filter{z-index:-1}\n.",[1],"filter,.",[1],"text-wrap{height:100%;width:100%}\n.",[1],"text-wrap{z-index:1}\n.",[1],"text,.",[1],"text-wrap{position:absolute}\n.",[1],"text{word-wrap:break-word;color:#fff;font-weight:700;line-height:1.2;padding:0 3em 0 1em;text-shadow:0 0 2px rgba(0,0,0,.5);top:50%;-webkit-transform:translateY(-50%) rotate(90deg);transform:translateY(-50%) rotate(90deg);-webkit-transform-origin:right center;transform-origin:right center;width:50%}\n.",[1],"bg-blur:after{background:rgba(0,0,0,.5);content:\x22\x22;height:100%;left:0;position:absolute;top:0;width:100%}\n.",[1],"text-blur{color:#fff;opacity:.5}\n",],undefined,{path:"./components/turnable3/segment.wxss"});
}