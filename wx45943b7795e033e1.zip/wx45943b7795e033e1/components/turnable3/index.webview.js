$gwx_XC_5=function(_,_v,_n,_p,_s,_wp,_wl,$gwn,$gwl,$gwh,wh,$gstack,$gwrt,gra,grb,TestTest,wfor,_ca,_da,_r,_rz,_o,_oz,_1,_1z,_2,_2z,_m,_mz,nv_getDate,nv_getRegExp,nv_console,nv_parseInt,nv_parseFloat,nv_isNaN,nv_isFinite,nv_decodeURI,nv_decodeURIComponent,nv_encodeURI,nv_encodeURIComponent,$gdc,nv_JSON,_af,_gv,_ai,_grp,_gd,_gapi,$ixc,_ic,_w,_ev,_tsd){return function(path,global){
if(typeof global==='undefined'){if (typeof __GWX_GLOBAL__==='undefined')global={};else global=__GWX_GLOBAL__;}if(typeof __WXML_GLOBAL__ === 'undefined') {__WXML_GLOBAL__={};
}__WXML_GLOBAL__.modules = __WXML_GLOBAL__.modules || {};
var e_={}
if(typeof(global.entrys)==='undefined')global.entrys={};e_=global.entrys;
var d_={}
if(typeof(global.defines)==='undefined')global.defines={};d_=global.defines;
var f_={}
if(typeof(global.modules)==='undefined')global.modules={};f_=global.modules || {};
var p_={}
__WXML_GLOBAL__.ops_cached = __WXML_GLOBAL__.ops_cached || {}
__WXML_GLOBAL__.ops_set = __WXML_GLOBAL__.ops_set || {};
__WXML_GLOBAL__.ops_init = __WXML_GLOBAL__.ops_init || {};
var z=__WXML_GLOBAL__.ops_set.$gwx_XC_5 || [];
function gz$gwx_XC_5_1(){
if( __WXML_GLOBAL__.ops_cached.$gwx_XC_5_1)return __WXML_GLOBAL__.ops_cached.$gwx_XC_5_1
__WXML_GLOBAL__.ops_cached.$gwx_XC_5_1=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
Z([3,'container'])
Z([a,[3,'width:'],[[2,'*'],[1,2],[[7],[3,'radius']]],[3,'px;height:'],[[2,'*'],[1,2],[[7],[3,'radius']]],[3,'px']])
Z([[7],[3,'items']])
Z([3,'index'])
Z([[6],[[7],[3,'items']],[3,'length']])
Z([[7],[3,'item']])
Z([[7],[3,'radius']])
Z(z[2])
Z(z[3])
Z([3,'line'])
Z([a,[3,'left:'],z[6],z[1][3],z[6],[3,'px;transform: translateX(-50%) rotate('],[[6],[[7],[3,'item']],[3,'endDeg']],[3,'deg)']])
})(__WXML_GLOBAL__.ops_cached.$gwx_XC_5_1);return __WXML_GLOBAL__.ops_cached.$gwx_XC_5_1
}
__WXML_GLOBAL__.ops_set.$gwx_XC_5=z;
__WXML_GLOBAL__.ops_init.$gwx_XC_5=true;
var x=['./components/turnable3/index.wxml'];d_[x[0]]={}
var m0=function(e,s,r,gg){
var z=gz$gwx_XC_5_1()
var o2B=_mz(z,'view',['class',0,'style',1],[],e,s,gg)
var c3B=_v()
_(o2B,c3B)
var o4B=function(a6B,l5B,t7B,gg){
var b9B=_n('view')
var o0B=_mz(z,'segment',['all_num',4,'item',1,'radius',2],[],a6B,l5B,gg)
_(b9B,o0B)
_(t7B,b9B)
return t7B
}
c3B.wxXCkey=4
_2z(z,2,o4B,e,s,gg,c3B,'item','index','index')
var xAC=_v()
_(o2B,xAC)
var oBC=function(cDC,fCC,hEC,gg){
var cGC=_mz(z,'view',['class',9,'style',1],[],cDC,fCC,gg)
_(hEC,cGC)
return hEC
}
xAC.wxXCkey=2
_2z(z,7,oBC,e,s,gg,xAC,'item','index','index')
_(r,o2B)
return r
}
e_[x[0]]={f:m0,j:[],i:[],ti:[],ic:[]}
if(path&&e_[path]){
outerGlobal.__wxml_comp_version__=0.02
return function(env,dd,global){$gwxc=0;var root={"tag":"wx-page"};root.children=[]
;g="$gwx_XC_5";var main=e_[path].f
if (typeof global==="undefined")global={};global.f=$gdc(f_[path],"",1);
if(typeof(outerGlobal.__webview_engine_version__)!='undefined'&&outerGlobal.__webview_engine_version__+1e-6>=0.02+1e-6&&outerGlobal.__mergeData__)
{
env=outerGlobal.__mergeData__(env,dd);
}
try{
main(env,{},root,global);
_tsd(root)
if(typeof(outerGlobal.__webview_engine_version__)=='undefined'|| outerGlobal.__webview_engine_version__+1e-6<0.01+1e-6){return _ev(root);}
}catch(err){
console.log(err)
}
;g="";
return root;
}
}
}
}(__g.a,__g.b,__g.c,__g.d,__g.e,__g.f,__g.g,__g.h,__g.i,__g.j,__g.k,__g.l,__g.m,__g.n,__g.o,__g.p,__g.q,__g.r,__g.s,__g.t,__g.u,__g.v,__g.w,__g.x,__g.y,__g.z,__g.A,__g.B,__g.C,__g.D,__g.E,__g.F,__g.G,__g.H,__g.I,__g.J,__g.K,__g.L,__g.M,__g.N,__g.O,__g.P,__g.Q,__g.R,__g.S,__g.T,__g.U,__g.V,__g.W,__g.X,__g.Y,__g.Z,__g.aa);if(__vd_version_info__.delayedGwx||false)$gwx_XC_5();	if (__vd_version_info__.delayedGwx) __wxAppCode__['components/turnable3/index.wxml'] = [$gwx_XC_5, './components/turnable3/index.wxml'];else __wxAppCode__['components/turnable3/index.wxml'] = $gwx_XC_5( './components/turnable3/index.wxml' );
	
var noCss=typeof __vd_version_info__!=='undefined'&&__vd_version_info__.noCss===true;if(!noCss){__wxAppCode__['components/turnable3/index.wxss'] = setCssToHead([[2,"./app.wxss"],"wx-view{box-sizing:border-box}\n.",[1],"container{border-radius:50%;margin:auto;position:relative}\n.",[1],"container:after{background:#fafafa;border-radius:50%;box-shadow:0 0 ",[0,8]," rgba(0,0,0,.3);content:\x22\x22;height:calc(100% + ",[0,16],");left:",[0,-8],";position:absolute;top:",[0,-8],";width:calc(100% + ",[0,16],");z-index:-1}\n.",[1],"item{overflow:hidden;-webkit-transform-origin:left center;transform-origin:left center}\n.",[1],"item,.",[1],"text{position:absolute}\n.",[1],"text{height:",[0,130],";left:0;top:0;-webkit-transform-origin:bottom center;transform-origin:bottom center}\n.",[1],"innerText{color:#fafafa;font-size:",[0,24],";font-weight:500;max-height:",[0,80],";overflow:hidden;padding:0 ",[0,50]," 0 ",[0,16],";text-overflow:ellipsis;-webkit-transform:rotate(90deg) translate(50%,-50%);transform:rotate(90deg) translate(50%,-50%);-webkit-transform-origin:top;transform-origin:top}\n.",[1],"line{background:#fafafa;-webkit-transform-origin:bottom center;transform-origin:bottom center;width:1px}\n.",[1],"filter,.",[1],"line{position:absolute}\n.",[1],"filter{height:100%;-webkit-transform-origin:left center;transform-origin:left center;width:100%;z-index:-1}\n@media (prefers-color-scheme:dark){.",[1],"container:after{background:#000;box-shadow:0 0 ",[0,8]," rgba(0,0,0,.5)}\n.",[1],"line{background:#000}\n}",],"Some selectors are not allowed in component wxss, including tag name selectors, ID selectors, and attribute selectors.(./components/turnable3/index.wxss:1:28)",{path:"./components/turnable3/index.wxss"});
}