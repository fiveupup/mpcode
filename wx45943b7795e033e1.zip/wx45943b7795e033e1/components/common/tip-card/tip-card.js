Component({
    properties: {
        showClose: {
            type: Boolean
        }
    },
    data: {
        show: !0
    },
    methods: {
        close: function() {
            this.setData({
                show: !1
            });
        }
    }
});