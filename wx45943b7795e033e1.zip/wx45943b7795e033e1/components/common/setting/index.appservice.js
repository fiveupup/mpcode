$gwx_XC_1=function(_,_v,_n,_p,_s,_wp,_wl,$gwn,$gwl,$gwh,wh,$gstack,$gwrt,gra,grb,TestTest,wfor,_ca,_da,_r,_rz,_o,_oz,_1,_1z,_2,_2z,_m,_mz,nv_getDate,nv_getRegExp,nv_console,nv_parseInt,nv_parseFloat,nv_isNaN,nv_isFinite,nv_decodeURI,nv_decodeURIComponent,nv_encodeURI,nv_encodeURIComponent,$gdc,nv_JSON,_af,_gv,_ai,_grp,_gd,_gapi,$ixc,_ic,_w,_ev,_tsd){return function(path,global){
if(typeof global==='undefined'){if (typeof __GWX_GLOBAL__==='undefined')global={};else global=__GWX_GLOBAL__;}if(typeof __WXML_GLOBAL__ === 'undefined') {__WXML_GLOBAL__={};
}__WXML_GLOBAL__.modules = __WXML_GLOBAL__.modules || {};
var e_={}
if(typeof(global.entrys)==='undefined')global.entrys={};e_=global.entrys;
var d_={}
if(typeof(global.defines)==='undefined')global.defines={};d_=global.defines;
var f_={}
if(typeof(global.modules)==='undefined')global.modules={};f_=global.modules || {};
var p_={}
__WXML_GLOBAL__.ops_cached = __WXML_GLOBAL__.ops_cached || {}
__WXML_GLOBAL__.ops_set = __WXML_GLOBAL__.ops_set || {};
__WXML_GLOBAL__.ops_init = __WXML_GLOBAL__.ops_init || {};
var z=__WXML_GLOBAL__.ops_set.$gwx_XC_1 || [];
function gz$gwx_XC_1_1(){
if( __WXML_GLOBAL__.ops_cached.$gwx_XC_1_1)return __WXML_GLOBAL__.ops_cached.$gwx_XC_1_1
__WXML_GLOBAL__.ops_cached.$gwx_XC_1_1=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
Z([3,'closeSetting'])
Z([3,'height:530rpx;background:#fff;transition:all .3s ease-out;padding-bottom:50rpx'])
Z([3,'bottom'])
Z([[7],[3,'showSetting']])
Z([3,'wrap'])
Z([3,'item'])
Z([3,'mr1'])
Z([3,'sjzp-a-27Hguanbixunhuan'])
Z([3,'40rpx'])
Z([3,'changeSetting'])
Z([[6],[[7],[3,'settings']],[3,'noRepeat']])
Z([3,'noRepeat'])
Z([3,'50rpx'])
Z(z[5])
Z(z[6])
Z([3,'music-o'])
Z([3,'36rpx'])
Z(z[9])
Z([[6],[[7],[3,'settings']],[3,'music']])
Z([3,'music'])
Z(z[12])
Z(z[5])
Z(z[6])
Z([3,'sjzp-zhendong'])
Z(z[16])
Z(z[9])
Z([[6],[[7],[3,'settings']],[3,'vibrate']])
Z([3,'vibrate'])
Z(z[12])
})(__WXML_GLOBAL__.ops_cached.$gwx_XC_1_1);return __WXML_GLOBAL__.ops_cached.$gwx_XC_1_1
}
__WXML_GLOBAL__.ops_set.$gwx_XC_1=z;
__WXML_GLOBAL__.ops_init.$gwx_XC_1=true;
var x=['./components/common/setting/index.wxml'];d_[x[0]]={}
var m0=function(e,s,r,gg){
var z=gz$gwx_XC_1_1()
var oD=_mz(z,'van-popup',['closeable',-1,'round',-1,'bind:close',0,'customStyle',1,'position',1,'show',2],[],e,s,gg)
var fE=_n('view')
_rz(z,fE,'class',4,e,s,gg)
var cF=_n('view')
_rz(z,cF,'class',5,e,s,gg)
var hG=_mz(z,'van-icon',['class',6,'name',1,'size',2],[],e,s,gg)
_(cF,hG)
var oH=_mz(z,'van-switch',['bind:change',9,'checked',1,'data-key',2,'size',3],[],e,s,gg)
_(cF,oH)
_(fE,cF)
var cI=_n('view')
_rz(z,cI,'class',13,e,s,gg)
var oJ=_mz(z,'van-icon',['class',14,'name',1,'size',2],[],e,s,gg)
_(cI,oJ)
var lK=_mz(z,'van-switch',['bind:change',17,'checked',1,'data-key',2,'size',3],[],e,s,gg)
_(cI,lK)
_(fE,cI)
var aL=_n('view')
_rz(z,aL,'class',21,e,s,gg)
var tM=_mz(z,'van-icon',['class',22,'name',1,'size',2],[],e,s,gg)
_(aL,tM)
var eN=_mz(z,'van-switch',['bind:change',25,'checked',1,'data-key',2,'size',3],[],e,s,gg)
_(aL,eN)
_(fE,aL)
_(oD,fE)
_(r,oD)
return r
}
e_[x[0]]={f:m0,j:[],i:[],ti:[],ic:[]}
if(path&&e_[path]){
return function(env,dd,global){$gwxc=0;var root={"tag":"wx-page"};root.children=[]
;g="$gwx_XC_1";var main=e_[path].f
if (typeof global==="undefined")global={};global.f=$gdc(f_[path],"",1);
try{
main(env,{},root,global);
_tsd(root)
}catch(err){
console.log(err)
}
;g="";
return root;
}
}
}
}(__g.a,__g.b,__g.c,__g.d,__g.e,__g.f,__g.g,__g.h,__g.i,__g.j,__g.k,__g.l,__g.m,__g.n,__g.o,__g.p,__g.q,__g.r,__g.s,__g.t,__g.u,__g.v,__g.w,__g.x,__g.y,__g.z,__g.A,__g.B,__g.C,__g.D,__g.E,__g.F,__g.G,__g.H,__g.I,__g.J,__g.K,__g.L,__g.M,__g.N,__g.O,__g.P,__g.Q,__g.R,__g.S,__g.T,__g.U,__g.V,__g.W,__g.X,__g.Y,__g.Z,__g.aa);if(__vd_version_info__.delayedGwx||false)$gwx_XC_1();	if (__vd_version_info__.delayedGwx) __wxAppCode__['components/common/setting/index.wxml'] = [$gwx_XC_1, './components/common/setting/index.wxml'];else __wxAppCode__['components/common/setting/index.wxml'] = $gwx_XC_1( './components/common/setting/index.wxml' );
	;__wxRoute = "components/common/setting/index";__wxRouteBegin = true;__wxAppCurrentFile__="components/common/setting/index.js";define("components/common/setting/index.js",function(require,module,exports,window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){
"use strict";var t=getApp();Component({properties:{showSetting:{type:Boolean,value:!1,observer:function(e,s,g){this.setData({settings:t.getSettings()})}}},data:{settings:t.getSettings(),ad:t.getAd("setting")},methods:{changeSetting:function(e){var s=e.currentTarget.dataset.key;t.globalData.settings[s]=e.detail,wx.setStorageSync("settings",t.globalData.settings),this.setData({settings:t.getSettings()}),this.triggerEvent("updateSetting")},closeSetting:function(){this.triggerEvent("closeSetting")}}});
},{isPage:false,isComponent:true,currentFile:'components/common/setting/index.js'});require("components/common/setting/index.js");