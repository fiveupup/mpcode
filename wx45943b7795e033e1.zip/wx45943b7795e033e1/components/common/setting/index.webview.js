$gwx_XC_1=function(_,_v,_n,_p,_s,_wp,_wl,$gwn,$gwl,$gwh,wh,$gstack,$gwrt,gra,grb,TestTest,wfor,_ca,_da,_r,_rz,_o,_oz,_1,_1z,_2,_2z,_m,_mz,nv_getDate,nv_getRegExp,nv_console,nv_parseInt,nv_parseFloat,nv_isNaN,nv_isFinite,nv_decodeURI,nv_decodeURIComponent,nv_encodeURI,nv_encodeURIComponent,$gdc,nv_JSON,_af,_gv,_ai,_grp,_gd,_gapi,$ixc,_ic,_w,_ev,_tsd){return function(path,global){
if(typeof global==='undefined'){if (typeof __GWX_GLOBAL__==='undefined')global={};else global=__GWX_GLOBAL__;}if(typeof __WXML_GLOBAL__ === 'undefined') {__WXML_GLOBAL__={};
}__WXML_GLOBAL__.modules = __WXML_GLOBAL__.modules || {};
var e_={}
if(typeof(global.entrys)==='undefined')global.entrys={};e_=global.entrys;
var d_={}
if(typeof(global.defines)==='undefined')global.defines={};d_=global.defines;
var f_={}
if(typeof(global.modules)==='undefined')global.modules={};f_=global.modules || {};
var p_={}
__WXML_GLOBAL__.ops_cached = __WXML_GLOBAL__.ops_cached || {}
__WXML_GLOBAL__.ops_set = __WXML_GLOBAL__.ops_set || {};
__WXML_GLOBAL__.ops_init = __WXML_GLOBAL__.ops_init || {};
var z=__WXML_GLOBAL__.ops_set.$gwx_XC_1 || [];
function gz$gwx_XC_1_1(){
if( __WXML_GLOBAL__.ops_cached.$gwx_XC_1_1)return __WXML_GLOBAL__.ops_cached.$gwx_XC_1_1
__WXML_GLOBAL__.ops_cached.$gwx_XC_1_1=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
Z([3,'closeSetting'])
Z([3,'height:530rpx;background:#fff;transition:all .3s ease-out;padding-bottom:50rpx'])
Z([3,'bottom'])
Z([[7],[3,'showSetting']])
Z([3,'title text-center mt3'])
Z([3,'系统设置'])
Z([3,'wrap'])
Z([3,'item'])
Z([3,'flex-align-center flex'])
Z([3,'mr1'])
Z([3,'sjzp-a-27Hguanbixunhuan'])
Z([3,'40rpx'])
Z([3,'选项不重复抽取'])
Z([3,'changeSetting'])
Z([[6],[[7],[3,'settings']],[3,'noRepeat']])
Z([3,'noRepeat'])
Z([3,'50rpx'])
Z(z[7])
Z([3,'flex flex-align-center'])
Z(z[9])
Z([3,'music-o'])
Z([3,'36rpx'])
Z([3,'开启音效'])
Z(z[13])
Z([[6],[[7],[3,'settings']],[3,'music']])
Z([3,'music'])
Z(z[16])
Z(z[7])
Z(z[18])
Z(z[9])
Z([3,'sjzp-zhendong'])
Z(z[21])
Z([3,'开启触感'])
Z(z[13])
Z([[6],[[7],[3,'settings']],[3,'vibrate']])
Z([3,'vibrate'])
Z(z[16])
})(__WXML_GLOBAL__.ops_cached.$gwx_XC_1_1);return __WXML_GLOBAL__.ops_cached.$gwx_XC_1_1
}
__WXML_GLOBAL__.ops_set.$gwx_XC_1=z;
__WXML_GLOBAL__.ops_init.$gwx_XC_1=true;
var x=['./components/common/setting/index.wxml'];d_[x[0]]={}
var m0=function(e,s,r,gg){
var z=gz$gwx_XC_1_1()
var cF=_mz(z,'van-popup',['closeable',-1,'round',-1,'bind:close',0,'customStyle',1,'position',1,'show',2],[],e,s,gg)
var hG=_n('view')
_rz(z,hG,'class',4,e,s,gg)
var oH=_oz(z,5,e,s,gg)
_(hG,oH)
_(cF,hG)
var cI=_n('view')
_rz(z,cI,'class',6,e,s,gg)
var oJ=_n('view')
_rz(z,oJ,'class',7,e,s,gg)
var lK=_n('view')
_rz(z,lK,'class',8,e,s,gg)
var aL=_mz(z,'van-icon',['class',9,'name',1,'size',2],[],e,s,gg)
_(lK,aL)
var tM=_n('view')
var eN=_oz(z,12,e,s,gg)
_(tM,eN)
_(lK,tM)
_(oJ,lK)
var bO=_mz(z,'van-switch',['bind:change',13,'checked',1,'data-key',2,'size',3],[],e,s,gg)
_(oJ,bO)
_(cI,oJ)
var oP=_n('view')
_rz(z,oP,'class',17,e,s,gg)
var xQ=_n('view')
_rz(z,xQ,'class',18,e,s,gg)
var oR=_mz(z,'van-icon',['class',19,'name',1,'size',2],[],e,s,gg)
_(xQ,oR)
var fS=_n('view')
var cT=_oz(z,22,e,s,gg)
_(fS,cT)
_(xQ,fS)
_(oP,xQ)
var hU=_mz(z,'van-switch',['bind:change',23,'checked',1,'data-key',2,'size',3],[],e,s,gg)
_(oP,hU)
_(cI,oP)
var oV=_n('view')
_rz(z,oV,'class',27,e,s,gg)
var cW=_n('view')
_rz(z,cW,'class',28,e,s,gg)
var oX=_mz(z,'van-icon',['class',29,'name',1,'size',2],[],e,s,gg)
_(cW,oX)
var lY=_n('view')
var aZ=_oz(z,32,e,s,gg)
_(lY,aZ)
_(cW,lY)
_(oV,cW)
var t1=_mz(z,'van-switch',['bind:change',33,'checked',1,'data-key',2,'size',3],[],e,s,gg)
_(oV,t1)
_(cI,oV)
_(cF,cI)
_(r,cF)
return r
}
e_[x[0]]={f:m0,j:[],i:[],ti:[],ic:[]}
if(path&&e_[path]){
outerGlobal.__wxml_comp_version__=0.02
return function(env,dd,global){$gwxc=0;var root={"tag":"wx-page"};root.children=[]
;g="$gwx_XC_1";var main=e_[path].f
if (typeof global==="undefined")global={};global.f=$gdc(f_[path],"",1);
if(typeof(outerGlobal.__webview_engine_version__)!='undefined'&&outerGlobal.__webview_engine_version__+1e-6>=0.02+1e-6&&outerGlobal.__mergeData__)
{
env=outerGlobal.__mergeData__(env,dd);
}
try{
main(env,{},root,global);
_tsd(root)
if(typeof(outerGlobal.__webview_engine_version__)=='undefined'|| outerGlobal.__webview_engine_version__+1e-6<0.01+1e-6){return _ev(root);}
}catch(err){
console.log(err)
}
;g="";
return root;
}
}
}
}(__g.a,__g.b,__g.c,__g.d,__g.e,__g.f,__g.g,__g.h,__g.i,__g.j,__g.k,__g.l,__g.m,__g.n,__g.o,__g.p,__g.q,__g.r,__g.s,__g.t,__g.u,__g.v,__g.w,__g.x,__g.y,__g.z,__g.A,__g.B,__g.C,__g.D,__g.E,__g.F,__g.G,__g.H,__g.I,__g.J,__g.K,__g.L,__g.M,__g.N,__g.O,__g.P,__g.Q,__g.R,__g.S,__g.T,__g.U,__g.V,__g.W,__g.X,__g.Y,__g.Z,__g.aa);if(__vd_version_info__.delayedGwx||false)$gwx_XC_1();	if (__vd_version_info__.delayedGwx) __wxAppCode__['components/common/setting/index.wxml'] = [$gwx_XC_1, './components/common/setting/index.wxml'];else __wxAppCode__['components/common/setting/index.wxml'] = $gwx_XC_1( './components/common/setting/index.wxml' );
	
var noCss=typeof __vd_version_info__!=='undefined'&&__vd_version_info__.noCss===true;if(!noCss){__wxAppCode__['components/common/setting/index.wxss'] = setCssToHead([[2,"./app.wxss"],".",[1],"wrap{padding:",[0,40]," ",[0,32],"}\n.",[1],"item{-webkit-align-items:center;align-items:center;display:-webkit-flex;display:flex;-webkit-justify-content:space-between;justify-content:space-between;padding:",[0,20]," ",[0,10],"}\n.",[1],"item+.",[1],"item{border-top:1px solid #eee}\n.",[1],"ad{background:#eee;border-radius:0 0 ",[0,32]," ",[0,32],";bottom:0;overflow:hidden;position:absolute;width:100%}\n",],"Some selectors are not allowed in component wxss, including tag name selectors, ID selectors, and attribute selectors.(./components/common/setting/index.wxss:1:28)",{path:"./components/common/setting/index.wxss"});
}