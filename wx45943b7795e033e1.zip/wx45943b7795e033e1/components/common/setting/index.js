var t = getApp();

Component({
    properties: {
        showSetting: {
            type: Boolean,
            value: !1,
            observer: function(e, s, g) {
                this.setData({
                    settings: t.getSettings()
                });
            }
        }
    },
    data: {
        settings: t.getSettings(),
        ad: t.getAd("setting")
    },
    methods: {
        changeSetting: function(e) {
            var s = e.currentTarget.dataset.key;
            t.globalData.settings[s] = e.detail, wx.setStorageSync("settings", t.globalData.settings), 
            this.setData({
                settings: t.getSettings()
            }), this.triggerEvent("updateSetting");
        },
        closeSetting: function() {
            this.triggerEvent("closeSetting");
        }
    }
});