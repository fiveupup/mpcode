getApp();

Component({
    lifetimes: {
        attached: function() {}
    },
    properties: {
        position: {
            type: String
        },
        adWidth: {
            type: String
        }
    },
    data: {
        show: !0,
        ad_id: "adunit-a004f1f9f9c42946"
    },
    methods: {
        onClose: function() {
            this.setData({
                show: !1
            });
        },
        adLoad: function() {},
        adError: function(t) {
            this.setData({
                show: !1
            }), console.log("Banner 广告加载失败", t);
        },
        onAdError: function(t) {
            console.log("onAdError", t), this.setData({
                show: !1
            });
        }
    }
});