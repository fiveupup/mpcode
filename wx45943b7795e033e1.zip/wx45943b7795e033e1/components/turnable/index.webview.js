$gwx_XC_4=function(_,_v,_n,_p,_s,_wp,_wl,$gwn,$gwl,$gwh,wh,$gstack,$gwrt,gra,grb,TestTest,wfor,_ca,_da,_r,_rz,_o,_oz,_1,_1z,_2,_2z,_m,_mz,nv_getDate,nv_getRegExp,nv_console,nv_parseInt,nv_parseFloat,nv_isNaN,nv_isFinite,nv_decodeURI,nv_decodeURIComponent,nv_encodeURI,nv_encodeURIComponent,$gdc,nv_JSON,_af,_gv,_ai,_grp,_gd,_gapi,$ixc,_ic,_w,_ev,_tsd){return function(path,global){
if(typeof global==='undefined'){if (typeof __GWX_GLOBAL__==='undefined')global={};else global=__GWX_GLOBAL__;}if(typeof __WXML_GLOBAL__ === 'undefined') {__WXML_GLOBAL__={};
}__WXML_GLOBAL__.modules = __WXML_GLOBAL__.modules || {};
var e_={}
if(typeof(global.entrys)==='undefined')global.entrys={};e_=global.entrys;
var d_={}
if(typeof(global.defines)==='undefined')global.defines={};d_=global.defines;
var f_={}
if(typeof(global.modules)==='undefined')global.modules={};f_=global.modules || {};
var p_={}
__WXML_GLOBAL__.ops_cached = __WXML_GLOBAL__.ops_cached || {}
__WXML_GLOBAL__.ops_set = __WXML_GLOBAL__.ops_set || {};
__WXML_GLOBAL__.ops_init = __WXML_GLOBAL__.ops_init || {};
var z=__WXML_GLOBAL__.ops_set.$gwx_XC_4 || [];
function gz$gwx_XC_4_1(){
if( __WXML_GLOBAL__.ops_cached.$gwx_XC_4_1)return __WXML_GLOBAL__.ops_cached.$gwx_XC_4_1
__WXML_GLOBAL__.ops_cached.$gwx_XC_4_1=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
Z([3,'container'])
Z([3,'turning'])
Z([a,[[2,'?:'],[[2,'==='],[[7],[3,'state']],[1,1]],[1,'run'],[1,'']],[3,' turn']])
Z([a,[3,'transform: rotate('],[[7],[3,'rotate']],[3,'turn)']])
Z([[6],[[7],[3,'items']],[3,'length']])
Z([[7],[3,'radius']])
Z([3,'item-group'])
Z([a,[3,'width: '],[[2,'*'],[1,2],[[7],[3,'radius']]],[3,'px;height:'],[[2,'*'],[1,2],[[7],[3,'radius']]],[3,'px']])
Z([[7],[3,'items']])
Z([3,'index'])
Z([3,'item'])
Z([[12],[[6],[[7],[3,'computed']],[3,'itemStyle']],[[5],[[5],[[5],[[7],[3,'items']]],[[7],[3,'radius']]],[[7],[3,'index']]]])
Z([3,'width: 10px;font-size: 24rpx;font-weight: 500'])
Z([a,[[7],[3,'item']]])
Z([3,'start'])
Z([3,'pointer'])
Z([a,[3,'left:'],z[5],[3,'px;top:'],z[5],z[7][5]])
Z([3,' 开始 '])
})(__WXML_GLOBAL__.ops_cached.$gwx_XC_4_1);return __WXML_GLOBAL__.ops_cached.$gwx_XC_4_1
}
__WXML_GLOBAL__.ops_set.$gwx_XC_4=z;
__WXML_GLOBAL__.ops_init.$gwx_XC_4=true;
var x=['./components/turnable/index.wxml'];d_[x[0]]={}
var m0=function(e,s,r,gg){
var z=gz$gwx_XC_4_1()
var fKB=_n('view')
_rz(z,fKB,'class',0,e,s,gg)
var cLB=_n('view')
_rz(z,cLB,'class',1,e,s,gg)
var hMB=_mz(z,'view',['class',2,'style',1],[],e,s,gg)
var oNB=_mz(z,'background',['count',4,'radius',1],[],e,s,gg)
_(hMB,oNB)
var cOB=_mz(z,'view',['class',6,'style',1],[],e,s,gg)
var oPB=_v()
_(cOB,oPB)
var lQB=function(tSB,aRB,eTB,gg){
var oVB=_mz(z,'view',['class',10,'style',1],[],tSB,aRB,gg)
var xWB=_n('view')
_rz(z,xWB,'style',12,tSB,aRB,gg)
var oXB=_oz(z,13,tSB,aRB,gg)
_(xWB,oXB)
_(oVB,xWB)
_(eTB,oVB)
return eTB
}
oPB.wxXCkey=2
_2z(z,8,lQB,e,s,gg,oPB,'item','index','index')
_(hMB,cOB)
_(cLB,hMB)
var fYB=_mz(z,'view',['catch:tap',14,'class',1,'style',2],[],e,s,gg)
var cZB=_oz(z,17,e,s,gg)
_(fYB,cZB)
_(cLB,fYB)
_(fKB,cLB)
_(r,fKB)
return r
}
e_[x[0]]={f:m0,j:[],i:[],ti:[],ic:[]}
if(path&&e_[path]){
outerGlobal.__wxml_comp_version__=0.02
return function(env,dd,global){$gwxc=0;var root={"tag":"wx-page"};root.children=[]
;g="$gwx_XC_4";var main=e_[path].f
if (typeof global==="undefined")global={};global.f=$gdc(f_[path],"",1);
if(typeof(outerGlobal.__webview_engine_version__)!='undefined'&&outerGlobal.__webview_engine_version__+1e-6>=0.02+1e-6&&outerGlobal.__mergeData__)
{
env=outerGlobal.__mergeData__(env,dd);
}
try{
main(env,{},root,global);
_tsd(root)
if(typeof(outerGlobal.__webview_engine_version__)=='undefined'|| outerGlobal.__webview_engine_version__+1e-6<0.01+1e-6){return _ev(root);}
}catch(err){
console.log(err)
}
;g="";
return root;
}
}
}
}(__g.a,__g.b,__g.c,__g.d,__g.e,__g.f,__g.g,__g.h,__g.i,__g.j,__g.k,__g.l,__g.m,__g.n,__g.o,__g.p,__g.q,__g.r,__g.s,__g.t,__g.u,__g.v,__g.w,__g.x,__g.y,__g.z,__g.A,__g.B,__g.C,__g.D,__g.E,__g.F,__g.G,__g.H,__g.I,__g.J,__g.K,__g.L,__g.M,__g.N,__g.O,__g.P,__g.Q,__g.R,__g.S,__g.T,__g.U,__g.V,__g.W,__g.X,__g.Y,__g.Z,__g.aa);if(__vd_version_info__.delayedGwx||false)$gwx_XC_4();	if (__vd_version_info__.delayedGwx) __wxAppCode__['components/turnable/index.wxml'] = [$gwx_XC_4, './components/turnable/index.wxml'];else __wxAppCode__['components/turnable/index.wxml'] = $gwx_XC_4( './components/turnable/index.wxml' );
	
var noCss=typeof __vd_version_info__!=='undefined'&&__vd_version_info__.noCss===true;if(!noCss){__wxAppCode__['components/turnable/index.wxss'] = setCssToHead(["wx-view{box-sizing:border-box}\n.",[1],"container{display:-webkit-flex;display:flex;-webkit-justify-content:center;justify-content:center}\n.",[1],"turning{position:relative}\n.",[1],"pointer{-webkit-align-items:center;align-items:center;background:red;border-radius:50%;color:#fff;display:-webkit-flex;display:flex;font-size:",[0,28],";font-weight:500;height:",[0,100],";-webkit-justify-content:center;justify-content:center;top:50%;-webkit-transform:translate(-50%,-50%);transform:translate(-50%,-50%);width:",[0,100],";z-index:1}\n.",[1],"pointer,.",[1],"pointer:before{left:50%;position:absolute}\n.",[1],"pointer:before{border:solid;border-color:transparent transparent red;border-width:0 ",[0,40]," ",[0,50],";content:\x22\x22;display:block;top:",[0,-30],";-webkit-transform:translateX(-50%);transform:translateX(-50%)}\n.",[1],"run{-webkit-animation:rotate 8s linear infinite;animation:rotate 8s linear infinite}\n@-webkit-keyframes rotate{to{-webkit-transform:rotate(20turn);transform:rotate(20turn)}\n}@keyframes rotate{to{-webkit-transform:rotate(20turn);transform:rotate(20turn)}\n}.",[1],"item-group{left:0;top:0}\n.",[1],"item,.",[1],"item-group{display:-webkit-flex;display:flex;-webkit-justify-content:center;justify-content:center;position:absolute}\n.",[1],"item{-webkit-align-items:flex-start;align-items:flex-start;box-sizing:border-box;padding-top:",[0,30],";-webkit-transform-origin:bottom center;transform-origin:bottom center}\n",],"Some selectors are not allowed in component wxss, including tag name selectors, ID selectors, and attribute selectors.(./components/turnable/index.wxss:1:1)",{path:"./components/turnable/index.wxss"});
}