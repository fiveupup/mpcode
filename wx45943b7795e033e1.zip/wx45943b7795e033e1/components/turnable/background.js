Component({
    properties: {
        radius: {
            type: Number,
            observer: function(e) {}
        },
        count: {
            type: Number
        },
        colors: {
            type: Array,
            value: [ "#00b9f1", "#C5E99B", "#D499B9" ]
        }
    },
    data: {},
    methods: {}
});