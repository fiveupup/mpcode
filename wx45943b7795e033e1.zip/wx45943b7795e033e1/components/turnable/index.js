Component({
    properties: {
        state: {
            type: Number
        },
        items: {
            type: Array
        },
        colors: {
            type: Array,
            value: [ "black", "white" ]
        }
    },
    data: {
        radius: 155,
        rotate: 0
    },
    methods: {
        start: function() {
            var t = this;
            1 != this.data.state && (this.triggerEvent("start"), setTimeout(function() {
                var e = t.data.items, a = Math.floor(200 * Math.random()) % e.length;
                t.triggerEvent("stop", e[a]), t.setData({
                    rotate: -1 / e.length * a
                });
            }, 1800));
        }
    }
});