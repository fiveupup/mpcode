$gwx_XC_26=function(_,_v,_n,_p,_s,_wp,_wl,$gwn,$gwl,$gwh,wh,$gstack,$gwrt,gra,grb,TestTest,wfor,_ca,_da,_r,_rz,_o,_oz,_1,_1z,_2,_2z,_m,_mz,nv_getDate,nv_getRegExp,nv_console,nv_parseInt,nv_parseFloat,nv_isNaN,nv_isFinite,nv_decodeURI,nv_decodeURIComponent,nv_encodeURI,nv_encodeURIComponent,$gdc,nv_JSON,_af,_gv,_ai,_grp,_gd,_gapi,$ixc,_ic,_w,_ev,_tsd){return function(path,global){
if(typeof global==='undefined'){if (typeof __GWX_GLOBAL__==='undefined')global={};else global=__GWX_GLOBAL__;}if(typeof __WXML_GLOBAL__ === 'undefined') {__WXML_GLOBAL__={};
}__WXML_GLOBAL__.modules = __WXML_GLOBAL__.modules || {};
var e_={}
if(typeof(global.entrys)==='undefined')global.entrys={};e_=global.entrys;
var d_={}
if(typeof(global.defines)==='undefined')global.defines={};d_=global.defines;
var f_={}
if(typeof(global.modules)==='undefined')global.modules={};f_=global.modules || {};
var p_={}
__WXML_GLOBAL__.ops_cached = __WXML_GLOBAL__.ops_cached || {}
__WXML_GLOBAL__.ops_set = __WXML_GLOBAL__.ops_set || {};
__WXML_GLOBAL__.ops_init = __WXML_GLOBAL__.ops_init || {};
var z=__WXML_GLOBAL__.ops_set.$gwx_XC_26 || [];
function gz$gwx_XC_26_1(){
if( __WXML_GLOBAL__.ops_cached.$gwx_XC_26_1)return __WXML_GLOBAL__.ops_cached.$gwx_XC_26_1
__WXML_GLOBAL__.ops_cached.$gwx_XC_26_1=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
Z([3,'width:750rpx;box-sizing:border-box;overflow:hidden;background:#f6f7f8;transition:all .3s ease-out;padding-bottom:50rpx'])
Z([3,'bottom'])
Z([[7],[3,'showEdit']])
Z([3,'items'])
Z([[7],[3,'items_obj']])
Z([3,'index'])
Z([3,'delItem'])
Z([3,'#FF725C'])
Z([[7],[3,'index']])
Z([3,'cross'])
Z([3,'38rpx'])
Z([3,'margin-left:20rpx'])
Z([3,'addNewItem'])
Z([3,'item'])
Z([3,'color: #1c90ff;'])
Z([3,'#1c90ff'])
Z([3,'add'])
Z([3,'42rpx'])
Z([1,false])
Z([3,'addMany'])
Z(z[13])
Z(z[14])
Z(z[15])
Z([3,'wap-nav'])
Z(z[17])
Z([[7],[3,'showLoading']])
Z([3,'width:750rpx;box-sizing:border-box;overflow:hidden;background:#f6f7f8;transition:all .3s ease-out;'])
Z(z[1])
Z([1,true])
Z([3,'loading'])
Z([[2,'==='],[[6],[[7],[3,'loadingInfo']],[3,'status']],[1,0]])
Z(z[15])
Z([3,'100'])
Z([3,'spinner'])
Z([[2,'==='],[[6],[[7],[3,'loadingInfo']],[3,'status']],[1,1]])
Z([[2,'==='],[[6],[[7],[3,'loadingInfo']],[3,'status']],[[2,'-'],[1,1]]])
Z(z[34])
Z([3,'hideLoading'])
Z([3,'padding:18rpx 100rpx;margin-top:38rpx'])
Z([3,'info'])
Z(z[35])
Z([3,'margin-top:38rpx;text-align:center'])
Z([3,'padding:18rpx 30rpx;margin-right:30rpx'])
Z([3,'contact'])
Z(z[39])
Z([3,'saveItems'])
Z([3,'padding:18rpx 50rpx;'])
Z(z[39])
Z([3,'savezp'])
})(__WXML_GLOBAL__.ops_cached.$gwx_XC_26_1);return __WXML_GLOBAL__.ops_cached.$gwx_XC_26_1
}
__WXML_GLOBAL__.ops_set.$gwx_XC_26=z;
__WXML_GLOBAL__.ops_init.$gwx_XC_26=true;
var x=['./components/zhuanpan/edit/edit.wxml'];d_[x[0]]={}
var m0=function(e,s,r,gg){
var z=gz$gwx_XC_26_1()
var aNF=_mz(z,'van-popup',['round',-1,'customStyle',0,'position',1,'show',1],[],e,s,gg)
var tOF=_n('view')
_rz(z,tOF,'class',3,e,s,gg)
var bQF=_v()
_(tOF,bQF)
var oRF=function(oTF,xSF,fUF,gg){
var hWF=_mz(z,'van-icon',['catch:tap',6,'color',1,'data-index',2,'name',3,'size',4,'style',5],[],oTF,xSF,gg)
_(fUF,hWF)
return fUF
}
bQF.wxXCkey=4
_2z(z,4,oRF,e,s,gg,bQF,'item','index','index')
var oXF=_mz(z,'view',['catch:tap',12,'class',1,'style',2],[],e,s,gg)
var cYF=_mz(z,'van-icon',['color',15,'name',1,'size',2],[],e,s,gg)
_(oXF,cYF)
_(tOF,oXF)
var ePF=_v()
_(tOF,ePF)
if(_oz(z,18,e,s,gg)){ePF.wxVkey=1
var oZF=_mz(z,'view',['catch:tap',19,'class',1,'style',2],[],e,s,gg)
var l1F=_mz(z,'van-icon',['color',22,'name',1,'size',2],[],e,s,gg)
_(oZF,l1F)
_(ePF,oZF)
}
ePF.wxXCkey=1
ePF.wxXCkey=3
_(aNF,tOF)
_(r,aNF)
var lMF=_v()
_(r,lMF)
if(_oz(z,25,e,s,gg)){lMF.wxVkey=1
var a2F=_mz(z,'van-popup',['round',-1,'customStyle',26,'position',1,'show',2],[],e,s,gg)
var t3F=_n('view')
_rz(z,t3F,'class',29,e,s,gg)
var e4F=_v()
_(t3F,e4F)
if(_oz(z,30,e,s,gg)){e4F.wxVkey=1
var f9F=_mz(z,'van-loading',['color',31,'size',1,'type',2],[],e,s,gg)
_(e4F,f9F)
}
var b5F=_v()
_(t3F,b5F)
if(_oz(z,34,e,s,gg)){b5F.wxVkey=1
}
var o6F=_v()
_(t3F,o6F)
if(_oz(z,35,e,s,gg)){o6F.wxVkey=1
}
var x7F=_v()
_(t3F,x7F)
if(_oz(z,36,e,s,gg)){x7F.wxVkey=1
var c0F=_mz(z,'van-button',['round',-1,'bind:tap',37,'customStyle',1,'type',2],[],e,s,gg)
_(x7F,c0F)
}
var o8F=_v()
_(t3F,o8F)
if(_oz(z,40,e,s,gg)){o8F.wxVkey=1
var hAG=_n('view')
_rz(z,hAG,'style',41,e,s,gg)
var oBG=_mz(z,'van-button',['round',-1,'customStyle',42,'openType',1,'type',2],[],e,s,gg)
_(hAG,oBG)
var cCG=_mz(z,'van-button',['round',-1,'bind:tap',45,'customStyle',1,'type',2],[],e,s,gg)
_(hAG,cCG)
_(o8F,hAG)
}
e4F.wxXCkey=1
e4F.wxXCkey=3
b5F.wxXCkey=1
o6F.wxXCkey=1
x7F.wxXCkey=1
x7F.wxXCkey=3
o8F.wxXCkey=1
o8F.wxXCkey=3
_(a2F,t3F)
var oDG=_n('ads')
_rz(z,oDG,'position',48,e,s,gg)
_(a2F,oDG)
_(lMF,a2F)
}
lMF.wxXCkey=1
lMF.wxXCkey=3
return r
}
e_[x[0]]={f:m0,j:[],i:[],ti:[],ic:[]}
if(path&&e_[path]){
return function(env,dd,global){$gwxc=0;var root={"tag":"wx-page"};root.children=[]
;g="$gwx_XC_26";var main=e_[path].f
if (typeof global==="undefined")global={};global.f=$gdc(f_[path],"",1);
try{
main(env,{},root,global);
_tsd(root)
}catch(err){
console.log(err)
}
;g="";
return root;
}
}
}
}(__g.a,__g.b,__g.c,__g.d,__g.e,__g.f,__g.g,__g.h,__g.i,__g.j,__g.k,__g.l,__g.m,__g.n,__g.o,__g.p,__g.q,__g.r,__g.s,__g.t,__g.u,__g.v,__g.w,__g.x,__g.y,__g.z,__g.A,__g.B,__g.C,__g.D,__g.E,__g.F,__g.G,__g.H,__g.I,__g.J,__g.K,__g.L,__g.M,__g.N,__g.O,__g.P,__g.Q,__g.R,__g.S,__g.T,__g.U,__g.V,__g.W,__g.X,__g.Y,__g.Z,__g.aa);if(__vd_version_info__.delayedGwx||false)$gwx_XC_26();	if (__vd_version_info__.delayedGwx) __wxAppCode__['components/zhuanpan/edit/edit.wxml'] = [$gwx_XC_26, './components/zhuanpan/edit/edit.wxml'];else __wxAppCode__['components/zhuanpan/edit/edit.wxml'] = $gwx_XC_26( './components/zhuanpan/edit/edit.wxml' );
	;__wxRoute = "components/zhuanpan/edit/edit";__wxRouteBegin = true;__wxAppCurrentFile__="components/zhuanpan/edit/edit.js";define("components/zhuanpan/edit/edit.js",function(require,module,exports,window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){
"use strict";var t=require("../../../@babel/runtime/helpers/interopRequireDefault")(require("../../../@babel/runtime/regenerator")),e=require("../../../@babel/runtime/helpers/asyncToGenerator"),i=require("../../../@babel/runtime/helpers/defineProperty"),a=require("../../../8A51F322415216BFEC379B250C07EA57.js"),n=require("../../../D3DADA56415216BFB5BCB25179D6EA57.js");Component({behaviors:[wx.Bus],properties:{showEdit:{type:Boolean}},data:{title:"",items_obj:[],showLoading:!1,loadingInfo:{status:0,text:"加载中..."}},methods:{close:function(){var t=this,e=this.$bus.store.get("zpInfo"),i=this.data.items_obj.map((function(t){return t.text})).join(""),a=e.items_obj.map((function(t){return t.text})).join("");this.data.title!==e.title||i!==a?wx.showModal({title:"提示",content:"您的更改尚未保存，是否放弃编辑转盘？",success:function(e){e.confirm&&t.setData({showEdit:!1})}}):this.setData({showEdit:!1})},itemChange:function(t){var e=t.currentTarget.dataset.index,a=t.detail.value;this.setData(i({},"items_obj[".concat(e,"].text"),a))},changeTitle:function(t){var e=t.detail.value;this.setData({title:e})},delItem:function(t){if(this.data.items_obj.length<3)wx.showToast({title:"至少保留两个选项哦~",icon:"none"});else{var e=t.currentTarget.dataset.index;this.data.items_obj.splice(e,1),wx.vibrateShort(),this.setData({focus:!1,items_obj:this.data.items_obj})}},addNewItem:function(t){var e,a=this,s=this.data.items_obj,o={id:Math.random().toString(36).substr(2,4)+s.length,text:"",color:n[s.length%n.length],weight:1};this.setData((i(e={},"items_obj[".concat(s.length,"]"),o),i(e,"focus",!0),e));var r=this.createSelectorQuery();r.select("#innerView").boundingClientRect((function(t){a.setData({scrollTop:t.height+20})})),wx.nextTick((function(){r.exec()}))},saveItems:function(n){var s=this;return e(t.default.mark((function e(){var n,o,r,u,c,d;return t.default.wrap((function(t){for(;;)switch(t.prev=t.next){case 0:return s.setData((i(n={showLoading:!0},"loadingInfo.status",0),i(n,"loadingInfo.text","保存中.."),n)),o=s.data.items_obj.map((function(t){return t.text})).join("")+s.data.title,t.next=4,a.checkMsg(o);case 4:return t.sent||s.setData(i({},"loadingInfo.text","转盘中存在敏感词汇，正在逐个检查..")),t.prev=6,t.next=9,a.updateOne({id:s.$bus.store.get("zpInfo").id,title:s.data.title,items_obj:s.data.items_obj});case 9:0===(r=t.sent).code?(s.setData((i(u={},"loadingInfo.status",1),i(u,"loadingInfo.text","保存成功"),u)),s.$bus.event.emit("edit:saveSuccess",{zpInfo:r.data}),getApp().globalData._updateZpList=!0):s.setData((i(c={},"loadingInfo.status",-1),i(c,"loadingInfo.text",JSON.stringify(r)),c)),t.next=17;break;case 13:throw t.prev=13,t.t0=t.catch(6),s.setData((i(d={},"loadingInfo.status",-1),i(d,"loadingInfo.text",JSON.stringify(t.t0)),d)),t.t0;case 17:case"end":return t.stop()}}),e,null,[[6,13]])})))()},hideLoading:function(){this.setData({showLoading:!1,showEdit:!1})}},lifetimes:{attached:function(){var t=this;this.$bus.event.export("edit:showEdit",(function(e){var i=e.zpInfo;console.log(i),t.setData({items_obj:JSON.parse(JSON.stringify(i.items_obj)),title:i.title,showEdit:!0})})),this.$bus.event.on("edit:hideEdit",(function(){t.setData({showEdit:!1})}))}}});
},{isPage:false,isComponent:true,currentFile:'components/zhuanpan/edit/edit.js'});require("components/zhuanpan/edit/edit.js");