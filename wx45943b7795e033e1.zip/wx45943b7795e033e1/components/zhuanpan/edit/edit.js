var t = require("../../../@babel/runtime/helpers/interopRequireDefault")(require("../../../@babel/runtime/regenerator")), e = require("../../../@babel/runtime/helpers/asyncToGenerator"), i = require("../../../@babel/runtime/helpers/defineProperty"), a = require("../../../8A51F322415216BFEC379B250C07EA57.js"), n = require("../../../D3DADA56415216BFB5BCB25179D6EA57.js");

Component({
    behaviors: [ wx.Bus ],
    properties: {
        showEdit: {
            type: Boolean
        }
    },
    data: {
        title: "",
        items_obj: [],
        showLoading: !1,
        loadingInfo: {
            status: 0,
            text: "加载中..."
        }
    },
    methods: {
        close: function() {
            var t = this, e = this.$bus.store.get("zpInfo"), i = this.data.items_obj.map(function(t) {
                return t.text;
            }).join(""), a = e.items_obj.map(function(t) {
                return t.text;
            }).join("");
            this.data.title !== e.title || i !== a ? wx.showModal({
                title: "提示",
                content: "您的更改尚未保存，是否放弃编辑转盘？",
                success: function(e) {
                    e.confirm && t.setData({
                        showEdit: !1
                    });
                }
            }) : this.setData({
                showEdit: !1
            });
        },
        itemChange: function(t) {
            var e = t.currentTarget.dataset.index, a = t.detail.value;
            this.setData(i({}, "items_obj[".concat(e, "].text"), a));
        },
        changeTitle: function(t) {
            var e = t.detail.value;
            this.setData({
                title: e
            });
        },
        delItem: function(t) {
            if (this.data.items_obj.length < 3) wx.showToast({
                title: "至少保留两个选项哦~",
                icon: "none"
            }); else {
                var e = t.currentTarget.dataset.index;
                this.data.items_obj.splice(e, 1), wx.vibrateShort(), this.setData({
                    focus: !1,
                    items_obj: this.data.items_obj
                });
            }
        },
        addNewItem: function(t) {
            var e, a = this, s = this.data.items_obj, o = {
                id: Math.random().toString(36).substr(2, 4) + s.length,
                text: "",
                color: n[s.length % n.length],
                weight: 1
            };
            this.setData((i(e = {}, "items_obj[".concat(s.length, "]"), o), i(e, "focus", !0), 
            e));
            var r = this.createSelectorQuery();
            r.select("#innerView").boundingClientRect(function(t) {
                a.setData({
                    scrollTop: t.height + 20
                });
            }), wx.nextTick(function() {
                r.exec();
            });
        },
        saveItems: function(n) {
            var s = this;
            return e(t.default.mark(function e() {
                var n, o, r, u, c, d;
                return t.default.wrap(function(t) {
                    for (;;) switch (t.prev = t.next) {
                      case 0:
                        return s.setData((i(n = {
                            showLoading: !0
                        }, "loadingInfo.status", 0), i(n, "loadingInfo.text", "保存中.."), n)), o = s.data.items_obj.map(function(t) {
                            return t.text;
                        }).join("") + s.data.title, t.next = 4, a.checkMsg(o);

                      case 4:
                        return t.sent || s.setData(i({}, "loadingInfo.text", "转盘中存在敏感词汇，正在逐个检查..")), t.prev = 6, 
                        t.next = 9, a.updateOne({
                            id: s.$bus.store.get("zpInfo").id,
                            title: s.data.title,
                            items_obj: s.data.items_obj
                        });

                      case 9:
                        0 === (r = t.sent).code ? (s.setData((i(u = {}, "loadingInfo.status", 1), i(u, "loadingInfo.text", "保存成功"), 
                        u)), s.$bus.event.emit("edit:saveSuccess", {
                            zpInfo: r.data
                        }), getApp().globalData._updateZpList = !0) : s.setData((i(c = {}, "loadingInfo.status", -1), 
                        i(c, "loadingInfo.text", JSON.stringify(r)), c)), t.next = 17;
                        break;

                      case 13:
                        throw t.prev = 13, t.t0 = t.catch(6), s.setData((i(d = {}, "loadingInfo.status", -1), 
                        i(d, "loadingInfo.text", JSON.stringify(t.t0)), d)), t.t0;

                      case 17:
                      case "end":
                        return t.stop();
                    }
                }, e, null, [ [ 6, 13 ] ]);
            }))();
        },
        hideLoading: function() {
            this.setData({
                showLoading: !1,
                showEdit: !1
            });
        }
    },
    lifetimes: {
        attached: function() {
            var t = this;
            this.$bus.event.export("edit:showEdit", function(e) {
                var i = e.zpInfo;
                console.log(i), t.setData({
                    items_obj: JSON.parse(JSON.stringify(i.items_obj)),
                    title: i.title,
                    showEdit: !0
                });
            }), this.$bus.event.on("edit:hideEdit", function() {
                t.setData({
                    showEdit: !1
                });
            });
        }
    }
});