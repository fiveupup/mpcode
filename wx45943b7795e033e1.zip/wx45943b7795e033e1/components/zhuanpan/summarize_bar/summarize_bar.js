Component({
    behaviors: [ wx.Bus ],
    properties: {},
    data: {
        show: !1,
        all: 0,
        used: 0
    },
    methods: {
        toReset: function() {
            this.$bus.event.call("black:clearBlack");
        },
        toDetail: function() {
            var e = JSON.parse(JSON.stringify(this.$bus.get("zpInfo").items_obj)), t = "zp_".concat(this.$bus.get("zpInfo").id);
            wx.navigateTo({
                url: "/pages/zhuanpan/summarize_page/summarize_page",
                success: function(s) {
                    s.eventChannel.emit("getData", {
                        zpItems: e,
                        cacheKey: t
                    });
                }
            });
        }
    },
    lifetimes: {
        attached: function() {
            var e = this;
            this.$bus.event.export("summarize_bar:updateCount", function(t) {
                var s = e.$bus.store.get("zpInfo");
                console.log("summarize_bar:updateCount", t, s), e.setData({
                    used: t,
                    all: s.items_obj.length
                });
            }), this.$bus.event.on("page:zpInfoLoaded", function() {
                var t = e.$bus.store.get("zpInfo");
                e.$bus.store.get("shouldSaveResult") || e.setData({
                    show: t.settings && t.settings.no_repeat
                });
            }), this.$bus.event.export("summarize_bar:updateShow", function() {
                var t = e.$bus.store.get("zpInfo");
                e.$bus.store.get("shouldSaveResult") || e.setData({
                    show: t.settings && t.settings.no_repeat
                });
            });
        }
    }
});