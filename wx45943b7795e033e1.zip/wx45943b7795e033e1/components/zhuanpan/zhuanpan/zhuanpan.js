var e = require("../../../@babel/runtime/helpers/createForOfIteratorHelper"), t = require("../../../@babel/runtime/helpers/objectSpread2"), s = require("../../../9CF0F3B1415216BFFA969BB66868EA57.js");

Component({
    data: {
        all_weight: 0,
        showItems: []
    },
    properties: {
        radius: {
            type: Number,
            value: 158
        }
    },
    behaviors: [ require("../../../85D10F46415216BFE3B767417A58EA57.js"), require("../../../37C5DC90415216BF51A3B4975378EA57.js"), wx.Bus, s ],
    methods: {
        initItems: function() {
            var s = {}, i = this.$bus.get("zpInfo").items_obj;
            i = i.map(function(e, i) {
                var a = t({}, e);
                return a.index = i, s[e.id] = a, a;
            });
            var a = JSON.parse(JSON.stringify(i)), r = 0;
            a.forEach(function(e) {
                r += e.weight;
            });
            for (var n = 0, h = [], g = 0; g < a.length; g++) {
                var o = a[g];
                o.deg = o.weight / r * 360, 0 === n && (n = o.deg / 2), o.endDeg = n, o.startDeg = n - o.deg, 
                o.status = 0, n = o.startDeg;
                for (var u = 0; u < o.weight; u++) h.push(g);
            }
            var d, l = JSON.parse(JSON.stringify(i)), m = 0, f = e(l);
            try {
                for (f.s(); !(d = f.n()).done; ) {
                    var p = d.value;
                    p.deg = p.weight / r * 360, 0 === m && (m = -p.deg / 2), p.startDeg = m, p.status = 0, 
                    p.deg = p.weight / r * 360, p.endDeg = m + p.deg, m = p.endDeg;
                }
            } catch (e) {
                f.e(e);
            } finally {
                f.f();
            }
            this.$bus.set("showItems", a), this.$bus.set("realItems", l), this.$bus.set("allWeightItems", h), 
            this.$bus.set("item_map", s), this.setData({
                showItems: a,
                all_weight: r
            });
        },
        initZpItems2: function() {
            var e = this.$bus.get("zpInfo");
            if (e.settings && e.settings.hide_weight) {
                var s = {}, i = e.items_obj;
                i = i.map(function(e, i) {
                    var a = t({}, e);
                    return a.index = i, s[e.id] = a, a;
                });
                var a = JSON.parse(JSON.stringify(i)), r = 0;
                a.forEach(function(e) {
                    r += e.weight;
                });
                for (var n = 0, h = [], g = 0; g < a.length; g++) {
                    var o = a[g];
                    o.deg = 360 / a.length, 0 === n && (n = o.deg / 2), o.endDeg = n, o.startDeg = n - o.deg, 
                    o.status = 0, n = o.startDeg;
                    for (var u = 0; u < o.weight; u++) h.push(g);
                }
                for (var d = JSON.parse(JSON.stringify(i)), l = 0, m = 0; m < d.length; m++) {
                    var f = d[m];
                    f.deg = 360 / a.length, 0 === l && (l = -f.deg / 2), f.startDeg = l, f.status = 0, 
                    f.endDeg = l + f.deg, l = f.endDeg;
                }
                console.log("realItems", d), console.log("showItems", a), this.$bus.set("showItems", a), 
                this.$bus.set("realItems", d), this.$bus.set("allWeightItems", h), this.$bus.set("item_map", s), 
                this.setData({
                    showItems: a,
                    all_weight: r
                });
            } else this.initItems();
        },
        initZpRadius: function() {
            var e = wx.getSystemInfoSync(), t = e.windowWidth, s = e.windowHeight, i = Math.floor(.93 * Math.min(t, s) / 2);
            i = Math.min(i, s / 3), this.setData({
                radius: i
            });
        }
    },
    lifetimes: {
        attached: function() {
            this.$bus.on("page:zpInfoLoaded", this.initZpItems2.bind(this)), this.initZpRadius();
        }
    }
});