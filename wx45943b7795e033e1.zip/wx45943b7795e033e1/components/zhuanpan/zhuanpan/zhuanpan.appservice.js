$gwx_XC_31=function(_,_v,_n,_p,_s,_wp,_wl,$gwn,$gwl,$gwh,wh,$gstack,$gwrt,gra,grb,TestTest,wfor,_ca,_da,_r,_rz,_o,_oz,_1,_1z,_2,_2z,_m,_mz,nv_getDate,nv_getRegExp,nv_console,nv_parseInt,nv_parseFloat,nv_isNaN,nv_isFinite,nv_decodeURI,nv_decodeURIComponent,nv_encodeURI,nv_encodeURIComponent,$gdc,nv_JSON,_af,_gv,_ai,_grp,_gd,_gapi,$ixc,_ic,_w,_ev,_tsd){return function(path,global){
if(typeof global==='undefined'){if (typeof __GWX_GLOBAL__==='undefined')global={};else global=__GWX_GLOBAL__;}if(typeof __WXML_GLOBAL__ === 'undefined') {__WXML_GLOBAL__={};
}__WXML_GLOBAL__.modules = __WXML_GLOBAL__.modules || {};
var e_={}
if(typeof(global.entrys)==='undefined')global.entrys={};e_=global.entrys;
var d_={}
if(typeof(global.defines)==='undefined')global.defines={};d_=global.defines;
var f_={}
if(typeof(global.modules)==='undefined')global.modules={};f_=global.modules || {};
var p_={}
__WXML_GLOBAL__.ops_cached = __WXML_GLOBAL__.ops_cached || {}
__WXML_GLOBAL__.ops_set = __WXML_GLOBAL__.ops_set || {};
__WXML_GLOBAL__.ops_init = __WXML_GLOBAL__.ops_init || {};
var z=__WXML_GLOBAL__.ops_set.$gwx_XC_31 || [];
function gz$gwx_XC_31_1(){
if( __WXML_GLOBAL__.ops_cached.$gwx_XC_31_1)return __WXML_GLOBAL__.ops_cached.$gwx_XC_31_1
__WXML_GLOBAL__.ops_cached.$gwx_XC_31_1=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
Z([3,'onZpStopped'])
Z([3,'zhuanpan'])
Z([[7],[3,'style']])
Z([[7],[3,'all_weight']])
Z([[7],[3,'showItems']])
Z([[7],[3,'radius']])
Z([[7],[3,'showMask']])
})(__WXML_GLOBAL__.ops_cached.$gwx_XC_31_1);return __WXML_GLOBAL__.ops_cached.$gwx_XC_31_1
}
__WXML_GLOBAL__.ops_set.$gwx_XC_31=z;
__WXML_GLOBAL__.ops_init.$gwx_XC_31=true;
var x=['./components/zhuanpan/zhuanpan/zhuanpan.wxml'];d_[x[0]]={}
var m0=function(e,s,r,gg){
var z=gz$gwx_XC_31_1()
var bAH=_mz(z,'view',['bind:transitionend',0,'id',1,'style',1],[],e,s,gg)
var oBH=_mz(z,'turnable',['all_weight',3,'items',1,'radius',2,'showMask',3],[],e,s,gg)
_(bAH,oBH)
_(r,bAH)
return r
}
e_[x[0]]={f:m0,j:[],i:[],ti:[],ic:[]}
if(path&&e_[path]){
return function(env,dd,global){$gwxc=0;var root={"tag":"wx-page"};root.children=[]
;g="$gwx_XC_31";var main=e_[path].f
if (typeof global==="undefined")global={};global.f=$gdc(f_[path],"",1);
try{
main(env,{},root,global);
_tsd(root)
}catch(err){
console.log(err)
}
;g="";
return root;
}
}
}
}(__g.a,__g.b,__g.c,__g.d,__g.e,__g.f,__g.g,__g.h,__g.i,__g.j,__g.k,__g.l,__g.m,__g.n,__g.o,__g.p,__g.q,__g.r,__g.s,__g.t,__g.u,__g.v,__g.w,__g.x,__g.y,__g.z,__g.A,__g.B,__g.C,__g.D,__g.E,__g.F,__g.G,__g.H,__g.I,__g.J,__g.K,__g.L,__g.M,__g.N,__g.O,__g.P,__g.Q,__g.R,__g.S,__g.T,__g.U,__g.V,__g.W,__g.X,__g.Y,__g.Z,__g.aa);if(__vd_version_info__.delayedGwx||false)$gwx_XC_31();	if (__vd_version_info__.delayedGwx) __wxAppCode__['components/zhuanpan/zhuanpan/zhuanpan.wxml'] = [$gwx_XC_31, './components/zhuanpan/zhuanpan/zhuanpan.wxml'];else __wxAppCode__['components/zhuanpan/zhuanpan/zhuanpan.wxml'] = $gwx_XC_31( './components/zhuanpan/zhuanpan/zhuanpan.wxml' );
	;__wxRoute = "components/zhuanpan/zhuanpan/zhuanpan";__wxRouteBegin = true;__wxAppCurrentFile__="components/zhuanpan/zhuanpan/zhuanpan.js";define("components/zhuanpan/zhuanpan/zhuanpan.js",function(require,module,exports,window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){
"use strict";var e=require("../../../@babel/runtime/helpers/createForOfIteratorHelper"),t=require("../../../@babel/runtime/helpers/objectSpread2"),s=require("../../../9CF0F3B1415216BFFA969BB66868EA57.js");Component({data:{all_weight:0,showItems:[]},properties:{radius:{type:Number,value:158}},behaviors:[require("../../../85D10F46415216BFE3B767417A58EA57.js"),require("../../../37C5DC90415216BF51A3B4975378EA57.js"),wx.Bus,s],methods:{initItems:function(){var s={},i=this.$bus.get("zpInfo").items_obj;i=i.map((function(e,i){var a=t({},e);return a.index=i,s[e.id]=a,a}));var a=JSON.parse(JSON.stringify(i)),r=0;a.forEach((function(e){r+=e.weight}));for(var n=0,h=[],g=0;g<a.length;g++){var o=a[g];o.deg=o.weight/r*360,0===n&&(n=o.deg/2),o.endDeg=n,o.startDeg=n-o.deg,o.status=0,n=o.startDeg;for(var u=0;u<o.weight;u++)h.push(g)}var d,l=JSON.parse(JSON.stringify(i)),m=0,f=e(l);try{for(f.s();!(d=f.n()).done;){var p=d.value;p.deg=p.weight/r*360,0===m&&(m=-p.deg/2),p.startDeg=m,p.status=0,p.deg=p.weight/r*360,p.endDeg=m+p.deg,m=p.endDeg}}catch(e){f.e(e)}finally{f.f()}this.$bus.set("showItems",a),this.$bus.set("realItems",l),this.$bus.set("allWeightItems",h),this.$bus.set("item_map",s),this.setData({showItems:a,all_weight:r})},initZpItems2:function(){var e=this.$bus.get("zpInfo");if(e.settings&&e.settings.hide_weight){var s={},i=e.items_obj;i=i.map((function(e,i){var a=t({},e);return a.index=i,s[e.id]=a,a}));var a=JSON.parse(JSON.stringify(i)),r=0;a.forEach((function(e){r+=e.weight}));for(var n=0,h=[],g=0;g<a.length;g++){var o=a[g];o.deg=360/a.length,0===n&&(n=o.deg/2),o.endDeg=n,o.startDeg=n-o.deg,o.status=0,n=o.startDeg;for(var u=0;u<o.weight;u++)h.push(g)}for(var d=JSON.parse(JSON.stringify(i)),l=0,m=0;m<d.length;m++){var f=d[m];f.deg=360/a.length,0===l&&(l=-f.deg/2),f.startDeg=l,f.status=0,f.endDeg=l+f.deg,l=f.endDeg}console.log("realItems",d),console.log("showItems",a),this.$bus.set("showItems",a),this.$bus.set("realItems",d),this.$bus.set("allWeightItems",h),this.$bus.set("item_map",s),this.setData({showItems:a,all_weight:r})}else this.initItems()},initZpRadius:function(){var e=wx.getSystemInfoSync(),t=e.windowWidth,s=e.windowHeight,i=Math.floor(.93*Math.min(t,s)/2);i=Math.min(i,s/3),this.setData({radius:i})}},lifetimes:{attached:function(){this.$bus.on("page:zpInfoLoaded",this.initZpItems2.bind(this)),this.initZpRadius()}}});
},{isPage:false,isComponent:true,currentFile:'components/zhuanpan/zhuanpan/zhuanpan.js'});require("components/zhuanpan/zhuanpan/zhuanpan.js");