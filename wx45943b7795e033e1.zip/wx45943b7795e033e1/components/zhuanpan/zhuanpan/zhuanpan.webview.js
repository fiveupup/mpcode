$gwx_XC_31=function(_,_v,_n,_p,_s,_wp,_wl,$gwn,$gwl,$gwh,wh,$gstack,$gwrt,gra,grb,TestTest,wfor,_ca,_da,_r,_rz,_o,_oz,_1,_1z,_2,_2z,_m,_mz,nv_getDate,nv_getRegExp,nv_console,nv_parseInt,nv_parseFloat,nv_isNaN,nv_isFinite,nv_decodeURI,nv_decodeURIComponent,nv_encodeURI,nv_encodeURIComponent,$gdc,nv_JSON,_af,_gv,_ai,_grp,_gd,_gapi,$ixc,_ic,_w,_ev,_tsd){return function(path,global){
if(typeof global==='undefined'){if (typeof __GWX_GLOBAL__==='undefined')global={};else global=__GWX_GLOBAL__;}if(typeof __WXML_GLOBAL__ === 'undefined') {__WXML_GLOBAL__={};
}__WXML_GLOBAL__.modules = __WXML_GLOBAL__.modules || {};
var e_={}
if(typeof(global.entrys)==='undefined')global.entrys={};e_=global.entrys;
var d_={}
if(typeof(global.defines)==='undefined')global.defines={};d_=global.defines;
var f_={}
if(typeof(global.modules)==='undefined')global.modules={};f_=global.modules || {};
var p_={}
__WXML_GLOBAL__.ops_cached = __WXML_GLOBAL__.ops_cached || {}
__WXML_GLOBAL__.ops_set = __WXML_GLOBAL__.ops_set || {};
__WXML_GLOBAL__.ops_init = __WXML_GLOBAL__.ops_init || {};
var z=__WXML_GLOBAL__.ops_set.$gwx_XC_31 || [];
function gz$gwx_XC_31_1(){
if( __WXML_GLOBAL__.ops_cached.$gwx_XC_31_1)return __WXML_GLOBAL__.ops_cached.$gwx_XC_31_1
__WXML_GLOBAL__.ops_cached.$gwx_XC_31_1=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
Z([a,[3,'width:'],[[2,'+'],[[2,'*'],[1,2],[[7],[3,'radius']]],[1,26]],[3,'px;height:'],[[2,'+'],[[2,'*'],[1,2],[[7],[3,'radius']]],[1,26]],[3,'px;overflow:hidden;padding:10px;margin:auto']])
Z([3,'zp-container'])
Z([a,z[0][1],[[2,'*'],[1,2],[[7],[3,'radius']]],z[0][3],[[2,'*'],[1,2],[[7],[3,'radius']]],[3,'px']])
Z([3,'onZpStopped'])
Z([3,'zhuanpan'])
Z([[7],[3,'style']])
Z([[7],[3,'all_weight']])
Z([[7],[3,'showItems']])
Z([[7],[3,'radius']])
Z([[7],[3,'showMask']])
Z([3,'longtap'])
Z([3,'start'])
Z([3,'pointer'])
Z([a,[3,'left:'],z[8],[3,'px;top:'],z[8],[3,'px;']])
Z([3,'flex flex-center text'])
Z(z[11])
Z([3,'Go'])
})(__WXML_GLOBAL__.ops_cached.$gwx_XC_31_1);return __WXML_GLOBAL__.ops_cached.$gwx_XC_31_1
}
__WXML_GLOBAL__.ops_set.$gwx_XC_31=z;
__WXML_GLOBAL__.ops_init.$gwx_XC_31=true;
var x=['./components/zhuanpan/zhuanpan/zhuanpan.wxml'];d_[x[0]]={}
var m0=function(e,s,r,gg){
var z=gz$gwx_XC_31_1()
var oXM=_n('view')
_rz(z,oXM,'style',0,e,s,gg)
var cYM=_mz(z,'view',['class',1,'style',1],[],e,s,gg)
var oZM=_mz(z,'view',['bind:transitionend',3,'id',1,'style',2],[],e,s,gg)
var l1M=_mz(z,'turnable',['all_weight',6,'items',1,'radius',2,'showMask',3],[],e,s,gg)
_(oZM,l1M)
_(cYM,oZM)
var a2M=_mz(z,'view',['catch:longpress',10,'catch:tap',1,'class',2,'style',3],[],e,s,gg)
var t3M=_n('view')
_rz(z,t3M,'class',14,e,s,gg)
var e4M=_n('view')
_rz(z,e4M,'class',15,e,s,gg)
var b5M=_oz(z,16,e,s,gg)
_(e4M,b5M)
_(t3M,e4M)
_(a2M,t3M)
_(cYM,a2M)
_(oXM,cYM)
_(r,oXM)
return r
}
e_[x[0]]={f:m0,j:[],i:[],ti:[],ic:[]}
if(path&&e_[path]){
outerGlobal.__wxml_comp_version__=0.02
return function(env,dd,global){$gwxc=0;var root={"tag":"wx-page"};root.children=[]
;g="$gwx_XC_31";var main=e_[path].f
if (typeof global==="undefined")global={};global.f=$gdc(f_[path],"",1);
if(typeof(outerGlobal.__webview_engine_version__)!='undefined'&&outerGlobal.__webview_engine_version__+1e-6>=0.02+1e-6&&outerGlobal.__mergeData__)
{
env=outerGlobal.__mergeData__(env,dd);
}
try{
main(env,{},root,global);
_tsd(root)
if(typeof(outerGlobal.__webview_engine_version__)=='undefined'|| outerGlobal.__webview_engine_version__+1e-6<0.01+1e-6){return _ev(root);}
}catch(err){
console.log(err)
}
;g="";
return root;
}
}
}
}(__g.a,__g.b,__g.c,__g.d,__g.e,__g.f,__g.g,__g.h,__g.i,__g.j,__g.k,__g.l,__g.m,__g.n,__g.o,__g.p,__g.q,__g.r,__g.s,__g.t,__g.u,__g.v,__g.w,__g.x,__g.y,__g.z,__g.A,__g.B,__g.C,__g.D,__g.E,__g.F,__g.G,__g.H,__g.I,__g.J,__g.K,__g.L,__g.M,__g.N,__g.O,__g.P,__g.Q,__g.R,__g.S,__g.T,__g.U,__g.V,__g.W,__g.X,__g.Y,__g.Z,__g.aa);if(__vd_version_info__.delayedGwx||false)$gwx_XC_31();	if (__vd_version_info__.delayedGwx) __wxAppCode__['components/zhuanpan/zhuanpan/zhuanpan.wxml'] = [$gwx_XC_31, './components/zhuanpan/zhuanpan/zhuanpan.wxml'];else __wxAppCode__['components/zhuanpan/zhuanpan/zhuanpan.wxml'] = $gwx_XC_31( './components/zhuanpan/zhuanpan/zhuanpan.wxml' );
	
var noCss=typeof __vd_version_info__!=='undefined'&&__vd_version_info__.noCss===true;if(!noCss){__wxAppCode__['components/zhuanpan/zhuanpan/zhuanpan.wxss'] = setCssToHead([[2,"./app.wxss"],".",[1],"zp-container{box-sizing:border-box;margin:auto;position:relative}\n.",[1],"pointer{-webkit-align-items:center;align-items:center;background:#f9f9f9;border-radius:50%;color:#fff;display:-webkit-flex;display:flex;font-size:14px;font-weight:500;height:60px;-webkit-justify-content:center;justify-content:center;top:50%;-webkit-transform:translate(-50%,-50%);transform:translate(-50%,-50%);width:60px;z-index:1}\n.",[1],"pointer,.",[1],"pointer:before{left:50%;position:absolute}\n.",[1],"pointer:before{border:solid;border-color:transparent transparent #f9f9f9;border-width:0 10px 15px;content:\x22\x22;display:block;top:-10px;-webkit-transform:translateX(-50%);transform:translateX(-50%)}\n.",[1],"pointer \x3e .",[1],"text{border-radius:50%;color:#1c90ff;font-size:",[0,28],";font-weight:bolder;height:75%;left:50%;position:absolute;top:50%;-webkit-transform:translate(-50%,-50%);transform:translate(-50%,-50%);width:75%;z-index:1}\n.",[1],"start{-webkit-align-items:center;align-items:center;background:#f2f2f2;border-radius:20px;display:-webkit-flex;display:flex;font-size:21px;height:45px;-webkit-justify-content:center;justify-content:center;width:45px}\n@media (prefers-color-scheme:dark){.",[1],"pointer{background:#333}\n.",[1],"pointer:before{border-color:transparent transparent #333}\n.",[1],"start{background:#333}\n}",],"Some selectors are not allowed in component wxss, including tag name selectors, ID selectors, and attribute selectors.(./components/zhuanpan/zhuanpan/zhuanpan.wxss:1:28)",{path:"./components/zhuanpan/zhuanpan/zhuanpan.wxss"});
}