$gwx_XC_28=function(_,_v,_n,_p,_s,_wp,_wl,$gwn,$gwl,$gwh,wh,$gstack,$gwrt,gra,grb,TestTest,wfor,_ca,_da,_r,_rz,_o,_oz,_1,_1z,_2,_2z,_m,_mz,nv_getDate,nv_getRegExp,nv_console,nv_parseInt,nv_parseFloat,nv_isNaN,nv_isFinite,nv_decodeURI,nv_decodeURIComponent,nv_encodeURI,nv_encodeURIComponent,$gdc,nv_JSON,_af,_gv,_ai,_grp,_gd,_gapi,$ixc,_ic,_w,_ev,_tsd){return function(path,global){
if(typeof global==='undefined'){if (typeof __GWX_GLOBAL__==='undefined')global={};else global=__GWX_GLOBAL__;}if(typeof __WXML_GLOBAL__ === 'undefined') {__WXML_GLOBAL__={};
}__WXML_GLOBAL__.modules = __WXML_GLOBAL__.modules || {};
var e_={}
if(typeof(global.entrys)==='undefined')global.entrys={};e_=global.entrys;
var d_={}
if(typeof(global.defines)==='undefined')global.defines={};d_=global.defines;
var f_={}
if(typeof(global.modules)==='undefined')global.modules={};f_=global.modules || {};
var p_={}
__WXML_GLOBAL__.ops_cached = __WXML_GLOBAL__.ops_cached || {}
__WXML_GLOBAL__.ops_set = __WXML_GLOBAL__.ops_set || {};
__WXML_GLOBAL__.ops_init = __WXML_GLOBAL__.ops_init || {};
var z=__WXML_GLOBAL__.ops_set.$gwx_XC_28 || [];
function gz$gwx_XC_28_1(){
if( __WXML_GLOBAL__.ops_cached.$gwx_XC_28_1)return __WXML_GLOBAL__.ops_cached.$gwx_XC_28_1
__WXML_GLOBAL__.ops_cached.$gwx_XC_28_1=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
Z([3,''])
Z([3,'result ^flex-center'])
Z([[2,'&&'],[[7],[3,'showShare']],[[7],[3,'result']]])
Z([3,'btn share-btn'])
Z([3,'result'])
Z([3,'shareResult'])
Z([3,'share'])
Z(z[6])
Z([3,'color:#1c90ff'])
})(__WXML_GLOBAL__.ops_cached.$gwx_XC_28_1);return __WXML_GLOBAL__.ops_cached.$gwx_XC_28_1
}
__WXML_GLOBAL__.ops_set.$gwx_XC_28=z;
__WXML_GLOBAL__.ops_init.$gwx_XC_28=true;
var x=['./components/zhuanpan/result/result.wxml'];d_[x[0]]={}
var m0=function(e,s,r,gg){
var z=gz$gwx_XC_28_1()
var c2G=_mz(z,'view',['bind:longpress',0,'class',1],[],e,s,gg)
var h3G=_v()
_(c2G,h3G)
if(_oz(z,2,e,s,gg)){h3G.wxVkey=1
var o4G=_mz(z,'van-button',['customClass',3,'dataset',1,'id',2,'openType',3],[],e,s,gg)
var c5G=_mz(z,'van-icon',['name',7,'style',1],[],e,s,gg)
_(o4G,c5G)
_(h3G,o4G)
}
h3G.wxXCkey=1
h3G.wxXCkey=3
_(r,c2G)
return r
}
e_[x[0]]={f:m0,j:[],i:[],ti:[],ic:[]}
if(path&&e_[path]){
return function(env,dd,global){$gwxc=0;var root={"tag":"wx-page"};root.children=[]
;g="$gwx_XC_28";var main=e_[path].f
if (typeof global==="undefined")global={};global.f=$gdc(f_[path],"",1);
try{
main(env,{},root,global);
_tsd(root)
}catch(err){
console.log(err)
}
;g="";
return root;
}
}
}
}(__g.a,__g.b,__g.c,__g.d,__g.e,__g.f,__g.g,__g.h,__g.i,__g.j,__g.k,__g.l,__g.m,__g.n,__g.o,__g.p,__g.q,__g.r,__g.s,__g.t,__g.u,__g.v,__g.w,__g.x,__g.y,__g.z,__g.A,__g.B,__g.C,__g.D,__g.E,__g.F,__g.G,__g.H,__g.I,__g.J,__g.K,__g.L,__g.M,__g.N,__g.O,__g.P,__g.Q,__g.R,__g.S,__g.T,__g.U,__g.V,__g.W,__g.X,__g.Y,__g.Z,__g.aa);if(__vd_version_info__.delayedGwx||false)$gwx_XC_28();	if (__vd_version_info__.delayedGwx) __wxAppCode__['components/zhuanpan/result/result.wxml'] = [$gwx_XC_28, './components/zhuanpan/result/result.wxml'];else __wxAppCode__['components/zhuanpan/result/result.wxml'] = $gwx_XC_28( './components/zhuanpan/result/result.wxml' );
	;__wxRoute = "components/zhuanpan/result/result";__wxRouteBegin = true;__wxAppCurrentFile__="components/zhuanpan/result/result.js";define("components/zhuanpan/result/result.js",function(require,module,exports,window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){
"use strict";var e=require("../../../@babel/runtime/helpers/interopRequireDefault")(require("../../../@babel/runtime/regenerator")),t=require("../../../@babel/runtime/helpers/asyncToGenerator"),s=require("../../../3BF47E73415216BF5D9216745509EA57.js").sensitiveHash,a=require("../../../8A51F322415216BFEC379B250C07EA57.js"),r=getApp();Component({behaviors:[wx.Bus],properties:{},data:{result:"??",showShare:!1},methods:{onTapResult:function(){var e=this;this.data.result&&this.data.showShare&&wx.showActionSheet({itemList:["复制结果"],success:function(t){0===t.tapIndex&&e.toCopy()}})},toCopy:function(){this.data.result&&this.data.showShare&&wx.setClipboardData({data:this.data.result,success:function(){wx.showToast({title:"转盘结果复制成功",icon:"none"})}})},uploadResult:function(r){var n=this;return t(e.default.mark((function t(){var o,i,u,c,h,l;return e.default.wrap((function(e){for(;;)switch(e.prev=e.next){case 0:return console.log("uploadResult",r),o=n.$bus.get("zpInfo"),i=o.id,u=r.text,c=r.weight,h=r.id,l=s(i+h+c+u),e.next=7,a.createZpRecord({zp_id:i,item_id:h,item_text:u,weight:c,key:l});case 7:e.sent;case 8:case"end":return e.stop()}}),t)})))()}},lifetimes:{attached:function(){var s=this;this.$bus.on("zhuanpan:step",(function(e){e&&e.text!==s.data.result&&(s.$bus.get("settings").vibrate&&wx.vibrateShort(),s.setData({result:e.text,showShare:!1}))})),this.$bus.on("zhuanpan:stop",(function(a){a&&(s.$bus.store.get("shouldSaveResult")&&s.$bus.store.get("recordsTimes")<=s.$bus.store.get("zpInfo").share_settings.p_times&&s.uploadResult(a).then(t(e.default.mark((function t(){return e.default.wrap((function(e){for(;;)switch(e.prev=e.next){case 0:return s.$bus.event.call("page:updateRecordsTimes"),e.next=3,r.getUser();case 3:e.sent.wx_name||wx.showModal({title:"未设置昵称",content:"检测到您尚未设置昵称，设置昵称后，您的转盘结果将会显示在转盘记录中",confirmText:"去设置",cancelText:"暂不设置",success:function(e){e.confirm&&wx.navigateTo({url:"/p3/user-info/user-info"})}});case 5:case"end":return e.stop()}}),t)})))),s.$bus.get("settings").vibrate&&wx.vibrateLong(),s.setData({result:a.text,showShare:!0}))})),this.$bus.on("page:zpInfoLoaded",(function(){s.setData({result:"??",showShare:!1})})),this.$bus.on("page:recoveryZp",(function(){s.setData({result:"??",showShare:!1})}))}}});
},{isPage:false,isComponent:true,currentFile:'components/zhuanpan/result/result.js'});require("components/zhuanpan/result/result.js");