var e = require("../../../@babel/runtime/helpers/interopRequireDefault")(require("../../../@babel/runtime/regenerator")), t = require("../../../@babel/runtime/helpers/asyncToGenerator"), s = require("../../../3BF47E73415216BF5D9216745509EA57.js").sensitiveHash, a = require("../../../8A51F322415216BFEC379B250C07EA57.js"), r = getApp();

Component({
    behaviors: [ wx.Bus ],
    properties: {},
    data: {
        result: "??",
        showShare: !1
    },
    methods: {
        onTapResult: function() {
            var e = this;
            this.data.result && this.data.showShare && wx.showActionSheet({
                itemList: [ "复制结果" ],
                success: function(t) {
                    0 === t.tapIndex && e.toCopy();
                }
            });
        },
        toCopy: function() {
            this.data.result && this.data.showShare && wx.setClipboardData({
                data: this.data.result,
                success: function() {
                    wx.showToast({
                        title: "转盘结果复制成功",
                        icon: "none"
                    });
                }
            });
        },
        uploadResult: function(r) {
            var n = this;
            return t(e.default.mark(function t() {
                var o, i, u, c, h, l;
                return e.default.wrap(function(e) {
                    for (;;) switch (e.prev = e.next) {
                      case 0:
                        return console.log("uploadResult", r), o = n.$bus.get("zpInfo"), i = o.id, u = r.text, 
                        c = r.weight, h = r.id, l = s(i + h + c + u), e.next = 7, a.createZpRecord({
                            zp_id: i,
                            item_id: h,
                            item_text: u,
                            weight: c,
                            key: l
                        });

                      case 7:
                        e.sent;

                      case 8:
                      case "end":
                        return e.stop();
                    }
                }, t);
            }))();
        }
    },
    lifetimes: {
        attached: function() {
            var s = this;
            this.$bus.on("zhuanpan:step", function(e) {
                e && e.text !== s.data.result && (s.$bus.get("settings").vibrate && wx.vibrateShort(), 
                s.setData({
                    result: e.text,
                    showShare: !1
                }));
            }), this.$bus.on("zhuanpan:stop", function(a) {
                a && (s.$bus.store.get("shouldSaveResult") && s.$bus.store.get("recordsTimes") <= s.$bus.store.get("zpInfo").share_settings.p_times && s.uploadResult(a).then(t(e.default.mark(function t() {
                    return e.default.wrap(function(e) {
                        for (;;) switch (e.prev = e.next) {
                          case 0:
                            return s.$bus.event.call("page:updateRecordsTimes"), e.next = 3, r.getUser();

                          case 3:
                            e.sent.wx_name || wx.showModal({
                                title: "未设置昵称",
                                content: "检测到您尚未设置昵称，设置昵称后，您的转盘结果将会显示在转盘记录中",
                                confirmText: "去设置",
                                cancelText: "暂不设置",
                                success: function(e) {
                                    e.confirm && wx.navigateTo({
                                        url: "/p3/user-info/user-info"
                                    });
                                }
                            });

                          case 5:
                          case "end":
                            return e.stop();
                        }
                    }, t);
                }))), s.$bus.get("settings").vibrate && wx.vibrateLong(), s.setData({
                    result: a.text,
                    showShare: !0
                }));
            }), this.$bus.on("page:zpInfoLoaded", function() {
                s.setData({
                    result: "??",
                    showShare: !1
                });
            }), this.$bus.on("page:recoveryZp", function() {
                s.setData({
                    result: "??",
                    showShare: !1
                });
            });
        }
    }
});