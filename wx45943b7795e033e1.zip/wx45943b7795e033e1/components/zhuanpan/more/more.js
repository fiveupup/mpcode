var e = require("../../../@babel/runtime/helpers/interopRequireDefault")(require("../../../@babel/runtime/regenerator")), t = require("../../../@babel/runtime/helpers/defineProperty"), s = require("../../../@babel/runtime/helpers/asyncToGenerator"), a = require("../../../72CE30E5415216BF14A858E26129EA57.js").getTTS, r = getApp();

Component({
    behaviors: [ wx.Bus ],
    properties: {},
    data: {
        showMore: !1,
        settings: {
            vibrate: !0,
            sound: !0,
            speaker: "1"
        },
        speakers: [ {
            text: "不需要播报转盘结果",
            value: "none"
        }, {
            text: "情感女声-智瑜",
            value: "1001"
        }, {
            text: "知性女声-智娜",
            value: "1007"
        }, {
            text: "通用女声-智莉",
            value: "1005"
        }, {
            text: "通用男声-智华",
            value: "1"
        }, {
            text: "情感男声-智靖",
            value: "1018"
        }, {
            text: "情感男声-智云",
            value: "1004"
        } ]
    },
    methods: {
        showMore: function() {
            this.setData({
                showMore: !0
            });
        },
        hideMore: function() {
            this.setData({
                showMore: !1
            });
        },
        showShare: function() {
            this.$bus.event.call("share:showShare");
        },
        shareMyZp: function() {
            var e = this.$bus.get("zpInfo");
            e.id.startsWith("template_") || e.openid !== r.globalData.openid ? wx.showToast({
                title: "请先保存当前转盘，才可以分享哦！",
                icon: "none"
            }) : (this.setData({
                showMore: !1
            }), this.$bus.event.emit("share-settings:show"));
        },
        settingsChange: function(r) {
            var n = this;
            return s(e.default.mark(function s() {
                var i, o, u;
                return e.default.wrap(function(e) {
                    for (;;) switch (e.prev = e.next) {
                      case 0:
                        if (i = r.currentTarget.dataset.type, o = r.detail, n.setData(t({}, "settings.".concat(i), o)), 
                        "speaker" !== i) {
                            e.next = 10;
                            break;
                        }
                        if ("none" !== o) {
                            e.next = 6;
                            break;
                        }
                        return e.abrupt("return");

                      case 6:
                        return e.next = 8, a("欢迎使用全能小转盘", o);

                      case 8:
                        0 === (u = e.sent).code && (n.audioCtx.src = u.data, n.audioCtx.play());

                      case 10:
                        n.updateSettings();

                      case 11:
                      case "end":
                        return e.stop();
                    }
                }, s);
            }))();
        },
        updateSettings: function() {
            this.$bus.store.set("settings", this.data.settings), wx.setStorageSync("settings", this.data.settings);
        },
        showDyh: function() {
            wx.navigateTo({
                url: "/pages/webview/webview?url=".concat(encodeURIComponent("https://mp.weixin.qq.com/s/crtWaRZGrSh_DUOT9T48Dw"))
            });
        }
    },
    lifetimes: {
        attached: function() {
            var e = this, t = wx.getStorageSync("settings") || this.data.settings;
            this.$bus.store.set("settings", t), this.$bus.event.export("more:showMore", function() {
                e.showMore(), e.setData({
                    settings: t
                });
            }), this.$bus.event.export("more:hiddenMore", function() {
                e.hideMore();
            }), this.audioCtx = wx.createInnerAudioContext();
        },
        detached: function() {
            this.audioCtx && this.audioCtx.destroy();
        }
    }
});