$gwx_XC_27=function(_,_v,_n,_p,_s,_wp,_wl,$gwn,$gwl,$gwh,wh,$gstack,$gwrt,gra,grb,TestTest,wfor,_ca,_da,_r,_rz,_o,_oz,_1,_1z,_2,_2z,_m,_mz,nv_getDate,nv_getRegExp,nv_console,nv_parseInt,nv_parseFloat,nv_isNaN,nv_isFinite,nv_decodeURI,nv_decodeURIComponent,nv_encodeURI,nv_encodeURIComponent,$gdc,nv_JSON,_af,_gv,_ai,_grp,_gd,_gapi,$ixc,_ic,_w,_ev,_tsd){return function(path,global){
if(typeof global==='undefined'){if (typeof __GWX_GLOBAL__==='undefined')global={};else global=__GWX_GLOBAL__;}if(typeof __WXML_GLOBAL__ === 'undefined') {__WXML_GLOBAL__={};
}__WXML_GLOBAL__.modules = __WXML_GLOBAL__.modules || {};
var e_={}
if(typeof(global.entrys)==='undefined')global.entrys={};e_=global.entrys;
var d_={}
if(typeof(global.defines)==='undefined')global.defines={};d_=global.defines;
var f_={}
if(typeof(global.modules)==='undefined')global.modules={};f_=global.modules || {};
var p_={}
__WXML_GLOBAL__.ops_cached = __WXML_GLOBAL__.ops_cached || {}
__WXML_GLOBAL__.ops_set = __WXML_GLOBAL__.ops_set || {};
__WXML_GLOBAL__.ops_init = __WXML_GLOBAL__.ops_init || {};
var z=__WXML_GLOBAL__.ops_set.$gwx_XC_27 || [];
function gz$gwx_XC_27_1(){
if( __WXML_GLOBAL__.ops_cached.$gwx_XC_27_1)return __WXML_GLOBAL__.ops_cached.$gwx_XC_27_1
__WXML_GLOBAL__.ops_cached.$gwx_XC_27_1=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
Z([3,'hideMore'])
Z([1,true])
Z([3,'setting-popup'])
Z([3,'bottom'])
Z([[7],[3,'showMore']])
Z(z[0])
Z([3,'^setting-item ^view-btn'])
Z([3,'btn_share_more'])
Z([3,'share'])
Z([3,'^mr1'])
Z([3,'#1c90ff'])
Z([3,'share-o'])
Z([3,'38rpx'])
Z([3,' 分享 '])
Z([3,'arrow'])
Z([3,'^setting-item'])
Z(z[9])
Z(z[10])
Z([3,'bullhorn-o'])
Z(z[12])
Z([3,' 声音 '])
Z([3,'settingsChange'])
Z([[6],[[7],[3,'settings']],[3,'sound']])
Z([3,'sound'])
Z([3,'24'])
Z(z[15])
Z([3,'^iconfont ^sjzp-zhendong ^mr1'])
Z([3,'font-size:38rpx;color:#1c90ff;'])
Z([3,' 震动效果 '])
Z(z[21])
Z([[6],[[7],[3,'settings']],[3,'vibrate']])
Z([3,'vibrate'])
Z(z[24])
Z(z[15])
Z(z[9])
Z(z[10])
Z(z[18])
Z(z[12])
Z([3,' 播报声音 '])
Z([3,'dropdown'])
Z([3,'up'])
Z(z[21])
Z([3,'speaker'])
Z([[7],[3,'speakers']])
Z([[2,'||'],[[6],[[7],[3,'settings']],[3,'speaker']],[1,'1']])
Z([1,false])
Z(z[15])
Z(z[9])
Z(z[10])
Z([3,'records'])
Z(z[12])
Z([3,' 历史记录 '])
Z(z[14])
Z(z[45])
Z(z[15])
Z([3,'^iconfont ^qinglihuancun ^mr1'])
Z([3,'font-size:38rpx;color:#1c90ff'])
Z([3,' 清除缓存 '])
Z(z[14])
Z(z[45])
Z([3,'height:140rpx;padding:0;width:686rpx;border-radius:32rpx;background:var(--bg-color);border-radius:32rpx;margin-top:16rpx'])
Z([3,'contact'])
Z(z[15])
Z([3,'width:686rpx'])
Z([3,'display:flex;flex-direction:column;align-items:start'])
Z(z[9])
Z(z[10])
Z(z[61])
Z(z[12])
Z([3,' 联系开发者 '])
Z([3,'desc'])
Z([3,' 提建议，反馈bug，寻求帮助 '])
Z([3,'showDyh'])
Z([3,'^text-center ^mt3 ^mb1'])
Z([3,'font-size:.8em;color:#1c90ff'])
Z([3,'关注公众号'])
})(__WXML_GLOBAL__.ops_cached.$gwx_XC_27_1);return __WXML_GLOBAL__.ops_cached.$gwx_XC_27_1
}
__WXML_GLOBAL__.ops_set.$gwx_XC_27=z;
__WXML_GLOBAL__.ops_init.$gwx_XC_27=true;
var x=['./components/zhuanpan/more/more.wxml'];d_[x[0]]={}
var m0=function(e,s,r,gg){
var z=gz$gwx_XC_27_1()
var lOK=_mz(z,'van-popup',['bind:close',0,'closeable',1,'customClass',1,'position',2,'show',3],[],e,s,gg)
var bSK=_n('view')
var oTK=_mz(z,'button',['bindtap',5,'class',1,'data-detail',2,'openType',3],[],e,s,gg)
var xUK=_n('view')
var oVK=_n('view')
var fWK=_mz(z,'van-icon',['class',9,'color',1,'name',2,'size',3],[],e,s,gg)
_(oVK,fWK)
var cXK=_oz(z,13,e,s,gg)
_(oVK,cXK)
_(xUK,oVK)
_(oTK,xUK)
var hYK=_n('view')
var oZK=_n('van-icon')
_rz(z,oZK,'name',14,e,s,gg)
_(hYK,oZK)
_(oTK,hYK)
_(bSK,oTK)
_(lOK,bSK)
var c1K=_n('view')
_rz(z,c1K,'class',15,e,s,gg)
var o2K=_n('view')
var l3K=_mz(z,'van-icon',['class',16,'color',1,'name',2,'size',3],[],e,s,gg)
_(o2K,l3K)
var a4K=_oz(z,20,e,s,gg)
_(o2K,a4K)
_(c1K,o2K)
var t5K=_n('view')
var e6K=_mz(z,'van-switch',['bind:change',21,'checked',1,'data-type',2,'size',3],[],e,s,gg)
_(t5K,e6K)
_(c1K,t5K)
_(lOK,c1K)
var b7K=_n('view')
_rz(z,b7K,'class',25,e,s,gg)
var o8K=_n('view')
var x9K=_mz(z,'text',['class',26,'style',1],[],e,s,gg)
_(o8K,x9K)
var o0K=_oz(z,28,e,s,gg)
_(o8K,o0K)
_(b7K,o8K)
var fAL=_n('view')
var cBL=_mz(z,'van-switch',['bind:change',29,'checked',1,'data-type',2,'size',3],[],e,s,gg)
_(fAL,cBL)
_(b7K,fAL)
_(lOK,b7K)
var hCL=_n('view')
_rz(z,hCL,'class',33,e,s,gg)
var oDL=_n('view')
var cEL=_mz(z,'van-icon',['class',34,'color',1,'name',2,'size',3],[],e,s,gg)
_(oDL,cEL)
var oFL=_oz(z,38,e,s,gg)
_(oDL,oFL)
_(hCL,oDL)
var lGL=_n('view')
var aHL=_mz(z,'van-dropdown-menu',['customClass',39,'direction',1],[],e,s,gg)
var tIL=_mz(z,'van-dropdown-item',['bindchange',41,'data-type',1,'options',2,'value',3],[],e,s,gg)
_(aHL,tIL)
_(lGL,aHL)
_(hCL,lGL)
_(lOK,hCL)
var aPK=_v()
_(lOK,aPK)
if(_oz(z,45,e,s,gg)){aPK.wxVkey=1
var eJL=_n('view')
_rz(z,eJL,'class',46,e,s,gg)
var bKL=_n('view')
var oLL=_mz(z,'van-icon',['class',47,'color',1,'name',2,'size',3],[],e,s,gg)
_(bKL,oLL)
var xML=_oz(z,51,e,s,gg)
_(bKL,xML)
_(eJL,bKL)
var oNL=_n('view')
var fOL=_n('van-icon')
_rz(z,fOL,'name',52,e,s,gg)
_(oNL,fOL)
_(eJL,oNL)
_(aPK,eJL)
}
var tQK=_v()
_(lOK,tQK)
if(_oz(z,53,e,s,gg)){tQK.wxVkey=1
var cPL=_n('view')
_rz(z,cPL,'class',54,e,s,gg)
var hQL=_n('view')
var oRL=_mz(z,'text',['class',55,'style',1],[],e,s,gg)
_(hQL,oRL)
var cSL=_oz(z,57,e,s,gg)
_(hQL,cSL)
_(cPL,hQL)
var oTL=_n('view')
var lUL=_n('van-icon')
_rz(z,lUL,'name',58,e,s,gg)
_(oTL,lUL)
_(cPL,oTL)
_(tQK,cPL)
}
var eRK=_v()
_(lOK,eRK)
if(_oz(z,59,e,s,gg)){eRK.wxVkey=1
var aVL=_mz(z,'van-button',['plain',-1,'customStyle',60,'openType',1],[],e,s,gg)
var tWL=_mz(z,'view',['class',62,'style',1],[],e,s,gg)
var eXL=_n('view')
_rz(z,eXL,'style',64,e,s,gg)
var bYL=_n('view')
var oZL=_mz(z,'van-icon',['class',65,'color',1,'name',2,'size',3],[],e,s,gg)
_(bYL,oZL)
var x1L=_oz(z,69,e,s,gg)
_(bYL,x1L)
_(eXL,bYL)
var o2L=_n('view')
_rz(z,o2L,'class',70,e,s,gg)
var f3L=_oz(z,71,e,s,gg)
_(o2L,f3L)
_(eXL,o2L)
_(tWL,eXL)
_(aVL,tWL)
_(eRK,aVL)
}
var c4L=_mz(z,'view',['catch:tap',72,'class',1,'style',2],[],e,s,gg)
var h5L=_oz(z,75,e,s,gg)
_(c4L,h5L)
_(lOK,c4L)
aPK.wxXCkey=1
aPK.wxXCkey=3
tQK.wxXCkey=1
tQK.wxXCkey=3
eRK.wxXCkey=1
eRK.wxXCkey=3
_(r,lOK)
return r
}
e_[x[0]]={f:m0,j:[],i:[],ti:[],ic:[]}
if(path&&e_[path]){
outerGlobal.__wxml_comp_version__=0.02
return function(env,dd,global){$gwxc=0;var root={"tag":"wx-page"};root.children=[]
;g="$gwx_XC_27";var main=e_[path].f
if (typeof global==="undefined")global={};global.f=$gdc(f_[path],"",1);
if(typeof(outerGlobal.__webview_engine_version__)!='undefined'&&outerGlobal.__webview_engine_version__+1e-6>=0.02+1e-6&&outerGlobal.__mergeData__)
{
env=outerGlobal.__mergeData__(env,dd);
}
try{
main(env,{},root,global);
_tsd(root)
if(typeof(outerGlobal.__webview_engine_version__)=='undefined'|| outerGlobal.__webview_engine_version__+1e-6<0.01+1e-6){return _ev(root);}
}catch(err){
console.log(err)
}
;g="";
return root;
}
}
}
}(__g.a,__g.b,__g.c,__g.d,__g.e,__g.f,__g.g,__g.h,__g.i,__g.j,__g.k,__g.l,__g.m,__g.n,__g.o,__g.p,__g.q,__g.r,__g.s,__g.t,__g.u,__g.v,__g.w,__g.x,__g.y,__g.z,__g.A,__g.B,__g.C,__g.D,__g.E,__g.F,__g.G,__g.H,__g.I,__g.J,__g.K,__g.L,__g.M,__g.N,__g.O,__g.P,__g.Q,__g.R,__g.S,__g.T,__g.U,__g.V,__g.W,__g.X,__g.Y,__g.Z,__g.aa);if(__vd_version_info__.delayedGwx||false)$gwx_XC_27();	if (__vd_version_info__.delayedGwx) __wxAppCode__['components/zhuanpan/more/more.wxml'] = [$gwx_XC_27, './components/zhuanpan/more/more.wxml'];else __wxAppCode__['components/zhuanpan/more/more.wxml'] = $gwx_XC_27( './components/zhuanpan/more/more.wxml' );
	
var noCss=typeof __vd_version_info__!=='undefined'&&__vd_version_info__.noCss===true;if(!noCss){__wxAppCode__['components/zhuanpan/more/more.wxss'] = setCssToHead([".",[1],"desc{color:var(--desc-text-color);font-size:",[0,28],";line-height:1.5;margin-top:",[0,10],"}\n.",[1],"setting-popup{padding:",[0,80]," ",[0,30]," ",[0,100],"}\n@media (prefers-color-scheme:dark){.",[1],"setting-popup{background-color:#333!important}\n}.",[1],"dropdown{background:transparent;padding:",[0,32],"}\n",],undefined,{path:"./components/zhuanpan/more/more.wxss"});
}