$gwx_XC_27=function(_,_v,_n,_p,_s,_wp,_wl,$gwn,$gwl,$gwh,wh,$gstack,$gwrt,gra,grb,TestTest,wfor,_ca,_da,_r,_rz,_o,_oz,_1,_1z,_2,_2z,_m,_mz,nv_getDate,nv_getRegExp,nv_console,nv_parseInt,nv_parseFloat,nv_isNaN,nv_isFinite,nv_decodeURI,nv_decodeURIComponent,nv_encodeURI,nv_encodeURIComponent,$gdc,nv_JSON,_af,_gv,_ai,_grp,_gd,_gapi,$ixc,_ic,_w,_ev,_tsd){return function(path,global){
if(typeof global==='undefined'){if (typeof __GWX_GLOBAL__==='undefined')global={};else global=__GWX_GLOBAL__;}if(typeof __WXML_GLOBAL__ === 'undefined') {__WXML_GLOBAL__={};
}__WXML_GLOBAL__.modules = __WXML_GLOBAL__.modules || {};
var e_={}
if(typeof(global.entrys)==='undefined')global.entrys={};e_=global.entrys;
var d_={}
if(typeof(global.defines)==='undefined')global.defines={};d_=global.defines;
var f_={}
if(typeof(global.modules)==='undefined')global.modules={};f_=global.modules || {};
var p_={}
__WXML_GLOBAL__.ops_cached = __WXML_GLOBAL__.ops_cached || {}
__WXML_GLOBAL__.ops_set = __WXML_GLOBAL__.ops_set || {};
__WXML_GLOBAL__.ops_init = __WXML_GLOBAL__.ops_init || {};
var z=__WXML_GLOBAL__.ops_set.$gwx_XC_27 || [];
function gz$gwx_XC_27_1(){
if( __WXML_GLOBAL__.ops_cached.$gwx_XC_27_1)return __WXML_GLOBAL__.ops_cached.$gwx_XC_27_1
__WXML_GLOBAL__.ops_cached.$gwx_XC_27_1=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
Z([3,'hideMore'])
Z([1,true])
Z([3,'setting-popup'])
Z([3,'bottom'])
Z([[7],[3,'showMore']])
Z(z[0])
Z([3,'^setting-item ^view-btn'])
Z([3,'btn_share_more'])
Z([3,'share'])
Z([3,'^mr1'])
Z([3,'#1c90ff'])
Z([3,'share-o'])
Z([3,'38rpx'])
Z([3,'arrow'])
Z([3,'^setting-item'])
Z(z[9])
Z(z[10])
Z([3,'bullhorn-o'])
Z(z[12])
Z([3,'settingsChange'])
Z([[6],[[7],[3,'settings']],[3,'sound']])
Z([3,'sound'])
Z([3,'24'])
Z(z[19])
Z([[6],[[7],[3,'settings']],[3,'vibrate']])
Z([3,'vibrate'])
Z(z[22])
Z(z[14])
Z(z[9])
Z(z[10])
Z(z[17])
Z(z[12])
Z([3,'dropdown'])
Z([3,'up'])
Z(z[19])
Z([3,'speaker'])
Z([[7],[3,'speakers']])
Z([[2,'||'],[[6],[[7],[3,'settings']],[3,'speaker']],[1,'1']])
Z([1,false])
Z(z[14])
Z(z[9])
Z(z[10])
Z([3,'records'])
Z(z[12])
Z(z[13])
Z(z[38])
Z(z[13])
Z(z[38])
Z([3,'height:140rpx;padding:0;width:686rpx;border-radius:32rpx;background:var(--bg-color);border-radius:32rpx;margin-top:16rpx'])
Z([3,'contact'])
Z(z[9])
Z(z[10])
Z(z[49])
Z(z[12])
})(__WXML_GLOBAL__.ops_cached.$gwx_XC_27_1);return __WXML_GLOBAL__.ops_cached.$gwx_XC_27_1
}
__WXML_GLOBAL__.ops_set.$gwx_XC_27=z;
__WXML_GLOBAL__.ops_init.$gwx_XC_27=true;
var x=['./components/zhuanpan/more/more.wxml'];d_[x[0]]={}
var m0=function(e,s,r,gg){
var z=gz$gwx_XC_27_1()
var aFG=_mz(z,'van-popup',['bind:close',0,'closeable',1,'customClass',1,'position',2,'show',3],[],e,s,gg)
var oJG=_mz(z,'button',['bindtap',5,'class',1,'data-detail',2,'openType',3],[],e,s,gg)
var xKG=_mz(z,'van-icon',['class',9,'color',1,'name',2,'size',3],[],e,s,gg)
_(oJG,xKG)
var oLG=_n('van-icon')
_rz(z,oLG,'name',13,e,s,gg)
_(oJG,oLG)
_(aFG,oJG)
var fMG=_n('view')
_rz(z,fMG,'class',14,e,s,gg)
var cNG=_mz(z,'van-icon',['class',15,'color',1,'name',2,'size',3],[],e,s,gg)
_(fMG,cNG)
var hOG=_mz(z,'van-switch',['bind:change',19,'checked',1,'data-type',2,'size',3],[],e,s,gg)
_(fMG,hOG)
_(aFG,fMG)
var oPG=_mz(z,'van-switch',['bind:change',23,'checked',1,'data-type',2,'size',3],[],e,s,gg)
_(aFG,oPG)
var cQG=_n('view')
_rz(z,cQG,'class',27,e,s,gg)
var oRG=_mz(z,'van-icon',['class',28,'color',1,'name',2,'size',3],[],e,s,gg)
_(cQG,oRG)
var lSG=_mz(z,'van-dropdown-menu',['customClass',32,'direction',1],[],e,s,gg)
var aTG=_mz(z,'van-dropdown-item',['bindchange',34,'data-type',1,'options',2,'value',3],[],e,s,gg)
_(lSG,aTG)
_(cQG,lSG)
_(aFG,cQG)
var tGG=_v()
_(aFG,tGG)
if(_oz(z,38,e,s,gg)){tGG.wxVkey=1
var tUG=_n('view')
_rz(z,tUG,'class',39,e,s,gg)
var eVG=_mz(z,'van-icon',['class',40,'color',1,'name',2,'size',3],[],e,s,gg)
_(tUG,eVG)
var bWG=_n('van-icon')
_rz(z,bWG,'name',44,e,s,gg)
_(tUG,bWG)
_(tGG,tUG)
}
var eHG=_v()
_(aFG,eHG)
if(_oz(z,45,e,s,gg)){eHG.wxVkey=1
var oXG=_n('van-icon')
_rz(z,oXG,'name',46,e,s,gg)
_(eHG,oXG)
}
var bIG=_v()
_(aFG,bIG)
if(_oz(z,47,e,s,gg)){bIG.wxVkey=1
var xYG=_mz(z,'van-button',['plain',-1,'customStyle',48,'openType',1],[],e,s,gg)
var oZG=_mz(z,'van-icon',['class',50,'color',1,'name',2,'size',3],[],e,s,gg)
_(xYG,oZG)
_(bIG,xYG)
}
tGG.wxXCkey=1
tGG.wxXCkey=3
eHG.wxXCkey=1
eHG.wxXCkey=3
bIG.wxXCkey=1
bIG.wxXCkey=3
_(r,aFG)
return r
}
e_[x[0]]={f:m0,j:[],i:[],ti:[],ic:[]}
if(path&&e_[path]){
return function(env,dd,global){$gwxc=0;var root={"tag":"wx-page"};root.children=[]
;g="$gwx_XC_27";var main=e_[path].f
if (typeof global==="undefined")global={};global.f=$gdc(f_[path],"",1);
try{
main(env,{},root,global);
_tsd(root)
}catch(err){
console.log(err)
}
;g="";
return root;
}
}
}
}(__g.a,__g.b,__g.c,__g.d,__g.e,__g.f,__g.g,__g.h,__g.i,__g.j,__g.k,__g.l,__g.m,__g.n,__g.o,__g.p,__g.q,__g.r,__g.s,__g.t,__g.u,__g.v,__g.w,__g.x,__g.y,__g.z,__g.A,__g.B,__g.C,__g.D,__g.E,__g.F,__g.G,__g.H,__g.I,__g.J,__g.K,__g.L,__g.M,__g.N,__g.O,__g.P,__g.Q,__g.R,__g.S,__g.T,__g.U,__g.V,__g.W,__g.X,__g.Y,__g.Z,__g.aa);if(__vd_version_info__.delayedGwx||false)$gwx_XC_27();	if (__vd_version_info__.delayedGwx) __wxAppCode__['components/zhuanpan/more/more.wxml'] = [$gwx_XC_27, './components/zhuanpan/more/more.wxml'];else __wxAppCode__['components/zhuanpan/more/more.wxml'] = $gwx_XC_27( './components/zhuanpan/more/more.wxml' );
	;__wxRoute = "components/zhuanpan/more/more";__wxRouteBegin = true;__wxAppCurrentFile__="components/zhuanpan/more/more.js";define("components/zhuanpan/more/more.js",function(require,module,exports,window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){
"use strict";var e=require("../../../@babel/runtime/helpers/interopRequireDefault")(require("../../../@babel/runtime/regenerator")),t=require("../../../@babel/runtime/helpers/defineProperty"),s=require("../../../@babel/runtime/helpers/asyncToGenerator"),a=require("../../../72CE30E5415216BF14A858E26129EA57.js").getTTS,r=getApp();Component({behaviors:[wx.Bus],properties:{},data:{showMore:!1,settings:{vibrate:!0,sound:!0,speaker:"1"},speakers:[{text:"不需要播报转盘结果",value:"none"},{text:"情感女声-智瑜",value:"1001"},{text:"知性女声-智娜",value:"1007"},{text:"通用女声-智莉",value:"1005"},{text:"通用男声-智华",value:"1"},{text:"情感男声-智靖",value:"1018"},{text:"情感男声-智云",value:"1004"}]},methods:{showMore:function(){this.setData({showMore:!0})},hideMore:function(){this.setData({showMore:!1})},showShare:function(){this.$bus.event.call("share:showShare")},shareMyZp:function(){var e=this.$bus.get("zpInfo");e.id.startsWith("template_")||e.openid!==r.globalData.openid?wx.showToast({title:"请先保存当前转盘，才可以分享哦！",icon:"none"}):(this.setData({showMore:!1}),this.$bus.event.emit("share-settings:show"))},settingsChange:function(r){var n=this;return s(e.default.mark((function s(){var i,o,u;return e.default.wrap((function(e){for(;;)switch(e.prev=e.next){case 0:if(i=r.currentTarget.dataset.type,o=r.detail,n.setData(t({},"settings.".concat(i),o)),"speaker"!==i){e.next=10;break}if("none"!==o){e.next=6;break}return e.abrupt("return");case 6:return e.next=8,a("欢迎使用全能小转盘",o);case 8:0===(u=e.sent).code&&(n.audioCtx.src=u.data,n.audioCtx.play());case 10:n.updateSettings();case 11:case"end":return e.stop()}}),s)})))()},updateSettings:function(){this.$bus.store.set("settings",this.data.settings),wx.setStorageSync("settings",this.data.settings)},showDyh:function(){wx.navigateTo({url:"/pages/webview/webview?url=".concat(encodeURIComponent("https://mp.weixin.qq.com/s/crtWaRZGrSh_DUOT9T48Dw"))})}},lifetimes:{attached:function(){var e=this,t=wx.getStorageSync("settings")||this.data.settings;this.$bus.store.set("settings",t),this.$bus.event.export("more:showMore",(function(){e.showMore(),e.setData({settings:t})})),this.$bus.event.export("more:hiddenMore",(function(){e.hideMore()})),this.audioCtx=wx.createInnerAudioContext()},detached:function(){this.audioCtx&&this.audioCtx.destroy()}}});
},{isPage:false,isComponent:true,currentFile:'components/zhuanpan/more/more.js'});require("components/zhuanpan/more/more.js");