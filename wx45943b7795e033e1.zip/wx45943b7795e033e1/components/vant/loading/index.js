Object.defineProperty(exports, "__esModule", {
    value: !0
}), (0, require("../../../F7998786415216BF91FFEF81DB47EA57.js").VantComponent)({
    props: {
        color: String,
        vertical: Boolean,
        type: {
            type: String,
            value: "circular"
        },
        size: String,
        textSize: String
    },
    data: {
        array12: Array.from({
            length: 12
        })
    }
});