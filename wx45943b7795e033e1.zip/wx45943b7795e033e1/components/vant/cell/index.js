Object.defineProperty(exports, "__esModule", {
    value: !0
});

var e = require("../../../D1056893415216BFB7630094D8E7EA57.js");

(0, require("../../../F7998786415216BF91FFEF81DB47EA57.js").VantComponent)({
    classes: [ "title-class", "label-class", "value-class", "right-icon-class", "hover-class" ],
    mixins: [ e.link ],
    props: {
        title: null,
        value: null,
        icon: String,
        size: String,
        label: String,
        center: Boolean,
        isLink: Boolean,
        required: Boolean,
        clickable: Boolean,
        titleWidth: String,
        customStyle: String,
        arrowDirection: String,
        useLabelSlot: Boolean,
        border: {
            type: Boolean,
            value: !0
        },
        titleStyle: String
    },
    methods: {
        onClick: function(e) {
            this.$emit("click", e.detail), this.jumpLink();
        }
    }
});