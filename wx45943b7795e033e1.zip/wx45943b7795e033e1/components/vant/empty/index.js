Object.defineProperty(exports, "__esModule", {
    value: !0
}), (0, require("../../../F7998786415216BF91FFEF81DB47EA57.js").VantComponent)({
    props: {
        description: String,
        image: {
            type: String,
            value: "default"
        }
    }
});