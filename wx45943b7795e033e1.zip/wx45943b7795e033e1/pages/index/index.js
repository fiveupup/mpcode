var t = require("../../@babel/runtime/helpers/interopRequireDefault"), e = require("../../@babel/runtime/helpers/toConsumableArray"), a = t(require("../../@babel/runtime/regenerator")), n = require("../../@babel/runtime/helpers/asyncToGenerator"), r = getApp(), o = require("../../BD436B82415216BFDB250385AAE6EA57.js"), i = require("../../8A51F322415216BFEC379B250C07EA57.js");

Page({
    data: {
        hotList: [],
        mineList: [],
        showNotice: !1,
        loading: !0,
        offset: 0,
        count: 0
    },
    toZp: function(t) {
        var e = t.currentTarget.dataset, a = e.id, n = e.from;
        wx.navigateTo({
            url: "/pages/zhuanpan/index/index?id=".concat(a, "&from=").concat(n)
        });
    },
    loadHotList: function() {
        var t = o.index;
        this.setData({
            hotList: t
        });
    },
    onLoad: function() {
        this.loadHotList(), this.loadMyList();
    },
    loadMyList: function() {
        var t = this;
        return n(a.default.mark(function e() {
            var n, o, s;
            return a.default.wrap(function(e) {
                for (;;) switch (e.prev = e.next) {
                  case 0:
                    return wx.showNavigationBarLoading(), e.next = 3, r.initLogin();

                  case 3:
                    if (e.sent) {
                        e.next = 7;
                        break;
                    }
                    return t.setData({
                        showNotice: !0
                    }), wx.hideNavigationBarLoading(), e.abrupt("return");

                  case 7:
                    return console.log("登录成功"), e.prev = 8, e.next = 11, i.list();

                  case 11:
                    if (n = e.sent, t.setData({
                        loading: !1
                    }), 0 !== n.code) {
                        e.next = 19;
                        break;
                    }
                    return o = n.data.list, s = n.data.count, wx.hideNavigationBarLoading(), t.setData({
                        list: o,
                        showNotice: !1,
                        count: s,
                        offset: 0
                    }), e.abrupt("return");

                  case 19:
                    e.next = 23;
                    break;

                  case 21:
                    e.prev = 21, e.t0 = e.catch(8);

                  case 23:
                    t.setData({
                        showNotice: !0
                    });

                  case 24:
                  case "end":
                    return e.stop();
                }
            }, e, null, [ [ 8, 21 ] ]);
        }))();
    },
    showMore: function() {
        var t = this;
        return n(a.default.mark(function n() {
            var r, o, s;
            return a.default.wrap(function(a) {
                for (;;) switch (a.prev = a.next) {
                  case 0:
                    return wx.showLoading({
                        title: "加载中.."
                    }), a.next = 3, i.list(t.data.offset + 30);

                  case 3:
                    r = a.sent, wx.hideLoading(), 0 === r.code && (s = r.data.list, (o = t.data.list).push.apply(o, e(s)), 
                    wx.hideNavigationBarLoading(), t.setData({
                        list: t.data.list,
                        offset: t.data.offset + 30
                    }));

                  case 6:
                  case "end":
                    return a.stop();
                }
            }, n);
        }))();
    },
    showMoreSheet: function(t) {
        var e = this;
        return n(a.default.mark(function r() {
            var o, i, s;
            return a.default.wrap(function(r) {
                for (;;) switch (r.prev = r.next) {
                  case 0:
                    o = t.currentTarget.dataset.id, s = [ (i = {
                        DELETE: "🗑️  删除",
                        EDIT: "📝  编辑",
                        COPY: "📋  复制",
                        SHARE_TO_HOT: "分享到热门转盘"
                    }).EDIT, i.COPY, i.DELETE, i.SHARE_TO_HOT ], wx.showActionSheet({
                        itemList: s,
                        success: function() {
                            var t = n(a.default.mark(function t(n) {
                                return a.default.wrap(function(t) {
                                    for (;;) switch (t.prev = t.next) {
                                      case 0:
                                        console.log(n), t.t0 = s[n.tapIndex], t.next = t.t0 === i.EDIT ? 4 : t.t0 === i.COPY ? 6 : t.t0 === i.DELETE ? 8 : t.t0 === i.SHARE_TO_HOT ? 10 : 11;
                                        break;

                                      case 4:
                                        return e.editZp(o), t.abrupt("break", 11);

                                      case 6:
                                        return e.copyZp(o), t.abrupt("break", 11);

                                      case 8:
                                        return e.deleteZp(o), t.abrupt("break", 11);

                                      case 10:
                                        e.shareToHot(o);

                                      case 11:
                                      case "end":
                                        return t.stop();
                                    }
                                }, t);
                            }));
                            return function(e) {
                                return t.apply(this, arguments);
                            };
                        }()
                    });

                  case 4:
                  case "end":
                    return r.stop();
                }
            }, r);
        }))();
    },
    copyZp: function(t) {
        var e = this;
        return n(a.default.mark(function n() {
            return a.default.wrap(function(a) {
                for (;;) switch (a.prev = a.next) {
                  case 0:
                    return a.next = 2, i.copy(t);

                  case 2:
                    0 === a.sent.code && (wx.showToast({
                        title: "复制成功！",
                        icon: "success",
                        duration: 2e3
                    }), e.loadMyList());

                  case 4:
                  case "end":
                    return a.stop();
                }
            }, n);
        }))();
    },
    shareToHot: function(t) {
        var e;
        wx.showModal({
            title: "将转盘分享至【热门转盘】",
            content: "分享后，所有人都能看到该转盘。人工审核通过后才会出现在热门转盘列表，且分享后不可撤销！",
            confirmText: "确认分享",
            success: (e = n(a.default.mark(function e(n) {
                return a.default.wrap(function(e) {
                    for (;;) switch (e.prev = e.next) {
                      case 0:
                        if (!n.confirm) {
                            e.next = 5;
                            break;
                        }
                        return e.next = 3, i.addToHot(t);

                      case 3:
                        0 === e.sent.code ? wx.showToast({
                            title: "分享成功，感谢您！",
                            icon: "none",
                            duration: 5e3
                        }) : wx.showToast({
                            title: "分享失败！同转盘只能分享一次哦~",
                            icon: "none",
                            duration: 2e3
                        });

                      case 5:
                      case "end":
                        return e.stop();
                    }
                }, e);
            })), function(t) {
                return e.apply(this, arguments);
            })
        });
    },
    addZp: function() {
        wx.navigateTo({
            url: "/pages/zhuanpan/edit/edit?type=add"
        });
    },
    editZp: function(t) {
        wx.navigateTo({
            url: "/pages/zhuanpan/edit/edit?type=edit&id=".concat(t)
        });
    },
    deleteZp: function(t) {
        var e = this;
        return n(a.default.mark(function n() {
            return a.default.wrap(function(a) {
                for (;;) switch (a.prev = a.next) {
                  case 0:
                    return a.next = 2, i.deleteOneById(t);

                  case 2:
                    0 === a.sent.code && (wx.showToast({
                        title: "删除成功！",
                        icon: "success",
                        duration: 2e3
                    }), e.loadMyList());

                  case 4:
                  case "end":
                    return a.stop();
                }
            }, n);
        }))();
    },
    onShareAppMessage: function(t) {
        if ("button" === t.from) {
            console.log(t);
            var e = t.target.dataset.detail, a = "/pages/zhuanpan/index/index?id=".concat(e.id, "&from=share") + (e.share_type_is_2 ? "&share_type=2" : "");
            return console.log(a), {
                title: e.title,
                path: a,
                imageUrl: "http://pan00.jialidun.vip/zp/zplogo.jpeg",
                success: function(t) {
                    wx.showToast({
                        title: "分享成功～"
                    });
                }
            };
        }
        return {
            title: "全能小转盘！",
            path: "/pages/index/index",
            imageUrl: "http://pan00.jialidun.vip/zp/zplogo.jpeg",
            success: function(t) {
                wx.showToast({
                    title: "分享成功！"
                });
            }
        };
    },
    onShareTimeline: function() {
        return {
            title: "全能小转盘！",
            query: "top_c=相互推荐&sub_c=朋友圈"
        };
    },
    onShow: function() {
        r.globalData._updateZpList && (this.loadMyList(), r.globalData._updateZpList = !1);
    },
    toMoreZp: function() {
        wx.navigateTo({
            url: "/pages/more/more"
        });
    },
    onReady: function() {}
});