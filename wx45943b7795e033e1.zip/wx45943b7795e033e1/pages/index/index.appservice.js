$gwx_XC_34=function(_,_v,_n,_p,_s,_wp,_wl,$gwn,$gwl,$gwh,wh,$gstack,$gwrt,gra,grb,TestTest,wfor,_ca,_da,_r,_rz,_o,_oz,_1,_1z,_2,_2z,_m,_mz,nv_getDate,nv_getRegExp,nv_console,nv_parseInt,nv_parseFloat,nv_isNaN,nv_isFinite,nv_decodeURI,nv_decodeURIComponent,nv_encodeURI,nv_encodeURIComponent,$gdc,nv_JSON,_af,_gv,_ai,_grp,_gd,_gapi,$ixc,_ic,_w,_ev,_tsd){return function(path,global){
if(typeof global==='undefined'){if (typeof __GWX_GLOBAL__==='undefined')global={};else global=__GWX_GLOBAL__;}if(typeof __WXML_GLOBAL__ === 'undefined') {__WXML_GLOBAL__={};
}__WXML_GLOBAL__.modules = __WXML_GLOBAL__.modules || {};
var e_={}
if(typeof(global.entrys)==='undefined')global.entrys={};e_=global.entrys;
var d_={}
if(typeof(global.defines)==='undefined')global.defines={};d_=global.defines;
var f_={}
if(typeof(global.modules)==='undefined')global.modules={};f_=global.modules || {};
var p_={}
__WXML_GLOBAL__.ops_cached = __WXML_GLOBAL__.ops_cached || {}
__WXML_GLOBAL__.ops_set = __WXML_GLOBAL__.ops_set || {};
__WXML_GLOBAL__.ops_init = __WXML_GLOBAL__.ops_init || {};
var z=__WXML_GLOBAL__.ops_set.$gwx_XC_34 || [];
function gz$gwx_XC_34_1(){
if( __WXML_GLOBAL__.ops_cached.$gwx_XC_34_1)return __WXML_GLOBAL__.ops_cached.$gwx_XC_34_1
__WXML_GLOBAL__.ops_cached.$gwx_XC_34_1=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
Z([[2,'?:'],[[2,'>'],[[6],[[7],[3,'list']],[3,'length']],[1,0]],[1,1],[1,0]])
Z([3,'true'])
Z([3,'热门转盘'])
Z([3,'list'])
Z([3,'margin-top: 20rpx'])
Z([[7],[3,'hotList']])
Z([3,'key'])
Z([3,'toZp'])
Z([3,'box'])
Z([3,'hot'])
Z([[6],[[7],[3,'item']],[3,'id']])
Z([[6],[[7],[3,'item']],[3,'icon']])
Z([3,'80rpx'])
Z([3,'toMoreZp'])
Z(z[8])
Z([3,'more-o'])
Z(z[12])
Z([3,'我的转盘'])
Z([1,false])
Z([[7],[3,'showNotice']])
Z([3,'#e3f7ff'])
Z([3,'loadMyList'])
Z([3,'#1f90cc'])
Z([3,'info-o'])
Z([3,'加载失败了，点击重试'])
Z([[7],[3,'loading']])
Z([3,'#1989fa'])
Z([3,'200rpx'])
Z([3,'spinner'])
Z([3,'mine_list'])
Z([3,'margin-top: 20rpx;min-height:80vh;padding-bottom:120rpx'])
Z([3,'addZp'])
Z([3,'addNew'])
Z([3,'mr2'])
Z([3,'#1c90ff'])
Z([3,'add-o'])
Z([3,'56rpx'])
Z([[7],[3,'list']])
Z([3,'id'])
Z([3,'flex flex-align-center'])
Z([3,'border:none;color:#ccc;font-size:24rpx;width:60rpx'])
Z([[9],[[9],[[8],'id',[[6],[[7],[3,'item']],[3,'id']]],[[8],'title',[[6],[[7],[3,'item']],[3,'title']]]],[[8],'share_type_is_2',[[2,'&&'],[[6],[[7],[3,'item']],[3,'share_settings']],[[2,'>'],[[6],[[6],[[7],[3,'item']],[3,'share_settings']],[3,'p_times']],[1,0]]]]])
Z([3,'share'])
Z(z[42])
Z([3,'medium'])
Z([3,'showMoreSheet'])
Z([3,'text-center'])
Z(z[10])
Z([3,'width:60rpx'])
Z([3,'#ccc'])
Z([3,'sjzp-gengduo'])
Z([3,'28rpx'])
Z([[2,'<'],[[6],[[7],[3,'list']],[3,'length']],[[7],[3,'count']]])
Z([3,'showMore'])
Z([3,'text-center mt2'])
Z([[2,'<'],[[6],[[7],[3,'list']],[3,'length']],[1,1]])
Z([3,'您还没有创建过任何转盘呢'])
Z([3,'https://img01.yzcdn.cn/vant/custom-empty-image.png'])
Z(z[31])
Z([3,'width:300rpx'])
Z([3,'info'])
})(__WXML_GLOBAL__.ops_cached.$gwx_XC_34_1);return __WXML_GLOBAL__.ops_cached.$gwx_XC_34_1
}
__WXML_GLOBAL__.ops_set.$gwx_XC_34=z;
__WXML_GLOBAL__.ops_init.$gwx_XC_34=true;
var x=['./pages/index/index.wxml'];d_[x[0]]={}
var m0=function(e,s,r,gg){
var z=gz$gwx_XC_34_1()
var hUH=_mz(z,'van-tabs',['active',0,'swipeable',1],[],e,s,gg)
var oVH=_n('van-tab')
_rz(z,oVH,'title',2,e,s,gg)
var cWH=_mz(z,'view',['class',3,'style',1],[],e,s,gg)
var oXH=_v()
_(cWH,oXH)
var lYH=function(t1H,aZH,e2H,gg){
var o4H=_mz(z,'view',['bind:tap',7,'class',1,'data-from',2,'data-id',3],[],t1H,aZH,gg)
var x5H=_mz(z,'van-icon',['name',11,'size',1],[],t1H,aZH,gg)
_(o4H,x5H)
_(e2H,o4H)
return e2H
}
oXH.wxXCkey=4
_2z(z,5,lYH,e,s,gg,oXH,'item','index','key')
var o6H=_mz(z,'view',['bindtap',13,'class',1],[],e,s,gg)
var f7H=_mz(z,'van-icon',['name',15,'size',1],[],e,s,gg)
_(o6H,f7H)
_(cWH,o6H)
_(oVH,cWH)
_(hUH,oVH)
var c8H=_n('van-tab')
_rz(z,c8H,'title',17,e,s,gg)
var h9H=_v()
_(c8H,h9H)
if(_oz(z,18,e,s,gg)){h9H.wxVkey=1
}
var o0H=_n('view')
var cAI=_v()
_(o0H,cAI)
if(_oz(z,19,e,s,gg)){cAI.wxVkey=1
var lCI=_mz(z,'van-notice-bar',['background',20,'bind:click',1,'color',2,'leftIcon',3,'text',4],[],e,s,gg)
_(cAI,lCI)
}
var oBI=_v()
_(o0H,oBI)
if(_oz(z,25,e,s,gg)){oBI.wxVkey=1
var aDI=_mz(z,'van-loading',['color',26,'size',1,'type',2],[],e,s,gg)
_(oBI,aDI)
}
var tEI=_mz(z,'view',['class',29,'style',1],[],e,s,gg)
var oHI=_mz(z,'view',['catch:tap',31,'class',1],[],e,s,gg)
var xII=_mz(z,'van-icon',['class',33,'color',1,'name',2,'size',3],[],e,s,gg)
_(oHI,xII)
_(tEI,oHI)
var oJI=_v()
_(tEI,oJI)
var fKI=function(hMI,cLI,oNI,gg){
var oPI=_n('view')
_rz(z,oPI,'class',39,hMI,cLI,gg)
var lQI=_mz(z,'van-button',['customStyle',40,'dataset',1,'icon',2,'openType',3,'size',4],[],hMI,cLI,gg)
_(oPI,lQI)
var aRI=_mz(z,'view',['bind:tap',45,'class',1,'data-id',2,'style',3],[],hMI,cLI,gg)
var tSI=_mz(z,'van-icon',['color',49,'name',1,'size',2],[],hMI,cLI,gg)
_(aRI,tSI)
_(oPI,aRI)
_(oNI,oPI)
return oNI
}
oJI.wxXCkey=4
_2z(z,37,fKI,e,s,gg,oJI,'item','index','id')
var eFI=_v()
_(tEI,eFI)
if(_oz(z,52,e,s,gg)){eFI.wxVkey=1
var eTI=_mz(z,'view',['bindtap',53,'class',1],[],e,s,gg)
var bUI=_n('van-button')
_(eTI,bUI)
_(eFI,eTI)
}
var bGI=_v()
_(tEI,bGI)
if(_oz(z,55,e,s,gg)){bGI.wxVkey=1
var oVI=_n('view')
var xWI=_mz(z,'van-empty',['description',56,'image',1],[],e,s,gg)
_(oVI,xWI)
var oXI=_mz(z,'van-button',['round',-1,'bind:tap',58,'customStyle',1,'type',2],[],e,s,gg)
_(oVI,oXI)
_(bGI,oVI)
}
eFI.wxXCkey=1
eFI.wxXCkey=3
bGI.wxXCkey=1
bGI.wxXCkey=3
_(o0H,tEI)
cAI.wxXCkey=1
cAI.wxXCkey=3
oBI.wxXCkey=1
oBI.wxXCkey=3
_(c8H,o0H)
h9H.wxXCkey=1
_(hUH,c8H)
_(r,hUH)
return r
}
e_[x[0]]={f:m0,j:[],i:[],ti:[],ic:[]}
if(path&&e_[path]){
return function(env,dd,global){$gwxc=0;var root={"tag":"wx-page"};root.children=[]
;g="$gwx_XC_34";var main=e_[path].f
if (typeof global==="undefined")global={};global.f=$gdc(f_[path],"",1);
try{
main(env,{},root,global);
_tsd(root)
}catch(err){
console.log(err)
}
;g="";
return root;
}
}
}
}(__g.a,__g.b,__g.c,__g.d,__g.e,__g.f,__g.g,__g.h,__g.i,__g.j,__g.k,__g.l,__g.m,__g.n,__g.o,__g.p,__g.q,__g.r,__g.s,__g.t,__g.u,__g.v,__g.w,__g.x,__g.y,__g.z,__g.A,__g.B,__g.C,__g.D,__g.E,__g.F,__g.G,__g.H,__g.I,__g.J,__g.K,__g.L,__g.M,__g.N,__g.O,__g.P,__g.Q,__g.R,__g.S,__g.T,__g.U,__g.V,__g.W,__g.X,__g.Y,__g.Z,__g.aa);if(__vd_version_info__.delayedGwx||false)$gwx_XC_34();	if (__vd_version_info__.delayedGwx) __wxAppCode__['pages/index/index.wxml'] = [$gwx_XC_34, './pages/index/index.wxml'];else __wxAppCode__['pages/index/index.wxml'] = $gwx_XC_34( './pages/index/index.wxml' );
	;__wxRoute = "pages/index/index";__wxRouteBegin = true;__wxAppCurrentFile__="pages/index/index.js";define("pages/index/index.js",function(require,module,exports,window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){
"use strict";var t=require("../../@babel/runtime/helpers/interopRequireDefault"),e=require("../../@babel/runtime/helpers/toConsumableArray"),a=t(require("../../@babel/runtime/regenerator")),n=require("../../@babel/runtime/helpers/asyncToGenerator"),r=getApp(),o=require("../../BD436B82415216BFDB250385AAE6EA57.js"),i=require("../../8A51F322415216BFEC379B250C07EA57.js");Page({data:{hotList:[],mineList:[],showNotice:!1,loading:!0,offset:0,count:0},toZp:function(t){var e=t.currentTarget.dataset,a=e.id,n=e.from;wx.navigateTo({url:"/pages/zhuanpan/index/index?id=".concat(a,"&from=").concat(n)})},loadHotList:function(){var t=o.index;this.setData({hotList:t})},onLoad:function(){this.loadHotList(),this.loadMyList()},loadMyList:function(){var t=this;return n(a.default.mark((function e(){var n,o,s;return a.default.wrap((function(e){for(;;)switch(e.prev=e.next){case 0:return wx.showNavigationBarLoading(),e.next=3,r.initLogin();case 3:if(e.sent){e.next=7;break}return t.setData({showNotice:!0}),wx.hideNavigationBarLoading(),e.abrupt("return");case 7:return console.log("登录成功"),e.prev=8,e.next=11,i.list();case 11:if(n=e.sent,t.setData({loading:!1}),0!==n.code){e.next=19;break}return o=n.data.list,s=n.data.count,wx.hideNavigationBarLoading(),t.setData({list:o,showNotice:!1,count:s,offset:0}),e.abrupt("return");case 19:e.next=23;break;case 21:e.prev=21,e.t0=e.catch(8);case 23:t.setData({showNotice:!0});case 24:case"end":return e.stop()}}),e,null,[[8,21]])})))()},showMore:function(){var t=this;return n(a.default.mark((function n(){var r,o,s;return a.default.wrap((function(a){for(;;)switch(a.prev=a.next){case 0:return wx.showLoading({title:"加载中.."}),a.next=3,i.list(t.data.offset+30);case 3:r=a.sent,wx.hideLoading(),0===r.code&&(s=r.data.list,(o=t.data.list).push.apply(o,e(s)),wx.hideNavigationBarLoading(),t.setData({list:t.data.list,offset:t.data.offset+30}));case 6:case"end":return a.stop()}}),n)})))()},showMoreSheet:function(t){var e=this;return n(a.default.mark((function r(){var o,i,s;return a.default.wrap((function(r){for(;;)switch(r.prev=r.next){case 0:o=t.currentTarget.dataset.id,s=[(i={DELETE:"🗑️  删除",EDIT:"📝  编辑",COPY:"📋  复制",SHARE_TO_HOT:"分享到热门转盘"}).EDIT,i.COPY,i.DELETE,i.SHARE_TO_HOT],wx.showActionSheet({itemList:s,success:function(){var t=n(a.default.mark((function t(n){return a.default.wrap((function(t){for(;;)switch(t.prev=t.next){case 0:console.log(n),t.t0=s[n.tapIndex],t.next=t.t0===i.EDIT?4:t.t0===i.COPY?6:t.t0===i.DELETE?8:t.t0===i.SHARE_TO_HOT?10:11;break;case 4:return e.editZp(o),t.abrupt("break",11);case 6:return e.copyZp(o),t.abrupt("break",11);case 8:return e.deleteZp(o),t.abrupt("break",11);case 10:e.shareToHot(o);case 11:case"end":return t.stop()}}),t)})));return function(e){return t.apply(this,arguments)}}()});case 4:case"end":return r.stop()}}),r)})))()},copyZp:function(t){var e=this;return n(a.default.mark((function n(){return a.default.wrap((function(a){for(;;)switch(a.prev=a.next){case 0:return a.next=2,i.copy(t);case 2:0===a.sent.code&&(wx.showToast({title:"复制成功！",icon:"success",duration:2e3}),e.loadMyList());case 4:case"end":return a.stop()}}),n)})))()},shareToHot:function(t){var e;wx.showModal({title:"将转盘分享至【热门转盘】",content:"分享后，所有人都能看到该转盘。人工审核通过后才会出现在热门转盘列表，且分享后不可撤销！",confirmText:"确认分享",success:(e=n(a.default.mark((function e(n){return a.default.wrap((function(e){for(;;)switch(e.prev=e.next){case 0:if(!n.confirm){e.next=5;break}return e.next=3,i.addToHot(t);case 3:0===e.sent.code?wx.showToast({title:"分享成功，感谢您！",icon:"none",duration:5e3}):wx.showToast({title:"分享失败！同转盘只能分享一次哦~",icon:"none",duration:2e3});case 5:case"end":return e.stop()}}),e)}))),function(t){return e.apply(this,arguments)})})},addZp:function(){wx.navigateTo({url:"/pages/zhuanpan/edit/edit?type=add"})},editZp:function(t){wx.navigateTo({url:"/pages/zhuanpan/edit/edit?type=edit&id=".concat(t)})},deleteZp:function(t){var e=this;return n(a.default.mark((function n(){return a.default.wrap((function(a){for(;;)switch(a.prev=a.next){case 0:return a.next=2,i.deleteOneById(t);case 2:0===a.sent.code&&(wx.showToast({title:"删除成功！",icon:"success",duration:2e3}),e.loadMyList());case 4:case"end":return a.stop()}}),n)})))()},onShareAppMessage:function(t){if("button"===t.from){console.log(t);var e=t.target.dataset.detail,a="/pages/zhuanpan/index/index?id=".concat(e.id,"&from=share")+(e.share_type_is_2?"&share_type=2":"");return console.log(a),{title:e.title,path:a,imageUrl:"http://pan00.jialidun.vip/zp/zplogo.jpeg",success:function(t){wx.showToast({title:"分享成功～"})}}}return{title:"全能小转盘！",path:"/pages/index/index",imageUrl:"http://pan00.jialidun.vip/zp/zplogo.jpeg",success:function(t){wx.showToast({title:"分享成功！"})}}},onShareTimeline:function(){return{title:"全能小转盘！",query:"top_c=相互推荐&sub_c=朋友圈"}},onShow:function(){r.globalData._updateZpList&&(this.loadMyList(),r.globalData._updateZpList=!1)},toMoreZp:function(){wx.navigateTo({url:"/pages/more/more"})},onReady:function(){}});
},{isPage:true,isComponent:true,currentFile:'pages/index/index.js'});require("pages/index/index.js");