$gwx_XC_34=function(_,_v,_n,_p,_s,_wp,_wl,$gwn,$gwl,$gwh,wh,$gstack,$gwrt,gra,grb,TestTest,wfor,_ca,_da,_r,_rz,_o,_oz,_1,_1z,_2,_2z,_m,_mz,nv_getDate,nv_getRegExp,nv_console,nv_parseInt,nv_parseFloat,nv_isNaN,nv_isFinite,nv_decodeURI,nv_decodeURIComponent,nv_encodeURI,nv_encodeURIComponent,$gdc,nv_JSON,_af,_gv,_ai,_grp,_gd,_gapi,$ixc,_ic,_w,_ev,_tsd){return function(path,global){
if(typeof global==='undefined'){if (typeof __GWX_GLOBAL__==='undefined')global={};else global=__GWX_GLOBAL__;}if(typeof __WXML_GLOBAL__ === 'undefined') {__WXML_GLOBAL__={};
}__WXML_GLOBAL__.modules = __WXML_GLOBAL__.modules || {};
var e_={}
if(typeof(global.entrys)==='undefined')global.entrys={};e_=global.entrys;
var d_={}
if(typeof(global.defines)==='undefined')global.defines={};d_=global.defines;
var f_={}
if(typeof(global.modules)==='undefined')global.modules={};f_=global.modules || {};
var p_={}
__WXML_GLOBAL__.ops_cached = __WXML_GLOBAL__.ops_cached || {}
__WXML_GLOBAL__.ops_set = __WXML_GLOBAL__.ops_set || {};
__WXML_GLOBAL__.ops_init = __WXML_GLOBAL__.ops_init || {};
var z=__WXML_GLOBAL__.ops_set.$gwx_XC_34 || [];
function gz$gwx_XC_34_1(){
if( __WXML_GLOBAL__.ops_cached.$gwx_XC_34_1)return __WXML_GLOBAL__.ops_cached.$gwx_XC_34_1
__WXML_GLOBAL__.ops_cached.$gwx_XC_34_1=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
Z([[2,'?:'],[[2,'>'],[[6],[[7],[3,'list']],[3,'length']],[1,0]],[1,1],[1,0]])
Z([3,'true'])
Z([3,'热门转盘'])
Z([3,'list'])
Z([3,'margin-top: 20rpx'])
Z([[7],[3,'hotList']])
Z([3,'key'])
Z([3,'toZp'])
Z([3,'box'])
Z([3,'hot'])
Z([[6],[[7],[3,'item']],[3,'id']])
Z([[6],[[7],[3,'item']],[3,'icon']])
Z([3,'80rpx'])
Z([3,'text'])
Z([a,[[6],[[7],[3,'item']],[3,'title']]])
Z([3,'toMoreZp'])
Z(z[8])
Z([3,'more-o'])
Z(z[12])
Z([3,'text ml3'])
Z([3,'更多转盘'])
Z([3,'我的转盘'])
Z([1,false])
Z([3,' 最上面显示上次使用的转盘 我的转盘置顶操作： 默认是列表样式的，长按列表项可以将转盘置顶，置顶的样式，就是现在【我的转盘】的样式。 只不过图标统一换成图标样式。后期可自定义？？？ '])
Z([[7],[3,'showNotice']])
Z([3,'#e3f7ff'])
Z([3,'loadMyList'])
Z([3,'#1f90cc'])
Z([3,'info-o'])
Z([3,'加载失败了，点击重试'])
Z([[7],[3,'loading']])
Z([3,'flex-center mt5'])
Z([3,'#1989fa'])
Z([3,'200rpx'])
Z([3,'spinner'])
Z([3,'mine_list'])
Z([3,'margin-top: 20rpx;min-height:80vh;padding-bottom:120rpx'])
Z([3,'addZp'])
Z([3,'addNew'])
Z([3,'mr2'])
Z([3,'#1c90ff'])
Z([3,'add-o'])
Z([3,'56rpx'])
Z([3,' 创建新转盘 '])
Z([[7],[3,'list']])
Z([3,'id'])
Z([3,'item'])
Z(z[7])
Z([3,'mr2 flex flex-align-center'])
Z([3,'mine'])
Z(z[10])
Z([3,'flex-grow:1'])
Z([a,z[14][1]])
Z([3,'flex flex-align-center'])
Z([3,'border:none;color:#ccc;font-size:24rpx;width:60rpx'])
Z([[9],[[9],[[8],'id',[[6],[[7],[3,'item']],[3,'id']]],[[8],'title',[[6],[[7],[3,'item']],[3,'title']]]],[[8],'share_type_is_2',[[2,'&&'],[[6],[[7],[3,'item']],[3,'share_settings']],[[2,'>'],[[6],[[6],[[7],[3,'item']],[3,'share_settings']],[3,'p_times']],[1,0]]]]])
Z([3,'share'])
Z(z[56])
Z([3,'medium'])
Z([3,'showMoreSheet'])
Z([3,'text-center'])
Z(z[10])
Z([3,'width:60rpx'])
Z([3,'#ccc'])
Z([3,'sjzp-gengduo'])
Z([3,'28rpx'])
Z([[2,'<'],[[6],[[7],[3,'list']],[3,'length']],[[7],[3,'count']]])
Z([3,'showMore'])
Z([3,'text-center mt2'])
Z([3,'加载更多...'])
Z([[2,'<'],[[6],[[7],[3,'list']],[3,'length']],[1,1]])
Z([3,'您还没有创建过任何转盘呢'])
Z([3,'https://img01.yzcdn.cn/vant/custom-empty-image.png'])
Z(z[60])
Z(z[37])
Z([3,'width:300rpx'])
Z([3,'info'])
Z([3,'创建转盘'])
})(__WXML_GLOBAL__.ops_cached.$gwx_XC_34_1);return __WXML_GLOBAL__.ops_cached.$gwx_XC_34_1
}
__WXML_GLOBAL__.ops_set.$gwx_XC_34=z;
__WXML_GLOBAL__.ops_init.$gwx_XC_34=true;
var x=['./pages/index/index.wxml'];d_[x[0]]={}
var m0=function(e,s,r,gg){
var z=gz$gwx_XC_34_1()
var cIO=_mz(z,'van-tabs',['active',0,'swipeable',1],[],e,s,gg)
var oJO=_n('van-tab')
_rz(z,oJO,'title',2,e,s,gg)
var lKO=_n('view')
var aLO=_mz(z,'view',['class',3,'style',1],[],e,s,gg)
var tMO=_v()
_(aLO,tMO)
var eNO=function(oPO,bOO,xQO,gg){
var fSO=_mz(z,'view',['bind:tap',7,'class',1,'data-from',2,'data-id',3],[],oPO,bOO,gg)
var cTO=_mz(z,'van-icon',['name',11,'size',1],[],oPO,bOO,gg)
_(fSO,cTO)
var hUO=_n('view')
_rz(z,hUO,'class',13,oPO,bOO,gg)
var oVO=_oz(z,14,oPO,bOO,gg)
_(hUO,oVO)
_(fSO,hUO)
_(xQO,fSO)
return xQO
}
tMO.wxXCkey=4
_2z(z,5,eNO,e,s,gg,tMO,'item','index','key')
var cWO=_mz(z,'view',['bindtap',15,'class',1],[],e,s,gg)
var oXO=_mz(z,'van-icon',['name',17,'size',1],[],e,s,gg)
_(cWO,oXO)
var lYO=_n('text')
_rz(z,lYO,'class',19,e,s,gg)
var aZO=_oz(z,20,e,s,gg)
_(lYO,aZO)
_(cWO,lYO)
_(aLO,cWO)
_(lKO,aLO)
_(oJO,lKO)
_(cIO,oJO)
var t1O=_n('van-tab')
_rz(z,t1O,'title',21,e,s,gg)
var e2O=_v()
_(t1O,e2O)
if(_oz(z,22,e,s,gg)){e2O.wxVkey=1
var b3O=_n('view')
var o4O=_oz(z,23,e,s,gg)
_(b3O,o4O)
_(e2O,b3O)
}
var x5O=_n('view')
var o6O=_v()
_(x5O,o6O)
if(_oz(z,24,e,s,gg)){o6O.wxVkey=1
var c8O=_mz(z,'van-notice-bar',['background',25,'bind:click',1,'color',2,'leftIcon',3,'text',4],[],e,s,gg)
_(o6O,c8O)
}
var f7O=_v()
_(x5O,f7O)
if(_oz(z,30,e,s,gg)){f7O.wxVkey=1
var h9O=_n('view')
_rz(z,h9O,'class',31,e,s,gg)
var o0O=_mz(z,'van-loading',['color',32,'size',1,'type',2],[],e,s,gg)
_(h9O,o0O)
_(f7O,h9O)
}
var cAP=_mz(z,'view',['class',35,'style',1],[],e,s,gg)
var aDP=_mz(z,'view',['catch:tap',37,'class',1],[],e,s,gg)
var tEP=_mz(z,'van-icon',['class',39,'color',1,'name',2,'size',3],[],e,s,gg)
_(aDP,tEP)
var eFP=_oz(z,43,e,s,gg)
_(aDP,eFP)
_(cAP,aDP)
var bGP=_v()
_(cAP,bGP)
var oHP=function(oJP,xIP,fKP,gg){
var hMP=_n('view')
_rz(z,hMP,'class',46,oJP,xIP,gg)
var oNP=_mz(z,'view',['bind:tap',47,'class',1,'data-from',2,'data-id',3,'style',4],[],oJP,xIP,gg)
var cOP=_oz(z,52,oJP,xIP,gg)
_(oNP,cOP)
_(hMP,oNP)
var oPP=_n('view')
_rz(z,oPP,'class',53,oJP,xIP,gg)
var lQP=_n('view')
var aRP=_mz(z,'van-button',['customStyle',54,'dataset',1,'icon',2,'openType',3,'size',4],[],oJP,xIP,gg)
_(lQP,aRP)
_(oPP,lQP)
var tSP=_mz(z,'view',['bind:tap',59,'class',1,'data-id',2,'style',3],[],oJP,xIP,gg)
var eTP=_mz(z,'van-icon',['color',63,'name',1,'size',2],[],oJP,xIP,gg)
_(tSP,eTP)
_(oPP,tSP)
_(hMP,oPP)
_(fKP,hMP)
return fKP
}
bGP.wxXCkey=4
_2z(z,44,oHP,e,s,gg,bGP,'item','index','id')
var oBP=_v()
_(cAP,oBP)
if(_oz(z,66,e,s,gg)){oBP.wxVkey=1
var bUP=_mz(z,'view',['bindtap',67,'class',1],[],e,s,gg)
var oVP=_n('van-button')
var xWP=_oz(z,69,e,s,gg)
_(oVP,xWP)
_(bUP,oVP)
_(oBP,bUP)
}
var lCP=_v()
_(cAP,lCP)
if(_oz(z,70,e,s,gg)){lCP.wxVkey=1
var oXP=_n('view')
var fYP=_mz(z,'van-empty',['description',71,'image',1],[],e,s,gg)
_(oXP,fYP)
var cZP=_n('view')
_rz(z,cZP,'class',73,e,s,gg)
var h1P=_mz(z,'van-button',['round',-1,'bind:tap',74,'customStyle',1,'type',2],[],e,s,gg)
var o2P=_oz(z,77,e,s,gg)
_(h1P,o2P)
_(cZP,h1P)
_(oXP,cZP)
_(lCP,oXP)
}
oBP.wxXCkey=1
oBP.wxXCkey=3
lCP.wxXCkey=1
lCP.wxXCkey=3
_(x5O,cAP)
o6O.wxXCkey=1
o6O.wxXCkey=3
f7O.wxXCkey=1
f7O.wxXCkey=3
_(t1O,x5O)
e2O.wxXCkey=1
_(cIO,t1O)
_(r,cIO)
return r
}
e_[x[0]]={f:m0,j:[],i:[],ti:[],ic:[]}
if(path&&e_[path]){
outerGlobal.__wxml_comp_version__=0.02
return function(env,dd,global){$gwxc=0;var root={"tag":"wx-page"};root.children=[]
;g="$gwx_XC_34";var main=e_[path].f
if (typeof global==="undefined")global={};global.f=$gdc(f_[path],"",1);
if(typeof(outerGlobal.__webview_engine_version__)!='undefined'&&outerGlobal.__webview_engine_version__+1e-6>=0.02+1e-6&&outerGlobal.__mergeData__)
{
env=outerGlobal.__mergeData__(env,dd);
}
try{
main(env,{},root,global);
_tsd(root)
if(typeof(outerGlobal.__webview_engine_version__)=='undefined'|| outerGlobal.__webview_engine_version__+1e-6<0.01+1e-6){return _ev(root);}
}catch(err){
console.log(err)
}
;g="";
return root;
}
}
}
}(__g.a,__g.b,__g.c,__g.d,__g.e,__g.f,__g.g,__g.h,__g.i,__g.j,__g.k,__g.l,__g.m,__g.n,__g.o,__g.p,__g.q,__g.r,__g.s,__g.t,__g.u,__g.v,__g.w,__g.x,__g.y,__g.z,__g.A,__g.B,__g.C,__g.D,__g.E,__g.F,__g.G,__g.H,__g.I,__g.J,__g.K,__g.L,__g.M,__g.N,__g.O,__g.P,__g.Q,__g.R,__g.S,__g.T,__g.U,__g.V,__g.W,__g.X,__g.Y,__g.Z,__g.aa);if(__vd_version_info__.delayedGwx||false)$gwx_XC_34();	if (__vd_version_info__.delayedGwx) __wxAppCode__['pages/index/index.wxml'] = [$gwx_XC_34, './pages/index/index.wxml'];else __wxAppCode__['pages/index/index.wxml'] = $gwx_XC_34( './pages/index/index.wxml' );
	
var noCss=typeof __vd_version_info__!=='undefined'&&__vd_version_info__.noCss===true;if(!noCss){__wxAppCode__['pages/index/index.wxss'] = setCssToHead(["body{background-color:#f6f7f8}\n.",[1],"list{grid-row-gap:",[0,42],";grid-column-gap:",[0,30],";display:grid;grid-template-columns:1fr 1fr;padding:",[0,32],"}\n.",[1],"mine_list{-webkit-flex-direction:column;flex-direction:column;padding-bottom:",[0,50],"}\n.",[1],"mine_list,.",[1],"mine_list .",[1],"item{display:-webkit-flex;display:flex}\n.",[1],"mine_list .",[1],"item{background:#fff;border-radius:",[0,32],";box-shadow:1px 3px 5px #eee;box-sizing:border-box;font-weight:500;-webkit-justify-content:space-between;justify-content:space-between;margin:",[0,22]," auto 0;padding:",[0,32],";width:",[0,710],"}\n.",[1],"item{color:#333}\n.",[1],"addNew{background:#fff;border:1px solid #1c90ff;border-radius:",[0,20],";color:#1c90ff;font-size:",[0,32],";height:",[0,90],";-webkit-justify-content:center;justify-content:center;margin:",[0,18]," ",[0,32],";padding:",[0,12],"}\n.",[1],"addNew,.",[1],"box{-webkit-align-items:center;align-items:center;box-shadow:1px 3px 5px #eee;display:-webkit-flex;display:flex}\n.",[1],"box{background-color:#fff;border-radius:",[0,32],";color:#333;font-size:",[0,28],";padding:",[0,35],"}\n.",[1],"text{color:#333;font-weight:700;margin-left:",[0,16],"}\n.",[1],"share{background:#fff;bottom:",[0,0],";font-size:",[0,32],";height:",[0,100],";left:0;position:fixed;width:100%}\n.",[1],"ad{-webkit-align-items:center;align-items:center;background:#eee;display:-webkit-flex;display:flex;-webkit-flex-direction:column;flex-direction:column;-webkit-justify-content:center;justify-content:center;margin-top:",[0,80],"}\n",],"Some selectors are not allowed in component wxss, including tag name selectors, ID selectors, and attribute selectors.(./pages/index/index.wxss:1:1)",{path:"./pages/index/index.wxss"});
}