var t = require("../../@babel/runtime/helpers/interopRequireDefault")(require("../../@babel/runtime/regenerator")), e = require("../../@babel/runtime/helpers/asyncToGenerator"), n = null, o = require("../../E36C2C77415216BF850A44701BF6EA57.js"), i = (o.getUploadToken, 
o.updateAvatar, getApp());

Page({
    data: {
        SHOW_TOP: !1,
        showSetting: !1,
        userInfo: {}
    },
    toUserInfo: function() {
        wx.navigateTo({
            url: "/p3/user-info/user-info"
        });
    },
    getUserInfo: function(n) {
        var o = this;
        return e(t.default.mark(function e() {
            var n;
            return t.default.wrap(function(t) {
                for (;;) switch (t.prev = t.next) {
                  case 0:
                    return t.next = 2, i.getUser();

                  case 2:
                    n = t.sent, o.setData({
                        userInfo: n
                    });

                  case 4:
                  case "end":
                    return t.stop();
                }
            }, e);
        }))();
    },
    hideTop: function() {
        this.setData({
            SHOW_TOP: !1
        });
    },
    showTop: function() {
        this.setData({
            SHOW_TOP: !0
        });
    },
    toSetting: function() {
        this.setData({
            showSetting: !0
        });
    },
    closeSetting: function() {
        this.setData({
            showSetting: !1
        });
    },
    toZs: function() {
        wx.navigateTo({
            url: "/pages/webview/webview?url=".concat(encodeURIComponent("https://mp.weixin.qq.com/s/crtWaRZGrSh_DUOT9T48Dw"))
        });
    },
    onLoad: function(t) {
        this.getUserInfo();
    },
    copyMyId: function() {
        wx.setClipboardData({
            data: getApp().globalData.userInfo.id,
            success: function(t) {
                wx.showToast({
                    title: "id已复制"
                });
            }
        }), i.addEvent({
            id: "user",
            type: "复制id"
        });
    },
    onReady: function() {},
    onShow: function() {
        this.getUserInfo();
    },
    onHide: function() {},
    onUnload: function() {},
    onPullDownRefresh: function() {},
    onReachBottom: function() {},
    export: function() {
        wx.showModal({
            title: "提醒",
            content: "导出属于会员专属功能，您需要观看广告才可使用",
            confirmText: "去使用",
            cancelText: "不用啦",
            success: function() {
                n && n.show().catch(function() {
                    n.load().then(function() {
                        return n.show(function(t) {
                            console.log("激励广告看完了？", t);
                        });
                    }).catch(function(t) {
                        console.log("激励视频 广告显示失败");
                    });
                });
            }
        });
    },
    onShareAppMessage: function() {
        return {
            title: "快来用全能小转盘！",
            path: "/pages/index/index",
            imageUrl: "http://pan00.jialidun.vip/zp/zplogo.jpeg",
            success: function(t) {
                wx.showToast({
                    title: "分享成功！"
                });
            }
        };
    }
});