$gwx_XC_35=function(_,_v,_n,_p,_s,_wp,_wl,$gwn,$gwl,$gwh,wh,$gstack,$gwrt,gra,grb,TestTest,wfor,_ca,_da,_r,_rz,_o,_oz,_1,_1z,_2,_2z,_m,_mz,nv_getDate,nv_getRegExp,nv_console,nv_parseInt,nv_parseFloat,nv_isNaN,nv_isFinite,nv_decodeURI,nv_decodeURIComponent,nv_encodeURI,nv_encodeURIComponent,$gdc,nv_JSON,_af,_gv,_ai,_grp,_gd,_gapi,$ixc,_ic,_w,_ev,_tsd){return function(path,global){
if(typeof global==='undefined'){if (typeof __GWX_GLOBAL__==='undefined')global={};else global=__GWX_GLOBAL__;}if(typeof __WXML_GLOBAL__ === 'undefined') {__WXML_GLOBAL__={};
}__WXML_GLOBAL__.modules = __WXML_GLOBAL__.modules || {};
var e_={}
if(typeof(global.entrys)==='undefined')global.entrys={};e_=global.entrys;
var d_={}
if(typeof(global.defines)==='undefined')global.defines={};d_=global.defines;
var f_={}
if(typeof(global.modules)==='undefined')global.modules={};f_=global.modules || {};
var p_={}
__WXML_GLOBAL__.ops_cached = __WXML_GLOBAL__.ops_cached || {}
__WXML_GLOBAL__.ops_set = __WXML_GLOBAL__.ops_set || {};
__WXML_GLOBAL__.ops_init = __WXML_GLOBAL__.ops_init || {};
var z=__WXML_GLOBAL__.ops_set.$gwx_XC_35 || [];
function gz$gwx_XC_35_1(){
if( __WXML_GLOBAL__.ops_cached.$gwx_XC_35_1)return __WXML_GLOBAL__.ops_cached.$gwx_XC_35_1
__WXML_GLOBAL__.ops_cached.$gwx_XC_35_1=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
Z([3,'container'])
Z([3,'toUserInfo'])
Z([3,'user-info'])
Z([3,'avatar-wrapper'])
Z([3,'avatar'])
Z([3,'aspectFill'])
Z([[2,'?:'],[[6],[[7],[3,'userInfo']],[3,'wx_avatar']],[[2,'+'],[[2,'+'],[1,'http://pan.jialidun.vip/'],[[6],[[7],[3,'userInfo']],[3,'wx_avatar']]],[1,'?imageMogr2/thumbnail/150x']],[1,'https://mmbiz.qpic.cn/mmbiz/icTdbqWNOwNRna42FI242Lcia07jQodd2FJGIYQfG0LAJGFxM4FbnQP6yfMxBgJ0F3YRqJCJ1aPAK2dQagdusBZg/0']])
Z([3,'user-name mt2 mb4'])
Z([a,[[2,'||'],[[6],[[7],[3,'userInfo']],[3,'wx_name']],[1,'没名字用户']]])
Z([3,'btn-container'])
Z([3,'showTop'])
Z([3,'item flex-space-between flex-align-center'])
Z([3,'flex'])
Z([3,'like-o'])
Z([3,'32rpx'])
Z([3,'text'])
Z([3,'添加到我的小程序'])
Z([3,'#ccc'])
Z([3,'arrow'])
Z(z[14])
Z([3,'btn-container mt3'])
Z([3,'item flex-space-between'])
Z([3,'share'])
Z(z[12])
Z([3,'sjzp-fenxiang'])
Z(z[14])
Z(z[15])
Z([3,'分享给朋友'])
Z(z[17])
Z(z[18])
Z(z[14])
Z([3,'line'])
Z(z[21])
Z([3,'feedback'])
Z(z[12])
Z([3,'envelop-o'])
Z(z[14])
Z(z[15])
Z([3,'反馈问题'])
Z(z[17])
Z(z[18])
Z(z[14])
Z(z[31])
Z(z[21])
Z([3,'contact'])
Z(z[12])
Z([3,'service-o'])
Z(z[14])
Z(z[15])
Z([3,'联系客服'])
Z(z[17])
Z(z[18])
Z(z[14])
Z(z[20])
Z([3,'toZs'])
Z(z[21])
Z(z[12])
Z([3,'flower-o'])
Z(z[14])
Z(z[15])
Z([3,'关注公众号'])
Z(z[17])
Z(z[18])
Z(z[14])
Z([1,false])
Z([3,'font-size:20rpx'])
Z([a,[3,' '],[[6],[[7],[3,'userInfo']],[3,'id']],[3,' ']])
Z(z[64])
Z([3,'ad_container'])
Z([1,30])
Z([3,'adunit-45cd853843569a7e'])
Z([[7],[3,'SHOW_TOP']])
Z([3,'box'])
Z([3,'add-tips'])
Z([3,'top:0px;right:10rpx'])
Z(z[18])
Z([3,'hideTop'])
Z([3,'body'])
Z([3,'tips'])
Z([3,'添加到我的小程序,下次打开更方便'])
Z([3,'closeSetting'])
Z([[7],[3,'showSetting']])
})(__WXML_GLOBAL__.ops_cached.$gwx_XC_35_1);return __WXML_GLOBAL__.ops_cached.$gwx_XC_35_1
}
__WXML_GLOBAL__.ops_set.$gwx_XC_35=z;
__WXML_GLOBAL__.ops_init.$gwx_XC_35=true;
var x=['./pages/mine/index.wxml'];d_[x[0]]={}
var m0=function(e,s,r,gg){
var z=gz$gwx_XC_35_1()
var a6P=_n('view')
_rz(z,a6P,'class',0,e,s,gg)
var e8P=_mz(z,'view',['bind:tap',1,'class',1],[],e,s,gg)
var b9P=_n('view')
_rz(z,b9P,'class',3,e,s,gg)
var o0P=_mz(z,'image',['class',4,'mode',1,'src',2],[],e,s,gg)
_(b9P,o0P)
_(e8P,b9P)
var xAQ=_n('view')
_rz(z,xAQ,'class',7,e,s,gg)
var oBQ=_oz(z,8,e,s,gg)
_(xAQ,oBQ)
_(e8P,xAQ)
_(a6P,e8P)
var fCQ=_n('view')
_rz(z,fCQ,'class',9,e,s,gg)
var cDQ=_mz(z,'button',['bind:tap',10,'class',1],[],e,s,gg)
var hEQ=_n('view')
_rz(z,hEQ,'class',12,e,s,gg)
var oFQ=_mz(z,'van-icon',['name',13,'size',1],[],e,s,gg)
_(hEQ,oFQ)
var cGQ=_n('text')
_rz(z,cGQ,'class',15,e,s,gg)
var oHQ=_oz(z,16,e,s,gg)
_(cGQ,oHQ)
_(hEQ,cGQ)
_(cDQ,hEQ)
var lIQ=_mz(z,'van-icon',['color',17,'name',1,'size',2],[],e,s,gg)
_(cDQ,lIQ)
_(fCQ,cDQ)
_(a6P,fCQ)
var aJQ=_n('view')
_rz(z,aJQ,'class',20,e,s,gg)
var tKQ=_mz(z,'button',['class',21,'openType',1],[],e,s,gg)
var eLQ=_n('view')
_rz(z,eLQ,'class',23,e,s,gg)
var bMQ=_mz(z,'van-icon',['name',24,'size',1],[],e,s,gg)
_(eLQ,bMQ)
var oNQ=_n('text')
_rz(z,oNQ,'class',26,e,s,gg)
var xOQ=_oz(z,27,e,s,gg)
_(oNQ,xOQ)
_(eLQ,oNQ)
_(tKQ,eLQ)
var oPQ=_mz(z,'van-icon',['color',28,'name',1,'size',2],[],e,s,gg)
_(tKQ,oPQ)
_(aJQ,tKQ)
var fQQ=_n('view')
_rz(z,fQQ,'class',31,e,s,gg)
_(aJQ,fQQ)
var cRQ=_mz(z,'button',['class',32,'openType',1],[],e,s,gg)
var hSQ=_n('view')
_rz(z,hSQ,'class',34,e,s,gg)
var oTQ=_mz(z,'van-icon',['name',35,'size',1],[],e,s,gg)
_(hSQ,oTQ)
var cUQ=_n('text')
_rz(z,cUQ,'class',37,e,s,gg)
var oVQ=_oz(z,38,e,s,gg)
_(cUQ,oVQ)
_(hSQ,cUQ)
_(cRQ,hSQ)
var lWQ=_mz(z,'van-icon',['color',39,'name',1,'size',2],[],e,s,gg)
_(cRQ,lWQ)
_(aJQ,cRQ)
var aXQ=_n('view')
_rz(z,aXQ,'class',42,e,s,gg)
_(aJQ,aXQ)
var tYQ=_mz(z,'button',['class',43,'openType',1],[],e,s,gg)
var eZQ=_n('view')
_rz(z,eZQ,'class',45,e,s,gg)
var b1Q=_mz(z,'van-icon',['name',46,'size',1],[],e,s,gg)
_(eZQ,b1Q)
var o2Q=_n('text')
_rz(z,o2Q,'class',48,e,s,gg)
var x3Q=_oz(z,49,e,s,gg)
_(o2Q,x3Q)
_(eZQ,o2Q)
_(tYQ,eZQ)
var o4Q=_mz(z,'van-icon',['color',50,'name',1,'size',2],[],e,s,gg)
_(tYQ,o4Q)
_(aJQ,tYQ)
_(a6P,aJQ)
var f5Q=_n('view')
_rz(z,f5Q,'class',53,e,s,gg)
var c6Q=_mz(z,'button',['bindtap',54,'class',1],[],e,s,gg)
var h7Q=_n('view')
_rz(z,h7Q,'class',56,e,s,gg)
var o8Q=_mz(z,'van-icon',['name',57,'size',1],[],e,s,gg)
_(h7Q,o8Q)
var c9Q=_n('text')
_rz(z,c9Q,'class',59,e,s,gg)
var o0Q=_oz(z,60,e,s,gg)
_(c9Q,o0Q)
_(h7Q,c9Q)
_(c6Q,h7Q)
var lAR=_mz(z,'van-icon',['color',61,'name',1,'size',2],[],e,s,gg)
_(c6Q,lAR)
_(f5Q,c6Q)
_(a6P,f5Q)
var t7P=_v()
_(a6P,t7P)
if(_oz(z,64,e,s,gg)){t7P.wxVkey=1
var aBR=_n('view')
_rz(z,aBR,'style',65,e,s,gg)
var tCR=_oz(z,66,e,s,gg)
_(aBR,tCR)
_(t7P,aBR)
}
t7P.wxXCkey=1
_(r,a6P)
var o4P=_v()
_(r,o4P)
if(_oz(z,67,e,s,gg)){o4P.wxVkey=1
var eDR=_n('view')
_rz(z,eDR,'class',68,e,s,gg)
var bER=_mz(z,'ad-custom',['adIntervals',69,'unitId',1],[],e,s,gg)
_(eDR,bER)
_(o4P,eDR)
}
var l5P=_v()
_(r,l5P)
if(_oz(z,71,e,s,gg)){l5P.wxVkey=1
var oFR=_mz(z,'view',['class',72,'id',1,'style',2],[],e,s,gg)
var xGR=_n('view')
_rz(z,xGR,'class',75,e,s,gg)
_(oFR,xGR)
var oHR=_mz(z,'view',['bindtap',76,'class',1],[],e,s,gg)
var fIR=_n('view')
_rz(z,fIR,'class',78,e,s,gg)
var cJR=_oz(z,79,e,s,gg)
_(fIR,cJR)
_(oHR,fIR)
_(oFR,oHR)
_(l5P,oFR)
}
var hKR=_mz(z,'setting',['bind:closeSetting',80,'showSetting',1],[],e,s,gg)
_(r,hKR)
o4P.wxXCkey=1
l5P.wxXCkey=1
return r
}
e_[x[0]]={f:m0,j:[],i:[],ti:[],ic:[]}
if(path&&e_[path]){
outerGlobal.__wxml_comp_version__=0.02
return function(env,dd,global){$gwxc=0;var root={"tag":"wx-page"};root.children=[]
;g="$gwx_XC_35";var main=e_[path].f
if (typeof global==="undefined")global={};global.f=$gdc(f_[path],"",1);
if(typeof(outerGlobal.__webview_engine_version__)!='undefined'&&outerGlobal.__webview_engine_version__+1e-6>=0.02+1e-6&&outerGlobal.__mergeData__)
{
env=outerGlobal.__mergeData__(env,dd);
}
try{
main(env,{},root,global);
_tsd(root)
if(typeof(outerGlobal.__webview_engine_version__)=='undefined'|| outerGlobal.__webview_engine_version__+1e-6<0.01+1e-6){return _ev(root);}
}catch(err){
console.log(err)
}
;g="";
return root;
}
}
}
}(__g.a,__g.b,__g.c,__g.d,__g.e,__g.f,__g.g,__g.h,__g.i,__g.j,__g.k,__g.l,__g.m,__g.n,__g.o,__g.p,__g.q,__g.r,__g.s,__g.t,__g.u,__g.v,__g.w,__g.x,__g.y,__g.z,__g.A,__g.B,__g.C,__g.D,__g.E,__g.F,__g.G,__g.H,__g.I,__g.J,__g.K,__g.L,__g.M,__g.N,__g.O,__g.P,__g.Q,__g.R,__g.S,__g.T,__g.U,__g.V,__g.W,__g.X,__g.Y,__g.Z,__g.aa);if(__vd_version_info__.delayedGwx||false)$gwx_XC_35();	if (__vd_version_info__.delayedGwx) __wxAppCode__['pages/mine/index.wxml'] = [$gwx_XC_35, './pages/mine/index.wxml'];else __wxAppCode__['pages/mine/index.wxml'] = $gwx_XC_35( './pages/mine/index.wxml' );
	
var noCss=typeof __vd_version_info__!=='undefined'&&__vd_version_info__.noCss===true;if(!noCss){__wxAppCode__['pages/mine/index.wxss'] = setCssToHead(["body{background:#f6f7f8;color:#333}\n.",[1],"container{display:-webkit-flex;display:flex;-webkit-flex-direction:column;flex-direction:column;margin-top:",[0,20],";padding:",[0,32],"}\nwx-button{color:#333}\n.",[1],"btn-container{background:#fff;border-radius:",[0,32],";padding:",[0,10],"}\n.",[1],"line{background:#f5f6f7;height:",[0,1],";margin:auto;width:",[0,580],"}\n.",[1],"item{background:transparent;border:none;box-shadow:none;outline:none}\n.",[1],"item .",[1],"text{margin-left:",[0,20],"}\n.",[1],"item:after{border:none;clear:both;content:\x22\x22;display:block}\n.",[1],"box{-webkit-align-items:flex-end;align-items:flex-end;background-color:rgba(0,0,0,.75);border-radius:",[0,32],";color:#fff;display:-webkit-flex;display:flex;-webkit-flex-direction:column;flex-direction:column;margin-top:",[0,12],";padding:",[0,32],";position:fixed;right:",[0,10],";z-index:999}\n.",[1],"arrow{border:",[0,12]," solid transparent;border-bottom-color:rgba(0,0,0,.75);height:0;position:absolute;right:",[0,125],";top:",[0,-20],";width:0}\n.",[1],"ad_container{background:#fff;border-radius:",[0,32]," ",[0,32]," 0 0;bottom:",[0,18],";-webkit-justify-content:center;justify-content:center;margin-top:",[0,40],";padding:",[0,28]," 0 0;position:absolute;width:100%}\n.",[1],"ad_container,.",[1],"user-info{-webkit-align-items:center;align-items:center;display:-webkit-flex;display:flex}\n.",[1],"user-info{-webkit-flex-direction:column;flex-direction:column;margin-bottom:",[0,20],"}\n.",[1],"avatar{border-radius:50%;box-sizing:border-box;height:66px;overflow:hidden;width:66px}\n.",[1],"avatar-wrapper{background:transparent;border-radius:50%!important;box-sizing:border-box;height:66px!important;padding:0;width:66px!important}\n.",[1],"user-name{color:#333;font-size:",[0,28],";margin-top:",[0,10],"}\n",],"Some selectors are not allowed in component wxss, including tag name selectors, ID selectors, and attribute selectors.(./pages/mine/index.wxss:1:164)",{path:"./pages/mine/index.wxss"});
}