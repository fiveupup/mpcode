$gwx_XC_35=function(_,_v,_n,_p,_s,_wp,_wl,$gwn,$gwl,$gwh,wh,$gstack,$gwrt,gra,grb,TestTest,wfor,_ca,_da,_r,_rz,_o,_oz,_1,_1z,_2,_2z,_m,_mz,nv_getDate,nv_getRegExp,nv_console,nv_parseInt,nv_parseFloat,nv_isNaN,nv_isFinite,nv_decodeURI,nv_decodeURIComponent,nv_encodeURI,nv_encodeURIComponent,$gdc,nv_JSON,_af,_gv,_ai,_grp,_gd,_gapi,$ixc,_ic,_w,_ev,_tsd){return function(path,global){
if(typeof global==='undefined'){if (typeof __GWX_GLOBAL__==='undefined')global={};else global=__GWX_GLOBAL__;}if(typeof __WXML_GLOBAL__ === 'undefined') {__WXML_GLOBAL__={};
}__WXML_GLOBAL__.modules = __WXML_GLOBAL__.modules || {};
var e_={}
if(typeof(global.entrys)==='undefined')global.entrys={};e_=global.entrys;
var d_={}
if(typeof(global.defines)==='undefined')global.defines={};d_=global.defines;
var f_={}
if(typeof(global.modules)==='undefined')global.modules={};f_=global.modules || {};
var p_={}
__WXML_GLOBAL__.ops_cached = __WXML_GLOBAL__.ops_cached || {}
__WXML_GLOBAL__.ops_set = __WXML_GLOBAL__.ops_set || {};
__WXML_GLOBAL__.ops_init = __WXML_GLOBAL__.ops_init || {};
var z=__WXML_GLOBAL__.ops_set.$gwx_XC_35 || [];
function gz$gwx_XC_35_1(){
if( __WXML_GLOBAL__.ops_cached.$gwx_XC_35_1)return __WXML_GLOBAL__.ops_cached.$gwx_XC_35_1
__WXML_GLOBAL__.ops_cached.$gwx_XC_35_1=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
Z([3,'container'])
Z([3,'showTop'])
Z([3,'item flex-space-between flex-align-center'])
Z([3,'like-o'])
Z([3,'32rpx'])
Z([3,'#ccc'])
Z([3,'arrow'])
Z(z[4])
Z([3,'btn-container mt3'])
Z([3,'item flex-space-between'])
Z([3,'share'])
Z([3,'sjzp-fenxiang'])
Z(z[4])
Z(z[5])
Z(z[6])
Z(z[4])
Z(z[9])
Z([3,'feedback'])
Z([3,'envelop-o'])
Z(z[4])
Z(z[5])
Z(z[6])
Z(z[4])
Z(z[9])
Z([3,'contact'])
Z([3,'service-o'])
Z(z[4])
Z(z[5])
Z(z[6])
Z(z[4])
Z([3,'toZs'])
Z(z[9])
Z([3,'flower-o'])
Z(z[4])
Z(z[5])
Z(z[6])
Z(z[4])
Z([1,false])
Z(z[37])
Z([[7],[3,'SHOW_TOP']])
Z([3,'closeSetting'])
Z([[7],[3,'showSetting']])
})(__WXML_GLOBAL__.ops_cached.$gwx_XC_35_1);return __WXML_GLOBAL__.ops_cached.$gwx_XC_35_1
}
__WXML_GLOBAL__.ops_set.$gwx_XC_35=z;
__WXML_GLOBAL__.ops_init.$gwx_XC_35=true;
var x=['./pages/mine/index.wxml'];d_[x[0]]={}
var m0=function(e,s,r,gg){
var z=gz$gwx_XC_35_1()
var o2I=_n('view')
_rz(z,o2I,'class',0,e,s,gg)
var o4I=_mz(z,'button',['bind:tap',1,'class',1],[],e,s,gg)
var l5I=_mz(z,'van-icon',['name',3,'size',1],[],e,s,gg)
_(o4I,l5I)
var a6I=_mz(z,'van-icon',['color',5,'name',1,'size',2],[],e,s,gg)
_(o4I,a6I)
_(o2I,o4I)
var t7I=_n('view')
_rz(z,t7I,'class',8,e,s,gg)
var e8I=_mz(z,'button',['class',9,'openType',1],[],e,s,gg)
var b9I=_mz(z,'van-icon',['name',11,'size',1],[],e,s,gg)
_(e8I,b9I)
var o0I=_mz(z,'van-icon',['color',13,'name',1,'size',2],[],e,s,gg)
_(e8I,o0I)
_(t7I,e8I)
var xAJ=_mz(z,'button',['class',16,'openType',1],[],e,s,gg)
var oBJ=_mz(z,'van-icon',['name',18,'size',1],[],e,s,gg)
_(xAJ,oBJ)
var fCJ=_mz(z,'van-icon',['color',20,'name',1,'size',2],[],e,s,gg)
_(xAJ,fCJ)
_(t7I,xAJ)
var cDJ=_mz(z,'button',['class',23,'openType',1],[],e,s,gg)
var hEJ=_mz(z,'van-icon',['name',25,'size',1],[],e,s,gg)
_(cDJ,hEJ)
var oFJ=_mz(z,'van-icon',['color',27,'name',1,'size',2],[],e,s,gg)
_(cDJ,oFJ)
_(t7I,cDJ)
_(o2I,t7I)
var cGJ=_mz(z,'button',['bindtap',30,'class',1],[],e,s,gg)
var oHJ=_mz(z,'van-icon',['name',32,'size',1],[],e,s,gg)
_(cGJ,oHJ)
var lIJ=_mz(z,'van-icon',['color',34,'name',1,'size',2],[],e,s,gg)
_(cGJ,lIJ)
_(o2I,cGJ)
var c3I=_v()
_(o2I,c3I)
if(_oz(z,37,e,s,gg)){c3I.wxVkey=1
}
c3I.wxXCkey=1
_(r,o2I)
var cZI=_v()
_(r,cZI)
if(_oz(z,38,e,s,gg)){cZI.wxVkey=1
}
var h1I=_v()
_(r,h1I)
if(_oz(z,39,e,s,gg)){h1I.wxVkey=1
}
var aJJ=_mz(z,'setting',['bind:closeSetting',40,'showSetting',1],[],e,s,gg)
_(r,aJJ)
cZI.wxXCkey=1
h1I.wxXCkey=1
return r
}
e_[x[0]]={f:m0,j:[],i:[],ti:[],ic:[]}
if(path&&e_[path]){
return function(env,dd,global){$gwxc=0;var root={"tag":"wx-page"};root.children=[]
;g="$gwx_XC_35";var main=e_[path].f
if (typeof global==="undefined")global={};global.f=$gdc(f_[path],"",1);
try{
main(env,{},root,global);
_tsd(root)
}catch(err){
console.log(err)
}
;g="";
return root;
}
}
}
}(__g.a,__g.b,__g.c,__g.d,__g.e,__g.f,__g.g,__g.h,__g.i,__g.j,__g.k,__g.l,__g.m,__g.n,__g.o,__g.p,__g.q,__g.r,__g.s,__g.t,__g.u,__g.v,__g.w,__g.x,__g.y,__g.z,__g.A,__g.B,__g.C,__g.D,__g.E,__g.F,__g.G,__g.H,__g.I,__g.J,__g.K,__g.L,__g.M,__g.N,__g.O,__g.P,__g.Q,__g.R,__g.S,__g.T,__g.U,__g.V,__g.W,__g.X,__g.Y,__g.Z,__g.aa);if(__vd_version_info__.delayedGwx||false)$gwx_XC_35();	if (__vd_version_info__.delayedGwx) __wxAppCode__['pages/mine/index.wxml'] = [$gwx_XC_35, './pages/mine/index.wxml'];else __wxAppCode__['pages/mine/index.wxml'] = $gwx_XC_35( './pages/mine/index.wxml' );
	;__wxRoute = "pages/mine/index";__wxRouteBegin = true;__wxAppCurrentFile__="pages/mine/index.js";define("pages/mine/index.js",function(require,module,exports,window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){
"use strict";var t=require("../../@babel/runtime/helpers/interopRequireDefault")(require("../../@babel/runtime/regenerator")),e=require("../../@babel/runtime/helpers/asyncToGenerator"),n=null,o=require("../../E36C2C77415216BF850A44701BF6EA57.js"),i=(o.getUploadToken,o.updateAvatar,getApp());Page({data:{SHOW_TOP:!1,showSetting:!1,userInfo:{}},toUserInfo:function(){wx.navigateTo({url:"/p3/user-info/user-info"})},getUserInfo:function(n){var o=this;return e(t.default.mark((function e(){var n;return t.default.wrap((function(t){for(;;)switch(t.prev=t.next){case 0:return t.next=2,i.getUser();case 2:n=t.sent,o.setData({userInfo:n});case 4:case"end":return t.stop()}}),e)})))()},hideTop:function(){this.setData({SHOW_TOP:!1})},showTop:function(){this.setData({SHOW_TOP:!0})},toSetting:function(){this.setData({showSetting:!0})},closeSetting:function(){this.setData({showSetting:!1})},toZs:function(){wx.navigateTo({url:"/pages/webview/webview?url=".concat(encodeURIComponent("https://mp.weixin.qq.com/s/crtWaRZGrSh_DUOT9T48Dw"))})},onLoad:function(t){this.getUserInfo()},copyMyId:function(){wx.setClipboardData({data:getApp().globalData.userInfo.id,success:function(t){wx.showToast({title:"id已复制"})}}),i.addEvent({id:"user",type:"复制id"})},onReady:function(){},onShow:function(){this.getUserInfo()},onHide:function(){},onUnload:function(){},onPullDownRefresh:function(){},onReachBottom:function(){},export:function(){wx.showModal({title:"提醒",content:"导出属于会员专属功能，您需要观看广告才可使用",confirmText:"去使用",cancelText:"不用啦",success:function(){n&&n.show().catch((function(){n.load().then((function(){return n.show((function(t){console.log("激励广告看完了？",t)}))})).catch((function(t){console.log("激励视频 广告显示失败")}))}))}})},onShareAppMessage:function(){return{title:"快来用全能小转盘！",path:"/pages/index/index",imageUrl:"http://pan00.jialidun.vip/zp/zplogo.jpeg",success:function(t){wx.showToast({title:"分享成功！"})}}}});
},{isPage:true,isComponent:true,currentFile:'pages/mine/index.js'});require("pages/mine/index.js");