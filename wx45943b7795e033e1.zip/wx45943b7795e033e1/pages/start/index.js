var e, t = require("../../@babel/runtime/helpers/interopRequireDefault")(require("../../@babel/runtime/regenerator")), n = require("../../@babel/runtime/helpers/asyncToGenerator"), r = require("../../72CE30E5415216BF14A858E26129EA57.js"), s = r.login, a = r.getUser, o = r.signUp, i = getApp();

Page({
    data: {},
    relaunch: function() {
        wx.reLaunch({
            url: "/pages/start/index"
        });
    },
    onLoad: (e = n(t.default.mark(function e() {
        return t.default.wrap(function(e) {
            for (;;) switch (e.prev = e.next) {
              case 0:
                return e.prev = 0, wx.showLoading({
                    title: "加载中.."
                }), e.next = 4, s();

              case 4:
                return e.next = 6, this.getUserInfo();

              case 6:
                wx.hideLoading(), e.next = 13;
                break;

              case 9:
                e.prev = 9, e.t0 = e.catch(0), console.error(e.t0), i.addEvent({
                    id: "login",
                    type: "onLoad异常",
                    status: "error",
                    message: e.t0
                });

              case 13:
              case "end":
                return e.stop();
            }
        }, e, this, [ [ 0, 9 ] ]);
    })), function() {
        return e.apply(this, arguments);
    }),
    getUserInfo: function() {
        var e = this;
        return n(t.default.mark(function n() {
            var r;
            return t.default.wrap(function(t) {
                for (;;) switch (t.prev = t.next) {
                  case 0:
                    return t.next = 2, a();

                  case 2:
                    if (4031 !== (r = t.sent).code) {
                        t.next = 9;
                        break;
                    }
                    return i.addEvent({
                        id: "login",
                        type: "getUser",
                        status: "error",
                        msg: "用户未注册"
                    }), t.next = 7, e.signUp();

                  case 7:
                    t.next = 10;
                    break;

                  case 9:
                    0 === r.code ? (i.addEvent({
                        id: "login",
                        type: "getUser",
                        status: "success",
                        msg: ""
                    }), console.log("获取到用户信息了", r), i.globalData.userInfo = r.data, wx.switchTab({
                        url: "/pages/index/index"
                    })) : (i.addEvent({
                        id: "login",
                        type: "getUser",
                        status: "error",
                        msg: r
                    }), wx.showModal({
                        title: "提示",
                        content: "拉取数据出错了，请检查网络并重试",
                        showCancel: !1,
                        confirmText: "重试",
                        success: function() {
                            wx.showLoading({
                                title: "加载中.."
                            }), e.getUserInfo();
                        }
                    }));

                  case 10:
                  case "end":
                    return t.stop();
                }
            }, n);
        }))();
    },
    signUp: function() {
        var e = this;
        return n(t.default.mark(function n() {
            var r, s, a, c, u, d, l, g;
            return t.default.wrap(function(t) {
                for (;;) switch (t.prev = t.next) {
                  case 0:
                    return r = wx.getSystemInfoSync(), s = r.brand, a = r.system, c = r.platform, u = r.version, 
                    d = r.model, l = {
                        scene: i.globalData.scene,
                        sub_c: i.globalData.sub_c,
                        top_c: i.globalData.top_c,
                        brand: s,
                        system: a,
                        platform: c,
                        model: d,
                        version: u
                    }, t.next = 4, o(l);

                  case 4:
                    0 == (g = t.sent).code ? (i.addEvent({
                        id: "login",
                        type: "新用户注册",
                        status: "success",
                        msg: ""
                    }), i.globalData.userInfo = g.data, wx.switchTab({
                        url: "/pages/index/index"
                    })) : (wx.showModal({
                        title: "提示",
                        content: "进入失败，请检查网络并重试",
                        showCancel: !1,
                        confirmText: "重试",
                        success: function() {
                            wx.showLoading({
                                title: "加载中.."
                            }), e.signUp();
                        }
                    }), i.addEvent({
                        id: "login",
                        type: "新用户注册",
                        status: "error",
                        msg: g
                    }));

                  case 6:
                  case "end":
                    return t.stop();
                }
            }, n);
        }))();
    },
    onReady: function() {},
    onShow: function() {},
    onHide: function() {},
    onUnload: function() {},
    onPullDownRefresh: function() {},
    onReachBottom: function() {},
    onShareAppMessage: function() {}
});