$gwx_XC_37=function(_,_v,_n,_p,_s,_wp,_wl,$gwn,$gwl,$gwh,wh,$gstack,$gwrt,gra,grb,TestTest,wfor,_ca,_da,_r,_rz,_o,_oz,_1,_1z,_2,_2z,_m,_mz,nv_getDate,nv_getRegExp,nv_console,nv_parseInt,nv_parseFloat,nv_isNaN,nv_isFinite,nv_decodeURI,nv_decodeURIComponent,nv_encodeURI,nv_encodeURIComponent,$gdc,nv_JSON,_af,_gv,_ai,_grp,_gd,_gapi,$ixc,_ic,_w,_ev,_tsd){return function(path,global){
if(typeof global==='undefined'){if (typeof __GWX_GLOBAL__==='undefined')global={};else global=__GWX_GLOBAL__;}if(typeof __WXML_GLOBAL__ === 'undefined') {__WXML_GLOBAL__={};
}__WXML_GLOBAL__.modules = __WXML_GLOBAL__.modules || {};
var e_={}
if(typeof(global.entrys)==='undefined')global.entrys={};e_=global.entrys;
var d_={}
if(typeof(global.defines)==='undefined')global.defines={};d_=global.defines;
var f_={}
if(typeof(global.modules)==='undefined')global.modules={};f_=global.modules || {};
var p_={}
__WXML_GLOBAL__.ops_cached = __WXML_GLOBAL__.ops_cached || {}
__WXML_GLOBAL__.ops_set = __WXML_GLOBAL__.ops_set || {};
__WXML_GLOBAL__.ops_init = __WXML_GLOBAL__.ops_init || {};
var z=__WXML_GLOBAL__.ops_set.$gwx_XC_37 || [];
function gz$gwx_XC_37_1(){
if( __WXML_GLOBAL__.ops_cached.$gwx_XC_37_1)return __WXML_GLOBAL__.ops_cached.$gwx_XC_37_1
__WXML_GLOBAL__.ops_cached.$gwx_XC_37_1=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
})(__WXML_GLOBAL__.ops_cached.$gwx_XC_37_1);return __WXML_GLOBAL__.ops_cached.$gwx_XC_37_1
}
__WXML_GLOBAL__.ops_set.$gwx_XC_37=z;
__WXML_GLOBAL__.ops_init.$gwx_XC_37=true;
var x=['./pages/start/index.wxml'];d_[x[0]]={}
var m0=function(e,s,r,gg){
var z=gz$gwx_XC_37_1()
return r
}
e_[x[0]]={f:m0,j:[],i:[],ti:[],ic:[]}
if(path&&e_[path]){
return function(env,dd,global){$gwxc=0;var root={"tag":"wx-page"};root.children=[]
;g="$gwx_XC_37";var main=e_[path].f
if (typeof global==="undefined")global={};global.f=$gdc(f_[path],"",1);
try{
main(env,{},root,global);
_tsd(root)
}catch(err){
console.log(err)
}
;g="";
return root;
}
}
}
}(__g.a,__g.b,__g.c,__g.d,__g.e,__g.f,__g.g,__g.h,__g.i,__g.j,__g.k,__g.l,__g.m,__g.n,__g.o,__g.p,__g.q,__g.r,__g.s,__g.t,__g.u,__g.v,__g.w,__g.x,__g.y,__g.z,__g.A,__g.B,__g.C,__g.D,__g.E,__g.F,__g.G,__g.H,__g.I,__g.J,__g.K,__g.L,__g.M,__g.N,__g.O,__g.P,__g.Q,__g.R,__g.S,__g.T,__g.U,__g.V,__g.W,__g.X,__g.Y,__g.Z,__g.aa);if(__vd_version_info__.delayedGwx||false)$gwx_XC_37();	if (__vd_version_info__.delayedGwx) __wxAppCode__['pages/start/index.wxml'] = [$gwx_XC_37, './pages/start/index.wxml'];else __wxAppCode__['pages/start/index.wxml'] = $gwx_XC_37( './pages/start/index.wxml' );
	;__wxRoute = "pages/start/index";__wxRouteBegin = true;__wxAppCurrentFile__="pages/start/index.js";define("pages/start/index.js",function(require,module,exports,window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){
"use strict";var e,t=require("../../@babel/runtime/helpers/interopRequireDefault")(require("../../@babel/runtime/regenerator")),n=require("../../@babel/runtime/helpers/asyncToGenerator"),r=require("../../72CE30E5415216BF14A858E26129EA57.js"),s=r.login,a=r.getUser,o=r.signUp,i=getApp();Page({data:{},relaunch:function(){wx.reLaunch({url:"/pages/start/index"})},onLoad:(e=n(t.default.mark((function e(){return t.default.wrap((function(e){for(;;)switch(e.prev=e.next){case 0:return e.prev=0,wx.showLoading({title:"加载中.."}),e.next=4,s();case 4:return e.next=6,this.getUserInfo();case 6:wx.hideLoading(),e.next=13;break;case 9:e.prev=9,e.t0=e.catch(0),console.error(e.t0),i.addEvent({id:"login",type:"onLoad异常",status:"error",message:e.t0});case 13:case"end":return e.stop()}}),e,this,[[0,9]])}))),function(){return e.apply(this,arguments)}),getUserInfo:function(){var e=this;return n(t.default.mark((function n(){var r;return t.default.wrap((function(t){for(;;)switch(t.prev=t.next){case 0:return t.next=2,a();case 2:if(4031!==(r=t.sent).code){t.next=9;break}return i.addEvent({id:"login",type:"getUser",status:"error",msg:"用户未注册"}),t.next=7,e.signUp();case 7:t.next=10;break;case 9:0===r.code?(i.addEvent({id:"login",type:"getUser",status:"success",msg:""}),console.log("获取到用户信息了",r),i.globalData.userInfo=r.data,wx.switchTab({url:"/pages/index/index"})):(i.addEvent({id:"login",type:"getUser",status:"error",msg:r}),wx.showModal({title:"提示",content:"拉取数据出错了，请检查网络并重试",showCancel:!1,confirmText:"重试",success:function(){wx.showLoading({title:"加载中.."}),e.getUserInfo()}}));case 10:case"end":return t.stop()}}),n)})))()},signUp:function(){var e=this;return n(t.default.mark((function n(){var r,s,a,c,u,d,l,g;return t.default.wrap((function(t){for(;;)switch(t.prev=t.next){case 0:return r=wx.getSystemInfoSync(),s=r.brand,a=r.system,c=r.platform,u=r.version,d=r.model,l={scene:i.globalData.scene,sub_c:i.globalData.sub_c,top_c:i.globalData.top_c,brand:s,system:a,platform:c,model:d,version:u},t.next=4,o(l);case 4:0==(g=t.sent).code?(i.addEvent({id:"login",type:"新用户注册",status:"success",msg:""}),i.globalData.userInfo=g.data,wx.switchTab({url:"/pages/index/index"})):(wx.showModal({title:"提示",content:"进入失败，请检查网络并重试",showCancel:!1,confirmText:"重试",success:function(){wx.showLoading({title:"加载中.."}),e.signUp()}}),i.addEvent({id:"login",type:"新用户注册",status:"error",msg:g}));case 6:case"end":return t.stop()}}),n)})))()},onReady:function(){},onShow:function(){},onHide:function(){},onUnload:function(){},onPullDownRefresh:function(){},onReachBottom:function(){},onShareAppMessage:function(){}});
},{isPage:true,isComponent:true,currentFile:'pages/start/index.js'});require("pages/start/index.js");