var t = require("../../../@babel/runtime/helpers/interopRequireDefault"), a = require("../../../@babel/runtime/helpers/toConsumableArray"), e = t(require("../../../@babel/runtime/regenerator")), s = require("../../../@babel/runtime/helpers/asyncToGenerator"), i = require("../../../8A51F322415216BFEC379B250C07EA57.js"), n = getApp();

Page({
    data: {
        myList: [],
        myListCount: 0,
        myListOffset: 0,
        allList: [],
        limit: 15,
        allListCount: 0,
        allListOffset: 0
    },
    onLoad: function(t) {
        console.log(t), this.setData({
            id: t.id
        }), wx.showLoading(), this.loadMyList(), this.loadAllList(), console.log(t.openid), 
        t.openid === n.globalData.openid && this.setData({
            showDelete: !0
        });
    },
    delResult: function(t) {
        var a = this;
        console.log(t.currentTarget.dataset);
        var n, r = t.currentTarget.dataset.id;
        wx.showModal({
            title: "提示",
            content: "确定删除此条记录？",
            success: (n = s(e.default.mark(function t(s) {
                return e.default.wrap(function(t) {
                    for (;;) switch (t.prev = t.next) {
                      case 0:
                        if (!s.confirm) {
                            t.next = 5;
                            break;
                        }
                        return t.next = 3, i.delRecord({
                            id: r,
                            zp_id: a.data.id
                        });

                      case 3:
                        0 === t.sent.code && (wx.showToast({
                            title: "删除成功"
                        }), a.setData({
                            allList: a.data.allList.filter(function(t) {
                                return t.id !== r;
                            }),
                            allListCount: a.data.allListCount - 1
                        }), -1 !== a.data.myList.findIndex(function(t) {
                            return t.id === r;
                        }) && a.setData({
                            myList: a.data.myList.filter(function(t) {
                                return t.id !== r;
                            }),
                            myListCount: a.data.myListCount - 1
                        }));

                      case 5:
                      case "end":
                        return t.stop();
                    }
                }, t);
            })), function(t) {
                return n.apply(this, arguments);
            })
        });
    },
    loadMoreMyList: function() {
        var t = this;
        return s(e.default.mark(function s() {
            var n;
            return e.default.wrap(function(e) {
                for (;;) switch (e.prev = e.next) {
                  case 0:
                    if (!(t.data.myListOffset > t.data.myListCount)) {
                        e.next = 3;
                        break;
                    }
                    return wx.showToast({
                        title: "没有更多了",
                        icon: "none"
                    }), e.abrupt("return", !1);

                  case 3:
                    return e.next = 5, i.MyZPRecords({
                        zp_id: t.data.id,
                        offset: t.data.myListOffset + t.data.limit
                    });

                  case 5:
                    0 === (n = e.sent).code && (console.log(n.data.list), t.data.myList = [].concat(a(t.data.myList), a(n.data.list)), 
                    console.log(t.data.myList), t.setData({
                        myList: t.data.myList,
                        myListCount: n.data.count,
                        myListOffset: t.data.myListOffset + t.data.limit
                    }));

                  case 7:
                  case "end":
                    return e.stop();
                }
            }, s);
        }))();
    },
    loadMoreAllList: function() {
        var t = this;
        return s(e.default.mark(function s() {
            var n;
            return e.default.wrap(function(e) {
                for (;;) switch (e.prev = e.next) {
                  case 0:
                    if (!(t.data.allListOffset > t.data.allListCount)) {
                        e.next = 3;
                        break;
                    }
                    return wx.showToast({
                        title: "没有更多了",
                        icon: "none"
                    }), e.abrupt("return", !1);

                  case 3:
                    return e.next = 5, i.allRecords({
                        zp_id: t.data.id,
                        offset: t.data.allListOffset + t.data.limit
                    });

                  case 5:
                    0 === (n = e.sent).code && (console.log(n.data.list), t.data.allList = [].concat(a(t.data.allList), a(n.data.list)), 
                    console.log(t.data.allList), t.setData({
                        allList: t.data.allList,
                        allListCount: n.data.count,
                        allListOffset: t.data.allListOffset + t.data.limit
                    }));

                  case 7:
                  case "end":
                    return e.stop();
                }
            }, s);
        }))();
    },
    loadMyList: function() {
        var t = this;
        return s(e.default.mark(function a() {
            var s;
            return e.default.wrap(function(a) {
                for (;;) switch (a.prev = a.next) {
                  case 0:
                    return a.next = 2, i.MyZPRecords({
                        zp_id: t.data.id
                    });

                  case 2:
                    s = a.sent, wx.hideLoading(), 0 === s.code && t.setData({
                        myList: s.data.list,
                        myListCount: s.data.count
                    });

                  case 5:
                  case "end":
                    return a.stop();
                }
            }, a);
        }))();
    },
    loadAllList: function() {
        var t = this;
        return s(e.default.mark(function a() {
            var s;
            return e.default.wrap(function(a) {
                for (;;) switch (a.prev = a.next) {
                  case 0:
                    return a.next = 2, i.allRecords({
                        zp_id: t.data.id
                    });

                  case 2:
                    0 === (s = a.sent).code && t.setData({
                        allList: s.data.list,
                        allListCount: s.data.count
                    });

                  case 4:
                  case "end":
                    return a.stop();
                }
            }, a);
        }))();
    }
});