$gwx_XC_44=function(_,_v,_n,_p,_s,_wp,_wl,$gwn,$gwl,$gwh,wh,$gstack,$gwrt,gra,grb,TestTest,wfor,_ca,_da,_r,_rz,_o,_oz,_1,_1z,_2,_2z,_m,_mz,nv_getDate,nv_getRegExp,nv_console,nv_parseInt,nv_parseFloat,nv_isNaN,nv_isFinite,nv_decodeURI,nv_decodeURIComponent,nv_encodeURI,nv_encodeURIComponent,$gdc,nv_JSON,_af,_gv,_ai,_grp,_gd,_gapi,$ixc,_ic,_w,_ev,_tsd){return function(path,global){
if(typeof global==='undefined'){if (typeof __GWX_GLOBAL__==='undefined')global={};else global=__GWX_GLOBAL__;}if(typeof __WXML_GLOBAL__ === 'undefined') {__WXML_GLOBAL__={};
}__WXML_GLOBAL__.modules = __WXML_GLOBAL__.modules || {};
var e_={}
if(typeof(global.entrys)==='undefined')global.entrys={};e_=global.entrys;
var d_={}
if(typeof(global.defines)==='undefined')global.defines={};d_=global.defines;
var f_={}
if(typeof(global.modules)==='undefined')global.modules={};f_=global.modules || {};
var p_={}
__WXML_GLOBAL__.ops_cached = __WXML_GLOBAL__.ops_cached || {}
__WXML_GLOBAL__.ops_set = __WXML_GLOBAL__.ops_set || {};
__WXML_GLOBAL__.ops_init = __WXML_GLOBAL__.ops_init || {};
var z=__WXML_GLOBAL__.ops_set.$gwx_XC_44 || [];
function gz$gwx_XC_44_1(){
if( __WXML_GLOBAL__.ops_cached.$gwx_XC_44_1)return __WXML_GLOBAL__.ops_cached.$gwx_XC_44_1
__WXML_GLOBAL__.ops_cached.$gwx_XC_44_1=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
Z([3,'wrap'])
Z([[2,'&&'],[[2,'&&'],[[7],[3,'share_settings']],[[2,'>'],[[6],[[7],[3,'share_settings']],[3,'p_times']],[1,0]]],[[2,'||'],[[7],[3,'isMineZp']],[[2,'==='],[[7],[3,'share_type']],[1,2]]]])
Z([3,'toResults'])
Z([3,'height:28px;font-size:14px'])
Z([[2,'!'],[[7],[3,'zpLoad']]])
Z([[2,'||'],[[7],[3,'isMineZp']],[[7],[3,'isTemplate']]])
Z([3,'tapEdit'])
Z([a,[3,'control-item menu '],[[2,'?:'],[[2,'!=='],[[7],[3,'zpState']],[1,1]],[1,'disable'],[1,'']]])
Z([3,'edit'])
Z([3,'right:10px'])
Z(z[8])
Z([3,'30px'])
Z([[2,'!'],[[6],[[7],[3,'share_settings']],[3,'p_times']]])
Z([3,'saveZp'])
Z([a,z[7][1],z[7][2]])
Z(z[8])
Z(z[9])
Z([3,'sjzp-baocun'])
Z(z[11])
Z([3,'footer'])
Z([[7],[3,'isTemplate']])
Z(z[6])
Z(z[8])
Z([3,'sjzp-youjiantou'])
Z([3,'15px'])
Z([[2,'&&'],[[2,'!'],[[7],[3,'isMineZp']]],[[2,'!'],[[6],[[7],[3,'share_settings']],[3,'p_times']]]])
Z([3,'showSaveZp'])
Z(z[8])
Z(z[23])
Z(z[24])
})(__WXML_GLOBAL__.ops_cached.$gwx_XC_44_1);return __WXML_GLOBAL__.ops_cached.$gwx_XC_44_1
}
__WXML_GLOBAL__.ops_set.$gwx_XC_44=z;
__WXML_GLOBAL__.ops_init.$gwx_XC_44=true;
var x=['./pages/zhuanpan/index/index.wxml'];d_[x[0]]={}
var m0=function(e,s,r,gg){
var z=gz$gwx_XC_44_1()
var cSL=_n('view')
_rz(z,cSL,'class',0,e,s,gg)
var oTL=_v()
_(cSL,oTL)
if(_oz(z,1,e,s,gg)){oTL.wxVkey=1
var tWL=_mz(z,'van-button',['round',-1,'bindtap',2,'customStyle',1],[],e,s,gg)
_(oTL,tWL)
}
var eXL=_n('result')
_(cSL,eXL)
var lUL=_v()
_(cSL,lUL)
if(_oz(z,4,e,s,gg)){lUL.wxVkey=1
}
var bYL=_n('zhuanpan')
_(cSL,bYL)
var oZL=_n('summarize-bar')
_(cSL,oZL)
var aVL=_v()
_(cSL,aVL)
if(_oz(z,5,e,s,gg)){aVL.wxVkey=1
var x1L=_mz(z,'view',['bind:tap',6,'class',1,'data-target',2,'style',3],[],e,s,gg)
var o2L=_mz(z,'van-icon',['name',10,'size',1],[],e,s,gg)
_(x1L,o2L)
_(aVL,x1L)
}
else if(_oz(z,12,e,s,gg)){aVL.wxVkey=2
var f3L=_mz(z,'view',['bind:tap',13,'class',1,'data-target',2,'style',3],[],e,s,gg)
var c4L=_mz(z,'van-icon',['name',17,'size',1],[],e,s,gg)
_(f3L,c4L)
_(aVL,f3L)
}
var h5L=_n('view')
_rz(z,h5L,'class',19,e,s,gg)
var o6L=_v()
_(h5L,o6L)
if(_oz(z,20,e,s,gg)){o6L.wxVkey=1
var c7L=_n('tip-card')
var o8L=_mz(z,'view',['bind:tap',21,'data-target',1],[],e,s,gg)
var l9L=_mz(z,'van-icon',['name',23,'size',1],[],e,s,gg)
_(o8L,l9L)
_(c7L,o8L)
_(o6L,c7L)
}
else if(_oz(z,25,e,s,gg)){o6L.wxVkey=2
var a0L=_n('tip-card')
var tAM=_mz(z,'view',['bind:tap',26,'data-target',1],[],e,s,gg)
var eBM=_mz(z,'van-icon',['name',28,'size',1],[],e,s,gg)
_(tAM,eBM)
_(a0L,tAM)
_(o6L,a0L)
}
o6L.wxXCkey=1
o6L.wxXCkey=3
o6L.wxXCkey=3
_(cSL,h5L)
oTL.wxXCkey=1
oTL.wxXCkey=3
lUL.wxXCkey=1
aVL.wxXCkey=1
aVL.wxXCkey=3
aVL.wxXCkey=3
_(r,cSL)
var bCM=_n('more')
_(r,bCM)
var oDM=_n('share')
_(r,oDM)
var xEM=_n('share-settings')
_(r,xEM)
return r
}
e_[x[0]]={f:m0,j:[],i:[],ti:[],ic:[]}
if(path&&e_[path]){
return function(env,dd,global){$gwxc=0;var root={"tag":"wx-page"};root.children=[]
;g="$gwx_XC_44";var main=e_[path].f
if (typeof global==="undefined")global={};global.f=$gdc(f_[path],"",1);
try{
main(env,{},root,global);
_tsd(root)
}catch(err){
console.log(err)
}
;g="";
return root;
}
}
}
}(__g.a,__g.b,__g.c,__g.d,__g.e,__g.f,__g.g,__g.h,__g.i,__g.j,__g.k,__g.l,__g.m,__g.n,__g.o,__g.p,__g.q,__g.r,__g.s,__g.t,__g.u,__g.v,__g.w,__g.x,__g.y,__g.z,__g.A,__g.B,__g.C,__g.D,__g.E,__g.F,__g.G,__g.H,__g.I,__g.J,__g.K,__g.L,__g.M,__g.N,__g.O,__g.P,__g.Q,__g.R,__g.S,__g.T,__g.U,__g.V,__g.W,__g.X,__g.Y,__g.Z,__g.aa);if(__vd_version_info__.delayedGwx||false)$gwx_XC_44();	if (__vd_version_info__.delayedGwx) __wxAppCode__['pages/zhuanpan/index/index.wxml'] = [$gwx_XC_44, './pages/zhuanpan/index/index.wxml'];else __wxAppCode__['pages/zhuanpan/index/index.wxml'] = $gwx_XC_44( './pages/zhuanpan/index/index.wxml' );
	;__wxRoute = "pages/zhuanpan/index/index";__wxRouteBegin = true;__wxAppCurrentFile__="pages/zhuanpan/index/index.js";define("pages/zhuanpan/index/index.js",function(require,module,exports,window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){
"use strict";var e=require("../../../@babel/runtime/helpers/interopRequireDefault")(require("../../../@babel/runtime/regenerator")),t=require("../../../@babel/runtime/helpers/asyncToGenerator"),a=getApp(),n=require("../../../BD436B82415216BFDB250385AAE6EA57.js"),r=require("../../../8A51F322415216BFEC379B250C07EA57.js"),s=require("../../../A4874271415216BFC2E12A763DE8EA57.js");Page({behaviors:[wx.Bus,s],data:{zpState:0,zpLoad:!1,isTemplate:!1,isMineZp:!0,share_type:0,shouldSaveResult:!1,share_settings:{},have_join_times:0},moreShare:function(){var e=this,t=this.$bus.store.get("zpInfo");return t.openid&&t.openid===a.globalData.openid?new Promise((function(n){wx.showActionSheet({itemList:["分享当前转盘方案","邀请别人参与此转盘"],success:function(r){return 0===r.tapIndex?n({title:t.title,path:"/pages/zhuanpan/index/index?type=share&id=".concat(t.id,"&top_c=分享转盘&sub_c=").concat(a.globalData.openid)}):1===r.tapIndex?(e.$bus.event.emit("share-settings:show"),!1):void 0}})})):{}},onShareAppMessage:function(n){var s=this;return t(e.default.mark((function i(){var o,u,p;return e.default.wrap((function(i){for(;;)switch(i.prev=i.next){case 0:if(console.log("onShareAppMessage",n),o=s.$bus.store.get("zpInfo"),"menu"!==n.from){i.next=8;break}return i.next=5,s.moreShare();case 5:if(!(u=i.sent)){i.next=8;break}return i.abrupt("return",u);case 8:if("button"!==n.from){i.next=26;break}if("btn_share_more"!==n.target.dataset.detail){i.next=17;break}return i.next=12,s.moreShare();case 12:if(!(p=i.sent)){i.next=16;break}return console.log("fengxiang",p),i.abrupt("return",p);case 16:return i.abrupt("return",{title:o.title,path:"/pages/zhuanpan/index/index?type=share&share_type=2&id=".concat(o.id,"&top_c=share_setting&sub_c=").concat(a.globalData.openid)});case 17:if("result"!==n.target.dataset.detail){i.next=21;break}return i.abrupt("return",{title:s.$bus.get("result").text,path:"/pages/zhuanpan/index/index?type=share&id=".concat(o.id,"&top_c=分享结果&sub_c=").concat(a.globalData.openid)});case 21:if("saveShareSetting"!==n.target.dataset.detail){i.next=26;break}return console.log("saveShareSetting"),i.next=25,new Promise(function(){var a=t(e.default.mark((function t(a,n){var i,u;return e.default.wrap((function(e){for(;;)switch(e.prev=e.next){case 0:return wx.showLoading({title:"保存中..."}),e.next=3,r.UpdateShareSettings({id:o.id,p_times:(null===(i=o.share_settings)||void 0===i?void 0:i.p_times)||1});case 3:(u=e.sent)&&0===u.code&&(s.$bus.store.set("zpInfo",u.data),wx.hideLoading(),s.$bus.event.emit("share-settings:hide"),a());case 5:case"end":return e.stop()}}),t)})));return function(e,t){return a.apply(this,arguments)}}());case 25:return i.abrupt("return",{title:o.title,path:"/pages/zhuanpan/index/index?type=share&share_type=2&id=".concat(o.id,"&top_c=share_setting&sub_c=").concat(a.globalData.openid)});case 26:return i.abrupt("return",{title:o.title,path:"/pages/zhuanpan/index/index?type=share&id=".concat(o.id,"&top_c=分享转盘&sub_c=").concat(a.globalData.openid)});case 27:case"end":return i.stop()}}),i)})))()},onShareTimeline:function(){var e=this.$bus.store.get("zpInfo");return{title:e.title,query:"type=share&id=".concat(e.id)}},onLoad:function(a){var n=this;return t(e.default.mark((function t(){return e.default.wrap((function(e){for(;;)switch(e.prev=e.next){case 0:a.id.startsWith("template_")?n.loadFromTemplate(a.id):n.loadZpFromServer(a.id),n.$bus.store.set("options",a),a.share_type&&2==a.share_type&&n.setData({share_type:2});case 3:case"end":return e.stop()}}),t)})))()},loadFromTemplate:function(e){var t=n.all_zps[e];t?(this.initZp(t),a.addLog({id:"打开转盘",title:t.title,type:"template"})):this.loadZpFromServer(e)},initZp:function(e){n.initZpItemsObj(e),this.$bus.store.set("zpInfo",e),this.setData({title:e.title,zpState:1,zpLoad:!0,share_settings:e.share_settings,isTemplate:e.id.startsWith("template_")}),wx.setStorageSync("lastZp",e),e.openid!==a.globalData.openid?this.setData({isMineZp:!1}):this.setData({isMineZp:!0}),(2===this.data.share_type||e.openid===a.globalData.openid)&&e.share_settings&&e.share_settings.p_times>0&&(this.setData({shouldSaveResult:!0}),this.$bus.store.set("shouldSaveResult",!0)),this.$bus.emit("page:zpInfoLoaded"),this.getZPRecordsTimes(e)},getZPRecordsTimes:function(a){var n=this;return t(e.default.mark((function t(){var s;return e.default.wrap((function(e){for(;;)switch(e.prev=e.next){case 0:if(!(a.share_settings&&a.share_settings.p_times>0)){e.next=5;break}return e.next=3,r.MyZPRecordsCount({zp_id:a.id});case 3:0===(s=e.sent).code&&(n.setData({have_join_times:s.data}),n.$bus.store.set("recordsTimes",s.data),s.data>=a.share_settings.p_times&&n.$bus.store.set("shouldSaveResult",!1),n.$bus.event.call("summarize_bar:updateShow"));case 5:case"end":return e.stop()}}),t)})))()},loadZpFromServer:function(n){var s=this;return t(e.default.mark((function t(){var i;return e.default.wrap((function(e){for(;;)switch(e.prev=e.next){case 0:return wx.showLoading({title:"转盘加载中.."}),e.next=3,a.initLogin();case 3:if(e.prev=3,!n.startsWith("template_server_")){e.next=10;break}return e.next=7,r.getTemplateById(n);case 7:i=e.sent,e.next=13;break;case 10:return e.next=12,r.findOneById(n);case 12:i=e.sent;case 13:wx.hideLoading(),0===i.code&&(s.initZp(i.data),a.addLog({id:"打开转盘",title:i.data.title,type:"server"})),e.next=21;break;case 17:e.prev=17,e.t0=e.catch(3),wx.showModal({title:"加载出错了，请稍后重试",content:e.t0.toString(),showCancel:!1,complete:function(e){wx.navigateBack()}}),a.addLog({id:"加载转盘出错",status:"error",msg:e.t0});case 21:case"end":return e.stop()}}),t,null,[[3,17]])})))()},toResetZp:function(){var a=this;return t(e.default.mark((function t(){return e.default.wrap((function(e){for(;;)switch(e.prev=e.next){case 0:if(a.checkZpIsReady()){e.next=2;break}return e.abrupt("return");case 2:a.$bus.emit("page:recoveryZp"),a.setData({showResetZp:!1});case 4:case"end":return e.stop()}}),t)})))()},toResults:function(){var e=this.$bus.store.get("zpInfo");wx.navigateTo({url:"/pages/zhuanpan/results/results"+"?id=".concat(e.id,"&openid=").concat(e.openid)})},checkZpIsReady:function(){return 1===this.data.zpState},onShow:function(){console.log("onShow",a.globalData.current_edit_zp),a.globalData.current_edit_zp&&(this.initZp(a.globalData.current_edit_zp),a.globalData.current_edit_zp=null),a.globalData._needupdateBlackList&&(this.$bus.event.call("black:initBlack"),a.globalData._needupdateBlackList=!1)},onReady:function(){}});
},{isPage:true,isComponent:true,currentFile:'pages/zhuanpan/index/index.js'});require("pages/zhuanpan/index/index.js");