var e = require("../../../../../@babel/runtime/helpers/interopRequireDefault")(require("../../../../../@babel/runtime/regenerator")), t = require("../../../../../@babel/runtime/helpers/asyncToGenerator"), s = require("../../../../../8A51F322415216BFEC379B250C07EA57.js");

Component({
    behaviors: [ wx.Bus ],
    properties: {},
    data: {
        show: !1,
        allow_share: !0,
        p_times: 1
    },
    methods: {
        changeShareStatus: function(e) {
            console.log(e.detail), this.setData({
                allow_share: e.detail
            });
        },
        saveShareSettings: function() {
            var n = this;
            return t(e.default.mark(function t() {
                var a, i;
                return e.default.wrap(function(e) {
                    for (;;) switch (e.prev = e.next) {
                      case 0:
                        return a = n.$bus.get("zpInfo"), wx.showLoading({
                            title: "保存中.."
                        }), e.next = 4, s.UpdateShareSettings({
                            id: a.id,
                            p_times: 0
                        });

                      case 4:
                        (i = e.sent) && 0 === i.code && (n.$bus.store.set("zpInfo", i.data), wx.showModal({
                            title: "提示",
                            content: "保存成功",
                            showCancel: !1,
                            success: function() {
                                wx.navigateBack();
                            }
                        }));

                      case 6:
                      case "end":
                        return e.stop();
                    }
                }, t);
            }))();
        },
        handleClose: function() {
            this.setData({
                show: !1
            });
        },
        onSave: function() {
            console.log("onSave");
        },
        onStepperChange: function(e) {
            this.setData({
                p_times: e.detail
            });
            var t = this.$bus.get("zpInfo");
            t.share_settings || (t.share_settings = {}), this.$bus.get("zpInfo").share_settings.p_times = e.detail, 
            console.log("zpInfo", t);
        }
    },
    lifetimes: {
        attached: function() {
            var e = this;
            this.$bus.event.on("share-settings:show", function() {
                var t, s = e.$bus.get("zpInfo");
                e.setData({
                    show: !0,
                    p_times: (null === (t = s.share_settings) || void 0 === t ? void 0 : t.p_times) || 1
                });
            }), this.$bus.event.on("share-settings:hide", function() {
                e.setData({
                    show: !1
                });
            });
        }
    }
});