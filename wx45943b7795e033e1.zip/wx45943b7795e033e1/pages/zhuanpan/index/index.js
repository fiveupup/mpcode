var e = require("../../../@babel/runtime/helpers/interopRequireDefault")(require("../../../@babel/runtime/regenerator")), t = require("../../../@babel/runtime/helpers/asyncToGenerator"), a = getApp(), n = require("../../../BD436B82415216BFDB250385AAE6EA57.js"), r = require("../../../8A51F322415216BFEC379B250C07EA57.js"), s = require("../../../A4874271415216BFC2E12A763DE8EA57.js");

Page({
    behaviors: [ wx.Bus, s ],
    data: {
        zpState: 0,
        zpLoad: !1,
        isTemplate: !1,
        isMineZp: !0,
        share_type: 0,
        shouldSaveResult: !1,
        share_settings: {},
        have_join_times: 0
    },
    moreShare: function() {
        var e = this, t = this.$bus.store.get("zpInfo");
        return t.openid && t.openid === a.globalData.openid ? new Promise(function(n) {
            wx.showActionSheet({
                itemList: [ "分享当前转盘方案", "邀请别人参与此转盘" ],
                success: function(r) {
                    return 0 === r.tapIndex ? n({
                        title: t.title,
                        path: "/pages/zhuanpan/index/index?type=share&id=".concat(t.id, "&top_c=分享转盘&sub_c=").concat(a.globalData.openid)
                    }) : 1 === r.tapIndex ? (e.$bus.event.emit("share-settings:show"), !1) : void 0;
                }
            });
        }) : {};
    },
    onShareAppMessage: function(n) {
        var s = this;
        return t(e.default.mark(function i() {
            var o, u, p;
            return e.default.wrap(function(i) {
                for (;;) switch (i.prev = i.next) {
                  case 0:
                    if (console.log("onShareAppMessage", n), o = s.$bus.store.get("zpInfo"), "menu" !== n.from) {
                        i.next = 8;
                        break;
                    }
                    return i.next = 5, s.moreShare();

                  case 5:
                    if (!(u = i.sent)) {
                        i.next = 8;
                        break;
                    }
                    return i.abrupt("return", u);

                  case 8:
                    if ("button" !== n.from) {
                        i.next = 26;
                        break;
                    }
                    if ("btn_share_more" !== n.target.dataset.detail) {
                        i.next = 17;
                        break;
                    }
                    return i.next = 12, s.moreShare();

                  case 12:
                    if (!(p = i.sent)) {
                        i.next = 16;
                        break;
                    }
                    return console.log("fengxiang", p), i.abrupt("return", p);

                  case 16:
                    return i.abrupt("return", {
                        title: o.title,
                        path: "/pages/zhuanpan/index/index?type=share&share_type=2&id=".concat(o.id, "&top_c=share_setting&sub_c=").concat(a.globalData.openid)
                    });

                  case 17:
                    if ("result" !== n.target.dataset.detail) {
                        i.next = 21;
                        break;
                    }
                    return i.abrupt("return", {
                        title: s.$bus.get("result").text,
                        path: "/pages/zhuanpan/index/index?type=share&id=".concat(o.id, "&top_c=分享结果&sub_c=").concat(a.globalData.openid)
                    });

                  case 21:
                    if ("saveShareSetting" !== n.target.dataset.detail) {
                        i.next = 26;
                        break;
                    }
                    return console.log("saveShareSetting"), i.next = 25, new Promise(function() {
                        var a = t(e.default.mark(function t(a, n) {
                            var i, u;
                            return e.default.wrap(function(e) {
                                for (;;) switch (e.prev = e.next) {
                                  case 0:
                                    return wx.showLoading({
                                        title: "保存中..."
                                    }), e.next = 3, r.UpdateShareSettings({
                                        id: o.id,
                                        p_times: (null === (i = o.share_settings) || void 0 === i ? void 0 : i.p_times) || 1
                                    });

                                  case 3:
                                    (u = e.sent) && 0 === u.code && (s.$bus.store.set("zpInfo", u.data), wx.hideLoading(), 
                                    s.$bus.event.emit("share-settings:hide"), a());

                                  case 5:
                                  case "end":
                                    return e.stop();
                                }
                            }, t);
                        }));
                        return function(e, t) {
                            return a.apply(this, arguments);
                        };
                    }());

                  case 25:
                    return i.abrupt("return", {
                        title: o.title,
                        path: "/pages/zhuanpan/index/index?type=share&share_type=2&id=".concat(o.id, "&top_c=share_setting&sub_c=").concat(a.globalData.openid)
                    });

                  case 26:
                    return i.abrupt("return", {
                        title: o.title,
                        path: "/pages/zhuanpan/index/index?type=share&id=".concat(o.id, "&top_c=分享转盘&sub_c=").concat(a.globalData.openid)
                    });

                  case 27:
                  case "end":
                    return i.stop();
                }
            }, i);
        }))();
    },
    onShareTimeline: function() {
        var e = this.$bus.store.get("zpInfo");
        return {
            title: e.title,
            query: "type=share&id=".concat(e.id)
        };
    },
    onLoad: function(a) {
        var n = this;
        return t(e.default.mark(function t() {
            return e.default.wrap(function(e) {
                for (;;) switch (e.prev = e.next) {
                  case 0:
                    a.id.startsWith("template_") ? n.loadFromTemplate(a.id) : n.loadZpFromServer(a.id), 
                    n.$bus.store.set("options", a), a.share_type && 2 == a.share_type && n.setData({
                        share_type: 2
                    });

                  case 3:
                  case "end":
                    return e.stop();
                }
            }, t);
        }))();
    },
    loadFromTemplate: function(e) {
        var t = n.all_zps[e];
        t ? (this.initZp(t), a.addLog({
            id: "打开转盘",
            title: t.title,
            type: "template"
        })) : this.loadZpFromServer(e);
    },
    initZp: function(e) {
        n.initZpItemsObj(e), this.$bus.store.set("zpInfo", e), this.setData({
            title: e.title,
            zpState: 1,
            zpLoad: !0,
            share_settings: e.share_settings,
            isTemplate: e.id.startsWith("template_")
        }), wx.setStorageSync("lastZp", e), e.openid !== a.globalData.openid ? this.setData({
            isMineZp: !1
        }) : this.setData({
            isMineZp: !0
        }), (2 === this.data.share_type || e.openid === a.globalData.openid) && e.share_settings && e.share_settings.p_times > 0 && (this.setData({
            shouldSaveResult: !0
        }), this.$bus.store.set("shouldSaveResult", !0)), this.$bus.emit("page:zpInfoLoaded"), 
        this.getZPRecordsTimes(e);
    },
    getZPRecordsTimes: function(a) {
        var n = this;
        return t(e.default.mark(function t() {
            var s;
            return e.default.wrap(function(e) {
                for (;;) switch (e.prev = e.next) {
                  case 0:
                    if (!(a.share_settings && a.share_settings.p_times > 0)) {
                        e.next = 5;
                        break;
                    }
                    return e.next = 3, r.MyZPRecordsCount({
                        zp_id: a.id
                    });

                  case 3:
                    0 === (s = e.sent).code && (n.setData({
                        have_join_times: s.data
                    }), n.$bus.store.set("recordsTimes", s.data), s.data >= a.share_settings.p_times && n.$bus.store.set("shouldSaveResult", !1), 
                    n.$bus.event.call("summarize_bar:updateShow"));

                  case 5:
                  case "end":
                    return e.stop();
                }
            }, t);
        }))();
    },
    loadZpFromServer: function(n) {
        var s = this;
        return t(e.default.mark(function t() {
            var i;
            return e.default.wrap(function(e) {
                for (;;) switch (e.prev = e.next) {
                  case 0:
                    return wx.showLoading({
                        title: "转盘加载中.."
                    }), e.next = 3, a.initLogin();

                  case 3:
                    if (e.prev = 3, !n.startsWith("template_server_")) {
                        e.next = 10;
                        break;
                    }
                    return e.next = 7, r.getTemplateById(n);

                  case 7:
                    i = e.sent, e.next = 13;
                    break;

                  case 10:
                    return e.next = 12, r.findOneById(n);

                  case 12:
                    i = e.sent;

                  case 13:
                    wx.hideLoading(), 0 === i.code && (s.initZp(i.data), a.addLog({
                        id: "打开转盘",
                        title: i.data.title,
                        type: "server"
                    })), e.next = 21;
                    break;

                  case 17:
                    e.prev = 17, e.t0 = e.catch(3), wx.showModal({
                        title: "加载出错了，请稍后重试",
                        content: e.t0.toString(),
                        showCancel: !1,
                        complete: function(e) {
                            wx.navigateBack();
                        }
                    }), a.addLog({
                        id: "加载转盘出错",
                        status: "error",
                        msg: e.t0
                    });

                  case 21:
                  case "end":
                    return e.stop();
                }
            }, t, null, [ [ 3, 17 ] ]);
        }))();
    },
    toResetZp: function() {
        var a = this;
        return t(e.default.mark(function t() {
            return e.default.wrap(function(e) {
                for (;;) switch (e.prev = e.next) {
                  case 0:
                    if (a.checkZpIsReady()) {
                        e.next = 2;
                        break;
                    }
                    return e.abrupt("return");

                  case 2:
                    a.$bus.emit("page:recoveryZp"), a.setData({
                        showResetZp: !1
                    });

                  case 4:
                  case "end":
                    return e.stop();
                }
            }, t);
        }))();
    },
    toResults: function() {
        var e = this.$bus.store.get("zpInfo");
        wx.navigateTo({
            url: "/pages/zhuanpan/results/results" + "?id=".concat(e.id, "&openid=").concat(e.openid)
        });
    },
    checkZpIsReady: function() {
        return 1 === this.data.zpState;
    },
    onShow: function() {
        console.log("onShow", a.globalData.current_edit_zp), a.globalData.current_edit_zp && (this.initZp(a.globalData.current_edit_zp), 
        a.globalData.current_edit_zp = null), a.globalData._needupdateBlackList && (this.$bus.event.call("black:initBlack"), 
        a.globalData._needupdateBlackList = !1);
    },
    onReady: function() {}
});