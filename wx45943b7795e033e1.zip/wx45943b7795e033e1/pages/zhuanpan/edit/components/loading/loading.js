Component({
    behaviors: [ wx.Bus ],
    data: {
        show: !1,
        text: "",
        status: 0,
        ad: "adunit-5a63853e89fdbca5"
    },
    methods: {
        onHide: function() {
            this.setData({
                show: !1
            }), this.$bus.emit("loading:hide", {
                status: this.data.status
            });
        },
        redo: function() {
            this.setData({
                show: !1
            });
        }
    },
    lifetimes: {
        attached: function() {
            var t = this;
            this.$bus.event.export("loading:show", function() {
                t.setData({
                    show: !0
                });
            }), this.$bus.event.export("loading:setText", function(s) {
                var a = s.text, e = s.status;
                t.setData({
                    text: a,
                    status: e
                });
            });
        }
    }
});