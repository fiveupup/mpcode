require("../../../../../@babel/runtime/helpers/Objectvalues");

var e = require("../../../../../D3DADA56415216BFB5BCB25179D6EA57.js");

Component({
    behaviors: [ wx.Bus ],
    properties: {},
    data: {
        showColors: !1
    },
    methods: {
        closeSetting: function() {
            this.setData({
                showColors: !1
            });
        },
        initColorsMap: function() {
            for (var o = {}, t = 0; t < e.length; t++) o[e[t]] = {
                color: e[t],
                selected: !1,
                checked: !1,
                index: t
            };
            this.setData({
                colors_map: o
            }), this.$bus.store.set("colors_map", o);
        },
        selectColor: function(e) {
            var o = e.currentTarget.dataset.color;
            this.setData({
                showColors: !1
            }), this.$bus.event.call("page:setColor", {
                color: o,
                index: this.$bus.store.get("current_zp_item_index")
            });
        }
    },
    lifetimes: {
        attached: function() {
            var e = this;
            this.$bus.event.export("colors:showColors", function(o) {
                var t = o.index, s = o.selectedColor;
                e.$bus.store.set("current_zp_item_index", t), Object.values(e.data.colors_map).forEach(function(e) {
                    e.checked = !1, e.selected = !1;
                });
                var r = s[t];
                r && e.data.colors_map[r] && (e.data.colors_map[r].selected = !0), s.forEach(function(o) {
                    var t = e.data.colors_map[o];
                    t && (t.checked = !0);
                }), e.setData({
                    showColors: !0,
                    colors_map: e.data.colors_map
                });
            }), this.initColorsMap();
        }
    }
});