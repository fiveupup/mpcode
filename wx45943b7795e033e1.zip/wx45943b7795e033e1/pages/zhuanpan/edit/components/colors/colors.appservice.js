$gwx_XC_40=function(_,_v,_n,_p,_s,_wp,_wl,$gwn,$gwl,$gwh,wh,$gstack,$gwrt,gra,grb,TestTest,wfor,_ca,_da,_r,_rz,_o,_oz,_1,_1z,_2,_2z,_m,_mz,nv_getDate,nv_getRegExp,nv_console,nv_parseInt,nv_parseFloat,nv_isNaN,nv_isFinite,nv_decodeURI,nv_decodeURIComponent,nv_encodeURI,nv_encodeURIComponent,$gdc,nv_JSON,_af,_gv,_ai,_grp,_gd,_gapi,$ixc,_ic,_w,_ev,_tsd){return function(path,global){
if(typeof global==='undefined'){if (typeof __GWX_GLOBAL__==='undefined')global={};else global=__GWX_GLOBAL__;}if(typeof __WXML_GLOBAL__ === 'undefined') {__WXML_GLOBAL__={};
}__WXML_GLOBAL__.modules = __WXML_GLOBAL__.modules || {};
var e_={}
if(typeof(global.entrys)==='undefined')global.entrys={};e_=global.entrys;
var d_={}
if(typeof(global.defines)==='undefined')global.defines={};d_=global.defines;
var f_={}
if(typeof(global.modules)==='undefined')global.modules={};f_=global.modules || {};
var p_={}
__WXML_GLOBAL__.ops_cached = __WXML_GLOBAL__.ops_cached || {}
__WXML_GLOBAL__.ops_set = __WXML_GLOBAL__.ops_set || {};
__WXML_GLOBAL__.ops_init = __WXML_GLOBAL__.ops_init || {};
var z=__WXML_GLOBAL__.ops_set.$gwx_XC_40 || [];
function gz$gwx_XC_40_1(){
if( __WXML_GLOBAL__.ops_cached.$gwx_XC_40_1)return __WXML_GLOBAL__.ops_cached.$gwx_XC_40_1
__WXML_GLOBAL__.ops_cached.$gwx_XC_40_1=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
Z([3,'closeSetting'])
Z([3,'colors-popup'])
Z([3,'height:1300rpx;background:#fff;transition:all .3s ease-out;padding-bottom:50rpx'])
Z([3,'bottom'])
Z([[7],[3,'showColors']])
Z([3,'color'])
Z([[7],[3,'colors_map']])
Z([3,'index'])
Z([3,'selectColor'])
Z([a,[3,'item '],[[2,'?:'],[[6],[[7],[3,'item']],[3,'selected']],[1,'selected'],[1,'']]])
Z([[7],[3,'color']])
Z([a,[3,'background:'],z[10]])
Z([[6],[[7],[3,'item']],[3,'checked']])
Z([3,'#999'])
Z([3,'success'])
Z([3,'66rpx'])
})(__WXML_GLOBAL__.ops_cached.$gwx_XC_40_1);return __WXML_GLOBAL__.ops_cached.$gwx_XC_40_1
}
__WXML_GLOBAL__.ops_set.$gwx_XC_40=z;
__WXML_GLOBAL__.ops_init.$gwx_XC_40=true;
var x=['./pages/zhuanpan/edit/components/colors/colors.wxml'];d_[x[0]]={}
var m0=function(e,s,r,gg){
var z=gz$gwx_XC_40_1()
var eZJ=_mz(z,'van-popup',['closeable',-1,'round',-1,'bind:close',0,'customClass',1,'customStyle',1,'position',2,'show',3],[],e,s,gg)
var b1J=_v()
_(eZJ,b1J)
var o2J=function(o4J,x3J,f5J,gg){
var h7J=_mz(z,'view',['bind:tap',8,'class',1,'data-color',2,'style',3],[],o4J,x3J,gg)
var o8J=_v()
_(h7J,o8J)
if(_oz(z,12,o4J,x3J,gg)){o8J.wxVkey=1
var c9J=_mz(z,'van-icon',['color',13,'name',1,'size',2],[],o4J,x3J,gg)
_(o8J,c9J)
}
o8J.wxXCkey=1
o8J.wxXCkey=3
_(f5J,h7J)
return f5J
}
b1J.wxXCkey=4
_2z(z,6,o2J,e,s,gg,b1J,'item','color','index')
_(r,eZJ)
return r
}
e_[x[0]]={f:m0,j:[],i:[],ti:[],ic:[]}
if(path&&e_[path]){
return function(env,dd,global){$gwxc=0;var root={"tag":"wx-page"};root.children=[]
;g="$gwx_XC_40";var main=e_[path].f
if (typeof global==="undefined")global={};global.f=$gdc(f_[path],"",1);
try{
main(env,{},root,global);
_tsd(root)
}catch(err){
console.log(err)
}
;g="";
return root;
}
}
}
}(__g.a,__g.b,__g.c,__g.d,__g.e,__g.f,__g.g,__g.h,__g.i,__g.j,__g.k,__g.l,__g.m,__g.n,__g.o,__g.p,__g.q,__g.r,__g.s,__g.t,__g.u,__g.v,__g.w,__g.x,__g.y,__g.z,__g.A,__g.B,__g.C,__g.D,__g.E,__g.F,__g.G,__g.H,__g.I,__g.J,__g.K,__g.L,__g.M,__g.N,__g.O,__g.P,__g.Q,__g.R,__g.S,__g.T,__g.U,__g.V,__g.W,__g.X,__g.Y,__g.Z,__g.aa);if(__vd_version_info__.delayedGwx||false)$gwx_XC_40();	if (__vd_version_info__.delayedGwx) __wxAppCode__['pages/zhuanpan/edit/components/colors/colors.wxml'] = [$gwx_XC_40, './pages/zhuanpan/edit/components/colors/colors.wxml'];else __wxAppCode__['pages/zhuanpan/edit/components/colors/colors.wxml'] = $gwx_XC_40( './pages/zhuanpan/edit/components/colors/colors.wxml' );
	;__wxRoute = "pages/zhuanpan/edit/components/colors/colors";__wxRouteBegin = true;__wxAppCurrentFile__="pages/zhuanpan/edit/components/colors/colors.js";define("pages/zhuanpan/edit/components/colors/colors.js",function(require,module,exports,window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){
"use strict";require("../../../../../@babel/runtime/helpers/Objectvalues");var e=require("../../../../../D3DADA56415216BFB5BCB25179D6EA57.js");Component({behaviors:[wx.Bus],properties:{},data:{showColors:!1},methods:{closeSetting:function(){this.setData({showColors:!1})},initColorsMap:function(){for(var o={},t=0;t<e.length;t++)o[e[t]]={color:e[t],selected:!1,checked:!1,index:t};this.setData({colors_map:o}),this.$bus.store.set("colors_map",o)},selectColor:function(e){var o=e.currentTarget.dataset.color;this.setData({showColors:!1}),this.$bus.event.call("page:setColor",{color:o,index:this.$bus.store.get("current_zp_item_index")})}},lifetimes:{attached:function(){var e=this;this.$bus.event.export("colors:showColors",(function(o){var t=o.index,s=o.selectedColor;e.$bus.store.set("current_zp_item_index",t),Object.values(e.data.colors_map).forEach((function(e){e.checked=!1,e.selected=!1}));var r=s[t];r&&e.data.colors_map[r]&&(e.data.colors_map[r].selected=!0),s.forEach((function(o){var t=e.data.colors_map[o];t&&(t.checked=!0)})),e.setData({showColors:!0,colors_map:e.data.colors_map})})),this.initColorsMap()}}});
},{isPage:false,isComponent:true,currentFile:'pages/zhuanpan/edit/components/colors/colors.js'});require("pages/zhuanpan/edit/components/colors/colors.js");