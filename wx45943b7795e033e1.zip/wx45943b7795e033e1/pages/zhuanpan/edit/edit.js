var t, e = require("../../../@babel/runtime/helpers/interopRequireDefault"), i = require("../../../@babel/runtime/helpers/createForOfIteratorHelper"), a = require("../../../@babel/runtime/helpers/defineProperty"), n = e(require("../../../@babel/runtime/regenerator")), o = require("../../../@babel/runtime/helpers/asyncToGenerator"), s = require("../../../BD436B82415216BFDB250385AAE6EA57.js"), r = s.getTemplateZpInfo, c = (s.empty_zp, 
require("../../../D3DADA56415216BFB5BCB25179D6EA57.js")), d = require("../../../6BCCA7D4415216BF0DAACFD3DDD8EA57.js"), l = require("../../../8A51F322415216BFEC379B250C07EA57.js"), u = getApp();

Page({
    behaviors: [ wx.Bus, d ],
    data: {
        zp_info: {},
        focus: !1,
        showSetting: !1,
        hideWeight: !1
    },
    checkHideWeight: function() {
        var t = this.data.zp_info.items_obj.some(function(t) {
            return 1 !== t.weight;
        });
        console.log("hasWeightNot1", t), t ? this.setData({
            hideWeight: !0
        }) : this.setData({
            hideWeight: !1
        });
    },
    onLoad: (t = o(n.default.mark(function t(e) {
        var i, a, o;
        return n.default.wrap(function(t) {
            for (;;) switch (t.prev = t.next) {
              case 0:
                if ("add" !== e.type) {
                    t.next = 8;
                    break;
                }
                return this.setData({
                    zp_info: JSON.parse(JSON.stringify(r()))
                }), wx.setNavigationBarTitle({
                    title: "创建转盘"
                }), this.createType = "add", u.addLog({
                    id: "进入编辑",
                    title: this.data.zp_info.title,
                    type: "创建转盘"
                }), this.top_c = "创建新的", this.sub_c = "空白转盘", t.abrupt("return");

              case 8:
                if (!(i = e.id).startsWith("template_")) {
                    t.next = 23;
                    break;
                }
                if (a = r(i), !i.startsWith("template_server_")) {
                    t.next = 16;
                    break;
                }
                return t.next = 14, l.getTemplateById(i);

              case 14:
                0 === (o = t.sent).code ? a = o.data : wx.showToast({
                    title: "加载模板失败",
                    icon: "none"
                });

              case 16:
                this.setData({
                    zp_info: a
                }), u.addLog({
                    id: "进入编辑",
                    title: this.data.zp_info.title,
                    type: "编辑转盘",
                    p1: "系统模板"
                }), this.top_c = "系统模板", this.sub_c = this.data.zp_info.title, this.checkHideWeight(), 
                t.next = 24;
                break;

              case 23:
                this.loadZpFromServer(i);

              case 24:
                this.editStatus = 0;

              case 25:
              case "end":
                return t.stop();
            }
        }, t, this);
    })), function(e) {
        return t.apply(this, arguments);
    }),
    loadZpFromServer: function(t) {
        var e = this;
        return o(n.default.mark(function i() {
            var a, o;
            return n.default.wrap(function(i) {
                for (;;) switch (i.prev = i.next) {
                  case 0:
                    return wx.showLoading({
                        title: "加载中..."
                    }), i.next = 3, l.findOneById(t);

                  case 3:
                    a = i.sent, wx.hideLoading(), 0 === a.code && ((o = a.data).openid !== u.globalData.openid && wx.setNavigationBarTitle({
                        title: "创建转盘"
                    }), e.setData({
                        zp_info: o
                    }), u.addLog({
                        id: "进入编辑",
                        title: e.data.zp_info.title,
                        type: "编辑转盘",
                        p1: "server"
                    }), e.sub_c = e.data.zp_info.title, e.top_c = e.data.zp_info.openid === u.globalData.openid ? "自己的转盘" : "别人的转盘"), 
                    e.checkHideWeight();

                  case 7:
                  case "end":
                    return i.stop();
                }
            }, i);
        }))();
    },
    clearTitle: function() {
        this.setData(a({}, "zp_info.title", ""));
    },
    delItem: function(t) {
        var e;
        if (console.log("e", t), this.data.zp_info.items_obj.length < 3) wx.showToast({
            title: "至少保留两个选项呀",
            icon: "none"
        }); else {
            var i = t.currentTarget.dataset.index - 0, n = this.data.zp_info;
            n.items_obj.splice(i, 1), this.setData((a(e = {}, "zp_info.items_obj", n.items_obj), 
            a(e, "focus", !1), e));
        }
    },
    addNewItem: function() {
        var t, e = c[0], i = this.data.zp_info;
        if (i.items_obj.length > 0) {
            var n = i.items_obj[i.items_obj.length - 1], o = this.$bus.store.get("colors_map")[n.color], s = o ? o.index + 1 : 0;
            e = s && s < c.length ? c[s] : c[0];
        }
        var r = this.data.zp_info.items_obj.length, d = Math.random().toString(36).substr(2, 5);
        this.setData((a(t = {}, "zp_info.items_obj[".concat(r, "]"), {
            id: d,
            text: "",
            color: e,
            weight: 1
        }), a(t, "focus", !0), t)), this.checkHideWeight();
    },
    onEditOption: function(t) {
        var e = t.currentTarget.dataset, i = e.index, n = e.type, o = t.detail.value;
        this.setData(a({}, "zp_info.items_obj[".concat(i, "].").concat(n), o)), this.checkHideWeight();
    },
    onBlur: function(t) {
        var e, i, n = t.currentTarget.dataset, o = n.index, s = n.type, r = parseInt(t.detail.value);
        Number.isNaN(r) || r < 1 ? this.setData((a(e = {}, "zp_info.items_obj[".concat(o, "].").concat(s), 1), 
        a(e, "focus", !1), e)) : this.setData((a(i = {}, "zp_info.items_obj[".concat(o, "].").concat(s), r), 
        a(i, "focus", !1), i));
    },
    optionMore: function(t) {
        var e = this, i = t.currentTarget.dataset.index, n = this.data.zp_info.items_obj, o = n[i];
        wx.showActionSheet({
            itemList: [ "📋 复制", "👆 上移", "👇 下移" ],
            success: function(t) {
                switch (t.tapIndex) {
                  case 0:
                    var s = Object.assign({}, o);
                    n.splice(i + 1, 0, s);
                    break;

                  case 1:
                    if (0 === i) return void wx.showToast({
                        title: "已经是第一个了",
                        icon: "none"
                    });
                    var r = n[i];
                    n[i] = n[i - 1], n[i - 1] = r;
                    break;

                  case 2:
                    if (i === n.length - 1) return void wx.showToast({
                        title: "已经是最后一个了",
                        icon: "none"
                    });
                    var c = n[i];
                    n[i] = n[i + 1], n[i + 1] = c;
                }
                e.setData(a({}, "zp_info.items_obj", n));
            }
        });
    },
    onChangeTitle: function(t) {
        this.setData(a({}, "zp_info.title", t.detail.value)), this.editStatus = 1;
    },
    onChangeSetting: function(t) {
        var e = t.currentTarget.dataset.type, i = t.detail;
        this.setData(a({}, "zp_info.settings.".concat(e), i));
    },
    onSelColor: function(t) {
        var e = t.currentTarget.dataset.index, i = this.data.zp_info.items_obj.map(function(t) {
            return t.color;
        });
        this.$bus.event.call("colors:showColors", {
            index: e,
            selectedColor: i
        });
    },
    showSetting: function() {
        this.setData({
            showSetting: !0
        });
    },
    saveZp: function() {
        var t = this;
        return o(n.default.mark(function e() {
            var i, a, o, s;
            return n.default.wrap(function(e) {
                for (;;) switch (e.prev = e.next) {
                  case 0:
                    if (console.log("保存转盘"), !(t.data.zp_info.items_obj.length < 2)) {
                        e.next = 4;
                        break;
                    }
                    return wx.showToast({
                        title: "至少两个选项才能保存",
                        icon: "none"
                    }), e.abrupt("return");

                  case 4:
                    t.$bus.event.call("loading:show", !0), t.$bus.event.call("loading:setText", {
                        text: "保存中...",
                        status: 0
                    });
                    try {
                        u.loadMini();
                    } catch (t) {}
                    return console.log("即将保存转盘", t.data.zp_info), e.prev = 8, e.next = 11, l.updateOne(t.data.zp_info);

                  case 11:
                    s = e.sent, console.log(s), 0 === s.code ? (t.editStatus = 2, t.$bus.event.call("loading:setText", {
                        text: "保存成功",
                        status: 1
                    }), u.globalData.current_edit_zp = s.data, u.globalData._updateZpList = !0, t.addEvent("ok", "保存成功")) : (t.$bus.event.call("loading:setText", {
                        text: "保存失败",
                        status: 2
                    }), t.addEvent("error", JSON.stringify(s))), e.next = 20;
                    break;

                  case 16:
                    e.prev = 16, e.t0 = e.catch(8), t.addEvent("error", JSON.stringify(e.t0)), t.$bus.event.call("loading:setText", {
                        text: JSON.stringify(e.t0),
                        status: 2
                    });

                  case 20:
                    u.addLog({
                        id: "编辑转盘",
                        title: t.data.zp_info.title,
                        type: "保存成功",
                        c1: t.data.zp_info.items_obj.length,
                        c2: (null === (i = t.data.zp_info.settings) || void 0 === i ? void 0 : i.seconds) || 5,
                        p1: null !== (a = t.data.zp_info.settings) && void 0 !== a && a.no_repeat ? "不允许重复" : "允许重复",
                        p2: null !== (o = t.data.zp_info.settings) && void 0 !== o && o.hide_weight ? "隐藏概率" : "不隐藏",
                        top_c: t.top_c,
                        sub_c: t.sub_c
                    });

                  case 21:
                  case "end":
                    return e.stop();
                }
            }, e, null, [ [ 8, 16 ] ]);
        }))();
    },
    addEvent: function(t, e) {
        u.addEvent({
            id: "save_zp",
            title: this.data.zp_info.title,
            status: t,
            msg: e
        });
    },
    onBatchAdd: function(t) {
        var e = t.detail.rows;
        if (e && 0 !== e.length) {
            console.log("接收到批量添加事件", t.detail);
            var n, o = this.data.zp_info, s = i(e);
            try {
                for (s.s(); !(n = s.n()).done; ) {
                    var r = n.value, d = c[0];
                    if (o.items_obj.length > 0) {
                        var l = o.items_obj[o.items_obj.length - 1], u = this.$bus.store.get("colors_map")[l.color].index + 1;
                        d = u < c.length ? c[u] : c[0];
                    }
                    this.data.zp_info.items_obj.push({
                        id: Math.random().toString(36).substr(2, 5),
                        text: r,
                        color: d,
                        weight: 1
                    });
                }
            } catch (t) {
                s.e(t);
            } finally {
                s.f();
            }
            this.setData(a({}, "zp_info.items_obj", this.data.zp_info.items_obj));
        }
    },
    showBatchAdd: function() {
        this.$bus.event.call("batchAdd:show", !0);
    },
    onUnload: function() {}
});