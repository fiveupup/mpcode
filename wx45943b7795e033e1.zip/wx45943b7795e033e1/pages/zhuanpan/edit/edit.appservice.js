$gwx_XC_42=function(_,_v,_n,_p,_s,_wp,_wl,$gwn,$gwl,$gwh,wh,$gstack,$gwrt,gra,grb,TestTest,wfor,_ca,_da,_r,_rz,_o,_oz,_1,_1z,_2,_2z,_m,_mz,nv_getDate,nv_getRegExp,nv_console,nv_parseInt,nv_parseFloat,nv_isNaN,nv_isFinite,nv_decodeURI,nv_decodeURIComponent,nv_encodeURI,nv_encodeURIComponent,$gdc,nv_JSON,_af,_gv,_ai,_grp,_gd,_gapi,$ixc,_ic,_w,_ev,_tsd){return function(path,global){
if(typeof global==='undefined'){if (typeof __GWX_GLOBAL__==='undefined')global={};else global=__GWX_GLOBAL__;}if(typeof __WXML_GLOBAL__ === 'undefined') {__WXML_GLOBAL__={};
}__WXML_GLOBAL__.modules = __WXML_GLOBAL__.modules || {};
var e_={}
if(typeof(global.entrys)==='undefined')global.entrys={};e_=global.entrys;
var d_={}
if(typeof(global.defines)==='undefined')global.defines={};d_=global.defines;
var f_={}
if(typeof(global.modules)==='undefined')global.modules={};f_=global.modules || {};
var p_={}
__WXML_GLOBAL__.ops_cached = __WXML_GLOBAL__.ops_cached || {}
__WXML_GLOBAL__.ops_set = __WXML_GLOBAL__.ops_set || {};
__WXML_GLOBAL__.ops_init = __WXML_GLOBAL__.ops_init || {};
var z=__WXML_GLOBAL__.ops_set.$gwx_XC_42 || [];
function gz$gwx_XC_42_1(){
if( __WXML_GLOBAL__.ops_cached.$gwx_XC_42_1)return __WXML_GLOBAL__.ops_cached.$gwx_XC_42_1
__WXML_GLOBAL__.ops_cached.$gwx_XC_42_1=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
Z([3,'page'])
Z([3,'clearTitle'])
Z([3,'#ff3333'])
Z([3,'close'])
Z([3,'18px'])
Z([3,'margin-top:-15px'])
Z([[6],[[7],[3,'zp_info']],[3,'items_obj']])
Z([3,'id'])
Z([3,'option-wrap flex-space-between mt2 flex-align-center'])
Z([3,'delItem'])
Z([3,'flex-center mr1'])
Z([[7],[3,'index']])
Z([3,'width:16px'])
Z([3,'#fb6f88'])
Z([3,'cross'])
Z([3,'16'])
Z([3,'optionMore'])
Z([3,'#666'])
Z(z[11])
Z([3,'sjzp-gengduo'])
Z([3,'16px'])
Z([3,'width:50rpx'])
Z([3,'addNewItem'])
Z([3,'option-wrap mt2 flex'])
Z([3,'color: #1c90ff;padding: 14px'])
Z([3,'mr1'])
Z([3,'add-o'])
Z([3,'20px'])
Z([3,'showBatchAdd'])
Z(z[23])
Z(z[24])
Z(z[25])
Z([3,'sjzp-piliangtianjia'])
Z([3,'40rpx'])
Z([3,'mt3'])
Z([3,'item flex-space-between'])
Z([3,'mr2'])
Z([3,'sjzp-a-27Hguanbixunhuan'])
Z(z[27])
Z([3,'onChangeSetting'])
Z([[6],[[6],[[7],[3,'zp_info']],[3,'settings']],[3,'no_repeat']])
Z([3,'no_repeat'])
Z([3,'24px'])
Z(z[35])
Z(z[36])
Z([3,'sjzp-a-xuexijilulishijilushijian'])
Z([3,'21px'])
Z(z[39])
Z([3,'seconds'])
Z([3,'30'])
Z([3,'1'])
Z(z[50])
Z([[2,'||'],[[6],[[6],[[7],[3,'zp_info']],[3,'settings']],[3,'seconds']],[1,5]])
Z([[7],[3,'hideWeight']])
Z(z[35])
Z(z[36])
Z([3,'sjzp-yincang'])
Z(z[42])
Z(z[39])
Z([[6],[[6],[[7],[3,'zp_info']],[3,'settings']],[3,'hide_weight']])
Z([3,'hide_weight'])
Z(z[42])
Z([3,'saveZp'])
Z([3,'width:100%'])
Z([3,'large'])
Z([3,'info'])
Z([3,'onBatchAdd'])
})(__WXML_GLOBAL__.ops_cached.$gwx_XC_42_1);return __WXML_GLOBAL__.ops_cached.$gwx_XC_42_1
}
__WXML_GLOBAL__.ops_set.$gwx_XC_42=z;
__WXML_GLOBAL__.ops_init.$gwx_XC_42=true;
var x=['./pages/zhuanpan/edit/edit.wxml'];d_[x[0]]={}
var m0=function(e,s,r,gg){
var z=gz$gwx_XC_42_1()
var oLK=_n('view')
_rz(z,oLK,'class',0,e,s,gg)
var cMK=_mz(z,'van-icon',['bind:tap',1,'color',1,'name',2,'size',3],[],e,s,gg)
_(oLK,cMK)
var oNK=_n('view')
_rz(z,oNK,'style',5,e,s,gg)
var lOK=_v()
_(oNK,lOK)
var aPK=function(eRK,tQK,bSK,gg){
var xUK=_n('view')
_rz(z,xUK,'class',8,eRK,tQK,gg)
var oVK=_mz(z,'view',['bind:tap',9,'class',1,'data-index',2,'style',3],[],eRK,tQK,gg)
var fWK=_mz(z,'van-icon',['color',13,'name',1,'size',2],[],eRK,tQK,gg)
_(oVK,fWK)
_(xUK,oVK)
var cXK=_mz(z,'van-icon',['bind:tap',16,'color',1,'data-index',2,'name',3,'size',4,'style',5],[],eRK,tQK,gg)
_(xUK,cXK)
_(bSK,xUK)
return bSK
}
lOK.wxXCkey=4
_2z(z,6,aPK,e,s,gg,lOK,'item','index','id')
var hYK=_mz(z,'view',['catch:tap',22,'class',1,'style',2],[],e,s,gg)
var oZK=_mz(z,'van-icon',['class',25,'name',1,'size',2],[],e,s,gg)
_(hYK,oZK)
_(oNK,hYK)
var c1K=_mz(z,'view',['catch:tap',28,'class',1,'style',2],[],e,s,gg)
var o2K=_mz(z,'van-icon',['class',31,'name',1,'size',2],[],e,s,gg)
_(c1K,o2K)
_(oNK,c1K)
_(oLK,oNK)
var l3K=_n('view')
_rz(z,l3K,'class',34,e,s,gg)
var t5K=_n('view')
_rz(z,t5K,'class',35,e,s,gg)
var e6K=_mz(z,'van-icon',['class',36,'name',1,'size',2],[],e,s,gg)
_(t5K,e6K)
var b7K=_mz(z,'van-switch',['bind:change',39,'checked',1,'data-type',2,'size',3],[],e,s,gg)
_(t5K,b7K)
_(l3K,t5K)
var o8K=_n('view')
_rz(z,o8K,'class',43,e,s,gg)
var x9K=_mz(z,'van-icon',['class',44,'name',1,'size',2],[],e,s,gg)
_(o8K,x9K)
var o0K=_mz(z,'van-stepper',['bind:change',47,'data-type',1,'max',2,'min',3,'step',4,'value',5],[],e,s,gg)
_(o8K,o0K)
_(l3K,o8K)
var a4K=_v()
_(l3K,a4K)
if(_oz(z,53,e,s,gg)){a4K.wxVkey=1
var fAL=_n('view')
_rz(z,fAL,'class',54,e,s,gg)
var cBL=_mz(z,'van-icon',['class',55,'name',1,'size',2],[],e,s,gg)
_(fAL,cBL)
var hCL=_mz(z,'van-switch',['bind:change',58,'checked',1,'data-type',2,'size',3],[],e,s,gg)
_(fAL,hCL)
_(a4K,fAL)
}
a4K.wxXCkey=1
a4K.wxXCkey=3
_(oLK,l3K)
_(r,oLK)
var oDL=_mz(z,'van-button',['round',-1,'catch:tap',62,'customStyle',1,'size',2,'type',3],[],e,s,gg)
_(r,oDL)
var cEL=_n('colors')
_(r,cEL)
var oFL=_n('loading')
_(r,oFL)
var lGL=_n('more')
_(r,lGL)
var aHL=_n('batchAdd')
_rz(z,aHL,'bind:batchAdd',66,e,s,gg)
_(r,aHL)
return r
}
e_[x[0]]={f:m0,j:[],i:[],ti:[],ic:[]}
if(path&&e_[path]){
return function(env,dd,global){$gwxc=0;var root={"tag":"wx-page"};root.children=[]
;g="$gwx_XC_42";var main=e_[path].f
if (typeof global==="undefined")global={};global.f=$gdc(f_[path],"",1);
try{
main(env,{},root,global);
_tsd(root)
}catch(err){
console.log(err)
}
;g="";
return root;
}
}
}
}(__g.a,__g.b,__g.c,__g.d,__g.e,__g.f,__g.g,__g.h,__g.i,__g.j,__g.k,__g.l,__g.m,__g.n,__g.o,__g.p,__g.q,__g.r,__g.s,__g.t,__g.u,__g.v,__g.w,__g.x,__g.y,__g.z,__g.A,__g.B,__g.C,__g.D,__g.E,__g.F,__g.G,__g.H,__g.I,__g.J,__g.K,__g.L,__g.M,__g.N,__g.O,__g.P,__g.Q,__g.R,__g.S,__g.T,__g.U,__g.V,__g.W,__g.X,__g.Y,__g.Z,__g.aa);if(__vd_version_info__.delayedGwx||false)$gwx_XC_42();	if (__vd_version_info__.delayedGwx) __wxAppCode__['pages/zhuanpan/edit/edit.wxml'] = [$gwx_XC_42, './pages/zhuanpan/edit/edit.wxml'];else __wxAppCode__['pages/zhuanpan/edit/edit.wxml'] = $gwx_XC_42( './pages/zhuanpan/edit/edit.wxml' );
	;__wxRoute = "pages/zhuanpan/edit/edit";__wxRouteBegin = true;__wxAppCurrentFile__="pages/zhuanpan/edit/edit.js";define("pages/zhuanpan/edit/edit.js",function(require,module,exports,window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){
"use strict";var t,e=require("../../../@babel/runtime/helpers/interopRequireDefault"),i=require("../../../@babel/runtime/helpers/createForOfIteratorHelper"),a=require("../../../@babel/runtime/helpers/defineProperty"),n=e(require("../../../@babel/runtime/regenerator")),o=require("../../../@babel/runtime/helpers/asyncToGenerator"),s=require("../../../BD436B82415216BFDB250385AAE6EA57.js"),r=s.getTemplateZpInfo,c=(s.empty_zp,require("../../../D3DADA56415216BFB5BCB25179D6EA57.js")),d=require("../../../6BCCA7D4415216BF0DAACFD3DDD8EA57.js"),l=require("../../../8A51F322415216BFEC379B250C07EA57.js"),u=getApp();Page({behaviors:[wx.Bus,d],data:{zp_info:{},focus:!1,showSetting:!1,hideWeight:!1},checkHideWeight:function(){var t=this.data.zp_info.items_obj.some((function(t){return 1!==t.weight}));console.log("hasWeightNot1",t),t?this.setData({hideWeight:!0}):this.setData({hideWeight:!1})},onLoad:(t=o(n.default.mark((function t(e){var i,a,o;return n.default.wrap((function(t){for(;;)switch(t.prev=t.next){case 0:if("add"!==e.type){t.next=8;break}return this.setData({zp_info:JSON.parse(JSON.stringify(r()))}),wx.setNavigationBarTitle({title:"创建转盘"}),this.createType="add",u.addLog({id:"进入编辑",title:this.data.zp_info.title,type:"创建转盘"}),this.top_c="创建新的",this.sub_c="空白转盘",t.abrupt("return");case 8:if(!(i=e.id).startsWith("template_")){t.next=23;break}if(a=r(i),!i.startsWith("template_server_")){t.next=16;break}return t.next=14,l.getTemplateById(i);case 14:0===(o=t.sent).code?a=o.data:wx.showToast({title:"加载模板失败",icon:"none"});case 16:this.setData({zp_info:a}),u.addLog({id:"进入编辑",title:this.data.zp_info.title,type:"编辑转盘",p1:"系统模板"}),this.top_c="系统模板",this.sub_c=this.data.zp_info.title,this.checkHideWeight(),t.next=24;break;case 23:this.loadZpFromServer(i);case 24:this.editStatus=0;case 25:case"end":return t.stop()}}),t,this)}))),function(e){return t.apply(this,arguments)}),loadZpFromServer:function(t){var e=this;return o(n.default.mark((function i(){var a,o;return n.default.wrap((function(i){for(;;)switch(i.prev=i.next){case 0:return wx.showLoading({title:"加载中..."}),i.next=3,l.findOneById(t);case 3:a=i.sent,wx.hideLoading(),0===a.code&&((o=a.data).openid!==u.globalData.openid&&wx.setNavigationBarTitle({title:"创建转盘"}),e.setData({zp_info:o}),u.addLog({id:"进入编辑",title:e.data.zp_info.title,type:"编辑转盘",p1:"server"}),e.sub_c=e.data.zp_info.title,e.top_c=e.data.zp_info.openid===u.globalData.openid?"自己的转盘":"别人的转盘"),e.checkHideWeight();case 7:case"end":return i.stop()}}),i)})))()},clearTitle:function(){this.setData(a({},"zp_info.title",""))},delItem:function(t){var e;if(console.log("e",t),this.data.zp_info.items_obj.length<3)wx.showToast({title:"至少保留两个选项呀",icon:"none"});else{var i=t.currentTarget.dataset.index-0,n=this.data.zp_info;n.items_obj.splice(i,1),this.setData((a(e={},"zp_info.items_obj",n.items_obj),a(e,"focus",!1),e))}},addNewItem:function(){var t,e=c[0],i=this.data.zp_info;if(i.items_obj.length>0){var n=i.items_obj[i.items_obj.length-1],o=this.$bus.store.get("colors_map")[n.color],s=o?o.index+1:0;e=s&&s<c.length?c[s]:c[0]}var r=this.data.zp_info.items_obj.length,d=Math.random().toString(36).substr(2,5);this.setData((a(t={},"zp_info.items_obj[".concat(r,"]"),{id:d,text:"",color:e,weight:1}),a(t,"focus",!0),t)),this.checkHideWeight()},onEditOption:function(t){var e=t.currentTarget.dataset,i=e.index,n=e.type,o=t.detail.value;this.setData(a({},"zp_info.items_obj[".concat(i,"].").concat(n),o)),this.checkHideWeight()},onBlur:function(t){var e,i,n=t.currentTarget.dataset,o=n.index,s=n.type,r=parseInt(t.detail.value);Number.isNaN(r)||r<1?this.setData((a(e={},"zp_info.items_obj[".concat(o,"].").concat(s),1),a(e,"focus",!1),e)):this.setData((a(i={},"zp_info.items_obj[".concat(o,"].").concat(s),r),a(i,"focus",!1),i))},optionMore:function(t){var e=this,i=t.currentTarget.dataset.index,n=this.data.zp_info.items_obj,o=n[i];wx.showActionSheet({itemList:["📋 复制","👆 上移","👇 下移"],success:function(t){switch(t.tapIndex){case 0:var s=Object.assign({},o);n.splice(i+1,0,s);break;case 1:if(0===i)return void wx.showToast({title:"已经是第一个了",icon:"none"});var r=n[i];n[i]=n[i-1],n[i-1]=r;break;case 2:if(i===n.length-1)return void wx.showToast({title:"已经是最后一个了",icon:"none"});var c=n[i];n[i]=n[i+1],n[i+1]=c}e.setData(a({},"zp_info.items_obj",n))}})},onChangeTitle:function(t){this.setData(a({},"zp_info.title",t.detail.value)),this.editStatus=1},onChangeSetting:function(t){var e=t.currentTarget.dataset.type,i=t.detail;this.setData(a({},"zp_info.settings.".concat(e),i))},onSelColor:function(t){var e=t.currentTarget.dataset.index,i=this.data.zp_info.items_obj.map((function(t){return t.color}));this.$bus.event.call("colors:showColors",{index:e,selectedColor:i})},showSetting:function(){this.setData({showSetting:!0})},saveZp:function(){var t=this;return o(n.default.mark((function e(){var i,a,o,s;return n.default.wrap((function(e){for(;;)switch(e.prev=e.next){case 0:if(console.log("保存转盘"),!(t.data.zp_info.items_obj.length<2)){e.next=4;break}return wx.showToast({title:"至少两个选项才能保存",icon:"none"}),e.abrupt("return");case 4:t.$bus.event.call("loading:show",!0),t.$bus.event.call("loading:setText",{text:"保存中...",status:0});try{u.loadMini()}catch(t){}return console.log("即将保存转盘",t.data.zp_info),e.prev=8,e.next=11,l.updateOne(t.data.zp_info);case 11:s=e.sent,console.log(s),0===s.code?(t.editStatus=2,t.$bus.event.call("loading:setText",{text:"保存成功",status:1}),u.globalData.current_edit_zp=s.data,u.globalData._updateZpList=!0,t.addEvent("ok","保存成功")):(t.$bus.event.call("loading:setText",{text:"保存失败",status:2}),t.addEvent("error",JSON.stringify(s))),e.next=20;break;case 16:e.prev=16,e.t0=e.catch(8),t.addEvent("error",JSON.stringify(e.t0)),t.$bus.event.call("loading:setText",{text:JSON.stringify(e.t0),status:2});case 20:u.addLog({id:"编辑转盘",title:t.data.zp_info.title,type:"保存成功",c1:t.data.zp_info.items_obj.length,c2:(null===(i=t.data.zp_info.settings)||void 0===i?void 0:i.seconds)||5,p1:null!==(a=t.data.zp_info.settings)&&void 0!==a&&a.no_repeat?"不允许重复":"允许重复",p2:null!==(o=t.data.zp_info.settings)&&void 0!==o&&o.hide_weight?"隐藏概率":"不隐藏",top_c:t.top_c,sub_c:t.sub_c});case 21:case"end":return e.stop()}}),e,null,[[8,16]])})))()},addEvent:function(t,e){u.addEvent({id:"save_zp",title:this.data.zp_info.title,status:t,msg:e})},onBatchAdd:function(t){var e=t.detail.rows;if(e&&0!==e.length){console.log("接收到批量添加事件",t.detail);var n,o=this.data.zp_info,s=i(e);try{for(s.s();!(n=s.n()).done;){var r=n.value,d=c[0];if(o.items_obj.length>0){var l=o.items_obj[o.items_obj.length-1],u=this.$bus.store.get("colors_map")[l.color].index+1;d=u<c.length?c[u]:c[0]}this.data.zp_info.items_obj.push({id:Math.random().toString(36).substr(2,5),text:r,color:d,weight:1})}}catch(t){s.e(t)}finally{s.f()}this.setData(a({},"zp_info.items_obj",this.data.zp_info.items_obj))}},showBatchAdd:function(){this.$bus.event.call("batchAdd:show",!0)},onUnload:function(){}});
},{isPage:true,isComponent:true,currentFile:'pages/zhuanpan/edit/edit.js'});require("pages/zhuanpan/edit/edit.js");