var t = require("../../../@babel/runtime/helpers/createForOfIteratorHelper");

Page({
    data: {
        black: [],
        rest: []
    },
    onLoad: function(t) {
        var e = this;
        this.getOpenerEventChannel().on("getData", function(t) {
            e.initData(t);
        });
    },
    initData: function(e) {
        var n = wx.getStorageSync(e.cacheKey) || [], a = e.zpItems;
        console.log("initData", n, a), this.cacheKey = e.cacheKey;
        var i, c, o = [], r = t(n);
        try {
            var s = function() {
                var t = c.value, e = a.findIndex(function(e) {
                    return e.id === t;
                });
                -1 !== e && (o.push(a[e]), a.splice(e, 1));
            };
            for (r.s(); !(c = r.n()).done; ) s();
        } catch (t) {
            r.e(t);
        } finally {
            r.f();
        }
        o = o.reverse(), i = a, this.setData({
            black: o,
            rest: i
        });
    },
    handleDelete: function(t) {
        var e = t.currentTarget.dataset.id, n = this.data.black, a = this.data.rest, i = n.findIndex(function(t) {
            return t.id === e;
        }), c = n.splice(i, 1)[0];
        a.push(c), wx.setStorageSync(this.cacheKey, n.map(function(t) {
            return t.id;
        })), getApp().globalData._needupdateBlackList = !0, this.setData({
            black: n,
            rest: a
        });
    },
    onReady: function() {},
    onShow: function() {},
    onHide: function() {},
    onUnload: function() {},
    onPullDownRefresh: function() {},
    onReachBottom: function() {}
});