$gwx_XC_46=function(_,_v,_n,_p,_s,_wp,_wl,$gwn,$gwl,$gwh,wh,$gstack,$gwrt,gra,grb,TestTest,wfor,_ca,_da,_r,_rz,_o,_oz,_1,_1z,_2,_2z,_m,_mz,nv_getDate,nv_getRegExp,nv_console,nv_parseInt,nv_parseFloat,nv_isNaN,nv_isFinite,nv_decodeURI,nv_decodeURIComponent,nv_encodeURI,nv_encodeURIComponent,$gdc,nv_JSON,_af,_gv,_ai,_grp,_gd,_gapi,$ixc,_ic,_w,_ev,_tsd){return function(path,global){
if(typeof global==='undefined'){if (typeof __GWX_GLOBAL__==='undefined')global={};else global=__GWX_GLOBAL__;}if(typeof __WXML_GLOBAL__ === 'undefined') {__WXML_GLOBAL__={};
}__WXML_GLOBAL__.modules = __WXML_GLOBAL__.modules || {};
var e_={}
if(typeof(global.entrys)==='undefined')global.entrys={};e_=global.entrys;
var d_={}
if(typeof(global.defines)==='undefined')global.defines={};d_=global.defines;
var f_={}
if(typeof(global.modules)==='undefined')global.modules={};f_=global.modules || {};
var p_={}
__WXML_GLOBAL__.ops_cached = __WXML_GLOBAL__.ops_cached || {}
__WXML_GLOBAL__.ops_set = __WXML_GLOBAL__.ops_set || {};
__WXML_GLOBAL__.ops_init = __WXML_GLOBAL__.ops_init || {};
var z=__WXML_GLOBAL__.ops_set.$gwx_XC_46 || [];
function gz$gwx_XC_46_1(){
if( __WXML_GLOBAL__.ops_cached.$gwx_XC_46_1)return __WXML_GLOBAL__.ops_cached.$gwx_XC_46_1
__WXML_GLOBAL__.ops_cached.$gwx_XC_46_1=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
Z([[2,'?:'],[[2,'>'],[[6],[[7],[3,'list']],[3,'length']],[1,0]],[1,1],[1,0]])
Z([3,'true'])
Z([a,[3,'已抽选项('],[[6],[[7],[3,'black']],[3,'length']],[3,')']])
Z([[7],[3,'black']])
Z([3,'handleDelete'])
Z([[6],[[7],[3,'item']],[3,'id']])
Z([3,'delete-o'])
Z([a,[3,'未抽选项('],[[6],[[7],[3,'rest']],[3,'length']],z[2][3]])
})(__WXML_GLOBAL__.ops_cached.$gwx_XC_46_1);return __WXML_GLOBAL__.ops_cached.$gwx_XC_46_1
}
__WXML_GLOBAL__.ops_set.$gwx_XC_46=z;
__WXML_GLOBAL__.ops_init.$gwx_XC_46=true;
var x=['./pages/zhuanpan/summarize_page/summarize_page.wxml'];d_[x[0]]={}
var m0=function(e,s,r,gg){
var z=gz$gwx_XC_46_1()
var l1M=_mz(z,'van-tabs',['active',0,'swipeable',1],[],e,s,gg)
var a2M=_n('van-tab')
_rz(z,a2M,'title',2,e,s,gg)
var t3M=_v()
_(a2M,t3M)
var e4M=function(o6M,b5M,x7M,gg){
var f9M=_mz(z,'view',['catch:tap',4,'data-id',1],[],o6M,b5M,gg)
var c0M=_n('van-icon')
_rz(z,c0M,'name',6,o6M,b5M,gg)
_(f9M,c0M)
_(x7M,f9M)
return x7M
}
t3M.wxXCkey=4
_2z(z,3,e4M,e,s,gg,t3M,'item','index','')
_(l1M,a2M)
var hAN=_n('van-tab')
_rz(z,hAN,'title',7,e,s,gg)
_(l1M,hAN)
_(r,l1M)
return r
}
e_[x[0]]={f:m0,j:[],i:[],ti:[],ic:[]}
if(path&&e_[path]){
return function(env,dd,global){$gwxc=0;var root={"tag":"wx-page"};root.children=[]
;g="$gwx_XC_46";var main=e_[path].f
if (typeof global==="undefined")global={};global.f=$gdc(f_[path],"",1);
try{
main(env,{},root,global);
_tsd(root)
}catch(err){
console.log(err)
}
;g="";
return root;
}
}
}
}(__g.a,__g.b,__g.c,__g.d,__g.e,__g.f,__g.g,__g.h,__g.i,__g.j,__g.k,__g.l,__g.m,__g.n,__g.o,__g.p,__g.q,__g.r,__g.s,__g.t,__g.u,__g.v,__g.w,__g.x,__g.y,__g.z,__g.A,__g.B,__g.C,__g.D,__g.E,__g.F,__g.G,__g.H,__g.I,__g.J,__g.K,__g.L,__g.M,__g.N,__g.O,__g.P,__g.Q,__g.R,__g.S,__g.T,__g.U,__g.V,__g.W,__g.X,__g.Y,__g.Z,__g.aa);if(__vd_version_info__.delayedGwx||false)$gwx_XC_46();	if (__vd_version_info__.delayedGwx) __wxAppCode__['pages/zhuanpan/summarize_page/summarize_page.wxml'] = [$gwx_XC_46, './pages/zhuanpan/summarize_page/summarize_page.wxml'];else __wxAppCode__['pages/zhuanpan/summarize_page/summarize_page.wxml'] = $gwx_XC_46( './pages/zhuanpan/summarize_page/summarize_page.wxml' );
	;__wxRoute = "pages/zhuanpan/summarize_page/summarize_page";__wxRouteBegin = true;__wxAppCurrentFile__="pages/zhuanpan/summarize_page/summarize_page.js";define("pages/zhuanpan/summarize_page/summarize_page.js",function(require,module,exports,window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){
"use strict";var t=require("../../../@babel/runtime/helpers/createForOfIteratorHelper");Page({data:{black:[],rest:[]},onLoad:function(t){var e=this;this.getOpenerEventChannel().on("getData",(function(t){e.initData(t)}))},initData:function(e){var n=wx.getStorageSync(e.cacheKey)||[],a=e.zpItems;console.log("initData",n,a),this.cacheKey=e.cacheKey;var i,c,o=[],r=t(n);try{var s=function(){var t=c.value,e=a.findIndex((function(e){return e.id===t}));-1!==e&&(o.push(a[e]),a.splice(e,1))};for(r.s();!(c=r.n()).done;)s()}catch(t){r.e(t)}finally{r.f()}o=o.reverse(),i=a,this.setData({black:o,rest:i})},handleDelete:function(t){var e=t.currentTarget.dataset.id,n=this.data.black,a=this.data.rest,i=n.findIndex((function(t){return t.id===e})),c=n.splice(i,1)[0];a.push(c),wx.setStorageSync(this.cacheKey,n.map((function(t){return t.id}))),getApp().globalData._needupdateBlackList=!0,this.setData({black:n,rest:a})},onReady:function(){},onShow:function(){},onHide:function(){},onUnload:function(){},onPullDownRefresh:function(){},onReachBottom:function(){}});
},{isPage:true,isComponent:true,currentFile:'pages/zhuanpan/summarize_page/summarize_page.js'});require("pages/zhuanpan/summarize_page/summarize_page.js");