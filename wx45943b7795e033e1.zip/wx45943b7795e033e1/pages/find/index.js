getApp();

Page({
    data: {
        waimaiUrl: ""
    },
    toNum: function() {
        wx.navigateTo({
            url: "/p2/number/index"
        });
    },
    toShaizi: function() {
        wx.navigateTo({
            url: "/p2/shaizi/shaizi"
        });
    },
    toWaimai: function() {
        wx.navigateTo({
            url: "/pages/webview/webview?url=".concat(encodeURIComponent(this.data.waimaiUrl))
        });
    },
    onLoad: function(n) {
        var i = wx.getStorageSync("config");
        i && i.waimai && this.setData({
            waimaiUrl: i.waimai
        });
    },
    onReady: function() {},
    onShow: function() {},
    onHide: function() {},
    onUnload: function() {},
    onPullDownRefresh: function() {},
    onReachBottom: function() {},
    onShareAppMessage: function() {}
});