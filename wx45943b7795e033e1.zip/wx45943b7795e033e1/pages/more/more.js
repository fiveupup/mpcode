var e = require("../../@babel/runtime/helpers/interopRequireDefault")(require("../../@babel/runtime/regenerator")), t = require("../../@babel/runtime/helpers/asyncToGenerator"), n = require("../../8A51F322415216BFEC379B250C07EA57.js").loadTemplates;

Page({
    data: {
        templates: [],
        all_count: 0,
        limit: 20,
        offset: 0
    },
    onLoad: function(a) {
        var o = this;
        return t(e.default.mark(function t() {
            var a;
            return e.default.wrap(function(e) {
                for (;;) switch (e.prev = e.next) {
                  case 0:
                    return e.next = 2, n({
                        offset: o.data.offset,
                        limit: o.data.limit
                    });

                  case 2:
                    a = e.sent, console.log(a), 0 === a.code && o.setData({
                        all_count: a.data.count,
                        templates: a.data.list
                    });

                  case 5:
                  case "end":
                    return e.stop();
                }
            }, t);
        }))();
    },
    toZp: function(e) {
        var t = e.currentTarget.dataset.id;
        wx.navigateTo({
            url: "/pages/zhuanpan/index/index?id=".concat(t, "&from=template")
        });
    },
    onReady: function() {},
    onShow: function() {},
    onHide: function() {},
    onUnload: function() {},
    onPullDownRefresh: function() {},
    onReachBottom: function() {},
    onShareAppMessage: function() {}
});