(wx["webpackJsonp"] = wx["webpackJsonp"] || []).push([ [ 398 ], {
    5349: function() {
        var n, o = new Set(), t = new Set();
        wx.onNeedPrivacyAuthorization && wx.onNeedPrivacyAuthorization(function(o) {
            console.log("触发 onNeedPrivacyAuthorization"), "function" === typeof n && n(o);
        });
        var e = function(n) {
            t.forEach(function(o) {
                n !== o && o();
            });
        };
        Component({
            data: {
                title: "用户隐私保护提示",
                desc1: "感谢您使用本工具，您使用本工具前应当阅并同意",
                urlTitle: "《用户隐私保护指引》",
                desc2: "当您点击同意并开始时用产品服务时，即表示你已理解并同息该条款内容，该条款将对您产生法律约束力。如您拒绝，将无法使用工具生成头像。",
                innerShow: !1,
                height: 0
            },
            lifetimes: {
                attached: function() {
                    var i = this, c = function() {
                        i.disPopUp();
                    };
                    n = function(n) {
                        o.add(n), i.popUp(), e(c);
                    }, this.closePopUp = c, t.add(this.closePopUp);
                },
                detached: function() {
                    t.delete(this.closePopUp);
                }
            },
            pageLifetimes: {
                show: function() {
                    var t = this;
                    this.closePopUp && (n = function(n) {
                        o.add(n), t.popUp(), e(t.closePopUp);
                    });
                }
            },
            methods: {
                handleAgree: function(n) {
                    this.disPopUp(), o.forEach(function(n) {
                        n({
                            event: "agree",
                            buttonId: "agree-btn"
                        });
                    }), o.clear();
                },
                handleDisagree: function(n) {
                    this.disPopUp(), o.forEach(function(n) {
                        n({
                            event: "disagree"
                        });
                    }), o.clear();
                },
                popUp: function() {
                    !1 === this.data.innerShow && this.setData({
                        innerShow: !0
                    });
                },
                disPopUp: function() {
                    !0 === this.data.innerShow && this.setData({
                        innerShow: !1
                    });
                },
                openPrivacyContract: function() {
                    wx.openPrivacyContract({
                        success: function(n) {
                            console.log("openPrivacyContract success");
                        },
                        fail: function(n) {
                            console.error("openPrivacyContract fail", n);
                        }
                    });
                }
            }
        });
    }
}, function(n) {
    var o = function(o) {
        return n(n.s = o);
    };
    o(5349);
} ]);