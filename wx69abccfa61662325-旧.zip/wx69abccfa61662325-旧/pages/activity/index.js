(wx["webpackJsonp"] = wx["webpackJsonp"] || []).push([ [ 530 ], {
    7238: function(n, a, e) {
        var i = e(2180), t = e(1515), r = e(2954), s = e.n(r), c = e(9572), o = e(5413), l = e(5893);
        function u() {
            var n;
            return (0, l.jsxs)(t.G7, {
                className: "wrapper",
                children: [ (0, l.jsx)(c.Z, {
                    title: "活动页",
                    showBackBtn: !0
                }), (0, l.jsxs)(t.G7, {
                    className: "components-warper",
                    children: [ (0, l.jsx)(t.G7, {
                        className: "title",
                        children: " 2023 年活动"
                    }), null === (n = [ {
                        url: "/pages/page101/index",
                        imagePath: o
                    } ]) || void 0 === n ? void 0 : n.map(function(n, a) {
                        return (0, l.jsx)(t.G7, {
                            className: "activity-list",
                            onClick: function() {
                                s().navigateTo({
                                    url: null === n || void 0 === n ? void 0 : n.url
                                });
                            },
                            children: (0, l.jsx)(t.Ee, {
                                src: null === n || void 0 === n ? void 0 : n.imagePath
                            })
                        }, a);
                    }) ]
                }) ]
            });
        }
        var v = {
            navigationBarTitleText: "首页"
        };
        Page((0, i.createPageConfig)(u, "pages/activity/index", {
            root: {
                cn: []
            }
        }, v || {}));
    }
}, function(n) {
    var a = function(a) {
        return n(n.s = a);
    };
    n.O(0, [ 107, 216, 592 ], function() {
        return a(7238);
    });
    n.O();
} ]);