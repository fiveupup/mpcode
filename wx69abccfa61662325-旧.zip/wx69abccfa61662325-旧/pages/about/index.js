(wx["webpackJsonp"] = wx["webpackJsonp"] || []).push([ [ 567 ], {
    692: function(e, s, n) {
        var r = n(2180), i = n(1515), t = n(9572), c = n.p + "images/logo_text_horizontal.svg", o = n.p + "images/logo_text.png", a = n(5893);
        function x() {
            return (0, a.jsxs)(i.G7, {
                className: "wrapper",
                children: [ (0, a.jsx)(t.Z, {
                    title: "关于",
                    showBackBtn: !0
                }), (0, a.jsxs)(i.G7, {
                    className: "components-warper",
                    children: [ (0, a.jsx)(i.Ee, {
                        src: o
                    }), (0, a.jsx)(i.xv, {
                        children: "不知道有和我一样喜欢经常换头像的人吗？为了方便更换微信头像，我们开发了这个小程序。"
                    }), (0, a.jsx)(i.xv, {
                        children: "功能都很简单啦，我们也不希望让这个工具变得复杂。其中「头像挂件」适合用在类似微信这种“正方形”头像上，可能不太适配一些“圆形”头像的社交平台。"
                    }), (0, a.jsx)(i.xv, {
                        children: "另外，我们会经常更新哦，记得常来瞧瞧～"
                    }), (0, a.jsxs)(i.G7, {
                        className: "footer",
                        children: [ (0, a.jsx)(i.Ee, {
                            src: c
                        }), (0, a.jsxs)(i.G7, {
                            className: "copyRight",
                            children: [ (0, a.jsx)(i.G7, {
                                children: "Copyright © 2023 MAN! GO Studio."
                            }), (0, a.jsx)(i.G7, {
                                children: "Designed by YorKun, Coded by ZiMing."
                            }) ]
                        }) ]
                    }) ]
                }) ]
            });
        }
        var l = {
            navigationBarTitleText: "首页"
        };
        Page((0, r.createPageConfig)(x, "pages/about/index", {
            root: {
                cn: []
            }
        }, l || {}));
    }
}, function(e) {
    var s = function(s) {
        return e(e.s = s);
    };
    e.O(0, [ 107, 216, 592 ], function() {
        return s(692);
    });
    e.O();
} ]);