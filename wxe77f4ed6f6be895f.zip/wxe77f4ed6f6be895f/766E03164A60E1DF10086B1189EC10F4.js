var e, r = require("@babel/runtime/helpers/typeof.js");

e = function(e) {
    return e.HmacSHA512;
}, "object" === ("undefined" == typeof exports ? "undefined" : r(exports)) ? module.exports = exports = e(require("026E56734A60E1DF64083E7464EB10F4.js"), require("ABE5E3114A60E1DFCD838B16B07E10F4.js"), require("819B0FE64A60E1DFE7FD67E1E15E10F4.js"), require("21AAF9974A60E1DF47CC9190CAFC10F4.js")) : "function" == typeof define && define.amd ? define([ "./core", "./x64-core", "./sha512", "./hmac" ], e) : e((void 0).CryptoJS);