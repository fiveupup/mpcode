var e, r = require("@babel/runtime/helpers/typeof.js");

e = function(e) {
    return e.mode.CFB = function() {
        var r = e.lib.BlockCipherMode.extend();
        function i(e, r, i, o) {
            var c, t = this._iv;
            t ? (c = t.slice(0), this._iv = void 0) : c = this._prevBlock, o.encryptBlock(c, 0);
            for (var n = 0; n < i; n++) e[r + n] ^= c[n];
        }
        return r.Encryptor = r.extend({
            processBlock: function(e, r) {
                var o = this._cipher, c = o.blockSize;
                i.call(this, e, r, c, o), this._prevBlock = e.slice(r, r + c);
            }
        }), r.Decryptor = r.extend({
            processBlock: function(e, r) {
                var o = this._cipher, c = o.blockSize, t = e.slice(r, r + c);
                i.call(this, e, r, c, o), this._prevBlock = t;
            }
        }), r;
    }(), e.mode.CFB;
}, "object" === ("undefined" == typeof exports ? "undefined" : r(exports)) ? module.exports = exports = e(require("026E56734A60E1DF64083E7464EB10F4.js"), require("D31415734A60E1DFB5727D74A3DB10F4.js")) : "function" == typeof define && define.amd ? define([ "./core", "./cipher-core" ], e) : e((void 0).CryptoJS);