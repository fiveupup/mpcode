require("../../utils/wxParse/wxParse.js");

var t = require("../../13753E374A60E1DF75135630065B10F4.js");

Component({
    options: {
        multipleSlots: !0
    },
    properties: {
        inCollection: {
            type: Number,
            value: 0
        },
        nowQid: {
            type: Number,
            value: 0
        },
        ajaxData: {
            type: Object,
            value: {}
        },
        isCollectUrl: {
            type: Number,
            value: 0
        },
        paramAtoB: {
            type: Boolean,
            value: !1
        },
        btn_no: {
            type: String,
            value: "取消"
        },
        btn_ok: {
            type: String,
            value: "确定"
        }
    },
    data: {
        flag: !0
    },
    methods: {
        collection: function(e) {
            var a = e.currentTarget.dataset.id, i = this.data.ajaxData.data[this.data.nowQid].id;
            a ? (t.removeCollection(i), this.setData({
                inCollection: 0
            })) : (t.addCollection(i), this.setData({
                inCollection: 1
            }));
        },
        tofeedback: function() {
            wx.navigateTo({
                url: "../errorFebeck/errorFebeck?questionId=" + this.data.ajaxData.data[this.data.nowQid].id
            });
        },
        change: function() {
            this.triggerEvent("myevent", {
                ifCardShow: !0
            });
        },
        _error: function() {
            this.triggerEvent("error");
        },
        _success: function() {
            this.triggerEvent("success");
        }
    }
});