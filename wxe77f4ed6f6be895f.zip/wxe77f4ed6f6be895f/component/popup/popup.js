Component({
    options: {
        multipleSlots: !0
    },
    properties: {
        title: {
            type: String,
            value: "标题"
        },
        content: {
            type: Object,
            value: "内容"
        },
        myAnswer: {
            type: String,
            value: "内容"
        },
        analysisFile: {
            type: Array,
            value: []
        },
        rightAnswer: {
            type: String,
            value: "内容"
        },
        btn_no: {
            type: String,
            value: "取消"
        },
        btn_ok: {
            type: String,
            value: "确定"
        }
    },
    data: {
        flag: !0
    },
    methods: {
        hidePopup: function() {
            this.setData({
                flag: 1
            });
        },
        showPopup: function() {
            this.setData({
                flag: 0
            });
        },
        _error: function() {
            this.triggerEvent("error");
        },
        _success: function() {
            this.triggerEvent("success");
        },
        checkDetail: function(t) {
            wx.navigateTo({
                url: "/pages/collectBookDetail/index?id=" + t.currentTarget.dataset.id
            });
        }
    }
});