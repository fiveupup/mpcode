Component({
    properties: {
        propArray: {
            type: Array
        }
    },
    data: {
        selectShow: !1,
        nowText: "请选择",
        animationData: {},
        selectid: ""
    },
    methods: {
        selectToggle: function() {
            var t = this.data.selectShow, e = wx.createAnimation({
                timingFunction: "ease"
            });
            this.animation = e, t ? (e.rotate(0).step(), this.setData({
                animationData: e.export()
            })) : (e.rotate(180).step(), this.setData({
                animationData: e.export()
            })), this.setData({
                selectShow: !t
            });
        },
        setText: function(t) {
            var e = this.properties.propArray, a = t.target.dataset.index, i = t.target.dataset.id, s = e[a].text;
            this.animation.rotate(0).step(), this.setData({
                selectShow: !1,
                nowText: s,
                selectid: i,
                animationData: this.animation.export()
            }), this.triggerEvent("eventListener", {
                selectid: this.data.selectid
            });
        }
    }
});