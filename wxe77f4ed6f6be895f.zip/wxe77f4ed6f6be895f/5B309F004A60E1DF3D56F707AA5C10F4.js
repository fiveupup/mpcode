var e, r = require("@babel/runtime/helpers/typeof.js");

e = function(e) {
    var r, t, i, n, o, a, c;
    return t = (r = e).lib, i = t.Base, n = t.WordArray, o = r.algo, a = o.MD5, c = o.EvpKDF = i.extend({
        cfg: i.extend({
            keySize: 4,
            hasher: a,
            iterations: 1
        }),
        init: function(e) {
            this.cfg = this.cfg.extend(e);
        },
        compute: function(e, r) {
            for (var t, i = this.cfg, o = i.hasher.create(), a = n.create(), c = a.words, s = i.keySize, f = i.iterations; c.length < s; ) {
                t && o.update(t), t = o.update(e).finalize(r), o.reset();
                for (var u = 1; u < f; u++) t = o.finalize(t), o.reset();
                a.concat(t);
            }
            return a.sigBytes = 4 * s, a;
        }
    }), r.EvpKDF = function(e, r, t) {
        return c.create(t).compute(e, r);
    }, e.EvpKDF;
}, "object" === ("undefined" == typeof exports ? "undefined" : r(exports)) ? module.exports = exports = e(require("026E56734A60E1DF64083E7464EB10F4.js"), require("EFE62A834A60E1DF89804284B61E10F4.js"), require("21AAF9974A60E1DF47CC9190CAFC10F4.js")) : "function" == typeof define && define.amd ? define([ "./core", "./sha1", "./hmac" ], e) : e((void 0).CryptoJS);