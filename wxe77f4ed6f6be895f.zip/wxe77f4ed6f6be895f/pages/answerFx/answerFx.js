var e = require("../../58E7CAE54A60E1DF3E81A2E229AB10F4.js");

getApp();

Page({
    data: {
        ec: {
            lazyLoad: !1
        },
        answerinfo: {},
        id: "",
        examinationId: "",
        wrong: 0,
        notanswer: 0,
        right: 0,
        all: 0,
        ranks: 0,
        usetime: 0,
        examType: "",
        web_url: getApp().web_config.web_url
    },
    onLoad: function(e) {
        this.setData({
            recordId: e.id ? e.id : "",
            examinationId: e.examinationId ? e.examinationId : "",
            examType: e.examType ? e.examType : "",
            id: e.id
        }), this.getAnswerinfo();
    },
    init_pieCharts: function() {
        var e = this;
        this.piechartsComponnet.init(function(t, a, i) {
            var n = echarts.init(t, null, {
                width: a,
                height: i
            });
            return n.setOption(e.getPieOption()), n;
        });
    },
    getPieOption: function() {
        return {
            tooltip: {
                show: !0,
                formatter: "{a} <br/>{b} : {c} ({d}%)"
            },
            toolbox: {
                show: !0,
                feature: {
                    mark: {
                        show: !0
                    },
                    dataView: {
                        show: !0,
                        readOnly: !1
                    },
                    restore: {
                        show: !0
                    },
                    saveAsImage: {
                        show: !0
                    }
                }
            },
            color: [ "#56cbff", "#ff6300" ],
            calculable: !0,
            series: [ {
                name: "分类",
                type: "pie",
                center: [ "50%", "50%" ],
                radius: 80,
                itemStyle: {
                    normal: {
                        label: {
                            show: !0,
                            position: "inner",
                            formatter: function(e) {
                                return (e.percent - 0).toFixed(0) + "%";
                            }
                        },
                        labelLine: {
                            show: !1
                        }
                    },
                    emphasis: {
                        label: {
                            show: !0,
                            formatter: "{b}\n{d}%"
                        }
                    }
                },
                data: [ {
                    value: 99,
                    name: "A"
                }, {
                    value: 1,
                    name: "B"
                } ]
            } ]
        };
    },
    getAnswerinfo: function() {
        var t = this;
        wx.request({
            url: getApp().web_config.web_url + "/api/examination/viewRecord",
            data: {
                recordId: t.data.id
            },
            header: {
                "content-type": "application/x-www-form-urlencoded",
                cookie: "SESSION=" + wx.getStorageSync("3rd_session")
            },
            method: "POST",
            success: function(a) {
                if (0 == a.data.status) {
                    for (var i = a.data.data, n = i.questionTypeSummaries, r = 0, s = 0, o = 0, l = 0, d = 0; d < n.length; d++) {
                        if (n[d].questions.length > 0) for (var c = 0; c < n[d].questions.length; c++) 1 == n[d].questions[c].checkResult ? r += 1 : n[d].questions[c].userAnswer ? s += 1 : o += 1;
                        l += 1;
                    }
                    if (1 == i.currentUserScoreRanking) var u = "100%"; else u = 0 == (u = Math.round(i.currentUserScoreRanking / i.totalExaminationUserNumbers * 1e4) / 100 + "%") ? 1 : u;
                    var w = Date.parse(i.beginTime), h = Date.parse(i.endTime), p = parseInt((h - w) / 6e4);
                    new e({
                        canvasId: "canvas1",
                        type: "pie",
                        series: [ {
                            name: "未做提",
                            data: o
                        }, {
                            name: "答错题",
                            data: s
                        }, {
                            name: "答对题",
                            data: r
                        } ],
                        width: 200,
                        height: 200,
                        titleFontSize: 30,
                        dataLabel: !0
                    }), t.setData({
                        right: r,
                        usetime: p || 1,
                        all: l,
                        wrong: s,
                        notanswer: o,
                        answerinfo: i,
                        ranks: u
                    });
                } else getApp().chkResponse(a);
            },
            fail: function(e) {
                getApp().requestError();
            }
        });
    },
    goonlineAnswer: function() {
        wx.navigateTo({
            url: "/pages/startAnswer/startAnswer?status=重新考试&isCollectUrl=2&id=" + this.data.examinationId
        });
    },
    reviewAnswer: function() {
        wx.redirectTo({
            url: "../singleChoiceDetail/singleChoiceDetail?isCollectUrl=3&recordId=" + this.data.id + "&examType=" + this.data.examType
        });
    }
});