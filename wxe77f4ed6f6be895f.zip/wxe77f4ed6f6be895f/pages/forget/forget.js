var t = require("../../E06A3E954A60E1DF860C5692828B10F4.js");

Page({
    data: {
        login_member: "",
        login_code: null,
        input_login_code: "",
        get_code_status: !0,
        show_get_code: "获取验证码",
        get_code_time: 60,
        verifyCode: "",
        yzmurl: "",
        mobileM: "",
        code: "",
        yzmCodeUrl: "",
        picAddress: getApp().web_config.web_url,
        newpwd: "",
        newpwd2: ""
    },
    onLoad: function(t) {
        this.createCode();
    },
    pwdSubmit: function() {
        if ("" == this.data.login_member) return wx.showToast({
            title: "手机号不能为空",
            icon: "none",
            duration: 1e3
        }), !1;
        if (/^1\d{10}$/.test(this.data.login_member)) return "" == this.data.verifyCode.toUpperCase() ? (wx.showToast({
            title: "图片验证码不能为空",
            icon: "none",
            duration: 2e3
        }), !1) : "" == this.data.mobileM ? (wx.showToast({
            title: "手机验证码不能为空",
            icon: "none",
            duration: 2e3
        }), !1) : "" == this.data.newpwd || "" == this.data.newpwd2 ? (wx.showToast({
            title: "密码不能为空",
            icon: "none",
            duration: 1e3
        }), !1) : this.data.newpwd != this.data.newpwd2 ? (wx.showToast({
            title: "两次密码输入不一致",
            icon: "none",
            duration: 1e3
        }), !1) : void wx.request({
            url: getApp().web_config.web_url + "/api/candidate/findPwd",
            method: "post",
            header: {
                "content-type": "application/x-www-form-urlencoded"
            },
            data: {
                mobile: this.data.login_member,
                password: t.hexMD5(this.data.newpwd),
                verifyCode: this.data.mobileM
            },
            success: function(t) {
                0 == t.data.status ? wx.showToast({
                    title: "密码修改成功",
                    icon: "none",
                    duration: 3e3,
                    success: function() {
                        wx.reLaunch({
                            url: "/pages/login/login"
                        });
                    }
                }) : wx.showToast({
                    title: "手机" + t.data.message,
                    icon: "none",
                    duration: 3e3
                });
            },
            fail: function(t) {
                getApp().requestError();
            }
        });
        wx.showToast({
            title: "请输入正确的手机号",
            icon: "none",
            duration: 1e3
        });
    },
    input_val: function(t) {
        var e = t.detail.value;
        this.setData({
            login_member: e
        });
    },
    pic_val: function(t) {
        var e = t.detail.value;
        this.setData({
            yzm: e
        });
    },
    yzmInput: function(t) {
        this.setData({
            verifyCode: t.detail.value
        });
    },
    regcodeValue: function(t) {
        this.setData({
            mobileM: t.detail.value
        });
    },
    huanyizhang: function() {
        this.createCode();
    },
    newpwd_input: function(t) {
        this.setData({
            newpwd: t.detail.value
        });
    },
    newpwd2_input: function(t) {
        this.setData({
            newpwd2: t.detail.value
        });
    },
    createCode: function() {
        this.setData({
            yzmCodeUrl: this.data.picAddress + "/api/kaptcha?t=" + Date.now() + "&userCard=" + wx.getStorageSync("userCard")
        });
    },
    check: function() {
        if ("" == this.data.login_member) return wx.showToast({
            title: "手机号不能为空",
            icon: "none",
            duration: 1e3
        }), !1;
        if (/^1\d{10}$/.test(this.data.login_member)) {
            if ("" == this.data.verifyCode.toUpperCase()) return wx.showToast({
                title: "图片验证码不能为空",
                icon: "none",
                duration: 2e3
            }), !1;
            if (this.data.get_code_status) if (11 == this.data.login_member.length) /^1\d{10}$/.test(this.data.login_member) ? this.get_code() : wx.showToast({
                title: "请输入正确的手机号",
                icon: "loading",
                duration: 1e3
            }); else wx.showToast({
                title: "请输入完整手机号",
                icon: "loading",
                duration: 1e3
            }); else wx.showToast({
                title: "正在获取",
                icon: "loading",
                duration: 1e3
            });
        } else wx.showToast({
            title: "请输入正确的手机号",
            icon: "none",
            duration: 1e3
        });
    },
    get_code: function() {
        this.setData({
            get_code_status: !1
        });
        var t = this;
        wx.request({
            url: getApp().web_config.web_url + "/api/candidate/getSMSCode?userCard=" + wx.getStorageSync("userCard"),
            data: {
                mobile: t.data.login_member,
                verifyCode: t.data.verifyCode,
                module: "pwd"
            },
            method: "post",
            header: {
                "content-type": "application/x-www-form-urlencoded"
            },
            success: function(e) {
                if (0 == e.data.status) var a = setInterval(function() {
                    t.data.get_code_time > 0 ? t.setData({
                        get_code_time: t.data.get_code_time - 1,
                        show_get_code: "剩余" + (t.data.get_code_time - 1) + "秒",
                        get_code_status: !1
                    }) : (clearInterval(a), t.setData({
                        get_code_time: 60,
                        show_get_code: "获取验证码",
                        get_code_status: !0
                    }));
                }, 1e3); else wx.showToast({
                    title: e.data.message,
                    icon: "none",
                    duration: 1e3
                }), t.setData({
                    get_code_status: !0
                });
            },
            fail: function(t) {
                wx.showToast({
                    title: "请求失败",
                    icon: "loading",
                    duration: 1e3
                });
            }
        });
    }
});