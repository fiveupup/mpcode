Page({
    data: {
        type: 1,
        answerData: []
    },
    onLoad: function(t) {
        this.setData({
            type: t.type ? t.type : 1
        }), this.getWeekData();
    },
    getWeekData: function() {
        var t = this;
        wx.request({
            url: getApp().web_config.web_url + "/api/examination/listExamination",
            data: {
                pageSize: 1,
                curPage: 1,
                examType: "009002"
            },
            header: {
                "content-type": "application/json",
                cookie: "SESSION=" + wx.getStorageSync("3rd_session")
            },
            method: "GET",
            success: function(a) {
                0 == a.data.status ? a.data.data.rows.length > 0 && t.setData({
                    answerData: a.data.data.rows[0]
                }) : getApp().chkResponse(a);
            },
            fail: function(t) {
                getApp().requestError();
            }
        });
    },
    goAnswerFx: function() {
        wx.redirectTo({
            url: "/pages/answerFx/answerFx?id=" + this.data.answerData.examRecords[0].id + "&examinationId=" + this.data.answerData.id
        });
    },
    reStart: function() {
        wx.request({
            url: getApp().web_config.web_url + "/api/examination/listExamination",
            data: {
                pageSize: 1,
                curPage: 1,
                examType: "009002"
            },
            header: {
                "content-type": "application/json",
                cookie: "SESSION=" + wx.getStorageSync("3rd_session")
            },
            method: "GET",
            success: function(t) {
                0 == t.data.status ? t.data.data.rows.length > 0 ? wx.navigateTo({
                    url: "../startAnswer/startAnswer?status=开始答题&startAnswer=开始答题&isCollectUrl=2&id=" + t.data.data.rows[0].id
                }) : wx.showToast({
                    title: "暂无试卷",
                    icon: "fail",
                    duration: 2e3,
                    success: function() {
                        setTimeout(function() {
                            wx.reLaunch({
                                url: "/pages/index/index"
                            });
                        }, 2e3);
                    }
                }) : getApp().chkResponse(t);
            },
            fail: function(t) {
                getApp().requestError();
            }
        });
    },
    goStart: function() {
        wx.navigateTo({
            url: "../startAnswer/startAnswer?status=开始答题&isCollectUrl=2&id=" + this.data.answerData.id
        });
    },
    goonStart: function() {
        wx.navigateTo({
            url: "../startAnswer/startAnswer?status=继续答题&isCollectUrl=2&id=" + this.data.answerData.id
        });
    }
});