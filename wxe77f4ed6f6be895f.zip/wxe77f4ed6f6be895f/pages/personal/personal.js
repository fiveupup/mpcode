var t = getApp();

Page({
    data: {
        picAddress: getApp().web_config.web_url,
        tabbar: {},
        userinfo: {},
        picture: "",
        point: "",
        myHeadImg: null,
        userInfo: {},
        hasUserInfo: !1,
        saveAddress: "",
        ririxuePoint: 0,
        zhouzhoulianPoint: 0,
        yueyuebiPoint: 0,
        athleticsPoint: 0
    },
    onLoad: function(e) {
        var o = this;
        wx.getSystemInfo({
            success: function(t) {
                o.setData({
                    height: t.windowHeight - 240
                });
            }
        }), t.editTabbar(), wx.hideTabBar();
    },
    changeHead: function() {
        var t = this;
        wx.chooseImage({
            count: 1,
            sizeType: [ "original", "compressed" ],
            sourceType: [ "album", "camera" ],
            success: function(e) {
                var o = e.tempFilePaths;
                t.upload(t, o);
            },
            fail: function(t) {},
            complete: function(t) {}
        });
    },
    upload: function(t, e) {
        var o = this;
        o.data.picture;
        wx.showToast({
            icon: "loading",
            title: "正在上传"
        }), wx.uploadFile({
            url: getApp().web_config.web_url + "/api/common/fileUpload/upload",
            filePath: e[0],
            header: {
                "content-type": "application/json",
                cookie: "SESSION=" + wx.getStorageSync("3rd_session")
            },
            formData: {
                uploadType: "image"
            },
            name: "file",
            success: function(t) {
                var n = JSON.parse(t.data);
                o.setData({
                    saveAddress: n.data.saveAddress
                }), 0 == n.status && wx.showModal({
                    title: "提示",
                    content: "是否上传此照片",
                    success: function(t) {
                        t.confirm ? wx.request({
                            url: getApp().web_config.web_url + "/api/candidate/update",
                            data: {
                                picture: o.data.saveAddress,
                                id: o.data.userinfo.userId
                            },
                            method: "post",
                            header: {
                                "content-type": "application/x-www-form-urlencoded",
                                cookie: "SESSION=" + wx.getStorageSync("3rd_session")
                            },
                            success: function(t) {
                                console.log(t.data);
                            }
                        }) : t.cancel && (o.setData({
                            myHeadImg: o.data.userinfo.picture
                        }), console.log("用户点击取消"));
                    }
                }), 200 == t.statusCode ? (o.setData({
                    myHeadImg: e[0]
                }), wx.setStorage({
                    key: "myHeadImg",
                    data: e[0]
                })) : wx.showModal({
                    title: "提示",
                    content: "上传失败",
                    showCancel: !1
                });
            },
            fail: function(t) {
                wx.showModal({
                    title: "提示",
                    content: "上传失败",
                    showCancel: !1
                });
            },
            complete: function() {
                wx.hideToast();
            }
        });
    },
    onReady: function() {},
    onShow: function() {
        wx.hideTabBar(), this.getPoint(), this.getUserAthleticsPoint();
    },
    jumpPzl: function() {
        wx.navigateTo({
            url: "../personSet/personSet"
        });
    },
    jumpMedal: function() {
        wx.navigateTo({
            url: "../medal/index"
        });
    },
    getPoint: function() {
        var t = this;
        wx.request({
            url: getApp().web_config.web_url + "/api/studentPoint/getUserPoint",
            data: {},
            method: "get",
            header: {
                "content-type": "application/json",
                cookie: "SESSION=" + wx.getStorageSync("3rd_session")
            },
            success: function(e) {
                0 == e.data.status ? t.setData({
                    ririxuePoint: e.data.data.ririxuePoint,
                    zhouzhoulianPoint: e.data.data.zhouzhoulianPoint,
                    yueyuebiPoint: e.data.data.yueyuebiPoint
                }) : getApp().chkResponse(e);
            },
            fail: function(t) {
                getApp().requestError();
            }
        });
    },
    getUserAthleticsPoint: function() {
        var t = this;
        wx.request({
            url: getApp().web_config.web_url + "/api/studentPoint/getUserAthleticsPoint",
            data: {},
            method: "get",
            header: {
                "content-type": "application/json",
                cookie: "SESSION=" + wx.getStorageSync("3rd_session")
            },
            success: function(e) {
                0 == e.data.status ? t.setData({
                    athleticsPoint: e.data.data.athleticsPoint
                }) : getApp().chkResponse(e);
            },
            fail: function(t) {
                getApp().requestError();
            }
        });
    },
    jumpAwjl: function() {
        wx.navigateTo({
            url: "../answerRecord/answerRecord"
        });
    },
    jumpBattleRecord: function() {
        wx.navigateTo({
            url: "../battleRecords/battleRecords"
        });
    },
    jumpMysc: function() {
        wx.navigateTo({
            url: "../collectionlist/collectionlist"
        });
    },
    jumpMis: function() {
        wx.navigateTo({
            url: "../errorBank/errorBank"
        });
    },
    jumpRank: function() {
        wx.navigateTo({
            url: "../rankingList/rankingList"
        });
    },
    jumpHonor: function() {
        wx.navigateTo({
            url: "../myHonor/myHonor"
        });
    },
    formatDate: function(t) {
        var e = new Date(t.replace(/-/g, "/")), o = e.getFullYear(), n = e.getMonth() + 1, a = e.getDate();
        return n < 10 && (n = "0" + n), a < 10 && (a = "0" + a), o + "-" + n + "-" + a;
    },
    onHide: function() {},
    onUnload: function() {},
    onPullDownRefresh: function() {},
    onReachBottom: function() {},
    onShareAppMessage: function() {}
});