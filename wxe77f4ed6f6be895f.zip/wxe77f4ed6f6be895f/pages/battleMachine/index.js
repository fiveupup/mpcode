var t = require("../../9597AF934A60E1DFF3F1C794C59B10F4.js"), e = require("../../13753E374A60E1DF75135630065B10F4.js"), a = getApp();

Page({
    data: {
        userInfo: [],
        againstId: "",
        opponentId: "",
        showCountDown: !1,
        againstResultName: "",
        getPoint: 0,
        userName: "",
        currentIndex: 0,
        questionList: [],
        choiceList: [],
        myAnswer: "",
        currentTimestamp: new Date().getTime(),
        multipleAnswer: [],
        opponentScore: 0,
        myScore: 0,
        questionTypeName: "",
        questionType: "",
        pkRightName: "机器人",
        totalTime: "",
        every_times: "",
        remainingTime: "",
        stompClient: {},
        liList: [ 0, 1, 2, 3, 4, 5, 6, 7, 8, 9 ]
    },
    onLoad: function(t) {
        this.setData({
            chapterId: t.chapterId,
            chapterName: t.chapterName,
            userInfo: wx.getStorageSync("userinfo")
        }), this.initData();
    },
    onReady: function() {},
    onShow: function() {},
    onHide: function() {},
    onUnload: function() {
        this.clearCountDown();
    },
    onPullDownRefresh: function() {},
    onReachBottom: function() {},
    startCountDown: function() {
        var t = this;
        wx.request({
            url: getApp().web_config.web_url + "/api/fight/findIsFighting",
            data: {
                level: t.data.level
            },
            method: "get",
            header: {
                "content-type": "application/x-www-form-urlencoded",
                cookie: "SESSION=" + wx.getStorageSync("3rd_session")
            },
            success: function(e) {
                var a = e.data;
                if (console.log(a), 0 === a.status) if (a.data) {
                    t.setData({
                        remainingTime: a.data.remainingTime,
                        againstId: a.data.id
                    });
                    var n = 0;
                    a.data.remainingTime && (n = parseInt(a.data.remainingTime));
                    var i = parseInt(n / 1e3);
                    t.getUserAnswerTimes(), t.setData({
                        timer: ""
                    }), t.getTotalCountDown(i), t.assignmentTime(), t.getCountCode(), t.getCurrentScore(a.data.id);
                } else wx.redirectTo({
                    url: "/pages/battleSearch/index"
                }); else wx.redirectTo({
                    url: "/pages/battleSearch/index"
                });
            }
        });
    },
    getTotalCountDown: function(t) {
        var e = this, a = this;
        this.data.totaltimer || this.setData({
            totaltimer: setInterval(function() {
                e.data.totalcount > 0 && e.data.totalcount <= t ? (e.data.totalcount--, a.setData({
                    totalcount: a.data.totalcount
                })) : (a.clearCountDown(), a.autoCommit());
            }, 1e3),
            totalcount: t
        });
    },
    clearCountDown: function() {
        clearInterval(this.data.totaltimer), clearInterval(this.data.timer), this.setData({
            totaltimer: "",
            timer: "",
            totalcount: 0
        });
    },
    assignmentTime: function() {
        var t = 0;
        "LOW" == this.data.level ? t = 20 : "MIDDLE" == this.data.level ? t = 15 : "HEIGHT" == this.data.level && (t = 10), 
        this.setData({
            times: t,
            every_times: t
        });
    },
    getCountCode: function() {
        var t = this;
        t.setData({
            timer: setInterval(function() {
                t.data.times--, t.setData({
                    times: t.data.times
                }), 0 === t.data.times && (clearInterval(t.data.timer), t.setData({
                    timer: ""
                }), t.nextQuestion(), t.assignmentTime(), t.getCountCode());
            }, 1e3)
        });
    },
    getUserAnswerTimes: function() {
        var t = this;
        wx.request({
            url: getApp().web_config.web_url + "/api/fight/getUserAnswerTimes",
            data: {
                againstRecordId: t.data.againstId
            },
            method: "get",
            header: {
                "content-type": "application/x-www-form-urlencoded",
                cookie: "SESSION=" + wx.getStorageSync("3rd_session")
            },
            success: function(e) {
                var a = e.data.data;
                t.processingScores(a);
            }
        });
    },
    getCurrentScore: function(t) {
        var e = this;
        wx.request({
            url: getApp().web_config.web_url + "/api/fight/getCurrentScore",
            data: {
                againstRecordId: t
            },
            method: "get",
            header: {
                "content-type": "application/x-www-form-urlencoded",
                cookie: "SESSION=" + wx.getStorageSync("3rd_session")
            },
            success: function(t) {
                var a = t.data;
                e.setData({
                    myScore: a.data
                });
            }
        });
    },
    autoCommit: function() {
        var e = this;
        wx.request({
            url: getApp().web_config.web_url + "/api/fight/calculateBattleResults",
            data: {
                againstId: e.data.againstId,
                level: e.data.level
            },
            method: "post",
            header: {
                "content-type": "application/x-www-form-urlencoded",
                cookie: "SESSION=" + wx.getStorageSync("3rd_session")
            },
            success: function(a) {
                var n = a.data;
                if (0 == n.status) {
                    e.data.showCountDown = !1;
                    var i = "";
                    1 == n.data.againstResult ? (i = "恭喜您，获得胜利", e.data.getPoint = 2) : 2 == n.data.againstResult ? (i = "很遗憾，对战失败", 
                    e.data.getPoint = 0) : (0 == e.data.myScore ? (i = "平局", e.data.getPoint = 0) : e.data.getPoint = 1, 
                    n.data.againstResult = 3), e.data.totalTime = t.s_to_hs(n.totalAnswerDuration), 
                    e.data.battleResult = !0, e.setData({
                        showCountDown: e.data.showCountDown,
                        againstResultName: i,
                        getPoint: e.data.getPoint,
                        battleResult: e.data.battleResult,
                        totalTime: e.data.totalTime
                    }), console.log(e.data.totalTime), wx.redirectTo({
                        url: "/pages/battleResult/index?recordId=" + e.data.againstId + "&title=" + i + "&if_win=" + n.data.againstResult + "&score=" + n.data.acquirePoint + "&totalTime=" + t.s_to_hs(n.data.totalAnswerDuration)
                    });
                }
            }
        });
    },
    getQuestionList: function() {
        var t = this, e = {
            platformId: 1,
            number: 10
        };
        "" != this.data.chapterId && (e.chapterId = this.data.chapterId), wx.request({
            url: getApp().web_config.web_url + "/api/fight/findRandomQuestionList",
            data: e,
            method: "get",
            header: {
                "content-type": "application/x-www-form-urlencoded",
                cookie: "SESSION=" + wx.getStorageSync("3rd_session")
            },
            success: function(e) {
                var a = e.data;
                0 == a.status && (t.setData({
                    questionList: a.data,
                    currentIndex: 0
                }), t.initQuestion(0), t.startCountDown());
            }
        });
    },
    initData: function() {
        var t = this;
        wx.request({
            url: getApp().web_config.web_url + "/api/fight/martchMachine",
            data: {},
            method: "POST",
            header: {
                "content-type": "application/x-www-form-urlencoded",
                cookie: "SESSION=" + wx.getStorageSync("3rd_session")
            },
            success: function(e) {
                if ("SUCCESS" !== e.data.code) return wx.showToast({
                    title: e.data.message,
                    icon: "none",
                    duration: 2e3
                }), void setTimeout(function() {
                    wx.reLaunch({
                        url: "/pages/index/index"
                    });
                }, 3e3);
                var a = e.data.data;
                t.setData({
                    againstId: a.againstId,
                    level: a.level
                }), t.getQuestionList();
            }
        });
    },
    initQuestion: function(a) {
        var n = this.data.questionList[this.data.currentIndex];
        n.questionBasicInfo.content = e.htmlDecodeByRegExp(n.questionBasicInfo.content);
        var i = e.getDicNameById(n.questionBasicInfo.type);
        n.choiceList;
        if (null != n.choiceList && null != n.choiceList) for (var o = 0; o < n.choiceList.length; o++) n.choiceList[o].content = t.html(n.choiceList[o].content);
        this.data.questionList[this.data.currentIndex] = n, this.setData({
            questionList: this.data.questionList,
            questionTypeName: i,
            questionType: n.questionBasicInfo.type,
            myAnswer: ""
        });
    },
    nextQuestion: function() {
        var t = "", e = this, n = new Date().getTime(), i = Math.round((n - e.data.currentTimestamp) / 1e3);
        if (console.log(i, 1), console.log(n, 2), console.log(e.data.currentTimestamp, 3), 
        "001002" == e.data.questionType) {
            for (var o = 0; o < e.data.multipleAnswer.length; o++) e.data.multipleAnswer[o] && (t += e.data.multipleAnswer[o] + ",");
            t = t.slice(0, -1);
        } else t = e.data.myAnswer;
        wx.request({
            url: getApp().web_config.web_url + "/api/fight/saveUserAgainstRecordsDetail",
            data: {
                againstRecordId: e.data.againstId,
                questionId: e.data.questionList[e.data.currentIndex].questionBasicInfo.id,
                userAnswer: t,
                answerDuration: e.data.every_times - e.data.times,
                againstWay: 1
            },
            method: "POST",
            header: {
                "content-type": "application/x-www-form-urlencoded",
                cookie: "SESSION=" + wx.getStorageSync("3rd_session")
            },
            success: function(t) {
                var n = t.data.data;
                if (n.answerTimes) {
                    if (n.answerTimes >= a.question.total_question_num) return e.clearCountDown(), void e.autoCommit();
                    e.processingScores(n.answerTimes);
                }
                e.setData({
                    myScore: n.score
                }), e.data.myScore = n.score, e.data.myScore >= a.question.total_question_num * a.question.every_score ? e.autoCommit() : (e.data.currentIndex += 1, 
                e.setData({
                    currentIndex: e.data.currentIndex,
                    myAnswer: "",
                    multipleAnswer: [],
                    currentTimestamp: new Date().getTime()
                }), e.data.currentIndex >= e.data.questionList.length ? e.getQuestionList() : e.initQuestion(e.data.currentIndex)), 
                clearInterval(e.data.timer), e.setData({
                    timer: ""
                }), e.assignmentTime(), e.getCountCode();
            }
        });
    },
    processingScores: function(t) {
        var e = this;
        setTimeout(function() {
            e.setData({
                opponentScore: t * a.question.every_score
            }), t * a.question.every_score == a.question.total_question_num * a.question.every_score && (e.clearCountDown(), 
            e.autoCommit());
        }, 1e3);
    },
    singleChoice: function(t) {
        var e = t.currentTarget.dataset.code;
        this.setData({
            myAnswer: e
        });
    },
    multipleChoice: function(t) {
        this.data.multipleAnswer[t.currentTarget.dataset.index] = this.data.multipleAnswer[t.currentTarget.dataset.index] ? "" : t.currentTarget.dataset.code, 
        this.setData({
            multipleAnswer: this.data.multipleAnswer
        });
    }
});