var e = require("../../13753E374A60E1DF75135630065B10F4.js");

Page({
    data: {
        pagedata: {},
        id: "",
        isCollectUrl: "",
        status: "",
        startAnswer: "开始答题",
        examType: "",
        picAddress: getApp().web_config.web_url
    },
    onLoad: function(e) {
        this.setData({
            isCollectUrl: e.isCollectUrl,
            status: e.status ? e.status : "开始答题",
            examType: e.examType ? e.examType : "",
            id: e.id ? e.id : "",
            startAnswer: 99 == e.isCollectUrl ? "开始比试" : e.status ? e.status : "开始答题"
        }), 2 == e.isCollectUrl ? this.chkExam() : 3 == e.isCollectUrl ? this.getAnswerinfo() : 99 == e.isCollectUrl && this.getMonthAnswerinfo();
    },
    chkExam: function() {
        var e = this;
        wx.request({
            url: getApp().web_config.web_url + "/api/examination/checkExamination",
            data: {
                id: e.data.id
            },
            header: {
                "content-type": "application/json",
                cookie: "SESSION=" + wx.getStorageSync("3rd_session")
            },
            method: "GET",
            success: function(t) {
                1 == t.data.status && "link" == t.data.code ? wx.showModal({
                    title: "",
                    content: t.data.message,
                    cancelText: "继续答题",
                    confirmText: "取消",
                    success: function(e) {
                        e.confirm ? wx.reLaunch({
                            url: "/pages/index/index"
                        }) : e.cancel && wx.redirectTo({
                            url: "../singleChoiceDetail/singleChoiceDetail?isCollectUrl=2&recordId=" + t.data.data
                        });
                    }
                }) : 1 == t.data.status && "point" == t.data.code ? wx.showToast({
                    title: t.data.message,
                    icon: "none",
                    duration: 2e3,
                    success: function() {
                        setTimeout(function() {
                            wx.reLaunch({
                                url: "/pages/index/index"
                            });
                        }, 2e3);
                    }
                }) : e.getAnswer();
            },
            fail: function(e) {
                getApp().requestError();
            }
        });
    },
    getAnswerinfo: function() {
        var t = this;
        wx.request({
            url: getApp().web_config.web_url + "/api/examination/viewRecord",
            data: {
                recordId: t.data.id
            },
            header: {
                "content-type": "application/x-www-form-urlencoded",
                cookie: "SESSION=" + wx.getStorageSync("3rd_session")
            },
            method: "POST",
            success: function(a) {
                if (0 == a.data.status) {
                    var i = a.data.data, n = "";
                    if (i.questionTypeSummaries.length > 0) for (var s = 0; s < i.questionTypeSummaries.length; s++) {
                        e.getDicNameById("001");
                        n += e.getDicNameById(i.questionTypeSummaries[s].type) + "题" + i.questionTypeSummaries[s].questions.length + "道,";
                    }
                    t.setData({
                        pagedata: i,
                        questiondesc: n.substring(0, n.length - 1)
                    });
                } else getApp().chkResponse(a);
            },
            fail: function(e) {
                getApp().requestError();
            }
        });
    },
    getAnswer: function() {
        var e = this;
        wx.request({
            url: getApp().web_config.web_url + "/api/examination/getExaminationStructure",
            data: {
                id: e.data.id
            },
            header: {
                "content-type": "application/json",
                cookie: "SESSION=" + wx.getStorageSync("3rd_session")
            },
            method: "GET",
            success: function(t) {
                0 == t.data.status ? e.setData({
                    pagedata: t.data.data,
                    isCollectUrl: 99 == e.data.isCollectUrl ? 2 : e.data.isCollectUrl
                }) : 1 == t.data.status ? wx.showToast({
                    title: t.data.message,
                    icon: "none",
                    duration: 2e3,
                    success: function() {
                        setTimeout(function() {
                            wx.reLaunch({
                                url: "/pages/index/index"
                            });
                        }, 2e3);
                    }
                }) : getApp().chkResponse(t);
            },
            fail: function(e) {
                getApp().requestError();
            }
        });
    },
    startAnswer: function() {
        wx.redirectTo({
            url: "../singleChoiceDetail/singleChoiceDetail?isCollectUrl=" + this.data.isCollectUrl + "&recordId=" + this.data.id + "&examType=" + this.data.examType
        });
    },
    getMonthAnswerinfo: function() {
        var e = this;
        wx.request({
            url: getApp().web_config.web_url + "/api/examination/listExamination",
            data: {
                curPage: 1,
                pageSize: 1,
                examName: "",
                examType: "009001"
            },
            header: {
                "content-type": "application/x-www-form-urlencoded",
                cookie: "SESSION=" + wx.getStorageSync("3rd_session")
            },
            method: "get",
            success: function(t) {
                if (0 == t.data.status) {
                    var a = t.data.data.rows;
                    a.length > 0 ? (e.setData({
                        id: a[0].id
                    }), e.chkExam()) : wx.showToast({
                        title: "暂无试卷",
                        icon: "fail",
                        duration: 2e3,
                        success: function() {
                            setTimeout(function() {
                                wx.reLaunch({
                                    url: "/pages/index/index"
                                });
                            }, 2e3);
                        }
                    });
                } else getApp().chkResponse(t);
            },
            fail: function(e) {
                getApp().requestError();
            }
        });
    },
    onReady: function() {},
    onShow: function() {},
    onHide: function() {},
    onUnload: function() {},
    onPullDownRefresh: function() {},
    onReachBottom: function() {},
    onShareAppMessage: function() {}
});