var t = getApp();

require("../../utils/wxParse/wxParse.js");

Page({
    data: {
        userInfo: {},
        bannerTop: [],
        bannerTwo: [],
        bannerThree: [],
        bannerData: [],
        questionTypeLists: [],
        chaptername: "",
        picAddress: t.web_config.web_url,
        nvabarData: {
            showCapsule: 1,
            title: "在线学习"
        },
        from: "",
        height: 2 * t.globalData.height + 20
    },
    ajaxData: function() {
        var e = this;
        wx.request({
            url: t.web_config.web_url + "/api/courseCategory/listChapter",
            data: {},
            header: {
                "content-type": "application/json",
                cookie: "SESSION=" + wx.getStorageSync("3rd_session")
            },
            method: "GET",
            success: function(t) {
                if (0 == t.data.status) {
                    var a = t.data.data, n = [], r = [], o = [];
                    if (a.length > 0) for (var s = 0; s < a.length; s++) s < 2 ? n.push(a[s]) : s < 5 ? r.push(a[s]) : o.push(a[s]);
                    e.setData({
                        bannerTop: n,
                        bannerTwo: r,
                        bannerThree: o,
                        bannerData: a
                    });
                } else getApp().chkResponse(t);
            },
            fail: function(e) {
                t.requestError();
            }
        });
    },
    getAjaxData: function(e, a) {
        var n = this;
        wx.request({
            url: t.web_config.web_url + "/api/questionPractice/getNumbers",
            data: {
                chapterId: a
            },
            header: {
                "content-type": "application/json",
                cookie: "SESSION=" + wx.getStorageSync("3rd_session")
            },
            method: "GET",
            success: function(a) {
                0 == a.data.status ? n.setData({
                    questionTypeLists: a.data.data,
                    chaptername: e
                }) : t.chkResponse(a);
            },
            fail: function(t) {}
        });
    },
    getQuestionType: function(t) {
        var e = t.currentTarget.dataset.title, a = t.currentTarget.dataset.id;
        1 != this.data.from ? this.getAjaxData(e, a) : wx.redirectTo({
            url: "/pages/battleMachine/index?chapterId=" + a + "&chapterName=" + e
        });
    },
    bindViewTapSingle: function(t) {
        var e = t.currentTarget.dataset.chapterid, a = t.currentTarget.dataset.questiontype, n = t.currentTarget.dataset.viewtype, r = t.currentTarget.dataset.totalnumber;
        wx.navigateTo({
            url: "../" + n + "/" + n + "?questionType=" + a + "&chapterId=" + e + "&chaptername=" + this.data.chaptername + "&totalnumber=" + r
        });
    },
    onLoad: function(t) {
        this.setData({
            from: t.from ? t.from : ""
        }), 1 == t.from && wx.setNavigationBarTitle({
            title: "月月比"
        }), this.ajaxData(), this.setData({
            userInfo: wx.getStorageSync("userinfo")
        });
    },
    onReady: function() {},
    onShow: function() {
        this.setData({
            questionTypeLists: []
        });
    },
    onHide: function() {},
    onUnload: function() {},
    onPullDownRefresh: function() {},
    onReachBottom: function() {}
});