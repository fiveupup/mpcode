Page({
    data: {
        pagedata: [],
        questionTypeLists: {},
        pageSize: 100,
        curPage: 1,
        topNum: 0,
        examType: ""
    },
    lower: function() {
        for (var t = this, e = this.data.pagedata, a = [], n = 0; n < 10; n++) a.push(n);
        var o = e.concat(a);
        if (console.log(a.length), o.length >= 100) return wx.showToast({
            title: "我也是有底线的",
            icon: "success",
            duration: 300
        }), !1;
        wx.showLoading({
            title: "加载中",
            icon: "loading"
        }), setTimeout(function() {
            t.setData({
                res: o
            }), wx.hideLoading();
        }, 1500);
    },
    scrolltoupper: function(t) {
        console.log(t), t.detail.scrollTop > 100 ? this.setData({
            floorstatus: !0
        }) : this.setData({
            floorstatus: !1
        });
    },
    goTop: function(t) {
        this.setData({
            topNum: this.data.topNum = 0
        }), wx.showToast({
            title: "回到顶部",
            icon: "success",
            duration: 1500
        });
    },
    onLoad: function(t) {
        var e = this;
        this.getAnswerRecord(), wx.getSystemInfo({
            success: function(t) {
                e.setData({
                    height: t.windowHeight - 141
                });
            }
        });
    },
    startAnswer: function(t) {
        wx.redirectTo({
            url: "../startAnswer/startAnswer?status=开始考试&isCollectUrl=2&id=" + t.currentTarget.dataset.id + "&examinationId=" + t.currentTarget.dataset.examinationid
        });
    },
    answerFx: function(t) {
        wx.request({
            url: getApp().web_config.web_url + "/api/examination/viewRecord",
            data: {
                recordId: t.currentTarget.dataset.id
            },
            header: {
                "content-type": "application/x-www-form-urlencoded",
                cookie: "SESSION=" + wx.getStorageSync("3rd_session")
            },
            method: "POST",
            success: function(e) {
                0 != e.data.status ? wx.showToast({
                    title: e.data.message,
                    icon: "none",
                    duration: 1500
                }) : wx.navigateTo({
                    url: "../answerFx/answerFx?id=" + t.currentTarget.dataset.id + "&examinationId=" + t.currentTarget.dataset.examinationid + "&examType=" + t.currentTarget.dataset.examtype
                });
            },
            fail: function(t) {
                getApp().requestError();
            }
        });
    },
    getAnswerRecord: function() {
        var t = this;
        wx.request({
            url: getApp().web_config.web_url + "/api/examination/listParticipatedExamination",
            data: {
                pageSize: t.data.pageSize,
                curPage: t.data.curPage,
                examType: t.data.examType
            },
            header: {
                "content-type": "application/json",
                cookie: "SESSION=" + wx.getStorageSync("3rd_session")
            },
            method: "GET",
            success: function(e) {
                0 == e.data.status ? t.setData({
                    pagedata: e.data.data.rows
                }) : getApp().chkResponse(e);
            },
            fail: function(t) {
                getApp().requestError();
            }
        });
    },
    onReady: function() {},
    onShow: function() {},
    onHide: function() {},
    onUnload: function() {},
    onPullDownRefresh: function() {},
    onReachBottom: function() {},
    onShareAppMessage: function() {}
});