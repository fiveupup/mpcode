var t = getApp();

Page({
    data: {
        userInfo: [],
        isAgree: !1,
        examType: 1,
        ruleText: "",
        classRule: "dayRules",
        showModal: !1,
        todayAnswerNum: 0,
        height: t.globalData.deviceHeight,
        isIpx: t.globalData.isIpx,
        currentPkNumber: 0,
        count_down: 0,
        timer: "",
        Stomp: "",
        orgId: "",
        goAnswer: !1,
        stompClient: {},
        socketConnected: !1
    },
    onLoad: function(t) {
        this.setData({
            weekRule: this.data.newWeekRule,
            orgId: t.orgId,
            userInfo: wx.getStorageSync("userinfo")
        });
        var e = this.data.height, o = this.data.isIpx;
        e < 600 && !o ? this.setData({
            height: "390rpx"
        }) : e > 600 && !o ? this.setData({
            height: e - 260
        }) : e > 600 && o && this.setData({
            height: e - 280
        }), this.countDown(), this.initSocket();
    },
    onUnload: function() {
        this.data.socketConnected && (wx.closeSocket(), this.setData({
            socketConnected: !1
        })), wx.onSocketClose(function(t) {
            console.log("WebSocket 已关闭！");
        }), this.data.stompClient.disconnect(function() {
            console.log("Stomp 已关闭！");
        }), clearInterval(this.data.timer), this.setData({
            timer: ""
        }), console.log(this.data.goAnswer, "this.data.goAnswer"), this.data.goAnswer || (console.log("清空reids"), 
        this.clearUserForRedis());
    },
    closeAlert: function() {
        this.setData({
            showModal: !1
        });
    },
    checkboxChange: function() {
        this.setData({
            isAgree: !this.data.isAgree
        });
    },
    showAlert: function() {
        this.setData({
            showModal: !0
        });
    },
    goBattleQw: function() {
        if (0 == this.data.count_down) {
            this.initSocket();
            wx.redirectTo({
                url: "/pages/onlineStudy/onlineStudy?from=1"
            });
        } else wx.showToast({
            title: "您正在匹配，请稍等",
            icon: "none",
            duration: 2e3
        });
    },
    sendSocketMessage: function(t) {
        this.data.socketConnected && wx.sendSocketMessage({
            data: t
        });
    },
    close: function() {
        this.data.socketConnected && (wx.closeSocket(), this.setData({
            socketConnected: !1
        }));
    },
    connect: function(t) {
        function e() {
            return t.apply(this, arguments);
        }
        return e.toString = function() {
            return t.toString();
        }, e;
    }(function() {
        var t = this, e = {
            send: t.sendSocketMessage,
            close: t.close
        };
        return wx.connectSocket({
            url: "wss://" + getApp().globalData.websocketUrl + "/ws",
            success: function(e) {
                t.setData({
                    socketConnected: !0
                });
            }
        }), wx.onSocketOpen(function(t) {
            console.log("WebSocket 连接成功"), e.onopen();
        }), wx.onSocketMessage(function(t) {
            e.onmessage(t);
        }), wx.onSocketError(function(t) {
            console.log("WebSocket 错误事件");
        }), wx.onSocketClose(function(t) {
            console.log("WebSocket 连接关闭"), socketConnected = !1, reconnect && connect();
        }), e;
    }),
    initSocket: function() {
        var t = this, e = t.connect(), o = require("../../28F70F364A60E1DF4E916731EC8B10F4.js").Stomp;
        o.setInterval = function(t, e) {
            return setInterval(e, t);
        }, o.clearInterval = function(t) {
            return clearInterval(t);
        }, t.setData({
            stompClient: o.over(e)
        }), t.data.stompClient.connect({}, function(e) {
            console.log("开始订阅"), t.data.stompClient.subscribe("/user/" + t.data.userInfo.userId + "/queue", t.onMessageReceived), 
            t.startMatch();
        });
    },
    onConnected: function() {
        console.log(t.globalData.client, "app.globalData.client"), t.globalData.client.subscribe("/user/" + this.data.userInfo.userId + "/queue", this.messageCallback), 
        console.log(t.globalData.client, "app.globalData.client2222222222222");
    },
    onError: function() {
        console.log("stompClient 连接异常");
    },
    onMessageReceived: function(t) {
        var e = JSON.parse(t.body);
        console.log(e, "匹配回调");
        e && ("ADD_USER" === e.type ? this.setData({
            currentPkNumber: e.content
        }) : "CHOOSE_USER" === e.type && e.content && (clearInterval(this.data.timer), this.setData({
            goAnswer: !0
        }), wx.redirectTo({
            url: "/pages/battleOnline/index?opponentId=" + e.content + "&againstId=" + e.againstId
        })));
    },
    clearUserForRedis: function() {
        this.data.userInfo.userId && wx.request({
            url: getApp().web_config.web_url + "/api/fight/clearUserForRedis",
            data: {
                userId: this.data.userInfo.userId
            },
            method: "post",
            header: {
                "content-type": "application/x-www-form-urlencoded",
                cookie: "SESSION=" + wx.getStorageSync("3rd_session")
            },
            success: function(t) {
                0 == t.data.status || (1 == t.data.status ? wx.showToast({
                    title: t.data.message,
                    icon: "none",
                    duration: 2e3
                }) : getApp().chkResponse(t));
            }
        });
    },
    chooseUser: function() {
        if (console.log(this.data.stompClient.connected ? "stompClient 连接成功" : "stompClient 连接失败"), 
        this.data.stompClient) {
            var t = {
                sender: this.data.userInfo.userId,
                proOrgId: this.data.orgId,
                type: "CHOOSE_USER"
            };
            console.info("开始匹配"), this.data.stompClient.send("/app/game.choose_user", {}, JSON.stringify(t));
        }
    },
    startMatch: function() {
        var t = this;
        wx.request({
            url: getApp().web_config.web_url + "/api/fight/getOpponentInfo",
            data: {},
            method: "get",
            header: {
                "content-type": "application/x-www-form-urlencoded",
                cookie: "SESSION=" + wx.getStorageSync("3rd_session")
            },
            success: function(e) {
                var o = e.data;
                if (0 === o.status) if (o) if (0 == o.data.remainingTime) t.endGame(o.data.againstId); else {
                    t.setData({
                        goAnswer: !0
                    });
                    var n = "/pages/battleOnline/index?opponentId=" + o.data.userAgainstRecordsInfo.userId + "&againstId=" + o.data.againstId;
                    wx.redirectTo({
                        url: n
                    });
                } else t.chooseUser(); else t.chooseUser();
            }
        });
    },
    endGame: function(t) {
        var e = this;
        console.info(t), wx.request({
            url: getApp().web_config.web_url + "/api/fight/gameOver?againstId=" + t,
            data: {},
            method: "post",
            header: {
                "content-type": "application/x-www-form-urlencoded",
                cookie: "SESSION=" + wx.getStorageSync("3rd_session")
            },
            success: function(t) {
                0 === t.data.status && e.startMatch();
            }
        });
    },
    goonMatch: function() {
        this.countDown(), this.initSocket();
    },
    countDown: function() {
        var t = this;
        t.data.timer = null, t.setData({
            count_down: 30
        }), t.setData({
            timer: setInterval(function() {
                t.data.count_down--, t.setData({
                    count_down: t.data.count_down
                }), 0 == t.data.count_down && (clearInterval(t.data.timer), t.setData({
                    timer: ""
                }), t.clearUserForRedis(), t.data.stompClient.disconnect(function() {
                    console.log("Stomp 已关闭！");
                }), t.data.socketConnected && (wx.closeSocket(), t.setData({
                    socketConnected: !1
                })), wx.onSocketClose(function(t) {
                    console.log("WebSocket 已关闭！");
                }), wx.showToast({
                    title: "当前无空闲玩家，是否重新匹配",
                    icon: "none",
                    duration: 2e3
                }));
            }, 1e3)
        });
    }
});