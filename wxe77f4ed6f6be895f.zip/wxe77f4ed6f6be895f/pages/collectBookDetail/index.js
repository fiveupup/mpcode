require("../../@babel/runtime/helpers/Arrayincludes");

var t = require("../../13753E374A60E1DF75135630065B10F4.js");

Page({
    data: {
        info: [],
        id: "",
        showModal: !1,
        imgUrl: "",
        imgwidth: 0,
        imgheight: 0
    },
    onLoad: function(t) {
        var e = this;
        wx.getSystemInfo({
            success: function(t) {
                e.setData({
                    height: t.windowHeight - 30
                });
            }
        }), this.setData({
            id: t.id
        }), this.getDetail(), this.addBrowerNumber();
    },
    imageLoad: function(t) {
        var e = 700 / (t.detail.width / t.detail.height);
        this.setData({
            imgwidth: 700,
            imgheight: e
        });
    },
    onReady: function() {},
    onShow: function() {},
    onHide: function() {},
    onUnload: function() {},
    onPullDownRefresh: function() {},
    onReachBottom: function() {},
    onShareAppMessage: function() {},
    getDetail: function() {
        var e = this;
        wx.request({
            url: getApp().web_config.web_url + "/api/information/findInformationById?id=" + e.data.id,
            data: {},
            method: "get",
            header: {
                "content-type": "application/x-www-form-urlencoded",
                cookie: "SESSION=" + wx.getStorageSync("3rd_session")
            },
            success: function(a) {
                if (0 == a.data.status) {
                    a.data.data.infomationContent = t.toHtml(a.data.data.infomationContent);
                    var i = [];
                    a.data.data.fileUrl && (i = a.data.data.fileUrl.split(","));
                    var o = t.formatContent(a.data.data.infomationContent).replace(/\<img/gi, '<img style="width:100%;height:auto;"').replace(/\<p>/gi, '<p class="p_class">').replace(/\<table>/gi, '<table class="table">').replace(/\<tr>/gi, '<tr class="tr">').replace(/\<td>/gi, '<td class="td">');
                    e.setData({
                        info: a.data.data,
                        infomationContent: o,
                        fileUrl: i
                    });
                } else 1 == a.data.status ? wx.showToast({
                    title: a.data.message,
                    icon: "none",
                    duration: 2e3
                }) : getApp().chkResponse(a);
            }
        });
    },
    addBrowerNumber: function() {
        wx.request({
            url: getApp().web_config.web_url + "/api/information/addBrowerNumber?id=" + this.data.id,
            data: {},
            method: "post",
            header: {
                "content-type": "application/x-www-form-urlencoded",
                cookie: "SESSION=" + wx.getStorageSync("3rd_session")
            },
            success: function(t) {
                0 == t.data.status || (1 == t.data.status ? wx.showToast({
                    title: t.data.message,
                    icon: "none",
                    duration: 2e3
                }) : getApp().chkResponse(t));
            }
        });
    },
    downLoadPic: function(t) {
        var e = t.currentTarget.dataset.id, a = this.getFileType(e);
        [ "jpeg", "png", "jpg", "gif", "webp" ].includes(a) && this.setData({
            showModal: !0,
            imgUrl: e
        }), wx.downloadFile({
            url: e,
            success: function(t) {
                console.log(t.tempFilePath);
                var e = t.tempFilePath;
                wx.openDocument({
                    showMenu: !0,
                    filePath: e,
                    success: function(t) {
                        console.log(t);
                    },
                    fail: function(t) {
                        console.log(t);
                    }
                });
            }
        });
    },
    getFileType: function(t) {
        var e = t.lastIndexOf(".");
        return -1 != e ? t.substring(e + 1, t.length).toLowerCase() : "";
    },
    closeAlert: function() {
        this.setData({
            showModal: !1,
            imgUrl: ""
        });
    }
});