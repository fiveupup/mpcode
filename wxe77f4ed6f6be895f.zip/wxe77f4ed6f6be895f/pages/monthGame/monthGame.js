var e = getApp();

Page({
    data: {
        isAgree: !1,
        dayRule: "“日日学”：对活动期间连续每天登录学习的（每次学习 10 道题以上为有效学习，每天学习多少次都记为 1 次），由平台按月给予“日日学之星”，次月重新累计。",
        weekRule: "“周周练”：学员每周可在线答题。每套30道题满分30分，做多套试题，其所做各套试题的总得分即为“周周练”成绩（积分）。每周五下午5点，系统自动对一周来各学员“周周练”成绩，前100名学员（含并列）由平台给予“周周练达人”称号。每一次统计都是在原来基础上，加上新一周成绩后再排序，即：“周周练”成绩要不断累计。",
        monthRule: "月月比每月最后一个周末（周六、日的0时至24时，分别是5月30日、31日，6月27、28日，7月25、26日，8月29、30日，9月26、27日），所有注册学员在线答同一套试题，每人作答的题目顺序由平台随机生成。活动结束后，将每月答题成绩加权积分，形成学员“月月比”总成绩（学员总成绩=9月成绩*200%+8月成绩*140%+7月成绩*130%+6月成绩*120%+5月成绩×100%）。\n每省“月月比”总成绩排名前3的学员（如有并列，则看9月份比试成绩，取居前者）评为“岗位练兵明星”，颁发奖牌、证书。",
        examType: 1,
        ruleText: "",
        classRule: "dayRules",
        showModal: !1,
        todayAnswerNum: 0,
        height: e.globalData.deviceHeight - 50,
        isIpx: e.globalData.isIpx,
        newWeekRule: "学员每周（7 天）可在线答题。每天最多答5 套题，每套 10 道题，每道题 1 分，取当天得分最高的 2 套试题之和为当天积分。对本周累计积分位居全国前 100 的学员（从第 100 个学员可并列，每次排名都是在原来基础上，加上新一周积分后再排序），由平台给予“周周练达人”。"
    },
    onLoad: function(e) {
        this.setData({
            weekRule: this.data.newWeekRule
        });
        var t = e.examType ? e.examType : 1, a = 1 == t ? this.data.dayRule : 2 == t ? this.data.weekRule : this.data.monthRule, s = 1 == t ? "dayRules" : 2 == t ? "weekRules" : "monthRules";
        this.setData({
            examType: t,
            ruleText: a,
            classRule: s
        }), wx.setNavigationBarTitle({
            title: 1 == e.examType ? "日日学" : 2 == e.examType ? "周周练" : "月月比"
        }), this.getTodayAnswerData();
        var i = this.data.height, o = this.data.isIpx;
        i < 600 && !o ? this.setData({
            height: "390rpx"
        }) : i > 600 && !o ? this.setData({
            height: i - 260
        }) : i > 600 && o && this.setData({
            height: i - 280
        });
    },
    closeAlert: function() {
        this.setData({
            showModal: !1
        });
    },
    checkboxChange: function() {
        this.setData({
            isAgree: !this.data.isAgree
        });
    },
    showAlert: function() {
        this.setData({
            showModal: !0
        });
    },
    goMonthTest: function() {
        if (3 != this.data.examType || this.data.isAgree) {
            var e = 1 == this.data.examType ? "/pages/onlineStudy/onlineStudy" : 2 == this.data.examType ? "/pages/weekGame/weekGame" : "/pages/startAnswer/startAnswer?isCollectUrl=99&examType=009001";
            3 == this.data.examType ? wx.showModal({
                title: "提示",
                content: "确定要参加月月比？",
                success: function(t) {
                    t.confirm ? wx.redirectTo({
                        url: e
                    }) : t.cancel;
                }
            }) : wx.redirectTo({
                url: e
            });
        } else wx.showToast({
            title: "请先同意规则",
            icon: "none",
            duration: 2e3
        });
    },
    getTodayAnswerData: function() {
        var t = this;
        wx.request({
            url: e.web_config.web_url + "/api/studentPoint/getRirixueCount",
            data: {},
            header: {
                "content-type": "application/json",
                cookie: "SESSION=" + wx.getStorageSync("3rd_session")
            },
            method: "GET",
            success: function(e) {
                0 == e.data.status ? t.setData({
                    todayAnswerNum: e.data.data
                }) : getApp().chkResponse(e);
            },
            fail: function(t) {
                e.requestError();
            }
        });
    }
});