var a = getApp();

require("../../utils/wxParse/wxParse.js");

Page({
    data: {
        pageSize: 10,
        curPage: 1,
        loading: !1,
        nomore: !1,
        answers: [],
        picAddress: a.web_config.web_url,
        tabbar: {},
        examname: ""
    },
    onShow: function() {
        var t = this;
        wx.getSystemInfo({
            success: function(a) {
                t.setData({
                    height: a.windowHeight
                });
            }
        }), a.editTabbar(), this.getQuestion();
    },
    onLoad: function(t) {
        var e = this;
        wx.getSystemInfo({
            success: function(a) {
                e.setData({
                    height: a.windowHeight
                });
            }
        }), a.editTabbar(), this.getQuestion();
    },
    onReady: function() {},
    inputexamname: function(a) {
        var t = a.detail.value;
        this.setData({
            examname: t
        });
    },
    showPopup: function(a) {
        this.popup.showPopup();
        var t = a.currentTarget.dataset.id;
        this.setData({
            nowCode: t
        }), this.setData({
            answers: t
        });
    },
    scrolltoupper: function() {
        var a = this.data.curPage;
        a += 1, this.setData({
            curPage: a
        }), this.getQuestion();
    },
    getQuestion: function() {
        var t = this;
        if (wx.showLoading({
            title: "加载中",
            icon: "loading",
            duration: 500
        }), 1 != t.data.curPage && t.data.nomore) wx.showToast({
            title: "我也是有底线的",
            icon: "success",
            duration: 2e3
        }); else if (t.setData({
            loading: !0
        }), t.data.loading) {
            t.data.curPage;
            var e = {
                pageSize: t.data.pageSize,
                curPage: t.data.curPage
            };
            t.data.examname && (e.examName = t.data.examname), wx.request({
                url: a.web_config.web_url + "/api/examination/listExamination",
                data: e,
                header: {
                    "content-type": "application/json",
                    cookie: "SESSION=" + wx.getStorageSync("3rd_session")
                },
                method: "GET",
                success: function(a) {
                    if (0 == a.data.status) {
                        var e = t.data.answers;
                        if (e.length > 0) {
                            if (0 == a.data.data.rows.length) return 1 != t.data.curPage ? (wx.showToast({
                                title: "我也是有底线的",
                                icon: "success",
                                duration: 2e3
                            }), t.setData({
                                answers: e
                            }), !1) : (t.setData({
                                answers: "",
                                loading: !1,
                                nomore: !0
                            }), !1);
                            if (1 != t.data.curPage) for (var s = 0; s < a.data.data.rows.length; s++) e.push(a.data.data.rows[s]); else e = a.data.data.rows;
                        } else e = a.data.data.rows;
                        t.setData({
                            answers: e,
                            loading: !1
                        });
                    } else getApp().chkResponse(a);
                },
                fail: function(a) {
                    getApp().requestError();
                }
            });
        }
    },
    searchExamname: function() {
        this.data.examname;
        this.setData({
            curPage: 1,
            nomore: !1
        }), this.getQuestion();
    },
    startAnswer: function(a) {
        wx.navigateTo({
            url: "../startAnswer/startAnswer?status=" + a.currentTarget.dataset.status + "&isCollectUrl=2&id=" + a.currentTarget.dataset.id
        });
    },
    _error: function() {
        console.log("你点击了取消"), this.popup.hidePopup();
    },
    _success: function() {
        console.log("你点击了确定"), this.popup.hidePopup();
    },
    selectContent: function() {
        wx.navigateTo({
            url: "../onlineStudy/onlineStudy"
        });
    }
});