var t = getApp(), e = require("../../13753E374A60E1DF75135630065B10F4.js");

Page({
    data: {
        jsdata: {
            questionlist: {},
            questionall: {},
            answercard: {},
            answerData: {},
            subid: "",
            recordId: "",
            number: 5,
            startIndex: 0,
            totalnumber: 0,
            round: 1,
            page: 1,
            nowQid: 0,
            chapterId: "",
            questionType: "",
            isCollectUrl: 3,
            notAnswerTotal: 0,
            answerWrongTotal: 0,
            answerRightTotal: 0,
            questionid: "",
            collection_img: "",
            blanksNumber: 0,
            inputlist: [],
            title: "",
            againstRecordId: ""
        },
        analysisFile: [],
        selectCode: [],
        answer: "",
        analysis: "",
        resultdata: "",
        content: "",
        choices: [],
        nowCode: "",
        myAnswer: "",
        chaptername: "",
        timer: "",
        countDownNum: "2",
        picAddress: getApp().web_config.web_url,
        ifCardShow: !1,
        parms: [],
        ismiddle: 0,
        examType: "",
        middleTimer: ""
    },
    onMyEvent: function(t) {
        this.setData({
            ifCardShow: t.detail.ifCardShow
        });
    },
    showModal: function() {
        var t = wx.createAnimation({
            duration: 200,
            timingFunction: "linear",
            delay: 0
        });
        this.animation = t, t.translateY(300).step(), this.setData({
            animationData: t.export(),
            ifCardShow: !0
        }), setTimeout(function() {
            t.translateY(0).step(), this.setData({
                animationData: t.export()
            });
        }.bind(this), 200);
    },
    hideModal: function() {
        var t = wx.createAnimation({
            duration: 200,
            timingFunction: "linear",
            delay: 0
        });
        this.animation = t, t.translateY(300).step(), this.setData({
            animationData: t.export()
        }), setTimeout(function() {
            t.translateY(0).step(), this.setData({
                animationData: t.export(),
                ifCardShow: !1
            });
        }.bind(this), 200);
    },
    onLoad: function(t) {
        this.popup = this.selectComponent("#popup"), this.minitool = this.selectComponent("#minitool");
        var e = this.data.jsdata;
        e.againstRecordId = t.againstRecordId, this.setData({
            jsdata: e
        }), this.getQuestion();
    },
    onReady: function() {},
    showInfo: function() {
        this.popup;
        this.popup.showPopup();
    },
    showPopup: function(t) {
        var e = this.data.jsdata;
        2 != e.isCollectUrl && 4 != e.isCollectUrl && this.popup.showPopup();
        var a = t.currentTarget.dataset.id;
        e.answercard[e.questionid.toString() + "q"] = a, this.setData({
            jsdata: e,
            nowCode: a,
            myAnswer: a
        }), this.reviewQuestionNum();
    },
    multiChoice: function(t) {
        var e = "", a = this.data.jsdata, i = this.data.jsdata.answercard[a.questionid.toString() + "q"];
        i || (i = []);
        var s = t.currentTarget.dataset.id, n = t.currentTarget.dataset.index;
        if (i[n] = i[n] == s ? "" : s, i.length > 0) for (var o = 0; o < i.length; o++) i[o] && (e += i[o] + ",");
        e && (e = e.substring(0, e.length - 1)), this.data.selectCode[n].selected = !this.data.selectCode[n].selected, 
        a.answercard[a.questionid.toString() + "q"] = i, this.setData({
            jsdata: a,
            nowCode: i,
            myAnswer: e,
            selectCode: this.data.selectCode
        }), this.reviewQuestionNum();
    },
    getQuestion: function() {
        var e, a = this;
        e = t.web_config.web_url + "/api/fight/findDetailListByAgainstId", wx.request({
            url: e,
            data: {
                againstRecordId: a.data.jsdata.againstRecordId
            },
            header: {
                "content-type": "application/json",
                cookie: "SESSION=" + wx.getStorageSync("3rd_session")
            },
            method: "GET",
            success: function(t) {
                0 == t.data.data.length && (wx.showToast({
                    title: "您没有答题，暂无记录",
                    icon: "none",
                    duration: 2e3
                }), setTimeout(function() {
                    wx.navigateBack({
                        delta: 1
                    });
                }, 2e3)), a.handleData(t);
            },
            fail: function(e) {
                t.requestError();
            }
        });
    },
    handleData: function(a) {
        if (0 == a.data.status) {
            var i = a.data.data, s = this.data.jsdata;
            if (i[0].questionBasicInfo.content = e.htmlDecodeByRegExp(i[0].questionBasicInfo.content), 
            i[0].questionBasicInfo.analysis = e.htmlDecodeByRegExp(i[0].questionBasicInfo.analysis), 
            "001001" == i[0].questionBasicInfo.type) this.handleChoice(i[0]), s.choices = i[0].choiceList; else if ("001002" == i[0].questionBasicInfo.type || "001007" == i[0].questionBasicInfo.type) this.handleChoice(i[0]); else if ("001003" == i[0].questionBasicInfo.type) this.handleChoice(i[0]); else if ("001004" == i[0].questionBasicInfo.type) {
                s.inputlist = [], s.blanksNumber = i[0].blanksNumber;
                for (var n = 0; n < s.blanksNumber; n++) s.inputlist[n] = "";
            }
            s.inCollection = i[0].inCollection, s.title = e.getDicNameById(i[0].questionBasicInfo.type), 
            s.questionid = i[0].questionBasicInfo.id, s.questionType = i[0].questionBasicInfo.type, 
            s.datalists = i, this.setData({
                jsdata: s,
                resultdata: a.data,
                answer: i[0].questionBasicInfo.answer,
                content: i[0].questionBasicInfo.content,
                analysis: i[0].questionBasicInfo.analysis,
                myAnswer: i[0].userAgainstDetailJsonVo.userAnswer
            }), wx.setNavigationBarTitle({
                title: this.data.jsdata.chaptername
            }), this.getAnasylis(i[0].questionBasicInfo.id), this.reviewQuestionNum(), this.popup.showPopup(), 
            this.reviewQuestionNum();
        } else t.chkResponse(a);
    },
    reviewNextQuestion: function() {
        var t = this.data.jsdata;
        t.nowQid = t.nowQid + 1, t.datalists.length <= t.nowQid ? wx.showToast({
            title: "没有下一题了",
            icon: "none",
            duration: 2e3
        }) : (this.getAnasylis(t.datalists[t.nowQid].questionBasicInfo.id), this.handleCommonData(t.datalists[t.nowQid]), 
        this.popup.showPopup());
    },
    getContent: function(t) {
        var e = this.data.jsdata;
        e.answercard[e.questionid + "q"] = t.detail.value, this.setData({
            jsdata: e,
            myAnswer: t.detail.value
        }), this.reviewQuestionNum();
    },
    studyResult: function() {
        e.studyResult(this.data.jsdata.chapterId, this.data.jsdata.questionType, this.data.jsdata.chaptername, this.data.jsdata.totalnumber, "singleChoiceDetail", this.data.jsdata.isCollectUrl);
    },
    handleChoice: function(t) {
        var a = t.choiceList;
        if (t.choiceList.length > 0) {
            for (var i = 0; i < t.choiceList.length; i++) t.choiceList[i].content = e.htmlDecodeByRegExp(t.choiceList[i].content);
            this.setData({
                selectCode: a,
                choices: t.choiceList
            });
        }
    },
    _error: function() {
        console.log("你点击了取消"), this.popup.hidePopup();
    },
    _success: function() {
        console.log("你点击了确定"), this.popup.hidePopup();
    },
    selectContent: function() {
        wx.reLaunch({
            url: "/pages/onlineStudy/onlineStudy"
        });
    },
    bindblurac: function(t) {
        var e = this.data.myAnswer;
        this.setData({
            myAnswer: e
        });
    },
    inputbind: function(t) {
        var e = this.data.nowCode;
        e || (e = []);
        var a = t.detail.value;
        e[t.target.dataset.index] = a, e.length > 0 && e.join(",");
        var i = this.data.jsdata;
        i.answercard[i.questionid.toString() + "q"] = e, this.setData({
            jsdata: i,
            nowCode: e,
            myAnswer: e
        }), this.reviewQuestionNum();
    },
    handleCommonData: function(t) {
        var a = this.data.jsdata;
        if (t.content = e.htmlDecodeByRegExp(t.questionBasicInfo.content), t.analysis && (t.analysis = e.htmlDecodeByRegExp(t.questionBasicInfo.analysis)), 
        console.log(t, "parm"), "001001" == t.questionBasicInfo.type) this.handleChoice(t), 
        a.choices = t.choiceList, a.inCollection = t.inCollection; else if ("001002" == t.questionBasicInfo.type || "001007" == t.questionBasicInfo.type) this.handleChoice(t); else if ("001003" == t.questionBasicInfo.type) this.handleChoice(t); else if ("001004" == t.questionBasicInfo.type) {
            a.blanksNumber = t.blanksNumber, a.inputlist = [];
            for (var i = 0; i < a.blanksNumber; i++) a.inputlist[i] = "";
        }
        a.inCollection = t.inCollection, a.title = e.getDicNameById(t.questionBasicInfo.type), 
        a.questionType = t.questionBasicInfo.type, a.questionid = t.questionBasicInfo.id;
        var s = a.answercard[a.questionid.toString() + "q"] ? a.answercard[a.questionid.toString() + "q"] : t.userAnswer, n = "";
        if (("001002" == t.questionBasicInfo.type || "001004" == t.questionBasicInfo.type || "001007" == t.questionBasicInfo.type) && (n = s instanceof Array ? s : s ? s.split(",") : [], 
        a.answercard[a.questionid.toString() + "q"] = n, n)) {
            for (var o = 0; o < this.data.selectCode.length; o++) for (var d = 0; d < n.length; d++) if (this.data.selectCode[o].selected = !1, 
            this.data.selectCode[o].code == n[d]) {
                this.data.selectCode[o].selected = !0;
                break;
            }
            for (var r = [], c = 0; c < n.length; c++) "" != n[c] && r.push(n[c]);
            s = r.join(",");
        }
        this.setData({
            jsdata: a,
            myAnswer: s,
            nowCode: n,
            selectCode: this.data.selectCode,
            answer: t.questionBasicInfo.answer,
            content: t.content,
            analysis: e.htmlDecodeByRegExp(t.questionBasicInfo.analysis)
        }), 4 == a.isCollectUrl ? wx.setNavigationBarTitle({
            title: a.chaptername
        }) : wx.setNavigationBarTitle({
            title: this.data.jsdata.questionlist.name
        });
    },
    jumpQuestion: function(t) {
        var e = this.data.jsdata;
        e.nowQid = t.currentTarget.dataset.index, this.setData({
            jsdata: e
        }), this.handleCommonData(e.datalists[e.nowQid]), this.hideModal();
    },
    reviewQuestionNum: function() {
        var t = this.data.jsdata, e = 0, a = 0, i = this.data.jsdata.datalists, s = [], n = {};
        if (i) for (var o = 0; o < i.length; o++) i[o].userAgainstDetailJsonVo.userAnswer ? 0 == i[o].userAgainstDetailJsonVo.rightOrWrong && (a += 1) : e += 1, 
        n[i[o].questionBasicInfo.id + "q"] = i[o].userAgainstDetailJsonVo.userAnswer, s[o] = {
            id: i[o].questionBasicInfo.id,
            userAnswer: i[o].userAgainstDetailJsonVo.userAnswer
        };
        t.notAnswerTotal = e, t.answerWrongTotal = a, t.answerData = s, t.answercard = n, 
        this.setData({
            jsdata: t
        }), this.showPopup();
    },
    getAnswerinfo: function(t) {
        var e = this;
        wx.request({
            url: getApp().web_config.web_url + "/api/examination/viewRecord",
            data: {
                recordId: t
            },
            header: {
                "content-type": "application/x-www-form-urlencoded",
                cookie: "SESSION=" + wx.getStorageSync("3rd_session")
            },
            method: "POST",
            success: function(t) {
                if (0 != t.data.status) return wx.showToast({
                    title: t.data.message,
                    icon: "none",
                    duration: 2e3,
                    success: function() {
                        var t = setInterval(function() {
                            wx.reLaunch({
                                url: "/pages/index/index"
                            }), clearInterval(t);
                        }, 2e3);
                    }
                }), !1;
                wx.redirectTo({
                    url: "/pages/answerFx/answerFx?id=" + t.data.data.recordId + "&examType=" + e.data.examType
                });
            },
            fail: function(t) {
                getApp().requestError();
            }
        });
    },
    onUnload: function() {
        clearInterval(this.data.timer), 2 == this.data.jsdata.isCollectUrl && (clearInterval(this.data.middleTimer), 
        this.middleExit()), 0 == this.data.jsdata.isCollectUrl && (this.setData({
            ismiddle: 1
        }), this.submitBrush());
    },
    getAnasylis: function(e) {
        var a = this;
        wx.request({
            url: t.web_config.web_url + "/api/questionPractice/findInformationListByQuestionId",
            data: {
                questionId: e
            },
            header: {
                "content-type": "application/x-www-form-urlencoded",
                cookie: "SESSION=" + wx.getStorageSync("3rd_session")
            },
            method: "get",
            success: function(t) {
                0 == t.data.status && a.setData({
                    analysisFile: t.data.data ? t.data.data : []
                });
            },
            fail: function(e) {
                t.requestError();
            }
        });
    }
});