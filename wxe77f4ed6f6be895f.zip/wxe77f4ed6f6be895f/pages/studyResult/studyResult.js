Page({
    data: {
        chapterId: "",
        questionType: "",
        chaptername: "",
        totalnumber: "",
        viewtype: "",
        picAddress: getApp().web_config.web_url
    },
    onLoad: function(e) {
        this.setData({
            chapterId: e.chapterId,
            questionType: e.questionType,
            chaptername: e.chaptername,
            totalnumber: e.totalnumber,
            viewtype: e.viewtype
        });
    },
    goOnlineStudy: function() {
        wx.reLaunch({
            url: "../onlineStudy/onlineStudy"
        });
    },
    goRedo: function() {
        wx.redirectTo({
            url: "../singleChoiceDetail/singleChoiceDetail?isCollectUrl=1&questionType=" + this.data.questionType + "&chapterId=" + this.data.chapterId + "&chaptername=" + this.data.chaptername + "&totalnumber=" + this.data.totalnumber
        });
    },
    onReady: function() {},
    onShow: function() {},
    onHide: function() {},
    onUnload: function() {},
    onPullDownRefresh: function() {},
    onReachBottom: function() {},
    onShareAppMessage: function() {}
});