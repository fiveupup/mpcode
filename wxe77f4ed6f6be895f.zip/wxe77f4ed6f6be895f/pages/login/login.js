require("../../E06A3E954A60E1DF860C5692828B10F4.js");

var t = getApp();

Page({
    data: {
        phone: "",
        password: "",
        canIUse: wx.canIUse("button.open-type.getUserInfo"),
        verifyCode: "",
        code: "",
        picAddress: getApp().web_config.web_url
    },
    bindViewTap: function() {
        wx.navigateTo({
            url: "../register/register"
        });
    },
    bindViewTap1: function() {
        wx.navigateTo({
            url: "../forget/forget"
        });
    },
    phoneInput: function(t) {
        this.setData({
            phone: t.detail.value
        });
    },
    passwordInput: function(t) {
        this.setData({
            password: t.detail.value
        });
    },
    yzmInput: function(t) {
        this.setData({
            verifyCode: t.detail.value
        });
    },
    login: function() {
        return 0 == this.data.phone.length || 0 == this.data.password.length || 0 == this.data.verifyCode.length ? (wx.showToast({
            title: "用户名,密码,验证码不能为空",
            icon: "none",
            duration: 2e3
        }), !1) : this.data.verifyCode.toUpperCase() !== this.data.code.toUpperCase() ? (wx.showToast({
            title: "验证码不正确",
            icon: "none",
            duration: 2e3
        }), !1) : void getApp().toLogin(this.data.phone, this.data.password, 0);
    },
    onLoad: function(t) {
        this.createCode();
    },
    huanyizhang: function() {
        this.createCode();
    },
    createCode: function() {
        var t;
        t = "";
        for (var e = new Array(2, 3, 4, 5, 6, 7, 8, 9, "A", "B", "C", "D", "E", "F", "G", "H", "J", "K", "L", "M", "N", "P", "Q", "R", "S", "T", "U", "V", "W", "X", "Y", "Z"), a = 0; a < 4; a++) {
            t += e[Math.floor(32 * Math.random())];
        }
        this.setData({
            code: t
        });
    },
    getUserInfo: function(e) {
        t.globalData.userInfo = e.detail.userInfo, this.setData({
            userInfo: e.detail.userInfo,
            hasUserInfo: !0
        });
    }
});