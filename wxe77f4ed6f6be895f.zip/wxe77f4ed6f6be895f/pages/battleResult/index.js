Page({
    data: {
        title: "恭喜你，获得胜利！",
        result_url: [ "", "https://static.yun.chinahrt.com/Appfiles/static/bwWeChatImg/battle/batttleVictory.png", "https://static.yun.chinahrt.com/Appfiles/static/bwWeChatImg/battle/battleFail.png", "https://static.yun.chinahrt.com/Appfiles/static/bwWeChatImg/battle/battleEQ.png" ],
        if_win: 1,
        imgwidth: 0,
        totalTime: 0,
        score: 0,
        recordId: "",
        imgheight: 0
    },
    onLoad: function(t) {
        this.setData({
            title: t.title,
            if_win: t.if_win,
            score: t.score,
            recordId: t.recordId,
            totalTime: t.totalTime
        });
    },
    onReady: function() {},
    onShow: function() {},
    onHide: function() {},
    onUnload: function() {},
    onPullDownRefresh: function() {},
    onReachBottom: function() {},
    onShareAppMessage: function() {},
    goBattle: function() {
        wx.redirectTo({
            url: "/pages/battleIntroduce/index"
        });
    },
    goBattleRecord: function(t) {
        wx.navigateTo({
            url: "/pages/battleRecord/index?againstRecordId=" + this.data.recordId
        });
    }
});