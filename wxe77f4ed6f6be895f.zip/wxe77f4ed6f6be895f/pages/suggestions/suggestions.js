var t = getApp(), e = require("../../13753E374A60E1DF75135630065B10F4.js");

Page({
    data: {
        selectArray: [ {
            id: "001001",
            text: "对加强窗口经办队伍建设的意见建议"
        }, {
            id: "001002",
            text: "对练兵比武活动的意见反馈"
        } ],
        email: "",
        content: "",
        selectid: "",
        tabbar: {},
        isShow: !0
    },
    showTextarea: function(t) {
        this.setData({
            isShow: !this.data.isShow
        }), this.charChange();
    },
    handleEventListener: function(t) {
        this.setData({
            selectid: t.detail.selectid
        });
    },
    bindKeyInput: function(t) {
        this.setData({
            email: t.detail.value
        });
    },
    charChange: function(t) {
        this.setData({
            content: t.detail.value
        }), this.setData({
            content: this.data.content
        });
    },
    addAdvise: function() {
        var t = this, n = this.data.email;
        return n ? e.isEmail(n) ? this.data.selectid ? this.data.content ? void wx.request({
            url: getApp().web_config.web_url + "/api/studentAdvise/addAdvise",
            data: {
                content: this.data.content,
                contentType: this.data.selectid,
                email: this.data.email
            },
            header: {
                "content-type": "application/x-www-form-urlencoded",
                cookie: "SESSION=" + wx.getStorageSync("3rd_session")
            },
            method: "POST",
            success: function(t) {
                0 == t.data.status ? wx.showToast({
                    title: "提交成功",
                    con: "success",
                    duration: 2e3,
                    success: function() {
                        setTimeout(function() {
                            wx.reLaunch({
                                url: "/pages/index/index"
                            });
                        }, 1e3);
                    }
                }) : getApp().chkResponse(t);
            },
            fail: function(e) {
                t.addfail();
            }
        }) : (wx.showToast({
            title: "请填写详情描述",
            con: "none",
            duration: 2e3
        }), !1) : (wx.showToast({
            title: "请选择反馈类型",
            con: "none",
            duration: 2e3
        }), !1) : (wx.showToast({
            title: "邮箱格式不正确！",
            con: "none",
            duration: 2e3
        }), !1) : (wx.showToast({
            title: "请填写邮箱！",
            con: "none",
            duration: 2e3
        }), !1);
    },
    addfail: function() {
        wx.showToast({
            title: "添加失败！",
            con: "success",
            duration: 2e3,
            success: function() {
                setTimeout(function() {
                    wx.navigateBack({
                        delta: 1
                    });
                }, 1e3);
            }
        });
    },
    onLoad: function(e) {
        t.editTabbar(), wx.hideTabBar();
    },
    onReady: function() {},
    onShow: function() {
        wx.hideTabBar();
    },
    onHide: function() {},
    onUnload: function() {},
    onPullDownRefresh: function() {},
    onReachBottom: function() {},
    onShareAppMessage: function() {}
});