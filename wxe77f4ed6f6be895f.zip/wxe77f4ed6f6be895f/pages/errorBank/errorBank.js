Page({
    data: {
        pageSize: 15,
        curPage: 1,
        loading: !1,
        nomore: !1,
        errorlist: {},
        height: 600
    },
    onLoad: function(t) {
        var e = this;
        this.getErrorlists(), wx.getSystemInfo({
            success: function(t) {
                e.setData({
                    height: t.windowHeight
                });
            }
        });
    },
    errorReAnswer: function(t) {
        wx.navigateTo({
            url: "/pages/singleChoiceDetail/singleChoiceDetail?chaptername=" + t.currentTarget.dataset.name + "&isCollectUrl=4&recordId=" + t.currentTarget.dataset.id
        });
    },
    scrolltoupper: function() {
        var t = this.data.curPage;
        t += 1, this.setData({
            curPage: t
        }), this.getErrorlists();
    },
    getErrorlists: function() {
        wx.showLoading({
            title: "加载中",
            icon: "loading",
            duration: 500
        });
        var t = this;
        t.data.nomore ? wx.showToast({
            title: "我也是有底线的",
            icon: "success",
            duration: 2e3
        }) : (t.setData({
            loading: !0
        }), t.data.loading && wx.request({
            url: getApp().web_config.web_url + "/api/misAnsweredQuestion/listRecords",
            data: {
                pageSize: t.data.pageSize,
                curPage: t.data.curPage
            },
            header: {
                "content-type": "application/json",
                cookie: "SESSION=" + wx.getStorageSync("3rd_session")
            },
            method: "GET",
            success: function(e) {
                if (0 == e.data.status) {
                    var a = t.data.errorlist;
                    if (a.length > 0) {
                        if (0 == e.data.data.rows.length) return wx.showToast({
                            title: "我也是有底线的",
                            icon: "success",
                            duration: 2e3
                        }), t.setData({
                            errorlist: a,
                            loading: !1,
                            nomore: !0
                        }), !1;
                        for (var o = 0; o < e.data.data.rows.length; o++) a.push(e.data.data.rows[o]);
                    } else a = e.data.data.rows;
                    t.setData({
                        errorlist: a,
                        loading: !1
                    }), t.onPullDownRefresh();
                } else getApp().chkResponse(e);
            },
            fail: function(t) {
                app.requestError();
            }
        }));
    },
    onReady: function() {},
    onShow: function() {},
    onHide: function() {},
    onUnload: function() {},
    onPullDownRefresh: function() {},
    onReachBottom: function() {},
    onShareAppMessage: function() {}
});