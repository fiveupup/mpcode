var t = getApp();

Page({
    data: {
        countryList: [],
        cityList: [],
        countryIndex: 0,
        cityIndex: 0,
        rankingList: [],
        picAddress: getApp().web_config.web_url,
        count: 0,
        userinfo: "",
        realNameHead: "",
        orgNameHead: "",
        userRank: "",
        loading: !1,
        nomore: !1,
        curPage: 1,
        pid: 3202,
        cityTrue: !1,
        dayActive: "active",
        weekActive: "",
        monthActive: "",
        battleActive: "",
        pointType: "019001",
        tabbar: {},
        orgId: "",
        provinceId: "",
        showModal: !1
    },
    dayClick: function() {
        this.setData({
            dayActive: "active",
            weekActive: "",
            battleActive: "",
            monthActive: "",
            pointType: "019001",
            orgId: this.data.provinceId,
            countryIndex: 0,
            cityIndex: 0
        }), this.rankingList();
    },
    weekClick: function() {
        this.setData({
            dayActive: "",
            weekActive: "active",
            battleActive: "",
            monthActive: "",
            pointType: "019002",
            orgId: "",
            countryIndex: 0,
            cityIndex: 0
        }), this.rankingList();
    },
    monthClick: function() {
        this.setData({
            dayActive: "",
            weekActive: "",
            monthActive: "active",
            battleActive: "",
            pointType: "019003",
            orgId: this.data.provinceId,
            countryIndex: 0,
            cityIndex: 0
        }), this.rankingList();
    },
    battleClick: function() {
        this.setData({
            dayActive: "",
            weekActive: "",
            monthActive: "",
            battleActive: "active",
            pointType: "019004",
            orgId: this.data.provinceId,
            countryIndex: 0,
            cityIndex: 0
        }), this.rankingList();
    },
    toMore: function() {
        wx.navigateTo({
            url: "/pages/moreinfo/moreinfo"
        });
    },
    showDialog: function() {
        this.setData({
            showModal: !0
        });
    },
    closeAlert: function() {
        this.setData({
            showModal: !1
        });
    },
    errorFunction: function() {
        this.setData({
            photo: "getApp().web_config.web_url/images/headPicture.png"
        });
    },
    changeCountry: function(t) {
        var e = this;
        e.setData({
            countryIndex: t.detail.value,
            orgId: e.data.countryList[t.detail.value].id
        }), e.rankingList();
        e.setData({
            cityList: [],
            cityIndex: 0,
            pid: e.data.countryList[t.detail.value].id
        }), wx.request({
            url: getApp().web_config.web_url + "/api/organization/getByPId",
            data: {
                pid: e.data.pid
            },
            method: "get",
            header: {
                "content-type": "application/json"
            },
            success: function(t) {
                var i;
                0 == t.data.status ? ((i = t.data.data).unshift({
                    name: "请选择",
                    id: ""
                }), e.setData({
                    cityList: i,
                    cityTrue: !0,
                    orgId: e.data.pid
                }), e.rankingList()) : (getApp().chkResponse(t), (i = []).unshift({
                    name: "请选择",
                    id: ""
                }), e.setData({
                    cityList: i,
                    cityTrue: !0
                }));
            },
            fail: function(t) {
                getApp().requestError();
            }
        });
    },
    changeCity: function(t) {
        this.setData({
            cityIndex: t.detail.value,
            orgId: this.data.cityList[t.detail.value].id
        }), this.rankingList();
    },
    initprovince: function() {
        var t = this;
        wx.request({
            url: getApp().web_config.web_url + "/api/organization/get2Level",
            data: {},
            method: "get",
            header: {
                "content-type": "application/json"
            },
            success: function(e) {
                if (0 == e.data.status) {
                    var i = e.data.data;
                    i.unshift({
                        name: "请选择",
                        id: ""
                    }), t.setData({
                        countryList: i
                    }), wx.request({
                        url: getApp().web_config.web_url + "/api/organization/getByPId",
                        data: {
                            pid: t.data.pid
                        },
                        method: "get",
                        header: {
                            "content-type": "application/json"
                        },
                        success: function(e) {
                            var i;
                            0 == e.data.status ? ((i = e.data.data).unshift({
                                name: "请选择",
                                id: ""
                            }), t.setData({
                                cityList: i,
                                cityTrue: !0
                            }), t.rankingList()) : (getApp().chkResponse(e), (i = []).unshift({
                                name: "请选择",
                                id: ""
                            }), t.setData({
                                cityList: i,
                                cityTrue: !0
                            }));
                        },
                        fail: function(t) {
                            getApp().requestError();
                        }
                    });
                } else getApp().chkResponse(e);
            },
            fail: function(t) {
                getApp().requestError();
            }
        });
    },
    getUserRank: function() {
        var t = this;
        wx.request({
            url: getApp().web_config.web_url + "/api/studentPoint/getCurrentUserRanking",
            data: {
                platformId: 1,
                pointType: t.data.pointType
            },
            method: "get",
            header: {
                "content-type": "application/json",
                cookie: "SESSION=" + wx.getStorageSync("3rd_session")
            },
            success: function(e) {
                if (0 == e.data.status) {
                    var i = e.data.data;
                    t.setData({
                        userRank: i
                    });
                } else getApp().chkResponse(e);
            },
            fail: function(t) {
                getApp().requestError();
            }
        });
    },
    rankingList: function() {
        var t = this;
        wx.request({
            url: getApp().web_config.web_url + "/api/studentPoint/listRanking",
            data: {
                orgId: t.data.orgId,
                number: 50,
                pointType: t.data.pointType
            },
            method: "get",
            header: {
                "content-type": "application/json",
                cookie: "SESSION=" + wx.getStorageSync("3rd_session")
            },
            success: function(e) {
                0 == e.data.status ? t.setData({
                    rankingList: e.data.data
                }) : getApp().chkResponse(e);
            }
        });
    },
    onLoad: function() {
        var e = this;
        if (t.editTabbar(), wx.hideTabBar(), wx.getSystemInfo({
            success: function(t) {
                e.setData({
                    height: t.windowHeight - 150
                });
            }
        }), !wx.getStorageSync("userinfo")) return wx.showToast({
            title: "登录信息失效，请重新登录！",
            icon: "none",
            duration: 2e3
        }), void setTimeout(function() {
            wx.navigateTo({
                url: "../login/login"
            });
        }, 1e3);
        this.getUserRank(), this.initprovince();
    },
    onShow: function() {
        wx.hideTabBar();
    },
    onShareAppMessage: function() {}
});