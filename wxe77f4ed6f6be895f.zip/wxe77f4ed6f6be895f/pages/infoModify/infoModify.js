var t, e, a = require("../../@babel/runtime/helpers/defineProperty"), i = require("../../13753E374A60E1DF75135630065B10F4.js");

Page((e = {
    data: (t = {
        picAddress: getApp().web_config.web_url,
        userinfo: {},
        province: [],
        classList: [],
        blockList: [],
        ifShow: !1,
        ifShow1: !1,
        orgId: "",
        realname: "",
        department: "",
        birthday: ""
    }, a(t, "picAddress", getApp().web_config.web_url), a(t, "index", ""), a(t, "index1", ""), 
    a(t, "index2", ""), a(t, "userIndex", ""), a(t, "pathArr", []), a(t, "userTypeOptions", []), 
    a(t, "system", ""), t),
    bindDateChange: function(t) {
        var e = this.data.userinfo;
        e.birthday = t.detail.value, e.birthday = new Date(e.birthday);
        var a = e.birthday.getMonth() + 1;
        a = a > 9 ? a : "0" + a;
        var i = e.birthday.getDate();
        i = i > 9 ? i : "0" + i, e.birthday = e.birthday.getFullYear() + "-" + a + "-" + i, 
        this.setData({
            userinfo: e
        });
    },
    input_real: function(t) {
        var e = this.data.userinfo;
        e.realName = t.detail.value, this.setData({
            userinfo: e
        });
    },
    input_department: function(t) {
        var e = this.data.userinfo;
        e.department = t.detail.value, this.setData({
            userinfo: e
        });
    },
    provinceInit: function() {
        var t = this;
        wx.request({
            url: getApp().web_config.web_url + "/api/organization/get2Level",
            data: {},
            method: "get",
            header: {
                "content-type": "application/json",
                cookie: "SESSION=" + wx.getStorageSync("3rd_session")
            },
            success: function(e) {
                if (0 == e.data.status) {
                    t.setData({
                        province: e.data.data
                    });
                    "";
                } else getApp().chkResponse(e);
            }
        });
    }
}, a(e, "provinceInit", function() {
    var t = this;
    wx.request({
        url: getApp().web_config.web_url + "/api/organization/get2Level",
        data: {},
        method: "get",
        header: {
            "content-type": "application/json"
        },
        success: function(e) {
            t.setData({
                province: e.data.data
            });
            var a = "";
            t.data.pathArr.length > 1 && (a = t.data.pathArr[2]), a && t.citySelect(a);
        }
    });
}), a(e, "bindUserType", function(t) {
    this.setData({
        userIndex: t.detail.value
    });
}), a(e, "bindPickerProvince", function(t) {
    this.setData({
        index: t.detail.value
    }), this.citySelect(this.data.province[this.data.index].id);
}), a(e, "bindPickerCity", function(t) {
    this.setData({
        index1: t.detail.value
    }), this.blockSelect(this.data.classList[this.data.index1].id);
}), a(e, "bindPickerBlock", function(t) {
    console.log("picker发送选择改变，携带值为", t.detail.value), this.setData({
        index2: t.detail.value,
        orgId: this.data.blockList[t.detail.value].id
    });
}), a(e, "citySelect", function(t) {
    var e = this;
    t && this.setData({
        pid: t
    }, function() {
        wx.request({
            url: getApp().web_config.web_url + "/api/organization/getByPId",
            https: "",
            method: "get",
            header: {
                "content-type": "application/x-www-form-urlencoded",
                Accept: "application/json"
            },
            data: {
                pid: e.data.pid
            },
            success: function(t) {
                t.data.data.length > 0 ? e.setData({
                    ifShow: !0,
                    ifShow1: !1
                }) : e.setData({
                    ifShow: !1,
                    ifShow1: !1
                });
                var a = t.data.data;
                e.setData({
                    classList: a,
                    orgId: "",
                    index1: "",
                    index2: ""
                });
                var i = "";
                e.data.pathArr.length > 1 && (i = e.data.pathArr[3]), i && e.blockSelect(i);
            }
        });
    });
}), a(e, "blockSelect", function(t) {
    var e = this;
    t && this.setData({
        pid: t
    }, function() {
        wx.request({
            url: getApp().web_config.web_url + "/api/organization/getByPId",
            https: "",
            method: "get",
            header: {
                "content-type": "application/x-www-form-urlencoded",
                Accept: "application/json"
            },
            data: {
                pid: e.data.pid
            },
            success: function(a) {
                a.data.data.length > 0 ? e.setData({
                    ifShow1: !0
                }) : e.setData({
                    ifShow1: !1,
                    orgId: t
                });
                var i = a.data.data;
                if (e.setData({
                    blockList: i
                }), e.data.pathArr.length > 1) {
                    var n = e.findIndex(e.data.pathArr[2], e.data.province), s = e.findIndex(e.data.pathArr[3], e.data.classList), o = e.findIndex(e.data.pathArr[4], i);
                    e.setData({
                        index: n,
                        index1: s,
                        index2: o,
                        orgId: e.data.pathArr[4],
                        pathArr: []
                    });
                }
            }
        });
    });
}), a(e, "findIndex", function(t, e) {
    for (var a = 0; a < e.length; a++) if (e[a].id == t) return a;
}), a(e, "findUserIndex", function(t, e) {
    for (var a = 0; a < e.length; a++) if (e[a].value == t) return a;
}), a(e, "onLoad", function(t) {
    var e = this;
    wx.getSystemInfo({
        success: function(t) {
            e.setData({
                systemInfo: t
            }), "devtools" == t.platform ? e.setData({
                system: "devtools"
            }) : "ios" == t.platform ? e.setData({
                system: "ios"
            }) : "android" == t.platform && e.setData({
                system: "android"
            });
        }
    });
    var a = wx.getStorageSync("userinfo");
    a.birthday = a.birthday ? a.birthday.slice(0, 10) : "";
    var n = i.getDicSelect("022");
    console.log(n, "userTypeOptions");
    var s = e.findUserIndex(a.userType, n);
    this.setData({
        userinfo: a,
        pathArr: a.orgPath ? a.orgPath.split("-") : [],
        userTypeOptions: n,
        userIndex: s
    }), this.provinceInit();
}), a(e, "infoModify", function() {
    if (this.data.userinfo.realName) if (this.data.userinfo.birthday) if ("" !== this.data.userIndex) if (0 != this.data.userIndex || "" != this.data.userinfo.department) {
        var t = "";
        "" === this.data.index || (this.data.ifShow1 ? "" !== this.data.index2 && (t = this.data.blockList[this.data.index2].id) : this.data.ifShow && "" !== this.data.index1 && (t = this.data.classList[this.data.index1].id), 
        "" != t) ? wx.request({
            url: getApp().web_config.web_url + "/api/candidate/updateInfo",
            data: {
                orgId: t,
                birthday: this.data.userinfo.birthday,
                department: "022002" == this.data.userTypeOptions[this.data.userIndex].value ? "" : this.data.userinfo.department,
                realName: this.data.userinfo.realName,
                userType: this.data.userTypeOptions[this.data.userIndex].value
            },
            method: "post",
            header: {
                "content-type": "application/x-www-form-urlencoded",
                cookie: "SESSION=" + wx.getStorageSync("3rd_session")
            },
            success: function(t) {
                if (0 == t.data.status) return wx.setStorageSync("userinfo", t.data.data), wx.showToast({
                    title: "修改成功",
                    icon: "none",
                    duration: 2e3,
                    success: function() {
                        wx.reLaunch({
                            url: "/pages/personal/personal"
                        });
                    }
                }), !1;
                getApp().chkResponse(t);
            }
        }) : wx.showToast({
            title: "组织机构是必选项",
            icon: "none",
            duration: 1e3
        });
    } else wx.showToast({
        title: "工作单位是必填项",
        icon: "none",
        duration: 1e3
    }); else wx.showToast({
        title: "用户类型是必选项",
        icon: "none",
        duration: 1e3
    }); else wx.showToast({
        title: "出生日期是必选项",
        icon: "none",
        duration: 1e3
    }); else wx.showToast({
        title: "真实姓名是必填项",
        icon: "none",
        duration: 1e3
    });
}), a(e, "onReady", function() {}), a(e, "onShow", function() {
    wx.request({
        url: getApp().web_config.web_url + "/api/session/getSession",
        data: {},
        method: "post",
        header: {
            "content-type": "application/x-www-form-urlencoded",
            cookie: "SESSION=" + wx.getStorageSync("3rd_session")
        },
        success: function(t) {
            0 == t.data.status ? wx.setStorageSync("userinfo", t.data.data) : getApp().chkResponse(t);
        }
    });
}), a(e, "onHide", function() {}), a(e, "onUnload", function() {}), a(e, "onPullDownRefresh", function() {}), 
a(e, "onReachBottom", function() {}), a(e, "onShareAppMessage", function() {}), 
e));