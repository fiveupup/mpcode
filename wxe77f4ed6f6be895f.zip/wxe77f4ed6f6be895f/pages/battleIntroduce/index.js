var e = getApp();

Page({
    data: {
        userInfo: [],
        isAgree: !1,
        examType: 1,
        ruleText: "",
        classRule: "dayRules",
        showModal: !1,
        todayAnswerNum: 0,
        height: e.globalData.deviceHeight,
        isIpx: e.globalData.isIpx
    },
    onLoad: function(t) {
        e.chkLogin(), this.setData({
            weekRule: this.data.newWeekRule
        });
        var a = this.data.height, s = this.data.isIpx;
        a < 600 && !s ? this.setData({
            height: "390rpx"
        }) : a > 600 && !s ? this.setData({
            height: a - 260
        }) : a > 600 && s && this.setData({
            height: a - 280
        });
    },
    closeAlert: function() {
        this.setData({
            showModal: !1
        });
    },
    checkboxChange: function() {
        this.setData({
            isAgree: !this.data.isAgree
        });
    },
    showAlert: function() {
        this.setData({
            showModal: !0
        });
    },
    goBattleQw: function() {
        if (this.data.isAgree) {
            wx.redirectTo({
                url: "/pages/selectedProvinve/index"
            });
        } else wx.showToast({
            title: "请先同意规则",
            icon: "none",
            duration: 2e3
        });
    },
    goMonthTest: function() {
        if (3 != this.data.examType || this.data.isAgree) {
            var e = 1 == this.data.examType ? "/pages/onlineStudy/onlineStudy" : 2 == this.data.examType ? "/pages/weekGame/weekGame" : "/pages/startAnswer/startAnswer?isCollectUrl=99&examType=009001";
            3 == this.data.examType ? wx.showModal({
                title: "提示",
                content: "确定要参加月月比？",
                success: function(t) {
                    t.confirm ? wx.redirectTo({
                        url: e
                    }) : t.cancel;
                }
            }) : wx.redirectTo({
                url: e
            });
        } else wx.showToast({
            title: "请先同意规则",
            icon: "none",
            duration: 2e3
        });
    },
    goBattleMachine: function() {
        if (this.data.isAgree) {
            wx.redirectTo({
                url: "/pages/onlineStudy/onlineStudy?from=1"
            });
        } else wx.showToast({
            title: "请先同意规则",
            icon: "none",
            duration: 2e3
        });
    }
});