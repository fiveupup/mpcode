Page({
    data: {
        height: "",
        pageSize: 5,
        curPage: 1,
        topNum: 0,
        athleticsLevel: "",
        athleticsPoint: "",
        people: [],
        computer: [],
        findFightTimes: [],
        recordList: []
    },
    onLoad: function(t) {
        var e = this;
        wx.getSystemInfo({
            success: function(t) {
                e.setData({
                    height: t.windowHeight - 250
                });
            }
        }), this.findFightRecords(), this.getUserAthleticsPoint(), this.findFightTimes(), 
        this.findFightResultInfo(0), this.findFightResultInfo(1);
    },
    onReady: function() {},
    onShow: function() {},
    onHide: function() {},
    onUnload: function() {},
    onPullDownRefresh: function() {},
    onReachBottom: function() {},
    onShareAppMessage: function() {},
    scrolltoupper: function() {
        var t = this.data.curPage;
        t += 1, this.setData({
            curPage: t
        }), this.findFightRecords();
    },
    goTop: function(t) {
        this.setData({
            topNum: this.data.topNum = 0
        }), wx.showToast({
            title: "回到顶部",
            icon: "success",
            duration: 1500
        });
    },
    lower: function() {
        for (var t = this, e = this.data.recordList, a = [], i = 0; i < 10; i++) a.push(i);
        var o = e.concat(a);
        if (console.log(a.length), o.length >= 100) return wx.showToast({
            title: "我也是有底线的",
            icon: "success",
            duration: 300
        }), !1;
        wx.showLoading({
            title: "加载中",
            icon: "loading"
        }), setTimeout(function() {
            t.setData({
                res: o
            }), wx.hideLoading();
        }, 1500);
    },
    getUserAthleticsPoint: function() {
        var t = this;
        wx.request({
            url: getApp().web_config.web_url + "/api/studentPoint/getUserAthleticsPoint",
            data: {},
            method: "get",
            header: {
                "content-type": "application/json",
                cookie: "SESSION=" + wx.getStorageSync("3rd_session")
            },
            success: function(e) {
                0 == e.data.status ? t.setData({
                    yueyuebiTotalPoint: e.data.data.yueyuebiTotalPoint,
                    athleticsLevel: e.data.data.athleticsLevel
                }) : getApp().chkResponse(e);
            },
            fail: function(t) {
                getApp().requestError();
            }
        });
    },
    findFightResultInfo: function(t) {
        var e = this;
        wx.request({
            url: getApp().web_config.web_url + "/api/fight/findFightResultInfo?againstWay=" + t,
            data: {},
            method: "get",
            header: {
                "content-type": "application/json",
                cookie: "SESSION=" + wx.getStorageSync("3rd_session")
            },
            success: function(a) {
                0 == a.data.status ? t ? e.setData({
                    computer: a.data.data
                }) : e.setData({
                    people: a.data.data
                }) : getApp().chkResponse(a);
            },
            fail: function(t) {
                getApp().requestError();
            }
        });
    },
    findFightRecords: function() {
        var t = this, e = t.data.curPage;
        wx.request({
            url: getApp().web_config.web_url + "/api/fight/findFightRecords?curPage=" + e + "&pageSize=" + t.data.pageSize,
            data: {},
            method: "get",
            header: {
                "content-type": "application/json",
                cookie: "SESSION=" + wx.getStorageSync("3rd_session")
            },
            success: function(e) {
                if (0 == e.data.status) {
                    var a = t.data.recordList;
                    if (a.length > 0) {
                        if (0 == e.data.data.rows.length) return wx.showToast({
                            title: "我也是有底线的",
                            icon: "success",
                            duration: 2e3
                        }), t.setData({
                            recordList: a,
                            loading: !1,
                            nomore: !0
                        }), !1;
                        for (var i = 0; i < e.data.data.rows.length; i++) a.push(e.data.data.rows[i]);
                    } else a = e.data.data.rows;
                    t.setData({
                        recordList: a,
                        loading: !1
                    }), t.onPullDownRefresh();
                } else getApp().chkResponse(e);
            },
            fail: function(t) {
                getApp().requestError();
            }
        });
    },
    findFightTimes: function(t) {
        var e = this;
        wx.request({
            url: getApp().web_config.web_url + "/api/fight/findFightTimes",
            data: {},
            method: "get",
            header: {
                "content-type": "application/json",
                cookie: "SESSION=" + wx.getStorageSync("3rd_session")
            },
            success: function(t) {
                0 == t.data.status ? e.setData({
                    findFightTimes: t.data.data
                }) : getApp().chkResponse(t);
            },
            fail: function(t) {
                getApp().requestError();
            }
        });
    },
    goBattleRecord: function(t) {
        var e = t.currentTarget.dataset.id;
        wx.navigateTo({
            url: "/pages/battleRecord/index?againstRecordId=" + e
        });
    }
});