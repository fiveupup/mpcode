var e = getApp();

Page({
    data: {
        picAddress: getApp().web_config.web_url,
        tabbar: {},
        nvabarData: {
            showCapsule: 1,
            title: "首页"
        },
        height: 2 * e.globalData.height + 20,
        width: 0,
        headImgWith: 0
    },
    onLoad: function(t) {
        var o = this, n = Date.parse(new Date()), a = wx.getStorageSync("showNoticeTimes") ? wx.getStorageSync("showNoticeTimes") : 0;
        n < 15899904e5 && a < n - 864e5 && (wx.setStorageSync("showNoticeTimes", Date.parse(new Date())), 
        wx.showModal({
            title: "通知",
            content: "各地行风建设机构：\r\n 为保证月月比活动顺利进行，部在线练兵平台将于5月8日0时—24时、5月21日0时—24时进行两次压力测试。请各地组织学员在测试时间段登录答题，并及时收集反馈学员意见建议。",
            success: function(e) {
                e.confirm ? console.log("用户点击确定") : e.cancel && console.log("用户点击取消");
            }
        })), e.editTabbar(), wx.hideTabBar(), wx.getSystemInfo({
            success: function(e) {
                o.setData({
                    height: e.windowHeight - 20,
                    width: e.windowWidth,
                    headImgWith: Math.ceil(e.windowWidth / 1.44578313)
                });
            }
        });
    },
    myCollection: function() {
        wx.navigateTo({
            url: "../collectionlist/collectionlist"
        });
    },
    answerRecord: function() {
        wx.navigateTo({
            url: "../answerRecord/answerRecord"
        });
    },
    errorbank: function() {
        wx.navigateTo({
            url: "../errorBank/errorBank"
        });
    },
    onReady: function() {},
    onShow: function() {
        wx.hideTabBar();
        var e = wx.getStorageSync("userinfo");
        e && e.timestamp > Date.parse(new Date()) && getApp().toLogin(e.mobile, e.password, 1);
    },
    onHide: function() {},
    onUnload: function() {},
    onPullDownRefresh: function() {},
    onReachBottom: function() {},
    onShareAppMessage: function() {},
    goMonth: function() {
        wx.request({
            url: getApp().web_config.web_url + "/api/fight/findIsHasAttend",
            data: {},
            method: "get",
            header: {
                "content-type": "application/json",
                cookie: "SESSION=" + wx.getStorageSync("3rd_session")
            },
            success: function(e) {
                if (0 == e.data.status) {
                    if (e.data.data.hasAttend) {
                        if (!e.data.data.fighting) return void wx.showToast({
                            title: "今日已参加过月月比",
                            icon: "none",
                            duration: 1500
                        });
                        wx.redirectTo({
                            url: "/pages/battleIntroduce/index"
                        });
                    }
                    wx.redirectTo({
                        url: "/pages/battleIntroduce/index"
                    });
                } else getApp().chkResponse(e);
            },
            fail: function(e) {
                getApp().requestError();
            }
        });
    }
});