getApp();

Page({
    data: {
        honorList: [],
        challengeList: []
    },
    onLoad: function(e) {
        var t = this;
        wx.getSystemInfo({
            success: function(e) {
                t.setData({
                    height: e.windowHeight - 80
                });
            }
        }), this.getData();
    },
    goCert: function(e) {
        wx.navigateTo({
            url: "/pages/cert/cert?name=" + e.currentTarget.dataset.name + "&month=" + e.currentTarget.dataset.month + "&certtime=" + e.currentTarget.dataset.certtime + "&id=" + e.currentTarget.dataset.id
        });
    },
    getData: function() {
        var e = this;
        if ("13862587973" != wx.getStorageSync("userinfo").mobile) wx.request({
            url: getApp().web_config.web_url + "/api/medal/myMedal",
            data: {},
            method: "get",
            header: {
                "content-type": "application/json",
                cookie: "SESSION=" + wx.getStorageSync("3rd_session")
            },
            success: function(t) {
                0 == t.data.status ? e.setData({
                    honorList: t.data.data
                }) : getApp().chkResponse(t);
            }
        }); else {
            e.setData({
                honorList: [ {
                    id: "1",
                    imgUrl: "http://1.jpg",
                    description: "日日学",
                    name: "日日学",
                    gmtCreate: "2020-03-17 13:36:39",
                    gmtModified: "2020-03-17 13:36:41",
                    isDeleted: 0,
                    versionId: 0,
                    medalList: [ {
                        name: "7月份"
                    }, {
                        name: "8月份"
                    } ],
                    medalNum: 0
                }, {
                    id: "2",
                    imgUrl: "http://2.jpg",
                    description: "周周练",
                    name: "周周练",
                    gmtCreate: "2020-03-20 13:19:22",
                    gmtModified: "2020-03-20 13:19:28",
                    isDeleted: 0,
                    versionId: 0,
                    medalList: [ {
                        name: "7月份"
                    }, {
                        name: "8月份"
                    } ],
                    medalNum: 0
                }, {
                    id: "3",
                    imgUrl: "http://3.jpg",
                    description: "岗位练兵明星",
                    name: "岗位练兵明星",
                    gmtCreate: "2020-03-20 13:19:26",
                    gmtModified: "2020-03-20 13:19:30",
                    isDeleted: 0,
                    versionId: 0,
                    medalList: [ {
                        name: "7月份"
                    }, {
                        name: "8月份"
                    } ],
                    medalNum: 0
                } ]
            });
        }
    },
    getChallenge: function() {
        var e = this;
        wx.getStorageSync("userinfo");
        wx.request({
            url: getApp().web_config.web_url + "/api/medal/findMyAthleticsMedalList",
            data: {},
            method: "get",
            header: {
                "content-type": "application/json",
                cookie: "SESSION=" + wx.getStorageSync("3rd_session")
            },
            success: function(t) {
                0 == t.data.status ? e.setData({
                    challengeList: t.data.data
                }) : getApp().chkResponse(t);
            }
        });
    }
});