Page({
    data: {
        name: "",
        username: "",
        certtime: "",
        month: "",
        id: ""
    },
    onLoad: function(n) {
        var o = wx.getStorageSync("userinfo"), t = "";
        2 == n.id ? (t = n.month.substr(0, 2), t = parseInt(t), console.log(t, "mounth"), 
        t = t > 9 ? n.month.substr(0, 6) : n.month.substr(0, 5)) : t = 3 == n.id ? n.month : n.month.substr(0, 2), 
        console.log(t, "mounth"), this.setData({
            username: o.realName,
            name: n.name,
            id: n.id,
            month: t,
            certtime: n.certtime.substr(0, 10)
        });
    },
    onReady: function() {},
    onShow: function() {},
    onHide: function() {},
    onUnload: function() {},
    onPullDownRefresh: function() {},
    onReachBottom: function() {},
    onShareAppMessage: function() {}
});