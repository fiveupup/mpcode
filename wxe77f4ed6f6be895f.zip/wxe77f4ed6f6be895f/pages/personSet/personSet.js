getApp();

Page({
    data: {
        picAddress: "https://static.yun.chinahrt.com/Appfiles"
    },
    jumpInfor: function() {
        wx.navigateTo({
            url: "../infoModify/infoModify"
        });
    },
    jumpPassword: function() {
        wx.navigateTo({
            url: "../changePassword/changePassword"
        });
    },
    logout: function() {
        wx.setStorageSync("3rd_session", ""), wx.setStorageSync("userinfo", ""), wx.showToast({
            title: "退出成功！",
            icon: "success",
            duration: 2e3
        }), setTimeout(function() {
            wx.reLaunch({
                url: "/pages/index/index"
            });
        }, 1e3);
        wx.request({
            url: getApp().web_config.web_url + "/api/candidate/logout",
            data: {},
            method: "get",
            header: {
                "content-type": "application/json",
                cookie: "SESSION=" + wx.getStorageSync("3rd_session")
            },
            success: function(n) {
                n.data.status;
            },
            fail: function(n) {
                getApp().requestError();
            }
        });
    },
    onLoad: function() {
        if (!wx.getStorageSync("userinfo")) return wx.showToast({
            title: "登录信息失效，请重新登录！",
            icon: "none",
            duration: 2e3
        }), void setTimeout(function() {
            wx.navigateTo({
                url: "../login/login"
            });
        }, 1e3);
    },
    onHide: function() {},
    onUnload: function() {},
    onPullDownRefresh: function() {},
    onReachBottom: function() {},
    onShareAppMessage: function() {}
});