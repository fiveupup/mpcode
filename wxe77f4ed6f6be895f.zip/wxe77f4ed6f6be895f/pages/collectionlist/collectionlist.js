var t = require("../../13753E374A60E1DF75135630065B10F4.js");

Page({
    data: {
        showIndex: "",
        pageData: {},
        totalnum: 0,
        picAddress: getApp().web_config.web_url
    },
    onLoad: function(t) {
        this.getCollection();
    },
    getCollection: function() {
        var t = this;
        wx.request({
            url: getApp().web_config.web_url + "/api/collectionLibrary/listCollection",
            data: {},
            header: {
                "content-type": "application/json",
                cookie: "SESSION=" + wx.getStorageSync("3rd_session")
            },
            method: "GET",
            success: function(e) {
                if (0 == e.data.status) {
                    var a = e.data.data, n = t.data.totalnum;
                    if (a.length > 0) for (var o = 0; o < a.length; o++) a[o].collectNumbers > 0 && (n += Number(a[o].collectNumbers));
                    t.setData({
                        pageData: a,
                        totalnum: n
                    });
                } else getApp().chkResponse(e);
            },
            fail: function(t) {
                getApp().requestError();
            }
        });
    },
    getCollectionLists: function(e) {
        var a = this;
        wx.request({
            url: getApp().web_config.web_url + "/api/collectionLibrary/getNumbers",
            data: {
                chapterId: e.currentTarget.dataset.chapterid
            },
            header: {
                "content-type": "application/json",
                cookie: "SESSION=" + wx.getStorageSync("3rd_session")
            },
            method: "GET",
            success: function(e) {
                if (0 == e.data.status) {
                    var n = e.data.data;
                    if (n.length > 0) for (var o = 0; o < n.length; o++) n[o].classType = t.getCollectionColor(n[o].questionType), 
                    n[o].questionName = t.getDicNameById(n[o].questionType);
                    a.setData({
                        collectionLists: n
                    });
                } else getApp().chkResponse(e);
            },
            fail: function(t) {
                getApp().requestError();
            }
        });
    },
    goAnswer: function(t) {
        var e = t.currentTarget.dataset.chapterid, a = t.currentTarget.dataset.questiontype, n = t.currentTarget.dataset.chaptername, o = t.currentTarget.dataset.totalnumber;
        wx.navigateTo({
            url: "../singleChoiceDetail/singleChoiceDetail?chapterId=" + e + "&questionType=" + a + "&chaptername=" + n + "&totalnumber=" + o + "&isCollectUrl=1"
        });
    },
    panel: function(t) {
        t.currentTarget.dataset.chapterid != this.data.showIndex ? (this.getCollectionLists(t), 
        this.setData({
            showIndex: t.currentTarget.dataset.chapterid
        })) : this.setData({
            showIndex: ""
        });
    },
    onReady: function() {},
    onShow: function() {},
    onHide: function() {},
    onUnload: function() {},
    onPullDownRefresh: function() {},
    onReachBottom: function() {},
    onShareAppMessage: function() {}
});