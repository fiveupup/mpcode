Page({
    data: {
        height: 0,
        challengeList: []
    },
    onLoad: function(t) {
        var e = this;
        wx.getSystemInfo({
            success: function(t) {
                e.setData({
                    height: t.windowHeight - 80
                });
            }
        });
    },
    onReady: function() {},
    onShow: function() {},
    onHide: function() {},
    onUnload: function() {},
    onPullDownRefresh: function() {},
    onReachBottom: function() {},
    onShareAppMessage: function() {},
    getChallenge: function() {
        var t = this;
        wx.getStorageSync("userinfo");
        wx.request({
            url: getApp().web_config.web_url + "/api/medal/findMyAthleticsMedalList",
            data: {},
            method: "get",
            header: {
                "content-type": "application/json",
                cookie: "SESSION=" + wx.getStorageSync("3rd_session")
            },
            success: function(e) {
                0 == e.data.status ? t.setData({
                    challengeList: e.data.data
                }) : getApp().chkResponse(e);
            }
        });
    }
});