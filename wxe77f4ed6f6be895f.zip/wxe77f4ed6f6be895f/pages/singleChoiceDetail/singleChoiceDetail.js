var t = getApp(), a = require("../../13753E374A60E1DF75135630065B10F4.js");

Page({
    data: {
        jsdata: {
            questionlist: {},
            questionall: {},
            answercard: {},
            answerData: {},
            subid: "",
            recordId: "",
            number: 5,
            startIndex: 0,
            totalnumber: 0,
            round: 1,
            page: 1,
            nowQid: 0,
            chapterId: "",
            questionType: "",
            isCollectUrl: 0,
            notAnswerTotal: 0,
            answerWrongTotal: 0,
            answerRightTotal: 0,
            questionid: "",
            collection_img: "",
            blanksNumber: 0,
            inputlist: [],
            title: ""
        },
        analysisFile: [],
        selectCode: [],
        answer: "",
        analysis: "",
        resultdata: "",
        content: "",
        choices: [],
        nowCode: "",
        myAnswer: "",
        chaptername: "",
        timer: "",
        countDownNum: "2",
        picAddress: getApp().web_config.web_url,
        ifCardShow: !1,
        parms: [],
        ismiddle: 0,
        examType: "",
        middleTimer: ""
    },
    onMyEvent: function(t) {
        this.setData({
            ifCardShow: t.detail.ifCardShow
        });
    },
    showModal: function() {
        var t = wx.createAnimation({
            duration: 200,
            timingFunction: "linear",
            delay: 0
        });
        this.animation = t, t.translateY(300).step(), this.setData({
            animationData: t.export(),
            ifCardShow: !0
        }), setTimeout(function() {
            t.translateY(0).step(), this.setData({
                animationData: t.export()
            });
        }.bind(this), 200);
    },
    hideModal: function() {
        var t = wx.createAnimation({
            duration: 200,
            timingFunction: "linear",
            delay: 0
        });
        this.animation = t, t.translateY(300).step(), this.setData({
            animationData: t.export()
        }), setTimeout(function() {
            t.translateY(0).step(), this.setData({
                animationData: t.export(),
                ifCardShow: !1
            });
        }.bind(this), 200);
    },
    onLoad: function(t) {
        var a = this.data.jsdata;
        a.recordId = t.recordId, a.chapterId = t.chapterId, a.questionType = t.questionType, 
        a.chaptername = t.chaptername, a.totalnumber = t.totalnumber, a.isCollectUrl = t.isCollectUrl ? t.isCollectUrl : 0;
        var e = t.examType ? t.examType : "";
        if (this.setData({
            jsdata: a,
            examType: e,
            parms: t
        }), 4 == a.isCollectUrl ? this.errorReAnswer() : a.recordId ? this.getQuestionLists() : this.getQuestion(), 
        2 == this.data.jsdata.isCollectUrl) {
            var s = this;
            this.setData({
                middleTimer: setInterval(function() {
                    s.middleExit();
                }, 3e5)
            });
        }
    },
    onHide: function() {
        this.onUnload();
    },
    onReady: function() {
        this.popup = this.selectComponent("#popup"), this.minitool = this.selectComponent("#minitool");
    },
    examination: function() {
        var t = this.data.jsdata, a = this.data.jsdata.questionlist.questionTypeSummaries, e = [], s = {};
        this.data.jsdata.answerData;
        if (a.length > 0) for (var i = 0; i < a.length; i++) if (a[i].questions.length > 0) for (var n = 0; n < a[i].questions.length; n++) {
            var o = "";
            if (o = a[i].questions[n].userAnswer ? a[i].questions[n].checkResult ? "ItemRightAnswer" : "ItemErrorAnswer" : "ItemNoAnswer", 
            "001004" == a[i].questions[n].type && a[i].questions[n].userAnswer) if (-1 != a[i].questions[n].userAnswer.search(",")) {
                var r = a[i].questions[n].userAnswer.split(",");
                a[i].questions[n].userAnswer = r;
            } else a[i].questions[n].userAnswer = [ a[i].questions[n].userAnswer ];
            a[i].questions[n].classname = o, e.push(a[i].questions[n]), s[a[i].questions[n].id.toString() + "q"] = a[i].questions[n].userAnswer ? a[i].questions[n].userAnswer : "";
        }
        t.datalists = e, t.answercard = s, t.subid = this.data.jsdata.questionlist.recordId;
        var d = {};
        d.data = e, this.setData({
            countDownNum: Math.ceil(this.data.jsdata.questionlist.remainingTime / 1e3) + 2,
            resultdata: d,
            jsdata: t
        }), e.length > 0 && this.handleCommonData(e[0]), wx.setNavigationBarTitle({
            title: this.data.jsdata.questionlist.name
        }), t.questionlist.remainingTime < 0 ? this.tosubmit() : (this.countDown(), this.getAnasylis(d.data[0].id), 
        3 == t.isCollectUrl ? this.reviewQuestionNum() : this.handleQuestionNum());
    },
    showInfo: function() {
        this.popup;
        this.popup.showPopup();
    },
    showPopup: function(t) {
        var a = this.data.jsdata;
        2 != a.isCollectUrl && 4 != a.isCollectUrl && this.popup.showPopup();
        var e = t.currentTarget.dataset.id;
        a.answercard[a.questionid.toString() + "q"] = e, this.setData({
            jsdata: a,
            nowCode: e,
            myAnswer: e
        }), this.handleQuestionNum();
    },
    multiChoice: function(t) {
        var a = "", e = this.data.jsdata, s = this.data.jsdata.answercard[e.questionid.toString() + "q"];
        s || (s = []);
        var i = t.currentTarget.dataset.id, n = t.currentTarget.dataset.index;
        if (s[n] = s[n] == i ? "" : i, s.length > 0) for (var o = 0; o < s.length; o++) s[o] && (a += s[o] + ",");
        a && (a = a.substring(0, a.length - 1)), this.data.selectCode[n].selected = !this.data.selectCode[n].selected, 
        e.answercard[e.questionid.toString() + "q"] = s, this.setData({
            jsdata: e,
            nowCode: s,
            myAnswer: a,
            selectCode: this.data.selectCode
        }), this.handleQuestionNum();
    },
    getQuestion: function() {
        var a = this, e = "", s = {};
        1 == a.data.jsdata.isCollectUrl ? (e = t.web_config.web_url + "/api/collectionLibrary/listQuestions", 
        s = {
            chapterId: a.data.jsdata.chapterId,
            questionType: a.data.jsdata.questionType,
            number: a.data.jsdata.number,
            startIndex: a.data.jsdata.startIndex + (a.data.jsdata.page - 1) * a.data.jsdata.number
        }) : (e = t.web_config.web_url + "/api/questionPractice/listQuestions", s = {
            chapterId: a.data.jsdata.chapterId,
            questionType: a.data.jsdata.questionType,
            number: a.data.jsdata.number
        }), wx.request({
            url: e,
            data: s,
            header: {
                "content-type": "application/json",
                cookie: "SESSION=" + wx.getStorageSync("3rd_session")
            },
            method: "GET",
            success: function(t) {
                a.handleData(t);
            },
            fail: function(a) {
                t.requestError();
            }
        });
    },
    reviewNextQuestion: function() {
        var t = this.data.jsdata;
        t.nowQid = t.nowQid + 1, t.datalists.length <= t.nowQid ? wx.showToast({
            title: "没有下一题了",
            icon: "none",
            duration: 2e3
        }) : (this.getAnasylis(t.datalists[t.nowQid].id), this.handleCommonData(t.datalists[t.nowQid]), 
        3 == t.isCollectUrl && this.popup.showPopup());
    },
    nextQuestion: function(t) {
        var e = this.data.jsdata;
        if (3 == e.isCollectUrl || 2 == e.isCollectUrl) return this.reviewNextQuestion(), 
        !1;
        if (4 == e.isCollectUrl) return this.errorNextQuestion(), !1;
        this.popup.hidePopup(), e.nowQid = e.nowQid + 1;
        var s = this.data.resultdata.data;
        if (s.length <= e.nowQid) return e.nowQid = 0, e.page = e.page + 1, this.setData({
            jsdata: e
        }), void this.submitBrush();
        if (s[e.nowQid].content = a.htmlDecodeByRegExp(s[e.nowQid].content), s[e.nowQid].analysis = a.htmlDecodeByRegExp(s[e.nowQid].analysis), 
        "001001" == s[e.nowQid].type) {
            s[e.nowQid].choices;
            this.handleChoice(s[e.nowQid]);
        } else if ("001002" == s[e.nowQid].type || "001007" == s[e.nowQid].type) {
            s[e.nowQid].choices;
            this.handleChoice(s[e.nowQid]);
        } else if ("001003" == s[e.nowQid].type) {
            s[e.nowQid].choices;
            this.handleChoice(s[e.nowQid]);
        } else if ("001004" == s[e.nowQid].type) {
            e.inputlist = [], e.blanksNumber = s[e.nowQid].blanksNumber;
            for (var i = 0; i < e.blanksNumber; i++) e.inputlist[i] = "";
        }
        e.inCollection = s[e.nowQid].inCollection, e.questionid = s[e.nowQid].id, e.round = e.round + 1, 
        e.inputlist = e.inputlist, this.setData({
            jsdata: e,
            nowCode: "",
            answer: a.htmlDecodeByRegExp(s[e.nowQid].answer),
            content: a.htmlDecodeByRegExp(s[e.nowQid].content),
            analysis: a.htmlDecodeByRegExp(s[e.nowQid].analysis),
            myAnswer: ""
        }), this.getAnasylis(s[e.nowQid].id);
    },
    getContent: function(t) {
        var a = this.data.jsdata;
        a.answercard[a.questionid + "q"] = t.detail.value, this.setData({
            jsdata: a,
            myAnswer: t.detail.value
        }), this.handleQuestionNum();
    },
    studyResult: function() {
        a.studyResult(this.data.jsdata.chapterId, this.data.jsdata.questionType, this.data.jsdata.chaptername, this.data.jsdata.totalnumber, "singleChoiceDetail", this.data.jsdata.isCollectUrl);
    },
    handleData: function(e) {
        var s = this;
        if (0 == e.data.status) {
            var i = e.data.data, n = s.data.jsdata;
            if (i.length < 1 && 0 == s.data.ismiddle && 0 == s.data.jsdata.isCollectUrl) return void wx.showModal({
                title: "是否重新答题",
                content: "",
                success: function(a) {
                    a.confirm && wx.request({
                        url: getApp().web_config.web_url + "/api/questionPractice/refreshQuestion",
                        data: {
                            chapterId: s.data.jsdata.chapterId,
                            questionType: s.data.jsdata.questionType
                        },
                        header: {
                            "content-type": "application/json",
                            cookie: "SESSION=" + wx.getStorageSync("3rd_session")
                        },
                        method: "GET",
                        success: function(t) {
                            s.getQuestion(), s.data.jsdata.answercard = {}, s.setData({
                                jsdata: s.data.jsdata
                            });
                        },
                        fail: function(a) {
                            t.requestError();
                        }
                    });
                }
            });
            if (i[0].content = a.htmlDecodeByRegExp(i[0].content), i[0].analysis = a.htmlDecodeByRegExp(i[0].analysis), 
            "001001" == s.data.jsdata.questionType) this.handleChoice(i[0]), n.choices = i[0].choices; else if ("001002" == s.data.jsdata.questionType || "001007" == s.data.jsdata.questionType) this.handleChoice(i[0]); else if ("001003" == s.data.jsdata.questionType) this.handleChoice(i[0]); else if ("001004" == s.data.jsdata.questionType) {
                n.inputlist = [], n.blanksNumber = i[0].blanksNumber;
                for (var o = 0; o < n.blanksNumber; o++) n.inputlist[o] = "";
            }
            n.inCollection = i[0].inCollection, n.title = a.getDicNameById(s.data.jsdata.questionType), 
            n.questionid = i[0].id;
            var r = a.htmlDecodeByRegExp(i[0].analysis);
            r = r.replace(/</g, "&lt;"), s.setData({
                jsdata: n,
                resultdata: e.data,
                answer: a.htmlDecodeByRegExp(i[0].answer),
                content: a.htmlDecodeByRegExp(i[0].content),
                analysis: r
            }), wx.setNavigationBarTitle({
                title: s.data.jsdata.chaptername
            }), this.getAnasylis(i[0].id), this.handleQuestionNum();
        } else t.chkResponse(e);
    },
    handleChoice: function(t) {
        var e = t.choices;
        if (t.choices.length > 0) {
            for (var s = 0; s < t.choices.length; s++) t.choices[s].content = a.htmlDecodeByRegExp(t.choices[s].content);
            this.setData({
                selectCode: e,
                choices: t.choices
            });
        }
    },
    _error: function() {
        console.log("你点击了取消"), this.popup.hidePopup();
    },
    _success: function() {
        console.log("你点击了确定"), this.popup.hidePopup();
    },
    selectContent: function() {
        wx.reLaunch({
            url: "/pages/onlineStudy/onlineStudy"
        });
    },
    bindblurac: function(t) {
        var a = this.data.myAnswer;
        this.setData({
            myAnswer: a
        });
    },
    inputbind: function(t) {
        var a = this.data.nowCode;
        a || (a = []);
        var e = t.detail.value;
        a[t.target.dataset.index] = e, a.length > 0 && a.join(",");
        var s = this.data.jsdata;
        s.answercard[s.questionid.toString() + "q"] = a, this.setData({
            jsdata: s,
            nowCode: a,
            myAnswer: a
        }), this.handleQuestionNum();
    },
    handleCommonData: function(t) {
        var e = this.data.jsdata;
        if (t.content = a.htmlDecodeByRegExp(t.content), t.analysis && (t.analysis = a.htmlDecodeByRegExp(t.analysis)), 
        "001001" == t.type) this.handleChoice(t), e.choices = t.choices, e.inCollection = t.inCollection; else if ("001002" == t.type || "001007" == t.type) this.handleChoice(t); else if ("001003" == t.type) this.handleChoice(t); else if ("001004" == t.type) {
            e.blanksNumber = t.blanksNumber, e.inputlist = [];
            for (var s = 0; s < e.blanksNumber; s++) e.inputlist[s] = "";
        }
        e.inCollection = t.inCollection, e.title = a.getDicNameById(t.type), e.questionType = t.type, 
        e.questionid = t.id;
        var i = "";
        i = e.answercard[e.questionid.toString() + "q"] ? e.answercard[e.questionid.toString() + "q"] : t.userAnswer;
        var n = "";
        if (("001002" == t.type || "001004" == t.type || "001007" == t.type) && (n = i instanceof Array ? i : i ? i.split(",") : [], 
        e.answercard[e.questionid.toString() + "q"] = n, n)) {
            for (var o = 0; o < this.data.selectCode.length; o++) for (var r = 0; r < n.length; r++) if (this.data.selectCode[o].selected = !1, 
            this.data.selectCode[o].code == n[r]) {
                this.data.selectCode[o].selected = !0;
                break;
            }
            for (var d = [], c = 0; c < n.length; c++) "" != n[c] && d.push(n[c]);
            i = d.join(",");
        }
        this.setData({
            jsdata: e,
            myAnswer: i,
            nowCode: n,
            selectCode: this.data.selectCode,
            answer: t.answer,
            content: t.content,
            analysis: t.analysis
        }), 4 == e.isCollectUrl ? wx.setNavigationBarTitle({
            title: e.chaptername
        }) : wx.setNavigationBarTitle({
            title: this.data.jsdata.questionlist.name
        });
    },
    tosubmit: function() {
        var a = this, e = a.data.jsdata.answercard, s = [], i = [];
        for (var n in e) s.push(n), i.push(e[n]);
        var o = [], r = (a.data.jsdata.subid, a.data.jsdata.recordId, 0), d = 0, c = "";
        if (e) for (var u = 0; u < s.length; u++) {
            if (c = "", e[s[u]] instanceof Array) {
                if ("001002" == a.data.resultdata.data[u].type || "001007" == a.data.resultdata.data[u].type) {
                    if (e[s[u]]) for (var l = 0; l < e[s[u]].length; l++) e[s[u]][l] && (c += e[s[u]][l] + ",");
                    c && (c = c.substring(0, c.length - 1));
                } else e[s[u]] && (c = e[s[u]].join(","));
                c ? r += 1 : d += 1;
            } else e[s[u]] ? r += 1 : d += 1, c = e[s[u]];
            o[u] = {
                id: s[u].substring(0, s[u].length - 1),
                signed: 0,
                userAnswer: c
            };
        } else o = [];
        if (a.data.jsdata.questionlist.remainingTime < 0) return wx.request({
            url: t.web_config.web_url + "/api/examination/submit",
            data: {
                recordId: a.data.jsdata.subid,
                answerData: JSON.stringify(o)
            },
            header: {
                "content-type": "application/x-www-form-urlencoded",
                cookie: "SESSION=" + wx.getStorageSync("3rd_session")
            },
            method: "POST",
            success: function(t) {
                0 == t.data.status && wx.showModal({
                    title: "考试结束",
                    content: "",
                    cancelText: "查看成绩",
                    success: function(e) {
                        e.confirm ? wx.redirectTo({
                            url: "/pages/answerRecord/answerRecord"
                        }) : e.cancel && wx.redirectTo({
                            url: "/pages/answerFx/answerFx?id=" + t.data.data.recordId + "&examType=" + a.data.examType
                        });
                    }
                }), wx.redirectTo({
                    url: "/pages/answerRecord/answerRecord"
                });
            },
            fail: function(a) {
                t.requestError();
            }
        }), !1;
        !o || d > 0 ? 0 != a.data.countDownNum ? wx.showModal({
            title: "提示",
            content: "共" + s.length + "题,已答" + r + "题,未答" + d + "题, 是否交卷?",
            success: function(e) {
                e.cancel || wx.request({
                    url: t.web_config.web_url + "/api/examination/submit",
                    data: {
                        recordId: a.data.jsdata.subid,
                        answerData: JSON.stringify(o)
                    },
                    header: {
                        "content-type": "application/x-www-form-urlencoded",
                        cookie: "SESSION=" + wx.getStorageSync("3rd_session")
                    },
                    method: "POST",
                    success: function(t) {
                        0 == t.data.status && wx.showModal({
                            title: "考试结束",
                            content: "",
                            cancelText: "查看成绩",
                            success: function(e) {
                                e.confirm ? wx.redirectTo({
                                    url: "/pages/answerRecord/answerRecord"
                                }) : e.cancel && a.getAnswerinfo(t.data.data.recordId);
                            }
                        });
                    },
                    fail: function(a) {
                        t.requestError();
                    }
                });
            }
        }) : wx.request({
            url: t.web_config.web_url + "/api/examination/submit",
            data: {
                recordId: a.data.jsdata.subid,
                answerData: JSON.stringify(o)
            },
            header: {
                "content-type": "application/x-www-form-urlencoded",
                cookie: "SESSION=" + wx.getStorageSync("3rd_session")
            },
            method: "POST",
            success: function(t) {
                0 == t.data.status && wx.showModal({
                    title: "考试结束",
                    content: "",
                    cancelText: "查看成绩",
                    success: function(e) {
                        e.confirm ? wx.redirectTo({
                            url: "/pages/answerRecord/answerRecord"
                        }) : e.cancel && a.getAnswerinfo(t.data.data.recordId);
                    }
                });
            },
            fail: function(a) {
                t.requestError();
            }
        }) : wx.request({
            url: t.web_config.web_url + "/api/examination/submit",
            data: {
                recordId: a.data.jsdata.subid,
                answerData: JSON.stringify(o)
            },
            header: {
                "content-type": "application/x-www-form-urlencoded",
                cookie: "SESSION=" + wx.getStorageSync("3rd_session")
            },
            method: "POST",
            success: function(t) {
                0 == t.data.status && wx.showModal({
                    title: "考试结束",
                    content: "",
                    cancelText: "查看成绩",
                    success: function(e) {
                        e.confirm ? wx.redirectTo({
                            url: "/pages/answerRecord/answerRecord"
                        }) : e.cancel && wx.redirectTo({
                            url: "/pages/answerFx/answerFx?id=" + t.data.data.recordId + "&examType=" + a.data.examType
                        });
                    }
                });
            },
            fail: function(a) {
                t.requestError();
            }
        });
    },
    getQuestionLists: function() {
        var t = this, a = "", e = "GET", s = {}, i = {};
        2 == t.data.jsdata.isCollectUrl ? (a = getApp().web_config.web_url + "/api/examination/enterExamination", 
        e = "GET", s = {
            "content-type": "application/json",
            cookie: "SESSION=" + wx.getStorageSync("3rd_session")
        }, i = {
            id: t.data.jsdata.recordId
        }) : (a = getApp().web_config.web_url + "/api/examination/viewRecord", e = "POST", 
        s = {
            "content-type": "application/x-www-form-urlencoded",
            cookie: "SESSION=" + wx.getStorageSync("3rd_session")
        }, i = {
            recordId: t.data.jsdata.recordId
        }), wx.request({
            url: a,
            data: i,
            header: s,
            method: e,
            success: function(a) {
                if (0 == a.data.status) {
                    var e = t.data.jsdata;
                    e.questionlist = a.data.data, t.setData({
                        jsdata: e
                    }), t.examination();
                } else wx.showToast({
                    title: a.data.message,
                    icon: "none",
                    duration: 2e3
                }), setTimeout(function() {
                    wx.reLaunch({
                        url: "/pages/index/index"
                    });
                }, 2e3);
            },
            fail: function(t) {
                getApp().requestError();
            }
        });
    },
    countDown: function() {
        var t = this, a = t.data.countDownNum;
        t.setData({
            timer: setInterval(function() {
                if (0 == a) return clearInterval(t.data.timer), t.tosubmit(), !1;
                a--;
                var e = Math.floor(a / 86400), s = Math.floor((a - 24 * e * 3600) / 3600), i = Math.floor((a - 24 * e * 3600 - 3600 * s) / 60), n = a - 24 * e * 3600 - 3600 * s - 60 * i;
                t.setData({
                    countDownNum: a,
                    examHour: s + "时" + i + "分" + n + "秒"
                });
            }, 1e3)
        });
    },
    errorReAnswer: function() {
        var a = this, e = a.data.jsdata;
        wx.request({
            url: getApp().web_config.web_url + "/api/misAnsweredQuestion/listQuestions",
            data: {
                recordId: a.data.jsdata.recordId
            },
            header: {
                "content-type": "application/json",
                cookie: "SESSION=" + wx.getStorageSync("3rd_session")
            },
            method: "GET",
            success: function(t) {
                if (0 == t.data.status) {
                    e.questionlist = t.data.data;
                    var s = a.resultdata;
                    s = t.data, a.setData({
                        jsdata: e,
                        resultdata: s
                    }), a.handleCommonData(t.data.data[0]), a.handleQuestionNum();
                } else wx.showModal({
                    title: "",
                    content: t.data.message,
                    success: function(t) {
                        t.confirm && wx.navigateBack({
                            delta: 1
                        });
                    }
                });
            },
            fail: function(a) {
                t.requestError();
            }
        });
    },
    errorNextQuestion: function() {
        var t = this.data.jsdata;
        t.nowQid = t.nowQid + 1, t.questionlist.length <= t.nowQid ? (t.nowQid = 0, this.errorReAnswer()) : this.handleCommonData(t.questionlist[t.nowQid]), 
        this.setData({
            jsdata: t
        });
    },
    submitErrorform: function() {
        var a = this.data.jsdata.answercard, e = "", s = [], i = [];
        for (var n in a) s.push(n), i.push(a[n]);
        var o = [];
        this.data.jsdata.subid, this.data.jsdata.recordId;
        if (a) for (var r = 0; r < s.length; r++) {
            if (e = "", a[s[r]] instanceof Array) if ("001002" == this.data.resultdata.data[r].type || "001007" == this.data.resultdata.data[r].type) {
                if (a[s[r]]) for (var d = 0; d < a[s[r]].length; d++) a[s[r]][d] && (e += a[s[r]][d] + ",");
                e && (e = e.substring(0, e.length - 1));
            } else a[s[r]] && (e = a[s[r]].join(",")); else e = a[s[r]];
            o[r] = {
                id: s[r].substring(0, s[r].length - 1),
                signed: 0,
                userAnswer: e
            };
        } else o = [];
        wx.request({
            url: t.web_config.web_url + "/api/misAnsweredQuestion/saveAnswer",
            data: {
                recordId: this.data.jsdata.recordId,
                answerData: JSON.stringify(o)
            },
            header: {
                "content-type": "application/x-www-form-urlencoded",
                cookie: "SESSION=" + wx.getStorageSync("3rd_session")
            },
            method: "POST",
            success: function(t) {
                0 != t.data.status ? getApp().chkResponse(t) : wx.showToast({
                    title: t.data.httpStatus,
                    icon: "success",
                    duration: 2e3,
                    success: function(t) {
                        wx.navigateBack({
                            delta: 1
                        });
                    }
                });
            },
            fail: function(a) {
                t.requestError();
            }
        });
    },
    submitBrush: function() {
        var a = this, e = a.data.jsdata.answercard, s = [], i = [];
        for (var n in e) s.push(n), i.push(e[n]);
        var o = [], r = (a.data.jsdata.subid, a.data.jsdata.recordId, a.data.resultdata.data);
        console.log(r, "questionList"), console.log(a.data.jsdata.questionid, "that.data.jsdata.questionid");
        for (var d = 0; d < r.length; d++) {
            var c = "", u = r[d].id;
            if (1 == a.data.ismiddle && a.data.jsdata.questionid < u) break;
            if (e.hasOwnProperty(u + "q")) if (e[u + "q"] instanceof Array) if ("001002" == a.data.resultdata.data[d].type || "001007" == a.data.resultdata.data[d].type) {
                if (e[s[d]]) for (var l = 0; l < e[s[d]].length; l++) e[s[d]][l] && (c += e[s[d]][l] + ",");
                c && (c = c.substring(0, c.length - 1));
            } else e[s[d]] && (c = e[s[d]].join(",")); else c = e[u + "q"];
            c && o.push({
                id: u,
                signed: 0,
                userAnswer: c
            });
        }
        wx.request({
            url: t.web_config.web_url + "/api/questionPractice/saveAnswer",
            data: {
                chapterId: a.data.jsdata.chapterId,
                questionType: a.data.jsdata.questionType,
                answerData: JSON.stringify(o)
            },
            header: {
                "content-type": "application/x-www-form-urlencoded",
                cookie: "SESSION=" + wx.getStorageSync("3rd_session")
            },
            method: "POST",
            success: function(t) {
                if (0 != t.data.status) getApp().chkResponse(t); else {
                    var e = a.data.jsdata;
                    e.answercard = {}, a.setData({
                        jsdata: e,
                        myAnswer: ""
                    }), a.getQuestion();
                }
            },
            fail: function(a) {
                t.requestError();
            }
        });
    },
    jumpQuestion: function(t) {
        var a = this.data.jsdata;
        a.nowQid = t.currentTarget.dataset.index, this.setData({
            jsdata: a
        }), this.handleCommonData(a.datalists[a.nowQid]), this.hideModal();
    },
    handleQuestionNum: function() {
        var t = this.data.jsdata, a = 0, e = this.data.jsdata.answercard, s = "", i = [], n = [];
        for (var o in e) i.push(o), n.push(e[o]);
        var r = [];
        this.data.jsdata.subid, this.data.jsdata.recordId;
        if (e) {
            for (var d = 0; d < i.length; d++) {
                if (s = "", e[i[d]] instanceof Array) if ("001002" == this.data.resultdata.data[d].type || "001007" == this.data.resultdata.data[d].type) {
                    if (e[i[d]]) for (var c = 0; c < e[i[d]].length; c++) e[i[d]][c] && (s += e[i[d]][c] + ",");
                    s && (s = s.substring(0, s.length - 1));
                } else e[i[d]] && (s = e[i[d]].join(",")); else s = e[i[d]];
                r[d] = {
                    id: i[d].substring(0, i[d].length - 1),
                    signed: 0,
                    userAnswer: s
                };
            }
            for (var u = 0; u < r.length; u++) r[u].userAnswer || (a += 1);
        }
        t.notAnswerTotal = a, t.answerData = r, this.setData({
            jsdata: t
        });
    },
    reviewQuestionNum: function() {
        var t = this.data.jsdata, a = 0, e = 0, s = this.data.jsdata.datalists, i = [], n = {};
        if (s) for (var o = 0; o < s.length; o++) s[o].userAnswer ? s[o].checkResult || (e += 1) : a += 1, 
        n[s[o].id + "q"] = s[o].userAnswer, i[o] = {
            id: s[o].id,
            userAnswer: s[o].userAnswer
        };
        t.notAnswerTotal = a, t.answerWrongTotal = e, t.answerData = i, t.answercard = n, 
        this.setData({
            jsdata: t
        }), this.popup.showPopup();
    },
    middleExit: function() {
        var a = this.data.jsdata.answercard, e = [], s = [];
        for (var i in a) e.push(i), s.push(a[i]);
        var n = [], o = (this.data.jsdata.subid, "");
        if (a) for (var r = 0; r < e.length; r++) {
            if (o = "", a[e[r]] instanceof Array) if ("001002" == this.data.resultdata.data[r].type || "001007" == this.data.resultdata.data[r].type) {
                if (a[e[r]]) for (var d = 0; d < a[e[r]].length; d++) a[e[r]][d] && (o += a[e[r]][d] + ",");
                o && (o = o.substring(0, o.length - 1));
            } else a[e[r]] && (o = a[e[r]].join(",")); else o = a[e[r]];
            n[r] = {
                id: e[r].substring(0, e[r].length - 1),
                signed: 0,
                userAnswer: o
            };
        } else n = [];
        wx.request({
            url: t.web_config.web_url + "/api/examination/saveAnswer",
            data: {
                recordId: this.data.jsdata.subid,
                answerData: JSON.stringify(n)
            },
            header: {
                "content-type": "application/x-www-form-urlencoded",
                cookie: "SESSION=" + wx.getStorageSync("3rd_session")
            },
            method: "POST",
            success: function(t) {}
        });
    },
    getAnswerinfo: function(t) {
        var a = this;
        wx.request({
            url: getApp().web_config.web_url + "/api/examination/viewRecord",
            data: {
                recordId: t
            },
            header: {
                "content-type": "application/x-www-form-urlencoded",
                cookie: "SESSION=" + wx.getStorageSync("3rd_session")
            },
            method: "POST",
            success: function(t) {
                if (0 != t.data.status) return wx.showToast({
                    title: t.data.message,
                    icon: "none",
                    duration: 2e3,
                    success: function() {
                        var t = setInterval(function() {
                            wx.reLaunch({
                                url: "/pages/index/index"
                            }), clearInterval(t);
                        }, 2e3);
                    }
                }), !1;
                wx.redirectTo({
                    url: "/pages/answerFx/answerFx?id=" + t.data.data.recordId + "&examType=" + a.data.examType
                });
            },
            fail: function(t) {
                getApp().requestError();
            }
        });
    },
    onUnload: function() {
        clearInterval(this.data.timer), 2 == this.data.jsdata.isCollectUrl && (clearInterval(this.data.middleTimer), 
        this.middleExit()), 0 == this.data.jsdata.isCollectUrl && (this.setData({
            ismiddle: 1
        }), this.submitBrush());
    },
    getAnasylis: function(a) {
        var e = this;
        wx.request({
            url: t.web_config.web_url + "/api/questionPractice/findInformationListByQuestionId",
            data: {
                questionId: a
            },
            header: {
                "content-type": "application/x-www-form-urlencoded",
                cookie: "SESSION=" + wx.getStorageSync("3rd_session")
            },
            method: "get",
            success: function(t) {
                0 == t.data.status && e.setData({
                    analysisFile: t.data.data ? t.data.data : []
                });
            },
            fail: function(a) {
                t.requestError();
            }
        });
    }
});