var n = getApp();

Page({
    data: {
        picAddress: getApp().web_config.web_url,
        nvabarData: {
            showCapsule: 1,
            title: "首页"
        },
        height: 2 * n.globalData.height + 20
    },
    onLoad: function(n) {
        wx.hideTabBar();
    },
    myCollection: function() {
        wx.navigateTo({
            url: "../collectionlist/collectionlist"
        });
    },
    answerRecord: function() {
        wx.navigateTo({
            url: "../answerRecord/answerRecord"
        });
    },
    errorbank: function() {
        wx.navigateTo({
            url: "../errorBank/errorBank"
        });
    },
    onReady: function() {},
    onShow: function() {
        wx.hideTabBar();
    },
    onHide: function() {},
    onUnload: function() {},
    onPullDownRefresh: function() {},
    onReachBottom: function() {},
    onShareAppMessage: function() {}
});