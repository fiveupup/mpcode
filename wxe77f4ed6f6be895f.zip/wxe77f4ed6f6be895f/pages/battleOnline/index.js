var t = require("../../9597AF934A60E1DFF3F1C794C59B10F4.js"), e = require("../../13753E374A60E1DF75135630065B10F4.js");

getApp();

Page({
    data: {
        userInfo: [],
        againstId: "",
        opponentId: "",
        showCountDown: !1,
        againstResultName: "",
        getPoint: 0,
        userName: "",
        currentIndex: 0,
        questionList: [],
        choiceList: [],
        myAnswer: "",
        currentTimestamp: new Date().getTime(),
        multipleAnswer: [],
        opponentScore: 0,
        myScore: 0,
        questionTypeName: "",
        questionType: "",
        pkRightName: "",
        totalTime: "",
        remainingTime: "",
        timer: "",
        stompClient: {},
        liList: [ 0, 1, 2, 3, 4, 5, 6, 7, 8, 9 ],
        goNextQuestion: !0
    },
    onLoad: function(t) {
        this.setData({
            againstId: t.againstId,
            opponentId: t.opponentId,
            userInfo: wx.getStorageSync("userinfo")
        }), this.initSocket(), this.startCountDown(), this.getQuestionList();
    },
    onReady: function() {},
    onShow: function() {},
    onHide: function() {},
    onUnload: function() {
        wx.closeSocket(), wx.onSocketClose(function(t) {
            console.log("WebSocket 已关闭！");
        }), this.data.stompClient.disconnect(function() {
            console.log("Stomp 已关闭！");
        }), clearInterval(this.data.timer);
    },
    onPullDownRefresh: function() {},
    onReachBottom: function() {},
    onShareAppMessage: function() {},
    startCountDown: function() {
        var e = this;
        wx.request({
            url: getApp().web_config.web_url + "/api/fight/getOpponentInfo",
            data: {},
            method: "get",
            header: {
                "content-type": "application/x-www-form-urlencoded",
                cookie: "SESSION=" + wx.getStorageSync("3rd_session")
            },
            success: function(a) {
                var n = a.data;
                if (0 == n.status) {
                    if (n.data) {
                        var o = n.data.remainingTime;
                        if (0 == o) e.autoCommit(); else {
                            o = parseInt(o / 1e3);
                            var i = t.s_to_hs(o);
                            e.setData({
                                showCountDown: !0,
                                totalTime: i,
                                remainingTime: o,
                                pkRightName: n.data.candidate.realName,
                                timer: ""
                            }), e.getTotalCountDown(), e.getCurrentScore(e.data.opponentId, "opponent"), e.getCurrentScore(e.data.againstId, "myself");
                        }
                    }
                } else this.$router.push({
                    path: "/battle"
                });
            }
        });
    },
    getCurrentScore: function(t, e) {
        var a = this;
        wx.request({
            url: getApp().web_config.web_url + "/api/fight/getCurrentScore",
            data: {
                againstRecordId: t
            },
            method: "get",
            header: {
                "content-type": "application/x-www-form-urlencoded",
                cookie: "SESSION=" + wx.getStorageSync("3rd_session")
            },
            success: function(t) {
                var n = t.data;
                "opponent" == e ? a.setData({
                    opponentScore: n.data
                }) : "myself" == e && a.setData({
                    myScore: n.data
                });
            }
        });
    },
    autoCommit: function() {
        var e = this;
        wx.request({
            url: getApp().web_config.web_url + "/api/fight/gameOver",
            data: {
                againstId: e.data.againstId
            },
            method: "post",
            header: {
                "content-type": "application/x-www-form-urlencoded",
                cookie: "SESSION=" + wx.getStorageSync("3rd_session")
            },
            success: function(a) {
                var n = a.data;
                if (0 == n.status) {
                    e.data.showCountDown = !1;
                    var o = "";
                    if (!n.data) return;
                    1 == n.data.againstResult ? (o = "恭喜您，获得胜利", e.data.getPoint = 2) : 2 == n.data.againstResult ? (o = "很遗憾，对战失败", 
                    e.data.getPoint = 0) : 0 == e.data.myScore ? (o = "平局", e.data.getPoint = 0) : e.data.getPoint = 1, 
                    e.data.totalTime = t.s_to_hs(n.totalAnswerDuration), e.data.battleResult = !0, e.setData({
                        showCountDown: e.data.showCountDown,
                        againstResultName: e.data.againstResultName,
                        getPoint: e.data.getPoint,
                        battleResult: e.data.battleResult,
                        totalTime: e.data.totalTime
                    }), wx.closeSocket(), wx.onSocketClose(function(t) {
                        console.log("WebSocket 已关闭！");
                    }), e.data.stompClient.disconnect(function() {
                        console.log("Stomp 已关闭！");
                    }), console.log("/pages/battleResult/index?recordId=" + e.data.againstId + "&title=" + o + "&if_win=" + n.data.againstResult + "&score=" + n.data.acquirePoint + "&totalTime=" + t.s_to_hs(n.data.totalAnswerDuration)), 
                    wx.redirectTo({
                        url: "/pages/battleResult/index?recordId=" + e.data.againstId + "&title=" + o + "&if_win=" + n.data.againstResult + "&score=" + n.data.acquirePoint + "&totalTime=" + t.s_to_hs(n.data.totalAnswerDuration)
                    });
                } else {
                    wx.closeSocket(), wx.onSocketClose(function(t) {
                        console.log("WebSocket 已关闭！");
                    }), e.data.stompClient.disconnect(function() {
                        console.log("Stomp 已关闭！");
                    });
                    var i = "/pages/battleOnline/index?opponentId=" + matchData.data.userAgainstRecordsInfo.userId + "&againstId=" + matchData.data.againstId;
                    wx.redirectTo({
                        url: i
                    });
                }
            }
        });
    },
    getQuestionList: function() {
        var t = this;
        wx.request({
            url: getApp().web_config.web_url + "/api/fight/findRandomQuestionList",
            data: {
                platformId: 1,
                number: 10
            },
            method: "get",
            header: {
                "content-type": "application/x-www-form-urlencoded",
                cookie: "SESSION=" + wx.getStorageSync("3rd_session")
            },
            success: function(e) {
                var a = e.data;
                0 == a.status && (t.setData({
                    questionList: a.data,
                    currentIndex: 0
                }), t.initQuestion(0));
            }
        });
    },
    initSocket: function() {
        var t = this, e = !1, a = [];
        var n = {
            send: function(t) {
                e ? wx.sendSocketMessage({
                    data: t
                }) : a.push(t);
            },
            close: function() {
                e && wx.closeSocket();
            }
        };
        function o() {
            wx.connectSocket({
                url: "wss://" + getApp().globalData.websocketUrl + "/ws"
            });
        }
        o(), wx.onSocketOpen(function(t) {
            console.log("WebSocket 连接成功"), e = !0, n.onopen();
            for (var o = a.length, i = 0; i < o; i++) {
                var s = a.shift();
                wx.sendSocketMessage({
                    data: s
                });
            }
        }), wx.onSocketMessage(function(t) {
            n.onmessage(t);
        }), wx.onSocketError(function(t) {
            console.log("WebSocket 错误事件");
        }), wx.onSocketClose(function(t) {
            console.log("WebSocket 连接关闭"), e = !1, o();
        });
        var i = require("../../28F70F364A60E1DF4E916731EC8B10F4.js").Stomp;
        i.setInterval = function(t, e) {
            return setInterval(e, t);
        }, i.clearInterval = function(t) {
            return clearInterval(t);
        };
        var s = i.over(n);
        s.connect({}, function(e) {
            console.log("开始订阅"), s.subscribe("/user/" + t.data.userInfo.userId + "/queue", t.onMessageReceived);
        }), this.setData({
            stompClient: s
        });
    },
    onMessageReceived: function(t) {
        console.log(t, "payload");
        var e = JSON.parse(t.body);
        "DO_GAME" === e.type ? (console.log(e.content, "message.content1111111111111111"), 
        this.setData({
            opponentScore: e.content
        })) : "DO_END" === e.type && this.autoCommit();
    },
    initQuestion: function(a) {
        var n = this.data.questionList[this.data.currentIndex];
        n.questionBasicInfo.content = e.htmlDecodeByRegExp(n.questionBasicInfo.content);
        var o = e.getDicNameById(n.questionBasicInfo.type);
        n.choiceList;
        if (null != n.choiceList && null != n.choiceList) for (var i = 0; i < n.choiceList.length; i++) n.choiceList[i].content = t.html(n.choiceList[i].content);
        this.data.questionList[this.data.currentIndex] = n, this.setData({
            questionList: this.data.questionList,
            questionTypeName: o,
            questionType: n.questionBasicInfo.type,
            myAnswer: ""
        });
    },
    nextQuestion: function() {
        var t = "", e = this, a = new Date().getTime(), n = Math.round((a - e.data.currentTimestamp) / 1e3);
        if ("001002" == e.data.questionType) {
            for (var o = 0, i = 0; i < e.data.multipleAnswer.length; i++) e.data.multipleAnswer[i] && (o++, 
            t += e.data.multipleAnswer[i] + ",");
            if (0 == o) return void wx.showToast({
                title: "请选择答案",
                icon: "none",
                duration: 1500
            });
        } else {
            if ("" == e.data.myAnswer) return void wx.showToast({
                title: "请选择答案",
                icon: "none",
                duration: 1500
            });
            t = e.data.myAnswer;
        }
        e.data.goNextQuestion && (e.setData({
            goNextQuestion: !1
        }), wx.request({
            url: getApp().web_config.web_url + "/api/fight/saveUserAgainstRecordsDetail",
            data: {
                againstRecordId: e.data.againstId,
                questionId: e.data.questionList[e.data.currentIndex].questionBasicInfo.id,
                userAnswer: t,
                answerDuration: n,
                againstWay: 0
            },
            method: "POST",
            header: {
                "content-type": "application/x-www-form-urlencoded",
                cookie: "SESSION=" + wx.getStorageSync("3rd_session")
            },
            success: function(t) {
                var a = t.data.data;
                if (e.setData({
                    myScore: a.score,
                    goNextQuestion: !0
                }), a.answerTimes >= 10) e.autoCommit(); else {
                    var n = e.data.currentIndex + 1;
                    e.setData({
                        currentIndex: n,
                        myAnswer: "",
                        multipleAnswer: []
                    }), e.data.currentIndex >= e.data.questionList.length ? e.getQuestionList() : e.initQuestion(e.data.currentIndex);
                }
            }
        }));
    },
    singleChoice: function(t) {
        var e = t.currentTarget.dataset.code;
        this.setData({
            myAnswer: e
        });
    },
    multipleChoice: function(t) {
        this.data.multipleAnswer[t.currentTarget.dataset.index] = this.data.multipleAnswer[t.currentTarget.dataset.index] ? "" : t.currentTarget.dataset.code, 
        this.setData({
            multipleAnswer: this.data.multipleAnswer
        });
    },
    getTotalCountDown: function() {
        var e = this;
        e.data.timer || e.setData({
            timer: setInterval(function() {
                if (e.data.remainingTime > 0) {
                    e.data.remainingTime--;
                    var a = t.s_to_hs(e.data.remainingTime);
                    e.setData({
                        remainingTime: e.data.remainingTime,
                        totalTime: a
                    });
                } else clearInterval(e.data.timer), e.setData({
                    remainingTime: 0,
                    timer: ""
                }), e.autoCommit();
            }, 1e3)
        });
    }
});