var t = require("../../E06A3E954A60E1DF860C5692828B10F4.js");

Page({
    data: {
        picAddress: "https://static.yun.chinahrt.com/Appfiles",
        oldpassword: "",
        newpassword: "",
        repassword: ""
    },
    onLoad: function(t) {},
    oldpassword: function(t) {
        this.setData({
            oldpassword: t.detail.value
        });
    },
    newpassword: function(t) {
        this.setData({
            newpassword: t.detail.value
        });
    },
    repassword: function(t) {
        this.setData({
            repassword: t.detail.value
        });
    },
    changepw: function() {
        this.data.oldpassword ? this.data.newpassword ? this.data.repassword ? this.data.newpassword == this.data.repassword ? wx.request({
            url: getApp().web_config.web_url + "/api/candidate/updatePwd",
            data: {
                oldPassword: t.hexMD5(this.data.oldpassword),
                newPassword: t.hexMD5(this.data.newpassword)
            },
            method: "post",
            header: {
                "content-type": "application/x-www-form-urlencoded",
                cookie: "SESSION=" + wx.getStorageSync("3rd_session")
            },
            success: function(t) {
                if (0 == t.data.status) return wx.showToast({
                    title: "修改密码成功",
                    icon: "none",
                    duration: 2e3,
                    success: function() {
                        setTimeout(function() {
                            wx.reLaunch({
                                url: "/pages/personSet/personSet"
                            });
                        }, 1e3);
                    }
                }), !1;
                1 == t.data.status ? wx.showToast({
                    title: t.data.message,
                    icon: "none",
                    duration: 2e3
                }) : getApp().chkResponse(t);
            }
        }) : wx.showToast({
            title: "密码不一致",
            icon: "none",
            duration: 1e3
        }) : wx.showToast({
            title: "请输入确认密码",
            icon: "none",
            duration: 1e3
        }) : wx.showToast({
            title: "请输入新密码",
            icon: "none",
            duration: 1e3
        }) : wx.showToast({
            title: "请输入原密码",
            icon: "none",
            duration: 1e3
        });
    },
    onReady: function() {},
    onShow: function() {},
    onHide: function() {},
    onUnload: function() {},
    onPullDownRefresh: function() {},
    onReachBottom: function() {},
    onShareAppMessage: function() {}
});