Page({
    data: {
        provinceList: []
    },
    onLoad: function(t) {
        this.getProvince();
    },
    onReady: function() {},
    onShow: function() {},
    onHide: function() {},
    onUnload: function() {},
    onPullDownRefresh: function() {},
    onReachBottom: function() {},
    goBatch: function(t) {
        wx.redirectTo({
            url: "/pages/battleSearch/index?orgId=" + t.currentTarget.dataset.orgid
        });
    },
    getProvince: function() {
        var t = this;
        wx.request({
            url: getApp().web_config.web_url + "/api/fight/getOnlineNumberList",
            data: {},
            header: {
                "content-type": "application/x-www-form-urlencoded",
                cookie: "SESSION=" + wx.getStorageSync("3rd_session")
            },
            method: "get",
            success: function(e) {
                0 == e.data.status ? t.setData({
                    provinceList: e.data.data
                }) : getApp().chkResponse(e);
            },
            fail: function(t) {
                getApp().requestError();
            }
        });
    }
});