var t = require("../../13753E374A60E1DF75135630065B10F4.js"), e = getApp();

Page({
    data: {
        questionId: 0,
        content: "",
        choiceLists: {},
        typeLists: []
    },
    onLoad: function(e) {
        var n = t.getDicSelect("006");
        this.setData({
            questionId: e.questionId,
            choiceLists: n
        });
    },
    choiceType: function(t) {
        var e = this.data.typeLists, n = t.currentTarget.dataset.id, o = t.currentTarget.dataset.index;
        e[o] == n ? e[o] = "" : e[o] = n, this.setData({
            typeLists: e
        });
    },
    toFeedback: function() {
        var t = this;
        if (!this.data.content) return wx.showToast({
            title: "请详细描述试题错误所在",
            con: "none",
            duration: 2e3
        }), !1;
        if (this.data.content) {
            var n = this.data.typeLists, o = "";
            if (n.length > 0) for (var a = 0; a < n.length; a++) n[a] && (o += 0 == a ? n[a] : "," + n[a]);
            wx.request({
                url: e.web_config.web_url + "/api/studentQuestionCorrection/addCorrection",
                data: {
                    questionId: this.data.questionId,
                    contentType: o || "006006",
                    content: this.data.content
                },
                header: {
                    "content-type": "application/x-www-form-urlencoded",
                    cookie: "SESSION=" + wx.getStorageSync("3rd_session")
                },
                method: "POST",
                success: function(e) {
                    0 == e.data.status ? wx.showToast({
                        title: e.data.message,
                        con: "success",
                        duration: 2e3,
                        success: function() {
                            setTimeout(function() {
                                wx.navigateBack({
                                    delta: 1
                                });
                            }, 1e3);
                        }
                    }) : t.addfail();
                },
                fail: function(e) {
                    t.addfail();
                }
            });
        }
    },
    textBlur: function(t) {
        this.setData({
            content: t.detail.value
        });
    },
    addfail: function() {
        wx.showToast({
            title: "添加纠错失败！",
            con: "success",
            duration: 2e3,
            success: function() {
                setTimeout(function() {
                    wx.navigateBack({
                        delta: 1
                    });
                }, 1e3);
            }
        });
    },
    onReady: function() {},
    onShow: function() {},
    onHide: function() {},
    onUnload: function() {},
    onPullDownRefresh: function() {},
    onReachBottom: function() {},
    onShareAppMessage: function() {}
});