var e, r = require("@babel/runtime/helpers/typeof.js");

e = function(e) {
    return e.pad.Iso97971 = {
        pad: function(r, o) {
            r.concat(e.lib.WordArray.create([ 2147483648 ], 1)), e.pad.ZeroPadding.pad(r, o);
        },
        unpad: function(r) {
            e.pad.ZeroPadding.unpad(r), r.sigBytes--;
        }
    }, e.pad.Iso97971;
}, "object" === ("undefined" == typeof exports ? "undefined" : r(exports)) ? module.exports = exports = e(require("026E56734A60E1DF64083E7464EB10F4.js"), require("D31415734A60E1DFB5727D74A3DB10F4.js")) : "function" == typeof define && define.amd ? define([ "./core", "./cipher-core" ], e) : e((void 0).CryptoJS);