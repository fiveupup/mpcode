var t = function(t) {
    return (t = t.toString())[1] ? t : "0" + t;
};

module.exports = {
    formatTime: function(n) {
        var r = n.getFullYear(), e = n.getMonth() + 1, o = n.getDate(), u = n.getHours(), a = n.getMinutes(), i = n.getSeconds();
        return [ r, e, o ].map(t).join("/") + " " + [ u, a, i ].map(t).join(":");
    },
    s_to_hs: function(t) {
        var n;
        return n = Math.floor(t / 60), t %= 60, (n = 1 == (n += "").length ? "0" + n : n) + "分" + (t = 1 == (t += "").length ? "0" + t : t) + "秒";
    },
    html: function(t) {
        return (t = t ? t.replace(/&amp;/g, function(t) {
            return {
                "&amp;": "&"
            }[t];
        }) : "") ? t.replace(/&(2526gt|2526lt|quot|amp|#39|nbsp);/g, function(t) {
            return {
                "&2526lt;": "<",
                "&amp;": "&",
                "&quot;": '"',
                "&2526gt;": ">",
                "&#39;": "'",
                "&nbsp;": " "
            }[t];
        }) : "";
    },
    isBlackStr: function(t) {
        return !t || "" == $.trim(t);
    },
    contains: function(t, n) {
        for (var r = t.length; r--; ) if (t[r] === n) return !0;
        return !1;
    }
};