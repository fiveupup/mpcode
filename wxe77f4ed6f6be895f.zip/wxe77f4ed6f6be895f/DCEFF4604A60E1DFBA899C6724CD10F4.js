var e, r = require("@babel/runtime/helpers/typeof.js");

e = function(e) {
    return e.pad.ZeroPadding = {
        pad: function(e, r) {
            var i = 4 * r;
            e.clamp(), e.sigBytes += i - (e.sigBytes % i || i);
        },
        unpad: function(e) {
            var r = e.words, i = e.sigBytes - 1;
            for (i = e.sigBytes - 1; i >= 0; i--) if (r[i >>> 2] >>> 24 - i % 4 * 8 & 255) {
                e.sigBytes = i + 1;
                break;
            }
        }
    }, e.pad.ZeroPadding;
}, "object" === ("undefined" == typeof exports ? "undefined" : r(exports)) ? module.exports = exports = e(require("026E56734A60E1DF64083E7464EB10F4.js"), require("D31415734A60E1DFB5727D74A3DB10F4.js")) : "function" == typeof define && define.amd ? define([ "./core", "./cipher-core" ], e) : e((void 0).CryptoJS);