Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.queryParameters = exports.getapi = void 0;

var e = require("@babel/runtime/helpers/objectSpread2.js");

exports.getapi = function(t) {
    var o = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {};
    wx.showLoading({
        title: "loading...",
        mask: !0
    }), "POST" != o.method && "PUT" != o.method || (o.header = {
        "content-type": "application/x-www-form-urlencoded"
    });
    var n = o.header || {
        Accept: "application/json"
    };
    return token && (token = "/user/login" != t ? "?token=".concat(token) : ""), t = baseUrl + t + token, 
    new Promise(function(r, a) {
        wx.request(e(e({
            url: t
        }, o), {}, {
            header: n,
            success: function(e) {
                var t = e.data, o = e.statusCode;
                wx.hideLoading(), r(o < 200 || o >= 300 ? {
                    code: o,
                    msg: t.message,
                    data: null
                } : t);
            },
            fail: a,
            complete: function() {
                wx.hideLoading();
            }
        }));
    });
};

exports.queryParameters = function(e) {
    return Object.keys(e).map(function(t) {
        return [ t, e[t] ].map(encodeURIComponent).join("=");
    }).join("&");
};