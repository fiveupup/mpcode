var e, r = require("@babel/runtime/helpers/typeof.js");

e = function(e) {
    return function() {
        var r = e, t = r.lib.WordArray;
        function a(e, r, a) {
            for (var i = [], n = 0, o = 0; o < r; o++) if (o % 4) {
                var f = a[e.charCodeAt(o - 1)] << o % 4 * 2 | a[e.charCodeAt(o)] >>> 6 - o % 4 * 2;
                i[n >>> 2] |= f << 24 - n % 4 * 8, n++;
            }
            return t.create(i, n);
        }
        r.enc.Base64url = {
            stringify: function(e) {
                var r = !(arguments.length > 1 && void 0 !== arguments[1]) || arguments[1], t = e.words, a = e.sigBytes, i = r ? this._safe_map : this._map;
                e.clamp();
                for (var n = [], o = 0; o < a; o += 3) for (var f = t[o >>> 2] >>> 24 - o % 4 * 8 & 255, s = t[o + 1 >>> 2] >>> 24 - (o + 1) % 4 * 8 & 255, p = t[o + 2 >>> 2] >>> 24 - (o + 2) % 4 * 8 & 255, u = f << 16 | s << 8 | p, c = 0; c < 4 && o + .75 * c < a; c++) n.push(i.charAt(u >>> 6 * (3 - c) & 63));
                var h = i.charAt(64);
                if (h) for (;n.length % 4; ) n.push(h);
                return n.join("");
            },
            parse: function(e) {
                var r = !(arguments.length > 1 && void 0 !== arguments[1]) || arguments[1], t = e.length, i = r ? this._safe_map : this._map, n = this._reverseMap;
                if (!n) {
                    n = this._reverseMap = [];
                    for (var o = 0; o < i.length; o++) n[i.charCodeAt(o)] = o;
                }
                var f = i.charAt(64);
                if (f) {
                    var s = e.indexOf(f);
                    -1 !== s && (t = s);
                }
                return a(e, t, n);
            },
            _map: "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/=",
            _safe_map: "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789-_"
        };
    }(), e.enc.Base64url;
}, "object" === ("undefined" == typeof exports ? "undefined" : r(exports)) ? module.exports = exports = e(require("026E56734A60E1DF64083E7464EB10F4.js")) : "function" == typeof define && define.amd ? define([ "./core" ], e) : e((void 0).CryptoJS);