var e, r = require("@babel/runtime/helpers/typeof.js");

e = function(e) {
    var r;
    return e.mode.ECB = ((r = e.lib.BlockCipherMode.extend()).Encryptor = r.extend({
        processBlock: function(e, r) {
            this._cipher.encryptBlock(e, r);
        }
    }), r.Decryptor = r.extend({
        processBlock: function(e, r) {
            this._cipher.decryptBlock(e, r);
        }
    }), r), e.mode.ECB;
}, "object" === ("undefined" == typeof exports ? "undefined" : r(exports)) ? module.exports = exports = e(require("026E56734A60E1DF64083E7464EB10F4.js"), require("D31415734A60E1DFB5727D74A3DB10F4.js")) : "function" == typeof define && define.amd ? define([ "./core", "./cipher-core" ], e) : e((void 0).CryptoJS);