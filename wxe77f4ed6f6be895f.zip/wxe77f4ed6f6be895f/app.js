var e, t = require("@babel/runtime/helpers/defineProperty"), a = require("E06A3E954A60E1DF860C5692828B10F4.js"), n = require("A29232914A60E1DFC4F45A9652FB10F4.js");

App((t(e = {
    onShow: function() {
        wx.hideTabBar(), this.autoUpdate(), this.chkRandString();
    },
    globalData: {
        share: !1,
        height: 0,
        deviceHeight: 0,
        isIpx: !1,
        socketStatus: "",
        websocketUrl: "",
        client: "",
        ws: {}
    },
    question: {
        every_score: 3,
        total_question_num: 10
    },
    onLaunch: function(e) {
        var t = this;
        this.globalData.websocketUrl = "bw.rsbsyzx.cn", this.globalData.socketStatus = "", 
        this.globalData.client = "", wx.hideTabBar(), 1007 == e.scene || 1008 == e.scene ? this.globalData.share = !0 : this.globalData.share = !1, 
        wx.getSystemInfo({
            success: function(e) {
                t.globalData.height = e.statusBarHeight, t.globalData.deviceHeight = e.windowHeight;
                e.model.indexOf("iPhone X") > -1 && (t.globalData.isIpx = !0);
            },
            fail: function(e) {
                console.log(e);
            }
        }), wx.login({
            success: function(e) {}
        });
    },
    editTabbar: function() {
        var e = this.globalData.tabBar, t = getCurrentPages(), a = t[t.length - 1], n = a.route;
        for (var o in 0 != n.indexOf("/") && (n = "/" + n), e.list) e.list[o].selected = !1, 
        e.list[o].pagePath == n && (e.list[o].selected = !0);
        a.setData({
            tabbar: e
        });
    }
}, "globalData", {
    statusBarHeight: wx.getSystemInfoSync().statusBarHeight,
    header: {
        Cookie: "JSESSION=***"
    },
    appsecret: "ghvnkdj",
    systemInfo: null,
    userInfo: null,
    answerCardShow: !1,
    tabBar: {
        backgroundColor: "#ffffff",
        color: "#979795",
        selectedColor: "#1c1c1b",
        list: [ {
            pagePath: "/pages/index/index",
            iconPath: "/tabbarComponent/icon/icon_home.png",
            selectedIconPath: "/tabbarComponent/icon/icon_home_HL.png",
            text: "练兵"
        }, {
            pagePath: "/pages/suggestions/suggestions",
            iconPath: "/tabbarComponent/icon/tabBarSuggestions.png",
            selectedIconPath: "/tabbarComponent/icon/tabBarSuggestions_on.png",
            text: "建言献策"
        }, {
            pagePath: "/pages/personal/personal",
            iconPath: "/tabbarComponent/icon/tabBarMy.png",
            selectedIconPath: "/tabbarComponent/icon/tabBarMy_on.png",
            text: "我的"
        } ]
    }
}), t(e, "web_config", {
    web_url: "https://bw.rsbsyzx.cn",
    websocketUrl: "bw.rsbsyzx.cn"
}), t(e, "chkLogin", function() {
    var e = wx.getStorageSync("userinfo");
    return e && e.timestamp > Date.parse(new Date()) ? (this.toLogin(e.mobile, e.password, 1), 
    !0) : (wx.setStorageSync("3rd_session", ""), wx.setStorageSync("userinfo", ""), 
    wx.showToast({
        title: "登录信息失效，请重新登录！",
        icon: "none",
        duration: 2e3
    }), setTimeout(function() {
        wx.navigateTo({
            url: "../login/login"
        });
    }, 1e3), !1);
}), t(e, "chkResponse", function(e) {
    if (0 != e.data.status) {
        var t = wx.getStorageSync("userinfo");
        return t && t.timestamp > Date.parse(new Date()) ? void this.toLogin(t.mobile, t.password, 1) : (wx.setStorageSync("3rd_session", ""), 
        wx.setStorageSync("userinfo", ""), wx.showToast({
            title: "登录信息失效，请重新登录！",
            icon: "none",
            duration: 2e3
        }), setTimeout(function() {
            wx.navigateTo({
                url: "../login/login"
            });
        }, 1e3), !1);
    }
    return !(!e.data.status || 600 == e.data.status) || (wx.setStorageSync("3rd_session", ""), 
    wx.setStorageSync("userinfo", ""), wx.showToast({
        title: "登录信息失效，请重新登录！",
        icon: "none",
        duration: 2e3
    }), setTimeout(function() {
        wx.navigateTo({
            url: "../login/login"
        });
    }, 1e3), !1);
}), t(e, "toLogin", function(e, t, a) {
    var n = this;
    wx.request({
        url: this.web_config.web_url + "/api/candidate/beforeLogin",
        data: {},
        method: "GET",
        success: function(o) {
            n.handleLogin(e, t, a, o.data.data);
        },
        fail: function(e) {
            n.requestError();
        }
    });
}), t(e, "handleLogin", function(e, t, o, s) {
    var i = this, r = '{"password":"' + a.hexMD5(t) + '","verifyCode":"0000","mobile":"' + e + '","timestamp":' + s + "}", c = n.enc.Utf8.parse("biwulianbing2022"), g = n.enc.Utf8.parse("biwulianbing2022"), u = n.AES.encrypt(r, c, {
        iv: g,
        mode: n.mode.CBC,
        padding: n.pad.Pkcs7
    });
    wx.request({
        url: this.web_config.web_url + "/api/candidate/loginEncode",
        data: u.ciphertext.toString(n.enc.Base64),
        header: {
            "Content-Type": "application/json;charset=UTF-8"
        },
        method: "POST",
        success: function(e) {
            if (0 == e.data.status) {
                wx.setStorageSync("3rd_session", e.data.data.sessionId);
                var a = e.data.data;
                if (a.password = t, a.timestamp = Date.parse(new Date()) + 1296e6, wx.setStorageSync("userinfo", a), 
                i.getsession(), 0 == o) return void wx.reLaunch({
                    url: "/pages/index/index"
                });
            } else {
                if (1 == o) return void wx.reLaunch({
                    url: "/pages/login/login"
                });
                wx.showToast({
                    title: e.data.message,
                    icon: "none",
                    duration: 2e3
                });
            }
        },
        fail: function(e) {
            this.requestError();
        }
    });
}), t(e, "requestError", function(e) {
    wx.showToast({
        title: "网络错误！",
        icon: "loading",
        duration: 2e3
    });
}), t(e, "getsession", function() {
    wx.request({
        url: this.web_config.web_url + "/api/session/getSession",
        data: {},
        method: "post",
        header: {
            "content-type": "application/json",
            cookie: "SESSION=" + wx.getStorageSync("3rd_session")
        },
        success: function(e) {
            var t = wx.getStorageSync("userinfo");
            t.timestamp = Date.parse(new Date()) + 1296e6, wx.setStorageSync("userinfo", t);
        },
        fail: function(e) {
            this.requestError();
        }
    });
}), t(e, "generateRandomString", function() {
    for (var e = "", t = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789", a = 0; a < 10; a++) e += t.charAt(Math.floor(Math.random() * t.length));
    return e;
}), t(e, "chkRandString", function() {
    if (!wx.getStorageSync("userCard")) {
        var e = this.generateRandomString();
        wx.setStorageSync("userCard", e);
    }
}), t(e, "autoUpdate", function() {
    var e = this;
    if (wx.canIUse("getUpdateManager")) {
        var t = wx.getUpdateManager();
        t.onCheckForUpdate(function(a) {
            a.hasUpdate && wx.showModal({
                title: "更新提示",
                content: "检测到新版本，是否下载新版本并重启小程序？",
                success: function(a) {
                    a.confirm && e.downLoadAndUpdate(t);
                }
            });
        });
    } else wx.showModal({
        title: "提示",
        content: "当前微信版本过低，无法使用该功能，请升级到最新微信版本后重试。"
    });
}), t(e, "downLoadAndUpdate", function(e) {
    wx.showLoading(), e.onUpdateReady(function() {
        wx.hideLoading(), e.applyUpdate();
    }), e.onUpdateFailed(function() {
        wx.showModal({
            title: "已经有新版本了哟~",
            content: "新版本已经上线啦~，请您删除当前小程序，重新搜索打开哟~"
        });
    });
}), e));