var l = new Object();

function e(l) {
    return (l = l ? l.replace(/&amp;/g, function(l) {
        return {
            "&amp;": "&"
        }[l];
    }) : "") ? l.replace(/&(2526gt|2526lt|quot|amp|#39|nbsp);/g, function(l) {
        return {
            "&2526lt;": "<",
            "&amp;": "&",
            "&quot;": '"',
            "&2526gt;": ">",
            "&#39;": "'",
            "&nbsp;": " "
        }[l];
    }) : "";
}

l["001"] = "题型", l["001001"] = "单选", l["001002"] = "多选", l["001003"] = "判断", l["001004"] = "填空", 
l["001005"] = "简答", l["001006"] = "案例", l["001007"] = "不定项选择", l.SELECT_001 = [ {
    value: "001001",
    label: "单选"
}, {
    value: "001002",
    label: "多选"
}, {
    value: "001003",
    label: "判断"
}, {
    value: "001004",
    label: "填空"
}, {
    value: "001005",
    label: "简答"
}, {
    value: "001006",
    label: "案例"
}, {
    value: "001007",
    label: "不定项选择"
} ], l.COLLECTION = [ {
    value: "001001",
    label: ""
}, {
    value: "001002",
    label: "_multip"
}, {
    value: "001003",
    label: "_judge"
}, {
    value: "001004",
    label: "_blank"
}, {
    value: "001005",
    label: "_jd"
}, {
    value: "001006",
    label: "_case"
} ], l.VIEWTYPE = [ {
    value: "001001",
    label: "singleChoiceDetail"
}, {
    value: "001002",
    label: "multiChoiceDetail"
}, {
    value: "001003",
    label: "judgeQuestion"
}, {
    value: "001004",
    label: "completionDetail"
}, {
    value: "001005",
    label: "shortAnswerQuestion"
}, {
    value: "001006",
    label: "shortAnswerQuestion"
} ], l["003"] = "题型难度", l["003001"] = "简单", l["003002"] = "普通", l["003003"] = "困难", 
l.SELECT_003 = [ {
    value: "003001",
    label: "简单"
}, {
    value: "003002",
    label: "普通"
}, {
    value: "003003",
    label: "困难"
} ], l["008"] = "试题标签", l["008001"] = "测试", l["008002"] = "真题", l["008003"] = "模拟题", 
l["008004"] = "闯关题", l.SELECT_008 = [ {
    value: "008001",
    label: "测试"
}, {
    value: "008002",
    label: "真题"
}, {
    value: "008003",
    label: "模拟题"
}, {
    value: "008004",
    label: "闯关题"
} ], l["009"] = "试卷类型", l["009001"] = "历年真题", l["009002"] = "在线答题", l["009003"] = "闯关答题", 
l.SELECT_009 = [ {
    value: "009001",
    label: "历年真题"
}, {
    value: "009002",
    label: "在线答题"
}, {
    value: "009003",
    label: "闯关答题"
} ], l["010"] = "组卷方式", l["010001"] = "选题组卷", l["010002"] = "抽题组卷", l["010003"] = "随机组卷", 
l.SELECT_010 = [ {
    value: "010001",
    label: "选题组卷"
}, {
    value: "010002",
    label: "抽题组卷"
}, {
    value: "010003",
    label: "随机组卷"
} ], l["006"] = "试题纠错", l["006001"] = "含有错别字", l["006002"] = "题目不完整", l["006003"] = "答案不正确", 
l["006004"] = "图片不存在", l["006005"] = "解析不正确", l["006999"] = "其他错误", l.SELECT_006 = [ {
    value: "006001",
    label: "含有错别字"
}, {
    value: "006002",
    label: "题目不完整"
}, {
    value: "006003",
    label: "答案不正确"
}, {
    value: "006004",
    label: "图片不存在"
}, {
    value: "006005",
    label: "解析不正确"
}, {
    value: "006999",
    label: "其他不正确"
} ], l["012"] = "政治面貌", l["012001"] = "群众", l["012002"] = "共青团员", l["012003"] = "预备党员", 
l["012004"] = "中共党员", l["012005"] = "民主党派", l["013"] = "学历", l["013001"] = "无", 
l["013002"] = "中专或相当学历", l["013003"] = "大专或相当学历", l["013005"] = "本科", l["013006"] = "双学士", 
l["013007"] = "硕士", l["013008"] = "博士", l["013009"] = "博士后", l["013010"] = "其他", 
l["013011"] = "研究生（未取得学位）", l["013012"] = "高中", l["014"] = "单位性质", l["014001"] = "国有", 
l["014002"] = "公私合营", l["014003"] = "中外合资", l["014004"] = "外资", l["014005"] = "私营", 
l["014006"] = "集体", l["014007"] = "股份制", l["014008"] = "高新技术企业", l["014009"] = "一类（全额拨款）事业单位", 
l["014010"] = "依照公务员管理的事业单位", l["014011"] = "二类（差额拨款）事业单位", l["014012"] = "三类（自收自支）事业单位", 
l["014013"] = "实行企业化管理的事业单位", l["014014"] = "政府机关", l["014015"] = "党委机关", l["014016"] = "人民团体", 
l["015"] = "民族", l["015001"] = "汉族", l["015002"] = "蒙古族", l["015003"] = "回族", l["015004"] = "藏族", 
l["015005"] = "维吾尔族", l["015006"] = "苗族", l["015007"] = "彝族", l["015008"] = "壮族", 
l["015009"] = "布依族", l["015010"] = "朝鲜族", l["015011"] = "满族", l["015012"] = "侗族", 
l["015013"] = "瑶族", l["015014"] = "白族", l["015015"] = "土家族", l["015016"] = "哈尼族", 
l["015017"] = "哈萨克族", l["015018"] = "傣族", l["015019"] = "黎族", l["015020"] = "傈僳族", 
l["015021"] = "佤族", l["015022"] = "畲族", l["015023"] = "高山族", l["015024"] = "拉祜族", 
l["015025"] = "水族", l["015026"] = "东乡族", l["015028"] = "景颇族", l["015029"] = "柯尔克孜族", 
l["015030"] = "土族", l["015031"] = "达斡尔族", l["015032"] = "仫佬族", l["015033"] = "羌族", 
l["015034"] = "布朗族", l["015035"] = "撒拉族", l["015036"] = "毛难族", l["015037"] = "仡佬族", 
l["015038"] = "锡伯族", l["015039"] = "阿昌族", l["015040"] = "普米族", l["015041"] = "塔吉克族", 
l["015042"] = "怒族", l["015043"] = "乌孜别克族", l["015044"] = "俄罗斯族", l["015045"] = "鄂温克族", 
l["015046"] = "崩龙族", l["015047"] = "保安族", l["015048"] = "裕固族", l["015049"] = "京族", 
l["015050"] = "塔塔尔族", l["015051"] = "独龙族", l["015052"] = "鄂伦春族", l["015053"] = "赫哲族", 
l["015054"] = "门巴族", l["015055"] = "珞巴族", l["015056"] = "基诺族", l["015057"] = "穿青人", 
l["015058"] = "亻革家人", l["015059"] = "纳西族", l.SELECT_012 = [ {
    value: "012001",
    label: "群众"
}, {
    value: "012002",
    label: "共青团员"
}, {
    value: "012003",
    label: "预备党员"
}, {
    value: "012004",
    label: "中共党员"
}, {
    value: "012005",
    label: "民主党派"
} ], l.SELECT_013 = [ {
    value: "013009",
    label: "博士后"
}, {
    value: "013010",
    label: "其他"
}, {
    value: "013011",
    label: "研究生（未取得学位）"
}, {
    value: "013012",
    label: "高中"
}, {
    value: "013008",
    label: "博士"
}, {
    value: "013007",
    label: "硕士"
}, {
    value: "013006",
    label: "双学士"
}, {
    value: "013005",
    label: "本科"
}, {
    value: "013003",
    label: "大专或相当学历"
}, {
    value: "013002",
    label: "中专或相当学历"
}, {
    value: "013001",
    label: "无"
} ], l.SELECT_014 = [ {
    value: "014010",
    label: "依照公务员管理的事业单位"
}, {
    value: "014011",
    label: "二类（差额拨款）事业单位"
}, {
    value: "014012",
    label: "三类（自收自支）事业单位"
}, {
    value: "014013",
    label: "实行企业化管理的事业单位"
}, {
    value: "014014",
    label: "政府机关"
}, {
    value: "014015",
    label: "党委机关"
}, {
    value: "014016",
    label: "人民团体"
}, {
    value: "014009",
    label: "一类（全额拨款）事业单位"
}, {
    value: "014008",
    label: "高新技术企业"
}, {
    value: "014001",
    label: "国有"
}, {
    value: "014002",
    label: "公私合营"
}, {
    value: "014003",
    label: "中外合资"
}, {
    value: "014004",
    label: "外资"
}, {
    value: "014005",
    label: "私营"
}, {
    value: "014006",
    label: "集体"
}, {
    value: "014007",
    label: "股份制"
} ], l.SELECT_015 = [ {
    value: "015044",
    label: "俄罗斯族"
}, {
    value: "015043",
    label: "乌孜别克族"
}, {
    value: "015042",
    label: "怒族"
}, {
    value: "015041",
    label: "塔吉克族"
}, {
    value: "015040",
    label: "普米族"
}, {
    value: "015039",
    label: "阿昌族"
}, {
    value: "015038",
    label: "锡伯族"
}, {
    value: "015037",
    label: "仡佬族"
}, {
    value: "015036",
    label: "毛难族"
}, {
    value: "015035",
    label: "撒拉族"
}, {
    value: "015034",
    label: "布朗族"
}, {
    value: "015033",
    label: "羌族"
}, {
    value: "015032",
    label: "仫佬族"
}, {
    value: "015045",
    label: "鄂温克族"
}, {
    value: "015046",
    label: "崩龙族"
}, {
    value: "015059",
    label: "纳西族"
}, {
    value: "015058",
    label: "亻革家人"
}, {
    value: "015057",
    label: "穿青人"
}, {
    value: "015056",
    label: "基诺族"
}, {
    value: "015055",
    label: "珞巴族"
}, {
    value: "015054",
    label: "门巴族"
}, {
    value: "015053",
    label: "赫哲族"
}, {
    value: "015052",
    label: "鄂伦春族"
}, {
    value: "015051",
    label: "独龙族"
}, {
    value: "015050",
    label: "塔塔尔族"
}, {
    value: "015049",
    label: "京族"
}, {
    value: "015048",
    label: "裕固族"
}, {
    value: "015047",
    label: "保安族"
}, {
    value: "015031",
    label: "达斡尔族"
}, {
    value: "015030",
    label: "土族"
}, {
    value: "015013",
    label: "瑶族"
}, {
    value: "015012",
    label: "侗族"
}, {
    value: "015011",
    label: "满族"
}, {
    value: "015010",
    label: "朝鲜族"
}, {
    value: "015009",
    label: "布依族"
}, {
    value: "015008",
    label: "壮族"
}, {
    value: "015007",
    label: "彝族"
}, {
    value: "015006",
    label: "苗族"
}, {
    value: "015005",
    label: "维吾尔族"
}, {
    value: "015004",
    label: "藏族"
}, {
    value: "015003",
    label: "回族"
}, {
    value: "015002",
    label: "蒙古族"
}, {
    value: "015014",
    label: "白族"
}, {
    value: "015015",
    label: "土家族"
}, {
    value: "015016",
    label: "哈尼族"
}, {
    value: "015029",
    label: "柯尔克孜族"
}, {
    value: "015028",
    label: "景颇族"
}, {
    value: "015026",
    label: "东乡族"
}, {
    value: "015025",
    label: "水族"
}, {
    value: "015024",
    label: "拉祜族"
}, {
    value: "015023",
    label: "高山族"
}, {
    value: "015022",
    label: "畲族"
}, {
    value: "015021",
    label: "佤族"
}, {
    value: "015020",
    label: "傈僳族"
}, {
    value: "015019",
    label: "黎族"
}, {
    value: "015018",
    label: "傣族"
}, {
    value: "015017",
    label: "哈萨克族"
}, {
    value: "015001",
    label: "汉族"
} ], l["022"] = "用户类型", l["022001"] = "人社部门", l["022002"] = "社会公众", l.SELECT_022 = [ {
    value: "022001",
    label: "人社部门"
}, {
    value: "022002",
    label: "社会公众"
} ], module.exports = {
    addCollection: function(l) {
        var e = getApp();
        wx.request({
            url: e.web_config.web_url + "/api/collectionLibrary/addCollection",
            data: {
                questionId: l
            },
            header: {
                "content-type": "application/x-www-form-urlencoded",
                cookie: "SESSION=" + wx.getStorageSync("3rd_session")
            },
            method: "POST",
            success: function(l) {
                l.data.status;
            },
            fail: function(l) {}
        });
    },
    toHtml: e,
    htmlEncodeByRegExp: function(l) {
        return 0 == l.length ? "" : l.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/\s/g, "&nbsp;").replace(/\'/g, "&#39;").replace(/\"/g, "&quot;");
    },
    htmlDecodeByRegExp: function(l) {
        return 0 == l.length ? "" : e(l.replace(/&amp;/g, "&").replace(/&2526lt;/g, "<").replace(/&2526gt;/g, ">").replace(/&nbsp;/g, " ").replace(/&#39;/g, "'").replace(/&quot;/g, '"').replace(/\/>/g, "></img>").replace(/&quot;/g, '"'));
    },
    removeCollection: function(l) {
        var e = getApp();
        wx.request({
            url: e.web_config.web_url + "/api/collectionLibrary/removeCollection",
            data: {
                questionId: l
            },
            header: {
                "content-type": "application/x-www-form-urlencoded",
                cookie: "SESSION=" + wx.getStorageSync("3rd_session")
            },
            method: "POST",
            success: function(l) {
                l.data.status;
            },
            fail: function(l) {}
        });
    },
    getDicNameById: function(e) {
        return l[e];
    },
    getDicSelect: function(e) {
        return e ? l[e = "SELECT_" + e] : null;
    },
    isEmail: function(l) {
        return !!/^([a-z0-9A-Z]+[-|\\.]?)+[a-z0-9A-Z]@([a-z0-9A-Z]+(-[a-z0-9A-Z]+)?\.)+[a-zA-Z]{2,}$/.test(l);
    },
    studyResult: function(l, e, a, u, t, b) {
        wx.redirectTo({
            url: "../studyResult/studyResult?chapterId=" + l + "&questionType=" + e + "&chaptername=" + a + "&totalnumber=" + u + "&viewtype=singleChoiceDetail&viewtype=" + b
        });
    },
    getCollectionColor: function(e) {
        var a = l.COLLECTION;
        if (e && a) for (var u = 0; u < a.length; u++) if (a[u].value == e) return a[u].label;
        return null;
    },
    getViewtype: function(e) {
        var a = l.VIEWTYPE;
        if (e && a) for (var u = 0; u < a.length; u++) if (a[u].value == e) return a[u].label;
        return null;
    },
    formatContent: function(l) {
        return l = (l = (l = (l = (l = (l = (l = (l = (l = (l = (l = (l = l.replace(/<table[^<>]*>/gi, "<table>")).replace(/<thead[^<>]*>/gi, "<thead>")).replace(/<tbody[^<>]*>/gi, "<tbody>")).replace(/<tfoot[^<>]*>/gi, "<tfoot>")).replace(/<tr[^<>]*>/gi, "<tr>")).replace(/<th [^<>]*>/gi, "<th>")).replace(/<td[^<>]*>/gi, "<td >")).replace(/<th>\s*?<p>/gi, "<th>")).replace(/<\/p>\s*?<\/th>/gi, "</th>")).replace(/<td[^<>]*>\s*?<p>/gi, "<td>")).replace(/<td>\s*?<p>/gi, "<td>")).replace(/<\/p>\s*?<\/td>/gi, "</td>");
    }
};