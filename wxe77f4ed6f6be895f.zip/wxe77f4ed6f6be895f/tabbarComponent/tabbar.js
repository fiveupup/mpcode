getApp();

Component({
    properties: {
        tabbar: {
            type: Object,
            value: {
                backgroundColor: "#ffffff",
                color: "#979795",
                selectedColor: "#1c1c1b",
                list: [ {
                    pagePath: "/pages/index/index",
                    iconPath: "icon/icon_home.png",
                    selectedIconPath: "icon/icon_home_HL.png",
                    text: "学习"
                }, {
                    pagePath: "/pages/rankingList/rankingList",
                    iconPath: "icon/tabBarRanking.png",
                    selectedIconPath: "icon/tabBarRanking_on.png",
                    text: "排行榜"
                }, {
                    pagePath: "/pages/collectBook/collectBook",
                    iconPath: "icon/tabBarCollect.png",
                    selectedIconPath: "icon/tabBarCollect_on.png",
                    text: "藏经阁"
                }, {
                    pagePath: "/pages/suggestions/suggestions",
                    iconPath: "icon/tabBarSuggestions.png",
                    selectedIconPath: "icon/tabBarSuggestions_on.png",
                    text: "建言献策"
                }, {
                    pagePath: "/pages/personal/personal",
                    iconPath: "icon/tabBarMy.png",
                    selectedIconPath: "icon/tabBarMy_on.png",
                    text: "我的"
                } ]
            }
        }
    },
    data: {},
    methods: {}
});