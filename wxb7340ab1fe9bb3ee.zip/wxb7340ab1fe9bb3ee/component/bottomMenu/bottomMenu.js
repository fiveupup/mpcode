getApp(), require("../../utils/util");

Component({
    properties: {
        state: {
            type: Boolean,
            observer: function(t) {
                this.setData({
                    state: t
                });
            }
        },
        data: {
            type: Object,
            observer: function(t) {
                this.setData({
                    data: t
                });
            }
        }
    },
    data: {
        state: !1,
        data: ""
    },
    ready: function() {},
    methods: {
        closeBottomMenu: function() {
            this.triggerEvent("closeBottomMenu", {});
        },
        choose: function(t) {
            var e = t.currentTarget.dataset;
            this.triggerEvent("closeBottomMenu", {
                index: e.index,
                id: e.id
            });
        }
    }
});