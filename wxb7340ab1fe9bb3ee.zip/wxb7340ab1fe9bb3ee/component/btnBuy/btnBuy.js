getApp(), require("../../utils/util");

var e = require("../../pages/template/template");

Component({
    properties: {
        mode: {
            type: Number
        },
        bmode: {
            type: Number
        },
        groupid: {
            type: String
        },
        realNum: {
            type: Number
        },
        systemText: {
            type: String
        },
        isIOS: {
            type: Boolean
        },
        groupType: {
            type: String
        },
        mino: {
            type: String,
            observer: function(e) {
                console.log(999, "mino", e);
            }
        },
        minn: {
            type: String,
            observer: function(e) {
                console.log(999, "minn", e);
            }
        },
        categoryInfo: {
            type: Object
        },
        training: {
            type: Boolean
        }
    },
    data: {
        mode: -1,
        bmode: -1,
        groupid: 0,
        realNum: 0,
        systemText: "",
        isIOS: !1,
        groupType: 0,
        mino: 0,
        minn: 0,
        categoryInfo: {},
        webIdInfo: {}
    },
    ready: function() {
        this.data.webIdInfo = wx.getStorageSync("webIdInfo");
    },
    methods: {
        navigateToMiniProgramPro: function() {
            e.navigateToMiniProgramPro(3, this.data.categoryInfo.gid, this.data.categoryInfo.gname, this.data.webIdInfo.web_id);
        },
        goTrainingSuccess: function() {
            this.triggerEvent("goTrainingSuccess");
        },
        goBuyPage: function(e) {
            var t = e.currentTarget.dataset;
            this.triggerEvent("goBuyPage", {
                free: t.free,
                realnum: t.realnum
            });
        },
        goBuyList: function(e) {
            var t = e.currentTarget.dataset;
            this.triggerEvent("goBuyList", {
                free: t.free,
                realnum: t.realnum
            });
        },
        goFree: function(e) {
            var t = e.currentTarget.dataset;
            this.triggerEvent("goFree", {
                free: t.free,
                realnum: t.realnum
            });
        }
    }
});