getApp(), require("../../utils/util");

var e = require("../../configs/baseConfig"), t = require("../../utils/request").request;

Component({
    properties: {
        params: {
            type: Object,
            observer: function(e, t) {
                console.log(999, "params", e, t), (e.gid && e.resourceIds || e.liveId) && this.getInfo(e), 
                e.terminalPage && (this.data.terminalPage = e.terminalPage);
            }
        },
        styleStr: {
            type: String
        },
        styleType: {
            type: String
        }
    },
    data: {
        isShow: !1,
        title: "",
        info: {},
        showEntry: !1,
        terminalPage: "",
        requestData: {},
        entranceDescription: ""
    },
    ready: function() {},
    methods: {
        handle: function(e) {
            var t = this;
            22 != this.data.terminalPage ? this.getCode(function() {
                t.showEvent();
            }) : this.showEvent();
        },
        showEvent: function() {
            var e = this.data.info;
            if (1 == e.isLiveCode || !e.wechatFrom && 2 == e.wechatType || !e.wechatFrom && 3 == e.wechatType) this.setData({
                isShow: !0
            }); else {
                wx.setStorageSync("wxQrcodeInfo", e);
                var t = "/pages/addCode/addCode?storage=1&terminalPage=".concat(this.data.terminalPage);
                console.log(999, "path", t), wx.navigateTo({
                    url: t
                });
            }
        },
        getInfo: function(a) {
            var r, s = this;
            if (r = {
                passport: wx.getStorageSync("hq_token") || "",
                resource: a.resource,
                resourceIds: a.resourceIds,
                ruleType: a.ruleType,
                terminalPage: a.terminalPage,
                terminalType: 4,
                secondCategory: a.gid || 0
            }, console.log(999, "requestData", r), this.data.requestData = r, 20 == r.terminalPage && (this.data.requestData.buyOrderId = a.buyorderId), 
            22 == r.terminalPage) return this.data.requestData.buyOrderId = a.buyorderId, void this.getCode();
            t({
                url: "".concat(e.hostJAPI, "/crm/showQrEntrance"),
                data: r,
                success: function(e) {
                    if (0 == e.data.status.code) {
                        var t = e.data.data;
                        !t || 1 != t.showFlag && 2 != t.showFlag || s.setData({
                            entranceDescription: t.microMarketingWechat.entranceDescription,
                            showEntry: !0
                        });
                    }
                }
            });
        },
        getCode: function(a) {
            var r = this, s = this.data.requestData;
            t({
                url: "".concat(e.hostJAPI, "/crm/getWechatQr"),
                data: s,
                success: function(e) {
                    if (0 == e.data.status.code) {
                        var t = e.data.data;
                        if (22 == r.data.terminalPage) return void (e.data.success && r.setData({
                            entranceDescription: t.title,
                            showEntry: !0,
                            info: t
                        }));
                        t.terminalPage = s.terminalPage, r.data.info = t, r.setData({
                            info: t
                        }), "function" == typeof a && a();
                    }
                }
            });
        }
    }
});