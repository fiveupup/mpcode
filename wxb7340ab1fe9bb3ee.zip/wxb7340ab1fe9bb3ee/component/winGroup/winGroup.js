getApp();

var t = require("../../utils/util");

Component({
    properties: {
        state: {
            type: Boolean,
            observer: function(t) {
                this.setData({
                    state: t
                });
            }
        },
        type: {
            type: String,
            observer: function(t) {}
        },
        data: {
            type: Object,
            observer: function(t) {
                console.log(999, 111, t), t.gid && (this.data.gid = t.gid), this.initData(t);
            }
        },
        joinGroupData: {
            type: Object,
            observer: function(t) {}
        }
    },
    data: {
        state: !1,
        type: 0,
        data: "",
        goodId: "",
        joinGroupData: "",
        goodIndex: -1,
        gid: 0
    },
    ready: function() {
        this.initData();
    },
    methods: {
        initData: function() {
            var t = this.data.data;
            1 == this.data.type && (t.course.goods.length > 0 && t.course.goods.forEach(function(t, o) {
                t.pintuan_price = Math.round(t.pintuan_price);
            }), this.setData({
                data: t
            }));
        },
        closeWinGroup: function() {
            var t = this.data.data, o = this.data.type;
            1 == o && (t.course.goods.length > 0 && t.course.goods.forEach(function(t, o) {
                t.class = "";
            }), this.setData({
                data: t,
                goodId: "",
                goodIndex: -1
            })), this.triggerEvent("closeWinGroup", {
                type: o
            });
        },
        choose: function(t) {
            var o = this, a = t.currentTarget.dataset, d = this.data.data;
            1 != a.status && (this.data.goodId = a.goodid, d.course.goods.length > 0 && d.course.goods.forEach(function(t, d) {
                t.good_id == a.goodid ? (o.data.goodIndex = d, t.class = "on") : t.class = "";
            }), this.setData({
                data: d,
                goodId: this.data.goodId,
                goodIndex: this.data.goodIndex
            }));
        },
        goCheckout: function() {
            var o = this.data.data, a = this.data.joinGroupData, d = "/pages/orderDetail/orderDetail?groupId=".concat(a.groupId, "&goodsId=").concat(this.data.goodId, "&gid=").concat(this.data.gid);
            if (0 == this.data.type && (d += "&pintuanId=".concat(o.pintuan.id)), this.data.goodId) if (1 != a.pintuanStatus) {
                for (var i in console.log(9999, "joinGroupData", a), a) "type" != i && (d = "".concat(d, "&").concat(i, "=").concat(a[i]));
                console.log(999, "path", d), this.closeWinGroup(), wx.navigateTo({
                    url: d
                });
            } else t.showToast2("你已参过团"); else t.showToast2("请选择一个课程");
        }
    }
});