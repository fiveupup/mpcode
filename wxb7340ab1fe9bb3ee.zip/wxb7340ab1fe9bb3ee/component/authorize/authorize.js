Component({
    options: {
        multipleSlots: !0
    },
    properties: {
        title: {
            type: String,
            value: "提示"
        },
        content: {
            type: String,
            value: "必须授权小程序才能操作，请点击“确定”允许小程序进入授权。"
        }
    },
    data: {
        isShow: !1
    },
    ready: function() {
        var t = this;
        wx.getSetting({
            success: function(e) {
                console.log(999, "getSetting", e), e.authSetting["scope.userInfo"] ? t.setData({
                    isShow: !1
                }) : t.setData({
                    isShow: !0
                });
            }
        });
    },
    methods: {
        bindGetUserInfo: function(t) {
            "getUserInfo:ok" == t.detail.errMsg && (this.setData({
                isShow: !1
            }), this.triggerEvent("userinfoevent"));
        },
        hideAuthorize: function() {
            this.setData({
                isShow: !1
            });
        }
    }
});