getApp(), require("../../utils/util");

Component({
    properties: {
        barType: {
            type: Number,
            observer: function(t) {
                var e = this;
                this.setData({
                    barType: t
                }, function() {
                    2 == t && e.setData({
                        barStyle1: "height:0"
                    });
                });
            }
        },
        title: {
            type: String,
            observer: function(t) {
                t && this.setData({
                    barTitle: t
                });
            }
        }
    },
    data: {
        barStyle: "",
        barStyle1: "",
        leftStyle: "",
        barType: 0,
        showHome: 0,
        showBack: 0,
        barTitle: "",
        windowWidth: 0,
        windowHeight: 0
    },
    ready: function() {
        var t = this;
        wx.getStorageSync("windowStyle") ? (this.data.windowWidth = wx.getStorageSync("windowStyle").width, 
        this.data.windowHeight = wx.getStorageSync("windowStyle").height, this.setBarStyle()) : wx.getSystemInfo({
            success: function(e) {
                t.data.windowWidth = e.windowWidth, t.data.windowHeight = e.windowHeight, t.setBarStyle();
            }
        });
    },
    methods: {
        setBarStyle: function() {
            var t = this, e = this, i = null, a = 0, n = 10;
            320 == this.data.windowWidth && 568 == this.data.windowHeight && (n = 560), setTimeout(function() {
                i = wx.getMenuButtonBoundingClientRect(), a = i.top, console.log(999, "menu", i), 
                e.setData({
                    barStyle: "padding-top:" + a + "px; height:" + (i.height + 18) + "px; line-height:" + (i.height + 18) + "px",
                    leftStyle: "height:" + (i.height - 2) + "px; line-height:" + (i.height - 2) + "px; top:" + a + "px;"
                }), wx.setStorageSync("barStyle", {
                    pt: a,
                    height: 50,
                    bottom: i.bottom
                }), wx.setStorageSync("windowStyle", {
                    width: t.data.windowWidth,
                    height: t.data.windowHeight
                });
            }, n);
        },
        goBack: function() {
            this.data.showHome ? wx.navigateTo({
                url: "/pages/index/index"
            }) : wx.navigateBack({
                delta: 1,
                fail: function() {
                    wx.navigateTo({
                        url: "/pages/index/index"
                    });
                }
            });
        },
        goHome: function() {
            wx.reLaunch({
                url: "/pages/index/index"
            });
        }
    }
});