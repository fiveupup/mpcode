getApp(), require("../../utils/util");

Component({
    properties: {
        type: {
            type: Number,
            observer: function(t) {
                this.setData({
                    type: t
                });
            }
        },
        data: {
            type: Array,
            observer: function(t) {
                this.setData({
                    data: t
                });
            }
        }
    },
    data: {
        type: "",
        data: null
    },
    ready: function() {},
    methods: {
        selected: function(t) {
            var e = this, a = t.currentTarget.dataset, s = this.data.data;
            1 != this.data.type && (s.forEach(function(t, s) {
                var o = "", d = "", r = "";
                t.goodsId == a.goodsid && t.groupId == a.groupid ? (a.state ? (o = 0, d = 0, r = "") : (o = a.goodsid, 
                d = a.groupid, r = a.name), e.triggerEvent("chooseCourseEvent", {
                    goodsId: o,
                    groupId: d,
                    name: r
                }), t.selected = !a.state) : t.selected = 0;
            }), this.setData({
                data: s
            }));
        }
    }
});