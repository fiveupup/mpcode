getApp(), require("../../utils/util"), require("../../configs/baseConfig"), require("../../utils/request");

Component({
    properties: {
        winState: {
            type: Boolean,
            observer: function(t) {
                this.setData({
                    gid: t
                });
            }
        },
        title: {
            type: String,
            observer: function(t) {
                this.setData({
                    title: t
                });
            }
        },
        content: {
            type: String,
            observer: function(t) {
                this.setData({
                    content: t
                });
            }
        }
    },
    data: {
        winState: !1,
        title: "",
        content: ""
    },
    ready: function() {},
    methods: {
        closeModalGift: function() {
            this.setData({
                winState: !1
            });
        }
    }
});