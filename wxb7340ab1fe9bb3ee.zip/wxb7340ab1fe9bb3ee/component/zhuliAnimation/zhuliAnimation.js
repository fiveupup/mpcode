var t = getApp(), i = require("../../configs/baseConfig"), e = require("../../configs/config_" + i.appName), a = require("../../utils/util");

Component({
    properties: {
        top: {
            type: Number,
            observer: function(t) {
                this.setData({
                    top: t
                });
            }
        },
        left: {
            type: Number,
            observer: function(t) {
                this.setData({
                    left: t
                });
            }
        },
        zgId: {
            type: Number,
            observer: function(t) {
                this.setData({
                    zg_id: t
                });
            }
        }
    },
    data: {
        top: 0,
        left: 0,
        zg_id: 0,
        zhuliData: ""
    },
    ready: function() {
        this.getListFinishZuliUser();
    },
    methods: {
        getListFinishZuliUser: function() {
            var r = this;
            wx.showLoading(), wx.request({
                url: i.host + "/wxapp/activity/zuli/listFinishZuliUser",
                data: {
                    _appid: e.appid,
                    _os: a.checkOS(),
                    _v: e.version,
                    org_id: i.orgId,
                    _t: a.timeStamp(),
                    zg_id: this.data.zg_id
                },
                success: function(i) {
                    if (0 == i.data.status.code) {
                        var e = i.data.data;
                        e.forEach(function(i, e) {
                            i.hqName = "学员_" + i.hq_uid.replace(i.hq_uid.substring(3, 7), "****"), 2 == i.gender && (i.imgUrl = "/images/avatar/" + t.random(7, 12) + ".png"), 
                            1 == i.gender && (i.imgUrl = "/images/avatar/" + t.random(1, 6) + ".png"), i.gender || (i.imgUrl = "/images/avatar/" + t.random(1, 12) + ".png");
                        }), r.setData({
                            zhuliData: e
                        });
                    }
                    a.hideLoading();
                }
            });
        }
    }
});