getApp(), require("../../utils/util");

Component({
    properties: {
        cardData: {
            type: Array,
            observer: function(t) {
                console.log(999, "n", t);
            }
        },
        groupId: {
            type: String
        }
    },
    data: {
        cardData: ""
    },
    ready: function() {},
    methods: {
        goGroupDetail: function(t) {
            var r = t.currentTarget.dataset;
            this.triggerEvent("goGroupDetail", {
                groupId: r.groupid
            });
        },
        showWinGroup: function(t) {
            var r = t.currentTarget.dataset;
            this.triggerEvent("showWinGroup", {
                type: r.type,
                activityId: r.activityId,
                pintuanStatus: r.pintuanStatus,
                groupId: r.groupId
            });
        }
    }
});