var t = getApp(), e = require("../../utils/util"), a = require("../../configs/baseConfig"), n = (require("../../configs/config_" + a.appName), 
require("../../utils/cache"));

Component({
    properties: {
        position: {
            type: Number,
            observer: function(t) {
                this.data.position = t;
            }
        },
        grayLevel: {
            type: Boolean
        },
        cid: {
            type: Number,
            observer: function(t) {
                this.data.cid = t;
            }
        },
        styleType: {
            type: Number,
            observer: function(t) {
                this.setData({
                    styleType: t
                });
            }
        },
        showDots: {
            type: Number,
            observer: function(t) {
                this.setData({
                    showDots: t
                });
            }
        }
    },
    data: {
        bannerData: "",
        grayLevel: !1,
        position: "",
        cid: "",
        gid: "",
        styleType: 0,
        current: 0,
        showDots: 0
    },
    ready: function() {
        var e, a, i = this;
        this.data.gid = wx.getStorageSync("categoryInfo").gid, 2 == this.data.position && (this.data.gid = this.data.cid), 
        e = "banner-".concat(this.data.gid), (a = n.get(e)) && null != a ? this.initBannerDatas(a) : t.getBannerDatas(this.data.position, this.data.gid, function(t) {
            i.initBannerDatas(t, function() {
                n.put(e, t, 300);
            });
        }, function(t) {});
    },
    methods: {
        initBannerDatas: function(t, a) {
            t.forEach(function(t, a) {
                t.images && (t.images = e.replaceOss(t.images));
            }), this.setData({
                bannerData: t
            }), "function" == typeof a && a();
        },
        navigateToMiniProgram: function(t) {
            var e = t.currentTarget.dataset, a = e.appid, n = e.path, i = wx.getStorageSync("categoryInfo"), r = i.gid, o = i.gname, s = wx.getStorageSync("webIdInfo").web_id;
            this.scEvent(t), "wxb7340ab1fe9bb3ee" != a ? wx.navigateToMiniProgram({
                appId: a,
                path: n + "?gid=" + r + "&gname=" + o + "&web_id=" + s,
                extraData: {
                    gid: r,
                    gname: o,
                    web_id: s
                },
                success: function() {}
            }) : wx.navigateTo({
                url: "/" + n
            });
        },
        navigateExtUrl: function(t) {
            var a = t.currentTarget.dataset.url;
            e.thirdAgrement(a) || (this.scEvent(t), wx.navigateTo({
                url: "/pages/webview/webview?url=" + encodeURIComponent(a)
            }));
        },
        contactEvent: function(t) {
            t.currentTarget.dataset;
            this.scEvent(t);
        },
        changeSwiper: function(t) {},
        transtionSwiper: function(t) {
            this.setData({
                current: t.detail.current
            });
        },
        scEvent: function(a) {
            var n = a.currentTarget.dataset.title, i = 1 == this.data.position ? "商城首页" : "商城频道页";
            e.reportEvent(t, "clickBanner", {
                belongPage: i,
                examinationID: this.data.gid + "",
                belongBlock: "banner",
                bannerName: n
            });
        }
    }
});