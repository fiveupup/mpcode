var a = getApp(), t = require("../../utils/util"), e = require("../../configs/baseConfig");

require("../../configs/config_" + e.appName);

Component({
    options: {
        multipleSlots: !0
    },
    properties: {
        isShowCoupon: {
            type: Boolean,
            value: !1
        },
        from: {
            type: String,
            value: "index"
        }
    },
    data: {
        missingPhone: "",
        smsCode: "",
        abletoSendCode: !0,
        interval: 60,
        verifyMsg: "重新获取",
        showVerifyLayer: !1
    },
    ready: function() {
        this.data.categoryInfo = wx.getStorageSync("categoryInfo") || {}, this.data.webIdInfo = wx.getStorageSync("webIdInfo") || {};
    },
    methods: {
        getPhoneNumberCB: function(o) {
            var n = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : function() {}, s = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : function() {}, d = arguments.length > 3 && void 0 !== arguments[3] ? arguments[3] : function() {};
            console.log("getPhoneNumberCB", o);
            var i = this;
            if (i.successCallback = n, i.faillCallback = s, i.redPacketCallback = d, !o.detail.iv) return t.hideLoading(), 
            void i.faillCallback();
            var r = {
                e: o
            };
            a.wxMobRegister(r, function(a) {
                switch (i.redPacketCallback(a), t.hideLoading(), console.log("wxMobRegister code:", a.data.status.code), 
                parseInt(a.data.status.code)) {
                  case 10001:
                    wx.getStorageSync("zhuliReg") && (wx.removeStorageSync("zhuliReg"), wx.setStorageSync("loginReg", 1)), 
                    wx.setStorage({
                        key: "hqUserInfo",
                        data: a.data.data
                    }), wx.setStorage({
                        key: e.tokenKey,
                        data: a.data.data.token,
                        success: function() {
                            10001 === parseInt(a.data.status.code) ? (i.data.token = a.data.data.token, i.successCallback()) : t.showToast2(a.data.status.msg), 
                            t.hideLoading();
                        }
                    });
                    break;

                  case 10002:
                    i.data.phone = a.data.data.phone, i.getSMSCode();
                }
            });
        },
        getSMSCode: function() {
            var e = this, o = e.data.phone.substr(0, 3) + "****" + e.data.phone.substr(-4);
            if (e.setData({
                showVerifyLayer: !0,
                missingPhone: o
            }), e.data.abletoSendCode) {
                t.showLoading({
                    title: "验证码获取中...",
                    mask: !0
                });
                var n = {
                    phone: e.data.phone
                };
                a.getSMSCode(n, function(a) {
                    0 == a.data.status.code ? (t.hideLoading(), t.showToast2("验证码已发送~"), e.countDown()) : 210 == a.data.status.code ? (t.showToast2(a.data.status.msg), 
                    e.setData({
                        showVerifyLayer: !1
                    })) : t.showToast2(a.data.status.msg);
                });
            }
        },
        countDown: function() {
            var a = this, t = setInterval(function() {
                a.data.interval--, a.setData({
                    abletoSendCode: !1,
                    verifyMsg: "(" + a.data.interval + "s)重新获取"
                }), 0 == a.data.interval && (clearInterval(t), a.data.abletoSendCode = !0, a.data.interval = 60, 
                a.setData({
                    abletoSendCode: !0,
                    verifyMsg: "重新获取"
                }));
            }, 1e3);
        },
        autoNext: function(a) {
            this.data.smsCode = a.detail.value, this.data.smsCode.length > 5 && this.submitLogin();
        },
        closeVerifyLayer: function() {
            this.setData({
                showVerifyLayer: !1
            });
        },
        submitLogin: function() {
            var o = this, n = this;
            t.showLoading({
                title: "加载中...",
                mask: !0
            }), a.getUserInfo(function() {
                var s = {
                    encryptedData: encodeURIComponent(a.globalData.appBaseInfo.data),
                    iv: encodeURIComponent(a.globalData.appBaseInfo.iv),
                    code: encodeURIComponent(a.globalData.code),
                    sessionKey: encodeURIComponent(wx.getStorageSync("sessionKey")),
                    name: o.data.phone,
                    smsCode: o.data.smsCode,
                    isBind: 1
                };
                a.login(s, function(a) {
                    0 == a.data.status.code && (n.setData({
                        showVerifyLayer: !1,
                        token: a.data.data.token
                    }), wx.setStorage({
                        key: "hqUserInfo",
                        data: a.data.data
                    }), wx.setStorage({
                        key: e.tokenTimeStamp,
                        data: t.timeStamp()
                    }), wx.setStorage({
                        key: e.tokenKey,
                        data: a.data.data.token,
                        success: function() {
                            n.data.token = a.data.data.token, n.successCallback();
                        }
                    })), t.hideLoading();
                });
            });
        }
    }
});