getApp(), require("../../utils/util"), require("../../configs/baseConfig"), require("../../utils/request");

var e = require("../../pages/template/template");

Component({
    properties: {
        winType: {
            type: String,
            observer: function(e) {
                this.setData({
                    winType: e
                });
            }
        },
        goodsName: {
            type: String,
            observer: function(e) {
                this.setData({
                    goodsName: e
                });
            }
        },
        winShareState: {
            type: Boolean,
            observer: function(e) {
                this.setData({
                    winShareState: e
                });
            }
        },
        drawSuccess: {
            type: Boolean,
            observer: function(e) {
                this.setData({
                    drawSuccess: e
                });
            }
        },
        drasCode: {
            type: Number,
            observer: function(e) {
                this.setData({
                    drasCode: e
                });
            }
        }
    },
    data: {
        winShareState: !1,
        goodsName: "",
        drawSuccess: !1,
        drasCode: 0,
        winType: 1
    },
    ready: function() {},
    methods: {
        goIndex: function() {
            wx.redirectTo({
                url: "/pages/index/index"
            });
        },
        navigateToOnlive: function() {
            e.navigateToMiniProgramPro(3, this.data.gid, this.data.gname);
        },
        closeWinShare: function() {
            2 == this.data.winType && this.setData({
                winShareState: !1
            });
        }
    }
});