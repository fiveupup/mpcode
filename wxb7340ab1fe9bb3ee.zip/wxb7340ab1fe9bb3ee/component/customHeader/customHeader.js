getApp(), require("../../utils/util");

Component({
    properties: {
        title: {
            type: [ String, Number ],
            value: ""
        },
        titleColor: {
            type: [ String ],
            value: "#0B0B0B"
        },
        type: {
            type: [ String ],
            value: "back"
        },
        arrowType: {
            type: [ String, Number ],
            value: 1
        },
        isScrollTop: {
            type: [ Boolean ],
            value: !1,
            observer: function(e, t) {
                this.menu && (e && this.data.scrollTopBg ? this.setData({
                    headerStyle: this.data.headerStyle + "background:" + this.data.scrollTopBg
                }) : this.setHeaderStyle());
            }
        },
        scrollTopBg: {
            type: [ String ],
            value: ""
        },
        backUrl: {
            type: [ String ],
            value: ""
        }
    },
    data: {
        headerStyle: "",
        hqUserInfo: {},
        headerHeight: 0
    },
    ready: function() {
        this.initHeader();
    },
    methods: {
        initHeader: function() {
            this.menu = wx.getMenuButtonBoundingClientRect(), this.setHeaderStyle(), this.setData({
                headerHeight: this.menu.top + 3 + this.menu.height + 5
            }), this.triggerEvent("getHeight", this.data.headerHeight);
        },
        setHeaderStyle: function() {
            this.setData({
                headerStyle: "padding-top:" + (this.menu.top + 3) + "px;height:" + (this.menu.height + 5) + "px;"
            });
        },
        back: function() {
            this.backUrl ? wx.reLaunch({
                url: this.backUrl
            }) : wx.navigateBack({
                delta: 1,
                fail: function() {
                    wx.navigateTo({
                        url: "/pages/index/index"
                    });
                }
            });
        }
    }
});