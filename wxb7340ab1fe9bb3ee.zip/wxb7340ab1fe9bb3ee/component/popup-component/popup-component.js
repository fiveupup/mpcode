var t = getApp().sensors;

Component({
    options: {
        multipleSlots: !0
    },
    ready: function() {},
    lifetimes: {
        attached: function() {
            this.subscribe();
        }
    },
    properties: {},
    data: {
        flag: !0,
        isShow: !1,
        template: {},
        image_list: [],
        image_load: {},
        msg: {
            $sf_msg_title: "",
            $sf_msg_content: "",
            $sf_msg_image_url: "",
            $sf_succeed: "",
            $sf_fail_reason: "",
            $sf_msg_id: ""
        },
        plan: {}
    },
    methods: {
        subscribe: function() {
            t.popupEmitter.sub = [], t.popupEmitter.add(this);
        },
        loadImage: function(t) {
            if (t && t.length > 0) {
                var a = [].concat(this.image_list, t);
                this.setData({
                    image_list: a
                });
            }
        },
        handle: function(t) {
            if (this.data.flag) {
                if (!t.popupTree && !t.properties) return this.popupFail(1001), !1;
                this.initMessage(t), this.setData({
                    template: t.popupTree
                }), this.setData({
                    image_load: {}
                }), t.msg.plan && this.setData({
                    plan: t.msg.plan
                }), !t.msg.is_control_group && this.data.flag ? (this.setData({
                    isShow: !0
                }), this.needLoadimageFirst() ? this.loadimageFirst() : this.showPopup()) : this.popupFail(2e3);
            }
        },
        initMessage: function(t) {
            var a = t.popupTree, e = {
                $sf_msg_id: t.msg.uuid
            };
            e.$sf_msg_title = a.title ? a.title.innerText : "", e.$sf_msg_content = a.content ? a.content.innerText : "", 
            e.$sf_msg_image_url = a.img ? a.img.src : "", e.plan_id = t.msg.plan && t.msg.plan.plan_id || "", 
            e.$sf_audience_id = t.msg.plan && t.msg.plan.audience_id || "", e.is_control_group = t.msg.is_control_group, 
            this.setData({
                msg: e
            });
        },
        popupFail: function(a) {
            var e = Object.assign({}, this.data.msg);
            e.$sf_succeed = !1, e.fail_code = a, e.$sf_fail_reason = {
                1000: "图片加载失败",
                1001: "预览信息解析失败，请检查计划配置",
                2000: "对照组"
            }[a], e.is_control_group = this.data.msg.is_control_group, 2e3 !== a ? t.events.emit("popup_load_fail", e) : t.events.emit("group_popup_display", e), 
            t.events.emit("popup_end", this.data.plan);
        },
        clickMask: function() {
            if (this.data.template.properties.maskCloseEnabled) {
                var a = Object.assign({}, this.data.msg);
                a.$sf_msg_action_id = this.data.template.properties.maskActionId, a.$sf_close_type = "POPUP_CLOSE_MASK", 
                a.$sf_msg_element_type = "mask", a.is_control_group = this.data.msg.is_control_group, 
                t.events.emit("popup_click", a), this.hidePopup();
            }
        },
        hidePopup: function() {
            this.setData({
                flag: !0
            }), this.setData({
                isShow: !1
            }), t.events.emit("popup_end", this.data.plan);
        },
        showPopup: function() {
            if (this.data.msg.is_control_group) return !1;
            this.setData({
                flag: !1
            });
            var a = Object.assign({}, this.data.msg);
            a.$sf_succeed = !0, a.is_control_group = this.data.msg.is_control_group, t.events.emit("popup_display", a);
        },
        tapContent: function() {
            console.log("点击了弹窗窗体");
        },
        topCloseButton: function() {
            var t = this.data.template.image_button;
            t.$sf_close_type || (t.$sf_close_type = "POPUP_CLOSE_TOPRIGHT"), this.popupCLick(t);
        },
        buttomCloseButton: function() {
            var t = this.data.template.image_button;
            t.$sf_close_type || (t.$sf_close_type = "POPUP_CLOSE_BOTTOM"), this.popupCLick(t);
        },
        clickImage: function() {
            var t = this.data.template.img;
            t.$sf_close_type || (t.$sf_close_type = "POPUP_CLOSE_BUTTON"), this.popupCLick(t);
        },
        buttonFirst: function() {
            var t = this.data.template.button[0];
            "close" !== t.action_type || t.$sf_close_type || (t.$sf_close_type = "POPUP_CLOSE_BUTTON"), 
            this.popupCLick(t);
        },
        buttonSecond: function() {
            var t = this.data.template.button[1];
            "close" !== t.action_type || t.$sf_close_type || (t.$sf_close_type = "POPUP_CLOSE_BUTTON"), 
            this.popupCLick(t);
        },
        popupCLick: function(a) {
            var e = Object.assign({}, this.data.msg);
            switch (e.$sf_msg_element_type = a.type, e.$sf_msg_element_content = a.innerText, 
            e.$sf_msg_action_id = a.id, e.action_value = a.value, e.$sf_msg_element_action = a.action_type, 
            e.$sf_close_type = a.$sf_close_type, e.is_control_group = this.data.msg.is_control_group, 
            a.action_type) {
              case "copy":
                wx.setClipboardData({
                    data: a.value,
                    success: function(t) {
                        console.log("复制文本成功");
                    }
                });
                break;

              case "navigateTo":
                e.action_value = {
                    path: a.path
                }, this.navigatePage(e.action_value);
                break;

              case "navigateToMiniProgram":
                e.action_value = {
                    path: a.path,
                    appid: a.appid
                }, this.navigateMini(e.action_value);
            }
            t.events.emit("popup_click", e), a.closeable && this.hidePopup();
        },
        navigatePage: function(t) {
            wx.navigateTo({
                url: t.path,
                success: function() {
                    console.log("navigate success");
                },
                fail: function(t) {
                    console.log("navigate fail: ", t);
                }
            });
        },
        navigateMini: function(t) {
            wx.navigateToMiniProgram({
                appId: t.appid,
                path: t.path,
                success: function() {
                    console.log("navigate success");
                },
                fail: function(t) {
                    console.log("navigate fail： ", t);
                }
            });
        },
        needLoadimageFirst: function() {
            return !!(this.data.template.img || this.isExistImageButton() || this.data.template.image_button && !this.data.template.image_button.useLocalImage);
        },
        isExistImageButton: function() {
            if (!this.data.template.button || this.data.template.button.length < 1) return !1;
            var t = this.data.template.button;
            for (var a in t) if ("image_button" === t[a].type) return !0;
        },
        loadimageFirst: function() {
            if (this.data.template.img && this.setData({
                "image_load.image": 0
            }), this.data.template.image_button && (this.data.template.image_button.useLocalImage || this.setData({
                "image_load.image_button": 0
            })), this.data.template.button && this.data.template.button.length > 0) {
                var t = this.data.template.button;
                for (var a in t) "image_button" === t[a].type && (0 == a ? this.setData({
                    "image_load.first_button": 0
                }) : 1 == a && this.setData({
                    "image_load.second_button": 0
                }));
            }
        },
        image: function() {
            this.setData({
                "image_load.image": 1
            }), this.checkLoad();
        },
        imageError: function(t) {
            console.log("load image error: ", t.detail), this.setData({
                "image_load.image": 2
            }), this.checkLoad();
        },
        firstButton: function() {
            this.setData({
                "image_load.first_button": 1
            }), this.checkLoad();
        },
        firstButtonError: function(t) {
            console.log("load button error: ", t.detail), this.setData({
                "mage_load.first_button": 2
            }), this.checkLoad();
        },
        secondButton: function() {
            this.setData({
                "image_load.second_button": 1
            }), this.checkLoad();
        },
        secondButtonError: function(t) {
            console.log("load button error: ", t.detail), this.setData({
                "mage_load.first_button": 2
            }), this.checkLoad();
        },
        imageButton: function() {
            if (this.data.template.image_button.useLocalImage) return !1;
            this.setData({
                "image_load.image_button": 1
            }), this.checkLoad();
        },
        imageButtonError: function(t) {
            if (console.log("load  button error: ", t.detail), this.data.template.image_button.useLocalImage) return !1;
            this.setData({
                "mage_load.image_button": 2
            }), this.checkLoad();
        },
        checkLoad: function() {
            var t = !0, a = !0, e = this.data.image_load;
            for (var i in e) 0 === e[i] ? a = !1 : 2 === e[i] && (t = !1);
            a && t && this.showPopup(), a && !t && this.popupFail(1e3);
        }
    }
});