getApp(), require("../../utils/util");

Component({
    properties: {
        imgUrl: {
            type: String,
            observer: function(e) {}
        },
        isShow: {
            type: Boolean,
            value: !1,
            observer: function(e) {}
        },
        info: {
            type: Object,
            value: {}
        },
        isQueryTeacherWechatExam: {
            type: Boolean,
            value: !1,
            observer: function(e) {}
        },
        teacherid: {
            type: String,
            value: "",
            observer: function(e) {
                console.log(999, "teacherid", e);
            }
        },
        isLiveCode: {
            type: String,
            value: ""
        },
        wechatFrom: {
            type: Number,
            value: ""
        },
        terminalPage: {
            type: Number,
            value: "",
            observer: function(e, t) {}
        }
    },
    data: {
        path: "",
        optionsArr: []
    },
    ready: function() {
        var e = getCurrentPages()[getCurrentPages().length - 1], t = [];
        for (var a in e.options) t.push(a + "=" + e.options[a]);
        this.setData({
            optionsArr: t,
            path: e.route + "?" + t.join("&")
        });
    },
    methods: {
        close: function() {
            console.log(9999, "path", "".concat(this.data.path).concat(0 == this.data.optionsArr.length ? "" : "&", "sendImage=1&imageUrl=").concat(this.data.info.wechatQrcode)), 
            this.setData({
                isShow: !1
            });
        },
        show: function() {
            this.setData({
                isShow: !0
            });
        },
        goAddCode: function() {
            var e = "/pages/addCode/addCode?id=".concat(this.data.teacherid, "&wechatFrom=").concat(this.data.wechatFrom || 0, "&terminalPage=").concat(this.data.terminalPage);
            wx.navigateTo({
                url: e
            });
        }
    }
});