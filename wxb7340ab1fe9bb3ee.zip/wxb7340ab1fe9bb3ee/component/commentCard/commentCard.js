getApp();

var t = require("../../configs/baseConfig"), e = require("../../configs/config_" + t.appName), o = require("../../utils/util");

Component({
    properties: {
        commentOptions: {
            type: Object,
            observer: function(t) {
                this.setData({
                    commentData: t
                });
            }
        },
        commentLoadDone: {
            type: Boolean,
            observer: function(t) {
                this.setData({
                    commentDataDone: t
                });
            }
        }
    },
    data: {
        commentData: "",
        commentDataDone: !1
    },
    ready: function() {
        this.data.token = wx.getStorageSync(t.tokenKey) || "";
    },
    methods: {
        thumbUp: function(a) {
            if (this.data.token) {
                var n = a.currentTarget.dataset;
                this.triggerEvent("thumbUp", n.comment), this.data.commentOptions.datalList.forEach(function(t, e) {
                    t.id == n.comment.id && (n.comment.thumbFlag ? (t.thumbUpNum--, t.thumbFlag = 0) : (t.thumbUpNum++, 
                    t.thumbFlag = 1));
                }), this.setData({
                    commentOptions: this.data.commentOptions
                }), wx.request({
                    url: "".concat(t.hostJAPI, "/comment/v1/thumbUp"),
                    data: {
                        passport: this.data.token,
                        commentId: n.comment.id,
                        thumbUp: n.comment.thumbFlag ? 0 : 1,
                        ip: "127.0.0.1",
                        platform: t.platform,
                        org_id: t.orgId,
                        _os: t.os,
                        _v: e.version,
                        _t: o.timeStamp()
                    },
                    method: "POST",
                    dataType: "json",
                    header: {
                        "content-type": "application/x-www-form-urlencoded"
                    },
                    success: function(t) {
                        t.data.status.code;
                    },
                    fail: function(t) {}
                });
            } else wx.navigateTo({
                url: "/pages/login/login?from=" + encodeURIComponent(o.getCurrentPage())
            });
        }
    }
});