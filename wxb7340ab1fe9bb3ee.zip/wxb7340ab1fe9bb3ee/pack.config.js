module.exports = {
    packPath: "",
    appMode: "top"
};