require("../../uni-bootstrap.js");

var e = {};

e["/.././../utils/util.js"] = require("/.././../utils/util.js"), (global.webpackJsonp = global.webpackJsonp || []).push([ [ "pages/addCode/addCode" ], {
    140: function(e, t, n) {
        (function(e) {
            n(4);
            t(n(2));
            function t(e) {
                return e && e.__esModule ? e : {
                    default: e
                };
            }
            e(t(n(141)).default);
        }).call(this, n(1).createPage);
    },
    141: function(e, t, n) {
        n.r(t);
        var o = n(142), a = n(144);
        for (var r in a) "default" !== r && function(e) {
            n.d(t, e, function() {
                return a[e];
            });
        }(r);
        n(146);
        var i = n(10), c = Object(i.default)(a.default, o.render, o.staticRenderFns, !1, null, null, null, !1, o.components, void 0);
        c.options.__file = "pages/addCode/addCode.vue", t.default = c.exports;
    },
    142: function(e, t, n) {
        n.r(t);
        var o = n(143);
        n.d(t, "render", function() {
            return o.render;
        }), n.d(t, "staticRenderFns", function() {
            return o.staticRenderFns;
        }), n.d(t, "recyclableRender", function() {
            return o.recyclableRender;
        }), n.d(t, "components", function() {
            return o.components;
        });
    },
    143: function(e, t, n) {
        n.r(t), n.d(t, "render", function() {
            return o;
        }), n.d(t, "staticRenderFns", function() {
            return r;
        }), n.d(t, "recyclableRender", function() {
            return a;
        }), n.d(t, "components", function() {});
        var o = function() {
            var e = this.$createElement;
            this._self._c;
        }, a = !1, r = [];
        o._withStripped = !0;
    },
    144: function(e, t, n) {
        n.r(t);
        var o = n(145), a = n.n(o);
        for (var r in o) "default" !== r && function(e) {
            n.d(t, e, function() {
                return o[e];
            });
        }(r);
        t.default = a.a;
    },
    145: function(t, n, o) {
        (function(t) {
            Object.defineProperty(n, "__esModule", {
                value: !0
            }), n.default = void 0;
            var a, r = (a = o(20)) && a.__esModule ? a : {
                default: a
            };
            function i(e, t) {
                return function(e) {
                    if (Array.isArray(e)) return e;
                }(e) || function(e, t) {
                    if ("undefined" == typeof Symbol || !(Symbol.iterator in Object(e))) return;
                    var n = [], o = !0, a = !1, r = void 0;
                    try {
                        for (var i, c = e[Symbol.iterator](); !(o = (i = c.next()).done) && (n.push(i.value), 
                        !t || n.length !== t); o = !0) ;
                    } catch (e) {
                        a = !0, r = e;
                    } finally {
                        try {
                            o || null == c.return || c.return();
                        } finally {
                            if (a) throw r;
                        }
                    }
                    return n;
                }(e, t) || function(e, t) {
                    if (!e) return;
                    if ("string" == typeof e) return c(e, t);
                    var n = Object.prototype.toString.call(e).slice(8, -1);
                    "Object" === n && e.constructor && (n = e.constructor.name);
                    if ("Map" === n || "Set" === n) return Array.from(e);
                    if ("Arguments" === n || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n)) return c(e, t);
                }(e, t) || function() {
                    throw new TypeError("Invalid attempt to destructure non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.");
                }();
            }
            function c(e, t) {
                (null == t || t > e.length) && (t = e.length);
                for (var n = 0, o = new Array(t); n < t; n++) o[n] = e[n];
                return o;
            }
            var s = getApp(), d = o(24)("./config_" + r.default.appName).default, l = e["/.././../utils/util.js"], u = {
                data: function() {
                    return {
                        isFromApp: 0,
                        wechatQr: {},
                        codeData: "",
                        codeImage: "",
                        navigation: "",
                        hquid: "",
                        token: "",
                        left: "",
                        wxcodeImgs: [ "https://oss-hqwx-edu24ol.hqwx.com/miniapp/hq_mall/wxcode9.png" ],
                        customBgImgUrl: ""
                    };
                },
                components: {
                    cDetailCode: function() {
                        Promise.all([ o.e("common/vendor"), o.e("components/c-detail-code/c-detail-code") ]).then(function() {
                            return resolve(o(381));
                        }.bind(null, o)).catch(o.oe);
                    }
                },
                onLoad: function(e) {
                    if (console.log(999, 111, e), e.bgImgName && (this.customBgImgUrl = "https://oss-hqwx-edu24ol.hqwx.com/miniapp/common/addcode/".concat(e.bgImgName)), 
                    e.lotteryId) this.getLotteryActivityDetail(e.lotteryId); else {
                        if (e.storage) {
                            this.wechatQr.terminalPage = e.terminalPage, this.wechatQr.appName = d.appid, this.codeData = t.getStorageSync("wxQrcodeInfo") || {};
                            var n = this.codeData.wechatQrcode || this.codeData.assistTeacherVo.webchatQrcodeUrl;
                            return this.codeImage = n.replace("http://", "https://"), void this.reportEvent("进入页面");
                        }
                        var o = "";
                        if (e.extra && e.scene && (o = JSON.parse(decodeURIComponent(e.extra))), e.scene) {
                            console.log(22, e.scene);
                            var a = decodeURIComponent(e.scene).replace("scene=", ""), r = null;
                            a.indexOf(",") > 0 && (r = a.split(",")), a.indexOf("&") > 0 && (r = a.split("&")), 
                            console.log(999, 111, e.scene, a, r);
                            var c = i(r, 6), s = c[0], l = c[1], u = c[2], h = c[3], f = c[4], p = c[5];
                            this.isFromApp = 1, this.wechatQr = {
                                id: s,
                                wechatFrom: u,
                                terminalPage: h,
                                appName: l
                            }, o && (this.wechatQr = Object.assign(this.wechatQr, o)), this.hquid = f, this.token = p, 
                            console.log("wechatQr", this.wechatQr), this.getCode();
                        } else {
                            var m = e.appName || d.appid;
                            if (e.id) this.wechatQr = {
                                id: e.id,
                                wechatFrom: e.wechatFrom,
                                terminalPage: e.terminalPage,
                                appName: m
                            }, e.wxb && (this.wechatQr.bussiness = e.wxb), e.wxbId && (this.wechatQr.bussinessId = e.wxbId), 
                            this.hquid = e.hquid || (t.getStorageSync("hqUserInfo") ? t.getStorageSync("hqUserInfo").uid : ""), 
                            console.log(88888), this.getCode(); else if (t.getStorageSync("wxcode")) {
                                var g = t.getStorageSync("wxcode"), w = this.wxcodeImgs.filter(function(e, t) {
                                    return e == g.img;
                                });
                                console.log(888, w), new Date().getTime() - g.timeStemp > 6e4 || !w.length ? this.setStorageSync() : this.codeImage = g.img;
                            } else this.setStorageSync();
                        }
                    }
                },
                onShow: function(e) {},
                methods: {
                    setStorageSync: function() {
                        var e = "https://oss-hqwx-edu24ol.hqwx.com/miniapp/hq_mall/wxcode" + s.random(9, 9) + ".png";
                        this.codeImage = e, t.setStorageSync("wxcode", {
                            img: e,
                            timeStemp: new Date().getTime()
                        });
                    },
                    goBack: function() {
                        t.navigateBack({
                            delta: 1,
                            fail: function() {
                                t.navigateTo({
                                    url: "/pages/index/index"
                                });
                            }
                        });
                    },
                    getCode: function() {
                        var e = this, t = Object.assign({}, this.wechatQr, {
                            passport: this.token || ""
                        });
                        console.log(999, 222, t), this.$hq.http.get("".concat(r.default.httpHost, "japi.hqwx.com/crm/getWechatQrById"), t).then(function(t) {
                            0 == t.data.status.code && (e.codeData = t.data.data, e.codeImage = t.data.data.wechatQrcode, 
                            e.reportEvent("进入页面"));
                        });
                    },
                    longpress: function() {
                        this.wechatQr && this.reportEvent("长按识别二维码");
                    },
                    reportEvent: function(e) {
                        var t = {
                            belongPage: this.wechatQr.terminalPage,
                            QRCodeId: this.codeData.id,
                            QRCodeName: this.codeData.showName,
                            QRCodeType: this.codeData.wechatType,
                            examinationName: this.codeData.category,
                            appName: this.wechatQr.appName,
                            distinctID: this.hquid,
                            sourceType: e
                        };
                        console.log(999, "data", t), l.reportEvent(s, "pressAddWeChat", t);
                    },
                    getLotteryActivityDetail: function(e) {
                        var t = this, n = {
                            ids: "".concat(e),
                            passport: !0,
                            edu24ol_token: !0
                        };
                        this.$hq.get("https://japi.hqwx.com/op/lottery/getLotteryActivityDetail", n).then(function(n) {
                            if (0 == n.data.status.code && n.data.data.length > 0) {
                                var o = n.data.data[0];
                                o && o.id == e && (t.codeImage = o.sallerImg);
                            }
                        });
                    }
                }
            };
            n.default = u;
        }).call(this, o(1).default);
    },
    146: function(e, t, n) {
        n.r(t);
        var o = n(147), a = n.n(o);
        for (var r in o) "default" !== r && function(e) {
            n.d(t, e, function() {
                return o[e];
            });
        }(r);
        t.default = a.a;
    },
    147: function(e, t, n) {}
}, [ [ 140, "common/runtime", "common/vendor" ] ] ]);