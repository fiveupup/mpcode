var a = getApp(), t = require("../../utils/util"), e = require("../template/template"), o = require("../../configs/baseConfig"), i = require("../../configs/config_" + o.appName), d = require("../../utils/allGid");

Page({
    data: {
        pageAddr: 1,
        categoryData: [],
        categoryName: "",
        categoryId: 0,
        pageNumber: 1,
        isEmpty: !1,
        dataInfo: null,
        isOver: 0,
        webIdInfo: {},
        bannerData: [],
        isIPhoneX: !1,
        isGettingData: !1,
        grayLevel: !0
    },
    onLoad: function(e) {
        e = a.customDecode(e);
        var o = this;
        t.setUrlParams(e), t.showLoading({
            title: "加载中...",
            mask: !0
        }), this.fromOther(e), a.updateCheck(function() {}, function() {
            o.setData({
                grayLevel: !1
            });
        }), e.web_id && a.setWebIdToStorage(e.web_id), this.getWedId(), this.fixIPhone(), 
        o.data.categoryId = e.gid, o.data.categoryName = decodeURIComponent(e.gname) || "", 
        o.data.categoryData = wx.getStorageSync("categoryData"), this.setData({
            categoryName: this.data.categoryName
        }), o.setData({
            categoryId: o.data.categoryId
        }), o.data.categoryId && t.reportEvent(a, "MPViewScreenExID", {
            $url_path: o.route,
            examinationID: o.data.categoryId + ""
        }), e.wxEduCd && wx.setStorageSync("wxEduCd", e.wxEduCd), "undefined" != this.data.categoryName ? (wx.setNavigationBarTitle({
            title: o.data.categoryName
        }), o.getDataList()) : o.fromEduCd(e, function() {
            o.getDataList();
        });
    },
    fromOther: function(a) {
        void 0 !== a.gid && void 0 !== a.gname && (this.setData({
            categoryInfo: {
                gid: a.gid,
                gname: decodeURIComponent(a.gname)
            }
        }), a.isCourseList || wx.setStorageSync("categoryInfo", {
            gid: a.gid,
            gname: decodeURIComponent(a.gname)
        }));
    },
    btmBarCreateFormId: function(a) {
        e.btmBarCreateFormId(a);
    },
    getDataList: function(a) {
        var e, d = this, n = (d.data.dataInfo, !a || !a.type || "scrolltolower" == a.type);
        1 != d.data.isOver && 1 != this.data.isGettingData && (this.data.isGettingData = 1, 
        t.showLoading(), wx.request({
            url: o.host + "/mobile/v2/goods/getGoodsGroupList",
            data: {
                _appid: i.appid,
                _os: o.os,
                _v: i.version,
                _t: t.timeStamp(),
                platform: o.platform,
                objType: o.objType,
                second_category: d.data.categoryId,
                isNew: 1,
                from: 10 * (d.data.pageNumber - 1),
                rows: 10,
                org_id: o.orgId
            },
            method: "GET",
            dataType: "json",
            success: function(a) {
                0 == a.data.status.code && (n ? (null != a.data.data && a.data.data.length > 0 ? (e = a.data.data, 
                d.setData({
                    isEmpty: !1,
                    dataInfo: e
                })) : (1 == d.data.pageNumber && d.setData({
                    isEmpty: !0
                }), d.data.isOver = 1), d.data.pageNumber++) : (d.data.pageNumber = 1, null != a.data.data && a.data.data.list.length > 0 ? (e = a.data.data.list, 
                d.setData({
                    isEmpty: !1,
                    dataInfo: e
                })) : (d.setData({
                    isEmpty: !0
                }), d.data.isOver = 1))), t.hideLoading();
            },
            fail: function(a) {
                t.hideLoading();
            }
        }));
    },
    getLoadNum: function() {
        t.hideLoading(), this.data.isGettingData = 0;
    },
    clickMallCard: function(a) {
        var t = a.detail.__args__[0];
        wx.navigateTo({
            url: "/pages/courseDetail/courseDetail?id=".concat(t.id)
        });
    },
    navigateToMiniProgramPro: function() {
        e.navigateToMiniProgramPro(1, wx.getStorageSync("categoryInfo").gid, wx.getStorageSync("categoryInfo").gname, this.data.webIdInfo.web_id);
    },
    fixIPhone: function() {
        a.fixIPhone(this);
    },
    fromEduCd: function(a, t) {
        for (var e = "", o = 0; o < d.length; o++) if (d[o].id == this.data.categoryId) {
            e = d[o].name, wx.setStorageSync("categoryInfo", {
                gid: this.data.categoryId,
                gname: e
            }), wx.setNavigationBarTitle({
                title: e
            }), "function" == typeof t && t(), this.setData({
                categoryName: e
            });
            break;
        }
        a.wxEduCd && wx.setStorageSync("wxEduCd", a.wxEduCd);
    },
    getWedId: function() {
        var a = this;
        wx.getStorage({
            key: "webIdInfo",
            success: function(t) {
                a.data.webIdInfo = t.data || {};
            },
            fail: function(t) {
                a.data.webIdInfo = {};
            }
        });
    },
    onShareAppMessage: function(a) {
        var t = i.shareObj.path + "?web_id=" + this.data.webIdInfo.web_id + "&wxEduCd=" + wx.getStorageSync("wxEduCd");
        return {
            title: i.shareObj.title,
            path: t,
            imageUrl: i.shareObj.imageUrl,
            success: function(a) {}
        };
    }
});