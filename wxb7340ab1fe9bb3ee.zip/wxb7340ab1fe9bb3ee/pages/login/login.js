var e = getApp(), t = require("../../utils/util"), a = require("../../configs/baseConfig"), o = require("../../configs/config_" + a.appName);

Page({
    data: {
        phone: "",
        missingPhone: "",
        password: "",
        smsCode: "",
        warnText: "",
        isShowWarn: !1,
        showPhoneDel: !1,
        showPasswordDel: !1,
        sourcePath: "/pages/user/user",
        sourceParams: "",
        sourceParamsJSONstr: "",
        otherLoginParams: "",
        isBind: 1,
        abletoSendCode: !0,
        interval: 60,
        verifyMsg: "重新获取",
        showVerifyLayer: !1,
        focusIndex: 1
    },
    onLoad: function(o) {
        if (this.data.firstPType = t.getUrlParams().firstPType || "", wx.getStorageSync("categoryInfoShortID") && wx.getStorageSync("categoryInfoShortID").gid ? this.data.categoryInfo = wx.getStorageSync("categoryInfoShortID") || {} : this.data.categoryInfo = wx.getStorageSync("categoryInfo") || {}, 
        this.data.webIdInfo = wx.getStorageSync("webIdInfo") || {}, wx.removeStorageSync("hqUserInfo"), 
        wx.removeStorageSync(a.tokenKey), void 0 !== o.sourcePath && (this.data.sourcePath = decodeURIComponent(o.sourcePath), 
        this.data.otherLoginParams = "sourcePath=" + o.sourcePath), this.data.from = o.from || "", 
        o.from && (this.data.sourcePath = decodeURIComponent(o.from), this.jumpPath = this.data.sourcePath, 
        this.data.otherLoginParams = "sourcePath=" + o.from), void 0 !== o.from && 1 == t.queryString(decodeURIComponent(o.from), "chooseExam")) {
            var n = "/pages/exam/exam?sourcePath=/pages/exam/exam" + encodeURIComponent("?chooseExam=1");
            this.data.sourcePath = n, this.data.otherLoginParams = "sourcePath=" + n;
        }
        this.setData({
            otherLoginParams: this.data.otherLoginParams
        }), e.globalData.code && e.globalData.appBaseInfo && e.globalData.appBaseInfo.iv, 
        e.getUserInfo(this.queryBindState, this);
    },
    onHide: function() {},
    onUnload: function() {},
    getUserInfoData: function() {
        e.getUserInfo(this.queryBindState);
    },
    queryBindState: function() {
        var n = this;
        t.showLoading({
            title: "加载中...",
            mask: !0
        }), wx.request({
            url: a.host + "/wxapp/v1/user/profile",
            method: "POST",
            dataType: "json",
            header: {
                "content-type": "application/x-www-form-urlencoded"
            },
            data: {
                appid: o.appid,
                org_id: a.orgId,
                platform: a.platform,
                encryptedData: encodeURIComponent(e.globalData.appBaseInfo.encryptedData),
                code: encodeURIComponent(e.globalData.code),
                iv: encodeURIComponent(e.globalData.appBaseInfo.iv),
                sessionKey: encodeURIComponent(wx.getStorageSync("sessionKey")),
                distinct_id: o.sdid
            },
            success: function(o) {
                console.log("queryBindState", o), 0 == o.data.status.code ? (t.userBindReport(e, o.data.data.uid), 
                wx.setStorage({
                    key: "hqUserInfo",
                    data: o.data.data
                }), wx.setStorage({
                    key: a.tokenTimeStamp,
                    data: t.timeStamp()
                }), wx.setStorage({
                    key: a.tokenKey,
                    data: o.data.data.token,
                    success: function() {
                        0 == o.data.status.code ? wx.redirectTo({
                            url: n.data.sourcePath,
                            success: function(e) {
                                console.log("reLaunch success");
                            },
                            fail: function(e) {
                                console.log("reLaunch err", e), wx.redirectTo({
                                    url: n.data.sourcePath,
                                    success: function(e) {
                                        console.log("redirectTo success");
                                    },
                                    fail: function(e) {
                                        console.log("redirectTo err", e);
                                    }
                                });
                            }
                        }) : t.showToast2(o.data.status.msg), t.hideLoading();
                    }
                })) : t.hideLoading();
            }
        });
    },
    getPhoneNumberCB: function(o) {
        console.log("getPhoneNumberCB", o);
        var n = this, s = wx.getStorageSync("zhuliLogin") ? null : this.data.categoryInfo.gid;
        if (t.showLoading({
            title: "登录中...",
            mask: !0
        }), !o.detail.iv) return t.hideLoading(), void t.showToast2("您已经取消登录~");
        e.wxMobRegister({
            e: o,
            sortId: s || null,
            chId: n.data.webIdInfo.web_id || null,
            u: "",
            c: "",
            s: ""
        }, function(o) {
            switch (parseInt(o.data.status.code)) {
              case 10001:
                t.userBindReport(e, o.data.data.uid), wx.removeStorageSync("zhuliLogin"), wx.getStorageSync("zhuliReg") && (wx.removeStorageSync("zhuliReg"), 
                wx.setStorageSync("loginReg", 1)), wx.removeStorageSync("regtype"), wx.setStorage({
                    key: "hqUserInfo",
                    data: o.data.data
                }), wx.setStorage({
                    key: a.tokenKey,
                    data: o.data.data.token,
                    success: function() {
                        wx.setStorage({
                            key: a.tokenTimeStamp,
                            data: t.timeStamp()
                        }), console.log("_this.data.sourcePath", n.data.sourcePath), 10001 === parseInt(o.data.status.code) ? wx.redirectTo({
                            url: n.data.sourcePath,
                            success: function(e) {
                                console.log("reLaunch success");
                            },
                            fail: function(e) {
                                console.log("reLaunch err", e), wx.redirectTo({
                                    url: n.data.sourcePath,
                                    success: function(e) {
                                        console.log("redirectTo success");
                                    },
                                    fail: function(e) {
                                        console.log("redirectTo err", e);
                                    }
                                });
                            }
                        }) : t.showToast2(o.data.status.msg), t.hideLoading();
                    }
                });
                break;

              case 10002:
                n.data.phone = o.data.data.phone, n.getSMSCode();
                break;

              default:
                t.showToast2("您的手机号无效或不支持国外手机号码！");
            }
        });
    },
    clickLoginButton: function() {
        t.reportEvent(e, "clickLoginButton", {});
    },
    getSMSCode: function() {
        var n = this, s = n.data.phone.substr(0, 3) + "****" + n.data.phone.substr(-4);
        n.setData({
            showVerifyLayer: !0,
            missingPhone: s
        }), n.data.abletoSendCode && (t.reportEvent(e, "getSMSCode", {
            serviceType: "短信登录"
        }), t.showLoading({
            title: "验证码获取中...",
            mask: !0
        }), e.getUserInfo(function() {
            wx.request({
                url: a.host + "/wxapp/v1/user/sms",
                method: "POST",
                dataType: "json",
                header: {
                    "content-type": "application/x-www-form-urlencoded"
                },
                data: {
                    appid: o.appid,
                    org_id: a.orgId,
                    platform: a.platform,
                    encryptedData: encodeURIComponent(e.globalData.appBaseInfo.encryptedData),
                    code: encodeURIComponent(e.globalData.code),
                    iv: encodeURIComponent(e.globalData.appBaseInfo.iv),
                    phone: n.data.phone,
                    sessionKey: encodeURIComponent(wx.getStorageSync("sessionKey")),
                    optStr: "login",
                    distinct_id: o.sdid
                },
                success: function(e) {
                    console.log("getSMSCode", e), t.hideLoading(), 0 == e.data.status.code ? (t.showToast2("验证码已发送~"), 
                    n.countDown()) : t.showToast2(e.data.status.msg);
                }
            });
        }));
    },
    countDown: function() {
        var e = this, t = setInterval(function() {
            e.data.interval--, e.setData({
                abletoSendCode: !1,
                verifyMsg: "(" + e.data.interval + "s)重新获取"
            }), 0 == e.data.interval && (clearInterval(t), e.data.abletoSendCode = !0, e.data.interval = 60, 
            e.setData({
                abletoSendCode: !0,
                verifyMsg: "重新获取"
            }));
        }, 1e3);
    },
    submitLogin: function() {
        var n = this;
        t.showLoading({
            title: "登录中...",
            mask: !0
        }), t.reportEvent(e, "clickLoginButton", {});
        var s = e.setExtProperties();
        e.getUserInfo(function() {
            wx.request({
                url: a.host + "/wxapp/v1/user/login",
                method: "POST",
                dataType: "json",
                header: {
                    "content-type": "application/x-www-form-urlencoded"
                },
                data: {
                    srcType: o.srcType,
                    firstPType: n.data.firstPType || o.firstPType,
                    lastPType: o.lastPType,
                    isBind: n.data.isBind,
                    appid: o.appid,
                    org_id: a.orgId,
                    platform: a.platform,
                    encryptedData: encodeURIComponent(e.globalData.appBaseInfo.encryptedData),
                    code: encodeURIComponent(e.globalData.code),
                    iv: encodeURIComponent(e.globalData.appBaseInfo.iv),
                    sessionKey: encodeURIComponent(wx.getStorageSync("sessionKey")),
                    name: n.data.phone,
                    pwd: n.data.password,
                    smsCode: n.data.smsCode,
                    regtype: wx.getStorageSync("regtype") || "",
                    distinct_id: o.sdid,
                    groupId: wx.getStorageSync("trainingGroupId") || "",
                    extProperties: s
                },
                success: function(o) {
                    if (console.log("submitLogin", o), 239 == o.data.status.code) {
                        var s = o.data.data;
                        wx.showModal({
                            title: "提示",
                            content: "当前账号已绑定其它微信号，继续登录需解除已有绑定。是否继续解绑操作？",
                            cancelText: "放弃",
                            confirmText: "继续解绑",
                            success: function(e) {
                                e.confirm ? (wx.setStorage({
                                    key: "hqUserInfo",
                                    data: s
                                }), wx.setStorage({
                                    key: a.tokenKey,
                                    data: s.token
                                }), wx.redirectTo({
                                    url: "/pages/unbindAccount/unbindAccount"
                                })) : e.cancel && t.showToast2("未完成解绑，登录失败。");
                            }
                        }), t.hideLoading();
                    } else 0 == o.data.status.code ? (t.userBindReport(e, o.data.data.uid), wx.removeStorageSync("regtype"), 
                    wx.getStorageSync("zhuliReg") && (wx.removeStorageSync("zhuliReg"), o.data.data.loginReg && wx.setStorageSync("loginReg", 1)), 
                    wx.setStorage({
                        key: "hqUserInfo",
                        data: o.data.data
                    }), wx.setStorage({
                        key: a.tokenTimeStamp,
                        data: t.timeStamp()
                    }), wx.setStorage({
                        key: a.tokenKey,
                        data: o.data.data.token,
                        success: function() {
                            wx.reLaunch({
                                url: n.data.sourcePath
                            });
                        }
                    }), t.hideLoading()) : (t.hideLoading(), t.showToast2(o.data.status.msg));
                }
            });
        });
    },
    autoNext: function(e) {
        this.data.smsCode = e.detail.value, this.data.smsCode.length > 5 && this.submitLogin();
    },
    closeVerifyLayer: function() {
        this.setData({
            showVerifyLayer: !1
        });
    },
    onShareAppMessage: function(t) {
        var a = "/pages/index/index?gid=" + this.data.categoryInfo.gid + "&gname=" + this.data.categoryInfo.gname;
        return a = this.data.webIdInfo.web_id ? a + "&web_id=" + this.data.webIdInfo.web_id : a, 
        {
            title: (e.globalData.userInfo ? e.globalData.userInfo.nickName : "环球网校_快题库") + "(每日一练)",
            path: a,
            success: function(e) {},
            fail: function(e) {}
        };
    }
});