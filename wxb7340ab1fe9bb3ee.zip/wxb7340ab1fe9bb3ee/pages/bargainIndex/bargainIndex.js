var a = getApp(), t = require("../../utils/util"), e = require("../../configs/baseConfig"), o = require("../../configs/config_" + e.appName), n = require("../../utils/request");

require("../../utils/allGid");

Page({
    data: {
        goodListData: {},
        sourcePath: "",
        pid: "",
        gid: "",
        gname: "",
        tab: 0,
        resTimer: null,
        isTimer: 0,
        edu24ol_token: "",
        uid: 0,
        loginURL: "",
        navData: "",
        tabScrollIntoView: "tab-0",
        onCategoryInfo: {},
        fixTab: !1,
        goodListDataEmpty: 0
    },
    onLoad: function(o) {
        o = a.customDecode(o);
        var n = this;
        t.setUrlParams(o), o.web_id && a.setWebIdToStorage(o.web_id), o.gid && (n.setData({
            gid: o.gid,
            gname: decodeURIComponent(o.gname)
        }), wx.setStorageSync("categoryInfo", {
            gid: o.gid,
            gname: decodeURIComponent(o.gname)
        })), this.setData({
            loginURL: "/pages/login/login?sourcePath=/pages/bargainIndex/bargainIndex" + encodeURIComponent("?path=bargain")
        }), a.HQTokenStorage(function() {
            wx.getStorageSync("categoryInfo").gid && n.setData({
                gid: wx.getStorageSync("categoryInfo").gid,
                gname: wx.getStorageSync("categoryInfo").gname
            }), n.initData(o);
        }, function() {
            o.path && "bargain" == o.path && a.getUserShortId(wx.getStorageSync(e.tokenKey), function(a) {
                a.data.data && 0 != a.data.data.length || wx.navigateTo({
                    url: "/pages/exam/exam?sourcePath=/pages/bargainIndex/bargainIndex"
                });
            }, function() {
                wx.navigateTo({
                    url: "/pages/login/login?sourcePath=" + encodeURIComponent("/pages/bargainIndex/bargainIndex?path=index")
                });
            }), wx.getStorageSync("categoryInfo").gid ? (n.setData({
                gid: wx.getStorageSync("categoryInfo").gid,
                gname: wx.getStorageSync("categoryInfo").gname
            }), n.data.edu24ol_token = wx.getStorageSync(e.tokenKey) || "", n.data.edu24ol_token && (n.data.uid = wx.getStorageSync("hqUserInfo").uid || "0"), 
            n.initData(o)) : wx.redirectTo({
                url: "/pages/exam/exam?sourcePath=/pages/bargainIndex/bargainIndex"
            });
        }), n.data.gid && t.reportEvent(a, "MPViewScreenExID", {
            $url_path: n.route,
            examinationID: n.data.gid + ""
        });
    },
    initData: function(a) {
        "index" == a.sourcePath ? this.setData({
            sourcePath: "index"
        }) : "tiku_pro" == a.sourcePath && this.fromOther(a), a && a.gid && a.gname && (this.data.onCategoryInfo = {
            gid: a.gid,
            gname: a.gname
        }, this.data.fixTab = !0), a.pid && (this.data.pid = a.pid), a && a.tab && this.setData({
            tab: a.tab
        }), this.getWedId(), this.getListsWithUserRelated();
    },
    goToLogin: function(a) {
        var t = this, e = a.target.dataset;
        wx.setStorage({
            key: "categoryInfo",
            data: {
                gid: e.gid,
                gname: e.gname
            },
            success: function() {
                wx.navigateTo({
                    url: t.data.loginURL
                });
            }
        });
    },
    changeData: function(a) {
        var t = a.currentTarget.dataset;
        this.data.tab != t.index && (this.data.resTimer && clearInterval(this.data.resTimer), 
        this.data.isTimer = 0, this.data.onCategoryInfo = {
            gid: t.gid,
            gname: t.gname
        }, this.setData({
            tabScrollIntoView: this.data.tabScrollIntoView,
            onCategoryInfo: this.data.onCategoryInfo,
            tab: t.index,
            goodListDataEmpty: 0
        }), this.data.goodListData[t.gid] ? 0 == this.data.goodListData[t.gid].length && this.setData({
            goodListDataEmpty: 1
        }) : this.getData());
    },
    getListsWithUserRelated: function() {
        var a = this;
        t.showLoading({
            title: "加载中..."
        });
        var e = wx.getStorageSync("categoryInfo").gid, o = wx.getStorageSync("favorateData") || [], i = [];
        o.length > 0 && o.forEach(function(a, t) {
            i.push(a.gid);
        });
        var d = {
            token: wx.getStorageSync("hq_token"),
            intention: e,
            interested: i.join(",")
        };
        n.getListsWithUserRelated(d, function(t) {
            if (0 == t.data.status.code) {
                var e = t.data.data, o = [], n = a.data.tab;
                if (o = o.concat(e.intentionSortIdList, e.interestedSortIdList, e.hot, e.intentionRelatedGroup, e.interestedRelatedGroup, e.other), 
                a.data.navData = o, a.data.fixTab) for (var i = 0; i < o.length; i++) if (o[i].categoryId == a.data.onCategoryInfo.gid) {
                    n = i, a.setData({
                        tab: i
                    });
                    break;
                }
                a.data.onCategoryInfo = {
                    gid: o[n].categoryId,
                    gname: o[n].categoryName
                }, a.setData({
                    navData: o,
                    onCategoryInfo: a.data.onCategoryInfo
                }), a.getData();
            }
        });
    },
    getData: function() {
        var a, n = this;
        t.showLoading({
            title: "加载中..."
        });
        var i = this.data.onCategoryInfo.gid;
        a = {
            appid: o.appid,
            org_id: e.orgId,
            edu24ol_token: n.data.edu24ol_token,
            sid: i,
            t: t.timeStamp()
        }, wx.request({
            url: e.host + "/wxapp/activity/zuli/activityList",
            data: a,
            success: function(a) {
                if (0 == a.data.status.code) {
                    var e = a.data.data, o = n.data.goodListData ? n.data.goodListData : {};
                    o[i] = e, n.setData({
                        goodListData: o
                    }), a.data.data.length > 0 ? n.setData({
                        goodListDataEmpty: 0
                    }) : n.setData({
                        goodListDataEmpty: 1
                    }), t.hideLoading();
                } else if (40041 == a.data.status.code || 40042 == a.data.status.code) {
                    t.hideLoading();
                    wx.navigateTo({
                        url: "/pages/login/login?sourcePath=" + encodeURIComponent("/pages/bargainIndex/bargainIndex?path=index")
                    });
                } else t.hideLoading();
            },
            fail: function(a) {
                t.showToast2("网络出错或暂无数据"), t.hideLoading();
            }
        });
    },
    getWxUserInfo: function(t) {
        wx.request({
            url: e.host + "/wxapp/v1/user/getWxUserInfo",
            data: {
                appid: o.appid,
                org_id: e.orgId,
                encryptedData: encodeURIComponent(a.globalData.appBaseInfo.encryptedData),
                code: encodeURIComponent(a.globalData.code),
                iv: encodeURIComponent(a.globalData.appBaseInfo.iv),
                sessionKey: encodeURIComponent(wx.getStorageSync("sessionKey")),
                thirdLogin: o.thirdLogin || "",
                thirdMp: o.thirdMp || ""
            },
            method: "POST",
            header: {
                "content-type": "application/x-www-form-urlencoded"
            },
            success: function(a) {
                0 == a.data.status.code && (wx.setStorageSync("wxInfo", a.data.data), "function" == typeof t && t());
            },
            fail: function() {}
        });
    },
    goBargainDetail: function(a) {
        var t = a.currentTarget.dataset, e = "/pages/bargainDetail/bargainDetail", o = t.zgid, n = t.zugid;
        n > 0 ? (n, e = e + "?zug_id=" + n) : (o, e = e + "?zg_id=" + o + "&uid=" + this.data.uid), 
        wx.navigateTo({
            url: e
        });
    },
    shareFriend: function(a, n) {
        var i = wx.getStorageSync("loginReg") ? 1 : 0;
        wx.request({
            url: e.host + "/wxapp/activity/zuli/share",
            data: {
                appid: o.appid,
                org_id: e.orgId,
                zg_id: a,
                form_id: this.data.formId,
                open_id: wx.getStorageSync("wxInfo").openId,
                edu24ol_token: this.data.edu24ol_token,
                new_user: i
            },
            success: function(a) {
                if (0 == a.data.status.code) {
                    a.data.data;
                    wx.removeStorageSync("loginReg"), t.showToast2("你分享的活动已成功"), setTimeout(function() {
                        wx.navigateTo({
                            url: n
                        });
                    }, 2e3);
                } else 1e4 == a.data.status.code ? t.showToast2("你分享的活动不存在") : 10001 == a.data.status.code ? t.showToast2("你分享的活动已失效") : 10002 == a.data.status.code ? t.showToast2("你分享的活动的库存已为0") : 10003 == a.data.status.code ? t.showToast2("你分享的活动的已完成助力了") : 10004 == a.data.status.code ? t.showToast2("由于系统原因,分享失败") : 40041 != a.data.status.code && 40042 != a.data.status.code || console.log(999, 111);
                t.hideLoading();
            }
        });
    },
    getWedId: function() {
        var a = this;
        wx.getStorage({
            key: "webIdInfo",
            success: function(t) {
                a.data.webIdInfo = t.data || {};
            },
            fail: function(t) {
                a.data.webIdInfo = {};
            }
        });
    },
    fromOther: function(t) {
        t && (t.gid && t.gname && wx.setStorageSync("categoryInfo", {
            gid: t.gid,
            gname: encodeURIComponent(t.gname)
        }), a.setWebIdToStorage(t.web_id));
    },
    getUserInfoData: function(t) {
        a.getUserInfo(function() {}, this);
    },
    onShareAppMessage: function(e) {
        var o = this, n = e.from, i = "/pages/bargainDetail/bargainDetail", d = "&web_id=" + o.data.webIdInfo.web_id, g = "", s = "", r = "", c = "嘿快来看看我发现的免费好课", u = "https://oss-hqwx-edu24ol.hqwx.com/5b932ece644f95dcda3c5083611a33b04458e552.png";
        return "button" == n ? (g = e.target.dataset.mode, s = e.target.dataset.zgid, r = e.target.dataset.zugid, 
        c = e.target.dataset.title, "", r > 0 ? (r, i = i + "?zug_id=" + r + "&fromZhuli=1") : (s, 
        i = i + "?zg_id=" + s + "&uid=" + o.data.uid + "&fromZhuli=1"), 3 != g && 4 != g && 5 != g || (c += "，点击帮我免费领！"), 
        c = "朋友一生一起走，帮我助力真朋友", u = "https://oss-hqwx-edu24ol.hqwx.com/ceae7eec36c65446151ab26054e2a175e28f2acf.jpg") : i = "/pages/bargainIndex/bargainIndex?gname=" + o.data.gname + "&gid=" + o.data.gid, 
        o.data.webIdInfo.web_id && (i += d), "button" != n || 3 != g && 4 != g && 5 != g || (wx.getStorageSync("wxInfo") ? o.shareFriend(s, i) : a.getUserInfo(function() {
            o.getWxUserInfo(function() {
                o.shareFriend(s, i);
            });
        })), {
            title: c,
            path: i,
            imageUrl: u,
            success: function(a) {
                console.log("success");
            },
            complete: function() {
                console.log("complete"), t.hideLoading();
            }
        };
    }
});