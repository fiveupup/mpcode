var e = getApp(), o = require("../../utils/util"), n = require("../../configs/baseConfig"), t = require("../../configs/config_" + n.appName), a = require("../../utils/request");

Page({
    data: {
        wxInfo: {},
        hqUserInfo: {},
        canUnbindAccount: !1
    },
    onLoad: function(n) {
        var t = this;
        o.showLoading({
            title: "加载中...",
            mask: !0
        }), n && "login" == n.sourcePath ? t.data.sourcePath = "login" : t.data.sourcePath = "", 
        this.setData({
            hqUserInfo: wx.getStorageSync("hqUserInfo")
        }), this.profile(function() {
            e.getHQInfo(function(e) {
                o.hideLoading(), t.setData({
                    wxInfo: e.thirdAddInfo,
                    canUnbindAccount: !0
                });
            }, function(e) {});
        });
    },
    profile: function(e) {
        var t = this;
        a.profile(function(a) {
            0 == a.data.status.code ? (o.showLoading(), wx.setStorageSync(n.tokenKey, a.data.data.token), 
            wx.setStorageSync(n.tokenTimeStamp, o.timeStamp()), wx.setStorageSync("hqUserInfo", a.data.data), 
            t.setData({
                hqUserInfo: a.data.data
            }), "function" == typeof e && e()) : (o.showToast2("登录信息有误，请重新登录..."), setTimeout(function() {
                wx.redirectTo({
                    url: "/pages/login/login"
                });
            }, 2e3));
        });
    },
    unbindAccount: function() {
        var e = this;
        this.data.canUnbindAccount ? wx.showModal({
            title: "提示",
            content: "确认要解除当前账号与小程序的绑定吗？",
            cancelText: "放弃",
            confirmText: "继续解绑",
            confirmColor: "#0b86e5",
            success: function(o) {
                o.confirm ? e.unbindThirdUser() : o.cancel && wx.redirectTo({
                    url: "/pages/user/user?source=unbindAccount"
                });
            }
        }) : o.showToast2("用户信息获取中，请稍等...");
    },
    unbindThirdUser: function() {
        var a = this, r = this.data.wxInfo;
        wx.request({
            url: n.host + "/wxapp/v1/user/unbindThirdUser",
            data: {
                appid: t.appid,
                org_id: n.orgId,
                token: wx.getStorageSync(n.tokenKey),
                uid: wx.getStorageSync("hqUserInfo").uid,
                openid: r.userInfoArr.openId,
                source: r.userInfoArr.source,
                srvName: r.userInfoArr.srvName,
                encryptedData: encodeURIComponent(e.globalData.appBaseInfo.encryptedData),
                code: encodeURIComponent(e.globalData.code),
                iv: encodeURIComponent(e.globalData.appBaseInfo.iv),
                sessionKey: encodeURIComponent(wx.getStorageSync("sessionKey")),
                thirdLogin: t.thirdLogin || "",
                thirdMp: t.thirdMp || ""
            },
            method: "POST",
            header: {
                "content-type": "application/x-www-form-urlencoded"
            },
            success: function(e) {
                0 == e.data.status.code ? (wx.removeStorageSync("zhuliReg"), "login" == a.data.sourcePath ? a.bindThirdUser() : (a.clearUserInfoData(), 
                wx.redirectTo({
                    url: "/pages/user/user?source=unbindAccount"
                }))) : (a.clearUserInfoData(), o.showToast2("解绑账号失败，请稍后再试。"));
            },
            fail: function() {
                a.clearUserInfoData(), o.showToast2("解绑账号失败，请稍后再试。");
            }
        });
    },
    bindThirdUser: function() {
        wx.request({
            url: n.host + "/wxapp/v1/user/bindThirdUser",
            data: {
                appid: t.appid,
                org_id: n.orgId,
                token: wx.getStorageSync(n.tokenKey),
                uid: wx.getStorageSync("hqUserInfo").uid,
                encryptedData: encodeURIComponent(e.globalData.appBaseInfo.encryptedData),
                code: encodeURIComponent(e.globalData.code),
                iv: encodeURIComponent(e.globalData.appBaseInfo.iv),
                sessionKey: encodeURIComponent(wx.getStorageSync("sessionKey")),
                thirdLogin: t.thirdLogin || "",
                thirdMp: t.thirdMp || ""
            },
            method: "POST",
            header: {
                "content-type": "application/x-www-form-urlencoded"
            },
            success: function(e) {
                0 == e.data.status.code ? wx.redirectTo({
                    url: "/pages/user/user?source=unbindAccount"
                }) : o.showToast2("自动登录失败。");
            },
            fail: function() {
                o.showToast2("自动登录失败。");
            }
        });
    },
    clearUserInfoData: function() {
        wx.removeStorageSync("hqUserInfo"), wx.removeStorageSync(n.tokenKey), wx.removeStorageSync(n.tokenTimeStamp);
    }
});