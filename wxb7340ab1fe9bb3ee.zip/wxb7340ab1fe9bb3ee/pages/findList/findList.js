var a = getApp(), t = require("../../utils/util"), e = require("../template/template"), i = require("../../configs/baseConfig");

require("../../configs/config_" + i.appName);

Page({
    data: {
        pageAddr: 2,
        qid: 0,
        qname: "",
        pageNo: 1,
        listData: [],
        done: !1,
        isLoading: !1,
        initLoading: 1,
        firstLoading: 1,
        tabType: 1,
        categoryName: "",
        categoryId: "",
        webIdInfo: "",
        isIPhoneX: !1,
        isEmpty: !1,
        grayLevel: !0,
        token: "",
        detailId: ""
    },
    onLoad: function(t) {
        var e = this;
        if (a.updateCheck(function() {}, function() {
            e.setData({
                grayLevel: !1
            });
        }), t && 1 == t.share) return wx.navigateTo({
            url: "/pages/findDetail/findDetail?id=" + t.id
        }), void (e.data.firstLoading = 0);
        this.initPage(t), this.setData({
            token: wx.getStorageSync("hq_token")
        });
    },
    onShow: function(a) {
        0 == this.data.firstLoading && (this.data.pageNo = 1, this.initPage(a));
    },
    btmBarCreateFormId: function(a) {
        e.btmBarCreateFormId(a);
    },
    createFormId: function(a) {
        wx.navigateTo({
            url: "/pages/findDetail/findDetail?id=".concat(a.currentTarget.dataset.id, "&gid=").concat(this.data.qid, "&gname=").concat(this.data.qname)
        });
    },
    initPage: function(t) {
        var e = wx.getStorageSync("categoryInfo"), i = wx.getStorageSync("findInfo");
        t.gid && t.gname && (e = {
            gid: t.gid,
            gname: decodeURIComponent(t.gname)
        }, wx.setStorageSync("categoryInfo", e)), e ? (this.data.categoryName = e.gname || "", 
        this.data.categoryId = e.gid || "", this.getWedId(), a.fixIPhone(this), t && t.qid ? (this.data.qid = t.qid, 
        this.data.qname = t.qname) : (this.data.qid = i.qid ? i.qid : e.gid, this.data.qname = i.qname ? i.qname : e.gname), 
        this.setData({
            qname: this.data.qname
        }), this.getListData()) : wx.redirectTo({
            url: "/pages/exam/exam?sourcePath=/pages/findList/findList"
        });
    },
    getListData: function(a) {
        var e = this, n = "", s = "", o = this.data.pageNo, d = this.data.listData, g = !(!a || "scrolltolower" != a.type), c = [];
        g && e.data.done || this.data.isLoading || (this.data.isLoading = !0, 0 == this.data.tabType ? s = 0 : 1 == this.data.tabType && (s = e.data.qid), 
        this.data.isLoading = !1, t.showLoading({
            title: "加载中……",
            mask: "true"
        }), wx.request({
            url: i.host + "/wxapp/v1/banner/lists",
            data: {
                category_id: s,
                page: o,
                org_id: i.orgId
            },
            success: function(a) {
                0 == a.data.status.code ? ((n = a.data.data) && n.length > 0 ? (n.forEach(function(a, e) {
                    c = [], a.tags && (c = a.tags.split(",")), a.tagsArray = c, a.cover = t.replaceOss(a.cover);
                }), 1 == e.data.initLoading ? (e.data.initLoading = 0, e.data.pageNo++, d = d.concat(n)) : g ? (e.data.pageNo++, 
                d = d.concat(n)) : (e.data.pageNo = 1, d = n, e.data.done = !0), e.setData({
                    listData: d
                }), e.data.isLoading = !1, t.hideLoading()) : g ? (e.data.done = !0, e.data.isLoading = !1) : e.setData({
                    isEmpty: !0
                }), t.hideLoading()) : (t.hideLoading(), e.setData({
                    isEmpty: !0
                }), e.data.isLoading = !1);
            },
            fail: function(a) {
                t.hideLoading();
            }
        }));
    },
    chooseTab: function(a) {
        this.data.tabType = a.currentTarget.dataset.tab, this.data.initLoading = 1, this.data.pageNo = 1, 
        this.data.done = !1, this.data.listData = [], this.setData({
            listData: this.data.listData,
            tabType: this.data.tabType,
            isEmpty: !1
        }), this.getListData();
    },
    getWedId: function() {
        var a = this;
        wx.getStorage({
            key: "webIdInfo",
            success: function(t) {
                a.data.webIdInfo = t.data || {};
            },
            fail: function(t) {
                a.data.webIdInfo = {};
            }
        });
    },
    requestSubscribeMessage: function() {
        wx.canIUse("requestSubscribeMessage") ? wx.requestSubscribeMessage({
            tmplIds: [ "Rh-Dsy95SuCDOQ4XePNFqX31GD-CKAM39pc9fW9OUjk" ],
            success: function(t) {
                if ("requestSubscribeMessage:ok" == t.errMsg) if ("accept" == t["Rh-Dsy95SuCDOQ4XePNFqX31GD-CKAM39pc9fW9OUjk"]) {
                    var e = {
                        "Rh-Dsy95SuCDOQ4XePNFqX31GD-CKAM39pc9fW9OUjk": t["Rh-Dsy95SuCDOQ4XePNFqX31GD-CKAM39pc9fW9OUjk"]
                    };
                    a.addSubscribeMsg(e, function() {
                        "function" == typeof callback && callback();
                    });
                } else wx.showToast({
                    title: "订阅失败",
                    icon: "none"
                });
            }
        }) : wx.showModal({
            title: "提示",
            content: "当前微信版本过低，无法使用该功能，请升级到最新微信版本后重试。",
            showCancel: !1
        });
    },
    getPhoneNumberCB: function(a) {
        console.log(a), this.data.detailId = a.currentTarget.dataset.id, "getPhoneNumber:ok" == a.detail.errMsg ? console.log(this.selectComponent("#quick-login-fn").$vm.wxMobRegister(a)) : wx.showToast({
            title: "授权才能查看哦~",
            icon: "none"
        });
    },
    loginSuc: function() {
        this.setData({
            token: wx.getStorageSync("hq_token")
        }), this.data.detailId && wx.navigateTo({
            url: "/pages/findDetail/findDetail?id=" + this.data.detailId
        }), console.log("登录成功~");
    },
    stopPropagation: function() {},
    onShareAppMessage: function(t) {
        t.from;
        var e = "/pages/findList/findList", i = "menu" == t.from ? "右上角分享" : "分享按钮";
        return a.appShare({
            belongPage: "发现列表页",
            shareContentID: this.data.categoryId,
            shareButton: i,
            shareContent: this.data.categoryName
        }), e = "".concat(e).concat(a.globalData.uuid ? "?shareId=" + a.globalData.uuid : ""), 
        console.log(9999, e), {
            title: this.data.categoryName + "这些考试资讯，你不能错过！",
            path: e,
            imageUrl: "https://oss-hqwx-edu24ol.hqwx.com/miniapp/hq_mall/share/find_list.png",
            success: function(a) {},
            complete: function() {}
        };
    }
});