var e = getApp(), t = require("../../utils/util"), a = require("../../configs/baseConfig"), o = require("../../configs/config_" + a.appName);

Page({
    data: {
        phone: "",
        code: "",
        password: "",
        isShowWarn: !1,
        warnText: "",
        checked: "icon-checked",
        passwordType: "password",
        typeClass: "icon-ege-dis",
        sendText: "发送验证码",
        canSendCode: !0,
        passwordFocus: !1
    },
    onLoad: function(a) {
        console.log("page register onLoad", a);
        var o = this;
        o.data.firstPType = t.getUrlParams().firstPType || "", e.setWebIdToStorage(a.web_id), 
        wx.getStorage({
            key: "webIdInfo",
            success: function(e) {
                o.data.webIdInfo = e.data || {};
            },
            fail: function(e) {
                o.data.webIdInfo = {};
            }
        }), wx.getStorageSync("categoryInfoShortID") && wx.getStorageSync("categoryInfoShortID").gid ? o.data.categoryInfo = wx.getStorageSync("categoryInfoShortID") || {} : wx.getStorage({
            key: "categoryInfo",
            success: function(e) {
                o.data.categoryInfo = e.data || {};
            },
            fail: function(e) {
                console.log("getStorage categoryInfo err", e), o.data.categoryInfo = {};
            }
        });
    },
    hideWarn: function() {
        var e = this;
        setTimeout(function() {
            e.setData({
                isShowWarn: !1
            });
        }, 2e3);
    },
    showWarn: function(e) {
        this.setData({
            warnText: e,
            isShowWarn: !0
        }), this.hideWarn();
    },
    bindPhoneInput: function(e) {
        this.data.phone = e.detail.value;
    },
    bindCodeInput: function(e) {
        this.data.code = e.detail.value;
    },
    bindPasswordInput: function(e) {
        this.data.password = e.detail.value;
    },
    bindPhoneBlur: function(e) {
        this.setData({
            phone: e.detail.value
        });
    },
    bindCodeBlur: function(e) {
        this.setData({
            code: e.detail.value
        });
    },
    bindPasswordBlur: function(e) {
        this.setData({
            password: e.detail.value
        });
    },
    changeType: function() {
        "password" == this.data.passwordType ? this.setData({
            passwordType: "text",
            typeClass: "",
            passwordFocus: !0
        }) : this.setData({
            passwordType: "password",
            typeClass: "icon-ege-dis",
            passwordFocus: !0
        });
    },
    submitRegister: function() {
        var n = this, s = "/pages/user/user?source=register";
        if (t.isPhone(n.data.phone)) if ("" != n.data.code) if (t.isPassword(n.data.password)) if ("" != n.data.checked) {
            t.showLoading({
                title: "加载中...",
                mask: !0
            }), t.reportEvent(e, "clickRegisterButton", {});
            var r = wx.getStorageSync("regUrlObj"), d = r ? r.regUrl : "", i = wx.getStorageSync("zhuliLogin") ? null : n.data.categoryInfo.gid, c = wx.getStorageSync("zhuliLogin") ? 424 : o.srcType, p = wx.getStorageSync("regtype") || "", g = e.setExtProperties();
            wx.request({
                url: a.host + "/wxapp/v1/user/register",
                method: "POST",
                data: {
                    platform: a.platform,
                    appid: o.appid,
                    org_id: a.orgId,
                    encryptedData: encodeURIComponent(e.globalData.appBaseInfo.encryptedData),
                    code: encodeURIComponent(e.globalData.code),
                    iv: encodeURIComponent(e.globalData.appBaseInfo.iv),
                    sessionKey: encodeURIComponent(wx.getStorageSync("sessionKey")),
                    thirdLogin: o.thirdLogin || "",
                    thirdMp: o.thirdMp || "",
                    srcType: c,
                    firstPType: n.data.firstPType || o.firstPType,
                    lastPType: o.lastPType,
                    phone: n.data.phone,
                    smsCode: n.data.code,
                    pwd: n.data.password,
                    chId: n.data.webIdInfo.web_id || null,
                    sortId: i || null,
                    regUrl: d,
                    regtype: p,
                    groupId: wx.getStorageSync("trainingGroupId") || "",
                    extProperties: g
                },
                header: {
                    "content-type": "application/x-www-form-urlencoded"
                },
                success: function(o) {
                    0 == o.data.status.code ? (t.userBindReport(e, o.data.data.uid), wx.getStorageSync("zhuliReg") && (wx.removeStorageSync("zhuliReg"), 
                    wx.setStorageSync("loginReg", 1)), wx.setStorageSync("hqUserInfo", o.data.data), 
                    wx.setStorageSync(a.tokenKey, o.data.data.token), wx.removeStorageSync("zhuliLogin"), 
                    wx.removeStorageSync("regtype"), 0 === n.data.source && (s = "/pages/index/index"), 
                    wx.redirectTo({
                        url: s
                    })) : n.showWarn(o.data.status.msg), t.hideLoading();
                },
                fail: function(e) {
                    n.showWarn(e), t.hideLoading();
                }
            });
        } else n.showWarn("阅读并同意《环球网校注册协议》"); else n.showWarn("密码为4-18位(数字，字母，下划线)"); else n.showWarn("验证码不能为空"); else n.showWarn("手机号码格式不正确");
    },
    sendCode: function() {
        var n = this;
        if (0 != this.data.canSendCode) {
            if (!t.isPhone(this.data.phone)) return this.setData({
                warnText: "手机号码格式不正确",
                isShowWarn: !0
            }), void this.hideWarn();
            t.reportEvent(e, "getSMSCode", {
                serviceType: "注册"
            }), t.showLoading({
                title: "加载中",
                mask: !0
            }), e.getUserInfo(function() {
                wx.request({
                    url: a.host + "/wxapp/v1/user/sms",
                    method: "POST",
                    data: {
                        platform: a.platform,
                        appid: o.appid,
                        org_id: a.orgId,
                        encryptedData: encodeURIComponent(e.globalData.appBaseInfo.encryptedData),
                        code: encodeURIComponent(e.globalData.code),
                        iv: encodeURIComponent(e.globalData.appBaseInfo.iv),
                        sessionKey: encodeURIComponent(wx.getStorageSync("sessionKey")),
                        thirdLogin: o.thirdLogin || "",
                        thirdMp: o.thirdMp || "",
                        phone: n.data.phone,
                        optStr: "register",
                        distinct_id: o.sdid
                    },
                    header: {
                        "content-type": "application/x-www-form-urlencoded"
                    },
                    success: function(e) {
                        if (t.hideLoading(), 0 == e.data.status.code) {
                            var a = 60;
                            n.setData({
                                sendText: a + "s",
                                canSendCode: !1
                            });
                            var o = setInterval(function() {
                                a--, n.setData({
                                    sendText: a + "s"
                                }), 0 == a && (clearInterval(o), n.setData({
                                    sendText: "重新发送",
                                    canSendCode: !0
                                }));
                            }, 1e3);
                        } else n.showWarn(e.data.status.msg);
                    }
                });
            });
        }
    },
    isAgree: function() {
        "" == this.data.checked ? this.setData({
            checked: "icon-checked"
        }) : this.setData({
            checked: ""
        });
    }
});