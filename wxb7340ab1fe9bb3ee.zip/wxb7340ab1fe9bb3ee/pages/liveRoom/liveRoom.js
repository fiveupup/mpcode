var e = getApp(), o = require("../../utils/util"), a = (require("../template/template"), 
require("../../configs/baseConfig")), t = require("../../configs/config_" + a.appName);

Page({
    data: {
        isIPhoneX: !1,
        liveRoomInfo: {},
        homeTop: "48rpx"
    },
    onLoad: function(o) {
        var t = this;
        t.data.id = o.id || "", console.log("id", t.data.id);
        var i = wx.getMenuButtonBoundingClientRect();
        t.setData({
            homeTop: i.top + "px"
        }), t.data.token = wx.getStorageSync(a.tokenKey) || "", t.data.hqUserInfo = wx.getStorageSync("hqUserInfo"), 
        t.data.hqUserInfo && (t.data.hqUid = t.data.hqUserInfo.uid), e.getUserInfo(function(e) {
            t.profile();
        }, this), e.fixIPhone(this), e.setWebIdToStorage(o.web_id || ""), t.data.webId = (wx.getStorageSync("webIdInfo") || {}).web_id || null, 
        t.data.categoryInfo = wx.getStorageSync("categoryInfo") || {}, t.getLiveRoomInfo();
    },
    goLive: function() {
        this.data.token ? (this.liveReport(), wx.navigateTo({
            url: "plugin-private://wx2b03c6e691cd7370/pages/live-player-plugin?room_id=" + this.data.roomId
        })) : this.goLogin();
    },
    liveReport: function() {
        var i = this;
        e.globalData.liveReportTimer && clearInterval(e.globalData.liveReportTimer);
        var n = function() {
            wx.request({
                url: "https://edu24ol-io.98809.com/mobile/v1/live/streaminfo",
                data: {
                    _appid: t.appid,
                    _os: o.checkOS(),
                    _v: "1.0.1",
                    _org_id: a.orgId,
                    sid: i.data.liveRoomInfo.sid,
                    ssid: i.data.liveRoomInfo.ssid,
                    _t: new Date().getTime(),
                    _terminalid: 2 == o.checkOS() ? 400 : 401,
                    lessonid: i.data.liveRoomInfo.lesson_id,
                    yyuid: 0,
                    hquid: i.data.hqUid,
                    access_url: "pages/liveRoom/liveRoom?id=" + i.data.id,
                    extra: JSON.stringify({
                        wxnick: e.globalData.appBaseInfo.userInfo.nickName,
                        courseid: i.data.liveRoomInfo.course_id
                    })
                },
                success: function(e) {
                    console.log("liveReport success");
                }
            });
        };
        n(), e.globalData.liveReportTimer = setInterval(function() {
            n();
        }, 12e4);
    },
    profile: function() {
        var i = this;
        wx.request({
            url: a.host + "/wxapp/v1/user/profile",
            method: "POST",
            dataType: "json",
            header: {
                "content-type": "application/x-www-form-urlencoded"
            },
            data: {
                appid: t.appid,
                org_id: a.orgId,
                platform: a.platform,
                encryptedData: encodeURIComponent(e.globalData.appBaseInfo.encryptedData),
                code: encodeURIComponent(e.globalData.code),
                iv: encodeURIComponent(e.globalData.appBaseInfo.iv),
                distinct_id: t.sdid
            },
            success: function(e) {
                0 == e.data.status.code && (wx.setStorage({
                    key: "hqUserInfo",
                    data: e.data.data
                }), i.data.hqUid = e.data.data.uid, wx.setStorage({
                    key: a.tokenTimeStamp,
                    data: o.timeStamp()
                }), wx.setStorage({
                    key: a.tokenKey,
                    data: e.data.data.token
                }));
            }
        });
    },
    goLogin: function() {
        wx.redirectTo({
            url: "/pages/login/login?from=" + encodeURIComponent("/pages/liveRoom/liveRoom?id=" + this.data.id)
        });
    },
    getUserInfoData: function(o) {
        var a = this;
        e.getUserInfo(function(e) {
            a.profile();
        }, this);
    },
    getLiveRoomInfo: function() {
        var e = this;
        o.showLoading({
            title: "加载中...",
            mask: !0
        }), wx.request({
            url: a.host + "/wxapp/v1/live/getLiveRoomInfo",
            data: {
                _appid: t.appid,
                _os: o.checkOS(),
                _v: t.version,
                org_id: a.orgId,
                _t: o.timeStamp(),
                id: e.data.id
            },
            success: function(o) {
                0 == o.data.status.code && e.setData({
                    liveRoomInfo: o.data.data,
                    roomId: Number(o.data.data.room_id)
                });
            },
            complete: function() {
                o.hideLoading();
            }
        });
    },
    onShareAppMessage: function(o) {
        return {
            title: e.globalData.appBaseInfo.userInfo.nickName + "邀请你进入直播间",
            path: "/pages/liveRoom/liveRoom?id=" + this.data.id,
            success: function(e) {},
            complete: function() {}
        };
    }
});