require("../../@babel/runtime/helpers/Arrayincludes"), require("../../uni-bootstrap.js"), 
(global.webpackJsonp = global.webpackJsonp || []).push([ [ "pages/paySuccess/paySuccess" ], {
    68: function(n, e, t) {
        (function(n) {
            t(4);
            e(t(2));
            function e(n) {
                return n && n.__esModule ? n : {
                    default: n
                };
            }
            n(e(t(69)).default);
        }).call(this, t(1).createPage);
    },
    69: function(n, e, t) {
        t.r(e);
        var r = t(70), o = t(72);
        for (var u in o) "default" !== u && function(n) {
            t.d(e, n, function() {
                return o[n];
            });
        }(u);
        t(74);
        var i = t(10), a = Object(i.default)(o.default, r.render, r.staticRenderFns, !1, null, null, null, !1, r.components, void 0);
        a.options.__file = "pages/paySuccess/paySuccess.vue", e.default = a.exports;
    },
    70: function(n, e, t) {
        t.r(e);
        var r = t(71);
        t.d(e, "render", function() {
            return r.render;
        }), t.d(e, "staticRenderFns", function() {
            return r.staticRenderFns;
        }), t.d(e, "recyclableRender", function() {
            return r.recyclableRender;
        }), t.d(e, "components", function() {
            return r.components;
        });
    },
    71: function(n, e, t) {
        t.r(e), t.d(e, "render", function() {
            return o;
        }), t.d(e, "staticRenderFns", function() {
            return i;
        }), t.d(e, "recyclableRender", function() {
            return u;
        }), t.d(e, "components", function() {
            return r;
        });
        var r = {
            cQuickLoginFn: function() {
                return Promise.all([ t.e("common/vendor"), t.e("components/c-quick-login-fn/c-quick-login-fn") ]).then(t.bind(null, 360));
            }
        }, o = function() {
            var n = this.$createElement, e = (this._self._c, {
                gid: this.options.gid,
                pageName: "支付成功页",
                resource: 1,
                resourceIds: this.options.goodsId,
                ruleType: 1,
                terminalPage: 22,
                buyorderId: this.options.buyOrderId
            });
            this.$mp.data = Object.assign({}, {
                $root: {
                    a0: e
                }
            });
        }, u = !1, i = [];
        o._withStripped = !0;
    },
    72: function(n, e, t) {
        t.r(e);
        var r = t(73), o = t.n(r);
        for (var u in r) "default" !== u && function(n) {
            t.d(e, n, function() {
                return r[n];
            });
        }(u);
        e.default = o.a;
    },
    73: function(n, e, t) {
        (function(n) {
            Object.defineProperty(e, "__esModule", {
                value: !0
            }), e.default = void 0;
            var r, o = (r = t(20)) && r.__esModule ? r : {
                default: r
            };
            var u = {
                data: function() {
                    return {
                        options: {}
                    };
                },
                onLoad: function(n) {
                    this.options = n;
                },
                onShow: function() {},
                methods: {
                    handle: function() {
                        var e = "/pages/myCourse/myCourse";
                        this.options.num && (e = "/packageUser/pages/myOrder/myOrder"), this.options.num || "wxapp" != o.default.platform || ![ "hqwxmall_wxapp" ].includes(o.default.appid) ? n.redirectTo({
                            url: e
                        }) : n.navigateToMiniProgram({
                            appId: "wx890b8e807c46f703",
                            path: "/pages/myCourse/myCourse"
                        });
                    }
                }
            };
            e.default = u;
        }).call(this, t(1).default);
    },
    74: function(n, e, t) {
        t.r(e);
        var r = t(75), o = t.n(r);
        for (var u in r) "default" !== u && function(n) {
            t.d(e, n, function() {
                return r[n];
            });
        }(u);
        e.default = o.a;
    },
    75: function(n, e, t) {}
}, [ [ 68, "common/runtime", "common/vendor" ] ] ]);