require("../../uni-bootstrap.js"), (global.webpackJsonp = global.webpackJsonp || []).push([ [ "pages/questionnaire/questionnaire" ], {
    132: function(t, n, e) {
        (function(t) {
            e(4);
            n(e(2));
            function n(t) {
                return t && t.__esModule ? t : {
                    default: t
                };
            }
            t(n(e(133)).default);
        }).call(this, e(1).createPage);
    },
    133: function(t, n, e) {
        e.r(n);
        var o = e(134), a = e(136);
        for (var i in a) "default" !== i && function(t) {
            e.d(n, t, function() {
                return a[t];
            });
        }(i);
        e(138);
        var r = e(10), s = Object(r.default)(a.default, o.render, o.staticRenderFns, !1, null, null, null, !1, o.components, void 0);
        s.options.__file = "pages/questionnaire/questionnaire.vue", n.default = s.exports;
    },
    134: function(t, n, e) {
        e.r(n);
        var o = e(135);
        e.d(n, "render", function() {
            return o.render;
        }), e.d(n, "staticRenderFns", function() {
            return o.staticRenderFns;
        }), e.d(n, "recyclableRender", function() {
            return o.recyclableRender;
        }), e.d(n, "components", function() {
            return o.components;
        });
    },
    135: function(t, n, e) {
        e.r(n), e.d(n, "render", function() {
            return o;
        }), e.d(n, "staticRenderFns", function() {
            return i;
        }), e.d(n, "recyclableRender", function() {
            return a;
        }), e.d(n, "components", function() {});
        var o = function() {
            var t = this.$createElement;
            this._self._c;
        }, a = !1, i = [];
        o._withStripped = !0;
    },
    136: function(t, n, e) {
        e.r(n);
        var o = e(137), a = e.n(o);
        for (var i in o) "default" !== i && function(t) {
            e.d(n, t, function() {
                return o[t];
            });
        }(i);
        n.default = a.a;
    },
    137: function(t, n, e) {
        (function(t) {
            Object.defineProperty(n, "__esModule", {
                value: !0
            }), n.default = void 0;
            var o = e(22), a = getApp(), i = {
                data: function() {
                    return {
                        showSubmitBtn: !1,
                        canSubmit: !1,
                        questionData: []
                    };
                },
                computed: {},
                onLoad: function(t) {
                    this.getQuestions();
                },
                methods: {
                    getQuestions: function() {
                        var n = this;
                        t.showLoading(), this.$hq.get("/crm/v1/questionnaire/getQuestion", {}).then(function(e) {
                            if (0 == e.data.status.code) {
                                var o = e.data.data;
                                o.length > 0 && o.forEach(function(t, n) {
                                    var e = [];
                                    t.hasAnswer = !1, t.showMore = !1, t.answerCount = 0, t.answer.forEach(function(t, n) {
                                        e.push({
                                            id: n + 1,
                                            value: t,
                                            selected: !1
                                        });
                                    }), t.options = e, t.answer = [], t.btnState = !1, t.type = t.multiple ? 0 : 1;
                                }), n.questionData = o;
                            }
                            t.hideLoading();
                        });
                    },
                    showOptionsMore: function(t) {
                        var n = t.currentTarget.dataset;
                        this.questionData.forEach(function(t, e) {
                            n.index == e && (t.showMore = !0);
                        });
                    },
                    confirm: function(t) {
                        var n = t.currentTarget.dataset, e = this.questionData, o = [];
                        n.state && (e.forEach(function(t, e) {
                            n.index == e && (t.options.forEach(function(t, n) {
                                t.selected && o.push(t);
                            }), t.hasAnswer = !0, t.answer = o, t.showMore = !1);
                        }), this.checkSubmitBtnState());
                    },
                    reChoice: function(t) {
                        var n = t.currentTarget.dataset;
                        this.questionData.forEach(function(t, e) {
                            n.index == e && (t.answer = [], t.hasAnswer = !1, t.answerCount = 0, t.options.forEach(function(t, n) {
                                t.selected = !1;
                            }));
                        }), this.checkSubmitBtnState();
                    },
                    chooseOption: function(t) {
                        0 == t.currentTarget.dataset.type ? this.multipleChoice(t) : this.singleChoice(t);
                    },
                    multipleChoice: function(t) {
                        var n = t.currentTarget.dataset, e = this.questionData, o = 0;
                        e.forEach(function(t, e) {
                            e == n.index && (o = t.answerCount, t.options.forEach(function(e, a) {
                                a == n.i && (e.selected = !e.selected, e.selected ? (t.btnState = !0, o++, t.showMore || (t.showMore = !0)) : o--, 
                                0 == o && (t.btnState = !1), t.answerCount = o);
                            }));
                        }), this.questionData = e;
                    },
                    singleChoice: function(t) {
                        var n = t.currentTarget.dataset, e = this.questionData, o = 0, a = [];
                        e.forEach(function(t, e) {
                            n.index == e && t.options.forEach(function(e, i) {
                                i == n.i ? (e.selected = !e.selected, e.selected ? (o++, t.hasAnswer = !0, a.push(e)) : (a = [], 
                                t.hasAnswer = !1, o--), t.answer = a, t.answerCount = o) : e.selected = !1;
                            });
                        }), this.questionData = e, this.checkSubmitBtnState();
                    },
                    checkSubmitBtnState: function() {
                        var t = this.questionData, n = !0;
                        t.forEach(function(t, e) {
                            t.hasAnswer || (n = !1);
                        }), this.showSubmitBtn = n;
                    },
                    submit: function() {
                        var n = this;
                        if (!this.canSubmit) {
                            this.canSubmit = !0;
                            var e = [], o = this.questionData;
                            if (!t.getStorageSync("hq_token")) return t.setStorageSync("questionData", this.questionData), 
                            void t.redirectTo({
                                url: "/pages/login/login?sourcePath=/pages/questionnaire/questionnaire" + encodeURIComponent("?autoSubmit=1")
                            });
                            t.showLoading();
                            var a = [];
                            o.forEach(function(t, n) {
                                var o = {}, i = [], r = [];
                                o.question = n, t.answer.forEach(function(t, n) {
                                    t.selected && (i.push(t.id - 1), r.push(t.value));
                                }), o.answer = i, a.push(r), e.push(o);
                            }), this.reportEvent({
                                focusAreas: a[0].join(","),
                                workBelongIndustry: a[1].join(",")
                            }), this.$hq.get("/crm/v1/questionnaire/batchSave", {
                                edu24ol_token: t.getStorageSync("hq_token"),
                                answer: JSON.stringify(e)
                            }).then(function(e) {
                                t.hideLoading(), n.canSubmit = !1, 0 == e.data.status.code ? t.redirectTo({
                                    url: "/pages/addCode/addCode"
                                }) : t.showToast({
                                    icon: "none",
                                    title: e.data.status.msg
                                });
                            });
                        }
                    },
                    reportEvent: function(t) {
                        (0, o.reportEvent)(a, "MPpowerAnswer", {
                            focusAreas: t.focusAreas,
                            workBelongIndustry: t.workBelongIndustry
                        });
                    }
                }
            };
            n.default = i;
        }).call(this, e(1).default);
    },
    138: function(t, n, e) {
        e.r(n);
        var o = e(139), a = e.n(o);
        for (var i in o) "default" !== i && function(t) {
            e.d(n, t, function() {
                return o[t];
            });
        }(i);
        n.default = a.a;
    },
    139: function(t, n, e) {}
}, [ [ 132, "common/runtime", "common/vendor" ] ] ]);