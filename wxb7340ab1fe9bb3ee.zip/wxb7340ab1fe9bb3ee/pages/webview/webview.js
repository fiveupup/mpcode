getApp(), require("../../utils/util");

var e = require("../../configs/baseConfig");

require("../../configs/config_" + e.appName);

Page({
    data: {
        url: ""
    },
    onLoad: function(e) {
        e.url && this.setData({
            url: decodeURIComponent(e.url)
        });
    },
    onShareAppMessage: function(e) {
        e.from;
        var t = "/pages/findDetail/findDetail?id=" + this.data.id + "&share=1";
        return {
            title: this.data.title,
            path: t,
            imageUrl: "",
            success: function(e) {},
            complete: function() {}
        };
    }
});