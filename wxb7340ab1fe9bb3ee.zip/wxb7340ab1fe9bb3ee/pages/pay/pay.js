require("../../@babel/runtime/helpers/Arrayincludes"), require("../../uni-bootstrap.js"), 
(global.webpackJsonp = global.webpackJsonp || []).push([ [ "pages/pay/pay" ], {
    60: function(e, o, t) {
        (function(e) {
            t(4);
            o(t(2));
            function o(e) {
                return e && e.__esModule ? e : {
                    default: e
                };
            }
            e(o(t(61)).default);
        }).call(this, t(1).createPage);
    },
    61: function(e, o, t) {
        t.r(o);
        var r = t(62), n = t(64);
        for (var i in n) "default" !== i && function(e) {
            t.d(o, e, function() {
                return n[e];
            });
        }(i);
        t(66);
        var a = t(10), d = Object(a.default)(n.default, r.render, r.staticRenderFns, !1, null, null, null, !1, r.components, void 0);
        d.options.__file = "pages/pay/pay.vue", o.default = d.exports;
    },
    62: function(e, o, t) {
        t.r(o);
        var r = t(63);
        t.d(o, "render", function() {
            return r.render;
        }), t.d(o, "staticRenderFns", function() {
            return r.staticRenderFns;
        }), t.d(o, "recyclableRender", function() {
            return r.recyclableRender;
        }), t.d(o, "components", function() {
            return r.components;
        });
    },
    63: function(e, o, t) {
        t.r(o), t.d(o, "render", function() {
            return r;
        }), t.d(o, "staticRenderFns", function() {
            return i;
        }), t.d(o, "recyclableRender", function() {
            return n;
        }), t.d(o, "components", function() {});
        var r = function() {
            var e = this.$createElement;
            this._self._c;
        }, n = !1, i = [];
        r._withStripped = !0;
    },
    64: function(e, o, t) {
        t.r(o);
        var r = t(65), n = t.n(r);
        for (var i in r) "default" !== i && function(e) {
            t.d(o, e, function() {
                return r[e];
            });
        }(i);
        o.default = n.a;
    },
    65: function(e, o, t) {
        (function(e) {
            Object.defineProperty(o, "__esModule", {
                value: !0
            }), o.default = void 0;
            var r, n = (r = t(20)) && r.__esModule ? r : {
                default: r
            }, i = t(21);
            var a = {
                data: function() {
                    return {
                        options: {},
                        payType: 0,
                        isSubmit: !1,
                        isUseFqWithAutoAuth: !0,
                        priceInfo: {
                            averagePrice: 0,
                            surplusPrice: 0
                        },
                        orderInfo: {},
                        isLoading: !0,
                        deliveryId: "",
                        delivery: "",
                        goodsId: "",
                        productIsTraining: !1
                    };
                },
                onLoad: function(o) {
                    var t = this;
                    this.options = o, o.deliveryId && (this.delivery = o.delivery, this.deliveryId = o.deliveryId, 
                    this.goodsId = o.goodsId), e.getStorageSync("hqUserInfo").wxOpenId ? (e.showLoading({
                        title: "加载中..."
                    }), this.getOrderInfo()) : (0, i.profile)(function() {
                        t.getOrderInfo();
                    }), this.payType = 1;
                },
                onShow: function() {},
                methods: {
                    choose: function(o) {
                        3 != o || this.isUseFqWithAutoAuth ? this.payType = o : e.showToast({
                            icon: "none",
                            title: "抱歉，您的支付宝账户暂不支持月月付方式"
                        });
                    },
                    requestPayment: function() {
                        var o = this;
                        if (!this.isLoading) if (0 != this.payType) {
                            if (!this.isSubmit) {
                                this.isSubmit = !0;
                                var t = {
                                    ordercode: this.options.ordercode,
                                    payType: this.payType,
                                    orderId: this.orderInfo.id
                                };
                                this.groupInfo && (t.courseId = this.groupInfo.id), e.showLoading({
                                    title: "加载中..."
                                }), (0, i.requestPayment)(t, function(t) {
                                    if (o.isSubmit = !1, o.delivery) e.navigateTo({
                                        url: "/pages/deliveryResult/deliveryResult?deliveryId=".concat(o.deliveryId, "&goodsId=").concat(o.goodsId)
                                    }); else if (o.productIsTraining) e.redirectTo({
                                        url: "/subpackages/pages/trainingSuccess/trainingSuccess?groupId=".concat(o.options.groupid, "&orderId=").concat(o.orderInfo.id)
                                    }); else {
                                        o.rPaySuccess(o.orderInfo.id), (0, i.actionSourceSave)(o.orderInfo.id, 2);
                                        var r = "/pages/paySuccess/paySuccess?groupid=".concat(o.options.groupid, "&gid=").concat(o.options.gid, "&goodsId=").concat(o.options.goodsId, "&buyOrderId=").concat(o.options.buyOrderId);
                                        if (2 == o.groupInfo.courseType) {
                                            var n = o.orderInfo.buyOrderDetailList[0].amount;
                                            r += "&num=".concat(n);
                                        }
                                        console.log(999, "222paySuccess", r), e.redirectTo({
                                            url: r
                                        });
                                    }
                                }, function(t) {
                                    if (o.isSubmit = !1, "pay" == t.errorType) {
                                        e.showToast({
                                            title: "已取消支付",
                                            icon: "none"
                                        });
                                    }
                                });
                            }
                        } else e.showToast({
                            title: "请选择支付方式",
                            icon: !1
                        });
                    },
                    rPaySuccess: function(e) {
                        this.$hq.get("".concat(n.default.hostJAPI, "/buy/pay/rPaySuccess"), {
                            id: e,
                            edu24ol_token: 1,
                            terminalType: n.default.terminalType
                        }).then(function(e) {
                            console.log(e);
                        });
                    },
                    getOrderInfo: function() {
                        var o = this, t = {
                            edu24ol_token: !0,
                            orderCode: this.options.ordercode
                        };
                        this.$hq.get("".concat(n.default.hostJAPI, "/buy/order/orderInfo"), t).then(function(t) {
                            e.hideLoading();
                            var r = !1, n = {}, a = [];
                            if ([ 0, 10003 ].includes(t.data.status.code)) {
                                var d = t.data.data.orderInfo, s = t.data.data.groupInfo;
                                d && d.buyOrderDetailList && d.buyOrderDetailList.length > 0 && d.buyOrderDetailList.forEach(function(e, o) {
                                    if (a.push(e.goodsId), e.goods) {
                                        if (e.goods.goodsPairsList && e.goods.goodsPairsList.length > 0) e.goods.goodsPairsList.forEach(function(e, o) {
                                            3 == e.goodsCategory && (r = !0);
                                        });
                                        3 == e.goods.goodsCategory && (r = !0);
                                    }
                                }), s && (n = {
                                    goodsID: a.join(","),
                                    secondCategory: s.second_category
                                });
                            }
                            if (o.productIsTraining = r, e.setStorageSync("trainingParams", n), 0 == t.data.status.code && t.data.data && t.data.data.orderInfo) {
                                var c = t.data.data.orderInfo;
                                c.price = Math.floor((100 * c.oriMoney - 100 * c.payed - 100 * c.discMoney) / 100), 
                                o.priceInfo.averagePrice = (c.price / 10).toFixed(2), o.priceInfo.surplusPrice = (9 * o.priceInfo.averagePrice).toFixed(2), 
                                o.orderInfo = c, o.isLoading = !1, o.groupInfo = t.data.data.groupInfo, o.requestPayment();
                            } else if (10003 == t.data.status.code) {
                                if (o.delivery) return void e.navigateTo({
                                    url: "/pages/deliveryResult/deliveryResult?deliveryId=".concat(o.deliveryId, "&goodsId=").concat(o.goodsId)
                                });
                                var u = 0 == t.data.data.orderInfo.money ? 3 : 2;
                                if ((0, i.actionSourceSave)(t.data.data.orderInfo.id, u), r) e.redirectTo({
                                    url: "/subpackages/pages/trainingSuccess/trainingSuccess?groupId=".concat(o.options.groupid, "&orderId=").concat(t.data.data.orderInfo.id)
                                }); else {
                                    var f = "/pages/paySuccess/paySuccess?groupid=".concat(o.options.groupid, "&gid=").concat(o.options.gid, "&goodsId=").concat(o.options.goodsId, "&buyOrderId=").concat(o.options.buyOrderId);
                                    if (2 == t.data.data.groupInfo.courseType) {
                                        var l = t.data.data.orderInfo.buyOrderDetailList[0].amount;
                                        f += "&num=".concat(l);
                                    }
                                    console.log(999, "111paySuccess", f), e.redirectTo({
                                        url: f
                                    });
                                }
                            } else e.showToast({
                                title: t.data.status.msg,
                                icon: "none"
                            });
                        });
                    }
                }
            };
            o.default = a;
        }).call(this, t(1).default);
    },
    66: function(e, o, t) {
        t.r(o);
        var r = t(67), n = t.n(r);
        for (var i in r) "default" !== i && function(e) {
            t.d(o, e, function() {
                return r[e];
            });
        }(i);
        o.default = n.a;
    },
    67: function(e, o, t) {}
}, [ [ 60, "common/runtime", "common/vendor" ] ] ]);