var a = getApp(), t = require("../../utils/util"), e = require("../template/template"), i = require("../../configs/baseConfig"), s = require("../../configs/config_" + i.appName), o = require("../../utils/request");

Page({
    data: {
        loginCode: 0,
        code: 0,
        mode: null,
        countTime: {
            h: "00",
            m: "00",
            s: "00"
        },
        infoData: [],
        loginURL: "",
        appName: "快题库",
        goodName: "",
        sId: "",
        userInfo: null,
        wxUserInfo: null,
        elseCourseData: null,
        edu24ol_token: "",
        goodId: "",
        zgId: 0,
        consignee_id: "",
        addressNone: 0,
        addressType: "save",
        totaloriRealNum: 0,
        saveAddress: 0,
        initAddress: 0,
        ezuli: 0,
        ezugid: 0,
        isGetCourse: 0,
        tabIndex: 0,
        stateWinRule: !1,
        stateWinSubscribe: !1,
        isSubscribe: 0,
        isShare: 0,
        timer: null,
        zhuliData: [ "助你一臂之力当学霸", "路遇学霸，随手助力", "苟学霸，勿相忘", "拔刀相助，在所不辞", "好好学习，天天向上", "学霸，带我飞吧" ],
        isZhuli: !1,
        isZhuliing: !1,
        activityGid: 0,
        showGiftBag: 0,
        experienceList: [],
        isTotalPriceLessThanThousand: !1
    },
    onLoad: function(e) {
        for (var i in e = a.customDecode(e), this.utmOptions = {}, e) i.indexOf("utm_") > -1 && (this.utmOptions[i] = e[i]);
        console.log("utm:", this.utmOptions);
        wx.hideShareMenu(), t.setUrlParams(e), this.fromOther(e), e.web_id && a.setWebIdToStorage(e.web_id), 
        e.saveAddress && (this.data.saveAddress = 1, this.data.ezugid = e.zug_id), e.zuli && (this.data.ezuli = 1), 
        e.isShare && 1 == e.isShare && (this.data.isShare = 1), e.isZhuli && (this.data.isZhuli = !0), 
        wx.getStorageSync("initAddress") && 1 == wx.getStorageSync("initAddress") && (this.data.initAddress = 1), 
        this.getWedId(), this.data.categoryInfo = wx.getStorageSync("categoryInfo") || {}, 
        e && (decodeURIComponent(e.zug_id) > 0 ? (this.data.argsType = "zug_id", this.data.argsValu = decodeURIComponent(e.zug_id)) : (this.data.argsType = "zg_id", 
        this.data.argsValu = decodeURIComponent(e.zg_id), this.data.uuid = decodeURIComponent(e.uid), 
        "&uid=" + this.data.uuid), this.setData({
            argsType: this.data.argsType,
            argsValu: this.data.argsValu
        }), e.path && e.path), wx.getStorageSync("userInfo") && this.setData({
            wxUserInfo: wx.getStorageSync("userInfo")
        }), this.data.hqUserInfo = wx.getStorageSync("hqUserInfo") || {};
    },
    onShow: function() {
        var t = this;
        this.data.isZhuliing = !1, a.HQTokenStorage(function() {
            t.setData({
                loginCode: 0,
                loginURL: "/pages/login/login?sourcePath=/pages/bargainDetail/bargainDetail" + encodeURIComponent("?path=bargain&" + t.data.argsType + "=" + t.data.argsValu + "&uid=" + t.data.uuid)
            }, function() {
                t.initData();
            });
        }, function() {
            t.setData({
                loginCode: 1
            }), t.data.edu24ol_token = wx.getStorageSync(i.tokenKey) || "", t.data.uid = wx.getStorageSync("hqUserInfo").uid || "", 
            t.data.categoryName = t.data.categoryInfo.gname || "", t.data.categoryId = t.data.categoryInfo.gid || "", 
            t.initData();
        });
    },
    onUnload: function() {
        clearInterval(this.data.timer);
    },
    initData: function() {
        var a = this;
        if (1 == this.data.saveAddress) return t.showToast2("收货信息填写成功"), void (1 == this.data.ezuli && a.getAddressList(function() {
            a.zuligetCourse();
        }));
        wx.showLoading(), this.getUserInfoData();
    },
    fromOther: function(a) {
        void 0 !== a.gid && void 0 !== a.gname && (wx.setStorageSync("categoryInfo", {
            gid: a.gid,
            gname: decodeURIComponent(a.gname)
        }), this.setData({
            categoryInfo: {
                gid: a.gid,
                gname: decodeURIComponent(a.gname)
            }
        }));
    },
    getUserInfoData: function(t) {
        var e = this;
        a.getUserInfo(function() {
            e.getWxUserInfo(function() {
                e.getData();
            });
        }, this);
    },
    getData: function() {
        var e = this, o = {
            appid: s.appid,
            org_id: i.orgId,
            edu24ol_token: wx.getStorageSync(i.tokenKey) || "",
            open_id: e.data.wxUserInfo.openId
        }, d = 0;
        "zg_id" == e.data.argsType && (o.uid = e.data.uuid), o[e.data.argsType] = e.data.argsValu, 
        wx.request({
            url: i.host + "/wxapp/activity/zuli/shareInfo",
            data: o,
            success: function(i) {
                if (0 == i.data.status.code) {
                    if (d = 0, null != i.data.data.share_user ? e.setData({
                        userInfo: i.data.data.share_user
                    }) : (e.data.wxUserInfo.avator = e.data.wxUserInfo.avatarUrl, e.setData({
                        userInfo: e.data.wxUserInfo
                    })), e.setData({
                        appName: i.data.data.activity.app_name || "快题库"
                    }), e.data.goodName = i.data.data.activity.good_name, e.data.sId = i.data.data.activity.second_category, 
                    e.data.goodId = i.data.data.activity.good_id, e.data.totaloriRealNum = i.data.data.share_activity.totaloriRealNum, 
                    e.data.ezugid = i.data.data.share_activity.zug_id || 0, e.data.zgId = i.data.data.activity.id, 
                    e.data.ezugid && e.setUpdateShareMenu(e.data.ezugid), 0 == i.data.data.share_activity.is_self) {
                        var s = "bargain_".concat(i.data.data.share_activity.zug_id), o = "";
                        wx.getStorageSync(s) ? o = wx.getStorageSync(s) : (o = "/images/avatar/" + a.random(1, 12) + ".png", 
                        wx.setStorageSync(s, o)), i.data.data.share_user.logo = o, i.data.data.share_user.name = i.data.data.share_user.alias ? i.data.data.share_user.alias : "学员_".concat(i.data.data.share_user.hq_uid);
                    }
                    i.data.data.friend_list && i.data.data.friend_list.map(function(t) {
                        if (t.hqName = "学员_" + t.friend_uid.replace(t.friend_uid.substring(3, 7), "****"), 
                        !t.gender) {
                            var e = "/images/avatar/" + a.random(1, 12) + ".png", i = wx.getStorageSync("friendAvatar") || {};
                            t.imgUrl = i[t.friend_uid] || e, i[t.friend_uid] || (i[t.friend_uid] = e, wx.setStorageSync("friendAvatar", i));
                        }
                    }), e.setData({
                        zgId: e.data.zgId
                    }), i.data.data.activity.second_category && t.reportEvent(a, "MPViewScreenExID", {
                        $url_path: e.route,
                        examinationID: i.data.data.activity.second_category + ""
                    }), 1 == e.data.totaloriRealNum && e.setData({
                        addressNone: 1
                    }), e.data.shareInfo = i.data.data, i.data.data.activity.good_desc && (i.data.data.activity.good_desc = e.fixedGoodDesc(i.data.data.activity.good_desc)), 
                    console.log(999, 111, i.data.data), e.setStatusMode(i.data.data), e.elseCourse(), 
                    e.getExperienceList(), e.setCategoryInfoShortID(i.data.data.activity);
                } else 1e4 == i.data.status.code ? (d = 1, t.showToast2("活动不存在"), setTimeout(function() {
                    wx.redirectTo({
                        url: "/pages/bargainIndex/bargainIndex"
                    });
                }, 1500)) : 10001 == i.data.status.code ? (t.hideLoading(), d = 1, i.data.data.activity.good_desc && (i.data.data.activity.good_desc = e.fixedGoodDesc(i.data.data.activity.good_desc)), 
                e.setData({
                    infoData: i.data.data,
                    tabIndex: 1
                })) : 10002 == i.data.status.code ? (t.hideLoading(), d = 2, i.data.data.activity.good_desc && (i.data.data.activity.good_desc = e.fixedGoodDesc(i.data.data.activity.good_desc)), 
                e.setData({
                    infoData: i.data.data
                })) : 10003 == i.data.status.code && (d = 1, t.showToast2("活动不存在"), setTimeout(function() {
                    wx.redirectTo({
                        url: "/pages/bargainIndex/bargainIndex"
                    });
                }, 1500));
                0 != i.data.status.code && (wx.getStorageSync("wxInfo") && e.setData({
                    userInfo: wx.getStorageSync("wxInfo")
                }), wx.hideLoading()), e.setData({
                    code: d
                });
            }
        });
    },
    goLogin: function(a) {
        var t = this;
        0 == a.currentTarget.dataset.type ? (wx.setStorageSync("regtype", 103), wx.setStorageSync("zhuliLogin", 1)) : wx.setStorageSync("regtype", 102), 
        wx.setStorage({
            key: "zhuliReg",
            data: 1,
            success: function() {
                wx.redirectTo({
                    url: t.data.loginURL
                });
            }
        });
    },
    fixedGoodDesc: function(a) {
        var t = "", e = new RegExp("(i?)(<img.*?style=['\"])([^>]+>)", "gmi"), i = new RegExp("(i?)(<img)(?!(.*?style=['\"](.*)['\"])[^>]+>)", "gmi");
        return a && (t = a = a.replace(e, '$2display:inline-block; max-width:100%!important; vertical-align:top;" />').replace(i, '$2 style="display:inline-block; max-width:100%!important; vertical-align:top;"$3')), 
        t;
    },
    setCategoryInfoShortID: function(a) {
        wx.getStorageSync("categoryInfo") ? wx.setStorageSync("categoryInfoShortID", {
            gid: a.second_category,
            gname: a.second_category_name
        }) : wx.setStorageSync("categoryInfo", {
            gid: a.second_category,
            gname: a.second_category_name
        });
    },
    setStatusMode: function(a) {
        var e = this, i = 0, s = null;
        a.friend_list.length;
        this.data.activityData = a, 0 == a.share_activity.zug_id && (a.share_activity.is_self = 1), 
        1 == a.share_activity.is_self ? 1 == a.share_activity.is_get_course ? i = 1 : 1 == a.share_activity.is_finished ? i = 2 : 0 == a.share_activity.create_time ? i = 3 : new Date().getTime() - 1e3 * a.share_activity.create_time < 1728e5 ? i = 4 : i = 5 : 0 == a.share_activity.is_self && (1 == a.share_activity.is_finished ? i = 1 : new Date().getTime() - 1e3 * a.share_activity.create_time > 1728e5 ? i = 4 : i = 0 == a.share_activity.is_zulied ? 2 : 3), 
        t.hideLoading(), 1 == a.share_activity.is_self ? 4 == i ? this.data.timer = setInterval(function() {
            s = t.countTime(2, 1e3 * a.share_activity.create_time), e.setData({
                countTime: s
            });
        }, 1e3) : 5 == i && (s = t.countTime(2, 1e3 * a.share_activity.create_time), e.setData({
            countTime: s
        })) : 0 == a.share_activity.is_self && (2 == i || 3 == i ? this.data.timer = setInterval(function() {
            s = t.countTime(2, 1e3 * a.share_activity.create_time), e.setData({
                countTime: s
            });
        }, 1e3) : 4 == i && (s = t.countTime(2, 1e3 * a.share_activity.create_time), e.setData({
            countTime: s
        }))), 1 == a.share_activity.is_self && 2 == i && 1 == this.data.addressNone && e.getAddressList(), 
        1 == a.share_activity.is_self && 3 == i && this.setData({
            tabIndex: 1
        }), 0 == a.share_activity.is_self && 4 == i && this.setData({
            tabIndex: 1
        }), wx.setStorageSync("shareInfoData", a), this.setData({
            mode: i,
            infoData: a
        }), 0 == a.share_activity.is_self && 3 == i && this.getGiftCourseListData(function(a) {
            a.data.data && a.data.data.list.length > 0 && e.setData({
                showGiftBag: 1
            });
        });
    },
    getGiftCourseListData: function(a) {
        var t = this, e = wx.getStorageSync("wxOpenId");
        o.getGiftCourseList({
            token: wx.getStorageSync(i.tokenKey) || "",
            gid: this.data.shareInfo.activity.second_category,
            openid: e
        }, function(e) {
            if (0 == e.data.status.code) "function" == typeof a && a(e); else if (40042 == e.data.status.code) {
                var i = "/pages/login/login?sourcePath=/pages/bargainDetail/bargainDetail" + encodeURIComponent("?path=bargain&" + t.data.argsType + "=" + t.data.argsValu);
                wx.navigateTo({
                    url: i
                });
            }
        });
    },
    MPPowerEvent: function(e) {
        var i = wx.getStorageSync("loginReg") && 1 == wx.getStorageSync("loginReg") ? "是" : "否", s = {
            examinationName: this.data.shareInfo.activity.second_category_name,
            activityID: this.data.shareInfo.activity.id,
            activityName: this.data.shareInfo.activity.good_name,
            newRegister: i
        };
        Object.assign(s, e), t.reportEvent(a, "MPPower", s);
    },
    getCourse: function() {
        var a = this;
        1 != this.data.addressNone ? this.zuligetCourse() : t.showModal("", "该商品包含书籍资料，请填写收货信息后进行领取", function() {
            a.goAddress(1);
        });
    },
    zuligetCourse: function() {
        var a = this;
        t.showLoading(), 1 != this.data.isGetCourse && (this.data.isGetCourse = 1, this.data.consignee_id || 1 != this.data.saveAddress ? wx.request({
            url: i.host + "/wxapp/activity/zuli/getCourse",
            data: {
                appid: s.appid,
                org_id: i.orgId,
                zug_id: a.data.ezugid,
                edu24ol_token: wx.getStorageSync(i.tokenKey) || "",
                consignee_id: a.data.consignee_id,
                chanel_id: (wx.getStorageSync("webIdInfo") || {}).web_id || "",
                first_product_id: s.firstPType,
                last_product_id: s.lastPType,
                source_type: s.srcType
            },
            success: function(e) {
                if (0 == e.data.status.code) {
                    var i = wx.getStorageSync("shareInfoData");
                    i && i.activity && 1 == i.activity.good_type ? t.showToast2("您领取的商品需要在".concat(a.data.appName, "APP学习,请去应用市场搜索“").concat(a.data.appName, "”下载。")) : t.showToast2("领取课程成功！"), 
                    a.data.mode = 1, a.setData({
                        mode: 1
                    });
                } else 1e4 == e.data.status.code ? t.showToast2("你分享的活动不存在") : 10001 == e.data.status.code ? t.showToast2("你分享的活动已失效") : 10002 == e.data.status.code ? t.showToast2("你分享的活动的库存已为0") : 10003 == e.data.status.code ? t.showToast2("找不到您分享的助力活动") : 10004 == e.data.status.code ? t.showToast2("此助力活动不是你分享的") : 10005 == e.data.status.code ? t.showToast2("分享的活动还没有完成助力了") : 10006 == e.data.status.code ? t.showToast2("你已经领取过课程了") : 10007 == e.data.status.code && t.showToast2("由于系统原因,领取课程失败");
                1 == a.data.saveAddress && 1 == a.data.ezuli ? a.getUserInfoData() : t.hideLoading(), 
                a.data.isGetCourse = 0;
            },
            fail: function() {
                t.showToast2("领取课程失败"), t.hideLoading(), a.data.isGetCourse = 0;
            }
        }) : t.showModal("", "该商品包含书籍资料，请填写收货信息后进行领取", function() {
            a.goAddress(1);
        }));
    },
    getAddressList: function(a) {
        var e = this, s = {}, o = 0, d = 0;
        wx.getStorageSync("initAddress"), wx.request({
            url: i.host + "/public/address/getAddressList",
            data: {
                edu24ol_token: wx.getStorageSync(i.tokenKey) || "",
                org_id: i.orgId
            },
            success: function(i) {
                if (0 == i.data.status.code) {
                    if (!(s = i.data.data)) return void t.showToast2("请求地址接口失败");
                    s.forEach(function(a, t) {
                        1 == a.status && (o = 1, e.data.consignee_id = a.id);
                    }), 0 == o && (e.data.consignee_id = s[0].id), d = e.data.consignee_id ? "modify" : "save", 
                    e.setData({
                        addressType: d
                    }), "function" == typeof a && a();
                } else if (40042 == i.data.status.code) {
                    var n = "/pages/login/login?sourcePath=/pages/bargainDetail/bargainDetail" + encodeURIComponent("?" + e.data.argsType + "=" + e.data.argsValu);
                    wx.navigateTo({
                        url: n
                    });
                }
            },
            fail: function(a) {
                t.showToast2("请求地址接口失败");
            }
        });
    },
    goAddress: function(a) {
        var t = "/pages/address/address?", e = "";
        wx.setStorageSync("initAddress", 1), e = 1 == a ? "&zuli=1" : "&zuli=0", t = t + "type=" + this.data.addressType + "&id=" + this.data.consignee_id + "&zug_id=" + this.data.ezugid + e, 
        wx.navigateTo({
            url: t
        });
    },
    goAddressZhuli: function() {
        var a = "/packageAddress/pages/addressListZhuli/addressListZhuli?zugId=".concat(this.data.ezugid, "&zgId=").concat(this.data.zgId);
        wx.getStorageSync(i.tokenKey) || (a = "/pages/login/login?from=" + encodeURIComponent(a)), 
        console.log(999, "url", a), wx.navigateTo({
            url: a
        });
    },
    elseCourse: function() {
        var a, e = this, o = [];
        a = {
            appid: s.appid,
            org_id: i.orgId,
            edu24ol_token: wx.getStorageSync(i.tokenKey) || "",
            sid: e.data.sId,
            t: t.timeStamp()
        }, wx.request({
            url: i.host + "/wxapp/activity/zuli/activityList",
            data: a,
            success: function(a) {
                0 == a.data.status.code ? (a.data.data && a.data.data.length > 0 && a.data.data.forEach(function(a, t) {
                    a.activity.url = "/pages/bargainDetail/bargainDetail?zg_id=" + a.activity.id + "&uid=" + e.data.uid, 
                    0 == a.share_activity.is_get_course && ("zg_id" == e.data.argsType && a.activity.id != e.data.argsValu && o.push(a), 
                    "zug_id" == e.data.argsType && a.share_activity.zug_id != e.data.argsValu && o.push(a));
                }), e.setData({
                    elseCourseData: o
                }), t.hideLoading()) : t.hideLoading();
            },
            fail: function(a) {
                t.showToast2("网络出错或暂无数据"), t.hideLoading();
            }
        });
    },
    getWxUserInfo: function(e) {
        var o = this;
        wx.request({
            url: i.host + "/wxapp/v1/user/getWxUserInfo",
            method: "POST",
            dataType: "json",
            header: {
                "content-type": "application/x-www-form-urlencoded"
            },
            data: {
                appid: s.appid,
                org_id: i.orgId,
                platform: i.platform,
                encryptedData: encodeURIComponent(a.globalData.appBaseInfo.encryptedData),
                code: encodeURIComponent(a.globalData.code),
                iv: encodeURIComponent(a.globalData.appBaseInfo.iv),
                sessionKey: encodeURIComponent(wx.getStorageSync("sessionKey")),
                thirdLogin: s.thirdLogin || "",
                thirdMp: s.thirdMp || ""
            },
            success: function(a) {
                0 == a.data.status.code ? (o.data.wxUserInfo = a.data.data, "function" == typeof e && e()) : t.showToast2("获取个人信息失败。");
            },
            fail: function(a) {
                t.showToast2("获取个人信息失败。");
            }
        });
    },
    shareFriend: function(a, e) {
        var o = this, d = "", n = wx.getStorageSync("loginReg") ? 1 : 0;
        t.showLoading({
            title: "加载中...",
            mask: !0
        }), wx.request({
            url: i.host + "/wxapp/activity/zuli/share",
            data: {
                appid: s.appid,
                org_id: i.orgId,
                zg_id: a,
                form_id: o.data.formId,
                open_id: o.data.wxUserInfo.openId,
                edu24ol_token: wx.getStorageSync(i.tokenKey) || "",
                new_user: n
            },
            success: function(a) {
                o.data.activityData;
                if (0 == a.data.status.code) return 3 == o.data.mode && o.MPPowerEvent({
                    role: "开启助力"
                }), wx.removeStorageSync("loginReg"), d = a.data.data.zug_id ? a.data.data.zug_id : a.data.data.id, 
                void setTimeout(function() {
                    wx.redirectTo({
                        url: "/pages/bargainDetail/bargainDetail?path=bargain&zug_id=".concat(d, "&isShare=").concat(e, "&") + t.paramsStringify(o.utmOptions)
                    });
                }, 1500);
                1e4 == a.data.status.code ? t.showToast2("你分享的活动不存在") : 10001 == a.data.status.code ? t.showToast2("你分享的活动已失效") : 10002 == a.data.status.code ? t.showToast2("你分享的活动的库存已为0") : 10003 == a.data.status.code ? t.showToast2("你分享的活动已完成助力了") : 10004 == a.data.status.code && t.showToast2("由于系统原因,分享失败");
            }
        });
    },
    getWechatQr: function() {
        var a = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : function() {}, e = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : function() {}, o = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : 32;
        wx.request({
            url: i.hostJAPI + "/crm/getWechatQr",
            data: {
                _appid: s.appid,
                _os: i.os,
                _v: s.version,
                _t: t.timeStamp(),
                platform: i.platform,
                resource: 4,
                resourceIds: o,
                ruleType: 2,
                secondCategory: this.data.shareInfo.activity.second_category,
                terminalPage: o,
                terminalType: 4,
                passport: wx.getStorageSync(i.tokenKey) || ""
            },
            type: "GET",
            dataType: "json",
            success: function(t) {
                0 == t.data.status.code ? a() : e();
            }
        });
    },
    zhuli: function(a) {
        var e = this, o = a.zugid, d = wx.getStorageSync("loginReg") ? 1 : 0;
        this.data.isZhuliing || (this.data.isZhuliing = !0, wx.request({
            url: i.host + "/wxapp/activity/zuli/zuli",
            data: {
                appid: s.appid,
                org_id: i.orgId,
                zug_id: o,
                form_id: e.data.formId,
                nickname: e.data.wxUserInfo.nickName,
                avator: e.data.wxUserInfo.avatarUrl,
                edu24ol_token: wx.getStorageSync(i.tokenKey) || "",
                new_user: d
            },
            method: "POST",
            header: {
                "content-type": "application/x-www-form-urlencoded"
            },
            success: function(a) {
                e.data.activityData;
                if (0 == a.data.status.code) {
                    e.MPPowerEvent({
                        role: "帮助助力"
                    }), t.showToast2("助力成功！"), wx.removeStorageSync("loginReg");
                    e.getWechatQr(function() {
                        wx.navigateTo({
                            url: "/packageJoinWeixin/pages/helperSuccess/helperSuccess?gid=" + e.data.shareInfo.activity.second_category
                        });
                    }, function() {
                        var a, t;
                        a = !0, t = function() {
                            a && setTimeout(function() {
                                wx.navigateTo({
                                    url: "/packageJoinWeixin/pages/official/official"
                                });
                            }, 3e3);
                        }, e.getGiftCourseListData(function(a) {
                            var i = "/pages/bargainDetail/bargainDetail?path=bargain&zug_id=" + o + "&isZhuli=1";
                            if (a.data.data && a.data.data.list.length > 0) return i = "/pages/giftZhuli/giftZhuli?gid=".concat(e.data.shareInfo.activity.second_category), 
                            void setTimeout(function() {
                                wx.navigateTo({
                                    url: i
                                }), t();
                            }, 1500);
                            setTimeout(function() {
                                wx.redirectTo({
                                    url: i
                                }), t();
                            }, 1500);
                        });
                    });
                } else 1e4 == a.data.status.code ? t.showToast2("你助力的活动不存在") : 10001 == a.data.status.code ? t.showToast2("你助力的活动已失效") : 10002 == a.data.status.code ? t.showToast2("你助力的活动的库存已为0") : 10003 == a.data.status.code ? t.showToast2("你助力的活动的已完成助力了") : 10004 == a.data.status.code ? t.showToast2("由于系统原因,助力失败") : 10006 == a.data.status.code ? t.showToast2("不能为自己的活动助力") : 10009 == a.data.status.code ? t.showToast2("助力次数已达上限，看看其它助力活动吧") : 10010 == a.data.status.code && t.showToast2("您已经为Ta助力3次，下个月再来吧");
                e.data.isZhuliing = !1;
            }
        }));
    },
    checkUserRecord: function(a, t) {
        wx.request({
            url: "".concat(i.host, "/crm/v1/questionnaire/checkUserRecord"),
            data: {
                edu24ol_token: wx.getStorageSync("hq_token")
            },
            success: function(e) {
                0 == e.data.status.code && (e.data.data ? "function" == typeof a && a() : "function" == typeof t && t());
            }
        });
    },
    goStudy: function() {
        var a = this;
        1 != this.data.totaloriRealNum ? this.qryIsJoinQywx(function() {
            a.navigateToMiniProgramPro();
        }, function() {
            a.getWechatQr(function() {
                wx.navigateTo({
                    url: "/packageJoinWeixin/pages/launchSuccess/launchSuccess?gid=" + a.data.shareInfo.activity.second_category
                });
            }, function() {
                navigateToMiniProgramPro();
            }, 33);
        }) : this.navigateToMiniProgramPro();
    },
    navigateToMiniProgramPro: function() {
        e.navigateToMiniProgramPro(3, this.data.categoryId, this.data.categoryName, this.data.webIdInfo.web_id);
    },
    goBargainIndex: function() {
        wx.navigateTo({
            url: "/pages/bargainIndex/bargainIndex"
        });
    },
    getWedId: function() {
        var a = this;
        wx.getStorage({
            key: "webIdInfo",
            success: function(t) {
                a.data.webIdInfo = t.data || {};
            },
            fail: function(t) {
                a.data.webIdInfo = {};
            }
        });
    },
    getFormId: function(a) {
        var t = a.target.dataset.type;
        this.data.formId = a.detail.formId, "zhuli" == t && this.zhuli(a.target.dataset);
    },
    qryIsJoinQywx: function() {
        var a = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : function() {}, e = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : function() {};
        wx.showLoading({
            title: "加载中...",
            mask: !0
        }), wx.request({
            url: i.host + "/crm/v1/wx/qryIsJoinQywx",
            method: "GET",
            dataType: "json",
            data: {
                _appid: s.appid,
                _os: i.os,
                _v: s.version,
                _t: t.timeStamp(),
                platform: i.platform,
                unionid: this.data.hqUserInfo.wxUnionId || this.data.hqUserInfo.unionId
            },
            success: function(t) {
                wx.hideLoading(), 0 == t.data.status.code && (t.data.data.is_join ? a() : e());
            }
        });
    },
    createFormId: function(a) {
        var t = a.target.dataset.type || "";
        if (this.data.formId = a.detail.formId, "open" != a.detail.target.dataset.type) t && ("zhuli" == t ? this.zhuli(a.target.dataset) : "more" == t && wx.redirectTo({
            url: "/pages/bargainIndex/bargainIndex"
        })); else {
            var e = a.detail.target.dataset.zgid;
            this.shareFriend(e, 1);
        }
    },
    changeTab: function(a) {
        var t = a.currentTarget.dataset;
        this.setData({
            tabIndex: t.type
        });
    },
    showWinRule: function() {
        this.setData({
            stateWinRule: !0
        });
    },
    closeWinRule: function() {
        this.setData({
            stateWinRule: !1
        });
    },
    requestSubscribeMessage: function() {
        var a = this;
        wx.canIUse("requestSubscribeMessage") ? this.subscribeMessage(function() {
            a.data.isSubscribe = 1;
        }) : wx.showModal({
            title: "提示",
            content: "当前微信版本过低，无法使用该功能，请升级到最新微信版本后重试。",
            showCancel: !1
        });
    },
    subscribeMessage: function(t) {
        var e = this, i = 0;
        wx.requestSubscribeMessage({
            tmplIds: [ "nZSsrU55oi0SnSYoI2oUs9zqwux8ewG4WleyBGBMGrM", "C1wF6uFaLIdFX13FGjAyS-EGvhrPifXRurJfVfqz5Aw" ],
            success: function(s) {
                if ("requestSubscribeMessage:ok" == s.errMsg) if ("accept" == s.nZSsrU55oi0SnSYoI2oUs9zqwux8ewG4WleyBGBMGrM && (i = 1), 
                "accept" == s["C1wF6uFaLIdFX13FGjAyS-EGvhrPifXRurJfVfqz5Aw"] && (i = 1), 1 == i) {
                    var o = {
                        nZSsrU55oi0SnSYoI2oUs9zqwux8ewG4WleyBGBMGrM: s.nZSsrU55oi0SnSYoI2oUs9zqwux8ewG4WleyBGBMGrM,
                        "C1wF6uFaLIdFX13FGjAyS-EGvhrPifXRurJfVfqz5Aw": s["C1wF6uFaLIdFX13FGjAyS-EGvhrPifXRurJfVfqz5Aw"]
                    };
                    a.addSubscribeMsg(o, function() {
                        "function" == typeof t && t(), e.toDetail();
                    }), e.setData({
                        stateWinSubscribe: !1
                    });
                } else e.setData({
                    stateWinSubscribe: !1
                }), e.toDetail(), wx.showToast({
                    title: "订阅失败",
                    icon: "none"
                });
            }
        });
    },
    closeWinSubscribe: function(a) {
        var t = this;
        wx.canIUse("requestSubscribeMessage") ? 1 != this.data.isSubscribe ? this.subscribeMessage(function() {
            t.setData({
                stateWinSubscribe: !1
            });
        }) : this.setData({
            stateWinSubscribe: !1
        }) : t.setData({
            stateWinSubscribe: !1
        });
    },
    goGiftZhuli: function() {
        wx.navigateTo({
            url: "/pages/giftZhuli/giftZhuli?gid=".concat(this.data.shareInfo.activity.second_category)
        });
    },
    getExperienceList: function() {
        var a = this, t = wx.getStorageSync("hqUserInfo") || {}, e = {
            secondCategory: a.data.sId,
            passport: t.token || ""
        }, i = {
            from: 0,
            rows: 2,
            secondCategory: a.data.sId
        };
        t.token ? o.request({
            url: "https://japi.hqwx.com/buy/isTotalPriceLessThanThousand",
            data: e,
            method: "GET",
            success: function(t) {
                0 == t.data.status.code && t.data.data.flag && a.setData({
                    isTotalPriceLessThanThousand: !0
                });
            }
        }) : a.setData({
            isTotalPriceLessThanThousand: !0
        }), o.request({
            url: "https://japi.hqwx.com/uc/study/experienceWithSecondCategory",
            data: i,
            method: "GET",
            success: function(t) {
                if (0 == t.data.status.code) {
                    var e = t.data.data || [];
                    a.setData({
                        experienceList: e
                    });
                }
            }
        });
    },
    toDetail: function() {
        if (this.data.isTotalPriceLessThanThousand && this.data.experienceList.length > 0) {
            var a = wx.getStorageSync("toDetailList") || [];
            if (a.indexOf(this.data.zgId) > -1) return;
            a.push(this.data.zgId), wx.setStorageSync("toDetailList", a), wx.navigateTo({
                url: "/pages/courseDetail/courseDetail?id=" + this.data.experienceList[0].id
            });
        }
    },
    setUpdateShareMenu: function(a) {
        wx.request({
            url: i.host + "/wxapp/v1/tableMsg/get",
            data: {
                appid: s.appid,
                org_id: i.orgId,
                platform: i.platform,
                sourceId: a,
                sourceType: 2
            },
            success: function(a) {
                0 == a.data.status.code && wx.updateShareMenu({
                    withShareTicket: !0,
                    isUpdatableMessage: !0,
                    activityId: a.data.data.activity_id,
                    templateInfo: {
                        parameterList: [ {
                            name: "member_count",
                            value: a.data.data.member_count
                        }, {
                            name: "room_limit",
                            value: a.data.data.room_limit
                        } ]
                    }
                });
            }
        });
    },
    onShareAppMessage: function(e) {
        var i = e.from, s = "/pages/bargainDetail/bargainDetail", o = "&web_id=" + this.data.webIdInfo.web_id, d = "", n = "";
        e.target.dataset.type;
        e.web_id && a.setWebIdToStorage(e.web_id), "button" == i ? (d = e.target.dataset.zgid, 
        n = e.target.dataset.zugid, e.target.dataset.type) : "zug_id" == this.data.argsType ? n = this.data.argsValu : d = this.data.argsValu, 
        s = n > 0 ? s + "?zug_id=" + n + "&" + t.paramsStringify(this.utmOptions) : s + "?zg_id=" + d + "&uid=" + this.data.uid + "&" + t.paramsStringify(this.utmOptions), 
        this.data.webIdInfo.web_id && (s += o), 1 == this.data.infoData.share_activity.is_self && "button" == i && this.setData({
            stateWinSubscribe: !0
        });
        return {
            title: "".concat(this.data.goodName, "，点击帮我免费领！"),
            path: s,
            imageUrl: "https://oss-hqwx-edu24ol.hqwx.com/miniapp/hq_mall/share/bargain_detail.png",
            success: function(a) {},
            complete: function() {
                t.hideLoading();
            }
        };
    }
});