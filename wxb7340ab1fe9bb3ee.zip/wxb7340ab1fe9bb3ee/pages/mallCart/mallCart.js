var a = getApp(), t = require("../../utils/util"), e = require("../../configs/baseConfig"), d = require("../../configs/config_" + e.appName);

Page({
    data: {
        group_id: -1,
        realNum: -1,
        ldata: [],
        cnums: 0,
        cprice: 0,
        tdata: [],
        systemText: ""
    },
    onLoad: function(a) {
        var o = this;
        null != a.gid && null != a.realNum || wx.redirectTo({
            url: "/pages/index/index"
        }), o.data.group_id = a.gid, o.data.realNum = a.realNum, o.setData({
            group_id: o.data.group_id,
            realNum: o.data.realNum
        }), o.setData({
            token: wx.getStorageSync(e.tokenKey) || e.testToken
        }), 1 == t.checkOS() ? this.setData({
            systemText: "购买"
        }) : 2 == t.checkOS() && this.setData({
            systemText: "选课"
        }), t.showLoading({
            title: "加载中...",
            mask: !0
        }), wx.request({
            url: e.host + "/mobile/v2/goods/groups_goods",
            data: {
                gpid: o.data.group_id,
                edu24ol_token: o.data.token,
                org_id: e.orgId,
                appid: d.appid,
                _v: d.version,
                _os: e.os
            },
            method: "GET",
            dataType: "json",
            success: function(a) {
                if (40042 != a.data.status.code) {
                    if (0 == a.data.status.code) {
                        o.data.ldata = a.data.data;
                        for (var e = 0; e < a.data.data.length; e++) a.data.data[e].checked = !1;
                        o.setData({
                            ldata: o.data.ldata
                        });
                    } else t.showToast2("网络出错或暂无数据");
                    t.hideLoading();
                } else wx.redirect({
                    url: "/pages/login/login?sourcePath=%2Fpages%courseDetail%courseDetail%3Fid%3D" + o.data.group_id
                });
            },
            fail: function() {
                t.hideLoading(), t.showToast2("网络出错或暂无数据");
            }
        });
    },
    checkboxChange: function(a) {
        for (var t = a.detail.value, e = 0, d = 0; d < this.data.ldata.length; d++) for (var o = 0; o < t.length; o++) this.data.ldata[d].id == t[o] && (e += this.data.ldata[d].sale_price);
        this.setData({
            tdata: t,
            cnums: t.length,
            cprice: parseInt(e)
        });
    },
    buythis: function() {
        var a = 1, t = this.data.tdata;
        if (0 != this.data.tdata.length) {
            for (var e = 0; e < this.data.ldata.length; e++) for (var d = 0; d < t.length; d++) this.data.ldata[e].id == t[d] && (0 == this.data.ldata[e].price && 0 == this.data.ldata[e].sale_price || (a = 0));
            if (1 == a && 0 == this.data.realNum) this.goFree(); else {
                var o = "/pages/orderDetail/orderDetail?groupId=".concat(this.data.group_id, "&goodsId=").concat(this.data.tdata);
                wx.navigateTo({
                    url: o
                });
            }
        }
    },
    goFree: function() {
        var o = this;
        t.showLoading({
            title: "开通中...",
            mask: !0
        }), wx.request({
            url: "".concat(e.hostJAPI, "/buy/order/qboxCreateOrder"),
            data: {
                groupId: o.data.group_id,
                edu24ol_token: o.data.token,
                goodsId: o.data.tdata.toString(),
                salesSrc: wx.getStorageSync("wxEduCd"),
                org_id: e.orgId,
                appId: d.appid,
                terminalType: e.terminalType,
                termVersion: d.version,
                _v: d.version,
                _os: e.os
            },
            method: "POST",
            header: {
                "content-type": "application/x-www-form-urlencoded"
            },
            success: function(e) {
                if (0 == e.data.status.code) {
                    var d = "/pages/paySuccess/paySuccess?isFree=1&goodsId=".concat(goodsId, "&gid=").concat(o.data.cData.second_category);
                    a.actionSourceSave(e.data.data.buyOrderId, 3), console.log(999, "paySuccess", d), 
                    wx.redirectTo({
                        url: d
                    });
                } else t.hideLoading();
            },
            fall: function() {
                t.hideLoading();
            }
        });
    }
});