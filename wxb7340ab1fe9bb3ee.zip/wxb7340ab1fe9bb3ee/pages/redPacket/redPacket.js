var a = getApp(), e = require("../../utils/util"), t = (require("../template/template"), 
require("../../configs/baseConfig")), o = require("../../configs/config_" + t.appName);

Page({
    data: {
        web_id: 0,
        userInfo: {},
        isIPhoneX: !1,
        selectIndex: 0,
        isShowDialog: !1,
        isShowDialog2: !1,
        isShowDialog3: !1,
        isShowDialog4: !1,
        memberList: [],
        userRedPackInfoOne: !1,
        userRedPackInfoLoaded: !1,
        dataLoaded: !1,
        helpLost: !0,
        wrongText: "助力失败，仅限新用户助力",
        helpSuccess: !1,
        checkAlreadyHelpOne: !1,
        activityNum: 6
    },
    onLoad: function(e) {
        var o = this;
        this.data.activityId = e.activity_id, this.data.shareOpenid = e.share_openid || "", 
        this.data.shareAvator = e.share_avator || "", this.data.shareNickName = e.share_nickname || "", 
        this.data.shareRedpackId = e.share_redpack_id || "", console.log("from other", e), 
        a.setWebIdToStorage(e.web_id), this.data.shareRedpackId || wx.hideShareMenu(), a.HQTokenStorage(function() {
            wx.setStorageSync(t.tokenKey, ""), wx.setStorageSync(t.tokenTimeStamp, ""), console.log("clearToken");
        }, function() {
            console.log("hasToken");
        }), this.webIdInfo = wx.getStorageSync("webIdInfo") || {}, this.data.categoryInfo = wx.getStorageSync("categoryInfo") || {}, 
        this.data.token = wx.getStorageSync(t.tokenKey) || "", this.data.wxOpenId = wx.getStorageSync("wxOpenId") || "", 
        this.profileData = {}, this.setData({
            token: this.data.token,
            shareAvator: this.data.shareAvator,
            shareNickName: this.data.shareNickName,
            activityId: this.data.activityId
        }), this.sharePage(this.data.wxOpenId), a.getUserInfo(function() {
            o.reGetUserData();
        }), a.getUserInfo(function() {
            o.queryBindState();
        }), this.getActivityInfo();
    },
    help: function() {
        this.setData({
            helpLost: !0,
            wrongText: "助力失败，仅限新用户助力"
        }), this.showDialog2();
    },
    tab: function(a) {
        var e = a.currentTarget.dataset.index;
        this.setData({
            selectIndex: e
        });
    },
    showDialog: function() {
        this.setData({
            isShowDialog: !0
        });
    },
    closeDialog: function() {
        this.setData({
            isShowDialog: !1
        });
    },
    showDialog2: function() {
        this.setData({
            isShowDialog2: !0
        });
    },
    closeDialog2: function() {
        this.setData({
            isShowDialog2: !1
        });
    },
    showDialog3: function() {
        this.setData({
            isShowDialog3: !0
        });
    },
    closeDialog3: function() {
        this.setData({
            isShowDialog3: !1
        });
    },
    clearTimer: function() {
        this.timer && (clearTimeout(this.timer), console.log("this.timer"));
    },
    showDialog4: function() {
        this.setData({
            isShowDialog4: !0
        });
    },
    closeDialog4: function() {
        this.setData({
            isShowDialog4: !1
        });
    },
    showDialog5: function() {
        this.setData({
            isShowDialog5: !0
        });
    },
    closeDialog5: function() {
        this.setData({
            isShowDialog5: !1
        });
    },
    requestSubscribeMessage: function() {
        var a = this;
        this.subscribeMessage(function() {
            a.data.isSubscribe = 1, a.setData({
                isShowDialog5: !1
            });
        });
    },
    subscribeMessage: function(e) {
        var t = this, o = 0;
        wx.requestSubscribeMessage({
            tmplIds: [ "23OL3eP7ebGr50FGwK6pQnXv-mESMnLZnqz9f_NoU7g" ],
            success: function(i) {
                if (console.log("requestSubscribeMessage success", i), "requestSubscribeMessage:ok" == i.errMsg) if ("accept" == i["23OL3eP7ebGr50FGwK6pQnXv-mESMnLZnqz9f_NoU7g"] && (o = 1), 
                1 == o) {
                    var s = {
                        "23OL3eP7ebGr50FGwK6pQnXv-mESMnLZnqz9f_NoU7g": i["23OL3eP7ebGr50FGwK6pQnXv-mESMnLZnqz9f_NoU7g"]
                    };
                    a.addSubscribeMsg(s, function() {
                        "function" == typeof e && e();
                    });
                } else wx.showToast({
                    title: "订阅失败",
                    icon: "none"
                }), t.setData({
                    isShowDialog5: !1
                });
            },
            fail: function(a) {
                console.log("fail", a), "function" == typeof e && e(), wx.showToast({
                    title: "请将微信升级至最新版本后点击小程序右上角设置->设置->打开订阅消息",
                    icon: "none",
                    duration: 5e3
                });
            },
            complete: function(a) {}
        });
    },
    closeWinSubscribe: function(a) {
        var e = this;
        1 != this.data.isSubscribe ? this.subscribeMessage(function() {
            e.setData({
                isShowDialog5: !1
            });
        }) : this.setData({
            isShowDialog5: !1
        });
    },
    sharePage: function(a) {
        a && (this.data.shareOpenid && a != this.data.shareOpenid ? this.setData({
            isSharePage: !0
        }) : this.setData({
            isSharePage: !1
        }));
    },
    reGetUserData: function() {
        var a = this;
        this.getProfile(function(e) {
            a.data.wxAppToken = e.wxAppToken, a.data.wxOpenId = e.openId, wx.setStorageSync("wxOpenId", a.data.wxOpenId), 
            a.data.avator = e.avatarUrl, a.data.nickName = e.nickName, a.sharePage(a.data.wxOpenId), 
            console.log("profileData", e), a.setData({
                dataLoaded: !0
            }), a.data.token && !a.data.userRedPackInfoOne && a.userRedPackInfo(), !a.data.checkAlreadyHelpOne && a.data.isSharePage && a.checkAlreadyHelp();
        });
    },
    getUserInfoData: function() {
        var e = this;
        a.getUserInfo(function() {
            e.reGetUserData();
        }), a.getUserInfo(function() {
            e.queryBindState();
        });
    },
    queryBindState: function() {
        var i = this;
        e.showLoading({
            title: "加载中...",
            mask: !0
        }), wx.request({
            url: t.host + "/wxapp/v1/user/profile",
            method: "POST",
            dataType: "json",
            header: {
                "content-type": "application/x-www-form-urlencoded"
            },
            data: {
                appid: o.appid,
                org_id: t.orgId,
                platform: t.platform,
                encryptedData: encodeURIComponent(a.globalData.appBaseInfo.encryptedData),
                code: encodeURIComponent(a.globalData.code),
                iv: encodeURIComponent(a.globalData.appBaseInfo.iv),
                sessionKey: encodeURIComponent(wx.getStorageSync("sessionKey")),
                distinct_id: o.sdid
            },
            success: function(a) {
                0 == a.data.status.code && (wx.setStorage({
                    key: "hqUserInfo",
                    data: a.data.data
                }), wx.setStorage({
                    key: t.tokenTimeStamp,
                    data: e.timeStamp()
                }), wx.setStorage({
                    key: t.tokenKey,
                    data: a.data.data.token
                }), i.setData({
                    token: wx.getStorageSync(t.tokenKey) || ""
                }), i.reGetUserData());
            },
            complete: function() {
                e.hideLoading();
            }
        });
    },
    getActivityTime: function(a, t) {
        var o = e.formatTime2(1e3 * a), i = e.formatTime2(1e3 * t);
        this.setData({
            activityTime: Number(o.month) + "月" + Number(o.day) + "日-" + Number(i.month) + "月" + Number(i.day) + "日"
        });
    },
    checkAlreadyHelp: function() {
        var a = this;
        a.data.checkAlreadyHelpOne = !0, e.showLoading({
            title: "加载中...",
            mask: !0
        }), wx.request({
            url: t.host + "/wxapp/activity/red_pack/checkAlreadyHelp",
            method: "GET",
            data: {
                _appid: o.appid,
                _os: t.os,
                _v: o.version,
                _t: e.timeStamp(),
                org_id: t.orgId,
                platform: t.platform,
                user_red_pack_id: a.data.shareRedpackId,
                open_id: a.data.wxOpenId
            },
            success: function(e) {
                console.log("checkAlreadyHelp", e), 0 == e.data.status.code && a.setData({
                    helpSuccess: e.data.data
                });
            },
            fail: function() {},
            complete: function() {
                e.hideLoading();
            }
        });
    },
    getActivityInfo: function() {
        var a = this;
        e.showLoading({
            title: "加载中...",
            mask: !0
        }), wx.request({
            url: t.host + "/wxapp/activity/red_pack/get_activity_info",
            method: "GET",
            data: {
                _appid: o.appid,
                _os: t.os,
                _v: o.version,
                _t: e.timeStamp(),
                org_id: t.orgId,
                platform: t.platform,
                activity_id: a.data.activityId
            },
            success: function(e) {
                console.log("get_activity_info", e), 0 == e.data.status.code && (a.setData({
                    activityName: e.data.data.name,
                    leftMoneyRate: e.data.data.left_money_rate,
                    shareImage: e.data.data.share_image,
                    shareTitle: e.data.data.share_title
                }), a.getActivityTime(e.data.data.start_time, e.data.data.end_time));
            },
            fail: function() {},
            complete: function() {
                e.hideLoading();
            }
        });
    },
    userRedPackInfo: function() {
        var a = this;
        a.data.userRedPackInfoOne = !0, e.showLoading({
            title: "加载中...",
            mask: !0
        }), wx.request({
            url: t.host + "/wxapp/activity/red_pack/user_red_pack_info",
            method: "GET",
            data: {
                _appid: o.appid,
                _os: t.os,
                _v: o.version,
                _t: e.timeStamp(),
                org_id: t.orgId,
                platform: t.platform,
                wxapp_token: a.data.wxAppToken,
                activity_id: a.data.activityId
            },
            success: function(t) {
                if (console.log("user_red_pack_info", t), 0 == t.data.status.code) {
                    var o = t.data.data.activity_info, i = t.data.data.user_red_pack_info, s = "", n = "";
                    i.first_money && (s = e.formatTime2(1e3 * i.first_money.create_time), s = Number(s.month) + "月" + Number(s.day) + "日 " + s.hour + ":" + s.minute + ":" + s.second, 
                    n = i.first_money.money);
                    var d = "", r = "";
                    i.last_money && (d = e.formatTime2(1e3 * i.last_money.create_time), d = Number(d.month) + "月" + Number(d.day) + "日 " + d.hour + ":" + d.minute + ":" + d.second, 
                    r = i.last_money.money), t.data.data.member_list.forEach(function(a, t) {
                        var o = e.formatTime2(1e3 * a.create_date);
                        o = Number(o.month) + "月" + Number(o.day) + "日 " + o.hour + ":" + o.minute + ":" + o.second, 
                        a.creatTime = o;
                    });
                    var c = wx.getStorageSync("hasShowFirstMoney" + o.id) || "", h = wx.getStorageSync("hasShowLastMoney" + o.id) || "";
                    n && !r && (c || (a.showDialog3(), a.setData({
                        showMoney: n
                    }), wx.setStorageSync("hasShowFirstMoney" + o.id, 1))), r && (h || (a.showDialog3(), 
                    a.setData({
                        showMoney: r,
                        isLastMoney: !0
                    }), wx.setStorageSync("hasShowLastMoney" + o.id, 1)));
                    var l = !1, g = new Date().getTime();
                    (2 == o.status || !o.left_money || g - 1e3 * o.end_time > 0) && (l = !0), 3 == o.status && a.setData({
                        isShowDialog6: !0
                    }), a.setData({
                        activityName: o.name,
                        activityId: o.id,
                        leftMoneyRate: o.left_money_rate,
                        memberList: t.data.data.member_list,
                        userRedPackInfo: i,
                        firstMoney: n,
                        lastMoney: r,
                        firstMoneyTime: s,
                        lastMoneyTime: d,
                        activityInvalid: l,
                        redPackId: i.id
                    }), wx.showShareMenu();
                }
            },
            fail: function() {},
            complete: function() {
                a.setData({
                    dataLoaded: !0
                }), e.hideLoading();
            }
        });
    },
    getProfile: function() {
        var i = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : function() {}, s = this;
        e.showLoading({
            title: "加载中...",
            mask: !0
        }), "{}" == JSON.stringify(this.profileData) ? wx.request({
            url: t.host + "/wxapp/v1/user/getWxUserInfo",
            method: "POST",
            dataType: "json",
            header: {
                "content-type": "application/x-www-form-urlencoded"
            },
            data: {
                appid: t.appid,
                org_id: t.orgId,
                platform: t.platform,
                encryptedData: encodeURIComponent(a.globalData.appBaseInfo.encryptedData),
                code: encodeURIComponent(a.globalData.code),
                iv: encodeURIComponent(a.globalData.appBaseInfo.iv),
                sessionKey: encodeURIComponent(wx.getStorageSync("sessionKey")),
                thirdMp: o.thirdMp || "",
                thirdLogin: o.thirdLogin || ""
            },
            success: function(a) {
                e.hideLoading(), 0 == a.data.status.code && (s.profileData = a.data.data, i(s.profileData));
            },
            fail: function(a) {
                e.hideLoading();
            }
        }) : i(this.profileData);
    },
    getPhoneNumberCB: function(a) {
        var o = this;
        e.showLoading({
            title: "加载中...",
            mask: !0
        }), a.redPackId = this.data.shareRedpackId, this.selectComponent("#bindPhone").getPhoneNumberCB(a, function(a) {
            o.setData({
                token: wx.getStorageSync(t.tokenKey) || ""
            }), o.reGetUserData(), o.closeDialog(), o.data.isSharePage && (o.setData({
                helpLost: !0,
                wrongText: "助力失败，仅限新用户助力"
            }), o.showDialog2());
        }, function() {
            e.showToast2("登录后才能参与活动哦");
        }, function(a) {
            console.log("红包助力用户绑定", a);
            var e = parseInt(a.data.status.code);
            if (1e3 == e || 1001 == e || 1002 == e || 1003 == e || 1004 == e || 1005 == e || 1006 == e) switch (a.data.data && (wx.setStorageSync("hqUserInfo", a.data.data), 
            wx.setStorageSync(t.tokenKey, a.data.data.token), o.setData({
                token: a.data.data.token
            })), e) {
              case 1e3:
                o.setData({
                    helpLost: !1
                }), o.showDialog2(), o.timer = setTimeout(function() {
                    var a = "/pages/redPacket/redPacket?activity_id=" + o.data.activityId + "&share_openid=" + o.data.shareOpenid + "&share_avator=" + o.data.shareAvator + "&share_nickname=" + o.data.shareNickName + "&share_redpack_id=" + o.data.shareRedpackId;
                    a = o.webIdInfo.web_id ? a + "&web_id=" + o.webIdInfo.web_id : a, console.log("go Path", a), 
                    wx.redirectTo({
                        url: a
                    });
                }, 3e3);
                break;

              case 1001:
                o.setData({
                    helpLost: !0,
                    wrongText: "助力失败，助力数据不合法"
                }), o.showDialog2();
                break;

              case 1002:
                o.setData({
                    helpLost: !0,
                    wrongText: "助力失败，助力人数已满"
                }), o.showDialog2();
                break;

              case 1003:
                o.setData({
                    activityInvalid: !0
                });
                break;

              case 1004:
                o.setData({
                    helpLost: !0,
                    wrongText: "助力失败，仅限新用户助力"
                }), o.showDialog2();
                break;

              case 1005:
                o.setData({
                    helpLost: !0,
                    wrongText: "系统繁忙,请稍后再试"
                }), o.showDialog2();
                break;

              case 1006:
                o.setData({
                    helpLost: !0,
                    wrongText: "当前访问量过大，请稍后再试"
                }), o.showDialog2();
            }
        });
    },
    onShareAppMessage: function(a) {
        var e = this, t = "/pages/redPacket/redPacket?activity_id=" + this.data.activityId + "&share_openid=" + this.data.wxOpenId + "&share_avator=" + this.data.avator + "&share_nickname=" + this.data.nickName + "&share_redpack_id=" + this.data.redPackId;
        return t = this.webIdInfo.web_id ? t + "&web_id=" + this.webIdInfo.web_id : t, console.log("share path", t), 
        this.data.activityInvalid || this.data.isSharePage || this.data.isShowDialog3 || this.data.memberList.length == this.data.activityNum || setTimeout(function() {
            e.showDialog5();
        }, 500), {
            title: this.data.shareTitle || "环球新春派大礼，快看看你能领多少？",
            path: t,
            imageUrl: this.data.shareImage || "https://oss-hqwx-edu24ol.hqwx.com/3e643f0836e334b36af3ccf8f72e58ac3a4afbd3.png",
            success: function(a) {},
            fail: function(a) {},
            complete: function() {}
        };
    }
});