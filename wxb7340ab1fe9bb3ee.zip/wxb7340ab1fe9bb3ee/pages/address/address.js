getApp();

var o = require("../../utils/util"), i = require("../../configs/baseConfig"), e = require("../../configs/config_" + i.appName);

Page({
    data: {
        src: ""
    },
    onLoad: function(d) {
        var t, r = "", a = d.id, n = wx.getStorageSync(i.tokenKey), p = (o.checkOS(), d.zug_id), s = d.zuli;
        r = "modify" == d.type ? "modifyShipAddr" : "saveShipAddr", t = i.httpHost + "mapp.98809.com/wap/v2/addr/" + r + "?id=" + a + "&edu24ol_token=" + n + "&_os=2&_v=" + e.version + "&_appid=" + e.appid + "&org_id=" + i.orgId + "&zug_id=" + p + "&zuli=" + s, 
        console.log("_src", t), this.setData({
            src: decodeURIComponent(t)
        });
    },
    onShow: function(o) {}
});