require("../../uni-bootstrap.js"), (global.webpackJsonp = global.webpackJsonp || []).push([ [ "pages/orderDetail/orderDetail" ], {
    52: function(t, e, o) {
        (function(t) {
            o(4);
            e(o(2));
            function e(t) {
                return t && t.__esModule ? t : {
                    default: t
                };
            }
            t(e(o(53)).default);
        }).call(this, o(1).createPage);
    },
    53: function(t, e, o) {
        o.r(e);
        var a = o(54), i = o(56);
        for (var r in i) "default" !== r && function(t) {
            o.d(e, t, function() {
                return i[t];
            });
        }(r);
        o(58);
        var n = o(10), s = Object(n.default)(i.default, a.render, a.staticRenderFns, !1, null, null, null, !1, a.components, void 0);
        s.options.__file = "pages/orderDetail/orderDetail.vue", e.default = s.exports;
    },
    54: function(t, e, o) {
        o.r(e);
        var a = o(55);
        o.d(e, "render", function() {
            return a.render;
        }), o.d(e, "staticRenderFns", function() {
            return a.staticRenderFns;
        }), o.d(e, "recyclableRender", function() {
            return a.recyclableRender;
        }), o.d(e, "components", function() {
            return a.components;
        });
    },
    55: function(t, e, o) {
        o.r(e), o.d(e, "render", function() {
            return i;
        }), o.d(e, "staticRenderFns", function() {
            return n;
        }), o.d(e, "recyclableRender", function() {
            return r;
        }), o.d(e, "components", function() {
            return a;
        });
        var a = {
            cCourseAgree: function() {
                return o.e("components/c-course-agree/c-course-agree").then(o.bind(null, 353));
            }
        }, i = function() {
            var t = this, e = t.$createElement, o = (t._self._c, t.isLoading ? null : t.__map(t.cartList, function(e, o) {
                return {
                    $orig: t.__get_orig(e),
                    l0: e.cartDetailList && e.cartDetailList.length > 0 ? t.__map(e.cartDetailList, function(e, o) {
                        return {
                            $orig: t.__get_orig(e),
                            f0: e.goods.start_time ? t._f("date")(e.goods.start_time, "yyyy年mm月dd日") : null,
                            f1: e.goods.start_time ? t._f("date")(e.goods.end_time, "yyyy年mm月dd日") : null
                        };
                    }) : null
                };
            }));
            t._isMounted || (t.e0 = function(e) {
                t.isShowWinMemberProducts = !0;
            }, t.e1 = function(e) {
                t.isShowWinMemberProducts = !1;
            }, t.e2 = function(e) {
                t.isShowWinMemberProducts = !1;
            }), t.$mp.data = Object.assign({}, {
                $root: {
                    l1: o
                }
            });
        }, r = !1, n = [];
        i._withStripped = !0;
    },
    56: function(t, e, o) {
        o.r(e);
        var a = o(57), i = o.n(a);
        for (var r in a) "default" !== r && function(t) {
            o.d(e, t, function() {
                return a[t];
            });
        }(r);
        e.default = i.a;
    },
    57: function(t, e, o) {
        (function(t) {
            Object.defineProperty(e, "__esModule", {
                value: !0
            }), e.default = void 0;
            var a, i = (a = o(20)) && a.__esModule ? a : {
                default: a
            }, r = o(21);
            function n(t) {
                return function(t) {
                    if (Array.isArray(t)) return s(t);
                }(t) || function(t) {
                    if ("undefined" != typeof Symbol && Symbol.iterator in Object(t)) return Array.from(t);
                }(t) || function(t, e) {
                    if (!t) return;
                    if ("string" == typeof t) return s(t, e);
                    var o = Object.prototype.toString.call(t).slice(8, -1);
                    "Object" === o && t.constructor && (o = t.constructor.name);
                    if ("Map" === o || "Set" === o) return Array.from(t);
                    if ("Arguments" === o || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(o)) return s(t, e);
                }(t) || function() {
                    throw new TypeError("Invalid attempt to spread non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.");
                }();
            }
            function s(t, e) {
                (null == e || e > t.length) && (e = t.length);
                for (var o = 0, a = new Array(e); o < e; o++) a[o] = t[o];
                return a;
            }
            var d = getApp(), c = {
                data: function() {
                    return {
                        options: {},
                        groupId: "",
                        goodsId: "",
                        groupInfo: null,
                        prices: null,
                        cartList: null,
                        realNun: 0,
                        goodsPairsList: [],
                        freightInfo: null,
                        addressData: null,
                        cartIds: "",
                        addressId: 0,
                        couponCode: 0,
                        balance: 0,
                        cartGroupData: "",
                        totalPriceData: "",
                        couponData: "",
                        giftCount: 0,
                        winState: !1,
                        winType: "",
                        isPaying: !1,
                        isLoading: !0,
                        deliveryId: "",
                        delivery: "",
                        pintuanId: "",
                        activityId: "",
                        memberProducts: [],
                        isMemberSales: 0,
                        isShowMemberPrice: 0,
                        chooseMemberPrice: 0,
                        memberDetail: "",
                        isShowWinMemberProducts: !1,
                        memberGoodsIds: [],
                        goodsNum: 1
                    };
                },
                onLoad: function(e) {
                    this.groupId = e.groupId || "0", this.goodsId = e.goodsId || "72915,72918", this.pintuanId = e.pintuanId || 0, 
                    this.activityId = e.activityId || 0, this.goodsNum = e.num || 1, this.options = e, 
                    e.delivery && (this.delivery = e.delivery, this.deliveryId = e.deliveryId), t.showLoading({
                        title: "加载中...",
                        mask: !0
                    }), 1 == e.type ? this.getCartGroupGoodsList() : this.addToCart();
                },
                onShow: function() {
                    this.cartGroupData && this.getAddressList();
                },
                methods: {
                    addToCart: function() {
                        var t = this, e = [];
                        this.goodsId.split(",").map(function(o) {
                            e.push([ o, t.goodsNum ]);
                        });
                        var o = {
                            edu24ol_token: !0,
                            groupId: this.groupId,
                            activityId: this.activityId,
                            pintuanId: this.pintuanId,
                            goods: JSON.stringify(e)
                        };
                        this.options.activityId && (o.activityId = this.options.activityId), this.options.pintuanId && (o.pintuanId = this.options.pintuanId), 
                        this.options.miniappBargainId && (o.miniapp_bargain_id = this.options.miniappBargainId), 
                        this.$hq.get("".concat(i.default.hostJAPI, "/buy/cart/addToCart"), o).then(function(e) {
                            0 == e.data.status.code && t.getCartGroupGoodsList();
                        });
                    },
                    getCartGroupGoodsList: function() {
                        var e = this;
                        this.$hq.get("".concat(i.default.hostJAPI, "/buy/cart/getCartGroupGoodsList"), {
                            edu24ol_token: !0,
                            groupId: this.groupId,
                            goodsId: this.goodsId
                        }).then(function(o) {
                            if (0 == o.data.status.code) {
                                var a = o.data.data, i = [], r = 0, s = [];
                                if (e.groupInfo = a.groupInfo, e.cartList = a.cartInfo.cartList, e.realNun = a.realNun, 
                                a.cartInfo.cartList.forEach(function(t, o) {
                                    i.push(t.id), t.goods.isMemberSales && e.memberGoodsIds.push(t.goods.id), t.goods.goodsPairsList.map(function(e) {
                                        e.cartId = t.id, e.parentsId = t.goods.id;
                                    }), s.push.apply(s, n(t.goods.goodsPairsList)), t.cartDetailList && (t.showState = 0, 
                                    0 == o && (t.showState = 1), t.cartDetailList.forEach(function(t, e) {
                                        2 == t.buyType && r++;
                                    }), t.goods.isMemberSales && e.memberProducts.push(t.goods));
                                }), e.goodsPairsList = s, e.cartIds = i.join(","), e.giftCount = r, e.cartGroupData = a, 
                                a.memberDiscountPrice) {
                                    var d = a.userMemberLevel;
                                    d.privilegeList.forEach(function(t, e) {
                                        "sales_buy_course" == t.type && (d.salesBuyCourse = t);
                                    }), e.memberDetail = d;
                                }
                                1 == a.realNun ? e.getAddressList() : e.getCartGroupTotalPrice(function() {
                                    e.getCouponByGoods();
                                });
                            } else t.hideLoading(), t.showToast({
                                title: o.data.status.msg,
                                icon: "none"
                            });
                        });
                    },
                    getAddressList: function() {
                        var t = this;
                        this.$hq.get("".concat(i.default.hostJAPI, "/buy/consignee/getUserConsigneeList"), {
                            edu24ol_token: !0,
                            from: 0,
                            rows: 1
                        }).then(function(e) {
                            if (0 == e.data.status.code) {
                                var o = e.data.data;
                                o && (o.length > 0 ? (t.addressData = o[0], t.addressId = o[0].id) : (t.addressData = "", 
                                t.addressId = 0));
                            } else t.addressId = 0, t.addressData = null;
                            t.getCartGroupTotalPrice(function() {
                                t.getCouponByGoods();
                            });
                        });
                    },
                    getCartGroupTotalPrice: function(e) {
                        var o = this, a = {
                            edu24ol_token: !0,
                            addrId: this.addressId,
                            cartIds: this.cartIds
                        };
                        this.couponCode && (a = Object.assign(a, {
                            couponCode: this.couponCode
                        })), this.$hq.get("".concat(i.default.hostJAPI, "/buy/cart/getCartGroupTotalPrice"), a).then(function(a) {
                            if (0 == a.data.status.code) {
                                var i = a.data.data;
                                o.totalPriceData = i, o.isLoading = !1, o.balance = i.useBalance, o.prices = i.cartInfo, 
                                o.freightInfo = i.freightInfo, o.comparePrice(), "function" == typeof e && e(a);
                            }
                            t.hideLoading();
                        });
                    },
                    getCouponByGoods: function() {
                        var e = this;
                        this.$hq.get("".concat(i.default.hostJAPI, "/sales/getCouponByGoods"), {
                            passport: t.getStorageSync(i.default.tokenKey),
                            amount: this.totalPriceData.cartInfo.payPrice,
                            from: 0,
                            rows: 20,
                            goodsIds: this.goodsId,
                            terminalType: i.default.terminalType
                        }).then(function(t) {
                            if (0 == t.data.status.code) {
                                var o = t.data.data;
                                if (o.availableCouponList && o.availableCouponList.length > 0 && o.availableCouponList.forEach(function(t, o) {
                                    t.activate_begin_time_ft = e.$hq.timeFormat(t.activate_begin_time, "yyyy.mm.dd"), 
                                    t.activate_end_time_ft = e.$hq.timeFormat(t.activate_end_time, "yyyy.mm.dd");
                                }), e.couponData = o, o && o.availableCouponList && o.availableCouponList.length) {
                                    var a = {
                                        currentTarget: {
                                            dataset: {
                                                couponcode: o.availableCouponList[0].code
                                            }
                                        }
                                    };
                                    e.chooseCoupon(a);
                                }
                            }
                        });
                    },
                    goAddressList: function() {
                        t.navigateTo({
                            url: "/packageAddress/pages/addressList/addressList"
                        });
                    },
                    showWin: function(t) {
                        var e = t.currentTarget.dataset;
                        "gift" == e.type && 0 == this.giftCount || ("coupon" != e.type || this.couponData && 0 != this.couponData.availableCouponList.length) && (this.winState = !0, 
                        this.winType = e.type);
                    },
                    closeWin: function() {
                        this.winState = !1, this.winType = "";
                    },
                    changeGiftshow: function(t) {
                        var e = t.currentTarget.dataset;
                        this.cartGroupData.cartInfo.cartList.forEach(function(t, o) {
                            e.index == o && (t.showState = 1 == e.showstate ? 0 : 1);
                        });
                    },
                    useMemberPrice: function() {
                        (this.isShowMemberPrice = 1, this.couponCode) && (this.couponData.availableCouponList.forEach(function(t, e) {
                            t.showState = 0;
                        }), this.couponCode = 0, this.getCartGroupTotalPrice());
                    },
                    useCouponPrice: function() {
                        this.isShowMemberPrice = 0;
                    },
                    comparePrice: function() {
                        var t = this.totalPriceData;
                        console.log(999, "comparePrice"), 0 == this.chooseMemberPrice || 1 == this.chooseMemberPrice ? t.userMemberPrice && t.userMemberPrice <= t.cartInfo.payPrice ? (t.userMemberSavePrice = t.cartInfo.savePrice + t.cartInfo.payPrice - t.userMemberPrice, 
                        this.useMemberPrice()) : this.useCouponPrice() : 2 == this.chooseMemberPrice && this.useCouponPrice();
                    },
                    chooseCoupon: function(e) {
                        var o = e.currentTarget.dataset, a = this.couponData.availableCouponList;
                        console.log("e", e), t.showLoading({
                            title: "加载中...",
                            mask: !0
                        }), a.forEach(function(t, e) {
                            t.showState = 0, t.code == o.couponcode && (t.showState = 1);
                        }), this.couponCode = o.couponcode, this.getCartGroupTotalPrice(), this.closeWin();
                    },
                    setCoupon: function(t) {
                        var e = t.currentTarget.dataset;
                        e.couponcode && 0 != e.couponcode ? this.chooseMemberPrice = 2 : this.chooseMemberPrice = 1, 
                        this.chooseCoupon(t);
                    },
                    chooseGoodsHandle: function(t) {
                        var e = t.currentTarget.dataset.data, o = t.currentTarget.dataset.index;
                        console.log(e, o), 0 == e.isBuy ? this.chooseGoods(o, e) : this.cancelGoods(o, e);
                    },
                    chooseGoods: function(e, o) {
                        var a = this, r = {
                            parentsId: o.parentsId,
                            goodsId: o.id,
                            cartId: o.cartId,
                            edu24ol_token: !0
                        };
                        t.showLoading({
                            title: "加载中...",
                            mask: !0
                        }), this.$hq.post("".concat(i.default.hostJAPI, "/buy/cart/addPairsToCart"), r).then(function(t) {
                            0 == t.data.status.code && (o.isBuy = 1, a.$set(a.goodsPairsList, e, o), a.getCartGroupTotalPrice());
                        });
                    },
                    cancelGoods: function(t, e) {
                        var o = this, a = {
                            edu24ol_token: !0,
                            parentsId: e.parentsId,
                            goodsId: e.id,
                            cartId: e.cartId,
                            buyType: 1
                        };
                        this.$hq.post("/mobile/v2/cart/delCartDetail", a).then(function(a) {
                            0 == a.data.status.code && (e.isBuy = 0, o.$set(o.goodsPairsList, t, e), o.getCartGroupTotalPrice());
                        });
                    },
                    pay: function() {
                        var e = this;
                        if (this.$refs["c-course-agree"].isCheck()) if (this.cartGroupData && this.cartGroupData.realNun && !this.addressId) t.showToast({
                            title: "请填写收货地址信息",
                            icon: "none"
                        }); else if (1 != this.isPaying) {
                            this.isPaying = !0, t.showLoading({
                                title: "订单提交中...",
                                mask: !0
                            });
                            var o = {
                                cartIds: this.cartIds,
                                groupId: this.groupId,
                                useBalance: this.balance,
                                consigneeId: this.addressId
                            };
                            this.isShowMemberPrice && (o.memberGoodsIds = this.memberGoodsIds.join(",")), this.couponCode && (o.code = this.couponCode), 
                            d.globalData["web_id_".concat(this.groupId)] && (o.web_id = d.globalData["web_id_".concat(this.groupId)]);
                            var a = t.getStorageSync("wxEduCd");
                            a && (o.salesSrc = a), (0, r.createOrder)(o, function(o) {
                                if (t.hideLoading(), e.isPaying = !1, 0 == o.data.status.code) {
                                    var a = o.data.data;
                                    console.log(999, "buyOrderId", a);
                                    var i = {
                                        ordercode: a.buyOrderCode,
                                        groupid: e.groupId,
                                        goodsId: e.goodsId,
                                        buyOrderId: a.buyOrderId
                                    };
                                    e.options.num && (i.num = e.options.num), (0, r.actionSourceSave)(a.buyOrderId, 1), 
                                    e.$refs["c-course-agree"].saveAgreed(a.buyOrderId), e.delivery && (i.delivery = 1, 
                                    i.deliveryId = e.deliveryId);
                                    var n = e.options.gid || 0, s = "/pages/pay/pay?gid=".concat(n, "&") + e.$hq.utils.paramsStringify(i);
                                    console.log(999, 111, s), t.redirectTo({
                                        url: s
                                    });
                                } else if (400500 == o.data.status.code || 400502 == o.data.status.code) {
                                    var d = o.data.data.buyOrderId;
                                    t.showModal({
                                        content: o.data.status.msg,
                                        showCancel: !0,
                                        confirmText: "去支付",
                                        success: function(e) {
                                            var o = "/subpackages/pages/orderDetail/orderDetail?id=".concat(d);
                                            e.confirm && t.redirectTo({
                                                url: o
                                            });
                                        },
                                        fail: function(t) {}
                                    });
                                } else t.showToast({
                                    title: o.data.status.msg,
                                    icon: "none"
                                });
                            });
                        }
                    }
                }
            };
            e.default = c;
        }).call(this, o(1).default);
    },
    58: function(t, e, o) {
        o.r(e);
        var a = o(59), i = o.n(a);
        for (var r in a) "default" !== r && function(t) {
            o.d(e, t, function() {
                return a[t];
            });
        }(r);
        e.default = i.a;
    },
    59: function(t, e, o) {}
}, [ [ 52, "common/runtime", "common/vendor" ] ] ]);