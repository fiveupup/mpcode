var t = getApp(), e = require("../../utils/util"), a = require("../../configs/baseConfig");

require("../../configs/config_" + a.appName);

Page({
    data: {
        title: "",
        url: "",
        id: ""
    },
    onLoad: function(t) {
        this.data.options = t, t.url ? this.setData({
            url: 1 == t.type ? decodeURIComponent(decodeURIComponent(t.url)) : decodeURIComponent(t.url)
        }) : t && 1 == t.share ? wx.redirectTo({
            url: "/pages/findList/findList?share=1&id=" + t.id
        }) : (void 0 !== t.gid && void 0 !== t.gname && (wx.setStorageSync("categoryInfo", {
            gid: t.gid,
            gname: decodeURIComponent(t.gname)
        }), this.setData({
            categoryInfo: {
                gid: t.gid,
                gname: decodeURIComponent(t.gname)
            }
        })), t.id && (this.data.id = t.id, this.getDetail()));
    },
    onShow: function(t) {},
    getDetail: function() {
        var t = this, e = "";
        wx.request({
            url: a.host + "/wxapp/v1/banner/detail",
            data: {
                id: t.data.id,
                org_id: a.orgId
            },
            success: function(a) {
                console.log(a), 0 == a.data.status.code && (e = a.data.data, t.setData({
                    title: e.title || e.sub_title,
                    url: e.url
                }));
            }
        });
    },
    onShareAppMessage: function(a) {
        a.from;
        var i = "/pages/findDetail/findDetail?" + e.paramsStringify(this.data.options), o = "".concat(this.data.title);
        console.log(999, "options", this.data.options);
        var n = "menu" == a.from ? "右上角分享" : "分享按钮";
        return t.appShare({
            belongPage: "发现详情页",
            shareContentID: this.data.id,
            shareButton: n,
            shareContent: this.data.title
        }), i = "".concat(i).concat(t.globalData.uuid ? "&shareId=" + t.globalData.uuid : ""), 
        console.log(9999, i), {
            title: o,
            path: i,
            imageUrl: "https://oss-hqwx-edu24ol.hqwx.com/miniapp/hq_mall/share/find_detail.png",
            success: function(t) {},
            complete: function() {}
        };
    }
});