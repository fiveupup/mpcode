var t, a = require("../../@babel/runtime/helpers/slicedToArray"), e = require("../../@babel/runtime/helpers/defineProperty"), c = getApp(), o = require("../../utils/util"), n = require("../../configs/baseConfig"), s = (require("../../configs/config_" + n.appName), 
[ 1036, 1038, 1069, 1089, 1090 ]);

Page({
    data: (t = {
        token: "",
        groupId: "",
        teacherId: "",
        teacherName: "",
        gid: "",
        isOffiecAccount: 0,
        type: 0,
        showBack: 1,
        scale: 1,
        pageStyle: "",
        canvasStyle: "",
        backStyle: "",
        actionsStyle: "",
        bgStyle: "",
        contentStyle: "",
        backText: "< 返回"
    }, e(t, "token", ""), e(t, "webchatNo", ""), e(t, "path", "/pages/contact/contact"), 
    t),
    onLoad: function(t) {
        if (1 != t.fromType) {
            if (s.indexOf(c.globalData.scene) > -1 && this.setData({
                showBack: 1
            }), console.log(999, "scene", t.scene), t.scene) {
                var e = decodeURIComponent(t.scene).replace("scene=", ""), n = null;
                e.indexOf(",") > 0 && (n = e.split(",")), e.indexOf("&") > 0 && (n = e.split("&"));
                var i = a(n, 9), h = i[0], d = i[1], r = i[2], p = i[3], l = i[4], g = i[5], y = i[6], f = i[7], u = i[8];
                this.data.groupId = h, this.data.teacherId = d, this.data.teacherName = r, this.data.gid = p, 
                this.data.isOffiecAccount = l, this.data.type = g || 0, this.data.token = y || "", 
                this.data.webchatNo = f || "", this.data.imageUrl = u || "";
                var m = "".concat(this.data.path, "?sendCourseTeacher=1&teacherId=").concat(this.data.teacherId, "&type=").concat(this.data.type, "&secondCategory=").concat(this.data.gid, "&token=").concat(this.data.token);
                1 == this.data.isOffiecAccount && (m = "".concat(this.data.path, "?sendOfficialAccount=1&secondCategory=").concat(this.data.gid), 
                this.data.webchatNo && this.data.token && /\w+/g.test(this.data.token) && (m = "".concat(this.data.path, "?createQrcode=1&webchatNo=").concat(this.data.webchatNo, "&token=").concat(this.data.token, "&id=").concat(this.data.teacherId))), 
                this.data.imageUrl && (m = "".concat(this.data.path, "?sendImage=1&imageUrl=").concat(encodeURIComponent(this.data.imageUrl))), 
                console.log(999, "type", this.data.type), console.log(999, "token", this.data.token), 
                this.data.path = m, console.log(999, "path", m), this.setData({
                    path: this.data.path
                });
            }
        } else {
            var b = {
                fromType: 1,
                teacherId: t.teacherId,
                sendTeacherWechat: 1,
                secondCategoryId: t.sid || t.secondCategoryId,
                secondCategoryName: t.sname || t.secondCategoryName
            };
            this.setData({
                showBack: 0,
                path: "".concat(this.data.path, "?").concat(o.paramsStringify(b))
            });
        }
    },
    drawAnimation: function() {
        var t = wx.createCanvasContext("canvas"), a = wx.getSystemInfoSync(), e = a.screenWidth, c = a.screenHeight, o = "", n = "", s = "", i = "", h = (e / 750).toFixed(2);
        c < 780 ? (o = "bottom:48rpx;", n = "top:1060rpx;", s = "top:-40rpx;") : (o = "bottom:116rpx;", 
        n = "top:1174rpx;", s = "top:0", i = "margin-top:234rpx;"), this.setData({
            canvasStyle: "width : ".concat(438 * h, "px; height:").concat(712 * h, "px"),
            pageStyle: "height: ".concat(c, "px;"),
            actionsStyle: o,
            backStyle: n,
            bgStyle: s,
            contentStyle: i
        }), t.canvas = {
            width: 438 * h,
            height: 712 * h
        }, lottie.loadAnimation({
            renderer: "canvas",
            loop: !0,
            autoplay: !0,
            path: "https://edu24ol.bs2cdn.98809.com/1604911866_5fa902fa74a7c.json",
            rendererSettings: {
                context: t,
                clearCanvas: !0
            }
        });
    },
    launchAppError: function(t) {
        console.log(999, "launchAppError", t);
    },
    addTeacher: function() {}
});