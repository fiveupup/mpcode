getApp();

var t = require("../../utils/util"), e = require("../../configs/baseConfig"), a = (require("../../configs/config_" + e.appName), 
require("../../utils/request"));

Page({
    data: {
        currentTab: "0",
        bottomMenuState: !1,
        groupData: "",
        domCourse: "",
        isFixed: !1,
        tabTop: "",
        domTab: "",
        deltaY: 0,
        scrollTop: "",
        timer: null
    },
    onLoad: function(t) {
        this.getMiniappRecommendGroupData();
    },
    onHide: function(t) {
        this.data.timer && clearTimeout(this.data.timer);
    },
    onUnload: function() {
        this.data.timer && clearTimeout(this.data.timer);
    },
    changeTab: function(t) {
        var e = t.currentTarget.dataset, a = this.data.domCourse;
        this.setData({
            isFixed: !0,
            scrollTop: a[e.index],
            currentTab: "".concat(e.index)
        });
    },
    showBottomMenu: function(t) {
        this.setData({
            bottomMenuState: !0
        });
    },
    oncloseBottomMenu: function(t) {
        var e = t.detail;
        if (this.setData({
            bottomMenuState: !1
        }), t && e) {
            var a = this.data.domCourse;
            this.setData({
                isFixed: !0,
                scrollTop: a[e.index],
                currentTab: e.index
            });
        }
    },
    getMiniappRecommendGroupData: function() {
        var e = this;
        t.showLoading(), a.getMiniappRecommendGroup({}, function(a) {
            if (0 == a.data.status.code) {
                var i = a.data.data;
                e.setData({
                    groupData: i
                }, function() {
                    e.querySelectorQuery();
                }), t.hideLoading();
            }
        });
    },
    querySelectorQuery: function() {
        var t = this, e = wx.createSelectorQuery();
        e.selectAll(".banner-tab").boundingClientRect(function(e) {
            t.setData({
                domTab: e[0].height
            });
        }).exec(), e.selectAll(".mod-course").boundingClientRect(function(e) {
            for (var a = [], i = 0; i < e.length; i++) a.push(e[i].top - 2 * t.data.domTab);
            t.setData({
                domCourse: a
            });
        }).exec();
    },
    goCourseDetail: function(t) {
        var e = t.currentTarget.dataset;
        wx.navigateTo({
            url: "/pages/courseDetail/courseDetail?id=".concat(e.id)
        });
    },
    scroll: function(t) {
        this.data.timer && clearTimeout(this.data.timer), this.data.timer = setTimeout(function() {
            this.scaleScroll(t);
        }.bind(this), 10);
    },
    scaleScroll: function(t) {
        var e = t.detail.scrollTop, a = this.data.currentTab || 0, i = this.data.domCourse;
        if (e > i[0] ? this.setData({
            isFixed: !0
        }) : this.setData({
            isFixed: !1
        }), e >= 0 && e <= i[0]) a = 0; else if (e >= i[i.length - 1]) a = i.length - 1; else for (var o = 1; o < i.length; o++) e >= i[o - 1] && e < i[o] && (a = o - 1);
        this.setData({
            currentTab: a
        });
    },
    onShareAppMessage: function(t) {}
});