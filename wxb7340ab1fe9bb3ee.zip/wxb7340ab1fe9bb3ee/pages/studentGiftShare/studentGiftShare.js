var t = getApp(), a = require("../../utils/util"), e = require("../../configs/baseConfig"), i = (require("../../configs/config_" + e.appName), 
require("../../utils/allGid"), require("../template/template")), o = require("../../utils/request");

Page({
    data: {
        token: "",
        winShareState: !1,
        gid: "",
        gname: "",
        goodsId: "",
        groupId: "",
        goodsName: "",
        uid: "",
        giftGoodsListDatas: null,
        drawSuccess: !1
    },
    onLoad: function(a) {
        t.setWebIdToStorage(a.web_id), this.data.uid = wx.getStorageSync("hqUserInfo").uid, 
        this.data.token = wx.getStorageSync(e.tokenKey) || "", this.data.gid = a && a.gid ? a.gid : 0, 
        this.data.gname = a && a.gname ? a.gname : "", this.getGiftGoodsList();
    },
    getGiftGoodsList: function() {
        var t = this;
        a.showLoading(), o.getGiftGoodsList({
            token: this.data.token,
            gid: this.data.gid,
            type: 2
        }, function(e) {
            if (0 == e.data.status.code) {
                var i = e.data.data;
                i.forEach(function(t, e) {
                    t.selected = !1, t.teacherList && t.teacherList.length > 0 && t.teacherList.forEach(function(t, e) {
                        a.getStrLength(t.teacherName) >= 8 && (t.teacherName = t.teacherName.slice(0, 4));
                    });
                }), t.setData({
                    giftGoodsListDatas: i
                });
            }
            a.hideLoading();
        });
    },
    chooseCourse: function(t) {
        var a = t.detail;
        this.data.goodsId = a.goodsId, this.data.groupId = a.groupId, this.data.goodsName = a.name, 
        this.setData({
            goodsId: this.data.goodsId,
            goodsName: this.data.goodsName
        });
    },
    notice: function() {
        a.showToast2("请先选择一门课");
    },
    getCourse: function() {
        var t = this;
        a.showLoading(), o.shareGiftDraw({
            token: this.data.token,
            gid: this.data.groupId,
            id: this.data.goodsId,
            uid: this.data.uid
        }, function(e) {
            0 == e.data.status.code && (t.data.drawSuccess = !0), t.setData({
                winShareState: !0,
                drawSuccess: t.data.drawSuccess
            }), a.hideLoading();
        });
    },
    goIndex: function() {
        wx.redirectTo({
            url: "/pages/index/index"
        });
    },
    navigateToOnlive: function() {
        i.navigateToMiniProgramPro(3, this.data.gid, this.data.gname);
    },
    onShareAppMessage: function(t) {
        var a = "/pages/courseShare/courseShare?uid=".concat(this.data.uid, "&goodsId=").concat(this.data.goodsId, "&groupId=").concat(this.data.groupId), e = wx.getStorageSync("webIdInfo");
        return e && e.web_id && (a += "&web_id=".concat(e.web_id)), console.log(999, "path", a), 
        this.setData({
            winShareState: !0,
            drawSuccess: 1
        }), {
            title: "环球网校·职业教育考证培训，精品好课，尽在其中",
            path: a,
            imageUrl: "",
            success: function(t) {},
            complete: function() {}
        };
    }
});