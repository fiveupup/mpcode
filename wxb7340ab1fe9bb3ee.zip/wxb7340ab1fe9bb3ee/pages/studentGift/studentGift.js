var t = getApp(), a = require("../../utils/util"), e = require("../../configs/baseConfig"), i = (require("../../configs/config_" + e.appName), 
require("../../utils/allGid")), o = require("../../utils/request");

Page({
    data: {
        gid: "",
        gname: "",
        token: "",
        categoryInfo: {},
        couponListDatas: null,
        giftGoodsListDatas: null,
        couponListIds: [],
        goodsListIds: [],
        triggerSource: "",
        logining: 0,
        giftName: "",
        winState: !1,
        winTitle: "",
        winContent: ""
    },
    onLoad: function(o) {
        var n = this, s = "", g = wx.getStorageSync("categoryInfo");
        if (t.setWebIdToStorage(o.web_id), o && o.gid) {
            for (var d = 0; d < i.length; d++) if (i[d].id == o.gid) {
                s = i[d].name;
                break;
            }
            this.setData({
                categoryInfo: {
                    gid: o.gid,
                    gname: s
                },
                gid: o.gid,
                gname: s
            }), g || wx.setStorageSync("categoryInfo", {
                gid: o.gid,
                gname: s
            });
        } else this.data.categoryInfo = g, this.data.gid = g.gid, this.data.gname = g.gname, 
        this.setData({
            gname: this.data.gname
        });
        if (wx.getStorageSync("studentGiftType")) {
            var r = wx.getStorageSync("studentGiftType");
            this.data.triggerSource = "popup" == r ? "首页弹窗-小程序" : "首页浮标-小程序";
        }
        this.data.token = wx.getStorageSync(e.tokenKey), o && "login" == o.type && (this.data.logining = 1, 
        a.showLoading({
            mask: "true"
        }), wx.getStorage({
            key: "giftLoginDatas",
            success: function(t) {
                if ("getStorage:ok" == t.errMsg) {
                    var a = t.data;
                    return n.data.couponListIds = a.couponList, n.data.goodsListIds = a.goodsList, void n.giftDraw();
                }
            }
        })), this.getGiftCouponList();
    },
    changeGid: function() {
        wx.redirectTo({
            url: "/pages/exam/exam?sourcePath=/pages/studentGift/studentGift"
        });
    },
    getUserInfoData: function(a) {
        t.getUserInfo(function() {}, this);
    },
    getGiftCouponList: function() {
        var t = this;
        0 == this.data.logining && a.showLoading(), o.getGiftCouponList({
            token: this.data.token
        }, function(a) {
            if (0 == a.data.status.code) {
                var e = a.data.data, i = [];
                e.forEach(function(t, a) {
                    i.push(t.couponId);
                }), t.data.couponListIds = i, t.setData({
                    couponListDatas: e
                });
            }
            t.getGiftGoodsList();
        });
    },
    getGiftGoodsList: function() {
        var t = this, i = this;
        o.getGiftGoodsList({
            token: wx.getStorageSync(e.tokenKey),
            gid: this.data.gid,
            type: 1
        }, function(e) {
            if (0 == e.data.status.code) {
                var o = e.data.data, n = [];
                if (o.forEach(function(t, e) {
                    n.push(t.goodsId), t.teacherList && t.teacherList.length > 0 && t.teacherList.forEach(function(t, e) {
                        a.getStrLength(t.teacherName) >= 8 && (t.teacherName = t.teacherName.slice(0, 4));
                    });
                }), o && o.length > 0 && (i.data.giftName = o[0].giftName || ""), 0 == o.length && (!t.data.couponList || 0 == i.data.couponList.length)) return i.setData({
                    winState: !0,
                    winTitle: "抱歉",
                    winContent: "礼包奖品已领完，请稍后再试。"
                }), void a.hideLoading();
                i.data.goodsListIds = n, i.setData({
                    giftGoodsListDatas: o
                });
            }
            0 == t.data.logining && a.hideLoading();
        });
    },
    giftDraw: function() {
        var i = this;
        if (0 != this.data.goodsListIds.length) {
            if (0 == this.data.logining && a.showLoading(), !this.data.token && 0 == this.data.logining) return a.showToast2("请先登录"), 
            void wx.setStorage({
                key: "giftLoginDatas",
                data: {
                    couponList: this.data.couponListIds || {},
                    goodsList: this.data.goodsListIds || {}
                },
                success: function() {
                    setTimeout(function() {
                        a.hideLoading(), wx.redirectTo({
                            url: "/pages/login/login?sourcePath=" + encodeURIComponent("/pages/studentGift/studentGift?type=login&gid=".concat(i.data.categoryInfo.gid))
                        });
                    }, 1500);
                }
            });
            o.giftDraw({
                token: wx.getStorageSync(e.tokenKey),
                couponList: String(this.data.couponListIds),
                goodsList: String(this.data.goodsListIds),
                gid: this.data.categoryInfo.gid
            }, function(e) {
                if (a.hideLoading(), 0 == e.data.status.code) a.showToast2("领取成功"), a.reportEvent(t, "NewUserGiftPack", {
                    triggerSource: i.data.triggerSource,
                    testIntention: i.data.gid,
                    giftExamination: i.data.giftName
                }), setTimeout(function() {
                    var t = wx.getStorageSync("webIdInfo"), a = "/pages/studentGiftShare/studentGiftShare?gid=".concat(i.data.categoryInfo.gid, "&gname=").concat(i.data.categoryInfo.gname);
                    t && t.web_id && (a += "&web_id=".concat(t.web_id)), console.log(999, "path", a), 
                    wx.redirectTo({
                        url: a
                    });
                }, 2500); else if (40042 == e.data.status.code) a.showToast2("用户信息已过期，请重新登录"), setTimeout(function() {
                    a.hideLoading(), wx.redirectTo({
                        url: "/pages/login/login?sourcePath=" + encodeURIComponent("/pages/studentGift/studentGift?type=login&gid=".concat(i.data.categoryInfo.gid))
                    });
                }, 2500); else {
                    var o = 1401 == e.data.status.code ? "亲爱的用户" : "抱歉";
                    e.data.status.code;
                    i.setData({
                        winState: !0,
                        winTitle: o,
                        winContent: e.data.status.msg
                    });
                }
            });
        } else a.showToast2("请先选择考试");
    },
    onShareAppMessage: function(t) {}
});