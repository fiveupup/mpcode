getApp();

var e = require("../../configs/baseConfig"), a = {
    navigateToMiniProgramPro: function(a, r, o, i) {
        var t = "", s = "", n = "";
        1 != a && 2 != a || (s = "wxae3a9748da999008", n = "&share=1", 1 == a ? t = "/pages/dayList/dayList" : 2 == a && (t = "/pages/myCourse/myCourse")), 
        3 != a && 4 != a || (s = "wx890b8e807c46f703", 3 == a ? t = "/pages/myCourse/myCourse" : 4 == a && (t = "/pages/myActivityDoc/myActivityDoc")), 
        wx.navigateToMiniProgram({
            appId: s,
            path: t + "?gid=" + r + "&gname=" + o + "&web_id=" + i + n,
            envVersion: e.envVersion,
            extraData: {
                gid: r,
                gname: o,
                web_id: i
            },
            success: function() {
                console.log("appid", s), console.log(t, r, o, i);
            }
        });
    },
    btmBarCreateFormId: function(e) {
        wx.redirectTo({
            url: e.currentTarget.dataset.url
        });
    }
};

module.exports = a;