var e = getApp(), t = require("../../utils/util"), a = require("../../configs/baseConfig"), o = require("../../configs/config_" + a.appName);

Page({
    data: {
        phone: "",
        smsCode: "",
        warnText: "",
        showWarn: !1,
        showPhoneDel: !1,
        showCodeDel: !1,
        abletoSendCode: !0,
        interval: 60,
        codeMsg: "获取验证码",
        errMsg: "",
        sourcePath: "/pages/user/user",
        sourceParams: "",
        sourceParamsJSONstr: "",
        disabled: !0,
        isBind: 1,
        veriflyErr: !1,
        phoneErr: !1
    },
    onLoad: function(e) {
        console.log("onLoad", e), this.data.firstPType = t.getUrlParams().firstPType || "", 
        wx.getStorageSync("categoryInfoShortID") && wx.getStorageSync("categoryInfoShortID").gid ? this.data.categoryInfo = wx.getStorageSync("categoryInfoShortID") || {} : this.data.categoryInfo = wx.getStorageSync("categoryInfo") || {}, 
        this.data.webIdInfo = wx.getStorageSync("webIdInfo") || {}, wx.removeStorageSync("hqUserInfo"), 
        wx.removeStorageSync(a.tokenKey), this.data.sourcePath = null != e.sourcePath && decodeURIComponent(e.sourcePath) || this.data.sourcePath;
    },
    phoneInput: function(e) {
        var t = !1;
        this.data.phone = e.detail.value, t = this.data.phone.length > 0, this.data.phone.length < 1 || this.data.smsCode.length < 1 ? this.data.disabled = !0 : this.data.disabled = !1, 
        this.setData({
            phoneErr: !1,
            disabled: this.data.disabled,
            showPhoneDel: t
        });
    },
    smscodeInput: function(e) {
        var t = !1;
        this.data.smsCode = e.detail.value, t = this.data.smsCode.length > 0, this.data.phone.length < 1 || this.data.smsCode.length < 1 ? this.data.disabled = !0 : this.data.disabled = !1, 
        this.setData({
            veriflyErr: !1,
            disabled: this.data.disabled,
            showCodeDel: t
        });
    },
    clearValue: function(e) {
        switch (e.target.dataset.type) {
          case "phone":
            this.setData({
                phone: "",
                showPhoneDel: !1
            });
            break;

          case "smsCode":
            this.setData({
                smsCode: "",
                showCodeDel: !1
            });
        }
    },
    getSMSCode: function() {
        var s = this;
        /^1\d{10}/.test(s.data.phone) ? (t.reportEvent(e, "getSMSCode", {
            serviceType: "短信登录"
        }), s.data.abletoSendCode && (t.showLoading({
            title: "验证码获取中...",
            mask: !0
        }), e.getUserInfo(function() {
            wx.request({
                url: a.host + "/wxapp/v1/user/sms",
                method: "POST",
                dataType: "json",
                header: {
                    "content-type": "application/x-www-form-urlencoded"
                },
                data: {
                    appid: o.appid,
                    org_id: a.orgId,
                    platform: a.platform,
                    encryptedData: encodeURIComponent(e.globalData.appBaseInfo.encryptedData),
                    code: encodeURIComponent(e.globalData.code),
                    iv: encodeURIComponent(e.globalData.appBaseInfo.iv),
                    sessionKey: encodeURIComponent(wx.getStorageSync("sessionKey")),
                    phone: s.data.phone,
                    optStr: "login",
                    distinct_id: o.sdid
                },
                success: function(e) {
                    console.log("getSMSCode", e), 0 == e.data.status.code ? (t.showToast2("验证码已发送~"), 
                    s.countDown()) : (s.showWarn(e.data.status.msg), t.hideLoading());
                }
            });
        }))) : s.showWarn("请输入正确的手机号!");
    },
    countDown: function() {
        var e = this, t = this, a = setInterval(function() {
            t.data.interval--, e.setData({
                abletoSendCode: !1,
                codeMsg: "(" + t.data.interval + "s)重新获取"
            }), 0 == t.data.interval && (clearInterval(a), t.data.interval = 60, t.setData({
                abletoSendCode: !0,
                codeMsg: "获取验证码"
            }));
        }, 1e3);
    },
    showWarn: function(e) {
        var t = this;
        t.setData({
            showWarn: !0,
            errMsg: e
        }), setTimeout(function() {
            t.setData({
                showWarn: !1
            });
        }, 4e3);
    },
    submitLogin: function() {
        var s = this;
        if (s.data.phone.length < 1) s.showWarn("手机号不能为空！"); else if (/^1\d{10}/.test(s.data.phone)) if (s.data.smsCode.length < 1) s.showWarn("验证码不能为空！"); else if (/\d{6}/.test(s.data.smsCode)) {
            t.showLoading({
                title: "登录中...",
                mask: !0
            }), t.reportEvent(e, "clickSMSLoginButton", {});
            var n = wx.getStorageSync("zhuliLogin") ? null : this.data.categoryInfo.gid, d = wx.getStorageSync("zhuliLogin") ? 424 : o.srcType;
            e.getUserInfo(function() {
                var r = wx.getStorageSync("regUrlObj"), i = r ? r.regUrl : "", c = wx.getStorageSync("regtype") || "", g = e.setExtProperties();
                wx.request({
                    url: a.host + "/wxapp/v1/user/login",
                    method: "POST",
                    dataType: "json",
                    header: {
                        "content-type": "application/x-www-form-urlencoded"
                    },
                    data: {
                        srcType: d,
                        firstPType: s.data.firstPType || o.firstPType,
                        lastPType: o.lastPType,
                        isBind: s.data.isBind,
                        appid: o.appid,
                        org_id: a.orgId,
                        platform: a.platform,
                        encryptedData: encodeURIComponent(e.globalData.appBaseInfo.encryptedData),
                        code: encodeURIComponent(e.globalData.code),
                        iv: encodeURIComponent(e.globalData.appBaseInfo.iv),
                        sessionKey: encodeURIComponent(wx.getStorageSync("sessionKey")),
                        name: s.data.phone,
                        smsCode: s.data.smsCode,
                        chId: s.data.webIdInfo.web_id || null,
                        sortId: n || null,
                        distinct_id: o.sdid,
                        regUrl: i,
                        regtype: c,
                        groupId: wx.getStorageSync("trainingGroupId") || "",
                        extProperties: g
                    },
                    success: function(o) {
                        switch (console.log("submitLogin", o), parseInt(o.data.status.code)) {
                          case 0:
                            wx.removeStorageSync("zhuliLogin"), wx.removeStorageSync("regtype"), t.userBindReport(e, o.data.data.uid), 
                            wx.getStorageSync("zhuliReg") && (wx.removeStorageSync("zhuliReg"), o.data.data.loginReg && wx.setStorageSync("loginReg", 1)), 
                            wx.setStorage({
                                key: "hqUserInfo",
                                data: o.data.data
                            }), wx.setStorage({
                                key: a.tokenTimeStamp,
                                data: t.timeStamp()
                            }), wx.setStorage({
                                key: a.tokenKey,
                                data: o.data.data.token,
                                success: function() {
                                    wx.reLaunch({
                                        url: s.data.sourcePath
                                    });
                                }
                            });
                            break;

                          case 232:
                            s.setData({
                                veriflyErr: !0
                            }), s.showWarn(o.data.status.msg);
                            break;

                          case 211:
                          case 201:
                            s.setData({
                                phoneErr: !0
                            }), s.showWarn(o.data.status.msg);
                            break;

                          case 239:
                            var n = o.data.data;
                            wx.showModal({
                                title: "提示",
                                content: "当前账号已绑定其它微信号，继续登录需解除已有绑定。是否继续解绑操作？",
                                cancelText: "放弃",
                                confirmText: "继续解绑",
                                success: function(e) {
                                    e.confirm ? (wx.setStorage({
                                        key: "hqUserInfo",
                                        data: n
                                    }), wx.setStorage({
                                        key: a.tokenKey,
                                        data: n.token
                                    }), wx.redirectTo({
                                        url: "/pages/unbindAccount/unbindAccount"
                                    })) : e.cancel && t.showToast2("未完成解绑，登录失败。");
                                }
                            });
                            break;

                          default:
                            s.showWarn(o.data.status.msg);
                        }
                        t.hideLoading();
                    }
                });
            });
        } else s.showWarn("验证码不正确！"); else s.showWarn("您的手机号无效或不支持国外手机号码！");
    }
});