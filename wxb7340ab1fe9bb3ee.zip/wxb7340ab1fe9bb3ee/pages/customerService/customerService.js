require("../../uni-bootstrap.js"), (global.webpackJsonp = global.webpackJsonp || []).push([ [ "pages/customerService/customerService" ], {
    164: function(e, n, t) {
        (function(e) {
            t(4);
            n(t(2));
            function n(e) {
                return e && e.__esModule ? e : {
                    default: e
                };
            }
            e(n(t(165)).default);
        }).call(this, t(1).createPage);
    },
    165: function(e, n, t) {
        t.r(n);
        var r = t(166), u = t(168);
        for (var c in u) "default" !== c && function(e) {
            t.d(n, e, function() {
                return u[e];
            });
        }(c);
        t(170);
        var o = t(10), a = Object(o.default)(u.default, r.render, r.staticRenderFns, !1, null, "aa3dfa14", null, !1, r.components, void 0);
        a.options.__file = "pages/customerService/customerService.vue", n.default = a.exports;
    },
    166: function(e, n, t) {
        t.r(n);
        var r = t(167);
        t.d(n, "render", function() {
            return r.render;
        }), t.d(n, "staticRenderFns", function() {
            return r.staticRenderFns;
        }), t.d(n, "recyclableRender", function() {
            return r.recyclableRender;
        }), t.d(n, "components", function() {
            return r.components;
        });
    },
    167: function(e, n, t) {
        t.r(n), t.d(n, "render", function() {
            return r;
        }), t.d(n, "staticRenderFns", function() {
            return c;
        }), t.d(n, "recyclableRender", function() {
            return u;
        }), t.d(n, "components", function() {});
        var r = function() {
            var e = this.$createElement;
            this._self._c;
        }, u = !1, c = [];
        r._withStripped = !0;
    },
    168: function(e, n, t) {
        t.r(n);
        var r = t(169), u = t.n(r);
        for (var c in r) "default" !== c && function(e) {
            t.d(n, e, function() {
                return r[e];
            });
        }(c);
        n.default = u.a;
    },
    169: function(e, n, t) {
        Object.defineProperty(n, "__esModule", {
            value: !0
        }), n.default = void 0;
        n.default = {
            data: function() {
                return {
                    path: ""
                };
            },
            onLoad: function(e) {
                var n = e.imageUrl;
                this.path = "/pages/customerService/customerService?sendImage=1&imageUrl=".concat(n);
            }
        };
    },
    170: function(e, n, t) {
        t.r(n);
        var r = t(171), u = t.n(r);
        for (var c in r) "default" !== c && function(e) {
            t.d(n, e, function() {
                return r[e];
            });
        }(c);
        n.default = u.a;
    },
    171: function(e, n, t) {}
}, [ [ 164, "common/runtime", "common/vendor" ] ] ]);