var e = getApp();

Page({
    data: {},
    onLoad: function(o) {
        if (o = e.customDecode(o), wx.showLoading({
            title: "跳转中..."
        }), o.path) {
            var t = o.query ? "".concat(o.path, "?").concat(o.query, "&__from=web") : "".concat(o.path, "?__from=web");
            t = 0 == t.indexOf("/") ? t : "/" + t, wx.redirectTo({
                url: t,
                success: function() {
                    wx.hideLoading();
                },
                fail: function(e) {
                    wx.hideLoading(), console.log("/pages/outside/outside:", e), wx.redirectTo({
                        url: "/pages/index/index"
                    });
                }
            });
        }
    }
});