require("../../uni-bootstrap.js"), (global.webpackJsonp = global.webpackJsonp || []).push([ [ "pages/addCodeAuthorize/addCodeAuthorize" ], {
    148: function(t, e, n) {
        (function(t) {
            n(4);
            e(n(2));
            function e(t) {
                return t && t.__esModule ? t : {
                    default: t
                };
            }
            t(e(n(149)).default);
        }).call(this, n(1).createPage);
    },
    149: function(t, e, n) {
        n.r(e);
        var o = n(150), i = n(152);
        for (var a in i) "default" !== a && function(t) {
            n.d(e, t, function() {
                return i[t];
            });
        }(a);
        n(154);
        var r = n(10), d = Object(r.default)(i.default, o.render, o.staticRenderFns, !1, null, "79d1aa34", null, !1, o.components, void 0);
        d.options.__file = "pages/addCodeAuthorize/addCodeAuthorize.vue", e.default = d.exports;
    },
    150: function(t, e, n) {
        n.r(e);
        var o = n(151);
        n.d(e, "render", function() {
            return o.render;
        }), n.d(e, "staticRenderFns", function() {
            return o.staticRenderFns;
        }), n.d(e, "recyclableRender", function() {
            return o.recyclableRender;
        }), n.d(e, "components", function() {
            return o.components;
        });
    },
    151: function(t, e, n) {
        n.r(e), n.d(e, "render", function() {
            return i;
        }), n.d(e, "staticRenderFns", function() {
            return r;
        }), n.d(e, "recyclableRender", function() {
            return a;
        }), n.d(e, "components", function() {
            return o;
        });
        var o = {
            cNavTop: function() {
                return n.e("components/c-nav-top/c-nav-top").then(n.bind(null, 409));
            }
        }, i = function() {
            var t = this.$createElement;
            this._self._c;
        }, a = !1, r = [];
        i._withStripped = !0;
    },
    152: function(t, e, n) {
        n.r(e);
        var o = n(153), i = n.n(o);
        for (var a in o) "default" !== a && function(t) {
            n.d(e, t, function() {
                return o[t];
            });
        }(a);
        e.default = i.a;
    },
    153: function(t, e, n) {
        (function(t) {
            Object.defineProperty(e, "__esModule", {
                value: !0
            }), e.default = void 0;
            var o, i = (o = n(20)) && o.__esModule ? o : {
                default: o
            }, a = n(22), r = n(21);
            var d = {
                data: function() {
                    return {
                        options: "",
                        isiPhoneX: !1
                    };
                },
                onLoad: function(e) {
                    this.options = e, this.isiPhoneX = (0, a.fixIphoneX)(), this.matchScene(), t.getStorageSync("hq_token") && (this.goPath = 1);
                },
                methods: {
                    getStringQuery: function(t, e) {
                        var n = new RegExp("(^|&)" + e + "=([^&]*)(&|$)", "i"), o = t.match(n);
                        return null != o ? o[2] : null;
                    },
                    matchParams: function(t) {
                        var e = t.split("&"), n = {};
                        e.forEach(function(t) {
                            var e = t.split("=");
                            n[e[0]] = e[1];
                        }), Object.assign(this.options, n), console.log(9999, "options", this.options);
                    },
                    matchScene: function() {
                        var t = decodeURIComponent(this.options.scene);
                        t && (this.options.id = this.getStringQuery(t, "id"), this.getUrlParamById());
                    },
                    getUrlParamById: function() {
                        var e = this;
                        t.showLoading();
                        var n = {
                            id: this.options.id
                        };
                        this.$hq.get("".concat(i.default.hostJAPI, "/crm/getUrlParamById"), n).then(function(n) {
                            if (0 == n.data.status.code) {
                                var o = n.data.data;
                                e.matchParams(o), e.categoryInfo = {
                                    gid: e.options.gid,
                                    gname: (0, a.getGName)(e.options.gid)
                                }, t.setStorageSync("categoryInfo", e.categoryInfo), e.getWechatQr();
                            }
                        });
                    },
                    getWechatQr: function() {
                        var e = this, n = {
                            resource: this.options.resource,
                            resourceIds: this.options.resourceIds,
                            ruleType: this.options.ruleType,
                            secondCategory: this.options.gid,
                            terminalPage: this.options.terminalPage,
                            terminalType: this.options.terminalType,
                            platform: this.options.platform || "wx_mini"
                        };
                        this.$hq.get("".concat(i.default.hostJAPI, "/crm/getWechatQr"), n).then(function(n) {
                            if (0 == n.data.status.code) {
                                var o = n.data.data;
                                t.setStorageSync("wxQrcodeInfo", o), e.path = "/pages/addCode/addCode?storage=1&terminalPage=".concat(e.options.terminalPage), 
                                t.hideLoading(), e.goPath && e.goAddCode();
                            }
                        });
                    },
                    getPhoneNumberCB: function(e) {
                        var n = this;
                        if (e.detail.iv) {
                            t.showLoading();
                            var o = this.options, i = {
                                modEncryptedData: e.detail.encryptedData,
                                modIv: e.detail.iv,
                                sortId: o.gid || 0,
                                chId: o.webid || null,
                                srcType: o.srcType || null,
                                firstPType: o.firstPType || null,
                                lastPType: o.lastPType || null
                            };
                            (0, r.wxMobRegister)(i, function(e) {
                                switch (t.hideLoading(), parseInt(e.data.status.code)) {
                                  case 10001:
                                    (0, r.profile)(function() {
                                        n.goAddCode();
                                    });
                                }
                            });
                        } else t.showToast({
                            title: "您已经取消登录~",
                            icon: "none"
                        });
                    },
                    goAddCode: function() {
                        t.redirectTo({
                            url: this.path
                        });
                    }
                }
            };
            e.default = d;
        }).call(this, n(1).default);
    },
    154: function(t, e, n) {
        n.r(e);
        var o = n(155), i = n.n(o);
        for (var a in o) "default" !== a && function(t) {
            n.d(e, t, function() {
                return o[t];
            });
        }(a);
        e.default = i.a;
    },
    155: function(t, e, n) {}
}, [ [ 148, "common/runtime", "common/vendor" ] ] ]);