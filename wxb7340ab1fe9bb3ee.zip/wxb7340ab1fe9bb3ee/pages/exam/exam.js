require("../../uni-bootstrap.js"), (global.webpackJsonp = global.webpackJsonp || []).push([ [ "pages/exam/exam" ], {
    26: function(t, e, n) {
        (function(t) {
            n(4);
            e(n(2));
            function e(t) {
                return t && t.__esModule ? t : {
                    default: t
                };
            }
            t(e(n(27)).default);
        }).call(this, n(1).createPage);
    },
    27: function(t, e, n) {
        n.r(e);
        var a = n(28), o = n(30);
        for (var i in o) "default" !== i && function(t) {
            n.d(e, t, function() {
                return o[t];
            });
        }(i);
        n(32);
        var r = n(10), c = Object(r.default)(o.default, a.render, a.staticRenderFns, !1, null, null, null, !1, a.components, void 0);
        c.options.__file = "pages/exam/exam.vue", e.default = c.exports;
    },
    28: function(t, e, n) {
        n.r(e);
        var a = n(29);
        n.d(e, "render", function() {
            return a.render;
        }), n.d(e, "staticRenderFns", function() {
            return a.staticRenderFns;
        }), n.d(e, "recyclableRender", function() {
            return a.recyclableRender;
        }), n.d(e, "components", function() {
            return a.components;
        });
    },
    29: function(t, e, n) {
        n.r(e), n.d(e, "render", function() {
            return a;
        }), n.d(e, "staticRenderFns", function() {
            return i;
        }), n.d(e, "recyclableRender", function() {
            return o;
        }), n.d(e, "components", function() {});
        var a = function() {
            var t = this.$createElement;
            this._self._c;
        }, o = !1, i = [];
        a._withStripped = !0;
    },
    30: function(t, e, n) {
        n.r(e);
        var a = n(31), o = n.n(a);
        for (var i in a) "default" !== i && function(t) {
            n.d(e, t, function() {
                return a[t];
            });
        }(i);
        e.default = o.a;
    },
    31: function(t, e, n) {
        (function(t) {
            Object.defineProperty(e, "__esModule", {
                value: !0
            }), e.default = void 0;
            (a = n(20)) && a.__esModule;
            var a, o = n(21);
            var i = {
                data: function() {
                    return {
                        token: "",
                        categoryInfo: {},
                        step: 0,
                        sourcePath: "",
                        intentionData: [],
                        favorateData: [],
                        groupData: [],
                        confirmBtnClass: "disabled",
                        confirmBtnText: "选好了"
                    };
                },
                onLoad: function(e) {
                    e && e.sourcePath && (this.sourcePath = decodeURIComponent(e.sourcePath)), this.categoryInfo = t.getStorageSync("categoryInfo"), 
                    this.token = t.getStorageSync("hq_token"), this.step = e.step || 0, this.confirmBtnText = e && 1 == e.step ? "下一步" : "选好了", 
                    this.initGroupCategoryData();
                },
                onShow: function() {},
                methods: {
                    initGroupCategoryData: function() {
                        t.getStorageSync("groupCategoryData") ? (this.groupData = t.getStorageSync("groupCategoryData"), 
                        2 == this.step && this.initGroupDataState(), 2 != this.step && this.getGroupCategoryData()) : (t.showLoading({
                            title: "加载中..."
                        }), this.getGroupCategoryData());
                    },
                    getGroupCategoryData: function() {
                        var e = this;
                        (0, o.getGroupCategory)({}, function(n) {
                            if (0 == n.data.status.code) {
                                var a = n.data.data, o = a.groupCategoryList, i = a.normalCategoryList, r = [];
                                o.forEach(function(n, a) {
                                    for (var o in i) if (n.groupId == o) {
                                        var c = i[o];
                                        c.forEach(function(a, o) {
                                            a.groupName = 17 == n.groupId ? "".concat(n.groupName) : "".concat(n.groupName, "-").concat(a.name), 
                                            a.unitList.forEach(function(n, a) {
                                                if (2 == e.step) {
                                                    var o = t.getStorageSync("categoryInfo");
                                                    n.categoryId == o.gid ? (n.state = -1, n.intentionData = 1) : n.state = 0;
                                                } else n.state = 0;
                                            });
                                        }), r.push({
                                            groupName: n.groupName,
                                            groupId: n.groupId,
                                            list: c
                                        });
                                    }
                                }), e.groupData = r, t.setStorageSync("groupCategoryData", r);
                            }
                            t.hideLoading();
                        });
                    },
                    choose: function(t) {
                        var e = this, n = t.currentTarget.dataset, a = this.groupData;
                        a.forEach(function(t, a) {
                            t.list.forEach(function(t, a) {
                                t.unitList.forEach(function(t, a) {
                                    2 == e.step ? t.categoryId == n.gid && (0 == t.state ? (e.favorateData.push({
                                        gname: n.gname,
                                        gid: n.gid
                                    }), t.state = 1) : 1 == t.state && (e.favorateData.forEach(function(n, a) {
                                        n.gid == t.categoryId && e.favorateData.splice(a, 1);
                                    }), t.state = 0)) : t.categoryId == n.gid ? (t.state = !t.state, 0 == t.state ? e.intentionData = [] : e.intentionData = [ {
                                        gname: n.gname,
                                        gid: n.gid
                                    } ]) : t.state = 0;
                                });
                            });
                        }), 2 == this.step && this.checkGroupDataState(), 2 != this.step && this.checkChooseState(), 
                        this.groupData = a;
                    },
                    confirm: function() {
                        var e = this;
                        if (0 == this.step) {
                            if (!this.checkChooseData("请选择考试")) return;
                            t.getStorageSync("noChangeCategoryInfo") ? t.setStorageSync("onCategoryInfo", {
                                gid: this.intentionData[0].gid,
                                gname: this.intentionData[0].gname
                            }) : t.setStorageSync("categoryInfo", this.intentionData[0]), this.checkTokenUpdateUserInfo(function() {
                                var n = "?gid=".concat(e.intentionData[0].gid, "&gname=").concat(e.intentionData[0].gname);
                                if (e.sourcePath) {
                                    var a = "".concat(e.sourcePath).concat(n);
                                    t.redirectTo({
                                        url: a
                                    });
                                } else {
                                    getCurrentPages().length <= 1 ? t.redirectTo({
                                        url: "/pages/index/index".concat(n)
                                    }) : t.navigateBack({
                                        delta: 1
                                    });
                                }
                            });
                        }
                        if (1 == this.step) {
                            if (!this.checkChooseData("请选择考试")) return;
                            t.setStorageSync("categoryInfo", this.intentionData[0]), this.checkTokenUpdateUserInfo(function() {
                                t.navigateTo({
                                    url: "/pages/exam/exam?step=2"
                                });
                            });
                        }
                        if (2 == this.step) {
                            if (!this.checkChooseData("请选择考试")) return;
                            t.setStorageSync("favorateData", this.favorateData), this.checkTokenUserInterested(function() {
                                t.reLaunch({
                                    url: "/pages/index/index"
                                });
                            });
                        }
                    },
                    initGroupDataState: function() {
                        var t = this.groupData, e = this.categoryInfo;
                        t.forEach(function(t) {
                            t.list.forEach(function(t) {
                                t.unitList.forEach(function(t) {
                                    t.categoryId == e.gid && (t.state = -1, t.intentionData = 1);
                                });
                            });
                        }), this.groupData = t;
                    },
                    checkGroupDataState: function() {
                        for (var t = this.favorateData, e = [], n = 0; n < t.length; n++) (0 == n || t[n].gid != t[n - 1].gid) && e.push(t[n]);
                        (this.favorateData = e, e.length < 2) ? this.groupData.forEach(function(t) {
                            t.list.forEach(function(t) {
                                t.unitList.forEach(function(t) {
                                    e.forEach(function(e) {
                                        e.gid == t.categoryId ? t.state = 1 : 1 != t.intentionData && (t.state = 0);
                                    });
                                });
                            });
                        }) : this.groupData.forEach(function(t) {
                            t.list.forEach(function(t) {
                                t.unitList.forEach(function(t) {
                                    e.forEach(function(e) {
                                        e.gid != t.categoryId && 0 == t.state && (t.state = -1);
                                    });
                                });
                            });
                        });
                        this.checkChooseState();
                    },
                    checkChooseState: function() {
                        2 == this.step ? this.confirmBtnClass = this.favorateData && this.favorateData.length >= 1 ? "" : "disabled" : this.confirmBtnClass = this.intentionData && 1 == this.intentionData.length ? "" : "disabled";
                    },
                    checkChooseData: function(e) {
                        return 2 == this.step ? !(this.favorateData.length < 1) || (t.showToast({
                            title: e,
                            icon: "none"
                        }), !1) : !(!this.intentionData || 0 == this.intentionData.length) || (t.showToast({
                            title: e,
                            icon: "none"
                        }), !1);
                    },
                    jump: function() {
                        t.reLaunch({
                            url: "/pages/index/index"
                        });
                    },
                    checkTokenUpdateUserInfo: function(e) {
                        if (!t.getStorageSync("hq_token") || 1 == t.getStorageSync("noChangeCategoryInfo")) return t.removeStorageSync("noChangeCategoryInfo"), 
                        void ("function" == typeof e && e());
                        this.updateUserInfo(e);
                    },
                    updateUserInfo: function(e) {
                        t.showLoading();
                        var n = {
                            edu24ol_token: t.getStorageSync("hq_token"),
                            second_category: this.intentionData[0].gid
                        };
                        (0, o.updateUserInfo)(n, function(n) {
                            "function" == typeof e && e(), t.hideLoading();
                        });
                    },
                    checkTokenUserInterested: function(t) {
                        this.token ? this.userInterested(t) : "function" == typeof t && t();
                    },
                    userInterested: function(e) {
                        t.showLoading();
                        var n = [];
                        this.favorateData.forEach(function(t) {
                            n.push(t.gid);
                        });
                        var a = {
                            edu24ol_token: this.token,
                            second_category_list: n.join(",")
                        };
                        (0, o.userInterested)(a, function(n) {
                            "function" == typeof e && e(), t.hideLoading();
                        });
                    }
                }
            };
            e.default = i;
        }).call(this, n(1).default);
    },
    32: function(t, e, n) {
        n.r(e);
        var a = n(33), o = n.n(a);
        for (var i in a) "default" !== i && function(t) {
            n.d(e, t, function() {
                return a[t];
            });
        }(i);
        e.default = o.a;
    },
    33: function(t, e, n) {}
}, [ [ 26, "common/runtime", "common/vendor" ] ] ]);