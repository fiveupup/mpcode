require("../../@babel/runtime/helpers/Arrayincludes");

var t, a, e = require("../../@babel/runtime/helpers/defineProperty"), o = getApp(), i = require("../../utils/util"), s = require("../../configs/baseConfig"), r = require("../../configs/config_" + s.appName), d = require("../../utils/request");

Page((a = {
    data: (t = {
        tab: "tab1",
        cData: {},
        courseDetail: "",
        classtable: [],
        categoryListDatas: [],
        group_id: null,
        mode: -1,
        bmode: -1,
        maxo: null,
        maxn: null,
        mino: null,
        minn: null,
        djs1: 0,
        djs2: 0,
        djs3: 0,
        djs4: 0,
        startTimeTeam: 0,
        teacherData: [],
        webIdInfo: {},
        showHome: !0,
        sysModel: "",
        isIPhoneX: !1,
        commentCount: 0,
        commentData: null,
        systemText: "",
        realNum: 0,
        grayLevel: !0,
        goodsCouponDatas: "",
        isHiddenWinBox: !0,
        winBoxType: 0,
        couponTitle: "",
        giftsTitle: "",
        giftsData: [],
        servicesTitle: "",
        servicesData: [],
        scrollIntoView: "scroll-1",
        selectQueryArray: [],
        totalCoursePrice: 0,
        totalCourseOriginalPrice: 0,
        selectedCourseCount: 0,
        isShowCouponTips: 0,
        totalGoodsIds: [],
        scrollTop: 0,
        showNavigationBar: 0,
        tabFixedStyle: 0,
        scrollViewTop: "",
        scrollTop1: 0,
        scrollTop2: 0,
        scrollTop3: 0,
        scrollTop4: 0,
        deltaY: 0,
        isClickTab: 0,
        navigationBarTitle: "课程详情",
        scrollHeight: "100vh",
        openid: "",
        groupname: "",
        serviceParam: "",
        container: null,
        showLiveBar: !1,
        timerQuery: null,
        timerClick: null
    }, e(t, "scrollIntoView", ""), e(t, "isShowTearcher", !1), e(t, "activityData", null), 
    e(t, "buyOrderGroupListData", ""), e(t, "activityTimer", null), e(t, "activityTime", null), 
    e(t, "listGroupData", ""), e(t, "winGroupState", !1), e(t, "winGroupType", 0), e(t, "groupData", ""), 
    e(t, "joinGroupData", ""), e(t, "leftCount", 0), e(t, "goodsList", ""), e(t, "productIsTraining", !1), 
    e(t, "messagePath", "pages/courseDetail/courseDetail?sendCourseTeacher=1&groupId="), 
    e(t, "title", ""), e(t, "isScrollTop", !1), e(t, "groupsGoodsIndex", 0), e(t, "videoPicIndex", 1), 
    e(t, "isShowBtmBar", !1), e(t, "recommendList", []), e(t, "recommendIndex", 0), 
    e(t, "headerH", 0), e(t, "freeStudyLessonList", []), e(t, "codeTitleList", [ "备考用对方法，小白入门也能轻松学！", "高性价比就看它，带你系统掌握知识点、攻克难题！", "学习有妙招，夯基、强化、冲刺，助你稳中取胜！", "强师精研打磨，全阶段带学，专为高效备考而生。" ]), 
    e(t, "CourseBehaviorDetails", {
        courseName: "",
        courseID: "",
        examinationName: "",
        timeOnPage: "",
        playbackProgressDuration: "",
        slidePicture: "",
        clickRecommendedCourseID: [],
        clickRecommendedCourseName: [],
        clickComment: "",
        likeCommentID: [],
        clickTeacherHomepage: ""
    }), e(t, "bannerVideoDuration", 0), e(t, "bannerVideoTime", 0), e(t, "exchangeId", 0), 
    e(t, "isHideWinExchange", !0), e(t, "goodsId", 0), e(t, "isShowMember", !1), e(t, "goodsNum", 1), 
    e(t, "reduceBtn", "dis"), e(t, "addBtn", ""), t),
    onLoad: function(t) {
        (t.web_id && (o.globalData["web_id_".concat(t.id)] = t.web_id), console.log("options", t), 
        t.scene) && (console.log("scene", t.scene), decodeURIComponent(t.scene).split("&").forEach(function(a, e) {
            t[a.split("=")[0]] = a.split("=")[1];
        }), console.log("scene", t));
        t = o.customDecode(t);
        var a = this;
        i.setUrlParams(t), a.data.options = t, a.data.mainGroupId = t.id, null == t.id && wx.redirectTo({
            url: "/pages/index/index"
        }), this.data.messagePath = "".concat(this.data.messagePath).concat(t.id), this.setData({
            messagePath: this.data.messagePath
        }), this.fromOther(t), o.showLiveRoom(this, t.gid), this.initScrollHeight(), t.realNum && (this.data.realNum = t.realNum, 
        this.setData({
            realNum: this.data.realNum
        })), wx.getStorageSync("realNum") && wx.getStorageSync("realNum") == t.id && (a.data.realNum = 1, 
        a.setData({
            realNum: a.data.realNum
        }), wx.removeStorageSync("realNum")), wx.getStorageSync("trainingGroupId") && wx.removeStorageSync("trainingGroupId"), 
        o.updateCheck(function() {}, function() {
            a.setData({
                grayLevel: !1
            });
        }), t.source && 1 == t.source && (this.setData({
            showHome: !1
        }), encodeURIComponent("&source=1")), t.exchangeId && (this.setData({
            exchangeId: t.exchangeId,
            goodsId: t.goodsId
        }), this.getExchangeDetail(), this.getUserCredit()), a.s = t.s, a.t = t.t, o.setWebIdToStorage(t.web_id), 
        a.getWedId(), o.fixIPhone(this), a.fromEduCd(t), o.fixIPhone(this), wx.setStorageSync("lastCourseId", t.id), 
        wx.setStorageSync("lastUrl", "courseDetail"), a.data.categoryInfo = wx.getStorageSync("categoryInfo") || {}, 
        a.setData({
            categoryInfo: a.data.categoryInfo
        }), a.setData({
            token: wx.getStorageSync(s.tokenKey) || ""
        }), 1 == i.checkOS() ? this.setData({
            systemText: "报名"
        }) : 2 == i.checkOS() && this.setData({
            systemText: "选课"
        }), 2 == i.checkOS() && this.setData({
            isIOS: !0
        }), i.showLoading({
            title: "加载中...",
            mask: !0
        }), a.data.hqUserInfo = wx.getStorageSync("hqUserInfo") || "", a.data.mpUserInfo = wx.getStorageSync("mpUserInfo") || "", 
        wx.getStorageSync("hqUserInfo") && wx.getStorageSync("hqUserInfo").wxOpenId ? this.data.openid = wx.getStorageSync("hqUserInfo").wxOpenId : o.getUserInfo(function(t) {
            o.getWxUserInfo(function(t) {
                a.data.openid = t.openId;
            });
        }, this);
    },
    onShow: function() {
        this.setData({
            goodsNum: 1
        }), this.reportCourseBehaviorDetailsTime(), this.init();
    },
    init: function() {
        this.data.group_id = this.data.options.id, this.setData({
            group_id: this.data.group_id
        }), wx.removeStorageSync("trainingParams"), this.data.totalCoursePrice = 0, this.data.totalCourseOriginalPrice = 0, 
        this.data.isHiddenWinBox = !0, this.setData({
            videoPicIndex: 1,
            totalCoursePrice: 0,
            totalCourseOriginalPrice: 0,
            isHiddenWinBox: !0,
            totalGoodsIds: [],
            selectedCourseCount: 0,
            videoAutoPlay: !1
        }), this.getGoodsGroupDetails();
    },
    onHide: function() {
        this.reportCourseBehaviorDetails(), this.clearCourseBehaviorDetailsTime(), this.resetCourseBehaviorDetails();
    },
    bannerLoadedmetadata: function(t) {
        this.data.bannerVideoDuration = parseInt(t.detail.duration);
    },
    bannerPlay: function() {
        this.data.bannerIsPlay = !0;
    },
    bannerPause: function() {
        this.data.bannerIsPlay = !1;
    },
    goCommentList: function() {
        this.data.CourseBehaviorDetails.clickComment = "1", this.reportCourseBehaviorDetails(), 
        this.clearCourseBehaviorDetailsTime(), this.resetCourseBehaviorDetails(), wx.navigateTo({
            url: "/subpackages/pages/commentList/commentList?id=" + this.data.group_id
        });
    },
    reportCourseBehaviorDetailsTime: function() {
        var t = this;
        this.data.reportTime = 0, this.data.bannerVideoTime = 0, this.data.reportTimer = setInterval(function() {
            t.data.reportTime++, t.data.bannerIsPlay && t.data.bannerVideoTime++;
        }, 1e3);
    },
    resetCourseBehaviorDetails: function() {
        this.data.reportTime = 0, this.data.bannerVideoTime = 0, this.data.CourseBehaviorDetails = {
            courseName: "",
            courseID: "",
            examinationName: "",
            timeOnPage: "",
            playbackProgressDuration: "",
            slidePicture: "",
            clickRecommendedCourseID: [],
            clickRecommendedCourseName: [],
            clickComment: "",
            likeCommentID: [],
            clickTeacherHomepage: ""
        };
    },
    clearCourseBehaviorDetailsTime: function() {
        this.data.reportTimer && clearInterval(this.data.reportTimer);
    },
    getExchangeDetail: function() {
        var t = this, a = {
            edu24ol_token: wx.getStorageSync("hq_token"),
            id: this.data.exchangeId
        };
        wx.request({
            url: s.host + "/uc/credit/getExchangeDetail",
            data: a,
            success: function(a) {
                0 == a.data.status.code && t.setData({
                    exchangeDetail: a.data.data
                });
            }
        });
    },
    getUserCredit: function() {
        var t = this, a = {
            edu24ol_token: wx.getStorageSync("hq_token"),
            passport: wx.getStorageSync("hq_token")
        };
        wx.request({
            url: "".concat(s.hostJAPI, "/credit/userCredit"),
            data: a,
            success: function(a) {
                0 == a.data.status.code && t.setData({
                    credit: a.data.data
                });
            }
        });
    },
    showExchange: function() {
        var t = this;
        wx.showModal({
            content: "是否确认兑换该商品",
            success: function(a) {
                a.confirm && t.goExchange();
            }
        });
    },
    goExchange: function() {
        wx.showLoading();
        var t = {
            edu24ol_token: wx.getStorageSync("hq_token"),
            id: this.data.exchangeId
        };
        wx.request({
            url: "".concat(s.host, "/uc/credit/exchange"),
            data: t,
            success: function(t) {
                wx.hideLoading(), 0 == t.data.status.code ? (wx.showToast({
                    title: "兑换成功"
                }), setTimeout(function() {
                    wx.navigateToMiniProgram({
                        appId: "wx890b8e807c46f703",
                        path: "/packageStudy/pages/myCourse/myCourse"
                    });
                }, 1500)) : wx.showToast({
                    icon: "none",
                    title: t.data.status.msg
                });
            }
        });
    },
    closeWinExchange: function() {
        this.setData({
            isHideWinExchange: !0
        });
    },
    reportCourseBehaviorDetails: function() {
        this.data.CourseBehaviorDetails.courseName = this.data.cData.name, this.data.CourseBehaviorDetails.courseID = this.data.cData.id, 
        this.data.CourseBehaviorDetails.examinationName = this.data.cData.second_category_name, 
        this.data.cData.videoUrl && (this.data.reportTime <= this.data.bannerVideoDuration ? this.data.CourseBehaviorDetails.playbackProgressDuration = this.data.bannerVideoTime.toString() : this.data.CourseBehaviorDetails.playbackProgressDuration = this.data.bannerVideoDuration.toString()), 
        this.data.CourseBehaviorDetails.timeOnPage = this.data.reportTime.toString(), this.data.CourseBehaviorDetails.slidePicture = this.data.CourseBehaviorDetails.slidePicture.toString(), 
        this.data.CourseBehaviorDetails.clickRecommendedCourseID = this.data.CourseBehaviorDetails.clickRecommendedCourseID.join(","), 
        this.data.CourseBehaviorDetails.clickRecommendedCourseName = this.data.CourseBehaviorDetails.clickRecommendedCourseName.join(","), 
        this.data.CourseBehaviorDetails.likeCommentID = this.data.CourseBehaviorDetails.likeCommentID.join(","), 
        i.reportEvent(o, "CourseBehaviorDetails", this.data.CourseBehaviorDetails), console.log("CourseBehaviorDetails", this.data.CourseBehaviorDetails);
    },
    createCode: function() {
        var t = "";
        1 == this.data.mode ? t = "¥" + this.data.maxo : 2 == this.data.mode ? t = "¥" + this.data.mino : 3 == this.data.mode ? t = "¥" + (this.data.maxn != this.data.maxo ? this.data.maxn : this.data.minn) : 4 == this.data.mode ? t = "¥" + this.data.minn + "起" : 6 == this.data.mode && (t = "¥0");
        var a = "", e = !1, o = this.data.cData.price_type;
        1 != o && 2 != o || (a = this.data.codeTitleList[0], e = !0), 3 == o && (a = this.data.codeTitleList[1], 
        e = !0), 4 == o && (a = this.data.codeTitleList[2]), 5 == o && (a = this.data.codeTitleList[3]);
        var i = "id=" + this.data.group_id;
        this.data.webIdInfo.web_id && (i = i + "&web_id=" + this.data.webIdInfo.web_id);
        var s = this.data.hqUserInfo && this.data.hqUserInfo.faceUrl || this.data.mpUserInfo && this.data.mpUserInfo.avatarUrl || "https://oss-hqwx-edu24ol.hqwx.com/miniapp/hq_live/avatar.png", r = this.data.hqUserInfo && this.data.hqUserInfo.nickName || this.data.mpUserInfo && this.data.mpUserInfo.nickName || "微信用户";
        this.selectComponent("#cDetailCode").$vm.createCourseCode({
            teacherPic: s,
            teacherName: r,
            des: "推荐给你一门有用的课程",
            title: a,
            pic: this.data.cData.big_pic || "https://oss-hqwx-edu24ol.hqwx.com/miniapp/hq_live/courseDetail/share1.png",
            name: this.data.cData.name || "",
            price: t,
            urlParams: i,
            recommend: "好课推荐·" + this.data.cData.second_category_name || "",
            isLow: e
        });
    },
    tabCourse: function(t) {
        if (!this.data.tabCourseLoading) {
            this.data.tabCourseLoading = !0;
            var a = t.currentTarget.dataset;
            this.setData({
                recommendIndex: a.index
            }), this.data.options.id = a.item.id;
            var e = this.data.recommendList[a.index];
            this.data.CourseBehaviorDetails.clickRecommendedCourseID.constructor === Array && -1 == this.data.CourseBehaviorDetails.clickRecommendedCourseID.indexOf(e.id) && this.data.mainGroupId != e.id && (this.data.CourseBehaviorDetails.clickRecommendedCourseID.push(e.id), 
            this.data.CourseBehaviorDetails.clickRecommendedCourseName.push(e.name)), this.reportCourseBehaviorDetails(), 
            this.resetCourseBehaviorDetails(), this.init();
        }
    },
    getHeaderH: function(t) {
        var a = t.detail || 0;
        this.setData({
            headerH: a,
            tabFixedStyle: "top:" + a + "px"
        });
    },
    screenchange: function(t) {
        t.detail.fullScreen ? this.setData({
            hideHeader: !0
        }) : this.setData({
            hideHeader: !1
        });
    },
    changeVideoPic: function(t) {
        this.setData({
            videoPicIndex: t.detail.current + 1
        }), this.data.videoCtx && (0 == t.detail.current ? (this.data.videoCtx.play(), console.log("play")) : (this.data.videoCtx.pause(), 
        console.log("pause"))), this.data.CourseBehaviorDetails.slidePicture - this.data.videoPicIndex < 0 && (this.data.CourseBehaviorDetails.slidePicture = this.data.videoPicIndex);
    },
    thumbUp: function(t) {
        -1 != this.data.CourseBehaviorDetails.likeCommentID.indexOf(t.detail.id) || t.detail.thumbFlag || this.data.CourseBehaviorDetails.likeCommentID.push(t.detail.id);
    },
    saveTrainingData: function(t) {
        var a = this;
        if (this.data.training) {
            var e = [], o = [];
            Array.isArray(t) ? t.forEach(function(t, i) {
                a.data.cList.forEach(function(a, i) {
                    t == a.id && (e.push(a.id), o.push(a.name));
                });
            }) : t ? (o = [ this.data.cList[0].name ], e = [ this.data.cList[0].id ]) : this.data.cList.forEach(function(t, a) {
                1 == t.bought_status && (e.push(t.id), o.push(t.name));
            });
            var i = {
                courseID: this.data.cData.id,
                courseCategory: this.data.cData.course_type,
                courseName: this.data.cData.name,
                goodsCategory: this.data.productIsTraining,
                goodsID: e.join(","),
                goodsTitle: o.join(","),
                secondCategory: this.data.courseSecondCategory
            };
            console.log("trainingParams", i), wx.setStorageSync("trainingParams", i);
        }
    },
    goTrainingSuccess: function() {
        this.saveTrainingData(), wx.redirectTo({
            url: "/subpackages/pages/trainingSuccess/trainingSuccess?groupId=".concat(this.data.cData.id)
        });
    }
}, e(a, "onHide", function() {
    i.hideLoading(), clearTimeout(this.data.timerQuery), clearTimeout(this.data.timerClick), 
    clearInterval(this.data.startTimeTeam), clearInterval(this.data.activityTimer), 
    o.clearInterValCourseTimer();
}), e(a, "onUnload", function() {
    i.hideLoading(), clearTimeout(this.data.timerQuery), clearTimeout(this.data.timerClick), 
    clearInterval(this.data.startTimeTeam), clearInterval(this.data.activityTimer), 
    o.clearInterValCourseTimer();
}), e(a, "fromOther", function(t) {
    var a = wx.getStorageSync("categoryInfo");
    a && a.gname || void 0 === t.gid || void 0 === t.gname || (wx.setStorageSync("categoryInfo", {
        gid: t.gid,
        gname: decodeURIComponent(t.gname)
    }), this.setData({
        categoryInfo: {
            gid: t.gid,
            gname: decodeURIComponent(t.gname)
        }
    }));
}), e(a, "initScrollHeight", function() {
    var t = this;
    wx.getStorageSync("windowStyle") ? (this.data.scrollHeight = wx.getStorageSync("windowStyle").height - 55 + "px", 
    this.setData({
        scrollHeight: t.data.scrollHeight
    })) : wx.getSystemInfo({
        success: function(a) {
            t.data.scrollHeight = a.windowHeight - 55 + "px", t.setData({
                scrollHeight: t.data.scrollHeight
            });
        }
    });
}), e(a, "getBargainActFromCourseId", function() {
    var t = this;
    wx.request({
        url: s.host + "/wxapp/v1/webBook/getBargainActFromCourseId",
        data: {
            _appid: r.appid,
            _os: i.checkOS(),
            _v: r.version,
            org_id: s.orgId,
            _t: i.timeStamp(),
            courseId: t.data.group_id
        },
        success: function(a) {
            if (0 == a.data.status.code) {
                var e;
                a.data.data && a.data.data.goods_list.sort(function(t, a) {
                    return t.bargain_price - a.bargain_price;
                }), e = Math.round(a.data.data && a.data.data.goods_list && a.data.data.goods_list[0].bargain_price || 0), 
                t.setData({
                    bargainData: a.data.data,
                    minPrice: e
                });
            }
        }
    });
}), e(a, "goBargain", function() {
    wx.navigateToMiniProgram({
        appId: "wxa6a53322a38ff9a9",
        path: "pages/bargainDetail/bargainDetail?id=" + this.data.bargainData.id
    });
}), e(a, "getGoodsExtraDetail", function() {
    var t = this, a = this;
    wx.request({
        url: s.host + "/mobile/v2/goods/getGoodsExtraDetail",
        data: {
            _appid: r.appid,
            _os: i.checkOS(),
            _v: r.version,
            org_id: s.orgId,
            _t: i.timeStamp(),
            edu24ol_token: wx.getStorageSync(s.tokenKey) || "",
            terminal_type: s.terminalType,
            terminalType: s.terminalType,
            gid: this.data.group_id
        },
        success: function(e) {
            if (0 == e.data.status.code) {
                if (e.data.data.recommend && e.data.data.recommend.length && !t.data.recommendLoaded && (e.data.data.recommend.forEach(function(a, e) {
                    t.data.recommendList.push({
                        name: a.name,
                        alias: a.alias,
                        recommendSentence: a.recommend_sentence,
                        id: a.id,
                        teacherPic: a.teachers && a.teachers.length && a.teachers[0].pic || ""
                    });
                }), t.setData({
                    recommendList: t.data.recommendList
                }), t.data.recommendLoaded = !0), 2 != t.data.cData.course_type && e.data.data.couponList && e.data.data.couponList.length > 0) {
                    var o = e.data.data.couponList, s = 0, r = "", d = [], n = [], c = 0;
                    o.forEach(function(t, a) {
                        var e = new Date(t.begin_time), o = new Date(t.end_time), r = new Date().getTime();
                        0 == t.state && (c = 1), t.date = "".concat(e.getFullYear(), ".").concat(i.formatNumber(e.getMonth() + 1), ".").concat(i.formatNumber(e.getDate()), "至").concat(o.getFullYear(), ".").concat(i.formatNumber(o.getMonth() + 1), ".").concat(i.formatNumber(o.getDate())), 
                        r > t.end_time && (t.status = 3), 1 == t.couponType ? (s = 1, n.push(t.couponRuleCondition.value)) : 0 == t.couponType && d.push(10 * t.couponRuleCondition.value);
                    }), r = 1 == s ? "领券最高可减".concat(Math.max.apply(Math, n), "元") : "领券最高享".concat(Math.min.apply(Math, d), "折优惠"), 
                    c = a.data.isShowMember ? 0 : c, a.setData({
                        couponTitle: r,
                        goodsCouponDatas: o,
                        isShowCouponTips: c
                    });
                }
                if (e.data.data.giftList && e.data.data.giftList.length > 0) {
                    var u, l = [];
                    e.data.data.giftList.forEach(function(t, a) {
                        l.push(t.name);
                    }), u = l.join(" · "), a.data.giftsData = e.data.data.giftList, a.setData({
                        giftsTitle: u
                    });
                }
                if (e.data.data.service && e.data.data.service.length > 0) {
                    var h, g = [];
                    e.data.data.service.forEach(function(t, a) {
                        g.push(t.type_name);
                    }), h = g.join(" · "), a.setData({
                        servicesTitle: h,
                        servicesData: e.data.data.service
                    });
                }
            }
        }
    });
}), e(a, "showWinBox", function(t) {
    this.setData({
        isHiddenWinBox: !1,
        winBoxType: t.currentTarget.dataset.index,
        scrollTop: 0
    });
}), e(a, "closeWinBox", function() {
    1 == this.data.winBoxType && (this.data.cList.forEach(function(t, a) {
        t.state = 0;
    }), this.setData({
        cList: this.data.cList
    })), this.setData({
        isHiddenWinBox: !0
    });
}), e(a, "openCoupon", function() {
    this.setData({
        winBoxType: 2,
        scrollTop: 0
    });
}), e(a, "getCoupon", function(t) {
    var a = this, e = t.currentTarget.dataset.id;
    this.data.token ? (i.showLoading(), wx.request({
        url: s.host + "/sales/v1/coupon/pullCoupons",
        data: {
            _appid: r.appid,
            _os: i.checkOS(),
            _v: r.version,
            org_id: s.orgId,
            _t: i.timeStamp(),
            edu24ol_token: wx.getStorageSync(s.tokenKey) || "",
            terminal_type: s.terminalType,
            terminalType: s.terminalType,
            coupon_id: e
        },
        success: function(t) {
            if (0 == t.data.status.code || 8 == t.data.status.code) {
                i.hideLoading(), i.showToast2("领取优惠券成功");
                var o = a.data.goodsCouponDatas, s = 0;
                o.forEach(function(t, a) {
                    t.id == e && (t.state = 1), 0 == t.state && (s = 1);
                }), a.setData({
                    goodsCouponDatas: o,
                    isShowCouponTips: s
                });
            } else if (9 == t.data.status.code) {
                i.hideLoading(), i.showToast2(t.data.status.msg);
                var r = a.data.goodsCouponDatas, d = 0;
                r.forEach(function(t, a) {
                    t.id == e && (t.state = 3), 0 == t.state && (d = 1);
                }), a.setData({
                    goodsCouponDatas: r,
                    isShowCouponTips: d
                });
            } else i.hideLoading();
        },
        fail: function() {
            i.hideLoading();
        }
    })) : wx.navigateTo({
        url: "/pages/login/login?sourcePath=%2Fpages%2FcourseDetail%2FcourseDetail%3Fid%3D" + a.data.group_id
    });
}), e(a, "getGoodsGroupDetails", function() {
    var t = this, a = t.data.options;
    o.globalData.sysInfo ? t.data.sysModel = o.globalData.sysInfo.os : wx.getSystemInfo({
        success: function(a) {
            a.system.indexOf("Android") > -1 ? t.data.sysModel = 1 : a.system.indexOf("iOS") > -1 && (t.data.sysModel = 2);
        }
    }), wx.request({
        url: s.host + "/mobile/v2/goods/getGoodsGroupDetails",
        data: {
            group_id: a.id,
            org_id: s.orgId,
            appid: r.appid,
            _v: r.version,
            _os: s.os,
            edu24ol_token: wx.getStorageSync(s.tokenKey) || "",
            terminalType: s.terminalType,
            terminal_type: s.terminalType
        },
        method: "GET",
        dataType: "json",
        success: function(e) {
            if (40042 != e.data.status.code) if (0 == e.data.status.code) if (t.setData({
                serviceParam: "?groupid=" + r.groupid + "&title=" + encodeURIComponent(e.data.data.name) + "&secondCategory=" + e.data.data.second_category
            }), e.data.data) {
                wx.getStorageSync("categoryInfo") || wx.setStorageSync("categoryInfo", {
                    gid: e.data.data.second_category,
                    gname: e.data.data.second_category_name
                }), t.data.courseSecondCategory = e.data.data.second_category, e.data.data.teachers && e.data.data.teachers.length > 0 && e.data.data.teachers.forEach(function(t, a) {
                    t.list1 = t.list.substr(0, 60) + "...", t.actionsState = 0;
                }), e.data.data.show_time && (e.data.data.show_time = e.data.data.show_time.replace(/\-/g, "."));
                var s = e.data.data, d = Math.max(0, s.limit - (s.bought_count || 0) - (s.buyer_count || 0)), n = 0;
                null != s.min_user_member_price && s.min_user_member_price <= s.min_sale_price && (n = 1, 
                t.getMemberDetailByType(), t.data.isShowMember = n, t.setData({
                    isShowMember: n
                }));
                var c = !1, u = !1;
                if (e.data.data.goods_group_content_list && e.data.data.goods_group_content_list.length > 0) for (var l = e.data.data.goods_group_content_list, h = 0; h < l.length; h++) 3 == l[h].goods_category && (u = !0), 
                2 == l[h].schedule_type && (c = !0);
                t.data.productIsTraining = u, t.data.productIsSchedule = c;
                var g = [];
                e.data.data.videoUrl && (g.push({
                    url: e.data.data.videoUrl,
                    video: 1
                }), t.setData({
                    videoPoster: e.data.data.big_pic
                }), t.data.videoCtx = wx.createVideoContext("video"), setTimeout(function() {
                    t.setData({
                        videoAutoPlay: !0,
                        videoPoster: ""
                    }), t.data.videoCtx.play();
                }, 800));
                for (var m = 0; m < 5; m++) 0 == m && e.data.data.big_pic && !e.data.data.videoUrl ? g.push({
                    url: e.data.data.big_pic
                }) : e.data.data["big_pic" + m] && g.push({
                    url: e.data.data["big_pic" + m]
                });
                if (g.length && (t.data.CourseBehaviorDetails.slidePicture = "1"), 2 == e.data.data.course_type && t.setData({
                    systemText: "购买"
                }), t.setData({
                    cData: e.data.data,
                    videoPicList: g,
                    bought_count: e.data.data.bought_count || 0,
                    buyer_count: e.data.data.buyer_count || 0,
                    leftCount: d || 0,
                    teacherData: e.data.data.teachers,
                    realNum: e.data.data.realNum,
                    productIsSchedule: c,
                    training: u
                }), wx.setStorageSync("trainingGroupId", a.id), t.data.groupname = e.data.data.name, 
                e.data.data.second_category && i.reportEvent(o, "MPViewScreenExID", {
                    $url_path: t.route,
                    examinationID: e.data.data.second_category + ""
                }), t.setData({
                    activityData: ""
                }), t.setData({
                    buyOrderGroupListData: ""
                }), e.data.data.activity) {
                    var p = e.data.data.activity;
                    p.info.end_time > 0 && (t.data.activityTimer = setInterval(function() {
                        var a = i.countTime(4, p.info.end_time);
                        t.setData({
                            activityTime: a
                        });
                    }, 1e3)), p.info.min_price = Math.round(p.info.min_price), t.setData({
                        activityData: p
                    }), t.queryBuyOrderGroupVO();
                } else t.getBargainActFromCourseId();
                e.data.data.goods_list && (t.data.goodsList = e.data.data.goods_list.join(","), 
                t.setData({
                    goodsList: t.data.goodsList
                })), t.getCourseTeacherData(), t.getCourseDeatil(), t.setmode(), t.setButton(), 
                t.data.productIsSchedule || (t.getCTable(), t.getFreeLessonVideoList()), t.setData({
                    isShowBtmBar: !0
                }), t.data.recommendLoaded || t.data.recommendList.push({
                    alias: e.data.data.alias || "",
                    recommendSentence: e.data.data.recommend_sentence || "",
                    id: e.data.data.id,
                    name: e.data.data.name,
                    teacherPic: e.data.data.teachers && e.data.data.teachers.length && e.data.data.teachers[0].pic || ""
                }), t.getGoodsExtraDetail();
            } else i.showToast2("网络出错或暂无数据"); else i.showToast2("网络出错或暂无数据"); else wx.redirectTo({
                url: "/pages/login/login?sourcePath=%2Fpages%2FcourseDetail%2FcourseDetail%3Fid%3D" + t.data.group_id
            });
        },
        fail: function() {
            i.hideLoading(), i.showToast2("网络出错或暂无数据");
        }
    });
}), e(a, "getCourseTeacherData", function() {
    var t = this;
    d.getHqCourseTeacher({
        goodsGroupId: this.data.group_id
    }, function(a) {
        0 == a.data.status.code && a.data.data && a.data.data.id && t.setData({
            isShowTearcher: !0
        });
    });
}), e(a, "changeT", function(t) {
    var a = this, e = 0;
    this.selectQuery(function() {
        var o = a.data.queryList[0].height || 0;
        a.data.queryList.forEach(function(i, s) {
            i && i.id == t.currentTarget.dataset.id && (e = i.top + a.data.scrollTop - a.data.headerH - o);
        }), a.setData({
            scrollViewTop: e,
            tab: t.currentTarget.dataset.name
        });
    });
}), e(a, "setSelectorHeight", function() {
    var t = this.data.cData.big_pic ? 90 : 0;
    this.data.scrollTop1 = Math.ceil(this.data.selectQueryArray[0] + this.data.selectQueryArray[1] - 108) + t, 
    this.data.scrollTop2 = Math.ceil(this.data.scrollTop1 + this.data.selectQueryArray[2]), 
    this.data.scrollTop3 = Math.ceil(this.data.scrollTop2 + this.data.selectQueryArray[3]), 
    this.data.scrollTop4 = Math.ceil(this.data.scrollTop3 + this.data.selectQueryArray[4]);
}), e(a, "selectQuery", function() {
    var t = this, a = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : function() {};
    this.data.query = wx.createSelectorQuery(), this.data.query.select("#courseTabButton").boundingClientRect();
    for (var e = 0; e < 4; e++) this.data.query.select("#scroll-" + e).boundingClientRect();
    this.data.queryList = [], this.data.query.exec(function(e) {
        t.data.queryList = e, a();
    });
}), e(a, "scrollView", function(t) {
    var a = t.detail.scrollTop;
    this.data.scrollTop = a, a > 200 ? this.setData({
        isScrollTop: !0,
        title: this.data.cData && this.data.cData.name || ""
    }) : this.setData({
        isScrollTop: !1,
        title: ""
    });
}), e(a, "getCourseDeatil", function() {
    var t, a, e = this;
    "" != e.data.cData.content && null != e.data.cData.content && (t = i.replaceOss(e.data.cData.content), 
    wx.request({
        url: t,
        method: "GET",
        dataType: "json",
        data: {
            _t: i.timeStamp(),
            org_id: s.orgId,
            appid: r.appid,
            _v: r.version,
            _os: s.os
        },
        success: function(t) {
            a = t.data.replace(/.+?\,(.+).+/gi, "$1").replace(/\"|\'/g, "").replace(/(\\|&quot;)/g, "'"), 
            a = i.replaceOss(a), e.setData({
                courseDetail: i.replaceHTMLChar(a).replace(/style\=/g, "style11=").replace(/<img style11\=\'max-width\:100%/g, "<img style='max-width:100%!important; vertical-align:top")
            }, function() {});
        }
    }));
}), e(a, "getCatalog", function() {
    var t = this, a = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : function() {};
    o.allCategory(function(e) {
        e && e.length > 0 && (t.data.categoryListDatas = e, a());
    });
}), e(a, "getCTable", function() {
    var t = this, a = this;
    wx.request({
        url: s.host + "/mobile/v2/goods/getAllGoodsGroupProductListById",
        data: {
            group_id: a.data.group_id,
            org_id: s.orgId,
            appid: r.appid,
            _v: r.version,
            _os: s.os
        },
        method: "GET",
        dataType: "json",
        success: function(e) {
            if (0 == e.data.status.code) {
                var o = e.data.data;
                a.setData({
                    hasSchedule: o && o.length
                });
                var i = [], s = 0, r = 0;
                o && o.length && (o.forEach(function(t, a) {
                    t.timetables.forEach(function(t, a) {
                        r >= 8 || (i.push({
                            category_id: t.category_id,
                            list: []
                        }), r++, t.app_goods_products.forEach(function(t, a) {
                            r >= 8 || (i[s].list.push(t), r++);
                        }), s++);
                    });
                }), t.getCatalog(function() {
                    t.data.categoryListDatas.forEach(function(t, a) {
                        i.forEach(function(a, e) {
                            a.category_id == t.id && (a.category_name = t.name);
                        });
                    }), console.log(44, i), t.setData({
                        ellipsisSchedule: i
                    });
                }));
            }
            a.getCourseComments();
        },
        fail: function() {}
    });
}), e(a, "getCourseComments", function() {
    var t = this, a = "", e = 0, d = !1, n = this.data.group_id;
    wx.request({
        url: s.hostJAPI + "/comment/v1/getGoodsGroupComments",
        data: {
            appid: r.appid,
            goodsGroupId: this.data.group_id,
            from: 0,
            rows: 2,
            passport: wx.getStorageSync(s.tokenKey) || "",
            platform: s.platform,
            org_id: s.orgId,
            _os: s.os,
            _v: r.version,
            _t: i.timeStamp()
        },
        method: "GET",
        dataType: "json",
        success: function(s) {
            if (0 == s.data.status.code) {
                0 == (a = s.data.data).total && (d = !0), a.dataList && a.dataList.length > 0 && (0 != a.total ? (e = a.total, 
                a.dataList.forEach(function(t, a) {
                    t.createDateFMT = i.formatTime(new Date(t.createDate));
                }), a.total > 2 && !0) : d = !0), t.setData({
                    commentData: {
                        groupId: n,
                        total: e,
                        datalList: a.dataList,
                        showMore: !1,
                        dataEmpty: d
                    }
                }, function() {
                    t.selectQuery(), t.data.timerQuery = setTimeout(function() {
                        t.selectQuery(), i.hideLoading();
                    }, 2e3);
                }), t.data.tabCourseLoading = !1, t.data.teacherIDArr = [], t.data.teacherNameArr = [], 
                t.data.cData.teachers && t.data.cData.teachers.length > 0 && t.data.cData.teachers.forEach(function(a) {
                    t.data.teacherIDArr.push(a.id + ""), t.data.teacherNameArr.push(a.name);
                });
                var r = "其他", c = "课程详情页";
                1 == t.s && (r = "首页", c = 1 == t.t ? "轮播图" : "考试意向课程列表"), i.reportEvent(o, "viewCourseDetail", {
                    belongPage: r,
                    belongSeat: c,
                    seatNum: "",
                    courseID: t.data.group_id + "",
                    courseName: t.data.cData.name,
                    examinationID: t.data.categoryInfo.gid + "",
                    examinationName: t.data.categoryInfo.gname,
                    originalPriceMax: parseInt(t.data.cData.max_price, 10),
                    originalPriceMin: parseInt(t.data.cData.min_price, 10),
                    currentPriceMax: parseInt(t.data.cData.max_sale_price, 10),
                    currentPriceMin: parseInt(t.data.cData.min_sale_price, 10),
                    teacherIDs: t.data.teacherIDArr,
                    teacherNames: t.data.teacherNameArr,
                    commentNum: t.data.commentData && t.data.commentData.total || 0,
                    isTryListen: t.data.tryListen
                });
            }
        },
        fail: function(t) {},
        complete: function() {}
    });
}), e(a, "setmode", function(t) {
    var a = this.data.cData, e = a.max_price, o = a.max_sale_price, s = a.min_price, r = a.min_sale_price;
    if (e == o && s == r && e == s && 0 == e ? this.data.mode = 6 : e == o && s == r && e == s ? this.data.mode = 1 : e == o && s == r && e != s ? this.data.mode = 2 : e == o && s == r || e != s ? e == o && s == r || e == s || ("reset" == t ? this.data.mode = 2 : (this.data.mode = 4, 
    this.timef())) : "reset" == t ? this.data.mode = 1 : (this.data.mode = 3, this.timef()), 
    this.data.isShowMember && (5 != this.data.mode || 6 != this.data.mode)) {
        var d = a.min_user_member_price;
        (d <= r || this.data.activityData && d <= this.data.activityData.info.min_price) && (d != a.max_sale_price && this.setData({
            duozhi: 1
        }), this.setData({
            isShowMember: 1,
            minMemberPrice: d
        }));
    }
    this.setData({
        mode: this.data.mode,
        maxo: parseInt(e),
        mino: parseInt(s),
        maxn: parseInt(o),
        minn: parseInt(r)
    }), 2 == i.checkOS() && 0 == this.data.realNum && 6 != this.data.mode && this.data.grayLevel && this.setData({
        tab: "tab2"
    });
}), e(a, "timef", function() {
    var t = this, a = t.data.cData.activity_end_time;
    t.data.startTimeTeam = setInterval(function() {
        var e, o, i, s, r = a - new Date().getTime();
        r >= 0 ? (e = Math.floor(r / 1e3 / 60 / 60 / 24), o = Math.floor(r / 1e3 / 60 / 60 % 24), 
        i = Math.floor(r / 1e3 / 60 % 60), s = Math.floor(r / 1e3 % 60)) : (e = 0, o = 0, 
        i = 0, s = 0, t.clearInfo()), t.setData({
            djs1: t.b(e, 2),
            djs2: t.b(o, 2),
            djs3: t.b(i, 2),
            djs4: t.b(s, 2)
        });
    }, 1e3);
}), e(a, "b", function(t, a) {
    var e = String(Math.abs(t));
    return e.length < a && (e = "0" + e), e;
}), e(a, "clearInfo", function() {
    clearInterval(this.data.startTimeTeam), this.setmode("reset");
}), e(a, "setButton", function() {
    var t = this;
    "" == t.data.token && (t.data.bmode = 1), wx.request({
        url: s.host + "/mobile/v2/goods/groups_goods",
        data: {
            gpid: t.data.group_id,
            edu24ol_token: wx.getStorageSync(s.tokenKey) || "",
            org_id: s.orgId,
            appid: r.appid,
            _v: r.version,
            _os: s.os,
            terminalType: s.terminalType,
            terminal_type: s.terminalType
        },
        method: "GET",
        dataType: "json",
        success: function(a) {
            if (40042 == a.data.status.code) t.data.bmode = 1; else if (0 == a.data.status.code) {
                for (var e = 1, o = 0; o < a.data.data.length; o++) {
                    var s = a.data.data[o];
                    s.state = 0, s.tag_state = 0, 0 == a.data.data[o].bought_status && (e = 0), a.data.data[o].giftList && a.data.data[o].giftList.map(function(t) {
                        t.startTime = t.start_time ? i.timeFormat(t.start_time, "yyyy年mm月dd日") : "", t.endTime = t.end_time ? i.timeFormat(t.end_time, "yyyy年mm月dd日") : "";
                    }), s.memberClass = "", s.isShowMemberPrice = 0, s.user_member_price = Math.floor(s.user_member_price), 
                    s.sale_price = Math.floor(s.sale_price), s.is_member_sales && s.user_member_price <= s.sale_price && (s.isShowMemberPrice = 1, 
                    s.memberClass = "item-member");
                }
                1 == a.data.data.length ? 1 == t.data.cData.realNum ? t.data.bmode = 4 : t.data.bmode = 6 : 1 == t.data.cData.realNum ? t.data.bmode = 5 : t.data.bmode = 7, 
                1 == e && (t.data.bmode = 2), t.data.cData.limit && t.data.cData.limit <= t.data.buyer_count + t.data.bought_count && 2 != t.data.bmode && (t.data.bmode = 3);
            }
            if ("" == t.data.token && 3 != t.data.bmode && (t.data.bmode = 1), a.data.data.forEach(function(t, a) {
                t.sale_price = Math.floor(t.sale_price);
            }), 2 == t.data.cData.course_type && 4 == t.data.bmode) {
                var r = a.data.data[0], d = 0;
                r.tag_state = 1, t.data.totalGoodsIds = [ r.id ], d = r.isShowMemberPrice && r.user_member_price ? r.user_member_price : r.sale_price, 
                r.price, t.setData({
                    totalCoursePrice: d,
                    totalCourseOriginalPrice: d
                });
            }
            t.setData({
                bmode: t.data.bmode,
                cList: a.data.data
            }), t.data.productIsSchedule && (t.getSchedules(t.data.cList[0].id), t.freeStudyLessonList(), 
            wx.hideLoading());
        },
        fail: function() {}
    });
}), e(a, "getSchedules", function(t) {
    var a = this, e = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : 0;
    this.data.cList[e].schedulesListLoaded || wx.request({
        url: s.adminApi + "/goods-siteapp/app/v2/course-schedules/list",
        data: {
            goodsId: t,
            org_id: s.orgId,
            appid: r.appid,
            platform: s.platform,
            passport: wx.getStorageSync("hq_token") || ""
        },
        method: "GET",
        dataType: "json",
        headers: {
            orgId: s.orgId,
            appId: r.appid,
            "edu24ol-token": wx.getStorageSync("hq_token")
        },
        success: function(t) {
            console.log("course-schedules/list", t), 0 == t.data.code && (t.data.data && t.data.data.forEach(function(t, a) {
                t.stageGroups.forEach(function(t, a) {
                    t.stages.forEach(function(t, a) {
                        t.simpleList = [], t.simpleListLoaded = !1, t.up = !1;
                    });
                });
            }), a.data.cList[e].schedulesList = t.data.data, a.data.cList[e].schedulesListLoaded = !0, 
            a.setData({
                cList: a.data.cList
            }));
        },
        fail: function(t) {}
    });
}), e(a, "selectGroupsGoodsList", function(t) {
    var a = t.currentTarget.dataset;
    this.getSchedules(a.item.id, a.index), this.setData({
        groupsGoodsIndex: a.index
    });
}), e(a, "selectSchedulesList", function(t) {
    var a = t.currentTarget.dataset;
    this.data.cList[a.index].schedulesListIndex = a.scindex, this.setData({
        cList: this.data.cList
    });
}), e(a, "getSimpleList", function(t) {
    var a = t.currentTarget.dataset;
    console.log(333, a), this.simpleList(a.item.id, a.scitem.scheduleId, a.stitem.stageId, a.scindex, a.sindex, a.stindex);
}), e(a, "simpleList", function(t, a, e, o, d, n) {
    var c = this;
    console.log(t, a, e, o, d, n);
    var u = this.data.cList[this.data.groupsGoodsIndex].schedulesList[o].stageGroups[d].stages[n];
    u.up = !u.up, u.simpleListLoaded ? this.setData({
        cList: this.data.cList
    }) : wx.request({
        url: s.adminApi + "/goods-siteapp/app/v2/course-lessons/simple-list",
        data: {
            goodsId: t,
            scheduleId: a,
            stageId: e,
            org_id: s.orgId,
            appid: r.appid,
            pschId: s.pschId,
            platform: s.platform,
            schId: s.orgId
        },
        method: "GET",
        dataType: "json",
        headers: {
            orgId: s.orgId,
            appId: r.appid,
            "edu24ol-token": wx.getStorageSync("hq_token")
        },
        success: function(t) {
            0 == t.data.code && (t.data.data.forEach(function(t, a) {
                if (t.duration) {
                    var e = i.formatDuration(t.duration);
                    t.durationFormat = e.h + ":" + e.m + ":" + e.s;
                }
            }), u.simpleList = t.data.data, u.simpleListLoaded = !0, c.setData({
                cList: c.data.cList
            }));
        }
    });
}), e(a, "goVideo", function(t) {
    var a = function(t) {
        t ? wx.navigateTo({
            url: "/pages/video/video?url=" + encodeURIComponent(t)
        }) : wx.showToast({
            title: "暂无视频",
            icon: "none"
        });
    }, e = t.currentTarget.dataset;
    if (e.simitem.needDetails) {
        if (e.simitem.videoInfo && e.simitem.videoInfo.mediaInfos) {
            var o = e.simitem.videoInfo.mediaInfos;
            a(o.fhd_m3u8 && o.fhd_m3u8.url || o.hd_m3u8 && o.hd_m3u8.url || o.sd_m3u8 && o.sd_m3u8.url);
        }
    } else a(e.simitem.hdUrl || e.simitem.mdUrl || e.simitem.sdUrl);
}), e(a, "getFreeLessonVideoList", function() {
    var t = this;
    wx.request({
        url: s.hostJAPI + "/uc/v3/study/group/getFreeLessonVideoList",
        data: {
            goodsGroup: this.data.group_id,
            appid: r.appid,
            platform: s.platform,
            org_id: s.orgId,
            _os: s.os,
            _v: r.version,
            _t: i.timeStamp()
        },
        method: "GET",
        dataType: "json",
        success: function(a) {
            0 == a.data.status.code && ((a.data.data || []).forEach(function(t, a) {
                t.lessonId = t.id, t.needDetails = 1;
            }), t.setData({
                freeStudyLessonList: a.data.data || []
            }));
        }
    });
}), e(a, "freeStudyLessonList", function() {
    var t = this;
    wx.request({
        url: s.adminApi + "/goods-siteapp/app/v2/course-lessons/freeStudyLessonList",
        data: {
            hqGroupId: this.data.group_id,
            org_id: s.orgId,
            appid: r.appid,
            platform: s.platform
        },
        method: "GET",
        dataType: "json",
        headers: {
            orgId: s.orgId,
            appId: r.appid,
            "edu24ol-token": wx.getStorageSync("hq_token")
        },
        success: function(a) {
            0 == a.data.code && t.setData({
                freeStudyLessonList: a.data.data || []
            });
        }
    });
}), e(a, "changeWinGiftState", function(t) {
    for (var a = t.currentTarget.dataset.state, e = t.currentTarget.dataset.id, o = this.data.cList, i = 0; i < o.length; i++) if (o[i].id == e) {
        o[i].state = !a;
        break;
    }
    this.setData({
        cList: o
    });
}), e(a, "ifLogin", function(t) {
    o.globalData.appBaseInfo ? "function" == typeof t && t() : o.getUserInfo(function(a) {
        "function" == typeof t && t();
    });
}), e(a, "goBuyPage", function(t) {
    var a = this, e = t.currentTarget.dataset.free, o = t.currentTarget.dataset.realNum;
    0 == e && 2 == i.checkOS() && 0 == o ? a.showIOSTips() : (wx.removeStorageSync("realNum"), 
    wx.setStorage({
        key: "realNum",
        data: a.data.group_id,
        success: function() {
            a.ifLogin(function() {
                if (2 != a.data.cData.course_type) {
                    a.saveTrainingData([ a.data.cList[0].id ]);
                    var e = "/pages/orderDetail/orderDetail?groupId=".concat(a.data.group_id, "&goodsId=").concat(a.data.cList[0].id, "&gid=").concat(a.data.cData.second_category);
                    2 == a.data.cData.course_type && a.data.goodsNum && (e += "&num=".concat(a.data.goodsNum, "&courseType=2")), 
                    wx.navigateTo({
                        url: e,
                        success: function() {
                            a.buyBtnReport();
                        }
                    });
                } else a.goBuyList(t);
            });
        }
    }));
}), e(a, "goBuyList", function(t) {
    var a = this, e = t.currentTarget.dataset.free, o = t.currentTarget.dataset.realNum;
    0 == e && 2 == i.checkOS() && 0 == o ? a.showIOSTips() : (wx.removeStorageSync("realNum"), 
    wx.setStorage({
        key: "realNum",
        data: a.data.group_id,
        success: function() {
            a.ifLogin(function() {
                a.buyBtnReport(), a.setData({
                    isHiddenWinBox: !1,
                    winBoxType: 3,
                    scrollTop: 0
                });
            });
        }
    }));
}), e(a, "changeGoodsNum", function(t) {
    var a = t.detail.value, e = "", o = "";
    a < 0 ? (a = 1, e = "dis") : a > 999 ? (a = 999, o = "dis") : (e = "", o = ""), 
    this.setData({
        goodsNum: a,
        reduceBtn: e,
        addBtn: o
    });
}), e(a, "blurGoodsNum", function(t) {
    0 == t.detail.value && this.setData({
        goodsNum: 1
    });
}), e(a, "addGoodsNum", function() {
    999 != this.data.goodsNum && (this.data.goodsNum++, 999 == this.data.goodsNum && this.setData({
        addBtn: "dis"
    }), this.setData({
        goodsNum: this.data.goodsNum,
        reduceBtn: ""
    }));
}), e(a, "reduceGoodsNum", function() {
    1 != this.data.goodsNum && (this.data.goodsNum--, 1 == this.data.goodsNum && this.setData({
        reduceBtn: "dis"
    }), this.setData({
        goodsNum: this.data.goodsNum,
        addBtn: ""
    }));
}), e(a, "buyBtnReport", function() {
    console.log("buyBtnReport");
    var t = [], a = [], e = [], s = 0;
    this.data.cList.forEach(function(o) {
        t.push(o.id + ""), a.push(o.name + ""), e.push(o.alias + ""), s += o.gift_count;
    }), i.reportEvent(o, "buyNow", {
        courseID: this.data.cList[0].id + "",
        courseName: this.data.cList[0].name,
        examinationID: this.data.categoryInfo.gid + "",
        examinationName: this.data.categoryInfo.gname,
        originalPrice: parseInt(this.data.cData.max_sale_price, 10),
        currentPrice: parseInt(this.data.cData.min_sale_price, 10),
        teacherIDs: this.data.teacherIDArr,
        teacherNames: this.data.teacherNameArr,
        commentNum: this.data.commentData && this.data.commentData.total || 0,
        isTryListen: this.data.tryListen,
        goodsIDs: t,
        goodsTitles: a,
        goodsAliasNames: e,
        giftNum: s || 0,
        purchasedNum: parseInt(this.data.bought_count + this.data.buyer_count, 10),
        limitNum: parseInt(this.data.cData.limit || 0, 10),
        discountCountdown: "剩".concat(this.data.djs1, "天", this.data.djs2, "小时", this.data.djs3, "分", this.data.djs4, "秒"),
        belongPage: "课程详情页",
        belongSeat: "购买区域",
        pre_course: this.data.mainGroupId == this.data.cList[0].id ? "" : this.data.cList[0].name
    });
}), e(a, "goFree", function(t) {
    var a = this, e = this.data.cList[0].id.toString();
    i.showLoading({
        title: "开通中...",
        mask: !0
    }), 1 == t && (e = this.data.totalGoodsIds.toString()), a.buyBtnReport(), wx.request({
        url: "".concat(s.hostJAPI, "/buy/order/qboxCreateOrder"),
        data: {
            groupId: a.data.group_id,
            edu24ol_token: wx.getStorageSync(s.tokenKey) || "",
            goodsId: e,
            salesSrc: wx.getStorageSync("wxEduCd"),
            org_id: s.orgId,
            appid: r.appid,
            _v: r.version,
            _os: s.os
        },
        method: "POST",
        header: {
            "content-type": "application/x-www-form-urlencoded"
        },
        success: function(t) {
            if (0 == t.data.status.code) {
                o.actionSourceSave(t.data.data.buyOrderId, 3);
                var i = {
                    goodsId: e,
                    buyOrderId: t.data.data.buyOrderId
                };
                a.data.training ? a.getOrderInfo(t.data.data.buyOrderCode, function(o) {
                    o ? (a.saveTrainingData(e.split(",")), wx.redirectTo({
                        url: "/subpackages/pages/trainingSuccess/trainingSuccess?groupId=" + a.data.group_id + "&orderId=" + t.data.data.buyOrderId
                    })) : a.goPaySuccess(i);
                }) : a.goPaySuccess(i);
            }
        }
    });
}), e(a, "getOrderInfo", function(t, a) {
    wx.request({
        url: s.host + "/mobile/v2/trade/orderInfo",
        data: {
            orderCode: t,
            edu24ol_token: wx.getStorageSync(s.tokenKey) || "",
            org_id: s.orgId,
            appid: r.appid,
            _v: r.version,
            _os: s.os
        },
        method: "GET",
        dataType: "json",
        success: function(t) {
            wx.hideLoading();
            var e = !1;
            if ([ 0, 10003 ].includes(t.data.status.code)) {
                var o = t.data.data.orderInfo;
                o && o.buyOrderDetailList && o.buyOrderDetailList.length > 0 && o.buyOrderDetailList.forEach(function(t, a) {
                    t.goods && 3 == t.goods.goodsCategory && (e = !0);
                }), "function" == typeof a && a(e);
            }
        }
    });
}), e(a, "goPaySuccess", function(t) {
    var a = "/pages/paySuccess/paySuccess?isFree=1&goodsId=".concat(t.goodsId, "&groupId=").concat(this.data.group_id, "&gid=").concat(this.data.cData.second_category, "&buyOrderId=").concat(t.buyOrderId);
    console.log(999, "paySuccess", a), wx.redirectTo({
        url: a
    }), console.log("开通成功去成功页面");
}), e(a, "showIOSTips", function() {
    wx.showModal({
        title: "请前往Android端手机激活",
        content: "基于微信小程序平台的运营规范，小程序暂不支持IOS设备激活课程，请前往Android端手机激活课程",
        showCancel: !1,
        success: function(t) {
            t.confirm || t.cancel;
        }
    });
}), e(a, "goClassTabels", function(t) {
    t.currentTarget.dataset.gid;
    var a = t.currentTarget.dataset;
    wx.navigateTo({
        url: "/subpackages/pages/courseOutline/courseOutline?groupid=" + this.data.group_id + "&goodIndex=" + a.index
    });
}), e(a, "fromEduCd", function(t) {
    t && t.wxEduCd && wx.setStorageSync("wxEduCd", t.wxEduCd);
}), e(a, "getWedId", function() {
    var t = this;
    wx.getStorage({
        key: "webIdInfo",
        success: function(a) {
            t.data.webIdInfo = a.data || {};
        },
        fail: function(a) {
            t.data.webIdInfo = {};
        }
    });
}), e(a, "getUserInfoData", function(t) {
    var a = this;
    o.getUserInfo(function(t) {
        a.getGoodsGroupDetails();
    }, this);
}), e(a, "contact", function() {
    i.reportEvent(o, "consultCourse", {
        belongPage: "课程详情页",
        consultModule: "课程咨询",
        courseID: this.data.categoryInfo.gid + "",
        courseName: this.data.categoryInfo.gname
    }), i.reportEvent(o, "MPNewsService", {
        belongPage: "课程详情页",
        examinationID: this.data.categoryInfo.gid || 0,
        isSend: !1
    });
}), e(a, "kefu", function() {
    i.reportEvent(o, "addWeChatClick", {
        belongPage: "课程详情页",
        examinationName: this.data.categoryInfo.gid || 0
    });
}), e(a, "chooseCourse", function(t) {
    var a = t.currentTarget.dataset;
    2 == this.data.cData.course_type ? this.chooseCourseSingle(a) : this.chooseCourseMultiple(a);
}), e(a, "chooseCourseSingle", function(t) {
    for (var a = t.id, e = this.data.cList, o = "", i = [], s = "", r = 0; r < e.length; r++) {
        if (e[r].id == a) e[r].tag_state = 1, o = e[r].isShowMemberPrice ? e[r].user_member_price : e[r].sale_price, 
        s = e[r].price, i.push(e[r].id); else e[r].tag_state = 0;
    }
    this.setData({
        cList: e,
        totalCoursePrice: o,
        totalCourseOriginalPrice: s,
        selectedCourseCount: 1,
        totalGoodsIds: i
    });
}), e(a, "chooseCourseMultiple", function(t) {
    var a = t.type, e = t.id, o = t.state, i = this.data.cList, s = this.data.totalCoursePrice, r = this.data.totalCourseOriginalPrice, d = this.data.selectedCourseCount, n = this.data.totalGoodsIds, c = 0;
    if (1 != o) {
        for (var u = 0; u < i.length; u++) if (i[u].id == e) {
            i[u].tag_state = 1 == a ? 0 : 1;
            var l = i[u].isShowMemberPrice ? i[u].user_member_price : i[u].sale_price;
            0 == a ? (s += l, r += i[u].price, n.push(i[u].id), d++) : (s -= l, r -= i[u].price, 
            d--);
            break;
        }
        if (1 == a) {
            for (var h = 0; h < n.length; h++) n[h] == e && (c = h);
            n.splice(c, 1);
        }
        this.setData({
            cList: i,
            totalCoursePrice: s,
            totalCourseOriginalPrice: r,
            selectedCourseCount: d,
            totalGoodsIds: n
        });
    } else this.showCourseTips();
}), e(a, "getMemberDetailByType", function() {
    var t = this, a = {
        accountType: 0,
        edu24ol_token: wx.getStorageSync("hq_token")
    };
    wx.request({
        url: "".concat(s.hostJAPI, "/member/getMemberDetailByType"),
        data: a,
        success: function(a) {
            0 == a.data.status.code && a.data.data.userLevel.privilegeList.forEach(function(a, e) {
                "sales_buy_course" == a.type && t.setData({
                    salesBuyCourse: a
                });
            });
        }
    });
}), e(a, "showCourseTips", function() {
    wx.showToast({
        title: "本课程已报名",
        icon: "none"
    });
}), e(a, "buythis", function() {
    var t = 1, a = this.data.cList, e = this.data.totalGoodsIds;
    if (0 != e.length) {
        for (var o = 0; o < a.length; o++) for (var i = 0; i < e.length; i++) a[o].id == e[i] && (0 == parseInt(a[o].price, 10) && 0 == parseInt(a[o].sale_price, 10) || (t = 0));
        if (1 == t && 0 == this.data.realNum) this.goFree(1); else {
            this.saveTrainingData(e);
            var s = "/pages/orderDetail/orderDetail?groupId=".concat(this.data.group_id, "&goodsId=").concat(e, "&gid=").concat(this.data.cData.second_category);
            2 == this.data.cData.course_type && this.data.goodsNum && (s += "&num=".concat(this.data.goodsNum, "&courseType=2")), 
            wx.navigateTo({
                url: s
            });
        }
    }
}), e(a, "changeTeacherState", function(t) {
    var a = t.currentTarget.dataset;
    this.data.teacherData.forEach(function(t, e) {
        a.id == t.id && (t.actionsState = 0 == a.state ? 1 : 0);
    }), this.setData({
        teacherData: this.data.teacherData
    });
}), e(a, "requestSubscribeMessage", function() {
    var t = this;
    wx.canIUse("requestSubscribeMessage") ? wx.requestSubscribeMessage({
        tmplIds: [ "vW34jds4uYqJ2pm_588TjkBqZMg2v5cLI00T522UL4M" ],
        success: function(a) {
            if ("requestSubscribeMessage:ok" == a.errMsg) if ("accept" == a.vW34jds4uYqJ2pm_588TjkBqZMg2v5cLI00T522UL4M) {
                var e = {
                    vW34jds4uYqJ2pm_588TjkBqZMg2v5cLI00T522UL4M: a.vW34jds4uYqJ2pm_588TjkBqZMg2v5cLI00T522UL4M
                };
                o.addSubscribeMsg(e, function() {
                    t.collectGoodsGroup();
                });
            } else wx.showToast({
                title: "订阅失败",
                icon: "none"
            });
        }
    }) : wx.showModal({
        title: "提示",
        content: "当前微信版本过低，无法使用该功能，请升级到最新微信版本后重试。",
        showCancel: !1
    });
}), e(a, "collectGoodsGroup", function() {
    wx.request({
        url: s.host + "/wxapp/v1/goods/collectGoodsGroup",
        method: "POST",
        header: {
            "content-type": "application/x-www-form-urlencoded"
        },
        data: {
            _appid: r.appid,
            _os: s.os,
            _v: r.version,
            _t: i.timeStamp(),
            org_id: s.orgId,
            platform: s.platform,
            app_id: r.app_id,
            mp: r.appid,
            open_id: this.data.openid,
            group_id: this.data.group_id,
            group_name: this.data.groupname,
            type: 1,
            edu24ol_token: wx.getStorageSync(s.tokenKey) || ""
        },
        success: function() {},
        complete: function() {
            "function" == typeof callback && callback();
        }
    });
}), e(a, "scKFEvent", function() {
    i.reportEvent(o, "MpClick", {
        belongPage: this.route,
        clickElement: "客服",
        nextPage: "pages/service/service"
    });
}), e(a, "queryBuyOrderGroupVO", function() {
    var t = this;
    d.queryBuyOrderGroupVO({
        from: 0,
        rows: 10,
        token: this.data.token,
        courseId: this.data.group_id,
        returnPath: "/pages/courseDetail/courseDetail?id=".concat(this.data.group_id)
    }, function(a) {
        if (0 == a.data.status.code) {
            var e = a.data.data, o = [], s = [];
            if (e.buyOrderGroupList.forEach(function(t, a) {
                1 == t.state && (t.activityTime = i.countTime(3, t.endDate), t.userPhoto = "https://oss-hqwx-edu24ol.hqwx.com/9f1b0ce0a89de554908dc69e541a0dec9f70ab21.png", 
                s.push(t));
            }), s.length <= 2) o.push(s); else for (var r = [], d = 0; d < s.length; d++) {
                var n = s[d];
                if (d == s.length - 1 && d % 2 == 0) {
                    r.push(n), o.push(r);
                    break;
                }
                r.push(n), d % 2 == 1 && (o.push(r), r = []);
            }
            e.groupArray = o, t.getGroupListGoodsData(), t.setData({
                buyOrderGroupListData: e
            });
        }
    });
}), e(a, "getGroupListGoodsData", function() {
    var t = this;
    d.groupListGoods({
        token: this.data.token,
        courseId: this.data.group_id,
        returnPath: "/pages/courseDetail/courseDetail?id=".concat(this.data.group_id)
    }, function(a) {
        if (0 == a.data.status.code) {
            var e = a.data.data, o = t.data.activityData, i = Object.assign({}, {
                activity: o.info,
                course: {
                    course_id: t.data.group_id,
                    goods: e.goods,
                    name: t.data.groupname
                },
                pintuan: {
                    id: e.pintuan_id
                },
                user_pintuan_status: 0,
                gid: t.data.cData.second_category
            });
            t.data.groupData = i, t.setData({
                listGroupData: e
            });
        }
    });
}), e(a, "onGoGroupDetail", function(t) {
    var a;
    a = {
        currentTarget: {
            dataset: t.detail
        }
    }, this.goGroupDetail(a);
}), e(a, "goGroupDetail", function(t) {
    var a = t.currentTarget.dataset, e = "/pages/groupDetail/groupDetail?groupId=".concat(a.groupId);
    if (!this.data.token) return e = "/pages/login/login?sourcePath=" + encodeURIComponent(e), 
    void wx.navigateTo({
        url: e
    });
    wx.navigateTo({
        url: e
    });
}), e(a, "onShowWinGroup", function(t) {
    var a;
    a = {
        currentTarget: {
            dataset: t.detail
        }
    }, this.showWinGroup(a);
}), e(a, "showWinGroup", function(t) {
    var a = t.currentTarget.dataset, e = "", o = "";
    if (this.data.token) 1 == a.type && (e = this.data.groupData, o = a), this.setData({
        winGroupState: !0,
        winGroupType: a.type,
        groupData: e,
        joinGroupData: o
    }); else {
        var i = "/pages/courseDetail/courseDetail?id=".concat(this.data.group_id);
        wx.navigateTo({
            url: "/pages/login/login?sourcePath=" + encodeURIComponent(i)
        });
    }
}), e(a, "closeWinGroup", function(t) {
    t.currentTarget.dataset;
    this.setData({
        winGroupState: !1,
        winGroupType: -1
    });
}), e(a, "goLogin", function() {
    var t = "/pages/courseDetail/courseDetail?id=".concat(wx.getStorageSync("lastCourseId"));
    wx.navigateTo({
        url: "/pages/login/login?sourcePath=" + encodeURIComponent(t)
    });
}), e(a, "onShareAppMessage", function(t) {
    var a = "/pages/courseDetail/courseDetail?id=" + wx.getStorageSync("lastCourseId"), e = this.data.webIdInfo.web_id ? a + "&web_id=" + this.data.webIdInfo.web_id : a + "&wxEduCd=" + wx.getStorageSync("wxEduCd"), i = "我发现一个不错的课程，".concat(this.data.cData.name), s = "menu" == t.from ? "右上角分享" : "分享按钮";
    return o.appShare({
        belongPage: "课程详情页",
        shareContentID: this.data.options.id,
        shareButton: s,
        shareContent: this.data.cData.name
    }), e = "".concat(e).concat(o.globalData.uuid ? "&shareId=" + o.globalData.uuid : ""), 
    console.log(9999, e), {
        title: i,
        path: e,
        imageUrl: "https://oss-hqwx-edu24ol.hqwx.com/miniapp/hq_mall/share/course_detail.png",
        success: function(t) {}
    };
}), a));