getApp(), require("../../utils/util");

var t = require("../../configs/baseConfig"), i = (require("../../configs/config_" + t.appName), 
require("../../utils/request")), a = require("../../pages/template/template");

Page({
    data: {
        token: "",
        categoryInfo: "",
        openid: "",
        courseLeft: 0,
        giftData: [],
        dataEmpty: !1,
        isSubmitting: !1,
        timer: null,
        web_id: "",
        activityGid: ""
    },
    onLoad: function(t) {
        t && t.gid && (this.data.activityGid = t.gid), this.data.token = wx.getStorageSync("hq_token"), 
        this.data.categoryInfo = wx.getStorageSync("categoryInfo"), this.data.openid = wx.getStorageSync("wxOpenId"), 
        this.data.web_id = wx.getStorageSync("webIdInfo").web_id, this.getGiftData();
    },
    getGiftData: function() {
        var t = this;
        wx.showLoading(), i.getGiftCourseList({
            token: this.data.token,
            gid: this.data.activityGid || this.data.categoryInfo.gid,
            openid: this.data.openid
        }, function(i) {
            if (0 == i.data.status.code) {
                var a = i.data.data;
                a.list && a.list.length > 0 ? t.setData({
                    giftData: a.list,
                    dataEmpty: !1
                }) : t.setData({
                    dataEmpty: !0
                }), t.setData({
                    courseLeft: a.left || 0
                }), wx.hideLoading();
            } else if (40042 == i.data.status.code) {
                var e = "/pages/login/login?sourcePath=" + encodeURIComponent("/pages/giftZhuli/giftZhuli?gid=" + t.data.activityGid);
                wx.redirectTo({
                    url: e
                });
            }
        });
    },
    goLearning: function() {
        a.navigateToMiniProgramPro(3, this.data.categoryInfo.gid, this.data.categoryInfo.gname, this.data.web_id);
    },
    getCourse: function(t) {
        var a = this, e = this, o = t.currentTarget.dataset;
        1 != this.data.isSubmitting && (this.data.isSubmitting = !0, wx.showLoading(), i.giftGoodsgroupForFree({
            token: this.data.token,
            giftid: o.giftid,
            goodsgroup: o.id
        }, function(t) {
            0 == t.data.status.code ? (wx.hideLoading(), wx.showToast({
                title: "恭喜您，领取成功！",
                icon: "none"
            }), a.data.timer = setTimeout(function() {
                clearTimeout(a.data.timer), wx.redirectTo({
                    url: "/pages/giftZhuli/giftZhuli?gid=".concat(e.data.activityGid)
                });
            }, 2e3)) : (wx.hideLoading(), wx.showToast({
                title: t.data.status.msg,
                icon: "none"
            })), a.data.isSubmitting = !1;
        }));
    }
});