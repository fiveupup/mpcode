var e, t = require("../../@babel/runtime/helpers/defineProperty"), a = getApp(), s = require("../../utils/util"), o = require("../../configs/baseConfig"), n = require("../../configs/config_" + o.appName);

Page((e = {
    data: {
        phone: "",
        password: "",
        errMsg: "",
        isShowWarn: !1,
        showPhoneDel: !1,
        showPasswordDel: !1,
        sourcePath: "/pages/user/user",
        sourceParams: "",
        isBind: 1,
        disabled: !0
    },
    onLoad: function(e) {
        this.data.firstPType = s.getUrlParams().firstPType || "", console.log("IdLogin", e), 
        this.setData({
            categoryInfo: wx.getStorageSync("categoryInfo") || {}
        }), this.data.webIdInfo = wx.getStorageSync("webIdInfo") || {}, wx.removeStorageSync("hqUserInfo"), 
        wx.removeStorageSync(o.tokenKey), this.data.sourcePath = decodeURIComponent(e.sourcePath) || this.data.sourcePath;
    },
    hideWarn: function() {
        var e = this;
        setTimeout(function() {
            e.setData({
                isShowWarn: !1
            });
        }, 2e3);
    },
    showWarn: function(e) {
        this.setData({
            warnText: e,
            isShowWarn: !0
        }), this.hideWarn();
    },
    bindPhoneInput: function(e) {
        e.detail.value.length < 1 || this.data.password.length < 1 ? this.data.disabled = !0 : this.data.disabled = !1, 
        this.setData({
            disabled: this.data.disabled,
            phone: e.detail.value,
            showPhoneDel: !0
        });
    },
    bindPasswordInput: function(e) {
        e.detail.value.length < 1 || this.data.phone.length < 1 ? this.data.disabled = !0 : this.data.disabled = !1, 
        this.setData({
            disabled: this.data.disabled,
            password: e.detail.value,
            showPasswordDel: !0
        });
    },
    bindPhoneBlur: function() {
        this.setData({
            showPhoneDel: !1
        });
    },
    bindPasswordBlur: function(e) {
        this.setData({
            showPasswordDel: !1
        });
    },
    bindPhoneFocus: function(e) {
        this.sOrHDel(e, "showPhoneDel");
    },
    bindPasswordFocus: function(e) {
        this.sOrHDel(e, "showPasswordDel");
    },
    delPhone: function() {
        var e = this;
        setTimeout(function() {
            e.setData({
                phone: "",
                showPhoneDel: !1
            });
        }, 200);
    },
    delPassword: function() {
        var e = this;
        setTimeout(function() {
            e.setData({
                password: "",
                showPasswordDel: !1
            });
        }, 200);
    },
    sOrHDel: function(e, a) {
        "" == e.detail.value ? this.setData(t({}, a, !1)) : this.setData(t({}, a, !0));
    },
    submitLogin: function() {
        var e = this;
        if ("" != e.data.phone) if ("" != e.data.password) {
            s.reportEvent(a, "clickLoginButton", {}), s.showLoading({
                title: "登录中...",
                mask: !0
            });
            var t = wx.getStorageSync("regtype") || "", i = a.setExtProperties();
            a.getUserInfo(function() {
                wx.request({
                    url: o.host + "/wxapp/v1/user/login",
                    method: "POST",
                    dataType: "json",
                    header: {
                        "content-type": "application/x-www-form-urlencoded"
                    },
                    data: {
                        srcType: n.srcType,
                        firstPType: e.data.firstPType || n.firstPType,
                        lastPType: n.lastPType,
                        isBind: e.data.isBind,
                        appid: n.appid,
                        org_id: o.orgId,
                        platform: o.platform,
                        encryptedData: encodeURIComponent(a.globalData.appBaseInfo.encryptedData),
                        code: encodeURIComponent(a.globalData.code),
                        sessionKey: encodeURIComponent(wx.getStorageSync("sessionKey")),
                        iv: encodeURIComponent(a.globalData.appBaseInfo.iv),
                        name: e.data.phone,
                        pwd: e.data.password,
                        smsCode: 0,
                        regtype: t,
                        distinct_id: n.sdid,
                        extProperties: i
                    },
                    success: function(t) {
                        if (console.log("submitLogin", t), 239 == t.data.status.code) {
                            var n = t.data.data;
                            wx.showModal({
                                title: "提示",
                                content: "当前账号已绑定其它微信号，继续登录需解除已有绑定。是否继续解绑操作？",
                                cancelText: "放弃",
                                confirmText: "继续解绑",
                                success: function(e) {
                                    e.confirm ? (wx.setStorage({
                                        key: "hqUserInfo",
                                        data: n
                                    }), wx.setStorage({
                                        key: o.tokenKey,
                                        data: n.token
                                    }), wx.redirectTo({
                                        url: "/pages/unbindAccount/unbindAccount"
                                    })) : e.cancel && s.showToast2("未完成解绑，登录失败。");
                                }
                            }), s.hideLoading();
                        } else 0 == t.data.status.code ? (s.userBindReport(a, t.data.data.uid), wx.getStorageSync("zhuliReg") && (wx.removeStorageSync("zhuliReg"), 
                        t.data.data.loginReg && wx.setStorageSync("loginReg", 1)), wx.removeStorageSync("regtype"), 
                        wx.setStorage({
                            key: "hqUserInfo",
                            data: t.data.data
                        }), wx.setStorage({
                            key: o.tokenTimeStamp,
                            data: s.timeStamp()
                        }), wx.setStorage({
                            key: o.tokenKey,
                            data: t.data.data.token,
                            success: function() {
                                wx.reLaunch({
                                    url: e.data.sourcePath
                                });
                            }
                        }), s.hideLoading()) : (s.hideLoading(), e.showWarn(t.data.status.msg));
                    }
                });
            });
        } else e.showWarn("密码不能为空"); else e.showWarn("用户名/手机号不能为空");
    }
}, t(e, "showWarn", function(e) {
    var t = this;
    t.setData({
        showWarn: !0,
        errMsg: e
    }), setTimeout(function() {
        t.setData({
            showWarn: !1
        });
    }, 4e3);
}), t(e, "onShareAppMessage", function(e) {
    var t = "/pages/index/index?gid=" + this.data.categoryInfo.gid + "&gname=" + this.data.categoryInfo.gname;
    return t = this.data.webIdInfo.web_id ? t + "&web_id=" + this.data.webIdInfo.web_id : t, 
    {
        title: (a.globalData.userInfo ? a.globalData.userInfo.nickName : "环球网校_快题库") + "(每日一练)",
        path: t,
        success: function(e) {},
        fail: function(e) {}
    };
}), e));