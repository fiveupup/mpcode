var t = getApp(), a = require("../../utils/util"), e = require("../../configs/baseConfig"), i = (require("../../configs/config_" + e.appName), 
require("../../utils/request"));

Page({
    data: {
        web_id: "",
        groupData: "",
        groupMemberData: "",
        token: "",
        groupId: "384",
        timer: null,
        activityTime: "",
        winGroupState: !1,
        winGroupType: 0,
        joinGroupData: "",
        groupState: 0
    },
    onLoad: function(a) {
        a.web_id && (this.data.web_id = a.web_id, t.setWebIdToStorage(a.web_id)), this.data.groupId = a.groupId;
    },
    onShow: function(t) {
        var a = this;
        wx.getSetting({
            success: function(t) {
                "getSetting:ok" == t.errMsg && t.authSetting && t.authSetting["scope.userInfo"] && a.profile(function() {
                    a.getGroupData();
                });
            }
        });
    },
    onHide: function() {
        clearInterval(this.data.timer);
    },
    onUnload: function() {
        clearInterval(this.data.timer);
    },
    profile: function(t) {
        i.profile(function(i) {
            if (0 == i.data.status.code && i.data.data) {
                var o = i.data.data;
                wx.setStorageSync(e.tokenKey, o.token), wx.setStorageSync(e.tokenTimeStamp, a.timeStamp());
            }
            "function" == typeof t && t(i);
        }, function(a) {
            "function" == typeof t && t(res);
        });
    },
    getUserInfoData: function() {
        var t = this;
        this.profile(function() {
            t.getGroupData();
        });
    },
    getGroupData: function() {
        var t = this;
        i.activityInfoByPid({
            token: wx.getStorageSync(e.tokenKey),
            pintuanId: this.data.groupId,
            returnPath: "/pages/groupDetail/groupDetail?groupId=".concat(this.data.groupId)
        }, function(e) {
            if (0 == e.data.status.code) {
                var i = e.data.data, o = 0, n = new Date().getTime();
                (1 == i.activity.status || i.activity.end_time < n) && (o = -1), i.activity.min_price && (i.activity.min_price = Math.round(i.activity.min_price)), 
                t.setTime(i.pintuan.remain_time), t.setData({
                    groupData: i,
                    groupState: o
                }), wx.getStorageSync("categoryInfo") && wx.getStorageSync("categoryInfo").gid || wx.setStorageSync("categoryInfo", {
                    gid: i.course.second_category,
                    gname: i.course.second_category_name
                }), t.getGroupMemberData();
            } else a.hideLoading();
        });
    },
    getGroupMemberData: function() {
        var t = this;
        i.listUserByPid({
            token: wx.getStorageSync(e.tokenKey),
            pintuanId: this.data.groupId,
            returnPath: "/pages/groupDetail/groupDetail?groupId=".concat(this.data.groupId)
        }, function(e) {
            if (0 == e.data.status.code) {
                a.hideLoading();
                var i = e.data.data;
                t.setData({
                    groupMemberData: i
                });
            }
        });
    },
    setTime: function(t) {
        var e = this, i = "00", o = "00", n = "00", r = 0, u = 0;
        this.data.timer = setInterval(function() {
            if (u = 1e3 * t - 1e3 * r, r++, u <= 0) return clearInterval(e.data.timer), void e.setData({
                activityTime: {
                    hours: "00",
                    minutes: "00",
                    seconds: "00"
                }
            });
            u > 0 && (i = Math.floor(u / 36e5), o = Math.floor((u - 1e3 * i * 60 * 60) / 6e4), 
            n = Math.floor((u - 1e3 * i * 60 * 60 - 1e3 * o * 60) / 1e3)), e.setData({
                activityTime: {
                    hours: a.formatNumber(i),
                    minutes: a.formatNumber(o),
                    seconds: a.formatNumber(n)
                }
            });
        }, 1e3);
    },
    showWinGroup: function(t) {
        var a = t.currentTarget.dataset;
        this.setData({
            winGroupState: !0,
            winGroupType: a.type
        });
    },
    closeWinGroup: function(t) {
        this.setData({
            winGroupState: !1,
            winGroupType: 0,
            joinGroupData: ""
        });
    },
    joinGroup: function(t) {
        var a = t.currentTarget.dataset;
        if (wx.getStorageSync(e.tokenKey)) this.setData({
            winGroupState: !0,
            winGroupType: 1,
            joinGroupData: a
        }); else {
            var i = "/pages/groupDetail/groupDetail?groupId=".concat(this.data.groupId);
            wx.navigateTo({
                url: "/pages/login/login?sourcePath=" + encodeURIComponent(i)
            });
        }
    },
    onShareAppMessage: function(t) {
        var a = "/pages/groupDetail/groupDetail?groupId=" + this.data.groupId + "&web_id=" + this.data.web_id, e = this.data.groupData.activity.pintuan_num - this.data.groupMemberData.length, i = "仅差".concat(e, "人，").concat(this.data.groupData.activity.name, "（成团后自动开课）");
        return console.log(999, 222, i), {
            title: "",
            path: a,
            imageUrl: "",
            success: function(t) {}
        };
    }
});