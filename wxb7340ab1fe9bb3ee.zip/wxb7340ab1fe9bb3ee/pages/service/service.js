getApp();

var e = require("../../utils/util"), a = require("../../configs/baseConfig"), t = require("../../configs/config_" + a.appName);

Page({
    data: {
        path: "https://mapp.98809.com/mp/qiSdkCrmSenior.html"
    },
    onLoad: function(a) {
        var i = wx.getStorageSync("hqUserInfo"), o = i ? encodeURIComponent(i.uName) : "", r = wx.getStorageSync("qiUid");
        r || (r = e.randomString(), wx.setStorageSync("qiUid", r)), console.log("qiUid:", r);
        var n = "?schId=2&org_id=" + t.orgId + "&appid=" + t.appid + "&channelType=" + t.firstPType + "&sourceType=" + t.srcType + "&username=" + o + "&name=" + o + "&uid=" + r;
        for (var p in a) n += "&" + p + "=" + a[p];
        this.setData({
            path: this.data.path + n
        }), console.log(this.data.path);
    }
});