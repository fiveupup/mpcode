require("../../uni-bootstrap.js"), (global.webpackJsonp = global.webpackJsonp || []).push([ [ "pages/index/index" ], {
    42: function(t, e, n) {
        (function(t) {
            n(4);
            e(n(2));
            function e(t) {
                return t && t.__esModule ? t : {
                    default: t
                };
            }
            t(e(n(43)).default);
        }).call(this, n(1).createPage);
    },
    43: function(t, e, n) {
        n.r(e);
        var a = n(44), o = n(46);
        for (var i in o) "default" !== i && function(t) {
            n.d(e, t, function() {
                return o[t];
            });
        }(i);
        n(50);
        var s = n(10), r = Object(s.default)(o.default, a.render, a.staticRenderFns, !1, null, null, null, !1, a.components, void 0);
        r.options.__file = "pages/index/index.vue", e.default = r.exports;
    },
    44: function(t, e, n) {
        n.r(e);
        var a = n(45);
        n.d(e, "render", function() {
            return a.render;
        }), n.d(e, "staticRenderFns", function() {
            return a.staticRenderFns;
        }), n.d(e, "recyclableRender", function() {
            return a.recyclableRender;
        }), n.d(e, "components", function() {
            return a.components;
        });
    },
    45: function(t, e, n) {
        n.r(e), n.d(e, "render", function() {
            return o;
        }), n.d(e, "staticRenderFns", function() {
            return s;
        }), n.d(e, "recyclableRender", function() {
            return i;
        }), n.d(e, "components", function() {
            return a;
        });
        var a = {
            cBargainCard: function() {
                return n.e("components/c-bargain-card/c-bargain-card").then(n.bind(null, 294));
            },
            cBanner: function() {
                return n.e("components/c-banner/c-banner").then(n.bind(null, 301));
            },
            cExperience: function() {
                return n.e("components/c-experience/c-experience").then(n.bind(null, 308));
            },
            cMallCard: function() {
                return Promise.all([ n.e("common/vendor"), n.e("components/c-mall-card/c-mall-card") ]).then(n.bind(null, 315));
            },
            cTabBar: function() {
                return n.e("components/c-tabBar/c-tabBar").then(n.bind(null, 325));
            },
            cAuthorize: function() {
                return n.e("components/c-authorize/c-authorize").then(n.bind(null, 332));
            },
            cPopup: function() {
                return n.e("components/c-popup/c-popup").then(n.bind(null, 339));
            },
            cIcon: function() {
                return n.e("components/c-icon/c-icon").then(n.bind(null, 346));
            }
        }, o = function() {
            var t = this.$createElement;
            this._self._c;
        }, i = !1, s = [];
        o._withStripped = !0;
    },
    46: function(t, e, n) {
        n.r(e);
        var a = n(47), o = n.n(a);
        for (var i in a) "default" !== i && function(t) {
            n.d(e, t, function() {
                return a[t];
            });
        }(i);
        e.default = o.a;
    },
    47: function(t, e, n) {
        (function(t) {
            Object.defineProperty(e, "__esModule", {
                value: !0
            }), e.default = void 0;
            var a, o = (a = n(20)) && a.__esModule ? a : {
                default: a
            }, i = n(21), s = n(22);
            var r = getApp(), c = n(48), d = [ {
                images: "https://oss-hqwx-edu24ol.oss-cn-beijing.aliyuncs.com/miniapp/hq_mall/ico1.png",
                title: "考试介绍",
                url_type: 0
            }, {
                images: "https://oss-hqwx-edu24ol.oss-cn-beijing.aliyuncs.com/miniapp/hq_mall/ico2.png",
                title: "精选课程",
                url_type: 0
            }, {
                images: "https://oss-hqwx-edu24ol.oss-cn-beijing.aliyuncs.com/miniapp/hq_mall/ico3.png",
                title: "领劵中心",
                url_type: 0
            }, {
                images: "https://oss-hqwx-edu24ol.oss-cn-beijing.aliyuncs.com/miniapp/hq_mall/ico4.png",
                title: "图书商城",
                url_type: 0
            }, {
                images: "https://oss-hqwx-edu24ol.hqwx.com/miniapp/hq_mall/ico5.png",
                title: "领取资料",
                url_type: 0
            } ], u = {
                data: function() {
                    return {
                        token: "",
                        web_id: "",
                        categoryInfo: {},
                        onCategoryInfo: {},
                        isIPhoneX: !1,
                        isIos: 1,
                        swiperStyle: "",
                        navData: [],
                        tabScrollIntoView: "tab-0",
                        contentCurrent: -1,
                        discountCurrent: 0,
                        liveData: "",
                        liveCourseData: "",
                        channelIconData: [],
                        channelIconCount: 5,
                        limitCourseDataEmpty: !0,
                        limitCourseData: "",
                        limitCourseCount: {},
                        limitCourseTimer: null,
                        discountData: [],
                        groupData: [],
                        isGettingGoodsData: !1,
                        isGoodsDataOver: !1,
                        adListData: [],
                        goodsGroupListData: [],
                        recommendedGoodsData: [],
                        from: 1,
                        rows: 10,
                        isShowAppCouponWin: !1,
                        isShowVerify: !1,
                        abletoSendCode: !0,
                        interval: 60,
                        verifyMsg: "重新获取",
                        missingPhone: "",
                        winContactPopupData: "",
                        isShare: !1,
                        isShowGift: !1,
                        isShowGiftBanner: !1,
                        isShowGiftIcon: !1,
                        isShowWinContactPopup: !1,
                        isShowExperienceDialog: !1,
                        experienceList: [],
                        isExperienceLoaded: !1,
                        isTotalPriceLessThanThousand: !1,
                        homePrompt: !1
                    };
                },
                components: {
                    CMallCard: function() {
                        Promise.all([ n.e("common/vendor"), n.e("components/c-mall-card/c-mall-card") ]).then(function() {
                            return resolve(n(315));
                        }.bind(null, n)).catch(n.oe);
                    },
                    CPopup: function() {
                        n.e("components/c-popup/c-popup").then(function() {
                            return resolve(n(339));
                        }.bind(null, n)).catch(n.oe);
                    },
                    CBargainCard: function() {
                        n.e("components/c-bargain-card/c-bargain-card").then(function() {
                            return resolve(n(294));
                        }.bind(null, n)).catch(n.oe);
                    }
                },
                onLoad: function(e) {
                    var n = this;
                    if (e = (0, s.customDecode)(e), (0, s.setUrlParams)(e), this.token = t.getStorageSync("hq_token") || "", 
                    e.web_id && ((0, s.setWebIdToStorage)(e.web_id), this.web_id = e.web_id), 1 == e.isShare && (this.isShare = !0), 
                    e.wxEduCd && t.setStorageSync("wxEduCd", e.wxEduCd), !this.checkAppCoupon(e) && !this.checkIndexScene(e)) {
                        if (this.isIPhoneX = (0, s.fixIphoneX)(), this.checkOS(), this.checkSwiperStyle(), 
                        (0, s.getSceneParam)(e.scene, "g")) {
                            var a = (0, s.getSceneParam)(e.scene, "g"), o = {
                                gid: a,
                                gname: (0, s.getGName)(a)
                            };
                            return this.onCategoryInfo = o, void this.initPageData();
                        }
                        if (e.gid) {
                            var i = {
                                gid: e.gid,
                                gname: decodeURIComponent(e.gname)
                            };
                            this.onCategoryInfo = i, this.initPageData();
                        } else if (t.getStorageSync("onCategoryInfo")) {
                            var r = t.getStorageSync("onCategoryInfo"), c = {
                                gid: r.gid,
                                gname: decodeURIComponent(r.gname)
                            };
                            this.onCategoryInfo = c, this.initPageData();
                        } else this.checkCategoryInfo(function() {
                            n.initPageData();
                        });
                    }
                },
                onShow: function() {
                    t.getStorageSync("hq_token") && !t.getStorageSync("homePrompt") && this.gethomePrompt();
                },
                onHide: function() {
                    t.hideLoading();
                },
                onUnload: function() {
                    t.hideLoading();
                },
                methods: {
                    checkOS: function() {
                        var e = this;
                        t.getSystemInfo({
                            success: function(t) {
                                t.system.indexOf("Android") > -1 && (e.isIos = 0);
                            }
                        });
                    },
                    gethomePrompt: function() {
                        var t = this;
                        this.$hq.get("".concat(o.default.hostJAPI, "/member/homePrompt"), {
                            edu24ol_token: !0,
                            passport: !0
                        }).then(function(e) {
                            if (0 == e.data.status.code) {
                                wx.setStorageSync("homePrompt", 1);
                                var n = e.data.data;
                                n.memberInfo.userLevel.privilegeList.forEach(function(t, e) {
                                    "sales_buy_course" == t.type && (n.memberInfo.salesBuyCourse = t), "multiple_get_credit" == t.type && (n.memberInfo.multipleGetCredit = t);
                                }), t.homePrompt = n;
                            }
                        });
                    },
                    goMember: function() {
                        this.homePrompt = "", t.navigateTo({
                            url: "/packageMember/pages/member/member"
                        });
                    },
                    closeMember: function() {
                        this.homePrompt = "";
                    },
                    checkSwiperStyle: function() {
                        this.isIPhoneX ? this.swiperStyle = "height: calc(100vh - 94rpx - 98rpx - 70rpx)" : this.swiperStyle = "";
                    },
                    scanCode: function() {
                        t.scanCode({
                            success: function(e) {
                                console.log("scanCode", e), t.navigateTo({
                                    url: "/" + e.path
                                });
                            }
                        });
                    },
                    getUserInfoData: function(t) {},
                    checkCategoryInfo: function(e) {
                        if (t.getStorageSync("categoryInfo") && t.getStorageSync("categoryInfo").gid && t.getStorageSync("categoryInfo").gname) {
                            var n = t.getStorageSync("categoryInfo");
                            this.categoryInfo = n, this.onCategoryInfo = n, this.contentCurrent = 0, "function" == typeof e && e();
                        } else {
                            t.redirectTo({
                                url: "/pages/exam/exam?step=1&sourcePath=/pages/index/index"
                            });
                        }
                    },
                    getListsWithUserRelated: function() {
                        var e = this, n = t.getStorageSync("categoryInfo").gid, a = t.getStorageSync("favorateData") || [], o = [];
                        a.length > 0 && a.forEach(function(t, e) {
                            o.push(t.gid);
                        });
                        var s = {
                            edu24ol_token: this.token,
                            intention: n,
                            interested: o.join(",")
                        };
                        (0, i.getListsWithUserRelated)(s, function(t) {
                            if (0 == t.data.status.code) {
                                var n = t.data.data, a = [], o = 0;
                                (a = a.concat(n.intentionSortIdList, n.interestedSortIdList, n.hot, n.intentionRelatedGroup, n.interestedRelatedGroup, n.other)).length > 16 && (a = a.slice(0, 16)), 
                                e.onCategoryInfo && a.forEach(function(t, n) {
                                    t.categoryId == e.onCategoryInfo.gid && (e.contentCurrent = n, e.tabScrollIntoView = "tab-".concat(n), 
                                    o = 1);
                                }), 0 == o && (a.push({
                                    categoryName: e.onCategoryInfo.gname,
                                    categoryId: e.onCategoryInfo.gid
                                }), e.contentCurrent = a.length - 1, e.tabScrollIntoView = "tab-".concat(a.length - 1)), 
                                e.navData = a, e.getPageData();
                            }
                        });
                    },
                    initPageData: function() {
                        t.showLoading({
                            mask: !0
                        }), this.getListsWithUserRelated(), t.getStorageSync("indexData_groupData") && (this.groupData = t.getStorageSync("indexData_groupData")), 
                        this.getActivityGroupByUserRelatedCategory(), t.getStorageSync("indexData_discountData") && (this.discountData = t.getStorageSync("indexData_discountData")), 
                        this.getSalesList(), this.checkGiftBanner(), this.reportEvent();
                    },
                    getPageData: function() {
                        t.showLoading({
                            mask: !0
                        }), clearInterval(this.limitCourseTimer), this.limitCourseCount = {}, this.limitCourseData = "", 
                        this.limitCourseDataEmpty = !0, this.getStorage("limitCourseData") && (this.limitCourseData = this.getStorage("limitCourseData")), 
                        this.getLimitedTimeCourse(), this.getSalesList(), this.getLiveClass(), this.channelIconCount = 5, 
                        this.channelIconData = this.$hq.copy(d), console.log(222, this.channelIconData), 
                        this.getChannelIcon(), this.isGoodsDataOver = !1, this.isGettingGoodsData = !1, 
                        this.from = 1, this.adListData = [], this.goodsGroupListData = [], this.recommendedGoodsData = [], 
                        this.getStorage("recommendedGoods"), this.getRecommendedGoodsGroupList(), this.getExperienceList();
                    },
                    checkGiftBanner: function() {
                        this.token ? this.canDraw() : (this.isShowGift = !0, t.getStorageSync("isCloseGiftBanner") ? this.isShowGiftIcon = !0 : this.isShowGiftBanner = !0);
                    },
                    canDraw: function() {
                        var e = this, n = {
                            edu24ol_token: this.token
                        };
                        (0, i.canDraw)(n, function(n) {
                            0 == n.data.status.code && (e.isShowGift = !0, t.getStorageSync("isCloseGiftBanner") ? e.isShowGiftIcon = !0 : e.isShowGiftBanner = !0);
                        });
                    },
                    getRecommendedGoodsGroupList: function() {
                        var e = this;
                        if (!this.isGettingGoodsData && (this.isGettingGoodsData = !0, !this.isGoodsDataOver)) {
                            var n = {
                                from: (this.from - 1) * this.rows,
                                rows: this.rows,
                                second_category: this.onCategoryInfo.gid,
                                withAd: 1
                            };
                            (0, i.getRecommendedGoodsGroupList)(n, function(n) {
                                if (0 == n.data.status.code) {
                                    var a = n.data.data, o = Object.assign([], a.goodsGroupList), i = Object.assign([], a.adList), s = [];
                                    if (a.goodsGroupList && 0 != a.goodsGroupList.length || (e.isGoodsDataOver = !0), 
                                    0 == a.adList.length && 0 == a.goodsGroupList.length) return void (e.isGettingGoodsData = !1);
                                    if (o.length > 0 && i.length > 0) {
                                        var r = i.length;
                                        s = e.$hq.copy(o);
                                        for (var c = 0; c < r; c++) i[c].type = "ad", s.splice(5 * c, 0, i[c]);
                                    } else if (o.length > 0 && 0 == i.length) s = o; else if (0 == o.length && i.length > 0) {
                                        for (var d = 0; d < i.length; d++) i[d].type = "ad";
                                        s = i;
                                    }
                                    if (e.isGettingGoodsData = !1, e.goodsGroupListData = o, e.adListData = i, t.getStorageSync("hq_token")) {
                                        var u = [];
                                        o.forEach(function(t, e) {
                                            u.push(t.id);
                                        }), e.ids = u, e.tempRecommendedGoodsData = s, e.getRecommentCommonCourseByIds();
                                    } else e.recommendedGoodsData = s;
                                    e.setStorage({
                                        recommendedGoods: s
                                    });
                                }
                            });
                        }
                    },
                    getRecommentCommonCourseByIds: function() {
                        var t = this, e = this.ids.join(",");
                        this.getCommonCourseByIds(e).then(function(e) {
                            if (0 == e.data.status.code) {
                                var n = e.data.data, a = t.tempRecommendedGoodsData;
                                a.forEach(function(t, e) {
                                    n.forEach(function(e, n) {
                                        t.id == e.id && (t.memberDiscount = e.memberDiscount, t.maxMemberPrice = e.maxMemberPrice, 
                                        t.minMemberPrice = e.minMemberPrice);
                                    });
                                }), t.recommendedGoodsData = a;
                            } else t.recommendedGoodsData = tempRecommendedGoodsData;
                        });
                    },
                    getLimitCourseByIds: function() {
                        var t = this, e = this.limitCourseId, n = this.tempLimitCourseData;
                        this.getCommonCourseByIds(e).then(function(e) {
                            (t.limitCourseData = n, t.limitCourseDataEmpty = !1, t.setStorage({
                                limitCourseData: n
                            }), 0 == e.data.status.code) && (e.data.data.forEach(function(t, e) {
                                n.id == t.id && (n.memberDiscount = t.memberDiscount, n.maxMemberPrice = t.maxMemberPrice, 
                                n.minMemberPrice = t.minMemberPrice, t.minMemberPrice <= t.minSalePrice && (n.isShowMemberPrice = 1));
                            }), t.limitCourseData = n, t.limitCourseDataEmpty = !1, t.setStorage({
                                limitCourseData: n
                            }));
                        });
                    },
                    getCommonCourseByIds: function(t) {
                        var e = this, n = {
                            ids: t,
                            passport: !0,
                            edu24ol_token: !0
                        };
                        return new Promise(function(t, a) {
                            e.$hq.get("".concat(o.default.hostJAPI, "/course/getCommonCourseByIds"), n).then(function(e) {
                                t(e);
                            });
                        });
                    },
                    getMoreRecommendedGoodsGroupList: function() {
                        this.from++, this.getRecommendedGoodsGroupList();
                    },
                    closeGiftBanner: function() {
                        this.isShowGiftIcon = !0, this.isShowGiftBanner = !1, t.setStorageSync("isCloseGiftBanner", 1);
                    },
                    goGiftBanner: function(e) {
                        t.navigateTo({
                            url: "/pages/studentGift/studentGift"
                        });
                    },
                    reportEvent: function() {
                        this.categoryInfo.gid && (0, s.reportEvent)(r, "MPViewScreenExID", {
                            $url_path: "pages/index/index",
                            examinationID: this.categoryInfo.gid + ""
                        });
                    },
                    checkIndexScene: function(e) {
                        if (e.scene) {
                            var n = encodeURIComponent("&&scene=" + e.scene), a = "/pages/index/index?source=index".concat(n);
                            return t.redirectTo({
                                url: "/pages/exam/exam?sourcePath=" + encodeURIComponent(a)
                            }), !0;
                        }
                        return !1;
                    },
                    checkAppCoupon: function(t) {
                        var e = this;
                        return !!/^vfr/.test(t.scene) && (this.token ? this.showModal("抱歉，您不是新用户无法领取优惠，请打开“环球网校”app邀请新用户即可领取优惠券！", function() {
                            e.checkCategoryInfo();
                        }) : (this.scene = t.scene, this.checkWxMobRegister(this.scene)), !0);
                    },
                    getChannelIcon: function() {
                        var t = this, e = {
                            second_category: this.onCategoryInfo.gid
                        };
                        (0, i.channelIcon)(e, function(e) {
                            if (0 == e.data.status.code) if (e.data.data && e.data.data.length > 0) {
                                var n = e.data.data, a = n.length, o = t.channelIconData;
                                n && n.length > 0 && n.forEach(function(t, e) {
                                    o[5 - a] = t, a--;
                                }), t.channelIconCount = 5, t.channelIconData = o;
                            } else t.showQr();
                        });
                    },
                    getLimitedTimeCourse: function() {
                        var e = this, n = {
                            second_category: this.onCategoryInfo.gid
                        };
                        (0, i.getLimitedTimeCourse)(n, function(n) {
                            if (t.hideLoading(), 0 == n.data.status.code) if (n.data.data) {
                                if (n.data.data.activityEndTime ? e.limitCourseTimer = setInterval(function() {
                                    e.limitCourseCount = (0, s.countTime)(n.data.data.activity_end_time || n.data.data.activityEndTime);
                                }, 1e3) : e.limitCourseCount = {
                                    days: "0",
                                    hours: "00",
                                    minutes: "00",
                                    seconds: "00"
                                }, !n.data.data.banner_title) {
                                    n.data.data.sellPoint.length > 0 ? n.data.data.banner_title = n.data.data.sellPoint : n.data.data.banner_title = [ n.data.data.name.slice(0, 11) ], 
                                    "string" == typeof n.data.data.banner_title && (n.data.data.banner_title = n.data.data.banner_title.split(" "));
                                }
                                n.data.data.bigPic || n.data.data.teacher_banner || (n.data.data.defalut_banner = "https://oss-hqwx-edu24ol.hqwx.com/miniapp/hq_mall/banner_discount_1.png");
                                var a = n.data.data;
                                a.minSalePrice = parseInt(a.minSalePrice), a.minPrice = parseInt(a.minPrice), t.getStorageSync("hq_token") ? (e.limitCourseId = a.id, 
                                e.tempLimitCourseData = a, e.getLimitCourseByIds()) : (e.limitCourseData = a, e.limitCourseDataEmpty = !1, 
                                e.setStorage({
                                    limitCourseData: n.data.data
                                }));
                            } else e.limitCourseData = "", e.limitCourseDataEmpty = !0;
                        });
                    },
                    getSalesList: function() {
                        var e = this, n = {
                            second_category: this.onCategoryInfo.gid
                        };
                        (0, i.getFirstOrderDiscountedGoodsGroupList)(n, function(n) {
                            0 == n.data.status.code && (n.data.data && n.data.data.length > 0 && (n.data.data.forEach(function(t, e) {
                                if (t.banner_title || (t.sellPoint.length > 0 ? t.banner_title = sellPoint : t.banner_title = [ t.name.slice(0, 11) ]), 
                                "string" == typeof t.banner_title && (t.banner_title = t.banner_title.split(" ")), 
                                !t.bigPic && !t.teacher_banner) {
                                    var n = e % 10;
                                    t.defalut_banner = "https://oss-hqwx-edu24ol.hqwx.com/miniapp/hq_mall/banner_default_".concat(n, ".png");
                                }
                                t.minPrice = parseInt(t.minPrice), t.minSalePrice = parseInt(t.minSalePrice), t.maxPrice = parseInt(t.maxPrice), 
                                t.maxSalePrice = parseInt(t.maxSalePrice);
                            }), e.discountData = n.data.data, t.setStorageSync("indexData_discountData", n.data.data)));
                        });
                    },
                    getActivityGroupByUserRelatedCategory: function() {
                        var e = this;
                        (0, i.getActivityGroupByUserRelatedCategory)({}, function(n) {
                            if (0 == n.data.status.code) {
                                var a = n.data.data;
                                a.forEach(function(t, e) {
                                    if (t.sellPoint.length > 0 ? t.banner_title = t.sellPoint : t.banner_title = [ t.name.slice(0, 11) ], 
                                    "string" == typeof t.banner_title && (t.banner_title = t.banner_title.split(" ")), 
                                    !t.bigPic && !t.teacher_banner) {
                                        var n = e % 10;
                                        t.defalut_banner = "https://oss-hqwx-edu24ol.hqwx.com/miniapp/hq_mall/banner_default_".concat(n, ".png");
                                    }
                                    t.pintuanPrice = parseInt(t.pintuanPrice);
                                }), e.groupData = a, t.setStorageSync("indexData_groupData", n.data.data);
                            }
                        });
                    },
                    getLiveClass: function() {
                        var t = this, e = {
                            limit: 1,
                            examId: this.onCategoryInfo.gid,
                            passportCors: this.token
                        };
                        (0, i.liveClass)(e, function(e) {
                            if (0 == e.data.status && e.data.data.length > 0) {
                                var n = e.data.data[0];
                                n.formatDate = t.fnTime(1e3 * n.startTime), t.liveCourseData = n, c.getInstance().axiosData(n.roomId).then(function(e) {
                                    t.liveData = e;
                                });
                            }
                        });
                    },
                    fnTime: function(t) {
                        var e = new Date(t), n = "".concat(e.getFullYear(), "/").concat(e.getMonth() + 1, "/").concat(e.getDate()), a = new Date(n).getTime(), o = new Date(), i = "".concat(o.getFullYear(), "/").concat(o.getMonth() + 1, "/").concat(o.getDate()), s = new Date(i).getTime();
                        return console.log(999, "pttTime", a), console.log(999, "todayTime", s), s == a ? "今天 ".concat(this.$hq.timeFormat(t, "hh:MM")) : a - s == 864e5 ? "明天 ".concat(this.$hq.timeFormat(t, "hh:MM")) : this.$hq.timeFormat(t, "mm-dd hh:MM");
                    },
                    showQr: function() {
                        var t = this, e = {
                            passport: wx.getStorageSync("hq_token") || "",
                            resource: 4,
                            resourceIds: 13,
                            ruleType: 2,
                            terminalPage: 13,
                            terminalType: 4,
                            secondCategory: this.onCategoryInfo.gid || 0
                        };
                        this.$hq.get("".concat(o.default.httpHost, "japi.hqwx.com/crm/showQrEntrance"), e).then(function(e) {
                            if (0 == e.data.status.code) if (!e.data.data || 1 != e.data.data.showFlag && 2 != e.data.data.showFlag) t.channelIconCount = 4, 
                            t.channelIconData = t.channelIconData.slice(0, 4); else {
                                var n = e.data.data.microMarketingWechat;
                                t.winContactPopupData = n, t.channelIconData = t.$hq.copy(d);
                            } else t.channelIconCount = 4, t.channelIconData = t.channelIconData.slice(0, 4);
                        });
                    },
                    getQr: function() {
                        var e = this, n = {
                            passport: wx.getStorageSync("hq_token") || "",
                            resource: 4,
                            resourceIds: 13,
                            ruleType: 2,
                            terminalPage: 13,
                            terminalType: 4,
                            secondCategory: this.onCategoryInfo.gid || 0
                        };
                        this.$hq.get("".concat(o.default.httpHost, "japi.hqwx.com/crm/getWechatQr"), n).then(function(n) {
                            if (0 == n.data.status.code) {
                                var a = n.data.data;
                                if (console.log(999, 222, a), 1 == a.isLiveCode || !a.wechatFrom && 2 == a.wechatType || !a.wechatFrom && 3 == a.wechatType) a.path = "/pages/index/index?gid=".concat(e.onCategoryInfo.gid, "&sendImage=1&imageUrl=").concat(a.wechatQrcode), 
                                e.isShowWinContactPopup = !0, e.winContactPopupData = a, console.log(999, 111, e.winContactPopupData.path); else {
                                    t.setStorageSync("wxQrcodeInfo", a);
                                    t.navigateTo({
                                        url: "/pages/addCode/addCode?storage=1&terminalPage=13"
                                    });
                                }
                            }
                        });
                    },
                    bindCourseAssist: function() {
                        var t = this, e = {
                            secondCategory: this.onCategoryInfo.gid,
                            module: "webchatkc_sy"
                        };
                        this.channelIconCount = 5, this.channelIconData = this.$hq.copy(d).slice(0, 4), 
                        (0, i.bindCourseAssist)(e, function(e) {
                            if (0 == e.data.status.code) {
                                var n = e.data.data.assistTeacherVo, a = getCurrentPages()[getCurrentPages().length - 1], o = [];
                                for (var i in a.options) o.push(i + "=" + a.options[i]);
                                n.path = "".concat(a.route, "?").concat(o.join("&")).concat(0 == o.length ? "" : "&", "sendCourseTeacher=1&teacherId=").concat(n.id), 
                                t.winContactPopupData = n, t.channelIconData = t.$hq.copy(d);
                            } else t.channelIconCount = 4, t.channelIconData = t.channelIconData.slice(0, 4);
                        });
                    },
                    checkWxMobRegister: function(e) {
                        var n = "?" + decodeURIComponent(e);
                        if (console.log(999, "_scene", n), decodeURIComponent(e).indexOf("s=") > -1 && decodeURIComponent(e).indexOf("u=") > -1) this.s = (0, 
                        s.queryString)(n, "s"), this.u = (0, s.queryString)(n, "u"), this.c = (0, s.queryString)(n, "c"), 
                        t.setStorageSync("vfr", {
                            s: this.s,
                            u: this.u,
                            c: this.c
                        }); else {
                            var a = decodeURIComponent(e).split("&");
                            console.log(999, 222, a), this.s = a[1], this.u = a[2], (0, s.setWebIdToStorage)(a[3]), 
                            t.setStorageSync("vfr", {
                                s: this.s,
                                u: this.u,
                                c: this.c
                            });
                        }
                        this.token || (this.isShowAppCouponWin = !0);
                    },
                    getPhoneNumberCB: function(e) {
                        var n = this;
                        if (!e.detail.iv) return t.showToast({
                            title: "您已经取消登录~",
                            icon: "none"
                        }), void (this.isShowAppCouponWin = !1);
                        t.showLoading();
                        var a = {
                            modEncryptedData: e.detail.encryptedData,
                            modIv: e.detail.iv,
                            sortId: t.getStorageSync("categoryInfo").gid || "",
                            chId: this.web_id || "",
                            u: this.u,
                            c: this.c,
                            s: this.s
                        };
                        (0, i.wxMobRegister)(a, function(e) {
                            switch (t.hideLoading(), parseInt(e.data.status.code)) {
                              case 10001:
                                (0, s.userBindReport)(r, e.data.data.uid), n.creatUserInfo(e.data.data), n.isShowAppCouponWin = !1, 
                                n.showModal("抱歉，您不是新用户无法领取优惠，请打开“环球网校”app邀请新用户即可领取优惠券！", function() {
                                    n.checkCategoryInfo();
                                });
                                break;

                              case 10002:
                                n.phone = e.data.data.phone, n.getSMSCode();
                                break;

                              case 10004:
                                n.isShowAppCouponWin = !1, (0, s.userBindReport)(r, e.data.data.uid), n.creatUserInfo(e.data.data, function() {
                                    n.showModal("恭喜您，获得“" + (e.data.data.coupon_name || "") + "块钱优惠券”！请前往应用市场下载“环球网校”APP使用。", function() {
                                        n.checkCategoryInfo();
                                    });
                                });
                                break;

                              case 10005:
                                n.isShowAppCouponWin = !1, n.showModal("您来晚了一步，优惠被领完了～", function() {
                                    n.checkCategoryInfo();
                                });
                                break;

                              default:
                                n.isShowAppCouponWin = !1, n.showModal(e.data.status.msg, function() {
                                    n.checkCategoryInfo();
                                });
                            }
                        });
                    },
                    getSMSCode: function() {
                        var e = this, n = this.phone.substr(0, 3) + "****" + this.phone.substr(-4);
                        this.missingPhone = n, this.abletoSendCode && (t.showLoading({
                            title: "验证码获取中..."
                        }), (0, s.reportEvent)(r, "getSMSCode", {
                            serviceType: "短信登录"
                        }), (0, i.getSMSCode)({
                            phone: this.phone,
                            optStr: "login"
                        }, function(n) {
                            0 == n.data.status.code ? (t.hideLoading(), t.showToast({
                                title: "验证码已发送",
                                icon: "none"
                            }), e.isShowVerify = !0, e.isShowAppCouponWin = !1, e.countDown()) : (t.hideLoading(), 
                            t.showToas({
                                title: "res.data.status.msg",
                                icon: "none"
                            }), e.isShowAppCouponWin = !1);
                        }));
                    },
                    autoNext: function(t) {
                        this.smsCode = t.detail.value, this.smsCode.length > 5 && this.submitLogin();
                    },
                    submitLogin: function() {
                        var e = this;
                        t.showLoading(), (0, i.login)({
                            isBind: 1,
                            name: this.phone,
                            password: "",
                            smsCode: this.smsCode
                        }, function(n) {
                            0 == n.data.status.code && (t.hideLoading(), e.isShowVerify = !1, e.showModal("抱歉，您不是新用户无法领取优惠，请打开“环球网校”app邀请新用户即可领取优惠券！", function() {
                                e.checkCategoryInfo();
                            }));
                        });
                    },
                    countDown: function() {
                        var t = this, e = setInterval(function() {
                            t.interval--, t.abletoSendCode = !1, t.verifyMsg = "(".concat(t.interval, "s)重新获取"), 
                            0 == t.interval && (clearInterval(e), t.abletoSendCode = !0, t.interval = 60, t.abletoSendCode = !0, 
                            t.verifyMsg = "重新获取");
                        }, 1e3);
                    },
                    creatUserInfo: function(e, n) {
                        t.setStorage({
                            key: "hqUserInfo",
                            data: e
                        }), t.setStorage({
                            key: "hq_token",
                            data: e.token,
                            success: function() {
                                "function" == typeof n && n();
                            }
                        });
                    },
                    setStorage: function(e) {
                        var n = "indexData_".concat(this.onCategoryInfo.gid), a = t.getStorageSync(n);
                        a = Object.assign({}, a, e), t.setStorageSync(n, a);
                    },
                    getStorage: function(e) {
                        var n = "indexData_".concat(this.onCategoryInfo.gid), a = t.getStorageSync(n);
                        return a && a[e] ? a[e] : [];
                    },
                    changeTab: function(e) {
                        var n = e.currentTarget.dataset;
                        this.contentCurrent = n.index, this.onCategoryInfo = {
                            gid: n.gid,
                            gname: n.gname
                        }, t.setStorageSync("onCategoryInfo", {
                            gid: this.onCategoryInfo.gid,
                            gname: this.onCategoryInfo.gname
                        }), this.getPageData();
                    },
                    swiperContentChange: function(e) {
                        var n = e.detail.current;
                        this.navData;
                        this.contentCurrent = n, t.setStorageSync("onCategoryInfo", {
                            gid: this.onCategoryInfo.gid,
                            gname: this.onCategoryInfo.gname
                        }), this.getPageData();
                    },
                    swiperDiscountChange: function(t) {
                        var e = t.detail.current;
                        this.discountCurrent = e;
                    },
                    goDraw: function() {
                        var e = this.categoryInfo, n = "pages/index/index?gid=".concat(e.gid, "&gname=").concat(e.gname, "&web_id=").concat(this.web_id);
                        t.navigateToMiniProgram({
                            appId: "wxa6a53322a38ff9a9",
                            path: n
                        });
                    },
                    goExam: function() {
                        t.setStorageSync("noChangeCategoryInfo", 1), t.redirectTo({
                            url: "/pages/examIntention/examIntention?sourcePath=/pages/index/index"
                        });
                    },
                    goNav: function(e) {
                        var n = e.currentTarget.dataset, a = this.onCategoryInfo;
                        if (console.log(999, "goNav", n.index), 4 == n.index) this.getQr(); else if (3 == n.index) t.navigateToMiniProgram({
                            appId: "wxa6a53322a38ff9a9",
                            path: "pages/index/index?gid=".concat(a.gid, "&gname=").concat(a.gname, "&web_id=").concat(this.web_id)
                        }); else {
                            var o = "";
                            switch (n.index) {
                              case 0:
                                o = "/pages/examGuide/examGuide?gid=".concat(a.gid, "&gname=").concat(a.gname);
                                break;

                              case 1:
                                o = "/pages/courseList/courseList?gid=".concat(a.gid, "&gname=").concat(a.gname);
                                break;

                              case 2:
                                o = "/pages/couponCenter/couponCenter?gid=".concat(a.gid);
                            }
                            t.navigateTo({
                                url: o
                            });
                        }
                    },
                    navigateToMiniProgram: function(e) {
                        var n = e.currentTarget.dataset, a = n.appid, o = n.path, i = t.getStorageSync("onCategoryInfo") || t.getStorageSync("categoryInfo"), s = i.gid, r = i.gname, c = t.getStorageSync("webIdInfo").web_id || "";
                        "wxb7340ab1fe9bb3ee" != a ? t.navigateToMiniProgram({
                            appId: a,
                            path: o + "?gid=" + s + "&gname=" + r + "&web_id=" + c,
                            extraData: {
                                gid: s,
                                gname: r,
                                web_id: c
                            },
                            success: function() {
                                console.log(o, s, r, c);
                            }
                        }) : t.navigateTo({
                            url: "/" + o
                        });
                    },
                    navigateExtUrl: function(e) {
                        var n = e.currentTarget.dataset.url;
                        t.navigateTo({
                            url: "/pages/webview/webview?url=" + encodeURIComponent(n)
                        });
                    },
                    goLiveDetail: function(e) {
                        var n = e.currentTarget.dataset;
                        t.navigateToMiniProgram({
                            appId: "wx890b8e807c46f703",
                            path: "pages/liveDetail/liveDetail?id=".concat(n.id, "&livelessonid=").concat(n.livelessonid, "&gid=").concat(n.gid, "&gname=").concat(n.gname, "&web_id=").concat(this.web_id)
                        });
                    },
                    goCourseDetail: function(e) {
                        var n = e.currentTarget.dataset;
                        n.sourcetype && "discount" == n.sourcetype && r.sensors.track("clickDiscount", {
                            belongPage: "商城首页",
                            examinationID: n.data.secondCategory,
                            courseID: n.data.id,
                            courseName: n.data.name
                        }), t.navigateTo({
                            url: "/pages/courseDetail/courseDetail?id=".concat(n.id)
                        });
                    },
                    goGroup: function() {
                        t.navigateTo({
                            url: "/pages/group/group?gid=".concat(this.onCategoryInfo.gid, "&gname=").concat(this.onCategoryInfo.gname)
                        });
                    },
                    goGroupDetail: function(e) {
                        var n = e.currentTarget.dataset;
                        t.navigateTo({
                            url: "/pages/groupDetail/groupDetail?groupId=".concat(n.id)
                        });
                    },
                    goStudent: function() {
                        t.navigateTo({
                            url: "/pages/studentGift/studentGift"
                        });
                    },
                    clickMallCard: function(e) {
                        t.navigateTo({
                            url: "/pages/courseDetail/courseDetail?id=".concat(e.id)
                        });
                    },
                    closeWinContactPopup: function() {
                        this.isShowWinContactPopup = !1;
                    },
                    showModal: function(e, n) {
                        t.showModal({
                            title: "",
                            content: e || "",
                            showCancel: !1,
                            success: function(t) {
                                "function" == typeof n && n();
                            }
                        });
                    },
                    getExperienceList: function() {
                        var e = this, n = t.getStorageSync("hqUserInfo") || {}, a = {
                            secondCategory: this.onCategoryInfo.gid,
                            passport: n.token || ""
                        }, o = {
                            from: 0,
                            rows: 3,
                            secondCategory: this.onCategoryInfo.gid
                        };
                        this.experienceList = [], this.isShowExperienceDialog = !1, n.token ? this.$hq.get("https://japi.hqwx.com/buy/isTotalPriceLessThanThousand", a).then(function(t) {
                            0 == t.data.status.code && (t.data.data.flag ? e.isTotalPriceLessThanThousand = !0 : e.isExperienceLoaded = !0);
                        }) : this.isTotalPriceLessThanThousand = !0, this.$hq.get("https://japi.hqwx.com/uc/study/experienceWithSecondCategory", o).then(function(n) {
                            if (0 == n.data.status.code) {
                                var a = n.data.data || [];
                                if (!t.getStorageSync("launch_experience_popup_loaded")) if (a.length > 0) -1 == (t.getStorageSync("experience_dialog") || []).indexOf(e.onCategoryInfo.gid) && t.setStorageSync("launch_experience_popup_loaded", 1);
                                e.experienceList = a;
                            }
                            e.isExperienceLoaded = !0;
                        });
                    },
                    getLoadNum: function() {}
                },
                onShareAppMessage: function(t) {
                    var e = "/pages/index/index?gid=".concat(this.categoryInfo.gid, "&gname=").concat(this.categoryInfo.gname, "&web_id=").concat(this.web_id);
                    return this.isShare = !1, {
                        title: "环球网校·职业教育考证培训，精品好课，尽在其中",
                        path: e,
                        imageUrl: "https://oss-hqwx-edu24ol.hqwx.com/f1d853594d0adb014964c2bd778da7d77f310b1a.png",
                        success: function(t) {},
                        complete: function() {}
                    };
                }
            };
            e.default = u;
        }).call(this, n(1).default);
    },
    50: function(t, e, n) {
        n.r(e);
        var a = n(51), o = n.n(a);
        for (var i in a) "default" !== i && function(t) {
            n.d(e, t, function() {
                return a[t];
            });
        }(i);
        e.default = o.a;
    },
    51: function(t, e, n) {}
}, [ [ 42, "common/runtime", "common/vendor" ] ] ]);