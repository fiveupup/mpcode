require("../../uni-bootstrap.js"), (global.webpackJsonp = global.webpackJsonp || []).push([ [ "pages/examIntention/examIntention" ], {
    34: function(t, e, a) {
        (function(t) {
            a(4);
            e(a(2));
            function e(t) {
                return t && t.__esModule ? t : {
                    default: t
                };
            }
            t(e(a(35)).default);
        }).call(this, a(1).createPage);
    },
    35: function(t, e, a) {
        a.r(e);
        var n = a(36), i = a(38);
        for (var o in i) "default" !== o && function(t) {
            a.d(e, t, function() {
                return i[t];
            });
        }(o);
        a(40);
        var r = a(10), s = Object(r.default)(i.default, n.render, n.staticRenderFns, !1, null, null, null, !1, n.components, void 0);
        s.options.__file = "pages/examIntention/examIntention.vue", e.default = s.exports;
    },
    36: function(t, e, a) {
        a.r(e);
        var n = a(37);
        a.d(e, "render", function() {
            return n.render;
        }), a.d(e, "staticRenderFns", function() {
            return n.staticRenderFns;
        }), a.d(e, "recyclableRender", function() {
            return n.recyclableRender;
        }), a.d(e, "components", function() {
            return n.components;
        });
    },
    37: function(t, e, a) {
        a.r(e), a.d(e, "render", function() {
            return n;
        }), a.d(e, "staticRenderFns", function() {
            return o;
        }), a.d(e, "recyclableRender", function() {
            return i;
        }), a.d(e, "components", function() {});
        var n = function() {
            var t = this.$createElement;
            this._self._c;
        }, i = !1, o = [];
        n._withStripped = !0;
    },
    38: function(t, e, a) {
        a.r(e);
        var n = a(39), i = a.n(n);
        for (var o in n) "default" !== o && function(t) {
            a.d(e, t, function() {
                return n[t];
            });
        }(o);
        e.default = i.a;
    },
    39: function(t, e, a) {
        (function(t) {
            Object.defineProperty(e, "__esModule", {
                value: !0
            }), e.default = void 0;
            var n = a(21), i = {
                data: function() {
                    return {
                        token: "",
                        categoryInfo: {},
                        selectQueryArray: [],
                        activedIndex: 0,
                        deltaY: 0,
                        scrollIntoView: "scroll-0",
                        favorateData: [],
                        intentionData: [],
                        favorateState: 0,
                        intentionState: 0,
                        addClassState: 0,
                        editType: "",
                        moveStyle: [],
                        firstMoveWidth: 0,
                        secondMoveWidth: 0,
                        moveIndex: -1,
                        startX: 0,
                        startLeft: 0,
                        distanceX: 10,
                        left: 0,
                        groupData: []
                    };
                },
                onLoad: function(e) {
                    this.token = t.getStorageSync("hq_token"), this.getCategoryInfo(), this.initMoveElement(), 
                    this.initGroupCategoryData();
                },
                onShow: function() {},
                methods: {
                    getCategoryInfo: function() {
                        this.categoryInfo = t.getStorageSync("categoryInfo"), this.intentionData = t.getStorageSync("categoryInfo") ? [ t.getStorageSync("categoryInfo") ] : [], 
                        this.favorateData = t.getStorageSync("favorateData") || [], !this.token || 0 != this.intentionData.length && 0 != this.favorateData.length || this.getUserRelatedSortIdInfo();
                    },
                    initGroupCategoryData: function() {
                        t.getStorageSync("groupCategoryData") ? (this.groupData = t.getStorageSync("groupCategoryData"), 
                        this.getGroupCategoryData()) : (t.showLoading({
                            title: "加载中..."
                        }), this.getGroupCategoryData());
                    },
                    getGroupCategoryData: function() {
                        var e = this;
                        (0, n.getGroupCategory)({}, function(a) {
                            if (0 == a.data.status.code) {
                                var n = a.data.data, i = n.groupCategoryList, o = n.normalCategoryList, r = [];
                                i.forEach(function(a, n) {
                                    for (var i in o) if (a.groupId == i) {
                                        var s = o[i];
                                        s.forEach(function(n, i) {
                                            n.groupName = 17 == a.groupId ? "".concat(a.groupName) : "".concat(a.groupName, "-").concat(n.name), 
                                            n.unitList.forEach(function(a, n) {
                                                if (2 == e.step) {
                                                    var i = t.getStorageSync("categoryInfo");
                                                    a.categoryId == i.gid ? (a.state = -1, a.intentionData = 1) : a.state = 0;
                                                } else a.state = 0;
                                            });
                                        }), r.push({
                                            groupName: a.groupName,
                                            groupId: a.groupId,
                                            list: s
                                        });
                                    }
                                }), e.groupData = r, e.selectQuery(), t.setStorageSync("groupCategoryData", r);
                            }
                            t.hideLoading();
                        });
                    },
                    choose: function(e) {
                        var a = e.currentTarget.dataset;
                        this.editType || (t.setStorageSync("onCategoryInfo", {
                            gid: a.gid,
                            gname: a.gname
                        }), t.redirectTo({
                            url: "/pages/index/index?gid=".concat(a.gid, "&gname=").concat(a.gname)
                        }));
                    },
                    edit: function(e) {
                        var a = e.currentTarget.dataset;
                        if ("favorate" == a.type && 0 == this.intentionState) this.favorateState = !a.state, 
                        this.editType = a.type, this.checkAddClass(), this.favorateState || (t.setStorageSync("favorateData", this.favorateData), 
                        this.token && this.userInterested(), this.editType = ""); else if ("intention" == a.type && 0 == this.favorateState) {
                            if (0 == this.intentionData.length) return;
                            this.intentionState = !a.state, this.editType = a.type, this.checkAddClass(), this.intentionState || (this.token && this.categoryInfo.gid && this.categoryInfo.gid != this.intentionData[0].gid && this.updateUserInfo(), 
                            this.categoryInfo = this.intentionData[0], t.setStorageSync("categoryInfo", this.categoryInfo), 
                            this.editType = "");
                        }
                    },
                    add: function(t) {
                        if (1 != this.addClassState) {
                            var e = t.currentTarget.dataset, a = {
                                gname: e.gname,
                                gid: e.gid
                            };
                            0 != e.state && ("favorate" == this.editType ? (this.favorateData.push(a), this.initMoveElement()) : "intention" == this.editType && this.intentionData.push(a), 
                            this.checkAddClass());
                        }
                    },
                    del: function(t) {
                        var e = t.currentTarget.dataset;
                        "favorate" == e.type ? this.favorateData.splice(e.index, 1) : "intention" == e.type && this.intentionData.splice(e.index, 1), 
                        this.checkAddClass();
                    },
                    checkAddClass: function() {
                        var t = "", e = "";
                        "intention" == this.editType ? (t = this.intentionData, e = this.favorateData, this.addClassState = 1 == this.intentionData.length ? 1 : 0) : "favorate" == this.editType && (t = this.favorateData, 
                        e = this.intentionData, this.addClassState = 2 == this.favorateData.length ? 1 : 0);
                        var a = this.groupData;
                        1 == this.addClassState ? (a.forEach(function(e, a) {
                            e.list.forEach(function(e, a) {
                                e.unitList.forEach(function(e) {
                                    e.class = "disabled", t.forEach(function(t) {
                                        t.gid == e.categoryId && (e.class = "added");
                                    });
                                });
                            });
                        }), this.groupData = a) : (a.forEach(function(e) {
                            e.list.forEach(function(e) {
                                e.unitList.forEach(function(e) {
                                    0 == t.length ? e.class = "" : t.forEach(function(t) {
                                        t.gid == e.categoryId ? e.class = "added" : e.class = "";
                                    });
                                });
                            });
                        }), a.forEach(function(t) {
                            t.list.forEach(function(t) {
                                t.unitList.forEach(function(t) {
                                    e.length > 0 && e.forEach(function(e) {
                                        e.gid == t.categoryId && (t.class = "disabled");
                                    });
                                });
                            });
                        }), this.groupData = a);
                    },
                    initMoveElement: function(e) {
                        var a = this;
                        if (!(this.favorateData.length < 2)) var n = setTimeout(function() {
                            t.createSelectorQuery().select("#movable0").fields({
                                size: !0
                            }, function(n) {
                                a.moveStyle[0] = {
                                    style: "left:0"
                                }, a.moveStyle[1] = {
                                    style: "left:".concat(n.width + a.distanceX, "px;")
                                }, a.firstMoveWidth = n.width, t.createSelectorQuery().select("#movable1").fields({
                                    size: !0
                                }, function(t) {
                                    a.secondMoveWidth = t.width, "function" == e && e();
                                }).exec();
                            }).exec(), clearTimeout(n);
                        }, 10);
                    },
                    touchstart: function(e) {
                        var a = this;
                        if (!(0 == e.changedTouches.length || e.changedTouches.length > 1 || this.favorateData.length < 2 || 0 == this.favorateState)) {
                            var n = e.currentTarget.dataset.index;
                            this.startX = e.changedTouches[0].pageX, this.moveIndex = n, t.createSelectorQuery().select("#movable" + n).fields({
                                rect: !0
                            }, function(t) {
                                a.startLeft = t.left;
                            }).exec();
                        }
                    },
                    touchmove: function(t) {
                        var e, a, n = t.currentTarget.dataset.index;
                        this.favorateData.length < 2 || 0 != this.favorateState && (e = t.changedTouches[0].pageX, 
                        a = Math.floor(e - this.startX + this.startLeft), this.left = a, this.moveStyle[n] = {
                            style: "left:".concat(a, "px; background:#CCC;")
                        });
                    },
                    touchend: function(t) {
                        this.favorateData.length < 2 || this.left < 10 || 0 != this.favorateState && (1 == this.moveIndex ? this.left <= this.firstMoveWidth - this.secondMoveWidth ? this.changeFavorateDataPosition() : this.moveStyle[this.moveIndex] = {
                            style: "left:".concat(this.firstMoveWidth + this.distanceX, "px;")
                        } : this.left <= this.firstMoveWidth + this.distanceX ? this.moveStyle[0] = {
                            style: "left:0"
                        } : this.changeFavorateDataPosition(), this.moveIndex = -1, this.left = 0);
                    },
                    changeFavorateDataPosition: function() {
                        var t = this, e = this.favorateData, a = [];
                        a.push(e[1]), a.push(e[0]), this.favorateData = a;
                        var n = setTimeout(function() {
                            t.initMoveElement(), clearTimeout(n);
                        }, 10);
                    },
                    changeExam: function(t) {
                        var e = t.currentTarget.dataset.index;
                        this.scrollIntoView = "scroll-".concat(e + 1), this.activedIndex = e;
                    },
                    selectQuery: function() {
                        for (var e = this, a = this.groupData.length, n = 0; n <= a; n++) t.createSelectorQuery().select("#scroll-" + n).fields({
                            rect: !0
                        }, function(t) {
                            t && "undefined" != t.top && e.selectQueryArray.push(t.top);
                        }).exec();
                    },
                    scroll: function(t) {
                        var e = t.detail.scrollTop, a = Array.from(this.selectQueryArray);
                        if (!(Math.abs(Math.abs(this.deltaY) - Math.abs(t.detail.deltaY)) >= 40)) {
                            this.deltaY = t.detail.deltaY;
                            for (var n = 0; n < a.length; n++) e + a[0] >= a[n] && (this.activedIndex = n);
                        }
                    },
                    getUserRelatedSortIdInfo: function() {
                        var e = this;
                        t.showLoading();
                        var a = {
                            edu24ol_token: this.token
                        };
                        (0, n.getUserRelatedSortIdInfo)(a, function(a) {
                            if (0 == a.data.status.code) {
                                var n = a.data.data;
                                if (0 == e.intentionData.length && n.intentionSortIdList && n.intentionSortIdList.length > 0) {
                                    var i = n.intentionSortIdList[0], o = {
                                        gname: i.name,
                                        gid: i.id
                                    };
                                    e.intentionData = [ o ], t.setStorageSync("categoryInfo", o);
                                }
                                if (0 == e.favorateData.length && n.interestedSortIdList && n.interestedSortIdList.length > 0) {
                                    var r = n.interestedSortIdList, s = [];
                                    r.forEach(function(t) {
                                        s.push({
                                            gname: t.name,
                                            gid: t.id
                                        });
                                    }), e.favorateData = s, t.setStorageSync("favorateData", s), e.initMoveElement();
                                }
                            }
                            t.hideLoading();
                        });
                    },
                    updateUserInfo: function() {
                        var t = {
                            edu24ol_token: this.token,
                            second_category: this.intentionData[0].gid
                        };
                        (0, n.updateUserInfo)(t, function(t) {});
                    },
                    userInterested: function() {
                        t.showLoading();
                        var e = [];
                        this.favorateData.forEach(function(t) {
                            e.push(t.gid);
                        });
                        var a = {
                            edu24ol_token: this.token,
                            second_category_list: e.join(",")
                        };
                        (0, n.userInterested)(a, function(e) {
                            t.hideLoading();
                        });
                    }
                }
            };
            e.default = i;
        }).call(this, a(1).default);
    },
    40: function(t, e, a) {
        a.r(e);
        var n = a(41), i = a.n(n);
        for (var o in n) "default" !== o && function(t) {
            a.d(e, t, function() {
                return n[t];
            });
        }(o);
        e.default = i.a;
    },
    41: function(t, e, a) {}
}, [ [ 34, "common/runtime", "common/vendor" ] ] ]);