require("../../uni-bootstrap.js"), (global.webpackJsonp = global.webpackJsonp || []).push([ [ "pages/group/group" ], {
    108: function(n, t, e) {
        (function(n) {
            e(4);
            t(e(2));
            function t(n) {
                return n && n.__esModule ? n : {
                    default: n
                };
            }
            n(t(e(109)).default);
        }).call(this, e(1).createPage);
    },
    109: function(n, t, e) {
        e.r(t);
        var o = e(110), a = e(112);
        for (var r in a) "default" !== r && function(n) {
            e.d(t, n, function() {
                return a[n];
            });
        }(r);
        e(114);
        var i = e(10), c = Object(i.default)(a.default, o.render, o.staticRenderFns, !1, null, null, null, !1, o.components, void 0);
        c.options.__file = "pages/group/group.vue", t.default = c.exports;
    },
    110: function(n, t, e) {
        e.r(t);
        var o = e(111);
        e.d(t, "render", function() {
            return o.render;
        }), e.d(t, "staticRenderFns", function() {
            return o.staticRenderFns;
        }), e.d(t, "recyclableRender", function() {
            return o.recyclableRender;
        }), e.d(t, "components", function() {
            return o.components;
        });
    },
    111: function(n, t, e) {
        e.r(t), e.d(t, "render", function() {
            return a;
        }), e.d(t, "staticRenderFns", function() {
            return i;
        }), e.d(t, "recyclableRender", function() {
            return r;
        }), e.d(t, "components", function() {
            return o;
        });
        var o = {
            cMallCard: function() {
                return Promise.all([ e.e("common/vendor"), e.e("components/c-mall-card/c-mall-card") ]).then(e.bind(null, 315));
            },
            cAuthorize: function() {
                return e.e("components/c-authorize/c-authorize").then(e.bind(null, 332));
            }
        }, a = function() {
            var n = this.$createElement;
            this._self._c;
        }, r = !1, i = [];
        a._withStripped = !0;
    },
    112: function(n, t, e) {
        e.r(t);
        var o = e(113), a = e.n(o);
        for (var r in o) "default" !== r && function(n) {
            e.d(t, n, function() {
                return o[n];
            });
        }(r);
        t.default = a.a;
    },
    113: function(n, t, e) {
        (function(n) {
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = void 0;
            var o, a = (o = e(20)) && o.__esModule ? o : {
                default: o
            }, r = e(21), i = e(22);
            getApp(), e(24)("./config_" + a.default.appName);
            var c = {
                data: function() {
                    return {
                        token: "",
                        hqUserInfo: "",
                        categoryInfo: {},
                        onCategoryInfo: {},
                        web_id: "",
                        courseData: [],
                        isGettingData: !1,
                        from: 1,
                        rows: 30,
                        isOver: !1
                    };
                },
                onLoad: function(t) {
                    t = (0, i.customDecode)(t), (0, i.setUrlParams)(t), t.gid && (this.onCategoryInfo = {
                        gid: t.gid,
                        gname: t.gname
                    }, n.getStorageSync("categoryInfo") || (this.categoryInfo = {
                        gid: t.gid,
                        gname: t.gname
                    }, n.setStorageSync("categoryInfo", this.categoryInfo))), t.web_id && ((0, i.setWebIdToStorage)(t.web_id), 
                    this.web_id = t.web_id);
                },
                onShow: function() {
                    this.token = n.getStorageSync("hq_token"), this.hqUserInfo = n.getStorageSync("hqUserInfo"), 
                    this.categoryInfo = n.getStorageSync("categoryInfo"), this.web_id = n.getStorageSync("webIdInfo").web_id, 
                    this.getCourseData();
                },
                methods: {
                    getUserInfoData: function(n) {},
                    getCourseData: function() {
                        var t = this;
                        if (!this.isOver && !this.isGettingData) {
                            this.isGettingData = !0;
                            var e = {
                                second_category: "",
                                from: (this.from - 1) * this.rows,
                                rows: this.rows
                            }, o = this.courseData || [];
                            n.showLoading(), (0, r.getGroupActivityCourseList)(e, function(e) {
                                if (0 == e.data.status.code) {
                                    var a, r = e.data.data, i = [], c = [], u = 0, s = "";
                                    r.forEach(function(n, t) {
                                        if (n.sellPoint.length > 0 ? (n.sellPoint.forEach(function(n, t) {
                                            u <= 12 && n.length + u + " " <= 12 && (u += (s += n + " ").length);
                                        }), n.banner_title = s) : n.banner_title = n.name.slice(0, 11), !n.bigPic && !n.teacher_banner) {
                                            var e = t % 10;
                                            n.defalut_banner = "https://oss-hqwx-edu24ol.hqwx.com/miniapp/hq_mall/banner_default_".concat(e, ".png");
                                        }
                                        null != n.pingtuan_info ? i.push(n) : c.push(n);
                                    }), t.isGettingData = !0, a = o.concat(i, c), t.courseData = a, r.length < t.rows && (t.isOver = !0);
                                } else t.isOver = !0, t.isGettingData = !0;
                                n.hideLoading();
                            });
                        }
                    },
                    clickMallCard: function(t) {
                        n.navigateTo({
                            url: "/pages/courseDetail/courseDetail?id=".concat(t.id)
                        });
                    },
                    getLoadNum: function() {}
                },
                onShareAppMessage: function(n) {
                    var t = "/pages/group/group?gid=".concat(this.onCategoryInfo.gid, "&gname=").concat(this.onCategoryInfo.gname, "&web_id=").concat(this.web_id);
                    return console.log(999, 111, t), {
                        title: "拼着买更优惠，#考试名称 精品好课低价秒",
                        path: t,
                        imageUrl: "",
                        success: function(n) {}
                    };
                }
            };
            t.default = c;
        }).call(this, e(1).default);
    },
    114: function(n, t, e) {
        e.r(t);
        var o = e(115), a = e.n(o);
        for (var r in o) "default" !== r && function(n) {
            e.d(t, n, function() {
                return o[n];
            });
        }(r);
        t.default = a.a;
    },
    115: function(n, t, e) {}
}, [ [ 108, "common/runtime", "common/vendor" ] ] ]);