getApp(), require("../../utils/util"), require("../template/template");

var e = require("../../configs/baseConfig");

require("../../configs/config_" + e.appName);

Page({
    data: {},
    onLoad: function(e) {
        e.url && this.setData({
            url: decodeURIComponent(e.url)
        });
    }
});