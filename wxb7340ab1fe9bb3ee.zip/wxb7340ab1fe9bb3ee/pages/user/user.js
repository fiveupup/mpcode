require("../../uni-bootstrap.js"), (global.webpackJsonp = global.webpackJsonp || []).push([ [ "pages/user/user" ], {
    100: function(e, t, a) {
        (function(e) {
            a(4);
            t(a(2));
            function t(e) {
                return e && e.__esModule ? e : {
                    default: e
                };
            }
            e(t(a(101)).default);
        }).call(this, a(1).createPage);
    },
    101: function(e, t, a) {
        a.r(t);
        var n = a(102), o = a(104);
        for (var r in o) "default" !== r && function(e) {
            a.d(t, e, function() {
                return o[e];
            });
        }(r);
        a(106);
        var i = a(10), c = Object(i.default)(o.default, n.render, n.staticRenderFns, !1, null, null, null, !1, n.components, void 0);
        c.options.__file = "pages/user/user.vue", t.default = c.exports;
    },
    102: function(e, t, a) {
        a.r(t);
        var n = a(103);
        a.d(t, "render", function() {
            return n.render;
        }), a.d(t, "staticRenderFns", function() {
            return n.staticRenderFns;
        }), a.d(t, "recyclableRender", function() {
            return n.recyclableRender;
        }), a.d(t, "components", function() {
            return n.components;
        });
    },
    103: function(e, t, a) {
        a.r(t), a.d(t, "render", function() {
            return o;
        }), a.d(t, "staticRenderFns", function() {
            return i;
        }), a.d(t, "recyclableRender", function() {
            return r;
        }), a.d(t, "components", function() {
            return n;
        });
        var n = {
            cCollegeCard: function() {
                return Promise.all([ a.e("common/vendor"), a.e("components/c-college-card/c-college-card") ]).then(a.bind(null, 367));
            },
            cTabBar: function() {
                return a.e("components/c-tabBar/c-tabBar").then(a.bind(null, 325));
            }
        }, o = function() {
            var e = this.$createElement;
            this._self._c;
        }, r = !1, i = [];
        o._withStripped = !0;
    },
    104: function(e, t, a) {
        a.r(t);
        var n = a(105), o = a.n(n);
        for (var r in n) "default" !== r && function(e) {
            a.d(t, e, function() {
                return n[e];
            });
        }(r);
        t.default = o.a;
    },
    105: function(e, t, a) {
        (function(e) {
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = void 0;
            var n, o = (n = a(20)) && n.__esModule ? n : {
                default: n
            }, r = a(22), i = a(21);
            var c = getApp(), s = a(24)("./config_" + o.default.appName).default, d = {
                data: function() {
                    return {
                        token: "",
                        hqUserInfo: "",
                        categoryInfo: {},
                        web_id: "",
                        pathParameter: "",
                        orderData: [],
                        couponData: "",
                        version: "",
                        isIPhoneX: !1,
                        showVersion: !1,
                        qrcodeInfo: {},
                        memberDetail: ""
                    };
                },
                onLoad: function(t) {
                    t.gid && (this.categoryInfo = {
                        gid: t.gid,
                        gname: t.gname
                    }, e.setStorageSync("categoryInfo", this.categoryInfo)), t.web_id && ((0, r.setWebIdToStorage)(t.web_id), 
                    this.web_id = t.web_id), this.isIPhoneX = (0, r.fixIphoneX)(), this.version = s.version, 
                    this.getQrcodeInfo();
                },
                onShow: function() {
                    this.token = e.getStorageSync("hq_token"), this.hqUserInfo = e.getStorageSync("hqUserInfo"), 
                    this.categoryInfo = e.getStorageSync("categoryInfo"), this.web_id = e.getStorageSync("webIdInfo").web_id, 
                    this.pathParameter = "?gid=".concat(this.categoryInfo.gid, "&gname=").concat(this.categoryInfo.gname, "&web_id=").concat(this.web_id), 
                    this.token && this.getUserOrderList(), this.token && this.getUserCouponList(), this.token && this.getMemberDetailByType();
                },
                methods: {
                    goMall: function() {
                        e.navigateTo({
                            url: "/packageMember/pages/member/member"
                        });
                    },
                    getMemberDetailByType: function() {
                        var e = this;
                        this.$hq.get("".concat(o.default.hostJAPI, "/member/getMemberDetailByType"), {
                            accountType: 0,
                            edu24ol_token: !0
                        }).then(function(t) {
                            if (0 == t.data.status.code && t.data.data && t.data.data.userLevel) {
                                var a = t.data.data, n = 0;
                                switch (a.userLevel.type) {
                                  case "level_bronze":
                                    n = 1;
                                    break;

                                  case "level_silver":
                                    n = 2;
                                    break;

                                  case "level_goal":
                                    n = 3;
                                    break;

                                  case "level_platinum":
                                    n = 4;
                                    break;

                                  case "level_diamond":
                                    n = 5;
                                }
                                a.userLevel.grade = n, e.memberDetail = a || "";
                            }
                        });
                    },
                    getUserOrderList: function() {
                        var e = this, t = {
                            edu24ol_token: this.token,
                            terminal_type: o.default.terminalType,
                            terminalType: o.default.terminalType,
                            state: 1
                        };
                        (0, i.userOrderList)(t, function(t) {
                            0 == t.data.status.code && (e.orderData = t.data.data);
                        });
                    },
                    getUserCouponList: function() {
                        var e = this, t = {
                            edu24ol_token: this.token,
                            terminal_type: o.default.terminalType,
                            terminalType: o.default.terminalType,
                            from: 0,
                            rows: 20,
                            state: 1
                        };
                        (0, i.getUserCouponList)(t, function(t) {
                            0 == t.data.status.code && (e.couponData = t.data.data);
                        });
                    },
                    goUnbindAccount: function() {
                        var t = "/pages/unbindAccount/unbindAccount";
                        this.hqUserInfo || (t = "/pages/login/login?sourcePath=/pages/user/user"), e.navigateTo({
                            url: t
                        });
                    },
                    goInfo: function() {
                        var t = "/packageProfile/pages/editInfo/editInfo";
                        this.token || (t = "/pages/login/login?sourcePath=/pages/user/user"), e.navigateTo({
                            url: t
                        });
                    },
                    goMyOrder: function() {
                        var t = "/packageUser/pages/myOrder/myOrder";
                        this.hqUserInfo || (t = "/pages/login/login?sourcePath=/pages/user/user"), e.navigateTo({
                            url: t
                        });
                    },
                    goMyCoupon: function() {
                        var t = "/subpackages/pages/couponList/couponList";
                        this.hqUserInfo || (t = "/pages/login/login?sourcePath=/pages/user/user"), e.navigateTo({
                            url: t
                        });
                    },
                    goMyCourse: function() {
                        var t = "pages/myCourse/myCourse".concat(this.pathParameter);
                        e.navigateToMiniProgram({
                            appId: "wx890b8e807c46f703",
                            path: t
                        });
                    },
                    goTiku: function() {
                        var t = "pages/index/index".concat(this.pathParameter);
                        e.navigateToMiniProgram({
                            appId: "wxae3a9748da999008",
                            path: t
                        });
                    },
                    goMyDocument: function() {
                        var t = "pages/myActivityDoc/myActivityDoc".concat(this.pathParameter);
                        e.navigateToMiniProgram({
                            appId: "wx890b8e807c46f703",
                            path: t
                        });
                    },
                    goBook: function() {
                        var t = "pages/index/index".concat(this.pathParameter);
                        e.navigateToMiniProgram({
                            appId: "wxa6a53322a38ff9a9",
                            path: t
                        });
                    },
                    goBaokao: function() {
                        var t = "pages/searchTest/searchTest".concat(this.pathParameter);
                        e.navigateToMiniProgram({
                            appId: "wxe691176daf37984f",
                            path: t
                        });
                    },
                    goCalendar: function() {
                        var t = "pages/calendarTime/calendarTime".concat(this.pathParameter);
                        e.navigateToMiniProgram({
                            appId: "wxe691176daf37984f",
                            path: t
                        });
                    },
                    goIndex: function() {
                        e.redirectTo({
                            url: "/pages/index/index?isShare=1"
                        });
                    },
                    goAddress: function() {
                        var t = "/packageAddress/pages/addressList/addressList";
                        e.navigateTo({
                            url: this.token ? t : "/pages/login/login?sourcePath=" + t
                        });
                    },
                    goFeedback: function() {
                        e.navigateToMiniProgram({
                            appId: "wx8abaf00ee8c3202e",
                            path: "",
                            extraData: {
                                id: 47814
                            }
                        });
                    },
                    goKefu: function() {
                        var t = "?groupid=" + s.afterSalesGroupid + "&title=" + encodeURIComponent("个人中心") + "&secondCategory=" + this.categoryInfo.gid || !1;
                        e.navigateTo({
                            url: "/pages/service/service".concat(t)
                        }), (0, r.reportEvent)(c, "MpClick", {
                            belongPage: this.route,
                            clickElement: "客服",
                            nextPage: "pages/service/service"
                        });
                    },
                    getLoadNum: function() {},
                    getQrcodeInfo: function() {
                        var t = this, a = {
                            objId: e.getStorageSync("categoryInfo").gid,
                            type: 3,
                            module: "webchatkc_grzx",
                            terminal: "terminalwebchatkc"
                        };
                        this.$hq.get("https://adminapi.hqwx.com/operation-growth-siteapp/app/v1/wxgzh/drainage/qrcode-info", a).then(function(e) {
                            0 == e.data.code && e.data.data && (t.qrcodeInfo = e.data.data);
                        });
                    },
                    followHandle: function() {
                        var t = e.getStorageSync("categoryInfo");
                        (0, r.reportEvent)(c, "addTeacher", {
                            belongPage: "个人中心",
                            QRCodeType: this.qrcodeInfo.codeType,
                            addTeacherPath: 1 == this.qrcodeInfo.addTeacherPathType ? "公众号文章" : "客服消息",
                            examinationName: t.gname || "",
                            teacherID: this.qrcodeInfo.id,
                            teacherName: this.qrcodeInfo.name
                        });
                        var a = "/pages/customerService/customerService?imageUrl=" + this.qrcodeInfo.webchatQrcodeUrl;
                        1 == this.qrcodeInfo.addTeacherPathType && (a = "/pages/webview/webview?url=" + encodeURIComponent(this.qrcodeInfo.addTeacherPathUrl)), 
                        e.navigateTo({
                            url: a
                        });
                    }
                }
            };
            t.default = d;
        }).call(this, a(1).default);
    },
    106: function(e, t, a) {
        a.r(t);
        var n = a(107), o = a.n(n);
        for (var r in n) "default" !== r && function(e) {
            a.d(t, e, function() {
                return n[e];
            });
        }(r);
        t.default = o.a;
    },
    107: function(e, t, a) {}
}, [ [ 100, "common/runtime", "common/vendor" ] ] ]);