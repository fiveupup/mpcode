require("../../uni-bootstrap.js"), (global.webpackJsonp = global.webpackJsonp || []).push([ [ "pages/couponCenter/couponCenter" ], {
    76: function(t, e, n) {
        (function(t) {
            n(4);
            e(n(2));
            function e(t) {
                return t && t.__esModule ? t : {
                    default: t
                };
            }
            t(e(n(77)).default);
        }).call(this, n(1).createPage);
    },
    77: function(t, e, n) {
        n.r(e);
        var i = n(78), o = n(80);
        for (var s in o) "default" !== s && function(t) {
            n.d(e, t, function() {
                return o[t];
            });
        }(s);
        n(82);
        var a = n(10), r = Object(a.default)(o.default, i.render, i.staticRenderFns, !1, null, null, null, !1, i.components, void 0);
        r.options.__file = "pages/couponCenter/couponCenter.vue", e.default = r.exports;
    },
    78: function(t, e, n) {
        n.r(e);
        var i = n(79);
        n.d(e, "render", function() {
            return i.render;
        }), n.d(e, "staticRenderFns", function() {
            return i.staticRenderFns;
        }), n.d(e, "recyclableRender", function() {
            return i.recyclableRender;
        }), n.d(e, "components", function() {
            return i.components;
        });
    },
    79: function(t, e, n) {
        n.r(e), n.d(e, "render", function() {
            return i;
        }), n.d(e, "staticRenderFns", function() {
            return s;
        }), n.d(e, "recyclableRender", function() {
            return o;
        }), n.d(e, "components", function() {});
        var i = function() {
            var t = this.$createElement;
            this._self._c;
        }, o = !1, s = [];
        i._withStripped = !0;
    },
    80: function(t, e, n) {
        n.r(e);
        var i = n(81), o = n.n(i);
        for (var s in i) "default" !== s && function(t) {
            n.d(e, t, function() {
                return i[t];
            });
        }(s);
        e.default = o.a;
    },
    81: function(t, e, n) {
        (function(t) {
            Object.defineProperty(e, "__esModule", {
                value: !0
            }), e.default = void 0;
            var n = {
                data: function() {
                    return {
                        currentIndex: 0,
                        tabScrollIntoView: "tab-0",
                        tablist: [],
                        couponLists: {},
                        timeLimitCouponList: [],
                        activityTime: [ "10:00", "12:00", "17:00", "20:00" ],
                        timeStampList: [],
                        dateInfo: [ {
                            date: "10:00",
                            txt: "即将开抢",
                            isInProgress: !1
                        }, {
                            date: "18:00",
                            txt: "即将开抢",
                            isInProgress: !1
                        } ],
                        interval: 0,
                        countDown: "",
                        gid: 0
                    };
                },
                onLoad: function(t) {
                    this.gid = t.gid || 0, this.computeTime(), this.getTimeLimitCouponList(), this.getCategoryList();
                },
                methods: {
                    computeTime: function() {
                        var t = this, e = new Date(), n = e.getTime(), i = e.getFullYear(), o = e.getMonth() + 1, s = e.getDate();
                        this.activityTime.map(function(e) {
                            t.timeStampList.push(new Date("".concat(i, "/").concat(o, "/").concat(s, " ").concat(e)).getTime());
                        }), console.log(this.timeStampList), n >= this.timeStampList[0] && n < this.timeStampList[1] ? (this.dateInfo = [ {
                            date: "",
                            txt: "抢购中",
                            isInProgress: !0
                        }, {
                            date: "18:00",
                            txt: "即将开抢",
                            isInProgress: !1
                        } ], this.interval = (this.timeStampList[1] - n) / 1e3, this.setCountDown(1)) : n >= this.timeStampList[1] && n < this.timeStampList[2] ? this.dateInfo = [ {
                            date: "18:00",
                            txt: "即将开抢",
                            isInProgress: !1
                        }, {
                            date: "明日10:00",
                            txt: "即将开抢",
                            isInProgress: !1
                        } ] : n >= this.timeStampList[2] && n < this.timeStampList[3] ? (this.dateInfo = [ {
                            date: "",
                            txt: "抢购中",
                            isInProgress: !0
                        }, {
                            date: "明日10:00",
                            txt: "即将开抢",
                            isInProgress: !1
                        } ], this.interval = (this.timeStampList[3] - n) / 1e3, this.setCountDown(2)) : n >= this.timeStampList[3] && (this.dateInfo = [ {
                            date: "明日10:00",
                            txt: "即将开抢",
                            isInProgress: !1
                        }, {
                            date: "明日18:00",
                            txt: "即将开抢",
                            isInProgress: !1
                        } ]);
                    },
                    switchTab: function(t) {
                        this.currentIndex != t && (this.currentIndex = t);
                    },
                    swiperChange: function(t) {
                        this.currentIndex = t.detail.current;
                        var e = this.tablist[this.currentIndex].categoryId;
                        this.couponLists[e].loaded || this.getList(e);
                    },
                    getCategoryList: function() {
                        var t = this;
                        this.$hq.http.get("/wxapp/v1/sales/getSecondCategoryTagWithHasCoupon").then(function(e) {
                            if (0 == e.data.status.code) {
                                t.tablist = e.data.data || [];
                                var n = {}, i = !1;
                                if (t.tablist.map(function(e, o) {
                                    t.gid && t.gid == e.categoryId && (i = !0, t.currentIndex = o, o > 4 && (t.tabScrollIntoView = "tab-" + o)), 
                                    n[e.categoryId] = {
                                        loaded: !1,
                                        list: []
                                    };
                                }), t.couponLists = n, t.tablist.length > 0) {
                                    var o = i ? t.gid : t.tablist[0].categoryId;
                                    t.getList(o);
                                }
                            }
                        });
                    },
                    getList: function(e) {
                        var n = this;
                        t.showLoading({
                            title: "加载中...",
                            mask: !0
                        });
                        var i = {
                            edu24ol_token: !0,
                            second_category: e
                        };
                        this.$hq.http.get("/wxapp/v1/sales/getCouponListBySecondCategory", i).then(function(i) {
                            if (0 == i.data.status.code) {
                                var o = i.data.data || [];
                                o.map(function(t) {
                                    t.startDate = n.$hq.timeFormat(t.start_time), t.endDate = n.$hq.timeFormat(t.end_time);
                                }), n.couponLists[e] = {
                                    loaded: !0,
                                    list: o
                                }, console.log(n.couponLists);
                            }
                            t.hideLoading();
                        });
                    },
                    getTimeLimitCouponList: function() {
                        var t = this;
                        this.$hq.http.get("/wxapp/v1/sales/getActivityTimeLimitCouponList", {
                            edu24ol_token: !0
                        }).then(function(e) {
                            0 == e.data.status.code && (e.data.data.map(function(e) {
                                e.progress = parseInt(e.bindNum / e.totalNum * 100) + "%", e.startDate = t.$hq.timeFormat(e.start_time), 
                                e.endDate = t.$hq.timeFormat(e.end_time);
                            }), t.timeLimitCouponList = e.data.data);
                        });
                    },
                    pullCoupons: function(e, n, i, o) {
                        var s = this;
                        t.showLoading({
                            title: "加载中...",
                            mask: !0
                        });
                        var a = {
                            edu24ol_token: !0,
                            coupon_id: e
                        };
                        this.$hq.get("/sales/v1/coupon/pullCoupons", a).then(function(e) {
                            if (t.hideLoading(), 0 == e.data.status.code || 8 == e.data.status.code) if (1 == i) {
                                var a = s.timeLimitCouponList[n];
                                a.accepted = 1, s.$set(s.timeLimitCouponList, n, a);
                            } else {
                                var r = s.couponLists[o].list[n];
                                r.accepted = 1, s.$set(s.couponLists[o].list, n, r);
                            } else t.showToast({
                                title: e.data.status.msg,
                                icon: "none"
                            });
                        });
                    },
                    handle1: function(e) {
                        var n = this.timeLimitCouponList[e];
                        0 == n.accepted ? n.totalNum != n.bindNum && (this.dateInfo[0].isInProgress ? this.pullCoupons(n.id, e, 1) : t.showToast({
                            title: "请留意抢购时间",
                            icon: "none"
                        })) : this.jumpto(n);
                    },
                    handle2: function(t, e) {
                        var n = this.couponLists[e].list[t];
                        console.log(this.couponLists[e], n), 0 == n.accepted ? this.pullCoupons(n.id, t, 2, e) : this.jumpto(n);
                    },
                    jumpto: function(e) {
                        t.setStorageSync("couponInfo", e), t.navigateTo({
                            url: "/pages/couponDetail/couponDetail?couponId=" + e.id
                        });
                    },
                    setCountDown: function(t) {
                        var e = this, n = parseInt(this.interval);
                        this.timer && (clearInterval(this.timer), this.timer = null), this.timer = setInterval(function() {
                            if (0 == n) {
                                clearInterval(e.timer), e.timer = null;
                                var i = [ {
                                    date: "18:00",
                                    txt: "即将开抢",
                                    isInProgress: !1
                                }, {
                                    date: "明日10:00",
                                    txt: "即将开抢",
                                    isInProgress: !1
                                } ];
                                return 2 == t && (i[0].date = "明日10:00", i[1].date = "明日18:00"), void (e.dateInfo = i);
                            }
                            n--;
                            var o = parseInt(n / 3600), s = parseInt(n % 3600 / 60), a = n % 3600 % 60;
                            e.countDown = "".concat(e.format(o), ":").concat(e.format(s), ":").concat(e.format(a));
                        }, 1e3);
                    },
                    format: function(t) {
                        return ("" + t).length > 1 ? t : "0" + t;
                    }
                },
                onUnload: function() {
                    this.timer && (clearInterval(this.timer), this.timer = null, console.log("清除定时器"));
                }
            };
            e.default = n;
        }).call(this, n(1).default);
    },
    82: function(t, e, n) {
        n.r(e);
        var i = n(83), o = n.n(i);
        for (var s in i) "default" !== s && function(t) {
            n.d(e, t, function() {
                return i[t];
            });
        }(s);
        e.default = o.a;
    },
    83: function(t, e, n) {}
}, [ [ 76, "common/runtime", "common/vendor" ] ] ]);