var a = require("../../@babel/runtime/helpers/slicedToArray"), t = require("../../@babel/runtime/helpers/defineProperty"), e = getApp(), o = require("../../utils/util"), i = require("../../configs/baseConfig"), s = (require("../../configs/config_" + i.appName), 
require("../../utils/allGid"), require("../../utils/request")), d = require("../../pages/template/template");

Page({
    data: t({
        token: "",
        goodsId: "",
        groupId: "",
        uid: "",
        myUid: "",
        webId: "",
        utmSources: "",
        isSelf: 0,
        categoryInfo: {},
        shareDetailDatas: null,
        path: "",
        winShareState: !1,
        goodsName: "",
        drawSuccess: !1,
        drasCode: 0,
        isloading: 0
    }, "categoryInfo", {}),
    onLoad: function(t) {
        wx.getStorageSync("categoryInfo");
        if (this.data.goodsId = t && t.goodsId, this.data.groupId = t && t.groupId, this.data.uid = t && t.uid, 
        e.setWebIdToStorage(t.web_id), t.scene) {
            var s = decodeURIComponent(t.scene);
            if (/^gs/g.test(t.scene)) {
                var d = null;
                s.indexOf(",") > -1 && (d = s.split(",")), s.indexOf("&") > -1 && (d = s.split("&"));
                var n = a(d, 6), r = (n[0], n[1]), g = n[2], c = n[3], h = n[4], u = n[5];
                this.data.uid = r, this.data.goodsId = g, this.data.groupId = c, this.data.webId = h, 
                this.data.utmSources = u, e.setWebIdToStorage(this.data.webId);
            }
        }
        this.data.myUid = wx.getStorageSync("hqUserInfo") && wx.getStorageSync("hqUserInfo").uid || 0, 
        this.data.token = wx.getStorageSync(i.tokenKey) || "", this.data.path = "/pages/courseShare/courseShare?uid=".concat(this.data.uid, "&goodsId=").concat(this.data.goodsId, "&groupId=").concat(this.data.groupId), 
        0 != this.data.myUid && this.data.uid == this.data.myUid && (this.data.isSelf = 1, 
        this.setData({
            isSelf: this.data.isSelf
        })), t && "login" == t.type && 0 == this.data.isSelf && (o.showLoading({
            mask: !0
        }), this.data.isloading = 1, this.getCourse()), this.shareGiftDetail();
    },
    getUserInfoData: function() {
        this.shareGiftDetail();
    },
    shareGiftDetail: function() {
        var a = this, t = this;
        0 == this.data.isloading && o.showLoading(), s.shareGiftDetail({
            token: this.data.token,
            gid: this.data.groupId,
            id: this.data.goodsId,
            uid: this.data.uid
        }, function(e) {
            if (0 == e.data.status.code) {
                var i = e.data.data;
                t.data.categoryInfo = {
                    gid: i.secondCategory,
                    gname: i.secondCategoryName
                }, i.teacherList && i.teacherList.length > 0 && i.teacherList.forEach(function(a, t) {
                    o.getStrLength(a.teacherName) >= 8 && (a.teacherName = a.teacherName.slice(0, 4));
                }), wx.getStorageSync("categoryInfo") || wx.setStorageSync("categoryInfo", t.data.categoryInfo), 
                t.setData({
                    shareDetailDatas: i,
                    goodsName: i && i.name
                });
            } else if (40041 == e.data.status.code || 40042 == e.data.status.code) {
                var s = "/pages/courseShare/courseShare?uid=".concat(a.data.uid, "&goodsId=").concat(a.data.goodsId, "&groupId=").concat(a.data.groupId, "&webId=").concat(a.data.webId, "&utmSources=").concat(a.data.utmSources);
                wx.redirectTo({
                    url: "/pages/login/login?sourcePath=" + encodeURIComponent(s)
                });
            } else o.showToast2(e.data.status.msg);
            0 == a.data.isloading && o.hideLoading();
        });
    },
    getCourse: function(a) {
        var t = this, i = this;
        if (this.data.drawSuccess) d.navigateToMiniProgramPro(3, this.data.categoryInfo.gid, this.data.categoryInfo.gname); else if (!(a && a.currentTarget.dataset.type <= 0)) {
            if (!this.data.token) return o.showToast2("请先登录"), void setTimeout(function() {
                wx.navigateTo({
                    url: "/pages/login/login?sourcePath=" + encodeURIComponent(t.data.path + "&type=login")
                });
            }, 1500);
            o.showLoading(), s.shareGiftDraw({
                token: this.data.token,
                gid: this.data.groupId,
                id: this.data.goodsId,
                uid: this.data.uid
            }, function(a) {
                var s = 0;
                if (0 == a.data.status.code) o.hideLoading(), s = 1, i.setData({
                    drawSuccess: s,
                    drasCode: a.data.status.code,
                    winShareState: !0
                }), o.reportEvent(e, "newGiftShareReceiveClick", {
                    goodsTitle: i.data.shareDetailDatas.name,
                    goodsID: i.data.goodsId,
                    examinationName: i.data.categoryInfo.gname
                }); else {
                    if (40042 == a.data.status.code) return o.hideLoading(), o.showToast2("用户信息已过期，请重新登录"), 
                    void setTimeout(function() {
                        wx.redirectTo({
                            url: "/pages/login/login?sourcePath=" + encodeURIComponent(i.data.path + "&type=login")
                        });
                    }, 2500);
                    o.hideLoading(), o.showToast2(a.data.status.msg), 1502 != a.data.status.code && 1401 != a.data.status.code || i.setData({
                        drawSuccess: 1
                    });
                }
                t.data.isloading = 0;
            });
        }
    },
    onShareAppMessage: function(a) {
        var t = this.data.categoryInfo, e = this.data.path + "&gid=".concat(t.gid, "&gname=").concat(t.gname), o = wx.getStorageSync("webIdInfo");
        return o && (e += "&web_id=".concat(o.web_id)), console.log(999, "path", e), {
            title: "环球网校·职业教育考证培训，精品好课，尽在其中",
            path: e,
            imageUrl: "",
            success: function(a) {},
            complete: function() {}
        };
    }
});