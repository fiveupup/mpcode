var e = getApp(), a = {
    version: "4.11.19",
    appid: "hqwxmall_wxapp",
    app_id: "wxb7340ab1fe9bb3ee",
    orgId: 2,
    groupName: "hqwxmall_wxapp",
    srcType: 400,
    firstPType: 408,
    lastPType: 408,
    srcTypeValue: 400,
    logoImg: "../../images/" + require("./baseConfig").appName + "/logo.png",
    shareObj: {
        title: "环球网校",
        path: "/pages/index/index",
        imageUrl: "https://oss-hqwx-edu24ol.hqwx.com/miniapp/hq_mall/share.jpg"
    },
    groupid: 398266688,
    afterSalesGroupid: 397810562
};

e && e.globalData.extConfig.thirdLogin && (a = Object.assign(a, e.globalData.extConfig)), 
module.exports = a;