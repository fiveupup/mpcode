(global.webpackJsonp = global.webpackJsonp || []).push([ [ "common/main" ], [ function(t, e, o) {
    (function(t, e) {
        o(4);
        var n = l(o(2)), a = l(o(5)), r = l(o(11)), u = l(o(20)), i = o(21);
        function l(t) {
            return t && t.__esModule ? t : {
                default: t
            };
        }
        function p(t, e) {
            var o = Object.keys(t);
            if (Object.getOwnPropertySymbols) {
                var n = Object.getOwnPropertySymbols(t);
                e && (n = n.filter(function(e) {
                    return Object.getOwnPropertyDescriptor(t, e).enumerable;
                })), o.push.apply(o, n);
            }
            return o;
        }
        function f(t, e, o) {
            return e in t ? Object.defineProperty(t, e, {
                value: o,
                enumerable: !0,
                configurable: !0,
                writable: !0
            }) : t[e] = o, t;
        }
        var d = o(24)("./config_" + u.default.appName).default;
        console.log("AppConfig", d), n.default.use(r.default), console.log(n.default.prototype.$hq), 
        n.default.prototype.$hq.http.setConfig({
            baseUrl: "https://kjapi.98809.com"
        }), n.default.prototype.$hq.http.interceptors.request = function(t) {
            var e = {
                appid: u.default.appid,
                _appid: u.default.appid,
                app_id: u.default.appid,
                _os: u.default.os,
                _v: u.default.version,
                _t: Date.now(),
                platform: u.default.platform,
                org_id: u.default.orgId,
                schId: d.orgId,
                pschId: d.pschId
            };
            return t.url.indexOf(u.default.hostJAPI) > -1 && (e.platform = "wx_mini"), t.data = Object.assign({}, e, t.data), 
            t;
        }, n.default.prototype.$hq.http.interceptors.response = function(e, o) {
            if (!t.getStorageSync("hq_token") && e.data && e.data.status && [ 40041, 40042 ].indexOf(e.data.status.code) > -1) {
                t.hideLoading();
                var a = getCurrentPages()[getCurrentPages().length - 1], r = "/" + a.route;
                return "{}" != JSON.stringify(a.options) && (r += "?" + n.default.prototype.$hq.utils.paramsStringify(a.options)), 
                t.setStorageSync("page2login", r), void t.navigateTo({
                    url: "/pages/login/login"
                });
            }
            return e;
        }, n.default.prototype.$hq.http.updateUserInfo = function(e, o) {
            (0, i.profile)(function(n) {
                0 == n.data.status.code ? (t.setStorageSync(u.default.tokenKey, n.data.data.token), 
                t.setStorageSync("hqUserInfo", n.data.data), e()) : o();
            });
        }, n.default.config.productionTip = !1, a.default.mpType = "app", e(new n.default(function(t) {
            for (var e = 1; e < arguments.length; e++) {
                var o = null != arguments[e] ? arguments[e] : {};
                e % 2 ? p(Object(o), !0).forEach(function(e) {
                    f(t, e, o[e]);
                }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(t, Object.getOwnPropertyDescriptors(o)) : p(Object(o)).forEach(function(e) {
                    Object.defineProperty(t, e, Object.getOwnPropertyDescriptor(o, e));
                });
            }
            return t;
        }({}, a.default))).$mount();
    }).call(this, o(1).default, o(1).createApp);
}, , , , , function(t, e, o) {
    o.r(e);
    var n = o(6);
    for (var a in n) "default" !== a && function(t) {
        o.d(e, t, function() {
            return n[t];
        });
    }(a);
    o(8);
    var r = o(10), u = Object(r.default)(n.default, void 0, void 0, !1, null, null, null, !1, void 0, void 0);
    u.options.__file = "App.vue", e.default = u.exports;
}, function(t, e, o) {
    o.r(e);
    var n = o(7), a = o.n(n);
    for (var r in n) "default" !== r && function(t) {
        o.d(e, t, function() {
            return n[t];
        });
    }(r);
    e.default = a.a;
}, function(t, e, o) {
    (function(t) {
        Object.defineProperty(e, "__esModule", {
            value: !0
        }), e.default = void 0;
        var o = {
            onLaunch: function() {
                console.log("App Launch"), t.removeStorageSync("launch_experience_popup_loaded");
            },
            onShow: function() {
                console.log("App Show");
            },
            onHide: function() {
                console.log("App Hide");
            },
            globalData: {
                test: "Hello! I am the globalData from App.vue"
            }
        };
        e.default = o;
    }).call(this, o(1).default);
}, function(t, e, o) {
    o.r(e);
    var n = o(9), a = o.n(n);
    for (var r in n) "default" !== r && function(t) {
        o.d(e, t, function() {
            return n[t];
        });
    }(r);
    e.default = a.a;
}, function(t, e, o) {} ], [ [ 0, "common/runtime", "common/vendor" ] ] ]), module.exports = {};