require("@babel/runtime/helpers/Arrayincludes");

var e = require("./utils/util"), t = require("./configs/baseConfig"), o = require("./configs/config_hqwxmall"), a = require("./utils/allGid"), n = require("./utils/cache"), i = require("./utils/wxRequest");

require("./utils/log").init({
    open: !0,
    envVersion: "release",
    notReport: [ "https://api.sc.hqwx.com", "https://api.live.bilibili.com" ],
    reportPerformance: [ {
        id: 1004,
        url: "/mobile/v2/goods/getGoodsGroupList"
    }, {
        id: 1005,
        url: "/mobile/v2/categories/get_group_category"
    }, {
        id: 1007,
        url: "/wxapp/activity/zuli/activityList"
    }, {
        id: 1008,
        url: "/wxapp/activity/zuli/shareInfo"
    }, {
        id: 1009,
        url: "/wxapp/activity/zuli/share"
    }, {
        id: 1010,
        url: "/wxapp/activity/zuli/zuli"
    }, {
        id: 1011,
        url: "/wxapp/v1/user/getWxUserInfo"
    }, {
        id: 1012,
        url: "/wxapp/v1/user/profile"
    }, {
        id: 1013,
        url: "/wxapp/v1/user/wxMobRegister"
    }, {
        id: 1014,
        url: "/wxapp/v1/user/login"
    }, {
        id: 1015,
        url: "/wxapp/v1/user/register"
    }, {
        id: 1016,
        url: "/wxapp/v1/user/unbindThirdUser"
    }, {
        id: 1017,
        url: "/wxapp/v1/live/listRoom"
    }, {
        id: 1018,
        url: "/ping"
    } ],
    reportPerformanceAllId: 1006
});

var s = require("./utils/sensorsdata.min.js"), r = require("./utils/popup.cmd.min.js");

s.setPara({
    name: "sensors",
    server_url: "https://api.sc.hqwx.com/sa?project=production",
    send_timeout: 1e3,
    use_client_time: !1,
    show_log: !0,
    allow_amend_share_path: !0,
    autoTrack: {
        appLaunch: !0,
        appShow: !0,
        appHide: !0,
        pageShow: !0,
        pageShare: !0
    },
    is_plugin: !1
}), s.usePlugin(r, {
    show_log: !0,
    api_base_url: t.httpHost + "popup.sc.hqwx.com/api/v2",
    app_id: "wxb7340ab1fe9bb3ee",
    popup_listener: {
        onClick: function(e, t) {
            if (t) {
                var o = "";
                if ([ "navigateTo", "navigateToMiniProgram" ].includes(t.type)) {
                    o = t.value.path;
                    /^\//.test(o) || (o = "/" + o);
                }
                switch (t.type) {
                  case "close":
                    break;

                  case "openlink":
                    o = t.value, o = "/pages/findDetail/findDetail?url=" + encodeURIComponent(o), console.log(999, 333, o), 
                    wx.navigateTo({
                        url: o
                    });
                    break;

                  case "copy":
                  case "customize":
                    break;

                  case "navigateTo":
                    wx.navigateTo({
                        url: o
                    });
                    break;

                  case "navigateToMiniProgram":
                    console.log(999, 555, o), wx.navigateToMiniProgram({
                        appId: t.value.appid,
                        path: o,
                        success: function(e) {}
                    });
                }
            }
            console.log(999, "onClick", e, t);
        },
        onLoadSuccess: function(e) {
            console.log(999, "onLoadSuccess ", e);
        },
        onLoadFailed: function(e, t, o) {
            console.log(999, "计划： ", e, " code: ", t, " meaage: ", o);
        }
    }
}), s.registerApp({
    platform: t.platform,
    appName: t.appid,
    topOrgId: "14",
    orgId: t.orgId + ""
}), s.init(), o.sdid = s.store.getDistinctId(), require("./uni-bootstrap.js");

i(), App({
    globalData: {
        web_id: null,
        liveTimer: null,
        courseTimer: [],
        hasGetWxOpenId: !1,
        scene: 1
    },
    onLaunch: function(e) {
        if (wx.getStorageSync("initAddress") && wx.removeStorageSync("initAddress"), wx.getStorageSync("liveBarData") && wx.removeStorageSync("liveBarData"), 
        this.globalData.extConfig = wx.getExtConfigSync ? wx.getExtConfigSync() : {}, wx.canIUse("getUpdateManager")) {
            var t = wx.getUpdateManager();
            t.onCheckForUpdate(function(e) {
                e.hasUpdate && (t.onUpdateReady(function() {
                    wx.showModal({
                        title: "更新提示",
                        content: "新版本已经准备好，是否重启应用？",
                        showCancel: !1,
                        success: function(e) {
                            e.confirm && t.applyUpdate();
                        }
                    });
                }), t.onUpdateFailed(function() {
                    wx.showModal({
                        title: "已经有新版本了哟~",
                        content: "新版本已经上线啦~，请您删除当前小程序，重新搜索打开哟~",
                        showCancel: !1
                    });
                }));
            });
        } else wx.showModal({
            title: "提示",
            content: "当前微信版本过低，无法使用该功能，请升级到最新微信版本后重试。",
            showCancel: !1
        });
        wx.showShareMenu({
            withShareTicket: !0
        }), this.checkToken();
    },
    onShow: function(e) {
        if (console.log(999, "onShow", e), e.query = this.customDecode(e.query), this.globalData.scene = e.scene, 
        e.query && e.query.gid && "undefined" != e.query.gid) {
            for (var t = e.query.gid, n = "", i = 0; i < a.length; i++) if (a[i].id == t) {
                n = a[i].name;
                break;
            }
            wx.setStorageSync("categoryInfo", {
                gid: t,
                gname: n
            });
        }
        console.log(9999, "e.query", e.query), e && e.query && (e.query.appShareId && (this.globalData.shareId = e.query.appShareId, 
        o.srcType = 2002), e.query.shareId && (this.globalData.shareId = e.query.shareId));
        var r = [ 1036 ].indexOf(e.scene) > -1, c = [ 1007 ].indexOf(e.scene) > -1;
        this.globalData.shareId && (r || c || (this.globalData.shareId = ""), r || (o.srcType = o.srcTypeValue), 
        this.globalData.shareId && (s.para.autoTrack.pageShow = {
            shareID: this.globalData.shareId
        })), this.friendsShareAd(e);
    },
    checkToken: function() {
        var e = this;
        wx.getSetting({
            success: function(t) {
                "getSetting:ok" == t.errMsg && t.authSetting && t.authSetting["scope.userInfo"] && wx.login({
                    success: function(t) {
                        var o = Object.assign({}, {
                            code: t.code
                        }, o);
                        wx.getUserInfo({
                            withCredentials: !0,
                            success: function(t) {
                                Object.assign(o, t), e.profile(o);
                            }
                        });
                    }
                });
            }
        });
    },
    profile: function(a) {
        var n = {
            appid: o.appid,
            _appid: o.appid,
            pschId: t.pschId,
            schId: t.orgId,
            t: e.timeStamp(),
            os: e.checkOS(),
            platform: t.platform,
            encryptedData: encodeURIComponent(a.encryptedData),
            code: encodeURIComponent(a.code),
            iv: encodeURIComponent(a.iv)
        };
        wx.request({
            url: "".concat(t.host, "/wxapp/v1/user/profile"),
            data: n,
            method: "POST",
            header: {
                "content-type": "application/x-www-form-urlencoded"
            },
            success: function(o) {
                if (0 == o.data.status.code) {
                    var a = o.data.data;
                    wx.setStorageSync(t.tokenKey, a.token), wx.setStorageSync(t.tokenTimeStamp, e.timeStamp()), 
                    wx.setStorageSync("hqUserInfo", a);
                }
            },
            fail: function(e) {}
        });
    },
    friendsShareAd: function(t) {
        var a = t.query, n = t.path + "?", i = !1, s = !1, r = {}, c = "regUrlObj";
        if ("{}" != JSON.stringify(a)) {
            for (var d in a) "utm_source" == d && "wechatsrM" == a[d] && (i = !0), "src_type" == d && (s = !0);
            if (i || s) {
                for (var p in a) n += p + "=" + a[p] + "&";
                r = {
                    regUrl: n = n.substring(0, n.length - 1),
                    timeStamp: e.timeStamp()
                }, wx.setStorageSync(c, r), this.eFSA = t;
            }
        }
        if (r = wx.getStorageSync(c)) if (e.timeStamp() - r.timeStamp > 6048e5) wx.removeStorageSync(c); else {
            var l = Number(e.queryString(r.regUrl, "src_type")) || "";
            "wechatsrM" == e.queryString(r.regUrl, "utm_source") ? o.srcType = l || 420 : o.srcType = l;
        }
        console.log("regUrlObj", r);
    },
    getUserInfo: function(e, t) {
        var o = this;
        o.globalData.userInfo ? "function" == typeof e && e(this.globalData) : wx.checkSession({
            success: function() {
                o.wxLogin(t, e);
            },
            fail: function() {
                o.wxLogin(t, e);
            }
        });
    },
    wxLogin: function(e, a) {
        var n = this;
        wx.login({
            success: function(i) {
                Object.assign(n.globalData, {
                    code: i.code
                }), wx.request({
                    url: t.host + "/wxapp/v1/user/wxLogin",
                    data: {
                        appid: o.appid,
                        org_id: t.orgId,
                        code: i.code
                    },
                    success: function(t) {
                        if (0 == t.data.status.code) {
                            var o = t.data.data.session_key;
                            wx.setStorageSync("sessionKey", o), Object.assign(n.globalData, {
                                sessionKey: o
                            }), n.wxUserInfo(e, a);
                        }
                    }
                });
            },
            fail: function(e) {
                wx.hideLoading(), wx.showModal({
                    title: "提示",
                    content: "微信用户登录失败，请用删除小程序，重新进入~",
                    showCancel: !1
                });
            }
        });
    },
    wxUserInfo: function(e, t) {
        var o = this;
        wx.getUserInfo({
            withCredentials: !0,
            success: function(a) {
                Object.assign(o.globalData, {
                    sysInfo: wx.getSystemInfoSync()
                }, {
                    appBaseInfo: a
                }), o.globalData.sysInfo.system.indexOf("Android") > -1 && (o.globalData.sysInfo.os = 1), 
                o.globalData.sysInfo.system.indexOf("iOS") > -1 && (o.globalData.sysInfo.os = 2), 
                "function" == typeof t && t(o.globalData), wx.getStorageSync("wxOpenId") || o.globalData.hasGetWxOpenId || (o.getWxUserInfo(function(e) {
                    wx.setStorageSync("wxOpenId", e.openId);
                }), o.globalData.hasGetWxOpenId = !0), e && e.selectComponent("#authorize").hideAuthorize(), 
                wx.hideLoading();
            },
            fail: function(e) {
                "courseDetail" == wx.getStorageSync("lastUrl") ? wx.getStorageSync("lastCourseId") : wx.getStorageSync("lastUrl"), 
                wx.hideLoading();
            }
        });
    },
    getHQInfo: function(a, n) {
        var i = this;
        this.getUserInfo(function() {
            wx.request({
                url: t.host + "/wxapp/v1/user/getUserInfo",
                data: {
                    appid: o.appid,
                    org_id: t.orgId,
                    token: wx.getStorageSync(t.tokenKey),
                    uid: wx.getStorageSync("hqUserInfo").uid,
                    encryptedData: encodeURIComponent(i.globalData.appBaseInfo.encryptedData),
                    code: encodeURIComponent(i.globalData.code),
                    iv: encodeURIComponent(i.globalData.appBaseInfo.iv),
                    sessionKey: encodeURIComponent(wx.getStorageSync("sessionKey")),
                    thirdLogin: o.thirdLogin || "",
                    thirdMp: o.thirdMp || ""
                },
                method: "POST",
                header: {
                    "content-type": "application/x-www-form-urlencoded"
                },
                success: function(t) {
                    0 == t.data.status.code ? "function" == typeof a && a(t.data.data) : "function" == typeof n && n(t), 
                    e.hideLoading();
                },
                fail: function() {
                    e.showToast2("获取个人信息失败。"), e.hideLoading();
                }
            });
        });
    },
    getWxUserInfo: function(a) {
        var n = this;
        this.getUserInfo(function() {
            wx.request({
                url: t.host + "/wxapp/v1/user/getWxUserInfo",
                data: {
                    appid: o.appid,
                    org_id: t.orgId,
                    encryptedData: encodeURIComponent(n.globalData.appBaseInfo.encryptedData),
                    code: encodeURIComponent(n.globalData.code),
                    iv: encodeURIComponent(n.globalData.appBaseInfo.iv),
                    sessionKey: encodeURIComponent(wx.getStorageSync("sessionKey")),
                    thirdLogin: o.thirdLogin || "",
                    thirdMp: o.thirdMp || ""
                },
                method: "POST",
                header: {
                    "content-type": "application/x-www-form-urlencoded"
                },
                success: function(t) {
                    0 == t.data.status.code ? "function" == typeof a && a(t.data.data) : e.showToast2("获取个人信息失败。"), 
                    e.hideLoading();
                },
                fail: function() {
                    e.showToast2("获取个人信息失败。"), e.hideLoading();
                }
            });
        });
    },
    wxMobRegister: function(a, n) {
        var i = this, s = wx.getStorageSync("regUrlObj"), r = s ? s.regUrl : "", c = wx.getStorageSync("vfr"), d = wx.getStorageSync("categoryInfo") && wx.getStorageSync("categoryInfo").gid, p = e.getUrlParams().firstPType || "", l = o.srcType, u = wx.getStorageSync("webIdInfo") && wx.getStorageSync("webIdInfo").web_id || "", g = wx.getStorageSync("regtype") || "", f = this.setExtProperties();
        wx.getStorageSync("zhuliLogin") && (d = null, l = 424), this.getUserInfo(function() {
            var s = {
                org_id: t.orgId,
                appid: o.appid,
                encryptedData: encodeURIComponent(i.globalData.appBaseInfo.encryptedData),
                iv: encodeURIComponent(i.globalData.appBaseInfo.iv),
                code: encodeURIComponent(i.globalData.code),
                sessionKey: encodeURIComponent(wx.getStorageSync("sessionKey")),
                modEncryptedData: encodeURIComponent(a.e.detail.encryptedData),
                modIv: encodeURIComponent(a.e.detail.iv)
            };
            wx.request({
                url: t.host + "/wxapp/v1/user/wxMobRegister",
                method: "POST",
                dataType: "json",
                header: {
                    "content-type": "application/x-www-form-urlencoded"
                },
                data: {
                    appid: o.appid,
                    org_id: t.orgId,
                    platform: t.platform,
                    encryptedData: s.encryptedData,
                    iv: s.iv,
                    code: s.code,
                    modEncryptedData: s.modEncryptedData,
                    modIv: s.modIv,
                    sessionKey: s.sessionKey,
                    srcType: l,
                    firstPType: p || o.firstPType,
                    lastPType: o.lastPType,
                    chId: a.chId || u || null,
                    sortId: a.sortId || d || null,
                    inviteId: a.u || c && c.u || "",
                    coupon: a.c || c && c.c || "",
                    shareKey: a.s || c && c.s || "",
                    distinct_id: o.sdid,
                    regUrl: r,
                    regtype: g,
                    redPackId: a.e.redPackId || "",
                    groupId: wx.getStorageSync("trainingGroupId") || "",
                    extProperties: f
                },
                success: function(t) {
                    "function" == typeof n && n(t), e.hideLoading();
                },
                fail: function(t) {
                    console.log("wxMobRegister fail", t), e.hideLoading();
                }
            });
        });
    },
    getSMSCode: function(a, n) {
        var i = Object.assign({
            appid: o.appid,
            org_id: t.orgId,
            platform: t.platform,
            encryptedData: encodeURIComponent(this.globalData.appBaseInfo.encryptedData),
            code: encodeURIComponent(this.globalData.code),
            iv: encodeURIComponent(this.globalData.appBaseInfo.iv),
            sessionKey: encodeURIComponent(wx.getStorageSync("sessionKey")),
            distinct_id: o.sdid
        }, a);
        this.getUserInfo(function() {
            wx.request({
                url: t.host + "/wxapp/v1/user/sms",
                method: "POST",
                dataType: "json",
                header: {
                    "content-type": "application/x-www-form-urlencoded"
                },
                data: i,
                success: function(t) {
                    console.log("getSMSCode", t), e.hideLoading(), "function" == typeof n && n(t);
                },
                fail: function(t) {
                    e.showToast2(t.data.status.msg), e.hideLoading();
                }
            });
        });
    },
    login: function(a, n) {
        var i = this, s = e.getUrlParams().firstPType || "", r = this.setExtProperties();
        e.showLoading({
            title: "登录中...",
            mask: !0
        }), wx.login({
            success: function(c) {
                Object.assign(i.globalData, {
                    code: c.code
                }), wx.request({
                    url: t.host + "/wxapp/v1/user/login",
                    method: "POST",
                    dataType: "json",
                    header: {
                        "content-type": "application/x-www-form-urlencoded"
                    },
                    data: {
                        srcType: o.srcType,
                        firstPType: s || o.firstPType,
                        lastPType: o.lastPType,
                        appid: o.appid,
                        org_id: t.orgId,
                        platform: t.platform,
                        encryptedData: encodeURIComponent(i.globalData.appBaseInfo.encryptedData),
                        code: encodeURIComponent(i.globalData.code),
                        iv: encodeURIComponent(i.globalData.appBaseInfo.iv),
                        sessionKey: encodeURIComponent(wx.getStorageSync("sessionKey")),
                        isBind: a.isBind || 0,
                        name: a.name || "",
                        pwd: a.password || "",
                        smsCode: a.smsCode,
                        distinct_id: o.sdid,
                        extProperties: r
                    },
                    success: function(o) {
                        if (console.log("submitLogin", o), 239 == o.data.status.code) {
                            var a = o.data.data;
                            wx.showModal({
                                title: "提示",
                                content: "当前账号已绑定其它微信号，继续登录需解除已有绑定。是否继续解绑操作？",
                                cancelText: "放弃",
                                confirmText: "继续解绑",
                                success: function(o) {
                                    o.confirm ? (wx.setStorage({
                                        key: "hqUserInfo",
                                        data: a
                                    }), wx.setStorage({
                                        key: t.tokenKey,
                                        data: a.token
                                    }), wx.redirectTo({
                                        url: "/pages/unbindAccount/unbindAccount"
                                    })) : o.cancel && e.showToast2("未完成解绑，登录失败。");
                                }
                            }), e.hideLoading();
                        } else 0 == o.data.status.code ? (e.userBindReport(i, o.data.data.uid), wx.setStorage({
                            key: "hqUserInfo",
                            data: o.data.data
                        }), wx.setStorage({
                            key: t.tokenTimeStamp,
                            data: e.timeStamp()
                        }), wx.setStorage({
                            key: t.tokenKey,
                            data: o.data.data.token,
                            success: function() {
                                "function" == typeof n && n(o);
                            }
                        }), e.hideLoading()) : (e.hideLoading(), e.showToast2(o.data.status.msg));
                    }
                });
            }
        });
    },
    checkNetworkState: function(e) {
        wx.getNetworkType({
            success: function(t) {
                wx.hideLoading(), "none" != t.networkType ? e && e() : wx.showModal({
                    title: "提示",
                    content: "您现在处于无网络连接或网络连接不正常，请查检你的网络状况~",
                    showCancel: !1
                });
            },
            fail: function() {
                wx.hideLoading(), wx.showModal({
                    title: "提示",
                    content: "获取您的网络状况失败，请重试~",
                    showCancel: !1
                });
            }
        });
    },
    setWebIdToStorage: function(t) {
        var o = "webIdInfo", a = wx.getStorageSync(o) || {};
        console.log("setWebIdToStorage", t), void 0 !== t ? (a[t] || (a = {}), a.web_id = parseInt(t), 
        a.timeStamp = e.timeStamp(), wx.setStorageSync(o, a)) : (e.timeStamp() - a.timeStamp || 0) > 6048e5 && wx.removeStorageSync(o), 
        this.web_id = a.web_id || 0;
    },
    HQTokenStorage: function(o, a) {
        wx.getStorageSync(t.tokenKey) ? wx.getStorageSync(t.tokenTimeStamp) ? e.timeStamp() - wx.getStorageSync(t.tokenTimeStamp) > 5184e5 ? "function" == typeof o && o() : "function" == typeof a && a() : "function" == typeof o && o() : "function" == typeof a && o();
    },
    checkUserToken: function(o, a) {
        wx.getSetting({
            success: function(n) {
                n.authSetting["scope.userInfo"] && (wx.getStorageSync(t.wx_token) ? "function" == typeof o && o() : (e.showLoading({
                    title: "获取用户信息中，请稍候……",
                    mask: "true"
                }), "function" == typeof a && a()));
            }
        });
    },
    getUserShortId: function(e, a, n) {
        wx.request({
            url: t.host + "/mobile/v2/user/getMiniAppUserSortID",
            data: {
                _appid: o.appid,
                edu24ol_token: e,
                org_id: t.orgId,
                goToLogin: !1
            },
            method: "GET",
            dataType: "json",
            success: function(e) {
                0 == e.data.status.code ? "function" == typeof a && a(e) : 40041 != e.data.status.code && 40042 != e.data.status.code || "function" == typeof n && n(e);
            }
        });
    },
    getAppCategory: function(a, n) {
        wx.request({
            url: t.host + "/mobile/v2/categories/miniapp_all_list",
            data: {
                _appid: o.appid,
                org_id: t.orgId,
                _t: e.timeStamp(),
                level: a.level || "1,2"
            },
            success: function(e) {
                0 == e.data.status.code && e.data.data && e.data.data.length > 0 && "function" == typeof n && n(e.data.data);
            }
        });
    },
    allCategory: function(a) {
        wx.request({
            url: t.host + "/mobile/v2/categories/all_lists",
            data: {
                _appid: o.appid,
                org_id: t.orgId,
                _t: e.timeStamp()
            },
            success: function(e) {
                0 == e.data.status.code && e.data.data && "function" == typeof a && a(e.data.data);
            }
        });
    },
    getGroupCategory: function(a) {
        wx.request({
            url: t.host + "/mobile/v2/categories/get_group_category",
            data: {
                _appid: o.appid,
                org_id: t.orgId,
                _t: e.timeStamp()
            },
            success: function(e) {
                0 == e.data.status.code && e.data.data && "function" == typeof a && a(e.data.data);
            }
        });
    },
    fixIPhone: function(e) {
        wx.getSystemInfoSync().model.indexOf("iPhone X") > -1 ? e.setData({
            isIPhoneX: !0
        }) : e.setData({
            isIPhoneX: !1
        });
    },
    createFormId: function(e, a) {
        wx.request({
            url: t.host + "/wxapp/v1/user/createFormId",
            method: "POST",
            dataType: "json",
            header: {
                "content-type": "application/x-www-form-urlencoded"
            },
            data: {
                appid: o.appid,
                org_id: t.orgId,
                platform: t.platform,
                encryptedData: encodeURIComponent(this.globalData.appBaseInfo.encryptedData),
                code: encodeURIComponent(this.globalData.code),
                iv: encodeURIComponent(this.globalData.appBaseInfo.iv),
                sessionKey: encodeURIComponent(wx.getStorageSync("sessionKey")),
                form_id: e
            },
            success: function(e) {
                0 == e.data.status.code && "function" == typeof a && a(e.data.data);
            }
        });
    },
    getBannerDatas: function(a, n, i, s) {
        var r = "";
        wx.request({
            url: t.host + "/wxapp/v1/advertising/banner",
            data: {
                _appid: o.appid,
                _os: t.os,
                _v: o.version,
                _t: e.timeStamp(),
                org_id: t.orgId,
                platform: t.platform,
                position: a,
                secondCategory: n
            },
            method: "GET",
            dataType: "json",
            success: function(e) {
                0 == e.data.status.code && (r = e.data.data) ? "function" == typeof i && i(r) : "function" == typeof s && s(e);
            },
            fail: function(e) {
                "function" == typeof s && s(e);
            }
        });
    },
    getIconsDatas: function(a, n, i) {
        var s = "";
        wx.request({
            url: t.host + "/wxapp/v1/advertising/icon",
            data: {
                _appid: o.appid,
                _os: t.os,
                _v: o.version,
                _t: e.timeStamp(),
                org_id: t.orgId,
                platform: t.platform,
                position: a,
                secondCategory: wx.getStorageSync("categoryInfo").gid
            },
            method: "GET",
            dataType: "json",
            success: function(e) {
                0 == e.data.status.code ? (s = e.data.data) ? "function" == typeof n && n(s) : "function" == typeof i && i(s) : "function" == typeof i && i(e);
            },
            fail: function() {
                "function" == typeof i && i(res);
            }
        });
    },
    getPopupsDatas: function(a, n, i) {
        var s = "";
        wx.request({
            url: t.host + "/wxapp/v1/advertising/pop_ups",
            data: {
                _appid: o.appid,
                _os: t.os,
                _v: o.version,
                _t: e.timeStamp(),
                org_id: t.orgId,
                platform: t.platform,
                position: a,
                secondCategory: wx.getStorageSync("categoryInfo").gid
            },
            method: "GET",
            dataType: "json",
            success: function(e) {
                0 == e.data.status.code ? (s = e.data.data) ? "function" == typeof n && n(s) : "function" == typeof i && i(s) : "function" == typeof i && i(e);
            },
            fail: function(e) {
                "function" == typeof i && i(e);
            }
        });
    },
    updateCheck: function(a, i) {
        var s = "updateCheck_".concat(o.version), r = n.get(s);
        r && null != r ? 0 == r.on ? "function" == typeof a && a() : "function" == typeof i && i() : wx.request({
            url: t.host + "/wxapp/v1/tool/updateCheck",
            data: {
                version: o.version,
                appid: o.appid,
                org_id: t.orgId,
                _t: e.timeStamp()
            },
            success: function(e) {
                0 == e.data.status.code && null != e.data.data && (0 === e.data.data.on ? "function" == typeof a && a() : "function" == typeof i && i(), 
                n.put(s, {
                    on: e.data.data.on
                }, 300));
            }
        });
    },
    addSubscribeMsg: function(a, n) {
        var i = this;
        this.getUserInfo(function() {
            wx.showLoading(), wx.request({
                url: t.host + "/wxapp/v1/user/addSubscribeMsg",
                data: {
                    appid: o.appid,
                    os: t.os,
                    v: o.version,
                    t: e.timeStamp(),
                    org_id: t.orgId,
                    platform: t.platform,
                    template: a,
                    encryptedData: encodeURIComponent(i.globalData.appBaseInfo.encryptedData),
                    code: encodeURIComponent(i.globalData.code),
                    iv: encodeURIComponent(i.globalData.appBaseInfo.iv),
                    sessionKey: encodeURIComponent(wx.getStorageSync("sessionKey"))
                },
                success: function(e) {
                    0 == e.data.status.code ? ("function" == typeof n && n(), wx.showToast({
                        title: "订阅成功",
                        icon: "none"
                    })) : wx.hideLoading();
                }
            });
        });
    },
    saveExamId: function(a, n) {
        var i = this;
        wx.showLoading(), this.getUserInfo(function() {
            wx.request({
                url: t.host + "/wxapp/v1/user/saveExamId",
                data: {
                    appid: o.appid,
                    os: t.os,
                    v: o.version,
                    t: e.timeStamp(),
                    org_id: t.orgId,
                    platform: t.platform,
                    exam_id: a,
                    encryptedData: encodeURIComponent(i.globalData.appBaseInfo.encryptedData),
                    code: encodeURIComponent(i.globalData.code),
                    sessionKey: encodeURIComponent(wx.getStorageSync("sessionKey")),
                    iv: encodeURIComponent(i.globalData.appBaseInfo.iv)
                },
                success: function(e) {
                    0 == e.data.status.code ? "function" == typeof n && n(e) : wx.hideLoading();
                }
            });
        });
    },
    getlistRoom: function(a) {
        var n = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : function() {};
        wx.request({
            url: t.host + "/wxapp/v1/live/listRoom",
            data: {
                appid: o.appid,
                os: t.os,
                v: o.version,
                t: e.timeStamp(),
                org_id: t.orgId,
                platform: t.platform,
                exam_id: a
            },
            success: function(e) {
                console.log("listRoom", e), 0 == e.data.status.code && "function" == typeof n && n(e);
            }
        });
    },
    getLiveStatus: function(e) {
        var t = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : function() {}, o = requirePlugin("live-player-plugin");
        o.getLiveStatus({
            room_id: e
        }).then(function(e) {
            var o = e.liveStatus;
            t(o), console.log("get live status", o);
        }).catch(function(e) {
            console.log("get live status", e);
        });
    },
    showLiveRoom: function(e, t) {
        var o = this;
        if (t) {
            if (this.globalData.liveTimer) {
                var a = wx.getStorageSync("liveBarData");
                a && a.gid != t && wx.removeStorageSync("liveBarData"), clearInterval(this.globalData.liveTimer);
            }
            var n = function(t) {
                o.getlistRoom(t, function(a) {
                    var n = wx.getStorageSync("liveBarData");
                    if (n && (1 == n.show && e.setData({
                        showLiveBar: !0,
                        roomId: n.roomId
                    }), 0 == n.show && e.setData({
                        showLiveBar: !1
                    })), a.data.data.list) for (var i = a.data.data.list, s = i.length, r = (i[0].room_id, 
                    []), c = function(a) {
                        o.getLiveStatus(i[a].room_id, function(o) {
                            r.push({
                                index: a,
                                roomId: i[a].room_id,
                                status: o
                            }), r.sort(function(e, t) {
                                return e.index - t.index;
                            }), console.log("listLive", r);
                            for (var n = r.length, s = "", c = !1, d = !1, p = 0; p < n; p++) if (101 == r[p].status) {
                                s = r[p].roomId, c = !0;
                                break;
                            }
                            if (c) return e.setData({
                                showLiveBar: !0,
                                roomId: s
                            }), wx.setStorageSync("liveBarData", {
                                show: 1,
                                roomId: s,
                                gid: t
                            }), void console.log("hasLiving", s);
                            for (var l = 0; l < n; l++) if (102 == r[l].status) {
                                s = r[l].roomId, d = !0;
                                break;
                            }
                            if (d) return e.setData({
                                showLiveBar: !0,
                                roomId: s
                            }), wx.setStorageSync("liveBarData", {
                                show: 1,
                                roomId: s,
                                gid: t
                            }), void console.log("hasWillStart", s);
                            e.setData({
                                showLiveBar: !1
                            }), wx.setStorageSync("liveBarData", {
                                show: 0,
                                gid: t
                            });
                        });
                    }, d = 0; d < s; d++) c(d); else e.setData({
                        showLiveBar: !1
                    }), wx.setStorageSync("liveBarData", {
                        show: 0,
                        gid: t
                    });
                });
            };
            n(t), this.globalData.liveTimer = setInterval(function() {
                console.log(t), n(t);
            }, 6e4);
        }
    },
    clearInterValCourseTimer: function() {
        this.globalData.courseTimer && this.globalData.courseTimer.length > 0 && this.globalData.courseTimer.forEach(function(e, t) {
            clearInterval(e);
        }), this.globalData.courseTimer = [];
    },
    startNetWork: function() {
        var e = this;
        e.ping(), wx.onNetworkStatusChange(function(t) {
            e.ping(t);
        });
    },
    ping: function(a) {
        var n = new Date().getTime();
        wx.request({
            url: t.host + "/ping",
            data: {
                _appid: o.appid,
                _os: t.os,
                _v: o.version,
                _t: e.timeStamp(),
                org_id: t.orgId,
                platform: t.platform
            },
            success: function(t) {
                var o = new Date().getTime() - n, i = e.formatTime(new Date()), s = o + "_" + i;
                a && null != a && (s = o + "_" + a.isConnected + "_" + a.networkType + "_" + i), 
                console.log("898911", s), wx.setStorageSync("appNetworkUseTimeKey", s);
            }
        });
    },
    customDecode: function(e) {
        if (console.log("页面原始参数:", e), e) for (var t in e) e[t] = decodeURIComponent(e[t].replace(/@/g, "%"));
        return console.log("页面解码后参数:", e), e;
    },
    random: function(e, t) {
        return Math.round(Math.random() * (t - e)) + e;
    },
    actionSourceSave: function(e, a) {
        var n = {
            appid: o.appid,
            org_id: t.orgId,
            platform: t.platform,
            firstProductId: o.firstPType,
            lastProductId: o.lastPType,
            sourceType: o.srcType,
            objectId: e,
            objectType: a,
            passport: wx.getStorageSync("hq_token")
        }, i = (wx.getStorageSync("webIdInfo") || {}).web_id || "";
        i && (n.chanelId = i), wx.request({
            url: t.hostJAPI + "/buy/actionsource/actionSourceSave",
            method: "POST",
            dataType: "json",
            header: {
                "content-type": "application/x-www-form-urlencoded"
            },
            data: n,
            success: function(e) {
                console.log("actionSourceSave", e);
            }
        });
    },
    appShare: function(t) {
        var o = e.guid();
        this.globalData.uuid = o;
        var a = {
            shareID: o,
            belongPage: t.belongPage,
            shareContentID: t.shareContentID,
            shareButton: t.shareButton,
            shareChannel: "微信好友",
            shareMethod: "小程序",
            shareContent: t.shareContent
        };
        e.reportEvent(this, "AppShare", a);
    },
    setExtProperties: function() {
        if (this.globalData.shareId) {
            var e = {
                shareId: this.globalData.shareId
            };
            return JSON.stringify(e);
        }
        return "";
    }
});