require("../../uni-bootstrap.js"), (global.webpackJsonp = global.webpackJsonp || []).push([ [ "components/c-tabBar/c-tabBar" ], {
    325: function(n, t, e) {
        e.r(t);
        var o = e(326), a = e(328);
        for (var i in a) "default" !== i && function(n) {
            e.d(t, n, function() {
                return a[n];
            });
        }(i);
        e(330);
        var c = e(10), r = Object(c.default)(a.default, o.render, o.staticRenderFns, !1, null, null, null, !1, o.components, void 0);
        r.options.__file = "components/c-tabBar/c-tabBar.vue", t.default = r.exports;
    },
    326: function(n, t, e) {
        e.r(t);
        var o = e(327);
        e.d(t, "render", function() {
            return o.render;
        }), e.d(t, "staticRenderFns", function() {
            return o.staticRenderFns;
        }), e.d(t, "recyclableRender", function() {
            return o.recyclableRender;
        }), e.d(t, "components", function() {
            return o.components;
        });
    },
    327: function(n, t, e) {
        e.r(t), e.d(t, "render", function() {
            return o;
        }), e.d(t, "staticRenderFns", function() {
            return i;
        }), e.d(t, "recyclableRender", function() {
            return a;
        }), e.d(t, "components", function() {});
        var o = function() {
            var n = this.$createElement;
            this._self._c;
        }, a = !1, i = [];
        o._withStripped = !0;
    },
    328: function(n, t, e) {
        e.r(t);
        var o = e(329), a = e.n(o);
        for (var i in o) "default" !== i && function(n) {
            e.d(t, n, function() {
                return o[n];
            });
        }(i);
        t.default = a.a;
    },
    329: function(n, t, e) {
        (function(n) {
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = void 0;
            var o = e(22), a = (getApp(), {
                props: {
                    currentKey: {
                        type: String,
                        default: "index"
                    }
                },
                data: function() {
                    return {
                        isIPhoneX: !1,
                        list: [ {
                            key: "index",
                            title: "首页",
                            ico: "https://oss-hqwx-edu24ol.oss-cn-beijing.aliyuncs.com/miniapp/hq_mall/ico_tabbaar_home.png",
                            curico: "https://oss-hqwx-edu24ol.oss-cn-beijing.aliyuncs.com/miniapp/hq_mall/ico_tabbaar_home_on.png",
                            path: "/pages/index/index"
                        }, {
                            key: "find",
                            title: "发现",
                            ico: "https://oss-hqwx-edu24ol.hqwx.com/miniapp/hq_mall/ico_tabbaar_find.png",
                            curico: "https://oss-hqwx-edu24ol.hqwx.com/miniapp/hq_mall/ico_tabbaar_find_on.png",
                            path: "/pages/findList/findList"
                        }, {
                            key: "bargain",
                            title: "0元领课",
                            ico: "https://oss-hqwx-edu24ol.hqwx.com/ico_gift-1617013021674.png",
                            curico: "https://oss-hqwx-edu24ol.hqwx.com/ico_gift-1617013021674.png",
                            path: "/pages/bargainIndex/bargainIndex"
                        }, {
                            key: "user",
                            title: "我的",
                            ico: "https://oss-hqwx-edu24ol.hqwx.com/miniapp/hq_mall/ico_tabbaar_user.png",
                            curico: "https://oss-hqwx-edu24ol.hqwx.com/miniapp/hq_mall/ico_tabbaar_user_on.png",
                            path: "/pages/user/user"
                        } ]
                    };
                },
                mounted: function() {
                    this.isIPhoneX = (0, o.fixIphoneX)();
                },
                methods: {
                    switchTab: function(t, e) {
                        t.key != this.currentKey && n.redirectTo({
                            url: this.list[e].path
                        });
                    }
                }
            });
            t.default = a;
        }).call(this, e(1).default);
    },
    330: function(n, t, e) {
        e.r(t);
        var o = e(331), a = e.n(o);
        for (var i in o) "default" !== i && function(n) {
            e.d(t, n, function() {
                return o[n];
            });
        }(i);
        t.default = a.a;
    },
    331: function(n, t, e) {}
} ]), (global.webpackJsonp = global.webpackJsonp || []).push([ "components/c-tabBar/c-tabBar-create-component", {
    "components/c-tabBar/c-tabBar-create-component": function(n, t, e) {
        e("1").createComponent(e(325));
    }
}, [ [ "components/c-tabBar/c-tabBar-create-component" ] ] ]);