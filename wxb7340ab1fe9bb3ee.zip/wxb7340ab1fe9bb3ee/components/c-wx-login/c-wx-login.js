require("../../uni-bootstrap.js");

var e = {};

e["/.././../utils/util.js"] = require("/.././../utils/util.js"), (global.webpackJsonp = global.webpackJsonp || []).push([ [ "components/c-wx-login/c-wx-login" ], {
    374: function(e, t, n) {
        n.r(t);
        var o = n(375), i = n(377);
        for (var a in i) "default" !== a && function(e) {
            n.d(t, e, function() {
                return i[e];
            });
        }(a);
        n(379);
        var s = n(10), r = Object(s.default)(i.default, o.render, o.staticRenderFns, !1, null, "2188a564", null, !1, o.components, void 0);
        r.options.__file = "components/c-wx-login/c-wx-login.vue", t.default = r.exports;
    },
    375: function(e, t, n) {
        n.r(t);
        var o = n(376);
        n.d(t, "render", function() {
            return o.render;
        }), n.d(t, "staticRenderFns", function() {
            return o.staticRenderFns;
        }), n.d(t, "recyclableRender", function() {
            return o.recyclableRender;
        }), n.d(t, "components", function() {
            return o.components;
        });
    },
    376: function(e, t, n) {
        n.r(t), n.d(t, "render", function() {
            return o;
        }), n.d(t, "staticRenderFns", function() {
            return a;
        }), n.d(t, "recyclableRender", function() {
            return i;
        }), n.d(t, "components", function() {});
        var o = function() {
            var e = this.$createElement;
            this._self._c;
        }, i = !1, a = [];
        o._withStripped = !0;
    },
    377: function(e, t, n) {
        n.r(t);
        var o = n(378), i = n.n(o);
        for (var a in o) "default" !== a && function(e) {
            n.d(t, e, function() {
                return o[e];
            });
        }(a);
        t.default = i.a;
    },
    378: function(t, n, o) {
        (function(t) {
            Object.defineProperty(n, "__esModule", {
                value: !0
            }), n.default = void 0;
            var i, a = (i = o(20)) && i.__esModule ? i : {
                default: i
            }, s = o(21);
            getApp();
            var r = e["/.././../utils/util.js"], d = {
                props: {
                    sourcePath: {
                        type: String
                    },
                    type: {
                        type: String
                    },
                    btnText: {
                        type: String
                    },
                    btnStyle: {
                        type: String
                    }
                },
                data: function() {
                    return {
                        hideVerifyLayer: !0,
                        missingPhone: "",
                        phone: "",
                        smsCode: "",
                        interval: 60,
                        verifyMsg: "重新获取",
                        abletoSendCode: !0,
                        timer: 0,
                        gid: "",
                        isTriggerRegister: 0,
                        isTriggerLogin: 0,
                        envName: a.default.taroEnvName
                    };
                },
                mounted: function() {},
                methods: {
                    getPhoneNumberCB: function(e) {
                        var n, o = this;
                        if (t.showLoading({
                            title: "登录中",
                            mask: !0
                        }), !e.detail.iv) return t.hideLoading(), this.$emit("cancelGetPhoneNumber", {
                            sourcePath: this.sourcePath,
                            type: this.type
                        }), void r.showToast("您已经取消登录~");
                        n = {
                            modEncryptedData: e.detail.encryptedData,
                            modIv: e.detail.iv,
                            sortId: t.getStorageSync("categoryInfo").gid || "",
                            chId: t.getStorageSync("webIdInfo").web_id || ""
                        }, (0, s.wxMobRegister)(n, function(e) {
                            switch (parseInt(e.data.status.code)) {
                              case 10001:
                                (0, s.getWxUserInfo)({}, function(e) {
                                    0 == e.data.status.code && (t.setStorageSync(a.default.wxUserInfo, e.data.data), 
                                    t.setStorageSync(a.default.wxAppTokenName, e.data.data.wxAppToken), 0 == o.isTriggerRegister && (r.showToast("登录成功"), 
                                    o.$emit("wxMobRegisterSuccess", {
                                        sourcePath: o.sourcePath,
                                        type: o.type
                                    }), o.isTriggerRegister = 1));
                                }), t.setStorageSync("wxUserInfo", e.data.data), t.setStorageSync("wxAppToken", e.data.data.wxAppToken), 
                                t.setStorageSync("wxAppTokenTimeStamp", new Date().getTime());
                                break;

                              case 10002:
                                o.phone = e.data.data.phone, o.getSMSCode();
                                break;

                              default:
                                r.showToast("您的手机号无效或不支持国外手机号码！");
                            }
                        });
                    },
                    getSMSCode: function() {
                        var e = this, n = this.phone.substr(0, 3) + "****" + this.phone.substr(-4);
                        this.hideVerifyLayer = !1, this.missingPhone = n, this.abletoSendCode && (t.showLoading({
                            title: "验证码获取中...",
                            mask: !0
                        }), (0, s.getSMSCode)({
                            phone: this.phone
                        }, function(t) {
                            switch (t.data.status.code) {
                              case 0:
                                r.showToast("验证码已发送~"), e.hideVerifyLayer = !1, e.countDown();
                                break;

                              default:
                                r.showToast(t.data.status.msg), e.hideVerifyLayer = !0;
                            }
                        }));
                    },
                    countDown: function() {
                        var e = this;
                        this.timer = setInterval(function() {
                            e.interval--, e.abletoSendCode = !1, e.verifyMsg = "(" + e.interval + "s)重新获取", 
                            0 == e.interval && (clearInterval(e.timer), e.abletoSendCode = !0, e.interval = 60, 
                            e.verifyMsg = "重新获取");
                        }, 1e3);
                    },
                    autoNext: function(e) {
                        this.smsCode = e.detail.value, this.smsCode.length > 5 && this.submitLogin();
                    },
                    submitLogin: function() {
                        var e = this;
                        1 != this.isTriggerLogin && (this.isTriggerLogin = 1, t.showLoading(), (0, s.login)({
                            isBind: 1,
                            name: this.phone || "",
                            pwd: "",
                            smsCode: this.smsCode,
                            sortId: this.gid
                        }, function(n) {
                            t.hideLoading(), e.hideVerifyLayer = !0, r.showToast("登录成功"), t.setStorageSync("hqUserInfo", n.data.data), 
                            t.setStorageSync(a.default.tokenKey, n.data.data.token), t.setStorageSync(a.default.tokenTimeStamp, new Date().getTime()), 
                            e.$emit("submitLoginSuccess", {
                                sourcePath: e.sourcePath,
                                type: e.type
                            });
                        }, function() {
                            t.hideLoading(), showToast(res.data.status.msg);
                        }, function(n) {
                            t.hideLoading(), showToast(n.data.status.msg), clearInterval(e.timer), e.abletoSendCode = !0, 
                            e.interval = 60, e.isTriggerLogin = 0, e.smsCode = "", e.verifyMsg = "重新获取";
                        }));
                    },
                    closeVerifyLayer: function() {
                        this.hideVerifyLayer = !0;
                    }
                }
            };
            n.default = d;
        }).call(this, o(1).default);
    },
    379: function(e, t, n) {
        n.r(t);
        var o = n(380), i = n.n(o);
        for (var a in o) "default" !== a && function(e) {
            n.d(t, e, function() {
                return o[e];
            });
        }(a);
        t.default = i.a;
    },
    380: function(e, t, n) {}
} ]), (global.webpackJsonp = global.webpackJsonp || []).push([ "components/c-wx-login/c-wx-login-create-component", {
    "components/c-wx-login/c-wx-login-create-component": function(e, t, n) {
        n("1").createComponent(n(374));
    }
}, [ [ "components/c-wx-login/c-wx-login-create-component" ] ] ]);