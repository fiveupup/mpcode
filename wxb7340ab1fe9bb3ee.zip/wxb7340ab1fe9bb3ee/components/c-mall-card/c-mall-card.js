require("../../uni-bootstrap.js"), (global.webpackJsonp = global.webpackJsonp || []).push([ [ "components/c-mall-card/c-mall-card" ], {
    315: function(e, t, n) {
        n.r(t);
        var i = n(316), a = n(318);
        for (var r in a) "default" !== r && function(e) {
            n.d(t, e, function() {
                return a[e];
            });
        }(r);
        n(323);
        var c = n(10), o = Object(c.default)(a.default, i.render, i.staticRenderFns, !1, null, "4e3d6cf8", null, !1, i.components, void 0);
        o.options.__file = "components/c-mall-card/c-mall-card.vue", t.default = o.exports;
    },
    316: function(e, t, n) {
        n.r(t);
        var i = n(317);
        n.d(t, "render", function() {
            return i.render;
        }), n.d(t, "staticRenderFns", function() {
            return i.staticRenderFns;
        }), n.d(t, "recyclableRender", function() {
            return i.recyclableRender;
        }), n.d(t, "components", function() {
            return i.components;
        });
    },
    317: function(e, t, n) {
        n.r(t), n.d(t, "render", function() {
            return a;
        }), n.d(t, "staticRenderFns", function() {
            return c;
        }), n.d(t, "recyclableRender", function() {
            return r;
        }), n.d(t, "components", function() {
            return i;
        });
        var i = {
            cMallCardAdContent: function() {
                return n.e("components/c-mall-card-ad-content/c-mall-card-ad-content").then(n.bind(null, 430));
            }
        }, a = function() {
            var e = this.$createElement;
            this._self._c;
        }, r = !1, c = [];
        a._withStripped = !0;
    },
    318: function(e, t, n) {
        n.r(t);
        var i = n(319), a = n.n(i);
        for (var r in i) "default" !== r && function(e) {
            n.d(t, e, function() {
                return i[e];
            });
        }(r);
        t.default = a.a;
    },
    319: function(e, t, n) {
        (function(e) {
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = void 0;
            var i, a = (i = n(320)) && i.__esModule ? i : {
                default: i
            }, r = n(22);
            function c(e, t, n, i, a, r, c) {
                try {
                    var o = e[r](c), s = o.value;
                } catch (e) {
                    return void n(e);
                }
                o.done ? t(s) : Promise.resolve(s).then(i, a);
            }
            var o = getApp(), s = {
                components: {
                    cMallCardAdContent: function() {
                        n.e("components/c-mall-card-ad-content/c-mall-card-ad-content").then(function() {
                            return resolve(n(430));
                        }.bind(null, n)).catch(n.oe);
                    }
                },
                props: {
                    list: {
                        type: Array,
                        default: function() {
                            return [];
                        }
                    }
                },
                data: function() {
                    return {
                        newList: [],
                        newListCount: 0,
                        boxHeight: [],
                        isIOS: 1
                    };
                },
                watch: {
                    list: function(e, t) {
                        e != t && this.setData(e);
                    }
                },
                mounted: function() {
                    this.checkOS(), this.mountedData();
                },
                methods: {
                    checkOS: function() {
                        var t = this;
                        e.getSystemInfo({
                            success: function(e) {
                                e.system.indexOf("Android") > -1 && (t.isIOS = 0);
                            }
                        });
                    },
                    mountedData: function() {
                        this.list && 0 != this.list.length && this.setData(this.list);
                    },
                    setData: function(t) {
                        var n = this.newList.length || 0;
                        this.newList = this.newList.concat(t), console.log(188883), this.setMode();
                        var i, r = this.newList.length, o = e.getSystemInfoSync().screenWidth, s = "";
                        this.$nextTick((i = a.default.mark(function t() {
                            var i, c, l, u;
                            return a.default.wrap(function(t) {
                                for (;;) switch (t.prev = t.next) {
                                  case 0:
                                    return i = e.createSelectorQuery().in(this), c = [], t.next = 4, new Promise(function(e, t) {
                                        setTimeout(function() {
                                            i.selectAll(".waterfall-flow .item").fields({
                                                size: !0
                                            }, function(t) {
                                                c = t, e();
                                            }).exec();
                                        }, 1500);
                                    });

                                  case 4:
                                    for (l = n; l < r; l++) l < 2 ? (s = "top: 0; left: ".concat((o / 2 - 8) * l, "px;"), 
                                    this.boxHeight.push(c[l].height)) : (u = this.boxHeight[0]) > this.boxHeight[1] ? (u = this.boxHeight[1], 
                                    this.boxHeight[1] = u + c[l].height + 5, s = "top: ".concat(u + 5, "px; left: ").concat(o / 2 - 8, "px;")) : (this.boxHeight[0] = u + c[l].height + 5, 
                                    s = "top: ".concat(u + 5, "px; left: 0;")), this.$set(this.newList[l], "style", s), 
                                    this.$emit("finishLoad"), this.$forceUpdate();

                                  case 5:
                                  case "end":
                                    return t.stop();
                                }
                            }, t, this);
                        }), function() {
                            var e = this, t = arguments;
                            return new Promise(function(n, a) {
                                var r = i.apply(e, t);
                                function o(e) {
                                    c(r, n, a, o, s, "next", e);
                                }
                                function s(e) {
                                    c(r, n, a, o, s, "throw", e);
                                }
                                o(void 0);
                            });
                        }));
                    },
                    setMode: function() {
                        this.list && 0 != this.list.length && this.list.forEach(function(e, t) {
                            e.type, e.teachers && (e.teachers.length > 3 && (e.teachers = e.teachers.slice(0, 3)), 
                            e.teachers.forEach(function(e, t) {
                                e.name.length > 3 && (e.name = e.name.slice(0, 3) + "...");
                            })), "ad" == e.type && e.tags && (e.tagsArray = e.tags.split(","), e.tagsArray.length > 3 && (e.tagsArray = e.tagsArray.slice(0, 3)), 
                            e.tagsArray.forEach(function(e, t) {
                                e.length > 3 && (e = e.slice(0, 3) + "....");
                            }));
                            var n = e.maxPrice || e.max_price || 0, i = e.maxSalePrice || e.max_sale_price || 0, a = e.minPrice || e.min_price || 0, c = e.minSalePrice || e.min_sale_price || 0;
                            if (n == i && a == c && n == a && 0 == n ? e.mode = 6 : n == i && a == c && n == a ? e.mode = 1 : n == i && a == c && n != a ? e.mode = 2 : n == i && a == c || n != a ? n == i && a == c || n == a || (e.mode = 4) : e.mode = 3, 
                            e.limit && e.limit <= (e.buyer_count || 0) + (e.bought_count || 0) && (e.mode = 5), 
                            e.maxo = n, e.mino = a, e.maxn = i, e.minn = c, e.banner_title || "ad" == e.type || (e.sellPoint && e.sellPoint.length ? e.banner_title = e.sellPoint : e.banner_title = [ e.name.slice(0, 11) ]), 
                            "string" == typeof e.banner_title && (e.banner_title = e.banner_title.split(" ")), 
                            !(e.image || e.bigPic || e.big_pic || e.teacher_banner)) {
                                var o = t % 10;
                                e.defalut_banner = "https://oss-hqwx-edu24ol.hqwx.com/miniapp/hq_mall/banner_default_".concat(o, ".png");
                            }
                            (e.activityEndTime > 0 || e.activity_end_time > 0) && (e.activityEndTimeCount = (0, 
                            r.countTime)(e.activityEndTime || e.activity_end_time)), !e.memberDiscount || 5 == e.mode && 6 == e.mode || e.minMemberPrice <= e.minn && (e.minMemberPrice != e.maxMemberPrice && (e.duozhi = 1), 
                            e.isShowMemberPrice = 1);
                        });
                    },
                    choose: function(e) {
                        var t = e.currentTarget.dataset.index;
                        this.$emit("click", this.newList[t]);
                    },
                    navigateToMiniProgram: function(t) {
                        var n = t.currentTarget.dataset, i = n.title, a = n.gid, r = n.appid, c = n.path, s = e.getStorageSync("onCategoryInfo") || e.getStorageSync("categoryInfo"), l = s.gid, u = s.gname, d = e.getStorageSync("webIdInfo").web_id || "";
                        o.sensors.track("clickBanner", {
                            belongPage: "商城首页",
                            examinationID: a,
                            belongBlock: "推荐广告位",
                            bannerName: i,
                            targetUrl: c,
                            bannerNum: ""
                        }), "wxb7340ab1fe9bb3ee" != r ? e.navigateToMiniProgram({
                            appId: r,
                            path: c + "?gid=" + l + "&gname=" + u + "&web_id=" + d,
                            extraData: {
                                gid: l,
                                gname: u,
                                web_id: d
                            },
                            success: function() {
                                console.log(c + "?gid=" + l + "&gname=" + u + "&web_id=" + d);
                            }
                        }) : e.navigateTo({
                            url: "/" + c
                        });
                    },
                    navigateExtUrl: function(t) {
                        var n = t.currentTarget.dataset.url;
                        (0, r.thirdAgrement)(n) || e.navigateTo({
                            url: "/pages/webview/webview?url=" + encodeURIComponent(n)
                        });
                    }
                }
            };
            t.default = s;
        }).call(this, n(1).default);
    },
    323: function(e, t, n) {
        n.r(t);
        var i = n(324), a = n.n(i);
        for (var r in i) "default" !== r && function(e) {
            n.d(t, e, function() {
                return i[e];
            });
        }(r);
        t.default = a.a;
    },
    324: function(e, t, n) {}
} ]), (global.webpackJsonp = global.webpackJsonp || []).push([ "components/c-mall-card/c-mall-card-create-component", {
    "components/c-mall-card/c-mall-card-create-component": function(e, t, n) {
        n("1").createComponent(n(315));
    }
}, [ [ "components/c-mall-card/c-mall-card-create-component" ] ] ]);