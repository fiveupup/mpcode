require("../../uni-bootstrap.js"), (global.webpackJsonp = global.webpackJsonp || []).push([ [ "components/c-detail-code/c-detail-code" ], {
    381: function(t, e, i) {
        i.r(e);
        var n = i(382), c = i(384);
        for (var a in c) "default" !== a && function(t) {
            i.d(e, t, function() {
                return c[t];
            });
        }(a);
        i(386);
        var s = i(10), o = Object(s.default)(c.default, n.render, n.staticRenderFns, !1, null, "40e76984", null, !1, n.components, void 0);
        o.options.__file = "components/c-detail-code/c-detail-code.vue", e.default = o.exports;
    },
    382: function(t, e, i) {
        i.r(e);
        var n = i(383);
        i.d(e, "render", function() {
            return n.render;
        }), i.d(e, "staticRenderFns", function() {
            return n.staticRenderFns;
        }), i.d(e, "recyclableRender", function() {
            return n.recyclableRender;
        }), i.d(e, "components", function() {
            return n.components;
        });
    },
    383: function(t, e, i) {
        i.r(e), i.d(e, "render", function() {
            return n;
        }), i.d(e, "staticRenderFns", function() {
            return a;
        }), i.d(e, "recyclableRender", function() {
            return c;
        }), i.d(e, "components", function() {});
        var n = function() {
            var t = this, e = t.$createElement;
            t._self._c;
            t._isMounted || (t.e0 = function(e) {
                t.isShow = !1;
            });
        }, c = !1, a = [];
        n._withStripped = !0;
    },
    384: function(t, e, i) {
        i.r(e);
        var n = i(385), c = i.n(n);
        for (var a in n) "default" !== a && function(t) {
            i.d(e, t, function() {
                return n[t];
            });
        }(a);
        e.default = c.a;
    },
    385: function(t, e, i) {
        (function(t) {
            Object.defineProperty(e, "__esModule", {
                value: !0
            }), e.default = void 0;
            var n = c(i(20));
            c(i(22));
            function c(t) {
                return t && t.__esModule ? t : {
                    default: t
                };
            }
            var a = i(24)("./config_" + n.default.appName).default, s = {
                props: {
                    noData: {
                        type: [ Boolean ],
                        default: !1
                    },
                    noMore: {
                        type: [ Boolean ],
                        default: !1
                    },
                    loading: {
                        type: [ Boolean ],
                        default: !1
                    }
                },
                data: function() {
                    return {
                        isShow: !1,
                        canvasStyle: "",
                        scale: 1
                    };
                },
                computed: {},
                created: function() {},
                mounted: function() {},
                methods: {
                    createCourseCode: function(e) {
                        var i = this;
                        this.initCanvas(), this.isShow = !0, this.designScale = 1.5, t.showLoading({
                            title: "加载中...",
                            mask: !0
                        }), setTimeout(function() {
                            t.hideLoading();
                        }, 8e3), this.loadImg({
                            url: "https://oss-hqwx-edu24ol.hqwx.com/miniapp/hq_live/courseDetail/course_detail_code.png",
                            left: 0,
                            top: 0,
                            width: 750,
                            height: 1334
                        }, function() {
                            if (i.ctx.textBaseline = "top", i.fillText(e.teacherName, 34, "#333333", 155, 53, "bold "), 
                            i.fillText(e.des, 28, "#333333", 155, 100), i.fillRect(), i.loadImg({
                                url: e.teacherPic.replace("http://", "https://"),
                                left: 40,
                                top: 40,
                                width: 100,
                                circle: !0
                            }, function() {
                                i.loadImg({
                                    url: e.pic.replace("http://", "https://"),
                                    left: 55,
                                    top: 177,
                                    width: 640,
                                    height: 640
                                }, function() {
                                    var c = encodeURIComponent(e.urlParams), s = 1 * new Date();
                                    i.loadImg({
                                        url: "https://kjapi.98809.com/weixin/v1/interface/getwxacodeunlimit?_appid=".concat(a.appid, "&_v=").concat(a.version, "&_t=").concat(s, "&platform=").concat(n.default.platform, "&org_id=").concat(a.orgId, "&mp=").concat(a.appid, "&page=").concat("pages/courseDetail/courseDetail", "&width=").concat(430, "&scene=").concat(c),
                                        left: 528,
                                        top: 1110,
                                        width: 164,
                                        height: 164
                                    }, function() {
                                        t.hideLoading();
                                    });
                                });
                            }), i.wrapText(e.title, 37, "#171717", 16, 2, 855, 69), i.wrapText(e.name, 24, "#666666", 18, 1, 1002, 70), 
                            e.isLow) {
                                i.ctx.textAlign = "right", i.fillText(e.price, 44, "#202A31", 680, 989);
                                var c = 602 - 33 * e.price.length;
                                i.roundRect(c, 994, 78, 30, 5, "#DC1E00"), i.ctx.textAlign = "left", i.fillText("抢购价", 24, "#ffffff", c + 3, 998);
                            } else i.ctx.textAlign = "right", i.roundRect(430, 994, 250, 38, 5, "#196EFF"), 
                            i.wrapText(e.recommend, 24, "#ffffff", 10, 1, 1002, 665);
                        });
                    },
                    wrapText: function(t, e, i) {
                        var n = arguments.length > 3 && void 0 !== arguments[3] ? arguments[3] : 15, c = arguments.length > 4 && void 0 !== arguments[4] ? arguments[4] : 2, a = arguments.length > 5 && void 0 !== arguments[5] ? arguments[5] : 60, s = arguments.length > 6 && void 0 !== arguments[6] ? arguments[6] : 0, o = arguments.length > 7 && void 0 !== arguments[7] ? arguments[7] : "";
                        if (e = e / this.designScale * this.scale, a = a / this.designScale * this.scale, 
                        this.ctx.font = o + e + "px Arial", this.ctx.fillStyle = i, t.length > n * c && (t = t.substring(0, n * c - 1) + "..."), 
                        1 != c) for (var l = 0; l < c; l++) {
                            var d = a + l * (e + e / 3), h = (l + 1) * n;
                            1 == l && (h += 2), this.ctx.fillText(t.substring(l * n, h), s / this.designScale * this.scale, d);
                        } else this.ctx.fillText(t, s / this.designScale * this.scale, a);
                    },
                    loadImg: function() {
                        var e = this, i = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {}, n = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : function() {};
                        t.downloadFile({
                            url: i.url,
                            success: function(t) {
                                var c = e.canvas.createImage();
                                c.src = t.tempFilePath, c.onload = function() {
                                    i.circle ? e.circleImg(e.ctx, c, i.left / e.designScale * e.scale, i.top / e.designScale * e.scale, i.width / e.designScale * e.scale / 2) : e.ctx.drawImage(c, i.left / e.designScale * e.scale, i.top / e.designScale * e.scale, i.width / e.designScale * e.scale, i.height / e.designScale * e.scale), 
                                    n();
                                };
                            }
                        });
                    },
                    fillText: function(t, e, i, n, c) {
                        var a = arguments.length > 5 && void 0 !== arguments[5] ? arguments[5] : "";
                        this.ctx.font = a + e / this.designScale * this.scale + "px Arial", this.ctx.fillStyle = i, 
                        this.ctx.fillText(t, n / this.designScale * this.scale, c / this.designScale * this.scale);
                    },
                    fillRect: function() {
                        var t = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : "#ffffff", e = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : 40, i = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : 162, n = arguments.length > 3 && void 0 !== arguments[3] ? arguments[3] : 670, c = arguments.length > 4 && void 0 !== arguments[4] ? arguments[4] : 900;
                        this.ctx.fillStyle = t, this.ctx.shadow = (this.designScale, this.scale, this.designScale, 
                        this.scale, this.designScale, this.scale, "rgba(0,0,0,0.1)"), this.ctx.fillRect(e / this.designScale * this.scale, i / this.designScale * this.scale, n / this.designScale * this.scale, c / this.designScale * this.scale);
                    },
                    fillRect2: function() {
                        var t = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : "#ffffff", e = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : 30, i = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : 870, n = arguments.length > 3 && void 0 !== arguments[3] ? arguments[3] : 690, c = arguments.length > 4 && void 0 !== arguments[4] ? arguments[4] : 192;
                        this.ctx.fillStyle = t, this.ctx.fillRect(e / this.designScale * this.scale, i / this.designScale * this.scale, n / this.designScale * this.scale, c / this.designScale * this.scale);
                    },
                    circleImg: function(t, e, i, n, c) {
                        t.save();
                        var a = 2 * c, s = i + c, o = n + c;
                        t.arc(s, o, c, 0, 2 * Math.PI), t.clip(), t.drawImage(e, i, n, a, a), t.restore();
                    },
                    roundRect: function(t, e, i, n, c, a) {
                        t = t / this.designScale * this.scale, e = e / this.designScale * this.scale, i = i / this.designScale * this.scale, 
                        n = n / this.designScale * this.scale, i < 2 * (c = c / this.designScale * this.scale) && (c = i / 2), 
                        n < 2 * c && (c = n / 2), this.ctx.beginPath(), this.ctx.moveTo(t + c, e), this.ctx.arcTo(t + i, e, t + i, e + n, c), 
                        this.ctx.arcTo(t + i, e + n, t, e + n, c), this.ctx.arcTo(t, e + n, t, e, c), this.ctx.arcTo(t, e, t + i, e, c), 
                        this.ctx.fillStyle = a, this.ctx.closePath(), this.ctx.fill();
                    },
                    createImg: function() {
                        var e = this;
                        t.showToast({
                            title: "图片保存中...",
                            mask: !0,
                            icon: "none"
                        });
                        var i = this.canvasW * Math.ceil(this.systemInfo.pixelRatio), n = this.canvasH * Math.ceil(this.systemInfo.pixelRatio);
                        t.canvasToTempFilePath({
                            x: 0,
                            y: 0,
                            width: i,
                            height: n,
                            destWidth: i,
                            destHeight: n,
                            canvas: this.canvas,
                            success: function(t) {
                                e.saveImg(t.tempFilePath);
                            },
                            fail: function(t) {
                                console.log(t);
                            }
                        }, this);
                    },
                    saveImg: function(e) {
                        t.authorize({
                            scope: "scope.writePhotosAlbum",
                            success: function() {
                                t.saveImageToPhotosAlbum({
                                    filePath: e,
                                    success: function(e) {
                                        t.showToast({
                                            icon: "none",
                                            title: "图片保存成功"
                                        });
                                    },
                                    fail: function(e) {
                                        t.hideToast();
                                    }
                                });
                            },
                            fail: function() {
                                t.showModal({
                                    title: "保存失败",
                                    content: "若不打开授权，无法将图片保存在相册中！",
                                    showCancel: !0,
                                    cancelText: "知道了",
                                    confirmText: "去授权",
                                    success: function(e) {
                                        e.confirm && t.openSetting({
                                            success: function(t) {
                                                t.authSetting = {
                                                    "scope.writePhotosAlbum": !0
                                                };
                                            }
                                        });
                                    }
                                });
                            }
                        });
                    },
                    initCanvas: function() {
                        var e = this;
                        t.createSelectorQuery().in(this).select("#mainImg").fields({
                            node: !0,
                            size: !0
                        }).exec(function(i) {
                            e.canvas = i[0].node, e.ctx = e.canvas.getContext("2d"), e.systemInfo = t.getSystemInfoSync(), 
                            e.scale = e.systemInfo.screenWidth / 750, e.canvasW = 500 * e.scale, e.canvasH = 890 * e.scale, 
                            e.canvas.width = e.canvasW * e.systemInfo.pixelRatio, e.canvas.height = e.canvasH * e.systemInfo.pixelRatio, 
                            e.ctx.scale(e.systemInfo.pixelRatio, e.systemInfo.pixelRatio), e.canvasStyle = "width:".concat(e.canvasW, "px;height:").concat(e.canvasH, "px;");
                        });
                    }
                }
            };
            e.default = s;
        }).call(this, i(1).default);
    },
    386: function(t, e, i) {
        i.r(e);
        var n = i(387), c = i.n(n);
        for (var a in n) "default" !== a && function(t) {
            i.d(e, t, function() {
                return n[t];
            });
        }(a);
        e.default = c.a;
    },
    387: function(t, e, i) {}
} ]), (global.webpackJsonp = global.webpackJsonp || []).push([ "components/c-detail-code/c-detail-code-create-component", {
    "components/c-detail-code/c-detail-code-create-component": function(t, e, i) {
        i("1").createComponent(i(381));
    }
}, [ [ "components/c-detail-code/c-detail-code-create-component" ] ] ]);