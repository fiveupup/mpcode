require("../../uni-bootstrap.js"), (global.webpackJsonp = global.webpackJsonp || []).push([ [ "components/c-icon/c-icon" ], {
    346: function(n, e, t) {
        t.r(e);
        var o = t(347), i = t(349);
        for (var a in i) "default" !== a && function(n) {
            t.d(e, n, function() {
                return i[n];
            });
        }(a);
        t(351);
        var c = t(10), r = Object(c.default)(i.default, o.render, o.staticRenderFns, !1, null, "c4409a38", null, !1, o.components, void 0);
        r.options.__file = "components/c-icon/c-icon.vue", e.default = r.exports;
    },
    347: function(n, e, t) {
        t.r(e);
        var o = t(348);
        t.d(e, "render", function() {
            return o.render;
        }), t.d(e, "staticRenderFns", function() {
            return o.staticRenderFns;
        }), t.d(e, "recyclableRender", function() {
            return o.recyclableRender;
        }), t.d(e, "components", function() {
            return o.components;
        });
    },
    348: function(n, e, t) {
        t.r(e), t.d(e, "render", function() {
            return o;
        }), t.d(e, "staticRenderFns", function() {
            return a;
        }), t.d(e, "recyclableRender", function() {
            return i;
        }), t.d(e, "components", function() {});
        var o = function() {
            var n = this.$createElement;
            this._self._c;
        }, i = !1, a = [];
        o._withStripped = !0;
    },
    349: function(n, e, t) {
        t.r(e);
        var o = t(350), i = t.n(o);
        for (var a in o) "default" !== a && function(n) {
            t.d(e, n, function() {
                return o[n];
            });
        }(a);
        e.default = i.a;
    },
    350: function(n, e, t) {
        (function(n) {
            Object.defineProperty(e, "__esModule", {
                value: !0
            }), e.default = void 0;
            var o = t(21), i = t(22), a = getApp(), c = {
                props: {
                    grayLevel: {
                        type: Boolean
                    },
                    position: {
                        type: Number
                    },
                    gid: {
                        type: Number
                    },
                    gname: {
                        type: String
                    },
                    isShow: {
                        type: Boolean,
                        default: !1
                    }
                },
                watch: {
                    isShow: {
                        handler: function(n) {
                            this.isShowIcon = n, n && this.getIconsDatas();
                        },
                        immediate: !0
                    },
                    gid: {
                        handler: function(n) {
                            this.getIconsDatas();
                        }
                    }
                },
                data: function() {
                    return {
                        iconData: "",
                        isShowIcon: !1
                    };
                },
                mounted: function() {
                    this.isShow;
                },
                methods: {
                    getIconsDatas: function() {
                        var n = this;
                        if (this.gid) {
                            var e = {
                                position: this.position,
                                secondCategory: this.gid
                            };
                            (0, o.getIconsDatas)(e, function(e) {
                                if (0 == e.data.status.code) {
                                    var t = e.data.data;
                                    t.images = (0, i.replaceOss)(t.images), n.iconData = t;
                                }
                            });
                        }
                    },
                    click: function(n) {
                        var e = n.currentTarget.dataset, t = e.url, o = e.type, c = e.appid, r = e.path;
                        (0, i.reportEvent)(a, "clickBanner", {
                            belongPage: "商城首页",
                            examinationID: (this.gid || 0) + "",
                            belongBlock: "浮标",
                            bannerName: e.title
                        }), 2 == o ? this.navigateToMiniProgram(c, r) : 3 == o && this.navigateExtUrl(t);
                    },
                    navigateToMiniProgram: function(e, t) {
                        var o = this.gid, i = this.gname, a = n.getStorageSync("webIdInfo").web_id;
                        "wxb7340ab1fe9bb3ee" != e ? n.navigateToMiniProgram({
                            appId: e,
                            path: t + "?gid=" + o + "&gname=" + i + "&web_id=" + a,
                            extraData: {
                                gid: o,
                                gname: i,
                                web_id: a
                            },
                            success: function() {
                                console.log(e, o, i, a);
                            }
                        }) : n.navigateTo({
                            url: "/" + t + "?sourcePath=index"
                        });
                    },
                    navigateExtUrl: function(e) {
                        n.navigateTo({
                            url: "/pages/webview/webview?url=" + encodeURIComponent(e)
                        });
                    }
                }
            };
            e.default = c;
        }).call(this, t(1).default);
    },
    351: function(n, e, t) {
        t.r(e);
        var o = t(352), i = t.n(o);
        for (var a in o) "default" !== a && function(n) {
            t.d(e, n, function() {
                return o[n];
            });
        }(a);
        e.default = i.a;
    },
    352: function(n, e, t) {}
} ]), (global.webpackJsonp = global.webpackJsonp || []).push([ "components/c-icon/c-icon-create-component", {
    "components/c-icon/c-icon-create-component": function(n, e, t) {
        t("1").createComponent(t(346));
    }
}, [ [ "components/c-icon/c-icon-create-component" ] ] ]);