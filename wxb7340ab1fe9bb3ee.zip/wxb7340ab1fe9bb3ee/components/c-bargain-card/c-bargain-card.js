require("../../uni-bootstrap.js"), (global.webpackJsonp = global.webpackJsonp || []).push([ [ "components/c-bargain-card/c-bargain-card" ], {
    294: function(t, n, e) {
        e.r(n);
        var a = e(295), i = e(297);
        for (var r in i) "default" !== r && function(t) {
            e.d(n, t, function() {
                return i[t];
            });
        }(r);
        e(299);
        var c = e(10), o = Object(c.default)(i.default, a.render, a.staticRenderFns, !1, null, "28ff7aa4", null, !1, a.components, void 0);
        o.options.__file = "components/c-bargain-card/c-bargain-card.vue", n.default = o.exports;
    },
    295: function(t, n, e) {
        e.r(n);
        var a = e(296);
        e.d(n, "render", function() {
            return a.render;
        }), e.d(n, "staticRenderFns", function() {
            return a.staticRenderFns;
        }), e.d(n, "recyclableRender", function() {
            return a.recyclableRender;
        }), e.d(n, "components", function() {
            return a.components;
        });
    },
    296: function(t, n, e) {
        e.r(n), e.d(n, "render", function() {
            return a;
        }), e.d(n, "staticRenderFns", function() {
            return r;
        }), e.d(n, "recyclableRender", function() {
            return i;
        }), e.d(n, "components", function() {});
        var a = function() {
            var t = this.$createElement;
            this._self._c;
        }, i = !1, r = [];
        a._withStripped = !0;
    },
    297: function(t, n, e) {
        e.r(n);
        var a = e(298), i = e.n(a);
        for (var r in a) "default" !== r && function(t) {
            e.d(n, t, function() {
                return a[t];
            });
        }(r);
        n.default = i.a;
    },
    298: function(t, n, e) {
        (function(t) {
            Object.defineProperty(n, "__esModule", {
                value: !0
            }), n.default = void 0;
            e(21);
            var a = e(22), i = (getApp(), {
                props: {
                    list: {
                        type: Array
                    }
                },
                watch: {
                    list: function(t) {
                        this.setStatusMode();
                    }
                },
                data: function() {
                    return {
                        uid: 0,
                        viewList: []
                    };
                },
                mounted: function() {
                    this.uid = t.getStorageSync("hqUserInfo") ? t.getStorageSync("hqUserInfo").uid : 0, 
                    this.setStatusMode();
                },
                methods: {
                    setStatusMode: function() {
                        var n = this;
                        if (this.list && 0 != this.list.length) {
                            var e = 0, i = null, r = "", c = this.list;
                            c.forEach(function(c, o) {
                                if (4 == (e = t.getStorageSync("hq_token") ? 0 == c.activity.status ? 1 : 1 == c.share_activity.is_finished ? 2 : 0 == c.share_activity.create_time ? 3 : new Date().getTime() - 1e3 * c.share_activity.create_time < 1728e5 ? 4 : 5 : 0) && (i = (0, 
                                a.countTime)(c.share_activity.create_time, 1), c.activity.time = i), r = c.share_activity.zug_id > 0 ? "?zug_id=" + c.share_activity.zug_id : "?zg_id=" + c.activity.id + "&uid=" + n.uid, 
                                c.activity.banner_title || (c.activity.banner_title = c.activity.good_name.slice(0, 11)), 
                                !c.activity.teacher_banner) {
                                    var u = o % 10;
                                    c.activity.defalut_banner = "https://oss-hqwx-edu24ol.hqwx.com/miniapp/hq_mall/banner_default_".concat(u, ".png");
                                }
                                c.activity.mode = e, c.activity.args = r;
                            }), this.viewList = c, this.sortActivityData();
                        }
                    },
                    sortActivityData: function() {
                        var t = [], n = [], e = [], a = [];
                        this.viewList.forEach(function(a, i) {
                            2 == a.activity.mode ? n.push(a) : 4 == a.activity.mode ? t.push(a) : e.push(a);
                        }), a = (a = t.concat(n)).concat(e), this.viewList = a;
                    },
                    goLogin: function(t) {
                        t.currentTarget.dataset;
                    },
                    goBargainDetail: function(n) {
                        var e = "/pages/bargainDetail/bargainDetail";
                        e += n.currentTarget.dataset.args, t.navigateTo({
                            url: e
                        });
                    }
                }
            });
            n.default = i;
        }).call(this, e(1).default);
    },
    299: function(t, n, e) {
        e.r(n);
        var a = e(300), i = e.n(a);
        for (var r in a) "default" !== r && function(t) {
            e.d(n, t, function() {
                return a[t];
            });
        }(r);
        n.default = i.a;
    },
    300: function(t, n, e) {}
} ]), (global.webpackJsonp = global.webpackJsonp || []).push([ "components/c-bargain-card/c-bargain-card-create-component", {
    "components/c-bargain-card/c-bargain-card-create-component": function(t, n, e) {
        e("1").createComponent(e(294));
    }
}, [ [ "components/c-bargain-card/c-bargain-card-create-component" ] ] ]);