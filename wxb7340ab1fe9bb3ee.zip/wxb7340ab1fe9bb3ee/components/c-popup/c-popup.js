require("../../uni-bootstrap.js"), (global.webpackJsonp = global.webpackJsonp || []).push([ [ "components/c-popup/c-popup" ], {
    339: function(t, n, e) {
        e.r(n);
        var o = e(340), a = e(342);
        for (var c in a) "default" !== c && function(t) {
            e.d(n, t, function() {
                return a[t];
            });
        }(c);
        e(344);
        var i = e(10), r = Object(i.default)(a.default, o.render, o.staticRenderFns, !1, null, "f9544cec", null, !1, o.components, void 0);
        r.options.__file = "components/c-popup/c-popup.vue", n.default = r.exports;
    },
    340: function(t, n, e) {
        e.r(n);
        var o = e(341);
        e.d(n, "render", function() {
            return o.render;
        }), e.d(n, "staticRenderFns", function() {
            return o.staticRenderFns;
        }), e.d(n, "recyclableRender", function() {
            return o.recyclableRender;
        }), e.d(n, "components", function() {
            return o.components;
        });
    },
    341: function(t, n, e) {
        e.r(n), e.d(n, "render", function() {
            return o;
        }), e.d(n, "staticRenderFns", function() {
            return c;
        }), e.d(n, "recyclableRender", function() {
            return a;
        }), e.d(n, "components", function() {});
        var o = function() {
            var t = this.$createElement;
            this._self._c;
        }, a = !1, c = [];
        o._withStripped = !0;
    },
    342: function(t, n, e) {
        e.r(n);
        var o = e(343), a = e.n(o);
        for (var c in o) "default" !== c && function(t) {
            e.d(n, t, function() {
                return o[t];
            });
        }(c);
        n.default = a.a;
    },
    343: function(t, n, e) {
        (function(t) {
            Object.defineProperty(n, "__esModule", {
                value: !0
            }), n.default = void 0;
            var o = e(21), a = e(22), c = getApp(), i = {
                props: {
                    grayLevel: {
                        type: Boolean
                    },
                    position: {
                        type: Number
                    },
                    gid: {
                        type: Number
                    }
                },
                data: function() {
                    return {
                        popupData: ""
                    };
                },
                mounted: function() {
                    this.checkPopupsDatas();
                },
                watch: {
                    gid: function(t, n) {
                        t != n && this.checkPopupsDatas();
                    }
                },
                methods: {
                    checkPopupsDatas: function() {
                        1 == this.position && t.getStorageSync("ad_".concat(this.gid)) || this.getPopupsDatas();
                    },
                    getPopupsDatas: function() {
                        var n = this;
                        if (this.gid) {
                            var e = {
                                secondCategory: this.gid,
                                position: this.position
                            };
                            (0, o.getPopupsDatas)(e, function(e) {
                                var o = "ad_".concat(n.gid);
                                if (0 == e.data.status.code) {
                                    var c = e.data.data;
                                    c.images = (0, a.replaceOss)(c.images), 1 == n.position && (n.popupData = c);
                                }
                                t.setStorageSync(o, new Date());
                            });
                        }
                    },
                    navigateToMiniProgram: function(n) {
                        var e = n.currentTarget.dataset, o = e.appid, a = e.path, c = t.getStorageSync("onCategoryInfo") || t.getStorageSync("categoryInfo"), i = c.gid, r = c.gname, p = t.getStorageSync("webIdInfo").web_id || "";
                        this.scEvent(n), this.popupData = "", "wxb7340ab1fe9bb3ee" != o ? t.navigateToMiniProgram({
                            appId: o,
                            path: a + "?gid=" + i + "&gname=" + r + "&web_id=" + p,
                            extraData: {
                                gid: i,
                                gname: r,
                                web_id: p
                            },
                            success: function() {
                                console.log(a, i, r, p);
                            }
                        }) : t.navigateTo({
                            url: "/" + a
                        });
                    },
                    navigateExtUrl: function(n) {
                        var e = n.currentTarget.dataset.url;
                        this.scEvent(n), t.navigateTo({
                            url: "/pages/webview/webview?url=" + encodeURIComponent(e)
                        }), this.popupData = "";
                    },
                    closeDialog: function() {
                        this.popupData = "";
                    },
                    kefu: function(t) {
                        this.scEvent(t);
                    },
                    scEvent: function(n) {
                        var e = n.currentTarget.dataset.title, o = t.getStorageSync("categoryInfo"), i = 1 == this.position ? "商城首页" : "商城频道页";
                        (0, a.reportEvent)(c, "clickBanner", {
                            belongPage: i,
                            examinationID: o.gid + "",
                            belongBlock: "弹窗",
                            bannerName: e
                        });
                    }
                }
            };
            n.default = i;
        }).call(this, e(1).default);
    },
    344: function(t, n, e) {
        e.r(n);
        var o = e(345), a = e.n(o);
        for (var c in o) "default" !== c && function(t) {
            e.d(n, t, function() {
                return o[t];
            });
        }(c);
        n.default = a.a;
    },
    345: function(t, n, e) {}
} ]), (global.webpackJsonp = global.webpackJsonp || []).push([ "components/c-popup/c-popup-create-component", {
    "components/c-popup/c-popup-create-component": function(t, n, e) {
        e("1").createComponent(e(339));
    }
}, [ [ "components/c-popup/c-popup-create-component" ] ] ]);