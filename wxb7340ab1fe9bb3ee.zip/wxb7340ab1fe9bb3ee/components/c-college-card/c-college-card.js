require("../../uni-bootstrap.js"), (global.webpackJsonp = global.webpackJsonp || []).push([ [ "components/c-college-card/c-college-card" ], {
    367: function(e, t, n) {
        n.r(t);
        var o = n(368), c = n(370);
        for (var r in c) "default" !== r && function(e) {
            n.d(t, e, function() {
                return c[e];
            });
        }(r);
        n(372);
        var i = n(10), a = Object(i.default)(c.default, o.render, o.staticRenderFns, !1, null, "7276bd78", null, !1, o.components, void 0);
        a.options.__file = "components/c-college-card/c-college-card.vue", t.default = a.exports;
    },
    368: function(e, t, n) {
        n.r(t);
        var o = n(369);
        n.d(t, "render", function() {
            return o.render;
        }), n.d(t, "staticRenderFns", function() {
            return o.staticRenderFns;
        }), n.d(t, "recyclableRender", function() {
            return o.recyclableRender;
        }), n.d(t, "components", function() {
            return o.components;
        });
    },
    369: function(e, t, n) {
        n.r(t), n.d(t, "render", function() {
            return o;
        }), n.d(t, "staticRenderFns", function() {
            return r;
        }), n.d(t, "recyclableRender", function() {
            return c;
        }), n.d(t, "components", function() {});
        var o = function() {
            var e = this.$createElement;
            this._self._c;
        }, c = !1, r = [];
        o._withStripped = !0;
    },
    370: function(e, t, n) {
        n.r(t);
        var o = n(371), c = n.n(o);
        for (var r in o) "default" !== r && function(e) {
            n.d(t, e, function() {
                return o[e];
            });
        }(r);
        t.default = c.a;
    },
    371: function(e, t, n) {
        (function(e) {
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = void 0;
            var o, c = (o = n(320)) && o.__esModule ? o : {
                default: o
            }, r = n(21);
            function i(e, t, n, o, c, r, i) {
                try {
                    var a = e[r](i), s = a.value;
                } catch (e) {
                    return void n(e);
                }
                a.done ? t(s) : Promise.resolve(s).then(o, c);
            }
            getApp();
            var a = {
                props: {},
                data: function() {
                    return {
                        isIos: 1,
                        boxHeight: [],
                        newList: [],
                        recommendGroupData: []
                    };
                },
                mounted: function() {
                    this.checkOS(), this.getMiniappRecommendGroup();
                },
                methods: {
                    checkOS: function() {
                        var t = this;
                        e.getSystemInfo({
                            success: function(e) {
                                e.system.indexOf("Android") > -1 && (t.isIos = 0);
                            }
                        });
                    },
                    getMiniappRecommendGroup: function() {
                        var t = this;
                        e.showLoading(), (0, r.getMiniappRecommendGroup)({}, function(n) {
                            if (0 == n.data.status.code && n.data.data.length > 0) {
                                var o = n.data.data, c = [];
                                o.forEach(function(e, t) {
                                    !e.course_info && (e.course_info = []), e.course_info.forEach(function(e, n) {
                                        if (c.push(e), !e.big_pic && !e.teacher_banner) {
                                            var o = t % 10;
                                            e.defalut_banner = "https://oss-hqwx-edu24ol.hqwx.com/miniapp/hq_mall/banner_default_".concat(o, ".png");
                                        }
                                    });
                                }), t.recommendGroupData = c, t.setData(), e.hideLoading();
                            }
                        });
                    },
                    setData: function() {
                        this.newList = this.recommendGroupData;
                        this.newList.length;
                        var t, n = this.newList.length, o = e.getSystemInfoSync().screenWidth, r = "";
                        this.$nextTick((t = c.default.mark(function t() {
                            var i, a, s, u;
                            return c.default.wrap(function(t) {
                                for (;;) switch (t.prev = t.next) {
                                  case 0:
                                    return i = e.createSelectorQuery().in(this), a = [], t.next = 4, new Promise(function(e, t) {
                                        setTimeout(function() {
                                            i.selectAll(".waterfall-flow .item").fields({
                                                size: !0
                                            }, function(t) {
                                                a = t, e();
                                            }).exec();
                                        }, 2e3);
                                    });

                                  case 4:
                                    for (s = 0; s < n; s++) s < 2 ? (r = "top: 0; left: ".concat((o / 2 - 8) * s, "px;"), 
                                    this.boxHeight.push(a[s].height)) : (u = this.boxHeight[0]) > this.boxHeight[1] ? (u = this.boxHeight[1], 
                                    this.boxHeight[1] = u + a[s].height + 5, r = "top: ".concat(u + 5, "px; left: ").concat(o / 2 - 8, "px;")) : (this.boxHeight[0] = u + a[s].height + 5, 
                                    r = "top: ".concat(u + 5, "px; left: 0;")), this.$set(this.newList[s], "style", r), 
                                    this.$emit("finishLoad"), this.$forceUpdate();

                                  case 5:
                                  case "end":
                                    return t.stop();
                                }
                            }, t, this);
                        }), function() {
                            var e = this, n = arguments;
                            return new Promise(function(o, c) {
                                var r = t.apply(e, n);
                                function a(e) {
                                    i(r, o, c, a, s, "next", e);
                                }
                                function s(e) {
                                    i(r, o, c, a, s, "throw", e);
                                }
                                a(void 0);
                            });
                        }));
                    },
                    goCourseDetail: function(t) {
                        var n = t.currentTarget.dataset;
                        e.navigateTo({
                            url: "/pages/courseDetail/courseDetail?id=".concat(n.id)
                        });
                    }
                }
            };
            t.default = a;
        }).call(this, n(1).default);
    },
    372: function(e, t, n) {
        n.r(t);
        var o = n(373), c = n.n(o);
        for (var r in o) "default" !== r && function(e) {
            n.d(t, e, function() {
                return o[e];
            });
        }(r);
        t.default = c.a;
    },
    373: function(e, t, n) {}
} ]), (global.webpackJsonp = global.webpackJsonp || []).push([ "components/c-college-card/c-college-card-create-component", {
    "components/c-college-card/c-college-card-create-component": function(e, t, n) {
        n("1").createComponent(n(367));
    }
}, [ [ "components/c-college-card/c-college-card-create-component" ] ] ]);