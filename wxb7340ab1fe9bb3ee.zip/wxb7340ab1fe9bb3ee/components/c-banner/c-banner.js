require("../../uni-bootstrap.js"), (global.webpackJsonp = global.webpackJsonp || []).push([ [ "components/c-banner/c-banner" ], {
    301: function(n, e, t) {
        t.r(e);
        var a = t(302), r = t(304);
        for (var o in r) "default" !== o && function(n) {
            t.d(e, n, function() {
                return r[n];
            });
        }(o);
        t(306);
        var i = t(10), c = Object(i.default)(r.default, a.render, a.staticRenderFns, !1, null, "97cf4a78", null, !1, a.components, void 0);
        c.options.__file = "components/c-banner/c-banner.vue", e.default = c.exports;
    },
    302: function(n, e, t) {
        t.r(e);
        var a = t(303);
        t.d(e, "render", function() {
            return a.render;
        }), t.d(e, "staticRenderFns", function() {
            return a.staticRenderFns;
        }), t.d(e, "recyclableRender", function() {
            return a.recyclableRender;
        }), t.d(e, "components", function() {
            return a.components;
        });
    },
    303: function(n, e, t) {
        t.r(e), t.d(e, "render", function() {
            return a;
        }), t.d(e, "staticRenderFns", function() {
            return o;
        }), t.d(e, "recyclableRender", function() {
            return r;
        }), t.d(e, "components", function() {});
        var a = function() {
            var n = this.$createElement;
            this._self._c;
        }, r = !1, o = [];
        a._withStripped = !0;
    },
    304: function(n, e, t) {
        t.r(e);
        var a = t(305), r = t.n(a);
        for (var o in a) "default" !== o && function(n) {
            t.d(e, n, function() {
                return a[n];
            });
        }(o);
        e.default = r.a;
    },
    305: function(n, e, t) {
        (function(n) {
            Object.defineProperty(e, "__esModule", {
                value: !0
            }), e.default = void 0;
            var a = t(21), r = t(22), o = getApp(), i = {
                props: {
                    position: {
                        type: Number
                    },
                    gid: {
                        type: Number
                    }
                },
                data: function() {
                    return {
                        grayLevel: !1,
                        bannerData: [],
                        current: 0
                    };
                },
                created: function() {
                    if (1 == this.position) {
                        var e = n.getStorageSync("indexBanner");
                        e && e["".concat(this.gid)] && (this.bannerData = e["".concat(this.gid)]), this.getAdvertisingBanner();
                    }
                },
                methods: {
                    getAdvertisingBanner: function() {
                        var e = this, t = {
                            secondCategory: this.gid,
                            position: this.position
                        };
                        (0, a.advertisingBanner)(t, function(t) {
                            if (0 == t.data.status.code) {
                                var a = t.data.data;
                                if (a.forEach(function(n) {
                                    n.images = (0, r.replaceOss)(n.images);
                                }), e.bannerData = a, 1 == e.position) {
                                    var o = "indexBanner", i = n.getStorageSync(o) || {};
                                    i["".concat(e.gid)] = a, n.setStorageSync(o, i);
                                }
                            }
                        });
                    },
                    change: function(n) {
                        this.current = n.detail.current;
                    },
                    navigateToMiniProgram: function(e) {
                        var t = e.currentTarget.dataset, a = t.appid, r = t.path, o = n.getStorageSync("onCategoryInfo") || n.getStorageSync("categoryInfo"), i = o.gid, c = o.gname, u = n.getStorageSync("webIdInfo").web_id || "";
                        this.scEvent(e), "wxb7340ab1fe9bb3ee" != a ? n.navigateToMiniProgram({
                            appId: a,
                            path: r + "?gid=" + i + "&gname=" + c + "&web_id=" + u,
                            extraData: {
                                gid: i,
                                gname: c,
                                web_id: u
                            },
                            success: function() {}
                        }) : n.navigateTo({
                            url: "/" + r
                        });
                    },
                    navigateExtUrl: function(e) {
                        var t = e.currentTarget.dataset.url;
                        (0, r.thirdAgrement)(t) || (this.scEvent(e), n.navigateTo({
                            url: "/pages/webview/webview?url=" + encodeURIComponent(t)
                        }));
                    },
                    scEvent: function(n) {
                        var e = n.currentTarget.dataset.title, t = 1 == this.position ? "商城首页" : "商城频道页";
                        (0, r.reportEvent)(o, "clickBanner", {
                            belongPage: t,
                            examinationID: this.gid + "",
                            belongBlock: "banner",
                            bannerName: e
                        });
                    }
                }
            };
            e.default = i;
        }).call(this, t(1).default);
    },
    306: function(n, e, t) {
        t.r(e);
        var a = t(307), r = t.n(a);
        for (var o in a) "default" !== o && function(n) {
            t.d(e, n, function() {
                return a[n];
            });
        }(o);
        e.default = r.a;
    },
    307: function(n, e, t) {}
} ]), (global.webpackJsonp = global.webpackJsonp || []).push([ "components/c-banner/c-banner-create-component", {
    "components/c-banner/c-banner-create-component": function(n, e, t) {
        t("1").createComponent(t(301));
    }
}, [ [ "components/c-banner/c-banner-create-component" ] ] ]);