require("../../uni-bootstrap.js"), (global.webpackJsonp = global.webpackJsonp || []).push([ [ "components/c-quick-login-fn/c-quick-login-fn" ], {
    360: function(n, t, e) {
        e.r(t);
        var o = e(361), i = e(363);
        for (var a in i) "default" !== a && function(n) {
            e.d(t, n, function() {
                return i[n];
            });
        }(a);
        e(365);
        var s = e(10), r = Object(s.default)(i.default, o.render, o.staticRenderFns, !1, null, "392563c4", null, !1, o.components, void 0);
        r.options.__file = "components/c-quick-login-fn/c-quick-login-fn.vue", t.default = r.exports;
    },
    361: function(n, t, e) {
        e.r(t);
        var o = e(362);
        e.d(t, "render", function() {
            return o.render;
        }), e.d(t, "staticRenderFns", function() {
            return o.staticRenderFns;
        }), e.d(t, "recyclableRender", function() {
            return o.recyclableRender;
        }), e.d(t, "components", function() {
            return o.components;
        });
    },
    362: function(n, t, e) {
        e.r(t), e.d(t, "render", function() {
            return o;
        }), e.d(t, "staticRenderFns", function() {
            return a;
        }), e.d(t, "recyclableRender", function() {
            return i;
        }), e.d(t, "components", function() {});
        var o = function() {
            var n = this, t = n.$createElement;
            n._self._c;
            n._isMounted || (n.e0 = function(t) {
                n.showVerifyLayer = !1;
            });
        }, i = !1, a = [];
        o._withStripped = !0;
    },
    363: function(n, t, e) {
        e.r(t);
        var o = e(364), i = e.n(o);
        for (var a in o) "default" !== a && function(n) {
            e.d(t, n, function() {
                return o[n];
            });
        }(a);
        t.default = i.a;
    },
    364: function(n, t, e) {
        (function(n) {
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = void 0;
            var o = e(21), i = {
                data: function() {
                    return {
                        showVerifyLayer: !1,
                        abletoSendCode: !0,
                        missingPhone: "",
                        verifyMsg: "重新获取",
                        phone: "",
                        interval: 60,
                        smsCode: ""
                    };
                },
                methods: {
                    wxMobRegister: function(t) {
                        var e = this;
                        n.showLoading({
                            title: "登录中...",
                            mask: !0
                        });
                        var i = {
                            modEncryptedData: t.detail.encryptedData,
                            modIv: t.detail.iv
                        };
                        (0, o.wxMobRegister)(i, function(t) {
                            n.hideLoading(), 0 == t.data.status.code || "10001" == t.data.status.code ? (0, 
                            o.profile)(function() {
                                e.$emit("success");
                            }) : 10002 == t.data.status.code ? (e.phone = t.data.data.phone, e.missingPhone = e.phone.substr(0, 3) + "****" + e.phone.substr(-4), 
                            e.getSMSCode()) : n.showToast({
                                title: t.data.status.msg || "未知错误",
                                icon: "none"
                            });
                        });
                    },
                    getSMSCode: function() {
                        var t = this;
                        this.abletoSendCode && (n.showLoading({
                            title: "验证码获取中...",
                            mask: !0
                        }), this.showVerifyLayer = !0, (0, o.getSMSCode)({
                            phone: this.phone
                        }, function(e) {
                            switch (n.hideLoading(), e.data.status.code) {
                              case 0:
                                n.showToast({
                                    title: "验证码已发送",
                                    icon: "none"
                                }), t.countDown();
                                break;

                              default:
                                n.showToast({
                                    title: e.data.status.msg,
                                    icon: "none"
                                });
                            }
                        }));
                    },
                    countDown: function() {
                        var n = this;
                        this.timer && (clearInterval(this.timer), this.timer = null), this.timer = setInterval(function() {
                            n.interval--, n.abletoSendCode = !1, n.verifyMsg = "(".concat(n.interval, "s)重新获取"), 
                            0 == n.interval && (clearInterval(n.timer), n.abletoSendCode = !0, n.interval = 60, 
                            n.verifyMsg = "重新获取");
                        }, 1e3);
                    },
                    autoNext: function(n) {
                        this.smsCode = n.detail.value, this.smsCode.length > 5 && this.submitLogin();
                    },
                    submitLogin: function() {
                        var t = this;
                        n.showLoading({
                            title: "登录中...",
                            mask: !0
                        }), (0, o.login)({
                            name: this.phone,
                            smsCode: this.smsCode
                        }, function(e) {
                            n.hideLoading(), 0 == e.data.status.code ? (t.showVerifyLayer = !1, (0, o.profile)(function() {
                                t.$emit("success");
                            })) : (n.showToast({
                                title: e.data.status.msg,
                                icon: "none"
                            }), t.abletoSendCode = !0, t.interval = 60, t.smsCode = "", t.verifyMsg = "重新获取");
                        });
                    }
                },
                destroyed: function() {
                    this.timer && (clearInterval(this.timer), this.timer = null);
                }
            };
            t.default = i;
        }).call(this, e(1).default);
    },
    365: function(n, t, e) {
        e.r(t);
        var o = e(366), i = e.n(o);
        for (var a in o) "default" !== a && function(n) {
            e.d(t, n, function() {
                return o[n];
            });
        }(a);
        t.default = i.a;
    },
    366: function(n, t, e) {}
} ]), (global.webpackJsonp = global.webpackJsonp || []).push([ "components/c-quick-login-fn/c-quick-login-fn-create-component", {
    "components/c-quick-login-fn/c-quick-login-fn-create-component": function(n, t, e) {
        e("1").createComponent(e(360));
    }
}, [ [ "components/c-quick-login-fn/c-quick-login-fn-create-component" ] ] ]);