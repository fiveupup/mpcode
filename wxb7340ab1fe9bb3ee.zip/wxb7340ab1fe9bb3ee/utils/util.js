var e, t = require("../@babel/runtime/helpers/defineProperty");

require("../configs/baseConfig");

String.prototype.padStart || (String.prototype.padStart = function(e, t) {
    return e >>= 0, t = String(void 0 !== t ? t : " "), this.length > e ? String(this) : ((e -= this.length) > t.length && (t += t.repeat(e / t.length)), 
    t.slice(0, e) + String(this));
});

var r = (t(e = {
    formatTime: function(e) {
        var t = e.getFullYear(), r = e.getMonth() + 1, n = e.getDate(), o = e.getHours(), a = e.getMinutes(), i = e.getSeconds();
        return [ t, r, n ].map(this.formatNumber).join("/") + " " + [ o, a, i ].map(this.formatNumber).join(":");
    },
    formatTime2: function(e) {
        var t = new Date(e), r = t.getFullYear(), n = t.getMonth() + 1, o = t.getDate(), a = t.getHours(), i = t.getMinutes(), c = t.getSeconds();
        return {
            year: r,
            month: n < 10 ? "0" + n : n,
            day: o < 10 ? "0" + o : o,
            hour: a < 10 ? "0" + a : a,
            minute: i < 10 ? "0" + i : i,
            second: c < 10 ? "0" + c : c
        };
    },
    formatDuration: function(e) {
        var t = parseInt(e);
        return {
            h: Math.floor(t / 3600) < 10 ? "0" + Math.floor(t / 3600) : Math.floor(t / 3600),
            m: Math.floor(t / 60 % 60) < 10 ? "0" + Math.floor(t / 60 % 60) : Math.floor(t / 60 % 60),
            s: Math.floor(t % 60) < 10 ? "0" + Math.floor(t % 60) : Math.floor(t % 60)
        };
    },
    queryString: function(e, t) {
        var r, n, o = e && e.split("?")[1] ? e.split("?")[1].split("&") : [], a = {};
        for (r = 0, n = o.length; r < n; r++) a[o[r].split("=")[0] || "undefined"] = o[r].split("=")[1] || "";
        return a[t] || "";
    },
    paramsStringify: function(e) {
        if ("[object Object]" != Object.prototype.toString.call(e)) return e;
        var t = [];
        for (var r in e) t.push(r + "=" + e[r]);
        return t.join("&");
    },
    formatNumber: function(e) {
        return (e = e.toString())[1] ? e : "0" + e;
    },
    delHTMLMark: function(e) {
        return e.replace(/(&lt;.*?&gt;|&lt;\/.*?&gt)/g, "").replace(/&amp;/g, "&").replace(/&quot;/g, '"').replace(/&mdash;/g, "—").replace(/&nbsp;/g, " ").replace(/&times;/g, "×").replace(/&divide;/g, "÷").replace(/(&ldquo;|&rdquo;)/g, '"').replace(/&rarr;/g, "→").replace(/&ge;/g, "≥").replace(/&le;/g, "≤").replace(/&Omega;/g, "Ω").replace(/&Oslash;/g, "Ø").replace(/&plusmn;/g, "±").replace(/&sum;/g, "∑");
    },
    replaceHTMLChar: function(e) {
        return e.replace(/&rdquo;/g, "").replace(/&amp;/g, "&").replace(/&quot;/g, '"').replace(/&mdash;/g, "—").replace(/&nbsp;/g, " ").replace(/&times;/g, "×").replace(/&divide;/g, "÷").replace(/(&ldquo;|&rdquo;)/g, '"').replace(/(&lsquo;|&rsquo;)/g, "'").replace(/&rarr;/g, "→").replace(/&ge;/g, "≥").replace(/&le;/g, "≤").replace(/&Omega;/g, "Ω").replace(/&Oslash;/g, "Ø").replace(/&plusmn;/g, "±").replace(/&sum;/g, "∑").replace(/&middot;/g, "·").replace(/&ang;/g, "∠").replace(/&deg;/g, "°").replace(/&radic;/g, "√").replace(/&hellip;/g, "……").replace(/&gt;/g, ">").replace(/&lt;/g, "<").replace(/font-family: \"[^\"]*\"/g, "").replace(/<p [^>]*>/g, "<p>").replace(/<span [^>]*>/g, "<span>").replace(/<img/g, "<img style='max-width:100%;height:auto;'").replace(/<p><br\/><\/p>/g, " ");
    },
    countTime: function(e, t) {
        if (!t) return -1;
        var r, n = new Date().getTime(), o = "", a = 0, i = "", c = "", s = "";
        return 1 == e || 2 == e ? o = Number(t) + 1728e5 : 3 != e && 4 != e || (o = Number(t)), 
        (r = o - n) > 0 ? (4 == e && (a = Math.floor(r / 864e5)), i = Math.floor((r - 1e3 * a * 60 * 60 * 24) / 36e5), 
        c = Math.floor((r - 1e3 * a * 60 * 60 * 24 - 1e3 * i * 60 * 60) / 6e4), s = Math.floor((r - 1e3 * a * 60 * 60 * 24 - 1e3 * i * 60 * 60 - 1e3 * c * 60) / 1e3), 
        1 == e ? this.formatNumber(i) + "小时" + this.formatNumber(c) + "分钟" + this.formatNumber(s) + "秒" : {
            d: String(this.formatNumber(a)),
            h: String(this.formatNumber(i)),
            m: String(this.formatNumber(c)),
            s: String(this.formatNumber(s))
        }) : 0 == r ? 0 : 1 == e ? "00小时00分00秒" : {
            d: "00",
            h: "00",
            m: "00",
            s: "00"
        };
    },
    timeStamp: function() {
        return 1 * new Date();
    },
    isPhone: function(e) {
        return /^1\d{10}$/.test(e);
    },
    isPassword: function(e) {
        return /^[a-zA-Z0-9_]{4,18}$/.test(e);
    },
    showLoading: function(e) {
        try {
            wx.showLoading(e);
        } catch (e) {}
    },
    hideLoading: function() {
        try {
            wx.hideLoading();
        } catch (e) {}
    },
    showToast: function(e) {
        try {
            wx.showToast(e);
        } catch (e) {}
    },
    showToast2: function(e) {
        try {
            wx.showToast({
                title: e,
                icon: "none",
                duration: 4e3
            });
        } catch (e) {}
    },
    hideToast: function() {
        try {
            wx.hideToast();
        } catch (e) {}
    },
    showModal: function(e, t, r, n) {
        try {
            wx.showModal({
                title: e || "提示",
                content: t,
                showCancel: !1,
                confirmColor: "#5291fe",
                success: function() {
                    "function" == typeof r && r();
                },
                fail: function() {
                    "function" == typeof n && n();
                }
            });
        } catch (e) {}
    },
    getStrLength: function(e) {
        for (var t = 0, r = 0; r < e.length; r++) e.charCodeAt(r) > 127 || 94 == e.charCodeAt(r) ? t += 2 : t++;
        return t;
    },
    checkOS: function() {
        var e = 1;
        if (wx.getStorageSync("systemInfo")) {
            var t = wx.getStorageSync("systemInfo");
            t.system.indexOf("Android") > -1 ? e = 1 : t.system.indexOf("iOS") > -1 && (e = 2);
        } else wx.getSystemInfo({
            success: function(t) {
                t.system.indexOf("Android") > -1 ? e = 1 : t.system.indexOf("iOS") > -1 && (e = 2);
            }
        });
        return e;
    },
    reportEvent: function(e, t, r) {
        e.sensors.track(t, Object.assign({}, r));
    },
    userBindReport: function(e, t) {
        e.sensors.login(t + "");
    },
    thirdAgrement: function(e) {
        var t = "", r = "";
        if (/^miniProgram\:/.test(e)) return t = e.split("::")[0].replace("miniProgram://appId=", ""), 
        r = e.split("::")[1].replace("path=", ""), wx.navigateToMiniProgram({
            appId: t,
            path: r,
            extraData: {},
            envVersion: "release",
            success: function(e) {},
            fail: function() {},
            complete: function() {}
        }), !0;
    },
    randomString: function() {
        for (var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : 16, t = "ABCDEFGHJKMNPQRSTWXYZabcdefhijkmnprstwxyz2345678", r = t.length, n = "", o = 0; o < e; o++) n += t.charAt(Math.floor(Math.random() * r));
        return n;
    },
    replaceImagePath: function(e) {
        return e.replace(/http\:\/\/edu24ol\.bs2cdn\.100\.com\//g, "https://edu24ol.bs2cdn.98809.com/").replace(/http\:/, "https:");
    },
    replaceOss: function(e) {
        return e = (e = (e = (e = (e = (e = (e = e.replace("http://edu24ol.bs2cdn.100.com:80", "https://oss-hqwx-edu24ol.hqwx.com")).replace(/https?\:\/\/edu24ol\.bs2cdn\.100\.com/g, "https://oss-hqwx-edu24ol.hqwx.com")).replace("http://edu100.bs2cdn.100.com:80", "https://oss-hqwx-edu100.hqwx.com")).replace("http://edu100.bs2cdn.100.com", "https://oss-hqwx-edu100.hqwx.com")).replace("http://oss-hqwx-edu24ol.hqwx.com:80", "https://oss-hqwx-edu24ol.hqwx.com")).replace("http://oss-hqwx-edu24ol.hqwx.com", "https://oss-hqwx-edu24ol.hqwx.com")).replace("http://oss-hqwx-edu100.hqwx.com:80", "https://oss-hqwx-edu100.hqwx.com");
    },
    setBarHeight: function() {
        var e = 44;
        wx.getSystemInfo({
            success: function(t) {
                e += t.statusBarHeight, -1 !== t.system.indexOf("Android") && (e += 4), wx.getMenuButtonBoundingClientRect(), 
                wx.setStorageSync("barStyle", {
                    height: e
                }), wx.setStorageSync("windowStyle", {
                    width: t.windowWidth,
                    height: t.windowHeight
                });
            }
        });
    },
    debounce: function(e, t) {
        var r;
        return function() {
            r && clearTimeout(r), r = setTimeout(e, t);
        };
    },
    throttle: function(e, t) {
        var r = arguments, n = this, o = 0;
        return function() {
            +new Date() - o > t && (e.apply(n, r), o = +new Date());
        };
    },
    setUrlParams: function(e) {
        var t = [ "firstPType" ], r = wx.getStorageSync("urlParams");
        if (r && "{}" != JSON.stringify(r)) {
            var n = function(n) {
                t.forEach(function(t, o) {
                    n == t && e[t] && (r[n] = e[t]);
                });
            };
            for (var o in r) n(o);
        } else r = {}, t.forEach(function(t, n) {
            r[t] = e[t];
        });
        wx.setStorageSync("urlParams", r);
    },
    getUrlParams: function() {
        try {
            return wx.getStorageSync("urlParams") || {};
        } catch (e) {
            return {};
        }
    },
    getCurrentPage: function() {
        var e = getCurrentPages() || [], t = e[e.length - 1], r = t.route, n = t.options, o = [];
        for (var a in n) o.push(a + "=" + n[a]);
        return "/" + r + "?" + o.join("&");
    }
}, "paramsStringify", function(e) {
    if ("[object Object]" != Object.prototype.toString.call(e)) return e;
    var t = [];
    for (var r in e) t.push(r + "=" + e[r]);
    return t.join("&");
}), t(e, "timeFormat", function() {
    var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : null, t = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : "yyyy-mm-dd";
    (e = parseInt(e)) || (e = Number(new Date())), 10 == e.toString().length && (e *= 1e3);
    var r, n = new Date(e), o = {
        "y+": n.getFullYear().toString(),
        "m+": (n.getMonth() + 1).toString(),
        "d+": n.getDate().toString(),
        "h+": n.getHours().toString(),
        "M+": n.getMinutes().toString(),
        "s+": n.getSeconds().toString()
    };
    for (var a in o) (r = new RegExp("(" + a + ")").exec(t)) && (t = t.replace(r[1], 1 == r[1].length ? o[a] : o[a].padStart(r[1].length, "0")));
    return t;
}), t(e, "guid", function() {
    return "xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx".replace(/[xy]/g, function(e) {
        var t = 16 * Math.random() | 0;
        return ("x" == e ? t : 3 & t | 8).toString(16);
    });
}), e);

module.exports = r;