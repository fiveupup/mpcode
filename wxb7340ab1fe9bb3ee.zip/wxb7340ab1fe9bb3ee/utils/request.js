Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.listUserByPid = exports.getListsWithUserRelated = exports.activityInfoByPid = void 0;

var t = getApp(), o = require("../configs/baseConfig"), e = require("../configs/config_" + o.appName), n = require("./util"), i = function t(i) {
    return (i = Object.assign({}, {
        showLoading: i.showLoading || !1,
        loadingTitle: i.loadingTitle || "加载中",
        loadingMask: i.loadingMask || !0,
        url: i.url || "",
        method: i.method || "GET",
        data: i.data,
        success: i.success,
        fail: i.fail,
        showFailToast: i.showFailToast || !1,
        toastFialTitle: i.toastFialTitle || "登录失效，请重新登录",
        returnPath: i.returnPath || "/pages/index/index"
    })).data = Object.assign({}, {
        appid: e.appid,
        _appid: e.appid,
        org_id: o.orgId,
        pschId: o.pschId,
        schId: o.orgId,
        t: n.timeStamp(),
        os: n.checkOS(),
        platform: o.platform
    }, i.data), i.data.edu24ol_token && (i.data.edu24ol_token = wx.getStorageSync("hq_token")), 
    "POST" == i.method && (i.contentType = "application/x-www-form-urlencoded"), i.showLoading && wx.showLoading({
        title: i.loadingTitle,
        mask: i.loadingMask
    }), wx.request({
        url: i.url,
        method: i.method,
        data: i.data,
        header: {
            "content-type": i.contentType || "application/json"
        },
        success: function(e) {
            40041 == e.data.status.code || 40042 == e.data.status.code ? (n.showLoading(), a(function(e) {
                if (0 == e.data.status.code) wx.setStorage({
                    key: o.tokenTimeStamp,
                    data: n.timeStamp()
                }), wx.setStorage({
                    key: o.tokenKey,
                    data: e.data.data.token,
                    success: function() {
                        i.data = Object.assign(i.data, {
                            edu24ol_token: e.data.data.token
                        }, i.data), t(i);
                    }
                }); else {
                    var a = 0;
                    i.showFailToast && (n.showToast2(i.toastFialTitle), a = 1500);
                    var s = setTimeout(function() {
                        clearTimeout(s);
                        var t = "/pages/login/login?sourcePath=" + encodeURIComponent(i.returnPath);
                        wx.navigateTo({
                            url: t
                        });
                    }, a);
                }
            })) : "function" == typeof i.success && i.success(e);
        },
        fail: function(t) {
            "function" == typeof i.fail && i.fail(t);
        }
    });
}, a = function(n, a) {
    var s = {};
    wx.showLoading(), t.getUserInfo(function(t) {
        s = {
            encryptedData: encodeURIComponent(t.appBaseInfo.encryptedData),
            code: encodeURIComponent(t.code),
            iv: encodeURIComponent(t.appBaseInfo.iv),
            sessionKey: encodeURIComponent(wx.getStorageSync("sessionKey")),
            distinct_id: e.sdid
        }, i({
            url: "".concat(o.host, "/wxapp/v1/user/profile"),
            data: s,
            method: "POST",
            success: function(t) {
                "function" == typeof n && n(t);
            },
            fail: function(t) {
                "function" == typeof a && a(t);
            }
        });
    });
}, s = function(t, e, n) {
    i({
        url: "".concat(o.host, "/mobile/v2/pintuan/activity_info_by_pid"),
        data: {
            edu24ol_token: t.token,
            pintuan_id: t.pintuanId,
            returnPath: t.returnPath
        },
        success: function(t) {
            "function" == typeof e && e(t);
        },
        fail: function(t) {
            "function" == typeof n && n(t);
        }
    });
};

exports.activityInfoByPid = s;

var c = function(t, e, n) {
    i({
        url: "".concat(o.host, "/mobile/v2/pintuan/list_user_by_pid"),
        data: {
            edu24ol_token: t.token,
            pintuan_id: t.pintuanId,
            returnPath: t.returnPath
        },
        success: function(t) {
            "function" == typeof e && e(t);
        },
        fail: function(t) {
            "function" == typeof n && n(t);
        }
    });
};

exports.listUserByPid = c;

var d = function(t, e, n) {
    i({
        url: "".concat(o.host, "/mobile/v2/categories/getListsWithUserRelated"),
        data: {
            edu24ol_token: t.token,
            intention: t.intention,
            interested: t.interested
        },
        success: function(t) {
            "function" == typeof e && e(t);
        },
        fail: function(t) {
            "function" == typeof n && n(t);
        }
    });
};

exports.getListsWithUserRelated = d, module.exports = {
    request: i,
    profile: a,
    giftDraw: function(t, i) {
        var a;
        a = {
            _appid: e.appid,
            pschId: o.pschId,
            schId: o.orgId,
            _os: n.checkOS(),
            _t: n.timeStamp(),
            _v: e.version,
            platform: o.platform,
            edu24ol_token: t.token,
            secondCategory: t.gid
        }, wx.request({
            url: "".concat(o.hostJAPI, "/op/gift/draw"),
            data: a,
            method: "GET",
            success: function(t) {
                "function" == typeof i && i(t);
            }
        });
    },
    getGiftCouponList: function(t, i) {
        var a;
        a = {
            _appid: e.appid,
            pschId: o.pschId,
            schId: o.orgId,
            _os: n.checkOS(),
            _t: n.timeStamp(),
            _v: e.version,
            platform: o.platform,
            edu24ol_token: t.token
        }, wx.request({
            url: "".concat(o.hostJAPI, "/op/gift/getCouponList"),
            data: a,
            method: "GET",
            success: function(t) {
                "function" == typeof i && i(t);
            }
        });
    },
    getGiftEntranceInfo: function(t, i) {
        var a;
        a = {
            _appid: e.appid,
            pschId: o.pschId,
            schId: o.orgId,
            _os: n.checkOS(),
            _t: n.timeStamp(),
            _v: e.version,
            platform: o.platform,
            edu24ol_token: t.token
        }, wx.request({
            url: "".concat(o.hostJAPI, "/op/gift/getEntranceInfo"),
            data: a,
            method: "GET",
            success: function(t) {
                "function" == typeof i && i(t);
            }
        });
    },
    getGiftGoodsList: function(t, i) {
        var a;
        a = {
            _appid: e.appid,
            pschId: o.pschId,
            schId: o.orgId,
            _os: n.checkOS(),
            _t: n.timeStamp(),
            _v: e.version,
            platform: o.platform,
            edu24ol_token: t.token,
            secondCategory: t.gid,
            type: t.type
        }, wx.request({
            url: "".concat(o.hostJAPI, "/op/gift/getGoodsList"),
            data: a,
            method: "GET",
            success: function(t) {
                "function" == typeof i && i(t);
            }
        });
    },
    getGiftPosterInfo: function(t, i) {
        var a;
        a = {
            _appid: e.appid,
            pschId: o.pschId,
            schId: o.orgId,
            _os: n.checkOS(),
            _t: n.timeStamp(),
            _v: e.version,
            platform: o.platform,
            edu24ol_token: t.token,
            gid: t.gid,
            id: t.id
        }, wx.request({
            url: "".concat(o.hostJAPI, "/op/gift/getPosterInfo"),
            data: a,
            method: "GET",
            success: function(t) {
                "function" == typeof i && i(t);
            }
        });
    },
    shareGiftDetail: function(t, i) {
        var a;
        a = {
            _appid: e.appid,
            pschId: o.pschId,
            schId: o.orgId,
            _os: n.checkOS(),
            _t: n.timeStamp(),
            _v: e.version,
            platform: o.platform,
            edu24ol_token: t.token,
            gid: t.gid,
            id: t.id,
            uid: t.uid
        }, wx.request({
            url: "".concat(o.hostJAPI, "/op/gift/shareDetail"),
            data: a,
            method: "GET",
            success: function(t) {
                "function" == typeof i && i(t);
            }
        });
    },
    shareGiftDraw: function(t, i) {
        var a;
        a = {
            _appid: e.appid,
            pschId: o.pschId,
            schId: o.orgId,
            _os: n.checkOS(),
            _t: n.timeStamp(),
            _v: e.version,
            platform: o.platform,
            edu24ol_token: t.token,
            gid: t.gid,
            id: t.id,
            uid: t.uid
        }, wx.request({
            url: "".concat(o.hostJAPI, "/op/gift/shareDraw"),
            data: a,
            method: "GET",
            success: function(t) {
                "function" == typeof i && i(t);
            }
        });
    },
    getHqCourseTeacher: function(t, i) {
        var a;
        a = {
            _appid: e.appid,
            pschId: o.pschId,
            schId: o.orgId,
            _os: n.checkOS(),
            _t: n.timeStamp(),
            _v: e.version,
            platform: o.platform,
            goodsGroupId: t.goodsGroupId
        }, wx.request({
            url: "".concat(o.host, "/wxapp/activity/course/getHqCourseTeacher"),
            data: a,
            method: "GET",
            success: function(t) {
                "function" == typeof i && i(t);
            }
        });
    },
    getGiftCourseList: function(t, i) {
        var a;
        a = {
            _appid: e.appid,
            appid: e.appid,
            pschId: o.pschId,
            schId: o.orgId,
            _os: n.checkOS(),
            _t: n.timeStamp(),
            _v: e.version,
            platform: o.platform,
            edu24ol_token: t.token,
            second_category_id: t.gid,
            open_id: t.openid
        }, wx.request({
            url: "".concat(o.host, "/wxapp/activity/gift/get_gift_course_list"),
            data: a,
            method: "GET",
            success: function(t) {
                "function" == typeof i && i(t);
            }
        });
    },
    giftGoodsgroupForFree: function(t, i) {
        var a;
        a = {
            _appid: e.appid,
            appid: e.appid,
            pschId: o.pschId,
            schId: o.orgId,
            _os: n.checkOS(),
            _t: n.timeStamp(),
            _v: e.version,
            platform: o.platform,
            edu24ol_token: t.token,
            gift_id: t.giftid,
            goodsgroup: t.goodsgroup
        }, wx.request({
            url: "".concat(o.host, "/wxapp/activity/gift/receive_gift_goodsgroup_for_free"),
            data: a,
            method: "GET",
            success: function(t) {
                "function" == typeof i && i(t);
            }
        });
    },
    getAIAppCategoryList: function(t, i) {
        var a;
        a = {
            _appid: e.appid,
            pschId: o.pschId,
            schId: o.orgId,
            _os: n.checkOS(),
            _t: n.timeStamp(),
            _v: e.version,
            platform: o.platform,
            secondCategory: t.gid
        }, wx.request({
            url: "".concat(o.hostJAPI, "/goodsController/getAIAppCategoryList"),
            data: a,
            method: "GET",
            success: function(t) {
                "function" == typeof i && i(t);
            }
        });
    },
    getHotGoodsGroup: function(t, i) {
        var a;
        a = {
            _appid: e.appid,
            pschId: o.pschId,
            schId: o.orgId,
            _os: n.checkOS(),
            _t: n.timeStamp(),
            _v: e.version,
            platform: o.platform,
            from: t.from,
            terminal_type: o.terminalType,
            rows: t.rows,
            secondCategory: t.gid
        }, wx.request({
            url: "".concat(o.host, "/mobile/v2/goods/getHotGoodsGroup"),
            data: a,
            method: "GET",
            success: function(t) {
                "function" == typeof i && i(t);
            }
        });
    },
    activityInfoByPid: s,
    listUserByPid: c,
    updateUserInfo: function(t, e, n) {
        i({
            url: "".concat(o.host, "/mobile/v2/user/updateUserInfo"),
            data: {
                edu24ol_token: t.token,
                second_category: t.chooseId
            },
            method: "POST",
            dataType: "json",
            header: {
                "content-type": "application/x-www-form-urlencoded"
            },
            success: function(t) {
                "function" == typeof e && e(t);
            },
            fail: function(t) {
                "function" == typeof n && n(t);
            }
        });
    },
    addToCart: function(t, e, n) {
        i({
            url: "".concat(o.host, "/mobile/v2/cart/addToCart"),
            data: {
                activity_id: t.activityId || 0,
                edu24ol_token: t.token,
                goodsid: t.goodsId,
                group_id: t.groupId
            },
            success: function(t) {
                "function" == typeof e && e(t);
            },
            fail: function(t) {
                "function" == typeof n && n(t);
            }
        });
    },
    getListsWithUserRelated: d,
    groupListGoods: function(t, e, n) {
        i({
            url: "".concat(o.host, "/mobile/v2/pintuan/list_goods"),
            data: {
                edu24ol_token: t.token,
                course_id: t.courseId,
                returnPath: t.returnPath
            },
            success: function(t) {
                "function" == typeof e && e(t);
            },
            fail: function(t) {
                "function" == typeof n && n(t);
            }
        });
    },
    queryBuyOrderGroupVO: function(t, e, n) {
        i({
            url: "".concat(o.hostJAPI, "/buy/pintuan/queryBuyOrderGroupVO"),
            data: {
                from: t.from,
                rows: t.rows,
                edu24ol_token: t.token,
                courseId: t.courseId,
                returnPath: t.returnPath
            },
            success: function(t) {
                "function" == typeof e && e(t);
            },
            fail: function(t) {
                "function" == typeof n && n(t);
            }
        });
    },
    getMiniappRecommendGroup: function(t, e, n) {
        i({
            url: "".concat(o.host, "/mobile/v2/goods/getMiniappRecommendGroup"),
            data: {},
            success: function(t) {
                "function" == typeof e && e(t);
            },
            fail: function(t) {
                "function" == typeof n && n(t);
            }
        });
    },
    getGroupActivitySecondCategoryList: function(t, e, n) {
        i({
            url: "".concat(o.host, "/mobile/v2/pintuan/getGroupActivitySecondCategoryList"),
            data: {},
            success: function(t) {
                "function" == typeof e && e(t);
            },
            fail: function(t) {
                "function" == typeof n && n(t);
            }
        });
    }
};