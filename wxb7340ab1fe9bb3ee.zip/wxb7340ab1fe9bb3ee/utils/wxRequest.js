var t = require("../configs/config_hqwxmall"), e = require("../configs/baseConfig"), n = require("../utils/util"), o = 0, a = 0, i = function(t, e) {
    wx.login({
        success: function(n) {
            var o = Object.assign({}, {
                code: n.code
            }, t, o);
            wx.getSetting({
                success: function(t) {
                    t.authSetting && t.authSetting["scope.userInfo"] && wx.getUserInfo({
                        withCredentials: !0,
                        success: function(t) {
                            Object.assign(o, t), c(o, e);
                        }
                    });
                }
            });
        }
    });
}, c = function(o, i) {
    var c = {
        appid: t.appid,
        _appid: t.appid,
        pschId: e.pschId,
        schId: e.orgId,
        t: n.timeStamp(),
        os: n.checkOS(),
        platform: e.platform,
        encryptedData: encodeURIComponent(o.encryptedData),
        code: encodeURIComponent(o.code),
        iv: encodeURIComponent(o.iv)
    };
    wx.request({
        url: "".concat(e.host, "/wxapp/v1/user/profile"),
        data: c,
        method: "POST",
        header: {
            "content-type": "application/x-www-form-urlencoded"
        },
        success: function(t) {
            if (0 == t.data.status.code) "function" == typeof i && i(t.data.data); else {
                if (o && o.data && 0 == o.data.goToLogin) return;
                if (++a <= 1) {
                    var e = getCurrentPages(), n = "/".concat(e[e.length - 1].route, "?wx=1"), c = e[e.length - 1].options, s = "", r = "/pages/login/login?sourcePath=";
                    for (var u in c) s += "&".concat(u, "=").concat(c[u]);
                    r += encodeURIComponent(n += s), wx.navigateTo({
                        url: r
                    });
                }
            }
        },
        fail: function(t) {}
    });
};

module.exports = function(t) {
    t = Object.assign({}, {
        notReport: [ "https://api.sc.hqwx.com", "https://api.live.bilibili.com", "https://kjapi.98809.com/ping" ]
    }, t);
    var a = wx.request;
    Object.defineProperty(wx, "request", {
        configurable: !0,
        enumerable: !0,
        writable: !0,
        value: function() {
            for (var c = this, s = arguments[0] || {}, r = s.success, u = s.fail, p = t.notReport.length, d = 0; d < p; d++) if (s.url.indexOf(t.notReport[d]) > -1) return a.apply(this, arguments);
            return s.success = function(t) {
                if (t && t.data) if (!t.data.status || 40041 != t.data.status.code && 40042 != t.data.status.code) {
                    if (r) return r.apply(c, arguments);
                } else i({
                    data: s.data
                }, function(t) {
                    o++, wx.setStorageSync(e.tokenKey, t.token), wx.setStorageSync(e.tokenTimeStamp, n.timeStamp()), 
                    wx.setStorageSync("hqUserInfo", t), s.data.edu24ol_token = t.token, o <= 3 ? wx.request(s) : wx.redirectTo({
                        url: "/pages/index/index"
                    });
                });
            }, s.fail = function(t) {
                if (u) return u.apply(this, arguments);
            }, a.apply(this, arguments);
        }
    });
};