var e = {
    put: function(e, t, r) {
        wx.setStorageSync(e, t);
        var a = parseInt(r);
        if (a > 0) {
            var n = Date.parse(new Date());
            n = n / 1e3 + a, wx.setStorageSync(e + "_deadtime", n + "");
        } else wx.removeStorageSync(e + "_deadtime");
    },
    get: function(e, t) {
        var r = parseInt(wx.getStorageSync(e + "_deadtime"));
        if (r && parseInt(r) < Date.parse(new Date()) / 1e3) return t || void 0;
        var a = wx.getStorageSync(e);
        return a || t;
    },
    remove: function(e) {
        wx.removeStorageSync(e), wx.removeStorageSync(e + "_deadtime");
    },
    clear: function() {
        wx.clearStorageSync();
    }
};

module.exports = e;