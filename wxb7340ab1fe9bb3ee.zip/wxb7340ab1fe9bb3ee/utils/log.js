var e = require("./util"), r = require("./cache"), t = wx.getRealtimeLogManager ? wx.getRealtimeLogManager() : null, o = {
    info: function() {
        t && t.info.apply(t, arguments);
    },
    warn: function() {
        t && t.warn.apply(t, arguments);
    },
    error: function() {
        t && t.error.apply(t, arguments);
    },
    setFilterMsg: function(e) {
        t && t.setFilterMsg && "string" == typeof e && t.setFilterMsg(e);
    },
    addFilterMsg: function(e) {
        t && t.addFilterMsg && "string" == typeof e && t.addFilterMsg(e);
    }
}, n = function(t) {
    var n = !(arguments.length > 1 && void 0 !== arguments[1]) || arguments[1];
    t = Object.assign({}, t);
    var s = n ? "接口错误，返回码[" + t.statusCode + "]" : "fail错误," + t.err && t.err.errMsg, a = function() {
        var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : function() {}, t = r.get("logUserIP");
        t ? e(t) : wx.request({
            url: "https://api.live.bilibili.com/client/v1/Ip/getInfoNew",
            data: {},
            dataType: "json",
            timeout: 800,
            success: function(t) {
                0 == t.data.code && (r.put("logUserIP", t.data.data, 3600), e(t.data.data));
            },
            fail: function() {
                e("");
            }
        });
    };
    a(function(r) {
        wx.getSystemInfo({
            success: function(n) {
                wx.getNetworkType({
                    success: function(a) {
                        o.error({
                            created: e.formatTime(new Date()),
                            creator: t.openid,
                            system: n,
                            err_msg: s,
                            request_method: t.requestMethod || "GET",
                            request_url: t.requestUrl,
                            reponse_header: t.reponseHeader || "",
                            use_time: t.userTime,
                            request_query: t.requestQuery,
                            network: a,
                            user_ip: r,
                            userNetworkUseTime: wx.getStorageSync("appNetworkUseTimeKey")
                        });
                        var i = t.requestUrl, u = i.substring(i.lastIndexOf("/") + 1);
                        o.addFilterMsg(u);
                    }
                });
            }
        });
    });
};

o.init = function(e) {
    e = Object.assign({}, {
        open: !1,
        envVersion: "release",
        time: 2e3,
        timeout: 1e4,
        notReport: [],
        reportPerformance: [],
        reportPerformanceAllId: "",
        reportTimes: 20
    }, e);
    var r = wx.getAccountInfoSync();
    if (e.open && r.miniProgram.envVersion == e.envVersion) {
        var t = wx.request;
        Object.defineProperty(wx, "request", {
            configurable: !0,
            enumerable: !0,
            writable: !0,
            value: function() {
                for (var r = arguments[0] || {}, o = r.success, s = r.fail, a = new Date().getTime(), i = {
                    openid: wx.getStorageSync("wxOpenId"),
                    requestMethod: r.method,
                    requestUrl: r.url,
                    requestQuery: r.data,
                    reportTimes: e.reportTimes
                }, u = e.notReport.length, c = 0; c < u; c++) if (r.url.indexOf(e.notReport[c]) > -1) return t.apply(this, arguments);
                r.timeout = e.timeout;
                var l = function(t, o) {
                    if (wx.canIUse("reportPerformance")) {
                        for (var n = e.reportPerformance.length, s = 0; s < n; s++) r.url.indexOf(e.reportPerformance[s].url) > -1 && wx.reportPerformance(e.reportPerformance[s].id, o - t);
                        "" != e.reportPerformanceAllId && wx.reportPerformance(e.reportPerformanceAllId, o - t);
                    }
                };
                return r.success = function(r) {
                    var t = new Date().getTime();
                    return (200 != r.statusCode || t - a > e.time) && (i.statusCode = r.statusCode, 
                    i.reponseHeader = r.header, i.userTime = t - a, n(i), console.log("report success error:", i)), 
                    l(a, t), o.apply(this, arguments);
                }, r.fail = function(e) {
                    var r = new Date().getTime();
                    return i.err = e, i.reponseHeader = e.header, i.userTime = r - a, n(i, !1), console.log("report fail error:", i), 
                    l(a, r), s.apply(this, arguments);
                }, t.apply(this, arguments);
            }
        });
    }
}, module.exports = o;