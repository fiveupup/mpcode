var globalThis = this, self = this;module.exports =
require("../../_commons/0.js")([
{
"ids": [4],
"modules":{

/***/ "./node_modules/@mpflow/webpack-plugin/lib/loaders/page-loader.js?appContext=src%2Fplugin&outputPath=pages%2Findex%2Findex!./src/plugin/pages/index/index.ts":
/*!*******************************************************************************************************************************************************************!*\
  !*** ./node_modules/@mpflow/webpack-plugin/lib/loaders/page-loader.js?appContext=src%2Fplugin&outputPath=pages%2Findex%2Findex!./src/plugin/pages/index/index.ts ***!
  \*******************************************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__(/*! ./index.ts */ "./src/plugin/pages/index/index.ts")

/***/ }),

/***/ "./src/plugin/pages/index/index.ts":
/*!*****************************************!*\
  !*** ./src/plugin/pages/index/index.ts ***!
  \*****************************************/
/*! no static exports found */
/***/ (function(module, exports) {

// import request from '../../common/request'

Page({
  data: {},
  onLoad: function onLoad() {
    /* request({
      url: 'wxacommentplugin',
    }).then(res => {
      console.log('wxacommentplugin res', res)
    }).catch(err => {
      console.error('wxacommentplugin err', err)
    }) */
  }
});

/***/ })

},
"entries": [["./node_modules/@mpflow/webpack-plugin/lib/loaders/page-loader.js?appContext=src%2Fplugin&outputPath=pages%2Findex%2Findex!./src/plugin/pages/index/index.ts",0]]
},
]);