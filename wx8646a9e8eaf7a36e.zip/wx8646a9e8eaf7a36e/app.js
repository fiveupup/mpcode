Object.defineProperty(exports, Symbol.toStringTag, {
    value: "Module"
});

var o = require("./common/vendor.js");

Math;

var n = {
    onLaunch: function onLaunch() {
        console.log("App Launch");
    },
    onShow: function onShow() {
        console.log("App Show");
    },
    onHide: function onHide() {
        console.log("App Hide");
    }
};

function e() {
    return {
        app: o.createSSRApp(n)
    };
}

e().app.mount("#app"), exports.createApp = e;