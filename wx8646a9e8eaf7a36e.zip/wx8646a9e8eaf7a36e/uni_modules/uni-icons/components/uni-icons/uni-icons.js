var e = require("./icons.js"), t = require("../../../../common/vendor.js"), i = {
    name: "UniIcons",
    emits: [ "click" ],
    props: {
        type: {
            type: String,
            default: ""
        },
        color: {
            type: String,
            default: "#333333"
        },
        size: {
            type: [ Number, String ],
            default: 16
        },
        customPrefix: {
            type: String,
            default: ""
        }
    },
    data: function data() {
        return {
            icons: e.icons.glyphs
        };
    },
    computed: {
        unicode: function unicode() {
            var _this = this;
            var e = this.icons.find(function(e) {
                return e.font_class === _this.type;
            });
            return e ? unescape("%u".concat(e.unicode)) : "";
        },
        iconSize: function iconSize() {
            return "number" == typeof (e = this.size) || /^[0-9]*$/g.test(e) ? e + "px" : e;
            var e;
        }
    },
    methods: {
        _onClick: function _onClick() {
            this.$emit("click");
        }
    }
};

var n = t._export_sfc(i, [ [ "render", function(e, i, n, o, c, r) {
    return {
        a: n.color,
        b: r.iconSize,
        c: t.n("uniui-" + n.type),
        d: t.n(n.customPrefix),
        e: t.n(n.customPrefix ? n.type : ""),
        f: t.o(function() {
            return r._onClick && r._onClick.apply(r, arguments);
        })
    };
} ] ]);

wx.createComponent(n);