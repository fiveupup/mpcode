var t = require("../../../../common/vendor.js"), e = {
    name: "UniBadge",
    emits: [ "click" ],
    props: {
        type: {
            type: String,
            default: "error"
        },
        inverted: {
            type: Boolean,
            default: !1
        },
        isDot: {
            type: Boolean,
            default: !1
        },
        maxNum: {
            type: Number,
            default: 99
        },
        absolute: {
            type: String,
            default: ""
        },
        offset: {
            type: Array,
            default: function _default() {
                return [ 0, 0 ];
            }
        },
        text: {
            type: [ String, Number ],
            default: ""
        },
        size: {
            type: String,
            default: "small"
        },
        customStyle: {
            type: Object,
            default: function _default() {
                return {};
            }
        }
    },
    data: function data() {
        return {};
    },
    computed: {
        width: function width() {
            return 8 * String(this.text).length + 12;
        },
        classNames: function classNames() {
            var t = this.inverted, e = this.type, i = this.size, o = this.absolute;
            return [ t ? "uni-badge--" + e + "-inverted" : "", "uni-badge--" + e, "uni-badge--" + i, o ? "uni-badge--absolute" : "" ].join(" ");
        },
        positionStyle: function positionStyle() {
            if (!this.absolute) return {};
            var t = this.width / 2, e = 10;
            this.isDot && (t = 5, e = 5);
            var i = "".concat(-t + this.offset[0], "px"), o = "".concat(-e + this.offset[1], "px"), s = {
                rightTop: {
                    right: i,
                    top: o
                },
                rightBottom: {
                    right: i,
                    bottom: o
                },
                leftBottom: {
                    left: i,
                    bottom: o
                },
                leftTop: {
                    left: i,
                    top: o
                }
            }, r = s[this.absolute];
            return r || s.rightTop;
        },
        dotStyle: function dotStyle() {
            return this.isDot ? {
                width: "10px",
                minWidth: "0",
                height: "10px",
                padding: "0",
                borderRadius: "10px"
            } : {};
        },
        displayValue: function displayValue() {
            var t = this.isDot, e = this.text, i = this.maxNum;
            return t ? "" : Number(e) > i ? "".concat(i, "+") : e;
        }
    },
    methods: {
        onClick: function onClick() {
            this.$emit("click");
        }
    }
};

var i = t._export_sfc(e, [ [ "render", function(e, i, o, s, r, n) {
    return t.e({
        a: o.text
    }, o.text ? {
        b: t.t(n.displayValue),
        c: t.n(n.classNames),
        d: t.s(n.positionStyle),
        e: t.s(o.customStyle),
        f: t.s(n.dotStyle),
        g: t.o(function(t) {
            return n.onClick();
        })
    } : {});
} ] ]);

wx.createComponent(i);