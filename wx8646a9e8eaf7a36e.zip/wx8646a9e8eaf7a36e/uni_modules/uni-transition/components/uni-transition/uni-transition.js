var _toConsumableArray2 = require("../../../../@babel/runtime/helpers/toConsumableArray");

var _typeof2 = require("../../../../@babel/runtime/helpers/typeof");

var _objectSpread2 = require("../../../../@babel/runtime/helpers/objectSpread2");

var t = require("./createAnimation.js"), i = require("../../../../common/vendor.js"), s = {
    name: "uniTransition",
    emits: [ "click", "change" ],
    props: {
        show: {
            type: Boolean,
            default: !1
        },
        modeClass: {
            type: [ Array, String ],
            default: function _default() {
                return "fade";
            }
        },
        duration: {
            type: Number,
            default: 300
        },
        styles: {
            type: Object,
            default: function _default() {
                return {};
            }
        },
        customClass: {
            type: String,
            default: ""
        },
        onceRender: {
            type: Boolean,
            default: !1
        }
    },
    data: function data() {
        return {
            isShow: !1,
            transform: "",
            opacity: 1,
            animationData: {},
            durationTime: 300,
            config: {}
        };
    },
    watch: {
        show: {
            handler: function handler(t) {
                t ? this.open() : this.isShow && this.close();
            },
            immediate: !0
        }
    },
    computed: {
        stylesObject: function stylesObject() {
            var t = _objectSpread2(_objectSpread2({}, this.styles), {}, {
                "transition-duration": this.duration / 1e3 + "s"
            }), i = "";
            for (var _s in t) {
                i += this.toLine(_s) + ":" + t[_s] + ";";
            }
            return i;
        },
        transformStyles: function transformStyles() {
            return "transform:" + this.transform + ";opacity:" + this.opacity + ";" + this.stylesObject;
        }
    },
    created: function created() {
        this.config = {
            duration: this.duration,
            timingFunction: "ease",
            transformOrigin: "50% 50%",
            delay: 0
        }, this.durationTime = this.duration;
    },
    methods: {
        init: function init() {
            var i = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {};
            i.duration && (this.durationTime = i.duration), this.animation = t.createAnimation(Object.assign(this.config, i), this);
        },
        onClick: function onClick() {
            this.$emit("click", {
                detail: this.isShow
            });
        },
        step: function step(t) {
            var i = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : {};
            if (this.animation) {
                for (var _i in t) try {
                    var _this$animation;
                    "object" == _typeof2(t[_i]) ? (_this$animation = this.animation)[_i].apply(_this$animation, _toConsumableArray2(t[_i])) : this.animation[_i](t[_i]);
                } catch (s) {
                    console.error("方法 ".concat(_i, " 不存在"));
                }
                return this.animation.step(i), this;
            }
        },
        run: function run(t) {
            this.animation && this.animation.run(t);
        },
        open: function open() {
            var _this = this;
            clearTimeout(this.timer), this.transform = "", this.isShow = !0;
            var _this$styleInit = this.styleInit(!1), i = _this$styleInit.opacity, s = _this$styleInit.transform;
            void 0 !== i && (this.opacity = i), this.transform = s, this.$nextTick(function() {
                _this.timer = setTimeout(function() {
                    _this.animation = t.createAnimation(_this.config, _this), _this.tranfromInit(!1).step(), 
                    _this.animation.run(), _this.$emit("change", {
                        detail: _this.isShow
                    });
                }, 20);
            });
        },
        close: function close(t) {
            var _this2 = this;
            this.animation && this.tranfromInit(!0).step().run(function() {
                _this2.isShow = !1, _this2.animationData = null, _this2.animation = null;
                var _this2$styleInit = _this2.styleInit(!1), t = _this2$styleInit.opacity, i = _this2$styleInit.transform;
                _this2.opacity = t || 1, _this2.transform = i, _this2.$emit("change", {
                    detail: _this2.isShow
                });
            });
        },
        styleInit: function styleInit(t) {
            var _this3 = this;
            var i = {
                transform: ""
            }, s = function s(t, _s2) {
                "fade" === _s2 ? i.opacity = _this3.animationType(t)[_s2] : i.transform += _this3.animationType(t)[_s2] + " ";
            };
            return "string" == typeof this.modeClass ? s(t, this.modeClass) : this.modeClass.forEach(function(i) {
                s(t, i);
            }), i;
        },
        tranfromInit: function tranfromInit(t) {
            var _this4 = this;
            var i = function i(t, _i2) {
                var s = null;
                "fade" === _i2 ? s = t ? 0 : 1 : (s = t ? "-100%" : "0", "zoom-in" === _i2 && (s = t ? .8 : 1), 
                "zoom-out" === _i2 && (s = t ? 1.2 : 1), "slide-right" === _i2 && (s = t ? "100%" : "0"), 
                "slide-bottom" === _i2 && (s = t ? "100%" : "0")), _this4.animation[_this4.animationMode()[_i2]](s);
            };
            return "string" == typeof this.modeClass ? i(t, this.modeClass) : this.modeClass.forEach(function(s) {
                i(t, s);
            }), this.animation;
        },
        animationType: function animationType(t) {
            return {
                fade: t ? 1 : 0,
                "slide-top": "translateY(".concat(t ? "0" : "-100%", ")"),
                "slide-right": "translateX(".concat(t ? "0" : "100%", ")"),
                "slide-bottom": "translateY(".concat(t ? "0" : "100%", ")"),
                "slide-left": "translateX(".concat(t ? "0" : "-100%", ")"),
                "zoom-in": "scaleX(".concat(t ? 1 : .8, ") scaleY(").concat(t ? 1 : .8, ")"),
                "zoom-out": "scaleX(".concat(t ? 1 : 1.2, ") scaleY(").concat(t ? 1 : 1.2, ")")
            };
        },
        animationMode: function animationMode() {
            return {
                fade: "opacity",
                "slide-top": "translateY",
                "slide-right": "translateX",
                "slide-bottom": "translateY",
                "slide-left": "translateX",
                "zoom-in": "scale",
                "zoom-out": "scale"
            };
        },
        toLine: function toLine(t) {
            return t.replace(/([A-Z])/g, "-$1").toLowerCase();
        }
    }
};

var e = i._export_sfc(s, [ [ "render", function(t, s, e, a, n, o) {
    return i.e({
        a: n.isShow || e.onceRender
    }, n.isShow || e.onceRender ? {
        b: n.isShow,
        c: n.animationData,
        d: i.n(e.customClass),
        e: i.s(o.transformStyles),
        f: i.o(function() {
            return o.onClick && o.onClick.apply(o, arguments);
        })
    } : {});
} ] ]);

wx.createComponent(e);