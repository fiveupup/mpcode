var _slicedToArray2 = require("../../../../@babel/runtime/helpers/slicedToArray");

var t = require("../../../../common/vendor.js"), e = {
    name: "UniListItem",
    emits: [ "click", "switchChange" ],
    props: {
        direction: {
            type: String,
            default: "row"
        },
        title: {
            type: String,
            default: ""
        },
        note: {
            type: String,
            default: ""
        },
        ellipsis: {
            type: [ Number, String ],
            default: 0
        },
        disabled: {
            type: [ Boolean, String ],
            default: !1
        },
        clickable: {
            type: Boolean,
            default: !1
        },
        showArrow: {
            type: [ Boolean, String ],
            default: !1
        },
        link: {
            type: [ Boolean, String ],
            default: !1
        },
        to: {
            type: String,
            default: ""
        },
        showBadge: {
            type: [ Boolean, String ],
            default: !1
        },
        showSwitch: {
            type: [ Boolean, String ],
            default: !1
        },
        switchChecked: {
            type: [ Boolean, String ],
            default: !1
        },
        badgeText: {
            type: String,
            default: ""
        },
        badgeType: {
            type: String,
            default: "success"
        },
        badgeStyle: {
            type: Object,
            default: function _default() {
                return {};
            }
        },
        rightText: {
            type: String,
            default: ""
        },
        thumb: {
            type: String,
            default: ""
        },
        thumbSize: {
            type: String,
            default: "base"
        },
        showExtraIcon: {
            type: [ Boolean, String ],
            default: !1
        },
        extraIcon: {
            type: Object,
            default: function _default() {
                return {
                    type: "",
                    color: "#000000",
                    size: 20,
                    customPrefix: ""
                };
            }
        },
        border: {
            type: Boolean,
            default: !0
        },
        customStyle: {
            type: Object,
            default: function _default() {
                return {
                    padding: "",
                    backgroundColor: "#FFFFFF"
                };
            }
        },
        keepScrollPosition: {
            type: Boolean,
            default: !1
        }
    },
    watch: {
        "customStyle.padding": {
            handler: function handler(t) {
                "number" == typeof t && (t += "");
                var e = t.split(" ");
                if (1 === e.length) {
                    var _t = e[0];
                    this.padding = {
                        top: _t,
                        right: _t,
                        bottom: _t,
                        left: _t
                    };
                } else if (2 === e.length) {
                    var _e = _slicedToArray2(e, 2), _t2 = _e[0], _i = _e[1];
                    this.padding = {
                        top: _t2,
                        right: _i,
                        bottom: _t2,
                        left: _i
                    };
                } else if (4 === e.length) {
                    var _e2 = _slicedToArray2(e, 4), _t3 = _e2[0], _i2 = _e2[1], o = _e2[2], n = _e2[3];
                    this.padding = {
                        top: _t3,
                        right: _i2,
                        bottom: o,
                        left: n
                    };
                }
            },
            immediate: !0
        }
    },
    data: function data() {
        return {
            isFirstChild: !1,
            padding: {
                top: "",
                right: "",
                bottom: "",
                left: ""
            }
        };
    },
    mounted: function mounted() {
        this.list = this.getForm(), this.list && (this.list.firstChildAppend || (this.list.firstChildAppend = !0, 
        this.isFirstChild = !0));
    },
    methods: {
        getForm: function getForm() {
            var t = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : "uniList";
            var e = this.$parent, i = e.$options.name;
            for (;i !== t; ) {
                if (e = e.$parent, !e) return !1;
                i = e.$options.name;
            }
            return e;
        },
        onClick: function onClick() {
            "" === this.to ? (this.clickable || this.link) && this.$emit("click", {
                data: {}
            }) : this.openPage();
        },
        onSwitchChange: function onSwitchChange(t) {
            this.$emit("switchChange", t.detail);
        },
        openPage: function openPage() {
            -1 !== [ "navigateTo", "redirectTo", "reLaunch", "switchTab" ].indexOf(this.link) ? this.pageApi(this.link) : this.pageApi("navigateTo");
        },
        pageApi: function pageApi(e) {
            var _this = this;
            var i = {
                url: this.to,
                success: function success(t) {
                    _this.$emit("click", {
                        data: t
                    });
                },
                fail: function fail(t) {
                    _this.$emit("click", {
                        data: t
                    });
                }
            };
            switch (e) {
              case "navigateTo":
              default:
                t.index.navigateTo(i);
                break;

              case "redirectTo":
                t.index.redirectTo(i);
                break;

              case "reLaunch":
                t.index.reLaunch(i);
                break;

              case "switchTab":
                t.index.switchTab(i);
            }
        }
    }
};

if (!Array) {
    (t.resolveComponent("uni-icons") + t.resolveComponent("uni-badge"))();
}

Math || (function() {
    return "../../../uni-icons/components/uni-icons/uni-icons.js";
} + function() {
    return "../../../uni-badge/components/uni-badge/uni-badge.js";
})();

var i = t._export_sfc(e, [ [ "render", function(e, i, o, n, s, a) {
    return t.e({
        a: !s.isFirstChild
    }, s.isFirstChild ? {} : {
        b: o.border ? 1 : ""
    }, {
        c: o.thumb
    }, o.thumb ? {
        d: o.thumb,
        e: t.n("uni-list--" + o.thumbSize)
    } : o.showExtraIcon ? {
        g: t.p({
            customPrefix: o.extraIcon.customPrefix,
            color: o.extraIcon.color,
            size: o.extraIcon.size,
            type: o.extraIcon.type
        })
    } : {}, {
        f: o.showExtraIcon,
        h: o.title
    }, o.title ? {
        i: t.t(o.title),
        j: t.n(0 !== o.ellipsis && o.ellipsis <= 2 ? "uni-ellipsis-" + o.ellipsis : "")
    } : {}, {
        k: o.note
    }, o.note ? {
        l: t.t(o.note)
    } : {}, {
        m: o.thumb || o.showExtraIcon || o.showBadge || o.showSwitch ? 1 : "",
        n: o.rightText || o.showBadge || o.showSwitch
    }, o.rightText || o.showBadge || o.showSwitch ? t.e({
        o: o.rightText
    }, o.rightText ? {
        p: t.t(o.rightText)
    } : {}, {
        q: o.showBadge
    }, o.showBadge ? {
        r: t.p({
            type: o.badgeType,
            text: o.badgeText,
            "custom-style": o.badgeStyle
        })
    } : {}, {
        s: o.showSwitch
    }, o.showSwitch ? {
        t: o.disabled,
        v: o.switchChecked,
        w: t.o(function() {
            return a.onSwitchChange && a.onSwitchChange.apply(a, arguments);
        })
    } : {}, {
        x: "column" === o.direction ? 1 : ""
    }) : {}, {
        y: o.showArrow || o.link ? 1 : "",
        z: "column" === o.direction ? 1 : "",
        A: s.padding.top,
        B: s.padding.left,
        C: s.padding.right,
        D: s.padding.bottom,
        E: o.showArrow || o.link
    }, o.showArrow || o.link ? {
        F: t.p({
            size: 16,
            color: "#bbb",
            type: "arrowright"
        })
    } : {}, {
        G: o.disabled ? 1 : "",
        H: o.customStyle.backgroundColor,
        I: !o.clickable && !o.link || o.disabled || o.showSwitch ? "" : "uni-list-item--hover",
        J: t.o(function() {
            return a.onClick && a.onClick.apply(a, arguments);
        })
    });
} ] ]);

wx.createComponent(i);