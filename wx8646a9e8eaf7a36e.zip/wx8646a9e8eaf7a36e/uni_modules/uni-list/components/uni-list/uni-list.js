var e = require("../../../../common/vendor.js"), o = {
    name: "uniList",
    "mp-weixin": {
        options: {
            multipleSlots: !1
        }
    },
    props: {
        stackFromEnd: {
            type: Boolean,
            default: !1
        },
        enableBackToTop: {
            type: [ Boolean, String ],
            default: !1
        },
        scrollY: {
            type: [ Boolean, String ],
            default: !1
        },
        border: {
            type: Boolean,
            default: !0
        },
        renderReverse: {
            type: Boolean,
            default: !1
        }
    },
    created: function created() {
        this.firstChildAppend = !1;
    },
    methods: {
        loadMore: function loadMore(e) {
            this.$emit("scrolltolower");
        },
        scroll: function scroll(e) {
            this.$emit("scroll", e);
        }
    }
};

var r = e._export_sfc(o, [ [ "render", function(o, r, t, l, n, s) {
    return e.e({
        a: t.border
    }, (t.border, {}), {
        b: t.border
    }, (t.border, {}));
} ] ]);

wx.createComponent(r);