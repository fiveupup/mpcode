var e = require("../../../../common/vendor.js"), t = {
    name: "UniGrid",
    emits: [ "change" ],
    props: {
        column: {
            type: Number,
            default: 3
        },
        showBorder: {
            type: Boolean,
            default: !0
        },
        borderColor: {
            type: String,
            default: "#D2D2D2"
        },
        square: {
            type: Boolean,
            default: !0
        },
        highlight: {
            type: Boolean,
            default: !0
        }
    },
    provide: function provide() {
        return {
            grid: this
        };
    },
    data: function data() {
        return {
            elId: "Uni_".concat(Math.ceil(1e6 * Math.random()).toString(36)),
            width: 0
        };
    },
    created: function created() {
        this.children = [];
    },
    mounted: function mounted() {
        var _this = this;
        this.$nextTick(function() {
            _this.init();
        });
    },
    methods: {
        init: function init() {
            var _this2 = this;
            setTimeout(function() {
                _this2._getSize(function(e) {
                    _this2.children.forEach(function(t, i) {
                        t.width = e;
                    });
                });
            }, 50);
        },
        change: function change(e) {
            this.$emit("change", e);
        },
        _getSize: function _getSize(t) {
            var _this3 = this;
            e.index.createSelectorQuery().in(this).select("#".concat(this.elId)).boundingClientRect().exec(function(e) {
                _this3.width = parseInt((e[0].width - 1) / _this3.column) + "px", t(_this3.width);
            });
        }
    }
};

var i = e._export_sfc(t, [ [ "render", function(e, t, i, r, n, o) {
    return {
        a: n.elId,
        b: i.showBorder ? 1 : "",
        c: i.borderColor
    };
} ] ]);

wx.createComponent(i);