var e = {
    en: {
        "uni-search-bar.cancel": "cancel",
        "uni-search-bar.placeholder": "Search enter content"
    },
    "zh-Hans": {
        "uni-search-bar.cancel": "cancel",
        "uni-search-bar.placeholder": "请输入搜索内容"
    },
    "zh-Hant": {
        "uni-search-bar.cancel": "cancel",
        "uni-search-bar.placeholder": "請輸入搜索內容"
    }
};

exports.messages = e;