exports.getComponent = function(t, e) {
    var n = null;
    return n = t.selectComponent && t.selectComponent(e) && t.selectComponent(e).$vm, 
    n;
}, exports.getContext = function() {
    var t = getCurrentPages();
    return t[t.length - 1];
};