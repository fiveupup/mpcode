var e = require("../../common/vendor.js"), n = require("../../libs/request.js"), o = require("../../config/config.js"), s = require("../../libs/user.js");

require("../../config/zhengfangwei_config.js");

var i = "", a = !1;

var c = {
    data: function data() {
        return {
            app_name: "",
            login_success: !1
        };
    },
    onLoad: function onLoad(e) {
        i = e.scene, s.isLogin() || s.login(), this.app_name = o.Config.wxAppName();
    },
    methods: {
        handleConfirm: function handleConfirm() {
            var _this = this;
            a || (i ? (a = !0, e.index.showLoading({
                title: ""
            }), n.request({
                method: "POST",
                url: "/wechat/login.MiniScanLogin/confirmLogin",
                data: {
                    code: i
                },
                success: function success(n) {
                    n.status ? (_this.login_success = !0, e.index.showToast({
                        title: "授权成功"
                    })) : e.index.showToast({
                        title: n.msg,
                        icon: "error"
                    });
                },
                fail: function fail(e) {
                    console.error(e);
                },
                complete: function complete() {
                    a = !1, e.index.hideLoading();
                }
            })) : e.index.showToast({
                title: "参数异常，请重新扫码",
                icon: "error"
            }));
        },
        handleCancel: function handleCancel() {
            e.index.redirectTo({
                url: "/pages/index/index"
            });
        }
    }
};

var r = e._export_sfc(c, [ [ "render", function(n, o, s, i, a, c) {
    return e.e({
        a: a.login_success
    }, a.login_success ? {} : {
        b: e.t(a.app_name)
    }, {
        c: e.t(a.app_name),
        d: a.login_success
    }, a.login_success ? {
        e: e.o(function() {
            return c.handleCancel && c.handleCancel.apply(c, arguments);
        })
    } : {
        f: e.o(function() {
            return c.handleConfirm && c.handleConfirm.apply(c, arguments);
        }),
        g: e.o(function() {
            return c.handleCancel && c.handleCancel.apply(c, arguments);
        })
    });
} ], [ "__scopeId", "data-v-90076ffd" ] ]);

wx.createPage(r);