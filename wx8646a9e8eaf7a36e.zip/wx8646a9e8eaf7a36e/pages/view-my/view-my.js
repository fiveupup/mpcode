var e = require("../../common/vendor.js"), i = require("../../libs/recenet_visit.js"), t = require("../../libs/resource.js"), s = require("../../libs/format.js"), n = {
    data: function data() {
        return {
            loading: !0,
            items: []
        };
    },
    onLoad: function onLoad(e) {
        this.fetchList();
    },
    methods: {
        clickItem: function clickItem(i) {
            e.index.navigateTo({
                url: "/pages/file/file?uuid=" + i.uuid + "&skip_ad=true"
            });
        },
        fetchList: function fetchList() {
            var _this = this;
            i.getVisitFiles().reverse().forEach(function(e) {
                e.file_ext_url = t.getIconURI(e.file_ext);
                var i = s.formatBytes(e.file_size);
                e.file_size_format_value = i.val, e.file_size_format_unit = i.unit, _this.items.push(e);
            }), this.loading = !1;
        }
    }
};

if (!Array) {
    (e.resolveComponent("uni-icons") + e.resolveComponent("uni-list-item") + e.resolveComponent("uni-list"))();
}

Math || (function() {
    return "../../uni_modules/uni-icons/components/uni-icons/uni-icons.js";
} + function() {
    return "../../uni_modules/uni-list/components/uni-list-item/uni-list-item.js";
} + function() {
    return "../../uni_modules/uni-list/components/uni-list/uni-list.js";
})();

var o = e._export_sfc(n, [ [ "render", function(i, t, s, n, o, l) {
    return e.e({
        a: e.f(o.items, function(i, t, s) {
            return {
                a: i.file_ext_url,
                b: e.t(i.file_name),
                c: e.t(i.visit_time),
                d: e.t(i.file_size_format_value),
                e: e.t(i.file_size_format_unit),
                f: "9e831d44-2-" + s + ",9e831d44-1-" + s,
                g: t,
                h: e.o(function(e) {
                    return l.clickItem(i);
                }, t),
                i: "9e831d44-1-" + s + ",9e831d44-0"
            };
        }),
        b: e.p({
            type: "right",
            size: "24",
            color: "grey"
        }),
        c: e.p({
            border: !0,
            clickable: !0
        }),
        d: o.loading
    }, (o.loading, {}), {
        e: !o.loading && 0 === o.items.length
    }, (o.loading || o.items.length, {}));
} ], [ "__scopeId", "data-v-9e831d44" ] ]);

wx.createPage(o);