var e = require("../../common/vendor.js"), i = require("../../config/config.js"), n = require("../../libs/web_url.js");

require("../../config/zhengfangwei_config.js");

var t = {
    data: function data() {
        return {
            currentTabIndex: -1,
            file_uuid: "",
            pcUploadUrl: i.Config.pcUploadUrl()
        };
    },
    onLoad: function onLoad(e) {
        var _this = this;
        this.file_uuid = e.uuid || "", parseInt(e.type) >= 0 ? this.currentTabIndex = parseInt(e.type) : this.currentTabIndex = 1, 
        1 === this.currentTabIndex && setTimeout(function() {
            _this.copyMiniDirectPath();
        }, 500);
    },
    methods: {
        onClickItem: function onClickItem(e) {
            this.currentTabIndex !== e.currentIndex && (this.currentTabIndex = e.currentIndex);
        },
        onClickToCopyMiniDirectPath: function onClickToCopyMiniDirectPath() {
            this.copyMiniDirectPath(!0);
        },
        copyMiniAppId: function copyMiniAppId() {
            e.index.setClipboardData({
                data: i.Config.wxAppId()
            });
        },
        copyMiniPath: function copyMiniPath() {
            e.index.setClipboardData({
                data: "pages/file/file?uuid=" + this.file_uuid
            });
        },
        copyMiniDirectPath: function copyMiniDirectPath() {
            var t = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : !1;
            var o = i.Config.masterWxApp(), r = "/pages/webview/webview?url=" + encodeURIComponent(n.createDirectPathURL(i.Config.wxAppId(), i.Config.wxAppName(), this.file_uuid));
            t && e.wx$1.openEmbeddedMiniProgram({
                appId: o.wxAppId,
                path: r
            });
        },
        copyURL: function copyURL() {
            e.index.setClipboardData({
                data: this.pcUploadUrl,
                success: function success() {
                    e.index.showModal({
                        title: "提示",
                        content: "请到电脑浏览器访问",
                        showCancel: !1
                    });
                }
            });
        }
    }
};

if (!Array) {
    (e.resolveComponent("ws-wx-privacy") + e.resolveComponent("uni-segmented-control"))();
}

Math || (function() {
    return "../../components/ws-wx-privacy/ws-wx-privacy.js";
} + function() {
    return "../../uni_modules/uni-segmented-control/components/uni-segmented-control/uni-segmented-control.js";
})();

var o = e._export_sfc(t, [ [ "render", function(i, n, t, o, r, c) {
    return e.e({
        a: e.p({
            id: "privacy-popup"
        }),
        b: e.o(c.onClickItem),
        c: e.p({
            current: r.currentTabIndex,
            values: [ "小程序路径", "直达链接" ],
            "style-type": "text",
            "active-color": "#67c23a"
        }),
        d: 0 == r.currentTabIndex
    }, 0 == r.currentTabIndex ? {
        e: e.o(function() {
            return c.copyMiniAppId && c.copyMiniAppId.apply(c, arguments);
        }),
        f: e.o(function() {
            return c.copyMiniPath && c.copyMiniPath.apply(c, arguments);
        })
    } : {}, {
        g: 1 == r.currentTabIndex
    }, 1 == r.currentTabIndex ? {
        h: e.o(function() {
            return c.onClickToCopyMiniDirectPath && c.onClickToCopyMiniDirectPath.apply(c, arguments);
        }),
        i: e.t(r.pcUploadUrl),
        j: e.o(function() {
            return c.copyURL && c.copyURL.apply(c, arguments);
        })
    } : {});
} ], [ "__scopeId", "data-v-b0dbc529" ] ]);

wx.createPage(o);