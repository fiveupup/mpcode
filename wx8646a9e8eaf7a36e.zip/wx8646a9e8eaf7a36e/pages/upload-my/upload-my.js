var e = require("../../common/vendor.js"), i = require("../../libs/request.js"), t = require("../../libs/resource.js"), s = require("../../libs/user.js"), o = require("../../config/config.js"), n = require("../../libs/format.js");

require("../../config/zhengfangwei_config.js");

var l = {
    data: function data() {
        return {
            search_file_name: "",
            page: 1,
            noMore: !1,
            items: [],
            selectItem: {
                file_name: ""
            },
            selectItemIndex: -1
        };
    },
    onLoad: function onLoad(e) {
        var _this = this;
        s.isLogin() ? this.fetchList(1) : s.login(function() {
            _this.fetchList(1);
        });
    },
    onReachBottom: function onReachBottom() {
        this.noMore || this.fetchList(this.page + 1);
    },
    methods: {
        search: function search(_ref) {
            var e = _ref.value;
            this.search_file_name = e, this.items = [], this.fetchList(1);
        },
        clickItem: function clickItem(e, i) {
            this.selectItem = e, this.selectItemIndex = i, this.$refs.popup.open("bottom");
        },
        closePopup: function closePopup() {
            this.$refs.popup.close();
        },
        fetchList: function fetchList(s) {
            var _this2 = this;
            e.index.showLoading({
                title: "加载中..."
            }), i.request({
                url: "/api/pc/myUploadFiles",
                data: {
                    page: s,
                    file_name: this.search_file_name
                },
                success: function success(e) {
                    e.status && e.data.items.length > 0 ? (e.data.items.forEach(function(e) {
                        e.file_ext_url = t.getIconURI(e.file_ext);
                        var i = n.formatBytes(e.file_size);
                        e.file_size_format_value = i.val, e.file_size_format_unit = i.unit, _this2.items.push(e);
                    }), _this2.page = e.data.page, _this2.noMore = e.data.items.length !== e.data.page_size) : _this2.noMore = !0;
                },
                complete: function complete() {
                    e.index.hideLoading();
                }
            });
        },
        handleViewFile: function handleViewFile() {
            e.index.navigateTo({
                url: "/pages/file/file?uuid=" + this.selectItem.file_uuid + "&skip_ad=true"
            }), this.closePopup();
        },
        handleCopyMiniPath: function handleCopyMiniPath() {
            e.index.setClipboardData({
                data: "pages/file/file?uuid=" + this.selectItem.file_uuid
            }), this.closePopup();
        },
        handleCopyMiniDirectPath: function handleCopyMiniDirectPath() {
            e.index.navigateTo({
                url: "/pages/upload-copy-path/upload-copy-path?type=1&uuid=" + this.selectItem.file_uuid
            }), this.closePopup();
        },
        handleGenerateMiniCode: function handleGenerateMiniCode() {
            e.index.showLoading({
                title: "加载中..."
            }), i.request({
                url: "/api/file/getMiniCode",
                data: {
                    appid: o.Config.wxAppId(),
                    uuid: this.selectItem.file_uuid
                },
                success: function success(i) {
                    i.status ? e.index.previewImage({
                        urls: [ i.data.qrcode_url ]
                    }) : e.index.showToast({
                        icon: "error",
                        title: "生成失败"
                    });
                },
                complete: function complete() {
                    e.index.hideLoading();
                }
            }), this.closePopup();
        },
        handleDelFile: function handleDelFile() {
            var _this3 = this;
            this.closePopup(), e.index.showModal({
                title: "删除确认",
                content: "文件删除后将无法访问和下载",
                confirmText: "确认删除",
                success: function success(e) {
                    e.confirm ? _this3.doDelFile() : e.cancel;
                }
            });
        },
        doDelFile: function doDelFile() {
            var _this4 = this;
            i.request({
                method: "POST",
                url: "/api/file/delFile",
                data: {
                    uuid: this.selectItem.file_uuid
                },
                success: function success(i) {
                    i.status ? (e.index.showToast({
                        title: "删除成功"
                    }), _this4.items.splice(_this4.selectItemIndex, 1)) : e.index.showToast({
                        icon: "error",
                        title: "删除失败"
                    });
                }
            });
        }
    }
};

if (!Array) {
    (e.resolveComponent("ws-wx-privacy") + e.resolveComponent("uni-search-bar") + e.resolveComponent("uni-icons") + e.resolveComponent("uni-list-item") + e.resolveComponent("uni-list") + e.resolveComponent("uni-load-more") + e.resolveComponent("uni-popup"))();
}

Math || (function() {
    return "../../components/ws-wx-privacy/ws-wx-privacy.js";
} + function() {
    return "../../uni_modules/uni-search-bar/components/uni-search-bar/uni-search-bar.js";
} + function() {
    return "../../uni_modules/uni-icons/components/uni-icons/uni-icons.js";
} + function() {
    return "../../uni_modules/uni-list/components/uni-list-item/uni-list-item.js";
} + function() {
    return "../../uni_modules/uni-list/components/uni-list/uni-list.js";
} + function() {
    return "../../uni_modules/uni-load-more/components/uni-load-more/uni-load-more.js";
} + function() {
    return "../../uni_modules/uni-popup/components/uni-popup/uni-popup.js";
})();

var a = e._export_sfc(l, [ [ "render", function(i, t, s, o, n, l) {
    return {
        a: e.p({
            id: "privacy-popup"
        }),
        b: e.o(l.search),
        c: e.p({
            radius: "5",
            placeholder: "搜索文件名",
            clearButton: "auto"
        }),
        d: e.f(n.items, function(i, t, s) {
            return {
                a: i.file_ext_url,
                b: e.t(i.file_name),
                c: e.t(i.create_time),
                d: e.t(i.file_size_format_value),
                e: e.t(i.file_size_format_unit),
                f: "b61c0c9b-4-" + s + ",b61c0c9b-3-" + s,
                g: t,
                h: e.o(function(e) {
                    return l.clickItem(i, t);
                }, t),
                i: "b61c0c9b-3-" + s + ",b61c0c9b-2"
            };
        }),
        e: e.p({
            type: "settings",
            size: "24",
            color: "grey"
        }),
        f: e.p({
            border: !0,
            clickable: !0
        }),
        g: e.p({
            status: n.noMore ? "noMore" : "loading"
        }),
        h: e.t(n.selectItem.file_name),
        i: e.o(function() {
            return l.handleViewFile && l.handleViewFile.apply(l, arguments);
        }),
        j: e.o(function() {
            return l.handleCopyMiniPath && l.handleCopyMiniPath.apply(l, arguments);
        }),
        k: e.o(function() {
            return l.handleCopyMiniDirectPath && l.handleCopyMiniDirectPath.apply(l, arguments);
        }),
        l: e.o(function() {
            return l.handleGenerateMiniCode && l.handleGenerateMiniCode.apply(l, arguments);
        }),
        m: e.o(function() {
            return l.handleDelFile && l.handleDelFile.apply(l, arguments);
        }),
        n: e.o(function() {
            return l.closePopup && l.closePopup.apply(l, arguments);
        }),
        o: e.sr("popup", "b61c0c9b-6")
    };
} ], [ "__scopeId", "data-v-b61c0c9b" ] ]);

wx.createPage(a);