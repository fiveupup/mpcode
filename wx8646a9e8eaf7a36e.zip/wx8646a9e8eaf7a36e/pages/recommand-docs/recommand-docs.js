var e = require("../../common/vendor.js"), i = require("../../libs/request.js"), s = require("../../libs/resource.js");

require("../../config/config.js"), require("../../config/zhengfangwei_config.js"), 
require("../../libs/user.js");

var n = {
    data: function data() {
        return {
            searchValue: "",
            lists: []
        };
    },
    onLoad: function onLoad(e) {
        this.fetchFiles();
    },
    mounted: function mounted() {},
    methods: {
        search: function search(i) {
            e.index.showToast({
                title: "搜索：" + i.value,
                icon: "none"
            });
        },
        clickItem: function clickItem(i) {
            e.index.navigateTo({
                url: "/pages/file/file?uuid=" + i.uuid + "&skip_ad=true"
            });
        },
        fetchFiles: function fetchFiles() {
            var _this = this;
            i.request({
                url: "/api/file/recommendFile",
                data: {
                    file_name: this.searchValue
                },
                success: function success(e) {
                    if (e.status) {
                        var _i = e.data;
                        for (var _e = 0; _e < _i.length; _e++) _i[_e].icon = s.getIconURI(_i[_e].file_ext);
                        _this.lists = _i;
                    }
                }
            });
        },
        doSearch: function doSearch() {
            this.fetchFiles();
        }
    }
};

if (!Array) {
    (e.resolveComponent("uni-search-bar") + e.resolveComponent("uni-icons") + e.resolveComponent("uni-list-item") + e.resolveComponent("uni-list"))();
}

Math || (function() {
    return "../../uni_modules/uni-search-bar/components/uni-search-bar/uni-search-bar.js";
} + function() {
    return "../../uni_modules/uni-icons/components/uni-icons/uni-icons.js";
} + function() {
    return "../../uni_modules/uni-list/components/uni-list-item/uni-list-item.js";
} + function() {
    return "../../uni_modules/uni-list/components/uni-list/uni-list.js";
})();

var o = e._export_sfc(n, [ [ "render", function(i, s, n, o, t, u) {
    return {
        a: e.o(u.doSearch),
        b: e.o(function(e) {
            return t.searchValue = e;
        }),
        c: e.p({
            modelValue: t.searchValue
        }),
        d: e.f(t.lists, function(i, s, n) {
            return {
                a: i.icon,
                b: e.t(i.file_name),
                c: "e6b9e776-3-" + n + ",e6b9e776-2-" + n,
                d: i.uuid,
                e: e.o(function(e) {
                    return u.clickItem(i);
                }, i.uuid),
                f: "e6b9e776-2-" + n + ",e6b9e776-1"
            };
        }),
        e: e.p({
            type: "right",
            size: "24",
            color: "grey"
        }),
        f: e.p({
            border: !0,
            clickable: !0
        })
    };
} ], [ "__scopeId", "data-v-e6b9e776" ] ]);

wx.createPage(o);