var o = require("../../common/vendor.js"), e = require("../../config/config.js");

require("../../config/zhengfangwei_config.js");

var c = {
    data: function data() {
        return {
            pcUploadUrl: e.Config.pcUploadUrl()
        };
    },
    methods: {
        copyURL: function copyURL() {
            o.index.setClipboardData({
                data: this.pcUploadUrl,
                success: function success() {
                    o.index.showModal({
                        title: "提示",
                        content: "已复制，请到浏览器访问",
                        showCancel: !1
                    });
                }
            });
        }
    }
};

if (!Array) {
    o.resolveComponent("ws-wx-privacy")();
}

Math;

var r = o._export_sfc(c, [ [ "render", function(e, c, r, n, t, a) {
    return {
        a: o.p({
            id: "privacy-popup"
        }),
        b: o.t(t.pcUploadUrl),
        c: o.o(function() {
            return a.copyURL && a.copyURL.apply(a, arguments);
        })
    };
} ] ]);

wx.createPage(r);