var o = require("../../common/vendor.js"), e = require("../../libs/request.js");

require("../../config/config.js"), require("../../config/zhengfangwei_config.js"), 
require("../../libs/user.js");

var s = {
    data: function data() {
        return {
            upload_procent: -1
        };
    },
    methods: {
        gotoUploadPC: function gotoUploadPC() {
            o.index.redirectTo({
                url: "/pages/upload-pc/upload-pc"
            });
        },
        clickUpload: function clickUpload() {
            this.fetchUploadConfig();
        },
        fetchUploadConfig: function fetchUploadConfig() {
            var _this = this;
            e.request({
                url: "/api/upload/getMiniUploadConfig",
                success: function success(e) {
                    console.log("fetchUploadConfig", e), e.status ? _this.chooseMessageFile(e.data) : o.index.showToast({
                        title: e.msg
                    });
                }
            });
        },
        chooseMessageFile: function chooseMessageFile(e) {
            var _this2 = this;
            var s = e.allow_suffix.split(",") || [ "doc", "docx", "xls", "xlsx", "ppt", "pptx", "pdf" ];
            console.log("chooseMessageFile", s), o.wx$1.chooseMessageFile({
                count: 1,
                type: "file",
                extension: s,
                success: function success(o) {
                    console.log("chooseMessageFile", o), o.tempFiles.length > 0 && _this2.doUploadFile(o.tempFiles[0], e);
                }
            });
        },
        doUploadFile: function doUploadFile(e, s) {
            var _this3 = this;
            var l = {
                "x:custom_file_name": e.name,
                key: s.key,
                token: s.upload_token
            };
            o.index.showLoading({
                title: "上传中"
            }), console.log("doUploadFile", l), this.upload_procent = 10, o.wx$1.uploadFile({
                url: s.upload_url,
                filePath: e.path,
                name: "file",
                formData: l,
                success: function success(o) {
                    try {
                        var e = JSON.parse(o.data);
                        _this3.onUploadSuccess(e);
                    } catch (s) {
                        console.log("parse JSON failed, origin String is: " + o.data), _this3.onUploadFaild(s);
                    }
                },
                fail: function fail(e) {
                    console.error(e), o.index.hideLoading(), _this3.onUploadFaild(e);
                },
                complete: function complete() {}
            }).onProgressUpdate(function(o) {
                _this3.onUploadProgressUpdate(o);
            });
        },
        bindUploadFile: function bindUploadFile(s) {
            var _this4 = this;
            e.request({
                method: "POST",
                url: "/api/pc/batchSaveUploadFile",
                data: {
                    file_uuids: [ s.uuid ]
                },
                success: function success(e) {
                    e.status ? (_this4.upload_procent = 100, o.index.redirectTo({
                        url: "/pages/upload-my/upload-my"
                    })) : o.index.showToast({
                        title: e.msg,
                        icon: "error"
                    });
                },
                complete: function complete() {
                    _this4.upload_procent = -1, o.index.hideLoading();
                }
            });
        },
        onUploadProgressUpdate: function onUploadProgressUpdate(o) {
            console.log("onUploadProgressUpdate", o), this.upload_procent = parseInt(o.progress);
        },
        onUploadSuccess: function onUploadSuccess(e) {
            console.log("onUploadSuccess", e), e.status ? this.bindUploadFile(e.data) : o.index.showToast({
                title: e.msg,
                icon: "error"
            });
        },
        onUploadFaild: function onUploadFaild(e) {
            this.upload_procent = -1, o.index.showToast({
                title: "上传失败",
                icon: "error"
            });
        }
    }
};

if (!Array) {
    o.resolveComponent("ws-wx-privacy")();
}

Math;

var l = o._export_sfc(s, [ [ "render", function(e, s, l, a, i, t) {
    return o.e({
        a: o.p({
            id: "privacy-popup"
        }),
        b: i.upload_procent > 0
    }, i.upload_procent > 0 ? {
        c: i.upload_procent
    } : {}, {
        d: o.o(function() {
            return t.clickUpload && t.clickUpload.apply(t, arguments);
        }),
        e: o.o(function() {
            return t.gotoUploadPC && t.gotoUploadPC.apply(t, arguments);
        })
    });
} ] ]);

wx.createPage(l);