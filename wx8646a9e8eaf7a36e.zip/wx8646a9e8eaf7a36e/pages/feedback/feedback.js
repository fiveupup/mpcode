var e = require("../../common/vendor.js"), t = require("../../libs/request.js"), n = require("../../config/config.js");

require("../../libs/user.js"), require("../../config/zhengfangwei_config.js");

var o = "";

var i = {
    data: function data() {
        return {
            content: ""
        };
    },
    onLoad: function onLoad(e) {
        o = e.file_uuid;
    },
    computed: {
        enableSubmit: function enableSubmit() {
            return this.content.length > 0;
        },
        contentLength: function contentLength() {
            return this.content.length || 0;
        }
    },
    methods: {
        handleSubmit: function handleSubmit() {
            var _this = this;
            t.request({
                method: "POST",
                url: "/api/mini.Feedback/create",
                data: {
                    appid: n.Config.wxAppId(),
                    app_name: n.Config.wxAppName(),
                    object_type: "file",
                    object_id: o,
                    content: this.content
                },
                success: function success(t) {
                    e.index.showToast({
                        title: t.msg
                    }), t.status && (_this.content = "", setTimeout(function() {
                        e.index.navigateBack();
                    }, 1200));
                }
            });
        }
    }
};

if (!Array) {
    e.resolveComponent("uni-easyinput")();
}

Math;

var a = e._export_sfc(i, [ [ "render", function(t, n, o, i, a, c) {
    return {
        a: e.o(function(e) {
            return a.content = e;
        }),
        b: e.p({
            type: "textarea",
            placeholder: "请输入内容",
            maxlength: "200",
            modelValue: a.content
        }),
        c: e.t(c.contentLength),
        d: e.o(function() {
            return c.handleSubmit && c.handleSubmit.apply(c, arguments);
        }),
        e: !c.enableSubmit
    };
} ], [ "__scopeId", "data-v-49076b86" ] ]);

wx.createPage(a);