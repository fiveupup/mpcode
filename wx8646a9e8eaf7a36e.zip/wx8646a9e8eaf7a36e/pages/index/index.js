var e = require("../../common/vendor.js"), o = require("../../config/config.js");

require("../../config/zhengfangwei_config.js");

var n = {
    data: function data() {
        return {
            app_name: " ",
            app_desc: " "
        };
    },
    onLoad: function onLoad() {
        e.index.showShareMenu && e.index.showShareMenu({
            menus: [ "shareAppMessage", "shareTimeline" ]
        }), this.app_name = o.Config.wxAppName(), this.app_desc = o.Config.wxAppDesc();
    },
    methods: {
        navigateTo: function navigateTo(o) {
            e.index.navigateTo({
                url: o
            });
        },
        toPdfConvert: function toPdfConvert(o) {
            e.wx$1.navigateToMiniProgram({
                appId: "wx4095b1145a1332ee",
                extraData: {
                    from: "xfj",
                    type: o
                }
            });
        }
    }
};

if (!Array) {
    (e.resolveComponent("uni-badge") + e.resolveComponent("uni-grid-item") + e.resolveComponent("uni-grid"))();
}

Math || (function() {
    return "../../uni_modules/uni-badge/components/uni-badge/uni-badge.js";
} + function() {
    return "../../uni_modules/uni-grid/components/uni-grid-item/uni-grid-item.js";
} + function() {
    return "../../uni_modules/uni-grid/components/uni-grid/uni-grid.js";
})();

var a = e._export_sfc(n, [ [ "render", function(o, n, a, t, r, i) {
    return {
        a: e.t(r.app_name),
        b: e.t(r.app_desc),
        c: e.p({
            text: "",
            type: "success"
        }),
        d: e.o(function(e) {
            return i.navigateTo("/pages/upload/upload");
        }),
        e: e.p({
            text: "",
            type: "success"
        }),
        f: e.o(function(e) {
            return i.navigateTo("/pages/upload-my/upload-my");
        }),
        g: e.p({
            text: "",
            type: "success"
        }),
        h: e.o(function(e) {
            return i.navigateTo("/pages/view-my/view-my");
        }),
        i: e.p({
            column: 3,
            "show-border": !1,
            square: !1
        }),
        j: e.o(function(e) {
            return i.navigateTo("/pages/recommand-docs/recommand-docs");
        }),
        k: e.o(function(e) {
            return i.navigateTo("/pages/faq/faq");
        }),
        l: e.p({
            column: 3,
            "show-border": !1,
            square: !1
        }),
        m: e.p({
            text: "免费",
            type: "error"
        }),
        n: e.o(function(e) {
            return i.toPdfConvert("word");
        }),
        o: e.p({
            text: "免费",
            type: "error"
        }),
        p: e.o(function(e) {
            return i.toPdfConvert("excel");
        }),
        q: e.p({
            text: "免费",
            type: "error"
        }),
        r: e.o(function(e) {
            return i.toPdfConvert("ppt");
        }),
        s: e.p({
            column: 3,
            "show-border": !1,
            square: !1
        })
    };
} ], [ "__scopeId", "data-v-cffbe104" ] ]);

wx.createPage(a);