var e = require("../../common/vendor.js"), i = require("../../config/config.js"), o = require("../../libs/ad_utils.js"), s = require("../../libs/request.js"), t = require("../../libs/resource.js"), a = require("../../libs/format.js"), l = require("../../libs/recenet_visit.js");

require("../../config/zhengfangwei_config.js"), require("../../libs/user.js");

var d = null, n = {}, r = null;

var h = {
    data: function data() {
        return {
            uuid: "",
            file: {
                uuid: "",
                file_name: "",
                file_size: 0,
                file_size_kb: 0,
                file_size_format_value: "",
                file_size_format_unit: "",
                download_amount: "",
                file_ext: "",
                icon: ""
            },
            fetchStatus: 0,
            fetchErrorMsg: "服务异常，请稍后再试",
            isDownloaded: !1,
            skip_ad: !1,
            show_reward_ad: !1,
            show_embed_ad: !1,
            show_interstitial_ad: !1
        };
    },
    computed: {
        enableViewFile: function enableViewFile() {
            return [ "doc", "docx", "xls", "xlsx", "ppt", "pptx", "pdf" ].indexOf(this.file.file_ext) >= 0;
        }
    },
    onLoad: function onLoad(i) {
        e.index.showShareMenu && e.index.showShareMenu({
            menus: [ "shareAppMessage", "shareTimeline" ]
        }), this.uuid = i.uuid, this.uuid || (this.uuid = i.scene), this.skip_ad = "true" === i.skip_ad, 
        this.skip_ad || this.fetchAdStrategy();
    },
    onReady: function onReady() {
        this.fetchFile();
    },
    onShow: function onShow() {},
    onShareAppMessage: function onShareAppMessage(e) {
        return {
            title: this.file.file_name,
            path: "/pages/file/file?uuid=" + this.uuid
        };
    },
    onShareTimeline: function onShareTimeline() {
        return {
            title: this.file.file_name
        };
    },
    methods: {
        fetchFile: function fetchFile() {
            var _this = this;
            e.index.showLoading(), s.request({
                url: "/api/file/detailV3",
                data: {
                    uuid: this.uuid
                },
                success: function success(i) {
                    if (e.index.hideLoading(), i.status) {
                        i.data.icon = t.getIconURI(i.data.file_ext);
                        var _e = a.formatBytes(i.data.file_size);
                        i.data.file_size_format_value = _e.val, i.data.file_size_format_unit = _e.unit, 
                        _this.file = i.data, _this.fetchStatus = 1;
                    } else _this.fetchErrorMsg = i.msg, _this.fetchStatus = 2;
                }
            });
        },
        fetchAdStrategy: function fetchAdStrategy() {
            var _this2 = this;
            s.request({
                url: "/api/mini.AdStrategy/fileDetail",
                data: {
                    file_uuid: this.uuid,
                    appid: i.Config.wxAppId()
                },
                success: function success(e) {
                    e.status && (_this2.show_reward_ad = !!e.data.show_reward, _this2.show_reward_ad && _this2.rewardedAdInit(), 
                    _this2.show_embed_ad = !!e.data.show_embed, _this2.show_embed_ad && (n = e.data.embed_ad_info), 
                    _this2.show_interstitial_ad = !!e.data.show_interstitial, _this2.show_interstitial_ad && _this2.initInterstitialAd());
                }
            });
        },
        navigateTo: function navigateTo(i) {
            e.index.navigateTo({
                url: i
            });
        },
        redirectTo: function redirectTo(i) {
            e.index.redirectTo({
                url: i
            });
        },
        handleDownloadFile: function handleDownloadFile() {
            console.log("handleDownloadFile"), this.rewardedAdTriggerShow(), this.triggerShowInterstitialAd(), 
            this.doHandleDownloadFile();
        },
        doHandleDownloadFile: function doHandleDownloadFile() {
            var _this3 = this;
            this.cacheDownload({
                success: function success(i) {
                    _this3.isDownloaded = !0, _this3.doDownlog(), e.index.showToast({
                        title: "文件已加载完成"
                    });
                }
            });
        },
        handleViewFile: function handleViewFile() {
            var _this4 = this;
            this.cacheDownload({
                success: function success(e) {
                    _this4.previewFile(e), _this4.triggerShowEmbedAd();
                }
            });
        },
        previewFile: function previewFile(i) {
            var _this5 = this;
            e.wx$1.openDocument ? e.index.openDocument({
                filePath: i,
                fileType: this.file.file_ext,
                showMenu: !0,
                success: function success(e) {
                    console.log("打开文档成功");
                },
                fail: function fail(e) {
                    _this5.saveFileToDisk(i);
                }
            }) : e.index.showToast({
                title: "微信版本过低，无法打开文件",
                icon: "error"
            });
        },
        saveFileToDisk: function saveFileToDisk(i) {
            e.wx$1.saveFileToDisk({
                filePath: i,
                success: function success(i) {
                    console.log(i), e.index.showToast({
                        title: "保存文档成功",
                        icon: "success"
                    });
                },
                fail: function fail(i) {
                    console.log(i);
                    var o = "保存文档失败";
                    "saveFileToDisk:fail user cancel" === i.errMsg && (o = "保存文档已取消"), e.index.showToast({
                        title: o,
                        icon: "error"
                    });
                }
            });
        },
        doDownlog: function doDownlog() {
            l.addVisitFile(this.file), s.request({
                url: "/api/file/log",
                data: {
                    uuid: this.uuid,
                    action: "down"
                }
            });
        },
        initInterstitialAd: function initInterstitialAd() {
            var _this6 = this;
            var s = i.Config.adConfig().interstitialAdId;
            console.log("initInterstitialAd:" + s), e.wx$1.createInterstitialAd && s && (r = e.wx$1.createInterstitialAd({
                adUnitId: s
            }), r.onLoad(function() {
                console.log("interstitialAd::onLoad");
            }), r.onError(function(e) {}), r.onClose(function() {
                o.markAdShowAtFile("InterstitialAd", _this6.file.uuid);
            }));
        },
        showInterstitialAd: function showInterstitialAd() {
            r && r.show().catch(function(e) {
                console.error(e);
            });
        },
        triggerShowInterstitialAd: function triggerShowInterstitialAd() {
            if (!this.show_interstitial_ad) return;
            o.isAdShowedAtFile("InterstitialAd", this.file.uuid) || this.showInterstitialAd();
        },
        handleSaveFile: function handleSaveFile() {
            var i = e.wx$1.getSystemInfoSync();
            "windows" !== i.platform && "mac" !== i.platform && "devtools" !== i.platform ? this.$refs.popup.open("bottom") : this.downloadToLocal();
        },
        closePopup: function closePopup() {
            this.$refs.popup.close();
        },
        downloadToLocal: function downloadToLocal() {
            this.cacheDownload({
                success: function success(i) {
                    e.wx$1.saveFileToDisk({
                        filePath: i,
                        success: function success(i) {
                            e.index.showToast({
                                title: "保存成功"
                            });
                        },
                        fail: function fail(i) {
                            console.error(i), e.index.showToast({
                                title: "保存失败",
                                icon: "error"
                            });
                        }
                    });
                }
            });
        },
        shareFileMessage: function shareFileMessage() {
            this.cacheDownload({
                success: function success(i) {
                    e.wx$1.shareFileMessage({
                        filePath: i,
                        success: function success(i) {
                            e.index.showToast({
                                title: "分享成功"
                            });
                        },
                        fail: function fail(i) {
                            console.error(i), e.index.showToast({
                                title: "分享失败",
                                icon: "error"
                            });
                        }
                    });
                }
            });
        },
        addFileToFavorites: function addFileToFavorites() {
            this.cacheDownload({
                success: function success(i) {
                    e.wx$1.addFileToFavorites({
                        filePath: i,
                        success: function success(i) {
                            e.index.showToast({
                                title: "收藏成功"
                            });
                        },
                        fail: function fail(i) {
                            console.error(i), e.index.showToast({
                                title: "收藏失败",
                                icon: "error"
                            });
                        }
                    });
                }
            });
        },
        cacheDownload: function cacheDownload(_ref) {
            var i = _ref.success, o = _ref.fail;
            var s = this.file.file_name.split("."), t = s.slice(0, s.length - 1).join("") + "_" + e.md5(this.file.file_url).toString() + "." + this.file.file_ext, a = e.wx$1.env.USER_DATA_PATH + "/" + t;
            console.log("saveFilePath:", a);
            try {
                e.wx$1.getFileSystemManager().accessSync(a), console.log("【fs.accessSync】本地文件存在，可直接打开"), 
                i && i(a);
            } catch (l) {
                console.error("【fs.accessSync】", l), e.index.showLoading({
                    title: "加载中"
                }), e.index.downloadFile({
                    url: this.file.file_url,
                    filePath: a,
                    success: function success(o) {
                        e.index.hideLoading(), console.log("download finish"), i && i(a);
                    },
                    fail: function fail(i) {
                        e.index.hideLoading(), console.error(i), o ? o(i) : e.index.showToast({
                            title: "获取文件失败",
                            icon: "error"
                        });
                    }
                });
            }
        },
        toHome: function toHome() {
            e.index.navigateTo({
                url: "/pages/index/index"
            });
        },
        triggerShowEmbedAd: function triggerShowEmbedAd() {
            o.isAdShowedAtFile("EmbedAd", this.file.uuid) || this.showEmbedAd();
        },
        showEmbedAd: function showEmbedAd() {
            var _this7 = this;
            this.show_embed_ad && n.appid && n.app_path && e.wx$1.openEmbeddedMiniProgram({
                appId: n.appid,
                path: n.app_path,
                success: function success() {
                    o.markAdShowAtFile("EmbedAd", _this7.file.uuid);
                }
            });
        },
        handleFeedback: function handleFeedback() {
            e.index.navigateTo({
                url: "/pages/feedback/feedback?file_uuid=" + this.file.uuid
            });
        },
        handleStatement: function handleStatement() {
            e.index.showToast({
                title: "免责声明"
            });
        },
        rewardedAdInit: function rewardedAdInit() {
            var _this8 = this;
            var o = i.Config.adConfig().rewardAdId;
            console.log("initRewardedVideoAd:" + o), e.wx$1.createRewardedVideoAd && (d = e.wx$1.createRewardedVideoAd({
                adUnitId: o
            }), d.onLoad(function() {
                console.log("初始化激励广告完成");
            }), d.onError(function(e) {
                console.log("激励广告：发生错误"), console.error(e);
            }), d.onClose(function(e) {
                console.log("激励广告:关闭"), _this8.rewardedVideoEndAction(e.isEnded);
            }), d.load());
        },
        rewardedAdShow: function rewardedAdShow() {
            d && d.show().then(function() {
                console.log("激励视频广告显示成功callback..");
            }).catch(function(e) {
                console.log("激励视频广告显示失败 callback"), console.error(e), d.load().then(function() {
                    d.show().then(function() {
                        console.log("重试load,激励视频广告显示成功callback..");
                    });
                }).catch(function(e) {
                    console.log("激励视频广告显示失败");
                });
            });
        },
        rewardedAdTriggerShow: function rewardedAdTriggerShow() {
            o.isAdShowedAtFile("RewardedAd", this.file.uuid) || this.rewardedAdShow();
        },
        rewardedVideoEndAction: function rewardedVideoEndAction(e) {
            console.log("rewardedVideoEndAction:" + e), o.markAdShowAtFile("RewardedAd", this.file.uuid);
        }
    }
};

if (!Array) {
    (e.resolveComponent("uni-icons") + e.resolveComponent("uni-popup"))();
}

Math || (function() {
    return "../../uni_modules/uni-icons/components/uni-icons/uni-icons.js";
} + function() {
    return "../../uni_modules/uni-popup/components/uni-popup/uni-popup.js";
})();

var c = e._export_sfc(h, [ [ "render", function(i, o, s, t, a, l) {
    return e.e({
        a: 1 == a.fetchStatus
    }, 1 == a.fetchStatus ? e.e({
        b: a.file.icon
    }, a.file.icon ? {
        c: a.file.icon
    } : {}, {
        d: e.t(a.file.file_name),
        e: e.t(a.file.file_size_format_value),
        f: e.t(a.file.file_size_format_unit),
        g: e.t(a.file.download_amount),
        h: !a.isDownloaded
    }, a.isDownloaded ? {} : {
        i: e.o(function() {
            return l.handleDownloadFile && l.handleDownloadFile.apply(l, arguments);
        })
    }, {
        j: a.isDownloaded && l.enableViewFile
    }, a.isDownloaded && l.enableViewFile ? {
        k: e.o(function() {
            return l.handleViewFile && l.handleViewFile.apply(l, arguments);
        })
    } : {}, {
        l: a.isDownloaded
    }, a.isDownloaded ? {
        m: e.o(function() {
            return l.handleSaveFile && l.handleSaveFile.apply(l, arguments);
        })
    } : {}, {
        n: e.p({
            type: "home-filled",
            size: "34",
            color: "#409EFF"
        }),
        o: e.o(function(e) {
            return l.redirectTo("/pages/index/index");
        }),
        p: e.p({
            type: "paperplane-filled",
            size: "34",
            color: "#409EFF"
        }),
        q: e.p({
            type: "headphones",
            size: "34",
            color: "#409EFF"
        }),
        r: e.p({
            type: "help",
            size: "34",
            color: "#409EFF"
        }),
        s: e.o(function(e) {
            return l.navigateTo("/pages/faq/faq");
        }),
        t: e.o(function() {
            return l.handleFeedback && l.handleFeedback.apply(l, arguments);
        })
    }) : {}, {
        v: 2 == a.fetchStatus
    }, 2 == a.fetchStatus ? {
        w: e.t(a.fetchErrorMsg),
        x: e.o(function() {
            return l.toHome && l.toHome.apply(l, arguments);
        })
    } : {}, {
        y: e.o(function() {
            return l.shareFileMessage && l.shareFileMessage.apply(l, arguments);
        }),
        z: e.o(function() {
            return l.addFileToFavorites && l.addFileToFavorites.apply(l, arguments);
        }),
        A: e.o(function() {
            return l.closePopup && l.closePopup.apply(l, arguments);
        }),
        B: e.sr("popup", "6377e98b-4"),
        C: e.p({
            "background-color": "#fff"
        })
    });
} ] ]);

h.__runtimeHooks = 6, wx.createPage(c);