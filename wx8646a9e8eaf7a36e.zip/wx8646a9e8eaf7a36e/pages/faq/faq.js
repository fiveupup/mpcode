var t = {
    data: function data() {
        return {
            content: '<div style="color: #67C23A;padding: 8px 0px 8px 0px;font-weight: bold;"># 文件多久删除?</div>\n\t\t\t\t<p style="font-size: 14px">只要是合法的文件，自上传日起至少保留12个月</p>\n<div style="color: #67C23A;padding: 8px 0px 8px 0px;font-weight: bold;"># 文件无法下载?</div>\n<p style="font-size: 14px">如果文件下载页一直在显示[加载中...]，有可能是因为网络不稳定导致，您可以尝试切换一下网络试试。如果还是无法下载，可以尝试发送给『文件传输助手』，在电脑端下载。</p>\n\n<div style="color: #67C23A;padding: 8px 0px 8px 0px;font-weight: bold;"># 文件如何保存?</div>\n<p  style="font-size: 14px">下载完成后，发送文件给文件传输助手或好友或者收藏到微信收藏夹，或者直接打开文件 (支持Word、Excel、PPT、PDF) 。如果点击按钮没有反应，可尝试将您的微信更新到最新版再尝试。</p>\n\n<div style="color: #67C23A;padding: 8px 0px 8px 0px;font-weight: bold;"># 文件无法浏览?</div>\n<p style="font-size: 14px">小程序使用微信自带的文件浏览工具，如果文件无法浏览，可能是由于微信缓存的问题或者微信不支持浏览此类文件。可以尝试重新下载按钮,或者把小程序从微信最近列表中移除，再重新进来</p>\n\n<div style="color: #67C23A;padding: 8px 0px 8px 0px;font-weight: bold;"># 文件不存在或者404?</div>\n<p style="font-size: 14px">文件可能已被删除，或者网络没加载成功</p>\n'
        };
    }
};

var p = require("../../common/vendor.js")._export_sfc(t, [ [ "render", function(t, p, n, o, e, d) {
    return {
        a: e.content
    };
} ] ]);

wx.createPage(p);