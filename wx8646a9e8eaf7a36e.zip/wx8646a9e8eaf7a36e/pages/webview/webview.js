var e = require("../../common/vendor.js"), r = {
    data: function data() {
        return {
            url: ""
        };
    },
    onLoad: function onLoad(e) {
        this.url = decodeURIComponent(e.url);
    },
    methods: {}
};

var o = e._export_sfc(r, [ [ "render", function(r, o, t, n, u, c) {
    return e.e({
        a: u.url
    }, u.url ? {
        b: u.url
    } : {});
} ] ]);

wx.createPage(o);