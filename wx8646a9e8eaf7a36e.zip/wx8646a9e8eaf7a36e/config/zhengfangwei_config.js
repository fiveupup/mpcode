var e = {
    wxAppId: function wxAppId() {
        return "wx8646a9e8eaf7a36e";
    },
    wxAppName: function wxAppName() {
        return "正方微附件";
    },
    wxAppDesc: function wxAppDesc() {
        return "简单易用的附件工具";
    },
    pcUploadUrl: function pcUploadUrl() {
        return "https://zfw.devonline.net";
    },
    adConfig: function adConfig() {
        return {
            rewardAdId: "adunit-fc1054fe7c2f9c9c",
            interstitialAdId: "adunit-978391f12e0326e2"
        };
    }
};

exports.Config = e;