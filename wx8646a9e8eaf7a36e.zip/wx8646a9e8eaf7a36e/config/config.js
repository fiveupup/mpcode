var p = require("./zhengfangwei_config.js"), e = {
    env: "prd",
    baseUrl: function baseUrl() {
        return "dev" == this.env ? "http://xiaofujian.biz:8888" : "https://xfj.devonline.net";
    },
    wxAppId: function wxAppId() {
        return p.Config.wxAppId();
    },
    wxAppName: function wxAppName() {
        return p.Config.wxAppName();
    },
    wxAppDesc: function wxAppDesc() {
        return p.Config.wxAppDesc();
    },
    masterWxApp: function masterWxApp() {
        return {
            wxAppId: "wx00020d76ba7e71a7",
            wxAppName: "易附件助手"
        };
    },
    isMasterApp: function isMasterApp() {
        return masterWxApp().wxAppId === p.Config.wxAppId();
    },
    webappURL: function webappURL() {
        return "https://app.wfj.devonline.net";
    },
    pcUploadUrl: function pcUploadUrl() {
        return p.Config.pcUploadUrl();
    },
    adConfig: function adConfig() {
        return p.Config.adConfig();
    }
};

exports.Config = e;