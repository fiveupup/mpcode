var t = require("../../@babel/runtime/helpers/toConsumableArray"), e = require("../../@babel/runtime/helpers/objectSpread2"), a = require("../../lib/query-string"), n = require("../../lib/request"), i = require("../../lib/collect"), o = require("../../lib/time").getDateString, s = require("../../behaviors/useGlobalData");

function r(t) {
    var e, a, n, i = new Date(t), o = i.getFullYear(), s = (i.getMonth() + 1).toString().padStart(2, "0"), r = i.getDate().toString().padStart(2, "0"), c = new Date();
    return c - i <= 6e4 ? "刚刚" : c - i <= 36e5 ? "".concat(Math.floor((c - i) / 60 / 1e3), " 分钟前") : c - i <= 864e5 ? "".concat(Math.floor((c - i) / 3600 / 1e3), " 小时前") : function(t) {
        var e = new Date(t), a = new Date();
        return a.setDate(a.getDate() - 1), a.toDateString() === e.toDateString();
    }(t) ? "昨天" : (e = c, a = new Date(t), n = new Date(e), a.getFullYear() === n.getFullYear() ? "".concat(s, "-").concat(r) : "".concat(o, "-").concat(s, "-").concat(r));
}

function c(t) {
    return "string" == typeof t.text ? t.text : (t.children || []).map(c).join("");
}

Component({
    behaviors: [ s ],
    data: {
        token: void 0,
        publication: void 0,
        bindTicket: null,
        autoSubscribeWechat: !1,
        error: null,
        posts: null,
        postsPagination: null,
        postsError: null,
        isScrolledTop: !0
    },
    methods: {
        onLoad: function(t) {
            var e, n, i;
            if (t.token) e = t.token; else if (t.scene) {
                var o = a.parse(decodeURIComponent(t.scene));
                e = o.token || o.t, n = o.bt || o.b, i = Boolean(o.asw) || Boolean(n);
            }
            this.setData({
                token: e,
                bindTicket: n,
                autoSubscribeWechat: i
            }), this.loadPublication(), this.loadPosts();
        },
        onPullDownRefresh: function() {
            var t = this;
            wx.stopPullDownRefresh(), this.requestingPosts = !1, this.initLoadingNext = !1, 
            this.setData({
                posts: null,
                postsPagination: null,
                postsError: null
            }, function() {
                return Promise.all([ t.loadPublication(), t.loadPosts() ]).then(function() {
                    wx.showToast({
                        title: "更新成功",
                        icon: "none"
                    });
                }, function() {
                    wx.showToast({
                        title: "更新失败",
                        icon: "none"
                    });
                });
            });
        },
        onShareAppMessage: function() {
            if (this.data.publication) return {
                title: this.data.publication.name
            };
        },
        onPageScroll: function(t) {
            var e = t.scrollTop;
            e > 0 && this.data.isScrolledTop ? this.setData({
                isScrolledTop: !1
            }) : e <= 0 && !this.data.isScrolledTop && this.setData({
                isScrolledTop: !0
            });
        },
        handleRetryRequestPublication: function() {
            this.loadPublication();
        },
        handleRetryRequestPosts: function() {
            this.loadPosts();
        },
        handleSubscriptionUpdated: function(t) {
            var a = e({}, t.detail);
            this.setData({
                "publication.subscription": a
            });
        },
        loadPublication: function() {
            var t = this;
            return this.setData({
                error: null
            }), n({
                url: "/publications/".concat(this.data.token),
                data: {
                    id_type: "token"
                }
            }).then(function(a) {
                var n = a.data, s = n.subscription.expired_at;
                t.setData({
                    publication: e(e({}, n), {}, {
                        subscriptionExpiredAt: s && o(s)
                    })
                }, function() {
                    !t.initLoadingNext && t.data.posts && (wx.createIntersectionObserver().relativeToViewport().observe("#posts-loading", function(e) {
                        e.intersectionRatio > 0 && t.data.postsPagination && t.data.postsPagination.has_next && t.loadPosts();
                    }), t.initLoadingNext = !0);
                }), i({
                    type: "PageShow",
                    isSubscriber: n.subscription.has_subscribed,
                    entity: {
                        type: "Publication",
                        id: n.id
                    }
                }).catch(function(t) {
                    return console.error(t);
                });
            }, function(e) {
                var a = {
                    message: e.data && e.data.message || e.message || "网络错误，请重试"
                };
                return t.setData({
                    error: a
                }), Promise.reject(a);
            });
        },
        loadPosts: function() {
            var a = this;
            if (!this.requestingPosts) {
                this.requestingPosts = !0, this.setData({
                    postsError: null
                });
                var i = this.data.postsPagination ? this.data.postsPagination.next.replace("https://zhubai.love/api", "") : "/publications/".concat(this.data.token, "/posts");
                return n({
                    url: i,
                    data: {
                        publication_id_type: "token"
                    }
                }).then(function(n) {
                    var i = n.data;
                    a.requestingPosts = !1;
                    var o = i.data.map(function(t) {
                        var a = function(t, e) {
                            for (var a = e.substring(0, 2 * t).split(""), n = 0, i = "", o = 0; o < a.length; o++) {
                                var s = a[o];
                                if (/[a-z0-9\s]/.test(s) ? n += .5 : n += 1, !(n <= t)) break;
                                i += s;
                            }
                            var r = n > t;
                            return {
                                summary: "".concat(i).concat(r ? "..." : ""),
                                isTruncated: r
                            };
                        }(110, function(t, e) {
                            var a = !1, n = "";
                            if (0 === (n = t.map(function(t) {
                                return "paywall" === t.type && (a = !0), c(t);
                            }).join(e ? "" : "\n")).replaceAll(/\s/g, "").length && a) return "该专属内容仅会员可见";
                            return n;
                        }(JSON.parse(t.content))), n = a.summary, i = a.isTruncated;
                        return e(e({}, t), {}, {
                            createdAt: r(t.created_at),
                            summary: n,
                            isTruncated: i
                        });
                    });
                    a.setData({
                        posts: [].concat(t(a.data.posts || []), t(o)),
                        postsPagination: i.pagination
                    }, function() {
                        !a.initLoadingNext && a.data.publication && (wx.createIntersectionObserver().relativeToViewport().observe("#posts-loading", function(t) {
                            t.intersectionRatio > 0 && a.data.postsPagination && a.data.postsPagination.has_next && a.loadPosts();
                        }), a.initLoadingNext = !0);
                    });
                }, function(t) {
                    var e = {
                        message: t.data && t.data.message || t.message || "网络错误，请重试"
                    };
                    return a.setData({
                        postsError: e
                    }), a.requestingPosts = !1, a.initLoadingNext = !1, Promise.reject(e);
                });
            }
        },
        getWebURL: function() {
            return "https://".concat(this.data.publication.token, ".zhubai.love");
        }
    }
});