var t = require("../../@babel/runtime/helpers/defineProperty"), e = require("../../@babel/runtime/helpers/objectSpread2"), i = require("../../behaviors/useGlobalData"), n = require("../../lib/request");

function o(t) {
    return "string" == typeof t.text ? t.text : t.children.map(o).join("");
}

function a(t) {
    var e = t.publication, i = [ {
        type: "paragraph",
        children: [ {
            text: ""
        } ]
    } ];
    try {
        i = JSON.parse(e.membership.description);
    } catch (t) {}
    return i;
}

Component({
    behaviors: [ i ],
    data: {
        publication: void 0,
        content: [],
        error: null,
        subscribeButtonVisible: !0,
        images: {}
    },
    methods: {
        onLoad: function(t) {
            this.publicationToken = t.token, this.requestPublication();
        },
        onPullDownRefresh: function() {
            wx.stopPullDownRefresh(), this.requestPublication().then(function() {
                wx.showToast({
                    title: "更新成功",
                    icon: "none"
                });
            }, function() {
                wx.showToast({
                    title: "更新失败",
                    icon: "error"
                });
            });
        },
        onShareAppMessage: function() {
            if (this.data.publication) return {
                title: "".concat(this.data.publication.name, " - 会员计划")
            };
        },
        onPageScroll: function(t) {
            var e = t.scrollTop;
            this.data.publication && (this.previousScrollTop || (this.previousScrollTop = 0), 
            e > 0 && e - this.previousScrollTop > 0 && this.data.subscribeButtonVisible ? this.setData({
                subscribeButtonVisible: !1
            }) : e - this.previousScrollTop < 0 && !this.data.subscribeButtonVisible && !this.isFooterVisible && this.setData({
                subscribeButtonVisible: !0
            }), this.previousScrollTop = e);
        },
        handleTapPaywall: function() {
            var t = this.selectComponent(".subscribe-button");
            t && t.handleTap();
        },
        handleSubscriptionUpdated: function(t) {
            var i = e({}, t.detail);
            this.setData({
                "publication.subscription": i
            });
        },
        requestPublication: function() {
            var t = this;
            return this.setData({
                error: null
            }), n({
                url: "/publications/".concat(this.publicationToken),
                data: {
                    id_type: "token"
                }
            }).then(function(e) {
                var i = e.data;
                t.setData({
                    publication: i,
                    content: a({
                        publication: i
                    }),
                    error: null
                }, function() {
                    wx.createIntersectionObserver().relativeToViewport().observe(".footer", function(e) {
                        e.intersectionRatio > 0 ? t.isFooterVisible = !0 : t.isFooterVisible = !1;
                    });
                });
            }, function(e) {
                var i = {
                    message: e.data && e.data.message || e.message || "网络错误，请重试",
                    handleRetry: "requestPublication"
                };
                return t.setData({
                    error: i
                }), Promise.reject(i);
            });
        },
        handleImageLoad: function(i) {
            var n = i.detail, o = n.width, a = n.height, r = i.target.dataset.url;
            this.setData({
                images: e(e({}, this.data.images), {}, t({}, r, {
                    width: o,
                    height: a
                }))
            });
        },
        handleClickImage: function(t) {
            var e = t.target.dataset.url;
            wx.previewImage({
                current: e,
                urls: [ e ]
            });
        },
        hanldeImageLongPress: function() {},
        handleClickLink: function(t) {
            var e = t.currentTarget.dataset.node, i = e.url, n = o(e);
            /^https:\/\/(.+\.)?zhubai.love/.test(i) && !i.startsWith("https://link.zhubai.love") ? wx.navigateTo({
                url: "/pages/webpage/webpage?&url=".concat(encodeURIComponent(i))
            }) : wx.setClipboardData({
                data: i
            }).then(function() {
                return wx.navigateTo({
                    url: "/pages/link/link?text=".concat(encodeURIComponent(n), "&url=").concat(encodeURIComponent(i), "&copied=true")
                });
            }, function() {
                return wx.navigateTo({
                    url: "/pages/link/link?text=".concat(encodeURIComponent(n), "&url=").concat(encodeURIComponent(i), "&copied=false")
                });
            });
        }
    }
});