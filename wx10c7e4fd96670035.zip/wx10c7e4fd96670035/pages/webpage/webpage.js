Component({
    properties: {
        url: {
            type: String,
            value: void 0
        }
    },
    methods: {
        onLoad: function(t) {
            this.setData({
                url: decodeURIComponent(t.url)
            });
        }
    }
});