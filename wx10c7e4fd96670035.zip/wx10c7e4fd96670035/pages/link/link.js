var e = require("../../behaviors/useGlobalData"), t = require("../../lib/query-string");

Component({
    behaviors: [ e ],
    data: {
        showGuide: !1
    },
    properties: {
        url: {
            type: String,
            value: void 0
        },
        copied: {
            type: String,
            value: !0
        }
    },
    methods: {
        onLoad: function() {
            var e = t.parse(this.data.url);
            this.setData({
                targetURL: e.url || this.data.url
            });
            var i = "hidden" !== wx.getStorageSync("guide-open-link-in-wechat");
            this.setData({
                showGuide: i
            });
        },
        handleShowGuide: function() {
            this.selectComponent(".guide-modal").setVisible(!0), this.setData({
                showGuide: !1
            }), wx.setStorage({
                key: "guide-open-link-in-wechat",
                data: "hidden"
            });
        }
    }
});