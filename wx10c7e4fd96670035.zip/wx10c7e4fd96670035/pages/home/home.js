var t = require("../../@babel/runtime/helpers/toConsumableArray"), i = require("../../lib/request");

Component({
    data: {
        publications: null,
        error: null,
        pagination: null
    },
    methods: {
        onLoad: function() {
            this.loadPublications();
        },
        onPullDownRefresh: function() {
            var t = this;
            this.requesting = !1, this.initLoadingNext = !1, this.setData({
                publications: null,
                pagination: null,
                error: null
            }, function() {
                return t.loadPublications().then(function() {
                    wx.stopPullDownRefresh(), wx.showToast({
                        title: "更新成功",
                        icon: "none"
                    });
                }, function() {
                    wx.stopPullDownRefresh(), wx.showToast({
                        title: "更新失败",
                        icon: "error"
                    });
                });
            });
        },
        loadPublications: function() {
            var n = this;
            if (!this.requesting) {
                this.requesting = !0, this.setData({
                    error: null
                });
                var a = this.data.pagination ? this.data.pagination.next.replace("https://zhubai.love/api", "") : "/self/subscribed_publications";
                return i({
                    url: a
                }).then(function(i) {
                    var a = i.data;
                    n.requesting = !1, n.setData({
                        publications: [].concat(t(n.data.publications || []), t(a.data)),
                        pagination: a.pagination,
                        error: null
                    }, function() {
                        n.initLoadingNext || (wx.createIntersectionObserver().relativeToViewport().observe("#loading", function(t) {
                            t.intersectionRatio > 0 && n.data.pagination.has_next && n.loadPublications();
                        }), n.initLoadingNext = !0);
                    });
                }, function(t) {
                    n.setData({
                        error: {
                            message: t.data && t.data.message || t.message || "网络错误，请重试",
                            handleRetry: "loadPublications"
                        }
                    }), n.requesting = !1, n.initLoadingNext = !1;
                });
            }
        }
    }
});