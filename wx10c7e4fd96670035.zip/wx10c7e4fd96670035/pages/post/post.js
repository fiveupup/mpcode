var t = require("../../@babel/runtime/helpers/toConsumableArray"), e = require("../../@babel/runtime/helpers/defineProperty"), i = require("../../@babel/runtime/helpers/objectSpread2"), o = require("../../@babel/runtime/helpers/slicedToArray");

require("../../@babel/runtime/helpers/Arrayincludes");

var n = require("../../behaviors/useGlobalData"), s = require("../../lib/request"), r = require("../../lib/collect"), a = require("../../lib/time"), c = require("../../lib/scene").isFromPush;

function u(t) {
    return "string" == typeof t.text ? t.text : t.children.map(u).join("");
}

function l(e) {
    var i = e.post, o = e.onlyFreeContent, n = i.paywall, s = JSON.parse(i.content);
    if (!n) return s;
    var r = {
        type: "paywall",
        children: [ {
            text: ""
        } ]
    };
    return o ? [].concat(t(s.slice(0, n.start_at)), [ r ]) : s.map(function(t) {
        return "paywall" === t.type ? r : t;
    });
}

Component({
    behaviors: [ n ],
    data: {
        post: void 0,
        content: [],
        error: null,
        subscribeButtonVisible: !0,
        images: {},
        isPreview: !1,
        draftId: null,
        previewToken: null,
        previewType: "paid"
    },
    methods: {
        onLoad: function(t) {
            if (t.id) this.postId = t.id; else if (t.scene) {
                var e = decodeURIComponent(t.scene);
                if (e.includes("id=")) this.postId = e.match(/id=(.+)$/)[1]; else {
                    var i = e.split("-"), n = o(i, 3), s = n[0], r = n[1], a = n[2], c = "p" === s;
                    this.isPreview = c, this.draftId = r, this.previewToken = a, this.setData({
                        isPreview: c,
                        draftId: r,
                        previewToken: a
                    });
                }
            }
            this.requestPost();
        },
        onPullDownRefresh: function() {
            wx.stopPullDownRefresh(), this.requestPost().then(function() {
                wx.showToast({
                    title: "更新成功",
                    icon: "none"
                });
            }, function() {
                wx.showToast({
                    title: "更新失败",
                    icon: "error"
                });
            });
        },
        onShareAppMessage: function() {
            if (this.data.post) return {
                title: this.data.post.title
            };
        },
        onPageScroll: function(t) {
            var e = t.scrollTop;
            this.data.post && (this.previousScrollTop || (this.previousScrollTop = 0), e > 0 && e - this.previousScrollTop > 0 && this.data.subscribeButtonVisible ? this.setData({
                subscribeButtonVisible: !1
            }) : e - this.previousScrollTop < 0 && !this.data.subscribeButtonVisible && !this.isFooterVisible && this.setData({
                subscribeButtonVisible: !0
            }), this.previousScrollTop = e);
        },
        handleSubscriptionUpdated: function(t) {
            var e = i({}, t.detail);
            e.has_subscribed && !this.data.post.publication.subscription.has_subscribed && "paid" === e.type && (wx.showLoading({
                title: "更新内容"
            }), this.requestPost().then(function() {
                wx.showToast({
                    title: "更新成功",
                    icon: "none"
                });
            }, function() {
                wx.showToast({
                    title: "更新失败",
                    icon: "error"
                });
            })), this.setData({
                "post.publication.subscription": e
            });
        },
        handleSwitchPreviewType: function() {
            var t = this.data, e = t.post, i = "paid" === t.previewType ? "free" : "paid";
            this.setData({
                previewType: i,
                content: l({
                    post: e,
                    onlyFreeContent: "free" === i
                })
            });
        },
        handleTapPaywall: function() {
            var t = this.selectComponent(".subscribe-button");
            t && t.handleTap();
        },
        requestPost: function() {
            var t = this;
            this.setData({
                error: null
            });
            var e = this.isPreview ? "/drafts/".concat(this.draftId, "/preview?token=").concat(this.previewToken) : "/posts/".concat(this.postId);
            return s({
                url: e
            }).then(function(t) {
                var e = t.data;
                return s({
                    url: "/publications/".concat(e.publication_id || e.publication.id)
                }).then(function(t) {
                    var o = t.data;
                    return i(i({}, e), {}, {
                        publication: o,
                        author: i({}, o.author),
                        createdAt: a.getRelativeTimeString(e.created_at)
                    });
                });
            }).then(function(e) {
                t.setData({
                    post: e,
                    content: l({
                        post: e
                    }),
                    error: null
                }, function() {
                    wx.createIntersectionObserver().relativeToViewport().observe(".footer", function(e) {
                        e.intersectionRatio > 0 ? t.isFooterVisible = !0 : t.isFooterVisible = !1;
                    });
                }), t.isPreview || r({
                    type: "PageShow",
                    isSubscriber: e.publication.subscription.has_subscribed,
                    entity: {
                        type: "Post",
                        id: e.id
                    }
                }).catch(function(t) {
                    return console.error(t);
                });
            }, function(e) {
                var i = {
                    message: e.data && e.data.message || e.message || "网络错误，请重试",
                    handleRetry: "requestPost"
                };
                return t.setData({
                    error: i
                }), Promise.reject(i);
            });
        },
        handleImageLoad: function(t) {
            var o = t.detail, n = o.width, s = o.height, r = t.target.dataset.url;
            this.setData({
                images: i(i({}, this.data.images), {}, e({}, r, {
                    width: n,
                    height: s
                }))
            });
        },
        handleClickImage: function(t) {
            var e = t.target.dataset.url;
            wx.previewImage({
                current: e,
                urls: [ e ]
            });
        },
        hanldeImageLongPress: function() {},
        handleClickLink: function(t) {
            var e = t.currentTarget.dataset.node, i = e.url, o = u(e), n = this.data.globalData.self, s = this.data.post, r = s.publication.subscription.has_subscribed, a = i;
            n && r && c() ? a = "https://link.zhubai.love/api/link?is_push=1&subscription_type=wechat&subscriber_id=".concat(n.id, "&post_id=").concat(s.id, "&url=").concat(encodeURIComponent(i)) : n && r && (a = "https://link.zhubai.love/api/link?subscription_type=wechat&subscriber_id=".concat(n.id, "&post_id=").concat(s.id, "&url=").concat(encodeURIComponent(i))), 
            /^https:\/\/(.+\.)?zhubai.love/.test(i) && !i.startsWith("https://link.zhubai.love") ? wx.navigateTo({
                url: "/pages/webpage/webpage?url=".concat(encodeURIComponent(a))
            }) : wx.setClipboardData({
                data: a
            }).then(function() {
                return wx.navigateTo({
                    url: "/pages/link/link?text=".concat(encodeURIComponent(o), "&url=").concat(encodeURIComponent(a), "&copied=true")
                });
            }, function() {
                return wx.navigateTo({
                    url: "/pages/link/link?text=".concat(encodeURIComponent(o), "&url=").concat(encodeURIComponent(a), "&copied=false")
                });
            });
        },
        getWebURL: function() {
            return "https://".concat(this.data.post.publication.token, ".zhubai.love/posts/").concat(this.data.post.id);
        }
    }
});