var e = require("@babel/runtime/helpers/objectSpread2"), t = require("lib/redux"), n = require("lib/request"), r = {
    self: void 0,
    systemInfo: void 0
};

App({
    store: t.createStore(function() {
        var t = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : r, n = arguments.length > 1 ? arguments[1] : void 0;
        switch (n.type) {
          case "updateSelf":
            return e(e({}, t), {}, {
                self: e(e({}, t.self), n.payload)
            });

          case "updateSystemInfo":
            return e(e({}, t), {}, {
                systemInfo: e(e({}, t.systemInfo), n.payload)
            });

          default:
            return t;
        }
    }),
    launchOptions: null,
    onLaunch: function() {
        var e = this;
        try {
            var t = wx.getSystemInfoSync();
            this.store.dispatch({
                type: "updateSystemInfo",
                payload: t
            });
        } catch (e) {}
        n({
            url: "/self"
        }).then(function(t) {
            return e.store.dispatch({
                type: "updateSelf",
                payload: t.data
            });
        }, function() {});
    },
    onShow: function(e) {
        this.launchOptions = e;
    }
});