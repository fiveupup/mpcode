module.exports = {
    bracketSpacing: !1,
    semi: !1,
    singleQuote: !0,
    trailingComma: "es5"
};