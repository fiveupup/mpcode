var t = require("../../behaviors/useGlobalData"), i = require("../../lib/request");

Component({
    externalClasses: [ "class-name" ],
    behaviors: [ t ],
    properties: {
        publication: {
            type: Object,
            value: {}
        }
    },
    data: {
        settingError: !1
    },
    methods: {
        requestNotificationCredit: function() {
            var t = this;
            return i({
                url: "/wechat/self/notification_credit"
            }).then(function(i) {
                var e = i.data.credit;
                return t.dispatch({
                    type: "updateSelf",
                    payload: {
                        notificationCredit: e
                    }
                }), e;
            });
        },
        handleTipTap: function() {
            this.data.settingError ? wx.openSetting({
                withSubscriptions: !0
            }) : (this.selectComponent(".subscription-modal").setVisible(!0), wx.reportAnalytics("show_notification_credit_view", {
                credit: this.data.globalData.self.notificationCredit
            }));
        },
        checkSetting: function() {
            var t = this;
            return wx.getSetting({
                withSubscriptions: !0
            }).then(function(i) {
                var e = i.subscriptionsSetting, n = e.mainSwitch, r = e.itemSettings, o = r && "reject" === r["2TncyzIZm0Sc6uezjXgyWXkZG1cyYZB_HLlwmVguiyg"];
                !n || o ? t.setData({
                    settingError: !0
                }) : t.setData({
                    settingError: !1
                });
            });
        }
    },
    attached: function() {
        var t = this;
        this.requestNotificationCredit().catch(function() {
            return t.requestNotificationCredit();
        }).then(function(i) {
            0 === i && t.data.publication.isSubscribed && (t.selectComponent(".subscription-modal").setVisible(!0), 
            wx.reportAnalytics("show_notification_credit_view", {
                credit: i
            }));
        }, function(t) {
            return console.error(t);
        }), this.checkSetting();
    },
    pageLifetimes: {
        show: function() {
            this.checkSetting();
        }
    }
});