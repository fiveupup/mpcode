Component({
    externalClasses: [ "class-name" ],
    properties: {
        webUrl: {
            type: String,
            value: void 0
        },
        poster: {
            type: String,
            value: void 0
        },
        isPreview: {
            type: Boolean,
            value: !1
        }
    },
    data: {
        isPosterViewVisible: !1,
        image: null,
        error: null
    },
    methods: {
        handleTap: function() {
            this.setData({
                isPosterViewVisible: !1,
                image: null,
                error: null
            }), this.selectComponent(".share-modal").setVisible(!0);
        },
        handleCancel: function() {
            this.selectComponent(".share-modal").setVisible(!1);
        },
        handleCopy: function() {
            var e = this;
            wx.setClipboardData({
                data: this.data.webUrl
            }).then(function() {
                return e.handleCancel();
            }, function() {
                return wx.showToast({
                    title: "复制失败",
                    icon: "none"
                });
            });
        },
        handleGetPoster: function() {
            this.data.isPreview ? wx.showToast({
                title: "发布后才可生成",
                icon: "none"
            }) : (this.setData({
                isPosterViewVisible: !0,
                image: null,
                error: null
            }), this.loadPoster());
        },
        handleHidePoster: function() {
            this.setData({
                isPosterViewVisible: !1,
                image: null,
                error: null
            });
        },
        handleSavePoster: function() {
            var e = this;
            wx.saveImageToPhotosAlbum({
                filePath: this.data.image.url
            }).then(function() {
                e.handleCancel(), wx.showToast({
                    title: "保存成功",
                    icon: "none"
                });
            }, function() {
                return wx.showToast({
                    title: "保存失败",
                    icon: "none"
                });
            });
        },
        hanldeImageLongPress: function() {},
        loadPoster: function() {
            var e = this;
            this.setData({
                error: null
            }), wx.downloadFile({
                url: this.data.poster,
                success: function(t) {
                    200 === t.statusCode ? wx.getImageInfo({
                        src: t.tempFilePath
                    }).then(function(a) {
                        var n = a.width, s = a.height;
                        e.setData({
                            image: {
                                url: t.tempFilePath,
                                width: n,
                                height: s
                            }
                        });
                    }, function() {
                        return e.setData({
                            error: {
                                message: "获取图片信息失败",
                                handleRetry: "loadPoster"
                            }
                        });
                    }) : e.setData({
                        error: {
                            message: "服务异常",
                            handleRetry: "loadPoster"
                        }
                    });
                },
                fail: function() {
                    return e.setData({
                        error: {
                            message: "下载失败",
                            handleRetry: "loadPoster"
                        }
                    });
                }
            });
        }
    }
});