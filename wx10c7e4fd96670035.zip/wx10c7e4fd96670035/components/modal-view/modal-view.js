Component({
    externalClasses: [ "class-name" ],
    properties: {
        visible: {
            type: Boolean,
            value: !1
        },
        disableHiding: {
            type: Boolean,
            value: !1
        }
    },
    data: {
        entering: !1,
        leaving: !1
    },
    methods: {
        setVisible: function(e) {
            e !== this.data.visible && this.setData({
                visible: e,
                entering: e,
                leaving: !e
            });
        },
        handleAnimationEnd: function(e) {
            "fadeIn" === e.detail.animationName ? this.setData({
                entering: !1
            }) : "fadeOut" === e.detail.animationName && this.setData({
                leaving: !1
            });
        },
        handleTap: function(e) {
            "modal-view-mask" !== e.target.id || this.data.disableHiding || this.setVisible(!1);
        },
        handleTouchMove: function() {}
    }
});