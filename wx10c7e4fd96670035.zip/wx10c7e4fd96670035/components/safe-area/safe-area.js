var e = require("../../behaviors/useGlobalData");

Component({
    behaviors: [ e ],
    properties: {
        bottom: {
            type: Boolean,
            value: !1
        },
        extraHeight: {
            type: Number,
            value: 0
        }
    }
});