Component({
    properties: {
        title: {
            type: String,
            value: ""
        },
        transparent: {
            type: Boolean,
            value: !1
        },
        isScrolledTop: {
            type: Boolean,
            value: !0
        }
    },
    data: {
        showBackButton: !1,
        showHomeButton: !1,
        customNavDisabled: !1
    },
    observers: {
        title: function(t) {
            wx.setNavigationBarTitle({
                title: t
            });
        }
    },
    attached: function() {
        var t = getCurrentPages();
        this.setData({
            showBackButton: t.length > 1,
            showHomeButton: 1 === t.length && "pages/home/home" !== t[0].route
        });
        try {
            var e = "windows" === wx.getSystemInfoSync().platform;
            this.setData({
                customNavDisabled: e
            }), e && wx.setNavigationBarTitle({
                title: this.data.title
            });
        } catch (t) {}
    },
    methods: {
        handleBack: function() {
            wx.navigateBack();
        },
        handleGoHome: function() {
            wx.switchTab({
                url: "/pages/home/home"
            });
        }
    }
});