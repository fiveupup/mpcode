var e = require("../../@babel/runtime/helpers/regeneratorRuntime"), t = require("../../@babel/runtime/helpers/asyncToGenerator"), a = require("../../@babel/runtime/helpers/objectSpread2"), i = require("../../behaviors/useGlobalData"), s = require("../../lib/request"), r = require("../../lib/richtext").getCharactersCount, n = {
    error: null,
    requesting: !1,
    view: "select-approach",
    email: "",
    inputError: null,
    sentConfirmEmail: !1
};

Component({
    externalClasses: [ "class-name", "icon-class-name" ],
    behaviors: [ i ],
    properties: {
        publication: {
            type: Object,
            value: void 0
        },
        isPreview: {
            type: Boolean,
            value: !1
        }
    },
    data: a(a({}, n), {}, {
        showDescriptionLink: !1
    }),
    observers: {
        publication: function(e) {
            var t = e.membership;
            if (t) {
                var a = [];
                try {
                    a = JSON.parse(t.description);
                } catch (e) {}
                this.setData({
                    showDescriptionLink: r(a) > 0
                });
            } else this.setData({
                showDescriptionLink: !1
            });
        }
    },
    pageLifetimes: {
        show: function() {
            var e = this, t = this.selectComponent(".subscription-modal");
            "offical-account" === this.data.view && t.data.visible && this.data.globalData.self && !this.data.globalData.self.has_subscribed_mp && this.loadSelf().then(function(t) {
                t.has_subscribed_mp && (e.requestSubscribeWechat().then(function() {
                    return e.setData({
                        view: "select-approach"
                    });
                }, function() {}), wx.reportAnalytics("follow_official_account_success", {
                    source: "subscribe"
                }));
            }, function() {
                return e.setData({
                    view: "select-approach"
                });
            });
        }
    },
    lifetimes: {
        detached: function() {
            clearInterval(this.interval);
        }
    },
    methods: {
        handleTap: function() {
            if (this.data.isPreview) wx.showToast({
                title: "发布后才可订阅",
                icon: "none"
            }); else {
                this.setData(a({}, n));
                var e = this.data.globalData.self;
                e && e.name && e.account.email || this.loadSelf().catch(function() {});
                var t = Boolean(this.data.publication.membership), i = Boolean("paid" === this.data.publication.subscription.type);
                t && !i && this.setData({
                    view: "select-plan"
                }), this.selectComponent(".subscription-modal").setVisible(!0);
            }
        },
        handleHide: function() {
            this.selectComponent(".subscription-modal").setVisible(!1);
        },
        loadSelf: function() {
            var e = this;
            return this.setData({
                requesting: !0,
                error: null
            }), s({
                url: "/self"
            }).then(function(t) {
                var i = t.data;
                return e.dispatch({
                    type: "updateSelf",
                    payload: a({}, i)
                }), e.setData({
                    requesting: !1,
                    error: Boolean(i.name) ? null : {
                        title: "需获取你的名字和头像",
                        message: "作者知道是谁在订阅会有更多鼓励 💪",
                        retryText: "好的",
                        handleRetry: "getAndSetUserProfile"
                    }
                }), i;
            }, function(t) {
                return e.setData({
                    requesting: !1,
                    error: {
                        message: t.data && t.data.message || t.message || "获取个人信息失败",
                        handleRetry: "loadSelf"
                    }
                }), Promise.reject();
            });
        },
        getAndSetUserProfile: function() {
            var a = this;
            return t(e().mark(function t() {
                return e().wrap(function(e) {
                    for (;;) switch (e.prev = e.next) {
                      case 0:
                        if (a.setData({
                            requesting: !0,
                            error: null
                        }), e.prev = 1, a.userProfile) {
                            e.next = 5;
                            break;
                        }
                        return e.next = 5, a.getUserProfile();

                      case 5:
                        return e.next = 7, a.setUserProfile();

                      case 7:
                        a.setData({
                            requesting: !1,
                            error: null
                        }), e.next = 13;
                        break;

                      case 10:
                        e.prev = 10, e.t0 = e.catch(1), a.setData({
                            requesting: !1,
                            error: e.t0
                        });

                      case 13:
                      case "end":
                        return e.stop();
                    }
                }, t, null, [ [ 1, 10 ] ]);
            }))();
        },
        getUserProfile: function() {
            var e = this;
            return wx.getUserProfile({
                desc: "让作者知道是谁在订阅"
            }).then(function(t) {
                var a = t.userInfo.avatarUrl, i = t.userInfo.nickName;
                e.userProfile = {
                    avatar: a,
                    name: i
                };
            }, function() {
                return Promise.reject({
                    title: "需获取你的名字和头像",
                    message: "作者知道是谁在订阅会有更多鼓励 💪",
                    retryText: "好的",
                    handleRetry: "getAndSetUserProfile"
                });
            });
        },
        setUserProfile: function() {
            var e = this;
            return s({
                method: "PUT",
                url: "/self",
                data: this.userProfile
            }).then(function() {
                return e.dispatch({
                    type: "updateSelf",
                    payload: e.userProfile
                });
            }, function(e) {
                return Promise.reject({
                    message: e.data && e.data.message || e.message || "设置个人信息失败",
                    handleRetry: "getAndSetUserProfile"
                });
            });
        },
        handleSubscribeWechat: function() {
            var e = this.data.publication, t = e.subscription.approach.wechat, a = e.approach.wechat;
            t ? this.setData({
                view: "unsubscribe-wechat"
            }) : a ? this.data.globalData.self.has_subscribed_mp ? this.requestSubscribeWechat().catch(function() {}) : (this.setData({
                view: "offical-account"
            }), wx.reportAnalytics("show_follow_guide", {
                source: "subscribe"
            })) : wx.showToast({
                title: "微信订阅已被作者禁用",
                icon: "none"
            });
        },
        requestSubscribeWechat: function() {
            var e = this;
            return this.setData({
                requesting: !0,
                error: null
            }), s({
                method: "POST",
                url: "/publications/".concat(this.data.publication.id, "/subscription/wechat")
            }).then(function() {
                var t = a(a({}, e.data.publication.subscription), {}, {
                    has_subscribed: !0,
                    approach: a(a({}, e.data.publication.subscription.approach), {}, {
                        wechat: !0
                    })
                });
                e.setData({
                    requesting: !1,
                    publication: a(a({}, e.data.publication), {}, {
                        subscription: t
                    })
                }), wx.showToast({
                    title: "订阅成功",
                    icon: "none"
                }), e.triggerEvent("subscriptionupdated", t);
            }, function(t) {
                if (t.data && 700006 === t.data.code) {
                    e.setData({
                        requesting: !1,
                        view: "offical-account"
                    });
                    var i = e.data.globalData.self;
                    e.dispatch({
                        type: "updateSelf",
                        payload: a(a({}, i), {}, {
                            has_subscribed_mp: !1
                        })
                    }), wx.reportAnalytics("show_follow_guide", {
                        source: "subscribe"
                    });
                } else if (t.data && 600003 === t.data.code) {
                    var s = a(a({}, e.data.publication.subscription), {}, {
                        has_subscribed: !0,
                        approach: a(a({}, e.data.publication.subscription.approach), {}, {
                            wechat: !0
                        })
                    });
                    e.setData({
                        requesting: !1,
                        publication: a(a({}, e.data.publication), {}, {
                            subscription: s
                        })
                    }), wx.showToast({
                        title: "订阅成功",
                        icon: "none"
                    }), e.triggerEvent("subscriptionupdated", s);
                } else e.setData({
                    requesting: !1,
                    error: {
                        message: t.data && t.data.message || t.message || "订阅失败",
                        handleRetry: "requestSubscribeWechat"
                    }
                });
                return Promise.reject(t);
            });
        },
        handleUnsubscribeWechat: function() {
            var i = this;
            return t(e().mark(function t() {
                var r, n;
                return e().wrap(function(e) {
                    for (;;) switch (e.prev = e.next) {
                      case 0:
                        return i.setData({
                            requesting: !0,
                            error: null
                        }), e.prev = 1, e.next = 4, s({
                            method: "DELETE",
                            url: "/publications/".concat(i.data.publication.id, "/subscription/wechat")
                        });

                      case 4:
                        r = i.data.publication, n = a(a({}, r.subscription), {}, {
                            has_subscribed: "paid" === r.subscription.type || r.subscription.approach.email,
                            approach: a(a({}, r.subscription.approach), {}, {
                                wechat: !1
                            })
                        }), i.setData({
                            requesting: !1,
                            error: null,
                            view: "select-approach",
                            publication: a(a({}, r), {}, {
                                subscription: n
                            })
                        }), i.triggerEvent("subscriptionupdated", n), e.next = 13;
                        break;

                      case 10:
                        e.prev = 10, e.t0 = e.catch(1), i.setData({
                            requesting: !1,
                            view: "select-approach",
                            error: {
                                message: e.t0.data && e.t0.data.message || e.t0.message || "取消订阅失败",
                                handleRetry: "handleUnsubscribeWechat"
                            }
                        });

                      case 13:
                      case "end":
                        return e.stop();
                    }
                }, t, null, [ [ 1, 10 ] ]);
            }))();
        },
        handleCancelUnsubscribe: function() {
            this.setData({
                view: "select-approach"
            });
        },
        handleRequestEmailSubscribe: function() {
            var e = this.data.publication, t = e.subscription.approach.email, a = e.approach.email, i = Boolean(this.data.globalData.self.account.email);
            t ? this.setData({
                view: "unsubscribe-email"
            }) : a ? i ? this.requestSubscribeEmail() : this.setData({
                view: "bind-email",
                email: "",
                inputError: null
            }) : wx.showToast({
                title: "邮箱订阅已被作者禁用",
                icon: "none"
            });
        },
        requestSubscribeEmail: function() {
            var e = this;
            this.setData({
                requesting: !0,
                error: null
            }), s({
                method: "POST",
                url: "/publications/".concat(this.data.publication.id, "/subscription/email")
            }).then(function() {
                var t = e.data.publication, i = a(a({}, t.subscription), {}, {
                    has_subscribed: !0,
                    approach: a(a({}, t.subscription.approach), {}, {
                        email: !0
                    })
                });
                e.setData({
                    requesting: !1,
                    publication: a(a({}, t), {}, {
                        subscription: i
                    })
                }), wx.showToast({
                    title: "订阅成功",
                    icon: "none"
                }), e.triggerEvent("subscriptionupdated", i);
            }, function(t) {
                if (t.data && 200007 === t.data.code) {
                    e.setData({
                        requesting: !1,
                        view: "offical-account"
                    });
                    var i = e.data.globalData.self;
                    e.dispatch({
                        type: "updateSelf",
                        payload: a(a({}, i), {}, {
                            account: a(a({}, i.account), {}, {
                                email: null
                            })
                        })
                    }), e.setData({
                        view: "bind-email"
                    });
                } else if (t.data && 600003 === t.data.code) {
                    var s = e.data.publication, r = a(a({}, s.subscription), {}, {
                        has_subscribed: !0,
                        approach: a(a({}, s.subscription.approach), {}, {
                            email: !0
                        })
                    });
                    e.setData({
                        requesting: !1,
                        publication: a(a({}, s), {}, {
                            subscription: r
                        })
                    }), wx.showToast({
                        title: "订阅成功",
                        icon: "none"
                    }), e.triggerEvent("subscriptionupdated", r);
                } else e.setData({
                    requesting: !1,
                    error: {
                        message: t.data && t.data.message || t.message || "订阅失败",
                        handleRetry: "requestSubscribeEmail"
                    }
                });
            });
        },
        handleUnsubscribeEmail: function() {
            var i = this;
            return t(e().mark(function t() {
                var r, n;
                return e().wrap(function(e) {
                    for (;;) switch (e.prev = e.next) {
                      case 0:
                        return i.setData({
                            requesting: !0,
                            error: null
                        }), e.prev = 1, e.next = 4, s({
                            method: "DELETE",
                            url: "/publications/".concat(i.data.publication.id, "/subscription/email")
                        });

                      case 4:
                        r = i.data.publication, n = a(a({}, r.subscription), {}, {
                            has_subscribed: "paid" === r.subscription.type || r.subscription.approach.wechat,
                            approach: a(a({}, r.subscription.approach), {}, {
                                email: !1
                            })
                        }), i.setData({
                            requesting: !1,
                            error: null,
                            view: "select-approach",
                            publication: a(a({}, r), {}, {
                                subscription: n
                            })
                        }), i.triggerEvent("subscriptionupdated", n), e.next = 13;
                        break;

                      case 10:
                        e.prev = 10, e.t0 = e.catch(1), i.setData({
                            requesting: !1,
                            view: "select-approach",
                            error: {
                                message: e.t0.data && e.t0.data.message || e.t0.message || "取消订阅失败",
                                handleRetry: "handleUnsubscribeEmail"
                            }
                        });

                      case 13:
                      case "end":
                        return e.stop();
                    }
                }, t, null, [ [ 1, 10 ] ]);
            }))();
        },
        handleEmailInput: function() {
            this.setData({
                inputError: null
            });
        },
        handleEmailBinding: function() {
            var e = this;
            0 !== this.data.email.length ? (this.setData({
                requesting: !0
            }), s({
                url: "/self/email_confirmation",
                method: "POST",
                data: {
                    email: this.data.email.trim()
                }
            }).then(function() {
                e.setData({
                    requesting: !1,
                    sentConfirmEmail: !0
                }), clearInterval(e.interval), e.interval = setInterval(function() {
                    e.selectComponent(".subscription-modal").data.visible ? s({
                        url: "/self"
                    }).then(function(t) {
                        var a = t.data;
                        e.dispatch({
                            type: "updateSelf",
                            payload: a
                        }), a.account.email === e.data.email.trim() && (e.setData({
                            view: "select-approach"
                        }), e.requestSubscribeEmail(), clearInterval(e.interval));
                    }) : clearInterval(e.interval);
                }, 3e3);
            }, function(t) {
                return e.setData({
                    requesting: !1,
                    inputError: t && t.data && t.data.validation_errors && t.data.validation_errors.email[0] || t && t.data && t.data.message || t && t.message || "绑定失败"
                });
            })) : this.setData({
                inputError: !0
            });
        },
        handleCancelEmailBinding: function() {
            clearInterval(this.interval), this.data.sentConfirmEmail ? this.handleHide() : this.setData({
                view: "select-approach"
            });
        },
        handlePaidSubscribe: function() {
            wx.showToast({
                title: "如有疑问，请联系客服",
                icon: "none"
            });
        },
        handleFreeSubscribe: function() {
            this.setData({
                view: "select-approach"
            });
        }
    }
});