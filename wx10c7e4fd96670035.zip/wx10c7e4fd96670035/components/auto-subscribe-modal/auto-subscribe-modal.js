var e = require("../../@babel/runtime/helpers/regeneratorRuntime"), t = require("../../@babel/runtime/helpers/asyncToGenerator"), a = require("../../@babel/runtime/helpers/objectSpread2"), r = require("../../behaviors/useGlobalData"), s = require("../../lib/request");

Component({
    behaviors: [ r ],
    properties: {
        publication: {
            type: Object,
            value: void 0
        },
        ticket: {
            type: String,
            value: void 0
        }
    },
    data: {
        loading: !1,
        error: null,
        showWechatBinding: !1
    },
    pageLifetimes: {
        show: function() {
            var e = this.selectComponent("#modal");
            e && e.data.visible && this.data.globalData.self && !this.data.globalData.self.has_subscribed_mp && this.loadSelf();
        }
    },
    lifetimes: {
        attached: function() {
            this.data.ticket && this.data.ticket.length > 0 && this.setData({
                showWechatBinding: !0
            }), this.setVisible(!0), this.loadSelf();
        }
    },
    methods: {
        setVisible: function(e) {
            this.selectComponent("#modal").setVisible(e);
        },
        handleHide: function() {
            this.setVisible(!1);
        },
        loadSelf: function() {
            var e = this;
            this.setData({
                loading: !0,
                error: null
            }), s({
                url: "/self"
            }).then(function(t) {
                var a = t.data;
                return e.dispatch({
                    type: "updateSelf",
                    payload: a
                }), e.setData({
                    loading: !1
                }), a.has_subscribed_mp && a.name && a.avatar && !e.data.showWechatBinding && e.requestWechatSubscribe(), 
                a;
            }, function(t) {
                var a = {
                    message: t.data && t.data.message || t.message || "获取个人信息失败",
                    handleRetry: "loadSelf"
                };
                e.setData({
                    loading: !1,
                    error: a
                });
            });
        },
        requestBindWechat: function() {
            var e = this;
            this.setData({
                loading: !0,
                error: null
            }), s({
                method: "PUT",
                url: "/self/account",
                data: {
                    ticket: this.data.ticket
                }
            }).then(function() {
                e.setData({
                    showWechatBinding: !1
                }), e.loadSelf();
            }, function(t) {
                var a = t && t.data && 800001 === t.data.code;
                e.setData({
                    loading: !1,
                    error: {
                        message: t.data && t.data.message || t.message || "绑定失败",
                        handleRetry: !a && "requestBindWechat"
                    }
                });
            });
        },
        requestWechatSubscribe: function() {
            var e = this;
            this.setData({
                loading: !0,
                error: null
            });
            var t = this.data.publication;
            s({
                method: "POST",
                url: "/publications/".concat(this.data.publication.id, "/subscription/wechat")
            }).then(function() {
                var r = a(a({}, t.subscription), {}, {
                    has_subscribed: !0,
                    approach: a(a({}, t.subscription.approach), {}, {
                        wechat: !0
                    })
                });
                e.setData({
                    loading: !1,
                    publication: a(a({}, t), {}, {
                        subscription: r
                    })
                }), e.triggerEvent("subscriptionupdated", r);
            }, function(r) {
                if (r.data && 700006 === r.data.code) {
                    e.setData({
                        loading: !1
                    });
                    var s = e.data.globalData.self;
                    e.dispatch({
                        type: "updateSelf",
                        payload: a(a({}, s), {}, {
                            has_subscribed_mp: !1
                        })
                    });
                } else if (r.data && 600003 === r.data.code) {
                    var i = a(a({}, t.subscription), {}, {
                        has_subscribed: !0,
                        approach: a(a({}, t.subscription.approach), {}, {
                            wechat: !0
                        })
                    });
                    e.setData({
                        loading: !1,
                        publication: a(a({}, t), {}, {
                            subscription: i
                        })
                    }), e.triggerEvent("subscriptionupdated", i);
                } else e.setData({
                    loading: !1,
                    error: {
                        message: r.data && r.data.message || r.message || "订阅失败",
                        handleRetry: "requestWechatSubscribe"
                    }
                });
            });
        },
        updateSelf: function() {
            var a = this;
            return t(e().mark(function t() {
                return e().wrap(function(e) {
                    for (;;) switch (e.prev = e.next) {
                      case 0:
                        if (a.setData({
                            loading: !0,
                            error: null
                        }), e.prev = 1, a.userProfile) {
                            e.next = 5;
                            break;
                        }
                        return e.next = 5, a.getUserProfile();

                      case 5:
                        e.next = 9;
                        break;

                      case 7:
                        e.prev = 7, e.t0 = e.catch(1);

                      case 9:
                        if (a.userProfile) {
                            e.next = 12;
                            break;
                        }
                        return a.setData({
                            loading: !1
                        }), e.abrupt("return");

                      case 12:
                        return e.prev = 12, e.next = 15, a.setUserProfile();

                      case 15:
                        a.setData({
                            loading: !1
                        }), e.next = 21;
                        break;

                      case 18:
                        e.prev = 18, e.t1 = e.catch(12), a.setData({
                            loading: !1,
                            error: e.t1
                        });

                      case 21:
                      case "end":
                        return e.stop();
                    }
                }, t, null, [ [ 1, 7 ], [ 12, 18 ] ]);
            }))();
        },
        getUserProfile: function() {
            var e = this;
            return wx.getUserProfile({
                desc: "让作者知道是谁在订阅"
            }).then(function(t) {
                var a = t.userInfo.avatarUrl, r = t.userInfo.nickName;
                e.userProfile = {
                    avatar: a,
                    name: r
                };
            }, function() {
                return wx.showToast({
                    title: "获取信息失败",
                    icon: "none"
                }), Promise.reject();
            });
        },
        setUserProfile: function() {
            var e = this;
            return s({
                method: "PUT",
                url: "/self",
                data: this.userProfile
            }).then(function() {
                return e.dispatch({
                    type: "updateSelf",
                    payload: e.userProfile
                });
            }, function(e) {
                return Promise.reject({
                    message: e.data && e.data.message || e.message || "设置个人信息失败",
                    handleRetry: "updateSelf"
                });
            });
        }
    }
});