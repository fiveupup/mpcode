var e = require("../../behaviors/useGlobalData"), t = require("../../lib/request");

Component({
    behaviors: [ e ],
    properties: {
        publication: {
            type: Object,
            value: {}
        }
    },
    data: {
        loading: !1,
        error: null,
        success: !1
    },
    methods: {
        handleTipTap: function() {
            this.setData({
                loading: !1,
                error: null,
                success: !1
            }), this.selectComponent(".modal").setVisible(!0), wx.reportAnalytics("show_follow_guide", {
                source: "guide"
            });
        },
        updateSelf: function() {
            var e = this;
            return this.setData({
                loading: !0,
                error: null
            }), this.requestSelf().then(function(t) {
                e.setData({
                    loading: !1,
                    success: t.has_subscribed_mp
                }), t.has_subscribed_mp && wx.reportAnalytics("follow_official_account_success", {
                    source: "guide"
                });
            }, function(t) {
                e.setData({
                    success: !1,
                    loading: !1,
                    error: {
                        message: t.data && t.data.message || t.message || "获取关注状态失败",
                        handleRetry: "updateSelf"
                    }
                });
            });
        },
        requestSelf: function() {
            var e = this;
            return t({
                url: "/self"
            }).then(function(t) {
                var s = t.data;
                return e.dispatch({
                    type: "updateSelf",
                    payload: s
                }), s;
            });
        }
    },
    attached: function() {
        var e = this;
        this.data.publication.subscription.approach.wechat && this.requestSelf().catch(function() {
            return e.requestSelf();
        }).catch(function() {
            return e.data.globalData.self;
        }).then(function(t) {
            t && !t.has_subscribed_mp && (e.selectComponent(".modal").setVisible(!0), wx.reportAnalytics("show_follow_guide", {
                source: "guide"
            }));
        }, function(e) {
            return console.error(e);
        });
    },
    pageLifetimes: {
        hide: function() {
            var e = this.selectComponent(".modal");
            e && e.data.visible && !this.data.success && this.setData({
                loading: !0
            });
        },
        show: function() {
            if (this.data.publication.subscription.approach.wechat) {
                var e = this.selectComponent(".modal");
                e && e.data.visible && !this.data.success && this.updateSelf();
            }
        }
    }
});