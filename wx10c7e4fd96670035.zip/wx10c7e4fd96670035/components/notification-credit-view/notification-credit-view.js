var t = require("../../behaviors/useGlobalData"), e = require("../../lib/authorizeSubscriptionMessage");

Component({
    externalClasses: [ "class-name" ],
    behaviors: [ t ],
    properties: {
        credit: {
            type: Number,
            value: 0
        }
    },
    data: {
        alwaysYes: void 0,
        loading: !1
    },
    attached: function() {
        this.updateSettings();
    },
    methods: {
        handleAdd: function() {
            var t = this;
            this.setData({
                loading: !0
            }), e().then(function() {
                var e = t.data.credit + 1;
                t.setData({
                    credit: e,
                    loading: !1
                }), t.updateSettings(), t.dispatch({
                    type: "updateSelf",
                    payload: {
                        notificationCredit: e
                    }
                }), wx.reportAnalytics("add_notification_credit", {
                    credit: e
                });
            }, function(e) {
                var i = e.type, a = e.message;
                t.setData({
                    loading: !1
                }), "reject" !== i && wx.showToast({
                    title: a,
                    icon: "error",
                    duration: 3e3
                });
            });
        },
        updateSettings: function() {
            var t = this;
            wx.getSetting({
                withSubscriptions: !0,
                success: function(e) {
                    var i = Boolean(e.subscriptionsSetting.itemSettings && "accept" === e.subscriptionsSetting.itemSettings["2TncyzIZm0Sc6uezjXgyWXkZG1cyYZB_HLlwmVguiyg"]);
                    t.setData({
                        alwaysYes: i
                    });
                }
            });
        }
    }
});