var t = getApp().store;

module.exports = Behavior({
    data: {
        globalData: t.getState()
    },
    attached: function() {
        var a = this;
        this.setData({
            globalData: t.getState()
        }), t.subscribe(function() {
            return a.setData({
                globalData: t.getState()
            });
        });
    },
    methods: {
        dispatch: function(a) {
            t.dispatch(a);
        }
    }
});