var e = require("../../api/product.js"), n = getApp();

n.window, new e.Product();

Page({
    data: {
        datasrc: ""
    },
    onLoad: function(e) {
        var t = e.url;
        e.annualreview && (t = "https://yjs.web.dezhengedu.com/WebPhone/Activity/2022/index.html?stuid=" + e.userstuid + "&sysid=" + n.globalData.SassID), 
        e.wenjuanis && (t = "https://yjs.web.dezhengedu.com/WxHtml/wenjuan.html?busid=1&saasid=1&stuid=" + e.userstuid), 
        e.wxservice && (t = "https://yjs.web.dezhengedu.com/WxService/QuestionGive.html?RecordID=" + e.recordid), 
        console.log("马上跳转连接中..."), this.setData({
            datasrc: t
        }), !n.globalData.StuID && e.annualreview && (n.checkLoginReadyCallback = function(e) {
            if ("登陆成功" == e.data.msg) {
                if (!e.data.data.SysUserInfo.StuID) return void wx.navigateTo({
                    url: "/pages/login"
                });
            } else wx.navigateTo({
                url: "/pages/login"
            });
        });
    },
    onReady: function() {},
    onShow: function() {},
    onHide: function() {},
    onUnload: function() {},
    onPullDownRefresh: function() {},
    onReachBottom: function() {},
    onShareAppMessage: function() {
        return util.wxShare({});
    }
});