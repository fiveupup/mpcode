var a, t = (a = require("../../utils/crypto.js")) && a.__esModule ? a : {
    default: a
}, e = require("../../utils/getToken.js");

var o = getApp(), s = o.window, n = require("../../utils/util.js");

Page({
    data: {
        window: s,
        timenum: 60,
        timeobj: null,
        isShowBtn: !1,
        isloadlogin: !1,
        info_id: o.globalData.wxInfoID
    },
    login: function() {
        var a = this;
        console.log("1. ---------------------------------------"), console.log("请求名称：微信授权获取用户基本信息"), 
        console.log("请求方法：wx.login -> wx.getUserProfile"), console.log("执行函数：login");
        this.data.isloadlogin || (this.data.isloadlogin = !0, wx.request({
            url: o.globalData.configs.TOP_HOST + "/api/wx_xcx_info/GetListByAll?System_Station_ID=" + o.globalData.SassID,
            success: function(s) {
                if (s.data.DES && s.data.data) try {
                    s.data.data = JSON.parse(t.default.decrypt(s.data));
                } catch (a) {
                    s.data.data = t.default.decrypt(s.data);
                }
                if (Array.isArray(s.data.data) && s.data.data.length > 0) {
                    if (o.globalData.appInfo = s.data.data[0], o.updataGlobalData("appInfo", s.data.data[0]), 
                    wx.setStorage({
                        data: o.globalData.appInfo,
                        key: "appInfo"
                    }), 1 == o.globalData.appInfo.IsWxappRespect) return void wx.redirectTo({
                        url: "/pages/respect/respect"
                    });
                    wx.login({
                        success: function(s) {
                            wx.showLoading({
                                title: "正在微信授权.."
                            });
                            var l = o.globalData.AgentBusType ? o.globalData.AgentBusType : "微信小程序";
                            "tuiguangrenyuan" == l && (l = "推广人员");
                            var i = "";
                            o.globalData.IsAgency > 0 ? o.globalData.AgencyStuID && (i = o.globalData.AgencyStuID) : (o.globalData.RecommendStuID && (i = o.globalData.RecommendStuID), 
                            o.globalData.PullNewStuID && o.globalData.PullNewID && (i = o.globalData.PullNewStuID, 
                            l = "拉新注册")), wx.request({
                                url: o.globalData.configs.TOP_HOST + "/api/wx/CheckCodeV2",
                                data: {
                                    Id: a.data.info_id,
                                    code: s.code,
                                    Source: l,
                                    SourceStuID: l ? i : ""
                                },
                                header: {
                                    "content-type": "application/json"
                                },
                                success: function(s) {
                                    if (s.data.DES && s.data.data) try {
                                        s.data.data = JSON.parse(t.default.decrypt(s.data));
                                    } catch (a) {
                                        s.data.data = t.default.decrypt(s.data);
                                    }
                                    var l = s.data;
                                    if (a.data.isloadlogin = !1, "登陆成功" == l.msg) {
                                        wx.hideLoading({
                                            fial: function(a) {}
                                        }), l.data.resule.session_key;
                                        var i = l.data.WxUserInfo;
                                        if (i.StuID.length > 3) {
                                            wx.setStorage({
                                                data: !0,
                                                key: "isLogin"
                                            }), o.globalData.isLogin = !0, console.log("-------------- login.js 初始化 ------------------------");
                                            var u = l.data.SysUserInfo;
                                            wx.setStorage({
                                                key: "StuID",
                                                data: u.StuID
                                            }), wx.setStorage({
                                                key: "SysUserInfo",
                                                data: u
                                            }), o.globalData.IsAct = 2 == u.IsAct, o.updataGlobalData("isLogin", !0), o.updataGlobalData("SysUserInfo", u), 
                                            o.updataGlobalData("StuID", u.StuID), o.updataGlobalData("Tel", u.Tel), o.updataGlobalData("IsAct", 2 == u.IsAct), 
                                            o.globalData.subjectindex = "数一" == u.SubjectType ? 0 : "数二" == u.SubjectType ? 1 : "数三" == u.SubjectType ? 2 : -1, 
                                            o.updataGlobalData("SubjectType", "数一" == u.SubjectType ? 0 : "数二" == u.SubjectType ? 1 : "数三" == u.SubjectType ? 2 : -1), 
                                            wx.setStorage({
                                                data: "数一" == u.SubjectType ? 0 : "数二" == u.SubjectType ? 1 : "数三" == u.SubjectType ? 2 : -1,
                                                key: "subjectindex"
                                            }), console.log("获取StuID：" + u.StuID), console.log("----------------------------------------------"), 
                                            console.log(i), o.updataGlobalData("userInfo", {
                                                SysUserInfo: u,
                                                userCode: u.ID,
                                                nickName: i.Nickname,
                                                avatarUrl: i.HeadImgurl,
                                                subscribe: i.Subscribe,
                                                OpenID: i.OpenID
                                            }), wx.setStorage({
                                                data: {
                                                    userCode: u.ID,
                                                    nickName: i.Nickname,
                                                    avatarUrl: i.HeadImgurl,
                                                    subscribe: i.Subscribe,
                                                    OpenID: i.OpenID
                                                },
                                                key: "userInfo"
                                            }), console.log("----------------------------------------------");
                                            var r = 1, d = "";
                                            u.VipEndTime && (r = o.isVipFunction(u.VipEndTime) ? 2 : 1), 2 == r && (d = u.VipEndTime), 
                                            o.updataGlobalData("vipLevel", r), o.updataGlobalData("VIPValidTime", d), wx.setStorage({
                                                data: r,
                                                key: "vipLevel"
                                            }), wx.setStorage({
                                                data: d,
                                                key: "VIPValidTime"
                                            }), console.log("----------------------------------------------");
                                            var p = l.data.UserInfo;
                                            console.log(p), p.length > 0 ? (o.updataGlobalData("UsersInfo", p), o.updataGlobalData("UsersInfo", p)) : (o.updataGlobalData("UsersInfo", []), 
                                            o.updataGlobalData("UsersInfo", []));
                                            var g = !1;
                                            if (o.globalData.appInfo && o.globalData.appInfo.BetaProduct && l.data.CourseUsers.length > 0) {
                                                var c = o.globalData.appInfo.BetaProduct.split(",");
                                                l.data.CourseUsers.map(function(a) {
                                                    c.map(function(t) {
                                                        a.CourseProductID == t && (g = !0);
                                                    });
                                                });
                                            }
                                            o.globalData.isBetaProduct = g, o.updataGlobalData("isBetaProduct", g), wx.setStorage({
                                                data: g,
                                                key: "isBetaProduct"
                                            });
                                            var f = !1;
                                            if (o.globalData.appInfo.BetaVipProduct) {
                                                if (o.globalData.appInfo.BetaVipProduct.indexOf("VIP用户") > -1 && 2 == r) ; else if (l.data.CourseUsers.length > 0) {
                                                    var D = o.globalData.appInfo.BetaVipProduct.split(",");
                                                    l.data.CourseUsers.map(function(a) {
                                                        D.map(function(t) {
                                                            a.CourseProductID == t && (f = !0);
                                                        });
                                                    });
                                                }
                                            } else f = !0;
                                            o.globalData.isBetaVipProduct = f, o.updataGlobalData("isBetaVipProduct", f), wx.setStorage({
                                                data: f,
                                                key: "isBetaVipProduct"
                                            });
                                            var b = !1;
                                            if (o.globalData.appInfo && o.globalData.appInfo.ParmText1) {
                                                if (o.globalData.appInfo.ParmText1.indexOf("VIP用户") > -1 && 2 == r) b = !0; else if (l.data.CourseUsers.length > 0) {
                                                    var I = o.globalData.appInfo.ParmText1.split(",");
                                                    l.data.CourseUsers.map(function(a) {
                                                        I.map(function(t) {
                                                            a.CourseProductID == t && (b = !0);
                                                        });
                                                    });
                                                }
                                            } else b = !1;
                                            o.globalData.isMajorComputing = b, o.updataGlobalData("isMajorComputing", b), wx.setStorage({
                                                data: b,
                                                key: "isMajorComputing"
                                            });
                                            var x = !1;
                                            l.data.CourseUsers.map(function(a) {
                                                1095 != a.CourseProductID && 1096 != a.CourseProductID && 1097 != a.CourseProductID || (x = !0);
                                            }), o.globalData.isLookMajorComputing = x, o.updataGlobalData("isLookMajorComputing", x), 
                                            wx.setStorage({
                                                data: x,
                                                key: "isLookMajorComputing"
                                            });
                                            var w = !1;
                                            if (o.globalData.appInfo.BetaDYProducts) {
                                                if (o.globalData.appInfo.BetaDYProducts.indexOf("VIP用户") > -1 && 2 == r) ; else if (l.data.CourseUsers.length > 0) {
                                                    var y = o.globalData.appInfo.BetaDYProducts.split(",");
                                                    l.data.CourseUsers.map(function(a) {
                                                        y.map(function(t) {
                                                            a.CourseProductID == t && (w = !0);
                                                        });
                                                    });
                                                }
                                            } else w = !1;
                                            if (o.globalData.isBetaDYVipProduct = w, o.updataGlobalData("isBetaDYVipProduct", w), 
                                            wx.setStorage({
                                                data: w,
                                                key: "isBetaDYVipProduct"
                                            }), console.log("----------------------------------------------"), wx.showToast({
                                                title: "登录成功"
                                            }), l.Token) {
                                                n.referAgentUrl(), n.setAppsource();
                                                var S = getCurrentPages(), m = 0;
                                                if (S.map(function(a, t) {
                                                    -1 == a.route.indexOf("pages/login") && (m = t);
                                                }), S[m].route.indexOf("pages/study/study") > -1) wx.switchTab({
                                                    url: "/pages/study/study"
                                                }); else if (S[m].route.indexOf("pages/index/index") > -1) wx.switchTab({
                                                    url: "/pages/index/index"
                                                }); else if (S[m].route.indexOf("pages/user/user") > -1) wx.switchTab({
                                                    url: "/pages/user/user"
                                                }); else if (S[m].route.indexOf("wenjuan/pages/UserInfo/UserInfo") > -1) wx.switchTab({
                                                    url: "/pages/study/study"
                                                }); else if (S[m].route.indexOf("pages/maintenance/maintenance") > -1) wx.switchTab({
                                                    url: "/pages/study/study"
                                                }); else if (S[m].route.indexOf("pages/pageLoading/pageLoading") > -1) wx.switchTab({
                                                    url: "/pages/study/study"
                                                }); else {
                                                    var h = S.length - m - 1;
                                                    h > 0 && -1 == S[m].route.indexOf("pages/login") ? wx.navigateBack({
                                                        delta: h,
                                                        success: function() {
                                                            S[m].onLoad(S[m].options);
                                                        }
                                                    }) : wx.switchTab({
                                                        url: "/pages/study/study"
                                                    });
                                                }
                                            } else wx.setStorageSync("isToken", !0), (0, e.getToken)(l.data.SysUserInfo.StuID).then(function(a) {
                                                n.referAgentUrl(), n.setAppsource();
                                                var t = getCurrentPages(), e = 0;
                                                if (t.map(function(a, t) {
                                                    -1 == a.route.indexOf("pages/login") && (e = t);
                                                }), t[e].route.indexOf("pages/study/study") > -1) wx.switchTab({
                                                    url: "/pages/study/study"
                                                }); else if (t[e].route.indexOf("pages/index/index") > -1) wx.switchTab({
                                                    url: "/pages/index/index"
                                                }); else if (t[e].route.indexOf("pages/user/user") > -1) wx.switchTab({
                                                    url: "/pages/user/user"
                                                }); else if (t[e].route.indexOf("wenjuan/pages/UserInfo/UserInfo") > -1) wx.switchTab({
                                                    url: "/pages/study/study"
                                                }); else if (t[e].route.indexOf("pages/maintenance/maintenance") > -1) wx.switchTab({
                                                    url: "/pages/study/study"
                                                }); else if (t[e].route.indexOf("pages/pageLoading/pageLoading") > -1) wx.switchTab({
                                                    url: "/pages/study/study"
                                                }); else {
                                                    var o = t.length - e - 1;
                                                    o > 0 && -1 == t[e].route.indexOf("pages/login") ? wx.navigateBack({
                                                        delta: o,
                                                        success: function() {
                                                            t[e].onLoad(t[e].options);
                                                        }
                                                    }) : wx.switchTab({
                                                        url: "/pages/study/study"
                                                    });
                                                }
                                            });
                                        } else a.onShow();
                                    } else "需绑定手机号码" == l.errmsg ? wx.switchTab({
                                        url: "/pages/study/study"
                                    }) : a.onShow();
                                }
                            });
                        },
                        fail: function(a) {
                            console.log("wx.login fail ...");
                        }
                    });
                }
            }
        }));
    },
    onLoad: function(a) {},
    onReady: function() {},
    onShow: function() {
        var a = this;
        wx.hideShareMenu(), this.data.timeobj && clearInterval(this.data.timeobj), this.setData({
            isShowBtn: !1,
            timenum: 60
        }), this.data.timeobj = setInterval(function() {
            var t = a.data.timenum;
            t > 0 ? (t -= 1, a.setData({
                timenum: t
            })) : (t = 0, clearInterval(a.data.timeobj), a.setData({
                timenum: t,
                isShowBtn: !0
            }));
        }, 1e3);
    },
    onHide: function() {
        this.data.timeobj && clearInterval(this.data.timeobj);
    },
    onUnload: function() {},
    onPullDownRefresh: function() {},
    onReachBottom: function() {},
    onShareAppMessage: function() {}
});