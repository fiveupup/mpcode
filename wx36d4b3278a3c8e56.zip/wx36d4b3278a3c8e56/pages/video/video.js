var o = require("../../utils/util.js"), t = getApp(), a = t.window;

Page({
    data: {
        window: a,
        navigator: {
            border: !1,
            color: "#333333",
            bg: "#ffffff",
            back: !0,
            leftText: "",
            title: "视频播放",
            othergoback: !0,
            othergoHome: !0
        },
        vid: "",
        videoIntroData: {},
        videoOutroData: {},
        logoData: {},
        StuID: ""
    },
    videoPause: function() {},
    timeUpdate: function() {},
    onLoad: function(o) {
        var a = this, e = o.vid;
        t.globalData.StuID ? this.setData({
            vid: e,
            StuID: t.globalData.StuID
        }) : t.checkLoginReadyCallback = function(o) {
            "登陆成功" == o.data.msg ? a.setData({
                vid: e,
                StuID: o.data.data.SysUserInfo.StuID
            }) : wx.navigateTo({
                url: "/pages/login"
            });
        };
    },
    onReady: function() {},
    onShow: function() {
        var o = {}, a = {}, e = {}, i = t.globalData.appInfo;
        e = !(!i || 1 != i.VideoLogoState) && {
            enable: !0,
            width: i.VideoLogoWidth + "px",
            height: i.VideoLogoHight + "px",
            src: i.VideoLogo,
            position: i.VideoLogoPosition,
            xOffset: i.VideoxOffset + "%",
            yOffset: i.VideoyOffset + "%"
        }, o = 1 == i.VideoTopEnable && {
            enable: !0,
            duration: i.VideoTopDuration,
            src: i.VideoTop,
            "show-skip-btn": i.VideoTopSkip
        }, a = 1 == i.VideoEndEnable && {
            enable: !0,
            duration: i.VideoEndDuration,
            src: i.VideoEnd,
            "show-skip-btn": i.VideoEndSkip
        }, this.setData({
            logoData: e,
            videoIntroData: o,
            videoOutroData: a
        });
    },
    onHide: function() {},
    onUnload: function() {},
    onPullDownRefresh: function() {},
    onReachBottom: function() {},
    onShareAppMessage: function() {
        return o.wxShare({});
    }
});