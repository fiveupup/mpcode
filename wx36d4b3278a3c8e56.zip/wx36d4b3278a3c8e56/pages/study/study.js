require("../../@babel/runtime/helpers/Arrayincludes");

var e, t = require("../../@babel/runtime/helpers/defineProperty"), a = require("../../@babel/runtime/helpers/regeneratorRuntime"), s = require("../../@babel/runtime/helpers/asyncToGenerator"), n = require("../../api/user"), i = (e = require("../../utils/util")) && e.__esModule ? e : {
    default: e
}, o = require("../../api/product.js"), r = require("../../api/question.js"), u = require("../../api/course");

var d = getApp(), c = d.window, l = new u.Course(), g = new o.Product(), p = (new r.Question(), 
new n.User());

Page({
    data: {
        window: c,
        navigator: {
            border: !1,
            color: "#333333",
            bg: "#ffe88c",
            back: !1,
            leftText: "考研数学欧几里得",
            title: ""
        },
        isReadUnInfo: !1,
        isOpenAuthDialog: !1,
        OpenID: "",
        StuID: "",
        userCode: "",
        isLogin: !1,
        userInfo: {},
        SysUserInfo: {},
        vipLevel: "普通用户",
        vipEndTime: "",
        InfoNum: 0,
        isHaveExamine: !1,
        vipEndDay: 0,
        isShowActHint: !1,
        isMonligtedTeacher: !1,
        isQuestionTeacher: !1,
        yearEndTime: 365,
        yearConut: 23,
        isVip: !1,
        subjectindex: -1,
        subjectlist: [ {
            value: "数一",
            index: 0
        }, {
            value: "数二",
            index: 1
        }, {
            value: "数三",
            index: 2
        } ],
        booktabIndex: 0,
        BookID: "",
        bookList: [],
        paperList: [],
        PaperIDs: "",
        isStudy: !1,
        delectCount: 0,
        couponShow: !1,
        couponThirdDayClick: !1,
        couponcardNum: 0,
        couponcardList: [],
        iswikifixed: !1,
        choice1: !1,
        choice2: !1,
        choice3: !1,
        choiceType: 0,
        ChoiceTips: !1,
        albumList: [],
        albumDelArr: [],
        SeekpaiImg: {
            cameraImg: "https://ojld.oss-cn-shanghai.aliyuncs.com/Yjs/202210/c955896c-bf68-485b-9760-9f1d1d3cab83.png",
            archie: "https://ojld.oss-cn-shanghai.aliyuncs.com/Yjs/202210/ed697d69-7b4d-4a12-b39a-4b51b575d8b4.png",
            booklog: "",
            textAdContent: "版本持续更新中..."
        },
        IsPerfectcard: !1,
        interval1: "",
        interval2: "",
        IsActframes: !1,
        albumScrollID: 0,
        albumScrolltopID: 0,
        albumScrollCount: 0,
        StuIDIsLogin: !1,
        isIOS: !1,
        isCourse: !1,
        buoyList: [],
        isbuoyShow: !1,
        indexADList: [],
        indexADShow: !1,
        isShowdel: !1,
        delmodel: {
            isshowClear: !1,
            title: "移除提示",
            titlecolor: "#CF4935",
            content: "是否确认从书架移除.",
            btnList: [ {
                content: "取消",
                bgcolor: "#F3F3F3",
                color: "#333333",
                id: 2
            }, {
                content: "确认",
                bgcolor: "#FFDC21",
                color: "#333333",
                id: 1
            } ]
        },
        UserPayVipList: [],
        isCourseClass: !1,
        isLookMajorComputing: !1,
        isMajorComputing: !1,
        isMajorComputingalt: !1,
        IswuVipLook: !1,
        isiosservice: !1,
        BannerList: [],
        ProductList: [],
        BannerListios: [],
        isIOSCouponUser: !1,
        regCouponTime: "2023-07-20 00:00:00",
        showPage1: !0,
        showContainer: !0,
        MyIntegral: 0,
        todyrIntegral: 0,
        isApplyMockExam: !1,
        isNoprompt: !1,
        isDelType: 0,
        updatanum: 0,
        ChannelsLiveState: 0,
        ChannelsLiveID: 0,
        isShowChannelsLive: !1
    },
    updateData: function() {
        wx.showLoading({
            title: "加载中"
        });
        try {
            wx.removeStorageSync("LoginToken");
        } catch (e) {}
        d.onLaunch(), d.checkLoginReadyCallback = function(e) {
            "登陆成功" == e.data.msg && setTimeout(function() {
                wx.hideLoading({
                    success: function(e) {}
                }), wx.showToast({
                    title: "更新成功"
                });
            }, 1e3);
        };
    },
    guanbiLive: function() {
        i.default.dateFormat("YYYY-MM-DD", new Date());
        wx.setStorageSync(!0), this.setData({
            isShowChannelsLive: !1
        });
    },
    gotochannelsLive: function() {
        if (1 == this.data.ChannelsLiveState) wx.reserveChannelsLive({
            noticeId: this.data.ChannelsLiveID
        }); else if (2 == this.data.ChannelsLiveState) {
            wx.openChannelsLive({
                finderUserName: "sphtpNXlwcsWy5I"
            });
        }
    },
    getvideoLiveinfo: function() {
        var e = "sphtpNXlwcsWy5I", t = this;
        wx.getChannelsLiveNoticeInfo({
            finderUserName: e,
            success: function(e) {
                if (e && 0 == e.status && e.reservable) {
                    var a = e.noticeId;
                    t.setData({
                        ChannelsLiveState: 1,
                        ChannelsLiveID: a
                    });
                }
            },
            fail: function(e) {}
        }), wx.getChannelsLiveInfo({
            finderUserName: e,
            success: function(e) {
                if (e && 2 == e.status) {
                    t.setData({
                        ChannelsLiveState: 2,
                        ChannelsLiveID: 0
                    });
                }
            },
            fail: function(e) {}
        });
    },
    GetNoReadContentList: function() {
        var e = this;
        return s(a().mark(function t() {
            var s, n, o;
            return a().wrap(function(t) {
                for (;;) switch (t.prev = t.next) {
                  case 0:
                    if (!(s = i.default.IsStorageSyncExpire("studyGetNoReadContentListdata")) || !Array.isArray(s)) {
                        t.next = 5;
                        break;
                    }
                    s = s, t.next = 10;
                    break;

                  case 5:
                    return n = {
                        StuID: e.data.StuID
                    }, t.next = 8, g.GetNoReadContentList(n);

                  case 8:
                    o = t.sent, Array.isArray(o.data) && o.data.length > 0 && Array.isArray(o.data[0]) ? (s = o.data[0], 
                    i.default.AddSotrageSyncExpire("studyGetNoReadContentListdata", s)) : s = [];

                  case 10:
                    s.length > 0 && e.setData({
                        updatanum: s[0].count
                    });

                  case 11:
                  case "end":
                    return t.stop();
                }
            }, t);
        }))();
    },
    SubNoprompt: function(e) {
        var t = e.currentTarget.dataset.item;
        wx.setStorageSync("ADisNoprompt" + t.ID, !this.data.isNoprompt), this.setData({
            isNoprompt: !this.data.isNoprompt
        });
    },
    gotodetails: function(e) {
        if (this.checkUserLogin()) {
            var t = e.currentTarget.dataset.index, a = "";
            0 == t ? (a = "模拟考试", wx.navigateTo({
                url: "/dryrun/pages/dryunlist/dryunlist"
            })) : 1 == t ? (a = "专业选择", wx.navigateTo({
                url: "/school/pages/InfoFill/InfoFill"
            })) : 2 == t ? (a = "选择题库", wx.navigateTo({
                url: "/choice/pages/index"
            })) : 3 == t ? (a = "数学专辑", wx.navigateTo({
                url: "/choice/pages/albumindex/albumindex"
            })) : 4 == t ? (a = "6点档", wx.navigateTo({
                url: "/wenjuan/pages/Liveindex/Liveindex"
            })) : 5 == t ? (a = "题号搜索", wx.navigateTo({
                url: "/topic/pages/searchQuestion/searchQuestion"
            })) : 6 == t ? (a = "错题本", wx.navigateTo({
                url: "/user/pages/MyNotesList/MyNotesList?type=0"
            })) : 7 == t ? (a = "收藏", wx.navigateTo({
                url: "/user/pages/MyNotesList/MyNotesList?type=1"
            })) : 8 == t ? (a = "学习记录", wx.navigateTo({
                url: "/user/pages/browse/browse"
            })) : 9 == t ? (a = "课程", wx.navigateTo({
                url: "/course/pages/Courseindex/Courseindex"
            })) : 10 == t && (a = "四大计算", wx.navigateTo({
                url: "/choice/pages/MajorComputing/catalog/catalog"
            })), d.addHeadImgListLog2("学习", a);
        }
    },
    GetFunctionAllocationList: function() {
        var e = this;
        return s(a().mark(function t() {
            var s, n;
            return a().wrap(function(t) {
                for (;;) switch (t.prev = t.next) {
                  case 0:
                    if (!(s = i.default.IsStorageSyncExpire("studyAndindexGetFunctionAllocationListData")) || !Array.isArray(s)) {
                        t.next = 5;
                        break;
                    }
                    s = s, t.next = 9;
                    break;

                  case 5:
                    return t.next = 7, g.GetFunctionAllocationList({
                        StuID: e.data.StuID,
                        BusType: "考试用户",
                        System_Station_ID: d.globalData.SassID
                    });

                  case 7:
                    n = t.sent, Array.isArray(n.data) ? (s = n.data, i.default.AddSotrageSyncExpire("studyAndindexGetFunctionAllocationListData", s)) : s = [];

                  case 9:
                    s.length > 0 ? e.data.isApplyMockExam = !0 : e.data.isApplyMockExam = !1, e.getBookList();

                  case 11:
                  case "end":
                    return t.stop();
                }
            }, t);
        }))();
    },
    GetcomputingInfoList: function() {
        var e = this;
        return s(a().mark(function t() {
            var s, n, o;
            return a().wrap(function(t) {
                for (;;) switch (t.prev = t.next) {
                  case 0:
                    if (s = !1, !(n = i.default.IsStorageSyncExpire("computingInfoGetFunctionAllocationListData")) || !Array.isArray(n)) {
                        t.next = 6;
                        break;
                    }
                    n.length > 0 && (s = !0), t.next = 10;
                    break;

                  case 6:
                    return t.next = 8, g.GetFunctionAllocationList({
                        StuID: e.data.StuID,
                        BusType: "四大计算",
                        page: 1,
                        limit: 1e3
                    });

                  case 8:
                    o = t.sent, Array.isArray(o.data) && o.data.length > 0 ? (n = o.data, i.default.AddSotrageSyncExpire("computingInfoGetFunctionAllocationListData", n), 
                    s = !0) : s = !1;

                  case 10:
                    e.setData({
                        isMajorComputingalt: s
                    });

                  case 11:
                  case "end":
                    return t.stop();
                }
            }, t);
        }))();
    },
    gotointegral: function() {
        this.checkUserLogin() && (this.closeChoicebtn(), wx.navigateTo({
            url: "/user/pages/Integral/Integral"
        }));
    },
    getUserIntegral: function() {
        var e = this;
        return s(a().mark(function t() {
            var s, n, o, r;
            return a().wrap(function(t) {
                for (;;) switch (t.prev = t.next) {
                  case 0:
                    if (!(s = i.default.IsStorageSyncExpire("studyGetUserIntegraldata")) || !Array.isArray(s)) {
                        t.next = 5;
                        break;
                    }
                    s = s, t.next = 9;
                    break;

                  case 5:
                    return t.next = 7, g.GetUserIntegral({
                        StuID: e.data.StuID
                    });

                  case 7:
                    n = t.sent, Array.isArray(n.data) && n.data.length > 0 && Array.isArray(n.data[0]) ? (s = n.data[0], 
                    i.default.AddSotrageSyncExpire("studyGetUserIntegraldata", s)) : s = [];

                  case 9:
                    if (s.length > 0 && e.setData({
                        MyIntegral: s[0].Integral
                    }), !(o = i.default.IsStorageSyncExpire("studyGetIntegralRuleInfodata")) || !Array.isArray(o)) {
                        t.next = 15;
                        break;
                    }
                    o = o, t.next = 19;
                    break;

                  case 15:
                    return t.next = 17, g.GetIntegralRuleInfo({
                        System_Station_ID: d.globalData.SassID,
                        StuID: e.data.StuID
                    });

                  case 17:
                    r = t.sent, Array.isArray(r.data) && r.data.length > 3 ? (o = r.data[3], i.default.AddSotrageSyncExpire("studyGetIntegralRuleInfodata", o)) : o = [];

                  case 19:
                    o.length > 0 ? e.setData({
                        todyrIntegral: o[0].Integral ? o[0].Integral : 0
                    }) : e.setData({
                        todyrIntegral: 0
                    });

                  case 20:
                  case "end":
                    return t.stop();
                }
            }, t);
        }))();
    },
    hideIosService: function() {
        this.setData({
            isiosservice: !1
        });
    },
    getUserPayFirstVipList: function() {
        var e = this;
        return s(a().mark(function t() {
            var s, n;
            return a().wrap(function(t) {
                for (;;) switch (t.prev = t.next) {
                  case 0:
                    if (!(s = i.default.IsStorageSyncExpire("studyGetUserPayFirstVipListdata")) || !Array.isArray(s)) {
                        t.next = 5;
                        break;
                    }
                    s = s, t.next = 9;
                    break;

                  case 5:
                    return t.next = 7, g.GetUserPayFirstVipList({
                        System_Station_ID: d.globalData.SassID,
                        StuID: e.data.StuID
                    });

                  case 7:
                    n = t.sent, Array.isArray(n.data) && n.data.length > 0 && Array.isArray(n.data[0]) ? (s = n.data[0], 
                    i.default.AddSotrageSyncExpire("studyGetUserPayFirstVipListdata", s)) : s = [];

                  case 9:
                    s.length > 0 && (e.data.UserPayVipList = s), e.disposeData(), e.disposebuoyData();

                  case 12:
                  case "end":
                    return t.stop();
                }
            }, t);
        }))();
    },
    getBannerList: function() {
        var e = this;
        return s(a().mark(function t() {
            var s, n, o, r, u, c, l;
            return a().wrap(function(t) {
                for (;;) switch (t.prev = t.next) {
                  case 0:
                    if (s = e, !(n = i.default.IsStorageSyncExpire("studyGetHeadImgByBannerListdata")) || !Array.isArray(n)) {
                        t.next = 6;
                        break;
                    }
                    n = n, t.next = 11;
                    break;

                  case 6:
                    return o = {
                        System_Station_ID: d.globalData.SassID,
                        BusType: "首页轮播",
                        StuID: e.data.StuID,
                        IsValid: 1,
                        Type: -1
                    }, t.next = 9, g.GetHeadImg(o);

                  case 9:
                    r = t.sent, Array.isArray(r.data) ? (n = r.data, i.default.AddSotrageSyncExpire("studyGetHeadImgByBannerListdata", n)) : n = [];

                  case 11:
                    u = [], c = [], l = [], n.map(function(e) {
                        "0001-01-01T00:00:00" != e.ReleaseTime && "1900-01-01 00:00:00" != e.ReleaseTime && e.ReleaseTime ? new Date() > new Date(e.ReleaseTime) && l.push(e) : l.push(e);
                    }), l.map(function(t) {
                        t.HeadImg && (t.HeadImg = t.HeadImg.replace(/.png_yjs/g, ".png"), t.HeadImgarr = t.HeadImg.split(";")), 
                        t.HeadImgarr.length < 2 && t.HeadImgarr.push(""), e.data.isIOS && t.HeadImgarr[1] && c.push(t), 
                        "问卷调查" == t.Title ? s.data.IsWenJuan || u.push(t) : t.Title.indexOf("_老用户") > 1 ? d.globalData.isFristLogin || u.push(t) : t.Title.indexOf("_首客") > 1 ? d.globalData.isFristLogin && u.push(t) : u.push(t);
                    }), e.setData({
                        BannerList: u,
                        BannerListios: c
                    });

                  case 17:
                  case "end":
                    return t.stop();
                }
            }, t);
        }))();
    },
    getIndexAd: function() {
        var e = this;
        return s(a().mark(function t() {
            var s, n, o, r, u, c;
            return a().wrap(function(t) {
                for (;;) switch (t.prev = t.next) {
                  case 0:
                    if (s = e, !(n = i.default.IsStorageSyncExpire("studyGetHeadImgByindexADList")) || !Array.isArray(n)) {
                        t.next = 6;
                        break;
                    }
                    n = n, t.next = 11;
                    break;

                  case 6:
                    return o = {
                        System_Station_ID: d.globalData.SassID,
                        BusType: "首页弹窗",
                        StuID: e.data.StuID,
                        IsValid: 1,
                        Type: -1,
                        IsLayer: 1
                    }, t.next = 9, g.GetHeadImg(o);

                  case 9:
                    r = t.sent, Array.isArray(r.data) ? (n = r.data, i.default.AddSotrageSyncExpire("studyGetHeadImgByindexADList", n)) : n = [];

                  case 11:
                    n.length > 0 && (u = [], c = [], n.map(function(e) {
                        "0001-01-01T00:00:00" != e.ReleaseTime && "1900-01-01 00:00:00" != e.ReleaseTime && e.ReleaseTime ? new Date() > new Date(e.ReleaseTime) && c.push(e) : c.push(e);
                    }), c.map(function(e) {
                        e.HeadImg && (e.HeadImg = e.HeadImg.replace(/.png_yjs/g, ".png"), e.Json = "" != e.Json && null != e.Json ? parseInt(e.Json) : 0, 
                        e.HeadImgarr = e.HeadImg.split(";")), e.HeadImgarr.length < 2 && e.HeadImgarr.push(""), 
                        "问卷调查" == e.Title && s.data.IsWenJuan || u.push(e);
                    }), u = u.sort(function(e, t) {
                        return e.Json - t.Json;
                    }), e.setData({
                        indexADList: u
                    })), e.getIndexbuoy();

                  case 13:
                  case "end":
                    return t.stop();
                }
            }, t);
        }))();
    },
    getIndexbuoy: function() {
        var e = this;
        return s(a().mark(function t() {
            var s, n, o, r, u;
            return a().wrap(function(t) {
                for (;;) switch (t.prev = t.next) {
                  case 0:
                    if (e, !(s = i.default.IsStorageSyncExpire("studyGetHeadImgBybuoyListdata")) || !Array.isArray(s)) {
                        t.next = 6;
                        break;
                    }
                    s = s, t.next = 11;
                    break;

                  case 6:
                    return n = {
                        System_Station_ID: d.globalData.SassID,
                        BusType: "学习页浮标",
                        StuID: e.data.StuID,
                        IsValid: 1,
                        Type: -1,
                        IsLayer: 1
                    }, t.next = 9, g.GetHeadImg(n);

                  case 9:
                    o = t.sent, Array.isArray(o.data) ? (s = o.data, i.default.AddSotrageSyncExpire("studyGetHeadImgBybuoyListdata", s)) : s = [];

                  case 11:
                    r = [], s.length > 0 && (u = [], s.map(function(e) {
                        "0001-01-01T00:00:00" != e.ReleaseTime && "1900-01-01 00:00:00" != e.ReleaseTime && e.ReleaseTime ? new Date() > new Date(e.ReleaseTime) && u.push(e) : u.push(e);
                    }), u.map(function(e) {
                        e.HeadImg && (e.HeadImg = e.HeadImg.replace(/.png_yjs/g, ".png"), e.HeadImg = e.HeadImg.replace(/.gif_yjs/g, ".gif"), 
                        e.Json = "" != e.Json && null != e.Json ? parseInt(e.Json) : 0, e.HeadImgarr = e.HeadImg.split(";")), 
                        e.HeadImgarr.length < 2 && e.HeadImgarr.push(""), r.push(e);
                    }), r = r.sort(function(e, t) {
                        return e.Json - t.Json;
                    }), e.setData({
                        buoyList: r
                    })), e.getUserPayFirstVipList();

                  case 14:
                  case "end":
                    return t.stop();
                }
            }, t);
        }))();
    },
    disposebuoyData: function() {
        var e = [], t = this.data.buoyList, a = this.data.UserPayVipList, s = this.data.SysUserInfo.LoginCount, n = wx.getStorageSync("LoginCount") ? wx.getStorageSync("LoginCount") : 0, o = !1, r = i.default.dateFormat("YYYY-MM-DD", new Date()), u = this.data.isVip, d = new Date().getFullYear();
        if (t.length > 0) for (var c = 0; c < t.length; c++) if (1 != t[c].Json) if (2 == t[c].Json && u) e.push(t[c]); else if (3 != t[c].Json || u) {
            if (4 == t[c].Json) {
                var l = this.deweight(a, "ProductName", "上岸卡"), g = l.buy ? l.buylist.buyAddTime.substring(0, 4) : "";
                if (u && l.buy && d == g) {
                    e.push(t[c]);
                    continue;
                }
            } else if (5 == t[c].Json) {
                var p = this.deweight(a, "ProductName", "半年卡"), I = p.buy ? p.buylist.buyAddTime.substring(0, 4) : "";
                if (u && p.buy && d == I) {
                    e.push(t[c]);
                    continue;
                }
            } else if (6 == t[c].Json) {
                var D = this.deweight(a, "ProductName", "季卡"), y = D.buy ? D.buylist.buyAddTime.substring(0, 4) : "";
                if (u && D.buy && d == y) {
                    e.push(t[c]);
                    continue;
                }
            } else if (7 == t[c].Json) {
                var h = this.deweight(a, "ProductName", "月卡"), f = h.buy ? h.buylist.buyAddTime.substring(0, 4) : "";
                if (u && h.buy && d == f) {
                    e.push(t[c]);
                    continue;
                }
            } else if (8 == t[c].Json) {
                var S = this.deweight(a, "ProductName", "首月卡"), b = S.buy ? S.buylist.buyAddTime.substring(0, 4) : "";
                if (u && S.buy && d == b) {
                    e.push(t[c]);
                    continue;
                }
            } else if (0 == t[c].Json || null == t[c].Json || "" == t[c].Json) {
                e.push(t[c]);
                continue;
            }
        } else e.push(t[c]); else {
            if (!this.deweight(a, "ProductName", "首月卡").buy) if (e.push(t[c]), o = !0, n > 0 && s - n >= 20) wx.setStorageSync("isbuoyShow2", !1), 
            o = !0; else try {
                wx.getStorageSync("isbuoyShow2") && (o = !1);
            } catch (e) {}
            (0 == e.length || s < 20) && (o = !1), this.setData({
                buoyList: e,
                isbuoyShow: o
            });
        }
        if ((e = e.sort(function(e, t) {
            return e.Json - t.Json;
        })).length > 0 && 1 != e[0].Json) {
            o = !0;
            try {
                wx.getStorageSync(r + "" + e[0].ID) && (o = !1);
            } catch (e) {}
        } else o = o;
        (this.data.isCourseClass || this.data.SysUserInfo.LoginCount < 3) && (o = !1), this.setData({
            buoyList: e,
            isbuoyShow: o
        });
    },
    disposeData: function() {
        var e = this.data.indexADList, t = [], a = this.data.UserPayVipList, s = this.data.SysUserInfo.LoginCount, n = wx.getStorageSync("LoginCount") ? wx.getStorageSync("LoginCount") : 0, o = !1, r = i.default.dateFormat("YYYY-MM-DD", new Date()), u = this.data.isVip, d = new Date().getFullYear();
        if (e.length > 0) for (var c = 0; c < e.length; c++) if (1 != e[c].Json) if (2 == e[c].Json && u) t.push(e[c]); else if (3 != e[c].Json || u) {
            if (4 == e[c].Json) {
                var l = this.deweight(a, "ProductName", "上岸卡"), g = l.buy ? l.buylist.buyAddTime.substring(0, 4) : "";
                if (u && l.buy && d == g) {
                    t.push(e[c]);
                    continue;
                }
            } else if (5 == e[c].Json) {
                var p = this.deweight(a, "ProductName", "半年卡"), I = p.buy ? p.buylist.buyAddTime.substring(0, 4) : "";
                if (u && p.buy && d == I) {
                    t.push(e[c]);
                    continue;
                }
            } else if (6 == e[c].Json) {
                var D = this.deweight(a, "ProductName", "季卡"), y = D.buy ? D.buylist.buyAddTime.substring(0, 4) : "";
                if (u && D.buy && d == y) {
                    t.push(e[c]);
                    continue;
                }
            } else if (7 == e[c].Json) {
                var h = this.deweight(a, "ProductName", "月卡"), f = h.buy ? h.buylist.buyAddTime.substring(0, 4) : "";
                if (u && h.buy && d == f) {
                    t.push(e[c]);
                    continue;
                }
            } else if (7 == e[c].Json) {
                var S = this.deweight(a, "ProductName", "首月卡"), b = S.buy ? S.buylist.buyAddTime.substring(0, 4) : "";
                if (u && S.buy && d == b) {
                    t.push(e[c]);
                    continue;
                }
            } else if (0 == e[c].Json || null == e[c].Json || "" == e[c].Json) {
                t.push(e[c]);
                continue;
            }
        } else (!this.data.isIOS || 338 != e[c].ID && 339 != e[c].ID) && t.push(e[c]); else {
            if (!this.deweight(a, "ProductName", "首月卡").buy) if (t.push(e[c]), o = !0, n > 0 && s - n >= 20) {
                o = !0;
                try {
                    wx.getStorageSync(r + "" + e[c].ID) && (o = !1);
                } catch (e) {}
            } else try {
                wx.getStorageSync(r + "" + e[c].ID) && (o = !1);
            } catch (e) {}
            (0 == t.length || s < 20) && (o = !1), this.setData({
                indexADList: t,
                indexADShow: o
            });
        }
        if ((t = t.sort(function(e, t) {
            return e.Json - t.Json;
        })).length > 0 && 1 != t[0].Json) {
            o = !0;
            try {
                var x = wx.getStorageSync(r + "" + t[0].ID), m = wx.getStorageSync("ADisNoprompt" + t[0].ID);
                (x || m) && (o = !1);
            } catch (e) {}
        } else o = o;
        (this.data.isCourseClass || this.data.SysUserInfo.LoginCount < 3) && (o = !1), this.setData({
            indexADList: t,
            indexADShow: o
        });
    },
    clickclear: function() {
        this.data.SysUserInfo.LoginCount;
        var e = i.default.dateFormat("YYYY-MM-DD", new Date());
        this.data.indexADList[0].BusType.indexOf("首页弹窗") > -1 && wx.setStorageSync(e + "" + this.data.indexADList[0].ID, !0), 
        this.setData({
            indexADShow: !1
        });
    },
    gotoAD: function(e) {
        var t = e.currentTarget.dataset.item, a = e.currentTarget.dataset.index, s = i.default.dateFormat("YYYY-MM-DD", new Date()), n = this;
        if (this.checkUserLogin()) if (1 == a) wx.setStorageSync("isbuoyShow2", !0), wx.setStorageSync("LoginCount", this.data.SysUserInfo.LoginCount), 
        wx.setStorageSync(s + "" + t.ID, !0), this.setData({
            isbuoyShow: !1
        }); else {
            if (d.addHeadImgListLog(t.ID), 1 == t.Json) return wx.setStorageSync("AD" + t.ID, !0), 
            wx.setStorageSync(s + "" + t.ID, !0), wx.setStorageSync("LoginCount", this.data.SysUserInfo.LoginCount), 
            wx.navigateTo({
                url: "/wenjuan/pages/VIPInfo/VIPInfo?FirstPay=1"
            }), !1;
            if (1 == t.IsToUrl) {
                if (t.BusType.indexOf("首页弹窗") > -1) try {
                    wx.setStorageSync(s + "" + t.ID, !0);
                } catch (e) {}
                wx.navigateTo({
                    url: "/pages/about/about?ID=" + t.ID
                }), this.setData({
                    indexADShow: !1
                });
            } else if (t.Url) {
                if (t.BusType.indexOf("首页弹窗") > -1) try {
                    wx.setStorageSync(s + "" + t.ID, !0);
                } catch (e) {}
                if (this.setData({
                    indexADShow: !1
                }), t.Url.indexOf("mp.weixin.qq.com") > -1) wx.navigateTo({
                    url: "/pages/webview/webview?url=" + t.Url
                }); else if (t.Url.indexOf("https://") > -1) {
                    var o = t.Url;
                    if (t.Contexts && this.isJSON(t.Contexts)) {
                        var r = JSON.parse(t.Contexts), u = "";
                        r.map(function(e) {
                            u = u + "&" + e.toLocaleLowerCase() + "=" + n.data[e];
                        }), u && (u = (u = u.slice(1)) + "&v=" + Date.now(), o = o.indexOf("?") > -1 ? o + "&" + u : o + "?" + u);
                    }
                    "https://yjs.web.dezhengedu.com/WebPhone/Activity/2022/index.html" == o ? wx.navigateTo({
                        url: "/pages/webview/webview?annualreview=1&userstuid=" + n.data.StuID
                    }) : wx.navigateTo({
                        url: "/pages/webview/webview?wenjuanis=1&userstuid=" + n.data.StuID
                    });
                } else wx.navigateTo({
                    url: t.Url
                });
            } else wx.previewImage({
                current: t.HeadImg,
                urls: [ t.HeadImg ]
            });
        }
    },
    deweight: function(e, t, a) {
        var s = {
            buy: !1,
            buylist: ""
        };
        return e.some(function(e) {
            return e[t].indexOf(a) > -1 ? (s.buy = !0, s.buylist = e, !0) : (s.buy = !1, !1);
        }), s;
    },
    GetCourse: function() {
        var e = this;
        return s(a().mark(function t() {
            var s, n, o, r, u;
            return a().wrap(function(t) {
                for (;;) switch (t.prev = t.next) {
                  case 0:
                    if (!(s = i.default.IsStorageSyncExpire("userAndStudyGetCoursedata")) || !Array.isArray(s)) {
                        t.next = 5;
                        break;
                    }
                    s = s, t.next = 10;
                    break;

                  case 5:
                    return n = {
                        StuID: e.data.StuID,
                        System_Station_ID: d.globalData.SassID,
                        Type: "培训课程",
                        SortDesc: "Sort"
                    }, t.next = 8, g.GetProductByStuID(n);

                  case 8:
                    o = t.sent, Array.isArray(o.data) ? (s = o.data, i.default.AddSotrageSyncExpire("userAndStudyGetCoursedata", s)) : s = [];

                  case 10:
                    if (r = !1, !(s.length > 0)) {
                        t.next = 24;
                        break;
                    }
                    u = 0;

                  case 13:
                    if (!(u < s.length)) {
                        t.next = 20;
                        break;
                    }
                    if (1095 != s[u].ID && 1096 != s[u].ID && 1097 != s[u].ID) {
                        t.next = 17;
                        break;
                    }
                    return r = !0, t.abrupt("break", 20);

                  case 17:
                    u++, t.next = 13;
                    break;

                  case 20:
                    e.setData({
                        isCourseClass: r
                    }), e.setData({
                        isCourse: !0
                    }), t.next = 26;
                    break;

                  case 24:
                    e.setData({
                        isCourseClass: r
                    }), e.setData({
                        isCourse: !1
                    });

                  case 26:
                  case "end":
                    return t.stop();
                }
            }, t);
        }))();
    },
    changealbumScrollID: function(e) {
        this.setData({
            albumScrolltopID: e.currentTarget.dataset.id,
            albumScrollID: e.currentTarget.dataset.id
        });
    },
    gotoupdate: function() {
        wx.navigateTo({
            url: "/wenjuan/pages/UpdateList/UpdateList"
        });
    },
    translateDataToTree: function(e) {
        return e.filter(function(t) {
            var a = e.filter(function(e) {
                return t.ID == e.PID;
            });
            return a.length > 0 && (t.children = a), 0 == t.PID;
        });
    },
    closeChoicebtn: function() {
        this.setData({
            ChoiceTips: !1
        });
    },
    choicekbtn: function() {
        this.checkUserLogin() && (this.closeChoicebtn(), wx.navigateTo({
            url: "/wenjuan/pages/VIPInfo/VIPInfo"
        }));
    },
    getPageScroll: function(e) {
        var t = this;
        (wx.createSelectorQuery().select(".content_book_boxs").boundingClientRect(function(e) {
            (e && e.top ? e.top : 0) < 105 + c.statusBarHeight ? t.setData({
                iswikifixed: !0
            }) : t.setData({
                iswikifixed: !1
            });
        }).exec(), 2 == this.data.booktabIndex) && (5 == parseInt(10 * Math.random()) && wx.createSelectorQuery().in(this).selectAll(".catalog_album").boundingClientRect(function(e) {
            if (Array.isArray(e) && e.length > 0) {
                var a = 999999, s = 0;
                e.map(function(e) {
                    e.topheight = e.top - c.statusBarHeight - 45, e.topheight < 10 && (e.topheight < 0 && (e.topheight = -e.topheight), 
                    e.topheight < a && (a = e.topheight, e.id && (s = parseInt(e.id.replace(/[^\d]/g, " ")))));
                }), s > 0 && t.setData({
                    albumScrollID: s
                });
            }
        }).exec());
    },
    chengasubject: function(e) {
        var t = this;
        wx.showLoading({
            title: "正在切换..."
        }), t.setData({
            subjectindex: e.detail.value,
            choiceType: 0 == e.detail.value ? 1 : 1 == e.detail.value ? 2 : 2 == e.detail.value ? 3 : 0
        }), d.updataGlobalData("subjectindex", e.detail.value), p.updataUserChoiceType({
            ID: this.data.SysUserInfo.ID,
            ChoiceType: 0 == e.detail.value ? "数一" : 1 == e.detail.value ? "数二" : 2 == e.detail.value ? "数三" : ""
        }).then(function(e) {});
        var a = {
            ID: this.data.SysUserInfo.ID,
            SubjectType: 0 == e.detail.value ? "数一" : 1 == e.detail.value ? "数二" : 2 == e.detail.value ? "数三" : ""
        };
        p.updataSubjectType(a).then(function(e) {
            (e.msg = "操作成功") && t.getBookList();
        });
    },
    getBookPaperList: function() {
        var e = this;
        return s(a().mark(function t() {
            var s, n, o, r, u;
            return a().wrap(function(t) {
                for (;;) switch (t.prev = t.next) {
                  case 0:
                    if (s = e, !(n = i.default.IsStorageSyncExpire("indexAndStudyGetBookListOfVipByPaper")) || !Array.isArray(n)) {
                        t.next = 6;
                        break;
                    }
                    n = n, t.next = 10;
                    break;

                  case 6:
                    return t.next = 8, l.GetBookListOfVip({
                        IsValid: 1,
                        System_Station_ID: d.globalData.SassID,
                        BusType: "试卷",
                        IsBook: 1,
                        IsBeta: 0,
                        IsRecommend: ""
                    });

                  case 8:
                    o = t.sent, Array.isArray(o.data) && o.data.length > 0 && Array.isArray(o.data[0]) ? (n = o.data[0], 
                    i.default.AddSotrageSyncExpire("indexAndStudyGetBookListOfVipByPaper", n)) : n = [];

                  case 10:
                    if (n.length > 0) {
                        if (r = [], u = [], [], s.data.SysUserInfo.PaperIDs) s.data.PaperIDs = e.data.SysUserInfo.PaperIDs; else try {
                            wx.getStorageSync({
                                key: "PaperIDs",
                                success: function(e) {
                                    e.data && (s.data.PaperIDs = e.data);
                                }
                            });
                        } catch (e) {}
                        s.data.PaperIDs || (s.data.PaperIDs = "863,926,957"), s.data.PaperIDs.toString().split(",").map(function(e) {
                            n.map(function(t) {
                                t.HeadImg && (t.HeadImg = t.HeadImg.replace(/.png_yjs/g, ".png")), t.isSelect = !1, 
                                t.ID == e && (t.isSelect = !0, t.isDelect = !1, r.push(t));
                            });
                        }), r.map(function(e, t) {
                            0 != s.data.subjectindex || "数一" != e.BusValue && "通用" != e.BusValue || u.push(e), 
                            1 != s.data.subjectindex || "数二" != e.BusValue && "通用" != e.BusValue || u.push(e), 
                            2 != s.data.subjectindex || "数三" != e.BusValue && "通用" != e.BusValue || u.push(e);
                        }), u.reverse(), s.setData({
                            paperList: u
                        });
                    }
                    setTimeout(function() {
                        wx.hideLoading();
                    }, 1e3);

                  case 12:
                  case "end":
                    return t.stop();
                }
            }, t);
        }))();
    },
    getBookList: function() {
        var e = this;
        return s(a().mark(function t() {
            var s, n, o, r, u, c;
            return a().wrap(function(t) {
                for (;;) switch (t.prev = t.next) {
                  case 0:
                    if (s = e, !(n = i.default.IsStorageSyncExpire("indexAndstudyGetBookListOfVipByBook")) || !Array.isArray(n)) {
                        t.next = 6;
                        break;
                    }
                    n = n, t.next = 10;
                    break;

                  case 6:
                    return t.next = 8, l.GetBookListOfVip({
                        IsValid: 1,
                        System_Station_ID: d.globalData.SassID,
                        BusType: "书籍",
                        IsBook: 1,
                        IsBeta: 0,
                        IsRecommend: ""
                    });

                  case 8:
                    o = t.sent, Array.isArray(o.data) && o.data.length > 0 && Array.isArray(o.data[0]) ? (n = o.data[0], 
                    i.default.AddSotrageSyncExpire("indexAndstudyGetBookListOfVipByBook", n)) : n = [];

                  case 10:
                    n.length > 0 && (r = [], u = [], c = [], s.data.BookID && (c = s.data.BookID.toString().split(",")), 
                    c.map(function(t) {
                        n.map(function(a) {
                            a.HeadImg && (a.HeadImg = a.HeadImg.replace(/.png_yjs/g, ".png")), a.isSelect = !1, 
                            a.ID == t && (a.isSelect = !0, a.isDelect = !1, 721 != a.ID && 813 != a.ID && 1121 != a.ID && 1163 != a.ID && 2170 != a.ID && 2172 != a.ID && 2173 != a.ID ? r.push(a) : (!e.data.IswuVipLook || 721 != a.ID && 813 != a.ID && 1121 != a.ID && 1163 != a.ID) && (!e.data.isApplyMockExam || 2170 != a.ID && 2172 != a.ID && 2173 != a.ID) || r.push(a));
                        });
                    }), r.map(function(e, t) {
                        0 != s.data.subjectindex || "数一" != e.BusValue && "通用" != e.BusValue || u.push(e), 
                        1 != s.data.subjectindex || "数二" != e.BusValue && "通用" != e.BusValue || u.push(e), 
                        2 != s.data.subjectindex || "数三" != e.BusValue && "通用" != e.BusValue || u.push(e);
                    }), u.reverse(), s.setData({
                        bookList: u
                    })), e.getBookPaperList();

                  case 12:
                  case "end":
                    return t.stop();
                }
            }, t);
        }))();
    },
    showdelmodel: function(e) {
        var a = e.currentTarget.dataset.type, s = e.currentTarget.dataset.item, n = e.currentTarget.dataset.index;
        0 == a ? this.setData(t(t(t(t(t({}, "delmodel.content", "是否确认从书架移除" + s.Name), "isShowdel", !0), "bookList[" + n + "].isDelect", !this.data.bookList[n].isDelect), "delectCount", 1), "isDelType", a)) : 1 == a && this.setData(t(t(t(t(t({}, "delmodel.content", "是否确认从书架移除" + s.Name), "isShowdel", !0), "paperList[" + n + "].isDelect", !this.data.paperList[n].isDelect), "delectCount", 1), "isDelType", a));
    },
    hidedelmodel: function(e) {
        if (1 == e.detail.id) this.delectBook(); else if (2 == e.detail.id) if (0 == this.data.isDelType) {
            var a = this.data.bookList;
            a.map(function(e) {
                e.isDelect = !1;
            }), this.setData(t(t({
                isShowdel: !1,
                delectCount: 0
            }, "isShowdel", !1), "bookList", a));
        } else if (1 == this.data.isDelType) {
            var s = this.data.paperList;
            s.map(function(e) {
                e.isDelect = !1;
            }), this.setData(t(t({
                isShowdel: !1,
                delectCount: 0
            }, "isShowdel", !1), "paperList", s));
        }
    },
    delectBook: function() {
        var e = this;
        if (0 == this.data.delectCount) wx.showToast({
            title: "请选择要删除的书籍",
            icon: "none"
        }); else if (0 == this.data.isDelType) {
            var t, a = [], s = [], n = this.data.BookID ? this.data.BookID.toString().split(",") : [];
            this.data.bookList.map(function(e) {
                e.isDelect && e.ID ? s.push(e.ID.toString()) : a.push(e);
            });
            var i = this.getNewArr(s, n);
            t = i ? i.toString() : "", this.data.SysUserInfo.ID && this.data.SysUserInfo.EBookIDs != t ? p.updataUserBookIDs({
                ID: this.data.SysUserInfo.ID,
                EBookIDs: t
            }).then(function(s) {
                e.data.SysUserInfo.EBookIDs = t, d.globalData.SysUserInfo = e.data.SysUserInfo, 
                d.updataGlobalData("SysUserInfo", e.data.SysUserInfo), d.globalData.eBookID = t, 
                d.updataGlobalData("eBookID", t), wx.setStorage({
                    key: "eBookID",
                    data: t
                }), e.setData({
                    BookID: t,
                    bookList: a,
                    delectCount: 0,
                    isShowDelect: !1,
                    isShowdel: !1
                });
            }) : (d.globalData.eBookID = t, d.updataGlobalData("eBookID", t), wx.setStorage({
                key: "eBookID",
                data: t
            }), this.setData({
                BookID: t,
                bookList: a,
                delectCount: 0,
                isShowDelect: !1,
                isShowdel: !1
            }));
        } else if (1 == this.data.isDelType) {
            var o, r = [], u = [], c = this.data.PaperIDs ? this.data.PaperIDs.toString().split(",") : [];
            this.data.paperList.map(function(e) {
                e.isDelect ? u.push(e.ID.toString()) : r.push(e);
            });
            var l = this.getNewArr(u, c);
            o = l ? l.toString() : "", this.data.SysUserInfo.ID && this.data.SysUserInfo.PaperIDs != o ? p.updataUserPaperIDs({
                ID: this.data.SysUserInfo.ID,
                PaperIDs: o
            }).then(function(t) {
                e.data.SysUserInfo.PaperIDs = o, d.globalData.SysUserInfo = e.data.SysUserInfo, 
                d.updataGlobalData("SysUserInfo", e.data.SysUserInfo), d.globalData.PaperIDs = o, 
                d.updataGlobalData("PaperIDs", o), wx.setStorage({
                    key: "PaperIDs",
                    data: o
                }), e.setData({
                    PaperIDs: o,
                    paperList: r,
                    delectCount: 0,
                    isShowDelect: !1,
                    isShowdel: !1
                });
            }) : (d.globalData.PaperIDs = o, d.updataGlobalData("PaperIDs", o), wx.setStorage({
                key: "PaperIDs",
                data: o
            }), this.setData({
                PaperIDs: o,
                paperList: r,
                delectCount: 0,
                isShowDelect: !1,
                isShowdel: !1
            }));
        }
    },
    getNewArr: function(e, t) {
        return e.concat(t).filter(function(e, t, a) {
            return a.indexOf(e) === a.lastIndexOf(e);
        });
    },
    gotoQuestion: function(e) {
        var t = this, a = e.currentTarget.dataset.index, s = e.currentTarget.dataset.type, n = {};
        n = 0 == s ? this.data.bookList[a] : this.data.paperList[a], this.checkUserLogin() && (1 != n.IsVipLook || 721 != n.ID && 813 != n.ID && 1121 != n.ID && 1163 != n.ID ? this.data.isStudy || (this.data.isStudy = !0, 
        p.GetUserViewRecordByBook({
            StuID: this.data.StuID,
            BusType: i.default.recordType.view,
            BookID: n.ID
        }).then(function(e) {
            if (1 == n.IsBtn && wx.setStorageSync("capacityBook" + n.ID, !0), Array.isArray(e.data) && e.data.length > 0 && Array.isArray(e.data[0]) && e.data[0].length > 0) {
                var a = e.data[0][0];
                t.data.isStudy = !1, wx.navigateTo({
                    url: "/topic/pages/topic?bookID=" + n.ID + "&bookName=" + n.Name + "&topicPage=" + a.questionPage + "&topicNum=" + a.questionID + "&courseID=" + a.qID + "&source=1"
                });
            } else l.GetQuestionFirstByBookID({
                BookID: n.ID
            }).then(function(e) {
                if (Array.isArray(e.data) && e.data.length > 0 && Array.isArray(e.data[0]) && e.data[0].length > 0) {
                    var a = e.data[0][0];
                    t.data.isStudy = !1, wx.navigateTo({
                        url: "/topic/pages/topic?bookID=" + n.ID + "&bookName=" + a.Name + "&topicPage=" + a.QuestionPage + "&topicNum=" + a.QuestionSort + "&courseID=" + a.QuestionID + "&source=1"
                    });
                }
            });
        })) : this.data.IswuVipLook ? this.data.isStudy || (this.data.isStudy = !0, p.GetUserViewRecordByBook({
            StuID: this.data.StuID,
            BusType: i.default.recordType.view,
            BookID: n.ID
        }).then(function(e) {
            if (1 == n.IsBtn && wx.setStorageSync("capacityBook" + n.ID, !0), Array.isArray(e.data) && e.data.length > 0 && Array.isArray(e.data[0]) && e.data[0].length > 0) {
                var a = e.data[0][0];
                t.data.isStudy = !1, wx.navigateTo({
                    url: "/topic/pages/topic?bookID=" + n.ID + "&bookName=" + n.Name + "&topicPage=" + a.questionPage + "&topicNum=" + a.questionID + "&courseID=" + a.qID + "&source=1"
                });
            } else l.GetQuestionFirstByBookID({
                BookID: n.ID
            }).then(function(e) {
                if (Array.isArray(e.data) && e.data.length > 0 && Array.isArray(e.data[0]) && e.data[0].length > 0) {
                    var a = e.data[0][0];
                    t.data.isStudy = !1, wx.navigateTo({
                        url: "/topic/pages/topic?bookID=" + n.ID + "&bookName=" + a.Name + "&topicPage=" + a.QuestionPage + "&topicNum=" + a.QuestionSort + "&courseID=" + a.QuestionID + "&source=1"
                    });
                }
            });
        })) : wx.navigateTo({
            url: "/topic/pages/VipLook/VipLook?VipLookText=" + n.VipLookText + "&bookname=" + n.Name + "&bookid=" + n.ID
        }));
    },
    gotoMorebook: function(e) {
        var t = e.currentTarget.dataset.type;
        wx.setStorageSync("indexpagebooktabIndex", t), this.checkUserLogin() && wx.switchTab({
            url: "/pages/index/index"
        });
    },
    getCurDate: function() {
        var e = new Date(), t = e.getFullYear(), a = e.getMonth() + 1;
        return a < 10 && (a = "0" + a), t + "-" + a + "-" + e.getDate();
    },
    checkStuCouponLoginThirdDay: function() {
        var e = this;
        return s(a().mark(function t() {
            var s, n, o, r;
            return a().wrap(function(t) {
                for (;;) switch (t.prev = t.next) {
                  case 0:
                    if ((s = e).data.isIOS) {
                        t.next = 15;
                        break;
                    }
                    if (!(n = i.default.IsStorageSyncExpire("CheckStuCouponLoginThirdDay")) || !Array.isArray(n)) {
                        t.next = 7;
                        break;
                    }
                    n = n, t.next = 12;
                    break;

                  case 7:
                    return o = {
                        System_Station_ID: d.globalData.SassID,
                        StuID: d.globalData.StuID,
                        CouponID: 264
                    }, t.next = 10, p.CheckStuCouponLoginThirdDay(o);

                  case 10:
                    r = t.sent, Array.isArray(r.data) && r.data.length > 0 && Array.isArray(r.data[0]) ? (n = r.data[0], 
                    i.default.AddSotrageSyncExpire("studyCheckStuCouponLoginThirdDaydata", n)) : n = [];

                  case 12:
                    if (n.length > 0 && n[0].Today == s.getCurDate()) try {
                        wx.getStorageSync("couponThirdDayClick") ? s.setData({
                            couponShow: !1
                        }) : s.setData({
                            couponShow: !0
                        });
                    } catch (e) {}
                    t.next = 16;
                    break;

                  case 15:
                    console.log("苹果用户");

                  case 16:
                  case "end":
                    return t.stop();
                }
            }, t);
        }))();
    },
    addUserCouponRecord: function(e) {
        if (e > 0) {
            var t = [ {
                UserID: this.data.userInfo.userCode,
                CouponID: e,
                System_Station_ID: d.globalData.SassID,
                AddPerosns: "Sys"
            } ];
            p.AddUserCouponVipByTel(t).then(function(e) {
                wx.removeStorageSync("studygetcouponcardListdata");
            });
        }
    },
    checkStuLoginThirdDay: function() {
        this.data.SysUserInfo && !this.data.isIOS && (3 == this.data.SysUserInfo.LoginCountDay && this.addUserCouponRecord(264));
    },
    couponclear: function() {
        try {
            wx.setStorageSync("couponcard" + this.data.couponcardList[0].ID, !0), wx.setStorageSync("couponThirdDayClick", !0);
        } catch (e) {}
        this.setData({
            couponShow: !1
        });
    },
    gotoCoupons: function() {
        if (this.checkUserLogin()) {
            try {
                wx.setStorageSync("couponcard" + this.data.couponcardList[0].ID, !0), wx.setStorageSync("couponThirdDayClick", !0);
            } catch (e) {}
            d.addHeadImgListLog2("优惠券弹窗", "", this.data.couponcardList[0].ID), wx.navigateTo({
                url: "/wenjuan/pages/CouponsList/CouponsList"
            }), this.setData({
                couponShow: !1
            });
        }
    },
    getcouponcardList: function() {
        var e = this;
        return s(a().mark(function t() {
            var s, n, o, r, u, c, l, p, I, D, y, h;
            return a().wrap(function(t) {
                for (;;) switch (t.prev = t.next) {
                  case 0:
                    if (!(s = i.default.IsStorageSyncExpire("studygetcouponcardListdata")) || !Array.isArray(s)) {
                        t.next = 5;
                        break;
                    }
                    s = s, t.next = 10;
                    break;

                  case 5:
                    return n = {
                        StuID: e.data.StuID,
                        System_Station_ID: d.globalData.SassID,
                        IsConvert: 1,
                        page: 0,
                        limit: 1e3
                    }, t.next = 8, g.GetCouponsInfo(n);

                  case 8:
                    o = t.sent, Array.isArray(o.data) ? (s = o.data, i.default.AddSotrageSyncExpire("studygetcouponcardListdata", s)) : s = [];

                  case 10:
                    if (u = [], c = (r = e).data.isIOS, l = r.data.SysUserInfo.AddTime, p = r.data.isIOSCouponUser, 
                    I = [ 264, 265, 266, 267 ], D = [ 265, 266, 267 ], s.length > 0) {
                        if (y = 0, h = !1, s.map(function(e) {
                            0 == e.IsUse && new Date() < new Date(e.EndTime) && (y += 1, e.EndTime = i.default.dateFormat("YYYY-MM-DD", e.EndTime), 
                            u.push(e), I.includes(e.CouponID) && c && (p = !0)), !c && l >= r.data.regCouponTime && 264 != e.CouponID && 265 != e.CouponID && 266 != e.CouponID && r.checkStuLoginThirdDay();
                        }), (u = u.sort(function(e, t) {
                            return t.ConvertTime.localeCompare(e.ConvertTime) || t.ConvertTime.localeCompare(e.ConvertTime);
                        })).length > 0) {
                            h = !(D.includes(u[0].CouponID) && !c);
                            try {
                                wx.getStorageSync("couponcard" + u[0].ID) && (h = !1);
                            } catch (e) {}
                        }
                        e.data.couponcardList.length > 0 && e.data.couponcardList[0].ID == u.ID && (h = !1), 
                        e.setData({
                            couponcardNum: y,
                            couponShow: h,
                            couponcardList: u,
                            isIOSCouponUser: p
                        });
                    } else !c && l >= r.data.regCouponTime && r.checkStuLoginThirdDay();

                  case 18:
                  case "end":
                    return t.stop();
                }
            }, t);
        }))();
    },
    checkUserLogin: function() {
        if ("" != this.data.StuID && this.data.isLogin) return !0;
        this.setData({
            StuIDIsLogin: !0
        });
    },
    gotoLogin: function(e) {
        0 == e.currentTarget.dataset.index ? this.setData({
            StuIDIsLogin: !1
        }) : wx.navigateTo({
            url: "../login?backPath=user"
        });
    },
    onReady: function() {},
    authUserInfo: function() {
        var e = this;
        "" != e.data.OpenID ? wx.getUserProfile({
            lang: "zh_CN",
            desc: "用户登录",
            success: function(t) {
                if (t.rawData) {
                    var a = JSON.parse(t.rawData.toString());
                    p.UpdateWXUser({
                        OpenID: e.data.OpenID,
                        NickName: a.nickName,
                        HeadImgurl: a.avatarUrl,
                        Sex: a.gender,
                        Country: a.country,
                        Province: a.province,
                        City: a.city,
                        UpdateColumns: a.nickName ? "NickName,HeadImgurl,Sex,Country,Province,City" : "Sex,Country,Province,City"
                    }).then(function(t) {
                        wx.showToast({
                            icon: "success",
                            title: "更新成功",
                            success: function() {
                                e.setData({
                                    isOpenAuthDialog: !1
                                });
                            }
                        });
                    }), wx.setStorage({
                        data: a,
                        key: "userInfo"
                    });
                }
            },
            fail: function() {
                wx.showModal({
                    title: "您已拒绝小程序获取信息"
                }), e.setData({
                    isOpenAuthDialog: !0
                });
            }
        }) : console.log("小程序标识为空...");
    },
    checkUserIsReadUnInfo: function() {
        var e = this, a = d.globalData.UsersInfo ? d.globalData.UsersInfo : [];
        0 != a.length && a[0].UserName || wx.getStorage({
            key: "isReadUnInfo",
            success: function(s) {
                e.setData({
                    isReadUnInfo: s.data
                }), s.data && a[0].UserName || wx.showModal(t(t(t(t(t({
                    title: "提示"
                }, "title", "你的信息还未完善，马上去完善"), "cancelText", "稍后完善"), "cancelColor", "#ccc"), "confirmText", "马上完善"), "complete", function(t) {
                    t.confirm ? wx.navigateTo({
                        url: "/wenjuan/pages/UserInfo/UserInfo"
                    }) : t.cancel && (wx.setStorage({
                        data: !0,
                        key: "isReadUnInfo"
                    }), e.setData({
                        isReadUnInfo: !0
                    }));
                }));
            },
            fail: function(a) {
                wx.showModal(t(t(t(t(t({
                    title: "提示"
                }, "title", "你的信息还未完善，马上去完善"), "cancelText", "稍后完善"), "cancelColor", "#ccc"), "confirmText", "马上完善"), "complete", function(t) {
                    t.confirm ? wx.navigateTo({
                        url: "/wenjuan/pages/UserInfo/UserInfo"
                    }) : t.cancel && (wx.setStorage({
                        data: !0,
                        key: "isReadUnInfo"
                    }), e.setData({
                        isReadUnInfo: !0
                    }));
                }));
            }
        });
    },
    onShow: function() {
        var e = this;
        try {
            wx.hideTabBar({
                animation: !0
            });
        } catch (e) {}
        wx.getStorage({
            key: "isLogin",
            success: function(e) {
                t.setData({
                    isLogin: e.data
                });
            }
        }), this.setData({
            isIOS: d.globalData.isIOS
        });
        var t = this, a = 365, s = new Date().getFullYear(), n = i.default.dateFormat("YYYY-MM-DD", new Date()), o = s + "-12-21", r = i.default.getDiffDay(o, n);
        r >= 0 ? a = r : (o = s + 1 + "-12-21", a = i.default.getDiffDay(o, n)), wx.getStorage({
            key: "isLogin",
            success: function(e) {
                t.setData({
                    isLogin: e.data,
                    StuIDIsLogin: !1
                });
            }
        });
        var u = !1, c = !1, l = !1, g = 0, p = -1, I = !1, D = wx.getStorageSync(n + "Live");
        if ((I = !D) && d.globalData.appInfo && 1 == d.globalData.appInfo.IsChannelsLive ? (I = !0, 
        t.getvideoLiveinfo()) : I = !1, d.globalData.StuID) {
            var y = 0;
            p = d.globalData.subjectindex, 1 != d.globalData.SysUserInfo.IsOldUser ? wx.navigateTo({
                url: "/pages/guide/guide"
            }) : -1 !== p && "" !== p && null !== p || wx.navigateTo({
                url: "/pages/loginsubject/loginsubject"
            });
            try {
                y = wx.getStorageSync("indexpagebooktabIndex");
            } catch (e) {}
            var h;
            h = parseInt((new Date(d.globalData.VIPValidTime).getTime() - new Date().getTime()) / 864e5);
            var f = !1;
            2 == d.globalData.vipLevel && (f = !0, u = !0, c = !0, l = !0), d.globalData.SysUserInfo.SubjectType && ("数一" == d.globalData.SysUserInfo.SubjectType ? g = 1 : "数二" == d.globalData.SysUserInfo.SubjectType ? g = 2 : "数三" == d.globalData.SysUserInfo.SubjectType && (g = 3)), 
            t.setData({
                isLogin: !0,
                StuID: d.globalData.StuID,
                OpenID: d.globalData.userInfo.OpenID,
                userCode: d.globalData.userInfo.userCode,
                curVipType: d.globalData.vipLevel,
                vipLevel: d.globalData.vipLevel >= 2 ? "VIP会员" : "普通用户",
                vipEndTime: i.default.dateFormat("YYYY-MM-DD", d.globalData.VIPValidTime),
                BookID: d.globalData.SysUserInfo.EBookIDs ? d.globalData.SysUserInfo.EBookIDs : d.globalData.eBookID,
                vipEndDay: h,
                userInfo: d.globalData.userInfo,
                yearEndTime: a,
                isVip: f,
                subjectindex: p,
                booktabIndex: y,
                SysUserInfo: d.globalData.SysUserInfo,
                choice1: u,
                choice2: c,
                choice3: l,
                choiceType: g,
                isMajorComputing: d.globalData.isMajorComputing,
                isLookMajorComputing: d.globalData.isLookMajorComputing,
                IswuVipLook: d.globalData.IswuVipLook,
                isShowChannelsLive: I
            }), t.getcouponcardList(), this.getIndexAd(), this.getBannerList(), t.GetCourse(), 
            t.GetNoReadContentList(), t.getUserIntegral(), t.GetcomputingInfoList(), y < 2 && this.GetFunctionAllocationList();
        } else d.checkLoginReadyCallback = function(s) {
            if ("登陆成功" == s.data.msg) {
                var n = !1, o = 1, r = "", D = s.data.data.SysUserInfo;
                D.VipEndTime && (o = d.isVipFunction(D.VipEndTime) ? 2 : 1), 2 == o && (r = D.VipEndTime, 
                n = !0, u = !0, c = !0, l = !0);
                var y;
                y = parseInt((new Date(D.VipEndTime).getTime() - new Date().getTime()) / 864e5);
                var h = 0;
                try {
                    h = wx.getStorageSync("indexpagebooktabIndex");
                } catch (e) {}
                s.data.data.SysUserInfo.SubjectType && ("数一" == s.data.data.SysUserInfo.SubjectType ? (p = 0, 
                g = 1) : "数二" == s.data.data.SysUserInfo.SubjectType ? (g = 2, p = 1) : "数三" == s.data.data.SysUserInfo.SubjectType && (g = 3, 
                p = 2)), 1 != s.data.data.SysUserInfo.IsOldUser ? wx.navigateTo({
                    url: "/pages/guide/guide"
                }) : -1 !== p && "" !== p && null !== p || wx.navigateTo({
                    url: "/pages/loginsubject/loginsubject"
                });
                var f = !1;
                if (d.globalData.appInfo.ParmText1) {
                    if (d.globalData.appInfo.ParmText1.indexOf("VIP用户") > -1 && 2 == o) f = !0; else if (s.data.data.CourseUsers.length > 0) {
                        var S = d.globalData.appInfo.ParmText1 ? d.globalData.appInfo.ParmText1.split(",") : [];
                        s.data.data.CourseUsers.map(function(e) {
                            S.map(function(t) {
                                e.CourseProductID == t && (f = !0);
                            });
                        });
                    }
                } else f = !0;
                var b = !1;
                s.data.data.CourseUsers.length > 0 && s.data.data.CourseUsers.map(function(e) {
                    1095 != e.CourseProductID && 1096 != e.CourseProductID && 1097 != e.CourseProductID || (b = !0);
                }), t.setData({
                    isMajorComputing: f,
                    isLookMajorComputing: b,
                    isLogin: !0,
                    StuID: s.data.data.SysUserInfo.StuID,
                    OpenID: s.data.data.WxUserInfo.OpenID,
                    userCode: s.data.data.SysUserInfo.ID,
                    curVipType: o,
                    vipLevel: 2 == o ? "VIP会员" : "普通用户",
                    vipEndTime: i.default.dateFormat("YYYY-MM-DD", r),
                    vipEndDay: y,
                    BookID: s.data.data.SysUserInfo.EBookIDs ? s.data.data.SysUserInfo.EBookIDs : d.globalData.eBookID,
                    userInfo: {
                        SysUserInfo: s.data.data.SysUserInfo,
                        nickName: s.data.data.WxUserInfo.Nickname,
                        avatarUrl: s.data.data.WxUserInfo.HeadImgurl,
                        subscribe: s.data.data.WxUserInfo.Subscribe,
                        OpenID: s.data.data.WxUserInfo.OpenID
                    },
                    yearEndTime: a,
                    isVip: n,
                    subjectindex: p,
                    booktabIndex: h,
                    SysUserInfo: s.data.data.SysUserInfo,
                    choice1: u,
                    choice2: c,
                    choice3: l,
                    choiceType: g,
                    IswuVipLook: d.globalData.IswuVipLook,
                    isShowChannelsLive: I
                }), t.getcouponcardList(), e.getIndexAd(), e.getBannerList(), t.GetCourse(), t.GetNoReadContentList(), 
                t.getUserIntegral(), t.GetcomputingInfoList(), h < 2 && e.GetFunctionAllocationList();
            }
        };
        t.checkStuCouponLoginThirdDay();
    },
    onLoad: function(e) {
        var t = d.globalData.StuID;
        this.setData({
            userInfo: d.globalData.userInfo,
            StuID: t
        }), getApp().registerListener(this.onCurrentUserChange.bind(this));
    },
    onCurrentUserChange: function() {
        if (getApp().globalData.vipLevel && getApp().globalData.VIPValidTime) {
            var e, t = getApp().globalData.vipLevel;
            e = parseInt((new Date(getApp().globalData.VIPValidTime).getTime() - new Date().getTime()) / 864e5), 
            this.setData({
                curVipType: t,
                vipLevel: 2 == t ? "VIP会员" : "普通用户",
                vipEndTime: i.default.dateFormat("YYYY-MM-DD", getApp().globalData.VIPValidTime),
                vipEndDay: e
            });
        }
    },
    onHide: function() {
        clearInterval(this.data.interval1), clearInterval(this.data.interval2);
    },
    onUnload: function() {},
    onPullDownRefresh: function() {},
    onReachBottom: function() {},
    onShareAppMessage: function() {
        var e = "";
        return d.globalData.userInfo && d.globalData.userInfo.nickName && (e = d.globalData.userInfo.nickName), 
        i.default.wxShare({
            title: "你的好友" + e + "向你推荐：百万考研学子都在用的考研数学小程序！",
            url: "/pages/study/study",
            params: {
                fissionID: this.data.StuID
            },
            isMerge: !1
        });
    }
});