var t, a = require("../../@babel/runtime/helpers/defineProperty"), e = require("../../api/product"), s = require("../../api/user"), o = require("../../api/course"), i = require("../../utils/util.js"), n = getApp(), r = n.window, u = new e.Product(), d = new s.User(), l = new o.Course();

Page({
    data: (t = {
        window: r,
        navigator: {
            border: !1,
            color: "#333",
            bg: "#ffffff",
            back: !1,
            leftText: "",
            title: "引导页面",
            othergoback: !0,
            othergoHome: !0
        },
        isLogin: !1,
        StuID: "",
        sysScroll: !0,
        objList: [ {
            isShow: !0,
            problem: "你学习的科目类别是？",
            type: 1,
            answerList: [ "数一", "数二", "数三" ],
            userinput: ""
        }, {
            isShow: !1,
            problem: "你现在的备考年份是？",
            type: 1,
            answerList: [ "2024", "2025", "其他" ],
            userinput: ""
        } ],
        inputtext: "",
        IsShowInput: !1,
        IsShowBook: !1,
        IsShowBookList: !1,
        userCode: 0,
        UserInfo: {
            ID: 0
        }
    }, a(a(a(a(a(a(a(a(a(a(t, "StuID", ""), "teacherNameList", []), "rBookList", []), "SysUserInfo", {}), "BookList", []), "pageName", ""), "booklistType", 0), "albumList", []), "scrollTo", ""), "endId", "view_id_"), 
    a(a(a(a(a(a(a(a(t, "Isshowlogin", !0), "iswxuser", !1), "OpenID", ""), "headImg", ""), "nickName", ""), "userInfo", {}), "isService", !1), "guideServiceimg", "")),
    onChooseAvatar: function(t) {
        var a = t.detail.avatarUrl;
        this.uploadImgs(a);
    },
    nicknameInput: function(t) {
        this.setData({
            nickName: t.detail.value
        });
    },
    chenganickname: function(t) {
        var a = t.detail.value;
        this.setData({
            nickName: a
        });
    },
    wxok: function() {
        var t = this;
        d.UpdateWXUser({
            OpenID: this.data.OpenID,
            NickName: this.data.nickName,
            HeadImgurl: this.data.headImg,
            UpdateColumns: "NickName,HeadImgurl"
        }).then(function(a) {
            t.setData({
                Isshowlogin: !1,
                IsShowInput: !0,
                iswxuser: !1
            }), n.globalData.userInfo.avatarUrl = t.data.headImg, n.globalData.userInfo.nickName = t.data.nickName, 
            t.data.userInfo.nickName = t.data.nickName, t.data.userInfo.avatarUrl = t.data.headImg, 
            n.updataGlobalData("userInfo", t.data.userInfo), console.log(t.data.userInfo, "this.data.userInfo"), 
            wx.showToast({
                icon: "success",
                title: "授权成功"
            });
        });
    },
    uploadImgs: function(t) {
        var a = this;
        wx.uploadFile({
            filePath: t,
            name: "file",
            url: n.globalData.configs.TOP_HOST + "/api/sys_attachment/LayuiUpImg",
            header: {
                "Content-Type": "application/x-www-form-urlencoded"
            },
            success: function(t) {
                var e = t.data;
                e = JSON.parse(e).data, a.setData({
                    headImg: e.src
                });
            }
        });
    },
    skippagewxuser: function() {
        n.addHeadImgListLog2("引导页", "头像昵称"), this.setData({
            Isshowlogin: !1,
            IsShowInput: !0
        });
    },
    gotowxuser: function(t) {
        var a = t.currentTarget.dataset.index;
        0 == a ? this.setData({
            iswxuser: !0
        }) : 1 == a && this.setData({
            iswxuser: !1
        });
    },
    closeService: function() {
        this.setData({
            isService: !1,
            IsShowBook: !0
        });
    },
    setSource: function() {
        if (this.checkUserLogin()) if (this.data.UserInfo && this.data.UserInfo.ID > 0) {
            var t = {
                StuID: this.data.StuID,
                Source: this.data.objList[2].userinput,
                UpdateColumns: "Source"
            };
            d.updateUserInfoByStuID(t).then();
        } else d.updateUserInfoByStuID({
            StuID: this.data.StuID,
            Source: this.data.objList[2].userinput
        }).then(function(t) {
            t.data;
        });
    },
    setScore2: function() {
        if (this.checkUserLogin()) if (this.data.UserInfo && this.data.UserInfo.ID > 0) {
            var t = {
                StuID: this.data.StuID,
                Score2: this.data.objList[1].userinput,
                UpdateColumns: "Score2"
            };
            d.updateUserInfoByStuID(t).then(function(t) {
                t.msg;
            });
        } else d.updateUserInfoByStuID({
            StuID: this.data.StuID,
            Score2: this.data.objList[1].userinput
        }).then(function(t) {
            t.data;
        });
    },
    setSubjectType: function() {
        var t = this;
        if (this.data.userCode > 0) {
            var a = {
                ID: this.data.userCode,
                SubjectType: this.data.objList[0].userinput
            }, e = -1;
            "数一" == this.data.objList[0].userinput ? e = 0 : "数二" == this.data.objList[0].userinput ? e = 1 : "数三" == this.data.objList[0].userinput && (e = 2), 
            d.updataSubjectType(a).then(function(a) {
                n.globalData.SysUserInfo.SubjectType = t.data.objList[0].userinput, t.data.SysUserInfo.SubjectType = t.data.objList[0].userinput, 
                n.updataGlobalData("SysUserInfo", t.data.SysUserInfo), n.globalData.subjectindex = e, 
                n.updataGlobalData("subjectindex", e), console.log(n.globalData.subjectindex, "subjectindex22"), 
                console.log(n.globalData.SysUserInfo, "subjectindex");
            });
        }
    },
    selectuserinput: function(t) {
        var e = t.currentTarget.dataset.index, s = t.currentTarget.dataset.indexs, o = "";
        o = 1 == this.data.objList[e].type ? this.data.objList[e].answerList[s] : this.data.objList[e].answerList[s].title, 
        e < this.data.objList.length - 1 ? (this.setData(a(a({}, "objList[" + e + "].userinput", o), "objList[" + (e + 1) + "].isShow", !0)), 
        this.autoScroll(), wx.setStorage({
            key: "newUserObjList",
            data: JSON.stringify(this.data.objList)
        })) : (this.setData(a(a(a({}, "objList[" + e + "].userinput", o), "IsShowInput", !1), "IsShowBook", !0)), 
        this.autoScroll(), wx.setStorage({
            key: "newUserObjList",
            data: JSON.stringify(this.data.objList)
        }), this.getBookisRecommend(), this.getteacherNameList()), 0 == e ? this.setSubjectType() : 1 == e ? this.setScore2() : 2 == e && this.setSource();
    },
    inputtext: function(t) {
        this.setData({
            inputtext: t.detail.value
        });
    },
    inputbtn: function(t) {
        var e = t.currentTarget.dataset.index;
        e < this.data.objList.length - 1 ? (this.setData(a(a({}, "objList[" + e + "].userinput", this.data.inputtext), "objList[" + (e + 1) + "].isShow", !0)), 
        this.autoScroll(), wx.setStorage({
            key: "newUserObjList",
            data: JSON.stringify(this.data.objList)
        })) : ("2025" == userinput ? this.setData(a(a(a({}, "objList[" + e + "].userinput", userinput), "IsShowInput", !1), "isService", !0)) : this.setData(a(a(a({}, "objList[" + e + "].userinput", this.data.inputtext), "IsShowInput", !1), "IsShowBook", !0)), 
        this.autoScroll(), wx.setStorage({
            key: "newUserObjList",
            data: JSON.stringify(this.data.objList)
        }), this.getBookisRecommend(), this.getteacherNameList()), 0 == e ? this.setSubjectType() : 1 == e ? this.setScore2() : 2 == e && this.setSource();
    },
    onfocus: function() {
        this.setData({
            sysScroll: !1
        });
    },
    onblur: function(t, a, e) {
        this.setData({
            sysScroll: !0
        });
    },
    getteacherNameList: function() {
        var t = this;
        u.GetBookTeacher_v2({
            System_Station_ID: n.globalData.SassID,
            BusValue: this.data.objList[0].userinput
        }).then(function(a) {
            if (Array.isArray(a.data) && a.data.length > 0 && Array.isArray(a.data[0]) && a.data[0].length > 0) {
                var e = a.data[0];
                e.map(function(t) {
                    if (t.TeacherName) {
                        var a = t.TeacherName.split("");
                        2 == a.length ? t.TeacherName = a[0] + "*" : 3 == a.length ? t.TeacherName = a[0] + "*" + a[2] : (t.TeacherName = "", 
                        a.map(function(a, e) {
                            t.TeacherName = 1 == e ? t.TeacherName + "*" : t.TeacherName + a;
                        }));
                    }
                }), t.setData({
                    teacherNameList: e
                });
            }
        });
    },
    getBookisRecommend: function() {
        var t = this;
        u.GetBookisRecommend_v2({
            System_Station_ID: n.globalData.SassID,
            BusValue: this.data.objList[0].userinput
        }).then(function(a) {
            if (Array.isArray(a.data) && a.data.length > 0 && Array.isArray(a.data[0]) && a.data[0].length > 0) {
                var e = a.data[0];
                t.setData({
                    rBookList: e
                });
            }
        });
    },
    selectBook: function(t) {
        var a = this;
        if (1 == t.currentTarget.dataset.type || 1 == this.data.booklistType) {
            var e = t.currentTarget.dataset.item, s = this.data.SysUserInfo.EBookIDs ? this.data.SysUserInfo.EBookIDs : n.globalData.eBookID;
            s = s ? s + "," + e.ID : e.ID, d.updataUserBookIDs({
                ID: this.data.userCode,
                EBookIDs: s
            }).then(function(t) {
                a.data.SysUserInfo.EBookIDs = s, n.globalData.SysUserInfo = a.data.SysUserInfo, 
                n.updataGlobalData("SysUserInfo", a.data.SysUserInfo), n.globalData.eBookID = s, 
                n.updataGlobalData("eBookID", s), wx.setStorage({
                    key: "eBookID",
                    data: s
                }), d.updataIsOldUser({
                    ID: a.data.userCode,
                    IsOldUser: 1
                }).then(function(t) {
                    l.GetQuestionFirstByBookID({
                        BookID: e.ID
                    }).then(function(t) {
                        if (Array.isArray(t.data) && t.data.length > 0 && Array.isArray(t.data[0]) && t.data[0].length > 0) {
                            var s = t.data[0][0];
                            a.data.isStudy = !1, wx.setStorageSync("indexpagebooktabIndex", 0), n.globalData.SysUserInfo.IsOldUser = 1, 
                            a.data.SysUserInfo.IsOldUser = 1, n.updataGlobalData("SysUserInfo", a.data.SysUserInfo), 
                            wx.redirectTo({
                                url: "/topic/pages/topic?bookID=" + e.ID + "&bookName=" + s.Name + "&topicPage=" + s.QuestionPage + "&topicNum=" + s.QuestionSort + "&courseID=" + s.QuestionID + "&source=1"
                            });
                        }
                    });
                });
            });
        } else if (2 == this.data.booklistType) {
            var o = t.currentTarget.dataset.item, i = this.data.SysUserInfo.PaperIDs ? this.data.SysUserInfo.PaperIDs : n.globalData.PaperIDs;
            i || (i = "863"), i = i ? i + "," + o.ID : o.ID, d.updataUserPaperIDs({
                ID: this.data.SysUserInfo.ID,
                PaperIDs: i
            }).then(function(t) {
                a.data.SysUserInfo.PaperIDs = i, n.globalData.SysUserInfo = a.data.SysUserInfo, 
                n.updataGlobalData("SysUserInfo", a.data.SysUserInfo), n.globalData.PaperIDs = i, 
                n.updataGlobalData("PaperIDs", i), wx.setStorage({
                    key: "PaperIDs",
                    data: i
                }), d.updataIsOldUser({
                    ID: a.data.userCode,
                    IsOldUser: 1
                }).then(function(t) {
                    l.GetQuestionFirstByBookID({
                        BookID: o.ID
                    }).then(function(t) {
                        if (Array.isArray(t.data) && t.data.length > 0 && Array.isArray(t.data[0]) && t.data[0].length > 0) {
                            var e = t.data[0][0];
                            a.data.isStudy = !1, wx.setStorageSync("indexpagebooktabIndex", 1), n.globalData.SysUserInfo.IsOldUser = 1, 
                            a.data.SysUserInfo.IsOldUser = 1, n.updataGlobalData("SysUserInfo", a.data.SysUserInfo), 
                            wx.redirectTo({
                                url: "/topic/pages/topic?bookID=" + o.ID + "&bookName=" + e.Name + "&topicPage=" + e.QuestionPage + "&topicNum=" + e.QuestionSort + "&courseID=" + e.QuestionID + "&source=1"
                            });
                        }
                    });
                });
            });
        }
    },
    skippage: function() {
        var t = this;
        n.addHeadImgListLog2("引导页", "问答"), d.updataIsOldUser({
            ID: this.data.userCode,
            IsOldUser: 1
        }).then(function(a) {
            if (t.data.objList[0].userinput) n.globalData.SysUserInfo.IsOldUser = 1, t.data.SysUserInfo.IsOldUser = 1, 
            n.updataGlobalData("SysUserInfo", t.data.SysUserInfo), wx.switchTab({
                url: "/pages/study/study"
            }); else if (t.data.userCode > 0) {
                var e = {
                    ID: t.data.userCode,
                    SubjectType: "数一"
                };
                d.updataSubjectType(e).then(function(a) {
                    n.globalData.SysUserInfo.SubjectType = "数一", t.data.SysUserInfo.SubjectType = "数一", 
                    n.globalData.SysUserInfo.IsOldUser = 1, t.data.SysUserInfo.IsOldUser = 1, n.updataGlobalData("SysUserInfo", t.data.SysUserInfo), 
                    n.globalData.subjectindex = 0, n.updataGlobalData("subjectindex", 0), wx.switchTab({
                        url: "/pages/study/study"
                    });
                });
            }
        });
    },
    showBookList: function(t) {
        var a = t.currentTarget.dataset.type;
        if (1 == a) {
            var e = t.currentTarget.dataset.item;
            this.getTeacherBookList(e);
        } else 2 == a ? this.getBookListByNoTeacherName() : 3 == a ? this.getBookListByPaper() : 4 == a && this.getAlbumList();
    },
    getTeacherBookList: function(t) {
        var a = this;
        u.GetBookListByTeacher_v2({
            System_Station_ID: n.globalData.SassID,
            BusValue: this.data.objList[0].userinput,
            TeacherName: t
        }).then(function(e) {
            var s = [];
            Array.isArray(e.data) && e.data.length > 0 && Array.isArray(e.data[0]) && (s = e.data[0]), 
            a.setData({
                BookList: s,
                IsShowBook: !1,
                IsShowBookList: !0,
                pageName: t,
                booklistType: 1
            });
        });
    },
    getBookListByNoTeacherName: function() {
        var t = this;
        u.GetBookListByNoTeacherName_v2({
            System_Station_ID: n.globalData.SassID,
            BusValue: this.data.objList[0].userinput
        }).then(function(a) {
            var e = [];
            Array.isArray(a.data) && a.data.length > 0 && Array.isArray(a.data[0]) && (e = a.data[0]), 
            t.setData({
                BookList: e,
                IsShowBook: !1,
                IsShowBookList: !0,
                pageName: "每月练习册",
                booklistType: 1
            });
        });
    },
    getBookListByPaper: function() {
        var t = this;
        u.GetBookListByPaper_v2({
            System_Station_ID: n.globalData.SassID,
            BusValue: this.data.objList[0].userinput
        }).then(function(a) {
            var e = [];
            Array.isArray(a.data) && a.data.length > 0 && Array.isArray(a.data[0]) && (e = a.data[0]), 
            t.setData({
                BookList: e,
                IsShowBook: !1,
                IsShowBookList: !0,
                pageName: "36年真题",
                booklistType: 2
            });
        });
    },
    translateDataToTree: function(t) {
        return t.filter(function(a) {
            var e = t.filter(function(t) {
                return a.ID == t.PID;
            });
            return e.length > 0 && (a.children = e), 0 == a.PID;
        });
    },
    getAlbumList: function() {
        var t = this;
        u.GetAlbumList({
            System_Station_ID: n.globalData.SassID,
            IsValid: 1,
            BusType: "会员专辑",
            SortDesc: "Sort"
        }).then(function(a) {
            var e = [];
            if (Array.isArray(a.data) && a.data.length > 0) {
                var s = new Date().toLocaleDateString(), o = t.data.SysUserInfo.ID ? t.data.SysUserInfo.AlbumIDs : "";
                o = o ? o.split(",") : [], a.data.map(function(t) {
                    if (t.PID > 0) {
                        if (t.isOnline = !1, t.OnlineTime) {
                            var a = new Date(t.OnlineTime).toLocaleDateString();
                            new Date(a) - new Date(s) < 0 ? t.isOnline = !0 : t.OnlineTime = i.dateFormat("M.D", t.OnlineTime);
                        } else t.isOnline = !0;
                        if (1 == t.Authority) if (t.FreeEndTime) {
                            var e = new Date(t.FreeEndTime), o = new Date(), n = e.getTime() - o.getTime();
                            t.FreeEndTime = parseInt(n / 864e5);
                        } else t.FreeEndTime = "免费";
                    } else {
                        var r = t.Title.indexOf("阶段");
                        t.TitleBg = r > 2 ? t.Title.substring(r - 2, r) : t.Title.substring(0, r);
                    }
                });
                var n = t.translateDataToTree(a.data);
                n.map(function(t) {
                    t.onlinecount = 0, Array.isArray(t.children) && t.children.map(function(a) {
                        a.isOnline && (t.onlinecount = t.onlinecount + 1);
                    });
                }), e = n;
            }
            t.setData({
                albumList: e,
                IsShowBook: !1,
                IsShowBookList: !0,
                pageName: "高分专辑",
                booklistType: 3
            });
        });
    },
    gotoAlbum: function(t) {
        var a = this, e = t.currentTarget.dataset.item, s = t.currentTarget.dataset.index, o = (t.currentTarget.dataset.indexs, 
        this.data.SysUserInfo.AlbumIDs ? this.data.SysUserInfo.AlbumIDs : n.globalData.AlbumIDs);
        o = o ? o + "," + e.ID : e.ID, d.updataUserAlbumIDs({
            ID: this.data.SysUserInfo.ID,
            AlbumIDs: o
        }).then(function(t) {
            a.data.SysUserInfo.AlbumIDs = o, n.globalData.SysUserInfo = a.data.SysUserInfo, 
            n.updataGlobalData("SysUserInfo", a.data.SysUserInfo), n.globalData.AlbumIDs = o, 
            n.updataGlobalData("AlbumIDs", o), wx.setStorage({
                key: "AlbumIDs",
                data: o
            }), d.updataUserPaperIDs({
                ID: a.data.SysUserInfo.ID,
                PaperIDs: PaperIDs
            }).then(function(t) {
                wx.setStorageSync("indexpagebooktabIndex", 2), wx.redirectTo({
                    url: "/choice/pages/albumInfo/albumInfo?AlbumID=" + e.ID + "&selectindex=" + s + "&isAddStudy=1"
                });
            });
        });
    },
    ShowBack: function() {
        this.setData({
            booklistType: 0,
            IsShowBook: !0,
            IsShowBookList: !1
        });
    },
    autoScroll: function() {
        var t = "view_id_" + parseInt(1e6 * Math.random());
        this.setData({
            scrollTo: ""
        }), this.setData({
            endId: t
        }), this.setData({
            scrollTo: t
        });
    },
    checkUserLogin: function() {
        if ("" != this.data.StuID && this.data.isLogin) return !0;
        wx.navigateTo({
            url: "/pages/login"
        });
    },
    onLoad: function(t) {
        var a = this;
        wx.getStorage({
            key: "isLogin",
            success: function(t) {
                a.setData({
                    isLogin: t.data
                });
            }
        });
        this.data.objList;
        try {
            var e = wx.getStorageSync("newUserObjList");
            if (e) {
                e = JSON.parse(e);
                var s = !1;
                e.map(function(t) {
                    t.isShow || t.userinput || (s = !0);
                }), this.setData({
                    objList: e,
                    Isshowlogin: !0
                }), s || (this.getBookisRecommend(), this.getteacherNameList());
            }
        } catch (t) {}
        n.globalData.StuID ? (this.setData({
            StuID: n.globalData.StuID,
            userCode: n.globalData.userInfo.userCode,
            UserInfo: n.globalData.UsersInfo.length > 0 ? n.globalData.UsersInfo[0] : {
                ID: 0
            },
            userInfo: n.globalData.userInfo,
            SysUserInfo: n.globalData.SysUserInfo,
            OpenID: n.globalData.userInfo.OpenID,
            guideServiceimg: n.globalData.guideServiceimg ? n.globalData.guideServiceimg : n.globalData.SysUserInfo.SCRM_CodeImg ? n.globalData.SysUserInfo.SCRM_CodeImg.replace(/.png_yjs/g, ".png") : "",
            isLogin: !0
        }), console.log(n.globalData.guideServiceimg, "guideServiceimg")) : n.checkLoginReadyCallback = function(t) {
            if ("登陆成功" == t.data.msg) {
                var e = {
                    ID: 0
                };
                t.data.data.UserInfo.length > 0 && (e = t.data.data.UserInfo[0]), a.setData({
                    StuID: t.data.data.SysUserInfo.StuID,
                    userCode: t.data.data.SysUserInfo.ID,
                    UserInfo: e,
                    SysUserInfo: t.data.data.SysUserInfo,
                    OpenID: t.data.data.WxUserInfo.OpenID,
                    userInfo: {
                        SysUserInfo: t.data.data.SysUserInfo,
                        nickName: t.data.data.WxUserInfo.Nickname,
                        avatarUrl: t.data.data.WxUserInfo.HeadImgurl,
                        subscribe: t.data.data.WxUserInfo.Subscribe,
                        OpenID: t.data.data.WxUserInfo.OpenID
                    },
                    guideServiceimg: n.globalData.guideServiceimg ? n.globalData.guideServiceimg : t.data.data.SysUserInfo.SCRM_CodeImg ? t.data.data.SysUserInfo.SCRM_CodeImg.replace(/.png_yjs/g, ".png") : "",
                    isLogin: !0
                });
            } else console.log(111, "科目选择页面");
        };
    },
    onReady: function() {},
    onShow: function() {
        console.log(getCurrentPages());
    },
    onHide: function() {},
    onUnload: function() {},
    onPullDownRefresh: function() {},
    onReachBottom: function() {},
    onShareAppMessage: function() {
        return i.wxShare({});
    }
});