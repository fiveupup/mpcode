var t = require("../../api/course"), a = require("../../api/user"), e = require("../../utils/util.js"), s = getApp(), n = s.window, o = (new t.Course(), 
new a.User());

Page({
    data: {
        window: n,
        navigator: {
            border: !1,
            color: "#333",
            bg: "#ffffff",
            back: !1,
            leftText: "",
            title: "",
            othergoback: !0,
            othergoHome: !0
        },
        subjectindex: -1,
        SysUserInfo: {}
    },
    selectsub: function(t) {
        var a = t.currentTarget.dataset.index;
        this.setData({
            subjectindex: a
        }), s.updataGlobalData("subjectindex", a);
    },
    gostudy: function(t) {
        var a = this;
        if (this.data.StuID) if (a.data.subjectindex && a.data.subjectindex > -1) {
            s.globalData.isFristLogin = !1, s.updataGlobalData("isFristLogin", !1), o.updataUserChoiceType({
                ID: this.data.SysUserInfo.ID,
                ChoiceType: 0 == t.detail.value ? "数一" : 1 == t.detail.value ? "数二" : 2 == t.detail.value ? "数三" : ""
            }).then(function(t) {});
            var e = {
                ID: this.data.SysUserInfo.ID,
                SubjectType: 0 == a.data.subjectindex ? "数一" : 1 == a.data.subjectindex ? "数二" : 2 == a.data.subjectindex ? "数三" : ""
            };
            o.updataSubjectType(e).then(function(t) {
                (t.msg = "操作成功") && (console.log(e, "param输出参数"), a.setData({
                    subjectindex: s.globalData.subjectindex
                }), wx.switchTab({
                    url: "/pages/study/study?subjectindex=" + s.globalData.subjectindex
                }));
            });
        } else wx.showToast({
            title: "还未选择科备考科目",
            icon: "error",
            duration: 2e3
        }); else a.data.subjectindex && a.data.subjectindex > -1 ? (a.setData({
            subjectindex: s.globalData.subjectindex
        }), wx.switchTab({
            url: "/pages/study/study"
        })) : wx.showToast({
            title: "还未选择科备考科目",
            icon: "error",
            duration: 2e3
        });
    },
    onLoad: function(t) {
        var a = this, e = -1;
        s.globalData.StuID ? (e = s.globalData.subjectindex, this.setData({
            StuID: s.globalData.StuID,
            subjectindex: e,
            SysUserInfo: s.globalData.SysUserInfo
        })) : s.checkLoginReadyCallback = function(t) {
            "登陆成功" == t.data.msg ? (t.data.data.SysUserInfo.SubjectType && ("数一" == t.data.data.SysUserInfo.SubjectType ? e = 0 : "数二" == t.data.data.SysUserInfo.SubjectType ? e = 1 : "数三" == t.data.data.SysUserInfo.SubjectType && (e = 2)), 
            a.setData({
                StuID: t.data.data.SysUserInfo.StuID,
                subjectindex: e,
                SysUserInfo: t.data.data.SysUserInfo
            })) : console.log(111, "科目选择页面");
        };
    },
    onReady: function() {},
    onShow: function() {},
    onHide: function() {},
    onUnload: function() {},
    onPullDownRefresh: function() {},
    onReachBottom: function() {},
    onShareAppMessage: function() {
        return e.wxShare({});
    }
});