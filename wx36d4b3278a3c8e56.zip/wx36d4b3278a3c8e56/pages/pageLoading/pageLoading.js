var t = getApp();

Page({
    data: {
        count: 0
    },
    onLoad: function(n) {
        t.globalData.StuID ? wx.switchTab({
            url: "/pages/study/study"
        }) : t.checkLoginReadyCallback = function(t) {
            wx.switchTab({
                url: "/pages/study/study"
            });
        };
    },
    onReady: function() {},
    onShow: function() {
        this.data.count = this.data.count + 1, this.data.count > 1 && wx.switchTab({
            url: "/pages/study/study"
        });
    },
    onHide: function() {},
    onUnload: function() {},
    onPullDownRefresh: function() {},
    onReachBottom: function() {},
    onShareAppMessage: function() {}
});