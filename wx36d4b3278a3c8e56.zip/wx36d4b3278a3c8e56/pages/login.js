var a, e = require("../utils/getToken.js"), t = require("../api/user"), o = require("../api/product.js"), n = (a = require("../utils/crypto.js")) && a.__esModule ? a : {
    default: a
};

var s = require("../utils/util.js"), i = getApp(), l = i.window, u = new t.User(), d = new o.Product();

Page({
    data: {
        window: l,
        navigator: {
            border: !1,
            color: "#333333",
            bg: "#ffffff",
            back: !0,
            leftText: "",
            title: "",
            othergoback: !0,
            othergoHome: !0
        },
        info_id: i.globalData.wxInfoID,
        isAuthorize: !1,
        userInfo: {},
        OpenID: "",
        isfrist: !1,
        isloading: !1,
        isloadlogin: !1,
        appInfo: null,
        isShowTel: !1,
        inputTel: "",
        inputCode: "",
        SessionID: "",
        isNOinputtel: !1,
        IsSendMsg: !1,
        sendTime: 300,
        sendtext: "获取验证码",
        isloginload: !1,
        AgreementList: [ {}, {} ],
        isConsentBuy: !1,
        iswxuser: !1,
        headImg: "",
        nickName: "",
        isShowTelBtn: !1
    },
    consentBuy: function() {
        this.setData({
            isConsentBuy: !this.data.isConsentBuy
        });
    },
    getVipAgreement: function() {
        var a = this, e = {
            System_Station_ID: i.globalData.SassID,
            BusType: "用户协议",
            StuID: this.data.StuID,
            IsValid: 1,
            Type: -1
        };
        d.GetHeadImg(e).then(function(e) {
            if (Array.isArray(e.data) && e.data.length > 0) {
                var t = [];
                if (e.data.map(function(a) {
                    a.HeadImg && a.HeadImg.indexOf(".png") > -1 && (a.HeadImg = a.HeadImg.replace(/.png_yjs/g, ".png")), 
                    "0001-01-01T00:00:00" != a.ReleaseTime && "1900-01-01 00:00:00" != a.ReleaseTime && a.ReleaseTime ? new Date() > new Date(a.ReleaseTime) && t.push(a) : t.push(a);
                }), t.length > 0) {
                    var o = a.data.AgreementList;
                    o[0] = t[0], a.setData({
                        AgreementList: o
                    });
                }
            }
        });
    },
    getVipAgreement2: function() {
        var a = this, e = {
            System_Station_ID: i.globalData.SassID,
            BusType: "隐私协议",
            StuID: this.data.StuID,
            IsValid: 1,
            Type: -1
        };
        d.GetHeadImg(e).then(function(e) {
            if (Array.isArray(e.data) && e.data.length > 0) {
                var t = [];
                if (e.data.map(function(a) {
                    a.HeadImg && a.HeadImg.indexOf(".png") > -1 && (a.HeadImg = a.HeadImg.replace(/.png_yjs/g, ".png")), 
                    "0001-01-01T00:00:00" != a.ReleaseTime && "1900-01-01 00:00:00" != a.ReleaseTime && a.ReleaseTime ? new Date() > new Date(a.ReleaseTime) && t.push(a) : t.push(a);
                }), t.length > 0) {
                    var o = a.data.AgreementList;
                    o[1] = t[0], a.setData({
                        AgreementList: o
                    });
                }
            }
        });
    },
    VipAgreement: function(a) {
        var e = a.currentTarget.dataset.item;
        console.log(e);
        var t = this;
        if (1 == e.IsToUrl) wx.navigateTo({
            url: "/pages/about/about?ID=" + e.ID
        }); else if (e.Url) if (e.Url.indexOf("mp.weixin.qq.com") > -1) wx.navigateTo({
            url: "/pages/webview/webview?url=" + e.Url
        }); else if (e.Url.indexOf("https://") > -1) {
            var o = e.Url;
            if (e.Contexts && this.isJSON(e.Contexts)) {
                var n = JSON.parse(e.Contexts), s = "";
                n.map(function(a) {
                    s = s + "&" + a.toLocaleLowerCase() + "=" + t.data[a];
                }), s && (s = (s = s.slice(1)) + "&v=" + Date.now(), o = o.indexOf("?") > -1 ? o + "&" + s : o + "?" + s);
            }
            "https://yjs.web.dezhengedu.com/WebPhone/Activity/2022/index.html" == o ? wx.navigateTo({
                url: "/pages/webview/webview?annualreview=1&userstuid=" + t.data.StuID
            }) : wx.navigateTo({
                url: "/pages/webview/webview?wenjuanis=1&userstuid=" + t.data.StuID
            });
        } else wx.navigateTo({
            url: e.Url
        }); else wx.previewImage({
            current: e.HeadImg,
            urls: [ e.HeadImg ]
        });
    },
    back: function() {
        wx.navigateBack({
            delta: 1
        });
    },
    inputTelchange: function(a) {
        this.setData({
            inputTel: a.detail.value
        });
    },
    inputCodechange: function(a) {
        this.setData({
            inputCode: a.detail.value
        });
    },
    sendCode: function() {
        var a = this;
        if (!this.data.IsSendMsg) {
            if (this.data.inputTel) if (/^1\d{10}$/.test(this.data.inputTel)) {
                this.setData({
                    IsSendMsg: !0,
                    isNOinputtel: !0
                });
                var e = this;
                u.SendMsg({
                    Tel: this.data.inputTel
                }).then(function(t) {
                    if ("操作成功" == t.msg) {
                        a.data.SessionID = t.data;
                        var o = a.data.sendTime, n = setInterval(function() {
                            o < 0 ? (o = 300, e.setData({
                                IsSendMsg: !1,
                                sendTime: 300,
                                sendtext: "获取验证码",
                                isNOinputtel: !1
                            }), clearInterval(n)) : (o -= 1, e.setData({
                                sendTime: o,
                                sendtext: o + "秒再获取"
                            }));
                        }, 1e3);
                    } else a.setData({
                        IsSendMsg: !1,
                        sendTime: 300,
                        sendtext: "获取验证码",
                        isNOinputtel: !1
                    });
                });
            } else wx.showToast({
                title: "手机号码不正确！",
                icon: "none"
            }); else wx.showToast({
                title: "手机号码不能为空！",
                icon: "none"
            });
        }
    },
    logintel: function() {
        var a = this;
        if (!this.data.isloginload) if (this.data.inputTel) if (/^1\d{10}$/.test(this.data.inputTel)) if (this.data.inputCode) {
            this.data.isloginload = !0;
            this.data.userInfo;
            var e = i.globalData.AgentBusType ? i.globalData.AgentBusType : "微信小程序";
            "tuiguangrenyuan" == e && (e = "推广人员");
            var t = "";
            i.globalData.IsAgency > 0 ? i.globalData.AgencyStuID && (t = i.globalData.AgencyStuID) : (i.globalData.RecommendStuID && (t = i.globalData.RecommendStuID), 
            i.globalData.PullNewStuID && i.globalData.PullNewID && (t = i.globalData.PullNewStuID, 
            e = "拉新注册")), u.WebLogin({
                SessionID: this.data.SessionID,
                yzm: this.data.inputCode,
                Tel: this.data.inputTel,
                OpenID: this.data.OpenID,
                Info_ID: this.data.info_id,
                System_Station_ID: i.globalData.SassID,
                Source: e,
                SourceStuID: e ? t : ""
            }).then(function(e) {
                a.data.isloginload = !1, -1 == e.count ? wx.showToast({
                    title: e.data,
                    icon: "none"
                }) : (i.onLaunch(), i.checkLoginReadyCallback = function(a) {
                    if ("登陆成功" == a.data.msg) {
                        wx.hideLoading({
                            fial: function(a) {}
                        }), 1 == i.globalData.PullNewType && (i.globalData.isPullNewSign = !0, i.updataGlobalData("isPullNewSign", !0));
                        var e = getCurrentPages(), t = 0;
                        if (e.map(function(a, e) {
                            -1 == a.route.indexOf("pages/login") && (t = e);
                        }), e[t].onLoad(e[t].options), e[t].route.indexOf("pages/study/study") > -1) wx.switchTab({
                            url: "/pages/study/study"
                        }); else if (e[t].route.indexOf("pages/index/index") > -1) wx.switchTab({
                            url: "/pages/index/index"
                        }); else if (e[t].route.indexOf("pages/user/user") > -1) wx.switchTab({
                            url: "/pages/user/user"
                        }); else if (e[t].route.indexOf("wenjuan/pages/UserInfo/UserInfo") > -1) wx.switchTab({
                            url: "/pages/study/study"
                        }); else if (e[t].route.indexOf("choice/pages/loginNoquestion/loginNoquestion") > -1) wx.switchTab({
                            url: "/pages/study/study"
                        }); else {
                            var o = e.length - t - 1;
                            o > 0 ? wx.navigateBack({
                                delta: o
                            }) : wx.switchTab({
                                url: "/pages/study/study"
                            });
                        }
                    } else wx.navigateTo({
                        url: "/pages/login"
                    });
                });
            });
        } else wx.showToast({
            title: "验证码不能为空！",
            icon: "none"
        }); else wx.showToast({
            title: "手机号码不正确！",
            icon: "none"
        }); else wx.showToast({
            title: "手机号码不能为空！",
            icon: "none"
        });
    },
    cleartel: function() {
        this.setData({
            isShowTel: !1
        });
    },
    authUserInfo: function() {
        this.data.isConsentBuy ? this.setData({
            isLogin: !0,
            isShowTel: !0
        }) : wx.showToast({
            title: "请确认欧几里得用户协议",
            icon: "none",
            duration: 1500
        });
    },
    getPhoneNumber: function(a) {
        console.log("2. ---------------------------------------"), console.log("请求名称：手机号授权并解码"), 
        console.log("请求方法：/api/wx/DecryptTel"), console.log("执行函数：getPhoneNumber");
        var e = this;
        if (this.data.isConsentBuy) {
            if (!this.data.isloading) if (null != e.data.OpenID && "" != e.data.OpenID) {
                this.data.isloading = !0;
                var t = i.globalData.AgentBusType ? i.globalData.AgentBusType : "微信小程序";
                "tuiguangrenyuan" == t && (t = "推广人员");
                var o = "";
                i.globalData.IsAgency > 0 ? i.globalData.AgencyStuID && (o = i.globalData.AgencyStuID) : (i.globalData.RecommendStuID && (o = i.globalData.RecommendStuID), 
                i.globalData.PullNewStuID && i.globalData.PullNewID && (o = i.globalData.PullNewStuID, 
                t = "拉新注册")), wx.request({
                    url: i.globalData.configs.TOP_HOST + "/api/wx/DecryptTel",
                    header: {
                        "Content-Type": "application/x-www-form-urlencoded"
                    },
                    method: "POST",
                    data: s.json2Form({
                        encryptedData: a.detail.encryptedData,
                        iv: a.detail.iv,
                        session_key: e.data.session_key,
                        openid: e.data.OpenID,
                        info_id: e.data.info_id,
                        Source: t,
                        SourceStuID: t ? o : ""
                    }),
                    success: function(a) {
                        if (a.data.DES && a.data.data) try {
                            a.data.data = JSON.parse(n.default.decrypt(a.data));
                        } catch (e) {
                            a.data.data = n.default.decrypt(a.data);
                        }
                        e.data.isloading = !1;
                        a.data, e.data.userInfo;
                        console.log("3. ---------------------------------------"), console.log("请求名称：授权信息并创建档案"), 
                        console.log("请求方法：userApi.CreateWXUser"), i.globalData.isFristLogin = !0, i.updataGlobalData("isFristLogin", !0), 
                        i.onLaunch(), i.checkLoginReadyCallback = function(a) {
                            if (console.log(a, "ddd"), "登陆成功" == a.data.msg) {
                                wx.hideLoading({
                                    fial: function(a) {}
                                }), 1 == i.globalData.PullNewType && (i.globalData.isPullNewSign = !0, i.updataGlobalData("isPullNewSign", !0));
                                var e = getCurrentPages(), t = 0;
                                if (e.map(function(a, e) {
                                    -1 == a.route.indexOf("pages/login") && (t = e);
                                }), e[t].onLoad(e[t].options), e[t].route.indexOf("pages/study/study") > -1) wx.switchTab({
                                    url: "/pages/study/study"
                                }); else if (e[t].route.indexOf("pages/index/index") > -1) wx.switchTab({
                                    url: "/pages/index/index"
                                }); else if (e[t].route.indexOf("pages/user/user") > -1) wx.switchTab({
                                    url: "/pages/user/user"
                                }); else if (e[t].route.indexOf("wenjuan/pages/UserInfo/UserInfo") > -1) wx.switchTab({
                                    url: "/pages/study/study"
                                }); else {
                                    var o = e.length - t - 1;
                                    o > 0 ? wx.navigateBack({
                                        delta: o
                                    }) : wx.switchTab({
                                        url: "/pages/study/study"
                                    });
                                }
                            } else wx.navigateTo({
                                url: "/pages/login"
                            });
                        };
                    }
                });
            } else this.data.isloading = !0, 1 == i.globalData.PullNewType && (i.globalData.isPullNewSign = !0, 
            i.updataGlobalData("isPullNewSign", !0)), e.login();
        } else wx.showToast({
            title: "请确认欧几里得用户协议",
            icon: "none",
            duration: 1500
        });
    },
    login: function() {
        var a = arguments.length > 0 && void 0 !== arguments[0] && arguments[0], t = this;
        console.log("1. ---------------------------------------"), console.log("请求名称：微信授权获取用户基本信息"), 
        console.log("请求方法：wx.login -> wx.getUserProfile"), console.log("执行函数：login");
        this.data.headImg, this.data.nickName;
        this.data.isloadlogin || (this.data.isloadlogin = !0, wx.login({
            success: function(o) {
                wx.showLoading({
                    title: "正在微信授权.."
                });
                var l = i.globalData.AgentBusType ? i.globalData.AgentBusType : "微信小程序";
                "tuiguangrenyuan" == l && (l = "推广人员");
                var u = "";
                i.globalData.IsAgency > 0 ? i.globalData.AgencyStuID && (u = i.globalData.AgencyStuID) : (i.globalData.RecommendStuID && (u = i.globalData.RecommendStuID), 
                i.globalData.PullNewStuID && i.globalData.PullNewID && (u = i.globalData.PullNewStuID, 
                l = "拉新注册")), wx.request({
                    url: i.globalData.configs.TOP_HOST + "/api/wx/CheckCodeV2",
                    data: {
                        Id: t.data.info_id,
                        code: o.code,
                        Source: l,
                        SourceStuID: l ? u : ""
                    },
                    header: {
                        "content-type": "application/json"
                    },
                    success: function(o) {
                        if (o.data.DES && o.data.data) try {
                            o.data.data = JSON.parse(n.default.decrypt(o.data));
                        } catch (a) {
                            o.data.data = n.default.decrypt(o.data);
                        }
                        var l = o.data;
                        if (t.data.isloading = !1, t.data.isloadlogin = !1, "登陆成功" == l.msg) if (a) t.setData({
                            OpenID: l.data.WxUserInfo.openid,
                            session_key: l.session_key
                        }), wx.hideLoading({
                            fial: function(a) {}
                        }), l.data.WxUserInfo.StuID ? t.setData({
                            isShowTelBtn: !0
                        }) : wx.redirectTo({
                            url: "/pages/maintenance/maintenance"
                        }); else {
                            wx.hideLoading({
                                fial: function(a) {}
                            }), l.data.resule.session_key;
                            var u = l.data.WxUserInfo;
                            if (u.StuID.length > 3) {
                                t.setData({
                                    isShowTelBtn: !0
                                }), wx.setStorage({
                                    data: !0,
                                    key: "isLogin"
                                }), i.globalData.isLogin = !0, console.log("-------------- login.js 初始化 ------------------------");
                                var d = l.data.SysUserInfo;
                                wx.setStorage({
                                    key: "StuID",
                                    data: d.StuID
                                }), wx.setStorage({
                                    key: "SysUserInfo",
                                    data: d
                                }), i.globalData.IsAct = 2 == d.IsAct, i.updataGlobalData("isLogin", !0), i.updataGlobalData("SysUserInfo", d), 
                                i.updataGlobalData("StuID", d.StuID), i.updataGlobalData("Tel", d.Tel), i.updataGlobalData("IsAct", 2 == d.IsAct), 
                                i.globalData.subjectindex = "数一" == d.SubjectType ? 0 : "数二" == d.SubjectType ? 1 : "数三" == d.SubjectType ? 2 : -1, 
                                i.updataGlobalData("SubjectType", "数一" == d.SubjectType ? 0 : "数二" == d.SubjectType ? 1 : "数三" == d.SubjectType ? 2 : -1), 
                                wx.setStorage({
                                    data: "数一" == d.SubjectType ? 0 : "数二" == d.SubjectType ? 1 : "数三" == d.SubjectType ? 2 : -1,
                                    key: "subjectindex"
                                }), console.log("获取StuID：" + d.StuID), console.log("----------------------------------------------"), 
                                console.log(u), i.updataGlobalData("userInfo", {
                                    SysUserInfo: d,
                                    userCode: d.ID,
                                    nickName: u.Nickname,
                                    avatarUrl: u.HeadImgurl,
                                    subscribe: u.Subscribe,
                                    OpenID: u.OpenID
                                }), wx.setStorage({
                                    data: {
                                        userCode: d.ID,
                                        nickName: u.Nickname,
                                        avatarUrl: u.HeadImgurl,
                                        subscribe: u.Subscribe,
                                        OpenID: u.OpenID
                                    },
                                    key: "userInfo"
                                }), console.log("----------------------------------------------");
                                var r = 1, g = "";
                                d.VipEndTime && (r = i.isVipFunction(d.VipEndTime) ? 2 : 1), 2 == r && (g = d.VipEndTime), 
                                i.updataGlobalData("vipLevel", r), i.updataGlobalData("VIPValidTime", g), wx.setStorage({
                                    data: r,
                                    key: "vipLevel"
                                }), wx.setStorage({
                                    data: g,
                                    key: "VIPValidTime"
                                }), console.log("----------------------------------------------");
                                var p = l.data.UserInfo;
                                console.log(p), p.length > 0 ? (i.updataGlobalData("UsersInfo", p), i.updataGlobalData("UsersInfo", p)) : (i.updataGlobalData("UsersInfo", []), 
                                i.updataGlobalData("UsersInfo", []));
                                var c = !1;
                                if (i.globalData.appInfo.BetaProduct && l.data.CourseUsers.length > 0) {
                                    var f = i.globalData.appInfo.BetaProduct.split(",");
                                    l.data.CourseUsers.map(function(a) {
                                        f.map(function(e) {
                                            a.CourseProductID == e && (c = !0);
                                        });
                                    });
                                }
                                i.globalData.isBetaProduct = c, i.updataGlobalData("isBetaProduct", c), wx.setStorage({
                                    data: c,
                                    key: "isBetaProduct"
                                });
                                var D = !1;
                                if (i.globalData.appInfo.BetaVipProduct) {
                                    if (i.globalData.appInfo.BetaVipProduct.indexOf("VIP用户") > -1 && 2 == r) ; else if (l.data.CourseUsers.length > 0) {
                                        var w = i.globalData.appInfo.BetaVipProduct.split(",");
                                        l.data.CourseUsers.map(function(a) {
                                            w.map(function(e) {
                                                a.CourseProductID == e && (D = !0);
                                            });
                                        });
                                    }
                                } else D = !0;
                                i.globalData.isBetaVipProduct = D, i.updataGlobalData("isBetaVipProduct", D), wx.setStorage({
                                    data: D,
                                    key: "isBetaVipProduct"
                                });
                                var I = !1;
                                if (i.globalData.appInfo && i.globalData.appInfo.ParmText1) {
                                    if (i.globalData.appInfo.ParmText1.indexOf("VIP用户") > -1 && 2 == r) I = !0; else if (l.data.CourseUsers.length > 0) {
                                        var h = i.globalData.appInfo.ParmText1.split(",");
                                        l.data.CourseUsers.map(function(a) {
                                            h.map(function(e) {
                                                a.CourseProductID == e && (I = !0);
                                            });
                                        });
                                    }
                                } else I = !1;
                                i.globalData.isMajorComputing = I, i.updataGlobalData("isMajorComputing", I), wx.setStorage({
                                    data: I,
                                    key: "isMajorComputing"
                                });
                                var b = !1;
                                l.data.CourseUsers.map(function(a) {
                                    1095 != a.CourseProductID && 1096 != a.CourseProductID && 1097 != a.CourseProductID || (b = !0);
                                }), i.globalData.isLookMajorComputing = b, i.updataGlobalData("isLookMajorComputing", b), 
                                wx.setStorage({
                                    data: b,
                                    key: "isLookMajorComputing"
                                });
                                var x = !1;
                                if (i.globalData.appInfo.BetaDYProducts) {
                                    if (i.globalData.appInfo.BetaDYProducts.indexOf("VIP用户") > -1 && 2 == r) ; else if (l.data.CourseUsers.length > 0) {
                                        var y = i.globalData.appInfo.BetaDYProducts.split(",");
                                        l.data.CourseUsers.map(function(a) {
                                            y.map(function(e) {
                                                a.CourseProductID == e && (x = !0);
                                            });
                                        });
                                    }
                                } else x = !1;
                                if (i.globalData.isBetaDYVipProduct = x, i.updataGlobalData("isBetaDYVipProduct", x), 
                                wx.setStorage({
                                    data: x,
                                    key: "isBetaDYVipProduct"
                                }), console.log("----------------------------------------------"), wx.showToast({
                                    title: "登录成功"
                                }), l.Token) {
                                    s.referAgentUrl(), s.setAppsource();
                                    var S = getCurrentPages();
                                    -1 == S[S.length - 1].route.indexOf("pages/login") ? wx.navigateBack({
                                        delta: 1
                                    }) : wx.switchTab({
                                        url: "/pages/index/index"
                                    });
                                } else wx.setStorageSync("isToken", !0), (0, e.getToken)(l.data.SysUserInfo.StuID).then(function(a) {
                                    s.referAgentUrl(), s.setAppsource();
                                    var e = getCurrentPages(), t = 0;
                                    if (e.map(function(a, e) {
                                        -1 == a.route.indexOf("pages/login") && (t = e);
                                    }), e[t].onLoad(e[t].options), e[t].route.indexOf("pages/study/study") > -1) wx.switchTab({
                                        url: "/pages/study/study"
                                    }); else if (e[t].route.indexOf("pages/index/index") > -1) wx.switchTab({
                                        url: "/pages/index/index"
                                    }); else if (e[t].route.indexOf("pages/user/user") > -1) wx.switchTab({
                                        url: "/pages/user/user"
                                    }); else if (e[t].route.indexOf("wenjuan/pages/UserInfo/UserInfo") > -1) wx.switchTab({
                                        url: "/pages/study/study"
                                    }); else {
                                        var o = e.length - t - 1;
                                        o > 0 && -1 == e[t].route.indexOf("pages/login") ? wx.navigateBack({
                                            delta: o
                                        }) : wx.switchTab({
                                            url: "/pages/study/study"
                                        });
                                    }
                                });
                            } else wx.redirectTo({
                                url: "/pages/maintenance/maintenance"
                            }), wx.hideLoading({
                                fial: function(a) {}
                            }), console.log("账号异常，非StuID 可能是手机号 ...");
                        } else "需绑定手机号码" == l.errmsg ? (console.info("2. ---------------------------------------"), 
                        console.info("请求名称：等待用户授权手机号"), console.info("请求方法：/api/wx/DecryptTel"), console.info("执行函数：getPhoneNumber"), 
                        a ? t.setData({
                            OpenID: l.openid,
                            session_key: l.session_key,
                            isShowTelBtn: !0
                        }) : t.setData({
                            OpenID: l.openid,
                            session_key: l.session_key,
                            isLogin: !0,
                            isShowTel: !0,
                            isShowTelBtn: !0
                        }), wx.hideLoading({
                            fial: function(a) {}
                        })) : (wx.hideLoading({
                            fial: function(a) {}
                        }), wx.showModal({
                            title: "登录提示",
                            showCancel: !1,
                            content: "请联系管理员：" + l.msg
                        }), wx.redirectTo({
                            url: "/pages/maintenance/maintenance"
                        }));
                    }
                });
            },
            fail: function(a) {
                console.log("wx.login fail ...");
            }
        }));
    },
    onLoad: function(a) {
        var e = this;
        getApp().registerListener(this.onCurrentUserChange.bind(this)), wx.hideShareMenu(), 
        i.globalData.appInfo ? (this.setData({
            appInfo: i.globalData.appInfo
        }), this.getVipAgreement(), this.getVipAgreement2(), this.login(!0)) : (i.checkLoginReadyCallback = function(a) {
            e.setData({
                appInfo: i.globalData.appInfo
            }), e.login(!0);
        }, this.getVipAgreement(), this.getVipAgreement2());
    },
    onCurrentUserChange: function() {
        if (getApp().globalData.vipLevel && getApp().globalData.VIPValidTime) {
            var a = getApp().globalData.vipLevel;
            this.setData({
                vipLevel: 2 == a ? "VIP会员" : "普通用户"
            });
        }
    },
    onReady: function() {},
    onShow: function() {},
    onHide: function() {},
    onShareAppMessage: function() {
        return s.wxShare({});
    },
    onUnload: function() {},
    onPullDownRefresh: function() {},
    onReachBottom: function() {}
});