var t = require("../../api/product.js"), a = getApp(), e = a.window, n = new t.Product();

Page({
    data: {
        window: e,
        navigator: {
            border: !1,
            color: "#333333",
            bg: "#ffffff",
            back: !0,
            leftText: "",
            title: "欧几里得",
            othergoback: !0,
            othergoHome: !0
        },
        list: [],
        ADID: 0,
        datainfo: null
    },
    gotoMyService: function() {
        wx.navigateTo({
            url: "/user/pages/myService/myService"
        });
    },
    getData: function() {
        var t = this;
        n.GetHeadImg({
            ID: this.data.ADID,
            StuID: a.globalData.StuID,
            IsValid: 238 == this.data.ADID ? -1 : 1
        }).then(function(a) {
            if (Array.isArray(a.data) && a.data.length > 0) {
                var e = a.data[0];
                e.Files && (e.Files = e.Files.replace(/.png_yjs/g, ".png"), e.Files = e.Files.split(";")), 
                t.setData({
                    list: e.Files,
                    datainfo: e
                });
            }
        });
    },
    gotourl: function() {
        wx.navigateTo({
            url: this.data.datainfo.Url
        });
    },
    onLoad: function(t) {
        this.setData({
            ADID: t.ID
        }), this.getData();
    },
    onReady: function() {},
    onShow: function(t) {},
    onHide: function() {},
    onUnload: function() {},
    onPullDownRefresh: function() {},
    onReachBottom: function() {},
    onShareAppMessage: function() {
        return util.wxShare({});
    }
});