var e, a, t = require("../../@babel/runtime/helpers/regeneratorRuntime"), n = require("../../@babel/runtime/helpers/asyncToGenerator"), o = require("../../@babel/runtime/helpers/defineProperty"), r = require("../../api/user"), i = (e = require("../../utils/util")) && e.__esModule ? e : {
    default: e
}, s = require("../../api/product.js"), u = require("../../api/question.js");

var c = getApp(), l = c.window, d = new s.Product(), g = new u.Question(), p = new r.User();

Page({
    data: (a = {
        window: l,
        navigator: {
            border: !1,
            color: "#333333",
            bg: "#ffffff",
            back: !1,
            leftText: "",
            title: ""
        },
        isReadUnInfo: !1,
        isOpenAuthDialog: !1,
        OpenID: "",
        StuID: "",
        userCode: "",
        isLogin: !1,
        userInfo: {},
        sysUserInfo: {},
        vipLevel: "普通用户",
        vipEndTime: "",
        userPages: [ {
            name: "错题本",
            url: "marks"
        }, {
            name: "我的收藏",
            url: "favorite"
        }, {
            name: "我的提问",
            url: "question"
        } ],
        InfoNum: 0,
        isHaveExamine: !1,
        QQGroup: "",
        vipEndDay: 0
    }, o(o(o(o(o(o(o(o(o(o(a, "userInfo", {}), "isShowActHint", !1), "isMonligtedTeacher", !1), "isQuestionTeacher", !1), "isDYVipProduct", !1), "isVip", !1), "couponcardNum", 0), "isBetaVipProduct", !1), "isDYVipProduct", !1), "isIOS", !1), 
    o(o(o(o(a, "isCourse", !1), "isSetShow", !1), "isCreator", !1), "isshowSchool", !1)),
    navTocompany: function() {
        var e = this;
        return n(t().mark(function a() {
            var n, o, r, s, u, l, g, p;
            return t().wrap(function(a) {
                for (;;) switch (a.prev = a.next) {
                  case 0:
                    if (!(n = i.default.IsStorageSyncExpire("appotherImgdata")) || !Array.isArray(n)) {
                        a.next = 5;
                        break;
                    }
                    n = n, a.next = 10;
                    break;

                  case 5:
                    return o = {
                        System_Station_ID: c.globalData.SassID,
                        BusType: "其他临时图片",
                        IsValid: 1,
                        Type: -1,
                        SortDesc: "AddTime Desc"
                    }, a.next = 8, d.GetHeadImg(o);

                  case 8:
                    r = a.sent, Array.isArray(r.data) ? (n = r.data, i.default.AddSotrageSyncExpire("appotherImgdata", n)) : n = [];

                  case 10:
                    n.length > 0 ? (s = [], n.map(function(e) {
                        "企业文化" == e.Title && s.push(e);
                    }), s.length > 0 ? (s[0].HeadImg = s[0].HeadImg ? s[0].HeadImg.replace(/.png_yjs/g, ".png") : "", 
                    u = s[0], c.addHeadImgListLog(u.ID), 1 == u.IsToUrl ? wx.navigateTo({
                        url: "/pages/about/about?ID=" + u.ID
                    }) : u.Url ? u.Url.indexOf("mp.weixin.qq.com") > -1 ? wx.navigateTo({
                        url: "/pages/webview/webview?url=" + u.Url
                    }) : u.Url.indexOf("https://") > -1 ? (l = u.Url, u.Contexts && e.isJSON(u.Contexts) && (g = JSON.parse(u.Contexts), 
                    p = "", g.map(function(e) {
                        p = p + "&" + e.toLocaleLowerCase() + "=" + that.data[e];
                    }), p && (p = (p = p.slice(1)) + "&v=" + Date.now(), l = l.indexOf("?") > -1 ? l + "&" + p : l + "?" + p)), 
                    "https://yjs.web.dezhengedu.com/WebPhone/Activity/2022/index.html" == l ? wx.navigateTo({
                        url: "/pages/webview/webview?annualreview=1&userstuid=" + that.data.StuID
                    }) : wx.navigateTo({
                        url: "/pages/webview/webview?wenjuanis=1&userstuid=" + that.data.StuID
                    })) : wx.navigateTo({
                        url: u.Url
                    }) : wx.previewImage({
                        current: u.HeadImg,
                        urls: [ u.HeadImg ]
                    })) : wx.showToast({
                        icon: "none",
                        title: "暂未设置企业文化"
                    })) : wx.showToast({
                        icon: "none",
                        title: "暂未设置企业文化"
                    });

                  case 11:
                  case "end":
                    return a.stop();
                }
            }, a);
        }))();
    },
    SetShow: function() {
        this.setData({
            isSetShow: !this.data.isSetShow
        });
    },
    GetCourse: function() {
        var e = this;
        return n(t().mark(function a() {
            var n, o, r, s, u;
            return t().wrap(function(a) {
                for (;;) switch (a.prev = a.next) {
                  case 0:
                    if (!(n = i.default.IsStorageSyncExpire("userAndStudyGetCoursedata")) || !Array.isArray(n)) {
                        a.next = 5;
                        break;
                    }
                    n = n, a.next = 10;
                    break;

                  case 5:
                    return o = {
                        StuID: e.data.StuID,
                        System_Station_ID: c.globalData.SassID,
                        Type: "培训课程",
                        SortDesc: "Sort"
                    }, a.next = 8, d.GetProductByStuID(o);

                  case 8:
                    r = a.sent, Array.isArray(r.data) ? (n = r.data, i.default.AddSotrageSyncExpire("userAndStudyGetCoursedata", n)) : n = [];

                  case 10:
                    if (s = !1, !(n.length > 0)) {
                        a.next = 23;
                        break;
                    }
                    u = 0;

                  case 13:
                    if (!(u < n.length)) {
                        a.next = 20;
                        break;
                    }
                    if (1189 != n[u].ID) {
                        a.next = 17;
                        break;
                    }
                    return s = !0, a.abrupt("break", 20);

                  case 17:
                    u++, a.next = 13;
                    break;

                  case 20:
                    e.setData({
                        isCourse: !0,
                        isshowSchool: s
                    }), a.next = 24;
                    break;

                  case 23:
                    e.setData({
                        isCourse: !1,
                        isshowSchool: s
                    });

                  case 24:
                  case "end":
                    return a.stop();
                }
            }, a);
        }))();
    },
    handleContact: function(e) {
        console.log(e.detail.path, "e.detail.path"), console.log(e.detail.query, "e.detail.query");
    },
    getcouponcardList: function() {
        var e = this;
        return n(t().mark(function a() {
            var n, o, r, s;
            return t().wrap(function(a) {
                for (;;) switch (a.prev = a.next) {
                  case 0:
                    if (!(n = i.default.IsStorageSyncExpire("usergetcouponcardListdata")) || !Array.isArray(n)) {
                        a.next = 5;
                        break;
                    }
                    n = n, a.next = 10;
                    break;

                  case 5:
                    return o = {
                        StuID: e.data.StuID,
                        System_Station_ID: c.globalData.SassID,
                        IsConvert: 1,
                        IsUse: -1,
                        page: 0,
                        limit: 1e3
                    }, a.next = 8, d.GetCouponsInfo(o);

                  case 8:
                    r = a.sent, Array.isArray(r.data) ? (n = r.data, i.default.AddSotrageSyncExpire("usergetcouponcardListdata", n)) : n = [];

                  case 10:
                    s = 0, n.map(function(e) {
                        new Date() < new Date(e.EndTime) && (s += 1);
                    }), e.setData({
                        couponcardNum: s
                    });

                  case 13:
                  case "end":
                    return a.stop();
                }
            }, a);
        }))();
    },
    navToMyIntegral: function() {
        wx.navigateTo({
            url: "/user/pages/Integral/Integral"
        });
    },
    navToSchool: function() {
        wx.navigateTo({
            url: "/school/pages/findMajor/findMajor"
        });
    },
    navToSchool2: function() {
        wx.navigateTo({
            url: "/school/pages/SchoolList/SchoolList"
        });
    },
    gotoCourseList: function() {
        wx.navigateTo({
            url: "/course/pages/ProductList/ProductList"
        });
    },
    updateData: function() {
        wx.showLoading({
            title: "加载中"
        });
        try {
            wx.removeStorageSync("LoginToken");
        } catch (e) {}
        c.onLaunch(), c.checkLoginReadyCallback = function(e) {
            "登陆成功" == e.data.msg && setTimeout(function() {
                wx.hideLoading({
                    success: function(e) {}
                }), wx.showToast({
                    title: "更新成功"
                }), wx.switchTab({
                    url: "/pages/study/study"
                });
            }, 1e3);
        };
    },
    getInfoNum: function(e) {
        this.setData({
            InfoNum: e.detail
        });
    },
    clearActModel: function() {
        this.setData({
            isShowActHint: !1
        });
    },
    gotorobot: function() {
        wx.navigateTo({
            url: "/user/pages/robot/robot"
        });
    },
    linkToWenDa: function() {
        wx.navigateTo({
            url: "/wenda/pages/index"
        });
    },
    linkToDaYi: function() {
        wx.navigateTo({
            url: "/wenda/pages/answer/index/index"
        });
    },
    gotoCourse: function() {
        this.checkUserLogin() && wx.navigateTo({
            url: "/course/pages/ProductList/ProductList"
        });
    },
    navTodryrunPage: function() {
        this.checkUserLogin() && wx.navigateTo({
            url: "/dryrun/pages/myexamlist/myexamlist"
        });
    },
    navToGraduate: function() {
        this.checkUserLogin() && wx.navigateTo({
            url: "/user/pages/Graduate/Graduate"
        });
    },
    navtoActive: function() {
        this.checkUserLogin() && wx.navigateTo({
            url: "/user/pages/FunctionActivateInput/FunctionActivateInput"
        });
    },
    navToMyInfo: function() {
        wx.navigateTo({
            url: "/user/pages/MyInfo/MyInfo"
        });
    },
    navToRecruit: function() {
        wx.navigateTo({
            url: "/user/pages/recruitlist/recruitlist"
        });
    },
    navToCoursePage: function() {
        wx.navigateTo({
            url: "/user/pages/MyProductList/MyProductList"
        });
    },
    navToVipPage: function() {
        this.checkUserLogin() && wx.navigateTo({
            url: "vip"
        });
    },
    navLoginPage: function() {
        wx.navigateTo({
            url: "../login?page=user"
        });
    },
    gotoCourseLog: function() {
        this.checkUserLogin() && wx.navigateTo({
            url: "/user/pages/CourseLog/CourseLog"
        });
    },
    gotomyNotes: function() {
        this.checkUserLogin() && wx.navigateTo({
            url: "/user/pages/MyNotesList/MyNotesList"
        });
    },
    navToUserPage: function(e) {
        if (this.checkUserLogin()) {
            var a = e.currentTarget.dataset.page;
            "marks" != a && "favorite" != a || this.setData({
                isShowActHint: !0
            }), wx.navigateTo({
                url: "../../user/pages/" + a + "?vip=" + this.data.curVipType
            });
        }
    },
    gotomywraparound: function() {
        this.checkUserLogin() && wx.navigateTo({
            url: "/wenjuan/pages/CouponsList/CouponsList"
        });
    },
    gotoCoupons: function() {
        wx.navigateTo({
            url: "/wenjuan/pages/CouponsList/CouponsList"
        });
    },
    gotocouponsEndec: function() {
        wx.navigateTo({
            url: "/wenjuan/pages/CouponsEndecActivate/CouponsEndecActivate"
        });
    },
    gotocouponstuid: function() {
        this.checkUserLogin() && (c.addHeadImgListLog2("我的", "推广大使"), wx.navigateTo({
            url: "/user/pages/Extend/Extend"
        }));
    },
    gotoopinion: function() {
        wx.navigateTo({
            url: "/user/pages/TicklingOpinion/TicklingOpinion"
        });
    },
    linkToUserInfo: function() {
        this.checkUserLogin() && wx.navigateTo({
            url: "/wenjuan/pages/UserInfo/UserInfo"
        });
    },
    gotoMyService: function() {
        wx.navigateTo({
            url: "/user/pages/myService/myService"
        });
    },
    navToUserVipPage: function() {
        wx.navigateTo({
            url: "/wenjuan/pages/VIPInfo/VIPInfo"
        });
    },
    linkToVIP: function() {
        this.checkUserLogin() && wx.navigateTo({
            url: "/wenjuan/pages/VIPInfo/VIPInfo"
        });
    },
    scanBookCode: function(e) {
        wx.scanCode({
            onlyFromCamera: !0,
            success: function(e) {
                var a = e.result, t = e.result ? e.result.split("=") : [];
                t.length > 1 && (t = t[1], a && a.indexOf("oujilide.php") > 0 ? wx.redirectTo({
                    url: "../../topic/pages/topic?q=" + t
                }) : a && a.indexOf("video") > 0 ? wx.navigateTo({
                    url: "/topic/pages/video?vid=" + t + "&VideoID=" + t
                }) : wx.showModal({
                    title: "提示",
                    content: "抱歉，无法识别二维码里的内容！\n关于考研的问题都可以联系班班，\n微信号：liqilin04 \n",
                    showCancel: !1,
                    confirmText: "知道了"
                }));
                var n = e.path;
                n && n.indexOf("page=vip") > 0 && (wx.showToast({
                    title: "会员权益"
                }), wx.navigateTo({
                    url: "/wenjuan/pages/VIPInfo/VIPInfo"
                }));
            },
            fail: function() {},
            complete: function() {}
        });
    },
    checkUserLogin: function() {
        if ("" != this.data.StuID && this.data.isLogin) return !0;
        wx.navigateTo({
            url: "../login?backPath=user"
        });
    },
    navToplay: function() {
        var e = encodeURIComponent(JSON.stringify({
            path: "pages/index/index",
            pid: 1
        }));
        wx.navigateTo({
            url: "plugin-private://wx2b03c6e691cd7370/pages/live-player-plugin?room_id=".concat(3, "&custom_params=").concat(e)
        });
    },
    getData: function() {
        var e = this;
        return n(t().mark(function a() {
            var n, o;
            return t().wrap(function(a) {
                for (;;) switch (a.prev = a.next) {
                  case 0:
                    if (!(n = i.default.IsStorageSyncExpire("userGetExamineListdata")) || !Array.isArray(n)) {
                        a.next = 5;
                        break;
                    }
                    n = n, a.next = 9;
                    break;

                  case 5:
                    return a.next = 7, d.GetExamineList({
                        StuID: e.data.StuID,
                        limit: 10,
                        page: 1
                    });

                  case 7:
                    o = a.sent, Array.isArray(o.data) ? (n = o.data, i.default.AddSotrageSyncExpire("userGetExamineListdata", n)) : n = [];

                  case 9:
                    n.length > 0 ? e.setData({
                        isHaveExamine: !0
                    }) : e.setData({
                        isHaveExamine: !1
                    });

                  case 10:
                  case "end":
                    return a.stop();
                }
            }, a);
        }))();
    },
    copyQQ: function() {
        wx.setClipboardData({
            data: this.data.QQGroup,
            success: function(e) {
                wx.getClipboardData({
                    success: function(e) {
                        wx.showToast({
                            title: "复制成功"
                        });
                    }
                });
            }
        });
    },
    getQuestionTeacher: function() {
        var e = this;
        return n(t().mark(function a() {
            var n, o, r;
            return t().wrap(function(a) {
                for (;;) switch (a.prev = a.next) {
                  case 0:
                    if (n = e, !(o = i.default.IsStorageSyncExpire("userCheckUserIsQuestionTeacherdata")) || !Array.isArray(o)) {
                        a.next = 6;
                        break;
                    }
                    o = o, a.next = 10;
                    break;

                  case 6:
                    return a.next = 8, g.CheckUserIsQuestionTeacher({
                        UserID: c.globalData.userInfo.userCode,
                        System_Station_ID: c.globalData.SassID
                    });

                  case 8:
                    r = a.sent, Array.isArray(r.data) && r.data.length > 0 && Array.isArray(r.data[0]) ? (o = r.data[0], 
                    i.default.AddSotrageSyncExpire("userCheckUserIsQuestionTeacherdata", o)) : o = [];

                  case 10:
                    o.length > 0 ? n.setData({
                        isQuestionTeacher: !0
                    }) : n.setData({
                        isQuestionTeacher: !1
                    });

                  case 11:
                  case "end":
                    return a.stop();
                }
            }, a);
        }))();
    },
    getMonligtedTeacher: function() {
        var e = this;
        return n(t().mark(function a() {
            var n, o;
            return t().wrap(function(a) {
                for (;;) switch (a.prev = a.next) {
                  case 0:
                    if (!(n = i.default.IsStorageSyncExpire("userGetMonligtedTeacherListdata")) || !Array.isArray(n)) {
                        a.next = 5;
                        break;
                    }
                    n = n, a.next = 9;
                    break;

                  case 5:
                    return a.next = 7, d.GetMonligtedTeacherList({
                        BusValue: e.data.StuID,
                        System_Station_ID: c.globalData.SassID,
                        IsValid: 1,
                        page: 0,
                        limit: 1
                    });

                  case 7:
                    o = a.sent, Array.isArray(o.data) ? (n = o.data, i.default.AddSotrageSyncExpire("userGetMonligtedTeacherListdata", n)) : n = [];

                  case 9:
                    n.length > 0 ? (e.setData({
                        isMonligtedTeacher: !0
                    }), wx.setStorage({
                        key: "isMonligtedTeacher",
                        data: !0
                    }), wx.setStorage({
                        key: "MonligtedTeacherBookID",
                        data: n[0].Notes ? n[0].Notes : ""
                    })) : (wx.setStorage({
                        key: "isMonligtedTeacher",
                        data: !1
                    }), wx.setStorage({
                        key: "MonligtedTeacherBookID",
                        data: ""
                    }), e.setData({
                        isMonligtedTeacher: !1
                    }));

                  case 10:
                  case "end":
                    return a.stop();
                }
            }, a);
        }))();
    },
    getCreatorTeacher: function() {
        var e = this;
        return n(t().mark(function a() {
            var n, o;
            return t().wrap(function(a) {
                for (;;) switch (a.prev = a.next) {
                  case 0:
                    if (!(n = i.default.IsStorageSyncExpire("userGetDetermineCreatordata")) || !Array.isArray(n)) {
                        a.next = 5;
                        break;
                    }
                    n = n, a.next = 9;
                    break;

                  case 5:
                    return a.next = 7, p.GetDetermineCreator({
                        System_Station_ID: c.globalData.SassID,
                        StuID: e.data.StuID
                    });

                  case 7:
                    o = a.sent, Array.isArray(o.data) && o.data.length > 0 && Array.isArray(o.data[0]) ? (n = o.data[0], 
                    i.default.AddSotrageSyncExpire("userGetDetermineCreatordata", n)) : n = [];

                  case 9:
                    n.length > 0 && e.setData({
                        isCreator: !0
                    });

                  case 10:
                  case "end":
                    return a.stop();
                }
            }, a);
        }))();
    },
    gotoCreator: function() {
        wx.navigateTo({
            url: "/user/pages/creator/creator"
        });
    },
    onLoad: function(e) {
        getApp().registerListener(this.onCurrentUserChange.bind(this));
        var a = c.globalData.StuID;
        this.setData({
            userInfo: c.globalData.userInfo,
            StuID: a
        });
    },
    onCurrentUserChange: function() {
        if (getApp().globalData.vipLevel && getApp().globalData.VIPValidTime) {
            var e, a = getApp().globalData.vipLevel;
            e = parseInt((new Date(getApp().globalData.VIPValidTime).getTime() - new Date().getTime()) / 864e5), 
            this.setData({
                curVipType: a,
                vipLevel: 2 == a ? "VIP会员" : "普通用户",
                vipEndTime: i.default.dateFormat("YYYY-MM-DD", getApp().globalData.VIPValidTime),
                vipEndDay: e
            });
        }
    },
    onReady: function() {},
    authUserInfo: function() {
        var e = this;
        "" != e.data.OpenID ? wx.getUserProfile({
            lang: "zh_CN",
            desc: "用户登录",
            success: function(e) {
                return !1;
            },
            fail: function() {
                wx.showModal({
                    title: "您已拒绝小程序获取信息"
                }), e.setData({
                    isOpenAuthDialog: !0
                });
            }
        }) : console.log("小程序标识为空...");
    },
    checkUserIsReadUnInfo: function() {
        var e = this, a = c.globalData.UsersInfo ? c.globalData.UsersInfo : [];
        0 != a.length && a[0].UserName || wx.getStorage({
            key: "isReadUnInfo",
            success: function(t) {
                e.setData({
                    isReadUnInfo: t.data
                }), t.data && a[0].UserName || wx.showModal(o(o(o(o(o({
                    title: "提示"
                }, "title", "你的信息还未完善，马上去完善"), "cancelText", "稍后完善"), "cancelColor", "#ccc"), "confirmText", "马上完善"), "complete", function(a) {
                    a.confirm ? wx.navigateTo({
                        url: "/wenjuan/pages/UserInfo/UserInfo"
                    }) : a.cancel && (wx.setStorage({
                        data: !0,
                        key: "isReadUnInfo"
                    }), e.setData({
                        isReadUnInfo: !0
                    }));
                }));
            },
            fail: function(a) {
                wx.showModal(o(o(o(o(o({
                    title: "提示"
                }, "title", "你的信息还未完善，马上去完善"), "cancelText", "稍后完善"), "cancelColor", "#ccc"), "confirmText", "马上完善"), "complete", function(a) {
                    a.confirm ? wx.navigateTo({
                        url: "/wenjuan/pages/UserInfo/UserInfo"
                    }) : a.cancel && (wx.setStorage({
                        data: !0,
                        key: "isReadUnInfo"
                    }), e.setData({
                        isReadUnInfo: !0
                    }));
                }));
            }
        });
    },
    onShow: function() {
        try {
            wx.hideTabBar({
                animation: !0
            });
        } catch (e) {}
        var e = this;
        if (this.setData({
            isIOS: c.globalData.isIOS
        }), wx.getStorage({
            key: "isLogin",
            success: function(a) {
                e.setData({
                    isLogin: a.data
                });
            }
        }), c.globalData.StuID) {
            var a = !1;
            2 == c.globalData.vipLevel && (a = !0);
            var t;
            t = c.globalData.VIPValidTime ? parseInt((new Date(c.globalData.VIPValidTime).getTime() - new Date().getTime()) / 864e5) : -1, 
            e.setData({
                isLogin: !0,
                StuID: c.globalData.StuID,
                OpenID: c.globalData.userInfo.OpenID,
                userCode: c.globalData.userInfo.userCode,
                curVipType: c.globalData.vipLevel,
                vipLevel: c.globalData.vipLevel >= 2 ? "VIP会员" : "普通用户",
                vipEndTime: i.default.dateFormat("YYYY-MM-DD", c.globalData.VIPValidTime),
                sysUserInfo: c.globalData.UsersInfo.length > 0 ? c.globalData.UsersInfo[0] : {},
                QQGroup: c.globalData.appInfo.QQGroup,
                vipEndDay: t,
                userInfo: c.globalData.userInfo,
                isVip: a,
                isBetaVipProduct: c.globalData.isBetaVipProduct,
                isDYVipProduct: c.globalData.isBetaDYVipProduct
            }), e.getData(), e.getMonligtedTeacher(), e.getQuestionTeacher(), e.getcouponcardList(), 
            e.GetCourse(), e.getCreatorTeacher();
        } else c.checkLoginReadyCallback = function(a) {
            if ("登陆成功" == a.data.msg) {
                var t = !1, n = 1, o = "", r = a.data.data.SysUserInfo;
                r.VipEndTime && (n = c.isVipFunction(r.VipEndTime) ? 2 : 1), 2 == n && (o = r.VipEndTime, 
                t = !0);
                var s;
                s = parseInt((new Date(r.VipEndTime).getTime() - new Date().getTime()) / 864e5);
                var u = !1;
                if (c.globalData.appInfo.BetaVipProduct) {
                    if (c.globalData.appInfo.BetaVipProduct.indexOf("VIP用户") > -1 && 2 == n) ; else if (a.data.data.CourseUsers.length > 0) {
                        var l = c.globalData.appInfo.BetaVipProduct.split(",");
                        a.data.data.CourseUsers.map(function(e) {
                            l.map(function(a) {
                                e.CourseProductID == a && (u = !0);
                            });
                        });
                    }
                } else u = !0;
                var d = !1;
                if (c.globalData.appInfo.BetaDYProducts) {
                    if (c.globalData.appInfo.BetaDYProducts.indexOf("VIP用户") > -1 && 2 == n) ; else if (a.data.data.CourseUsers.length > 0) {
                        var g = c.globalData.appInfo.BetaDYProducts.split(",");
                        a.data.data.CourseUsers.map(function(e) {
                            g.map(function(a) {
                                e.CourseProductID == a && (d = !0);
                            });
                        });
                    }
                } else d = !0;
                e.setData({
                    isLogin: !0,
                    StuID: a.data.data.SysUserInfo.StuID,
                    OpenID: a.data.data.WxUserInfo.OpenID,
                    userCode: a.data.data.SysUserInfo.ID,
                    curVipType: n,
                    vipLevel: 2 == n ? "VIP会员" : "普通用户",
                    vipEndTime: i.default.dateFormat("YYYY-MM-DD", o),
                    sysUserInfo: a.data.data.UserInfo.length > 0 ? a.data.data.UserInfo[0] : {},
                    QQGroup: c.globalData.appInfo.QQGroup,
                    vipEndDay: s,
                    userInfo: {
                        SysUserInfo: a.data.data.SysUserInfo,
                        nickName: a.data.data.WxUserInfo.Nickname,
                        avatarUrl: a.data.data.WxUserInfo.HeadImgurl,
                        subscribe: a.data.data.WxUserInfo.Subscribe,
                        OpenID: a.data.data.WxUserInfo.OpenID
                    },
                    isVip: t,
                    isBetaVipProduct: u,
                    isDYVipProduct: d
                }), e.getData(), e.getMonligtedTeacher(), e.getcouponcardList(), e.getQuestionTeacher(), 
                e.getCreatorTeacher(), e.GetCourse();
            } else wx.navigateTo({
                url: "/pages/login"
            });
        };
    },
    onHide: function() {},
    onUnload: function() {},
    onPullDownRefresh: function() {},
    onReachBottom: function() {},
    onShareAppMessage: function() {
        return i.default.wxShare({});
    }
});