var a = require("../../api/user"), e = getApp(), o = e.window;

new a.User();

Page({
    data: {
        window: o,
        navigator: {
            border: !1,
            color: "#333333",
            bg: "#ffffff",
            back: !0,
            leftText: "",
            title: "设置"
        },
        userInfo: {}
    },
    updateVIP: function() {
        e.onLaunch(), e.checkLoginReadyCallback = function(a) {
            "登陆成功" == a.data.msg ? (wx.showModal({
                content: "更新成功"
            }), setTimeout(function() {
                wx.switchTab({
                    url: "/pages/study/study"
                });
            }, 1e3)) : wx.navigateTo({
                url: "/pages/login"
            });
        };
    },
    exitWxapp: function() {
        wx.removeStorageSync("StuID"), wx.removeStorageSync("SysUserInfo"), wx.removeStorageSync("userInfo"), 
        wx.removeStorageSync("vipLevel"), wx.removeStorageSync("VIPValidTime"), wx.removeStorageSync("UsersInfo"), 
        wx.removeStorageSync("isToken"), wx.removeStorageSync("LoginToken"), wx.setStorage({
            data: !1,
            key: "isLogin"
        }), e.updataGlobalData("isLogin", !1), e.updataGlobalData("StuID", ""), wx.switchTab({
            url: "/pages/study/study",
            success: function(a) {
                var e = getCurrentPages().pop();
                null != e && null != e && (e.options = {
                    backLogin: 1,
                    page: ""
                }, e.onLoad(e.options));
            }
        });
    },
    onLoad: function(a) {
        var o = this;
        e.globalData.StuID ? this.setData({
            userInfo: e.globalData.userInfo
        }) : e.checkLoginReadyCallback = function(a) {
            "登陆成功" == a.data.msg ? o.setData({
                userInfo: {
                    SysUserInfo: a.data.data.SysUserInfo,
                    nickName: a.data.data.WxUserInfo.Nickname,
                    avatarUrl: a.data.data.WxUserInfo.HeadImgurl,
                    subscribe: a.data.data.WxUserInfo.Subscribe,
                    OpenID: a.data.data.WxUserInfo.OpenID
                }
            }) : wx.navigateTo({
                url: "/pages/login"
            });
        };
    },
    onReady: function() {},
    onShow: function() {},
    onHide: function() {},
    onUnload: function() {},
    onPullDownRefresh: function() {},
    onReachBottom: function() {},
    onShareAppMessage: function() {
        return util.wxShare({});
    }
});