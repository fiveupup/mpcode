var e = require("../../@babel/runtime/helpers/regeneratorRuntime"), t = require("../../@babel/runtime/helpers/asyncToGenerator"), a = require("../../api/product.js"), r = (require("../../utils/util.js"), 
getApp()), n = r.window, o = new a.Product();

Page({
    data: {
        window: n,
        navigator: {
            border: !1,
            color: "#333",
            bg: "#ffffff",
            back: !0,
            leftText: "",
            title: "欧几里得数学",
            othergoback: !0,
            othergoHome: !0
        },
        StuID: "",
        SysUserInfo: null,
        orderID: 0,
        orderInfo: null,
        QuestionOrdeComment: []
    },
    previewImg: function(e) {
        wx.previewImage({
            current: e.target.dataset.src,
            urls: [ e.target.dataset.src ]
        });
    },
    getorderinfo: function() {
        var a = this;
        return t(e().mark(function t() {
            var r;
            return e().wrap(function(e) {
                for (;;) switch (e.prev = e.next) {
                  case 0:
                    return e.next = 2, o.GetQaQuestionOrderList({
                        ID: a.data.orderID,
                        limit: 1,
                        page: 1
                    });

                  case 2:
                    r = e.sent, Array.isArray(r.data) && r.data.length > 0 ? ((r = r.data).map(function(e) {
                        e.Files ? e.Files = e.Files.split(",") : e.Files = [], e.BasFiles ? e.BasFiles = e.BasFiles.split(";") : e.BasFiles = [];
                    }), a.setData({
                        orderInfo: r[0]
                    }), a.getodercomment(r[0].StuID), console.log(r[0])) : wx.navigateBack();

                  case 4:
                  case "end":
                    return e.stop();
                }
            }, t);
        }))();
    },
    getodercomment: function(a) {
        var n = this;
        return t(e().mark(function t() {
            var s, i;
            return e().wrap(function(e) {
                for (;;) switch (e.prev = e.next) {
                  case 0:
                    return s = [], e.next = 3, o.GetQaQuestionCommentList({
                        limit: 1e3,
                        page: 1,
                        BusID: n.data.orderID,
                        QuestionID: n.data.orderInfo.QuestionID,
                        System_Station_ID: r.globalData.SaasID,
                        SortDesc: "AddTime ASC"
                    });

                  case 3:
                    i = e.sent, Array.isArray(i.data) && i.data.length > 0 && (i.data.map(function(e) {
                        e.BusUrl ? e.BusUrl = e.BusUrl.split(",") : e.BusUrl = [], a == e.StuID ? e.IdentityType = "学生" : e.IdentityType = "老师";
                    }), s = i.data, console.log(s), n.setData({
                        QuestionOrdeComment: s
                    }));

                  case 5:
                  case "end":
                    return e.stop();
                }
            }, t);
        }))();
    },
    onLoad: function(e) {
        wx.hideShareMenu();
        var t = this, a = e.id ? e.id : 0;
        a || wx.navigateBack(), r.globalData.StuID ? (this.setData({
            StuID: r.globalData.StuID,
            SysUserInfo: r.globalData.SysUserInfo,
            orderID: a
        }), t.getorderinfo()) : r.checkLoginReadyCallback = function(e) {
            "登陆成功" == e.data.msg ? (t.setData({
                StuID: e.data.data.SysUserInfo.StuID,
                SysUserInfo: e.data.data.SysUserInfo,
                orderID: a
            }), t.getorderinfo()) : wx.navigateTo({
                url: "/pages/login"
            });
        };
    },
    onReady: function() {},
    onShow: function() {},
    onHide: function() {},
    onUnload: function() {},
    onPullDownRefresh: function() {},
    onReachBottom: function() {},
    onShareAppMessage: function() {}
});