var a = getApp(), t = a.window;

Page({
    data: {
        window: t,
        text: "系统维护中"
    },
    onLoad: function(t) {
        var o = this;
        a.globalData.appInfo ? 1 == a.globalData.appInfo.IsWxappRespect ? a.globalData.appInfo.RespectParm && this.setData({
            text: a.globalData.appInfo.RespectParm
        }) : wx.switchTab({
            url: "/pages/study/study"
        }) : a.checkLoginReadyCallback = function(t) {
            "登陆成功" == t.data.msg && (1 == a.globalData.appInfo.IsWxappRespect ? a.globalData.appInfo.RespectParm && o.setData({
                text: a.globalData.appInfo.RespectParm
            }) : wx.switchTab({
                url: "/pages/study/study"
            }));
        };
    },
    onReady: function() {},
    onShow: function() {},
    onHide: function() {},
    onUnload: function() {},
    onPullDownRefresh: function() {},
    onReachBottom: function() {},
    onShareAppMessage: function() {}
});