var e = require("../@babel/runtime/helpers/objectSpread2"), t = r(require("crypto-js")), a = r(require("../config.js"));

function r(e) {
    return e && e.__esModule ? e : {
        default: e
    };
}

var n, o, u, d = {};

n = d, o = t.default.enc.Utf8.parse("59b87344b54f31977f7c3dd445ab13e1"), u = t.default.enc.Utf8.parse("59b87344b54f3197"), 
n.encrypt = function(e) {
    var a = t.default.enc.Utf8.parse(e);
    return t.default.AES.encrypt(a, o, {
        iv: u,
        mode: t.default.mode.CBC,
        padding: t.default.pad.ZeroPadding
    });
}, n.decrypt = function(e) {
    var r = e.data;
    o = t.default.enc.Utf8.parse(e.RequestId);
    var n = t.default.AES.decrypt(r, o, {
        iv: u,
        mode: t.default.mode.CBC,
        padding: t.default.pad.ZeroPadding
    });
    try {
        return t.default.enc.Utf8 ? n.toString(t.default.enc.Utf8) : "";
    } catch (e) {
        if (getApp().globalData.StuID) {
            var d = {
                System_Station_ID: getApp().globalData.SassID,
                ErrorTxt: r,
                Notes: e,
                StuID: getApp().globalData.StuID,
                OpenID: getApp().globalData.userInfo.OpenID,
                Urls: "",
                PhoNetInfo: JSON.stringify(getApp().window),
                BusType: "小程序用户报错"
            }, p = {
                "content-type": "application/x-www-form-urlencoded;charset=utf-8",
                Accept: "application/json, text/plain, */*",
                Authorization: wx.getStorageSync("LoginToken")
            };
            wx.request({
                url: a.default.TOP_HOST + "/api/sys_error/Inner_sys_error",
                method: "post",
                data: d,
                header: p,
                scriptCharset: "utf-8",
                success: function(e) {},
                fail: function(e) {},
                complete: function(e) {
                    return [];
                }
            });
        }
    }
}, module.exports = e({}, d);