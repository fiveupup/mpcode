Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.default = void 0;

var e = require("../@babel/runtime/helpers/classCallCheck"), r = require("../@babel/runtime/helpers/createClass"), t = function() {
    function t() {
        e(this, t);
    }
    return r(t, [ {
        key: "setStorage2app",
        value: function(e) {
            for (var r = this, t = wx.getStorageInfoSync().keys || [], o = function(o) {
                r.get(t[o]).then(function(r) {
                    e[t[o]] = r;
                });
            }, n = 0; n < t.length; n++) o(n);
        }
    }, {
        key: "get",
        value: function(e) {
            var r = arguments.length > 1 && void 0 !== arguments[1] && arguments[1];
            if ("string" != typeof e) throw new Error("key is typeof string at storage.Get");
            if ("" === e.Trim()) throw new Error("key is not null at storage.Get");
            return new Promise(function(t, o) {
                if (r) {
                    var n = wx.getStorageSync(e.Trim());
                    t(n);
                } else wx.getStorage({
                    key: e.Trim(),
                    success: function(e) {
                        var r = e.data;
                        t(r);
                    },
                    fail: function(e) {
                        o(e.errMsg);
                    }
                });
            });
        }
    }, {
        key: "set",
        value: function(e, r) {
            var t = arguments.length > 2 && void 0 !== arguments[2] && arguments[2];
            if ("string" != typeof e) throw new Error("key is typeof string at storage.Set");
            if ("" === e.Trim()) throw new Error("key is not null at storage.Set");
            return new Promise(function(o, n) {
                t ? (wx.setStorageSync(e.Trim(), r), o({
                    errMsg: "storage okey"
                })) : wx.setStorage({
                    key: e.Trim(),
                    data: r,
                    success: function(e) {
                        o({
                            errMsg: "storage okey"
                        });
                    }
                });
            });
        }
    }, {
        key: "rm",
        value: function() {
            var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : "", r = arguments.length > 1 && void 0 !== arguments[1] && arguments[1];
            if ("string" != typeof e) throw new Error("key is typeof string at storage.rm");
            return new Promise(function(t, o) {
                "" === e ? r ? wx.clearStorage({
                    success: function() {
                        t({
                            errMsg: "clearStorage is okey"
                        });
                    }
                }) : (wx.clearStorageSync(), t({
                    errMsg: "clearStorage is okey"
                })) : r ? (wx.removeStorage(e.Trim()), t({
                    errMsg: "clearStorage is okey"
                })) : wx.removeStorage({
                    key: e.Trim(),
                    success: function() {
                        t({
                            errMsg: "clearStorage is okey"
                        });
                    }
                });
            });
        }
    } ]), t;
}();

String.prototype.Trim = String.prototype.Trim || function() {
    return this.replace(/(^\s*)|(\s*$)/g, "");
};

exports.default = new t();