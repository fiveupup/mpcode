var e = t(require("../config.js")), a = t(require("./crypto.js"));

function t(e) {
    return e && e.__esModule ? e : {
        default: e
    };
}

getApp();

module.exports = {
    getToken: function(t) {
        return wx.setStorageSync("isToken", !1), new Promise(function(n, s) {
            wx.request({
                url: e.default.TOP_HOST + "/api/OAuth2/Login",
                method: "POST",
                data: {
                    scope: "wxxcx",
                    username: t,
                    password: t
                },
                async: !1,
                header: {
                    "content-type": "application/x-www-form-urlencoded"
                },
                scriptCharset: "utf-8",
                success: function(e) {
                    if (e.data.DES && e.data.Data) {
                        e.data.data = e.data.Data;
                        try {
                            e.data.Data = JSON.parse(a.default.decrypt(e.data));
                        } catch (t) {
                            e.data.Data = a.default.decrypt(e.data);
                        }
                    }
                    if (200 == e.data.Code && e.data.Data.access_token) {
                        var t = "Bearer " + e.data.Data.access_token;
                        wx.setStorageSync("LoginToken", t);
                        var s = getCurrentPages(), o = s[s.length - 1];
                        o.route.indexOf("pages/study/study") > -1 ? (wx.switchTab({
                            url: "/pages/study/study"
                        }), o.onShow(o.options)) : o.route.indexOf("pages/index/index") > -1 ? (o.onShow(o.options), 
                        wx.switchTab({
                            url: "/pages/index/index"
                        })) : o.route.indexOf("pages/user/user") > -1 ? (o.onShow(o.options), wx.switchTab({
                            url: "/pages/user/user"
                        })) : o.route.indexOf("wenjuan/pages/UserInfo/UserInfo") > -1 || o.route.indexOf("pages/maintenance/maintenance") > -1 || o.route.indexOf("pages/pageLoading/pageLoading") > -1 ? wx.switchTab({
                            url: "/pages/study/study"
                        }) : (o.route.indexOf("pages/login"), o.onLoad(o.options)), n(e);
                    }
                }
            });
        });
    }
};