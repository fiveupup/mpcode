Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.Course = void 0;

var e, t = require("../@babel/runtime/helpers/objectSpread2"), u = require("../@babel/runtime/helpers/classCallCheck"), o = require("../@babel/runtime/helpers/createClass"), s = require("../@babel/runtime/helpers/inherits"), a = require("../@babel/runtime/helpers/createSuper"), r = (e = require("../utils/http.js")) && e.__esModule ? e : {
    default: e
};

exports.Course = function(e) {
    s(i, e);
    var r = a(i);
    function i() {
        return u(this, i), r.apply(this, arguments);
    }
    return o(i, [ {
        key: "checkQuestionInUserCourseList",
        value: function(e) {
            return this.request({
                url: "/api/Master/AutoModel",
                method: "POST",
                data: {
                    command: "checkQuestionInUserCourseList2",
                    data: JSON.stringify(e)
                }
            });
        }
    }, {
        key: "CheckQrcodeQuestionInZhenTiList",
        value: function(e) {
            return this.request({
                url: "/api/Master/AutoModel",
                method: "POST",
                data: {
                    command: "CheckQrcodeQuestionInZhenTiList2",
                    data: JSON.stringify(e)
                }
            });
        }
    }, {
        key: "addTopicInfoClickRecord",
        value: function(e) {
            return this.request({
                url: "/api/question_downs/Inner_question_downs",
                method: "POST",
                data: e
            });
        }
    }, {
        key: "GetBookListByStationID",
        value: function(e) {
            return this.request({
                url: "/api/Master/AutoModel",
                method: "POST",
                data: {
                    command: "GetBookListByStationID",
                    data: JSON.stringify({
                        System_Station_ID: getApp().globalData.SassID
                    })
                }
            });
        }
    }, {
        key: "GetQuestionDiscussListByQuestionID",
        value: function(e) {
            return this.request({
                url: "/api/Master/AutoModel",
                method: "POST",
                noLoading: !0,
                data: {
                    command: "GetQuestionDiscussListByQuestionID",
                    data: JSON.stringify({
                        QuestionID: e.QuestionID
                    })
                }
            });
        }
    }, {
        key: "GetQuestionDiscussInfoByID",
        value: function(e) {
            return this.request({
                url: "/api/Master/AutoModel",
                method: "POST",
                noLoading: !0,
                data: {
                    command: "GetQuestionDiscussInfoByID",
                    data: JSON.stringify({
                        ID: e.ID,
                        QuestionID: e.QuestionID
                    })
                }
            });
        }
    }, {
        key: "GetDiscussListByParentID",
        value: function(e) {
            return this.request({
                url: "/api/Master/AutoModel",
                method: "POST",
                noLoading: !0,
                data: {
                    command: "GetDiscussListByPID",
                    data: JSON.stringify({
                        QuestionID: e.QuestionID,
                        PID: e.PID
                    })
                }
            });
        }
    }, {
        key: "CreateDiscuss",
        value: function(e) {
            return this.request({
                url: "/api/question_discuss/Inner_question_discuss",
                method: "POST",
                data: {
                    QuestionID: e.QuestionID,
                    AddPerson: e.AddPerson,
                    StuID: e.StuID,
                    Txt: e.Txt,
                    Files: e.Files
                }
            });
        }
    }, {
        key: "SendDiscussCommnetMsg",
        value: function(e) {
            return this.request({
                url: "/api/wx/Xcx_MsgSend",
                method: "POST",
                data: {
                    wx_ID: 5,
                    openids: e.openid,
                    data: e.params,
                    templateId: getApp().globalData.appSubscribeText,
                    url: e.url,
                    Type: 1,
                    System_Station_ID: getApp().globalData.SassID
                }
            });
        }
    }, {
        key: "CreateDiscussCommnet",
        value: function(e) {
            return this.request({
                url: "/api/question_discuss/Inner_question_discuss",
                method: "POST",
                data: {
                    QuestionID: e.QuestionID,
                    AddPerson: e.AddPerson,
                    StuID: e.StuID,
                    Txt: e.Txt,
                    PID: e.PID
                }
            });
        }
    }, {
        key: "CreateDiscussCommnetReply",
        value: function(e) {
            return this.request({
                url: "/api/question_discuss/Inner_question_discuss",
                method: "POST",
                data: {
                    QuestionID: e.QuestionID,
                    AddPerson: e.AddPerson,
                    StuID: e.StuID,
                    Title: e.Reply,
                    Txt: e.Txt,
                    PID: e.PID
                }
            });
        }
    }, {
        key: "GetQuestionFirstByBookID",
        value: function(e) {
            return this.request({
                url: "/api/Master/AutoModel",
                method: "POST",
                noLoading: !0,
                data: {
                    command: "GetQuestionFirstByBookID1",
                    data: JSON.stringify({
                        BookID: e.BookID
                    })
                }
            });
        }
    }, {
        key: "GetUserCourseDetailInfo",
        value: function(e) {
            return this.request({
                url: "/api/Master/AutoModel",
                method: "POST",
                noLoading: !0,
                data: {
                    command: "GetUserCourseDetailInfo",
                    data: JSON.stringify({
                        StuID: e.StuID,
                        CourseID: e.CourseID
                    })
                }
            });
        }
    }, {
        key: "getUserCourseDetailInfoAndCourseDetailCount",
        value: function(e) {
            return this.request({
                url: "/api/course_users/GetUserProgress",
                method: "GET",
                data: {
                    QuestionID: e.QuestionID,
                    StuID: e.StuID,
                    CourseID: e.CourseID
                }
            });
        }
    }, {
        key: "GetTopicInfoByQrcode",
        value: function(e) {
            return this.request({
                url: "/api/Master/AutoModel",
                method: "POST",
                data: {
                    command: "GetTopicInfoByQrcode",
                    data: JSON.stringify({
                        qrcode: e.qrcode
                    })
                }
            });
        }
    }, {
        key: "GetCourseQrcodeInfo",
        value: function(e) {
            return this.request({
                url: "/api/Master/AutoModel",
                method: "POST",
                noLoading: !0,
                data: {
                    command: "GetCourseQrcodeInfo",
                    data: JSON.stringify({
                        qrcode: e.qrcode
                    })
                }
            });
        }
    }, {
        key: "GetCourseDetailIDBySetDay",
        value: function(e) {
            return this.request({
                url: "/api/question_tests/GetCourseDetailIDBySetDay",
                method: "GET",
                noLoading: !0,
                data: {
                    StuiD: e.StuID,
                    DetailQuestionID: e.DetailQuestionID,
                    CourseID: e.CourseID
                }
            });
        }
    }, {
        key: "updateSearchResult",
        value: function(e) {
            return this.request({
                url: "/api/question_photo_log/Inner_question_photo_log",
                method: "POST",
                data: e
            });
        }
    }, {
        key: "addSearchResult",
        value: function(e) {
            return this.request({
                url: "/api/question_photo_log/Inner_question_photo_log",
                method: "POST",
                data: {
                    StuID: e.StuID,
                    ImageUrl: e.ImageUrl,
                    Result: e.Result,
                    Score: e.Score,
                    AddPerson: "考研数学小程序"
                }
            });
        }
    }, {
        key: "GetQuestionListBySearch",
        value: function(e) {
            return this.request({
                url: "/api/question_list/GetListByPage",
                data: e
            });
        }
    }, {
        key: "GetQuestionSearchPhotoList",
        value: function(e) {
            return this.request({
                url: "/api/question_search_photo/GetListByPage",
                data: e
            });
        }
    }, {
        key: "GetBookListBySearchQuestion",
        value: function(e) {
            return this.request({
                url: "/api/Master/AutoModel",
                method: "POST",
                data: {
                    command: "GetBookListBySearchQuestion",
                    data: JSON.stringify(e)
                }
            });
        }
    }, {
        key: "GetPaperListBySearchQuestion",
        value: function(e) {
            return this.request({
                url: "/api/Master/AutoModel",
                method: "POST",
                data: {
                    command: "GetPaperListBySearchQuestion",
                    data: JSON.stringify(e)
                }
            });
        }
    }, {
        key: "GetSearchQuestionList",
        value: function(e) {
            return this.request({
                url: "/api/question_list/GetSearchQuestionList",
                data: e
            });
        }
    }, {
        key: "GetQuestionInfo",
        value: function(e) {
            return this.request({
                url: "/api/question_list/GetListByPage",
                data: t(t({}, e), {}, {
                    page: 1,
                    limit: 50
                })
            });
        }
    }, {
        key: "GetQuestionInfoNew",
        value: function(e) {
            return this.request({
                url: "/api/question_list/GetQuestionByQuestionNew",
                data: t({}, e)
            });
        }
    }, {
        key: "GetQuestionNexts",
        value: function(e) {
            return this.request({
                url: "/api/Master/AutoModel",
                method: "POST",
                data: {
                    command: "GetQuestionNexts1",
                    data: JSON.stringify(e)
                }
            });
        }
    }, {
        key: "GetQuestionNexts2",
        value: function(e) {
            return this.request({
                url: "/api/Master/AutoModel",
                method: "POST",
                data: {
                    command: "GetQuestionNexts2",
                    data: JSON.stringify(e)
                }
            });
        }
    }, {
        key: "GetUserRecordCatalog",
        value: function(e) {
            return this.request({
                url: "/api/Master/AutoModel",
                method: "POST",
                data: {
                    command: "GetUserRecordCatalog",
                    data: JSON.stringify(e)
                }
            });
        }
    }, {
        key: "GetBookList",
        value: function(e) {
            return this.request({
                url: "/api/book_list/GetListByPage",
                data: e,
                noLoading: !0
            });
        }
    }, {
        key: "GetBookListOfVip",
        value: function(e) {
            return this.request({
                url: "/api/Master/AutoModel",
                method: "POST",
                data: {
                    command: "GetBookListOfVip",
                    data: JSON.stringify(e)
                }
            });
        }
    }, {
        key: "GetPaperListOfVip",
        value: function(e) {
            return this.request({
                url: "/api/Master/AutoModel",
                method: "POST",
                data: {
                    command: "GetPaperListBySort",
                    data: JSON.stringify(e)
                }
            });
        }
    }, {
        key: "GetBookChapterList",
        value: function(e) {
            return this.request({
                url: "/api/Master/AutoModel",
                method: "POST",
                noLoading: !0,
                data: {
                    command: "GetBookChapterList",
                    data: JSON.stringify({
                        BookID: e.BookID
                    })
                }
            });
        }
    }, {
        key: "GetQuestionFiles",
        value: function(e) {
            return this.request({
                url: "/api/question_files/GetListByAll",
                data: e
            });
        }
    }, {
        key: "GetBookConfig",
        value: function(e) {
            return this.request({
                url: "/api/book_list_conf/GetListByPage",
                data: e
            });
        }
    }, {
        key: "SetSearchPhotoLog",
        value: function(e) {
            return this.request({
                url: "/api/question_search_photo/Inner_question_search_photo",
                method: "POST",
                data: e
            });
        }
    }, {
        key: "GetPhotoQuestionInfo",
        value: function(e) {
            return this.request({
                url: "/api/question_search_photo/SearchPhotoKey",
                method: "POST",
                data: e
            });
        }
    }, {
        key: "GetPhotoQuestionInfo2",
        value: function(e) {
            return this.request({
                url: "/api/question_search_photo/SearchPhotoKey2",
                method: "POST",
                data: e
            });
        }
    }, {
        key: "GetPhotoGetBookByAll",
        value: function(e) {
            return this.request({
                url: "/api/question_search_photo/GetBookByAll",
                method: "POST",
                data: e
            });
        }
    }, {
        key: "GetPhotoGetBookByID",
        value: function(e) {
            return this.request({
                url: "/api/question_search_photo/GetBookByID",
                method: "POST",
                data: e
            });
        }
    }, {
        key: "GetVideoAdsInfo",
        value: function(e) {
            return this.request({
                url: "/api/sys_user_links/GetVideo",
                data: e,
                noLoading: !0
            });
        }
    }, {
        key: "GetCoursePacketInfo",
        value: function(e) {
            return this.request({
                url: "/api/c_course_packet/GetListByPage",
                data: e
            });
        }
    }, {
        key: "GetPacketList",
        value: function(e) {
            return this.request({
                url: "/api/c_course_packet/GetPacketList",
                data: e
            });
        }
    }, {
        key: "GetPacketByPaperList",
        value: function(e) {
            return this.request({
                url: "/api/c_course_packet/GetPacketByPaperList",
                data: e
            });
        }
    }, {
        key: "GetPacketChapterList",
        value: function(e) {
            return this.request({
                url: "/api/c_course_packet/GetPacket",
                data: e
            });
        }
    }, {
        key: "GetPacketChapterList2",
        value: function(e) {
            return this.request({
                url: "/api/c_course_packet/GetPacket2",
                data: e
            });
        }
    }, {
        key: "GetCoursePacketList",
        value: function(e) {
            return this.request({
                url: "/api/Master/AutoModel",
                method: "POST",
                noLoading: !0,
                data: {
                    command: "GetCoursePacketList",
                    data: JSON.stringify({
                        CoursePacketID: e.CoursePacketID,
                        ProductID: e.ProductID
                    })
                }
            });
        }
    }, {
        key: "GetCoursePacketLastStudy",
        value: function(e) {
            return this.request({
                url: "/api/Master/AutoModel",
                method: "POST",
                noLoading: !0,
                data: {
                    command: "GetCoursePacketLastStudy",
                    data: JSON.stringify({
                        CoursePacketID: e.CoursePacketID,
                        ProductID: e.ProductID,
                        StuID: e.StuID
                    })
                }
            });
        }
    } ]), i;
}(r.default);