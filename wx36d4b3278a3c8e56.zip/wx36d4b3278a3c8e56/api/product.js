Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.Product = void 0;

var e = require("../@babel/runtime/helpers/objectSpread2"), t = require("../@babel/runtime/helpers/classCallCheck"), r = require("../@babel/runtime/helpers/createClass"), u = require("../@babel/runtime/helpers/inherits"), a = require("../@babel/runtime/helpers/createSuper"), s = o(require("../utils/http.js"));

o(require("../utils/util.js"));

function o(e) {
    return e && e.__esModule ? e : {
        default: e
    };
}

getApp(), exports.Product = function(s) {
    u(i, s);
    var o = a(i);
    function i() {
        return t(this, i), o.apply(this, arguments);
    }
    return r(i, [ {
        key: "AddSysError",
        value: function(e) {
            return this.request({
                url: "/api/sys_error/Inner_sys_error",
                data: e,
                method: "POST"
            });
        }
    }, {
        key: "GetQuestionOtherInfoNew",
        value: function(e) {
            return this.request({
                url: "/api/question_list/GetQuestionByIDSoleDes",
                data: e
            });
        }
    }, {
        key: "GetVipPayList",
        value: function(e) {
            return this.request({
                url: "/api/c_course_product/GetListByPageToVip",
                data: e
            });
        }
    }, {
        key: "GetCouponsInfo",
        value: function(e) {
            return this.request({
                url: "/api/couponcard_study/GetListByPage",
                data: e
            });
        }
    }, {
        key: "GetCoupoActivationCodensInfo",
        value: function(e) {
            return this.request({
                url: "/api/couponcard_study/ActivationCode",
                data: e,
                method: "POST"
            });
        }
    }, {
        key: "GetActivationCodeStudyInfo",
        value: function(e) {
            return this.request({
                url: "/api/couponcard_study/ActivationCodeStudy",
                data: e,
                method: "POST"
            });
        }
    }, {
        key: "AddCoupons",
        value: function(e) {
            return this.request({
                url: "/api/couponcard_study/Inner_couponcard_study",
                data: e,
                method: "POST"
            });
        }
    }, {
        key: "GetUserByProductCourseWare",
        value: function(e) {
            return this.request({
                url: "/api/Master/AutoModel",
                method: "POST",
                data: {
                    command: "GetUserByProductCourseWare",
                    data: JSON.stringify(e)
                }
            });
        }
    }, {
        key: "GetCourseInfo",
        value: function(e) {
            return this.request({
                url: "/api/c_course_list/GetListByPage",
                data: e
            });
        }
    }, {
        key: "GetCoursebyStuID",
        value: function(e) {
            return this.request({
                url: "/api/c_course_list/GetCoursebyStuID",
                data: e
            });
        }
    }, {
        key: "GetCourseListAll",
        value: function(e) {
            return this.request({
                url: "/api/c_course_list/GetCourseListAll",
                data: e
            });
        }
    }, {
        key: "addCalendarProgress",
        value: function(e) {
            return this.request({
                method: "POST",
                url: "/api/c_course_users_progress/Inner_c_course_users_progress",
                data: e
            });
        }
    }, {
        key: "GetProductLastTimeLog",
        value: function(e) {
            return this.request({
                url: "/api/Master/AutoModel",
                method: "POST",
                data: {
                    command: "GetProductLastTimeLog",
                    data: JSON.stringify(e)
                }
            });
        }
    }, {
        key: "GetCalendarDetailList",
        value: function(e) {
            return this.request({
                url: "/api/c_course_list/GetCalendarDetailList2",
                data: e
            });
        }
    }, {
        key: "GetUsersRecord",
        value: function(e) {
            return this.request({
                url: "/api/c_course_users_record/GetListByAll",
                data: e
            });
        }
    }, {
        key: "AddUsersRecord",
        value: function(e) {
            return this.request({
                url: "/api/c_course_users_record/Inner_c_course_users_record",
                method: "POST",
                data: e
            });
        }
    }, {
        key: "DelsUsersRecord",
        value: function(e) {
            return this.request({
                url: "/api/c_course_users_record/Dels_c_course_users_record",
                method: "POST",
                data: e
            });
        }
    }, {
        key: "GetQuestionOtherInfo",
        value: function(e) {
            return this.request({
                url: "/api/question_list/GetQuestionByID",
                data: e
            });
        }
    }, {
        key: "GetUserRecordAll",
        value: function(e) {
            return this.request({
                url: "/api/sys_user_record/GetListByStuid",
                data: e
            });
        }
    }, {
        key: "GetQuestionMark",
        value: function(e) {
            return this.request({
                url: "/api/sys_user_record/GetListByAll",
                data: e
            });
        }
    }, {
        key: "GetUsersNotesCountByType",
        value: function(e) {
            return this.request({
                url: "/api/Master/AutoModel",
                method: "POST",
                data: {
                    command: "GetUsersNotesCountByType",
                    data: JSON.stringify(e)
                }
            });
        }
    }, {
        key: "GetUserRecordListType",
        value: function(e) {
            return this.request({
                url: "/api/Master/AutoModel",
                method: "POST",
                data: {
                    command: "GetUserRecordListType",
                    data: JSON.stringify(e)
                }
            });
        }
    }, {
        key: "AddQuestionMark",
        value: function(e) {
            return this.request({
                url: "/api/sys_user_record/Inner_sys_user_record",
                method: "POST",
                data: e
            });
        }
    }, {
        key: "DelQuestionMark",
        value: function(e) {
            return this.request({
                url: "/api/sys_user_record/Del_sys_user_record",
                method: "POST",
                data: e
            });
        }
    }, {
        key: "GetQuestionExamByStuID",
        value: function(e) {
            return this.request({
                url: "/api/c_course_list/GetQuestionExamByStuID",
                data: e
            });
        }
    }, {
        key: "GetQuestionExamByStuIDList",
        value: function(e) {
            return this.request({
                url: "/api/c_course_list/GetQuestionExamByStuIDList",
                data: e
            });
        }
    }, {
        key: "UnlockCalendarByStuID",
        value: function(e) {
            return this.request({
                url: "/api/c_course_calendar/UnlockCalendarByStuID",
                method: "POST",
                data: e,
                noLoading: !0
            });
        }
    }, {
        key: "GetCourseProductRecordCounts",
        value: function(e) {
            return this.request({
                url: "/api/Master/AutoModel",
                method: "POST",
                data: {
                    command: "GetCourseProductRecordCounts",
                    data: JSON.stringify(e)
                }
            });
        }
    }, {
        key: "GetVIPProduct",
        value: function(e) {
            return this.request({
                url: "/api/c_course_product/GetListByPage",
                data: e
            });
        }
    }, {
        key: "GetProductByStuID2",
        value: function(e) {
            return this.request({
                url: "/api/c_course_product/GetProductByStuID2",
                data: e
            });
        }
    }, {
        key: "GetProductByStuID",
        value: function(e) {
            return this.request({
                url: "/api/c_course_product/GetProductByStuID",
                data: e
            });
        }
    }, {
        key: "GetProductByStuIDAndProductID",
        value: function(e) {
            return this.request({
                url: "/api/c_course_product/GetProductByStuIDAndProductID",
                data: e
            });
        }
    }, {
        key: "VIPProductByStuid",
        value: function(e) {
            return this.request({
                url: "/api/c_course_product/VIPProductByStuid",
                method: "POST",
                data: e,
                noLoading: !0
            });
        }
    }, {
        key: "UnifiedOrderAndGetJsApiPara",
        value: function(e) {
            return this.request({
                url: "/api/wxpay/UnifiedOrderAndGetJsApiPara",
                data: e,
                method: "POST"
            });
        }
    }, {
        key: "GetPaperRecordCounts",
        value: function(e) {
            return this.request({
                url: "/api/Master/AutoModel",
                method: "POST",
                data: {
                    command: "GetPaperRecordCounts",
                    data: JSON.stringify(e)
                }
            });
        }
    }, {
        key: "GetCourseCalendarDetail",
        value: function(e) {
            return this.request({
                url: "/api/c_course_calendar_detail/GetListByAll",
                data: e
            });
        }
    }, {
        key: "GetPaperInfo",
        value: function(e) {
            return this.request({
                url: "/api/c_paper/GetListByAll",
                data: e
            });
        }
    }, {
        key: "GetPaperQuestionList",
        value: function(e) {
            return this.request({
                url: "/api/c_paper_question/GetListByAll",
                data: e
            });
        }
    }, {
        key: "GetUserPaperInfo",
        value: function(e) {
            return this.request({
                url: "/api/c_course_list/GetUserPaperInfo",
                data: e
            });
        }
    }, {
        key: "GetHeadImg",
        value: function(e) {
            return this.request({
                url: "/api/headimg_list/GetListByAll",
                data: e,
                noLoading: !0
            });
        }
    }, {
        key: "GetHeadImgPage",
        value: function(e) {
            return this.request({
                url: "/api/headimg_list/GetListByPage",
                data: e,
                noLoading: !0
            });
        }
    }, {
        key: "GetPaperQuestionInfo",
        value: function(e) {
            return this.request({
                url: "/api/c_paper_question/GetListByPaper2",
                data: e
            });
        }
    }, {
        key: "GetListByStudentPaper",
        value: function(t) {
            return this.request({
                url: "/api/c_paper_question/GetListByStudentPaper",
                data: e(e({}, t), {}, {
                    page: 0,
                    limit: 1e3
                })
            });
        }
    }, {
        key: "Inner_c_paper_student_record",
        value: function(e) {
            return this.request({
                url: "/api/c_paper_student_record/Inner_c_paper_student_record",
                method: "POST",
                data: e
            });
        }
    }, {
        key: "Inner_c_paper_student_recordAll",
        value: function(e) {
            return this.request({
                url: "/api/c_paper_student_record/InnerAll_c_paper_student_record",
                method: "POST",
                data: e
            });
        }
    }, {
        key: "Inner_c_paper_student",
        value: function(e) {
            return this.request({
                url: "/api/c_paper_student/Inner_c_paper_student",
                method: "POST",
                data: e
            });
        }
    }, {
        key: "GetStudentPaper",
        value: function(e) {
            return this.request({
                url: "/api/c_paper_student/GetListByAll",
                data: e
            });
        }
    }, {
        key: "GetStudentQuestionGroups",
        value: function(t) {
            return this.request({
                url: "/api/question_groups/GetListByPage",
                data: e(e({}, t), {}, {
                    SortDesc: "Sort"
                })
            });
        }
    }, {
        key: "GetUserRecordPaperQuestionList",
        value: function(e) {
            var t = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : 1;
            return this.request({
                url: "/api/Master/AutoModel",
                data: {
                    command: 1 == t ? "GetUserRecordPaperQuestionList" : "GetUserRecordPaperQuestionListBySchool",
                    data: JSON.stringify(e)
                },
                method: "POST"
            });
        }
    }, {
        key: "RelPaperByStuID",
        value: function(e) {
            return this.request({
                url: "/api/c_paper/RelPaperByStuID",
                method: "POST",
                data: e
            });
        }
    }, {
        key: "RelPaperByStuID1",
        value: function(e) {
            return this.request({
                url: "/api/c_paper/RelPaperByStuID1",
                method: "POST",
                data: e
            });
        }
    }, {
        key: "GetUserPaperList",
        value: function(e) {
            return this.request({
                url: "/api/c_paper/GetUserPaperList2",
                data: e
            });
        }
    }, {
        key: "Inner_c_course_users",
        value: function(e) {
            return this.request({
                url: "/api/c_course_users/Inner_c_course_users",
                method: "POST",
                data: e
            });
        }
    }, {
        key: "Get_c_course_users",
        value: function(e) {
            return this.request({
                url: "/api/c_course_users/GetListByAll",
                data: e
            });
        }
    }, {
        key: "GetUserInfoByStuID",
        value: function(e) {
            return this.request({
                url: "/api/wx_users/GetListByAll",
                data: e
            });
        }
    }, {
        key: "GetSchoolAnalyseList",
        value: function(e) {
            return this.request({
                url: "/api/s_school/GetListByAll",
                data: e
            });
        }
    }, {
        key: "GetSchoolAnalyseFilesList",
        value: function(e) {
            return this.request({
                url: "/api/s_school_files/GetListByAll",
                data: e
            });
        }
    }, {
        key: "GetPaperScoreByList",
        value: function(e) {
            return this.request({
                url: "/api/Master/AutoModel",
                method: "POST",
                noLoading: !0,
                data: {
                    command: "GetPaperScoreByList",
                    data: JSON.stringify(e)
                }
            });
        }
    }, {
        key: "GetMarkPaperScoreByList",
        value: function(e) {
            return this.request({
                url: "/api/Master/AutoModel",
                method: "POST",
                noLoading: !0,
                data: {
                    command: "GetMarkPaperScoreByList",
                    data: JSON.stringify(e)
                }
            });
        }
    }, {
        key: "AddSysGive",
        value: function(e) {
            return this.request({
                url: "/api/sys_give/Inner_sys_give",
                method: "POST",
                data: e
            });
        }
    }, {
        key: "DelSysGive",
        value: function(e) {
            return this.request({
                url: "/api/sys_give/Del_sys_give",
                method: "POST",
                data: e
            });
        }
    }, {
        key: "GetSysGive",
        value: function(e) {
            return this.request({
                url: "/api/sys_give/GetListBypage",
                data: e
            });
        }
    }, {
        key: "GetMyInfoList",
        value: function(e) {
            return this.request({
                url: "/api/sys_msg_push/GetListByAll",
                data: e,
                noLoading: !0
            });
        }
    }, {
        key: "GetInfoList",
        value: function(e) {
            return this.request({
                url: "/api/sys_msg_push/GetListByPage",
                data: e
            });
        }
    }, {
        key: "SetInfoRead",
        value: function(e) {
            return this.request({
                url: "/api/sys_msg_push/UpdateIsReadState",
                method: "POST",
                data: e
            });
        }
    }, {
        key: "GetQuestionInfoByID",
        value: function(e) {
            return this.request({
                url: "/api/Master/AutoModel",
                method: "POST",
                noLoading: !0,
                data: {
                    command: "GetQuestionInfo",
                    data: JSON.stringify(e)
                }
            });
        }
    }, {
        key: "GetPaperQuestionLinkSortList",
        value: function(e) {
            return this.request({
                url: "/api/Master/AutoModel",
                method: "POST",
                noLoading: !0,
                data: {
                    command: "GetPaperQuestionLinkSortList",
                    data: JSON.stringify(e)
                }
            });
        }
    }, {
        key: "GetXcxRelQuestionMenu",
        value: function(e) {
            return this.request({
                url: "/api/Master/AutoModel",
                method: "POST",
                noLoading: !0,
                data: {
                    command: "GetRelQuestionMenu",
                    data: JSON.stringify(e)
                }
            });
        }
    }, {
        key: "GetRelQuestionByRid",
        value: function(e) {
            return this.request({
                url: "/api/rel_question_log/GetRelQuestionByRid",
                data: e,
                method: "POST"
            });
        }
    }, {
        key: "AddRelQuestionLog",
        value: function(e) {
            return this.request({
                url: "/api/rel_question_log/Inner_rel_question_log",
                data: e,
                method: "POST"
            });
        }
    }, {
        key: "GetRelQuestionList",
        value: function(e) {
            return this.request({
                url: "/api/rel_question_log/GetListByPage",
                data: e
            });
        }
    }, {
        key: "GetRelQuestionLog",
        value: function(e) {
            return this.request({
                url: "/api/rel_question_log/GetListByAll",
                data: e
            });
        }
    }, {
        key: "AddRelExerciseLog",
        value: function(e) {
            return this.request({
                url: "/api/rel_exercise_log/Inner_rel_exercise_log",
                data: e,
                method: "POST"
            });
        }
    }, {
        key: "GetExamineList",
        value: function(e) {
            return this.request({
                url: "/api/examine_student_paper/GetListByPage",
                data: e
            });
        }
    }, {
        key: "GetExamineListByAllByPaper",
        value: function(e) {
            return this.request({
                url: "/api/examine_student_result/GetListByAllByPaper",
                data: e
            });
        }
    }, {
        key: "AddExamineStudentResult",
        value: function(e) {
            return this.request({
                url: "/api/examine_student_result/Inner_examine_student_result",
                data: e,
                method: "POST"
            });
        }
    }, {
        key: "GetQusetionExamine",
        value: function(t) {
            return this.request({
                url: "/api/examine_student_result/GetListByAll",
                data: e({}, t)
            });
        }
    }, {
        key: "Inner_c_course_product_log",
        value: function(e) {
            return this.request({
                url: "/api/c_course_product_log/Inner_c_course_product_log2",
                data: e,
                method: "POST",
                noLoading: !0
            });
        }
    }, {
        key: "GetStuCourseProductLog",
        value: function(e) {
            return this.request({
                url: "/api/c_course_product_log/GetListByPage",
                data: e
            });
        }
    }, {
        key: "ActCode",
        value: function(e) {
            return this.request({
                url: "/api/sys_users_isact/ActCode",
                data: e,
                method: "POST"
            });
        }
    }, {
        key: "GetVipLookQuestionCount",
        value: function(e) {
            return this.request({
                url: "/api/question_look_count/GetListByPage",
                data: e
            });
        }
    }, {
        key: "SetVipLookQuestionCount",
        value: function(e) {
            return this.request({
                url: "/api/question_look_count/Inner_question_look_count",
                data: e,
                method: "POST"
            });
        }
    }, {
        key: "GetMonligtedTeacherList",
        value: function(e) {
            return this.request({
                url: "/api/question_teachers/GetListByPage",
                data: e
            });
        }
    }, {
        key: "GetUserPullNewActive",
        value: function(e) {
            return this.request({
                url: "/api/pull_new/GetUserPullNewActive",
                data: e
            });
        }
    }, {
        key: "GetPullNewInfo",
        value: function(e) {
            return this.request({
                url: "/api/pull_new/GetListByPage",
                data: e
            });
        }
    }, {
        key: "GetUersPullNewLog",
        value: function(e) {
            return this.request({
                url: "/api/pull_new_log/GetListByPage",
                data: e
            });
        }
    }, {
        key: "GetPullNewLogListByStuID",
        value: function(e) {
            return this.request({
                url: "/api/Master/AutoModel",
                method: "POST",
                noLoading: !1,
                data: {
                    command: "GetPullNewLogListByStuID",
                    data: JSON.stringify(e)
                }
            });
        }
    }, {
        key: "GetPullNuwLogStudentList",
        value: function(e) {
            return this.request({
                url: "/api/Master/AutoModel",
                method: "POST",
                noLoading: !1,
                data: {
                    command: "GetPullNuwLogStudentList1",
                    data: JSON.stringify(e)
                }
            });
        }
    }, {
        key: "GetUserPullNewIsFinish",
        value: function(e) {
            return this.request({
                url: "/api/Master/AutoModel",
                method: "POST",
                noLoading: !1,
                data: {
                    command: "GetUserPullNewIsFinish",
                    data: JSON.stringify(e)
                }
            });
        }
    }, {
        key: "SetPullNewLog",
        value: function(e) {
            return this.request({
                url: "/api/pull_new_log/Inner_pull_new_log",
                data: e,
                method: "POST"
            });
        }
    }, {
        key: "GetUserPullNewStuIDList",
        value: function(e) {
            return this.request({
                url: "/api/Master/AutoModel",
                method: "POST",
                noLoading: !1,
                data: {
                    command: "GetUserPullNewStuIDList",
                    data: JSON.stringify(e)
                }
            });
        }
    }, {
        key: "GetUserIsPullNewLog",
        value: function(e) {
            return this.request({
                url: "/api/Master/AutoModel",
                method: "POST",
                noLoading: !0,
                data: {
                    command: "GetUserIsPullNewLog",
                    data: JSON.stringify(e)
                }
            });
        }
    }, {
        key: "AddQuestionExtrapolationLog",
        value: function(e) {
            return this.request({
                url: "/api/quesiton_extrapolation_log/Inner_quesiton_extrapolation_log",
                data: e,
                method: "POST"
            });
        }
    }, {
        key: "GetQuestionExtrapolationList",
        value: function(e) {
            return this.request({
                url: "/api/quesiton_extrapolation_log/GetQuestionPush",
                data: e
            });
        }
    }, {
        key: "GetExtrapolationQuestionLogInfo",
        value: function(e) {
            return this.request({
                url: "/api/quesiton_extrapolation_log/GetListByPage",
                data: e
            });
        }
    }, {
        key: "GetSysUsersFiles",
        value: function(e) {
            return this.request({
                url: "/api/sys_users_files/GetListByPage2",
                data: e
            });
        }
    }, {
        key: "GetWeekLoginUserCount",
        value: function(e) {
            return this.request({
                url: "/api/Master/AutoModel",
                method: "POST",
                noLoading: !0,
                data: {
                    command: "GetWeekLoginUserCount",
                    data: JSON.stringify(e)
                }
            });
        }
    }, {
        key: "GetQuestionRightCountByPaper",
        value: function(e) {
            return this.request({
                url: "/api/Master/AutoModel",
                method: "POST",
                data: {
                    command: "GetQuestionRightCountByPaper",
                    data: JSON.stringify(e)
                }
            });
        }
    }, {
        key: "GetQuestionRightCountByPaper1",
        value: function(e) {
            return this.request({
                url: "/api/Master/AutoModel",
                method: "POST",
                data: {
                    command: "GetQuestionRightCountByPaper1",
                    data: JSON.stringify(e)
                }
            });
        }
    }, {
        key: "GetMyPaperScoreRanking",
        value: function(e) {
            return this.request({
                url: "/api/Master/AutoModel",
                method: "POST",
                data: {
                    command: "GetMyPaperScoreRanking",
                    data: JSON.stringify(e)
                }
            });
        }
    }, {
        key: "GetMyMarkPaperScoreRanking",
        value: function(e) {
            return this.request({
                url: "/api/Master/AutoModel",
                method: "POST",
                data: {
                    command: "GetMyMarkPaperScoreRanking",
                    data: JSON.stringify(e)
                }
            });
        }
    }, {
        key: "GetLeakFillingStatistics1",
        value: function(e) {
            return this.request({
                url: "/api/Master/AutoModel",
                method: "POST",
                data: {
                    command: "GetLeakFillingStatistics1",
                    data: JSON.stringify(e)
                }
            });
        }
    }, {
        key: "GetLeakFillingStatistics2",
        value: function(e) {
            return this.request({
                url: "/api/Master/AutoModel",
                method: "POST",
                data: {
                    command: "GetLeakFillingStatistics2",
                    data: JSON.stringify(e)
                }
            });
        }
    }, {
        key: "GetLeadFillingModelList",
        value: function(e) {
            return this.request({
                url: "/api/Master/AutoModel",
                method: "POST",
                data: {
                    command: "GetLeadFillingModelList",
                    data: JSON.stringify(e)
                }
            });
        }
    }, {
        key: "GetLeadFillCalendarInfo",
        value: function(e) {
            return this.request({
                url: "/api/Master/AutoModel",
                method: "POST",
                data: {
                    command: "GetLeadFillCalendarInfo",
                    data: JSON.stringify(e)
                }
            });
        }
    }, {
        key: "GetLeakFillingRecommend",
        value: function(e) {
            return this.request({
                url: "/api/c_paper_student_recommend/GetListByAll",
                data: e
            });
        }
    }, {
        key: "AddLeakFillingRecommend",
        value: function(e) {
            return this.request({
                url: "/api/c_paper_student_recommend/Inner_c_paper_student_recommend",
                data: e,
                method: "POST"
            });
        }
    }, {
        key: "UpdateColumnsAllLeakFillingRecommend",
        value: function(e) {
            return this.request({
                url: "/api/c_paper_student_recommend/InnerAll_c_paper_student_recommend",
                data: e,
                method: "POST"
            });
        }
    }, {
        key: "GetProductAllList",
        value: function(e) {
            return this.request({
                url: "/api/Master/AutoModel",
                method: "POST",
                data: {
                    command: "GetProductAllList",
                    data: JSON.stringify(e)
                }
            });
        }
    }, {
        key: "GetCourseThrillerPaperList",
        value: function(e) {
            return this.request({
                url: "/api/Master/AutoModel",
                method: "POST",
                data: {
                    command: "GetCourseThrillerPaperList",
                    data: JSON.stringify(e)
                }
            });
        }
    }, {
        key: "GetSpecialVideoListBySpecialID",
        value: function(e) {
            return this.request({
                url: "/api/Master/AutoModel",
                method: "POST",
                data: {
                    command: "GetSpecialVideoListBySpecialID",
                    data: JSON.stringify(e)
                }
            });
        }
    }, {
        key: "RelPaperByStuBySpecial",
        value: function(e) {
            return this.request({
                url: "/api/c_paper/RelPaperByStuBySpecial2",
                method: "POST",
                data: e
            });
        }
    }, {
        key: "GetUserExamLastScore",
        value: function(e) {
            return this.request({
                url: "/api/Master/AutoModel",
                method: "POST",
                data: {
                    command: "GetUserExamLastScore",
                    data: JSON.stringify(e)
                }
            });
        }
    }, {
        key: "GetPaperPastPerformance",
        value: function(e) {
            return this.request({
                url: "/api/Master/AutoModel",
                method: "POST",
                data: {
                    command: "GetPaperPastPerformance",
                    data: JSON.stringify(e)
                }
            });
        }
    }, {
        key: "GetPaperScourByWxApp",
        value: function(e) {
            return this.request({
                url: "/api/Master/AutoModel",
                method: "POST",
                data: {
                    command: "GetPaperScourByWxApp",
                    data: JSON.stringify(e)
                }
            });
        }
    }, {
        key: "GetPaperExamLastByWxApp",
        value: function(e) {
            return this.request({
                url: "/api/Master/AutoModel",
                method: "POST",
                data: {
                    command: "GetPaperExamLastByWxApp",
                    data: JSON.stringify(e)
                }
            });
        }
    }, {
        key: "GetCourseOrderInfo",
        value: function(e) {
            return this.request({
                url: "/api/c_course_order/GetListByPage",
                data: e
            });
        }
    }, {
        key: "SetCourseOrder",
        value: function(e) {
            return this.request({
                url: "/api/c_course_order/Inner_c_course_order",
                data: e,
                method: "POST"
            });
        }
    }, {
        key: "SetHeadImgLog",
        value: function(e) {
            return this.request({
                url: "/api/headimg_list_log/Inner_headimg_list_log",
                data: e,
                method: "POST",
                noLoading: !1
            });
        }
    }, {
        key: "SetHeadImgLog2",
        value: function(e) {
            return this.request({
                url: "/api/headimg_list_log/Inner_headimg_list_log",
                data: e,
                method: "POST",
                noLoading: !1
            });
        }
    }, {
        key: "choiceRelPaper",
        value: function(e) {
            return this.request({
                url: "/api/choice_question_exercise/RelPaper",
                data: e,
                method: "POST"
            });
        }
    }, {
        key: "DelChoiceQuestion",
        value: function(e) {
            return this.request({
                url: "/api/choice_question_exercise_log/DelChoiceQuestionByStuID",
                data: e,
                method: "POST"
            });
        }
    }, {
        key: "choiceGetPaperQuestion",
        value: function(e) {
            return this.request({
                url: "/api/choice_question_exercise/GetPaper",
                data: e
            });
        }
    }, {
        key: "choiceSubmitAnswer",
        value: function(e) {
            return this.request({
                url: "/api/choice_question_exercise_log/Inner_choice_question_exercise_log",
                data: e,
                method: "POST"
            });
        }
    }, {
        key: "choiceSubmitPaper",
        value: function(e) {
            return this.request({
                url: "/api/choice_question_exercise/Inner_choice_question_exercise",
                data: e,
                method: "POST"
            });
        }
    }, {
        key: "GetCataLogListByStuIDAndCode",
        value: function(e) {
            return this.request({
                url: "/api/Master/AutoModel",
                method: "POST",
                data: {
                    command: "GetCataLogListByStuIDAndCode",
                    data: JSON.stringify(e)
                }
            });
        }
    }, {
        key: "GetCatalogHistoryList",
        value: function(e) {
            return this.request({
                url: "/api/Master/AutoModel",
                method: "POST",
                data: {
                    command: "GetCatalogHistoryList",
                    data: JSON.stringify(e)
                }
            });
        }
    }, {
        key: "RelPaperByCJZT",
        value: function(e) {
            return this.request({
                url: "/api/c_paper/RelPaperByCJZT",
                method: "POST",
                data: e
            });
        }
    }, {
        key: "RelPaperByStuIDCJZT",
        value: function(e) {
            return this.request({
                url: "/api/c_paper/RelPaperByStuIDCJZT",
                method: "POST",
                data: e
            });
        }
    }, {
        key: "GetSuperPaperQuestionList",
        value: function(e) {
            return this.request({
                url: "/api/Master/AutoModel",
                method: "POST",
                data: {
                    command: "GetSuperPaperQuestionList",
                    data: JSON.stringify(e)
                }
            });
        }
    }, {
        key: "GetSuperSpecialList",
        value: function(e) {
            return this.request({
                url: "/api/Master/AutoModel",
                method: "POST",
                data: {
                    command: "GetSuperSpecialList",
                    data: JSON.stringify(e)
                }
            });
        }
    }, {
        key: "GetUserPayFirstVipList",
        value: function(e) {
            return this.request({
                url: "/api/Master/AutoModel",
                method: "POST",
                data: {
                    command: "GetUserPayFirstVipList",
                    data: JSON.stringify(e)
                }
            });
        }
    }, {
        key: "checkUserSearch",
        value: function(e) {
            return this.request({
                url: "/api/Master/AutoModel",
                method: "POST",
                data: {
                    command: "checkUserSearch",
                    data: JSON.stringify(e)
                }
            });
        }
    }, {
        key: "InActByID",
        value: function(e) {
            return this.request({
                url: "/api/couponcard/InActByID",
                method: "POST",
                data: e
            });
        }
    }, {
        key: "GetlistByCache",
        value: function(e) {
            return this.request({
                url: "/api/book_highscorealbum_catalog/GetlistByCache",
                data: e
            });
        }
    }, {
        key: "GetlistByCache2",
        value: function(e) {
            return this.request({
                url: "/api/book_highscorealbum_catalog/GetlistByCache2",
                data: e
            });
        }
    }, {
        key: "GetHighscorealbumQuestionList",
        value: function(e) {
            return this.request({
                url: "/api/Master/AutoModel",
                method: "POST",
                data: {
                    command: "GetHighscorealbumQuestionList",
                    data: JSON.stringify(e)
                }
            });
        }
    }, {
        key: "GetHighscorealbumQuestionListByCourse",
        value: function(e) {
            return this.request({
                url: "/api/Master/AutoModel",
                method: "POST",
                data: {
                    command: "GetHighscorealbumQuestionListByCourse",
                    data: JSON.stringify(e)
                }
            });
        }
    }, {
        key: "GetHighscorealbumStudylog",
        value: function(e) {
            return this.request({
                url: "/api/book_highscorealbum_studylog/GetListByPage",
                data: e
            });
        }
    }, {
        key: "AddHighscorealbumStudylog",
        value: function(e) {
            return this.request({
                url: "/api/book_highscorealbum_studylog/Inner_book_highscorealbum_studylog",
                method: "POST",
                data: e
            });
        }
    }, {
        key: "DelHighscorealbumStudylog",
        value: function(e) {
            return this.request({
                url: "/api/book_highscorealbum_studylog/Del_book_highscorealbum_studylog",
                method: "POST",
                data: e
            });
        }
    }, {
        key: "GetHighscorealbumCatalogList",
        value: function(e) {
            return this.request({
                url: "/api/book_highscorealbum_catalog/GetListByPage",
                data: e
            });
        }
    }, {
        key: "GetModelAblumQuestionList",
        value: function(e) {
            return this.request({
                url: "/api/Master/AutoModel",
                method: "POST",
                data: {
                    command: "GetModelAblumQuestionList",
                    data: JSON.stringify(e)
                }
            });
        }
    }, {
        key: "GetLeadFillModelAblumQuestionList",
        value: function(e) {
            return this.request({
                url: "/api/Master/AutoModel",
                method: "POST",
                data: {
                    command: "GetLeadFillModelAblumQuestionList",
                    data: JSON.stringify(e)
                }
            });
        }
    }, {
        key: "GetHighscorealbumGive",
        value: function(e) {
            return this.request({
                url: "/api/Master/AutoModel",
                method: "POST",
                data: {
                    command: "GetHighscorealbumGive",
                    data: JSON.stringify(e)
                }
            });
        }
    }, {
        key: "GetAlbumList",
        value: function(e) {
            return this.request({
                url: "/api/book_highscorealbum/GetListByAll",
                data: e
            });
        }
    }, {
        key: "GetAlbumInfo",
        value: function(e) {
            return this.request({
                url: "/api/Master/AutoModel",
                method: "POST",
                data: {
                    command: "GetAlbumInfo",
                    data: JSON.stringify(e)
                }
            });
        }
    }, {
        key: "GetPaperQuestionResolveAndTypeList",
        value: function(e) {
            return this.request({
                url: "/api/Master/AutoModel",
                method: "POST",
                data: {
                    command: "GetPaperQuestionResolveAndTypeList",
                    data: JSON.stringify(e)
                }
            });
        }
    }, {
        key: "AddPaperUsersRecord",
        value: function(e) {
            return this.request({
                url: "/api/c_paper_users_record/Inner_c_paper_users_record",
                data: e,
                method: "POST"
            });
        }
    }, {
        key: "AddAllPaperUsersRecord",
        value: function(e) {
            return this.request({
                url: "/api/c_paper_users_record/InnerAll_c_paper_users_record",
                data: e,
                method: "POST"
            });
        }
    }, {
        key: "GetPaperUsersRecord",
        value: function(e) {
            return this.request({
                url: "/api/c_paper_users_record/GetListByAll",
                data: e
            });
        }
    }, {
        key: "GetPaperQuestionAnalysisList",
        value: function(e) {
            return this.request({
                url: "/api/Master/AutoModel",
                method: "POST",
                data: {
                    command: "GetPaperQuestionAnalysisList",
                    data: JSON.stringify(e)
                }
            });
        }
    }, {
        key: "GetMajorComputingUserErrorQuestionCount",
        value: function(e) {
            return this.request({
                url: "/api/Master/AutoModel",
                method: "POST",
                data: {
                    command: "GetMajorComputingUserErrorQuestionCount",
                    data: JSON.stringify(e)
                }
            });
        }
    }, {
        key: "RetryPaperByPaperUserRecord",
        value: function(e) {
            return this.request({
                url: "/api/c_paper_users_record/RetryPaper",
                data: e,
                method: "POST"
            });
        }
    }, {
        key: "GetMajorComputingUserErrorQuestionListByCatalog",
        value: function(e) {
            return this.request({
                url: "/api/Master/AutoModel",
                method: "POST",
                data: {
                    command: "GetMajorComputingUserErrorQuestionListByCatalog",
                    data: JSON.stringify(e)
                }
            });
        }
    }, {
        key: "GetMajorComputingUserErrorQuestionResolveList",
        value: function(e) {
            return this.request({
                url: "/api/Master/AutoModel",
                method: "POST",
                data: {
                    command: "GetMajorComputingUserErrorQuestionResolveList",
                    data: JSON.stringify(e)
                }
            });
        }
    }, {
        key: "GetMajorComputingUserErrorQuestionList",
        value: function(e) {
            return this.request({
                url: "/api/Master/AutoModel",
                method: "POST",
                data: {
                    command: "GetMajorComputingUserErrorQuestionList",
                    data: JSON.stringify(e)
                }
            });
        }
    }, {
        key: "GetPaperByInfoResult",
        value: function(e) {
            return this.request({
                url: "/api/c_paper/GetPaperByInfoResult",
                data: e
            });
        }
    }, {
        key: "GetAlbumOperationinfo",
        value: function(e) {
            return this.request({
                url: "/api/Master/AutoModel",
                method: "POST",
                data: {
                    command: "GetAlbumOperationinfo",
                    data: JSON.stringify(e)
                }
            });
        }
    }, {
        key: "GetAlbumTecherPaperOperationinfo",
        value: function(e) {
            return this.request({
                url: "/api/Master/AutoModel",
                method: "POST",
                data: {
                    command: "GetAlbumTecherPaperOperationinfo",
                    data: JSON.stringify(e)
                }
            });
        }
    }, {
        key: "GetQuestionInfoByResolve",
        value: function(e) {
            return this.request({
                url: "/api/Master/AutoModel",
                method: "POST",
                data: {
                    command: "GetQuestionInfoByResolve",
                    data: JSON.stringify(e)
                }
            });
        }
    }, {
        key: "GetMajorComputingLastLog",
        value: function(e) {
            return this.request({
                url: "/api/Master/AutoModel",
                method: "POST",
                data: {
                    command: "GetMajorComputingLastLog",
                    data: JSON.stringify(e)
                }
            });
        }
    }, {
        key: "AddQuestionCapacityLog",
        value: function(e) {
            return this.request({
                url: "/api/question_capacity_log/Inner_question_capacity_log",
                method: "POST",
                data: e
            });
        }
    }, {
        key: "GetQuestionCapacityLog",
        value: function(e) {
            return this.request({
                url: "/api/question_capacity_log/GetListByPage",
                data: e
            });
        }
    }, {
        key: "GetBookTeacher_v2",
        value: function(e) {
            return this.request({
                url: "/api/Master/AutoModel",
                method: "POST",
                data: {
                    command: "GetBookTeacher_v2",
                    data: JSON.stringify(e)
                }
            });
        }
    }, {
        key: "GetBookisRecommend_v2",
        value: function(e) {
            return this.request({
                url: "/api/Master/AutoModel",
                method: "POST",
                data: {
                    command: "GetBookisRecommend_v2",
                    data: JSON.stringify(e)
                }
            });
        }
    }, {
        key: "GetBookListByTeacher_v2",
        value: function(e) {
            return this.request({
                url: "/api/Master/AutoModel",
                method: "POST",
                data: {
                    command: "GetBookListByTeacher_v2",
                    data: JSON.stringify(e)
                }
            });
        }
    }, {
        key: "GetBookListByNoTeacherName_v2",
        value: function(e) {
            return this.request({
                url: "/api/Master/AutoModel",
                method: "POST",
                data: {
                    command: "GetBookListByNoTeacherName_v2",
                    data: JSON.stringify(e)
                }
            });
        }
    }, {
        key: "GetBookListByPaper_v2",
        value: function(e) {
            return this.request({
                url: "/api/Master/AutoModel",
                method: "POST",
                data: {
                    command: "GetBookListByPaper_v2",
                    data: JSON.stringify(e)
                }
            });
        }
    }, {
        key: "GetFunctionAllocationList",
        value: function(e) {
            return this.request({
                url: "/api/sys_users_function_allocation/GetListByPage",
                data: e
            });
        }
    }, {
        key: "InnerFunctionAllocationList",
        value: function(e) {
            return this.request({
                url: "/api/sys_users_function_allocation/Inner_sys_users_function_allocation",
                method: "POST",
                data: e
            });
        }
    }, {
        key: "GetDryRunInfoByPage",
        value: function(e) {
            return this.request({
                url: "/api/sys_users_dryrun/GetListByPage",
                data: e
            });
        }
    }, {
        key: "GetDryRunInfoList",
        value: function(e) {
            return this.request({
                url: "/api/Master/AutoModel",
                method: "POST",
                data: {
                    command: "GetDryRunInfoList",
                    data: JSON.stringify(e)
                }
            });
        }
    }, {
        key: "GetDryAppliInfo",
        value: function(e) {
            return this.request({
                url: "/api/Master/AutoModel",
                method: "POST",
                data: {
                    command: "GetDryAppliInfo",
                    data: JSON.stringify(e)
                }
            });
        }
    }, {
        key: "GetDryrunList",
        value: function(e) {
            return this.request({
                url: "/api/sys_users_dryrun/GetDryrunList",
                data: e
            });
        }
    }, {
        key: "GetDryrunListBy2",
        value: function(e) {
            return this.request({
                url: "/api/sys_users_dryrun/GetDryrunListBy2",
                data: e
            });
        }
    }, {
        key: "GetDryrunList2",
        value: function(e) {
            return this.request({
                url: "/api/sys_users_dryrun/GetDryrunList2",
                data: e
            });
        }
    }, {
        key: "GetDryListByIDs",
        value: function(e) {
            return this.request({
                url: "/api/Master/AutoModel",
                method: "POST",
                data: {
                    command: "GetDryListByIDs",
                    data: JSON.stringify(e)
                }
            });
        }
    }, {
        key: "GetDryPaperLog",
        value: function(e) {
            return this.request({
                url: "/api/sys_users_dryrun_paperlog/GetListByPage",
                data: e
            });
        }
    }, {
        key: "AddDryPaperLog",
        value: function(e) {
            try {
                return this.request({
                    url: "/api/sys_users_dryrun_paperlog/Inner_sys_users_dryrun_paperlog",
                    method: "POST",
                    data: e
                });
            } catch (e) {}
        }
    }, {
        key: "GetDryPaperQuestionList",
        value: function(e) {
            return this.request({
                url: "/api/c_paper_question/GetPaperQuestion",
                data: e
            });
        }
    }, {
        key: "GetDrypaperQuestionLog",
        value: function(e) {
            return this.request({
                url: "/api/sys_users_dryrun_questionlog/GetListByPage",
                data: e
            });
        }
    }, {
        key: "AddDryPaperQuestionLog",
        value: function(e) {
            try {
                return this.request({
                    url: "/api/sys_users_dryrun_questionlog/Inner_sys_users_dryrun_questionlog",
                    method: "POST",
                    data: e
                });
            } catch (e) {}
        }
    }, {
        key: "AddDryPaperQuestionLogAll",
        value: function(e) {
            try {
                return this.request({
                    url: "/api/sys_users_dryrun_questionlog/InnerAll_sys_users_dryrun_questionlog",
                    method: "POST",
                    data: e
                });
            } catch (e) {}
        }
    }, {
        key: "GetQuesionInfoByPaperIDandIDs",
        value: function(e) {
            return this.request({
                url: "/api/Master/AutoModel",
                method: "POST",
                data: {
                    command: "GetQuesionInfoByPaperIDandIDs",
                    data: JSON.stringify(e)
                }
            });
        }
    }, {
        key: "GetExamStatistics1",
        value: function(e) {
            return this.request({
                url: "/api/Master/AutoModel",
                method: "POST",
                data: {
                    command: "GetExamStatistics1",
                    data: JSON.stringify(e)
                }
            });
        }
    }, {
        key: "GetExamStatistics2",
        value: function(e) {
            return this.request({
                url: "/api/Master/AutoModel",
                method: "POST",
                data: {
                    command: "GetExamStatistics2",
                    data: JSON.stringify(e)
                }
            });
        }
    }, {
        key: "GetExamStatistics3",
        value: function(e) {
            return this.request({
                url: "/api/Master/AutoModel",
                method: "POST",
                data: {
                    command: "GetExamStatistics3",
                    data: JSON.stringify(e)
                }
            });
        }
    }, {
        key: "GetExamStatistics4",
        value: function(e) {
            return this.request({
                url: "/api/Master/AutoModel",
                method: "POST",
                data: {
                    command: "GetExamStatistics4",
                    data: JSON.stringify(e)
                }
            });
        }
    }, {
        key: "GetExamUserScoreAndQuestionType",
        value: function(e) {
            return this.request({
                url: "/api/Master/AutoModel",
                method: "POST",
                data: {
                    command: "GetExamUserScoreAndQuestionType",
                    data: JSON.stringify(e)
                }
            });
        }
    }, {
        key: "GetExamUserRink",
        value: function(e) {
            return this.request({
                url: "/api/Master/AutoModel",
                method: "POST",
                data: {
                    command: "GetExamUserRink",
                    data: JSON.stringify(e)
                }
            });
        }
    }, {
        key: "GetUserInfoByStuIDBymodel",
        value: function(e) {
            return this.request({
                url: "/api/Master/AutoModel",
                method: "POST",
                data: {
                    command: "GetUserInfoByStuID",
                    data: JSON.stringify(e)
                }
            });
        }
    }, {
        key: "AddSysUserBookCatalog",
        value: function(e) {
            return this.request({
                url: "/api/sys_user_book_catalog/Inner_sys_user_book_catalog",
                method: "POST",
                data: e
            });
        }
    }, {
        key: "updatedSysUserBookCatalog",
        value: function(e) {
            return this.request({
                url: "/api/sys_user_book_catalog/InnerAll_sys_user_book_catalog",
                method: "POST",
                data: e
            });
        }
    }, {
        key: "GetSysUserBookCatalog",
        value: function(e) {
            return this.request({
                url: "/api/Master/AutoModel",
                method: "POST",
                data: {
                    command: "GetSysUserBookCatalog",
                    data: JSON.stringify(e)
                }
            });
        }
    }, {
        key: "DelSysUserBookCatalog",
        value: function(e) {
            return this.request({
                url: "/api/sys_user_book_catalog/Del_sys_user_book_catalog",
                method: "POST",
                data: e
            });
        }
    }, {
        key: "AddSysUserBookQuestion",
        value: function(e) {
            return this.request({
                url: "/api/sys_user_book_question/Inner_sys_user_book_question",
                method: "POST",
                data: e
            });
        }
    }, {
        key: "UpdatesysSysUserBookQuestion",
        value: function(e) {
            return this.request({
                url: "/api/sys_user_book_question/Updatesys_user_book_question",
                method: "POST",
                data: e
            });
        }
    }, {
        key: "GetSysUserBookQuestion",
        value: function(e) {
            return this.request({
                url: "/api/sys_user_book_question/GetListByPage",
                data: e
            });
        }
    }, {
        key: "GetQuestionCatalog",
        value: function(e) {
            return this.request({
                url: "/api/Master/AutoModel",
                method: "POST",
                data: {
                    command: "GetQuestionCatalog",
                    data: JSON.stringify(e)
                }
            });
        }
    }, {
        key: "GeSysUserBookQuestionCount",
        value: function(e) {
            return this.request({
                url: "/api/Master/AutoModel",
                method: "POST",
                data: {
                    command: "GeSysUserBookQuestionCount",
                    data: JSON.stringify(e)
                }
            });
        }
    }, {
        key: "DelsSysUserBookQuestion",
        value: function(e) {
            return this.request({
                url: "/api/sys_user_book_question/Dels_sys_user_book_question",
                method: "POST",
                data: e
            });
        }
    }, {
        key: "GetSysUserBookQuestionNextList",
        value: function(e) {
            return this.request({
                url: "/api/Master/AutoModel",
                method: "POST",
                data: {
                    command: "GetSysUserBookQuestionNextList",
                    data: JSON.stringify(e)
                }
            });
        }
    }, {
        key: "GetIntegralRuleInfo",
        value: function(e) {
            return this.request({
                url: "/api/Master/AutoModel",
                method: "POST",
                data: {
                    command: "GetIntegralRuleInfo",
                    data: JSON.stringify(e)
                }
            });
        }
    }, {
        key: "GetUserIntegral",
        value: function(e) {
            return this.request({
                url: "/api/Master/AutoModel",
                method: "POST",
                data: {
                    command: "GetUserIntegral",
                    data: JSON.stringify(e)
                }
            });
        }
    }, {
        key: "GetIntegralConvertInfo",
        value: function(e) {
            return this.request({
                url: "/api/Master/AutoModel",
                method: "POST",
                data: {
                    command: "GetIntegralConvertInfo",
                    data: JSON.stringify(e)
                }
            });
        }
    }, {
        key: "ConsumeConvert",
        value: function(e) {
            return this.request({
                url: "/api/sys_integral_log/consume",
                method: "POST",
                data: e
            });
        }
    }, {
        key: "GetUserIntegralDetail",
        value: function(e) {
            return this.request({
                url: "/api/Master/AutoModel",
                method: "POST",
                data: {
                    command: "GetUserIntegralDetail",
                    data: JSON.stringify({
                        StuID: e.StuID,
                        Operation: e.Operation
                    }),
                    limit: e.limit,
                    page: e.page
                }
            });
        }
    }, {
        key: "GetIntegralChooseSchoolLog",
        value: function(e) {
            return this.request({
                url: "/api/Master/AutoModel",
                method: "POST",
                data: {
                    command: "GetIntegralChooseSchoolLog",
                    data: JSON.stringify(e)
                }
            });
        }
    }, {
        key: "GetLookAnalysis",
        value: function(e) {
            return this.request({
                url: "/api/Master/AutoModel",
                method: "POST",
                data: {
                    command: "GetLookAnalysis",
                    data: JSON.stringify(e)
                }
            });
        }
    }, {
        key: "GetContentList",
        value: function(e) {
            return this.request({
                url: "/api/content_list/GetListByAll",
                data: e
            });
        }
    }, {
        key: "InnerAllContentListLog",
        value: function(e) {
            return this.request({
                url: "/api/content_list_log/InnerAll_content_list_log",
                method: "POST",
                data: e
            });
        }
    }, {
        key: "InnerContentListLog",
        value: function(e) {
            return this.request({
                url: "/api/content_list_log/Inner_content_list_log",
                method: "POST",
                data: e
            });
        }
    }, {
        key: "DelContentListLog",
        value: function(e) {
            return this.request({
                url: "/api/content_list_log/Del_content_list_log",
                method: "POST",
                data: e
            });
        }
    }, {
        key: "GetNoReadContentList",
        value: function(e) {
            return this.request({
                url: "/api/Master/AutoModel",
                method: "POST",
                data: {
                    command: "GetNoReadContentList",
                    data: JSON.stringify(e)
                }
            });
        }
    }, {
        key: "GetUserProductCourseList",
        value: function(e) {
            return this.request({
                url: "/api/Master/AutoModel",
                method: "POST",
                data: {
                    command: "GetUserProductCourseList",
                    data: JSON.stringify(e)
                }
            });
        }
    }, {
        key: "CreateSysUserInfoByStuID",
        value: function(e) {
            return this.request({
                url: "/api/sys_users_info/Inner_sys_users_info",
                method: "POST",
                data: e
            });
        }
    }, {
        key: "GetQaQuestionOrderList",
        value: function(e) {
            return this.request({
                url: "/api/question_orders/GetListByPage",
                data: e
            });
        }
    }, {
        key: "GetQaQuestionCommentList",
        value: function(e) {
            return this.request({
                url: "/api/question_order_comments/GetListByPage",
                data: e
            });
        }
    } ]), i;
}(s.default);