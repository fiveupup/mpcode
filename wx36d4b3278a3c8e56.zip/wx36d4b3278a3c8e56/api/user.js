Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.User = void 0;

var e, t = require("../@babel/runtime/helpers/objectSpread2"), r = require("../@babel/runtime/helpers/classCallCheck"), s = require("../@babel/runtime/helpers/createClass"), a = require("../@babel/runtime/helpers/inherits"), u = require("../@babel/runtime/helpers/createSuper"), o = (e = require("../utils/http.js")) && e.__esModule ? e : {
    default: e
};

exports.User = function(e) {
    a(i, e);
    var o = u(i);
    function i() {
        return r(this, i), o.apply(this, arguments);
    }
    return s(i, [ {
        key: "Gettimes",
        value: function(e) {
            return this.request({
                url: "/api/base/gettimes",
                method: "get",
                data: {}
            });
        }
    }, {
        key: "GetUserAskStatu",
        value: function(e) {
            return this.request({
                url: "/api/Master/AutoModel",
                method: "POST",
                data: {
                    command: "GetUserAskStatu",
                    data: JSON.stringify({
                        StuID: e.StuID
                    })
                }
            });
        }
    }, {
        key: "updateCourseUser",
        value: function(e) {
            return this.request({
                url: "/api/course_users/Inner_course_users",
                method: "POST",
                data: {
                    Tel: e.Tel,
                    StuID: e.StuID,
                    ID: e.ID,
                    UpdateColumns: "StuID"
                }
            });
        }
    }, {
        key: "GetUserCourseDetailInfo",
        value: function(e) {
            return this.request({
                url: "/api/Master/AutoModel",
                method: "POST",
                noLoading: !0,
                data: {
                    command: "GetUserCourseDetailInfo",
                    data: JSON.stringify({
                        CourseID: e.CourseID,
                        StuID: e.StuID
                    })
                }
            });
        }
    }, {
        key: "GetSysUserInfo",
        value: function(e) {
            return this.request({
                url: "/api/sys_users_info/GetListByAll",
                method: "GET",
                data: {
                    StuID: e.StuID
                }
            });
        }
    }, {
        key: "CreateUserAsk",
        value: function(e) {
            return this.request({
                url: "/api/Master/AutoModel",
                method: "POST",
                data: {
                    command: "CreateUserAsk",
                    data: JSON.stringify({
                        StuID: e.StuID,
                        QuestionID: e.QuestionID,
                        AskTitle: e.AskTitle,
                        AskImage: e.AskImage
                    })
                }
            });
        }
    }, {
        key: "CreateUserAsk2",
        value: function(e) {
            return this.request({
                url: "/api/sys_user_ask/Inner_sys_user_ask",
                method: "POST",
                data: {
                    StuID: e.StuID,
                    QuestionID: e.QuestionID,
                    AskTitle: e.AskTitle,
                    AskImage: e.AskImage,
                    PID: e.PID
                }
            });
        }
    }, {
        key: "GetSysUserVipInfo",
        value: function(e) {
            return this.request({
                url: "/api/sys_user_vip/GetListByAll",
                method: "GET",
                data: {
                    StuID: e.StuID
                }
            });
        }
    }, {
        key: "GetProvinceList",
        value: function(e) {
            return this.request({
                url: "/api/Master/AutoModel",
                method: "POST",
                data: {
                    command: "GetSysProvinceList"
                }
            });
        }
    }, {
        key: "GetProvinceSchoolList",
        value: function(e) {
            return this.request({
                url: "/api/Master/AutoModel",
                method: "POST",
                data: {
                    command: "GetSysProvinceSchoolList",
                    data: JSON.stringify({
                        Key: e.ProvinceID
                    })
                }
            });
        }
    }, {
        key: "CreateSysUserInfo",
        value: function(e) {
            return this.request({
                url: "/api/sys_users_info/Inner_sys_users_info",
                method: "POST",
                data: {
                    StuID: e.StuID,
                    UserName: e.UserName,
                    SchoolName: e.SchoolName,
                    TargetSchool: e.TargetSchool,
                    IsCrossCourse: e.IsCrossCourse,
                    TargetScore: e.TargetScore,
                    IsWorkStudy: e.IsWorkStudy,
                    CourseName: e.CourseName,
                    isJoinCourse: e.IsJoinCourse,
                    Province: e.Province,
                    QQ: e.QQ,
                    ElseQuestion: e.ElseQuestion,
                    System_Station_ID: getApp().globalData.SassID,
                    Source: e.Source ? e.Source : "小程序会员激活",
                    Score2: e.Score2,
                    UseRestsApp: e.UseRestsApp,
                    IsRealizeCourse: e.IsRealizeCourse,
                    IsInActivities: e.IsInActivities,
                    GoOverTime: e.GoOverTime
                }
            });
        }
    }, {
        key: "UpdateUserAsk",
        value: function(e) {
            return this.request({
                url: "/api/sys_user_ask/UpdateUserAskIsView",
                method: "POST",
                data: {
                    ID: e.ID,
                    IsView: 1
                }
            });
        }
    }, {
        key: "updateUserInfoSchooName",
        value: function(e) {
            return this.request({
                url: "/api/sys_users_info/Inner_sys_users_info",
                method: "POST",
                data: {
                    ID: e.ID,
                    SchoolName: e.SchoolName,
                    UpdateColumns: "SchoolName"
                }
            });
        }
    }, {
        key: "updateUserInfoTargetSchool",
        value: function(e) {
            return this.request({
                url: "/api/sys_users_info/Inner_sys_users_info",
                method: "POST",
                data: {
                    ID: e.ID,
                    TargetSchool: e.TargetSchool,
                    UpdateColumns: "TargetSchool"
                }
            });
        }
    }, {
        key: "updateUserInfoTargetScore",
        value: function(e) {
            return this.request({
                url: "/api/sys_users_info/Inner_sys_users_info",
                method: "POST",
                data: {
                    ID: e.ID,
                    TargetScore: e.TargetScore,
                    UpdateColumns: "TargetScore"
                }
            });
        }
    }, {
        key: "updateUserInfoIsWorkStudy",
        value: function(e) {
            return this.request({
                url: "/api/sys_users_info/Inner_sys_users_info",
                method: "POST",
                data: {
                    ID: e.ID,
                    IsWorkStudy: e.IsWorkStudy,
                    UpdateColumns: "IsWorkStudy"
                }
            });
        }
    }, {
        key: "updateUserInfoIsJoinCourse",
        value: function(e) {
            return this.request({
                url: "/api/sys_users_info/Inner_sys_users_info",
                method: "POST",
                data: {
                    ID: e.ID,
                    IsJoinCourse: e.IsJoinCourse,
                    UpdateColumns: "isJoinCourse"
                }
            });
        }
    }, {
        key: "updateUserInfoSource",
        value: function(e) {
            return this.request({
                url: "/api/sys_users_info/Inner_sys_users_info",
                method: "POST",
                data: {
                    ID: e.ID,
                    Source: e.Source,
                    UpdateColumns: "Source"
                }
            });
        }
    }, {
        key: "GetUserRecord",
        value: function(e) {
            return this.request({
                url: "/api/Master/AutoModel",
                method: "POST",
                data: {
                    command: "GetUserRecordListPager1",
                    data: JSON.stringify(e)
                }
            });
        }
    }, {
        key: "GetUserViewRecordByBook",
        value: function(e) {
            return this.request({
                url: "/api/Master/AutoModel",
                method: "POST",
                data: {
                    command: "GetUserLastViewByBook_math",
                    data: JSON.stringify({
                        StuID: e.StuID,
                        BookID: e.BookID
                    })
                }
            });
        }
    }, {
        key: "GetUserViewRecordByExercise",
        value: function(e) {
            return this.request({
                url: "/api/Master/AutoModel",
                method: "POST",
                data: {
                    command: "GetUserLastViewByExercise_math",
                    data: JSON.stringify({
                        StuID: e.StuID,
                        BookID: e.BookID
                    })
                }
            });
        }
    }, {
        key: "GetUserQuestionDiscussList",
        value: function(e) {
            return this.request({
                url: "/api/Master/AutoModel",
                method: "POST",
                data: {
                    command: "GetUserQuestionDiscussListPager",
                    data: JSON.stringify(e)
                }
            });
        }
    }, {
        key: "CreateCourseUser",
        value: function(e) {
            return this.request({
                url: "/api/course_users/Inner_course_users",
                method: "POST",
                data: {
                    StuID: e.StuID,
                    CourseID: e.CourseID,
                    StudyInfo: e.StudyInfo,
                    Room: e.RoomID,
                    AddPerson: "小程序报名",
                    System_Station_ID: getApp().globalData.SassID,
                    IsDelete: 0
                }
            });
        }
    }, {
        key: "CancelUserRecord",
        value: function(e) {
            return this.request({
                url: "/api/sys_user_record/Del_sys_user_record",
                method: "POST",
                data: {
                    ID: e.ID
                }
            });
        }
    }, {
        key: "CreateCourseUserProgress",
        value: function(e) {
            return this.request({
                url: "/api/course_users_progress/Inner_course_users_progress",
                method: "POST",
                data: {
                    StuID: e.StuID,
                    CourseID: e.CourseID,
                    CourseDetailID: e.CourseDetailID,
                    RoomID: e.RoomID,
                    IsFinished: 0
                }
            });
        }
    }, {
        key: "CreateQuestionUserTest",
        value: function(e) {
            return this.request({
                url: "/api/question_users_test/Inner_question_users_test",
                method: "POST",
                data: {
                    StuID: e.StuID,
                    TestID: e.TestID,
                    OptionID: e.OptionID,
                    SignContent: e.SignContent,
                    DetailQuestionID: e.DetailQuestionID,
                    ProcessID: e.ProcessID,
                    QuestionID: e.QuestionID
                }
            });
        }
    }, {
        key: "updateUserVipExpired",
        value: function(e) {
            return this.request({
                url: "/api/sys_user_vip/Inner_sys_user_vip",
                method: "POST",
                data: {
                    ID: e.ID,
                    SVIPValidTime: e.SVIPValidTime,
                    UpdateColumns: "SVIPValidTime"
                }
            });
        }
    }, {
        key: "updateUserVipCode",
        value: function(e) {
            return this.request({
                url: "/api/sys_user_vip_codes/Inner_sys_user_vip_codes",
                method: "POST",
                data: {
                    ID: e.ID,
                    StuID: e.StuID,
                    Status: e.Status,
                    UseTime: e.UseTime,
                    UpdateColumns: "StuID,Status,UseTime"
                }
            });
        }
    }, {
        key: "updateCourseUserProcess",
        value: function(e) {
            return this.request({
                url: "/api/course_users_progress/Inner_course_users_progress",
                method: "POST",
                data: {
                    ID: e.ID,
                    IsFinished: e.IsFinished,
                    UpdateColumns: "IsFinished"
                }
            });
        }
    }, {
        key: "createUserVipByCardCode",
        value: function(e) {
            return this.request({
                url: "/api/sys_user_vip/Inner_sys_user_vip",
                method: "POST",
                data: {
                    StuID: e.StuID,
                    VIPValidTime: e.VIPValidTime,
                    IsVIP: 1,
                    System_Station_ID: getApp().globalData.SassID
                }
            });
        }
    }, {
        key: "createUserVip",
        value: function(e) {
            return this.request({
                url: "/api/sys_user_vip/Inner_sys_user_vip",
                method: "POST",
                data: {
                    StuID: e.StuID,
                    SVIPValidTime: e.SVIPValidTime,
                    IsVIP: 1,
                    IsSVIP: 1,
                    System_Station_ID: getApp().globalData.SassID
                }
            });
        }
    }, {
        key: "createDefaultUserVip",
        value: function(e) {
            return this.request({
                url: "/api/sys_user_vip/Inner_sys_user_vip",
                method: "POST",
                data: {
                    StuID: e.StuID,
                    IsVIP: 1,
                    VIPValidTime: e.VIPValidTime,
                    IsSVIP: 1,
                    SVIPValidTime: e.VIPValidTime,
                    System_Station_ID: getApp().globalData.SassID
                }
            });
        }
    }, {
        key: "UpdateWXUserSubscribe",
        value: function(e) {
            return this.request({
                url: "/api/wx_users/Inner_wx_users",
                method: "POST",
                data: {
                    OpenID: e.OpenID,
                    Subscribe: e.Subscribe,
                    UpdateColumns: "Subscribe"
                }
            });
        }
    }, {
        key: "UpdateWXUserHeadImgurl",
        value: function(e) {
            return this.request({
                url: "/api/wx_users/Inner_wx_users",
                method: "POST",
                data: {
                    OpenID: e.OpenID,
                    HeadImgurl: e.HeadImgurl,
                    UpdateColumns: "HeadImgurl"
                }
            });
        }
    }, {
        key: "UpdateWXUserNickname",
        value: function(e) {
            return this.request({
                url: "/api/wx_users/Inner_wx_users",
                method: "POST",
                data: {
                    OpenID: e.OpenID,
                    Nickname: e.Nickname,
                    UpdateColumns: "Nickname"
                }
            });
        }
    }, {
        key: "CreateWXUser",
        value: function(e) {
            return this.request({
                url: "/api/wx_users/Inner_wx_users",
                method: "POST",
                data: {
                    OpenID: e.OpenID,
                    Info_ID: getApp().globalData.wxInfoID,
                    Nickname: "微信用户" != e.NickName ? e.NickName : "",
                    Sex: e.Sex,
                    HeadImgurl: "微信用户" != e.NickName ? e.HeadImgurl : "",
                    Country: e.Country,
                    Province: e.Province,
                    City: e.City,
                    System_Station_ID: getApp().globalData.SassID,
                    IsGetInfo: 1
                }
            });
        }
    }, {
        key: "UpdateWXUser",
        value: function(e) {
            return this.request({
                url: "/api/wx_users/Inner_wx_users",
                method: "POST",
                data: e
            });
        }
    }, {
        key: "GetSysUsersInfo",
        value: function(e) {
            return this.request({
                url: "/api/sys_users/GetListByPage",
                method: "GET",
                data: {
                    ID: e.ID
                }
            });
        }
    }, {
        key: "updateSysUser",
        value: function(e) {
            return this.request({
                url: "/api/sys_users/Inner_sys_users",
                method: "POST",
                data: {
                    ID: e.ID,
                    IsGetInfo: 1,
                    UpdateColumns: "IsGetInfo"
                }
            });
        }
    }, {
        key: "updataUserBookIDs",
        value: function(e) {
            return this.request({
                url: "/api/sys_users/Inner_sys_users",
                method: "POST",
                data: {
                    ID: e.ID,
                    EBookIDs: e.EBookIDs,
                    UpdateColumns: "ID,EBookIDs"
                }
            });
        }
    }, {
        key: "updataUserPaperIDs",
        value: function(e) {
            return this.request({
                url: "/api/sys_users/Inner_sys_users",
                method: "POST",
                data: {
                    ID: e.ID,
                    PaperIDs: e.PaperIDs,
                    UpdateColumns: "ID,PaperIDs"
                }
            });
        }
    }, {
        key: "updataUserAlbumIDs",
        value: function(e) {
            return this.request({
                url: "/api/sys_users/Inner_sys_users",
                method: "POST",
                data: {
                    ID: e.ID,
                    AlbumIDs: e.AlbumIDs,
                    UpdateColumns: "ID,AlbumIDs"
                }
            });
        }
    }, {
        key: "updataUserChoiceType",
        value: function(e) {
            return this.request({
                url: "/api/sys_users/Inner_sys_users",
                method: "POST",
                data: {
                    ID: e.ID,
                    ChoiceType: e.ChoiceType,
                    UpdateColumns: "ID,ChoiceType"
                }
            });
        }
    }, {
        key: "updataSubjectType",
        value: function(e) {
            return this.request({
                url: "/api/sys_users/Inner_sys_users",
                method: "POST",
                data: {
                    ID: e.ID,
                    SubjectType: e.SubjectType,
                    UpdateColumns: "ID,SubjectType"
                }
            });
        }
    }, {
        key: "updataIsOldUser",
        value: function(e) {
            return this.request({
                url: "/api/sys_users/Inner_sys_users",
                method: "POST",
                data: {
                    ID: e.ID,
                    IsOldUser: e.IsOldUser,
                    UpdateColumns: "ID,IsOldUser"
                }
            });
        }
    }, {
        key: "Login",
        value: function(e) {
            return this.request({
                url: "/api/wx/DecryptTel",
                method: "POST",
                data: JSON.stringify({
                    encryptedData: e.encryptedData,
                    iv: e.iv,
                    session_key: e.session_key,
                    openid: e.openid,
                    info_id: e.info_id
                })
            });
        }
    }, {
        key: "CreateUserCourseBookRecord",
        value: function(e) {
            return this.request({
                url: "/api/course_qrcode_book/Inner_course_qrcode_book",
                method: "POST",
                data: e
            });
        }
    }, {
        key: "GetUserCourseQrcodeBookList",
        value: function(e) {
            return this.request({
                url: "/api/Master/AutoModel",
                method: "POST",
                data: {
                    command: "GetUserCourseQrcodeBookListPager1",
                    data: JSON.stringify(e)
                }
            });
        }
    }, {
        key: "GetUserCourseQrcodeBookList1",
        value: function(e) {
            return this.request({
                url: "/api/Master/AutoModel",
                method: "POST",
                data: {
                    command: "GetUserCourseQrcodeBookListPager11",
                    data: JSON.stringify(e)
                }
            });
        }
    }, {
        key: "GetUserCapacityCount",
        value: function(e) {
            return this.request({
                url: "/api/Master/AutoModel",
                method: "POST",
                data: {
                    command: "GetUserCapacityCount",
                    data: JSON.stringify(e)
                }
            });
        }
    }, {
        key: "GetUserCourseQrcodeBookList2",
        value: function(e) {
            return this.request({
                url: "/api/Master/AutoModel",
                method: "POST",
                data: {
                    command: "GetUserCourseQrcodeBookList2",
                    data: JSON.stringify(e)
                }
            });
        }
    }, {
        key: "GetUserExtrapolationList",
        value: function(e) {
            return this.request({
                url: "/api/Master/AutoModel",
                method: "POST",
                noLoading: !0,
                data: {
                    command: "GetUserExtrapolationList",
                    data: JSON.stringify(e)
                }
            });
        }
    }, {
        key: "GetUserCourseQrcodePhotoBookListPager",
        value: function(e) {
            return this.request({
                url: "/api/Master/AutoModel",
                method: "POST",
                data: {
                    command: "GetUserCourseQrcodePhotoBookListPager1",
                    data: JSON.stringify(e)
                }
            });
        }
    }, {
        key: "WxXcxDecrypt",
        value: function(e) {
            return this.request({
                url: "/api/Wx/WxXcxDecrypt",
                method: "POST",
                data: e
            });
        }
    }, {
        key: "GetProductList",
        value: function(e) {
            return this.request({
                url: "/api/product_list/GetListByAll",
                data: e
            });
        }
    }, {
        key: "GetActiveInfo",
        value: function(e) {
            return this.request({
                url: "/api/activity_list/GetListByAll",
                data: t(t({}, e), {}, {
                    System_Station_ID: getApp().globalData.SassID
                })
            });
        }
    }, {
        key: "SetActivety",
        value: function(e) {
            return this.request({
                url: "/api/activity_user_log/Inner_activity_user_log",
                method: "POST",
                data: e
            });
        }
    }, {
        key: "SetVipCode",
        value: function(e) {
            return this.request({
                url: "/api/activity_user_log/BindAct",
                method: "POST",
                data: e
            });
        }
    }, {
        key: "SetVipActID",
        value: function(e) {
            return this.request({
                url: "/api/activity_user_log/ActID",
                method: "POST",
                data: e
            });
        }
    }, {
        key: "GetVipdataList",
        value: function(e) {
            return this.request({
                url: "/api/activity_user_log/GetListByAll",
                noLoading: !0,
                data: e
            });
        }
    }, {
        key: "GetWxShareData",
        value: function(e) {
            var t = getCurrentPages(), r = "/" + t[t.length - 1].route;
            return this.request({
                url: "/api/wx_shares/GetListByAll",
                data: {
                    Path: r
                }
            });
        }
    }, {
        key: "GetServiceList",
        value: function(e) {
            return this.request({
                url: "/api/sys_work_user/GetListByAll",
                data: t(t({}, e), {}, {
                    System_Station_ID: getApp().globalData.SassID
                })
            });
        }
    }, {
        key: "AddAgentUrl",
        value: function(e) {
            return this.request({
                url: "/api/agent_url/Inner_agent_url",
                method: "POST",
                data: e,
                noLoading: !0
            });
        }
    }, {
        key: "GetDicData",
        value: function(e) {
            return this.request({
                url: "/api/Dic/SelectDic",
                data: e,
                noLoading: !0
            });
        }
    }, {
        key: "SetAppsource",
        value: function(e) {
            return this.request({
                url: "/api/sys_users_source/Inner_sys_users_source",
                method: "POST",
                data: e,
                noLoading: !0
            });
        }
    }, {
        key: "GetUserService",
        value: function(e) {
            return this.request({
                url: "/api/Master/AutoModel",
                method: "POST",
                data: {
                    command: "GetUserService2",
                    data: JSON.stringify(e)
                }
            });
        }
    }, {
        key: "UpdateBusKeyByStuID",
        value: function(e) {
            return this.request({
                url: "/api/sys_user_record/UpdateBusKeyByStuID",
                data: e,
                method: "POST"
            });
        }
    }, {
        key: "DelBusTypeByIds",
        value: function(e) {
            return this.request({
                url: "/api/sys_user_record/DelBusTypeByIds",
                data: e,
                method: "POST"
            });
        }
    }, {
        key: "DelBusTypeByStuID",
        value: function(e) {
            return this.request({
                url: "/api/sys_user_record/DelBusTypeByStuID",
                data: e,
                method: "POST"
            });
        }
    }, {
        key: "GetUserRecordListPager2",
        value: function(e) {
            return this.request({
                url: "/api/Master/AutoModel",
                method: "POST",
                data: {
                    command: "GetUserRecordListPager2",
                    data: JSON.stringify(e)
                }
            });
        }
    }, {
        key: "GetUserRecordListPager3",
        value: function(e) {
            return this.request({
                url: "/api/Master/AutoModel",
                method: "POST",
                data: {
                    command: "GetUserRecordListPager3",
                    data: JSON.stringify(e)
                }
            });
        }
    }, {
        key: "GetUserRecordBookList",
        value: function(e) {
            return this.request({
                url: "/api/Master/AutoModel",
                method: "POST",
                data: {
                    command: "GetUserRecordBookList",
                    data: JSON.stringify(e)
                }
            });
        }
    }, {
        key: "GetExtendInfo",
        value: function(e) {
            return this.request({
                url: "/api/couponcard_stuid/GetListByPage",
                data: e
            });
        }
    }, {
        key: "AddExtendInfo",
        value: function(e) {
            return this.request({
                url: "/api/couponcard_study/SetCodeByStuID",
                method: "POST",
                data: e
            });
        }
    }, {
        key: "GetExtendUserList",
        value: function(e) {
            return this.request({
                url: "/api/Master/AutoModel",
                method: "POST",
                data: {
                    command: "GetExtendUserList",
                    data: JSON.stringify(e)
                }
            });
        }
    }, {
        key: "AddSetCodeByStudyInfo",
        value: function(e) {
            return this.request({
                url: "/api/couponcard_study/SetCodeByStudy",
                method: "POST",
                data: e
            });
        }
    }, {
        key: "AddUserCouponVipByTel",
        value: function(e) {
            return this.request({
                url: "/api/couponcard_study/InnerCodeByTel",
                method: "POST",
                data: {
                    Content: JSON.stringify(e)
                }
            });
        }
    }, {
        key: "getWechatmsg",
        value: function(e) {
            return this.request({
                url: "/api/Wechat/msg",
                method: "POST",
                data: e
            });
        }
    }, {
        key: "SendMsg",
        value: function(e) {
            return this.request({
                url: "/api/base/SendMsg",
                method: "POST",
                data: e
            });
        }
    }, {
        key: "WebLogin",
        value: function(e) {
            return this.request({
                url: "/api/wx/BindLogin",
                method: "POST",
                data: e
            });
        }
    }, {
        key: "GetScanText",
        value: function(e) {
            return this.request({
                url: "/api/base/ScanText2",
                method: "Get",
                data: e
            });
        }
    }, {
        key: "SetCodeByStudy",
        value: function(e) {
            return this.request({
                url: "/api/Master/AutoModel",
                method: "POST",
                data: {
                    command: "GetUserBookBy1149",
                    data: JSON.stringify(e)
                }
            });
        }
    }, {
        key: "updateUserInfoByStuID",
        value: function(e) {
            return this.request({
                url: "/api/sys_users_info/Inner_sys_users_info",
                method: "POST",
                data: e
            });
        }
    }, {
        key: "GetMajorList",
        value: function(e) {
            return this.request({
                url: "/api/Master/AutoModel",
                method: "POST",
                data: {
                    command: "GetMajorList",
                    data: JSON.stringify(e)
                }
            });
        }
    }, {
        key: "GetMajorSchool",
        value: function(e) {
            return this.request({
                url: "/api/Master/AutoModel",
                method: "POST",
                data: {
                    command: "GetMajorSchool",
                    data: JSON.stringify(e)
                }
            });
        }
    }, {
        key: "GetFushiScore",
        value: function(e) {
            return this.request({
                url: "/api/Master/AutoModel",
                method: "POST",
                data: {
                    command: "GetFushiScore",
                    data: JSON.stringify(e)
                }
            });
        }
    }, {
        key: "GetSchoolMajorScoreList",
        value: function(e) {
            return this.request({
                url: "/api/Master/AutoModel",
                method: "POST",
                data: {
                    command: "GetSchoolMajorScoreList",
                    data: JSON.stringify(e)
                }
            });
        }
    }, {
        key: "GetZexiaoSchoolList",
        value: function(e) {
            return this.request({
                url: "/api/Master/AutoModel",
                method: "POST",
                data: {
                    command: "GetZexiaoSchoolList",
                    data: JSON.stringify(e)
                }
            });
        }
    }, {
        key: "GetSchoolInMajor",
        value: function(e) {
            return this.request({
                url: "/api/Master/AutoModel",
                method: "POST",
                data: {
                    command: "GetSchoolInMajor",
                    data: JSON.stringify(e)
                }
            });
        }
    }, {
        key: "GetSchoolMajorTiaojiList",
        value: function(e) {
            return this.request({
                url: "/api/Master/AutoModel",
                method: "POST",
                data: {
                    command: "GetSchoolMajorTiaojiList",
                    data: JSON.stringify(e)
                }
            });
        }
    }, {
        key: "GetSchoolMajor",
        value: function(e) {
            return this.request({
                url: "/api/Master/AutoModel",
                method: "POST",
                data: {
                    command: "GetSchoolMajor",
                    data: JSON.stringify(e)
                }
            });
        }
    }, {
        key: "GetSchoolTiaoji",
        value: function(e) {
            return this.request({
                url: "/api/Master/AutoModel",
                method: "POST",
                data: {
                    command: "GetSchoolTiaoji",
                    data: JSON.stringify(e)
                }
            });
        }
    }, {
        key: "GetSchoolMajorList",
        value: function(e) {
            return this.request({
                url: "/api/Master/AutoModel",
                method: "POST",
                data: {
                    command: "GetSchoolMajorList",
                    data: JSON.stringify(e)
                }
            });
        }
    }, {
        key: "GetSchoolDetails",
        value: function(e) {
            return this.request({
                url: "/api/Master/AutoModel",
                method: "POST",
                data: {
                    command: "GetSchoolDetails",
                    data: JSON.stringify(e)
                }
            });
        }
    }, {
        key: "GetSearchSchoolMajorList",
        value: function(e) {
            return this.request({
                url: "/api/Master/AutoModel",
                method: "POST",
                data: {
                    command: "GetSearchSchoolMajorList",
                    data: JSON.stringify(e)
                }
            });
        }
    }, {
        key: "GetSProvinceList",
        value: function(e) {
            return this.request({
                url: "/api/Master/AutoModel",
                method: "POST",
                data: {
                    command: "GetSProvinceList",
                    data: JSON.stringify(e)
                }
            });
        }
    }, {
        key: "GetMajorDetails",
        value: function(e) {
            return this.request({
                url: "/api/Master/AutoModel",
                method: "POST",
                data: {
                    command: "GetMajorDetails",
                    data: JSON.stringify(e)
                }
            });
        }
    }, {
        key: "GetMajorFushi",
        value: function(e) {
            return this.request({
                url: "/api/Master/AutoModel",
                method: "POST",
                data: {
                    command: "GetMajorFushi",
                    data: JSON.stringify(e)
                }
            });
        }
    }, {
        key: "GetSchoolMajorDuibi",
        value: function(e) {
            return this.request({
                url: "/api/Master/AutoModel",
                method: "POST",
                data: {
                    command: "GetSchoolMajorDuibi",
                    data: JSON.stringify(e)
                }
            });
        }
    }, {
        key: "GetMajorGradeList",
        value: function(e) {
            return this.request({
                url: "/api/Master/AutoModel",
                method: "POST",
                data: {
                    command: "GetMajorGradeList",
                    data: JSON.stringify(e)
                }
            });
        }
    }, {
        key: "GetMajorLuqu",
        value: function(e) {
            return this.request({
                url: "/api/Master/AutoModel",
                method: "POST",
                data: {
                    command: "GetMajorLuqu",
                    data: JSON.stringify(e)
                }
            });
        }
    }, {
        key: "GetFushiAndGuojiaxianScoreDuiBi",
        value: function(e) {
            return this.request({
                url: "/api/Master/AutoModel",
                method: "POST",
                data: {
                    command: "GetFushiAndGuojiaxianScoreDuiBi",
                    data: JSON.stringify(e)
                }
            });
        }
    }, {
        key: "GetGuojiaxian",
        value: function(e) {
            return this.request({
                url: "/api/Master/AutoModel",
                method: "POST",
                data: {
                    command: "GetGuojiaxian",
                    data: JSON.stringify(e)
                }
            });
        }
    }, {
        key: "GetSchoolOpenMajorList",
        value: function(e) {
            return this.request({
                url: "/api/Master/AutoModel",
                method: "POST",
                data: {
                    command: "GetSchoolOpenMajorList",
                    data: JSON.stringify(e)
                }
            });
        }
    }, {
        key: "GetSchoolMajorZhaoSheng",
        value: function(e) {
            return this.request({
                url: "/api/Master/AutoModel",
                method: "POST",
                data: {
                    command: "GetSchoolMajorZhaoSheng",
                    data: JSON.stringify(e)
                }
            });
        }
    }, {
        key: "GetMajortypeList",
        value: function(e) {
            return this.request({
                url: "/api/Master/AutoModel",
                method: "POST",
                data: {
                    command: "GetMajortypeList",
                    data: JSON.stringify(e)
                }
            });
        }
    }, {
        key: "GetDetermineCreator",
        value: function(e) {
            return this.request({
                url: "/api/Master/AutoModel",
                method: "POST",
                data: {
                    command: "GetDetermineCreator",
                    data: JSON.stringify(e)
                }
            });
        }
    }, {
        key: "GetCreatorQuestionList",
        value: function(e) {
            return this.request({
                url: "/api/Master/AutoModel",
                method: "POST",
                data: {
                    command: "GetCreatorQuestionList",
                    data: JSON.stringify(e)
                }
            });
        }
    }, {
        key: "GetCreatorModelList",
        value: function(e) {
            return this.request({
                url: "/api/Master/AutoModel",
                method: "POST",
                data: {
                    command: "GetCreatorModelList",
                    data: JSON.stringify(e)
                }
            });
        }
    }, {
        key: "AddUserVisitRecordOfVipPage",
        value: function(e) {
            return this.request({
                url: "/api/sys_users_log/Inner_sys_users_log",
                data: e,
                method: "POST"
            });
        }
    }, {
        key: "CheckStuCouponLoginThirdDay",
        value: function(e) {
            return this.request({
                url: "/api/Master/AutoModel",
                method: "POST",
                data: {
                    command: "checkStuCouponLoginThirdDay",
                    data: JSON.stringify(e)
                }
            });
        }
    }, {
        key: "GetSysUserBookQuestionList",
        value: function(e) {
            return this.request({
                url: "/api/Master/AutoModel",
                method: "POST",
                data: {
                    command: "GetSysUserBookQuestionList",
                    data: JSON.stringify(e)
                }
            });
        }
    }, {
        key: "GetSysUserQuestionBookList",
        value: function(e) {
            return this.request({
                url: "/api/Master/AutoModel",
                method: "POST",
                data: {
                    command: "GetSysUserQuestionBookList",
                    data: JSON.stringify(e)
                }
            });
        }
    }, {
        key: "updataTel",
        value: function(e) {
            return this.request({
                url: "/api/sys_users/Inner_sys_users",
                method: "POST",
                data: {
                    ID: 250970,
                    Tel: 1837465141,
                    UpdateColumns: "ID,Tel"
                }
            });
        }
    }, {
        key: "AddUserCoordinate",
        value: function(e) {
            return this.request({
                url: "/api/sys_coordinate/Inner_sys_coordinate",
                data: e,
                method: "POST"
            });
        }
    }, {
        key: "UpdateUsersScrm",
        value: function(e) {
            return this.request({
                url: "/api/scrm_users/UpdateUsers",
                data: e,
                method: "POST"
            });
        }
    } ]), i;
}(o.default);