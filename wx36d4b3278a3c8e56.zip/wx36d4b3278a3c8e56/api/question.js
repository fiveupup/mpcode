Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.Question = void 0;

var e = require("../@babel/runtime/helpers/classCallCheck"), t = require("../@babel/runtime/helpers/createClass"), r = require("../@babel/runtime/helpers/inherits"), a = require("../@babel/runtime/helpers/createSuper"), n = i(require("../utils/http.js"));

i(require("../utils/util.js"));

function i(e) {
    return e && e.__esModule ? e : {
        default: e
    };
}

getApp(), exports.Question = function(n) {
    r(u, n);
    var i = a(u);
    function u() {
        return e(this, u), i.apply(this, arguments);
    }
    return t(u, [ {
        key: "SendMsgToTeacher",
        value: function(e) {
            return this.request({
                url: "/api/wx/SendTemplateMsg",
                data: {
                    Context: JSON.stringify({
                        first: {
                            value: "你有一条新消息提醒"
                        },
                        keyword2: {
                            value: e.Content
                        },
                        keyword1: {
                            value: e.Type
                        },
                        remark: {
                            value: "点击查看详情"
                        }
                    }),
                    TemplateId: "3tKCsE4OfHvJNLvPr3IlHQ56Rgo87di9I3ECI8uO-GQ",
                    WxInfo_ID: 7,
                    Openid: e.Openid,
                    MiniProgram: JSON.stringify({
                        appid: "wx36d4b3278a3c8e56",
                        pagepath: "wenda/pages/answer/index/index"
                    })
                },
                method: "POST"
            });
        }
    }, {
        key: "SendMsgToTeacherLevel",
        value: function(e) {
            return this.request({
                url: "/api/wx/SendTemplateMsg",
                data: {
                    Context: JSON.stringify({
                        first: {
                            value: "你有一条新消息提醒"
                        },
                        keyword2: {
                            value: e.Content
                        },
                        keyword1: {
                            value: e.Type
                        },
                        remark: {
                            value: "点击查看详情"
                        }
                    }),
                    TemplateId: "3tKCsE4OfHvJNLvPr3IlHQ56Rgo87di9I3ECI8uO-GQ",
                    WxInfo_ID: 7,
                    Openid: e.Openid,
                    MiniProgram: JSON.stringify({
                        appid: "wx36d4b3278a3c8e56",
                        pagepath: "wenda/pages/answer/level/info"
                    })
                },
                method: "POST"
            });
        }
    }, {
        key: "SendMsgToTeacherRepy",
        value: function(e) {
            return this.request({
                url: "/api/wx/SendTemplateMsg",
                data: {
                    Context: JSON.stringify({
                        first: {
                            value: "你有一条新消息提醒"
                        },
                        keyword2: {
                            value: e.Content
                        },
                        keyword1: {
                            value: e.Type
                        },
                        remark: {
                            value: "点击查看详情"
                        }
                    }),
                    TemplateId: "3tKCsE4OfHvJNLvPr3IlHQ56Rgo87di9I3ECI8uO-GQ",
                    WxInfo_ID: 7,
                    Openid: e.Openid,
                    MiniProgram: JSON.stringify({
                        appid: "wx36d4b3278a3c8e56",
                        pagepath: "wenda/pages/answer/comment/comment"
                    })
                },
                method: "POST"
            });
        }
    }, {
        key: "SendSysXcxMsgToUser",
        value: function(e) {
            return this.request({
                url: "/api/wx/Xcx_MsgSend2",
                data: {
                    wx_ID: 2,
                    openids: e.openids,
                    data: e.data,
                    templateId: "0MFnEGYAmS8AbTKk-IDnBSYRKGS1ClCaTB9h3MZZYxA",
                    url: e.url,
                    Type: 2,
                    BusType: "系统消息",
                    System_Station_ID: e.System_Station_ID
                },
                method: "POST"
            });
        }
    }, {
        key: "SendXcxMsgToUser",
        value: function(e) {
            return this.request({
                url: "/api/wx/Xcx_MsgSend2",
                data: {
                    wx_ID: 2,
                    openids: e.openids,
                    data: e.data,
                    templateId: "0MFnEGYAmS8AbTKk-IDnBSYRKGS1ClCaTB9h3MZZYxA",
                    url: e.url,
                    Type: 2,
                    BusType: "数学答疑",
                    System_Station_ID: e.System_Station_ID
                },
                method: "POST"
            });
        }
    }, {
        key: "SendTemplateMsgToUser",
        value: function(e) {
            return this.request({
                url: "/api/wx/SendTemplateMsg",
                data: {
                    Context: JSON.stringify({
                        first: {
                            value: "你有一条新答疑点评提醒"
                        },
                        keyword1: {
                            value: e.ServiceType
                        },
                        keyword2: {
                            value: e.TeacherName
                        },
                        keyword3: {
                            value: e.UpdateTime
                        },
                        remark: {
                            value: "点击查看提问详情"
                        }
                    }),
                    TemplateId: "XXckzAjbTXQSBkP62-TmZOZ7HM1jnMv7Td6RY5M6y7o",
                    WxInfo_ID: 7,
                    Openid: e.Openid,
                    MiniProgram: JSON.stringify({
                        appid: "wx36d4b3278a3c8e56",
                        pagepath: e.WxappPath
                    })
                },
                method: "POST"
            });
        }
    }, {
        key: "SendMsgPush",
        value: function(e) {
            return this.request({
                url: "/api/wx/Send",
                data: e,
                method: "POST"
            });
        }
    }, {
        key: "SendTemplateMsgToTeacher",
        value: function(e) {
            return this.request({
                url: "/api/wx/SendTemplateMsg",
                data: {
                    Context: JSON.stringify({
                        first: {
                            value: "你有一条新答疑追问提醒"
                        },
                        keyword1: {
                            value: e.ServiceType
                        },
                        keyword2: {
                            value: e.Content
                        },
                        remark: {
                            value: "点击查看提问详情"
                        }
                    }),
                    TemplateId: "3tKCsE4OfHvJNLvPr3IlHQ56Rgo87di9I3ECI8uO-GQ",
                    WxInfo_ID: 7,
                    Openid: e.Openid,
                    MiniProgram: JSON.stringify({
                        appid: "wx36d4b3278a3c8e56",
                        pagepath: e.WxappPath
                    })
                },
                method: "POST"
            });
        }
    }, {
        key: "SendMsgToManager",
        value: function(e) {
            return this.request({
                url: "/api/wx/SendTemplateMsg",
                data: {
                    Context: JSON.stringify({
                        first: {
                            value: "你有一条新消息提醒"
                        },
                        keyword2: {
                            value: e.Content
                        },
                        keyword1: {
                            value: e.Type
                        },
                        remark: {
                            value: "在电脑端查看详情"
                        }
                    }),
                    TemplateId: "3tKCsE4OfHvJNLvPr3IlHQ56Rgo87di9I3ECI8uO-GQ",
                    WxInfo_ID: 7,
                    Openid: e.Openid
                },
                method: "POST"
            });
        }
    }, {
        key: "AddTeacherQuestionOrderLog",
        value: function(e) {
            return this.request({
                url: "/api/question_order_log/Inner_question_order_log",
                data: e,
                method: "POST"
            });
        }
    }, {
        key: "checkUserIsSubscribe",
        value: function(e) {
            return this.request({
                url: "/api/Master/AutoModel",
                method: "POST",
                data: {
                    command: "checkUserIsSubscribe",
                    data: JSON.stringify(e)
                }
            });
        }
    }, {
        key: "CancelUserQuestionOrder",
        value: function(e) {
            return this.request({
                url: "/api/question_orders/Del_question_orders",
                method: "POST",
                data: {
                    ID: e.ID
                }
            });
        }
    }, {
        key: "AddQuestionByUser",
        value: function(e) {
            return this.request({
                url: "/api/quetion_list/Inner_quetion_list",
                data: e,
                method: "POST"
            });
        }
    }, {
        key: "AddQuestionOrder",
        value: function(e) {
            return this.request({
                url: "/api/question_orders/Inner_question_orders",
                data: e,
                method: "POST"
            });
        }
    }, {
        key: "GetUserTodayQuestionOrderCounts",
        value: function(e) {
            return this.request({
                url: "/api/Master/AutoModel",
                method: "POST",
                data: {
                    command: "GetUserQuestionOrderCounts",
                    data: JSON.stringify(e)
                }
            });
        }
    }, {
        key: "GetUserQuestionOrderLevel",
        value: function(e) {
            return this.request({
                url: "/api/Master/AutoModel",
                method: "POST",
                data: {
                    command: "GetUserQuestionOrderLevel",
                    data: JSON.stringify(e)
                }
            });
        }
    }, {
        key: "GetUserQuestionOrderLevelOfTeacher",
        value: function(e) {
            return this.request({
                url: "/api/Master/AutoModel",
                method: "POST",
                data: {
                    command: "GetUserQuestionOrderLevelOfTeacher",
                    data: JSON.stringify(e)
                }
            });
        }
    }, {
        key: "GetUserQuestionOrderList",
        value: function(e) {
            return this.request({
                url: "/api/Master/AutoModel",
                method: "POST",
                data: {
                    command: "GetUserQuestionOrderList",
                    data: JSON.stringify(e)
                }
            });
        }
    }, {
        key: "GetQuestionOrderInfo",
        value: function(e) {
            return this.request({
                url: "/api/Master/AutoModel",
                method: "POST",
                data: {
                    command: "GetQuestionOrderInfo",
                    data: JSON.stringify(e)
                }
            });
        }
    }, {
        key: "GetUserQuestionOrderTotal",
        value: function(e) {
            return this.request({
                url: "/api/Master/AutoModel",
                method: "POST",
                data: {
                    command: "GetAnswerUserCounts",
                    data: JSON.stringify(e)
                }
            });
        }
    }, {
        key: "GetWaitQuestionOrderCount",
        value: function(e) {
            return this.request({
                url: "/api/Master/AutoModel",
                method: "POST",
                data: {
                    command: "GetWaitQuestionOrderCount",
                    data: JSON.stringify(e)
                }
            });
        }
    }, {
        key: "GetWaitQuestionOrderListCounts",
        value: function(e) {
            return this.request({
                url: "/api/Master/AutoModel",
                method: "POST",
                data: {
                    command: "GetWaitQuestionOrderListCounts",
                    data: JSON.stringify(e)
                }
            });
        }
    }, {
        key: "AddQuestionOrderComment",
        value: function(e) {
            return this.request({
                url: "/api/question_order_comments/Inner_question_order_comments",
                data: e,
                method: "POST"
            });
        }
    }, {
        key: "GetQuestionOrderCommentList",
        value: function(e) {
            return this.request({
                url: "/api/Master/AutoModel",
                method: "POST",
                data: {
                    command: "GetQuestionOrderCommentList",
                    data: JSON.stringify(e)
                }
            });
        }
    }, {
        key: "AddQuestionOrderLevel",
        value: function(e) {
            return this.request({
                url: "/api/question_order_level/Inner_question_order_level",
                data: e,
                method: "POST"
            });
        }
    }, {
        key: "GetQuestionFeedBackList",
        value: function(e) {
            return this.request({
                url: "/api/sys_dic/GetListByAll",
                method: "GET",
                data: {
                    Pkey: "02f7a7be2de84747991bbef28cadd145",
                    SortDesc: "Sort ASC"
                }
            });
        }
    }, {
        key: "AddQuestionFeedBack",
        value: function(e) {
            return this.request({
                url: "/api/sys_give/Inner_sys_give",
                data: e,
                method: "POST"
            });
        }
    }, {
        key: "CheckUserIsQuestionTeacher",
        value: function(e) {
            return this.request({
                url: "/api/Master/AutoModel",
                method: "POST",
                data: {
                    command: "CheckUserIsQuestionTeacher",
                    data: JSON.stringify(e)
                }
            });
        }
    }, {
        key: "GetQuestionTeacherWorkToday",
        value: function(e) {
            return this.request({
                url: "/api/Master/AutoModel",
                method: "POST",
                data: {
                    command: "GetQuestionTeacherWorkToday",
                    data: JSON.stringify(e)
                }
            });
        }
    }, {
        key: "GetAnswerTeacherCounts",
        value: function(e) {
            return this.request({
                url: "/api/Master/AutoModel",
                method: "POST",
                data: {
                    command: "GetAnswerTeacherCounts",
                    data: JSON.stringify(e)
                }
            });
        }
    }, {
        key: "GetZTAnswerTeacherCounts",
        value: function(e) {
            return this.request({
                url: "/api/Master/AutoModel",
                method: "POST",
                data: {
                    command: "GetNewAnswerTeacherCounts",
                    data: JSON.stringify(e)
                }
            });
        }
    }, {
        key: "GetTeacherQuestionOrderTotal",
        value: function(e) {
            return this.request({
                url: "/api/Master/AutoModel",
                method: "POST",
                data: {
                    command: "GetAnswerUserCounts",
                    data: JSON.stringify(e)
                }
            });
        }
    }, {
        key: "GetTeacherQuestionOrderWaitList",
        value: function(e) {
            return this.request({
                url: "/api/Master/AutoModel",
                method: "POST",
                data: {
                    page: e.page,
                    limit: e.limit,
                    command: "GetQuestionOrderUnAnswerList",
                    data: JSON.stringify(e)
                }
            });
        }
    }, {
        key: "GetNewTeacherQuestionOrderWaitList",
        value: function(e) {
            return this.request({
                url: "/api/Master/AutoModel",
                method: "POST",
                data: {
                    page: e.page,
                    limit: e.limit,
                    command: "GetNewQuestionOrderUnAnswerList",
                    data: JSON.stringify(e)
                }
            });
        }
    }, {
        key: "GetQuestionTeacherAnswerDetailList",
        value: function(e) {
            return this.request({
                url: "/api/Master/AutoModel",
                method: "POST",
                data: {
                    page: e.page,
                    limit: e.limit,
                    command: "GetQuestionTeacherAnswerDetailList",
                    data: JSON.stringify(e)
                }
            });
        }
    }, {
        key: "GetQuestionOrderUnAnswerListOfTeacher",
        value: function(e) {
            return this.request({
                url: "/api/Master/AutoModel",
                method: "POST",
                data: {
                    page: e.page,
                    limit: e.limit,
                    command: "GetQuestionOrderUnAnswerListOfTeacher",
                    data: JSON.stringify(e)
                }
            });
        }
    }, {
        key: "GetQuestionOrderUnCommentListOfTeacherNewLimit",
        value: function(e) {
            return this.request({
                url: "/api/Master/AutoModel",
                method: "POST",
                data: {
                    command: "GetQuestionOrderUnCommentListOfTeacherNewLimits",
                    data: JSON.stringify(e)
                }
            });
        }
    }, {
        key: "GetQuestionOrderUnCommentListOfTeacher",
        value: function(e) {
            return this.request({
                url: "/api/Master/AutoModel",
                method: "POST",
                data: {
                    page: e.page,
                    limit: e.limit,
                    command: "GetQuestionOrderUnCommentListOfTeacher",
                    data: JSON.stringify(e)
                }
            });
        }
    }, {
        key: "GetQuestionOrderAnswerListOfTeacher",
        value: function(e) {
            return this.request({
                url: "/api/Master/AutoModel",
                method: "POST",
                data: {
                    page: e.page,
                    limit: e.limit,
                    command: "GetQuestionOrderAnswerListOfTeacher",
                    data: JSON.stringify(e)
                }
            });
        }
    }, {
        key: "GetNewQuestionOrderAnswerlistOfTeacher",
        value: function(e) {
            return this.request({
                url: "/api/Master/AutoModel",
                method: "POST",
                data: {
                    page: e.page,
                    limit: e.limit,
                    command: "GetNewQuestionOrderAnswerlistOfTeacher",
                    data: JSON.stringify(e)
                }
            });
        }
    }, {
        key: "GetNewQuestionOrderAnswerRefuseListOfTeacher",
        value: function(e) {
            return this.request({
                url: "/api/Master/AutoModel",
                method: "POST",
                data: {
                    page: e.page,
                    limit: e.limit,
                    command: "GetNewQuestionOrderAnswerRefuseListOfTeacher",
                    data: JSON.stringify(e)
                }
            });
        }
    }, {
        key: "GetNewQuestionOrderLevelListOfTeacher",
        value: function(e) {
            return this.request({
                url: "/api/Master/AutoModel",
                method: "POST",
                data: {
                    page: e.page,
                    limit: e.limit,
                    command: "getNewQuestionOrderLevelListOfTeacher",
                    data: JSON.stringify(e)
                }
            });
        }
    }, {
        key: "GetQuestionOrderInfoByID",
        value: function(e) {
            return this.request({
                url: "/api/Master/AutoModel",
                method: "POST",
                data: {
                    command: "GetQuestionOrderInfoByID",
                    data: JSON.stringify(e)
                }
            });
        }
    }, {
        key: "GetQuestionOrderNewInfoByID",
        value: function(e) {
            return this.request({
                url: "/api/Master/AutoModel",
                method: "POST",
                data: {
                    command: "GetQuestionOrderNewInfoByID",
                    data: JSON.stringify(e)
                }
            });
        }
    }, {
        key: "BindingQuestionOrderByTeacher",
        value: function(e) {
            return this.request({
                url: "/api/question_orders/Inner_question_orders",
                data: e,
                method: "POST"
            });
        }
    }, {
        key: "SignQuestionTeacherWorkTime",
        value: function(e) {
            return this.request({
                url: "/api/question_teacher_work/Inner_question_teacher_work",
                data: e,
                method: "POST"
            });
        }
    }, {
        key: "GetTeacherWaitAnswerCounts",
        value: function(e) {
            return this.request({
                url: "/api/Master/AutoModel",
                method: "POST",
                data: {
                    command: "GetTeacherWaitAnswerCounts",
                    data: JSON.stringify(e)
                }
            });
        }
    }, {
        key: "UpdateQuestionOrderByTeacher",
        value: function(e) {
            return this.request({
                url: "/api/question_orders/Inner_question_orders",
                data: e,
                method: "POST"
            });
        }
    }, {
        key: "UpdateQuestionOrderCommentNotesByTeacher",
        value: function(e) {
            return this.request({
                url: "/api/question_order_comments/UpdateNotes",
                data: e,
                method: "POST"
            });
        }
    }, {
        key: "ClearQuestionOrderCommentByTeacher",
        value: function(e) {
            return this.request({
                url: "/api/question_order_comments/Del_question_order_comments",
                data: e,
                method: "POST"
            });
        }
    }, {
        key: "UpdateQuestionOrderNotes",
        value: function(e) {
            return this.request({
                url: "/api/question_orders/Inner_question_orders",
                data: e,
                method: "POST"
            });
        }
    }, {
        key: "GetTeacherInfoOfAccountID",
        value: function(e) {
            return this.request({
                url: "/api/Master/AutoModel",
                method: "POST",
                data: {
                    command: "GetTeacherInfoOfAccountID",
                    data: JSON.stringify(e)
                }
            });
        }
    }, {
        key: "GetQuestionOrderCountsList",
        value: function(e) {
            return this.request({
                url: "/api/Master/AutoModel",
                method: "POST",
                data: {
                    command: "GetQuestionOrderCountsList",
                    data: JSON.stringify(e)
                }
            });
        }
    }, {
        key: "GetQuestionOrderTeacherTotalOfMonth",
        value: function(e) {
            return this.request({
                url: "/api/Master/AutoModel",
                method: "POST",
                data: {
                    command: "GetQuestionOrderTeacherTotalOfMonth",
                    data: JSON.stringify(e)
                }
            });
        }
    }, {
        key: "GetQuestionOrderTeacherAnswerListOfMonth",
        value: function(e) {
            return this.request({
                url: "/api/Master/AutoModel",
                method: "POST",
                data: {
                    command: "GetQuestionOrderTeacherAnswerListOfMonth",
                    data: JSON.stringify(e)
                }
            });
        }
    }, {
        key: "UpdateQuestionFilesGive",
        value: function(e) {
            return this.request({
                url: "/api/question_files_give/Inner_question_files_give",
                data: e,
                method: "POST"
            });
        }
    }, {
        key: "DelQuestionFilesGive",
        value: function(e) {
            return this.request({
                url: "/api/question_files_give/Del_question_files_give",
                data: e,
                method: "POST"
            });
        }
    }, {
        key: "GetQuestionFilesGive",
        value: function(e) {
            return this.request({
                url: "/api/question_files_give/GetListByAll",
                data: e
            });
        }
    }, {
        key: "GetCourseQrcodeStuID",
        value: function(e) {
            return this.request({
                url: "/api/course_qrcode_book/GetStuID",
                noLoading: !0,
                data: e
            });
        }
    } ]), u;
}(n.default);