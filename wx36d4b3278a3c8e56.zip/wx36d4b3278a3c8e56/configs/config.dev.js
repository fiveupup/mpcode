var e = require("../@babel/runtime/helpers/objectSpread2");

module.exports = e({}, {
    TOP_HOST: "https://api.tumukaoyan.com",
    HOST: "",
    _cookie: ""
});