var e = require("../@babel/runtime/helpers/objectSpread2");

module.exports = e({}, {
    TOP_HOST: "http://yjs.webapi.dezhengedu.com:9511",
    HOST: "",
    _cookie: ""
});