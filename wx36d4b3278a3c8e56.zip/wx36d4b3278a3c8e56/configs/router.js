module.exports = [ {
    pagePath: "pages/index/index",
    text: "资源",
    iconPath: "/assets/Images/index.png",
    selectedIconPath: "/assets/Images/index_select.png",
    auth: 0
}, {
    pagePath: "pages/study/study",
    iconPath: "/assets/Images/study.png",
    selectedIconPath: "/assets/Images/study_select.png",
    auth: 0
}, {
    pagePath: "pages/user/user",
    text: "我的",
    iconPath: "/assets/Images/user.png",
    selectedIconPath: "/assets/Images/user_select.png",
    auth: 0
} ];