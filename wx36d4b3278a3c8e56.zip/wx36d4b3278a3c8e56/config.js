var e = {};

e = require("configs/config.dev.js"), console.log("当前处于【开发环境】"), module.exports = e;