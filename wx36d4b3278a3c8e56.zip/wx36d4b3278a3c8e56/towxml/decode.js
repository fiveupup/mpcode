var t = require("./config"), a = getApp().window;

Component({
    options: {
        styleIsolation: "apply-shared"
    },
    properties: {
        nodes: {
            type: Object,
            value: {},
            observer: function(t) {
                t && t.child && t.child.length > 0 && t.child.map(function(t) {
                    "navigator" == t.tag && (t.islogType = 0, t.attr.href && t.attr.href.indexOf("pages/video/video") > -1 && (t.islogType = 1)), 
                    "img" == t.tag && (t.attr.islatexreplacdata = !1, (t.attr.src.indexOf("https://ojld.oss-cn-shanghai.aliyuncs.com/Yjs/202310/3309ab3a-6e97-4a8e-8fdd-c89c93614985.png") > -1 || t.attr.src.indexOf("https://ojld.oss-cn-shanghai.aliyuncs.com/Yjs/202305/c5415dcb-4ff2-4345-a7c7-4993b048f29a.png") > -1) && (t.attr.islatexreplacdata = !0, 
                    t.attr.style && a.windowWidth > 680 && (t.attr.style = "vertical-align:middle;width:40px;height:40px;")));
                }), this.setData({
                    nodes: t
                });
            }
        }
    },
    lifetimes: {
        attached: function() {
            var a = this;
            t.events.forEach(function(t) {
                a["_" + t] = function() {
                    var a;
                    global._events && "function" == typeof global._events[t] && (a = global._events)[t].apply(a, arguments);
                };
            });
        }
    }
});