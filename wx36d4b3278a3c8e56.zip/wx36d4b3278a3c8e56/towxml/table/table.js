Component({
    options: {
        styleIsolation: "shared"
    },
    properties: {
        data: {
            type: Object,
            value: {}
        }
    }
});