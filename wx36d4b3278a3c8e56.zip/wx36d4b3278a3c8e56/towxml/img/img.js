var t = require("../config");

Component({
    options: {
        styleIsolation: "shared"
    },
    properties: {
        data: {
            type: Object,
            value: {}
        }
    },
    data: {
        attr: {
            src: "",
            class: "",
            style: "",
            islatexreplacdata: !1
        },
        size: {
            w: 0,
            h: 0
        },
        styleObj: {},
        imgList: [],
        defImg: ""
    },
    lifetimes: {
        attached: function() {
            var a = this, e = this.data.data.attr;
            if (e.width && (a.data.size.w = +e.width / t.dpr), e.height && (a.data.size.h = +e.height / t.dpr), 
            e.style) {
                e.style = e.style.replace(/;\s{0,}/gi, ";"), e.style.split(";").forEach(function(e) {
                    var s = e.split(":");
                    if (/^(width|height)$/i.test(s[0])) {
                        var i = parseInt(s[1]) || 0, r = "";
                        switch (s[0].toLocaleLowerCase()) {
                          case "width":
                            r = "w";
                            break;

                          case "height":
                            r = "h";
                        }
                        a.data.size[r] = i / t.dpr;
                    } else a.data.styleObj[s[0]] = s[1];
                });
            }
            var s = !1;
            (e.src.indexOf("https://ojld.oss-cn-shanghai.aliyuncs.com/Yjs/202310/3309ab3a-6e97-4a8e-8fdd-c89c93614985.png") > -1 || e.src.indexOf("https://ojld.oss-cn-shanghai.aliyuncs.com/Yjs/202305/c5415dcb-4ff2-4345-a7c7-4993b048f29a.png") > -1) && (s = !0), 
            a.setData({
                attr: {
                    src: e.src,
                    class: e.class,
                    style: a.setStyle(a.data.styleObj),
                    islatexreplacdata: s
                },
                size: a.data.size
            });
        }
    },
    methods: {
        previewImg: function(t) {
            var a = t.currentTarget.dataset.src;
            wx.previewImage({
                current: a,
                urls: [ a ]
            });
        },
        setStyle: function(t) {
            var a = "";
            for (var e in t) a += "".concat(e, ":").concat(t[e], ";");
            return a;
        },
        load: function(a) {
            this.data.size.w && this.data.size.h || this.setData({
                size: {
                    w: a.detail.width / t.dpr,
                    h: a.detail.height / t.dpr
                }
            });
        }
    }
});