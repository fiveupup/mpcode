Component({
    options: {
        styleIsolation: "shared"
    },
    properties: {
        nodes: {
            type: Object,
            value: {},
            observer: function(t, e) {
                t != e && e && (this.setData({
                    isShow: !1
                }), this.setData({
                    isShow: !0
                }));
            }
        },
        IsDarkMode: {
            type: Boolean,
            value: !1
        }
    },
    data: {
        someData: {},
        isShow: !0,
        isShowWatermark: !1
    },
    ready: function() {
        this.setData({
            isShowWatermark: !0
        });
    }
});