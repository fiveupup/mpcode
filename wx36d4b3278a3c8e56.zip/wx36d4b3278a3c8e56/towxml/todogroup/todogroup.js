Component({
    options: {
        styleIsolation: "shared"
    },
    properties: {
        data: {
            type: Object,
            value: {}
        }
    },
    data: {},
    methods: {
        _change: function() {
            var e;
            global._events && "function" == typeof global._events.change && (e = global._events).change.apply(e, arguments);
        }
    }
});