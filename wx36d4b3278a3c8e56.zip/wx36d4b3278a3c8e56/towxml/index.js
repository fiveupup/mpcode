var e = require("./parse/markdown/index"), r = require("./parse/index"), a = [ {
    replaceoriginal: /《答案》/g,
    replaceresult: '<span style="display:inline-block; border: 1px solid #ffedd9; background-color: #ffedd9; padding: 2px 10px 2px 4px;  border-radius: 4px; color:#000;">'
}, {
    replaceoriginal: /《\/答案》/g,
    replaceresult: "</span>"
}, {
    replaceoriginal: /《解析》/g,
    replaceresult: '<span style="display:inline-block; border: 1px solid #ffedd9; background-color:  #ffedd9; padding: 4px 8px 4px 4px;margin-top:10px; border-radius: 4px; color:#000;">'
}, {
    replaceoriginal: /《\/解析》/g,
    replaceresult: "</span>"
}, {
    replaceoriginal: /《分析》/g,
    replaceresult: '<span style="display:inline-block; border: 2px dashed #ffbd74;padding: 10px; margin-top:10px; border-radius: 4px; color:#000;width:calc(100% - 24px)">'
}, {
    replaceoriginal: /《\/分析》/g,
    replaceresult: "</span>"
}, {
    replaceoriginal: /《步骤》/g,
    replaceresult: '<span style="color:#000; padding:6px 10px;margin-right:6px;margin-top:10px;border-radius:4px">'
}, {
    replaceoriginal: /《\/步骤》/g,
    replaceresult: "</span>"
}, {
    replaceoriginal: /《注释》/g,
    replaceresult: '<span style="display:inline-block; border: 1px solid #fff5ea; background-color: #fff5ea; padding: 10px; margin-top:10px; border-radius: 4px; color:#000;width:calc(100% - 22px)">'
}, {
    replaceoriginal: /《\/注释》/g,
    replaceresult: "</span>"
}, {
    replaceoriginal: /《结论》/g,
    replaceresult: '<span style="display:inline-block;  border: 2px dashed #ffbd74; padding: 10px; margin-top:10px; border-radius: 4px; color:#000;width:calc(100% - 24px)">'
}, {
    replaceoriginal: /《\/结论》/g,
    replaceresult: "</span>"
}, {
    replaceoriginal: /《其他》/g,
    replaceresult: '<span style="display:inline-block; border: 1px solid#e8f4db; background-color: #e8f4db; padding: 10px; margin-top:10px; border-radius: 4px; color:#000;width:calc(100% - 22px)">'
}, {
    replaceoriginal: /《\/其他》/g,
    replaceresult: "</span>"
}, {
    replaceoriginal: /《点评》/g,
    replaceresult: '<span style="display:inline-block; border: 2px dashed #ffe4d9;background-color: #ffe4d9; padding: 10px; margin-top:10px; border-radius: 4px;width:calc(100% - 24px)"><img src="https://ojld.oss-cn-shanghai.aliyuncs.com/Yjs/202305/c5415dcb-4ff2-4345-a7c7-4993b048f29a.png" alt="book icon" style="vertical-align:middle;width:30px;height:30px;">'
}, {
    replaceoriginal: /《\/点评》/g,
    replaceresult: "</span>"
}, {
    replaceoriginal: /《答疑注释》Q/g,
    replaceresult: '[<img src="https://ojld.oss-cn-shanghai.aliyuncs.com/Yjs/202310/3309ab3a-6e97-4a8e-8fdd-c89c93614985.png" alt="book icon" style="vertical-align:middle;width:24px;height:24px;">](/pages/qanotes/qanotes?id='
}, {
    replaceoriginal: /《\/答疑注释》/g,
    replaceresult: ")"
} ];

module.exports = function(l, p, i) {
    var o, n;
    switch (i = i || {}, "markdown" == p && l && (n = l, a.map(function(e) {
        n = n.replace(e.replaceoriginal, e.replaceresult);
    }), l = n), l && (l = (l = (l = l.replace(/\\oiint/g, "\\ooint")).replace(/\\ooint/g, "\\mathop{{\\int\\!\\!\\!\\!\\!\\int}\\mkern-21mu \\bigcirc}")).replace(/\\overgroup/g, "\\overset{\\frown}")), 
    p) {
      case "markdown":
        o = r(e(l), i);
        break;

      case "html":
        o = r(l, i);
        break;

      default:
        throw new Error("Invalid type, only markdown and html are supported");
    }
    return o;
};