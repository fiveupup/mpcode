var e = require("../../config"), r = require("./highlight");

e.highlight.forEach(function(e) {
    r.registerLanguage(e, require("./languages/".concat(e)).default);
}), module.exports = r;