Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.default = function(e) {
    var t = e.getLanguage("c-like").rawDefinition();
    return t.name = "C", t.aliases = [ "c", "h" ], t;
};