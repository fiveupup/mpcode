/*! Project:无, Create:FWS 2020.01.08 21:48, Update:FWS 2020.01.08 21:48 */
"use strict";

Object.defineProperty(exports, "__esModule", {
    value: !0
});

var e = require("./decode"), d = require("./encode");

exports.decode = function(d, o) {
    return (!o || o <= 0 ? e.decodeXML : e.decodeHTML)(d);
}, exports.decodeStrict = function(d, o) {
    return (!o || o <= 0 ? e.decodeXML : e.decodeHTMLStrict)(d);
}, exports.encode = function(e, o) {
    return (!o || o <= 0 ? d.encodeXML : d.encodeHTML)(e);
};

var o = require("./encode");

exports.encodeXML = o.encodeXML, exports.encodeHTML = o.encodeHTML, exports.escape = o.escape, 
exports.encodeHTML4 = o.encodeHTML, exports.encodeHTML5 = o.encodeHTML;

var c = require("./decode");

exports.decodeXML = c.decodeXML, exports.decodeHTML = c.decodeHTML, exports.decodeHTMLStrict = c.decodeHTMLStrict, 
exports.decodeHTML4 = c.decodeHTML, exports.decodeHTML5 = c.decodeHTML, exports.decodeHTML4Strict = c.decodeHTMLStrict, 
exports.decodeHTML5Strict = c.decodeHTMLStrict, exports.decodeXMLStrict = c.decodeXML;