/*! Project:无, Create:FWS 2020.01.08 21:48, Update:FWS 2020.01.08 21:48 */
"use strict";

function e(e) {
    var t = Object.keys(e).join("|"), n = r(e), u = new RegExp("&(?:" + (t += "|#[xX][\\da-fA-F]+|#\\d+") + ");", "g");
    return function(e) {
        return String(e).replace(u, n);
    };
}

function r(e) {
    return function(r) {
        return "#" === r.charAt(1) ? "X" === r.charAt(2) || "x" === r.charAt(2) ? s.default(parseInt(r.substr(3), 16)) : s.default(parseInt(r.substr(2), 10)) : e[r.slice(1, -1)];
    };
}

var t = function(e) {
    return e && e.__esModule ? e : {
        default: e
    };
};

Object.defineProperty(exports, "__esModule", {
    value: !0
});

var n = t(require("./maps/entities.json")), u = t(require("./maps/legacy.json")), o = t(require("./maps/xml.json")), s = t(require("./decode_codepoint"));

exports.decodeXML = e(o.default), exports.decodeHTMLStrict = e(n.default);

var a = function(e, r) {
    return e < r ? 1 : -1;
};

exports.decodeHTML = function() {
    function e(e) {
        return ";" !== e.substr(-1) && (e += ";"), i(e);
    }
    for (var t = Object.keys(u.default).sort(a), o = Object.keys(n.default).sort(a), s = 0, c = 0; s < o.length; s++) t[c] === o[s] ? (o[s] += ";?", 
    c++) : o[s] += ";";
    var d = new RegExp("&(?:" + o.join("|") + "|#[xX][\\da-fA-F]+;?|#\\d+;?)", "g"), i = r(n.default);
    return function(r) {
        return String(r).replace(d, e);
    };
}();