/*! Project:无, Create:FWS 2020.01.08 21:48, Update:FWS 2020.01.08 21:48 */
"use strict";

var e = function(e) {
    return e && e.__esModule ? e : {
        default: e
    };
};

Object.defineProperty(exports, "__esModule", {
    value: !0
});

var r = e(require("./maps/decode"));

exports.default = function(e) {
    if (e >= 55296 && e <= 57343 || e > 1114111) return "�";
    e in r.default && (e = r.default[e]);
    var t = "";
    return e > 65535 && (e -= 65536, t += String.fromCharCode(e >>> 10 & 1023 | 55296), 
    e = 56320 | 1023 & e), t + String.fromCharCode(e);
};