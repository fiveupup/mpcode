/*! Project:无, Create:FWS 2020.01.08 21:48, Update:FWS 2020.01.08 21:48 */
"use strict";

function e(e) {
    return Object.keys(e).sort().reduce(function(r, t) {
        return r[e[t]] = "&" + t + ";", r;
    }, {});
}

function r(e) {
    var r = [], t = [];
    return Object.keys(e).forEach(function(e) {
        return 1 === e.length ? r.push("\\" + e) : t.push(e);
    }), t.unshift("[" + r.join("") + "]"), new RegExp(t.join("|"), "g");
}

function t(e) {
    return "&#x" + e.charCodeAt(0).toString(16).toUpperCase() + ";";
}

function n(e, r) {
    return "&#x" + (1024 * (e.charCodeAt(0) - 55296) + e.charCodeAt(1) - 56320 + 65536).toString(16).toUpperCase() + ";";
}

function u(e, r) {
    return function(u) {
        return u.replace(r, function(r) {
            return e[r];
        }).replace(f, n).replace(p, t);
    };
}

var o = function(e) {
    return e && e.__esModule ? e : {
        default: e
    };
};

Object.defineProperty(exports, "__esModule", {
    value: !0
});

var c = e(o(require("./maps/xml.json")).default), a = r(c);

exports.encodeXML = u(c, a);

var i = e(o(require("./maps/entities.json")).default), s = r(i);

exports.encodeHTML = u(i, s);

var p = /[^\0-\x7F]/g, f = /[\uD800-\uDBFF][\uDC00-\uDFFF]/g, l = r(c);

exports.escape = function(e) {
    return e.replace(l, t).replace(f, n).replace(p, t);
};