/*! Project:无, Create:FWS 2020.01.08 21:48, Update:FWS 2020.01.08 21:48 */
"use strict";

var t = require("../../../../@babel/runtime/helpers/typeof");

Object.defineProperty(exports, "__esModule", {
    value: !0
});

var e = require("./node");

exports.Node = e.Node, exports.Element = e.Element, exports.DataNode = e.DataNode, 
exports.NodeWithChildren = e.NodeWithChildren;

var o = /\s+/g, n = {
    normalizeWhitespace: !1,
    withStartIndices: !1,
    withEndIndices: !1
}, s = function() {
    function s(e, o, s) {
        this.dom = [], this._done = !1, this._tagStack = [], this._lastNode = null, this._parser = null, 
        "function" == typeof o && (s = o, o = n), "object" == t(e) && (o = e, e = void 0), 
        this._callback = e || null, this._options = o || n, this._elementCB = s || null;
    }
    return s.prototype.onparserinit = function(t) {
        this._parser = t;
    }, s.prototype.onreset = function() {
        this.dom = [], this._done = !1, this._tagStack = [], this._lastNode = null, this._parser = this._parser || null;
    }, s.prototype.onend = function() {
        this._done || (this._done = !0, this._parser = null, this.handleCallback(null));
    }, s.prototype.onerror = function(t) {
        this.handleCallback(t);
    }, s.prototype.onclosetag = function() {
        this._lastNode = null;
        var t = this._tagStack.pop();
        t && this._parser && (this._options.withEndIndices && (t.endIndex = this._parser.endIndex), 
        this._elementCB && this._elementCB(t));
    }, s.prototype.onopentag = function(t, o) {
        var n = new e.Element(t, o);
        this.addNode(n), this._tagStack.push(n);
    }, s.prototype.ontext = function(t) {
        var n = this._options.normalizeWhitespace, s = this._lastNode;
        if (s && "text" === s.type) n ? s.data = (s.data + t).replace(o, " ") : s.data += t; else {
            n && (t = t.replace(o, " "));
            var i = new e.DataNode("text", t);
            this.addNode(i), this._lastNode = i;
        }
    }, s.prototype.oncomment = function(t) {
        if (this._lastNode && "comment" === this._lastNode.type) this._lastNode.data += t; else {
            var o = new e.DataNode("comment", t);
            this.addNode(o), this._lastNode = o;
        }
    }, s.prototype.oncommentend = function() {
        this._lastNode = null;
    }, s.prototype.oncdatastart = function() {
        var t = new e.DataNode("text", ""), o = new e.NodeWithChildren("cdata", [ t ]);
        this.addNode(o), t.parent = o, this._lastNode = t;
    }, s.prototype.oncdataend = function() {
        this._lastNode = null;
    }, s.prototype.onprocessinginstruction = function(t, o) {
        var n = new e.ProcessingInstruction(t, o);
        this.addNode(n);
    }, s.prototype.handleCallback = function(t) {
        if ("function" == typeof this._callback) this._callback(t, this.dom); else if (t) throw t;
    }, s.prototype.addNode = function(t) {
        var e = this._tagStack[this._tagStack.length - 1], o = e ? e.children : this.dom, n = o[o.length - 1];
        this._parser && (this._options.withStartIndices && (t.startIndex = this._parser.startIndex), 
        this._options.withEndIndices && (t.endIndex = this._parser.endIndex)), o.push(t), 
        n && (t.prev = n, n.next = t), e && (t.parent = e), this._lastNode = null;
    }, s.prototype.addDataNode = function(t) {
        this.addNode(t), this._lastNode = t;
    }, s;
}();

exports.DomHandler = s, exports.default = s;