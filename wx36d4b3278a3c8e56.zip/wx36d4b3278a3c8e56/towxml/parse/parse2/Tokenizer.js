/*! Project:无, Create:FWS 2020.01.08 21:48, Update:FWS 2020.01.08 21:48 */
"use strict";

function t(t) {
    return " " === t || "\n" === t || "\t" === t || "\f" === t || "\r" === t;
}

function s(t, s, i) {
    var e = t.toLowerCase();
    return t === e ? function(t, _) {
        _ === e ? t._state = s : (t._state = i, t._index--);
    } : function(_, a) {
        a === e || a === t ? _._state = s : (_._state = i, _._index--);
    };
}

function i(t, s) {
    var i = t.toLowerCase();
    return function(e, _) {
        _ === i || _ === t ? e._state = s : (e._state = 3, e._index--);
    };
}

var e = function(t) {
    return t && t.__esModule ? t : {
        default: t
    };
};

Object.defineProperty(exports, "__esModule", {
    value: !0
});

var _ = e(require("./entities/decode_codepoint")), a = e(require("./entities/maps/entities")), h = e(require("./entities/maps/legacy")), n = e(require("./entities/maps/xml")), o = s("C", 23, 16), r = s("D", 24, 16), c = s("A", 25, 16), f = s("T", 26, 16), d = s("A", 27, 16), u = i("R", 34), p = i("I", 35), b = i("P", 36), x = i("T", 37), S = s("R", 39, 1), l = s("I", 40, 1), y = s("P", 41, 1), m = s("T", 42, 1), g = i("Y", 44), A = i("L", 45), I = i("E", 46), E = s("Y", 48, 1), T = s("L", 49, 1), N = s("E", 50, 1), C = s("#", 52, 53), B = s("X", 55, 54), v = function() {
    function s(t, s) {
        this._state = 1, this._buffer = "", this._sectionStart = 0, this._index = 0, this._bufferOffset = 0, 
        this._baseState = 1, this._special = 1, this._running = !0, this._ended = !1, this._cbs = s, 
        this._xmlMode = !(!t || !t.xmlMode), this._decodeEntities = !(!t || !t.decodeEntities);
    }
    return s.prototype.reset = function() {
        this._state = 1, this._buffer = "", this._sectionStart = 0, this._index = 0, this._bufferOffset = 0, 
        this._baseState = 1, this._special = 1, this._running = !0, this._ended = !1;
    }, s.prototype._stateText = function(t) {
        "<" === t ? (this._index > this._sectionStart && this._cbs.ontext(this._getSection()), 
        this._state = 2, this._sectionStart = this._index) : this._decodeEntities && 1 === this._special && "&" === t && (this._index > this._sectionStart && this._cbs.ontext(this._getSection()), 
        this._baseState = 1, this._state = 51, this._sectionStart = this._index);
    }, s.prototype._stateBeforeTagName = function(s) {
        "/" === s ? this._state = 5 : "<" === s ? (this._cbs.ontext(this._getSection()), 
        this._sectionStart = this._index) : ">" === s || 1 !== this._special || t(s) ? this._state = 1 : "!" === s ? (this._state = 15, 
        this._sectionStart = this._index + 1) : "?" === s ? (this._state = 17, this._sectionStart = this._index + 1) : (this._state = this._xmlMode || "s" !== s && "S" !== s ? 3 : 31, 
        this._sectionStart = this._index);
    }, s.prototype._stateInTagName = function(s) {
        ("/" === s || ">" === s || t(s)) && (this._emitToken("onopentagname"), this._state = 8, 
        this._index--);
    }, s.prototype._stateBeforeCloseingTagName = function(s) {
        t(s) || (">" === s ? this._state = 1 : 1 !== this._special ? "s" === s || "S" === s ? this._state = 32 : (this._state = 1, 
        this._index--) : (this._state = 6, this._sectionStart = this._index));
    }, s.prototype._stateInCloseingTagName = function(s) {
        (">" === s || t(s)) && (this._emitToken("onclosetag"), this._state = 7, this._index--);
    }, s.prototype._stateAfterCloseingTagName = function(t) {
        ">" === t && (this._state = 1, this._sectionStart = this._index + 1);
    }, s.prototype._stateBeforeAttributeName = function(s) {
        ">" === s ? (this._cbs.onopentagend(), this._state = 1, this._sectionStart = this._index + 1) : "/" === s ? this._state = 4 : t(s) || (this._state = 9, 
        this._sectionStart = this._index);
    }, s.prototype._stateInSelfClosingTag = function(s) {
        ">" === s ? (this._cbs.onselfclosingtag(), this._state = 1, this._sectionStart = this._index + 1) : t(s) || (this._state = 8, 
        this._index--);
    }, s.prototype._stateInAttributeName = function(s) {
        ("=" === s || "/" === s || ">" === s || t(s)) && (this._cbs.onattribname(this._getSection()), 
        this._sectionStart = -1, this._state = 10, this._index--);
    }, s.prototype._stateAfterAttributeName = function(s) {
        "=" === s ? this._state = 11 : "/" === s || ">" === s ? (this._cbs.onattribend(), 
        this._state = 8, this._index--) : t(s) || (this._cbs.onattribend(), this._state = 9, 
        this._sectionStart = this._index);
    }, s.prototype._stateBeforeAttributeValue = function(s) {
        '"' === s ? (this._state = 12, this._sectionStart = this._index + 1) : "'" === s ? (this._state = 13, 
        this._sectionStart = this._index + 1) : t(s) || (this._state = 14, this._sectionStart = this._index, 
        this._index--);
    }, s.prototype._stateInAttributeValueDoubleQuotes = function(t) {
        '"' === t ? (this._emitToken("onattribdata"), this._cbs.onattribend(), this._state = 8) : this._decodeEntities && "&" === t && (this._emitToken("onattribdata"), 
        this._baseState = this._state, this._state = 51, this._sectionStart = this._index);
    }, s.prototype._stateInAttributeValueSingleQuotes = function(t) {
        "'" === t ? (this._emitToken("onattribdata"), this._cbs.onattribend(), this._state = 8) : this._decodeEntities && "&" === t && (this._emitToken("onattribdata"), 
        this._baseState = this._state, this._state = 51, this._sectionStart = this._index);
    }, s.prototype._stateInAttributeValueNoQuotes = function(s) {
        t(s) || ">" === s ? (this._emitToken("onattribdata"), this._cbs.onattribend(), this._state = 8, 
        this._index--) : this._decodeEntities && "&" === s && (this._emitToken("onattribdata"), 
        this._baseState = this._state, this._state = 51, this._sectionStart = this._index);
    }, s.prototype._stateBeforeDeclaration = function(t) {
        this._state = "[" === t ? 22 : "-" === t ? 18 : 16;
    }, s.prototype._stateInDeclaration = function(t) {
        ">" === t && (this._cbs.ondeclaration(this._getSection()), this._state = 1, this._sectionStart = this._index + 1);
    }, s.prototype._stateInProcessingInstruction = function(t) {
        ">" === t && (this._cbs.onprocessinginstruction(this._getSection()), this._state = 1, 
        this._sectionStart = this._index + 1);
    }, s.prototype._stateBeforeComment = function(t) {
        "-" === t ? (this._state = 19, this._sectionStart = this._index + 1) : this._state = 16;
    }, s.prototype._stateInComment = function(t) {
        "-" === t && (this._state = 20);
    }, s.prototype._stateAfterComment1 = function(t) {
        this._state = "-" === t ? 21 : 19;
    }, s.prototype._stateAfterComment2 = function(t) {
        ">" === t ? (this._cbs.oncomment(this._buffer.substring(this._sectionStart, this._index - 2)), 
        this._state = 1, this._sectionStart = this._index + 1) : "-" !== t && (this._state = 19);
    }, s.prototype._stateBeforeCdata6 = function(t) {
        "[" === t ? (this._state = 28, this._sectionStart = this._index + 1) : (this._state = 16, 
        this._index--);
    }, s.prototype._stateInCdata = function(t) {
        "]" === t && (this._state = 29);
    }, s.prototype._stateAfterCdata1 = function(t) {
        this._state = "]" === t ? 30 : 28;
    }, s.prototype._stateAfterCdata2 = function(t) {
        ">" === t ? (this._cbs.oncdata(this._buffer.substring(this._sectionStart, this._index - 2)), 
        this._state = 1, this._sectionStart = this._index + 1) : "]" !== t && (this._state = 28);
    }, s.prototype._stateBeforeSpecial = function(t) {
        "c" === t || "C" === t ? this._state = 33 : "t" === t || "T" === t ? this._state = 43 : (this._state = 3, 
        this._index--);
    }, s.prototype._stateBeforeSpecialEnd = function(t) {
        2 !== this._special || "c" !== t && "C" !== t ? 3 !== this._special || "t" !== t && "T" !== t ? this._state = 1 : this._state = 47 : this._state = 38;
    }, s.prototype._stateBeforeScript5 = function(s) {
        ("/" === s || ">" === s || t(s)) && (this._special = 2), this._state = 3, this._index--;
    }, s.prototype._stateAfterScript5 = function(s) {
        ">" === s || t(s) ? (this._special = 1, this._state = 6, this._sectionStart = this._index - 6, 
        this._index--) : this._state = 1;
    }, s.prototype._stateBeforeStyle4 = function(s) {
        ("/" === s || ">" === s || t(s)) && (this._special = 3), this._state = 3, this._index--;
    }, s.prototype._stateAfterStyle4 = function(s) {
        ">" === s || t(s) ? (this._special = 1, this._state = 6, this._sectionStart = this._index - 5, 
        this._index--) : this._state = 1;
    }, s.prototype._parseNamedEntityStrict = function() {
        if (this._sectionStart + 1 < this._index) {
            var t = this._buffer.substring(this._sectionStart + 1, this._index), s = this._xmlMode ? n.default : a.default;
            Object.prototype.hasOwnProperty.call(s, t) && (this._emitPartial(s[t]), this._sectionStart = this._index + 1);
        }
    }, s.prototype._parseLegacyEntity = function() {
        var t = this._sectionStart + 1, s = this._index - t;
        for (s > 6 && (s = 6); s >= 2; ) {
            var i = this._buffer.substr(t, s);
            if (Object.prototype.hasOwnProperty.call(h.default, i)) return this._emitPartial(h.default[i]), 
            void (this._sectionStart += s + 1);
            s--;
        }
    }, s.prototype._stateInNamedEntity = function(t) {
        ";" === t ? (this._parseNamedEntityStrict(), this._sectionStart + 1 < this._index && !this._xmlMode && this._parseLegacyEntity(), 
        this._state = this._baseState) : (t < "a" || t > "z") && (t < "A" || t > "Z") && (t < "0" || t > "9") && (this._xmlMode || this._sectionStart + 1 === this._index || (1 !== this._baseState ? "=" !== t && this._parseNamedEntityStrict() : this._parseLegacyEntity()), 
        this._state = this._baseState, this._index--);
    }, s.prototype._decodeNumericEntity = function(t, s) {
        var i = this._sectionStart + t;
        if (i !== this._index) {
            var e = this._buffer.substring(i, this._index), a = parseInt(e, s);
            this._emitPartial(_.default(a)), this._sectionStart = this._index;
        } else this._sectionStart--;
        this._state = this._baseState;
    }, s.prototype._stateInNumericEntity = function(t) {
        ";" === t ? (this._decodeNumericEntity(2, 10), this._sectionStart++) : (t < "0" || t > "9") && (this._xmlMode ? this._state = this._baseState : this._decodeNumericEntity(2, 10), 
        this._index--);
    }, s.prototype._stateInHexEntity = function(t) {
        ";" === t ? (this._decodeNumericEntity(3, 16), this._sectionStart++) : (t < "a" || t > "f") && (t < "A" || t > "F") && (t < "0" || t > "9") && (this._xmlMode ? this._state = this._baseState : this._decodeNumericEntity(3, 16), 
        this._index--);
    }, s.prototype._cleanup = function() {
        this._sectionStart < 0 ? (this._buffer = "", this._bufferOffset += this._index, 
        this._index = 0) : this._running && (1 === this._state ? (this._sectionStart !== this._index && this._cbs.ontext(this._buffer.substr(this._sectionStart)), 
        this._buffer = "", this._bufferOffset += this._index, this._index = 0) : this._sectionStart === this._index ? (this._buffer = "", 
        this._bufferOffset += this._index, this._index = 0) : (this._buffer = this._buffer.substr(this._sectionStart), 
        this._index -= this._sectionStart, this._bufferOffset += this._sectionStart), this._sectionStart = 0);
    }, s.prototype.write = function(t) {
        this._ended && this._cbs.onerror(Error(".write() after done!")), this._buffer += t, 
        this._parse();
    }, s.prototype._parse = function() {
        for (;this._index < this._buffer.length && this._running; ) {
            var t = this._buffer.charAt(this._index);
            1 === this._state ? this._stateText(t) : 12 === this._state ? this._stateInAttributeValueDoubleQuotes(t) : 9 === this._state ? this._stateInAttributeName(t) : 19 === this._state ? this._stateInComment(t) : 8 === this._state ? this._stateBeforeAttributeName(t) : 3 === this._state ? this._stateInTagName(t) : 6 === this._state ? this._stateInCloseingTagName(t) : 2 === this._state ? this._stateBeforeTagName(t) : 10 === this._state ? this._stateAfterAttributeName(t) : 13 === this._state ? this._stateInAttributeValueSingleQuotes(t) : 11 === this._state ? this._stateBeforeAttributeValue(t) : 5 === this._state ? this._stateBeforeCloseingTagName(t) : 7 === this._state ? this._stateAfterCloseingTagName(t) : 31 === this._state ? this._stateBeforeSpecial(t) : 20 === this._state ? this._stateAfterComment1(t) : 14 === this._state ? this._stateInAttributeValueNoQuotes(t) : 4 === this._state ? this._stateInSelfClosingTag(t) : 16 === this._state ? this._stateInDeclaration(t) : 15 === this._state ? this._stateBeforeDeclaration(t) : 21 === this._state ? this._stateAfterComment2(t) : 18 === this._state ? this._stateBeforeComment(t) : 32 === this._state ? this._stateBeforeSpecialEnd(t) : 38 === this._state ? S(this, t) : 39 === this._state ? l(this, t) : 40 === this._state ? y(this, t) : 33 === this._state ? u(this, t) : 34 === this._state ? p(this, t) : 35 === this._state ? b(this, t) : 36 === this._state ? x(this, t) : 37 === this._state ? this._stateBeforeScript5(t) : 41 === this._state ? m(this, t) : 42 === this._state ? this._stateAfterScript5(t) : 43 === this._state ? g(this, t) : 28 === this._state ? this._stateInCdata(t) : 44 === this._state ? A(this, t) : 45 === this._state ? I(this, t) : 46 === this._state ? this._stateBeforeStyle4(t) : 47 === this._state ? E(this, t) : 48 === this._state ? T(this, t) : 49 === this._state ? N(this, t) : 50 === this._state ? this._stateAfterStyle4(t) : 17 === this._state ? this._stateInProcessingInstruction(t) : 53 === this._state ? this._stateInNamedEntity(t) : 22 === this._state ? o(this, t) : 51 === this._state ? C(this, t) : 23 === this._state ? r(this, t) : 24 === this._state ? c(this, t) : 29 === this._state ? this._stateAfterCdata1(t) : 30 === this._state ? this._stateAfterCdata2(t) : 25 === this._state ? f(this, t) : 26 === this._state ? d(this, t) : 27 === this._state ? this._stateBeforeCdata6(t) : 55 === this._state ? this._stateInHexEntity(t) : 54 === this._state ? this._stateInNumericEntity(t) : 52 === this._state ? B(this, t) : this._cbs.onerror(Error("unknown _state"), this._state), 
            this._index++;
        }
        this._cleanup();
    }, s.prototype.pause = function() {
        this._running = !1;
    }, s.prototype.resume = function() {
        this._running = !0, this._index < this._buffer.length && this._parse(), this._ended && this._finish();
    }, s.prototype.end = function(t) {
        this._ended && this._cbs.onerror(Error(".end() after done!")), t && this.write(t), 
        this._ended = !0, this._running && this._finish();
    }, s.prototype._finish = function() {
        this._sectionStart < this._index && this._handleTrailingData(), this._cbs.onend();
    }, s.prototype._handleTrailingData = function() {
        var t = this._buffer.substr(this._sectionStart);
        28 === this._state || 29 === this._state || 30 === this._state ? this._cbs.oncdata(t) : 19 === this._state || 20 === this._state || 21 === this._state ? this._cbs.oncomment(t) : 53 !== this._state || this._xmlMode ? 54 !== this._state || this._xmlMode ? 55 !== this._state || this._xmlMode ? 3 !== this._state && 8 !== this._state && 11 !== this._state && 10 !== this._state && 9 !== this._state && 13 !== this._state && 12 !== this._state && 14 !== this._state && 6 !== this._state && this._cbs.ontext(t) : (this._decodeNumericEntity(3, 16), 
        this._sectionStart < this._index && (this._state = this._baseState, this._handleTrailingData())) : (this._decodeNumericEntity(2, 10), 
        this._sectionStart < this._index && (this._state = this._baseState, this._handleTrailingData())) : (this._parseLegacyEntity(), 
        this._sectionStart < this._index && (this._state = this._baseState, this._handleTrailingData()));
    }, s.prototype.getAbsoluteIndex = function() {
        return this._bufferOffset + this._index;
    }, s.prototype._getSection = function() {
        return this._buffer.substring(this._sectionStart, this._index);
    }, s.prototype._emitToken = function(t) {
        this._cbs[t](this._getSection()), this._sectionStart = -1;
    }, s.prototype._emitPartial = function(t) {
        1 !== this._baseState ? this._cbs.onattribdata(t) : this._cbs.ontext(t);
    }, s;
}();

exports.default = v;