/*! Project:无, Create:FWS 2020.01.08 21:48, Update:FWS 2020.01.08 21:48 */
"use strict";

function t(e, o) {
    var n = this;
    return n._tagname = "", n._attribname = "", n._attribvalue = "", n._attribs = null, 
    n._stack = [], n._foreignContext = [], n.startIndex = 0, n.endIndex = null, n.parseChunk = t.prototype.write, 
    n.done = t.prototype.end, n._options = o || {}, n._cbs = e || {}, n._tagname = "", 
    n._attribname = "", n._attribvalue = "", n._attribs = null, n._stack = [], n._foreignContext = [], 
    n.startIndex = 0, n.endIndex = null, n._lowerCaseTagNames = "lowerCaseTags" in n._options ? !!n._options.lowerCaseTags : !n._options.xmlMode, 
    n._lowerCaseAttributeNames = "lowerCaseAttributeNames" in n._options ? !!n._options.lowerCaseAttributeNames : !n._options.xmlMode, 
    n._tokenizer = new (n._options.Tokenizer || s.default)(n._options, n), n._cbs.onparserinit && n._cbs.onparserinit(n), 
    n;
}

var e = function(t) {
    return t && t.__esModule ? t : {
        default: t
    };
};

Object.defineProperty(exports, "__esModule", {
    value: !0
});

var s = e(require("./Tokenizer")), o = new Set([ "input", "option", "optgroup", "select", "button", "datalist", "textarea" ]), n = new Set([ "p" ]), i = {
    tr: new Set([ "tr", "th", "td" ]),
    th: new Set([ "th" ]),
    td: new Set([ "thead", "th", "td" ]),
    body: new Set([ "head", "link", "script" ]),
    li: new Set([ "li" ]),
    p: n,
    h1: n,
    h2: n,
    h3: n,
    h4: n,
    h5: n,
    h6: n,
    select: o,
    input: o,
    output: o,
    button: o,
    datalist: o,
    textarea: o,
    option: new Set([ "option" ]),
    optgroup: new Set([ "optgroup", "option" ]),
    dd: new Set([ "dt", "dd" ]),
    dt: new Set([ "dt", "dd" ]),
    address: n,
    article: n,
    aside: n,
    blockquote: n,
    details: n,
    div: n,
    dl: n,
    fieldset: n,
    figcaption: n,
    figure: n,
    footer: n,
    form: n,
    header: n,
    hr: n,
    main: n,
    nav: n,
    ol: n,
    pre: n,
    section: n,
    table: n,
    ul: n,
    rt: new Set([ "rt", "rp" ]),
    rp: new Set([ "rt", "rp" ]),
    tbody: new Set([ "thead", "tbody" ]),
    tfoot: new Set([ "thead", "tbody" ])
}, a = new Set([ "area", "base", "basefont", "br", "col", "command", "embed", "frame", "hr", "img", "input", "isindex", "keygen", "link", "meta", "param", "source", "track", "wbr" ]), r = new Set([ "math", "svg" ]), h = new Set([ "mi", "mo", "mn", "ms", "mtext", "annotation-xml", "foreignObject", "desc", "title" ]), _ = /\s|\//;

t.prototype._updatePosition = function(t) {
    null === this.endIndex ? this._tokenizer._sectionStart <= t ? this.startIndex = 0 : this.startIndex = this._tokenizer._sectionStart - t : this.startIndex = this.endIndex + 1, 
    this.endIndex = this._tokenizer.getAbsoluteIndex();
}, t.prototype.ontext = function(t) {
    this._updatePosition(1), this.endIndex--, this._cbs.ontext && this._cbs.ontext(t);
}, t.prototype.onopentagname = function(t) {
    if (this._lowerCaseTagNames && (t = t.toLowerCase()), this._tagname = t, !this._options.xmlMode && t in i) for (var e = void 0; i[t].has(e = this._stack[this._stack.length - 1]); this.onclosetag(e)) ;
    !this._options.xmlMode && a.has(t) || (this._stack.push(t), r.has(t) ? this._foreignContext.push(!0) : h.has(t) && this._foreignContext.push(!1)), 
    this._cbs.onopentagname && this._cbs.onopentagname(t), this._cbs.onopentag && (this._attribs = {});
}, t.prototype.onopentagend = function() {
    this._updatePosition(1), this._attribs && (this._cbs.onopentag && this._cbs.onopentag(this._tagname, this._attribs), 
    this._attribs = null), !this._options.xmlMode && this._cbs.onclosetag && a.has(this._tagname) && this._cbs.onclosetag(this._tagname), 
    this._tagname = "";
}, t.prototype.onclosetag = function(t) {
    if (this._updatePosition(1), this._lowerCaseTagNames && (t = t.toLowerCase()), (r.has(t) || h.has(t)) && this._foreignContext.pop(), 
    !this._stack.length || !this._options.xmlMode && a.has(t)) this._options.xmlMode || "br" !== t && "p" !== t || (this.onopentagname(t), 
    this._closeCurrentTag()); else {
        var e = this._stack.lastIndexOf(t);
        if (-1 !== e) if (this._cbs.onclosetag) for (e = this._stack.length - e; e--; ) this._cbs.onclosetag(this._stack.pop()); else this._stack.length = e; else "p" !== t || this._options.xmlMode || (this.onopentagname(t), 
        this._closeCurrentTag());
    }
}, t.prototype.onselfclosingtag = function() {
    this._options.xmlMode || this._options.recognizeSelfClosing || this._foreignContext[this._foreignContext.length - 1] ? this._closeCurrentTag() : this.onopentagend();
}, t.prototype._closeCurrentTag = function() {
    var t = this._tagname;
    this.onopentagend(), this._stack[this._stack.length - 1] === t && (this._cbs.onclosetag && this._cbs.onclosetag(t), 
    this._stack.pop());
}, t.prototype.onattribname = function(t) {
    this._lowerCaseAttributeNames && (t = t.toLowerCase()), this._attribname = t;
}, t.prototype.onattribdata = function(t) {
    this._attribvalue += t;
}, t.prototype.onattribend = function() {
    this._cbs.onattribute && this._cbs.onattribute(this._attribname, this._attribvalue), 
    this._attribs && !Object.prototype.hasOwnProperty.call(this._attribs, this._attribname) && (this._attribs[this._attribname] = this._attribvalue), 
    this._attribname = "", this._attribvalue = "";
}, t.prototype._getInstructionName = function(t) {
    var e = t.search(_), s = e < 0 ? t : t.substr(0, e);
    return this._lowerCaseTagNames && (s = s.toLowerCase()), s;
}, t.prototype.ondeclaration = function(t) {
    if (this._cbs.onprocessinginstruction) {
        var e = this._getInstructionName(t);
        this._cbs.onprocessinginstruction("!" + e, "!" + t);
    }
}, t.prototype.onprocessinginstruction = function(t) {
    if (this._cbs.onprocessinginstruction) {
        var e = this._getInstructionName(t);
        this._cbs.onprocessinginstruction("?" + e, "?" + t);
    }
}, t.prototype.oncomment = function(t) {
    this._updatePosition(4), this._cbs.oncomment && this._cbs.oncomment(t), this._cbs.oncommentend && this._cbs.oncommentend();
}, t.prototype.oncdata = function(t) {
    this._updatePosition(1), this._options.xmlMode || this._options.recognizeCDATA ? (this._cbs.oncdatastart && this._cbs.oncdatastart(), 
    this._cbs.ontext && this._cbs.ontext(t), this._cbs.oncdataend && this._cbs.oncdataend()) : this.oncomment("[CDATA[" + t + "]]");
}, t.prototype.onerror = function(t) {
    this._cbs.onerror && this._cbs.onerror(t);
}, t.prototype.onend = function() {
    if (this._cbs.onclosetag) for (var t = this._stack.length; t > 0; this._cbs.onclosetag(this._stack[--t])) ;
    this._cbs.onend && this._cbs.onend();
}, t.prototype.reset = function() {
    this._cbs.onreset && this._cbs.onreset(), this._tokenizer.reset(), this._tagname = "", 
    this._attribname = "", this._attribs = null, this._stack = [], this._cbs.onparserinit && this._cbs.onparserinit(this);
}, t.prototype.parseComplete = function(t) {
    this.reset(), this.end(t);
}, t.prototype.write = function(t) {
    this._tokenizer.write(t);
}, t.prototype.end = function(t) {
    this._tokenizer.end(t);
}, t.prototype.pause = function() {
    this._tokenizer.pause();
}, t.prototype.resume = function() {
    this._tokenizer.resume();
}, exports.Parser = t;