/*! Project:无, Create:FWS 2020.01.08 21:48, Update:FWS 2020.01.08 21:48 */ var e = require("./domhandler/index"), r = require("./Parser");

module.exports = function(n, d) {
    var o = new e.DomHandler(void 0, d);
    return new r.Parser(o, d).end(n), o.dom;
};