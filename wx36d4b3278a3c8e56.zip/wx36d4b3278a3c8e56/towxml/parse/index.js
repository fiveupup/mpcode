var t, e = require("../../@babel/runtime/helpers/toConsumableArray"), a = require("./parse2/index"), r = require("../config"), c = (t = {
    a: "navigator",
    todogroup: "checkbox-group",
    audio: "audio-player"
}, [].concat(e(r.wxml), e(r.components)).forEach(function(e) {
    t[e] = e;
}), t), n = function(t, e) {
    var a, r = {
        theme: e.theme || "light",
        _e: {}
    }, n = global._events = {}, i = e.base;
    if (global._theme = r.theme, e.events) for (var o in e.events) n[o] = e.events[o];
    return (a = function(t, e, r) {
        e.child = e.child || [], r.child = r.child || [], t.forEach(function(t) {
            if ("comment" !== t.type) {
                var n, o = {}, s = {};
                if (o.type = s.type = t.type, o._e = s, "text" === t.type) o.text = s.text = t.data; else {
                    if (o.tag = (n = t.name) ? c[n] || "view" : void 0, s.tag = t.name, o.attr = t.attribs, 
                    s.attr = JSON.parse(JSON.stringify(t.attribs)), o.attr.class = o.attr.class ? "h2w__".concat(t.name, " ").concat(o.attr.class) : "h2w__".concat(t.name), 
                    i && o.attr.src) {
                        var h = o.attr.src;
                        switch (h.indexOf("//")) {
                          case 0:
                            o.attr.src = "https:".concat(h);
                            break;

                          case -1:
                            o.attr.src = "".concat(i).concat(h);
                        }
                    }
                    t.children && a(t.children, o, s);
                }
                r.child.push(s), e.child.push(o);
            }
        });
    })(t, r, r._e), r;
};

module.exports = function(t, e) {
    var r;
    return t = (r = /<body[^>]*>([\s\S]*)<\/body>/i).test(t) && r.exec(t)[1] || t, n(a(t, {
        decodeEntities: !0
    }), e);
};