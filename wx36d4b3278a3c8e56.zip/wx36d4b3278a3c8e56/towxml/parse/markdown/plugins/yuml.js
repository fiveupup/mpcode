require("../../../config");

module.exports = function(e) {
    var r = e.renderer.rules.fence.bind(e.renderer.rules);
    e.renderer.rules.fence = function(e, n, u, t, o) {
        var c = e[n], i = c.content.trim();
        return "yuml" === c.info ? function(e) {
            return '<yuml value="'.concat(encodeURIComponent(e), '"></yuml>');
        }(i) : r(e, n, u, t, o);
    };
};