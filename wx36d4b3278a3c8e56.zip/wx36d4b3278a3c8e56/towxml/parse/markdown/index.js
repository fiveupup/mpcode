var e, r = require("../../../@babel/runtime/helpers/toConsumableArray");

e = require("../highlight/index");

var n, t = require("../../config"), i = (n = {
    html: !0,
    xhtmlOut: !0,
    typographer: !0,
    breaks: !0
}, t.highlight.length && e && (n.highlight = function(r, n, i) {
    var o = r.split(/\r|\n/gi).length, u = e.highlightAuto(r).value;
    return u = u.replace(/\r|\n/g, "<br/>").replace(/ /g, "&nbsp;").replace(/\t/g, "&nbsp;&nbsp;&nbsp;&nbsp;"), 
    t.showLineNumber ? function() {
        for (var e = '<ul class="h2w__lineNum">', r = 0; r < o - 1; r++) e += '<li class="h2w__lineNumLine">'.concat(r + 1, "</li>");
        return e += "</ul>";
    }() + u : u;
}), n), o = require("./markdown")(i);

[].concat(r(t.markdown), r(t.components)).forEach(function(e) {
    /^audio-player|table|todogroup|img$/.test(e) || o.use(require("./plugins/".concat(e)));
}), o.renderer.rules.emoji = function(e, r) {
    var n = e[r];
    return '<g-emoji class="h2w__emoji h2w__emoji--'.concat(n.markup, '">').concat(n.content, "</g-emoji>");
}, module.exports = function(e) {
    return o.render(e);
};