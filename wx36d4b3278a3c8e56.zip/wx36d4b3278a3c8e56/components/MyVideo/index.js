var e = 0, t = 0, i = 0, a = null, o = getApp();

o.window;

Component({
    properties: {
        isIOS: {
            type: Boolean,
            value: o.globalData.isIOS
        },
        width: {
            type: String,
            value: "calc(100%)"
        },
        height: {
            type: String,
            value: "270rpx"
        },
        autoplay: {
            type: Boolean,
            value: !1
        },
        loop: {
            type: Boolean,
            value: !1
        },
        muted: {
            type: Boolean,
            value: !1
        },
        initialtime: {
            type: Number,
            value: 0
        },
        poster: {
            type: String,
            value: ""
        },
        vid: {
            type: String,
            observer: function(a) {
                t = 0, e = 0, i = 0;
                var n = !1, s = !1, d = !1, l = o.globalData.appInfo;
                d = !(!l || 1 != l.VideoLogoState) && {
                    width: l.VideoLogoWidth + "px",
                    height: l.VideoLogoHight + "px",
                    src: l.VideoLogo,
                    xOffset: l.VideoxOffset + "%",
                    yOffset: l.VideoyOffset + "%"
                }, n = 1 == l.VideoTopEnable && {
                    enable: !0,
                    duration: l.VideoTopDuration,
                    src: l.VideoTop,
                    showskipbtn: 1 == l.VideoTopSkip
                }, s = 1 == l.VideoEndEnable && {
                    enable: !0,
                    duration: l.VideoEndDuration,
                    src: l.VideoEnd,
                    showskipbtn: 1 == l.VideoEndSkip
                }, this.data.initialtime > 0 && n && (n.enable = !1), n && (this.data.autoplay = !0), 
                this.setData({
                    videoPlay: !1,
                    playAlls: !0,
                    duration: 0,
                    videoIntroData: n,
                    videoOutroData: s,
                    logoData: d
                }), this.getSourceVideoPlay(a);
            }
        },
        isAllowSeek: {
            type: String,
            value: "yes"
        },
        isVip: {
            type: Boolean,
            observer: function(e) {
                this.setData({
                    isVip: e
                });
            }
        },
        bookID: {
            type: Number
        },
        isquestion: {
            type: Boolean
        }
    },
    lifetimes: {
        ready: function() {
            this.setData({
                autoplay: this.data.initialtime > 0 || this.data.autoplay
            });
        },
        detached: function() {
            this.triggerEvent("videoPause", e);
        }
    },
    pageLifetimes: {
        show: function() {},
        hide: function() {
            this.triggerEvent("videoPause", e);
        },
        resize: function(e) {}
    },
    data: {
        videoPlay: !1,
        playAlls: !0,
        duration: 0,
        videoIntroData: !1,
        videoOutroData: !1,
        logoData: !1,
        isiosservice: !1,
        isloadedmetadata: !1
    },
    methods: {
        gotovippage: function() {
            this.data.isIOS ? this.setData({
                isiosservice: !0
            }) : wx.navigateTo({
                url: "/wenjuan/pages/VIPInfo/VIPInfo"
            });
        },
        hideIosService: function() {
            this.setData({
                isiosservice: !1
            });
        },
        getSourceVideoPlay: function(e) {
            a = this.selectComponent("#bookVideo");
        },
        videoProgress: function(e) {},
        loadedmetadata: function(e) {
            console.log(e), this.setData({
                isloadedmetadata: !0
            });
        },
        videoWaiting: function(e) {},
        videoPlay: function(e) {
            this.setData({
                videoPlay: !0
            });
        },
        videoPause: function(t) {
            this.triggerEvent("videoPause", e), this.setData({
                videoPlay: !1
            });
        },
        videoEnd: function(t) {
            this.setData({
                videoPlay: !1
            }), this.triggerEvent("videoEnd", e);
        },
        timeUpdate: function(o) {
            "no" == this.data.isAllowSeek ? (o.detail.currentTime > i + 1 || o.detail.currentTime < i - 1) && (o.detail.currentTime = i, 
            a.seek(o.detail.currentTime)) : "ifViewed" == this.data.isAllowSeek && o.detail.currentTime > t + 1 && (o.detail.currentTime = t, 
            a.seek(o.detail.currentTime)), t < o.detail.currentTime && (t = o.detail.currentTime), 
            e = Math.floor(o.detail.currentTime), this.triggerEvent("timeUpdate", o.detail);
        }
    }
});