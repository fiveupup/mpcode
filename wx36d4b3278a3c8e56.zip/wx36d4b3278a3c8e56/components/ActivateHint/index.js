Component({
    properties: {},
    data: {},
    methods: {
        clearModel: function() {
            this.triggerEvent("clickclear", {});
        },
        gotodetail: function() {
            this.clearModel(), wx.navigateTo({
                url: "/user/pages/FunctionActivate/FunctionActivate"
            });
        }
    }
});