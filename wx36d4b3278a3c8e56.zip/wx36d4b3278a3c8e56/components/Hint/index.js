Component({
    properties: {
        props: {
            type: Object
        },
        titlecolor: {
            type: String
        },
        isbtn2: {
            type: Boolean,
            value: !1
        },
        IsDarkMode: {
            type: Boolean,
            value: !1
        }
    },
    data: {},
    methods: {
        clickclear: function() {
            this.triggerEvent("clickclear", {});
        },
        clickbtn: function(t) {
            this.triggerEvent("clickbtn", {
                id: t.currentTarget.dataset.id
            });
        }
    }
});