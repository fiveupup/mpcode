var t, i = require("../../@babel/runtime/helpers/defineProperty"), a = (t = require("../../utils/util")) && t.__esModule ? t : {
    default: t
}, n = require("../../api/course"), o = require("../../api/user"), e = require("../../api/product.js"), s = require("../../api/question.js");

var u = new n.Course(), r = getApp(), l = r.window, d = new o.User(), h = new e.Product(), p = new s.Question(), c = [ {
    type: "题目解析",
    IsNotVipLook: !0,
    IsNoVipLookVideo: !0,
    noVipImg: "http://ysj-question.oss-cn-hangzhou.aliyuncs.com/Yjs/202205/0478d570-5ae9-46a5-8d10-4ab466701ffc.png",
    BusID: !1
}, {
    type: "视频解析",
    IsNotVipLook: !1,
    IsNoVipLookVideo: !1,
    noVipImg: "http://ysj-question.oss-cn-hangzhou.aliyuncs.com/Yjs/202205/0c64bab1-63c7-42d7-8e82-bf967715ed21.png",
    BusID: !1
}, {
    type: "知识点",
    IsNotVipLook: !1,
    IsNoVipLookVideo: !1,
    noVipImg: "",
    BusID: !1
}, {
    type: "疑难点",
    IsNotVipLook: !1,
    IsNoVipLookVideo: !1,
    noVipImg: "http://ysj-question.oss-cn-hangzhou.aliyuncs.com/Yjs/202205/368e3b87-eff7-4ae8-8adc-685cf319030f.png",
    BusID: !1
}, {
    type: "讨论区",
    IsNotVipLook: !0,
    IsNoVipLookVideo: !0,
    noVipImg: "",
    BusID: !1
}, {
    type: "骚操作",
    IsNotVipLook: !1,
    IsNoVipLookVideo: !1,
    noVipImg: "http://ysj-question.oss-cn-hangzhou.aliyuncs.com/Yjs/202205/061f6efa-6517-41bf-ab35-222807b71dd4.png",
    BusID: !1
}, {
    type: "考点",
    IsNotVipLook: !1,
    IsNoVipLookVideo: !1,
    noVipImg: "http://ysj-question.oss-cn-hangzhou.aliyuncs.com/Yjs/202205/c123018c-cfa2-47e5-bbc0-625fd04a8e52.png",
    BusID: !1
}, {
    type: "一题多解",
    IsNotVipLook: !1,
    IsNoVipLookVideo: !1,
    noVipImg: "http://ysj-question.oss-cn-hangzhou.aliyuncs.com/Yjs/202205/6544faa6-4b36-4e46-b37e-7692c33327ee.png",
    BusID: !1
}, {
    type: "重要结论",
    IsNotVipLook: !1,
    IsNoVipLookVideo: !1,
    noVipImg: "http://ysj-question.oss-cn-hangzhou.aliyuncs.com/Yjs/202205/4ffe8f0d-d77e-4342-bc56-25e7ff115660.png",
    BusID: !1
}, {
    type: "举一反三",
    IsNotVipLook: !1,
    IsNoVipLookVideo: !1,
    noVipImg: "http://ysj-question.oss-cn-hangzhou.aliyuncs.com/Yjs/202205/92e7ff34-6a3c-44be-8919-6a2fc370dc70.png",
    BusID: !1
} ];

Component({
    options: {
        addGlobalClass: !0
    },
    properties: {
        isleadfillcourse: {
            type: Boolean,
            value: !1
        },
        yidoList: {
            type: Array
        },
        SourceQuestionID: {
            type: Number,
            value: 0
        },
        isSubmitExtrapolation: {
            type: Boolean,
            value: !1,
            observer: function(t) {
                t && this.data.SourceQuestionID > 0 && this.getQuestionExtrapolationList();
            }
        },
        isVip: {
            type: Boolean
        },
        QuestionInfo: {
            type: Object,
            observer: function(t) {
                var i = this;
                t && t.ID > 0 && t.ID != this.data.QuestionID && (this.setData({
                    userInfo: r.globalData.userInfo,
                    QuestionID: t.ID,
                    isFrist: !1,
                    isHaveVipLookCount: r.globalData.appInfo.VipLookCount > 0,
                    isloading: !1,
                    VipLookCount: r.globalData.appInfo.VipLookCount,
                    AnalysisShow: !0,
                    VLinkShow: !0,
                    DisturbShow: !0,
                    TestingShow: !0,
                    MultisolutionShow: !0,
                    RubShow: !0,
                    ImportantShow: !0,
                    ExtrapolationShow: !0,
                    DiscussListShow: !0,
                    tabIndex: 0,
                    OtherInfo: {},
                    BoxHaveValue: 0,
                    isBetaVipProduct: r.globalData.isBetaVipProduct,
                    isBetaDYVipProduct: r.globalData.isBetaDYVipProduct,
                    isdataLoading: !1,
                    bookID: t.BookID,
                    questioninfotop: 0,
                    top: 0,
                    navlist: [ {
                        text: "不跳步",
                        num: 0,
                        Isselect: !0,
                        IsPackUp: 3,
                        height: 0
                    }, {
                        text: "视频解析",
                        num: 1,
                        Isselect: !1,
                        IsPackUp: 3,
                        height: 0
                    }, {
                        text: "疑难点",
                        num: 2,
                        Isselect: !1,
                        IsPackUp: 3,
                        height: 0
                    }, {
                        text: "秒杀技巧",
                        num: 3,
                        Isselect: !1,
                        IsPackUp: 3,
                        height: 0
                    }, {
                        text: "考点",
                        num: 4,
                        Isselect: !1,
                        IsPackUp: 3,
                        height: 0
                    }, {
                        text: "一题多解",
                        num: 5,
                        Isselect: !1,
                        IsPackUp: 3,
                        height: 0
                    }, {
                        text: "重要结论",
                        num: 6,
                        Isselect: !1,
                        IsPackUp: 3,
                        height: 0
                    }, {
                        text: "举一反三",
                        num: 7,
                        Isselect: !1,
                        IsPackUp: 3,
                        height: 0
                    } ],
                    QuestionErrorBaseType: "",
                    temptop: 0,
                    dianzanlist: [],
                    boxHeight: 0
                }), r.globalData.appInfo.VipLookCount > 0 && setTimeout(function() {
                    i.getVipLookCountList(t.ID);
                }, 200), this.GetQuestionFilesGive(), this.data.isVip || this.data.isVipNo || this.getNoVipImgList());
            }
        },
        QusetionExamine: {
            type: Array
        },
        isExtrapolationShow: {
            type: Boolean,
            value: !0
        },
        isFinish: {
            type: Boolean,
            value: !0
        },
        iswikifixed: {
            type: Boolean,
            value: !1
        },
        isShowVipLog: {
            type: Boolean,
            value: !0
        },
        isgetdifficulty: {
            type: Boolean,
            value: !1
        },
        isShowProduct: {
            type: Boolean,
            value: !0
        },
        isexam: {
            type: Boolean,
            value: !1
        },
        isShowVLink: {
            type: Boolean,
            value: !0
        },
        isshowAnalysis: {
            type: Boolean,
            value: !1,
            observer: function(t, i) {
                var a = this, n = [ 0, 0 ];
                this.data.isShowNavber && this.data.navlistshow && this.data.isshowAnalysis && this.data.isdataLoading && this.data.navlist.length > 1 && wx.createSelectorQuery().in(this).select(".questionInfo_posinav").boundingClientRect(function(t) {
                    t ? (n[0] = 2 * (l.windowWidth - t.width + 40), n[1] = l.windowHeight, a.setData({
                        tuodoheight: t.height
                    })) : a.setData({
                        tuodoheight: 100
                    });
                }).exec();
            }
        },
        ScrollTop: {
            type: Number,
            observer: function(t, i) {
                var a = this, n = this.data.navlist;
                if (n.map(function(t) {
                    t.height = 0;
                }), this.data.isloading && this.data.isshowAnalysis) {
                    var o = 0;
                    wx.createSelectorQuery().in(a).selectAll(".locationclass").boundingClientRect(function(t) {
                        Array.isArray(t) && t.length > 0 && t.map(function(t) {
                            t.id && (t.numindex = parseInt(t.id.replace(/[^\d]/g, " "))), n[t.numindex].height = o, 
                            o += t.height;
                        }), a.setnavlistIsselect(n);
                    }).exec();
                }
            }
        },
        locationtop: {
            type: Number,
            observer: function(t) {
                0 == this.data.questioninfotop && (this.data.questioninfotop = t);
            }
        },
        IsDarkMode: {
            type: Boolean,
            value: !1,
            observer: function(t) {
                this.data.bookID > 0 && this.data.isdataLoading && (this.GetQuestionFilesGive(), 
                this.data.isVip || this.data.isVipNo || this.getNoVipImgList());
            }
        },
        isShowNavber: {
            type: Boolean,
            value: !0
        }
    },
    pageLifetimes: {
        show: function() {
            this.data.isFrist || this.getQuestionExtrapolationList(), this.setData({
                isFrist: !1
            });
        }
    },
    data: {
        StuID: r.globalData.StuID,
        AnalysisShow: !0,
        VLinkShow: !0,
        DisturbShow: !0,
        TestingShow: !0,
        MultisolutionShow: !0,
        RubShow: !0,
        ImportantShow: !0,
        ExtrapolationShow: !0,
        DiscussListShow: !0,
        OtherInfo: {},
        QuestionID: 0,
        bookID: 0,
        AnswerImgShow: !0,
        LinkVideoListShow: !1,
        QuestionVideoListShow: !1,
        isOpenSubscribeDialog: !1,
        userInfo: {},
        vipConfigs: c,
        QuestionVideoList: [],
        isFrist: !0,
        isHaveVipLookCount: !1,
        VipLookCount: 3,
        isVipLookCount: !1,
        VipLookQuestionCountList: [],
        VipLookmodel: {
            isshowClear: !1,
            title: "提示",
            titlecolor: "#CF4935",
            content: "每天可免费查看3次，当前剩余3次",
            btnList: [ {
                content: "取消",
                bgcolor: "#F3F3F3",
                color: "#333333",
                id: 2
            }, {
                content: "免费获取",
                bgcolor: "#F3F3F3",
                color: "#333333",
                id: 1
            } ]
        },
        isShowVipLook: !1,
        isVipModelShow: !0,
        isloading: !1,
        tabIndex: 0,
        BoxHaveValue: 0,
        window: l,
        DoExtrapolationList: [],
        NoDoExtrapolationList: [],
        isBetaVipProduct: !1,
        isBetaDYVipProduct: !1,
        isLookAd: !1,
        isdataLoading: !1,
        top: 0,
        navlist: [ {
            text: "不跳步",
            num: 0,
            Isselect: !0,
            IsPackUp: 3,
            height: 0
        }, {
            text: "视频解析",
            num: 1,
            Isselect: !1,
            IsPackUp: 3,
            height: 0
        }, {
            text: "疑难点",
            num: 2,
            Isselect: !1,
            IsPackUp: 3,
            height: 0
        }, {
            text: "秒杀技巧",
            num: 3,
            Isselect: !1,
            IsPackUp: 3,
            height: 0
        }, {
            text: "考点",
            num: 4,
            Isselect: !1,
            IsPackUp: 3,
            height: 0
        }, {
            text: "一题多解",
            num: 5,
            Isselect: !1,
            IsPackUp: 3,
            height: 0
        }, {
            text: "重要结论",
            num: 6,
            Isselect: !1,
            IsPackUp: 3,
            height: 0
        }, {
            text: "举一反三",
            num: 7,
            Isselect: !1,
            IsPackUp: 3,
            height: 0
        } ],
        navlistshow: !0,
        QuestionErrorBaseType: "",
        temptop: 0,
        dianzanlist: [],
        boxHeight: 0,
        questioninfotop: 0,
        isExtrapolationEnd: !1,
        tuodoheight: 0,
        isIOS: r.globalData.isIOS,
        navlistlength: 8,
        isiosservice: !1,
        IosServiceimg: ""
    },
    lifetimes: {
        ready: function() {
            this.setData({
                vipConfigs: c
            });
        }
    },
    methods: {
        showvipIosService: function() {
            console.log(121, 1212), this.triggerEvent("showIosService", !0);
        },
        hideIosService: function() {
            this.setData({
                isiosservice: !1
            });
        },
        showIosService: function(t) {
            this.data.isIOS ? this.triggerEvent("showIosService", !0) : wx.navigateTo({
                url: "/wenjuan/pages/VIPInfo/VIPInfo"
            });
        },
        getSysdata: function() {
            this.data.isloading, this.data.isshowAnalysis;
            wx.getSystemInfo({
                success: function(t) {
                    return this.data.isShowNavber && this.data.navlistshow && this.data.isshowAnalysis && this.data.isdataLoading && this.data.navlist.length > 1 && wx.createSelectorQuery().select(".questionInfo_posinav").boundingClientRect(function(t) {
                        return console.log(t, "resres"), !1;
                    }).exec(), !1;
                },
                fail: function(t) {
                    console.log(t);
                }
            });
        },
        touchmove: function(t) {},
        touchEnd: function(t) {},
        setnavlistIsselect: function(t) {
            for (var i = 0, a = 0; a < t.length; a++) t[a].Isselect = !1, 1 == t[a].IsPackUp && t[a].height - this.data.ScrollTop + this.data.questioninfotop < 50 && (i = a);
            t[i].Isselect = !0, this.setData({
                navlist: t
            });
        },
        golocation: function(t) {
            var i = this, a = t.currentTarget.dataset.index;
            wx.createSelectorQuery().in(this).select("#location" + a).boundingClientRect(function(t) {
                i.triggerEvent("gotolocation", t);
            }).exec();
            var n = this.data.navlist;
            n.map(function(t, i) {
                t.num == a ? t.Isselect = !0 : t.Isselect = !1;
            }), this.setData({
                navlist: n
            });
        },
        PackUp: function() {
            var t = this;
            (this.setData({
                navlistshow: !this.data.navlistshow
            }), this.data.navlistshow) && wx.createSelectorQuery().in(this).select(".questionInfo_posinav").boundingClientRect(function(i) {
                if (i) {
                    var a = [ 0, 0 ];
                    a[0] = 2 * (l.windowWidth - i.width + 40), a[1] = l.windowHeight;
                    var n;
                    n = i.height, t.setData({
                        tuodoheight: n
                    });
                } else t.setData({
                    tuodoheight: 100
                });
            }).exec();
        },
        showQuestionError: function(t) {
            console.log(111);
            var i = t.currentTarget.dataset.text;
            i = i || t.detail, this.setData({
                QuestionErrorBaseType: i,
                isShowQuestionError: !0
            }), this.triggerEvent("showQuestionMode", i);
        },
        hideQuestionError: function() {
            this.setData({
                isShowQuestionError: !1
            });
        },
        fewerShowfalse: function() {
            this.setData({
                DisturbShow: !1,
                RubShow: !1,
                TestingShow: !1,
                MultisolutionShow: !1,
                ImportantShow: !1,
                ExtrapolationShow: !1
            });
        },
        showQuestion: function(t) {
            var i = t.currentTarget.dataset.item;
            this.triggerEvent("showQuestionMode", i);
        },
        changeTab: function(t) {
            var i = t.currentTarget.dataset.index;
            i != this.data.tabIndex && this.setData({
                tabIndex: i
            });
        },
        showEcamine: function() {
            this.setData({
                QusetionExamineShow: this.data.QusetionExamineShow
            });
        },
        getBookConfig: function(t) {
            var i = this;
            t > 0 && u.GetBookConfig({
                page: 0,
                limit: 1e3,
                IsValid: 1,
                BookID: t,
                SortDesc: "ID"
            }).then(function(t) {
                var a = c, n = !0;
                Array.isArray(t.data) && t.data.length > 0 && t.data.map(function(t) {
                    a.map(function(i) {
                        t.Type == i.type && (i.IsNotVipLook = 1 == t.IsNotVipLook, i.IsNoVipLookVideo = 1 == t.IsNoVipLookVideo, 
                        i.BusID = 0 == t.BusID, i.IsNotVipLook || (n = i.IsNotVipLook));
                    });
                });
                var o = !1;
                a.map(function(t, i) {
                    0 == i || 1 == i ? t.IsNotVipLook && t.IsNoVipLookVideo || (o = !0) : (9 == t && isExtrapolationShow, 
                    t.IsNotVipLook || (o = !0));
                }), i.setData({
                    vipConfigs: a,
                    isVipModelShow: o
                }), i.GetQuestionFilesGive(), i.data.isVip || n || i.getNoVipImgList();
            });
        },
        addTopicInfoClickRecord: function(t) {
            var i = {
                BusType: t,
                QuestionID: this.data.QuestionInfo.ID,
                AddPerson: r.globalData.StuID,
                Notes: "详情点击记录",
                System_Station_ID: r.globalData.SassID
            };
            u.addTopicInfoClickRecord(i).then(function(t) {});
        },
        gotoExtrapolationQuestion: function(t) {
            if (this.data.isVipLookCount || this.data.isVip || this.data.vipConfigs[9].IsNotVipLook) if (1 == t) ; else {
                var i = t.currentTarget.dataset.item, a = "/topic/pages/Extrapolation/Extrapolation?courseID=" + i.ID + "&bookID=" + i.BookID + "&SourceQuestionID=" + this.data.QuestionID;
                a = i.IsDiscuss > 0 ? "/topic/pages/Extrapolation/Extrapolation?courseID=" + i.ID + "&bookID=" + i.BookID + "&SourceQuestionID=" + this.data.QuestionID + "&isLook=true" : "/topic/pages/Extrapolation/Extrapolation?courseID=" + i.ID + "&bookID=" + i.BookID + "&SourceQuestionID=" + this.data.SourceQuestionID + "&isLook=true", 
                wx.navigateTo({
                    url: a
                });
            } else this.getvipinfo();
        },
        gotovideo: function(t) {
            var i = t.currentTarget.dataset.item;
            wx.navigateTo({
                url: "/topic/pages/video?vid=" + i.BusValue
            });
        },
        getQuestionOtherInfo: function() {
            var t = this, i = this;
            if (this.data.QuestionID > 0) {
                this.setData({
                    OtherInfo: {
                        Analysis: [],
                        Difficulty: [],
                        VLink: [],
                        Disturb: [],
                        Testing: [],
                        Multisolution: [],
                        Rub: [],
                        Important: [],
                        Extrapolation: []
                    }
                });
                try {
                    h.GetQuestionOtherInfoNew({
                        ID: this.data.QuestionID,
                        System_Station_ID: r.globalData.SassID,
                        SortDesc: "Sort"
                    }).then(function(a) {
                        if (Array.isArray(a.data)) {
                            var n = {
                                Analysis: [],
                                Difficulty: [],
                                VLink: [],
                                Disturb: [],
                                Testing: [],
                                Multisolution: [],
                                Rub: [],
                                Important: [],
                                Extrapolation: []
                            }, o = t.data.navlist, e = t.data.dianzanlist, s = (r.globalData.StuID, []);
                            t.data.QuestionInfo.AnalysisScore && t.data.QuestionInfo.AnalysisScore.length > 0 && (s = t.data.QuestionInfo.AnalysisScore).map(function(t) {
                                t.ishave = !1;
                            }), a.data.map(function(a) {
                                1 == a.IsValid && (a.dianzancount = a.Give, a.isidanzan = !1, "知识库" == a.BusUrl && a.BusID > 0 && a._question_code && (a.Context = a._question_code.Content, 
                                "考点" == a.BusType && (a.BusValue = a._question_code.Title)), i.data.IsDarkMode ? "难度" == a.BusType ? (n.Difficulty.push(a), 
                                t.data.isgetdifficulty && t.triggerEvent("getdifficulty", a.BusValue)) : "视频解析" == a.BusType ? (0 == a.IsExamCourse && n.VLink.push(a), 
                                t.data.isleadfillcourse && 1 == a.IsExamCourse && n.VLink.push(a)) : "骚操作" == a.BusType ? a.Context && (a.Context = r.towxml(a.Context, "markdown", {
                                    theme: "dark"
                                }), n.Disturb.push(a)) : "考点" == a.BusType ? a.Context && (a.Context = r.towxml(a.Context, "markdown", {
                                    theme: "dark"
                                }), n.Testing.push(a)) : "一题多解" == a.BusType ? a.Context && (a.Context = r.towxml(a.Context, "markdown", {
                                    theme: "dark"
                                }), n.Multisolution.push(a)) : "疑难点" == a.BusType ? a.Context && (a.Context = r.towxml(a.Context, "markdown", {
                                    theme: "dark"
                                }), n.Rub.push(a)) : "重要结论" == a.BusType ? a.Context && (a.Context = r.towxml(a.Context, "markdown", {
                                    theme: "dark"
                                }), n.Important.push(a)) : "题目详解" == a.BusType && a.Context && (s.length > 0 && s.map(function(t) {
                                    !t.ishave && a.Context.indexOf("\x3c!--分数--\x3e") > -1 && (a.Context = a.Context.replace("\x3c!--分数--\x3e", "$\\color{#ff0000}{(" + t.Score + "分)}$"), 
                                    t.ishave = !0);
                                }), a.Context = r.towxml(a.Context, "markdown", {
                                    theme: "dark"
                                }), n.Analysis.push(a)) : "难度" == a.BusType ? (n.Difficulty.push(a), t.data.isgetdifficulty && t.triggerEvent("getdifficulty", a.BusValue)) : "视频解析" == a.BusType ? (0 == a.IsExamCourse && n.VLink.push(a), 
                                t.data.isleadfillcourse && 1 == a.IsExamCourse && n.VLink.push(a)) : "骚操作" == a.BusType ? a.Context && (a.Context = r.towxml(a.Context, "markdown"), 
                                n.Disturb.push(a)) : "考点" == a.BusType ? a.Context && (a.Context = r.towxml(a.Context, "markdown"), 
                                n.Testing.push(a)) : "一题多解" == a.BusType ? a.Context && (a.Context = r.towxml(a.Context, "markdown"), 
                                n.Multisolution.push(a)) : "疑难点" == a.BusType ? a.Context && (a.Context = r.towxml(a.Context, "markdown"), 
                                n.Rub.push(a)) : "重要结论" == a.BusType ? a.Context && (a.Context = r.towxml(a.Context, "markdown"), 
                                n.Important.push(a)) : "题目详解" == a.BusType && a.Context && (s.length > 0 && s.map(function(t) {
                                    !t.ishave && a.Context.indexOf("\x3c!--分数--\x3e") > -1 && (a.Context = a.Context.replace("\x3c!--分数--\x3e", "$\\color{#ff0000}{(" + t.Score + "分)}$"), 
                                    t.ishave = !0);
                                }), a.Context = r.towxml(a.Context, "markdown"), n.Analysis.push(a)));
                            }), e.map(function(t) {
                                "视频解析" == t.BusType ? 1 == n.VLink.length && (n.VLink[0].isidanzan = !0) : "骚操作" == t.BusType ? n.Disturb.length > 1 ? n.Rub.map(function(i, a) {
                                    t.BusID == i.ID && (i.isidanzan = !0);
                                }) : 1 == n.Disturb.length && (n.Disturb[0].isidanzan = !0) : "考点" == t.BusType ? n.Testing.length > 1 ? n.Testing.map(function(i, a) {
                                    t.BusID == i.ID && (i.isidanzan = !0);
                                }) : 1 == n.Testing.length && (n.Testing[0].isidanzan = !0) : "一题多解" == t.BusType ? 1 == n.Multisolution.length && (n.Multisolution[0].isidanzan = !0) : "疑难点" == t.BusType ? n.Rub.length > 1 ? n.Rub.map(function(i, a) {
                                    t.BusID == i.ID && (i.isidanzan = !0);
                                }) : 1 == n.Rub.length && (n.Rub[0].isidanzan = !0) : "重要结论" == t.BusType ? n.Important.length > 1 ? n.Important.map(function(i, a) {
                                    t.BusID == i.ID && (i.isidanzan = !0);
                                }) : 1 == n.Important.length && (n.Important[0].isidanzan = !0) : "题目详解" == t.BusType && (n.Analysis[0].isidanzan = !0);
                            });
                            var u = 0, l = 0;
                            n.Disturb.length > 0 && (l += 1), o.map(function(t) {
                                t.IsPackUp = 0, t.Isselect = !1;
                            }), n.Analysis.length > 0 && (o[0].IsPackUp = 1, o[0].Isselect = !0, u++), n.VLink.length > 0 && t.data.isShowVLink && (l += 1, 
                            o[1].IsPackUp = 1, u++), n.Rub.length > 0 && (l += 1, o[2].IsPackUp = 1, u++), n.Disturb.length > 0 && (l += 1, 
                            o[3].IsPackUp = 1, u++), n.Testing.length > 0 && (l += 1, o[4].IsPackUp = 1, u++), 
                            n.Multisolution.length > 0 && (l += 1, o[5].IsPackUp = 1, u++), n.Important.length > 0 && (l += 1, 
                            o[6].IsPackUp = 1, u++), t.data.BoxHaveValue = l, t.setData({
                                OtherInfo: n,
                                navlist: o,
                                isloading: !0,
                                navlistlength: u
                            }), t.getQuestionExtrapolationList(!0);
                        }
                        t.triggerEvent("showdataLoading", !0), t.setData({
                            isdataLoading: !0
                        });
                    });
                } catch (t) {
                    console.log(1111111, t), this.triggerEvent("showdataLoading", !0), this.setData({
                        isdataLoading: !0
                    });
                }
            }
        },
        GetQuestionFilesGive: function() {
            var t = this;
            p.GetQuestionFilesGive({
                QuestionID: this.data.QuestionID,
                IsValid: 1,
                StuID: r.globalData.StuID
            }).then(function(i) {
                if (Array.isArray(i.data) && i.data.length > 0) {
                    var a = t.data.dianzanlist;
                    a = i.data, t.setData({
                        dianzanlist: a
                    });
                }
                t.getQuestionOtherInfo();
            });
        },
        GetQuestionDianZanCount: function() {
            var t = this, i = this.data.OtherInfo;
            u.GetQuestionFiles({
                QuestionID: this.data.QuestionID
            }).then(function(a) {
                Array.isArray(a.data) && a.data.length > 0 && (a.data.map(function(t) {
                    "视频解析" == t.BusType ? i.VLink.length > 1 ? i.VLink.map(function(i, a) {
                        t.ID == i.ID && (i.dianzancount = t.Give);
                    }) : 1 == i.VLink.length && (i.VLink[0].dianzancount = t.Give) : "骚操作" == t.BusType ? i.Disturb.length > 1 ? i.Rub.map(function(i, a) {
                        t.ID == i.ID && (i.dianzancount = t.Give);
                    }) : 1 == i.Disturb.length && (i.Disturb[0].dianzancount = t.Give) : "考点" == t.BusType ? i.Testing.length > 1 ? i.Testing.map(function(i, a) {
                        t.ID == i.ID && (i.dianzancount = t.Give);
                    }) : 1 == i.Testing.length && (i.Testing[0].dianzancount = t.Give) : "一题多解" == t.BusType ? i.Multisolution.length > 1 ? i.Multisolution.map(function(i, a) {
                        t.ID == i.ID && (i.dianzancount = t.Give);
                    }) : 1 == i.Multisolution.length && (i.Multisolution[0].dianzancount = t.Give) : "疑难点" == t.BusType ? i.Rub.length > 1 ? i.Rub.map(function(i, a) {
                        t.ID == i.ID && (i.dianzancount = t.Give);
                    }) : 1 == i.Rub.length && (i.Rub[0].dianzancount = t.Give) : "重要结论" == t.BusType ? i.Important.length > 1 ? i.Important.map(function(i, a) {
                        t.ID == i.ID && (i.dianzancount = t.Give);
                    }) : 1 == i.Important.length && (i.Important[0].dianzancount = t.Give) : "题目详解" == t.BusType && i.Analysis.length > 0 && (i.Analysis[0].dianzancount = t.Give);
                }), t.setData({
                    OtherInfo: i
                }));
            });
        },
        getQuestionExtrapolationList: function() {
            var t = this;
            r.globalData.StuID;
            this.setData({
                isExtrapolationEnd: !1
            }), h.GetQuestionExtrapolationList({
                stuid: r.globalData.StuID,
                QuestionID: this.data.isSubmitExtrapolation ? this.data.SourceQuestionID : this.data.QuestionID,
                limit: 3
            }).then(function(a) {
                var n = [], o = [], e = [], s = t.data.BoxHaveValue, u = t.data.navlist, l = !1, d = t.data.navlistlength, h = 0;
                Array.isArray(a.data) && a.data.length > 0 && (n = a.data, a.data.map(function(i) {
                    i.IsDiscuss > 0 ? (h += 1, o.push(i)) : (i.QuestionTxt && (i.QuestionTxt = t.data.IsDarkMode ? r.towxml(i.QuestionTxt, "markdown", {
                        theme: "dark"
                    }) : r.towxml(i.QuestionTxt, "markdown")), e.push(i)), h == a.data.length && (l = !0), 
                    i.BusType = "举一反三";
                }), (o.length > 0 || e.length > 0) && t.data.isExtrapolationShow && (s += 1, u[7].IsPackUp = 1, 
                d += 1)), t.setData(i(i(i(i(i(i(i({}, "OtherInfo.Extrapolation", n), "DoExtrapolationList", o), "NoDoExtrapolationList", e), "BoxHaveValue", s), "navlist", u), "isextrapolationEnd", l), "navlistlength", d));
            });
        },
        translateDataToTree: function(t) {
            var i = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : "ID", a = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : "PID";
            return t.filter(function(n) {
                var o = t.filter(function(t) {
                    return n[i] == t[a];
                });
                return !(o.length > 0) || (n.children = o), !n[a];
            });
        },
        previewImg: function(t) {
            var i = t.currentTarget.dataset.src, a = [];
            a.push(i), this.selectComponent("#previewComponent").showPreview(), this.setData({
                defImg: a[0],
                imgList: a
            });
        },
        switchMenu: function(t) {
            var a = t.currentTarget.dataset.mid;
            if (this.data.isFinish || 1 == a) if (1 == a) this.setData({
                AnswerImgShow: !this.data.AnswerImgShow
            }); else if (2 == a) this.setData({
                LinkVideoListShow: !this.data.LinkVideoListShow
            }); else if (3 == a) this.setData({
                QuestionVideoListShow: !this.data.QuestionVideoListShow
            }); else if (4 == a) {
                var n = t.currentTarget.dataset.index, o = "OtherInfo.DifficultList[" + n + "].tabShow";
                this.setData(i({}, o, !this.data.OtherInfo.DifficultList[n].tabShow));
            } else 5 == a ? (this.data.userInfo.subscribe < 4 && this.setData({
                isOpenSubscribeDialog: !0
            }), this.setData({
                DiscussListShow: !this.data.DiscussListShow
            })) : 6 == a ? this.setData({
                DisturbShow: !this.data.DisturbShow
            }) : 7 == a && this.setData({
                ExtrapolationShow: !this.data.ExtrapolationShow
            }); else wx.showToast({
                title: "交卷后才能查看！",
                icon: "error"
            });
        },
        gotovip: function() {
            wx.navigateTo({
                url: "/wenjuan/pages/VIPInfo/VIPInfo"
            });
        },
        addSubscribe: function() {
            var t = this;
            wx.requestSubscribeMessage({
                tmplIds: [ r.globalData.appSubscribeText ],
                success: function(a) {
                    "accept" == a[r.globalData.appSubscribeText] ? d.UpdateWXUserSubscribe({
                        OpenID: t.data.userInfo.OpenID,
                        Subscribe: t.data.userInfo.subscribe + 1
                    }).then(function(a) {
                        t.setData(i({}, "userInfo.subscribe", t.data.userInfo.subscribe + 1)), r.updataGlobalData("userInfo", t.data.userInfo), 
                        wx.setStorage({
                            data: t.data.userInfo,
                            key: "userInfo"
                        }), wx.showToast({
                            icon: "none",
                            title: "订阅成功"
                        });
                    }) : wx.showToast({
                        icon: "none",
                        title: "订阅失败"
                    });
                }
            });
        },
        closeSubscribeDialog: function() {
            this.setData({
                isOpenSubscribeDialog: !1
            });
        },
        getVipLookCountList: function(t) {
            var i = this;
            if (!this.data.isVip) {
                var n = a.default.dateFormat("YYYY-MM-DD", new Date());
                h.GetVipLookQuestionCount({
                    StuID: r.globalData.StuID,
                    System_Station_ID: r.globalData.SassID,
                    BusType: "vip内容免费查看次数",
                    LookDate: n
                }).then(function(a) {
                    if (Array.isArray(a.data)) {
                        var n = !1;
                        a.data.map(function(i) {
                            i.BusID == t && (n = !0);
                        }), i.setData({
                            VipLookQuestionCountList: a.data,
                            isVipLookCount: n
                        });
                    }
                });
            }
        },
        getvipinfo: function() {
            wx.navigateTo({
                url: "/wenjuan/pages/VIPInfo/VIPInfo"
            });
        },
        hideVipLookmodel: function(t) {
            r.globalData.StuID ? 1 == t.detail.id ? this.data.VipLookQuestionCountList.length < r.globalData.appInfo.VipLookCount ? this.setData({
                isLookAd: !0
            }) : wx.navigateTo({
                url: "/wenjuan/pages/VIPInfo/VIPInfo"
            }) : 2 == t.detail.id && this.setData({
                isShowVipLook: !1
            }) : wx.navigateTo({
                url: "/pages/login."
            });
        },
        hideShowVipLook: function() {
            this.setData({
                isShowVipLook: !1,
                isLookAd: !1
            });
        },
        getADaward: function() {
            this.hideShowVipLook();
            var t = this, i = a.default.dateFormat("YYYY-MM-DD", new Date()), n = {
                BusID: t.data.QuestionID,
                BusType: "vip内容免费查看次数",
                LookDate: i,
                StuID: r.globalData.StuID,
                System_Station_ID: r.globalData.SassID
            };
            h.SetVipLookQuestionCount(n).then(function(i) {
                "操作成功" == i.msg && (t.getVipLookCountList(t.data.QuestionID), t.setData({
                    isVipLookCount: !0,
                    isShowVipLook: !1
                }));
            });
        },
        dianzan: function(t) {
            var a = this, n = t.currentTarget.dataset.item, o = t.currentTarget.dataset.index, e = this.data.OtherInfo, s = this.data.NoDoExtrapolationList;
            if (n.isidanzan) {
                var u = {
                    StuID: r.globalData.StuID,
                    BusID: n.ID
                };
                p.DelQuestionFilesGive(u).then(function(t) {
                    if (t.msg = "操作成功") {
                        if ("视频解析" == n.BusType) {
                            var u, r;
                            u = "OtherInfo.VLink[" + o + "].dianzancount", r = "OtherInfo.VLink[" + o + "].isidanzan", 
                            e.VLink[o].dianzancount--, e.VLink[o].isidanzan = !1, a.setData(i(i({}, u, e.VLink[o].dianzancount), r, e.VLink[o].isidanzan));
                        } else if ("骚操作" == n.BusType) {
                            var l, d;
                            l = "OtherInfo.Disturb[" + o + "].dianzancount", d = "OtherInfo.Disturb[" + o + "].isidanzan", 
                            e.Disturb[o].dianzancount--, e.Disturb[o].isidanzan = !1, a.setData(i(i({}, l, e.Disturb[o].dianzancount), d, e.Disturb[o].isidanzan));
                        } else if ("考点" == n.BusType) {
                            var h, p;
                            h = "OtherInfo.Testing[" + o + "].dianzancount", p = "OtherInfo.Testing[" + o + "].isidanzan", 
                            e.Testing[o].dianzancount--, e.Testing[o].isidanzan = !1, a.setData(i(i({}, h, e.Testing[o].dianzancount), p, e.Testing[o].isidanzan));
                        } else if ("一题多解" == n.BusType) {
                            var c, I;
                            c = "OtherInfo.Multisolution[" + o + "].dianzancount", I = "OtherInfo.Multisolution[" + o + "].isidanzan", 
                            e.Multisolution[o].dianzancount--, e.Multisolution[o].isidanzan = !1, a.setData(i(i({}, c, e.Multisolution[o].dianzancount), I, e.Multisolution[o].isidanzan));
                        } else if ("疑难点" == n.BusType) {
                            var g, f;
                            g = "OtherInfo.Rub[" + o + "].dianzancount", f = "OtherInfo.Rub[" + o + "].isidanzan", 
                            e.Rub[o].dianzancount--, e.Rub[o].isidanzan = !1, a.setData(i(i({}, g, e.Rub[o].dianzancount), f, e.Rub[o].isidanzan));
                        } else if ("重要结论" == n.BusType) {
                            var D, m;
                            D = "OtherInfo.Important[" + o + "].dianzancount", m = "OtherInfo.Important[" + o + "].isidanzan", 
                            e.Important[o].dianzancount--, e.Important[o].isidanzan = !1, a.setData(i(i({}, D, e.Important[o].dianzancount), m, e.Important[o].isidanzan));
                        } else if ("题目详解" == n.BusType) {
                            var v, y;
                            v = "OtherInfo.Analysis[" + o + "].dianzancount", y = "OtherInfo.Analysis[" + o + "].isidanzan", 
                            e.Analysis[o].dianzancount--, e.Analysis[o].isidanzan = !1, a.setData(i(i({}, v, e.Analysis[o].dianzancount), y, e.Analysis[o].isidanzan));
                        } else if ("举一反三" == n.BusType) {
                            var w, x;
                            w = "NoDoExtrapolationList[" + o + "].dianzancount", x = "NoDoExtrapolationList[" + o + "].isidanzan", 
                            s[o].dianzancount--, s[o].isidanzan = !1, a.setData(i(i({}, w, s[o].dianzancount), x, s[o].isidanzan));
                        }
                        wx.showToast({
                            title: "取消点赞",
                            icon: "none",
                            duration: 1500
                        });
                    }
                });
            } else {
                var l = {
                    StuID: r.globalData.StuID,
                    BusID: n.ID,
                    QuestionID: this.data.QuestionID,
                    BusType: n.BusType,
                    IsValid: 1,
                    System_Station_ID: r.globalData.SassID
                };
                p.UpdateQuestionFilesGive(l).then(function(t) {
                    if (t.msg = "操作成功") {
                        if ("视频解析" == n.BusType) {
                            var u, r;
                            u = "OtherInfo.VLink[" + o + "].dianzancount", r = "OtherInfo.VLink[" + o + "].isidanzan", 
                            e.VLink[o].dianzancount++, e.VLink[o].isidanzan = !0, a.setData(i(i({}, u, e.VLink[o].dianzancount), r, e.VLink[o].isidanzan));
                        } else if ("骚操作" == n.BusType) {
                            var l, d;
                            l = "OtherInfo.Disturb[" + o + "].dianzancount", d = "OtherInfo.Disturb[" + o + "].isidanzan", 
                            e.Disturb[o].dianzancount++, e.Disturb[o].isidanzan = !0, a.setData(i(i({}, l, e.Disturb[o].dianzancount), d, e.Disturb[o].isidanzan));
                        } else if ("考点" == n.BusType) {
                            var h, p;
                            h = "OtherInfo.Testing[" + o + "].dianzancount", p = "OtherInfo.Testing[" + o + "].isidanzan", 
                            e.Testing[o].dianzancount++, e.Testing[o].isidanzan = !0, a.setData(i(i({}, h, e.Testing[o].dianzancount), p, e.Testing[o].isidanzan));
                        } else if ("一题多解" == n.BusType) {
                            var c, I;
                            c = "OtherInfo.Multisolution[" + o + "].dianzancount", I = "OtherInfo.Multisolution[" + o + "].isidanzan", 
                            e.Multisolution[o].dianzancount++, e.Multisolution[o].isidanzan = !0, a.setData(i(i({}, c, e.Multisolution[o].dianzancount), I, e.Multisolution[o].isidanzan));
                        } else if ("疑难点" == n.BusType) {
                            var g, f;
                            g = "OtherInfo.Rub[" + o + "].dianzancount", f = "OtherInfo.Rub[" + o + "].isidanzan", 
                            e.Rub[o].dianzancount++, e.Rub[o].isidanzan = !0, a.setData(i(i({}, g, e.Rub[o].dianzancount), f, e.Rub[o].isidanzan));
                        } else if ("重要结论" == n.BusType) {
                            var D, m;
                            D = "OtherInfo.Important[" + o + "].dianzancount", m = "OtherInfo.Important[" + o + "].isidanzan", 
                            e.Important[o].dianzancount++, e.Important[o].isidanzan = !0, a.setData(i(i({}, D, e.Important[o].dianzancount), m, e.Important[o].isidanzan));
                        } else if ("题目详解" == n.BusType) {
                            var v, y;
                            v = "OtherInfo.Analysis[" + o + "].dianzancount", y = "OtherInfo.Analysis[" + o + "].isidanzan", 
                            e.Analysis[o].dianzancount++, e.Analysis[o].isidanzan = !0, a.setData(i(i({}, v, e.Analysis[o].dianzancount), y, e.Analysis[o].isidanzan));
                        } else if ("举一反三" == n.BusType) {
                            var w, x;
                            w = "NoDoExtrapolationList[" + o + "].dianzancount", x = "NoDoExtrapolationList[" + o + "].isidanzan", 
                            s[o].dianzancount++, s[o].isidanzan = !0, a.setData(i(i({}, w, s[o].dianzancount), x, s[o].isidanzan));
                        }
                        wx.showToast({
                            title: "点赞成功",
                            icon: "none",
                            duration: 1500
                        });
                    }
                });
            }
        },
        getNoVipImgList: function() {
            var t = this;
            h.GetHeadImg({
                System_Station_ID: r.globalData.SassID,
                BusType: "题目内容VIP示例",
                IsValid: 1
            }).then(function(i) {
                var a = t.data.vipConfigs;
                if (Array.isArray(i.data)) {
                    var n = [];
                    i.data.map(function(t) {
                        "0001-01-01T00:00:00" != t.ReleaseTime && "1900-01-01 00:00:00" != t.ReleaseTime && t.ReleaseTime ? new Date() > new Date(t.ReleaseTime) && n.push(t) : n.push(t);
                    }), n.map(function(t) {
                        a.map(function(i) {
                            t.Title == i.type && t.HeadImg && (t.HeadImg.indexOf(".png") > -1 && (t.HeadImg = t.HeadImg.replace(/.png_yjs/g, ".png")), 
                            i.noVipImg = t.HeadImg);
                        });
                    }), t.setData({
                        vipConfigs: a
                    });
                }
            });
        }
    }
});