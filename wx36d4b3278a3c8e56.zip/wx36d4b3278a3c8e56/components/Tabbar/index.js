var t = require("../../@babel/runtime/helpers/regeneratorRuntime"), e = require("../../@babel/runtime/helpers/asyncToGenerator"), a = require("../../@babel/runtime/helpers/typeof"), r = o(require("../../configs/router.js")), n = require("../../api/product.js"), i = o(require("../../utils/util"));

function o(t) {
    return t && t.__esModule ? t : {
        default: t
    };
}

var u = getApp(), s = new n.Product();

Component({
    properties: {
        activeIdx: {
            type: Number,
            value: 0
        },
        auth: {
            type: Number,
            value: 0,
            observer: "onAuthChanged"
        },
        StuID: {
            type: String,
            observer: function(t) {
                t && this.getMyInfoList();
            }
        }
    },
    data: {
        tabbarList: r.default,
        _auth: 0,
        infoNum: 0
    },
    methods: {
        preventTouchMove: function() {},
        handleItemTap: function(t) {
            var e = t.currentTarget.dataset, a = e.idx, r = e.path;
            a !== this.data.activeIdx ? wx.switchTab({
                url: "/".concat(r)
            }) : this.trigger("refresh");
        },
        onAuthChanged: function(t) {
            wx.setStorageSync("__com-tabbar-auth", t), this.setData({
                _auth: t
            });
        },
        trigger: function(t) {
            var e = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {}, r = arguments.length > 2 ? arguments[2] : void 0;
            if (!t) throw new TypeError("没有自定义事件名");
            this.triggerEvent(t, e), console.log("发送 ".concat(t, " 事件,携带的值为 ").concat("object" === a(e) ? JSON.stringify(e) : e, " ").concat(r ? "   ---   " + r : ""));
        },
        getMyInfoList: function() {
            var a = this;
            return e(t().mark(function e() {
                var r, n, o;
                return t().wrap(function(t) {
                    for (;;) switch (t.prev = t.next) {
                      case 0:
                        if (!a.data.StuID && !u.globalData.StuID) {
                            t.next = 14;
                            break;
                        }
                        if (!(r = i.default.IsStorageSyncExpire("TabbarGetInfoList")) || !Array.isArray(r)) {
                            t.next = 6;
                            break;
                        }
                        r = r, t.next = 10;
                        break;

                      case 6:
                        return t.next = 8, s.GetInfoList({
                            StuID: a.data.StuID ? a.data.StuID : u.globalData.StuID,
                            IsRead: -1,
                            System_Station_ID: u.globalData.SassID,
                            limit: 1e3,
                            page: 1
                        });

                      case 8:
                        n = t.sent, Array.isArray(n.data) ? (r = n.data, i.default.AddSotrageSyncExpire("TabbarGetInfoList", r, 5)) : r = [];

                      case 10:
                        o = 0, r.map(function(t, e) {
                            "讨论回复" != t.BusType && 0 == t.IsRead && o++;
                        }), a.triggerEvent("getInfoNum", o), a.setData({
                            infoNum: o
                        });

                      case 14:
                      case "end":
                        return t.stop();
                    }
                }, e);
            }))();
        }
    },
    ready: function() {},
    pageLifetimes: {
        show: function() {
            this.getMyInfoList(), this.setData({
                _auth: wx.getStorageSync("__com-tabbar-auth")
            });
        }
    }
});