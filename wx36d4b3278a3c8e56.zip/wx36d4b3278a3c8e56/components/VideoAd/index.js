var t;

(t = require("../../utils/util")) && t.__esModule;

var i, e = new (require("../../api/course").Course)(), n = getApp(), a = n.window;

Component({
    properties: {
        Source: {
            type: String,
            value: "",
            observer: function(t) {
                var i = wx.getMenuButtonBoundingClientRect();
                this.setData({
                    boundingBottom: i.bottom + 5,
                    ismuted: !1,
                    ishaveUrlStr: !1,
                    duration: 30,
                    countdown: 30,
                    isFinish: !1,
                    adInfo: {},
                    isShowhint: !1
                }), this.getaddata();
            }
        }
    },
    lifetimes: {
        attached: function() {}
    },
    data: {
        window: a,
        boundingBottom: 0,
        ismuted: !1,
        ishaveUrlStr: !1,
        duration: 30,
        countdown: 30,
        isFinish: !1,
        adInfo: {},
        isShowhint: !1,
        Hintmodel: {
            isshowClear: !1,
            title: "暂未获得奖励",
            titlecolor: "#CF4935",
            content: "是否继续观看广告",
            btnList: [ {
                content: "放弃观看",
                bgcolor: "#F3F3F3",
                color: "#333333",
                id: 2
            }, {
                content: "继续观看",
                bgcolor: "#F3F3F3",
                color: "#333333",
                id: 1
            } ]
        }
    },
    methods: {
        gotoad: function() {
            var t = this.data.adInfo;
            this.triggerEvent("clickclear", {}), n.globalData.StuID ? t.ContactUrl && (t.ContactUrl.indexOf("http://") > -1 || t.ContactUrl.indexOf("https://") > -1 ? wx.navigateTo({
                url: "/pages/webview/webview?url=" + t.ContactUrl
            }) : wx.navigateTo({
                url: t.ContactUrl
            })) : wx.navigateTo({
                url: "/pages/login"
            });
        },
        clearBtn: function() {
            this.data.isFinish ? (this.triggerEvent("getaward", {}), this.setData({
                isShowhint: !1
            })) : this.setData({
                isShowhint: !0
            });
        },
        hideHIntmodel: function(t) {
            1 == t.detail.id ? this.setData({
                isShowhint: !1
            }) : (this.setData({
                isShowhint: !1
            }), this.triggerEvent("clickclear", {}));
        },
        getaddata: function() {
            var t = this;
            e.GetVideoAdsInfo({
                Source: this.data.Source,
                StuID: n.globalData.StuID,
                log: 1
            }).then(function(i) {
                if (i.data) {
                    var e = i.data;
                    e.BusValue && e.BusValue.indexOf(".png") > -1 && (e.BusValue = e.BusValue.replace(/.png_yjs/g, ".png")), 
                    1 == e.BusID && (e.VideoUrl ? (e.VideoUrl.indexOf(".png") > -1 && (e.VideoUrl = e.VideoUrl.replace(/.png_yjs/g, ".png")), 
                    e.VideoUrl = e.VideoUrl.split(",")) : e.VideoUrl = []), t.setData({
                        adInfo: e
                    }), 1 == e.BusID && (t.setData({
                        countdown: 30
                    }), t.setTime());
                } else t.triggerEvent("clickclear", {});
            });
        },
        setTime: function() {
            var t = this;
            i = setInterval(function() {
                1 == t.data.countdown ? (clearInterval(i), t.setData({
                    isFinish: !0
                })) : t.setData({
                    countdown: t.data.countdown - 1
                });
            }, 1e3);
        },
        preventTouchMove: function() {},
        changemuted: function() {
            this.setData({
                ismuted: !this.data.ismuted
            });
        },
        bindtimeupdate: function(t) {
            this.data.countdown > 0 ? this.setData({
                duration: t.detail.duration,
                countdown: parseInt(t.detail.duration - t.detail.currentTime)
            }) : this.setData({
                isFinish: !0
            });
        }
    }
});