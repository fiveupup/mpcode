var t = require("../../@babel/runtime/helpers/defineProperty");

Component({
    options: {
        pureDataPattern: /^_/
    },
    properties: {
        src: {
            type: String,
            observer: function(t, a) {
                t && (this.setData({
                    imagePath: t
                }), this.data._isInit ? this._initImage() : this._init());
            }
        },
        aspectRatio: {
            type: Number,
            observer: function(t, a) {
                t && (this.setData({
                    _aspectRatio: t
                }), this.data._isInit && this._initImage());
            }
        },
        isProportion: {
            type: Boolean,
            observer: function(t, a) {
                this.setData({
                    isProportion: t
                });
            }
        },
        quality: {
            type: Number,
            observer: function(t, a) {
                this.setData({
                    _quality: t
                });
            }
        },
        isLoadimg: {
            type: Boolean,
            value: !1
        }
    },
    data: {
        imagePath: null,
        isProportion: !1,
        viewImagesLocation: {
            width: 0,
            height: 0,
            top: 0,
            left: 0
        },
        crop: {
            top: 0,
            right: 0,
            bottom: 0,
            left: 0
        },
        canvas: {
            width: null,
            height: null
        },
        _isInit: !1,
        _aspectRatio: 1,
        _systemInfo: null,
        _originalImageInfo: null,
        _viewThanOriginal: null,
        _startX: null,
        _startY: null,
        _startCrop: null,
        _quality: 1
    },
    lifetimes: {
        attached: function() {
            this.data._ctx || this.setData({
                _ctx: wx.createCanvasContext("image-cropper-canvas-id", this)
            });
        },
        detached: function() {}
    },
    pageLifetimes: {
        show: function() {},
        hide: function() {},
        resize: function() {}
    },
    methods: {
        _init: function() {
            var t = this;
            wx.getSystemInfo({
                success: function(a) {
                    var i = a;
                    i.rpxPxRatio = 750 / i.windowWidth, i.windowWidthRpx = i.windowWidth * i.rpxPxRatio, 
                    i.windowHeightRpx = i.windowHeight * i.rpxPxRatio - 100, t.setData({
                        _systemInfo: i
                    }), t._initImage();
                }
            });
        },
        _initImage: function() {
            var t = this, a = t.data._systemInfo;
            t.setData({
                crop: {
                    top: 0,
                    right: 0,
                    bottom: 0,
                    left: 0
                }
            }), wx.showLoading({
                title: "加载中"
            }), wx.getImageInfo({
                src: t.data.imagePath,
                success: function(i) {
                    var o = i;
                    t.setData({
                        _originalImageInfo: o
                    });
                    var e, h = t.data._ctx, s = o.width / o.height;
                    e = o.width >= o.height ? {
                        width: o.width > 4e3 ? 4e3 : o.width,
                        height: o.width > 4e3 ? 4e3 / s : o.height
                    } : {
                        width: o.height > 4e3 ? 4e3 * s : o.width,
                        height: o.height > 4e3 ? 4e3 : o.height
                    }, t.setData({
                        canvas: e
                    }), h.drawImage(o.path, 0, 0, o.width, o.height, 0, 0, e.width, e.height), h.draw(!1);
                    var r = a.windowWidthRpx - 80, n = r / o.width, d = o.height * n;
                    d < a.windowHeightRpx ? (t._setProportionCode(r, d), t._cropLocationCenter(r, d), 
                    t.setData({
                        viewImagesLocation: {
                            width: r,
                            height: d,
                            top: (a.windowHeightRpx - d) / 2,
                            left: 40
                        },
                        crop: t.data.crop
                    })) : (n = (d = a.windowHeightRpx) / o.height, r = o.width * n, t._setProportionCode(r, d), 
                    t._cropLocationCenter(r, d), t.setData({
                        viewImagesLocation: {
                            width: r,
                            height: d,
                            top: 0,
                            left: (a.windowWidthRpx - r) / 2
                        },
                        crop: t.data.crop
                    })), t.setData({
                        _viewThanOriginal: n,
                        _isInit: !0
                    }), wx.hideLoading();
                },
                fail: function() {
                    wx.hideLoading();
                }
            });
        },
        _setProportionCode: function(a, i) {
            var o, e, h = this.data._aspectRatio;
            console.log("初始化宽度：" + a + ",初始化高度：" + i), h > 0 && h < 1 ? a >= i ? (e = i - 50, 
            this.setData(t(t({}, "crop.right", e * h), "crop.bottom", e))) : (e = .75 * i, console.log("裁剪高度：" + e), 
            console.log("系数：" + h), console.log("裁剪宽度：" + e * (h + .25)), this.setData(t(t({}, "crop.right", e * h), "crop.bottom", e))) : (console.log("裁剪框宽高比值为 1.8"), 
            console.log("初始化宽高比 ->  " + a + "：" + i), a >= i ? (console.log("宽大于高"), o = a - 50, 
            this.setData(t(t({}, "crop.right", o), "crop.bottom", i / h))) : (console.log("宽小于高"), 
            o = a - 50, this.setData(t(t({}, "crop.right", o), "crop.bottom", o / h))), console.log("结果为 ->  " + o + ":" + o / h));
        },
        _cropLocationCenter: function(t, a) {
            var i = this.data.crop, o = i.right - i.left, e = i.bottom - i.top;
            return i.top = i.top + a / 2 - e / 2, i.bottom = i.bottom + a / 2 - e / 2, i.left = i.left + t / 2 - o / 2, 
            i.right = i.right + t / 2 - o / 2, i;
        },
        _cropViewTouchstart: function(t) {
            var a = this.data._systemInfo;
            this.setData({
                _startX: t.touches[0].pageX * a.rpxPxRatio,
                _startY: t.touches[0].pageY * a.rpxPxRatio,
                _startCrop: this.data.crop
            });
        },
        _cropViewMove: function(t) {
            var a = this.data._systemInfo, i = t.touches[0].pageX * a.rpxPxRatio, o = t.touches[0].pageY * a.rpxPxRatio, e = {
                top: this.data._startCrop.top - (this.data._startY - o),
                right: this.data._startCrop.right - (this.data._startX - i),
                bottom: this.data._startCrop.bottom - (this.data._startY - o),
                left: this.data._startCrop.left - (this.data._startX - i)
            };
            e.top < 0 && (e.top = 0, e.bottom = this.data._startCrop.bottom - this.data._startCrop.top), 
            e.right > this.data.viewImagesLocation.width && (e.right = this.data.viewImagesLocation.width, 
            e.left = this.data.viewImagesLocation.width - this.data._startCrop.right + this.data._startCrop.left), 
            e.bottom > this.data.viewImagesLocation.height && (e.bottom = this.data.viewImagesLocation.height, 
            e.top = this.data.viewImagesLocation.height - this.data._startCrop.bottom + this.data._startCrop.top), 
            e.left < 0 && (e.left = 0, e.right = this.data._startCrop.right - this.data._startCrop.left), 
            this.setData({
                crop: e
            });
        },
        _leftUpTouchmove: function(a) {
            var i, o = this.data._systemInfo, e = this.data._aspectRatio, h = a.touches[0].pageX * o.rpxPxRatio, s = a.touches[0].pageY * o.rpxPxRatio, r = h - this.data.viewImagesLocation.left;
            if (this.data.isProportion) {
                if ((i = this.data.crop.bottom - (this.data.crop.right - r) / e) < 0) return;
                if (r < 0) return;
                var n, d;
                e >= 1 ? (n = 80 * e, d = 80) : (n = 80, d = 80 / e), this.data.crop.bottom - i < d && (i = this.data.crop.bottom - d), 
                this.data.crop.right - r < n && (r = this.data.crop.right - n);
            } else (i = s - this.data.viewImagesLocation.top) < 0 && (i = 0), r < 0 && (r = 0), 
            this.data.crop.bottom - i < 80 && (i = this.data.crop.bottom - 80), this.data.crop.right - r < 80 && (r = this.data.crop.right - 80);
            this.setData(t(t({}, "crop.top", i), "crop.left", r));
        },
        _upTouchmove: function(a) {
            var i = this.data._systemInfo, o = (this.data._aspectRatio, a.touches[0].pageY * i.rpxPxRatio - this.data.viewImagesLocation.top);
            o < 0 || this.data.crop.bottom - o < 80 || this.setData(t({}, "crop.top", o));
        },
        _rightUpTouchmove: function(a) {
            var i, o = this.data._systemInfo, e = this.data._aspectRatio, h = a.touches[0].pageX * o.rpxPxRatio, s = a.touches[0].pageY * o.rpxPxRatio, r = h - this.data.viewImagesLocation.left;
            if (this.data.isProportion) {
                if ((i = this.data.crop.bottom - (r - this.data.crop.left) / e) < 0) return;
                if (h > (o.windowWidthRpx + this.data.viewImagesLocation.width) / 2) return;
                var n, d;
                e >= 1 ? (n = 80 * e, d = 80) : (n = 80, d = 80 / e), this.data.crop.bottom - i < d && (i = this.data.crop.bottom - d), 
                r - this.data.crop.left < n && (r = this.data.crop.left + n);
            } else (i = s - this.data.viewImagesLocation.top) < 0 && (i = 0), h > (o.windowWidthRpx + this.data.viewImagesLocation.width) / 2 && (r = this.data.viewImagesLocation.width), 
            this.data.crop.bottom - i < 80 && (i = this.data.crop.bottom - 80), r - this.data.crop.left < 80 && (r = this.data.crop.left + 80);
            this.setData(t(t({}, "crop.top", i), "crop.right", r));
        },
        _rightTouchmove: function(a) {
            var i = this.data._systemInfo, o = (this.data._aspectRatio, a.touches[0].pageX * i.rpxPxRatio), e = o - this.data.viewImagesLocation.left;
            o > (i.windowWidthRpx + this.data.viewImagesLocation.width) / 2 || e - this.data.crop.left < 80 || this.setData(t({}, "crop.right", e));
        },
        _rightDownTouchmove: function(a) {
            var i, o = this.data._systemInfo, e = this.data._aspectRatio, h = a.touches[0].pageX * o.rpxPxRatio, s = a.touches[0].pageY * o.rpxPxRatio, r = h - this.data.viewImagesLocation.left;
            if (this.data.isProportion) {
                if (i = (r - this.data.crop.left) / e + this.data.crop.top, h > (o.windowWidthRpx + this.data.viewImagesLocation.width) / 2) return;
                if (i > this.data.viewImagesLocation.height) return;
                var n, d;
                e >= 1 ? (n = 80 * e, d = 80) : (n = 80, d = 80 / e), i - this.data.crop.top < d && (i = this.data.crop.top + d), 
                r - this.data.crop.left < n && (r = this.data.crop.left + n);
            } else i = s - this.data.viewImagesLocation.top, h > (o.windowWidthRpx + this.data.viewImagesLocation.width) / 2 && (r = this.data.viewImagesLocation.width), 
            i > this.data.viewImagesLocation.height && (i = this.data.viewImagesLocation.height), 
            i - this.data.crop.top < 80 && (i = this.data.crop.top + 80), r - this.data.crop.left < 80 && (r = this.data.crop.left + 80);
            this.setData(t(t({}, "crop.right", r), "crop.bottom", i));
        },
        _downTouchmove: function(a) {
            var i = this.data._systemInfo, o = (this.data._aspectRatio, a.touches[0].pageY * i.rpxPxRatio - this.data.viewImagesLocation.top);
            o > this.data.viewImagesLocation.height || o - this.data.crop.top < 80 || this.setData(t({}, "crop.bottom", o));
        },
        _leftDownTouchmove: function(a) {
            var i, o = this.data._systemInfo, e = this.data._aspectRatio, h = a.touches[0].pageX * o.rpxPxRatio, s = a.touches[0].pageY * o.rpxPxRatio, r = h - this.data.viewImagesLocation.left;
            if (this.data.isProportion) {
                if (i = (this.data.crop.right - r) / e + this.data.crop.top, h < this.data.viewImagesLocation.left) return;
                if (i > this.data.viewImagesLocation.height) return;
                var n, d;
                e >= 1 ? (n = 80 * e, d = 80) : (n = 80, d = 80 / e), i - this.data.crop.top < d && (i = this.data.crop.top + d), 
                this.data.crop.right - r < n && (r = this.data.crop.right - n);
            } else i = s - this.data.viewImagesLocation.top, h < this.data.viewImagesLocation.left && (r = 0), 
            i > this.data.viewImagesLocation.height && (i = this.data.viewImagesLocation.height), 
            i - this.data.crop.top < 80 && (i = this.data.crop.top + 80), this.data.crop.right - r < 80 && (r = this.data.crop.right - 80);
            this.setData(t(t({}, "crop.left", r), "crop.bottom", i));
        },
        _leftTouchmove: function(a) {
            var i = this.data._systemInfo, o = (this.data._aspectRatio, a.touches[0].pageX * i.rpxPxRatio - this.data.viewImagesLocation.left);
            o < 0 || this.data.crop.right - o < 80 || this.setData(t({}, "crop.left", o));
        },
        getResults: function(t) {
            var a = JSON.parse(JSON.stringify(this.data.crop));
            a.top = Math.round(a.top / this.data._viewThanOriginal), a.right = Math.round(a.right / this.data._viewThanOriginal), 
            a.bottom = Math.round(a.bottom / this.data._viewThanOriginal), a.left = Math.round(a.left / this.data._viewThanOriginal), 
            a.width = a.right - a.left, a.height = a.bottom - a.top, delete a.bottom, delete a.right, 
            t({
                crop: a,
                originalImageInfo: this.data._originalImageInfo
            });
        },
        _getImagePath: function(t) {
            wx.showLoading({
                title: "请稍后",
                mask: !0
            });
            var a = this, i = JSON.parse(JSON.stringify(a.data.crop));
            i.top = Math.round(i.top / a.data._viewThanOriginal), i.right = Math.round(i.right / a.data._viewThanOriginal), 
            i.bottom = Math.round(i.bottom / a.data._viewThanOriginal), i.left = Math.round(i.left / a.data._viewThanOriginal), 
            i.width = i.right - i.left, i.height = i.bottom - i.top;
            var o = a.data._originalImageInfo.path, e = i.top, h = i.left, s = i.width, r = i.height;
            wx.getImageInfo({
                src: o,
                success: function(i) {
                    a.setData({
                        canvas: {
                            width: i.width,
                            height: i.height
                        }
                    }), a.createSelectorQuery().select("#image-cropper-canvas").fields({
                        node: !0,
                        size: !0
                    }).exec(function(i) {
                        if (Array.isArray(i) && i.length > 0 && i[0]) {
                            var n = i[0].node, d = n.getContext("2d"), c = i[0].width, p = i[0].height;
                            n.width = c, n.height = p;
                            var g = n.createImage();
                            g.src = o, g.onload = function(i) {
                                d.drawImage(g, 0, 0, c, p, 0, 0, c, p);
                                var o = 300 / c, l = h * o, w = e * o, f = s * o, m = r * o;
                                wx.canvasToTempFilePath({
                                    x: l,
                                    y: w,
                                    width: f,
                                    height: m,
                                    destWidth: 2 * s,
                                    destHeight: 2 * r,
                                    canvas: n,
                                    fileType: "jpg",
                                    quality: a.data._quality,
                                    success: function(a) {
                                        wx.hideLoading(), t({
                                            path: a.tempFilePath
                                        });
                                    },
                                    fail: function(t) {
                                        wx.hideLoading(), console.log(t);
                                    }
                                });
                            }, g.onerror = function(t) {
                                wx.hideLoading(), console.error("err:", t);
                            };
                        }
                    });
                },
                fail: function(t) {
                    wx.hideLoading(), console.log(t);
                }
            });
        },
        getImagePath: function(t) {
            wx.showLoading({
                title: "请稍后",
                mask: !0
            });
            var a = this, i = JSON.parse(JSON.stringify(a.data.crop));
            i.right = Math.round(i.right / a.data._viewThanOriginal), i.bottom = Math.round(i.bottom / a.data._viewThanOriginal), 
            i.top = Math.round(i.top / a.data._viewThanOriginal), i.left = Math.round(i.left / a.data._viewThanOriginal), 
            i.width = i.right - i.left, i.height = i.bottom - i.top;
            var o = this.data.canvas.width / this.data._originalImageInfo.width, e = i.left * o, h = i.top * o, s = i.width * o, r = i.height * o;
            setTimeout(function() {
                wx.canvasToTempFilePath({
                    x: e,
                    y: h,
                    width: s,
                    height: r,
                    destWidth: 2 * s,
                    destHeight: 2 * r,
                    canvasId: "image-cropper-canvas-id",
                    fileType: "jpg",
                    quality: a.data._quality,
                    success: function(a) {
                        wx.hideLoading(), t({
                            path: a.tempFilePath
                        });
                    },
                    fail: function(t) {
                        console.log(t), wx.hideLoading();
                    }
                }, a);
            }, 100);
        }
    }
});