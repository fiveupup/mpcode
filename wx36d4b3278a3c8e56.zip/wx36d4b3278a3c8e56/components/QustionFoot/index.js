var t, e = require("../../@babel/runtime/helpers/defineProperty"), a = (t = require("../../utils/util")) && t.__esModule ? t : {
    default: t
}, s = require("../../api/course"), o = require("../../api/product.js"), i = require("../../api/user");

var n = getApp(), r = new s.Course(), l = new o.Product(), u = new i.User();

Component({
    options: {
        addGlobalClass: !0
    },
    properties: {
        isIOS: {
            type: Boolean,
            value: n.globalData.isIOS
        },
        tabIndex: {
            type: Number,
            observer: function(t) {}
        },
        markList: {
            type: Array
        },
        favoriteList: {
            type: Array
        },
        notesList: {
            type: Array
        },
        isShowShar: {
            type: Boolean,
            value: !0
        },
        questionID: {
            type: Number,
            value: 0,
            observer: function(t) {
                this.setData({
                    BusNotes: "",
                    BusKeyList: [],
                    BusKeyIndex: 0,
                    BusKeyValue: "",
                    NotesCounts: 0,
                    imglist: [],
                    uploadImgList: [],
                    imgList1: [],
                    defImg: "",
                    unUpload: !1
                });
            }
        },
        StuID: {
            type: String
        },
        IsAct: {
            type: Boolean,
            value: !0
        },
        BookID: {
            type: Number,
            value: 0
        },
        isHavecatalog: {
            type: Boolean,
            value: !0
        },
        isCourse: {
            type: Boolean,
            value: !1
        },
        isModelShow: {
            type: Boolean,
            value: !1,
            observer: function(t) {
                t && this.showMode();
            }
        },
        booktabIndex: {
            type: Number,
            value: -1
        },
        IsDarkMode: {
            type: Boolean,
            value: !1,
            observer: function(t) {
                t ? this.setData({
                    IsDarkModetext: "dark_"
                }) : this.setData({
                    IsDarkModetext: ""
                });
            }
        }
    },
    data: {
        isErrorShowHint: !1,
        ErrorHintmodel: {
            isshowClear: !1,
            title: "错题本题数已达上限",
            titlecolor: "#CF4935",
            content: "开通会员尊享无上限错题本功能",
            btnList: [ {
                content: "我知道了",
                bgcolor: "#F3F3F3",
                color: "#333333",
                id: 1
            }, {
                content: "了解会员",
                bgcolor: "#FFDC21",
                color: "#333333",
                id: 2
            } ]
        },
        isCollectShowHint: !1,
        CollectHintmodel: {
            isshowClear: !1,
            title: "收藏题数已达上限",
            titlecolor: "#CF4935",
            content: "开通会员尊享无上限收藏功能",
            btnList: [ {
                content: "我知道了",
                bgcolor: "#F3F3F3",
                color: "#333333",
                id: 1
            }, {
                content: "了解会员",
                bgcolor: "#FFDC21",
                color: "#333333",
                id: 2
            } ]
        },
        isShowActHint: !1,
        isModelShow: !1,
        BusNotes: "",
        BusKeyList: [],
        BusKeyIndex: 0,
        inputBusKey: "",
        tabIndex: 0,
        NotesCounts: 0,
        imglist: [],
        uploadImgList: [],
        imgList1: [],
        defImg: "",
        unUpload: !1,
        IsDarkModetext: ""
    },
    methods: {
        preventTouchMove: function() {},
        previewImg: function(t) {
            wx.previewImage({
                current: t.target.dataset.src,
                urls: [ t.target.dataset.src ]
            });
        },
        chooseImg: function() {
            var t = this, e = t.data.imglist, a = t.data.uploadImgList;
            wx.chooseMedia({
                count: 3,
                mediaType: [ "image" ],
                sizeType: [ "original", "compressed" ],
                sourceType: [ "album", "camera" ],
                success: function(s) {
                    var o = [];
                    if (s.tempFiles.map(function(t) {
                        o.push(t.tempFilePath);
                    }), (e = e.concat(o)).length < 3) {
                        var i = new Set(e);
                        t.setData({
                            imglist: Array.from(i)
                        }), t.uploadImg(o);
                    } else {
                        wx.showToast({
                            icon: "none",
                            title: "最多可以选3张图片"
                        }), e.length <= 3 && a.length < 3 && t.uploadImg(o), e = e.slice(0, 3);
                        var n = new Set(e);
                        t.setData({
                            unUpload: !0,
                            imglist: Array.from(n)
                        });
                    }
                }
            });
        },
        uploadImg: function(t) {
            for (var e = this, a = [], s = (a = e.data.uploadImgList, 0); s < t.length; s++) wx.uploadFile({
                filePath: t[s],
                name: "file",
                url: n.globalData.configs.TOP_HOST + "/api/sys_attachment/LayuiUpImg",
                header: {
                    "Content-Type": "application/x-www-form-urlencoded"
                },
                success: function(t) {
                    var s = t.data;
                    s = JSON.parse(s).data, a.push(s.src), e.setData({
                        uploadImgList: a
                    });
                }
            });
        },
        delImg: function(t) {
            var e = t.currentTarget.dataset.idx, a = this.data.imglist, s = this.data.uploadImgList;
            a.splice(e, 1), s.splice(e, 1), this.setData({
                imglist: a,
                uploadImgList: s,
                unUpload: !1
            });
        },
        tabchages: function(t) {
            var e = t.currentTarget.dataset.index;
            this.setData({
                tabIndex: e
            }), this.showMode();
        },
        clickclear: function(t) {
            var e = this;
            if (0 == t.currentTarget.dataset.index) return this.setData({
                isShowActHint: !1,
                tabIndex: -1,
                BusNotes: "",
                BusKeyList: [],
                BusKeyIndex: -1,
                inputBusKey: "",
                isModelShow: !1
            }), this.triggerEvent("hideQuestionModel", !1), !1;
            var a = this.data.tabIndex, s = 0;
            0 == a ? this.data.markList.length > 0 && (s = this.data.markList[0].ID) : 1 == a ? this.data.favoriteList.length > 0 && (s = this.data.favoriteList[0].ID) : 2 == a && this.data.notesList.length > 0 && (s = this.data.notesList[0].ID), 
            s > 0 ? wx.showModal({
                title: "提示",
                content: "是否确认取消" + (0 == a ? "错题" : "收藏"),
                success: function(t) {
                    if (t.confirm) {
                        var o = {
                            ids: s
                        };
                        l.DelsSysUserBookQuestion(o).then(function(t) {
                            if ("操作成功" == t.msg) {
                                wx.showToast({
                                    title: "取消收藏成功",
                                    icon: "success",
                                    duration: 2e3
                                });
                                var s = "mark";
                                0 == a ? s = "mark" : 1 == a ? s = "favorite" : 2 == a && (s = "notes"), e.triggerEvent("updatedata", s), 
                                e.triggerEvent("hideQuestionModel", !1);
                            }
                        });
                    } else t.cancel && console.log("用户点击取消");
                }
            }) : (this.setData({
                isShowActHint: !1,
                tabIndex: -1,
                BusNotes: "",
                BusKeyList: [],
                BusKeyIndex: -1,
                inputBusKey: "",
                isModelShow: !1
            }), this.triggerEvent("hideQuestionModel", !1));
        },
        checkedBusKeyList: function(t) {
            var e = t.currentTarget.dataset.index;
            this.setData({
                BusKeyIndex: e,
                inputBusKey: this.data.BusKeyList[e]
            });
        },
        inputBusKey: function(t) {
            var e = t.detail.value;
            e ? this.setData({
                BusKeyValue: e,
                BusKeyIndex: -1
            }) : this.setData({
                BusKeyValue: e
            });
        },
        changeNotes: function(t) {
            this.setData({
                BusNotes: t.detail.value
            });
        },
        showMode: function(t) {
            var e = this;
            console.log(this.data.BookID, "4545");
            var a = this.data.tabIndex, s = 0 == a ? "错题" : 1 == a ? "收藏" : "笔记";
            l.GetSysUserBookCatalog({
                StuID: this.data.StuID,
                BusType: s,
                Type: "用户笔记本",
                System_Station_ID: n.globalData.SassID,
                BusValue: 0 == n.globalData.subjectindex ? "数一" : 1 == n.globalData.subjectindex ? "数二" : 2 == n.globalData.subjectindex ? "数三" : "数一"
            }).then(function(t) {
                var a = [], o = "";
                Array.isArray(t.data) && t.data.length > 0 && Array.isArray(t.data[0]) && (o = "默认分类", 
                t.data[0].map(function(t) {
                    "默认分类" == t.Name ? a.unshift(t) : t.Name && a.push(t);
                }));
                0 == a.length ? a.push({
                    StuID: e.data.StuID,
                    BusType: s,
                    Type: "用户笔记本",
                    System_Station_ID: n.globalData.SassID,
                    Name: "默认分类",
                    ID: 0
                }) : a.some(function(t) {
                    return "默认分类" == t.Name;
                }) || a.unshift({
                    StuID: e.data.StuID,
                    BusType: s,
                    Type: "用户笔记本",
                    System_Station_ID: n.globalData.SassID,
                    Name: "默认分类",
                    ID: 0
                });
                console.log(a, "BusKeyList"), e.setData({
                    BusNotes: "",
                    isModelShow: !0,
                    BusKeyList: a,
                    BusKeyIndex: 0,
                    BusKeyValue: o
                }), 0 == e.data.BookID ? r.GetQuestionSearchPhotoList({
                    page: 0,
                    limit: 1,
                    QuestionID: e.data.questionID
                }).then(function(t) {
                    Array.isArray(t.data) && t.data.length > 0 ? (e.data.BookID = t.data[0].BookID, 
                    e.getQuestionnotesList(), e.getUserNoteCounts()) : r.GetQuestionListBySearch({
                        page: 0,
                        limit: 1,
                        ID: e.data.questionID
                    }).then(function(t) {
                        Array.isArray(t.data) && t.data.length > 0 && (e.data.BookID = t.data[0].BookID, 
                        e.getQuestionnotesList(), e.getUserNoteCounts());
                    });
                }) : (e.getQuestionnotesList(), e.getUserNoteCounts());
            });
        },
        getQuestionnotesList: function() {
            var t = this, e = a.default.recordType.mark, s = this.data.tabIndex;
            0 == s ? (e = a.default.recordType.mark, this.data.markList = []) : 1 == s ? (e = a.default.recordType.favorite, 
            this.data.favoriteList = []) : 2 == s && (e = a.default.recordType.notes, this.data.notesList = []);
            var o = {
                StuID: this.data.StuID,
                Type: e,
                QuestionID: this.data.questionID
            };
            l.GetSysUserBookQuestion(o).then(function(e) {
                var a = 0, o = [], i = "", n = t.data.BusKeyValue, r = [], l = [];
                Array.isArray(e.data) && (o = e.data, e.data.length > 0 && (i = e.data[0].Content ? e.data[0].Content : "", 
                e.data[0].ContentImg && null != e.data[0].ContentImg && "null" != e.data[0].ContentImg && (r = e.data[0].ContentImg.split(","), 
                l = e.data[0].ContentImg.split(","), e.data[0].ContentImg = e.data[0].ContentImg.split(",")), 
                t.data.BusKeyList.map(function(t, s) {
                    t.ID == e.data[0].CatalogID && (a = s, n = t.Name);
                })));
                var u;
                u = 3 == l.length, 0 == s ? t.setData({
                    markList: o,
                    BusKeyIndex: a,
                    BusNotes: i,
                    BusKeyValue: n,
                    uploadImgList: l,
                    imglist: r,
                    unUpload: u
                }) : 1 == s ? t.setData({
                    favoriteList: o,
                    BusKeyIndex: a,
                    BusNotes: i,
                    BusKeyValue: n,
                    uploadImgList: l,
                    imglist: r,
                    unUpload: u
                }) : 2 == s && t.setData({
                    notesList: o,
                    BusKeyIndex: a,
                    BusNotes: i,
                    BusKeyValue: n,
                    uploadImgList: l,
                    imglist: r,
                    unUpload: u
                });
            });
        },
        getUserNoteCounts: function() {
            var t = this, e = a.default.recordType.mark, s = this.data.tabIndex, o = 0;
            0 == s ? e = a.default.recordType.mark : 1 == s ? e = a.default.recordType.favorite : 2 == s && (e = a.default.recordType.notes);
            var i = n.globalData.appInfo.IsNotVipErrorQuestion, r = !1;
            2 == n.globalData.vipLevel && (r = !0), i > 0 && !r && s < 2 && l.GeSysUserBookQuestionCount({
                StuID: this.data.StuID,
                Type: e,
                System_Station_ID: n.globalData.SassID
            }).then(function(e) {
                Array.isArray(e.data) && e.data.length > 0 && Array.isArray(e.data[0]) && e.data[0].length > 0 && (o = e.data[0][0].count), 
                t.setData({
                    NotesCounts: o
                });
            });
        },
        submitfoot: function() {
            var t = this;
            if (this.data.IsAct) {
                var s = a.default.recordType.mark, o = this.data.tabIndex, i = 0;
                if (0 == o) {
                    s = a.default.recordType.mark, this.data.markList.length > 0 && (i = this.data.markList[0].ID);
                    var r = n.globalData.appInfo.IsNotVipErrorQuestion, d = this.data.NotesCounts, c = !1;
                    if (2 == n.globalData.vipLevel && (c = !0), r > 0 && !c && d > r) {
                        var h = this.data.isIOS, g = [];
                        return g = h ? [ {
                            content: "我知道了",
                            bgcolor: "#FFDC21",
                            color: "#333333",
                            id: 1
                        } ] : [ {
                            content: "我知道了",
                            bgcolor: "#F3F3F3",
                            color: "#333333",
                            id: 1
                        }, {
                            content: "了解会员",
                            bgcolor: "#FFDC21",
                            color: "#333333",
                            id: 2
                        } ], void this.setData(e(e({
                            isErrorShowHint: !0,
                            BusNotes: "",
                            isModelShow: !1,
                            tabIndex: 0
                        }, "ErrorHintmodel.content", h ? "权益用户尊享无上限错题本功能" : "开通会员尊享无上限错题本功能"), "ErrorHintmodel.btnList", g));
                    }
                } else if (1 == o) {
                    s = a.default.recordType.favorite, this.data.favoriteList.length > 0 && (i = this.data.favoriteList[0].ID);
                    var I = n.globalData.appInfo.IsNotVipCollectQuestion, p = this.data.NotesCounts, m = !1;
                    if (2 == n.globalData.vipLevel && (m = !0), I > 0 && !m && p > I) {
                        var D = this.data.isIOS, y = [];
                        return y = D ? [ {
                            content: "我知道了",
                            bgcolor: "#FFDC21",
                            color: "#333333",
                            id: 1
                        } ] : [ {
                            content: "我知道了",
                            bgcolor: "#F3F3F3",
                            color: "#333333",
                            id: 1
                        }, {
                            content: "了解会员",
                            bgcolor: "#FFDC21",
                            color: "#333333",
                            id: 2
                        } ], void this.setData(e(e({
                            isCollectShowHint: !0,
                            BusNotes: "",
                            isModelShow: !1,
                            tabIndex: 0
                        }, "CollectHintmodel.content", D ? "权益用户尊享无上限错题本功能" : "开通会员尊享无上限收藏功能"), "ErrorHintmodel.btnList", y));
                    }
                } else 2 == o && (s = a.default.recordType.notes, this.data.notesList.length > 0 && (i = this.data.notesList[0].ID));
                if (this.data.BusKeyValue) {
                    var f = "";
                    this.data.uploadImgList.map(function(t) {
                        f = f + "," + t;
                    }), f = f.slice(1);
                    var v = this.data.booktabIndex, B = 0 == v ? "电子书" : 1 == v ? "真题" : 2 == v ? "课程" : 3 == v ? "选择题库" : 4 == v ? "专辑" : 5 == v ? "考试" : "", S = {
                        StuID: this.data.StuID,
                        Type: s,
                        QuestionID: this.data.questionID,
                        IsCourse: this.data.isCourse ? "2" : "1",
                        System_Station_ID: n.globalData.SassID,
                        Content: this.data.BusNotes,
                        BookID: this.data.BookID,
                        CatalogID: this.data.BusKeyIndex > -1 ? this.data.BusKeyList[this.data.BusKeyIndex].ID : 0,
                        ContentImg: f,
                        Source: B
                    }, b = {};
                    i > 0 && (S.ID = i, S.UpdateColumns = "CatalogID,Source,Content,ContentImg");
                    var w = this.data.BusKeyValue ? this.data.BusKeyValue.replace(/[\r\n]/g, "").replace(/(^\s*)|(\s*$)/g, "") + this.data.BusNotes : "";
                    console.log(S, "param"), 1 == n.globalData.appInfo.Parm2 ? u.GetScanText({
                        txt: w
                    }).then(function(e) {
                        "" == e.Data.Labels && "" == e.Data.Reason ? (console.log("检查通过"), 0 == S.CatalogID ? (b = {
                            StuID: t.data.StuID,
                            BusType: 0 == o ? "错题" : 1 == o ? "收藏" : "笔记",
                            Type: "用户笔记本",
                            System_Station_ID: n.globalData.SassID,
                            Name: t.data.BusKeyValue ? t.data.BusKeyValue.replace(/[\r\n]/g, "").replace(/(^\s*)|(\s*$)/g, "") : ""
                        }, l.AddSysUserBookCatalog(b).then(function(e) {
                            "操作成功" == e.msg && (S.CatalogID = e.data, l.AddSysUserBookQuestion(S).then(function(e) {
                                if ("操作成功" == e.msg) {
                                    var a = "mark";
                                    0 == o ? a = "mark" : 1 == o ? a = "favorite" : 2 == o && (a = "notes"), t.triggerEvent("updatedata", a), 
                                    t.setData({
                                        BusNotes: "",
                                        isModelShow: !1,
                                        tabIndex: -1
                                    }), wx.showToast({
                                        title: (0 == o ? "错题" : 1 == o ? "收藏" : "笔记") + "保存成功",
                                        icon: "success",
                                        duration: 2e3
                                    });
                                }
                            }));
                        })) : l.AddSysUserBookQuestion(S).then(function(e) {
                            if ("操作成功" == e.msg) {
                                var a = "mark";
                                0 == o ? a = "mark" : 1 == o ? a = "favorite" : 2 == o && (a = "notes"), t.triggerEvent("updatedata", a), 
                                t.setData({
                                    BusNotes: "",
                                    isModelShow: !1,
                                    tabIndex: -1
                                }), wx.showToast({
                                    title: (0 == o ? "错题" : 1 == o ? "收藏" : "笔记") + "保存成功",
                                    icon: "success",
                                    duration: 2e3
                                });
                            }
                        })) : (console.log("检查未通过"), wx.showToast({
                            title: "输入内容有违规文字",
                            icon: "none"
                        }));
                    }) : 0 == S.CatalogID ? (b = {
                        StuID: this.data.StuID,
                        BusType: 0 == o ? "错题" : 1 == o ? "收藏" : "笔记",
                        Type: "用户笔记本",
                        System_Station_ID: n.globalData.SassID,
                        Name: this.data.BusKeyValue ? this.data.BusKeyValue.replace(/[\r\n]/g, "").replace(/(^\s*)|(\s*$)/g, "") : ""
                    }, l.AddSysUserBookCatalog(b).then(function(e) {
                        "操作成功" == e.msg && (S.CatalogID = e.data, l.AddSysUserBookQuestion(S).then(function(e) {
                            if ("操作成功" == e.msg) {
                                var a = "mark";
                                0 == o ? a = "mark" : 1 == o ? a = "favorite" : 2 == o && (a = "notes"), t.triggerEvent("updatedata", a), 
                                t.setData({
                                    BusNotes: "",
                                    isModelShow: !1,
                                    tabIndex: -1
                                }), wx.showToast({
                                    title: (0 == o ? "错题" : 1 == o ? "收藏" : "笔记") + "保存成功",
                                    icon: "success",
                                    duration: 2e3
                                });
                            }
                        }));
                    })) : l.AddSysUserBookQuestion(S).then(function(e) {
                        if ("操作成功" == e.msg) {
                            var a = "mark";
                            0 == o ? a = "mark" : 1 == o ? a = "favorite" : 2 == o && (a = "notes"), t.triggerEvent("updatedata", a), 
                            t.setData({
                                BusNotes: "",
                                isModelShow: !1,
                                tabIndex: -1
                            }), wx.showToast({
                                title: (0 == o ? "错题" : 1 == o ? "收藏" : "笔记") + "保存成功",
                                icon: "success",
                                duration: 2e3
                            });
                        }
                    });
                } else wx.showToast({
                    title: "错题分类不能为空！",
                    icon: "error",
                    duration: 2e3
                });
            } else this.setData({
                isShowActHint: !0
            });
        },
        clearErrormodel: function() {
            this.setData({
                isErrorShowHint: !1
            });
        },
        ErrorhideHint: function(t) {
            var e = t.detail.id;
            1 == e ? this.clearErrormodel() : 2 == e && (this.clearErrormodel(), wx.navigateTo({
                url: "/wenjuan/pages/VIPInfo/VIPInfo"
            }));
        },
        clearCollectmodel: function() {
            this.setData({
                isCollectShowHint: !1
            });
        },
        CollecthideHint: function(t) {
            var e = t.detail.id;
            1 == e ? this.clearCollectmodel() : 2 == e && (this.clearCollectmodel(), wx.navigateTo({
                url: "/wenjuan/pages/VIPInfo/VIPInfo"
            }));
        }
    }
});