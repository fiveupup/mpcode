var e = getApp();

Component({
    properties: {
        isiosservice: {
            type: Boolean,
            observer: function(a) {
                a && (e.globalData.IosServiceimg ? this.setData({
                    IosServiceimg: e.globalData.IosServiceimg
                }) : wx.navigateTo({
                    url: "/wenjuan/pages/VIPInfo/VIPInfo"
                }));
            }
        }
    },
    data: {
        isIOS: e.globalData.isIOS,
        IosServiceimg: e.globalData.IosServiceimg
    },
    methods: {
        gotoImg: function() {},
        gotoIosservice: function(e) {
            var a = e.currentTarget.dataset.index;
            1 == a || 2 == a && (this.setData({
                isiosservice: !1
            }), this.triggerEvent("hideIosService", !1));
        },
        gotovippage: function() {
            e.globalData.StuID && e.globalData.isLogin ? wx.navigateTo({
                url: "/wenjuan/pages/VIPInfo/VIPInfo"
            }) : wx.navigateTo({
                url: "/pages/login"
            });
        }
    }
});