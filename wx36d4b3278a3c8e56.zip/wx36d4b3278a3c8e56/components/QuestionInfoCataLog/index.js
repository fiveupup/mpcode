(t = require("../../utils/util")) && t.__esModule;

var t, o = require("../../api/product.js");

var a = getApp(), i = (a.window, new o.Product());

Component({
    options: {
        addGlobalClass: !0
    },
    properties: {
        isleadfillcourse: {
            type: Boolean,
            value: !1
        },
        QuestionInfo: {
            type: Object,
            observer: function(t) {
                t.ID > 0 && t.ID != this.data.QuestionID && (this.data.QuestionID = t.ID, this.setData({
                    isFrist: !1,
                    DoExtrapolationList: [],
                    NoDoExtrapolationList: []
                }), this.getQuestionOtherInfo());
            }
        },
        bookID: {
            type: Number
        },
        isVip: {
            type: Boolean
        },
        isExtrapolationShow: {
            type: Boolean,
            value: !0
        },
        isSubmitExtrapolation: {
            type: Boolean,
            value: !1,
            observer: function(t) {
                t && this.data.SourceQuestionID > 0 && this.getQuestionExtrapolationList();
            }
        },
        SourceQuestionID: {
            type: Number,
            value: 0
        },
        IsDarkMode: {
            type: Boolean,
            value: !1
        }
    },
    data: {
        QuestionID: 0,
        OtherInfo: {
            Analysis: [],
            VLink: [],
            Disturb: [],
            Testing: [],
            Multisolution: [],
            Rub: [],
            Important: [],
            ModelBank: []
        },
        isFrist: !0,
        oldFilesList: [],
        ExtrapolationShow: !0,
        DoExtrapolationList: [],
        NoDoExtrapolationList: [],
        Extrapolation: []
    },
    pageLifetimes: {
        show: function() {
            this.data.oldFilesList.length > 0 && this.getzhongdian(this.data.oldFilesList), 
            this.data.isFrist || this.getQuestionExtrapolationList(), this.setData({
                isFrist: !1
            });
        }
    },
    methods: {
        getQuestionOtherInfo: function() {
            var t = this;
            this.data.QuestionInfo.ID > 0 && (this.setData({
                OtherInfo: {
                    Analysis: [],
                    VLink: [],
                    Disturb: [],
                    Testing: [],
                    Multisolution: [],
                    Rub: [],
                    Important: [],
                    ModelBank: []
                }
            }), this.data.oldFilesList = [], i.GetQuestionOtherInfoNew({
                ID: this.data.QuestionID,
                System_Station_ID: a.globalData.SassID,
                SortDesc: "Sort"
            }).then(function(o) {
                Array.isArray(o.data) && (o.data.map(function(o) {
                    o.Title && (o.Title = t.data.IsDarkMode ? a.towxml(o.Title, "markdown", {
                        theme: "dark"
                    }) : a.towxml(o.Title, "markdown"));
                }), t.data.oldFilesList = o.data), t.getzhongdian(t.data.oldFilesList);
            }), this.data.isExtrapolationShow && this.getQuestionExtrapolationList(!0));
        },
        gotoQdetails: function(t) {
            var o = t.currentTarget.dataset.index, a = t.currentTarget.dataset.item;
            1 == o ? wx.navigateTo({
                url: "/topic/pages/video?vid=" + a.BusValue + "&isVip=" + this.data.isVip + "&isquestion=1&QuestionID=" + this.data.QuestionID + "&BusID=" + a.ID + "&bookID=" + this.data.bookID
            }) : 7 == o ? wx.navigateTo({
                url: "/topic/pages/topicModel?QuestionID=" + this.data.QuestionID + "&BusID=" + a.ID + "&bookID=" + this.data.bookID
            }) : wx.navigateTo({
                url: "/topic/pages/topicdetails?QuestionID=" + this.data.QuestionID + "&otherinfoindex=" + o + "&BusID=" + a.ID + "&bookID=" + this.data.bookID
            });
        },
        getzhongdian: function(t) {
            var o = this, s = {
                Analysis: [],
                VLink: [],
                Disturb: [],
                Testing: [],
                Multisolution: [],
                Rub: [],
                Important: [],
                ModelBank: []
            };
            i.GetSysGive({
                BusType: 1,
                StuID: a.globalData.StuID,
                Type: 4,
                System_Station_ID: a.globalData.SassID,
                BusID: this.data.QuestionID
            }).then(function(a) {
                var i = [];
                Array.isArray(a.data) && (i = a.data), t.map(function(t) {
                    1 == t.IsValid && (t.iskeynote = !1, i.map(function(o) {
                        o.BusValue == t.ID && (t.iskeynote = !0);
                    }), "知识库" == t.BusUrl && t.BusID > 0 && t._question_code && (t.BusValue = t._question_code.Title), 
                    "视频解析" == t.BusType ? (0 == t.IsExamCourse && s.VLink.push(t), o.data.isleadfillcourse && 1 == t.IsExamCourse && s.VLink.push(t)) : "骚操作" == t.BusType ? s.Disturb.push(t) : "考点" == t.BusType ? s.Testing.push(t) : "一题多解" == t.BusType ? s.Multisolution.push(t) : "疑难点" == t.BusType ? s.Rub.push(t) : "重要结论" == t.BusType ? t.Context && s.Important.push(t) : "题目详解" == t.BusType ? s.Analysis.push(t) : "模板资源" == t.BusType && (t.BusValue = t._book_highscorealbum.Title, 
                    s.ModelBank.push(t)));
                }), o.triggerEvent("showdataLoading", !0), o.setData({
                    isdataLoading: !0,
                    OtherInfo: s
                });
            });
        },
        getQuestionExtrapolationList: function() {
            var t = this;
            a.globalData.StuID;
            this.setData({
                isExtrapolationEnd: !1
            }), i.GetQuestionExtrapolationList({
                stuid: a.globalData.StuID,
                QuestionID: this.data.isSubmitExtrapolation ? this.data.SourceQuestionID : this.data.QuestionID,
                limit: 3
            }).then(function(o) {
                var i = [], s = [], e = [], n = !1, u = 0;
                Array.isArray(o.data) && o.data.length > 0 && (i = o.data, o.data.map(function(i) {
                    i.IsDiscuss > 0 ? (u += 1, s.push(i)) : (i.QuestionTxt && (i.QuestionTxt = t.data.IsDarkMode ? a.towxml(i.QuestionTxt, "markdown", {
                        theme: "dark"
                    }) : a.towxml(i.QuestionTxt, "markdown")), e.push(i)), u == o.data.length && (n = !0), 
                    i.BusType = "举一反三";
                })), t.setData({
                    Extrapolation: i,
                    DoExtrapolationList: s,
                    NoDoExtrapolationList: e,
                    isextrapolationEnd: n
                });
            });
        },
        gotoExtrapolationQuestion: function(t) {
            if (this.data.isVip) {
                var o = t.currentTarget.dataset.item, a = "/topic/pages/Extrapolation/Extrapolation?courseID=" + o.ID + "&bookID=" + o.BookID + "&SourceQuestionID=" + this.data.QuestionID;
                a = o.IsDiscuss > 0 ? "/topic/pages/Extrapolation/Extrapolation?courseID=" + o.ID + "&bookID=" + o.BookID + "&SourceQuestionID=" + this.data.QuestionID + "&isLook=true" : "/topic/pages/Extrapolation/Extrapolation?courseID=" + o.ID + "&bookID=" + o.BookID + "&SourceQuestionID=" + this.data.SourceQuestionID + "&isLook=true", 
                wx.navigateTo({
                    url: a
                });
            }
        },
        showQuestionError: function(t) {
            var o = t.currentTarget.dataset.text;
            this.triggerEvent("showQuestionMode", o);
        }
    }
});