Component({
    properties: {
        myValue: {
            type: String,
            value: "考研数学欧几里得"
        },
        IsDarkMode: {
            type: Boolean,
            value: !1,
            observer: function(t) {
                this.setData({
                    IsDarkMode: t
                });
            }
        }
    },
    data: {
        text: "考研数学欧几里得",
        color: "rgba(231, 231, 231, 0.5)",
        rows: [],
        cols: [],
        IsDarkMode: !1
    },
    attached: function() {
        this.data.text = this.data.myValue;
        var t = this;
        wx.createSelectorQuery().in(this).select("#towxmlIDList").boundingClientRect(function(e) {
            var a = e.width, r = e.height, o = Math.ceil(a / (40 * t.data.text.length)), s = Math.ceil(r / 100);
            t.setData({
                rows: new Array(o),
                cols: new Array(s)
            });
        }).exec();
    }
});