var t, a = require("../../@babel/runtime/helpers/defineProperty"), i = (t = require("../../utils/util")) && t.__esModule ? t : {
    default: t
}, e = require("../../api/product.js");

var s = getApp(), d = new e.Product();

Component({
    properties: {
        videoID: {
            type: Number
        },
        vid: {
            type: String
        },
        StuID: {
            type: String
        }
    },
    data: {
        mydata: {
            ID: 0,
            BusNumber: 5,
            Content: ""
        },
        list: [],
        isShowSubmit: !1,
        isSubmit: !1,
        isAll: !1,
        pageIndex: 1,
        isloading: !1
    },
    lifetimes: {
        ready: function() {
            this.getlist(), this.getmydata();
        },
        detached: function() {}
    },
    ready: function() {
        this.getlist(), this.getmydata();
    },
    detached: function() {},
    methods: {
        getmydata: function() {
            var t = this, a = {
                BusType: 2,
                StuID: this.data.StuID,
                Type: 2,
                System_Station_ID: s.globalData.SassID,
                BusValue: this.data.vid,
                BusID: this.data.videoID,
                page: 1,
                limit: 1
            };
            d.GetSysGive(a).then(function(a) {
                Array.isArray(a.data) && a.data.length > 0 && t.setData({
                    mydata: a.data[0]
                });
            });
        },
        getlist: function() {
            var t = this, a = {
                BusType: 2,
                Type: 2,
                System_Station_ID: s.globalData.SassID,
                BusValue: this.data.vid,
                BusID: this.data.videoID,
                page: this.data.pageIndex,
                limit: 10
            };
            d.GetSysGive(a).then(function(a) {
                if (Array.isArray(a.data)) {
                    t.data.isloading = !1;
                    var e = t.data.list, s = !1;
                    a.data.map(function(t) {
                        t.AddTime = t.AddTime ? i.default.dateFormat("MM.DD HH:mm", t.AddTime) : "", e.push(t);
                    }), a.data.length < 10 && (s = !0), t.setData({
                        list: e,
                        isAll: s
                    });
                }
            });
        },
        gotoAppraise: function() {
            this.setData({
                isShowSubmit: !0
            });
        },
        changeEvalue: function(t) {
            this.setData(a({}, "mydata.BusNumber", t.detail));
        },
        changeinput: function(t) {
            this.setData(a({}, "mydata.Content", t.detail.value));
        },
        hideQuestion: function() {
            this.setData({
                isShowSubmit: !1
            });
        },
        submitData: function() {
            var t = this, a = {
                ID: this.data.mydata.ID,
                BusType: 2,
                StuID: this.data.StuID,
                Type: 2,
                System_Station_ID: s.globalData.SassID,
                BusValue: this.data.vid,
                BusID: this.data.videoID,
                BusNumber: this.data.mydata.BusNumber,
                Content: this.data.mydata.Content
            };
            d.AddSysGive(a).then(function(a) {
                "操作成功" == a.msg && (t.getmydata(), t.data.pageIndex = 1, t.data.list = [], t.getlist(), 
                t.setData({
                    isSubmit: !0
                }));
            });
        },
        hidemodel: function() {
            this.setData({
                isSubmit: !1,
                isShowSubmit: !1
            });
        },
        setdata: function() {
            this.data.isloading || (this.data.isloading = !0, this.data.pageIndex = this.data.pageIndex + 1, 
            this.getlist());
        }
    }
});