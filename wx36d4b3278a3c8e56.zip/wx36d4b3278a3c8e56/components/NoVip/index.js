var a = getApp();

Component({
    properties: {
        text: {
            type: String,
            value: "开通权益享受更多权益"
        },
        isHaveVipLookCount: {
            type: Boolean,
            value: !1
        },
        noVipImg: {
            type: String,
            value: "http://ysj-question.oss-cn-hangzhou.aliyuncs.com/Yjs/202205/0478d570-5ae9-46a5-8d10-4ab466701ffc.png"
        },
        IsDarkMode: {
            type: Boolean,
            value: !1
        }
    },
    data: {
        isIOS: a.globalData.isIOS,
        IosServiceimg: "",
        isiosservice: !1
    },
    methods: {
        gotoImg: function() {},
        showIosService: function(o) {
            this.data.isIOS && a.globalData.IosServiceimg ? this.triggerEvent("showvipIosService", !0) : wx.navigateTo({
                url: "/wenjuan/pages/VIPInfo/VIPInfo"
            });
        },
        hideIosService: function() {
            this.setData({
                isiosservice: !1
            });
        },
        gotovippage: function() {
            a.globalData.StuID && a.globalData.isLogin ? wx.navigateTo({
                url: "/wenjuan/pages/VIPInfo/VIPInfo"
            }) : wx.navigateTo({
                url: "/pages/login"
            });
        },
        getVipInfo: function() {
            a.globalData.StuID && a.globalData.isLogin ? this.triggerEvent("clickvipcount") : wx.navigateTo({
                url: "/pages/login"
            });
        },
        getvip: function() {
            a.globalData.StuID && a.globalData.isLogin ? wx.navigateTo({
                url: "/wenjuan/pages/VIPInfo/VIPInfo"
            }) : wx.navigateTo({
                url: "/pages/login"
            });
        }
    }
});