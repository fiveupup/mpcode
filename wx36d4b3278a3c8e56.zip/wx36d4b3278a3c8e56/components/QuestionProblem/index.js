var t = require("../../@babel/runtime/helpers/defineProperty");

Component({
    properties: {
        IsDarkMode: {
            type: Boolean,
            value: !1
        },
        IsLook: {
            type: Boolean,
            value: !1
        },
        QuestionOption: {
            type: Array
        },
        QuestionStem: {
            type: Array
        },
        ActiveOptionIDs: {
            type: Array,
            observer: function(e) {
                var o = this, i = [], n = [];
                if (this.data.QuestionOption && this.data.QuestionOption.length > 0) {
                    var s = this.data.QuestionOption;
                    console.log(s), s.map(function(s, a) {
                        s.IsActive && o.setData(t({}, "QuestionOption[" + a + "].IsActive", !1)), e.map(function(e) {
                            s.ID == e && (o.setData(t({}, "QuestionOption[" + a + "].IsActive", !0)), i.push(o.data.optionAList[a]));
                        }), 1 == s.IsAnswer && n.push(o.data.optionAList[a]);
                    }), n = n.length > 0 ? n.toString() : "无", i = i.length > 0 ? i.toString() : "未选择", 
                    this.setData({
                        myoptions: i,
                        analysisoptions: n
                    }), console.log(n, i);
                }
            }
        },
        Type: {
            type: String
        }
    },
    data: {
        optionAList: [ "A", "B", "C", "D", "E", "F", "G", "H", "I", "J", "K" ],
        myoptions: "",
        analysisoptions: ""
    },
    methods: {
        chengeoption: function(t) {
            this.triggerEvent("clickoption", t.currentTarget.dataset.item);
        }
    }
});