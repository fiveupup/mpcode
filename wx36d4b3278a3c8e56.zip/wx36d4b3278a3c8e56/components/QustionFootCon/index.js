(e = require("../../utils/util")) && e.__esModule;

var e, t = require("../../api/product.js"), a = require("../../api/user");

var s = getApp();

new t.Product(), new a.User();

Component({
    options: {
        addGlobalClass: !0
    },
    properties: {
        isIOS: {
            type: Boolean,
            value: s.globalData.isIOS
        },
        markList: {
            type: Array
        },
        favoriteList: {
            type: Array
        },
        notesList: {
            type: Array
        },
        StuID: {
            type: String
        },
        IsAct: {
            type: Boolean,
            value: !0
        },
        isCourse: {
            type: Boolean,
            value: !1
        },
        IsDarkMode: {
            type: Boolean,
            value: !1,
            observer: function(e) {
                e ? this.setData({
                    IsDarkModetext: "dark_"
                }) : this.setData({
                    IsDarkModetext: ""
                });
            }
        }
    },
    data: {
        IsDarkModetext: ""
    },
    methods: {
        preventTouchMove: function() {},
        previewImg: function(e) {
            wx.previewImage({
                current: e.target.dataset.src,
                urls: [ e.target.dataset.src ]
            });
        },
        chooseImg: function() {
            var e = this, t = e.data.imglist, a = e.data.uploadImgList;
            wx.chooseMedia({
                count: 3,
                mediaType: [ "image" ],
                sizeType: [ "original", "compressed" ],
                sourceType: [ "album", "camera" ],
                success: function(s) {
                    var r = [];
                    if (s.tempFiles.map(function(e) {
                        r.push(e.tempFilePath);
                    }), (t = t.concat(r)).length < 3) {
                        var o = new Set(t);
                        e.setData({
                            imglist: Array.from(o)
                        }), e.uploadImg(r);
                    } else {
                        wx.showToast({
                            icon: "none",
                            title: "最多可以选3张图片"
                        }), t.length <= 3 && a.length < 3 && e.uploadImg(r), t = t.slice(0, 3);
                        var i = new Set(t);
                        e.setData({
                            unUpload: !0,
                            imglist: Array.from(i)
                        });
                    }
                }
            });
        }
    }
});