Component({
    properties: {
        Sum: {
            type: Number,
            value: 5
        },
        checkedNum: {
            type: Number,
            value: 3
        },
        noColor: {
            type: String,
            value: "#D9D9D9"
        },
        activeColor: {
            type: String,
            value: "#F8D757"
        },
        gap: {
            type: Number,
            value: 10
        },
        size: {
            type: Number,
            value: 32
        },
        iconType: {
            type: String,
            value: "iconshoucang"
        },
        isClick: {
            type: Boolean,
            value: !1
        },
        pjiaimageurl: {
            type: String,
            value: "/topic/images/ku.png"
        },
        isevaluate: {
            type: Boolean,
            value: !1
        }
    },
    data: {},
    methods: {
        changeIndex: function(e) {
            if (this.data.isClick) {
                var t = e.currentTarget.dataset.index + 1;
                this.setData({
                    checkedNum: t
                }), this.triggerEvent("checkNum", t);
            }
        }
    }
});