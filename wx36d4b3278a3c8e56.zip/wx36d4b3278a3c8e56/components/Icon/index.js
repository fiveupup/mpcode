Component({
    properties: {
        type: {
            value: "",
            type: String
        },
        size: {
            value: void 0,
            type: Number
        },
        color: {
            value: "",
            type: String
        },
        isPx: {
            type: Boolean,
            value: !1
        }
    },
    data: {},
    methods: {}
});