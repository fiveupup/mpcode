var t = require("../../@babel/runtime/helpers/defineProperty"), e = require("../../api/product.js"), a = require("../../api/user"), s = getApp(), i = new e.Product(), n = new a.User();

Component({
    properties: {
        StuID: {
            type: String
        },
        QuestionID: {
            type: Number
        },
        BookID: {
            type: Number,
            value: 0
        },
        QuestionErrorBaseType: {
            type: String,
            value: "",
            observer: function(t) {
                var e = [ {
                    name: "题干有误",
                    type: 1,
                    isState: !1
                }, {
                    name: "答案有误",
                    type: 1,
                    isState: !1
                }, {
                    name: "解析有误",
                    type: 1,
                    isState: !1
                }, {
                    name: "有错别字",
                    type: 2,
                    isState: !1
                }, {
                    name: "其他（请补充）",
                    type: 2,
                    isState: !1
                } ], a = "题目反馈";
                "文字解析" == t ? (e = [ {
                    name: "有错别字",
                    type: 1,
                    isState: !1
                }, {
                    name: "有乱码",
                    type: 1,
                    isState: !1
                }, {
                    name: "出现乱码",
                    type: 1,
                    isState: !1
                }, {
                    name: "图像错误",
                    type: 2,
                    isState: !1
                }, {
                    name: "题干或答案有误",
                    type: 2,
                    isState: !1
                }, {
                    name: "内容有误",
                    type: 2,
                    isState: !1
                }, {
                    name: "其他（请补充）",
                    type: 2,
                    isState: !1
                }, {
                    name: "跳步严重",
                    type: 1,
                    isState: !1
                }, {
                    name: "逻辑混乱",
                    type: 1,
                    isState: !1
                }, {
                    name: "前后矛盾",
                    type: 1,
                    isState: !1
                } ], a = "解析反馈") : "视频解析" == t ? (a = "视频反馈", e = [ {
                    name: "视频与题干不对应",
                    type: 2,
                    isState: !1
                }, {
                    name: "视频播放错误",
                    type: 2,
                    isState: !1
                }, {
                    name: "讲解错误",
                    type: 2,
                    isState: !1
                }, {
                    name: "其他（请补充）",
                    type: 2,
                    isState: !1
                } ]) : "骚操作" == t ? (a = "秒杀技巧反馈", e = [ {
                    name: "题干与解析不对应",
                    type: 2,
                    isState: !1
                }, {
                    name: "我有更好的秒杀技巧",
                    type: 2,
                    isState: !1
                }, {
                    name: "解析错误",
                    type: 2,
                    isState: !1
                }, {
                    name: "其他（请补充）",
                    type: 2,
                    isState: !1
                } ]) : "疑难点" == t ? (a = "疑难点反馈", e = [ {
                    name: "文字数字符号公式错误",
                    type: 2,
                    isState: !1
                }, {
                    name: "疑难点与题干不对应",
                    type: 2,
                    isState: !1
                }, {
                    name: "其他（请补充）",
                    type: 2,
                    isState: !1
                } ]) : "考点" == t ? (a = "考点反馈", e = [ {
                    name: "文字数字符号公式错误",
                    type: 2,
                    isState: !1
                }, {
                    name: "考点与题干不对应",
                    type: 2,
                    isState: !1
                }, {
                    name: "考点有误",
                    type: 2,
                    isState: !1
                }, {
                    name: "其他（请补充）",
                    type: 2,
                    isState: !1
                } ]) : "一题多解" == t ? (a = "一题多解反馈", e = [ {
                    name: "有错别字",
                    type: 1,
                    isState: !1
                }, {
                    name: "有乱码",
                    type: 1,
                    isState: !1
                }, {
                    name: "出现乱码",
                    type: 1,
                    isState: !1
                }, {
                    name: "图像错误",
                    type: 2,
                    isState: !1
                }, {
                    name: "题干或答案有误",
                    type: 2,
                    isState: !1
                }, {
                    name: "内容有误",
                    type: 2,
                    isState: !1
                }, {
                    name: "其他（请补充）",
                    type: 2,
                    isState: !1
                }, {
                    name: "跳步严重",
                    type: 1,
                    isState: !1
                }, {
                    name: "逻辑混乱",
                    type: 1,
                    isState: !1
                }, {
                    name: "前后矛盾",
                    type: 1,
                    isState: !1
                } ]) : "重要结论" == t ? (a = "重要结论反馈", e = [ {
                    name: "文字数字符号公式错误",
                    type: 2,
                    isState: !1
                }, {
                    name: "重要结论与题干不对应",
                    type: 2,
                    isState: !1
                }, {
                    name: "重要结论有误",
                    type: 2,
                    isState: !1
                }, {
                    name: "其他（请补充）",
                    type: 2,
                    isState: !1
                } ]) : "举一反三" == t ? (a = "举一反三反馈", e = [ {
                    name: "推题不准",
                    type: 2,
                    isState: !1
                }, {
                    name: "推题题干错误",
                    type: 2,
                    isState: !1
                }, {
                    name: "其他（请补充）",
                    type: 2,
                    isState: !1
                } ]) : e = "题反馈" == t ? [ {
                    name: "有错别字",
                    type: 1,
                    isState: !1
                }, {
                    name: "有乱码",
                    type: 1,
                    isState: !1
                }, {
                    name: "出现乱码",
                    type: 1,
                    isState: !1
                }, {
                    name: "图像错误",
                    type: 1,
                    isState: !1
                }, {
                    name: "题干或答案有误",
                    type: 2,
                    isState: !1
                }, {
                    name: "内容有误",
                    type: 1,
                    isState: !1
                }, {
                    name: "其他（请补充）",
                    type: 2,
                    isState: !1
                }, {
                    name: "跳步严重",
                    type: 1,
                    isState: !1
                }, {
                    name: "逻辑混乱",
                    type: 1,
                    isState: !1
                }, {
                    name: "前后矛盾",
                    type: 1,
                    isState: !1
                } ] : [ {
                    name: "题干有误",
                    type: 1,
                    isState: !1
                }, {
                    name: "答案有误",
                    type: 1,
                    isState: !1
                }, {
                    name: "解析有误",
                    type: 1,
                    isState: !1
                }, {
                    name: "有错别字",
                    type: 2,
                    isState: !1
                }, {
                    name: "其他（请补充）",
                    type: 2,
                    isState: !1
                } ], this.setData({
                    list: e,
                    errorTitle: a
                });
            }
        },
        booktabIndex: {
            type: Number,
            value: -1
        },
        IsDarkMode: {
            type: Boolean,
            value: !1,
            observer: function(t) {
                t ? this.setData({
                    IsDarkModetext: "dark_"
                }) : this.setData({
                    IsDarkModetext: ""
                });
            }
        }
    },
    data: {
        list: [ {
            name: "题干有误",
            type: 1,
            isState: !1
        }, {
            name: "答案有误",
            type: 1,
            isState: !1
        }, {
            name: "解析有误",
            type: 1,
            isState: !1
        }, {
            name: "有错别字",
            type: 2,
            isState: !1
        }, {
            name: "其他（请补充）",
            type: 2,
            isState: !1
        } ],
        errorTitle: "题目反馈",
        inputValue: "",
        isSubmit: !1,
        isUploadImg: !1,
        imglist: [],
        uploadImgList: [],
        isUploadAnswerImg: !1,
        answerimglist: [],
        uploadAnswerImgList: [],
        unUpload: !1,
        isloading: !1,
        imgList1: [],
        defImg: "",
        IsDarkModetext: ""
    },
    methods: t({
        checkedList: function(e) {
            var a = e.currentTarget.dataset.index;
            this.setData(t({}, "list[" + a + "].isState", !this.data.list[a].isState));
        },
        changeinput: function(t) {
            this.setData({
                inputValue: t.detail.value
            });
        },
        hideQuestion: function() {
            this.triggerEvent("hideQuestionModel");
        },
        submitData: function() {
            var t = this;
            if (!this.data.isloading) {
                this.data.isloading = !0;
                var e = "";
                if (this.data.list.map(function(t) {
                    t.isState && (e = e + "," + t.name);
                }), !e) return this.data.isloading = !1, wx.showModal({
                    title: "提示",
                    content: "请选择题目错误类型！",
                    showCancel: !1,
                    confirmColor: "#FFE002",
                    confirmText: "我知道了"
                }), !1;
                if (e = e.substr(1), !this.data.inputValue) return this.data.isloading = !1, wx.showModal({
                    title: "提示",
                    content: "请填写补充说明！",
                    showCancel: !1,
                    confirmColor: "#FFE002",
                    confirmText: "我知道了"
                }), !1;
                if (this.data.inputValue.length < 5) return this.data.isloading = !1, wx.showModal({
                    title: "提示",
                    content: "补充说明不能少于5个字！",
                    showCancel: !1,
                    confirmColor: "#FFE002",
                    confirmText: "我知道了"
                }), !1;
                var a = "";
                if (this.data.uploadImgList.map(function(t) {
                    a = a + "," + t;
                }), "" == (a = a.slice(1))) return this.data.isloading = !1, wx.showToast({
                    icon: "none",
                    title: "请上传错误描述图片"
                }), !1;
                var o = "";
                this.data.uploadAnswerImgList.map(function(t) {
                    o = o + "," + t;
                }), o = o.slice(1);
                this.data.booktabIndex;
                var m = {
                    BusType: 1,
                    Type: 3,
                    StuID: this.data.StuID,
                    BusID: this.data.QuestionID,
                    BusValue: e,
                    Content: this.data.inputValue,
                    System_Station_ID: s.globalData.SassID,
                    BusNumber: 0,
                    Notes: a,
                    AnswerImg: o,
                    BookID: this.data.BookID,
                    BaseType: this.data.QuestionErrorBaseType
                };
                1 == s.globalData.appInfo.Parm2 ? n.GetScanText({
                    txt: this.data.inputValue
                }).then(function(e) {
                    "" == e.Data.Labels && "" == e.Data.Reason ? (console.log("检查通过"), i.AddSysGive(m).then(function(e) {
                        t.data.isloading = !1, "操作成功" == e.msg && t.setData({
                            isSubmit: !0
                        });
                    })) : (console.log("检查未通过"), wx.showToast({
                        title: "输入内容有违规文字",
                        icon: "none"
                    }));
                }) : i.AddSysGive(m).then(function(e) {
                    t.data.isloading = !1, "操作成功" == e.msg && t.setData({
                        isSubmit: !0
                    });
                });
            }
        },
        hidemodel: function() {
            this.setData({
                isSubmit: !1
            }), this.triggerEvent("hideQuestionModel");
        },
        previewImg: function(t) {
            this.selectComponent("#previewComponenterror").showPreview(), this.setData({
                defImg: t.target.dataset.src,
                imgList1: this.data.imglist
            });
        },
        chooseImg: function() {
            console.log("点击选择错误反馈图片");
            var t = this, e = t.data.imglist;
            wx.chooseImage({
                count: 1,
                sizeType: [ "original", "compressed" ],
                sourceType: [ "album", "camera" ],
                success: function(a) {
                    var s = a.tempFilePaths;
                    if ((e = e.concat(s)).length < 3) {
                        var i = new Set(e);
                        t.setData({
                            imglist: Array.from(i)
                        }), t.uploadImg(s);
                    } else {
                        wx.showToast({
                            icon: "none",
                            title: "最多可以选3张图片"
                        }), e = e.slice(0, 3);
                        var n = new Set(e);
                        t.setData({
                            unUpload: !0,
                            imglist: Array.from(n)
                        });
                    }
                }
            });
        },
        uploadImg: function(t) {
            console.log(t);
            for (var e = this, a = [], i = (a = e.data.uploadImgList, 0); i < t.length; i++) wx.uploadFile({
                filePath: t[i],
                name: "file",
                url: s.globalData.configs.TOP_HOST + "/api/sys_attachment/LayuiUpImg",
                header: {
                    "Content-Type": "application/x-www-form-urlencoded"
                },
                success: function(t) {
                    var s = t.data;
                    s = JSON.parse(s).data, a.push(s.src), e.setData({
                        uploadImgList: a,
                        isUploadImg: !0
                    });
                }
            });
        },
        delImg: function(t) {
            var e = t.currentTarget.dataset.idx, a = this.data.imglist, s = this.data.uploadImgList;
            a.splice(e, 1), s.splice(e, 1), this.setData({
                imglist: a,
                uploadImgList: s,
                isUploadImg: !1
            });
        },
        chooseAnswerImg: function() {
            console.log("点击选择答案图片");
            var t = this, e = t.data.answerimglist;
            wx.chooseImage({
                count: 1,
                sizeType: [ "original", "compressed" ],
                sourceType: [ "album", "camera" ],
                success: function(a) {
                    var s = a.tempFilePaths;
                    if ((e = e.concat(s)).length < 3) {
                        var i = new Set(e);
                        t.setData({
                            answerimglist: Array.from(i)
                        }), t.uploadAnswerImg(s);
                    } else {
                        wx.showToast({
                            icon: "none",
                            title: "最多可以选3张图片"
                        }), e = e.slice(0, 3);
                        var n = new Set(e);
                        t.setData({
                            unUpload: !0,
                            answerimglist: Array.from(n)
                        });
                    }
                }
            });
        },
        uploadAnswerImg: function(t) {
            console.log(t);
            for (var e = this, a = [], i = (a = e.data.uploadAnswerImgList, 0); i < t.length; i++) wx.uploadFile({
                filePath: t[i],
                name: "file",
                url: s.globalData.configs.TOP_HOST + "/api/sys_attachment/LayuiUpImg",
                header: {
                    "Content-Type": "application/x-www-form-urlencoded"
                },
                success: function(t) {
                    var s = t.data;
                    s = JSON.parse(s).data, a.push(s.src), e.setData({
                        uploadAnswerImgList: a,
                        isUploadAnswerImg: !0
                    });
                }
            });
        },
        delAnswerImg: function(t) {
            var e = t.currentTarget.dataset.idx, a = this.data.answerimglist, s = this.data.uploadAnswerImgList;
            a.splice(e, 1), s.splice(e, 1), this.setData({
                answerimglist: a,
                uploadAnswerImgList: s,
                isUploadAnswerImg: !1
            });
        }
    }, "previewImg", function(t) {
        this.selectComponent("#previewComponenterror").showPreview(), this.setData({
            defImg: t.target.dataset.src,
            imgList1: this.data.answerimglist
        });
    })
});