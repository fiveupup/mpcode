Component({
    properties: {},
    data: {},
    methods: {}
});