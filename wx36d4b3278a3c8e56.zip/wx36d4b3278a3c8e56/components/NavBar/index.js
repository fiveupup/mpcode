var t = getApp().window;

Component({
    properties: {
        props: {
            type: Object,
            observer: function(t) {
                t.title && (t.title = t.title.length > 12 ? t.title.substring(0, 12) + ".." : t.title), 
                this.setData({
                    props: t
                });
            }
        },
        color: String,
        othergoback: Boolean,
        othergoHome: Boolean
    },
    data: {
        window: t
    },
    methods: {
        goback: function() {
            this.data.othergoback ? this.triggerEvent("othergoback") : wx.navigateBack();
        },
        goHomeback: function() {
            this.data.othergoHome ? this.triggerEvent("othergoHome") : wx.switchTab({
                url: "/pages/study/study"
            });
        },
        gohomeClass: function() {
            this.triggerEvent("tabclass");
        },
        gotobook: function() {
            this.triggerEvent("gotobook");
        }
    }
});