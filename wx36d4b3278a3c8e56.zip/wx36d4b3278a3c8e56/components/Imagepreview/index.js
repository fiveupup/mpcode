var t, a = getApp().window;

Component({
    properties: {
        previewImgList: {
            type: Array,
            value: !1
        },
        previewImg: {
            type: null,
            value: !1
        },
        isrotate: {
            type: Boolean,
            value: !1
        }
    },
    attached: function() {
        t = this;
    },
    data: {
        window: a,
        preview_box_top: 0,
        left: "0px;",
        touchS: [ 0, 0 ],
        touchE: [ 0, 0 ],
        index: 0,
        imgindex: 0,
        previewHideStatus: !1,
        scale: 1,
        scaleObj: {
            scale: 1,
            x: 0,
            y: 0,
            yes: !0
        },
        touchStartTime: 0,
        touchEndTime: 0,
        lastTapTime: 0,
        lastTapTimeoutFunc: null,
        rotate: 90,
        pagewidth: 0,
        pageheight: 0,
        winheight: parseInt(a.screenHeight) - 60
    },
    methods: {
        jingzhi: function(a) {
            this.data.touchEndTime, this.data.touchStartTime;
            var e = a.timeStamp, i = this.data.lastTapDiffTime;
            this.data.lastTapDiffTime = e, e - i < 300 ? (console.log("double tap"), clearTimeout(this.data.lastTapTimeoutFunc), 
            1 == t.data.scale ? t.setData({
                scale: 3
            }) : t.setData({
                scale: 1
            })) : this.data.lastTapTimeoutFunc = setTimeout(function() {
                console.log("single tap"), t.data.scaleObj.yes;
            }, 300);
        },
        configqxClick: function(t) {
            this.setData({
                scopeWritePhotosAlbum: t.detail
            });
        },
        touchStart: function(t) {
            this.data.touchStartTime = t.timeStamp;
            var a = t.touches[0].pageX, e = t.touches[0].pageY;
            this.data.touchS = [ a, e ];
        },
        touchMove: function(t) {
            this.data.touchS;
            var a = t.touches[0].pageX, e = t.touches[0].pageY;
            this.data.touchE = [ a, e ];
        },
        touchEnd: function(t) {
            var a = this;
            this.data.touchEndTime = t.timeStamp;
            var e = this.data.touchS, i = this.data.touchE, s = this.data.scaleObj;
            s.yes && (0 == i[0] ? console.log("点击") : e[0] < i[0] - 50 && 1 == s.scale && 0 == s.x && 0 == s.y ? 0 !== this.data.index && (this.data.index -= 1, 
            this.data.imgindex -= 1, this.setData({
                index: this.data.index,
                left: "-" + this.data.index + "00%;transition: all .5s;",
                imgindex: this.data.imgindex
            })) : e[0] > i[0] + 50 && 1 == s.scale && 0 == s.x && 0 == s.y ? this.data.index !== this.data.previewImgList.length - 1 && (this.data.index += 1, 
            this.data.imgindex += 1, this.setData({
                index: this.data.index,
                left: "-" + this.data.index + "00%;transition: all .5s;",
                imgindex: this.data.imgindex
            })) : console.log("下滑/上滑"), this.data.touchE = [ 0, 0 ]), setTimeout(function() {
                0 == a.data.scaleObj.x && 0 == a.data.scaleObj.y && 1 == a.data.scaleObj.scale && (a.data.scaleObj.yes = !0);
            }, 500);
        },
        showPreview: function() {
            this.setData({
                previewHideStatus: !0,
                preview_box_top: 0
            });
        },
        hidePreview: function() {
            this.setData({
                previewHideStatus: !1,
                preview_box_top: 0,
                previewImg: null
            });
        },
        onScale: function(t) {
            this.data.scaleObj = {
                scale: t.detail.scale,
                x: t.detail.x,
                y: t.detail.y,
                yes: !1
            };
        },
        stopPageScroll: function() {},
        changerotate: function() {
            var t = this.data.rotate;
            t < 90 ? t = 270 : t < 180 ? t = 0 : t < 270 ? t = 90 : t < 360 && (t = 180);
            var a = this.data.pagewidth, e = this.data.pageheight;
            this.setData({
                rotate: t,
                pagewidth: e,
                pageheight: a
            });
        }
    },
    observers: {
        previewImgList: function(t) {},
        previewImg: function(t) {
            var e = this;
            this.data.isrotate && this.setData({
                rotate: 90,
                touchS: [ 0, 0 ],
                touchE: [ 0, 0 ],
                scale: 1
            }), this.data.previewImgList.map(function(a, i) {
                if (a == t) {
                    var s = i;
                    s += 1, e.setData({
                        index: i,
                        imgindex: s,
                        left: "-" + i + "00%;"
                    });
                }
            }), this.setData({
                pagewidth: a.screenHeight - 60,
                pageheight: a.screenWidth
            }), this.data.isrotate && this.changerotate();
        }
    }
});