var e = require("../@babel/runtime/helpers/createForOfIteratorHelper"), t = require("../@babel/runtime/helpers/typeof"), o = require("miniprogram-render").$$adapter, n = o.Event, a = o.cache, r = o.tool;

function i(e, o) {
    if ("number" == typeof e && "number" == typeof o) return parseInt(1e3 * e, 10) === parseInt(1e3 * o, 10);
    if ("object" === t(e) && "object" === t(o)) {
        if (null === e || null === o) return e === o;
        var n = Array.isArray(e), a = Array.isArray(o);
        if (n && a) {
            if (e.length !== o.length) return !1;
            for (var r = 0, s = e.length; r < s; r++) if (!i(e[r], o[r])) return !1;
            return !0;
        }
        if (!a && !a) {
            var d = Object.keys(e), l = Object.keys(o);
            if (d.length !== l.length) return !1;
            for (var c = 0, h = d; c < h.length; c++) {
                var m = h[c];
                if (!i(e[m], o[m])) return !1;
            }
            return !0;
        }
    }
    return e === o;
}

function s(o, n, a, s, d) {
    var l = o.props, c = void 0 === l ? [] : l, h = o.propsVal;
    if (c.length) {
        var m, p = e(c);
        try {
            for (p.s(); !(m = p.n()).done; ) {
                var u = m.value, f = a.getAttribute(u);
                if (void 0 === f && (f = a.getAttribute(r.toDash(u))), void 0 === f && h && (f = h[u]), 
                "string" == typeof (f = void 0 !== f ? f : null)) {
                    try {
                        var v = JSON.parse(f);
                        "object" === t(v) && (f = v);
                    } catch (e) {}
                    "string" == typeof f && (f = "false" !== f && f);
                }
                var g = r.toCamel(u);
                d && i(d[g], f) || (s[g] = f);
            }
        } catch (e) {
            p.e(e);
        } finally {
            p.f();
        }
    }
    var N = a.id;
    d && d.id === N || (s.id = N);
    var y = "wx-comp-".concat(n, " node-").concat(a.$$nodeId, " ").concat(a.className || "");
    d && d.className === y || (s.className = y);
    var $ = a.style.cssText;
    d && d.style === $ || (s.style = $);
    var b = a.childNodes.map(function(e) {
        var t = e.$$domInfo;
        return {
            slot: t.slot,
            nodeId: t.nodeId,
            pageId: t.pageId,
            id: t.id,
            className: "element" === t.type ? "h5-".concat(t.tagName, " node-").concat(t.nodeId, " ").concat(t.className || "") : "",
            style: t.style
        };
    }).filter(function(e) {
        return !!e.slot;
    });
    s.hasSlots = b.length, s.slots = b;
}

function d(e, t) {
    r.setData ? r.setData(e, t) : e.setData(t);
}

Component({
    properties: {
        kboneCustomComponentName: {
            type: String,
            value: ""
        }
    },
    options: {
        addGlobalClass: !0,
        virtualHost: !0
    },
    attached: function() {
        var t = this, o = this.dataset.privateNodeId, n = this.dataset.privatePageId, i = {};
        this.nodeId = o, this.pageId = n, this.domNode = a.getNode(n, o);
        var l = a.getConfig();
        this.compConfig = l.runtime && l.runtime.usingComponents && l.runtime.usingComponents[this.domNode.behavior] || {}, 
        this.onSelfNodeUpdate = r.throttle(this.onSelfNodeUpdate.bind(this)), this.domNode.$$clearEvent("$$domNodeUpdate", {
            $$namespace: "proxy"
        }), this.domNode.addEventListener("$$domNodeUpdate", this.onSelfNodeUpdate, {
            $$namespace: "proxy"
        });
        var c = this.compConfig.events, h = void 0 === c ? [] : c;
        if (h.length) {
            var m, p = e(h);
            try {
                var u = function() {
                    var e = m.value;
                    t["on".concat(e)] = function(o) {
                        return t.callSimpleEvent(e, o);
                    };
                };
                for (p.s(); !(m = p.n()).done; ) u();
            } catch (e) {
                p.e(e);
            } finally {
                p.f();
            }
        }
        s(this.compConfig, this.domNode.behavior, this.domNode, i), Object.keys(i).length && d(this, i), 
        this.domNode._wxCustomComponent = this.selectComponent(".node-".concat(this.domNode.$$nodeId));
    },
    detached: function() {
        this.nodeId = null, this.pageId = null, this.domNode._wxCustomComponent = null, 
        this.domNode = null;
    },
    methods: {
        onSelfNodeUpdate: function() {
            if (this.pageId && this.nodeId) {
                var e = {};
                s(this.compConfig, this.domNode.behavior, this.domNode, e, this.data), d(this, e), 
                this.domNode._wxCustomComponent = this.selectComponent(".node-".concat(this.domNode.$$nodeId));
            }
        },
        callSimpleEvent: function(e, t) {
            var o = this.domNode;
            o && o.$$trigger(e, {
                event: new n({
                    name: e,
                    target: o,
                    eventPhase: n.AT_TARGET,
                    detail: t && t.detail
                }),
                currentTarget: o
            });
        }
    }
});