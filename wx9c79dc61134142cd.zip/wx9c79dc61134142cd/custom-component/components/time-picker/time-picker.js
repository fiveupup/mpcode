require("../../../@babel/runtime/helpers/Arrayincludes");

var t = require("../../../@babel/runtime/helpers/slicedToArray");

Component({
    properties: {
        show: {
            type: Boolean,
            value: !1
        },
        title: {
            type: String,
            value: "选择时间"
        },
        allday: {
            type: Boolean,
            value: !1
        },
        startTimeData: {
            type: Object
        },
        starttime: {
            type: Number
        },
        lastTimeData: {
            type: Object,
            default: {}
        },
        lasttime: {
            type: Number
        },
        unfold: {
            type: String,
            value: ""
        },
        disable: {
            type: String,
            value: ""
        },
        unuse: {
            type: String,
            value: ""
        }
    },
    data: {
        startDateConfig: {
            year: 0,
            month: 0,
            day: 0
        },
        startTimeConfig: {
            minuteList: [ 0, 15, 30, 45 ],
            indexVal: [ 0, 0 ],
            hours: [],
            minutes: [],
            hourSize: 240,
            minuteSize: 400
        },
        lastTimeConfig: {
            oneDay: {
                indexVal: [ 0, 0 ],
                hours: [],
                minutes: [],
                minuteSet: []
            },
            allDay: {
                indexVal: [ 0, 0 ],
                day: []
            }
        },
        startTime: {
            year: 0,
            month: 0,
            day: 0,
            hour: 0,
            minute: 0
        },
        lastTime: {
            day: 1,
            hour: 1,
            minute: 0
        },
        startDateString: "",
        startTimeString: "",
        lastTimeString: "",
        allDayChecked: !1,
        monthChecked: !1,
        timeChecked: !1,
        lastTimeChecked: !1,
        alldayDisable: !1,
        timeDisable: !1,
        lastDisable: !1,
        alldayUnuse: !1,
        timeUnuse: !1,
        lastUnuse: !1
    },
    attached: function() {
        this.setStartTime(), this.setTimePicker(), this.setLastPicker();
    },
    methods: {
        setStartTime: function() {
            var t = new Date(), e = {
                year: t.getFullYear(),
                month: t.getMonth() + 1,
                day: t.getDate(),
                hour: t.getHours(),
                minute: t.getMinutes()
            };
            this.setData({
                startTime: e,
                startDateConfig: e
            });
        },
        setTimePicker: function() {
            for (var t = [], e = [], a = this.data.startTimeConfig, i = a.hourSize, n = a.minuteSize, s = a.minuteList, o = 0; o < i; o++) {
                var r = o % 24;
                r = r < 10 ? "0".concat(r) : "".concat(r), t.push(r);
            }
            for (var l = 0; l < n; l++) {
                var h = s[l % 4];
                e.push(h);
            }
            this.setData({
                "startTimeConfig.hours": t,
                "startTimeConfig.minutes": e
            });
            var c = new Date().getHours();
            this.setData({
                "startTimeConfig.indexVal": [ c, 200 ]
            });
        },
        setLastPicker: function() {
            this.setLastPickerHour(), this.setLastPickerMinute(), this.setLastPickerDay();
        },
        setLastPickerHour: function() {
            for (var t = [], e = 0; e <= 24; e++) t.push("".concat(e, "小时"));
            this.setData({
                "lastTimeConfig.oneDay.hours": t
            });
        },
        setLastPickerMinute: function() {
            this.setData({
                "lastTimeConfig.oneDay.minuteSet": [ 0, 15, 30, 45 ]
            });
        },
        setLastPickerDay: function() {
            for (var t = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : new Date(), e = [], a = new Date(), i = [ "周日", "周一", "周二", "周三", "周四", "周五", "周六" ], n = 1; n <= 30; n++) {
                var s = new Date(t.getTime() + 864e5 * (n - 1)), o = s.getFullYear() !== a.getFullYear() ? "".concat(s.getFullYear(), "/") : "", r = s.getMonth() + 1, l = s.getDate();
                r = r < 10 ? "0".concat(r) : r, l = l < 10 ? "0".concat(l) : l;
                var h = s.getDay(), c = a.getFullYear() === s.getFullYear() && a.getMonth() === s.getMonth() && a.getDate() === s.getDate();
                c ? e.push("".concat(n, "天 （今天）")) : e.push("".concat(n, "天 （").concat(o).concat(r, "/").concat(l, " ").concat(i[h], "）"));
            }
            this.setData({
                "lastTimeConfig.allDay.day": e
            });
        },
        timePickerchange: function(e) {
            var a = e.detail, i = (void 0 === a ? {} : a).value, n = t(void 0 === i ? [] : i, 2), s = n[0], o = n[1], r = s % 24, l = this.data.startTimeConfig.minuteList[o % 4];
            this.setData({
                "startTime.hour": r,
                "startTime.minute": l
            });
        },
        resetPickerPosition: function(t, e) {
            for (var a = this.data.startTimeConfig, i = a.hourSize, n = void 0 === i ? 240 : i, s = a.minuteSize, o = void 0 === s ? 600 : s, r = Math.floor(n / 2), l = Math.floor(o / 2); r % 24 != t % 24; ) r += 1;
            for (;l % 60 != e % 60; ) l += 1;
            this.setData({
                "startTimeConfig.indexVal": [ r, l ]
            });
        },
        oneDayPickerchange: function(t) {
            var e = t.detail, a = (void 0 === e ? {} : e).value, i = void 0 === a ? [] : a, n = i[0] || 0, s = i[1] || 0, o = this.data.lastTime, r = o.hour, l = o.minute, h = this.data.lastTimeConfig.oneDay.minuteSet;
            0 === n ? 0 !== r && (s = -1 === (s = (h = [ 15, 30, 45 ]).findIndex(function(t) {
                return t === l;
            })) ? 0 : s) : n < 24 ? 0 !== r && 24 !== r || (s = -1 === (s = (h = [ 0, 15, 30, 45 ]).findIndex(function(t) {
                return t === l;
            })) ? 0 : s) : 24 !== r && (s = -1 === (s = (h = [ 0 ]).findIndex(function(t) {
                return t === l;
            })) ? 0 : s), h !== this.data.lastTimeConfig.oneDay.minuteSet && this.setData({
                "lastTimeConfig.oneDay.minuteSet": h
            }), this.setData({
                "lastTime.hour": n,
                "lastTime.minute": h[s],
                "lastTimeConfig.oneDay.indexVal": [ n, s ]
            });
        },
        oneDayPickerEnd: function() {
            var e = t(this.data.lastTimeConfig.oneDay.indexVal, 2), a = e[0], i = e[1];
            this.setData({
                "lastTimeConfig.oneDay.indexVal": [ a, i ]
            });
        },
        allDayPickerchange: function(e) {
            var a = e.detail, i = (void 0 === a ? {} : a).value, n = t(void 0 === i ? [] : i, 1)[0], s = void 0 === n ? 0 : n;
            this.setData({
                "lastTime.day": s + 1
            });
        },
        calendarDateChange: function(t) {
            var e = t.detail, a = (void 0 === e ? {} : e).selectDate, i = void 0 === a ? {} : a, n = i.day, s = i.month, o = i.year;
            this.setData({
                "startTime.year": o,
                "startTime.month": s,
                "startTime.day": n
            });
        },
        daySwitchChange: function() {
            var t = !this.data.allDayChecked;
            this.setData({
                allDayChecked: t
            }), !0 === t && this.data.timeChecked && this.setData({
                timeChecked: !1,
                monthChecked: !0
            });
        },
        handleMonthClick: function(t) {
            this.setData({
                timeChecked: !1,
                lastTimeChecked: !1,
                monthChecked: !this.data.monthChecked
            }), this.triggerEvent("monthclick", t);
        },
        handleTimeClick: function() {
            this.setData({
                monthChecked: !1,
                lastTimeChecked: !1,
                timeChecked: !this.data.timeChecked
            });
        },
        handleDurationClick: function() {
            this.data.lastDisable || this.setData({
                monthChecked: !1,
                timeChecked: !1,
                lastTimeChecked: !this.data.lastTimeChecked
            });
        },
        handlecancel: function(t) {
            this.triggerEvent("cancel", t);
        },
        handleConfirm: function() {
            var t = this.data.startTime, e = t.year, a = t.month, i = t.day, n = t.hour, s = t.minute, o = {
                allday: this.data.allDayChecked,
                startTimeData: this.data.startTime,
                starttime: new Date(e, a - 1, i, n, s).getTime(),
                lastTimeData: this.data.lastTime
            };
            this.triggerEvent("confirm", o);
        },
        getLastData: function(t) {
            var e = t, a = Math.floor(e / 864e5);
            e -= 864e5 * a;
            var i = Math.floor(e / 36e5);
            return e -= 36e5 * i, {
                day: a,
                hour: i,
                minute: Math.floor(e / 6e4)
            };
        },
        getStartTime: function(t) {
            var e = t ? new Date(t) : new Date(), a = e.getMinutes(), i = this.data.startTimeConfig.minuteList, n = e.getHours(), s = i.find(function(t) {
                return t >= a;
            });
            return n = void 0 === s ? n + 1 : n, n %= 24, {
                year: e.getFullYear(),
                month: e.getMonth() + 1,
                day: e.getDate(),
                hour: n || 0,
                minute: s || 0
            };
        }
    },
    observers: {
        "startTime.year, startTime.month, startTime.day": function() {
            var t, e = this.data.startTime, a = e.month, i = e.day, n = this.data.startTime.year, s = new Date().getFullYear();
            a = a < 10 ? "0".concat(a) : "".concat(a), i = i < 10 ? "0".concat(i) : "".concat(i), 
            t = s === n ? "".concat(a, "月").concat(i, "日") : "".concat(n, "/").concat(a, "/").concat(i), 
            this.setData({
                startDateString: t
            }), this.setLastPickerDay(new Date(n, a - 1, i));
        },
        "startTime.hour, startTime.minute": function() {
            var t = this.data.startTime, e = t.hour, a = t.minute;
            e = e < 10 ? "0".concat(e) : "".concat(e), a = a < 10 ? "0".concat(a) : "".concat(a), 
            this.setData({
                startTimeString: "".concat(e, ":").concat(a)
            });
        },
        "allDayChecked, lastTime.day, lastTime.hour, lastTime.minute": function() {
            var t = this.data.allDayChecked, e = this.data.lastTime, a = e.day, i = e.hour, n = e.minute;
            if (t) this.setData({
                lastTimeString: "".concat(a, "天")
            }); else if (i < 24) {
                var s = 0 === i ? "" : "".concat(i, "小时"), o = 0 === n ? "" : "".concat(n, "分钟");
                this.setData({
                    lastTimeString: "".concat(s).concat(o)
                });
            } else this.setData({
                lastTimeString: "1天"
            });
        },
        "lastTimeConfig.oneDay.minuteSet": function() {
            var t = this.data.lastTimeConfig.oneDay.minuteSet.map(function(t) {
                return "".concat(t, "分钟");
            });
            this.setData({
                "lastTimeConfig.oneDay.minutes": t
            });
        },
        show: function(t) {
            var e = this.properties, a = e.allday, i = e.starttime, n = e.lasttime, s = void 0 === n ? 9e5 : n, o = e.unfold, r = void 0 === o ? "" : o, l = e.unuse, h = void 0 === l ? "" : l, c = e.disable, m = this.getStartTime(i), u = this.getLastData(s);
            if (!0 === t) {
                var d, D = u.hour;
                d = 0 === D ? [ 15, 30, 45 ] : 24 === D ? [ 0 ] : [ 0, 15, 30, 45 ], this.setData({
                    allDayChecked: a,
                    "lastTimeConfig.oneDay.minuteSet": d,
                    startTime: Object.assign(this.data.startTime, m),
                    lastTime: Object.assign(this.data.lastTime, u),
                    startDateConfig: Object.assign(this.data.startDateConfig, m),
                    monthChecked: "month" === r,
                    timeChecked: "time" === r && !a,
                    lastTimeChecked: "last" === r,
                    lastUnuse: h.includes("last"),
                    timeUnuse: h.includes("time"),
                    alldayUnuse: h.includes("allday"),
                    lastDisable: c.includes("last"),
                    timeDisable: c.includes("time"),
                    alldayDisable: c.includes("allday")
                });
            } else this.setData({
                monthChecked: !1,
                timeChecked: !1,
                lastTimeChecked: !1
            });
        },
        timeChecked: function(t) {
            if (!1 === t) return !1;
            var e = this.data.startTime, a = e.hour, i = e.minute, n = this.data.startTimeConfig.minuteList.findIndex(function(t) {
                return t === i;
            });
            this.setData({
                "startTimeConfig.indexVal": [ a + 120, n + 200 ]
            });
        },
        "lastTimeChecked, allDayChecked": function(t) {
            var e = this;
            if (!1 === t) return !1;
            var a = this.data.allDayChecked, i = this.data.lastTime, n = i.day, s = i.hour, o = i.minute;
            if (a) this.setData({
                "lastTimeConfig.allDay.indexVal": [ n - 1 ]
            }); else {
                var r, l = this.data.lastTimeConfig.oneDay.minuteSet;
                r = -1 === (r = l.findIndex(function(t) {
                    return t === o;
                })) ? 0 : r, this.setData({
                    "lastTimeConfig.oneDay.minuteSet": l,
                    "lastTimeConfig.oneDay.indexVal": [ s, r ]
                }), Promise.resolve().then(function() {
                    e.setData({
                        "lastTimeConfig.oneDay.indexVal": [ s, r ]
                    });
                });
            }
        }
    }
});