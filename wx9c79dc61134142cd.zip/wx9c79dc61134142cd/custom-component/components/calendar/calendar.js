var t = require("../../../@babel/runtime/helpers/slicedToArray"), e = require("../utils/util"), a = 0, i = 0;

Component({
    properties: {
        spot: Object,
        date: Object,
        todayChange: Object,
        beginDay: {
            type: String,
            value: ""
        },
        swiperHigh: {
            type: Number,
            value: 0
        },
        foldDisable: {
            type: Boolean,
            value: !1
        },
        showTitle: {
            type: Boolean,
            value: !1
        },
        openStatus: Boolean
    },
    data: {
        open: !1,
        dateListArray: [],
        selectDate: {},
        swiperPosition: 1,
        swiperDuration: 0,
        offsetDay: 0,
        headerDayList: [ "日", "一", "二", "三", "四", "五", "六" ],
        showLunarCalendar: !1,
        showHoliday: !0,
        onlyKalendsFifteen: !1,
        swiperHeight: 308,
        calendarTitleText: ""
    },
    methods: {
        formatTime: function(t) {
            var e = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : "Y-M-D";
            function a(t) {
                var e = t.toString();
                return e[1] ? e : "0".concat(e);
            }
            function i(t, e) {
                var i = [ "Y", "M", "D", "h", "m", "s" ], n = [], s = new Date(t), o = e;
                n.push(s.getFullYear()), n.push(a(s.getMonth() + 1)), n.push(a(s.getDate())), n.push(a(s.getHours())), 
                n.push(a(s.getMinutes())), n.push(a(s.getSeconds()));
                for (var r = 0; r < n.length; r++) {
                    var h = n[r], d = i[r];
                    o = o.replace(d, h);
                }
                return o;
            }
            return i(t, e);
        },
        onSwiperAnimationFinish: function(t) {
            var e = t.detail, a = e.current, i = e.source;
            i && "touch" !== i || 1 !== a && (this.setData({
                swiperDuration: 0
            }), this.triggerSwiperChange(this.data.open, a < this.data.swiperPosition), this.data.open ? this.invokeChangeMonth(a) : this.invokeChangeWeek(a));
        },
        onOpenChange: function() {
            e.setValueInLocalStorage("open_status", !this.data.open), this.setData({
                open: !this.data.open
            });
        },
        onSelectChange: function(t) {
            var e = {
                year: t.currentTarget.dataset.year,
                month: t.currentTarget.dataset.month,
                day: t.currentTarget.dataset.day,
                dateString: t.currentTarget.dataset.dateStringing
            }, a = !this.data.open;
            this.invokeSelectDate(e, a, !0);
        },
        invokeChangeMonth: function(t) {
            for (var e = new Date(), a = e.getMonth() + 1, i = e.getDate(), n = !1, s = {}, o = this.data.dateListArray[t], r = 0; r < o.length; r++) {
                var h = o[r];
                if (h.isCurrentMonth) {
                    if (h.month === a && (n = !0), !n) {
                        s = h;
                        break;
                    }
                    if (i === h.day) {
                        s = h;
                        break;
                    }
                }
            }
            this.invokeSelectDate(s, !1, !1);
        },
        invokeChangeWeek: function(e) {
            for (var a = new Date(), i = !1, n = {}, s = this.data.dateListArray[e], o = 0; o < s.length; o++) {
                var r = s[o];
                if (a.getFullYear() === r.year && a.getMonth() === r.month - 1 && a.getDate() === r.day) {
                    n = r, i = !0;
                    break;
                }
            }
            i || (n = t(s, 1)[0]);
            this.invokeSelectDate(n, !0, !1);
        },
        invokeSelectDate: function(t, e, a) {
            var i = !1;
            if (e) for (var n = this.data.dateListArray[this.data.swiperPosition], s = 0; s < n.length; s++) {
                var o = n[s];
                if (t.year === o.year && t.month === o.month && t.day === o.day) {
                    i = !0;
                    break;
                }
            } else i = this.data.selectDate.year === t.year && this.data.selectDate.month === t.month;
            this.setData({
                selectDate: t
            }), this.triggerDateChange(t, a), i || this.dateInit(t.year, t.month, t.day);
        },
        triggerDateChange: function(t, e) {
            var a = this.formatTime(new Date(t.year, t.month - 1, t.day)), i = null !== this.data.spot ? this.data.spot[a] : void 0, n = {
                selectDate: t,
                isClick: e,
                isEventDot: !!i && i.eventDot
            }, s = this.getMonthTitle(n);
            n.titleText = s, this.setData({
                calendarTitleText: s
            }), this.triggerEvent("datechange", n);
        },
        triggerModeChange: function(t) {
            this.triggerEvent("modechange", t);
        },
        triggerSwiperChange: function(t, e) {
            this.triggerEvent("swiperchange", {
                isMonth: t,
                toLeft: e
            });
        },
        dateInit: function(t, e, a) {
            for (var i = [], n = this.data.headerDayList.indexOf("一"), s = 0; s < 3; s++) this.data.open ? i[s] = this.initMonthList(t, e + (s - 1), n) : i[s] = this.initWeekList(t, e, a, s - 1, n);
            this.setData({
                dateListArray: i,
                swiperPosition: 1,
                swiperDuration: 150
            });
        },
        initMonthList: function(t, e, a) {
            var i = [], n = new Date(t, e - 1), s = new Date(), o = new Date(s.getFullYear(), s.getMonth(), s.getDate()), r = n.getDay(), h = 2;
            0 === r && 1 === this.data.offsetDay ? h -= 7 : 6 === r && 6 === this.data.offsetDay && (h += 7);
            for (var d = 0; d < 42; d++) {
                var g = new Date(n);
                g.setDate(d - r - a + h);
                var u = {};
                (u = {
                    day: g.getDate(),
                    month: g.getMonth() + 1,
                    year: g.getFullYear(),
                    dateString: this.formatTime(g)
                }).isCurrentMonth = e > 12 ? u.month === e - 12 : e < 1 ? u.month === e + 12 : u.month === e;
                var l = new Date(u.year, u.month - 1, u.day);
                u.isPassDay = o.getTime() > l.getTime(), u.isToday = o.getTime() === l.getTime(), 
                null !== this.data.spot && (u.spot = this.data.spot[u.dateString]), i[d] = u;
            }
            return i;
        },
        initWeekList: function(t, e, a, i, n) {
            var s = [], o = new Date(t, e - 1, a), r = new Date(), h = new Date(r.getFullYear(), r.getMonth(), r.getDate()), d = o.getDay(), g = 1 - n;
            6 === d && 6 === this.data.offsetDay && (g += 7);
            for (var u = 0; u < 7; u++) {
                var l = new Date(o);
                l.setDate(o.getDate() + 7 * i - d + u + g);
                var c = {};
                (c = {
                    day: l.getDate(),
                    month: l.getMonth() + 1,
                    year: l.getFullYear(),
                    dateString: this.formatTime(l)
                }).isCurrentMonth = !0;
                var D = new Date(c.year, c.month - 1, c.day);
                c.isPassDay = h.getTime() > D.getTime(), c.isToday = h.getTime() === D.getTime(), 
                null !== this.data.spot && (c.spot = this.data.spot[c.dateString]), s[u] = c;
            }
            return s;
        },
        updateSpot: function() {
            var t = this;
            null !== this.data.spot && (this.data.dateListArray.forEach(function(e) {
                e.forEach(function(e) {
                    var a = t.data.spot[e.dateString];
                    e.spot = a;
                });
            }), this.setData({
                dateListArray: this.data.dateListArray
            }));
        },
        updateDate: function() {
            if (null !== this.data.date) {
                var t = new Date(this.data.date.year, this.data.date.month - 1, this.data.date.day), e = {
                    year: t.getFullYear(),
                    month: t.getMonth() + 1,
                    day: t.getDate(),
                    dateString: this.formatTime(t)
                };
                this.setData({
                    selectDate: e
                }), this.dateInit(e.year, e.month, e.day), this.triggerDateChange(e, !1);
            }
        },
        onTouchStart: function(t) {
            a = t.touches[0].pageX, i = t.touches[0].pageY;
        },
        onTouchMove: function(t) {
            if (!this.data.foldDisable) {
                var e = t.changedTouches[0].pageX, n = t.changedTouches[0].pageY, s = e - a, o = n - i;
                Math.abs(s) < Math.abs(o) && (o < 0 ? this.data.open && this.onOpenChange() : this.data.open || this.onOpenChange());
            }
        },
        onTouchEnd: function() {
            a = 0, i = 0;
        },
        onTouchCancel: function() {
            a = 0, i = 0;
        },
        updateBeginDay: function() {
            var t = 0;
            switch (this.data.beginDay) {
              case "Monday":
                t = 1;
                break;

              case "Saturday":
                t = 6;
                break;

              default:
                t = 0;
            }
            if (this.offsetDay !== t) {
                this.setData({
                    offsetDay: t
                });
                var e = "日一二三四五六".substring(t) + "日一二三四五六".substring(0, t);
                if (this.data.headerDayList.toString().replace(/,/g, "") !== e) {
                    var a = e.split("");
                    this.setData({
                        headerDayList: a
                    });
                    var i = this.data.selectDate.year, n = this.data.selectDate.month, s = this.data.selectDate.day;
                    this.dateInit(i, n, s);
                }
            }
        },
        displayItemConfiguration: function() {
            var t = e.getValueFromLocalStorage("show_lunar_calendar");
            "" !== t && void 0 !== t && this.setData({
                showLunarCalendar: t
            });
            var a = e.getValueFromLocalStorage("show_holiday");
            "" !== a && void 0 !== a && this.setData({
                showHoliday: a
            });
            var i = e.getValueFromLocalStorage("only_kalends_fifteen");
            "" !== i && void 0 !== i && this.setData({
                onlyKalendsFifteen: i
            });
        },
        getSwiperHeight: function() {
            if (this.data.swiperHigh) return this.data.swiperHigh;
            return 86 * (this.data.open ? 6 : 1);
        },
        getMonthTitle: function(t) {
            var e = t.selectDate, a = new Date().getFullYear() === e.year, i = "".concat(e.year, "年").concat(e.month, "月"), n = "".concat(e.month, "月");
            return a ? n : i;
        },
        toPreItem: function() {
            var t = this.data.swiperPosition - 1;
            t < 0 || this.setData({
                swiperPosition: t
            });
        },
        toNextItem: function() {
            var t = this.data.swiperPosition + 1;
            t > 2 || this.setData({
                swiperPosition: t
            });
        }
    },
    attached: function() {
        this.setData({
            open: this.data.foldDisable
        });
    },
    observers: {
        spot: function() {
            this.updateSpot();
        },
        date: function() {
            this.updateDate();
        },
        beginDay: function() {
            this.updateBeginDay();
        },
        todayChange: function(t) {
            t && this.dateInit(t.year, t.month + 1, t.day);
        },
        "swiperHigh, open, showHoliday, showLunarCalendar": function() {
            this.setData({
                swiperHeight: this.getSwiperHeight()
            });
        },
        open: function() {
            var t = this.data.selectDate.year, e = this.data.selectDate.month, a = this.data.selectDate.day;
            this.dateInit(t, e, a), this.triggerModeChange(this.data.open);
        },
        openStatus: function(t) {
            this.setData({
                open: t
            });
        }
    }
});