module.exports = {
    hex: function(t) {
        var r = null;
        return !/^#/.test(t) || 7 !== t.length && 9 !== t.length ? null !== (r = /^(rgb|rgba)\((.+)\)/.exec(t)) ? "#" + r[2].split(",").map(function(t, r) {
            return t = t.trim(), 1 === (t = (t = 3 === r ? Math.floor(255 * parseFloat(t)) : parseInt(t, 10)).toString(16)).length && (t = "0" + t), 
            t;
        }).join("") : "#00000000" : t;
    },
    splitLineToCamelCase: function(t) {
        return t.split("-").map(function(t, r) {
            return 0 === r ? t : t[0].toUpperCase() + t.slice(1);
        }).join("");
    },
    compareVersion: function(t, r) {
        t = t.split("."), r = r.split(".");
        for (var n = Math.max(t.length, r.length); t.length < n; ) t.push("0");
        for (;r.length < n; ) r.push("0");
        for (var e = 0; e < n; e++) {
            var l = parseInt(t[e], 10), i = parseInt(r[e], 10);
            if (l > i) return 1;
            if (l < i) return -1;
        }
        return 0;
    }
};