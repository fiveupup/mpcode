module.exports = {
    getValueFromLocalStorage: function(t) {
        var c = null;
        try {
            c = wx.getStorageSync("".concat(DEFAULT_ENV_KEY, "_").concat(t));
        } catch (t) {
            c = null;
        }
        return c;
    },
    setValueInLocalStorage: function(t, c) {
        wx.setStorage({
            key: "".concat(DEFAULT_ENV_KEY, "_").concat(t),
            data: c,
            success: function() {},
            fail: function() {}
        });
    }
};