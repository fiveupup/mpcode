var o, n = require("../../../sdk/logger/calendar_logger"), e = require("../../../stores/invite/InviteEntryController").InviteEntryController, t = require("../../../configs/AppConfig"), r = function(o) {
    var e = t.DEFAULT_ENV_KEY;
    try {
        decodeURIComponent(o).indexOf(t.ENV_LIST.production.inviteHost) > -1 && (e = "production");
    } catch (e) {
        n.error("web url decode error ".concat(o, " ").concat(JSON.stringify(e)), "web.js");
    }
    return {
        urlEnv: e,
        wxEnv: t.DEFAULT_ENV_KEY
    };
};

Page({
    data: {
        url: "",
        title: "",
        frontColor: "#000000",
        backgroundColor: "#ffffff"
    },
    onLoad: function(e) {
        n.info("load web options: ".concat(JSON.stringify(e)), "web.js");
        var c = e.title, i = void 0 === c ? "" : c, a = e.url, d = void 0 === a ? "" : a, s = e.fontcolor, u = void 0 === s ? "" : s, f = e.background, l = void 0 === f ? "" : f;
        if (n.info("onLoad url: ".concat(decodeURIComponent(d), ", fontcolor: ").concat(decodeURIComponent(u), ", background: ").concat(decodeURIComponent(l)), "web.js"), 
        this.setData({
            title: i,
            url: decodeURIComponent(d),
            frontColor: decodeURIComponent(u) || this.fontColor,
            backgroundColor: decodeURIComponent(l) || this.backgroundColor
        }), o = Date.now(), "release" !== t.wxVersion) {
            var w = r(d);
            (function(o) {
                var n = r(o);
                return n.urlEnv === n.wxEnv;
            })(d) || wx.showModal({
                title: "检测到环境不匹配",
                content: "网页版是".concat("production" === w.urlEnv ? "正式环境" : "测试环境", ",小程序是").concat("production" === w.wxEnv ? "正式环境" : "测试环境"),
                success: function(o) {
                    o.confirm && wx.showToast({
                        title: "可以在设置页更改环境",
                        icon: "success"
                    });
                }
            });
        }
    },
    onReady: function() {},
    onShow: function() {},
    onHide: function() {},
    onUnload: function() {},
    onPullDownRefresh: function() {},
    onReachBottom: function() {},
    webLoadSuccess: function(e) {
        var t = Date.now() - o;
        n.info("webLoadSucc: url=".concat(e.detail.src, ", time=").concat(t, "}"), "web.js"), 
        n.aegisSdk.aegis.reportTime({
            name: "webLoadTime",
            duration: t,
            ext3: e.detail.src
        });
    },
    webLoadError: function(e) {
        var t = JSON.stringify(e);
        n.error("webLoadErr: ".concat(t, ", time=").concat(Date.now() - o, "}"), "web.js"), 
        n.aegisSdk.aegis.reportEvent({
            name: "webLoadErr",
            ext3: t
        });
    },
    onWebPostMessage: function(o) {
        n.info("onWebPostMessage: ".concat(JSON.stringify(o)), "web.js"), e.onRecieveWebPostMessage(o.detail.data);
    }
});