var e = require("../../@babel/runtime/helpers/createForOfIteratorHelper"), t = require("../../@babel/runtime/helpers/slicedToArray"), n = require("../../@babel/runtime/helpers/objectSpread2"), a = require("../../@babel/runtime/helpers/typeof"), i = require("../../@babel/runtime/helpers/regeneratorRuntime"), o = require("../../@babel/runtime/helpers/asyncToGenerator"), r = require("../../stores/calendarinfo/CalendarInfoController"), s = require("../../stores/calendardrawer/CalendarDrawerController"), c = require("../../auth/AuthController"), d = require("../../utils/beacon/report_data"), l = require("@tencent/calendar-js-sdk").CalendarSDK, u = require("../../stores/UserStore.js"), h = require("../../utils/detail-share-picture.js"), g = require("../../utils/util"), m = g.rpx2Px, p = g.getTimeInfo, f = g.initRecurMenuItems, v = g.initMeetingRecurMenuItems, I = g.initMeetingRecurMenuDeleteItems, w = g.formatDescription, D = g.parseColors, S = g.formatRgba, C = require("../../utils/remindTimeUtil").formatRemindOption, T = require("@tencent/wecalendar-web-business-plugins"), _ = T.util, y = T.Permission, R = require("debounce"), x = _.formatMeetingCode, b = getApp(), P = {}, E = !1, M = "https://cdn.calendar.tencent.com/calendar_res/mpCalendar/canvas/detail-share-default-new.jpg", k = function() {};

Page({
    data: {
        title: "",
        timeInfo: "",
        repeatStr: "",
        meetingCode: "",
        meetingPass: "",
        address: "",
        meetingRoom: "",
        isMeeting: !1,
        desc: "",
        descArr: [],
        isDescOverFlow: !1,
        isDescExend: !1,
        showMenuAs: !1,
        showMore: !1,
        participantAvatarList: [],
        totalCount: 0,
        isCreator: !1,
        acceptStr: "",
        rejectStr: "",
        pendingStr: "",
        eventStatus: -1,
        needPassword: !1,
        currentClickEventStatus: 0,
        shareTimeInfo: "",
        isMeetingPeriod: !1,
        showAcceptRejectButton: !1,
        creatorAvatarUrl: "",
        showRecurDeleteMenu: !1,
        deleteMessage: "您确定删除此日程吗",
        showBottomContainer: !1,
        itemList: [],
        showReselectAs: !1,
        tabBarFixed: !1,
        mbbox: {
            top: 24,
            height: 32
        },
        navHeight: 0,
        shareImgInit: !1,
        showRemindDialog: !1,
        remindStr: "",
        remindTimeSelectItems: [],
        showRecurEditMenu: !1,
        calendarSelectPageShow: !1,
        recurType: "delete",
        calendarList: [],
        isShare: !1,
        belongCalendarName: "",
        showParticipant: !1,
        recurMenuItems: [],
        beforeEndRemindItems: [],
        attachImages: []
    },
    showDialog: function() {
        this.dialog.showDialog();
    },
    hideDialog: function() {
        this.dialog.hideDialog();
    },
    onLoad: function(e) {
        var t = this;
        if (this.initHeight(), this.calendarDrawerController = new s(), console.log("options:", e), 
        wx.showLoading(), e.eventId) {
            var n = e.eventId, a = e.calendarId, i = e.parentId, o = e.startTime, r = e.source;
            if (Object.assign(this, {
                eventId: n,
                calendarId: a,
                fromSource: r || "",
                recurParentId: i,
                startTime: o
            }), !u.isLoginSuccess()) {
                var c = "/pages/detail/detail?eventId=".concat(n, "&calendarId=").concat(a);
                return i && (c += "&startTime=".concat(o, "&parentId=").concat(i, "&source=").concat(r)), 
                void wx.reLaunch({
                    url: "".concat("/pages/index/index?redirectType=1&redirectUrl=").concat(encodeURIComponent("".concat(c)), "&comeFrom=3")
                });
            }
            this.getEventInfo(n, a, i, o);
        } else {
            var l = this.getOpenerEventChannel();
            l && l.on && l.on("eventDetail", function(e) {
                console.log("eventInfo", e);
                var n = e.data;
                t.eventInfo = n, Object.assign(t, {
                    eventId: n.eventId,
                    calendarId: n.calendarId,
                    fromSource: "mainpage"
                }), t.getEventInfo(n.eventId, n.calendarId, n.parentEventId, n.startTime);
            });
        }
        this.dialog = this.selectComponent("#confirm-dialog"), this.editPassword = this.selectComponent("#edit-password"), 
        this.guideShare = this.selectComponent("#guide-share"), "invite" === this.fromSource && setTimeout(function() {
            t.guideShare.showDialog(), d.dataReport("schedule_detail_null_guidenotification_null_null_explore");
        }, 1e3);
    },
    onShow: function(e) {
        console.log("option", e);
    },
    initHeight: function() {
        var e = b.globalData.sysInfo || wx.getSystemInfoSync(), t = {}, n = 0;
        if ("function" == typeof wx.getMenuButtonBoundingClientRect) n = (t = wx.getMenuButtonBoundingClientRect()).top + t.height + m(27, e.screenWidth); else {
            var a = (e.statusBarHeight || 20) + 4;
            t = {
                top: a,
                height: 32
            }, n = a + 32 + m(27, e.screenWidth);
        }
        this.setData({
            mbbox: t,
            navHeight: n
        });
    },
    getParentEventId: function() {
        var e = this.eventInfo, t = e.eventId, n = e.parentEventId;
        return n && "0" !== n ? n : t;
    },
    getEventInfo: function(e, t) {
        var n = arguments, a = this;
        return o(i().mark(function o() {
            var r, s, c;
            return i().wrap(function(i) {
                for (;;) switch (i.prev = i.next) {
                  case 0:
                    if (r = n.length > 2 && void 0 !== n[2] ? n[2] : 0, s = n.length > 3 ? n[3] : void 0, 
                    console.log("getEventInfo----", e, t, r, s), a.corpId && a.calendarUid) {
                        i.next = 8;
                        break;
                    }
                    return i.next = 6, a.getCalendarInfo(t);

                  case 6:
                    (c = i.sent) && Object.assign(a, {
                        corpId: c.corpId,
                        calendarUid: c.calendarUid
                    });

                  case 8:
                    l.getInstance().getEventDetail(t, a.corpId, a.calendarUid, "".concat(e), r, s).then(function(e) {
                        wx.hideLoading(), console.log("getEventDetail: event:", e), a.parseEventInfo(e);
                    }).catch(function(e) {
                        console.log("err", e), wx.hideLoading(), wx.showToast({
                            title: e.message || "无权限",
                            icon: "none"
                        }), setTimeout(function() {
                            a.navigateBack();
                        }, 3e3);
                    });

                  case 9:
                  case "end":
                    return i.stop();
                }
            }, o);
        }))();
    },
    getCalendarInfo: function(e) {
        return r.getInstance().getCalendarInfoList().then(function(t) {
            for (var n = 0; n < t.length; n++) {
                var a = t[n];
                if (e === a.calendarId) return Promise.resolve(a);
            }
            return Promise.resolve(void 0);
        }).catch(function(e) {
            return console.log("err", e), Promise.resolve(void 0);
        });
    },
    handleEventStatus: function(e, t) {
        var n = "", a = "", i = "", o = !1;
        switch (e) {
          case 1:
            n = "已接受", i = "待定", a = "拒绝";
            break;

          case 2:
            n = "接受", i = "待定", a = "已拒绝";
            break;

          case 4:
            n = "接受", a = "拒绝", i = "已待定";
            break;

          default:
            o = !0, n = "接受", i = "待定", a = "拒绝";
        }
        if (this.setData({
            acceptStr: n,
            rejectStr: a,
            pendingStr: i,
            eventStatus: e
        }), t) {
            var r = getCurrentPages(), s = r[r.length - 2];
            void 0 !== s && s.setData({
                editSuccess: !0,
                startTime: this.eventInfo.startTime,
                eventId: "".concat(this.getParentEventId())
            }), this.setData({
                showAcceptRejectButton: !1
            });
        } else !0 === o && this.setData({
            showAcceptRejectButton: !0
        });
    },
    getMeetingCode: function(e) {
        var t = "", n = "", a = !1, i = !1;
        return e.meetingInfo && (i = e.meetingInfo.isPeriod, a = 2 === e.meetingInfo.isNeedPassword, 
        t = x(e.meetingInfo.meetingCode), n = e.meetingInfo.meetingPass), {
            meetingCode: t,
            meetingPass: n,
            needPassword: a,
            isMeetingPeriod: i
        };
    },
    getSource: function() {
        return "publicaccount" === this.fromSource || "miniprogram" === this.fromSource ? 1 : "mainpage" === this.fromSource ? 0 : 2;
    },
    getCalendarType: function() {
        var e = "0";
        return E ? e = "2" : "1400143280" === this.corpId && (e = "4"), e;
    },
    parseEventInfo: function(e) {
        var t = this;
        return o(i().mark(function n() {
            var a, o, s, c, l, u, h, g, m, f, v, I, D, S, C, T, _, R, x, b, P, M, k, A, L, j, B;
            return i().wrap(function(n) {
                for (;;) switch (n.prev = n.next) {
                  case 0:
                    if (e && e.eventId) {
                        n.next = 2;
                        break;
                    }
                    return n.abrupt("return");

                  case 2:
                    return n.next = 4, r.getInstance().getCalendarInfoById(e.calendarId);

                  case 4:
                    a = n.sent, o = p(e.startTime, e.endTime, e.isAllDay, !1), s = p(e.startTime, e.endTime, e.isAllDay, !0, !0), 
                    c = t.getMeetingCode(e), l = c.meetingCode, u = c.meetingPass, h = c.needPassword, 
                    g = c.isMeetingPeriod, 3 === e.eventType && (E = !0), m = e.busType, f = e.location && e.location.meetingRoom || "", 
                    v = e.location && e.location.address || "", D = /(http(s)?:\/\/)meeting.tencent.com/, 
                    S = /(http(s)?:\/\/)work.weixin.qq.com/, C = /(http(s)?:\/\/)\w+[^\s]+(\.[^\s]+)(tencentmeeting.com)/.test(I = v || f) || D.test(I) || S.test(I), 
                    T = 1 === e.role, _ = 3 === e.role, R = new y(e.accessRole), x = 4 === a.calType, 
                    t.canEdit = (T || x && R.edit) && !("" === e.rruleDesc && g), t.canRemove = !x || x && R.edit, 
                    t.canShare = (!x || x && R.share) && 1 !== m, t.canShare || wx.hideShareMenu(), 
                    b = !E && (t.canEdit || t.canRemove || t.canShare), P = e.participantSimInfo && e.participantSimInfo.avartList.length || 0, 
                    M = P > 0, k = 4 === a.calType ? a.summary : "", A = "确认删除日程？", 1 === m && (A = "删除后将通知".concat(T ? "参与者" : "创建者", "，无法恢复，请谨慎操作。")), 
                    L = !(4 === a.calType || -1 === e.responseStatus || E || 1 === m || _ && 0 === e.responseStatus), 
                    j = e.desc || "", B = w(j), t.handleEventStatus(e.responseStatus), t.eventInfo = e, 
                    t.setData({
                        title: e.summary || "",
                        attachImages: e.attachImages || [],
                        timeInfo: o,
                        meetingCode: l,
                        meetingPass: u,
                        desc: j,
                        descArr: B || [],
                        meetingRoom: f,
                        isMeeting: C,
                        address: v,
                        showMore: b,
                        participantAvatarList: e.participantSimInfo && e.participantSimInfo.avartList || [],
                        totalCount: e.participantSimInfo && e.participantSimInfo.totalCount || 0,
                        isCreator: T,
                        needPassword: h,
                        shareTimeInfo: s,
                        isMeetingPeriod: g,
                        repeatStr: e.rruleDesc,
                        endInfo: e.endInfo,
                        confirmMessage: A,
                        showBottomContainer: L,
                        belongCalendarName: k,
                        showParticipant: M,
                        isShare: x
                    }), -1 === e.responseStatus || E || g || !T || d.dataReport("homepage_detail_null_sharebutton_null_null_explore", {}), 
                    d.dataReport("e#schedule_detail#all#explore", {
                        calendar_type: t.getCalendarType(),
                        creatoridentity: T ? "0" : "1",
                        source: t.getSource()
                    }), t.canShare && t.createSharePicture(), t.wrapAction(), t.handleRemindData(e), 
                    t.initCalendarList(e.calendarId);

                  case 43:
                  case "end":
                    return n.stop();
                }
            }, n);
        }))();
    },
    handleRemindData: function(e) {
        var t = C({
            isAllDay: e.isAllDay,
            remindTimes: e.remindTimes,
            remindWays: e.remindWays
        }).remindStr;
        this.setData({
            remindStr: t || "不提醒"
        });
    },
    createSharePicture: function() {
        var e = this, t = this.data, n = t.title, a = t.meetingCode, i = t.address, o = t.shareTimeInfo;
        return h({
            title: n,
            hasMeeting: "" !== a,
            address: i,
            timeInfo: o
        }).then(function(t) {
            return M = t.tempFilePath.tempFilePath, e.setData({
                shareImgUrl: M,
                shareImgInit: !0
            }), M;
        });
    },
    clickParticipantDetail: function() {
        if (d.dataReport("e#schedule_detail#member#click", {}), this.data.isCreator) {
            var e = this.data, t = e.calendarId, n = e.calendarUid, a = e.corpId, i = "/partnerList?event_id=".concat(this.getParentEventId()) + "&calendar_id=".concat(t, "&cal_uid=").concat(n, "&corp_id=").concat(a);
            wx.navigateTo({
                url: "/PartnerList/pages/PartnerList/index?type=jump&targeturl=".concat(encodeURIComponent(i))
            });
        } else wx.showToast({
            icon: "none",
            title: "暂无权限查看成员信息"
        });
    },
    copyMeetingCode: function() {
        var e = this.eventInfo, t = {
            startTime: e.startTime,
            endTime: e.endTime,
            summary: e.summary,
            meetingCode: e.meetingInfo.meetingCode
        };
        this.setData({
            joinDialogData: t
        }), d.dataReport("e#schedule_detail#copy_meeting_code#click", {});
    },
    goEdit: function() {
        if (this.canEdit) {
            d.dataReport("e#schedule_detail#more_edit#click", {});
            var e = this.eventInfo, t = this.eventInfo.startTime < new Date().getTime();
            if (0 !== e.eventType && t) return this.setData({
                showMenuAs: !1
            }), void wx.showToast({
                title: "不支持修改过去时间的腾讯会议日程",
                icon: "none"
            });
            if (this.data.isMeetingPeriod && "" === this.data.repeatStr) return this.setData({
                showMenuAs: !1
            }), void wx.showToast({
                title: "该周期性腾讯会议日程不支持修改",
                icon: "none"
            });
            if (1 === e.busType) return this.setData({
                showMenuAs: !1
            }), void wx.showToast({
                title: "预约类日程不支持编辑",
                icon: "none"
            });
            wx.navigateTo({
                url: "/create/create",
                success: function(t) {
                    t.eventChannel.emit("eventDetail", {
                        data: e
                    });
                }
            }), this.setData({
                showMenuAs: !1
            });
        }
    },
    goWebView: function(e) {
        var t = this, n = e.currentTarget.dataset.url;
        n ? d.dataReport("e#schedule_detail#link#click") : d.dataReport("e#schedule_detail#head_link#click");
        var a = n || this.data.address || this.data.meetingRoom;
        a.startsWith("https://") && c.getMeetingCode(a).then(function(e) {
            if (console.log("get meeting code", e), e && e.data && 0 === e.data.code) {
                var n = e.data.data.meeting_code, a = t.eventInfo, i = {
                    startTime: a.startTime,
                    endTime: a.endTime,
                    summary: a.summary,
                    meetingCode: n
                };
                t.setData({
                    joinDialogData: i
                });
            } else wx.showToast({
                title: e.message,
                icon: "none"
            });
        });
    },
    deleteConfirm: function() {
        if ("0" !== this.eventInfo.parentEventId) return this.setData({
            showRecurEditMenu: !0,
            showMenuAs: !1
        }), void (this.data.isMeetingPeriod ? this.setData({
            recurMenuItems: I
        }) : this.setData({
            recurMenuItems: f
        }));
        this.setData({
            showMenuAs: !1
        }), this.showDialog();
    },
    cancleDelete: function() {
        1 === this.eventInfo.busType && d.dataReport("detail_null_delete_fromappointment_secondaryconfirmation_null_explore", {
            click: "1"
        }), this.hideDialog();
    },
    confirmDelete: function(e) {
        var t = this;
        console.log("e:", e);
        var n = 0;
        e.detail && e.detail.type ? n = e.detail.type : e.currentTarget && e.currentTarget.dataset.type && (n = e.currentTarget.dataset.type), 
        d.dataReport("e#schedule_detail#more_delete#click", {}), 1 === this.eventInfo.busType && d.dataReport("detail_null_delete_fromappointment_secondaryconfirmation_null_explore", {
            click: "0"
        }), this.hideDialog(), wx.showLoading({
            title: "删除中......"
        }), console.log("delete type", n, a(n)), console.log("event eventId:", this.getParentEventId()), 
        console.log("event calendarId:", this.eventInfo.calendarId), r.getInstance().getCalendarInfoById(this.eventInfo.calendarId).then(function(e) {
            var a = t.eventInfo, i = e.calendarUid, o = e.corpId, r = e.calendarId;
            l.getInstance().deleteScheduleEvent(parseInt(n, 10), a, i, o, r).then(function(e) {
                console.log("data:", e), wx.showToast({
                    title: "删除成功",
                    icon: "none"
                });
                var n = getCurrentPages(), a = n[n.length - 2];
                console.log("delteTime:", t.eventInfo.startTime), void 0 !== a ? (a.setData({
                    deleteSuccess: !0,
                    startTime: t.eventInfo.startTime
                }), setTimeout(function() {
                    wx.navigateBack({
                        delta: 1
                    });
                }, 1e3)) : wx.reLaunch({
                    url: "/pages/month/month"
                });
            }).catch(function(e) {
                console.log("delete_err:", e);
                var t = "删除失败，请稍候再试";
                switch (e.code) {
                  case 200036:
                    t = "无法取消进行中的会议";
                    break;

                  case 200035:
                    t = "非会议创建者无法取消会议";
                    break;

                  case 200040:
                    t = "暂不支持删除周期性日程";
                    break;

                  case 500009:
                    t = '参与者不支持删除"仅当前日程"';
                    break;

                  case 500010:
                    t = '参与者不支持删除"将来的所有日程"';
                }
                wx.showToast({
                    title: t,
                    icon: "none"
                });
            });
        }).catch(function(e) {
            console.log("delete_err:", e), wx.showToast({
                title: "删除失败，请稍候再试",
                icon: "none"
            });
        });
    },
    onShareAppMessage: function() {
        var e, t, n = this, a = "0";
        E ? a = "2" : "1400143280" === this.data.corpId && (a = "4"), this.data.showMenuAs ? d.dataReport("e#schedule_detail#more_share#click", {
            calendar_type: a
        }) : d.dataReport("e#schedule_detail#share#click", {
            calendar_type: a
        }), this.setData({
            showMenuAs: !1
        });
        var i = this.calendarId, o = this.calendarUid, r = this.corpId, s = this.eventId;
        if (null !== (e = this.eventInfo) && void 0 !== e && e.originEventId && "0" !== (null === (t = this.eventInfo) || void 0 === t ? void 0 : t.originEventId)) {
            var c = this.eventInfo, l = c.parentEventId, h = c.startTime, g = c.eventId;
            s = "".concat(g, "&parent_event_id=").concat(l, "&period_start_time=").concat(parseInt(h / 1e3, 10));
        }
        var m = "/eventShare?event_id=".concat(s, "&calendar_id=").concat(i, "&cal_uid=").concat(o, "&corp_id=").concat(r), p = "/EventShare/pages/EventShare/index?type=share&targeturl=".concat(encodeURIComponent(m)), f = {
            title: "".concat(u.nickName, "邀请你加入日程"),
            imageUrl: M,
            path: p
        };
        return this.data.shareImgInit ? f : new Promise(function(e) {
            var t = !1;
            n.createSharePicture().then(function(n) {
                f.imageUrl = n, t = !0, e(f);
            }).catch(function(t) {
                console.log(t), e(f);
            });
            var a = b.globalData.isMobile ? 2e3 : 500;
            setTimeout(function() {
                t || e(f);
            }, a);
        });
    },
    onPageScroll: function(e) {
        R(this.setTabBarFixed(e), 500);
    },
    setTabBarFixed: function(e) {
        var t = this.data, n = t.tabBarFixed, a = t.navHeight;
        (!n && e.scrollTop >= a + 10 || n && e.scrollTop < a) && this.setData({
            tabBarFixed: !n
        });
    },
    changeEventStatus: function(e, t) {
        var n = this;
        if (1 !== e || !0 !== this.data.needPassword || "" !== t) {
            wx.showLoading({
                title: "更改中..."
            });
            var a = this.eventInfo;
            "0" !== a.parentEventId && (this.eventId = a.parentEventId), l.getInstance().acceptRejectEvent(this.eventId, this.calendarId, this.corpId, this.calendarUid, t, e).then(function(t) {
                console.log("res:", t), wx.showToast({
                    title: "更改成功",
                    icon: "none"
                }), n.handleEventStatus(e, !0);
            }).catch(function(e) {
                var t = e && (e.msg || e.message) || "更改失败，请稍候再试";
                wx.showToast({
                    title: t,
                    icon: "none"
                });
            });
        } else this.editPassword.showDialog();
    },
    onClickReject: function() {
        2 !== this.data.eventStatus && (d.dataReport("e#schedule_detail#reject#click", {}), 
        this.setData({
            currentClickEventStatus: 2
        }), this.changeEventStatus(2, ""));
    },
    onClickPending: function() {
        4 !== this.data.eventStatus && (d.dataReport("schedule_detail_null_pendingbutton_null_null_click", {}), 
        this.setData({
            currentClickEventStatus: 4
        }), this.changeEventStatus(4, ""));
    },
    onClickAccept: function() {
        1 !== this.data.eventStatus && (d.dataReport("e#schedule_detail#accept#click", {
            passwordbox: this.data.needPassword ? "0" : "1"
        }), this.setData({
            currentClickEventStatus: 1
        }), this.changeEventStatus(1, ""));
    },
    clickReselectStatus: function() {
        d.dataReport("e#schedule_detail#reselect#click", {}), 1 !== this.eventInfo.busType && (this.showActionSheet(P.reselect), 
        this.setData({
            showReselectAs: !0
        }));
    },
    hidePasswordDialog: function() {
        this.editPassword.hideDialog();
    },
    canclepassword: function() {
        this.hidePasswordDialog();
    },
    confirmPassword: function() {
        this.hidePasswordDialog(), this.changeEventStatus(this.data.currentClickEventStatus, this.editPassword.getInputPassword());
    },
    showMoreMenu: function() {
        d.dataReport("e#schedule_detail#more#click", {}), this.showActionSheet(P.share), 
        this.setData({
            showMenuAs: !0
        });
    },
    showActionSheet: function(e) {
        var t = e.itemList, n = e.complete, a = e.itemColor, i = void 0 === a ? "#1E2126" : a;
        k = n, this.setData({
            itemList: t,
            itemColor: i
        });
    },
    pickItem: function(e) {
        k(e.detail);
    },
    wrapAction: function() {
        var e = this, t = {
            itemList: [],
            complete: function(t) {
                switch (t.type) {
                  case "share":
                    break;

                  case "edit":
                    e.goEdit();
                    break;

                  case "delete":
                    e.deleteConfirm();
                }
            }
        };
        this.canShare && t.itemList.push({
            text: "分享",
            type: "share"
        }), console.log("this.canEdit:", this.canEdit), this.canEdit && t.itemList.push({
            text: "编辑",
            type: "edit"
        }), this.canRemove && t.itemList.push({
            text: "删除",
            type: "delete",
            color: "#FF434D"
        });
        var n = {
            itemList: [ {
                text: "接受",
                type: "accept"
            }, {
                text: "待定",
                type: "pending"
            }, {
                text: "拒绝",
                type: "reject"
            } ],
            complete: function(t) {
                switch (t.type) {
                  case "accept":
                    e.onClickAccept();
                    break;

                  case "reject":
                    e.onClickReject();
                    break;

                  case "pending":
                    e.onClickPending();
                }
            }
        };
        P.share = t, P.reselect = n, P.type = "share", this.showActionSheet(P.share);
    },
    cancelAction: function() {
        this.setData({
            showMenuAs: !1,
            showReselectAs: !1
        });
    },
    onClickAddress: function() {
        this.setData({
            showTextDetail: !0,
            detailText: this.data.address || this.data.meetingRoom
        });
    },
    extendDesc: function() {
        this.setData({
            isDescExend: !0
        });
    },
    navigateBack: function() {
        return getCurrentPages().length > 1 ? wx.navigateBack({
            delta: 1
        }) : wx.redirectTo({
            url: "/pages/month/month"
        });
    },
    updateRemoteCalendarInfoIfNeed: function(e, t, n) {
        return r.getInstance().getCalendarInfoList().then(function(a) {
            if (console.log("calendarInfoList", a), null === a || 0 === a.length) return console.info("updateRemoteCalendarSelectedIfNeed", "empty calendarInfoList"), 
            Promise.resolve(void 0);
            for (var i = 0; i < a.length; i++) {
                var o = a[i];
                if (o.calendarId === e && o.corpId === t && o.calendarUid === n && !o.isSelected) return console.info("updateRemoteCalendarSelectedIfNeed", "should update ", o), 
                Promise.resolve(o);
            }
            return Promise.resolve(void 0);
        }).then(function(e) {
            if (void 0 === e) return Promise.resolve();
            console.info("updateRemoteCalendarSelectedIfNeed", "do update ", e);
            var t = [ {
                id: e.calendarId,
                corp_id: e.corpId,
                cal_uid: e.calendarUid,
                is_selected: 1
            } ];
            return l.getInstance().updateCalendarInfos(t);
        });
    },
    showRecurringModifyMenu: function() {
        this.setData({
            showRecurEditMenu: !0,
            recurType: "edit"
        }), this.data.isMeetingPeriod ? this.setData({
            recurMenuItems: v
        }) : this.setData({
            recurMenuItems: f
        });
    },
    cancelRecurMenu: function() {
        this.setData({
            showRecurEditMenu: !1
        });
    },
    commitRecurringModify: function(e) {
        if (this.setData({
            showRecurEditMenu: !1
        }), "delete" === this.data.recurType) return this.confirmDelete(e);
    },
    initCalendarList: function(a) {
        var i = this;
        r.getInstance().getCalendarInfoList().then(function(o) {
            var r = i.calendarDrawerController.getDisplayCalendarList(o, !1), s = null, c = D();
            if (r.forEach(function(e) {
                e.accountCalList.forEach(function(t) {
                    null === a ? t.isDefault && ((s = n({}, t)).groupName = e.groupName) : a === t.calendarId && ((s = n({}, t)).groupName = e.groupName);
                });
            }), !s) {
                var d = t(r[0].accountCalList, 1);
                (s = d[0]).groupName = r[0].groupName;
            }
            var l, u = e(c);
            try {
                for (u.s(); !(l = u.n()).done; ) {
                    var h = t(l.value, 2), g = h[0], m = h[1];
                    a === g && (s.borderColor = S(m));
                }
            } catch (e) {
                u.e(e);
            } finally {
                u.f();
            }
            i.setData({
                calendarList: r,
                selectedCalendar: s
            });
        }).catch(function(e) {
            console.log(e);
        });
    },
    reportNotificationClick: function() {
        d.dataReport("schedule_detail_null_guidenotification_notificationbutton_null_click");
    }
});