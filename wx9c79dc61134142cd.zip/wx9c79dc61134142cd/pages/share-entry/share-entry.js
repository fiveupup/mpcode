var e = require("../../@babel/runtime/helpers/slicedToArray"), n = require("../../sdk/logger/calendar_logger"), t = "share-entry.js";

Page({
    data: {
        firstEnter: !0
    },
    onLoad: function(o) {
        var a = o.sharePath, c = decodeURIComponent(a), i = Date.now();
        n.info("onLoad sharePath raw: ".concat(a, ", decode: ").concat(c), t);
        var r = c && c.split("?"), s = e(r || [], 2), u = s[0], d = s[1], f = "";
        if (d && (f = d.replace("url=", "")), "/pages/sub-web/web/web" === u) {
            var g = decodeURIComponent(f), l = g && g.split("?"), v = l && l[1], p = decodeURIComponent(v), h = l && l[0];
            if (n.info("deWebviewUrl: ".concat(g, ", query: ").concat(v, ", url: ").concat(h, ", deQuery: ").concat(p), t), 
            -1 !== h.indexOf("/share-detail/invite/detail")) return void wx.navigateTo({
                url: "/EventShare/pages/EventShare/index?type=jump&targeturl=".concat(encodeURIComponent("/eventShare?".concat(p))),
                success: function() {
                    n.info("navigator succss.raw: ".concat(a, ",\n            decode: ").concat(c, ",time = ").concat(Date.now() - i), t);
                }
            });
            if (/\/service_booking\/detail\/[0-9]{0,}/.test(h)) return void wx.navigateTo({
                url: "/ServiceBooking/pages/ServiceBookingDetail/index?type=jump&targeturl=".concat(f),
                success: function() {
                    n.info("navigator succss.raw: ".concat(a, ",\n            decode: ").concat(c, ",time = ").concat(Date.now() - i), t);
                }
            });
            if (/\/accept_invite\/[0-9]{0,}/.test(h)) return void wx.navigateTo({
                url: "/invite/pages/AcceptInvite/index?type=jump&targeturl=".concat(f),
                success: function() {
                    n.info("navigator succss.raw: ".concat(a, ",\n            decode: ").concat(c, ",time = ").concat(Date.now() - i), t);
                }
            });
        }
        wx.navigateTo({
            url: c,
            success: function() {
                n.info("navigator succss.raw: ".concat(a, ",decode: ").concat(c, ",time = ").concat(Date.now() - i), t);
            }
        });
    },
    onReady: function() {},
    onShow: function() {
        if (this.data.firstEnter) return this.data.firstEnter = !1, void n.info("onShow first enter. Ignore.", t);
        n.info("reLaunch to month page.", t), wx.reLaunch({
            url: "/pages/month/month"
        });
    },
    onHide: function() {},
    onUnload: function() {},
    onPullDownRefresh: function() {},
    onReachBottom: function() {},
    onShareAppMessage: function() {}
});