var t = require("../../configs/AppConfig.js"), e = require("../../utils/util"), o = e.getValueFromLocalStorage, a = e.setValueInLocalStorage, n = e.getQueryString;

Page({
    data: {
        currentYear: "",
        showModal: !1
    },
    setShowModal: function(t) {
        this.setData({
            showModal: t
        });
    },
    onUseImmediately: function() {
        this.setShowModal(!0);
    },
    onNotInUse: function() {
        this.setShowModal(!1);
    },
    onAgree: function() {
        this.setShowModal(!1), a("COMPLIANCE", 1), wx.navigateTo({
            url: "../month/month"
        });
    },
    goLink: function(e) {
        var o = n({
            url: t[e.currentTarget.dataset.link]
        });
        wx.navigateTo({
            url: "/pages/sub-web/web/web".concat(o)
        });
    },
    onLoad: function() {
        var t = o("COMPLIANCE"), e = new Date().getFullYear();
        this.setData({
            currentYear: e,
            showModal: !t
        }), t && wx.navigateTo({
            url: "../month/month"
        });
    }
});