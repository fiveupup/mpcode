var e = require("../../@babel/runtime/helpers/objectSpread2"), t = require("../../@babel/runtime/helpers/createForOfIteratorHelper");

require("../../@babel/runtime/helpers/Objectvalues");

var a = require("../../@babel/runtime/helpers/regeneratorRuntime"), n = require("../../@babel/runtime/helpers/asyncToGenerator"), i = require("../../@babel/runtime/helpers/slicedToArray"), r = require("debounce"), o = require("../../stores/calendarinfo/CalendarInfoController.js"), c = require("../../stores/overview/OverViewController.js"), s = require("../../stores/event/EventController.js"), l = require("../../sdk/logger/calendar_logger"), d = require("../../stores/UserStore.js"), h = require("../../auth/AuthController"), u = require("../../constants/UserType"), g = require("../../stores/syncwemeet/SyncWeMeetController"), f = require("../../stores/calendardrawer/CalendarDrawerController"), v = require("../../utils/beacon/report_data"), m = require("../../stores/guide_tips/GuideTipsController"), p = require("../../utils/util"), S = require("../../configs/AppConfig"), D = require("../../constants/Calendar"), y = D.CalendarType, C = D.AccessType, _ = require("@tencent/calendar-js-sdk").CalendarSDK, w = require("../../stores/AppConfig").refreshConfig, T = require("../../stores/officialaccountsfocus/officialaccountsfocus.js"), I = T.OfficialAccountsFocus, b = T.OFFICIAL_ACCOUNTS_FOFUCS_CHANGE, E = require("../../stores/invite/InviteEntryController.js"), L = E.InviteEntryController, R = E.WEB_INVITE_SUCCESS, A = E.WEB_CREATE_EVENT_SUCCESS, k = E.WEB_BOOKING_CREATE_SUCCESS, N = require("../../stores/inviteHistory/index"), O = require("../../stores/Setting.js"), x = require("../../utils/wxmlToCanvas.js"), U = require("../../utils/Dayjs.js"), M = require("@tencent/wecalendar-web-business-plugins").Permission, H = "https://cdn.calendar.tencent.com/calendar_res/mpCalendar/canvas/detail-share-default-new.jpg", F = "".concat("https://cdn.calendar.tencent.com/calendar_res/", "bg_home.png"), q = "month.js", P = getApp(), J = !1, W = !1;

Page({
    data: {
        dayList: [],
        calendarSpot: {},
        titleText: "",
        isRegister: !0,
        showTodayBtn: !1,
        drawerInfo: {},
        hadCreateInviteSuccess: !1,
        hadCreateBookingSuccess: !1,
        eventMode: "list",
        showPublicAlert: !1,
        hadFocusOfficialAccounts: {},
        firstLineGuide: "",
        secondLineGuide: "",
        currentDate: {
            year: "",
            month: "",
            day: ""
        },
        showMenuItemsDialog: !1,
        beginDay: "",
        newEventId: "",
        openStatus: !1,
        resource_invite: "https://cdn.calendar.tencent.com/calendar_res/mpCalendar/month_invite.png",
        resource_booking: "https://cdn.calendar.tencent.com/calendar_res/mpCalendar/month_booking.png",
        isLogin: !1,
        showShareDialog: !1,
        accessRole: C.SHARE_WITH_VIEW,
        currentShareCalendar: {},
        invitationCode: "",
        shareImgInit: !1,
        shareResult: {
            canShare: !0,
            message: "操作失败，请稍后再试"
        },
        containerTop: 200,
        groupCalendarList: []
    },
    onShareAppMessage: function(e) {
        var t = this, a = e.from;
        if ("menu" === a) return l.infoAll("month share from: ".concat(a)), {
            title: "".concat(d.nickName, "邀请你使用腾讯日历"),
            path: "pages/month/month",
            imageUrl: F
        };
        var n = this.data.invitationCode, i = this.data.currentShareCalendar.calendarId, r = "/CalendarShare/pages/CalendarShare/index?calendar_id=".concat(i, "&invitation_code=").concat(n), o = {
            title: "".concat(d.nickName, "邀请你订阅共享日历"),
            path: r,
            imageUrl: H
        };
        return l.infoAll("month share from: ".concat(a, ", shareData: ").concat(JSON.stringify(o))), 
        new Promise(function(e, a) {
            if (t.data.shareResult && !t.data.shareResult.canShare) return wx.showToast({
                icon: "none",
                title: t.data.shareResult && t.data.shareResult.message || "操作失败，请稍后再试"
            }), void a();
            if (t.data.shareImgInit) return o.imageUrl = t.data.shareImgUrl, t.setData({
                showShareDialog: !1
            }), void e(o);
            var n = !1;
            t.createSharePicture().then(function(a) {
                o.imageUrl = a, n = !0, t.setData({
                    showShareDialog: !1
                }), e(o);
            });
            var i = P.globalData.isMobile ? 2e3 : 500;
            setTimeout(function() {
                n || (t.setData({
                    showShareDialog: !1
                }), e(o));
            }, i);
        });
    },
    calendarDateChange: function(e) {
        var t = e.detail, a = t.selectDate, n = t.isClick, i = t.isEventDot, r = t.titleText;
        l.infoAll("calendarDateChange ".concat(JSON.stringify(a)), q), v.dataReport("e#main#top_date#click", {
            schedule_exists: i ? "0" : "1",
            week_or_month: this.data.isMonthMode ? "1" : "0",
            user_positivie_or_negative: n ? "0" : "1"
        }), this.setData({
            titleText: r
        });
        var o = new Date(a.year, a.month - 1, a.day - 1), c = new Date(a.year, a.month - 1, a.day), s = new Date(a.year, a.month - 1, a.day + 1), d = new Date(), h = c.getFullYear() === d.getFullYear() && c.getMonth() === d.getMonth() && c.getDate() === d.getDate();
        this.setData({
            showTodayBtn: !h,
            dayList: [ {
                year: o.getFullYear(),
                month: o.getMonth() + 1,
                day: o.getDate()
            }, {
                year: c.getFullYear(),
                month: c.getMonth() + 1,
                day: c.getDate()
            }, {
                year: s.getFullYear(),
                month: s.getMonth() + 1,
                day: s.getDate()
            } ]
        }), this.requestCalendarData("再刷新数据"), h || v.dataReport("e#main#today#explore", {});
    },
    eventDateChange: function(e) {
        l.infoAll("eventDateChange ".concat(JSON.stringify(e.detail)), q), this.setData({
            calendarSelectDate: {
                year: e.detail.year,
                month: e.detail.month,
                day: e.detail.day
            }
        });
    },
    calendarModeChange: function(e) {
        var t = e.detail;
        this.setData({
            isMonthMode: t
        }), this.openStatus = t, this.changeEventHeight(t), v.dataReport(t ? "e#main#date_bar_open#click" : "e#main#date_bar_close#click");
    },
    calendarSwiperChange: function(e) {
        var t = e.detail, a = t.isMonth, n = t.toLeft;
        v.dataReport(a ? "e#main#date_bar_month_view#click" : "e#main#date_bar_week_view#click", {
            slide_type: n ? "1" : "0"
        });
    },
    eventSwiperChange: function(e) {
        v.dataReport("homepage_day_schedulelist_slide", {
            slide_type: e.detail ? "1" : "0"
        });
    },
    changeEventHeight: function(e) {
        var t = this, a = this.container || {}, n = a.current, i = a.previous;
        if (n && i && "list" === this.data.eventMode) {
            var r = i.top, o = n.top, c = this.openStatus;
            if (c && o < r || !c && o > r) return this.container = {
                current: i,
                previous: n
            }, void this.setData({
                containerHeight: i.height,
                containerTop: i.top
            });
        }
        wx.getSystemInfo({
            success: function(a) {
                var n = t;
                wx.createSelectorQuery().select("#nav_bar").boundingClientRect(function(i) {
                    var r = p.getValueFromLocalStorage("open_status"), o = 750 * (null !== i ? i.height : 0) / a.windowWidth, c = 96 + 86 * (e || r ? 6 : 1), s = void 0 !== t.data.alldaySchedule ? t.data.alldaySchedule.length : 0, l = s > 0 ? 54 * s + 16 * (s - 1) : 0;
                    l = "day" === t.data.eventMode ? l : 0;
                    var d = Math.min(l, 426) + (l > 0 ? 28 : 0), h = c + d, u = 750 * a.windowHeight / a.windowWidth - c - o - d;
                    if (n.setData({
                        containerHeight: u,
                        containerTop: h
                    }), "list" === t.data.eventMode) {
                        var g = (t.container || {}).current;
                        t.container = Object.assign({}, t.container, {
                            current: {
                                top: h,
                                height: u
                            }
                        }), g && g.top !== h && (t.container.previous = {
                            top: g && g.top || 0,
                            height: g && g.height || 0
                        });
                    }
                }).exec();
            }
        });
    },
    onClickSchedule: function(e) {
        var t = e.detail, a = t.schedule, n = t.index;
        this.currentIdx = n;
        var i = this.data, r = i.eventId, o = i.startTime, c = i.parentId, s = i.calendarId;
        if (this.prevIdx === "".concat(n) && r && s && (r !== a.eventId || s !== a.calendarId)) {
            var l = "eventId=".concat(r, "&calendarId=").concat(s, "&startTime=").concat(o, "&parentId=").concat(c);
            wx.navigateTo({
                url: "/pages/detail/detail?".concat(l, "&from=mainpage")
            });
        } else wx.navigateTo({
            url: "/pages/detail/detail",
            success: function(e) {
                e.eventChannel.emit("eventDetail", {
                    data: a
                });
            }
        });
        m.getInstance().notifyScheduleClick(), v.dataReport("e#main#schedule_list#click", {
            calendar_type: 3 === a.eventType ? "2" : "0",
            schedule_type: a.endTime > new Date().getTime() ? "0" : "1",
            calendar_view_type: "day" === this.data.eventMode ? "1" : "0"
        }), this.prevIdx = "".concat(n);
    },
    onShowJoinMeeting: function(e) {
        var t = e.detail, a = i(this.data.dayList, 2)[1], n = new Date(a.year, a.month - 1, a.day);
        t.forEach(function(e) {
            new Date(e.day.year, e.day.month - 1, e.day.day).getTime() === n.getTime() && v.dataReport("e#main#schedule_list_join_meeting#explore", {});
        });
    },
    onClickJoinMeeting: function(e) {
        var t = e.detail, a = {
            startTime: t.startTime,
            endTime: t.endTime,
            summary: t.summary,
            meetingCode: t.meetingInfo.meetingCode
        };
        this.setData({
            joinDialogData: a
        }), v.dataReport("e#main#schedule_list_join_meeting#click", {});
    },
    onTodayClick: function() {
        this.selectTargetDate(new Date()), v.dataReport("e#main#today#click", {});
    },
    onCreateClick: function() {
        if (l.infoAll("onCreateClick", q), 2 !== d.registerState) {
            v.dataReport("homepage_newbutton_click", {}), v.dataReport("e#main#simplify#click", {}, !0), 
            m.getInstance().notifyCreateBtnClick();
            var e = this.data.dayList[1] || {}, t = this;
            wx.navigateTo({
                url: "/create/create?year=".concat(e.year, "&month=").concat(e.month, "&day=").concat(e.day),
                success: function(e) {
                    e.eventChannel.once("createEventSuccess", function(e) {
                        var a = e.eventId, n = e.startTime;
                        t.newEventId = a, l.infoAll("createEventSuccess eventId = ".concat(a, ", ").concat(JSON.stringify(new Date(n))), q), 
                        t.setData({
                            scrollTargetEvent: e
                        }), t.clearCalendarData(), t.selectTargetDate(new Date(n)), t.reload = !0, !0 === I.getNeedShowOfficialAccountDialog() && (t.setData({
                            showPublicAlert: !0
                        }), I.handleShowOfficialAccountDialog(), v.dataReport("e#main#follow_guidance#explore", {}));
                    });
                }
            }), v.dataReport("homepage_null_null_add_schedule_null_click", {});
        } else this.onAuthBtnTab();
    },
    reloadCalendarData: function() {
        this.clearCalendarData(), this.requestCalendarData("reloadCalendarData");
    },
    clearCalendarData: function() {
        o.getInstance().reload(), c.getInstance().reload(), s.getInstance().reload();
    },
    requestCalendarData: function(e) {
        var t = this;
        return n(a().mark(function n() {
            var r, o, h, u, g, f;
            return a().wrap(function(a) {
                for (;;) switch (a.prev = a.next) {
                  case 0:
                    if (l.info("requestCalendarData from ".concat(e), q), 0 !== t.data.dayList.length) {
                        a.next = 3;
                        break;
                    }
                    return a.abrupt("return");

                  case 3:
                    if (!1 !== d.userLoginSuc) {
                        a.next = 6;
                        break;
                    }
                    return l.infoAll("requestCalendarData not login", q), a.abrupt("return");

                  case 6:
                    if (r = i(t.data.dayList, 2), o = r[1], h = new Date(o.year, o.month - 1, o.day), 
                    u = h.toLocaleDateString(), l.infoAll("requestCalendarData execute for: ".concat(u), q), 
                    t.calendarInfoList) {
                        a.next = 13;
                        break;
                    }
                    return a.next = 13, t.initSubScriber();

                  case 13:
                    g = c.getInstance().getScheduleOverViewThreeMonth(h.getTime()).then(function(e) {
                        return l.infoAll("requestCalendarData overview show for: ".concat(u), q), t.setData({
                            calendarSpot: t.buildSpotArr(e)
                        }), 0;
                    }).catch(function(e) {
                        return l.infoAll("requestCalendarData overview error for: ".concat(u, " ").concat(JSON.stringify(e)), q), 
                        401 === e.statusCode ? 401 : -1 === e ? 0 : e.code;
                    }), f = Promise.all([ s.getInstance().getEventListByOffset(h.getTime()).catch(function(e) {
                        return -1 === e ? Promise.resolve([]) : Promise.reject(e);
                    }) ]).then(function(e) {
                        var a, n = i(e, 1)[0];
                        t.reload = !1, l.infoAll("requestCalendarData event show for: ".concat(u, " ").concat(JSON.stringify(n)), q);
                        var r = i(t.data.dayList, 2)[1], o = new Date(r.year, r.month - 1, r.day).getTime();
                        return (null === (a = n[1]) || void 0 === a ? void 0 : a.dayTime) === o && t.setData({
                            eventArr: t.buildEventArr(n),
                            alldaySchedule: t.buildAllDayArr(n)[1],
                            newEventId: t.newEventId
                        }), t.changeEventHeight(t.data.isMonthMode), 0;
                    }).catch(function(e) {
                        return t.reload = !1, l.infoAll("requestCalendarData event error for: ".concat(u, " ").concat(JSON.stringify(e)), q), 
                        401 === e.statusCode ? 401 : e.code;
                    }), Promise.all([ g, f ]).then(function(e) {
                        e.forEach(function(e) {
                            if (0 !== e) return 401 === e ? l.error("relogin for 401", q) : 200020 === e && l.error("relogin for 200020", q), 
                            !1;
                        });
                    });

                  case 16:
                  case "end":
                    return a.stop();
                }
            }, n);
        }))();
    },
    initSubScriber: function() {
        var e = this;
        return o.getInstance().getCalendarInfoList().then(function(a) {
            e.calendarInfoList = a, e.setData({
                calUidList: e.buildCalUidList(a)
            });
            var n = e.calendarDrawerController.getDisplayCalendarList(a);
            e.setData({
                groupCalendarList: p.initGroupCalendarList(n)
            }), Object.values(n).forEach(function(a) {
                var r = a.accountCalList, c = [], s = [];
                r.forEach(function(e) {
                    if (0 === e.calType || 3 === e.calType) c.push({
                        cal_uid: e.calendarUid,
                        corp_id: e.corpId,
                        calendar_id: e.calendarId
                    }); else if (e.calType === y.SHARED) {
                        var t = s.find(function(t) {
                            return t.cal_uid === e.calendarUid;
                        });
                        t ? t.calendar_ids.push(e.calendarId) : s.push({
                            cal_uid: e.calendarUid,
                            corp_id: e.corpId,
                            calendar_ids: [ e.calendarId ]
                        });
                    }
                });
                var d = {
                    creator_calendar: c,
                    subscriber_calendar: s
                };
                o.getInstance().batchQuerySubscribers(d).then(function(a) {
                    var o = a.subscribers, c = a.creators, s = p.parseColors();
                    r.forEach(function(e) {
                        if (0 === e.calType || 3 === e.calType) o.forEach(function(t) {
                            e.calendarId === t.calendar_id && (e.subscribes = p.formatSubscribers(t));
                        }); else if (e.calType === y.SHARED) {
                            c.forEach(function(t, a) {
                                e.calendarId === t.calendar_id && (e.creators = "".concat(c[a].nickname));
                            });
                            var a, n = t(s);
                            try {
                                for (n.s(); !(a = n.n()).done; ) {
                                    var r = i(a.value, 2), l = r[0], d = r[1];
                                    e.calendarId === l && (e.borderColor = p.formatRgba(d));
                                }
                            } catch (e) {
                                n.e(e);
                            } finally {
                                n.f();
                            }
                        }
                    }), e.setData({
                        groupCalendarList: p.initGroupCalendarList(n)
                    });
                }).catch(function(e) {
                    l.infoAll("requestSubscribers event error for: ".concat(JSON.stringify(e)), q);
                });
            });
        }).catch(function(e) {
            console.log("initSubScriber e:", e);
        });
    },
    buildCalUidList: function(e) {
        var t = [];
        return e.forEach(function(e) {
            var a = e.calendarUid;
            if ("" === a || t.indexOf(a) >= 0) return !0;
            t.push(a);
        }), t;
    },
    buildEventArr: function(e) {
        var a = this, n = p.parseColors(), r = [];
        return e.forEach(function(e) {
            var o = e.dayTime, c = [];
            e.eventList.forEach(function(e) {
                a.calendarInfoList.forEach(function(a) {
                    if (a.calendarId === e.calendarId) return e.bgColor = a.bgColor, e.fgColor = a.fgColor, 
                    !1;
                    var r, o = t(n);
                    try {
                        for (o.s(); !(r = o.n()).done; ) {
                            var c = i(r.value, 2), s = c[0], l = c[1];
                            if (e.calendarId === s) return e.bgColor = p.formatRgba(l), e.fgColor = p.formatRgba(l), 
                            !1;
                        }
                    } catch (e) {
                        o.e(e);
                    } finally {
                        o.f();
                    }
                });
                var r = {
                    dayTime: o,
                    event: e,
                    title: e.summary,
                    color: e.bgColor
                };
                c.push(r);
            }), r.push(c);
        }), l.info("formatter normal event: ".concat(JSON.stringify(r)), q), r;
    },
    buildAllDayArr: function(e) {
        var t = this, a = [];
        return e.forEach(function(e) {
            var n = [], i = e.dayTime;
            e.eventList.forEach(function(e) {
                var a = new Date(e.startTime), r = new Date(e.endTime), o = e.isAllDay, c = a.getTime() <= i && r.getTime() >= i + 864e5;
                if (!o && !c) return !0;
                if (3 === e.eventType) return !0;
                t.calendarInfoList.forEach(function(t) {
                    if (t.calendarId === e.calendarId) return e.bgColor = t.bgColor, !1;
                });
                var s = {
                    event: e,
                    title: e.summary,
                    color: e.bgColor
                };
                n.push(s);
            }), a.push(n);
        }), l.info("formatter all day event: ".concat(JSON.stringify(a)), q), a;
    },
    buildSpotArr: function(e) {
        var t = i(this.data.dayList, 2)[1], a = new Date(), n = new Date(t.year, t.month - 1, t.day).getTime(), r = new Date(a.getFullYear(), a.getMonth(), a.getDate()).getTime(), o = n === r, c = 0, s = {};
        return e.forEach(function(e) {
            var t, a = e.eventCount;
            e.isOnDuty && (t = {
                wording: "班",
                color: "#FF434D"
            }, a -= 1), e.isOffDuty && (t = {
                wording: "休",
                color: "#00B996"
            }, a -= 1);
            var n = e.holiday.length;
            n > 0 && (a -= n), s[e.day] = {
                tips: t,
                eventDot: a > 0,
                holiday: n > 0 ? e.holiday[0] : ""
            }, e.time === r && (c = a);
        }), o && v.dataReport("homepage_day_schedulelist_numb", {
            sechedule_count: "".concat(c)
        }), s;
    },
    selectTargetDate: function(e) {
        var t = {
            year: e.getFullYear(),
            month: e.getMonth() + 1,
            day: e.getDate()
        };
        this.setData({
            calendarSelectDate: t
        });
    },
    onLoad: function(e) {
        var t = this;
        l.info("onLoad: ".concat(JSON.stringify(e)), q);
        var a = p.getValueFromLocalStorage("event_mode_view");
        "" !== a && void 0 !== a && this.setData({
            eventMode: a
        });
        var n = p.getValueFromLocalStorage("open_status");
        "" !== n && void 0 !== n && (this.setData({
            openStatus: n
        }), this.openStatus = n);
        var i = p.getValueFromLocalStorage("show_lunar_calendar");
        "" !== i && void 0 !== i || p.setValueInLocalStorage("show_lunar_calendar", !0), 
        d.addEventListener(this.onUserStoreChange), L.addEventListener(this.onWebEventCreateSuccess), 
        I.addEventListener(this.onOfficialAccountsFocusChange), this.syncWeMeetController = new g(function() {
            t.showSyncDialog();
        }, function() {
            t.onSyncWemeetStateChanged();
        }), this.calendarDrawer = this.selectComponent("#calendar_drawer"), this.calendarDrawerController = new f(), 
        2 === d.registerState && this.onNeedRegister("init"), d.userLoginSuc && this.onUserLoginSuc(), 
        this.eventComp = this.selectComponent("#event-comp"), this.guideTips = this.selectComponent("#guide-tips"), 
        this.calendarView = this.selectComponent("#calendar_view"), this.widget = this.selectComponent(".widget"), 
        m.getInstance().setGuideListener({
            onCreateTipsStatus: this.onCreateTipsStatus,
            onDetailTipsStatus: this.onDetailTipsStatus
        }), this.selectTargetDate(new Date()), d.userLoginSuc && this.syncWeMeetController.checkShowSyncWemeet(), 
        this.newEventId = "", P.globalData.isMobile || this.setData({
            resource_booking: "https://cdn.calendar.tencent.com/calendar_res/mpCalendar/month_booking.png",
            resource_invite: "https://cdn.calendar.tencent.com/calendar_res/mpCalendar/month_invite.png"
        }), this.changeList = [], s.getInstance().eventEmitter.subscribe("event_list_change", function(e) {
            var a = e.reload, n = e.time;
            if (!a) {
                var i = "".concat(t.data.eventMode, "-").concat(n);
                t.changeList.includes(i) || (console.log("触发了event_list_change:", n), t.changeList.push(i), 
                t.requestCalendarData("data_fetch"), t.changeEventHeight(!1));
            }
        });
    },
    onReady: function() {
        this.selectComponent("#nav_bar").setData({
            displayStyle: "z-index: 0"
        });
    },
    renderToCanvas: function(e) {
        var t = this, a = e.title, n = e.desc, i = e.eventTitle, r = e.eventTime, o = x.renderWxml(a, n, i, r), c = x.renderStyle(a, i), s = this.widget.renderToCanvas({
            wxml: o,
            style: c
        });
        return new Promise(function(e) {
            s.then(function() {
                t.widget.canvasToTempFilePath().then(function(t) {
                    e(t.tempFilePath);
                });
            });
        });
    },
    handleTodayWhetherChange: function() {
        var e = new Date(), t = p.getValueFromLocalStorage("begin_day") || "Sunday";
        if (this.setData({
            beginDay: t
        }), "" === this.data.currentDate.year) {
            var a = {};
            a.year = e.getFullYear(), a.month = e.getMonth(), a.day = e.getDate(), this.setData({
                currentDate: a
            });
        } else if (this.data.currentDate.year !== e.getFullYear() || this.data.currentDate.month !== e.getMonth() || this.data.currentDate.day !== e.getDate()) {
            var n = {};
            n.year = e.getFullYear(), n.month = e.getMonth(), n.day = e.getDate();
            var i = {};
            i.year = this.data.currentDate.year, i.month = this.data.currentDate.month, i.day = this.data.currentDate.day;
            var r = this.data.calendarSelectDate.year === e.getFullYear() && this.data.calendarSelectDate.month - 1 === e.getMonth() && this.data.calendarSelectDate.day === e.getDate();
            this.setData({
                showTodayBtn: !r,
                currentDate: n,
                calendarTodayChange: i
            });
        }
    },
    handleEventModeChange: function() {
        var e = p.getValueFromLocalStorage("event_mode_view");
        "" !== e && void 0 !== e && e !== this.data.eventMode && this.setData({
            eventMode: e
        });
    },
    onShow: function() {
        this.handleTodayWhetherChange(), this.handleEventModeChange(), this.calendarView.displayItemConfiguration(), 
        m.getInstance().notifyMainPageShow(), w();
        var e = I.getHadFocusOfficialAccount() ? 0 : 1;
        v.dataReport("e#main#all#explore", {
            officialaccount: e
        });
        var t = getCurrentPages(), a = t[t.length - 1];
        if (a.data.editSuccess) {
            var n = a.data, i = n.eventId, r = n.startTime, o = {
                eventId: i,
                startTime: r
            };
            l.infoAll("editEventSuccess eventId = ".concat(i, ", ").concat(JSON.stringify(new Date(r))), q), 
            this.setData({
                scrollTargetEvent: o,
                editSuccess: !1
            }), this.clearCalendarData(), this.selectTargetDate(new Date(r)), this.data.reload = !0;
        }
        if (a.data.deleteSuccess) {
            var c = a.data.startTime;
            this.setData({
                deleteSuccess: !1
            }), this.clearCalendarData(), this.selectTargetDate(new Date(c)), this.data.reload = !0;
        }
        !this.data.reload && this.data.isRegister && (this.reloadCalendarData(), l.infoAll("onShow auto reload data", q), 
        this.initSubScriber()), this.data.reload = !1, I.getFocusStateFromServer();
    },
    onHide: function() {
        delete this.data.eventId, delete this.data.parentId, delete this.data.calendarId;
    },
    onUnload: function() {
        d.removeEventListener(this.onUserStoreChange), L.removeEventListener(this.onWebEventCreateSuccess), 
        I.removeEventListener(this.onOfficialAccountsFocusChange);
    },
    loadDataToCalendarDrawer: function() {
        var t = this;
        this.calendarDrawerController.createDrawerData().then(function(a) {
            l.info("resp from CalendarDrawerController createDrawerData: ".concat(JSON.stringify(a)), q), 
            t.setData({
                drawerInfo: e(e({}, t.data.drawerInfo), a)
            });
        }).catch(function(e) {
            l.info("err from CalendarDrawerController createDrawerData: ".concat(JSON.stringify(e)), q);
        }), I.getFocusStateFromServer();
    },
    onDrawerClick: function() {
        this.calendarDrawer.openDrawer(), this.loadDataToCalendarDrawer(), this.loadAccessData(), 
        v.dataReport("e#main#sidebar#click", {});
    },
    loadAccessData: function() {
        this.setData({
            roleList: p.roleList,
            accessList: p.accessList
        });
    },
    onClickRole: function(e) {
        for (var t = this, a = e.detail.index, n = p.roleList, i = 0; i < n.length; i++) n[i].isSelect = i === a;
        this.setData({
            roleList: n
        });
        var o, c = this.data.accessList;
        o = 0 === a ? C.EDIT : this.getAccessRole(c), this.setData({
            accessRole: o
        }), r(this.generateInvitationCode().catch(function(e) {
            var a = e || {}, n = a.code, i = a.message, r = "分享出错".concat(i || JSON.stringify(e));
            700001 === n && (r = "操作失败，请稍后再试"), t.setData({
                shareResult: {
                    canShare: !1,
                    message: r
                }
            });
        }), 500);
    },
    onClickAccess: function(e) {
        var t = this, a = e.detail.index, n = this.data.accessList, i = n;
        i[a].isSelect = !i[a].isSelect, this.setData({
            accessList: i
        });
        var o = this.getAccessRole(n);
        this.setData({
            accessRole: o
        }), this.createSharePicture(), r(this.generateInvitationCode().catch(function(e) {
            var a = e || {}, n = a.code, i = a.message, r = "分享出错".concat(i || JSON.stringify(e));
            700001 === n && (r = "操作失败，请稍后再试"), t.setData({
                shareResult: {
                    canShare: !1,
                    message: r
                }
            });
        }), 500);
    },
    getAccessRole: function(e) {
        var t;
        return e[0].isSelect && e[1].isSelect ? t = C.SHARE_WITH_SCHEDULE : e[0].isSelect && !e[1].isSelect ? t = C.SCHEDULE : !e[0].isSelect && e[1].isSelect ? t = C.SHARE_WITH_VIEW : e[0].isSelect || e[1].isSelect || (t = C.VIEW), 
        t;
    },
    generateInvitationCode: function() {
        var e = this, t = {
            calendar_id: this.data.currentShareCalendar.calendarId,
            cal_uid: this.data.currentShareCalendar.calendarUid,
            corp_id: this.data.currentShareCalendar.corpId,
            access_role: this.data.accessRole
        };
        return o.getInstance().getInvitationCode(t).then(function(t) {
            e.setData({
                invitationCode: t.invitation_code
            });
        });
    },
    getEventListByCalendar: function() {
        var e = this, t = {
            flag: 0,
            limit: 100,
            offset: 0,
            refer_time: Math.floor(new Date().getTime() / 1e3),
            event_types: "0,1,2,3",
            calendars: [ {
                calendar_id: this.data.currentShareCalendar.calendarId,
                cal_uid: this.data.currentShareCalendar.calendarUid,
                corp_id: this.data.currentShareCalendar.corpId
            } ]
        };
        return s.getInstance().getEventListByReferTime(t).then(function(t) {
            e.setData({
                calendarEvents: t.list
            });
        });
    },
    onHideDrawer: function(e) {
        l.info("onHideDrawer payload: ".concat(JSON.stringify(e)), q), e.detail.selectStateChanged && (l.info("selectStateChanged, then reloadCalendarData.", q), 
        this.reloadCalendarData());
    },
    onCalendarItemTab: function(e) {
        var t = e.detail;
        l.info("onCalendarItemTab calendarInfo: ".concat(JSON.stringify(t)), q), this.calendarDrawerController.changeCalendarSelectState(t).then(function() {
            l.info("changeCalendarSelectState suc.", q), v.dataReport("e#main#sidebar_calendar_list#click", {
                calendar_type: t.calType,
                show_or_hide: t.isSelect ? 1 : 0
            }), o.getInstance().reload();
        }).catch(function(e) {
            l.info("changeCalendarSelectState err: ".concat(JSON.stringify(e)), q);
        });
    },
    onClickShareCalendar: function(e) {
        var t = this, a = e.detail;
        l.info("onClickShareCalendar", q), this.setData({
            currentShareCalendar: a
        });
        var n = JSON.parse(JSON.stringify(p.roleList)), i = JSON.parse(JSON.stringify(p.accessList));
        n.forEach(function(e, t) {
            e.isSelect = 1 === t, e.disable = a.calType === y.SHARED;
        }), i.forEach(function(e) {
            "仅看忙闲" === e.name && (e.isSelect = a.accessRole === C.SHARE_WITH_SCHEDULE, e.disable = a.accessRole === C.SHARE_WITH_SCHEDULE);
        });
        var r = a.accessRole === C.EDIT ? C.SHARE_WITH_VIEW : a.accessRole, o = a.calType === y.SHARED ? r : C.SHARE_WITH_VIEW;
        this.setData({
            roleList: n,
            accessList: i,
            accessRole: o
        }), this.generateInvitationCode().then(function() {
            t.setData({
                showShareDialog: !0
            });
        }).catch(function(e) {
            var t = e || {}, a = t.code, n = t.message, i = "分享出错".concat(n || JSON.stringify(e));
            700001 === a && (i = "操作失败，请稍后再试"), wx.showToast({
                icon: "none",
                title: i
            });
        }), this.getEventListByCalendar().then(function() {
            t.createSharePicture();
        }).catch(function(e) {
            var t = (e || {}).message;
            wx.showToast({
                icon: "none",
                title: t
            });
        });
    },
    createSharePicture: function() {
        var e = this, t = this.data.currentShareCalendar, a = t.calType === y.SHARED ? t.creators : d.nickName, n = "", i = "", r = this.data.calendarEvents.length > 0 && this.data.calendarEvents[0].event_info;
        if (r) {
            var o = new M(this.data.accessRole);
            n = (null == o ? void 0 : o.view) && (null == r ? void 0 : r.summary) || "*****";
            var c = 1e3 * (null == r ? void 0 : r.start_time) || "", s = 1e3 * (null == r ? void 0 : r.end_time) || "", l = U(c), h = U(s);
            i = "".concat(l.format("MM/DD"), " ").concat(U(l).format("HH:mm"), "-").concat(U(h).format("HH:mm")), 
            null != r && r.is_period && (i += " 周期");
        }
        var u = {
            title: t.calName,
            desc: "创建者：".concat(a),
            eventTitle: n,
            eventTime: i
        };
        return this.renderToCanvas(u).then(function(t) {
            return H = t, e.setData({
                shareImgUrl: H,
                shareImgInit: !0
            }), H;
        });
    },
    onCloseGrantPhoneTap: function() {
        l.info("onCloseGrantPhoneTap", q), this.phoneDialog.hide(), v.dataReport("e#main_login#phone_verification#click", {
            user_click_type: "1"
        });
        var e = d.registerAuthCode, t = d.nickName, a = d.avatarUrl, n = S.DEFAULT_ENV_KEY;
        wx.showLoading({
            title: "登录中",
            mask: !0
        }), h.registerByNoPhoneAndLogin(e, t, a).then(function(e) {
            wx.hideLoading(), l.info("registerByNoPhoneAndLogin resp: ".concat(JSON.stringify(e)), q), 
            v.dataReport("e#main_login#wechat_login_agree#click", {
                login_status: 1,
                env_name: n
            }, !0), wx.showToast({
                title: "登录成功"
            }), J = !1;
        }).catch(function(e) {
            var t = null == e ? void 0 : e.code, a = (null == e ? void 0 : e.message) || (null == e ? void 0 : e.errmsg);
            wx.hideLoading(), l.info("registerByNoPhoneAndLogin error: ".concat(JSON.stringify(e)), q), 
            v.dataReport("e#main_login#wechat_login_agree#click", {
                login_status: 0,
                env_name: n,
                error_code: t,
                error_msg: a
            }, !0), wx.showToast({
                icon: "none",
                title: "服务错误，请重试"
            }), J = !1;
        });
    },
    onGetPhoneNumberTab: function(e) {
        l.info("onGetPhoneNumberTab errMsg: ".concat(JSON.stringify(e)), q), v.dataReport("e#main_login#phone_verification#click", {
            user_click_type: "0"
        }), v.dataReport("e#main_login#wechat_login_phone_bind#explore", {
            user_click_type: "0"
        }), J = !1;
    },
    onWxPhoneNumGranted: function(e) {
        var t = this;
        if (!W) {
            wx.showLoading({
                mask: !0
            }), W = !0, l.info("onWxPhoneNumGranted: ".concat(JSON.stringify(e)), q), v.dataReport("e#main_login#wechat_login_phone_bind_allow#click", {
                user_click_type: 0
            });
            var a = e.detail, n = a.iv, i = a.encryptedData, r = S.DEFAULT_ENV_KEY;
            h.registerByAutoPhoneAndLogin(i, n).then(function(e) {
                l.info("registerByAutoPhoneAndLogin resp: ".concat(JSON.stringify(e)), q), v.dataReport("e#main_login#wechat_login_agree#click", {
                    login_status: 1,
                    env_name: r
                }, !0), wx.showToast({
                    title: "登录成功"
                }), t.phoneDialog.hide(), J = !1, W = !1, setTimeout(function() {
                    wx.hideLoading();
                }, 300);
            }).catch(function(e) {
                l.error("registerByAutoPhoneAndLogin error: ".concat(JSON.stringify(e)), q);
                var t = e.code, a = (null == e ? void 0 : e.message) || "服务错误，请重试";
                wx.hideLoading(), -50004 === t || -10001 === t ? (wx.showToast({
                    icon: "none",
                    title: -50004 === t ? "该手机号已绑定其它微信，请使用其它手机号" : "参数错误，请重新尝试",
                    mask: !0,
                    duration: 1e3
                }), setTimeout(function() {
                    wx.reLaunch({
                        url: "/pages/month/month"
                    });
                }, 1e3)) : (v.dataReport("e#main_login#wechat_login_agree#click", {
                    login_status: 0,
                    env_name: r,
                    error_code: t,
                    error_msg: a
                }, !0), wx.showToast({
                    icon: "none",
                    title: a
                })), J = !1, W = !1;
            });
        }
    },
    onWxPhoneNumRefuse: function() {
        v.dataReport("e#main_login#wechat_login_phone_bind_allow#click", {
            user_click_type: 1
        }), J = !1;
    },
    onUserStoreChange: function(e, t) {
        var a = this;
        switch (e) {
          case u.USER_LOGIN_SUC:
            l.info("onUserStoreChange action: ".concat(e), q), this.onUserLoginSuc();
            break;

          case u.GET_IS_REGISTER:
            l.info("onUserStoreChange action: ".concat(e, ", payload: ").concat(JSON.stringify(t)), q), 
            2 === t.registerState && this.onNeedRegister("action");
            break;

          case u.REFRESH_USER_INFO:
            l.info("UserType.REFRESH_USER_INFO in month. refresh drawer data.", q), this.calendarDrawerController.createUserInfo().then(function(e) {
                l.info("resp from CalendarDrawerController createUserInfo: ".concat(JSON.stringify(e)), q), 
                a.setData({
                    drawerInfo: e
                });
            }).catch(function(e) {
                l.info("err from CalendarDrawerController createUserInfo: ".concat(JSON.stringify(e)), q);
            });
        }
    },
    onWebEventCreateSuccess: function(e, t) {
        switch (e) {
          case R:
            this.setData({
                hadCreateInviteSuccess: !0
            });
            break;

          case A:
            var a = t.eventId, n = t.startTime;
            l.infoAll("onCreateEventSuccess eventId = ".concat(a, ", ").concat(JSON.stringify(new Date(n))), q), 
            a && n && (this.setData({
                scrollTargetEvent: t
            }), this.clearCalendarData(), this.selectTargetDate(new Date(n)), this.data.reload = !0);
            break;

          case k:
            this.setData({
                hadCreateBookingSuccess: !0
            });
        }
    },
    onOfficialAccountsFocusChange: function(e, t) {
        e === b && (this.setData({
            hadFocusOfficialAccounts: t
        }), v.dataReport("e#main_login#all#explore", {
            officialaccount: !0 === t.focus ? 0 : 1
        }));
    },
    onNeedRegister: function(e) {
        l.info("onNeedRegister from ".concat(e), q), this.setData({
            isRegister: !1
        });
    },
    onUserLoginSuc: function() {
        l.info("onUserLoginSuc", q), !1 === this.data.isRegister && this.setData({
            isRegister: !0
        }), this.setData({
            isLogin: !0
        }), this.syncWeMeetController.checkShowSyncWemeet(), this.requestCalendarData("onUserLoginSuc"), 
        this.loadDataToCalendarDrawer(), setTimeout(function() {
            h.refreshUserInfo();
        }, 3e3);
    },
    showSyncDialog: function() {
        this.syncDialog = this.selectComponent("#sync-dialog"), this.syncDialog.show(), 
        v.dataReport("homepage_meetingauthorize_explore", {});
    },
    onUserConfirmSync: function() {
        l.info("onUserConfirmSync", q), this.syncWeMeetController.onUserConfirmSync(), this.syncDialog.hide(), 
        v.dataReport("e#setting#synchronize_tencent_meeting_data#click", {
            button_click_type: "0"
        });
    },
    onUserDeniedSync: function() {
        l.info("onUserDeniedSync", q), this.syncWeMeetController.onUserDeniedSync(), this.syncDialog && this.syncDialog.hide(), 
        v.dataReport("e#setting#synchronize_tencent_meeting_data#click", {
            button_click_type: "1"
        });
    },
    onSyncWemeetStateChanged: function() {
        l.info("onSyncWemeetStateChanged", q), this.reloadCalendarData();
    },
    onCreateTipsStatus: function(e) {
        l.info("onCreateTipsStatus show: ".concat(e), q), e ? this.guideTips.showCreateTips() : this.guideTips.hideCreateTips();
    },
    onDetailTipsStatus: function(e) {
        l.info("onDetailTipsStatus show: ".concat(e), q), e ? this.eventComp && this.eventComp.showDetailTips() : this.eventComp && this.eventComp.hideDetailTips();
    },
    onCreateGuideTipsTab: function() {
        l.info("onCreateGuideTipsTab", q), m.getInstance().notifyCreateGuideTipsTab();
    },
    onDetailGuideTipsTab: function() {
        l.info("onDetailGuideTipsTab", q), m.getInstance().notifyDetailGuideTipsTab();
    },
    onAuthBtnTab: function() {
        var e = this;
        l.info("onAuthBtnTab", q), J || (J = !0, wx.getUserProfile({
            lang: "zh_CN",
            desc: "使用您的微信昵称作为日历昵称",
            success: function(t) {
                l.info("onAuthBtnTab suc: ".concat(JSON.stringify(t)), q);
                var a = t.userInfo;
                d.nickName = a.nickName, d.avatarUrl = a.avatarUrl, e.showPhoneDialog(), l.info("onAuthBtnTab nickName: ".concat(l.getMd5(a.nickName), ",\n          avatarUrl: ").concat(a.avatarUrl), q);
            },
            fail: function(e) {
                l.info("onAuthBtnTab fail: ".concat(JSON.stringify(e)), q), wx.showToast({
                    title: "授权失败，请重新授权",
                    icon: "none"
                }), J = !1;
            },
            complete: function(e) {
                l.info("onAuthBtnTab complete: ".concat(JSON.stringify(e)), q);
            }
        }));
    },
    showPhoneDialog: function() {
        this.phoneDialog = this.selectComponent("#phone-dialog"), this.phoneDialog.show(), 
        v.dataReport("e#main_login#phone_verification#explore", {});
    },
    goUseRules: function() {
        var e = p.getQueryString({
            url: S.WeMeetUsageRules
        });
        wx.navigateTo({
            url: "../sub-web/web/web".concat(e)
        });
    },
    goPrivacy: function() {
        var e = p.getQueryString({
            url: S.WeMeetPrivacy
        });
        wx.navigateTo({
            url: "../sub-web/web/web".concat(e)
        });
    },
    toOpenPublicAlert: function() {
        v.dataReport("e#main#follow_guidance_follow#click", {}), this.closePublishAlert();
        var e = S.DEFAULT_ENV_KEY, t = p.getQueryString({
            url: "production" === e ? S.PublicHome : S.PublicHomeTest
        });
        wx.navigateTo({
            url: "../sub-web/web/web".concat(t)
        });
    },
    closePublishAlert: function() {
        v.dataReport("e#main#follow_guidance_close#click", {}), this.setData({
            showPublicAlert: !1
        });
    },
    onMenuItemsDialogClick: function() {
        2 !== d.registerState ? this.setData({
            showMenuItemsDialog: !0
        }) : this.onAuthBtnTab();
    },
    cancelMenuItemsDialog: function() {
        this.setData({
            showMenuItemsDialog: !1
        });
    },
    clickInvite: function() {
        N.getData(!0), O.INVITE_H5 ? L.navigateToInviteHistory() : wx.navigateTo({
            url: "/inviteList/pages/historyInvitation/index"
        }), p.setValueInLocalStorage("hadClickInviteItem", !0), p.setValueInLocalStorage("hadClickDrawerInviteItem", !0), 
        v.dataReport("e#main#invitation#click", {}), d.isLoginSuccess() && _.getInstance().clearInvitationReplyCnt().then(function(e) {
            console.log("clearInvitationReplyCnt success:", e);
        }).catch(function(e) {
            console.log("clearInvitationReplyCnt err:", e);
        }), this.setData({
            showMenuItemsDialog: !1
        });
    },
    clickBooking: function() {
        wx.navigateTo({
            url: "/ServiceBookingOfferServiceList/pages/ServiceBookingOfferServiceList/index"
        }), p.setValueInLocalStorage("hadClickAppointItem", !0), p.setValueInLocalStorage("hadClickDrawerAppointItem", !0), 
        v.dataReport("e#main#appointment#click", {}), this.setData({
            showMenuItemsDialog: !1
        });
    }
});