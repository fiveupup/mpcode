var e = require("../../utils/beacon/report_data"), o = require("../../auth/AuthController"), n = require("../../sdk/logger/calendar_logger"), t = require("../../stores/UserStore"), i = require("../../utils/util"), r = require("../../configs/AppConfig"), a = require("../../auth/AuthUnionJumper"), c = "index.js";

Page({
    data: {
        showAuthView: !1,
        currentYear: ""
    },
    onLoad: function(o) {
        var t = this;
        this.parseOptions(o);
        var i = new Date().getFullYear();
        this.setData({
            currentYear: i
        }), this.makeSureLoginStateIsValid().then(function() {
            t.init();
        }).catch(function(e) {
            n.error("login in error: ".concat(e), c);
        }), e.dataReport("e#main_login#all#explore", {
            source: this.comeFrom
        });
    },
    parseOptions: function(e) {
        n.info("onLoad ".concat(JSON.stringify(e)), c), this.redirectType = e.redirectType, 
        this.redirectUrl = e.redirectUrl, this.needTmpToken = e.needTmpToken, this.comeFrom = e.comeFrom, 
        this.fontcolor = e.fontcolor, this.background = e.background, void 0 !== this.redirectType && void 0 !== this.redirectUrl && (a.setRedirectType(this.redirectType), 
        a.setRedirectUrl(this.redirectUrl)), this.needTmpToken && a.setNeedTmpToken(this.needTmpToken), 
        void 0 === this.comeFrom && (this.comeFrom = "0"), this.fontcolor && a.setFrontColor(this.fontcolor), 
        this.background && a.setBackgroundColor(this.background);
    },
    makeSureLoginStateIsValid: function() {
        return n.info("makeSureLoginStateIsValid"), new Promise(function(e, t) {
            var i = o.isLoginStateValid();
            n.info("makeSureLoginStateIsValid resp: ".concat(i)), i ? e("") : (n.info("do login.", c), 
            o.doLogin().then(function(o) {
                e(""), n.info("AuthController login resp: ".concat(JSON.stringify(o)), c);
            }).catch(function(e) {
                t(e), n.info("AuthController login err: ".concat(JSON.stringify(e)), c);
            }));
        });
    },
    init: function() {
        var e = this, i = t.isRegister, r = this;
        n.info("init isRegister: ".concat(i), c), !!t.getCGIToken() ? a.doJump().catch(function(t) {
            401 === t.statusCode && (o.clearLoginInfo(), o.reInit(), e.makeSureLoginStateIsValid().then(function() {
                r.init();
            }).catch(function(e) {
                n.error("login in error: ".concat(e), c);
            }));
        }) : this.setData({
            showAuthView: !0
        });
    },
    onShareAppMessage: function() {
        return {
            title: "腾讯日历",
            path: "pages/index/index"
        };
    },
    onAuthBtnTab: function() {
        var o = this;
        e.dataReport("e#main_login#wechat_login#explore", {
            source: this.comeFrom
        }), wx.getUserProfile({
            lang: "zh_CN",
            desc: "使用您的微信昵称作为日历昵称",
            success: function(e) {
                n.info("onGetUserProfile suc: ".concat(JSON.stringify(e)), c);
                var i = e.userInfo;
                t.nickName = i.nickName, t.avatarUrl = i.avatarUrl, o.showPhoneDialog(), n.info("onGetUserProfile nickName: ".concat(n.getMd5(i.nickName), ",\n          avatarUrl: ").concat(i.avatarUrl), c);
            },
            fail: function(e) {
                n.info("onGetUserProfile fail: ".concat(JSON.stringify(e)), c);
            },
            complete: function(e) {
                n.info("onGetUserProfile complete: ".concat(JSON.stringify(e)), c);
            }
        });
    },
    goUseRules: function() {
        var o = i.getQueryString({
            url: r.WeMeetUsageRules
        });
        wx.navigateTo({
            url: "../sub-web/web/web".concat(o)
        }), e.dataReport("e#main_login#service_agreement#click");
    },
    goPrivacy: function() {
        var o = i.getQueryString({
            url: r.WeMeetPrivacy
        });
        wx.navigateTo({
            url: "../sub-web/web/web".concat(o)
        }), e.dataReport("e#main_login#privacy_agreement#click");
    },
    showPhoneDialog: function() {
        this.phoneDialog = this.selectComponent("#phone-dialog"), this.phoneDialog.show();
    },
    onCloseGrantPhoneTap: function() {
        n.info("onCloseGrantPhoneTap", c), this.phoneDialog.hide(), this.registerByNoPhoneAndDoJump();
    },
    onGetPhoneNumberTab: function(e) {
        n.info("onGetPhoneNumberTab errMsg: ".concat(JSON.stringify(e)), c);
    },
    onWxPhoneNumGranted: function(t) {
        var i = this;
        n.info("onWxPhoneNumGranted: ".concat(JSON.stringify(t)), c);
        var s = t.detail, l = s.iv, g = s.encryptedData, u = r.DEFAULT_ENV_KEY;
        o.registerByAutoPhoneAndLogin(g, l).then(function(t) {
            n.info("registerByAutoPhoneAndLogin resp: ".concat(JSON.stringify(t)), c), e.dataReport("e#main_login#wechat_login_agree#click", {
                login_status: 1,
                env_name: u
            }, !0), wx.showToast({
                title: "登录成功"
            }), a.doJump().catch(function(t) {
                401 === t.statusCode && (o.clearLoginInfo(), o.reInit(), i.makeSureLoginStateIsValid().then(function() {
                    self.init();
                }).catch(function(o) {
                    n.error("login in error: ".concat(o), c);
                    var t = null == o ? void 0 : o.code, i = (null == o ? void 0 : o.message) || (null == o ? void 0 : o.errmsg);
                    e.dataReport("e#main_login#wechat_login_agree#click", {
                        login_status: 0,
                        env_name: u,
                        error_code: t,
                        error_msg: i
                    }, !0);
                }));
            }), i.phoneDialog.hide();
        }).catch(function(o) {
            n.error("registerByAutoPhoneAndLogin error: ".concat(JSON.stringify(o)), c);
            var t = o.code, r = (null == o ? void 0 : o.message) || "服务错误，请重试";
            -50004 === t ? i.registerByNoPhoneAndDoJump() : (e.dataReport("e#main_login#wechat_login_agree#click", {
                login_status: 0,
                env_name: u,
                error_code: t,
                error_msg: r
            }, !0), wx.showToast({
                icon: "none",
                title: r
            }));
        });
    },
    onWxPhoneNumRefuse: function() {
        e.dataReport("e#main_login#wechat_login_phone_bind_allow#click", {
            user_click_type: 1
        });
    },
    registerByNoPhoneAndDoJump: function() {
        var i = this;
        n.infoAll("registerByNoPhoneAndDoJump", c);
        var s = t.registerAuthCode, l = t.nickName, g = t.avatarUrl, u = r.DEFAULT_ENV_KEY;
        wx.showLoading({
            title: "登录中"
        }), o.registerByNoPhoneAndLogin(s, l, g).then(function(t) {
            wx.hideLoading(), n.info("registerByNoPhoneAndLogin resp: ".concat(JSON.stringify(t)), c), 
            e.dataReport("e#main_login#wechat_login_agree#click", {
                login_status: 1,
                env_name: u
            }, !0), wx.showToast({
                title: "登录成功"
            }), a.doJump().catch(function(t) {
                401 === t.statusCode && (o.clearLoginInfo(), o.reInit(), i.makeSureLoginStateIsValid().then(function() {
                    self.init();
                }).catch(function(o) {
                    var t = null == o ? void 0 : o.code, i = (null == o ? void 0 : o.message) || (null == o ? void 0 : o.errmsg);
                    n.error("login in error: ".concat(o), c), e.dataReport("e#main_login#wechat_login_agree#click", {
                        login_status: 0,
                        env_name: u,
                        error_code: t,
                        error_msg: i
                    }, !0);
                }));
            });
        }).catch(function(o) {
            wx.hideLoading();
            var t = null == o ? void 0 : o.code, i = (null == o ? void 0 : o.message) || (null == o ? void 0 : o.errmsg);
            n.error("login in error: ".concat(o), c), e.dataReport("e#main_login#wechat_login_agree#click", {
                login_status: 0,
                env_name: u,
                error_code: t,
                error_msg: i
            }, !0), wx.showToast({
                icon: "none",
                title: "服务错误，请重试"
            });
        });
    }
});