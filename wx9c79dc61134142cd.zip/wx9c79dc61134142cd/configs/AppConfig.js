var e = require("../@babel/runtime/helpers/typeof"), t = function() {
    var t = "release";
    return void 0 !== ("undefined" == typeof __wxConfig ? "undefined" : e(__wxConfig)) && (t = __wxConfig && __wxConfig.envVersion), 
    t;
}(), n = "production";

if ("release" !== t) try {
    var c = wx.getStorageSync("CALANDER_ENV_KEY");
    c && (n = c);
} catch (e) {}

var a = {
    MP_CALENDAR_VERSION: "2.2.0.3",
    APPID: "wx9c79dc61134142cd",
    ENV_SWITCH_ENABLE: !1,
    EventRemindPushTemplId: "_rOrieVywYfpT_df2tRF-ZziRVnY2iVhR47LLqZjwzI",
    WeMeetOfficialSite: "https://meeting.qq.com",
    WeMeetUsageRules: "https://calendar.tencent.com/calendar-service.html",
    WeMeetPrivacy: "https://calendar.tencent.com/calendar-declare.html",
    WeMeetNewPrivacy: "https://privacy.qq.com/document/preview/42e425018caf4054a88a4c56a78afc60",
    WeMeetKidsPrivacy: "https://privacy.qq.com/policy/kids-privacypolicy",
    CalendarTXC: "https://support.qq.com/products/335602",
    PublicHome: "https://mp.weixin.qq.com/s/L2KTE1sytihDtmkMSMYLjQ",
    PublicHomeTest: "https://mp.weixin.qq.com/s/LnyfzE5HCVHUnQA46Pq-VA",
    DEFAULT_ENV_KEY: n,
    wxVersion: t,
    ENV_LIST: {
        production: {
            key: "production",
            name: "正式环境",
            httpCgi: "https://cgigw.calendar.tencent.com",
            eventShare: "https://w.calendar.tencent.com/share-detail/invite/detail",
            inviteHost: "https://w.calendar.tencent.com",
            bookingHost: "https://w.calendar.tencent.com",
            disabled: !1
        },
        defaultTest: {
            key: "defaultTest",
            name: "默认测试环境",
            httpCgi: "https://cgigwtest.calendar.tencent.com",
            eventShare: "https://wtest.calendar.tencent.com/share-detail/invite/detail",
            inviteHost: "https://wtest.calendar.tencent.com",
            bookingHost: "https://wtest.calendar.tencent.com",
            disabled: !1
        },
        pre: {
            key: "pre",
            name: "预发布",
            httpCgi: "https://cgigwpre.calendar.tencent.com",
            eventShare: "https://wtest.calendar.tencent.com/share-detail/invite/detail",
            inviteHost: "https://wtest.calendar.tencent.com",
            disabled: !1
        },
        testOnly: {
            key: "testOnly",
            name: "testOnly",
            httpCgi: "https://cgigwtest.calendar.tencent.com/stke90048env",
            eventShare: "https://wtest.calendar.tencent.com/share-detail/invite/detail",
            inviteHost: "https://wtest.calendar.tencent.com",
            disabled: !1
        }
    }
};

module.exports = a;