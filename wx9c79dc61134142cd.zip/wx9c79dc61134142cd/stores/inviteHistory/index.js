var t = require("../../@babel/runtime/helpers/createClass"), e = require("../../@babel/runtime/helpers/classCallCheck"), n = require("../../https/CGIClient"), i = new (t(function t() {
    var i = this;
    e(this, t), this.getFromRemote = function(t) {
        return i.pending || (i.pending = new Promise(function(e) {
            t ? n.get("/invite/v1/getDetailList?".concat(n.getReuqestCommonParams()), {
                data: {
                    status: 1,
                    limit: 10,
                    offset: 0
                }
            }).then(function(t) {
                var n = t.list;
                i.list = n || [], e(i.list);
            }) : e([]);
        })), i.pending;
    }, this.getData = function(t) {
        return new Promise(function(e) {
            0 === i.list.length ? i.getFromRemote(t).then(function(t) {
                return e(t);
            }) : e(i.list);
        });
    }, this.setCurrentInvite = function(t) {
        i.currentInvite = t, i.currentInvite.is_owner = !0;
    }, this.getCurrentInvite = function(t) {
        return i.currentInvite && i.currentInvite.id === t ? i.currentInvite : null;
    }, this.list = [], this.pending = null, this.currentInvite = null;
}))();

module.exports = i;