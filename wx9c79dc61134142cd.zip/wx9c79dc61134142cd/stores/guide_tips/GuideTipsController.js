var e = require("../../@babel/runtime/helpers/classCallCheck"), i = require("../../@babel/runtime/helpers/createClass"), t = require("../../utils/beacon/report_data"), a = require("../../sdk/logger/calendar_logger"), s = "GuideTipsController.js", n = function() {
    function n() {
        e(this, n), this.needGuideTips = !1, this.createGuideTipsShow = !1, this.detailGuideTipsShow = !1;
    }
    return i(n, [ {
        key: "setGuideListener",
        value: function() {
            var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {}, i = e.onCreateTipsStatus, t = e.onDetailTipsStatus;
            i && (this.onCreateTipsStatus = i), t && (this.onDetailTipsStatus = t);
        }
    }, {
        key: "notifyNeedGuideTips",
        value: function() {
            var e = this;
            this.needGuideTips = !0, this.showCreateTips().then(function() {
                e.showDetailTips();
            });
        }
    }, {
        key: "showCreateTips",
        value: function() {
            var e = this;
            return new Promise(function(i) {
                e.needGuideTips ? (e.callOnCreateTipsStatus(!0), e.tipsHideTimer = setTimeout(function() {
                    a.info("createTipsHideTimer timer out", s), e.callOnCreateTipsStatus(!1), t.dataReport("e#main#schedule_create_guidance#explore", {
                        disapear_type: "2"
                    }), i("");
                }, 8e3)) : a.info("showCreateTips but needGuideTips is false. Do not show.", s);
            });
        }
    }, {
        key: "showDetailTips",
        value: function() {
            var e = this;
            return new Promise(function(i) {
                e.needGuideTips ? e.detailTipsShowed ? a.info("showDetailTips but detailTipsShowed has been showed. Do not show.", s) : e.scheduleClicked ? a.info("showDetailTips but schedule has been clicked. Do not show.", s) : (e.callOnDetailTipsStatus(!0), 
                e.detailTipsShowed = !0, e.tipsHideTimer = setTimeout(function() {
                    a.info("onDetailTipsStatus timer out", s), e.callOnDetailTipsStatus(!1), t.dataReport("e#main#schedule_detail_guidance#explore", {
                        disapear_type: "2"
                    }), i("");
                }, 8e3)) : a.info("showDetailTips but needGuideTips is false. Do not show.", s);
            });
        }
    }, {
        key: "notifyCreateGuideTipsTab",
        value: function() {
            a.info("onCreateGuideTipsTab", s), clearTimeout(this.tipsHideTimer), this.callOnCreateTipsStatus(!1), 
            this.showDetailTips(), t.dataReport("e#main#schedule_create_guidance#explore", {
                disapear_type: "0"
            });
        }
    }, {
        key: "notifyDetailGuideTipsTab",
        value: function() {
            a.info("onDetailGuideTipsTab", s), clearTimeout(this.tipsHideTimer), this.callOnDetailTipsStatus(!1), 
            t.dataReport("e#main#schedule_detail_guidance#explore", {
                disapear_type: "0"
            });
        }
    }, {
        key: "notifyScheduleClick",
        value: function() {
            a.info("notifyScheduleClick", s), this.scheduleClicked = !0, this.detailGuideTipsShow && (t.dataReport("e#main#schedule_detail_guidance#explore", {
                disapear_type: "1"
            }), this.callOnDetailTipsStatus(!1), clearTimeout(this.tipsHideTimer));
        }
    }, {
        key: "notifyCreateBtnClick",
        value: function() {
            a.info("nofityCreateBtnClick", s), this.createBtnClicked = !0, this.createGuideTipsShow && (t.dataReport("e#main#schedule_create_guidance#explore", {
                disapear_type: "1"
            }), this.callOnCreateTipsStatus(!1), clearTimeout(this.tipsHideTimer));
        }
    }, {
        key: "notifyMainPageShow",
        value: function() {
            a.info("notifyMainPageShow", s), this.createBtnClicked && (this.showDetailTips(), 
            this.createBtnClicked = !1);
        }
    }, {
        key: "callOnCreateTipsStatus",
        value: function(e) {
            this.createGuideTipsShow = !!e, this.onCreateTipsStatus(!!e);
        }
    }, {
        key: "callOnDetailTipsStatus",
        value: function(e) {
            this.detailGuideTipsShow = !!e, this.onDetailTipsStatus(!!e);
        }
    } ], [ {
        key: "getInstance",
        value: function() {
            return void 0 === n.prototype.instance && (n.prototype.instance = new n()), n.prototype.instance;
        }
    } ]), n;
}();

module.exports = n;