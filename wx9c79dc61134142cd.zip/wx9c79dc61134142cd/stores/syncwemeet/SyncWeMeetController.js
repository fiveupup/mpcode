var e = require("../../@babel/runtime/helpers/classCallCheck"), n = require("../../@babel/runtime/helpers/createClass"), t = require("../../auth/AuthController"), i = require("../../sdk/logger/calendar_logger"), c = require("../guide_tips/GuideTipsController"), r = "SyncWeMeetController.js", o = function() {
    function o(n, t) {
        e(this, o), this.showSyncDialogFunc = n, this.onSyncWemeetStateChanged = t;
    }
    return n(o, [ {
        key: "checkShowSyncWemeet",
        value: function() {
            var e = this;
            t.getMeetingBindDetail().then(function(n) {
                i.info("checkShowSyncWemeet getMeetingBindDetail status: ".concat(n), r), 0 === n && e.showSyncDialogFunc.call();
            }).catch(function(e) {
                i.error("checkShowSyncWemeet getMeetingBindDetail error: ".concat(JSON.stringify(e)));
            });
        }
    }, {
        key: "onUserConfirmSync",
        value: function() {
            var e = this;
            t.setSyncMeeting(!0).then(function() {
                i.info("onUserConfirmSync suc.", r), e.onSyncWemeetStateChanged.call(), c.getInstance().notifyNeedGuideTips();
            }).catch(function() {
                i.error("onUserConfirmSync fail.", r);
            });
        }
    }, {
        key: "onUserDeniedSync",
        value: function() {
            var e = this;
            t.setSyncMeeting(!1).then(function() {
                i.info("onUserDeniedSync suc.", r), e.onSyncWemeetStateChanged.call(), c.getInstance().notifyNeedGuideTips();
            }).catch(function() {
                i.error("onUserDeniedSync fail.", r);
            });
        }
    } ]), o;
}();

module.exports = o;