var e = require("../@babel/runtime/helpers/objectSpread2"), t = require("../@babel/runtime/helpers/classCallCheck"), n = require("../@babel/runtime/helpers/createClass"), o = require("../@babel/runtime/helpers/possibleConstructorReturn"), i = require("../@babel/runtime/helpers/assertThisInitialized"), a = require("../@babel/runtime/helpers/inherits"), s = require("../@babel/runtime/helpers/createSuper");

console.log("UserStore.js loaded start");

var r = require("../utils/EventEmitter"), c = require("../utils/Dispatcher"), u = require("../constants/UserType"), h = require("../utils/util"), l = require("../constants/MultMediaState").AccessState, d = require("../sdk/logger/calendar_logger"), v = "UserStore.js", g = new (function(c) {
    a(C, r);
    var I = s(C);
    function C(e) {
        var n;
        return t(this, C), C.prototype.instance ? o(n, C.prototype.instance) : (n = I.call(this, e), 
        C.prototype.instance = i(n), n.init(), n);
    }
    return n(C, [ {
        key: "init",
        value: function() {
            this.registerAuthCode = "", this.setOpenID(""), this.unionId = "", this.userId = "", 
            this.registerState = 0, this.nickName = "", this.avatarUrl = "", this.area = "", 
            this.phone = "", this.appId = "", this.setCGIToken(""), this.cgiTokenEXP = "", this.userLoginSuc = !1, 
            this.avatarUrlTempSavePath = "", this.accountErrCode = 0, this.xmppLogin = !1, this.wxUserInfo = h.getValueFromLocalStorage("wx_user_info") || null, 
            this.unionIdEXP = 0, this.phoneCountryCode = "", this.phone = "", this.xmppToken = "", 
            this.xmppTokenEXP = 0, this.defaultNickname = "", this.iKnowToKeepInForeground = !1, 
            this.registerOrLoginAuthCode = "", this.isCorpUser = !1, this.accountList = [], 
            this.wemeetLoginInfo = null, this.wemeetLoginInfoEXP = 0, this.captchaSecondsLeft = 0, 
            this.captchaCountDownTimerID = 0, this.cameraAccessState = l.NeverAsk, this.microphoneAccessState = l.NeverAsk, 
            this.leaveReason = "", this.autoJoin = !1, this.prevSuccMeetingCode = "", this.isBindWX = !1;
        }
    }, {
        key: "initAccountInfo",
        value: function() {
            var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {}, t = e.openId, n = void 0 === t ? "" : t, o = e.unionId, i = void 0 === o ? "" : o, a = e.userId, s = void 0 === a ? "" : a, r = e.appId, c = void 0 === r ? "" : r, u = e.nickName, h = void 0 === u ? "" : u, l = e.avatarUrl, d = void 0 === l ? "" : l, v = e.area, g = void 0 === v ? "" : v, I = e.phone, C = void 0 === I ? "" : I, k = e.cgiToken, p = void 0 === k ? "" : k, E = e.cgiTokenEXP, _ = void 0 === E ? 0 : E;
            this.setOpenID(n), this.unionId = i, this.userId = s, this.appId = c, this.nickName = h, 
            this.avatarUrl = d, this.area = g, this.phone = C, this.setCGIToken(p), this.cgiTokenEXP = _, 
            this.handleDownloadAvatar();
        }
    }, {
        key: "setAvatarTempSavePath",
        value: function(e) {
            this.avatarUrlTempSavePath = e;
        }
    }, {
        key: "setOpenID",
        value: function() {
            var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : "";
            !this.openId || e ? this.openId = e : d.warn("FATAL ERROR: dangerous write! Ignored. openId set from ".concat(this.openId, " to ").concat(e, "."), v);
        }
    }, {
        key: "getOpenID",
        value: function() {
            return this.openId;
        }
    }, {
        key: "setUnionId",
        value: function() {
            var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : "";
            this.unionId = e;
        }
    }, {
        key: "setRegisterAuthCode",
        value: function() {
            var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : "";
            this.registerAuthCode = e;
        }
    }, {
        key: "setUnionIdEXP",
        value: function() {
            var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : 0;
            this.unionIdEXP = e;
        }
    }, {
        key: "getUnionId",
        value: function() {
            return this.unionId;
        }
    }, {
        key: "getUnionIdEXP",
        value: function() {
            return this.unionIdEXP;
        }
    }, {
        key: "setCGIToken",
        value: function() {
            var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : "";
            this.cgiToken && !e && d.warn("cgiToken changed to empty. call stack = ".concat(new Error("stack").stack), v), 
            this.cgiToken = e;
        }
    }, {
        key: "getCGIToken",
        value: function() {
            return this.cgiToken;
        }
    }, {
        key: "getCGITokenEXP",
        value: function() {
            return this.cgiTokenEXP;
        }
    }, {
        key: "getTicket",
        value: function() {
            var e = (this.wemeetLoginInfo || {}).activity_ticket;
            return void 0 === e ? "" : e;
        }
    }, {
        key: "setPhoneNum",
        value: function(e) {
            var t = e || {}, n = t.phone_number, o = void 0 === n ? "" : n, i = t.country_code, a = void 0 === i ? "86" : i;
            this.phone = o, this.phoneCountryCode = a;
        }
    }, {
        key: "getPhoneNum",
        value: function() {
            return this.phone;
        }
    }, {
        key: "getPhoneCountryCode",
        value: function() {
            return this.phoneCountryCode;
        }
    }, {
        key: "setXMPPToken",
        value: function() {
            var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : "";
            this.xmppToken = e;
        }
    }, {
        key: "getXMPPToken",
        value: function() {
            return this.xmppToken;
        }
    }, {
        key: "getXMPPTokenExp",
        value: function() {
            return this.xmppTokenEXP;
        }
    }, {
        key: "getDefaultNickName",
        value: function() {
            return this.defaultNickname;
        }
    }, {
        key: "getWXUserInfo",
        value: function() {
            return this.wxUserInfo;
        }
    }, {
        key: "setWXUserInfo",
        value: function() {
            var t = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : null;
            this.wxUserInfo = t;
            var n = h.getValueFromLocalStorage("wx_user_info"), o = e(e({}, n), t);
            h.setValueInLocalStorage("wx_user_info", o);
        }
    }, {
        key: "getIKnowToKeepInForeground",
        value: function() {
            return this.iKnowToKeepInForeground;
        }
    }, {
        key: "setIKnowToKeepInForeground",
        value: function(e) {
            this.iKnowToKeepInForeground = e, h.setValueInLocalStorage("iKnowToKeepInForeground", e);
        }
    }, {
        key: "setIsBindWX",
        value: function(e) {
            this.isBindWX = e;
        }
    }, {
        key: "getIsBindWX",
        value: function() {
            return this.isBindWX;
        }
    }, {
        key: "setRegisterOrLoginAuthCode",
        value: function(e) {
            this.registerOrLoginAuthCode = e;
        }
    }, {
        key: "getRegisterOrLoginAuthCode",
        value: function() {
            return this.registerOrLoginAuthCode;
        }
    }, {
        key: "clearRegisterOrLoginAuthCode",
        value: function() {
            this.setRegisterOrLoginAuthCode("");
        }
    }, {
        key: "setIsCorpUser",
        value: function(e) {
            this.isCorpUser = e;
        }
    }, {
        key: "getIsCorpUser",
        value: function() {
            return this.isCorpUser;
        }
    }, {
        key: "getWeMeetLoginToken",
        value: function() {
            var e = (this.wemeetLoginInfo || {}).wemeet_cgi_token;
            return void 0 === e ? "" : e;
        }
    }, {
        key: "setWeMeetLoginTokenEXP",
        value: function(e) {
            this.wemeetLoginInfoEXP = e;
        }
    }, {
        key: "getWeMeetLoginTokenEXP",
        value: function() {
            return this.wemeetLoginInfoEXP;
        }
    }, {
        key: "refreshWeMeetLoginInfo",
        value: function(e) {
            this.setWeMeetLoginInfo(e);
        }
    }, {
        key: "getUserID",
        value: function() {
            var e = (this.wemeetLoginInfo || {}).userid;
            return void 0 === e ? "" : e;
        }
    }, {
        key: "getAppID",
        value: function() {
            var e = (this.wemeetLoginInfo || {}).app_id;
            return void 0 === e ? "" : e;
        }
    }, {
        key: "setWeMeetLoginInfo",
        value: function(e) {
            this.wemeetLoginInfo = e;
        }
    }, {
        key: "getWeMeetLoginInfo",
        value: function() {
            return this.wemeetLoginInfo;
        }
    }, {
        key: "clearWeMeetLoginInfo",
        value: function() {
            this.wemeetLoginInfo = null, this.wemeetLoginInfoEXP = 0;
        }
    }, {
        key: "handleGetOpenUnionId",
        value: function() {
            var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {};
            d.info("handleGetOpenUnionId: ".concat(JSON.stringify(e)), v);
            var t = e || {}, n = t.openId, o = t.unionId;
            this.setOpenID(n), this.setUnionId(o);
        }
    }, {
        key: "handleGetIsRegister",
        value: function() {
            var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {};
            d.info("handleGetIsRegister: ".concat(JSON.stringify(e)), v);
            var t = e || {}, n = t.registerAuthCode, o = t.registerState;
            this.setRegisterAuthCode(n), this.registerState = o;
        }
    }, {
        key: "handleCalendarAuthCodeSucc",
        value: function() {
            var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {};
            d.info("handleCalendarAuthCodeSucc: ".concat(JSON.stringify(e)), v);
            var t = e || {}, n = t.userId, o = t.nickName, i = t.avatarUrl, a = t.area, s = t.phone, r = t.appId, c = t.cgiToken, u = t.cgiTokenEXP;
            this.userId = n, this.nickName = o, this.avatarUrl = i, this.area = a, this.phone = s, 
            this.appId = r, this.setCGIToken(c), this.cgiTokenEXP = u, this.handleDownloadAvatar();
        }
    }, {
        key: "handleUserLoginSuc",
        value: function() {
            this.registerState = 1, this.userLoginSuc = !0;
        }
    }, {
        key: "isLoginSuccess",
        value: function() {
            return 1 === this.registerState && !0 === this.userLoginSuc;
        }
    }, {
        key: "handleRefreshUserInfo",
        value: function() {
            var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {};
            d.info("handleRefreshUserInfo: ".concat(JSON.stringify(e)), v);
            var t = e || {}, n = t.nickName, o = t.avatarUrl, i = t.area, a = t.phone;
            this.nickName = n, this.avatarUrl = o, this.area = i, this.phone = a, this.handleDownloadAvatar();
        }
    }, {
        key: "handleCGILoginSucc",
        value: function() {
            var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {}, t = e.openId, n = void 0 === t ? this.openId : t, o = e.unionId, i = void 0 === o ? this.unionId : o, a = e.unionIdEXP, s = void 0 === a ? this.unionIdEXP : a, r = e.cgiToken, c = void 0 === r ? this.cgiToken : r, u = e.cgiExp, h = void 0 === u ? this.cgiTokenEXP : u;
            this.setOpenID(n), this.unionId = i, this.unionIdEXP = s, this.setCGIToken(c), this.cgiTokenEXP = h, 
            this.setAccountErrorCode(0);
        }
    }, {
        key: "handleCGILoginFail",
        value: function() {
            this.setOpenID(""), this.setCGIToken(""), this.cgiTokenEXP = "", this.unionIdEXP = "";
        }
    }, {
        key: "handleXMPPAccountInfoGetSucc",
        value: function() {
            var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {}, t = e.phoneNumber, n = e.xmppToken, o = e.xmppExp;
            this.phone = t, this.xmppToken = n, this.xmppTokenEXP = o;
        }
    }, {
        key: "handleXMPPAccountInfoGetFail",
        value: function() {
            this.phone = "", this.xmppToken = "", this.xmppTokenEXP = "";
        }
    }, {
        key: "handleXmppLoginSuccess",
        value: function() {
            this.xmppLogin = !0, this.setAccountErrorCode(0);
        }
    }, {
        key: "handleXmppLoginFail",
        value: function() {
            var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {}, t = e.code, n = void 0 === t ? "UNKNOWN" : t;
            this.xmppLogin = !1, this.setAccountErrorCode(n);
        }
    }, {
        key: "handleXMPPLogout",
        value: function(e, t) {
            this.xmppLogin = !1, e === u.XMPP_LOGOUT_ON_ABNORMAL_ACCOUNT ? this.setAccountErrorCode(-20001) : this.setAccountErrorCode(0);
            var n = "";
            switch (e) {
              case u.XMPP_LOGOUT_ON_POSITIVELY:
                n = "";
                break;

              case u.XMPP_LOGOUT_ON_ABNORMAL_NETWORK:
                n = "网络异常，如需加入会议，请退出并重新进入小程序";
                break;

              case u.XMPP_LOGOUT_ON_KICKED_BY_SAME_ACCOUNT:
                n = "您已在其它设备登录，当前设备已断开连接";
                break;

              case u.XMPP_LOGOUT_ON_ABNORMAL_ACCOUNT:
                n = "账号状态异常";
                break;

              case u.XMPP_LOGOUT_ON_OTHERS_SITUATION:
                n = "网络可能已断开";
                break;

              default:
                d.warn("Unhandled type ".concat(e, " at UserStore.handleXMPPLogout"), v);
            }
            var o = (t || {}).data, i = void 0 === o ? {} : o;
            this.emit(e, {
                data: {
                    ecode: i.ecode,
                    reason: n
                }
            }), g.setLeaveReason(n);
        }
    }, {
        key: "setAutoJoin",
        value: function(e) {
            this.autoJoin = e;
        }
    }, {
        key: "getAutoJoin",
        value: function() {
            return this.autoJoin;
        }
    }, {
        key: "setPrevSuccMeetingCode",
        value: function(e) {
            d.info("prevSuccMeetingCode changed from ".concat(this.prevSuccMeetingCode, " to ").concat(e), v), 
            this.prevSuccMeetingCode = e;
        }
    }, {
        key: "getPrevSuccMeetingCode",
        value: function() {
            return this.prevSuccMeetingCode;
        }
    }, {
        key: "setAccountErrorCode",
        value: function(e) {
            this.accountErrCode = e;
        }
    }, {
        key: "getAccountErroeCode",
        value: function() {
            return this.accountErrCode;
        }
    }, {
        key: "isAccountIllegal",
        value: function() {
            return -20001 === this.accountErrCode;
        }
    }, {
        key: "handleAccountListChange",
        value: function(e) {
            Array.isArray(e) ? this.accountList = e : console.error("'accountList' is supposed to be an array but got: ".concat(e));
        }
    }, {
        key: "getAccountList",
        value: function() {
            return this.accountList;
        }
    }, {
        key: "getAccountPicked",
        value: function() {
            if (!this.wemeetLoginInfo) return null;
            var e = "personnel";
            if (this.isCorpUser) {
                if (this.accountList.length < 1) return console.error("当前已登录，但是已绑定企业账号的用户却没有企业账号列表。"), 
                e;
                for (var t = 0, n = this.accountList.length; t < n; t++) if (this.accountList[t].corp_id === this.wemeetLoginInfo.app_id) {
                    e = this.accountList[t];
                    break;
                }
            }
            return e;
        }
    }, {
        key: "captchaCountDownStarted",
        value: function(e) {
            var t = this;
            d.info("captchaCountDownStarted", v), 0 < this.captchaCountDownTimerID && clearInterval(this.captchaCountDownTimerID), 
            this.captchaSecondsLeft = e, this.captchaCountDownChanged(this.captchaSecondsLeft), 
            this.captchaSecondsLeft -= 1, this.captchaCountDownTimerID = setInterval(function() {
                t.captchaCountDownChanged(t.captchaSecondsLeft), t.captchaSecondsLeft -= 1, t.captchaSecondsLeft < 0 && (t.captchaSecondsLeft = 0, 
                clearInterval(t.captchaCountDownTimerID));
            }, 1e3);
        }
    }, {
        key: "captchaCountDownChanged",
        value: function(e) {
            this.emit(u.WEMEET_ACCOUNT_REGISTER_CAPTCHA_COUNT_DOWN_CHANGE, e);
        }
    }, {
        key: "getCaptchaSecondsLeft",
        value: function() {
            return this.captchaSecondsLeft;
        }
    }, {
        key: "getCameraAccessState",
        value: function() {
            return this.cameraAccessState;
        }
    }, {
        key: "updateCameraAccessState",
        value: function(e) {
            this.cameraAccessState !== e && (h.clog.info("camera access state changed from ".concat(this.cameraAccessState, " to ").concat(e)), 
            this.cameraAccessState = e);
        }
    }, {
        key: "getMicrophoneAccessState",
        value: function() {
            return this.microphoneAccessState;
        }
    }, {
        key: "updateMicrophoneAccessState",
        value: function(e) {
            this.microphoneAccessState !== e && (h.clog.info("microphone access state changed from ".concat(this.microphoneAccessState, " to ").concat(e)), 
            this.microphoneAccessState = e);
        }
    }, {
        key: "setLeaveReason",
        value: function(e) {
            d.info("leaveReason changed from ".concat(this.leaveReason, " to ").concat(e, ".\n     stack: ").concat(new Error("why?").stack), v), 
            this.leaveReason = e, this.emit(u.LEAVE_MEETING_REASON_CHANGE, {
                data: e
            });
        }
    }, {
        key: "getLeaveReason",
        value: function() {
            return this.leaveReason;
        }
    }, {
        key: "onceEventListener",
        value: function(e) {
            var t = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : null;
            this.unsubscribe("CHANGE", e, t), this.subscribe("CHANGE", e, t);
        }
    }, {
        key: "addEventListener",
        value: function(e) {
            this.subscribe("CHANGE", e);
        }
    }, {
        key: "removeEventListener",
        value: function(e) {
            this.unsubscribe("CHANGE", e);
        }
    }, {
        key: "emit",
        value: function(e, t) {
            this.publish("CHANGE", e, t);
        }
    }, {
        key: "handleDownloadAvatar",
        value: function() {
            var e = this;
            new Promise(function(e, t) {
                wx.downloadFile({
                    url: g.avatarUrl,
                    success: function(t) {
                        e(t);
                    },
                    fail: function(e) {
                        t(e);
                    }
                });
            }).then(function(t) {
                200 === t.statusCode ? e.setAvatarTempSavePath(t.tempFilePath) : console.log("res", t);
            }).catch(function(e) {
                console.log("download avatar err", e);
            });
        }
    } ]), C;
}())();

c.register(function() {
    var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {}, t = e.type, n = e.payload;
    if (t) switch (t) {
      case u.ACCOUNT_INFO_INIT:
        g.initAccountInfo(n), g.emit(t, n);
        break;

      case u.GET_OPEN_UNION_ID:
        g.handleGetOpenUnionId(n), g.emit(t, n);
        break;

      case u.GET_IS_REGISTER:
        g.handleGetIsRegister(n), g.emit(t, n);
        break;

      case u.CALENDAR_AUTH_CODE_SUC:
        g.handleCalendarAuthCodeSucc(n), g.emit(t, n);
        break;

      case u.USER_LOGIN_SUC:
        g.handleUserLoginSuc(n), g.emit(t, n);
        break;

      case u.REFRESH_USER_INFO:
        g.handleRefreshUserInfo(n), g.emit(t, n);
        break;

      case u.CGI_LOGIN_SUCC:
        g.handleCGILoginSucc(n), g.emit(t, n);
        break;

      case u.CGI_LOGIN_FAIL:
        g.handleCGILoginFail(n), g.emit(t, n);
        break;

      case u.XMPP_ACCOUNT_INFO_GET_SUCC:
        g.handleXMPPAccountInfoGetSucc(n), g.emit(t, n);
        break;

      case u.XMPP_ACCOUNT_INFO_GET_FAIL:
        g.handleXMPPAccountInfoGetFail(n), g.emit(t, n);
        break;

      case u.ACCOUNT_ERROR_CODE_CHANGE:
        g.setAccountErrorCode(n);
        break;

      case u.OPENID_CHANGE:
        g.setOpenID(n);
        break;

      case u.UNIONID_CHANGE:
        g.setUnionId(n);
        break;

      case u.UNIONIDEXP_CHANGE:
        g.setUnionIdEXP(n);
        break;

      case u.PHONE_NUM_CHANGE:
        g.setPhoneNum(n), g.emit(t, n);
        break;

      case u.CGI_TOKEN_CHANGE:
        g.setCGIToken(n);
        break;

      case u.XMPP_TOKEN_CHANGE:
        g.setXMPPToken(n);
        break;

      case u.XMPP_LOGIN_SUCC:
        g.handleXmppLoginSuccess(), g.emit(t, n);
        break;

      case u.XMPP_LOGIN_FAIL:
        g.handleXmppLoginFail(n.data), g.emit(t, n);
        break;

      case u.XMPP_LOGOUT_ON_POSITIVELY:
      case u.XMPP_LOGOUT_ON_ABNORMAL_NETWORK:
      case u.XMPP_LOGOUT_ON_KICKED_BY_SAME_ACCOUNT:
      case u.XMPP_LOGOUT_ON_ABNORMAL_ACCOUNT:
      case u.XMPP_LOGOUT_ON_OTHERS_SITUATION:
        g.handleXMPPLogout(t, n);
        break;

      case u.WEMEET_REGISTER_OR_LOGIN_AUTH_CODE_CHANGE:
        g.setRegisterOrLoginAuthCode(n);
        break;

      case u.WEMEET_REGISTER_OR_LOGIN_BIND_WX_CHANGE:
        g.setIsBindWX(n);
        break;

      case u.WEMEET_IS_CORP_USER_CHANGE:
        g.setIsCorpUser(n);
        break;

      case u.WEMEET_ACCOUNT_LIST_CHANGE:
        g.handleAccountListChange(n), g.emit(t, n);
        break;

      case u.WEMEET_ACCOUNT_LOGIN_SUCC:
        g.setWeMeetLoginInfo(n), g.emit(t, n);
        break;

      case u.WEMEET_ACCOUNT_LOGOUT_SUCC:
        g.clearWeMeetLoginInfo(n), g.emit(t, n);
        break;

      case u.AUTH_CODE_FOR_REGISTER_GOT:
        g.setRegisterOrLoginAuthCode(n), g.emit(t, n);
        break;

      case u.USER_BIND_WX_CHANGE:
        g.setIsBindWX(n), g.emit(t, n);
        break;

      case u.WEMEET_LOGIN_INFO_EXP_CHANG:
        g.setWeMeetLoginTokenEXP(n);
        break;

      case u.WEMEET_ACCOUNT_LOGIN_INFO_REFRESHED:
        g.refreshWeMeetLoginInfo(n), g.emit(t, n);
        break;

      case u.WEMEET_ACCOUNT_REGISTER_CAPTCHA_COUNT_DOWN_START:
        g.captchaCountDownStarted(n);
        break;

      case u.WEMEET_ACCOUNT_REGISTER_CAPTCHA_COUNT_DOWN_CHANGE:
        g.captchaCountDownChanged(n);
        break;

      case u.WEMEET_ACCOUNT_REGISTER_SUCC:
        g.emit(t, n);
        break;

      case u.WX_USER_INFO_CHANGE:
        g.setWXUserInfo(n.data);
        break;

      case u.CAMERA_ACCESS_STATE_CHANGE:
        g.updateCameraAccessState(n);
        break;

      case u.MICROPHONE_ACCESS_STATE_CHANGE:
        g.updateMicrophoneAccessState(n);
    }
}), console.log("UserStore.js loaded end"), module.exports = g;