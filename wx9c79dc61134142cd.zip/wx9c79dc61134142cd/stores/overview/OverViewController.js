var e = require("../../@babel/runtime/helpers/classCallCheck"), t = require("../../@babel/runtime/helpers/createClass"), r = require("@tencent/calendar-js-sdk"), i = r.CalendarSDK, n = r.DayOverView, o = require("../calendarinfo/CalendarInfoController.js"), a = require("../../sdk/logger/calendar_logger"), l = require("../CalendarStore"), h = "OverViewController.js", u = function() {
    function r() {
        e(this, r), this.overViewCache = [], this.overViewRequestArr = [], this.needReload = !1;
    }
    return t(r, [ {
        key: "reload",
        value: function() {
            this.overViewCache = [], this.overViewRequestArr.length > 0 ? (this.needReload = !0, 
            a.infoAll("needReload mark", h)) : a.infoAll("needReload pass", h);
        }
    }, {
        key: "getScheduleOverViewOneDay",
        value: function(e) {
            var t = new Date(e), r = this.formatTime(new Date(t.getFullYear(), t.getMonth(), t.getDate()).getTime()), i = this.overViewCache[r];
            if (void 0 === i) {
                var o = new Date(t.getFullYear(), t.getMonth() - 1, 1).getTime(), u = new Date(t.getFullYear(), t.getMonth() + 2, 0).getTime();
                return this.getScheduleOverViewRemote(l.getOverviewEventTypeArr(), o, u).then(function(e) {
                    for (var t, i = 0; i < e.length; i++) {
                        var o = e[i];
                        if (o.day === r) {
                            t = o;
                            break;
                        }
                    }
                    return void 0 === t && ((t = new n()).day = r), a.infoAll("getScheduleOverViewOneDay from remote ".concat(JSON.stringify(t)), h), 
                    Promise.resolve(t);
                });
            }
            return a.infoAll("getScheduleOverViewOneDay hit cache ".concat(JSON.stringify(i)), h), 
            Promise.resolve(i);
        }
    }, {
        key: "getScheduleOverViewThreeMonth",
        value: function(e) {
            for (var t = new Date(e), r = new Date(t.getFullYear(), t.getMonth() - 1, 1).getTime(), i = new Date(t.getFullYear(), t.getMonth() + 2, 0).getTime(), n = new Date(r), o = new Date(i), u = [], c = !1; n.getTime() <= o.getTime(); ) {
                var s = this.formatTime(n.getTime()), v = this.overViewCache[s];
                if (void 0 === v) {
                    c = !0;
                    break;
                }
                u.push(v), n.setDate(n.getDate() + 1);
            }
            return c ? (a.infoAll("getScheduleOverViewThreeMonth from remote", h), this.getScheduleOverViewRemote(l.getOverviewEventTypeArr(), r, i)) : (a.infoAll("getScheduleOverViewThreeMonth hit cache", h), 
            Promise.resolve(u));
        }
    }, {
        key: "getScheduleOverViewRemote",
        value: function(e, t, r) {
            var i = this, o = this.getOverViewRequest(this.overViewRequestArr, t, r);
            return void 0 !== o ? (a.infoAll("getScheduleOverViewRemote is loading", h), new Promise(function(e, t) {
                o.resolveCacheArr.push(e), o.rejectCacheArr.push(t);
            })) : (this.overViewRequestArr.push(new c(t, r)), a.infoAll("getScheduleOverViewRemote exeucte", h), 
            this.getScheduleOverViewRemoteWithReload(e, t, r).then(function(e) {
                a.infoAll("getScheduleOverViewRemote success", h);
                var o = new Date(t), l = new Date(r);
                for (i.checkCacheSize(); o.getTime() <= l.getTime(); ) {
                    var u = i.formatTime(o.getTime()), c = new n();
                    c.day = u;
                    for (var s = 0; s < e.length; s++) {
                        var v = e[s];
                        if (v instanceof n && v.day === u) {
                            c = v;
                            break;
                        }
                    }
                    c.time = o.getTime(), delete i.overViewCache[u], i.overViewCache[u] = c, o.setDate(o.getDate() + 1);
                }
                var g = i.getOverViewRequest(i.overViewRequestArr, t, r);
                return void 0 !== g && (g.resolveCacheArr.forEach(function(t) {
                    t(e);
                }), i.deleteOverViewRequest(i.overViewRequestArr, t, r)), Promise.resolve(e);
            }).catch(function(e) {
                a.infoAll("getScheduleOverViewRemote failed", h);
                var n = i.getOverViewRequest(i.overViewRequestArr, t, r);
                return void 0 !== n && (n.rejectCacheArr.forEach(function(t) {
                    t(e);
                }), i.deleteOverViewRequest(i.overViewRequestArr, t, r)), Promise.reject(e);
            }));
        }
    }, {
        key: "getScheduleOverViewRemoteWithReload",
        value: function(e, t, r) {
            var n = this;
            return o.getInstance().getSelectedCalendarInfoList().then(function(n) {
                return i.getInstance().getScheduleOverView(n, e, t, r);
            }).then(function(i) {
                return n.needReload ? (n.needReload = !1, a.infoAll("getScheduleOverViewRemoteWithReload needReload", h), 
                n.getScheduleOverViewRemoteWithReload(e, t, r)) : Promise.resolve(i);
            }).catch(function(e) {
                return n.needReload = !1, Promise.reject(e);
            });
        }
    }, {
        key: "getOverViewRequest",
        value: function(e, t, r) {
            for (var i, n = 0; n < e.length; n++) {
                var o = e[n];
                if (o.startTime === t && o.endTime === r) {
                    i = o;
                    break;
                }
            }
            return i;
        }
    }, {
        key: "deleteOverViewRequest",
        value: function(e, t, r) {
            for (var i = 0; i < e.length; i++) {
                var n = e[i];
                if (n.startTime === t && n.endTime === r) {
                    e.splice(i, 1);
                    break;
                }
            }
        }
    }, {
        key: "checkCacheSize",
        value: function() {
            var e = this, t = Object.keys(this.overViewCache).length;
            t > 365 && Object.keys(this.overViewCache).slice(180, t).forEach(function(t) {
                delete e.overViewCache[t];
            });
        }
    }, {
        key: "formatTime",
        value: function(e) {
            var t = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : "Y-M-D";
            function r(e) {
                var t = e.toString();
                return t[1] ? t : "0".concat(t);
            }
            function i(e, t) {
                var i = [ "Y", "M", "D", "h", "m", "s" ], n = [], o = new Date(e), a = t;
                n.push(o.getFullYear()), n.push(r(o.getMonth() + 1)), n.push(r(o.getDate())), n.push(r(o.getHours())), 
                n.push(r(o.getMinutes())), n.push(r(o.getSeconds()));
                for (var l = 0; l < n.length; l++) {
                    var h = n[l], u = i[l];
                    a = a.replace(u, h);
                }
                return a;
            }
            return i(e, t);
        }
    } ], [ {
        key: "getInstance",
        value: function() {
            return void 0 === r.prototype.instance && (r.prototype.instance = new r()), r.prototype.instance;
        }
    } ]), r;
}(), c = t(function t(r, i) {
    e(this, t), this.startTime = r, this.endTime = i, this.resolveCacheArr = [], this.rejectCacheArr = [];
});

module.exports = u;