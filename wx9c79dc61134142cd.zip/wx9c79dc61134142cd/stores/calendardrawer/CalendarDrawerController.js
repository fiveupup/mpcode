var e = require("../../@babel/runtime/helpers/classCallCheck"), o = require("../../@babel/runtime/helpers/createClass"), r = require("../../utils/util"), t = (require("../../sdk/logger/calendar_logger"), 
require("../calendarinfo/CalendarInfoController"), require("@tencent/calendar-js-sdk").CalendarSDK), n = require("../../stores/UserStore"), a = function() {
    function a() {
        e(this, a);
    }
    return o(a, [ {
        key: "createInviteData",
        value: function() {
            return 2 === n.registerState || !1 === n.userLoginSuc ? Promise.resolve({
                inviteNums: "暂无新回复",
                showInviteRedDot: !1,
                showInviteNums: !1,
                showInviteNews: !1
            }) : t.getInstance().getNewInvitationReplyCnt().then(function(e) {
                var o = !1, t = !1, n = !1, a = "暂无新内容", i = e, s = r.getValueFromLocalStorage("hadClickInviteItem"), c = r.getValueFromLocalStorage("hadClickDrawerInviteItem");
                return s ? (!c || i > 0) && (t = !0) : (o = !0, n = !1), o || (n = !0, i > 0 && (a = i > 99 ? "99+条新回复" : "".concat(i, "条新回复"))), 
                Promise.resolve({
                    inviteNums: a,
                    showInviteRedDot: t,
                    showInviteNums: n,
                    showInviteNew: o
                });
            }).catch(function(e) {
                return console.log("createInviteData err:", e), {
                    inviteNums: "暂无新内容",
                    showInviteRedDot: !1,
                    showInviteNums: !0,
                    showInviteNew: !1
                };
            });
        }
    }, {
        key: "createBookingData",
        value: function(e) {
            return 2 === n.registerState || !1 === n.userLoginSuc ? Promise.resolve({
                bookingNums: "暂无新内容",
                showBookingRedDot: !1,
                showBookingNums: !0,
                showBookingNew: !1
            }) : (console.log("createBookingData", e), t.getInstance().getNewAppointReplyCnt().then(function(e) {
                var o = !1, t = !1, n = !1, a = "暂无新内容", i = e, s = r.getValueFromLocalStorage("hadClickAppointItem"), c = r.getValueFromLocalStorage("hadClickDrawerAppointItem");
                return s ? (!c || i > 0) && (t = !0) : (o = !0, n = !1), o || (n = !0, i > 0 && (a = i > 99 ? "99+条新预约" : "".concat(i, "条新预约"))), 
                Promise.resolve({
                    bookingNums: a,
                    showBookingRedDot: t,
                    showBookingNums: n,
                    showBookingNew: o
                });
            }).catch(function(e) {
                return console.log("createBookingData err:", e), {
                    bookingNums: "暂无新内容",
                    showBookingRedDot: !1,
                    showBookingNums: !0,
                    showBookingNew: !1
                };
            }));
        }
    }, {
        key: "createDrawerData",
        value: function() {
            return 2 === n.registerState ? Promise.resolve({
                isRegister: !1
            }) : !1 === n.userLoginSuc ? Promise.resolve({}) : Promise.resolve({
                isRegister: !0,
                headIcon: n.avatarUrl,
                phoneNum: r.toNotSensePhoneNum(n.phone),
                nickName: n.nickName
            });
        }
    }, {
        key: "createUserInfo",
        value: function() {
            return 2 === n.registerState ? Promise.resolve({
                isRegister: !1
            }) : !1 === n.userLoginSuc ? Promise.resolve({}) : Promise.resolve({
                isRegister: !0,
                headIcon: n.avatarUrl,
                phoneNum: r.toNotSensePhoneNum(n.phone),
                nickName: n.nickName
            });
        }
    }, {
        key: "getDisplayCalendarList",
        value: function(e) {
            var o = !(arguments.length > 1 && void 0 !== arguments[1]) || arguments[1], r = [], t = [];
            Object.keys(e).forEach(function(o) {
                var n = e[o];
                if ("10000" !== n.calendarId && "10001" !== n.calendarId) {
                    var a = n.fgColor, i = 9 === a.length ? a.substring(0, n.fgColor.length - 2) : a, s = i;
                    i && 7 === i.length && (s = "rgba(" + parseInt("0x" + i.slice(1, 3)) + "," + parseInt("0x" + i.slice(3, 5)) + "," + parseInt("0x" + i.slice(5, 7)) + ",1)");
                    var c = {
                        corpId: n.corpId || "common",
                        calendarId: n.calendarId,
                        calendarUid: n.calendarUid,
                        weMeetUid: n.weMeetUid,
                        color: n.bgColor,
                        borderColor: s,
                        calName: n.summary,
                        isSelect: n.isSelected,
                        calType: n.calType,
                        isDefault: n.isDefault,
                        operation: n.operation,
                        accessRole: n.accessRole
                    };
                    n.corpId ? r.push(c) : t.push(c);
                }
            });
            var n = [];
            return r.length && n.push({
                groupName: "我的日历",
                accountCalList: r
            }), o && t.length && n.push({
                groupName: "订阅日历",
                accountCalList: t
            }), n;
        }
    }, {
        key: "changeCalendarSelectState",
        value: function(e) {
            var o = [ {
                id: e.calendarId,
                corp_id: "common" === e.corpId ? n.appId : e.corpId,
                cal_uid: "" === e.calendarUid ? n.userId : e.calendarUid,
                is_selected: e.isSelect ? 0 : 1
            } ];
            return t.getInstance().updateCalendarInfos(o);
        }
    } ]), a;
}();

module.exports = a;