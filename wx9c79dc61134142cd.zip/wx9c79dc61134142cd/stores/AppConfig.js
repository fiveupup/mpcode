var e = require("../@babel/runtime/helpers/interopRequireDefault").default;

Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.refreshConfig = void 0;

var r = require("../@babel/runtime/helpers/objectSpread2"), t = e(require("./UserStore")), i = e(require("../constants/UserType")), a = e(require("../https/CGIClient"));

t.default.addEventListener(function(e) {
    e === i.default.USER_LOGIN_SUC && (console.log("login success call refresh"), d());
});

var d = exports.refreshConfig = function() {
    if (t.default.isLoginSuccess()) {
        var e = {
            config_key_list: [ "server.default_remind_time", "server.default_remind_end_time", "server.allday_remind_time", "week_start", "show_holiday", "show_lunar", "show_weather", "calendar.shared.custom.color", "server.timepicker.default_interval" ]
        };
        a.default.post("/calendar/v1/viewConfig/query?".concat(a.default.getReuqestCommonParams(e)), {
            data: e
        }).then(function(e) {
            console.log("go_view_config", e.params);
            var t = r({}, e.params || {});
            t.default_remind_time = void 0 === t["server.default_remind_time"] ? "15" : t["server.default_remind_time"], 
            t.allday_remind_time = void 0 === t["server.allday_remind_time"] ? "-480" : t["server.allday_remind_time"], 
            t.default_remind_end_time = void 0 === t["server.default_remind_end_time"] ? "" : t["server.default_remind_end_time"], 
            delete t["server.default_remind_time"], delete t["server.allday_remind_time"], delete t["server.default_remind_end_time"], 
            wx.setStorage({
                key: "view_config",
                data: t
            });
        }).catch(function(e) {
            console.error("go_view_config", e);
        });
    }
};