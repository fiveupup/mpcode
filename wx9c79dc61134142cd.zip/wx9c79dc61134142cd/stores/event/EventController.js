var e = require("../../@babel/runtime/helpers/slicedToArray"), t = require("../../@babel/runtime/helpers/classCallCheck"), n = require("../../@babel/runtime/helpers/createClass"), r = require("@tencent/calendar-js-sdk"), i = r.CalendarSDK, a = r.EventInfo, o = require("../calendarinfo/CalendarInfoController.js"), s = require("../overview/OverViewController.js"), c = require("../../sdk/logger/calendar_logger"), f = require("../CalendarStore"), l = require("../../https/CGIClient"), u = require("../../utils/EventEmitter"), v = "EventController.js", h = function() {
    function r() {
        t(this, r), this.eventListCache = {}, this.preEndTime = -1, this.nextEndTime = -1, 
        this.requestByOffsetArr = [], this.requestByDayArr = [], this.needReloadByOffset = !1, 
        this.needReloadByDay = !1, this.eventEmitter = new u();
    }
    return n(r, [ {
        key: "reload",
        value: function() {
            this.eventListCache = {}, this.preEndTime = -1, this.nextEndTime = -1, this.reloadFlag = !0;
            var e = this.requestByOffsetArr.length > 0, t = this.requestByDayArr.length > 0;
            e ? (this.needReloadByOffset = !0, c.infoAll("needReloadByOffset mark ", v)) : c.infoAll("needReloadByOffset pass ", v), 
            t ? (this.needReloadByDay = !0, c.infoAll("needReloadByDay mark ", v)) : c.infoAll("needReloadByDay pass ", v);
        }
    }, {
        key: "getEventListByOffset",
        value: function(e) {
            var t = new Date(e), n = new Date(t.getFullYear(), t.getMonth(), t.getDate()), r = n.getTime(), i = Object.keys(this.eventListCache), a = -1, o = -1;
            i.forEach(function(e) {
                a = -1 === a ? e : Math.min(a, e), o = -1 === o ? e : Math.max(o, e);
            });
            var s = e >= a && e <= o, l = -1 !== this.preEndTime && e < this.preEndTime || -1 !== this.nextEndTime && e > this.nextEndTime;
            return s || l ? (c.infoAll("getEventListByOffset hit cache range but need confirm count for ".concat(JSON.stringify(n)), v), 
            this.confirmCacheEventCount(r)) : (c.infoAll("getEventListByOffset out of cache range for ".concat(JSON.stringify(n)), v), 
            this.getEventListByOffsetWithReload(f.getListEventTypeArr(), r));
        }
    }, {
        key: "confirmCacheEventCount",
        value: function(e) {
            var t = this;
            c.infoAll("confirmCacheEventCount start for ".concat(new Date(e).toLocaleDateString()), v);
            var n = [];
            return n.push(e - 864e5), n.push(e), n.push(e + 864e5), this.getScheduleOverViewThreeDay(n).then(function(r) {
                for (var i = t.readEventListFromCacheThreedDay(e), a = [], o = 0; o < r.length; o++) {
                    var s = n[o], l = i[o].eventList.length, u = r[o].eventCount - (!0 === r[o].isOffDuty ? 1 : 0) - (!0 === r[o].isOnDuty ? 1 : 0);
                    l < u ? (c.infoAll("cache=".concat(l, " mismatch expect=").concat(u, " for ").concat(new Date(s).toLocaleDateString()), v), 
                    a.push(t.getEventListByDayWithReload(f.getListEventTypeArr(), s))) : c.infoAll("cache=".concat(l, " match expect=").concat(u, " for ").concat(new Date(s).toLocaleDateString()), v);
                }
                if (a.length > 0) {
                    if (t.reloadFlag) return t.reloadFlag = !1, Promise.all(a).then(function() {
                        return t.readEventListFromCacheThreedDay(e);
                    });
                    Promise.all(a).then(function() {
                        return t.readEventListFromCacheThreedDay(e);
                    }).then(function() {
                        t.eventEmitter.publish("event_list_change", {
                            reload: t.reloadFlag,
                            time: e
                        });
                    });
                }
                return i;
            });
        }
    }, {
        key: "getScheduleOverViewThreeDay",
        value: function(e) {
            var t = [];
            return e.forEach(function(e) {
                t.push(s.getInstance().getScheduleOverViewOneDay(e));
            }), Promise.all(t);
        }
    }, {
        key: "getEventListByOffsetWithReload",
        value: function(e, t) {
            var n = this;
            return this.getEventListByOffsetInner(e, t).then(function(r) {
                return n.needReloadByOffset ? (n.needReloadByOffset = !1, c.infoAll("getEventListByOffsetWithReload need realod", v), 
                n.getEventListByOffsetWithReload(e, t)) : (n.writeEventListToCache(r), n.confirmCacheEventCount(t));
            }).catch(function(e) {
                return n.needReloadByOffset = !1, Promise.reject(e);
            });
        }
    }, {
        key: "getEventListByOffsetInner",
        value: function(e, t) {
            var n = this, r = this.getEventRequest(this.requestByOffsetArr, t);
            return void 0 !== r ? (c.infoAll("getEventListByOffsetInner is loading for ".concat(new Date(t).toLocaleDateString()), v), 
            new Promise(function(e, t) {
                r.resolveCacheArr.push(e), r.rejectCacheArr.push(t);
            })) : (this.requestByOffsetArr.push(new y(t)), c.infoAll("getEventListByOffsetInner execute for ".concat(new Date(t).toLocaleDateString()), v), 
            o.getInstance().getSelectedCalendarInfoList().then(function(r) {
                var i = n.getEventListByOffsetDirection(r, e, t, 0, [], !1), a = n.getEventListByOffsetDirection(r, e, t, 0, [], !0);
                return Promise.all([ i, a ]).then(function(e) {
                    var r = [];
                    e.forEach(function(e) {
                        r = r.concat(e);
                    }), c.infoAll("getEventListByOffsetInner suc for ".concat(new Date(t).toLocaleDateString()), v);
                    var i = n.getEventRequest(n.requestByOffsetArr, t);
                    return void 0 !== i && (i.resolveCacheArr.forEach(function(e) {
                        e(r);
                    }), n.deleteEventRequest(n.requestByOffsetArr, t)), Promise.resolve(r);
                }).catch(function(e) {
                    c.infoAll("getEventListByOffsetInner failed for ".concat(new Date(t).toLocaleDateString()), v);
                    var r = n.getEventRequest(n.requestByOffsetArr, t);
                    return void 0 !== r && (r.rejectCacheArr.forEach(function(t) {
                        t(e);
                    }), n.deleteEventRequest(n.requestByOffsetArr, t)), Promise.reject(e);
                });
            }).catch(function(e) {
                c.infoAll("getEventListByOffsetInner failed for ".concat(new Date(t).toLocaleDateString()), v);
                var r = n.getEventRequest(n.requestByOffsetArr, t);
                return void 0 !== r && (r.rejectCacheArr.forEach(function(t) {
                    t(e);
                }), n.deleteEventRequest(n.requestByOffsetArr, t)), Promise.reject(e);
            }));
        }
    }, {
        key: "getEventListByDayWithReload",
        value: function(e, t) {
            var n = this;
            return this.getEventListByDayInner(e, t).then(function(r) {
                if (n.needReloadByDay) return n.needReloadByDay = !1, c.infoAll("getEventListByDayWithReload needReloadByDay for ".concat(new Date(t).toLocaleDateString()), v), 
                n.getEventListByDayWithReload(e, t);
                n.writeEventListToCache(r);
                var i = n.readEventListFromCacheThreedDay(t);
                return Promise.resolve(i);
            }).catch(function(e) {
                return n.needReloadByDay = !1, Promise.reject(e);
            });
        }
    }, {
        key: "getEventListByDayInner",
        value: function(e, t) {
            var n = this, r = this.getEventRequest(this.requestByDayArr, t);
            return void 0 !== r ? (c.infoAll("getEventListByDayInner is loading for ".concat(new Date(t).toLocaleDateString()), v), 
            new Promise(function(e, t) {
                r.resolveCacheArr.push(e), r.rejectCacheArr.push(t);
            })) : (this.requestByDayArr.push(new y(t)), c.infoAll("getEventListByDayInner execute for ".concat(new Date(t).toLocaleDateString()), v), 
            o.getInstance().getSelectedCalendarInfoList().then(function(r) {
                return n.getEventListByDayDirection(r, e, t, 0, []);
            }).then(function(e) {
                c.infoAll("getEventListByDayInner success for ".concat(new Date(t).toLocaleDateString()), v);
                var r = n.getEventRequest(n.requestByDayArr, t);
                return void 0 !== r && (r.resolveCacheArr.forEach(function(t) {
                    t(e);
                }), n.deleteEventRequest(n.requestByDayArr, t)), Promise.resolve(e);
            }).catch(function(e) {
                c.infoAll("getEventListByDayInner failed for ".concat(new Date(t).toLocaleDateString()), v);
                var r = n.getEventRequest(n.requestByDayArr, t);
                return void 0 !== r && (r.rejectCacheArr.forEach(function(t) {
                    t(e);
                }), n.deleteEventRequest(n.requestByDayArr, t)), Promise.reject(e);
            }));
        }
    }, {
        key: "getEventListByDayDirection",
        value: function(e, t, n, r, a) {
            var o = this;
            return c.infoAll("getEventListByDayDirection excute for ".concat(new Date(n).toLocaleDateString(), ", offset=").concat(r), v), 
            i.getInstance().getEventListByDay(e, t, n, r, 100).then(function(t) {
                if (c.infoAll("getEventListByDayDirection success for ".concat(new Date(n).toLocaleDateString(), ", offset=").concat(r), v), 
                t.length < 100) return Promise.resolve(a.concat(t));
                c.infoAll("getEventListByDayDirection result length larger than 100, continute", v);
                var i = r + 100;
                return o.getEventListByDayInner(e, n, i, a.concat(t));
            });
        }
    }, {
        key: "getEventListByOffsetDirection",
        value: function(t, n, r, o, s, f) {
            var l, u = this;
            return l = f ? i.getInstance().getEventListByOffset(t, n, r, o, 100, !1) : i.getInstance().getEventListByOffset(t, n, r - 1, o, 100, !0), 
            c.infoAll("getEventListByOffsetDir exc ".concat(new Date(r).toLocaleDateString(), ", offset=").concat(o, " isNext=").concat(f), v), 
            l.then(function(n) {
                c.infoAll("getEventListByOffsetDir suc ".concat(new Date(r).toLocaleDateString(), ", offset=").concat(o, " isNext=").concat(f), v);
                var i = 0, l = n.filter(function(e) {
                    return "0" === e.eventId || 1 !== e.isPeriod || (i += 1, c.infoAll("getEventListByOffsetDirect filter recurring event=".concat(JSON.stringify(e)), v), 
                    !1);
                });
                if (l.sort(function(e, t) {
                    return e.startTime - t.startTime;
                }), l.length < 100 - i) {
                    if (f) {
                        var h = l[l.length - 1];
                        u.nextEndTime = void 0 !== h ? h.startTime : r, c.infoAll("getEventListByOffsetDirect no more, nextEndDay=".concat(new Date(u.nextEndTime).toLocaleDateString()), v);
                    } else {
                        var y = e(l, 1)[0];
                        u.preEndTime = void 0 !== y ? y.startTime : r, c.infoAll("getEventListByOffsetDirect no more, preEndDay=".concat(new Date(u.preEndTime).toLocaleDateString()), v);
                    }
                    return Promise.resolve(s.concat(l));
                }
                if (o >= 200) return c.infoAll("getEventListByOffsetDirect over 200 limit, break", v), 
                Promise.resolve(s.concat(l));
                var g = !1;
                if (f) {
                    var d = l[l.length - 1], D = r + 172800;
                    g = d instanceof a && d.startTime < D;
                } else {
                    var E = e(l, 1)[0], m = r - 86400;
                    g = E instanceof a && E.startTime > m;
                }
                if (g) {
                    c.infoAll("getEventListByOffsetDirect has more, continute", v);
                    var L = o + 100;
                    return u.getEventListByOffsetDirection(t, r, L, s.concat(l), f);
                }
                return c.infoAll("getEventListByOffsetDirect return normally", v), Promise.resolve(s.concat(l));
            });
        }
    }, {
        key: "writeEventListToCache",
        value: function(e) {
            var t = this;
            e.forEach(function(e) {
                for (var n = new Date(e.startTime), r = new Date(n.getFullYear(), n.getMonth(), n.getDate()), i = new Date(e.endTime), a = (new Date(i.getFullYear(), i.getMonth(), i.getDate()).getTime() - r.getTime()) / 864e5, o = 0; o <= a; o++) {
                    var s = r.getTime(), f = void 0;
                    f = 0 === o ? n.getHours() : 0;
                    var l = t.eventListCache[s];
                    void 0 === l && (l = {});
                    var u = l[f];
                    if (void 0 === u && (u = []), r.setDate(r.getDate() + 1), u.length > 62) c.warnAll("writeEventListToCache abandon because over size ".concat(JSON.stringify(e)), v); else u.some(function(t) {
                        return e.calendarId === t.calendarId && e.eventId === t.eventId && e.parentEventId === t.parentEventId;
                    }) || (u.push(e), l[f] = u, t.eventListCache[s] = l);
                }
            });
        }
    }, {
        key: "readEventListFromCacheThreedDay",
        value: function(e) {
            var t = this, n = [], r = [];
            return r.push(e - 864e5), r.push(e), r.push(e + 864e5), r.forEach(function(e) {
                var r = t.eventListCache[e];
                void 0 === r && (r = {});
                var i = [];
                Object.keys(r).forEach(function(e) {
                    i = i.concat(r[e]);
                }), i.sort(function(e, t) {
                    return e.startTime !== t.startTime ? e.startTime - t.startTime : e.endTime !== t.endTime ? e.endTime - t.endTime : e.updateTime - t.updateTime;
                }), n.push({
                    dayTime: e,
                    eventList: i
                });
            }), n;
        }
    }, {
        key: "getEventRequest",
        value: function(e, t) {
            for (var n, r = 0; r < e.length; r++) {
                var i = e[r];
                if (i.startTime === t) {
                    n = i;
                    break;
                }
            }
            return n;
        }
    }, {
        key: "deleteEventRequest",
        value: function(e, t) {
            for (var n = 0; n < e.length; n++) {
                if (e[n].startTime === t) {
                    e.splice(n, 1);
                    break;
                }
            }
        }
    }, {
        key: "getEventListByReferTime",
        value: function(e) {
            return l.post("/calendar/v1/getCalendarEventListByReferTime?".concat(l.getReuqestCommonParams()), {
                data: e
            });
        }
    } ], [ {
        key: "getInstance",
        value: function() {
            return void 0 === r.prototype.instance && (r.prototype.instance = new r()), r.prototype.instance;
        }
    } ]), r;
}(), y = n(function e(n) {
    t(this, e), this.startTime = n, this.resolveCacheArr = [], this.rejectCacheArr = [];
});

module.exports = h;