var e = require("../@babel/runtime/helpers/classCallCheck"), t = require("../@babel/runtime/helpers/createClass"), n = require("../@babel/runtime/helpers/possibleConstructorReturn"), r = require("../@babel/runtime/helpers/assertThisInitialized"), a = require("../@babel/runtime/helpers/inherits"), s = require("../@babel/runtime/helpers/createSuper");

console.log("AppStore.js loaded start");

var i = require("../utils/EventEmitter"), o = require("../utils/Dispatcher"), u = require("../constants/AppType"), c = require("../configs/AppConfig"), h = require("../utils/util"), p = require("../utils/base64.js").Base64, l = require("../sdk/logger/calendar_logger"), v = c.DEFAULT_ENV_KEY, y = c.MaxCustomerDataLength, f = new (function(o) {
    a(m, i);
    var f = s(m);
    function m(t) {
        var a;
        return e(this, m), m.prototype.instance ? n(a, m.prototype.instance) : (a = f.call(this, t), 
        m.prototype.instance = r(a), a.init(), a);
    }
    return t(m, [ {
        key: "init",
        value: function() {
            this.sysInfo = {}, this.isQYWX = !1, this.QYWXVersion = "", this.weChatVer = "", 
            this.isSupportDevice = !1, this.canOpenApp = !1, this.isAndroid = !1, this.isIPhoneX = !1, 
            this.statusBarHeight = 0, this.isForeground = null, this.customerDataCache = {
                meetingID: "",
                customerData: ""
            }, this.enableEnvSwitch = c.ENV_SWITCH_ENABLE, this.envMap = c.ENV_LIST, this.currEnvKey = c.ENV_LIST[v].key, 
            this.initCustomerDataCache();
        }
    }, {
        key: "getSysInfo",
        value: function() {
            return this.sysInfo;
        }
    }, {
        key: "setSysInfo",
        value: function(e) {
            if (e) {
                var t = e.sysInfo, n = e.isSupportDevice;
                this.sysInfo = t, this.isQYWX = "wxwork" === t.environment, this.weChatVer = t.version, 
                this.isSupportDevice = n;
                try {
                    this.isAndroid = t.platform.toLowerCase().indexOf("android") >= 0, this.isIPhoneX = t.model.indexOf("iPhone X") > -1 || t.model.indexOf("iPhone12") > -1;
                } catch (e) {
                    l.error("sysInfo exception: ".concat(JSON.stringify(e)));
                }
                this.statusBarHeight = t.statusBarHeight;
            }
        }
    }, {
        key: "setQYWXVersion",
        value: function() {
            var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : "";
            this.QYWXVersion = e;
        }
    }, {
        key: "getQYWXVersion",
        value: function() {
            return this.QYWXVersion;
        }
    }, {
        key: "getWeChatVersion",
        value: function() {
            return this.weChatVer;
        }
    }, {
        key: "isSupportQYWX",
        value: function() {
            return h.isSupportQYWX(this.QYWXVersion);
        }
    }, {
        key: "getPlatform",
        value: function() {
            return this.sysInfo && this.sysInfo.platform ? this.sysInfo.platform.toLowerCase() : "unknown";
        }
    }, {
        key: "getIsQYWX",
        value: function() {
            return this.isQYWX;
        }
    }, {
        key: "getIsSupportDevice",
        value: function() {
            return this.isSupportDevice;
        }
    }, {
        key: "isAndroid",
        value: function() {
            return this.isAndroid;
        }
    }, {
        key: "isIPhoneX",
        value: function() {
            return this.isIPhoneX;
        }
    }, {
        key: "isDevtools",
        value: function() {
            var e = !1;
            try {
                e = "devtools" === this.sysInfo.platform.toLowerCase();
            } catch (t) {
                l.error("isDevTools exception: ".concat(JSON.stringify(t))), e = !1;
            }
            return e;
        }
    }, {
        key: "setCanOpenApp",
        value: function(e) {
            this.canOpenApp = e;
        }
    }, {
        key: "getCanOpenApp",
        value: function() {
            return this.canOpenApp;
        }
    }, {
        key: "getStatusBarHeight",
        value: function() {
            return this.statusBarHeight;
        }
    }, {
        key: "getEnvSwitchEnable",
        value: function() {
            return this.enableEnvSwitch;
        }
    }, {
        key: "getCurrEnv",
        value: function() {
            var e = this.envMap[this.currEnvKey];
            return e || (l.warn("".concat(this.currEnvKey, "环境不存在，使用默认环境: ").concat(v)), e = c.ENV_LIST[v]), 
            e;
        }
    }, {
        key: "setCurrEnvKey",
        value: function() {
            var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : c.ENV_LIST[v].key;
            if (!this.envMap[e]) return l.warn("".concat(e, "环境不存在，设置成默认环境: ").concat(v)), void (this.currEnvKey = this.envMap[v].key);
            this.currEnvKey = e;
        }
    }, {
        key: "getEnvMap",
        value: function() {
            return this.envMap;
        }
    }, {
        key: "getSignUrl",
        value: function() {
            return this.getCurrEnv().signurl;
        }
    }, {
        key: "getMicUrl",
        value: function() {
            return this.getCurrEnv().micurl;
        }
    }, {
        key: "getXMPPWSUrl",
        value: function() {
            return this.getCurrEnv().srvurl;
        }
    }, {
        key: "getHttpCgi",
        value: function() {
            return this.getCurrEnv().httpCgi;
        }
    }, {
        key: "getSdkAppId",
        value: function() {
            return this.getCurrEnv().sdkappid;
        }
    }, {
        key: "getEnvName",
        value: function() {
            return this.getCurrEnv().name;
        }
    }, {
        key: "isRunningForeground",
        value: function() {
            return !0 === this.isForeground;
        }
    }, {
        key: "isRunningBackground",
        value: function() {
            return !1 === this.isForeground;
        }
    }, {
        key: "setIsRunningForeground",
        value: function(e) {
            var t = this.isRunningBackground() && !0 === e, n = this.isRunningForeground() && !1 === e;
            t || n ? l.info("switched to ".concat(t ? "foreground" : "background")) : l.info("may be this is the first time that App launched? prev = ".concat(this.isForeground, ", curr = ").concat(e)), 
            this.isForeground = e, t ? this.emit(u.APP_SWITCH_TO_FOREGROUND, {}) : this.emit(u.APP_SWITCH_TO_BACKGROUND, {});
        }
    }, {
        key: "isCustomerDataValid",
        value: function(e) {
            if (!e) return !1;
            var t = null;
            try {
                t = JSON.parse(p.decode(e));
            } catch (t) {
                return l.error("Base64 decode/JSON parse error on 3rd party 'customerData'.\n        errmsg = ".concat(t.message, "\n        customerData = ").concat(e, "\n      ")), 
                !1;
            }
            return y < e.length ? (l.warn("3rd party passed 'customerData' too long: ".concat(e.length, "\n        Max length is ").concat(y, "\n        'customerData': ").concat(JSON.stringify(e), "\n      ")), 
            !1) : Object.prototype.hasOwnProperty.call(t, "ver") ? h.isVersion(t.ver) ? Object.prototype.hasOwnProperty.call(t, "userData") ? (l.info("3rd party 'customerData' set succeed. 'customerData'(decoded) is: ".concat(JSON.stringify(t))), 
            !0) : (l.warn("'userData' is expected to be a property of 'customerData'(decoded): ".concat(JSON.stringify(t))), 
            !1) : (l.warn("'ver' is expected to be a version format string like(x.x), but got(decoded): ".concat(t.ver, ".\n        'customerData': ").concat(JSON.stringify(t))), 
            !1) : (l.warn("'ver' is expected to be a property of 'customerData'(decoded): ".concat(JSON.stringify(t))), 
            !1);
        }
    }, {
        key: "setCustomerData",
        value: function(e) {
            e && !this.isCustomerDataValid(e) || (this.customerDataCache.customerData = e, this.customerDataCache.meetingID = "");
        }
    }, {
        key: "getCustomerDataFor",
        value: function(e) {
            return this.hasCustomerData() ? this.hasCustomerDataFor(e) ? this.getCustomerData() : this.customerDataCache.meetingID ? "" : (this.setCustomerDataFor(e), 
            this.getCustomerData()) : (l.info("没有customerData"), "");
        }
    }, {
        key: "getCustomerData",
        value: function() {
            return this.customerDataCache.customerData;
        }
    }, {
        key: "hasCustomerData",
        value: function() {
            return !!this.customerDataCache.customerData;
        }
    }, {
        key: "hasCustomerDataFor",
        value: function(e) {
            var t = this.customerDataCache.meetingID, n = this.customerDataCache.customerData;
            return !(!t || !n) && (e === t || (l.info("we have customerData saved for meetingID '".concat(t, "', but not for '").concat(e, "'")), 
            !1));
        }
    }, {
        key: "setCustomerDataFor",
        value: function(e) {
            this.customerDataCache.customerData ? (this.customerDataCache.meetingID = e, l.info("meetingID(".concat(e, ") now has a associated customerData.")), 
            h.setValueInLocalStorage("customer_data", this.customerDataCache)) : l.warn("It is supposed to have customerData set firstly before setting meetingID: ".concat(e));
        }
    }, {
        key: "initCustomerDataCache",
        value: function() {
            var e = h.getValueFromLocalStorage("customer_data");
            e && (this.customerDataCache = e, l.info("read 'customer_data' from localStorage succeed: ".concat(JSON.stringify(e))));
        }
    }, {
        key: "onAppOnShow",
        value: function(e) {
            this.setIsRunningForeground(!0);
            var t = e.scene, n = this.getEventNameByScene(t);
            if (l.info("app show with scene: ".concat(t, "(").concat(n, ").\n      res: ").concat(JSON.stringify(e), "\n    ")), 
            this.updateAbilityToOpenApp(t), 1167 === t) {
                var r = (e || {}).query, a = void 0 === r ? {} : r;
                this.setCustomerData(a.customerData || null);
            }
        }
    }, {
        key: "onAppOnHide",
        value: function() {
            this.setIsRunningForeground(!1);
        }
    }, {
        key: "getEventNameByScene",
        value: function(e) {
            var t = "";
            switch (e) {
              case 1001:
                t = "open_mp_by_main_port_of_discover";
                break;

              case 1005:
                t = "open_mp_by_search";
                break;

              case 1089:
                t = "open_mp_by_recently_used";
                break;

              case 1036:
                t = "open_mp_by_share_card_from_app";
                break;

              case 1007:
                t = "open_mp_by_share_card_from_mp";
                break;

              case 1037:
                t = "open_mp_by_another_mp";
                break;

              case 1048:
                t = "open_mp_by_longpress_on_mp_code";
                break;

              case 1131:
                t = "open_mp_by_popup_window";
                break;

              case 1167:
                t = "open_mp_by_h5";
                break;

              default:
                t = "";
            }
            return t;
        }
    }, {
        key: "getBeaconData",
        value: function(e) {
            var t = {};
            switch (e.scene) {
              case 1037:
                var n = e.query || {}, r = e.referrerInfo || {};
                t = {
                    chn: n.chn || "",
                    appId: r.appId || ""
                };
            }
            return t;
        }
    }, {
        key: "updateAbilityToOpenApp",
        value: function(e) {
            if (1069 === e || 1036 === e) {
                this.setCanOpenApp(!0);
                var t = this.getSysInfo();
                1069 === e && !h.compareVersion(t.SDKVersion, "2.5.1") >= 0 && (this.setCanOpenApp(!1), 
                console.warn("mp sdk is less than 2.5.1, 1069 wont be saved. so we just make it unabled to open App"));
            } else 1089 === e || 1090 === e || 1038 === e ? this.getCanOpenApp() : this.setCanOpenApp(!1);
        }
    }, {
        key: "onceEventListener",
        value: function(e) {
            this.unsubscribe("CHANGE", e), this.subscribe("CHANGE", e);
        }
    }, {
        key: "addEventListener",
        value: function(e) {
            this.subscribe("CHANGE", e);
        }
    }, {
        key: "removeEventListener",
        value: function(e) {
            this.unsubscribe("CHANGE", e);
        }
    }, {
        key: "emit",
        value: function(e, t) {
            this.publish("CHANGE", e, t);
        }
    } ]), m;
}())();

o.register(function() {
    var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {}, t = e.type, n = e.payload;
    if (t) switch (t) {
      case u.INIT_SYSTEM_INFO_SUCC:
        var r = n || {}, a = r.data, s = void 0 === a ? {} : a;
        f.setSysInfo(s), f.emit(t, n);
        break;

      case u.INIT_SYSTEM_INFO_FAIL:
        f.setSysInfo({});
        break;

      case u.QYWX_VERSION_CHANGE:
        var i = n.data;
        f.setQYWXVersion(i);
        break;

      case u.CURR_ENV_CHANGE:
        f.setCurrEnvKey(n), f.emit(t, n);
    }
}), console.log("AppStore.js loaded end"), module.exports = f;