var e = require("../@babel/runtime/helpers/classCallCheck"), t = require("../@babel/runtime/helpers/createClass"), i = new (function() {
    function i() {
        if (e(this, i), i.prototype.instance) return i.prototype.instance;
        i.prototype.instance = this;
    }
    return t(i, [ {
        key: "init",
        value: function() {
            this.INVITE_H5 = !1, this.ENV_CHANGE = !1;
        }
    }, {
        key: "resetInvite",
        value: function() {
            this.INVITE_H5 = !this.INVITE_H5;
        }
    }, {
        key: "resetEnvSwitch",
        value: function() {
            this.ENV_CHANGE = !this.ENV_CHANGE;
        }
    } ]), i;
}())();

module.exports = i;