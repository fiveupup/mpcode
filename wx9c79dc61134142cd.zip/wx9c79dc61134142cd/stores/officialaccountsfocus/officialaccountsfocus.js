var e = require("../../@babel/runtime/helpers/classCallCheck"), t = require("../../@babel/runtime/helpers/createClass"), c = require("../../@babel/runtime/helpers/possibleConstructorReturn"), o = require("../../@babel/runtime/helpers/assertThisInitialized"), a = require("../../@babel/runtime/helpers/inherits"), i = require("../../@babel/runtime/helpers/createSuper");

console.log("CalendarStore.js loaded start");

var s = require("../../utils/EventEmitter"), u = require("../../utils/util"), r = require("@tencent/calendar-js-sdk").CalendarSDK, n = require("../UserStore"), l = function(l) {
    a(F, s);
    var f = i(F);
    function F() {
        var t;
        return e(this, F), F.prototype.instance ? c(t, F.prototype.instance) : (t = f.call(this), 
        F.prototype.instance = o(t), t.init(), t);
    }
    return t(F, [ {
        key: "init",
        value: function() {
            var e = u.getValueFromLocalStorage("had_focus_official_accounts");
            console.log("OfficialAccountsFocus init hadFocusOfficialAccounts: ".concat(e)), 
            this.hadFocusOfficialAccount = e || !1, this.getFocusStateFromServer();
        }
    }, {
        key: "getFocusStateFromServer",
        value: function() {
            var e = this;
            n.isLoginSuccess() && r.getInstance().queryPublicAccountSubscribeStatus().then(function(t) {
                console.log("getFocusStateFromServer res: ".concat(t.status)), u.setValueInLocalStorage("had_focus_official_accounts", 2 === t.status), 
                e.hadFocusOfficialAccount = 2 === t.status, e.emit("OFFICIAL_ACCOUNTS_FOFUCS_CHANGE", {
                    focus: 2 === t.status
                });
            }).catch(function(e) {
                console.log("getFocusStateFromServer err", e);
            });
        }
    }, {
        key: "getHadFocusOfficialAccount",
        value: function() {
            return this.hadFocusOfficialAccount;
        }
    }, {
        key: "getNeedShowOfficialAccountDialog",
        value: function() {
            console.log("getNeedShowOfficialAccountDialog hadFocusOfficialAccount:", this.hadFocusOfficialAccount);
            var e = u.getValueFromLocalStorage("create_event_times");
            return e ? e += 1 : e = 1, u.setValueInLocalStorage("create_event_times", e), !1 === this.hadFocusOfficialAccount ? e % 3 == 1 : (u.setValueInLocalStorage("create_event_times", 0), 
            !1);
        }
    }, {
        key: "handleShowOfficialAccountDialog",
        value: function() {
            var e = u.getValueFromLocalStorage("show_official_accounts_times");
            console.log("handleShowOfficialAccountDialog times:", e), e ? u.setValueInLocalStorage("show_official_accounts_times", e + 1) : u.setValueInLocalStorage("show_official_accounts_times", 1);
        }
    }, {
        key: "addEventListener",
        value: function(e) {
            this.subscribe("OFFICIAL_ACCOUNTS_FOFUCS_CHANGE", e);
        }
    }, {
        key: "removeEventListener",
        value: function(e) {
            this.unsubscribe("OFFICIAL_ACCOUNTS_FOFUCS_CHANGE", e);
        }
    }, {
        key: "emit",
        value: function(e, t) {
            this.publish("OFFICIAL_ACCOUNTS_FOFUCS_CHANGE", e, t);
        }
    } ]), F;
}();

console.log("OfficialAccountsFocus.js loaded end"), module.exports = {
    OfficialAccountsFocus: new l(),
    OFFICIAL_ACCOUNTS_FOFUCS_CHANGE: "OFFICIAL_ACCOUNTS_FOFUCS_CHANGE"
};