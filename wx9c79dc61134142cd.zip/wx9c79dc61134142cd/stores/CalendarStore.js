var e = require("../@babel/runtime/helpers/classCallCheck"), r = require("../@babel/runtime/helpers/createClass"), t = require("../@babel/runtime/helpers/possibleConstructorReturn"), i = require("../@babel/runtime/helpers/assertThisInitialized"), n = require("../@babel/runtime/helpers/inherits"), s = require("../@babel/runtime/helpers/createSuper");

console.log("CalendarStore.js loaded start");

var o = require("../sdk/logger/calendar_logger"), v = require("../utils/EventEmitter"), a = "CalendarStore.js", l = new (function(l) {
    n(p, v);
    var u = s(p);
    function p() {
        var r;
        return e(this, p), p.prototype.instance ? t(r, p.prototype.instance) : (r = u.call(this), 
        p.prototype.instance = i(r), r.init(), r);
    }
    return r(p, [ {
        key: "init",
        value: function() {
            this.overviewEventTypeArr = [ 0, 1, 2, 3, 4, 5 ], this.listEventTypeArr = [ 0, 1, 2, 3 ];
        }
    }, {
        key: "removeWeMeetFromOverviewTypeArr",
        value: function() {
            for (var e = -1, r = 0; r < this.overviewEventTypeArr.length; r++) if (1 === this.overviewEventTypeArr[r]) {
                e = r, o.info("removeWeMeetFromOverviewTypeArr target is ".concat(e), a);
                break;
            }
            -1 !== e && this.overviewEventTypeArr.splice(e, 1), o.info("removeWeMeetFromOverviewTypeArr result: ".concat(JSON.stringify(this.overviewEventTypeArr)), a);
        }
    }, {
        key: "removeWeMeetFromListTypeArr",
        value: function() {
            for (var e = -1, r = 0; r < this.listEventTypeArr.length; r++) if (1 === this.listEventTypeArr[r]) {
                e = r, o.info("removeWeMeetFromListTypeArr target is ".concat(e), a);
                break;
            }
            -1 !== e && this.listEventTypeArr.splice(e, 1), o.info("removeWeMeetFromListTypeArr result: ".concat(JSON.stringify(this.listEventTypeArr)), a);
        }
    }, {
        key: "addWeMeetToOverViewTypeArr",
        value: function() {
            for (var e = !1, r = 0; r < this.overviewEventTypeArr.length; r++) 1 === this.overviewEventTypeArr[r] && (e = !0);
            e || (this.overviewEventTypeArr.push(1), o.info("addWeMeetToOverViewTypeArr wemeet type not found. then add.", a)), 
            o.info("addWeMeetToOverViewTypeArr result: ".concat(JSON.stringify(this.overviewEventTypeArr)), a);
        }
    }, {
        key: "addWeMeetToListTypeArr",
        value: function() {
            for (var e = !1, r = 0; r < this.listEventTypeArr.length; r++) 1 === this.listEventTypeArr[r] && (e = !0);
            e || (this.listEventTypeArr.push(1), o.info("addWeMeetToListTypeArr wemeet type not found. then add.", a)), 
            o.info("addWeMeetToListTypeArr result: ".concat(JSON.stringify(this.listEventTypeArr)), a);
        }
    }, {
        key: "getOverviewEventTypeArr",
        value: function() {
            return this.overviewEventTypeArr;
        }
    }, {
        key: "getListEventTypeArr",
        value: function() {
            return this.listEventTypeArr;
        }
    }, {
        key: "addEventListener",
        value: function(e) {
            this.subscribe("CHANGE", e);
        }
    }, {
        key: "removeEventListener",
        value: function(e) {
            this.unsubscribe("CHANGE", e);
        }
    }, {
        key: "emit",
        value: function(e, r) {
            this.publish("CHANGE", e, r);
        }
    } ]), p;
}())();

console.log("CalendarStore.js loaded end"), module.exports = l;