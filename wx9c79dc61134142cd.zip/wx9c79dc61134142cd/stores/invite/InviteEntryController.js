require("../../@babel/runtime/helpers/Objectvalues");

var e = require("../../@babel/runtime/helpers/classCallCheck"), t = require("../../@babel/runtime/helpers/createClass"), i = require("../../@babel/runtime/helpers/possibleConstructorReturn"), n = require("../../@babel/runtime/helpers/assertThisInitialized"), o = require("../../@babel/runtime/helpers/inherits"), a = require("../../@babel/runtime/helpers/createSuper"), r = require("../../auth/AuthController"), c = require("../../utils/util"), l = require("../../sdk/logger/calendar_logger"), u = require("../../utils/EventEmitter"), s = "InviteEntryController.js", v = require("../../configs/AppConfig"), E = v.DEFAULT_ENV_KEY, S = function(S) {
    o(g, u);
    var _ = a(g);
    function g() {
        var t;
        return e(this, g), g.prototype.instance ? i(t, g.prototype.instance) : ((t = _.call(this)).init(), 
        g.prototype.instance = n(t), t);
    }
    return t(g, [ {
        key: "init",
        value: function() {
            this.rediretUrl = "".concat(v.ENV_LIST[E].inviteHost, "/share-detail/mini-program-login");
        }
    }, {
        key: "addEventListener",
        value: function(e) {
            this.subscribe("CHANGE", e);
        }
    }, {
        key: "removeEventListener",
        value: function(e) {
            this.unsubscribe("CHANGE", e);
        }
    }, {
        key: "emit",
        value: function(e, t) {
            this.publish("CHANGE", e, t);
        }
    }, {
        key: "navigateToInviteCreate",
        value: function() {
            c.setValueInLocalStorage("hadClickInviteItem", !0);
            var e = "".concat(v.ENV_LIST[E].inviteHost, "/invite/create");
            this.navigateToH5(e);
        }
    }, {
        key: "navigateToBookingCreate",
        value: function() {
            c.setValueInLocalStorage("hadClickAppointItem", !0);
            var e = "".concat(v.ENV_LIST[E].bookingHost, "/invite/create");
            this.navigateToH5(e);
        }
    }, {
        key: "navigateToInviteHistory",
        value: function() {
            var e = "".concat(v.ENV_LIST[E].inviteHost, "/invite/history-invite");
            this.navigateToH5(e);
        }
    }, {
        key: "navigateToBookingHistory",
        value: function() {
            var e = "".concat(v.ENV_LIST[E].bookingHost, "/invite/service_booking/offerList");
            this.navigateToH5(e);
        }
    }, {
        key: "navigateToH5",
        value: function(e) {
            this.doRedirectNavigate(e);
        }
    }, {
        key: "isWebTokenNotExp",
        value: function() {
            var e = c.getValueFromLocalStorage("invite_login_time");
            if ("" !== e) {
                l.info("isWebTokenNotExp inviteLoginTime: ".concat(this.fomateTime(e)), s);
                var t = new Date().getTime(), i = t - e;
                return l.info("isWebTokenNotExp curTime: ".concat(this.fomateTime(t), ", deltaTime: ").concat(i, ", tokenVaildTime: ").concat(25e8), s), 
                i < 25e8;
            }
            return !1;
        }
    }, {
        key: "clearWebToken",
        value: function() {
            l.info("clearWebToken", s), c.setValueInLocalStorage("invite_login_time", "");
        }
    }, {
        key: "fomateTime",
        value: function(e) {
            return c.formatDate("YYYY-mm-dd HH:MM:SS", new Date(e));
        }
    }, {
        key: "doDirectNavigate",
        value: function(e) {
            l.info("doDirectNavigate", s), c.navigateToH5(e);
        }
    }, {
        key: "doRedirectNavigate",
        value: function(e) {
            var t = this;
            l.info("doRedirectNavigate", s), r.getTmpTokenForH5().then(function(i) {
                l.info("doRedirectNavigate tmpToken: ".concat(i), s);
                var n = "".concat(t.rediretUrl, "?token=").concat(i, "&url=").concat(encodeURIComponent(e));
                l.info("doRedirectNavigate url: ".concat(n), s), c.navigateToH5(n);
            }).catch(function(e) {
                l.info("doRedirectNavigate error: ".concat(JSON.stringify(e)), s);
            });
        }
    }, {
        key: "onRecieveWebPostMessage",
        value: function(e) {
            var t = this;
            l.info("onRecieveWebPostMessage dataList: ".concat(JSON.stringify(e)), s), Object.values(e).forEach(function(e) {
                l.info("data from web: ".concat(JSON.stringify(e)), s), "WEB_LOGIN_SUCCESS" === e.type && t.handleWebLoginSuccess(), 
                "WEB_INVITE_SUCCESS" === e.type && t.emit("WEB_INVITE_SUCCESS", {}), "WEB_CREATE_EVENT_SUCCESS" === e.type && t.emit("WEB_CREATE_EVENT_SUCCESS", e.value), 
                "WEB_BOOKING_CREATE_SUCCESS" === e.type && t.emit("WEB_BOOKING_CREATE_SUCCESS", {});
            });
        }
    }, {
        key: "handleWebLoginSuccess",
        value: function() {
            var e = c.getValueFromLocalStorage("invite_login_time");
            if ("" === e) {
                var t = new Date().getTime();
                l.infoAll("set invite_login_time as ".concat(t, ", ").concat(this.fomateTime(t)), s), 
                c.setValueInLocalStorage("invite_login_time", t);
            } else l.info("invite_login_time not null: ".concat(e, ". Ignore."), s);
        }
    } ]), g;
}();

module.exports = {
    InviteEntryController: new S(),
    WEB_LOGIN_SUCCESS: "WEB_LOGIN_SUCCESS",
    WEB_INVITE_SUCCESS: "WEB_INVITE_SUCCESS",
    WEB_CREATE_EVENT_SUCCESS: "WEB_CREATE_EVENT_SUCCESS",
    WEB_BOOKING_CREATE_SUCCESS: "WEB_BOOKING_CREATE_SUCCESS"
};