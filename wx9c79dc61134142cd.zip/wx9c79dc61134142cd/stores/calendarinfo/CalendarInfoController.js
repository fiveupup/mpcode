var e = require("../../@babel/runtime/helpers/slicedToArray");

require("../../@babel/runtime/helpers/Objectvalues");

var r = require("../../@babel/runtime/helpers/classCallCheck"), n = require("../../@babel/runtime/helpers/createClass"), a = require("@tencent/calendar-js-sdk"), t = a.CalendarSDK, o = a.CalendarInfo, l = require("../../sdk/logger/calendar_logger"), i = require("../../utils/util"), c = require("../CalendarStore"), s = require("../../https/CGIClient"), d = "CalendarInfoController.js", f = function() {
    function a() {
        r(this, a), this.loading = !1, this.needReload = !1, this.calendarInfoArrCache = [], 
        this.resolveArrCache = [], this.rejectArrCache = [];
    }
    return n(a, [ {
        key: "reload",
        value: function() {
            if (!this.loading) return this.calendarInfoArrCache = [], void l.infoAll("reload pass", d);
            this.needReload = !0, l.infoAll("reload mark", d);
        }
    }, {
        key: "getCalendarInfoList",
        value: function() {
            var e = this;
            return this.loading ? (l.infoAll("getCalendarInfoList is loading", d), new Promise(function(r, n) {
                e.resolveArrCache.push(r), e.rejectArrCache.push(n);
            })) : void 0 !== this.calendarInfoArrCache && this.calendarInfoArrCache.length > 0 ? (l.infoAll("getCalendarInfoList hit cache", d), 
            Promise.resolve(this.calendarInfoArrCache)) : (l.infoAll("getCalendarInfoList excute", d), 
            this.loading = !0, this.getCalendarInfoListWithReload().then(function(r) {
                return l.infoAll("getCalendarInfoList success", d), e.loading = !1, e.calendarInfoArrCache = r, 
                e.resolveArrCache.forEach(function(e) {
                    e(r);
                }), e.resolveArrCache.splice(0, e.resolveArrCache.length), Promise.resolve(r);
            }).catch(function(r) {
                return l.infoAll("getCalendarInfoList failed", d), e.loading = !1, e.rejectArrCache.forEach(function(e) {
                    e(r);
                }), e.rejectArrCache.splice(0, e.rejectArrCache.length), Promise.reject(r);
            }));
        }
    }, {
        key: "getCalendarInfoListWithReload",
        value: function() {
            var r = this;
            return t.getInstance().getCalendarInfoList({}, {
                interface_version: 1
            }).then(function(e) {
                l.info("getCalendarInfoListWithReload then: ".concat(JSON.stringify(e)), d);
                var r = -1;
                return Object.values(e.syncInfo).forEach(function(e) {
                    1 === e.type && (r = e.status);
                }), l.infoAll("getCalendarInfoListWithReload status: ".concat(r), d), 0 === r ? (l.info("remove wemeet event type.", d), 
                c.removeWeMeetFromListTypeArr(), c.removeWeMeetFromOverviewTypeArr()) : (l.info("add wemeet event type.", d), 
                c.addWeMeetToListTypeArr(), c.addWeMeetToOverViewTypeArr()), e;
            }).then(function(r) {
                l.info("getCalendarInfoListWithReload data: ".concat(JSON.stringify(r)), d);
                var n = r, a = [ [ "#0E62FF", "#A4D0FF99" ], [ "#00B996", "#83E6D399" ], [ "#FF5A43", "#FFAF9F99" ], [ "#FF9922", "#FBC99199" ], [ "#009EB9", "#68CDD999" ], [ "#837FED", "#B3B1FF99" ], [ "#E86AB9", "#FFA7DE99" ], [ "#F15E65", "#FCA8AC99" ] ], t = 0;
                return Object.keys(n.calendarList).forEach(function(r) {
                    if ("" === n.calendarList[r].fgColor || "" === n.calendarList[r].bgColor) {
                        var o = e(a[t], 2);
                        n.calendarList[r].fgColor = o[0], n.calendarList[r].bgColor = o[1], l.info("use hardcode color => index: ".concat(r, ",\n              fgColor: ").concat(n.calendarList[r].fgColor, ", bgColor: ").concat(n.calendarList[r].bgColor), d), 
                        t += 1;
                    } else {
                        l.info("remote raw color => index: ".concat(r, ",\n              fgColor: ").concat(n.calendarList[r].fgColor, ", bgColor: ").concat(n.calendarList[r].bgColor), d);
                        var c = i.argbTorgba(n.calendarList[r].fgColor), s = i.argbTorgba(n.calendarList[r].bgColor);
                        n.calendarList[r].fgColor = i.formatRgba(c), n.calendarList[r].bgColor = i.formatRgba(s);
                    }
                }), n;
            }).then(function(e) {
                if (r.needReload) return l.infoAll("getCalendarInfoListWithReload needReload", d), 
                r.needReload = !1, r.getCalendarInfoListWithReload();
                var n = e.calendarList;
                return Promise.resolve(n);
            }).catch(function(e) {
                return r.needReload = !1, l.info("SDK getCalendarInfoList error: ".concat(JSON.stringify(e)), d), 
                Promise.reject(e);
            });
        }
    }, {
        key: "getCalendarInfoById",
        value: function(e) {
            var r = this, n = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : 0;
            return new Promise(function(a, t) {
                r.getCalendarInfoList().then(function(r) {
                    r.forEach(function(r, t) {
                        r.calendarId !== e || a(0 === n ? r : {
                            item: r,
                            index: t
                        });
                    }), a(null);
                }).catch(function(e) {
                    t(e);
                });
            });
        }
    }, {
        key: "getSelectedCalendarInfoList",
        value: function() {
            return this.getCalendarInfoList().then(function(e) {
                if (null === e || 0 === e.length) return l.warnAll("getSelectedCalendarInfoList : empty calendarInfoList", d), 
                Promise.reject(-1);
                var r = [], n = [];
                return e.forEach(function(e) {
                    e instanceof o && e.isSelected && (r.push({
                        calendar_id: e.calendarId,
                        corp_id: e.corpId,
                        cal_uid: e.calendarUid
                    }), n.push(e));
                }), 0 === n.length ? (l.warnAll("getSelectedCalendarInfoList : no selected calendar", d), 
                Promise.reject(-1)) : Promise.resolve(r, n);
            });
        }
    }, {
        key: "updateCalendarInfo",
        value: function(e) {
            var r = this;
            if (console.log("updateCalendar store", e), e.calendarId) return this.getCalendarInfoById(e.calendarId, 1).then(function(n) {
                if (console.log("updateCalendarInfo response", n), n) {
                    var a = r.calendarInfoArrCache[n.index];
                    return Object.assign(a, e), r.calendarInfoArrCache.splice(n.index, 1, a), Promise.resolve(r.calendarInfoArrCache);
                }
                return r.calendarInfoArrCache.splice(0, 0, e), Promise.resolve(r.calendarInfoArrCache);
            }).catch(function(e) {
                return l.warnAll("calendarInfo find id error ".concat(e)), Promise.reject(-1);
            });
        }
    }, {
        key: "deleteCalendar",
        value: function(e) {
            var r = this;
            if (e) return this.getCalendarInfoById(e, 1).then(function(e) {
                return console.log("deleteCalendar response", e), e && r.calendarInfoArrCache.splice(e.index, 1), 
                Promise.resolve(r.calendarInfoArrCache);
            }).catch(function(e) {
                return l.warnAll("calendarInfo find id error ".concat(e)), Promise.reject(-1);
            });
        }
    }, {
        key: "batchUpdateCalendar",
        value: function(e) {
            if (Array.isArray(e) || 0 !== e.length) return t.getInstance().updateCalendarInfos(e);
        }
    }, {
        key: "getDefaultCalendar",
        value: function() {
            return this.getCalendarInfoList().then(function() {
                var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : [], r = e.filter(function(e) {
                    return 4 !== e.calType;
                });
                console.log("======56789=====", r);
                var n = r.find(function(e) {
                    return 1 === e.isDefault;
                });
                return n || r[0];
            });
        }
    }, {
        key: "batchQuerySubscribers",
        value: function(e) {
            return s.post("/calendar/v1/batchQuerySubscribers?".concat(s.getReuqestCommonParams()), {
                data: e
            });
        }
    }, {
        key: "getInvitationCode",
        value: function(e) {
            return s.get("/calendar/v1/getInvitationCode?".concat(s.getReuqestCommonParams()), {
                data: e
            });
        }
    } ], [ {
        key: "getInstance",
        value: function() {
            return void 0 === a.prototype.instance && (a.prototype.instance = new a()), a.prototype.instance;
        }
    } ]), a;
}();

module.exports = f;