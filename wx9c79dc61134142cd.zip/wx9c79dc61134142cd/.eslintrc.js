module.exports = {
    parserOptions: {
        ecmaVersion: 2018,
        sourceType: "module",
        ecmaFeatures: {
            impliedStrict: !0
        }
    },
    env: {
        browser: !0,
        node: !0,
        es6: !0
    },
    extends: [ "@tencent/eslint-config-tencent" ],
    rules: {
        "no-debugger": "error",
        "new-cap": [ "error", {
            capIsNewExceptions: [ "App", "Page", "Component" ]
        } ],
        "linebreak-style": [ 0, "windows" ],
        "max-len": [ "error", {
            code: 120,
            comments: 120
        } ],
        "import/newline-after-import": [ "error", {
            count: 1
        } ]
    },
    globals: {
        require: !0,
        Page: !0,
        wx: !0,
        App: !0,
        getApp: !0,
        getCurrentPages: !0,
        Component: !0,
        getRegExp: !0,
        globalThis: !0
    }
};