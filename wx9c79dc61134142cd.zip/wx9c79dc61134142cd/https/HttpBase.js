var e = require("../@babel/runtime/helpers/objectSpread2"), t = require("../utils/beacon/report_data"), i = require("../stores/AppStore"), a = {
    get: function(t) {
        var i = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {};
        return this.request(t, e(e({}, i), {}, {
            method: "GET"
        }));
    },
    post: function(t, i) {
        return this.request(t, e(e({}, i), {}, {
            method: "POST"
        }));
    },
    request: function(a, c) {
        var n = c.method, r = void 0 === n ? "GET" : n, o = c.data, s = void 0 === o ? {} : o, _ = c.header, u = void 0 === _ ? {} : _, d = {
            "content-type": "application/json"
        }, g = {}, m = a.replace(/^.*\/(.*?)\?.*$|^.*\/(.*)$/, "$1$2"), p = new Date().getTime(), l = i.getCurrEnv().key;
        return new Promise(function(i, c) {
            wx.request({
                url: a,
                method: r,
                data: e(e({}, g), s),
                header: e(e({}, d), u),
                success: function(e) {
                    var a = e.data || {}, c = e.statusCode, n = a.code, r = a.nonce, o = a.message, s = new Date().getTime() - p;
                    t.dataReport("mp_calendar_cgi", {
                        cgi_trace_id: "",
                        cgi_name: m,
                        cgi_time_cost: s,
                        cgi_http_code: n,
                        cgi_http_status_code: c,
                        cgi_nonce: r,
                        cgi_message: o,
                        env_name: l
                    }), i(e);
                },
                fail: function(e) {
                    var i = "wx request fail: ".concat(JSON.stringify(e)), a = new Date().getTime() - p;
                    t.dataReport("mp_calendar_cgi", {
                        cgi_trace_id: "null",
                        cgi_name: m,
                        cgi_time_cost: a,
                        cgi_http_code: 999999999,
                        cgi_http_status_code: "null",
                        cgi_nonce: "",
                        cgi_message: i,
                        env_name: l
                    }), c(e);
                }
            });
        });
    }
};

module.exports = a;