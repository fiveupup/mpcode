var e = require("../@babel/runtime/helpers/objectSpread2"), t = require("./HttpBase"), o = require("../stores/UserStore"), n = require("../stores/AppStore"), a = require("./CGIClient"), r = require("../sdk/logger/calendar_logger"), c = "UserHttps.js", i = {
    calendarLoginRaw: function(e) {
        var o = {
            code: e
        }, r = "".concat(n.getHttpCgi(), "/v2/account/mini-program/login?").concat(a.getReuqestCommonParams(o));
        return e ? t.post(r, {
            data: o
        }) : Promise.reject({
            code: "999999999",
            errmsg: "code is undefined"
        });
    },
    registerByAutoPhoneRaw: function(e, o, r, c, i) {
        var u = {
            register_auth_code: e,
            encrypted_data: o,
            iv: r,
            nickname: c,
            avatar_url: i
        }, s = "".concat(n.getHttpCgi(), "/v2/account/mini-program/register-by-phone?").concat(a.getReuqestCommonParams(u));
        return t.post(s, {
            data: u
        });
    },
    registerByUserPhoneRaw: function(e, o, r, c, i, u) {
        var s = {
            register_auth_code: e,
            area: o,
            phone: r,
            sms_code: c,
            nickname: i,
            avatar_url: u
        }, g = "".concat(n.getHttpCgi(), "/v2/account/mini-program/register-by-phone?").concat(a.getReuqestCommonParams(s));
        return t.post(g, {
            data: s
        });
    },
    registerByNoPhoneRaw: function(e, o, r) {
        var c = {
            register_auth_code: e,
            nickname: o,
            avatar_url: r
        }, i = "".concat(n.getHttpCgi(), "/v2/account/mini-program/register-by-phone?").concat(a.getReuqestCommonParams(c));
        return t.post(i, {
            data: c
        });
    },
    loginByAuthCodeCgi: function(e) {
        var t = {
            auth_code: e,
            identity_type: 1
        }, o = "/v2/account/login/auth-code".concat("?", a.getReuqestCommonParams(t));
        return r.info("loginByAuthCodeRaw data: ".concat(JSON.stringify(t)), c), a.post(o, {
            data: t
        });
    },
    getCaptchaCgi: function(e) {
        var t = "/v2/common/msg/send-phone-code".concat("?", a.getReuqestCommonParams(e));
        return r.info("getCaptchaRaw data: ".concat(JSON.stringify(e)), c), a.post(t, {
            data: e
        });
    },
    getMeetingBindDetailCgi: function() {
        var e = "/v2/account/profile/get-meeting-bind-detail".concat("?", a.getReuqestCommonParams());
        return r.info("getMeetingBindDetailCgi", c), a.get(e);
    },
    setSyncMeetingCgi: function(e) {
        var t = {
            auth_result: e ? "1" : "2"
        }, o = "/v2/account/profile/set-sync-meeting-auth".concat("?", a.getReuqestCommonParams(t));
        return r.info("setSyncMeetingCgi data: ".concat(JSON.stringify(t)), c), a.post(o, {
            data: t
        });
    },
    refreshTokenCgi: function(e) {
        var t = {
            refresh_token: e ? 1 : 0
        }, o = "/v2/account/login/refresh-token".concat("?", a.getReuqestCommonParams(t));
        return r.info("refreshTokenCgi data: ".concat(JSON.stringify(t)), c), a.post(o, {
            data: t
        });
    },
    getTmpTokenForH5Cgi: function() {
        var e = "/v2/user-logic/get-jump-token".concat("?", a.getReuqestCommonParams());
        return a.get(e);
    },
    bindUserPhoneCgi: function(e, t, o) {
        var n = {
            phone: e,
            area: t,
            code: o
        }, i = "/v2/account/bind/phone".concat("?", a.getReuqestCommonParams(n));
        return r.info("bindUserPhoneCgi data: ".concat(JSON.stringify(n)), c), a.post(i, {
            data: n
        });
    },
    bindWxPhoneCgi: function(e, t, o) {
        var n = {
            userid: e,
            encrypted_data: t,
            iv: o
        }, i = "/v2/account/bind/bind-wechat-phone".concat("?", a.getReuqestCommonParams(n));
        return r.info("bindWxPhoneCgi data: ".concat(JSON.stringify(n)), c), a.post(i, {
            data: n
        });
    },
    wemeetLogin: function(e) {
        var o = "".concat(n.getHttpCgi(), "/account/mini-program/login");
        return e ? t.get(o, {
            data: {
                auth_code: e,
                auth_type: "wxwork",
                auth_instid: 8
            }
        }) : Promise.reject({
            code: "999999999",
            errmsg: "code is undefined"
        });
    },
    authUserInfo: function(e, a) {
        var r = "".concat(n.getHttpCgi(), "/account/mini-program/auth-user-info"), c = o.getOpenID(), i = o.getCGIToken();
        return t.post(r, {
            data: {
                open_id: c,
                cgi_token: i,
                encrypted_data: e,
                iv: a
            }
        }).then(function() {
            var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {}, t = e.data, o = t || {}, n = o.code, a = o.data;
            if (0 === n) return a;
            throw e;
        });
    },
    getPhoneNumber: function(e, a) {
        var r = o.getOpenID(), c = o.getCGIToken(), i = "".concat(n.getHttpCgi(), "/account/mini-program/get-phone");
        return t.post(i, {
            data: {
                userid: r,
                wemeet_cgi_token: c,
                encrypted_data: e,
                iv: a
            }
        });
    },
    getAuthCodeForLogin: function(e) {
        var t = "".concat(a.APIS.AUTH_LOGIN, "?").concat(a.getReuqestCommonParams(e));
        return a.post(t, {
            data: e
        });
    },
    getAuthCodeForRegister: function(t) {
        var o = "".concat(a.APIS.AUTH_LOGIN, "?").concat(a.getReuqestCommonParams(t));
        return a.post(o, {
            data: e({}, t)
        });
    },
    registerPhone: function(e) {
        var t = e.area, o = e.phone, n = e.code, r = e.auth_code;
        if (t || (console.warn('no "area" provided, set to 86 as default'), e.area = "86"), 
        !r) return Promise.reject({
            code: "999999999",
            errmsg: "auth_code is required"
        });
        if (!o || !n) return Promise.reject({
            code: "999999999",
            errmsg: "phone&code is required"
        });
        var c = "".concat(a.APIS.WECHAT_BIND_PHONE, "?").concat(a.getReuqestCommonParams(e));
        return a.post(c, {
            data: e
        });
    },
    loginUsingAuthCode: function(e) {
        var t = e.auth_code, o = e.identity_type, n = e.corp_id;
        if (!t) return Promise.reject({
            code: "999999999",
            errmsg: "auth_code is required"
        });
        if (1 !== o && 2 !== o) return Promise.reject({
            code: "999999999",
            errmsg: "identity_type is illegal: ".concat(o)
        });
        if (2 === o && !n) return Promise.reject({
            code: "999999999",
            errmsg: "corp_id is required when enterprise account is choosen"
        });
        var r = "".concat(a.APIS.AUTH_CODE, "?").concat(a.getReuqestCommonParams(e));
        return a.post(r, {
            data: e
        });
    },
    refreshWeMeetLoginToken: function(e) {
        var t = e.refresh_token;
        if (0 !== t && 1 !== t) return Promise.reject({
            code: "999999999",
            errmsg: "refreshToken is supposed to be 1 or 2, but got ".concat(t)
        });
        var o = "".concat(a.APIS.REFRESH_TOKEN, "?").concat(a.getReuqestCommonParams(e));
        return a.post(o, {
            data: e
        });
    },
    wemeetLogout: function() {
        var e = "".concat(a.APIS.WEMEET_LOGOUT, "?").concat(a.getReuqestCommonParams());
        return a.get(e);
    },
    getVirtualCard: function(e) {
        var t = "".concat(a.APIS.GET_VIRTUAL_CARD, "?").concat(a.getReuqestCommonParams(e));
        return a.post(t, {
            data: e
        });
    },
    updateQrcodeStatus: function(e) {
        var t = "/v2/user-logic/update-qrcode-status?".concat(a.getReuqestCommonParams(e));
        return a.post(t, {
            data: e
        });
    },
    authorizeCallback: function(e) {
        var t = "/v2/account/auth/authorize-callback?".concat(a.getReuqestCommonParams(e));
        return a.post(t, {
            data: e
        }).then(function(e) {
            return {
                data: {
                    code: 0,
                    data: e
                }
            };
        });
    },
    getMeetingCodeFromURL: function(e) {
        var t = "/calendar/v1/getMeetingCodeFromUrl?".concat(a.getReuqestCommonParams());
        return a.post(t, {
            data: e
        }).then(function(e) {
            return {
                data: {
                    code: 0,
                    data: e
                }
            };
        });
    }
};

module.exports = i;