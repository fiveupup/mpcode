var e = (0, require("../@babel/runtime/helpers/interopRequireDefault").default)(require("../sdk/cgi/cgi")), c = require("../utils/Dispatcher"), t = require("../constants/AppType"), a = require("../constants/UserType"), o = require("../sdk/logger/calendar_logger"), n = require("../stores/AppStore"), s = require("../utils/beacon/report_data"), i = require("../configs/AppConfig"), r = new e.default(), g = "CGIClient.js";

r.setConfig({
    accessKey: "xdZzeqKJOfPCUv2YhsQpHlSLFu14j9Gn",
    cgiHostUrl: n.getHttpCgi(),
    instanceId: "8",
    os: "iOS",
    osVersion: "10.0.1",
    osModel: "iPhone",
    mockHostUrl: "http://cowork.yapi.oa.com/mock/256",
    appVersion: i.MP_CALENDAR_VERSION,
    onRequestSuc: function(e) {
        var c = e.statusCode, t = e.traceId, a = e.cgiName, i = e.cost, r = e.code, p = e.nonce, d = e.message, _ = e.rawResp, u = n.getCurrEnv().key;
        o.infoAll("onRequestSuc: statusCode: ".concat(c, ", traceId: ").concat(t, ", cgiName: ").concat(a, ", cost: ").concat(i, ", code: ").concat(r, ", nonce: ").concat(p, ", message: ").concat(d, ", envName: ").concat(u), g), 
        o.info("onRequestSuc: traceId: ".concat(t, ", cgiName: ").concat(a, ", statusCode: ").concat(c, ", rawResp: ").concat(JSON.stringify(_), ", envName: ").concat(u), g), 
        s.dataReport("mp_calendar_cgi", {
            cgi_http_status_code: c,
            cgi_trace_id: t,
            cgi_name: a,
            cgi_time_cost: i,
            cgi_http_code: r,
            cgi_nonce: p,
            cgi_message: d,
            env_name: u
        });
    },
    onRequestFail: function(e) {
        var c = e.statusCode, t = e.traceId, a = e.cgiName, i = e.cost, r = e.code, p = e.nonce, d = e.message, _ = e.rawResp, u = n.getCurrEnv().key;
        o.infoAll("onRequestFail: statusCode: ".concat(c, ", traceId: ").concat(t, ", cgiName: ").concat(a, ", cost: ").concat(i, ", code: ").concat(r, ", nonce: ").concat(p, ", message: ").concat(d, ", envName: ").concat(u), g), 
        o.info("onRequestFail: traceId: ".concat(t, ", cgiName: ").concat(a, ", statusCode: ").concat(c, ", rawResp: ").concat(JSON.stringify(_), ", envName: ").concat(u), g), 
        s.dataReport("mp_calendar_cgi", {
            cgi_http_status_code: c,
            cgi_trace_id: t,
            cgi_name: a,
            cgi_time_cost: i,
            cgi_http_code: r,
            cgi_nonce: p,
            cgi_message: d,
            env_name: u
        });
    }
}), console.log("CGIClient Dispatcher.register"), c.register(function() {
    var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {}, c = e.type, n = e.payload;
    if (c) switch (c) {
      case t.INIT_SYSTEM_INFO_SUCC:
        var s = n || {}, i = s.data, p = void 0 === i ? {} : i, d = p || {}, _ = d.sysInfo;
        o.info("CGIClient INIT_SYSTEM_INFO_SUCC: ".concat(JSON.stringify(_)), g);
        var u = (_.system || "").replace(/(.*?)\s.*/, "$1"), C = (_.system || "").replace(/.*?\s(.*)/, "$1");
        r.setConfig({
            os: u,
            osVersion: C,
            osModel: "iPhone"
        });
        break;

      case a.ACCOUNT_INFO_INIT:
        var I = n || {}, l = I.userId, m = I.appId, N = I.cgiToken;
        o.info("UserType.ACCOUNT_INFO_INIT: userId: ".concat(l, ", appId: ").concat(m, ", cgiToken: ").concat(N), g), 
        r.setConfig({
            cgiToken: N,
            appUID: l,
            appId: m
        });
        break;

      case a.CALENDAR_AUTH_CODE_SUC:
        var f = n || {}, T = f.userId, v = f.appId, S = f.cgiToken;
        o.info("UserType.CALENDAR_AUTH_CODE_SUC:\n       userId: ".concat(T, ", appId: ").concat(v, ", cgiToken: ").concat(S), g), 
        r.setConfig({
            cgiToken: S,
            appUID: T,
            appId: v
        });
    }
}), module.exports = r;