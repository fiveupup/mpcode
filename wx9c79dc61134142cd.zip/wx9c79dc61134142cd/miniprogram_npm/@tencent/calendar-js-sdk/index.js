var _typeof3 = require("../../../@babel/runtime/helpers/typeof");

module.exports = function() {
    var __MODS__ = {}, __DEFINE__ = function(e, t, n) {
        __MODS__[e] = {
            status: 0,
            func: t,
            req: n,
            m: {
                exports: {},
                _tempexports: {}
            }
        };
    }, __REQUIRE__ = function(e, t) {
        if (!__MODS__[e]) return require(t);
        if (!__MODS__[e].status) {
            var n = __MODS__[e].m;
            n._exports = n._tempexports;
            var r = Object.getOwnPropertyDescriptor(n, "exports");
            r && r.configurable && Object.defineProperty(n, "exports", {
                set: function(e) {
                    "object" === _typeof3(e) && e !== n._exports && (n._exports.__proto__ = e.__proto__, 
                    Object.keys(e).forEach(function(t) {
                        n._exports[t] = e[t];
                    })), n._tempexports = e;
                },
                get: function() {
                    return n._tempexports;
                }
            }), __MODS__[e].status = 1, __MODS__[e].func(__MODS__[e].req, n, n.exports);
        }
        return __MODS__[e].m.exports;
    }, __REQUIRE_WILDCARD__ = function(e) {
        if (e && e.__esModule) return e;
        var t = {};
        if (null != e) for (var n in e) Object.prototype.hasOwnProperty.call(e, n) && (t[n] = e[n]);
        return t.default = e, t;
    }, __REQUIRE_DEFAULT__ = function(e) {
        return e && e.__esModule ? e.default : e;
    };
    return __DEFINE__(1699270751485, function(require, module, exports) {
        !function(e, t) {
            if ("object" == _typeof3(exports) && "object" == _typeof3(module)) module.exports = t(); else if ("function" == typeof define && define.amd) define([], t); else {
                var n = t();
                for (var r in n) ("object" == _typeof3(exports) ? exports : e)[r] = n[r];
            }
        }(self, function() {
            return function() {
                var __webpack_modules__ = {
                    547: function _(module, exports, __webpack_require__) {
                        var __WEBPACK_AMD_DEFINE_ARRAY__, __WEBPACK_AMD_DEFINE_RESULT__, __WEBPACK_AMD_DEFINE_FACTORY__, __WEBPACK_AMD_DEFINE_RESULT__, global, factory;
                        function _typeof(e) {
                            return (_typeof = "function" == typeof Symbol && "symbol" == _typeof3(Symbol.iterator) ? function(e) {
                                return _typeof3(e);
                            } : function(e) {
                                return e && "function" == typeof Symbol && e.constructor === Symbol && e !== Symbol.prototype ? "symbol" : _typeof3(e);
                            })(e);
                        }
                        global = "undefined" != typeof self ? self : "undefined" != typeof window ? window : void 0 !== __webpack_require__.g ? __webpack_require__.g : this, 
                        factory = function factory(global) {
                            global = global || {};
                            var _Base64 = global.Base64, version = "2.5.1", buffer;
                            if (module.exports) try {
                                buffer = eval("require('buffer').Buffer");
                            } catch (e) {
                                buffer = void 0;
                            }
                            var b64chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/", b64tab = function(e) {
                                for (var t = {}, n = 0, r = e.length; n < r; n++) t[e.charAt(n)] = n;
                                return t;
                            }(b64chars), fromCharCode = String.fromCharCode, cb_utob = function(e) {
                                if (e.length < 2) return (t = e.charCodeAt(0)) < 128 ? e : t < 2048 ? fromCharCode(192 | t >>> 6) + fromCharCode(128 | 63 & t) : fromCharCode(224 | t >>> 12 & 15) + fromCharCode(128 | t >>> 6 & 63) + fromCharCode(128 | 63 & t);
                                var t = 65536 + 1024 * (e.charCodeAt(0) - 55296) + (e.charCodeAt(1) - 56320);
                                return fromCharCode(240 | t >>> 18 & 7) + fromCharCode(128 | t >>> 12 & 63) + fromCharCode(128 | t >>> 6 & 63) + fromCharCode(128 | 63 & t);
                            }, re_utob = /[\uD800-\uDBFF][\uDC00-\uDFFFF]|[^\x00-\x7F]/g, utob = function(e) {
                                return e.replace(re_utob, cb_utob);
                            }, cb_encode = function(e) {
                                var t = [ 0, 2, 1 ][e.length % 3], n = e.charCodeAt(0) << 16 | (e.length > 1 ? e.charCodeAt(1) : 0) << 8 | (e.length > 2 ? e.charCodeAt(2) : 0);
                                return [ b64chars.charAt(n >>> 18), b64chars.charAt(n >>> 12 & 63), t >= 2 ? "=" : b64chars.charAt(n >>> 6 & 63), t >= 1 ? "=" : b64chars.charAt(63 & n) ].join("");
                            }, btoa = global.btoa ? function(e) {
                                return global.btoa(e);
                            } : function(e) {
                                return e.replace(/[\s\S]{1,3}/g, cb_encode);
                            }, _encode = function(e) {
                                return "[object Uint8Array]" === Object.prototype.toString.call(e) ? e.toString("base64") : btoa(utob(String(e)));
                            }, encode = function(e, t) {
                                return t ? _encode(String(e)).replace(/[+\/]/g, function(e) {
                                    return "+" == e ? "-" : "_";
                                }).replace(/=/g, "") : _encode(e);
                            }, encodeURI = function(e) {
                                return encode(e, !0);
                            }, re_btou = new RegExp([ "[À-ß][-¿]", "[à-ï][-¿]{2}", "[ð-÷][-¿]{3}" ].join("|"), "g"), cb_btou = function(e) {
                                switch (e.length) {
                                  case 4:
                                    var t = ((7 & e.charCodeAt(0)) << 18 | (63 & e.charCodeAt(1)) << 12 | (63 & e.charCodeAt(2)) << 6 | 63 & e.charCodeAt(3)) - 65536;
                                    return fromCharCode(55296 + (t >>> 10)) + fromCharCode(56320 + (1023 & t));

                                  case 3:
                                    return fromCharCode((15 & e.charCodeAt(0)) << 12 | (63 & e.charCodeAt(1)) << 6 | 63 & e.charCodeAt(2));

                                  default:
                                    return fromCharCode((31 & e.charCodeAt(0)) << 6 | 63 & e.charCodeAt(1));
                                }
                            }, btou = function(e) {
                                return e.replace(re_btou, cb_btou);
                            }, cb_decode = function(e) {
                                var t = e.length, n = t % 4, r = (t > 0 ? b64tab[e.charAt(0)] << 18 : 0) | (t > 1 ? b64tab[e.charAt(1)] << 12 : 0) | (t > 2 ? b64tab[e.charAt(2)] << 6 : 0) | (t > 3 ? b64tab[e.charAt(3)] : 0), o = [ fromCharCode(r >>> 16), fromCharCode(r >>> 8 & 255), fromCharCode(255 & r) ];
                                return o.length -= [ 0, 0, 2, 1 ][n], o.join("");
                            }, _atob = global.atob ? function(e) {
                                return global.atob(e);
                            } : function(e) {
                                return e.replace(/\S{1,4}/g, cb_decode);
                            }, atob = function(e) {
                                return _atob(String(e).replace(/[^A-Za-z0-9\+\/]/g, ""));
                            }, _decode = buffer ? buffer.from && Uint8Array && buffer.from !== Uint8Array.from ? function(e) {
                                return (e.constructor === buffer.constructor ? e : buffer.from(e, "base64")).toString();
                            } : function(e) {
                                return (e.constructor === buffer.constructor ? e : new buffer(e, "base64")).toString();
                            } : function(e) {
                                return btou(_atob(e));
                            }, decode = function(e) {
                                return _decode(String(e).replace(/[-_]/g, function(e) {
                                    return "-" == e ? "+" : "/";
                                }).replace(/[^A-Za-z0-9\+\/]/g, ""));
                            }, noConflict = function() {
                                var e = global.Base64;
                                return global.Base64 = _Base64, e;
                            };
                            if (global.Base64 = {
                                VERSION: version,
                                atob: atob,
                                btoa: btoa,
                                fromBase64: decode,
                                toBase64: encode,
                                utob: utob,
                                encode: encode,
                                encodeURI: encodeURI,
                                btou: btou,
                                decode: decode,
                                noConflict: noConflict,
                                __buffer__: buffer
                            }, "function" == typeof Object.defineProperty) {
                                var noEnum = function(e) {
                                    return {
                                        value: e,
                                        enumerable: !1,
                                        writable: !0,
                                        configurable: !0
                                    };
                                };
                                global.Base64.extendString = function() {
                                    Object.defineProperty(String.prototype, "fromBase64", noEnum(function() {
                                        return decode(this);
                                    })), Object.defineProperty(String.prototype, "toBase64", noEnum(function(e) {
                                        return encode(this, e);
                                    })), Object.defineProperty(String.prototype, "toBase64URI", noEnum(function() {
                                        return encode(this, !0);
                                    }));
                                };
                            }
                            return global.Meteor && (Base64 = global.Base64), module.exports ? module.exports.Base64 = global.Base64 : (__WEBPACK_AMD_DEFINE_ARRAY__ = [], 
                            __WEBPACK_AMD_DEFINE_RESULT__ = function() {
                                return global.Base64;
                            }.apply(exports, __WEBPACK_AMD_DEFINE_ARRAY__), void 0 === __WEBPACK_AMD_DEFINE_RESULT__ || (module.exports = __WEBPACK_AMD_DEFINE_RESULT__)), 
                            {
                                Base64: global.Base64
                            };
                        }, "object" === _typeof(exports) ? module.exports = factory(global) : void 0 === (__WEBPACK_AMD_DEFINE_RESULT__ = "function" == typeof (__WEBPACK_AMD_DEFINE_FACTORY__ = factory) ? __WEBPACK_AMD_DEFINE_FACTORY__.call(exports, __webpack_require__, exports, module) : __WEBPACK_AMD_DEFINE_FACTORY__) || (module.exports = __WEBPACK_AMD_DEFINE_RESULT__);
                    },
                    413: function(e, t, n) {
                        function r(e, t) {
                            var n = Object.keys(e);
                            if (Object.getOwnPropertySymbols) {
                                var r = Object.getOwnPropertySymbols(e);
                                t && (r = r.filter(function(t) {
                                    return Object.getOwnPropertyDescriptor(e, t).enumerable;
                                })), n.push.apply(n, r);
                            }
                            return n;
                        }
                        function o(e) {
                            for (var t = 1; t < arguments.length; t++) {
                                var n = null != arguments[t] ? arguments[t] : {};
                                t % 2 ? r(Object(n), !0).forEach(function(t) {
                                    i(e, t, n[t]);
                                }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(n)) : r(Object(n)).forEach(function(t) {
                                    Object.defineProperty(e, t, Object.getOwnPropertyDescriptor(n, t));
                                });
                            }
                            return e;
                        }
                        function i(e, t, n) {
                            return t in e ? Object.defineProperty(e, t, {
                                value: n,
                                enumerable: !0,
                                configurable: !0,
                                writable: !0
                            }) : e[t] = n, e;
                        }
                        var a = n(718), s = n(547).Base64, c = function() {
                            function e() {
                                !function(e, t) {
                                    if (!(e instanceof t)) throw new TypeError("Cannot call a class as a function");
                                }(this, e), this.accessKey = "", this.cgiToken = "", this.cgiHostUrl = "", this.instanceId = "", 
                                this.os = "", this.osVersion = "", this.osModel = "", this.appId = "", this.appUID = "", 
                                this.appVersion = "", this.onRequestSuc = "", this.onRequestFail = "", this.mockHostUrl = "/mock/256";
                            }
                            var t, r;
                            return t = e, (r = [ {
                                key: "setConfig",
                                value: function() {
                                    var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {}, t = e.accessKey, n = e.cgiToken, r = e.cgiHostUrl, o = e.instanceId, i = e.os, a = e.osVersion, s = e.osModel, c = e.appId, u = e.appUID, f = e.appVersion, l = e.mockHostUrl, p = e.onRequestSuc, h = e.onRequestFail;
                                    t && (this.accessKey = t), n && (this.cgiToken = n), r && (this.cgiHostUrl = r), 
                                    l && (this.mockHostUrl = l), o && (this.instanceId = o), i && (this.os = i), a && (this.osVersion = a), 
                                    s && (this.osModel = s), c && (this.appId = c), u && (this.appUID = u), f && (this.appVersion = f), 
                                    p && (this.onRequestSuc = p), h && (this.onRequestFail = h);
                                }
                            }, {
                                key: "setAppId",
                                value: function(e) {
                                    this.appId = e;
                                }
                            }, {
                                key: "setAppUID",
                                value: function(e) {
                                    this.appUID = e;
                                }
                            }, {
                                key: "setCgiToken",
                                value: function(e) {
                                    this.cgiToken = e;
                                }
                            }, {
                                key: "get",
                                value: function(e) {
                                    var t = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {}, n = arguments.length > 2 && void 0 !== arguments[2] && arguments[2];
                                    return this.cgiRequest(e, o({
                                        method: "GET"
                                    }, t), n);
                                }
                            }, {
                                key: "post",
                                value: function(e) {
                                    var t = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {}, n = arguments.length > 2 && void 0 !== arguments[2] && arguments[2];
                                    return this.cgiRequest(e, o(o({
                                        method: "POST"
                                    }, t), {}, {
                                        mock: n
                                    }));
                                }
                            }, {
                                key: "cgiRequest",
                                value: function(e, t, n) {
                                    var r = this;
                                    if (!n && /^https?/.test(e)) return Promise.reject({
                                        code: "999999999",
                                        errmsg: "Invalid CGI api provided: ".concat(e, ". Expected to be non-domain prefixed.")
                                    });
                                    var i = t.method, a = void 0 === i ? "GET" : i, s = t.data, c = void 0 === s ? {} : s, u = t.header, f = void 0 === u ? {} : u, l = "".concat(n ? this.mockHostUrl : this.cgiHostUrl).concat(e, "?").concat(this.getReuqestCommonParams(c)), p = {
                                        "content-type": "application/json",
                                        platform: "web"
                                    }, h = {};
                                    return new Promise(function(e, t) {
                                        console.log("[CGI]%c[%s]", "background-color:#006fff;color:white;font-weight:bold;", r.getCgiName(l), "starts..."), 
                                        r.canUseWxRequest() ? r.doWxRequest(l, a, o(o({}, h), c), o(o({}, p), f), e, t, n) : r.doAxiosRequest(l, a, o(o({}, h), c), o(o({}, p), f), e, t);
                                    });
                                }
                            }, {
                                key: "doWxRequest",
                                value: function(e, t, n, r, o, i, a) {
                                    var s = this;
                                    if (a) {
                                        var c = "TCOA_TICKET=".concat(u("TCOA_TICKET"), ";TCOA=").concat(u("TCOA"), ";RIO_TCOA_TICKET=").concat(u("RIO_TCOA_TICKET"));
                                        Object.assign(r, {
                                            Cookie: c
                                        });
                                    }
                                    var f = new Date().getTime();
                                    wx.request({
                                        url: e,
                                        method: t,
                                        data: n,
                                        header: r,
                                        enableHttp2: !0,
                                        enableQuic: !0,
                                        enableCache: !0,
                                        success: function(t) {
                                            var n = (t || {}).header || {}, r = (t || {}).data || {}, a = (t || {}).statusCode, c = t || {};
                                            c.puRequestTime = f;
                                            var u = new Date().getTime() - f;
                                            s.processResponse(s.getCgiName(e), n, r, a, u, c, o, i);
                                        },
                                        fail: function(t) {
                                            var n = new Date().getTime() - f;
                                            s.processError(s.getCgiName(e), n, "wx request fail: ".concat(JSON.stringify(t)), t, i);
                                        }
                                    });
                                }
                            }, {
                                key: "doAxiosRequest",
                                value: function(e, t, r, o, i, a) {
                                    var s = this, c = n(867).default, u = new Date().getTime();
                                    if ("GET" === t.toUpperCase()) {
                                        var f, l = "", p = 0;
                                        Object.keys(r).forEach(function(e) {
                                            0 !== p && (l += "&"), l += e + "=" + r[e], p += 1;
                                        }), console.log("queryStr: ".concat(l)), f = -1 === e.indexOf("?") ? "".concat(e, "?").concat(l) : "".concat(e, "&").concat(l), 
                                        console.log("getUrl: ".concat(f)), c.get(f, {
                                            headers: o
                                        }).then(function(t) {
                                            console.log("response from axios get header: ".concat(JSON.stringify(t.headers))), 
                                            console.log("response from axios get httpData: ".concat(JSON.stringify(t.data))), 
                                            console.log("response from axios get statusCode: ".concat(t.status));
                                            var n = t.headers, r = t.data, o = t.status, c = new Date().getTime() - u;
                                            s.processResponse(s.getCgiName(e), n, r, o, c, {
                                                httpHeader: n,
                                                httpData: r,
                                                statusCode: o
                                            }, i, a);
                                        }).catch(function(t) {
                                            console.error("error from axios get: ".concat(t));
                                            var n = t.response, r = new Date().getTime() - u;
                                            if (n) {
                                                console.log("response from axios get header: ".concat(JSON.stringify(n.headers))), 
                                                console.log("response from axios get httpData: ".concat(JSON.stringify(n.data))), 
                                                console.log("response from axios get statusCode: ".concat(n.status));
                                                var o = n.headers, c = n.data, f = n.status;
                                                s.processResponse(s.getCgiName(e), o, c, f, r, {
                                                    httpHeader: o,
                                                    httpData: c,
                                                    statusCode: f
                                                }, i, a);
                                            } else s.processError(s.getCgiName(e), r, "axios request fail: ".concat(JSON.stringify(t)), t, a);
                                        });
                                    } else "POST" === t.toUpperCase() && c.post(e, r, {
                                        headers: o
                                    }).then(function(t) {
                                        console.log("response from axios post header: ".concat(JSON.stringify(t.headers))), 
                                        console.log("response from axios post httpData: ".concat(JSON.stringify(t.data))), 
                                        console.log("response from axios post statusCode: ".concat(t.status));
                                        var n = t.headers, r = t.data, o = t.status, c = new Date().getTime() - u;
                                        s.processResponse(s.getCgiName(e), n, r, o, c, {
                                            httpHeader: n,
                                            httpData: r,
                                            statusCode: o
                                        }, i, a);
                                    }).catch(function(t) {
                                        console.log("error from axios post: ".concat(t));
                                        var n = t.response, r = new Date().getTime() - u;
                                        if (n) {
                                            console.log("response from axios post header: ".concat(JSON.stringify(n.headers))), 
                                            console.log("response from axios post httpData: ".concat(JSON.stringify(n.data))), 
                                            console.log("response from axios post statusCode: ".concat(n.status));
                                            var o = n.headers, c = n.data, f = n.status;
                                            s.processResponse(s.getCgiName(e), o, c, f, r, {
                                                httpHeader: o,
                                                httpData: c,
                                                statusCode: f
                                            }, i, a);
                                        } else s.processError(s.getCgiName(e), r, "axios request fail: ".concat(JSON.stringify(t)), t, a);
                                    });
                                }
                            }, {
                                key: "getValueFromHeader",
                                value: function(e, t) {
                                    var n = t.toLowerCase(), r = void 0;
                                    return Object.keys(e).forEach(function(t) {
                                        t.toLowerCase() != n || (r = e[t]);
                                    }), r;
                                }
                            }, {
                                key: "processResponse",
                                value: function(e, t, n, r, o, i, a, s) {
                                    var c = this.getValueFromHeader(t, "traceid"), u = n.code, f = n.nonce, l = this.getMessageFromHttpData(n);
                                    if (console.log("traceId:", c), console.log("code: ".concat(u, ", message: ").concat(l, ", nonce: ").concat(f)), 
                                    0 !== u) {
                                        var p = u || "N1";
                                        this.onRequestFail && this.onRequestFail({
                                            statusCode: r,
                                            traceId: c,
                                            cgiName: e,
                                            cost: o,
                                            code: p,
                                            nonce: f,
                                            message: l,
                                            rawResp: i
                                        });
                                        var h = "".concat(e, " CGI error.\n              code = ").concat(p, ",\n              message = ").concat(l, ",\n              nonce = ").concat(f, ".\n              raw response = ").concat(JSON.stringify(i));
                                        return console.log("[CGI]%c[%s]", "background-color:#fbe0e0;color:white;font-weight:bold;", e, h), 
                                        void s({
                                            statusCode: r,
                                            code: u,
                                            message: l
                                        });
                                    }
                                    this.onRequestSuc && this.onRequestSuc({
                                        statusCode: r,
                                        traceId: c,
                                        cgiName: e,
                                        cost: o,
                                        code: u,
                                        nonce: f,
                                        message: l,
                                        rawResp: i
                                    }), console.log("[CGI]%c[%s]", "background-color:#22c56b;color:white;font-weight:bold;", e, "ok"), 
                                    a(n.data);
                                }
                            }, {
                                key: "processError",
                                value: function(e, t, n, r, o) {
                                    this.onRequestFail && this.onRequestFail({
                                        statusCode: -1,
                                        traceId: "-1",
                                        cgiName: e,
                                        cost: t,
                                        code: 999999999,
                                        nonce: "",
                                        message: n,
                                        rawResp: r
                                    }), console.log("[CGI]%c[%s]", "background-color:#DC143C;color:white;font-weight:bold;", e, "request fail: ".concat(JSON.stringify(r))), 
                                    o({
                                        errmsg: r.errMsg || "request fail",
                                        code: "999999999"
                                    });
                                }
                            }, {
                                key: "getCgiName",
                                value: function(e) {
                                    return e.replace(/^.*\/(.*?)\?.*$|^.*\/(.*)$/, "$1$2");
                                }
                            }, {
                                key: "canUseWxRequest",
                                value: function() {
                                    try {
                                        return !!wx.request;
                                    } catch (e) {
                                        return !1;
                                    }
                                }
                            }, {
                                key: "getMessageFromHttpData",
                                value: function(e) {
                                    var t = "";
                                    if (Object.prototype.hasOwnProperty.call(e, "message")) t = e.message ? e.message : "CGI(-1)"; else if (Object.prototype.hasOwnProperty.call(e, "msg")) {
                                        if (t = e.msg ? e.msg : "CGI(-2)", e.msg && 1 === e.msg_encoded) try {
                                            t = s.decode(e.msg);
                                        } catch (n) {
                                            console.error("decode base64 failed. exception: ".concat(JSON.stringify(n), ", msg to decode: ").concat(e.msg)), 
                                            t = "CGI(-3)";
                                        }
                                    } else t = "CGI(-4)";
                                    return t;
                                }
                            }, {
                                key: "randomString",
                                value: function() {
                                    for (var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : 9, t = "ABCDEFGHJKMNPQRSTWXYZabcdefhijkmnprstwxyz2345678", n = "", r = 0; r < e; r++) n += t[Math.floor(Math.random() * t.length)];
                                    return n;
                                }
                            }, {
                                key: "fixedEncodeURIComponent",
                                value: function(e) {
                                    return encodeURIComponent(e).replace(/[!'()*]/g, function(e) {
                                        return "%".concat(e.charCodeAt(0).toString(16).toUpperCase());
                                    });
                                }
                            }, {
                                key: "getReuqestCommonParams",
                                value: function() {
                                    var e = this, t = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {}, n = this.randomString(8), r = {
                                        c_app_id: this.appId,
                                        c_os: this.os,
                                        c_os_version: this.osVersion,
                                        c_os_model: this.osModel,
                                        c_timestamp: Math.floor(new Date().getTime() / 1e3),
                                        c_nonce: n,
                                        c_app_version: this.appVersion,
                                        c_instance_id: this.instanceId,
                                        c_app_uid: this.appUID,
                                        c_token: this.cgiToken,
                                        c_device_id: ""
                                    }, o = [];
                                    Object.keys(r).forEach(function(t) {
                                        o.push({
                                            key: t,
                                            value: e.fixedEncodeURIComponent(r[t])
                                        });
                                    });
                                    var i = [];
                                    o.forEach(function(e) {
                                        i.push("".concat(e.key, "=").concat(e.value));
                                    });
                                    var s = i.join("&");
                                    Object.assign(r, t), Object.keys(t).forEach(function(n) {
                                        o.push({
                                            key: n,
                                            value: e.fixedEncodeURIComponent(t[n])
                                        });
                                    }), o.sort(function(e, t) {
                                        return e.key < t.key ? -1 : 1;
                                    }), i = [], o.forEach(function(e) {
                                        i.push("".concat(e.key, "=").concat(e.value));
                                    });
                                    var c = i.join("&"), u = this, f = l(c);
                                    function l(e) {
                                        return a("".concat(e).concat(u.accessKey));
                                    }
                                    return "".concat(s, "&c_signature=").concat(f);
                                }
                            } ]) && function(e, t) {
                                for (var n = 0; n < t.length; n++) {
                                    var r = t[n];
                                    r.enumerable = r.enumerable || !1, r.configurable = !0, "value" in r && (r.writable = !0), 
                                    Object.defineProperty(e, r.key, r);
                                }
                            }(t.prototype, r), Object.defineProperty(t, "prototype", {
                                writable: !1
                            }), e;
                        }();
                        function u(e) {
                            return wx.getStorageSync ? wx.getStorageSync(e) : window.localStorage.getItem(e);
                        }
                        e.exports = c;
                    },
                    718: function _(module, __unused_webpack_exports, __webpack_require__) {
                        function _typeof(e) {
                            return (_typeof = "function" == typeof Symbol && "symbol" == _typeof3(Symbol.iterator) ? function(e) {
                                return _typeof3(e);
                            } : function(e) {
                                return e && "function" == typeof Symbol && e.constructor === Symbol && e !== Symbol.prototype ? "symbol" : _typeof3(e);
                            })(e);
                        }
                        module = __webpack_require__.nmd(module);
                        var ERROR = "input is invalid type", WINDOW = "object" === ("undefined" == typeof window ? "undefined" : _typeof(window)), root = WINDOW ? window : {};
                        root.JS_SHA256_NO_WINDOW && (WINDOW = !1);
                        var WEB_WORKER = !WINDOW && "object" === ("undefined" == typeof self ? "undefined" : _typeof(self)), NODE_JS = !root.JS_SHA256_NO_NODE_JS && "object" === ("undefined" == typeof process ? "undefined" : _typeof(process)) && process.versions && process.versions.node;
                        NODE_JS ? root = __webpack_require__.g : WEB_WORKER && (root = self);
                        var COMMON_JS = !root.JS_SHA256_NO_COMMON_JS && "object" === _typeof(module) && module.exports, AMD = __webpack_require__.amdO, ARRAY_BUFFER = !root.JS_SHA256_NO_ARRAY_BUFFER && "undefined" != typeof ArrayBuffer, HEX_CHARS = "0123456789abcdef".split(""), EXTRA = [ -2147483648, 8388608, 32768, 128 ], SHIFT = [ 24, 16, 8, 0 ], K = [ 1116352408, 1899447441, 3049323471, 3921009573, 961987163, 1508970993, 2453635748, 2870763221, 3624381080, 310598401, 607225278, 1426881987, 1925078388, 2162078206, 2614888103, 3248222580, 3835390401, 4022224774, 264347078, 604807628, 770255983, 1249150122, 1555081692, 1996064986, 2554220882, 2821834349, 2952996808, 3210313671, 3336571891, 3584528711, 113926993, 338241895, 666307205, 773529912, 1294757372, 1396182291, 1695183700, 1986661051, 2177026350, 2456956037, 2730485921, 2820302411, 3259730800, 3345764771, 3516065817, 3600352804, 4094571909, 275423344, 430227734, 506948616, 659060556, 883997877, 958139571, 1322822218, 1537002063, 1747873779, 1955562222, 2024104815, 2227730452, 2361852424, 2428436474, 2756734187, 3204031479, 3329325298 ], OUTPUT_TYPES = [ "hex", "array", "digest", "arrayBuffer" ], blocks = [];
                        !root.JS_SHA256_NO_NODE_JS && Array.isArray || (Array.isArray = function(e) {
                            return "[object Array]" === Object.prototype.toString.call(e);
                        }), !ARRAY_BUFFER || !root.JS_SHA256_NO_ARRAY_BUFFER_IS_VIEW && ArrayBuffer.isView || (ArrayBuffer.isView = function(e) {
                            return "object" === _typeof(e) && e.buffer && e.buffer.constructor === ArrayBuffer;
                        });
                        var createOutputMethod = function(e, t) {
                            return function(n) {
                                return new Sha256(t, !0).update(n)[e]();
                            };
                        }, createMethod = function(e) {
                            var t = createOutputMethod("hex", e);
                            NODE_JS && (t = nodeWrap(t, e)), t.create = function() {
                                return new Sha256(e);
                            }, t.update = function(e) {
                                return t.create().update(e);
                            };
                            for (var n = 0; n < OUTPUT_TYPES.length; ++n) {
                                var r = OUTPUT_TYPES[n];
                                t[r] = createOutputMethod(r, e);
                            }
                            return t;
                        }, nodeWrap = function nodeWrap(method, is224) {
                            var crypto = eval("require('crypto')"), Buffer = eval("require('buffer').Buffer"), algorithm = is224 ? "sha224" : "sha256", nodeMethod = function(e) {
                                if ("string" == typeof e) return crypto.createHash(algorithm).update(e, "utf8").digest("hex");
                                if (null == e) throw new Error(ERROR);
                                return e.constructor === ArrayBuffer && (e = new Uint8Array(e)), Array.isArray(e) || ArrayBuffer.isView(e) || e.constructor === Buffer ? crypto.createHash(algorithm).update(new Buffer(e)).digest("hex") : method(e);
                            };
                            return nodeMethod;
                        }, createHmacOutputMethod = function(e, t) {
                            return function(n, r) {
                                return new HmacSha256(n, t, !0).update(r)[e]();
                            };
                        }, createHmacMethod = function(e) {
                            var t = createHmacOutputMethod("hex", e);
                            t.create = function(t) {
                                return new HmacSha256(t, e);
                            }, t.update = function(e, n) {
                                return t.create(e).update(n);
                            };
                            for (var n = 0; n < OUTPUT_TYPES.length; ++n) {
                                var r = OUTPUT_TYPES[n];
                                t[r] = createHmacOutputMethod(r, e);
                            }
                            return t;
                        };
                        function Sha256(e, t) {
                            t ? (blocks[0] = blocks[16] = blocks[1] = blocks[2] = blocks[3] = blocks[4] = blocks[5] = blocks[6] = blocks[7] = blocks[8] = blocks[9] = blocks[10] = blocks[11] = blocks[12] = blocks[13] = blocks[14] = blocks[15] = 0, 
                            this.blocks = blocks) : this.blocks = [ 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 ], 
                            e ? (this.h0 = 3238371032, this.h1 = 914150663, this.h2 = 812702999, this.h3 = 4144912697, 
                            this.h4 = 4290775857, this.h5 = 1750603025, this.h6 = 1694076839, this.h7 = 3204075428) : (this.h0 = 1779033703, 
                            this.h1 = 3144134277, this.h2 = 1013904242, this.h3 = 2773480762, this.h4 = 1359893119, 
                            this.h5 = 2600822924, this.h6 = 528734635, this.h7 = 1541459225), this.block = this.start = this.bytes = this.hBytes = 0, 
                            this.finalized = this.hashed = !1, this.first = !0, this.is224 = e;
                        }
                        function HmacSha256(e, t, n) {
                            var r, o = _typeof(e);
                            if ("string" === o) {
                                var i, a = [], s = e.length, c = 0;
                                for (r = 0; r < s; ++r) (i = e.charCodeAt(r)) < 128 ? a[c++] = i : i < 2048 ? (a[c++] = 192 | i >> 6, 
                                a[c++] = 128 | 63 & i) : i < 55296 || i >= 57344 ? (a[c++] = 224 | i >> 12, a[c++] = 128 | i >> 6 & 63, 
                                a[c++] = 128 | 63 & i) : (i = 65536 + ((1023 & i) << 10 | 1023 & e.charCodeAt(++r)), 
                                a[c++] = 240 | i >> 18, a[c++] = 128 | i >> 12 & 63, a[c++] = 128 | i >> 6 & 63, 
                                a[c++] = 128 | 63 & i);
                                e = a;
                            } else {
                                if ("object" !== o) throw new Error(ERROR);
                                if (null === e) throw new Error(ERROR);
                                if (ARRAY_BUFFER && e.constructor === ArrayBuffer) e = new Uint8Array(e); else if (!(Array.isArray(e) || ARRAY_BUFFER && ArrayBuffer.isView(e))) throw new Error(ERROR);
                            }
                            e.length > 64 && (e = new Sha256(t, !0).update(e).array());
                            var u = [], f = [];
                            for (r = 0; r < 64; ++r) {
                                var l = e[r] || 0;
                                u[r] = 92 ^ l, f[r] = 54 ^ l;
                            }
                            Sha256.call(this, t, n), this.update(f), this.oKeyPad = u, this.inner = !0, this.sharedMemory = n;
                        }
                        Sha256.prototype.update = function(e) {
                            if (!this.finalized) {
                                var t, n = _typeof(e);
                                if ("string" !== n) {
                                    if ("object" !== n) throw new Error(ERROR);
                                    if (null === e) throw new Error(ERROR);
                                    if (ARRAY_BUFFER && e.constructor === ArrayBuffer) e = new Uint8Array(e); else if (!(Array.isArray(e) || ARRAY_BUFFER && ArrayBuffer.isView(e))) throw new Error(ERROR);
                                    t = !0;
                                }
                                for (var r, o, i = 0, a = e.length, s = this.blocks; i < a; ) {
                                    if (this.hashed && (this.hashed = !1, s[0] = this.block, s[16] = s[1] = s[2] = s[3] = s[4] = s[5] = s[6] = s[7] = s[8] = s[9] = s[10] = s[11] = s[12] = s[13] = s[14] = s[15] = 0), 
                                    t) for (o = this.start; i < a && o < 64; ++i) s[o >> 2] |= e[i] << SHIFT[3 & o++]; else for (o = this.start; i < a && o < 64; ++i) (r = e.charCodeAt(i)) < 128 ? s[o >> 2] |= r << SHIFT[3 & o++] : r < 2048 ? (s[o >> 2] |= (192 | r >> 6) << SHIFT[3 & o++], 
                                    s[o >> 2] |= (128 | 63 & r) << SHIFT[3 & o++]) : r < 55296 || r >= 57344 ? (s[o >> 2] |= (224 | r >> 12) << SHIFT[3 & o++], 
                                    s[o >> 2] |= (128 | r >> 6 & 63) << SHIFT[3 & o++], s[o >> 2] |= (128 | 63 & r) << SHIFT[3 & o++]) : (r = 65536 + ((1023 & r) << 10 | 1023 & e.charCodeAt(++i)), 
                                    s[o >> 2] |= (240 | r >> 18) << SHIFT[3 & o++], s[o >> 2] |= (128 | r >> 12 & 63) << SHIFT[3 & o++], 
                                    s[o >> 2] |= (128 | r >> 6 & 63) << SHIFT[3 & o++], s[o >> 2] |= (128 | 63 & r) << SHIFT[3 & o++]);
                                    this.lastByteIndex = o, this.bytes += o - this.start, o >= 64 ? (this.block = s[16], 
                                    this.start = o - 64, this.hash(), this.hashed = !0) : this.start = o;
                                }
                                return this.bytes > 4294967295 && (this.hBytes += this.bytes / 4294967296 << 0, 
                                this.bytes = this.bytes % 4294967296), this;
                            }
                        }, Sha256.prototype.finalize = function() {
                            if (!this.finalized) {
                                this.finalized = !0;
                                var e = this.blocks, t = this.lastByteIndex;
                                e[16] = this.block, e[t >> 2] |= EXTRA[3 & t], this.block = e[16], t >= 56 && (this.hashed || this.hash(), 
                                e[0] = this.block, e[16] = e[1] = e[2] = e[3] = e[4] = e[5] = e[6] = e[7] = e[8] = e[9] = e[10] = e[11] = e[12] = e[13] = e[14] = e[15] = 0), 
                                e[14] = this.hBytes << 3 | this.bytes >>> 29, e[15] = this.bytes << 3, this.hash();
                            }
                        }, Sha256.prototype.hash = function() {
                            var e, t, n, r, o, i, a, s, c, u = this.h0, f = this.h1, l = this.h2, p = this.h3, h = this.h4, d = this.h5, _ = this.h6, g = this.h7, m = this.blocks;
                            for (e = 16; e < 64; ++e) t = ((o = m[e - 15]) >>> 7 | o << 25) ^ (o >>> 18 | o << 14) ^ o >>> 3, 
                            n = ((o = m[e - 2]) >>> 17 | o << 15) ^ (o >>> 19 | o << 13) ^ o >>> 10, m[e] = m[e - 16] + t + m[e - 7] + n << 0;
                            for (c = f & l, e = 0; e < 64; e += 4) this.first ? (this.is224 ? (i = 300032, g = (o = m[0] - 1413257819) - 150054599 << 0, 
                            p = o + 24177077 << 0) : (i = 704751109, g = (o = m[0] - 210244248) - 1521486534 << 0, 
                            p = o + 143694565 << 0), this.first = !1) : (t = (u >>> 2 | u << 30) ^ (u >>> 13 | u << 19) ^ (u >>> 22 | u << 10), 
                            r = (i = u & f) ^ u & l ^ c, g = p + (o = g + (n = (h >>> 6 | h << 26) ^ (h >>> 11 | h << 21) ^ (h >>> 25 | h << 7)) + (h & d ^ ~h & _) + K[e] + m[e]) << 0, 
                            p = o + (t + r) << 0), t = (p >>> 2 | p << 30) ^ (p >>> 13 | p << 19) ^ (p >>> 22 | p << 10), 
                            r = (a = p & u) ^ p & f ^ i, _ = l + (o = _ + (n = (g >>> 6 | g << 26) ^ (g >>> 11 | g << 21) ^ (g >>> 25 | g << 7)) + (g & h ^ ~g & d) + K[e + 1] + m[e + 1]) << 0, 
                            t = ((l = o + (t + r) << 0) >>> 2 | l << 30) ^ (l >>> 13 | l << 19) ^ (l >>> 22 | l << 10), 
                            r = (s = l & p) ^ l & u ^ a, d = f + (o = d + (n = (_ >>> 6 | _ << 26) ^ (_ >>> 11 | _ << 21) ^ (_ >>> 25 | _ << 7)) + (_ & g ^ ~_ & h) + K[e + 2] + m[e + 2]) << 0, 
                            t = ((f = o + (t + r) << 0) >>> 2 | f << 30) ^ (f >>> 13 | f << 19) ^ (f >>> 22 | f << 10), 
                            r = (c = f & l) ^ f & p ^ s, h = u + (o = h + (n = (d >>> 6 | d << 26) ^ (d >>> 11 | d << 21) ^ (d >>> 25 | d << 7)) + (d & _ ^ ~d & g) + K[e + 3] + m[e + 3]) << 0, 
                            u = o + (t + r) << 0;
                            this.h0 = this.h0 + u << 0, this.h1 = this.h1 + f << 0, this.h2 = this.h2 + l << 0, 
                            this.h3 = this.h3 + p << 0, this.h4 = this.h4 + h << 0, this.h5 = this.h5 + d << 0, 
                            this.h6 = this.h6 + _ << 0, this.h7 = this.h7 + g << 0;
                        }, Sha256.prototype.hex = function() {
                            this.finalize();
                            var e = this.h0, t = this.h1, n = this.h2, r = this.h3, o = this.h4, i = this.h5, a = this.h6, s = this.h7, c = HEX_CHARS[e >> 28 & 15] + HEX_CHARS[e >> 24 & 15] + HEX_CHARS[e >> 20 & 15] + HEX_CHARS[e >> 16 & 15] + HEX_CHARS[e >> 12 & 15] + HEX_CHARS[e >> 8 & 15] + HEX_CHARS[e >> 4 & 15] + HEX_CHARS[15 & e] + HEX_CHARS[t >> 28 & 15] + HEX_CHARS[t >> 24 & 15] + HEX_CHARS[t >> 20 & 15] + HEX_CHARS[t >> 16 & 15] + HEX_CHARS[t >> 12 & 15] + HEX_CHARS[t >> 8 & 15] + HEX_CHARS[t >> 4 & 15] + HEX_CHARS[15 & t] + HEX_CHARS[n >> 28 & 15] + HEX_CHARS[n >> 24 & 15] + HEX_CHARS[n >> 20 & 15] + HEX_CHARS[n >> 16 & 15] + HEX_CHARS[n >> 12 & 15] + HEX_CHARS[n >> 8 & 15] + HEX_CHARS[n >> 4 & 15] + HEX_CHARS[15 & n] + HEX_CHARS[r >> 28 & 15] + HEX_CHARS[r >> 24 & 15] + HEX_CHARS[r >> 20 & 15] + HEX_CHARS[r >> 16 & 15] + HEX_CHARS[r >> 12 & 15] + HEX_CHARS[r >> 8 & 15] + HEX_CHARS[r >> 4 & 15] + HEX_CHARS[15 & r] + HEX_CHARS[o >> 28 & 15] + HEX_CHARS[o >> 24 & 15] + HEX_CHARS[o >> 20 & 15] + HEX_CHARS[o >> 16 & 15] + HEX_CHARS[o >> 12 & 15] + HEX_CHARS[o >> 8 & 15] + HEX_CHARS[o >> 4 & 15] + HEX_CHARS[15 & o] + HEX_CHARS[i >> 28 & 15] + HEX_CHARS[i >> 24 & 15] + HEX_CHARS[i >> 20 & 15] + HEX_CHARS[i >> 16 & 15] + HEX_CHARS[i >> 12 & 15] + HEX_CHARS[i >> 8 & 15] + HEX_CHARS[i >> 4 & 15] + HEX_CHARS[15 & i] + HEX_CHARS[a >> 28 & 15] + HEX_CHARS[a >> 24 & 15] + HEX_CHARS[a >> 20 & 15] + HEX_CHARS[a >> 16 & 15] + HEX_CHARS[a >> 12 & 15] + HEX_CHARS[a >> 8 & 15] + HEX_CHARS[a >> 4 & 15] + HEX_CHARS[15 & a];
                            return this.is224 || (c += HEX_CHARS[s >> 28 & 15] + HEX_CHARS[s >> 24 & 15] + HEX_CHARS[s >> 20 & 15] + HEX_CHARS[s >> 16 & 15] + HEX_CHARS[s >> 12 & 15] + HEX_CHARS[s >> 8 & 15] + HEX_CHARS[s >> 4 & 15] + HEX_CHARS[15 & s]), 
                            c;
                        }, Sha256.prototype.toString = Sha256.prototype.hex, Sha256.prototype.digest = function() {
                            this.finalize();
                            var e = this.h0, t = this.h1, n = this.h2, r = this.h3, o = this.h4, i = this.h5, a = this.h6, s = this.h7, c = [ e >> 24 & 255, e >> 16 & 255, e >> 8 & 255, 255 & e, t >> 24 & 255, t >> 16 & 255, t >> 8 & 255, 255 & t, n >> 24 & 255, n >> 16 & 255, n >> 8 & 255, 255 & n, r >> 24 & 255, r >> 16 & 255, r >> 8 & 255, 255 & r, o >> 24 & 255, o >> 16 & 255, o >> 8 & 255, 255 & o, i >> 24 & 255, i >> 16 & 255, i >> 8 & 255, 255 & i, a >> 24 & 255, a >> 16 & 255, a >> 8 & 255, 255 & a ];
                            return this.is224 || c.push(s >> 24 & 255, s >> 16 & 255, s >> 8 & 255, 255 & s), 
                            c;
                        }, Sha256.prototype.array = Sha256.prototype.digest, Sha256.prototype.arrayBuffer = function() {
                            this.finalize();
                            var e = new ArrayBuffer(this.is224 ? 28 : 32), t = new DataView(e);
                            return t.setUint32(0, this.h0), t.setUint32(4, this.h1), t.setUint32(8, this.h2), 
                            t.setUint32(12, this.h3), t.setUint32(16, this.h4), t.setUint32(20, this.h5), t.setUint32(24, this.h6), 
                            this.is224 || t.setUint32(28, this.h7), e;
                        }, HmacSha256.prototype = new Sha256(), HmacSha256.prototype.finalize = function() {
                            if (Sha256.prototype.finalize.call(this), this.inner) {
                                this.inner = !1;
                                var e = this.array();
                                Sha256.call(this, this.is224, this.sharedMemory), this.update(this.oKeyPad), this.update(e), 
                                Sha256.prototype.finalize.call(this);
                            }
                        };
                        var exports = createMethod();
                        exports.sha256 = exports, exports.sha224 = createMethod(!0), exports.sha256.hmac = createHmacMethod(), 
                        exports.sha224.hmac = createHmacMethod(!0), module.exports = createMethod();
                    },
                    867: function(e, t, n) {
                        e.exports = n(322);
                    },
                    803: function(e, t, n) {
                        var r = n(814), o = n(145), i = n(537), a = n(415), s = n(210), c = n(870), u = n(511);
                        e.exports = function(e) {
                            return new Promise(function(t, f) {
                                var l = e.data, p = e.headers;
                                r.isFormData(l) && delete p["Content-Type"];
                                var h = new XMLHttpRequest();
                                if (e.auth) {
                                    var d = e.auth.username || "", _ = e.auth.password || "";
                                    p.Authorization = "Basic " + btoa(d + ":" + _);
                                }
                                var g = a(e.baseURL, e.url);
                                if (h.open(e.method.toUpperCase(), i(g, e.params, e.paramsSerializer), !0), h.timeout = e.timeout, 
                                h.onreadystatechange = function() {
                                    if (h && 4 === h.readyState && (0 !== h.status || h.responseURL && 0 === h.responseURL.indexOf("file:"))) {
                                        var n = "getAllResponseHeaders" in h ? s(h.getAllResponseHeaders()) : null, r = {
                                            data: e.responseType && "text" !== e.responseType ? h.response : h.responseText,
                                            status: h.status,
                                            statusText: h.statusText,
                                            headers: n,
                                            config: e,
                                            request: h
                                        };
                                        o(t, f, r), h = null;
                                    }
                                }, h.onabort = function() {
                                    h && (f(u("Request aborted", e, "ECONNABORTED", h)), h = null);
                                }, h.onerror = function() {
                                    f(u("Network Error", e, null, h)), h = null;
                                }, h.ontimeout = function() {
                                    var t = "timeout of " + e.timeout + "ms exceeded";
                                    e.timeoutErrorMessage && (t = e.timeoutErrorMessage), f(u(t, e, "ECONNABORTED", h)), 
                                    h = null;
                                }, r.isStandardBrowserEnv()) {
                                    var m = n(970), y = (e.withCredentials || c(g)) && e.xsrfCookieName ? m.read(e.xsrfCookieName) : void 0;
                                    y && (p[e.xsrfHeaderName] = y);
                                }
                                if ("setRequestHeader" in h && r.forEach(p, function(e, t) {
                                    void 0 === l && "content-type" === t.toLowerCase() ? delete p[t] : h.setRequestHeader(t, e);
                                }), r.isUndefined(e.withCredentials) || (h.withCredentials = !!e.withCredentials), 
                                e.responseType) try {
                                    h.responseType = e.responseType;
                                } catch (t) {
                                    if ("json" !== e.responseType) throw t;
                                }
                                "function" == typeof e.onDownloadProgress && h.addEventListener("progress", e.onDownloadProgress), 
                                "function" == typeof e.onUploadProgress && h.upload && h.upload.addEventListener("progress", e.onUploadProgress), 
                                e.cancelToken && e.cancelToken.promise.then(function(e) {
                                    h && (h.abort(), f(e), h = null);
                                }), void 0 === l && (l = null), h.send(l);
                            });
                        };
                    },
                    322: function(e, t, n) {
                        var r = n(814), o = n(984), i = n(874), a = n(713);
                        function s(e) {
                            var t = new i(e), n = o(i.prototype.request, t);
                            return r.extend(n, i.prototype, t), r.extend(n, t), n;
                        }
                        var c = s(n(50));
                        c.Axios = i, c.create = function(e) {
                            return s(a(c.defaults, e));
                        }, c.Cancel = n(455), c.CancelToken = n(462), c.isCancel = n(652), c.all = function(e) {
                            return Promise.all(e);
                        }, c.spread = n(396), e.exports = c, e.exports.default = c;
                    },
                    455: function(e) {
                        function t(e) {
                            this.message = e;
                        }
                        t.prototype.toString = function() {
                            return "Cancel" + (this.message ? ": " + this.message : "");
                        }, t.prototype.__CANCEL__ = !0, e.exports = t;
                    },
                    462: function(e, t, n) {
                        var r = n(455);
                        function o(e) {
                            if ("function" != typeof e) throw new TypeError("executor must be a function.");
                            var t;
                            this.promise = new Promise(function(e) {
                                t = e;
                            });
                            var n = this;
                            e(function(e) {
                                n.reason || (n.reason = new r(e), t(n.reason));
                            });
                        }
                        o.prototype.throwIfRequested = function() {
                            if (this.reason) throw this.reason;
                        }, o.source = function() {
                            var e;
                            return {
                                token: new o(function(t) {
                                    e = t;
                                }),
                                cancel: e
                            };
                        }, e.exports = o;
                    },
                    652: function(e) {
                        e.exports = function(e) {
                            return !(!e || !e.__CANCEL__);
                        };
                    },
                    874: function(e, t, n) {
                        var r = n(814), o = n(537), i = n(962), a = n(281), s = n(713);
                        function c(e) {
                            this.defaults = e, this.interceptors = {
                                request: new i(),
                                response: new i()
                            };
                        }
                        c.prototype.request = function(e) {
                            "string" == typeof e ? (e = arguments[1] || {}).url = arguments[0] : e = e || {}, 
                            (e = s(this.defaults, e)).method ? e.method = e.method.toLowerCase() : this.defaults.method ? e.method = this.defaults.method.toLowerCase() : e.method = "get";
                            var t = [ a, void 0 ], n = Promise.resolve(e);
                            for (this.interceptors.request.forEach(function(e) {
                                t.unshift(e.fulfilled, e.rejected);
                            }), this.interceptors.response.forEach(function(e) {
                                t.push(e.fulfilled, e.rejected);
                            }); t.length; ) n = n.then(t.shift(), t.shift());
                            return n;
                        }, c.prototype.getUri = function(e) {
                            return e = s(this.defaults, e), o(e.url, e.params, e.paramsSerializer).replace(/^\?/, "");
                        }, r.forEach([ "delete", "get", "head", "options" ], function(e) {
                            c.prototype[e] = function(t, n) {
                                return this.request(r.merge(n || {}, {
                                    method: e,
                                    url: t
                                }));
                            };
                        }), r.forEach([ "post", "put", "patch" ], function(e) {
                            c.prototype[e] = function(t, n, o) {
                                return this.request(r.merge(o || {}, {
                                    method: e,
                                    url: t,
                                    data: n
                                }));
                            };
                        }), e.exports = c;
                    },
                    962: function(e, t, n) {
                        var r = n(814);
                        function o() {
                            this.handlers = [];
                        }
                        o.prototype.use = function(e, t) {
                            return this.handlers.push({
                                fulfilled: e,
                                rejected: t
                            }), this.handlers.length - 1;
                        }, o.prototype.eject = function(e) {
                            this.handlers[e] && (this.handlers[e] = null);
                        }, o.prototype.forEach = function(e) {
                            r.forEach(this.handlers, function(t) {
                                null !== t && e(t);
                            });
                        }, e.exports = o;
                    },
                    415: function(e, t, n) {
                        var r = n(788), o = n(188);
                        e.exports = function(e, t) {
                            return e && !r(t) ? o(e, t) : t;
                        };
                    },
                    511: function(e, t, n) {
                        var r = n(474);
                        e.exports = function(e, t, n, o, i) {
                            var a = new Error(e);
                            return r(a, t, n, o, i);
                        };
                    },
                    281: function(e, t, n) {
                        var r = n(814), o = n(72), i = n(652), a = n(50);
                        function s(e) {
                            e.cancelToken && e.cancelToken.throwIfRequested();
                        }
                        e.exports = function(e) {
                            return s(e), e.headers = e.headers || {}, e.data = o(e.data, e.headers, e.transformRequest), 
                            e.headers = r.merge(e.headers.common || {}, e.headers[e.method] || {}, e.headers), 
                            r.forEach([ "delete", "get", "head", "post", "put", "patch", "common" ], function(t) {
                                delete e.headers[t];
                            }), (e.adapter || a.adapter)(e).then(function(t) {
                                return s(e), t.data = o(t.data, t.headers, e.transformResponse), t;
                            }, function(t) {
                                return i(t) || (s(e), t && t.response && (t.response.data = o(t.response.data, t.response.headers, e.transformResponse))), 
                                Promise.reject(t);
                            });
                        };
                    },
                    474: function(e) {
                        e.exports = function(e, t, n, r, o) {
                            return e.config = t, n && (e.code = n), e.request = r, e.response = o, e.isAxiosError = !0, 
                            e.toJSON = function() {
                                return {
                                    message: this.message,
                                    name: this.name,
                                    description: this.description,
                                    number: this.number,
                                    fileName: this.fileName,
                                    lineNumber: this.lineNumber,
                                    columnNumber: this.columnNumber,
                                    stack: this.stack,
                                    config: this.config,
                                    code: this.code
                                };
                            }, e;
                        };
                    },
                    713: function(e, t, n) {
                        var r = n(814);
                        e.exports = function(e, t) {
                            t = t || {};
                            var n = {}, o = [ "url", "method", "params", "data" ], i = [ "headers", "auth", "proxy" ], a = [ "baseURL", "url", "transformRequest", "transformResponse", "paramsSerializer", "timeout", "withCredentials", "adapter", "responseType", "xsrfCookieName", "xsrfHeaderName", "onUploadProgress", "onDownloadProgress", "maxContentLength", "validateStatus", "maxRedirects", "httpAgent", "httpsAgent", "cancelToken", "socketPath" ];
                            r.forEach(o, function(e) {
                                void 0 !== t[e] && (n[e] = t[e]);
                            }), r.forEach(i, function(o) {
                                r.isObject(t[o]) ? n[o] = r.deepMerge(e[o], t[o]) : void 0 !== t[o] ? n[o] = t[o] : r.isObject(e[o]) ? n[o] = r.deepMerge(e[o]) : void 0 !== e[o] && (n[o] = e[o]);
                            }), r.forEach(a, function(r) {
                                void 0 !== t[r] ? n[r] = t[r] : void 0 !== e[r] && (n[r] = e[r]);
                            });
                            var s = o.concat(i).concat(a), c = Object.keys(t).filter(function(e) {
                                return -1 === s.indexOf(e);
                            });
                            return r.forEach(c, function(r) {
                                void 0 !== t[r] ? n[r] = t[r] : void 0 !== e[r] && (n[r] = e[r]);
                            }), n;
                        };
                    },
                    145: function(e, t, n) {
                        var r = n(511);
                        e.exports = function(e, t, n) {
                            var o = n.config.validateStatus;
                            !o || o(n.status) ? e(n) : t(r("Request failed with status code " + n.status, n.config, null, n.request, n));
                        };
                    },
                    72: function(e, t, n) {
                        var r = n(814);
                        e.exports = function(e, t, n) {
                            return r.forEach(n, function(n) {
                                e = n(e, t);
                            }), e;
                        };
                    },
                    50: function(e, t, n) {
                        var r = n(814), o = n(517), i = {
                            "Content-Type": "application/x-www-form-urlencoded"
                        };
                        function a(e, t) {
                            !r.isUndefined(e) && r.isUndefined(e["Content-Type"]) && (e["Content-Type"] = t);
                        }
                        var s, c = {
                            adapter: (("undefined" != typeof XMLHttpRequest || "undefined" != typeof process && "[object process]" === Object.prototype.toString.call(process)) && (s = n(803)), 
                            s),
                            transformRequest: [ function(e, t) {
                                return o(t, "Accept"), o(t, "Content-Type"), r.isFormData(e) || r.isArrayBuffer(e) || r.isBuffer(e) || r.isStream(e) || r.isFile(e) || r.isBlob(e) ? e : r.isArrayBufferView(e) ? e.buffer : r.isURLSearchParams(e) ? (a(t, "application/x-www-form-urlencoded;charset=utf-8"), 
                                e.toString()) : r.isObject(e) ? (a(t, "application/json;charset=utf-8"), JSON.stringify(e)) : e;
                            } ],
                            transformResponse: [ function(e) {
                                if ("string" == typeof e) try {
                                    e = JSON.parse(e);
                                } catch (e) {}
                                return e;
                            } ],
                            timeout: 0,
                            xsrfCookieName: "XSRF-TOKEN",
                            xsrfHeaderName: "X-XSRF-TOKEN",
                            maxContentLength: -1,
                            validateStatus: function(e) {
                                return e >= 200 && e < 300;
                            },
                            headers: {
                                common: {
                                    Accept: "application/json, text/plain, */*"
                                }
                            }
                        };
                        r.forEach([ "delete", "get", "head" ], function(e) {
                            c.headers[e] = {};
                        }), r.forEach([ "post", "put", "patch" ], function(e) {
                            c.headers[e] = r.merge(i);
                        }), e.exports = c;
                    },
                    984: function(e) {
                        e.exports = function(e, t) {
                            return function() {
                                for (var n = new Array(arguments.length), r = 0; r < n.length; r++) n[r] = arguments[r];
                                return e.apply(t, n);
                            };
                        };
                    },
                    537: function(e, t, n) {
                        var r = n(814);
                        function o(e) {
                            return encodeURIComponent(e).replace(/%40/gi, "@").replace(/%3A/gi, ":").replace(/%24/g, "$").replace(/%2C/gi, ",").replace(/%20/g, "+").replace(/%5B/gi, "[").replace(/%5D/gi, "]");
                        }
                        e.exports = function(e, t, n) {
                            if (!t) return e;
                            var i;
                            if (n) i = n(t); else if (r.isURLSearchParams(t)) i = t.toString(); else {
                                var a = [];
                                r.forEach(t, function(e, t) {
                                    null != e && (r.isArray(e) ? t += "[]" : e = [ e ], r.forEach(e, function(e) {
                                        r.isDate(e) ? e = e.toISOString() : r.isObject(e) && (e = JSON.stringify(e)), a.push(o(t) + "=" + o(e));
                                    }));
                                }), i = a.join("&");
                            }
                            if (i) {
                                var s = e.indexOf("#");
                                -1 !== s && (e = e.slice(0, s)), e += (-1 === e.indexOf("?") ? "?" : "&") + i;
                            }
                            return e;
                        };
                    },
                    188: function(e) {
                        e.exports = function(e, t) {
                            return t ? e.replace(/\/+$/, "") + "/" + t.replace(/^\/+/, "") : e;
                        };
                    },
                    970: function(e, t, n) {
                        var r = n(814);
                        e.exports = r.isStandardBrowserEnv() ? {
                            write: function(e, t, n, o, i, a) {
                                var s = [];
                                s.push(e + "=" + encodeURIComponent(t)), r.isNumber(n) && s.push("expires=" + new Date(n).toGMTString()), 
                                r.isString(o) && s.push("path=" + o), r.isString(i) && s.push("domain=" + i), !0 === a && s.push("secure"), 
                                document.cookie = s.join("; ");
                            },
                            read: function(e) {
                                var t = document.cookie.match(new RegExp("(^|;\\s*)(" + e + ")=([^;]*)"));
                                return t ? decodeURIComponent(t[3]) : null;
                            },
                            remove: function(e) {
                                this.write(e, "", Date.now() - 864e5);
                            }
                        } : {
                            write: function() {},
                            read: function() {
                                return null;
                            },
                            remove: function() {}
                        };
                    },
                    788: function(e) {
                        e.exports = function(e) {
                            return /^([a-z][a-z\d\+\-\.]*:)?\/\//i.test(e);
                        };
                    },
                    870: function(e, t, n) {
                        var r = n(814);
                        e.exports = r.isStandardBrowserEnv() ? function() {
                            var e, t = /(msie|trident)/i.test(navigator.userAgent), n = document.createElement("a");
                            function o(e) {
                                var r = e;
                                return t && (n.setAttribute("href", r), r = n.href), n.setAttribute("href", r), 
                                {
                                    href: n.href,
                                    protocol: n.protocol ? n.protocol.replace(/:$/, "") : "",
                                    host: n.host,
                                    search: n.search ? n.search.replace(/^\?/, "") : "",
                                    hash: n.hash ? n.hash.replace(/^#/, "") : "",
                                    hostname: n.hostname,
                                    port: n.port,
                                    pathname: "/" === n.pathname.charAt(0) ? n.pathname : "/" + n.pathname
                                };
                            }
                            return e = o(window.location.href), function(t) {
                                var n = r.isString(t) ? o(t) : t;
                                return n.protocol === e.protocol && n.host === e.host;
                            };
                        }() : function() {
                            return !0;
                        };
                    },
                    517: function(e, t, n) {
                        var r = n(814);
                        e.exports = function(e, t) {
                            r.forEach(e, function(n, r) {
                                r !== t && r.toUpperCase() === t.toUpperCase() && (e[t] = n, delete e[r]);
                            });
                        };
                    },
                    210: function(e, t, n) {
                        var r = n(814), o = [ "age", "authorization", "content-length", "content-type", "etag", "expires", "from", "host", "if-modified-since", "if-unmodified-since", "last-modified", "location", "max-forwards", "proxy-authorization", "referer", "retry-after", "user-agent" ];
                        e.exports = function(e) {
                            var t, n, i, a = {};
                            return e ? (r.forEach(e.split("\n"), function(e) {
                                if (i = e.indexOf(":"), t = r.trim(e.substr(0, i)).toLowerCase(), n = r.trim(e.substr(i + 1)), 
                                t) {
                                    if (a[t] && o.indexOf(t) >= 0) return;
                                    a[t] = "set-cookie" === t ? (a[t] ? a[t] : []).concat([ n ]) : a[t] ? a[t] + ", " + n : n;
                                }
                            }), a) : a;
                        };
                    },
                    396: function(e) {
                        e.exports = function(e) {
                            return function(t) {
                                return e.apply(null, t);
                            };
                        };
                    },
                    814: function(e, t, n) {
                        function r(e) {
                            return (r = "function" == typeof Symbol && "symbol" == _typeof3(Symbol.iterator) ? function(e) {
                                return _typeof3(e);
                            } : function(e) {
                                return e && "function" == typeof Symbol && e.constructor === Symbol && e !== Symbol.prototype ? "symbol" : _typeof3(e);
                            })(e);
                        }
                        var o = n(984), i = Object.prototype.toString;
                        function a(e) {
                            return "[object Array]" === i.call(e);
                        }
                        function s(e) {
                            return void 0 === e;
                        }
                        function c(e) {
                            return null !== e && "object" === r(e);
                        }
                        function u(e) {
                            return "[object Function]" === i.call(e);
                        }
                        function f(e, t) {
                            if (null != e) if ("object" !== r(e) && (e = [ e ]), a(e)) for (var n = 0, o = e.length; n < o; n++) t.call(null, e[n], n, e); else for (var i in e) Object.prototype.hasOwnProperty.call(e, i) && t.call(null, e[i], i, e);
                        }
                        e.exports = {
                            isArray: a,
                            isArrayBuffer: function(e) {
                                return "[object ArrayBuffer]" === i.call(e);
                            },
                            isBuffer: function(e) {
                                return null !== e && !s(e) && null !== e.constructor && !s(e.constructor) && "function" == typeof e.constructor.isBuffer && e.constructor.isBuffer(e);
                            },
                            isFormData: function(e) {
                                return "undefined" != typeof FormData && e instanceof FormData;
                            },
                            isArrayBufferView: function(e) {
                                return "undefined" != typeof ArrayBuffer && ArrayBuffer.isView ? ArrayBuffer.isView(e) : e && e.buffer && e.buffer instanceof ArrayBuffer;
                            },
                            isString: function(e) {
                                return "string" == typeof e;
                            },
                            isNumber: function(e) {
                                return "number" == typeof e;
                            },
                            isObject: c,
                            isUndefined: s,
                            isDate: function(e) {
                                return "[object Date]" === i.call(e);
                            },
                            isFile: function(e) {
                                return "[object File]" === i.call(e);
                            },
                            isBlob: function(e) {
                                return "[object Blob]" === i.call(e);
                            },
                            isFunction: u,
                            isStream: function(e) {
                                return c(e) && u(e.pipe);
                            },
                            isURLSearchParams: function(e) {
                                return "undefined" != typeof URLSearchParams && e instanceof URLSearchParams;
                            },
                            isStandardBrowserEnv: function() {
                                return ("undefined" == typeof navigator || "ReactNative" !== navigator.product && "NativeScript" !== navigator.product && "NS" !== navigator.product) && "undefined" != typeof window && "undefined" != typeof document;
                            },
                            forEach: f,
                            merge: function e() {
                                var t = {};
                                function n(n, o) {
                                    "object" === r(t[o]) && "object" === r(n) ? t[o] = e(t[o], n) : t[o] = n;
                                }
                                for (var o = 0, i = arguments.length; o < i; o++) f(arguments[o], n);
                                return t;
                            },
                            deepMerge: function e() {
                                var t = {};
                                function n(n, o) {
                                    "object" === r(t[o]) && "object" === r(n) ? t[o] = e(t[o], n) : "object" === r(n) ? t[o] = e({}, n) : t[o] = n;
                                }
                                for (var o = 0, i = arguments.length; o < i; o++) f(arguments[o], n);
                                return t;
                            },
                            extend: function(e, t, n) {
                                return f(t, function(t, r) {
                                    e[r] = n && "function" == typeof t ? o(t, n) : t;
                                }), e;
                            },
                            trim: function(e) {
                                return e.replace(/^\s*/, "").replace(/\s*$/, "");
                            }
                        };
                    },
                    376: function(e) {
                        function t(e, t) {
                            for (var n = 0; n < t.length; n++) {
                                var r = t[n];
                                r.enumerable = r.enumerable || !1, r.configurable = !0, "value" in r && (r.writable = !0), 
                                Object.defineProperty(e, r.key, r);
                            }
                        }
                        function n(e, t, n) {
                            return t in e ? Object.defineProperty(e, t, {
                                value: n,
                                enumerable: !0,
                                configurable: !0,
                                writable: !0
                            }) : e[t] = n, e;
                        }
                        var r = function(e, n, r) {
                            return n && t(e.prototype, n), r && t(e, r), Object.defineProperty(e, "prototype", {
                                writable: !1
                            }), e;
                        }(function e() {
                            !function(e, t) {
                                if (!(e instanceof t)) throw new TypeError("Cannot call a class as a function");
                            }(this, e), n(this, "calendarId", ""), n(this, "corpId", ""), n(this, "corpName", ""), 
                            n(this, "calendarUid", ""), n(this, "weMeetUid", ""), n(this, "summary", ""), n(this, "description", ""), 
                            n(this, "version", ""), n(this, "accessRole", 0), n(this, "isPrimary", !1), n(this, "calType", 0), 
                            n(this, "location", ""), n(this, "timezone", ""), n(this, "isShare", !1), n(this, "color", ""), 
                            n(this, "bgColor", ""), n(this, "fgColor", ""), n(this, "isHidden", !1), n(this, "isSelected", !1), 
                            n(this, "createTime", 0), n(this, "updateTime", 0), n(this, "summaryOverrided", "");
                        });
                        e.exports = r;
                    },
                    119: function(e, t, n) {
                        function r(e, t) {
                            var n = Object.keys(e);
                            if (Object.getOwnPropertySymbols) {
                                var r = Object.getOwnPropertySymbols(e);
                                t && (r = r.filter(function(t) {
                                    return Object.getOwnPropertyDescriptor(e, t).enumerable;
                                })), n.push.apply(n, r);
                            }
                            return n;
                        }
                        function o(e) {
                            for (var t = 1; t < arguments.length; t++) {
                                var n = null != arguments[t] ? arguments[t] : {};
                                t % 2 ? r(Object(n), !0).forEach(function(t) {
                                    a(e, t, n[t]);
                                }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(n)) : r(Object(n)).forEach(function(t) {
                                    Object.defineProperty(e, t, Object.getOwnPropertyDescriptor(n, t));
                                });
                            }
                            return e;
                        }
                        function i(e, t) {
                            for (var n = 0; n < t.length; n++) {
                                var r = t[n];
                                r.enumerable = r.enumerable || !1, r.configurable = !0, "value" in r && (r.writable = !0), 
                                Object.defineProperty(e, r.key, r);
                            }
                        }
                        function a(e, t, n) {
                            return t in e ? Object.defineProperty(e, t, {
                                value: n,
                                enumerable: !0,
                                configurable: !0,
                                writable: !0
                            }) : e[t] = n, e;
                        }
                        var s = n(334), c = n(200).API_NAME, u = n(389), f = n(376), l = n(467), p = l.EventInfo, h = l.MeetingInfo, d = n(382), _ = n(991), g = function() {
                            function e() {
                                !function(e, t) {
                                    if (!(e instanceof t)) throw new TypeError("Cannot call a class as a function");
                                }(this, e), a(this, "accountConfig", void 0), this.logger = new _();
                            }
                            var t, n, r;
                            return t = e, r = [ {
                                key: "getInstance",
                                value: function() {
                                    return void 0 === e.prototype.instance && (e.prototype.instance = new e()), e.prototype.instance;
                                }
                            } ], (n = [ {
                                key: "init",
                                value: function() {
                                    this.logger.info("sdk init");
                                }
                            }, {
                                key: "setLogger",
                                value: function(e) {
                                    e && (this.logger = e);
                                }
                            }, {
                                key: "setAccountConfig",
                                value: function(e) {
                                    this.accountConfig = o(o({}, this.accountConfig), e), s.getInstance().setConfig(e);
                                }
                            }, {
                                key: "getCalendarInfoList",
                                value: function(e) {
                                    var t = this, n = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {
                                        interface_version: 1
                                    };
                                    return new Promise(function(r, o) {
                                        s.getInstance().get(c.GET_CALENDAR_LIST, e || {}, n).then(function(e) {
                                            if (e) {
                                                var t = [];
                                                if (e.userCalendar && e.userCalendar.forEach(function(e) {
                                                    for (var n = e.corp_id, r = e.corp_name, o = e.cal_uid, i = e.wemeet_uid, a = e.user_type, s = 0; s < e.list.length; s++) {
                                                        var c = u.parseCalendarInfo(e.list[s]);
                                                        c.corpId = n, c.corpName = r, c.calendarUid = o, c.weMeetUid = i, c.userType = a, 
                                                        c.isDefault = e.list[s].is_default, t.push(c);
                                                    }
                                                }), e.commonCalendar) for (var n = 0; n < e.commonCalendar.length; n++) t.push(u.parseCalendarInfo(e.commonCalendar[n]));
                                                var i = e.syncOption, a = e.isExistWemeet;
                                                r({
                                                    calendarList: t,
                                                    syncInfo: i,
                                                    exitWemeetAccount: a
                                                });
                                            } else o({
                                                code: -1
                                            });
                                        }).catch(function(e) {
                                            t.logger.info(e, "SDK"), o(e);
                                        });
                                    });
                                }
                            }, {
                                key: "getEventListByOffset",
                                value: function(e, t, n, r, o, i) {
                                    var a = this, f = m(e, t, n);
                                    if (f.code < 0) return Promise.reject(f);
                                    var l = {
                                        calendars: e,
                                        event_types: t.join(","),
                                        offset: r,
                                        limit: o,
                                        version: this.accountConfig.appVersion
                                    };
                                    return i ? l.end_time = Math.floor(n / 1e3) : l.start_time = Math.floor(n / 1e3), 
                                    this.logger.info({
                                        getEventListByOffset_req: l
                                    }, "SDK"), new Promise(function(e, t) {
                                        s.getInstance().post(c.GET_EVENT_LIST, l).then(function(n) {
                                            if (a.logger.info({
                                                getEventListByOffset_rsp: n
                                            }, "SDK"), n) {
                                                for (var r = [], o = 0; o < n.list.length; o++) r.push(u.parserEventInfo(n.list[o]));
                                                e(r), a.logger.info({
                                                    getEventListByOffset_parser_list: r
                                                }, "SDK");
                                            } else t({
                                                code: -1
                                            });
                                        }).catch(function(e) {
                                            t(e);
                                        });
                                    });
                                }
                            }, {
                                key: "getEventListByDay",
                                value: function(e, t, n, r, o) {
                                    var i = this, a = m(e, t, n);
                                    if (a.code < 0) return this.logger.error("getEventListByDay params error", "SDK"), 
                                    Promise.reject(a);
                                    var f = {
                                        calendars: e,
                                        event_types: t.join(","),
                                        day_times: Math.floor(n / 1e3).toString(10),
                                        offset: r,
                                        limit: o,
                                        timezone: y(),
                                        version: this.accountConfig.appVersion
                                    };
                                    return this.logger.info({
                                        getEventListByDay_req: f
                                    }, "SDK"), new Promise(function(e, t) {
                                        s.getInstance().post(c.GET_DAY_EVENT_LIST, f).then(function(n) {
                                            if (i.logger.info({
                                                getEventListByDay_rsp: n
                                            }, "SDK"), n) {
                                                for (var r = [], o = 0; o < n.list.length; o++) r.push(u.parserEventInfo(n.list[o]));
                                                e(r);
                                            } else t({
                                                code: -1
                                            });
                                        }).catch(function(e) {
                                            t(e);
                                        });
                                    });
                                }
                            }, {
                                key: "getEventListByMonth",
                                value: function(e, t, n, r, o) {
                                    var i = this, a = m(e, t, n);
                                    if (a.code < 0) return this.logger.error("getEventListByMonth params error", "SDK"), 
                                    Promise.reject(a);
                                    var f = {
                                        calendars: e,
                                        event_types: t.join(","),
                                        start_day: Math.floor(n / 1e3).toString(10),
                                        end_day: Math.floor(r / 1e3).toString(10),
                                        limit: o,
                                        timezone: y()
                                    };
                                    return this.logger.info({
                                        getEventListByMonth: f
                                    }, "SDK"), new Promise(function(e, t) {
                                        s.getInstance().post(c.GET_MONTH_EVENT_LIST, f).then(function(n) {
                                            if (i.logger.info({
                                                getEventListByMonth_rsp: n
                                            }, "SDK"), n) {
                                                for (var r = [], o = function(e) {
                                                    var t = {
                                                        date: n[e].date,
                                                        totalCount: n[e].cnt,
                                                        eventList: []
                                                    };
                                                    n[e].list.forEach(function(e) {
                                                        t.eventList.push(u.parserEventInfo(e));
                                                    }), r.push(t);
                                                }, a = 0; a < n.length; a++) o(a);
                                                e(r);
                                            } else t({
                                                code: -1
                                            });
                                        }).catch(function(e) {
                                            t(e);
                                        });
                                    });
                                }
                            }, {
                                key: "getEventListByWeek",
                                value: function(e, t, n, r, o) {
                                    var i = this, a = m(e, t, n);
                                    if (a.code < 0) return this.logger.error("getEventListByMonth params error", "SDK"), 
                                    Promise.reject(a);
                                    var f = {
                                        calendars: e,
                                        event_types: t.join(","),
                                        start_day: Math.floor(n / 1e3).toString(10),
                                        end_day: Math.floor(r / 1e3).toString(10),
                                        limit: o,
                                        timezone: y()
                                    };
                                    return this.logger.info({
                                        getEventListByMonth: f
                                    }, "SDK"), new Promise(function(e, t) {
                                        s.getInstance().post(c.GET_WEEK_EVENT_LIST, f).then(function(n) {
                                            if (i.logger.info({
                                                getEventListByWeek_rsp: n
                                            }, "SDK"), n) {
                                                for (var r = [], o = function(e) {
                                                    var t = {
                                                        date: n[e].date,
                                                        totalCount: n[e].cnt,
                                                        eventList: []
                                                    };
                                                    n[e].list.forEach(function(e) {
                                                        t.eventList.push(u.parserEventInfo(e));
                                                    }), r.push(t);
                                                }, a = 0; a < n.length; a++) o(a);
                                                e(r);
                                            } else t({
                                                code: -1
                                            });
                                        }).catch(function(e) {
                                            t(e);
                                        });
                                    });
                                }
                            }, {
                                key: "getScheduleOverView",
                                value: function(e, t, n, r) {
                                    var o = m(e, t, n);
                                    if (o.code < 0) return Promise.reject(o);
                                    var i = {
                                        calendars: e,
                                        event_types: t.join(","),
                                        start_day: Math.floor(n / 1e3),
                                        end_day: Math.floor(r / 1e3),
                                        timezone: y(),
                                        version: this.accountConfig.appVersion
                                    };
                                    return new Promise(function(e, t) {
                                        s.getInstance().post(c.GET_OVER_VIEW, i).then(function(n) {
                                            if (n) {
                                                for (var r = [], o = 0; o < n.length; o++) r.push(u.paresOverview(n[o]));
                                                e(r);
                                            } else t({
                                                code: -1
                                            });
                                        }).catch(function(e) {
                                            t(e);
                                        });
                                    });
                                }
                            }, {
                                key: "updateCalendarInfos",
                                value: function(e) {
                                    if (!Array.isArray(e) || 0 === e.length) return Promise.reject({
                                        code: -1,
                                        msg: "calendarInfoList error!"
                                    });
                                    for (var t = 0; t < e.length; t++) if (!e[t].id) return Promise.reject({
                                        code: -1,
                                        msg: "calendarInfo miss id!"
                                    });
                                    var n = {
                                        calendar_info: e
                                    };
                                    return new Promise(function(e, t) {
                                        s.getInstance().post(c.UPDATE_CALENDAR, n).then(function(t) {
                                            e(t);
                                        }).catch(function(e) {
                                            t(e);
                                        });
                                    });
                                }
                            }, {
                                key: "createScheduleEvent",
                                value: function(e) {
                                    var t = this;
                                    if (!e.calendar_id || !e.subject || !e.start_time) return Promise.reject({
                                        code: -1,
                                        msg: "eventInfo miss need param!"
                                    });
                                    var n = o({}, e), r = n.rrule ? c.CREATE_RECURRING_SCHEDULE : c.CREATE_SCHEDULE;
                                    return new Promise(function(e, o) {
                                        s.getInstance().post(r, n).then(function(n) {
                                            t.logger.info({
                                                createScheduleEvent_resp: n
                                            }, "SDK"), e(n);
                                        }).catch(function(e) {
                                            t.logger.info({
                                                createScheduleEvent_resp: e
                                            }, "SDK"), o(e);
                                        });
                                    });
                                }
                            }, {
                                key: "editEvent",
                                value: function(e, t) {
                                    var n = this;
                                    if (!t.calendar_id || !t.subject || !t.start_time) return Promise.reject({
                                        code: -1,
                                        msg: "eventInfo miss need param!"
                                    });
                                    var r, i = o({}, t);
                                    switch (e) {
                                      case 0:
                                        r = c.EDIT_EVENT, i.event_id = t.eventId;
                                        break;

                                      case 1:
                                        r = c.EDIT_RECURRING_EVENT, i.contain_future = 1;
                                        break;

                                      case 2:
                                        r = c.EDIT_RECURRING_EVENT, i.contain_future = 2;
                                        break;

                                      case 3:
                                        r = c.EDIT_RECURRING_EVENT, i.event_id = t.originEventId, i.contain_future = 3;
                                        break;

                                      default:
                                        return Promise.reject({
                                            code: -1,
                                            msg: "unknown editEvent type!"
                                        });
                                    }
                                    return new Promise(function(e, t) {
                                        s.getInstance().post(r, i).then(function(t) {
                                            n.logger.info({
                                                editEvent_resp: t
                                            }, "SDK"), e(t);
                                        }).catch(function(e) {
                                            n.logger.info({
                                                editEvent_resp: e
                                            }, "SDK"), t(e);
                                        });
                                    });
                                }
                            }, {
                                key: "deleteScheduleEvent",
                                value: function(e, t, n, r, o) {
                                    var i, a = this, u = {
                                        cal_uid: n,
                                        corp_id: r,
                                        calendar_id: o
                                    };
                                    switch (console.log("deleteScheduleEvent", e, 1 === e), e) {
                                      case 0:
                                        i = c.DELETE_EVENT, u.event_id = t.eventId;
                                        break;

                                      case 1:
                                        i = c.DELETE_RECURRING_EVENT, u.event_id = t.eventId, u.parent_event_id = t.parentEventId, 
                                        u.period_start_time = Math.floor(t.startTime / 1e3), u.contain_future = 1;
                                        break;

                                      case 2:
                                        i = c.DELETE_RECURRING_EVENT, u.event_id = t.eventId, u.parent_event_id = t.parentEventId, 
                                        u.period_start_time = Math.floor(t.startTime / 1e3), u.contain_future = 2;
                                        break;

                                      case 3:
                                        i = c.DELETE_RECURRING_EVENT, u.event_id = t.originEventId, u.contain_future = 3;
                                        break;

                                      default:
                                        return Promise.reject({
                                            code: -1,
                                            msg: "unknown delete type!"
                                        });
                                    }
                                    return this.logger.info({
                                        deleteScheduleEvent_req: u
                                    }, "SDK"), new Promise(function(e, t) {
                                        s.getInstance().post(i, u).then(function(t) {
                                            a.logger.info({
                                                deleteScheduleEvent_resp: t
                                            }, "SDK"), e(t);
                                        }).catch(function(e) {
                                            a.logger.info({
                                                deleteScheduleEvent_resp: e
                                            }, "SDK"), t(e);
                                        });
                                    });
                                }
                            }, {
                                key: "getEventDetail",
                                value: function(e, t, n, r, o, i) {
                                    var a = this;
                                    if (!e || !r) return Promise.reject({
                                        code: -1,
                                        msg: "miss need param!"
                                    });
                                    var f = {
                                        event_id: r,
                                        calendar_id: e,
                                        corp_id: t,
                                        cal_uid: n
                                    };
                                    return o && i && (f.parent_event_id = o, f.period_start_time = Math.floor(i / 1e3)), 
                                    new Promise(function(e, t) {
                                        s.getInstance().get(c.GET_EVENT_DETAIL, f).then(function(t) {
                                            a.logger.info({
                                                getEventDetail_resp: t
                                            }, "SDK");
                                            var n = u.parseEventInfoByDetail(t);
                                            e(n);
                                        }).catch(function(e) {
                                            a.logger.info({
                                                getEventDetail_resp: e
                                            }, "SDK"), t(e);
                                        });
                                    });
                                }
                            }, {
                                key: "isExistInvitationList",
                                value: function(e) {
                                    var t = {
                                        time: e
                                    };
                                    return new Promise(function(e, n) {
                                        s.getInstance().get(c.IS_EXIST_INVITATION_LIST, t).then(function(t) {
                                            e(t);
                                        }).catch(function(e) {
                                            n(e);
                                        });
                                    });
                                }
                            }, {
                                key: "getNewInvitationReplyCnt",
                                value: function() {
                                    var e = this;
                                    return new Promise(function(t, n) {
                                        s.getInstance().get(c.GET_NEW_INVITATION_REPLY_CNT, {}).then(function(n) {
                                            e.logger.info({
                                                getNewInvitationReplyCnt_resp: n
                                            }, "SDK"), t(n);
                                        }).catch(function(t) {
                                            e.logger.info({
                                                getNewInvitationReplyCnt_resp: t
                                            }, "SDK"), n(t);
                                        });
                                    });
                                }
                            }, {
                                key: "clearInvitationReplyCnt",
                                value: function() {
                                    var e = this;
                                    return new Promise(function(t, n) {
                                        s.getInstance().post(c.CLEAR_INVITATION_REPLY_CNT, {}).then(function(n) {
                                            e.logger.info({
                                                clearInvitationReplyCnt_resp: n
                                            }, "SDK"), t(n);
                                        }).catch(function(t) {
                                            e.logger.info({
                                                clearInvitationReplyCnt_resp: t
                                            }, "SDK"), n(t);
                                        });
                                    });
                                }
                            }, {
                                key: "getEventparticipant",
                                value: function(e, t, n, r, o) {
                                    var i = this, a = {
                                        event_id: e,
                                        corp_id: t,
                                        cal_uid: n,
                                        page_size: r,
                                        page_cursor: o
                                    };
                                    return this.logger.info({
                                        getEventparticipant_req: a
                                    }, "SDK"), new Promise(function(e, t) {
                                        s.getInstance().get(c.EVENT_PARTICIPANT, a).then(function(t) {
                                            i.logger.info({
                                                getEventparticipant_rsp: t
                                            }, "SDK"), e(t);
                                        }).catch(function(e) {
                                            i.logger.info({
                                                getEventparticipant_rsp: e
                                            }, "SDK"), t(e);
                                        });
                                    });
                                }
                            }, {
                                key: "acceptRejectEvent",
                                value: function(e, t, n, r, o, i) {
                                    var a = this, u = {
                                        calendar_id: t,
                                        event_id: e,
                                        response_status: i,
                                        meeting_password: o,
                                        corp_id: n,
                                        cal_uid: r
                                    };
                                    return this.logger.info({
                                        acceptRejectEvent_req: u
                                    }, "SDK"), new Promise(function(e, t) {
                                        s.getInstance().get(c.ACCEPT_EVENT, u).then(function(t) {
                                            a.logger.info({
                                                acceptRejectEvent_rsp: t
                                            }, "SDK"), e(t);
                                        }).catch(function(e) {
                                            a.logger.info({
                                                acceptRejectEvent_rsp: e
                                            }, "SDK"), t(e);
                                        });
                                    });
                                }
                            }, {
                                key: "queryPublicAccountSubscribeStatus",
                                value: function() {
                                    var e = this;
                                    return new Promise(function(t, n) {
                                        s.getInstance().get(c.PUBLIC_ACCOUNT_SUBSCRIBESTATUS, {}).then(function(n) {
                                            e.logger.info({
                                                queryPublicAccountSubscribeStatus_rsp: n
                                            }, "SDK"), t(n);
                                        }).catch(function(t) {
                                            e.logger.info({
                                                queryPublicAccountSubscribeStatus_rsp: t
                                            }, "SDK"), n(t);
                                        });
                                    });
                                }
                            }, {
                                key: "eventMiniProgramSubscribeStatus",
                                value: function(e, t) {
                                    var n = this, r = {
                                        template_value: e,
                                        event_id: t
                                    };
                                    return this.logger.info({
                                        acceptRejectEvent_req: r
                                    }, "SDK"), new Promise(function(e, t) {
                                        s.getInstance().get(c.MINIPROGRAM_EVENT_SUBSCRIPTIONS, r).then(function(t) {
                                            n.logger.info({
                                                eventMiniProgramSubscribeStatus_rsp: t
                                            }, "SDK"), e(t);
                                        }).catch(function(e) {
                                            n.logger.info({
                                                eventMiniProgramSubscribeStatus_rsp: e
                                            }, "SDK"), t(e);
                                        });
                                    });
                                }
                            }, {
                                key: "getNewAppointReplyCnt",
                                value: function() {
                                    var e = this;
                                    return new Promise(function(t, n) {
                                        s.getInstance().get(c.GET_APPOINT_REPLY_COUNT, {}).then(function(n) {
                                            e.logger.info({
                                                getNewAppointReplyCnt_resp: n
                                            }, "SDK"), t(n);
                                        }).catch(function(t) {
                                            e.logger.info({
                                                getNewAppointReplyCnt_resp: t
                                            }, "SDK"), n(t);
                                        });
                                    });
                                }
                            }, {
                                key: "setDataSyncStatus",
                                value: function(e, t) {
                                    var n = {
                                        type: e,
                                        status: t
                                    };
                                    return new Promise(function(e, t) {
                                        s.getInstance().post(c.SET_SYNC, n).then(function(t) {
                                            e(t || {
                                                result: "ok"
                                            });
                                        }).catch(function(e) {
                                            t(e);
                                        });
                                    });
                                }
                            }, {
                                key: "batchQuerySubscribers",
                                value: function(e) {
                                    return new Promise(function(t, n) {
                                        s.getInstance().post(c.BATCH_QUERY_SUBSCRIBERS, e).then(function(e) {
                                            t(e);
                                        }).catch(function(e) {
                                            n(e);
                                        });
                                    });
                                }
                            } ]) && i(t.prototype, n), r && i(t, r), Object.defineProperty(t, "prototype", {
                                writable: !1
                            }), e;
                        }();
                        function m(e, t, n) {
                            return e && t && n ? Array.isArray(e) && 0 !== e.length ? Array.isArray(t) && 0 !== t.length ? {
                                code: 0
                            } : {
                                code: -1,
                                msg: "eventTypeArr error!"
                            } : {
                                code: -1,
                                msg: "calendarIdArr error!"
                            } : {
                                code: -1,
                                msg: "miss params！please input not null value"
                            };
                        }
                        function y() {
                            var e = function(e) {
                                return e < 10 ? "0".concat(e) : "".concat(e);
                            }, t = new Date().getTimezoneOffset(), n = Math.floor(Math.abs(t) / 60), r = Math.abs(t) % 60;
                            return t > 0 ? "-".concat(e(n)).concat(e(r)) : "+".concat(e(n)).concat(e(r));
                        }
                        e.exports = {
                            CalendarSDK: g,
                            CalendarInfo: f,
                            EventInfo: p,
                            MeetingInfo: h,
                            DayOverView: d
                        };
                    },
                    334: function(e, t, n) {
                        function r(e, t) {
                            var n = Object.keys(e);
                            if (Object.getOwnPropertySymbols) {
                                var r = Object.getOwnPropertySymbols(e);
                                t && (r = r.filter(function(t) {
                                    return Object.getOwnPropertyDescriptor(e, t).enumerable;
                                })), n.push.apply(n, r);
                            }
                            return n;
                        }
                        function o(e) {
                            for (var t = 1; t < arguments.length; t++) {
                                var n = null != arguments[t] ? arguments[t] : {};
                                t % 2 ? r(Object(n), !0).forEach(function(t) {
                                    a(e, t, n[t]);
                                }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(n)) : r(Object(n)).forEach(function(t) {
                                    Object.defineProperty(e, t, Object.getOwnPropertyDescriptor(n, t));
                                });
                            }
                            return e;
                        }
                        function i(e, t) {
                            for (var n = 0; n < t.length; n++) {
                                var r = t[n];
                                r.enumerable = r.enumerable || !1, r.configurable = !0, "value" in r && (r.writable = !0), 
                                Object.defineProperty(e, r.key, r);
                            }
                        }
                        function a(e, t, n) {
                            return t in e ? Object.defineProperty(e, t, {
                                value: n,
                                enumerable: !0,
                                configurable: !0,
                                writable: !0
                            }) : e[t] = n, e;
                        }
                        var s = n(413), c = function() {
                            function e() {
                                !function(e, t) {
                                    if (!(e instanceof t)) throw new TypeError("Cannot call a class as a function");
                                }(this, e), a(this, "appId", void 0), a(this, "appUid", void 0), a(this, "instanceId", void 0), 
                                this.cgi = new s();
                            }
                            var t, n, r;
                            return t = e, r = [ {
                                key: "getInstance",
                                value: function() {
                                    return void 0 === e.prototype.instance && (e.prototype.instance = new e()), e.prototype.instance;
                                }
                            } ], (n = [ {
                                key: "setConfig",
                                value: function(e) {
                                    this.mock = e.mock, this.cgi.setConfig(e), this.appId = e.appId || this.appId, this.appUid = e.appUID || this.appUid, 
                                    this.instanceId = e.instanceId || this.instanceId;
                                }
                            }, {
                                key: "get",
                                value: function(e, t, n) {
                                    var r = "".concat(e, "?").concat(this.cgi.getReuqestCommonParams(t));
                                    return this.cgi.get(r, {
                                        header: o({
                                            app_id: this.appId,
                                            app_uid: this.appUid,
                                            instanceId: this.instanceId
                                        }, n),
                                        data: t
                                    });
                                }
                            }, {
                                key: "post",
                                value: function(e, t, n) {
                                    var r = "".concat(e, "?").concat(this.cgi.getReuqestCommonParams({}));
                                    return this.cgi.post(r, {
                                        header: o({
                                            app_id: this.appId,
                                            app_uid: this.appUid,
                                            instanceId: this.instanceId
                                        }, n),
                                        data: t
                                    });
                                }
                            } ]) && i(t.prototype, n), r && i(t, r), Object.defineProperty(t, "prototype", {
                                writable: !1
                            }), e;
                        }();
                        e.exports = c;
                    },
                    200: function(e) {
                        e.exports = {
                            API_NAME: {
                                GET_CALENDAR_LIST: "/calendar/v1/getCalendarList",
                                GET_OVER_VIEW: "/calendar/v1/getScheduleView",
                                GET_EVENT_LIST: "/calendar/v1/getCalendarEventList",
                                GET_DAY_EVENT_LIST: "/calendar/v1/getEventListByDay",
                                GET_MONTH_EVENT_LIST: "/calendar/v1/getEventListByMonth",
                                GET_WEEK_EVENT_LIST: "/calendar/v1/getEventListByWeek",
                                UPDATE_CALENDAR: "/calendar/v1/batchUpdateUserInfo",
                                GET_EVENT_DETAIL: "/calendar/v1/getEventDetail",
                                CREATE_SCHEDULE: "/calendar/v1/eventCreate",
                                CREATE_RECURRING_SCHEDULE: "/calendar/v1/createPeriodEvent",
                                SET_SYNC: "/calendar/v1/changeDataSyncStatus",
                                DELETE_EVENT: "/calendar/v1/eventDelete",
                                DELETE_RECURRING_EVENT: "/calendar/v1/deletePeriodEvent",
                                EDIT_EVENT: "/calendar/v1/eventEdit",
                                EDIT_RECURRING_EVENT: "/calendar/v1/updatePeriodEvent",
                                IS_EXIST_INVITATION_LIST: "/calendar/v1/isExistInvitationList",
                                GET_NEW_INVITATION_REPLY_CNT: "/invite/v1/getNewReplyCnt",
                                CLEAR_INVITATION_REPLY_CNT: "/invite/v1/clearNewReplyCnt",
                                ACCEPT_EVENT: "/calendar/v1/acceptEvent",
                                EVENT_PARTICIPANT: "/calendar/v1/getEventParticipant",
                                MINIPROGRAM_EVENT_SUBSCRIPTIONS: "/calendar/v1/callbackSuccess",
                                PUBLIC_ACCOUNT_SUBSCRIBESTATUS: "/calendar/v1/querySubscribeStatus",
                                GET_APPOINT_REPLY_COUNT: "/appoint/v1/get_reply_count",
                                BATCH_QUERY_SUBSCRIBERS: "/calendar/v1/batchQuerySubscribers"
                            }
                        };
                    },
                    389: function(e, t, n) {
                        var r = n(376), o = n(467), i = o.EventInfo, a = o.MeetingInfo, s = o.ParticipantSimInfo, c = o.RemindWays, u = (o.AttachData, 
                        n(382));
                        e.exports = {
                            paresOverview: function(e) {
                                var t = new u();
                                return t.day = e.day || "", t.isScheduled = 1 === e.is_scheduled, t.eventCount = e.num || 0, 
                                t.holiday = e.holiday || [], t.isOffDuty = 1 === e.isOffDuty, t.isOnDuty = 1 === e.isOnDuty, 
                                t;
                            },
                            parseCalendarInfo: function(e) {
                                var t = new r();
                                return t.calendarId = e.id, t.summary = e.summary, t.description = e.desc, t.loc = e.loc, 
                                t.timezone = e.timezone, t.version = e.version, t.isShare = 1 === e.is_share, t.calType = e.cal_type, 
                                t.accessRole = e.access_role, t.color = e.color, t.bgColor = e.bg_color, t.fgColor = e.fg_color, 
                                t.summaryOverrided = e.summary_override, t.isPrimary = 1 === e.is_primary, t.isHidden = 1 === e.is_hidden, 
                                t.isSelected = 1 === e.is_selected, t.updateTime = parseInt(e.update_time, 10), 
                                t.createTime = parseInt(e.create_time, 10), t.operation = e.operation, t;
                            },
                            parserEventInfo: function(e) {
                                var t = new i(), n = e.event_info;
                                if (!n) return t;
                                t.eventId = n.event_id, t.summary = n.summary, t.desc = n.desc, t.loc = n.loc, t.timezone = n.timezone, 
                                t.startTime = 1e3 * parseInt(n.start_time, 10), t.endTime = 1e3 * parseInt(n.end_time, 10), 
                                t.isAllDay = 1 === n.is_all_day, t.eventType = n.event_type, t.creatorUserType = n.creator_user_type, 
                                t.creatorAppId = n.creator_app_id, t.creatorUid = n.creator_uid, t.calendarId = n.calendar_id, 
                                t.visibility = n.visibility, t.transparency = n.transparency, t.priority = n.priority, 
                                t.updateTime = parseInt(n.update_time, 10), t.createTime = parseInt(n.create_time, 10), 
                                t.creator = n.creator, t.creatorAvatar = n.avatar, t.role = n.role, t.calType = n.cal_type, 
                                t.rruleDesc = n.rrule_desc, t.location = {}, n.loc && (t.location.address = n.loc.loc), 
                                t.remindTimes = n.remind_time, t.responseStatus = n.response_status;
                                var r = e.meet_extern_info;
                                if (r) {
                                    var o = new a();
                                    o.eventId = r.event_id, o.meetingId = r.meeting_id, o.meetingCode = r.meeting_code, 
                                    o.meetingUrl = r.meeting_url, o.meetingPass = r.meeting_pass, o.meetingSubject = r.meeting_subject, 
                                    o.isPeriod = 1 === r.is_period, o.subMeetingId = r.sub_meeting_id, o.pmiCode = r.pmi_code, 
                                    o.isSpecial = r.is_special, o.isNeedPassword = r.is_need_password, o.meetingType = r.meeting_type, 
                                    t.meetingInfo = o;
                                } else t.meetingInfo = null;
                                var c = e.participant_sim_info;
                                if (c) {
                                    var u = new s();
                                    u.totalCount = c.total_count, u.avartList = c.avartList, t.participantSimInfo = u;
                                } else t.participantSimInfo = null;
                                return t.parentEventId = n.parent_event_id, t.originEventId = n.origin_event_id, 
                                t.timeStep = n.time_step, t.rrule = n.rrule, t.isPeriod = n.is_period, t.accessRole = n.access_role, 
                                t;
                            },
                            parseEventInfoByDetail: function(e) {
                                var t = new i(), n = e.event_info;
                                if (!n) return t;
                                t.eventId = n.event_id, t.parentEventId = n.parent_event_id, t.summary = n.summary, 
                                t.desc = n.description, t.timezone = n.timezone, t.startTime = 1e3 * parseInt(n.start_time, 10), 
                                t.endTime = 1e3 * parseInt(n.end_time, 10), t.createTime = 1e3 * parseInt(n.create_time, 10), 
                                t.isAllDay = 1 === n.is_all_day, t.eventType = n.event_type, t.location = {}, n.location && (t.location.address = n.location.loc), 
                                t.remindTimes = n.remind_time, t.responseStatus = n.response_status, t.role = n.role;
                                var r = e.calendar_info;
                                r && (t.calendarId = r.id), t.creatorNickName = n.creator;
                                var o = e.meet_extern_info;
                                if (o) {
                                    var u = new a();
                                    u.meetingCode = o.meeting_code, u.meetingUrl = o.meeting_url, u.meetingPass = o.meeting_pass, 
                                    u.isNeedPassword = o.is_need_password, u.isPeriod = o.is_period, u.meetingType = o.meeting_type, 
                                    t.meetingInfo = u;
                                } else t.meetingInfo = null;
                                var f = e.participant_simple_info;
                                if (f) {
                                    var l = new s();
                                    l.totalCount = f.total_count, l.avartList = f.avatar_list, t.participantSimInfo = l;
                                } else t.participantSimInfo = null;
                                if (n.remind_ways) {
                                    var p = new c();
                                    p.startTime = n.remind_ways.start_time, p.endTime = n.remind_ways.end_time, t.remindWays = p;
                                }
                                return t.parentEventId = n.parent_event_id, t.originEventId = n.origin_event_id, 
                                t.timeStep = n.time_step, t.rrule = n.rrule, t.rruleDesc = n.rrule_desc, t.creatorAvatar = n.avatar, 
                                t.busType = n.bus_type, t.accessRole = n.access_role, n.end_info && (t.endInfo = n.end_info), 
                                t.endType = n.end_type, e.attach_data && e.attach_data.images.length && (t.attachImages = e.attach_data.images), 
                                t;
                            }
                        };
                    },
                    382: function(e) {
                        function t(e, t) {
                            for (var n = 0; n < t.length; n++) {
                                var r = t[n];
                                r.enumerable = r.enumerable || !1, r.configurable = !0, "value" in r && (r.writable = !0), 
                                Object.defineProperty(e, r.key, r);
                            }
                        }
                        function n(e, t, n) {
                            return t in e ? Object.defineProperty(e, t, {
                                value: n,
                                enumerable: !0,
                                configurable: !0,
                                writable: !0
                            }) : e[t] = n, e;
                        }
                        var r = function(e, n, r) {
                            return n && t(e.prototype, n), r && t(e, r), Object.defineProperty(e, "prototype", {
                                writable: !1
                            }), e;
                        }(function e() {
                            !function(e, t) {
                                if (!(e instanceof t)) throw new TypeError("Cannot call a class as a function");
                            }(this, e), n(this, "day", ""), n(this, "isScheduled", !1), n(this, "eventCount", 0), 
                            n(this, "holiday", []), n(this, "isOnDuty", !1), n(this, "isOffDuty", !1);
                        });
                        e.exports = r;
                    },
                    467: function(e) {
                        function t(e, t) {
                            for (var n = 0; n < t.length; n++) {
                                var r = t[n];
                                r.enumerable = r.enumerable || !1, r.configurable = !0, "value" in r && (r.writable = !0), 
                                Object.defineProperty(e, r.key, r);
                            }
                        }
                        function n(e, n, r) {
                            return n && t(e.prototype, n), r && t(e, r), Object.defineProperty(e, "prototype", {
                                writable: !1
                            }), e;
                        }
                        function r(e, t) {
                            if (!(e instanceof t)) throw new TypeError("Cannot call a class as a function");
                        }
                        function o(e, t, n) {
                            return t in e ? Object.defineProperty(e, t, {
                                value: n,
                                enumerable: !0,
                                configurable: !0,
                                writable: !0
                            }) : e[t] = n, e;
                        }
                        var i = n(function e() {
                            r(this, e), o(this, "eventId", ""), o(this, "calendarId", ""), o(this, "summary", ""), 
                            o(this, "desc", ""), o(this, "location", {}), o(this, "timezone", ""), o(this, "startTime", 0), 
                            o(this, "endTime", 0), o(this, "isAllDay", !1), o(this, "eventType", 0), o(this, "creatorUserType", ""), 
                            o(this, "creatorAppId", ""), o(this, "creatorUid", ""), o(this, "visibility", ""), 
                            o(this, "transparency", ""), o(this, "priority", 0), o(this, "updateTime", 0), o(this, "createTime", 0), 
                            o(this, "creator", ""), o(this, "creatorAvatar", ""), o(this, "creatorNickName", ""), 
                            o(this, "remindTimes", []), o(this, "remindWays", new a()), o(this, "meetingInfo", new s()), 
                            o(this, "responseStatus", 1), o(this, "participantSimInfo", new c()), o(this, "parentEventId", ""), 
                            o(this, "originEventId", ""), o(this, "timeStep", ""), o(this, "rrule", ""), o(this, "isPeriod", ""), 
                            o(this, "busType", 0), o(this, "role", ""), o(this, "endInfo", ""), o(this, "endType", 0), 
                            o(this, "rruleDesc", "");
                        }), a = n(function e() {
                            r(this, e), o(this, "startTime", []), o(this, "endTime", []);
                        }), s = n(function e() {
                            r(this, e), o(this, "meetingId", ""), o(this, "meetingCode", ""), o(this, "meetingUrl", ""), 
                            o(this, "meetingPass", ""), o(this, "meetingSubject", ""), o(this, "isPeriod", !1), 
                            o(this, "subMeetingId", ""), o(this, "pmiCode", ""), o(this, "isSpecial", !1), o(this, "eventId", ""), 
                            o(this, "isNeedPassword", !1), o(this, "meetingType", 0);
                        }), c = n(function e() {
                            r(this, e), o(this, "totalCount", 0), o(this, "avartList", []);
                        });
                        e.exports = {
                            EventInfo: i,
                            MeetingInfo: s,
                            ParticipantSimInfo: c,
                            RemindWays: a
                        };
                    },
                    991: function(e) {
                        var t = function() {
                            function e() {
                                !function(e, t) {
                                    if (!(e instanceof t)) throw new TypeError("Cannot call a class as a function");
                                }(this, e);
                            }
                            var t, n;
                            return t = e, (n = [ {
                                key: "info",
                                value: function(e, t) {
                                    console.log(this.getMsgStr(e, t));
                                }
                            }, {
                                key: "infoAll",
                                value: function(e, t) {
                                    console.info(this.getMsgStr(e, t));
                                }
                            }, {
                                key: "warn",
                                value: function(e, t) {
                                    console.warn(this.getMsgStr(e, t));
                                }
                            }, {
                                key: "error",
                                value: function(e, t) {
                                    console.error(this.getMsgStr(e, t));
                                }
                            }, {
                                key: "getMsgStr",
                                value: function() {
                                    var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : "", t = arguments.length > 1 ? arguments[1] : void 0, n = "string" == typeof e ? e : JSON.stringify(e);
                                    return "".concat("string" == typeof t ? "[".concat(t, "]") : "", " ").concat(n);
                                }
                            } ]) && function(e, t) {
                                for (var n = 0; n < t.length; n++) {
                                    var r = t[n];
                                    r.enumerable = r.enumerable || !1, r.configurable = !0, "value" in r && (r.writable = !0), 
                                    Object.defineProperty(e, r.key, r);
                                }
                            }(t.prototype, n), Object.defineProperty(t, "prototype", {
                                writable: !1
                            }), e;
                        }();
                        e.exports = t;
                    }
                }, __webpack_module_cache__ = {};
                function __webpack_require__(e) {
                    var t = __webpack_module_cache__[e];
                    if (void 0 !== t) return t.exports;
                    var n = __webpack_module_cache__[e] = {
                        id: e,
                        loaded: !1,
                        exports: {}
                    };
                    return __webpack_modules__[e].call(n.exports, n, n.exports, __webpack_require__), 
                    n.loaded = !0, n.exports;
                }
                __webpack_require__.amdO = {}, __webpack_require__.g = function() {
                    if ("object" == ("undefined" == typeof globalThis ? "undefined" : _typeof3(globalThis))) return globalThis;
                    try {
                        return this || new Function("return this")();
                    } catch (e) {
                        if ("object" == ("undefined" == typeof window ? "undefined" : _typeof3(window))) return window;
                    }
                }(), __webpack_require__.nmd = function(e) {
                    return e.paths = [], e.children || (e.children = []), e;
                };
                var __webpack_exports__ = __webpack_require__(119);
                return __webpack_exports__;
            }();
        });
    }, function(e) {
        return __REQUIRE__({}[e], e);
    }), __REQUIRE__(1699270751485);
}();