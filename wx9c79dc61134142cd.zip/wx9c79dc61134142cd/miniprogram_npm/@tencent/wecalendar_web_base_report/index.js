require("../../../@babel/runtime/helpers/Arrayincludes");

var e, t, r = require("../../../@babel/runtime/helpers/typeof");

module.exports = (e = {}, t = function(t, n) {
    if (!e[t]) return require(n);
    if (!e[t].status) {
        var o = e[t].m;
        o._exports = o._tempexports;
        var i = Object.getOwnPropertyDescriptor(o, "exports");
        i && i.configurable && Object.defineProperty(o, "exports", {
            set: function(e) {
                "object" === r(e) && e !== o._exports && (o._exports.__proto__ = e.__proto__, Object.keys(e).forEach(function(t) {
                    o._exports[t] = e[t];
                })), o._tempexports = e;
            },
            get: function() {
                return o._tempexports;
            }
        }), e[t].status = 1, e[t].func(e[t].req, o, o.exports);
    }
    return e[t].m.exports;
}, function(t, r, n) {
    e[t] = {
        status: 0,
        func: r,
        req: n,
        m: {
            exports: {},
            _tempexports: {}
        }
    };
}(1699270751486, function(e, t, n) {
    var o, i;
    o = "undefined" != typeof self ? self : this, i = function() {
        return function() {
            var e = {
                112: function(e) {
                    e.exports = function(e, t) {
                        if (!(e instanceof t)) throw new TypeError("Cannot call a class as a function");
                    }, e.exports.__esModule = !0, e.exports.default = e.exports;
                },
                639: function(e) {
                    function t(e, t) {
                        for (var r = 0; r < t.length; r++) {
                            var n = t[r];
                            n.enumerable = n.enumerable || !1, n.configurable = !0, "value" in n && (n.writable = !0), 
                            Object.defineProperty(e, n.key, n);
                        }
                    }
                    e.exports = function(e, r, n) {
                        return r && t(e.prototype, r), n && t(e, n), Object.defineProperty(e, "prototype", {
                            writable: !1
                        }), e;
                    }, e.exports.__esModule = !0, e.exports.default = e.exports;
                },
                230: function(e) {
                    e.exports = function(e, t, r) {
                        return t in e ? Object.defineProperty(e, t, {
                            value: r,
                            enumerable: !0,
                            configurable: !0,
                            writable: !0
                        }) : e[t] = r, e;
                    }, e.exports.__esModule = !0, e.exports.default = e.exports;
                },
                378: function(e) {
                    e.exports = function(e) {
                        return e && e.__esModule ? e : {
                            default: e
                        };
                    }, e.exports.__esModule = !0, e.exports.default = e.exports;
                },
                861: function(e) {
                    function t(n) {
                        return e.exports = t = "function" == typeof Symbol && "symbol" == r(Symbol.iterator) ? function(e) {
                            return r(e);
                        } : function(e) {
                            return e && "function" == typeof Symbol && e.constructor === Symbol && e !== Symbol.prototype ? "symbol" : r(e);
                        }, e.exports.__esModule = !0, e.exports.default = e.exports, t(n);
                    }
                    e.exports = t, e.exports.__esModule = !0, e.exports.default = e.exports;
                },
                364: function(e, t, r) {
                    var n = r(378);
                    Object.defineProperty(t, "__esModule", {
                        value: !0
                    }), t.default = void 0;
                    var o = n(r(861)), i = function() {
                        return "object" === ("undefined" == typeof navigator ? "undefined" : (0, o.default)(navigator)) ? navigator.userAgent : "mp";
                    }, u = function() {
                        var e = i().toLowerCase(), t = function(t) {
                            return -1 === e.indexOf(t);
                        }, r = e.indexOf("safari/") > -1, n = t("chrome/"), o = t("qq/") && t("mqqbrowser");
                        return r && n && o;
                    }, a = function() {
                        var e = i();
                        return !(!u() || !navigator.maxTouchPoints) || /Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i.test(e);
                    };
                    function c() {
                        var e, t = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : null === (e = navigator) || void 0 === e ? void 0 : e.userAgent;
                        return !!/iPad/i.test(t) || !(!u() || a() || !navigator.maxTouchPoints);
                    }
                    var s = function() {
                        return /android|adr/i.test(i());
                    }, l = {
                        device_type: "",
                        hardware_os: "",
                        nav_platform: "",
                        user_agent: ""
                    }, f = {
                        windows: "Windows",
                        android: "Android",
                        ios: "IOS",
                        mac: "Mac",
                        linux: "Linux",
                        unknown: "unknown"
                    };
                    t.default = function() {
                        return l.device_type || (l.device_type = c() || function() {
                            var e, t, r, n, o;
                            return s() && !(null !== (e = navigator) && void 0 !== e && e.userAgent.toLowerCase().includes("mobile")) || (null == (o = window ? window.navigator : null) ? void 0 : o.platform.toLowerCase().includes("linux")) && (null == o || null === (r = o.appPackageName) || void 0 === r || null === (n = r.toLowerCase()) || void 0 === n ? void 0 : n.includes("huawei")) || function() {
                                var e = window ? window.navigator : null, t = null == e ? void 0 : e.userAgent.toLowerCase();
                                return !(!t || !t.includes("android") && !t.includes("huawei") || !t.includes("qq"));
                            }() || s() && (null === (t = window) || void 0 === t ? void 0 : t.screen.width) > 600;
                        }() ? "tablet" : a() ? "mobile" : "pc"), l.hardware_os || (l.hardware_os = f[function() {
                            var e = i();
                            return /Win/.test(e) && !/Mac/.test(e) ? "windows" : /Android/.test(e) ? "android" : /iPhone/.test(e) || c() ? "ios" : function() {
                                var e = i();
                                return !a() && /macintosh|mac os x/i.test(e);
                            }() ? "mac" : e.includes("Linux") ? "linux" : "unknown";
                        }()]), l.nav_platform || (l.nav_platform = function() {
                            var e = i();
                            if (e.match("Windows")) return e.match("X64") ? "Windows" : "Win32";
                            if (e.match("Macintosh")) return "MacIntel";
                            if (e.match("Linux")) {
                                if (e.match("arch64")) return "Linux aarch64";
                                if (e.match("armv8")) return "Linux armv8l";
                                if (e.match("x86")) return "Linux x86_64";
                                if (e.match("armv7")) return "Linux armv7l";
                            }
                            return c() ? "iPad" : e.match("iPhone") ? "iPhone" : "unknown";
                        }()), l.user_agent || (l.user_agent = i()), l;
                    };
                },
                793: function(e, t, r) {
                    var n = r(378);
                    Object.defineProperty(t, "__esModule", {
                        value: !0
                    }), t.setTest = t.registerReportChannel = t.registerOnError = t.default = void 0, 
                    n(r(129));
                    var o = "https://reporttest.calendar.tencent.com/api/data-report", i = !0, u = o;
                    t.setTest = function(e, t) {
                        i = e, u = t || (e ? o : "https://report.calendar.tencent.com/api/data-report");
                    };
                    var a = [];
                    t.registerReportChannel = function(e) {
                        a.push(e);
                    };
                    var c = function() {};
                    t.registerOnError = function(e) {
                        return c = e;
                    };
                    var s = [], l = 0, f = function e(t, r) {
                        t && i && (t.event_value.app_main_version = "999.999.999.999");
                        var n = s.concat(t || []);
                        return s = [], n.length ? function(e) {
                            return new Promise(function(t, r) {
                                wx.request({
                                    url: u,
                                    method: "POST",
                                    data: e,
                                    header: {
                                        "content-type": "application/json"
                                    },
                                    success: function(e) {
                                        t(e);
                                    },
                                    fail: function(e) {
                                        r(e);
                                    }
                                });
                            });
                        }({
                            event_params: n,
                            report_flag: 3,
                            report_cmd: i || r ? "cmd_test_new_atta" : "cmd_prod_old_atta",
                            request_time: Date.now(),
                            client_ip: null
                        }).catch(function(t) {
                            if ((s = s.concat(n)).length > 30) {
                                var r = s.slice(0, s.length - 30);
                                c(t, r), s = s.slice(-30);
                            }
                            clearTimeout(l), l = setTimeout(function() {
                                e(null, !1);
                            }, 5e3);
                        }) : Promise.resolve();
                    };
                    t.default = function(e, t, r) {
                        return a.forEach(function(r) {
                            try {
                                r(e, t);
                            } catch (e) {
                                console.warn("report failed", e);
                            }
                        }), f(e, r);
                    };
                },
                129: function(e) {
                    e.exports = wx;
                }
            }, t = {};
            function n(r) {
                var o = t[r];
                if (void 0 !== o) return o.exports;
                var i = t[r] = {
                    exports: {}
                };
                return e[r](i, i.exports, n), i.exports;
            }
            var o = {};
            return function() {
                var e = o, t = n(378), r = n(861);
                Object.defineProperty(e, "__esModule", {
                    value: !0
                }), e.dataReport = function(e) {
                    var t = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {}, r = arguments.length > 2 ? arguments[2] : void 0, n = new Date().getTime(), o = function() {
                        var o = p.get(-2), i = p.get(-1);
                        return Promise.resolve(v()).then(function(u) {
                            var a = {
                                event_code: e,
                                event_value: f(f(f({}, d(u)), d(t)), {}, {
                                    prev_page: o,
                                    current_page: i
                                }),
                                event_time: n
                            };
                            return (0, c.default)(a, t, r);
                        });
                    };
                    return p.get(-1) ? o() : p.resolved.then(o);
                }, e.onVisitNextPage = function(e) {
                    p.push(e);
                }, Object.defineProperty(e, "registerOnError", {
                    enumerable: !0,
                    get: function() {
                        return c.registerOnError;
                    }
                }), Object.defineProperty(e, "registerReportChannel", {
                    enumerable: !0,
                    get: function() {
                        return c.registerReportChannel;
                    }
                }), e.setGetCommonParams = void 0, Object.defineProperty(e, "setTest", {
                    enumerable: !0,
                    get: function() {
                        return c.setTest;
                    }
                });
                var i = t(n(639)), u = t(n(112)), a = t(n(230)), c = function(e, t) {
                    if (e && e.__esModule) return e;
                    if (null === e || "object" !== r(e) && "function" != typeof e) return {
                        default: e
                    };
                    var n = function(e) {
                        if ("function" != typeof WeakMap) return null;
                        var t = new WeakMap(), r = new WeakMap();
                        return function(e) {
                            return e ? r : t;
                        }(e);
                    }(t);
                    if (n && n.has(e)) return n.get(e);
                    var o = {}, i = Object.defineProperty && Object.getOwnPropertyDescriptor;
                    for (var u in e) if ("default" !== u && Object.prototype.hasOwnProperty.call(e, u)) {
                        var a = i ? Object.getOwnPropertyDescriptor(e, u) : null;
                        a && (a.get || a.set) ? Object.defineProperty(o, u, a) : o[u] = e[u];
                    }
                    return o.default = e, n && n.set(e, o), o;
                }(n(793)), s = t(n(364));
                function l(e, t) {
                    var r = Object.keys(e);
                    if (Object.getOwnPropertySymbols) {
                        var n = Object.getOwnPropertySymbols(e);
                        t && (n = n.filter(function(t) {
                            return Object.getOwnPropertyDescriptor(e, t).enumerable;
                        })), r.push.apply(r, n);
                    }
                    return r;
                }
                function f(e) {
                    for (var t = 1; t < arguments.length; t++) {
                        var r = null != arguments[t] ? arguments[t] : {};
                        t % 2 ? l(Object(r), !0).forEach(function(t) {
                            (0, a.default)(e, t, r[t]);
                        }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(r)) : l(Object(r)).forEach(function(t) {
                            Object.defineProperty(e, t, Object.getOwnPropertyDescriptor(r, t));
                        });
                    }
                    return e;
                }
                var p = new ((0, i.default)(function e() {
                    var t = this;
                    (0, u.default)(this, e), (0, a.default)(this, "resolved", void 0), (0, a.default)(this, "res", void 0), 
                    (0, a.default)(this, "push", function(e) {
                        var r = (getApp() || {}).globalData;
                        r && (r.urlStack || (r.urlStack = []), r.urlStack.push(e), r.urlStack = r.urlStack.slice(-2), 
                        t.res && (t.res(), t.res = void 0));
                    }), (0, a.default)(this, "get", function(e) {
                        var t, r, n = (null === (t = getApp()) || void 0 === t ? void 0 : t.globalData.urlStack) || [], o = e < 0 ? n.length + e : e, i = null === (r = getCurrentPages().pop()) || void 0 === r ? void 0 : r.route;
                        return -1 === e && n[o] && i && !n[o].includes(i) ? (console.warn("mismatch current url", i, n[o]), 
                        i) : n[o];
                    }), this.resolved = new Promise(function(e) {
                        setTimeout(function() {
                            e();
                        }, 2e3), t.res = e;
                    });
                }))(), d = function(e) {
                    return e ? Object.keys(e).reduce(function(t, r) {
                        return f(f({}, t), {}, (0, a.default)({}, r, "string" == typeof e[r] ? e[r] : JSON.stringify(void 0 === e[r] ? "" : e[r])));
                    }, {}) : {};
                }, v = function() {
                    return {};
                };
                e.setGetCommonParams = function(e) {
                    v = function() {
                        try {
                            return f(f({}, (0, s.default)()), e());
                        } catch (e) {
                            return console.error("custom report failed", e), {};
                        }
                    };
                };
            }(), o;
        }();
    }, "object" == r(n) && "object" == r(t) ? t.exports = i() : "function" == typeof define && define.amd ? define([], i) : "object" == r(n) ? n.library = i() : o.library = i();
}, function(e) {
    return t({}[e], e);
}), t(1699270751486));