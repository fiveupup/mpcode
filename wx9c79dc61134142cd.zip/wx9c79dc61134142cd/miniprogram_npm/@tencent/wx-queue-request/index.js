var e, t, i = require("../../../@babel/runtime/helpers/typeof");

module.exports = (e = {}, t = function(t, o) {
    if (!e[t]) return require(o);
    if (!e[t].status) {
        var n = e[t].m;
        n._exports = n._tempexports;
        var s = Object.getOwnPropertyDescriptor(n, "exports");
        s && s.configurable && Object.defineProperty(n, "exports", {
            set: function(e) {
                "object" === i(e) && e !== n._exports && (n._exports.__proto__ = e.__proto__, Object.keys(e).forEach(function(t) {
                    n._exports[t] = e[t];
                })), n._tempexports = e;
            },
            get: function() {
                return n._tempexports;
            }
        }), e[t].status = 1, e[t].func(e[t].req, n, n.exports);
    }
    return e[t].m.exports;
}, function(t, i, o) {
    e[t] = {
        status: 0,
        func: i,
        req: o,
        m: {
            exports: {},
            _tempexports: {}
        }
    };
}(1699270751492, function(e, t, o) {
    !function(e, n) {
        "object" == i(o) && void 0 !== t ? t.exports = n() : "function" == typeof define && define.amd ? define(n) : (e = "undefined" != typeof globalThis ? globalThis : e || self)["@tencent/wx-queue-request"] = n();
    }(this, function() {
        var e = function() {
            return (e = Object.assign || function(e) {
                for (var t, i = 1, o = arguments.length; i < o; i++) for (var n in t = arguments[i]) Object.prototype.hasOwnProperty.call(t, n) && (e[n] = t[n]);
                return e;
            }).apply(this, arguments);
        };
        i.prototype.add = function(t) {
            var i = this, o = e({}, t);
            return o.complete = function() {
                for (var e, o = [], n = 0; n < arguments.length; n++) o[n] = arguments[n];
                null != (e = t.complete) && e.call.apply(e, function(e, t, i) {
                    if (i || 2 === arguments.length) for (var o, n = 0, s = t.length; n < s; n++) !o && n in t || ((o = o || Array.prototype.slice.call(t, 0, n))[n] = t[n]);
                    return e.concat(o || Array.prototype.slice.call(t));
                }([ t ], o, !1)), i.remove(t._qrseq);
            }, this.pool[t._qrseq] = !0, this.originRequest(o);
        }, i.prototype.remove = function(e) {
            var t;
            delete this.pool[e], null != (t = (e = this.config).onReqComplete) && t.call(e);
        }, i.prototype.getReqNum = function() {
            return Object.keys(this.pool).length;
        };
        var t = i;
        function i(e) {
            void 0 === e && (e = {}), this.pool = {}, this.config = e, this.originRequest = wx.request.bind(wx);
        }
        n.prototype.offChunkReceived = function(e) {
            throw new Error("Method not implemented.");
        }, n.prototype.onChunkReceived = function(e) {
            throw new Error("Method not implemented.");
        }, n.prototype.setRequestTask = function(e) {
            if (this.task) throw new Error("RequestTask has been set");
            this.task = e, this.operations.forEach(function(t) {
                switch (t.type) {
                  case "on":
                    e.onHeadersReceived(t.cb);
                    break;

                  case "off":
                    e.offHeadersReceived(t.cb);
                    break;

                  case "abort":
                    e.abort();
                }
            }), this.operations = [];
        }, n.prototype.abort = function() {
            this.task ? this.task.abort() : this.operations.push({
                type: "abort"
            });
        }, n.prototype.offHeadersReceived = function(e) {
            this.task ? this.task.offHeadersReceived(e) : this.operations.push({
                type: "off",
                cb: e
            });
        }, n.prototype.onHeadersReceived = function(e) {
            this.task ? this.task.onHeadersReceived(e) : this.operations.push({
                type: "on",
                cb: e
            });
        };
        var o = n;
        function n() {
            this.operations = [];
        }
        r.prototype.startTimer = function() {
            var e = this;
            this.timer || (this.timer = setInterval(function() {
                return e.checkHeadTimeout();
            }, this.config.maxWaitingTime / 2));
        }, r.prototype.checkHeadTimeout = function() {
            var e, t, i;
            this.queue.length && (i = this.queue[0], Date.now() - i._qrtime > this.config.maxWaitingTime && null != (t = (e = this.config).onWaitingTimeout) && t.call(e, i));
        }, r.prototype.enqueue = function(e) {
            this.queue.push(e), this.startTimer();
            var t = new o();
            return this.reqTaskProxys[e._qrseq] = t, this.queue.length > this.config.maxQueueLen && this.dequeueAbandon(), 
            t;
        }, r.prototype.dequeueAll = function() {
            for (;this.queue.length; ) this.dequeue();
        }, r.prototype.dequeue = function() {
            var e, t, i, o = this.queue.shift();
            o && (console.log("[queueRequest]延迟发送请求", "seq:", o._qrseq, "等待时长:", Date.now() - (null != (i = o._qrtime) ? i : 0), "url:", o.url), 
            i = this.config.request(o), null != (t = null == (e = this.reqTaskProxys[o._qrseq]) ? void 0 : e.setRequestTask) && t.call(e, i), 
            delete this.reqTaskProxys[o._qrseq]), !this.queue.length && this.timer && (clearInterval(this.timer), 
            this.timer = void 0);
        }, r.prototype.dequeueAbandon = function() {
            var e, t, i = this.queue.shift();
            i && (null != (t = (e = this.config).onRequestAbandon) && t.call(e, i), delete this.reqTaskProxys[i._qrseq], 
            console.log("[queueRequest]丢弃请求", "seq:", null == i ? void 0 : i._qrseq, "等待队列长度:", this.queue.length, "url:", i.url));
        }, r.prototype.getWaitingNum = function() {
            return this.queue.length;
        };
        var s = r;
        function r(e) {
            this.queue = [], this.reqTaskProxys = {}, this.config = e;
        }
        u = Number.MAX_SAFE_INTEGER, a = 0;
        var u, a, h = (c.prototype.formatConfig = function(e) {
            return {
                lowPriority: (e = void 0 === e ? {} : e).lowPriority || [],
                busyThreshold: e.busyThreshold || 5,
                fullThreshold: e.busyThreshold || 8,
                maxQueueLen: e.maxQueueLen || 20,
                maxWaitingTime: e.maxWaitingTime || 3e3
            };
        }, c.prototype.queueRequest = function(t) {
            var i, o = e(e({}, t), {
                _qrseq: (u <= a && (a = 0), a++),
                _qrtime: Date.now()
            });
            switch (!0) {
              case !this.useWaiting:
              case i = t.url, !this.config.lowPriority.find(function(e) {
                    return e.test(i);
                }):
              case this.requestPool.getReqNum() < this.config.busyThreshold:
                return this.requestPool.add(o);

              default:
                return this.waitingQueue.enqueue(o);
            }
        }, c.prototype.make = function() {
            this.originRequest = wx.request, this.useWaiting = !0, Object.defineProperty(wx, "request", {
                value: this.queueRequest.bind(this)
            }), wx.onAppHide(this.onAppHide), wx.onAppShow(this.onAppShow);
        }, c.prototype.recover = function() {
            this.useWaiting = !1, this.waitingQueue.dequeueAll(), this.originRequest && Object.defineProperty(wx, "request", {
                value: this.originRequest
            }), wx.offAppHide(this.onAppHide), wx.offAppShow(this.onAppShow);
        }, c);
        function c(e) {
            var i = this;
            this.useWaiting = !1, this.checkWaitingRequest = function() {
                i.requestPool.getReqNum() < i.config.busyThreshold && i.waitingQueue.getWaitingNum() && i.waitingQueue.dequeue();
            }, this.checkTimeoutWaitingRequest = function() {
                i.requestPool.getReqNum() < i.config.fullThreshold && i.waitingQueue.getWaitingNum() && i.waitingQueue.dequeue();
            }, this.onWaitingQueueAbandon = function() {
                wx.reportMonitor("0", 1);
            }, this.onAppHide = function() {
                i.useWaiting = !1, i.waitingQueue.dequeueAll();
            }, this.onAppShow = function() {
                i.useWaiting = !0;
            }, this.config = this.formatConfig(e), this.requestPool = new t({
                onReqComplete: this.checkWaitingRequest
            }), this.waitingQueue = new s({
                request: this.requestPool.add.bind(this.requestPool),
                maxWaitingTime: this.config.maxWaitingTime,
                maxQueueLen: this.config.maxQueueLen,
                onWaitingTimeout: this.checkTimeoutWaitingRequest,
                onRequestAbandon: this.onWaitingQueueAbandon
            });
        }
        return function(e) {
            return (e = new h(e)).make(), e;
        };
    });
}, function(e) {
    return t({}[e], e);
}), t(1699270751492));