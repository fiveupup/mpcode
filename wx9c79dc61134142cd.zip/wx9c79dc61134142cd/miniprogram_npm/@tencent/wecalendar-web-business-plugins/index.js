require("../../../@babel/runtime/helpers/Arrayincludes"), require("../../../@babel/runtime/helpers/Objectvalues");

var t, e, n, r = require("../../../@babel/runtime/helpers/typeof");

module.exports = (t = {}, n = function(e, n) {
    if (!t[e]) return require(n);
    if (!t[e].status) {
        var o = t[e].m;
        o._exports = o._tempexports;
        var i = Object.getOwnPropertyDescriptor(o, "exports");
        i && i.configurable && Object.defineProperty(o, "exports", {
            set: function(t) {
                "object" === r(t) && t !== o._exports && (o._exports.__proto__ = t.__proto__, Object.keys(t).forEach(function(e) {
                    o._exports[e] = t[e];
                })), o._tempexports = t;
            },
            get: function() {
                return o._tempexports;
            }
        }), t[e].status = 1, t[e].func(t[e].req, o, o.exports);
    }
    return t[e].m.exports;
}, (e = function(e, n, r) {
    t[e] = {
        status: 0,
        func: n,
        req: r,
        m: {
            exports: {},
            _tempexports: {}
        }
    };
})(1699270751487, function(t, e, n) {
    var r = t("./dist/util"), o = t("./dist/timeInterval"), i = t("./dist/lunar").solar2lunar, a = t("./dist/permission").Permission;
    e.exports = {
        util: r,
        timeInterval: o,
        solar2lunar: i,
        Permission: a
    };
}, function(t) {
    return n({
        "./dist/util": 1699270751488,
        "./dist/timeInterval": 1699270751489,
        "./dist/lunar": 1699270751490,
        "./dist/permission": 1699270751491
    }[t], t);
}), e(1699270751488, function(t, e, n) {
    !function(t, o) {
        if ("object" == r(n) && "object" == r(e)) e.exports = o(); else if ("function" == typeof define && define.amd) define([], o); else {
            var i = o();
            for (var a in i) ("object" == r(n) ? n : t)[a] = i[a];
        }
    }(this, function() {
        return function() {
            var t = {
                965: function(t) {
                    var e = {
                        utf8: {
                            stringToBytes: function(t) {
                                return e.bin.stringToBytes(unescape(encodeURIComponent(t)));
                            },
                            bytesToString: function(t) {
                                return decodeURIComponent(escape(e.bin.bytesToString(t)));
                            }
                        },
                        bin: {
                            stringToBytes: function(t) {
                                for (var e = [], n = 0; n < t.length; n++) e.push(255 & t.charCodeAt(n));
                                return e;
                            },
                            bytesToString: function(t) {
                                for (var e = [], n = 0; n < t.length; n++) e.push(String.fromCharCode(t[n]));
                                return e.join("");
                            }
                        }
                    };
                    t.exports = e;
                },
                332: function(t) {
                    var e, n;
                    e = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/", n = {
                        rotl: function(t, e) {
                            return t << e | t >>> 32 - e;
                        },
                        rotr: function(t, e) {
                            return t << 32 - e | t >>> e;
                        },
                        endian: function(t) {
                            if (t.constructor == Number) return 16711935 & n.rotl(t, 8) | 4278255360 & n.rotl(t, 24);
                            for (var e = 0; e < t.length; e++) t[e] = n.endian(t[e]);
                            return t;
                        },
                        randomBytes: function(t) {
                            for (var e = []; t > 0; t--) e.push(Math.floor(256 * Math.random()));
                            return e;
                        },
                        bytesToWords: function(t) {
                            for (var e = [], n = 0, r = 0; n < t.length; n++, r += 8) e[r >>> 5] |= t[n] << 24 - r % 32;
                            return e;
                        },
                        wordsToBytes: function(t) {
                            for (var e = [], n = 0; n < 32 * t.length; n += 8) e.push(t[n >>> 5] >>> 24 - n % 32 & 255);
                            return e;
                        },
                        bytesToHex: function(t) {
                            for (var e = [], n = 0; n < t.length; n++) e.push((t[n] >>> 4).toString(16)), e.push((15 & t[n]).toString(16));
                            return e.join("");
                        },
                        hexToBytes: function(t) {
                            for (var e = [], n = 0; n < t.length; n += 2) e.push(parseInt(t.substr(n, 2), 16));
                            return e;
                        },
                        bytesToBase64: function(t) {
                            for (var n = [], r = 0; r < t.length; r += 3) for (var o = t[r] << 16 | t[r + 1] << 8 | t[r + 2], i = 0; i < 4; i++) 8 * r + 6 * i <= 8 * t.length ? n.push(e.charAt(o >>> 6 * (3 - i) & 63)) : n.push("=");
                            return n.join("");
                        },
                        base64ToBytes: function(t) {
                            t = t.replace(/[^A-Z0-9+\/]/gi, "");
                            for (var n = [], r = 0, o = 0; r < t.length; o = ++r % 4) 0 != o && n.push((e.indexOf(t.charAt(r - 1)) & Math.pow(2, -2 * o + 8) - 1) << 2 * o | e.indexOf(t.charAt(r)) >>> 6 - 2 * o);
                            return n;
                        }
                    }, t.exports = n;
                },
                516: function(t, e, n) {
                    var o, i, a;
                    function u(t) {
                        return (u = "function" == typeof Symbol && "symbol" == r(Symbol.iterator) ? function(t) {
                            return r(t);
                        } : function(t) {
                            return t && "function" == typeof Symbol && t.constructor === Symbol && t !== Symbol.prototype ? "symbol" : r(t);
                        })(t);
                    }
                    a = function() {
                        var t = 6e4, e = 36e5, n = "millisecond", r = "second", o = "minute", i = "hour", a = "day", c = "week", s = "month", f = "quarter", l = "year", h = "date", d = "Invalid Date", v = /^(\d{4})[-/]?(\d{1,2})?[-/]?(\d{0,2})[Tt\s]*(\d{1,2})?:?(\d{1,2})?:?(\d{1,2})?[.:]?(\d+)?$/, p = /\[([^\]]+)]|Y{1,4}|M{1,4}|D{1,2}|d{1,4}|H{1,2}|h{1,2}|a|A|m{1,2}|s{1,2}|Z{1,2}|SSS/g, y = {
                            name: "en",
                            weekdays: "Sunday_Monday_Tuesday_Wednesday_Thursday_Friday_Saturday".split("_"),
                            months: "January_February_March_April_May_June_July_August_September_October_November_December".split("_")
                        }, g = function(t, e, n) {
                            var r = String(t);
                            return !r || r.length >= e ? t : "" + Array(e + 1 - r.length).join(n) + t;
                        }, b = {
                            s: g,
                            z: function(t) {
                                var e = -t.utcOffset(), n = Math.abs(e), r = Math.floor(n / 60), o = n % 60;
                                return (e <= 0 ? "+" : "-") + g(r, 2, "0") + ":" + g(o, 2, "0");
                            },
                            m: function t(e, n) {
                                if (e.date() < n.date()) return -t(n, e);
                                var r = 12 * (n.year() - e.year()) + (n.month() - e.month()), o = e.clone().add(r, s), i = n - o < 0, a = e.clone().add(r + (i ? -1 : 1), s);
                                return +(-(r + (n - o) / (i ? o - a : a - o)) || 0);
                            },
                            a: function(t) {
                                return t < 0 ? Math.ceil(t) || 0 : Math.floor(t);
                            },
                            p: function(t) {
                                return {
                                    M: s,
                                    y: l,
                                    w: c,
                                    d: a,
                                    D: h,
                                    h: i,
                                    m: o,
                                    s: r,
                                    ms: n,
                                    Q: f
                                }[t] || String(t || "").toLowerCase().replace(/s$/, "");
                            },
                            u: function(t) {
                                return void 0 === t;
                            }
                        }, m = "en", M = {};
                        M[m] = y;
                        var D = function(t) {
                            return t instanceof O;
                        }, w = function t(e, n, r) {
                            var o;
                            if (!e) return m;
                            if ("string" == typeof e) {
                                var i = e.toLowerCase();
                                M[i] && (o = i), n && (M[i] = n, o = i);
                                var a = e.split("-");
                                if (!o && a.length > 1) return t(a[0]);
                            } else {
                                var u = e.name;
                                M[u] = e, o = u;
                            }
                            return !r && o && (m = o), o || !r && m;
                        }, $ = function(t, e) {
                            if (D(t)) return t.clone();
                            var n = "object" == u(e) ? e : {};
                            return n.date = t, n.args = arguments, new O(n);
                        }, S = b;
                        S.l = w, S.i = D, S.w = function(t, e) {
                            return $(t, {
                                locale: e.$L,
                                utc: e.$u,
                                x: e.$x,
                                $offset: e.$offset
                            });
                        };
                        var O = function() {
                            function u(t) {
                                this.$L = w(t.locale, null, !0), this.parse(t);
                            }
                            var y = u.prototype;
                            return y.parse = function(t) {
                                this.$d = function(t) {
                                    var e = t.date, n = t.utc;
                                    if (null === e) return new Date(NaN);
                                    if (S.u(e)) return new Date();
                                    if (e instanceof Date) return new Date(e);
                                    if ("string" == typeof e && !/Z$/i.test(e)) {
                                        var r = e.match(v);
                                        if (r) {
                                            var o = r[2] - 1 || 0, i = (r[7] || "0").substring(0, 3);
                                            return n ? new Date(Date.UTC(r[1], o, r[3] || 1, r[4] || 0, r[5] || 0, r[6] || 0, i)) : new Date(r[1], o, r[3] || 1, r[4] || 0, r[5] || 0, r[6] || 0, i);
                                        }
                                    }
                                    return new Date(e);
                                }(t), this.$x = t.x || {}, this.init();
                            }, y.init = function() {
                                var t = this.$d;
                                this.$y = t.getFullYear(), this.$M = t.getMonth(), this.$D = t.getDate(), this.$W = t.getDay(), 
                                this.$H = t.getHours(), this.$m = t.getMinutes(), this.$s = t.getSeconds(), this.$ms = t.getMilliseconds();
                            }, y.$utils = function() {
                                return S;
                            }, y.isValid = function() {
                                return !(this.$d.toString() === d);
                            }, y.isSame = function(t, e) {
                                var n = $(t);
                                return this.startOf(e) <= n && n <= this.endOf(e);
                            }, y.isAfter = function(t, e) {
                                return $(t) < this.startOf(e);
                            }, y.isBefore = function(t, e) {
                                return this.endOf(e) < $(t);
                            }, y.$g = function(t, e, n) {
                                return S.u(t) ? this[e] : this.set(n, t);
                            }, y.unix = function() {
                                return Math.floor(this.valueOf() / 1e3);
                            }, y.valueOf = function() {
                                return this.$d.getTime();
                            }, y.startOf = function(t, e) {
                                var n = this, u = !!S.u(e) || e, f = S.p(t), d = function(t, e) {
                                    var r = S.w(n.$u ? Date.UTC(n.$y, e, t) : new Date(n.$y, e, t), n);
                                    return u ? r : r.endOf(a);
                                }, v = function(t, e) {
                                    return S.w(n.toDate()[t].apply(n.toDate("s"), (u ? [ 0, 0, 0, 0 ] : [ 23, 59, 59, 999 ]).slice(e)), n);
                                }, p = this.$W, y = this.$M, g = this.$D, b = "set" + (this.$u ? "UTC" : "");
                                switch (f) {
                                  case l:
                                    return u ? d(1, 0) : d(31, 11);

                                  case s:
                                    return u ? d(1, y) : d(0, y + 1);

                                  case c:
                                    var m = this.$locale().weekStart || 0, M = (p < m ? p + 7 : p) - m;
                                    return d(u ? g - M : g + (6 - M), y);

                                  case a:
                                  case h:
                                    return v(b + "Hours", 0);

                                  case i:
                                    return v(b + "Minutes", 1);

                                  case o:
                                    return v(b + "Seconds", 2);

                                  case r:
                                    return v(b + "Milliseconds", 3);

                                  default:
                                    return this.clone();
                                }
                            }, y.endOf = function(t) {
                                return this.startOf(t, !1);
                            }, y.$set = function(t, e) {
                                var u, c = S.p(t), f = "set" + (this.$u ? "UTC" : ""), d = (u = {}, u[a] = f + "Date", 
                                u[h] = f + "Date", u[s] = f + "Month", u[l] = f + "FullYear", u[i] = f + "Hours", 
                                u[o] = f + "Minutes", u[r] = f + "Seconds", u[n] = f + "Milliseconds", u)[c], v = c === a ? this.$D + (e - this.$W) : e;
                                if (c === s || c === l) {
                                    var p = this.clone().set(h, 1);
                                    p.$d[d](v), p.init(), this.$d = p.set(h, Math.min(this.$D, p.daysInMonth())).$d;
                                } else d && this.$d[d](v);
                                return this.init(), this;
                            }, y.set = function(t, e) {
                                return this.clone().$set(t, e);
                            }, y.get = function(t) {
                                return this[S.p(t)]();
                            }, y.add = function(n, u) {
                                var f, h = this;
                                n = Number(n);
                                var d = S.p(u), v = function(t) {
                                    var e = $(h);
                                    return S.w(e.date(e.date() + Math.round(t * n)), h);
                                };
                                if (d === s) return this.set(s, this.$M + n);
                                if (d === l) return this.set(l, this.$y + n);
                                if (d === a) return v(1);
                                if (d === c) return v(7);
                                var p = (f = {}, f[o] = t, f[i] = e, f[r] = 1e3, f)[d] || 1, y = this.$d.getTime() + n * p;
                                return S.w(y, this);
                            }, y.subtract = function(t, e) {
                                return this.add(-1 * t, e);
                            }, y.format = function(t) {
                                var e = this, n = this.$locale();
                                if (!this.isValid()) return n.invalidDate || d;
                                var r = t || "YYYY-MM-DDTHH:mm:ssZ", o = S.z(this), i = this.$H, a = this.$m, u = this.$M, c = n.weekdays, s = n.months, f = function(t, n, o, i) {
                                    return t && (t[n] || t(e, r)) || o[n].slice(0, i);
                                }, l = function(t) {
                                    return S.s(i % 12 || 12, t, "0");
                                }, h = n.meridiem || function(t, e, n) {
                                    var r = t < 12 ? "AM" : "PM";
                                    return n ? r.toLowerCase() : r;
                                }, v = {
                                    YY: String(this.$y).slice(-2),
                                    YYYY: this.$y,
                                    M: u + 1,
                                    MM: S.s(u + 1, 2, "0"),
                                    MMM: f(n.monthsShort, u, s, 3),
                                    MMMM: f(s, u),
                                    D: this.$D,
                                    DD: S.s(this.$D, 2, "0"),
                                    d: String(this.$W),
                                    dd: f(n.weekdaysMin, this.$W, c, 2),
                                    ddd: f(n.weekdaysShort, this.$W, c, 3),
                                    dddd: c[this.$W],
                                    H: String(i),
                                    HH: S.s(i, 2, "0"),
                                    h: l(1),
                                    hh: l(2),
                                    a: h(i, a, !0),
                                    A: h(i, a, !1),
                                    m: String(a),
                                    mm: S.s(a, 2, "0"),
                                    s: String(this.$s),
                                    ss: S.s(this.$s, 2, "0"),
                                    SSS: S.s(this.$ms, 3, "0"),
                                    Z: o
                                };
                                return r.replace(p, function(t, e) {
                                    return e || v[t] || o.replace(":", "");
                                });
                            }, y.utcOffset = function() {
                                return 15 * -Math.round(this.$d.getTimezoneOffset() / 15);
                            }, y.diff = function(n, u, h) {
                                var d, v = S.p(u), p = $(n), y = (p.utcOffset() - this.utcOffset()) * t, g = this - p, b = S.m(this, p);
                                return b = (d = {}, d[l] = b / 12, d[s] = b, d[f] = b / 3, d[c] = (g - y) / 6048e5, 
                                d[a] = (g - y) / 864e5, d[i] = g / e, d[o] = g / t, d[r] = g / 1e3, d)[v] || g, 
                                h ? b : S.a(b);
                            }, y.daysInMonth = function() {
                                return this.endOf(s).$D;
                            }, y.$locale = function() {
                                return M[this.$L];
                            }, y.locale = function(t, e) {
                                if (!t) return this.$L;
                                var n = this.clone(), r = w(t, e, !0);
                                return r && (n.$L = r), n;
                            }, y.clone = function() {
                                return S.w(this.$d, this);
                            }, y.toDate = function() {
                                return new Date(this.valueOf());
                            }, y.toJSON = function() {
                                return this.isValid() ? this.toISOString() : null;
                            }, y.toISOString = function() {
                                return this.$d.toISOString();
                            }, y.toString = function() {
                                return this.$d.toUTCString();
                            }, u;
                        }(), T = O.prototype;
                        return $.prototype = T, [ [ "$ms", n ], [ "$s", r ], [ "$m", o ], [ "$H", i ], [ "$W", a ], [ "$M", s ], [ "$y", l ], [ "$D", h ] ].forEach(function(t) {
                            T[t[1]] = function(e) {
                                return this.$g(e, t[0], t[1]);
                            };
                        }), $.extend = function(t, e) {
                            return t.$i || (t(e, O, $), t.$i = !0), $;
                        }, $.locale = w, $.isDayjs = D, $.unix = function(t) {
                            return $(1e3 * t);
                        }, $.en = M[m], $.Ls = M, $.p = {}, $;
                    }, "object" == u(e) ? t.exports = a() : void 0 === (i = "function" == typeof (o = a) ? o.call(e, n, e, t) : o) || (t.exports = i);
                },
                343: function(t) {
                    function e(t) {
                        return !!t.constructor && "function" == typeof t.constructor.isBuffer && t.constructor.isBuffer(t);
                    }
                    t.exports = function(t) {
                        return null != t && (e(t) || function(t) {
                            return "function" == typeof t.readFloatLE && "function" == typeof t.slice && e(t.slice(0, 0));
                        }(t) || !!t._isBuffer);
                    };
                },
                546: function(t, e, n) {
                    var r, o, i, a, u;
                    r = n(332), o = n(965).utf8, i = n(343), a = n(965).bin, (u = function t(e, n) {
                        e.constructor == String ? e = n && "binary" === n.encoding ? a.stringToBytes(e) : o.stringToBytes(e) : i(e) ? e = Array.prototype.slice.call(e, 0) : Array.isArray(e) || e.constructor === Uint8Array || (e = e.toString());
                        for (var u = r.bytesToWords(e), c = 8 * e.length, s = 1732584193, f = -271733879, l = -1732584194, h = 271733878, d = 0; d < u.length; d++) u[d] = 16711935 & (u[d] << 8 | u[d] >>> 24) | 4278255360 & (u[d] << 24 | u[d] >>> 8);
                        u[c >>> 5] |= 128 << c % 32, u[14 + (c + 64 >>> 9 << 4)] = c;
                        var v = t._ff, p = t._gg, y = t._hh, g = t._ii;
                        for (d = 0; d < u.length; d += 16) {
                            var b = s, m = f, M = l, D = h;
                            s = v(s, f, l, h, u[d + 0], 7, -680876936), h = v(h, s, f, l, u[d + 1], 12, -389564586), 
                            l = v(l, h, s, f, u[d + 2], 17, 606105819), f = v(f, l, h, s, u[d + 3], 22, -1044525330), 
                            s = v(s, f, l, h, u[d + 4], 7, -176418897), h = v(h, s, f, l, u[d + 5], 12, 1200080426), 
                            l = v(l, h, s, f, u[d + 6], 17, -1473231341), f = v(f, l, h, s, u[d + 7], 22, -45705983), 
                            s = v(s, f, l, h, u[d + 8], 7, 1770035416), h = v(h, s, f, l, u[d + 9], 12, -1958414417), 
                            l = v(l, h, s, f, u[d + 10], 17, -42063), f = v(f, l, h, s, u[d + 11], 22, -1990404162), 
                            s = v(s, f, l, h, u[d + 12], 7, 1804603682), h = v(h, s, f, l, u[d + 13], 12, -40341101), 
                            l = v(l, h, s, f, u[d + 14], 17, -1502002290), s = p(s, f = v(f, l, h, s, u[d + 15], 22, 1236535329), l, h, u[d + 1], 5, -165796510), 
                            h = p(h, s, f, l, u[d + 6], 9, -1069501632), l = p(l, h, s, f, u[d + 11], 14, 643717713), 
                            f = p(f, l, h, s, u[d + 0], 20, -373897302), s = p(s, f, l, h, u[d + 5], 5, -701558691), 
                            h = p(h, s, f, l, u[d + 10], 9, 38016083), l = p(l, h, s, f, u[d + 15], 14, -660478335), 
                            f = p(f, l, h, s, u[d + 4], 20, -405537848), s = p(s, f, l, h, u[d + 9], 5, 568446438), 
                            h = p(h, s, f, l, u[d + 14], 9, -1019803690), l = p(l, h, s, f, u[d + 3], 14, -187363961), 
                            f = p(f, l, h, s, u[d + 8], 20, 1163531501), s = p(s, f, l, h, u[d + 13], 5, -1444681467), 
                            h = p(h, s, f, l, u[d + 2], 9, -51403784), l = p(l, h, s, f, u[d + 7], 14, 1735328473), 
                            s = y(s, f = p(f, l, h, s, u[d + 12], 20, -1926607734), l, h, u[d + 5], 4, -378558), 
                            h = y(h, s, f, l, u[d + 8], 11, -2022574463), l = y(l, h, s, f, u[d + 11], 16, 1839030562), 
                            f = y(f, l, h, s, u[d + 14], 23, -35309556), s = y(s, f, l, h, u[d + 1], 4, -1530992060), 
                            h = y(h, s, f, l, u[d + 4], 11, 1272893353), l = y(l, h, s, f, u[d + 7], 16, -155497632), 
                            f = y(f, l, h, s, u[d + 10], 23, -1094730640), s = y(s, f, l, h, u[d + 13], 4, 681279174), 
                            h = y(h, s, f, l, u[d + 0], 11, -358537222), l = y(l, h, s, f, u[d + 3], 16, -722521979), 
                            f = y(f, l, h, s, u[d + 6], 23, 76029189), s = y(s, f, l, h, u[d + 9], 4, -640364487), 
                            h = y(h, s, f, l, u[d + 12], 11, -421815835), l = y(l, h, s, f, u[d + 15], 16, 530742520), 
                            s = g(s, f = y(f, l, h, s, u[d + 2], 23, -995338651), l, h, u[d + 0], 6, -198630844), 
                            h = g(h, s, f, l, u[d + 7], 10, 1126891415), l = g(l, h, s, f, u[d + 14], 15, -1416354905), 
                            f = g(f, l, h, s, u[d + 5], 21, -57434055), s = g(s, f, l, h, u[d + 12], 6, 1700485571), 
                            h = g(h, s, f, l, u[d + 3], 10, -1894986606), l = g(l, h, s, f, u[d + 10], 15, -1051523), 
                            f = g(f, l, h, s, u[d + 1], 21, -2054922799), s = g(s, f, l, h, u[d + 8], 6, 1873313359), 
                            h = g(h, s, f, l, u[d + 15], 10, -30611744), l = g(l, h, s, f, u[d + 6], 15, -1560198380), 
                            f = g(f, l, h, s, u[d + 13], 21, 1309151649), s = g(s, f, l, h, u[d + 4], 6, -145523070), 
                            h = g(h, s, f, l, u[d + 11], 10, -1120210379), l = g(l, h, s, f, u[d + 2], 15, 718787259), 
                            f = g(f, l, h, s, u[d + 9], 21, -343485551), s = s + b >>> 0, f = f + m >>> 0, l = l + M >>> 0, 
                            h = h + D >>> 0;
                        }
                        return r.endian([ s, f, l, h ]);
                    })._ff = function(t, e, n, r, o, i, a) {
                        var u = t + (e & n | ~e & r) + (o >>> 0) + a;
                        return (u << i | u >>> 32 - i) + e;
                    }, u._gg = function(t, e, n, r, o, i, a) {
                        var u = t + (e & r | n & ~r) + (o >>> 0) + a;
                        return (u << i | u >>> 32 - i) + e;
                    }, u._hh = function(t, e, n, r, o, i, a) {
                        var u = t + (e ^ n ^ r) + (o >>> 0) + a;
                        return (u << i | u >>> 32 - i) + e;
                    }, u._ii = function(t, e, n, r, o, i, a) {
                        var u = t + (n ^ (e | ~r)) + (o >>> 0) + a;
                        return (u << i | u >>> 32 - i) + e;
                    }, u._blocksize = 16, u._digestsize = 16, t.exports = function(t, e) {
                        if (null == t) throw new Error("Illegal argument " + t);
                        var n = r.wordsToBytes(u(t, e));
                        return e && e.asBytes ? n : e && e.asString ? a.bytesToString(n) : r.bytesToHex(n);
                    };
                },
                311: function(t, e, n) {
                    var r = n(885), o = [ 19416, 19168, 42352, 21717, 53856, 55632, 91476, 22176, 39632, 21970, 19168, 42422, 42192, 53840, 119381, 46400, 54944, 44450, 38320, 84343, 18800, 42160, 46261, 27216, 27968, 109396, 11104, 38256, 21234, 18800, 25958, 54432, 59984, 28309, 23248, 11104, 100067, 37600, 116951, 51536, 54432, 120998, 46416, 22176, 107956, 9680, 37584, 53938, 43344, 46423, 27808, 46416, 86869, 19872, 42416, 83315, 21168, 43432, 59728, 27296, 44710, 43856, 19296, 43748, 42352, 21088, 62051, 55632, 23383, 22176, 38608, 19925, 19152, 42192, 54484, 53840, 54616, 46400, 46752, 103846, 38320, 18864, 43380, 42160, 45690, 27216, 27968, 44870, 43872, 38256, 19189, 18800, 25776, 29859, 59984, 27480, 21952, 43872, 38613, 37600, 51552, 55636, 54432, 55888, 30034, 22176, 43959, 9680, 37584, 51893, 43344, 46240, 47780, 44368, 21977, 19360, 42416, 86390, 21168, 43312, 31060, 27296, 44368, 23378, 19296, 42726, 42208, 53856, 60005, 54576, 23200, 30371, 38608, 19195, 19152, 42192, 118966, 53840, 54560, 56645, 46496, 22224, 21938, 18864, 42359, 42160, 43600, 111189, 27936, 44448, 84835, 37744, 18936, 18800, 25776, 92326, 59984, 27424, 108228, 43744, 41696, 53987, 51552, 54615, 54432, 55888, 23893, 22176, 42704, 21972, 21200, 43448, 43344, 46240, 46758, 44368, 21920, 43940, 42416, 21168, 45683, 26928, 29495, 27296, 44368, 84821, 19296, 42352, 21732, 53600, 59752, 54560, 55968, 92838, 22224, 19168, 43476, 41680, 53584, 62034, 54560 ], i = [ "日", "一", "二", "三", "四", "五", "六", "七", "八", "九", "十" ], a = [ "初", "十", "廿", "卅" ], u = [ "正", "二", "三", "四", "五", "六", "七", "八", "九", "十", "冬", "腊" ];
                    function c(t) {
                        var e, n = 348;
                        for (e = 32768; e > 8; e >>= 1) n += o[t - 1900] & e ? 1 : 0;
                        return n + f(t);
                    }
                    function s(t) {
                        return 15 & o[t - 1900];
                    }
                    function f(t) {
                        return s(t) ? 65536 & o[t - 1900] ? 30 : 29 : 0;
                    }
                    function l(t) {
                        return t > 12 || t < 1 ? -1 : u[t - 1] + "月";
                    }
                    function h(t) {
                        var e;
                        switch (t) {
                          case 10:
                            e = "初十";
                            break;

                          case 20:
                            e = "二十";
                            break;

                          case 30:
                            e = "三十";
                            break;

                          default:
                            e = a[Math.floor(t / 10)], e += i[t % 10];
                        }
                        return e;
                    }
                    t.exports = {
                        solar2lunar: function(t) {
                            var e, n = t.getFullYear(), i = t.getMonth() + 1, a = t.getDate();
                            if (n < 1900 || n > 2100) return -1;
                            if (1900 === n && 1 === n && a < 31) return -1;
                            var u = 0, d = (Date.UTC(t.getFullYear(), t.getMonth(), t.getDate()) - Date.UTC(1900, 0, 31)) / 864e5;
                            for (e = 1900; e < 2101 && d > 0; e++) d -= u = c(e);
                            d < 0 && (d += u, e -= 1);
                            var v, p = e, y = s(e), g = !1;
                            for (e = 1; e < 13 && d > 0; e++) y > 0 && e === y + 1 && !1 === g ? (--e, g = !0, 
                            u = f(p)) : u = (v = e) > 12 || v < 1 ? -1 : o[p - 1900] & 65536 >> v ? 30 : 29, 
                            !0 === g && e === y + 1 && (g = !1), d -= u;
                            0 === d && y > 0 && e === y + 1 && (g ? g = !1 : (g = !0, --e)), d < 0 && (d += u, 
                            --e);
                            var b = e, m = d + 1, M = r(n, i, a);
                            return {
                                lunarYear: p,
                                lunarMonth: b,
                                lunarDay: m,
                                lunarMonthCn: (g ? "闰" : "") + l(b),
                                lunarDayCn: h(m),
                                lunarTerm: M
                            };
                        }
                    };
                },
                885: function(t) {
                    var e, n = [], r = [ "小寒", "大寒", "立春", "雨水", "惊蛰", "春分", "清明", "谷雨", "立夏", "小满", "芒种", "夏至", "小暑", "大暑", "立秋", "处暑", "白露", "秋分", "寒露", "霜降", "立冬", "小雪", "大雪", "冬至" ], o = {
                        1914: "立春",
                        1915: "惊蛰",
                        1923: "雨水",
                        1947: "立春",
                        1948: "惊蛰",
                        2000: "惊蛰春分清明立夏芒种夏至大暑立秋白露寒露霜降立冬小雪冬至小寒立春雨水",
                        2019: "小寒",
                        2021: "冬至",
                        2026: "雨水"
                    }, i = {
                        1902: "芒种",
                        1911: "立夏",
                        1914: "冬至",
                        1922: "大暑",
                        1925: "小暑",
                        1927: "白露",
                        1928: "夏至",
                        1942: "秋分",
                        1947: "冬至",
                        1951: "冬至",
                        1978: "小雪",
                        1980: "冬至",
                        1982: "小寒",
                        1984: "冬至",
                        2002: "立秋",
                        2008: "小满",
                        2016: "小暑",
                        2082: "大寒",
                        2089: "霜降立冬"
                    }, a = [ [ 6.11, 20.84, 4.6295, 19.4599, 6.3826, 21.4155, 5.59, 20.888, 6.318, 21.86, 6.5, 22.2, 7.928, 23.65, 8.35, 23.95, 8.44, 23.822, 9.098, 24.218, 8.218, 23.08, 7.9, 22.6 ], [ 5.4055, 20.12, 3.87, 18.73, 5.63, 20.646, 4.81, 20.1, 5.52, 21.04, 5.678, 21.37, 7.108, 22.83, 7.5, 23.13, 7.646, 23.042, 8.318, 23.438, 7.438, 22.36, 7.18, 21.94 ] ], u = function(t, e) {
                        var n = -1;
                        if (t > 1900 && t <= 2e3 ? n = 0 : t > 2e3 && t < 2100 && (n = 1), n < 0) return -1;
                        var o = a[n][e], i = t % 100, u = i, s = r[e];
                        return (t % 4 == 0 && t % 100 != 0 || t % 400 == 0) && e <= 3 && (u -= 1), Math.ceil(Math.floor(.2422 * i + o, 10) - u / 4) + c(t, s);
                    }, c = function(t, e) {
                        var n = 0;
                        return (n += s(o, t, e, -1)) + s(i, t, e, 1);
                    }, s = function(t, e, n, r) {
                        return t[e] && t[e].indexOf(n) > -1 ? r : 0;
                    };
                    t.exports = function(t, o, i) {
                        if (t < 1901 || t > 2099) return null;
                        var a = "".concat(o > 9 ? o : "0".concat(o)).concat(i > 9 ? i : "0".concat(i));
                        t !== e && function(t) {
                            e = t, n = [];
                            for (var r = 0, o = 1; o < 13; ) {
                                var i = "".concat(o > 9 ? o : "0".concat(o)), a = u(t, r), c = u(t, r += 1), s = "".concat(i).concat(a > 9 ? a : "0".concat(a)), f = "".concat(i).concat(c > 9 ? c : "0".concat(c));
                                n.push(s), n.push(f), r += 1, o += 1;
                            }
                        }(t);
                        var c = n.indexOf(a);
                        return c > -1 ? r[c] : null;
                    };
                }
            }, e = {};
            function n(r) {
                var o = e[r];
                if (void 0 !== o) return o.exports;
                var i = e[r] = {
                    exports: {}
                };
                return t[r].call(i.exports, i, i.exports, n), i.exports;
            }
            n.n = function(t) {
                var e = t && t.__esModule ? function() {
                    return t.default;
                } : function() {
                    return t;
                };
                return n.d(e, {
                    a: e
                }), e;
            }, n.d = function(t, e) {
                for (var r in e) n.o(e, r) && !n.o(t, r) && Object.defineProperty(t, r, {
                    enumerable: !0,
                    get: e[r]
                });
            }, n.o = function(t, e) {
                return Object.prototype.hasOwnProperty.call(t, e);
            }, n.r = function(t) {
                "undefined" != typeof Symbol && Symbol.toStringTag && Object.defineProperty(t, Symbol.toStringTag, {
                    value: "Module"
                }), Object.defineProperty(t, "__esModule", {
                    value: !0
                });
            };
            var o = {};
            return function() {
                n.r(o), n.d(o, {
                    hexMD5: function() {
                        return u;
                    },
                    reSortCrossDayScheduleList: function() {
                        return s;
                    },
                    dateFormat: function() {
                        return f;
                    },
                    formatMeetingCode: function() {
                        return l;
                    },
                    filterMeetingCode: function() {
                        return h;
                    },
                    RECURRINGOPTIONS: function() {
                        return b;
                    },
                    getRecurOptions: function() {
                        return M;
                    },
                    getDisableText: function() {
                        return D;
                    },
                    getDefaultDateInfo: function() {
                        return w;
                    },
                    getCustomRrule: function() {
                        return $;
                    },
                    getCurrentRecurringRule: function() {
                        return O;
                    },
                    getCurrentLunarRecurringRule: function() {
                        return T;
                    },
                    wrapFunctionEnableControl: function() {
                        return x;
                    },
                    getFunctionControl: function() {
                        return Y;
                    },
                    getEndLimitInfo: function() {
                        return k;
                    },
                    logInfo: function() {
                        return R;
                    }
                });
                var t = n(311), e = n(516), r = n.n(e), i = n(546), a = n.n(i);
                function u(t) {
                    return a()(t).toString().substring(0, 32);
                }
                var c = [ "周日", "周一", "周二", "周三", "周四", "周五", "周六" ], s = function(t, e) {
                    if (0 === e || !t[e] && !t[e - 1]) return t;
                    var n = t[e].eventList || [], r = t[e - 1].eventList || [], o = [], i = [];
                    if (n.forEach(function(t, e) {
                        if (t && t.crossDay && 0 !== t.crossDayIndex) {
                            var a = r.findIndex(function(e) {
                                return e && e.eventId === t.eventId && e.parentEventId === t.parentEventId;
                            });
                            if (a >= 0) {
                                if (0 === a && n[0] && n[0].onlyNewTag) return;
                                o.push(e), i.push(a);
                            }
                        }
                    }), o.length > 0) {
                        var a = [];
                        o.forEach(function(t, e) {
                            a[i[e]] = n[t];
                        }), n.forEach(function(t, e) {
                            if (-1 === o.indexOf(e)) {
                                for (var n = -1, r = a.length, i = 0; i < r; i++) if (!a[i]) {
                                    n = i;
                                    break;
                                }
                                n > -1 ? a[n] = t : a.push(t);
                            }
                        }), t[e].eventList = a;
                    }
                    return t;
                }, f = function(t) {
                    return r()(t).format("YYYY-MM-DD");
                };
                function l(t) {
                    var e;
                    switch ("".concat(t).length) {
                      case 10:
                        e = /(\w{3})(\w{3})(\w{4})/;
                        break;

                      case 11:
                        e = /(\w{3})(\w{4})(\w{4})/;
                        break;

                      case 12:
                        e = /(\w{4})(\w{4})(\w{4})/;
                        break;

                      default:
                        e = /(\w{3})(\w{3})(\w{3})/;
                    }
                    return t.replace(e, "$1 $2 $3");
                }
                function h(t) {
                    var e = !0, n = 2;
                    return t.includes("https://meeting.tencent.com/") || t.includes("tencentmeeting.com") || t.includes("https://work.weixin.qq.com") || (e = (t = t.replace(/[^0-9]/gi, "")).length >= 9 && t.length <= 12, 
                    t = l(t), n = 1), {
                        value: t,
                        type: n,
                        isValid: e
                    };
                }
                var d = 3, v = 7, p = 8, y = 9, g = 10, b = [ {
                    label: "不重复",
                    value: 0
                }, {
                    label: "每天",
                    value: 1
                }, {
                    label: "每个工作日（周一至周五）",
                    value: 2
                }, {
                    label: "法定工作日（跳过法定节假日）",
                    value: d
                }, {
                    label: "每周",
                    value: 4
                }, {
                    label: "每两周",
                    value: 5
                }, {
                    label: "每月",
                    value: 6
                }, {
                    label: "每月",
                    value: v
                }, {
                    label: "每年",
                    value: p
                }, {
                    label: "每年",
                    value: y
                }, {
                    label: "自定义",
                    value: g
                } ], m = {
                    3: "抱歉，不支持创建按法定工作日重复的视频会议",
                    7: "抱歉，不支持创建按农历重复的视频会议",
                    8: "抱歉，不支持创建按年重复的视频会议",
                    9: "抱歉，不支持创建按农历重复的视频会议"
                }, M = function(e) {
                    var n = arguments.length > 1 && void 0 !== arguments[1] && arguments[1], r = new Date(e), o = (0, 
                    t.solar2lunar)(r);
                    return b.forEach(function(t) {
                        var e = "";
                        6 === t.value ? (e = "每月（".concat(r.getDate(), "日）"), t.label = e) : t.value === v ? (e = "农历每月（".concat(o.lunarDayCn, "）"), 
                        t.label = e) : t.value === p ? (e = "每年（".concat(r.getMonth() + 1, "月").concat(r.getDate(), "日）"), 
                        t.label = e) : t.value === y && (e = "农历每年（".concat(o.lunarMonthCn).concat(o.lunarDayCn, "）"), 
                        t.label = e);
                    }), n ? b.filter(function(t) {
                        return ![ d, v, p, y ].includes(t.value);
                    }) : b;
                }, D = function(t) {
                    return m[t];
                }, w = function(t) {
                    var e, n, o = new Date(t), i = [ "SU", "MO", "TU", "WE", "TH", "FR", "SA" ], a = o.getDay(), u = c[a], s = o.getDate(), f = (n = (e = o).getDate() + (6 - e.getDay()), 
                    Math.ceil(n / 7));
                    return f = r()(t).startOf("month").day() > a ? f - 1 : f, {
                        week: {
                            key: "BYDAY",
                            options: [ i[a] ],
                            text: u
                        },
                        month: [ {
                            key: "BYMONTHDAY",
                            options: [ s ],
                            text: "".concat(s, "日")
                        }, {
                            key: "BYDAY",
                            options: [ "".concat(f).concat(i[a]) ],
                            text: "第".concat(f, "个").concat(u)
                        } ]
                    };
                }, $ = function(t, e, n, r) {
                    var o = "";
                    switch (t) {
                      case "day":
                        o = "FREQ=DAILY;INTERVAL=".concat(e);
                        break;

                      case "week":
                        o = "FREQ=WEEKLY;INTERVAL=".concat(e, ";").concat(n, "=").concat(r.join(","));
                        break;

                      case "month":
                        o = "FREQ=MONTHLY;INTERVAL=".concat(e, ";").concat(n, "=").concat(r.join(","));
                    }
                    return o;
                }, S = function(t, e, n) {
                    return 0 === t && e ? ";COUNT=".concat(n) : "";
                }, O = function(t, e) {
                    var n = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : 0, o = arguments.length > 3 && void 0 !== arguments[3] ? arguments[3] : 0, i = arguments.length > 4 && void 0 !== arguments[4] && arguments[4], a = arguments.length > 5 && void 0 !== arguments[5] ? arguments[5] : "", u = new Date(e), c = [ "SU", "MO", "TU", "WE", "TH", "FR", "SA" ], s = u.getDay(), f = "";
                    switch (t) {
                      case 1:
                        f = "FREQ=DAILY".concat(S(n, i, 200));
                        break;

                      case 2:
                        f = "FREQ=WEEKLY;BYDAY=MO,TU,WE,TH,FR".concat(S(n, i, 200));
                        break;

                      case d:
                        f = "FREQ=DAILY";
                        break;

                      case 4:
                        f = "FREQ=WEEKLY;BYDAY=".concat(c[s]).concat(S(n, i, 200));
                        break;

                      case 5:
                        f = "FREQ=WEEKLY;BYDAY=".concat(c[s], ";INTERVAL=2").concat(S(n, i, 50));
                        break;

                      case 6:
                        f = "FREQ=MONTHLY;BYMONTHDAY=".concat(u.getDate()).concat(S(n, i, 50));
                        break;

                      case v:
                        f = "FREQ=MONTHLY";
                        break;

                      case p:
                      case y:
                        f = "FREQ=YEARLY";
                        break;

                      case g:
                        if (0 === n && i) {
                            var l = E(i, e, a), h = l.count;
                            f = "".concat(a, ";COUNT=").concat(h);
                        } else f = a;
                        break;

                      default:
                        f = "";
                    }
                    return f && 0 !== n && o && (f += ";DTSTART=".concat(r()(e).format("YYYYMMDDTHHmmss")), 
                    1 === n && (f += ";COUNT=".concat(o)), 2 === n && (f += ";UNTIL=".concat(r()(parseFloat(o)).format("YYYYMMDD"), "T").concat(r()(e).format("HHmmss")))), 
                    f;
                }, T = function(t) {
                    switch (t) {
                      case d:
                        return "FREQ=LEGAL_WORK";

                      case v:
                        return "FREQ=LUNAR_MONTHLY";

                      case y:
                        return "FREQ=LUNAR_YEARLY";

                      default:
                        return "";
                    }
                }, x = function() {
                    var t = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : 0, e = {
                        DataBaseVersion: "r",
                        AddRRuleSolarDate: "r",
                        AddRRuleYearly: "r",
                        AddRRuleExtern: "r",
                        AddRRuleCustom: "r"
                    }, n = "", r = Object.keys(e);
                    r.forEach(function(e, r) {
                        n += "".concat(r === t ? e : "null", ",");
                    }), n = "".concat(n.slice(0, n.length - 1), ";");
                    var o = Object.values(e);
                    return o.forEach(function(e, r) {
                        n += "".concat(r === t ? e : "-", ",");
                    }), n = n.substring(0, n.length - 1);
                }, Y = function(t) {
                    var e = 0;
                    switch (t) {
                      case 0:
                        e = 0;
                        break;

                      case 1:
                      case 2:
                      case 4:
                      case 5:
                      case 6:
                        e = 1;
                        break;

                      case p:
                        e = 2;
                        break;

                      case d:
                      case v:
                      case y:
                        e = 3;
                        break;

                      case g:
                        e = 4;
                    }
                    return x(e);
                }, _ = function(t, e, n) {
                    return r()(t).add(e, n);
                }, A = function(t, e) {
                    return {
                        count: t,
                        timestamp: e.valueOf(),
                        year: e.year(),
                        month: e.month() + 1,
                        day: e.date(),
                        week: c[e.format("d")]
                    };
                }, E = function() {
                    var t = arguments.length > 0 && void 0 !== arguments[0] && arguments[0], e = arguments.length > 1 ? arguments[1] : void 0, n = arguments.length > 2 ? arguments[2] : void 0;
                    if (!t) {
                        var r = _(e, 10, "year");
                        return {
                            count: 3650,
                            dateEnd: r
                        };
                    }
                    if (n.includes("DAILY")) {
                        var o = _(e, 5, "year");
                        return {
                            count: 200,
                            dateEnd: o
                        };
                    }
                    var i = n.split(";"), a = parseInt(i.find(function(t) {
                        return t.includes("INTERVAL");
                    }).split("=")[1]), u = i.find(function(t) {
                        return t.includes("BYMONTHDAY") || t.includes("BYDAY");
                    }), c = u && u.split("=")[1].split(",").length || 1, s = a > 1 ? 49 : 199;
                    return {
                        count: s + 1,
                        dateEnd: n.includes("MONTHLY") ? _(e, Math.floor(a * s / c), "month") : _(e, Math.floor(7 * a * s / c), "days")
                    };
                }, k = function(t, e) {
                    var n = arguments.length > 2 && void 0 !== arguments[2] && arguments[2], r = arguments.length > 3 && void 0 !== arguments[3] ? arguments[3] : "";
                    if (!n) {
                        var o = _(e, 5, "year");
                        return A(200, o);
                    }
                    switch (t) {
                      case 1:
                        var i = _(e, 199, "days");
                        return A(200, i);

                      case 2:
                        var a = _(e, 199 + 2 * Math.ceil(40), "days"), u = parseInt(a.format("d"));
                        return 0 === u && (a = a.subtract(2, "days")), 6 === u && (a = a.subtract(1, "days")), 
                        A(200, a);

                      case 4:
                        var c = _(e, 1393, "days");
                        return A(200, c);

                      case 5:
                        var s = _(e, 686, "days");
                        return A(50, s);

                      case 6:
                        var f = _(e, 49, "month");
                        return A(50, f);

                      case g:
                        var l = E(n, e, r), h = l.count, d = l.dateEnd;
                        return A(h, d);
                    }
                }, R = function() {
                    var t = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : "", e = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : "";
                    console.log("[".concat(e, "]").concat(t)), "undefined" != typeof window && window.nextAegis && "function" == typeof window.nextAegis.infoAll && window.nextAegis.infoAll("[".concat(e, "]").concat(t));
                };
            }(), o;
        }();
    });
}, function(t) {
    return n({}[t], t);
}), e(1699270751489, function(t, e, n) {
    !function(t, o) {
        if ("object" == r(n) && "object" == r(e)) e.exports = o(); else if ("function" == typeof define && define.amd) define([], o); else {
            var i = o();
            for (var a in i) ("object" == r(n) ? n : t)[a] = i[a];
        }
    }(this, function() {
        return function() {
            var t = {
                d: function(e, n) {
                    for (var r in n) t.o(n, r) && !t.o(e, r) && Object.defineProperty(e, r, {
                        enumerable: !0,
                        get: n[r]
                    });
                },
                o: function(t, e) {
                    return Object.prototype.hasOwnProperty.call(t, e);
                },
                r: function(t) {
                    "undefined" != typeof Symbol && Symbol.toStringTag && Object.defineProperty(t, Symbol.toStringTag, {
                        value: "Module"
                    }), Object.defineProperty(t, "__esModule", {
                        value: !0
                    });
                }
            }, e = {};
            t.r(e), t.d(e, {
                minuteList: function() {
                    return n;
                },
                timeStep: function() {
                    return r;
                }
            });
            var n = function() {
                for (var t = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : 15, e = 0, n = e * t, r = []; n < 60; ) r.push(n), 
                n = ++e * t;
                return r;
            }, r = [ {
                label: "1分钟",
                value: "1"
            }, {
                label: "5分钟",
                value: "5"
            }, {
                label: "10分钟",
                value: "10"
            }, {
                label: "15分钟",
                value: "15"
            }, {
                label: "30分钟",
                value: "30"
            }, {
                label: "1小时",
                value: "60"
            } ];
            return e;
        }();
    });
}, function(t) {
    return n({}[t], t);
}), e(1699270751490, function(t, e, n) {
    !function(t, o) {
        if ("object" == r(n) && "object" == r(e)) e.exports = o(); else if ("function" == typeof define && define.amd) define([], o); else {
            var i = o();
            for (var a in i) ("object" == r(n) ? n : t)[a] = i[a];
        }
    }(this, function() {
        return t = {
            311: function(t, e, n) {
                var r = n(885), o = [ 19416, 19168, 42352, 21717, 53856, 55632, 91476, 22176, 39632, 21970, 19168, 42422, 42192, 53840, 119381, 46400, 54944, 44450, 38320, 84343, 18800, 42160, 46261, 27216, 27968, 109396, 11104, 38256, 21234, 18800, 25958, 54432, 59984, 28309, 23248, 11104, 100067, 37600, 116951, 51536, 54432, 120998, 46416, 22176, 107956, 9680, 37584, 53938, 43344, 46423, 27808, 46416, 86869, 19872, 42416, 83315, 21168, 43432, 59728, 27296, 44710, 43856, 19296, 43748, 42352, 21088, 62051, 55632, 23383, 22176, 38608, 19925, 19152, 42192, 54484, 53840, 54616, 46400, 46752, 103846, 38320, 18864, 43380, 42160, 45690, 27216, 27968, 44870, 43872, 38256, 19189, 18800, 25776, 29859, 59984, 27480, 21952, 43872, 38613, 37600, 51552, 55636, 54432, 55888, 30034, 22176, 43959, 9680, 37584, 51893, 43344, 46240, 47780, 44368, 21977, 19360, 42416, 86390, 21168, 43312, 31060, 27296, 44368, 23378, 19296, 42726, 42208, 53856, 60005, 54576, 23200, 30371, 38608, 19195, 19152, 42192, 118966, 53840, 54560, 56645, 46496, 22224, 21938, 18864, 42359, 42160, 43600, 111189, 27936, 44448, 84835, 37744, 18936, 18800, 25776, 92326, 59984, 27424, 108228, 43744, 41696, 53987, 51552, 54615, 54432, 55888, 23893, 22176, 42704, 21972, 21200, 43448, 43344, 46240, 46758, 44368, 21920, 43940, 42416, 21168, 45683, 26928, 29495, 27296, 44368, 84821, 19296, 42352, 21732, 53600, 59752, 54560, 55968, 92838, 22224, 19168, 43476, 41680, 53584, 62034, 54560 ], i = [ "日", "一", "二", "三", "四", "五", "六", "七", "八", "九", "十" ], a = [ "初", "十", "廿", "卅" ], u = [ "正", "二", "三", "四", "五", "六", "七", "八", "九", "十", "冬", "腊" ];
                function c(t) {
                    var e, n = 348;
                    for (e = 32768; e > 8; e >>= 1) n += o[t - 1900] & e ? 1 : 0;
                    return n + f(t);
                }
                function s(t) {
                    return 15 & o[t - 1900];
                }
                function f(t) {
                    return s(t) ? 65536 & o[t - 1900] ? 30 : 29 : 0;
                }
                function l(t) {
                    return t > 12 || t < 1 ? -1 : u[t - 1] + "月";
                }
                function h(t) {
                    var e;
                    switch (t) {
                      case 10:
                        e = "初十";
                        break;

                      case 20:
                        e = "二十";
                        break;

                      case 30:
                        e = "三十";
                        break;

                      default:
                        e = a[Math.floor(t / 10)], e += i[t % 10];
                    }
                    return e;
                }
                t.exports = {
                    solar2lunar: function(t) {
                        var e, n = t.getFullYear(), i = t.getMonth() + 1, a = t.getDate();
                        if (n < 1900 || n > 2100) return -1;
                        if (1900 === n && 1 === n && a < 31) return -1;
                        var u = 0, d = (Date.UTC(t.getFullYear(), t.getMonth(), t.getDate()) - Date.UTC(1900, 0, 31)) / 864e5;
                        for (e = 1900; e < 2101 && d > 0; e++) d -= u = c(e);
                        d < 0 && (d += u, e -= 1);
                        var v, p = e, y = s(e), g = !1;
                        for (e = 1; e < 13 && d > 0; e++) y > 0 && e === y + 1 && !1 === g ? (--e, g = !0, 
                        u = f(p)) : u = (v = e) > 12 || v < 1 ? -1 : o[p - 1900] & 65536 >> v ? 30 : 29, 
                        !0 === g && e === y + 1 && (g = !1), d -= u;
                        0 === d && y > 0 && e === y + 1 && (g ? g = !1 : (g = !0, --e)), d < 0 && (d += u, 
                        --e);
                        var b = e, m = d + 1, M = r(n, i, a);
                        return {
                            lunarYear: p,
                            lunarMonth: b,
                            lunarDay: m,
                            lunarMonthCn: (g ? "闰" : "") + l(b),
                            lunarDayCn: h(m),
                            lunarTerm: M
                        };
                    }
                };
            },
            885: function(t) {
                var e, n = [], r = [ "小寒", "大寒", "立春", "雨水", "惊蛰", "春分", "清明", "谷雨", "立夏", "小满", "芒种", "夏至", "小暑", "大暑", "立秋", "处暑", "白露", "秋分", "寒露", "霜降", "立冬", "小雪", "大雪", "冬至" ], o = {
                    1914: "立春",
                    1915: "惊蛰",
                    1923: "雨水",
                    1947: "立春",
                    1948: "惊蛰",
                    2000: "惊蛰春分清明立夏芒种夏至大暑立秋白露寒露霜降立冬小雪冬至小寒立春雨水",
                    2019: "小寒",
                    2021: "冬至",
                    2026: "雨水"
                }, i = {
                    1902: "芒种",
                    1911: "立夏",
                    1914: "冬至",
                    1922: "大暑",
                    1925: "小暑",
                    1927: "白露",
                    1928: "夏至",
                    1942: "秋分",
                    1947: "冬至",
                    1951: "冬至",
                    1978: "小雪",
                    1980: "冬至",
                    1982: "小寒",
                    1984: "冬至",
                    2002: "立秋",
                    2008: "小满",
                    2016: "小暑",
                    2082: "大寒",
                    2089: "霜降立冬"
                }, a = [ [ 6.11, 20.84, 4.6295, 19.4599, 6.3826, 21.4155, 5.59, 20.888, 6.318, 21.86, 6.5, 22.2, 7.928, 23.65, 8.35, 23.95, 8.44, 23.822, 9.098, 24.218, 8.218, 23.08, 7.9, 22.6 ], [ 5.4055, 20.12, 3.87, 18.73, 5.63, 20.646, 4.81, 20.1, 5.52, 21.04, 5.678, 21.37, 7.108, 22.83, 7.5, 23.13, 7.646, 23.042, 8.318, 23.438, 7.438, 22.36, 7.18, 21.94 ] ], u = function(t, e) {
                    var n = -1;
                    if (t > 1900 && t <= 2e3 ? n = 0 : t > 2e3 && t < 2100 && (n = 1), n < 0) return -1;
                    var o = a[n][e], i = t % 100, u = i, s = r[e];
                    return (t % 4 == 0 && t % 100 != 0 || t % 400 == 0) && e <= 3 && (u -= 1), Math.ceil(Math.floor(.2422 * i + o, 10) - u / 4) + c(t, s);
                }, c = function(t, e) {
                    var n = 0;
                    return (n += s(o, t, e, -1)) + s(i, t, e, 1);
                }, s = function(t, e, n, r) {
                    return t[e] && t[e].indexOf(n) > -1 ? r : 0;
                };
                t.exports = function(t, o, i) {
                    if (t < 1901 || t > 2099) return null;
                    var a = "".concat(o > 9 ? o : "0".concat(o)).concat(i > 9 ? i : "0".concat(i));
                    t !== e && function(t) {
                        e = t, n = [];
                        for (var r = 0, o = 1; o < 13; ) {
                            var i = "".concat(o > 9 ? o : "0".concat(o)), a = u(t, r), c = u(t, r += 1), s = "".concat(i).concat(a > 9 ? a : "0".concat(a)), f = "".concat(i).concat(c > 9 ? c : "0".concat(c));
                            n.push(s), n.push(f), r += 1, o += 1;
                        }
                    }(t);
                    var c = n.indexOf(a);
                    return c > -1 ? r[c] : null;
                };
            }
        }, e = {}, function n(r) {
            var o = e[r];
            if (void 0 !== o) return o.exports;
            var i = e[r] = {
                exports: {}
            };
            return t[r](i, i.exports, n), i.exports;
        }(311);
        var t, e;
    });
}, function(t) {
    return n({}[t], t);
}), e(1699270751491, function(t, e, n) {
    !function(t, o) {
        if ("object" == r(n) && "object" == r(e)) e.exports = o(); else if ("function" == typeof define && define.amd) define([], o); else {
            var i = o();
            for (var a in i) ("object" == r(n) ? n : t)[a] = i[a];
        }
    }(this, function() {
        return function() {
            var t = {
                d: function(e, n) {
                    for (var r in n) t.o(n, r) && !t.o(e, r) && Object.defineProperty(e, r, {
                        enumerable: !0,
                        get: n[r]
                    });
                },
                o: function(t, e) {
                    return Object.prototype.hasOwnProperty.call(t, e);
                },
                r: function(t) {
                    "undefined" != typeof Symbol && Symbol.toStringTag && Object.defineProperty(t, Symbol.toStringTag, {
                        value: "Module"
                    }), Object.defineProperty(t, "__esModule", {
                        value: !0
                    });
                }
            }, e = {};
            function n(t) {
                return (n = "function" == typeof Symbol && "symbol" == r(Symbol.iterator) ? function(t) {
                    return r(t);
                } : function(t) {
                    return t && "function" == typeof Symbol && t.constructor === Symbol && t !== Symbol.prototype ? "symbol" : r(t);
                })(t);
            }
            t.r(e), t.d(e, {
                Permission: function() {
                    return o;
                }
            });
            var o = function() {
                function t(e) {
                    var r, o, i;
                    (function(t, e) {
                        if (!(t instanceof e)) throw new TypeError("Cannot call a class as a function");
                    })(this, t), r = this, o = new Array(5).fill(0), "seq" in r ? Object.defineProperty(r, "seq", {
                        value: o,
                        enumerable: !0,
                        configurable: !0,
                        writable: !0
                    }) : r.seq = o, "number" == typeof e ? (this.seq = e.toString(2).split("").map(Number), 
                    this.seq = (i = this.seq, new Array(Math.max(5 - i.length, 0)).fill(0).concat(i))) : "object" === n(e) ? (this.edit = !!e.edit, 
                    this.share = !!e.share, this.schedule = !!e.schedule, this.view = !!e.view) : console.error("Permission unknown arg", e);
                }
                var e, r;
                return e = t, (r = [ {
                    key: "val",
                    get: function() {
                        return parseInt(this.seq.join(""), 2);
                    }
                }, {
                    key: "edit",
                    get: function() {
                        return 1 === this.seq[1];
                    },
                    set: function(t) {
                        this.seq[1] = Number(t);
                    }
                }, {
                    key: "share",
                    get: function() {
                        return 1 === this.seq[2];
                    },
                    set: function(t) {
                        this.seq[2] = Number(t);
                    }
                }, {
                    key: "view",
                    get: function() {
                        return 1 === this.seq[3];
                    },
                    set: function(t) {
                        this.seq[3] = Number(t);
                    }
                }, {
                    key: "schedule",
                    get: function() {
                        return 1 === this.seq[4];
                    },
                    set: function(t) {
                        this.seq[4] = Number(t);
                    }
                }, {
                    key: "getRole",
                    value: function() {
                        return {
                            31: {
                                name: "管理员",
                                desc: "日历所有者"
                            },
                            15: {
                                name: "编辑者",
                                desc: "可创建、修改日程"
                            },
                            7: {
                                name: "查看者",
                                desc: "可查看、分享日程"
                            }
                        }[this.val];
                    }
                } ]) && function(t, e) {
                    for (var n = 0; n < e.length; n++) {
                        var r = e[n];
                        r.enumerable = r.enumerable || !1, r.configurable = !0, "value" in r && (r.writable = !0), 
                        Object.defineProperty(t, r.key, r);
                    }
                }(e.prototype, r), Object.defineProperty(e, "prototype", {
                    writable: !1
                }), t;
            }();
            return e;
        }();
    });
}, function(t) {
    return n({}[t], t);
}), n(1699270751487));