module.exports = require("../_commons/0.js")([ {
    ids: [ 2 ],
    modules: {
        11: function(e, t, o) {
            e.exports = o(118);
        },
        118: function(e, t) {
            Component({
                options: {
                    addGlobalClass: !0
                },
                properties: {
                    extClass: {
                        type: String,
                        value: ""
                    },
                    content: {
                        type: String,
                        value: ""
                    },
                    ariaLabel: {
                        type: String,
                        value: ""
                    }
                }
            });
        }
    },
    entries: [ [ 11, 0 ] ]
} ]);