$gwx_XC_17=function(_,_v,_n,_p,_s,_wp,_wl,$gwn,$gwl,$gwh,wh,$gstack,$gwrt,gra,grb,TestTest,wfor,_ca,_da,_r,_rz,_o,_oz,_1,_1z,_2,_2z,_m,_mz,nv_getDate,nv_getRegExp,nv_console,nv_parseInt,nv_parseFloat,nv_isNaN,nv_isFinite,nv_decodeURI,nv_decodeURIComponent,nv_encodeURI,nv_encodeURIComponent,$gdc,nv_JSON,_af,_gv,_ai,_grp,_gd,_gapi,$ixc,_ic,_w,_ev,_tsd){return function(path,global){
if(typeof global==='undefined'){if (typeof __GWX_GLOBAL__==='undefined')global={};else global=__GWX_GLOBAL__;}var __WXML_GLOBAL__={};{
}__WXML_GLOBAL__.modules = __WXML_GLOBAL__.modules || {};
var e_={}
if(typeof(global.entrys)==='undefined')global.entrys={};e_=global.entrys;
var d_={}
if(typeof(global.defines)==='undefined')global.defines={};d_=global.defines;
var f_={}
if(typeof(global.modules)==='undefined')global.modules={};f_=global.modules || {};
var p_={}
__WXML_GLOBAL__.ops_cached = __WXML_GLOBAL__.ops_cached || {}
__WXML_GLOBAL__.ops_set = __WXML_GLOBAL__.ops_set || {};
__WXML_GLOBAL__.ops_init = __WXML_GLOBAL__.ops_init || {};
var z=__WXML_GLOBAL__.ops_set.$gwx_XC_17 || [];
function gz$gwx_XC_17_1(){
if( __WXML_GLOBAL__.ops_cached.$gwx_XC_17_1)return __WXML_GLOBAL__.ops_cached.$gwx_XC_17_1
__WXML_GLOBAL__.ops_cached.$gwx_XC_17_1=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
Z([a,[3,'weui-search-bar '],[[2,'?:'],[[7],[3,'searchState']],[1,'weui-search-bar_focusing'],[1,'']],[3,' '],[[7],[3,'extClass']]])
Z([[7],[3,'searchState']])
Z([3,'searchResult'])
Z([3,'combobox'])
Z([3,'weui-search-bar__form'])
Z([3,'weui-search-bar__box'])
Z([3,'weui-icon-search'])
Z([3,'12'])
Z([3,'search'])
Z([[2,'>'],[[6],[[7],[3,'value']],[3,'length']],[1,0]])
Z([3,'showInput'])
Z([3,'weui-search-bar__label'])
Z([3,'searchText'])
Z(z[6])
Z(z[7])
Z(z[8])
Z([[2,'&&'],[[7],[3,'cancel']],[[7],[3,'searchState']]])
Z([[2,'&&'],[[7],[3,'searchState']],[[2,'>'],[[6],[[7],[3,'result']],[3,'length']],[1,0]]])
Z([3,'listbox'])
Z([a,z[0][3],[[2,'+'],[1,'searchbar-result '],[[7],[3,'extClass']]]])
Z(z[2])
Z([[7],[3,'result']])
Z([3,'index'])
Z([3,'option'])
Z([3,'selectResult'])
Z([3,'weui-cell_primary'])
Z([3,'result'])
Z([[7],[3,'index']])
})(__WXML_GLOBAL__.ops_cached.$gwx_XC_17_1);return __WXML_GLOBAL__.ops_cached.$gwx_XC_17_1
}
__WXML_GLOBAL__.ops_set.$gwx_XC_17=z;
__WXML_GLOBAL__.ops_init.$gwx_XC_17=true;
var x=['./miniprogram_npm/weui-miniprogram/searchbar/searchbar.wxml'];d_[x[0]]={}
var m0=function(e,s,r,gg){
var z=gz$gwx_XC_17_1()
var oVD=_n('view')
_rz(z,oVD,'class',0,e,s,gg)
var cXD=_mz(z,'view',['ariaHaspopup',-1,'ariaExpanded',1,'ariaOwns',1,'ariaRole',2,'class',3],[],e,s,gg)
var hYD=_n('view')
_rz(z,hYD,'class',5,e,s,gg)
var c1D=_mz(z,'icon',['class',6,'size',1,'type',2],[],e,s,gg)
_(hYD,c1D)
var oZD=_v()
_(hYD,oZD)
if(_oz(z,9,e,s,gg)){oZD.wxVkey=1
}
oZD.wxXCkey=1
_(cXD,hYD)
var o2D=_mz(z,'label',['bindtap',10,'class',1,'id',2],[],e,s,gg)
var l3D=_mz(z,'icon',['class',13,'size',1,'type',2],[],e,s,gg)
_(o2D,l3D)
_(cXD,o2D)
_(oVD,cXD)
var fWD=_v()
_(oVD,fWD)
if(_oz(z,16,e,s,gg)){fWD.wxVkey=1
}
fWD.wxXCkey=1
_(r,oVD)
var xUD=_v()
_(r,xUD)
if(_oz(z,17,e,s,gg)){xUD.wxVkey=1
var a4D=_mz(z,'mp-cells',['ariaRole',18,'extClass',1,'id',2],[],e,s,gg)
var t5D=_v()
_(a4D,t5D)
var e6D=function(o8D,b7D,x9D,gg){
var fAE=_mz(z,'mp-cell',['hover',-1,'ariaRole',23,'bindtap',1,'bodyClass',2,'class',3,'data-index',4],[],o8D,b7D,gg)
_(x9D,fAE)
return x9D
}
t5D.wxXCkey=4
_2z(z,21,e6D,e,s,gg,t5D,'item','index','index')
_(xUD,a4D)
}
xUD.wxXCkey=1
xUD.wxXCkey=3
return r
}
e_[x[0]]=e_[x[0]]||{f:m0,j:[],i:[],ti:[],ic:[]}
if(path&&e_[path]){
return function(env,dd,global){$gwxc=0;var root={"tag":"wx-page"};root.children=[]
;g="$gwx_XC_17";var main=e_[path].f
if (typeof global==="undefined")global={};global.f=$gdc(f_[path],"",1);
try{
main(env,{},root,global);
_tsd(root)
}catch(err){
console.log(err)
}
;g="";
return root;
}
}
}
}(__g.a,__g.b,__g.c,__g.d,__g.e,__g.f,__g.g,__g.h,__g.i,__g.j,__g.k,__g.l,__g.m,__g.n,__g.o,__g.p,__g.q,__g.r,__g.s,__g.t,__g.u,__g.v,__g.w,__g.x,__g.y,__g.z,__g.A,__g.B,__g.C,__g.D,__g.E,__g.F,__g.G,__g.H,__g.I,__g.J,__g.K,__g.L,__g.M,__g.N,__g.O,__g.P,__g.Q,__g.R,__g.S,__g.T,__g.U,__g.V,__g.W,__g.X,__g.Y,__g.Z,__g.aa);if(__vd_version_info__.delayedGwx||false)$gwx_XC_17();	if (__vd_version_info__.delayedGwx) __wxAppCode__['miniprogram_npm/weui-miniprogram/searchbar/searchbar.wxml'] = [$gwx_XC_17, './miniprogram_npm/weui-miniprogram/searchbar/searchbar.wxml'];else __wxAppCode__['miniprogram_npm/weui-miniprogram/searchbar/searchbar.wxml'] = $gwx_XC_17( './miniprogram_npm/weui-miniprogram/searchbar/searchbar.wxml' );
	;__wxRoute = "miniprogram_npm/weui-miniprogram/searchbar/searchbar";__wxRouteBegin = true;__wxAppCurrentFile__="miniprogram_npm/weui-miniprogram/searchbar/searchbar.js";define("miniprogram_npm/weui-miniprogram/searchbar/searchbar.js",function(require,module,exports,window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){
"use strict";module.exports=require("../_commons/0.js")([{ids:[18],modules:{198:function(t,e){Component({options:{addGlobalClass:!0,writeIdToDOM:!0},properties:{extClass:{type:String,value:""},focus:{type:Boolean,value:!1},placeholder:{type:String,value:"搜索"},value:{type:String,value:"",observer:"valueChange"},search:{type:null,value:null},throttle:{type:Number,value:500},cancelText:{type:String,value:"取消"},cancel:{type:Boolean,value:!0}},data:{result:[]},lastSearch:Date.now(),lifetimes:{attached:function(){this.data.focus&&this.setData({searchState:!0})}},methods:{valueChange:function(){this.data.value&&this.setData({searchState:!0})},clearInput:function(){this.setData({value:"",focus:!1,result:[]}),this.triggerEvent("clear")},inputFocus:function(t){this.triggerEvent("focus",t.detail)},inputBlur:function(t){this.setData({focus:!1}),this.triggerEvent("blur",t.detail)},showInput:function(){this.setData({focus:!0,searchState:!0})},hideInput:function(){this.setData({searchState:!1}),this.triggerEvent("cancel")},inputChange:function(t){var e=this;this.setData({value:t.detail.value}),this.triggerEvent("input",t.detail),Date.now()-this.lastSearch<this.data.throttle||"function"==typeof this.data.search&&(this.lastSearch=Date.now(),this.timerId=setTimeout(function(){e.data.search(e.data.value).then(function(t){e.setData({result:t})}).catch(function(t){console.error("search error",t)})},this.data.throttle))},selectResult:function(t){var e=t.currentTarget.dataset.index,a=this.data.result[e];this.triggerEvent("selectresult",{index:e,item:a})}}})},21:function(t,e,a){t.exports=a(198)}},entries:[[21,0]]}]);
},{isPage:false,isComponent:true,currentFile:'miniprogram_npm/weui-miniprogram/searchbar/searchbar.js'});require("miniprogram_npm/weui-miniprogram/searchbar/searchbar.js");