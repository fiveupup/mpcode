var e = require("../../@babel/runtime/helpers/objectSpread2"), t = require("../../@babel/runtime/helpers/createForOfIteratorHelper"), n = require("../../@babel/runtime/helpers/typeof");

module.exports = function(e) {
    var t = {};
    function r(n) {
        if (t[n]) return t[n].exports;
        var o = t[n] = {
            i: n,
            l: !1,
            exports: {}
        };
        return e[n].call(o.exports, o, o.exports, r), o.l = !0, o.exports;
    }
    return r.m = e, r.c = t, r.d = function(e, t, n) {
        r.o(e, t) || Object.defineProperty(e, t, {
            enumerable: !0,
            get: n
        });
    }, r.r = function(e) {
        "undefined" != typeof Symbol && Symbol.toStringTag && Object.defineProperty(e, Symbol.toStringTag, {
            value: "Module"
        }), Object.defineProperty(e, "__esModule", {
            value: !0
        });
    }, r.t = function(e, t) {
        if (1 & t && (e = r(e)), 8 & t) return e;
        if (4 & t && "object" == n(e) && e && e.__esModule) return e;
        var o = Object.create(null);
        if (r.r(o), Object.defineProperty(o, "default", {
            enumerable: !0,
            value: e
        }), 2 & t && "string" != typeof e) for (var a in e) r.d(o, a, function(t) {
            return e[t];
        }.bind(null, a));
        return o;
    }, r.n = function(e) {
        var t = e && e.__esModule ? function() {
            return e.default;
        } : function() {
            return e;
        };
        return r.d(t, "a", t), t;
    }, r.o = function(e, t) {
        return Object.prototype.hasOwnProperty.call(e, t);
    }, r.p = "", r(r.s = 2);
}([ function(e, t) {
    e.exports = require("miniprogram-render");
}, function(e, n, r) {
    var o = r(0).$$adapter, a = o.cache, i = o.tool;
    function u(e) {
        e.detail || (e.detail = {}), void 0 !== e.markerId && (e.detail.markerId = e.markerId), 
        void 0 !== e.controlId && (e.detail.controlId = e.controlId), void 0 !== e.name && (e.detail.name = e.name), 
        void 0 !== e.longitude && (e.detail.longitude = e.longitude), void 0 !== e.latitude && (e.detail.latitude = e.latitude);
    }
    function c(e) {
        if ("string" == typeof e) try {
            e = JSON.parse(e);
        } catch (t) {
            e = void 0;
        }
        return e;
    }
    function l(e, t, n) {
        var r = e.getAttribute(t);
        return !("false" === r || (!n || void 0 !== r) && !r);
    }
    function s(e, t, n) {
        var r = parseFloat(e.getAttribute(t));
        return isNaN(r) ? n : r;
    }
    function d(e) {
        e.currentTarget && e.currentTarget.dataset.privateNodeId || (e.currentTarget = e.currentTarget || {
            dataset: {}
        }, e.currentTarget.dataset.privateNodeId = e.target.dataset.privateNodeId);
    }
    var g = {
        "cover-image": {
            wxCompName: "cover-image",
            properties: [ {
                name: "src",
                get: function(e) {
                    var t = a.getWindow(e.$$pageId);
                    return e.src ? i.completeURL(e.src, t.location.origin, !0) : "";
                }
            } ],
            handles: {
                onCoverImageLoad: function(e) {
                    this.callSingleEvent("load", e);
                },
                onCoverImageError: function(e) {
                    this.callSingleEvent("error", e);
                }
            }
        },
        "cover-view": {
            wxCompName: "cover-view",
            properties: [ {
                name: "scrollTop",
                get: function(e) {
                    return e.getAttribute("scroll-top");
                }
            }, {
                name: "forceInCover",
                get: function(e) {
                    return void 0 !== e.getAttribute("marker-id");
                }
            }, {
                name: "markerId",
                get: function(e) {
                    return e.getAttribute("marker-id");
                }
            } ]
        },
        "match-media": {
            wxCompName: "match-media",
            properties: [ {
                name: "minWidth",
                get: function(e) {
                    return +e.getAttribute("min-width") || 0;
                }
            }, {
                name: "maxWidth",
                get: function(e) {
                    return +e.getAttribute("max-width") || 0;
                }
            }, {
                name: "width",
                get: function(e) {
                    return +e.getAttribute("width") || 0;
                }
            }, {
                name: "minHeight",
                get: function(e) {
                    return +e.getAttribute("min-height") || 0;
                }
            }, {
                name: "maxHeight",
                get: function(e) {
                    return +e.getAttribute("max-height") || 0;
                }
            }, {
                name: "height",
                get: function(e) {
                    return +e.getAttribute("height") || 0;
                }
            }, {
                name: "orientation",
                get: function(e) {
                    return e.getAttribute("orientation") || "";
                }
            } ]
        },
        "movable-area": {
            wxCompName: "movable-area",
            properties: [ {
                name: "scaleArea",
                get: function(e) {
                    return l(e, "scale-area");
                }
            } ]
        },
        "page-container": {
            wxCompName: "page-container",
            properties: [ {
                name: "show",
                get: function(e) {
                    return l(e, "show");
                }
            }, {
                name: "duration",
                get: function(e) {
                    return s(e, "duration", 300);
                }
            }, {
                name: "zIndex",
                get: function(e) {
                    return s(e, "z-index", 100);
                }
            }, {
                name: "overlay",
                get: function(e) {
                    return l(e, "overlay", !0);
                }
            }, {
                name: "position",
                get: function(e) {
                    return e.getAttribute("position") || "bottom";
                }
            }, {
                name: "round",
                get: function(e) {
                    return l(e, "round");
                }
            }, {
                name: "closeOnSlideDown",
                get: function(e) {
                    return l(e, "close-on-slideDown");
                }
            }, {
                name: "overlayStyle",
                get: function(e) {
                    return e.getAttribute("overlay-style") || "";
                }
            }, {
                name: "customStyle",
                get: function(e) {
                    return e.getAttribute("custom-style") || "";
                }
            } ],
            handles: {
                onPageContainerBeforeenter: function(e) {
                    this.callSingleEvent("beforeenter", e);
                    var t = this.getDomNodeFromEvt(e);
                    t && t.$$setAttributeWithoutUpdate("show", !0);
                },
                onPageContainerEnter: function(e) {
                    this.callSingleEvent("enter", e);
                },
                onPageContainerAfterenter: function(e) {
                    this.callSingleEvent("afterenter", e);
                },
                onPageContainerBeforeleave: function(e) {
                    this.callSingleEvent("beforeleave", e);
                    var t = this.getDomNodeFromEvt(e);
                    t && t.$$setAttributeWithoutUpdate("show", !1);
                },
                onPageContainerLeave: function(e) {
                    this.callSingleEvent("leave", e);
                },
                onPageContainerAfterleave: function(e) {
                    this.callSingleEvent("afterleave", e);
                },
                onPageContainerClickoverlay: function(e) {
                    this.callSingleEvent("clickoverlay", e);
                }
            }
        },
        "scroll-view": {
            wxCompName: "scroll-view",
            properties: [ {
                name: "scrollX",
                get: function(e) {
                    return l(e, "scroll-x");
                }
            }, {
                name: "scrollY",
                get: function(e) {
                    return l(e, "scroll-y");
                }
            }, {
                name: "upperThreshold",
                get: function(e) {
                    return e.getAttribute("upper-threshold") || "50";
                }
            }, {
                name: "lowerThreshold",
                get: function(e) {
                    return e.getAttribute("lower-threshold") || "50";
                }
            }, {
                name: "scrollTop",
                canBeUserChanged: !0,
                get: function(e) {
                    return e.getAttribute("scroll-top") || "";
                }
            }, {
                name: "scrollLeft",
                canBeUserChanged: !0,
                get: function(e) {
                    return e.getAttribute("scroll-left") || "";
                }
            }, {
                name: "scrollWithAnimation",
                get: function(e) {
                    return l(e, "scroll-with-animation");
                }
            }, {
                name: "enableBackToTop",
                get: function(e) {
                    return l(e, "enable-back-to-top");
                }
            }, {
                name: "enableFlex",
                get: function(e) {
                    return l(e, "enable-flex");
                }
            }, {
                name: "scrollAnchoring",
                get: function(e) {
                    return l(e, "scroll-anchoring");
                }
            }, {
                name: "refresherEnabled",
                get: function(e) {
                    return l(e, "refresher-enabled");
                }
            }, {
                name: "refresherThreshold",
                get: function(e) {
                    return e.getAttribute("refresher-threshold") || "45";
                }
            }, {
                name: "refresherDefaultStyle",
                get: function(e) {
                    return e.getAttribute("refresher-default-style") || "black";
                }
            }, {
                name: "refresherBackground",
                get: function(e) {
                    return e.getAttribute("refresher-background") || "#FFF";
                }
            }, {
                name: "refresherTriggered",
                get: function(e) {
                    var t = l(e, "refresher-triggered");
                    return !l(e, "refresher-enabled") && t ? (e.$$setAttributeWithoutUpdate("refresher-triggered", !1), 
                    !1) : t;
                }
            } ],
            handles: {
                onScrollViewScrolltoupper: function(e) {
                    this.callSingleEvent("scrolltoupper", e);
                },
                onScrollViewScrolltolower: function(e) {
                    this.callSingleEvent("scrolltolower", e);
                },
                onScrollViewScroll: function(e) {
                    var t = this.getDomNodeFromEvt(e);
                    t && (t.$$setAttributeWithoutUpdate("scroll-into-view", ""), t.$$setAttributeWithoutUpdate("scroll-top", e.detail.scrollTop), 
                    t.$$setAttributeWithoutUpdate("scroll-left", e.detail.scrollLeft), t._oldValues = t._oldValues || {}, 
                    t._oldValues.scrollIntoView = "", t._oldValues.scrollTop = e.detail.scrollTop || "", 
                    t._oldValues.scrollLeft = e.detail.scrollLeft || "", this.callSimpleEvent("scroll", e));
                },
                onScrollViewRefresherPulling: function(e) {
                    this.callSingleEvent("refresherpulling", e);
                },
                onScrollViewRefresherRefresh: function(e) {
                    var t = this.getDomNodeFromEvt(e);
                    t && t.setAttribute("refresher-triggered", !0), this.callSingleEvent("refresherrefresh", e);
                },
                onScrollViewRefresherRestore: function(e) {
                    var t = this.getDomNodeFromEvt(e);
                    t && t.setAttribute("refresher-triggered", !1), this.callSingleEvent("refresherrestore", e);
                },
                onScrollViewRefresherAbort: function(e) {
                    var t = this.getDomNodeFromEvt(e);
                    t && t.setAttribute("refresher-triggered", !1), this.callSingleEvent("refresherabort", e);
                }
            }
        },
        swiper: {
            wxCompName: "swiper",
            properties: [ {
                name: "indicatorDots",
                get: function(e) {
                    return l(e, "indicator-dots");
                }
            }, {
                name: "indicatorColor",
                get: function(e) {
                    return e.getAttribute("indicator-color") || "rgba(0, 0, 0, .3)";
                }
            }, {
                name: "indicatorActiveColor",
                get: function(e) {
                    return e.getAttribute("indicator-active-color") || "#000000";
                }
            }, {
                name: "autoplay",
                get: function(e) {
                    return l(e, "autoplay");
                }
            }, {
                name: "current",
                canBeUserChanged: !0,
                get: function(e) {
                    return +e.getAttribute("current") || 0;
                }
            }, {
                name: "interval",
                get: function(e) {
                    return s(e, "interval", 5e3);
                }
            }, {
                name: "duration",
                get: function(e) {
                    return s(e, "duration", 500);
                }
            }, {
                name: "circular",
                get: function(e) {
                    return l(e, "circular");
                }
            }, {
                name: "vertical",
                get: function(e) {
                    return l(e, "vertical");
                }
            }, {
                name: "previousMargin",
                get: function(e) {
                    return e.getAttribute("previous-margin") || "0px";
                }
            }, {
                name: "nextMargin",
                get: function(e) {
                    return e.getAttribute("next-margin") || "0px";
                }
            }, {
                name: "snapToEdge",
                get: function(e) {
                    return l(e, "snap-to-edge");
                }
            }, {
                name: "displayMultipleItems",
                get: function(e) {
                    return s(e, "display-multiple-items", 1);
                }
            }, {
                name: "skipHiddenItemLayout",
                get: function(e) {
                    return l(e, "skip-hidden-item-layout");
                }
            }, {
                name: "easingFunction",
                get: function(e) {
                    return e.getAttribute("easing-function") || "default";
                }
            } ],
            handles: {
                onSwiperChange: function(e) {
                    var t = this.getDomNodeFromEvt(e);
                    t && (t.$$setAttributeWithoutUpdate("current", e.detail.current), t._oldValues = t._oldValues || {}, 
                    t._oldValues.current = e.detail.current, this.callSingleEvent("change", e));
                },
                onSwiperTransition: function(e) {
                    this.callSingleEvent("transition", e);
                },
                onSwiperAnimationfinish: function(e) {
                    this.callSingleEvent("animationfinish", e);
                }
            }
        },
        view: {
            wxCompName: "view",
            properties: [ {
                name: "hoverClass",
                get: function(e) {
                    return e.getAttribute("hover-class") || "none";
                }
            }, {
                name: "hoverStopPropagation",
                get: function(e) {
                    return l(e, "hover-stop-propagation");
                }
            }, {
                name: "hoverStartTime",
                get: function(e) {
                    return s(e, "hover-start-time", 50);
                }
            }, {
                name: "hoverStayTime",
                get: function(e) {
                    return s(e, "hover-stay-time", 400);
                }
            } ]
        },
        icon: {
            wxCompName: "icon",
            properties: [ {
                name: "type",
                get: function(e) {
                    return e.getAttribute("type") || "";
                }
            }, {
                name: "size",
                get: function(e) {
                    return e.getAttribute("size") || "23";
                }
            }, {
                name: "color",
                get: function(e) {
                    return e.getAttribute("color") || "";
                }
            } ]
        },
        progress: {
            wxCompName: "progress",
            properties: [ {
                name: "percent",
                get: function(e) {
                    return +e.getAttribute("percent") || 0;
                }
            }, {
                name: "showInfo",
                get: function(e) {
                    return l(e, "show-info");
                }
            }, {
                name: "borderRadius",
                get: function(e) {
                    return e.getAttribute("border-radius") || "0";
                }
            }, {
                name: "fontSize",
                get: function(e) {
                    return e.getAttribute("font-size") || "16";
                }
            }, {
                name: "strokeWidth",
                get: function(e) {
                    return e.getAttribute("stroke-width") || "6";
                }
            }, {
                name: "color",
                get: function(e) {
                    return e.getAttribute("color") || "#09BB07";
                }
            }, {
                name: "activeColor",
                get: function(e) {
                    return e.getAttribute("active-color") || "#09BB07";
                }
            }, {
                name: "backgroundColor",
                get: function(e) {
                    return e.getAttribute("background-color") || "#EBEBEB";
                }
            }, {
                name: "active",
                get: function(e) {
                    return l(e, "active");
                }
            }, {
                name: "activeMode",
                get: function(e) {
                    return e.getAttribute("active-mode") || "backwards";
                }
            }, {
                name: "duration",
                get: function(e) {
                    return s(e, "duration", 30);
                }
            } ],
            handles: {
                onProgressActiveEnd: function(e) {
                    this.callSingleEvent("activeend", e);
                }
            }
        },
        "rich-text": {
            wxCompName: "rich-text",
            properties: [ {
                name: "nodes",
                get: function(e) {
                    var t = e.getAttribute("nodes"), n = c(t);
                    return void 0 !== n ? n : t || [];
                }
            }, {
                name: "space",
                get: function(e) {
                    return e.getAttribute("space") || "";
                }
            } ]
        },
        text: {
            wxCompName: "text",
            properties: [ {
                name: "selectable",
                get: function(e) {
                    return l(e, "selectable");
                }
            }, {
                name: "userSelect",
                get: function(e) {
                    return l(e, "user-select");
                }
            }, {
                name: "space",
                get: function(e) {
                    return e.getAttribute("space") || "";
                }
            }, {
                name: "decode",
                get: function(e) {
                    return l(e, "decode");
                }
            } ]
        },
        button: {
            wxCompName: "button",
            properties: [ {
                name: "size",
                get: function(e) {
                    return e.getAttribute("size") || "default";
                }
            }, {
                name: "type",
                get: function(e) {
                    return e.getAttribute("type") || void 0;
                }
            }, {
                name: "plain",
                get: function(e) {
                    return l(e, "plain");
                }
            }, {
                name: "disabled",
                get: function(e) {
                    return l(e, "disabled");
                }
            }, {
                name: "loading",
                get: function(e) {
                    return l(e, "loading");
                }
            }, {
                name: "formType",
                get: function(e) {
                    return e.getAttribute("form-type") || "";
                }
            }, {
                name: "openType",
                get: function(e) {
                    return e.getAttribute("open-type") || "";
                }
            }, {
                name: "hoverClass",
                get: function(e) {
                    return e.getAttribute("hover-class") || "button-hover";
                }
            }, {
                name: "hoverStopPropagation",
                get: function(e) {
                    return l(e, "hover-stop-propagation");
                }
            }, {
                name: "hoverStartTime",
                get: function(e) {
                    return s(e, "hover-start-time", 20);
                }
            }, {
                name: "hoverStayTime",
                get: function(e) {
                    return s(e, "hover-stay-time", 70);
                }
            }, {
                name: "lang",
                get: function(e) {
                    return e.getAttribute("lang") || "en";
                }
            }, {
                name: "sessionFrom",
                get: function(e) {
                    return e.getAttribute("session-from") || "";
                }
            }, {
                name: "sendMessageTitle",
                get: function(e) {
                    return e.getAttribute("send-message-title") || "";
                }
            }, {
                name: "sendMessagePath",
                get: function(e) {
                    return e.getAttribute("send-message-path") || "";
                }
            }, {
                name: "sendMessageImg",
                get: function(e) {
                    return e.getAttribute("send-message-img") || "";
                }
            }, {
                name: "appParameter",
                get: function(e) {
                    return e.getAttribute("app-parameter") || "";
                }
            }, {
                name: "showMessageCard",
                get: function(e) {
                    return l(e, "show-message-card");
                }
            }, {
                name: "businessId",
                get: function(e) {
                    return e.getAttribute("business-id") || "";
                }
            }, {
                name: "shareType",
                get: function(e) {
                    return s(e, "share-type", 27);
                }
            }, {
                name: "shareMode",
                get: function(e) {
                    return e.getAttribute("share-mode");
                }
            } ],
            handles: {
                onButtonGetUserInfo: function(e) {
                    this.callSingleEvent("getuserinfo", e);
                },
                onButtonContact: function(e) {
                    this.callSingleEvent("contact", e);
                },
                onButtonGetPhoneNumber: function(e) {
                    this.callSingleEvent("getphonenumber", e);
                },
                onButtonError: function(e) {
                    this.callSingleEvent("error", e);
                },
                onButtonOpenSetting: function(e) {
                    this.callSingleEvent("opensetting", e);
                },
                onButtonLaunchApp: function(e) {
                    this.callSingleEvent("launchapp", e);
                },
                onButtonGetRealnameAuthInfo: function(e) {
                    this.callSingleEvent("getrealnameauthinfo", e);
                },
                onButtonChooseAvatar: function(e) {
                    this.callSingleEvent("chooseavatar", e);
                }
            }
        },
        editor: {
            wxCompName: "editor",
            properties: [ {
                name: "readOnly",
                get: function(e) {
                    return l(e, "read-only");
                }
            }, {
                name: "placeholder",
                get: function(e) {
                    return e.getAttribute("placeholder") || "";
                }
            }, {
                name: "showImgSize",
                get: function(e) {
                    return l(e, "show-img-size");
                }
            }, {
                name: "showImgToolbar",
                get: function(e) {
                    return l(e, "show-img-toolbar");
                }
            }, {
                name: "showImgResize",
                get: function(e) {
                    return l(e, "show-img-resize");
                }
            } ],
            handles: {
                onEditorReady: function(e) {
                    this.callSingleEvent("ready", e);
                },
                onEditorFocus: function(e) {
                    this.callSingleEvent("focus", e);
                },
                onEditorBlur: function(e) {
                    this.callSingleEvent("blur", e);
                },
                onEditorInput: function(e) {
                    this.callSingleEvent("input", e);
                },
                onEditorStatusChange: function(e) {
                    this.callSingleEvent("statuschange", e);
                }
            }
        },
        form: {
            wxCompName: "form",
            properties: [ {
                name: "reportSubmit",
                get: function(e) {
                    return l(e, "report-submit");
                }
            }, {
                name: "reportSubmitTimeout",
                get: function(e) {
                    return +e.getAttribute("report-submit-timeout") || 0;
                }
            } ],
            handles: {
                onFormSubmit: function(e) {
                    var t = this.getDomNodeFromEvt(e);
                    t && (t._formId = e.detail.formId);
                },
                onFormReset: function() {}
            }
        },
        INPUT: {
            wxCompName: "input",
            properties: [ {
                name: "value",
                canBeUserChanged: !0,
                get: function(e) {
                    return e.value || "";
                }
            }, {
                name: "type",
                get: function(e) {
                    var t = e.type || "text";
                    return "password" !== t ? t : "text";
                }
            }, {
                name: "password",
                get: function(e) {
                    return "password" === e.type || l(e, "password");
                }
            }, {
                name: "placeholder",
                get: function(e) {
                    return e.placeholder;
                }
            }, {
                name: "placeholderStyle",
                get: function(e) {
                    return e.getAttribute("placeholder-style") || "";
                }
            }, {
                name: "placeholderClass",
                get: function(e) {
                    return e.getAttribute("placeholder-class") || "input-placeholder";
                }
            }, {
                name: "disabled",
                get: function(e) {
                    return e.disabled;
                }
            }, {
                name: "maxlength",
                get: function(e) {
                    return s(e, "maxlength", 140);
                }
            }, {
                name: "cursorSpacing",
                get: function(e) {
                    return +e.getAttribute("cursor-spacing") || 0;
                }
            }, {
                name: "autoFocus",
                get: function(e) {
                    return l(e, "autofocus");
                }
            }, {
                name: "focus",
                canBeUserChanged: !0,
                get: function(e) {
                    return l(e, "focus");
                }
            }, {
                name: "confirmType",
                get: function(e) {
                    return e.getAttribute("confirm-type") || "done";
                }
            }, {
                name: "confirmHold",
                get: function(e) {
                    return l(e, "confirm-hold");
                }
            }, {
                name: "cursor",
                get: function(e) {
                    return s(e, "cursor", -1);
                }
            }, {
                name: "selectionStart",
                get: function(e) {
                    return s(e, "selection-start", -1);
                }
            }, {
                name: "selectionEnd",
                get: function(e) {
                    return s(e, "selection-end", -1);
                }
            }, {
                name: "adjustPosition",
                get: function(e) {
                    return l(e, "adjust-position", !0);
                }
            }, {
                name: "holdKeyboard",
                get: function(e) {
                    return l(e, "hold-keyboard");
                }
            }, {
                name: "checked",
                canBeUserChanged: !0,
                get: function(e) {
                    return l(e, "checked");
                }
            }, {
                name: "color",
                get: function(e) {
                    return e.getAttribute("color") || "#09BB07";
                }
            } ],
            handles: {
                onInputInput: function(e) {
                    var t = this.getDomNodeFromEvt(e);
                    if (t) {
                        var n = "" + e.detail.value;
                        t.$$setAttributeWithoutUpdate("value", n), t._oldValues = t._oldValues || {}, t._oldValues.value = n, 
                        this.callEvent("input", e);
                    }
                },
                onInputFocus: function(e) {
                    var t = this.getDomNodeFromEvt(e);
                    t && (t._inputOldValue = t.value, t.$$setAttributeWithoutUpdate("focus", !0), t._oldValues = t._oldValues || {}, 
                    t._oldValues.focus = !0, this.callSimpleEvent("focus", e), this.callEvent("focusin", e));
                },
                onInputBlur: function(e) {
                    var t = this.getDomNodeFromEvt(e);
                    t && (t.$$setAttributeWithoutUpdate("focus", !1), t._oldValues = t._oldValues || {}, 
                    t._oldValues.focus = !1, void 0 !== t._inputOldValue && t.value !== t._inputOldValue && (t._inputOldValue = void 0, 
                    this.callEvent("change", e)), this.callSimpleEvent("blur", e), this.callEvent("focusout", e));
                },
                onInputConfirm: function(e) {
                    this.callSimpleEvent("confirm", e);
                },
                onInputKeyBoardHeightChange: function(e) {
                    this.callSingleEvent("keyboardheightchange", e);
                },
                onRadioChange: function(e) {
                    var n = this.getDomNodeFromEvt(e);
                    if (n) {
                        var r = a.getWindow(this.pageId), o = e.detail.value, i = n.name;
                        if (o === n.value) {
                            n.$$setAttributeWithoutUpdate("checked", !0), n._oldValues = n._oldValues || {}, 
                            n._oldValues.checked = !0;
                            var u, c = r.document.querySelectorAll("input[name=".concat(i, "]")) || [], l = t(c);
                            try {
                                for (l.s(); !(u = l.n()).done; ) {
                                    var s = u.value;
                                    "radio" === s.type && s !== n && (s.setAttribute("checked", !1), s._oldValues = s._oldValues || {}, 
                                    s._oldValues.checked = !1);
                                }
                            } catch (e) {
                                l.e(e);
                            } finally {
                                l.f();
                            }
                            this.callEvent("$$radioChange", e);
                        }
                        this.callEvent("input", e), this.callEvent("change", e);
                    }
                },
                onCheckboxChange: function(e) {
                    var t = this.getDomNodeFromEvt(e);
                    t && ((e.detail.value || []).indexOf(t.value) >= 0 ? (t.$$setAttributeWithoutUpdate("checked", !0), 
                    t._oldValues = t._oldValues || {}, t._oldValues.checked = !0) : (t.$$setAttributeWithoutUpdate("checked", !1), 
                    t._oldValues = t._oldValues || {}, t._oldValues.checked = !1), this.callEvent("$$checkboxChange", e), 
                    this.callEvent("input", e), this.callEvent("change", e));
                }
            }
        },
        picker: {
            wxCompName: "picker",
            properties: [ {
                name: "headerText",
                get: function(e) {
                    return e.getAttribute("header-text") || "";
                }
            }, {
                name: "mode",
                get: function(e) {
                    return e.getAttribute("mode") || "selector";
                }
            }, {
                name: "disabled",
                get: function(e) {
                    return l(e, "disabled");
                }
            }, {
                name: "range",
                get: function(e) {
                    if ("SELECT" === e.tagName) return e.options.map(function(e) {
                        return {
                            label: e.label,
                            value: e.value
                        };
                    });
                    var t = e.getAttribute("range");
                    if ("string" == typeof t) {
                        var n = c(t);
                        t = void 0 !== n ? n : t.split(",");
                    }
                    return void 0 !== t ? t : [];
                }
            }, {
                name: "rangeKey",
                get: function(e) {
                    return "SELECT" === e.tagName ? "label" : e.getAttribute("range-key") || "";
                }
            }, {
                name: "value",
                canBeUserChanged: !0,
                get: function(e) {
                    if ("SELECT" === e.tagName) return +e.selectedIndex || 0;
                    var t = e.getAttribute("mode") || "selector", n = e.getAttribute("value");
                    if ("selector" === t) return +n || 0;
                    if ("multiSelector" === t) {
                        if ("string" == typeof n) {
                            var r = c(n);
                            n = (n = void 0 !== r ? r : n.split(",")).map(function(e) {
                                return parseInt(e, 10);
                            });
                        }
                        return n || [];
                    }
                    if ("time" === t) return n || "";
                    if ("date" === t) return n || "0";
                    if ("region" === t) {
                        if ("string" == typeof n) {
                            var o = c(n);
                            n = void 0 !== o ? o : n.split(",");
                        }
                        return n || [];
                    }
                    return n;
                }
            }, {
                name: "start",
                get: function(e) {
                    return e.getAttribute("start") || "";
                }
            }, {
                name: "end",
                get: function(e) {
                    return e.getAttribute("end") || "";
                }
            }, {
                name: "fields",
                get: function(e) {
                    return e.getAttribute("fields") || "day";
                }
            }, {
                name: "customItem",
                get: function(e) {
                    return e.getAttribute("custom-item") || "";
                }
            } ],
            handles: {
                onPickerChange: function(e) {
                    var t = this.getDomNodeFromEvt(e);
                    if (t) {
                        var n = e.detail.value;
                        t._oldValues = t._oldValues || {}, t._oldValues.value = n, "SELECT" === t.tagName ? (n = +n, 
                        t.$$setAttributeWithoutUpdate("value", t.options[n] && t.options[n].value || ""), 
                        t.$$setAttributeWithoutUpdate("selectedIndex", n), t.$$resetOptions(), this.callEvent("change", e)) : (t.$$setAttributeWithoutUpdate("value", n), 
                        this.callSingleEvent("change", e));
                    }
                },
                onPickerColumnChange: function(e) {
                    this.callSingleEvent("columnchange", e);
                },
                onPickerCancel: function(e) {
                    this.callSingleEvent("cancel", e);
                }
            }
        },
        "picker-view": {
            wxCompName: "picker-view",
            properties: [ {
                name: "value",
                canBeUserChanged: !0,
                get: function(e) {
                    var t = e.getAttribute("value");
                    if ("string" == typeof t) {
                        var n = c(t);
                        t = (t = void 0 !== n ? n : t.split(",")).map(function(e) {
                            return parseInt(e, 10);
                        });
                    }
                    return void 0 !== t ? t : [];
                }
            }, {
                name: "indicatorStyle",
                get: function(e) {
                    return e.getAttribute("indicator-style") || "";
                }
            }, {
                name: "indicatorClass",
                get: function(e) {
                    return e.getAttribute("indicator-class") || "";
                }
            }, {
                name: "maskStyle",
                get: function(e) {
                    return e.getAttribute("mask-style") || "";
                }
            }, {
                name: "maskClass",
                get: function(e) {
                    return e.getAttribute("mask-class") || "";
                }
            } ],
            handles: {
                onPickerViewChange: function(e) {
                    var t = this.getDomNodeFromEvt(e);
                    t && (t.$$setAttributeWithoutUpdate("value", e.detail.value), t._oldValues = t._oldValues || {}, 
                    t._oldValues.value = e.detail.value, this.callSingleEvent("change", e));
                },
                onPickerViewPickstart: function(e) {
                    this.callSingleEvent("pickstart", e);
                },
                onPickerViewPickend: function(e) {
                    this.callSingleEvent("pickend", e);
                }
            }
        },
        slider: {
            wxCompName: "slider",
            properties: [ {
                name: "min",
                get: function(e) {
                    return +e.getAttribute("min") || 0;
                }
            }, {
                name: "max",
                get: function(e) {
                    return s(e, "max", 100);
                }
            }, {
                name: "step",
                get: function(e) {
                    return s(e, "step", 1);
                }
            }, {
                name: "disabled",
                get: function(e) {
                    return l(e, "disabled");
                }
            }, {
                name: "value",
                canBeUserChanged: !0,
                get: function(e) {
                    return +e.getAttribute("value") || 0;
                }
            }, {
                name: "color",
                get: function(e) {
                    return e.getAttribute("color") || "#e9e9e9";
                }
            }, {
                name: "selectedColor",
                get: function(e) {
                    return e.getAttribute("selected-color") || "#1aad19";
                }
            }, {
                name: "activeColor",
                get: function(e) {
                    return e.getAttribute("active-color") || "#1aad19";
                }
            }, {
                name: "backgroundColor",
                get: function(e) {
                    return e.getAttribute("background-color") || "#e9e9e9";
                }
            }, {
                name: "blockSize",
                get: function(e) {
                    return s(e, "block-size", 28);
                }
            }, {
                name: "blockColor",
                get: function(e) {
                    return e.getAttribute("block-color") || "#ffffff";
                }
            }, {
                name: "showValue",
                get: function(e) {
                    return l(e, "show-value");
                }
            } ],
            handles: {
                onSliderChange: function(e) {
                    var t = this.getDomNodeFromEvt(e);
                    t && (t.$$setAttributeWithoutUpdate("value", e.detail.value), t._oldValues = t._oldValues || {}, 
                    t._oldValues.value = e.detail.value, this.callSingleEvent("change", e));
                },
                onSliderChanging: function(e) {
                    this.callSingleEvent("changing", e);
                }
            }
        },
        switch: {
            wxCompName: "switch",
            properties: [ {
                name: "checked",
                canBeUserChanged: !0,
                get: function(e) {
                    return l(e, "checked");
                }
            }, {
                name: "disabled",
                get: function(e) {
                    return l(e, "disabled");
                }
            }, {
                name: "type",
                get: function(e) {
                    return e.getAttribute("type") || "switch";
                }
            }, {
                name: "color",
                get: function(e) {
                    return e.getAttribute("color") || "#04BE02";
                }
            } ],
            handles: {
                onSwitchChange: function(e) {
                    var t = this.getDomNodeFromEvt(e);
                    t && (t.$$setAttributeWithoutUpdate("checked", e.detail.value), t._oldValues = t._oldValues || {}, 
                    t._oldValues.checked = e.detail.value, this.callSingleEvent("change", e));
                }
            }
        },
        TEXTAREA: {
            wxCompName: "textarea",
            properties: [ {
                name: "value",
                canBeUserChanged: !0,
                get: function(e) {
                    return e.value || "";
                }
            }, {
                name: "placeholder",
                get: function(e) {
                    return e.placeholder;
                }
            }, {
                name: "placeholderStyle",
                get: function(e) {
                    return e.getAttribute("placeholder-style") || "";
                }
            }, {
                name: "placeholderClass",
                get: function(e) {
                    return e.getAttribute("placeholder-class") || "textarea-placeholder";
                }
            }, {
                name: "disabled",
                get: function(e) {
                    return e.disabled;
                }
            }, {
                name: "maxlength",
                get: function(e) {
                    return s(e, "maxlength", 140);
                }
            }, {
                name: "autoFocus",
                get: function(e) {
                    return l(e, "autofocus");
                }
            }, {
                name: "focus",
                canBeUserChanged: !0,
                get: function(e) {
                    return l(e, "focus");
                }
            }, {
                name: "autoHeight",
                get: function(e) {
                    return l(e, "auto-height");
                }
            }, {
                name: "fixed",
                get: function(e) {
                    return l(e, "fixed");
                }
            }, {
                name: "cursorSpacing",
                get: function(e) {
                    return +e.getAttribute("cursor-spacing") || 0;
                }
            }, {
                name: "cursor",
                get: function(e) {
                    return s(e, "cursor", -1);
                }
            }, {
                name: "showConfirmBar",
                get: function(e) {
                    return l(e, "show-confirm-bar", !0);
                }
            }, {
                name: "selectionStart",
                get: function(e) {
                    return s(e, "selection-start", -1);
                }
            }, {
                name: "selectionEnd",
                get: function(e) {
                    return s(e, "selection-end", -1);
                }
            }, {
                name: "adjustPosition",
                get: function(e) {
                    return l(e, "adjust-position", !0);
                }
            }, {
                name: "holdKeyboard",
                get: function(e) {
                    return l(e, "hold-keyboard");
                }
            }, {
                name: "disableDefaultPadding",
                get: function(e) {
                    return l(e, "disable-default-padding");
                }
            } ],
            handles: {
                onTextareaFocus: function(e) {
                    var t = this.getDomNodeFromEvt(e);
                    t && (t._textareaOldValue = t.value, t.$$setAttributeWithoutUpdate("focus", !0), 
                    t._oldValues = t._oldValues || {}, t._oldValues.focus = !0, this.callSimpleEvent("focus", e), 
                    this.callEvent("focusin", e));
                },
                onTextareaBlur: function(e) {
                    var t = this.getDomNodeFromEvt(e);
                    t && (t.$$setAttributeWithoutUpdate("focus", !1), t._oldValues = t._oldValues || {}, 
                    t._oldValues.focus = !1, void 0 !== t._textareaOldValue && t.value !== t._textareaOldValue && (t._textareaOldValue = void 0, 
                    this.callEvent("change", e)), this.callSimpleEvent("blur", e), this.callEvent("focusout", e));
                },
                onTextareaLineChange: function(e) {
                    this.callSingleEvent("linechange", e);
                },
                onTextareaInput: function(e) {
                    var t = this.getDomNodeFromEvt(e);
                    if (t) {
                        var n = "" + e.detail.value;
                        t.$$setAttributeWithoutUpdate("value", n), t._oldValues = t._oldValues || {}, t._oldValues.value = n, 
                        this.callEvent("input", e);
                    }
                },
                onTextareaConfirm: function(e) {
                    this.callSimpleEvent("confirm", e);
                },
                onTextareaKeyBoardHeightChange: function(e) {
                    this.callSingleEvent("keyboardheightchange", e);
                }
            }
        },
        navigator: {
            wxCompName: "navigator",
            properties: [ {
                name: "target",
                get: function(e) {
                    return e.getAttribute("target") || "self";
                }
            }, {
                name: "url",
                get: function(e) {
                    return e.getAttribute("url") || "";
                }
            }, {
                name: "openType",
                get: function(e) {
                    return e.getAttribute("open-type") || "navigate";
                }
            }, {
                name: "delta",
                get: function(e) {
                    return s(e, "delta", 1);
                }
            }, {
                name: "appId",
                get: function(e) {
                    return e.getAttribute("app-id") || "";
                }
            }, {
                name: "path",
                get: function(e) {
                    return e.getAttribute("path") || "";
                }
            }, {
                name: "extraData",
                get: function(e) {
                    return e.getAttribute("extra-data") || {};
                }
            }, {
                name: "version",
                get: function(e) {
                    return e.getAttribute("version") || "release";
                }
            }, {
                name: "hoverClass",
                get: function(e) {
                    return e.getAttribute("hover-class") || "navigator-hover";
                }
            }, {
                name: "hoverStopPropagation",
                get: function(e) {
                    return l(e, "hover-stop-propagation");
                }
            }, {
                name: "hoverStartTime",
                get: function(e) {
                    return s(e, "hover-start-time", 50);
                }
            }, {
                name: "hoverStayTime",
                get: function(e) {
                    return s(e, "hover-stay-time", 600);
                }
            } ],
            handles: {
                onNavigatorSuccess: function(e) {
                    this.callSingleEvent("success", e);
                },
                onNavigatorFail: function(e) {
                    this.callSingleEvent("fail", e);
                },
                onNavigatorComplete: function(e) {
                    this.callSingleEvent("complete", e);
                }
            }
        },
        camera: {
            wxCompName: "camera",
            properties: [ {
                name: "mode",
                get: function(e) {
                    return e.getAttribute("mode") || "normal";
                }
            }, {
                name: "resolution",
                get: function(e) {
                    return e.getAttribute("resolution") || "medium";
                }
            }, {
                name: "devicePosition",
                get: function(e) {
                    return e.getAttribute("device-position") || "back";
                }
            }, {
                name: "flash",
                get: function(e) {
                    return e.getAttribute("flash") || "auto";
                }
            }, {
                name: "frameSize",
                get: function(e) {
                    return e.getAttribute("frame-size") || "medium";
                }
            } ],
            handles: {
                onCameraStop: function(e) {
                    this.callSingleEvent("stop", e);
                },
                onCameraError: function(e) {
                    this.callSingleEvent("error", e);
                },
                onCameraInitDone: function(e) {
                    this.callSingleEvent("initdone", e);
                },
                onCameraScanCode: function(e) {
                    this.callSingleEvent("scancode", e);
                }
            }
        },
        image: {
            wxCompName: "image",
            properties: [ {
                name: "renderingMode",
                get: function(e) {
                    return e.getAttribute("rendering-mode") || "";
                }
            }, {
                name: "src",
                get: function(e) {
                    var t = a.getWindow(e.$$pageId);
                    return e.src ? i.completeURL(e.src, t.location.origin, !0) : "";
                }
            }, {
                name: "mode",
                get: function(e) {
                    return e.getAttribute("mode") || "scaleToFill";
                }
            }, {
                name: "webp",
                get: function(e) {
                    return l(e, "webp");
                }
            }, {
                name: "lazyLoad",
                get: function(e) {
                    return l(e, "lazy-load");
                }
            }, {
                name: "showMenuByLongpress",
                get: function(e) {
                    return l(e, "show-menu-by-longpress");
                }
            } ],
            handles: {
                onImageLoad: function(e) {
                    this.callSingleEvent("load", e);
                },
                onImageError: function(e) {
                    this.callSingleEvent("error", e);
                }
            }
        },
        "live-player": {
            wxCompName: "live-player",
            properties: [ {
                name: "src",
                get: function(e) {
                    var t = a.getWindow(e.$$pageId);
                    return e.src ? i.completeURL(e.src, t.location.origin, !0) : "";
                }
            }, {
                name: "mode",
                get: function(e) {
                    return e.getAttribute("mode") || "live";
                }
            }, {
                name: "autoplay",
                get: function(e) {
                    return l(e, "autoplay");
                }
            }, {
                name: "muted",
                get: function(e) {
                    return l(e, "muted");
                }
            }, {
                name: "orientation",
                get: function(e) {
                    return e.getAttribute("orientation") || "vertical";
                }
            }, {
                name: "objectFit",
                get: function(e) {
                    return e.getAttribute("object-fit") || "contain";
                }
            }, {
                name: "backgroundMute",
                get: function(e) {
                    return l(e, "background-mute");
                }
            }, {
                name: "minCache",
                get: function(e) {
                    return s(e, "min-cache", 1);
                }
            }, {
                name: "maxCache",
                get: function(e) {
                    return s(e, "max-cache", 3);
                }
            }, {
                name: "soundMode",
                get: function(e) {
                    return e.getAttribute("sound-mode") || "speaker";
                }
            }, {
                name: "autoPauseIfNavigate",
                get: function(e) {
                    return l(e, "auto-pause-if-navigate", !0);
                }
            }, {
                name: "autoPauseIfOpenNative",
                get: function(e) {
                    return l(e, "auto-pause-if-open-native", !0);
                }
            }, {
                name: "pictureInPictureMode",
                get: function(e) {
                    var t = e.getAttribute("picture-in-picture-mode");
                    if ("string" == typeof t) {
                        var n = c(t);
                        t = void 0 !== n ? n : t.split(","), Array.isArray(t) && 1 === t.length && (t = "" + t[0]);
                    }
                    return t;
                }
            } ],
            handles: {
                onLivePlayerStateChange: function(e) {
                    this.callSingleEvent("statechange", e);
                },
                onLivePlayerFullScreenChange: function(e) {
                    this.callSingleEvent("fullscreenchange", e);
                },
                onLivePlayerNetStatus: function(e) {
                    this.callSingleEvent("netstatus", e);
                },
                onLivePlayerAudioVolumeNotify: function(e) {
                    this.callSingleEvent("audiovolumenotify", e);
                },
                onLivePlayerEnterPictureInPicture: function(e) {
                    this.callSingleEvent("enterpictureinpicture", e);
                },
                onLivePlayerLeavePictureInPicture: function(e) {
                    this.callSingleEvent("leavepictureinpicture", e);
                }
            }
        },
        "live-pusher": {
            wxCompName: "live-pusher",
            properties: [ {
                name: "url",
                get: function(e) {
                    var t = a.getWindow(e.$$pageId), n = e.getAttribute("url");
                    return n ? i.completeURL(n, t.location.origin, !0) : "";
                }
            }, {
                name: "mode",
                get: function(e) {
                    return e.getAttribute("mode") || "RTC";
                }
            }, {
                name: "autopush",
                get: function(e) {
                    return l(e, "autopush");
                }
            }, {
                name: "muted",
                get: function(e) {
                    return l(e, "muted");
                }
            }, {
                name: "enableCamera",
                get: function(e) {
                    return l(e, "enable-camera", !0);
                }
            }, {
                name: "autoFocus",
                get: function(e) {
                    return l(e, "auto-focus", !0);
                }
            }, {
                name: "orientation",
                get: function(e) {
                    return e.getAttribute("orientation") || "vertical";
                }
            }, {
                name: "beauty",
                get: function(e) {
                    return +e.getAttribute("beauty") || 0;
                }
            }, {
                name: "whiteness",
                get: function(e) {
                    return +e.getAttribute("whiteness") || 0;
                }
            }, {
                name: "aspect",
                get: function(e) {
                    return e.getAttribute("aspect") || "9:16";
                }
            }, {
                name: "minBitrate",
                get: function(e) {
                    return s(e, "min-bitrate", 200);
                }
            }, {
                name: "maxBitrate",
                get: function(e) {
                    return s(e, "max-bitrate", 1e3);
                }
            }, {
                name: "waitingImage",
                get: function(e) {
                    return e.getAttribute("waiting-image") || "";
                }
            }, {
                name: "waitingImageHash",
                get: function(e) {
                    return e.getAttribute("waiting-image-hash") || "";
                }
            }, {
                name: "zoom",
                get: function(e) {
                    return l(e, "zoom");
                }
            }, {
                name: "devicePosition",
                get: function(e) {
                    return e.getAttribute("device-position") || "front";
                }
            }, {
                name: "backgroundMute",
                get: function(e) {
                    return l(e, "background-mute");
                }
            }, {
                name: "mirror",
                get: function(e) {
                    return l(e, "mirror");
                }
            }, {
                name: "remoteMirror",
                get: function(e) {
                    return l(e, "remote-mirror");
                }
            }, {
                name: "localMirror",
                get: function(e) {
                    return e.getAttribute("local-mirror") || "auto";
                }
            }, {
                name: "audioReverbType",
                get: function(e) {
                    return +e.getAttribute("audio-reverb-type") || 0;
                }
            }, {
                name: "enableMic",
                get: function(e) {
                    return l(e, "enable-mic", !0);
                }
            }, {
                name: "enableAgc",
                get: function(e) {
                    return l(e, "enable-agc");
                }
            }, {
                name: "enableAns",
                get: function(e) {
                    return l(e, "enable-ans");
                }
            }, {
                name: "audioVolumeType",
                get: function(e) {
                    return e.getAttribute("audio-volume-type") || "voicecall";
                }
            }, {
                name: "videoWidth",
                get: function(e) {
                    return s(e, "video-width", 360);
                }
            }, {
                name: "videoHeight",
                get: function(e) {
                    return s(e, "video-height", 640);
                }
            } ],
            handles: {
                onLivePusherStateChange: function(e) {
                    this.callSingleEvent("statechange", e);
                },
                onLivePusherNetStatus: function(e) {
                    this.callSingleEvent("netstatus", e);
                },
                onLivePusherError: function(e) {
                    this.callSingleEvent("error", e);
                },
                onLivePusherBgmStart: function(e) {
                    this.callSingleEvent("bgmstart", e);
                },
                onLivePusherBgmProgress: function(e) {
                    this.callSingleEvent("bgmprogress", e);
                },
                onLivePusherBgmComplete: function(e) {
                    this.callSingleEvent("bgmcomplete", e);
                }
            }
        },
        VIDEO: {
            wxCompName: "video",
            properties: [ {
                name: "src",
                get: function(e) {
                    var t = a.getWindow(e.$$pageId);
                    return e.src ? i.completeURL(e.src, t.location.origin, !0) : "";
                }
            }, {
                name: "duration",
                get: function(e) {
                    return +e.getAttribute("duration") || 0;
                }
            }, {
                name: "controls",
                get: function(e) {
                    return e.controls;
                }
            }, {
                name: "danmuList",
                get: function(e) {
                    var t = e.getAttribute("danmu-list");
                    return void 0 !== t ? t : [];
                }
            }, {
                name: "danmuBtn",
                get: function(e) {
                    return l(e, "danmu-btn");
                }
            }, {
                name: "enableDanmu",
                get: function(e) {
                    return l(e, "enable-danmu");
                }
            }, {
                name: "autoplay",
                get: function(e) {
                    return e.autoplay;
                }
            }, {
                name: "loop",
                get: function(e) {
                    return e.loop;
                }
            }, {
                name: "muted",
                get: function(e) {
                    return e.muted;
                }
            }, {
                name: "initialTime",
                get: function(e) {
                    return +e.getAttribute("initial-time") || 0;
                }
            }, {
                name: "direction",
                get: function(e) {
                    return s(e, "direction", -1);
                }
            }, {
                name: "showProgress",
                get: function(e) {
                    return l(e, "show-progress", !0);
                }
            }, {
                name: "showFullscreenBtn",
                get: function(e) {
                    return l(e, "show-fullscreen-btn", !0);
                }
            }, {
                name: "showPlayBtn",
                get: function(e) {
                    return l(e, "show-play-btn", !0);
                }
            }, {
                name: "showCenterPlayBtn",
                get: function(e) {
                    return l(e, "show-center-play-btn", !0);
                }
            }, {
                name: "enableProgressGesture",
                get: function(e) {
                    return l(e, "enable-progress-gesture", !0);
                }
            }, {
                name: "objectFit",
                get: function(e) {
                    return e.getAttribute("object-fit") || "contain";
                }
            }, {
                name: "poster",
                get: function(e) {
                    var t = a.getWindow(e.$$pageId);
                    return e.poster ? i.completeURL(e.poster, t.location.origin, !0) : "";
                }
            }, {
                name: "showMuteBtn",
                get: function(e) {
                    return l(e, "show-mute-btn");
                }
            }, {
                name: "title",
                get: function(e) {
                    return e.getAttribute("title") || "";
                }
            }, {
                name: "playBtnPosition",
                get: function(e) {
                    return e.getAttribute("play-btn-position") || "bottom";
                }
            }, {
                name: "enablePlayGesture",
                get: function(e) {
                    return l(e, "enable-play-gesture");
                }
            }, {
                name: "autoPauseIfNavigate",
                get: function(e) {
                    return l(e, "auto-pause-if-navigate", !0);
                }
            }, {
                name: "autoPauseIfOpenNative",
                get: function(e) {
                    return l(e, "auto-pause-if-open-native", !0);
                }
            }, {
                name: "vslideGesture",
                get: function(e) {
                    return l(e, "vslide-gesture");
                }
            }, {
                name: "vslideGestureInFullscreen",
                get: function(e) {
                    return l(e, "vslide-gesture-in-fullscreen", !0);
                }
            }, {
                name: "adUnitId",
                get: function(e) {
                    return e.getAttribute("ad-unit-id") || "";
                }
            }, {
                name: "posterForCrawler",
                get: function(e) {
                    return e.getAttribute("poster-for-crawler") || "";
                }
            }, {
                name: "showCastingButton",
                get: function(e) {
                    return l(e, "show-casting-button");
                }
            }, {
                name: "pictureInPictureMode",
                get: function(e) {
                    var t = e.getAttribute("picture-in-picture-mode");
                    if ("string" == typeof t) {
                        var n = c(t);
                        t = void 0 !== n ? n : t.split(","), Array.isArray(t) && 1 === t.length && (t = "" + t[0]);
                    }
                    return t;
                }
            }, {
                name: "pictureInPictureShowProgress",
                get: function(e) {
                    return l(e, "picture-in-picture-show-progress");
                }
            }, {
                name: "enableAutoRotation",
                get: function(e) {
                    return l(e, "enable-auto-rotation");
                }
            }, {
                name: "showScreenLockButton",
                get: function(e) {
                    return l(e, "show-screen-lock-button");
                }
            } ],
            handles: {
                onVideoPlay: function(e) {
                    this.callSingleEvent("play", e);
                },
                onVideoPause: function(e) {
                    this.callSingleEvent("pause", e);
                },
                onVideoEnded: function(e) {
                    this.callSingleEvent("ended", e);
                },
                onVideoTimeUpdate: function(e) {
                    var t = this.getDomNodeFromEvt(e);
                    t && (t.$$setAttributeWithoutUpdate("currentTime", e.detail.currentTime), this.callSingleEvent("timeupdate", e));
                },
                onVideoFullScreenChange: function(e) {
                    this.callSingleEvent("fullscreenchange", e);
                },
                onVideoWaiting: function(e) {
                    this.callSingleEvent("waiting", e);
                },
                onVideoError: function(e) {
                    this.callSingleEvent("error", e);
                },
                onVideoProgress: function(e) {
                    var t = this.getDomNodeFromEvt(e);
                    t && (t.$$setAttributeWithoutUpdate("buffered", e.detail.buffered), this.callSingleEvent("progress", e));
                },
                onVideoLoadedMetaData: function(e) {
                    this.callSingleEvent("loadedmetadata", e);
                },
                onVideoControlsToggle: function(e) {
                    this.callSingleEvent("controlstoggle", e);
                },
                onVideoEnterPictureInPicture: function(e) {
                    this.callSingleEvent("enterpictureinpicture", e);
                },
                onVideoLeavePictureInPicture: function(e) {
                    this.callSingleEvent("leavepictureinpicture", e);
                }
            }
        },
        "voip-room": {
            wxCompName: "voip-room",
            properties: [ {
                name: "openid",
                get: function(e) {
                    return e.getAttribute("openid") || "";
                }
            }, {
                name: "mode",
                get: function(e) {
                    return e.getAttribute("mode") || "camera";
                }
            }, {
                name: "devicePosition",
                get: function(e) {
                    return e.getAttribute("device-position") || "front";
                }
            } ],
            handles: {
                onVoipRoomError: function(e) {
                    this.callSingleEvent("error", e);
                }
            }
        },
        map: {
            wxCompName: "map",
            properties: [ {
                name: "longitude",
                canBeUserChanged: !0,
                get: function(e) {
                    return s(e, "longitude", 116.46);
                }
            }, {
                name: "latitude",
                canBeUserChanged: !0,
                get: function(e) {
                    return s(e, "latitude", 39.92);
                }
            }, {
                name: "scale",
                canBeUserChanged: !0,
                get: function(e) {
                    return s(e, "scale", 16);
                }
            }, {
                name: "markers",
                get: function(e) {
                    var t = c(e.getAttribute("markers"));
                    return void 0 !== t ? t : [];
                }
            }, {
                name: "polyline",
                get: function(e) {
                    var t = c(e.getAttribute("polyline"));
                    return void 0 !== t ? t : [];
                }
            }, {
                name: "circles",
                get: function(e) {
                    var t = c(e.getAttribute("circles"));
                    return void 0 !== t ? t : [];
                }
            }, {
                name: "controls",
                get: function(e) {
                    var t = c(e.getAttribute("controls"));
                    return void 0 !== t ? t : [];
                }
            }, {
                name: "includePoints",
                get: function(e) {
                    var t = c(e.getAttribute("include-points"));
                    return void 0 !== t ? t : [];
                }
            }, {
                name: "showLocation",
                get: function(e) {
                    return l(e, "show-location");
                }
            }, {
                name: "polygons",
                get: function(e) {
                    var t = c(e.getAttribute("polygons"));
                    return void 0 !== t ? t : [];
                }
            }, {
                name: "subkey",
                get: function(e) {
                    return e.getAttribute("subkey") || "";
                }
            }, {
                name: "layerStyle",
                get: function(e) {
                    return s(e, "layer-style", 1);
                }
            }, {
                name: "rotate",
                canBeUserChanged: !0,
                get: function(e) {
                    return +e.getAttribute("rotate") || 0;
                }
            }, {
                name: "skew",
                canBeUserChanged: !0,
                get: function(e) {
                    return +e.getAttribute("skew") || 0;
                }
            }, {
                name: "enable3D",
                get: function(e) {
                    return l(e, "enable-3D");
                }
            }, {
                name: "showCompass",
                get: function(e) {
                    return l(e, "show-compass");
                }
            }, {
                name: "showScale",
                get: function(e) {
                    return l(e, "show-scale");
                }
            }, {
                name: "enableOverlooking",
                get: function(e) {
                    return l(e, "enable-overlooking");
                }
            }, {
                name: "enableZoom",
                get: function(e) {
                    return l(e, "enable-zoom", !0);
                }
            }, {
                name: "enableScroll",
                get: function(e) {
                    return l(e, "enable-scroll", !0);
                }
            }, {
                name: "enableRotate",
                get: function(e) {
                    return l(e, "enable-rotate");
                }
            }, {
                name: "enableSatellite",
                get: function(e) {
                    return l(e, "enable-satellite");
                }
            }, {
                name: "enableTraffic",
                get: function(e) {
                    return l(e, "enable-traffic");
                }
            }, {
                name: "setting",
                get: function(e) {
                    return c(e.getAttribute("setting")) || {};
                }
            } ],
            handles: {
                onMapTap: function(e) {
                    this.callSingleEvent("tap", e);
                },
                onMapMarkerTap: function(e) {
                    u(e), this.callSingleEvent("markertap", e);
                },
                onMapLabelTap: function(e) {
                    u(e), this.callSingleEvent("labeltap", e);
                },
                onMapControlTap: function(e) {
                    u(e), this.callSingleEvent("controltap", e);
                },
                onMapCalloutTap: function(e) {
                    u(e), this.callSingleEvent("callouttap", e);
                },
                onMapUpdated: function(e) {
                    this.callSingleEvent("updated", e);
                },
                onMapRegionChange: function(e) {
                    var t = this.getDomNodeFromEvt(e);
                    t && (e.detail.causedBy || (e.detail.causedBy = e.causedBy), "end" !== e.type && "end" !== e.detail.type || (t._oldValues = t._oldValues || {}, 
                    t._oldValues.longitude = e.detail.centerLocation && e.detail.centerLocation.longitude, 
                    t._oldValues.latitude = e.detail.centerLocation && e.detail.centerLocation.latitude, 
                    t._oldValues.scale = e.detail.scale, t._oldValues.rotate = e.detail.rotate, t._oldValues.skew = e.detail.skew), 
                    this.callSingleEvent("regionchange", e));
                },
                onMapPoiTap: function(e) {
                    u(e), this.callSingleEvent("poitap", e);
                }
            }
        },
        CANVAS: {
            wxCompName: "canvas",
            properties: [ {
                name: "type",
                get: function(e) {
                    return e.getAttribute("type") || "";
                }
            }, {
                name: "canvasId",
                get: function(e) {
                    return e.getAttribute("canvas-id") || "";
                }
            }, {
                name: "disableScroll",
                get: function(e) {
                    return l(e, "disable-scroll");
                }
            }, {
                name: "disableEvent",
                get: function(e) {
                    return l(e, "disable-event");
                }
            } ],
            handles: {
                onCanvasTouchStart: function(e) {
                    d(e), this.callSingleEvent("canvastouchstart", e), this.onTouchStart(e);
                },
                onCanvasTouchMove: function(e) {
                    d(e), this.callSingleEvent("canvastouchmove", e), this.onTouchMove(e);
                },
                onCanvasTouchEnd: function(e) {
                    d(e), this.callSingleEvent("canvastouchend", e), this.onTouchEnd(e);
                },
                onCanvasTouchCancel: function(e) {
                    d(e), this.callSingleEvent("canvastouchcancel", e), this.onTouchCancel(e);
                },
                onCanvasLongTap: function(e) {
                    d(e), this.callSingleEvent("longtap", e);
                },
                onCanvasError: function(e) {
                    d(e), this.callSingleEvent("error", e);
                }
            }
        },
        ad: {
            wxCompName: "ad",
            properties: [ {
                name: "unitId",
                get: function(e) {
                    return e.getAttribute("unit-id") || "";
                }
            }, {
                name: "adIntervals",
                get: function(e) {
                    return +e.getAttribute("ad-intervals") || 0;
                }
            }, {
                name: "adType",
                get: function(e) {
                    return e.getAttribute("ad-type") || "banner";
                }
            }, {
                name: "adTheme",
                get: function(e) {
                    return e.getAttribute("ad-theme") || "white";
                }
            } ],
            handles: {
                onAdLoad: function(e) {
                    this.callSingleEvent("load", e);
                },
                onAdError: function(e) {
                    this.callSingleEvent("error", e);
                },
                onAdClose: function(e) {
                    this.callSingleEvent("close", e);
                }
            }
        },
        "ad-custom": {
            wxCompName: "ad-custom",
            properties: [ {
                name: "unitId",
                get: function(e) {
                    return e.getAttribute("unit-id") || "";
                }
            }, {
                name: "adIntervals",
                get: function(e) {
                    return +e.getAttribute("ad-intervals") || 0;
                }
            } ],
            handles: {
                onAdCustomLoad: function(e) {
                    this.callSingleEvent("load", e);
                },
                onAdCustomError: function(e) {
                    this.callSingleEvent("error", e);
                }
            }
        },
        "official-account": {
            wxCompName: "official-account",
            handles: {
                onOfficialAccountLoad: function(e) {
                    this.callSingleEvent("load", e);
                },
                onOfficialAccountError: function(e) {
                    this.callSingleEvent("error", e);
                }
            }
        },
        "open-data": {
            wxCompName: "open-data",
            properties: [ {
                name: "type",
                get: function(e) {
                    return e.getAttribute("type") || "";
                }
            }, {
                name: "openGid",
                get: function(e) {
                    return e.getAttribute("open-gid") || "";
                }
            }, {
                name: "lang",
                get: function(e) {
                    return e.getAttribute("lang") || "en";
                }
            }, {
                name: "defaultText",
                get: function(e) {
                    return e.getAttribute("default-text") || "";
                }
            }, {
                name: "defaultAvatar",
                get: function(e) {
                    return e.getAttribute("default-avatar") || "";
                }
            } ],
            handles: {
                onOpenDataError: function(e) {
                    this.callSingleEvent("error", e);
                }
            }
        },
        "web-view": {
            wxCompName: "web-view",
            properties: [ {
                name: "src",
                get: function(e) {
                    var t = a.getWindow(e.$$pageId);
                    return e.src ? i.completeURL(e.src, t.location.origin, !0) : "";
                }
            } ],
            handles: {
                onWebviewMessage: function(e) {
                    this.callSingleEvent("message", e);
                },
                onWebviewLoad: function(e) {
                    this.callSingleEvent("load", e);
                },
                onWebviewError: function(e) {
                    this.callSingleEvent("error", e);
                }
            }
        },
        capture: {
            wxCompName: "capture"
        },
        catch: {
            wxCompName: "catch"
        },
        animation: {
            wxCompName: "animation",
            properties: [ {
                name: "animation",
                get: function(e) {
                    return c(e.getAttribute("animation"));
                }
            } ]
        },
        "not-support": {
            wxCompName: "not-support"
        }
    };
    g.SELECT = g.picker;
    var m = {
        "movable-view": {
            properties: [ {
                name: "direction",
                get: function(e) {
                    return e.getAttribute("direction") || "none";
                }
            }, {
                name: "inertia",
                get: function(e) {
                    return l(e, "inertia");
                }
            }, {
                name: "outOfBounds",
                get: function(e) {
                    return l(e, "out-of-bounds");
                }
            }, {
                name: "x",
                canBeUserChanged: !0,
                get: function(e) {
                    return +e.getAttribute("x") || 0;
                }
            }, {
                name: "y",
                canBeUserChanged: !0,
                get: function(e) {
                    return +e.getAttribute("y") || 0;
                }
            }, {
                name: "damping",
                get: function(e) {
                    return s(e, "damping", 20);
                }
            }, {
                name: "friction",
                get: function(e) {
                    return s(e, "friction", 2);
                }
            }, {
                name: "disabled",
                get: function(e) {
                    return l(e, "disabled");
                }
            }, {
                name: "scale",
                get: function(e) {
                    return l(e, "scale");
                }
            }, {
                name: "scaleMin",
                get: function(e) {
                    return s(e, "scale-min", .5);
                }
            }, {
                name: "scaleMax",
                get: function(e) {
                    return s(e, "scale-max", 10);
                }
            }, {
                name: "scaleValue",
                canBeUserChanged: !0,
                get: function(e) {
                    return s(e, "scale-value", 1);
                }
            }, {
                name: "animation",
                get: function(e) {
                    return l(e, "animation", !0);
                }
            } ],
            handles: {
                onMovableViewChange: function(e) {
                    var t = this.getDomNodeFromEvt(e);
                    t && (t.$$setAttributeWithoutUpdate("x", e.detail.x), t.$$setAttributeWithoutUpdate("y", e.detail.y), 
                    t._oldValues = t._oldValues || {
                        scaleValue: s(t, "scale-value", 1)
                    }, t._oldValues.x = e.detail.x, t._oldValues.y = e.detail.y, this.callSingleEvent("change", e));
                },
                onMovableViewScale: function(e) {
                    var t = this.getDomNodeFromEvt(e);
                    t && (t.$$setAttributeWithoutUpdate("x", e.detail.x), t.$$setAttributeWithoutUpdate("y", e.detail.y), 
                    t.$$setAttributeWithoutUpdate("scale-value", e.detail.scale), t._oldValues = t._oldValues || {}, 
                    t._oldValues.x = e.detail.x, t._oldValues.y = e.detail.y, t._oldValues.scaleValue = e.detail.scale, 
                    this.callSingleEvent("scale", e));
                },
                onMovableViewHtouchmove: function(e) {
                    this.callSingleEvent("htouchmove", e);
                },
                onMovableViewVtouchmove: function(e) {
                    this.callSingleEvent("vtouchmove", e);
                }
            }
        },
        "swiper-item": {
            properties: [ {
                name: "itemId",
                get: function(e) {
                    return e.getAttribute("item-id") || "";
                }
            } ]
        }
    }, f = Object.keys(g), h = {}, p = {}, v = {};
    f.forEach(function(e) {
        var t = g[e], n = t.wxCompName, r = t.properties, o = t.handles;
        h[e] = n, p[n] = r || [], o && Object.assign(v, o);
    }), Object.keys(m).forEach(function(e) {
        var t = m[e].handles;
        t && Object.assign(v, t);
    }), e.exports = {
        wxCompData: p,
        wxCompHandles: v,
        wxCompNameMap: h,
        wxSubComponentMap: m
    };
}, function(n, r, o) {
    var a = o(0), i = o(3), u = o(1), c = a.$$adapter, l = c.cache, s = c.Event, d = c.EventTarget, g = c.tool, m = i.USE_TEMPLATE, f = u.wxCompHandles, h = u.wxCompNameMap, p = 10, v = !1, b = wx.getSystemInfoSync().SDKVersion, E = [];
    i.compareVersion(b, "2.10.3") >= 0 && E.push("wx://form-field-button"), i.compareVersion(b, "2.16.1") < 0 && console.warn("当前基础库版本过低，建议调整最低支持基础库版本。"), 
    n.exports = Behavior({
        behaviors: E,
        properties: {
            inCover: {
                type: Boolean,
                value: !1
            }
        },
        data: {
            wxCompName: "",
            wxCustomCompName: "",
            childNodes: []
        },
        created: function() {
            var e = l.getConfig(), t = +e.optimization.domSubTreeLevel;
            t >= 1 && t <= 10 && (p = t), v = "original" === e.optimization.setDataMode;
        },
        attached: function() {
            var e = this.dataset.privateNodeId, t = this.dataset.privatePageId, n = {};
            if (this.nodeId = e, this.pageId = t, this.domNode = l.getNode(t, e), this.domNode) {
                this.document = l.getDocument(t), this.onChildNodesUpdate = g.throttle(this.onChildNodesUpdate.bind(this)), 
                this.domNode.$$clearEvent("$$childNodesUpdate", {
                    $$namespace: "root"
                }), this.domNode.addEventListener("$$childNodesUpdate", this.onChildNodesUpdate, {
                    $$namespace: "root"
                }), this.onSelfNodeUpdate = g.throttle(this.onSelfNodeUpdate.bind(this)), this.domNode.$$clearEvent("$$domNodeUpdate", {
                    $$namespace: "root"
                }), this.domNode.addEventListener("$$domNodeUpdate", this.onSelfNodeUpdate, {
                    $$namespace: "root"
                }), this.init(n);
                var r = i.filterNodes(this.domNode, p - 1, this);
                n.childNodes = i.dealWithLeafAndSimple(r, this.onChildNodesUpdate), n.wxCompName && (this.domNode._wxComponent = this), 
                Object.keys(n).length && i.setData(this, n);
            }
        },
        detached: function() {
            this.nodeId = null, this.pageId = null, this.domNode = null, this.document = null;
        },
        methods: e({
            init: function(e) {
                var t = this.domNode, n = t.tagName;
                if (-1 === m.indexOf(n) && -1 === m.indexOf(t.behavior) && "WX-COMPONENT" === n) {
                    e.wxCompName = t.behavior;
                    var r = h[e.wxCompName];
                    r ? i.checkComponentAttr(r, t, e) : console.warn('value "'.concat(e.wxCompName, "\" is not supported for wx-component's behavior"));
                }
            },
            onChildNodesUpdate: function() {
                if (this.pageId && this.nodeId) {
                    var e = i.filterNodes(this.domNode, p - 1, this);
                    if (v) i.checkDiffChildNodes(e, this.data.childNodes) && i.setData(this, {
                        childNodes: i.dealWithLeafAndSimple(e, this.onChildNodesUpdate)
                    }); else {
                        var t = {
                            count: 0
                        }, n = i.dealWithLeafAndSimple(e, this.onChildNodesUpdate);
                        this.data.childNodes.length ? i.getDiffChildNodes(n, this.data.childNodes, t, "childNodes") ? i.setData(this, {
                            childNodes: n
                        }) : t.count && (delete t.count, i.setData(this, t)) : i.setData(this, {
                            childNodes: n
                        });
                    }
                }
            },
            onSelfNodeUpdate: function() {
                if (this.pageId && this.nodeId) {
                    var e = this.domNode, t = this.data, n = e.tagName;
                    if (-1 === m.indexOf(n) && -1 === m.indexOf(e.behavior) && "WX-COMPONENT" === n) {
                        var r = {}, o = h[e.behavior];
                        t.wxCompName !== e.behavior && (r.wxCompName = e.behavior), o && i.checkComponentAttr(o, e, r, t), 
                        Object.keys(r) && i.setData(this, r);
                    }
                }
            },
            callSingleEvent: function(e, t) {
                var n = this.getDomNodeFromEvt(t);
                if (n) {
                    var r = l.getWindow(this.pageId);
                    r && n.$$trigger(e, {
                        event: new s({
                            timeStamp: r.performance.now(),
                            touches: t && t.touches,
                            changedTouches: t && t.changedTouches,
                            name: e,
                            target: n,
                            eventPhase: s.AT_TARGET,
                            detail: t && t.detail,
                            $$extra: t && t.extra
                        }),
                        currentTarget: n
                    });
                }
            },
            callSimpleEvent: function(e, t, n) {
                (n = n || this.getDomNodeFromEvt(t)) && d.$$process(n, new s({
                    touches: t.touches,
                    changedTouches: t.changedTouches,
                    name: e,
                    target: n,
                    eventPhase: s.AT_TARGET,
                    detail: t && t.detail,
                    $$extra: t && t.extra,
                    bubbles: !1
                }));
            },
            callEvent: function(e, n, r) {
                var o = this, a = this.getDomNodeFromEvt(n), u = n;
                if (a && (d.$$process(a, e, n, r, function(n, r, a) {
                    if (setTimeout(function() {
                        if (!r.$$preventDefault) {
                            var e = l.getWindow(o.pageId);
                            if ("A" !== n.tagName || "click" !== r.type || a) if ("LABEL" !== n.tagName || "click" !== r.type || a) {
                                if (("BUTTON" === n.tagName || "WX-COMPONENT" === n.tagName && "button" === n.behavior) && "click" === r.type && !a) {
                                    var u = "BUTTON" === n.tagName ? n.getAttribute("type") : n.getAttribute("form-type"), c = n.getAttribute("form"), s = c ? e.document.getElementById(c) : i.findParentNode(n, "FORM");
                                    if (!s) return;
                                    if ("submit" !== u && "reset" !== u) return;
                                    var d = s.querySelectorAll("input[name]"), g = s.querySelectorAll("textarea[name]"), m = s.querySelectorAll("wx-component[behavior=switch]").filter(function(e) {
                                        return !!e.getAttribute("name");
                                    }), f = s.querySelectorAll("wx-component[behavior=slider]").filter(function(e) {
                                        return !!e.getAttribute("name");
                                    }), h = s.querySelectorAll("wx-component[behavior=picker]").filter(function(e) {
                                        return !!e.getAttribute("name");
                                    }), p = s.querySelectorAll("wx-component[behavior=picker-view]").filter(function(e) {
                                        return !!e.getAttribute("name");
                                    });
                                    if ("submit" === u) {
                                        var v = {};
                                        d.length && d.forEach(function(e) {
                                            "radio" === e.type ? e.checked && (v[e.name] = e.value) : "checkbox" === e.type ? (v[e.name] = v[e.name] || [], 
                                            e.checked && v[e.name].push(e.value)) : v[e.name] = e.value;
                                        }), g.length && g.forEach(function(e) {
                                            return v[e.getAttribute("name")] = e.value;
                                        }), m.length && m.forEach(function(e) {
                                            return v[e.getAttribute("name")] = !!e.getAttribute("checked");
                                        }), f.length && f.forEach(function(e) {
                                            return v[e.getAttribute("name")] = +e.getAttribute("value") || 0;
                                        }), (h.length || p.length) && [].concat(h, p).forEach(function(e) {
                                            var t = e.getAttribute("value");
                                            if ("string" == typeof t) try {
                                                t = JSON.parse(t);
                                            } catch (e) {}
                                            v[e.getAttribute("name")] = t;
                                        });
                                        var b = {
                                            value: v
                                        };
                                        s._formId && (b.formId = s._formId, s._formId = null), o.callSimpleEvent("submit", {
                                            detail: b,
                                            extra: {
                                                $$from: "button"
                                            }
                                        }, s);
                                    } else "reset" === u && (d.length && d.forEach(function(e) {
                                        "radio" === e.type || "checkbox" === e.type ? e.setAttribute("checked", !1) : e.setAttribute("value", "");
                                    }), g.length && g.forEach(function(e) {
                                        return e.setAttribute("value", "");
                                    }), m.length && m.forEach(function(e) {
                                        return e.setAttribute("checked", void 0);
                                    }), f.length && f.forEach(function(e) {
                                        return e.setAttribute("value", void 0);
                                    }), h.length && h.forEach(function(e) {
                                        return e.setAttribute("value", void 0);
                                    }), p.length && p.forEach(function(e) {
                                        return e.setAttribute("value", void 0);
                                    }), o.callSimpleEvent("reset", {
                                        extra: {
                                            $$from: "button"
                                        }
                                    }, s));
                                }
                            } else {
                                var E, A = n.getAttribute("for");
                                if (A ? E = e.document.getElementById(A) : ((E = n.querySelector("input")) || (E = n.querySelector("wx-component[behavior=switch]")), 
                                E || (E = n.querySelector("wx-component[behavior=button]"))), !E || E.getAttribute("disabled")) return;
                                if ("INPUT" === E.tagName) {
                                    if (i.checkEventAccessDomNode(r, E, n)) return;
                                    var S = E.type;
                                    if ("radio" === S) {
                                        E.setAttribute("checked", !0);
                                        var N = E.name;
                                        if (N) {
                                            var y, w = e.document.querySelectorAll("input[name=".concat(N, "]")) || [], C = t(w);
                                            try {
                                                for (C.s(); !(y = C.n()).done; ) {
                                                    var x = y.value;
                                                    "radio" === x.type && x !== E && x.setAttribute("checked", !1);
                                                }
                                            } catch (e) {
                                                C.e(e);
                                            } finally {
                                                C.f();
                                            }
                                            o.callSimpleEvent("change", {
                                                detail: {
                                                    value: E.value
                                                }
                                            }, E);
                                        } else {
                                            var $ = {
                                                dataset: {
                                                    pageId: o.pageId,
                                                    privateNodeId: E.$$nodeId
                                                }
                                            };
                                            o.callEvent("$$radioChange", {
                                                target: $,
                                                currentTarget: $,
                                                timeStamp: e.performance.now(),
                                                touches: r.touches,
                                                changedTouches: r.changedTouches,
                                                detail: {}
                                            });
                                        }
                                    } else if ("checkbox" === S) {
                                        var T = E.name;
                                        if (E.setAttribute("checked", !E.checked), T) o.callSimpleEvent("change", {
                                            detail: {
                                                value: E.checked ? [ E.value ] : []
                                            }
                                        }, E); else {
                                            var I = {
                                                dataset: {
                                                    pageId: o.pageId,
                                                    privateNodeId: E.$$nodeId
                                                }
                                            };
                                            o.callEvent("$$checkboxChange", {
                                                target: I,
                                                currentTarget: I,
                                                timeStamp: e.performance.now(),
                                                touches: r.touches,
                                                changedTouches: r.changedTouches,
                                                detail: {}
                                            });
                                        }
                                    } else E.focus();
                                } else if ("WX-COMPONENT" === E.tagName) {
                                    if (i.checkEventAccessDomNode(r, E, n)) return;
                                    var k = E.behavior;
                                    if ("switch" === k) {
                                        var V = !E.getAttribute("checked");
                                        E.setAttribute("checked", V), o.callSimpleEvent("change", {
                                            detail: {
                                                value: V
                                            }
                                        }, E);
                                    } else if ("button" === k) {
                                        var _ = {
                                            dataset: {
                                                pageId: o.pageId,
                                                privateNodeId: E.$$nodeId
                                            }
                                        }, P = {
                                            target: _,
                                            currentTarget: _,
                                            timeStamp: e.performance.now(),
                                            touches: r.touches,
                                            changedTouches: r.changedTouches,
                                            detail: {}
                                        };
                                        o.callEvent("click", P, {
                                            button: 0
                                        }), l.getConfig().runtime.disableMpEvent || o.callEvent("tap", P);
                                    }
                                }
                            } else {
                                var U = n.href, O = n.target;
                                if (!U || -1 !== U.indexOf("javascript")) return;
                                "_blank" === O ? e.open(U) : e.location.href = U;
                            }
                        }
                    }, 0), "touchend" === e && n._needCallTap) {
                        n._needCallTap = !1;
                        var c = {
                            target: u.target,
                            currentTarget: u.currentTarget
                        };
                        o.callEvent("click", c, {
                            button: 0
                        }), l.getConfig().runtime.disableMpEvent || o.callEvent("tap", c);
                    }
                }), "longpress" === e)) {
                    for (var c = !0, s = a.parentNode; s; ) (s.$$hasEventHandler(e) || "function" == typeof s["on" + e]) && (c = !1), 
                    s = s.parentNode;
                    a._needCallTap = c;
                }
            },
            onTouchStart: function(e) {
                this.document && this.document.$$checkEvent(e) && this.callEvent("touchstart", e);
            },
            onTouchMove: function(e) {
                this.document && this.document.$$checkEvent(e) && this.callEvent("touchmove", e);
            },
            onTouchEnd: function(e) {
                this.document && this.document.$$checkEvent(e) && this.callEvent("touchend", e);
            },
            onTouchCancel: function(e) {
                this.document && this.document.$$checkEvent(e) && this.callEvent("touchcancel", e);
            },
            onTap: function(e) {
                this.document && this.document.$$checkEvent(e) && (this.callEvent("click", e, {
                    button: 0
                }), l.getConfig().runtime.disableMpEvent || this.callEvent("tap", e));
            },
            onLongPress: function(e) {
                this.document && this.document.$$checkEvent(e) && (l.getConfig().runtime.disableMpEvent || this.callEvent("longpress", e));
            },
            onImgLoad: function(e) {
                this.callSingleEvent("load", e);
            },
            onImgError: function(e) {
                this.callSingleEvent("error", e);
            },
            onCaptureTouchStart: function(e) {
                this.callSingleEvent("touchstart", e);
            },
            onCaptureTouchMove: function(e) {
                this.callSingleEvent("touchmove", e);
            },
            onCaptureTouchEnd: function(e) {
                this.callSingleEvent("touchend", e);
            },
            onCaptureTouchCancel: function(e) {
                this.callSingleEvent("touchcancel", e);
            },
            onCaptureTap: function(e) {
                this.callSingleEvent("click", e), l.getConfig().runtime.disableMpEvent || this.callSingleEvent("tap", e);
            },
            onCaptureLongPress: function(e) {
                l.getConfig().runtime.disableMpEvent || this.callSingleEvent("longpress", e);
            },
            onTransitionEnd: function(e) {
                this.callEvent("transitionend", e);
            },
            onAnimationStart: function(e) {
                this.callEvent("animationstart", e);
            },
            onAnimationIteration: function(e) {
                this.callEvent("animationiteration", e);
            },
            onAnimationEnd: function(e) {
                this.callEvent("animationend", e);
            },
            getDomNodeFromEvt: function(e) {
                if (e) {
                    var t = this.pageId, n = e.currentTarget && e.currentTarget.dataset.privateNodeId || this.nodeId;
                    return l.getNode(t, n);
                }
            }
        }, f)
    });
}, function(e, r, o) {
    var a = o(0), i = o(1), u = a.$$adapter, c = u.cache, l = u.tool, s = i.wxCompData, d = i.wxCompNameMap, g = i.wxSubComponentMap, m = [ "nodeId", "pageId", "id", "className", "style", "isImage", "src", "mode", "webp", "lazyLoad", "showMenuByLongpress", "useTemplate", "extra", "compName", "isLeaf", "content", "isSimple" ], f = [ "nodeId", "pageId", "content" ], h = [ "WX-COMPONENT", "WX-CUSTOM-COMPONENT" ], p = [ "swiper", "movable-area", "picker-view" ], v = [ "swiper-item", "movable-view", "picker-view-column" ], b = [ "IFRAME" ].concat(h), E = [ "cover-image", "cover-view", "match-media", "movable-area", "movable-view", "page-container", "scroll-view", "swiper", "swiper-item", "icon", "progress", "rich-text", "text", "button", "editor", "form", "INPUT", "picker", "SELECT", "picker-view", "picker-view-column", "slider", "switch", "TEXTAREA", "navigator", "camera", "image", "live-player", "live-pusher", "VIDEO", "voip-room", "map", "CANVAS", "ad", "ad-custom", "official-account", "open-data", "web-view", "capture", "catch", "animation", "not-support", "WX-CUSTOM-COMPONENT" ], A = Object.prototype.hasOwnProperty;
    function S(e, t, r) {
        if ("number" == typeof e && "number" == typeof t) return parseInt(1e3 * e, 10) === parseInt(1e3 * t, 10);
        if (r) {
            if (void 0 === t) return !e;
            if (void 0 === e) return !t;
        }
        if ("object" == n(e) && "object" == n(t)) {
            if (null === e || null === t) return e === t;
            var o = Array.isArray(e), a = Array.isArray(t);
            if (o && a) {
                if (e.length !== t.length) return !1;
                for (var i = 0, u = e.length; i < u; i++) if (!S(e[i], t[i], r)) return !1;
                return !0;
            }
            if (!a && !a) {
                var c = Object.keys(e), l = Object.keys(t);
                if (c.length !== l.length) return !1;
                for (var s = 0, d = c; s < d.length; s++) {
                    var g = d[s];
                    if (!S(e[g], t[g], r)) return !1;
                }
                return !0;
            }
        }
        return e === t;
    }
    function N(e, n, r, o) {
        var a = arguments.length > 4 && void 0 !== arguments[4] ? arguments[4] : "", i = s[e];
        if (r.wxCompName = e, i && i.length) {
            var u, c = t(i);
            try {
                for (c.s(); !(u = c.n()).done; ) {
                    var l = u.value, d = l.name, g = l.get, m = l.canBeUserChanged, f = void 0 !== m && m, h = g(n);
                    if (f) {
                        var p = n._oldValues, v = !!p && !S(h, p[d], !0);
                        o && S(h, o[d]) && !v || (r[d] = h, v && (r.forceUpdate = !0));
                    } else o && S(h, o[d]) || (r[d] = h);
                }
            } catch (e) {
                c.e(e);
            } finally {
                c.f();
            }
        }
        var b = n.id;
        o && o.id === b || (r.id = b);
        var E = "".concat(a, " wx-comp-").concat(e, " node-").concat(n.$$nodeId, " ").concat(n.className || "");
        o && o.className === E || (r.className = E);
        var A = n.style.cssText;
        o && o.style === A || (r.style = A);
        var N = n.getAttribute("hidden") || !1;
        o && o.hidden === N || (r.hidden = N);
    }
    e.exports = {
        USE_TEMPLATE: E,
        filterNodes: function e(t, n, r) {
            var o = c.getWindow(t.$$pageId), i = t.childNodes || [];
            if ("function" != typeof i.map) return [];
            if ("SELECT" === t.tagName) {
                var u = i.findIndex(function(e) {
                    return e.value === t.value;
                });
                i = -1 !== u ? [ i[u] ] : [];
            }
            return i.map(function(t) {
                var i = t.$$domInfo;
                if (("element" === i.type || "text" === i.type) && !i.slot) {
                    if (t._wxComponent = r, i.className = "element" === i.type ? "h5-".concat(i.tagName, " node-").concat(i.nodeId, " ").concat(i.className || "") : "", 
                    i.domNode = t, h.indexOf(t.tagName) >= 0) {
                        if ("wx-component" === i.tagName && -1 !== v.indexOf(t.behavior)) {
                            i.compName = t.behavior, i.extra = {
                                hidden: t.getAttribute("hidden") || !1
                            };
                            var u = (g[t.behavior] || {}).properties;
                            return u && u.length && u.forEach(function(e) {
                                var n = e.name, r = e.get, o = e.canBeUserChanged, a = void 0 !== o && o, u = r(t);
                                if (i.extra[n] = u, a) {
                                    var c = t._oldValues;
                                    c && !S(u, c[n], !0) && (i.extra.forceUpdate = !0);
                                }
                            }), t.childNodes.length && n > 0 && (i.childNodes = e(t, n - 1, r)), i;
                        }
                        i.className = "h5-".concat(i.tagName, " ").concat("wx-component" === i.tagName ? "wx-" + t.behavior : ""), 
                        i.id = "", i.style = "";
                    }
                    i.isImage = "element" === i.type && "img" === i.tagName, i.isImage && (i.src = t.src ? l.completeURL(t.src, o.location.origin, !0) : "", 
                    i.mode = t.getAttribute("mode") || "", i.webp = !!t.getAttribute("webp"), i.lazyLoad = !!t.getAttribute("lazy-load"), 
                    i.showMenuByLongpress = !!t.getAttribute("show-menu-by-longpress"));
                    var c = "wx-component" === i.tagName ? t.behavior : t.tagName;
                    if (c = a.$$adapter.tool.isTagNameSupport(c) ? c : "not-support", i.useTemplate = !i.isImage && -1 !== E.indexOf(c), 
                    i.useTemplate) {
                        var s = d[c], m = {};
                        s && N(s, t, m, null, "h5-".concat(i.tagName, " ").concat("wx-component" === i.tagName ? "wx-" + t.behavior : "")), 
                        m.pageId = i.pageId, m.nodeId = i.nodeId, m.inCover = r.data.inCover, m.hasChildren = !!t.childNodes.length, 
                        i.extra = m;
                        var f = p.indexOf(c);
                        if (-1 !== f) {
                            var A = e(t, "picker-view" === c ? 1 : 0) || [];
                            m.childNodes = A.filter(function(e) {
                                return "element" === e.type && e.compName === v[f];
                            }).map(function(e) {
                                var t = Object.assign({}, e);
                                return t.childNodes && (t.childNodes = t.childNodes.map(function(e) {
                                    return Object.assign({}, e, {
                                        style: ""
                                    });
                                })), t;
                            });
                        }
                        if ("map" === c || "scroll-view" === c) {
                            var y = t.childNodes.map(function(e) {
                                var t = e.$$domInfo;
                                return {
                                    slot: t.slot,
                                    nodeId: t.nodeId,
                                    pageId: t.pageId,
                                    id: t.id,
                                    className: "element" === t.type ? "h5-".concat(t.tagName, " node-").concat(t.nodeId, " ").concat(t.className || "") : "",
                                    style: t.style
                                };
                            }).filter(function(e) {
                                return !!e.slot;
                            });
                            m.hasSlots = y.length, m.hasChildren = y.length < t.childNodes.length, m.slots = y;
                        }
                        "catch" === s && (m.touchStart = t.$$hasEventHandler("touchstart") ? "onTouchStart" : "", 
                        m.touchMove = t.$$hasEventHandler("touchmove") ? "onTouchMove" : "", m.touchEnd = t.$$hasEventHandler("touchend") ? "onTouchEnd" : "", 
                        m.touchCancel = t.$$hasEventHandler("touchcancel") ? "onTouchCancel" : ""), "text" !== s && "not-support" !== s || (m.content = t.textContent), 
                        "WX-CUSTOM-COMPONENT" === c && (m.wxCompName = "custom-component", m.wxCustomCompName = t.behavior);
                    }
                    return i.isLeaf = !i.isImage && !i.useTemplate && "element" === i.type && !t.children.length && -1 === b.indexOf(t.tagName), 
                    i.isLeaf && (i.content = t.childNodes.map(function(e) {
                        return "text" === e.$$domInfo.type ? e.textContent : "";
                    }).join("")), i.isSimple = !i.isImage && !i.useTemplate && !i.isLeaf && "element" === i.type && -1 === b.indexOf(t.tagName) && n > 0, 
                    i.isSimple && (i.content = "", i.childNodes = e(t, n - 1, r)), i;
                }
            }).filter(function(e) {
                return !!e;
            });
        },
        checkDiffChildNodes: function e(t, r) {
            if (t.length !== r.length) return !0;
            for (var o = 0, a = t.length; o < a; o++) {
                var i = t[o], u = r[o];
                if (i.type !== u.type) return !0;
                for (var c = 0, l = "element" === i.type ? m : f; c < l.length; c++) {
                    var s = l[c], d = i[s], g = u[s];
                    if ("object" != n(d) || Array.isArray(d)) {
                        if (!S(d, g)) return !0;
                    } else {
                        if ("object" != n(g)) return !0;
                        if ("extra" === s && d && d.forceUpdate) return d.forceUpdate = !1, !0;
                        for (var h = Object.keys(d), p = "extra" === s ? i.domNode : null, v = p && p._oldValues, b = 0, E = h; b < E.length; b++) {
                            var A = E[b], N = g[A];
                            if (v && void 0 !== v[A] && (N = v[A]), !S(d[A], N)) return !0;
                        }
                    }
                }
                var y = i.childNodes || [], w = u.childNodes || [];
                if ((y.length || w.length) && e(y, w)) return !0;
            }
            return !1;
        },
        getDiffChildNodes: function e(r, o, a, i, u, l) {
            var s = n(r);
            if ("object" === s && "object" === n(o) && null !== r && null !== o) {
                var d = Array.isArray(r), g = Array.isArray(o);
                if (d && g) {
                    if (r.length < o.length) {
                        if (a[i] = r, a.count++ > 100) return !0;
                    } else for (var h = 0, p = r.length; h < p; h++) if (e(r[h], o[h], a, "".concat(i, "[").concat(h, "]"))) return !0;
                } else if (d || g) {
                    if (a[i] = r, a.count++ > 100) return !0;
                } else {
                    var v = r.type, b = o.type, E = "element" === v ? [ "childNodes" ].concat(m) : f, N = !u && ("element" === v || "text" === v), y = !u && ("element" === v || "text" === v);
                    if (N && y && v === b) {
                        var w, C = t(E);
                        try {
                            for (C.s(); !(w = C.n()).done; ) {
                                var x = w.value, $ = "".concat(i, ".").concat(x), T = "extra" === x ? c.getNode(r.pageId, r.nodeId) : null;
                                if (e(r[x], o[x], a, $, "extra" === x, T)) return !0;
                            }
                        } catch (e) {
                            C.e(e);
                        } finally {
                            C.f();
                        }
                    } else if (N || y) {
                        if (a[i] = r, a.count++ > 100) return !0;
                    } else if (u && r.forceUpdate) {
                        if (r.forceUpdate = !1, a[i] = r, a.count++ > 100) return !0;
                    } else {
                        for (var I = 0, k = Object.keys(r); I < k.length; I++) {
                            var V = k[I], _ = "".concat(i, ".").concat(V);
                            if (A.call(o, V)) {
                                var P = o[V];
                                if (l && l._oldValues && void 0 !== l._oldValues[V] && (P = l._oldValues[V]), e(r[V], P, a, _)) return !0;
                            } else if (a[_] = r[V], a.count++ > 100) return !0;
                        }
                        for (var U = 0, O = Object.keys(o); U < O.length; U++) {
                            var L = O[U], M = "".concat(i, ".").concat(L);
                            if (!A.call(r, L) && (a[M] = null, a.count++ > 100)) return !0;
                        }
                    }
                }
            } else if (!S(r, o) && (r = "undefined" === s ? null : r, a[i] = r, a.count++ > 100)) return !0;
        },
        checkComponentAttr: N,
        dealWithLeafAndSimple: function e(t, n) {
            return t && t.length && (t = t.map(function(t) {
                var r = Object.assign({}, t);
                return r.domNode.$$clearEvent("$$childNodesUpdate", {
                    $$namespace: "child"
                }), (r.isImage || r.isLeaf || r.isSimple || r.useTemplate) && r.domNode.addEventListener("$$childNodesUpdate", n, {
                    $$namespace: "child"
                }), delete r.domNode, r.childNodes = e(r.childNodes, n) || [], r.extra && r.extra.childNodes && (r.extra.childNodes = e(r.extra.childNodes, n) || []), 
                r;
            })), t;
        },
        checkEventAccessDomNode: function(e, t, n) {
            n = n || t.ownerDocument.body;
            var r = e.target;
            if (t === n) return !0;
            for (;r && r !== n; ) {
                if (r === t) return !0;
                r = r.parentNode;
            }
            return !1;
        },
        findParentNode: function(e, t) {
            var n = function(e, t) {
                return !!e && (e.tagName === t || "WX-COMPONENT" === e.tagName && e.behavior === t.toLowerCase());
            }, r = e.parentNode;
            if (n(r, t)) return r;
            for (;r && r.tagName !== t; ) if (n(r = r.parentNode, t)) return r;
            return null;
        },
        compareVersion: function(e, t) {
            e = e.split("."), t = t.split(".");
            for (var n = Math.max(e.length, t.length); e.length < n; ) e.push("0");
            for (;t.length < n; ) t.push("0");
            for (var r = 0; r < n; r++) {
                var o = parseInt(e[r], 10), a = parseInt(t[r], 10);
                if (o > a) return 1;
                if (o < a) return -1;
            }
            return 0;
        },
        setData: function(e, t) {
            l.setData ? l.setData(e, t) : e.setData(t);
        }
    };
} ]);