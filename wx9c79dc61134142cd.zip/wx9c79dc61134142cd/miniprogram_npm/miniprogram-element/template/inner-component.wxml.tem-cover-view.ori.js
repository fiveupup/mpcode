function(e,s,r,gg){
var z=gz$gwx_40()
var b=x[41]+':cover-view'
r.wxVkey=b
gg.f=$gdc(f_["./miniprogram_npm/miniprogram-element/template/inner-component.wxml"],"",1)
if(p_[b]){_wl(b,x[41]);return}
p_[b]=true
try{
var oB=_mz(z,'cover-view',['bindlongpress',17,'bindtap',1,'bindtouchcancel',2,'bindtouchend',3,'bindtouchmove',4,'bindtouchstart',5,'class',6,'data-private-node-id',7,'data-private-page-id',8,'hidden',9,'id',10,'markerId',11,'scrollTop',12,'style',13],[],e,s,gg)
var xC=_v()
_(oB,xC)
if(_oz(z,31,e,s,gg)){xC.wxVkey=1
var oD=_mz(z,'element-vhost',['class',32,'data-private-node-id',1,'data-private-page-id',2,'inCover',4],['wx-custom-component',3],e,s,gg)
_(xC,oD)
}
xC.wxXCkey=1
xC.wxXCkey=3
_(r,oB)
}catch(err){
p_[b]=false
throw err
}
p_[b]=false
return r
}