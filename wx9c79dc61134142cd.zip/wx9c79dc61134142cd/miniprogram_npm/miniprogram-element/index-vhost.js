var s = require("./base");

Component({
    behaviors: [ s ],
    options: {
        addGlobalClass: !0,
        virtualHost: !0
    }
});