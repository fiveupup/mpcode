var s = require("./base");

Component({
    behaviors: [ s ],
    options: {
        addGlobalClass: !0
    }
});