var e = require("../../utils/util"), r = require("@tencent/wecalendar-web-business-plugins").timeInterval;

module.exports = function() {
    var t = e.getObjFromLocalStorage("view_config", {
        "server.timepicker.default_interval": "15"
    });
    return r.minuteList(t["server.timepicker.default_interval"]);
};