var t = require("../../@babel/runtime/helpers/slicedToArray"), e = require("./getInterval"), a = 240;

Component({
    properties: {
        cycle: {
            type: Boolean,
            value: !1
        },
        hour: {
            type: Number,
            value: -1
        },
        minute: {
            type: Number,
            value: -1
        }
    },
    data: {
        hours: [],
        minutes: [],
        indexVal: [ -1, -1 ]
    },
    attached: function() {
        this.generatorData();
    },
    methods: {
        generatorData: function() {
            var t = this.data.cycle, a = e();
            if (t) this.generatorCycleData(a); else {
                for (var i = 0, n = []; i < 24; ) n.push(i < 10 ? "0".concat(i) : "".concat(i)), 
                i += 1;
                this.setData({
                    hours: n,
                    minutes: a
                }), this.setInitVal(a);
            }
        },
        generatorCycleData: function(t) {
            for (var e = [], i = [], n = t.length, r = 100 * n, s = 0; s < a; s++) {
                var u = s % 24;
                u = u < 10 ? "0".concat(u) : "".concat(u), e.push(u);
            }
            for (var h = 0; h < r; h++) {
                var o = t[h % n];
                i.push(o);
            }
            this.setData({
                hours: e,
                minutes: i
            }), this.setInitVal(i);
        },
        setInitVal: function(t) {
            var e = this.data, i = e.hour, n = e.minute, r = t.length;
            if (-1 === i) {
                var s = new Date();
                i = s.getHours(), n = s.getMinutes();
            }
            for (var u = 0, h = 0; u < r; u++) if (t[u] === n || n > t[u - 1] && n < t[u]) {
                h = u;
                break;
            }
            this.data.cycle && (i += a / 2, h += t.length / 2), this.setData({
                indexVal: [ i, h ]
            });
        },
        timePickerchange: function(e) {
            var a = this.data.minutes, i = e.detail, n = (void 0 === i ? {} : i).value, r = t(void 0 === n ? [] : n, 2), s = r[0] % 24, u = a[r[1] % a.length];
            this.setData({
                hour: s,
                minute: u
            }), this.triggerEvent("change", {
                hour: s,
                minute: u
            });
        },
        timePickerchangeEnd: function() {
            var t = this.data.minutes;
            this.setInitVal(t);
        }
    }
});