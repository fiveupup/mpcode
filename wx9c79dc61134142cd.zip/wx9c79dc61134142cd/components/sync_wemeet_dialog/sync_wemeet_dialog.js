Component({
    options: {
        multipleSlots: !0
    },
    properties: {
        dialogHeight: {
            type: Number,
            value: 956
        }
    },
    data: {
        show: !1
    },
    attached: function() {
        console.log("slider-message-dialog attached");
    },
    methods: {
        show: function() {
            this.setData({
                show: !0
            });
        },
        hide: function() {
            this.setData({
                show: !1
            });
        },
        onSyncTab: function() {
            console.log("onSyncTab"), this.triggerEvent("UserConfirm", {});
        },
        onNotSyncTab: function() {
            console.log("onNotSyncTab"), this.triggerEvent("UserDeny", {});
        }
    }
});