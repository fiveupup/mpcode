var t = require("../../utils/Dayjs.js");

Component({
    properties: {
        allDayChecked: {
            type: Boolean,
            value: !1
        },
        startTime: {
            type: Number,
            value: 0
        },
        endTime: {
            type: Number,
            value: 0
        },
        label: {
            type: Object,
            value: {
                allDay: "日期",
                normal: "时间"
            }
        },
        monthChecked: {
            type: Boolean,
            value: !1
        },
        timeChecked: {
            type: Boolean,
            value: !0
        },
        limit: {
            type: Object,
            value: {}
        }
    },
    data: {
        startDateString: "",
        startTimeString: "",
        endDateString: "",
        startTimestamp: "",
        endTimestamp: "",
        startDateConfig: {
            year: 0,
            month: 0,
            day: 0,
            hour: 0,
            minute: 0
        },
        endDateConfig: {
            year: 0,
            month: 0,
            day: 0
        }
    },
    attached: function() {
        var e = this.data.allDayChecked, a = this.data, i = a.startTime, n = a.endTime;
        i || (i = Date.now()), i = t(i), e && !n && (n = i.add(5, "day").valueOf()), this.setStartTime(i), 
        e && this.setEndTime(t(n));
    },
    methods: {
        handleMonthClick: function() {
            var t = this.data.monthChecked;
            this.setData({
                monthChecked: !t,
                timeChecked: !1
            }), this.triggerEvent("click", {
                type: "month",
                visible: !t
            });
        },
        handleTimeClick: function() {
            var t = this.data.timeChecked;
            this.setData({
                monthChecked: !1,
                timeChecked: !t
            }), this.triggerEvent("click", {
                type: "time",
                visible: !t
            });
        },
        calendarDateChange: function(e) {
            var a = this.data, i = a.monthChecked, n = a.allDayChecked, r = a.startTimestamp, m = e.detail.selectDate, s = m.year, h = m.month, o = m.day, d = t(r);
            if (i) {
                var u = t("".concat(s, "-").concat(h, "-").concat(o, " ").concat(d.hour(), ":").concat(d.minute())), c = u.valueOf();
                if (n) {
                    var l = e.detail.nextTime;
                    if (!l) return;
                    c = u.hour(0).minute(0).valueOf();
                    var g = l.year, f = l.month, v = l.day, D = t("".concat(g, "-").concat(f, "-").concat(v)), y = u;
                    c > D.valueOf() && (y = D, D = u), s === g && h === f && o === v || (D = D.add(1, "day")), 
                    this.setData({
                        startDateString: y.format("MM月DD日"),
                        endDateString: D.format("MM月DD日"),
                        startTimestamp: y.valueOf(),
                        endTimestamp: D.valueOf()
                    }), this.triggerEvent("change", {
                        startTime: y.valueOf(),
                        endTime: D.valueOf()
                    });
                } else this.setData({
                    startDateString: u.format("MM月DD日"),
                    startTimeString: u.format("HH:mm"),
                    startTimestamp: c
                }), this.triggerEvent("change", {
                    startTime: c
                });
            }
        },
        lastdayChange: function() {},
        timeChange: function(e) {
            var a = (e || {}).detail, i = void 0 === a ? {} : a, n = i.hour, r = i.minute, m = this.data.startTimestamp, s = (m = t(m).hour(n).minute(r)).valueOf();
            this.setData({
                startTimestamp: s,
                startTimeString: m.format("HH:mm")
            }), this.triggerEvent("change", {
                startTime: s
            });
        },
        setStartTime: function(t) {
            var e = this.data.startTimestamp, a = t.valueOf();
            e !== a && this.setData({
                startDateString: t.format("MM月DD日"),
                startTimeString: t.format("HH:mm"),
                startDateConfig: {
                    year: t.get("year"),
                    month: t.get("month") + 1,
                    day: t.get("date"),
                    hour: t.get("hour"),
                    minute: t.get("minute")
                },
                startTimestamp: a
            });
        },
        setEndTime: function(t) {
            var e = (t = t.add(-1, "day")).valueOf();
            this.setData({
                endDateString: t.format("MM月DD日"),
                endDateConfig: {
                    year: t.get("year"),
                    month: t.get("month") + 1,
                    day: t.get("date"),
                    hour: t.get("hour"),
                    minute: t.get("minute")
                },
                endTimestamp: e
            });
        }
    },
    observers: {
        startTime: function() {
            this.setStartTime(t(this.data.startTime));
        },
        endTime: function() {
            this.setEndTime(t(this.data.endTime));
        },
        monthChecked: function() {
            var e = this.data, a = e.startTimestamp, i = e.startDateConfig, n = i.year, r = i.month, m = i.day, s = t(a), h = s.get("year"), o = s.get("month") + 1, d = s.get("date");
            h === n && o === r && m === d || this.setData({
                startDateConfig: {
                    year: h,
                    month: o,
                    day: d,
                    hour: s.get("hour"),
                    minute: s.get("minute")
                }
            });
        }
    }
});