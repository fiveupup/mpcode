Component({
    name: "custom-picker",
    properties: {
        title: {
            type: String,
            value: "选择视图"
        },
        showDialog: {
            type: Boolean,
            value: !1
        },
        bgColor: {
            type: String,
            value: "#F9FCFF"
        },
        showRetunIcon: {
            type: Boolean,
            value: !1
        }
    },
    externalClasses: [ "custom-class" ],
    options: {
        addGlobalClass: !0
    },
    methods: {
        cancelDialog: function() {
            this.triggerEvent("closePicker");
        }
    }
});