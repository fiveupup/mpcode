var t = require("../../@babel/runtime/helpers/slicedToArray"), e = require("../../utils/Dayjs.js");

Component({
    properties: {
        show: {
            type: Boolean,
            value: !1
        },
        allday: {
            type: Boolean,
            value: !1
        },
        startTimeData: {
            type: Object
        },
        endTimeData: {
            type: Object
        },
        lastTimeData: {
            type: Object
        },
        unfold: {
            type: String,
            value: ""
        }
    },
    data: {
        startDateConfig: {
            year: 0,
            month: 0,
            day: 0,
            timestamp: 0
        },
        endDateConfig: {
            year: 0,
            month: 0,
            day: 0,
            timestamp: 0
        },
        startTimeConfig: {
            minuteList: [ 0, 15, 30, 45 ],
            indexVal: [ 0, 0 ],
            hours: [],
            minutes: [],
            hourSize: 240,
            minuteSize: 400
        },
        endTimeConfig: {
            minuteSet: [ 0, 15, 30, 45 ],
            indexVal: [ 0, 0, 0 ],
            days: [ "当天", "隔天" ],
            hours: [],
            minutes: [ 0, 15, 30, 45 ]
        },
        lastTimeConfig: {
            oneDay: {
                indexVal: [ 0, 0 ],
                hours: [],
                minutes: [],
                minuteSet: []
            },
            allDay: {
                indexVal: [ 0, 0 ],
                day: []
            }
        },
        startTime: {
            year: 0,
            month: 0,
            day: 0,
            hour: 0,
            minute: 0
        },
        endTime: {
            year: 0,
            month: 0,
            day: 0,
            hour: 0,
            minute: 0
        },
        lastTime: {
            day: 1,
            hour: 1,
            minute: 0
        },
        startDateString: "",
        endDateString: "",
        startTimeString: "",
        endTimeString: "",
        lastTimeString: "",
        allDayChecked: !1,
        monthChecked: !1,
        timeChecked: !1,
        endTimeChecked: !1,
        lastTimeChecked: !1,
        disableSetDuration: !1,
        firstCount: 0
    },
    attached: function() {
        this.setStartTime(), this.setStartTimePicker(), this.setEndHoursArrToday(), this.setEndHourAndMinute(), 
        this.setLastPicker();
    },
    methods: {
        setStartTime: function() {
            var t = new Date(), e = {
                year: t.getFullYear(),
                month: t.getMonth() + 1,
                day: t.getDate(),
                hour: t.getHours(),
                minute: t.getMinutes()
            };
            this.setData({
                startTime: e,
                startDateConfig: e
            });
        },
        setStartTimePicker: function() {
            for (var t = [], e = [], a = this.data.startTimeConfig, i = a.hourSize, n = a.minuteSize, s = a.minuteList, o = 0; o < i; o++) {
                var d = o % 24;
                d = d < 10 ? "0".concat(d) : "".concat(d), t.push(d);
            }
            for (var r = 0; r < n; r++) {
                var m = s[r % 4];
                e.push(m);
            }
            var h = new Date().getHours();
            this.setData({
                "startTimeConfig.hours": t,
                "startTimeConfig.minutes": e
            }), this.setData({
                "startTimeConfig.indexVal": [ h, 200 ]
            });
        },
        setLastPicker: function() {
            this.setLastPickerHour(), this.setLastPickerMinute(), this.setLastPickerDay();
        },
        setLastPickerHour: function() {
            for (var t = [], e = 0; e <= 24; e++) t.push("".concat(e, "小时"));
            this.setData({
                "lastTimeConfig.oneDay.hours": t
            });
        },
        setLastPickerMinute: function() {
            this.setData({
                "lastTimeConfig.oneDay.minuteSet": [ 0, 15, 30, 45 ]
            });
        },
        setEndHoursArrToday: function() {
            var t = [], e = this.data.startTime.minute, a = this.data.startTime.hour;
            45 === e && (a += 1);
            for (var i = 0; i < 23 - a + 1; i++) {
                var n = i % (23 - a + 1);
                n = (n += a) < 10 ? "0".concat(n) : "".concat(n), t.push(n);
            }
            console.log("setEndHoursArrToday-endHoursArr", t), this.setData({
                "endTimeConfig.hours": t
            });
        },
        setEndHoursArrTommorrow: function(t) {
            for (var e = [], a = 0; a < t + 1; a++) {
                var i = a % (t + 1);
                i = i < 10 ? "0".concat(i) : "".concat(i), e.push(i);
            }
            console.log("setEndHoursArrTommorrow-endHoursArr", e), this.setData({
                "endTimeConfig.hours": e
            });
        },
        setEndHourAndMinute: function() {
            var t = this;
            if (0 !== this.data.endTimeConfig.hours.length) {
                var e = this.data.endTime, a = e.day, i = e.hour, n = e.minute, s = this.data.startTime, o = s.day, d = s.hour, r = s.minute, m = 0, h = 0;
                if (a === o) h = i - d, 45 === r && (h -= 1); else {
                    m = 1, this.setEndHoursArrTommorrow(d), h = i;
                    var u = this.data.endTimeConfig.minuteSet;
                    0 === r ? u = [ 0 ] : 15 === r ? u = [ 0, 15 ] : 30 === r && (u = [ 0, 15, 30 ]), 
                    this.setData({
                        "endTimeConfig.minuteSet": u
                    }), 45 === r && (h += 1);
                }
                var c = this.data.endTimeConfig.minuteSet.findIndex(function(t) {
                    return t === n;
                });
                console.log("endTimeConfig.indexVal", [ m, h, c ]), console.log("endTimeConfig:", this.data.endTimeConfig), 
                setTimeout(function() {
                    t.setData({
                        "endTimeConfig.indexVal": [ m, h, c ]
                    });
                }, 300);
            }
        },
        setEndTimePicker: function() {
            if (!(this.data.firstCount < 2)) {
                var t = this.data.startTime, e = t.year, a = t.month, i = t.day, n = t.hour, s = t.minute, o = new Date(e, a - 1, i);
                o.setHours(n), o.setMinutes(s), o.setSeconds(0), o.setMilliseconds(0);
                var d = o.getTime(), r = this.data.lastTime, m = r.hour, h = r.minute, u = new Date(d + 60 * m * 60 * 1e3 + 60 * h * 1e3), c = u.getDate(), l = u.getHours(), T = u.getMinutes();
                this.setData({
                    disableSetDuration: !0,
                    "endTime.day": i === c ? i : i + 1,
                    "endTime.hour": l,
                    "endTime.minute": T
                });
            }
        },
        setLastPickerDay: function() {
            for (var t = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : new Date(), a = [], i = new Date(), n = [ "周日", "周一", "周二", "周三", "周四", "周五", "周六" ], s = 1; s <= 30; s++) {
                var o = new Date(t + 864e5 * (s - 1)), d = i.getFullYear() === o.getFullYear(), r = d ? "" : "".concat(o.getFullYear(), "/"), m = o.getDay(), h = d && i.getMonth() === o.getMonth() && i.getDate() === o.getDate();
                h ? a.push("".concat(s, "天 （今天）")) : a.push("".concat(s, "天 （").concat(r).concat(e(o).format("MM/DD"), " ").concat(n[m], "）"));
            }
            this.setData({
                "lastTimeConfig.allDay.day": a
            });
        },
        timePickerchange: function(e) {
            var a = e.detail, i = (void 0 === a ? {} : a).value, n = t(void 0 === i ? [] : i, 2), s = n[0], o = n[1], d = s % 24, r = this.data.startTimeConfig.minuteList[o % 4];
            this.setData({
                disableSetDuration: !0,
                "startTime.hour": d,
                "startTime.minute": r
            });
        },
        endTimePickerchange: function(t) {
            var e = this, a = t.detail, i = (void 0 === a ? {} : a).value, n = void 0 === i ? [] : i;
            console.log("endTimePickerchange-value", n);
            var s = n[0], o = n[1], d = n[2], r = this.data.startTime.day, m = this.data.startTime.minute, h = this.data.startTime.hour, u = 0;
            0 === s ? (this.setEndHoursArrToday(h), void 0 === (u = this.data.endTimeConfig.hours[o]) && (o = this.data.endTimeConfig.hours.length - 1, 
            u = parseInt(this.data.endTimeConfig.hours[o]))) : (r += 1, this.setEndHoursArrTommorrow(h), 
            u = parseInt(this.data.endTimeConfig.hours[o]), u = o - h > 0 ? parseInt(o - h) : o);
            var c = this.data.endTimeConfig.minuteSet, l = c[d];
            void 0 === l && (d = c.findIndex(function(t) {
                return t === e.data.endTime.minute;
            }), l = c[d]), console.log("结束时间修改前的minute", c, l, d), 0 === s && parseInt(u) === parseInt(h) ? (0 === m ? d = -1 === (d = (c = [ 15, 30, 45 ]).findIndex(function(t) {
                return t === l;
            })) ? 0 : d : 15 === m ? d = -1 === (d = (c = [ 30, 45 ]).findIndex(function(t) {
                return t === l;
            })) ? 0 : d : 30 === m && (d = -1 === (d = (c = [ 45 ]).findIndex(function(t) {
                return t === l;
            })) ? 0 : d), this.setData({
                "endTimeConfig.minuteSet": c
            })) : 1 === s && parseInt(u) === parseInt(h) ? (0 === m ? d = -1 === (d = (c = [ 0 ]).findIndex(function(t) {
                return t === l;
            })) ? 0 : d : 15 === m ? d = -1 === (d = (c = [ 0, 15 ]).findIndex(function(t) {
                return t === l;
            })) ? 0 : d : 30 === m && (d = -1 === (d = (c = [ 0, 15, 30 ]).findIndex(function(t) {
                return t === l;
            })) ? 0 : d), this.setData({
                "endTimeConfig.minuteSet": c
            })) : (d = -1 === (d = (c = [ 0, 15, 30, 45 ]).findIndex(function(t) {
                return t === l;
            })) ? 0 : d, this.setData({
                "endTimeConfig.minuteSet": c
            })), l = c[d], console.log("结束时间修改后的minute", c, l, d), this.setData({
                disableSetDuration: !1,
                "endTime.day": r,
                "endTime.hour": u,
                "endTime.minute": l,
                "endTimeConfig.indexVal": [ s, o, d ]
            });
        },
        resetPickerPosition: function(t, e) {
            for (var a = this.data.startTimeConfig, i = a.hourSize, n = void 0 === i ? 240 : i, s = a.minuteSize, o = void 0 === s ? 600 : s, d = Math.floor(n / 2), r = Math.floor(o / 2); d % 24 != t % 24; ) d += 1;
            for (;r % 60 != e % 60; ) r += 1;
            this.setData({
                "startTimeConfig.indexVal": [ d, r ]
            });
        },
        oneDayPickerchange: function(t) {
            var e = t.detail, a = (void 0 === e ? {} : e).value, i = void 0 === a ? [] : a, n = i[0] || 0, s = i[1] || 0, o = this.data.lastTime, d = o.hour, r = o.minute, m = this.data.lastTimeConfig.oneDay.minuteSet;
            0 === n ? 0 !== d && (s = -1 === (s = (m = [ 15, 30, 45 ]).findIndex(function(t) {
                return t === r;
            })) ? 0 : s) : n < 24 ? 0 !== d && 24 !== d || (s = -1 === (s = (m = [ 0, 15, 30, 45 ]).findIndex(function(t) {
                return t === r;
            })) ? 0 : s) : 24 !== d && (s = -1 === (s = (m = [ 0 ]).findIndex(function(t) {
                return t === r;
            })) ? 0 : s), m !== this.data.lastTimeConfig.oneDay.minuteSet && this.setData({
                "lastTimeConfig.oneDay.minuteSet": m
            }), this.setData({
                disableSetDuration: !1,
                "lastTime.hour": n,
                "lastTime.minute": m[s],
                "lastTimeConfig.oneDay.indexVal": [ n, s ]
            });
        },
        oneDayPickerEnd: function() {
            var e = t(this.data.lastTimeConfig.oneDay.indexVal, 2), a = e[0], i = e[1];
            this.setData({
                "lastTimeConfig.oneDay.indexVal": [ a, i ]
            });
        },
        setEndDate: function(t) {
            var a, i = e(this.startTimeStamp).add(t, "days");
            a = e(this.startTimeStamp).year() !== i.year() ? i.format("YYYY年MM月DD日") : i.format("MM月DD日"), 
            this.setData({
                endDateString: a,
                endDateConfig: {
                    year: i.year(),
                    month: i.month() + 1,
                    day: i.date(),
                    timestamp: i.millisecond()
                }
            });
        },
        allDayPickerchange: function(e) {
            var a = e.detail, i = (void 0 === a ? {} : a).value, n = t(void 0 === i ? [] : i, 1)[0], s = void 0 === n ? 0 : n;
            this.setEndDate(s);
            var o = s + 1;
            this.setData({
                "lastTime.day": o
            });
        },
        calendarDateChange: function(t) {
            var a = t.detail, i = (void 0 === a ? {} : a).selectDate, n = void 0 === i ? {} : i, s = n.day, o = n.month, d = n.year, r = this.data, m = r.lastTime, h = void 0 === m ? {} : m, u = r.startTime;
            if (this.setData({
                "startTime.year": d,
                "startTime.month": o,
                "startTime.day": s
            }), !this.data.allDayChecked) {
                var c = h.hour, l = h.minute, T = e("".concat(d, "-").concat(o, "-").concat(s, " ").concat(u.hour || 0, ":").concat(u.minute || 0)).add(c, "hour").add(l, "minute").get("date");
                this.setData({
                    "endTime.year": d,
                    "endTime.month": o,
                    "endTime.day": T
                });
            }
        },
        lastdayChange: function(t) {
            var e = t.detail.day, a = void 0 === e ? 0 : e;
            this.setData({
                "lastTime.day": a
            }), this.setEndDate(a - 1);
        },
        daySwitchChange: function() {
            var t = !this.data.allDayChecked;
            this.setData({
                allDayChecked: t
            }), this.setEndDate(this.data.lastTime.day - 1), !0 === t && this.data.timeChecked && this.setData({
                timeChecked: !1,
                endTimeChecked: !1,
                monthChecked: !0
            });
        },
        handleMonthClick: function() {
            this.setData({
                timeChecked: !1,
                endTimeChecked: !1,
                lastTimeChecked: !1,
                monthChecked: !this.data.monthChecked
            });
        },
        handleTimeClick: function() {
            this.setData({
                monthChecked: !1,
                lastTimeChecked: !1,
                timeChecked: !this.data.timeChecked,
                endTimeChecked: !1
            });
        },
        handleEndTimeClick: function() {
            this.setData({
                monthChecked: !1,
                lastTimeChecked: !1,
                timeChecked: !1,
                endTimeChecked: !this.data.endTimeChecked
            });
        },
        handleDurationClick: function() {
            this.setData({
                monthChecked: !1,
                timeChecked: !1,
                endTimeChecked: !1,
                lastTimeChecked: !this.data.lastTimeChecked
            });
        },
        handlecancel: function(t) {
            this.triggerEvent("cancel", t);
        },
        handleConfirm: function() {
            var t = {
                allday: this.data.allDayChecked,
                startTimeData: this.data.startTime,
                lastTimeData: this.data.lastTime
            };
            this.triggerEvent("confirm", t);
        }
    },
    observers: {
        "startTime.year, startTime.month, startTime.day": function() {
            var t, a = this.data.startTime, i = a.month, n = a.day, s = a.hour, o = a.minute, d = this.data.startTime.year, r = new Date().getFullYear(), m = new Date(d, i - 1, n, s, o).getTime(), h = e(m);
            t = "".concat(r === d ? h.format("MM月DD日") : h.format("YYYY/MM/DD")), this.setData({
                startDateString: t
            }), console.log("======777777=====", this.data), this.startTimeStamp = m, this.data.allDayChecked && this.setEndDate(this.data.lastTime.day - 1), 
            this.setLastPickerDay(m);
        },
        "startTime.hour, startTime.minute": function() {
            var t = this.data.firstCount;
            this.setData({
                firstCount: t + 1
            });
            var e = this.data.startTime, a = e.hour, i = e.minute, n = this.data.endTime, s = n.day, o = n.hour, d = n.minute;
            console.log("startTimeString-startTime", this.data.startTime, this.data.endTime), 
            0 === s && 0 === o && 0 === d ? this.setEndHoursArrToday(a) : (this.setEndTimePicker(), 
            this.setEndHoursArrToday(a), this.setEndHourAndMinute()), a = a < 10 ? "0".concat(a) : "".concat(a), 
            i = i < 10 ? "0".concat(i) : "".concat(i), this.setData({
                startTimeString: "".concat(a, ":").concat(i)
            });
        },
        "endTime.day, endTime.hour, endTime.minute": function() {
            var t = this.data.endTime, e = t.day, a = t.hour, i = t.minute, n = this.data.startTime, s = n.day, o = n.hour, d = n.minute, r = this.data.lastTime, m = r.hour, h = r.minute;
            if (console.log("this.data.endTime", this.data.startTime, this.data.endTime), e = e === s ? "当天" : "隔天", 
            !this.data.disableSetDuration) {
                var u = a - o, c = i - d;
                if (m !== u || h !== c) {
                    if ("当天" === e) {
                        if (i - d < 0) if (c = i - d + 60, (u -= 1) < 0) u = 0, c = this.data.endTimeConfig.minuteSet[i] - d + 60;
                    } else u = a + 24 - o, i - d < 0 && (u -= 1, c = i - d + 60);
                    this.setData({
                        "lastTime.hour": u,
                        "lastTime.minute": c
                    });
                }
            }
            a = a < 10 ? "0".concat(a) : "".concat(a), i = i < 10 ? "0".concat(i) : "".concat(i), 
            this.setData({
                endTimeString: "".concat(e, " ").concat(a, ":").concat(i)
            });
        },
        "endTimeConfig.minuteSet": function() {
            var t = this.data.endTimeConfig.minuteSet;
            this.setData({
                "endTimeConfig.minutes": t
            });
        },
        "allDayChecked, lastTime.day, lastTime.hour, lastTime.minute": function() {
            var t = this.data.allDayChecked, e = this.data.lastTime, a = e.day, i = e.hour, n = e.minute;
            if (console.log("======88888======", this.data.lastTime), t) this.setData({
                lastTimeString: "".concat(a, "天")
            }); else {
                if (i < 24) {
                    var s = 0 === i ? "" : "".concat(i, "小时"), o = 0 === n ? "" : "".concat(n, "分钟");
                    this.setData({
                        lastTimeString: "".concat(s).concat(o)
                    });
                } else this.setData({
                    lastTimeString: "1天"
                });
                this.data.disableSetDuration || this.setEndTimePicker();
            }
        },
        "lastTimeConfig.oneDay.minuteSet": function() {
            var t = this.data.lastTimeConfig.oneDay.minuteSet.map(function(t) {
                return "".concat(t, "分钟");
            });
            this.setData({
                "lastTimeConfig.oneDay.minutes": t
            });
        },
        show: function(t) {
            var e = this.properties, a = e.allday, i = e.startTimeData, n = void 0 === i ? {} : i, s = e.endTimeData, o = void 0 === s ? {} : s, d = e.lastTimeData, r = void 0 === d ? {} : d, m = e.unfold, h = void 0 === m ? "" : m;
            if (!0 === t) {
                var u, c = r.hour;
                u = 0 === c ? [ 15, 30, 45 ] : 24 === c ? [ 0 ] : [ 0, 15, 30, 45 ], this.setData({
                    allDayChecked: a,
                    "lastTimeConfig.oneDay.minuteSet": u,
                    startTime: Object.assign(this.data.startTime, n),
                    endTime: Object.assign(this.data.endTime, o),
                    lastTime: Object.assign(this.data.lastTime, r),
                    startDateConfig: Object.assign(this.data.startDateConfig, n),
                    monthChecked: "month" === h,
                    timeChecked: "time" === h && !a,
                    lastTimeChecked: "last" === h,
                    endTimeChecked: "endTime" === h && !a
                });
            } else this.setData({
                monthChecked: !1,
                timeChecked: !1,
                endTimeChecked: !1,
                lastTimeChecked: !1
            });
        },
        timeChecked: function(t) {
            if (!1 === t) return !1;
            var e = this.data.startTime, a = e.hour, i = e.minute, n = this.data.startTimeConfig.minuteList.findIndex(function(t) {
                return t === i;
            });
            this.setData({
                "startTimeConfig.indexVal": [ a + 120, n + 200 ]
            });
        },
        endTimeChecked: function(t) {
            if (!1 === t) return !1;
            this.setEndHourAndMinute();
        },
        "lastTimeChecked, allDayChecked": function(t) {
            var e = this;
            if (!1 === t) return !1;
            var a = this.data.allDayChecked, i = this.data.lastTime, n = i.day, s = i.hour, o = i.minute;
            if (a) this.setData({
                "lastTimeConfig.allDay.indexVal": [ n - 1 ]
            }); else {
                var d, r = this.data.lastTimeConfig.oneDay.minuteSet;
                d = -1 === (d = r.findIndex(function(t) {
                    return t === o;
                })) ? 0 : d, this.setData({
                    "lastTimeConfig.oneDay.minuteSet": r,
                    "lastTimeConfig.oneDay.indexVal": [ s, d ]
                }), Promise.resolve().then(function() {
                    e.setData({
                        "lastTimeConfig.oneDay.indexVal": [ s, d ]
                    });
                });
            }
        }
    }
});