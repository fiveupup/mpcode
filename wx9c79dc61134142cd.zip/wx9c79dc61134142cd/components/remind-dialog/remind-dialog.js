Component({
    properties: {
        show: {
            type: Boolean,
            value: !1
        },
        selectStartItems: {
            type: Array,
            value: []
        },
        selectEndItems: {
            type: Array,
            value: []
        },
        showBeforeEndItem: {
            type: Boolean,
            value: !1
        },
        beforeEndRemindStr: {
            type: String,
            value: ""
        },
        allday: {
            type: Boolean,
            value: !1
        },
        startTime: {
            type: Number,
            value: 0
        },
        endTime: {
            type: Number,
            value: 0
        }
    },
    data: {
        canConfirm: !1,
        isScroll: !0
    },
    options: {
        addGlobalClass: !0
    },
    observers: {
        show: function(t) {
            t && this.setData({
                canConfirm: !1
            });
        }
    },
    methods: {
        prevent: function() {},
        hide: function() {
            this.setData({
                show: !1
            });
        },
        cancel: function() {
            this.data.show && (this.triggerEvent("cancel"), this.hide());
        },
        confirm: function() {
            this.data.show && this.data.canConfirm && (this.triggerEvent("confirm"), this.hide());
        },
        custiomRemindTimeDialogStatusChange: function(t) {
            var e = t.detail, i = (void 0 === e ? {} : e).status, a = void 0 !== i && i;
            this.setData({
                isScroll: !a
            });
        },
        beforeStartRemindItemClick: function(t) {
            var e = t.detail, i = void 0 === e ? {} : e;
            this.setData({
                canConfirm: !0
            }), this.triggerEvent("beforeStartRemindItemClick", i);
        },
        beforeEndRemindItemClick: function(t) {
            var e = t.detail, i = void 0 === e ? {} : e;
            this.setData({
                canConfirm: !0
            }), this.triggerEvent("beforeEndRemindItemClick", i);
        }
    }
});