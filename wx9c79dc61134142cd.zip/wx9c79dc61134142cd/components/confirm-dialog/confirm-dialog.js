Component({
    options: {
        multipleSlots: !0
    },
    properties: {
        title: {
            type: String,
            value: ""
        },
        content: {
            type: String,
            value: "弹窗内容"
        },
        cancelText: {
            type: String,
            value: "取消"
        },
        confirmText: {
            type: String,
            value: "确定"
        },
        confirmColor: {
            type: String,
            value: "#F66454"
        }
    },
    data: {
        isShow: !1
    },
    methods: {
        hideDialog: function() {
            this.setData({
                isShow: !1
            });
        },
        showDialog: function() {
            this.setData({
                isShow: !0
            });
        },
        _cancelEvent: function() {
            this.triggerEvent("cancelEvent");
        },
        _confirmEvent: function() {
            this.triggerEvent("confirmEvent");
        }
    }
});