Component({
    properties: {
        list: {
            type: Object
        },
        selectValue: {
            type: Array
        }
    },
    attached: function() {},
    data: {},
    options: {},
    externalClasses: [ "custom-class" ],
    methods: {
        timePickerchange: function(e) {
            var t = e.detail, i = (void 0 === t ? {} : t).value, a = void 0 === i ? [] : i;
            this.triggerEvent("timePickerchange", a);
        }
    }
});