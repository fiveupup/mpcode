require("../../@babel/runtime/helpers/Arrayincludes");

var e = require("@tencent/wecalendar-web-business-plugins").util, t = e.getDefaultDateInfo, s = e.getCustomRrule, a = {}, o = 1;

Component({
    properties: {
        showCustomRecur: {
            type: Boolean,
            value: !1
        },
        startTime: {
            type: Number,
            value: 0
        },
        customRrule: {
            type: String,
            value: ""
        },
        customRruleDesc: {
            type: String,
            value: ""
        }
    },
    data: {
        height: 36,
        defaultCounts: [ 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12 ],
        counts: [ 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12 ],
        dayCounts: [],
        types: [ {
            text: "天",
            type: "day"
        }, {
            text: "周",
            type: "week"
        }, {
            text: "月",
            type: "month"
        } ],
        weekItems: [ {
            text: "周一",
            type: "MO"
        }, {
            text: "周二",
            type: "TU"
        }, {
            text: "周三",
            type: "WE"
        }, {
            text: "周四",
            type: "TH"
        }, {
            text: "周五",
            type: "FR"
        }, {
            text: "周六",
            type: "SA"
        }, {
            text: "周日",
            type: "SU"
        } ],
        showWeekItems: !0,
        monthItems: [],
        showMonthItems: !1,
        pickerValue: [ 0, 0, 1 ]
    },
    options: {
        addGlobalClass: !0
    },
    methods: {
        prevent: function() {},
        hide: function() {
            this.setData({
                show: !1
            });
        },
        cancel: function() {
            this.data.showCustomRecur && (this.triggerEvent("cancel"), this.hide());
        },
        getCustomRecurData: function() {
            var e = this.data.pickerValue[2], t = this.data.types[e].type, i = "";
            if ("day" === t && (i = s(t, o)), "week" === t) {
                var c = a.week, u = this.data.weekItems, n = [];
                u.forEach(function(e) {
                    e.selected && n.push(e.type);
                }), i = s(t, o, c.key, n);
            }
            if ("month" === t) {
                var r = this.data.monthItems, h = [], l = "";
                r.forEach(function(e) {
                    e.selected && (l = e.key, h.push(e.options[0]));
                }), i = s(t, o, l, h);
            }
            var m = this.data.customRruleDesc.replace(/重复/g, "").trim();
            this.triggerEvent("customrecursave", {
                rrule: i,
                rruleDesc: m,
                pickerValue: this.data.pickerValue
            });
        },
        bindChange: function(e) {
            var t = e.detail.value, s = t[2], a = this.data.types[s].type, i = [];
            if ("day" === a) {
                var c = this.data.dayCounts;
                if (0 === c.length) {
                    for (var u = [], n = 1; n < 100; n++) u.push(n);
                    o = u[t[1]], this.setData({
                        counts: u,
                        dayCounts: u
                    });
                } else o = c[t[1]], this.setData({
                    counts: c
                });
                this.setData({
                    showWeekItems: !1,
                    showMonthItems: !1
                });
            }
            if ("week" === a) {
                var r = this.data, h = r.defaultCounts, l = r.weekItems;
                o = h[t[1]], this.setData({
                    showWeekItems: !0,
                    showMonthItems: !1,
                    counts: h
                }), l.forEach(function(e) {
                    e.selected && i.push(e.text);
                });
            }
            if ("month" === a && (o = this.data.defaultCounts[t[1]], this.setData({
                showWeekItems: !1,
                showMonthItems: !0,
                counts: this.data.defaultCounts
            }), this.data.monthItems.forEach(function(e) {
                e.selected && i.push(e.text);
            })), void 0 !== o) {
                var m = this.getCustomRruleDesc(a, o, i);
                this.setData({
                    customRruleDesc: m,
                    pickerValue: t
                });
            } else {
                o = 1;
                var d = this.getCustomRruleDesc(a, o, i);
                this.setData({
                    customRruleDesc: d,
                    pickerValue: [ 0, 0, t[2] ]
                });
            }
        },
        clickweekitem: function(e) {
            var t = e.currentTarget.dataset.index, s = this.data.weekItems, a = [], i = s.filter(function(e) {
                return e.selected;
            });
            s.forEach(function(e) {
                if (e.type === t) {
                    if (e.selected && 1 === i.length) return void a.push(e.text);
                    e.selected = !e.selected;
                }
                e.selected && a.push(e.text);
            });
            var c = this.getCustomRruleDesc("week", o, a);
            this.setData({
                weekItems: s,
                customRruleDesc: c
            });
        },
        clickmonthitem: function(e) {
            var t = e.currentTarget.dataset.index, s = this.data.monthItems, a = [];
            s.forEach(function(e) {
                e.key === t ? (a.push(e.text), e.selected = !e.selected) : e.selected = !1;
            });
            var i = this.getCustomRruleDesc("month", o, a);
            this.setData({
                monthItems: s,
                customRruleDesc: i
            });
        },
        getCustomRruleDesc: function(e, t) {
            for (var s = "", a = arguments.length, o = new Array(a > 2 ? a - 2 : 0), i = 2; i < a; i++) o[i - 2] = arguments[i];
            switch (e) {
              case "day":
                s = "每".concat(t, "天 重复"), 1 === t && (s = "每天 重复");
                break;

              case "week":
                s = "每".concat(t, "周的").concat(o.join(","), " 重复"), 1 === t && (s = "每周的".concat(o.join(","), " 重复"));
                break;

              case "month":
                s = "每".concat(t, "个月的").concat(o.join(","), " 重复"), 1 === t && (s = "每个月的".concat(o.join(","), " 重复"));
            }
            return s = s.replace(/,/g, "、");
        },
        initTime: function(e) {
            var s = a = t(e), i = s.month, c = s.week, u = this.data.weekItems;
            u.forEach(function(e) {
                e.text === c.text ? e.selected = !0 : e.selected = !1;
            });
            var n = i;
            n.forEach(function(e) {
                "BYMONTHDAY" === e.key ? e.selected = !0 : e.selected = !1;
            }), 1 !== o && (o = 1);
            var r = this.getCustomRruleDesc("week", o, [ c.text ]);
            this.setData({
                weekItems: u,
                monthItems: n,
                customRruleDesc: r,
                pickerValue: [ 0, o - 1, 1 ],
                showWeekItems: !0,
                showMonthItems: !1
            });
        }
    },
    observers: {
        showCustomRecur: function() {
            var e = this.data, t = e.showCustomRecur, s = e.startTime, a = e.weekItems, i = e.monthItems;
            if (t) {
                var c = this.data.customRrule;
                if ("" !== c) {
                    var u = c.split(";"), n = u[1].split("=");
                    if (o = parseInt(n[1]), c.includes("DAILY")) {
                        var r = this.getCustomRruleDesc("day", o);
                        this.setData({
                            counts: this.data.dayCounts,
                            pickerValue: [ 0, o - 1, 0 ],
                            customRruleDesc: r,
                            showWeekItems: !1,
                            showMonthItems: !1
                        });
                    }
                    if (c.includes("WEEKLY")) {
                        for (var h = u[2].split("=")[1], l = [], m = 0; m < a.length; m++) {
                            var d = a[m];
                            d.selected = h.indexOf(d.type) >= 0, d.selected && l.push(d.text);
                        }
                        var p = this.getCustomRruleDesc("week", o, l);
                        this.setData({
                            weekItems: a,
                            pickerValue: [ 0, o - 1, 1 ],
                            customRruleDesc: p,
                            showWeekItems: !0,
                            showMonthItems: !1
                        });
                    }
                    if (c.includes("MONTHLY")) {
                        for (var f = u[2].split("=")[0], k = [], w = 0; w < i.length; w++) {
                            var v = i[w];
                            v.selected = f === v.key, v.selected && k.push(v.text);
                        }
                        var D = this.getCustomRruleDesc("month", o, k);
                        this.setData({
                            monthItems: i,
                            pickerValue: [ 0, o - 1, 2 ],
                            customRruleDesc: D,
                            showWeekItems: !1,
                            showMonthItems: !0
                        });
                    }
                } else s && this.initTime(s);
            }
        },
        startTime: function(e) {
            console.log("startTime newVal:", e), this.initTime(e);
        }
    }
});