var t = require("../../utils/util"), e = t.getValueFromLocalStorage, a = t.setValueInLocalStorage;

Component({
    data: {
        showTips: !1,
        guildButton: [ {
            type: "default",
            className: "guild-tips-btn",
            text: "我知道了",
            value: 0
        } ]
    },
    attached: function() {
        var t = this;
        e("ACOUNT_TIPS") || setTimeout(function() {
            t.setData({
                showTips: !0
            });
        }, 100);
    },
    methods: {
        bindclose: function() {
            a("ACOUNT_TIPS", 1);
        },
        buttontap: function() {
            a("ACOUNT_TIPS", 1), this.setData({
                showTips: !1
            });
        }
    }
});