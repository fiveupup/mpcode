require("../../@babel/runtime/helpers/Objectvalues");

var a = require("../../utils/beacon/report_data"), e = require("../../sdk/logger/calendar_logger"), t = require("../../utils/util"), n = require("../../configs/AppConfig"), c = "calendar_drawer.js";

Component({
    properties: {
        open: {
            type: Boolean,
            value: !1
        },
        drawerInfo: Object,
        hadFocusOfficialAccounts: Object,
        groupCalendarList: Array
    },
    data: {
        isRegister: !0,
        calendarList: [],
        headIcon: "https://cdn.calendar.tencent.com/calendar_res/mpCalendar/avatar_not_login.png",
        nickName: "未登录",
        phoneNum: "",
        showFocusPublicAccount: !1,
        showCalendarList: !0,
        animationTime: 0
    },
    methods: {
        openDrawer: function() {
            this.setData({
                open: !0
            }), this.cachedSelectState(), a.dataReport("e#main#sidebar#click", {}), !0 === this.data.showFocusPublicAccount && a.dataReport("e#main#sidebar_follow_guidance#explore", {});
            var e = t.getValueFromLocalStorage("show_calendar_list");
            "" === e ? t.setValueInLocalStorage("show_calendar_list", !0) : this.setData({
                showCalendarList: e
            });
        },
        cachedSelectState: function() {
            var a = {};
            Object.values(this.data.calendarList).forEach(function(e) {
                e && Object.values(e.accountCalList).forEach(function(e) {
                    a[e.calendarId] = e.isSelect;
                });
            }), e.info("cachedSelectState: ".concat(JSON.stringify(a)), c), this.cacheSelectState = a;
        },
        isSelectStateChanged: function() {
            var a = this, t = {};
            Object.values(this.data.calendarList).forEach(function(a) {
                a && Object.values(a.accountCalList).forEach(function(a) {
                    t[a.calendarId] = a.isSelect;
                });
            }), e.info("newState: ".concat(JSON.stringify(t)), c);
            var n = !1;
            return Object.keys(t).forEach(function(e) {
                t[e] !== a.cacheSelectState[e] && (n = !0);
            }), e.info("select state changed: ".concat(n), c), n;
        },
        onMaskTab: function() {
            this.setData({
                open: !1
            }), this.triggerEvent("HideDrawer", {
                selectStateChanged: this.isSelectStateChanged()
            });
        },
        onCalendarItemTab: function(a) {
            var t = a.currentTarget.dataset, n = t.groupIndex, i = t.childIndex;
            e.info("onCalendarItemTab: ".concat(n, ", ").concat(i), c);
            var o = this.data.calendarList[n].accountCalList[i], r = {
                corpId: o.corpId,
                calendarId: o.calendarId,
                calendarUid: o.calendarUid,
                isSelect: o.isSelect,
                calType: o.calType
            };
            e.info("onCalendarItemTab payload: ".concat(JSON.stringify(r)), c), this.triggerEvent("CalendarItemTab", r);
            var s = this.data.calendarList[n] && this.data.calendarList[n].accountCalList[i], l = s.isSelect;
            s.isSelect = !l, this.setData({
                calendarList: this.data.calendarList
            });
        },
        onShareCalendar: function(a) {
            console.log("share current calendar", a);
            var e = a.currentTarget.dataset, t = e.groupIndex, n = e.childIndex, c = this.data.calendarList[t] && this.data.calendarList[t].accountCalList[n];
            this.triggerEvent("ShowShareDialog", c);
        },
        setCalendarItemSelectState: function(a, t) {
            e.info("setCalendarItemSelectState with calendarId: ".concat(a, ", isSelect: ").concat(t), c), 
            Object.values(this.data.calendarList).forEach(function(n) {
                var i = n.accountCalList;
                Object.values(i).forEach(function(n) {
                    n.calendarId === a && (e.info("change select state of calendarInfo: ".concat(JSON.stringify(n)), c), 
                    n.isSelect = t);
                });
            }), this.setData({
                calendarList: this.data.calendarList
            });
        },
        onClickAccountProfile: function() {
            a.dataReport("e#main#personal_center#click", {}), wx.navigateTo({
                url: "/accountinfo/accountinfo"
            });
        },
        onClickManageCalendar: function() {
            wx.navigateTo({
                url: "/SettingPages/pages/SettingCalendarManageNew/index"
            });
        },
        gotoCreateCalendar: function() {
            wx.navigateTo({
                url: "/SettingPages/pages/SettingCalendarCreate/index"
            });
        },
        onClickSetting: function() {
            a.dataReport("e#main#setting#click", {}), wx.navigateTo({
                url: "/setting/setting"
            });
        },
        onClickAuth: function() {
            this.triggerEvent("AuthTab", {});
        },
        goToPublicAccount: function() {
            a.dataReport("e#main#sidebar_follow_guidance_follow#click", {});
            var e = n.DEFAULT_ENV_KEY, c = t.getQueryString({
                url: "production" === e ? n.PublicHome : n.PublicHomeTest
            });
            wx.navigateTo({
                url: "../sub-web/web/web".concat(c)
            });
        },
        gotoFeedback: function() {
            wx.navigateTo({
                url: "/feedback/feedback"
            });
        }
    },
    observers: {
        drawerInfo: function(a) {
            e.info("drawerInfo: ".concat(JSON.stringify(a)), c), void 0 !== a.isRegister && this.setData({
                isRegister: a.isRegister
            }), a.headIcon && this.setData({
                headIcon: a.headIcon
            }), a.nickName && this.setData({
                nickName: t.formatNickName(a.nickName, 24)
            }), a.phoneNum ? this.setData({
                phoneNum: a.phoneNum
            }) : this.setData({
                phoneNum: "未绑定手机号"
            });
        },
        groupCalendarList: function(a) {
            console.log("groupCalendarList newVal:", a), a && a.length && this.setData({
                calendarList: a
            });
        },
        hadFocusOfficialAccounts: function(a) {
            e.info("hadFocusOfficialAccounts: ".concat(JSON.stringify(a)), c), this.setData({
                showFocusPublicAccount: !a.focus
            });
        }
    }
});