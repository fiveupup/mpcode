var e = require("../../@babel/runtime/helpers/slicedToArray"), a = require("../../@babel/runtime/helpers/toConsumableArray"), i = require("../../utils/Dayjs.js"), n = require("../../utils/remindTimeUtil").remindTimeFormat, t = {
    ALL_DAY_EVENT_DAY_SYSTEM: [ "天", "周" ],
    ALL_DAY_EVENT_TIME_SYSTEM: [ "上午", "下午" ],
    DAY_SYSTEM_INDEX: 1,
    TIME_SYSTEM_INDEX: 0,
    DAY_SYSTEM_MULTIPLE: [ 1, 7 ],
    TIME_SYSTEM_MULTIPLE: [ 1, 2 ]
}, l = function(e, a, i) {
    for (var n = [], t = e; t < a; t++) t < 10 && i ? n.push("0".concat(t)) : n.push(t);
    return n;
}, m = [ {
    key: "day",
    value: a(Array(31).keys()),
    unit: "天"
}, {
    key: "hour",
    value: l(0, 24, !0),
    unit: "时"
}, {
    key: "minute",
    value: l(0, 60, !0),
    unit: "分"
} ], r = [ [ {
    key: "day",
    value: a(Array(31).keys())
}, {
    key: "daySystem",
    value: t.ALL_DAY_EVENT_DAY_SYSTEM
} ], [ {
    key: "week",
    value: a(Array(5).keys())
}, {
    key: "daySystem",
    value: t.ALL_DAY_EVENT_DAY_SYSTEM
} ] ], d = [ [ {
    key: "timeSystem",
    value: t.ALL_DAY_EVENT_TIME_SYSTEM
}, {
    key: "hourAM",
    value: l(0, 13, !0)
}, {
    key: "minuteAM",
    value: l(0, 60, !0)
} ], [ {
    key: "timeSystem",
    value: t.ALL_DAY_EVENT_TIME_SYSTEM
}, {
    key: "hourPM",
    value: l(1, 12, !0)
}, {
    key: "minutePM",
    value: l(0, 60, !0)
} ] ];

Component({
    properties: {
        show: {
            type: Boolean,
            value: !1
        },
        allday: {
            type: Boolean,
            value: !1
        },
        baseTime: {
            type: Date,
            value: 0
        },
        type: {
            type: Number,
            value: 0
        },
        showExpiredTips: {
            type: Boolean,
            value: !0
        }
    },
    attached: function() {},
    data: {
        normalEventRemindTimeList: m,
        alldayEventRemindDayList: r,
        alldayEventRemindTimeList: d,
        normalEventRemindTimeIndexVal: [ 0, 0, 0 ],
        allDayEventRemindDayIndexVal: [ 0, 0 ],
        allDayEventRemindTimeIndexVal: [ 0, 0, 0 ],
        showAllDayEventRemindDayTimePicker: !0,
        showAllDayEventRemindTimePicker: !1,
        allDayEventRemindDayString: "",
        allDayEventRemindTimeString: "",
        normalEventRemindTimeString: "",
        isExpired: !1
    },
    observers: {
        baseTime: function() {
            if (this.data.allday) {
                var e = this.data, a = e.allDayEventRemindDayIndexVal, i = e.allDayEventRemindTimeIndexVal;
                this.allDayEventRemindDayPickerChange({
                    detail: a
                }), this.allDayEventRemindTimePickerChange({
                    detail: i
                });
            } else {
                var n = this.data.normalEventRemindTimeIndexVal;
                this.normalEventRemindTimePickerChange({
                    detail: n
                });
            }
        }
    },
    options: {},
    methods: {
        prevent: function() {},
        reset: function() {
            this.setData({
                normalEventRemindTimeIndexVal: [ 0, 0, 0 ],
                allDayEventRemindDayIndexVal: [ 0, 0 ],
                allDayEventRemindTimeIndexVal: [ 0, 0, 0 ],
                showAllDayEventRemindDayTimePicker: !0,
                showAllDayEventRemindTimePicker: !1,
                allDayEventRemindDayString: "",
                allDayEventRemindTimeString: "",
                normalEventRemindTimeString: "",
                isExpired: !1
            });
        },
        normalEventRemindTimePickerChange: function(a) {
            var n = a.detail, t = void 0 === n ? {} : n, l = e(t || [], 3), m = l[0], r = l[1], d = l[2], y = this.data.baseTime, E = i(y).subtract(m, "day").subtract(r, "hour").subtract(d, "minute"), s = "MM-DD HH:mm:ss";
            E.year() !== i().year() && (s = "YYYY-".concat(s)), this.setData({
                isExpired: E.isBefore(i()),
                normalEventRemindTimeString: E.format(s),
                normalEventRemindTimeIndexVal: t
            });
        },
        allDayEventRemindDayPickerChange: function(e) {
            var a = e.detail, i = void 0 === a ? [] : a, n = i && i[t.DAY_SYSTEM_INDEX], l = t.ALL_DAY_EVENT_DAY_SYSTEM[n], m = this.data.allDayEventRemindDayIndexVal && this.data.allDayEventRemindDayIndexVal[n], r = [].concat(i);
            n !== m && (r[0] = 0), this.setData({
                allDayEventRemindDayIndexVal: r,
                allDayEventRemindDayString: "".concat(r[0]).concat(l)
            });
        },
        handleDayClick: function() {
            this.setData({
                showAllDayEventRemindDayTimePicker: !0,
                showAllDayEventRemindTimePicker: !1
            });
        },
        handleTimeClick: function() {
            this.setData({
                showAllDayEventRemindTimePicker: !0,
                showAllDayEventRemindDayTimePicker: !1
            });
        },
        allDayEventRemindTimePickerChange: function(a) {
            var i = a.detail, n = void 0 === i ? [] : i, l = e(n || [], 1)[0], m = e(n || [], 3), r = m[1], d = m[2], y = e(this.data.allDayEventRemindTimeIndexVal, 1)[0], E = [].concat(n);
            l !== y && (E[1] = 0, E[2] = 0), 1 === l && (r = E[1] + 1), d < 10 && (d = "0".concat(d)), 
            this.setData({
                allDayEventRemindTimeIndexVal: E,
                allDayEventRemindTimeString: "".concat(t.ALL_DAY_EVENT_TIME_SYSTEM[l]).concat(r, ":").concat(d)
            });
        },
        handlecancel: function(e) {
            this.reset(), this.triggerEvent("cancel", e);
        },
        handleConfirm: function() {
            var a, l = this.properties || {}, m = l.allday, r = l.baseTime, d = l.type, y = "", E = "";
            if (m) {
                var s = this.data, v = s.allDayEventRemindDayIndexVal, D = s.allDayEventRemindTimeIndexVal, o = e(v || [], 2), T = o[0], u = o[1], c = t.DAY_SYSTEM_MULTIPLE[u], h = e(D || [], 3), _ = h[0], R = h[2], S = e(D || [], 2)[1], A = T * c;
                1 === _ && (S += 13);
                var Y = S, k = i(r).subtract(A, "day").hour(Y).minute(R);
                E = i(r).diff(k, "minute"), y = n(r, E, m);
            } else {
                var I = this.data.normalEventRemindTimeIndexVal, M = e(I || [], 3), V = M[0], p = M[1], L = M[2], f = i(r).subtract(V, "day").subtract(p, "hour").subtract(L, "minute");
                E = i(r).diff(f, "minute"), y = n(r, E, m, 0 === d);
            }
            a = {
                type: "ADD_OPTION",
                newOption: {
                    text: y,
                    isSelect: !0,
                    value: E
                }
            }, this.triggerEvent("confirm", a), this.reset();
        }
    }
});