var t = require("../../@babel/runtime/helpers/objectSpread2"), e = require("../../sdk/logger/calendar_logger");

Component({
    properties: {
        containerHeight: Number,
        containerTop: Number,
        dayList: Array,
        eventArr: Array,
        calUidList: Array,
        newEventId: String,
        loading: Boolean
    },
    data: {
        dataListArray: [],
        swiperPosition: 1,
        swiperDuration: 100,
        eventId: "",
        userScrollDraged: !1
    },
    methods: {
        formatNumber: function(t) {
            return t > 9 ? t : "0".concat(t);
        },
        updateDataListArray: function() {
            if (e.info("updateDataListArray ".concat(this.data.newEventId, " ").concat(this.newEventId), "event-list-mode.js"), 
            "" !== this.data.newEventId && this.data.newEventId !== this.newEventId) return this.setData({
                dataListArray: this.buildDataListArray(),
                swiperPosition: 1,
                swiperDuration: 100,
                eventId: this.data.newEventId
            }), void (this.newEventId = this.data.newEventId);
            this.setData({
                dataListArray: this.buildDataListArray(),
                swiperPosition: 1,
                swiperDuration: 100,
                eventId: ""
            });
        },
        buildDataListArray: function() {
            var e = new Date(), r = e.getTime(), i = [], a = this.builDataArr();
            console.log("builDataArr", a);
            for (var s = 0; s < a.length; s++) {
                for (var n = a[s], o = this.data.dayList[s], l = [], u = [], d = [], h = [], c = [], g = new Date(o.year, o.month - 1, o.day), v = g.getFullYear() === e.getFullYear() && g.getMonth() === e.getMonth() && g.getDate() === e.getDate(), m = 0; m < n.length; m++) {
                    var T, p = n[m], f = r > p.event.endTime, D = p.startTimeObj.times - (3600 * e.getHours() + 60 * e.getMinutes() + e.getSeconds()) <= 900, w = null === (T = p.event.meetingInfo) || void 0 === T ? void 0 : T.meetingCode, b = 4 === p.event.calType, S = p.event, y = S.responseStatus, A = S.role, L = S.isAllDay, j = 2 === y, O = 4 === y || 0 === y && 2 === A, E = v && w && D && !f, I = !E && w, C = b, M = -1 === this.data.calUidList.indexOf(p.event.creatorUid), P = this.formatNumber(p.startTimeObj.hours), H = this.formatNumber(p.startTimeObj.minutes), N = this.formatNumber(p.endTimeObj.hours), x = this.formatNumber(p.endTimeObj.minutes), F = "".concat(P, ":").concat(H), k = "".concat(N, ":").concat(x), J = L ? "全天" : "".concat(F, "-").concat(k), Y = "400";
                    p.event.isPeriod && M && I ? Y = "250" : (p.event.isPeriod && M || p.event.isPeriod && I || M) && (Y = "300");
                    var U = {
                        isReject: j,
                        isPending: O,
                        showJoinBtn: E,
                        showMeetingLogo: I,
                        showShareLogo: C,
                        showCreator: M,
                        time: J,
                        isOverTime: f,
                        address: p.event.location.address,
                        timeMaxWidth: Y
                    };
                    p.event.isAllDay ? (U.showHoursTitle = 0 === l.length, U.hoursTitle = "全天", l.push(t({
                        ui: U
                    }, p))) : p.startTimeObj.hours < 6 ? (U.showHoursTitle = 0 === u.length, U.hoursTitle = "凌晨", 
                    u.push(t({
                        ui: U
                    }, p))) : p.startTimeObj.hours < 12 ? (U.showHoursTitle = 0 === d.length, U.hoursTitle = "上午", 
                    d.push(t({
                        ui: U
                    }, p))) : p.startTimeObj.hours < 18 ? (U.showHoursTitle = 0 === h.length, U.hoursTitle = "下午", 
                    h.push(t({
                        ui: U
                    }, p))) : (U.showHoursTitle = 0 === c.length, U.hoursTitle = "晚上", c.push(t({
                        ui: U
                    }, p)));
                }
                var q = l.concat(u).concat(d).concat(h).concat(c);
                q.map(function(t) {
                    t.event.fgColor && 9 === t.event.fgColor.length && (t.event.fgColor = "rgba(" + parseInt("0x" + t.event.fgColor.slice(1, 3)) + "," + parseInt("0x" + t.event.fgColor.slice(3, 5)) + "," + parseInt("0x" + t.event.fgColor.slice(5, 7)) + ",1)"), 
                    t.event.repeatStr = 1 === t.event.eventType ? t.event.rruleDesc || "周期" : t.event.rruleDesc;
                }), i.push({
                    schduleList: q,
                    scrollTop: this.buildScrollTop()
                });
            }
            return i;
        },
        builDataArr: function() {
            var t = this.data.eventArr, e = [];
            return t.forEach(function(t) {
                var r = t.filter(function(t) {
                    var e = t.event, r = t.dayTime;
                    if (3 === e.eventType) return !1;
                    var i = new Date(e.startTime), a = new Date(i.getFullYear(), i.getMonth(), i.getDate()), s = new Date(e.endTime), n = new Date(s.getFullYear(), s.getMonth(), s.getDate()), o = a.getTime() === r ? i.getHours() : 0, l = a.getTime() === r ? i.getMinutes() : 0, u = n.getTime() === r ? s.getHours() : 24, d = n.getTime() === r ? s.getMinutes() : 0;
                    return t.startTimeObj = {
                        hours: o,
                        minutes: l
                    }, t.endTimeObj = {
                        hours: u,
                        minutes: d
                    }, t.startTimeObj.times = 3600 * t.startTimeObj.hours + 60 * t.startTimeObj.minutes, 
                    t.endTimeObj.times = 3600 * t.endTimeObj.hours + 60 * t.endTimeObj.minutes, !0;
                });
                e.push(r);
            }), e;
        },
        buildScrollTop: function() {
            return this.data.userScrollDraged ? this.data.userScrollTop : 0;
        },
        onSwiperAnimationFinish: function(t) {
            var r = t.detail, i = r.source, a = r.current;
            if ("touch" === i && a !== this.data.swiperPosition) {
                this.setData({
                    swiperDuration: 0
                }), e.info("onSwiperAnimationFinish \n      ".concat(JSON.stringify(this.data.dayList), " ").concat(a, " ").concat(this.data.swiperPosition), "event-list-mode.js"), 
                this.triggerEvent("swiperchange", a < this.data.swiperPosition);
                var s = this.data.dayList[a];
                this.triggerEvent("datechange", s);
            }
        },
        onSwiperTransitionStart: function() {
            var t = this;
            if (this.data.userScrollDraged) {
                var e = this.data.dataListArray, r = !1;
                e.forEach(function(e) {
                    e.scrollTop !== t.data.userScrollTop && (e.scrollTop = t.data.userScrollTop, r = !0);
                }), r && this.setData({
                    dataListArray: e
                });
            }
        },
        onScrollChange: function(t) {
            this.data.userScrollDraged || this.setData({
                userScrollDraged: !0
            }), this.data.userScrollDraged && (this.data.userScrollTop = t.detail.scrollTop);
        },
        onScrollDrag: function(t) {
            this.data.userScrollDraged || (this.data.userScrollDraged = !0, this.data.userScrollTop = t.detail.scrollTop);
        },
        onEventListScheduleClick: function(t) {
            var e = t.currentTarget.dataset, r = e.schedule, i = e.index;
            this.triggerEvent("clickSchedule", {
                schedule: r,
                index: i
            });
        },
        onEventListJoinMeetingClick: function(t) {
            this.triggerEvent("clickJoinMeeting", t.currentTarget.dataset.schedule);
        }
    },
    lifetimes: {
        attached: function() {
            if (this.data.eventArr && this.data.eventArr.length > 0) this.updateDataListArray(); else {
                for (var t = [], e = this.buildScrollTop(), r = 0; r < 3; r++) t.push({
                    schduleList: [],
                    scrollTop: e
                });
                this.setData({
                    dataListArray: t
                });
            }
        }
    },
    observers: {
        eventArr: function() {
            this.updateDataListArray();
        }
    }
});