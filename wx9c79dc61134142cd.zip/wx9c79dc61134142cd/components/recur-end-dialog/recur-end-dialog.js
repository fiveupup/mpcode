var e = require("../../utils/beacon/report_data");

Component({
    properties: {
        show: {
            type: Boolean,
            value: !1,
            observer: "__init"
        },
        selectItems: {
            type: Array,
            value: [],
            observer: function() {}
        },
        initTime: {
            type: Number,
            value: 0
        },
        repeatEndLimit: {
            type: Object,
            value: {}
        },
        initDefaultCount: {
            type: Number,
            value: 0,
            observer: "__init"
        }
    },
    data: {
        showDatePicker: !1,
        showCount: !1,
        defaultDate: "",
        defaultCount: 10,
        confirmRepeatEndType: 0
    },
    options: {
        addGlobalClass: !0
    },
    methods: {
        __init: function() {
            this.data.initDefaultCount && (this.setData({
                defaultCount: this.data.initDefaultCount
            }), this.setData({
                showDatePicker: !1,
                showCount: !1
            }));
        },
        prevent: function() {},
        hide: function() {
            this.setData({
                show: !1
            });
        },
        cancel: function() {
            this.data.show && (this.triggerEvent("cancel"), this.hide());
        },
        clickitem: function(e) {
            var t, a, i, n;
            this.triggerEvent("clickendrecuritem", null === (t = e.currentTarget) || void 0 === t ? void 0 : t.dataset), 
            this.setData({
                confirmRepeatEndType: null === (a = e.currentTarget) || void 0 === a ? void 0 : a.dataset.index,
                showDatePicker: 1 === (null === (i = e.currentTarget) || void 0 === i ? void 0 : i.dataset.index),
                showCount: 2 === (null === (n = e.currentTarget) || void 0 === n ? void 0 : n.dataset.index),
                repeatEndTime: "",
                repeatEndCount: ""
            });
        },
        onConfirm: function(t) {
            var a = t.detail, i = a.repeatEndType, n = a.repeatEndTime, o = a.repeatEndCount;
            console.log("onConfirm", t.detail), "date" === i ? (e.dataReport("e#deadline#toggle_time#click", {}), 
            this.setData({
                repeatEndTime: n
            })) : "count" === i && (e.dataReport("e#deadline#toggle_number#click", {}), this.setData({
                repeatEndCount: o
            }));
        },
        getRepeatEndData: function() {
            var e, t = this.data.initTime, a = this.data.confirmRepeatEndType;
            switch (a) {
              case 0:
                e = "";
                break;

              case 1:
                e = this.data.repeatEndTime || t;
                break;

              case 2:
                e = this.data.repeatEndCount || this.data.defaultCount;
                break;

              default:
                e = "";
            }
            this.triggerEvent("updaterepeatendword", {
                endType: a,
                endValue: e
            });
        }
    }
});