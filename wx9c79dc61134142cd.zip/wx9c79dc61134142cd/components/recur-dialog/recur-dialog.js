Component({
    properties: {
        show: {
            type: Boolean,
            value: !1
        },
        showEndRepeat: {
            type: Boolean,
            value: !1
        },
        selectItems: {
            type: Array,
            value: [],
            observer: function() {}
        },
        repeatEndWord: {
            type: String,
            default: ""
        }
    },
    data: {
        showEndRepeat: !1
    },
    options: {
        addGlobalClass: !0
    },
    methods: {
        prevent: function() {},
        hide: function() {
            this.setData({
                show: !1
            });
        },
        cancel: function() {
            this.data.show && (this.triggerEvent("cancel"), this.hide());
        },
        clickitem: function(e) {
            var t;
            this.triggerEvent("clickitem", null === (t = e.currentTarget) || void 0 === t ? void 0 : t.dataset);
        },
        clickcustomrecur: function() {
            this.triggerEvent("clickcustomrecur");
        },
        clickendrecur: function() {
            this.triggerEvent("clickendrecur");
        }
    }
});