var e = require("../../@babel/runtime/helpers/defineProperty"), t = require("../../utils/Dayjs.js"), a = require("../../utils/util"), n = a.isIPhone() || a.isMac(), i = function(e, t) {
    e || (e = "");
    for (var a = "", n = 0; n < t; n++) a += "0";
    return (a + e).substr(-t);
};

Component({
    properties: {
        show: {
            type: Boolean,
            value: !1,
            observer: "__init"
        },
        initTime: {
            type: Number,
            value: 0,
            observer: "__init"
        },
        onlyDay: {
            type: Boolean,
            value: !1
        },
        type: {
            type: Number,
            value: 0
        },
        repeatEndLimit: {
            type: Object,
            value: {},
            observer: "__init"
        }
    },
    data: {
        years: [],
        months: [],
        days: [],
        dates: [],
        hhs: [],
        mms: [],
        height: 36,
        unselectFontSize: 16,
        selectedFontSize: 21,
        defaultYears: [ 0 ],
        defaultMonths: [ 0 ],
        defaultDays: [ 0 ],
        defaultDates: [ 0 ],
        defaultHhs: [ 0 ],
        defaultMms: [ 0 ],
        yearsSelected: 0,
        monthsSelected: 0,
        daysSelected: 0,
        datesSelected: 0,
        hhsSelected: 0,
        mmsSelected: 0
    },
    observers: {
        years: function(e) {
            var t = e.filter(function(e) {
                return e.checked;
            }), a = this.data.months.filter(function(e) {
                return e.checked;
            }), n = t.length > 0 ? t[0].value : this.data.initDate && this.data.initDate.getFullYear(), i = a.length > 0 ? a[0].value : this.data.initDate && this.data.initDate.getMonth() + 1;
            console.log("observers selectedYear, selectedMonth", n, i), this.setMonths(n), this.setMonthDays(n, i);
        },
        months: function(e) {
            var t = this.data.years.filter(function(e) {
                return e.checked;
            }), a = e.filter(function(e) {
                return e.checked;
            }), n = t.length > 0 ? t[0].value : this.data.initDate && this.data.initDate.getFullYear(), i = a.length > 0 ? a[0].value : this.data.initDate && this.data.initDate.getMonth() + 1;
            console.log("observers selectedYear, selectedMonth", n, i), this.setMonthDays(n, i);
        }
    },
    methods: {
        __init: function(e) {
            if (e) {
                var a = new Date().getTime(), i = new Date(), s = this.data.initTime ? new Date(this.data.initTime) : new Date();
                console.log("initTime", this.data.initTime);
                var c = this.data.repeatEndLimit, o = c.year, r = c.month, h = c.day, l = c.week;
                console.log("repeatEndLimit___date picker", o, r, h, l);
                for (var d = [], u = s.getFullYear(), g = o - u + 1, m = 0; m < g; m++) {
                    var f, v;
                    f = "".concat(v = u + m, "年"), d.push({
                        text: f,
                        value: v
                    });
                }
                console.log("years", d);
                var D = s.getMonth() + 1;
                this.setMonths(u), this.setMonthDays(u, D);
                var y = "".concat(s.getFullYear() - 1, "-01-01"), p = "".concat(s.getFullYear() + 1, "-12-31"), M = new Date(n ? y.replace(/-/g, "/") : y), Y = (new Date(n ? p.replace(/-/g, "/") : p) - M) / 864e5;
                console.log("day count", Y);
                for (var T = [], b = [ 0 ], w = [ 0 ], S = [ 0 ], k = [ "日", "一", "二", "三", "四", "五", "六" ], F = 0; F < Y; F++) {
                    var E = M.getTime() + 24 * F * 60 * 60 * 1e3, _ = new Date(E), L = "";
                    L = _.getFullYear() === i.getFullYear() ? "".concat(t(E).format("MM月DD日"), "(周").concat(k[_.getDay()], ")") : "".concat(t(E).format("YYYY年MM月DD日"), "(周").concat(k[_.getDay()], ")");
                    var C = !1;
                    _.getFullYear() === i.getFullYear() && _.getDate() === i.getDate() && _.getMonth() === i.getMonth() && (L = "今天"), 
                    _.getFullYear() === s.getFullYear() && _.getDate() === s.getDate() && _.getMonth() === s.getMonth() && (C = !0, 
                    b = [ F ]), T.push({
                        text: L,
                        value: t(E).format("YYYY-MM-DD"),
                        checked: C
                    });
                }
                for (var x = [], H = 0; H < 24; H++) H === s.getHours() && (w = [ H ]), x.push({
                    text: "".concat(H < 10 ? "0".concat(H) : H, "时"),
                    value: "".concat(H < 10 ? "0".concat(H) : H),
                    checked: H === s.getHours()
                });
                var j = [];
                console.log("initDate.getMinutes", s.getMinutes());
                for (var q = 0; q <= 59; q++) q % 15 || (q === s.getMinutes() && (S = [ q / 15 ]), 
                j.push({
                    text: "".concat(q < 10 ? "0".concat(q) : q, "分"),
                    value: "".concat(q < 10 ? "0".concat(q) : q),
                    checked: q === s.getMinutes()
                }));
                this.setData({
                    initDate: s,
                    years: d,
                    dates: T,
                    hhs: x,
                    mms: j,
                    defaultYears: [ 0 ],
                    defaultDates: b,
                    defaultHhs: w,
                    defaultMms: S,
                    datesSelected: b[0],
                    hhsSelected: w[0],
                    mmsSelected: S[0]
                }), console.log("init pick cost:", new Date().getTime() - a);
            }
        },
        setMonths: function(e) {
            for (var t = this.data.initTime ? new Date(this.data.initTime) : new Date(), a = this.data.repeatEndLimit.year, n = this.data.repeatEndLimit.month, i = a === e ? n : 12, s = [], c = t && (e === t.getFullYear() ? t.getMonth() : 0); c < i; c++) {
                var o, r = 1;
                o = "".concat(r += c, "月"), s.push({
                    text: o,
                    value: r
                });
            }
            console.log("months", s), this.setData({
                months: s,
                defaultMonths: [ 0 ]
            });
        },
        setMonthDays: function(e, t) {
            var a = this.data.initTime ? new Date(this.data.initTime) : new Date(), s = [ "日", "一", "二", "三", "四", "五", "六" ], c = 31, o = this.data.repeatEndLimit.year, r = this.data.repeatEndLimit.month, h = this.data.repeatEndLimit.day;
            switch (t) {
              case 2:
                c = 28, function(e) {
                    return e % 4 == 0 && e % 100 != 0 || e % 400 == 0;
                }(e) && (c = 29);
                break;

              case 4:
              case 6:
              case 9:
              case 11:
                c = 30;
            }
            c = e === o && t === r ? h : c;
            for (var l = [], d = a && (e === a.getFullYear() && t === a.getMonth() + 1 ? a.getDate() : 1); d <= c; d++) {
                var u = "".concat(e, "-").concat(t, "-").concat(d), g = n ? u.replace(/-/g, "/") : u, m = new Date(g);
                l.push({
                    text: "".concat(i(d, 2), "日(周").concat(s[m.getDay()], ")"),
                    value: d
                });
            }
            this.setData({
                days: l,
                defaultDays: [ 0 ]
            });
        },
        none: function() {},
        bindChangeYears: function(e) {
            console.log("change years", e), this.changeTime(e, "years");
        },
        bindChangeMonths: function(e) {
            this.changeTime(e, "months");
        },
        bindChangeDays: function(e) {
            this.changeTime(e, "days");
        },
        bindChangeDates: function(e) {
            this.changeTime(e, "dates");
        },
        bindChangeHhs: function(e) {
            this.changeTime(e, "hhs");
        },
        bindChangeMms: function(e) {
            this.changeTime(e, "mms");
        },
        changeTime: function(t, a) {
            var n, s = t.detail.value, c = this.data[a];
            c.forEach(function(e) {
                return e.checked = !1;
            }), c[s[0]].checked = !0, this.setData((e(n = {}, a, c), e(n, "".concat(a, "Selected"), s[0]), 
            n));
            var o = this.data, r = o.years, h = o.months, l = o.days, d = o.initDate;
            console.log("change time days", l);
            var u = r.filter(function(e) {
                return e.checked;
            }), g = u.length > 0 ? u[0].value : d.getFullYear(), m = h.filter(function(e) {
                return e.checked;
            }), f = m.length > 0 ? m[0].value : h[this.data.monthsSelected].value, v = l.filter(function(e) {
                return e.checked;
            }), D = v.length > 0 ? v[0].value : l[this.data.daysSelected].value, y = "".concat(g, "/").concat(i(f, 2), "/").concat(i(D, 2), " 23:59:59");
            console.log("selectTime", y), this.triggerEvent("confirm", {
                repeatEndType: "date",
                repeatEndTime: new Date(y).getTime()
            });
        },
        cancel: function(e) {
            console.log("cancel"), this.triggerEvent("cancel", e);
        },
        confirm: function() {
            var e = this.data, t = e.dates, a = e.hhs, i = e.mms, s = e.datesSelected, c = e.hhsSelected, o = e.mmsSelected, r = "";
            r = this.data.onlyDay ? 1 === this.data.type ? "".concat(t[s].value, " 00:00") : "".concat(t[s].value, " 23:59:59") : "".concat(t[s].value, " ").concat(a[c].value, ":").concat(i[o].value), 
            r = n ? r.replace(/-/g, "/") : r, console.log(r), this.triggerEvent("confirm", {
                time: r,
                type: this.data.type
            });
        }
    }
});