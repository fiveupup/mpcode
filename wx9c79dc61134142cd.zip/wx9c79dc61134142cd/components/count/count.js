Component({
    properties: {
        show: {
            type: Boolean,
            value: !1,
            observer: "__init"
        },
        decrement: {
            type: Number,
            value: 1
        },
        increment: {
            type: Number,
            value: 1
        },
        minValue: {
            type: Number,
            value: 2
        },
        maxValue: {
            type: Number,
            value: 200
        },
        initValue: {
            type: String,
            value: "",
            observer: "__init"
        },
        repeatEndLimit: {
            type: Object,
            value: {},
            observer: "__init"
        }
    },
    data: {
        inputValue: "",
        minusDisable: !1,
        plusDisable: !1
    },
    options: {},
    observers: {
        inputValue: function(t) {
            var e = parseInt(t, 10);
            return console.log("input v", t), e <= this.data.minValue ? (this.setData({
                minusDisable: !0,
                plusDisable: !1
            }), void this.triggerEvent("confirm", {
                repeatEndType: "count",
                repeatEndCount: this.data.minValue
            })) : e >= this.data.maxValue ? (this.setData({
                minusDisable: !1,
                plusDisable: !0
            }), void this.triggerEvent("confirm", {
                repeatEndType: "count",
                repeatEndCount: this.data.maxValue
            })) : (this.setData({
                minusDisable: !1,
                plusDisable: !1
            }), void this.triggerEvent("confirm", {
                repeatEndType: "count",
                repeatEndCount: e
            }));
        }
    },
    methods: {
        __init: function() {
            var t = this.data, e = t.initValue, a = t.repeatEndLimit;
            console.log("count __init", a), this.setData({
                inputValue: e,
                maxValue: a.count || 200
            });
        },
        prevent: function() {},
        hide: function() {
            this.setData({
                show: !1
            });
        },
        cancel: function() {
            this.data.show && (this.triggerEvent("cancel"), this.hide());
        },
        minusClick: function() {
            var t = this.data, e = t.inputValue, a = t.decrement, i = t.minValue, n = parseInt(e, 10) - a;
            n >= i && this.setData({
                inputValue: n
            });
        },
        plusClick: function() {
            var t = this.data, e = t.inputValue, a = t.increment, i = t.maxValue, n = parseInt(e, 10) + a;
            n <= i && this.setData({
                inputValue: n
            });
        },
        onInput: function(t) {
            var e = t.detail.value, a = this.data, i = a.minValue, n = a.maxValue;
            e && e <= i && this.setData({
                inputValue: i
            }), e && e >= n && this.setData({
                inputValue: n
            }), this.setData({
                inputValue: e
            });
        }
    }
});