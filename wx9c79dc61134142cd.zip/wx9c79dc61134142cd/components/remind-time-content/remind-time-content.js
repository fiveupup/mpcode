Component({
    properties: {
        selectStartItems: {
            type: Array,
            value: []
        },
        selectEndItems: {
            type: Array,
            value: []
        },
        showBeforeEndItem: {
            type: Boolean,
            value: !1
        },
        allday: {
            type: Boolean,
            value: !1
        },
        startTime: {
            type: Number,
            value: 0
        },
        endTime: {
            type: Number,
            value: 0
        },
        showExpiredTips: {
            type: Boolean,
            value: !0
        }
    },
    data: {
        selectItemCount: 0,
        selectItemMax: 5,
        isShowTimePicker: !1,
        type: 0
    },
    options: {
        addGlobalClass: !0
    },
    observers: {
        "selectStartItems, selectEndItems": function(t, e) {
            var i, s, n = function(t) {
                var e = 0;
                return t.forEach(function(t) {
                    "" !== t.value && t.isSelect && (e += 1);
                }), e;
            };
            i = n(t), s = n(e), this.setData({
                selectItemCount: i + s
            }), this.selectStartBeforeItemCount = i, this.selectEndBeforeItemCount = s, this.isExpandUnselectStartItem = !1, 
            this.isExpandUnselectEndItem = !1;
        }
    },
    lifetimes: {
        attached: function() {
            this.selectStartBeforeItemCount = 0, this.selectEndBeforeItemCount = 0, this.isExpandUnselectStartItem = !1, 
            this.isExpandUnselectEndItem = !1;
        }
    },
    methods: {
        prevent: function() {},
        clickStartItem: function(t) {
            this.triggerEvent("clickbeforeStartItem", t.currentTarget.dataset);
        },
        clickEndItem: function(t) {
            this.triggerEvent("clickbeforeEndItem", t.currentTarget.dataset);
        },
        clickSelectStartItem: function(t) {
            this.clickStartItem(t);
        },
        clickSelectEndItem: function(t) {
            this.clickEndItem(t);
        },
        expandUnselectStartItem: function() {
            this.setData({
                isExpandUnselectStartItem: !0,
                isExpandUnselectEndItem: !1
            });
        },
        expandUnselectEndItem: function() {
            this.setData({
                isExpandUnselectStartItem: !1,
                isExpandUnselectEndItem: !0
            });
        },
        clickCustiomStartRemindTime: function() {
            this.triggerEvent("custiomRemindTimeDialogStatusChange", {
                status: !0
            }), this.setData({
                isShowTimePicker: !0,
                baseTime: this.properties.startTime,
                type: 0
            });
        },
        clickCustiomEndRemindTime: function() {
            this.triggerEvent("custiomRemindTimeDialogStatusChange", {
                status: !0
            }), this.setData({
                isShowTimePicker: !0,
                baseTime: this.properties.endTime,
                type: 1
            });
        },
        cancelCustomRemindTimePickerDialog: function() {
            this.triggerEvent("custiomRemindTimeDialogStatusChange", {
                status: !1
            }), this.setData({
                isShowTimePicker: !1
            });
        },
        confirmCustomRemindTimePickerDialog: function(t) {
            this.data.baseTime === this.properties.startTime ? this.triggerEvent("clickbeforeStartItem", t.detail) : this.triggerEvent("clickbeforeEndItem", t.detail), 
            this.triggerEvent("custiomRemindTimeDialogStatusChange", {
                status: !1
            }), this.setData({
                isShowTimePicker: !1
            });
        }
    }
});