Component({
    properties: {
        show: {
            type: Boolean,
            value: !1
        },
        selectItems: {
            type: Array,
            value: []
        },
        showBeforeEndItem: {
            type: Boolean,
            value: !1
        },
        beforeEndRemindStr: {
            type: String,
            value: ""
        },
        roleList: {
            type: Array,
            value: []
        },
        accessList: {
            type: Array,
            value: []
        }
    },
    data: {},
    options: {
        addGlobalClass: !0
    },
    methods: {
        prevent: function() {},
        hide: function() {
            this.setData({
                show: !1
            });
        },
        cancel: function() {
            this.data.show && (this.triggerEvent("cancel"), this.hide());
        },
        confirm: function() {
            this.data.show && (this.triggerEvent("confirm"), this.hide());
        },
        clickRoleItem: function(e) {
            e.currentTarget.dataset.roleItem.disable || this.triggerEvent("ClickRole", e.currentTarget.dataset);
        },
        clickAccessItem: function(e) {
            e.currentTarget.dataset.accessItem.disable || this.triggerEvent("ClickAccess", e.currentTarget.dataset);
        },
        onAccessSwitch: function(e) {
            var t = e.detail.value;
            console.log("onAccessSwitch", t);
        }
    }
});