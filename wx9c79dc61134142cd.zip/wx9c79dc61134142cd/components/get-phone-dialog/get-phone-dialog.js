Component({
    options: {
        multipleSlots: !0
    },
    properties: {
        dialogHeight: {
            type: Number,
            value: 634
        }
    },
    data: {
        show: !1
    },
    attached: function() {
        console.log("slider-message-dialog attached");
    },
    methods: {
        show: function() {
            this.setData({
                show: !0
            });
        },
        hide: function() {
            this.setData({
                show: !1
            });
        },
        onNegativeTab: function(e) {
            console.log("onNegativeTab: ".concat(JSON.stringify(e))), this.triggerEvent("CloseGrantPhoneTap", e.detail);
        },
        onPositiveTab: function(e) {
            console.log("onPositiveTab: ".concat(JSON.stringify(e))), this.triggerEvent("GetPhoneNumberTab", e.detail);
        },
        onWxGetPhoneNumResult: function(e) {
            if (console.log("onWxGetPhoneNumResult: ".concat(JSON.stringify(e))), "getPhoneNumber:ok" === e.detail.errMsg) {
                console.log("phone granted");
                var t = {
                    iv: e.detail.iv,
                    encryptedData: e.detail.encryptedData
                };
                console.log("phoneInfo:", JSON.stringify(t)), this.triggerEvent("WxPhoneNumGranted", t);
            } else console.warn("phone refused"), this.triggerEvent("WxPhoneNumRefuse", {});
        },
        goUseRules: function() {
            this.triggerEvent("UseRuleTab", {});
        },
        goPrivacy: function() {
            this.triggerEvent("PrivacyTab", {});
        }
    }
});