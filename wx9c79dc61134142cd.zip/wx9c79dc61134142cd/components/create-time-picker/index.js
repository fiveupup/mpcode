var t = require("../../@babel/runtime/helpers/slicedToArray"), a = require("./utils"), e = require("../time-lunar/getInterval"), i = require("../../utils/Dayjs.js");

Component({
    properties: {
        allday: {
            type: Boolean,
            value: !1
        },
        startTimeData: {
            type: Object
        },
        endTimeData: {
            type: Object
        },
        lastTimeData: {
            type: Object
        },
        unfold: {
            type: String,
            value: ""
        }
    },
    data: {
        lastTimeString: "",
        lastTimeConfig: {
            oneDay: {
                hours: [],
                minutes: [],
                indexVal: []
            },
            allDay: {
                day: [],
                indexVal: []
            }
        },
        endTime: 0,
        startTime: 0,
        viewType: "",
        endTimeLimit: {},
        unInit: !1,
        labelStart: {
            allDay: "开始时间",
            normal: "时间"
        },
        labelEnd: {
            allDay: "结束时间",
            normal: "时间"
        }
    },
    attached: function() {
        this.init(), this.resetDuration(), this.setUnfoldType({
            type: this.data.unfold,
            visible: !0
        });
    },
    methods: {
        init: function() {
            var t, n = this.data, s = n.startTimeData, r = n.endTimeData, o = n.allDay;
            if (s) {
                var l = s.year, d = s.month, u = s.day, m = s.hour, h = s.minute;
                t = i("".concat(l, "-").concat(d, "-").concat(u, " ").concat(m, ":").concat(h)).valueOf(), 
                this.setData({
                    startTime: t
                });
            } else t = Date.now(), this.setData({
                startTime: t
            });
            if (r) {
                var c = r.year, T = r.month, y = r.day, D = r.hour, f = r.minute, v = i("".concat(c, "-").concat(T, "-").concat(y, " ").concat(D, ":").concat(f));
                this.setData({
                    endTime: v.valueOf()
                });
            } else {
                var g;
                g = o ? i(t).add(1, "day") : i(t).add(1, "hour"), this.setData({
                    endTime: g.valueOf()
                });
            }
            this.resetAllDayList(t), this.setEndTimeLimit(t);
            var p = a.setLastPickerHour(), b = e();
            this.setData({
                "lastTimeConfig.oneDay.hours": p,
                "lastTimeConfig.oneDay.minutes": b
            });
        },
        resetDuration: function(t, e) {
            var i = !(arguments.length > 2 && void 0 !== arguments[2]) || arguments[2], n = t;
            n || (n = this.data.lastTimeData);
            var s = n, r = s.day, o = s.hour, l = s.minute;
            if (0 !== r || 0 !== o || 0 !== l) if (24 * r * 60 + 60 * o + l > 43200) wx.showToast({
                icon: "none",
                title: "最多选择30天"
            }); else {
                var d = "".concat(r > 0 ? "".concat(r, "天") : "").concat(o > 0 ? "".concat(o, "小时") : "").concat(l > 0 ? "".concat(l, "分钟") : ""), u = this.data.lastTimeConfig.oneDay.minutes, m = a.getMinuteValue(u, l);
                this.setData({
                    lastTimeString: d,
                    "lastTimeConfig.allDay.indexVal": [ r - 1 ],
                    "lastTimeConfig.oneDay.indexVal": [ 24 * r + o, m ],
                    lastTimeData: n
                }), i && this.setEndTimeByDuration(e, n);
            } else wx.showToast({
                icon: "none",
                title: "持续时间不能小于1分钟"
            });
        },
        setUnfoldType: function(t) {
            var a = t.type, e = t.visible;
            this.setData({
                viewType: e ? a : ""
            });
        },
        oneDayPickerchange: function(a) {
            var e = this.data.lastTimeConfig.oneDay.minutes, i = a.detail.value, n = t(i, 2), s = n[0], r = n[1], o = Math.floor(s / 24), l = {
                day: o,
                hour: s - 24 * o,
                minute: e[r]
            };
            this.resetDuration(l);
        },
        oneDayPickerchangeEnd: function() {
            this.resetDuration();
        },
        allDayPickerchange: function(a) {
            var e = a.detail.value, i = t(e, 1)[0];
            this.resetDuration({
                day: i + 1,
                hour: 0,
                minute: 0
            });
        },
        setEndTimeByDuration: function(t, a) {
            var e = t, n = a;
            e || (e = this.data.startTime), n || (n = this.data.lastTimeData);
            var s = (e = i(e)).add(n.day, "day").add(n.hour, "hour").add(n.minute, "minute");
            this.setData({
                endTime: s.valueOf()
            });
        },
        daySwitchChange: function() {
            var t, a = !this.data.allday, e = this.data.startTime;
            this.setData({
                allday: a
            }), a ? (e = i(e).hour(0).minute(0).valueOf(), t = {
                day: 1,
                hour: 0,
                minute: 0
            }) : t = {
                day: 0,
                hour: 1,
                minute: 0
            }, this.setData({
                startTime: e
            }), this.resetDuration(t, e), this.setUnfoldType({
                type: "startTime-month",
                visible: !0
            });
        },
        resetAllDayList: function(t) {
            var e = a.setLastPickerDay(t);
            this.setData({
                "lastTimeConfig.allDay.day": e
            });
        },
        itemTap: function(t) {
            var a = t.target, e = t.detail, i = a.id, n = e.type, s = e.visible;
            this.setUnfoldType({
                type: "".concat(i, "-").concat(n),
                visible: s
            });
        },
        handleDurationClick: function() {
            var t = this.data, e = t.viewType, i = t.lastTimeString;
            "last" !== e && "-1" === i && this.resetDuration(a.getInitDuration(!0)), this.setUnfoldType({
                type: "last",
                visible: "last" !== e
            });
        },
        changeTime: function(t) {
            var e = this, i = t.target, n = t.detail, s = i.id, r = n.startTime, o = n.endTime, l = this.data, d = l.allday, u = l.startTime, m = l.endTime;
            if ("startTime" === s) {
                if (!d && r === u) return;
                if (-1 === o) return void this.setData({
                    startTime: r,
                    lastTimeString: "-1"
                });
                var h, c = r - (d ? o : m);
                h = c >= 0 || Math.abs(c) / 864e5 > 30 ? a.getInitDuration(d) : a.getTimeObjectByDuration(c), 
                this.setData({
                    startTime: r
                }), this.resetAllDayList(r), this.resetDuration(h, r), this.setEndTimeLimit(r);
            } else {
                if (r === m) return;
                var T = r - u;
                if (T <= 0) return wx.showToast({
                    icon: "none",
                    title: "结束时间不能早于开始时间"
                }), void this.setData({
                    endTime: m
                });
                if (Math.abs(T) / 864e5 > 30) return wx.showToast({
                    icon: "none",
                    title: "最多选择30天"
                }), void setTimeout(function() {
                    e.setData({
                        endTime: m
                    });
                }, 150);
                var y = a.getTimeObjectByDuration(T);
                this.resetDuration(y, u);
            }
        },
        setEndTimeLimit: function(t) {
            var a = i(t).add(30, "day");
            this.setData({
                "endTimeLimit.min": i(t).add(-1, "day").valueOf(),
                "endTimeLimit.max": a.valueOf()
            });
        },
        handlecancel: function(t) {
            this.triggerEvent("cancel", t);
        },
        handleConfirm: function() {
            var t = this.data, e = t.startTime, i = t.lastTimeData, n = {
                allday: this.data.allday,
                startTimeData: a.parseTimeToObjct(e),
                lastTimeData: i
            };
            this.triggerEvent("confirm", n);
        }
    }
});