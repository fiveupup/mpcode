var t = require("../../utils/Dayjs.js");

module.exports = {
    setLastPickerDay: function() {
        for (var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : new Date(), r = [], a = new Date(), n = [ "周日", "周一", "周二", "周三", "周四", "周五", "周六" ], o = 1; o <= 30; o++) {
            var u = new Date(e + 864e5 * (o - 1)), i = a.getFullYear() === u.getFullYear(), c = i ? "" : "".concat(u.getFullYear(), "/"), h = u.getDay(), s = i && a.getMonth() === u.getMonth() && a.getDate() === u.getDate();
            s ? r.push("".concat(o, "天 （今天）")) : r.push("".concat(o, "天 （").concat(c).concat(t(u).format("MM/DD"), " ").concat(n[h], "）"));
        }
        return r;
    },
    setLastPickerHour: function() {
        for (var t = [], e = 0; e <= 720; e++) t.push(e);
        return t;
    },
    getMinuteValue: function(t, e) {
        for (var r = t.length, a = 0, n = 0; a < r; a++) if (t[a] === e || e > t[a - 1] && e < t[a]) {
            n = a;
            break;
        }
        return n;
    },
    getTimeObjectByDuration: function(t) {
        var e = Math.floor(Math.abs(t / 6e4)), r = Math.floor(e / 1440), a = Math.floor((e - 1440 * r) / 60);
        return {
            day: r,
            hour: a,
            minute: e - 1440 * r - 60 * a
        };
    },
    getInitDuration: function(t) {
        return t ? {
            day: 1,
            hour: 0,
            minute: 0
        } : {
            day: 0,
            hour: 1,
            minute: 0
        };
    },
    parseTimeToObjct: function(e) {
        var r = t(e);
        return {
            year: r.year(),
            month: r.month() + 1,
            day: r.date(),
            hour: r.hour(),
            minute: r.minute()
        };
    }
};