Component({
    properties: {
        show: {
            type: Boolean,
            value: !1
        },
        calendarList: {
            type: Array,
            value: []
        },
        selectedCalendarId: {
            type: String,
            value: ""
        }
    },
    data: {},
    options: {
        addGlobalClass: !0
    },
    methods: {
        prevent: function() {},
        hide: function() {
            this.setData({
                show: !1
            });
        },
        cancel: function() {
            this.data.show && (this.triggerEvent("cancel"), this.hide());
        },
        clickitem: function(t) {
            this.triggerEvent("clickitem", t.currentTarget.dataset);
        }
    }
});