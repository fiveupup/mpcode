Component({
    properties: {},
    data: {
        createTipsShow: 0,
        detailTipsShow: !1
    },
    methods: {
        showCreateTips: function() {
            this.setData({
                createTipsShow: 1
            });
        },
        hideCreateTips: function() {
            var t = this;
            1 === this.data.createTipsShow ? (this.setData({
                createTipsShow: 2
            }), setTimeout(function() {
                t.setData({
                    createTipsShow: 0
                });
            }, 600)) : this.setData({
                createTipsShow: 0
            });
        },
        showDetailTips: function() {
            this.setData({
                detailTipsShow: !0
            });
        },
        hideDetailTips: function() {
            this.setData({
                detailTipsShow: !1
            });
        },
        onCreateGuideTipsTab: function() {
            this.triggerEvent("CreateGuideTipsTab", {});
        },
        onDetailGuideTipsTab: function() {
            this.triggerEvent("DetailGuideTipsTab", {});
        }
    }
});