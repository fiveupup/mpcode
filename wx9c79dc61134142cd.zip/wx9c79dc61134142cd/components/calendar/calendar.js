var t = require("../../@babel/runtime/helpers/slicedToArray"), e = require("@tencent/wecalendar-web-business-plugins").solar2lunar, a = require("../../utils/util"), i = require("../../sdk/logger/calendar_logger"), n = require("../../utils/Dayjs.js"), o = "calendar.js", s = 0, r = 0;

Component({
    properties: {
        spot: Object,
        date: Object,
        endDate: Object,
        todayChange: Object,
        beginDay: {
            type: String,
            value: ""
        },
        swiperHigh: {
            type: Number,
            value: 0
        },
        foldDisable: {
            type: Boolean,
            value: !1
        },
        showTitle: {
            type: Boolean,
            value: !1
        },
        openStatus: Boolean,
        allday: {
            type: Boolean,
            value: !1
        },
        swipeNotChangeSlected: {
            type: Boolean,
            value: !1
        },
        limit: {
            type: Object,
            value: {
                min: -1,
                max: Math.MAX_SAFE_INTEGER
            }
        }
    },
    data: {
        open: !1,
        dateListArray: [],
        selectDate: {},
        swiperPosition: 1,
        swiperDuration: 0,
        headerDayList: [ "日", "一", "二", "三", "四", "五", "六" ],
        showLunarCalendar: !1,
        showHoliday: !0,
        onlyKalendsFifteen: !1,
        swiperHeight: 308,
        calendarTitleText: ""
    },
    methods: {
        formatTime: function(t) {
            var e = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : "Y-M-D";
            function a(t) {
                var e = t.toString();
                return e[1] ? e : "0".concat(e);
            }
            function i(t, e) {
                var i = [ "Y", "M", "D", "h", "m", "s" ], n = [], o = new Date(t), s = e;
                n.push(o.getFullYear()), n.push(a(o.getMonth() + 1)), n.push(a(o.getDate())), n.push(a(o.getHours())), 
                n.push(a(o.getMinutes())), n.push(a(o.getSeconds()));
                for (var r = 0; r < n.length; r++) {
                    var h = n[r], d = i[r];
                    s = s.replace(d, h);
                }
                return s;
            }
            return i(t, e);
        },
        onSwiperAnimationFinish: function(t) {
            var e = t.detail, a = e.current, n = e.source;
            i.infoAll("onSwiperAnimationFinish ".concat(JSON.stringify(t.detail), " ").concat(this.data.swiperPosition), o), 
            n && "touch" !== n || 1 !== a && (this.setData({
                swiperDuration: 0
            }), i.infoAll("onSwiperAnimationFinish set swiperDuration \n      ".concat(this.data.swiperDuration, " ").concat(this.data.swiperPosition), o), 
            this.triggerSwiperChange(this.data.open, a < this.data.swiperPosition), this.data.open ? (i.info("onSwiperAnimationFinish invokeChangeWeek mounth", o), 
            this.invokeChangeMonth(a)) : (i.info("onSwiperAnimationFinish invokeChangeWeek week", o), 
            this.invokeChangeWeek(a)));
        },
        onOpenChange: function() {
            a.setValueInLocalStorage("open_status", !this.data.open), this.setData({
                open: !this.data.open
            }), this.triggerModeChange(this.data.open);
        },
        onSelectChange: function(t) {
            var e = {
                year: t.currentTarget.dataset.year,
                month: t.currentTarget.dataset.month,
                day: t.currentTarget.dataset.day,
                dateString: t.currentTarget.dataset.dateStringing
            }, a = !this.data.open;
            this.invokeSelectDate(e, a, !0);
        },
        invokeChangeMonth: function(t) {
            for (var e = new Date(), a = e.getMonth() + 1, i = e.getDate(), n = !1, o = {}, s = this.data.dateListArray[t], r = 0; r < s.length; r++) {
                var h = s[r];
                if (h.isCurrentMonth) {
                    if (h.month === a && (n = !0), !n) {
                        o = h;
                        break;
                    }
                    if (i === h.day) {
                        o = h;
                        break;
                    }
                }
            }
            this.invokeSelectDate(o, !1, !1);
        },
        invokeChangeWeek: function(e) {
            for (var a = new Date(), n = !1, s = {}, r = this.data.dateListArray[e], h = 0; h < r.length; h++) {
                var d = r[h];
                if (a.getFullYear() === d.year && a.getMonth() === d.month - 1 && a.getDate() === d.day) {
                    s = d, n = !0;
                    break;
                }
            }
            n || (s = t(r, 1)[0]);
            i.info("invokeSelectDate 1 position:".concat(e, ",findToday:").concat(n, ",targetDate:").concat(s), o), 
            this.invokeSelectDate(s, !0, !1);
        },
        invokeSelectDate: function(t, e, a) {
            var s = !1;
            if (e) for (var r = this.data.dateListArray[this.data.swiperPosition], h = 0; h < r.length; h++) {
                var d = r[h];
                if (t.year === d.year && t.month === d.month && t.day === d.day) {
                    s = !0;
                    break;
                }
            } else s = this.data.selectDate.year === t.year && this.data.selectDate.month === t.month;
            i.info("invokeSelectDate 2 isSameMonthOrWeek:\n      ".concat(s, ",selectDate:").concat(JSON.stringify(this.data.selectDate), ",weekMode:").concat(e), o);
            var c = this.data, l = c.endDate, g = c.selectDate, u = t, D = a || !this.data.swipeNotChangeSlected, y = new Date(t.year, t.month - 1, t.day), f = this.data.limit, p = f.min, v = f.max;
            if (y < p || y > v) return a || this.setData({
                swiperPosition: 1
            }), wx.showToast({
                icon: "none",
                title: y < p ? "结束时间不能小于开始时间" : "最多选择30天"
            });
            if (D) if (this.data.allday) {
                console.log("in");
                var m = l.year, w = l.month, S = l.day, T = g.day, k = g.month, C = g.year, M = new Date(m, w - 1, S), b = new Date(C, k - 1, T);
                if (0 !== Math.abs(n(M).diff(b, "day")) || !a) this.setData({
                    selectDate: t,
                    endDate: t
                }); else {
                    var L = n(y).diff(b, "day");
                    if (L < 0) this.setData({
                        selectDate: t,
                        endDate: t
                    }); else {
                        if (Math.abs(L) >= 30) return wx.showToast({
                            icon: "none",
                            title: "最多选择30天"
                        });
                        this.setData({
                            endDate: t
                        }), u = g;
                    }
                }
            } else this.setData({
                selectDate: t
            });
            this.triggerDateChange(t, a, u, D), s || this.dateInit(t.year, t.month, t.day), 
            this.clickswitch = !1;
        },
        triggerDateChange: function(t, e, a) {
            var n = !(arguments.length > 3 && void 0 !== arguments[3]) || arguments[3], s = this.formatTime(new Date(t.year, t.month - 1, t.day)), r = null !== this.data.spot ? this.data.spot[s] : void 0, h = {
                selectDate: t,
                isClick: e,
                nextTime: a,
                isEventDot: !!r && r.eventDot
            };
            i.info("triggerDateChange dateString ".concat(s, " ").concat(r, " ").concat(e), o);
            var d = this.getMonthTitle(h);
            h.titleText = d, this.setData({
                calendarTitleText: d
            }), n && this.triggerEvent("datechange", h);
        },
        triggerModeChange: function(t) {
            this.triggerEvent("modechange", t);
        },
        triggerSwiperChange: function(t, e) {
            this.triggerEvent("swiperchange", {
                isMonth: t,
                toLeft: e
            });
        },
        dateInit: function(t, e, a) {
            if (!this.initing) {
                this.initing = !0;
                for (var n = [], s = this.data.headerDayList.indexOf("一"), r = 0; r < 3; r++) this.data.open ? n[r] = this.initMonthList(t, e + (r - 1), s) : n[r] = this.initWeekList(t, e, a, r - 1, s);
                i.info("dateListArrayObj \n      ".concat(JSON.stringify(n), " ").concat(t, " ").concat(e, " ").concat(a, " ").concat(s), o), 
                console.log("=====2======", n), this.setData({
                    dateListArray: n,
                    swiperPosition: 1,
                    swiperDuration: 150
                }), this.initing = !1, this.clickswitch = !1;
            }
        },
        initMonthList: function(t, a, i) {
            var n = [], o = new Date(t, a - 1), s = new Date(), r = new Date(s.getFullYear(), s.getMonth(), s.getDate()), h = o.getDay(), d = 2;
            0 === h && 1 === this.offsetDay ? d -= 7 : 6 === h && 6 === this.offsetDay && (d += 7);
            for (var c = 0; c < 42; c++) {
                var l = new Date(o);
                l.setDate(c - h - i + d);
                var g = {};
                (g = {
                    day: l.getDate(),
                    month: l.getMonth() + 1,
                    year: l.getFullYear(),
                    dateString: this.formatTime(l)
                }).isCurrentMonth = a > 12 ? g.month === a - 12 : a < 1 ? g.month === a + 12 : g.month === a;
                var u = new Date(g.year, g.month - 1, g.day);
                g.isPassDay = r.getTime() > u.getTime(), g.isToday = r.getTime() === u.getTime();
                var D = e(u), y = 1 === D.lunarDay ? D.lunarMonthCn : D.lunarDayCn;
                g.lunar = D.lunarTerm ? D.lunarTerm : y, null !== this.data.spot && (g.spot = this.data.spot[g.dateString]), 
                n[c] = g;
            }
            return n;
        },
        initWeekList: function(t, a, n, s, r) {
            var h = [], d = new Date(t, a - 1, n), c = new Date(), l = new Date(c.getFullYear(), c.getMonth(), c.getDate()), g = d.getDay(), u = 1 - r;
            i.info("startWeek ".concat(d, " ").concat(g, " ").concat(u, " ").concat(r), o), 
            6 === g && 6 === this.offsetDay && (u += 7), 0 === g && 0 === r && (u -= 7);
            for (var D = 0; D < 7; D++) {
                var y = new Date(d);
                y.setDate(d.getDate() + 7 * s - g + D + u);
                var f = {};
                (f = {
                    day: y.getDate(),
                    month: y.getMonth() + 1,
                    year: y.getFullYear(),
                    dateString: this.formatTime(y)
                }).isCurrentMonth = !0;
                var p = new Date(f.year, f.month - 1, f.day);
                f.isPassDay = l.getTime() > p.getTime(), f.isToday = l.getTime() === p.getTime();
                var v = e(p), m = 1 === v.lunarDay ? v.lunarMonthCn : v.lunarDayCn;
                f.lunar = v.lunarTerm ? v.lunarTerm : m, null !== this.data.spot && (f.spot = this.data.spot[f.dateString]), 
                h[D] = f;
            }
            return i.info("startWeek 2 ".concat(JSON.stringify(h), " ").concat(d), o), h;
        },
        updateSpot: function() {
            var t = this;
            null !== this.data.spot && (this.data.dateListArray.forEach(function(e) {
                e.forEach(function(e) {
                    var a = t.data.spot[e.dateString];
                    e.spot = a;
                });
            }), this.setData({
                dateListArray: this.data.dateListArray
            }));
        },
        updateDate: function() {
            if (i.info("updateDate ".concat(this.data.date), o), console.log("========888888======", this.data.date), 
            null !== this.data.date) {
                var t = new Date(this.data.date.year, this.data.date.month - 1, this.data.date.day);
                i.info("updateDate ".concat(t), o);
                var e = {
                    year: t.getFullYear(),
                    month: t.getMonth() + 1,
                    day: t.getDate(),
                    dateString: this.formatTime(t)
                };
                this.setData({
                    selectDate: e
                }), i.info("updateDate ".concat(JSON.stringify(e), " "), o), this.dateInit(e.year, e.month, e.day), 
                this.triggerDateChange(e, !1);
            }
        },
        updateEndDate: function() {
            if (this.data.allday) {
                var t = this.oldEndDate || {
                    year: 0,
                    month: 0,
                    day: 0
                }, e = t.year, a = t.month, i = t.day, n = this.data.endDate, o = n.year, s = n.month, r = n.day;
                if (e !== o || a !== s || i !== r) {
                    var h = this.data.selectDate, d = h.year, c = h.month, l = h.day;
                    this.dateInit(d, c, l);
                }
            }
        },
        onTouchStart: function(t) {
            s = t.touches[0].pageX, r = t.touches[0].pageY;
        },
        onTouchMove: function(t) {
            if (!this.data.foldDisable) {
                var e = t.changedTouches[0].pageX, a = t.changedTouches[0].pageY, i = e - s, n = a - r;
                Math.abs(i) < Math.abs(n) && (n < 0 ? this.data.open && this.onOpenChange() : this.data.open || this.onOpenChange());
            }
        },
        onTouchEnd: function() {
            s = 0, r = 0;
        },
        onTouchCancel: function() {
            s = 0, r = 0;
        },
        updateBeginDay: function() {
            console.log("updateBeginDay");
            var t = 0;
            switch (this.data.beginDay) {
              case "Monday":
                t = 1;
                break;

              case "Saturday":
                t = 6;
                break;

              default:
                t = 0;
            }
            if (this.offsetDay !== t) {
                this.offsetDay = t;
                var e = "日一二三四五六".substring(t) + "日一二三四五六".substring(0, t);
                if (this.data.headerDayList.toString().replace(/,/g, "") !== e) {
                    var a = e.split("");
                    this.setData({
                        headerDayList: a
                    });
                    var i = this.data.selectDate.year, n = this.data.selectDate.month, o = this.data.selectDate.day;
                    this.dateInit(i, n, o);
                }
            }
        },
        displayItemConfiguration: function() {
            var t = a.getValueFromLocalStorage("show_lunar_calendar");
            "" !== t && void 0 !== t && this.setData({
                showLunarCalendar: t
            });
            var e = a.getValueFromLocalStorage("show_holiday");
            "" !== e && void 0 !== e && this.setData({
                showHoliday: e
            });
            var i = a.getValueFromLocalStorage("only_kalends_fifteen");
            "" !== i && void 0 !== i && this.setData({
                onlyKalendsFifteen: i
            });
        },
        getSwiperHeight: function() {
            if (this.data.swiperHigh) return this.data.swiperHigh;
            return 86 * (this.data.open ? 6 : 1);
        },
        getMonthTitle: function(t) {
            var e = t.selectDate, a = new Date().getFullYear() === e.year, i = "".concat(e.year, "年").concat(e.month, "月"), n = "".concat(e.month, "月");
            return a ? n : i;
        },
        toPreItem: function() {
            var t = this.data.swiperPosition - 1;
            t < 0 || (this.setData({
                swiperPosition: t
            }), this.clickswitch = !0);
        },
        toNextItem: function() {
            var t = this.data.swiperPosition + 1;
            t > 2 || (this.setData({
                swiperPosition: t
            }), this.clickswitch = !0);
        }
    },
    attached: function() {
        this.setData({
            open: this.data.foldDisable
        }), this.offsetDay = 0;
    },
    observers: {
        spot: function() {
            this.updateSpot();
        },
        date: function() {
            this.updateDate();
        },
        endDate: function() {
            this.updateEndDate();
        },
        beginDay: function() {
            this.updateBeginDay();
        },
        todayChange: function(t) {
            t && this.dateInit(t.year, t.month + 1, t.day);
        },
        "swiperHigh, open, showHoliday, showLunarCalendar": function() {
            this.setData({
                swiperHeight: this.getSwiperHeight()
            });
        },
        open: function() {
            var t = this.data.selectDate.year, e = this.data.selectDate.month, a = this.data.selectDate.day;
            this.dateInit(t, e, a);
        },
        openStatus: function(t) {
            this.setData({
                open: t
            });
        }
    }
});