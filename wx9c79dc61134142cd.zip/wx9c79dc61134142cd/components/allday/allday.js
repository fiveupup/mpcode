Component({
    properties: {
        dataList: Array
    },
    data: {
        scrollTop: 0,
        overTime: !1
    },
    methods: {
        onScheduleClick: function(e) {
            var t = e.currentTarget.dataset, a = t.schedule, i = t.index;
            this.triggerEvent("clickSchedule", {
                schedule: a,
                index: i
            });
        },
        judgeIsOverTime: function(e) {
            var t = new Date(), a = new Date(t.getFullYear(), t.getMonth(), t.getDate()), i = e[0].event.endTime, r = new Date(i);
            return new Date(r.getFullYear(), r.getMonth(), r.getDate()) < a;
        }
    },
    observers: {
        dataList: function() {
            var e = this.judgeIsOverTime(this.data.dataList);
            this.setData({
                scrollTop: 0,
                overTime: e
            });
        }
    },
    lifetimes: {
        attached: function() {
            var e = this.judgeIsOverTime(this.data.dataList);
            this.setData({
                overTime: e
            });
        }
    }
});