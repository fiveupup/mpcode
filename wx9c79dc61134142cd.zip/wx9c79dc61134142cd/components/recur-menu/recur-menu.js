Component({
    properties: {
        show: {
            type: Boolean,
            value: !1
        },
        recurMenuItems: {
            type: Array,
            value: []
        },
        type: {
            type: String,
            value: "delete"
        }
    },
    data: {},
    options: {
        addGlobalClass: !0
    },
    methods: {
        prevent: function() {},
        hide: function() {
            this.setData({
                show: !1
            });
        },
        cancel: function() {
            this.data.show && (this.triggerEvent("cancel"), this.hide());
        },
        confirm: function(t) {
            this.triggerEvent("confirm", t.target.dataset);
        }
    }
});