var t = require("../../utils/Dayjs.js"), e = require("../../utils/beacon/report_data");

Component({
    properties: {
        show: {
            type: Boolean,
            value: !1
        },
        joinData: {
            type: Object,
            value: void 0
        }
    },
    methods: {
        close: function() {
            this.setData({
                show: !1
            });
        },
        onCopyMeetingCode: function() {
            e.dataReport("e#join_popup#copy_meeting_code#click"), wx.setClipboardData({
                data: this.copy,
                success: function() {
                    wx.hideToast(), wx.showToast({
                        icon: "none",
                        title: "会议号已复制"
                    });
                }
            }), this.setData({
                show: !1
            });
        },
        jumpToMeetingProgram: function() {
            e.dataReport("e#join_popup#join_meeting#click");
            var t = this.data.meetingCode && this.data.meetingCode.replaceAll(" ", "") || "";
            wx.navigateToMiniProgram({
                appId: "wx33fd6cdc62520063",
                path: "pages/index/index?chn=".concat("TencentCalendar", "&code=").concat(t),
                extraData: {},
                envVersion: "release",
                success: function(t) {
                    console.log("成功跳转到会议小程序", t);
                },
                fail: function(t) {
                    console.error("launch Tencent WeMeet Miniprogram failed: ".concat(t.errMsg));
                }
            });
        },
        numToString: function(t) {
            return t < 10 ? "0".concat(t) : "".concat(t);
        }
    },
    observers: {
        joinData: function() {
            var n = this.data.joinData;
            if (null !== n) {
                e.dataReport("e#join_popup#all#explore");
                for (var o = "", a = n.meetingCode.split(""), i = 0, c = 0; c < a.length; c++) o += a[c], 
                3 === (i += 1) && (o = "".concat(o, " "), i = 0);
                var s = new Date(n.startTime), r = new Date(n.endTime), u = "".concat(this.numToString(s.getMonth() + 1)), p = "".concat(this.numToString(s.getDate())), d = "".concat(this.numToString(s.getHours())), g = "".concat(this.numToString(s.getMinutes())), m = "".concat(d, ":").concat(g), l = "".concat(this.numToString(r.getHours())), h = "".concat(this.numToString(r.getMinutes())), T = "".concat(l, ":").concat(h), f = t(n.endTime).diff(t(n.startTime), "minute"), D = [ "周日", "周一", "周二", "周三", "周四", "周五", "周六" ][s.getDay()];
                this.copy = "会议ID：".concat(o), this.setData({
                    show: !0,
                    meetingCode: o,
                    summary: n.summary,
                    startDate: "".concat(u, "月").concat(p, "日"),
                    startTime: m,
                    endTime: T,
                    duration: "".concat(f, "分钟"),
                    startWeek: D
                });
            }
        }
    }
});