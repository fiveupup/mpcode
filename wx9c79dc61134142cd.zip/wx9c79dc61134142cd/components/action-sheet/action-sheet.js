Component({
    properties: {
        show: {
            type: Boolean,
            value: !1
        },
        itemColor: {
            type: String
        },
        actions: {
            type: Array,
            value: [],
            observer: function(t) {
                var e = this;
                this.setData({
                    list: t.map(function(t) {
                        return {
                            text: t.text,
                            type: t.type || "",
                            color: t.color || e.properties.itemColor || "inherit"
                        };
                    })
                });
            }
        }
    },
    data: {
        list: []
    },
    options: {
        addGlobalClass: !0
    },
    methods: {
        prevent: function() {},
        hide: function() {
            this.setData({
                show: !1
            });
        },
        chooseItem: function(t) {
            this.data.show && (this.triggerEvent("pick", t.target.dataset), this.hide());
        },
        cancel: function() {
            this.data.show && (this.triggerEvent("cancel"), this.hide());
        }
    }
});