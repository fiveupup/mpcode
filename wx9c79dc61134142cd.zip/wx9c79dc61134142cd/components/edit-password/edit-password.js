Component({
    options: {
        multipleSlots: !0
    },
    properties: {
        cancelText: {
            type: String,
            value: "取消"
        },
        confirmText: {
            type: String,
            value: "确定"
        }
    },
    data: {
        isShow: !1,
        inputPrompt: "请输入腾讯会议密码",
        password: ""
    },
    methods: {
        hideDialog: function() {
            this.setData({
                isShow: !this.data.isShow
            });
        },
        showDialog: function() {
            this.setData({
                isShow: !this.data.isShow
            });
        },
        getInputPassword: function() {
            return this.data.password;
        },
        onInputTitle: function(t) {
            this.setData({
                password: t.detail.value
            });
        },
        _cancelEvent: function() {
            this.triggerEvent("cancelEvent");
        },
        _confirmEvent: function() {
            this.triggerEvent("confirmEvent");
        }
    }
});