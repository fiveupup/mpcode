module.exports = {
    timeToHeight: function(t) {
        var e = 26, o = t || 0;
        t > 30 && (e += 15 * Math.ceil((o - 30) / 15));
        return 2 * e;
    },
    timeToTop: function(t) {
        return 30 * Math.floor(t / 15);
    }
};