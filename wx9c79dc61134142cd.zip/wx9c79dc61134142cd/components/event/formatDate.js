var e = require("../../@babel/runtime/helpers/classCallCheck"), t = require("../../@babel/runtime/helpers/createClass");

var n = function() {
    function n() {
        e(this, n), this.startTime = 0, this.endTime = 0, this.columns = [];
    }
    return t(n, [ {
        key: "insert",
        value: function(e) {
            this.findColumn(e).insert(e);
        }
    }, {
        key: "findColumn",
        value: function(e) {
            for (var t = this.columns.length, n = 0; n < t; n++) {
                var s = this.columns[n];
                if (r(s, e)) return s;
            }
            if (n === t) {
                var l = new i();
                return this.columns.push(l), l;
            }
        }
    }, {
        key: "layout",
        value: function() {
            for (var e = this.columns.length, t = 0; t < e; t++) this.columns[t].layout(t, e);
        }
    } ]), n;
}(), i = function() {
    function n() {
        e(this, n), this.startTime = 0, this.endTime = 0, this.cells = [];
    }
    return t(n, [ {
        key: "insert",
        value: function(e) {
            for (var t = this.cells.length, n = 0; n < t; n++) {
                var i = this.cells[n];
                e.event.startTime >= i.event.endTime && (this.cells.splice(n, 0, e), this.updatecellTimes());
            }
            n === t && (this.cells.push(e), this.updatecellTimes());
        }
    }, {
        key: "updatecellTimes",
        value: function() {
            this.startTime = this.cells[0].event.startTime, this.endTime = this.cells[this.cells.length - 1].event.endTime;
        }
    } ]), n;
}();

function s(e, t) {
    for (var n = null, i = t, s = 0; s < i.length; s++) if (i[s].startTime <= e.event.startTime && e.event.startTime < i[s].endTime) return n = i[s], 
    e.event.endTime > i[s].endTime && (i[s].endTime = e.event.endTime), n;
    return n;
}

function r(e, t) {
    return t.event.startTime >= e.endTime ? e : null;
}

module.exports = {
    buildCOE: function(e) {
        for (var t = [], i = function(e) {
            return e.sort(function(e, t) {
                return e.startTimeObj.times - t.startTimeObj.times;
            });
        }(e), r = 0, l = i.length; r < l; r++) {
            var u = i[r], m = s(u, t);
            null === m && ((m = new n()).startTime = u.event.startTime, m.endTime = u.event.endTime, 
            t.push(m)), m.insert(u);
        }
        return t;
    }
};