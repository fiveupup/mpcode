require("../../@babel/runtime/helpers/Objectvalues");

var t, e = require("./positionSize"), i = require("./formatDate"), a = require("../../sdk/logger/calendar_logger");

Component({
    properties: {
        containerHeight: Number,
        containerTop: Number,
        dayList: Array,
        eventArr: Array,
        scrollTargetEvent: Object,
        calUidList: Array,
        newEventId: String
    },
    data: {
        dataListArray: [],
        lineTop: 0,
        timeLineList: [],
        swiperPosition: 1,
        swiperDuration: 150,
        guideTipsShow: 0,
        eventId: ""
    },
    methods: {
        formatNumber: function(t) {
            return t > 9 ? t : "0".concat(t);
        },
        builDataArr: function() {
            var t = this, e = this.data.eventArr, a = [];
            return e.forEach(function(e) {
                var r = e.filter(function(t) {
                    var e = t.event, i = t.dayTime;
                    if (e.isAllDay) return !1;
                    var a = new Date(e.startTime), r = new Date(a.getFullYear(), a.getMonth(), a.getDate()), s = new Date(e.endTime), n = new Date(s.getFullYear(), s.getMonth(), s.getDate());
                    if (r.getTime() !== i && n.getTime() !== i) return !1;
                    var o = r.getTime() === i ? a.getHours() : 0, d = r.getTime() === i ? a.getMinutes() : 0, u = n.getTime() === i ? s.getHours() : 24, l = n.getTime() === i ? s.getMinutes() : 0;
                    return (0 !== o || 0 !== d || 24 !== u || 0 !== l) && (t.startTimeObj = {
                        hours: o,
                        minutes: d
                    }, t.endTimeObj = {
                        hours: u,
                        minutes: l
                    }, t.cellObj = {
                        order: 0,
                        count: 0
                    }, !0);
                });
                r.forEach(function(e) {
                    e.startTimeObj.times = 3600 * e.startTimeObj.hours + 60 * e.startTimeObj.minutes, 
                    e.endTimeObj.times = 3600 * e.endTimeObj.hours + 60 * e.endTimeObj.minutes;
                    var i = t.formatNumber(e.startTimeObj.hours), a = t.formatNumber(e.startTimeObj.minutes), r = t.formatNumber(e.endTimeObj.hours), s = t.formatNumber(e.endTimeObj.minutes), n = "".concat(i, ":").concat(a), o = "".concat(r, ":").concat(s);
                    e.timeRange = "".concat(n, "-").concat(o), e.endTimeObj.times - e.startTimeObj.times < 1800 && (e.endTimeObj.times = e.startTimeObj.times + 1800, 
                    e.endTimeObj.hours = Math.floor(e.endTimeObj.times / 60 / 60), e.endTimeObj.minutes = Math.floor((e.endTimeObj.times - 60 * e.endTimeObj.hours * 60) / 60)), 
                    24 === e.endTimeObj.hours && (e.endTimeObj.minutes = 0);
                });
                var s = (0, i.buildCOE)(r);
                a.push(s);
            }), a;
        },
        buildDataListArray: function(t) {
            var i = new Date(), a = this.buildScrollTop(), r = a.todayTimeTop, s = a.scrollViewTop, n = [], o = this.builDataArr(), d = this.data.scrollTargetEvent;
            void 0 !== d && (this.data.scrollTargetEvent = void 0);
            for (var u = -1, l = [], h = 0; h < t; h++) {
                for (var c = [], T = this.data.dayList[h], m = o[h], v = new Date(T.year, T.month - 1, T.day), g = v.getFullYear() === i.getFullYear() && v.getMonth() === i.getMonth() && v.getDate() === i.getDate(), p = 0; p < m.length; p++) {
                    var f = m[p].columns, w = f.length;
                    console.log("event scheduleList", f);
                    for (var b = 0; b < f.length; b++) for (var D = f[b].cells, S = b > 0 ? 8 * b : 0, y = 8 * (w - 1), L = Math.max((624 - y) / w, 8), O = L * b + S, j = 0; j < D.length; j++) {
                        var A = D[j], E = (0, e.timeToTop)(A.startTimeObj.times / 60), M = (0, e.timeToHeight)((A.endTimeObj.times - A.startTimeObj.times) / 60), I = A.event.endTime < i, x = A.startTimeObj.times - (3600 * i.getHours() + 60 * i.getMinutes() + i.getSeconds()) <= 900, N = 1 === A.event.eventType || 2 === A.event.eventType, C = 4 === A.event.calType, G = A.event, H = G.responseStatus, J = G.role, P = 2 === H, k = 4 === H || 0 === H && 2 === J, F = g && N && x && !I && 1 === f.length && 0 === O && M >= 80 && 624 === L;
                        if (d && (d.eventId === A.event.eventId || d.eventId === A.event.parentEventId)) {
                            var q = wx.getSystemInfoSync().windowWidth, Y = 120 * A.startTimeObj.hours / 750 * q, U = .16 * q;
                            u = Math.max(Math.round(Y - U), 0);
                        }
                        var V = 0, W = N && !F && L >= 56 && M >= 112, R = C, z = L >= 296 && M >= 112;
                        M > 112 && (V = 36 * parseInt((M - 76) / 36, 10));
                        var _ = {
                            show: O < 624,
                            width: L,
                            height: M,
                            top: E,
                            left: O,
                            multiTitle: V,
                            showCreator: -1 === this.data.calUidList.indexOf(A.event.creatorUid),
                            showAddress: M >= 112 && A.event.location.address && 624 === L,
                            isOverTime: I,
                            showJoin: F,
                            showTime: z,
                            showTitle: L >= 45,
                            showDtlMeetingLogo: W,
                            showTitleMeetingLogo: N && !F && L >= 56 && M < 112,
                            showShareLogo: R,
                            isReject: P,
                            isPending: k
                        };
                        A.left = O, A.event.repeatStr = 1 === A.event.eventType ? A.event.rruleDesc || "周期" : A.event.rruleDesc, 
                        _.titleMaxWidth = _.showJoin ? 450 : 620, c.push({
                            ui: _,
                            data: A
                        }), F && l.push({
                            day: T,
                            data: A
                        });
                    }
                }
                n.push({
                    schduleList: c,
                    todayTime: {
                        show: g,
                        top: r
                    },
                    scrollTop: s
                });
            }
            return u >= 0 && (n.forEach(function(t) {
                t.scrollTop = u;
            }), this.data.userScrollDraged = !0, this.data.userScrollTop = u), l.length > 0 && this.triggerEvent("showJoinMeeting", l), 
            this.addGuideTipsShowStatus(n), n;
        },
        buildScrollTop: function() {
            var t = wx.getSystemInfoSync().windowWidth, e = new Date(), i = 120 * e.getHours(), a = i / 750 * t, r = .16 * t;
            return {
                todayTimeTop: i + 120 * e.getMinutes() / 60 + 120 * e.getSeconds() / 60 / 60 - 7,
                scrollViewTop: this.data.userScrollDraged ? this.data.userScrollTop : Math.max(Math.round(a - r), 0)
            };
        },
        buildTimeLineList: function() {
            for (var t = [], e = 0; e < 25; e++) t[e] = "".concat(this.formatNumber(e), ":00");
            return t;
        },
        updateDataListArray: function(t) {
            if ("" !== this.data.newEventId && this.data.newEventId !== this.newEventId) return this.setData({
                dataListArray: this.buildDataListArray(t),
                swiperPosition: 1,
                swiperDuration: 150,
                eventId: this.data.newEventId
            }), void (this.newEventId = this.data.newEventId);
            this.setData({
                dataListArray: this.buildDataListArray(t),
                swiperPosition: 1,
                swiperDuration: 150,
                eventId: ""
            });
        },
        onSwiperAnimationFinish: function(t) {
            var e = t.detail.current;
            if (e !== this.data.swiperPosition) {
                this.setData({
                    swiperDuration: 0
                }), this.triggerEvent("swiperchange", e < this.data.swiperPosition);
                var i = this.data.dayList[e];
                this.triggerEvent("datechange", i);
            }
        },
        onSwiperTransitionStart: function() {
            var t = this;
            if (this.data.userScrollDraged) {
                var e = this.data.dataListArray, i = !1;
                e.forEach(function(e) {
                    e.scrollTop !== t.data.userScrollTop && (e.scrollTop = t.data.userScrollTop, i = !0);
                }), i && this.setData({
                    dataListArray: e
                });
            }
        },
        onScrollChange: function(t) {
            this.data.userScrollDraged && (this.data.userScrollTop = t.detail.scrollTop);
        },
        onScrollDrag: function(t) {
            this.data.userScrollDraged || (this.data.userScrollDraged = !0, this.data.userScrollTop = t.detail.scrollTop);
        },
        onEventListScheduleClick: function(t) {
            var e = t.currentTarget.dataset, i = e.schedule, a = e.index;
            this.triggerEvent("clickSchedule", {
                schedule: i,
                index: a
            });
        },
        onEventListJoinMeetingClick: function(t) {
            this.triggerEvent("clickJoinMeeting", t.currentTarget.dataset.schedule);
        },
        addGuideTipsShowStatus: function(t) {
            var e = !1;
            Object.values(t).forEach(function(t) {
                if (!e && !1 !== t.todayTime.show) {
                    var i = t.schduleList;
                    Object.values(i).forEach(function(t) {
                        if (!e) return "我能用腾讯日历做什么？" === t.data.title && t.ui.width > 500 ? (t.ui.showGuideTips = !0, 
                        void (e = !0)) : void 0;
                    });
                }
            }), a.info("addGuideTipsShowStatus ".concat(JSON.stringify(t)), "event.js");
        },
        showDetailTips: function() {
            this.setData({
                guideTipsShow: 1
            });
        },
        hideDetailTips: function() {
            var t = this;
            1 === this.data.guideTipsShow ? (this.setData({
                guideTipsShow: 2
            }), setTimeout(function() {
                t.setData({
                    guideTipsShow: 0
                });
            }, 600)) : this.setData({
                guideTipsShow: 0
            });
        },
        onDetailGuideTipsTab: function() {
            this.triggerEvent("DetailGuideTipsTab", {});
        },
        reSetTimeLineTop: function() {
            var e = this;
            t && clearInterval(t);
            var i = this.buildScrollTop().todayTimeTop;
            this.setData({
                lineTop: i
            }), t = setInterval(function() {
                !function() {
                    var t = e.buildScrollTop().todayTimeTop;
                    e.setData({
                        lineTop: t
                    });
                }();
            }, 9e5);
        }
    },
    lifetimes: {
        attached: function() {
            if (this.data.eventArr && this.data.eventArr.length > 0) {
                this.updateDataListArray(this.data.eventArr.length);
                var t = this.buildTimeLineList();
                this.setData({
                    timeLineList: t
                });
            } else {
                for (var e = this.buildTimeLineList(), i = [], a = this.buildScrollTop(), r = a.todayTimeTop, s = a.scrollViewTop, n = 0; n < 3; n++) {
                    var o = 1 === n;
                    i.push({
                        todayTime: {
                            show: o,
                            top: r
                        },
                        scrollTop: s
                    });
                }
                this.setData({
                    timeLineList: e,
                    dataListArray: i
                });
            }
        },
        ready: function() {
            this.reSetTimeLineTop();
        },
        detached: function() {
            clearInterval(t);
        }
    },
    observers: {
        eventArr: function(t) {
            this.updateDataListArray(t.length);
        }
    },
    pageLifetimes: {
        show: function() {
            this.reSetTimeLineTop();
        }
    }
});