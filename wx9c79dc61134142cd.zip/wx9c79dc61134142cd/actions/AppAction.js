require("../@babel/runtime/helpers/Arrayincludes"), console.log("AppAction.js loaded start");

var e = require("../utils/Dispatcher"), t = require("../stores/AppStore"), o = require("../stores/UserStore"), n = require("../auth/AuthController"), r = require("../sdk/logger/calendar_logger"), i = require("../constants/AppType"), s = require("../utils/util"), a = require("../utils/beacon/report_data"), p = "AppAction.js", c = {
    inited: !1,
    init: function() {
        this.inited || (this.doInit(), this.addListener(), this.updateSysInfo(), this.inited = !0);
    },
    doInit: function() {
        t.init(), o.init(), n.init();
    },
    updateSysInfo: function() {
        console.log("update sysInfo, initializing...");
        var t = {}, o = !1, n = !1;
        try {
            o = (t = wx.getSystemInfoSync()) && "wxwork" === t.environment, n = this.isDeviceSupported(t), 
            o && r.setConfig({
                platformType: "wxwork"
            }), e.dispatch({
                type: i.INIT_SYSTEM_INFO_SUCC,
                payload: {
                    data: {
                        sysInfo: t,
                        isSupportDevice: n
                    }
                }
            }), r.info("systemInfo: ".concat(JSON.stringify(t)), p);
        } catch (o) {
            r.error("Get system info falied: ".concat(JSON.stringify(o)), p), e.dispatch({
                type: i.INIT_SYSTEM_INFO_FAIL,
                payload: {
                    data: t
                }
            }), wx.showToast({
                title: o.message,
                icon: "none"
            });
        }
        if (o) {
            r.infoAll("wxwork detected! use wx.qy.xxx API to get wxwork client version only", p);
            try {
                wx.qy.getSystemInfo({
                    success: function(t) {
                        var o = s.isSupportQYWX(t.version);
                        e.dispatch({
                            type: i.QYWX_VERSION_CHANGE,
                            payload: {
                                data: t.version
                            }
                        }), r.infoAll("wxwork version: ".concat(t.version), p), a.dataReport("mp_wxwork_support", {
                            wxworkver: t.version,
                            support: o ? "Y" : "N"
                        });
                    },
                    fail: function(e) {
                        throw e;
                    }
                });
            } catch (e) {
                var c = e && e.errMsg || e;
                r.error("wx.qy.getSystemInfo API failed: ".concat(c), p);
            }
        }
    },
    updateCurrEnv: function(t) {
        e.dispatch({
            type: i.CURR_ENV_CHANGE,
            payload: t
        });
    },
    addListener: function() {},
    isDeviceSupported: function() {
        var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {}, t = (e.platform || "").toLowerCase(), o = (e.system || "").toLowerCase().replace(/^([a-z]+).*$/, "$1"), n = (e.model || "").toLowerCase(), i = [ "ios", "android", "devtools" ], s = !i.includes(t), c = [ "macos", "windows" ], d = c.includes(o), u = [ "pad", "ipad" ], l = 0 < u.filter(function(e) {
            return new RegExp("\\b".concat(e, "\\b")).test(n);
        }).length;
        return (s || d || l) && (a.dataReport("mp_banned_devices", {
            ban_platform: t,
            ban_system: o,
            ban_model: n
        }), r.warn("Device running our mp is not supported: platform=".concat(t, ", system=").concat(o, ", model=").concat(n), p)), 
        !s && !d && !l;
    },
    pageExposed: function(e) {
        e ? a.dataReport("mp_page_onload", {
            name: e
        }) : r.error("name is required for 'pageExposed', but got: ".concat(e), p);
    },
    assertReport: function() {}
};

console.log("AppAction.js loaded end"), module.exports = c;