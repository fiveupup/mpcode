var e = require("../@babel/runtime/helpers/objectSpread2"), a = require("../@babel/runtime/helpers/classCallCheck"), n = require("../@babel/runtime/helpers/createClass");

console.log("BeaconClient.js loaded start");

var r = require("../configs/AppConfig"), o = r.MP_CALENDAR_VERSION.replace(/^(\d+\.\d+\.\d+)(\.\d+)*$/, "$1");

var i = function() {
    function i() {
        a(this, i);
    }
    return n(i, [ {
        key: "init",
        value: function() {
            var e;
            this.commParams = {
                app_main_version: o,
                env_id: "",
                sdk_id: "",
                background: "N/A",
                network_type: "network_type",
                wx_app_id: r.APPID,
                app_id: "",
                wecalendar_platform: "MiniProgram",
                unique_report_id: "",
                os_ver: "",
                branch: "",
                device_id: (e = wx.getStorageSync("beacon_u"), e || (e = (1e6 * Date.now() + Math.floor(1e6 * Math.random())).toString(36), 
                wx.setStorageSync("beacon_u", String(e)), e)),
                app_publish_channel: "wechat",
                device_name: "",
                device_model: "",
                app_uid: "",
                language: "",
                manufacture: "",
                client_ip: "",
                server_ip: "",
                account_type: "",
                wx_openid: "",
                aid_ticket: "",
                taid_ticket: "",
                instance_id: "8",
                wecalendar_app_version: r.MP_CALENDAR_VERSION,
                package_type: ""
            };
            var a = this;
            wx.getNetworkType({
                success: function(e) {
                    var n = e.networkType;
                    a.commParams.network_type = n;
                }
            });
        }
    }, {
        key: "setConfig",
        value: function() {
            var a = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {}, n = a.sysInfo, r = a.openId, o = a.releaseChannel, i = a.appMainVersion, t = a.appUid, s = a.appId, p = a.packageType, c = n || {}, l = c.system, _ = c.model, d = c.version, u = c.SDKVersion, x = c.language;
            console.log("sysInfo: ".concat(JSON.stringify(n)));
            var m = {};
            r && (m.wx_openid = r), o && (m.app_publish_channel = o), i && (m.app_main_version = i), 
            t && (m.app_uid = t), s && (m.app_id = s), l && (m.os_ver = l), _ && (m.device_model = _), 
            d && (m.wxVersion = d), u && (m.mpVersion = u), x && (m.language = x), p && (m.package_type = p), 
            this.commParams = e(e({}, this.commParams), m), console.log("commParams: ".concat(JSON.stringify(this.commParams)));
        }
    }, {
        key: "getPackageType",
        value: function(e) {
            return "develop" === e ? "debug" : "trial" === e ? "dev_release" : "release" === e ? "publish_release" : "unknown";
        }
    } ]), i;
}();

module.exports = new i(), module.exports.getGuid = function() {
    var e = new Date().getTime();
    return "xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx".replace(/[x]/g, function(a) {
        var n = (e + 16 * Math.random()) % 16 | 0;
        return e = Math.floor(e / 16), ("x" === a ? n : 3 & n | 8).toString(16);
    });
}, console.log("BeaconClient.js loaded end");