var _ = require("../utils/util").mirror;

module.exports = _({
    INIT_SYSTEM_INFO_SUCC: null,
    INIT_SYSTEM_INFO_FAIL: null,
    QYWX_VERSION_CHANGE: null,
    INIT_ACCOUNT_INFO_SUCC: null,
    INIT_ACCOUNT_INFO_FAIL: null,
    SWITCH_EVN_SUCC: null,
    SWITCH_EVN_FAIL: null,
    CURR_ENV_CHANGE: null,
    APP_SWITCH_TO_FOREGROUND: null,
    APP_SWITCH_TO_BACKGROUND: null
});