module.exports = {
    CalendarType: {
        SHARED: 4
    },
    AccessType: {
        SCHEDULE: 1,
        VIEW: 3,
        SHARE_WITH_SCHEDULE: 5,
        SHARE_WITH_VIEW: 7,
        EDIT: 15
    }
};