module.exports = {
    AccessState: {
        NeverAsk: 0,
        AskedButDenied: 1,
        Permitted: 2
    },
    MeetingState: {
        CANCELLED: 1,
        DELETED: 3,
        NOSTATE: 6,
        RECYCLED: 7,
        getReadableMeetingState: function(e) {
            var t = "unknown(".concat(e, ")");
            switch (e) {
              case this.CANCELLED:
                t = "已取消";
                break;

              case this.DELETED:
                t = "已删除";
                break;

              case this.NOSTATE:
                t = "无状态";
                break;

              case this.RECYCLED:
                t = "已结束";
            }
            return t;
        }
    },
    MediaRoomState: {
        OUT: 0,
        IN: 1,
        RECONNECTING: 2,
        RESTARTING: 3,
        INTERRUPTED: 4,
        REDIRECTING: 5,
        getReadableState: function(e) {
            switch (e) {
              case 0:
                return "不在媒体房间中";

              case 1:
                return "在媒体房间中";

              case 2:
                return "媒体房间重连中...";

              case 3:
                return "媒体房间重启推流中";

              case 4:
                return "推流被系统来电或者微信VOIP中断";

              case 5:
                return "正在重定向中...";

              default:
                return "Unknown media room state: ".concat(e);
            }
        }
    }
};