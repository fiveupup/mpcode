var e = require("@babel/runtime/helpers/regeneratorRuntime"), n = require("@babel/runtime/helpers/asyncToGenerator");

require("@babel/runtime/helpers/Arrayincludes");

var o = require("./actions/AppAction"), t = require("./sdk/logger/calendar_logger"), a = require("./stores/UserStore"), c = require("./stores/AppStore"), i = require("./constants/UserType"), s = require("./constants/AppType"), r = require("@tencent/calendar-js-sdk").CalendarSDK, g = require("./auth/AuthController"), p = require("./configs/AppConfig"), u = require("@tencent/wecalendar_web_base_report"), l = require("./utils/beacon/report_data"), d = require("@tencent/wx-queue-request");

require("./utils/emotion");

App({
    onLaunch: function() {
        var e = this;
        d({
            lowPriority: [ /aegis\.qq\.com/, /otheve\.beacon\.qq\.com/, /reporttest\.calendar\.tencent\.com/, /report\.calendar\.tencent\.com/ ],
            maxWaitingTime: 3e3,
            maxQueueLen: 8,
            fullThreshold: 8
        }), wx.onAppRoute(function(e) {
            var n = e.query.targeturl || e.query.url;
            "/" !== (n = n ? decodeURIComponent(n) : "")[0] && (n = "/".concat(n));
            var o = n.match(/(\/accept_invite)\/\S+/) || n.match(/(\/service_booking\/detail)\/\S+/) || n.match(/ServiceBooking\/pages\/ServiceBookingPartResult\/index\/service_booking\/participantBookingResult\/\S+/) || n.match(/ServiceBooking\/pages\/ServiceBookingList\/index\/service_booking\/bookingList\/\S+/) || n.match(/ServiceBookingConfirm\/pages\/ServiceBookingPartResult\/index\/service_booking\/participantBookingResult\/\S+/) || n.match(/ServiceBookingList\/pages\/ServiceBookingList\/index\/service_booking\/bookingList\/\S+/) || [ "", n ];
            n = o[1].split("?")[0];
            var t = e.path + n;
            "/" === t[t.length - 1] && (t = t.slice(0, -1)), u.onVisitNextPage(t);
        }), this.setUpLogger({
            openId: "default_uid",
            wxLogEnable: !0,
            tamLogEnable: !0,
            isDevelop: !1,
            version: p.MP_CALENDAR_VERSION
        }), this.globalData.sysInfo = wx.getSystemInfoSync();
        var n = this.globalData.sysInfo, t = n.model, i = void 0 === t ? "" : t, s = n.system, r = (void 0 === s ? "" : s).toLowerCase(), g = r.includes("ios") || r.includes("android");
        this.globalData.isIpx = i.includes("iPhone X") || i.includes("iPhone 1"), this.globalData.isMobile = g, 
        a.addEventListener(this.onUserStoreChange), c.addEventListener(this.onAppStoreChange), 
        o.init(), this.getEnvVersion().then(function(n) {
            console.log("envVersion is ".concat(n, ".")), e.setUpLogger({
                isDevelop: !0
            }), l.dataReport("dau", {});
        }), this.initCalendarSDK();
    },
    onShow: function(e) {
        console.log("app onShow options:", e), this.globalData.options = e;
    },
    loadFontFace: function() {
        wx.loadFontFace({
            global: !0,
            family: "iconfont",
            source: 'url("https://cdn3.codesign.qq.com/icons/8ALwE9VKEd0X1Dp/latest/iconfont.ttf")',
            fail: function(e) {
                console.log("loadFontFace fail:", e);
            }
        });
    },
    onUserStoreChange: function(e) {
        switch (e) {
          case i.ACCOUNT_INFO_INIT:
            t.infoAll("onUserStoreChange action: ".concat(e), "app.js"), t.infoAll("ACCOUNT_INFO_INIT appId: ".concat(a.appId, ", uid: ").concat(a.userId), "app.js"), 
            this.setUpLogger({
                openId: a.openId
            }), r.getInstance().setAccountConfig({
                appId: a.appId,
                appUID: a.userId,
                cgiToken: a.cgiToken
            }), l.dataReport("dau", {});
            break;

          case i.GET_OPEN_UNION_ID:
            t.infoAll("onUserStoreChange action: ".concat(e), "app.js"), this.setUpLogger({
                openId: a.openId
            }), l.dataReport("dau", {});
            break;

          case i.USER_LOGIN_SUC:
            r.getInstance().setAccountConfig({
                appId: a.appId,
                appUID: a.userId,
                cgiToken: a.cgiToken
            }), this.setUpLogger({
                nickName: a.nickName,
                userId: a.userId
            }), l.dataReport("dau", {}), t.infoAll("onUserStoreChange action: ".concat(e), "app.js"), 
            t.infoAll("copenId: ".concat(a.openId, ", userId: ").concat(a.userId, ", nickName: ").concat(t.getMd5(a.nickName)), "app.js");
        }
    },
    onAppStoreChange: function(e, n) {
        switch (t.info("onAppStoreChange action: ".concat(e, ", payload: ").concat(JSON.stringify(n)), "app.js"), 
        e) {
          case s.INIT_SYSTEM_INFO_SUCC:
            var o = c.sysInfo;
            t.info("onAppStoreChange sysInfo: ".concat(JSON.stringify(o)), "app.js");
            var a = (o.system || "").replace(/(.*?)\s.*/, "$1"), i = (o.system || "").replace(/.*?\s(.*)/, "$1"), g = o.model || "";
            r.getInstance().setAccountConfig({
                os: a,
                osVersion: i,
                osModel: g
            });
        }
    },
    getEnvVersion: function() {
        return n(e().mark(function n() {
            var o;
            return e().wrap(function(e) {
                for (;;) switch (e.prev = e.next) {
                  case 0:
                    return o = wx.getAccountInfoSync(), console.log("accountInfo ".concat(JSON.stringify(o))), 
                    e.abrupt("return", o.miniProgram.envVersion);

                  case 3:
                  case "end":
                    return e.stop();
                }
            }, n);
        }))();
    },
    initCalendarSDK: function() {
        var e = this;
        r.getInstance().setAccountConfig({
            ismock: !1,
            instanceId: "8",
            accessKey: "xdZzeqKJOfPCUv2YhsQpHlSLFu14j9Gn",
            cgiHostUrl: c.getHttpCgi(),
            appVersion: p.MP_CALENDAR_VERSION,
            onRequestSuc: function(e) {
                var n = e.statusCode, o = e.traceId, a = e.cgiName, i = e.cost, s = e.code, r = e.nonce, g = e.message, p = e.rawResp, u = c.getCurrEnv().key;
                t.infoAll("onRequestSuc: statusCode: ".concat(n, ",\n          traceId: ").concat(o, ", cgiName: ").concat(a, ", cost: ").concat(i, ", code: ").concat(s, ",\n          nonce: ").concat(r, ", message: ").concat(g, ", envName: ").concat(u), "app.js"), 
                t.info("onRequestSuc: traceId: ".concat(o, ", cgiName: ").concat(a, ",\n          statusCode: ").concat(n, ", rawResp: ").concat(JSON.stringify(p), ", envName: ").concat(u), "app.js"), 
                l.dataReport("mp_calendar_cgi", {
                    cgi_http_status_code: n,
                    cgi_trace_id: o,
                    cgi_name: a,
                    cgi_time_cost: i,
                    cgi_http_code: s,
                    cgi_nonce: r,
                    cgi_message: g,
                    env_name: u
                });
            },
            onRequestFail: function(n) {
                var o = n.statusCode, a = n.traceId, i = n.cgiName, s = n.cost, r = n.code, p = n.nonce, u = n.message, d = n.rawResp, h = c.getCurrEnv().key;
                t.infoAll("onRequestFail: statusCode: ".concat(o, ", traceId: ").concat(a, ",\n          cgiName: ").concat(i, ", cost: ").concat(s, ", code: ").concat(r, ", nonce: ").concat(p, ",\n          message: ").concat(u, ", envName: ").concat(h), "app.js"), 
                t.infoAll("onRequestFail: traceId: ".concat(a, ", cgiName: ").concat(i, ",\n          statusCode: ").concat(o, ", rawResp: ").concat(JSON.stringify(d), ", envName: ").concat(h), "app.js"), 
                l.dataReport("mp_calendar_cgi", {
                    cgi_http_status_code: o,
                    cgi_trace_id: a,
                    cgi_name: i,
                    cgi_time_cost: s,
                    cgi_http_code: r,
                    cgi_nonce: p,
                    cgi_message: u,
                    env_name: h
                }), 401 === o ? (g.clearLoginInfo(), g.reInit()) : 200020 === r && (e.hasReAuth ? t.info("hasReAuth. do nothing", "app.js") : (t.info("no hasReAuth.", "app.js"), 
                g.clearLoginInfo(), g.reInit(), e.hasReAuth = !0));
            }
        }), r.getInstance().setLogger(t);
    },
    setUpLogger: function(e) {
        console.log("initLogger config: ".concat(JSON.stringify(e))), t.setConfig(e);
    },
    globalData: {
        isIpx: !1,
        sysInfo: {},
        options: {}
    }
});