require("../../@babel/runtime/helpers/Arrayincludes");

var e = require("../../@babel/runtime/helpers/classCallCheck"), t = require("../../@babel/runtime/helpers/createClass"), n = require("../../@babel/runtime/helpers/typeof");

!function(e, t) {
    if ("object" == ("undefined" == typeof exports ? "undefined" : n(exports)) && "object" == ("undefined" == typeof module ? "undefined" : n(module))) module.exports = t(); else if ("function" == typeof define && define.amd) define([], t); else {
        var r = t();
        for (var i in r) ("object" == ("undefined" == typeof exports ? "undefined" : n(exports)) ? exports : e)[i] = r[i];
    }
}(self, function() {
    return function() {
        var r = {
            522: function(e, t, n) {
                var r;
                !function(i) {
                    function o(e, t) {
                        var n = (65535 & e) + (65535 & t);
                        return (e >> 16) + (t >> 16) + (n >> 16) << 16 | 65535 & n;
                    }
                    function a(e, t, n, r, i, a) {
                        return o((s = o(o(t, e), o(r, a))) << (l = i) | s >>> 32 - l, n);
                        var s, l;
                    }
                    function s(e, t, n, r, i, o, s) {
                        return a(t & n | ~t & r, e, t, i, o, s);
                    }
                    function l(e, t, n, r, i, o, s) {
                        return a(t & r | n & ~r, e, t, i, o, s);
                    }
                    function c(e, t, n, r, i, o, s) {
                        return a(t ^ n ^ r, e, t, i, o, s);
                    }
                    function u(e, t, n, r, i, o, s) {
                        return a(n ^ (t | ~r), e, t, i, o, s);
                    }
                    function f(e, t) {
                        var n, r, i, a, f;
                        e[t >> 5] |= 128 << t % 32, e[14 + (t + 64 >>> 9 << 4)] = t;
                        var p = 1732584193, d = -271733879, h = -1732584194, g = 271733878;
                        for (n = 0; n < e.length; n += 16) r = p, i = d, a = h, f = g, p = s(p, d, h, g, e[n], 7, -680876936), 
                        g = s(g, p, d, h, e[n + 1], 12, -389564586), h = s(h, g, p, d, e[n + 2], 17, 606105819), 
                        d = s(d, h, g, p, e[n + 3], 22, -1044525330), p = s(p, d, h, g, e[n + 4], 7, -176418897), 
                        g = s(g, p, d, h, e[n + 5], 12, 1200080426), h = s(h, g, p, d, e[n + 6], 17, -1473231341), 
                        d = s(d, h, g, p, e[n + 7], 22, -45705983), p = s(p, d, h, g, e[n + 8], 7, 1770035416), 
                        g = s(g, p, d, h, e[n + 9], 12, -1958414417), h = s(h, g, p, d, e[n + 10], 17, -42063), 
                        d = s(d, h, g, p, e[n + 11], 22, -1990404162), p = s(p, d, h, g, e[n + 12], 7, 1804603682), 
                        g = s(g, p, d, h, e[n + 13], 12, -40341101), h = s(h, g, p, d, e[n + 14], 17, -1502002290), 
                        p = l(p, d = s(d, h, g, p, e[n + 15], 22, 1236535329), h, g, e[n + 1], 5, -165796510), 
                        g = l(g, p, d, h, e[n + 6], 9, -1069501632), h = l(h, g, p, d, e[n + 11], 14, 643717713), 
                        d = l(d, h, g, p, e[n], 20, -373897302), p = l(p, d, h, g, e[n + 5], 5, -701558691), 
                        g = l(g, p, d, h, e[n + 10], 9, 38016083), h = l(h, g, p, d, e[n + 15], 14, -660478335), 
                        d = l(d, h, g, p, e[n + 4], 20, -405537848), p = l(p, d, h, g, e[n + 9], 5, 568446438), 
                        g = l(g, p, d, h, e[n + 14], 9, -1019803690), h = l(h, g, p, d, e[n + 3], 14, -187363961), 
                        d = l(d, h, g, p, e[n + 8], 20, 1163531501), p = l(p, d, h, g, e[n + 13], 5, -1444681467), 
                        g = l(g, p, d, h, e[n + 2], 9, -51403784), h = l(h, g, p, d, e[n + 7], 14, 1735328473), 
                        p = c(p, d = l(d, h, g, p, e[n + 12], 20, -1926607734), h, g, e[n + 5], 4, -378558), 
                        g = c(g, p, d, h, e[n + 8], 11, -2022574463), h = c(h, g, p, d, e[n + 11], 16, 1839030562), 
                        d = c(d, h, g, p, e[n + 14], 23, -35309556), p = c(p, d, h, g, e[n + 1], 4, -1530992060), 
                        g = c(g, p, d, h, e[n + 4], 11, 1272893353), h = c(h, g, p, d, e[n + 7], 16, -155497632), 
                        d = c(d, h, g, p, e[n + 10], 23, -1094730640), p = c(p, d, h, g, e[n + 13], 4, 681279174), 
                        g = c(g, p, d, h, e[n], 11, -358537222), h = c(h, g, p, d, e[n + 3], 16, -722521979), 
                        d = c(d, h, g, p, e[n + 6], 23, 76029189), p = c(p, d, h, g, e[n + 9], 4, -640364487), 
                        g = c(g, p, d, h, e[n + 12], 11, -421815835), h = c(h, g, p, d, e[n + 15], 16, 530742520), 
                        p = u(p, d = c(d, h, g, p, e[n + 2], 23, -995338651), h, g, e[n], 6, -198630844), 
                        g = u(g, p, d, h, e[n + 7], 10, 1126891415), h = u(h, g, p, d, e[n + 14], 15, -1416354905), 
                        d = u(d, h, g, p, e[n + 5], 21, -57434055), p = u(p, d, h, g, e[n + 12], 6, 1700485571), 
                        g = u(g, p, d, h, e[n + 3], 10, -1894986606), h = u(h, g, p, d, e[n + 10], 15, -1051523), 
                        d = u(d, h, g, p, e[n + 1], 21, -2054922799), p = u(p, d, h, g, e[n + 8], 6, 1873313359), 
                        g = u(g, p, d, h, e[n + 15], 10, -30611744), h = u(h, g, p, d, e[n + 6], 15, -1560198380), 
                        d = u(d, h, g, p, e[n + 13], 21, 1309151649), p = u(p, d, h, g, e[n + 4], 6, -145523070), 
                        g = u(g, p, d, h, e[n + 11], 10, -1120210379), h = u(h, g, p, d, e[n + 2], 15, 718787259), 
                        d = u(d, h, g, p, e[n + 9], 21, -343485551), p = o(p, r), d = o(d, i), h = o(h, a), 
                        g = o(g, f);
                        return [ p, d, h, g ];
                    }
                    function p(e) {
                        var t, n = "", r = 32 * e.length;
                        for (t = 0; t < r; t += 8) n += String.fromCharCode(e[t >> 5] >>> t % 32 & 255);
                        return n;
                    }
                    function d(e) {
                        var t, n = [];
                        for (n[(e.length >> 2) - 1] = void 0, t = 0; t < n.length; t += 1) n[t] = 0;
                        var r = 8 * e.length;
                        for (t = 0; t < r; t += 8) n[t >> 5] |= (255 & e.charCodeAt(t / 8)) << t % 32;
                        return n;
                    }
                    function h(e) {
                        var t, n, r = "0123456789abcdef", i = "";
                        for (n = 0; n < e.length; n += 1) t = e.charCodeAt(n), i += r.charAt(t >>> 4 & 15) + r.charAt(15 & t);
                        return i;
                    }
                    function g(e) {
                        return unescape(encodeURIComponent(e));
                    }
                    function m(e) {
                        return function(e) {
                            return p(f(d(e), 8 * e.length));
                        }(g(e));
                    }
                    function v(e, t) {
                        return function(e, t) {
                            var n, r, i = d(e), o = [], a = [];
                            for (o[15] = a[15] = void 0, i.length > 16 && (i = f(i, 8 * e.length)), n = 0; n < 16; n += 1) o[n] = 909522486 ^ i[n], 
                            a[n] = 1549556828 ^ i[n];
                            return r = f(o.concat(d(t)), 512 + 8 * t.length), p(f(a.concat(r), 640));
                        }(g(e), g(t));
                    }
                    function y(e, t, n) {
                        return t ? n ? v(t, e) : h(v(t, e)) : n ? m(e) : h(m(e));
                    }
                    void 0 === (r = function() {
                        return y;
                    }.call(t, n, t, e)) || (e.exports = r);
                }();
            },
            143: function(e) {
                e.exports = function() {
                    var e = function(t, n) {
                        return (e = Object.setPrototypeOf || ({
                            __proto__: []
                        } instanceof Array ? function(e, t) {
                            e.__proto__ = t;
                        } : function(e, t) {
                            for (var n in t) Object.prototype.hasOwnProperty.call(t, n) && (e[n] = t[n]);
                        }))(t, n);
                    };
                    function t(t, n) {
                        function r() {
                            this.constructor = t;
                        }
                        e(t, n), t.prototype = null === n ? Object.create(n) : (r.prototype = n.prototype, 
                        new r());
                    }
                    var r = function() {
                        return (r = Object.assign || function(e) {
                            for (var t, n = 1, r = arguments.length; n < r; n++) for (var i in t = arguments[n]) Object.prototype.hasOwnProperty.call(t, i) && (e[i] = t[i]);
                            return e;
                        }).apply(this, arguments);
                    };
                    function i() {
                        for (var e = 0, t = 0, n = arguments.length; t < n; t++) e += arguments[t].length;
                        var r = Array(e), i = 0;
                        for (t = 0; t < n; t++) for (var o = arguments[t], a = 0, s = o.length; a < s; a++, 
                        i++) r[i] = o[a];
                        return r;
                    }
                    Object.assign || Object.defineProperty(Object, "assign", {
                        enumerable: !1,
                        configurable: !0,
                        writable: !0,
                        value: function(e) {
                            if (null == e) throw new TypeError("Cannot convert first argument to object");
                            for (var t = Object(e), n = 1; n < arguments.length; n++) if (null != (r = arguments[n])) for (var r = Object(r), i = Object.keys(Object(r)), o = 0, a = i.length; o < a; o++) {
                                var s = i[o], l = Object.getOwnPropertyDescriptor(r, s);
                                null != l && l.enumerable && (t[s] = r[s]);
                            }
                            return t;
                        }
                    });
                    var o = [ "ext1", "ext2", "ext3", "level", "trace", "tag", "seq", "code" ], a = (l.prototype.indexOf = function(e, t) {
                        for (var n = 0; n < e.length; n++) if (e[n].callback === t) return n;
                        return -1;
                    }, l.prototype.on = function(e, t, n) {
                        var r;
                        if (void 0 === n && (n = 0), this) return (r = this.eventsList[e]) || (this.eventsList[e] = [], 
                        r = this.eventsList[e]), -1 === this.indexOf(r, t) && r.push({
                            name: e,
                            type: n || 0,
                            callback: t
                        }), this;
                    }, l.prototype.one = function(e, t) {
                        this.on(e, t, 1);
                    }, l.prototype.remove = function(e, t) {
                        if (this) {
                            var n = this.eventsList[e];
                            if (n) {
                                if (t) return n.length && (t = this.indexOf(n, t), n.splice(t, 1)), this;
                                try {
                                    delete this.eventsList[e];
                                } catch (e) {}
                            }
                            return null;
                        }
                    }, l.prototype.clear = function() {
                        this.eventsList = {};
                    }, l), s = function(e) {
                        if (!e || 0 === e.length) return "{}";
                        e = Array.isArray(e) ? e : [ e ];
                        var t = Object.keys(e[0]), n = {}, r = (t.forEach(function(t) {
                            n[t] = e.map(function(e) {
                                return e[t];
                            });
                        }), n.count = e.length, n);
                        if ("string" == typeof r) return r;
                        try {
                            return JSON.stringify(r, H()) || "undefined";
                        } catch (r) {
                            return "error happen when aegis stringify: \n " + r.message + " \n " + r.stack;
                        }
                    };
                    function l() {
                        var e = this;
                        this.emit = function(t, n) {
                            if (e) {
                                var r;
                                if (null != (i = e.eventsList[t]) && i.length) for (var i = i.slice(), o = 0; o < i.length; o++) {
                                    r = i[o];
                                    try {
                                        var a = r.callback.apply(e, [ n ]);
                                        if (1 === r.type && e.remove(t, r.callback), !1 === a) break;
                                    } catch (t) {
                                        throw t;
                                    }
                                }
                                return e;
                            }
                        }, this.eventsList = {};
                    }
                    function c(e, t) {
                        return "string" == typeof e ? e.split("?")[t ? 1 : 0] || "" : e;
                    }
                    function u(e) {
                        return "string" == typeof e && e.startsWith("//") ? "undefined" != typeof location && "https:" === location.protocol : /^https/.test(e);
                    }
                    function f(e, t, n) {
                        var r, i;
                        try {
                            if ("function" == typeof (null == t ? void 0 : t.retCodeHandler)) return {
                                code: void 0 === (o = (i = t.retCodeHandler(e, null == n ? void 0 : n.url, null == n ? void 0 : n.ctx) || {}).code) ? "unknown" : o,
                                isErr: i.isErr
                            };
                            "string" == typeof e && (e = JSON.parse(e)), "function" == typeof (null == (r = null == t ? void 0 : t.ret) ? void 0 : r.join) && (U = [].concat(t.ret.map(function(e) {
                                return e.toLowerCase();
                            })));
                            var o, a = Object.getOwnPropertyNames(e).filter(function(e) {
                                return -1 !== U.indexOf(e.toLowerCase());
                            });
                            return a.length ? {
                                code: "" + (o = e[a[0]]),
                                isErr: 0 !== o && "0" !== o
                            } : {
                                code: "unknown",
                                isErr: !1
                            };
                        } catch (e) {
                            return {
                                code: "unknown",
                                isErr: !1
                            };
                        }
                    }
                    function p(e, t, n) {
                        try {
                            var r = "function" == typeof t ? t(e, null == n ? void 0 : n.url) || "" : e;
                            return I(r).slice(0, 102400);
                        } catch (e) {
                            return "";
                        }
                    }
                    function d(e, t) {
                        var n, r = [], i = e.config;
                        return e.lifeCycle.on("destroy", function() {
                            r.length = 0;
                        }), function(o, a) {
                            Array.isArray(o) ? r = r.concat(o) : r.push(o), t && r.length >= t || e.sendNow && 0 < r.length ? (r = F(r), 
                            a(r.splice(0, r.length)), n && clearTimeout(n)) : (n && clearTimeout(n), n = setTimeout(function() {
                                n = null, 0 < (r = F(r)).length && a(r.splice(0, r.length));
                            }, i.delay));
                        };
                    }
                    function h(e, t) {
                        return Array.isArray(e) ? t(e.map(function(e) {
                            return t = r(r({}, e), {
                                msg: "string" == typeof e.msg ? e.msg : [].concat(e.msg).map(_).join(" ")
                            }), o.forEach(function(e) {
                                t[e] || delete t[e];
                            }), t;
                            var t;
                        })) : t([ r(r({}, e), {
                            msg: "string" == typeof e.msg ? e.msg : _(e.msg)
                        }) ]);
                    }
                    function g(e, t) {
                        return function(n, i) {
                            var a, s, l, c = Array.isArray(n), u = c ? n : [ n ], f = (e.lifeCycle.emit("beforeRequest", n), 
                            e.config.beforeRequest);
                            (u = "function" == typeof f ? u.map(function(e) {
                                try {
                                    var n = f({
                                        logs: e,
                                        logType: t
                                    });
                                    return (null == n ? void 0 : n.logType) === t && null != n && n.logs ? n.logs : !1 !== n && e;
                                } catch (n) {
                                    return e;
                                }
                            }).filter(function(e) {
                                return !1 !== e;
                            }) : u).length && (a = u, n = o, !Array.isArray(a) || a.length <= 1 || (s = [], 
                            l = [], !(l = "string" == typeof n ? [ n ] : n)) || l.length <= 0 || (l.forEach(function(e) {
                                a.forEach(function(t) {
                                    null != t && t[e] && s.push(e);
                                });
                            }), 0 < s.length && (a = a.map(function(e) {
                                var t = {};
                                return s.forEach(function(e) {
                                    t[e] = "";
                                }), r(r({}, t), e);
                            }))), u = a, i(c ? u : u[0]));
                        };
                    }
                    function m(e) {
                        return function(t, r) {
                            e.lifeCycle.emit("modifyRequest", t);
                            var i = e.config.modifyRequest;
                            if ("function" == typeof i) try {
                                var o = i(t);
                                "object" == n(o) && "url" in o && (t = o);
                            } catch (t) {
                                console.error(t);
                            }
                            r(t);
                        };
                    }
                    function v(e) {
                        return function(t, n) {
                            e.lifeCycle.emit("afterRequest", t);
                            var r = e.config.afterRequest;
                            "function" == typeof r && !1 === r(t) || n(t);
                        };
                    }
                    function y(e) {
                        if (e && e.reduce && e.length) return 1 === e.length ? function(t, n) {
                            e[0](t, n || W);
                        } : e.reduce(function(e, t) {
                            return function(n, r) {
                                return void 0 === r && (r = W), e(n, function(e) {
                                    return null == t ? void 0 : t(e, r);
                                });
                            };
                        });
                        throw new TypeError("createPipeline need at least one function param");
                    }
                    function b(e, t) {
                        Object.getOwnPropertyNames(e).forEach(function(n) {
                            "function" == typeof e[n] && "constructor" !== n && (t ? t[n] = "sendPipeline" === n ? function() {
                                return function() {};
                            } : function() {} : e[n] = function() {});
                        });
                    }
                    function w(e) {
                        try {
                            var t, n, r, i = "";
                            return i = e.pageUrl || (n = (t = getCurrentPages())[t.length - 1] || {}, o = n.options, 
                            r = Object.keys(o).length ? "?" + Object.keys(o).map(function(e) {
                                return e + "=" + o[e];
                            }).join("&") : "", n.route ? n.route + r : ""), i = "function" == typeof e.urlHandler ? e.urlHandler() : i;
                        } catch (e) {
                            return "";
                        }
                        var o;
                    }
                    function E(e, t) {
                        if ("string" == typeof e && "string" == typeof t) {
                            if (e === t) return 1;
                            for (var n = e.split("."), r = t.split("."), i = Math.max(n.length, r.length), o = 0; o < i; o++) {
                                var a = ~~n[o], s = ~~r[o];
                                if (a < s) return;
                                if (s < a) return 1;
                            }
                        }
                    }
                    function O(e) {
                        return E(X = X || $.getSystemInfoSync().SDKVersion, "1.1.1") && $.canIUse ? $.canIUse(e) : !!$[e];
                    }
                    function R(e) {
                        for (var t, n = {
                            unknown: /unknown|none/i,
                            wifi: /wifi/i,
                            net2g: /2g/i,
                            net3g: /3g/i,
                            net4g: /4g/i,
                            net5g: /5g/i,
                            net6g: /6g/i
                        }, r = N.unknown, i = 0; i < Object.keys(n).length; i++) {
                            var o = Object.keys(n)[i];
                            if (null != (t = n[o]) && t.test(e)) {
                                r = N[o];
                                break;
                            }
                        }
                        return r;
                    }
                    function P(e) {
                        var t = e.apiName, n = re[t];
                        n ? n.hackCloudReq.addCallback(e) : (n = ne.cloud[t], re[t] = {
                            hackCloudReq: new ie(e),
                            originApi: n
                        }), re[t];
                    }
                    function S(e) {
                        var t = e.apiName, n = ae[t];
                        n ? n.hackReq.addCallback(e) : (n = wx[t], ae[t] = {
                            hackReq: new se(e),
                            originApi: n
                        }), ae[t];
                    }
                    var x, k, N, C, T, L, A, q, j, U = [ "ret", "retcode", "code", "errcode" ], H = function() {
                        var e = new WeakSet();
                        return function(t, r) {
                            if (r instanceof Error) return "Error.message: " + r.message + " \n  Error.stack: " + r.stack;
                            if ("object" == n(r) && null !== r) {
                                if (e.has(r)) return "[Circular " + (t || "root") + "]";
                                e.add(r);
                            }
                            return r;
                        };
                    }, _ = function(e) {
                        if ("string" == typeof e) return e;
                        try {
                            return e instanceof Error ? (JSON.stringify(e, H(), 4) || "undefined").replace(/"/gim, "") : JSON.stringify(e, H(), 4) || "undefined";
                        } catch (e) {
                            return "error happen when aegis stringify: \n " + e.message + " \n " + e.stack;
                        }
                    }, I = function e(t, r) {
                        void 0 === r && (r = 3);
                        var i, o, a, s = "";
                        return Array.isArray(t) ? (s += "[", i = t.length, t.forEach(function(t, o) {
                            s = (s += "object" == n(t) && 1 < r ? e(t, r - 1) : D(t)) + (o === i - 1 ? "" : ",");
                        }), s += "]") : t instanceof Object ? (s = "{", o = Object.keys(t), a = o.length, 
                        o.forEach(function(i, l) {
                            "object" == n(t[i]) && 1 < r ? s += '"' + i + '":' + e(t[i], r - 1) : s += M(i, t[i]), 
                            s += l === a - 1 || l < a - 1 && void 0 === t[o[l + 1]] ? "" : ",";
                        }), s += "}") : s += t, s;
                    }, M = function(e, t) {
                        var r = n(t), i = "";
                        return "string" == r || "object" == r ? i += '"' + e + '":"' + t + '"' : "function" == typeof t ? i += '"' + e + '":"function ' + t.name + '"' : "symbol" == n(t) ? i += '"' + e + '":"symbol"' : "number" != typeof t && "boolean" != r || (i += '"' + e + '": ' + t), 
                        i;
                    }, D = function(e) {
                        var t = n(e);
                        return "" + ("undefined" == t || "symbol" == t || "function" == t ? "null" : "string" == t || "object" == t ? '"' + e + '"' : e);
                    }, F = ((G = x = x || {}).INFO_ALL = "-1", G.API_RESPONSE = "1", G.INFO = "2", G.ERROR = "4", 
                    G.PROMISE_ERROR = "8", G.AJAX_ERROR = "16", G.SCRIPT_ERROR = "32", G.IMAGE_ERROR = "64", 
                    G.CSS_ERROR = "128", G.CONSOLE_ERROR = "256", G.MEDIA_ERROR = "512", G.RET_ERROR = "1024", 
                    G.REPORT = "2048", G.PV = "4096", G.EVENT = "8192", G.PAGE_NOT_FOUND_ERROR = "16384", 
                    G.WEBSOCKET_ERROR = "32768", G.BRIDGE_ERROR = "65536", (G = k = k || {})[G.android = 1] = "android", 
                    G[G.ios = 2] = "ios", G[G.windows = 3] = "windows", G[G.macos = 4] = "macos", G[G.linux = 5] = "linux", 
                    G[G.devtools = 6] = "devtools", G[G.other = 100] = "other", (G = N = N || {})[G.unknown = 100] = "unknown", 
                    G[G.wifi = 1] = "wifi", G[G.net2g = 2] = "net2g", G[G.net3g = 3] = "net3g", G[G.net4g = 4] = "net4g", 
                    G[G.net5g = 5] = "net5g", G[G.net6g = 6] = "net6g", (G = C = C || {}).LOG = "log", 
                    G.SPEED = "speed", G.PERFORMANCE = "performance", G.OFFLINE = "offline", G.WHITE_LIST = "whiteList", 
                    G.VITALS = "vitals", G.PV = "pv", G.CUSTOM_PV = "customPV", G.EVENT = "event", G.CUSTOM = "custom", 
                    G.SDK_ERROR = "sdkError", G.SET_DATA = "setData", G.LOAD_PACKAGE = "loadPackage", 
                    (G = T = T || {}).production = "production", G.development = "development", G.gray = "gray", 
                    G.pre = "pre", G.daily = "daily", G.local = "local", G.test = "test", G.others = "others", 
                    function(e) {
                        return e.filter(function(t, n) {
                            return "static" !== t.type || !e.find(function(e, r) {
                                return t.url === e.url && 200 === t.status && n < r;
                            });
                        });
                    }), B = function(e) {
                        e.level === x.INFO_ALL && (e.level = x.INFO);
                    }, J = function(e) {
                        return (Array.isArray(e) ? e : [ e ]).map(function(e) {
                            return Object.getOwnPropertyNames(e).reduce(function(t, n) {
                                return "ctx" !== n && (t[n] = e[n]), t;
                            }, {
                                level: x.INFO,
                                msg: ""
                            });
                        });
                    }, V = function(e) {
                        return function(t) {
                            return e.sendPipeline([ function(t, n) {
                                return n({
                                    url: e.config.url || "",
                                    data: s(J(t)),
                                    method: "post",
                                    contentType: "application/json",
                                    type: C.LOG,
                                    log: t,
                                    requestConfig: {
                                        timeout: 5e3
                                    },
                                    success: function() {
                                        var r = e.config.onReport;
                                        "function" == typeof r && t.forEach(function(e) {
                                            r(e);
                                        }), "function" == typeof n && n([]);
                                    },
                                    fail: function(t) {
                                        "403 forbidden" === t && e.destroy();
                                    }
                                });
                            } ], C.LOG)(t);
                        };
                    }, W = function() {}, G = (Object.defineProperty(me.prototype, "__version__", {
                        get: function() {
                            return console.warn("__version__ has discard, please use version"), "1.38.36";
                        },
                        enumerable: !1,
                        configurable: !0
                    }), Object.defineProperty(me.prototype, "LogType", {
                        get: function() {
                            return console.warn("LogType has discard, please use logType"), x;
                        },
                        enumerable: !1,
                        configurable: !0
                    }), me.prototype.init = function(e) {
                        this.setConfig(e);
                        for (var t = 0; t < me.installedPlugins.length; t++) try {
                            me.installedPlugins[t].patch(this);
                        } catch (e) {
                            this.sendSDKError(e);
                        }
                        this.lifeCycle.emit("onInited");
                    }, me.prototype.setConfig = function(e) {
                        Object.assign(this.config, e);
                        var t = (e = this.config).id, n = e.uin, r = e.version, i = e.ext1, o = e.ext2, a = e.ext3, s = e.aid, l = void 0 === (c = e.env) ? "production" : c, c = e.pageUrl;
                        return e = this.bean.id !== t || this.bean.uin !== n || this.bean.aid !== s, this.bean.id = t || "", 
                        this.bean.uin = n || "", this.bean.version = r || "1.38.36", this.bean.aid = s || "", 
                        this.bean.env = function() {
                            switch (l) {
                              case T.production:
                              case T.development:
                              case T.gray:
                              case T.pre:
                              case T.daily:
                              case T.local:
                              case T.test:
                              case T.others:
                                return 1;

                              default:
                                return;
                            }
                        }() ? l : T.others, c && this.extendBean("from", encodeURIComponent(c)), i && this.extendBean("ext1", encodeURIComponent(i)), 
                        o && this.extendBean("ext2", encodeURIComponent(o)), a && this.extendBean("ext3", encodeURIComponent(a)), 
                        e && this.lifeCycle.emit("onConfigChange", this.config), this.config;
                    }, me.use = function(e) {
                        -1 === me.installedPlugins.indexOf(e) && e.aegisPlugin && me.installedPlugins.push(e);
                    }, me.unuse = function(e) {
                        -1 !== (e = me.installedPlugins.indexOf(e)) && me.installedPlugins.splice(e, 1);
                    }, me.prototype.info = function() {
                        for (var e = [], t = 0; t < arguments.length; t++) e[t] = arguments[t];
                        var n = {
                            level: x.INFO,
                            msg: e
                        };
                        1 === e.length && e[0].msg && Object.assign(n, r({}, e[0]), {
                            level: x.INFO
                        }), this.normalLogPipeline(n);
                    }, me.prototype.infoAll = function() {
                        for (var e = [], t = 0; t < arguments.length; t++) e[t] = arguments[t];
                        var n = {
                            level: x.INFO_ALL,
                            msg: e
                        };
                        1 === e.length && e[0].msg && Object.assign(n, r({}, e[0]), {
                            level: x.INFO_ALL
                        }), this.normalLogPipeline(n);
                    }, me.prototype.report = function() {
                        for (var e = [], t = 0; t < arguments.length; t++) e[t] = arguments[t];
                        var n = {
                            level: x.REPORT,
                            msg: e
                        };
                        1 === e.length && e[0].msg && Object.assign(n, r({}, e[0])), this.normalLogPipeline(n);
                    }, me.prototype.error = function() {
                        for (var e = [], t = 0; t < arguments.length; t++) e[t] = arguments[t];
                        var n = {
                            level: x.ERROR,
                            msg: e
                        };
                        1 === e.length && e[0].msg && Object.assign(n, r({}, e[0]), {
                            level: x.ERROR
                        }), this.normalLogPipeline(n);
                    }, me.prototype.speedLogPipeline = function(e) {
                        throw new Error('You need to override "speedLogPipeline" method');
                    }, me.prototype.reportPv = function(e) {
                        var t, n = this;
                        e && (console.warn("reportPv is deprecated, please use reportEvent"), t = "" + Object.getOwnPropertyNames(this.bean).filter(function(e) {
                            return "id" !== e;
                        }).map(function(e) {
                            return e + "=" + n.bean[e];
                        }).join("&"), this.sendPipeline([ function(r, i) {
                            i({
                                url: n.config.url + "/" + e + "?" + t,
                                addBean: !1,
                                type: C.CUSTOM_PV,
                                fail: function(e) {
                                    "403 forbidden" === e && n.destroy();
                                }
                            });
                        } ], C.CUSTOM_PV)(null));
                    }, me.prototype.reportEvent = function(e) {
                        e && ((e = "string" == typeof e ? {
                            name: e,
                            ext1: this.config.ext1 || "",
                            ext2: this.config.ext2 || "",
                            ext3: this.config.ext3 || ""
                        } : e).name ? this.eventPipeline(e) : console.warn("reportEvent params error"));
                    }, me.prototype.reportTime = function(e, t) {
                        if ("object" == n(e)) return this.reportT(e);
                        "string" == typeof e ? "number" == typeof t ? t < 0 || 6e4 < t ? console.warn("reportTime: duration must between 0 and 60000") : this.submitCustomTime(e, t) : console.warn("reportTime: second param must be number") : console.warn("reportTime: first param must be a string");
                    }, me.prototype.reportT = function(e) {
                        var t = e.name, n = e.duration, r = void 0 === (r = e.ext1) ? "" : r, i = void 0 === (i = e.ext2) ? "" : i, o = void 0 === (o = e.ext3) ? "" : o;
                        if (e = e.from, "string" == typeof t && "number" == typeof n && "string" == typeof r && "string" == typeof i && "string" == typeof o) {
                            if (!(n < 0 || 6e4 < n)) return this.submitCustomTime(t, n, r, i, o, void 0 === e ? "" : e);
                            console.warn("reportTime: duration must between 0 and 60000");
                        } else console.warn("reportTime: params error");
                    }, me.prototype.time = function(e) {
                        "string" == typeof e ? this.timeMap[e] ? console.warn("Timer " + e + " already exists") : this.timeMap[e] = Date.now() : console.warn("time: first param must be a string");
                    }, me.prototype.timeEnd = function(e) {
                        "string" == typeof e ? this.timeMap[e] ? (this.submitCustomTime(e, Date.now() - this.timeMap[e]), 
                        delete this.timeMap[e]) : console.warn("Timer " + e + " does not exist") : console.warn("timeEnd: first param must be a string");
                    }, me.prototype.submitCustomTime = function(e, t, n, r, i, o) {
                        this.customTimePipeline({
                            name: e,
                            duration: t,
                            ext1: n || this.config.ext1,
                            ext2: r || this.config.ext2,
                            ext3: i || this.config.ext3,
                            from: o || void 0
                        });
                    }, me.prototype.extendBean = function(e, t) {
                        this.bean[e] = t;
                    }, me.prototype.sendPipeline = function(e, t) {
                        var n, r = this;
                        return y(i([ function(e, t) {
                            if ("number" != typeof n.config.random && (console.warn("random must in [0, 1], default is 1."), 
                            n.config.random = 1), !n.isHidden || !n.isGetSample) if (n.isGetSample) n.isHidden || t(e); else {
                                if (n.isGetSample = !0, Math.random() < n.config.random) return n.isHidden = !1, 
                                t(e);
                                n.isHidden = !0;
                            }
                        }, g(n = this, t) ], e, [ m(this), function(e, t) {
                            r.request(e, function() {
                                for (var n, o = [], a = 0; a < arguments.length; a++) o[a] = arguments[a];
                                r.failRequestCount = 0, t({
                                    isErr: !1,
                                    result: o,
                                    logType: null == e ? void 0 : e.type,
                                    logs: null == e ? void 0 : e.log
                                }), null != (n = null == e ? void 0 : e.success) && n.call.apply(n, i([ e ], o));
                            }, function() {
                                for (var n, o = [], a = 0; a < arguments.length; a++) o[a] = arguments[a];
                                10 <= ++r.failRequestCount && r.destroy(), t({
                                    isErr: !0,
                                    result: o,
                                    logType: null == e ? void 0 : e.type,
                                    logs: null == e ? void 0 : e.log
                                }), null != (n = null == e ? void 0 : e.fail) && n.call.apply(n, i([ e ], o));
                            });
                        }, v(this) ]));
                    }, me.prototype.send = function(e, t, n) {
                        var r = this;
                        return y([ m(this), function(e, i) {
                            r.request(e, function() {
                                for (var n = [], r = 0; r < arguments.length; r++) n[r] = arguments[r];
                                i({
                                    isErr: !1,
                                    result: n,
                                    logType: e.type,
                                    logs: e.log
                                }), null != t && t.apply(void 0, n);
                            }, function() {
                                for (var t = [], r = 0; r < arguments.length; r++) t[r] = arguments[r];
                                i({
                                    isErr: !0,
                                    result: t,
                                    logType: e.type,
                                    logs: e.log
                                }), null != n && n.apply(void 0, t);
                            });
                        }, v(this) ])(e);
                    }, me.prototype.ready = function(e, t, n) {
                        throw new Error('You need to override "ready" method');
                    }, me.prototype.request = function(e, t, n) {
                        throw new Error('You need to override "request" method');
                    }, me.prototype.sendSDKError = function(e) {
                        var t = this;
                        this.sendPipeline([ function(e, n) {
                            n({
                                url: t.config.url + "?id=1085&msg[0]=" + encodeURIComponent(_(e)) + "&level[0]=2&from=" + t.config.id + "&count=1&version=" + t.config.id + "(1.38.36)",
                                addBean: !1,
                                method: "get",
                                type: C.SDK_ERROR,
                                log: e
                            });
                        } ], C.SDK_ERROR)(e);
                    }, me.prototype.destroy = function(e) {
                        void 0 === e && (e = !1);
                        var t, n, r = me.instances.indexOf(this);
                        -1 !== r && me.instances.splice(r, 1);
                        for (var i = me.installedPlugins.length - 1; 0 <= i; i--) try {
                            me.installedPlugins[i].unpatch(this);
                        } catch (e) {
                            this.sendSDKError(e);
                        }
                        if (this.lifeCycle.emit("destroy"), this.lifeCycle.clear(), e) t = this, n = Object.getOwnPropertyDescriptors(t), 
                        Object.keys(n).forEach(function(e) {
                            n[e].writable && (t[e] = null);
                        }), Object.setPrototypeOf(this, null); else {
                            for (var o = this; o.constructor !== Object && b(o, this), o = Object.getPrototypeOf(o); ) ;
                            0 === me.instances.length && (b(r = Object.getPrototypeOf(this).constructor), b(me));
                        }
                    }, me.version = "1.38.36", me.instances = [], me.logType = x, me.environment = T, 
                    me.installedPlugins = [], me), K = (ge.prototype.patch = function(e) {
                        this.canUse(e) && this.exist(e) && (this.instances.push(e), this.triggerInit(e), 
                        this.triggerOnNewAegis(e));
                    }, ge.prototype.unpatch = function(e) {
                        -1 !== (e = this.instances.indexOf(e)) && (this.instances.splice(e, 1), 0 === this.instances.length) && this.uninstall();
                    }, ge.prototype.countInstance = function() {
                        return this.instances.length;
                    }, ge.prototype.uninstall = function() {
                        var e;
                        null != (e = null == (e = this.option) ? void 0 : e.destroy) && e.apply(this);
                    }, ge.prototype.walk = function(e) {
                        var t = this;
                        this.instances.forEach(function(n) {
                            var r = t.canUse(n);
                            r && e(n, r);
                        });
                    }, ge.prototype.canUse = function(e) {
                        return !(!(e = this.getConfig(e)) || "object" != n(e)) || !!e;
                    }, ge.prototype.getConfig = function(e) {
                        return null == (e = e.config) ? void 0 : e[this.name];
                    }, ge.prototype.exist = function(e) {
                        return -1 === this.instances.indexOf(e);
                    }, ge.prototype.triggerInit = function(e) {
                        var t;
                        this.inited || (this.inited = !0, null == (t = null == (t = this.option) ? void 0 : t.init)) || t.call(this.option, this.getConfig(e));
                    }, ge.prototype.triggerOnNewAegis = function(e) {
                        var t;
                        null != (t = null == (t = this.option) ? void 0 : t.onNewAegis) && t.call(this.option, e, this.getConfig(e));
                    }, ge), $ = wx || qq, X = "", z = new K({
                        name: "offlineLog",
                        onNewAegis: function(e) {
                            if ($.getFileSystemManager) try {
                                var t = e.config, n = t.id, r = void 0 === n ? "" : n, i = t.uin, o = void 0 === i ? 0 : i, a = t.offlineUrl, s = void 0 === a ? "" : a, l = t.offlineLogLimit, c = new Q({
                                    limit: l
                                });
                                e.lifeCycle.on("beforeWrite", function(t) {
                                    c.save2Offline(t = void 0 === t ? [] : t, e.config);
                                }), c.ready(function(t) {
                                    var n = (e.bean || {}).aid, i = void 0 === n ? "" : n;
                                    !t && r && (o || i) && e.send({
                                        url: s + "/offlineAuto",
                                        type: C.OFFLINE,
                                        log: C.OFFLINE
                                    }, function(n) {
                                        var a = (null == n ? void 0 : n.data).secretKey;
                                        a && !t && c.getLogs({
                                            id: r,
                                            uin: o
                                        }, function(t, n) {
                                            t ? console.error(t) : e.send({
                                                url: s + "/offlineLog",
                                                data: {
                                                    logs: n,
                                                    secretKey: a,
                                                    id: r,
                                                    uin: o,
                                                    aid: i
                                                },
                                                method: "post",
                                                type: C.OFFLINE,
                                                log: n
                                            }, function() {
                                                c.clearLogs();
                                            });
                                        });
                                    });
                                });
                            } catch (e) {
                                console.error(e);
                            } else console.warn("[aegis-mp-sdk]unsupport getFileSystemManager offline log not work!");
                        }
                    }), Q = (he.prototype.getLogs = function(e, t) {
                        var n = this.fileSystem, r = this.filePath;
                        n.readFile({
                            filePath: r,
                            encoding: "utf8",
                            fail: function(e) {
                                console.error(e);
                            },
                            success: function(e) {
                                e = (void 0 === (e = e.data) ? "" : e).toString().split("\n").filter(function(e) {
                                    return e;
                                }).map(function(e) {
                                    return JSON.parse(e);
                                }), t(null, e);
                            }
                        });
                    }, he.prototype.checkLimit = function(e, t) {
                        void 0 === t && (t = function() {});
                        var n = this.fileSystem, r = this.filePath, i = this.limitSize;
                        n.readFile({
                            filePath: r,
                            encoding: "utf8",
                            success: function(o) {
                                if ((o = (o = void 0 === (o = o.data) ? "" : o).toString() + e).length > i) {
                                    for (var a = o.split("\n"), s = "", l = a.length - 1; 0 <= l && !(a[l] && (s = a[l] + "\n" + s).length > i); l--) ;
                                    n.writeFile({
                                        filePath: r,
                                        data: s,
                                        success: t
                                    });
                                } else n.appendFile({
                                    data: e,
                                    filePath: r,
                                    encoding: "utf8",
                                    success: t,
                                    fail: function(e) {
                                        console.error(e);
                                    }
                                });
                            }
                        });
                    }, he), Y = new K({
                        name: "device",
                        onNewAegis: function(e) {
                            return t = this, r = function() {
                                return function(e, t) {
                                    var n, r, i, o = {
                                        label: 0,
                                        sent: function() {
                                            if (1 & i[0]) throw i[1];
                                            return i[1];
                                        },
                                        trys: [],
                                        ops: []
                                    }, a = {
                                        next: s(0),
                                        throw: s(1),
                                        return: s(2)
                                    };
                                    return "function" == typeof Symbol && (a[Symbol.iterator] = function() {
                                        return this;
                                    }), a;
                                    function s(a) {
                                        return function(s) {
                                            var l = [ a, s ];
                                            if (n) throw new TypeError("Generator is already executing.");
                                            for (;o; ) try {
                                                if (n = 1, r && (i = 2 & l[0] ? r.return : l[0] ? r.throw || ((i = r.return) && i.call(r), 
                                                0) : r.next) && !(i = i.call(r, l[1])).done) return i;
                                                switch (r = 0, (l = i ? [ 2 & l[0], i.value ] : l)[0]) {
                                                  case 0:
                                                  case 1:
                                                    i = l;
                                                    break;

                                                  case 4:
                                                    return o.label++, {
                                                        value: l[1],
                                                        done: !1
                                                    };

                                                  case 5:
                                                    o.label++, r = l[1], l = [ 0 ];
                                                    continue;

                                                  case 7:
                                                    l = o.ops.pop(), o.trys.pop();
                                                    continue;

                                                  default:
                                                    if (!((i = 0 < (i = o.trys).length && i[i.length - 1]) || 6 !== l[0] && 2 !== l[0])) {
                                                        o = 0;
                                                        continue;
                                                    }
                                                    if (3 === l[0] && (!i || l[1] > i[0] && l[1] < i[3])) o.label = l[1]; else if (6 === l[0] && o.label < i[1]) o.label = i[1], 
                                                    i = l; else {
                                                        if (!(i && o.label < i[2])) {
                                                            i[2] && o.ops.pop(), o.trys.pop();
                                                            continue;
                                                        }
                                                        o.label = i[2], o.ops.push(l);
                                                    }
                                                }
                                                l = t.call(e, o);
                                            } catch (s) {
                                                l = [ 6, s ], r = 0;
                                            } finally {
                                                n = i = 0;
                                            }
                                            if (5 & l[0]) throw l[1];
                                            return {
                                                value: l[0] ? l[1] : void 0,
                                                done: !0
                                            };
                                        };
                                    }
                                }(this, function(t) {
                                    return this.setSystemInfo(e), this.refreshNetwork(e), this.setNetworkChange(e), 
                                    [ 2 ];
                                });
                            }, new (n = (n = void 0) || Promise)(function(e, i) {
                                function o(e) {
                                    try {
                                        s(r.next(e));
                                    } catch (e) {
                                        i(e);
                                    }
                                }
                                function a(e) {
                                    try {
                                        s(r.throw(e));
                                    } catch (e) {
                                        i(e);
                                    }
                                }
                                function s(t) {
                                    var r;
                                    t.done ? e(t.value) : ((r = t.value) instanceof n ? r : new n(function(e) {
                                        e(r);
                                    })).then(o, a);
                                }
                                s((r = r.apply(t, [])).next());
                            });
                            var t, n, r;
                        },
                        setSystemInfo: function(e) {
                            var t = this;
                            try {
                                O("getSystemInfo") && $.getSystemInfo({
                                    success: function(n) {
                                        var r = n.platform, i = n.model, o = n.windowHeight, a = n.windowWidth, s = void 0 === (s = n.screenWidth) ? 0 : s;
                                        n = void 0 === (n = n.screenHeight) ? 0 : n, e.extendBean("platform", t.getPlatFormType(r)), 
                                        e.extendBean("model", i), e.extendBean("vp", Math.round(a) + " * " + Math.round(o)), 
                                        e.extendBean("sr", Math.round(s) + " * " + Math.round(n));
                                    }
                                });
                            } catch (e) {}
                        },
                        getPlatFormType: function(e) {
                            for (var t, n = {
                                android: /android/i,
                                ios: /ios/i,
                                windows: /windows/i,
                                macos: /mac/i,
                                devtools: /devtools/i
                            }, r = k.other, i = 0; i < Object.keys(n).length; i++) {
                                var o = Object.keys(n)[i];
                                if (null != (t = n[o]) && t.test(e)) {
                                    r = k[o];
                                    break;
                                }
                            }
                            return r;
                        },
                        setNetworkChange: function(e) {
                            O("onNetworkStatusChange") && $.onNetworkStatusChange(function(t) {
                                t = R(t.networkType), e.extendBean("netType", t);
                            });
                        },
                        setNetworkType: function(e) {
                            O("getNetworkType") && $.getNetworkType({
                                success: function(t) {
                                    t = R(t.networkType), e.extendBean("netType", t);
                                }
                            });
                        },
                        refreshNetwork: function(e) {
                            var t = this;
                            this.timer && clearTimeout(this.timer), this.setNetworkType(e), this.timer = setTimeout(function() {
                                t.refreshNetwork(e);
                            }, 1e4);
                        }
                    }), Z = $.request, ee = (t(de, q = G), Object.defineProperty(de.prototype, "getBean", {
                        get: function() {
                            var e = this;
                            return this.bean ? Object.getOwnPropertyNames(this.bean).map(function(t) {
                                return t + "=" + e.bean[t];
                            }).join("&") + "&from=" + encodeURIComponent(w(this.config)) : "from=" + encodeURIComponent(w(this.config));
                        },
                        enumerable: !1,
                        configurable: !0
                    }), de.prototype.initOfflineLog = function() {
                        de.use(z);
                    }, de.prototype.uploadLogs = function(e, t) {
                        this.lifeCycle.emit("uploadLogs", e = void 0 === e ? {} : e, t = void 0 === t ? {} : t);
                    }, de.prototype.reportPv = function(e) {
                        var t, n = this;
                        e && (t = Object.getOwnPropertyNames(this.bean).filter(function(e) {
                            return "id" !== e;
                        }).map(function(e) {
                            return e + "=" + n.bean[e];
                        }).join("&") + "&from=" + encodeURIComponent(w(this.config)), this.send({
                            url: this.config.url + "/" + e + "?" + t,
                            addBean: !1,
                            type: C.CUSTOM_PV,
                            log: C.CUSTOM_PV
                        }, function() {}, function() {}));
                    }, de.sessionID = "session-" + Date.now(), de.asyncPluginIndex = 0, G = de, new K({
                        name: "aid",
                        onNewAegis: function(e) {
                            this.initAid(function(t) {
                                e.bean.aid = t, e.config.aid = t;
                            });
                        },
                        initAid: function(e) {
                            $.getStorage({
                                key: "AEGIS_ID",
                                success: function(t) {
                                    e(t.data);
                                },
                                fail: function() {
                                    var t = "xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx".replace(/[xy]/g, function(e) {
                                        var t = 16 * Math.random() | 0;
                                        return ("x" === e ? t : 3 & t | 8).toString(16);
                                    });
                                    $.setStorage({
                                        key: "AEGIS_ID",
                                        data: t,
                                        success: function() {
                                            e(t);
                                        }
                                    });
                                }
                            });
                        }
                    })), te = (pe.prototype.addCallback = function(e) {
                        e && this.callbacks.push(e);
                    }, pe.prototype.prefixHandler = function(e) {
                        return r(r({}, e), {
                            aegisRequestStartTime: +new Date()
                        });
                    }, pe.prototype.successHandler = function(e, t) {
                        var n;
                        this.callbacks.forEach(function(n) {
                            var r;
                            try {
                                null != (r = n.success) && r.call(n, e, t);
                            } catch (n) {}
                        }), null != (n = t.success) && n.call(t, e, t);
                    }, pe.prototype.failHandler = function(e, t) {
                        var n;
                        this.callbacks.forEach(function(n) {
                            var r;
                            try {
                                null != (r = n.fail) && r.call(n, e, t);
                            } catch (n) {}
                        }), null != (n = t.fail) && n.call(t, e, t);
                    }, pe.prototype.completeHandler = function(e, t) {
                        var n;
                        this.callbacks.forEach(function(n) {
                            var r;
                            try {
                                null != (r = n.complete) && r.call(n, e, t);
                            } catch (n) {}
                        }), null != (n = t.complete) && n.call(t, e, t);
                    }, pe.prototype.override = function() {
                        try {
                            this.defineApiProperty();
                        } catch (e) {
                            console.warn("cannot override `" + this.apiName + "`, error is: " + e);
                        } finally {
                            this.isOverride = !0;
                        }
                    }, pe), ne = wx || qq, re = {}, ie = (t(fe, A = te), fe.prototype.defineApiProperty = function() {
                        var e = this;
                        ne.cloud && ne.cloud[this.apiName] && Object.defineProperty(ne.cloud, this.apiName, {
                            get: function() {
                                return e.hackHandler.bind(e);
                            }
                        });
                    }, fe.prototype.hackHandler = function(e) {
                        var t = this, n = this.prefixHandler(e);
                        return new Promise(function(e, i) {
                            var o = null == (o = re[t.apiName]) ? void 0 : o.originApi;
                            null != o && o(r(r({}, n), {
                                success: function(r) {
                                    t.successHandler(r, n), e(r);
                                },
                                fail: function(e) {
                                    t.failHandler(e, n), i(e);
                                },
                                complete: function(e) {
                                    t.completeHandler(e, n);
                                }
                            }));
                        });
                    }, fe), oe = wx || qq, ae = {}, se = (t(ue, L = te), ue.prototype.defineApiProperty = function() {
                        var e = this;
                        Object.defineProperty(oe, this.apiName, {
                            get: function() {
                                return e.hackHandler.bind(e);
                            }
                        });
                    }, ue.prototype.hackHandler = function(e) {
                        var t = this, n = this.prefixHandler(e);
                        return null == (e = null == (e = ae[this.apiName]) ? void 0 : e.originApi) ? void 0 : e(r(r({}, n), {
                            success: function(e) {
                                t.successHandler(e, n);
                            },
                            fail: function(e) {
                                t.failHandler(e, n);
                            },
                            complete: function(e) {
                                t.completeHandler(e, n);
                            }
                        }));
                    }, ue), le = wx || qq, ce = le.request;
                    function ue() {
                        return null !== L && L.apply(this, arguments) || this;
                    }
                    function fe() {
                        return null !== A && A.apply(this, arguments) || this;
                    }
                    function pe(e) {
                        this.callbacks = [], this.isOverride = !1;
                        var t = e.apiName;
                        this.apiName = t, this.isOverride || this.override(), this.callbacks.push(e);
                    }
                    function de(e) {
                        var t, i, o, a = q.call(this, e) || this;
                        a.originRequest = Z, a.speedLogPipeline = y([ (i = a.config, o = {}, function(e, t) {
                            var r, a;
                            i.speedSample ? (a = "object" == n(i.repeat) ? i.repeat : {
                                repeat: i.repeat
                            }, r = +a.speed || +a.repeat || 5, Array.isArray(e) ? (a = e.filter(function(e) {
                                var t = !o[e.url] || o[e.url] < r;
                                return o[e.url] = 1 + ~~o[e.url], t;
                            })).length && t(a) : (!o[e.url] || o[e.url] < r) && (o[e.url] = 1 + ~~o[e.url], 
                            t(e))) : t(e);
                        }), d(a), function(e, n) {
                            O("getNetworkType") ? $.getNetworkType({
                                success: function(r) {
                                    r = R(r.networkType), t.extendBean("netType", r), n(e);
                                }
                            }) : n(e);
                        }, function(e, t) {
                            a.lifeCycle.emit("beforeReportSpeed", e);
                            var n = a.config.beforeReportSpeed;
                            if ((e = "function" == typeof n ? e.filter(function(e) {
                                return !1 !== n(e);
                            }) : e).length) return t(e);
                        }, g(t = a, C.SPEED), function(e) {
                            var t, n, i, o;
                            a.send({
                                url: "" + a.config.speedUrl,
                                method: "post",
                                data: (e = e, t = a.bean, i = {
                                    fetch: [],
                                    static: [],
                                    bridge: []
                                }, o = {}, Array.isArray(e) ? e.forEach(function(e) {
                                    var t;
                                    null != (t = i[e.type]) && t.push(e);
                                }) : null != (n = i[e.type]) && n.push(e), o.payload = JSON.stringify(r({
                                    duration: i
                                }, t)), o)
                            });
                        } ]), a.requestQueue = [], a.requesting = !1, a.request = function(e, t, i) {
                            if (e.url && a.bean.id) {
                                var o, s, l, c, u;
                                if (/^\w{8}-\w{4}-\w{4}-\w{4}-\w{12}$/.test(String(a.bean.aid)) && !(a.requesting || O("getNetworkType") && void 0 === a.bean.netType)) return a.requesting = !0, 
                                o = e.url, a.config.whiteListUrl === o && (s = t, t = function(e) {
                                    null != s && s(JSON.stringify(e.data));
                                }), !1 !== e.addBean && (o = o + (-1 === o.indexOf("?") ? "?" : "&") + a.getBean), 
                                f = e.method || "get", l = function() {
                                    a.requesting = !1;
                                    var e = a.requestQueue.shift();
                                    e && a.request(e.options, e.success, e.fail);
                                }, c = e, (c = (u = a.config.onBeforeRequest) ? u(e, a) : c) && c.url ? (u = a.config.enableHttp2 || !1, 
                                "get" === f ? (f = o, p = c.data, o = "string" != typeof f ? "" : "object" == n(p) && p ? (d = Object.getOwnPropertyNames(p).map(function(e) {
                                    var t = p[e];
                                    return e + "=" + ("string" == typeof t ? encodeURIComponent(t) : encodeURIComponent(JSON.stringify(t)));
                                }).join("&").replace(/eval/gi, "evaI"), f + (-1 === f.indexOf("?") ? "?" : "&") + d) : f, 
                                a.originRequest(r({
                                    url: o,
                                    enableHttp2: u,
                                    success: t,
                                    fail: i,
                                    complete: l
                                }, e.requestConfig))) : ("string" == typeof c.data && (c.data = c.data.replace(/eval/gi, "evaI")), 
                                a.originRequest(r({
                                    url: o,
                                    enableHttp2: u,
                                    header: c.contentType ? {
                                        "content-type": c.contentType
                                    } : void 0,
                                    method: "POST",
                                    data: c.data,
                                    success: t,
                                    fail: i,
                                    complete: l
                                }, e.requestConfig))), !0) : (d = "", c && c.url || (d = "Sending request blocked. Please handle the parameters reasonably, options.url is necessary", 
                                console.log(d)), null != i && i(d), l(), !1);
                                a.requestQueue.push({
                                    options: e,
                                    success: t,
                                    fail: i
                                });
                            }
                            var f, p, d;
                        };
                        try {
                            e.offlineLog && a.initOfflineLog(), a.init(e), a.extendBean("sessionId", de.sessionID), 
                            a.extendBean("referer", (O("getLaunchOptionsSync") ? $.getLaunchOptionsSync() : {
                                scene: ""
                            }).scene || "");
                        } catch (e) {
                            console.warn(e), console.log("%cThe above error occurred in the process of initializing Aegis, which will affect your normal use of Aegis.\nIt is recommended that you contact us for feedback and thank you for your support.", "color: red"), 
                            a.sendSDKError(e);
                        }
                        return a;
                    }
                    function he(e) {
                        var t, n, r = this, i = void 0 === (i = (e = void 0 === e ? {} : e).path) ? "/.aegis.offline.log" : i;
                        e = void 0 === (e = e.limit) ? 2e4 : e, this.offlineBuffer = [], this.insertLog = (t = null, 
                        n = [], function(e) {
                            n = n.concat(e), t = t || setTimeout(function() {
                                t = null;
                                var e, i = r.fileSystem, o = r.filePath, a = n.map(function(e) {
                                    return JSON.stringify(e);
                                }).join("\n") + "\n";
                                a && (e = function(e) {
                                    e ? r.checkLimit(a, function() {
                                        n = [];
                                    }) : i.writeFile({
                                        data: a,
                                        filePath: o,
                                        encoding: "utf8",
                                        fail: function(e) {
                                            console.error(e);
                                        },
                                        success: function() {
                                            n = [];
                                        }
                                    });
                                }, i.access({
                                    path: o,
                                    success: function() {
                                        e(!0);
                                    },
                                    fail: function() {
                                        e();
                                    }
                                }));
                            }, 2e3);
                        }), this.ready = function(e) {
                            r.fileSystem ? setTimeout(function() {
                                e(null);
                            }, 0) : (e(new Error("getFileSystemManager file")), r.offlineLog = !1);
                        }, this.clearLogs = function() {
                            var e = r.fileSystem, t = r.filePath;
                            e.writeFile({
                                filePath: t,
                                data: "",
                                fail: function() {
                                    e.unlinkSync(t);
                                }
                            });
                        }, this.save2Offline = function(e, t) {
                            e = (e = Array.isArray(e) ? e : [ e ]).map(function(e) {
                                return "string" == typeof e && (e = {
                                    msg: e
                                }), function() {
                                    for (var e = [], t = 0; t < arguments.length; t++) e[t] = arguments[t];
                                    if (0 === e.length) throw new TypeError("Cannot convert undefined or null to object");
                                    for (var n = Object(e[0]), r = 1; r < e.length; r++) {
                                        var i = e[r];
                                        if (null !== i) for (var o in i) Object.prototype.hasOwnProperty.call(i, o) && (n[o] = i[o]);
                                    }
                                    return n;
                                }({
                                    id: t.id,
                                    uin: t.uin,
                                    time: +Date.now(),
                                    version: t.version,
                                    from: w(t)
                                }, e);
                            }), r.fileSystem ? r.insertLog(e) : (r.fileSystem || r.offlineBuffer.length || r.ready(function(e) {
                                e ? console.error(e) : r.offlineBuffer.length && (r.addLogs(r.offlineBuffer), r.offlineBuffer = []);
                            }), r.offlineBuffer = r.offlineBuffer.concat(e));
                        }, this.addLogs = function(e) {
                            r.fileSystem && r.insertLog(e);
                        }, this.filePath = $.env.USER_DATA_PATH + i, this.fileSystem = $.getFileSystemManager(), 
                        this.limitSize = e;
                    }
                    function ge(e) {
                        this.aegisPlugin = !0, this.name = "", this.instances = [], this.inited = !1, e.$walk = this.walk.bind(this), 
                        e.$getConfig = this.getConfig.bind(this), this.option = e, this.name = e.name;
                    }
                    function me(e) {
                        var t, n, r, i, o, s, l, c, u, f, p, g, m, v, b, w = this;
                        this.isGetSample = !1, this.isHidden = !1, this.config = {
                            version: 0,
                            delay: 1e3,
                            onError: !0,
                            repeat: 5,
                            random: 1,
                            aid: !0,
                            device: !0,
                            pagePerformance: !0,
                            webVitals: !0,
                            speedSample: !0,
                            onClose: !0,
                            hostUrl: "https://aegis.qq.com",
                            websocketHack: !1,
                            env: "production",
                            url: "",
                            offlineUrl: "",
                            whiteListUrl: "",
                            pvUrl: "",
                            speedUrl: "",
                            customTimeUrl: "",
                            performanceUrl: "",
                            webVitalsUrl: "",
                            eventUrl: "",
                            setDataReportUrl: "",
                            reportImmediately: !0
                        }, this.isWhiteList = !1, this.lifeCycle = new a(), this.bean = {}, this.normalLogPipeline = y([ d(this, 5), h, function(e, n) {
                            var r = t.config;
                            n(e = e.map(function(e) {
                                var t, n = r.maxLength || 102400;
                                try {
                                    if (!e.msg || e.msg.length <= n) return e;
                                    e.msg = null == (t = e.msg) ? void 0 : t.substring(0, n);
                                } catch (t) {
                                    e.msg = _(e.msg).substring(0, r.maxLength);
                                }
                                return e;
                            }));
                        }, (v = (t = this).config, b = {}, function(e, t) {
                            var n = "number" == typeof v.repeat ? v.repeat : 5;
                            if (0 === n) return t(e);
                            t(e.filter(function(e) {
                                return e.level !== x.ERROR && e.level !== x.PROMISE_ERROR && e.level !== x.AJAX_ERROR && e.level !== x.SCRIPT_ERROR && e.level !== x.IMAGE_ERROR && e.level !== x.CSS_ERROR && e.level !== x.MEDIA_ERROR || (b[e.msg] = b[e.msg] || 0, 
                                b[e.msg] += 1, !(b[e.msg] > n));
                            }));
                        }), (g = this.lifeCycle.emit, m = this.config, function(e, t) {
                            var n, r = m.logCreated;
                            return "function" == typeof r ? (n = e.filter(function(e) {
                                return !1 !== r(e);
                            }), g("beforeWrite", n), t(n)) : (g("beforeWrite", e), t(e));
                        }), (p = this, setTimeout(function() {
                            var e = p.config.pvUrl, t = void 0 === e ? "" : e;
                            t && p.sendPipeline([ function(e, n) {
                                n({
                                    url: t,
                                    type: C.PV,
                                    fail: function(e) {
                                        "403 forbidden" === e && p.destroy();
                                    }
                                });
                            } ], C.PV)(null);
                        }, 100), function(e, t) {
                            t(e);
                        }), (u = c = l = !1, f = [], (o = this).lifeCycle.on("onConfigChange", function() {
                            s && clearTimeout(s), s = setTimeout(function() {
                                var e, t;
                                !u && o.config && (u = !0, e = o.config.whiteListUrl, (t = void 0 === e ? "" : e) && o.sendPipeline([ function(e, n) {
                                    n({
                                        url: t,
                                        type: C.WHITE_LIST,
                                        success: function(e) {
                                            c = !0;
                                            try {
                                                var t = e.data || JSON.parse(e), n = t.retcode, r = t.result, i = void 0 === r ? {} : r;
                                                if (0 === n) {
                                                    if (l = i.is_in_white_list, o.isWhiteList = l, i.shutdown) return void o.destroy();
                                                    0 <= i.rate && i.rate <= 1 && (o.config.random = i.rate, o.isGetSample = !1);
                                                }
                                                o.isWhiteList && f.length ? V(o)(f.splice(0), function() {}) : !o.isWhiteList && f.length && (f.length = 0);
                                                var a = o.config.onWhitelist;
                                                "function" == typeof a && a(l);
                                            } catch (e) {}
                                        },
                                        fail: function(e) {
                                            "403 forbidden" === e && o.destroy(), c = !0;
                                        }
                                    });
                                } ], C.WHITE_LIST)(null), u = !1);
                            }, o.config.uin ? 50 : 500);
                        }), o.lifeCycle.on("destroy", function() {
                            f.length = 0;
                        }), function(e, t) {
                            var n;
                            l || null != (n = null == (n = o.config) ? void 0 : n.api) && n.reportRequest ? t(e.concat(f.splice(0)).map(function(e) {
                                return B(e), e;
                            })) : (n = e.filter(function(e) {
                                return e.level !== x.INFO && e.level !== x.API_RESPONSE ? (B(e), !0) : (c || (f.push(e), 
                                200 <= f.length && (f.length = 200)), !1);
                            })).length && t(n);
                        }), function(e, t) {
                            try {
                                var n = JSON.parse(JSON.stringify(e)), r = (w.lifeCycle.emit("beforeReport", n), 
                                w.config.beforeReport);
                                (e = "function" == typeof r ? e.filter(function(e) {
                                    return !1 !== r(e);
                                }) : e).length && t(e);
                            } catch (e) {}
                        }, V(this) ]), this.eventPipeline = y([ d(this, 10), (i = this, function(e) {
                            i.sendPipeline([ function(e, t) {
                                var n = e.map(function(e) {
                                    return {
                                        name: e.name,
                                        ext1: e.ext1 || i.config.ext1 || "",
                                        ext2: e.ext2 || i.config.ext2 || "",
                                        ext3: e.ext3 || i.config.ext3 || ""
                                    };
                                });
                                t({
                                    url: i.config.eventUrl + "?payload=" + encodeURIComponent(JSON.stringify(n)),
                                    type: C.EVENT,
                                    log: e,
                                    fail: function(e) {
                                        "403 forbidden" === e && i.destroy();
                                    }
                                });
                            } ], C.EVENT)(e);
                        }) ]), this.timeMap = {}, this.failRequestCount = 0, this.customTimePipeline = y([ d(this, 10), (r = this, 
                        function(e) {
                            return r.sendPipeline([ function(e, t) {
                                t({
                                    url: r.config.customTimeUrl + "?payload=" + encodeURIComponent(JSON.stringify({
                                        custom: e
                                    })),
                                    type: C.CUSTOM,
                                    log: e,
                                    fail: function(e) {
                                        "403 forbidden" === e && r.destroy();
                                    }
                                });
                            } ], C.CUSTOM)(e);
                        }) ]), this.config = (n = this.config, void 0 === (e = e.hostUrl) && (e = "https://aegis.qq.com"), 
                        n.url = n.url || e + "/collect", n.offlineUrl = n.offlineUrl || e + "/offline", 
                        n.whiteListUrl = n.whiteListUrl || e + "/collect/whitelist", n.pvUrl = n.pvUrl || e + "/collect/pv", 
                        n.eventUrl = n.eventUrl || e + "/collect/events", n.speedUrl = n.speedUrl || e + "/speed", 
                        n.customTimeUrl = n.customTimeUrl || e + "/speed/custom", n.performanceUrl = n.performanceUrl || e + "/speed/performance", 
                        n.webVitalsUrl = n.webVitalsUrl || e + "/speed/webvitals", n.setDataReportUrl = n.SetDataReportUrl || e + "/speed/miniProgramData", 
                        n), me.instances.push(this);
                    }
                    function ve() {
                        return null !== j && j.apply(this, arguments) || this;
                    }
                    function ye(e, t, r) {
                        return null != t && t.length && "object" == n(e) ? t.reduce(function(t, n) {
                            var i = e[n];
                            return i ? t + ("" === t ? "\n" : "\n\n") + r + " header " + n + ": " + i : t;
                        }, "") : "";
                    }
                    t(ve, j = te), ve.prototype.defineApiProperty = function() {
                        var e = this;
                        Object.defineProperty(le, "request", {
                            get: function() {
                                return e.hackHandler.bind(e);
                            }
                        });
                    };
                    var be, we, Ee = new K({
                        name: "reportApiSpeed",
                        override: !(ve.prototype.hackHandler = function(e) {
                            var t = this, n = this.prefixHandler(e);
                            return ce(r(r({}, n), {
                                success: function(e) {
                                    t.successHandler(e, n);
                                },
                                fail: function(e) {
                                    t.failHandler(e, n);
                                },
                                complete: function(e) {
                                    t.completeHandler(e, n);
                                }
                            }));
                        }),
                        onNewAegis: function(e) {
                            this.override || (this.override = !0, this.hackRequest(e.config), this.overrideCallFunction(e.config), 
                            this.overrideCallContainer(e.config));
                        },
                        hackRequest: function(e) {
                            var t = this;
                            S({
                                apiName: "request",
                                success: function(n, r) {
                                    var i, o, a, s, l, d;
                                    e.hostUrl && -1 < r.url.indexOf(e.hostUrl) || (i = {
                                        method: r.method || "get",
                                        url: c(r.url),
                                        duration: Date.now() - r.aegisRequestStartTime,
                                        status: n.statusCode || 0,
                                        nextHopProtocol: "",
                                        isHttps: u(r.url),
                                        type: "fetch"
                                    }, s = null == (s = e.api) ? void 0 : s.apiDetail, o = (a = f(n.data, e.api, {
                                        url: r.url,
                                        ctx: n
                                    }) || {}).code, a = a.isErr, d = s ? p(r.data, null == (d = e.api) ? void 0 : d.reqParamHandler, {
                                        url: r.url
                                    }) : "", s = s ? p(n.data, null == (s = e.api) ? void 0 : s.resBodyHandler, {
                                        url: r.url
                                    }) : "", l = (null == (l = e.api) ? void 0 : l.reqHeaders) || [], r = ye(null == r ? void 0 : r.header, l, "req"), 
                                    l = (null == (l = e.api) ? void 0 : l.resHeaders) || [], l = ye(null == n ? void 0 : n.header, l, "res"), 
                                    d = "req url: " + i.url + " \n                        \nreq method: " + i.method + " \n                        \nreq param: " + d + " \n                        \nres duration: " + i.duration + "ms \n                        \nres status: " + (n.statusCode || 0) + " \n                        \nres retcode: " + o + " \n                        \nres data: " + s + "\n                        " + r + "\n                        " + l, 
                                    t.publishNormalLog({
                                        msg: d,
                                        level: x.API_RESPONSE,
                                        ctx: n
                                    }), i.ret = o, i.isErr = +a, t.publishSpeedLog(i), a && t.publishNormalLog({
                                        msg: d,
                                        level: x.RET_ERROR,
                                        ctx: n
                                    }));
                                },
                                fail: function(n, r) {
                                    e.hostUrl && -1 < r.url.indexOf(e.hostUrl) || (r = {
                                        method: r.method || "get",
                                        url: c(r.url),
                                        duration: Date.now() - r.aegisRequestStartTime,
                                        status: 0,
                                        nextHopProtocol: "",
                                        isHttps: u(r.url),
                                        type: "fetch"
                                    }, t.publishSpeedLog(r));
                                }
                            });
                        },
                        overrideCallFunction: function(e) {
                            var t = this;
                            P({
                                apiName: "callFunction",
                                success: function(n, r) {
                                    t.cloudSuccessCallback(e, r, n, "callFunction");
                                },
                                fail: function(e, n) {
                                    n = {
                                        method: "call",
                                        url: "wx.cloud.callFunction." + n.name,
                                        duration: Date.now() - n.aegisRequestStartTime,
                                        status: 0,
                                        nextHopProtocol: "",
                                        type: "fetch",
                                        errMsg: e.errMsg,
                                        isHttps: !0
                                    }, t.publishSpeedLog(n);
                                }
                            });
                        },
                        overrideCallContainer: function(e) {
                            var t = this;
                            P({
                                apiName: "callContainer",
                                success: function(n, r) {
                                    t.cloudSuccessCallback(e, r, n, "callContainer");
                                },
                                fail: function(e, n) {
                                    n = {
                                        method: "call",
                                        url: "wx.cloud.callContainer." + n.path,
                                        duration: Date.now() - n.aegisRequestStartTime,
                                        status: 0,
                                        nextHopProtocol: "",
                                        type: "fetch",
                                        errMsg: e.errMsg,
                                        isHttps: !0
                                    }, t.publishSpeedLog(n);
                                }
                            });
                        },
                        cloudSuccessCallback: function(e, t, n, r) {
                            var i = "callFunction" === r ? t.name : t.path, o = "callFunction" === r ? n.result : n.data, a = (i = {
                                method: "call",
                                url: "wx.cloud." + r + "." + i,
                                duration: Date.now() - t.aegisRequestStartTime,
                                status: 200,
                                nextHopProtocol: "",
                                type: "fetch",
                                isHttps: !0
                            }, [ "apiName", "aegisRequestStartTime", "config", "success", "fail", "complete" ]), s = Object.keys(t).reduce(function(e, n) {
                                return a.includes(n) || (e[n] = t[n]), e;
                            }, {}), l = (r = "callFunction" === r ? (null == (r = n.data) ? void 0 : r.code) || 0 : n.statusCode, 
                            (c = f(o, e.api, {
                                url: i.url,
                                ctx: n
                            }) || {}).code), c = void 0 !== (c = c.isErr) && c;
                            i.ret = l, i.isErr = +c, s = (l = null == (l = e.api) ? void 0 : l.apiDetail) ? p(s, null == (s = e.api) ? void 0 : s.reqParamHandler, {
                                url: i.url
                            }) : "", o = l ? p(o, null == (l = e.api) ? void 0 : l.resBodyHandler, {
                                url: i.url
                            }) : "", l = (null == (l = e.api) ? void 0 : l.reqHeaders) || [], l = ye(null == t ? void 0 : t.header, l, "req"), 
                            e = (null == (e = e.api) ? void 0 : e.resHeaders) || [], e = ye(null == n ? void 0 : n.header, e, "res"), 
                            s = "req url: " + i.url + "\n                    \nreq type: " + i.type + "\n                    \nreq params: " + s + "\n                    \nres status: " + r + "\n                    \nres retcode: " + i.ret + "\n                    \nres duration: " + i.duration + "ms \n                    \nres data: " + o + "\n                    " + l + "\n                    " + e, 
                            this.publishNormalLog({
                                msg: s,
                                level: x.API_RESPONSE,
                                ctx: n
                            }), this.publishSpeedLog(i), c && this.publishNormalLog({
                                msg: s,
                                level: x.RET_ERROR,
                                ctx: n
                            });
                        },
                        publishSpeedLog: function(e) {
                            this.$walk(function(t) {
                                t.speedLogPipeline(e);
                            });
                        },
                        publishNormalLog: function(e) {
                            this.$walk(function(t) {
                                t.normalLogPipeline(e);
                            });
                        }
                    }), Oe = wx || qq, Re = Oe.connectSocket, Pe = (Te.prototype.addConfig = function(e) {
                        var t = e.send;
                        e = e.onError, t && this.sends.push(t), e && this.onErrors.push(e);
                    }, Te.prototype.toHack = function(e) {
                        var t = this, n = (this.onErrors.forEach(function(t) {
                            e.onError(t);
                        }), e.send);
                        return Object.defineProperty(e, "send", {
                            get: function() {
                                return function(i) {
                                    return new Promise(function(o) {
                                        n.call(e, r(r({}, i), {
                                            fail: function(e) {
                                                t.sends.forEach(function(t) {
                                                    var n;
                                                    null != (n = t.fail) && n.call(t, e, i);
                                                }), o(e);
                                            }
                                        }));
                                    });
                                };
                            }
                        }), e;
                    }, Te), Se = (t(Ce, we = te), Ce.prototype.addTaskConf = function(e) {
                        this.taskHack.addConfig(e);
                    }, Ce.prototype.defineApiProperty = function() {
                        var e = this;
                        Object.defineProperty(Oe, "connectSocket", {
                            get: function() {
                                return e.hackHandler.bind(e);
                            }
                        });
                    }, Ce.prototype.hackHandler = function(e) {
                        var t = this, n = this.prefixHandler(e);
                        return e = Re(r(r({}, n), {
                            success: function(e) {
                                t.successHandler(e, n);
                            },
                            fail: function(e) {
                                t.failHandler(e, n);
                            },
                            complete: function(e) {
                                t.completeHandler(e, n);
                            }
                        })), this.taskHack.toHack(e), e;
                    }, Ce), xe = (te = new K({
                        name: "onError",
                        onNewAegis: function(e) {
                            var t = $.getSystemInfoSync().SDKVersion;
                            this.listenError(), this.hackNetWork(e), this.hackCloud(e), e.config.websocketHack && E(t, "1.7.0") && this.hackWsConnect();
                        },
                        listenError: function() {
                            var e = this;
                            "function" == typeof $.onError && $.onError(function(t) {
                                t && e.publishErrorLog({
                                    msg: t,
                                    level: x.ERROR
                                });
                            }), O("onUnhandledRejection") && $.onUnhandledRejection(function(t) {
                                !(t = t.reason) || -1 < JSON.stringify(t).indexOf("request:fail") || e.publishErrorLog({
                                    msg: t,
                                    level: x.PROMISE_ERROR
                                });
                            }), O("onPageNotFound") && $.onPageNotFound(function(t) {
                                t && e.publishErrorLog({
                                    msg: t,
                                    level: x.PAGE_NOT_FOUND_ERROR
                                });
                            });
                        },
                        publishErrorLog: function(e) {
                            this.$walk(function(t) {
                                t.normalLogPipeline(e);
                            });
                        },
                        hackNetWork: function(e) {
                            for (var t = this, n = e.config, r = 0, i = [ {
                                apiName: "request",
                                complete: function(e, r) {
                                    return t.requestCompleteError(e, r, n);
                                }
                            }, {
                                apiName: "uploadFile",
                                complete: function(e, r) {
                                    return t.uploadFileCompleteError(e, r, n);
                                }
                            }, {
                                apiName: "downloadFile",
                                complete: function(e, r) {
                                    return t.downloadFileCompleteError(e, r, n);
                                }
                            } ]; r < i.length; r++) {
                                var o;
                                S({
                                    apiName: (o = i[r]).apiName,
                                    complete: o = o.complete
                                });
                            }
                        },
                        requestCompleteError: function(e, t, n) {
                            var r, i = e.errMsg, o = e.statusCode;
                            n.hostUrl && -1 < (null == (r = t.url) ? void 0 : r.indexOf(n.hostUrl)) || (r = this.getErrorType({
                                errMsg: i,
                                statusCode: o
                            })) && this.publishNetWorkError({
                                apiName: "request",
                                opts: t,
                                res: e,
                                config: n,
                                type: r
                            });
                        },
                        downloadFileCompleteError: function(e, t, n) {
                            var r, i = e.errMsg, o = e.statusCode, a = e.filePath, s = (e = e.tempFilePath, 
                            this.getErrorType({
                                errMsg: i,
                                statusCode: o
                            }));
                            s && (n = null != (r = n.api) && r.apiDetail ? p(t.data, null == (r = n.api) ? void 0 : r.reqParamHandler, {
                                url: t.url
                            }) : "", this.publishErrorLog({
                                msg: "AJAX_ERROR: downloadFile " + s + "\n                  \nres status: " + (o || 0) + "\n                  \nres duration: " + (Date.now() - t.aegisRequestStartTime) + "ms\n                  \nres filePath: " + a + "\n                  \nres tempFilePath: " + e + "\n                  \nreq url: " + t.url + "\n                  \nreq method: " + (t.method || "get") + "\n                  \nreq param: " + n + "\n                  \nerrMsg: " + i.slice(0, 1e3),
                                level: x.AJAX_ERROR
                            }));
                        },
                        uploadFileCompleteError: function(e, t, n) {
                            var r = e.errMsg, i = e.statusCode;
                            (r = this.getErrorType({
                                errMsg: r,
                                statusCode: i
                            })) && this.publishNetWorkError({
                                apiName: "uploadFile",
                                opts: t,
                                res: e,
                                config: n,
                                type: r
                            });
                        },
                        hackCloud: function(e) {
                            for (var t = this, n = e.config, r = 0, i = [ {
                                apiName: "callFunction",
                                complete: function(e, r) {
                                    return t.callFunctionCompleteError(e, r, n);
                                }
                            }, {
                                apiName: "callContainer",
                                complete: function(e, r) {
                                    return t.callContainerCompleteError(e, r, n);
                                }
                            } ]; r < i.length; r++) {
                                var o;
                                P({
                                    apiName: (o = i[r]).apiName,
                                    complete: o = o.complete
                                });
                            }
                        },
                        callFunctionCompleteError: function(e, t, n) {
                            var r, i;
                            (-1 < e.errMsg.indexOf("fail") || -1 < e.errMsg.indexOf("timeout")) && (i = (r = null == (r = n.api) ? void 0 : r.apiDetail) ? p(t.data, null == (i = n.api) ? void 0 : i.reqParamHandler, {
                                url: null == t ? void 0 : t.url
                            }) : "", n = r ? p(e, null == (r = n.api) ? void 0 : r.resBodyHandler, {
                                url: null == t ? void 0 : t.url
                            }) : "", this.publishErrorLog({
                                msg: "AJAX_ERROR: cloud.callFunction:fail\n                    \nres status: 0\n                    \nres duration: " + (Date.now() - t.aegisRequestStartTime) + "ms\n                    \nres data: " + n + "\n                    \nreq url: cloud.callFunction." + t.name + "\n                    \nreq method: POST\n                    \nreq param: " + i + "\n                    \nerrMsg: " + e.errMsg.slice(0, 1e3),
                                level: x.AJAX_ERROR
                            }));
                        },
                        callContainerCompleteError: function(e, t, n) {
                            var r, i, o, a = e.errMsg, s = e.statusCode;
                            (400 <= s || -1 < a.indexOf("fail") || -1 < a.indexOf("timeout")) && (r = (i = null == (i = n.api) ? void 0 : i.apiDetail) ? p(t.data, null == (r = n.api) ? void 0 : r.reqParamHandler, {
                                url: null == t ? void 0 : t.url
                            }) : "", i = i ? p(e, null == (i = n.api) ? void 0 : i.resBodyHandler, {
                                url: null == t ? void 0 : t.url
                            }) : "", o = (null == (o = n.api) ? void 0 : o.reqHeaders) || [], o = ye(null == t ? void 0 : t.header, o, "req"), 
                            n = (null == (n = n.api) ? void 0 : n.resHeaders) || [], e = ye(null == e ? void 0 : e.header, n, "res"), 
                            this.publishErrorLog({
                                msg: "AJAX_ERROR: cloud.callContainer:fail\n                    \nreq url: " + t.path + "\n                    \nreq method: " + (t.method || "POST") + "\n                    \nreq param: " + r + "\n                    \nres status: " + (s || 0) + "\n                    \nres duration: " + (Date.now() - t.aegisRequestStartTime) + "ms\n                    \nres data: " + i + "\n                    \nerrMsg: " + a.slice(0, 1e3) + "\n                    " + o + "\n                    " + e,
                                level: x.AJAX_ERROR
                            }));
                        },
                        publishNetWorkError: function(e) {
                            var t = e.apiName, n = e.opts, r = e.res, i = e.config, o = (e = e.type, r.errMsg), a = r.statusCode, s = r.data, l = "wx.cloud.callFunction." + n.url, c = f(s, i.api, {
                                url: l,
                                ctx: r
                            }).code, u = (d = null == (d = i.api) ? void 0 : d.apiDetail) ? p(n.data, null == (u = i.api) ? void 0 : u.reqParamHandler, {
                                url: l
                            }) : "", d = (s = d ? p(s, null == (d = i.api) ? void 0 : d.resBodyHandler, {
                                url: l
                            }) : "", l = (null == (d = i.api) ? void 0 : d.reqHeaders) || [], ye(null == n ? void 0 : n.header, l, "req"));
                            i = (null == (l = i.api) ? void 0 : l.resHeaders) || [], l = ye(null == r ? void 0 : r.header, i, "res"), 
                            this.publishErrorLog({
                                msg: "AJAX_ERROR: " + t + " " + e + "\n                  \nreq url: " + n.url + "\n                  \nreq method: " + (n.method || "get") + "\n                  \nreq param: " + u + "\n                  \nres status: " + (a || 0) + "\n                  \nres retcode: " + c + "\n                  \nres duration: " + (Date.now() - n.aegisRequestStartTime) + "ms\n                  \nres data: " + s + "\n                  \nerrMsg: " + o.slice(0, 1e3) + "\n                  " + d + "\n                  " + l,
                                level: x.AJAX_ERROR
                            });
                        },
                        getErrorType: function(e) {
                            var t = e.errMsg, n = (e = e.statusCode, "");
                            return -1 < t.indexOf("timeout") || -1 < t.indexOf("超时") ? n = "timeout" : 400 <= e ? n = "error" : (-1 < t.indexOf("fail") || !e || e < 0) && (n = "failed"), 
                            n;
                        },
                        hackWsConnect: function() {
                            var e, t, n = this;
                            S({
                                apiName: "sendSocketMessage",
                                fail: function(e) {
                                    n.publishSocketError(e);
                                }
                            }), e = (t = {
                                connectCallback: {
                                    fail: function(e) {
                                        n.publishSocketError(e);
                                    }
                                },
                                taskOpt: {
                                    onError: function(e) {
                                        n.publishSocketError(e);
                                    },
                                    send: {
                                        fail: function(e) {
                                            n.publishSocketError(e);
                                        }
                                    }
                                }
                            }).connectCallback, t = t.taskOpt, be ? be.addCallback(e) : be = new Se(e), t && be.addTaskConf(t);
                        },
                        publishSocketError: function(e) {
                            e && this.publishErrorLog({
                                msg: e.errMsg,
                                level: x.WEBSOCKET_ERROR
                            });
                        }
                    }), new K({
                        name: "reportAssetSpeed",
                        isStart: !1,
                        onNewAegis: function(e) {
                            this.isStart || (this.isStart = !0, this.start(e));
                        },
                        start: function() {
                            var e = this;
                            $.getPerformance && $.getPerformance().createObserver(function(t) {
                                null != (t = t.getEntries()) && t.forEach(function(t) {
                                    "number" != typeof t.duration || t.duration <= 0 || e.publishAssetLog(t);
                                });
                            }).observe({
                                entryTypes: [ "resource" ]
                            });
                        },
                        generateLog: function(e) {
                            return {
                                url: "" + c(e.uri),
                                method: "get",
                                duration: Math.round(100 * e.duration) / 100,
                                status: 200,
                                type: "static",
                                isHttps: !0,
                                urlQuery: "",
                                nextHopProtocol: "",
                                domainLookup: 0,
                                connectTime: 0
                            };
                        },
                        publishAssetLog: function(e) {
                            var t = this;
                            this.$walk(function(n) {
                                n.speedLogPipeline(t.generateLog(e));
                            });
                        }
                    })), ke = [ "onLaunch", "onHide", "onError", "onLoad", "onReady", "onShow", "onUnload" ], Ne = new K({
                        name: "pagePerformance",
                        pageNavigationStartTime: {},
                        onNewAegis: function(e) {
                            try {
                                O("getPerformance") && this.reportPerformance(e), this.setPagePV(e), this.reportSetDataTiming(e);
                            } catch (e) {}
                        },
                        reportPerformance: function(e) {
                            var t = this, n = null == (n = $.getPerformance()) ? void 0 : n.createObserver(function(n) {
                                var r = {}, i = null == (i = n.getEntriesByName("appLaunch")) ? void 0 : i[0], o = null == (o = n.getEntriesByName("firstRender")) ? void 0 : o[0], a = null == (a = n.getEntriesByName("evaluateScript")) ? void 0 : a[0], s = null == (s = n.getEntriesByName("route")) ? void 0 : s[0], l = null == (l = null == (l = n.getEntriesByName("firstPaint")) ? void 0 : l[0]) ? void 0 : l.startTime, c = null == (c = (null == (c = n.getEntriesByName("firstPaint")) ? void 0 : c[0]) || (null == (c = n.getEntriesByName("route")) ? void 0 : c[0]) || (null == (c = n.getEntriesByName("appLaunch")) ? void 0 : c[0])) ? void 0 : c.pageId, u = null == (n = (null == (u = n.getEntriesByName("route")) ? void 0 : u[0]) || (null == (u = n.getEntriesByName("appLaunch")) ? void 0 : u[0])) ? void 0 : n.startTime;
                                c && (t.pageNavigationStartTime[c] = null, u) && (t.pageNavigationStartTime[c] = u), 
                                i && (r.appLaunch = i.duration), o && (r.firstScreenTiming = o.duration), a && (r.scriptEvaluateTiming = a.duration), 
                                s && (r.pageRouteTiming = s.duration), l && u ? r.firstPaintTiming = Math.max(l - u, 0) : l && t.pageNavigationStartTime[c] && (r.firstPaintTiming = Math.max(l - t.pageNavigationStartTime[c], 0)), 
                                t.publish(r, e);
                            });
                            null != n && n.observe({
                                entryTypes: [ "navigation", "render", "script" ]
                            });
                        },
                        publish: function(e, t) {
                            var n, r, i, o = [], a = t.config, s = -1 === (null == (n = t.config.performanceUrl) ? void 0 : n.indexOf("?")) ? "?" : "&";
                            for (r in e) o.push(r + "=" + e[r]);
                            "function" == typeof a.urlHandler ? (i = a.urlHandler() || window.location.href, 
                            this.$walk(function(n) {
                                n.send({
                                    url: t.config.performanceUrl + s + o.join("&") + "&from=" + encodeURIComponent(i),
                                    beanFilter: [ "from" ],
                                    type: C.PERFORMANCE,
                                    log: e
                                });
                            })) : this.$walk(function(n) {
                                n.send({
                                    url: t.config.performanceUrl + s + o.join("&"),
                                    type: C.PERFORMANCE,
                                    log: e
                                });
                            });
                        },
                        setPagePV: function(e) {
                            var t = this;
                            $.onAppRoute && $.onAppRoute(function(e) {
                                "appLaunch" !== e.openType && (t.$walk(function(e) {
                                    e.send({
                                        url: "" + e.config.pvUrl,
                                        type: C.PV
                                    });
                                }), t.reportPageLoaded(e));
                            });
                        },
                        reportPageLoaded: function(e) {
                            e = "infoType: behaviorBacktracking\ndataType: pageLoadAndRoute\npageLoadedPath: " + e.path + "\nopenType: " + e.openType, 
                            this.publishNormalLog({
                                msg: e,
                                level: x.INFO
                            });
                        },
                        publishNormalLog: function(e) {
                            this.$walk(function(t) {
                                t.normalLogPipeline(e);
                            });
                        },
                        reportSetDataTiming: function(e) {
                            var t, n, r, i, o, a, s, l, c, u, f = this;
                            !0 !== (u = (u = e.config).setDataReportConfig || (null == (u = u.pagePerformance) ? void 0 : u.setDataReportConfig) || {}).disabled && (t = u.timeThreshold, 
                            n = !1 !== u.withDataPaths, r = t && 0 < +t ? +t : 30, i = y([ d(e, 10), function(t) {
                                t = t.map(function(e) {
                                    return {
                                        type: C.SET_DATA,
                                        component: e.from,
                                        duration: e.duration,
                                        fields: e.dataPaths && e.dataPaths.length ? e.dataPaths.sort().join(";") : void 0,
                                        size: e.size
                                    };
                                }), e.send({
                                    url: e.config.setDataReportUrl + "?payload=" + encodeURIComponent(JSON.stringify({
                                        miniProgramData: t
                                    })),
                                    type: C.SET_DATA,
                                    log: t
                                });
                            } ]), o = Page, a = Component, s = function(e, t) {
                                var n = 0;
                                return null != e && e.data ? (t.forEach(function(t) {
                                    for (var r = e.data[t[0]], i = 1, o = t.length; i < o; i++) r[t[i]] && (r = r[t[i]]);
                                    var a = "";
                                    try {
                                        a = JSON.stringify(r);
                                    } catch (t) {
                                        a = "";
                                    }
                                    n += 2 * (void 0 === a ? "" : a).replace(/[\u4e00-\u9fa5]/g, "aa").length;
                                }), n = Math.min(n, 10485760)) : n;
                            }, l = function(e, t) {
                                var o = t.updateStartTimestamp, a = t.updateEndTimestamp;
                                t = void 0 === (t = t.dataPaths) ? [] : t, a -= o, isNaN(a) || a < r || (o = {
                                    from: e.is,
                                    duration: a
                                }, n && 0 < t.length && Object.assign(o, {
                                    dataPaths: t.slice(0, 30),
                                    size: s(e, t)
                                }), i(o));
                            }, c = function(e) {
                                var t = "infoType: behaviorBacktracking\ndataType: tapEvent" + Object.keys(e[0]).reduce(function(t, n) {
                                    var r = "";
                                    try {
                                        r = n + ": " + JSON.stringify(e[0][n]);
                                    } catch (t) {
                                        r = "";
                                    }
                                    return t + "\n" + r;
                                }, "");
                                f.publishNormalLog({
                                    msg: t,
                                    level: x.INFO
                                });
                            }, Page = function(e) {
                                var t = e.onReady;
                                return e.onReady = function() {
                                    var e = this;
                                    return "function" == typeof this.setUpdatePerformanceListener && this.setUpdatePerformanceListener({
                                        withDataPaths: n
                                    }, function(t) {
                                        l(e, t);
                                    }), null == t ? void 0 : t.call(this);
                                }, Object.keys(e).forEach(function(t) {
                                    var n;
                                    "function" != typeof e[t] || ke.includes(t) || (n = e[t], e[t] = function() {
                                        for (var e = [], t = 0; t < arguments.length; t++) e[t] = arguments[t];
                                        return null != e && e[0] && "tap" === e[0].type && c(e), null == n ? void 0 : n.apply(this, e);
                                    });
                                }), o(e);
                            }, Component = function(e) {
                                e.lifetimes && e.lifetimes.attached ? (t = e.lifetimes.attached, e.lifetimes.attached = function() {
                                    var e = this;
                                    return "function" == typeof this.setUpdatePerformanceListener && this.setUpdatePerformanceListener({
                                        withDataPaths: n
                                    }, function(t) {
                                        l(e, t);
                                    }), null == t ? void 0 : t.call(this);
                                }) : (r = e.attached, e.attached = function() {
                                    var e = this;
                                    return "function" == typeof this.setUpdatePerformanceListener && this.setUpdatePerformanceListener({
                                        withDataPaths: n
                                    }, function(t) {
                                        l(e, t);
                                    }), null == r ? void 0 : r.call(this);
                                });
                                var t, r, i = e.methods;
                                return i && "[object Object]" === Object.prototype.toString.call(i) && Object.keys(i).forEach(function(e) {
                                    var t;
                                    "function" == typeof i[e] && (t = i[e], i[e] = function() {
                                        for (var e = [], n = 0; n < arguments.length; n++) e[n] = arguments[n];
                                        return null != e && e[0] && "tap" === e[0].type && c(e), null == t ? void 0 : t.apply(this, e);
                                    });
                                }), a(e);
                            });
                        }
                    });
                    function Ce(e) {
                        return (e = we.call(this, e) || this).taskHack = new Pe(), e;
                    }
                    function Te() {
                        this.onErrors = [], this.sends = [];
                    }
                    return K = new K({
                        name: "reportLoadPackageSpeed",
                        isLoaded: !1,
                        onNewAegis: function(e) {
                            this.isLoaded || (this.isLoaded = !0, this.start(e));
                        },
                        start: function() {
                            var e = this;
                            $.getPerformance && $.getPerformance().createObserver(function(t) {
                                null != (t = t.getEntries()) && t.forEach(function(t) {
                                    "number" != typeof t.duration || t.duration <= 0 || e.publishPackageLog(t);
                                });
                            }).observe({
                                entryTypes: [ "loadPackage" ]
                            });
                        },
                        generateLog: function(e) {
                            return [ {
                                type: C.LOAD_PACKAGE,
                                packageName: e.packageName,
                                size: Math.round(100 * e.packageSize) / 100,
                                duration: Math.round(100 * e.duration) / 100
                            } ];
                        },
                        publishPackageLog: function(e) {
                            var t = this;
                            this.$walk(function(n) {
                                var r = t.generateLog(e);
                                n.send({
                                    url: n.config.setDataReportUrl + "?payload=" + encodeURIComponent(JSON.stringify({
                                        miniProgramData: r
                                    })),
                                    type: C.LOAD_PACKAGE,
                                    log: r
                                });
                            });
                        }
                    }), G.use(te), G.use(Ee), G.use(ee), G.use(xe), G.use(Ne), G.use(K), G.use(Y), G;
                }();
            }
        }, i = {};
        function o(e) {
            var t = i[e];
            if (void 0 !== t) return t.exports;
            var n = i[e] = {
                exports: {}
            };
            return r[e].call(n.exports, n, n.exports, o), n.exports;
        }
        o.n = function(e) {
            var t = e && e.__esModule ? function() {
                return e.default;
            } : function() {
                return e;
            };
            return o.d(t, {
                a: t
            }), t;
        }, o.d = function(e, t) {
            for (var n in t) o.o(t, n) && !o.o(e, n) && Object.defineProperty(e, n, {
                enumerable: !0,
                get: t[n]
            });
        }, o.o = function(e, t) {
            return Object.prototype.hasOwnProperty.call(e, t);
        };
        var a = {};
        return function() {
            o.d(a, {
                default: function() {
                    return d;
                }
            });
            var r = wx.getRealtimeLogManager ? wx.getRealtimeLogManager() : null, i = function() {
                for (var e = arguments.length, t = new Array(e), n = 0; n < e; n++) t[n] = arguments[n];
                r && r.warn(t);
            }, s = function(e) {
                r && r.error(e);
            }, l = o(143), c = o.n(l);
            console.log("AegisClient.js loaded start");
            var u = new (function() {
                function n() {
                    if (e(this, n), this.aegis = void 0, n.prototype.instance) return n.prototype.instance;
                    this.init(), n.prototype.instance = this;
                }
                return t(n, [ {
                    key: "init",
                    value: function() {
                        var e = "release" !== function() {
                            var e = "release";
                            return wx && "undefined" != typeof wx && (e = wx.getAccountInfoSync().miniProgram.envVersion), 
                            e;
                        }() ? "ebsNQtbXJocPiFknTZ" : "ebsNQtbXQSFfIUXBAp";
                        this.aegis = new (c())({
                            id: e,
                            api: {
                                apiDetail: !0,
                                reqParamHandler: function(e) {
                                    return d.deepEncrypt(e);
                                }
                            },
                            reportApiSpeed: !0,
                            beforeRequest: function(e) {
                                if ("log" === e.logType && (e.logs.msg.includes("otheve.beacon.qq.com") || e.logs.msg.includes("reporttest.calendar.tencent.com") || e.logs.msg.includes("report.calendar.tencent.com"))) return !1;
                            }
                        });
                    }
                }, {
                    key: "setUid",
                    value: function(e) {
                        this.aegis.setConfig({
                            uin: e
                        });
                    }
                }, {
                    key: "setExt1",
                    value: function(e) {
                        this.aegis.setConfig({
                            ext1: e
                        });
                    }
                }, {
                    key: "setExt2",
                    value: function(e) {
                        this.aegis.setConfig({
                            ext2: e
                        });
                    }
                }, {
                    key: "setExt3",
                    value: function(e) {
                        this.aegis.setConfig({
                            ext3: e
                        });
                    }
                }, {
                    key: "setVersion",
                    value: function(e) {
                        this.aegis.setConfig({
                            version: e
                        });
                    }
                }, {
                    key: "infoAll",
                    value: function(e) {
                        if (e) try {
                            this.aegis.infoAll("info >>  ".concat(e));
                        } catch (t) {
                            console.e("aegis error! msg is ".concat(e, ", error: ").concat(JSON.stringify(t)));
                        } else console.error("aegis infoAll with empty msg");
                    }
                }, {
                    key: "warnAll",
                    value: function(e) {
                        if (e) try {
                            this.aegis.infoAll("warn >> ".concat(e));
                        } catch (t) {
                            console.e("aegis error! msg is ".concat(e, ", error: ").concat(JSON.stringify(t)));
                        } else console.error("aegis warnAll with empty msg");
                    }
                }, {
                    key: "info",
                    value: function(e) {
                        if (e) try {
                            this.aegis.info("info >> ".concat(e));
                        } catch (t) {
                            console.e("aegis error! msg is ".concat(e, ", error: ").concat(JSON.stringify(t)));
                        } else console.error("aegis info with empty msg");
                    }
                }, {
                    key: "warn",
                    value: function(e) {
                        if (e) try {
                            this.aegis.info("warn >> ".concat(e));
                        } catch (t) {
                            console.e("aegis error! msg is ".concat(e, ", error: ").concat(JSON.stringify(t)));
                        } else console.error("aegis warn with empty msg");
                    }
                }, {
                    key: "error",
                    value: function(e) {
                        if (e) try {
                            this.aegis.report(new Error(e));
                        } catch (t) {
                            console.e("aegis error! msg is ".concat(e, ", error: ").concat(JSON.stringify(t)));
                        } else console.error("aegis report with empty msg");
                    }
                } ]), n;
            }())();
            console.log("AegisClient.js loaded end");
            var f = o(522), p = o.n(f), d = new (function() {
                function r() {
                    var t = this;
                    if (e(this, r), this.deepEncrypt = function(e) {
                        var r = !1;
                        try {
                            e && ("string" == typeof e && (e = JSON.parse(e), r = !0), Object.keys(e).forEach(function(r) {
                                if ("object" == n(e[r])) return t.deepEncrypt(e[r]);
                                e[r] = t.encryptValue(r, e[r]);
                            })), r && (e = JSON.stringify(e));
                        } catch (e) {}
                        return e;
                    }, r.prototype.instance) return r.prototype.instance;
                    this.wxLogEnable = !0, this.tamLogEnable = !0, this.platformType = "wx", this.aegisSdk = u, 
                    r.prototype.instance = this;
                }
                return t(r, [ {
                    key: "setConfig",
                    value: function() {
                        var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {}, t = e.openId, n = e.nickName, r = e.userId, i = e.wxLogEnable, o = void 0 === i || i, a = e.tamLogEnable, s = void 0 === a || a, l = e.platformType, c = void 0 === l ? "wx" : l, f = e.isDevelop, p = void 0 !== f && f, d = e.version;
                        t && u.setUid(t), n && u.setExt1(n), r && u.setExt2(r), d && u.setVersion(d), o && (this.wxLogEnable = o), 
                        s && (this.tamLogEnable = s), c && (this.platformType = c), p && (this.isDevelop = p);
                    }
                }, {
                    key: "info",
                    value: function(e, t) {
                        if (!this.isDevelop) {
                            console.log("not develop, use info.");
                            var n = this.getMsgStr(e, t);
                            this.tamLogEnable && u.info(n);
                        }
                    }
                }, {
                    key: "warn",
                    value: function(e, t) {
                        if (!this.isDevelop) {
                            console.log("not develop, use warn.");
                            var n = this.getMsgStr(e, t);
                            console.warn(n), this.wxLogEnable && i(n), this.tamLogEnable && u.warn(n);
                        }
                    }
                }, {
                    key: "infoAll",
                    value: function(e, t) {
                        var n = this.getMsgStr(e, t);
                        this.tamLogEnable && u.infoAll(n);
                    }
                }, {
                    key: "warnAll",
                    value: function(e, t) {
                        var n = this.getMsgStr(e, t);
                        console.warn(n), this.wxLogEnable && i(n), this.tamLogEnable && u.warnAll(n);
                    }
                }, {
                    key: "error",
                    value: function(e, t) {
                        var n = this.getMsgStr(e, t);
                        console.error(n), this.wxLogEnable && s(n), this.tamLogEnable && u.error(n);
                    }
                }, {
                    key: "getMsgStr",
                    value: function() {
                        var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : "", t = arguments.length > 1 ? arguments[1] : void 0, n = "string" == typeof e ? e : JSON.stringify(e);
                        n && n.length > 5e3 && (n = n.substring(0, 5e3));
                        try {
                            n = this.encryptLog(n);
                        } catch (e) {
                            console.error(e);
                        }
                        return "[".concat(this.platformType, "] ").concat("string" == typeof t ? "[".concat(t, "]") : "", " ").concat(n);
                    }
                }, {
                    key: "encryptLog",
                    value: function(e) {
                        for (var t, n = e, r = RegExp(/"(meeting_subject|meetingSubject|title|subject|summary|creator|loc|creatorNickName|nickName|nick_name|corpName|desc|calName)":"(\S*?)"/g), i = []; null !== (t = r.exec(n)); ) i.push(t[2]);
                        return i.forEach(function(e) {
                            e && (n = n.replace(new RegExp(e.replace(/[.*+?^${}()|[\]\\]/g, "\\$&"), "g"), p()(e)));
                        }), n;
                    }
                }, {
                    key: "encryptValue",
                    value: function(e, t) {
                        return [ "meeting_subject", "meetingSubject", "title", "subject", "summary", "creator", "loc", "creatorNickName", "nickName", "nick_name", "corpName", "desc", "calName" ].includes(e) && (t = p()(t)), 
                        t;
                    }
                }, {
                    key: "getMd5",
                    value: function(e) {
                        return p()(e);
                    }
                } ]), r;
            }())();
        }(), a.default;
    }();
});