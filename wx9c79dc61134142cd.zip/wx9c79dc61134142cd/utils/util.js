require("../@babel/runtime/helpers/Objectvalues"), require("../@babel/runtime/helpers/Arrayincludes");

var t = require("../sdk/logger/calendar_logger"), e = require("../configs/AppConfig"), n = require("../utils/beacon/report_data"), o = require("../constants/Calendar").CalendarType, c = e.DEFAULT_ENV_KEY;

var a = function(t) {
    var e = t.split(";"), n = new Map();
    return e.forEach(function(t) {
        var e = t.split("=");
        n.set(e[0], e[1]);
    }), n;
}, r = function(t) {
    return (t = t.toString())[1] ? t : "0".concat(t);
};

function i(t, e) {
    if ("string" != typeof t) throw new Error("version1 should be type of string: ".concat(t));
    if ("string" != typeof e) throw new Error("version2 should be type of string: ".concat(e));
    for (var n = t.split("."), o = e.split("."), c = n.length, a = o.length, r = 0; r < c && r < a; r++) {
        var i = parseInt(n[r], 10);
        if (isNaN(i) || i < 0) throw new Error("invalid version1: ".concat(n));
        var u = parseInt(o[r], 10);
        if (isNaN(u) || u < 0) throw new Error("invalid version2: ".concat(o));
        if (i < u) return -1;
        if (i > u) return 1;
    }
    if (c === a) return 0;
    if (c > a) {
        for (var s = a; s < c; s++) if ("0" !== n[s]) return 1;
        return 0;
    }
    for (var l = c; l < a; l++) if ("0" !== o[l]) return -1;
    return 0;
}

function u() {
    var t = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {}, e = "";
    return Object.keys(t).forEach(function(n) {
        e += e ? "&" : "?", e += "".concat(n, "=").concat(t[n]);
    }), e;
}

var s = {
    info: function(t) {
        console.log("%c%s", "background-color: #006fff; color: white;", t);
    },
    warn: function(t) {
        console.log("%c%s", "background-color: orange; color: white;", t);
    },
    error: function(t) {
        console.log("%c%s", "background-color: red; color: white;", t);
    }
};

function l(t) {
    return t < 10 ? "0".concat(t) : "".concat(t);
}

function f(t, e, n, o, c, a, r, i) {
    if (t.getFullYear() !== e.getFullYear()) return "".concat(t.getFullYear()).concat(r).concat(n, " ").concat(c) + " 至 ".concat(e.getFullYear()).concat(r).concat(o, " ").concat(a);
    if (i.getFullYear() === t.getFullYear()) {
        var u = new Date(i.getTime() + 864e5);
        return t.getMonth() === i.getMonth() && t.getDate() === i.getDate() && e.getMonth() === u.getMonth() && e.getDate() === u.getDate() ? "今天 ".concat(c, " 至 明天 ").concat(a) : "".concat(n, " ").concat(c, " 至 ").concat(o, " ").concat(a);
    }
    return "".concat(t.getFullYear()).concat(r).concat(n, " ").concat(c, " 至 ").concat(o, " ").concat(a);
}

function g(t, e, n) {
    if (t) return " (".concat(e, ")");
    var o = n ? "" : " ";
    return " ".concat(e).concat(o);
}

function d(t, e, n) {
    if (!e) return "";
    var o = n ? "" : " ";
    return t.getHours() <= 12 ? " 上午".concat(o) : " 下午".concat(o);
}

function h(t, e, n, o, c, a, r, i, u) {
    t.getMonth() === e.getMonth() && t.getDate() === e.getDate() && (n = "今天");
    var s = new Date(t.getTime() + 864e5);
    s.getMonth() === e.getMonth() && s.getDate() === e.getDate() && (n = "明天");
    var l = g(u, n, o), f = d(e, u, o);
    if (t.getFullYear() === e.getFullYear()) return !0 === o ? "".concat(i).concat(l) : "".concat(i).concat(l).concat(f).concat(c, "-").concat(a);
    var h = u ? "" : e.getFullYear() + r;
    return !0 === o ? "".concat(h).concat(i).concat(l) : "".concat(h).concat(i).concat(l).concat(f).concat(c, "-").concat(a);
}

function p() {
    var t = wx.getSystemInfoSync(), e = t.model.toLowerCase(), n = t.platform.toLowerCase();
    return e.includes("mac") || n.includes("macos");
}

module.exports = {
    formatTime: function(t) {
        var e = t.getFullYear(), n = t.getMonth() + 1, o = t.getDate(), c = t.getHours(), a = t.getMinutes(), i = t.getSeconds();
        return "".concat([ e, n, o ].map(r).join("/"), " ").concat([ c, a, i ].map(r).join(":"));
    },
    formatDate: function(t, e) {
        var n = [ "YYYY", "mm", "dd", "HH", "MM", "SS" ], o = [];
        for (var c in o.push(e.getFullYear()), o.push(r(e.getMonth() + 1)), o.push(r(e.getDate())), 
        o.push(r(e.getHours())), o.push(r(e.getMinutes())), o.push(r(e.getSeconds())), o) t = t.replace(n[c], o[c]);
        return t;
    },
    mirror: function() {
        var t = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {}, e = {};
        return Object.keys(t).forEach(function(n) {
            Object.prototype.hasOwnProperty.call(t, n) && (e[n] = n);
        }), e;
    },
    getValueFromLocalStorage: function(e) {
        var n = null;
        try {
            n = wx.getStorageSync("".concat(c, "_").concat(e));
        } catch (o) {
            n = null, t.error("unable to get cached data for key = ".concat(e, " from local storage becasue: ").concat(JSON.stringify(o)));
        }
        return n;
    },
    setValueInLocalStorage: function(e, n) {
        wx.setStorage({
            key: "".concat(c, "_").concat(e),
            data: n,
            success: function() {
                "string" == typeof n || t.info("set ".concat(e, "=").concat(JSON.stringify(n), " into localStorage succeed"));
            },
            fail: function(o) {
                t.error("set to local storage failed. key=".concat(e, ", value=").concat(n, ". error=").concat(JSON.stringify(o)));
            }
        });
    },
    isTimeout: function() {
        var t = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : "";
        if ("string" != typeof t) return !1;
        var e = -1 < t.indexOf("timeout") || -1 < t.indexOf("请求超时") || -1 < t.indexOf("timed out") || -1 < t.indexOf("time out");
        return e;
    },
    isVersion: function(t) {
        return "string" == typeof t && /^(0|[1-9]\d*)\.((0|[1-9]\d*)\.)*(0|[1-9]\d*)$/.test(t);
    },
    toNotSensePhoneNum: function(t) {
        return t.replace(/(\d{3})\d*(\d{4})/, "$1****$2");
    },
    argbTorgba: function(t) {
        return 9 != t.length ? t : t.replace(/#(..)(......)/, "#$2$1");
    },
    formatRgba: function(t) {
        if (t && 9 === t.length) {
            var e = "CC" === t.toUpperCase().slice(8, 9) ? .8 : 1;
            return "rgba(".concat(parseInt("0x".concat(t.slice(1, 3))), ",").concat(parseInt("0x".concat(t.slice(3, 5))), ",").concat(parseInt("0x".concat(t.slice(5, 7))), ",").concat(e, ")");
        }
        return t;
    },
    splitColor: a,
    navigateToH5: function(e, n) {
        var o = u(Object.assign({
            url: encodeURIComponent(e)
        }, n)), c = "/pages/sub-web/web/web".concat(o);
        t.info("wxUrl is ".concat(c), "util.js"), wx.navigateTo({
            url: c
        });
    },
    getTimeInfo: function(t, e, n) {
        var o = !(arguments.length > 3 && void 0 !== arguments[3]) || arguments[3], c = arguments.length > 4 && void 0 !== arguments[4] && arguments[4], a = o ? "/" : "年", r = o ? "/" : "月", i = new Date(), u = [ "周日", "周一", "周二", "周三", "周四", "周五", "周六" ], s = new Date(t), p = new Date(e), m = "".concat(s.getMonth() + 1).concat(r).concat(s.getDate()), v = "".concat(p.getMonth() + 1).concat(r).concat(p.getDate()), w = u[s.getDay()], b = n ? "" : "".concat(l(s.getHours()), ":").concat(l(s.getMinutes())), S = n ? "" : "".concat(l(p.getHours()), ":").concat(l(p.getMinutes()));
        if (s.getFullYear() !== p.getFullYear()) return "".concat(s.getFullYear()).concat(a).concat(m, " ").concat(b) + "- ".concat(p.getFullYear()).concat(a).concat(v, " ").concat(S);
        if (s.getMonth() === p.getMonth() && s.getDate() === p.getDate()) {
            if (i.getFullYear() !== s.getFullYear()) {
                var y = g(c, w, n), _ = d(s, c, n), x = c ? "" : s.getFullYear() + a;
                return !0 === n ? "".concat(x).concat(m).concat(y) : "".concat(x).concat(m).concat(y).concat(_).concat(b, "-").concat(S);
            }
            return h(i, s, w, n, b, S, a, m, c);
        }
        return f(s, p, m, v, b, S, a, i);
    },
    submitSubscribe: function() {
        var t = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : "home";
        return new Promise(function(o, c) {
            wx.getSetting({
                withSubscriptions: !0,
                success: function(a) {
                    if (console.log("submitSubscribe:", a), a.subscriptionsSetting.mainSwitch) if (void 0 !== a.subscriptionsSetting.itemSettings) {
                        "home" == t && n.dataReport("e#schedule_create#notification_authorization#explore", {
                            checkeddefault: 1
                        }), "invite" == t && n.dataReport("e#invitation_share#confirm_subscription_notification#explore", {});
                        var r = a.subscriptionsSetting.itemSettings[e.EventRemindPushTemplId];
                        "accept" === r ? ("home" == t && n.dataReport("e#main#notification_authorization_allow#click", {
                            checkeddefault: 1
                        }), "invite" == t && n.dataReport("e#invitation_share#confirm_subscription_notification_allow#click", {
                            remember: 0
                        })) : "home" == t && n.dataReport("e#main#notification_authorization_cancel#click", {
                            checkeddefault: 1
                        }), o(r);
                    } else {
                        if (p()) return;
                        wx.requestSubscribeMessage({
                            tmplIds: [ e.EventRemindPushTemplId ],
                            success: function(c) {
                                "home" == t && n.dataReport("e#schedule_create#notification_authorization#explore", {
                                    checkeddefault: 0
                                }), "invite" == t && n.dataReport("e#invitation_share#confirm_subscription_notification#explore", {}), 
                                console.log(c);
                                var a = c[e.EventRemindPushTemplId];
                                "accept" === a ? ("home" == t && n.dataReport("e#main#notification_authorization_allow#click", {
                                    checkeddefault: 0
                                }), "invite" == t && n.dataReport("e#invitation_share#confirm_subscription_notification_allow#click", {
                                    remember: 1
                                })) : "home" == t && n.dataReport("e#main#notification_authorization_cancel#click", {
                                    checkeddefault: 0
                                }), o(a);
                            },
                            fail: function(t) {
                                console.log("订阅消息 失败:", t), c();
                            }
                        });
                    } else "home" == t && n.dataReport("e#schedule_create#notification_authorization_close#click", {}), 
                    console.log("订阅消息未开启"), c();
                },
                fail: function(t) {
                    console.log("testSubscripe->", t), c();
                }
            });
        });
    },
    compareVersion: i,
    isTimeAfterNow: function(t) {
        return t >= new Date().getTime();
    },
    isSupportQYWX: function(t) {
        return i(t, "3.0.10") >= 0;
    },
    getQueryString: u,
    clog: s,
    isIPhone: function() {
        var t = wx.getSystemInfoSync(), e = t.platform.toLowerCase(), n = t.model.toLowerCase();
        return e.includes("ios") || n.includes("iphone");
    },
    isMac: p,
    isWin: function() {
        var t = wx.getSystemInfoSync(), e = t.system.toLowerCase(), n = t.platform.toLowerCase();
        return e.includes("windows") || n.includes("windows");
    },
    getObjFromLocalStorage: function(t, e) {
        var n = wx.getStorageSync(t);
        try {
            return "string" == typeof n ? JSON.parse(n) : n || e;
        } catch (t) {
            return e;
        }
    },
    rpx2Px: function(t, e) {
        return t / (750 / e);
    },
    isPC: function() {
        var t = wx.getSystemInfoSync().system.toLowerCase();
        return !(t.includes("ios") || t.includes("android"));
    },
    initRecurMenuItems: [ {
        text: "仅当前日程",
        containFuture: 1
    }, {
        text: "将来的所有日程",
        containFuture: 2
    }, {
        text: "全部日程",
        containFuture: 3
    } ],
    initMeetingRecurMenuItems: [ {
        text: "修改该系列周期性会议",
        containFuture: 3
    }, {
        text: "仅修改本次",
        containFuture: 1
    } ],
    initMeetingRecurMenuDeleteItems: [ {
        text: "删除该系列周期性会议",
        containFuture: 3
    }, {
        text: "仅删除本次",
        containFuture: 1
    } ],
    initRecurEndItems: [ {
        text: "永不结束",
        type: 0,
        selected: !1
    }, {
        text: "按日期",
        type: 1,
        selected: !1
    }, {
        text: "按次数",
        type: 2,
        selected: !1
    } ],
    formatSubscribers: function(t) {
        var e = "", n = t.total_num, o = t.user_infos.map(function(t) {
            return t.nickname;
        });
        return n > 0 && n <= 3 ? e = "共享给：".concat(o.join("、")) : n > 3 && (e = "共享给：".concat(o.join("、"), "等共").concat(t.total_num, "人")), 
        e;
    },
    formatDuration: function() {
        var t = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : 0;
        t = Number(t);
        var e = Math.floor(t / 60), n = Math.floor(t % 60), o = "";
        return e > 0 && (o = "".concat(e, "小时")), n > 0 && (o = "".concat(o).concat(n, "分钟")), 
        o;
    },
    roleList: [ {
        name: "编辑者",
        desc: "可创建、修改日程",
        isSelect: !1,
        disable: !1,
        id: 0
    }, {
        name: "查看者",
        desc: "可查看、分享日程",
        isSelect: !0,
        disable: !1,
        id: 1
    } ],
    accessList: [ {
        name: "仅看忙闲",
        isSelect: !1,
        disable: !1,
        id: 0
    }, {
        name: "可分享",
        isSelect: !0,
        disable: !1,
        id: 1
    } ],
    formatDescription: function() {
        var t = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : "", e = t.split(/\n/), n = /(http(s)?:\/\/)\w+[^\s]+(\.[^\s]+)(tencentmeeting.com)/, o = /(http(s)?:\/\/)meeting.tencent.com/, c = /(http(s)?:\/\/)work.weixin.qq.com/, a = [];
        return e && e.length > 0 && e.forEach(function(t) {
            var e = {};
            if (o.test(t) || c.test(t) || n.test(t)) {
                var r = t.substring(t.indexOf("http"), t.length);
                e.value = t.replace(r, ""), e.url = r;
            } else e.value = t;
            a.push(e);
        }), a;
    },
    parseColors: function() {
        var t = wx.getStorageSync("view_config"), e = t && t["calendar.shared.custom.color"] || "";
        return a(e);
    },
    initGroupCalendarList: function(t) {
        var e = [ {
            key: "日历",
            accountCalList: []
        }, {
            key: "订阅日历",
            accountCalList: []
        } ];
        return Object.values(t).forEach(function(t) {
            t.accountCalList.forEach(function(t) {
                t.calType === o.SHARED ? e[1].accountCalList.push(t) : e[0].accountCalList.push(t);
            });
        }), e.forEach(function(t) {
            "订阅日历" === t.key && t.accountCalList.sort(function(t, e) {
                return t.calendarId - e.calendarId;
            });
        }), console.log("init groupedCalendarList", e), e;
    },
    formatNickName: function() {
        for (var t = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : "", e = arguments.length > 1 ? arguments[1] : void 0, n = 0, o = 0; o < t.length; o++) /[\u4e00-\u9fa5]/.test(t.charAt(o)) && n++, 
        n++;
        return n < e ? t : t.substring(0, e / 2 - 2) + "...";
    }
};