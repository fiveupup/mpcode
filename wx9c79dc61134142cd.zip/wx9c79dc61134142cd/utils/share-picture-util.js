var e = require("../@babel/runtime/helpers/regeneratorRuntime"), t = require("../@babel/runtime/helpers/asyncToGenerator"), n = require("../sdk/logger/calendar_logger"), r = getApp(), a = "https://cdn.calendar.tencent.com/calendar_res/mpCalendar/canvas";

function c(e) {
    return new Promise(function(t) {
        wx.canvasToTempFilePath({
            canvas: e,
            success: function(e) {
                t(e);
            },
            fail: function(e) {
                console.log("canvasToTempFilePath err=>", e), n.info("canvasToTempFilePath err ".concat(e), "share-picture-util.js"), 
                t({
                    tempFilePath: {
                        tempFilePath: ""
                    }
                });
            }
        });
    });
}

function s() {
    return (s = t(e().mark(function n(s, i, o, u, l) {
        return e().wrap(function(n) {
            for (;;) switch (n.prev = n.next) {
              case 0:
                return n.abrupt("return", new Promise(function() {
                    var n = t(e().mark(function t(n) {
                        var g, m, f, d, p, h, x, b, w, k, T, P, v, I, F, _, y, S, C, q, A, E, R, j, D, G, M;
                        return e().wrap(function(e) {
                            for (;;) switch (e.prev = e.next) {
                              case 0:
                                return g = s.getContext("2d"), m = r.globalData.sysInfo.pixelRatio, s.width = s._width * m, 
                                s.height = s._height * m, console.log("dpr:", m), g.scale(m, m), (f = s.createImage()).src = o, 
                                e.next = 10, new Promise(function(e) {
                                    f.onload = function() {
                                        e(f);
                                    };
                                });

                              case 10:
                                if (d = e.sent, g.drawImage(d, 0, 0, d.width, d.height, 0, 0, 420, 336), g.save(), 
                                g.textAlign = "left", g.fillStyle = "#1E2126", g.font = "normal bold ".concat(32, "px PingFangSC-Medium"), 
                                p = "...", h = g.measureText(p).width, x = -1, b = 372, w = 22, k = 64, T = 104, 
                                P = g.measureText(i).width, v = 0, I = 0, l && (P += 48, P += 8), !(P <= b)) {
                                    e.next = 32;
                                    break;
                                }
                                g.fillText(i, w, k), v = g.measureText(i).width + w + 8, e.next = 69;
                                break;

                              case 32:
                                I = 1, F = 0;

                              case 34:
                                if (!(F < i.length)) {
                                    e.next = 42;
                                    break;
                                }
                                if (!(g.measureText(i.substring(0, F + 1)).width > b || F === i.length - 1)) {
                                    e.next = 39;
                                    break;
                                }
                                return g.fillText(i.substring(0, F), w, k), x = F, e.abrupt("break", 42);

                              case 39:
                                F++, e.next = 34;
                                break;

                              case 42:
                                if (!(x > 0)) {
                                    e.next = 69;
                                    break;
                                }
                                _ = !1, y = x;

                              case 45:
                                if (!(y < i.length)) {
                                    e.next = 68;
                                    break;
                                }
                                if (S = g.measureText(i.substring(x, y + 1)).width, v = (S += l ? 56 : 0) - 8 - 20, 
                                !(S > b)) {
                                    e.next = 65;
                                    break;
                                }

                              case 50:
                                if (!(y > 0)) {
                                    e.next = 64;
                                    break;
                                }
                                if (y -= 1, S = g.measureText(i.substring(x, y + 1)).width, !((S += l ? 56 : 0) + h > b)) {
                                    e.next = 58;
                                    break;
                                }
                                return e.abrupt("continue", 50);

                              case 58:
                                return console.log(i.substring(x, y + 1) + p), g.fillText(i.substring(x, y + 1) + p, w, T), 
                                _ = !0, e.abrupt("break", 64);

                              case 62:
                                e.next = 50;
                                break;

                              case 64:
                                return e.abrupt("break", 68);

                              case 65:
                                y++, e.next = 45;
                                break;

                              case 68:
                                _ || g.fillText(i.substring(x), w, T);

                              case 69:
                                return (C = s.createImage()).src = "".concat(a, "/meeting_bg.png"), e.next = 73, 
                                new Promise(function(e) {
                                    C.onload = function() {
                                        e(C);
                                    };
                                });

                              case 73:
                                return q = e.sent, g.drawImage(q, 22, 116, 376, 226), g.font = "normal ".concat(24, "px PingFangSC"), 
                                (A = s.createImage()).src = "".concat(a, "/meeting_unchecked.png"), e.next = 80, 
                                new Promise(function(e) {
                                    A.onload = function() {
                                        e(A);
                                    };
                                });

                              case 80:
                                if (E = e.sent, !l) {
                                    e.next = 88;
                                    break;
                                }
                                return (R = s.createImage()).src = "https://cdn.calendar.tencent.com/calendar_res/mpCalendar/canvas/meetingIcon-new.png", 
                                e.next = 86, new Promise(function(e) {
                                    R.onload = function() {
                                        e(R);
                                    };
                                });

                              case 86:
                                j = e.sent, g.drawImage(j, v, I ? 72 : 30, 48, 48);

                              case 88:
                                return 1 === u.length && (g.drawImage(E, 54, 168, 24, 24), g.fillText(u[0], 102, 189)), 
                                2 === u.length && (u.forEach(function(e, t) {
                                    g.drawImage(E, 54, 144 + 33 * t * 2, 24, 24), g.fillText(e, 102, 165 + 33 * t * 2);
                                }), g.moveTo(102, 188), g.lineTo(398, 188), g.strokeStyle = "rgba(0, 20, 92, 0.08)", 
                                g.stroke()), (D = s.createImage()).src = "https://cdn.calendar.tencent.com/calendar_res/v2/vote_btn.png", 
                                e.next = 94, new Promise(function(e) {
                                    D.onload = function() {
                                        e(D);
                                    };
                                });

                              case 94:
                                return G = e.sent, g.drawImage(G, 54, 258, 312, 60), g.restore(), e.next = 99, c(s);

                              case 99:
                                M = e.sent, n({
                                    tempFilePath: {
                                        tempFilePath: M.tempFilePath
                                    }
                                });

                              case 101:
                              case "end":
                                return e.stop();
                            }
                        }, t);
                    }));
                    return function(e) {
                        return n.apply(this, arguments);
                    };
                }()));

              case 1:
              case "end":
                return n.stop();
            }
        }, n);
    }))).apply(this, arguments);
}

module.exports = {
    drawAndSavePicture: c,
    drawInviteShare: function(e, t, n, r, a) {
        return s.apply(this, arguments);
    }
};