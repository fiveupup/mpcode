var i = require("../@babel/runtime/helpers/classCallCheck"), s = require("../@babel/runtime/helpers/createClass"), t = new (function() {
    function t() {
        if (i(this, t), this.callbacks = {}, this.isDispatching = {}, this.isHandled = {}, 
        this.isPending = {}, this.lastID = 1, t.instance) return t.instance;
        t.instance = this, this.init();
    }
    return s(t, [ {
        key: "init",
        value: function() {
            this.callbacks = {}, this.isDispatching = !1, this.isHandled = {}, this.isPending = {}, 
            this.lastID = 1;
        }
    }, {
        key: "register",
        value: function(i) {
            this.lastID += 1;
            var s = "ID_" + this.lastID;
            return this.callbacks[s] = i, s;
        }
    }, {
        key: "unregister",
        value: function(i) {
            delete this.callbacks[i];
        }
    }, {
        key: "dispatch",
        value: function(i) {
            this.startDispatching(i);
            try {
                for (var s = Object.keys(this.callbacks), t = s.length, e = 0; e < t; e++) {
                    var a = s[e];
                    this.isPending[a] || this.invokeCallback(a);
                }
            } finally {
                this.stopDispatching();
            }
        }
    }, {
        key: "startDispatching",
        value: function(i) {
            for (var s = Object.keys(this.callbacks), t = s.length, e = 0; e < t; e++) {
                var a = s[e];
                this.isPending[a] = !1, this.isHandled[a] = !1;
            }
            this.pendingPayload = i, this.isDispatching = !0;
        }
    }, {
        key: "stopDispatching",
        value: function() {
            delete this.pendingPayload, this.isDispatching = !1;
        }
    }, {
        key: "invokeCallback",
        value: function(i) {
            this.isPending[i] = !0, this.callbacks[i](this.pendingPayload), this.isHandled[i] = !0;
        }
    } ]), t;
}())();

module.exports = t;