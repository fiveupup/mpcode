var n = require("../@babel/runtime/helpers/classCallCheck"), e = require("../@babel/runtime/helpers/createClass"), t = function() {
    function t() {
        n(this, t), this.mChannels = {};
    }
    return e(t, [ {
        key: "subscribe",
        value: function(n, e, t) {
            n && "string" == typeof n && "function" == typeof e && (this.mChannels[n] || (this.mChannels[n] = []), 
            t && (e.context = t), this.mChannels[n].push(e));
        }
    }, {
        key: "unsubscribe",
        value: function(n, e) {
            if (n && "string" == typeof n && "function" == typeof e && this.mChannels[n]) {
                var t = this.mChannels[n] || [], s = t.findIndex(function(n) {
                    return n === e;
                });
                s >= 0 && t.splice(s, 1);
            }
        }
    }, {
        key: "publish",
        value: function(n) {
            for (var e = arguments.length, t = new Array(e > 1 ? e - 1 : 0), s = 1; s < e; s++) t[s - 1] = arguments[s];
            if (n && "string" == typeof n) {
                var i = this.mChannels[n] || [];
                i.forEach(function(n) {
                    n.call.apply(n, [ n.context || null ].concat(t));
                });
            }
        }
    } ]), t;
}();

module.exports = t;