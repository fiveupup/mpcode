var e = require("../../@babel/runtime/helpers/objectSpread2"), r = require("@tencent/wecalendar_web_base_report"), t = require("../../clients/BeaconClient"), n = require("../../configs/AppConfig").wxVersion, o = require("../../sdk/logger/calendar_logger"), a = "release" === n;

r.setGetCommonParams(function() {
    return e(e({}, t.commParams), {}, {
        unique_report_id: t.getGuid()
    });
}), r.setTest(!a), r.registerOnError(function(e, r) {
    if (e && r) {
        var t = r.map(function(e) {
            return e.event_value.unique_report_id;
        }).join(",");
        console.error("data-report failed", e, t), o.infoAll("data-report failed ".concat(e.errMsg || e.message || JSON.stringify(e), ": ").concat(t));
    }
}), module.exports = {
    dataReport: function(e, t) {
        r.dataReport(e, t, !1);
    }
};