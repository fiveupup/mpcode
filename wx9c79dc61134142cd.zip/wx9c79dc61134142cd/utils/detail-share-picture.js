var e = require("../@babel/runtime/helpers/regeneratorRuntime"), t = require("../@babel/runtime/helpers/asyncToGenerator"), n = getApp(), r = 206, a = 236, i = "https://cdn.calendar.tencent.com/calendar_res/mpCalendar/canvas", s = require("./share-picture-util").drawAndSavePicture, c = function(e, t) {
    var n = t;
    if (function(e, t) {
        return e.measureText(t).width > 368;
    }(e, t)) {
        for (var r, a = e.measureText("...").width, i = 0; i < t.length; i++) if (e.measureText(t.substring(0, i + 1)).width + a > 368) {
            r = i;
            break;
        }
        n = t.substring(0, r) + "...";
    }
    return n;
}, u = function() {
    var n = t(e().mark(function t(n, r, a, s, c, u) {
        var o, l, f, x, d, h, p, m, b;
        return e().wrap(function(e) {
            for (;;) switch (e.prev = e.next) {
              case 0:
                o = r.measureText("...").width, l = -1, f = 0, x = 0;

              case 4:
                if (!(x < a.length)) {
                    e.next = 12;
                    break;
                }
                if (!(r.measureText(a.substring(0, x + 1)).width > 368)) {
                    e.next = 9;
                    break;
                }
                return r.fillText(a.substring(0, x), 26, c), l = x, e.abrupt("break", 12);

              case 9:
                x++, e.next = 4;
                break;

              case 12:
                if (!(l > 0)) {
                    e.next = 38;
                    break;
                }
                d = !1, h = s ? 48 : 0, p = l;

              case 16:
                if (!(p < a.length)) {
                    e.next = 35;
                    break;
                }
                if (!(r.measureText(a.substring(l, p)).width + h > 368)) {
                    e.next = 32;
                    break;
                }

              case 18:
                if (!(p > 0)) {
                    e.next = 30;
                    break;
                }
                if (p -= 1, !(r.measureText(a.substring(l, p + 1)).width + o + h > 368)) {
                    e.next = 24;
                    break;
                }
                return e.abrupt("continue", 18);

              case 24:
                return r.fillText(a.substring(l, p + 1) + "...", 26, u), d = !0, f = r.measureText(a.substring(l, p + 1)).width + o + 26 + 8, 
                e.abrupt("break", 30);

              case 28:
                e.next = 18;
                break;

              case 30:
                return e.abrupt("break", 35);

              case 32:
                p++, e.next = 16;
                break;

              case 35:
                d || (r.fillText(a.substring(l), 26, u), f = r.measureText(a.substring(l)).width + 26 + 8), 
                e.next = 40;
                break;

              case 38:
                r.fillText(a, 26, c), s && (f = 34);

              case 40:
                if (!s) {
                    e.next = 47;
                    break;
                }
                return (m = n.createImage()).src = "".concat(i, "/meetingIcon-new.png"), e.next = 45, 
                new Promise(function(e) {
                    m.onload = function() {
                        e(m);
                    };
                });

              case 45:
                b = e.sent, r.drawImage(b, f, 80, 40, 40);

              case 47:
              case "end":
                return e.stop();
            }
        }, t);
    }));
    return function(e, t, r, a, i, s) {
        return n.apply(this, arguments);
    };
}(), o = function() {
    var n = t(e().mark(function t(n, r, a, s, c, o) {
        var l, f, x, d;
        return e().wrap(function(e) {
            for (;;) switch (e.prev = e.next) {
              case 0:
                if (l = r.measureText(a).width, f = !0, s && (l += 40, l += 8), !(l <= 368)) {
                    e.next = 14;
                    break;
                }
                if (r.fillText(a, 26, c), !s) {
                    e.next = 12;
                    break;
                }
                return (x = n.createImage()).src = "".concat(i, "/meetingIcon-new.png"), e.next = 10, 
                new Promise(function(e) {
                    x.onload = function() {
                        e(x);
                    };
                });

              case 10:
                d = e.sent, r.drawImage(d, r.measureText(a).width + 26 + 8, 34, 40, 40);

              case 12:
                e.next = 17;
                break;

              case 14:
                return f = !1, e.next = 17, u(n, r, a, s, c, o);

              case 17:
                return e.abrupt("return", f);

              case 18:
              case "end":
                return e.stop();
            }
        }, t);
    }));
    return function(e, t, r, a, i, s) {
        return n.apply(this, arguments);
    };
}(), l = function() {
    var i = t(e().mark(function t(i, u) {
        var l, f, x, d, h, p, m, b, g, w, k, v;
        return e().wrap(function(e) {
            for (;;) switch (e.prev = e.next) {
              case 0:
                return "https://cdn.calendar.tencent.com/calendar_res/mpCalendar/canvas/detail-share-new.png", 
                l = i.title, f = i.hasMeeting, x = i.timeInfo, d = i.address, h = u.getContext("2d"), 
                (p = u.createImage()).src = "https://cdn.calendar.tencent.com/calendar_res/mpCalendar/canvas/detail-share-new.png", 
                e.next = 7, new Promise(function(e) {
                    p.onload = function() {
                        e(p);
                    };
                });

              case 7:
                return m = e.sent, b = n.globalData.sysInfo.pixelRatio, u.width = u._width * b, 
                u.height = u._height * b, console.log("dpr:", b), h.scale(b, b), h.drawImage(m, 0, 0, m.width, m.height, 0, 0, 420, 336), 
                h.save(), h.textAlign = "left", h.fillStyle = "#000000", h.font = "normal bold ".concat(36, "px PingFang SC"), 
                e.next = 20, o(u, h, l, f, 68, 112);

              case 20:
                return g = e.sent, w = 2 * (15 + (g ? 46 : 68)), h.textAlign = "left", h.fillStyle = "#000000", 
                h.font = "normal 400 ".concat(22, "px PingFang SC"), k = c(h, x), h.fillText(k, 26, w), 
                h.stroke(), g ? (r = 164, a = 194) : (r = 206, a = 236), e.next = 31, o(u, h, d, !1, r, a);

              case 31:
                return e.next = 33, s(u);

              case 33:
                if (v = e.sent) {
                    e.next = 36;
                    break;
                }
                return e.abrupt("return", Promise.reject());

              case 36:
                return e.abrupt("return", Promise.resolve({
                    tempFilePath: {
                        tempFilePath: v.tempFilePath
                    }
                }));

              case 37:
              case "end":
                return e.stop();
            }
        }, t);
    }));
    return function(e, t) {
        return i.apply(this, arguments);
    };
}();

module.exports = function(n, r) {
    var a = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : "mini";
    return r && "kbone" === a ? l(n, r) : new Promise(function(a, i) {
        wx.createSelectorQuery().select("#myCanvas").fields({
            node: !0,
            size: !0
        }).exec(function() {
            var s = t(e().mark(function t(s) {
                return e().wrap(function(e) {
                    for (;;) switch (e.prev = e.next) {
                      case 0:
                        (r = s[0].node)._width = s[0].width, r._height = s[0].height, l(n, r).then(function(e) {
                            a(e);
                        }).catch(function(e) {
                            i(e);
                        });

                      case 4:
                      case "end":
                        return e.stop();
                    }
                }, t);
            }));
            return function(e) {
                return s.apply(this, arguments);
            };
        }());
    });
};