var t = Math.ceil(178 / 9), e = Math.ceil(178 / 18);

module.exports = {
    renderWxml: function(n, i, a, r) {
        var c = a && a.length ? "https://cdn.calendar.tencent.com/calendar_res/subscribe_calendar_v2.png" : "https://cdn.calendar.tencent.com/calendar_res/subscribe_calendar_r.png";
        return '\n  <view class="card-wrap">\n    <image class="bg" src="'.concat(c, '">\n    </image>\n    <text class="title">').concat(function(n) {
            for (var i = n && n.length, a = 0, r = 0, c = 0; c < i; c++) if (n.charCodeAt(c) > 255 ? a += t : a += e, 
            a >= 356) {
                r = c;
                break;
            }
            return r ? "".concat(n.substring(0, r), "...") : n;
        }(n), '</text>\n    <text class="desc">').concat(i, '</text>\n    <view class="wrap">\n      <view class="container" wx:if="{{eventTitle}}">\n        <view class="icon"></view>\n        <text class="subtitle">').concat(a, '</text>\n      </view>\n      <text class="time" wx:if="{{eventTime}}">').concat(r, "</text>\n    </view>\n  </view>\n  ");
    },
    renderStyle: function(t, e) {
        return {
            cardWrap: {
                width: 210,
                height: 168,
                padding: 11
            },
            title: {
                fontFamily: "PingFang SC",
                fontSize: 18,
                fontWeight: 500,
                height: 18 * Math.min(Math.ceil(t && t.length / 9), 2) * 1.2,
                lineHeight: 20,
                width: 178,
                color: "rgba(30, 33, 38, 1)"
            },
            desc: {
                fontFamily: "PingFang SC",
                fontSize: 12,
                color: "rgba(133, 135, 138, 0.9)",
                width: 178,
                height: 18,
                fontWeight: 400,
                marginTop: 2
            },
            wrap: {
                width: 186,
                height: 60,
                position: "absolute",
                bottom: 20
            },
            container: {
                width: 178,
                height: 16,
                flexDirection: "row",
                justifyContent: "center",
                alignItems: "center"
            },
            icon: {
                width: 3,
                height: 10,
                backgroundColor: e && e.length ? "#F3A694" : "transparent",
                marginLeft: 8,
                borderRadius: 1,
                verticalAlign: "top"
            },
            subtitle: {
                fontFamily: "PingFang SC",
                width: 163,
                fontSize: 12,
                height: 12 * Math.min(Math.ceil(e && e.length / 6), 1) * 1.5,
                color: "rgba(30, 33, 38, 1)",
                fontWeight: 500,
                marginLeft: 4
            },
            time: {
                fontFamily: "PingFang SC",
                width: 163,
                height: 16,
                color: "rgba(79, 81, 86, 0.7)",
                fontSize: 9,
                fontWeight: 400,
                marginLeft: 15,
                marginTop: 4
            },
            bg: {
                width: 210,
                height: 168,
                position: "absolute",
                top: 0,
                left: 0
            }
        };
    }
};