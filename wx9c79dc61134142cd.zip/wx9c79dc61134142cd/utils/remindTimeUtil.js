var e = require("../@babel/runtime/helpers/objectSpread2");

require("../@babel/runtime/helpers/Arrayincludes");

var t = require("./Dayjs"), i = require("./util").getObjFromLocalStorage, n = function(e) {
    return Array.from(new Set(e));
}, a = {
    allDay: [ {
        text: "不提醒",
        value: "",
        isSelect: !1
    }, {
        text: "前一日晚10:00",
        value: 120,
        isSelect: !1
    }, {
        text: "当日00:00",
        value: 0,
        isSelect: !1
    }, {
        text: "当日早8:00",
        value: -480,
        isSelect: !1
    }, {
        text: "当日早10:00",
        value: -600,
        isSelect: !1
    } ],
    normal: [ {
        text: "不提醒",
        value: "",
        isSelect: !1
    }, {
        text: "开始时",
        value: 0,
        isSelect: !1
    }, {
        text: "前5分钟",
        value: 5,
        isSelect: !1
    }, {
        text: "前15分钟",
        value: 15,
        isSelect: !1
    }, {
        text: "前30分钟",
        value: 30,
        isSelect: !1
    }, {
        text: "前1小时",
        value: 60,
        isSelect: !1
    }, {
        text: "前2小时",
        value: 120,
        isSelect: !1
    }, {
        text: "前3小时",
        value: 180,
        isSelect: !1
    }, {
        text: "前6小时",
        value: 360,
        isSelect: !1
    }, {
        text: "前1天",
        value: 1440,
        isSelect: !1
    } ]
}, r = [ {
    text: "不提醒",
    value: "",
    isSelect: !1
}, {
    text: "结束前5分钟",
    value: 5,
    isSelect: !1
}, {
    text: "结束前10分钟",
    value: 10,
    isSelect: !1
}, {
    text: "结束前15分钟",
    value: 15,
    isSelect: !1
}, {
    text: "结束前30分钟",
    value: 30,
    isSelect: !1
}, {
    text: "结束前1小时",
    value: 60,
    isSelect: !1
}, {
    text: "结束前2小时",
    value: 120,
    isSelect: !1
} ], l = {}, c = {}, s = {};

a.allDay.forEach(function(e, t) {
    l[e.value] = t;
}), a.normal.forEach(function(e, t) {
    c[e.value] = t;
}), r.forEach(function(e, t) {
    s[e.value] = t;
});

var u = function(t) {
    var i = t.selectList, a = t.remindTimeList, r = t.isStartTimeRemind, u = t.isAllDay, o = [], f = c;
    if (u && (f = l), u || r || (f = s), 0 === i.length || i.includes("")) {
        var d = f[""], v = [].concat(a);
        return v[d].isSelect = !0, v;
    }
    var S = Object.keys(f), p = [].concat(S, i), x = (p = n(p)).indexOf("");
    return x > -1 && p.splice(x, 1), p = Array.from(p, function(e) {
        var t = Number(e);
        return isNaN(t) ? e : t;
    }), (p = n(p)).sort(function(e, t) {
        return e - t;
    }), p.unshift(""), p.forEach(function(t) {
        var n = !1, l = f[t];
        if (i.includes(t) && (n = !0), void 0 !== l) o.push(e(e({}, a[l]), {
            isSelect: n
        })); else {
            var c = u ? new Date().setHours(0, 0, 0, 0) : +new Date(), s = m(c, t, u, r);
            o.push({
                value: t,
                isSelect: n,
                text: s,
                customAttr: !0
            });
        }
    }), o;
}, m = function(e, i, n, a) {
    if (n) {
        var r = e - 60 * i * 1e3, l = new Date(r).setHours(0, 0, 0, 0), c = t(e).diff(t(l), "day"), s = t(r).format("H"), u = "";
        u = 0 === c % 7 ? "前".concat(c / 7, "周") : "前".concat(c, "天"), 0 === c && (u = "当日");
        var m = "".concat(u), o = "上午".concat(s);
        if (parseInt(s, 10) > 12) o = "下午".concat(s - 12);
        return m = "".concat(m).concat(o, ":").concat(t(r).format("mm"));
    }
    var f = parseInt(i / 60 / 24, 10), d = parseInt(i / 60 % 24, 10), v = parseInt(i % 60, 10);
    return 0 === f && 0 === d && 0 === v ? a ? "开始时" : "结束时" : "".concat(a ? "开始" : "结束", "前").concat(f > 0 ? "".concat(f, "天") : "").concat(d > 0 ? "".concat(d, "小时") : "").concat(v > 0 ? "".concat(v, "分钟") : "");
}, o = function(e) {
    var t = e.selectItems, i = [], n = "";
    return (void 0 === t ? [] : t).forEach(function(e) {
        e.isSelect && "不提醒" !== e.text && (i.push(e.value), n = n ? "".concat(n, "、").concat(e.text) : e.text);
    }), {
        times: i,
        remindStr: n
    };
};

module.exports = {
    allDayMap: l,
    normalMap: c,
    remindBeforeEndListMap: s,
    remindTimeFormat: m,
    remindList: a,
    formatRemindOption: function(t) {
        var i, n = t.isAllDay, l = t.remindTimes, c = t.remindWays, s = r.map(function(t) {
            return e(e({}, t), {}, {
                isSelect: !1
            });
        });
        i = n ? a.allDay.map(function(t) {
            return e(e({}, t), {}, {
                isSelect: !1
            });
        }) : a.normal.map(function(t) {
            return e(e({}, t), {}, {
                isSelect: !1
            });
        });
        var m = "", f = [ "" ];
        l && l.length > 0 && (f = l), i = u({
            selectList: f,
            remindTimeList: i,
            isStartTimeRemind: !0,
            isAllDay: n
        }), m = o({
            selectItems: i
        }).remindStr;
        var d = [ "" ];
        if (console.log("detail remind ways", c), c) {
            var v = c.endTime, S = c.end_time, p = v || S;
            d = 0 === p.length ? [ "" ] : p, n || (s = u({
                selectList: d,
                remindTimeList: s,
                isStartTimeRemind: !1,
                isAllDay: n
            }));
            var x = o({
                selectItems: s
            }).remindStr, D = [];
            m && D.push(m), x && D.push(x), m = D.join("、");
        }
        return {
            remindStr: m || "不提醒",
            newRemindTimes: f,
            newRemindBeforeEndTimes: d,
            remindTimeSelectItems: i,
            remindBeforeEndTimeItems: s
        };
    },
    remindBeforeEndList: r,
    getRemindStr: o,
    getDefaultRemindTime: function() {
        var e = i("view_config", {
            allday_remind_time: "-480",
            default_remind_time: "15",
            default_remind_end_time: ""
        }), t = e.default_remind_time.split(",").filter(function(e) {
            return "" !== e;
        }).map(Number), n = e.allday_remind_time.split(",").filter(function(e) {
            return "" !== e;
        }).map(Number), a = (e.default_remind_end_time || "").split(",").filter(function(e) {
            return "" !== e;
        }).map(Number);
        return {
            normalRemindTimesDefault: t = 0 === t.length ? [ "" ] : t,
            normalRemindEndTimesDefault: a = 0 === a.length ? [ "" ] : a,
            allDayRemindTimesDefault: n = 0 === n.length ? [ "" ] : n
        };
    },
    onRemindTimeItemClick: function(t) {
        var i = t.listData, n = t.index, a = t.type, r = t.addRemindOptionInfo, l = i;
        if ("ADD_OPTION" === a) return function(t) {
            for (var i = t.option, n = t.listData, a = !1, r = [].concat(n), l = 0; l < r.length; l++) if (r[l].value === i.value) {
                a = !0, r[l].isSelect = !0;
                break;
            }
            return a || r.push(e(e({}, i), {}, {
                customAttr: !0
            })), r[0].isSelect = !1, r;
        }({
            option: r,
            listData: l
        });
        if (0 === n) {
            l[n].isSelect = !0;
            for (var c = 0; c < l.length; c++) {
                var s = l[c];
                s.value !== l[n].value && (s.isSelect = !1);
            }
            return l;
        }
        if (n && i[n].customAttr) l.splice(n, 1); else if (l[n].isSelect = !l[n].isSelect, 
        l[n].isSelect) return l[0].isSelect = !1, l;
        return l = function(e) {
            var t = e.listData, i = 0, n = 0, a = [].concat(t);
            return a.forEach(function(e, t) {
                "" === e.value && (n = t), e.isSelect && (i += 1);
            }), 0 === i && (a[n].isSelect = !0), a;
        }({
            listData: l
        });
    }
};