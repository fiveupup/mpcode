var e = require("../sdk/logger/calendar_logger");

wx && "function" == typeof wx.getPerformance && wx.getPerformance().createObserver(function(r) {
    r.getEntries().forEach(function(r) {
        e.aegisSdk.aegis.reportTime({
            name: r.name,
            duration: r.duration,
            ext3: r.path
        });
    });
}).observe({
    entryTypes: [ "render", "script", "navigation" ]
});