require("../@babel/runtime/helpers/Objectvalues");

var e = require("../@babel/runtime/helpers/defineProperty"), n = require("../@babel/runtime/helpers/objectSpread2");

console.log("AuthController.js loaded start");

var o = require("../https/UserHttps"), t = require("../utils/Dispatcher"), r = require("../constants/UserType"), i = require("../sdk/logger/calendar_logger"), a = require("../stores/UserStore"), c = require("../https/CGIClient"), s = require("../configs/AppConfig"), g = require("@tencent/calendar-js-sdk").CalendarSDK, d = require("../utils/beacon/report_data"), u = require("../utils/util"), l = "AuthController.js", h = {
    inited: !1,
    init: function() {
        if (!this.inited) {
            this.inited = !0, this.isDoLogining = !1, this.loginHandler = null;
            var e = (wx.getEnterOptionsSync() || {}).path;
            if (this.initAccountInfo(), "LoginPage/pages/LoginPage/index" !== e) {
                var n = this.isLoginStateValid();
                i.infoAll("isLoginStateValid: ".concat(n), l), n ? t.dispatch({
                    type: r.USER_LOGIN_SUC,
                    payload: {}
                }) : this.doLogin();
            }
        }
    },
    loginPageInit: function(e) {
        var n = e.scene;
        this.updateQrCodeStatus({
            scene: n
        }), this.webLogin({
            scene: n
        });
    },
    updateQrCodeStatus: function(e) {
        var n = e.scene;
        o.updateQrcodeStatus({
            calendar_unique_key: n
        }).catch(function(e) {
            throw i.error("updateQrcodeStatus catch error: ".concat(JSON.stringify(e)), l), 
            e;
        });
    },
    webLogin: function(e) {
        var n = e.scene;
        this.doLogin({
            loginApi: o.authorizeCallback,
            loginExtraParams: {
                calendar_unique_id: n,
                app_id: s.APPID
            },
            authCodeKeyName: "authorize_code"
        });
    },
    initAccountInfo: function() {
        var e = u.getValueFromLocalStorage("account_info") || {}, n = e.openId, o = void 0 === n ? "" : n, a = e.unionId, c = void 0 === a ? "" : a, s = e.userId, g = void 0 === s ? "" : s, d = e.appId, h = void 0 === d ? "" : d, f = e.nickName, p = void 0 === f ? "" : f, y = e.avatarUrl, A = void 0 === y ? "" : y, m = e.area, C = void 0 === m ? "" : m, S = e.phone, v = void 0 === S ? "" : S, N = e.cgiToken, k = void 0 === N ? "" : N, _ = e.cgiTokenEXP, I = void 0 === _ ? 0 : _;
        i.infoAll("getting from cache: openId=".concat(o, ", unionId=").concat(c, ", userId=").concat(g, ", appId=").concat(h, ",\n      avatarUrl=").concat(A, ", area=").concat(C, ", phone=").concat(v, ", cgiToken=").concat(k, ",\n    cgiTokenEXP=").concat(I), l), 
        t.dispatch({
            type: r.ACCOUNT_INFO_INIT,
            payload: {
                openId: o,
                unionId: c,
                userId: g,
                appId: h,
                nickName: p,
                avatarUrl: A,
                area: C,
                phone: v,
                cgiToken: k,
                cgiTokenEXP: I
            }
        });
    },
    isLoginStateValid: function() {
        var e = this.isCGITokenValid();
        return i.infoAll("check login state: { isCGITokenValid: ".concat(e, " }"), l), e;
    },
    isWXSessionValid: function() {
        return new Promise(function(e) {
            wx.checkSession({
                success: function() {
                    i.infoAll("wx.checkSession success", l), e(!0);
                },
                fail: function() {
                    i.warn("wx.checkSession fail: session_key expired", l), e(!1);
                }
            });
        });
    },
    doWxLogin: function() {
        return new Promise(function(e, n) {
            wx.checkSession({
                success: function() {
                    i.infoAll("wx.checkSession success", l), e(!0);
                },
                fail: function() {
                    return i.warn("wx.checkSession fail: session_key expired", l), i.info("do login.", l), 
                    h.doLogin().then(function(n) {
                        e(!0), i.info("AuthController login resp: ".concat(JSON.stringify(n)), l);
                    }).catch(function(e) {
                        n(!1), i.info("AuthController login err: ".concat(JSON.stringify(e)), l);
                    });
                }
            });
        });
    },
    isCGITokenValid: function() {
        var e = a.getCGIToken(), n = a.getCGITokenEXP();
        return i.info("isCGITokenValid: cgiToken: ".concat(e, ", cgiTokenEXP: ").concat(n), l), 
        e ? isNaN(n) || n < 0 ? (i.error("invalid cgiTokenEXP: ".concat(n), l), !1) : u.isTimeAfterNow(n) : (i.warn("no cgi token found", l), 
        !1);
    },
    doLogin: function() {
        var o = this, a = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {}, c = a.loginApi, s = a.loginExtraParams, g = void 0 === s ? {} : s, d = a.authCodeKeyName, h = void 0 === d ? "wxAuthCode" : d;
        return this.isDoLogining ? (i.warnAll("上次登录还未返回，等待并复用上次的登陆请求", l), this.loginHandler) : (this.isDoLogining = !0, 
        this.loginHandler = this.wxLogin().then(function(t) {
            return i.infoAll("this.wxLogin ok, wxAuthCode = ".concat(t), l), o.calendarLogin({
                loginApi: c,
                params: n(n({}, g), {}, e({}, h, t)),
                authCodeKeyName: h
            });
        }).then(function(e) {
            i.infoAll("this.calendarLogin ok, resp = ".concat(JSON.stringify(e)), l);
            var a = e.authCode, c = e.registerAuthCode, s = e.isRegister, g = e.openId, d = e.unionId, h = u.getValueFromLocalStorage("account_info"), f = n(n({}, h), {}, {
                openId: g,
                unionId: d
            });
            return u.setValueInLocalStorage("account_info", f), t.dispatch({
                type: r.GET_OPEN_UNION_ID,
                payload: {
                    openId: g,
                    unionId: d
                }
            }), t.dispatch({
                type: r.GET_IS_REGISTER,
                payload: {
                    authCode: a,
                    registerAuthCode: c,
                    registerState: s ? 1 : 2
                }
            }), s ? o.calendarAuthCode(a) : (o.isDoLogining = !1, Promise.resolve({
                code: 999999999,
                message: "not register"
            }));
        }).catch(function(e) {
            throw o.isDoLogining = !1, i.error("loginHandler failed: msg = ".concat(e.message, ", stack = ").concat(e.stack), l), 
            i.infoAll("loginHandler failed raw err: ".concat(JSON.stringify(e)), l), t.dispatch({
                type: r.CGI_LOGIN_FAIL,
                payload: {}
            }), e;
        }), this.loginHandler);
    },
    wxLogin: function() {
        return new Promise(function(e, n) {
            wx.login({
                timeout: 1e4,
                success: function(o) {
                    o && o.code ? (i.info("wx.login succeed: ".concat(JSON.stringify(o)), l), d.dataReport("mp_login", {
                        login_type: "wx",
                        ret: "Y"
                    }), e(o.code)) : (i.error("wx.login success but cannot get code from response.\n            response = ".concat(JSON.stringify(o)), l), 
                    d.dataReport("mp_login", {
                        login_type: "wx",
                        ret: "N1"
                    }), n("wx.login falied(-1)"));
                },
                fail: function(e) {
                    var o = (e || {}).errMsg, t = void 0 === o ? "" : o, r = u.isTimeout(t);
                    i.error("wx.login failed because: ".concat(t), l), d.dataReport("mp_login", {
                        login_type: "wx",
                        ret: r ? "timeout" : t
                    }), n("wx.login falied(-2)");
                }
            });
        });
    },
    calendarLogin: function(e) {
        var n = e.loginApi, t = e.params, r = e.authCodeKeyName, a = t && t[r], c = o.calendarLoginRaw;
        return n && (c = n, a = t), c(a).then(function(e) {
            i.info("calendarLogin: ".concat(JSON.stringify(e)), l);
            var n = e.data || {}, o = n.code, t = n.message, r = n.nonce;
            if (0 === o) {
                var a = n.data, c = a.auth_code, s = a.register_auth_code, g = a.is_register, d = a.openid, u = a.unionid;
                return i.info("calendarLogin suc. authCode: ".concat(c, ", registerAuthCode: ").concat(s, ",isRegister: ").concat(g, ", openId: ").concat(d, ", unionId: ").concat(u), l), 
                {
                    authCode: c,
                    registerAuthCode: s,
                    isRegister: g,
                    openId: d,
                    unionId: u
                };
            }
            throw i.error("calendarLogin fail. code: ".concat(o, ", message: ").concat(t, ", nonce: ").concat(r), l), 
            {
                code: o,
                message: t
            };
        }).catch(function(e) {
            throw d.dataReport("mp_login", {
                login_type: "calendar-login",
                ret: "N3"
            }), i.error("calendarLogin fail with error: ".concat(JSON.stringify(e)), l), e;
        });
    },
    calendarAuthCode: function(e) {
        var a = this;
        return i.info("calendarAuthCode authCode: ".concat(e), l), o.loginByAuthCodeCgi(e).then(function(e) {
            i.infoAll("loginByAuthCode then: ".concat(JSON.stringify(e)), l);
            var o = e || {}, c = o.userid, s = o.nick_name, g = o.avatar, d = o.area, h = o.phone, f = o.app_id, p = o.wemeet_cgi_token, y = o.wemeet_cgi_token_expiretimes, A = new Date().getTime() + 1e3 * y;
            i.info("cgiTokenExpireTime: ".concat(y, ", cgiTokenEXP: ").concat(A), l);
            var m = u.getValueFromLocalStorage("account_info"), C = n(n({}, m), {}, {
                userId: c,
                appId: f,
                nickName: s,
                avatarUrl: g,
                area: d,
                phone: h,
                cgiToken: p,
                cgiTokenEXP: A
            });
            return u.setValueInLocalStorage("account_info", C), t.dispatch({
                type: r.CALENDAR_AUTH_CODE_SUC,
                payload: {
                    userId: c,
                    nickName: s,
                    avatarUrl: g,
                    area: d,
                    phone: h,
                    appId: f,
                    cgiToken: p,
                    cgiTokenEXP: A
                }
            }), t.dispatch({
                type: r.USER_LOGIN_SUC,
                payload: {}
            }), a.isDoLogining = !1, Promise.resolve({
                code: 0
            });
        }).catch(function(e) {
            throw i.error("calendarAuthCode failed: ".concat(JSON.stringify(e)), l), e;
        });
    },
    registerByAutoPhoneAndLogin: function(e, n) {
        var t = this;
        return h.doWxLogin().then(function(r) {
            console.log("registerByAutoPhoneAndLogin AuthController.doWxLogin:", r, Date.now());
            var c = a.nickName, s = a.avatarUrl, g = a.registerAuthCode;
            return i.info("onPhoneGranted: nickName: ".concat(i.getMd5(c), ", avatarUrl: ").concat(s, ",\n      iv: ").concat(n, ", encryptedData: ").concat(e, ", registerAuthCode: ").concat(g), l), 
            o.registerByAutoPhoneRaw(g, e, n, c, s).then(function(e) {
                i.infoAll("registerByAutoPhoneAndLogin resp: ".concat(JSON.stringify(e)), l);
                var n = e.data, o = n || {}, r = o.code, a = o.message, c = o.nonce;
                if (0 === r) {
                    var s = n.data.auth_code;
                    return i.infoAll("registerByAutoPhoneAndLogin authCode: ".concat(s), l), t.calendarAuthCode(s);
                }
                throw -50004 === r ? (i.error("registerByAutoPhoneAndLogin: phone has been register. \n            code: ".concat(r, ", message: ").concat(a, ", nonce: ").concat(c), l), 
                {
                    code: r,
                    message: "registerByAutoPhoneAndLogin: phone has been register. \n              code: ".concat(r, ", message: ").concat(a, ", nonce: ").concat(c)
                }) : (i.error("registerByAutoPhoneAndLogin: unknown error\n             code: ".concat(r, ", message: ").concat(a, ", nonce: ").concat(c), l), 
                {
                    code: r,
                    message: a
                });
            }).catch(function(e) {
                throw i.error("registerByAutoPhoneAndLogin catch error: ".concat(JSON.stringify(e)), l), 
                e;
            });
        }).catch(function(e) {
            throw console.log("onWxGetPhoneNumResult AuthController.doWxLogin err:", e, Date.now()), 
            e;
        });
    },
    getCaptcha: function(e, n, t, r) {
        var a = this, c = {
            area: e,
            phone: n,
            business_id: 18,
            ticket: t || "",
            rand_string: r || ""
        };
        return i.infoAll("getCaptcha request data: ".concat(JSON.stringify(c)), l), o.getCaptchaCgi(c).then(function(e) {
            i.infoAll("getCaptcha then: ".concat(JSON.stringify(e)), l);
            try {
                a.startCaptchaCountDown(60);
            } catch (e) {
                i.error("".concat(JSON.stringify(e)), l);
            }
            return {
                code: 0,
                message: "获取验证码成功"
            };
        }).catch(function(e) {
            throw i.error("getCaptcha error: ".concat(JSON.stringify(e)), l), {
                code: e.code,
                message: e.message
            };
        });
    },
    startCaptchaCountDown: function(e) {
        t.dispatch({
            type: r.WEMEET_ACCOUNT_REGISTER_CAPTCHA_COUNT_DOWN_START,
            payload: e
        });
    },
    registerByUserPhoneAndLogin: function(e, n, t, r, a, c) {
        var s = this;
        return o.registerByUserPhoneRaw(e, n, t, r, a, c).then(function(e) {
            i.infoAll("registerByUserPhone then: ".concat(JSON.stringify(e)), l);
            var n = e.data, o = n.code, t = n.message, r = n.nonce;
            if (0 === o) {
                var a = n.data.auth_code;
                return s.calendarAuthCode(a);
            }
            throw i.error("registerByUserPhoneAndLogin code: ".concat(o, ", message: ").concat(t, ", nonce: ").concat(r), l), 
            {
                code: o,
                message: t
            };
        }).catch(function(e) {
            throw i.error("registerByUserPhone err: ".concat(JSON.stringify(e)), l), e;
        });
    },
    registerByNoPhoneAndLogin: function(e, n, t) {
        var r = this;
        return i.infoAll("registerByNoPhoneAndLogin", l), o.registerByNoPhoneRaw(e, n, t).then(function(e) {
            i.infoAll("registerByNoPhoneAndLogin then: ".concat(JSON.stringify(e)), l);
            var n = e.data, o = n.code, t = n.message, a = n.nonce;
            if (0 === o) {
                var c = n.data.auth_code;
                return r.calendarAuthCode(c);
            }
            throw i.error("registerByNoPhoneAndLogin code: ".concat(o, ", message: ").concat(t, ", nonce: ").concat(a), l), 
            {
                code: o,
                message: t
            };
        }).catch(function(e) {
            throw i.error("registerByNoPhoneAndLogin err: ".concat(JSON.stringify(e)), l), e;
        });
    },
    getMeetingBindDetail: function() {
        return g.getInstance().getCalendarInfoList({}, {
            interface_version: 1
        }).then(function(e) {
            i.infoAll("getMeetingBindDetail then: ".concat(JSON.stringify(e)), l);
            var n = 0;
            return Object.values(e.syncInfo).forEach(function(e) {
                1 === e.type && (n = e.status);
            }), i.infoAll("getMeetingBindDetail status: ".concat(n), l), Promise.resolve(n);
        }).catch(function(e) {
            throw i.error("getMeetingBindDetail error : ".concat(JSON.stringify(e)), l), e;
        });
    },
    setSyncMeeting: function(e) {
        var n = e ? 2 : 1;
        return g.getInstance().setDataSyncStatus(1, n).then(function(e) {
            i.infoAll("setSyncMeeting success: ".concat(JSON.stringify(e)), l);
        }).catch(function(e) {
            throw i.error("setSyncMeeting error: ".concat(JSON.stringify(e)), l), e;
        });
    },
    refreshUserInfo: function() {
        return o.refreshTokenCgi(!1).then(function(e) {
            i.info("refreshUserInfo resp: ".concat(JSON.stringify(e)), l);
            var o = e || {}, a = o.nick_name, c = o.avatar, s = o.area, g = o.phone;
            i.infoAll("refreshUserInfo avatarUrl: ".concat(c, ", area: ").concat(s, ", phone: ").concat(g), l);
            var d = u.getValueFromLocalStorage("account_info"), h = n(n({}, d), {}, {
                nickName: a,
                avatarUrl: c,
                area: s,
                phone: g
            });
            u.setValueInLocalStorage("account_info", h), t.dispatch({
                type: r.REFRESH_USER_INFO,
                payload: {
                    nickName: a,
                    avatarUrl: c,
                    area: s,
                    phone: g
                }
            });
        }).catch(function(e) {
            i.error("refreshUserInfo error: ".concat(JSON.stringify(e)), l);
        });
    },
    clearLoginInfo: function() {
        i.info("clearLoginInfo", l), u.setValueInLocalStorage("account_info", {}), a.init(), 
        c.appUID = "", c.appId = "", c.cgiToken = "";
        u.setValueInLocalStorage("invite_login_time", "");
    },
    reInit: function() {
        this.inited = !1, this.init();
    },
    getTmpTokenForH5: function() {
        return o.getTmpTokenForH5Cgi().then(function(e) {
            return i.infoAll("getTmpTokenForH5 resp: ".concat(JSON.stringify(e)), l), e.token;
        }).catch(function(e) {
            return i.error("getTmpTokenForH5 error: ".concat(JSON.stringify(e)), l), Promise.reject(e);
        });
    },
    bindUserPhone: function(e, n, t) {
        return o.bindUserPhoneCgi(e, n, t).then(function(e) {
            return i.infoAll("bindUserPhone resp: ".concat(JSON.stringify(e)), l), e;
        }).catch(function(e) {
            i.error("bindUserPhone error: ".concat(JSON.stringify(e)), l);
            var n = "绑定失败";
            switch (e.code) {
              case -4e4:
                n = "绑定失败，手机号码不合法";
                break;

              case -40002:
                n = "短信验证码不正确";
                break;

              case -51008:
                n = "绑定失败，账号不存在";
                break;

              case -51032:
                n = "绑定失败，手机号地区不支持";
                break;

              case -52029:
                n = "绑定失败，该手机号已被其他账号绑定";
                break;

              case -52037:
                n = "绑定失败，不能与当前手机一致";
                break;

              case -40006:
                n = "不支持该国家/地区的手机号码";
            }
            throw {
                code: e.code,
                message: n
            };
        });
    },
    bindWxPhone: function(e, n, t) {
        var r = this;
        return o.bindWxPhoneCgi(e, n, t).then(function(e) {
            return i.infoAll("bindWxPhone resp: ".concat(JSON.stringify(e)), l), e;
        }).catch(function(e) {
            i.error("bindWxPhone error: ".concat(JSON.stringify(e)), l);
            var n = e.code, o = "绑定失败";
            switch (n) {
              case -2e4:
                o = "绑定失败，用户未登录";
                break;

              case -51008:
                o = "绑定失败，账号不存在";
                break;

              case -51032:
                o = "绑定失败，手机号地区不支持";
                break;

              case -52037:
                o = "绑定失败，不能与当前手机一致";
                break;

              case -52029:
                o = "该手机号已被其他账号绑定";
                break;

              case -20012:
                o = "登录态失效，请重新点击授权", r.doLogin();
                break;

              case -40006:
                o = "不支持该国家/地区的手机号码";
            }
            throw i.infoAll("bindWxPhone error code: ".concat(n, ", message: ").concat(o), l), 
            {
                code: n,
                message: o
            };
        });
    },
    getMeetingCode: function() {
        var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : "", n = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : "", t = {
            meeting_url: e,
            meeting_code: n
        };
        return o.getMeetingCodeFromURL(t).then(function(e) {
            return i.info("getMeetingCode resp: ".concat(JSON.stringify(e)), l), e;
        }).catch(function(e) {
            return i.error("getMeetingCode error: ".concat(JSON.stringify(e)), l), e;
        });
    }
};

console.log("AuthController.js loaded end"), module.exports = h;