var e = require("../@babel/runtime/helpers/classCallCheck"), t = require("../@babel/runtime/helpers/createClass"), n = require("./AuthController"), r = require("../utils/util"), o = require("../sdk/logger/calendar_logger"), i = "AuthUnionJumper.js", c = function() {
    function c() {
        if (e(this, c), c.prototype.instance) return c.prototype.instance;
        this.init(), c.prototype.instance = this;
    }
    return t(c, [ {
        key: "init",
        value: function() {
            this.redirectType = "1", this.redirectUrl = encodeURIComponent("/pages/month/month"), 
            this.needTmpToken = !1, this.fontcolor = void 0, this.background = void 0;
        }
    }, {
        key: "setRedirectType",
        value: function(e) {
            this.redirectType = e, o.info("setRedirectType: ".concat(e), i);
        }
    }, {
        key: "setRedirectUrl",
        value: function(e) {
            this.redirectUrl = e, o.info("setRedirectUrl: ".concat(e), i);
        }
    }, {
        key: "setNeedTmpToken",
        value: function(e) {
            this.needTmpToken = e, o.info("setNeedTmpToken: ".concat(e), i);
        }
    }, {
        key: "setFrontColor",
        value: function(e) {
            this.fontcolor = e;
        }
    }, {
        key: "setBackgroundColor",
        value: function(e) {
            this.background = e;
        }
    }, {
        key: "doJump",
        value: function() {
            var e = this;
            return new Promise(function(t, r) {
                e.needTmpToken ? n.getTmpTokenForH5().then(function(n) {
                    o.info("tmpToken is ".concat(n), i);
                    var r = decodeURIComponent(e.redirectUrl), c = r;
                    -1 === r.indexOf("?") ? c += "?token=".concat(n) : c += "&token=".concat(n);
                    var s = encodeURIComponent(c);
                    o.info("new url is ".concat(c, ", encode url is ").concat(s), i), e.redirectByTypeAndUrl(e.redirectType, s), 
                    t();
                }).catch(function(e) {
                    r(e);
                }) : (e.redirectByTypeAndUrl(e.redirectType, e.redirectUrl), t());
            });
        }
    }, {
        key: "redirectByTypeAndUrl",
        value: function(e, t) {
            if (o.info("redirectByTypeAndUrl redirectType: ".concat(e, ", rediretUrl: ").concat(t), i), 
            "1" === e) {
                var n = decodeURIComponent(t);
                o.info("wxUrl is ".concat(n), i), wx.reLaunch({
                    url: n
                });
            } else if ("2" === e) {
                var c = r.getQueryString({
                    url: t,
                    fontcolor: this.fontcolor ? this.fontcolor : "",
                    background: this.background ? this.background : ""
                }), s = "/pages/sub-web/web/web".concat(c), a = "/pages/share-entry/share-entry?sharePath=".concat(encodeURIComponent(s));
                o.info("webUrl is ".concat(s, ", redirectUrl is ").concat(a), i), wx.reLaunch({
                    url: a
                });
            }
            this.init();
        }
    } ]), c;
}();

module.exports = new c();