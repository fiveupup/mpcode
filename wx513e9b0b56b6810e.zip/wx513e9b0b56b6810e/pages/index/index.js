var e = getApp(), n = null;

Page({
    data: {
        adError: !1,
        navList: [ {
            name: "文件格式转换",
            openType: "navigate",
            remark: "办公文档转为PDF文件",
            target: "self",
            url: "/pages/format/format",
            icon: "/images/index/format.png",
            type: "long"
        }, {
            name: "转换记录",
            openType: "navigate",
            remark: "文档转换记录",
            target: "self",
            url: "/pages/format/record",
            icon: "../../images/index/record.png",
            type: "min"
        }, {
            name: "更多功能",
            openType: "navigate",
            remark: "开发中请期待",
            target: "self",
            url: "",
            icon: "../../images/index/coding.png",
            type: "min"
        } ]
    },
    onLoad: function(n) {
        this.navigate2page(n), e.initPrivacyAuth(this, 1);
    },
    navigate2page: function(e) {
        var n = e.scene;
        "oauth" == this.getScene(e).a && wx.navigateTo({
            url: "/pages/oauth/oauth?scene=" + n
        });
    },
    initAd: function() {
        var e = this;
        wx.createInterstitialAd && ((n = wx.createInterstitialAd({
            adUnitId: "adunit-faf4c1aee0ba0f7c"
        })).onLoad(function() {
            e.showAd();
        }), n.onError(function(e) {}), n.onClose(function() {}));
    },
    onShow: function() {},
    showAd: function() {
        n && n.show().catch(function(e) {
            console.error(e);
        });
    },
    onAdLoadFail: function() {
        this.setData({
            adError: !0
        });
    },
    getScene: function(e) {
        var n = {};
        if (e.scene) for (var t = decodeURIComponent(e.scene).split("&"), a = 0; a < t.length; a++) {
            var i = t[a].split("=");
            n[i[0]] = i.length > 1 ? i[1] : "";
        }
        return n;
    },
    onShareAppMessage: function(e) {
        return {
            title: "各种工具百宝箱，文档维修工具箱",
            path: "/pages/index/index"
        };
    }
});