var e = require("../../@babel/runtime/helpers/defineProperty"), t = getApp(), i = wx.getSystemInfoSync(), a = i.windowWidth, s = i.windowHeight, n = a, o = 750 / i.windowWidth, c = i.statusBarHeight * o, r = 44 * o, g = s * o, h = i.screenHeight * o - c - r - g, u = null;

Page({
    data: {
        plusImage: "../../image/index/plus.png",
        selectImgIndex: -1,
        selectIconPic: null,
        canvasWidth: n,
        canvasHeight: n,
        windowHeight: g,
        tabBarHeight: h,
        scrollHeight: g - 300 + h,
        images: [ {
            def: !0
        }, {
            def: !0
        } ]
    },
    onLoad: function(e) {
        this.getConfig(), this.initImages(), this.initAd(), t.initPrivacyAuth(this);
    },
    initImages: function() {
        var e = this;
        wx.getStorage({
            key: "temp_data_images",
            success: function(t) {
                var i = t.data;
                if (i) {
                    for (i.length > 9 && (i = i.slice(0, 9)); i.length < 2; ) i.push({
                        def: !0
                    });
                    e.setData({
                        images: i
                    });
                }
            }
        });
    },
    initAd: function() {
        var e = this;
        wx.createRewardedVideoAd && ((u = wx.createRewardedVideoAd({
            adUnitId: "adunit-3d52c28ea06f3663"
        })).onLoad(function() {}), u.onError(function(e) {}), u.onClose(function(t) {
            t && t.isEnded || void 0 === t ? e.saveImage2Album() : wx.showToast({
                title: "取消下载",
                icon: "none"
            });
        }));
    },
    getConfig: function() {
        t.request({
            url: "/config/vs",
            data: {
                app: "sudoku"
            },
            success: function(e) {
                var i = e.data.data;
                i && 0 == i.status && (t.globalData.isImageCheck = !0);
            }
        });
    },
    onShow: function(t) {
        var i = this.data.selectImgIndex, a = this.data.selectIconPic;
        if (i > -1 && a) {
            var s, n = "images[" + i + "].src", o = "images[" + i + "].def";
            this.setData((e(s = {}, n, this.data.selectIconPic), e(s, o, !1), s)), this.setData({
                selectImgIndex: -1,
                selectIconPic: null
            });
        }
    },
    onOneKeyUploadTap: function(e) {
        var i = this, a = e.currentTarget.id;
        wx.chooseImage({
            count: 9,
            sizeType: [ "original", "compressed" ],
            sourceType: [ "album" ],
            success: function(e) {
                var s = e.tempFilePaths;
                if (s && s.length > 0) {
                    var n = i.data.images, o = [];
                    "onekey" != a && n.forEach(function(e) {
                        e.def || o.push(e);
                    }), s.forEach(function(e) {
                        o.push({
                            src: e,
                            def: !1
                        });
                    }), o.push({
                        def: !0
                    }), i.setData({
                        images: o
                    }), i.initImagesSize(), t.loadAccessToken();
                }
            }
        });
    },
    onImageExistsTap: function(i) {
        var a = this, s = parseInt(i.currentTarget.id);
        wx.showActionSheet({
            itemList: [ "移除图片", "更换图片" ],
            success: function(i) {
                if (0 == i.tapIndex) {
                    for (var n = a.data.images, o = [], c = 0; c < n.length; c++) {
                        var r = n[c];
                        c != s && o.push(r);
                    }
                    1 == o.length && o.push({
                        def: !0
                    }), a.setData({
                        images: o
                    }), wx.showToast({
                        title: "已移除",
                        icon: "none"
                    });
                } else 1 == i.tapIndex && wx.showActionSheet({
                    itemList: [ "相册中选取", "用手机拍照", "聊天中选取" ],
                    success: function(i) {
                        0 == i.tapIndex ? wx.chooseImage({
                            count: 1,
                            sizeType: [ "original", "compressed" ],
                            sourceType: [ "album" ],
                            success: function(t) {
                                var i = {
                                    def: !1,
                                    src: t.tempFilePaths[0]
                                };
                                a.setData(e({}, "images[" + s + "]", i)), a.initImagesSize();
                            }
                        }) : 1 == i.tapIndex ? wx.chooseImage({
                            count: 1,
                            sizeType: [ "original", "compressed" ],
                            sourceType: [ "camera" ],
                            success: function(i) {
                                var n = {
                                    def: !1,
                                    src: i.tempFilePaths[0]
                                };
                                a.setData(e({}, "images[" + s + "]", n)), a.initImagesSize(), t.loadAccessToken();
                            }
                        }) : wx.chooseMessageFile({
                            count: 1,
                            type: "image",
                            success: function(t) {
                                var i = {
                                    def: !1,
                                    src: t.tempFiles[0].path
                                };
                                a.setData(e({}, "images[" + s + "]", i)), a.initImagesSize();
                            }
                        });
                    }
                });
            }
        });
    },
    initImagesSize: function() {
        for (var e = this.data.images, t = 0; t < e.length; t++) {
            var i = e[t];
            i.def || !i.src || i.width || this.initImageItemSize(t, i);
        }
    },
    initImageItemSize: function(t, i) {
        var a = this;
        wx.getImageInfo({
            src: i.src,
            success: function(s) {
                i.width = s.width, i.height = s.height;
                var n = "images[" + t + "]";
                a.setData(e({}, n, i));
            }
        });
    },
    getCropperImage: function() {
        var e = wx.getStorageSync("down_image_times");
        if (e) {
            var t = this.getDateStr();
            if (e.time == t && 1 == e.count) return void this.showVideoAd();
        }
        this.saveImage2Album();
    },
    showVideoAd: function() {
        var e = this;
        u && u.isReady() ? wx.showModal({
            title: "提示",
            content: "观看一次视频，解锁今日下载权限",
            success: function(t) {
                t.confirm ? u.show().catch(function() {
                    u.load().then(function() {
                        return u.show();
                    }).catch(function(t) {
                        e.saveImage2Album();
                    });
                }) : t.cancel && wx.showToast({
                    title: "取消保存",
                    icon: "none"
                });
            },
            fail: function() {
                e.saveImage2Album();
            }
        }) : e.saveImage2Album();
    },
    saveImage2Album: function(e) {
        var i = this, a = this.data.images, s = !1;
        if (a.forEach(function(e) {
            e.def || (s = !0);
        }), !s) return wx.hideLoading(), void wx.showModal({
            title: "温馨提示",
            content: "没有可生成的图片"
        });
        wx.showLoading({
            title: "正在合成图片"
        });
        for (var n = [], o = 0, c = i.data.canvasWidth, r = 0; r < a.length; r++) {
            if (!(m = a[r]).def) {
                var g = m.width, h = m.height, u = parseInt(h / (g / c)), d = {
                    src: m.src,
                    x: 0,
                    y: o,
                    width: c,
                    height: u
                };
                n.push(d), o += u;
            }
        }
        i.setData({
            canvasHeight: o
        });
        var f = wx.createCanvasContext("imageCanvas");
        f.setFillStyle("#ffffff"), f.fillRect(0, 0, c, o);
        for (r = 0; r < n.length; r++) {
            var m = n[r];
            f.drawImage(m.src, m.x, m.y, m.width, m.height);
        }
        f.draw(!1, function(a) {
            setTimeout(function() {
                wx.canvasToTempFilePath({
                    canvasId: "imageCanvas",
                    x: 0,
                    y: 0,
                    fileType: "jpg",
                    width: c,
                    height: o,
                    success: function(a) {
                        var s = a.tempFilePath, n = t.globalData.isImageCheck;
                        null != e && "undefined" != e || !n ? wx.getSetting({
                            success: function(e) {
                                if (!1 === e.authSetting["scope.writePhotosAlbum"]) return wx.hideLoading(), void wx.showModal({
                                    title: "授权提醒",
                                    content: "您需要授权保存图片到相册才能保存",
                                    confirmText: "去授权",
                                    confirmColor: "#f3513c",
                                    success: function(e) {
                                        e.confirm && wx.openSetting({});
                                    }
                                });
                                wx.saveImageToPhotosAlbum({
                                    filePath: s,
                                    success: function() {
                                        wx.hideLoading(), wx.showToast({
                                            title: "图片已保存"
                                        });
                                        var e = "down_image_times", t = wx.getStorageSync(e), a = t && t.count ? t.count : 0, s = {
                                            time: i.getDateStr(),
                                            count: a + 1
                                        };
                                        wx.setStorage({
                                            key: e,
                                            data: s
                                        });
                                    },
                                    fail: function() {
                                        wx.hideLoading();
                                    }
                                });
                            }
                        }) : t.imgSecurityCheck(s, i.saveImage2Album);
                    },
                    fail: function() {
                        wx.hideLoading();
                    }
                });
            }, 300);
        });
    },
    getDateStr: function() {
        var e = new Date(), t = e.getMonth() + 1;
        t = t > 9 ? t : "0" + t;
        var i = e.getDate();
        return i = i > 9 ? i : "0" + i, e.getFullYear() + "-" + t + "-" + i;
    }
});