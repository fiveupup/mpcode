var t = getApp();

require("../../utils/common.js"), Page({
    data: {
        platform: "",
        isDevicePc: !1,
        dataList: [],
        pageNo: 1,
        hasMore: !0,
        loading: !1,
        downloading: !1,
        filePath: "",
        tempItem: {},
        showTips: !1
    },
    onLoad: function(e) {
        this.getPlatform(), this.loadHistRecord(1), t.initPrivacyAuth(this);
    },
    onShow: function() {},
    getPlatform: function() {
        var t = this;
        wx.getSystemInfo({
            success: function(e) {
                var a = e.platform || "", i = "window" == a || "windows" == a || "mac" == a;
                t.setData({
                    platform: a,
                    isDevicePc: i
                });
            }
        });
    },
    onItemTap: function(t) {
        var e = this, a = t.currentTarget.dataset.index, i = this.data.dataList[a], o = i.status;
        wx.showActionSheet({
            itemList: [ "下载原始文件", "下载转换文档", "删除当前记录" ],
            success: function(t) {
                var n = t.tapIndex;
                if (0 == n) i.ty = 1, e.downFile(i); else if (1 == n) {
                    if (0 == o || 2 == o) {
                        var s = 0 == o ? "文件尚未准备好" : "文件转换失败，无法下载";
                        return void wx.showToast({
                            title: s,
                            icon: "none"
                        });
                    }
                    i.ty = 2, e.downFile(i);
                } else e.deleteConvert(a);
            }
        });
    },
    deleteConvert: function(e) {
        var a = this, i = a.data.dataList[e];
        wx.showModal({
            title: "提示",
            content: "删除后原文件及PDF文件将一同删除，您确定要继续吗？",
            success: function(e) {
                e.confirm && t.request({
                    url: "/attachment/convert/delete",
                    data: {
                        id: i.id
                    },
                    success: function(t) {
                        1 == t.data.code ? (a.loadPageOne(), wx.showToast({
                            title: t.data.msg
                        })) : wx.showModal({
                            showCancel: !1,
                            content: t.data.msg,
                            confirmText: "我知道了"
                        });
                    }
                });
            }
        }), wx.vibrateShort({
            type: "light"
        });
    },
    onPullDownRefresh: function() {
        this.loadPageOne();
    },
    loadPageOne: function() {
        this.setData({
            pageNo: 1,
            hasMore: !0
        }), this.loadHistRecord(1);
    },
    onReachBottom: function() {
        var t = this.data.pageNo;
        this.loadHistRecord(t);
    },
    loadHistRecord: function(e) {
        var a = this;
        if (a.data.hasMore && !a.data.loading) {
            a.setData({
                loading: !0
            }), t.request({
                url: "/attachment/convert/page",
                data: {
                    pageNo: e,
                    pageSize: 20
                },
                success: function(t) {
                    var i = t.data.rows, o = a.data.dataList;
                    a.initMoreAttr(i), 1 == e && (o = []);
                    for (var n = 0; n < i.length; n++) {
                        var s = i[n];
                        o.push(s);
                    }
                    a.setData({
                        dataList: o,
                        pageNo: e + 1,
                        loading: !1,
                        hasMore: 20 == i.length
                    }), wx.stopPullDownRefresh();
                }
            });
        } else wx.stopPullDownRefresh();
    },
    initMoreAttr: function(t) {
        if (t && !(t.length < 1)) for (var e = 0; e < t.length; e++) {
            var a = t[e], i = a.docUrl, o = "/images/icon/doc.png";
            i.indexOf("xls") > 0 ? o = "/images/icon/doc.png" : i.indexOf("ppt") > 0 && (o = "/images/icon/ppt.png"), 
            a.icon = o, a.sizeStr = this.formatSize(a.sizes), a.timeStr = new Date(a.createTime).format("MM月dd日 HH:mm");
        }
    },
    formatSize: function(t) {
        return t < 1024 ? (t / 1024 + 0).toFixed(2) + " KB" : t >= 1024 && t < 1048576 ? (t / 1024 + 0).toFixed(0) + " KB" : t >= 1048576 ? (t / 1024 / 1024 + 0).toFixed(2) + "MB" : void 0;
    },
    downFile: function(t) {
        var e = this, a = t.ty;
        if (!e.data.downloading) {
            e.setData({
                downloading: !0,
                tempItem: t
            });
            var i = 1 == a ? t.docUrl : t.pdfUrl, o = i.substring(i.lastIndexOf("/") + 1), n = wx.env.USER_DATA_PATH + "/convert/" + o;
            e.setData({
                filePath: n
            });
            var s = wx.getFileSystemManager();
            s.getFileInfo({
                filePath: n,
                success: function(t) {
                    e.saveAttachFile(n);
                },
                fail: function() {
                    var t = wx.env.USER_DATA_PATH + "/convert/";
                    try {
                        s.mkdirSync(t, !0);
                    } catch (t) {}
                    wx.showLoading({
                        title: "正在下载"
                    }), wx.downloadFile({
                        url: i,
                        filePath: n,
                        success: function(t) {
                            wx.hideLoading();
                            var a = t.filePath;
                            e.saveAttachFile(a);
                        },
                        fail: function(t) {
                            wx.hideLoading(), e.setData({
                                progress: 0,
                                downloading: !1
                            }), wx.showToast({
                                title: "下载失败，请重试",
                                icon: "none"
                            });
                        }
                    }).onProgressUpdate(function(t) {
                        wx.hideLoading();
                        var a = t.progress;
                        e.setData({
                            progress: a
                        });
                    });
                }
            });
        }
    },
    saveAttachFile: function(t) {
        var e = this;
        e.setData({
            downloading: !1,
            filePath: t
        });
        var a = e.data.platform;
        "window" == a || "windows" == a || "mac" == a ? wx.saveFileToDisk({
            filePath: t,
            success: function(t) {
                wx.showToast({
                    title: "保存成功"
                });
            },
            fail: function(t) {
                wx.showToast({
                    title: "保存失败",
                    icon: "none"
                });
            }
        }) : e.setData({
            showTips: !0
        }), setTimeout(function() {
            e.setData({
                progress: 0
            });
        }, 300);
    },
    openFile: function() {
        var t = this.data.filePath;
        wx.openDocument({
            filePath: t,
            showMenu: !0,
            success: function(t) {},
            fail: function(t) {
                wx.showModal({
                    title: "提示",
                    content: "文件打开失败，请添加到收藏查看"
                });
            }
        });
    },
    chooseSaveType: function() {
        var t = this;
        wx.showActionSheet({
            itemList: [ "分享给好友", "添加到收藏" ],
            success: function(e) {
                0 == e.tapIndex ? t.shareFile2Friend() : t.add2Favorite();
            }
        });
    },
    shareFile2Friend: function() {
        var t = this.data.filePath, e = this.data.tempItem;
        if (wx.shareFileMessage) {
            var a = 1 == e.ty ? e.name : e.pdfName;
            wx.shareFileMessage({
                filePath: t,
                fileName: a
            });
        } else wx.showModal({
            showCancel: !1,
            content: "您的微信版本过低，不支持分享文件，建议您使用其他人手机下载"
        });
    },
    add2Favorite: function() {
        var t = this.data.filePath, e = this.data.tempItem, a = 1 == e.ty ? e.name : e.pdfName;
        wx.addFileToFavorites ? wx.addFileToFavorites({
            filePath: t,
            fileName: a,
            success: function(t) {
                wx.showToast({
                    title: "已添加到收藏"
                });
            }
        }) : wx.showModal({
            showCancel: !1,
            content: "您的微信版本过低，不支持收藏文件，建议您使用其他人手机下载"
        });
    },
    closeModal: function() {
        this.setData({
            showTips: !1
        });
    }
});