var e = getApp(), t = null;

Page({
    data: {
        setting: {},
        progress: 0,
        qiniuUpToken: {}
    },
    onLoad: function(t) {
        this.showAd(), e.initPrivacyAuth(this);
    },
    onShow: function(e) {
        this.loadQiNiuToken();
    },
    showAd: function() {
        wx.createInterstitialAd && ((t = wx.createInterstitialAd({
            adUnitId: "adunit-5c864bd211b05e7f"
        })).onLoad(function() {
            t.show();
        }), t.onError(function(e) {}), t.onClose(function() {}));
    },
    uploadFile: function(e) {
        var t = this;
        if (!t.data.qiniuUpToken.token) return t.loadQiNiuToken(), void wx.showToast({
            title: "网络出错，请稍后重试",
            icon: "none"
        });
        wx.chooseMessageFile({
            count: 1,
            type: "file",
            extension: [ "doc", "docx", "xls", "xlsx", "ppt", "pptx" ],
            success: function(e) {
                if (e.tempFiles[0].size < 20971520) t.uploadOneFile(e.tempFiles, 0); else {
                    wx.showModal({
                        content: "请选择的小于20M的文件"
                    });
                }
            }
        });
    },
    uploadOneFile: function(t, n) {
        var o = this, a = t.length, i = o.data.qiniuUpToken, s = t[n], r = s.path, u = s.name, x = {
            name: u,
            sizes: s.size
        };
        o.setData({
            progress: 0
        });
        var c = u.lastIndexOf("."), l = c > 0 ? u.substring(c) : "", d = o.generateUUID().toUpperCase(), f = new Date().format("yyyyMMdd"), p = {
            token: i.token,
            key: "images/docx/" + f + "/" + d + l
        };
        wx.showLoading({
            title: "上传中"
        }), wx.uploadFile({
            url: e.globalData.upDomain,
            filePath: r,
            name: "file",
            formData: p,
            success: function(e) {
                var t = e.data, n = JSON.parse(t), a = i.accessUrl, s = (a = a.endsWith("/") ? a : a + "/") + n.key;
                x.docUrl = s, o.saveConvert(x);
            },
            fail: function(e) {
                wx.hideLoading(), wx.showToast({
                    title: "文件上传失败，请重新上传",
                    icon: "none"
                }), o.loadQiNiuToken();
            }
        }).onProgressUpdate(function(e) {
            var t = e.progress;
            t < 100 ? o.setData({
                progress: t
            }) : 100 === t && (o.setData({
                progress: 100
            }), n >= a - 1 && setTimeout(function() {
                o.setData({
                    progress: 0
                });
            }, 500));
        });
    },
    saveConvert: function(t) {
        e.request({
            url: "/attachment/convert/save",
            method: "post",
            data: t,
            success: function(e) {
                wx.hideLoading(), wx.navigateTo({
                    url: "/pages/format/record"
                });
            },
            fail: function() {
                wx.hideLoading();
            }
        });
    },
    loadQiNiuToken: function() {
        var t = this;
        e.request({
            url: "/upload/token",
            success: function(e) {
                t.setData({
                    qiniuUpToken: e.data
                });
            }
        });
    },
    generateUUID: function() {
        var e = new Date().getTime();
        return "xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx".replace(/[xy]/g, function(t) {
            var n = (e + 16 * Math.random()) % 16 | 0;
            return e = Math.floor(e / 16), ("x" == t ? n : 3 & n | 8).toString(16);
        });
    },
    getDateStr: function() {
        var e = new Date(), t = e.getMonth() + 1;
        t = t > 9 ? t : "0" + t;
        var n = e.getDate();
        return n = n > 9 ? n : "0" + n, e.getFullYear() + "-" + t + "-" + n;
    }
});