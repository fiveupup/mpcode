var t = getApp();

Page({
    data: {
        ticket: "",
        status: 1,
        loginUser: {},
        cancelBtn: "取消",
        tips: "您将使用微信登录微件助手"
    },
    onLoad: function(a) {
        this.initUserInfo(), this.getTicket(a), this.loadTicketStatus(), t.initPrivacyAuth(this);
    },
    getTicket: function(t) {
        var a = this.getScene(t).v || "";
        this.setData({
            ticket: a
        });
    },
    getScene: function(t) {
        var a = {};
        if (t.scene) for (var i = decodeURIComponent(t.scene).split("&"), s = 0; s < i.length; s++) {
            var e = i[s].split("=");
            a[e[0]] = e.length > 1 ? e[1] : "";
        }
        return a;
    },
    initUserInfo: function() {
        var a = this, i = t.globalData.loginUser;
        i && i.uid && (this.initAvatar(i), this.setData({
            loginUser: i
        })), t.loginCallback = function(t) {
            a.initAvatar(t), a.setData({
                loginUser: t
            }), a.loadTicketStatus();
        };
    },
    initAvatar: function(t) {
        var a = t.avatar;
        a && a.endsWith("/132") && (a = a.substring(0, a.length - 4) + "/0", t.avatar = a, 
        this.setData({
            loginUser: t
        }));
    },
    loadTicketStatus: function() {
        var a = this, i = this.data.ticket;
        t.request({
            url: "/ticket/status",
            data: {
                ticket: i
            },
            success: function(t) {
                var i = t.data;
                0 == i.code && (a.setData({
                    status: i.code
                }), a.setData({
                    tips: i.msg
                }));
            }
        });
    },
    getUserInfo: function(a) {
        var i = this;
        wx.getUserProfile && wx.getUserProfile({
            desc: "用于完善会员资料",
            success: function(s) {
                var e = s.userInfo, n = t.globalData.loginUser;
                n.nick = e.nickName, n.avatar = e.avatarUrl, t.globalData.loginUser = n, i.setData({
                    loginUser: n
                }), t.saveUserInfo(e, s.encryptedData, s.iv), a && a();
            }
        });
    },
    oauthLogin: function() {
        var a = this, i = this.data.ticket;
        this.data.loginUser ? t.request({
            url: "/oauth/login",
            data: {
                code: i
            },
            success: function(t) {
                a.setData({
                    status: 3
                }), wx.showModal({
                    content: t.data.msg,
                    showCancel: !1,
                    success: function() {
                        wx.switchTab({
                            url: "/pages/index/index"
                        });
                    }
                });
            }
        }) : t.login(0);
    },
    enterMiniApp: function() {
        wx.switchTab({
            url: "/pages/index/index"
        });
    },
    cancelOauth: function() {
        1 == this.data.status ? this.setData({
            status: 0,
            tips: "您已取消登录操作"
        }) : wx.exitMiniProgram();
    }
});