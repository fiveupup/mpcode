var t = getApp();

Page({
    data: {
        wechat: "Yongtion",
        loginUser: {},
        showAdmin: !1,
        userVip: {},
        adUnitId: {},
        modalShow: !1,
        adTimes: 0,
        adLimit: 5,
        inviteTimes: 0,
        inviteLimit: 5,
        canIUseUserProfile: !1
    },
    onLoad: function(a) {
        t.initPrivacyAuth(this);
    },
    onPullDownRefresh: function() {
        this.initUserInfo();
    },
    initUserInfo: function() {
        var a = this, i = t.globalData.loginUser;
        i && i.uid && (this.setData({
            loginUser: i
        }), 2 == i.role && a.setData({
            showAdmin: !0
        })), t.loginCallback = function(t) {
            a.setData({
                loginUser: t
            }), 2 == t.role && a.setData({
                showAdmin: !0
            });
        }, wx.stopPullDownRefresh();
    },
    onShow: function() {
        this.initUserInfo();
    },
    copyUid: function() {
        var t = this.data.loginUser.uid || 0;
        wx.setClipboardData({
            data: t + "",
            success: function() {
                wx.showToast({
                    title: "复制成功"
                });
            }
        });
    },
    copyWechat: function() {
        var t = this.data.wechat;
        wx.setClipboardData({
            data: t,
            success: function() {
                wx.showToast({
                    title: "微信已复制"
                });
            }
        });
    },
    getUserInfo: function() {
        var a = this;
        a.data.canIUseUserProfile && wx.getUserProfile({
            desc: "用于完善会员资料",
            success: function(i) {
                var o = i.userInfo, n = t.globalData.loginUser;
                n.nick = o.nickName, n.avatar = o.avatarUrl, t.globalData.loginUser = n, a.setData({
                    loginUser: n
                }), t.saveUserInfo(o, i.encryptedData, i.iv);
            }
        });
    },
    authSetting: function() {
        wx.openSetting();
    },
    showMember: function() {
        this.setData({
            modalShow: !0
        });
    },
    closeModal: function() {
        this.setData({
            modalShow: !1
        });
    },
    delayClose: function() {
        var t = this;
        setTimeout(function() {
            t.setData({
                modalShow: !1
            });
        }, 500);
    }
});