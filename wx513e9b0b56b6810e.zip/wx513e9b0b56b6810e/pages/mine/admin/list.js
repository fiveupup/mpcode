var a = getApp();

require("../../../utils/common.js"), Page({
    data: {
        dataList: [],
        pageNo: 1,
        hasMore: !0,
        loading: !1,
        isPc: !1,
        searching: !1,
        keyword: "",
        adTypes: {
            1: "chaping",
            2: "reward",
            3: "banner"
        }
    },
    onLoad: function() {
        wx.showLoading({
            title: "加载中"
        }), this.loadCounts(), this.loadDataList(1), this.getPlatform(), a.initPrivacyAuth(this);
    },
    getPlatform: function() {
        var a = this;
        wx.getSystemInfo({
            success: function(t) {
                var e = t.platform || "", o = "window" == e || "windows" == e || "mac" == e;
                a.setData({
                    isPc: o
                });
            }
        });
    },
    startSearch: function() {
        this.setData({
            searching: !0
        });
    },
    endSearch: function() {
        this.setData({
            searching: !1,
            keyword: ""
        }), this.setData({
            pageNo: 1,
            hasMore: !0
        }), this.loadCounts(), this.loadDataList(1);
    },
    keywordInput: function(a) {
        var t = a.detail.value;
        this.setData({
            keyword: t
        });
    },
    searchByKeyword: function() {
        this.setData({
            pageNo: 1,
            hasMore: !0
        }), wx.showLoading({
            title: "搜索中"
        }), this.loadDataList(1);
    },
    onPullDownRefresh: function() {
        this.setData({
            pageNo: 1,
            hasMore: !0
        }), this.loadCounts(), this.loadDataList(1);
    },
    onReachBottom: function() {
        var a = this.data.pageNo;
        this.loadDataList(a);
    },
    loadDataList: function(t) {
        var e = this;
        if (!e.data.hasMore || e.data.loading) return wx.hideLoading(), void wx.stopPullDownRefresh();
        e.setData({
            loading: !0
        });
        var o = e.data.keyword || "";
        a.request({
            url: "/attachment/all/page",
            method: "post",
            data: {
                pageNo: t,
                pageSize: 20,
                keyword: o
            },
            success: function(a) {
                wx.hideLoading(), wx.stopPullDownRefresh(), e.setData({
                    loading: !1
                });
                var o = a.data.rows, s = e.data.dataList;
                1 == t && (s = []);
                for (var i = 0; i < o.length; i++) {
                    var n = o[i];
                    s.push(n);
                }
                e.parseTime(s), e.setData({
                    dataList: s,
                    pageNo: t + 1,
                    hasMore: 20 == o.length
                });
            },
            fail: function() {
                wx.hideLoading(), wx.stopPullDownRefresh(), e.setData({
                    loading: !1
                });
            }
        });
    },
    parseTime: function(a) {
        if (a && !(a.length < 1)) for (var t = 0; t < a.length; t++) {
            var e = a[t];
            e.timeStr = new Date(e.createTime).format("MM月dd日 HH:mm");
        }
    },
    loadCounts: function() {
        var t = this;
        a.request({
            url: "/attachment/count",
            success: function(a) {
                t.setData({
                    counts: a.data.data
                });
            }
        });
    },
    onShow: function() {}
});