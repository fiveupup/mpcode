var t = getApp();

require("../../../utils/common.js"), Page({
    data: {
        loginUser: {},
        uuid: "",
        detail: {},
        edit: !1,
        suffix: "",
        tempName: "",
        focus: !1,
        progress: 0,
        filePath: "",
        showTips: !1,
        btnText: "下载文件",
        downloading: !1,
        setting: {},
        tempImgUrl: "",
        platform: "",
        isDevicePc: !1,
        confirm: !1,
        modalShow: !1,
        adList: [ {
            value: 1,
            text: "插屏广告"
        }, {
            value: 2,
            text: "激励广告"
        }, {
            value: 3,
            text: "模板广告"
        } ],
        tempTime: ""
    },
    onLoad: function(a) {
        var e = a.uuid;
        this.setData({
            uuid: e
        }), this.loadDetail(), this.loadTempTime(), this.initLoginUser(), this.getPlatform(), 
        this.initSetting(), t.initPrivacyAuth(this);
    },
    onShow: function(t) {},
    initSetting: function() {
        var a = this, e = t.globalData.setting;
        t.onSettingDone = function(t) {
            a.setData({
                setting: t
            });
        }, e && a.setData({
            setting: e
        });
    },
    getPlatform: function() {
        var t = this;
        wx.getSystemInfo({
            success: function(a) {
                var e = a.platform || "", i = "window" == e || "windows" == e || "mac" == e;
                t.setData({
                    platform: e,
                    isDevicePc: i
                });
            }
        });
    },
    initLoginUser: function() {
        var a = this, e = t.globalData.loginUser;
        e && e.uid && a.setData({
            loginUser: e
        }), t.loginCallback = function(t) {
            a.setData({
                loginUser: t
            }), a.data.detail.id || a.loadDetail();
        };
    },
    onPullDownRefresh: function() {
        this.loadDetail();
    },
    toEditName: function() {
        var t = !this.data.edit, a = this.data.detail.name, e = a.lastIndexOf(".");
        if (e > 0) {
            var i = a.substring(0, e), n = a.substring(e);
            this.setData({
                tempName: i,
                suffix: n
            });
        } else this.setData({
            tempName: a
        });
        this.setData({
            edit: t,
            focus: !0
        });
    },
    nameInput: function(t) {
        var a = t.detail.value;
        this.setData({
            tempName: a
        });
    },
    loadDetail: function() {
        var a = this, e = a.data.uuid;
        t.request({
            url: "/attachment/detail",
            data: {
                uuid: e
            },
            success: function(t) {
                var e = t.data.data;
                a.setData({
                    detail: e
                });
            },
            complete: function() {
                wx.stopPullDownRefresh();
            }
        });
    },
    loadTempTime: function() {
        var a = this, e = a.data.uuid;
        t.request({
            url: "/attachment/temp/deadline",
            data: {
                uuid: e
            },
            success: function(t) {
                var e = t.data.data;
                a.setData({
                    tempTime: e
                });
            },
            complete: function() {
                wx.stopPullDownRefresh();
            }
        });
    },
    saveAttachment: function() {
        var a = this, e = a.data.detail, i = a.data.suffix, n = a.data.tempName;
        if (n) {
            a.setData({
                focus: !1
            });
            var s = {
                id: e.id,
                name: n + i
            };
            t.request({
                url: "/attachment/save",
                data: s,
                method: "post",
                success: function(t) {
                    a.loadDetail(), a.setData({
                        edit: !1
                    }), wx.showToast({
                        title: t.data.msg,
                        icon: t.data.code ? "" : "none"
                    });
                }
            });
        } else wx.showToast({
            title: "文件名称不能为空",
            icon: "none"
        });
    },
    cancelUpdate: function() {
        this.setData({
            edit: !1,
            focus: !1
        });
    },
    updateAttach: function(a) {
        var e = this;
        t.request({
            url: "/attachment/save",
            data: a,
            method: "post",
            success: function(t) {
                e.loadDetail(), wx.showToast({
                    title: t.data.msg,
                    icon: t.data.code ? "" : "none"
                });
            }
        });
    },
    beforeDown: function() {
        var t = this.data.detail;
        t.id || t.uid ? t.url && !t.del ? t.status ? this.downAttach() : wx.showToast({
            title: "上传者已关闭下载",
            icon: "none"
        }) : wx.showToast({
            title: "文件已被上传者删除",
            icon: "none"
        }) : wx.showToast({
            title: "网络似乎不佳，切换网络重新打开试试吧",
            icon: "none"
        });
    },
    downAttach: function() {
        var t = this, a = t.data.uuid, e = t.data.detail;
        if (!t.data.downloading) {
            t.setData({
                downloading: !0
            });
            var i = e.name;
            i = t.replaceName(i);
            var n = e.urlDone, s = wx.env.USER_DATA_PATH + "/" + a + (n ? "_2" : "") + "/" + i;
            t.setData({
                filePath: s
            });
            var o = wx.getFileSystemManager();
            o.getFileInfo({
                filePath: s,
                success: function(a) {
                    t.saveAttachFile(s);
                },
                fail: function() {
                    var i = wx.env.USER_DATA_PATH + "/" + a + (n ? "_2" : "") + "/";
                    try {
                        o.mkdirSync(i, !0);
                    } catch (t) {}
                    wx.downloadFile({
                        url: e.url,
                        filePath: s,
                        success: function(a) {
                            var e = a.filePath;
                            t.saveAttachFile(e), t.onDownDone();
                        },
                        fail: function(a) {
                            t.setData({
                                progress: 0,
                                btnText: "下载文件",
                                downloading: !1
                            }), wx.showToast({
                                title: "下载失败，请重试",
                                icon: "none"
                            });
                        }
                    }).onProgressUpdate(function(a) {
                        var e = a.progress;
                        t.setData({
                            progress: e,
                            btnText: "已下载" + e + "%"
                        });
                    });
                }
            });
        }
    },
    replaceName: function(t) {
        for (;t.indexOf("/") >= 0; ) t = t.replace("/", "_");
        return t;
    },
    saveAttachFile: function(t) {
        var a = this;
        a.setData({
            downloading: !1,
            filePath: t
        });
        var e = a.data.platform;
        "window" == e || "windows" == e || "mac" == e ? wx.saveFileToDisk({
            filePath: t,
            success: function(t) {
                wx.showToast({
                    title: "保存成功"
                });
            },
            fail: function(t) {
                wx.showToast({
                    title: "保存失败",
                    icon: "none"
                });
            }
        }) : a.setData({
            showTips: !0
        }), setTimeout(function() {
            a.setData({
                progress: 0,
                btnText: "下载文件"
            });
        }, 300);
    },
    openFile: function() {
        var t = this.data.filePath;
        wx.openDocument({
            filePath: t,
            showMenu: !0,
            success: function(t) {},
            fail: function(t) {
                wx.showModal({
                    title: "提示",
                    content: "文件打开失败，请添加到收藏查看"
                });
            }
        });
    },
    shareFile2Friend: function() {
        var t = this.data.filePath, a = this.data.detail;
        wx.shareFileMessage ? wx.shareFileMessage({
            filePath: t,
            fileName: a.name
        }) : wx.showModal({
            showCancel: !1,
            content: "您的微信版本过低，不支持分享文件，建议您使用其他人手机下载"
        });
    },
    add2Favorite: function() {
        var t = this.data.filePath, a = this.data.detail.name;
        wx.addFileToFavorites ? wx.addFileToFavorites({
            filePath: t,
            fileName: a,
            success: function(t) {
                wx.showToast({
                    title: "已添加到收藏"
                });
            }
        }) : wx.showModal({
            showCancel: !1,
            content: "您的微信版本过低，不支持收藏文件，建议您使用其他人手机下载"
        });
    },
    closeModal: function() {
        this.setData({
            showTips: !1
        });
    },
    closeTips: function() {
        this.setData({
            modalShow: !1
        });
    },
    checkboxChange: function(t) {
        1 == t.detail.value.length ? this.setData({
            confirm: !0
        }) : this.setData({
            confirm: !1
        });
    },
    gotoPcDown: function() {
        var t = this.data.uuid;
        this.data.isDevicePc ? wx.showToast({
            title: '请点击"下载文件"按钮进行下载',
            icon: "none"
        }) : wx.navigateTo({
            url: "/pages/file/pc?uuid=" + t
        });
    },
    adTypeChange: function(t) {
        var a = t.detail.value, e = {
            id: this.data.detail.id,
            adType: a - 1 + 2
        };
        this.updateAttach(e);
    },
    onShowAdChange: function(t) {
        var a = {
            id: this.data.detail.id,
            showAd: t.detail.value ? 0 : 1
        };
        this.updateAttach(a);
    },
    onStatusChange: function(t) {
        var a = {
            id: this.data.detail.id,
            status: t.detail.value ? 0 : 1
        };
        this.updateAttach(a);
    },
    onUrlDoneChange: function(t) {
        var a = {
            id: this.data.detail.id,
            urlDone: t.detail.value ? 0 : 1
        };
        this.updateAttach(a);
    },
    tempTimeChange: function(t) {
        var a = t.detail.value;
        this.setData({
            tempTime: a
        }), this.add2tempList(a);
    },
    add2tempList: function(a) {
        var e = this, i = this.data.detail.id;
        t.request({
            url: "/attachment/add/temp",
            data: {
                id: i,
                time: a
            },
            success: function(t) {
                wx.showToast({
                    title: t.data.msg,
                    icon: "none"
                }), e.loadTempTime();
            }
        });
    },
    downloadSetting: function() {
        var t = this, a = this.data.detail, e = a.status, i = 1 == e ? "禁止下载" : "允许下载";
        wx.showActionSheet({
            alertText: e ? "设为禁止下载后用户将无法下载文件" : null,
            itemList: [ i ],
            itemColor: e ? "#ec1f04" : "#00a51b",
            success: function(i) {
                1 == e ? wx.showModal({
                    confirmColor: "#ec1f04",
                    content: "禁止下载后用户将无法下载文件，您确定要继续吗？",
                    success: function(i) {
                        i.confirm && t.updateAttach({
                            id: a.id,
                            status: e ? 0 : 1
                        });
                    }
                }) : t.updateAttach({
                    id: a.id,
                    status: e ? 0 : 1
                });
            }
        });
    },
    copyText: function(t) {
        var a = t.currentTarget.dataset.text + "";
        wx.setClipboardData({
            data: a,
            success: function() {
                wx.showToast({
                    title: "文本已复制"
                });
            }
        });
    }
});