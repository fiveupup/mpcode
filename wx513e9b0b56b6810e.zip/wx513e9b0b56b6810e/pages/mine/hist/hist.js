var a = getApp();

require("../../../utils/common.js"), Page({
    data: {
        dataList: [],
        pageNo: 1,
        hasMore: !0,
        loading: !1,
        listType: 1
    },
    onLoad: function(t) {
        var e = t.ty || 1;
        this.setData({
            listType: e
        }), 2 == e && wx.setNavigationBarTitle({
            title: "我的浏览"
        }), this.loadHistRecord(1), a.initPrivacyAuth(this);
    },
    onShow: function() {},
    onPullDownRefresh: function() {
        this.setData({
            pageNo: 1,
            hasMore: !0
        }), this.loadHistRecord(1);
    },
    onReachBottom: function() {
        var a = this.data.pageNo;
        this.loadHistRecord(a);
    },
    loadHistRecord: function(t) {
        var e = this;
        if (e.data.hasMore && !e.data.loading) {
            e.setData({
                loading: !0
            });
            var o = 1 == e.data.listType ? "/attachment/upload/page" : "/attachment/view/page";
            a.request({
                url: o,
                data: {
                    pageNo: t,
                    pageSize: 20
                },
                success: function(a) {
                    var o = a.data.rows, i = e.data.dataList;
                    e.parseTime(o), 1 == t && (i = []);
                    for (var s = 0; s < o.length; s++) {
                        var r = o[s];
                        i.push(r);
                    }
                    e.setData({
                        dataList: i,
                        pageNo: t + 1,
                        loading: !1,
                        hasMore: 20 == o.length
                    }), wx.stopPullDownRefresh();
                }
            });
        } else wx.stopPullDownRefresh();
    },
    parseTime: function(a) {
        if (a && !(a.length < 1)) for (var t = 0; t < a.length; t++) {
            var e = a[t];
            e.timeStr = new Date(e.createTime).format("yyyy年MM月dd日 HH:mm");
        }
    }
});