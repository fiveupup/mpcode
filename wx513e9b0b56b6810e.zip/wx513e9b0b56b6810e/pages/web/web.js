Page({
    data: {
        url: ""
    },
    onLoad: function(t) {
        var e = t.url;
        this.setData({
            url: e
        }), this.getArticleTitle(e);
    },
    getArticleTitle: function(t) {
        wx.request({
            url: t,
            success: function(t) {
                var e = t.data.match(/<meta property="og:title" content="(.*)" \/>/)[1];
                wx.setNavigationBarTitle({
                    title: e
                });
            }
        });
    },
    onShow: function() {},
    onPullDownRefresh: function() {}
});