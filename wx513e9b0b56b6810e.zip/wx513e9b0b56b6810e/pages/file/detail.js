var t = getApp();

require("../../utils/common.js");

var e = null, a = null, i = "下载文件";

Page({
    data: {
        loginUser: {},
        uuid: "",
        detail: {},
        openFirst: 0,
        isMine: !1,
        edit: !1,
        suffix: "",
        tempName: "",
        focus: !1,
        progress: 0,
        filePath: "",
        showTips: !1,
        btnText: i,
        downloading: !1,
        setting: {},
        canvasW: 375,
        canvasH: 80,
        realWidth: 0,
        realHeight: 0,
        canvas: null,
        ctx: null,
        tempImgUrl: "",
        platform: "",
        isDevicePc: !1,
        confirm: !1,
        modalShow: !1,
        showCourse: !0,
        showMaterial: !1,
        showSetting: !1,
        cardImage: "https://img.iduodou.com/images/xcx/doc/card.jpg",
        stepList: [ "https://img.iduodou.com/images/xcx/doc/step00.jpg", "https://img.iduodou.com/images/xcx/doc/step01.jpg", "https://img.iduodou.com/images/xcx/doc/step02.jpg", "https://img.iduodou.com/images/xcx/doc/step03.jpg" ],
        sizeLimit: 60,
        qiniuUpToken: {},
        extension: [ "pdf", "txt", "zip", "rar", "xls", "xlsx", "doc", "docx", "ppt", "pptx" ],
        showVideoAd: !1,
        showScreenAd: !1,
        showRewardAd: !1,
        errorShow: !1,
        btmModalShow: !1,
        settingModalShow: !1
    },
    onLoad: function(e) {
        var a = e.uuid || "";
        t.storeShareUid(e), this.setData({
            uuid: a,
            openFirst: 1
        }), this.loadDetail(), this.initLoginUser(), this.getPlatform(), this.initSetting(), 
        this.initAd(), t.initPrivacyAuth(this);
    },
    onShow: function(t) {
        this.data.openFirst || this.data.detail.id || this.loadDetail(), this.setData({
            openFirst: 0
        });
    },
    initAd: function() {
        var t = this;
        wx.createInterstitialAd && ((a = wx.createInterstitialAd({
            adUnitId: "adunit-5c864bd211b05e7f"
        })).onLoad(function() {}), a.onError(function(t) {}), a.onClose(function() {})), 
        wx.createRewardedVideoAd && ((e = wx.createRewardedVideoAd({
            adUnitId: "adunit-c0146256c4847f2b"
        })).onLoad(function() {}), e.onError(function(t) {}), e.onClose(function(e) {
            e && e.isEnded || void 0 === e ? (t.downAttach(), wx.setStorage({
                key: "down_doc_times",
                data: new Date().format("yyyyMMdd")
            })) : wx.showToast({
                title: "您已取消",
                icon: "none"
            });
        }));
    },
    initSetting: function() {
        var e = this, a = t.globalData.setting;
        t.onSettingDone = function(t) {
            e.setData({
                setting: t
            });
        }, a && e.setData({
            setting: a
        });
    },
    getPlatform: function() {
        var t = this;
        wx.getSystemInfo({
            success: function(e) {
                var a = e.platform || "", i = "window" == a || "windows" == a || "mac" == a;
                t.setData({
                    platform: a,
                    isDevicePc: i
                });
            }
        });
    },
    isFileMine: function() {
        var t = this.data.detail, e = this.data.loginUser, a = !1;
        t.uid && t.uid == e.uid && (a = !0), this.setData({
            isMine: a
        });
    },
    initLoginUser: function() {
        var e = this, a = t.globalData.loginUser;
        a && a.uid && (e.setData({
            loginUser: a
        }), e.onViewDone(), e.isFileMine(), e.initAdSetting()), t.loginCallback = function(t) {
            e.setData({
                loginUser: t
            }), e.onViewDone(), e.isFileMine(), e.initAdSetting(), e.data.detail.id || e.loadDetail();
        };
    },
    onPullDownRefresh: function() {
        this.loadDetail();
    },
    toEditName: function() {
        var t = !this.data.edit, e = this.data.detail.name, a = e.lastIndexOf(".");
        if (a > 0) {
            var i = e.substring(0, a), o = e.substring(a);
            this.setData({
                tempName: i,
                suffix: o
            });
        } else this.setData({
            tempName: e
        });
        this.setData({
            edit: t,
            focus: !0
        });
    },
    nameInput: function(t) {
        var e = t.detail.value;
        this.setData({
            tempName: e
        });
    },
    onViewDone: function() {
        var e = this.data.uuid;
        t.post("/attachment/view/done", {
            uuid: e
        });
    },
    onDownDone: function() {
        var e = this.data.uuid;
        t.post("/attachment/down/done", {
            uuid: e
        });
    },
    viewImageCourse: function(t) {
        var e = t.currentTarget.dataset.index || 0, a = this.data.stepList, i = a[e];
        wx.previewImage({
            urls: a,
            current: i
        });
    },
    loadDetail: function() {
        var e = this, a = e.data.uuid;
        t.request({
            url: "/attachment/detail",
            data: {
                uuid: a
            },
            success: function(t) {
                var a = t.data.data;
                e.setData({
                    detail: a
                }), e.isFileMine(), e.initAdSetting();
                var o = a.openDirect;
                i = o ? "打开文件" : "下载文件", e.setData({
                    btnText: i
                });
            },
            complete: function() {
                wx.stopPullDownRefresh();
            }
        });
    },
    saveAttachment: function() {
        var e = this, a = e.data.detail, i = e.data.suffix, o = e.data.tempName;
        if (o) {
            e.setData({
                focus: !1
            });
            var n = {
                id: a.id,
                name: o + i
            };
            t.request({
                url: "/attachment/save",
                data: n,
                method: "post",
                success: function(t) {
                    e.loadDetail(), e.setData({
                        edit: !1
                    }), wx.showToast({
                        title: t.data.msg,
                        icon: t.data.code ? "" : "none"
                    });
                }
            });
        } else wx.showToast({
            title: "文件名称不能为空",
            icon: "none"
        });
    },
    cancelUpdate: function() {
        this.setData({
            edit: !1,
            focus: !1
        });
    },
    updateAttach: function(e) {
        var a = this;
        t.request({
            url: "/attachment/save",
            data: e,
            method: "post",
            success: function(t) {
                a.loadDetail(), wx.showToast({
                    title: t.data.msg,
                    icon: t.data.code ? "" : "none"
                });
            }
        });
    },
    beforeDown: function() {
        var t = this.data.detail;
        t.id || t.uid ? t.url && !t.del ? t.status ? this.viewVideoAd() && this.downAttach() : wx.showToast({
            title: "上传者已关闭下载",
            icon: "none"
        }) : wx.showToast({
            title: "文件已被上传者删除",
            icon: "none"
        }) : wx.showToast({
            title: "网络似乎不佳，切换网络重新打开试试吧",
            icon: "none"
        });
    },
    downAttach: function() {
        var e = this, a = e.data.uuid, o = e.data.detail;
        if (!e.data.downloading) {
            e.setData({
                downloading: !0
            });
            var n = o.name;
            n = e.replaceName(n);
            var s = o.urlDone, d = wx.env.USER_DATA_PATH + "/" + a + (s ? "_2" : "") + "/" + n;
            e.setData({
                filePath: d
            });
            var c = wx.getFileSystemManager();
            c.getFileInfo({
                filePath: d,
                success: function(t) {
                    e.saveAttachFile(d);
                },
                fail: function() {
                    var n = wx.env.USER_DATA_PATH + "/" + a + (s ? "_2" : "") + "/";
                    try {
                        c.mkdirSync(n, !0);
                    } catch (t) {}
                    wx.showLoading({
                        title: "正在下载"
                    }), wx.downloadFile({
                        url: o.url,
                        filePath: d,
                        success: function(t) {
                            wx.hideLoading();
                            var a = t.filePath;
                            e.saveAttachFile(a), e.onDownDone(), e.add2TempFileList(a);
                        },
                        fail: function(a) {
                            wx.hideLoading(), e.setData({
                                progress: 0,
                                btnText: i,
                                downloading: !1
                            }), e.setData({
                                errorShow: !0
                            }), t.errorLog("doc_down", JSON.stringify(a));
                        }
                    }).onProgressUpdate(function(t) {
                        wx.hideLoading();
                        var a = t.progress;
                        e.setData({
                            progress: a,
                            btnText: "已下载" + a + "%"
                        });
                    }), e.showScreenAd();
                }
            });
        }
    },
    showCourseModal: function() {
        this.setData({
            btmModalShow: !0
        }), wx.vibrateShort({
            type: "light"
        });
    },
    showSettingModal: function() {
        this.setData({
            settingModalShow: !0
        }), wx.vibrateShort({
            type: "light"
        });
    },
    replaceName: function(t) {
        for (;t.indexOf("/") >= 0; ) t = t.replace("/", "_");
        return t;
    },
    saveAttachFile: function(t) {
        var e = this;
        e.setData({
            downloading: !1,
            filePath: t
        });
        var a = e.data.platform;
        if ("window" == a || "windows" == a || "mac" == a) wx.saveFileToDisk({
            filePath: t,
            success: function(t) {
                wx.showToast({
                    title: "保存成功"
                });
            },
            fail: function(t) {
                wx.showToast({
                    title: "保存失败",
                    icon: "none"
                });
            }
        }); else {
            e.setData({
                showTips: !0
            });
            var o = e.data.detail;
            o.canOpen && o.openDirect && wx.openDocument && wx.openDocument({
                filePath: t,
                showMenu: !0
            });
        }
        setTimeout(function() {
            e.setData({
                progress: 0,
                btnText: i
            });
        }, 300);
    },
    openFile: function() {
        var t = this.data.filePath;
        wx.openDocument({
            filePath: t,
            showMenu: !0,
            success: function(t) {},
            fail: function(t) {
                wx.showModal({
                    title: "提示",
                    content: "文件打开失败，请添加到收藏查看"
                });
            }
        });
    },
    chooseSaveType: function() {
        var t = this;
        wx.showActionSheet({
            itemList: [ "分享给好友", "添加到收藏" ],
            success: function(e) {
                0 == e.tapIndex ? t.shareFile2Friend() : t.add2Favorite();
            }
        });
    },
    shareFile2Friend: function() {
        var t = this.data.filePath, e = this.data.detail;
        wx.shareFileMessage ? wx.shareFileMessage({
            filePath: t,
            fileName: e.name
        }) : wx.showModal({
            showCancel: !1,
            content: "您的微信版本过低，不支持分享文件，建议您使用其他人手机下载"
        });
    },
    add2Favorite: function() {
        var t = this.data.filePath, e = this.data.detail.name;
        wx.addFileToFavorites ? wx.addFileToFavorites({
            filePath: t,
            fileName: e,
            success: function(t) {
                wx.showToast({
                    title: "已添加到收藏"
                });
            }
        }) : wx.showModal({
            showCancel: !1,
            content: "您的微信版本过低，不支持收藏文件，建议您使用其他人手机下载"
        });
    },
    add2TempFileList: function(t) {
        var e = "save_file_path_list", a = wx.getStorageSync(e);
        (a = a || []).push(t), wx.setStorage({
            key: e,
            data: a
        });
    },
    closeModal: function() {
        this.setData({
            showTips: !1,
            errorShow: !1,
            btmModalShow: !1,
            settingModalShow: !1
        });
    },
    copyPath: function() {
        var t = "pages/file/detail?uuid=" + this.data.uuid + "&sid=" + (this.data.loginUser.uid || 0);
        wx.setClipboardData({
            data: t,
            success: function() {
                wx.showToast({
                    title: "内容已复制"
                });
            }
        });
    },
    gotoWeb: function() {
        wx.navigateTo({
            url: "/pages/web/web"
        });
    },
    getUserInfo: function(e) {
        var a = this, i = a.data.loginUser;
        return !!(!i.uid || i.avatar && i.nick) || (!wx.getUserProfile || (wx.getUserProfile({
            desc: "用于完善会员资料",
            success: function(i) {
                var o = i.userInfo, n = t.globalData.loginUser;
                n.nick = o.nickName, n.avatar = o.avatarUrl, t.globalData.loginUser = n, a.setData({
                    loginUser: n
                }), e && e(), t.saveUserInfo(o, i.encryptedData, i.iv);
            }
        }), !1));
    },
    copyTitle: function() {
        var t = this.data.detail.name;
        wx.setClipboardData({
            data: t,
            success: function() {
                wx.showToast({
                    title: "复制成功"
                });
            }
        });
    },
    closeTips: function() {
        this.setData({
            modalShow: !1
        });
    },
    moreBtnTap: function() {
        var t = this.data.uuid;
        wx.navigateTo({
            url: "/pages/mine/admin/item?uuid=" + t
        });
    },
    confirmDelete: function() {
        this.setData({
            modalShow: !0,
            settingModalShow: !1,
            confirm: !1
        }), wx.vibrateShort({
            type: "heavy"
        });
    },
    checkboxChange: function(t) {
        1 == t.detail.value.length ? this.setData({
            confirm: !0
        }) : this.setData({
            confirm: !1
        });
    },
    doDeleteAttach: function() {
        var e = this;
        if (this.data.confirm) {
            var a = e.data.detail;
            t.post("/attachment/delete", {
                id: a.id
            }, function(t) {
                var a = t.data;
                e.setData({
                    modalShow: !1
                }), wx.showToast({
                    title: a.msg,
                    icon: 1 == a.code ? null : "none"
                }), 1 == a.code && setTimeout(function() {
                    wx.navigateBack();
                }, 800);
            });
        } else wx.showToast({
            title: "请勾选确认继续删除",
            icon: "none"
        });
    },
    gotoHome: function() {
        wx.switchTab({
            url: "/pages/index/index"
        });
    },
    gotoPcDown: function() {
        var t = this.data.uuid;
        this.data.isDevicePc ? wx.showToast({
            title: '请点击"下载文件"按钮进行下载',
            icon: "none"
        }) : wx.navigateTo({
            url: "/pages/file/pc?uuid=" + t
        });
    },
    gotoFaq: function() {
        wx.navigateTo({
            url: "/pages/faq/faq"
        });
    },
    viewCourse: function() {
        var t = !this.data.showCourse;
        this.setData({
            showCourse: t
        });
    },
    viewMaterial: function() {
        var t = !this.data.showMaterial;
        this.setData({
            showMaterial: t
        });
    },
    viewSetting: function() {
        var t = !this.data.showSetting;
        this.setData({
            showSetting: t
        });
    },
    downloadSetting: function() {
        var t = this, e = this.data.detail, a = e.status, i = 1 == a ? "禁止下载" : "允许下载";
        wx.showActionSheet({
            alertText: a ? "设为禁止下载后用户将无法下载文件" : null,
            itemList: [ i ],
            itemColor: a ? "#ec1f04" : "#00a51b",
            success: function(i) {
                1 == a ? wx.showModal({
                    confirmColor: "#ec1f04",
                    content: "禁止下载后用户将无法下载文件，您确定要继续吗？",
                    success: function(i) {
                        i.confirm && t.updateAttach({
                            id: e.id,
                            status: a ? 0 : 1
                        });
                    }
                }) : t.updateAttach({
                    id: e.id,
                    status: a ? 0 : 1
                });
            }
        });
    },
    openDirectChange: function(t) {
        var e = this, a = t.detail.value ? 1 : 0, i = this.data.detail;
        1 == a ? wx.showModal({
            content: "文件下载完成后，将自动跳转文件预览页，您确定要继续吗？",
            success: function(t) {
                t.confirm ? e.updateAttach({
                    id: i.id,
                    openDirect: a
                }) : e.loadDetail();
            }
        }) : e.updateAttach({
            id: i.id,
            openDirect: a
        });
    },
    exchangeFile: function() {
        var e = this, a = this.data.detail;
        a.urlDone ? wx.showToast({
            title: "文件只支持替换一次",
            icon: "none"
        }) : (e.loadQiNiuToken(), wx.showModal({
            content: "文件只能替换一次，替换后文件名称将变更为新文件的名字哦",
            confirmText: "我知道了",
            success: function(i) {
                if (i.confirm) {
                    var o = e.data.extension, n = e.data.setting.suffixes || o;
                    wx.chooseMessageFile({
                        count: 1,
                        type: "file",
                        extension: n,
                        success: function(i) {
                            var o = e.data.qiniuUpToken, n = i.tempFiles[0], s = n.path, d = n.name, c = n.size, r = e.data.sizeLimit;
                            if (!c > 1024 * r * 1024) {
                                var l = "您选择的文件大小已超过限制(单个文件不能超过" + r + "M)，无法上传";
                                wx.showModal({
                                    content: l
                                });
                            } else {
                                var u = {
                                    id: a.id,
                                    name: d,
                                    sizes: c
                                }, h = d.lastIndexOf("."), w = h > 0 ? d.substring(h) : "", f = e.generateUUID().toUpperCase(), x = new Date().format("yyyyMMdd"), g = {
                                    token: o.token,
                                    key: "images/docs/" + x + "/" + f + w
                                };
                                wx.uploadFile({
                                    url: t.globalData.upDomain,
                                    filePath: s,
                                    name: "file",
                                    formData: g,
                                    success: function(t) {
                                        var a = t.data, i = JSON.parse(a), n = o.accessUrl, s = (n = n.endsWith("/") ? n : n + "/") + i.key;
                                        u.url = s, e.updateAttach(u);
                                    },
                                    fail: function(t) {
                                        wx.hideLoading(), wx.showToast({
                                            title: "文件上传失败，请重新上传",
                                            icon: "none"
                                        }), e.loadQiNiuToken();
                                    }
                                }).onProgressUpdate(function(t) {
                                    var e = t.progress;
                                    wx.showLoading({
                                        title: "已上传" + e + "%"
                                    });
                                });
                            }
                        }
                    });
                }
            }
        }));
    },
    loadQiNiuToken: function() {
        var e = this;
        t.request({
            url: "/upload/token",
            success: function(t) {
                e.setData({
                    qiniuUpToken: t.data
                });
            }
        });
    },
    generateUUID: function() {
        var t = new Date().getTime();
        return "xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx".replace(/[xy]/g, function(e) {
            var a = (t + 16 * Math.random()) % 16 | 0;
            return t = Math.floor(t / 16), ("x" == e ? a : 3 & a | 8).toString(16);
        });
    },
    onShareInfo: function() {
        var t = this.data.loginUser.uid || 0, e = this.data.detail.name || "微件助手-您的实用工具箱", a = "uuid=" + this.data.uuid + "&sid=" + t;
        return {
            title: e,
            path: "/pages/file/detail?" + a,
            query: a
        };
    },
    onShareAppMessage: function() {
        return this.onShareInfo();
    },
    onShareTimeline: function() {
        return this.onShareInfo();
    },
    initAdSetting: function() {
        var t = this.data.detail, e = this.data.loginUser;
        if (t && e && t.id && e.uid) {
            var a = t.uid == e.uid, i = t.showAd, o = e.docVip, n = e.inviterUid || 0, s = t.showVideoAd, d = t.showScreenAd, c = t.showRewardAd;
            !a && !o && i && n && this.setData({
                showVideoAd: s,
                showScreenAd: d,
                showRewardAd: c
            });
        }
    },
    viewVideoAd: function() {
        var t = this;
        if (!this.data.showRewardAd) return !0;
        var a = wx.getStorageSync("down_doc_times"), i = new Date().format("yyyyMMdd");
        return !(!a || a != i) || (!e || !e.isReady() || (wx.showModal({
            title: "提示",
            content: "大文件下载是高级功能，请观看视频解锁下载",
            success: function(a) {
                a.confirm ? e.show().catch(function() {
                    e.load().then(function() {
                        return e.show();
                    }).catch(function(e) {
                        t.downAttach();
                    });
                }) : a.cancel && wx.showToast({
                    title: "取消下载",
                    icon: "none"
                });
            },
            fail: function() {
                t.downAttach();
            }
        }), !1));
    },
    showScreenAd: function() {
        var t = this.data.showScreenAd;
        if (t && a) {
            var e = wx.getStorageSync("down_screen_times"), i = new Date().format("yyyyMMdd");
            a.show().catch(function(t) {
                console.error(t);
            });
            var o = e && e.date == i && e.time ? e.time : 0;
            wx.setStorage({
                key: "down_screen_times",
                data: {
                    time: o + 1,
                    date: i
                }
            });
        }
    },
    clearSavedFiles: function() {
        wx.showLoading({
            title: "清除中"
        });
        var t = wx.getStorageSync("save_file_path_list");
        if (t) for (var e = wx.getFileSystemManager(), a = 0; a < t.length; a++) {
            var i = t[a];
            e.unlink({
                filePath: i
            });
        }
        wx.hideLoading(), wx.showModal({
            content: "缓存已清除，重新下载试试吧",
            showCancel: !1,
            confirmText: "我知道了"
        });
    },
    copyFileUrl: function() {
        var t = this.data.detail.url;
        wx.setClipboardData({
            data: t,
            success: function() {
                wx.showToast({
                    title: "链接复制成功"
                });
            }
        });
    }
});