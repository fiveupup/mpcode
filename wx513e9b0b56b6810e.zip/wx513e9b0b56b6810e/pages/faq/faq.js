var t = getApp();

Page({
    data: {},
    onLoad: function(i) {
        t.initPrivacyAuth(this);
    },
    onShow: function() {}
});