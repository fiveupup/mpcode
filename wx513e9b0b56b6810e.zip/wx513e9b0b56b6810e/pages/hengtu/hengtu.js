var e = require("../../@babel/runtime/helpers/defineProperty"), t = getApp(), a = wx.getSystemInfoSync(), i = a.windowWidth, n = a.windowHeight, s = i, o = 750 / a.windowWidth, c = a.statusBarHeight * o, g = 44 * o, u = n * o, r = a.screenHeight * o, h = null;

Page({
    data: {
        loginUser: {},
        plusImage: "../../image/index/plus.png",
        selectImgIndex: -1,
        selectIconPic: null,
        canvasWidth: s,
        canvasHeight: n,
        windowHeight: u,
        tabBarHeight: r - c - g - u,
        images: [ {
            def: !0
        }, {
            def: !0
        } ],
        withLine: !1
    },
    onLoad: function(e) {
        this.getConfig(), this.initUserInfo(), this.initAd(), t.initPrivacyAuth(this);
    },
    initUserInfo: function() {
        var e = this, a = t.globalData.loginUser;
        a && (this.setData({
            loginUser: a
        }), e.getSetting()), t.onLoginDone = function(t) {
            e.setData({
                loginUser: t
            }), e.getSetting();
        };
    },
    initAd: function() {
        var e = this;
        wx.createRewardedVideoAd && ((h = wx.createRewardedVideoAd({
            adUnitId: "adunit-3d52c28ea06f3663"
        })).onLoad(function() {}), h.onError(function(e) {}), h.onClose(function(t) {
            t && t.isEnded || void 0 === t ? e.saveImage2Album() : wx.showToast({
                title: "取消下载",
                icon: "none"
            });
        }));
    },
    withBorderLine: function() {
        var e = !this.data.withLine;
        this.setData({
            withLine: e
        });
    },
    getConfig: function() {
        t.request({
            url: "/config/vs",
            success: function(e) {
                var a = e.data.data;
                a && 0 == a.status && (t.globalData.isImageCheck = !0);
            }
        });
    },
    getSetting: function() {
        t.request({
            url: "/pintu/setting",
            success: function(e) {
                var a = e.data.data;
                a && !1 === a.check && (t.globalData.isImageCheck = !1);
            }
        });
    },
    onShow: function(t) {
        var a = this.data.selectImgIndex, i = this.data.selectIconPic;
        if (a > -1 && i) {
            var n, s = "images[" + a + "].src", o = "images[" + a + "].def";
            this.setData((e(n = {}, s, this.data.selectIconPic), e(n, o, !1), n)), this.setData({
                selectImgIndex: -1,
                selectIconPic: null
            });
        }
        wx.setStorage({
            key: "temp_data_images",
            data: null
        });
    },
    gotoShutu: function() {
        var e = this.data.images;
        wx.setStorage({
            key: "temp_data_images",
            data: e,
            success: function() {
                wx.navigateTo({
                    url: "/pages/shutu/shutu"
                });
            }
        });
    },
    gotoSitu: function(e) {
        var t = this.data.images;
        wx.setStorage({
            key: "temp_data_images",
            data: t,
            success: function() {
                wx.navigateTo({
                    url: "/pages/situ/situ"
                });
            }
        });
    },
    gotoJiutu: function(e) {
        var t = this.data.images;
        wx.setStorage({
            key: "temp_data_images",
            data: t,
            success: function() {
                wx.navigateTo({
                    url: "/pages/jiutu/jiutu"
                });
            }
        });
    },
    onOneKeyUploadTap: function(e) {
        var a = this, i = e.currentTarget.id;
        wx.chooseImage({
            count: 9,
            sizeType: [ "original", "compressed" ],
            sourceType: [ "album" ],
            success: function(e) {
                var n = e.tempFilePaths;
                if (n && n.length > 0) {
                    var s = a.data.images, o = [];
                    "onekey" != i && s.forEach(function(e) {
                        e.def || o.push(e);
                    }), n.forEach(function(e) {
                        o.push({
                            src: e,
                            def: !1
                        });
                    }), o.push({
                        def: !0
                    }), a.setData({
                        images: o
                    }), a.initImagesSize(), t.loadAccessToken();
                }
            }
        });
    },
    onImageExistsTap: function(a) {
        var i = this, n = parseInt(a.currentTarget.id);
        wx.showActionSheet({
            itemList: [ "移除图片", "更换图片" ],
            success: function(a) {
                if (0 == a.tapIndex) {
                    for (var s = i.data.images, o = [], c = 0; c < s.length; c++) {
                        var g = s[c];
                        c != n && o.push(g);
                    }
                    1 == o.length && o.push({
                        def: !0
                    }), i.setData({
                        images: o
                    }), wx.showToast({
                        title: "已移除",
                        icon: "none"
                    });
                } else 1 == a.tapIndex && wx.showActionSheet({
                    itemList: [ "相册中选取", "用手机拍照", "聊天中选取" ],
                    success: function(a) {
                        0 == a.tapIndex ? wx.chooseImage({
                            count: 1,
                            sizeType: [ "original", "compressed" ],
                            sourceType: [ "album" ],
                            success: function(t) {
                                var a = {
                                    def: !1,
                                    src: t.tempFilePaths[0]
                                };
                                i.setData(e({}, "images[" + n + "]", a)), i.initImagesSize();
                            }
                        }) : 1 == a.tapIndex ? wx.chooseImage({
                            count: 1,
                            sizeType: [ "original", "compressed" ],
                            sourceType: [ "camera" ],
                            success: function(a) {
                                var s = {
                                    def: !1,
                                    src: a.tempFilePaths[0]
                                };
                                i.setData(e({}, "images[" + n + "]", s)), i.initImagesSize(), t.loadAccessToken();
                            }
                        }) : wx.chooseMessageFile({
                            count: 1,
                            type: "image",
                            success: function(t) {
                                var a = {
                                    def: !1,
                                    src: t.tempFiles[0].path
                                };
                                i.setData(e({}, "images[" + n + "]", a)), i.initImagesSize();
                            }
                        });
                    }
                });
            }
        });
    },
    initImagesSize: function() {
        for (var e = this.data.images, t = 0; t < e.length; t++) {
            var a = e[t];
            a.def || !a.src || a.width || this.initImageItemSize(t, a);
        }
    },
    initImageItemSize: function(t, a) {
        var i = this;
        wx.getImageInfo({
            src: a.src,
            success: function(n) {
                a.width = n.width, a.height = n.height;
                var s = "images[" + t + "]";
                i.setData(e({}, s, a));
            }
        });
    },
    getCropperImage: function() {
        var e = wx.getStorageSync("down_image_times");
        if (e) {
            var t = this.getDateStr();
            if (e.time == t && 1 == e.count) return void this.showVideoAd();
        }
        this.saveImage2Album();
    },
    showVideoAd: function() {
        var e = this;
        h && h.isReady() ? wx.showModal({
            title: "提示",
            content: "观看一次视频，解锁今日下载权限",
            success: function(t) {
                t.confirm ? h.show().catch(function() {
                    h.load().then(function() {
                        return h.show();
                    }).catch(function(t) {
                        e.saveImage2Album();
                    });
                }) : t.cancel && wx.showToast({
                    title: "取消保存",
                    icon: "none"
                });
            },
            fail: function() {
                e.saveImage2Album();
            }
        }) : e.saveImage2Album();
    },
    saveImage2Album: function(e) {
        var a = this, i = this.data.images, n = !1;
        if (i.forEach(function(e) {
            e.def || (n = !0);
        }), !n) return wx.hideLoading(), void wx.showModal({
            title: "温馨提示",
            content: "没有可生成的图片"
        });
        wx.showLoading({
            title: "正在合成图片"
        });
        for (var s = [], o = a.data.canvasHeight, c = 0, g = a.data.withLine, u = 0; u < i.length; u++) {
            if (!(m = i[u]).def) {
                var r = m.width, h = m.height, d = parseInt(r / (h / o)), f = {
                    src: m.src,
                    x: c,
                    y: 0,
                    width: d,
                    height: o
                };
                s.push(f), c += d;
            }
        }
        g && (c += 8 * (s.length + 1), o += 16), a.setData({
            canvasWidth: c,
            canvasHeight: o
        });
        var l = wx.createCanvasContext("imageCanvas");
        l.fillStyle = g ? "#dedede" : "#ffffff", l.fillRect(0, 0, c, o);
        for (u = 0; u < s.length; u++) {
            var m = s[u];
            g ? l.drawImage(m.src, m.x + 8 * (u + 1), m.y + 8, m.width, m.height) : l.drawImage(m.src, m.x, m.y, m.width, m.height);
        }
        l.draw(!1, function(i) {
            setTimeout(function() {
                wx.canvasToTempFilePath({
                    canvasId: "imageCanvas",
                    x: 0,
                    y: 0,
                    fileType: "jpg",
                    width: c,
                    height: o,
                    success: function(i) {
                        var n = i.tempFilePath, s = t.globalData.isImageCheck;
                        null != e && "undefined" != e || !s ? wx.getSetting({
                            success: function(e) {
                                if (!1 === e.authSetting["scope.writePhotosAlbum"]) return wx.hideLoading(), void wx.showModal({
                                    title: "授权提醒",
                                    content: "您需要授权保存图片到相册才能保存",
                                    confirmText: "去授权",
                                    confirmColor: "#f3513c",
                                    success: function(e) {
                                        e.confirm && wx.openSetting({});
                                    }
                                });
                                wx.saveImageToPhotosAlbum({
                                    filePath: n,
                                    success: function() {
                                        wx.hideLoading(), wx.showToast({
                                            title: "图片已保存"
                                        });
                                        var e = "down_image_times", t = wx.getStorageSync(e), i = t && t.count ? t.count : 0, n = {
                                            time: a.getDateStr(),
                                            count: i + 1
                                        };
                                        wx.setStorage({
                                            key: e,
                                            data: n
                                        });
                                    },
                                    fail: function() {
                                        wx.hideLoading();
                                    }
                                });
                            }
                        }) : t.imgSecurityCheck(n, a.saveImage2Album);
                    },
                    fail: function() {
                        wx.hideLoading();
                    }
                });
            }, 300);
        });
    },
    getDateStr: function() {
        var e = new Date(), t = e.getMonth() + 1;
        t = t > 9 ? t : "0" + t;
        var a = e.getDate();
        return a = a > 9 ? a : "0" + a, e.getFullYear() + "-" + t + "-" + a;
    }
});