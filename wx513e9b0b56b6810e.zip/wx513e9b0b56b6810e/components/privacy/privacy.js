getApp();

Component({
    lifetimes: {
        attached: function() {
            this.getSystemInfo();
        },
        detached: function() {}
    },
    attached: function() {
        this.getSystemInfo();
    },
    detached: function() {},
    observers: {},
    properties: {
        name: {
            type: String,
            value: "微件助手"
        }
    },
    data: {
        showToolbar: !1,
        animationData: {},
        privacyName: "隐私保护指引",
        bottomHeight: 0
    },
    pageLifetimes: {
        show: function() {}
    },
    methods: {
        gotoPrivacy: function() {
            wx.openPrivacyContract();
        },
        onAgreePrivacyAuth: function() {
            this.hideModal();
        },
        onRefusePrivacyAuth: function() {
            wx.showToast({
                title: "您已拒绝我们的隐私协议，部分功能将不可用",
                icon: "none"
            }), this.hideModal();
        },
        showModal: function(t) {
            wx.hideTabBar();
            var a = this;
            wx.getPrivacySetting({
                success: function(t) {
                    var i = t.privacyContractName;
                    a.setData({
                        privacyName: i
                    });
                }
            });
            var i = wx.createAnimation({
                duration: 200,
                timingFunction: "ease",
                delay: 0
            });
            this.animation = i, i.translateY("100%").step(), this.setData({
                animationData: i.export(),
                showToolbar: !0
            }), setTimeout(function() {
                i.translateY(0).step(), this.setData({
                    animationData: i.export()
                });
            }.bind(this), 10);
        },
        hideModal: function() {
            var t = wx.createAnimation({
                duration: 200,
                timingFunction: "linear",
                delay: 0
            });
            this.animation = t, t.translateY("100%").step(), this.setData({
                animationData: t.export()
            }), setTimeout(function() {
                t.translateY(0).step(), this.setData({
                    animationData: t.export(),
                    showToolbar: !1
                });
            }.bind(this), 100), wx.showTabBar({
                animation: !0,
                fail: function() {
                    console.log("is not tabbar page");
                }
            });
        },
        getSystemInfo: function() {
            var t = this;
            wx.getSystemInfo({
                success: function(a) {
                    var i = 750 * (a.screenHeight - a.safeArea.bottom) / a.windowWidth;
                    t.setData({
                        bottomHeight: i
                    });
                }
            });
        }
    }
});