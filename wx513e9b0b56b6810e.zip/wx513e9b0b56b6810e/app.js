App({
    globalData: {
        loginUser: {},
        domain: "https://api.iduodou.com",
        backup: "https://api.here325.com",
        upDomain: "https://up-z1.qbox.me",
        dlDomain: "https://img.iduodou.com",
        app: "zdoc",
        version: 100,
        loginLocked: !1,
        shareUid: 0,
        optionOk: !1,
        setting: null,
        domainOk: !1,
        systemInfo: {},
        launchScene: 0,
        isImageCheck: !0,
        baiduAccessToken: {}
    },
    onLaunch: function(a) {
        this.storeLaunchScene(a), this.checkSession(), this.loadSetting(), this.testDomain(), 
        this.onAppUpdate(), this.getSystemInfo();
    },
    checkSession: function() {
        var a = this;
        wx.checkSession({
            success: function(t) {
                var e = a.globalData.loginUser, i = wx.getStorageSync("login_user_data");
                if (!(e && e.uid && i && i.sid)) {
                    var o = a.globalData.shareUid || 0;
                    a.login(o);
                }
                a.loadAccessToken();
            },
            fail: function(t) {
                var e = a.globalData.shareUid || 0;
                a.login(e);
            }
        });
    },
    login: function(a) {
        var t = this;
        t.globalData.loginLocked = !0, wx.login({
            success: function(e) {
                if (e.code) {
                    var i = t.globalData.launchScene;
                    t.request({
                        url: "/user/login",
                        data: {
                            code: e.code,
                            fromUid: a,
                            scene: i
                        },
                        success: function(a) {
                            var e = a.data;
                            if (1 == e.code) {
                                var i = e.data;
                                t.globalData.loginUser = i;
                                var o = {
                                    sid: e.data.sessionid,
                                    uid: e.data.uid
                                };
                                wx.setStorageSync("login_user_data", o), t.loginCallback && t.loginCallback(i);
                            }
                            t.loadAccessToken();
                        },
                        fail: function() {
                            t.globalData.loginLocked = !1;
                        },
                        complete: function() {
                            wx.hideLoading(), t.globalData.loginLocked = !1;
                        }
                    });
                } else wx.hideLoading();
            },
            fail: function() {
                wx.hideLoading();
            }
        });
    },
    saveUserInfo: function(a, t, e) {
        var i = {};
        for (var o in a) i[o] = a[o];
        i.avatar = i.avatarUrl, i.nick = i.nickName, delete i.avatarUrl, delete i.nickName, 
        i.encryptData = t, i.iv = e, this.post("/user/save", i);
    },
    storeLaunchScene: function(a) {
        a && (this.globalData.launchScene = a.scene || 0);
    },
    storeShareUid: function(a) {
        if (a) {
            var t = a.sid || a.shareUid || "0", e = this.getScene(a);
            "0" == t && e.uid && (t = e.uid), this.globalData.shareUid = t;
        }
    },
    getScene: function(a) {
        var t = {};
        if (a.scene) for (var e = decodeURIComponent(a.scene).split("&"), i = 0; i < e.length; i++) {
            var o = e[i].split("=");
            t[o[0]] = o.length > 1 ? o[1] : "";
        }
        return t;
    },
    request: function(a) {
        var t = this;
        a.url.startsWith("http") || (a.url = this.globalData.domain + a.url);
        var e = {}, i = this.globalData.loginUser;
        if (i.sessionid) e = {
            sessionid: i.sessionid,
            uid: i.uid
        }; else {
            var o = wx.getStorageSync("login_user_data");
            o && (e = {
                sessionid: o.sid,
                uid: o.uid
            });
        }
        e["content-type"] = "application/x-www-form-urlencoded", a.header = e;
        var n = a.complete, s = t.globalData.shareUid, c = "function" == typeof n ? function(a) {
            n(a), a.data && 488 == a.data.code && !t.globalData.loginLocked && (wx.showLoading({
                title: "登录中"
            }), t.login(s));
        } : function(a) {
            a.data && 488 == a.data.code && !t.globalData.loginLocked && (wx.showLoading({
                title: "登录中"
            }), t.login(s));
        };
        a.complete = c, a.data = a.data || {}, a.data.version = t.globalData.version, a.data.app = t.globalData.app;
        var l = t.globalData.systemInfo;
        a.data.md_ = l.model || "", a.data.pf_ = l.platform || "", wx.request(a);
    },
    post: function(a, t, e, i) {
        a.startsWith("http") || (a = this.globalData.domain + a), t.version = this.globalData.version, 
        this.request({
            url: a,
            data: t,
            method: "POST",
            success: e,
            fail: i
        });
    },
    loadSetting: function() {
        var a = this;
        a.request({
            url: "/attachment/setting",
            success: function(t) {
                var e = t.data.data;
                a.globalData.setting = e, a.onSettingDone && a.onSettingDone(e);
            }
        });
    },
    onAppUpdate: function() {
        if (wx.canIUse("getUpdateManager")) {
            var a = wx.getUpdateManager();
            a.onCheckForUpdate(function(t) {
                t.hasUpdate && (a.onUpdateReady(function() {
                    wx.showModal({
                        title: "更新提示",
                        content: "新版本已经准备好，是否重启应用？",
                        success: function(t) {
                            t.confirm && a.applyUpdate();
                        }
                    });
                }), a.onUpdateFailed(function() {
                    wx.showModal({
                        title: "已经有新版本了哟~",
                        content: "新版本已经上线啦~，请您删除当前小程序，重新搜索打开哟~"
                    });
                }));
            });
        }
    },
    errorLog: function(a, t) {
        this.post("/error/log/report", {
            tag: a,
            log: t
        });
    },
    testDomain: function() {
        var a = this, t = this.globalData.domain, e = this.globalData.backup;
        wx.request({
            url: t + "/tik/tok",
            timeout: 5e3,
            data: {
                v: "iduodou"
            },
            success: function(t) {
                "1" == t.data && (a.globalData.domainOk = !0);
            }
        }), setTimeout(function() {
            var t = a.globalData.domainOk;
            t || wx.request({
                url: e + "/tik/tok",
                timeout: 5e3,
                data: {
                    v: "here325"
                },
                success: function(i) {
                    if ("1" == i.data && !(t = a.globalData.domainOk)) {
                        a.globalData.domain = e;
                        var o = a.globalData.shareUid || 0;
                        a.login(o);
                    }
                }
            });
        }, 1e3);
    },
    getSystemInfo: function() {
        var a = this;
        wx.getSystemInfo({
            success: function(t) {
                a.globalData.systemInfo = t;
            }
        });
    },
    onPageNotFound: function(a) {
        var t = a.path, e = a.query;
        t.indexOf("pages/file/detail") > 0 && e.uuid ? wx.redirectTo({
            url: "pages/file/detail?uuid=" + e.uuid + "&sid=" + (e.sid || 0)
        }) : t.indexOf("pages/file/list") > 0 && e.uuid ? wx.redirectTo({
            url: "pages/file/list?uuid=" + e.uuid + "&sid=" + (e.sid || 0)
        }) : wx.switchTab({
            url: "pages/index/index"
        });
    },
    loadAccessToken: function() {
        var a = this;
        this.request({
            url: "/config/baidu/acc/token",
            success: function(t) {
                var e = t.data.data;
                a.globalData.baiduAccessToken = e;
            }
        });
    },
    imgSecurityCheck: function(a, t) {
        if (a) {
            var e = this;
            wx.getImageInfo({
                src: a,
                success: function(i) {
                    i.type;
                    var o = i.width, n = i.height, s = o / 1e3, c = n / 1e3;
                    if (o > 1e3 || n > 1e3) {
                        var l = 1e3, d = 1e3;
                        s > c ? d = n / s : l = o / c;
                        var r = wx.createCanvasContext("canvasForCut", this);
                        r.drawImage(a, 0, 0, l, d), r.draw(!1, function() {
                            wx.canvasToTempFilePath({
                                canvasId: "canvasForCut",
                                x: 0,
                                y: 0,
                                width: l,
                                height: d,
                                destWidth: l,
                                destHeight: d,
                                quality: .5,
                                fileType: "png",
                                success: function(a) {
                                    e.imgCloudCheck(a.tempFilePath, t);
                                },
                                fail: function(i) {
                                    e.imgCloudCheck(a, t);
                                }
                            }, this);
                        });
                    } else e.imgCloudCheck(a, t);
                }
            });
        } else t(!0);
    },
    imgCloudCheck: function(a, t) {
        var e = this.globalData.baiduAccessToken;
        if (!e) return t(!0), void this.loadAccessToken();
        var i = wx.getFileSystemManager().readFileSync(a, "base64");
        wx.request({
            url: "https://aip.baidubce.com/rest/2.0/solution/v1/img_censor/v2/user_defined?access_token=" + e,
            data: {
                image: i,
                imgType: 0
            },
            header: {
                "Content-Type": "application/x-www-form-urlencoded"
            },
            method: "POST",
            success: function(a) {
                var e = a.data.conclusionType;
                if (2 == e || 3 == e) return wx.showModal({
                    title: "温馨提示",
                    content: "经微信检测，您的图片包含敏感内容，无法保存"
                }), void wx.hideLoading();
                t(!0);
            },
            fail: function(a) {
                wx.hideLoading(), wx.showModal({
                    title: "温馨提示",
                    content: "保存失败，请重试"
                });
            }
        });
    },
    initPrivacyAuth: function(a, t) {
        wx.onNeedPrivacyAuthorization && wx.onNeedPrivacyAuthorization(function(t) {
            a.selectComponent("#privacy").showModal(), a.resolvePrivacyAuthorization = t;
        }), wx.getPrivacySetting && t && wx.getPrivacySetting({
            success: function(a) {
                a.needAuthorization && wx.requirePrivacyAuthorize();
            }
        });
    }
});