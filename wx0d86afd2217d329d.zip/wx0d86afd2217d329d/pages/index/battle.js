var t = getApp();

Page({
    data: {
        alone_index: 0,
        question_index: 0,
        count_down: 15e3,
        count_start: !1,
        mate_percentage: 50
    },
    onLoad: function() {
        var a = this;
        this.setData({
            statusBarHeight: wx.getSystemInfoSync().statusBarHeight,
            img_url: t.globalData.img_url
        }), this.filter(function() {
            a.setData({
                player: t.globalData.player
            }), t.globalData.player.dailyBattles < 3 ? a.param() : wx.showModal({
                content: "您已达到今日竞答次数上限！",
                showCancel: !1,
                success: function(t) {
                    t.confirm && wx.switchTab({
                        url: "index"
                    });
                }
            });
        });
    },
    filter: function(a) {
        var e = this;
        t.globalData.player = !1, t.globalData.maUser ? this.MATCH_STATUS(a) : t.land().then(function() {
            e.MATCH_STATUS(a);
        });
    },
    MATCH_STATUS: function(a) {
        t.request({}, "/weixin/param/MATCH_STATUS", !1, !1).then(function(e) {
            "ON" == e.data.paramValue ? t.player(!0).then(function() {
                a();
            }) : wx.showModal({
                content: e.data.comment,
                showCancel: !1,
                success: function(t) {
                    t.confirm && wx.switchTab({
                        url: "index"
                    });
                }
            });
        });
    },
    param: function(a) {
        var e = this;
        t.request({}, "/weixin/param/MATCH_TIME").then(function(t) {
            e.setData({
                param: t.data
            });
        });
    },
    match: function(a) {
        var e = this;
        t.request({
            roundType: 2
        }, "/weixin/battle/match").then(function(t) {
            e.bind_round(t.data), e.mate_success();
        }).catch(function() {
            e.mate_ban();
        });
    },
    bind_round: function(a) {
        var e;
        a.questions.forEach(function(t) {
            t.content = "(" + (1 == t.questionType ? "单选题" : "多选题") + ")" + t.content, t.next = !1, 
            t.answers.forEach(function(t, a) {
                t.answer_index = [ "A", "B", "C", "D" ][a], t.select = !1;
            });
        }), a.teams.forEach(function(a, n) {
            a.players.forEach(function(a) {
                if (0 == n && (e = a.division), 1 == n) {
                    a.division = e;
                    var i = a.nickname.length;
                    a.nickname = i > 1 ? a.nickname.substring(0, 1) + "**" + a.nickname.substring(i - 1, i) : 1 == i ? a.nickname + "**" : "**";
                }
                (a = t.bind_player(a)).score = 0, a.records.forEach(function(t) {
                    t.end = !1;
                });
            });
        }), this.setData({
            round: a
        });
    },
    back: function() {
        this.data.round ? wx.showModal({
            title: "提示",
            content: "离开对局会使战绩为负",
            success: function(a) {
                a.confirm && t.back();
            }
        }) : t.back();
    },
    check: function(t) {
        if (!this.data.round.questions[this.data.question_index].next) {
            var a = this.data.round;
            if (1 == a.questions[this.data.question_index].questionType) a.questions[this.data.question_index].answers.forEach(function(t) {
                t.select = !1;
            }), a.questions[this.data.question_index].answers[t.currentTarget.dataset.index].select = !0; else {
                var e = a.questions[this.data.question_index].answers[t.currentTarget.dataset.index].select;
                a.questions[this.data.question_index].answers[t.currentTarget.dataset.index].select = !e;
            }
            this.setData({
                round: a
            });
        }
    },
    record: function(a, e) {
        var n = this;
        if (!this.data.round.questions[this.data.question_index].next) if (this.has_select() || e) {
            var i = this.data.round;
            i.teams.forEach(function(a) {
                a.players.forEach(function(a) {
                    if (a.id == n.data.player.id) {
                        var e = n.check_answer(), o = a.records[n.data.question_index].id, s = new Date().getTime() - n.data.duration;
                        n.setData({
                            ts: !0,
                            error: !e
                        }), i.questions[n.data.question_index].next = !0, a.records[n.data.question_index].end = !0, 
                        n.setData({
                            round: i
                        }), n.finish_all(), t.request({
                            recordId: o,
                            correct: e,
                            duration: s > 15e3 ? 15e3 : s
                        }, "/weixin/battle/record", !0, !1).then(function(t) {
                            e && (n.setData({
                                mate_percentage: n.data.mate_percentage + 10
                            }), a.score += a.records[n.data.question_index].score), n.setData({
                                round: i
                            });
                        });
                    }
                });
            });
        } else wx.showToast({
            icon: "error",
            title: "请选择答案"
        });
    },
    check_answer: function(t) {
        var a = this.data.round.questions[this.data.question_index], e = !0;
        return a.answers.forEach(function(t) {
            t.select != t.correct && (e = !1);
        }), e;
    },
    has_select: function(t) {
        var a = this.data.round.questions[this.data.question_index], e = !1;
        return a.answers.forEach(function(t) {
            t.select && (e = !0);
        }), e;
    },
    finish_all: function(t) {
        var a = this, e = !0;
        this.data.round.teams.forEach(function(t) {
            t.players.forEach(function(t) {
                t.records[a.data.question_index].end || (e = !1);
            });
        }), e && setTimeout(function() {
            a.setData({
                count_down: a.data.time_index,
                count_start: !1
            }), a.change_question();
        }, 1e3);
    },
    time_change: function(t) {
        var a = this;
        this.setData({
            percentage: (15 - t.detail.ss) * (100 / 15),
            time_index: t.detail.ss > 0 ? 1e3 * t.detail.ss : 500
        });
        var e = this.data.round;
        e.teams.forEach(function(n) {
            n.players.forEach(function(n) {
                var i = n.records[a.data.question_index];
                if (i.bot) {
                    var o = i.duration && i.duration >= 0 ? i.duration > 15e3 ? 15e3 : i.duration : 0, s = o / 1e3 ^ 0;
                    t.detail.ss == 15 - s && setTimeout(function() {
                        n.records[a.data.question_index].end = !0, i.correct && (a.setData({
                            mate_percentage: a.data.mate_percentage - 10
                        }), n.score += n.records[a.data.question_index].score), a.setData({
                            round: e
                        }), a.finish_all();
                    }, o - 1e3 * s);
                }
            });
        });
    },
    time_end: function(t) {
        this.record(null, !0);
    },
    mate_start: function(t) {
        var a, e, n, i, o, s, r = this, c = Math.round(Math.random() * +(null !== (a = null === (e = this.data.param) || void 0 === e ? void 0 : e.comment) && void 0 !== a ? a : 10) - +(null !== (n = null === (i = this.data.param) || void 0 === i ? void 0 : i.paramValue) && void 0 !== n ? n : 1) + +(null !== (o = null === (s = this.data.param) || void 0 === s ? void 0 : s.paramValue) && void 0 !== o ? o : 1));
        this.setData({
            opaque_animation: !0
        });
        var u = wx.createAnimation({
            duration: 500
        });
        u.opacity(0).step(), this.animation("transparent", u), this.setData({
            mate_start: !0
        }), setTimeout(function() {
            var t = wx.createAnimation({
                duration: 500
            });
            t.opacity(1).step(), r.animation("opaque", t), r.setData({
                rote: !0
            }), setTimeout(function() {
                r.data.mate_start && r.match();
            }, 1e3 * c);
        }, 500);
    },
    mate_ban: function(t) {
        var a = this;
        this.setData({
            transparent_animation: !0
        });
        var e = wx.createAnimation({
            duration: 500
        });
        e.opacity(0).step(), this.animation("opaque", e), this.setData({
            mate_start: !1
        }), setTimeout(function() {
            var t = wx.createAnimation({
                duration: 500
            });
            t.opacity(1).step(), a.animation("transparent", t), a.setData({
                rote: !1
            });
        }, 500);
    },
    mate_success: function(t) {
        var a = this, e = wx.createAnimation({
            duration: 500
        });
        e.opacity(0).step(), this.animation("mate_end", e), this.setData({
            alone_index: 1
        }), setTimeout(function() {
            var t = wx.createAnimation({
                duration: 500
            });
            t.opacity(1).step(), a.animation("success_end", t);
        }, 500), setTimeout(function() {
            var t = wx.createAnimation({
                duration: 500
            });
            t.translateX(0).step(), a.animation("left", t), setTimeout(function() {
                var t = wx.createAnimation({
                    duration: 500
                });
                t.translateY(0).step(), a.animation("top", t);
            }, 1e3);
        }, 500), setTimeout(function() {
            var t = wx.createAnimation({
                duration: 500
            });
            t.opacity(0).step(), a.animation("success_end", t), a.setData({
                alone_index: 2
            }), setTimeout(function() {
                var t = wx.createAnimation({
                    duration: 500
                });
                t.opacity(1).step(), a.animation("question_start", t), a.quesiton();
            }, 500);
        }, 5e3);
    },
    quesiton: function(t) {
        var a = this, e = wx.createAnimation({
            duration: 500
        });
        e.opacity(1).step(), this.animation("question", e), setTimeout(function() {
            var t = wx.createAnimation({
                duration: 500
            });
            t.opacity(1).step(), a.animation("answer", t), a.setData({
                count_down: 15e3,
                count_start: !0,
                duration: new Date().getTime()
            });
        }, 500);
    },
    change_question: function() {
        var t, a = this;
        this.data.question_index < 4 ? ((t = wx.createAnimation({
            duration: 500
        })).opacity(0).step(), this.animation("question", t), (t = wx.createAnimation({
            duration: 500
        })).opacity(0).step(), this.animation("answer", t), setTimeout(function() {
            a.setData({
                question_index: a.data.question_index + 1,
                ts: !1,
                error: !1
            });
            var t = wx.createAnimation({
                duration: 500
            });
            t.opacity(1).step(), a.animation("question", t), setTimeout(function() {
                var t = wx.createAnimation({
                    duration: 500
                });
                t.opacity(1).step(), a.animation("answer", t), a.setData({
                    count_down: 15e3,
                    count_start: !0,
                    duration: new Date().getTime()
                });
            }, 500);
        }, 500)) : wx.redirectTo({
            url: "account?roundId=" + this.data.round.id + "&path=battle"
        });
    },
    animation: function(t, a) {
        var e = {};
        e[t] = a.export(), this.setData(e);
    },
    animation_end: function(t) {
        var a = {};
        a[t.currentTarget.dataset.code] = !1, this.setData(a);
    },
    onShareAppMessage: function(t) {
        return {
            title: "一起来答题吧！",
            path: "pages/index/index",
            imageUrl: "https://battle.wetruetech.com/img/logo.jpg?v=1.0"
        };
    },
    onShareTimeline: function(t) {
        return {
            title: "一起来答题吧！",
            path: "pages/index/index",
            imageUrl: "https://battle.wetruetech.com/img/logo.jpg?v=1.0"
        };
    }
});