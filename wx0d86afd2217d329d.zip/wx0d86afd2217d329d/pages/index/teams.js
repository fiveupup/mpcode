var t = getApp();

Page({
    data: {
        alone_index: 0,
        question_index: 0,
        count_down: 15e3,
        count_start: !1,
        mate_percentage: 50,
        captain: !1,
        fx_index: 0,
        finish: !1
    },
    onLoad: function(a) {
        this.setData({
            statusBarHeight: wx.getSystemInfoSync().statusBarHeight,
            img_url: t.globalData.img_url,
            room_id: a.room_id
        });
    },
    onShow: function(a) {
        var e = this;
        this.filter(function() {
            e.setData({
                player: t.globalData.player
            }), e.data.player.dailyBattles < 3 ? (e.socket(), e.param()) : wx.showModal({
                content: "您已达到今日竞答次数上限！",
                showCancel: !1,
                success: function(t) {
                    t.confirm && wx.switchTab({
                        url: "index"
                    });
                }
            });
        });
    },
    onHide: function(t) {
        clearTimeout(this.data.time_out);
    },
    onUnload: function(t) {
        this.data.task && this.data.task.close({
            code: 1e3
        });
    },
    socket: function(a) {
        var e = this, n = this, i = this.data.task;
        i ? this.hart() : ((i = wx.connectSocket({
            url: "wss://battle.wetruetech.com/socket",
            header: {
                Authorization: "SessionToken " + t.globalData.maUser.sessionToken
            },
            success: function(t) {
                console.info(t);
            },
            fail: function(t) {
                console.info(t);
            }
        })).onOpen(function() {
            n.setData({
                task: i
            }), n.room();
        }), i.onClose(function(t) {
            clearTimeout(e.data.time_out), 1e3 != t.code && wx.showModal({
                title: "提示",
                content: "房间连接超时，请重新加入！(" + t.code + ")",
                showCancel: !1,
                complete: function(t) {
                    t.confirm && wx.switchTab({
                        url: "index"
                    });
                }
            });
        }), i.onMessage(function(t) {
            var a = JSON.parse(t.data);
            switch (console.info(a), a.name) {
              case "RoomChange":
                1 == a.code ? e.setData({
                    room_id: a.roomId,
                    palyers: e.bind_players(a.palyers)
                }) : (clearTimeout(e.data.time_out), e.data.task.close({
                    code: 1e3
                }), wx.showModal({
                    content: a.message ? a.message : "连接失败",
                    showCancel: !1,
                    complete: function(t) {
                        t.confirm && wx.switchTab({
                            url: "index"
                        });
                    }
                }));
                break;

              case "MatchSuccess":
                e.bind_round(a.round), e.mate_success();
                break;

              case "Record":
                e.update_record(a.roundRecord);
                break;

              case "Ready":
                e.mate_start_animation();
                break;

              case "Cancel":
                e.mate_ban_animation();
            }
        }));
    },
    room: function(t) {
        this.data.room_id ? this.data.task.send({
            data: JSON.stringify({
                name: "JoinRoom",
                roomId: this.data.room_id
            })
        }) : this.data.task.send({
            data: JSON.stringify({
                name: "CreateRoom"
            })
        }), this.hart();
    },
    hart: function(t) {
        var a = this;
        this.setData({
            time_out: setTimeout(function() {
                a.data.task.send({
                    data: JSON.stringify({
                        name: "hart"
                    })
                }), a.hart();
            }, 1e4)
        });
    },
    filter: function(a) {
        var e = this;
        t.globalData.player = !1, t.globalData.maUser ? this.MATCH_STATUS(a) : t.land().then(function() {
            e.MATCH_STATUS(a);
        });
    },
    MATCH_STATUS: function(a) {
        t.request({}, "/weixin/param/MATCH_STATUS", !1, !1).then(function(e) {
            "ON" == e.data.paramValue ? t.player(!0).then(function() {
                a();
            }) : wx.showModal({
                content: e.data.comment,
                showCancel: !1,
                success: function(t) {
                    t.confirm && wx.switchTab({
                        url: "index"
                    });
                }
            });
        });
    },
    bind_players: function(a) {
        var e = this, n = 4 - a.length;
        this.setData({
            teams_num: a.length
        }), a.forEach(function(a, n) {
            if (0 == n && a.id == e.data.player.id && e.setData({
                captain: !0
            }), 0 != n && a.id == e.data.player.id && e.setData({
                captain: !1
            }), (a = t.bind_player(a)).id != e.data.player.id) {
                var i = a.nickname.length;
                a.nickname = i > 1 ? a.nickname.substring(0, 1) + "**" + a.nickname.substring(i - 1, i) : 1 == i ? a.nickname + "**" : "**";
            }
        });
        for (var i = 0; i < n; i++) a.push(null);
        return a;
    },
    param: function(a) {
        var e = this;
        t.request({}, "/weixin/param/MATCH_TIME").then(function(t) {
            e.setData({
                param: t.data
            });
        });
    },
    match: function(t) {
        this.data.task.send({
            data: JSON.stringify({
                name: "Match",
                roundType: 8
            })
        });
    },
    bind_round: function(a) {
        var e = this;
        a.questions.forEach(function(t) {
            t.content = "(" + (1 == t.questionType ? "单选题" : "多选题") + ")" + t.content, t.next = !1, 
            t.answers.forEach(function(t, a) {
                t.answer_index = [ "A", "B", "C", "D" ][a], t.select = !1;
            });
        }), a.teams.forEach(function(a) {
            a.score = 0, a.players.forEach(function(a) {
                if (a.id != e.data.player.id) {
                    var n = a.nickname.length;
                    a.nickname = n > 1 ? a.nickname.substring(0, 1) + "**" + a.nickname.substring(n - 1, n) : 1 == n ? a.nickname + "**" : "**";
                }
                (a = t.bind_player(a)).records.forEach(function(t) {
                    t.end = !1;
                });
            });
        }), this.setData({
            round: a
        });
    },
    update_record: function(t) {
        var a = this, e = this.data.round;
        t ? e.teams.forEach(function(n) {
            n.players.forEach(function(i) {
                i.records.forEach(function(o) {
                    o.id == t.id && (o.correct = t.correct, o.end = !0, i.id == a.data.player.id && (e.questions[a.data.question_index].next = !0, 
                    a.setData({
                        ts: !0,
                        error: !t.correct
                    })), t.correct && (n.score += o.score, a.setData({
                        mate_percentage: a.data.mate_percentage + 2.5
                    })), a.setData({
                        round: e
                    }), a.data.finish || a.finish_all());
                });
            });
        }) : (e.teams.forEach(function(t) {
            t.players.forEach(function(t) {
                t.records[a.data.question_index].end = !0;
            });
        }), this.setData({
            round: e,
            finish: !0
        }), this.finish_all());
    },
    back: function() {
        var a = this;
        this.data.round ? wx.showModal({
            title: "提示",
            content: "离开对局会使战绩为负",
            success: function(e) {
                e.confirm && (clearTimeout(a.data.time_out), a.data.task.send({
                    data: JSON.stringify({
                        name: "LeaveRoom",
                        roomId: a.data.room_id
                    })
                }), a.data.task.close({
                    code: 1e3
                }), t.back());
            }
        }) : (clearTimeout(this.data.time_out), this.data.task.send({
            data: JSON.stringify({
                name: "LeaveRoom",
                roomId: this.data.room_id
            })
        }), a.data.task.close({
            code: 1e3
        }), t.back());
    },
    check: function(t) {
        if (!this.data.round.questions[this.data.question_index].next) {
            var a = this.data.round;
            if (1 == a.questions[this.data.question_index].questionType) a.questions[this.data.question_index].answers.forEach(function(t) {
                t.select = !1;
            }), a.questions[this.data.question_index].answers[t.currentTarget.dataset.index].select = !0; else {
                var e = a.questions[this.data.question_index].answers[t.currentTarget.dataset.index].select;
                a.questions[this.data.question_index].answers[t.currentTarget.dataset.index].select = !e;
            }
            this.setData({
                round: a
            });
        }
    },
    record: function(t, a) {
        var e = this;
        this.data.round.questions[this.data.question_index].next || (this.has_select() || a ? this.data.round.teams.forEach(function(t) {
            t.players.forEach(function(t) {
                if (t.id == e.data.player.id) {
                    var a = e.check_answer(), n = t.records[e.data.question_index].id, i = new Date().getTime() - e.data.duration;
                    e.data.task.send({
                        data: JSON.stringify({
                            name: "Record",
                            recordId: n,
                            correct: a,
                            duration: i > 15e3 ? 15e3 : i
                        })
                    });
                }
            });
        }) : wx.showToast({
            icon: "error",
            title: "请选择答案"
        }));
    },
    check_answer: function(t) {
        var a = this.data.round.questions[this.data.question_index], e = !0;
        return a.answers.forEach(function(t) {
            t.select != t.correct && (e = !1);
        }), e;
    },
    has_select: function(t) {
        var a = this.data.round.questions[this.data.question_index], e = !1;
        return a.answers.forEach(function(t) {
            t.select && (e = !0);
        }), e;
    },
    finish_all: function(t) {
        var a = this, e = !0;
        this.data.round.teams.forEach(function(t) {
            t.players.forEach(function(t) {
                t.records[a.data.question_index].end || (e = !1);
            });
        }), e && setTimeout(function() {
            a.setData({
                count_down: a.data.time_index,
                count_start: !1
            }), a.change_question();
        }, 1e3);
    },
    time_change: function(t) {
        var a = this;
        this.setData({
            percentage: (15 - t.detail.ss) * (100 / 15),
            time_index: t.detail.ss > 0 ? 1e3 * t.detail.ss : 500
        });
        var e = this.data.round;
        e.teams.forEach(function(n, i) {
            n.players.forEach(function(o) {
                var s = o.records[a.data.question_index];
                if (s.bot) {
                    var r = s.duration && s.duration >= 0 ? s.duration > 15e3 ? 15e3 : s.duration : 0, c = r / 1e3 ^ 0;
                    t.detail.ss == 15 - c && setTimeout(function() {
                        if (o.records[a.data.question_index].end = !0, s.correct) {
                            var t = 0 == i ? a.data.mate_percentage + 2.5 : a.data.mate_percentage - 2.5;
                            a.setData({
                                mate_percentage: t
                            }), n.score += o.records[a.data.question_index].score;
                        }
                        a.setData({
                            round: e
                        }), a.finish_all();
                    }, r - 1e3 * c);
                }
            });
        });
    },
    time_end: function(t) {
        this.record(null, !0), this.update_record(null);
    },
    mate_start: function(t) {
        var a = this;
        if (4 == this.data.teams_num) {
            var e, n, i, o, s, r, c = Math.round(Math.random() * +(null !== (e = null === (n = this.data.param) || void 0 === n ? void 0 : n.comment) && void 0 !== e ? e : 10) - +(null !== (i = null === (o = this.data.param) || void 0 === o ? void 0 : o.paramValue) && void 0 !== i ? i : 1) + +(null !== (s = null === (r = this.data.param) || void 0 === r ? void 0 : r.paramValue) && void 0 !== s ? s : 1));
            this.data.task.send({
                data: JSON.stringify({
                    name: "Ready"
                })
            }), setTimeout(function() {
                a.data.mate_start && a.match();
            }, 1e3 * c);
        } else wx.showModal({
            content: "组队需达到4人方能开始比赛！",
            showCancel: !1
        });
    },
    mate_start_animation: function(t) {
        var a = this;
        this.setData({
            opaque_animation: !0,
            mate_start: !0
        });
        var e = wx.createAnimation({
            duration: 500
        });
        e.opacity(0).step(), this.animation("transparent", e), this.setData({
            fx_index: 1
        }), setTimeout(function() {
            var t = wx.createAnimation({
                duration: 500
            });
            t.opacity(1).step(), a.animation("opaque", t), a.setData({
                rote: !0
            });
        }, 500);
    },
    mate_ban: function(t) {
        this.data.task.send({
            data: JSON.stringify({
                name: "Cancel"
            })
        });
    },
    mate_ban_animation: function(t) {
        var a = this;
        this.setData({
            transparent_animation: !0,
            mate_start: !1
        });
        var e = wx.createAnimation({
            duration: 500
        });
        e.opacity(0).step(), this.animation("opaque", e), this.setData({
            fx_index: 0
        }), setTimeout(function() {
            var t = wx.createAnimation({
                duration: 500
            });
            t.opacity(1).step(), a.animation("transparent", t), a.setData({
                rote: !1
            });
        }, 500);
    },
    mate_success: function(t) {
        var a = this, e = wx.createAnimation({
            duration: 500
        });
        e.opacity(0).step(), this.animation("mate_end", e), this.setData({
            alone_index: 1
        }), setTimeout(function() {
            var t = wx.createAnimation({
                duration: 500
            });
            t.opacity(1).step(), a.animation("success_end", t);
        }, 500), setTimeout(function() {
            var t = wx.createAnimation({
                duration: 500
            });
            t.translateX(0).step(), a.animation("left", t), setTimeout(function() {
                var t = wx.createAnimation({
                    duration: 500
                });
                t.translateY(0).step(), a.animation("top", t);
            }, 1e3);
        }, 500), setTimeout(function() {
            var t = wx.createAnimation({
                duration: 500
            });
            t.opacity(0).step(), a.animation("success_end", t), a.setData({
                alone_index: 2
            }), setTimeout(function() {
                var t = wx.createAnimation({
                    duration: 500
                });
                t.opacity(1).step(), a.animation("question_start", t), a.quesiton();
            }, 500);
        }, 5e3);
    },
    quesiton: function(t) {
        var a = this, e = wx.createAnimation({
            duration: 500
        });
        e.opacity(1).step(), this.animation("question", e), setTimeout(function() {
            var t = wx.createAnimation({
                duration: 500
            });
            t.opacity(1).step(), a.animation("answer", t), a.setData({
                count_down: 15e3,
                count_start: !0,
                duration: new Date().getTime()
            });
        }, 500);
    },
    change_question: function() {
        var t, a = this;
        this.data.question_index < 4 ? ((t = wx.createAnimation({
            duration: 500
        })).opacity(0).step(), this.animation("question", t), (t = wx.createAnimation({
            duration: 500
        })).opacity(0).step(), this.animation("answer", t), setTimeout(function() {
            a.setData({
                question_index: a.data.question_index + 1,
                ts: !1,
                error: !1
            });
            var t = wx.createAnimation({
                duration: 500
            });
            t.opacity(1).step(), a.animation("question", t), setTimeout(function() {
                var t = wx.createAnimation({
                    duration: 500
                });
                t.opacity(1).step(), a.animation("answer", t), a.setData({
                    count_down: 15e3,
                    count_start: !0,
                    duration: new Date().getTime(),
                    finish: !1
                });
            }, 500);
        }, 500)) : (this.data.task.send({
            data: JSON.stringify({
                name: "Detail",
                roundId: this.data.round.id
            })
        }), wx.redirectTo({
            url: "account?roundId=" + this.data.round.id + "&path=teams&room_id=" + this.data.room_id
        }));
    },
    animation: function(t, a) {
        var e = {};
        e[t] = a.export(), this.setData(e);
    },
    animation_end: function(t) {
        var a = {};
        a[t.currentTarget.dataset.code] = !1, this.setData(a);
    },
    onShareAppMessage: function(t) {
        return {
            title: "和我组队答题吧！",
            path: "pages/index/teams?room_id=" + this.data.room_id,
            imageUrl: "https://battle.wetruetech.com/img/logo.jpg?v=1.0"
        };
    },
    onShareTimeline: function(t) {
        return {
            title: "和我组队答题吧！",
            path: "pages/index/teams?room_id=" + this.data.room_id,
            imageUrl: "https://battle.wetruetech.com/img/logo.jpg?v=1.0"
        };
    }
});