var t = getApp();

Component({
    data: {
        player: {
            division: 5
        }
    },
    pageLifetimes: {
        show: function() {
            var a = this;
            "function" == typeof this.getTabBar && this.getTabBar() && this.getTabBar().setData({
                url: "index"
            }), t.globalData.player = !1, t.globalData.maUser ? t.player(!1).then(function() {
                a.setData({
                    player: t.globalData.player
                });
            }) : t.land().then(function() {
                t.player(!1).then(function() {
                    a.setData({
                        player: t.globalData.player
                    });
                });
            }), t.globalData.show && this.solo();
        }
    },
    lifetimes: {
        attached: function() {
            var a = this;
            this.setData({
                statusBarHeight: wx.getSystemInfoSync().statusBarHeight,
                img_url: t.globalData.img_url
            }), t.globalData.maUser ? this.NOTICE() : t.land().then(function() {
                a.NOTICE();
            });
        }
    },
    methods: {
        NOTICE: function(a) {
            t.request({}, "/weixin/param/NOTICE", !1, !1).then(function(t) {
                "ON" == t.data.paramValue && wx.showModal({
                    content: t.data.comment,
                    showCancel: !1
                });
            });
        },
        show: function(t) {
            this.setData({
                visible: !0
            });
        },
        hide: function(t) {
            this.setData({
                visible: !1
            });
        },
        onVisibleChange: function(t) {
            this.setData({
                visible: t.detail.visible
            });
        },
        step: function(a) {
            this.filter(function() {
                t.globalData.player.dailyBattles < 3 ? wx.navigateTo({
                    url: a.currentTarget.dataset.code
                }) : wx.showModal({
                    content: "您已达到今日竞答次数上限！",
                    showCancel: !1
                });
            });
        },
        solo: function(t) {
            this.filter(function() {
                wx.navigateTo({
                    url: "solo"
                });
            });
        },
        model: function(t) {
            var a = t.currentTarget.dataset.code, e = "battle" == a ? "达到白银解锁双人竞赛！" : "multy" == a ? "达到黄金解锁四人竞赛！" : "达到钻石解锁组队竞赛！";
            wx.showModal({
                title: "提示",
                content: e,
                showCancel: !1
            });
        },
        filter: function(a) {
            var e = this;
            t.request({}, "/weixin/param/MATCH_STATUS", !1, !1).then(function(n) {
                "ON" == n.data.paramValue ? t.globalData.player ? a() : ("boolean" != typeof t.globalData.player || t.globalData.show) && (e.getTabBar().dict_type(), 
                e.getTabBar().region_type(), e.getTabBar().setData({
                    visible: !0
                })) : wx.showModal({
                    content: n.data.comment,
                    showCancel: !1
                });
            });
        },
        onShareAppMessage: function(t) {
            return {
                title: "一起来答题吧！",
                path: "pages/index/index",
                imageUrl: "https://battle.wetruetech.com/img/logo.jpg?v=1.0"
            };
        },
        onShareTimeline: function(t) {
            return {
                title: "一起来答题吧！",
                path: "pages/index/index",
                imageUrl: "https://battle.wetruetech.com/img/logo.jpg?v=1.0"
            };
        }
    }
});