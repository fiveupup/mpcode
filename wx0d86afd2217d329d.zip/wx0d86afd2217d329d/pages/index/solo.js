var t = getApp();

Page({
    data: {},
    onLoad: function() {
        var e = this;
        this.setData({
            statusBarHeight: wx.getSystemInfoSync().statusBarHeight,
            img_url: t.globalData.img_url
        }), this.filter(function() {
            e.setData({
                player: t.globalData.player
            }), e.match();
        });
    },
    filter: function(e) {
        var a = this;
        t.globalData.player = !1, t.globalData.maUser ? this.MATCH_STATUS(e) : t.land().then(function() {
            a.MATCH_STATUS(e);
        });
    },
    MATCH_STATUS: function(e) {
        t.request({}, "/weixin/param/MATCH_STATUS", !1, !1).then(function(a) {
            "ON" == a.data.paramValue ? t.player(!0).then(function() {
                e();
            }) : wx.showModal({
                content: a.data.comment,
                showCancel: !1,
                success: function(t) {
                    t.confirm && wx.switchTab({
                        url: "index"
                    });
                }
            });
        });
    },
    match: function(e) {
        var a = this, n = this;
        t.request({
            roundType: 1
        }, "/weixin/battle/match").then(function(t) {
            n.setData({
                id: t.data.id,
                question: n.bind_question(t.data.questions[0]),
                recordId: t.data.teams[0].players[0].records[0].id,
                question_time: new Date().getTime(),
                next: !1,
                ts: !1,
                error: !1,
                select: !1
            }), a.show_question();
        });
    },
    back: function() {
        t.back();
    },
    show_question: function() {
        var t = this, e = wx.createAnimation({
            duration: 500
        });
        e.opacity(1).step(), this.animation("queston_content", e), setTimeout(function() {
            var e = wx.createAnimation({
                duration: 500
            });
            e.opacity(1).step(), t.animation("answer", e);
        }, 500);
    },
    bind_question: function(t) {
        t.content = "(" + (1 == t.questionType ? "单选题" : "多选题") + ")" + t.content;
        var e = "", a = [ "A", "B", "C", "D" ];
        return t.answers.forEach(function(t, n) {
            t.select = !1, t.answer_index = a[n], t.correct && (e += a[n]);
        }), t.correct_text = e, t;
    },
    check: function(t) {
        if (!this.data.next) {
            var e = this.data.question;
            if (1 == e.questionType) e.answers.forEach(function(t) {
                t.select = !1;
            }), e.answers[t.currentTarget.dataset.index].select = !0; else {
                var a = e.answers[t.currentTarget.dataset.index].select;
                e.answers[t.currentTarget.dataset.index].select = !a;
            }
            this.setData({
                question: e
            });
        }
    },
    ts: function(t) {
        this.setData({
            visible: !0
        });
    },
    hide: function(t) {
        this.setData({
            visible: !1
        });
    },
    onVisibleChange: function(t) {
        this.setData({
            visible: t.detail.visible
        });
    },
    record: function(e) {
        var a = this;
        if (this.has_select()) {
            var n = this.check_answer(), i = new Date().getTime() - a.data.question_time;
            t.request({
                recordId: a.data.recordId,
                correct: n,
                duration: i
            }, "/weixin/battle/record").then(function(t) {
                n && wx.showToast({
                    icon: "success",
                    title: "回答正确"
                }), a.setData({
                    ts: !0,
                    error: !n,
                    next: !0
                }), a.detail(n);
            });
        } else wx.showToast({
            icon: "error",
            title: "请选择答案"
        });
    },
    detail: function(e) {
        var a = this;
        t.request({
            roundId: this.data.id
        }, "/weixin/battle/detail", !1, !1).then(function(t) {
            if (e) {
                var n = a.data.player;
                n.dailyPracticeCount += 1, a.setData({
                    player: n
                });
                [ 5, 10, 15 ].indexOf(n.dailyPracticeCount) > -1 && wx.showModal({
                    content: "您已获得10个答题积分！",
                    showCancel: !1
                }), 20 == n.dailyPracticeCount && wx.showModal({
                    content: "您已获得今日“在线练习”模式全部答题积分！积蓄力量，继续自由练习吧！",
                    showCancel: !1
                });
            }
        });
    },
    animation: function(t, e) {
        var a = {};
        a[t] = e.export(), this.setData(a);
    },
    check_answer: function(t) {
        var e = this.data.question, a = !0;
        return e.answers.forEach(function(t) {
            t.select != t.correct && (a = !1);
        }), a;
    },
    has_select: function(t) {
        var e = this.data.question, a = !1;
        return e.answers.forEach(function(t) {
            t.select && (a = !0);
        }), a;
    },
    onShareAppMessage: function(t) {
        return {
            title: "一起来答题吧！",
            path: "pages/index/index",
            imageUrl: "https://battle.wetruetech.com/img/logo.jpg?v=1.0"
        };
    },
    onShareTimeline: function(t) {
        return {
            title: "一起来答题吧！",
            path: "pages/index/index",
            imageUrl: "https://battle.wetruetech.com/img/logo.jpg?v=1.0"
        };
    }
});