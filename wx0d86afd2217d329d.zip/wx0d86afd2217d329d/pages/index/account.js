var a = getApp();

Page({
    data: {},
    onLoad: function(t) {
        this.setData({
            statusBarHeight: wx.getSystemInfoSync().statusBarHeight,
            img_url: a.globalData.img_url,
            path: t.path,
            room_id: t.room_id
        });
        var e = this;
        a.globalData.maUser ? a.player(!0).then(function() {
            e.setData({
                player: a.globalData.player
            }), e.detail(t.roundId);
        }) : a.land().then(function() {
            a.player(!0).then(function() {
                e.setData({
                    player: a.globalData.player
                }), e.detail(t.roundId);
            });
        });
    },
    detail: function(t) {
        var e = this;
        a.request({
            roundId: t
        }, "/weixin/battle/detail").then(function(a) {
            e.bind_round(a.data);
        });
    },
    bind_round: function(t) {
        var e = this;
        t.teams.forEach(function(t, n) {
            t.details.forEach(function(t) {
                if (t.avatar = t.avatarId ? a.globalData.url + "/weixin/show/" + t.avatarId : a.globalData.img_url.avatar, 
                t.playerId == e.data.player.id) e.setData({
                    totalScore: t.totalScore,
                    title_text: 0 == n ? "胜利!" : "惜败!"
                }); else {
                    var i = t.nickname.length;
                    t.nickname = i > 1 ? t.nickname.substring(0, 1) + "**" + t.nickname.substring(i - 1, i) : 1 == i ? t.nickname + "**" : "**";
                }
            });
        }), this.setData({
            round: t
        }), a.globalData.player = !1, a.player(!0).then(function() {
            e.setData({
                player: a.globalData.player
            });
        });
    },
    back: function() {
        a.back();
    },
    match: function(t) {
        if (a.globalData.player.dailyBattles < 3) {
            var e = "teams" == this.data.path ? "teams?room_id=" + this.data.room_id : this.data.path;
            wx.redirectTo({
                url: e
            });
        } else wx.showModal({
            content: "您已达到今日竞答次数上限！",
            showCancel: !1
        });
    },
    onShareAppMessage: function(a) {
        return {
            title: "神兽之间",
            path: "pages/index/index",
            imageUrl: "https://battle.wetruetech.com/img/logo.jpg?v=1.0"
        };
    },
    onShareTimeline: function(a) {
        return {
            title: "一起来答题吧！",
            path: "pages/index/index",
            imageUrl: "https://battle.wetruetech.com/img/logo.jpg?v=1.0"
        };
    }
});