var t = getApp();

Page({
    data: {},
    onLoad: function() {
        var a = this;
        this.setData({
            statusBarHeight: wx.getSystemInfoSync().statusBarHeight,
            img_url: t.globalData.img_url
        }), t.globalData.maUser ? t.player(!0).then(function() {
            a.setData({
                player: t.globalData.player
            }), a.dictionary();
        }) : t.land().then(function() {
            t.player(!0).then(function() {
                a.setData({
                    player: t.globalData.player
                }), a.dictionary();
            });
        });
    },
    dictionary: function() {
        var a = this;
        t.request({}, "/weixin/dict/type/ACHIEVE_TYPE").then(function(t) {
            a.bind_dict(t.data);
        });
    },
    bind_dict: function(a) {
        var e = this, i = 0;
        a.forEach(function(a) {
            a.img = t.globalData.url + "/img/" + a.dictCode + ".png", a.is_show = 0 != (parseInt(e.data.player.achievies, 16) & 1 << parseInt(a.dictValue) - 1), 
            i = a.is_show ? i + 1 : i;
        }), this.setData({
            achieve_list: a,
            number: i
        });
    },
    back: function() {
        t.back();
    },
    show: function(t) {
        this.setData({
            visible: !0,
            achieve_index: t.currentTarget.dataset.index
        });
    },
    onVisibleChange: function(t) {
        this.setData({
            visible: t.detail.visible
        });
    },
    open: function(a) {
        var e = this, i = this.data.achieve_list, n = (1 << parseInt(i[a.currentTarget.dataset.index].dictValue) - 1).toString(16).padStart(4, "0");
        t.request({
            achievies: n
        }, "/weixin/player/lightUp").then(function(n) {
            var r = wx.createAnimation({
                duration: 1e3
            });
            r.left("100%").step(), i[a.currentTarget.dataset.index].open = r.export(), e.setData({
                achieve_list: i
            }), setTimeout(function() {
                t.globalData.player = t.bind_player(n.data), e.setData({
                    player: t.globalData.player
                }), e.dictionary();
            }, 1500);
        });
    },
    onShareAppMessage: function(t) {
        return {
            title: "一起来答题吧！",
            path: "pages/index/index",
            imageUrl: "https://battle.wetruetech.com/img/logo.jpg?v=1.0"
        };
    },
    onShareTimeline: function(t) {
        return {
            title: "一起来答题吧！",
            path: "pages/index/index",
            imageUrl: "https://battle.wetruetech.com/img/logo.jpg?v=1.0"
        };
    }
});