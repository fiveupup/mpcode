var t = getApp();

Page({
    data: {},
    onLoad: function(a) {
        var i = this;
        this.setData({
            statusBarHeight: wx.getSystemInfoSync().statusBarHeight,
            img_url: t.globalData.img_url,
            id: a.id
        }), t.globalData.maUser ? (t.player(!1).then(function() {
            var e;
            i.setData({
                is_myself: (null === (e = t.globalData.player) || void 0 === e ? void 0 : e.id) == a.id
            });
        }), this.player()) : t.land().then(function() {
            t.player(!1).then(function() {
                var e;
                i.setData({
                    is_myself: (null === (e = t.globalData.player) || void 0 === e ? void 0 : e.id) == a.id
                });
            }), i.player();
        });
    },
    player: function() {
        var a = this;
        t.request({}, "/weixin/player/info/" + this.data.id).then(function(i) {
            a.setData({
                player: t.bind_player(i.data)
            }), a.dictionary();
        });
    },
    dictionary: function() {
        var a = this;
        t.request({}, "/weixin/dict/type/ACHIEVE_TYPE").then(function(t) {
            a.bind_dict(t.data);
        });
    },
    bind_dict: function(a) {
        var i = this, e = 0;
        a.forEach(function(a) {
            a.img = t.globalData.url + "/img/" + a.dictCode + ".png", a.is_show = 0 != (parseInt(i.data.player.achievies, 16) & 1 << parseInt(a.dictValue) - 1), 
            e = a.is_show ? e + 1 : e;
        }), this.setData({
            achieve_list: a,
            number: e
        });
    },
    back: function() {
        t.back();
    },
    show: function(t) {
        this.setData({
            visible: !0,
            achieve_index: t.currentTarget.dataset.index
        });
    },
    onVisibleChange: function(t) {
        this.setData({
            visible: t.detail.visible
        });
    },
    onShareAppMessage: function(t) {
        return {
            title: "我的战绩证书",
            path: "pages/core/share?id=" + this.data.id,
            imageUrl: "https://battle.wetruetech.com/img/logo.jpg?v=1.0"
        };
    },
    onShareTimeline: function(t) {
        return {
            title: "我的战绩证书",
            path: "pages/core/share?id=" + this.data.id,
            imageUrl: "https://battle.wetruetech.com/img/logo.jpg?v=1.0"
        };
    }
});