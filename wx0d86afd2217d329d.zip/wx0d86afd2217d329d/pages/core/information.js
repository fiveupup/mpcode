var t = getApp();

Page({
    data: {
        array: [ {
            text: "男",
            value: 1
        }, {
            text: "女",
            value: 2
        } ]
    },
    onLoad: function() {
        this.setData({
            statusBarHeight: wx.getSystemInfoSync().statusBarHeight,
            img_url: t.globalData.img_url
        });
        var a = this;
        t.globalData.maUser ? t.player(!0).then(function() {
            a.setData({
                player: t.globalData.player
            }), a.dict_type();
        }) : t.land().then(function() {
            t.player(!0).then(function() {
                a.setData({
                    player: t.globalData.player
                }), a.dict_type();
            });
        });
    },
    dict_type: function(a) {
        var e = this;
        t.request({}, "/weixin/dict/type/ORIGIN_TYPE").then(function(t) {
            e.setData({
                type_list: t.data
            }), e.type_index(), e.listAreas();
        });
    },
    type_index: function(t) {
        var a = this;
        this.data.type_list.forEach(function(t, e) {
            a.data.player.origin == t.dictValue && a.setData({
                type_index: e
            });
        });
    },
    listAreas: function(a) {
        var e = this;
        t.request({}, "/weixin/player/listAreas").then(function(t) {
            e.setData({
                region: t.data[1].organizationName + " - " + t.data[2].organizationName + " - " + t.data[3].organizationName
            });
        });
    },
    back: function() {
        t.back();
    },
    onChooseAvatar: function(a) {
        var e = this;
        t.uploadFile({
            avatarUrl: a.detail.avatarUrl
        }, "/weixin/player/upload").then(function(t) {
            e.editMaUser({
                avatarId: t.id
            });
        });
    },
    modal: function(t) {
        var a = this;
        wx.showModal({
            title: t.currentTarget.dataset.title,
            content: t.currentTarget.dataset.content,
            editable: !0,
            success: function(e) {
                if (e.confirm) {
                    if (!/^\S{0,20}$/.test(e.content)) return void wx.showToast({
                        icon: "error",
                        title: "请填写20字以内"
                    });
                    var i = {};
                    i[t.currentTarget.dataset.key] = e.content, a.editMaUser(i);
                }
            }
        });
    },
    change: function(t) {
        var a = {};
        "gender" == t.currentTarget.dataset.key && (a[t.currentTarget.dataset.key] = this.data.array[t.detail.value].value), 
        "birthday" == t.currentTarget.dataset.key && (a[t.currentTarget.dataset.key] = t.detail.value), 
        "origin" == t.currentTarget.dataset.key && (a[t.currentTarget.dataset.key] = this.data.type_list[t.detail.value].dictValue), 
        this.editMaUser(a);
    },
    editMaUser: function(a) {
        var e = this;
        t.request(a, "/weixin/player/enroll").then(function(a) {
            wx.showToast({
                icon: "success",
                title: "修改成功"
            }), t.globalData.player = t.bind_player(a.data), e.setData({
                player: t.globalData.player
            }), e.type_index();
        });
    },
    onShareAppMessage: function(t) {
        return {
            title: "一起来答题吧！",
            path: "pages/index/index",
            imageUrl: "https://battle.wetruetech.com/img/logo.jpg?v=1.0"
        };
    },
    onShareTimeline: function(t) {
        return {
            title: "一起来答题吧！",
            path: "pages/index/index",
            imageUrl: "https://battle.wetruetech.com/img/logo.jpg?v=1.0"
        };
    }
});