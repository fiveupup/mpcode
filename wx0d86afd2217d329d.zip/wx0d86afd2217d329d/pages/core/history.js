var t = getApp();

Page({
    data: {
        page: 0,
        size: 10,
        hasmore: !0
    },
    onLoad: function() {
        this.setData({
            statusBarHeight: wx.getSystemInfoSync().statusBarHeight,
            img_url: t.globalData.img_url
        });
        var a = this;
        t.globalData.maUser ? t.player(!0).then(function() {
            a.history();
        }) : t.land().then(function() {
            t.player(!0).then(function() {
                a.history();
            });
        });
    },
    history: function(a) {
        var e = this;
        t.request({
            page: e.data.page,
            size: e.data.size
        }, "/weixin/battle/history").then(function(t) {
            var a = e.data.historyList;
            a ? e.setData({
                historyList: a.concat(e.bind_history(t.data.content)),
                hasmore: !t.data.last
            }) : e.setData({
                historyList: e.bind_history(t.data.content),
                hasmore: !t.data.last
            });
        });
    },
    reach_bottom: function(t) {
        this.data.hasmore && (this.setData({
            page: this.data.page + 1
        }), this.history());
    },
    bind_history: function(a) {
        var e = this;
        return a.forEach(function(a) {
            a.rand_text = 8 == a.roundType ? "组队竞赛" : 4 == a.roundType ? "四人竞赛" : "双人竞赛", a.rand_style = 8 == a.roundType ? "1" : 4 == a.roundType ? "2" : "3", 
            a.date = e.rank_date_format(a.createTime), a.teams.forEach(function(e) {
                e.details.forEach(function(e) {
                    if (e.avatar = e.avatarId ? t.globalData.url + "/weixin/show/" + e.avatarId : t.globalData.img_url.avatar, 
                    e.duration = (e.duration / 1e3 ^ 0) + "s", e.playerId == t.globalData.player.id) a.myself = e; else {
                        var n = e.nickname.length;
                        e.nickname = n > 1 ? e.nickname.substring(0, 1) + "**" + e.nickname.substring(n - 1, n) : 1 == n ? e.nickname + "**" : "**";
                    }
                });
            });
        }), a;
    },
    back: function() {
        t.back();
    },
    handleChange: function(t) {
        this.setData({
            activeValues: t.detail.value
        });
    },
    rank_date_format: function(t) {
        var a = (new Date().getTime() - new Date(t).getTime()) / 1e3 ^ 0;
        return a < 60 ? a + "秒之前" : a < 3600 ? (a / 60 ^ 0) + "分钟之前" : a < 86400 ? (a / 3600 ^ 0) + "小时之前" : a < 2592e3 ? (a / 86400 ^ 0) + "天之前" : a < 31104e3 ? (a / 2592e3 ^ 0) + "月之前" : "1年前";
    },
    onShareAppMessage: function(t) {
        return {
            title: "一起来答题吧！",
            path: "pages/index/index",
            imageUrl: "https://battle.wetruetech.com/img/logo.jpg?v=1.0"
        };
    },
    onShareTimeline: function(t) {
        return {
            title: "一起来答题吧！",
            path: "pages/index/index",
            imageUrl: "https://battle.wetruetech.com/img/logo.jpg?v=1.0"
        };
    }
});