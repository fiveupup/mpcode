var t = getApp();

Component({
    data: {},
    pageLifetimes: {
        show: function() {
            var a = this;
            "function" == typeof this.getTabBar && this.getTabBar() && this.getTabBar().setData({
                url: "core"
            }), t.globalData.player = !1, t.globalData.maUser ? t.player(!0).then(function() {
                a.setData({
                    player: t.globalData.player
                });
            }) : t.land().then(function() {
                t.player(!0).then(function() {
                    a.setData({
                        player: t.globalData.player
                    });
                });
            });
        }
    },
    lifetimes: {
        attached: function() {
            this.setData({
                statusBarHeight: wx.getSystemInfoSync().statusBarHeight,
                img_url: t.globalData.img_url
            });
        }
    },
    methods: {
        step: function(t) {
            wx.navigateTo({
                url: t.currentTarget.dataset.code
            });
        },
        share: function(t) {
            console.info(), wx.navigateTo({
                url: "share?id=" + this.data.player.id
            });
        },
        onShareAppMessage: function(t) {
            return {
                title: "一起来答题吧！",
                path: "pages/index/index",
                imageUrl: "https://battle.wetruetech.com/img/logo.jpg?v=1.0"
            };
        },
        onShareTimeline: function(t) {
            return {
                title: "一起来答题吧！",
                path: "pages/index/index",
                imageUrl: "https://battle.wetruetech.com/img/logo.jpg?v=1.0"
            };
        }
    }
});