var e = "", t = "", r = {}, s = require("./wxDiscode.js"), a = require("./htmlparser.js"), o = (l("area,base,basefont,br,col,frame,hr,img,input,link,meta,param,embed,command,keygen,source,track,wbr"), 
l("br,a,code,address,article,applet,aside,audio,blockquote,button,canvas,center,dd,del,dir,div,dl,dt,fieldset,figcaption,figure,footer,form,frameset,h1,h2,h3,h4,h5,h6,header,hgroup,hr,iframe,ins,isindex,li,map,menu,noframes,noscript,object,ol,output,p,pre,section,script,table,tbody,td,tfoot,th,thead,tr,ul,video")), n = l("abbr,acronym,applet,b,basefont,bdo,big,button,cite,del,dfn,em,font,i,iframe,img,input,ins,kbd,label,map,object,q,s,samp,script,select,small,span,strike,strong,sub,sup,textarea,tt,u,var"), i = l("colgroup,dd,dt,li,options,p,td,tfoot,th,thead,tr");

l("checked,compact,declare,defer,disabled,ismap,multiple,nohref,noresize,noshade,nowrap,readonly,selected"), 
l("wxxxcode-style,script,style,view,scroll-view,block");

function l(e) {
    for (var t = {}, r = e.split(","), s = 0; s < r.length; s++) t[r[s]] = !0;
    return t;
}

function d(s) {
    var a = [];
    if (0 == e.length || !r) return (d = {
        node: "text"
    }).text = s, n = [ d ];
    s = s.replace(/\[([^\[\]]+)\]/g, ":$1:");
    for (var o = new RegExp("[:]"), n = s.split(o), i = 0; i < n.length; i++) {
        var l = n[i], d = {};
        r[l] ? (d.node = "element", d.tag = "emoji", d.text = r[l], d.baseSrc = t) : (d.node = "text", 
        d.text = l), a.push(d);
    }
    return a;
}

module.exports = {
    html2json: function(e, t) {
        e = function(e) {
            return e.replace(/<\?xml.*\?>\n/, "").replace(/<.*!doctype.*\>\n/, "").replace(/<.*!DOCTYPE.*\>\n/, "");
        }(e), e = s.strDiscode(e);
        var r = [], l = {
            node: t,
            nodes: [],
            images: [],
            imageUrls: []
        };
        return a(e, {
            start: function(e, a, d) {
                var c = {
                    node: "element",
                    tag: e
                };
                if (o[e] ? c.tagType = "block" : n[e] ? c.tagType = "inline" : i[e] && (c.tagType = "closeSelf"), 
                0 !== a.length && (c.attr = a.reduce(function(e, t) {
                    var r = t.name, s = t.value;
                    return "class" == r && (console.dir(s), c.classStr = s), "style" == r && (console.dir(s), 
                    c.styleStr = s), s.match(/ /) && (s = s.split(" ")), e[r] ? Array.isArray(e[r]) ? e[r].push(s) : e[r] = [ e[r], s ] : e[r] = s, 
                    e;
                }, {})), "img" === c.tag) {
                    c.imgIndex = l.images.length;
                    var u = c.attr.src;
                    u = s.urlToHttpUrl(u, "https"), c.attr.src = u, c.from = t, l.images.push(c), l.imageUrls.push(u);
                }
                if ("font" === c.tag) {
                    var p = [ "x-small", "small", "medium", "large", "x-large", "xx-large", "-webkit-xxx-large" ], m = {
                        color: "color",
                        face: "font-family",
                        size: "font-size"
                    };
                    for (var f in c.attr.style || (c.attr.style = []), c.styleStr || (c.styleStr = ""), 
                    m) if (c.attr[f]) {
                        var h = "size" === f ? p[c.attr[f] - 1] : c.attr[f];
                        c.attr.style.push(m[f]), c.attr.style.push(h), c.styleStr += m[f] + ": " + h + ";";
                    }
                }
                if ("source" === c.tag && (l.source = c.attr.src), d) {
                    var g = r[0] || l;
                    void 0 === g.nodes && (g.nodes = []), g.nodes.push(c);
                } else r.unshift(c);
            },
            end: function(e) {
                var t = r.shift();
                if (t.tag !== e && console.error("invalid state: mismatch end tag"), "video" === t.tag && l.source && (t.attr.src = l.source, 
                delete l.source), 0 === r.length) l.nodes.push(t); else {
                    var s = r[0];
                    void 0 === s.nodes && (s.nodes = []), s.nodes.push(t);
                }
            },
            chars: function(e) {
                var t = {
                    node: "text",
                    text: e,
                    textArray: d(e)
                };
                if (0 === r.length) l.nodes.push(t); else {
                    var s = r[0];
                    void 0 === s.nodes && (s.nodes = []), s.nodes.push(t);
                }
            },
            comment: function(e) {}
        }), l;
    },
    emojisInit: function() {
        var s = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : "", a = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : "/wxParse/emojis/", o = arguments.length > 2 ? arguments[2] : void 0;
        e = s, t = a, r = o;
    }
};