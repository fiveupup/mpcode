var t = getApp();

Page({
    data: {
        page: 0,
        size: 10,
        hasmore: !0
    },
    onLoad: function(a) {
        var e = this;
        this.setData({
            statusBarHeight: wx.getSystemInfoSync().statusBarHeight,
            img_url: t.globalData.img_url,
            subject_id: a.id,
            title_img: t.globalData.url + "/img/article" + a.id + ".png?v=1.1"
        }), t.globalData.maUser ? this.article() : t.land().then(function() {
            e.article();
        });
    },
    article: function(a) {
        var e = this;
        t.request({
            subjectId: this.data.subject_id,
            page: this.data.page,
            size: this.data.size
        }, "/weixin/article/search").then(function(t) {
            var a = e.data.article_list;
            a ? e.setData({
                article_list: a.concat(e.bind_article(t.data)),
                hasmore: t.data.length == e.data.size
            }) : e.setData({
                article_list: e.bind_article(t.data),
                hasmore: t.data.length == e.data.size
            });
        });
    },
    bind_article: function(a) {
        return a.forEach(function(a) {
            a.date = t.date_format(a.createTime, "-", !1);
        }), a;
    },
    reach_bottom: function(t) {
        this.data.hasmore && (this.setData({
            page: this.data.page + 1
        }), this.article());
    },
    detail: function(t) {
        wx.navigateTo({
            url: "detail?id=" + t.currentTarget.dataset.id
        });
    },
    back: function() {
        t.back();
    },
    onShareAppMessage: function(t) {
        return {
            title: "一起来答题吧！",
            path: "pages/index/index",
            imageUrl: "https://battle.wetruetech.com/img/logo.jpg?v=1.0"
        };
    },
    onShareTimeline: function(t) {
        return {
            title: "一起来答题吧！",
            path: "pages/index/index",
            imageUrl: "https://battle.wetruetech.com/img/logo.jpg?v=1.0"
        };
    }
});