var t = getApp();

Component({
    data: {},
    pageLifetimes: {
        show: function() {
            var e = this;
            "function" == typeof this.getTabBar && this.getTabBar() && this.getTabBar().setData({
                url: "subject"
            }), t.globalData.maUser ? this.subject() : t.land().then(function() {
                e.subject();
            });
        }
    },
    lifetimes: {
        attached: function() {
            this.setData({
                statusBarHeight: wx.getSystemInfoSync().statusBarHeight,
                img_url: t.globalData.img_url
            });
        }
    },
    methods: {
        subject: function(e) {
            var a = this;
            t.request({}, "/weixin/subject/search", !1, !1).then(function(t) {
                a.bind_subject(t.data);
            });
        },
        bind_subject: function(e) {
            e.forEach(function(e) {
                e.img = t.globalData.url + "/img/subject" + e.id + ".png?v=1.0";
            }), this.setData({
                subject_list: e
            });
        },
        start: function(t) {
            var e = this, a = this.data.subject_list;
            a[t.currentTarget.dataset.index].active = !0, this.setData({
                subject_list: a
            }), setTimeout(function() {
                a[t.currentTarget.dataset.index].active = !1, e.setData({
                    subject_list: a
                });
            }, 100);
        },
        step: function(t) {
            wx.navigateTo({
                url: "article?id=" + this.data.subject_list[t.currentTarget.dataset.index].id
            });
        },
        onShareAppMessage: function(t) {
            return {
                title: "一起来答题吧！",
                path: "pages/index/index",
                imageUrl: "https://battle.wetruetech.com/img/logo.jpg?v=1.0"
            };
        },
        onShareTimeline: function(t) {
            return {
                title: "一起来答题吧！",
                path: "pages/index/index",
                imageUrl: "https://battle.wetruetech.com/img/logo.jpg?v=1.0"
            };
        }
    }
});