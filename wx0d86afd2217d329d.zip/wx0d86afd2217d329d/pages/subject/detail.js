var t = require("../wxparse/wxParse.js"), e = getApp();

Page({
    data: {},
    onLoad: function(t) {
        var a = this;
        this.setData({
            statusBarHeight: wx.getSystemInfoSync().statusBarHeight,
            img_url: e.globalData.img_url,
            article_id: t.id
        }), e.globalData.maUser ? this.detail() : e.land().then(function() {
            a.detail();
        });
    },
    detail: function(a) {
        var i = this;
        e.request({}, "/weixin/article/index/" + this.data.article_id, !0, !1).then(function(e) {
            wx.showLoading({
                title: "数据加载中"
            }), i.setData({
                detail: e.data
            }), e.data.content && t.wxParse("content", "html", e.data.content, i, 5), wx.hideLoading();
        });
    },
    back: function() {
        e.back();
    },
    onShareAppMessage: function(t) {
        return {
            title: "一起来答题吧！",
            path: "pages/index/index",
            imageUrl: "https://battle.wetruetech.com/img/logo.jpg?v=1.0"
        };
    },
    onShareTimeline: function(t) {
        return {
            title: "一起来答题吧！",
            path: "pages/index/index",
            imageUrl: "https://battle.wetruetech.com/img/logo.jpg?v=1.0"
        };
    }
});