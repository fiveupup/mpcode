var a = getApp();

Component({
    data: {
        area_index: 0
    },
    pageLifetimes: {
        show: function() {
            var t = this;
            "function" == typeof this.getTabBar && this.getTabBar() && this.getTabBar().setData({
                url: "rank"
            }), a.globalData.player = !1, a.globalData.maUser ? a.player(!0).then(function() {
                t.setData({
                    player: a.globalData.player
                }), t.listAreas();
            }) : a.land().then(function() {
                a.player(!0).then(function() {
                    t.setData({
                        player: a.globalData.player
                    }), t.listAreas();
                });
            });
        }
    },
    lifetimes: {
        attached: function() {
            this.setData({
                statusBarHeight: wx.getSystemInfoSync().statusBarHeight,
                img_url: a.globalData.img_url
            });
        }
    },
    methods: {
        listAreas: function(t) {
            var e = this;
            a.request({}, "/weixin/player/listAreas", !0, !1).then(function(a) {
                e.setData({
                    areas_list: a.data
                }), e.rank(), e.my_rank();
            });
        },
        rank: function() {
            var t = this;
            a.request({
                oid: this.data.areas_list[this.data.area_index].oid,
                page: 0,
                size: 100
            }, "/weixin/statsPlayer/rank", !0, !1).then(function(a) {
                t.setData({
                    rank_list: t.bind_rank(a.data)
                });
            });
        },
        my_rank: function() {
            var t = this;
            a.request({
                oid: this.data.areas_list[this.data.area_index].oid
            }, "/weixin/statsPlayer/info", !0, !1).then(function(a) {
                var e;
                t.setData({
                    areaRank: null !== (e = a.data) && void 0 !== e && e.areaRank ? a.data.areaRank : "暂无"
                });
            });
        },
        bind_rank: function(t) {
            return t.forEach(function(t) {
                t.avatar = t.avatarId ? a.globalData.url + "/weixin/show/" + t.avatarId : a.globalData.img_url.avatar;
                var e = t.nickname.length;
                t.nickname = e > 1 ? t.nickname.substring(0, 1) + "**" + t.nickname.substring(e - 1, e) : 1 == e ? t.nickname + "**" : "**";
            }), t;
        },
        change: function(a) {
            this.setData({
                area_index: a.detail.value
            }), this.rank(), this.my_rank();
        },
        onShareAppMessage: function(a) {
            return {
                title: "一起来答题吧！",
                path: "pages/index/index",
                imageUrl: "https://battle.wetruetech.com/img/logo.jpg?v=1.0"
            };
        },
        onShareTimeline: function(a) {
            return {
                title: "一起来答题吧！",
                path: "pages/index/index",
                imageUrl: "https://battle.wetruetech.com/img/logo.jpg?v=1.0"
            };
        }
    }
});