App({
    onLaunch: function() {
        var t = wx.getUpdateManager();
        t.onCheckForUpdate(function(e) {
            e.hasUpdate && (t.onUpdateReady(function() {
                wx.showModal({
                    title: "更新提示",
                    content: "新版本已经准备好，是否重启应用？",
                    showCancel: !1,
                    success: function(e) {
                        e.confirm && t.applyUpdate();
                    }
                });
            }), t.onUpdateFailed(function() {
                wx.showModal({
                    title: "已经有新版本咯~",
                    content: "请您删除当前小程序，到微信 “发现-小程序” 页，重新搜索打开呦~",
                    showCancel: !1
                });
            }));
        });
    },
    globalData: {
        url: "https://battle.wetruetech.com",
        player: !1,
        img_url: {
            banner: "https://battle.wetruetech.com/img/banner.png?v=1.0",
            title: "https://battle.wetruetech.com/img/title.png?v=1.3",
            b1: "https://battle.wetruetech.com/img/b1.png?v=1.1",
            b2: "https://battle.wetruetech.com/img/b2.png?v=1.1",
            b3: "https://battle.wetruetech.com/img/b3.png?v=1.0",
            b4: "https://battle.wetruetech.com/img/b4.png?v=1.0",
            rull: "https://battle.wetruetech.com/img/rull.png",
            avatar: "https://battle.wetruetech.com/img/avatar.png",
            r1: "https://battle.wetruetech.com/img/r1.png",
            r2: "https://battle.wetruetech.com/img/r2.png",
            r3: "https://battle.wetruetech.com/img/r3.png",
            city: "https://battle.wetruetech.com/img/city.png",
            rank_banner: "https://battle.wetruetech.com/img/rank_banner.png",
            s1: "https://battle.wetruetech.com/img/s1.png",
            s2: "https://battle.wetruetech.com/img/s2.png",
            s3: "https://battle.wetruetech.com/img/s3.png",
            s4: "https://battle.wetruetech.com/img/s4.png",
            s5: "https://battle.wetruetech.com/img/s5.png",
            core_banner: "https://battle.wetruetech.com/img/core_banner.png",
            i1: "https://battle.wetruetech.com/img/i1.png",
            i2: "https://battle.wetruetech.com/img/i2.png",
            i3: "https://battle.wetruetech.com/img/i3.png",
            i4: "https://battle.wetruetech.com/img/i4.png",
            lock: "https://battle.wetruetech.com/img/lock.png",
            share_banner: "https://battle.wetruetech.com/img/share_banner.png",
            share1: "https://battle.wetruetech.com/img/share1.png",
            share2: "https://battle.wetruetech.com/img/share2.png",
            share3: "https://battle.wetruetech.com/img/share3.png",
            share4: "https://battle.wetruetech.com/img/share4.png",
            share5: "https://battle.wetruetech.com/img/share5.png",
            vs: "https://battle.wetruetech.com/img/vs.png",
            victory: "https://battle.wetruetech.com/img/victory.png?v=1.0",
            defeat: "https://battle.wetruetech.com/img/defeat.png?v=1.0",
            score: "https://battle.wetruetech.com/img/score.png",
            mate1: "https://battle.wetruetech.com/img/mate1.png?v=1.0",
            mate2: "https://battle.wetruetech.com/img/mate2.png",
            mate3: "https://battle.wetruetech.com/img/mate3.png",
            mate_success: "https://battle.wetruetech.com/img/mate_success.png",
            vs_fff: "https://battle.wetruetech.com/img/vs_fff.png",
            wait_in: "https://battle.wetruetech.com/img/wait_in.png",
            wait_out: "https://battle.wetruetech.com/img/wait_out.png",
            subject_title: "https://battle.wetruetech.com/img/subject_title.png",
            subject_head: "https://battle.wetruetech.com/img/subject_head.png"
        }
    },
    land: function(t) {
        var e = this;
        return new Promise(function(t, a) {
            wx.login({
                success: function(n) {
                    wx.request({
                        url: e.globalData.url + "/weixin/login",
                        data: {
                            code: n.code
                        },
                        success: function(a) {
                            e.globalData.maUser = a.data.data, t();
                        },
                        fail: function(t) {
                            a();
                        }
                    });
                }
            });
        });
    },
    player: function(t) {
        var e = this;
        return new Promise(function(a, n) {
            0 == e.globalData.player ? e.request({}, "/weixin/player/info", !0, !1).then(function(n) {
                n.data ? e.bind_player(n.data) : t && (e.globalData.show = t, wx.switchTab({
                    url: "/pages/index/index"
                })), e.globalData.player = n.data, a();
            }) : a();
        });
    },
    request: function(t, e) {
        var a = !(arguments.length > 2 && void 0 !== arguments[2]) || arguments[2], n = !(arguments.length > 3 && void 0 !== arguments[3]) || arguments[3], c = this;
        return n && wx.showLoading({
            title: "数据加载中"
        }), new Promise(function(o, i) {
            t.sessionToken = c.globalData.maUser.sessionToken ? c.globalData.maUser.sessionToken : "", 
            wx.request({
                url: c.globalData.url + e,
                data: t,
                dataType: "json",
                success: function(n) {
                    1e4 == n.data.code ? o(n.data) : "SESSION_NOT_FOUND" == n.data.code ? c.land().then(function() {
                        c.request(t, e).then(o).catch(i);
                    }) : (a && wx.showToast({
                        title: "网络错误",
                        icon: "none"
                    }), i(n.data));
                },
                fail: function(t) {
                    a && wx.showToast({
                        title: "网络错误",
                        icon: "none"
                    }), i(t.data);
                },
                complete: function(t) {
                    n && wx.hideLoading();
                }
            });
        });
    },
    back: function() {
        wx.navigateBack({
            fail: function() {
                wx.switchTab({
                    url: "/pages/index/index"
                });
            }
        });
    },
    uploadFile: function(t, e) {
        var a = this;
        return wx.showLoading({
            title: "数据上传中"
        }), new Promise(function(n, c) {
            wx.uploadFile({
                url: a.globalData.url + e,
                filePath: t.avatarUrl,
                name: "file",
                formData: {
                    sessionToken: a.globalData.maUser.sessionToken
                },
                success: function(t) {
                    1e4 == (t = JSON.parse(t.data)).code ? n(t.data) : (wx.showToast({
                        title: "网络错误",
                        icon: "none"
                    }), c(t.data));
                },
                fail: function(t) {
                    wx.showToast({
                        title: "网络错误",
                        icon: "none"
                    }), c(t.data);
                },
                complete: function(t) {
                    wx.hideLoading();
                }
            });
        });
    },
    bind_player: function(t) {
        return t.avatar = t.avatarId ? this.globalData.url + "/weixin/show/" + t.avatarId : this.globalData.img_url.avatar, 
        t.division_text = [ "青铜段位", "白银段位", "黄金段位", "钻石段位", "王者段位" ][t.division - 1], t.correctRate = t.correctRate + "%", 
        t;
    },
    date_format: function(t, e, a) {
        var n = new Date(t.replace(/-/g, "/")), c = n.getMonth() + 1 < 10 ? "0" + (n.getMonth() + 1) : n.getMonth() + 1, o = n.getDate() < 10 ? "0" + n.getDate() : n.getDate(), i = n.getHours() < 10 ? "0" + n.getHours() : n.getHours(), s = n.getMinutes() < 10 ? "0" + n.getMinutes() : n.getMinutes(), r = n.getSeconds() < 10 ? "0" + n.getSeconds() : n.getSeconds();
        return a ? n.getFullYear() + e + c + e + o + " " + i + ":" + s + ":" + r : n.getFullYear() + e + c + e + o;
    }
});