Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.SuperComponent = void 0;

var e = require("../../../../@babel/runtime/helpers/createClass"), r = require("../../../../@babel/runtime/helpers/classCallCheck"), t = e(function e() {
    r(this, e), this.app = getApp();
});

exports.SuperComponent = t;