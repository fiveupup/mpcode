Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.prefix = exports.default = void 0;

exports.default = {
    prefix: "t"
};

exports.prefix = "t";