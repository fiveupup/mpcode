Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.unitConvert = exports.uniqueFactory = exports.toCamel = exports.throttle = exports.styles = exports.setIcon = exports.isString = exports.isOverSize = exports.isObject = exports.isNumber = exports.isBool = exports.getRect = exports.getInstance = exports.getCurrentPage = exports.getCharacterLength = exports.getAnimationFrame = exports.debounce = exports.classNames = exports.chunk = exports.calcIcon = exports.addUnit = void 0;

var e = require("../../../@babel/runtime/helpers/defineProperty");

require("../../../@babel/runtime/helpers/Arrayincludes");

var t = require("../../../@babel/runtime/helpers/toConsumableArray"), r = require("../../../@babel/runtime/helpers/typeof"), n = require("./config"), o = wx.getSystemInfoSync();

exports.debounce = function(e) {
    var t, r = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : 500;
    return function() {
        for (var n = this, o = arguments.length, a = new Array(o), c = 0; c < o; c++) a[c] = arguments[c];
        t && clearTimeout(t), t = setTimeout(function() {
            e.apply(n, a);
        }, r);
    };
};

exports.throttle = function(e) {
    var t = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : 100, r = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : null, n = 0, o = null;
    return r || (r = {
        leading: !0
    }), function() {
        var a = Date.now();
        n || r.leading || (n = a);
        var c = t - (a - n), i = this;
        if (c <= 0) {
            o && (clearTimeout(o), o = null), n = a;
            for (var u = arguments.length, s = new Array(u), l = 0; l < u; l++) s[l] = arguments[l];
            e.apply(i, s);
        }
    };
};

exports.classNames = function e() {
    for (var n = {}.hasOwnProperty, o = [], a = arguments.length, c = new Array(a), i = 0; i < a; i++) c[i] = arguments[i];
    return c.forEach(function(a) {
        if (a) {
            var c = r(a);
            if ("string" === c || "number" === c) o.push(a); else if (Array.isArray(a) && a.length) {
                var i = e.apply(void 0, t(a));
                i && o.push(i);
            } else if ("object" === c) for (var u in a) n.call(a, u) && a[u] && o.push(u);
        }
    }), o.join(" ");
};

exports.styles = function(e) {
    return Object.keys(e).map(function(t) {
        return "".concat(t, ": ").concat(e[t]);
    }).join("; ");
};

exports.getAnimationFrame = function(e, t) {
    return wx.createSelectorQuery().in(e).selectViewport().boundingClientRect().exec(function() {
        t();
    });
};

exports.getRect = function(e, t) {
    var r = arguments.length > 2 && void 0 !== arguments[2] && arguments[2];
    return new Promise(function(n, o) {
        wx.createSelectorQuery().in(e)[r ? "selectAll" : "select"](t).boundingClientRect(function(e) {
            e ? n(e) : o(e);
        }).exec();
    });
};

var a = function(e) {
    return /^\d+(\.\d+)?$/.test(e);
};

exports.isNumber = a;

exports.addUnit = function(e) {
    if (function(e) {
        return null != e;
    }(e)) return e = String(e), a(e) ? "".concat(e, "px") : e;
};

exports.getCharacterLength = function(e, t, r) {
    if (!t || 0 === t.length) return {
        length: 0,
        characters: ""
    };
    if ("maxcharacter" === e) {
        for (var n = 0, o = 0; o < t.length; o += 1) {
            var a = 0;
            if (n + (a = t.charCodeAt(o) > 127 || 94 === t.charCodeAt(o) ? 2 : 1) > r) return {
                length: n,
                characters: t.slice(0, o)
            };
            n += a;
        }
        return {
            length: n,
            characters: t
        };
    }
    if ("maxlength" === e) {
        var c = t.length > r ? r : t.length;
        return {
            length: c,
            characters: t.slice(0, c)
        };
    }
    return {
        length: t.length,
        characters: t
    };
};

exports.chunk = function(e, t) {
    return Array.from({
        length: Math.ceil(e.length / t)
    }, function(r, n) {
        return e.slice(n * t, n * t + t);
    });
};

exports.getInstance = function(e, t) {
    if (!e) {
        var r = getCurrentPages(), n = r[r.length - 1];
        e = n.$$basePage || n;
    }
    var o = e ? e.selectComponent(t) : null;
    return o || (console.warn("未找到组件,请检查selector是否正确"), null);
};

exports.unitConvert = function(e) {
    var t;
    return "string" == typeof e ? e.includes("rpx") ? parseInt(e, 10) * (null !== (t = null == o ? void 0 : o.screenWidth) && void 0 !== t ? t : 750) / 750 : parseInt(e, 10) : e;
};

exports.setIcon = function(t, n, o) {
    var a, c, i, u;
    return n ? "string" == typeof n ? (e(c = {}, "".concat(t, "Name"), n), e(c, "".concat(t, "Data"), {}), 
    c) : "object" === r(n) ? (e(i = {}, "".concat(t, "Name"), ""), e(i, "".concat(t, "Data"), n), 
    i) : (e(u = {}, "".concat(t, "Name"), o), e(u, "".concat(t, "Data"), {}), u) : (e(a = {}, "".concat(t, "Name"), ""), 
    e(a, "".concat(t, "Data"), {}), a);
};

var c = function(e) {
    return "boolean" == typeof e;
};

exports.isBool = c;

var i = function(e) {
    return "object" === r(e) && null != e;
};

exports.isObject = i;

var u = function(e) {
    return "string" == typeof e;
};

exports.isString = u;

exports.toCamel = function(e) {
    return e.replace(/-(\w)/g, function(e, t) {
        return t.toUpperCase();
    });
};

exports.getCurrentPage = function() {
    var e = getCurrentPages();
    return e[e.length - 1];
};

exports.uniqueFactory = function(e) {
    var t = 0;
    return function() {
        return "".concat(n.prefix, "_").concat(e, "_").concat(t++);
    };
};

exports.calcIcon = function(e, t) {
    return c(e) && e && t || u(e) ? {
        name: c(e) ? t : e
    } : i(e) ? e : null;
};

exports.isOverSize = function(e, t) {
    var r;
    if (!t) return !1;
    var n = {
        B: 1,
        KB: 1e3,
        MB: 1e6,
        GB: 1e9
    };
    return e > ("number" == typeof t ? 1e3 * t : (null == t ? void 0 : t.size) * n[null !== (r = null == t ? void 0 : t.unit) && void 0 !== r ? r : "KB"]);
};