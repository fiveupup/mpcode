var e = require("../../../@babel/runtime/helpers/interopRequireDefault").default;

Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.default = void 0;

var t = require("../../../@babel/runtime/helpers/slicedToArray"), r = require("../../../@babel/runtime/helpers/classCallCheck"), i = require("../../../@babel/runtime/helpers/createClass"), n = require("../../../@babel/runtime/helpers/inherits"), o = require("../../../@babel/runtime/helpers/createSuper"), s = require("../../../@babel/runtime/helpers/typeof"), a = require("../common/src/index"), c = e(require("./props")), l = e(require("../common/config")), f = e(require("../mixins/page-scroll")), u = require("../common/utils"), p = function(e, t, r, i) {
    var n, o = arguments.length, a = o < 3 ? t : null === i ? i = Object.getOwnPropertyDescriptor(t, r) : i;
    if ("object" === ("undefined" == typeof Reflect ? "undefined" : s(Reflect)) && "function" == typeof Reflect.decorate) a = Reflect.decorate(e, t, r, i); else for (var c = e.length - 1; c >= 0; c--) (n = e[c]) && (a = (o < 3 ? n(a) : o > 3 ? n(t, r, a) : n(t, r)) || a);
    return o > 3 && a && Object.defineProperty(t, r, a), a;
}, h = l.default.prefix, d = "".concat(h, "-sticky"), m = ".".concat(d), x = function(e) {
    n(a, e);
    var s = o(a);
    function a() {
        var e;
        return r(this, a), (e = s.apply(this, arguments)).externalClasses = [ "".concat(h, "-class"), "".concat(h, "-class-content") ], 
        e.properties = c.default, e.behaviors = [ (0, f.default)() ], e.observers = {
            "offsetTop, disabled, container": function() {
                this.onScroll();
            }
        }, e.data = {
            prefix: h,
            classPrefix: d,
            containerStyle: "",
            contentStyle: ""
        }, e.methods = {
            onScroll: function(e) {
                var r = this, i = (e || {}).scrollTop, n = this.properties, o = n.container, s = n.offsetTop;
                n.disabled ? this.setDataAfterDiff({
                    isFixed: !1,
                    transform: 0
                }) : (this.scrollTop = i || this.scrollTop, "function" != typeof o ? (0, u.getRect)(this, m).then(function(e) {
                    e && (s >= e.top ? (r.setDataAfterDiff({
                        isFixed: !0,
                        height: e.height
                    }), r.transform = 0) : r.setDataAfterDiff({
                        isFixed: !1
                    }));
                }) : Promise.all([ (0, u.getRect)(this, m), this.getContainerRect() ]).then(function(e) {
                    var i = t(e, 2), n = i[0], o = i[1];
                    n && o && (s + n.height > o.height + o.top ? r.setDataAfterDiff({
                        isFixed: !1,
                        transform: o.height - n.height
                    }) : s >= n.top ? r.setDataAfterDiff({
                        isFixed: !0,
                        height: n.height,
                        transform: 0
                    }) : r.setDataAfterDiff({
                        isFixed: !1,
                        transform: 0
                    }));
                }));
            },
            setDataAfterDiff: function(e) {
                var t = this, r = this.properties.offsetTop, i = this.data, n = i.containerStyle, o = i.contentStyle, s = e.isFixed, a = e.height, c = e.transform;
                wx.nextTick(function() {
                    var e = "", i = "";
                    if (s && (e += "height:".concat(a, "px;"), i += "position:fixed;top:".concat(r, "px;left:0;right:0;")), 
                    c) {
                        var l = "translate3d(0, ".concat(c, "px, 0)");
                        i += "-webkit-transform:".concat(l, ";transform:").concat(l, ";");
                    }
                    n === e && o === i || t.setData({
                        containerStyle: e,
                        contentStyle: i
                    }), t.triggerEvent("scroll", {
                        scrollTop: t.scrollTop,
                        isFixed: s
                    });
                });
            },
            getContainerRect: function() {
                var e = this.properties.container();
                return new Promise(function(t) {
                    return e.boundingClientRect(t).exec();
                });
            }
        }, e;
    }
    return i(a, [ {
        key: "ready",
        value: function() {
            this.onScroll();
        }
    } ]), a;
}(a.SuperComponent), b = x = p([ (0, a.wxComponent)() ], x);

exports.default = b;