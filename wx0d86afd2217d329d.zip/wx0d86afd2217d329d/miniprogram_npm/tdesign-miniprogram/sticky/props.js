Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.default = void 0;

var e = {
    container: {
        type: null
    },
    disabled: {
        type: Boolean,
        value: !1
    },
    externalClasses: {
        type: Array
    },
    offsetTop: {
        type: Number,
        value: 0
    },
    zIndex: {
        type: Number,
        value: 99
    }
};

exports.default = e;