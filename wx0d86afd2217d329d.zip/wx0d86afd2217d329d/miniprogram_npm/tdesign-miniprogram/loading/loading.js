var e = require("../../../@babel/runtime/helpers/interopRequireDefault").default;

Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.default = void 0;

var t = require("../../../@babel/runtime/helpers/classCallCheck"), r = require("../../../@babel/runtime/helpers/createClass"), i = require("../../../@babel/runtime/helpers/inherits"), n = require("../../../@babel/runtime/helpers/createSuper"), s = require("../../../@babel/runtime/helpers/typeof"), a = require("../common/src/index"), l = e(require("../common/config")), o = e(require("./props")), u = function(e, t, r, i) {
    var n, a = arguments.length, l = a < 3 ? t : null === i ? i = Object.getOwnPropertyDescriptor(t, r) : i;
    if ("object" === ("undefined" == typeof Reflect ? "undefined" : s(Reflect)) && "function" == typeof Reflect.decorate) l = Reflect.decorate(e, t, r, i); else for (var o = e.length - 1; o >= 0; o--) (n = e[o]) && (l = (a < 3 ? n(l) : a > 3 ? n(t, r, l) : n(t, r)) || l);
    return a > 3 && l && Object.defineProperty(t, r, l), l;
}, c = l.default.prefix, f = "".concat(c, "-loading"), p = function(e) {
    i(a, e);
    var s = n(a);
    function a() {
        var e;
        return t(this, a), (e = s.apply(this, arguments)).externalClasses = [ "".concat(c, "-class"), "".concat(c, "-class-text"), "".concat(c, "-class-indicator") ], 
        e.data = {
            prefix: c,
            classPrefix: f,
            show: !0
        }, e.options = {
            multipleSlots: !0
        }, e.properties = Object.assign({}, o.default), e.timer = null, e.observers = {
            loading: function(e) {
                var t = this, r = this.properties.delay;
                this.timer && clearTimeout(this.timer), e && r ? this.timer = setTimeout(function() {
                    t.setData({
                        show: e
                    }), t.timer = null;
                }, r) : this.setData({
                    show: e
                });
            }
        }, e.lifetimes = {
            detached: function() {
                clearTimeout(this.timer);
            }
        }, e;
    }
    return r(a, [ {
        key: "refreshPage",
        value: function() {
            this.triggerEvent("reload");
        }
    } ]), a;
}(a.SuperComponent), h = p = u([ (0, a.wxComponent)() ], p);

exports.default = h;