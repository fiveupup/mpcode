var e = require("../../../@babel/runtime/helpers/interopRequireDefault").default;

Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.default = void 0;

var r = require("../../../@babel/runtime/helpers/createClass"), t = require("../../../@babel/runtime/helpers/classCallCheck"), n = require("../../../@babel/runtime/helpers/inherits"), a = require("../../../@babel/runtime/helpers/createSuper"), l = require("../../../@babel/runtime/helpers/typeof"), i = require("../common/src/index"), o = e(require("../common/config")), u = e(require("./props")), s = function(e, r, t, n) {
    var a, i = arguments.length, o = i < 3 ? r : null === n ? n = Object.getOwnPropertyDescriptor(r, t) : n;
    if ("object" === ("undefined" == typeof Reflect ? "undefined" : l(Reflect)) && "function" == typeof Reflect.decorate) o = Reflect.decorate(e, r, t, n); else for (var u = e.length - 1; u >= 0; u--) (a = e[u]) && (o = (i < 3 ? a(o) : i > 3 ? a(r, t, o) : a(r, t)) || o);
    return i > 3 && o && Object.defineProperty(r, t, o), o;
}, p = o.default.prefix, c = "".concat(p, "-collapse"), d = function(e) {
    n(i, e);
    var l = a(i);
    function i() {
        var e;
        return t(this, i), (e = l.apply(this, arguments)).options = {
            addGlobalClass: !0
        }, e.externalClasses = [ "".concat(p, "-class") ], e.relations = {
            "../collapse-panel/collapse-panel": {
                type: "descendant"
            }
        }, e.controlledProps = [ {
            key: "value",
            event: "change"
        } ], e.properties = u.default, e.data = {
            prefix: p,
            classPrefix: c
        }, e.observers = {
            "value, expandMutex ": function() {
                this.updateExpanded();
            }
        }, e.methods = {
            updateExpanded: function() {
                var e = this;
                this.$children.forEach(function(r) {
                    r.updateExpanded(e.properties.value);
                });
            },
            switch: function(e) {
                var r = this.properties, t = r.expandMutex, n = r.value, a = [];
                a = n.indexOf(e) > -1 ? n.filter(function(r) {
                    return r !== e;
                }) : t ? [ e ] : n.concat(e), this._trigger("change", {
                    value: a
                });
            }
        }, e;
    }
    return r(i);
}(i.SuperComponent), f = d = s([ (0, i.wxComponent)() ], d);

exports.default = f;