Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.default = void 0;

var e = {
    defaultExpandAll: {
        type: Boolean,
        value: !1
    },
    disabled: {
        type: Boolean
    },
    expandIcon: {
        type: Boolean,
        value: !0
    },
    expandMutex: {
        type: Boolean,
        value: !1
    },
    theme: {
        type: String,
        value: "default"
    },
    value: {
        type: Array,
        value: null
    },
    defaultValue: {
        type: Array,
        value: []
    }
};

exports.default = e;