Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.default = void 0;

var e = {
    align: {
        type: String,
        value: "middle"
    },
    arrow: {
        type: Boolean,
        value: !1
    },
    bordered: {
        type: Boolean,
        value: !0
    },
    description: {
        type: String
    },
    externalClasses: {
        type: Array
    },
    hover: {
        type: Boolean
    },
    image: {
        type: String
    },
    jumpType: {
        type: String,
        value: "navigateTo"
    },
    leftIcon: {
        type: String
    },
    note: {
        type: String
    },
    required: {
        type: Boolean,
        value: !1
    },
    rightIcon: {
        type: String
    },
    title: {
        type: String
    },
    url: {
        type: String,
        value: ""
    }
};

exports.default = e;