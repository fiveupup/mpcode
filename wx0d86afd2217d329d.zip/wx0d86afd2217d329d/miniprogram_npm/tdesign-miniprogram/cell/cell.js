var e = require("../../../@babel/runtime/helpers/interopRequireDefault").default;

Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.default = void 0;

var t = require("../../../@babel/runtime/helpers/classCallCheck"), r = require("../../../@babel/runtime/helpers/createClass"), l = require("../../../@babel/runtime/helpers/inherits"), c = require("../../../@babel/runtime/helpers/createSuper"), i = require("../../../@babel/runtime/helpers/typeof"), n = require("../common/src/index"), a = e(require("../common/config")), o = e(require("./props")), s = function(e, t, r, l) {
    var c, n = arguments.length, a = n < 3 ? t : null === l ? l = Object.getOwnPropertyDescriptor(t, r) : l;
    if ("object" === ("undefined" == typeof Reflect ? "undefined" : i(Reflect)) && "function" == typeof Reflect.decorate) a = Reflect.decorate(e, t, r, l); else for (var o = e.length - 1; o >= 0; o--) (c = e[o]) && (a = (n < 3 ? c(a) : n > 3 ? c(t, r, a) : c(t, r)) || a);
    return n > 3 && a && Object.defineProperty(t, r, a), a;
}, u = a.default.prefix, p = "".concat(u, "-cell"), f = function(e) {
    l(n, e);
    var i = c(n);
    function n() {
        var e;
        return t(this, n), (e = i.apply(this, arguments)).externalClasses = [ "".concat(u, "-class"), "".concat(u, "-class-title"), "".concat(u, "-class-description"), "".concat(u, "-class-note"), "".concat(u, "-class-hover"), "".concat(u, "-class-image"), "".concat(u, "-class-left"), "".concat(u, "-class-left-icon"), "".concat(u, "-class-right"), "".concat(u, "-class-right-icon") ], 
        e.relations = {
            "../cell-group/cell-group": {
                type: "parent"
            }
        }, e.options = {
            multipleSlots: !0
        }, e.properties = o.default, e.data = {
            prefix: u,
            classPrefix: p,
            isLastChild: !1
        }, e;
    }
    return r(n, [ {
        key: "onClick",
        value: function(e) {
            this.triggerEvent("click", e.detail), this.jumpLink();
        }
    }, {
        key: "jumpLink",
        value: function() {
            var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : "url", t = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : "jumpType", r = this.data[e], l = this.data[t];
            r && wx[l]({
                url: r
            });
        }
    } ]), n;
}(n.SuperComponent), d = f = s([ (0, n.wxComponent)() ], f);

exports.default = d;