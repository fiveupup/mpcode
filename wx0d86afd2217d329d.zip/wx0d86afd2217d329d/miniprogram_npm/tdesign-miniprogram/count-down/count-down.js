var e = require("../../../@babel/runtime/helpers/interopRequireDefault").default;

Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.default = void 0;

var t = require("../../../@babel/runtime/helpers/createClass"), i = require("../../../@babel/runtime/helpers/classCallCheck"), r = require("../../../@babel/runtime/helpers/inherits"), n = require("../../../@babel/runtime/helpers/createSuper"), a = require("../../../@babel/runtime/helpers/typeof"), s = require("../common/src/index"), o = e(require("../common/config")), u = e(require("./props")), c = require("./utils"), m = function(e, t, i, r) {
    var n, s = arguments.length, o = s < 3 ? t : null === r ? r = Object.getOwnPropertyDescriptor(t, i) : r;
    if ("object" === ("undefined" == typeof Reflect ? "undefined" : a(Reflect)) && "function" == typeof Reflect.decorate) o = Reflect.decorate(e, t, i, r); else for (var u = e.length - 1; u >= 0; u--) (n = e[u]) && (o = (s < 3 ? n(o) : s > 3 ? n(t, i, o) : n(t, i)) || o);
    return s > 3 && o && Object.defineProperty(t, i, o), o;
}, l = o.default.prefix, p = "".concat(l, "-count-down"), h = function(e) {
    r(s, e);
    var a = n(s);
    function s() {
        var e;
        return i(this, s), (e = a.apply(this, arguments)).externalClasses = [ "".concat(l, "-class"), "".concat(l, "-class-count"), "".concat(l, "-class-split") ], 
        e.properties = u.default, e.observers = {
            time: function() {
                this.reset();
            }
        }, e.data = {
            prefix: l,
            classPrefix: p,
            timeDataUnit: c.TimeDataUnit,
            timeData: (0, c.parseTimeData)(0),
            formattedTime: "0"
        }, e.timeoutId = null, e.lifetimes = {
            detached: function() {
                this.timeoutId && (clearTimeout(this.timeoutId), this.timeoutId = null);
            }
        }, e.methods = {
            start: function() {
                this.counting || (this.counting = !0, this.endTime = Date.now() + this.remain, this.doCount());
            },
            pause: function() {
                this.counting = !1, this.timeoutId && clearTimeout(this.timeoutId);
            },
            reset: function() {
                this.pause(), this.remain = this.properties.time, this.updateTime(this.remain), 
                this.properties.autoStart && this.start();
            },
            getTime: function() {
                return Math.max(this.endTime - Date.now(), 0);
            },
            updateTime: function(e) {
                var t = this.properties.format;
                this.remain = e;
                var i = (0, c.parseTimeData)(e);
                this.triggerEvent("change", i);
                var r = (0, c.parseFormat)(e, t).timeText, n = t.split(":");
                this.setData({
                    timeRange: n,
                    timeData: i,
                    formattedTime: r.replace(/:/g, " : ")
                }), 0 === e && (this.pause(), this.triggerEvent("finish"));
            },
            doCount: function() {
                var e = this;
                this.timeoutId = setTimeout(function() {
                    var t = e.getTime();
                    e.properties.millisecond ? e.updateTime(t) : (0, c.isSameSecond)(t, e.remain) && 0 !== t || e.updateTime(t), 
                    0 !== t && e.doCount();
                }, 33);
            }
        }, e;
    }
    return t(s);
}(s.SuperComponent), d = h = m([ (0, s.wxComponent)() ], h);

exports.default = d;