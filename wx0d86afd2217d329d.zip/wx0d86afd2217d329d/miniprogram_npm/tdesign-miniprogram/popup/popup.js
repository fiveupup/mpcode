var e = require("../../../@babel/runtime/helpers/interopRequireDefault").default;

Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.default = void 0;

var r = require("../../../@babel/runtime/helpers/createClass"), t = require("../../../@babel/runtime/helpers/classCallCheck"), i = require("../../../@babel/runtime/helpers/inherits"), l = require("../../../@babel/runtime/helpers/createSuper"), n = require("../../../@babel/runtime/helpers/typeof"), s = require("../common/src/index"), a = e(require("../common/config")), o = e(require("./props")), u = e(require("../mixins/transition")), c = function(e, r, t, i) {
    var l, s = arguments.length, a = s < 3 ? r : null === i ? i = Object.getOwnPropertyDescriptor(r, t) : i;
    if ("object" === ("undefined" == typeof Reflect ? "undefined" : n(Reflect)) && "function" == typeof Reflect.decorate) a = Reflect.decorate(e, r, t, i); else for (var o = e.length - 1; o >= 0; o--) (l = e[o]) && (a = (s < 3 ? l(a) : s > 3 ? l(r, t, a) : l(r, t)) || a);
    return s > 3 && a && Object.defineProperty(r, t, a), a;
};

delete o.default.visible;

var p = a.default.prefix, f = "".concat(p, "-popup"), d = function(e) {
    i(s, e);
    var n = l(s);
    function s() {
        var e;
        return t(this, s), (e = n.apply(this, arguments)).externalClasses = [ "".concat(p, "-class"), "".concat(p, "-class-content") ], 
        e.behaviors = [ (0, u.default)() ], e.options = {
            multipleSlots: !0
        }, e.properties = o.default, e.data = {
            prefix: p,
            classPrefix: f
        }, e.methods = {
            handleOverlayClick: function() {
                this.properties.closeOnOverlayClick && this.triggerEvent("visible-change", {
                    visible: !1
                });
            },
            handleClose: function() {
                this.triggerEvent("visible-change", {
                    visible: !1
                });
            }
        }, e;
    }
    return r(s);
}(s.SuperComponent), b = d = c([ (0, s.wxComponent)() ], d);

exports.default = b;