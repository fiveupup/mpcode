var e = require("../../../@babel/runtime/helpers/interopRequireDefault").default;

Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.default = void 0;

var r = require("../../../@babel/runtime/helpers/createClass"), t = require("../../../@babel/runtime/helpers/classCallCheck"), n = require("../../../@babel/runtime/helpers/inherits"), i = require("../../../@babel/runtime/helpers/createSuper"), o = require("../../../@babel/runtime/helpers/typeof"), u = require("../common/src/index"), l = e(require("../common/config")), a = e(require("../mixins/transition")), c = function(e, r, t, n) {
    var i, u = arguments.length, l = u < 3 ? r : null === n ? n = Object.getOwnPropertyDescriptor(r, t) : n;
    if ("object" === ("undefined" == typeof Reflect ? "undefined" : o(Reflect)) && "function" == typeof Reflect.decorate) l = Reflect.decorate(e, r, t, n); else for (var a = e.length - 1; a >= 0; a--) (i = e[a]) && (l = (u < 3 ? i(l) : u > 3 ? i(r, t, l) : i(r, t)) || l);
    return u > 3 && l && Object.defineProperty(r, t, l), l;
}, s = l.default.prefix, p = "".concat(s, "-overlay"), f = function(e) {
    n(u, e);
    var o = i(u);
    function u() {
        var e;
        return t(this, u), (e = o.apply(this, arguments)).properties = {
            zIndex: {
                type: Number,
                value: 11e3
            },
            duration: {
                type: Number,
                value: 300
            },
            backgroundColor: {
                type: String,
                value: ""
            },
            preventScrollThrough: {
                type: Boolean,
                value: !0
            }
        }, e.behaviors = [ (0, a.default)() ], e.data = {
            prefix: s,
            classPrefix: p,
            computedStyle: "",
            _zIndex: 11e3
        }, e.observers = {
            backgroundColor: function(e) {
                this.setData({
                    computedStyle: "background-color: ".concat(e, ";")
                });
            },
            zIndex: function(e) {
                0 !== e && this.setData({
                    _zIndex: e
                });
            }
        }, e.methods = {
            handleClick: function() {
                this.triggerEvent("click", {
                    visible: !this.properties.visible
                });
            },
            noop: function() {}
        }, e;
    }
    return r(u);
}(u.SuperComponent), d = f = c([ (0, u.wxComponent)() ], f);

exports.default = d;