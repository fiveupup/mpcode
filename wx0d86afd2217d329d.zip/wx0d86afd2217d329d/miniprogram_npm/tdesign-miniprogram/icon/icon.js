var e = require("../../../@babel/runtime/helpers/interopRequireDefault").default;

Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.default = void 0;

var t = require("../../../@babel/runtime/helpers/createClass"), r = require("../../../@babel/runtime/helpers/classCallCheck"), i = require("../../../@babel/runtime/helpers/inherits"), n = require("../../../@babel/runtime/helpers/createSuper"), o = require("../../../@babel/runtime/helpers/typeof"), s = require("../common/src/index"), c = e(require("../common/config")), l = e(require("./props")), a = require("../common/utils"), u = function(e, t, r, i) {
    var n, s = arguments.length, c = s < 3 ? t : null === i ? i = Object.getOwnPropertyDescriptor(t, r) : i;
    if ("object" === ("undefined" == typeof Reflect ? "undefined" : o(Reflect)) && "function" == typeof Reflect.decorate) c = Reflect.decorate(e, t, r, i); else for (var l = e.length - 1; l >= 0; l--) (n = e[l]) && (c = (s < 3 ? n(c) : s > 3 ? n(t, r, c) : n(t, r)) || c);
    return s > 3 && c && Object.defineProperty(t, r, c), c;
}, f = c.default.prefix, p = "".concat(f, "-icon"), d = function(e) {
    i(s, e);
    var o = n(s);
    function s() {
        var e;
        return r(this, s), (e = o.apply(this, arguments)).externalClasses = [ "".concat(f, "-class") ], 
        e.properties = l.default, e.data = {
            componentPrefix: f,
            classPrefix: p,
            isImage: !1,
            iconStyle: void 0
        }, e.observers = {
            "name, color, size, style": function() {
                this.setIconStyle();
            }
        }, e.methods = {
            onTap: function(e) {
                this.triggerEvent("click", e.detail);
            },
            setIconStyle: function() {
                var e = this.properties, t = e.name, r = e.color, i = e.size, n = -1 !== t.indexOf("/"), o = (0, 
                a.addUnit)(i), s = n ? {
                    width: o,
                    height: o
                } : {}, c = r ? {
                    color: r
                } : {}, l = i ? {
                    "font-size": o
                } : {};
                this.setData({
                    isImage: n,
                    iconStyle: "".concat((0, a.styles)(Object.assign(Object.assign(Object.assign({}, c), l), s)))
                });
            }
        }, e;
    }
    return t(s);
}(s.SuperComponent), b = d = u([ (0, s.wxComponent)() ], d);

exports.default = b;