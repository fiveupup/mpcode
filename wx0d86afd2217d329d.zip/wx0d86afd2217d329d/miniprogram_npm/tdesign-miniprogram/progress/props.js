Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.default = void 0;

var e = {
    color: {
        type: null,
        value: ""
    },
    externalClasses: {
        type: Array
    },
    label: {
        type: null,
        value: !0
    },
    percentage: {
        type: Number,
        value: 0
    },
    status: {
        type: String
    },
    strokeWidth: {
        type: null
    },
    theme: {
        type: String,
        value: "line"
    },
    trackColor: {
        type: String,
        value: ""
    }
};

exports.default = e;