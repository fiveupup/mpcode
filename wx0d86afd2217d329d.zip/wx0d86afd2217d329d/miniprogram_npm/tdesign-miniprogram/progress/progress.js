var e = require("../../../@babel/runtime/helpers/interopRequireDefault").default;

Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.default = void 0;

var t = require("../../../@babel/runtime/helpers/classCallCheck"), r = require("../../../@babel/runtime/helpers/createClass"), o = require("../../../@babel/runtime/helpers/inherits"), s = require("../../../@babel/runtime/helpers/createSuper"), i = require("../../../@babel/runtime/helpers/typeof"), n = require("../common/src/index"), a = e(require("../common/config")), c = e(require("./props")), u = require("./utils"), l = require("../common/utils"), f = function(e, t, r, o) {
    var s, n = arguments.length, a = n < 3 ? t : null === o ? o = Object.getOwnPropertyDescriptor(t, r) : o;
    if ("object" === ("undefined" == typeof Reflect ? "undefined" : i(Reflect)) && "function" == typeof Reflect.decorate) a = Reflect.decorate(e, t, r, o); else for (var c = e.length - 1; c >= 0; c--) (s = e[c]) && (a = (n < 3 ? s(a) : n > 3 ? s(t, r, a) : s(t, r)) || a);
    return n > 3 && a && Object.defineProperty(t, r, a), a;
}, p = a.default.prefix, h = "".concat(p, "-progress"), m = function(e) {
    o(a, e);
    var n = s(a);
    function a() {
        var e;
        return t(this, a), (e = n.apply(this, arguments)).externalClasses = [ "".concat(p, "-class"), "".concat(p, "-class-bar"), "".concat(p, "-class-label") ], 
        e.options = {
            multipleSlots: !0
        }, e.properties = c.default, e.data = {
            prefix: p,
            classPrefix: h,
            colorBar: "",
            heightBar: "",
            computedStatus: "",
            computedProgress: 0,
            isIOS: !1
        }, e.observers = {
            percentage: function(e) {
                e = Math.max(0, Math.min(e, 100)), this.setData({
                    computedStatus: 100 === e ? "success" : "",
                    computedProgress: e
                });
            },
            color: function(e) {
                this.setData({
                    colorBar: (0, u.getBackgroundColor)(e),
                    colorCircle: "object" === i(e) ? "" : e
                });
            },
            strokeWidth: function(e) {
                if (!e) return "";
                this.setData({
                    heightBar: (0, l.unitConvert)(e)
                });
            },
            theme: function(e) {
                "circle" === e && this.getInnerDiameter();
            },
            trackColor: function(e) {
                this.setData({
                    bgColorBar: e
                });
            }
        }, e.methods = {
            getInnerDiameter: function() {
                var e = this, t = this.properties.strokeWidth, r = ".".concat(h, "__canvas--circle");
                t && (0, l.getRect)(this, r).then(function(r) {
                    e.setData({
                        innerDiameter: r.width - 2 * (0, l.unitConvert)(t)
                    });
                });
            }
        }, e;
    }
    return r(a, [ {
        key: "attached",
        value: function() {
            var e = this;
            wx.getSystemInfo({
                success: function(t) {
                    var r = !!(t.system.toLowerCase().search("ios") + 1);
                    e.setData({
                        isIOS: r
                    });
                },
                fail: function(e) {
                    console.error("progress 获取系统信息失败", e);
                }
            });
        }
    } ]), a;
}(n.SuperComponent), d = m = f([ (0, n.wxComponent)() ], m);

exports.default = d;