Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.getBackgroundColor = function(r) {
    if ("string" == typeof r) return r;
    if (Array.isArray(r)) return r[0] && "#" === r[0][0] && r.unshift("90deg"), "linear-gradient( ".concat(r.join(","), " )");
    var e = r.from, n = r.to, o = r.direction, a = void 0 === o ? "to right" : o, c = t(r, [ "from", "to", "direction" ]), i = Object.keys(c);
    if (i.length) {
        var l = (i = i.sort(function(t, r) {
            return parseFloat(t.substr(0, t.length - 1)) - parseFloat(r.substr(0, r.length - 1));
        })).map(function(t) {
            return "".concat(c[t], " ").concat(t);
        });
        return "linear-gradient(".concat(a, ", ").concat(l.join(","), ")");
    }
    return "linear-gradient(".concat(a, ", ").concat(e, ", ").concat(n, ")");
};

var t = function(t, r) {
    var e = {};
    for (var n in t) Object.prototype.hasOwnProperty.call(t, n) && r.indexOf(n) < 0 && (e[n] = t[n]);
    if (null != t && "function" == typeof Object.getOwnPropertySymbols) {
        var o = 0;
        for (n = Object.getOwnPropertySymbols(t); o < n.length; o++) r.indexOf(n[o]) < 0 && Object.prototype.propertyIsEnumerable.call(t, n[o]) && (e[n[o]] = t[n[o]]);
    }
    return e;
};