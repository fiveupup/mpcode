var e = require("../../../@babel/runtime/helpers/interopRequireDefault").default;

Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.default = void 0, require("../../../@babel/runtime/helpers/Arrayincludes");

var t = require("../../../@babel/runtime/helpers/createClass"), a = require("../../../@babel/runtime/helpers/classCallCheck"), r = require("../../../@babel/runtime/helpers/inherits"), i = require("../../../@babel/runtime/helpers/createSuper"), n = require("../../../@babel/runtime/helpers/typeof"), s = require("../common/src/index"), l = e(require("../common/config")), o = e(require("./props")), p = require("../common/utils"), u = function(e, t, a, r) {
    var i, s = arguments.length, l = s < 3 ? t : null === r ? r = Object.getOwnPropertyDescriptor(t, a) : r;
    if ("object" === ("undefined" == typeof Reflect ? "undefined" : n(Reflect)) && "function" == typeof Reflect.decorate) l = Reflect.decorate(e, t, a, r); else for (var o = e.length - 1; o >= 0; o--) (i = e[o]) && (l = (s < 3 ? i(l) : s > 3 ? i(t, a, l) : i(t, a)) || l);
    return s > 3 && l && Object.defineProperty(t, a, l), l;
}, d = l.default.prefix, c = "".concat(d, "-collapse-panel"), h = function(e) {
    r(s, e);
    var n = i(s);
    function s() {
        var e;
        return a(this, s), (e = n.apply(this, arguments)).externalClasses = [ "".concat(d, "-class"), "".concat(d, "-class-content"), "".concat(d, "-class-header") ], 
        e.options = {
            multipleSlots: !0
        }, e.relations = {
            "../collapse/collapse": {
                type: "ancestor",
                linked: function(e) {
                    var t = e.properties, a = t.value, r = t.expandIcon, i = t.disabled;
                    this.setData({
                        ultimateExpandIcon: r || this.properties.expandIcon,
                        ultimateDisabled: null == this.properties.disabled ? i : this.properties.disabled
                    }), this.updateExpanded(a);
                }
            }
        }, e.properties = o.default, e.data = {
            prefix: d,
            expanded: !1,
            classPrefix: c,
            classBasePrefix: d,
            ultimateExpandIcon: !1,
            ultimateDisabled: !1
        }, e.methods = {
            updateExpanded: function() {
                var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : [];
                if (this.$parent && !this.data.ultimateDisabled) {
                    var t = this.properties.value, a = this.$parent.data.defaultExpandAll, r = a ? !this.data.expanded : e.includes(t);
                    r !== this.properties.expanded && (this.setData({
                        expanded: r
                    }), this.updateStyle(r));
                }
            },
            updateStyle: function(e) {
                var t = this;
                return (0, p.getRect)(this, ".".concat(c, "__content")).then(function(e) {
                    return e.height;
                }).then(function(a) {
                    var r = wx.createAnimation({
                        duration: 0,
                        timingFunction: "ease-in-out"
                    });
                    e ? r.height(a).top(0).step({
                        duration: 300
                    }).height("auto").step() : r.height(a).top(1).step({
                        duration: 1
                    }).height(0).step({
                        duration: 300
                    }), t.setData({
                        animation: r.export()
                    });
                });
            },
            onClick: function() {
                var e = this.data.ultimateDisabled, t = this.properties.value;
                e || (this.$parent.data.defaultExpandAll ? this.updateExpanded() : this.$parent.switch(t));
            }
        }, e;
    }
    return t(s);
}(s.SuperComponent), f = h = u([ (0, s.wxComponent)() ], h);

exports.default = f;