var e = require("../../../@babel/runtime/helpers/interopRequireDefault").default;

Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.default = void 0;

var r = require("../../../@babel/runtime/helpers/createClass"), t = require("../../../@babel/runtime/helpers/classCallCheck"), n = require("../../../@babel/runtime/helpers/inherits"), i = require("../../../@babel/runtime/helpers/createSuper"), a = require("../../../@babel/runtime/helpers/typeof"), l = require("../common/src/index"), o = e(require("../common/config")), c = e(require("./props")), u = require("../common/utils"), s = function(e, r, t, n) {
    var i, l = arguments.length, o = l < 3 ? r : null === n ? n = Object.getOwnPropertyDescriptor(r, t) : n;
    if ("object" === ("undefined" == typeof Reflect ? "undefined" : a(Reflect)) && "function" == typeof Reflect.decorate) o = Reflect.decorate(e, r, t, n); else for (var c = e.length - 1; c >= 0; c--) (i = e[c]) && (o = (l < 3 ? i(o) : l > 3 ? i(r, t, o) : i(r, t)) || o);
    return l > 3 && o && Object.defineProperty(r, t, o), o;
}, p = o.default.prefix, f = "".concat(p, "-badge"), d = (0, u.uniqueFactory)("badge"), b = function(e) {
    n(l, e);
    var a = i(l);
    function l() {
        var e;
        return t(this, l), (e = a.apply(this, arguments)).options = {
            multipleSlots: !0
        }, e.externalClasses = [ "".concat(p, "-class"), "".concat(p, "-class-count"), "".concat(p, "-class-content") ], 
        e.properties = c.default, e.data = {
            prefix: p,
            classPrefix: f,
            value: "",
            labelID: "",
            descriptionID: ""
        }, e.lifetimes = {
            ready: function() {
                var e = d();
                this.setData({
                    labelID: "".concat(e, "_label"),
                    descriptionID: "".concat(e, "_description")
                });
            }
        }, e;
    }
    return r(l);
}(l.SuperComponent), m = b = s([ (0, l.wxComponent)() ], b);

exports.default = m;