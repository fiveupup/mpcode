var e = require("../../../@babel/runtime/helpers/interopRequireDefault").default;

Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.default = void 0;

var t = require("../../../@babel/runtime/helpers/classCallCheck"), r = require("../../../@babel/runtime/helpers/createClass"), a = require("../../../@babel/runtime/helpers/inherits"), i = require("../../../@babel/runtime/helpers/createSuper"), n = require("../../../@babel/runtime/helpers/typeof"), l = require("../common/src/index"), u = e(require("./props")), o = function(e, t, r, a) {
    var i, l = arguments.length, u = l < 3 ? t : null === a ? a = Object.getOwnPropertyDescriptor(t, r) : a;
    if ("object" === ("undefined" == typeof Reflect ? "undefined" : n(Reflect)) && "function" == typeof Reflect.decorate) u = Reflect.decorate(e, t, r, a); else for (var o = e.length - 1; o >= 0; o--) (i = e[o]) && (u = (l < 3 ? i(u) : l > 3 ? i(t, r, u) : i(t, r)) || u);
    return l > 3 && u && Object.defineProperty(t, r, u), u;
}, s = e(require("../common/config")).default.prefix, p = "".concat(s, "-tab-panel"), c = function(e) {
    a(l, e);
    var n = i(l);
    function l() {
        var e;
        return t(this, l), (e = n.apply(this, arguments)).externalClasses = [ "".concat(s, "-class") ], 
        e.relations = {
            "../tabs/tabs": {
                type: "ancestor"
            }
        }, e.options = {
            multipleSlots: !0
        }, e.properties = u.default, e.data = {
            prefix: s,
            classPrefix: p,
            active: !1,
            hide: !0,
            id: ""
        }, e.observers = {
            "label, badgeProps, disabled, icon, panel, value": function() {
                this.update();
            }
        }, e;
    }
    return r(l, [ {
        key: "setId",
        value: function(e) {
            this.setData({
                id: e
            });
        }
    }, {
        key: "getComputedName",
        value: function() {
            return null != this.properties.value ? "".concat(this.properties.value) : "".concat(this.index);
        }
    }, {
        key: "update",
        value: function() {
            var e;
            null === (e = this.$parent) || void 0 === e || e.updateTabs();
        }
    }, {
        key: "render",
        value: function(e, t) {
            this.setData({
                active: e,
                hide: !t.data.animation && !e
            });
        }
    } ]), l;
}(l.SuperComponent), d = c = o([ (0, l.wxComponent)() ], c);

exports.default = d;