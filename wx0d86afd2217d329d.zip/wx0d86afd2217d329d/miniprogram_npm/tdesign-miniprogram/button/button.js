var e = require("../../../@babel/runtime/helpers/interopRequireDefault").default;

Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.default = void 0;

var t = require("../../../@babel/runtime/helpers/createClass"), a = require("../../../@babel/runtime/helpers/classCallCheck"), n = require("../../../@babel/runtime/helpers/inherits"), i = require("../../../@babel/runtime/helpers/createSuper"), r = require("../../../@babel/runtime/helpers/typeof"), s = require("../common/src/index"), o = e(require("../common/config")), c = e(require("./props")), l = require("../common/version"), u = require("../common/utils"), h = function(e, t, a, n) {
    var i, s = arguments.length, o = s < 3 ? t : null === n ? n = Object.getOwnPropertyDescriptor(t, a) : n;
    if ("object" === ("undefined" == typeof Reflect ? "undefined" : r(Reflect)) && "function" == typeof Reflect.decorate) o = Reflect.decorate(e, t, a, n); else for (var c = e.length - 1; c >= 0; c--) (i = e[c]) && (o = (s < 3 ? i(o) : s > 3 ? i(t, a, o) : i(t, a)) || o);
    return s > 3 && o && Object.defineProperty(t, a, o), o;
}, d = o.default.prefix, p = "".concat(d, "-button"), f = function(e) {
    n(s, e);
    var r = i(s);
    function s() {
        var e;
        return a(this, s), (e = r.apply(this, arguments)).externalClasses = [ "".concat(d, "-class"), "".concat(d, "-class-icon"), "".concat(d, "-class-loading") ], 
        e.behaviors = (0, l.canIUseFormFieldButton)() ? [ "wx://form-field-button" ] : [], 
        e.properties = c.default, e.options = {
            multipleSlots: !0
        }, e.data = {
            prefix: d,
            className: "",
            classPrefix: p
        }, e.observers = {
            "theme, size, plain, block, shape, disabled, loading, variant": function() {
                this.setClass();
            },
            icon: function(e) {
                var t = (0, u.setIcon)("icon", e, "");
                this.setData(Object.assign({}, t));
            }
        }, e.lifetimes = {
            attached: function() {
                this.setClass();
            }
        }, e.methods = {
            setClass: function() {
                var e = [ p, "".concat(d, "-class"), "".concat(p, "--").concat(this.data.variant || "base"), "".concat(p, "--").concat(this.data.theme || "default"), "".concat(p, "--").concat(this.data.shape || "rectangle"), "".concat(p, "--size-").concat(this.data.size || "medium") ];
                this.data.block && e.push("".concat(p, "--block")), this.data.disabled && e.push("".concat(p, "--disabled")), 
                this.data.ghost && e.push("".concat(p, "--ghost")), this.setData({
                    className: e.join(" ")
                });
            },
            getuserinfo: function(e) {
                this.triggerEvent("getuserinfo", e.detail);
            },
            contact: function(e) {
                this.triggerEvent("contact", e.detail);
            },
            getphonenumber: function(e) {
                this.triggerEvent("getphonenumber", e.detail);
            },
            error: function(e) {
                this.triggerEvent("error", e.detail);
            },
            opensetting: function(e) {
                this.triggerEvent("opensetting", e.detail);
            },
            launchapp: function(e) {
                this.triggerEvent("launchapp", e.detail);
            },
            chooseavatar: function(e) {
                this.triggerEvent("chooseavatar", e.detail);
            },
            handleTap: function(e) {
                this.data.disabled || this.data.loading || this.triggerEvent("tap", e);
            }
        }, e;
    }
    return t(s);
}(s.SuperComponent), g = f = h([ (0, s.wxComponent)() ], f);

exports.default = g;