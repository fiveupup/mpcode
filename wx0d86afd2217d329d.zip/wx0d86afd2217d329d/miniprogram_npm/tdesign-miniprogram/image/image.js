var e = require("../../../@babel/runtime/helpers/interopRequireDefault").default;

Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.default = void 0;

var t = require("../../../@babel/runtime/helpers/createClass"), i = require("../../../@babel/runtime/helpers/classCallCheck"), r = require("../../../@babel/runtime/helpers/inherits"), a = require("../../../@babel/runtime/helpers/createSuper"), n = require("../../../@babel/runtime/helpers/typeof"), s = require("../common/src/index"), o = e(require("./props")), c = e(require("../common/config")), l = require("../common/utils"), d = function(e, t, i, r) {
    var a, s = arguments.length, o = s < 3 ? t : null === r ? r = Object.getOwnPropertyDescriptor(t, i) : r;
    if ("object" === ("undefined" == typeof Reflect ? "undefined" : n(Reflect)) && "function" == typeof Reflect.decorate) o = Reflect.decorate(e, t, i, r); else for (var c = e.length - 1; c >= 0; c--) (a = e[c]) && (o = (s < 3 ? a(o) : s > 3 ? a(t, i, o) : a(t, i)) || o);
    return s > 3 && o && Object.defineProperty(t, i, o), o;
}, h = c.default.prefix, u = "".concat(h, "-image"), p = function(e) {
    r(s, e);
    var n = a(s);
    function s() {
        var e;
        return i(this, s), (e = n.apply(this, arguments)).externalClasses = [ "".concat(h, "-class"), "".concat(h, "-class-load") ], 
        e.options = {
            multipleSlots: !0
        }, e.properties = o.default, e.data = {
            prefix: h,
            isLoading: !0,
            isFailed: !1,
            innerStyle: "",
            classPrefix: u
        }, e.preSrc = "", e.lifetimes = {
            attached: function() {
                var e = this.data, t = e.width, i = e.height;
                this.update(), this.calcSize(t, i);
            }
        }, e.observers = {
            src: function() {
                this.preSrc !== this.properties.src && this.update();
            },
            "width, height": function(e, t) {
                this.calcSize(e, t);
            }
        }, e.methods = {
            onLoaded: function(e) {
                var t = this, i = wx.getSystemInfoSync().SDKVersion.split(".").map(function(e) {
                    return parseInt(e, 10);
                }), r = this.properties.mode, a = i[0] < 2 || 2 === i[0] && i[1] < 10 || 2 === i[0] && 10 === i[1] && i[2] < 3;
                if ("heightFix" === r && a) {
                    var n = e.detail, s = n.height, o = n.width;
                    (0, l.getRect)(this, "#image").then(function(e) {
                        var i = e.height, r = (i / s * o).toFixed(2);
                        t.setData({
                            innerStyle: "height: ".concat((0, l.addUnit)(i), "; width: ").concat(r, "px;")
                        });
                    });
                }
                this.setData({
                    isLoading: !1,
                    isFailed: !1
                }), this.triggerEvent("load", e.detail);
            },
            onLoadError: function(e) {
                this.setData({
                    isLoading: !1,
                    isFailed: !0
                }), this.triggerEvent("error", e.detail);
            },
            calcSize: function(e, t) {
                var i = "";
                e && (i += "width: ".concat((0, l.addUnit)(e), ";")), t && (i += "height: ".concat((0, 
                l.addUnit)(t), ";")), this.setData({
                    innerStyle: i
                });
            },
            update: function() {
                var e = this.properties.src;
                this.preSrc = e, e ? this.setData({
                    isLoading: !0,
                    isFailed: !1
                }) : this.onLoadError({
                    errMsg: "图片链接为空"
                });
            }
        }, e;
    }
    return t(s);
}(s.SuperComponent), f = p = d([ (0, s.wxComponent)() ], p);

exports.default = f;