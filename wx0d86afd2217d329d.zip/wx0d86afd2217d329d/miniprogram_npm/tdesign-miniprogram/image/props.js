Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.default = void 0;

var e = {
    error: {
        type: String,
        value: "default"
    },
    externalClasses: {
        type: Array
    },
    height: {
        type: null
    },
    lazy: {
        type: Boolean,
        value: !1
    },
    loading: {
        type: String,
        value: "default"
    },
    mode: {
        type: String,
        value: "scaleToFill"
    },
    shape: {
        type: String,
        value: "square"
    },
    showMenuByLongpress: {
        type: Boolean,
        value: !1
    },
    src: {
        type: String,
        value: ""
    },
    webp: {
        type: Boolean,
        value: !1
    },
    width: {
        type: null
    }
};

exports.default = e;