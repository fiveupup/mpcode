var t = getApp();

Component({
    data: {
        url: "index"
    },
    attached: function() {
        this.setData({
            img_url: t.globalData.img_url,
            avatarUrl: t.globalData.img_url.avatar
        });
    },
    methods: {
        chooseUrl: function(t) {
            this.filter(function() {
                wx.switchTab({
                    url: "/pages/" + t.currentTarget.dataset.url + "/" + t.currentTarget.dataset.url
                });
            });
        },
        dict_type: function() {
            var a = this;
            t.request({}, "/weixin/dict/type/ORIGIN_TYPE").then(function(t) {
                a.setData({
                    type_list: t.data
                });
            });
        },
        type_picker: function(t) {
            this.setData({
                type_index: t.detail.value,
                origin: this.data.type_list[t.detail.value].dictValue
            });
        },
        region_type: function() {
            var a = this;
            t.request({}, "/weixin/oragan/listWithSubList/1").then(function(t) {
                var i = [], e = t.data, n = t.data[0].subList, s = t.data[0].subList[0].subList;
                i.push(e), i.push(n), i.push(s), a.setData({
                    organization: t.data,
                    region_list: i
                });
            });
        },
        region_picker: function(t) {
            this.setData({
                region_text: this.data.region_list[0][t.detail.value[0]].text + " - " + this.data.region_list[1][t.detail.value[1]].text + " - " + this.data.region_list[2][t.detail.value[2]].text,
                region: this.data.region_list[2][t.detail.value[2]].key
            });
        },
        bindcolumnchange: function(t) {
            var a, i = null !== (a = this.data.region_index) && void 0 !== a ? a : [ 0, 0, 0 ];
            i[t.detail.column] = t.detail.value;
            for (var e = t.detail.column; e < 2; e++) i[e + 1] = 0;
            this.setData({
                region_index: i
            });
            var n = [];
            n.push(this.data.organization), n.push(this.data.organization[i[0]].subList), n.push(this.data.organization[i[0]].subList[i[1]].subList), 
            this.setData({
                region_list: n
            });
        },
        show: function(t) {
            this.setData({
                visible: !0
            });
        },
        hide: function(t) {
            this.setData({
                visible: !1
            });
        },
        onVisibleChange: function(t) {
            this.setData({
                visible: t.detail.visible
            });
        },
        onChooseAvatar: function(t) {
            this.setData({
                avatarUrl: t.detail.avatarUrl,
                hasAvatar: !0
            });
        },
        onSubmit: function(a) {
            var i = this;
            a.detail.value.nickname ? i.data.region ? i.data.origin ? i.data.hasAvatar ? t.uploadFile({
                avatarUrl: i.data.avatarUrl
            }, "/weixin/player/upload").then(function(t) {
                i.editMaUser({
                    nickname: a.detail.value.nickname,
                    oid: i.data.region,
                    origin: i.data.origin,
                    avatarId: t.id
                });
            }) : i.editMaUser({
                nickname: a.detail.value.nickname,
                oid: i.data.region,
                origin: i.data.origin
            }) : wx.showToast({
                icon: "error",
                title: "请选择用户类型"
            }) : wx.showToast({
                icon: "error",
                title: "请选择城市"
            }) : wx.showToast({
                icon: "error",
                title: "请输入昵称"
            });
        },
        editMaUser: function(a) {
            var i = this;
            t.request(a, "/weixin/player/enroll").then(function(a) {
                wx.showToast({
                    icon: "success",
                    title: "注册成功"
                }), i.setData({
                    visible: !1
                }), t.globalData.player = t.bind_player(a.data);
                var e = getCurrentPages();
                e[e.length - 1].setData({
                    player: t.globalData.player
                });
            });
        },
        filter: function(a) {
            t.globalData.player ? a() : "boolean" != typeof t.globalData.player && (this.dict_type(), 
            this.region_type(), this.setData({
                visible: !0
            }));
        }
    }
});