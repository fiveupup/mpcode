function e(e, n) {
    if (!(e instanceof n)) throw new TypeError("Cannot call a class as a function");
}

Object.defineProperty(exports, "__esModule", {
    value: !0
});

var n = function() {
    function e(e, n) {
        for (var t = 0; t < n.length; t++) {
            var o = n[t];
            o.enumerable = o.enumerable || !1, o.configurable = !0, "value" in o && (o.writable = !0), 
            Object.defineProperty(e, o.key, o);
        }
    }
    return function(n, t, o) {
        return t && e(n.prototype, t), o && e(n, o), n;
    };
}(), t = void 0, o = function() {
    function o() {
        return e(this, o), t || ((t = this).mute = !0 === wx.getStorageSync("mute"), t.loadAudios()), 
        t;
    }
    return n(o, [ {
        key: "loadAudios",
        value: function() {
            this.audioSources = {
                "button-click": "/assets/audio/button-click.mp3",
                swish: "/assets/audio/swish.mp3",
                erase: "/assets/audio/erase.mp3",
                "pencil-writing": "/assets/audio/pencil-writing.mp3",
                tada: "/assets/audio/tada.mp3",
                correct: "/assets/audio/correct.mp3",
                "game-end": "/assets/audio/game-end.mp3",
                silence: "/assets/audio/silence45s.mp3",
                "count-down": "/assets/audio/count-down.mp3"
            };
        }
    } ], [ {
        key: "play",
        value: function(e) {
            var n = arguments.length > 1 && void 0 !== arguments[1] && arguments[1];
            if (t.mute || !wx.createInnerAudioContext) return null;
            if (t.audioSources[e]) {
                var o = wx.createInnerAudioContext();
                return o.src = t.audioSources[e], o.loop = n, o.play(), n ? o.onStop(function() {
                    o.destroy();
                }) : o.onEnded(function() {
                    o.destroy();
                }), o.onError(function(e) {
                    console.log("Audio context error: ", e), o.destroy();
                }), o;
            }
            return console.error("Cannot find audio source for key", e), null;
        }
    }, {
        key: "setMute",
        value: function(e) {
            t.mute = e, wx.setStorageSync("mute", e);
        }
    }, {
        key: "getMute",
        value: function() {
            return t.mute;
        }
    }, {
        key: "playSilentBackground",
        value: function() {
            t.silentBackground || (t.silentBackground = this.play("silence", !0)), t.silentBackground && t.silentBackground.play();
        }
    } ]), o;
}();

exports.default = o, new o();