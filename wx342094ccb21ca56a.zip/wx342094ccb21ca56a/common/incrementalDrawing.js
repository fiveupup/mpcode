Object.defineProperty(exports, "__esModule", {
    value: !0
});

exports.IncrementalDrawingEvent = {
    TOUCH_START: "t_s",
    TOUCH_MOVE: "t_m",
    CLEAR: "clear",
    SKIP: "skip"
};