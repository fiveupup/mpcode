function e(e, n) {
    if (!(e instanceof n)) throw new TypeError("Cannot call a class as a function");
}

function n() {
    u.pingJobInstance && (clearTimeout(u.pingJobInstance), u.pingJobInstance = void 0);
}

function r() {
    u.pingJobInstance = setTimeout(i, a);
}

function i() {
    n(), new Promise(function(e, n) {
        if (null == s.User.current()) {
            var r = "AV.User.current() is null";
            return console.log("Ping - Error", r), void n(r);
        }
        try {
            t.invokeHttpRequest("ping", c.config.ping_api, {
                uid: s.User.current().id
            }, "POST", "", function(n) {
                console.log("Ping - Success"), e(n);
            }, function(e) {
                console.log("Ping - Failed", e), n(e);
            }, {
                retrying: !1
            });
        } catch (r) {
            console.log("Ping - Error", r), n(r);
        }
    }).then(r).catch(r);
}

function o() {
    return u = void 0, new l();
}

Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.MetricsPingScheduler = void 0, exports.clearPingJobInstance = n, exports.pingJob = i, 
exports.reset = o;

var t = function(e) {
    if (e && e.__esModule) return e;
    var n = {};
    if (null != e) for (var r in e) Object.prototype.hasOwnProperty.call(e, r) && (n[r] = e[r]);
    return n.default = e, n;
}(require("../game/api/rpcLayer.js")), c = require("../game/config.js"), s = require("../libs/av-live-query-weapp-min"), u = void 0, a = 6e4, l = exports.MetricsPingScheduler = function n() {
    return e(this, n), u || (this.pingJobInstance = void 0, u = this), u;
};

o();