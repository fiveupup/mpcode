function e(e) {
    return e && e.__esModule ? e : {
        default: e
    };
}

function t(e) {
    if (e && e.__esModule) return e;
    var t = {};
    if (null != e) for (var n in e) Object.prototype.hasOwnProperty.call(e, n) && (t[n] = e[n]);
    return t.default = e, t;
}

var n = t(require("./game/api/gameAPI.js")), o = require("./game/config.js"), a = e(require("./game/api/playHistoryAPI.js")), i = e(require("./game/api/quotaAPI.js")), r = t(require("./game/eventlog.js")), s = require("./common/initState.js"), c = e(require("./common/soundFXController.js")), l = t(require("./game/utils.js")), u = t(require("./common/metricsPingScheduler.js")), g = e(require("./game/themeUtils.js")), h = require("./libs/av-live-query-weapp-min"), d = require("./game/config/configManager"), f = require("./libs/WXBizDataCrypt"), p = require("./game/models/group"), v = require("./game/models/specialAccount"), m = "http://www.gstatic.com/qilin/drawtogether/share_card.png";

App({
    APP_ID: "wx342094ccb21ca56a",
    networkType: void 0,
    userInfo: void 0,
    systemInfo: void 0,
    alert: void 0,
    onLaunch: function(e) {
        console.log("Launch options: ", e), this.registerCallbacksForUpdateManager(), this.ops = e, 
        this.initEnvSync(), this.initLeanCloudSync(), this.initGetNetworkTypeListener(), 
        this.reload(), this.pkRooms = {};
    },
    setLoadingTarget: function() {
        var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : "";
        this.loadingTarget = e;
    },
    redirectToHome: function() {
        wx.redirectTo({
            url: "/pages/home/home"
        });
    },
    initGetNetworkTypeListener: function() {
        var e = this;
        wx.getNetworkType && wx.getNetworkType({
            success: function(t) {
                e.networkType = t.networkType;
            }
        }), wx.onNetworkStatusChange && wx.onNetworkStatusChange(function(t) {
            e.networkType = t.networkType;
        });
    },
    initEnvSync: function() {
        var e = wx.getSystemInfoSync();
        this.systemInfo = e, this.ops && this.ops.query && this.ops.query.env ? d.setEnv(this.ops.query.env) : e && "devtools" === e.platform ? d.setEnv(d.DEV_ENV) : d.setEnv(d.DEFAULT_ENV);
    },
    initLeanCloudSync: function() {
        h.init(d.getLeanCloudAppIdAndKey());
    },
    navigateIfApplicable: function() {
        return !!this.loadingTarget && (wx.navigateTo({
            url: this.loadingTarget
        }), this.loadingTarget = "", !0);
    },
    checkAuth: function() {
        return new Promise(function(e, t) {
            wx.getSetting({
                success: function(n) {
                    n && n.authSetting && n.authSetting["scope.userInfo"] ? e(n) : (console.log("check auth failed"), 
                    t(new Error("not authorized")));
                },
                fail: function(e) {
                    console.log("check auth failed:", e), t(e);
                }
            });
        });
    },
    reload: function() {
        var e = this;
        console.log("app.reload"), this.setInitState(s.InitState.LOADING), this.checkAuth().then(this.initialize).catch(function(t) {
            e.setInitState(s.InitState.AUTH_DENY);
        });
    },
    reloadLight: function() {
        var e = this;
        console.log("app.reloadLight"), this.setInitState(s.InitState.LOADING), this.checkAuth().then(this.checkQuota().then(function(t) {
            e.setInitState(s.InitState.SUCCESS);
        }).catch(function(t) {
            e.setInitState(s.InitState.FAIL), e.reportInitFail(t.cause, t.code);
        })).catch(function(t) {
            e.setInitState(s.InitState.AUTH_DENY);
        }), d.loadConfig().then(function() {
            console.log("reloadLight loadConfig success!");
        }).catch(function() {
            console.log("reloadLight loadConfig failed!");
        });
    },
    initialize: function() {
        var e = this;
        this.login().then(this.onLoginSucceed.bind(this)).catch(function(t) {
            console.error("Initial login failed. Retrying... Error: ", t.message), h.User.logOut(), 
            e.login().then(e.onLoginSucceed.bind(e)).catch(function(t) {
                console.error("Second login attempt failed. Giving up. Error: ", t.message), e.setInitState(s.InitState.FAIL), 
                e.reportInitFail(t.message, s.InitFailAction.LOGIN), h.User.logOut(), wx.clearStorageSync();
            });
        });
    },
    onHide: function() {
        console.log("Hide the application!!"), u.clearPingJobInstance(), this.closeActiveGameHandler && (this.closeActiveGameHandler(), 
        delete this.closeActiveGameHandler);
    },
    onShow: function(e) {
        console.log("Show the application!!", e), u.pingJob(), this.ops = e, this.getInitState() !== s.InitState.LOADING && (this.getInitState() === s.InitState.SUCCESS ? this.reloadLight() : this.reload());
        var t = r.reset();
        t.version = o.config.client_version, t.scene = e.scene, t.sharer_user_id = e.query.uid, 
        t.referer_id = e.query.referer_id, t.share_template_name = e.query.share_template_name, 
        t.landing_page = e.path, r.logEvent("open", t.data()), c.default.playSilentBackground();
    },
    checkQuota: function() {
        var e = wx.getStorageSync("appPermitGotTime") || 0, t = (new Date() - e) / 1e3 / 60;
        return console.log("app permit diff time: ", t), t > 10 ? new Promise(function(e, t) {
            i.default.checkAppPermitQuota().then(function() {
                wx.setStorageSync("appPermitGotTime", new Date()), e(!0);
            }).catch(function(e) {
                var n = s.InitFailAction.CHECK_QUOTA;
                e.lastRes && e.lastRes.statusCode && (n = (s.InitFailAction.CHECK_QUOTA_ERRCODE_BASE + e.lastRes.statusCode).toString()), 
                t({
                    code: n,
                    cause: e
                });
            });
        }) : Promise.resolve(!0);
    },
    checkAlert: function() {
        var e = this;
        return new Promise(function(t, n) {
            new h.Query(v).equalTo("account", h.User.current()).find().then(function(n) {
                n.length >= 1 && (e.alert = n), t();
            }).catch(function(e) {
                n({
                    code: s.InitFailAction.CHECK_ALERT_FAIL,
                    cause: e
                });
            });
        });
    },
    reportInitFail: function(e, t) {
        var n = r.getContext().data();
        n.action = t, r.logEvent("init_fail", n), this.initFailAction = t;
    },
    onError: function(e) {},
    login: function() {
        var e = h.User.current();
        return e ? e.isAuthenticated().then(function(t) {
            return t ? e : h.User.loginWithWeapp();
        }) : h.User.loginWithWeapp();
    },
    onLoginSucceed: function(e) {
        var t = this;
        this.leancloudUserId = e.id, wx.getUserInfo({
            success: function(n) {
                delete n.userInfo.gender, delete n.userInfo.city, delete n.userInfo.province, delete n.userInfo.country, 
                t.userInfo = n.userInfo;
                var o = n.userInfo;
                e.set("userInfo", n.userInfo), e.set("nickName", o.nickName), e.set("avatarUrl", o.avatarUrl), 
                e.set("language", o.language), e.save();
            },
            fail: function(e) {
                console.log("Failed to get user info:", e);
            }
        }), Promise.all([ this.checkAlert(), this.checkQuota(), a.default.initialFetch(e), d.loadConfig() ]).then(function() {
            t.alert ? t.setInitState(s.InitState.ALERT) : t.setInitState(s.InitState.SUCCESS), 
            u.pingJob(), d.configEnabled(d.enableNewCnLogo) && (m = "http://www.gstatic.com/qilin/drawtogether/new-share_card.png");
            var e = t.getPromotedTheme();
            if (e) {
                m = "http://www.gstatic.com/qilin/drawtogether/" + e + "_share_card.png";
                var n = r.getContext();
                n.app_theme = e, r.logEvent("open", n.data());
            }
        }).catch(function(e) {
            console.log("Init failed:", e), t.setInitState(s.InitState.FAIL), t.reportInitFail(e.cause, e.code);
        }), 1044 == this.ops.scene && this.getShareInfo(this.ops.shareTicket), this.ops.query.uid && e.id != this.ops.query.uid && e.follow(this.ops.query.uid);
    },
    setInitState: function(e) {
        console.log("Init state:", e), this._initStatus = e;
    },
    getInitState: function() {
        return this._initStatus;
    },
    getShareInfo: function(e) {
        wx.getShareInfo({
            shareTicket: e,
            complete: function(e) {
                var t = h.User.current().get("authData").lc_weapp.session_key, o = new f(getApp().APP_ID, t).decryptData(e.encryptedData, e.iv);
                console.log("decrypted data: ", o), o && n.getOrCreate(p, "openGId", o.openGId).then(function(e) {
                    e.addMember(h.User.current().id), e.save();
                });
            }
        });
    },
    createShareMessage: function(e) {
        var t = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : m;
        if (d.getEnv() !== d.PROD_ENV && e.path && (e.path = this.appendUrlArg(e.path, "env", d.getEnv())), 
        t && (e.imageUrl = t), e.template) {
            var n = l.pickRandomShareTemplate(e.template, e.templateArg);
            e.title = n.message, e.path = this.appendUrlArg(e.path, "share_template_name", n.template);
        }
        return e;
    },
    appendUrlArg: function(e, t, n) {
        return e.indexOf("?") < 0 ? e += "?" : e += "&", e += t + "=" + n;
    },
    onShareSuccess: function(e) {
        r.logEvent("share_success", r.getContext().data()), e.shareTickets && this.getShareInfo(e.shareTickets[0]);
    },
    setNavigationBar: function() {
        var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : o.config.app_title, t = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : "light";
        "light" == t ? wx.setNavigationBarColor({
            frontColor: "#000000",
            backgroundColor: "white"
        }) : "underwater" == t ? wx.setNavigationBarColor({
            frontColor: "#000000",
            backgroundColor: "#FFFFFF"
        }) : "land" == t ? wx.setNavigationBarColor({
            frontColor: "#000000",
            backgroundColor: "#FBBC04"
        }) : "to-outerspace" == t ? wx.setNavigationBarColor({
            frontColor: "#ffffff",
            backgroundColor: "#34A853"
        }) : "outerspace" == t ? wx.setNavigationBarColor({
            frontColor: "#ffffff",
            backgroundColor: "#185ABC"
        }) : "final-congrat" == t ? wx.setNavigationBarColor({
            frontColor: "#ffffff",
            backgroundColor: "#185ABC"
        }) : g.default.isValidTheme(t) ? wx.setNavigationBarColor({
            frontColor: g.default.getThemeConfig(t).navBarFrontColor,
            backgroundColor: g.default.getThemeConfig(t).navBarBgColor
        }) : t.endsWith("-congrat") && g.default.isValidTheme(t.substr(0, t.length - 8)) && (t = t.substr(0, t.length - 8), 
        wx.setNavigationBarColor({
            frontColor: g.default.getThemeConfig(t).congratNavBarFrontColor,
            backgroundColor: g.default.getThemeConfig(t).congratNavBarBgColor
        })), wx.setNavigationBarTitle({
            title: e
        });
    },
    getPromotedTheme: function() {
        var e = d.getArrayValue("PROMOTED_THEMES", []);
        return e && e.length ? e[0] : void 0;
    },
    popupNewAppVersionUpdate: function(e) {
        var t = this;
        if (wx.getUpdateManager) {
            var n = wx.getUpdateManager();
            e > 0 ? wx.showModal({
                title: "版本更新",
                content: "是否重启以应用小歌的新版本？",
                success: function(o) {
                    o.confirm ? n.applyUpdate() : setTimeout(function() {
                        t.popupNewAppVersionUpdate(e - 1);
                    }, 6e4);
                }
            }) : wx.showModal({
                title: "版本更新",
                content: "请重启以应用小歌的新版本哦！",
                showCancel: !1,
                complete: function() {
                    n.applyUpdate();
                }
            });
        }
    },
    registerCallbacksForUpdateManager: function() {
        var e = this;
        if (wx.getUpdateManager) {
            var t = wx.getUpdateManager();
            t.onCheckForUpdate(function(e) {
                console.log("updateManager onCheckForUpdate:", e.hasUpdate);
            }), t.onUpdateReady(function() {
                e.popupNewAppVersionUpdate(2);
            }), t.onUpdateFailed(function() {
                console.log("updateManager onUpdateFailed!");
            });
        } else console.log("getUpdateManager not available!");
    },
    currentRound: void 0,
    invitedCompetition: void 0,
    lastPkData: void 0,
    setLastPkData: function(e) {
        this.lastPkData = e;
    },
    getLastPkData: function() {
        return this.lastPkData;
    }
});