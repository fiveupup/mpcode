function e(e) {
    return e && e.__esModule ? e : {
        default: e
    };
}

var t = e(require("../../game/svgUtils.js")), o = function(e) {
    if (e && e.__esModule) return e;
    var t = {};
    if (null != e) for (var o in e) Object.prototype.hasOwnProperty.call(e, o) && (t[o] = e[o]);
    return t.default = e, t;
}(require("../../game/api/gameAPI.js")), i = e(require("../../common/soundFXController.js")), n = e(require("../../game/imageEncoding.js")), r = require("../../game/config.js"), a = require("../../common/initState"), d = require("../../libs/av-live-query-weapp-min").User, s = require("../../libs/underscore/underscore.modified"), u = require("../../game/models/words"), c = require("../../game/config/configManager");

Page({
    data: {
        user: null,
        appName: r.config.app_name,
        loaded: !1
    },
    showLoading: function() {
        !this._showLoading && wx.showLoading && (this._showLoading = !0, wx.showLoading({
            title: "加载中"
        }));
    },
    hideLoading: function() {
        this._showLoading && wx.hideLoading && (this._showLoading = !1, wx.hideLoading());
    },
    initMenu: function() {
        wx.showShareMenu && wx.showShareMenu({
            withShareTicket: !0
        });
    },
    onLoad: function(e) {
        this.initMenu();
    },
    onShow: function(e) {
        var t = this;
        if (this.setData({
            enableNewCnLogo: c.configEnabled(c.enableNewCnLogo)
        }), getApp().getInitState() === a.InitState.LOADING) return this.showLoading(), 
        void setTimeout(function() {
            t.onShow();
        }, 300);
        if (this.hideLoading(), getApp().getInitState() === a.InitState.SUCCESS) if (s.isEmpty(e) && (e = getApp().ops.query), 
        e.scene) {
            var i = decodeURIComponent(e.scene), n = !!i && i.split("&");
            n && n.length > 2 && "m2" == n[0] ? this.showWithCompetitionAndRoundNumber(n[1], n[2]) : (console.log("Unrecognized scene:", i), 
            this.redirectToHome());
        } else e.cId && e.roundNumber ? this.showWithCompetitionAndRoundNumber(e.cId, e.roundNumber) : e.recordId ? o.fetchRecord(e.recordId).then(function(e) {
            t.setData({
                user: e.get("user")
            }), t.showRoundDetails(e.get("word"), JSON.parse(e.get("image")), e.get("recognized"), e.get("duration"));
        }).catch(function(e) {
            getApp().redirectToHome();
        }) : (console.log("Unrecognized single image inv entrance options: ", e), getApp().redirectToHome()); else getApp().redirectToHome();
    },
    showWithCompetitionAndRoundNumber: function(e, t) {
        var i = this;
        o.fetchCompetition(e).then(function(e) {
            if (e.get("deleted")) getApp().redirectToHome(); else {
                i.theme = e.get("theme"), i.setData({
                    user: e.get("user"),
                    theme: i.theme
                });
                var o = e.get("result");
                if (o && o.detailed && o.detailed.length > t) {
                    var n = o.detailed[t];
                    i.showRoundDetails(n.word, n.drawing, n.recognized, n.duration);
                } else getApp().redirectToHome();
            }
        }).catch(function(e) {
            getApp().redirectToHome();
        });
    },
    onUnload: function() {
        this.hideLoading(), this.loaded = !1;
    },
    showRoundDetails: function(e, o, i, r) {
        var a = u.getAllWords(), d = a && a[e] && a[e].wordZhCn ? a[e].wordZhCn : e, s = n.default.decode(o), c = t.default.createSvgBase64FromSegments(s, 250, 200, {
            padding: 25
        }), g = Math.floor(10 * r) / 10;
        this.setData({
            drawingSvg: c,
            wordZhCn: d,
            recognized: i,
            duration: g,
            loaded: !0
        });
    },
    buttonStartDrawing: function() {
        if (!this.disableButtonClick) {
            this.disableButtonClick = !0;
            var e = "/pages/endless/endless";
            this.theme && (e += "?theme=" + this.theme), wx.redirectTo({
                url: e
            });
        }
    },
    buttonGoHome: function() {
        getApp().redirectToHome();
    },
    onShareAppMessage: function() {
        var e = d.current();
        return getApp().createShareMessage({
            template: "shareTemplateCommon",
            path: "/pages/home/home?uid=" + e.id,
            success: function(e) {
                getApp().onShareSuccess(e);
            }
        });
    },
    playClickSound: function() {
        i.default.play("button-click");
    }
});