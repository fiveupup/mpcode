function e(e) {
    return e && e.__esModule ? e : {
        default: e
    };
}

var t = e(require("../../game/api/generateShareResultAPI.js")), a = e(require("../../common/soundFXController.js")), n = function(e) {
    if (e && e.__esModule) return e;
    var t = {};
    if (null != e) for (var a in e) Object.prototype.hasOwnProperty.call(e, a) && (t[a] = e[a]);
    return t.default = e, t;
}(require("../../game/eventlog.js")), s = require("../../game/config.js");

Page({
    data: {},
    onLoad: function(e) {
        var t = getApp().getLastPkData(), a = getApp().getLastPkData().roundDetail;
        wx.setNavigationBarTitle({
            title: a.wordDisplay
        }), this.userChallengeId = t.userChallengeId, this.numPlayer = a.numSuccess + a.numFail, 
        this.wordDisplay = a.wordDisplay, this.resultStatus = a.resultStatus, this.setData(a), 
        this.setData({
            resultStatusDisplay: s.config.pkSingleImagePageStatusDisplay[this.resultStatus]
        });
    },
    onReady: function() {},
    onShow: function() {},
    onHide: function() {},
    onUnload: function() {
        wx.setNavigationBarTitle({
            title: "本局结果"
        });
    },
    onPullDownRefresh: function() {},
    onReachBottom: function() {},
    onShareAppMessage: function() {
        var e = {
            path: "/pages/pkSingleLanding/pkSingleLanding?ucid=" + this.userChallengeId + "&rid=" + this.data.roundId,
            template: "shareTemplatePkSingle" + this.resultStatus,
            success: function(e) {
                getApp().onShareSuccess(e);
            }
        };
        e.templateArg = {
            numPlayer: this.numPlayer,
            wordDisplay: this.wordDisplay
        };
        var a = t.default.getShareCardRequest({
            challengeId: this.data.challengeId,
            roundNumber: this.data.roundId,
            userId: this.data.myUserId
        });
        return getApp().createShareMessage(e, a);
    },
    playClickSound: function() {
        a.default.play("button-click");
    },
    saveToAlbum: function() {
        var e = this;
        t.default.checkSaveImagePermission(function() {
            var t = n.getContext().data();
            t.user_challenge_id = e.userChallengeId, t.round_id = e.data.roundId, n.logEvent("singe_image_gen", t), 
            e.createSharePhoto(function(t) {
                e.showSavedPhotoDialog(t);
            });
        });
    },
    createSharePhoto: function(e) {
        var a = {
            challengeId: this.data.challengeId,
            userId: this.data.myUserId,
            userChallengeId: this.userChallengeId,
            roundNumber: this.data.roundId
        };
        return t.default.generatePkShareResult(a, e);
    },
    catchTap: function() {},
    dismissSavedPhoto: function() {
        this.setData({
            savedPhotoDialogClass: ""
        });
    },
    showSavedPhotoDialog: function(e) {
        a.default.play("button-click"), this.setData({
            savedPhotoDialogClass: "visible",
            savedPhotoImageSrc: e
        });
    }
});