var e = function(e) {
    if (e && e.__esModule) return e;
    var t = {};
    if (null != e) for (var i in e) Object.prototype.hasOwnProperty.call(e, i) && (t[i] = e[i]);
    return t.default = e, t;
}(require("../../game/api/gameAPI.js")), t = function(e) {
    return e && e.__esModule ? e : {
        default: e
    };
}(require("../../game/pkResultUtil.js")), i = require("../../common/initState.js"), o = require("../../game/config.js");

Page({
    data: {},
    onLoad: function(e) {
        if (e.scene) {
            var t = decodeURIComponent(e.scene), i = !!t && t.split("&");
            i && i.length >= 2 && (e.ucid = i[0], e.rid = i[1]);
        }
        return e.ucid ? e.rid ? (wx.setNavigationBarTitle({
            title: "本局结果"
        }), this.ucid = e.ucid, this.rid = e.rid, void (this.loaded = !0)) : (console.log("Field rid not found"), 
        void getApp().redirectToHome()) : (console.log("Field ucid not found"), void getApp().redirectToHome());
    },
    onStartTapHandler: function() {
        wx.redirectTo({
            url: "/pages/pk/pk"
        });
    },
    onReady: function() {},
    showLoading: function() {
        !this._showLoading && wx.showLoading && (this._showLoading = !0, wx.showLoading({
            title: "加载中"
        }));
    },
    hideLoading: function() {
        this._showLoading && wx.hideLoading && (this._showLoading = !1, wx.hideLoading());
    },
    onShow: function() {
        var n = this;
        if (this.loaded) {
            if (getApp().getInitState() === i.InitState.LOADING) return this.showLoading(), 
            void setTimeout(function() {
                n.onShow();
            }, 300);
            this.hideLoading(), getApp().getInitState() === i.InitState.SUCCESS ? e.fetchChallengeDataFromLeanCloud(this.ucid).then(function(e) {
                wx.hideLoading();
                var i = e.formatChallengeResult(), a = i.myUserId, d = Object.assign({
                    myAvatarUrl: e.get("user").get("avatarUrl"),
                    myNickName: e.get("user").get("nickName"),
                    totalUser: i.userRankList.length
                }, t.default.getRoundDetail(i.rounds[n.rid], a));
                n.setData(d), n.setData({
                    resultStatusDisplay: o.config.pkSingleLandingPageStatusDisplay[d.resultStatus]
                });
            }).catch(function(e) {
                console.log("Fetch userChallenge by (ucid, rid) failed:", e), getApp().redirectToHome();
            }) : getApp().redirectToHome();
        }
    },
    onHide: function() {},
    onUnload: function() {},
    onPullDownRefresh: function() {},
    onReachBottom: function() {},
    onShareAppMessage: function() {}
});