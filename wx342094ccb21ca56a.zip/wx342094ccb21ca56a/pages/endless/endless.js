function e(e) {
    return e && e.__esModule ? e : {
        default: e
    };
}

var t = function(e) {
    if (e && e.__esModule) return e;
    var t = {};
    if (null != e) for (var a in e) Object.prototype.hasOwnProperty.call(e, a) && (t[a] = e[a]);
    return t.default = e, t;
}(require("../../game/utils.js")), a = e(require("../../game/themeUtils.js")), r = require("../../game/controllers/endlessGameController.js"), o = e(require("../../game/api/generateShareResultAPI.js")), s = require("../../libs/av-live-query-weapp-min").User, n = require("../../game/config/configManager");

Page({
    data: {
        isPartyMode: !1
    },
    onLoad: function(e) {
        e && e.isPartyMode && this.setData({
            isPartyMode: !0
        }), wx.showShareMenu && wx.showShareMenu({
            withShareTicket: !0
        });
        var t = getApp().invitedCompetition;
        this.gameController = new r.EndlessGameController(this, t), e.theme && (this.gameController.theme = e.theme), 
        t && t.get("user").id == s.current().id ? this.gameController.showEndCardWithCompetition(t) : (this.gameController.prepareGame(), 
        this.gameController.openGame()), this.user = s.current();
    },
    onReady: function() {},
    onShow: function() {
        this.gameController.showGame();
    },
    onHide: function() {
        this.gameController.hideGame();
    },
    onUnload: function() {
        this.gameController && (this.gameController.unload(), this.gameController.reset()), 
        getApp().invitedCompetition = void 0;
    },
    onPullDownRefresh: function() {},
    onReachBottom: function() {},
    onShareAppMessage: function() {
        if (this.shareTempleteThemeFinal) return getApp().createShareMessage({
            template: "shareTemplateThemeComplete",
            path: "/pages/theme/theme",
            success: function(e) {
                getApp().onShareSuccess(e);
            }
        }, "http://www.gstatic.com/qilin/drawtogether/kfc/kfc-all-complete-share-card.png");
        var e = this.gameController.getCompetition(), r = t.toParamStr({
            source: "wxcard",
            mode: "endless",
            uid: this.user.id,
            cid: e ? e.id : ""
        });
        this.data.isPartyMode && this.gameController.isGameEnded() && (r = t.toParamStr({
            mode: "gdd",
            source: "wxcard",
            ranking: this.gameController.cardsView.data.rank,
            totalPlayerCount: this.gameController.cardsView.data.total_players,
            uid: this.user.id,
            cid: e ? e.id : ""
        }));
        var s = {
            path: "/pages/challenge/challenge" + r,
            success: function(e) {
                getApp().onShareSuccess(e);
            }
        };
        if (this.gameController.isGameEnded()) {
            var i = e.get("result").total.round_pass;
            if (this.data.isPartyMode) {
                s.template = "shareTemplateGddResult";
                var l = o.default.getShareCardRequest({
                    totalPlayerCount: this.gameController.cardsView.data.total_players - 1,
                    ranking: this.gameController.cardsView.data.rank,
                    roundCount: this.gameController.cardsView.data.total_pass,
                    userId: this.user.id
                });
                return getApp().createShareMessage(s, l);
            }
            this.gameController.theme && a.default.hasShareTemplate(this.gameController.theme) ? s.template = "shareTemplateThemedEndGame_" + this.gameController.theme : s.template = "shareTemplateEndGame";
            var h = t.getThemeScheme(i + 1, this.gameController.theme);
            return s.templateArg = i, n.configEnabled(n.enableNewCnLogo) ? getApp().createShareMessage(s, "http://www.gstatic.com/qilin/drawtogether/new_sharecards/" + i + "-" + h + "-new.png") : getApp().createShareMessage(s, "http://www.gstatic.com/qilin/drawtogether/sharecards/" + i + "-" + h + ".png");
        }
        return s.template = "shareTemplateCommon", getApp().createShareMessage(s);
    }
});