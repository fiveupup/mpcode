var e = require("../../game/config.js");

Page({
    data: {
        appName: e.config.app_name,
        enableNewCnLogo: !1
    },
    handleGetUserInfo: function(e) {
        "getUserInfo:ok" == e.detail.errMsg && (getApp().reload(), getApp().redirectToHome());
    }
});