function e(e) {
    if (e && e.__esModule) return e;
    var t = {};
    if (null != e) for (var r in e) Object.prototype.hasOwnProperty.call(e, r) && (t[r] = e[r]);
    return t.default = e, t;
}

function t(e) {
    return e && e.__esModule ? e : {
        default: e
    };
}

var r = require("../../game/mockData.js"), i = t(require("../../game/api/generateShareResultAPI.js")), a = t(require("../../game/api/playHistoryAPI.js")), n = t(require("../../common/soundFXController.js")), s = t(require("../../game/svgUtils.js")), o = t(require("../../game/themeUtils.js")), h = e(require("../../game/api/gameAPI.js")), u = e(require("../../game/utils.js")), d = e(require("../../game/eventlog.js")), g = require("../../game/widgets/popup.js"), c = t(require("../../game/imageEncoding.js")), l = require("../../game/config/configManager"), m = require("../../libs/av-live-query-weapp-min").User, p = {
    "皮蛋瘦肉粥": "比皮蛋瘦肉粥还瘦！",
    "香辣鸡腿堡": "只加鸡腿不加班！",
    "香脆薯饼": "有薯饼，没猫饼！",
    "太阳蛋": "做个小太阳，浑身正能量！",
    "肯德基爷爷": "新年肯定行大运！",
    "棒棒的华夫": "荣“华夫”贵向我砸来！",
    "K咖啡": "举手投足，非常大咖！",
    "老北京鸡肉卷": "卷走TA的心！",
    "薯条": "薯我最旺！",
    "劲爆鸡米花": "手握两朵花：有钱花，随便花！",
    "汤圆": "源来，有你就是团圆。",
    "炸鸡": "成为当红炸子鸡！",
    "黄金鸡块": "家里有矿，黄金万两！",
    "安心油条": "头发飘逸，人不油腻！",
    "葡式蛋挞": "生活处处有彩蛋！",
    "鲜蔬沙拉": "我行，我素！",
    "花筒冰淇淋": "成为TA的小甜心！",
    "全家桶": "阖家欢乐，桶桶发财！",
    "香辣鸡翅": "运势无敌，翼飞冲天！",
    "香甜粟米棒": "吃嘛嘛香，身体倍儿棒！"
};

Page({
    data: {
        gallerys: []
    },
    onLoad: function(e) {
        if (wx.showShareMenu && wx.showShareMenu({
            withShareTicket: !0
        }), this.round = getApp().currentRound || r.gameround, !this.round) throw new Error("Cannot find current round!");
        this.setData({
            recognized: this.isRecognized()
        }), this.popup = new g.PopupView(this), this.competitionId = e.cId, e.theme && (this.theme = e.theme), 
        getApp().setNavigationBar(this.round.wordZhCn, this.theme || "light"), this.setData({
            theme: this.theme
        }), this.showRoundDetails();
    },
    isRecognized: function() {
        return void 0 === this.round.recognized || this.round.recognized;
    },
    showRoundDetails: function() {
        var e = p[this.round.wordZhCn];
        void 0 === e ? this.setData({
            roundDetailText: "在默默地观察大家的画作之后，小歌学会了" + this.round.wordZhCn + "的画法",
            myDrawing: this.round.drawingSvg
        }) : this.setData({
            roundDetailText: "2019，我的心愿是：" + e,
            myDrawing: this.round.drawingSvg
        }), this.next = 0, this.hasNext = void 0 === this.round.recognized || this.round.recognized, 
        this.reportedDrawings = {}, this.hasNext && this.fetchAndShowGallery();
    },
    handleLongPress: function(e) {
        var t = this, r = e.currentTarget.dataset.id;
        this.reportedDrawings[r] || this.popup.showAlert("举报不当画作", "我认为该画作有不恰当的地方", "确认举报", function() {
            h.reportDrawing(r, m.current()).then(function() {
                t.reportedDrawings[r] = !0, wx.showToast({
                    title: "你已举报该画作",
                    icon: "success"
                });
            }).catch(function(e) {
                wx.showToast({
                    title: "举报失败",
                    image: "/assets/icon/cross.png"
                });
            });
        });
    },
    playClickSound: function() {
        n.default.play("button-click");
    },
    shareImageToMoment: function() {
        var e = this;
        i.default.checkSaveImagePermission(function() {
            var t = d.getContext().data();
            t.recognized = e.isRecognized() ? 1 : 0, d.logEvent("singe_image_gen", t), e.createSharePhoto(function(t) {
                e.showSavedPhotoDialog(t);
            });
        });
    },
    createSharePhoto: function(e) {
        var t = this.getShareRequestParameters();
        return t.levelStr = a.default.getLatestPlayHistory().getLevelStr(), t.userId = m.current().id, 
        i.default.generateShareResult(t, e);
    },
    catchTap: function() {},
    dismissSavedPhoto: function() {
        this.setData({
            savedPhotoDialogClass: ""
        });
    },
    showSavedPhotoDialog: function(e) {
        n.default.play("button-click"), this.setData({
            savedPhotoDialogClass: "visible",
            savedPhotoImageSrc: e
        });
    },
    fetchAndShowGallery: function() {
        var e = this;
        return h.fetchGallery(this.round.word, this.next).then(function(t) {
            if (0 == t.length && 0 == e.data.gallerys.length) return console.log("End of records reached"), 
            void (e.hasNext = !1);
            for (var r = [], i = 0; i < t.length; i++) {
                var a = void 0, n = void 0;
                l.configEnabled(l.FETCH_GALLERY_FROM_API_SERVER) ? (a = t[i].image, n = t[i].objectId) : (a = t[i].get("image"), 
                n = t[i].getObjectId()), r.push({
                    svg: s.default.createSvgBase64FromSegments(c.default.decode(JSON.parse(a)), 180, 120, {
                        padding: 10
                    }),
                    record_id: n
                });
            }
            e.setData({
                gallerys: e.data.gallerys.concat(r)
            }), e.next++;
        }).catch(function(e) {
            throw new Error(e);
        });
    },
    onReachBottom: function() {
        this.hasNext && this.fetchAndShowGallery();
    },
    onShareAppMessage: function() {
        var e = m.current(), t = this.getShareRequestParameters(), r = this.getShareRequestParametersWithUid(e), a = "/pages/singleImageInvitation/singleImageInvitation" + u.toParamStr(r), n = void 0;
        this.theme && o.default.hasShareTemplate(this.theme) ? (n = this.isRecognized() ? "shareTemplateThemedSingleDrawingSuccess_" : "shareTemplateThemedSingleDrawingFail_", 
        n += this.theme) : n = this.isRecognized() ? "shareTemplateSingleDrawingSuccess" : "shareTemplateSingleDrawingFail";
        var s = this.round.wordZhCn;
        return console.log(this.theme, this.round.wordZhCn), console.log(p[this.round.wordZhCn]), 
        "kfc" === this.theme && (s = p[this.round.wordZhCn]), getApp().createShareMessage({
            template: n,
            templateArg: s,
            path: a,
            success: function(e) {
                getApp().onShareSuccess(e);
            }
        }, i.default.getShareCardRequest(t));
    },
    getShareRequestParameters: function() {
        var e = {};
        return this.competitionId ? (e.cId = this.competitionId, e.roundNumber = this.round.level ? this.round.level - 1 : this.round.round - 1) : (e.cId = this.round.competitionId, 
        e.roundNumber = this.round.round - 1), this.theme && o.default.hasShareTemplate(this.theme) && (e.theme = this.theme), 
        e;
    },
    getShareRequestParametersWithUid: function(e) {
        var t = this.getShareRequestParameters();
        return t.uid = e.id, t;
    }
});