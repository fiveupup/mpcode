function e(e) {
    return e && e.__esModule ? e : {
        default: e
    };
}

var t = e(require("../../common/soundFXController.js")), a = e(require("../../game/svgUtils.js")), o = e(require("../../game/tooltipUtils.js")), s = function(e) {
    if (e && e.__esModule) return e;
    var t = {};
    if (null != e) for (var a in e) Object.prototype.hasOwnProperty.call(e, a) && (t[a] = e[a]);
    return t.default = e, t;
}(require("../../game/api/gameAPI.js")), n = e(require("../../game/api/playHistoryAPI.js")), i = e(require("../../game/imageEncoding.js")), r = require("../../libs/av-live-query-weapp-min").User, u = require("../../libs/underscore/underscore.modified"), h = require("../../game/models/words"), l = void 0;

Page({
    data: {
        words: "",
        showAll: !0,
        showWord: !1,
        user: r.current(),
        totalNum: 0,
        fetchSuccess: !0,
        hasMore: !0
    },
    onLoad: function(e) {
        var t = this;
        wx.setNavigationBarTitle({
            title: "我的画作"
        }), wx.showShareMenu && wx.showShareMenu({
            withShareTicket: !0
        }), this.setData({
            user: r.current().toJSON()
        });
        var c = n.default.getLatestPlayHistory(), d = getApp().getPromotedTheme();
        l = h.getAllWords(), this.setData({
            showPromotionBanner: !!d
        }), d && (this.setData({
            theme: d
        }), this.theme = d);
        var g = c.getExp() < 300 || c.getExp() < u.size(l);
        g || getApp().setNavigationBar("我的画作", "outerspace");
        var p = d, m = c.getThemePassedWords(p).length, w = h.getThemeWords(p).length;
        this.setData({
            progressData: c.getLevelUpProgress(),
            userLevel: c.getLevelStr(),
            showTooltip: o.default.shouldShow("collection"),
            hasMore: g,
            showProgressBottom: !1,
            themePassedWordsCount: m,
            themeWordsCount: w,
            showBadge: w > 0 && m === w
        }), wx.showLoading && wx.showLoading({
            title: "加载中"
        }), s.fetchCollections(r.current()).then(function(e) {
            u.each(e, function(e) {
                var t = e.get("word");
                l[t] && (l[t].status = l[t].status || e.get("recognized"), e.get("recognized") && (l[t].drawingSvg = a.default.createSvgBase64FromSegments(i.default.decode(JSON.parse(e.get("image"))), 120, 120, {
                    padding: 0
                }), l[t].competitionId = e.get("competition").id, l[t].round = e.get("round")));
            }), t.setDataWithMultipleSegements(l), wx.hideLoading && wx.hideLoading();
        }).catch(function(e) {
            wx.hideLoading && wx.hideLoading(), t.setData({
                fetchSuccess: !1
            }), wx.showToast({
                title: "加载失败请重试",
                image: "/assets/icon/cross.png"
            });
        });
    },
    setDataWithMultipleSegements: function(e) {
        var t = 0, a = [], o = [];
        u.each(e, function(e, s, n) {
            t % 10 == 0 && (o.push({}), a.push(0)), t++, o[o.length - 1][s] = e;
        }), console.log("bucketIndex length: " + a.length);
        var s = u.pick(e, function(e, t, a) {
            return e.status;
        });
        this.setData({
            bucketIndex: a,
            totalNum: Object.keys(s).length
        }), this.setDataInSequence(o, 0);
    },
    setDataInSequence: function(e, t) {
        var a = this;
        if (!(t >= e.length)) {
            var o = {};
            o["words[" + t + "]"] = e[t], this.setData(o), u.defer(function() {
                a.setDataInSequence(e, t + 1);
            });
        }
    },
    playClickSound: function(e) {
        t.default.play("button-click");
    },
    handleCollectionTap: function(e) {
        this.playClickSound();
        var t = e.currentTarget.dataset.index;
        l[t].competitionId && l[t].round && (o.default.tickCount("collection"), getApp().currentRound = l[t], 
        wx.navigateTo({
            url: "/pages/roundDetail/roundDetail"
        }));
    },
    showAllToggle: function(e) {
        this.setData({
            showAll: e.detail.value
        });
    },
    onShareAppMessage: function() {
        var e = r.current();
        return getApp().createShareMessage({
            template: "shareTemplateCommon",
            path: "/pages/home/home?uid=" + e.id,
            success: function(e) {
                getApp().onShareSuccess(e);
            }
        }, null);
    },
    handlePlayTheme: function() {
        if (!this.disableButtonClick) {
            var e = "/pages/endless/endless";
            this.theme && (e += "?theme=" + this.theme), this.disableButtonClick = !0, (wx.reLaunch ? wx.reLaunch : wx.redirectTo)({
                url: e
            });
        }
    },
    handleBannerTap: function() {
        this.playClickSound(), this.theme ? wx.navigateTo({
            url: "/pages/theme/theme?theme=" + this.theme
        }) : getApp().redirectToHome();
    },
    handleBadgeTap: function() {
        this.playClickSound(), this.theme ? wx.navigateTo({
            url: "/pages/theme/theme?theme=" + this.theme
        }) : getApp().redirectToHome();
    }
});