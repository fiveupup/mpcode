function o(o) {
    return o && o.__esModule ? o : {
        default: o
    };
}

var t = require("../../game/controllers/roomController.js"), e = require("../../common/challengeStatus.js"), n = function(o) {
    if (o && o.__esModule) return o;
    var t = {};
    if (null != o) for (var e in o) Object.prototype.hasOwnProperty.call(o, e) && (t[e] = o[e]);
    return t.default = o, t;
}(require("../../game/api/playAPI.js")), r = require("../../common/initState.js"), a = o(require("../../game/api/generateShareResultAPI.js")), i = o(require("../../common/soundFXController.js")), s = require("../../libs/av-live-query-weapp-min.js").User, l = require("../../libs/underscore/underscore.modified"), h = require("../../game/config/configManager");

Page({
    data: {
        showQRCode: !1,
        isCountingDown: !1
    },
    initMenu: function() {
        wx.showShareMenu && wx.showShareMenu({
            withShareTicket: !0
        });
    },
    onLoad: function(o) {
        if (o.scene) {
            var t = decodeURIComponent(o.scene);
            this.targetRoom = t ? t.split("&")[1] : void 0;
        } else l.isEmpty(o) ? this.targetRoom = void 0 : this.targetRoom = o.room;
        this.loaded = !0, this.initMenu(), this.setData({
            gameOverCardClass: ""
        });
    },
    showGameOverCard: function() {
        var o = this;
        this.setData({
            gameOverCardClass: "visible"
        }, function() {
            setTimeout(function() {
                wx.redirectTo({
                    url: "/pages/pkResult/pkResult"
                });
            }, 1e3);
        }), setTimeout(function() {
            o.data.gameOverFailed || o.setData({
                gameOverFailed: "timeOut"
            });
        }, 1e4);
    },
    showErrorPage: function(o) {
        console.log("showerrorpage"), this.status = e.ChallengeStatus.CHALLENGE_STATUS_ERROR;
        var t = "", n = "动作太慢了";
        4302 === o ? t = "该房间人数已经满了哦" : 4314 === o ? t = "该局已经开始了哦" : o && -1 !== o ? t = "该房间已经关闭了哦 (" + (o + 1573) + ")" : n = "网络不给力!", 
        this.setData({
            status: this.status,
            errTitle: n,
            errText: t
        });
    },
    onReady: function() {},
    onShow: function(o) {
        var t = this;
        if (this.isForeground = !0, this.loaded) {
            if (getApp().getInitState() === r.InitState.LOADING) return this.showLoading(), 
            void setTimeout(function() {
                t.onShow();
            }, 300);
            this.hideLoading(), getApp().getInitState() === r.InitState.SUCCESS ? (wx.setNavigationBarTitle({
                title: "好友同玩"
            }), this.user = s.current(), this.setData({
                competitorsPlaceholder: Array(7),
                myAvatarUrl: this.user.get("avatarUrl"),
                pkChallengeTime: h.getIntValue(h.PK_CHALLENGE_TIME),
                enableNewCnLogo: h.configEnabled(h.enableNewCnLogo)
            }), this.ensureUserOptIn() && this.joinRoom()) : getApp().redirectToHome();
        }
    },
    ensureUserOptIn: function() {
        return !!wx.getStorageSync("pk.userOptIn") || (this.showInfo("授权使用你的微信头像与名字", "在接下来的同玩模式中，我们将会取用你的微信头像与名字。一同游玩的其他用户可能也会看到此信息。如果你不同意，可以点选取消离开。", "取消", "同意"), 
        !1);
    },
    showInfo: function(o, t, e, n) {
        this.setData({
            infoTheme: "profile",
            infoTitle: o,
            infoMessage: t,
            buttonTextCancel: e,
            buttonTextAccept: n,
            showInfo: !0
        });
    },
    ensureUserOptInButtonAccept: function() {
        this.setData({
            showInfo: !1
        }), wx.setStorageSync("pk.userOptIn", !0), this.joinRoom();
    },
    ensureUserOptInButtonCancel: function() {
        this.setData({
            showInfo: !1
        }), this.onBackHomeHandler();
    },
    joinRoom: function() {
        var o = this, r = this.targetRoom;
        r || this.status !== e.ChallengeStatus.CHALLENGE_STATUS_WAIT || this.roomController && this.roomController.getRoomName() && (r = this.roomController.getRoomName()), 
        n.initPlay(this.user).then(function() {
            o.roomController || (o.roomController = new t.RoomController(o), o.gameController = o.roomController.gameController, 
            o.setData({
                isHost: !r
            }), o.context = wx.createCanvasContext("pie-clock")), o.showLoading(), r ? (console.log("Attempting to join room", r), 
            o.roomController.joinRoom(r).then(function() {
                o.gameController && o.gameController.status === e.ChallengeStatus.CHALLENGE_STATUS_PLAY ? o.gameController.showGame() : (console.log("pk: join room success"), 
                o.status = e.ChallengeStatus.CHALLENGE_STATUS_WAIT, o.setData({
                    status: o.status
                }), console.log("this data set")), o.hideLoading();
            }).catch(function(t) {
                console.log("pk: join room failed"), console.log(t), o.hideLoading(), o.showErrorPage(t.code);
            })) : (console.log("Attempting to create room"), o.setData({
                players: [ {
                    avatarUrl: o.user.get("userInfo").avatarUrl,
                    nickName: o.user.get("userInfo").nickName
                } ],
                playersPlaceholder: 6
            }), o.roomController.createAndJoinRoom().then(function() {
                o.status = e.ChallengeStatus.CHALLENGE_STATUS_WAIT, o.setData({
                    status: o.status
                }), o.hideLoading();
            }).catch(function(t) {
                console.log("Create and Join Room Error", t), o.hideLoading(), o.showErrorPage(t.code);
            }));
        }).catch(function(t) {
            console.log("Init Play Error", t), o.showErrorPage(t.code);
        });
    },
    drawPieClock: function(o) {
        var t = this, e = 0;
        o.forEach(function(o) {
            e += o.data;
        });
        var n = 1.5 * Math.PI;
        o.map(function(o) {
            return o.proportion = o.data / e, o.startAngle = n, n += 2 * Math.PI * o.proportion, 
            o;
        }).forEach(function(o) {
            t.context.beginPath(), t.context.setFillStyle(o.color), t.context.moveTo(30, 30), 
            t.context.arc(30, 30, 15, o.startAngle, o.startAngle + 2 * Math.PI * o.proportion), 
            t.context.closePath(), t.context.fill();
        }), this.context.draw();
    },
    onHide: function() {
        this.isForeground = !1, this.gameController && this.gameController.hideGame();
    },
    onUnload: function() {
        this.hideLoading(), this.loaded = !1, this.status = void 0, this.roomController && this.roomController.unload(), 
        this.gameController && (this.gameController.unload(), this.gameController.reset());
    },
    showLoading: function() {
        !this._showLoading && wx.showLoading && (this._showLoading = !0, wx.showLoading({
            title: "加载中"
        }));
    },
    hideLoading: function() {
        console.log("hideloading"), this._showLoading && wx.hideLoading && (this._showLoading = !1, 
        wx.hideLoading());
    },
    onPullDownRefresh: function() {},
    onReachBottom: function() {},
    onStartTapHandler: function() {
        this.roomController.onStartChallengeButton();
    },
    playClickSound: function() {
        i.default.play("button-click");
    },
    onQRCodeTapHandler: function() {
        var o = this;
        this.createQRCode(function(t) {
            o.showQRCode(t);
        });
    },
    createQRCode: function(o) {
        if (this.roomController && this.roomController.getRoomName()) {
            var t = {
                room: this.roomController.getRoomName()
            };
            a.default.generateQRCodeResult(t, o);
        }
    },
    showQRCode: function(o) {
        this.setData({
            showQRCode: !0,
            qrCodeImageSrc: o
        });
    },
    dismissQRCode: function() {
        this.setData({
            showQRCode: !1
        });
    },
    onBackHomeHandler: function() {
        getApp().redirectToHome();
    },
    onPkHandler: function() {
        wx.redirectTo({
            url: "/pages/pk/pk"
        });
    },
    onShareAppMessage: function() {
        var o = "/pages/pk/pk?uid=" + this.user.id;
        this.roomController && this.roomController.getRoomName() && (o += "&room=" + this.roomController.getRoomName());
        var t = {
            template: "shareTemplatePkJoining",
            templateArg: {
                nickName: s.current().get("nickName")
            },
            path: o,
            success: function(o) {
                getApp().onShareSuccess(o);
            }
        };
        return h.configEnabled(h.enableNewCnLogo) ? getApp().createShareMessage(t, "http://www.gstatic.com/qilin/drawtogether/pk/invitation-share-card.png") : getApp().createShareMessage(t, "http://www.gstatic.com/qilin/drawtogether/pk/new-invitation-share-card.png");
    }
});