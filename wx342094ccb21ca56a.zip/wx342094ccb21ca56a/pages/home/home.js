function t(t) {
    return t && t.__esModule ? t : {
        default: t
    };
}

var e = require("../../game/config.js"), i = t(require("../../game/api/playHistoryAPI.js")), n = t(require("../../common/soundFXController.js")), a = require("../../game/widgets/popup.js"), o = function(t) {
    if (t && t.__esModule) return t;
    var e = {};
    if (null != t) for (var i in t) Object.prototype.hasOwnProperty.call(t, i) && (e[i] = t[i]);
    return e.default = t, e;
}(require("../../game/eventlog.js")), s = require("../../common/initState.js"), r = require("../../libs/av-live-query-weapp-min").User, l = require("../../game/config/configManager"), u = require("../../game/api/partyAPI");

Page({
    data: {
        user: r.current(),
        versionCode: e.config.client_version,
        isPartyMode: !1,
        isPartyGameReady: !1,
        shouldShowLogo: !1
    },
    options: !1,
    onLoad: function(t) {
        this.loaded = !0, this.options = t, u.init(t), wx.showShareMenu && wx.showShareMenu({
            withShareTicket: !0
        }), this.popup = new a.PopupView(this);
    },
    onHide: function() {
        var t = this;
        setTimeout(function() {
            t.setData({
                animateClass: ""
            });
        }, 300);
    },
    showLoading: function() {
        !this._showLoading && wx.showLoading && (this._showLoading = !0, wx.showLoading({
            title: "加载中"
        }));
    },
    hideLoading: function() {
        this._showLoading && wx.hideLoading && (this._showLoading = !1, wx.hideLoading());
    },
    gotoParty: function() {
        wx.redirectTo({
            url: "/pages/party/party"
        });
    },
    onShow: function() {
        var t = this;
        if (this.setData({
            enableNewCnLogo: l.configEnabled(l.enableNewCnLogo)
        }), this.loaded) {
            if (getApp().getInitState() === s.InitState.LOADING) return this.showLoading(), 
            void setTimeout(function() {
                t.onShow();
            }, 300);
            if (getApp().getInitState() === s.InitState.SUCCESS) {
                if (l.configEnabled(l.ENABLED_PARTY_MODE) && u.shouldGotoPartyPage()) return void this.gotoParty();
                if (this.setData({
                    isPartyMode: u.isPartyMode()
                }), getApp().navigateIfApplicable()) return;
                this.applyConfig();
                var n = i.default.getLatestPlayHistory().getLevelStr();
                getApp().setNavigationBar(e.config.app_title);
                var a = getApp().getPromotedTheme();
                a || (a = "default-home"), this.data.isPartyMode && (a = "party-home", u.setEventListener({
                    onStatusChange: function(e) {
                        "WAITING" == e ? t.setPartyButtonAs(!0) : "PLAYING" == e ? t.setPartyButtonAs(!0) : "INIT" != e && "END" != e || t.setPartyButtonAs(!1);
                    }
                }));
                wx.getStorageSync("invitationLoginVerified");
                this.setData({
                    userLevel: n,
                    user: r.current().toJSON(),
                    env: this.getEnvStr(),
                    loadSuccess: !0,
                    shouldShowLogo: !0,
                    showFooterText: l.getEnv() !== l.PROD_ENV,
                    theme: a,
                    enablePkMode: !1,
                    showNewUpdate: l.configEnabled(l.SHOW_NEW_UPDATE)
                }), this.disableButtonClick = !1;
                var d = o.getContext();
                d.retry_count = 0, o.logEvent("home", d.data());
            } else {
                if (getApp().getInitState() !== s.InitState.FAIL) return getApp().getInitState() === s.InitState.AUTH_DENY ? void wx.redirectTo({
                    url: "/pages/unauthorized/unauthorized"
                }) : getApp().getInitState() === s.InitState.ALERT ? void wx.redirectTo({
                    url: "/pages/alert/alert"
                }) : void console.log("Unknown init state:", getApp().getInitState());
                this.setData({
                    loadSuccess: !1,
                    errAction: getApp().initFailAction
                });
            }
            setTimeout(function() {
                t.setData({
                    animateClass: "on-screen"
                });
            }, 200), this.hideLoading(), this.setData({
                finishedLoading: !0
            });
        }
    },
    onUnload: function() {
        this.isPartyMode && u.setEventListener(null), this.hideLoading(), this.loaded = !1;
    },
    applyConfig: function() {
        var t = l.configEnabled(l.VS_MODE_EXPERIMENT_NAME);
        this.setData({
            vsModeEnabled: t
        });
    },
    handleShowRanking: function() {
        this.disableButtonClick || (this.disableButtonClick = !0, wx.navigateTo({
            url: "/pages/ranking/ranking"
        }));
    },
    setPartyButtonAs: function(t) {
        this.setData({
            isPartyGameReady: t
        });
    },
    getEnvStr: function() {
        return l.getEnv() === l.DEV_ENV ? "开发版" : l.getEnv() === l.BETA_ENV ? "内测版" : "";
    },
    playClickSound: function() {
        n.default.play("button-click");
    },
    handlePlayEndless: function() {
        this.disableButtonClick || (this.disableButtonClick = !0, wx.redirectTo({
            url: "/pages/endless/endless"
        }));
    },
    handlePlayDouble: function() {
        this.disableButtonClick || (this.disableButtonClick = !0, wx.navigateTo({
            url: "/pages/vs/vs?rid=" + this.data.user.id
        }));
    },
    handleShowCollection: function() {
        this.disableButtonClick || (this.disableButtonClick = !0, wx.navigateTo({
            url: "/pages/collection/collection"
        }));
    },
    handleShowSetting: function() {
        this.popup.showSelectionDialog();
    },
    handleFeedback: function() {
        wx.navigateTo({
            url: "/pages/feedback/feedback"
        });
    },
    handleReload: function() {
        l.reset(), getApp().reload(), this.onShow();
    },
    handlePlayPk: function() {
        this.disableButtonClick || (this.disableButtonClick = !0, wx.redirectTo({
            url: "/pages/pk/pk"
        }));
    },
    handleAvatarTap: function() {
        this.avatarTapCount || (this.avatarTapCount = 0), 10 == ++this.avatarTapCount && wx.redirectTo({
            url: "/pages/invitationlogin/invitationlogin"
        });
    },
    onShareAppMessage: function() {
        var t = r.current();
        return getApp().createShareMessage({
            template: "shareTemplateCommon",
            path: "/pages/home/home?uid=" + t.id,
            success: function(t) {
                getApp().onShareSuccess(t);
            }
        }, null);
    }
});