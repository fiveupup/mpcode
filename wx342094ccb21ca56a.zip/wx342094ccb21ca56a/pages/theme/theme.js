function e(e) {
    if (e && e.__esModule) return e;
    var t = {};
    if (null != e) for (var i in e) Object.prototype.hasOwnProperty.call(e, i) && (t[i] = e[i]);
    return t.default = e, t;
}

function t(e) {
    return e && e.__esModule ? e : {
        default: e
    };
}

var i = t(require("../../common/soundFXController.js")), a = t(require("../../game/svgUtils.js")), s = t(require("../../game/themeUtils.js")), o = t(require("../../game/tooltipUtils.js")), n = e(require("../../game/api/gameAPI.js")), h = e(require("../../game/utils.js")), r = t(require("../../game/imageEncoding.js")), u = t(require("../../game/api/playHistoryAPI.js")), l = t(require("../../game/api/generateShareResultAPI.js")), d = e(require("../../game/eventlog.js")), c = require("../../common/initState"), g = require("../../libs/av-live-query-weapp-min").User, m = require("../../libs/underscore/underscore.modified"), p = require("../../game/models/words"), f = void 0;

Page({
    data: {
        words: "",
        showAll: !0,
        showWord: !1,
        user: g.current(),
        totalNum: 0,
        fetchSuccess: !0,
        theme: getApp().getPromotedTheme()
    },
    showLoading: function() {
        !this._showLoading && wx.showLoading && (this._showLoading = !0, wx.showLoading({
            title: "加载中"
        }));
    },
    hideLoading: function() {
        this._showLoading && wx.hideLoading && (this._showLoading = !1, wx.hideLoading());
    },
    initMenu: function() {
        wx.showShareMenu && wx.showShareMenu({
            withShareTicket: !0
        });
    },
    onLoad: function(e) {
        this.initMenu(), this.theme = e.theme;
    },
    onShow: function(e) {
        var t = this;
        if (getApp().getInitState() === c.InitState.LOADING) return this.showLoading(), 
        void setTimeout(function() {
            t.onShow();
        }, 300);
        if (getApp().getInitState() !== c.InitState.SUCCESS) return this.hideLoading(), 
        void getApp().redirectToHome();
        if (m.isEmpty(e) && (e = getApp().ops.query), this.theme || (this.theme = getApp().getPromotedTheme()), 
        !this.theme) return this.hideLoading(), void getApp().redirectToHome();
        getApp().setNavigationBar(s.default.getThemeZhCnTitle(this.theme), this.theme), 
        this.isComplete = this.theme && u.default.getLatestPlayHistory().getThemeCompleted(this.theme), 
        this.setData({
            user: g.current(),
            theme: this.theme,
            complete: this.isComplete ? "complete" : "incomplete",
            showShareButtons: s.default.showShareButtons(this.theme)
        }), this.user = g.current(), f = p.getWordsWithTheme(this.theme);
        var i = m.map(m.values(f), function(e) {
            return e.word;
        });
        this.showLoading(), n.fetchThemeCollections(g.current(), i).then(function(e) {
            m.each(e, function(e) {
                var t = e.get("word");
                f[t] && (f[t].status = f[t].status || e.get("recognized"), e.get("recognized") && (f[t].drawingSvg = a.default.createSvgBase64FromSegments(r.default.decode(JSON.parse(e.get("image"))), 120, 120, {
                    padding: 0
                }), f[t].competitionId = e.get("competition").id, f[t].round = e.get("round")));
            }), t.setDataWithMultipleSegements(f), t.hideLoading();
        }).catch(function(e) {
            t.hideLoading(), t.setData({
                fetchSuccess: !1
            }), wx.showToast({
                title: "加载失败请重试",
                image: "/assets/icon/cross.png"
            });
        }), this.setData({
            loaded: !0
        });
    },
    setDataWithMultipleSegements: function(e) {
        var t = 0, i = [], a = [];
        m.each(e, function(e, s, o) {
            t % 10 == 0 && (a.push({}), i.push(0)), t++, a[a.length - 1][s] = e;
        }), console.log("bucketIndex length: " + i.length);
        var s = m.pick(e, function(e, t, i) {
            return e.status;
        });
        this.setData({
            bucketIndex: i,
            totalNum: Object.keys(s).length
        }), this.setDataInSequence(a, 0);
    },
    setDataInSequence: function(e, t) {
        var i = this;
        if (!(t >= e.length)) {
            var a = {};
            a["words[" + t + "]"] = e[t], this.setData(a), m.defer(function() {
                i.setDataInSequence(e, t + 1);
            });
        }
    },
    playClickSound: function(e) {
        i.default.play("button-click");
    },
    handleCollectionTap: function(e) {
        this.playClickSound();
        var t = e.currentTarget.dataset.index;
        if (f[t].competitionId && f[t].round) {
            o.default.tickCount("collection"), getApp().currentRound = f[t];
            var i = "/pages/roundDetail/roundDetail";
            this.theme && (i += "?theme=" + this.theme), wx.navigateTo({
                url: i
            });
        }
    },
    showAllToggle: function(e) {
        this.setData({
            showAll: e.detail.value
        });
    },
    onShareAppMessage: function() {
        var e = s.default.hasShareImage(this.theme) ? this.isComplete ? h.getGStaticUrl(this.theme + "/" + this.theme + "-all-complete-share-card.png") : h.getGStaticUrl(this.theme + "/" + this.theme + "_share_card.png") : h.getGStaticUrl("share_card.png");
        return getApp().createShareMessage({
            template: s.default.hasShareTemplate(this.theme) ? this.isComplete ? "shareTemplateThemeComplete" : "shareTemplateThemeIncomplete" : "shareTemplateCommon",
            path: "/pages/theme/theme",
            success: function(e) {
                getApp().onShareSuccess(e);
            }
        }, e);
    },
    handlePlayTheme: function() {
        if (!this.disableButtonClick) {
            var e = "/pages/endless/endless";
            this.theme && (e += "?theme=" + this.theme), this.disableButtonClick = !0, (wx.reLaunch ? wx.reLaunch : wx.redirectTo)({
                url: e
            });
        }
    },
    dismissSavedPhoto: function() {
        this.setData({
            savedPhotoDialogClass: ""
        });
    },
    saveToAlbum: function() {
        var e = this, t = u.default.getLatestPlayHistory();
        t && t.getThemePassedWords(this.theme).length ? (d.logEvent("long_image", d.getContext().data()), 
        l.default.checkSaveImagePermission(function() {
            e.createSharePhoto(function(t) {
                e.showSavedPhotoDialog(t);
            });
        })) : wx.showModal({
            title: "猜画小歌",
            content: "先动手画画吧，画出来才能生成长图哦",
            showCancel: !1
        });
    },
    showSavedPhotoDialog: function(e) {
        i.default.play("button-click"), this.setData({
            savedPhotoDialogClass: "visible",
            savedPhotoImageSrc: e
        });
    },
    createSharePhoto: function(e) {
        var t = {
            userId: this.user.id,
            levelStr: u.default.getLatestPlayHistory().getLevelStr(),
            theme: this.theme
        };
        l.default.generateThemeShareResult(t, e);
    }
});