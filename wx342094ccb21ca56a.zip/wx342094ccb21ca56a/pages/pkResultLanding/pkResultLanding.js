var t = function(t) {
    if (t && t.__esModule) return t;
    var e = {};
    if (null != t) for (var o in t) Object.prototype.hasOwnProperty.call(t, o) && (e[o] = t[o]);
    return e.default = t, e;
}(require("../../game/api/gameAPI.js")), e = require("../../common/initState.js");

Page({
    data: {},
    onLoad: function(t) {
        if (t.scene && (t.ucid = t.scene), !t.ucid) return console.log("Field ucid not found"), 
        void getApp().redirectToHome();
        wx.setNavigationBarTitle({
            title: "本局结果"
        }), this.ucid = t.ucid, this.loaded = !0;
    },
    onStartTapHandler: function() {
        wx.redirectTo({
            url: "/pages/pk/pk"
        });
    },
    onReady: function() {},
    showLoading: function() {
        !this._showLoading && wx.showLoading && (this._showLoading = !0, wx.showLoading({
            title: "加载中"
        }));
    },
    hideLoading: function() {
        this._showLoading && wx.hideLoading && (this._showLoading = !1, wx.hideLoading());
    },
    onShow: function() {
        var o = this;
        if (this.loaded) {
            if (getApp().getInitState() === e.InitState.LOADING) return this.showLoading(), 
            void setTimeout(function() {
                o.onShow();
            }, 300);
            this.hideLoading(), getApp().getInitState() === e.InitState.SUCCESS ? t.fetchChallengeDataFromLeanCloud(this.ucid).then(function(t) {
                wx.hideLoading();
                var e = t.formatChallengeResult();
                e.myAvatarUrl = t.get("user").get("avatarUrl"), e.myNickName = t.get("user").get("nickName"), 
                o.setData(e);
            }).catch(function(t) {
                console.log("Fetch userChallenge by ucid failed:", t), getApp().redirectToHome();
            }) : getApp().redirectToHome();
        }
    },
    showRoundDetail: function() {},
    onHide: function() {},
    onUnload: function() {},
    onPullDownRefresh: function() {},
    onReachBottom: function() {},
    onShareAppMessage: function() {}
});