var e = function(e) {
    if (e && e.__esModule) return e;
    var i = {};
    if (null != e) for (var t in e) Object.prototype.hasOwnProperty.call(e, t) && (i[t] = e[t]);
    return i.default = e, i;
}(require("../../game/utils.js")), i = function(e) {
    return e && e.__esModule ? e : {
        default: e
    };
}(require("../../game/api/invitationloginAPI.js")), t = require("../../libs/av-live-query-weapp-min").User, n = require("../../game/config/configManager");

Page({
    data: {
        user: null
    },
    onLoad: function(e) {
        getApp().setNavigationBar();
    },
    onShow: function() {
        var e = this;
        setTimeout(function() {
            e.setData({
                animateClass: "on-screen"
            });
        }, 200), this.setData({
            user: t.current(),
            enableNewCnLogo: n.configEnabled(n.enableNewCnLogo)
        }), console.log("User.current(): " + t.current()), void 0 != t.current() && i.default.verifyLoggedIn(t.current().id).then(function(i) {
            i.toString().startsWith("true") && (console.log("logged in"), e.verifyPass());
        });
    },
    sendEmail: function() {
        var n = this;
        this.email && (this.email = this.email.trim()), this.email && e.validateLdap(this.email) ? (console.log("email: " + this.email), 
        wx.showToast({
            title: "注册码发送中",
            duration: 5e3,
            icon: "loading"
        }), i.default.sendEmail(t.current().id, this.email + "@google.com").then(function(e) {
            return n.emailSendResponse(e);
        })) : wx.showToast({
            title: "请输入ldap",
            duration: 2e3,
            icon: "none"
        });
    },
    authenticate: function() {
        var n = this;
        void 0 == this.code && (this.code = ""), e.validateAllNumbers(this.code) ? i.default.verifyInvitationCode(t.current().id, this.code).then(function(e) {
            e.toString().startsWith("true") ? (console.log("verified invitation code"), n.verifyPass()) : wx.showToast({
                title: "认证失败",
                duration: 2e3,
                icon: "none"
            });
        }) : wx.showToast({
            title: "注册码必须是纯数字",
            duration: 2e3,
            icon: "none"
        });
    },
    emailKeyInput: function(e) {
        this.email = e.detail.value;
    },
    codeKeyInput: function(e) {
        this.code = e.detail.value;
    },
    emailSendResponse: function(e) {
        wx.hideToast(), wx.showToast({
            title: "注册码已经发送，请查收邮件",
            duration: 2e3,
            icon: "success"
        }), console.log("email send");
    },
    verifyPass: function() {
        wx.setStorageSync("invitationLoginVerified", !0), console.log("invitationLoginVerified"), 
        getApp().reload(), getApp().redirectToHome();
    }
});