var e = require("../../game/widgets/pkCardsView.js"), n = require("../../game/config/configManager");

Page({
    data: {},
    onLoad: function(n) {
        this.cardsView = new e.PkCardsView(this), this.cardsView.addListener("BACK_TO_HOME", function() {
            return wx.redirectTo({
                url: "/pages/home/home"
            });
        });
    },
    onReady: function() {},
    onShow: function() {},
    onHide: function() {},
    onUnload: function() {},
    onPullDownRefresh: function() {},
    onReachBottom: function() {},
    onShareAppMessage: function() {
        var e = {
            path: "/pages/pkResultLanding/pkResultLanding?ucid=" + this.userChallengeId,
            template: "shareTemplatePkResult",
            success: function(e) {
                getApp().onShareSuccess(e);
            }
        };
        return e.templateArg = {
            totalUser: this.totalUser,
            myRank: this.myRank,
            myNumRecognized: this.myNumRecognized
        }, n.configEnabled(n.enableNewCnLogo) ? getApp().createShareMessage(e, "http://www.gstatic.com/qilin/drawtogether/pk/sharecards/new-rank-" + this.myRank + ".png") : getApp().createShareMessage(e, "http://www.gstatic.com/qilin/drawtogether/pk/sharecards/rank-" + this.myRank + ".png");
    }
});