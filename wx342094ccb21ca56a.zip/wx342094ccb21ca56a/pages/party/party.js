var t = require("../../game/api/partyAPI"), r = require("../../game/config/configManager");

Page({
    data: {
        partyStatus: "",
        partyCountdown: -1,
        jointParty: !1,
        bgStyle: "bg-normal",
        loaded: !1
    },
    onLoad: function(e) {
        this.setData({
            enableNewCnLogo: r.configEnabled(r.enableNewCnLogo)
        }), this.partyStatus = "UNKNOWN", t.quitRoom(), t.setEventListener(this), this.isVerifying = t.start();
    },
    onShow: function() {
        wx.showLoading && ("UNKNOWN" == this.partyStatus || this.isVerifying) && wx.showLoading({
            title: "验证中"
        });
    },
    tryHideLoading: function() {
        wx.hideLoading && ("UNKNOWN" == this.partyStatus || this.isVerifying ? this.badQrcode && wx.hideLoading() : wx.hideLoading());
    },
    onVerifyCodeDone: function(t) {
        if (this.isVerifying = !1, this.badQrcode = !!t.error, this.tryHideLoading(), t.error) {
            var r = t.error.toLowerCase();
            "network error" == r ? 2 != this.data.errorCode && this.setData({
                errorCode: 1,
                errorTitle: "无法加入",
                errorMsgLine1: "可能是已经开始或是网络异常。",
                errorMsgLine2: "你可以稍后再试试看。",
                errorMsgLine3: "",
                bgStyle: "bg-error"
            }) : "invalid qrcode" != r && "qrcode is already used by another user" != r || this.setData({
                errorCode: 2,
                errorTitle: "二维码有问题",
                errorMsgLine1: "请注意二维码是专属个人使用，请不要分享他",
                errorMsgLine2: "人。有问题的话，请洽现场工作人员。",
                errorMsgLine3: "",
                bgStyle: "bg-error"
            }), this.data.loaded || this.setData({
                loaded: !0
            });
        } else this.partyStatus && this.onStatusChange(this.partyStatus);
    },
    checkProfileAllowed: function() {
        return !!wx.getStorageSync("party.confirm") || (this.showInfo("授权使用你的微信头像和名字", "在接下来的活动中，我们可能会取用你的微信头像和名字显示于屏幕上。如果你不同意，可以点选取消离开。", "取消", "同意"), 
        !1);
    },
    showInfo: function(t, r, e, o) {
        this.setData({
            theme: "info",
            title: t,
            message: r,
            buttonTextCancel: e,
            buttonTextAccept: o,
            showInfo: !0
        });
    },
    buttonAccept: function() {
        this.setData({
            showInfo: !1
        }), wx.setStorageSync("party.confirm", !0), "PLAYING" == this.partyStatus ? this.setData({
            errorCode: 1,
            errorTitle: "无法加入",
            errorMsgLine1: "可能是已经开始或是网络异常。",
            errorMsgLine2: "你可以稍后再试试看。",
            errorMsgLine3: "",
            bgStyle: "bg-error"
        }) : "WAITING" == this.partyStatus && this.tryJoinParty();
    },
    buttonCancel: function() {
        this.setData({
            showInfo: !1
        }), this.buttonHome();
    },
    onStatusChange: function(r) {
        this.partyStatus = r, this.tryHideLoading(), 1 == this.data.errorCode || 2 == this.data.errorCode || this.isVerifying || ("WAITING" == r ? this.tryJoinParty() : "PLAYING" == r ? t.canPlay() ? wx.getStorageSync("party.confirm") && this.startPartyMode() : this.setData({
            errorCode: 1,
            errorTitle: "无法加入",
            errorMsgLine1: "可能是已经开始或是网络异常。",
            errorMsgLine2: "你可以稍后再试试看。",
            errorMsgLine3: "",
            bgStyle: "bg-error"
        }) : "INIT" != r && "END" != r || 1 != this.data.errorCode && 2 != this.data.errorCode && this.setData({
            jointParty: !1,
            errorCode: 3,
            errorTitle: "GDD特别版马上就要开始",
            errorMsgLine1: "彩页的二维码仅供一个微信号使用，不可共",
            errorMsgLine2: "用。扫码成功后，请等待开始。你也可以先练",
            errorMsgLine3: "习一下单人作画。",
            bgStyle: "bg-error"
        }), "UNKNOWN" == r || this.data.loaded || (this.setData({
            loaded: !0
        }), setTimeout(function() {
            wx.hideLoading();
        }, 100)));
    },
    tryJoinParty: function() {
        var r = this;
        this.checkProfileAllowed() && t.canJoin() && t.join().then(function() {
            r.setData({
                errorCode: 0,
                bgStyle: "bg-normal",
                partyStatus: "等候主办人开始同玩"
            });
        }, function(t) {
            r.setData({
                errorCode: 1,
                errorTitle: "无法加入",
                errorMsgLine1: "可能是已经开始或是网络异常。",
                errorMsgLine2: "你可以稍后再试试看。",
                errorMsgLine3: "",
                bgStyle: "bg-error"
            });
        });
    },
    startPartyMode: function() {
        var t = this;
        this.countdownHandler && clearInterval(this.countdownHandler), this.partyCountdown = 3, 
        this.countdownHandler = setInterval(function() {
            if (t.setData({
                partyStatus: "",
                partyCountdown: t.partyCountdown
            }), 0 == t.partyCountdown) return wx.redirectTo({
                url: "/pages/endless/endless?isPartyMode=true"
            }), clearInterval(t.countdownHandler), void (t.countdownHandler = !1);
            t.partyCountdown--;
        }, 1e3);
    },
    buttonHome: function() {
        t.quitRoom(), t.setEventListener(null), this.countdownHandler && (clearInterval(this.countdownHandler), 
        this.countdownHandler = !1), wx.redirectTo({
            url: "/pages/home/home"
        });
    }
});