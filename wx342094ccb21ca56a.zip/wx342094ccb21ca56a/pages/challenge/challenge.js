function e(e) {
    if (e && e.__esModule) return e;
    var t = {};
    if (null != e) for (var i in e) Object.prototype.hasOwnProperty.call(e, i) && (t[i] = e[i]);
    return t.default = e, t;
}

function t(e) {
    return e && e.__esModule ? e : {
        default: e
    };
}

var i = t(require("../../game/svgUtils.js")), o = e(require("../../game/api/gameAPI.js")), n = e(require("../../game/utils.js")), a = t(require("../../common/soundFXController.js")), r = t(require("../../game/imageEncoding.js")), s = require("../../game/config.js"), d = require("../../common/initState"), h = require("../../game/widgets/digitImage.js"), g = require("../../game/api/bignumber.min.js"), u = require("../../libs/av-live-query-weapp-min").User, c = require("../../libs/underscore/underscore.modified"), l = require("../../game/config/configManager");

Page({
    data: {
        user: null,
        appName: s.config.app_name,
        digitImageData: void 0,
        themeScheme: "underwater",
        isSharedFromPartyMode: !1
    },
    initMenu: function() {
        wx.showShareMenu && wx.showShareMenu({
            withShareTicket: !0
        });
    },
    onLoad: function(e) {
        this.loaded = !0, this.initMenu();
    },
    showCompetition: function(e) {
        var t = this;
        o.fetchCompetition(e).then(function(e) {
            e && !e.get("deleted") ? (t.competition = e, t.showInvitationPage()) : getApp().redirectToHome();
        }).catch(function(t) {
            console.log("Could not load competition", e, t), getApp().redirectToHome();
        });
    },
    redirectToHome: function() {
        wx.redirectTo({
            url: "/pages/home/home"
        });
    },
    renderInvitationPageLowerContainer: function(e) {
        c.each(e, function(e, t) {
            e.drawingSvg = i.default.createSvgBase64FromSegments(r.default.decode(e.drawing), 180, 120, {
                padding: 25
            });
        }), this.setData({
            rounds: e
        });
    },
    showInvitationPage: function() {
        var e = this.competition.get("user"), t = this.competition.get("result"), i = this.competition.get("theme"), o = t ? t.total : void 0, a = o ? o.round_pass : 0, r = n.getThemeScheme(this.data.isSharedFromPartyMode ? 0 : a + 1, i);
        this.setData({
            user: e,
            themeScheme: r
        }), getApp().setNavigationBar(s.config.app_title, r), this.digitImage = new h.DigitImage(this), 
        this.digitImage.setDigits(a, e.get("nickName") + "本局成功画出", "张", r), this.setData({
            digitImageData: this.digitImage.getData()
        }), t && this.renderInvitationPageLowerContainer(t.detailed);
    },
    showLoading: function() {
        !this._showLoading && wx.showLoading && (this._showLoading = !0, wx.showLoading({
            title: "加载中"
        }));
    },
    hideLoading: function() {
        this._showLoading && wx.hideLoading && (this._showLoading = !1, wx.hideLoading());
    },
    onShow: function(e) {
        var t = this;
        if (this.loaded) {
            if (getApp().getInitState() === d.InitState.LOADING) return this.showLoading(), 
            void setTimeout(function() {
                t.onShow();
            }, 300);
            if (this.hideLoading(), getApp().getInitState() === d.InitState.SUCCESS) if (c.isEmpty(e) && (e = getApp().ops.query), 
            this.setData({
                enableNewCnLogo: l.configEnabled(l.enableNewCnLogo)
            }), "endless" == e.mode) "wxcard" == e.source && this.showCompetition(e.cid); else if ("gdd" == e.mode) this.setData({
                isSharedFromPartyMode: !0,
                rank: e.ranking,
                rankp0: Math.floor(e.ranking / 1e3),
                rankp1: Math.floor(e.ranking % 1e3 / 100),
                rankp2: Math.floor(e.ranking % 100 / 10),
                rankp3: e.ranking % 10,
                total_players: e.totalPlayerCount
            }), this.showCompetition(e.cid); else {
                var i = decodeURIComponent(e.scene), o = !!i && i.split("&");
                if (0 == e.scene.indexOf("m3")) {
                    var n = this.decode(e.scene.substr(2)), a = parseInt(n[1]), r = parseInt(n[2]);
                    this.setData({
                        isSharedFromPartyMode: !0,
                        rank: a,
                        rankp0: Math.floor(a / 1e3),
                        rankp1: Math.floor(a % 1e3 / 100),
                        rankp2: Math.floor(a % 100 / 10),
                        rankp3: a % 10,
                        total_players: r + 1
                    }), this.showCompetition(n[0]);
                } else o && o.length > 1 && "m1" == o[0] ? this.showCompetition(o[1]) : (console.log("Unrecognized scene:", i), 
                this.redirectToHome());
            } else getApp().redirectToHome();
        }
    },
    onUnload: function() {
        this.hideLoading(), this.loaded = !1;
    },
    onShareAppMessage: function() {
        var e = u.current();
        if (e) return getApp().createShareMessage({
            template: "shareTemplateCommon",
            path: "/pages/home/home?uid=" + e.id,
            success: function(e) {
                getApp().onShareSuccess(e);
            }
        });
    },
    buttonHome: function() {
        wx.redirectTo({
            url: "/pages/home/home"
        });
    },
    buttonStartDrawing: function() {
        if (!this.disableButtonClick && this.competition) {
            this.competition.get("user").id !== u.current().id && (getApp().invitedCompetition = this.competition), 
            this.disableButtonClick = !0;
            var e = "/pages/endless/endless", t = this.competition.get("theme");
            t && (e += "?theme=" + t), wx.redirectTo({
                url: e
            });
        }
    },
    playClickSound: function() {
        a.default.play("button-click");
    },
    convertX: function(e, t, i) {
        e += "";
        for (var o = new g.BigNumber(0), n = 0; n < e.length; ++n) {
            for (var a = e[n], r = 0; r < t.length && t[r] != a; ++r) ;
            if (!(r < t.length)) return !1;
            o = o.times(t.length).plus(r);
        }
        for (var s = ""; ;) {
            if (o.lt(i.length)) {
                s = i[parseInt(o.toFixed())] + s;
                break;
            }
            s = i[parseInt(o.mod(i.length).toFixed())] + s, o = o.div(i.length);
        }
        return s;
    },
    decode: function(e) {
        var t = [], i = !0, o = !1, n = void 0;
        try {
            for (var a, r = e.split("_")[Symbol.iterator](); !(i = (a = r.next()).done); i = !0) {
                var s = a.value;
                t.push(this.convertX(s, "0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ", "0123456789abcdef"));
            }
        } catch (e) {
            o = !0, n = e;
        } finally {
            try {
                !i && r.return && r.return();
            } finally {
                if (o) throw n;
            }
        }
        return t;
    }
});