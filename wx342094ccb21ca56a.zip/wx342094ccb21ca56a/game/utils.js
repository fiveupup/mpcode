function e(e) {
    return e[u.random(e.length - 1)];
}

function t(e) {
    var t = i.getArrayValue("LEVEL_THEME_ACCUMULATED_LADDER", []);
    return e < t[0] ? "underwater" : e < t[1] ? "land" : e < t[2] ? "to-outerspace" : e < t[3] ? "outerspace" : (console.log('Round count exceeds maximum! Return default theme "underwater"'), 
    "underwater");
}

Object.defineProperty(exports, "__esModule", {
    value: !0
});

var r = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(e) {
    return typeof e;
} : function(e) {
    return e && "function" == typeof Symbol && e.constructor === Symbol && e !== Symbol.prototype ? "symbol" : typeof e;
};

exports.shuffle = function(e) {
    for (var t = e.length; t; ) {
        var r = u.random(t--), o = [ e[t], e[r] ];
        e[r] = o[0], e[t] = o[1];
    }
}, exports.toParamStr = function(e) {
    return "?" + Object.keys(e).map(function(t) {
        return [ t, e[t] ].map(encodeURIComponent).join("=");
    }).join("&");
}, exports.fancyTimeFormat = function(e) {
    var t = ~~((e = Math.round(e)) % 3600 / 60), r = e % 60, o = "";
    return o += ~~(e / 3600) + ":" + (t < 10 ? "0" : ""), o += t + ":" + (r < 10 ? "0" : ""), 
    o += "" + r;
}, exports.textTimeFormat = function(e) {
    var t = ~~((e = Math.round(e)) / 3600), r = ~~(e % 3600 / 60), o = e % 60, n = "";
    return t > 0 && (n += t + "时"), r > 0 && (n += r + "分"), o > 0 && (n += o + "秒"), 
    n;
}, exports.validateGoogleMail = function(e) {
    return void 0 != e && /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@google.com$/.test(e.toLowerCase());
}, exports.validateLdap = function(e) {
    return void 0 != e && /^[a-z]+$/.test(e.toLowerCase());
}, exports.validateAllNumbers = function(e) {
    return void 0 != e && /^\d+$/.test(e.toLowerCase());
}, exports.getWindowRpxSize = function() {
    try {
        return {
            w: 750,
            h: 750 * wx.getSystemInfoSync().windowHeight / wx.getSystemInfoSync().windowWidth
        };
    } catch (e) {
        console.log(e);
    }
    return {
        w: 750,
        h: 1334
    };
}, exports.getWindowSize = function() {
    try {
        return {
            w: wx.getSystemInfoSync().windowWidth,
            h: wx.getSystemInfoSync().windowHeight
        };
    } catch (e) {
        console.log(e);
    }
    return {
        w: 750,
        h: 300
    };
}, exports.rpxToPx = function(e) {
    try {
        return e / 750 * wx.getSystemInfoSync().windowWidth;
    } catch (e) {
        console.log(e);
    }
    return e / 2;
}, exports.pickRandom = e, exports.pickRandomShareTemplate = function(t, n) {
    var a = e(o.config[t]), i = o.config.shareTemplates[a];
    return "object" === (void 0 === n ? "undefined" : r(n)) ? u.keys(n).forEach(function(e) {
        return i = i.replace("{" + e + "}", n[e]);
    }) : i = i.replace("{}", n), {
        template: a,
        message: i
    };
}, exports.getRandomInt = function(e, t) {
    return e = Math.ceil(e), t = Math.floor(t), Math.floor(Math.random() * (t - e)) + e;
}, exports.getLevelStr = function(e) {
    return e - 1 < o.config.levelNames.length ? "Lv. " + e + " " + o.config.levelNames[e - 1] : "Lv. " + e + " 超神";
}, exports.getLevel = function(e) {
    for (var t = i.getArrayValue("LEVEL_LADDER", []), r = 1, o = 0, n = 0; n < t.length && (o += t[n]) <= e; n++) r += 1;
    return r;
}, exports.getThemeSchemeFromRoundCount = t, exports.getThemeScheme = function(e, r) {
    return r && n.default.isValidTheme(r) ? n.default.getThemeConfig(r).themeScheme : t(e);
}, exports.getGStaticUrl = function(e) {
    return "https://www.gstatic.com/qilin/drawtogether/" + e;
}, exports.AVObjectfromJson = function(e, t) {
    var r = a.parseJSON(e), o = r.createdAt, n = r.updatedAt, u = r.objectId;
    delete r.createdAt, delete r.updatedAt, delete r.objectId;
    var i = t(r);
    return i.id = u, o && (i.createdAt = o), n && (i.updatedAt = n), u && (i.id = u), 
    i;
};

var o = require("config.js"), n = function(e) {
    return e && e.__esModule ? e : {
        default: e
    };
}(require("themeUtils.js")), u = require("../libs/underscore/underscore.modified"), a = require("../libs/av-live-query-weapp-min"), i = require("config/configManager");