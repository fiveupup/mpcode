function e(e, t) {
    if (!(e instanceof t)) throw new TypeError("Cannot call a class as a function");
}

function t(e, t) {
    if (!e) throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
    return !t || "object" != typeof t && "function" != typeof t ? e : t;
}

function r(e, t) {
    if ("function" != typeof t && null !== t) throw new TypeError("Super expression must either be null or a function, not " + typeof t);
    e.prototype = Object.create(t && t.prototype, {
        constructor: {
            value: e,
            enumerable: !1,
            writable: !0,
            configurable: !0
        }
    }), t && (Object.setPrototypeOf ? Object.setPrototypeOf(e, t) : e.__proto__ = t);
}

var n = function() {
    function e(e, t) {
        for (var r = 0; r < t.length; r++) {
            var n = t[r];
            n.enumerable = n.enumerable || !1, n.configurable = !0, "value" in n && (n.writable = !0), 
            Object.defineProperty(e, n.key, n);
        }
    }
    return function(t, r, n) {
        return r && e(t.prototype, r), n && e(t, n), t;
    };
}(), o = require("../../libs/av-live-query-weapp-min"), i = require("../../libs/underscore/underscore.modified"), u = !1, s = function(s) {
    function a() {
        return e(this, a), t(this, (a.__proto__ || Object.getPrototypeOf(a)).apply(this, arguments));
    }
    return r(a, o.Object), n(a, null, [ {
        key: "update",
        value: function(e) {
            wx.setStorageSync("words", e), u = !1;
        }
    }, {
        key: "getAllWords",
        value: function() {
            return u || (u = wx.getStorageSync("words")), u;
        }
    }, {
        key: "getWordsWithTheme",
        value: function(e) {
            var t = this.getAllWords(), r = {};
            return i.each(i.keys(t), function(n) {
                var o = t[n].themes;
                i.contains(o, e) && (r[n] = t[n]);
            }), r;
        }
    }, {
        key: "getWordsWithoutTheme",
        value: function(e) {
            var t = this.getAllWords(), r = {};
            return i.each(i.keys(t), function(n) {
                var o = t[n].themes;
                i.contains(o, e) || (r[n] = t[n]);
            }), r;
        }
    }, {
        key: "getThemeWords",
        value: function(e) {
            return i.keys(this.getWordsWithTheme(e));
        }
    }, {
        key: "getThemePassedWordsGivenList",
        value: function(e, t) {
            return i.intersection(t, this.getThemeWords(e));
        }
    }, {
        key: "getThemeCompletedGivenList",
        value: function(e, t) {
            var r = this.getThemePassedWordsGivenList(e, t).length, n = this.getThemeWords(e).length;
            return 0 != n && r == n;
        }
    }, {
        key: "getWord",
        value: function(e) {
            return a.getAllWords()[e];
        }
    }, {
        key: "getTTSUrl",
        value: function(e) {
            var t = e.word, r = e.ttsURLZhCn;
            return r ? r.url : "https://www.gstatic.com/qilin/drawtogether/wordaudios/" + t + ".mp3";
        }
    } ]), a;
}();

o.Object.register(s, "Words"), module.exports = s;