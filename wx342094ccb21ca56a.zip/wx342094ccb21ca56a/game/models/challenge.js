function e(e) {
    return e && e.__esModule ? e : {
        default: e
    };
}

function n(e, n) {
    if (!(e instanceof n)) throw new TypeError("Cannot call a class as a function");
}

function r(e, n) {
    if (!e) throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
    return !n || "object" != typeof n && "function" != typeof n ? e : n;
}

function t(e, n) {
    if ("function" != typeof n && null !== n) throw new TypeError("Super expression must either be null or a function, not " + typeof n);
    e.prototype = Object.create(n && n.prototype, {
        constructor: {
            value: e,
            enumerable: !1,
            writable: !0,
            configurable: !0
        }
    }), n && (Object.setPrototypeOf ? Object.setPrototypeOf(e, n) : e.__proto__ = n);
}

var o = function() {
    function e(e, n) {
        for (var r = 0; r < n.length; r++) {
            var t = n[r];
            t.enumerable = t.enumerable || !1, t.configurable = !0, "value" in t && (t.writable = !0), 
            Object.defineProperty(e, t.key, t);
        }
    }
    return function(n, r, t) {
        return r && e(n.prototype, r), t && e(n, t), n;
    };
}(), i = e(require("../svgUtils.js")), a = e(require("../imageEncoding.js")), u = require("../../libs/av-live-query-weapp-min"), s = require("../../libs/underscore/underscore.modified"), c = require("../models/words"), l = function(e) {
    function l() {
        return n(this, l), r(this, (l.__proto__ || Object.getPrototypeOf(l)).apply(this, arguments));
    }
    return t(l, u.Object), o(l, [ {
        key: "getMaxDrawingLength",
        value: function() {
            var e = this.get("result"), n = 0;
            return s.values(e).forEach(function(e) {
                Array.isArray(e) && (n = Math.max(n, e.length));
            }), n;
        }
    }, {
        key: "buildUserRankList",
        value: function(e) {
            var n = this.get("result"), r = {};
            e && (r = s.indexBy(e, "userId"));
            var t = [];
            s.keys(n).forEach(function(e) {
                var o = 0, i = 0;
                n[e] && n[e].forEach(function(e) {
                    null !== e && e.recognized && (o++, i += e.duration);
                });
                var a = {
                    userId: e,
                    numRecognized: o,
                    totalRecognitionTime: i
                };
                r[e] && (a.avatarUrl = r[e].userInfo.avatarUrl, a.nickName = r[e].userInfo.nickName), 
                t.push(a);
            }), t.sort(function(e, n) {
                return e.numRecognized != n.numRecognized ? n.numRecognized - e.numRecognized : e.totalRecognitionTime - n.totalRecognitionTime;
            });
            for (var o = 0; o < t.length; o++) o > 0 && t[o].numRecognized === t[o - 1].numRecognized && t[o].totalRecognitionTime === t[o - 1].totalRecognitionTime ? t[o].rank = t[o - 1].rank : t[o].rank = o + 1, 
            t[o].isWinner = 1 === t[o].rank ? "winner" : "";
            return t;
        }
    }, {
        key: "getRounds",
        value: function(e) {
            var n = this.get("challengeWords"), r = this.get("result"), t = {};
            e && (t = s.indexBy(e, "userId"));
            for (var o = [], u = c.getAllWords(), l = this.getMaxDrawingLength(), g = 0; g < n.length && g < l; g++) {
                var d = n[g];
                u[d] && (d = u[d].wordZhCn), o.push({
                    id: g + 1,
                    wordDisplay: d,
                    drawings: [],
                    numSuccess: 0,
                    numFail: 0
                });
            }
            return s.keys(r).forEach(function(e) {
                for (var n = r[e], u = 0; u < n.length; u++) {
                    null === n[u] && (n[u] = {}), n[u].drawing || (n[u].drawing = ""), n[u].recognized ? o[u].numSuccess++ : o[u].numFail++;
                    var s = {};
                    if (n[u].skipped && !n[u].recognized) s = {
                        userId: e,
                        skipped: !0,
                        score: 2e10
                    }; else {
                        var c = a.default.decode(n[u].drawing), l = 0;
                        c.forEach(function(e) {
                            if (e[0]) for (var n = 0; n + 1 < e[0].length; n++) l += Math.abs(e[0][n] - e[0][n + 1]) + Math.abs(e[1][n] - e[1][n + 1]);
                        }), s = {
                            userId: e,
                            drawingSvg: i.default.createSvgBase64FromSegments(c, 180, 180, {
                                padding: 25
                            }),
                            recognized: !!n[u].recognized,
                            score: n[u].recognized ? n[u].score : 1e10,
                            duration: n[u].duration,
                            drawingLength: l
                        };
                    }
                    t[e] && (s.avatarUrl = t[e].userInfo.avatarUrl, s.nickName = t[e].userInfo.nickName), 
                    o[u].drawings.push(s);
                }
            }), o.forEach(function(e) {
                e.drawings.sort(function(e, n) {
                    return e.score !== n.score ? e.score - n.score : e.drawingLength !== n.drawingLength ? n.drawingLength - e.drawingLength : e.userId < n.userId ? -1 : 1;
                });
            }), o;
        }
    } ]), l;
}();

u.Object.register(l, "Challenge"), module.exports = l;