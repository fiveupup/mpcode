function t(t, e) {
    if (!(t instanceof e)) throw new TypeError("Cannot call a class as a function");
}

Object.defineProperty(exports, "__esModule", {
    value: !0
});

var e = require("../models/words");

exports.GameRound = function i(s, o) {
    t(this, i), this.word = s;
    var r = e.getWord(this.word);
    this.wordZhCn = r ? r.wordZhCn : "", this.startTime = new Date(), this.recognized = !1, 
    this.level = o, this.recognitions = [], this.score = 999, this.width = 0, this.height = 0;
};