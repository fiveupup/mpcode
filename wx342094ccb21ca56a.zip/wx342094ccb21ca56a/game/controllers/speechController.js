function t(t, e) {
    if (!(t instanceof e)) throw new TypeError("Cannot call a class as a function");
}

function e() {
    if (0 != h.length && !h[0].downloading) {
        h[0].downloading = !0;
        var t = h[0].url, e = t, n = l.getStringValue(c, "https://www.gstatic.com/qilin/drawtogether/wordaudios/"), o = l.getStringValue(s, "https://qa.api.drawtogether.watchparty.cn/wordaudios/");
        n && o && (e = t.replace(n, o));
        try {
            wx.downloadFile({
                url: e,
                success: function(e) {
                    200 === e.statusCode ? wx.saveFile({
                        tempFilePath: e.tempFilePath,
                        fail: function() {
                            i();
                        },
                        success: function(e) {
                            var n = e.savedFilePath;
                            try {
                                wx.setStorageSync(a(t), n), f[t] = n;
                            } catch (t) {
                                console.log("error", t);
                            }
                            i();
                        }
                    }) : i();
                },
                fail: function(t) {
                    i();
                }
            });
        } catch (t) {
            i();
        }
    }
}

function n() {
    h.splice(1, h.length - 1);
}

function i() {
    ++d[h[0].url], h.shift(), e();
}

function o(t) {
    if (!(d[t] >= 3)) {
        var n = !0, i = !1, o = void 0;
        try {
            for (var a, r = h[Symbol.iterator](); !(n = (a = r.next()).done); n = !0) if (a.value.url == t) return;
        } catch (t) {
            i = !0, o = t;
        } finally {
            try {
                !n && r.return && r.return();
            } finally {
                if (i) throw o;
            }
        }
        h.push({
            url: t
        }), d[t] = 0, e();
    }
}

function a(t) {
    return "audio_path." + t;
}

Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.SpeechController = void 0;

var r = function() {
    function t(t, e) {
        for (var n = 0; n < e.length; n++) {
            var i = e[n];
            i.enumerable = i.enumerable || !1, i.configurable = !0, "value" in i && (i.writable = !0), 
            Object.defineProperty(t, i.key, i);
        }
    }
    return function(e, n, i) {
        return n && t(e.prototype, n), i && t(e, i), e;
    };
}(), u = function(t) {
    return t && t.__esModule ? t : {
        default: t
    };
}(require("../../common/soundFXController.js")), l = require("../config/configManager"), c = "AUDIO_CACHE_URL_REPLACE_SRC", s = "AUDIO_CACHE_URL_REPLACE_DEST", f = {}, h = [], d = {};

exports.SpeechController = function() {
    function e(n) {
        var i = this;
        t(this, e), wx.createInnerAudioContext && !u.default.getMute() ? (this.audioCtx = wx.createInnerAudioContext(), 
        this.audioCtx.autoplay = !1, this.audioCtx.loop = !1, this.audioCtx.src = e.getSrc(n), 
        this.audioCtx.onError(function(t) {
            i.speakErr(t);
        }), this.audioCtx.onEnded(function(t) {
            i.speakFinished();
        })) : this.audioCtx = null;
    }
    return r(e, null, [ {
        key: "preload",
        value: function(t) {
            !u.default.getMute() && l.configEnabled("AUDIO_CACHE_DISABLED") && e.fetch(t);
        }
    }, {
        key: "clearQueue",
        value: function() {
            n();
        }
    }, {
        key: "fetch",
        value: function(t) {
            if (t.startsWith("https://") && !f[t]) {
                var e = a(t), n = wx.getStorageSync(e);
                n ? wx.getFileInfo({
                    filePath: n,
                    success: function(e) {
                        f[t] = n;
                    },
                    fail: function() {
                        try {
                            wx.removeStorageSync(e);
                        } catch (t) {
                            console.log("error", t);
                        }
                        o(t);
                    }
                }) : o(t);
            }
        }
    }, {
        key: "onFetchFailed",
        value: function(t) {
            delete f[t];
        }
    }, {
        key: "getSrc",
        value: function(t) {
            return f[t] || t;
        }
    } ]), r(e, [ {
        key: "speakErr",
        value: function(t) {
            console.log(t), this._callback && this._callback(), this.destroy();
        }
    }, {
        key: "stop",
        value: function() {
            this.audioCtx && this.audioCtx.stop(), this.destroy();
        }
    }, {
        key: "speakFinished",
        value: function() {
            this._callback && this._callback(), this.destroy();
        }
    }, {
        key: "speak",
        value: function(t) {
            var e = this;
            this._callback = t, this.audioCtx && !u.default.getMute() ? (this.audioCtx.seek(0), 
            this.audioCtx.play()) : setTimeout(function() {
                e.speakFinished();
            }, 1e3);
        }
    }, {
        key: "destroy",
        value: function() {
            this._callback && (this._callback = null), this.audioCtx && (this.audioCtx.destroy(), 
            this.audioCtx = null);
        }
    } ]), e;
}();