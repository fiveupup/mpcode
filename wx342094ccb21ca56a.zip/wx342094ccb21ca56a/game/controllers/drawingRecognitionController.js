function e(e, t) {
    if (!(e instanceof t)) throw new TypeError("Cannot call a class as a function");
}

function t(e, t) {
    if (!e) throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
    return !t || "object" != typeof t && "function" != typeof t ? e : t;
}

function n(e, t) {
    if ("function" != typeof t && null !== t) throw new TypeError("Super expression must either be null or a function, not " + typeof t);
    e.prototype = Object.create(t && t.prototype, {
        constructor: {
            value: e,
            enumerable: !1,
            writable: !0,
            configurable: !0
        }
    }), t && (Object.setPrototypeOf ? Object.setPrototypeOf(e, t) : e.__proto__ = t);
}

Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.DrawingRecognitionController = exports.DrawingRecognitionControllerEvents = void 0;

var r = function() {
    function e(e, t) {
        for (var n = 0; n < t.length; n++) {
            var r = t[n];
            r.enumerable = r.enumerable || !1, r.configurable = !0, "value" in r && (r.writable = !0), 
            Object.defineProperty(e, r.key, r);
        }
    }
    return function(t, n, r) {
        return n && e(t.prototype, n), r && e(t, r), t;
    };
}(), o = require("../config.js"), i = function(e) {
    return e && e.__esModule ? e : {
        default: e
    };
}(require("../events.js")), s = require("../../libs/underscore/underscore.modified"), c = exports.DrawingRecognitionControllerEvents = {
    NEW_RECOGNITIONS: "NEW_RECOGNITIONS"
};

exports.DrawingRecognitionController = function(u) {
    function a(n) {
        e(this, a);
        var r = t(this, (a.__proto__ || Object.getPrototypeOf(a)).call(this));
        return r.segmentProcessor = n, r.wordBlacklist = o.config.blacklist, r.processDrawingThrottle = s.throttle(function(e, t) {
            return r.processDrawing(e, t);
        }, 1e3 * o.config.max_api_rate, {
            leading: !1
        }), r.isRecognizing = !1, r.reset(), r;
    }
    return n(a, i.default), r(a, [ {
        key: "reset",
        value: function() {}
    }, {
        key: "start",
        value: function() {
            this.reset(), this.isRecognizing = !0;
        }
    }, {
        key: "stop",
        value: function() {
            this.isRecognizing = !1;
        }
    }, {
        key: "processDrawing",
        value: function(e, t) {
            var n = this, r = t.getSegments();
            s.reduce(r, function(e, t) {
                return e + t[0].length;
            }, 0) > 10 && this.segmentProcessor(e, r, t.getWidth(), t.getHeight()).then(function(e) {
                return n.processRecognitionResponse(e);
            });
        }
    }, {
        key: "processRecognitionResponse",
        value: function(e) {
            if (this.isRecognizing) {
                var t = this.filterGuesses(e);
                this.emit(c.NEW_RECOGNITIONS, t);
            }
        }
    }, {
        key: "filterGuesses",
        value: function(e) {
            return s.filter(e, function(e) {
                return e.score < o.config.handwriting_threshold;
            });
        }
    }, {
        key: "onDrawingUpdated",
        value: function(e, t) {
            this.isRecognizing && this.processDrawingThrottle(e, t);
        }
    } ]), a;
}();