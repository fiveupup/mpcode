function e(e) {
    if (e && e.__esModule) return e;
    var t = {};
    if (null != e) for (var n in e) Object.prototype.hasOwnProperty.call(e, n) && (t[n] = e[n]);
    return t.default = e, t;
}

function t(e) {
    return e && e.__esModule ? e : {
        default: e
    };
}

function n(e, t) {
    if (!(e instanceof t)) throw new TypeError("Cannot call a class as a function");
}

function i(e, t) {
    if (!e) throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
    return !t || "object" != typeof t && "function" != typeof t ? e : t;
}

function o(e, t) {
    if ("function" != typeof t && null !== t) throw new TypeError("Super expression must either be null or a function, not " + typeof t);
    e.prototype = Object.create(t && t.prototype, {
        constructor: {
            value: e,
            enumerable: !1,
            writable: !0,
            configurable: !0
        }
    }), t && (Object.setPrototypeOf ? Object.setPrototypeOf(e, t) : e.__proto__ = t);
}

Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.PkGameController = void 0;

var r = function() {
    function e(e, t) {
        for (var n = 0; n < t.length; n++) {
            var i = t[n];
            i.enumerable = i.enumerable || !1, i.configurable = !0, "value" in i && (i.writable = !0), 
            Object.defineProperty(e, i.key, i);
        }
    }
    return function(t, n, i) {
        return n && e(t.prototype, n), i && e(t, i), t;
    };
}(), s = t(require("../events.js")), a = e(require("../utils.js")), u = t(require("../../common/soundFXController.js")), c = require("../models/gameRound.js"), l = require("../widgets/pkDrawingCanvas.js"), h = require("../widgets/machineView.js"), d = require("../widgets/clock.js"), g = require("../config.js"), p = require("../../common/challengeStatus.js"), m = t(require("../imageEncoding.js")), C = require("./speechController.js"), v = e(require("../../game/api/playAPI.js")), f = e(require("../eventlog.js")), w = require("./pkDrawingRecognitionController.js"), k = t(require("../api/generateShareResultAPI.js")), E = require("../widgets/pkCompetitorCanvas"), L = require("../../libs/av-live-query-weapp-min"), S = require("../../libs/underscore/underscore.modified"), T = require("../models/words.js"), y = require("../../game/config/configManager"), R = 4, _ = 1, D = 7;

exports.PkGameController = function(e) {
    function t(e, o) {
        n(this, t);
        var r = i(this, (t.__proto__ || Object.getPrototypeOf(t)).call(this));
        r.page = e, r.room = o, r.currentUser = L.User.current(), r.competitors = [], r.skipRemaining = g.config.skip_num, 
        r.page.setData({
            skipRemaining: r.skipRemaining
        }), r.clock = new d.Clock(wx.createCanvasContext("round-clock"), y.getIntValue(y.PK_ROUND_TIME), _, R), 
        r.pkClock = new d.Clock(wx.createCanvasContext("global-clock"), y.getIntValue(y.PK_CHALLENGE_TIME), _), 
        r.pkClock.setPreText("本局 "), r.page.buttonClear = r.buttonClear.bind(r), r.page.buttonIngameHome = r.buttonIngameHome.bind(r), 
        r.page.buttonWaitingHome = r.buttonWaitingHome.bind(r), r.page.buttonSkip = r.buttonSkip.bind(r);
        var s = a.getWindowRpxSize();
        return r.drawingCanvas = new l.PkDrawingCanvas("drawingCanvas", r.page, a.rpxToPx(s.w), a.rpxToPx(s.h - 210)), 
        r.competitorCanvas = new E.PkCompetitorCanvas("competitorCanvas", r.page, {
            width: a.rpxToPx(588),
            height: a.rpxToPx(70),
            competitorCount: D,
            margin: 2
        }), r.machineView = new h.MachineView(r.page), r.recognitionController = new w.PkDrawingRecognitionController(r.drawingCanvas.getWidth(), r.drawingCanvas.getHeight()), 
        r.drawingUntouched = !0, r.drawingCanvas.addListener("INCREMENTAL_DRAWING_UPDATED", function(e, t) {
            r.onIncrementalDrawingUpdated(t);
        }), r.clock.addListener(d.Clock.EVENT_TIME_UP, function() {
            return r.roundTimesUp();
        }), r.pkClock.addListener(d.Clock.EVENT_TIME_UP, function() {
            return r.pkTimesUp();
        }), r.pkClock.addListener(d.Clock.EVENT_TIME_UPDATE, function(e) {
            return r.pkTimeUpdate(e);
        }), r.recognitionController.addListener(w.PkDrawingRecognitionControllerEvents.NEW_RECOGNITIONS, function(e) {
            return r.onNewRecognitions(e);
        }), r.page.setData({
            myAvatarUrl: r.currentUser.get("avatarUrl")
        }), r.competitors = [], r.players = [], r.refreshCompetitorBar({}), r.pkShakeTime = y.getIntValue(y.PK_SHAKE_TIME), 
        f.getContext().initGame(), r;
    }
    return o(t, s.default), r(t, [ {
        key: "pkTimeUpdate",
        value: function(e) {
            e <= this.pkShakeTime && this.page.setData({
                isCountingDown: !0
            });
            var t = e <= 15 ? "#EA4335" : "#174EA6", n = e <= 15 ? "#FBD9D7" : "#E7EDF6", i = [ {
                data: this.durationSeconds - e,
                color: n
            }, {
                data: e,
                color: t
            } ];
            this.pkClock.setTextColor(t), this.page.drawPieClock(i);
        }
    }, {
        key: "buttonClear",
        value: function() {
            this.drawingCanvas.isInputIgnored() || !this.recognitionController.isRecognizing || this.isRecognized || (u.default.play("erase"), 
            this.clearCanvas());
        }
    }, {
        key: "buttonSkip",
        value: function() {
            0 == this.skipRemaining || this.isRecognized || this.isSkipped || (u.default.play("swish"), 
            this.isSkipped = !0, --this.skipRemaining, this.page.setData({
                skipRemaining: this.skipRemaining
            }), this.onIncrementalDrawingUpdated({
                event: "skip"
            }), this.pauseGame(), this.finishCurrentRound({
                recognition: !1
            }), this.startNextRound());
        }
    }, {
        key: "clearCanvas",
        value: function() {
            this.machineView.reset(), this.drawingCanvas.clear();
        }
    }, {
        key: "showExitModal",
        value: function(e, t) {
            var n = this;
            wx.showModal({
                title: "确定要离开吗",
                content: e,
                cancelText: "继续比画",
                confirmText: "狠心离开",
                success: function(e) {
                    if (e.confirm) {
                        var i = f.getContext().data();
                        n.appendPlayerCount(i), i.stage = t, f.logEvent("challenge_leave_room", i);
                        try {
                            v.leaveRoom();
                        } catch (e) {
                            console.log("Pk home tap error", e);
                        }
                        getApp().redirectToHome();
                    }
                }
            });
        }
    }, {
        key: "buttonWaitingHome",
        value: function() {
            this.showExitModal("你将会离开此局", "Waiting");
        }
    }, {
        key: "buttonIngameHome",
        value: function() {
            this.showExitModal("你将会离开此局并无法返回", "InGame");
        }
    }, {
        key: "unload",
        value: function() {
            this.unloaded = !0, this.challengeStatusListener && (v.getEventEmitter().removeListener("S2C_CHALLENGE_STATUS_UPDATED", this.challengeStatusListener), 
            this.challengeStatusListener = void 0), this.challengeCompletedListener && (v.getEventEmitter().removeListener("S2C_CHALLENGE_COMPLETED", this.challengeCompletedListener), 
            this.challengeCompletedListener = void 0), this.challengeSaveCompletedListener && (v.getEventEmitter().removeListener("S2C_CHALLENGE_SAVE_COMPLETED", this.challengeSaveCompletedListener), 
            this.challengeSaveCompletedListener = void 0), this.disconnectedEventListener && (v.getEventEmitter().removeListener("DISCONNECTED", this.disconnectedEventListener), 
            this.disconnectedEventListener = void 0), this.drawingEventListener && (v.getEventEmitter().removeListener("C2ALL_INCREMENTAL_DRAWING", this.drawingEventListener), 
            this.drawingEventListener = void 0);
        }
    }, {
        key: "showGame",
        value: function() {
            this.recognitionController.start(), this.machineView.show();
        }
    }, {
        key: "onUsersInfoUpdated",
        value: function(e) {
            var t = this;
            this.players = [], this.competitors = [], e.forEach(function(e) {
                if (e.userInfo) if (t.players.push({
                    userId: e.userId,
                    avatarUrl: e.userInfo.avatarUrl,
                    nickName: e.userInfo.nickName
                }), e.userId !== t.currentUser.id) {
                    var n = {
                        userId: e.userId,
                        avatarUrl: e.userInfo.avatarUrl,
                        nickName: e.userInfo.nickName,
                        actorId: e.actorId
                    };
                    e.isHost ? t.competitors.splice(0, 0, n) : t.competitors.push(n);
                } else e.isHost && t.page.setData({
                    isHost: !0
                });
            });
            for (var n = 0; n < this.competitors.length && n < D; n++) this.competitorCanvas.registerCompetitorKey(this.competitors[n].actorId, n);
            this.players.length > 0 && this.page.setData({
                competitors: this.competitors,
                competitorsPlaceholder: Array(D - this.competitors.length),
                players: this.players,
                playersPlaceholder: Array(Math.max(D - this.players.length, 0))
            });
        }
    }, {
        key: "onStartChallenge",
        value: function(e) {
            var t = this;
            console.log("Start challenge with params", e), f.logEvent("challenge_start", this.appendPlayerCount(f.getContext().data())), 
            this.resultPageUsersInfo = v.getUsersInfo(), this.durationSeconds = e.durationSeconds, 
            this.status = p.ChallengeStatus.CHALLENGE_STATUS_PLAY, this.reset(), e.currentSeconds && this.pkClock.setTimeLeft(this.durationSeconds - e.currentSeconds), 
            e.currentRound && (this.roundCount = e.currentRound - 1), this.words = e.words, 
            this.challengeStatusListener = function(e) {
                t.onChallengeStatusUpdated(e);
            }, this.drawingEventListener = function(e, n) {
                t.onDrawingEvent(e, n);
            }, this.challengeCompletedListener = function(e) {
                t.onChallengeCompleted(e);
            }, this.challengeSaveCompletedListener = function(e) {
                t.onChallengeSaveCompleted(e);
            }, this.disconnectedEventListener = function() {
                t.onDisconnected();
            }, v.getEventEmitter().addListener("C2ALL_INCREMENTAL_DRAWING", this.drawingEventListener), 
            v.getEventEmitter().addListener("S2C_CHALLENGE_STATUS_UPDATED", this.challengeStatusListener), 
            v.getEventEmitter().addListener("S2C_CHALLENGE_COMPLETED", this.challengeCompletedListener), 
            v.getEventEmitter().addListener("S2C_CHALLENGE_SAVE_COMPLETED", this.challengeSaveCompletedListener), 
            v.getEventEmitter().addListener("DISCONNECTED", this.disconnectedEventListener), 
            this.status = p.ChallengeStatus.CHALLENGE_STATUS_PLAY, this.page.setData({
                status: p.ChallengeStatus.CHALLENGE_STATUS_PLAY,
                isWarmUp: !0,
                condition: e.condition
            }, function() {
                u.default.play("count-down");
            });
            var n = setInterval(function() {
                t.page.setData({
                    isWarmUp: !1
                }), t.startPkTimeout = setTimeout(function() {
                    t.pkClock.startClock();
                }, 2e3), t.startNextRound(), clearInterval(n);
            }, 3e3);
        }
    }, {
        key: "onDisconnected",
        value: function() {
            this.page.isForeground && v.reconnectAndRejoinWithBackoff().catch(function(e) {
                console.error(e), wx.showModal({
                    title: "网络故障",
                    content: "网络不太给力。请过会再试。",
                    showCancel: !1,
                    success: function(e) {
                        getApp().redirectToHome();
                    }
                });
            });
        }
    }, {
        key: "refreshCompetitorBar",
        value: function(e) {
            var t = this;
            for (var n in e) !function(n) {
                if (e.hasOwnProperty(n)) {
                    var i = S.find(t.competitors, function(e) {
                        return e.userId === n;
                    });
                    i && (i.roundPassed = e[n].roundPassed);
                }
            }(n);
            var i = e[this.currentUser.id];
            i && i.roundPassed && this.page.setData({
                myRoundPassed: i.roundPassed
            }), this.page.setData({
                competitors: this.competitors,
                competitorsPlaceholder: Array(D - this.competitors.length)
            });
        }
    }, {
        key: "refreshCompetitorDrawings",
        value: function(e, t) {
            S.find(this.competitors, function(e) {
                return e.actorId === t;
            }) && this.competitorCanvas.updateDrawing(t, e.drawingData.width, e.drawingData.height, e.drawingData.incrementalDrawing), 
            this.page.setData({
                competitors: this.competitors,
                competitorsPlaceholder: Array(D - this.competitors.length)
            });
        }
    }, {
        key: "refreshBatchCompetitorDrawings",
        value: function(e) {
            var t = this;
            for (var n in e) !function(n) {
                if (e.hasOwnProperty(n)) {
                    var i = e[n].batchIncrementalDrawing;
                    if (i && i.length > 0) {
                        var o = S.find(t.competitors, function(e) {
                            return e.userId === n;
                        });
                        if (o) for (var r = o.actorId, s = 0; s < i.length; s++) {
                            var a = i[s];
                            t.refreshCompetitorDrawings(a, r);
                        }
                    }
                }
            }(n);
        }
    }, {
        key: "onChallengeStatusUpdated",
        value: function(e) {
            console.log("onChallengeStatusUpdated", e), this.refreshCompetitorBar(e), this.refreshBatchCompetitorDrawings(e);
        }
    }, {
        key: "onDrawingEvent",
        value: function(e, t) {
            console.log("onDrawingEvent", "sender: " + t, e), this.refreshCompetitorDrawings(e, t);
        }
    }, {
        key: "onChallengeCompleted",
        value: function(e) {
            console.log("Challenge Completed");
        }
    }, {
        key: "onChallengeSaveCompleted",
        value: function(e) {
            if (this.status !== p.ChallengeStatus.CHALLENGE_STATUS_END && e.roomName === this.room.roomName) {
                if (console.log("challenge save completed:", e), this.status = p.ChallengeStatus.CHALLENGE_STATUS_END, 
                this.page.setData({
                    status: this.status
                }), !e.success) return this.page.setData({
                    gameOverFailed: "saveFailed"
                }), void v.leaveRoom();
                getApp().setLastPkData({
                    userChallengeId: e.userChallengeId,
                    usersInfo: this.resultPageUsersInfo
                }), v.leaveRoom(), this.endGame();
            }
        }
    }, {
        key: "reset",
        value: function() {
            this.presentedWords = [], this.previousRounds = [], this.words = [], this.competition = void 0, 
            this.roundCount = 0, this.newGuessesCounter = 0, this.clock.reset(), this.pkClock.reset(), 
            this.startNextRoundTimeout && clearTimeout(this.startNextRoundTimeout), this.startPkTimeout && clearTimeout(this.startPkTimeout), 
            this.transTimeOut && clearTimeout(this.transTimeOut), this.clearCanvas(), this.recognitionController.stop();
        }
    }, {
        key: "finishCurrentRound",
        value: function(e) {
            this.recognitionController.stop(), this.drawingCanvas.ignoreInput(), this.currentRound.drawing = m.default.encode(this.drawingCanvas.getSegments()), 
            this.currentRound.width = this.drawingCanvas.getWidth(), this.currentRound.height = this.drawingCanvas.getHeight(), 
            this.currentRound.recognized = !!e.recognition, this.currentRound.recognitionId = e.recognition ? e.recognition.id : 0, 
            this.currentRound.score = e.recognition ? parseFloat(e.recognition.score) : 999, 
            this.currentRound.duration = Math.round(10 * this.clock.getTimeElapsed()) / 10, 
            this.previousRounds.push(this.currentRound);
        }
    }, {
        key: "shouldEndGame",
        value: function() {
            return this.roundCount > this.words.length || this.status != p.ChallengeStatus.CHALLENGE_STATUS_PLAY;
        }
    }, {
        key: "startNextRound",
        value: function() {
            var e = this;
            if (this.unloaded) console.log("unloaded error"); else if (this.shouldEndGame()) console.log("should end game error"); else {
                this.roundCount++, this.isRecognized = !1, this.isSkipped = !1;
                var t = this.words[this.roundCount - 1];
                C.SpeechController.clearQueue();
                var n = T.getWord(t);
                n && C.SpeechController.preload(T.getTTSUrl(n)), this.currentRound = new c.GameRound(t, this.roundCount), 
                this.presentedWords.push(this.currentRound.word), this.page.setData({
                    word: this.currentRound.wordZhCn,
                    level: "第 " + this.roundCount + " 题",
                    animClass: "center-text",
                    isRecognized: this.isRecognized
                }, function() {
                    e.continueStartNextRound();
                });
            }
        }
    }, {
        key: "continueStartNextRound",
        value: function() {
            var e = this;
            console.log("continueStartNextRound", this.roundCount);
            this.startNextRoundTimeout = setTimeout(function() {
                e.page.setData({
                    animClass: "on-screen"
                }), e.clock.startClock(), e.machineView.show(), e.drawingCanvas.acceptInput();
            }, 2e3), this.recognitionController.start(), this.drawingCanvas.clear(), this.drawingCanvas.show(), 
            this.machineView.reset(), this.machineView.hide(), this.clock.reset();
        }
    }, {
        key: "pauseGame",
        value: function() {
            this.clock.pauseClock();
        }
    }, {
        key: "resumeGame",
        value: function() {
            this.clock.startClock();
        }
    }, {
        key: "hideGame",
        value: function() {
            this.recognitionController.stop(), this.machineView.stop();
        }
    }, {
        key: "roundRecognized",
        value: function(e) {
            var t = this;
            this.isRecognized = !0, this.page.setData({
                isRecognized: this.isRecognized
            }), u.default.play("correct"), this.pauseGame(), this.machineView.setResultWord(e).then(function() {
                t.unloaded || (t.finishCurrentRound({
                    recognition: e
                }), t.startNextRound());
            });
        }
    }, {
        key: "roundTimesUp",
        value: function() {
            this.pauseGame(), this.finishCurrentRound({
                recognition: !1
            }), this.startNextRound();
        }
    }, {
        key: "pkTimesUp",
        value: function() {
            this.clock.pauseClock(), this.pkClock.pauseClock(), this.status = p.ChallengeStatus.CHALLENGE_STATUS_END, 
            this.recognitionController.stop(), this.machineView.reset(), this.drawingCanvas.hide(), 
            this.page.showGameOverCard();
        }
    }, {
        key: "endGame",
        value: function() {
            this.status !== p.ChallengeStatus.CHALLENGE_STATUS_PLAY && this.pkTimesUp(), f.logEvent("challenge_end", this.appendPlayerCount(f.getContext().data()));
        }
    }, {
        key: "onNewRecognitions",
        value: function(e) {
            var t = this;
            if (this.roundCount - 1 === e.roundNumber && this.recognitionController.isRecognizing && !this.isRecognized) {
                var n = S.find(e, function(e) {
                    return e.recognized;
                });
                if (this.currentRound && n) this.roundRecognized(n); else if (this.currentRound) {
                    e = S.filter(e, function(e) {
                        return e.word != t.currentRound.word && null != e.translation;
                    });
                    var i = S.pluck(e, "translation");
                    i = S.filter(i, function(e) {
                        return e.Translations.ZhCn != t.currentRound.wordZhCn;
                    }), 0 == this.machineView.setGuesses(i) ? this.newGuessesCounter++ : this.newGuessesCounter = 0, 
                    this.newGuessesCounter > 2 && (this.newGuessesCounter = 0, this.machineView.speakAndWrite(a.pickRandom(g.config.noNewGuessesSentences)));
                }
            }
        }
    }, {
        key: "onIncrementalDrawingUpdated",
        value: function(e) {
            this.recognitionController.onIncrementalDrawingUpdated(this.roundCount - 1, e), 
            this.drawingUntouched && (this.drawingUntouched = !1, this.machineView.setText("..."));
        }
    }, {
        key: "createSharePhoto",
        value: function(e) {
            var t = {
                cId: this.competition.id,
                userId: this.currentUser.id
            };
            k.default.generateShareResult(t, e);
        }
    }, {
        key: "appendPlayerCount",
        value: function(e) {
            return e.player_count = this.players.length, e;
        }
    } ]), t;
}();