function e(e, t) {
    if (!(e instanceof t)) throw new TypeError("Cannot call a class as a function");
}

function t(e, t) {
    if (!e) throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
    return !t || "object" != typeof t && "function" != typeof t ? e : t;
}

function n(e, t) {
    if ("function" != typeof t && null !== t) throw new TypeError("Super expression must either be null or a function, not " + typeof t);
    e.prototype = Object.create(t && t.prototype, {
        constructor: {
            value: e,
            enumerable: !1,
            writable: !0,
            configurable: !0
        }
    }), t && (Object.setPrototypeOf ? Object.setPrototypeOf(e, t) : e.__proto__ = t);
}

Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.RoomController = void 0;

var o = function() {
    function e(e, t) {
        for (var n = 0; n < t.length; n++) {
            var o = t[n];
            o.enumerable = o.enumerable || !1, o.configurable = !0, "value" in o && (o.writable = !0), 
            Object.defineProperty(e, o.key, o);
        }
    }
    return function(t, n, o) {
        return n && e(t.prototype, n), o && e(t, o), t;
    };
}(), r = function(e) {
    if (e && e.__esModule) return e;
    var t = {};
    if (null != e) for (var n in e) Object.prototype.hasOwnProperty.call(e, n) && (t[n] = e[n]);
    return t.default = e, t;
}(require("../../game/api/playAPI.js")), i = require("./pkGameController.js"), s = function(e) {
    return e && e.__esModule ? e : {
        default: e
    };
}(require("../events.js")), a = require("../../libs/underscore/underscore.modified");

exports.RoomController = function(l) {
    function c(n) {
        e(this, c);
        var o = t(this, (c.__proto__ || Object.getPrototypeOf(c)).call(this));
        return o.usersInfo = [], o.page = n, o.handlersRegistered = !1, o.gameController = new i.PkGameController(o.page, o), 
        o.currentUser = o.gameController.currentUser, o;
    }
    return n(c, s.default), o(c, [ {
        key: "getGameController",
        value: function() {
            return this.gameController;
        }
    }, {
        key: "createAndJoinRoom",
        value: function() {
            var e = this;
            return r.createRoom().then(function(t) {
                console.log("Room " + t + " created."), e.joinRoom(t);
            });
        }
    }, {
        key: "joinRoom",
        value: function(e) {
            var t = this;
            return this.roomName = e, this.hasShownKickOff = !1, this.handlersRegistered || (this.customPropertiesChangedListener = function(e) {
                t.onPlayerCustomPropertiesChanged(e);
            }, this.challengeStartedListener = function(e) {
                t.onChallengeStarted(e);
            }, this.challengeUpdatedListener = function() {
                t.onChallengeUpdated();
            }, this.playerRoomLeftListener = function(e) {
                t.onPlayerRoomLeft(e);
            }, this.disconnectedListener = function() {
                t.onDisconnected();
            }, this.challengeSavedListener = function() {
                t.onChallengeSaved();
            }, this.roomKickOffListener = function(e) {
                t.onRoomKickOff(e);
            }, r.getEventEmitter().addListener("PLAYER_CUSTOM_PROPERTIES_CHANGED", this.customPropertiesChangedListener), 
            r.getEventEmitter().addListener("PLAYER_ROOM_LEFT", this.playerRoomLeftListener), 
            r.getEventEmitter().addListener("S2C_CHALLENGE_STARTED", this.challengeStartedListener), 
            r.getEventEmitter().addListener("DISCONNECTED", this.disconnectedListener), r.getEventEmitter().addListener("S2C_CHALLENGE_STATUS_UPDATED", this.challengeUpdatedListener), 
            r.getEventEmitter().addListener("S2C_CHALLENGE_SAVE_COMPLETED", this.challengeSavedListener), 
            r.getEventEmitter().addListener("S2C_ROOM_KICK_OFF", this.roomKickOffListener), 
            this.handlersRegistered = !0), r.joinRoom(e).then(function() {
                r.updateMyUserInfo(), t.reloadUsersInfo();
            });
        }
    }, {
        key: "onPlayerRoomLeft",
        value: function(e) {
            for (var t = 0; t < this.usersInfo.length; t++) if (this.usersInfo[t].userId === e) return this.usersInfo.splice(t, 1), 
            void this.notifyUsersInfoUpdated();
        }
    }, {
        key: "onChallengeUpdated",
        value: function() {
            r.sendCustomEvent("C2S_RESEND_START", {}), this.challengeUpdatedListener && r.getEventEmitter().removeListener("S2C_CHALLENGE_STATUS_UPDATED", this.challengeUpdatedListener);
        }
    }, {
        key: "onDisconnected",
        value: function() {
            this.page.isForeground && r.reconnectAndRejoinWithBackoff().catch(function(e) {
                console.error(e), wx.showModal({
                    title: "网络故障",
                    content: "网络不太给力。请过会再试。",
                    showCancel: !1,
                    success: function(e) {
                        getApp().redirectToHome();
                    }
                });
            });
        }
    }, {
        key: "onChallengeSaved",
        value: function() {
            this.unload(), r.leaveRoom(), wx.showModal({
                title: "游戏已结束",
                content: "游戏已经结束了。请再开一局吧！",
                success: function(e) {
                    getApp().redirectToHome();
                }
            });
        }
    }, {
        key: "onStartChallengeButton",
        value: function() {
            r.sendCustomEvent("C2S_START_CHALLENGE", {});
        }
    }, {
        key: "onChallengeStarted",
        value: function(e) {
            this.reloadUsersInfo(), this.gameController.onStartChallenge(e), this.unload();
        }
    }, {
        key: "getRoomName",
        value: function() {
            return this.roomName;
        }
    }, {
        key: "onRoomKickOff",
        value: function(e) {
            e.roomName !== this.roomName || this.hasShownKickOff || (this.hasShownKickOff = !0, 
            wx.showModal({
                title: "房主已离开",
                content: "房主已离开，你将返回首页",
                showCancel: !1,
                success: function(e) {
                    try {
                        r.leaveRoom();
                    } catch (e) {
                        console.log("Kick off leave room error", e);
                    }
                    getApp().redirectToHome();
                }
            }));
        }
    }, {
        key: "onPlayerCustomPropertiesChanged",
        value: function(e) {
            e.changedProps && (this.updateUserInfo(e.player.userId, e.changedProps, e.player.actorId), 
            this.notifyUsersInfoUpdated());
        }
    }, {
        key: "updateUserInfo",
        value: function(e, t, n) {
            var o = a.find(this.usersInfo, function(t) {
                return t.userId === e;
            });
            o || (o = {
                userId: e,
                actorId: n
            }, this.usersInfo.push(o)), t.userInfo && (o.userInfo = t.userInfo), t.isHost && (o.isHost = t.isHost);
        }
    }, {
        key: "notifyUsersInfoUpdated",
        value: function() {
            this.gameController.onUsersInfoUpdated(this.usersInfo);
        }
    }, {
        key: "reloadUsersInfo",
        value: function() {
            console.log("reloading user info"), this.usersInfo = r.getUsersInfo(), this.notifyUsersInfoUpdated();
        }
    }, {
        key: "unload",
        value: function() {
            this.customPropertiesChangedListener && (r.getEventEmitter().removeListener("PLAYER_CUSTOM_PROPERTIES_CHANGED", this.customPropertiesChangedListener), 
            this.customPropertiesChangedListener = void 0), this.playerRoomLeftListener && (r.getEventEmitter().removeListener("PLAYER_ROOM_LEFT", this.playerRoomLeftListener), 
            this.playerRoomLeftListener = void 0), this.challengeStartedListener && (r.getEventEmitter().removeListener("S2C_CHALLENGE_STARTED", this.challengeStartedListener), 
            this.challengeStartedListener = void 0), this.disconnectedListener && (r.getEventEmitter().removeListener("DISCONNECTED", this.disconnectedListener), 
            this.disconnectedListener = void 0), this.challengeUpdatedListener && (r.getEventEmitter().removeListener("S2C_CHALLENGE_STATUS_UPDATED", this.challengeUpdatedListener), 
            this.challengeUpdatedListener = void 0), this.challengeSavedListener && (r.getEventEmitter().removeListener("S2C_CHALLENGE_SAVE_COMPLETED", this.challengeSavedListener), 
            this.challengeSavedListener = void 0), this.roomKickOffListener && (r.getEventEmitter().removeListener("S2C_ROOM_KICK_OFF", this.roomKickOffListener), 
            this.roomKickOffListener = void 0);
        }
    } ]), c;
}();