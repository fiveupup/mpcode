function e(e, t) {
    if (!(e instanceof t)) throw new TypeError("Cannot call a class as a function");
}

function t(e, t) {
    if (!e) throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
    return !t || "object" != typeof t && "function" != typeof t ? e : t;
}

function n(e, t) {
    if ("function" != typeof t && null !== t) throw new TypeError("Super expression must either be null or a function, not " + typeof t);
    e.prototype = Object.create(t && t.prototype, {
        constructor: {
            value: e,
            enumerable: !1,
            writable: !0,
            configurable: !0
        }
    }), t && (Object.setPrototypeOf ? Object.setPrototypeOf(e, t) : e.__proto__ = t);
}

Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.PkDrawingRecognitionController = exports.PkDrawingRecognitionControllerEvents = void 0;

var r = function() {
    function e(e, t) {
        for (var n = 0; n < t.length; n++) {
            var r = t[n];
            r.enumerable = r.enumerable || !1, r.configurable = !0, "value" in r && (r.writable = !0), 
            Object.defineProperty(e, r.key, r);
        }
    }
    return function(t, n, r) {
        return n && e(t.prototype, n), r && e(t, r), t;
    };
}(), i = require("../config.js"), o = function(e) {
    return e && e.__esModule ? e : {
        default: e
    };
}(require("../events.js")), s = function(e) {
    if (e && e.__esModule) return e;
    var t = {};
    if (null != e) for (var n in e) Object.prototype.hasOwnProperty.call(e, n) && (t[n] = e[n]);
    return t.default = e, t;
}(require("../api/playAPI.js")), u = require("../../common/incrementalDrawing.js"), a = require("../../libs/underscore/underscore.modified"), c = exports.PkDrawingRecognitionControllerEvents = {
    NEW_RECOGNITIONS: "NEW_RECOGNITIONS"
};

exports.PkDrawingRecognitionController = function(l) {
    function f(n, r) {
        e(this, f);
        var o = t(this, (f.__proto__ || Object.getPrototypeOf(f)).call(this));
        return o.canvasWidth = n, o.canvasHeight = r, o.processDrawingThrottle = a.throttle(function() {
            return o.processDrawing();
        }, 1e3 * i.config.max_pk_incremental_stroke_rate, {
            leading: !1
        }), o.isRecognizing = !1, o.pendingEventBuffer = [], o.reset(), o;
    }
    return n(f, o.default), r(f, [ {
        key: "reset",
        value: function() {
            this.roundNumber = void 0, this.lastSeqNumber = void 0, this.isRecognizing = !1;
        }
    }, {
        key: "start",
        value: function() {
            var e = this;
            this.reset(), this.isRecognizing = !0, this.recognitionResultListener = function(t) {
                if (e.isRecognizing && (!e.lastSeqNumber || e.lastSeqNumber < t.seqNumber)) {
                    e.lastSeqNumber = t.seqNumber;
                    var n = e.filterGuesses(t.recognitions);
                    n.roundNumber = t.roundNumber, e.emit(c.NEW_RECOGNITIONS, n);
                }
            }, s.getEventEmitter().addListener("S2C_RECOGNITION_RESULT", this.recognitionResultListener);
        }
    }, {
        key: "stop",
        value: function() {
            this.isRecognizing = !1, s.getEventEmitter().removeListener("S2C_RECOGNITION_RESULT", this.recognitionResultListener);
        }
    }, {
        key: "processDrawing",
        value: function() {
            if (0 !== this.pendingEventBuffer.length) {
                var e = Object.assign(this.pendingEventBuffer);
                this.pendingEventBuffer = [], s.processSegments(this.roundNumber, e, this.canvasWidth, this.canvasHeight);
            }
        }
    }, {
        key: "filterGuesses",
        value: function(e) {
            return a.filter(e, function(e) {
                return e.recognized || e.score < i.config.handwriting_threshold;
            });
        }
    }, {
        key: "onIncrementalDrawingUpdated",
        value: function(e, t) {
            if (this.isRecognizing) {
                if (this.roundNumber && this.roundNumber !== e && this.processDrawing(), this.roundNumber = e, 
                !t) return;
                this.pendingEventBuffer.push(t), t.event === u.IncrementalDrawingEvent.CLEAR || t.event === u.IncrementalDrawingEvent.SKIP ? this.processDrawing() : this.processDrawingThrottle();
            }
        }
    } ]), f;
}();