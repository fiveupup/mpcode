function e(e) {
    if (e && e.__esModule) return e;
    var t = {};
    if (null != e) for (var n in e) Object.prototype.hasOwnProperty.call(e, n) && (t[n] = e[n]);
    return t.default = e, t;
}

function t(e) {
    return e && e.__esModule ? e : {
        default: e
    };
}

function n(e, t) {
    if (!(e instanceof t)) throw new TypeError("Cannot call a class as a function");
}

function i(e, t) {
    if (!e) throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
    return !t || "object" != typeof t && "function" != typeof t ? e : t;
}

function s(e, t) {
    if ("function" != typeof t && null !== t) throw new TypeError("Super expression must either be null or a function, not " + typeof t);
    e.prototype = Object.create(t && t.prototype, {
        constructor: {
            value: e,
            enumerable: !1,
            writable: !0,
            configurable: !0
        }
    }), t && (Object.setPrototypeOf ? Object.setPrototypeOf(e, t) : e.__proto__ = t);
}

Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.EndlessGameController = void 0;

var o = function() {
    function e(e, t) {
        for (var n = 0; n < t.length; n++) {
            var i = t[n];
            i.enumerable = i.enumerable || !1, i.configurable = !0, "value" in i && (i.writable = !0), 
            Object.defineProperty(e, i.key, i);
        }
    }
    return function(t, n, i) {
        return n && e(t.prototype, n), i && e(t, i), t;
    };
}(), a = t(require("../events.js")), r = e(require("../eventlog.js")), u = e(require("../api/gameAPI.js")), d = e(require("../mockData.js")), h = e(require("../utils.js")), l = t(require("../api/playHistoryAPI.js")), c = t(require("../api/leaderboardAPI.js")), g = t(require("../../common/soundFXController.js")), m = require("../models/gameRound.js"), p = require("../widgets/drawingCanvas.js"), f = require("../widgets/cardsView.js"), w = require("../widgets/machineView.js"), v = require("../widgets/clock.js"), C = require("../config.js"), y = t(require("../imageEncoding.js")), R = require("../controllers/speechController.js"), k = require("./drawingRecognitionController.js"), P = t(require("../api/generateShareResultAPI.js")), T = t(require("../api/handwritingAPI.js")), E = require("../models/words"), _ = require("../api/partyAPI"), G = require("../../libs/underscore/underscore.modified"), L = require("../../libs/av-live-query-weapp-min").User, V = (require("../config/configManager"), 
5), S = .1;

exports.EndlessGameController = function(e) {
    function t(e, s) {
        n(this, t);
        var o = i(this, (t.__proto__ || Object.getPrototypeOf(t)).call(this));
        o.page = e, o.invitedCompetition = s, o.user = L.current(), o.finalEndGamePromise = void 0, 
        o.recognitionController = new k.DrawingRecognitionController(T.default.processSegments), 
        o.clock = new v.Clock(wx.createCanvasContext("round-clock"), C.config.round_length, S, V), 
        o.page.buttonClear = o.buttonClear.bind(o), o.page.buttonHome = o.buttonHome.bind(o), 
        o.page.partyEndConfirm = o.partyEndConfirm.bind(o);
        var a = h.getWindowSize();
        return o.drawingCanvas = new p.DrawingCanvas("drawingCanvas", o.page, a.w - 42, a.h - 68), 
        o.cardsView = new f.CardsView(o.page), o.machineView = new w.MachineView(o.page), 
        o.newCongratLevel = null, o.drawingUntouched = !0, o.drawingCanvas.addListener("DRAWING_UPDATED", function(e) {
            o.onDrawingUpdated(e);
        }), o.cardsView.addListener("START_GAME", function() {
            return o.startGame();
        }), o.cardsView.addListener("PLAY_AGAIN", function() {
            var e = r.getContext();
            e.retry_count++, r.logEvent("play_again", e), o.openGame();
        }), o.cardsView.addListener("BACK_TO_HOME", function() {
            return wx.redirectTo({
                url: "/pages/home/home"
            });
        }), o.cardsView.addListener("CHECK_RANKING", function() {
            return wx.navigateTo({
                url: "/pages/ranking/ranking"
            });
        }), o.cardsView.addListener("CREATE_SHARE_PHOTO", function() {
            r.logEvent("long_image", r.getContext().data()), P.default.checkSaveImagePermission(function() {
                o.createSharePhoto(function(e) {
                    o.cardsView.showSavedPhotoDialog(e);
                });
            });
        }), o.cardsView.addListener("CREATE_THEME_SHARE_PHOTO", function() {
            r.logEvent("long_image", r.getContext().data()), P.default.checkSaveImagePermission(function() {
                o.createThemeSharePhoto(function(e) {
                    o.cardsView.showSavedPhotoDialog(e);
                });
            });
        }), o.cardsView.addListener("RETRY_SAVE", function() {
            o.isForceEnd ? o.retryForceEnd() : o.saveResults(0);
        }), o.clock.addListener(v.Clock.EVENT_TIME_UP, function() {
            return o.roundTimesUp();
        }), o.clock.addListener(v.Clock.EVENT_COUNT_DOWN_UPDATE, function(e) {
            return o.countDownUpdate(e);
        }), o.clock.addListener(v.Clock.EVENT_TIME_ELAPSED_PERCENT, function(e) {
            return o.roundTimesElapsedPercent(e);
        }), o.recognitionController.addListener(k.DrawingRecognitionControllerEvents.NEW_RECOGNITIONS, function(e) {
            return o.onNewRecognitions(e);
        }), e.data.isPartyMode && (o.isPartyMode = !0, o.machineView.setData("isPartyMode", !0), 
        _.setEventListener({
            onRankChange: function(e, t, n) {
                o.machineView.setData("currentRank", e), o.machineView.setData("safeRange", t), 
                o.cardsView.setData("rank", e), o.cardsView.setData("total_players", n);
            },
            onStatusChange: function(e) {
                o.isForceEnd || "END" == e && (o.cardsView.setData("killedReason", "timeup"), o.forceEnd());
            },
            onPlayerStatusChange: function(e) {
                o.isForceEnd || ("FailByRankLimit" == e ? o.cardsView.setData("killedReason", "range") : o.cardsView.setData("killedReason", "timeout"), 
                o.forceEnd());
            }
        })), o;
    }
    return s(t, a.default), o(t, [ {
        key: "buttonClear",
        value: function() {
            !this.drawingCanvas.isInputIgnored() && this.recognitionController.isRecognizing && (g.default.play("erase"), 
            this.clearCanvas());
        }
    }, {
        key: "countDownUpdate",
        value: function(e) {
            this.page.setData({
                isCountingDown: e
            });
        }
    }, {
        key: "clearCanvas",
        value: function() {
            this.machineView.reset(), this.drawingCanvas.clear();
        }
    }, {
        key: "buttonHome",
        value: function() {
            wx.redirectTo({
                url: "/pages/home/home"
            });
        }
    }, {
        key: "prepareGame",
        value: function() {
            var e = this;
            if (!this.preparing) if (this.preparedCompetition) this.postPrepare && this.postPrepare(); else {
                this.preparing = !0;
                var t = {
                    playHistoryId: l.default.getLatestPlayHistory().id,
                    userId: L.current().id
                };
                this.theme && (t.theme = this.theme), this.invitedCompetition && (t.invitedCompetitionId = this.invitedCompetition.id), 
                this.previousRounds && this.previousRounds.length > 1 && (t.lastFailedWord = this.previousRounds[this.previousRounds.length - 1].word), 
                u.startEndlessGame(t).then(function(t) {
                    if (!e.unloaded) {
                        if (e.preparedCompetition = t, e.isPartyMode) {
                            var n = _.getWords();
                            n && (e.preparedCompetition.attributes.challengeWords = n);
                        }
                        e.preparing = !1, e.postPrepare && e.postPrepare();
                    }
                }).catch(function(t) {
                    console.log("cannot start game:", t), e.showModalToHome("网络故障", "网络不给力，请稍后重试");
                });
            }
        }
    }, {
        key: "unload",
        value: function() {
            this.unloaded = !0, 1 === this.state && r.logEvent("abandon_game", r.getContext().data());
        }
    }, {
        key: "getLocalPassedWordsCopy",
        value: function(e) {
            return e.get("passedWords").slice();
        }
    }, {
        key: "openGame",
        value: function() {
            console.log("Open Game"), this.reset(), this.localPassedWords = this.getLocalPassedWordsCopy(l.default.getLatestPlayHistory()), 
            this.theme && l.default.getLatestPlayHistory().getThemeCompleted(this.theme) && (this.themeCompleted = !0), 
            this.setLevelTheme(1), !this.isPartyMode && this.localPassedWords.length <= C.config.tutorial_round_threshold ? (this.drawingCanvas.hide(), 
            this.cardsView.showTutorialCard({
                theme: this.theme
            })) : this.startGame();
        }
    }, {
        key: "startGame",
        value: function() {
            var e = this;
            console.log("Start Game"), this.postPrepare = function() {
                e.competition = e.preparedCompetition, e.preparedCompetition = null, e.postPrepare = null, 
                e.challengeWords = e.competition.get("challengeWords");
                var t = r.getContext();
                t.play_count++, t.initGame(e.theme), e.updateLogContext(t), r.logEvent("start_game", t.data()), 
                e.state = 1, e.startNextRound();
            }, this.preparedCompetition ? this.postPrepare() : this.prepareGame();
        }
    }, {
        key: "updateLogContext",
        value: function(e) {
            e.round_count = this.roundCount, e.level_n = h.getLevel(this.localPassedWords.length);
        }
    }, {
        key: "mockShowEndCard",
        value: function() {
            var e = new d.Competition();
            this.cardsView.showEndlessEndCard(!1, 123, d.roundResults.slice(0), this.user, e.id, "Level Str", 28, "outerspace");
        }
    }, {
        key: "showEndCardWithCompetition",
        value: function(e) {
            this.drawingCanvas.hide(), this.cardsView.showEndlessEndCard(!1, [], e.get("result").detailed, this.user, e.id);
        }
    }, {
        key: "setLevelTheme",
        value: function(e) {
            if (!e || e <= 0) return this.page.setData({
                levelTheme: ""
            }), void getApp().setNavigationBar();
            var t = h.getThemeScheme(e, this.theme);
            this.page.setData({
                levelTheme: t
            }), getApp().setNavigationBar(C.config.app_title, t);
        }
    }, {
        key: "getCompetition",
        value: function() {
            return this.competition;
        }
    }, {
        key: "isGameEnded",
        value: function() {
            return 2 === this.state || this.isForceEnd;
        }
    }, {
        key: "getRoundTimeout",
        value: function() {
            return this.isPartyMode ? _.getRoundTimeout() : void 0;
        }
    }, {
        key: "reset",
        value: function() {
            this.presentedWords = [], this.previousRounds = [], this.challengeWords = [], this.competition = void 0, 
            this.currentRound = void 0, this.unsavedRoundStartIdx = 0, this.roundCount = 0, 
            this.newGuessesCounter = 0, this.clock.reset(this.getRoundTimeout()), this.finalEndGamePromise = void 0, 
            this.state = 0, this.startNextRoundTimeout && clearTimeout(this.startNextRoundTimeout), 
            this.transTimeOut && clearTimeout(this.transTimeOut), this.clearCanvas(), this.recognitionController.stop();
        }
    }, {
        key: "finishCurrentRound",
        value: function(e) {
            this.drawingCanvas.ignoreInput(), this.currentRound.drawing = y.default.encode(this.drawingCanvas.getSegments()), 
            this.currentRound.width = this.drawingCanvas.getWidth(), this.currentRound.height = this.drawingCanvas.getHeight(), 
            this.currentRound.recognized = !!e.recognition, this.currentRound.recognitionId = e.recognition ? e.recognition.id : 0, 
            this.currentRound.score = e.recognition ? parseFloat(e.recognition.score) : 999, 
            this.currentRound.duration = Math.round(10 * this.clock.getTimeElapsed()) / 10, 
            this.previousRounds.push(this.currentRound);
        }
    }, {
        key: "showCongratCard",
        value: function(e) {
            this.page.setData({
                animClass: ""
            }), this.machineView.hide(), this.cardsView.showNewRoundBreakCard(this.newCongratLevel, this.localPassedWords.length, e), 
            this.newCongratLevel = null;
        }
    }, {
        key: "shouldEndGame",
        value: function() {
            return this.roundCount > this.challengeWords.length || this.theme && !this.themeCompleted && E.getThemeCompletedGivenList(this.theme, this.localPassedWords);
        }
    }, {
        key: "startNextRound",
        value: function() {
            var e = this;
            if (!this.unloaded && !this.isForceEnd) {
                this.roundCount++, this.updateLogContext(r.getContext());
                var t = this.challengeWords[this.roundCount - 1];
                R.SpeechController.clearQueue();
                var n = E.getWord(t);
                if (n && R.SpeechController.preload(E.getTTSUrl(n)), this.shouldEndGame()) return this.theme && (this.themeCompleted = !0), 
                this.finalEndGamePromise = this.endGame(), void this.cardsView.showFinalCongratCard({
                    theme: this.theme,
                    wordCount: this.challengeWords.length
                });
                this.currentRound = new m.GameRound(t, this.roundCount), this.presentedWords.push(this.currentRound.word), 
                this.cardsView.hideTutorialCard(), this.page.setData({
                    word: this.currentRound.wordZhCn,
                    level: "第 " + this.roundCount + " 题",
                    animClass: "center-text"
                });
                var i = function() {
                    e.page.setData({
                        animClass: "on-screen"
                    }), e.clock.startClock(), e.machineView.show(), e.drawingCanvas.acceptInput();
                };
                if (this.isPartyMode) this.startNextRoundTimeout = setTimeout(i, 2e3); else {
                    var s = h.getThemeScheme(this.roundCount - 1, this.theme), o = h.getThemeScheme(this.roundCount, this.theme);
                    s !== o ? (this.page.setData({
                        targetTheme: o,
                        transitioning: "transitioning"
                    }), this.transTimeOut = setTimeout(function() {
                        e.setLevelTheme(e.roundCount), e.page.setData({
                            transitioning: ""
                        }), e.startNextRoundTimeout = setTimeout(i, 900);
                    }, 1100)) : this.startNextRoundTimeout = setTimeout(i, 2e3);
                }
                this.isPartyMode && (_.submitScore(this.roundCount - 1), this.cardsView.setData("total_pass", this.roundCount - 1)), 
                this.drawingCanvas.clear(), this.drawingCanvas.show(), this.machineView.reset(), 
                this.machineView.hide(), this.recognitionController.start(), this.clock.reset(this.getRoundTimeout());
            }
        }
    }, {
        key: "pauseGame",
        value: function() {
            this.clock.pauseClock();
        }
    }, {
        key: "resumeGame",
        value: function() {
            this.clock.startClock();
        }
    }, {
        key: "hideGame",
        value: function() {
            this.recognitionController.stop(), this.machineView.stop();
        }
    }, {
        key: "showGame",
        value: function() {
            this.recognitionController.start();
        }
    }, {
        key: "roundRecognized",
        value: function(e) {
            var t = this;
            g.default.play("correct"), this.recognitionController.stop(), this.pauseGame();
            var n = this.updateLocalPassedWords();
            this.machineView.setResultWord(e).then(function() {
                t.unloaded || (t.finishCurrentRound({
                    recognition: e
                }), n ? t.submitRounds().then(function() {
                    t.unsavedRoundStartIdx = t.previousRounds.length, t.isPartyMode ? t.startNextRound() : t.showCongratCard(h.getThemeScheme(t.roundCount, t.theme)), 
                    l.default.getLatestPlayHistory().attributes.passedWords = t.localPassedWords.slice();
                }).catch(function(e) {
                    console.log("Submit rounds got error: ", e), t.newCongratLevel = null, l.default.fetch().then(function() {
                        t.localPassedWords = t.getLocalPassedWordsCopy(l.default.getLatestPlayHistory()), 
                        t.startNextRound();
                    }).catch(function(e) {
                        t.startNextRound();
                    });
                }) : t.startNextRound());
            });
        }
    }, {
        key: "updateLocalPassedWords",
        value: function() {
            var e = this.localPassedWords.indexOf(this.currentRound.word) < 0;
            if (this.currentRound.isNewCollection = e, e) {
                var t = h.getLevel(this.localPassedWords.length);
                this.localPassedWords.push(this.currentRound.word);
                var n = h.getLevel(this.localPassedWords.length);
                if (n > t) return this.newCongratLevel = n, !0;
            }
            return !1;
        }
    }, {
        key: "pickRandom",
        value: function(e) {
            return e[G.random(e.length - 1)];
        }
    }, {
        key: "saveResults",
        value: function(e) {
            var t = this, n = setTimeout(function() {
                wx.showLoading({
                    title: "保存结果中"
                });
            }, e), i = [ this.cardsView.showGameOverCard({
                wordZhCn: this.currentRound.wordZhCn,
                theme: h.getThemeScheme(this.isPartyMode ? 0 : this.roundCount, this.theme)
            }), this.endGame() ];
            this.isPartyMode && i.push(_.getResult()), Promise.all(i).then(function(e) {
                clearTimeout(n), wx.hideLoading(), t.isPartyMode && t.updatePartyModeResult(e[2]), 
                t.showEndGameCard(e[1]);
            }).catch(function(e) {
                clearTimeout(n), wx.hideLoading(), console.log("End game error", e), r.logEvent("endgame_fail", r.getContext().data()), 
                t.cardsView.showRetrySaveCard(), l.default.fetch().catch(function(e) {
                    console.log("Cannot refetch PlayHistory", e);
                });
            });
        }
    }, {
        key: "roundTimesUp",
        value: function() {
            this.recognitionController.stop(), this.pauseGame(), this.finishCurrentRound({
                recognition: !1
            }), this.saveResults(1e3);
        }
    }, {
        key: "roundTimesElapsedPercent",
        value: function(e) {
            this.page.setData({
                timeElapsedPercent: e
            });
        }
    }, {
        key: "endGame",
        value: function() {
            var e = this;
            return this.isPartyMode && (_.reportEnd(), _.setEventListener(null)), this.state = 2, 
            new Promise(function(t, n) {
                e.competition || n("Missing competition!"), e.recognitionController.stop(), e.machineView.reset(), 
                e.drawingCanvas.hide();
                var i = l.default.getLatestPlayHistory();
                u.sendEndlessCompetitionResult(e.competition, e.previousRounds, e.unsavedRoundStartIdx, l.default.getLatestPlayHistory().id, e.user).then(function(e) {
                    return l.default.fetch();
                }).then(function(e) {
                    var n = i.attributes.endlessBestCount, s = i.attributes.endlessBestTime;
                    e.betterThan(i) && (n = e.attributes.endlessBestCount, s = e.attributes.endlessBestTime), 
                    c.default.uploadStatistics(n, s, e.attributes.passedWords.length), t({
                        playHistory: e,
                        isNewRecord: !i || e.betterThan(i)
                    });
                }).catch(n);
            });
        }
    }, {
        key: "showEndGameCard",
        value: function(e) {
            l.default.setLatestPlayHistory(e.playHistory), this.prepareGame();
            var t = void 0;
            t = this.theme ? e.playHistory.getThemeProgress(this.theme) : e.playHistory.getLevelUpProgress();
            var n = G.filter(this.previousRounds, function(e) {
                return 1 == e.recognized;
            }).length;
            this.cardsView.showEndlessEndCard(e.isNewRecord, n, this.previousRounds, this.user, this.competition.id, e.playHistory.getLevelStr(), t, h.getThemeScheme(this.isPartyMode ? 0 : this.roundCount, this.theme)), 
            r.logEvent("end_game", r.getContext().data());
        }
    }, {
        key: "submitRounds",
        value: function() {
            var e = Object.assign({}, l.default.getLatestPlayHistory());
            return e.attributes.passedWords = this.localPassedWords.slice(), u.submitRounds(e, this.competition, this.previousRounds.slice(this.unsavedRoundStartIdx), this.user);
        }
    }, {
        key: "showModalToHome",
        value: function(e, t) {
            r.getCurrentPage() && r.getCurrentPage().includes("pages/home/home") || wx.showModal({
                title: e,
                content: t,
                showCancel: !1,
                confirmText: "返回首页",
                complete: function() {
                    getApp().redirectToHome();
                }
            });
        }
    }, {
        key: "onNewRecognitions",
        value: function(e) {
            var t = this;
            if (this.recognitionController.isRecognizing) {
                var n = G.find(e, function(e) {
                    if (e.recognized) return !0;
                    var n = C.config.handwriting_recognition_threshold, i = t.challengeWords[t.roundCount - 1], s = E.getWord(i);
                    return s && s.batchName && "DEFAULT_BATCH" !== s.batchName && (n = C.config.handwriting_recognition_new_word_threshold), 
                    (e.word == t.currentRound.word || G.contains(t.currentRound.synonyms, e.word)) && e.score < n;
                });
                if (this.currentRound && n) this.roundRecognized(n); else if (this.currentRound) {
                    e = G.filter(e, function(e) {
                        return e.word != t.currentRound.word && null != e.translation;
                    });
                    var i = G.pluck(e, "translation");
                    i = G.filter(i, function(e) {
                        return e.Translations.ZhCn != t.currentRound.wordZhCn;
                    }), 0 == this.machineView.setGuesses(i) ? this.newGuessesCounter++ : this.newGuessesCounter = 0, 
                    this.newGuessesCounter > 2 && (this.newGuessesCounter = 0, this.machineView.speakAndWrite(this.pickRandom(C.config.noNewGuessesSentences)));
                }
            }
        }
    }, {
        key: "onDrawingUpdated",
        value: function(e) {
            this.recognitionController.onDrawingUpdated(this.roundCount - 1, e), this.drawingUntouched && (this.drawingUntouched = !1, 
            this.machineView.setText("..."));
        }
    }, {
        key: "createSharePhoto",
        value: function(e) {
            var t = {
                cId: this.competition.id,
                userId: this.user.id,
                levelStr: l.default.getLatestPlayHistory().getLevelStr()
            };
            this.isPartyMode && (t = {
                theme: "gdd",
                cId: this.competition.id,
                userId: this.user.id,
                ranking: this.cardsView.data.rank,
                totalPlayerCount: this.cardsView.data.total_players - 1,
                roundCount: this.cardsView.data.total_pass
            }), P.default.generateShareResult(t, e);
        }
    }, {
        key: "createThemeSharePhoto",
        value: function(e) {
            var t = {
                cId: this.competition.id,
                userId: this.user.id,
                levelStr: l.default.getLatestPlayHistory().getLevelStr(),
                theme: this.theme
            };
            P.default.generateThemeShareResult(t, e);
        }
    }, {
        key: "showFeedBack",
        value: function() {
            this.clock.started ? (this.clock.pauseClock(), this.wasInGameForFeedBack = !0, this.drawingCanvas.hide()) : this.wasInGameForFeedBack = !1, 
            this.feedBackView.showFeedBackCard();
        }
    }, {
        key: "dismissFeedBack",
        value: function() {
            console.log("in dismissFeedBack, wasInGameForFeedBack" + this.wasInGameForFeedBack), 
            this.wasInGameForFeedBack && (this.clock.startClock(), this.wasInGameForFeedBack = !1, 
            this.drawingCanvas.show());
        }
    }, {
        key: "partyEndConfirm",
        value: function() {
            this.partyGameResult && this.showEndGameCard(this.partyGameResult);
        }
    }, {
        key: "updatePartyModeResult",
        value: function(e) {
            e && e.rank && e.total_players && (this.cardsView.setData("rank", e.rank), this.cardsView.setData("total_players", e.total_players), 
            this.cardsView.setData("total_pass", e.score));
        }
    }, {
        key: "retryForceEnd",
        value: function() {
            var e = this;
            Promise.all([ this.endGame(), _.getResult() ]).then(function(t) {
                e.updateResultData(t), e.showEndGameCard(e.partyGameResult);
            }).catch(function(t) {
                e.cardsView.showRetrySaveCard();
            });
        }
    }, {
        key: "updateResultData",
        value: function(e) {
            if (this.partyGameResult = e[0], this.updatePartyModeResult(e[1]), e[1] && e[1].score) {
                var t = parseInt(e[1].score);
                this.partyGameResult.length > t && this.partyGameResult.splice(t, this.partyGameResult.length - t);
            }
        }
    }, {
        key: "forceEnd",
        value: function() {
            var e = this;
            this.isForceEnd || (this.isForceEnd = !0, this.startNextRoundTimeout && clearTimeout(this.startNextRoundTimeout), 
            this.transTimeOut && clearTimeout(this.transTimeOut), 2 != this.state && (this.recognitionController.stop(), 
            this.clock.pauseClock(), this.drawingCanvas.ignoreInput(), this.cardsView.showPartyGameEndPage({
                wordZhCn: this.currentRound.wordZhCn,
                theme: h.getThemeScheme(0, this.theme)
            }), Promise.all([ this.endGame(), _.getResult() ]).then(function(t) {
                wx.hideLoading(), e.updateResultData(t);
            }).catch(function(t) {
                e.cardsView.showRetrySaveCard();
            })));
        }
    } ]), t;
}();