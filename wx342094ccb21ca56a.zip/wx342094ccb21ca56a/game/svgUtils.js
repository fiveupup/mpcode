function e(e, n) {
    if (!(e instanceof n)) throw new TypeError("Cannot call a class as a function");
}

Object.defineProperty(exports, "__esModule", {
    value: !0
});

var n = function() {
    function e(e, n) {
        for (var r = 0; r < n.length; r++) {
            var t = n[r];
            t.enumerable = t.enumerable || !1, t.configurable = !0, "value" in t && (t.writable = !0), 
            Object.defineProperty(e, t.key, t);
        }
    }
    return function(n, r, t) {
        return r && e(n.prototype, r), t && e(n, t), n;
    };
}(), r = require("../libs/min-base64"), t = require("../libs/underscore/underscore.modified"), o = function() {
    function o() {
        e(this, o);
    }
    return n(o, null, [ {
        key: "createSvg",
        value: function(e, n) {
            return '<svg xmlns="http://www.w3.org/2000/svg" width="' + e + '" height="' + n + '" class="svg-margin-10">';
        }
    }, {
        key: "createLinePath",
        value: function(e) {
            var n = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : [ 0, 0 ], r = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : 1, t = arguments.length > 3 && void 0 !== arguments[3] ? arguments[3] : 2, o = arguments.length > 4 && void 0 !== arguments[4] ? arguments[4] : "#000000";
            if (0 != e.length && 0 != e[0].length) {
                for (var a = function(e, t) {
                    return (e - n[t]) * r;
                }, i = "M" + a(e[0][0], 0) + " " + a(e[1][0], 1), u = 1; u < e[0].length; u++) i += " L" + a(e[0][u], 0) + " " + a(e[1][u], 1);
                return '<path d="' + i + '" stroke="' + o + '" stroke-width="' + t + '" stroke-linecap="round" fill="none"></path>';
            }
        }
    }, {
        key: "calculateBoundingBox",
        value: function(e) {
            for (var n = -1, r = -1, t = -1, o = -1, a = 0; a < e.length; a++) for (var i = 0; i < e[a][0].length; i++) (-1 == n || n > e[a][0][i]) && (n = e[a][0][i]), 
            (-1 == r || r < e[a][0][i]) && (r = e[a][0][i]), (-1 == t || t > e[a][1][i]) && (t = e[a][1][i]), 
            (-1 == o || o < e[a][1][i]) && (o = e[a][1][i]);
            return {
                x: n - 5,
                y: t - 5,
                w: r - n + 10,
                h: o - t + 10
            };
        }
    }, {
        key: "createSvgBase64FromSegments",
        value: function(e, n, t) {
            var a = arguments.length > 3 && void 0 !== arguments[3] ? arguments[3] : {}, i = o.createSvgFromSegments(e, n, t, a);
            return "data:image/svg+xml;base64," + r.Base64.encode(i);
        }
    }, {
        key: "createSvgFromSegments",
        value: function(e, n, r) {
            var a = arguments.length > 3 && void 0 !== arguments[3] ? arguments[3] : {}, i = [];
            if (1 == (a = t.defaults(a, {
                padding: 0,
                order: 0,
                color: "#000000"
            })).order) for (var u = 0; u < e.length; u++) {
                for (var l = [ [], [] ], g = 0; g < e[u].length; g++) l[0].push(e[u][g][0]), l[1].push(e[u][g][1]);
                i.push(l);
            } else e && (i = e);
            n -= 2 * a.padding, r -= 2 * a.padding;
            var d = 2 * n / 140, v = o.createSvg(n, r), h = a.customizedBounding ? a.customizedBounding : o.calculateBoundingBox(i), c = n / r, s = [ h.x, h.y ], f = void 0;
            h.w / h.h > c ? (f = n / h.w, s[1] -= .5 * (r / f - h.h)) : (f = r / h.h, s[0] -= .5 * (n / f - h.w));
            for (var m = 0; m < i.length; m++) v += o.createLinePath(i[m], s, f, d, a.color);
            return v += "</svg>";
        }
    }, {
        key: "createLinePathCommand",
        value: function(e) {
            var n = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : [ 0, 0 ], r = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : 1;
            arguments.length > 3 && void 0 !== arguments[3] && arguments[3], arguments.length > 4 && void 0 !== arguments[4] && arguments[4];
            if (0 != e.length && 0 != e[0].length) {
                var t = function(e, t) {
                    return (e - n[t]) * r;
                }, o = [];
                o.push({
                    marker: "M",
                    values: [ t(e[0][0], 0), t(e[1][0], 1) ]
                });
                for (var a = 1; a < e[0].length; a++) o.push({
                    marker: "L",
                    values: [ t(e[0][0], 0), t(e[1][0], 1) ]
                });
                return o;
            }
        }
    }, {
        key: "createCommandsFromSegments",
        value: function(e, n, r) {
            var a = arguments.length > 3 && void 0 !== arguments[3] ? arguments[3] : {}, i = [];
            if (1 == (a = t.defaults(a, {
                padding: 0,
                order: 0,
                color: "#000000"
            })).order) for (var u = 0; u < e.length; u++) {
                for (var l = [ [], [] ], g = 0; g < e[u].length; g++) l[0].push(e[u][g][0]), l[1].push(e[u][g][1]);
                i.push(l);
            } else e && (i = e);
            n -= 2 * a.padding, r -= 2 * a.padding;
            var d = 2 * n / 140, v = o.calculateBoundingBox(i), h = n / r, c = [ v.x, v.y ], s = void 0;
            v.w / v.h > h ? (s = n / v.w, c[1] -= .5 * (r / s - v.h)) : (s = r / v.h, c[0] -= .5 * (n / s - v.w));
            for (var f = [], m = 0; m < i.length; m++) f = f.concat(o.createLinePathCommand(i[m], c, s, d, a.color));
            return f;
        }
    } ]), o;
}();

exports.default = o;