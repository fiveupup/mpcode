function e(e, a) {
    if (!(e instanceof a)) throw new TypeError("Cannot call a class as a function");
}

Object.defineProperty(exports, "__esModule", {
    value: !0
});

var a = function() {
    function e(e, a) {
        for (var r = 0; r < a.length; r++) {
            var n = a[r];
            n.enumerable = n.enumerable || !1, n.configurable = !0, "value" in n && (n.writable = !0), 
            Object.defineProperty(e, n.key, n);
        }
    }
    return function(a, r, n) {
        return r && e(a.prototype, r), n && e(a, n), a;
    };
}(), r = {
    qixi: {
        nameZhCn: "七夕",
        themeScheme: "qixi",
        navBarFrontColor: "#000000",
        navBarBgColor: "#FEF7FB",
        congratNavBarFrontColor: "#000000",
        congratNavBarBgColor: "#FEF7FB",
        hasShareImage: !0,
        hasShareTemplate: !0
    },
    kfc: {
        nameZhCn: "肯德基",
        themeScheme: "kfc",
        navBarFrontColor: "#000000",
        navBarBgColor: "#FFF9EF",
        congratNavBarFrontColor: "#000000",
        congratNavBarBgColor: "#FFF9EF",
        hasShareImage: !0,
        hasShareTemplate: !0
    },
    shanghai: {
        nameZhCn: "上海",
        themeScheme: "underwater",
        navBarFrontColor: "#000000",
        navBarBgColor: "#FFFFFF",
        congratNavBarFrontColor: "#ffffff",
        congratNavBarBgColor: "#185ABC",
        hideThemeShareButtons: !0,
        hasShareImage: !1,
        hasShareTemplate: !1
    },
    china: {
        nameZhCn: "中国"
    }
}, n = function() {
    function n() {
        e(this, n);
    }
    return a(n, null, [ {
        key: "getThemeZhCnTitle",
        value: function(e) {
            if (n.isValidTheme(e)) return r[e].nameZhCn;
        }
    }, {
        key: "getThemeConfig",
        value: function(e) {
            return r[e];
        }
    }, {
        key: "isValidTheme",
        value: function(e) {
            return void 0 !== r[e];
        }
    }, {
        key: "hasShareTemplate",
        value: function(e) {
            return n.isValidTheme(e) && r[e].hasShareTemplate;
        }
    }, {
        key: "hasShareImage",
        value: function(e) {
            return n.isValidTheme(e) && r[e].hasShareImage;
        }
    }, {
        key: "showShareButtons",
        value: function(e) {
            return n.isValidTheme(e) && !r[e].hideThemeShareButtons;
        }
    } ]), n;
}();

exports.default = n;