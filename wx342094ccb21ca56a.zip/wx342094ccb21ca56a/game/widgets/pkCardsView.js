function e(e) {
    if (e && e.__esModule) return e;
    var t = {};
    if (null != e) for (var a in e) Object.prototype.hasOwnProperty.call(e, a) && (t[a] = e[a]);
    return t.default = e, t;
}

function t(e) {
    return e && e.__esModule ? e : {
        default: e
    };
}

function a(e, t) {
    if (!(e instanceof t)) throw new TypeError("Cannot call a class as a function");
}

function n(e, t) {
    if (!e) throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
    return !t || "object" != typeof t && "function" != typeof t ? e : t;
}

function o(e, t) {
    if ("function" != typeof t && null !== t) throw new TypeError("Super expression must either be null or a function, not " + typeof t);
    e.prototype = Object.create(t && t.prototype, {
        constructor: {
            value: e,
            enumerable: !1,
            writable: !0,
            configurable: !0
        }
    }), t && (Object.setPrototypeOf ? Object.setPrototypeOf(e, t) : e.__proto__ = t);
}

Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.PkCardsView = void 0;

var i = function() {
    function e(e, t) {
        for (var a = 0; a < t.length; a++) {
            var n = t[a];
            n.enumerable = n.enumerable || !1, n.configurable = !0, "value" in n && (n.writable = !0), 
            Object.defineProperty(e, n.key, n);
        }
    }
    return function(t, a, n) {
        return a && e(t.prototype, a), n && e(t, n), t;
    };
}(), r = t(require("../events.js")), s = t(require("../../common/soundFXController.js")), l = t(require("../pkResultUtil.js")), u = e(require("../eventlog.js")), d = e(require("../api/gameAPI.js")), c = t(require("../api/generateShareResultAPI.js")), h = require("../../libs/underscore/underscore.modified");

exports.PkCardsView = function(e) {
    function t(e) {
        a(this, t);
        var o = n(this, (t.__proto__ || Object.getPrototypeOf(t)).call(this));
        return o.page = e, o.data = {}, o.page.saveToAlbum = o.saveToAlbum.bind(o), o.page.dismissSavedPhoto = o.dismissSavedPhoto.bind(o), 
        o.page.showRoundDetail = o.showRoundDetail.bind(o), o.page.playClickSound = o.playClickSound.bind(o), 
        o.page.catchTap = o.catchTap.bind(o), o.pkData = getApp().getLastPkData(), o.page.userChallengeId = o.pkData.userChallengeId, 
        o.endChallenge(o.pkData), o;
    }
    return o(t, r.default), i(t, [ {
        key: "updateUserInfo",
        value: function(e, t) {
            console.log("updateUserInfo", e, t);
        }
    }, {
        key: "onPlayerJoined",
        value: function(e) {
            console.log("playerJoined", e);
        }
    }, {
        key: "startChallenge",
        value: function(e) {
            console.log("startChallenge", e);
        }
    }, {
        key: "setData",
        value: function(e, t) {
            this.data[e] = t, this.page.setData({
                pkCardsViewData: this.data
            });
        }
    }, {
        key: "setBatchData",
        value: function(e) {
            var t = this;
            h.keys(e).forEach(function(a) {
                return t.data[a] = e[a];
            }), this.page.setData({
                pkCardsViewData: this.data
            });
        }
    }, {
        key: "endChallenge",
        value: function(e) {
            var t = this;
            wx.showLoading({
                title: "载入结果中"
            }), d.fetchChallengeDataFromLeanCloud(e.userChallengeId).then(function(a) {
                wx.hideLoading(), t.myUserId = a.get("user").id, t.myAvatarUrl = a.get("user").get("avatarUrl"), 
                t.myNickName = a.get("user").get("nickName"), t.challengeId = a.get("challenge").id, 
                t.renderData = a.formatChallengeResult(e.usersInfo), t.setBatchData(t.renderData), 
                t.page.totalUser = t.renderData.userRankList.length, t.page.myRank = t.renderData.myRank, 
                t.page.myNumRecognized = t.renderData.myNumRecognized, t.showPkEndCard();
                var n = u.getContext();
                n.player_count = t.renderData.userRankList.length, n.rank = t.renderData.myRank, 
                n.num_recognized = t.renderData.myNumRecognized;
            }).catch(function(e) {
                wx.hideLoading(), console.log("PK endchallenge error", e), u.logEvent("pk_endchallenge_fail", u.getContext().data()), 
                t.showPkEndCard();
            });
        }
    }, {
        key: "hideCard",
        value: function(e, t) {
            e.isVisible = !1, e.hasClass("visible") && (e.on("transitionend webkitTransitionEnd oTransitionEnd MSTransitionEnd", function() {
                e.hide(), e.off("transitionend webkitTransitionEnd oTransitionEnd MSTransitionEnd"), 
                t && t();
            }), e.removeClass("visible"));
        }
    }, {
        key: "playClickSound",
        value: function() {
            s.default.play("button-click");
        }
    }, {
        key: "showPkEndCard",
        value: function(e) {
            this.page.backToHome = this.backToHome.bind(this), this.setData("endCardClass", "visible");
        }
    }, {
        key: "backToHome",
        value: function(e) {
            this.emit("BACK_TO_HOME");
        }
    }, {
        key: "saveToAlbum",
        value: function() {
            var e = this;
            c.default.checkSaveImagePermission(function() {
                u.logEvent("long_image", u.getContext().data()), e.createSharePhoto(function(t) {
                    e.showSavedPhotoDialog(t);
                });
            });
        }
    }, {
        key: "createSharePhoto",
        value: function(e) {
            var t = {
                challengeId: this.challengeId,
                userChallengeId: this.page.userChallengeId,
                userId: this.myUserId,
                ranking: this.page.myRank
            };
            return c.default.generatePkShareResult(t, e);
        }
    }, {
        key: "showSavedPhotoDialog",
        value: function(e) {
            s.default.play("button-click"), this.data.savedPhotoDialogClass = "visible", this.data.savedPhotoImageSrc = e, 
            this.page.setData({
                pkCardsViewData: this.data
            });
        }
    }, {
        key: "dismissSavedPhoto",
        value: function() {
            this.setData("savedPhotoDialogClass", "");
        }
    }, {
        key: "catchTap",
        value: function() {}
    }, {
        key: "showRoundDetail",
        value: function(e) {
            var t = this.data.rounds[e.currentTarget.dataset.idx];
            this.pkData.roundDetail = Object.assign({
                myUserId: this.myUserId,
                myAvatarUrl: this.myAvatarUrl,
                myNickName: this.myNickName,
                totalUser: this.renderData.userRankList.length
            }, l.default.getRoundDetail(t, this.myUserId)), this.pkData.roundDetail.roundId = e.currentTarget.dataset.idx, 
            this.pkData.roundDetail.challengeId = this.challengeId, getApp().setLastPkData(this.pkData), 
            wx.navigateTo({
                url: "/pages/pkRoundDetail/pkRoundDetail"
            });
        }
    } ]), t;
}();