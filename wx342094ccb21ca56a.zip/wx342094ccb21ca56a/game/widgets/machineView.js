function e(e, t) {
    if (!(e instanceof t)) throw new TypeError("Cannot call a class as a function");
}

Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.MachineView = void 0;

var t = function() {
    function e(e, t) {
        for (var s = 0; s < t.length; s++) {
            var i = t[s];
            i.enumerable = i.enumerable || !1, i.configurable = !0, "value" in i && (i.writable = !0), 
            Object.defineProperty(e, i.key, i);
        }
    }
    return function(t, s, i) {
        return s && e(t.prototype, s), i && e(t, i), t;
    };
}(), s = require("../controllers/speechController.js"), i = function(e) {
    if (e && e.__esModule) return e;
    var t = {};
    if (null != e) for (var s in e) Object.prototype.hasOwnProperty.call(e, s) && (t[s] = e[s]);
    return t.default = e, t;
}(require("../utils.js")), n = require("../config.js"), a = require("../../libs/underscore/underscore.modified");

exports.MachineView = function() {
    function r(t) {
        var s = this;
        e(this, r), this.page = t, this.data = {}, this.resetTextAfterDelay = a.debounce(function() {
            return s.setText("...");
        }, 2e3), this.reset(), this.audioSources = {
            "猜出来了！这是": "/assets/audio/zhcn_cai_chu_lai_le_zhe_shi_1.8.mp3",
            "我知道了！这是": "/assets/audio/zhcn_i_know_this_is.mp3",
            "你不画让我怎么猜": "/assets/audio/zhcn_ni_bu_hua_rang_wo_zen_me_cai_1.8.mp3",
            "你画的啥玩意儿": "/assets/audio/zhcn_ni_hua_de_sha_wan_yi_er_1.8.mp3",
            "我猜这是": "/assets/audio/zhcn_wo_cai_zhe_shi_1.8.mp3",
            "我真的猜不出来": "/assets/audio/zhcn_wo_zhen_de_cai_bu_chu_lai_1.8.mp3",
            "再加把劲": "/assets/audio/zhcn_zai_jia_ba_jin_1.8.mp3",
            "抓紧时间画画呀！": "/assets/audio/zhcn_draw_quick.mp3",
            "你开始画我才能猜啊...": "/assets/audio/zhcn_you_draw_i_guess.mp3",
            "我真的看不懂": "/assets/audio/zhcn_i_dont_get_it.mp3",
            "我就快猜出来了": "/assets/audio/zhcn_nearly_get_it.mp3"
        };
    }
    return t(r, [ {
        key: "setData",
        value: function(e, t) {
            this.data[e] = t, this.page.setData({
                machineViewData: this.data
            });
        }
    }, {
        key: "reset",
        value: function() {
            this.setText("..."), this.clearGuessesQueue(), this.mentionedWords = {}, this.talkingGuesses = !1, 
            this.recentMentionedWords = [];
        }
    }, {
        key: "hide",
        value: function() {
            this.setData("machineViewClass", "");
        }
    }, {
        key: "show",
        value: function() {
            this.setData("machineViewClass", "visible");
        }
    }, {
        key: "stop",
        value: function() {
            this.clearAllSpeaking(), this.talkingGuesses = !1;
        }
    }, {
        key: "setText",
        value: function(e) {
            var t = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : "";
            this.data.txtA = e, this.data.txtB = t, this.page.setData({
                machineViewData: this.data
            }), this.resetTextAfterDelay();
        }
    }, {
        key: "speak",
        value: function(e, t) {
            var i = this;
            this.talking = !0, this.nowSpeaking = new s.SpeechController(e), this.nowSpeaking.speak(function() {
                i.nowSpeaking = void 0, i.talking = !1, t && t();
            });
        }
    }, {
        key: "speakAndWrite",
        value: function(e) {
            var t = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : void 0;
            this.setText(e), this.speak(this.getLocalSpeechUrlForText(e), t);
        }
    }, {
        key: "readNextGuess",
        value: function(e) {
            var t = this;
            if (this.talkingGuesses = !0, 0 != this.guessesQueue.length) {
                if (e) {
                    this.recentMentionedWords = [];
                    return this.setText("", "我猜这是"), void this.speak(this.getLocalSpeechUrlForText("我猜这是"), function() {
                        t.readNextGuess(!1);
                    });
                }
                var i = this.guessesQueue.shift(), n = i.Translations.ZhCn, a = "我猜这是" + this.recentMentionedWords.join(", ");
                this.recentMentionedWords.length > 0 && (a += ", "), this.setText(n, a), this.wordSpeaking = new s.SpeechController(i.AudioUrls.ZhCn).speak(function() {
                    var e = a.length > 30;
                    t.readNextGuess(e);
                }), this.recentMentionedWords.push(n), this.mentionedWords[i.Word] = 1;
            } else this.talkingGuesses = !1;
        }
    }, {
        key: "setResultWord",
        value: function(e) {
            var t = this;
            return new Promise(function(a, r) {
                var o = i.pickRandom(n.config.successSentences);
                t.setGuesses([]);
                var u = new s.SpeechController(e.translation.AudioUrls.ZhCn);
                t.setText(o + e.translation.Translations.ZhCn), setTimeout(function() {
                    t.speak(t.getLocalSpeechUrlForText(o), function() {
                        setTimeout(a, 600, "fast-return"), u.speak(a);
                    });
                }, 300);
            });
        }
    }, {
        key: "setGuesses",
        value: function(e) {
            var t = this;
            this.clearGuessesQueue(), this.guessesQueue = a.filter(e, function(e) {
                return !a.has(t.mentionedWords, e.Word);
            });
            var i = this.guessesQueue.length;
            if (i > 0) {
                s.SpeechController.clearQueue();
                var n = !0, r = !1, o = void 0;
                try {
                    for (var u, h = this.guessesQueue[Symbol.iterator](); !(n = (u = h.next()).done); n = !0) {
                        var l = u.value;
                        s.SpeechController.preload(l.AudioUrls.ZhCn);
                    }
                } catch (e) {
                    r = !0, o = e;
                } finally {
                    try {
                        !n && h.return && h.return();
                    } finally {
                        if (r) throw o;
                    }
                }
            }
            return !this.talkingGuesses && this.guessesQueue.length > 0 && this.readNextGuess(!0), 
            i;
        }
    }, {
        key: "clearGuessesQueue",
        value: function() {
            this.guessesQueue = [], this.clearAllSpeaking();
        }
    }, {
        key: "clearAllSpeaking",
        value: function() {
            this.wordSpeaking && (this.wordSpeaking.destroy(), this.wordSpeaking = null), this.nowSpeaking && (this.nowSpeaking.destroy(), 
            this.nowSpeaking = null);
        }
    }, {
        key: "getLocalSpeechUrlForText",
        value: function(e) {
            return this.audioSources[e];
        }
    } ]), r;
}();