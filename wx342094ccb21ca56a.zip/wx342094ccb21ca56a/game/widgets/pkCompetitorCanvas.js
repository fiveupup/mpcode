function t(t, e, i) {
    return e in t ? Object.defineProperty(t, e, {
        value: i,
        enumerable: !0,
        configurable: !0,
        writable: !0
    }) : t[e] = i, t;
}

function e(t, e) {
    if (!(t instanceof e)) throw new TypeError("Cannot call a class as a function");
}

Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.PkCompetitorCanvas = void 0;

var i = function() {
    function t(t, e) {
        for (var i = 0; i < e.length; i++) {
            var n = e[i];
            n.enumerable = n.enumerable || !1, n.configurable = !0, "value" in n && (n.writable = !0), 
            Object.defineProperty(t, n.key, n);
        }
    }
    return function(e, i, n) {
        return i && t(e.prototype, i), n && t(e, n), e;
    };
}(), n = require("../../common/incrementalDrawing"), o = require("../../libs/underscore/underscore.modified");

exports.PkCompetitorCanvas = function() {
    function r(i, n, o) {
        var a;
        e(this, r), this.canvasId = i, this.page = n, this.width = o.width, this.height = o.height, 
        this.page.setData((a = {}, t(a, i + "Width", this.width), t(a, i + "Height", this.height), 
        a)), this.margin = o.margin || 0, this.competitorCount = o.competitorCount, this.competitorWidth = this.width / this.competitorCount, 
        this.lineColor = "black", this.lineWidth = 1, this.context = wx.createCanvasContext(i), 
        this.context.setStrokeStyle(this.lineColor), this.context.setLineWidth(this.lineWidth), 
        this.keyToOrdinal = {}, this.lastPos = new Array(this.competitorCount);
    }
    return i(r, [ {
        key: "registerCompetitorKey",
        value: function(t, e) {
            this.keyToOrdinal[t] = e;
        }
    }, {
        key: "getCompetitorRect",
        value: function(t) {
            if (t < this.competitorCount) return {
                left: Math.round(t * this.competitorWidth),
                top: 0,
                height: Math.round(this.height),
                width: Math.round(this.competitorWidth)
            };
        }
    }, {
        key: "getCompetitorDrawableRect",
        value: function(t) {
            if (t < this.competitorCount) {
                var e = this.getCompetitorRect(t);
                return {
                    left: Math.round(e.left + this.margin),
                    top: Math.round(e.top + this.margin),
                    height: Math.round(e.height - 2 * this.margin),
                    width: Math.round(e.width - 2 * this.margin)
                };
            }
        }
    }, {
        key: "updateDrawing",
        value: function(t, e, i, r) {
            var a = this, s = this.keyToOrdinal[t];
            void 0 === s || s >= this.competitorCount || (this.setTransform(s, e, i), o.forEach(r, function(t) {
                if (t.event === n.IncrementalDrawingEvent.TOUCH_START) a.moveTo(s, t.data[0], t.data[1]); else if (t.event === n.IncrementalDrawingEvent.TOUCH_MOVE) {
                    if (!t.data || 0 === t.data.length) return;
                    a.lastPos[s] ? a.resumeLast(s) : a.moveTo(s, t.data[0][0], t.data[0][1]), o.forEach(t.data, function(t) {
                        a.lineTo(s, t[0], t[1]);
                    });
                } else t.event !== n.IncrementalDrawingEvent.CLEAR && t.event !== n.IncrementalDrawingEvent.SKIP || a.clear(s);
            }), this.context.stroke(), this.context.draw(!0));
        }
    }, {
        key: "setTransform",
        value: function(t, e, i) {
            var n = this.getCompetitorDrawableRect(t);
            this.transformX = function(t) {
                return t * n.width / e + n.left;
            }, this.transformY = function(t) {
                return t * n.height / i + n.top;
            };
        }
    }, {
        key: "moveTo",
        value: function(t, e, i) {
            this.transformX && (e = this.transformX(e)), this.transformY && (i = this.transformY(i)), 
            this.context.moveTo(e, i), this.lastPos[t] = {
                x: e,
                y: i
            };
        }
    }, {
        key: "lineTo",
        value: function(t, e, i) {
            this.transformX && (e = this.transformX(e)), this.transformY && (i = this.transformY(i)), 
            this.context.lineTo(e, i), this.lastPos[t] = {
                x: e,
                y: i
            };
        }
    }, {
        key: "resumeLast",
        value: function(t) {
            this.context.moveTo(this.lastPos[t].x, this.lastPos[t].y);
        }
    }, {
        key: "clear",
        value: function(t) {
            this.context.setFillStyle("white");
            var e = this.getCompetitorRect(t);
            this.context.fillRect(e.left, e.top, e.width, e.height), this.lastPos[t] = void 0;
        }
    } ]), r;
}();