function t(t) {
    if (t && t.__esModule) return t;
    var e = {};
    if (null != t) for (var a in t) Object.prototype.hasOwnProperty.call(t, a) && (e[a] = t[a]);
    return e.default = t, e;
}

function e(t) {
    return t && t.__esModule ? t : {
        default: t
    };
}

function a(t, e) {
    if (!(t instanceof e)) throw new TypeError("Cannot call a class as a function");
}

function i(t, e) {
    if (!t) throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
    return !e || "object" != typeof e && "function" != typeof e ? t : e;
}

function s(t, e) {
    if ("function" != typeof e && null !== e) throw new TypeError("Super expression must either be null or a function, not " + typeof e);
    t.prototype = Object.create(e && e.prototype, {
        constructor: {
            value: t,
            enumerable: !1,
            writable: !0,
            configurable: !0
        }
    }), e && (Object.setPrototypeOf ? Object.setPrototypeOf(t, e) : t.__proto__ = e);
}

Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.CardsView = void 0;

var n = function() {
    function t(t, e) {
        for (var a = 0; a < e.length; a++) {
            var i = e[a];
            i.enumerable = i.enumerable || !1, i.configurable = !0, "value" in i && (i.writable = !0), 
            Object.defineProperty(t, i.key, i);
        }
    }
    return function(e, a, i) {
        return a && t(e.prototype, a), i && t(e, i), e;
    };
}(), r = e(require("../events.js")), o = e(require("../../common/soundFXController.js")), l = e(require("../svgUtils.js")), d = e(require("../tooltipUtils.js")), h = e(require("../imageEncoding.js")), u = t(require("../api/gameAPI.js")), g = t(require("../utils.js")), c = require("../../game/config.js"), v = t(require("../../game/eventlog.js")), p = require("../../game/widgets/digitImage.js");

exports.CardsView = function(t) {
    function e(t) {
        a(this, e);
        var s = i(this, (e.__proto__ || Object.getPrototypeOf(e)).call(this));
        return s.page = t, s.data = {
            isPartyMode: t.data.isPartyMode,
            rank: 1,
            rankp0: 0,
            rankp1: 0,
            rankp2: 0,
            rankp3: 0
        }, s.page.buttonNewRoundReady = s.buttonNewRoundReady.bind(s), s.page.buttonStartGame = s.buttonStartGame.bind(s), 
        s.page.playClickSound = s.playClickSound.bind(s), s.page.showFinalEndCard = s.showFinalEndCard.bind(s), 
        s.page.dismissSavedPhoto = s.dismissSavedPhoto.bind(s), s;
    }
    return s(e, r.default), n(e, [ {
        key: "setData",
        value: function(t, e) {
            this.data.isPartyMode && "theme" == t && (e = "underwater"), this.data[t] = e, "rank" == t && (this.data.rankp0 = Math.floor(e / 1e3), 
            this.data.rankp1 = Math.floor(e % 1e3 / 100), this.data.rankp2 = Math.floor(e % 100 / 10), 
            this.data.rankp3 = e % 10), this.page.setData({
                cardsViewData: this.data
            });
        }
    }, {
        key: "hideCard",
        value: function(t, e) {
            t.isVisible = !1, t.hasClass("visible") && (t.on("transitionend webkitTransitionEnd oTransitionEnd MSTransitionEnd", function() {
                t.hide(), t.off("transitionend webkitTransitionEnd oTransitionEnd MSTransitionEnd"), 
                e && e();
            }), t.removeClass("visible"));
        }
    }, {
        key: "showTutorialCard",
        value: function() {
            var t = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {}, e = arguments[1], a = arguments[2];
            setTimeout(function() {
                o.default.play("swish");
            }, 100), this.setData("tutorialCardClass", "visible"), this.setData("tutorialCardTextClass", "");
            for (var i in t) this.setData(i, t[i]);
            e && setTimeout(a, e);
        }
    }, {
        key: "hideTutorialCard",
        value: function() {
            this.setData("tutorialCardClass", ""), this.setData("tutorialCardTextClass", "zoom-out");
        }
    }, {
        key: "showNewRoundBreakCard",
        value: function(t, e) {
            var a = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : "underwater";
            o.default.play("tada"), this.setData("newRoundBreakCardClass", "visible");
            var i = Math.floor(t / 10), s = t - 10 * i;
            this.setData("showTensDigit", i > 0), this.setData("tensDigitSrc", g.getGStaticUrl("numbers/digit-" + i + "-" + a + ".svg")), 
            this.setData("passedWordsCount", e), this.setData("onesDigitSrc", g.getGStaticUrl("numbers/digit-" + s + "-" + a + ".svg"));
        }
    }, {
        key: "buttonNewRoundReady",
        value: function() {
            this.setData("newRoundBreakCardClass", ""), this.page.gameController.startNextRound();
        }
    }, {
        key: "buttonStartGame",
        value: function() {
            this.hideTutorialCard(), this.emit("START_GAME");
        }
    }, {
        key: "playClickSound",
        value: function() {
            o.default.play("button-click");
        }
    }, {
        key: "showRetrySaveCard",
        value: function() {
            this.setData("retrySaveClass", "visible"), this.setData("gameOverCardClass", ""), 
            this.setData("retrySaveButton", !1), this.page.retrySave = this.retrySave.bind(this), 
            this.page.backToHome = this.backToHome.bind(this);
        }
    }, {
        key: "showGameOverCard",
        value: function(t) {
            return o.default.play("game-end"), this.setData("gameOverCardClass", "visible"), 
            this.setData("word", t.wordZhCn), this.setData("theme", t.theme), t.callback && t.callback(), 
            new Promise(function(t) {
                return setTimeout(t, 1e3);
            });
        }
    }, {
        key: "isBetter",
        value: function(t, e) {
            return e.round_pass > t.round_pass || e.round_pass == t.round_pass && e.duration < t.duration;
        }
    }, {
        key: "renderEndCardLowerContainer",
        value: function(t, e, a, i) {
            var s = this;
            this.page.showRoundDetails = function(e) {
                s.showRoundDetails(e, t, i);
            };
            for (var n = 0; n < a.length; n++) {
                var r = a[n];
                a[n].drawingSvg = l.default.createSvgBase64FromSegments(h.default.decode(r.drawing), 180, 120, {
                    padding: 25
                });
            }
            this.setData(e, a);
        }
    }, {
        key: "showFinalCongratCard",
        value: function(t) {
            o.default.play("tada"), this.page.playAgain = this.playAgain.bind(this), this.page.saveToAlbum = this.saveToAlbum.bind(this), 
            this.page.saveThemeToAlbum = this.saveThemeToAlbum.bind(this), this.page.shareFinalCongrat = this.shareFinalCongrat.bind(this), 
            this.page.catchTap = this.catchTap.bind(this), this.setData("wordCount", t.wordCount), 
            t.theme ? (this.page.shareTempleteThemeFinal = !0, this.setData("themeFinalCongratCardClass_" + t.theme, "visible"), 
            getApp().setNavigationBar(c.config.app_title, t.theme + "-congrat")) : (this.setData("finalCongratCardClass", "visible"), 
            getApp().setNavigationBar(c.config.app_title, "final-congrat"));
        }
    }, {
        key: "shareFinalCongrat",
        value: function() {}
    }, {
        key: "showEndlessEndCard",
        value: function(t, e, a, i, s, n, r, o) {
            var l = arguments.length > 8 && void 0 !== arguments[8] ? arguments[8] : void 0;
            arguments.length > 9 && void 0 !== arguments[9] && arguments[9];
            this.setData("retrySaveClass", ""), this.page.playAgain = this.playAgain.bind(this), 
            this.page.backToHome = this.backToHome.bind(this), this.page.saveToAlbum = this.saveToAlbum.bind(this), 
            this.page.shareGameResult = this.shareGameResult.bind(this), this.page.checkRanking = this.checkRanking.bind(this), 
            this.digitImage = new p.DigitImage(this), this.digitImage.setDigits(e, "本局成功画出", "张", o), 
            this.setData("digitImageData", this.digitImage.getData()), !1 !== r.showProgressBottom && (r.showProgressBottom = !0), 
            this.setData("progressData", r), this.setData("showTooltip", d.default.shouldShow("endcard"));
            var h = u.calFinalResult(a);
            if (h.prettyDuration = g.fancyTimeFormat(h.duration), this.setData("levelStr", n), 
            this.setData("endCardClass", "visible"), this.setData("theme", o), this.setData("user", i), 
            getApp().setNavigationBar(c.config.app_title, o), void 0 != l) {
                this.setData("showChallenge", !0);
                var v = l.get("result").total;
                v.prettyDuration = g.fancyTimeFormat(v.duration), this.setData("challenger", i), 
                this.setData("challengerResult", h), this.setData("creator", l.get("user")), this.setData("creatorResult", v), 
                this.setData("isChallengeSucceed", this.isBetter(v, h));
            } else this.setData("showChallenge", !1), this.setData("result", h), this.setData("isNewRecord", t);
            this.renderEndCardLowerContainer("endless", "rounds", a, s), this.timesRoundResultClicked = 0;
        }
    }, {
        key: "isShowingEndCard",
        value: function() {
            return "visible" == this.data.endCardClass;
        }
    }, {
        key: "showVsEndCard",
        value: function(t, e, a, i) {
            this.page.playAgain = this.playAgain.bind(this), this.page.saveToAlbum = this.saveToAlbum.bind(this), 
            t.total.prettyDuration = g.fancyTimeFormat(t.total.duration), e.total.prettyDuration = g.fancyTimeFormat(e.total.duration), 
            this.setData("creatorResult", t), this.setData("challengerResult", e), this.renderEndCardLowerContainer("vs", "creatorDrawings", t.detailed, i, []), 
            this.renderEndCardLowerContainer("vs", "challengerDrawings", e.detailed, i, []);
            var s = Math.max(t.detailed.length, e.detailed.length, 1);
            this.setData("competeRound", s), a = {
                WIN: {
                    theme: "light",
                    text: "对战胜利"
                },
                LOSE: {
                    theme: "black",
                    text: "对战失败"
                },
                TIE: {
                    theme: "dark",
                    text: "势均力敌"
                }
            }[a], getApp().setNavigationBar("本局结果", a.theme), this.setData("theme", a.theme), 
            this.setData("outcome", a.text), this.setData("endCardClass", "visible");
        }
    }, {
        key: "hideEndCardFooter",
        value: function() {
            this.setData("endCardFooterClass", "hide");
        }
    }, {
        key: "showEndCardFooter",
        value: function() {
            this.setData("endCardFooterClass", "");
        }
    }, {
        key: "hideEndCards",
        value: function() {
            this.setData("endCardClass", ""), this.setData("gameOverCardClass", ""), this.setData("retrySaveClass", ""), 
            this.setData("endCardZeroPassClass", ""), this.setData("finalCongratCardClass", ""), 
            this.setData("themeFinalCongratCardClass_" + this.page.gameController.theme, "");
        }
    }, {
        key: "setReplayStatus",
        value: function(t) {
            this.setData("replayStatus", t);
        }
    }, {
        key: "showRoundDetails",
        value: function(t, e, a) {
            var i = this;
            this.playClickSound();
            var s = t.currentTarget.dataset.index, n = t.currentTarget.dataset.rounds, r = this.data[n][s], o = v.getContext().data();
            o.recognized = r.recognized ? 1 : 0, o.is_new_collection = r.isNewCollection ? 1 : 0, 
            o.times_clicked = ++this.timesRoundResultClicked, v.logEvent("game_result_open_detail", o), 
            getApp().currentRound = r, "vs" == e && (this.page.delayLeaveRoom = !0, getApp().closeActiveGameHandler = function() {
                i.page.delayLeaveRoom = !1, i.page.gameController.leaveRoom();
            }), d.default.tickCount("endcard");
            var l = "/pages/roundDetail/roundDetail?cId=" + a, h = this.page.gameController.theme;
            h && (l += "&theme=" + h), wx.navigateTo({
                url: l
            });
        }
    }, {
        key: "playAgain",
        value: function(t) {
            this.emit("PLAY_AGAIN"), this.hideEndCards();
        }
    }, {
        key: "retrySave",
        value: function(t) {
            this.setData("retrySaveButton", !0), this.emit("RETRY_SAVE");
        }
    }, {
        key: "backToHome",
        value: function(t) {
            this.emit("BACK_TO_HOME");
        }
    }, {
        key: "checkRanking",
        value: function(t) {
            this.emit("CHECK_RANKING");
        }
    }, {
        key: "showFinalEndCard",
        value: function(t) {
            var e = this;
            this.page.gameController.finalEndGamePromise.then(function(t) {
                e.page.shareTempleteThemeFinal = void 0, e.page.gameController.showEndGameCard(t);
            });
        }
    }, {
        key: "saveToAlbum",
        value: function() {
            this.emit("CREATE_SHARE_PHOTO");
        }
    }, {
        key: "saveThemeToAlbum",
        value: function() {
            this.emit("CREATE_THEME_SHARE_PHOTO");
        }
    }, {
        key: "dismissSavedPhoto",
        value: function() {
            this.setData("savedPhotoDialogClass", ""), this.showEndCardFooter();
        }
    }, {
        key: "catchTap",
        value: function() {}
    }, {
        key: "showSavedPhotoDialog",
        value: function(t) {
            this.hideEndCardFooter(), this.setData("savedPhotoDialogClass", "visible"), this.setData("savedPhotoImageSrc", t);
        }
    }, {
        key: "shareGameResult",
        value: function() {
            v.logEvent("game_result_share_button", v.getContext().data());
        }
    }, {
        key: "showPartyGameEndPage",
        value: function(t) {
            o.default.play("game-end"), this.setData("gameOverCardClass", "visible"), this.setData("word", t.wordZhCn), 
            this.setData("theme", t.theme), t.callback && t.callback();
        }
    } ]), e;
}();