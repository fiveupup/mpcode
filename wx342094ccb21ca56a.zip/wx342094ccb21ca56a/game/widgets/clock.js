function t(t) {
    return t && t.__esModule ? t : {
        default: t
    };
}

function e(t, e) {
    if (!(t instanceof e)) throw new TypeError("Cannot call a class as a function");
}

function i(t, e) {
    if (!t) throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
    return !e || "object" != typeof e && "function" != typeof e ? t : e;
}

function n(t, e) {
    if ("function" != typeof e && null !== e) throw new TypeError("Super expression must either be null or a function, not " + typeof e);
    t.prototype = Object.create(e && e.prototype, {
        constructor: {
            value: t,
            enumerable: !1,
            writable: !0,
            configurable: !0
        }
    }), e && (Object.setPrototypeOf ? Object.setPrototypeOf(t, e) : t.__proto__ = e);
}

Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.Clock = void 0;

var r = function() {
    function t(t, e) {
        for (var i = 0; i < e.length; i++) {
            var n = e[i];
            n.enumerable = n.enumerable || !1, n.configurable = !0, "value" in n && (n.writable = !0), 
            Object.defineProperty(t, n.key, n);
        }
    }
    return function(e, i, n) {
        return i && t(e.prototype, i), n && t(e, n), e;
    };
}(), o = t(require("../events.js")), l = t(require("../../common/soundFXController.js")), s = null, a = exports.Clock = function(t) {
    function a(t, n, r, o) {
        e(this, a);
        var l = i(this, (a.__proto__ || Object.getPrototypeOf(a)).call(this));
        return l.context = t, l.totalTime = n, l.intervalTime = r, l.countDownTime = o || -1, 
        l.preText = "", l.reset(), l;
    }
    return n(a, o.default), r(a, [ {
        key: "setCountDownTime",
        value: function(t) {
            this.countDownTime = t;
        }
    }, {
        key: "setTextColor",
        value: function(t) {
            this.color = t;
        }
    }, {
        key: "setPreText",
        value: function(t) {
            this.preText = t;
        }
    }, {
        key: "setTimeLeft",
        value: function(t) {
            this.timeLeft = t;
        }
    }, {
        key: "reset",
        value: function(t) {
            t && (this.totalTime = t), this.timeLeft = this.totalTime, this.started = !1, this.color = a.COLOR_DEFAULT, 
            this.alertFlip = !1, this.pauseClock(), this.resetBeeper(), this.updateElm(), clearInterval(this.interval);
        }
    }, {
        key: "getTimeElapsed",
        value: function() {
            return this.totalTime - this.timeLeft;
        }
    }, {
        key: "calTimeElapsedPercent",
        value: function() {
            return 100 * (this.totalTime - this.timeLeft) / this.totalTime;
        }
    }, {
        key: "startClock",
        value: function() {
            var t = this;
            !s && wx.createInnerAudioContext && ((s = wx.createInnerAudioContext()).src = "https://www.gstatic.cn/qilin/drawtogether/click.mp3", 
            s.loop = !0), this.started = !0, this.interval && clearInterval(this.interval), 
            this.interval = setInterval(function() {
                t.timeLeft -= t.intervalTime, t.updateElm(), t.emit(a.EVENT_TIME_UPDATE, t.timeLeft, t.totalTime), 
                t.timeLeft <= 0 && (t.timeLeft = 0, t.pauseClock(), t.emit(a.EVENT_TIME_UP));
            }, 1e3 * this.intervalTime);
        }
    }, {
        key: "pauseClock",
        value: function() {
            this.started = !1, clearInterval(this.interval), this.interval = null, this.resetBeeper(), 
            this.emit(a.EVENT_COUNT_DOWN_UPDATE, !1);
        }
    }, {
        key: "resetBeeper",
        value: function() {
            s && (s.stop(), s.destroy(), s = null);
        }
    }, {
        key: "updateElm",
        value: function() {
            var t = Math.round(this.timeLeft), e = Math.floor(t / 60), i = t % 60;
            this.started && t <= this.countDownTime && (this.emit(a.EVENT_COUNT_DOWN_UPDATE, !0), 
            this.alertFlip || (this.alertFlip = !this.alertFlip, !l.default.getMute() && s && s.play())), 
            e = ("00" + e).slice(-2), i = ("00" + i).slice(-2), this.drawCanvas(this.preText + e + ":" + i), 
            this.emit(a.EVENT_TIME_ELAPSED_PERCENT, this.calTimeElapsedPercent()), this.emit(a.EVENT_TIME_UPDATE, this.timeLeft);
        }
    }, {
        key: "drawCanvas",
        value: function(t) {
            this.context.setFontSize(15), this.context.setFillStyle(this.color), this.context.fillText(t, 0, 30), 
            this.context.draw();
        }
    } ]), a;
}();

a.EVENT_TIME_UP = "EVENT_TIME_UP", a.EVENT_COUNT_DOWN_UPDATE = "EVENT_COUNT_DOWN_UPDATE", 
a.EVENT_COUNT_DOWN_END = "EVENT_COUNT_DOWN_END", a.EVENT_TIME_ELAPSED_PERCENT = "EVENT_TIME_ELAPSED_PERCENT", 
a.EVENT_TIME_UPDATE = "EVENT_TIME_UPDATE", a.COLOR_DEFAULT = "#5F6368";