function e(e, t) {
    if (!(e instanceof t)) throw new TypeError("Cannot call a class as a function");
}

Object.defineProperty(exports, "__esModule", {
    value: !0
});

var t = function() {
    function e(e, t) {
        for (var n = 0; n < t.length; n++) {
            var r = t[n];
            r.enumerable = r.enumerable || !1, r.configurable = !0, "value" in r && (r.writable = !0), 
            Object.defineProperty(e, r.key, r);
        }
    }
    return function(t, n, r) {
        return n && e(t.prototype, n), r && e(t, r), t;
    };
}(), n = require("../config.js"), r = function(e) {
    if (e && e.__esModule) return e;
    var t = {};
    if (null != e) for (var n in e) Object.prototype.hasOwnProperty.call(e, n) && (t[n] = e[n]);
    return t.default = e, t;
}(require("./rpcLayer.js")), o = void 0, u = function() {
    function u() {
        return e(this, u), o || (o = this, this.count = 0), o;
    }
    return t(u, [ {
        key: "sendRequest",
        value: function(e) {
            return new Promise(function(t, o) {
                r.invokeHttpRequest("quotaAPI", n.config.quota_api, {
                    api: e,
                    bucket: "app"
                }, "GET", "", function(e) {
                    console.log("Succeed to get quota", e), t(e);
                }, function(e) {
                    console.log("Failed to get quota", e), o(e);
                }, {
                    retrying: !0
                });
            });
        }
    } ], [ {
        key: "checkAppPermitQuota",
        value: function() {
            return u.checkQuota("QUOTA_APP_PERMITS");
        }
    }, {
        key: "checkQuota",
        value: function(e) {
            return o.sendRequest(e);
        }
    } ]), u;
}();

exports.default = u, new u();