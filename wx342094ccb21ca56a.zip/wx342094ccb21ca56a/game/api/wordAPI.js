Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.fetchWordsFromApiServer = function() {
    return new Promise(function(n, t) {
        e.invokeHttpRequest("enabledWordsAPI", r.config.enabled_words_api, "", "GET", "", function(e) {
            n(e.data);
        }, function(e) {
            t(e);
        }, {
            retrying: !0
        });
    });
}, exports.fetchWordsFromLeanCloud = function() {
    return new n.Query(t).equalTo("isTopic", !0).notEqualTo("blacklist", !0).ascending("failRate").include("ttsURLZhCn").limit(1e3).find();
};

var e = function(e) {
    if (e && e.__esModule) return e;
    var r = {};
    if (null != e) for (var n in e) Object.prototype.hasOwnProperty.call(e, n) && (r[n] = e[n]);
    return r.default = e, r;
}(require("./rpcLayer.js")), r = require("../config.js"), n = require("../../libs/av-live-query-weapp-min"), t = require("../models/words");