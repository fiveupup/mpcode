function t(t, e, n) {
    s.config.stats_server_api ? (t.room_id = c.options.party, d.invokeHttpRequest("PartyAPI", s.config.stats_server_api + "/uploadGameStats", t, "POST", {
        "content-type": "application/json"
    }, e, n)) : n && n({
        error: "unknown"
    });
}

function e(t, e, n) {
    s.config.stats_server_api ? (t.room_id = c.options.party, d.invokeHttpRequest("PartyAPI.profile", s.config.stats_server_api + "/profile", t, "POST", {
        "content-type": "application/json"
    }, e, n)) : n && n({
        error: "unknown"
    });
}

function n() {
    c.status = "UNKNOWN", c.isPartyMode = !1, c.isJointIn = !1, c.roundTimeout = !1, 
    c.eventListner = !1, c.started = !1, c.hadWentToParty = !1;
}

function r() {
    c.isPartyMode && c.user ? t({
        action: "get_room_status",
        wx_id: c.user.username
    }, function(t) {
        setTimeout(r, 2e3), c.roundTimeout = t.data.round_time_in_second, void 0 !== t.data.rank && void 0 !== t.data.next_rank_limit && void 0 !== t.data.total_players && (c.rank = t.data.rank, 
        c.next_rank_limit = t.data.next_rank_limit, c.total_players = t.data.total_players, 
        c.eventListner && c.eventListner.onRankChange && c.eventListner.onRankChange(c.rank, c.next_rank_limit, c.total_players));
        var e = t.data.room_status;
        c.status != e && (c.status = e, "INIT" == e && (c.status = "INIT", c.isJointIn = !1), 
        c.eventListner && c.eventListner.onStatusChange && ("WAITING" == e && c.isJointIn && wx.redirectTo({
            url: "/pages/party/party"
        }), c.eventListner.onStatusChange(c.status)));
        var n = t.data.player_status;
        c.player_status != n && (c.player_status = n, c.eventListner && c.eventListner.onPlayerStatusChange && c.eventListner.onPlayerStatusChange(c.player_status));
    }, function(t) {
        setTimeout(r, 2e3);
    }) : setTimeout(r, 2e3);
}

function o() {
    c.pingStarted || (c.pingStarted = !0, r());
}

Object.defineProperty(exports, "__esModule", {
    value: !0
});

var i = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(t) {
    return typeof t;
} : function(t) {
    return t && "function" == typeof Symbol && t.constructor === Symbol && t !== Symbol.prototype ? "symbol" : typeof t;
};

exports.shouldGotoPartyPage = function() {
    return !(!(u.configEnabled(u.ENABLED_PARTY_MODE) && c.options && c.options.isPartyMode && c.options.party) || c.hadWentToParty);
}, exports.start = function() {
    return c.hadWentToParty = !0, !c.started && (c.isPartyMode = !!(u.configEnabled(u.ENABLED_PARTY_MODE) && c.options && c.options.isPartyMode && c.options.party), 
    !!c.isPartyMode && (c.started = !0, a.currentAsync().then(function(t) {
        c.user = t.attributes, e({
            action: "add_profile",
            add_profile_request: {
                access_code: c.options.qrId,
                wx_id: c.user.username,
                name: c.user.nickName,
                avatar: c.user.avatarUrl
            }
        }, function(t) {
            t.data && t.data.error ? c.isProfileVerified || (c.isPartyMode = !1) : (c.isProfileVerified = !0, 
            wx.setStorageSync(p, {
                options: c.options,
                isProfileVerified: !0
            })), c.eventListner && c.eventListner.onVerifyCodeDone && c.eventListner.onVerifyCodeDone(t.data);
        }, function(t) {
            c.isProfileVerified || (c.isPartyMode = !1), c.eventListner && c.eventListner.onVerifyCodeDone && c.eventListner.onVerifyCodeDone({
                error: "network error"
            });
        });
    }), o(), !0));
}, exports.init = function(t) {
    var e = wx.getStorageSync(p);
    e && e.isProfileVerified && (c.isProfileVerified = !0, c.options = e.options, c.isPartyMode = !0), 
    t && void 0 !== t.isPartyMode && (n(), c.options = t);
}, exports.setEventListener = function(t) {
    c.eventListner = t, c.eventListner && c.eventListner.onStatusChange && c.eventListner.onStatusChange(c.status);
}, exports.join = function() {
    return new Promise(function(e, n) {
        c.user ? t({
            action: "join",
            join_request: {
                wx_id: c.user.username,
                name: c.user.nickName,
                avatar: c.user.avatarUrl
            }
        }, function(t) {
            if (c.words = !1, t.data.words) {
                var r = !1;
                try {
                    r = JSON.parse(t.data.words);
                } catch (e) {
                    console.log("invalid words:", t.data.words);
                }
                r && "object" == (void 0 === r ? "undefined" : i(r)) && r.length > 0 && (c.words = r);
            }
            t.data.error ? (c.isJointIn = !1, n({
                error: t.data.error
            })) : (c.isJointIn = !0, e());
        }, function(t) {
            n({
                error: "network error"
            });
        }) : n({
            error: "no signed in user"
        });
    });
}, exports.getResult = function() {
    return new Promise(function(e, n) {
        c.user ? t({
            action: "get_room_status",
            wx_id: c.user.username
        }, function(t) {
            t.data.error ? n(t.data) : e(t.data);
        }, function(t) {
            n({
                error: "network error"
            });
        }) : n({
            error: "no signed in user"
        });
    });
}, exports.submitScore = function(e) {
    e <= 0 || t({
        action: "update",
        update_request: {
            wx_id: c.user.username,
            score: e
        }
    });
}, exports.reportEnd = function() {
    t({
        action: "update",
        update_request: {
            wx_id: c.user.username,
            is_end: !0
        }
    }), c.isJointIn = !1;
}, exports.quitRoom = function() {
    c.isJointIn = !1;
}, exports.isPartyMode = function() {
    return !!u.configEnabled(u.ENABLED_PARTY_MODE) && (c.isPartyMode || !1);
}, exports.canPlay = function() {
    return c.isJointIn && "PLAYING" == c.status;
}, exports.canJoin = function() {
    return !c.isJointIn && "WAITING" == c.status;
}, exports.getWords = function() {
    return c.words;
}, exports.getRoundTimeout = function() {
    return c.roundTimeout;
}, exports.isForceEnd = function() {
    return "END" == c.status || "Alive" != c.player_status;
}, exports.getPlayerStatus = function() {
    return c.player_status;
};

var s = require("../config.js"), a = require("../../libs/av-live-query-weapp-min").User, u = require("../config/configManager"), d = require("rpcLayer"), p = "party.config", c = {};