function e() {
    if (p.length > 0) {
        for (var e = 0; e < p.length; e++) i.play.sendEvent(p[e].event, p[e].data, {
            receiverGroup: p[e].receiverGroup
        });
        p = [];
    }
}

function n() {
    i.play.on(i.Event.CONNECTED, function() {
        console.log("connect succeed"), a.emit(i.Event.CONNECTED), e();
    }), i.play.on(i.Event.CONNECT_FAILED, function(e) {
        console.log("connect fail", e), a.emit(i.Event.CONNECT_FAILED, e);
    }), i.play.on(i.Event.DISCONNECTED, function() {
        console.log("disconnected"), a.emit("DISCONNECTED");
    }), i.play.on(i.Event.ROOM_JOINED, function() {
        console.log("join room succeed. Room name: ", i.play.room.name), a.emit(i.Event.ROOM_JOINED), 
        e();
    }), i.play.on(i.Event.ROOM_JOIN_FAILED, function(e) {
        console.log("join room fail", e), a.emit(i.Event.ROOM_JOIN_FAILED, e);
    }), i.play.on(i.Event.ROOM_LEFT, function() {
        console.log("room left"), i.play.reset();
    }), i.play.on(i.Event.PLAYER_ROOM_JOINED, function(e) {
        console.log("PLAYER_ROOM_JOINED");
    }), i.play.on(i.Event.PLAYER_ROOM_LEFT, function(e) {
        console.log("PLAYER_ROOM_LEFT"), a.emit("PLAYER_ROOM_LEFT", e.leftPlayer.userId);
    }), i.play.on(i.Event.PLAYER_ACTIVITY_CHANGED, function() {
        console.log("PLAYER_ACTIVITY_CHANGED");
    }), i.play.on(i.Event.CUSTOM_EVENT, function(e) {
        console.log("CUSTOM_EVENT", e), a.emit(e.eventId, e.eventData, e.senderId);
    }), i.play.on(i.Event.ERROR, function(e) {
        console.log("ERROR", e);
    }), i.play.on(i.Event.PLAYER_CUSTOM_PROPERTIES_CHANGED, function(e) {
        a.emit("PLAYER_CUSTOM_PROPERTIES_CHANGED", e);
    }), E = !0;
}

function o(e, n, o, t) {
    return new Promise(function(r, i) {
        var c = void 0, u = function() {
            r(!0), l();
        }, s = function(e) {
            i(e), l();
        }, l = function() {
            a.removeListener(n, u), a.removeListener(o, s), c && clearTimeout(c);
        };
        a.addListener(n, u), a.addListener(o, s), t && (c = setTimeout(function() {
            l(), i("Timeout");
        }, t)), e();
    });
}

function t(e, n) {
    var o = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : i.ReceiverGroup.MasterClient;
    try {
        i.play.sendEvent(e, n, {
            receiverGroup: o
        }), console.log("Sending CUSTOM_EVENT", e, n, o);
    } catch (t) {
        3 != i.play._playState && (console.log("Network issue, push event to queue.", t, e, n, o), 
        p.push({
            event: e,
            data: n,
            receiverGroup: o
        }));
    }
}

Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.initPlay = function(e) {
    return E || n(), console.log("Initializing playSDK with user", e.id), l = e, f ? i.play.reset() : (i.play.init(Object.assign({
        region: i.Region.NorthChina,
        feature: "wechat"
    }, s.getLeanCloudAppIdAndKey())), f = !0), i.play.userId = l.id, o(function() {
        return i.play.connect();
    }, i.Event.CONNECTED, i.Event.CONNECT_FAILED);
}, exports.joinRoom = function(e) {
    return o(function() {
        console.log("calling rejoinRoom", e), i.play.rejoinRoom(e);
    }, i.Event.ROOM_JOINED, i.Event.ROOM_JOIN_FAILED).catch(function(n) {
        return o(function() {
            console.log("calling joinRoom", e), i.play.joinRoom(e);
        }, i.Event.ROOM_JOINED, i.Event.ROOM_JOIN_FAILED);
    });
}, exports.updateMyUserInfo = function() {
    console.log("Updating user info"), i.play.player.setCustomProperties({
        userInfo: l.get("userInfo")
    });
}, exports.getUsersInfo = function() {
    var e = [];
    return i.play.room.playerList.forEach(function(n) {
        n.properties && n.properties.userInfo && e.push({
            userId: n.userId,
            actorId: n.actorId,
            userInfo: n.properties.userInfo,
            isHost: n.properties.isHost
        });
    }), e;
}, exports.createRoom = function() {
    return new Promise(function(e, n) {
        c.invokeHttpRequest("createRoomAPI", r.config.create_room_api, {
            userId: l.id,
            mode: "p",
            durationSeconds: s.getIntValue(s.PK_CHALLENGE_TIME),
            warmupSeconds: r.config.tutorial_round_threshold
        }, "POST", "", function(n) {
            console.log("createRoom success", n), e(n.data.roomName);
        }, function(e) {
            console.log("createRoom failed", e), n(e);
        }, {
            retrying: !0,
            timeoutPeriod: 5e3
        });
    });
}, exports.sendCustomEvent = t, exports.getEventEmitter = function() {
    return a;
}, exports.getUser = function() {
    return l;
}, exports.leaveRoom = function() {
    i.play.leaveRoom();
}, exports.reconnectAndRejoin = function() {
    return o(function() {
        return i.play.reconnectAndRejoin();
    }, i.Event.ROOM_JOINED, i.Event.ROOM_JOIN_FAILED);
}, exports.reconnectAndRejoinWithBackoff = function() {
    var e = function(e) {
        return o(function() {
            console.log("Reconnecting in " + e / 1e3 + "s...."), setTimeout(function() {
                console.log("Connecting..."), i.play.reconnectAndRejoin();
            }, e);
        }, i.Event.ROOM_JOINED, i.Event.ROOM_JOIN_FAILED, e + 2e3);
    };
    return e(500).catch(function(n) {
        return e(1e3);
    }).catch(function(n) {
        return e(2e3);
    }).catch(function(n) {
        return e(4e3);
    }).catch(function(n) {
        return e(4e3);
    }).catch(function(n) {
        return e(4e3);
    });
}, exports.processSegments = function(e, n, o, r) {
    t(O, {
        seqNumber: ++R,
        roundNumber: e,
        drawingData: {
            width: o,
            height: r,
            incrementalDrawing: n
        }
    }, i.ReceiverGroup.MasterClient);
};

var r = require("../config.js"), i = require("../../libs/play-weapp.js"), c = function(e) {
    if (e && e.__esModule) return e;
    var n = {};
    if (null != e) for (var o in e) Object.prototype.hasOwnProperty.call(e, o) && (n[o] = e[o]);
    return n.default = e, n;
}(require("./rpcLayer.js")), u = function(e) {
    return e && e.__esModule ? e : {
        default: e
    };
}(require("../events.js")), s = require("../config/configManager"), l = void 0, a = new u.default(), E = !1, f = !1, p = [], O = "C2ALL_INCREMENTAL_DRAWING", R = 0;