function e(n, r, s, a, c, l, f, p, y) {
    var m = void 0, g = d.get(n) || 0, v = Date.now(), h = function(e) {
        var t = Date.now() - v;
        console.log("[" + e.statusCode + "] Invoked " + n + ", latency=" + t + "ms, url=" + r), 
        l && l(e);
    }, w = function(t) {
        if (403 == t.statusCode && t.data) try {
            for (var o = t.data.A, i = 0, u = o.length - 1; u >= 0; u--) i = 97 * i + o[u];
            var d = Math.floor(new Date().getTime() / 1e3);
            getApp().secondsDiff = i - d, console.log("Auth failed. Secondsdiff=", getApp().secondsDiff);
        } catch (e) {}
        var m = Date.now() - v;
        console.log("Invoke " + n + " failed, latency=" + m + "ms, url=" + r, t), p -= 1, 
        (y -= m) < 0 ? f && f({
            reason: "Request timed out!",
            lastRes: t
        }) : p < 0 ? f && f({
            reason: "Request exceeds max retry count!",
            lastRes: t
        }) : (console.log("Retrying request. Remaining retry count: ", p), e(n, r, s, a, c, l, f, p, y));
    }, b = o(), D = "object" == (void 0 === s ? "undefined" : i(s)) ? JSON.stringify(s) : s, x = u.OtpUtils.hashEncrypt("", D), j = Object.assign(c || {}, {
        "content-type": "application/json",
        userid: b,
        token: u.OtpUtils.hashEncrypt(b, u.OtpUtils.getCurrentMinuteInSeconds()),
        encrypt: x
    }), q = wx.request({
        url: r,
        data: D,
        method: a,
        header: j,
        success: function(e) {
            t(e.statusCode) ? h(e) : w(e);
        },
        fail: w,
        complete: function(e) {
            clearTimeout(m), g++, d.set(n, g);
        }
    });
    return m = setTimeout(function() {
        void 0 !== q && (q.error && q.abort(), f && f("Request timed out!"));
    }, y), q;
}

function t(e) {
    return e.toString().startsWith("2");
}

function o() {
    if (void 0 === getApp().leancloudUserId) {
        for (var e = "", t = 0; t < 24; t++) e += l[a.random(l.length - 1)];
        return e;
    }
    return getApp().leancloudUserId;
}

function n(e) {
    return "?" + r(e);
}

function r(e) {
    return Object.keys(e).map(function(t) {
        return [ t, e[t] ].map(encodeURIComponent).join("=");
    }).join("&");
}

Object.defineProperty(exports, "__esModule", {
    value: !0
});

var i = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(e) {
    return typeof e;
} : function(e) {
    return e && "function" == typeof Symbol && e.constructor === Symbol && e !== Symbol.prototype ? "symbol" : typeof e;
};

exports.invokeHttpRequest = function(t, o, i, u, a, l, d) {
    var f = arguments.length > 7 && void 0 !== arguments[7] ? arguments[7] : {}, p = f.retrying, y = void 0 !== p && p, m = f.timeoutPeriod, g = void 0 === m ? s.config.rpc_default_timeout_period : m, v = f.maxRetryCount, h = void 0 === v ? s.config.rpc_max_retry_count : v;
    return u === c && (o.includes("?") ? o += r(i) : o += n(i), i = ""), e(t, o, i, u, a, l, d, y ? h : 0, g);
}, exports.wxDownloadFile = function(e, n, r, i) {
    var s = d.get(e);
    s || (s = 0);
    var a = Date.now(), c = function(e) {
        var t = Date.now() - a;
        console.log("Download failed, latency=" + t + "ms, url=" + n, e), i && i(e);
    }, l = o();
    wx.downloadFile({
        url: n,
        header: {
            userid: l,
            token: u.OtpUtils.hashEncrypt(l, u.OtpUtils.getCurrentMinuteInSeconds())
        },
        success: function(o) {
            if (t(o.statusCode)) {
                var i = Date.now() - a;
                console.log("[" + o.statusCode + "] Download " + e + ", latency=" + i + "ms, url=" + n), 
                r && r(o);
            } else c();
        },
        fail: c,
        complete: function(t) {
            s++, d.set(e, s);
        }
    });
};

var s = require("../config.js"), u = require("../otpUtils.js"), a = require("../../libs/underscore/underscore.modified"), c = "GET", l = "abcdefghijklmnopqrstuvwxyz0123456789", d = new Map();