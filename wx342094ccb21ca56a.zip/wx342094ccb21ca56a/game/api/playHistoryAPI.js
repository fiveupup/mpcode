function e(e) {
    if (e && e.__esModule) return e;
    var t = {};
    if (null != e) for (var n in e) Object.prototype.hasOwnProperty.call(e, n) && (t[n] = e[n]);
    return t.default = e, t;
}

function t(e, t) {
    if (!(e instanceof t)) throw new TypeError("Cannot call a class as a function");
}

Object.defineProperty(exports, "__esModule", {
    value: !0
});

var n = function() {
    function e(e, t) {
        for (var n = 0; n < t.length; n++) {
            var r = t[n];
            r.enumerable = r.enumerable || !1, r.configurable = !0, "value" in r && (r.writable = !0), 
            Object.defineProperty(e, r.key, r);
        }
    }
    return function(t, n, r) {
        return n && e(t.prototype, n), r && e(t, r), t;
    };
}(), r = e(require("./rpcLayer.js")), i = require("../config.js"), o = e(require("./gameAPI.js")), a = require("../../common/initState.js"), u = require("../../libs/av-live-query-weapp-min"), s = require("../models/playHistory"), l = void 0, c = function() {
    function e() {
        return t(this, e), l || (l = this), l;
    }
    return n(e, null, [ {
        key: "initialFetch",
        value: function() {
            return new Promise(function(e, t) {
                if (null == u.User.current()) return t({
                    code: a.InitFailAction.FETCH_PLAY_HISTORY,
                    cause: "AV.User.current() is null"
                }), void (l.playHistory = null);
                o.getOrCreate(s, "player", u.User.current()).then(function(t) {
                    l.playHistory = t, e(t);
                }).catch(function(e) {
                    t({
                        code: a.InitFailAction.FETCH_PLAY_HISTORY,
                        cause: e
                    }), l.playHistory = null;
                });
            });
        }
    }, {
        key: "fetchWorldPersonalBestPlayHistory",
        value: function() {
            return new u.Query(s).include("player").select([ "player.nickName", "player.avatarUrl", "level" ]).addDescending("personalBestCount").addAscending("personalBestTime").addDescending("updatedAt").greaterThan("personalBestCount", 0).limit(100).find();
        }
    }, {
        key: "fetchTop100",
        value: function() {
            return new Promise(function(e, t) {
                r.invokeHttpRequest("top100API", i.config.top100_api, {}, "GET", "", function(t) {
                    e(t.data);
                }, function(t) {
                    e([]), wx.showToast({
                        title: "网络不给力",
                        image: "/assets/icon/cross.png",
                        duration: 2e3
                    });
                }, {
                    retrying: !0,
                    timeoutPeriod: 1e4
                });
            });
        }
    }, {
        key: "fetchUserRank",
        value: function(e, t) {
            return console.log("endlessBestCount, endlessBestTime: ", e, t), new Promise(function(n, o) {
                r.invokeHttpRequest("userRankAPI", i.config.user_rank_api, {
                    endlessBestCount: e,
                    endlessBestTime: t
                }, "GET", "", function(e) {
                    n(e.data);
                }, function(e) {
                    o(-1);
                }, {
                    retrying: !0,
                    timeoutPeriod: 1e4
                });
            });
        }
    }, {
        key: "fetchWorldVsPlayHistory",
        value: function() {
            return new u.Query(s).include("player").select([ "player.nickName", "player.avatarUrl", "level" ]).greaterThanOrEqualTo("vsGameCount", 10).addDescending("vsWinRate").addDescending("vsGameCount").addDescending("updatedAt").limit(100).find();
        }
    }, {
        key: "hasFetchedPlayHistory",
        value: function() {
            return !!l.playHistory;
        }
    }, {
        key: "fetch",
        value: function() {
            return new u.Query(s).equalTo("player", u.User.current()).find().then(function(e) {
                if (e.length < 1) throw new Error("Cannot find user play history. User: ", u.User.current());
                return l.playHistory = e[0], l.playHistory;
            });
        }
    }, {
        key: "getLatestPlayHistory",
        value: function() {
            return l.playHistory;
        }
    }, {
        key: "setLatestPlayHistory",
        value: function(e) {
            l.playHistory = e;
        }
    }, {
        key: "setOptout",
        value: function(e) {
            return console.log("optout: ", e), new Promise(function(t, n) {
                r.invokeHttpRequest("leaderboardOptout", i.config.leaderboardOptout_api, {
                    playHistoryId: l.playHistory.id,
                    optOutGlobalLeaderboard: e
                }, "POST", "", function(e) {
                    200 == e.statusCode ? t(!0) : n(e);
                }, function(e) {
                    n(e);
                });
            });
        }
    } ]), e;
}();

exports.default = c, new c();