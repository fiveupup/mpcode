function r(r, e) {
    if (!(r instanceof e)) throw new TypeError("Cannot call a class as a function");
}

Object.defineProperty(exports, "__esModule", {
    value: !0
});

var e = function() {
    function r(r, e) {
        for (var n = 0; n < e.length; n++) {
            var a = e[n];
            a.enumerable = a.enumerable || !1, a.configurable = !0, "value" in a && (a.writable = !0), 
            Object.defineProperty(r, a.key, a);
        }
    }
    return function(e, n, a) {
        return n && r(e.prototype, n), a && r(e, a), e;
    };
}(), n = function() {
    function n() {
        r(this, n);
    }
    return e(n, null, [ {
        key: "getRoundDetail",
        value: function(r, e) {
            var a = {
                myUserId: e,
                wordDisplay: r.wordDisplay,
                numSuccess: r.numSuccess,
                numFail: r.numFail,
                myDrawing: {
                    drawingSrc: ""
                },
                otherDrawings: []
            };
            return r.drawings.forEach(function(r) {
                var n = {
                    avatarUrl: r.avatarUrl
                };
                r.recognized || !r.skipped ? (n.drawingSrc = r.drawingSvg, n.recognized = r.recognized) : (n.drawingSrc = "http://www.gstatic.com/qilin/drawtogether/pk/skip-drawing.png", 
                n.skipped = !0), r.userId === e ? a.myDrawing = n : a.otherDrawings.push(n);
            }), a.resultStatus = n.calcResultStatus(a), a;
        }
    }, {
        key: "calcResultStatus",
        value: function(r) {
            var e = r.myDrawing.recognized ? "Correct" : "Incorrect", n = r.numSuccess, a = r.numFail;
            return r.myDrawing.drawingSrc ? (r.myDrawing.recognized ? n-- : a--, r.myDrawing.skipped ? "Skip" : 0 === n ? e + "None" : 0 === a ? e + "All" : e + "Part") : "NA";
        }
    } ]), n;
}();

exports.default = n;