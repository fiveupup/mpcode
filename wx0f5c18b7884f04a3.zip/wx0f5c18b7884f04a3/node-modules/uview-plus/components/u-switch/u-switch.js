var i = require("../../../../common/vendor.js"), e = {
    name: "u-switch",
    mixins: [ i.mpMixin, i.mixin, i.props$2 ],
    watch: {
        modelValue: {
            immediate: !0,
            handler: function handler(e) {
                e !== this.inactiveValue && e !== this.activeValue && i.index.$u.error("v-model绑定的值必须为inactiveValue、activeValue二者之一");
            }
        }
    },
    data: function data() {
        return {
            bgColor: "#ffffff"
        };
    },
    computed: {
        isActive: function isActive() {
            return this.modelValue === this.activeValue;
        },
        switchStyle: function switchStyle() {
            var e = {};
            return e.width = i.index.$u.addUnit(2 * this.size + 2), e.height = i.index.$u.addUnit(Number(this.size) + 2), 
            this.customInactiveColor && (e.borderColor = "rgba(0, 0, 0, 0)"), e.backgroundColor = this.isActive ? this.activeColor : this.inactiveColor, 
            e;
        },
        nodeStyle: function nodeStyle() {
            var e = {};
            e.width = i.index.$u.addUnit(this.size - this.space), e.height = i.index.$u.addUnit(this.size - this.space);
            var t = this.isActive ? i.index.$u.addUnit(this.space) : i.index.$u.addUnit(this.size);
            return e.transform = "translateX(-".concat(t, ")"), e;
        },
        bgStyle: function bgStyle() {
            var e = {};
            return e.width = i.index.$u.addUnit(2 * Number(this.size) - this.size / 2), e.height = i.index.$u.addUnit(this.size), 
            e.backgroundColor = this.inactiveColor, e.transform = "scale(".concat(this.isActive ? 0 : 1, ")"), 
            e;
        },
        customInactiveColor: function customInactiveColor() {
            return "#fff" !== this.inactiveColor && "#ffffff" !== this.inactiveColor;
        }
    },
    emits: [ "update:modelValue", "change" ],
    methods: {
        clickHandler: function clickHandler() {
            var _this = this;
            if (!this.disabled && !this.loading) {
                var _i = this.isActive ? this.inactiveValue : this.activeValue;
                this.asyncChange || this.$emit("update:modelValue", _i), this.$nextTick(function() {
                    _this.$emit("change", _i);
                });
            }
        }
    }
};

if (!Array) {
    i.resolveComponent("u-loading-icon")();
}

Math;

var t = i._export_sfc(e, [ [ "render", function(e, t, s, a, n, o) {
    return {
        a: i.s(o.bgStyle),
        b: i.p({
            show: e.loading,
            mode: "circle",
            timingFunction: "linear",
            color: e.modelValue ? e.activeColor : "#AAABAD",
            size: .6 * e.size
        }),
        c: i.n(e.modelValue && "u-switch__node--on"),
        d: i.s(o.nodeStyle),
        e: i.n(e.disabled && "u-switch--disabled"),
        f: i.s(o.switchStyle),
        g: i.s(e.$u.addStyle(e.customStyle)),
        h: i.o(function() {
            return o.clickHandler && o.clickHandler.apply(o, arguments);
        })
    };
} ], [ "__scopeId", "data-v-a17af18d" ] ]);

wx.createComponent(t);