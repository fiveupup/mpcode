var o = require("../../../../common/vendor.js"), e = {
    name: "u-toolbar",
    mixins: [ o.mpMixin, o.mixin, o.props$5 ],
    methods: {
        cancel: function cancel() {
            this.$emit("cancel");
        },
        confirm: function confirm() {
            this.$emit("confirm");
        }
    }
};

var c = o._export_sfc(e, [ [ "render", function(e, c, n, t, i, r) {
    return o.e({
        a: e.show
    }, e.show ? o.e({
        b: o.t(e.cancelText),
        c: o.o(function() {
            return r.cancel && r.cancel.apply(r, arguments);
        }),
        d: e.cancelColor,
        e: e.title
    }, e.title ? {
        f: o.t(e.title)
    } : {}, {
        g: o.t(e.confirmText),
        h: o.o(function() {
            return r.confirm && r.confirm.apply(r, arguments);
        }),
        i: e.confirmColor,
        j: o.o(function() {
            return e.noop && e.noop.apply(e, arguments);
        })
    }) : {});
} ], [ "__scopeId", "data-v-88cf1536" ] ]);

wx.createComponent(c);