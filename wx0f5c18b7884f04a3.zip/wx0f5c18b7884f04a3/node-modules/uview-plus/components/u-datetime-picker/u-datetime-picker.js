var _defineProperty2 = require("../../../../@babel/runtime/helpers/defineProperty");

var _slicedToArray2 = require("../../../../@babel/runtime/helpers/slicedToArray");

var e = require("../../../../common/vendor.js");

var t = {
    name: "datetime-picker",
    mixins: [ e.mpMixin, e.mixin, e.props$1 ],
    data: function data() {
        return {
            columns: [],
            innerDefaultIndex: [],
            innerFormatter: function innerFormatter(e, t) {
                return t;
            }
        };
    },
    watch: {
        show: function show(e, t) {
            e && this.updateColumnValue(this.innerValue);
        },
        propsChange: function propsChange() {
            this.init();
        }
    },
    computed: {
        propsChange: function propsChange() {
            return [ this.mode, this.maxDate, this.minDate, this.minHour, this.maxHour, this.minMinute, this.maxMinute, this.filter ];
        }
    },
    mounted: function mounted() {
        this.init();
    },
    emits: [ "close", "cancel", "confirm", "change", "update:modelValue" ],
    methods: {
        init: function init() {
            this.innerValue = this.correctValue(this.modelValue), this.updateColumnValue(this.innerValue);
        },
        setFormatter: function setFormatter(e) {
            this.innerFormatter = e;
        },
        close: function close() {
            this.closeOnClickOverlay && this.$emit("close");
        },
        cancel: function cancel() {
            this.$emit("cancel");
        },
        confirm: function confirm() {
            this.$emit("confirm", {
                value: this.innerValue,
                mode: this.mode
            }), this.$emit("update:modelValue", this.innerValue);
        },
        intercept: function intercept(t, i) {
            var n = t.match(/\d+/g);
            return n.length > 1 ? (e.index.$u.error("请勿在过滤或格式化函数时添加数字"), 0) : i && 4 == n[0].length ? n[0] : n[0].length > 2 ? (e.index.$u.error("请勿在过滤或格式化函数时添加数字"), 
            0) : n[0];
        },
        change: function change(t) {
            var i = t.indexs, n = t.values;
            var a = "";
            if ("time" === this.mode) a = "".concat(this.intercept(n[0][i[0]]), ":").concat(this.intercept(n[1][i[1]])); else {
                var _t = parseInt(this.intercept(n[0][i[0]], "year")), r = parseInt(this.intercept(n[1][i[1]]));
                var s = parseInt(n[2] ? this.intercept(n[2][i[2]]) : 1), o = 0, m = 0;
                var u = e.dayjs$1("".concat(_t, "-").concat(r)).daysInMonth();
                "year-month" === this.mode && (s = 1), s = Math.min(u, s), "datetime" === this.mode && (o = parseInt(this.intercept(n[3][i[3]])), 
                m = parseInt(this.intercept(n[4][i[4]]))), a = Number(new Date(_t, r - 1, s, o, m));
            }
            a = this.correctValue(a), this.innerValue = a, this.updateColumnValue(a), this.$emit("change", {
                value: a,
                mode: this.mode
            });
        },
        updateColumnValue: function updateColumnValue(e) {
            this.innerValue = e, this.updateColumns(), this.updateIndexs(e);
        },
        updateIndexs: function updateIndexs(t) {
            var i = [];
            var n = this.formatter || this.innerFormatter, a = e.index.$u.padZero;
            if ("time" === this.mode) {
                var _e = t.split(":");
                i = [ n("hour", _e[0]), n("minute", _e[1]) ];
            } else i = [ n("year", "".concat(e.dayjs$1(t).year())), n("month", a(e.dayjs$1(t).month() + 1)) ], 
            "date" === this.mode && i.push(n("day", a(e.dayjs$1(t).date()))), "datetime" === this.mode && i.push(n("day", a(e.dayjs$1(t).date())), n("hour", a(e.dayjs$1(t).hour())), n("minute", a(e.dayjs$1(t).minute())));
            var r = this.columns.map(function(e, t) {
                return Math.max(0, e.findIndex(function(e) {
                    return e === i[t];
                }));
            });
            this.innerDefaultIndex = r;
        },
        updateColumns: function updateColumns() {
            var e = this.formatter || this.innerFormatter, t = this.getOriginColumns().map(function(t) {
                return t.values.map(function(i) {
                    return e(t.type, i);
                });
            });
            this.columns = t;
        },
        getOriginColumns: function getOriginColumns() {
            var _this = this;
            return this.getRanges().map(function(_ref) {
                var t = _ref.type, i = _ref.range;
                var n = function(e, t) {
                    var i = -1;
                    var n = Array(e < 0 ? 0 : e);
                    for (;++i < e; ) n[i] = t(i);
                    return n;
                }(i[1] - i[0] + 1, function(n) {
                    var a = i[0] + n;
                    return a = "year" === t ? "".concat(a) : e.index.$u.padZero(a), a;
                });
                return _this.filter && (n = _this.filter(t, n)), {
                    type: t,
                    values: n
                };
            });
        },
        generateArray: function generateArray(e, t) {
            return Array.from(new Array(t + 1).keys()).slice(e);
        },
        correctValue: function correctValue(t) {
            var i = "time" !== this.mode;
            if (i && !e.index.$u.test.date(t) ? t = this.minDate : i || t || (t = "".concat(e.index.$u.padZero(this.minHour), ":").concat(e.index.$u.padZero(this.minMinute))), 
            i) return t = e.dayjs$1(t).isBefore(e.dayjs$1(this.minDate)) ? this.minDate : t, 
            t = e.dayjs$1(t).isAfter(e.dayjs$1(this.maxDate)) ? this.maxDate : t;
            {
                if (-1 === String(t).indexOf(":")) return e.index.$u.error("时间错误，请传递如12:24的格式");
                var _t$split = t.split(":"), _t$split2 = _slicedToArray2(_t$split, 2), _i = _t$split2[0], n = _t$split2[1];
                return _i = e.index.$u.padZero(e.index.$u.range(this.minHour, this.maxHour, Number(_i))), 
                n = e.index.$u.padZero(e.index.$u.range(this.minMinute, this.maxMinute, Number(n))), 
                "".concat(_i, ":").concat(n);
            }
        },
        getRanges: function getRanges() {
            if ("time" === this.mode) return [ {
                type: "hour",
                range: [ this.minHour, this.maxHour ]
            }, {
                type: "minute",
                range: [ this.minMinute, this.maxMinute ]
            } ];
            var _this$getBoundary = this.getBoundary("max", this.innerValue), e = _this$getBoundary.maxYear, t = _this$getBoundary.maxDate, i = _this$getBoundary.maxMonth, n = _this$getBoundary.maxHour, a = _this$getBoundary.maxMinute, _this$getBoundary2 = this.getBoundary("min", this.innerValue), r = _this$getBoundary2.minYear, s = _this$getBoundary2.minDate, o = _this$getBoundary2.minMonth, m = _this$getBoundary2.minHour, u = _this$getBoundary2.minMinute, h = [ {
                type: "year",
                range: [ r, e ]
            }, {
                type: "month",
                range: [ o, i ]
            }, {
                type: "day",
                range: [ s, t ]
            }, {
                type: "hour",
                range: [ m, n ]
            }, {
                type: "minute",
                range: [ u, a ]
            } ];
            return "date" === this.mode && h.splice(3, 2), "year-month" === this.mode && h.splice(2, 3), 
            h;
        },
        getBoundary: function getBoundary(t, i) {
            var n = new Date(i), a = new Date(this["".concat(t, "Date")]), r = e.dayjs$1(a).year();
            var s = 1, o = 1, m = 0, u = 0;
            return "max" === t && (s = 12, o = e.dayjs$1(n).daysInMonth(), m = 23, u = 59), 
            e.dayjs$1(n).year() === r && (s = e.dayjs$1(a).month() + 1, e.dayjs$1(n).month() + 1 === s && (o = e.dayjs$1(a).date(), 
            e.dayjs$1(n).date() === o && (m = e.dayjs$1(a).hour(), e.dayjs$1(n).hour() === m && (u = e.dayjs$1(a).minute())))), 
            _defineProperty2(_defineProperty2(_defineProperty2(_defineProperty2(_defineProperty2({}, "".concat(t, "Year"), r), "".concat(t, "Month"), s), "".concat(t, "Date"), o), "".concat(t, "Hour"), m), "".concat(t, "Minute"), u);
        }
    }
};

if (!Array) {
    e.resolveComponent("u-picker")();
}

Math;

var i = e._export_sfc(t, [ [ "render", function(t, i, n, a, r, s) {
    return {
        a: e.sr("picker", "e2860c81-0"),
        b: e.o(s.close),
        c: e.o(s.cancel),
        d: e.o(s.confirm),
        e: e.o(s.change),
        f: e.p({
            show: t.show,
            closeOnClickOverlay: t.closeOnClickOverlay,
            columns: r.columns,
            title: t.title,
            itemHeight: t.itemHeight,
            showToolbar: t.showToolbar,
            visibleItemCount: t.visibleItemCount,
            defaultIndex: r.innerDefaultIndex,
            cancelText: t.cancelText,
            confirmText: t.confirmText,
            cancelColor: t.cancelColor,
            confirmColor: t.confirmColor
        })
    };
} ], [ "__scopeId", "data-v-e2860c81" ] ]);

wx.createComponent(i);