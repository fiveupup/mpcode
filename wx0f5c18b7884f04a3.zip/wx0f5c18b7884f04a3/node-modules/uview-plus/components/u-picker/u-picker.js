var _regeneratorRuntime2 = require("../../../../@babel/runtime/helpers/regeneratorRuntime");

var _asyncToGenerator2 = require("../../../../@babel/runtime/helpers/asyncToGenerator");

var e = require("../../../../common/vendor.js"), n = {
    name: "u-picker",
    mixins: [ e.mpMixin, e.mixin, e.props$3 ],
    data: function data() {
        return {
            lastIndex: [],
            innerIndex: [],
            innerColumns: [],
            columnIndex: 0
        };
    },
    watch: {
        defaultIndex: {
            immediate: !0,
            handler: function handler(e) {
                this.setIndexs(e, !0);
            }
        },
        columns: {
            immediate: !0,
            deep: !0,
            handler: function handler(e) {
                this.setColumns(e);
            }
        }
    },
    emits: [ "close", "cancel", "confirm", "change" ],
    methods: {
        getItemText: function getItemText(n) {
            return e.index.$u.test.object(n) ? n[this.keyName] : n;
        },
        closeHandler: function closeHandler() {
            this.closeOnClickOverlay && this.$emit("close");
        },
        cancel: function cancel() {
            this.$emit("cancel");
        },
        confirm: function confirm() {
            var _this = this;
            this.$emit("confirm", {
                indexs: this.innerIndex,
                value: this.innerColumns.map(function(e, n) {
                    return e[_this.innerIndex[n]];
                }),
                values: this.innerColumns
            });
        },
        changeHandler: function changeHandler(e) {
            var n = e.detail.value;
            var t = 0, i = 0;
            for (var o = 0; o < n.length; o++) {
                var _e = n[o];
                if (_e !== (this.lastIndex[o] || 0)) {
                    i = o, t = _e;
                    break;
                }
            }
            this.columnIndex = i;
            var s = this.innerColumns;
            this.setLastIndex(n), this.setIndexs(n), this.$emit("change", {
                value: this.innerColumns.map(function(e, t) {
                    return e[n[t]];
                }),
                index: t,
                indexs: n,
                values: s,
                columnIndex: i
            });
        },
        setIndexs: function setIndexs(n, t) {
            this.innerIndex = e.index.$u.deepClone(n), t && this.setLastIndex(n);
        },
        setLastIndex: function setLastIndex(n) {
            this.lastIndex = e.index.$u.deepClone(n);
        },
        setColumnValues: function setColumnValues(n, t) {
            this.innerColumns.splice(n, 1, t);
            var i = e.index.$u.deepClone(this.innerIndex);
            for (var _e2 = 0; _e2 < this.innerColumns.length; _e2++) _e2 > this.columnIndex && (i[_e2] = 0);
            this.setIndexs(i);
        },
        getColumnValues: function getColumnValues(n) {
            return _asyncToGenerator2(/* */ _regeneratorRuntime2().mark(function _callee() {
                return _regeneratorRuntime2().wrap(function _callee$(_context) {
                    while (1) switch (_context.prev = _context.next) {
                      case 0:
                        _context.next = 2;
                        return e.index.$u.sleep();

                      case 2:
                      case "end":
                        return _context.stop();
                    }
                }, _callee);
            }))(), this.innerColumns[n];
        },
        setColumns: function setColumns(n) {
            console.log(n), this.innerColumns = e.index.$u.deepClone(n), 0 === this.innerIndex.length && (this.innerIndex = new Array(n.length).fill(0));
        },
        getIndexs: function getIndexs() {
            return this.innerIndex;
        },
        getValues: function getValues() {
            var _this2 = this;
            return _asyncToGenerator2(/* */ _regeneratorRuntime2().mark(function _callee2() {
                return _regeneratorRuntime2().wrap(function _callee2$(_context2) {
                    while (1) switch (_context2.prev = _context2.next) {
                      case 0:
                        _context2.next = 2;
                        return e.index.$u.sleep();

                      case 2:
                      case "end":
                        return _context2.stop();
                    }
                }, _callee2);
            }))(), this.innerColumns.map(function(e, n) {
                return e[_this2.innerIndex[n]];
            });
        }
    }
};

if (!Array) {
    (e.resolveComponent("u-toolbar") + e.resolveComponent("u-loading-icon") + e.resolveComponent("u-popup"))();
}

Math || (function() {
    return "../u-toolbar/u-toolbar.js";
} + function() {
    return "../u-loading-icon/u-loading-icon.js";
} + function() {
    return "../u-popup/u-popup.js";
})();

var t = e._export_sfc(n, [ [ "render", function(n, t, i, s, o, l) {
    return e.e({
        a: n.showToolbar
    }, n.showToolbar ? {
        b: e.o(l.cancel),
        c: e.o(l.confirm),
        d: e.p({
            cancelColor: n.cancelColor,
            confirmColor: n.confirmColor,
            cancelText: n.cancelText,
            confirmText: n.confirmText,
            title: n.title
        })
    } : {}, {
        e: e.f(o.innerColumns, function(t, i, s) {
            return e.e({
                a: n.$u.test.array(t)
            }, n.$u.test.array(t) ? {
                b: e.f(t, function(n, t, s) {
                    return {
                        a: e.t(l.getItemText(n)),
                        b: t,
                        c: t === o.innerIndex[i] ? "bold" : "normal"
                    };
                }),
                c: n.$u.addUnit(n.itemHeight),
                d: n.$u.addUnit(n.itemHeight)
            } : {}, {
                e: i
            });
        }),
        f: "height: ".concat(n.$u.addUnit(n.itemHeight)),
        g: o.innerIndex,
        h: n.immediateChange,
        i: "".concat(n.$u.addUnit(n.visibleItemCount * n.itemHeight)),
        j: e.o(function() {
            return l.changeHandler && l.changeHandler.apply(l, arguments);
        }),
        k: n.loading
    }, n.loading ? {
        l: e.p({
            mode: "circle"
        })
    } : {}, {
        m: e.o(l.closeHandler),
        n: e.p({
            show: n.show
        })
    });
} ], [ "__scopeId", "data-v-2cd212aa" ] ]);

wx.createComponent(t);