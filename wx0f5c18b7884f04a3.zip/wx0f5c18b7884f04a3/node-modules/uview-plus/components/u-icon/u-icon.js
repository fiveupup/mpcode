var i = require("../../../../common/vendor.js"), t = {
    name: "u-icon",
    data: function data() {
        return {};
    },
    emits: [ "click" ],
    mixins: [ i.mpMixin, i.mixin, i.props ],
    computed: {
        uClasses: function uClasses() {
            var t = [];
            return t.push(this.customPrefix + "-" + this.name), this.color && i.index.$u.config.type.includes(this.color) && t.push("u-icon__icon--" + this.color), 
            t;
        },
        iconStyle: function iconStyle() {
            var t = {};
            return t = {
                fontSize: i.index.$u.addUnit(this.size),
                lineHeight: i.index.$u.addUnit(this.size),
                fontWeight: this.bold ? "bold" : "normal",
                top: i.index.$u.addUnit(this.top)
            }, this.color && !i.index.$u.config.type.includes(this.color) && (t.color = this.color), 
            t;
        },
        isImg: function isImg() {
            return -1 !== this.name.indexOf("/");
        },
        imgStyle: function imgStyle() {
            var t = {};
            return t.width = this.width ? i.index.$u.addUnit(this.width) : i.index.$u.addUnit(this.size), 
            t.height = this.height ? i.index.$u.addUnit(this.height) : i.index.$u.addUnit(this.size), 
            t;
        },
        icon: function icon() {
            return i.icons["uicon-" + this.name] || this.name;
        }
    },
    methods: {
        clickHandler: function clickHandler(i) {
            this.$emit("click", this.index), this.stop && this.preventEvent(i);
        }
    }
};

var e = i._export_sfc(t, [ [ "render", function(t, e, s, n, o, d) {
    return i.e({
        a: d.isImg
    }, d.isImg ? {
        b: t.name,
        c: t.imgMode,
        d: i.s(d.imgStyle),
        e: i.s(t.$u.addStyle(t.customStyle))
    } : {
        f: i.t(d.icon),
        g: i.n(d.uClasses),
        h: i.s(d.iconStyle),
        i: i.s(t.$u.addStyle(t.customStyle)),
        j: t.hoverClass
    }, {
        k: "" !== t.label
    }, "" !== t.label ? {
        l: i.t(t.label),
        m: t.labelColor,
        n: t.$u.addUnit(t.labelSize),
        o: "right" == t.labelPos ? t.$u.addUnit(t.space) : 0,
        p: "bottom" == t.labelPos ? t.$u.addUnit(t.space) : 0,
        q: "left" == t.labelPos ? t.$u.addUnit(t.space) : 0,
        r: "top" == t.labelPos ? t.$u.addUnit(t.space) : 0
    } : {}, {
        s: i.o(function() {
            return d.clickHandler && d.clickHandler.apply(d, arguments);
        }),
        t: i.n("u-icon--" + t.labelPos)
    });
} ], [ "__scopeId", "data-v-890c3ce2" ] ]);

wx.createComponent(e);