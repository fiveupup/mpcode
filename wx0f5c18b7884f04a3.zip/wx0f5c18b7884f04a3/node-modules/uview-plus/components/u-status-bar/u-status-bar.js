var e = require("../../../../common/vendor.js"), t = {
    name: "u-status-bar",
    mixins: [ e.mpMixin, e.mixin, e.props$8 ],
    data: function data() {
        return {};
    },
    computed: {
        style: function style() {
            var t = {};
            return t.height = e.index.$u.addUnit(e.index.$u.sys().statusBarHeight, "px"), t.backgroundColor = this.bgColor, 
            e.index.$u.deepMerge(t, e.index.$u.addStyle(this.customStyle));
        }
    }
};

var n = e._export_sfc(t, [ [ "render", function(t, n, s, o, r, i) {
    return {
        a: e.s(i.style)
    };
} ], [ "__scopeId", "data-v-df170e56" ] ]);

wx.createComponent(n);