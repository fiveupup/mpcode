var _objectSpread2 = require("../../../../@babel/runtime/helpers/objectSpread2");

var t = require("../../../../common/vendor.js"), e = {
    name: "u-transition",
    data: function data() {
        return {
            inited: !1,
            viewStyle: {},
            status: "",
            transitionEnded: !1,
            display: !1,
            classes: ""
        };
    },
    computed: {
        mergeStyle: function mergeStyle() {
            var e = this.viewStyle, i = this.customStyle;
            return _objectSpread2(_objectSpread2({
                transitionDuration: "".concat(this.duration, "ms"),
                transitionTimingFunction: this.timingFunction
            }, t.index.$u.addStyle(i)), e);
        }
    },
    mixins: [ t.mpMixin, t.mixin, t.transition, t.props$10 ],
    watch: {
        show: {
            handler: function handler(t) {
                t ? this.vueEnter() : this.vueLeave();
            },
            immediate: !0
        }
    }
};

var i = t._export_sfc(e, [ [ "render", function(e, i, n, s, o, r) {
    return t.e({
        a: o.inited
    }, o.inited ? {
        b: t.o(function() {
            return e.clickHandler && e.clickHandler.apply(e, arguments);
        }),
        c: t.n(o.classes),
        d: t.s(r.mergeStyle),
        e: t.o(function() {
            return e.noop && e.noop.apply(e, arguments);
        })
    } : {});
} ], [ "__scopeId", "data-v-159cf890" ] ]);

wx.createComponent(i);