var _toConsumableArray2 = require("../../@babel/runtime/helpers/toConsumableArray");

var _regeneratorRuntime2 = require("../../@babel/runtime/helpers/regeneratorRuntime");

var _asyncToGenerator2 = require("../../@babel/runtime/helpers/asyncToGenerator");

var e = require("../../common/vendor.js"), r = require("../../api/bill.js");

if (require("../../ts/request.js"), require("../../ts/global.js"), require("../../api/user.js"), 
require("../../store/user.js"), !Array) {
    (e.resolveComponent("Loading") + e.resolveComponent("u-icon") + e.resolveComponent("LEcharts") + e.resolveComponent("MonthSelector") + e.resolveComponent("Toast"))();
}

Math || (a + function() {
    return "../../components/Loading.js";
} + function() {
    return "../../node-modules/uview-plus/components/u-icon/u-icon.js";
} + function() {
    return "../../components/LEcharts/LEcharts.js";
} + function() {
    return "../../components/MonthSelector.js";
} + function() {
    return "../../components/Toast.js";
})();

var a = function a() {
    return "./components/Head.js";
}, n = e.defineComponent({
    __name: "index",
    setup: function setup(a) {
        var n = e.ref(new Date().getFullYear()), t = e.ref([]);
        var o = e.ref({
            toolbox: {
                show: !1
            },
            series: [ {
                name: "The From",
                type: "pie",
                radius: [ "10%", "55%" ],
                itemStyle: {
                    borderRadius: 2,
                    borderColor: "#fff",
                    borderWidth: 1
                },
                label: {
                    show: !0,
                    formatter: "{b} {d}%",
                    fontSize: 10,
                    color: "#94a3b8"
                },
                data: []
            } ]
        }), l = e.ref([]), u = e.ref(!0), i = e.ref("expenditure"), s = e.ref(e.dayjs().format("YYYY-MM")), p = e.ref({}), c = e.ref(), f = e.ref(!1);
        e.onMounted(function() {
            var r = new Date().getFullYear();
            for (var _e = r - 10; _e <= r; _e++) t.value.push(String(_e));
            n.value = r, c.value.init(e.echarts, function() {
                f.value = !0;
            });
        }), t.value.length;
        var d = /* */ function() {
            var _ref = _asyncToGenerator2(/* */ _regeneratorRuntime2().mark(function _callee() {
                var _e2;
                return _regeneratorRuntime2().wrap(function _callee$(_context) {
                    while (1) switch (_context.prev = _context.next) {
                      case 0:
                        u.value = !0;
                        _context.prev = 1;
                        _context.next = 4;
                        return r.statistics({
                            date: s.value
                        });

                      case 4:
                        _e2 = _context.sent;
                        p.value = _e2.data;
                        _context.next = 11;
                        break;

                      case 8:
                        _context.prev = 8;
                        _context.t0 = _context["catch"](1);
                        console.error("加载数据失败:", _context.t0);

                      case 11:
                        _context.prev = 11;
                        setTimeout(function() {
                            u.value = !1, f.value && g(i.value);
                        }, 900);
                        return _context.finish(11);

                      case 14:
                      case "end":
                        return _context.stop();
                    }
                }, _callee, null, [ [ 1, 8, 11, 14 ] ]);
            }));
            return function d() {
                return _ref.apply(this, arguments);
            };
        }();
        d();
        var m = function m(e) {
            l.value = [], e.forEach(function(e) {
                var r = {};
                r.price = e.price, r.typeId = e.typeId, r.typeName = e.typeName, l.value.push(r);
            });
            var r = Math.max.apply(Math, _toConsumableArray2(l.value.map(function(e) {
                return e.price;
            })));
            l.value.forEach(function(e) {
                e.rate = e.price / r * 100;
            });
        }, x = function x(e) {
            o.value.series[0].data = [], e.forEach(function(e) {
                var r = {};
                r.name = e.typeName, r.value = e.price, o.value.series[0].data.push(r);
            }), c.value.setOption(o.value);
        }, b = e.ref(), v = function v() {
            b.value.showHandle(s.value);
        }, y = function y(e) {
            var r = "".concat(e.year, "-").concat(e.month < 10 ? "0" + e.month : e.month);
            r !== s.value && (s.value = r, d());
        }, g = function g(e) {
            i.value = e, "expenditure" === e ? (m(p.value.outDetail), x(p.value.outDetail)) : "income" === e ? (m(p.value.inDetail), 
            x(p.value.inDetail)) : "yearExpenditure" === e ? (m(p.value.yearOutDetail), x(p.value.yearOutDetail)) : "yearIncome" === e && (m(p.value.yearInDetail), 
            x(p.value.yearInDetail));
        };
        return function(r, a) {
            return {
                a: e.p({
                    title: "📉 统计"
                }),
                b: e.p({
                    show: e.unref(u)
                }),
                c: e.t(e.unref(s)),
                d: e.o(v),
                e: e.p({
                    name: "calendar-fill",
                    color: "#f9fafb",
                    size: "20"
                }),
                f: e.t(e.unref(p).out || 0),
                g: e.n("p-20rpx flex-none w-210rpx flex flex-col gap-20rpx bg-opacity-10 rounded-md transition-all duration-400"),
                h: e.n("expenditure" === e.unref(i) ? "bg-black" : ""),
                i: e.o(function(e) {
                    return g("expenditure");
                }),
                j: e.t(e.unref(p).in || 0),
                k: e.n("p-20rpx flex-none w-210rpx flex flex-col gap-20rpx bg-opacity-10 rounded-md transition-all duration-400"),
                l: e.n("income" === e.unref(i) ? "bg-black" : ""),
                m: e.o(function(e) {
                    return g("income");
                }),
                n: e.t(e.unref(p).yearOut || 0),
                o: e.n("p-20rpx flex-none w-210rpx flex flex-col gap-20rpx bg-opacity-10 rounded-md transition-all duration-400"),
                p: e.n("yearExpenditure" === e.unref(i) ? "bg-black" : ""),
                q: e.o(function(e) {
                    return g("yearExpenditure");
                }),
                r: e.t(e.unref(p).yearIn || 0),
                s: e.n("p-20rpx flex-none w-210rpx flex flex-col gap-20rpx bg-opacity-10 rounded-md transition-all duration-400"),
                t: e.n("yearIncome" === e.unref(i) ? "bg-black" : ""),
                v: e.o(function(e) {
                    return g("yearIncome");
                }),
                w: e.n("py-20rpx flex flex-col gap-30rpx transition-all duration-400"),
                x: e.n("expenditure" === e.unref(i) ? "bg-emerald-500" : "income" === e.unref(i) ? "bg-red-500" : "yearExpenditure" === e.unref(i) ? "bg-blue-500" : "yearIncome" === e.unref(i) ? "bg-yellow-500" : "bg-amber-500"),
                y: e.sr(c, "518b0554-3", {
                    k: "pieRef"
                }),
                z: e.f(e.unref(l), function(r, a, n) {
                    return {
                        a: e.t(r.typeName),
                        b: "".concat(r.rate, "%"),
                        c: e.t(r.price),
                        d: a
                    };
                }),
                A: e.n("flex flex-col min-h-screen transition-all duration-400"),
                B: e.n("expenditure" === e.unref(i) ? "bg-emerald-500" : "income" === e.unref(i) ? "bg-red-500" : "yearExpenditure" === e.unref(i) ? "bg-blue-500" : "yearIncome" === e.unref(i) ? "bg-yellow-500" : "bg-amber-500"),
                C: e.sr(b, "518b0554-4", {
                    k: "monthSelector"
                }),
                D: e.o(y),
                E: e.sr("toast", "518b0554-5")
            };
        };
    }
});

wx.createPage(n);