var e = require("../../../common/vendor.js");

if (!Array) {
    e.resolveComponent("HeadBar")();
}

Math;

var o = e.defineComponent({
    __name: "Head",
    props: {
        title: null
    },
    setup: function setup(o) {
        return function(t, n) {
            return {
                a: e.t(o.title),
                b: e.p({
                    color: "#FFFFFF00"
                })
            };
        };
    }
});

wx.createComponent(o);