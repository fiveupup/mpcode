var _regeneratorRuntime2 = require("../../@babel/runtime/helpers/regeneratorRuntime");

var _asyncToGenerator2 = require("../../@babel/runtime/helpers/asyncToGenerator");

var e = require("../../common/vendor.js"), s = require("../../api/user.js"), o = require("../../ts/global.js"), n = require("../../ts/request.js"), t = require("../../store/setting.js");

if (require("../../store/user.js"), !Array) {
    e.resolveComponent("u-icon")();
}

Math;

var a = e.defineComponent({
    __name: "user",
    setup: function setup(a) {
        e.ref(!1), t.useSettingStore(), e.ref("#10b981");
        var i = e.ref({});
        e.onShow(/* */ _asyncToGenerator2(/* */ _regeneratorRuntime2().mark(function _callee() {
            return _regeneratorRuntime2().wrap(function _callee$(_context) {
                while (1) switch (_context.prev = _context.next) {
                  case 0:
                    i.value = e.index.getStorageSync("user"), s.UserInfo({
                        openId: i.value.openId
                    }).then(function(e) {
                        o.saveLoginRes(e.data), i.value = e.data;
                    });

                  case 1:
                  case "end":
                    return _context.stop();
                }
            }, _callee);
        })));
        var l = function l(s) {
            e.index.navigateTo({
                url: "/pages/UserInfo/UserInfo"
            });
        }, c = function c(s) {
            e.index.navigateTo({
                url: "/pages/agreement/index"
            });
        }, r = function r(s) {
            e.index.navigateTo({
                url: "/pages/message/index"
            });
        }, u = function u(s) {
            e.index.navigateTo({
                url: "/pages/key/index"
            });
        };
        e.ref("生活不止眼前的苟且，还有诗和远方。");
        var d = function d() {
            e.index.showModal({
                title: "重置记账",
                content: "确定要重置记账吗？重置后将清空所有记账数据。",
                success: function success(s) {
                    s.confirm ? h() : s.cancel && e.index.showToast({
                        title: "已取消重置记账",
                        icon: "none"
                    });
                }
            });
        }, h = function h() {
            var s = i.value.openId;
            e.index.request({
                url: n.host + "/bill/reset",
                method: "POST",
                header: {
                    Authorization: o.getToken()
                },
                data: {
                    openId: s
                },
                success: function success(s) {
                    200 === s.data.code ? e.index.showToast({
                        title: "记账已重置",
                        icon: "success"
                    }) : e.index.showToast({
                        title: "重置记账失败",
                        icon: "none"
                    });
                },
                fail: function fail(s) {
                    e.index.showToast({
                        title: "重置记账失败",
                        icon: "none"
                    });
                }
            });
        }, p = function p() {
            e.index.showModal({
                title: "导出账单",
                content: "导出账单将会导出PDF发送至你的邮箱",
                success: function success(s) {
                    s.confirm ? g() : s.cancel && e.index.showToast({
                        title: "已取消导出账单",
                        icon: "none"
                    });
                }
            });
        }, g = function g() {
            var s = i.value.openId;
            e.index.request({
                url: n.host + "/bill/exportBillPdf",
                method: "POST",
                header: {
                    Authorization: o.getToken()
                },
                data: {
                    openId: s
                },
                success: function success(s) {
                    200 === s.data.code ? e.index.showToast({
                        title: "记账记录已导出",
                        icon: "success"
                    }) : e.index.showToast({
                        title: s.data.msg,
                        icon: "none"
                    });
                },
                fail: function fail(s) {
                    e.index.showToast({
                        title: "重置记账失败",
                        icon: "none"
                    });
                }
            });
        }, x = function x() {
            var o = 1 === i.value.isPush ? 0 : 1, n = 1 === o ? "成功开启" : "关闭成功";
            e.index.requestSubscribeMessage({
                tmplIds: [ "2BkLqy8kw0mkGjmBh_73RDXLve4P16gpwnl3hVfSuDY" ],
                success: function success(t) {
                    "accept" === t["2BkLqy8kw0mkGjmBh_73RDXLve4P16gpwnl3hVfSuDY"] ? s.updateUserInfo({
                        isPush: o,
                        openId: i.value.openId
                    }).then(function(s) {
                        200 === s.code && (i.value.isPush = o, e.index.showToast({
                            title: n,
                            icon: "none"
                        }));
                    }) : e.index.showToast({
                        title: "您取消了订阅消息",
                        icon: "none"
                    });
                }
            });
        }, m = function m() {
            var o = 1 === i.value.earPush ? 0 : 1, n = 1 === o ? "成功开启" : "关闭成功";
            e.index.requestSubscribeMessage({
                tmplIds: [ "-hw11A9slgtJXyh_xurAdtTsxigtw5-KswsUa6RAJVg" ],
                success: function success(t) {
                    "accept" === t["-hw11A9slgtJXyh_xurAdtTsxigtw5-KswsUa6RAJVg"] ? s.updateUserInfo({
                        earPush: o,
                        openId: i.value.openId
                    }).then(function(s) {
                        200 === s.code && (i.value.earPush = o, e.index.showToast({
                            title: n,
                            icon: "none"
                        }));
                    }) : e.index.showToast({
                        title: "您取消了订阅消息",
                        icon: "none"
                    });
                }
            });
        };
        return function(s, o) {
            return {
                a: i.value.avatar || "../../static/morentouxiang.png",
                b: e.t(i.value.nickname),
                c: e.t(null != i.value.billDays ? i.value.billDays : 0),
                d: e.t(null != i.value.billNums ? i.value.billNums : 0),
                e: e.p({
                    name: 1 === i.value.isPush ? "Close" : "Open",
                    size: "24",
                    color: 1 === i.value.isPush ? "#FF4444" : "#10B981"
                }),
                f: e.o(x),
                g: e.p({
                    name: 1 === i.value.earPush ? "Close" : "Open",
                    size: "24",
                    color: 1 === i.value.earPush ? "#FF4444" : "#10B981"
                }),
                h: e.o(m),
                i: e.p({
                    name: "Info",
                    size: "24",
                    color: "#9ca3af"
                }),
                j: e.o(l),
                k: e.p({
                    name: "Message",
                    size: "24",
                    color: "#9ca3af"
                }),
                l: e.o(r),
                m: e.p({
                    name: "Reset",
                    size: "24",
                    color: "#9ca3af"
                }),
                n: e.o(d),
                o: e.p({
                    name: "Export",
                    size: "24",
                    color: "#9ca3af"
                }),
                p: e.o(p),
                q: e.p({
                    name: "Key",
                    size: "24",
                    color: "#9ca3af"
                }),
                r: e.o(u),
                s: e.p({
                    name: "Agreement",
                    size: "24",
                    color: "#9ca3af"
                }),
                t: e.o(c)
            };
        };
    }
}), i = e._export_sfc(a, [ [ "__scopeId", "data-v-57885bac" ] ]);

wx.createPage(i);