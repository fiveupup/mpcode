var e = require("../../common/vendor.js"), s = require("../../api/bill.js"), o = require("../../store/record.js");

if (require("../../ts/request.js"), require("../../ts/global.js"), require("../../api/user.js"), 
require("../../store/user.js"), !Array) {
    e.resolveComponent("Toast")();
}

Math || (t + r + a + i + function() {
    return "../../components/Toast.js";
})();

var t = function t() {
    return "./components/Head.js";
}, r = function r() {
    return "./components/DetailViewer.js";
}, a = function a() {
    return "./components/DetailEditor.js";
}, i = function i() {
    return "./components/DelConfirm.js";
}, n = e.defineComponent({
    __name: "index",
    setup: function setup(t) {
        var r = e.ref(), a = o.useRecordStore();
        e.ref("详情");
        var i = e.ref(), n = e.ref("view"), u = function u() {
            i.value.showHandle();
        }, d = function d(e) {
            n.value = e;
        }, l = function l() {}, c = function c() {
            a.data.id && s.del({
                id: a.data.id
            }).then(function() {
                e.index.hideLoading(), r.value.show({
                    text: "删除成功",
                    type: "success"
                }), setTimeout(function() {
                    e.index.navigateBack();
                }, 1e3);
            });
        };
        return function(s, o) {
            return {
                a: e.p({
                    title: "view" === n.value ? "详情" : "编辑"
                }),
                b: e.o(u),
                c: e.o(d),
                d: e.p({
                    show: n.value
                }),
                e: e.o(d),
                f: e.p({
                    show: n.value,
                    toast: r.value
                }),
                g: e.sr(i, "1377a602-3", {
                    k: "delConfirm"
                }),
                h: e.o(l),
                i: e.o(c),
                j: e.sr(r, "1377a602-4", {
                    k: "toast"
                })
            };
        };
    }
});

wx.createPage(n);