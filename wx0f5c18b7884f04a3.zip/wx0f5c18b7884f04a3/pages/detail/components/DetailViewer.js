var e = require("../../../common/vendor.js"), r = require("../../../store/record.js"), t = require("../../../ts/global.js");

if (require("../../../ts/request.js"), require("../../../store/user.js"), require("../../../api/user.js"), 
!Array) {
    e.resolveComponent("u-icon")();
}

Math;

var a = e.defineComponent({
    __name: "DetailViewer",
    props: {
        show: {
            type: String,
            default: ""
        }
    },
    emits: [ "showDelConfirm", "changeShow" ],
    setup: function setup(a, _ref) {
        var n = _ref.emit;
        var o = r.useRecordStore();
        e.onMounted(function() {
            console.log(o.images.length);
        });
        return function(r, s) {
            return e.e({
                a: e.t(e.unref(o).data.recordTime),
                b: e.t(1 === e.unref(o).data.recordType ? "+" : "-"),
                c: e.t(e.unref(o).data.price),
                d: 1 === e.unref(o).data.recordType ? "#DD524C" : "#55B685",
                e: e.t(e.unref(o).data.remark),
                f: e.t(e.unref(o).data.typeName),
                g: e.t(e.unref(o).data.icon),
                h: e.t(e.unref(o).data.aiSay),
                i: e.f(e.unref(o).images, function(r, a, n) {
                    return {
                        a: e.o(function(a) {
                            return function(r) {
                                e.index.previewImage({
                                    urls: [ t.fileUrlReplace(r) ]
                                });
                            }(r);
                        }, a),
                        b: e.unref(t.fileUrlReplace)(r),
                        c: a
                    };
                }),
                j: e.n("absolute top-0 left-0 w-full h-full animate-duration-300"),
                k: e.n("bg-gray-100 bg-opacity-50 aspect-square rounded-md flex justify-center items-center cursor-default select-none relative overflow-hidden"),
                l: e.n("grid grid-cols-3 gap-20rpx"),
                m: e.unref(o).images.length < 1
            }, (e.unref(o).images.length, {}), {
                n: e.p({
                    name: "trash",
                    size: "15",
                    color: "#DD524C"
                }),
                o: e.o(function(e) {
                    return n("showDelConfirm");
                }),
                p: e.p({
                    name: "edit-pen",
                    size: "15",
                    color: "#394150"
                }),
                q: e.o(function(e) {
                    return n("changeShow", "edit");
                }),
                r: "view" === a.show ? "translateX(0)" : "translateX(calc(-100% - 40rpx))",
                s: "view" === a.show ? "1" : "0"
            });
        };
    }
});

wx.createComponent(a);