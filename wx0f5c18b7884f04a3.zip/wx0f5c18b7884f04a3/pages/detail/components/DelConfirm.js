var e = require("../../../common/vendor.js");

if (!Array) {
    e.resolveComponent("u-icon")();
}

Math;

var n = e.defineComponent({
    __name: "DelConfirm",
    emits: [ "cancel", "confirm" ],
    setup: function setup(n, _ref) {
        var o = _ref.expose, r = _ref.emit;
        var t = e.ref(!1);
        var c = function c() {
            t.value = !1, r("cancel");
        }, a = function a() {
            t.value = !1, r("confirm");
        };
        return o({
            showHandle: function showHandle() {
                t.value = !0;
            }
        }), function(n, o) {
            return {
                a: e.p({
                    name: "info-circle-fill",
                    size: "14",
                    color: "#fb923c"
                }),
                b: e.o(c),
                c: e.o(a),
                d: e.o(function() {}),
                e: e.unref(t) ? "translateY(0)" : "translateY(10%)",
                f: e.unref(t) ? "1" : "0",
                g: e.o(c),
                h: e.unref(t) ? "1" : "0",
                i: e.unref(t) ? "auto" : "none"
            };
        };
    }
}), o = e._export_sfc(n, [ [ "__scopeId", "data-v-89f1b7be" ] ]);

wx.createComponent(o);