var e = require("../../../common/vendor.js"), a = require("../../../store/record.js"), t = require("../../../api/bill.js"), n = require("../../../ts/request.js"), i = require("../../../ts/global.js");

if (require("../../../store/user.js"), require("../../../api/user.js"), !Array) {
    e.resolveComponent("u-icon")();
}

Math;

var r = e.defineComponent({
    __name: "DetailEditor",
    props: {
        show: {
            type: String,
            default: ""
        },
        toast: {
            type: Object,
            required: !0
        }
    },
    emits: [ "changeShow" ],
    setup: function setup(r, _ref) {
        var s = _ref.emit;
        var u = r, l = a.useRecordStore();
        e.watch(function() {
            return u.show;
        }, function(e) {
            "edit" === e && (d.value = l.images.length > 0 ? l.images.map(function(e) {
                return {
                    url: e,
                    status: "finish"
                };
            }) : [], d.value.length < 3 && d.value.push(o));
        });
        var o = {
            url: "",
            status: "wait"
        };
        var d = e.ref([ o ]);
        var m = function m() {
            var e = d.value.filter(function(e) {
                return "finish" === e.status;
            }).map(function(e) {
                return e.url;
            });
            l.data.images = JSON.stringify(e), t.update(l.data).then(function() {
                u.toast.show({
                    text: "保存成功",
                    type: "success"
                }), s("changeShow", "view");
            });
        };
        return function(a, t) {
            return {
                a: e.unref(l).data.price,
                b: e.o(function(a) {
                    return e.unref(l).data.price = a.detail.value;
                }),
                c: e.unref(l).data.remark,
                d: e.o(function(a) {
                    return e.unref(l).data.remark = a.detail.value;
                }),
                e: e.unref(l).data.typeName,
                f: e.o(function(a) {
                    return e.unref(l).data.typeName = a.detail.value;
                }),
                g: e.unref(l).data.icon,
                h: e.o(function(a) {
                    return e.unref(l).data.icon = a.detail.value;
                }),
                i: e.unref(l).data.aiSay,
                j: e.o(function(a) {
                    return e.unref(l).data.aiSay = a.detail.value;
                }),
                k: e.f(e.unref(d), function(a, t, r) {
                    return e.e({
                        a: "2abdf847-0-" + r,
                        b: e.n("wait" != a.status && "animate__animated animate__fadeOutDown"),
                        c: "2abdf847-1-" + r,
                        d: e.n("run" === a.status ? "animate__animated animate__fadeInDown block" : "animate__animated animate__fadeOutUp hidden"),
                        e: a.url
                    }, a.url ? {
                        f: e.o(function(t) {
                            return n = a.url, void e.index.previewImage({
                                urls: [ i.fileUrlReplace(n) ]
                            });
                            var n;
                        }, t),
                        g: e.unref(i.fileUrlReplace)(a.url)
                    } : {}, {
                        h: "2abdf847-2-" + r,
                        i: e.o(function(e) {
                            return function(e) {
                                d.value.splice(e, 1), d.value.length < 3 && !d.value.find(function(e) {
                                    return "wait" === e.status;
                                }) && d.value.push(o);
                            }(t);
                        }, t),
                        j: e.n("finish" === a.status ? "animate__animated animate__fadeIn block" : "animate__animated animate__fadeOut hidden"),
                        k: t,
                        l: e.o(function(t) {
                            return function(a) {
                                e.index.chooseImage({
                                    count: 1,
                                    success: function success(t) {
                                        console.log(t), a.status = "run", e.index.uploadFile({
                                            url: n.host + "/file/upload",
                                            filePath: t.tempFilePaths[0],
                                            name: "file",
                                            header: {
                                                Authorization: i.getToken()
                                            },
                                            success: function success(e) {
                                                var t = JSON.parse(e.data);
                                                a.status = "finish", a.url = t.msg, d.value.length < 3 && d.value.push({
                                                    url: "",
                                                    status: "wait"
                                                });
                                            }
                                        });
                                    }
                                });
                            }(a);
                        }, t)
                    });
                }),
                l: e.p({
                    name: "plus",
                    size: "16",
                    color: "#d1d5db"
                }),
                m: e.n("animate-duration-600 absolute"),
                n: e.p({
                    name: "arrow-upward",
                    size: "16",
                    color: "#26B981"
                }),
                o: e.n("animate-duration-600 absolute"),
                p: e.p({
                    name: "close",
                    size: "13",
                    color: "white"
                }),
                q: e.n("absolute top-0 left-0 w-full h-full animate-duration-300"),
                r: e.n("bg-gray-100 bg-opacity-50 aspect-square rounded-md flex justify-center items-center cursor-default select-none relative overflow-hidden"),
                s: e.n("animate__animated animate__fadeIn animate-duration-500"),
                t: e.o(m),
                v: e.o(function(e) {
                    return s("changeShow", "view");
                }),
                w: "edit" === r.show ? "translateX(0)" : "translateX(calc(100% + 40rpx))",
                x: "edit" === r.show ? "1" : "0"
            };
        };
    }
});

wx.createComponent(r);