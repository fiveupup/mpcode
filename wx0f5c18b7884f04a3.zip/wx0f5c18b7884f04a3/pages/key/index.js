var _regeneratorRuntime2 = require("../../@babel/runtime/helpers/regeneratorRuntime");

var _asyncToGenerator2 = require("../../@babel/runtime/helpers/asyncToGenerator");

var e = require("../../common/vendor.js"), t = require("../../ts/global.js"), a = require("../../ts/request.js"), n = require("../../api/user.js");

require("../../store/user.js"), Math || o();

var o = function o() {
    return "./components/Head.js";
}, s = e.defineComponent({
    __name: "index",
    setup: function setup(o) {
        e.ref();
        var s = e.ref([ {
            id: "1",
            name: "授权码"
        }, {
            id: "2",
            name: "密 码"
        } ]), i = e.ref([]), d = e.ref(""), r = e.ref({});
        e.onShow(/* */ _asyncToGenerator2(/* */ _regeneratorRuntime2().mark(function _callee() {
            return _regeneratorRuntime2().wrap(function _callee$(_context) {
                while (1) switch (_context.prev = _context.next) {
                  case 0:
                    r.value = e.index.getStorageSync("user"), n.UserInfo({
                        openId: r.value.openId
                    }).then(function(e) {
                        t.saveLoginRes(e.data), r.value = e.data;
                    });

                  case 1:
                  case "end":
                    return _context.stop();
                }
            }, _callee);
        }))), e.onMounted(function() {
            u();
        });
        var u = function u() {
            e.index.request({
                url: "".concat(a.host, "/key/list?userId=") + r.value.openId,
                method: "GET",
                header: {
                    "content-type": "application/json",
                    Authorization: t.getToken()
                },
                success: function success(t) {
                    200 === t.data.code ? i.value = t.data.data : e.index.showToast({
                        title: t.data.message,
                        icon: "none"
                    });
                },
                fail: function fail() {
                    e.index.showToast({
                        title: "请求失败，请稍后再试",
                        icon: "none"
                    });
                }
            });
        }, c = function c() {
            if (null === d.value || "" === d.value) return void e.index.showToast({
                title: "请选择卡密类型",
                icon: "none",
                duration: 2e3
            });
            var n = d.value;
            e.index.request({
                url: "".concat(a.host, "/key/save"),
                method: "POST",
                header: {
                    "content-type": "application/json",
                    Authorization: t.getToken()
                },
                data: {
                    type: n,
                    userId: r.value.openId,
                    name: r.value.nickname
                },
                success: function success(t) {
                    200 === t.data.code ? (i.value.unshift({
                        name: t.data.data.name,
                        createTime: t.data.data.createTime,
                        keyStr: t.data.data.keyStr
                    }), e.index.showToast({
                        title: "领取成功",
                        icon: "success"
                    })) : e.index.showToast({
                        title: t.data.msg,
                        icon: "none"
                    });
                }
            });
        };
        return function(t, a) {
            return e.e({
                a: e.f(s.value, function(t, a, n) {
                    return e.e({
                        a: e.t(t.name),
                        b: d.value === t.id
                    }, (d.value, t.id, {}), {
                        c: d.value === t.id ? 1 : "",
                        d: t.id,
                        e: e.o(function(e) {
                            return a = t.id, void (d.value = a);
                            var a;
                        }, t.id)
                    });
                }),
                b: e.o(c),
                c: e.f(i.value, function(t, a, n) {
                    return e.e({
                        a: e.t(t.name),
                        b: e.t(1 === t.type ? "授权码" : "密码"),
                        c: e.t(t.createTime),
                        d: t.keyStr
                    }, t.keyStr ? {
                        e: e.t(t.keyStr)
                    } : {}, {
                        f: e.o(function(a) {
                            return n = t.keyStr, void e.index.setClipboardData({
                                data: n,
                                success: function success() {
                                    e.index.showToast({
                                        title: "复制成功",
                                        icon: "success",
                                        duration: 2e3
                                    });
                                },
                                fail: function fail() {
                                    e.index.showToast({
                                        title: "复制失败",
                                        icon: "none",
                                        duration: 2e3
                                    });
                                }
                            });
                            var n;
                        }, a),
                        g: a
                    });
                }),
                d: 0 === i.value.length
            }, (i.value.length, {}));
        };
    }
});

wx.createPage(s);