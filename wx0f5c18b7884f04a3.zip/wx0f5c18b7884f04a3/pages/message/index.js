var _regeneratorRuntime2 = require("../../@babel/runtime/helpers/regeneratorRuntime");

var _asyncToGenerator2 = require("../../@babel/runtime/helpers/asyncToGenerator");

var e = require("../../common/vendor.js"), a = require("../../ts/global.js"), t = require("../../ts/request.js"), n = require("../../api/user.js");

require("../../store/user.js"), Math || o();

var o = function o() {
    return "./components/Head.js";
}, s = e.defineComponent({
    __name: "index",
    setup: function setup(o) {
        var s = e.ref("");
        var i = 1;
        e.ref("#10b981");
        var r = e.ref({});
        e.onShow(/* */ _asyncToGenerator2(/* */ _regeneratorRuntime2().mark(function _callee() {
            return _regeneratorRuntime2().wrap(function _callee$(_context) {
                while (1) switch (_context.prev = _context.next) {
                  case 0:
                    r.value = e.index.getStorageSync("user"), n.UserInfo({
                        openId: r.value.openId
                    }).then(function(e) {
                        a.saveLoginRes(e.data), r.value = e.data;
                    });

                  case 1:
                  case "end":
                    return _context.stop();
                }
            }, _callee);
        })));
        var c = e.ref([]), u = new Date().toLocaleString("zh-CN", {
            year: "numeric",
            month: "numeric",
            day: "numeric",
            hour: "numeric",
            minute: "numeric",
            second: "numeric",
            hour12: !1
        }).replace(/上午|下午/g, "").replace(/\//g, "-"), d = function d() {
            var n = s.value.trim();
            n ? e.index.request({
                url: t.host + "/message/create",
                method: "POST",
                header: {
                    "content-type": "application/json",
                    Authorization: a.getToken()
                },
                data: {
                    content: n,
                    nickname: r.value.nickname,
                    avatar: r.value.avatar,
                    userId: r.value.openId
                },
                success: function success(a) {
                    200 === a.data.code ? (e.index.showToast({
                        icon: "success",
                        title: "留言成功"
                    }), c.value.unshift({
                        nickname: r.value.nickname,
                        avatar: r.value.avatar,
                        content: n,
                        createTime: u
                    }), s.value = "") : e.index.showToast({
                        title: a.data.data,
                        icon: "none"
                    });
                }
            }) : e.index.showToast({
                title: "请输入内容后再提交反馈",
                icon: "none",
                duration: 2e3
            });
        }, l = function l() {
            e.index.request({
                url: t.host + "/message/list",
                method: "GET",
                header: {
                    Authorization: a.getToken()
                },
                data: {
                    page: i + 1
                },
                success: function success(a) {
                    a.data.data.records.length > 0 ? (c.value = c.value.concat(a.data.data.records), 
                    i++) : e.index.showToast({
                        title: "已加载全部数据",
                        icon: "none"
                    });
                },
                fail: function fail() {},
                complete: function complete() {}
            });
        };
        e.index.request({
            url: t.host + "/message/list",
            method: "GET",
            header: {
                Authorization: a.getToken()
            },
            data: {
                page: 1
            },
            success: function success(e) {
                c.value = e.data.data.records;
            },
            fail: function fail() {},
            complete: function complete() {}
        });
        return function(n, o) {
            return {
                a: s.value,
                b: e.o(function(e) {
                    return s.value = e.detail.value;
                }),
                c: e.o(d),
                d: e.o(function() {}),
                e: e.f(c.value, function(n, o, s) {
                    return e.e({
                        a: n.avatar,
                        b: e.t(n.nickname || "匿名"),
                        c: e.t(n.createTime),
                        d: e.t(n.content),
                        e: n.userId === r.value.openId
                    }, n.userId === r.value.openId ? {
                        f: e.o(function(n) {
                            return function(n) {
                                console.log(n);
                                var o = c.value[n];
                                e.index.request({
                                    url: t.host + "/message/delete",
                                    method: "DELETE",
                                    header: {
                                        Authorization: a.getToken(),
                                        "content-type": "application/json"
                                    },
                                    data: {
                                        messageId: o.messageId
                                    },
                                    success: function success(a) {
                                        200 === a.data.code ? (e.index.showToast({
                                            title: "留言删除成功",
                                            icon: "success"
                                        }), c.value.splice(n, 1)) : e.index.showToast({
                                            title: "删除失败，请稍后再试",
                                            icon: "none"
                                        });
                                    },
                                    fail: function fail() {
                                        e.index.showToast({
                                            title: "网络请求失败",
                                            icon: "none"
                                        });
                                    }
                                });
                            }(o);
                        }, o)
                    } : {}, {
                        g: o
                    });
                }),
                f: e.o(l)
            };
        };
    }
});

wx.createPage(s);