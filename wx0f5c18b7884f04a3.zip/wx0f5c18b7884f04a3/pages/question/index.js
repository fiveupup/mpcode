var e = require("../../common/vendor.js");

if (!Array) {
    e.resolveComponent("u-icon")();
}

Math || (o + function() {
    return "../../node-modules/uview-plus/components/u-icon/u-icon.js";
})();

var o = function o() {
    return "./components/Head.js";
}, n = e.defineComponent({
    __name: "index",
    setup: function setup(o) {
        return function(o, n) {
            return {
                a: e.p({
                    name: "checkbox-mark",
                    size: "12",
                    color: "white"
                }),
                b: e.p({
                    name: "bookmark-fill",
                    size: "12",
                    color: "white"
                }),
                c: e.p({
                    name: "bookmark-fill",
                    size: "12",
                    color: "white"
                })
            };
        };
    }
});

wx.createPage(n);