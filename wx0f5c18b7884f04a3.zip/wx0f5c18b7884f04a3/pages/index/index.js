var _regeneratorRuntime2 = require("../../@babel/runtime/helpers/regeneratorRuntime");

var _asyncToGenerator2 = require("../../@babel/runtime/helpers/asyncToGenerator");

var e = require("../../common/vendor.js"), o = require("../../store/setting.js"), t = require("../../ts/global.js"), n = require("../../api/bill.js"), a = require("../../store/record.js"), s = require("../../ts/request.js");

if (require("../../api/user.js"), require("../../store/user.js"), !Array) {
    (e.resolveComponent("u-icon") + e.resolveComponent("Loading") + e.resolveComponent("MonthSelector") + e.resolveComponent("Toast"))();
}

Math || (r + i + function() {
    return "../../node-modules/uview-plus/components/u-icon/u-icon.js";
} + l + function() {
    return "../../components/Loading.js";
} + function() {
    return "../../components/MonthSelector.js";
} + u + function() {
    return "../../components/Toast.js";
})();

var r = function r() {
    return "./components/Head.js";
}, i = function i() {
    return "./components/Today.js";
}, l = function l() {
    return "./components/HistoryItem.js";
}, u = function u() {
    return "./components/Recording.js";
}, d = e.defineComponent({
    __name: "index",
    setup: function setup(r) {
        var i = e.index.getRecorderManager();
        e.ref("");
        var l = e.ref(!1), u = e.ref(""), d = e.ref(!1), c = e.ref(0), m = e.ref();
        a.useRecordStore();
        var p = o.useSettingStore();
        var h = e.ref(!0), v = e.ref(e.dayjs().format("YYYY-MM"));
        var f = e.ref(!1);
        var g = e.ref({}), y = e.ref({
            in: 0,
            out: 0,
            withLastDay: 0
        });
        e.onMounted(/* */ _asyncToGenerator2(/* */ _regeneratorRuntime2().mark(function _callee() {
            return _regeneratorRuntime2().wrap(function _callee$(_context) {
                while (1) switch (_context.prev = _context.next) {
                  case 0:
                    setTimeout(function() {
                        h.value = !1;
                    }, 1e3);

                  case 1:
                  case "end":
                    return _context.stop();
                }
            }, _callee);
        }))), e.onShow(/* */ _asyncToGenerator2(/* */ _regeneratorRuntime2().mark(function _callee2() {
            return _regeneratorRuntime2().wrap(function _callee2$(_context2) {
                while (1) switch (_context2.prev = _context2.next) {
                  case 0:
                    _context2.t0 = t.loginVerify();
                    if (_context2.t0) {
                        _context2.next = 4;
                        break;
                    }
                    _context2.next = 4;
                    return t.loginHandle();

                  case 4:
                    x();

                  case 5:
                  case "end":
                    return _context2.stop();
                }
            }, _callee2);
        })));
        var x = function x() {
            w(), j();
        }, j = function j() {
            n.todayData().then(function(e) {
                y.value = e.data;
            }).catch(function() {
                m.value.show({
                    text: "连接超时，请稍后再试",
                    type: "error"
                });
            });
        }, w = function w() {
            n.listForMonth({
                month: v.value
            }).then(function(e) {
                g.value = e.data;
            }).catch(function() {
                m.value.show({
                    text: "连接超时，请稍后再试",
                    type: "error"
                });
            });
        };
        e.onShareAppMessage(function() {
            return {
                title: "🐱 大巫记账",
                path: "/pages/index/index",
                imageUrl: "https://img2.imgtp.com/2024/04/01/6ftpfAv2.jpeg"
            };
        }), e.onShareTimeline(function() {
            return {
                title: "🐱 大巫记账",
                path: "/pages/index/index",
                imageUrl: "https://img2.imgtp.com/2024/04/01/6ftpfAv2.jpeg"
            };
        });
        var T = e.ref(), S = function S() {
            T.value.showHandle(v.value);
        }, M = function M(e) {
            var o = "".concat(e.year, "-").concat(e.month < 10 ? "0" + e.month : e.month);
            o !== v.value && (v.value = o, w());
        }, q = e.ref(), F = function F() {
            q.value.showHandle();
        }, L = function L(o) {
            e.index.showLoading(), n.save(o).then(function() {
                return x();
            }).then(function() {
                e.index.hideLoading();
            }).catch(function(o) {
                e.index.hideLoading(), e.index.showToast({
                    title: "和某不知名服务间的通信发生错误，请重试 🥲",
                    icon: "none"
                });
            });
        }, A = function A() {
            l.value = !0, i.start({
                format: "mp3"
            }), c.value = setTimeout(function() {
                f.value = !0;
            }, 2e3);
        }, Y = function Y() {
            clearTimeout(c.value), l.value = !1, i.stop();
        };
        i.onStop(/* */ function() {
            var _ref3 = _asyncToGenerator2(/* */ _regeneratorRuntime2().mark(function _callee3(o) {
                var n;
                return _regeneratorRuntime2().wrap(function _callee3$(_context3) {
                    while (1) switch (_context3.prev = _context3.next) {
                      case 0:
                        if (f.value) {
                            _context3.next = 2;
                            break;
                        }
                        return _context3.abrupt("return", void e.index.showToast({
                            title: "请至少录音2秒",
                            icon: "none"
                        }));

                      case 2:
                        n = o.tempFilePath;
                        e.index.uploadFile({
                            url: s.host + "/file/uploadToText",
                            filePath: n,
                            name: "file",
                            header: {
                                Authorization: t.getToken()
                            },
                            success: function success(e) {
                                var o = JSON.parse(e.data);
                                200 === o.code ? (d.value = !0, null == o.msg ? u.value = "识别失败，请重试!" : u.value = o.msg) : (d.value = !0, 
                                u.value = "识别失败，请重试!");
                            },
                            fail: function fail(e) {
                                console.error("上传接口调用失败:", e);
                            }
                        });

                      case 4:
                      case "end":
                        return _context3.stop();
                    }
                }, _callee3);
            }));
            return function(_x) {
                return _ref3.apply(this, arguments);
            };
        }());
        var H = function H() {
            d.value = !1;
        }, k = function k() {
            d.value = !1;
            var o = {
                day: e.dayjs().format("YYYY-MM-DD"),
                chat: u.value,
                hasAiSay: !1,
                images: []
            };
            b(o);
        }, b = /* */ function() {
            var _ref4 = _asyncToGenerator2(/* */ _regeneratorRuntime2().mark(function _callee4(o) {
                return _regeneratorRuntime2().wrap(function _callee4$(_context4) {
                    while (1) switch (_context4.prev = _context4.next) {
                      case 0:
                        _context4.prev = 0;
                        e.index.showLoading();
                        _context4.next = 4;
                        return n.save(o);

                      case 4:
                        _context4.t0 = _context4.sent.code;
                        if (!(200 === _context4.t0)) {
                            _context4.next = 9;
                            break;
                        }
                        x();
                        _context4.next = 10;
                        break;

                      case 9:
                        e.index.showToast({
                            title: "提交失败，请重试",
                            icon: "none"
                        });

                      case 10:
                        _context4.next = 15;
                        break;

                      case 12:
                        _context4.prev = 12;
                        _context4.t1 = _context4["catch"](0);
                        e.index.showToast({
                            title: "提交出错，请检查网络",
                            icon: "none"
                        });

                      case 15:
                        _context4.prev = 15;
                        e.index.hideLoading();
                        return _context4.finish(15);

                      case 18:
                      case "end":
                        return _context4.stop();
                    }
                }, _callee4, null, [ [ 0, 12, 15, 18 ] ]);
            }));
            return function b(_x2) {
                return _ref4.apply(this, arguments);
            };
        }();
        return function(o, t) {
            return e.e({
                a: e.p({
                    today: e.unref(y)
                }),
                b: e.t(e.unref(v)),
                c: e.o(S),
                d: e.p({
                    name: "arrow-down-fill",
                    color: "#FFFFFF80",
                    size: "10"
                }),
                e: e.t(e.unref(g).out),
                f: e.t(e.unref(g).in),
                g: e.f(e.unref(g).days, function(o, t, n) {
                    return {
                        a: t,
                        b: "150d7252-3-" + n,
                        c: e.p({
                            day: o
                        })
                    };
                }),
                h: e.unref(p).isAppleAndHasLine ? "env(safe-area-inset-bottom)" : "20rpx",
                i: e.p({
                    show: e.unref(h)
                }),
                j: l.value ? 1 : "",
                k: e.o(A),
                l: e.o(Y),
                m: l.value
            }, (l.value, {}), {
                n: d.value
            }, d.value ? {
                o: u.value,
                p: e.o(function(e) {
                    return u.value = e.detail.value;
                }),
                q: e.o(H),
                r: e.o(k)
            } : {}, {
                s: e.p({
                    name: "attach",
                    size: "14",
                    color: "#55B685"
                }),
                t: e.o(F),
                v: e.sr(T, "150d7252-6", {
                    k: "monthSelector"
                }),
                w: e.o(M),
                x: e.sr(q, "150d7252-7", {
                    k: "recording"
                }),
                y: e.o(L),
                z: e.sr(m, "150d7252-8", {
                    k: "toast"
                })
            });
        };
    }
});

d.__runtimeHooks = 6, wx.createPage(d);