var e = require("../../../common/vendor.js");

if (!Array) {
    e.resolveComponent("HeadBar")();
}

Math;

var t = e.defineComponent({
    __name: "Head",
    setup: function setup(t) {
        var a = [ "💡 记账是理财的第一步", "📝 每一笔开支都是一次选择", "💰 理智消费，从记账开始", "🌟 记账让生活更有计划", "📊 理财小贴士：坚持记账有助于财务规划", "💡 记账不仅是记录，更是一种态度", "📈 记账，让财富增长更可控", "💸 理智消费，理财从现在开始", "🔍 记账，发现生活中的财富密码", "💡 精打细算，财富由此开始", "📝 记账，让生活更精彩", "💰 善待每一笔消费，它代表着你的选择", "🌟 每一次理财决策都值得记录", "📊 记账，让未来的财务规划更清晰", "💡 财富管理从小事做起，从记账开始", "📈 理财不只是数字游戏，更是人生智慧", "💸 懂得理财，才能更好地享受生活", "🔍 记账，让财务状况一目了然" ], n = e.ref(!0), l = e.ref(0), r = e.ref(a[Math.floor(Math.random() * a.length)]);
        return e.watch(n, function(e) {
            e && (r.value = "", l.value = (l.value + 1) % a.length);
        }), setInterval(function() {
            n.value && r.value.length < a[l.value].length && (r.value = a[l.value].substring(0, r.value.length + 1));
        }, 100), function(t, a) {
            return {
                a: e.t(r.value),
                b: e.p({
                    color: "#FFFFFF00"
                })
            };
        };
    }
});

wx.createComponent(t);