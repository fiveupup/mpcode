var e = require("../../../common/vendor.js"), a = require("../../../store/setting.js"), t = require("../../../store/userOptions.js"), n = require("../../../ts/request.js"), o = require("../../../ts/global.js");

if (require("../../../store/user.js"), require("../../../api/user.js"), !Array) {
    (e.resolveComponent("u-icon") + e.resolveComponent("u-datetime-picker") + e.resolveComponent("u-switch") + e.resolveComponent("Toast"))();
}

Math || (function() {
    return "../../../node-modules/uview-plus/components/u-icon/u-icon.js";
} + function() {
    return "../../../node-modules/uview-plus/components/u-datetime-picker/u-datetime-picker.js";
} + function() {
    return "../../../node-modules/uview-plus/components/u-switch/u-switch.js";
} + function() {
    return "../../../components/Toast.js";
})();

var i = e.defineComponent({
    __name: "Recording",
    emits: [ "confirm" ],
    setup: function setup(i, _ref) {
        var s = _ref.expose, u = _ref.emit;
        var r = a.useSettingStore(), l = t.userOptionsStore(), d = e.ref();
        var f = e.ref(!1), m = e.ref(!1), c = e.dayjs().valueOf(), p = e.ref(e.dayjs().valueOf()), v = e.ref([ {
            url: "",
            status: "wait"
        } ]);
        var h = e.ref({
            day: "",
            chat: "",
            images: []
        });
        var g = function g() {
            m.value ? m.value = !1 : (p.value = e.dayjs().valueOf(), f.value = !1, h.value.chat = "");
        };
        var w = e.ref(0);
        var _ = function _(e) {
            w.value = e.detail.height - 20;
        }, y = function y() {
            w.value = 0;
        }, j = function j() {
            h.value.chat ? (h.value.day = e.dayjs(p.value).format("YYYY-MM-DD"), h.value.images = v.value.filter(function(e) {
                return "finish" === e.status;
            }).map(function(e) {
                return e.url;
            }), h.value.hasAiSay = l.hasAiSay, u("confirm", h.value), g()) : d.value.show({
                type: "error",
                text: "请填写记账内容"
            });
        }, x = function x() {
            e.index.navigateTo({
                url: "/pages/agreement/index"
            });
        };
        return s({
            showHandle: function showHandle() {
                f.value = !0, v.value = [ {
                    url: "",
                    status: "wait"
                } ];
            }
        }), function(a, t) {
            return {
                a: e.p({
                    name: "close",
                    color: "#64748b"
                }),
                b: e.o(g),
                c: e.t(e.unref(e.dayjs)(e.unref(p)).format("YYYY-MM-DD")),
                d: e.p({
                    name: "arrow-down-fill",
                    color: "#00000020",
                    size: "10"
                }),
                e: e.o(function(a) {
                    return e.isRef(m) ? m.value = !0 : m = !0;
                }),
                f: e.o(function(a) {
                    return e.isRef(m) ? m.value = !1 : m = !1;
                }),
                g: e.o(function(a) {
                    return e.isRef(m) ? m.value = !1 : m = !1;
                }),
                h: e.o(function(a) {
                    return e.isRef(p) ? p.value = a : p = a;
                }),
                i: e.p({
                    show: e.unref(m),
                    maxDate: e.unref(c),
                    mode: "date",
                    itemHeight: 35,
                    confirmColor: "#55B685",
                    modelValue: e.unref(p)
                }),
                j: e.o(function(a) {
                    return e.unref(l).hasAiSay = a;
                }),
                k: e.p({
                    size: "15",
                    space: "2",
                    activeColor: "#f9ae3d",
                    inactiveColor: "rgb(230, 230, 230)",
                    modelValue: e.unref(l).hasAiSay
                }),
                l: e.o(_),
                m: e.o(y),
                n: e.unref(h).chat,
                o: e.o(function(a) {
                    return e.unref(h).chat = a.detail.value;
                }),
                p: e.o(x),
                q: e.f(e.unref(v), function(a, t, i) {
                    return e.e({
                        a: "53153ca3-4-" + i,
                        b: e.n("wait" != a.status && "animate__animated animate__fadeOutDown"),
                        c: "53153ca3-5-" + i,
                        d: e.n("run" === a.status ? "animate__animated animate__fadeInDown block" : "animate__animated animate__fadeOutUp hidden"),
                        e: a.url
                    }, a.url ? {
                        f: e.o(function(t) {
                            return n = a.url, void e.index.previewImage({
                                urls: [ o.fileUrlReplace(n) ]
                            });
                            var n;
                        }, t),
                        g: e.unref(o.fileUrlReplace)(a.url)
                    } : {}, {
                        h: "53153ca3-6-" + i,
                        i: e.o(function(e) {
                            return function(e) {
                                v.value.splice(e, 1), v.value.length < 3 && !v.value.find(function(e) {
                                    return "wait" === e.status;
                                }) && v.value.push({
                                    url: "",
                                    status: "wait"
                                });
                            }(t);
                        }, t),
                        j: e.n("finish" === a.status ? "animate__animated animate__fadeIn block" : "animate__animated animate__fadeOut hidden"),
                        k: t,
                        l: e.o(function(t) {
                            return function(a) {
                                e.index.chooseImage({
                                    count: 1,
                                    success: function success(t) {
                                        console.log(t), a.status = "run", e.index.uploadFile({
                                            url: n.host + "/file/upload",
                                            filePath: t.tempFilePaths[0],
                                            name: "file",
                                            header: {
                                                Authorization: o.getToken()
                                            },
                                            success: function success(e) {
                                                var t = JSON.parse(e.data);
                                                a.status = "finish", a.url = t.msg, v.value.length < 3 && v.value.push({
                                                    url: "",
                                                    status: "wait"
                                                });
                                            }
                                        });
                                    }
                                });
                            }(a);
                        }, t)
                    });
                }),
                r: e.p({
                    name: "plus",
                    size: "16",
                    color: "#d1d5db"
                }),
                s: e.n("animate-duration-600 absolute"),
                t: e.p({
                    name: "arrow-upward",
                    size: "16",
                    color: "#26B981"
                }),
                v: e.n("animate-duration-600 absolute"),
                w: e.p({
                    name: "close",
                    size: "13",
                    color: "white"
                }),
                x: e.n("absolute top-0 left-0 w-full h-full animate-duration-300"),
                y: e.n("bg-gray-200 bg-opacity-50 aspect-square rounded-md flex justify-center items-center cursor-default select-none relative overflow-hidden"),
                z: e.n("animate__animated animate__fadeInLeft animate-duration-500"),
                A: e.o(j),
                B: e.n("bg-gray-100 flex flex-col pt-20rpx transition-all duration-300"),
                C: e.unref(r).isAppleAndHasLine ? "env(safe-area-inset-bottom)" : "20rpx",
                D: e.unref(f) ? "translateY(0)" : "translateY(100%)",
                E: e.o(function(a) {
                    return e.isRef(m) ? m.value = !1 : m = !1;
                }),
                F: e.n("recording-view fixed flex flex-col justify-end top-0 left-0 right-0 bg-black bg-opacity-50 z-2 transition-all duration-300"),
                G: e.n("opaciry-0 pointer-events-none"),
                H: e.unref(f) ? "1" : "0",
                I: e.unref(f) ? "auto" : "none",
                J: e.unref(w) > 0 ? "".concat(e.unref(w), "rpx") : "0",
                K: e.o(g),
                L: e.sr(d, "53153ca3-7", {
                    k: "toast"
                })
            };
        };
    }
});

wx.createComponent(i);