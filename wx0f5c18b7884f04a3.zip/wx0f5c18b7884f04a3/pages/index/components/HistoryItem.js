var e = require("../../../common/vendor.js"), r = require("../../../store/record.js"), t = require("../../../ts/global.js"), o = require("../../../api/bill.js");

if (require("../../../ts/request.js"), require("../../../store/user.js"), require("../../../api/user.js"), 
!Array) {
    e.resolveComponent("u-icon")();
}

Math;

var s = e.defineComponent({
    __name: "HistoryItem",
    props: {
        day: {
            type: Object,
            default: function _default() {
                return [];
            }
        }
    },
    setup: function setup(s) {
        var a = s, i = r.useRecordStore();
        var n = !1, l = null;
        var d = function d() {
            clearTimeout(l);
        }, c = function c(r, t) {
            console.log(r.id), e.index.showModal({
                title: "删除",
                content: "确定要删除这条记录吗？",
                success: function success(e) {
                    var s;
                    e.confirm && (s = r.id, o.del({
                        id: s
                    })).then(function() {
                        a.day.details.splice(t, 1);
                    }).catch(function(e) {
                        console.log("请求失败：" + e.message);
                    });
                }
            });
        };
        return function(r, o) {
            return {
                a: e.t(s.day.day),
                b: e.t(s.day.out),
                c: e.t(s.day.in),
                d: e.f(s.day.details, function(o, a, u) {
                    return e.e({
                        a: e.t(e.unref(e.dayjs)(o.recordTime).format("HH:mm")),
                        b: e.t(o.icon),
                        c: e.t(o.remark),
                        d: e.t(o.aiSay || " -"),
                        e: e.f(JSON.parse(o.images) || [], function(r, o, s) {
                            return {
                                a: e.unref(t.fileUrlReplace)(r),
                                b: e.o(function(o) {
                                    return function(r) {
                                        e.index.previewImage({
                                            urls: [ t.fileUrlReplace(r) ]
                                        });
                                    }(r);
                                }, o),
                                c: o
                            };
                        }),
                        f: e.t(1 === o.recordType ? "+" : "-"),
                        g: e.t(o.price),
                        h: a < s.day.details.length - 1
                    }, (s.day.details.length, {}), r.showDelConfirm ? {
                        i: "3d76e20e-0-" + u,
                        j: e.p({
                            name: "trash",
                            size: "15",
                            color: "#DD524C"
                        }),
                        k: e.o(function(e) {
                            return c(o, a);
                        }, a)
                    } : {}, {
                        l: a,
                        m: e.o(function(r) {
                            return function(r) {
                                n || (i.data = r, e.index.navigateTo({
                                    url: "/pages/detail/index"
                                })), n = !1;
                            }(o);
                        }, a),
                        n: e.o(function(e) {
                            return function(e, r) {
                                n = !1, l = setTimeout(function() {
                                    n = !0, c(e, r);
                                }, 500);
                            }(o, a);
                        }, a),
                        o: e.o(d, a)
                    });
                }),
                e: r.showDelConfirm
            };
        };
    }
});

wx.createComponent(s);