var e = require("../../../common/vendor.js"), a = require("../../../ts/request.js");

require("../../../ts/global.js"), require("../../../api/user.js"), require("../../../store/user.js");

var t = e.defineComponent({
    __name: "Today",
    props: {
        today: {
            type: Object,
            required: !0
        }
    },
    setup: function setup(t) {
        var s = e.ref(""), r = e.ref(""), c = e.ref(""), u = e.ref(""), o = function o(e) {
            switch (e) {
              case "晴":
                return "☀";

              case "少云":
              case "晴间多云":
              case "阴":
                return "☁️";

              case "阵雨":
              case "雷阵雨":
              case "雷阵雨并伴有冰雹":
              case "小雨":
              case "中雨":
              case "大雨":
              case "大雪-暴雪":
                return "🌧️";

              case "暴雨":
              case "大暴雨":
              case "特大暴雨":
                return "⛈️";

              case "强阵雨":
              case "强雷阵雨":
              case "极端降雨":
              case "毛毛雨/细雨":
              case "雨":
              case "小雨-中雨":
              case "中雨-大雨":
              case "大雨-暴雨":
              case "暴雨-大暴雨":
              case "大暴雨-特大暴雨":
              case "雨雪天气":
              case "雨夹雪":
              case "阵雨夹雪":
              case "冻雨":
              case "雪":
              case "阵雪":
              case "小雪":
              case "中雪":
                return "🌨️";

              case "大雪":
              case "暴雪":
              case "小雪-中雪":
              case "中雪-大雪":
                return "❄️";

              case "热":
                return "🔥";

              case "冷":
                return "🥶";

              default:
                return "🌈";
            }
        }, n = function n() {
            e.wx$1.getLocation({
                type: "gcj02",
                highAccuracyExpireTime: 3e3,
                success: function success(e) {
                    (function(e, t) {
                        var o = {
                            latitude: e,
                            longitude: t
                        };
                        a.request.post(a.host + "/weather/putWeather", o).then(function(e) {
                            var a = e.data[0];
                            s.value = a.province, r.value = a.city, c.value = a.weather, u.value = a.temperature;
                        }).catch(function(e) {
                            console.error("Error fetching weather data:", e);
                        });
                    })(e.latitude, e.longitude);
                },
                fail: function fail(e) {
                    console.error(e.errMsg), s.value = null, r.value = null, c.value = null, u.value = null;
                }
            });
        };
        return e.onBeforeMount(function() {
            n();
        }), function(a, n) {
            return {
                a: e.t(s.value ? o(c.value) : "♥"),
                b: e.t(s.value ? "".concat(s.value, " - ").concat(r.value, " (").concat(c.value, ", 温度: ").concat(u.value, "°C)") : "你的位置没有授权"),
                c: e.t(t.today.out),
                d: e.t(t.today.in),
                e: e.t(t.today.withLastDay > 0 ? "+" : ""),
                f: t.today.withLastDay > 0 ? "rgb(248, 113, 113)" : "rgb(52, 211, 153)",
                g: e.t(t.today.withLastDay),
                h: t.today.withLastDay > 0 ? "rgb(248, 113, 113)" : "rgb(52, 211, 153)",
                i: e.t(t.today.totalAssets)
            };
        };
    }
});

wx.createComponent(t);