var e = require("../../common/vendor.js"), o = e.defineComponent({
    __name: "LoginDialog",
    setup: function setup(o) {
        var n = e.ref(!0), s = function s() {
            console.log("账号密码登录");
        }, c = function c() {
            console.log("微信授权登录"), e.index.login({
                success: function success(e) {
                    console.log("微信登录成功", e);
                },
                fail: function fail(e) {
                    console.error("微信登录失败", e);
                }
            });
        };
        return function(o, l) {
            return e.e({
                a: n.value
            }, n.value ? {
                b: e.o(s),
                c: e.o(c)
            } : {});
        };
    }
}), n = e._export_sfc(o, [ [ "__scopeId", "data-v-79b9e90b" ] ]);

wx.createPage(n);