var e = require("../../../common/vendor.js");

if (!Array) {
    (e.resolveComponent("u-icon") + e.resolveComponent("HeadBar"))();
}

Math || (function() {
    return "../../../node-modules/uview-plus/components/u-icon/u-icon.js";
} + function() {
    return "../../../components/HeadBar.js";
})();

var o = e.defineComponent({
    __name: "Head",
    setup: function setup(o) {
        var n = function n() {
            e.index.navigateBack();
        };
        return function(o, t) {
            return {
                a: e.o(n),
                b: e.p({
                    name: "arrow-left",
                    size: "14",
                    color: "white"
                }),
                c: e.p({
                    color: "#FFFFFF00"
                })
            };
        };
    }
});

wx.createComponent(o);