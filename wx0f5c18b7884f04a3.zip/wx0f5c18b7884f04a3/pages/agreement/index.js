var e = require("../../common/vendor.js");

if (!Array) {
    e.resolveComponent("u-icon")();
}

Math || (o + function() {
    return "../../node-modules/uview-plus/components/u-icon/u-icon.js";
})();

var o = function o() {
    return "./components/Head.js";
}, n = e.defineComponent({
    __name: "index",
    setup: function setup(o) {
        var n = e.ref(!1), a = function a() {
            n.value = !n.value;
        };
        return function(o, s) {
            return e.e({
                a: !n.value
            }, (n.value, {}), {
                b: n.value
            }, (n.value, {}), {
                c: e.p({
                    name: n.value ? "点击收起" : "点击展开",
                    size: "12",
                    color: "gray"
                }),
                d: e.o(a)
            });
        };
    }
}), a = e._export_sfc(n, [ [ "__scopeId", "data-v-f743184a" ] ]);

wx.createPage(a);