var e = require("../../common/vendor.js"), a = require("../../api/user.js"), t = require("../../ts/request.js"), u = require("../../ts/global.js");

require("../../store/user.js");

var l = e.defineComponent({
    __name: "UserInfo",
    setup: function setup(l) {
        var o = e.ref(""), n = e.ref(""), r = e.ref(""), i = e.ref({}), s = e.ref("");
        e.onShow(function() {
            i.value = e.index.getStorageSync("user"), o.value = i.value.nickname, s.value = i.value.avatar, 
            n.value = i.value.phone, r.value = i.value.email;
        });
        var v = function v(a) {
            var l = a.detail.avatarUrl;
            e.index.uploadFile({
                url: t.host + "/file/upload",
                filePath: l,
                name: "file",
                header: {
                    Authorization: u.getToken()
                },
                success: function success(e) {
                    var a = JSON.parse(e.data);
                    s.value = t.host + "/file/view" + a.msg;
                }
            });
        }, d = function d() {
            a.updateUserInfo({
                nickname: o.value,
                phone: n.value,
                email: r.value,
                openId: i.value.openId,
                avatar: s.value
            }).then(function(a) {
                200 == a.code && (e.index.showToast({
                    title: "操作成功",
                    icon: "none"
                }), setTimeout(function() {
                    e.index.navigateBack();
                }, 2e3));
            });
        };
        return function(a, t) {
            return {
                a: s.value || "../../static/morentouxiang.png",
                b: e.o(v),
                c: o.value,
                d: e.o(function(e) {
                    return o.value = e.detail.value;
                }),
                e: n.value,
                f: e.o(function(e) {
                    return n.value = e.detail.value;
                }),
                g: r.value,
                h: e.o(function(e) {
                    return r.value = e.detail.value;
                }),
                i: e.o(d)
            };
        };
    }
}), o = e._export_sfc(l, [ [ "__scopeId", "data-v-9e468eda" ] ]);

wx.createPage(o);