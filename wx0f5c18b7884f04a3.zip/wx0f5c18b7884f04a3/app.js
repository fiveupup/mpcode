var _regeneratorRuntime2 = require("@babel/runtime/helpers/regeneratorRuntime");

var _asyncToGenerator2 = require("@babel/runtime/helpers/asyncToGenerator");

Object.defineProperty(exports, Symbol.toStringTag, {
    value: "Module"
});

var e = require("./common/vendor.js"), o = require("./store/setting.js");

Math;

var t = e.defineComponent({
    __name: "App",
    setup: function setup(t) {
        var n = e.ref(!1), s = o.useSettingStore();
        return e.onLaunch(/* */ _asyncToGenerator2(/* */ _regeneratorRuntime2().mark(function _callee() {
            var o, t, a, c, _e, _o, _o2;
            return _regeneratorRuntime2().wrap(function _callee$(_context) {
                while (1) switch (_context.prev = _context.next) {
                  case 0:
                    t = e.index.getMenuButtonBoundingClientRect();
                    s.setTopH(2 * t.top), s.setCapsuleH(2 * t.height);
                    a = e.index.getSystemInfoSync(), c = !1;
                    if (null == (o = a.model) ? void 0 : o.toLowerCase().includes("ip")) {
                        _e = /\d+/g, _o = a.model.match(_e);
                        c = _o && _o.length > 0 ? _o[0] > 8 : a.model.toLowerCase().includes("x");
                    }
                    if (e.index.getSetting({
                        success: function success(e) {
                            e.authSetting["scope.userInfo"] ? console.log("用户已授权") : (n.value = !0, console.log("用户未授权"));
                        },
                        fail: function fail(e) {
                            console.error("获取授权状态失败", e);
                        }
                    }), e.index.canIUse("getUpdateManager")) {
                        _o2 = e.index.getUpdateManager();
                        _o2.onCheckForUpdate(function(e) {
                            console.log(e.hasUpdate);
                        }), _o2.onUpdateReady(function() {
                            e.index.showModal({
                                title: "更新提示",
                                content: "新版本已经准备好，是否重启应用？",
                                success: function success(e) {
                                    e.confirm && _o2.applyUpdate();
                                }
                            });
                        }), _o2.onUpdateFailed(function() {
                            e.index.showModal({
                                title: "更新失败",
                                content: "新版本下载失败，请检查网络设置并重试",
                                showCancel: !1
                            });
                        });
                    }
                    s.setIsAppleAndHasLine(c), console.log("App Launch");

                  case 6:
                  case "end":
                    return _context.stop();
                }
            }, _callee);
        }))), e.onShow(function() {
            console.log("App Show");
        }), e.onHide(function() {
            console.log("App Hide");
        }), function(o, t) {
            return e.e({
                a: n.value
            }, n.value ? {
                b: e.o(function() {
                    return o.promptUserForAuth && o.promptUserForAuth.apply(o, arguments);
                })
            } : {});
        };
    }
}), n = e.createPinia();

function s() {
    var o = e.createSSRApp(t);
    return o.use(n), o.use(e.uviewPlus), {
        app: o
    };
}

s().app.mount("#app"), exports.createApp = s;