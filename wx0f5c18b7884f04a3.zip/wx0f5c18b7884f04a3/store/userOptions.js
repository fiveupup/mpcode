var e = require("../common/vendor.js"), t = e.defineStore("userOptions", function() {
    var t = e.ref(!!e.index.getStorageSync("hasAiSay"));
    return e.watch(t, function(t, r) {
        e.index.setStorageSync("hasAiSay", t);
    }), {
        hasAiSay: t
    };
});

exports.userOptionsStore = t;