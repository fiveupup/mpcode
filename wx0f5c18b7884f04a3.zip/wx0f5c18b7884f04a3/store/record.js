var e = require("../common/vendor.js"), r = e.defineStore("record", function() {
    var r = e.ref({}), s = e.ref([]);
    return e.watch(r, function(e, r) {
        s.value = e.images ? JSON.parse(e.images) : [];
    }, {
        deep: !0
    }), {
        data: r,
        images: s
    };
});

exports.useRecordStore = r;