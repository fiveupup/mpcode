var e = require("../common/vendor.js"), s = e.defineStore("setting", function() {
    var s = e.ref(!0), t = e.ref(0), r = e.ref(0), n = e.ref(!1);
    return {
        isCustom: s,
        topH: t,
        capsuleH: r,
        isAppleAndHasLine: n,
        setIsCustom: function setIsCustom(e) {
            return s.value = e;
        },
        setTopH: function setTopH(e) {
            return t.value = e;
        },
        setCapsuleH: function setCapsuleH(e) {
            return r.value = e;
        },
        setIsAppleAndHasLine: function setIsAppleAndHasLine(e) {
            return n.value = e;
        }
    };
});

exports.useSettingStore = s;