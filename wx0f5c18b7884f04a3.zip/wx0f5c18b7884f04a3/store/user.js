var e = require("../common/vendor.js"), r = "user", s = e.defineStore("user", function() {
    var s = e.ref(e.index.getStorageSync(r) || {});
    return {
        user: s,
        saveLoginRes: function saveLoginRes(t) {
            s.value = t, e.index.setStorageSync(r, t);
        },
        loginVerify: function loginVerify() {
            return s.value && s.value.token;
        }
    };
});

exports.useUserStore = s;