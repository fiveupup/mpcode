var _regeneratorRuntime2 = require("../@babel/runtime/helpers/regeneratorRuntime");

var _asyncToGenerator2 = require("../@babel/runtime/helpers/asyncToGenerator");

var e = require("../common/vendor.js"), o = require("./request.js"), r = require("../api/user.js"), s = require("../store/user.js").useUserStore(), i = function i(e) {
    s.saveLoginRes(e);
};

exports.fileUrlReplace = function(e) {
    return o.host + "/file/view" + e;
}, exports.getToken = function() {
    return e.index.getStorageSync("token");
}, exports.loginHandle = function() {
    return new Promise(function(o) {
        e.index.login({
            provider: "weixin",
            success: function() {
                var _success = _asyncToGenerator2(/* */ _regeneratorRuntime2().mark(function _callee(s) {
                    return _regeneratorRuntime2().wrap(function _callee$(_context) {
                        while (1) switch (_context.prev = _context.next) {
                          case 0:
                            r.login({
                                code: s.code
                            }).then(function(r) {
                                i(r.data), e.index.setStorageSync("token", r.data.token), o("");
                            });

                          case 1:
                          case "end":
                            return _context.stop();
                        }
                    }, _callee);
                }));
                function success(_x) {
                    return _success.apply(this, arguments);
                }
                return success;
            }()
        });
    });
}, exports.loginVerify = function() {
    return s.loginVerify();
}, exports.saveLoginRes = i;