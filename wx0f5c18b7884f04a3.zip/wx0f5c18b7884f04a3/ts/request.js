var e = require("../common/vendor.js"), t = require("./global.js"), s = require("../store/user.js").useUserStore();

var r;

exports.host = void 0, r = "bill.wxredcover.cn", exports.host = "https://bill.wxredcover.cn";

var o = function o(e) {
    var t = s.user;
    t && (e.header = {
        Authorization: t.token,
        "Content-Type": "application/json"
    });
}, i = {
    qs: e.lib,
    get: function get(s, r, n) {
        return new Promise(function(n) {
            var d = {
                url: "",
                method: "GET",
                success: function success(s) {
                    401 == s.data.code ? t.loginHandle().then(function() {
                        o(d), e.index.request(d);
                    }) : n(s.data);
                }
            };
            o(d), r && (s = s + "?" + i.qs.stringify(r)), d.url = s, e.index.request(d);
        });
    },
    post: function post(s, r, n, d) {
        return new Promise(function(d, l) {
            var a = {
                url: "",
                method: "POST",
                timeout: 3e4,
                success: function success(s) {
                    401 == s.data.code ? t.loginHandle().then(function() {
                        o(a), e.index.request(a);
                    }) : 500 === s.data.code ? l(s.msg) : d(s.data);
                },
                fail: function fail(e) {
                    l(e);
                }
            };
            o(a), r && (s = s + "?" + i.qs.stringify(r)), a.url = s, n && (a.data = n), e.index.request(a);
        });
    }
};

exports.request = i;