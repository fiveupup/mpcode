var t = require("../ts/request.js");

exports.del = function(s) {
    return t.request.post(t.host + "/bill/del", s);
}, exports.listForMonth = function(s) {
    return t.request.post(t.host + "/bill/listForMonth", s);
}, exports.save = function(s) {
    return t.request.post(t.host + "/bill/save", null, s);
}, exports.statistics = function(s) {
    return t.request.post(t.host + "/bill/statistics", s);
}, exports.todayData = function() {
    return t.request.post(t.host + "/bill/todayData");
}, exports.update = function(s) {
    return t.request.post(t.host + "/bill/update", null, s);
};