var e = require("../ts/request.js");

exports.UserInfo = function(s) {
    return e.request.get(e.host + "/wx/getUserInfo", s, null);
}, exports.login = function(s) {
    return e.request.post(e.host + "/wx/login", s);
}, exports.updateUserInfo = function(s) {
    return e.request.post(e.host + "/wx/update", null, s);
};