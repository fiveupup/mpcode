require("../../@babel/runtime/helpers/Arrayincludes");

var _regeneratorRuntime2 = require("../../@babel/runtime/helpers/regeneratorRuntime");

var _typeof2 = require("../../@babel/runtime/helpers/typeof");

var _asyncToGenerator2 = require("../../@babel/runtime/helpers/asyncToGenerator");

var t = require("../../common/vendor.js"), e = require("./canvas.js"), s = require("./utils.js"), i = {
    name: "lime-echart",
    props: {
        type: {
            type: String,
            default: "2d"
        },
        customStyle: String,
        isDisableScroll: Boolean,
        isClickable: {
            type: Boolean,
            default: !0
        },
        enableHover: Boolean,
        beforeDelay: {
            type: Number,
            default: 30
        }
    },
    data: function data() {
        return {
            use2dCanvas: !0,
            width: null,
            height: null,
            nodeWidth: null,
            nodeHeight: null,
            canvasNode: null,
            config: {},
            inited: !1,
            finished: !1,
            file: "",
            platform: "",
            isPc: !1,
            isDown: !1,
            isOffscreenCanvas: !1,
            offscreenWidth: 0,
            offscreenHeight: 0
        };
    },
    computed: {
        canvasId: function canvasId() {
            return "lime-echart".concat(this._ && this._.uid || this._uid);
        },
        offscreenCanvasId: function offscreenCanvasId() {
            return "".concat(this.canvasId, "_offscreen");
        },
        offscreenStyle: function offscreenStyle() {
            return "width:".concat(this.offscreenWidth, "px;height: ").concat(this.offscreenHeight, "px; position: fixed; left: 99999px; background: red");
        },
        canvasStyle: function canvasStyle() {
            return this.width && this.height ? "width:" + this.width + "px;height:" + this.height + "px" : "";
        }
    },
    beforeDestroy: function beforeDestroy() {
        this.clear(), this.dispose();
    },
    created: function created() {
        var _t$index$getSystemInf = t.index.getSystemInfoSync(), e = _t$index$getSystemInf.SDKVersion, i = _t$index$getSystemInf.version, h = _t$index$getSystemInf.platform, a = _t$index$getSystemInf.environment;
        this.isPC = /windows/i.test(h), this.use2dCanvas = "2d" === this.type && s.compareVersion(e, "2.9.2") >= 0 && !(/ios/i.test(h) && /7.0.20/.test(i) || /wxwork/i.test(a)) && !this.isPC;
    },
    mounted: function mounted() {
        var _this = this;
        this.$nextTick(function() {
            _this.$emit("finished");
        });
    },
    methods: {
        setChart: function setChart(t) {
            this.chart ? "function" == typeof t && this.chart && t(this.chart) : console.warn("组件还未初始化，请先使用 init");
        },
        setOption: function setOption() {
            var _this$chart;
            this.chart && this.chart.setOption ? (_this$chart = this.chart).setOption.apply(_this$chart, arguments) : console.warn("组件还未初始化，请先使用 init");
        },
        showLoading: function showLoading() {
            var _this$chart2;
            this.chart && (_this$chart2 = this.chart).showLoading.apply(_this$chart2, arguments);
        },
        hideLoading: function hideLoading() {
            this.chart && this.chart.hideLoading();
        },
        clear: function clear() {
            this.chart && this.chart.clear();
        },
        dispose: function dispose() {
            this.chart && this.chart.dispose();
        },
        resize: function resize(e) {
            var _this2 = this;
            e && e.width && e.height ? (this.height = e.height, this.width = e.width, this.chart && this.chart.resize(e)) : this.$nextTick(function() {
                t.index.createSelectorQuery().in(_this2).select(".lime-echart").boundingClientRect().exec(function(t) {
                    if (t) {
                        var _t$ = t[0], _e = _t$.width, _s = _t$.height;
                        _this2.width = _e = _e || 300, _this2.height = _s = _s || 300, _this2.chart.resize({
                            width: _e,
                            height: _s
                        });
                    }
                });
            });
        },
        canvasToTempFilePath: function canvasToTempFilePath() {
            var _this3 = this;
            var e = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {};
            var s = this.use2dCanvas, i = this.canvasId, h = this.canvasNode;
            return new Promise(function(a, o) {
                var c = Object.assign({
                    canvasId: i,
                    success: a,
                    fail: o
                }, e);
                s && (delete c.canvasId, c.canvas = h), t.index.canvasToTempFilePath(c, _this3);
            });
        },
        init: function init(t) {
            var _arguments = arguments, _this4 = this;
            return _asyncToGenerator2(/* */ _regeneratorRuntime2().mark(function _callee() {
                var _len, i, _key, h, a, o, c;
                return _regeneratorRuntime2().wrap(function _callee$(_context) {
                    while (1) switch (_context.prev = _context.next) {
                      case 0:
                        for (_len = _arguments.length, i = new Array(_len > 1 ? _len - 1 : 0), _key = 1; _key < _len; _key++) {
                            i[_key - 1] = _arguments[_key];
                        }
                        if (!(console.log(_arguments), _arguments && _arguments.length < 2)) {
                            _context.next = 3;
                            break;
                        }
                        return _context.abrupt("return", void console.error("缺少参数：init(echarts, theme?:string, opts?: object, callback: function)"));

                      case 3:
                        a = null, o = {};
                        Array.from(_arguments).forEach(function(t) {
                            "function" == typeof t && (h = t), [ "string" ].includes(_typeof2(t)) && (a = t), 
                            "object" == _typeof2(t) && (o = t);
                        });
                        _context.t0 = _this4.beforeDelay;
                        if (!_context.t0) {
                            _context.next = 9;
                            break;
                        }
                        _context.next = 9;
                        return s.sleep(_this4.beforeDelay);

                      case 9:
                        _context.next = 11;
                        return _this4.getContext();

                      case 11:
                        c = _context.sent;
                        "function" == typeof h ? (e.setCanvasCreator(t, c), _this4.chart = t.init(c.canvas, a, Object.assign({}, c, o)), 
                        h(_this4.chart)) : console.error("callback 非 function");

                      case 13:
                      case "end":
                        return _context.stop();
                    }
                }, _callee);
            }))();
        },
        getContext: function getContext() {
            var _this5 = this;
            var i = this.use2dCanvas;
            var h = s.devicePixelRatio;
            return new Promise(i ? function(s) {
                t.index.createSelectorQuery().in(_this5).select("#".concat(_this5.canvasId)).fields({
                    node: !0,
                    size: !0
                }).exec(function(t) {
                    var _t$2 = t[0], i = _t$2.node, a = _t$2.width, o = _t$2.height;
                    _this5.width = a = a || 300, _this5.height = o = o || 300;
                    var c = i.getContext("2d"), n = new e.Canvas(c, _this5, !0, i);
                    _this5.canvasNode = i, s({
                        canvas: n,
                        width: a,
                        height: o,
                        devicePixelRatio: h,
                        node: i
                    });
                });
            } : function(i) {
                t.index.createSelectorQuery().in(_this5).select("#".concat(_this5.canvasId)).boundingClientRect().exec(function(a) {
                    if (a) {
                        var _a$ = a[0], o = _a$.width, c = _a$.height;
                        _this5.width = o = o || 300, _this5.height = c = c || 300, h = _this5.isPC ? s.devicePixelRatio : 1, 
                        _this5.rect = a[0], _this5.nodeWidth = o * h, _this5.nodeHeight = c * h;
                        var n = t.index.createCanvasContext(_this5.canvasId, _this5), r = new e.Canvas(n, _this5, !1);
                        i({
                            canvas: r,
                            width: o,
                            height: c,
                            devicePixelRatio: h
                        });
                    }
                });
            });
        },
        getRelative: function getRelative(t) {
            return {
                x: t.pageX - this.rect.left,
                y: t.pageY - this.rect.top,
                wheelDelta: t.wheelDelta
            };
        },
        getTouch: function getTouch(t) {
            return t.touches && t.touches[0] && t.touches[0].x ? t.touches[0] : this.getRelative(t);
        },
        touchStart: function touchStart(t) {
            if (this.isDown = !0, this.chart && (t.touches.length > 0 && "mousemove" != t.type || "mousedown" == t.type)) {
                var _i = this.getTouch(t), _h = this.chart.getZr().handler;
                e.dispatch.call(_h, "mousedown", _i), e.dispatch.call(_h, "mousemove", _i), _h.processGesture(s.wrapTouch(t), "start");
            }
        },
        touchMove: function touchMove(t) {
            if (this.isPc && this.enableHover && !this.isDown && (this.isDown = !0), this.chart && (t.touches.length > 0 && "mousemove" != t.type || "mousemove" == t.type && this.isDown)) {
                var _i2 = this.chart.getZr().handler;
                e.dispatch.call(_i2, "mousemove", this.getTouch(t)), _i2.processGesture(s.wrapTouch(t), "change");
            }
        },
        touchEnd: function touchEnd(t) {
            if (this.isDown = !1, this.chart) {
                var _ref = t.changedTouches && t.changedTouches[0] || {}, _i3 = _ref.x, _h2 = (_i3 ? t.changedTouches[0] : this.getRelative(t)) || {}, a = this.chart.getZr().handler;
                e.dispatch.call(a, "mouseup", _h2), this.isClickable && e.dispatch.call(a, "click", _h2), 
                a.processGesture(s.wrapTouch(t), "end"), setTimeout(function() {
                    e.dispatch.call(a, "mousemove", {
                        x: -1,
                        y: -1
                    }), e.dispatch.call(a, "mouseup", {
                        x: -1,
                        y: -1
                    });
                }, 500);
            }
        }
    }
};

var h = t._export_sfc(i, [ [ "render", function(e, s, i, h, a, o) {
    return t.e({
        a: o.canvasId
    }, o.canvasId ? t.e({
        b: a.use2dCanvas
    }, a.use2dCanvas ? {
        c: o.canvasId,
        d: t.s(o.canvasStyle),
        e: i.isDisableScroll,
        f: t.o(function() {
            return o.touchStart && o.touchStart.apply(o, arguments);
        }),
        g: t.o(function() {
            return o.touchMove && o.touchMove.apply(o, arguments);
        }),
        h: t.o(function() {
            return o.touchEnd && o.touchEnd.apply(o, arguments);
        })
    } : a.isPc ? {
        j: t.s(o.canvasStyle),
        k: o.canvasId,
        l: o.canvasId,
        m: i.isDisableScroll,
        n: t.o(function() {
            return o.touchStart && o.touchStart.apply(o, arguments);
        }),
        o: t.o(function() {
            return o.touchMove && o.touchMove.apply(o, arguments);
        }),
        p: t.o(function() {
            return o.touchEnd && o.touchEnd.apply(o, arguments);
        })
    } : {
        q: a.nodeWidth,
        r: a.nodeHeight,
        s: t.s(o.canvasStyle),
        t: o.canvasId,
        v: o.canvasId,
        w: i.isDisableScroll,
        x: t.o(function() {
            return o.touchStart && o.touchStart.apply(o, arguments);
        }),
        y: t.o(function() {
            return o.touchMove && o.touchMove.apply(o, arguments);
        }),
        z: t.o(function() {
            return o.touchEnd && o.touchEnd.apply(o, arguments);
        })
    }, {
        i: a.isPc,
        A: a.isOffscreenCanvas
    }, a.isOffscreenCanvas ? {
        B: t.s(o.offscreenStyle),
        C: o.offscreenCanvasId
    } : {}, {
        D: t.s(i.customStyle)
    }) : {});
} ], [ "__scopeId", "data-v-4a524682" ] ]);

wx.createComponent(h);