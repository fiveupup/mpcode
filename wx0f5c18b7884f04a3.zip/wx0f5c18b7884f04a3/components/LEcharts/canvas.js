var _toConsumableArray2 = require("../../@babel/runtime/helpers/toConsumableArray");

var _typeof2 = require("../../@babel/runtime/helpers/typeof");

var _classCallCheck2 = require("../../@babel/runtime/helpers/classCallCheck");

var _createClass2 = require("../../@babel/runtime/helpers/createClass");

var t = require("../../common/vendor.js"), e = {}, s = /([\d\.]+)px/;

var i = /* */ function() {
    function i() {
        _classCallCheck2(this, i);
        this.__events = {};
    }
    _createClass2(i, [ {
        key: "on",
        value: function on(t, e) {
            if (!t || !e) return;
            var s = this.__events[t] || [];
            s.push(e), this.__events[t] = s;
        }
    }, {
        key: "emit",
        value: function emit(t, e) {
            var _this = this;
            if (t.constructor === Object && (t = (e = t) && e.type), !t) return;
            var s = this.__events[t];
            s && s.length && s.forEach(function(t) {
                t.call(_this, e);
            });
        }
    }, {
        key: "off",
        value: function off(t, e) {
            var s = this.__events, _i = s[t];
            if (_i && _i.length) if (e) for (var _n = 0, _r = _i.length; _n < _r; _n++) _i[_n] === e && (_i.splice(_n, 1), 
            _n--); else delete s[t];
        }
    } ]);
    return i;
}();

var n = /* */ function() {
    function n() {
        _classCallCheck2(this, n);
        this.currentSrc = null, this.naturalHeight = 0, this.naturalWidth = 0, this.width = 0, 
        this.height = 0, this.tagName = "IMG";
    }
    _createClass2(n, [ {
        key: "src",
        get: function get() {
            return this.currentSrc;
        },
        set: function set(e) {
            var _this2 = this;
            this.currentSrc = e, t.index.getImageInfo({
                src: e,
                success: function success(t) {
                    _this2.naturalWidth = _this2.width = t.width, _this2.naturalHeight = _this2.height = t.height, 
                    _this2.onload();
                },
                fail: function fail() {
                    _this2.onerror();
                }
            });
        }
    } ]);
    return n;
}();

var r = /* */ function() {
    function r(t, e, s) {
        _classCallCheck2(this, r);
        this.tagName = "canvas", this.com = e, this.canvasId = s, this.ctx = t;
    }
    _createClass2(r, [ {
        key: "width",
        get: function get() {
            return this.com.offscreenWidth || 0;
        },
        set: function set(t) {
            this.com.offscreenWidth = t;
        }
    }, {
        key: "height",
        get: function get() {
            return this.com.offscreenHeight || 0;
        },
        set: function set(t) {
            this.com.offscreenHeight = t;
        }
    }, {
        key: "getContext",
        value: function getContext(t) {
            return this.ctx;
        }
    }, {
        key: "getImageData",
        value: function getImageData() {
            var _this3 = this;
            return new Promise(function(e, s) {
                _this3.com.$nextTick(function() {
                    t.index.canvasGetImageData({
                        x: 0,
                        y: 0,
                        width: _this3.com.offscreenWidth,
                        height: _this3.com.offscreenHeight,
                        canvasId: _this3.canvasId,
                        success: function success(t) {
                            e(t);
                        },
                        fail: function fail(t) {
                            s(t);
                        }
                    }, _this3.com);
                });
            });
        }
    } ]);
    return r;
}();

exports.Canvas = /* */ function() {
    function _class(t, s, n) {
        var r = arguments.length > 3 && arguments[3] !== undefined ? arguments[3] : {};
        _classCallCheck2(this, _class);
        e[s.canvasId] = {
            ctx: t
        }, this.canvasId = s.canvasId, this.chart = null, this.isNew = n, this.tagName = "canvas", 
        this.canvasNode = r, this.com = s, n || this._initStyle(t), this._initEvent(), this._ee = new i();
    }
    _createClass2(_class, [ {
        key: "getContext",
        value: function getContext(t) {
            if ("2d" === t) return this.ctx;
        }
    }, {
        key: "setChart",
        value: function setChart(t) {
            this.chart = t;
        }
    }, {
        key: "createOffscreenCanvas",
        value: function createOffscreenCanvas(e) {
            if (!this.children) {
                this.com.isOffscreenCanvas = !0, this.com.offscreenWidth = e.width || 300, this.com.offscreenHeight = e.height || 300;
                var _s = this.com, _i2 = this.com.offscreenCanvasId, _n2 = t.index.createCanvasContext(_i2, this.com);
                this._initStyle(_n2), this.children = new r(_n2, _s, _i2);
            }
            return this.children;
        }
    }, {
        key: "appendChild",
        value: function appendChild(t) {
            console.log("child", t);
        }
    }, {
        key: "dispatchEvent",
        value: function dispatchEvent(t, e) {
            return "object" == _typeof2(t) ? this._ee.emit(t.type, t) : this._ee.emit(t, e), 
            !0;
        }
    }, {
        key: "attachEvent",
        value: function attachEvent() {}
    }, {
        key: "detachEvent",
        value: function detachEvent() {}
    }, {
        key: "addEventListener",
        value: function addEventListener(t, e) {
            this._ee.on(t, e);
        }
    }, {
        key: "removeEventListener",
        value: function removeEventListener(t, e) {
            this._ee.off(t, e);
        }
    }, {
        key: "_initCanvas",
        value: function _initCanvas(t, e) {
            t.util.getContext = function() {
                return e;
            }, t.util.$override("measureText", function(t, s) {
                return e.font = s || "12px sans-serif", e.measureText(t, s);
            });
        }
    }, {
        key: "_initStyle",
        value: function _initStyle(t, e) {
            if ([ "fillStyle", "strokeStyle", "fontSize", "globalAlpha", "opacity", "textAlign", "textBaseline", "shadow", "lineWidth", "lineCap", "lineJoin", "lineDash", "miterLimit", "font" ].forEach(function(e) {
                Object.defineProperty(t, e, {
                    set: function set(i) {
                        if ("font" === e && s.test(i)) {
                            var _e = s.exec(i);
                            t.setFontSize(_e[1]);
                        } else "opacity" !== e ? ("fillStyle" !== e && "strokeStyle" !== e || "none" !== i && null !== i) && t["set" + e.charAt(0).toUpperCase() + e.slice(1)](i) : t.setGlobalAlpha(i);
                    }
                });
            }), this.isNew || e || (t.uniDrawImage = t.drawImage, t.drawImage = function() {
                for (var _len = arguments.length, e = new Array(_len), _key = 0; _key < _len; _key++) {
                    e[_key] = arguments[_key];
                }
                e[0] = e[0].src, t.uniDrawImage.apply(t, e);
            }), t.createRadialGradient || (t.createRadialGradient = function() {
                return t.createCircularGradient.apply(t, _toConsumableArray2(Array.prototype.slice.call(arguments).slice(-3)));
            }), t.strokeText || (t.strokeText = function() {
                t.fillText.apply(t, arguments);
            }), !t.measureText) {
                var _e2 = function _e2(t) {
                    var e = 0;
                    for (var _s2 = 0; _s2 < t.length; _s2++) t.charCodeAt(_s2) > 0 && t.charCodeAt(_s2) < 128 ? e++ : e += 2;
                    return e;
                };
                t.measureText = function(t, s) {
                    var i = 12;
                    return s && (i = parseInt(s.match(/([\d\.]+)px/)[1])), i /= 2, {
                        width: _e2(t) * i
                    };
                };
            }
        }
    }, {
        key: "_initEvent",
        value: function _initEvent(t) {
            var _this4 = this;
            this.event = {};
            [ {
                wxName: "touchStart",
                ecName: "mousedown"
            }, {
                wxName: "touchMove",
                ecName: "mousemove"
            }, {
                wxName: "touchEnd",
                ecName: "mouseup"
            }, {
                wxName: "touchEnd",
                ecName: "click"
            } ].forEach(function(t) {
                _this4.event[t.wxName] = function(e) {
                    var s = e.touches[0];
                    _this4.chart.getZr().handler.dispatch(t.ecName, {
                        zrX: "tap" === t.wxName ? s.clientX : s.x,
                        zrY: "tap" === t.wxName ? s.clientY : s.y
                    });
                };
            });
        }
    }, {
        key: "width",
        get: function get() {
            return this.canvasNode.width || 0;
        },
        set: function set(t) {
            this.canvasNode.width = t;
        }
    }, {
        key: "height",
        get: function get() {
            return this.canvasNode.height || 0;
        },
        set: function set(t) {
            this.canvasNode.height = t;
        }
    }, {
        key: "ctx",
        get: function get() {
            return e[this.canvasId].ctx || null;
        }
    }, {
        key: "chart",
        get: function get() {
            return e[this.canvasId].chart || null;
        },
        set: function set(t) {
            e[this.canvasId].chart = t;
        }
    } ]);
    return _class;
}(), exports.dispatch = function(t, _ref) {
    var e = _ref.x, s = _ref.y, i = _ref.wheelDelta;
    this.dispatch(t, {
        zrX: e,
        zrY: s,
        zrDelta: i,
        preventDefault: function preventDefault() {},
        stopPropagation: function stopPropagation() {}
    });
}, exports.setCanvasCreator = function(t, _ref2) {
    var e = _ref2.canvas, s = _ref2.node;
    t.registerPreprocessor(function(t) {
        t && t.series && (t.series.length > 0 ? t.series.forEach(function(t) {
            t.progressive = 0;
        }) : "object" == _typeof2(t.series) && (t.series.progressive = 0));
    }), t.setPlatformAPI && t.setPlatformAPI({
        loadImage: e.setChart ? function(t, e, i) {
            var r = null;
            return s && s.createImage ? (r = s.createImage(), r.onload = e.bind(r), r.onerror = i.bind(r), 
            r.src = t, r) : (r = new n(), r.onload = e.bind(r), r.onerror = i.bind(r), r.src = t, 
            r);
        } : null,
        createCanvas: function createCanvas() {
            return e;
        }
    });
};