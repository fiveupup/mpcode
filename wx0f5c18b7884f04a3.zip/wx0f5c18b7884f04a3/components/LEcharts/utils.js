var e = require("../../common/vendor.js").wx$1.getSystemInfoSync().pixelRatio;

exports.compareVersion = function(e, t) {
    e = e.split("."), t = t.split(".");
    var o = Math.max(e.length, t.length);
    for (;e.length < o; ) e.push("0");
    for (;t.length < o; ) t.push("0");
    for (var n = 0; n < o; n++) {
        var _o = parseInt(e[n], 10), r = parseInt(t[n], 10);
        if (_o > r) return 1;
        if (_o < r) return -1;
    }
    return 0;
}, exports.devicePixelRatio = e, exports.sleep = function(e) {
    return new Promise(function(t) {
        setTimeout(function() {
            t(!0);
        }, e);
    });
}, exports.wrapTouch = function(e) {
    for (var t = 0; t < e.touches.length; ++t) {
        var o = e.touches[t];
        o.offsetX = o.x, o.offsetY = o.y;
    }
    return e;
};