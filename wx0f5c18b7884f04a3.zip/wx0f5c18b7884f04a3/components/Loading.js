var o = require("../common/vendor.js").defineComponent({
    __name: "Loading",
    props: {
        show: {
            type: Boolean,
            default: !0
        }
    },
    setup: function setup(o) {
        return function(e, n) {
            return {
                a: o.show ? "1" : "0",
                b: o.show ? "auto" : "none"
            };
        };
    }
});

wx.createComponent(o);