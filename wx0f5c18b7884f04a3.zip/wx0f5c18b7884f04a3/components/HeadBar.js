var e = require("../common/vendor.js"), r = require("../store/setting.js"), t = e.defineComponent({
    __name: "HeadBar",
    props: {
        color: {
            type: String,
            default: "white"
        }
    },
    setup: function setup(t) {
        var o = r.useSettingStore();
        return function(r, n) {
            return {
                a: e.unref(o).topH + "rpx",
                b: e.unref(o).capsuleH + "rpx",
                c: t.color
            };
        };
    }
});

wx.createComponent(t);