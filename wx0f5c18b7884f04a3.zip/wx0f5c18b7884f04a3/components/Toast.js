var e = require("../common/vendor.js");

if (!Array) {
    e.resolveComponent("u-icon")();
}

Math;

var t = e.defineComponent({
    __name: "Toast",
    setup: function setup(t, _ref) {
        var r = _ref.expose;
        var n = e.ref({}), o = e.ref(!1), u = e.ref();
        return r({
            show: function show(e) {
                u.value && clearTimeout(u.value), n.value = "string" == typeof e ? {
                    text: e
                } : e, o.value = !0, u.value = setTimeout(function() {
                    o.value = !1;
                }, 2e3);
            }
        }), function(t, r) {
            return e.e({
                a: e.unref(n).type
            }, e.unref(n).type ? {
                b: e.p({
                    name: "success" === e.unref(n).type ? "checkmark" : "error-circle-fill",
                    color: (u = e.unref(n).type, "success" === u ? "#22c55e" : "error" === u ? "#ef4444" : "warning" === u ? "#f97316" : "info" === u ? "#64748b" : void 0)
                })
            } : {}, {
                c: e.t(e.unref(n).text),
                d: e.n("fixed flex flex-col justify-center items-center top-0 bottom-0 left-0 right-0 z-9 transition-all duration-300"),
                e: e.n("opaciry-0 pointer-events-none"),
                f: e.unref(o) ? "1" : "0"
            });
            var u;
        };
    }
});

wx.createComponent(t);