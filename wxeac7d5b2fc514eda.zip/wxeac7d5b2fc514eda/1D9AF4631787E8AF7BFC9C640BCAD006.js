var t = Behavior({
    lifetimes: {
        attached: function() {
            var t, e, n, o, u, r, i = getCurrentPages().pop();
            i.$bus || (i.$bus = (n = {}, o = [], r = [], {
                store: e = {
                    data: t = {},
                    get: function(e) {
                        return e ? t[e] : t;
                    },
                    set: function(e, n) {
                        t[e] = n;
                    },
                    remove: function(e) {
                        delete t[e];
                    },
                    init: function(e) {
                        Object.assign(t, e);
                    }
                },
                event: u = {
                    on: function(t, e) {
                        n[t] || (n[t] = []), n[t].push(e);
                    },
                    off: function(t, e) {
                        n[t] && (n[t] = e ? n[t].filter(function(t) {
                            return t !== e;
                        }) : []);
                    },
                    emit: function(t) {
                        for (var e = arguments.length, o = new Array(e > 1 ? e - 1 : 0), u = 1; u < e; u++) o[u - 1] = arguments[u];
                        n[t] && n[t].forEach(function(t) {
                            return t.apply(void 0, o);
                        });
                    },
                    export: function(t, e) {
                        o.push({
                            key: t,
                            fn: e
                        });
                    },
                    call: function(t) {
                        var e = o.find(function(e) {
                            return e.key === t;
                        });
                        if (e) {
                            for (var n = arguments.length, u = new Array(n > 1 ? n - 1 : 0), r = 1; r < n; r++) u[r - 1] = arguments[r];
                            e.fn.apply(e, u);
                        } else console.error("没有找到".concat(t, "对应的函数"));
                    }
                },
                get: e.get,
                set: e.set,
                emit: u.emit,
                on: u.on,
                setTimeout: function() {
                    var t = setTimeout.apply(null, arguments);
                    return r.push(t), t;
                },
                clearTimeout: function() {
                    r.forEach(function(t) {
                        return clearTimeout(t);
                    });
                },
                sleep: function(t) {
                    return new Promise(function(e) {
                        setTimeout(e, t);
                    });
                }
            }), i.store && i.store.constructor === Function && i.$bus.store.init(i.store()), 
            wx.$bus = i.$bus), this.$bus = i.$bus;
        },
        detached: function() {
            this.$bus.clearTimeout(), this.$bus = null;
        }
    }
});

wx.Bus = t, module.exports = t;