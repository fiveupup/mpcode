var t = require("@babel/runtime/helpers/objectSpread2.js"), e = require("7AE168401787E8AF1C8700472639D006.js"), a = {
    template_lianxisheng: {
        id: "template_lianxisheng",
        title: "🐔 练习生转盘",
        from: "hot",
        items: m([ "唱", "跳", "rap", "篮球", "再转一次" ])
    },
    template_zidingyi: {
        id: "template_zidingyi",
        from: "hot",
        title: "☝️ 自定义转盘",
        items: m([ "选项1", "选项2" ])
    },
    template_number: {
        id: "template_number",
        from: "hot",
        title: "🔢 选数字转盘",
        items: m([ "1", "2", "3", "4", "5", "6", "7", "8", "9", "10" ])
    },
    template_where_to_go: {
        id: "template_where_to_go",
        from: "hot",
        title: "🌍 去哪玩转盘",
        items: m([ "西安", "长沙", "南京", "秦皇岛", "北京", "哈尔滨", "河北", "深圳" ])
    },
    template_eat: {
        id: "template_eat",
        from: "hot",
        title: "🍚 吃什么转盘",
        items: m([ "火锅🍲", "水饺🥟", "🍜面条", "酸辣粉", "重庆小面", "🍗 🍔 炸鸡汉堡", "麻辣烫", "川菜 🌶️" ])
    },
    template_who_buy: {
        id: "template_who_buy",
        from: "hot",
        title: "💰 谁买单转盘",
        items: m([ "头发最长的", "最瘦的", "头发最短的", "手机电量最多的", "最高的", "最矮的", "年龄最小的", "年龄最大的" ])
    },
    template_zhenxinghuaanddamaoxian: {
        id: "template_damaoxian",
        from: "hot",
        title: "❓ 真心话&大冒险",
        items: m([ "真心话", "大冒险", "真心话", "大冒险", "再转一次" ])
    },
    template_wangzhe_hero: {
        id: "template_wangzhe_hero",
        from: "hot",
        title: "王者荣耀玩什么英雄🤔",
        items: m([ "公孙离", "鲁班七号", "娜可露露", "曜", "西施", "杨玉环", "小乔", "李白", "貂蝉", "嫦娥", "猴子" ])
    },
    template_eat_breakfast: {
        id: "template_eat_breakfast",
        from: "hot",
        title: "🥣 吃什么早餐",
        items: m([ "豆浆", "油条", "包子", "馒头", "面条", "鸡蛋", "煎饼果子" ])
    },
    template_damaoxian: {
        id: "template_damaoxian",
        from: "hot",
        title: "👍 大冒险转盘",
        items: m([ "背一首古诗", "做鬼脸", "绕口令：我爸是我爸我爸儿是我我是我爸儿", "打自己一下", "模仿五种动物的声音", "大笑五秒再大哭五秒，然后说：我该吃药了", "双手握拳高举说：我是超人，我要回家了", "唱一首歌", "模仿猪叫", "对你身边的人三秒咧嘴直到他笑为止", "跳个舞", "蹲起15个", "模仿小狗叫", "原地转5圈", "再转一次", "打开抖音模仿推荐的第一个人", "和椅子吵架", "走模特步回眸一笑", "平板撑15秒" ])
    },
    template_zhenxinhua: {
        id: "template_zhenxinhua",
        from: "hot",
        title: "👂 真心话转盘",
        items: m([ "说一个你不敢告诉爸妈的事", "你最喜欢哪三种颜色", "如果你知道有人暗恋你你会怎么做", "对未来的男（女）朋友说一句话吧", "如果有来生，你选择当？", "从在座的选一个人作为对象你会选谁？", "你会选择爱你的人还是你爱的人？", "一见钟情和日久生情你更喜欢哪一个？", "你想做但一直没做的事是什么？", "你最受不了别人对你做什么？", "你选男朋友首先看中什么", "在座的各位你看哪位异性最舒服", "你最喜欢的小说是什么？", "你希望你现在是多少岁？", "近一个星期让你最开心的事", "最反感别人的什么行为？", "你最想从头来过的一件事是什么？", "你最想养的宠物是什么？", "收到过最难忘的礼物是什么？", "目前为止，你做过最疯狂的事是什么", "你会做饭吗", "再转一次", "你最喜欢的一首歌是什么？", "如果从天而降99枚金币 你的第一反应是什么？", "走错过男女厕所吗？", "最喜欢哪部电影？", "最喜欢的明星是谁？", "让你拥有隐身的超能力5分钟，你会干什么？", "上次哭是什么时候？", "做过最浪漫的事是什么？" ])
    },
    template_dataosha: {
        id: "template_dataosha",
        from: "hot",
        title: "👊 潮玩大逃杀选哪个",
        items: m([ "杂物间", "休息室", "厂长室", "谈话室", "洗衣房", "工作室", "茶水间", "音乐室" ])
    },
    template_shuiduojiu: {
        id: "template_shuiduojiu",
        from: "hot",
        title: "😴 休息多长时间",
        items: m([ "5分钟", "半小时", "15分钟", "两小时", "不限时", "再转一次", "不休息", "10秒" ])
    },
    template_go_or_not: {
        id: "template_go_or_not",
        from: "hot",
        title: "🎒 去不去上班",
        items: m([ "去", "不去", "再转一次" ])
    },
    template_rember_word: {
        id: "template_rember_word",
        from: "hot",
        title: "📚 今天背几个单词",
        items: m([ "10个", "20个", "不用背", "再转一次", "30个", "50个" ])
    }
};

function m(t) {
    return t.map(function(t, a) {
        return {
            text: t,
            weight: 1,
            color: e[a]
        };
    });
}

module.exports = {
    all_zps: a,
    empty_zp: {
        title: "",
        items: [ {
            text: "",
            weight: 1,
            color: e[0]
        }, {
            text: "",
            weight: 1,
            color: e[2]
        } ]
    },
    default: t(t({}, a.template_zhenxinghuaanddamaoxian), {}, {
        title: "万能小转盘"
    }),
    hot: [ a.template_zidingyi, a.template_damaoxian, a.template_go_or_not, a.template_rember_word, a.template_eat_breakfast, a.template_shuiduojiu, a.template_zhenxinhua, a.template_zhenxinghuaanddamaoxian, a.template_number, a.template_where_to_go, a.template_eat, a.template_who_buy, a.template_wangzhe_hero, a.template_dataosha ]
};