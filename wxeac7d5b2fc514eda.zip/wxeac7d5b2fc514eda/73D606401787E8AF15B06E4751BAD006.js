module.exports = {
    hosts: {
        production: {
            api: "https://zp3010.a1.jialidun.vip",
            cdn: "https://app00.a1.jialidun.vip"
        },
        dev: {
            api: "https://dev-api.example.com",
            cdn: "https://dev-cdn.example.com"
        },
        local2: {
            api: "https://lcc.iwill.vip"
        },
        local: {
            api: "http://localhost:3010",
            cdn: "http://localhost:3010"
        }
    },
    env: "production"
};