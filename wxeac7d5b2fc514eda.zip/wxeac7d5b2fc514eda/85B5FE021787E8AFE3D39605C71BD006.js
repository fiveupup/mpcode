var e = require("@babel/runtime/helpers/interopRequireDefault.js"), t = require("@babel/runtime/helpers/objectSpread2.js"), r = e(require("@babel/runtime/regenerator.js")), n = require("@babel/runtime/helpers/asyncToGenerator.js"), u = require("73D606401787E8AF15B06E4751BAD006.js"), a = u.hosts, o = u.env, s = getApp(), i = {
    req: function(e, t, u) {
        var i = arguments.length > 3 && void 0 !== arguments[3] ? arguments[3] : {};
        s || (s = getApp());
        var c = 0;
        a[o].api;
        return new Promise(function(p, f) {
            !function d() {
                var g;
                i ? i.token = wx.getStorageSync("token") : i = {
                    token: wx.getStorageSync("token")
                }, wx.request({
                    url: a[o].api + e,
                    data: t,
                    method: u,
                    header: i,
                    timeout: 15e3,
                    success: (g = n(r.default.mark(function e(t) {
                        return r.default.wrap(function(e) {
                            for (;;) switch (e.prev = e.next) {
                              case 0:
                                if (401 !== t.statusCode && 403 !== t.statusCode) {
                                    e.next = 11;
                                    break;
                                }
                                if (!(c < 3)) {
                                    e.next = 9;
                                    break;
                                }
                                return e.next = 4, s.wxLogin();

                              case 4:
                                return c++, d(), e.abrupt("return");

                              case 9:
                                return f(t.data), e.abrupt("return");

                              case 11:
                                p(t.data);

                              case 12:
                              case "end":
                                return e.stop();
                            }
                        }, e);
                    })), function(e) {
                        return g.apply(this, arguments);
                    }),
                    fail: function(e) {
                        f(e);
                    }
                });
            }();
        });
    },
    get: function(e, t) {
        return this.req(e, "", "get", t);
    },
    post: function(e, t, r) {
        return this.req(e, t, "post", r);
    }
};

var c = {
    checkMsg: function(e) {
        return n(r.default.mark(function t() {
            return r.default.wrap(function(t) {
                for (;;) switch (t.prev = t.next) {
                  case 0:
                    return t.abrupt("return", i.post("/v1/checkMsg", {
                        msg: e
                    }));

                  case 1:
                  case "end":
                    return t.stop();
                }
            }, t);
        }))();
    },
    getTTS: function(e) {
        var t = arguments;
        return n(r.default.mark(function n() {
            var u;
            return r.default.wrap(function(r) {
                for (;;) switch (r.prev = r.next) {
                  case 0:
                    return u = t.length > 1 && void 0 !== t[1] ? t[1] : 1007, r.abrupt("return", i.post("/v1/tts", {
                        text: e,
                        voice_type: u
                    }));

                  case 2:
                  case "end":
                    return r.stop();
                }
            }, n);
        }))();
    },
    getUser: function() {
        return i.post("/v1/getUser");
    },
    draws: {
        getDraws: function() {
            return i.post("/v1/draws/list");
        },
        getDraw: function(e) {
            return i.post("/v1/draws/findOne", {
                id: e
            });
        },
        updateDraw: function(e) {
            return i.post("/v1/draws/update", e);
        },
        deleteDraw: function(e) {
            return i.post("/v1/draws/delete", e);
        },
        getWXQrcode: function(e) {
            return i.post("/v1/draws/getWXQrcode", e);
        }
    },
    wxPay: {
        createOrder: function(e) {
            return i.post("/v1/wxpay/createOrder", e);
        }
    }
};

module.exports = t({
    request: i,
    login: function(e) {
        return i.post("/login", e);
    }
}, c);