Component({
    properties: {
        item: {
            type: Object,
            observer: function(e) {
                if (e) {
                    var t = {
                        color: e.color,
                        text: e.text.length > 15 ? e.text.substring(0, 15) + "..." : e.text,
                        all_deg: e.deg,
                        deg: e.deg > 180 ? [ e.deg / 2, e.deg / 2 ] : [ e.deg ],
                        text_class: "",
                        bg_class: ""
                    };
                    this.setData(t);
                }
            }
        },
        radius: {
            type: Number
        }
    },
    data: {
        color: "#000",
        all_deg: 30,
        deg: [ 30 ],
        text: "👌🏻",
        text_class: "",
        bg_class: ""
    },
    methods: {}
});