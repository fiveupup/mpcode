getApp();

Component({
    properties: {
        items: {
            type: Array
        },
        radius: {
            type: Number,
            value: 155
        }
    },
    data: {},
    methods: {}
});