Object.defineProperty(exports, "__esModule", {
    value: !0
}), (0, require("../../../70BA88211787E8AF16DCE0264779D006.js").VantComponent)({
    props: {
        description: String,
        image: {
            type: String,
            value: "default"
        }
    }
});