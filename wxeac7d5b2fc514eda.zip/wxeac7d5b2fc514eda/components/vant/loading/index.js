Object.defineProperty(exports, "__esModule", {
    value: !0
}), (0, require("../../../70BA88211787E8AF16DCE0264779D006.js").VantComponent)({
    props: {
        color: String,
        vertical: Boolean,
        type: {
            type: String,
            value: "circular"
        },
        size: String,
        textSize: String
    },
    data: {
        array12: Array.from({
            length: 12
        })
    }
});