Object.defineProperty(exports, "__esModule", {
    value: !0
});

var e = require("../../../70BA88211787E8AF16DCE0264779D006.js"), s = require("../../../1675A2641787E8AF7013CA63EC5AD006.js");

(0, e.VantComponent)({
    classes: [ "enter-class", "enter-active-class", "enter-to-class", "leave-class", "leave-active-class", "leave-to-class" ],
    mixins: [ (0, s.transition)(!0) ]
});