var a = require("1D9AF4631787E8AF7BFC9C640BCAD006.js");

module.exports = Behavior({
    behaviors: [ a ],
    properties: {},
    data: {
        audioCtx: {
            audio: null
        },
        audioIndex: 0
    },
    methods: {
        playAudio: function() {
            this.data.audioCtx.audio.seek(0), this.data.audioCtx.audio.play();
        }
    },
    lifetimes: {
        attached: function() {
            var a = this;
            this.data.audioCtx.audio || (this.data.audioCtx.audio = wx.createInnerAudioContext(), 
            this.data.audioCtx.audio.src = "http://pan00.jialidun.vip/audio/win.mp3", this.data.audioCtx.audio.volume = .8), 
            this.$bus.event.on("zhuanpan:stop", function(i) {
                a.$bus.get("settings").sound && a.playAudio();
            });
        }
    }
});