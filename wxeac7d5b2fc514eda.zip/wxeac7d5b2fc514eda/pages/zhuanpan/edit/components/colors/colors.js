require("../../../../../@babel/runtime/helpers/Objectvalues");

var e = require("../../../../../1D9AF4631787E8AF7BFC9C640BCAD006.js"), o = require("../../../../../7AE168401787E8AF1C8700472639D006.js");

Component({
    behaviors: [ e ],
    properties: {},
    data: {
        showColors: !1
    },
    methods: {
        closeSetting: function() {
            this.setData({
                showColors: !1
            });
        },
        initColorsMap: function() {
            for (var e = {}, t = 0; t < o.length; t++) e[o[t]] = {
                color: o[t],
                selected: !1,
                checked: !1,
                index: t
            };
            this.setData({
                colors_map: e
            }), this.$bus.store.set("colors_map", e);
        },
        selectColor: function(e) {
            var o = e.currentTarget.dataset.color;
            this.setData({
                showColors: !1
            }), this.$bus.event.call("page:setColor", {
                color: o,
                index: this.$bus.store.get("current_zp_item_index")
            });
        }
    },
    lifetimes: {
        attached: function() {
            var e = this;
            this.$bus.event.export("colors:showColors", function(o) {
                var t = o.index, s = o.selectedColor;
                e.$bus.store.set("current_zp_item_index", t), Object.values(e.data.colors_map).forEach(function(e) {
                    e.checked = !1, e.selected = !1;
                });
                var r = s[t];
                e.data.colors_map[r].selected = !0, s.forEach(function(o) {
                    e.data.colors_map[o].checked = !0;
                }), e.setData({
                    showColors: !0,
                    colors_map: e.data.colors_map
                });
            }), this.initColorsMap();
        }
    }
});