var t = require("../../../../../1D9AF4631787E8AF7BFC9C640BCAD006.js");

Component({
    behaviors: [ t ],
    data: {
        show: !1,
        text: "",
        status: 0,
        isVip: !1
    },
    methods: {
        onHide: function() {
            this.setData({
                show: !1
            }), this.$bus.emit("loading:hide", {
                status: this.data.status
            });
        },
        toZanshang: function() {
            wx.navigateTo({
                url: "/pages/zanzhu/zanzhu"
            });
        }
    },
    lifetimes: {
        attached: function() {
            var t = this;
            console.log("得到的"), this.$bus.event.export("loading:show", function() {
                t.setData({
                    show: !0
                });
                var e = wx.getStorageSync("userInfo");
                e && e.vip_expired_at && new Date(e.vip_expired_at).getTime() > Date.now() && (console.log("vip用户"), 
                t.setData({
                    isVip: !0
                }));
            }), this.$bus.event.export("loading:setText", function(e) {
                var s = e.text, a = e.status;
                t.setData({
                    text: s,
                    status: a
                });
            });
        }
    }
});