var t = require("../../../../../@babel/runtime/helpers/toConsumableArray");

Component({
    behaviors: [ wx.Bus ],
    properties: {},
    data: {
        showNum: !1,
        blackNum: 0,
        allNum: 0
    },
    methods: {
        initBlackItems: function() {
            var t = wx.getStorageSync("blackItems_" + this.$bus.get("zpInfo").id) || [];
            this.$bus.set("blackItems", t);
        },
        initNum: function() {
            if (!this.$bus.store.get("settings").repeat) {
                var e = this.$bus.get("blackItems"), s = this.$bus.get("realItems").map(function(t) {
                    return t.text;
                });
                s = t(new Set(s)), this.setData({
                    blackNum: e.length,
                    allNum: s.length
                });
            }
        },
        toRecords: function() {
            var e = this, s = t(new Set(this.$bus.get("realItems").map(function(t) {
                return t.text;
            })));
            wx.navigateTo({
                url: "/pages/zhuanpan/records/records?id=".concat(this.$bus.get("zpInfo").id, "&allList=").concat(encodeURIComponent(JSON.stringify(s))).concat(this.data.showNum ? "&showNum=1" : ""),
                events: {
                    updateBlackItems: function() {
                        e.initBlackItems(), e.initNum();
                    }
                }
            });
        },
        clearBlackItems: function() {
            this.$bus.set("blackItems", []), wx.setStorageSync("blackItems_" + this.$bus.get("zpInfo").id, []);
        },
        addToBlackList: function(t) {
            if (this.$bus.get("settings").repeat) console.log("repeat mode"); else {
                var e = this.$bus.get("blackItems");
                e.push(t), wx.setStorageSync("blackItems_" + this.$bus.get("zpInfo").id, e), this.$bus.set("blackItems", e);
            }
        }
    },
    lifetimes: {
        attached: function() {
            var t = this;
            this.$bus.on("page:zpInfoLoaded", function(e) {
                t.$bus.store.get("settings") && !t.$bus.store.get("settings").repeat ? (t.setData({
                    showNum: !0
                }), t.initBlackItems(), t.initNum()) : t.setData({
                    showNum: !1
                });
            }), this.$bus.on("settings:change", function(e) {
                t.$bus.store.get("settings") && !t.$bus.store.get("settings").repeat ? (t.setData({
                    showNum: !0
                }), t.initBlackItems(), t.initNum()) : t.setData({
                    showNum: !1
                });
            }), this.$bus.event.export("jindu:clear", function() {
                t.clearBlackItems();
            }), this.$bus.event.export("jindu:addToBlackList", function(e) {
                t.addToBlackList(e), t.initNum();
            });
        }
    }
});