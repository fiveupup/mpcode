var e = require("../../../../../@babel/runtime/helpers/interopRequireDefault")(require("../../../../../@babel/runtime/regenerator")), t = require("../../../../../@babel/runtime/helpers/asyncToGenerator"), n = require("../../../../../1D9AF4631787E8AF7BFC9C640BCAD006.js"), r = require("../../../../../85B5FE021787E8AFE3D39605C71BD006.js").draws;

Component({
    behaviors: [ n ],
    properties: {},
    data: {
        showShare: !1,
        options: [ {
            name: "微信",
            icon: "wechat",
            openType: "share"
        }, {
            name: "复制页面路径",
            icon: "link"
        } ]
    },
    methods: {
        onSelectShare: function(e) {
            console.log(e), 0 === e.detail.index && (this.onCloseShare(), this.$bus.event.call("more:hiddenMore")), 
            1 === e.detail.index && this.copyPath();
        },
        copyPath: function() {
            var e = this.$bus.store.get("zpInfo");
            wx.setClipboardData({
                data: "/pages/zhuanpan/index/index?type=share&id=".concat(e.id00 || e.id),
                success: function() {
                    wx.showModal({
                        title: "复制成功",
                        content: "你可以将当前转盘添加到公众号文章或者小程序里面",
                        cancelText: "关闭",
                        confirmText: "查看教程",
                        success: function(e) {
                            e.confirm && wx.navigateTo({
                                url: "/pages/webview/webview?url=".concat(encodeURIComponent("https://mp.weixin.qq.com/s/_pMYjUnZ6R5zD7I__SlQZQ"))
                            });
                        }
                    });
                }
            });
        },
        genWXQrcode: function() {
            var n = this;
            return t(e.default.mark(function t() {
                var a, o;
                return e.default.wrap(function(e) {
                    for (;;) switch (e.prev = e.next) {
                      case 0:
                        return e.next = 2, r.getWXQrcode({
                            id: n.$bus.store.get("zpInfo").id
                        });

                      case 2:
                        a = e.sent, o = wx.createBufferURL(a.data), console.log("url11", o), wx.previewImage({
                            urls: [ o ]
                        });

                      case 6:
                      case "end":
                        return e.stop();
                    }
                }, t);
            }))();
        },
        onCloseShare: function() {
            this.setData({
                showShare: !1
            });
        }
    },
    lifetimes: {
        attached: function() {
            var e = this;
            this.$bus.event.export("share:showShare", function() {
                e.setData({
                    showShare: !0
                });
            });
        }
    }
});