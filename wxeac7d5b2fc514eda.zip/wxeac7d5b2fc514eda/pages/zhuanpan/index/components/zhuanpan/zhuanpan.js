var t = require("../../../../../@babel/runtime/helpers/createForOfIteratorHelper"), e = require("../../../../../1D9AF4631787E8AF7BFC9C640BCAD006.js");

Component({
    data: {
        all_weight: 0,
        showItems: []
    },
    properties: {
        radius: {
            type: Number,
            value: 158
        }
    },
    behaviors: [ require("../../../../../725E35821787E8AF14385D85BBFAD006.js"), require("../../../../../8AEC61C01787E8AFEC8A09C7770BD006.js"), e ],
    methods: {
        initItems: function() {
            var e = this.$bus.get("zpInfo").items;
            e.map(function(t, e) {
                return t.index = e, t;
            });
            var i = JSON.parse(JSON.stringify(e)), s = 0;
            i.forEach(function(t) {
                s += t.weight;
            });
            for (var r = 0, a = [], n = 0; n < i.length; n++) {
                var h = e[n];
                h.deg = h.weight / s * 360, 0 === r && (r = h.deg / 2), h.endDeg = r, h.startDeg = r - h.deg, 
                h.status = 0, r = h.startDeg;
                for (var o = 0; o < h.weight; o++) a.push(n);
            }
            if (e[0].weight > 1) for (var u = e[0].weight, g = 0; g < Math.floor(u / 2); g++) a.push(0), 
            a.shift();
            var d, f = JSON.parse(JSON.stringify(e)), l = 0, m = t(f);
            try {
                for (m.s(); !(d = m.n()).done; ) {
                    var p = d.value;
                    0 === l && (l = -p.deg / 2), p.startDeg = l, p.status = 0, p.deg = p.weight / s * 360, 
                    p.endDeg = l + p.deg, l = p.endDeg;
                }
            } catch (t) {
                m.e(t);
            } finally {
                m.f();
            }
            this.$bus.set("showItems", e), this.$bus.set("realItems", f), this.$bus.set("allWeightItems", a), 
            this.setData({
                showItems: e,
                all_weight: s
            });
        },
        initZpRadius: function() {
            var t = wx.getSystemInfoSync(), e = t.windowWidth, i = t.windowHeight, s = Math.floor(.95 * Math.min(e, i) / 2);
            this.setData({
                radius: s
            });
        }
    },
    lifetimes: {
        attached: function() {
            this.$bus.on("page:zpInfoLoaded", this.initItems.bind(this)), this.initZpRadius();
        }
    }
});