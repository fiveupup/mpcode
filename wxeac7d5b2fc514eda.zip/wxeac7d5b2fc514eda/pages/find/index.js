var t = getApp();

Page({
    data: {
        showKs: !1,
        ads: [ {
            title: "领外卖券",
            desc: "100%领到大额外卖券",
            img: "http://pan.jialidun.vip/imgs/shutiao.png",
            weight: 1,
            redirect_type: 3,
            redirect_url: "https://mp.weixin.qq.com/s/mwfSZhvooie64gRknSt1TQ"
        }, {
            title: "关注公众号",
            desc: "发现更多精彩",
            img: "http://pan.jialidun.vip/imgs/gongzhonghao.png",
            redirect_type: 3,
            redirect_url: "https://mp.weixin.qq.com/s/pxanhXArw-ulipfX-tF5ug"
        }, {
            title: "支持万能小转盘",
            desc: "赞赏开发者，去除广告",
            img: "http://pan.jialidun.vip/imgs/zanzhu.png",
            redirect_type: 2,
            path: "/pages/zanzhu/zanzhu"
        }, {
            title: "提建议，反馈问题",
            desc: "有任何问题都可以反馈给我们",
            img: "http://pan.jialidun.vip/imgs/feedback.png",
            click: function() {
                var e, i;
                wx.openEmbeddedMiniProgram({
                    appId: "wx8abaf00ee8c3202e",
                    extraData: {
                        id: "613112",
                        customData: {
                            customInfo: null === (e = t.globalData) || void 0 === e || null === (i = e.userInfo) || void 0 === i ? void 0 : i.openid
                        }
                    }
                });
            }
        } ]
    },
    toAd: function(t) {
        var e = t.currentTarget.dataset.index;
        console.log(e);
        var i = this.data.ads[e];
        i.click && "function" == typeof i.click ? i.click() : 1 === i.redirect_type ? wx.navigateToMiniProgram({
            appId: i.appid,
            path: i.path,
            success: function(t) {}
        }) : 2 === i.redirect_type ? wx.navigateTo({
            url: i.path
        }) : 3 === i.redirect_type && wx.navigateTo({
            url: "/pages/webview/webview?url=".concat(encodeURIComponent(i.redirect_url))
        });
    },
    onLoad: function(t) {},
    onReady: function() {},
    onShow: function() {},
    onHide: function() {},
    onUnload: function() {},
    onPullDownRefresh: function() {},
    onReachBottom: function() {},
    onShareAppMessage: function() {
        return {
            title: "一起来玩万能小转盘吧！",
            path: "/pages/zhuanpan/index/index",
            imageUrl: "http://pan.jialidun.vip/zp/wnxzp.png"
        };
    }
});