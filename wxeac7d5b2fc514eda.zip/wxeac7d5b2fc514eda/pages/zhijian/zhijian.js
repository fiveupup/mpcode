var t = require("../../@babel/runtime/helpers/defineProperty");

Page({
    data: {
        state: "stopped",
        items: []
    },
    ontouchstart: function(e) {
        if ("stopped" == this.data.state) {
            var s = {
                x: e.touches[0].clientX - 50,
                y: e.touches[0].clientY - 50
            };
            this.setData(t({}, "items[".concat(this.data.items.length, "]"), s));
        }
    },
    itemTouchMove: function() {},
    ontouchend: function(t) {
        console.log(t.changedTouches);
        for (var e = t.changedTouches, s = 0; s < e.length; s++) {
            var i = e[s].identifier;
            this.data.items.splice(i, 1), this.setData({
                items: this.data.items
            });
        }
    }
});