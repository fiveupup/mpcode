var _interopRequireDefault = require("../@babel/runtime/helpers/interopRequireDefault");require("../@babel/runtime/helpers/Objectvalues");var _assertThisInitialized2 = require("../@babel/runtime/helpers/assertThisInitialized");require("../@babel/runtime/helpers/Arrayincludes");var _regenerator = _interopRequireDefault(require("../@babel/runtime/regenerator"));var _asyncToGenerator2 = require("../@babel/runtime/helpers/asyncToGenerator");var _objectSpread2 = require("../@babel/runtime/helpers/objectSpread2");var _inherits2 = require("../@babel/runtime/helpers/inherits");var _createSuper2 = require("../@babel/runtime/helpers/createSuper");var _wrapNativeSuper2 = require("../@babel/runtime/helpers/wrapNativeSuper");var _createForOfIteratorHelper2 = require("../@babel/runtime/helpers/createForOfIteratorHelper");var _classCallCheck2 = require("../@babel/runtime/helpers/classCallCheck");var _createClass2 = require("../@babel/runtime/helpers/createClass");var _typeof2 = require("../@babel/runtime/helpers/typeof");var _defineProperty2 = require("../@babel/runtime/helpers/defineProperty");var _slicedToArray2 = require("../@babel/runtime/helpers/slicedToArray");var _toConsumableArray2 = require("../@babel/runtime/helpers/toConsumableArray");function e(e, t) {
  var n = Object.create(null),
      r = e.split(",");

  for (var _o2 = 0; _o2 < r.length; _o2++) {
    n[r[_o2]] = !0;
  }

  return t ? function (e) {
    return !!n[e.toLowerCase()];
  } : function (e) {
    return !!n[e];
  };
}function t(e) {
  if (b(e)) {
    var _n2 = {};

    for (var _r2 = 0; _r2 < e.length; _r2++) {
      var _o3 = e[_r2],
          _i2 = x(_o3) ? s(_o3) : t(_o3);

      if (_i2) for (var _e2 in _i2) {
        _n2[_e2] = _i2[_e2];
      }
    }

    return _n2;
  }

  return x(e) || P(e) ? e : void 0;
}var n = /;(?![^(]*\))/g,
    r = /:([^]+)/,
    o = /\/\*[\s\S]*?\*\//g;function s(e) {
  var t = {};
  return e.replace(o, "").split(n).forEach(function (e) {
    if (e) {
      var _n3 = e.split(r);

      _n3.length > 1 && (t[_n3[0].trim()] = _n3[1].trim());
    }
  }), t;
}function i(e) {
  var t = "";
  if (x(e)) t = e;else if (b(e)) for (var _n4 = 0; _n4 < e.length; _n4++) {
    var _r3 = i(e[_n4]);

    _r3 && (t += _r3 + " ");
  } else if (P(e)) for (var _n5 in e) {
    e[_n5] && (t += _n5 + " ");
  }
  return t.trim();
}var a = function a(e, t) {
  return t && t.__v_isRef ? a(e, t.value) : _(t) ? _defineProperty2({}, "Map(".concat(t.size, ")"), _toConsumableArray2(t.entries()).reduce(function (e, _ref) {
    var _ref2 = _slicedToArray2(_ref, 2),
        t = _ref2[0],
        n = _ref2[1];

    return e["".concat(t, " =>")] = n, e;
  }, {})) : w(t) ? _defineProperty2({}, "Set(".concat(t.size, ")"), _toConsumableArray2(t.values())) : !P(t) || b(t) || T(t) ? t : String(t);
},
    c = {},
    u = [],
    l = function l() {},
    f = function f() {
  return !1;
},
    h = /^on[^a-z]/,
    d = function d(e) {
  return h.test(e);
},
    p = function p(e) {
  return e.startsWith("onUpdate:");
},
    g = Object.assign,
    m = function m(e, t) {
  var n = e.indexOf(t);
  n > -1 && e.splice(n, 1);
},
    y = Object.prototype.hasOwnProperty,
    v = function v(e, t) {
  return y.call(e, t);
},
    b = Array.isArray,
    _ = function _(e) {
  return "[object Map]" === I(e);
},
    w = function w(e) {
  return "[object Set]" === I(e);
},
    k = function k(e) {
  return "function" == typeof e;
},
    x = function x(e) {
  return "string" == typeof e;
},
    S = function S(e) {
  return "symbol" == _typeof2(e);
},
    P = function P(e) {
  return null !== e && "object" == _typeof2(e);
},
    A = function A(e) {
  return P(e) && k(e.then) && k(e.catch);
},
    O = Object.prototype.toString,
    I = function I(e) {
  return O.call(e);
},
    T = function T(e) {
  return "[object Object]" === I(e);
},
    C = function C(e) {
  return x(e) && "NaN" !== e && "-" !== e[0] && "" + parseInt(e, 10) === e;
},
    E = e(",key,ref,ref_for,ref_key,onVnodeBeforeMount,onVnodeMounted,onVnodeBeforeUpdate,onVnodeUpdated,onVnodeBeforeUnmount,onVnodeUnmounted"),
    M = function M(e) {
  var t = Object.create(null);
  return function (n) {
    return t[n] || (t[n] = e(n));
  };
},
    L = /-(\w)/g,
    $ = M(function (e) {
  return e.replace(L, function (e, t) {
    return t ? t.toUpperCase() : "";
  });
}),
    R = /\B([A-Z])/g,
    N = M(function (e) {
  return e.replace(R, "-$1").toLowerCase();
}),
    j = M(function (e) {
  return e.charAt(0).toUpperCase() + e.slice(1);
}),
    D = M(function (e) {
  return e ? "on".concat(j(e)) : "";
}),
    U = function U(e, t) {
  return !Object.is(e, t);
},
    F = function F(e, t) {
  for (var _n6 = 0; _n6 < e.length; _n6++) {
    e[_n6](t);
  }
},
    q = function q(e) {
  var t = parseFloat(e);
  return isNaN(t) ? e : t;
},
    B = "data",
    H = "onShow",
    K = "onHide",
    V = "onLaunch",
    W = "onError",
    z = "onThemeChange",
    J = "onPageNotFound",
    G = "onUnhandledRejection",
    Y = "onLoad",
    Q = "onReady",
    X = "onUnload",
    Z = "onInit",
    ee = "onSaveExitState",
    te = "onResize",
    ne = "onBackPress",
    re = "onPageScroll",
    oe = "onTabItemTap",
    se = "onReachBottom",
    ie = "onPullDownRefresh",
    ae = "onShareTimeline",
    ce = "onAddToFavorites",
    ue = "onShareAppMessage",
    le = "onNavigationBarButtonTap",
    fe = "onNavigationBarSearchInputClicked",
    he = "onNavigationBarSearchInputChanged",
    de = "onNavigationBarSearchInputConfirmed",
    pe = "onNavigationBarSearchInputFocusChanged",
    ge = /:/g;function me(e) {
  var t = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : null;
  var n;
  return function () {
    for (var _len = arguments.length, r = new Array(_len), _key = 0; _key < _len; _key++) {
      r[_key] = arguments[_key];
    }

    return e && (n = e.apply(t, r), e = null), n;
  };
}function ye(e, t) {
  if (!x(t)) return;
  var n = (t = t.replace(/\[(\d+)\]/g, ".$1")).split(".");
  var r = n[0];
  return e || (e = {}), 1 === n.length ? e[r] : ye(e[r], n.slice(1).join("."));
}function ve(e) {
  var t = {};
  return T(e) && Object.keys(e).sort().forEach(function (n) {
    var r = n;
    t[r] = e[r];
  }), Object.keys(t) ? t : e;
}var be = encodeURIComponent;function _e(e) {
  var t = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : be;
  var n = e ? Object.keys(e).map(function (n) {
    var r = e[n];
    return void 0 === _typeof2(r) || null === r ? r = "" : T(r) && (r = JSON.stringify(r)), t(n) + "=" + t(r);
  }).filter(function (e) {
    return e.length > 0;
  }).join("&") : null;
  return n ? "?".concat(n) : "";
}var we = [Z, Y, H, K, X, ne, re, oe, se, ie, ae, ue, ce, ee, le, fe, he, de, pe];var ke = [H, K, V, W, z, J, G, Z, Y, Q, X, te, ne, re, oe, se, ie, ae, ce, ue, ee, le, fe, he, de, pe],
    xe = function () {
  return {
    onPageScroll: 1,
    onShareAppMessage: 2,
    onShareTimeline: 4
  };
}();function Se(e, t) {
  var n = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : !0;
  return !(n && !k(t)) && (ke.indexOf(e) > -1 || 0 === e.indexOf("on"));
}var Pe;var Ae = [];var Oe = me(function (e, t) {
  if (k(e._component.onError)) return t(e);
}),
    Ie = function Ie() {};Ie.prototype = {
  on: function on(e, t, n) {
    var r = this.e || (this.e = {});
    return (r[e] || (r[e] = [])).push({
      fn: t,
      ctx: n
    }), this;
  },
  once: function once(e, t, n) {
    var r = this;

    function o() {
      r.off(e, o), t.apply(n, arguments);
    }

    return o._ = t, this.on(e, o, n);
  },
  emit: function emit(e) {
    for (var t = [].slice.call(arguments, 1), n = ((this.e || (this.e = {}))[e] || []).slice(), r = 0, o = n.length; r < o; r++) {
      n[r].fn.apply(n[r].ctx, t);
    }

    return this;
  },
  off: function off(e, t) {
    var n = this.e || (this.e = {}),
        r = n[e],
        o = [];
    if (r && t) for (var s = 0, i = r.length; s < i; s++) {
      r[s].fn !== t && r[s].fn._ !== t && o.push(r[s]);
    }
    return o.length ? n[e] = o : delete n[e], this;
  }
};var Te = Ie;var Ce = ["{", "}"];var Ee = /^(?:\d)+/,
    Me = /^(?:\w)+/;var Le = "zh-Hans",
    $e = "zh-Hant",
    Re = "en",
    Ne = Object.prototype.hasOwnProperty,
    je = function je(e, t) {
  return Ne.call(e, t);
},
    De = new ( /*#__PURE__*/function () {
  function _class() {
    _classCallCheck2(this, _class);

    this._caches = Object.create(null);
  }

  _createClass2(_class, [{
    key: "interpolate",
    value: function interpolate(e, t) {
      var n = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : Ce;
      if (!t) return [e];
      var r = this._caches[e];
      return r || (r = function (e, _ref5) {
        var _ref6 = _slicedToArray2(_ref5, 2),
            t = _ref6[0],
            n = _ref6[1];

        var r = [];
        var o = 0,
            s = "";

        for (; o < e.length;) {
          var _i3 = e[o++];

          if (_i3 === t) {
            s && r.push({
              type: "text",
              value: s
            }), s = "";
            var _t2 = "";

            for (_i3 = e[o++]; void 0 !== _i3 && _i3 !== n;) {
              _t2 += _i3, _i3 = e[o++];
            }

            var _a2 = _i3 === n,
                _c2 = Ee.test(_t2) ? "list" : _a2 && Me.test(_t2) ? "named" : "unknown";

            r.push({
              value: _t2,
              type: _c2
            });
          } else s += _i3;
        }

        return s && r.push({
          type: "text",
          value: s
        }), r;
      }(e, n), this._caches[e] = r), function (e, t) {
        var n = [];
        var r = 0;
        var o = Array.isArray(t) ? "list" : (s = t, null !== s && "object" == _typeof2(s) ? "named" : "unknown");
        var s;
        if ("unknown" === o) return n;

        for (; r < e.length;) {
          var _s2 = e[r];

          switch (_s2.type) {
            case "text":
              n.push(_s2.value);
              break;

            case "list":
              n.push(t[parseInt(_s2.value, 10)]);
              break;

            case "named":
              "named" === o && n.push(t[_s2.value]);
          }

          r++;
        }

        return n;
      }(r, t);
    }
  }]);

  return _class;
}())();function Ue(e, t) {
  if (!e) return;
  if (e = e.trim().replace(/_/g, "-"), t && t[e]) return e;
  if ("chinese" === (e = e.toLowerCase())) return Le;
  if (0 === e.indexOf("zh")) return e.indexOf("-hans") > -1 ? Le : e.indexOf("-hant") > -1 ? $e : (n = e, ["-tw", "-hk", "-mo", "-cht"].find(function (e) {
    return -1 !== n.indexOf(e);
  }) ? $e : Le);
  var n;

  var r = function (e, t) {
    return t.find(function (t) {
      return 0 === e.indexOf(t);
    });
  }(e, [Re, "fr", "es"]);

  return r || void 0;
}var Fe = /*#__PURE__*/function () {
  function Fe(_ref7) {
    var e = _ref7.locale,
        t = _ref7.fallbackLocale,
        n = _ref7.messages,
        r = _ref7.watcher,
        o = _ref7.formater;

    _classCallCheck2(this, Fe);

    this.locale = Re, this.fallbackLocale = Re, this.message = {}, this.messages = {}, this.watchers = [], t && (this.fallbackLocale = t), this.formater = o || De, this.messages = n || {}, this.setLocale(e || Re), r && this.watchLocale(r);
  }

  _createClass2(Fe, [{
    key: "setLocale",
    value: function setLocale(e) {
      var _this = this;

      var t = this.locale;
      this.locale = Ue(e, this.messages) || this.fallbackLocale, this.messages[this.locale] || (this.messages[this.locale] = {}), this.message = this.messages[this.locale], t !== this.locale && this.watchers.forEach(function (e) {
        e(_this.locale, t);
      });
    }
  }, {
    key: "getLocale",
    value: function getLocale() {
      return this.locale;
    }
  }, {
    key: "watchLocale",
    value: function watchLocale(e) {
      var _this2 = this;

      var t = this.watchers.push(e) - 1;
      return function () {
        _this2.watchers.splice(t, 1);
      };
    }
  }, {
    key: "add",
    value: function add(e, t) {
      var n = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : !0;
      var r = this.messages[e];
      r ? n ? Object.assign(r, t) : Object.keys(t).forEach(function (e) {
        je(r, e) || (r[e] = t[e]);
      }) : this.messages[e] = t;
    }
  }, {
    key: "f",
    value: function f(e, t, n) {
      return this.formater.interpolate(e, t, n).join("");
    }
  }, {
    key: "t",
    value: function t(e, _t3, n) {
      var r = this.message;
      return "string" == typeof _t3 ? (_t3 = Ue(_t3, this.messages)) && (r = this.messages[_t3]) : n = _t3, je(r, e) ? this.formater.interpolate(r[e], n).join("") : (console.warn("Cannot translate the value of keypath ".concat(e, ". Use the value of keypath as default.")), e);
    }
  }]);

  return Fe;
}();function qe(e) {
  var _ref8;

  var t = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : {};
  var n = arguments.length > 2 ? arguments[2] : undefined;
  var r = arguments.length > 3 ? arguments[3] : undefined;
  "string" != typeof e && (_ref8 = [t, e], e = _ref8[0], t = _ref8[1], _ref8), "string" != typeof e && (e = void 0 !== On && On.getLocale ? On.getLocale() : "undefined" != typeof global && global.getLocale ? global.getLocale() : Re), "string" != typeof n && (n = "undefined" != typeof __uniConfig && __uniConfig.fallbackLocale || Re);
  var o = new Fe({
    locale: e,
    fallbackLocale: n,
    messages: t,
    watcher: r
  });

  var _s3 = function s(e, t) {
    if ("function" != typeof getApp) _s3 = function s(e, t) {
      return o.t(e, t);
    };else {
      var _e3 = !1;

      _s3 = function s(t, n) {
        var r = getApp().$vm;
        return r && (r.$locale, _e3 || (_e3 = !0, function (e, t) {
          e.$watchLocale ? e.$watchLocale(function (e) {
            t.setLocale(e);
          }) : e.$watch(function () {
            return e.$locale;
          }, function (e) {
            t.setLocale(e);
          });
        }(r, o))), o.t(t, n);
      };
    }
    return _s3(e, t);
  };

  return {
    i18n: o,
    f: function f(e, t, n) {
      return o.f(e, t, n);
    },
    t: function t(e, _t4) {
      return _s3(e, _t4);
    },
    add: function add(e, t) {
      var n = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : !0;
      return o.add(e, t, n);
    },
    watch: function watch(e) {
      return o.watchLocale(e);
    },
    getLocale: function getLocale() {
      return o.getLocale();
    },
    setLocale: function setLocale(e) {
      return o.setLocale(e);
    }
  };
}function Be(e) {
  return function () {
    try {
      return e.apply(e, arguments);
    } catch (Mc) {
      console.error(Mc);
    }
  };
}var He = 1;var Ke = {};function Ve(e, t, n) {
  if ("number" == typeof e) {
    var _r4 = Ke[e];
    if (_r4) return _r4.keepAlive || delete Ke[e], _r4.callback(t, n);
  }

  return t;
}var We = "success",
    ze = "fail",
    Je = "complete";function Ge(e) {
  var t = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : {};

  var _ref9 = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : {},
      n = _ref9.beforeAll,
      r = _ref9.beforeSuccess;

  T(t) || (t = {});

  var _ref10 = function (e) {
    var t = {};

    for (var _n7 in e) {
      var _r5 = e[_n7];
      k(_r5) && (t[_n7] = Be(_r5), delete e[_n7]);
    }

    return t;
  }(t),
      o = _ref10.success,
      s = _ref10.fail,
      i = _ref10.complete,
      a = k(o),
      c = k(s),
      u = k(i),
      l = He++;

  return function (e, t, n) {
    var r = arguments.length > 3 && arguments[3] !== undefined ? arguments[3] : !1;
    Ke[e] = {
      name: t,
      keepAlive: r,
      callback: n
    };
  }(l, e, function (l) {
    (l = l || {}).errMsg = function (e, t) {
      return e && -1 !== e.indexOf(":fail") ? t + e.substring(e.indexOf(":fail")) : t + ":ok";
    }(l.errMsg, e), k(n) && n(l), l.errMsg === e + ":ok" ? (k(r) && r(l, t), a && o(l)) : c && s(l), u && i(l);
  }), l;
}var Ye = "success",
    Qe = "fail",
    Xe = "complete",
    Ze = {},
    et = {};function tt(e, t) {
  return function (n) {
    return e(n, t) || n;
  };
}function nt(e, t, n) {
  var r = !1;

  for (var _o4 = 0; _o4 < e.length; _o4++) {
    var _s4 = e[_o4];
    if (r) r = Promise.resolve(tt(_s4, n));else {
      var _e4 = _s4(t, n);

      if (A(_e4) && (r = Promise.resolve(_e4)), !1 === _e4) return {
        then: function then() {},
        catch: function _catch() {}
      };
    }
  }

  return r || {
    then: function then(e) {
      return e(t);
    },
    catch: function _catch() {}
  };
}function rt(e) {
  var t = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : {};
  return [Ye, Qe, Xe].forEach(function (n) {
    var r = e[n];
    if (!b(r)) return;
    var o = t[n];

    t[n] = function (e) {
      nt(r, e, t).then(function (e) {
        return k(o) && o(e) || e;
      });
    };
  }), t;
}function ot(e, t) {
  var n = [];
  b(Ze.returnValue) && n.push.apply(n, _toConsumableArray2(Ze.returnValue));
  var r = et[e];
  return r && b(r.returnValue) && n.push.apply(n, _toConsumableArray2(r.returnValue)), n.forEach(function (e) {
    t = e(t) || t;
  }), t;
}function st(e) {
  var t = Object.create(null);
  Object.keys(Ze).forEach(function (e) {
    "returnValue" !== e && (t[e] = Ze[e].slice());
  });
  var n = et[e];
  return n && Object.keys(n).forEach(function (e) {
    "returnValue" !== e && (t[e] = (t[e] || []).concat(n[e]));
  }), t;
}function it(e, t, n, r) {
  var o = st(e);

  if (o && Object.keys(o).length) {
    if (b(o.invoke)) {
      return nt(o.invoke, n).then(function (n) {
        return t.apply(void 0, [rt(st(e), n)].concat(_toConsumableArray2(r)));
      });
    }

    return t.apply(void 0, [rt(o, n)].concat(_toConsumableArray2(r)));
  }

  return t.apply(void 0, [n].concat(_toConsumableArray2(r)));
}function at(e, t) {
  return function () {
    var n = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {};

    for (var _len2 = arguments.length, r = new Array(_len2 > 1 ? _len2 - 1 : 0), _key2 = 1; _key2 < _len2; _key2++) {
      r[_key2 - 1] = arguments[_key2];
    }

    return function (e) {
      return !(!T(e) || ![We, ze, Je].find(function (t) {
        return k(e[t]);
      }));
    }(n) ? ot(e, it(e, t, n, r)) : ot(e, new Promise(function (o, s) {
      it(e, t, g(n, {
        success: o,
        fail: s
      }), r);
    }));
  };
}function ct(e, t, n, r) {
  return Ve(e, g({
    errMsg: t + ":fail" + (n ? " " + n : "")
  }, r));
}function ut(e, t, n, r) {
  if (r && r.beforeInvoke) {
    var _e5 = r.beforeInvoke(t);

    if (x(_e5)) return _e5;
  }

  var o = function (e, t) {
    var n = e[0];
    if (!t || !T(t.formatArgs) && T(n)) return;
    var r = t.formatArgs,
        o = Object.keys(r);

    for (var _s5 = 0; _s5 < o.length; _s5++) {
      var _t5 = o[_s5],
          _i4 = r[_t5];

      if (k(_i4)) {
        var _r6 = _i4(e[0][_t5], n);

        if (x(_r6)) return _r6;
      } else v(n, _t5) || (n[_t5] = _i4);
    }
  }(t, r);

  if (o) return o;
}function lt(e, t, n, r) {
  return function (n) {
    var o = Ge(e, n, r),
        s = ut(0, [n], 0, r);
    return s ? ct(o, e, s) : t(n, {
      resolve: function resolve(t) {
        return function (e, t, n) {
          return Ve(e, g(n || {}, {
            errMsg: t + ":ok"
          }));
        }(o, e, t);
      },
      reject: function reject(t, n) {
        return ct(o, e, function (e) {
          return !e || x(e) ? e : e.stack ? (console.error(e.message + "\n" + e.stack), e.message) : e;
        }(t), n);
      }
    });
  };
}function ft(e, t, n, r) {
  return function (e, t, n, r) {
    return function () {
      for (var _len3 = arguments.length, e = new Array(_len3), _key3 = 0; _key3 < _len3; _key3++) {
        e[_key3] = arguments[_key3];
      }

      var n = ut(0, e, 0, r);
      if (n) throw new Error(n);
      return t.apply(null, e);
    };
  }(0, t, 0, r);
}var ht = !1,
    dt = 0,
    pt = 0;function gt() {
  var _wx$getSystemInfoSync = wx.getSystemInfoSync(),
      e = _wx$getSystemInfoSync.platform,
      t = _wx$getSystemInfoSync.pixelRatio,
      n = _wx$getSystemInfoSync.windowWidth;

  dt = n, pt = t, ht = "ios" === e;
}var mt = ft(0, function (e, t) {
  if (0 === dt && gt(), 0 === (e = Number(e))) return 0;
  var n = e / 750 * (t || dt);
  return n < 0 && (n = -n), n = Math.floor(n + 1e-4), 0 === n && (n = 1 !== pt && ht ? .5 : 1), e < 0 ? -n : n;
});function yt(e, t) {
  Object.keys(t).forEach(function (n) {
    k(t[n]) && (e[n] = function (e, t) {
      var n = t ? e ? e.concat(t) : b(t) ? t : [t] : e;
      return n ? function (e) {
        var t = [];

        for (var _n8 = 0; _n8 < e.length; _n8++) {
          -1 === t.indexOf(e[_n8]) && t.push(e[_n8]);
        }

        return t;
      }(n) : n;
    }(e[n], t[n]));
  });
}function vt(e, t) {
  e && t && Object.keys(t).forEach(function (n) {
    var r = e[n],
        o = t[n];
    b(r) && k(o) && m(r, o);
  });
}var bt = ft(0, function (e, t) {
  x(e) && T(t) ? yt(et[e] || (et[e] = {}), t) : T(e) && yt(Ze, e);
}),
    _t = ft(0, function (e, t) {
  x(e) ? T(t) ? vt(et[e], t) : delete et[e] : T(e) && vt(Ze, e);
}),
    wt = new Te(),
    kt = ft(0, function (e, t) {
  return wt.on(e, t), function () {
    return wt.off(e, t);
  };
}),
    xt = ft(0, function (e, t) {
  return wt.once(e, t), function () {
    return wt.off(e, t);
  };
}),
    St = ft(0, function (e, t) {
  e ? (b(e) || (e = [e]), e.forEach(function (e) {
    return wt.off(e, t);
  })) : wt.e = {};
}),
    Pt = ft(0, function (e) {
  for (var _len4 = arguments.length, t = new Array(_len4 > 1 ? _len4 - 1 : 0), _key4 = 1; _key4 < _len4; _key4++) {
    t[_key4 - 1] = arguments[_key4];
  }

  wt.emit.apply(wt, [e].concat(t));
});var At, Ot, It;function Tt(e) {
  try {
    return JSON.parse(e);
  } catch (Mc) {}

  return e;
}var Ct = [];function Et(e, t) {
  Ct.forEach(function (n) {
    n(e, t);
  }), Ct.length = 0;
}var Mt = at(Lt = "getPushClientId", function (e, t, n, r) {
  return lt(e, t, 0, r);
}(Lt, function (e, _ref11) {
  var t = _ref11.resolve,
      n = _ref11.reject;
  Promise.resolve().then(function () {
    void 0 === It && (It = !1, At = "", Ot = "uniPush is not enabled"), Ct.push(function (e, r) {
      e ? t({
        cid: e
      }) : n(r);
    }), void 0 !== At && Et(At, Ot);
  });
}, 0, $t));var Lt, $t;var Rt = [],
    Nt = /^\$|getLocale|setLocale|sendNativeEvent|restoreGlobal|requireGlobal|getCurrentSubNVue|getMenuButtonBoundingClientRect|^report|interceptors|Interceptor$|getSubNVueById|requireNativePlugin|upx2px|hideKeyboard|canIUse|^create|Sync$|Manager$|base64ToArrayBuffer|arrayBufferToBase64|getDeviceInfo|getAppBaseInfo|getWindowInfo|getSystemSetting|getAppAuthorizeSetting/,
    jt = /^create|Manager$/,
    Dt = ["createBLEConnection"],
    Ut = ["createBLEConnection"],
    Ft = /^on|^off/;function qt(e) {
  return jt.test(e) && -1 === Dt.indexOf(e);
}function Bt(e) {
  return Nt.test(e) && -1 === Ut.indexOf(e);
}function Ht(e) {
  return !(qt(e) || Bt(e) || function (e) {
    return Ft.test(e) && "onPush" !== e;
  }(e));
}function Kt(e, t) {
  return Ht(e) && k(t) ? function () {
    var n = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {};

    for (var _len5 = arguments.length, r = new Array(_len5 > 1 ? _len5 - 1 : 0), _key5 = 1; _key5 < _len5; _key5++) {
      r[_key5 - 1] = arguments[_key5];
    }

    return k(n.success) || k(n.fail) || k(n.complete) ? ot(e, it(e, t, n, r)) : ot(e, new Promise(function (o, s) {
      it(e, t, g({}, n, {
        success: o,
        fail: s
      }), r);
    }));
  } : t;
}Promise.prototype.finally || (Promise.prototype.finally = function (e) {
  var t = this.constructor;
  return this.then(function (n) {
    return t.resolve(e && e()).then(function () {
      return n;
    });
  }, function (n) {
    return t.resolve(e && e()).then(function () {
      throw n;
    });
  });
});var Vt = ["success", "fail", "cancel", "complete"];var Wt = function Wt() {
  var e = k(getApp) && getApp({
    allowDefault: !0
  });
  return e && e.$vm ? e.$vm.$locale : Ue(wx.getSystemInfoSync().language) || Re;
},
    zt = [];"undefined" != typeof global && (global.getLocale = Wt);var Jt = "__DC_STAT_UUID";var Gt;function Yt() {
  var e = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : wx;
  return function (t, n) {
    Gt = Gt || e.getStorageSync(Jt), Gt || (Gt = Date.now() + "" + Math.floor(1e7 * Math.random()), wx.setStorage({
      key: Jt,
      data: Gt
    })), n.deviceId = Gt;
  };
}function Qt(e, t) {
  if (e.safeArea) {
    var _n9 = e.safeArea;
    t.safeAreaInsets = {
      top: _n9.top,
      left: _n9.left,
      right: e.windowWidth - _n9.right,
      bottom: e.screenHeight - _n9.bottom
    };
  }
}function Xt(e, t) {
  var n = e.deviceType || "phone";
  {
    var _e6 = {
      ipad: "pad",
      windows: "pc",
      mac: "pc"
    },
        _r7 = Object.keys(_e6),
        _o5 = t.toLocaleLowerCase();

    for (var _t6 = 0; _t6 < _r7.length; _t6++) {
      var _s6 = _r7[_t6];

      if (-1 !== _o5.indexOf(_s6)) {
        n = _e6[_s6];
        break;
      }
    }
  }
  return n;
}function Zt(e) {
  var t = e;
  return t && (t = t.toLocaleLowerCase()), t;
}function en(e) {
  return Wt ? Wt() : e;
}function tn(e) {
  var t = e.hostName || "WeChat";
  return e.environment ? t = e.environment : e.host && e.host.env && (t = e.host.env), t;
}var nn = {
  returnValue: function returnValue(e, t) {
    Qt(e, t), Yt()(e, t), function (e, t) {
      var _e$brand = e.brand,
          n = _e$brand === void 0 ? "" : _e$brand,
          _e$model = e.model,
          r = _e$model === void 0 ? "" : _e$model,
          _e$system = e.system,
          o = _e$system === void 0 ? "" : _e$system,
          _e$language = e.language,
          s = _e$language === void 0 ? "" : _e$language,
          i = e.theme,
          a = e.version,
          c = e.platform,
          u = e.fontSizeSetting,
          l = e.SDKVersion,
          f = e.pixelRatio,
          h = e.deviceOrientation;
      var d = "",
          p = "";
      d = o.split(" ")[0] || "", p = o.split(" ")[1] || "";
      var m = a,
          y = Xt(e, r),
          v = Zt(n),
          b = tn(e),
          _ = h,
          w = f,
          k = l;
      var x = s.replace(/_/g, "-"),
          S = {
        appId: "__UNI__BC0D321",
        appName: "Spin-pro",
        appVersion: "1.0.0",
        appVersionCode: "100",
        appLanguage: en(x),
        uniCompileVersion: "3.7.11",
        uniRuntimeVersion: "3.7.11",
        uniPlatform: "mp-weixin",
        deviceBrand: v,
        deviceModel: r,
        deviceType: y,
        devicePixelRatio: w,
        deviceOrientation: _,
        osName: d.toLocaleLowerCase(),
        osVersion: p,
        hostTheme: i,
        hostVersion: m,
        hostLanguage: x,
        hostName: b,
        hostSDKVersion: k,
        hostFontSizeSetting: u,
        windowTop: 0,
        windowBottom: 0,
        osLanguage: void 0,
        osTheme: void 0,
        ua: void 0,
        hostPackageName: void 0,
        browserName: void 0,
        browserVersion: void 0
      };
      g(t, S);
    }(e, t);
  }
},
    rn = nn,
    on = {
  args: function args(e, t) {
    var n = parseInt(e.current);
    if (isNaN(n)) return;
    var r = e.urls;
    if (!b(r)) return;
    var o = r.length;
    return o ? (n < 0 ? n = 0 : n >= o && (n = o - 1), n > 0 ? (t.current = r[n], t.urls = r.filter(function (e, t) {
      return !(t < n) || e !== r[n];
    })) : t.current = r[0], {
      indicator: !1,
      loop: !1
    }) : void 0;
  }
},
    sn = {
  args: function args(e, t) {
    t.alertText = e.title;
  }
},
    an = {
  returnValue: function returnValue(e, t) {
    var n = e.brand,
        r = e.model;
    var o = Xt(e, r),
        s = Zt(n);
    Yt()(e, t), t = ve(g(t, {
      deviceType: o,
      deviceBrand: s,
      deviceModel: r
    }));
  }
},
    cn = {
  returnValue: function returnValue(e, t) {
    var n = e.version,
        r = e.language,
        o = e.SDKVersion,
        s = e.theme;
    var i = tn(e),
        a = r.replace(/_/g, "-");
    t = ve(g(t, {
      hostVersion: n,
      hostLanguage: a,
      hostName: i,
      hostSDKVersion: o,
      hostTheme: s,
      appId: "__UNI__BC0D321",
      appName: "Spin-pro",
      appVersion: "1.0.0",
      appVersionCode: "100",
      appLanguage: en(a)
    }));
  }
},
    un = {
  returnValue: function returnValue(e, t) {
    Qt(e, t), t = ve(g(t, {
      windowTop: 0,
      windowBottom: 0
    }));
  }
},
    ln = {
  $on: kt,
  $off: St,
  $once: xt,
  $emit: Pt,
  upx2px: mt,
  interceptors: {},
  addInterceptor: bt,
  removeInterceptor: _t,
  onCreateVueApp: function onCreateVueApp(e) {
    if (Pe) return e(Pe);
    Ae.push(e);
  },
  invokeCreateVueAppHook: function invokeCreateVueAppHook(e) {
    Pe = e, Ae.forEach(function (t) {
      return t(e);
    });
  },
  getLocale: Wt,
  setLocale: function setLocale(e) {
    var t = k(getApp) && getApp();
    if (!t) return !1;
    return t.$vm.$locale !== e && (t.$vm.$locale = e, zt.forEach(function (t) {
      return t({
        locale: e
      });
    }), !0);
  },
  onLocaleChange: function onLocaleChange(e) {
    -1 === zt.indexOf(e) && zt.push(e);
  },
  getPushClientId: Mt,
  onPushMessage: function onPushMessage(e) {
    -1 === Rt.indexOf(e) && Rt.push(e);
  },
  offPushMessage: function offPushMessage(e) {
    if (e) {
      var _t7 = Rt.indexOf(e);

      _t7 > -1 && Rt.splice(_t7, 1);
    } else Rt.length = 0;
  },
  invokePushCallback: function invokePushCallback(e) {
    if ("enabled" === e.type) It = !0;else if ("clientId" === e.type) At = e.cid, Ot = e.errMsg, Et(At, e.errMsg);else if ("pushMsg" === e.type) {
      var _t8 = {
        type: "receive",
        data: Tt(e.message)
      };

      for (var _e7 = 0; _e7 < Rt.length; _e7++) {
        if ((0, Rt[_e7])(_t8), _t8.stopped) break;
      }
    } else "click" === e.type && Rt.forEach(function (t) {
      t({
        type: "click",
        data: Tt(e.message)
      });
    });
  }
};var fn = ["qy", "env", "error", "version", "lanDebug", "cloud", "serviceMarket", "router", "worklet"],
    hn = ["lanDebug", "router", "worklet"],
    dn = wx.getLaunchOptionsSync ? wx.getLaunchOptionsSync() : null;function pn(e) {
  return (!dn || 1154 !== dn.scene || !hn.includes(e)) && (fn.indexOf(e) > -1 || "function" == typeof wx[e]);
}function gn() {
  var e = {};

  for (var _t9 in wx) {
    pn(_t9) && (e[_t9] = wx[_t9]);
  }

  return "undefined" != typeof globalThis && (globalThis.wx = e), e;
}var mn = ["__route__", "__wxExparserNodeId__", "__wxWebviewId__"],
    yn = (vn = {
  oauth: ["weixin"],
  share: ["weixin"],
  payment: ["wxpay"],
  push: ["weixin"]
}, function (_ref12) {
  var e = _ref12.service,
      t = _ref12.success,
      n = _ref12.fail,
      r = _ref12.complete;
  var o;
  vn[e] ? (o = {
    errMsg: "getProvider:ok",
    service: e,
    provider: vn[e]
  }, k(t) && t(o)) : (o = {
    errMsg: "getProvider:fail:服务[" + e + "]不存在"
  }, k(n) && n(o)), k(r) && r(o);
});var vn;var bn = gn();var _n = bn.getAppBaseInfo && bn.getAppBaseInfo();_n || (_n = bn.getSystemInfoSync());var wn = _n ? _n.host : null,
    kn = wn && "SAAASDK" === wn.env ? bn.miniapp.shareVideoMessage : bn.shareVideoMessage;var xn = Object.freeze({
  __proto__: null,
  createSelectorQuery: function createSelectorQuery() {
    var e = bn.createSelectorQuery(),
        t = e.in;
    return e.in = function (e) {
      return t.call(this, function (e) {
        var t = Object.create(null);
        return mn.forEach(function (n) {
          t[n] = e[n];
        }), t;
      }(e));
    }, e;
  },
  getProvider: yn,
  shareVideoMessage: kn
});var Sn = {
  args: function args(e, t) {
    e.compressedHeight && !t.compressHeight && (t.compressHeight = e.compressedHeight), e.compressedWidth && !t.compressWidth && (t.compressWidth = e.compressedWidth);
  }
};var Pn = Object.freeze({
  __proto__: null,
  compressImage: Sn,
  getAppAuthorizeSetting: {
    returnValue: function returnValue(e, t) {
      var n = e.locationReducedAccuracy;
      t.locationAccuracy = "unsupported", !0 === n ? t.locationAccuracy = "reduced" : !1 === n && (t.locationAccuracy = "full");
    }
  },
  getAppBaseInfo: cn,
  getDeviceInfo: an,
  getSystemInfo: nn,
  getSystemInfoSync: rn,
  getWindowInfo: un,
  previewImage: on,
  redirectTo: {},
  showActionSheet: sn
});var An = gn();var On = function (e, t) {
  var n = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : wx;

  var r = function (e) {
    function t(e, t, n) {
      return function (o) {
        return t(r(e, o, n));
      };
    }

    function n(e, n) {
      var r = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : {};
      var o = arguments.length > 3 && arguments[3] !== undefined ? arguments[3] : {};
      var s = arguments.length > 4 && arguments[4] !== undefined ? arguments[4] : !1;

      if (T(n)) {
        var _i5 = !0 === s ? n : {};

        k(r) && (r = r(n, _i5) || {});

        for (var _a3 in n) {
          if (v(r, _a3)) {
            var _t10 = r[_a3];
            k(_t10) && (_t10 = _t10(n[_a3], n, _i5)), _t10 ? x(_t10) ? _i5[_t10] = n[_a3] : T(_t10) && (_i5[_t10.name ? _t10.name : _a3] = _t10.value) : console.warn("\u5FAE\u4FE1\u5C0F\u7A0B\u5E8F ".concat(e, " \u6682\u4E0D\u652F\u6301 ").concat(_a3));
          } else if (-1 !== Vt.indexOf(_a3)) {
            var _r8 = n[_a3];
            k(_r8) && (_i5[_a3] = t(e, _r8, o));
          } else s || v(_i5, _a3) || (_i5[_a3] = n[_a3]);
        }

        return _i5;
      }

      return k(n) && (n = t(e, n, o)), n;
    }

    function r(t, r, o) {
      var s = arguments.length > 3 && arguments[3] !== undefined ? arguments[3] : !1;
      return k(e.returnValue) && (r = e.returnValue(t, r)), n(t, r, o, {}, s);
    }

    return function (t, o) {
      if (!v(e, t)) return o;
      var s = e[t];
      return s ? function (e, o) {
        var i = s;
        k(s) && (i = s(e));
        var a = [e = n(t, e, i.args, i.returnValue)];
        void 0 !== o && a.push(o);
        var c = wx[i.name || t].apply(wx, a);
        return Bt(t) ? r(t, c, i.returnValue, qt(t)) : c;
      } : function () {
        console.error("\u5FAE\u4FE1\u5C0F\u7A0B\u5E8F \u6682\u4E0D\u652F\u6301".concat(t));
      };
    };
  }(t);

  return new Proxy({}, {
    get: function get(t, o) {
      return v(t, o) ? t[o] : v(e, o) ? Kt(o, e[o]) : v(ln, o) ? Kt(o, ln[o]) : Kt(o, r(o, n[o]));
    }
  });
}(xn, Pn, An);var In;var Tn = /*#__PURE__*/function () {
  function Tn() {
    var e = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : !1;

    _classCallCheck2(this, Tn);

    this.detached = e, this._active = !0, this.effects = [], this.cleanups = [], this.parent = In, !e && In && (this.index = (In.scopes || (In.scopes = [])).push(this) - 1);
  }

  _createClass2(Tn, [{
    key: "active",
    get: function get() {
      return this._active;
    }
  }, {
    key: "run",
    value: function run(e) {
      if (this._active) {
        var _t11 = In;

        try {
          return In = this, e();
        } finally {
          In = _t11;
        }
      }
    }
  }, {
    key: "on",
    value: function on() {
      In = this;
    }
  }, {
    key: "off",
    value: function off() {
      In = this.parent;
    }
  }, {
    key: "stop",
    value: function stop(e) {
      if (this._active) {
        var _t12, _n10;

        for (_t12 = 0, _n10 = this.effects.length; _t12 < _n10; _t12++) {
          this.effects[_t12].stop();
        }

        for (_t12 = 0, _n10 = this.cleanups.length; _t12 < _n10; _t12++) {
          this.cleanups[_t12]();
        }

        if (this.scopes) for (_t12 = 0, _n10 = this.scopes.length; _t12 < _n10; _t12++) {
          this.scopes[_t12].stop(!0);
        }

        if (!this.detached && this.parent && !e) {
          var _e8 = this.parent.scopes.pop();

          _e8 && _e8 !== this && (this.parent.scopes[this.index] = _e8, _e8.index = this.index);
        }

        this.parent = void 0, this._active = !1;
      }
    }
  }]);

  return Tn;
}();var Cn = function Cn(e) {
  var t = new Set(e);
  return t.w = 0, t.n = 0, t;
},
    En = function En(e) {
  return (e.w & Rn) > 0;
},
    Mn = function Mn(e) {
  return (e.n & Rn) > 0;
},
    Ln = new WeakMap();var $n = 0,
    Rn = 1;var Nn;var jn = Symbol(""),
    Dn = Symbol("");var Un = /*#__PURE__*/function () {
  function Un(e) {
    var t = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : null;
    var n = arguments.length > 2 ? arguments[2] : undefined;

    _classCallCheck2(this, Un);

    this.fn = e, this.scheduler = t, this.active = !0, this.deps = [], this.parent = void 0, function (e) {
      var t = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : In;
      t && t.active && t.effects.push(e);
    }(this, n);
  }

  _createClass2(Un, [{
    key: "run",
    value: function run() {
      if (!this.active) return this.fn();
      var e = Nn,
          t = qn;

      for (; e;) {
        if (e === this) return;
        e = e.parent;
      }

      try {
        return this.parent = Nn, Nn = this, qn = !0, Rn = 1 << ++$n, $n <= 30 ? function (_ref13) {
          var e = _ref13.deps;
          if (e.length) for (var _t13 = 0; _t13 < e.length; _t13++) {
            e[_t13].w |= Rn;
          }
        }(this) : Fn(this), this.fn();
      } finally {
        $n <= 30 && function (e) {
          var t = e.deps;

          if (t.length) {
            var _n11 = 0;

            for (var _r9 = 0; _r9 < t.length; _r9++) {
              var _o6 = t[_r9];
              En(_o6) && !Mn(_o6) ? _o6.delete(e) : t[_n11++] = _o6, _o6.w &= ~Rn, _o6.n &= ~Rn;
            }

            t.length = _n11;
          }
        }(this), Rn = 1 << --$n, Nn = this.parent, qn = t, this.parent = void 0, this.deferStop && this.stop();
      }
    }
  }, {
    key: "stop",
    value: function stop() {
      Nn === this ? this.deferStop = !0 : this.active && (Fn(this), this.onStop && this.onStop(), this.active = !1);
    }
  }]);

  return Un;
}();function Fn(e) {
  var t = e.deps;

  if (t.length) {
    for (var _n12 = 0; _n12 < t.length; _n12++) {
      t[_n12].delete(e);
    }

    t.length = 0;
  }
}var qn = !0;var Bn = [];function Hn() {
  Bn.push(qn), qn = !1;
}function Kn() {
  var e = Bn.pop();
  qn = void 0 === e || e;
}function Vn(e, t, n) {
  if (qn && Nn) {
    var _t14 = Ln.get(e);

    _t14 || Ln.set(e, _t14 = new Map());

    var _r10 = _t14.get(n);

    _r10 || _t14.set(n, _r10 = Cn()), Wn(_r10);
  }
}function Wn(e, t) {
  var n = !1;
  $n <= 30 ? Mn(e) || (e.n |= Rn, n = !En(e)) : n = !e.has(Nn), n && (e.add(Nn), Nn.deps.push(e));
}function zn(e, t, n, r, o, s) {
  var i = Ln.get(e);
  if (!i) return;
  var a = [];
  if ("clear" === t) a = _toConsumableArray2(i.values());else if ("length" === n && b(e)) {
    var _e9 = Number(r);

    i.forEach(function (t, n) {
      ("length" === n || n >= _e9) && a.push(t);
    });
  } else switch (void 0 !== n && a.push(i.get(n)), t) {
    case "add":
      b(e) ? C(n) && a.push(i.get("length")) : (a.push(i.get(jn)), _(e) && a.push(i.get(Dn)));
      break;

    case "delete":
      b(e) || (a.push(i.get(jn)), _(e) && a.push(i.get(Dn)));
      break;

    case "set":
      _(e) && a.push(i.get(jn));
  }
  if (1 === a.length) a[0] && Jn(a[0]);else {
    var _e10 = [];

    var _iterator = _createForOfIteratorHelper2(a),
        _step;

    try {
      for (_iterator.s(); !(_step = _iterator.n()).done;) {
        var _t15 = _step.value;
        _t15 && _e10.push.apply(_e10, _toConsumableArray2(_t15));
      }
    } catch (err) {
      _iterator.e(err);
    } finally {
      _iterator.f();
    }

    Jn(Cn(_e10));
  }
}function Jn(e, t) {
  var n = b(e) ? e : _toConsumableArray2(e);

  var _iterator2 = _createForOfIteratorHelper2(n),
      _step2;

  try {
    for (_iterator2.s(); !(_step2 = _iterator2.n()).done;) {
      var _r11 = _step2.value;
      _r11.computed && Gn(_r11);
    }
  } catch (err) {
    _iterator2.e(err);
  } finally {
    _iterator2.f();
  }

  var _iterator3 = _createForOfIteratorHelper2(n),
      _step3;

  try {
    for (_iterator3.s(); !(_step3 = _iterator3.n()).done;) {
      var _r12 = _step3.value;
      _r12.computed || Gn(_r12);
    }
  } catch (err) {
    _iterator3.e(err);
  } finally {
    _iterator3.f();
  }
}function Gn(e, t) {
  (e !== Nn || e.allowRecurse) && (e.scheduler ? e.scheduler() : e.run());
}var Yn = e("__proto__,__v_isRef,__isVue"),
    Qn = new Set(Object.getOwnPropertyNames(Symbol).filter(function (e) {
  return "arguments" !== e && "caller" !== e;
}).map(function (e) {
  return Symbol[e];
}).filter(S)),
    Xn = or(),
    Zn = or(!1, !0),
    er = or(!0),
    tr = nr();function nr() {
  var e = {};
  return ["includes", "indexOf", "lastIndexOf"].forEach(function (t) {
    e[t] = function () {
      var n = qr(this);

      for (var _t16 = 0, _o7 = this.length; _t16 < _o7; _t16++) {
        Vn(n, 0, _t16 + "");
      }

      for (var _len6 = arguments.length, e = new Array(_len6), _key6 = 0; _key6 < _len6; _key6++) {
        e[_key6] = arguments[_key6];
      }

      var r = n[t].apply(n, e);
      return -1 === r || !1 === r ? n[t].apply(n, _toConsumableArray2(e.map(qr))) : r;
    };
  }), ["push", "pop", "shift", "unshift", "splice"].forEach(function (t) {
    e[t] = function () {
      Hn();

      for (var _len7 = arguments.length, e = new Array(_len7), _key7 = 0; _key7 < _len7; _key7++) {
        e[_key7] = arguments[_key7];
      }

      var n = qr(this)[t].apply(this, e);
      return Kn(), n;
    };
  }), e;
}function rr(e) {
  var t = qr(this);
  return Vn(t, 0, e), t.hasOwnProperty(e);
}function or() {
  var e = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : !1;
  var t = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : !1;
  return function (n, r, o) {
    if ("__v_isReactive" === r) return !e;
    if ("__v_isReadonly" === r) return e;
    if ("__v_isShallow" === r) return t;
    if ("__v_raw" === r && o === (e ? t ? Lr : Mr : t ? Er : Cr).get(n)) return n;
    var s = b(n);

    if (!e) {
      if (s && v(tr, r)) return Reflect.get(tr, r, o);
      if ("hasOwnProperty" === r) return rr;
    }

    var i = Reflect.get(n, r, o);
    return (S(r) ? Qn.has(r) : Yn(r)) ? i : (e || Vn(n, 0, r), t ? i : zr(i) ? s && C(r) ? i : i.value : P(i) ? e ? Nr(i) : Rr(i) : i);
  };
}function sr() {
  var e = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : !1;
  return function (t, n, r, o) {
    var s = t[n];
    if (Ur(s) && zr(s) && !zr(r)) return !1;
    if (!e && (Fr(r) || Ur(r) || (s = qr(s), r = qr(r)), !b(t) && zr(s) && !zr(r))) return s.value = r, !0;
    var i = b(t) && C(n) ? Number(n) < t.length : v(t, n),
        a = Reflect.set(t, n, r, o);
    return t === qr(o) && (i ? U(r, s) && zn(t, "set", n, r) : zn(t, "add", n, r)), a;
  };
}var ir = {
  get: Xn,
  set: sr(),
  deleteProperty: function deleteProperty(e, t) {
    var n = v(e, t);
    e[t];
    var r = Reflect.deleteProperty(e, t);
    return r && n && zn(e, "delete", t, void 0), r;
  },
  has: function has(e, t) {
    var n = Reflect.has(e, t);
    return S(t) && Qn.has(t) || Vn(e, 0, t), n;
  },
  ownKeys: function ownKeys(e) {
    return Vn(e, 0, b(e) ? "length" : jn), Reflect.ownKeys(e);
  }
},
    ar = {
  get: er,
  set: function set(e, t) {
    return !0;
  },
  deleteProperty: function deleteProperty(e, t) {
    return !0;
  }
},
    cr = g({}, ir, {
  get: Zn,
  set: sr(!0)
}),
    ur = function ur(e) {
  return e;
},
    lr = function lr(e) {
  return Reflect.getPrototypeOf(e);
};function fr(e, t) {
  var n = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : !1;
  var r = arguments.length > 3 && arguments[3] !== undefined ? arguments[3] : !1;
  var o = qr(e = e.__v_raw),
      s = qr(t);
  n || (t !== s && Vn(o, 0, t), Vn(o, 0, s));

  var _lr = lr(o),
      i = _lr.has,
      a = r ? ur : n ? Kr : Hr;

  return i.call(o, t) ? a(e.get(t)) : i.call(o, s) ? a(e.get(s)) : void (e !== o && e.get(t));
}function hr(e) {
  var t = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : !1;
  var n = this.__v_raw,
      r = qr(n),
      o = qr(e);
  return t || (e !== o && Vn(r, 0, e), Vn(r, 0, o)), e === o ? n.has(e) : n.has(e) || n.has(o);
}function dr(e) {
  var t = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : !1;
  return e = e.__v_raw, !t && Vn(qr(e), 0, jn), Reflect.get(e, "size", e);
}function pr(e) {
  e = qr(e);
  var t = qr(this);
  return lr(t).has.call(t, e) || (t.add(e), zn(t, "add", e, e)), this;
}function gr(e, t) {
  t = qr(t);

  var n = qr(this),
      _lr2 = lr(n),
      r = _lr2.has,
      o = _lr2.get;

  var s = r.call(n, e);
  s || (e = qr(e), s = r.call(n, e));
  var i = o.call(n, e);
  return n.set(e, t), s ? U(t, i) && zn(n, "set", e, t) : zn(n, "add", e, t), this;
}function mr(e) {
  var t = qr(this),
      _lr3 = lr(t),
      n = _lr3.has,
      r = _lr3.get;

  var o = n.call(t, e);
  o || (e = qr(e), o = n.call(t, e)), r && r.call(t, e);
  var s = t.delete(e);
  return o && zn(t, "delete", e, void 0), s;
}function yr() {
  var e = qr(this),
      t = 0 !== e.size,
      n = e.clear();
  return t && zn(e, "clear", void 0, void 0), n;
}function vr(e, t) {
  return function (n, r) {
    var o = this,
        s = o.__v_raw,
        i = qr(s),
        a = t ? ur : e ? Kr : Hr;
    return !e && Vn(i, 0, jn), s.forEach(function (e, t) {
      return n.call(r, a(e), a(t), o);
    });
  };
}function br(e, t, n) {
  return function () {
    var o = this.__v_raw,
        s = qr(o),
        i = _(s),
        a = "entries" === e || e === Symbol.iterator && i,
        c = "keys" === e && i,
        u = o[e].apply(o, arguments),
        l = n ? ur : t ? Kr : Hr;

    return !t && Vn(s, 0, c ? Dn : jn), _defineProperty2({
      next: function next() {
        var _u$next = u.next(),
            e = _u$next.value,
            t = _u$next.done;

        return t ? {
          value: e,
          done: t
        } : {
          value: a ? [l(e[0]), l(e[1])] : l(e),
          done: t
        };
      }
    }, Symbol.iterator, function () {
      return this;
    });
  };
}function _r(e) {
  return function () {
    return "delete" !== e && this;
  };
}function wr() {
  var e = {
    get: function get(e) {
      return fr(this, e);
    },

    get size() {
      return dr(this);
    },

    has: hr,
    add: pr,
    set: gr,
    delete: mr,
    clear: yr,
    forEach: vr(!1, !1)
  },
      t = {
    get: function get(e) {
      return fr(this, e, !1, !0);
    },

    get size() {
      return dr(this);
    },

    has: hr,
    add: pr,
    set: gr,
    delete: mr,
    clear: yr,
    forEach: vr(!1, !0)
  },
      n = {
    get: function get(e) {
      return fr(this, e, !0);
    },

    get size() {
      return dr(this, !0);
    },

    has: function has(e) {
      return hr.call(this, e, !0);
    },
    add: _r("add"),
    set: _r("set"),
    delete: _r("delete"),
    clear: _r("clear"),
    forEach: vr(!0, !1)
  },
      r = {
    get: function get(e) {
      return fr(this, e, !0, !0);
    },

    get size() {
      return dr(this, !0);
    },

    has: function has(e) {
      return hr.call(this, e, !0);
    },
    add: _r("add"),
    set: _r("set"),
    delete: _r("delete"),
    clear: _r("clear"),
    forEach: vr(!0, !0)
  };
  return ["keys", "values", "entries", Symbol.iterator].forEach(function (o) {
    e[o] = br(o, !1, !1), n[o] = br(o, !0, !1), t[o] = br(o, !1, !0), r[o] = br(o, !0, !0);
  }), [e, n, t, r];
}var _wr = wr(),
    _wr2 = _slicedToArray2(_wr, 4),
    kr = _wr2[0],
    xr = _wr2[1],
    Sr = _wr2[2],
    Pr = _wr2[3];function Ar(e, t) {
  var n = t ? e ? Pr : Sr : e ? xr : kr;
  return function (t, r, o) {
    return "__v_isReactive" === r ? !e : "__v_isReadonly" === r ? e : "__v_raw" === r ? t : Reflect.get(v(n, r) && r in t ? n : t, r, o);
  };
}var Or = {
  get: Ar(!1, !1)
},
    Ir = {
  get: Ar(!1, !0)
},
    Tr = {
  get: Ar(!0, !1)
},
    Cr = new WeakMap(),
    Er = new WeakMap(),
    Mr = new WeakMap(),
    Lr = new WeakMap();function $r(e) {
  return e.__v_skip || !Object.isExtensible(e) ? 0 : function (e) {
    switch (e) {
      case "Object":
      case "Array":
        return 1;

      case "Map":
      case "Set":
      case "WeakMap":
      case "WeakSet":
        return 2;

      default:
        return 0;
    }
  }(function (e) {
    return I(e).slice(8, -1);
  }(e));
}function Rr(e) {
  return Ur(e) ? e : jr(e, !1, ir, Or, Cr);
}function Nr(e) {
  return jr(e, !0, ar, Tr, Mr);
}function jr(e, t, n, r, o) {
  if (!P(e)) return e;
  if (e.__v_raw && (!t || !e.__v_isReactive)) return e;
  var s = o.get(e);
  if (s) return s;
  var i = $r(e);
  if (0 === i) return e;
  var a = new Proxy(e, 2 === i ? r : n);
  return o.set(e, a), a;
}function Dr(e) {
  return Ur(e) ? Dr(e.__v_raw) : !(!e || !e.__v_isReactive);
}function Ur(e) {
  return !(!e || !e.__v_isReadonly);
}function Fr(e) {
  return !(!e || !e.__v_isShallow);
}function qr(e) {
  var t = e && e.__v_raw;
  return t ? qr(t) : e;
}function Br(e) {
  return function (e, t, n) {
    Object.defineProperty(e, t, {
      configurable: !0,
      enumerable: !1,
      value: n
    });
  }(e, "__v_skip", !0), e;
}var Hr = function Hr(e) {
  return P(e) ? Rr(e) : e;
},
    Kr = function Kr(e) {
  return P(e) ? Nr(e) : e;
};function Vr(e) {
  qn && Nn && Wn((e = qr(e)).dep || (e.dep = Cn()));
}function Wr(e, t) {
  var n = (e = qr(e)).dep;
  n && Jn(n);
}function zr(e) {
  return !(!e || !0 !== e.__v_isRef);
}function Jr(e) {
  return Gr(e, !1);
}function Gr(e, t) {
  return zr(e) ? e : new Yr(e, t);
}var Yr = /*#__PURE__*/function () {
  function Yr(e, t) {
    _classCallCheck2(this, Yr);

    this.__v_isShallow = t, this.dep = void 0, this.__v_isRef = !0, this._rawValue = t ? e : qr(e), this._value = t ? e : Hr(e);
  }

  _createClass2(Yr, [{
    key: "value",
    get: function get() {
      return Vr(this), this._value;
    },
    set: function set(e) {
      var t = this.__v_isShallow || Fr(e) || Ur(e);
      e = t ? e : qr(e), U(e, this._rawValue) && (this._rawValue = e, this._value = t ? e : Hr(e), Wr(this));
    }
  }]);

  return Yr;
}();function Qr(e) {
  return zr(e) ? e.value : e;
}var Xr = {
  get: function get(e, t, n) {
    return Qr(Reflect.get(e, t, n));
  },
  set: function set(e, t, n, r) {
    var o = e[t];
    return zr(o) && !zr(n) ? (o.value = n, !0) : Reflect.set(e, t, n, r);
  }
};function Zr(e) {
  return Dr(e) ? e : new Proxy(e, Xr);
}var eo = /*#__PURE__*/function () {
  function eo(e, t, n) {
    _classCallCheck2(this, eo);

    this._object = e, this._key = t, this._defaultValue = n, this.__v_isRef = !0;
  }

  _createClass2(eo, [{
    key: "value",
    get: function get() {
      var e = this._object[this._key];
      return void 0 === e ? this._defaultValue : e;
    },
    set: function set(e) {
      this._object[this._key] = e;
    }
  }, {
    key: "dep",
    get: function get() {
      return e = qr(this._object), t = this._key, null === (n = Ln.get(e)) || void 0 === n ? void 0 : n.get(t);
      var e, t, n;
    }
  }]);

  return eo;
}();function to(e, t, n) {
  var r = e[t];
  return zr(r) ? r : new eo(e, t, n);
}var no;var ro = /*#__PURE__*/function () {
  function ro(e, t, n, r) {
    var _this3 = this;

    _classCallCheck2(this, ro);

    this._setter = t, this.dep = void 0, this.__v_isRef = !0, this[no] = !1, this._dirty = !0, this.effect = new Un(e, function () {
      _this3._dirty || (_this3._dirty = !0, Wr(_this3));
    }), this.effect.computed = this, this.effect.active = this._cacheable = !r, this.__v_isReadonly = n;
  }

  _createClass2(ro, [{
    key: "value",
    get: function get() {
      var e = qr(this);
      return Vr(e), !e._dirty && e._cacheable || (e._dirty = !1, e._value = e.effect.run()), e._value;
    },
    set: function set(e) {
      this._setter(e);
    }
  }]);

  return ro;
}();function oo(e, t, n, r) {
  var o;

  try {
    o = r ? e.apply(void 0, _toConsumableArray2(r)) : e();
  } catch (s) {
    io(s, t, n);
  }

  return o;
}function so(e, t, n, r) {
  if (k(e)) {
    var _o8 = oo(e, t, n, r);

    return _o8 && A(_o8) && _o8.catch(function (e) {
      io(e, t, n);
    }), _o8;
  }

  var o = [];

  for (var _s7 = 0; _s7 < e.length; _s7++) {
    o.push(so(e[_s7], t, n, r));
  }

  return o;
}function io(e, t, n) {
  var r = arguments.length > 3 && arguments[3] !== undefined ? arguments[3] : !0;
  t && t.vnode;

  if (t) {
    var _r13 = t.parent;
    var _o9 = t.proxy,
        _s8 = n;

    for (; _r13;) {
      var _t17 = _r13.ec;
      if (_t17) for (var _n13 = 0; _n13 < _t17.length; _n13++) {
        if (!1 === _t17[_n13](e, _o9, _s8)) return;
      }
      _r13 = _r13.parent;
    }

    var _i6 = t.appContext.config.errorHandler;
    if (_i6) return void oo(_i6, null, 10, [e, _o9, _s8]);
  }

  !function (e, t, n) {
    var r = arguments.length > 3 && arguments[3] !== undefined ? arguments[3] : !0;
    console.error(e);
  }(e, 0, 0, r);
}no = "__v_isReadonly";var ao = !1,
    co = !1;var uo = [];var lo = 0;var fo = [];var ho = null,
    po = 0;var go = Promise.resolve();var mo = null;function yo(e) {
  var t = mo || go;
  return e ? t.then(this ? e.bind(this) : e) : t;
}function vo(e) {
  uo.length && uo.includes(e, ao && e.allowRecurse ? lo + 1 : lo) || (null == e.id ? uo.push(e) : uo.splice(function (e) {
    var t = lo + 1,
        n = uo.length;

    for (; t < n;) {
      var _r14 = t + n >>> 1;

      ko(uo[_r14]) < e ? t = _r14 + 1 : n = _r14;
    }

    return t;
  }(e.id), 0, e), bo());
}function bo() {
  ao || co || (co = !0, mo = go.then(So));
}function _o(e) {
  b(e) ? fo.push.apply(fo, _toConsumableArray2(e)) : ho && ho.includes(e, e.allowRecurse ? po + 1 : po) || fo.push(e), bo();
}function wo(e) {
  var t = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : ao ? lo + 1 : 0;

  for (; t < uo.length; t++) {
    var _e11 = uo[t];
    _e11 && _e11.pre && (uo.splice(t, 1), t--, _e11());
  }
}var ko = function ko(e) {
  return null == e.id ? 1 / 0 : e.id;
},
    xo = function xo(e, t) {
  var n = ko(e) - ko(t);

  if (0 === n) {
    if (e.pre && !t.pre) return -1;
    if (t.pre && !e.pre) return 1;
  }

  return n;
};function So(e) {
  co = !1, ao = !0, uo.sort(xo);

  try {
    for (lo = 0; lo < uo.length; lo++) {
      var _e12 = uo[lo];
      _e12 && !1 !== _e12.active && oo(_e12, null, 14);
    }
  } finally {
    lo = 0, uo.length = 0, function (e) {
      if (fo.length) {
        var _ho;

        var _e13 = _toConsumableArray2(new Set(fo));

        if (fo.length = 0, ho) return void (_ho = ho).push.apply(_ho, _toConsumableArray2(_e13));

        for (ho = _e13, ho.sort(function (e, t) {
          return ko(e) - ko(t);
        }), po = 0; po < ho.length; po++) {
          ho[po]();
        }

        ho = null, po = 0;
      }
    }(), ao = !1, mo = null, (uo.length || fo.length) && So();
  }
}function Po(e, t) {
  if (e.isUnmounted) return;
  var r = e.vnode.props || c;

  for (var _len8 = arguments.length, n = new Array(_len8 > 2 ? _len8 - 2 : 0), _key8 = 2; _key8 < _len8; _key8++) {
    n[_key8 - 2] = arguments[_key8];
  }

  var o = n;
  var s = t.startsWith("update:"),
      i = s && t.slice(7);

  if (i && i in r) {
    var _e14 = "".concat("modelValue" === i ? "model" : i, "Modifiers"),
        _ref15 = r[_e14] || c,
        _t18 = _ref15.number,
        _s9 = _ref15.trim;

    _s9 && (o = n.map(function (e) {
      return x(e) ? e.trim() : e;
    })), _t18 && (o = n.map(q));
  }

  var a,
      u = r[a = D(t)] || r[a = D($(t))];
  !u && s && (u = r[a = D(N(t))]), u && so(u, e, 6, o);
  var l = r[a + "Once"];

  if (l) {
    if (e.emitted) {
      if (e.emitted[a]) return;
    } else e.emitted = {};

    e.emitted[a] = !0, so(l, e, 6, o);
  }
}function Ao(e, t) {
  var n = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : !1;
  var r = t.emitsCache,
      o = r.get(e);
  if (void 0 !== o) return o;
  var s = e.emits;
  var i = {},
      a = !1;

  if (!k(e)) {
    var _r15 = function _r15(e) {
      var n = Ao(e, t, !0);
      n && (a = !0, g(i, n));
    };

    !n && t.mixins.length && t.mixins.forEach(_r15), e.extends && _r15(e.extends), e.mixins && e.mixins.forEach(_r15);
  }

  return s || a ? (b(s) ? s.forEach(function (e) {
    return i[e] = null;
  }) : g(i, s), P(e) && r.set(e, i), i) : (P(e) && r.set(e, null), null);
}function Oo(e, t) {
  return !(!e || !d(t)) && (t = t.slice(2).replace(/Once$/, ""), v(e, t[0].toLowerCase() + t.slice(1)) || v(e, N(t)) || v(e, t));
}var Io = null;function To(e) {
  var t = Io;
  return Io = e, e && e.type.__scopeId, t;
}function Co(e, t) {
  var n = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : !1;
  var r = Es || Io;

  if (r) {
    var _o10 = null == r.parent ? r.vnode.appContext && r.vnode.appContext.provides : r.parent.provides;

    if (_o10 && e in _o10) return _o10[e];
    if (arguments.length > 1) return n && k(t) ? t.call(r.proxy) : t;
  }
}var Eo = {};function Mo(e, t, n) {
  return Lo(e, t, n);
}function Lo(e, t) {
  var _ref16 = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : c,
      n = _ref16.immediate,
      r = _ref16.deep,
      o = _ref16.flush,
      s = _ref16.onTrack,
      i = _ref16.onTrigger;

  var a = In === (null == Es ? void 0 : Es.scope) ? Es : null;
  var u,
      f,
      h = !1,
      d = !1;

  if (zr(e) ? (u = function u() {
    return e.value;
  }, h = Fr(e)) : Dr(e) ? (u = function u() {
    return e;
  }, r = !0) : b(e) ? (d = !0, h = e.some(function (e) {
    return Dr(e) || Fr(e);
  }), u = function u() {
    return e.map(function (e) {
      return zr(e) ? e.value : Dr(e) ? No(e) : k(e) ? oo(e, a, 2) : void 0;
    });
  }) : u = k(e) ? t ? function () {
    return oo(e, a, 2);
  } : function () {
    if (!a || !a.isUnmounted) return f && f(), so(e, a, 3, [p]);
  } : l, t && r) {
    var _e15 = u;

    u = function u() {
      return No(_e15());
    };
  }

  var p = function p(e) {
    f = _.onStop = function () {
      oo(e, a, 4);
    };
  },
      g = d ? new Array(e.length).fill(Eo) : Eo;

  var y = function y() {
    if (_.active) if (t) {
      var _e16 = _.run();

      (r || h || (d ? _e16.some(function (e, t) {
        return U(e, g[t]);
      }) : U(_e16, g))) && (f && f(), so(t, a, 3, [_e16, g === Eo ? void 0 : d && g[0] === Eo ? [] : g, p]), g = _e16);
    } else _.run();
  };

  var v;
  y.allowRecurse = !!t, "sync" === o ? v = y : "post" === o ? v = function v() {
    return As(y, a && a.suspense);
  } : (y.pre = !0, a && (y.id = a.uid), v = function v() {
    return vo(y);
  });

  var _ = new Un(u, v);

  t ? n ? y() : g = _.run() : "post" === o ? As(_.run.bind(_), a && a.suspense) : _.run();
  return function () {
    _.stop(), a && a.scope && m(a.scope.effects, _);
  };
}function $o(e, t, n) {
  var r = this.proxy,
      o = x(e) ? e.includes(".") ? Ro(r, e) : function () {
    return r[e];
  } : e.bind(r, r);
  var s;
  k(t) ? s = t : (s = t.handler, n = t);
  var i = Es;
  Ls(this);
  var a = Lo(o, s.bind(r), n);
  return i ? Ls(i) : $s(), a;
}function Ro(e, t) {
  var n = t.split(".");
  return function () {
    var t = e;

    for (var _e17 = 0; _e17 < n.length && t; _e17++) {
      t = t[n[_e17]];
    }

    return t;
  };
}function No(e, t) {
  if (!P(e) || e.__v_skip) return e;
  if ((t = t || new Set()).has(e)) return e;
  if (t.add(e), zr(e)) No(e.value, t);else if (b(e)) for (var _n14 = 0; _n14 < e.length; _n14++) {
    No(e[_n14], t);
  } else if (w(e) || _(e)) e.forEach(function (e) {
    No(e, t);
  });else if (T(e)) for (var _n15 in e) {
    No(e[_n15], t);
  }
  return e;
}function jo(e, t) {
  Uo(e, "a", t);
}function Do(e, t) {
  Uo(e, "da", t);
}function Uo(e, t) {
  var n = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : Es;

  var r = e.__wdc || (e.__wdc = function () {
    var t = n;

    for (; t;) {
      if (t.isDeactivated) return;
      t = t.parent;
    }

    return e();
  });

  if (qo(t, r, n), n) {
    var _e18 = n.parent;

    for (; _e18 && _e18.parent;) {
      _e18.parent.vnode.type.__isKeepAlive && Fo(r, t, n, _e18), _e18 = _e18.parent;
    }
  }
}function Fo(e, t, n, r) {
  var o = qo(t, e, r, !0);
  Jo(function () {
    m(r[t], o);
  }, n);
}function qo(e, t) {
  var n = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : Es;
  var r = arguments.length > 3 && arguments[3] !== undefined ? arguments[3] : !1;

  if (n) {
    (function (e) {
      return we.indexOf(e) > -1;
    })(e) && (n = n.root);

    var _o11 = n[e] || (n[e] = []),
        _s10 = t.__weh || (t.__weh = function () {
      if (n.isUnmounted) return;
      Hn(), Ls(n);

      for (var _len9 = arguments.length, r = new Array(_len9), _key9 = 0; _key9 < _len9; _key9++) {
        r[_key9] = arguments[_key9];
      }

      var o = so(t, n, e, r);
      return $s(), Kn(), o;
    });

    return r ? _o11.unshift(_s10) : _o11.push(_s10), _s10;
  }
}var Bo = function Bo(e) {
  return function (t) {
    var n = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : Es;
    return (!Ns || "sp" === e) && qo(e, function () {
      return t.apply(void 0, arguments);
    }, n);
  };
},
    Ho = Bo("bm"),
    Ko = Bo("m"),
    Vo = Bo("bu"),
    Wo = Bo("u"),
    zo = Bo("bum"),
    Jo = Bo("um"),
    Go = Bo("sp"),
    Yo = Bo("rtg"),
    Qo = Bo("rtc");function Xo(e) {
  var t = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : Es;
  qo("ec", e, t);
}var Zo = "components";function es(e, t) {
  return e && (e[t] || e[$(t)] || e[j($(t))]);
}var ts = function ts(e) {
  return e ? Rs(e) ? Us(e) || e.proxy : ts(e.parent) : null;
},
    ns = g(Object.create(null), {
  $: function $(e) {
    return e;
  },
  $el: function $el(e) {
    return e.__$el || (e.__$el = {});
  },
  $data: function $data(e) {
    return e.data;
  },
  $props: function $props(e) {
    return e.props;
  },
  $attrs: function $attrs(e) {
    return e.attrs;
  },
  $slots: function $slots(e) {
    return e.slots;
  },
  $refs: function $refs(e) {
    return e.refs;
  },
  $parent: function $parent(e) {
    return ts(e.parent);
  },
  $root: function $root(e) {
    return ts(e.root);
  },
  $emit: function $emit(e) {
    return e.emit;
  },
  $options: function $options(e) {
    return us(e);
  },
  $forceUpdate: function $forceUpdate(e) {
    return e.f || (e.f = function () {
      return vo(e.update);
    });
  },
  $watch: function $watch(e) {
    return $o.bind(e);
  }
}),
    rs = function rs(e, t) {
  return e !== c && !e.__isScriptSetup && v(e, t);
},
    os = {
  get: function get(_ref17, t) {
    var e = _ref17._;
    var n = e.ctx,
        r = e.setupState,
        o = e.data,
        s = e.props,
        i = e.accessCache,
        a = e.type,
        u = e.appContext;
    var l;

    if ("$" !== t[0]) {
      var _a4 = i[t];
      if (void 0 !== _a4) switch (_a4) {
        case 1:
          return r[t];

        case 2:
          return o[t];

        case 4:
          return n[t];

        case 3:
          return s[t];
      } else {
        if (rs(r, t)) return i[t] = 1, r[t];
        if (o !== c && v(o, t)) return i[t] = 2, o[t];
        if ((l = e.propsOptions[0]) && v(l, t)) return i[t] = 3, s[t];
        if (n !== c && v(n, t)) return i[t] = 4, n[t];
        ss && (i[t] = 0);
      }
    }

    var f = ns[t];
    var h, d;
    return f ? ("$attrs" === t && Vn(e, 0, t), f(e)) : (h = a.__cssModules) && (h = h[t]) ? h : n !== c && v(n, t) ? (i[t] = 4, n[t]) : (d = u.config.globalProperties, v(d, t) ? d[t] : void 0);
  },
  set: function set(_ref18, t, n) {
    var e = _ref18._;
    var r = e.data,
        o = e.setupState,
        s = e.ctx;
    return rs(o, t) ? (o[t] = n, !0) : r !== c && v(r, t) ? (r[t] = n, !0) : !v(e.props, t) && ("$" !== t[0] || !(t.slice(1) in e)) && (s[t] = n, !0);
  },
  has: function has(_ref19, i) {
    var _ref19$_ = _ref19._,
        e = _ref19$_.data,
        t = _ref19$_.setupState,
        n = _ref19$_.accessCache,
        r = _ref19$_.ctx,
        o = _ref19$_.appContext,
        s = _ref19$_.propsOptions;
    var a;
    return !!n[i] || e !== c && v(e, i) || rs(t, i) || (a = s[0]) && v(a, i) || v(r, i) || v(ns, i) || v(o.config.globalProperties, i);
  },
  defineProperty: function defineProperty(e, t, n) {
    return null != n.get ? e._.accessCache[t] = 0 : v(n, "value") && this.set(e, t, n.value, null), Reflect.defineProperty(e, t, n);
  }
};var ss = !0;function is(e) {
  var t = us(e),
      n = e.proxy,
      r = e.ctx;
  ss = !1, t.beforeCreate && as(t.beforeCreate, e, "bc");
  var o = t.data,
      s = t.computed,
      i = t.methods,
      a = t.watch,
      c = t.provide,
      u = t.inject,
      f = t.created,
      h = t.beforeMount,
      d = t.mounted,
      p = t.beforeUpdate,
      g = t.updated,
      m = t.activated,
      y = t.deactivated,
      v = t.beforeDestroy,
      _ = t.beforeUnmount,
      w = t.destroyed,
      x = t.unmounted,
      S = t.render,
      A = t.renderTracked,
      O = t.renderTriggered,
      I = t.errorCaptured,
      T = t.serverPrefetch,
      C = t.expose,
      E = t.inheritAttrs,
      M = t.components,
      L = t.directives,
      $ = t.filters;
  if (u && function (e, t) {
    var n = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : l;
    var r = arguments.length > 3 && arguments[3] !== undefined ? arguments[3] : !1;
    b(e) && (e = ds(e));

    var _loop = function _loop(_o12) {
      var n = e[_o12];
      var s = void 0;
      s = P(n) ? "default" in n ? Co(n.from || _o12, n.default, !0) : Co(n.from || _o12) : Co(n), zr(s) && r ? Object.defineProperty(t, _o12, {
        enumerable: !0,
        configurable: !0,
        get: function get() {
          return s.value;
        },
        set: function set(e) {
          return s.value = e;
        }
      }) : t[_o12] = s;
    };

    for (var _o12 in e) {
      _loop(_o12);
    }
  }(u, r, null, e.appContext.config.unwrapInjectedRef), i) for (var _l2 in i) {
    var _e19 = i[_l2];
    k(_e19) && (r[_l2] = _e19.bind(n));
  }

  if (o) {
    var _t19 = o.call(n, n);

    P(_t19) && (e.data = Rr(_t19));
  }

  if (ss = !0, s) {
    var _loop2 = function _loop2(_b) {
      var e = s[_b],
          t = k(e) ? e.bind(n, n) : k(e.get) ? e.get.bind(n, n) : l,
          o = !k(e) && k(e.set) ? e.set.bind(n) : l,
          i = Fs({
        get: t,
        set: o
      });
      Object.defineProperty(r, _b, {
        enumerable: !0,
        configurable: !0,
        get: function get() {
          return i.value;
        },
        set: function set(e) {
          return i.value = e;
        }
      });
    };

    for (var _b in s) {
      _loop2(_b);
    }
  }

  if (a) for (var _l3 in a) {
    cs(a[_l3], r, n, _l3);
  }

  if (c) {
    var _e20 = k(c) ? c.call(n) : c;

    Reflect.ownKeys(_e20).forEach(function (t) {
      !function (e, t) {
        if (Es) {
          var _n16 = Es.provides;

          var _r16 = Es.parent && Es.parent.provides;

          _r16 === _n16 && (_n16 = Es.provides = Object.create(_r16)), _n16[e] = t, "app" === Es.type.mpType && Es.appContext.app.provide(e, t);
        }
      }(t, _e20[t]);
    });
  }

  function R(e, t) {
    b(t) ? t.forEach(function (t) {
      return e(t.bind(n));
    }) : t && e(t.bind(n));
  }

  if (f && as(f, e, "c"), R(Ho, h), R(Ko, d), R(Vo, p), R(Wo, g), R(jo, m), R(Do, y), R(Xo, I), R(Qo, A), R(Yo, O), R(zo, _), R(Jo, x), R(Go, T), b(C)) if (C.length) {
    var _t20 = e.exposed || (e.exposed = {});

    C.forEach(function (e) {
      Object.defineProperty(_t20, e, {
        get: function get() {
          return n[e];
        },
        set: function set(t) {
          return n[e] = t;
        }
      });
    });
  } else e.exposed || (e.exposed = {});
  S && e.render === l && (e.render = S), null != E && (e.inheritAttrs = E), M && (e.components = M), L && (e.directives = L), e.ctx.$onApplyOptions && e.ctx.$onApplyOptions(t, e, n);
}function as(e, t, n) {
  so(b(e) ? e.map(function (e) {
    return e.bind(t.proxy);
  }) : e.bind(t.proxy), t, n);
}function cs(e, t, n, r) {
  var o = r.includes(".") ? Ro(n, r) : function () {
    return n[r];
  };

  if (x(e)) {
    var _n17 = t[e];
    k(_n17) && Mo(o, _n17);
  } else if (k(e)) Mo(o, e.bind(n));else if (P(e)) if (b(e)) e.forEach(function (e) {
    return cs(e, t, n, r);
  });else {
    var _r17 = k(e.handler) ? e.handler.bind(n) : t[e.handler];

    k(_r17) && Mo(o, _r17, e);
  }
}function us(e) {
  var t = e.type,
      n = t.mixins,
      r = t.extends,
      _e$appContext = e.appContext,
      o = _e$appContext.mixins,
      s = _e$appContext.optionsCache,
      i = _e$appContext.config.optionMergeStrategies,
      a = s.get(t);
  var c;
  return a ? c = a : o.length || n || r ? (c = {}, o.length && o.forEach(function (e) {
    return ls(c, e, i, !0);
  }), ls(c, t, i)) : c = t, P(t) && s.set(t, c), c;
}function ls(e, t, n) {
  var r = arguments.length > 3 && arguments[3] !== undefined ? arguments[3] : !1;
  var o = t.mixins,
      s = t.extends;
  s && ls(e, s, n, !0), o && o.forEach(function (t) {
    return ls(e, t, n, !0);
  });

  for (var _i7 in t) {
    if (r && "expose" === _i7) ;else {
      var _r18 = fs[_i7] || n && n[_i7];

      e[_i7] = _r18 ? _r18(e[_i7], t[_i7]) : t[_i7];
    }
  }

  return e;
}var fs = {
  data: hs,
  props: gs,
  emits: gs,
  methods: gs,
  computed: gs,
  beforeCreate: ps,
  created: ps,
  beforeMount: ps,
  mounted: ps,
  beforeUpdate: ps,
  updated: ps,
  beforeDestroy: ps,
  beforeUnmount: ps,
  destroyed: ps,
  unmounted: ps,
  activated: ps,
  deactivated: ps,
  errorCaptured: ps,
  serverPrefetch: ps,
  components: gs,
  directives: gs,
  watch: function watch(e, t) {
    if (!e) return t;
    if (!t) return e;
    var n = g(Object.create(null), e);

    for (var _r19 in t) {
      n[_r19] = ps(e[_r19], t[_r19]);
    }

    return n;
  },
  provide: hs,
  inject: function inject(e, t) {
    return gs(ds(e), ds(t));
  }
};function hs(e, t) {
  return t ? e ? function () {
    return g(k(e) ? e.call(this, this) : e, k(t) ? t.call(this, this) : t);
  } : t : e;
}function ds(e) {
  if (b(e)) {
    var _t21 = {};

    for (var _n18 = 0; _n18 < e.length; _n18++) {
      _t21[e[_n18]] = e[_n18];
    }

    return _t21;
  }

  return e;
}function ps(e, t) {
  return e ? _toConsumableArray2(new Set([].concat(e, t))) : t;
}function gs(e, t) {
  return e ? g(g(Object.create(null), e), t) : t;
}function ms(e, t, n) {
  var r = arguments.length > 3 && arguments[3] !== undefined ? arguments[3] : !1;
  var o = {},
      s = {};
  e.propsDefaults = Object.create(null), ys(e, t, o, s);

  for (var _i8 in e.propsOptions[0]) {
    _i8 in o || (o[_i8] = void 0);
  }

  n ? e.props = r ? o : jr(o, !1, cr, Ir, Er) : e.type.props ? e.props = o : e.props = s, e.attrs = s;
}function ys(e, t, n, r) {
  var _e$propsOptions = _slicedToArray2(e.propsOptions, 2),
      o = _e$propsOptions[0],
      s = _e$propsOptions[1];

  var i,
      a = !1;
  if (t) for (var _c3 in t) {
    if (E(_c3)) continue;
    var _u2 = t[_c3];

    var _l4 = void 0;

    o && v(o, _l4 = $(_c3)) ? s && s.includes(_l4) ? (i || (i = {}))[_l4] = _u2 : n[_l4] = _u2 : Oo(e.emitsOptions, _c3) || _c3 in r && _u2 === r[_c3] || (r[_c3] = _u2, a = !0);
  }

  if (s) {
    var _t22 = qr(n),
        _r20 = i || c;

    for (var _i9 = 0; _i9 < s.length; _i9++) {
      var _a5 = s[_i9];
      n[_a5] = vs(o, _t22, _a5, _r20[_a5], e, !v(_r20, _a5));
    }
  }

  return a;
}function vs(e, t, n, r, o, s) {
  var i = e[n];

  if (null != i) {
    var _e21 = v(i, "default");

    if (_e21 && void 0 === r) {
      var _e22 = i.default;

      if (i.type !== Function && k(_e22)) {
        var _s11 = o.propsDefaults;
        n in _s11 ? r = _s11[n] : (Ls(o), r = _s11[n] = _e22.call(null, t), $s());
      } else r = _e22;
    }

    i[0] && (s && !_e21 ? r = !1 : !i[1] || "" !== r && r !== N(n) || (r = !0));
  }

  return r;
}function bs(e, t) {
  var n = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : !1;
  var r = t.propsCache,
      o = r.get(e);
  if (o) return o;
  var s = e.props,
      i = {},
      a = [];
  var l = !1;

  if (!k(e)) {
    var _r21 = function _r21(e) {
      l = !0;

      var _bs = bs(e, t, !0),
          _bs2 = _slicedToArray2(_bs, 2),
          n = _bs2[0],
          r = _bs2[1];

      g(i, n), r && a.push.apply(a, _toConsumableArray2(r));
    };

    !n && t.mixins.length && t.mixins.forEach(_r21), e.extends && _r21(e.extends), e.mixins && e.mixins.forEach(_r21);
  }

  if (!s && !l) return P(e) && r.set(e, u), u;
  if (b(s)) for (var _u3 = 0; _u3 < s.length; _u3++) {
    var _e23 = $(s[_u3]);

    _s(_e23) && (i[_e23] = c);
  } else if (s) for (var _c4 in s) {
    var _e24 = $(_c4);

    if (_s(_e24)) {
      var _t23 = s[_c4],
          _n19 = i[_e24] = b(_t23) || k(_t23) ? {
        type: _t23
      } : Object.assign({}, _t23);

      if (_n19) {
        var _t24 = xs(Boolean, _n19.type),
            _r22 = xs(String, _n19.type);

        _n19[0] = _t24 > -1, _n19[1] = _r22 < 0 || _t24 < _r22, (_t24 > -1 || v(_n19, "default")) && a.push(_e24);
      }
    }
  }
  var f = [i, a];
  return P(e) && r.set(e, f), f;
}function _s(e) {
  return "$" !== e[0];
}function ws(e) {
  var t = e && e.toString().match(/^\s*(function|class) (\w+)/);
  return t ? t[2] : null === e ? "null" : "";
}function ks(e, t) {
  return ws(e) === ws(t);
}function xs(e, t) {
  return b(t) ? t.findIndex(function (t) {
    return ks(t, e);
  }) : k(t) && ks(t, e) ? 0 : -1;
}function Ss() {
  return {
    app: null,
    config: {
      isNativeTag: f,
      performance: !1,
      globalProperties: {},
      optionMergeStrategies: {},
      errorHandler: void 0,
      warnHandler: void 0,
      compilerOptions: {}
    },
    mixins: [],
    components: {},
    directives: {},
    provides: Object.create(null),
    optionsCache: new WeakMap(),
    propsCache: new WeakMap(),
    emitsCache: new WeakMap()
  };
}var Ps = 0;var As = _o;function Os(e) {
  return e ? Dr(t = e) || Ur(t) || "__vInternal" in e ? g({}, e) : e : null;
  var t;
}var Is = Ss();var Ts = 0;function Cs(e, t, n) {
  var r = e.type,
      o = (t ? t.appContext : e.appContext) || Is,
      s = {
    uid: Ts++,
    vnode: e,
    type: r,
    parent: t,
    appContext: o,
    root: null,
    next: null,
    subTree: null,
    effect: null,
    update: null,
    scope: new Tn(!0),
    render: null,
    proxy: null,
    exposed: null,
    exposeProxy: null,
    withProxy: null,
    provides: t ? t.provides : Object.create(o.provides),
    accessCache: null,
    renderCache: [],
    components: null,
    directives: null,
    propsOptions: bs(r, o),
    emitsOptions: Ao(r, o),
    emit: null,
    emitted: null,
    propsDefaults: c,
    inheritAttrs: r.inheritAttrs,
    ctx: c,
    data: c,
    props: c,
    attrs: c,
    slots: c,
    refs: c,
    setupState: c,
    setupContext: null,
    suspense: n,
    suspenseId: n ? n.pendingId : 0,
    asyncDep: null,
    asyncResolved: !1,
    isMounted: !1,
    isUnmounted: !1,
    isDeactivated: !1,
    bc: null,
    c: null,
    bm: null,
    m: null,
    bu: null,
    u: null,
    um: null,
    bum: null,
    da: null,
    a: null,
    rtg: null,
    rtc: null,
    ec: null,
    sp: null
  };
  return s.ctx = {
    _: s
  }, s.root = t ? t.root : s, s.emit = Po.bind(null, s), e.ce && e.ce(s), s;
}var Es = null;var Ms = function Ms() {
  return Es || Io;
},
    Ls = function Ls(e) {
  Es = e, e.scope.on();
},
    $s = function $s() {
  Es && Es.scope.off(), Es = null;
};function Rs(e) {
  return 4 & e.vnode.shapeFlag;
}var Ns = !1;function js(e) {
  var t = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : !1;
  Ns = t;
  var n = e.vnode.props,
      r = Rs(e);
  ms(e, n, r, t);
  var o = r ? function (e, t) {
    var n = e.type;
    e.accessCache = Object.create(null), e.proxy = Br(new Proxy(e.ctx, os));
    var r = n.setup;

    if (r) {
      var _t25 = e.setupContext = r.length > 1 ? function (e) {
        var t = function t(_t26) {
          e.exposed = _t26 || {};
        };

        var n;
        return {
          get attrs() {
            return n || (n = function (e) {
              return new Proxy(e.attrs, {
                get: function get(t, n) {
                  return Vn(e, 0, "$attrs"), t[n];
                }
              });
            }(e));
          },

          slots: e.slots,
          emit: e.emit,
          expose: t
        };
      }(e) : null;

      Ls(e), Hn();

      var _n20 = oo(r, e, 0, [e.props, _t25]);

      Kn(), $s(), A(_n20) ? _n20.then($s, $s) : function (e, t, n) {
        k(t) ? e.render = t : P(t) && (e.setupState = Zr(t));
        Ds(e);
      }(e, _n20);
    } else Ds(e);
  }(e) : void 0;
  return Ns = !1, o;
}function Ds(e, t, n) {
  var r = e.type;
  e.render || (e.render = r.render || l), Ls(e), Hn(), is(e), Kn(), $s();
}function Us(e) {
  if (e.exposed) return e.exposeProxy || (e.exposeProxy = new Proxy(Zr(Br(e.exposed)), {
    get: function get(t, n) {
      return n in t ? t[n] : e.proxy[n];
    },
    has: function has(e, t) {
      return t in e || t in ns;
    }
  }));
}var Fs = function Fs(e, t) {
  return function (e, t) {
    var n = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : !1;
    var r, o;
    var s = k(e);
    return s ? (r = e, o = l) : (r = e.get, o = e.set), new ro(r, o, s || !o, n);
  }(e, 0, Ns);
},
    qs = "3.2.47";function Bs(e) {
  return Qr(e);
}var Hs = "[object Array]",
    Ks = "[object Object]";function Vs(e, t) {
  var n = {};
  return Ws(e, t), zs(e, t, "", n), n;
}function Ws(e, t) {
  if ((e = Bs(e)) === t) return;
  var n = I(e),
      r = I(t);
  if (n == Ks && r == Ks) for (var _o13 in t) {
    var _n21 = e[_o13];
    void 0 === _n21 ? e[_o13] = null : Ws(_n21, t[_o13]);
  } else n == Hs && r == Hs && e.length >= t.length && t.forEach(function (t, n) {
    Ws(e[n], t);
  });
}function zs(e, t, n, r) {
  if ((e = Bs(e)) === t) return;
  var o = I(e),
      s = I(t);
  if (o == Ks) {
    if (s != Ks || Object.keys(e).length < Object.keys(t).length) Js(r, n, e);else {
      var _loop3 = function _loop3(_i10) {
        var o = Bs(e[_i10]),
            s = t[_i10],
            a = I(o),
            c = I(s);
        if (a != Hs && a != Ks) o != s && Js(r, ("" == n ? "" : n + ".") + _i10, o);else if (a == Hs) c != Hs || o.length < s.length ? Js(r, ("" == n ? "" : n + ".") + _i10, o) : o.forEach(function (e, t) {
          zs(e, s[t], ("" == n ? "" : n + ".") + _i10 + "[" + t + "]", r);
        });else if (a == Ks) if (c != Ks || Object.keys(o).length < Object.keys(s).length) Js(r, ("" == n ? "" : n + ".") + _i10, o);else for (var _e25 in o) {
          zs(o[_e25], s[_e25], ("" == n ? "" : n + ".") + _i10 + "." + _e25, r);
        }
      };

      for (var _i10 in e) {
        _loop3(_i10);
      }
    }
  } else o == Hs ? s != Hs || e.length < t.length ? Js(r, n, e) : e.forEach(function (e, o) {
    zs(e, t[o], n + "[" + o + "]", r);
  }) : Js(r, n, e);
}function Js(e, t, n) {
  e[t] = n;
}function Gs(e) {
  var t = e.ctx.__next_tick_callbacks;

  if (t && t.length) {
    var _e26 = t.slice(0);

    t.length = 0;

    for (var _t27 = 0; _t27 < _e26.length; _t27++) {
      _e26[_t27]();
    }
  }
}function Ys(e, t) {
  var n = e.ctx;
  if (!n.__next_tick_pending && !function (e) {
    return uo.includes(e.update);
  }(e)) return yo(t && t.bind(e.proxy));
  var r;
  return n.__next_tick_callbacks || (n.__next_tick_callbacks = []), n.__next_tick_callbacks.push(function () {
    t ? oo(t.bind(e.proxy), e, 14) : r && r(e.proxy);
  }), new Promise(function (e) {
    r = e;
  });
}function Qs(e, t) {
  var n = _typeof2(e = Bs(e));

  if ("object" === n && null !== e) {
    var _n22 = t.get(e);

    if (void 0 !== _n22) return _n22;

    if (b(e)) {
      var _r23 = e.length;
      _n22 = new Array(_r23), t.set(e, _n22);

      for (var _o14 = 0; _o14 < _r23; _o14++) {
        _n22[_o14] = Qs(e[_o14], t);
      }
    } else {
      _n22 = {}, t.set(e, _n22);

      for (var _r24 in e) {
        v(e, _r24) && (_n22[_r24] = Qs(e[_r24], t));
      }
    }

    return _n22;
  }

  if ("symbol" !== n) return e;
}function Xs(e) {
  return Qs(e, "undefined" != typeof WeakMap ? new WeakMap() : new Map());
}function Zs(e, t, n) {
  if (!t) return;
  t = Xs(t);
  var r = e.ctx,
      o = r.mpType;

  if ("page" === o || "component" === o) {
    t.r0 = 1;

    var _o15 = r.$scope,
        _s12 = Object.keys(t),
        _i11 = Vs(t, n || function (e, t) {
      var n = e.data,
          r = Object.create(null);
      return t.forEach(function (e) {
        r[e] = n[e];
      }), r;
    }(_o15, _s12));

    Object.keys(_i11).length ? (r.__next_tick_pending = !0, _o15.setData(_i11, function () {
      r.__next_tick_pending = !1, Gs(e);
    }), wo()) : Gs(e);
  }
}function ei(e, t, n) {
  t.appContext.config.globalProperties.$applyOptions(e, t, n);
  var r = e.computed;

  if (r) {
    var _e27 = Object.keys(r);

    if (_e27.length) {
      var _n23$$computedKeys;

      var _n23 = t.ctx;
      _n23.$computedKeys || (_n23.$computedKeys = []), (_n23$$computedKeys = _n23.$computedKeys).push.apply(_n23$$computedKeys, _toConsumableArray2(_e27));
    }
  }

  delete t.ctx.$onApplyOptions;
}function ti(e) {
  var t = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : !1;
  var n = e.setupState,
      r = e.$templateRefs,
      _e$ctx = e.ctx,
      o = _e$ctx.$scope,
      s = _e$ctx.$mpPlatform;
  if ("mp-alipay" === s) return;
  if (!r || !o) return;
  if (t) return r.forEach(function (e) {
    return ni(e, null, n);
  });

  var i = "mp-baidu" === s || "mp-toutiao" === s,
      a = function a(e) {
    var t = (o.selectAllComponents(".r") || []).concat(o.selectAllComponents(".r-i-f") || []);
    return e.filter(function (e) {
      var r = function (e, t) {
        var n = e.find(function (e) {
          return e && (e.properties || e.props).uI === t;
        });

        if (n) {
          var _e28 = n.$vm;
          return _e28 ? Us(_e28.$) || _e28 : function (e) {
            P(e) && Br(e);
            return e;
          }(n);
        }

        return null;
      }(t, e.i);

      return !(!i || null !== r) || (ni(e, r, n), !1);
    });
  },
      c = function c() {
    var t = a(r);
    t.length && e.proxy && e.proxy.$scope && e.proxy.$scope.setData({
      r1: 1
    }, function () {
      a(t);
    });
  };

  o._$setRef ? o._$setRef(c) : Ys(e, c);
}function ni(_ref20, n, r) {
  var e = _ref20.r,
      t = _ref20.f;
  if (k(e)) e(n, {});else {
    var _o16 = x(e),
        _s13 = zr(e);

    if (_o16 || _s13) if (t) {
      if (!_s13) return;
      b(e.value) || (e.value = []);
      var _t28 = e.value;

      if (-1 === _t28.indexOf(n)) {
        if (_t28.push(n), !n) return;
        zo(function () {
          return m(_t28, n);
        }, n.$);
      }
    } else _o16 ? v(r, e) && (r[e] = n) : zr(e) && (e.value = n);
  }
}var ri, oi;(oi = ri || (ri = {})).APP = "app", oi.PAGE = "page", oi.COMPONENT = "component";var si = _o;function ii(e, t) {
  var n = e.component = Cs(e, t.parentComponent, null);
  return n.ctx.$onApplyOptions = ei, n.ctx.$children = [], "app" === t.mpType && (n.render = l), t.onBeforeSetup && t.onBeforeSetup(n, t), js(n), t.parentComponent && n.proxy && t.parentComponent.ctx.$children.push(Us(n) || n.proxy), function (e) {
    var t = ui.bind(e);

    e.$updateScopedSlots = function () {
      return yo(function () {
        return vo(t);
      });
    };

    var n = function n() {
      if (e.isMounted) {
        var _t29 = e.next,
            _n24 = e.bu,
            _r25 = e.u;
        li(e, !1), Hn(), wo(), Kn(), _n24 && F(_n24), li(e, !0), Zs(e, ai(e)), _r25 && si(_r25);
      } else zo(function () {
        ti(e, !0);
      }, e), Zs(e, ai(e));
    },
        r = e.effect = new Un(n, function () {
      return vo(e.update);
    }, e.scope),
        o = e.update = r.run.bind(r);

    o.id = e.uid, li(e, !0), o();
  }(n), n.proxy;
}function ai(e) {
  var t = e.type,
      n = e.vnode,
      r = e.proxy,
      o = e.withProxy,
      s = e.props,
      _e$propsOptions2 = _slicedToArray2(e.propsOptions, 1),
      i = _e$propsOptions2[0],
      a = e.slots,
      c = e.attrs,
      u = e.emit,
      l = e.render,
      f = e.renderCache,
      h = e.data,
      p = e.setupState,
      g = e.ctx,
      m = e.uid,
      y = e.appContext.app.config.globalProperties.pruneComponentPropsCache,
      v = e.inheritAttrs;

  var b;
  e.$templateRefs = [], e.$ei = 0, y(m), e.__counter = 0 === e.__counter ? 1 : 0;

  var _ = To(e);

  try {
    if (4 & n.shapeFlag) {
      ci(v, s, i, c);

      var _e29 = o || r;

      b = l.call(_e29, _e29, f, s, p, h, g);
    } else {
      ci(v, s, i, t.props ? c : function (e) {
        var t;

        for (var _n25 in e) {
          ("class" === _n25 || "style" === _n25 || d(_n25)) && ((t || (t = {}))[_n25] = e[_n25]);
        }

        return t;
      }(c));
      var _e30 = t;
      b = _e30.length > 1 ? _e30(s, {
        attrs: c,
        slots: a,
        emit: u
      }) : _e30(s, null);
    }
  } catch (w) {
    io(w, e, 1), b = !1;
  }

  return ti(e), To(_), b;
}function ci(e, t, n, r) {
  if (t && r && !1 !== e) {
    var _e31 = Object.keys(r).filter(function (e) {
      return "class" !== e && "style" !== e;
    });

    if (!_e31.length) return;
    n && _e31.some(p) ? _e31.forEach(function (e) {
      p(e) && e.slice(9) in n || (t[e] = r[e]);
    }) : _e31.forEach(function (e) {
      return t[e] = r[e];
    });
  }
}function ui() {
  var e = this.$scopedSlotsData;
  if (!e || 0 === e.length) return;
  var t = this.ctx.$scope,
      n = t.data,
      r = Object.create(null);
  e.forEach(function (_ref21) {
    var e = _ref21.path,
        t = _ref21.index,
        o = _ref21.data;
    var s = ye(n, e),
        i = x(t) ? "".concat(e, ".").concat(t) : "".concat(e, "[").concat(t, "]");
    if (void 0 === s || void 0 === s[t]) r[i] = o;else {
      var _e32 = Vs(o, s[t]);

      Object.keys(_e32).forEach(function (t) {
        r[i + "." + t] = _e32[t];
      });
    }
  }), e.length = 0, Object.keys(r).length && t.setData(r);
}function li(_ref22, n) {
  var e = _ref22.effect,
      t = _ref22.update;
  e.allowRecurse = t.allowRecurse = n;
}var fi = function fi(e) {
  var t = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : null;
  k(e) || (e = Object.assign({}, e)), null == t || P(t) || (t = null);
  var n = Ss(),
      r = new Set(),
      o = n.app = {
    _uid: Ps++,
    _component: e,
    _props: t,
    _container: null,
    _context: n,
    _instance: null,
    version: qs,

    get config() {
      return n.config;
    },

    set config(e) {},

    use: function use(e) {
      for (var _len10 = arguments.length, t = new Array(_len10 > 1 ? _len10 - 1 : 0), _key10 = 1; _key10 < _len10; _key10++) {
        t[_key10 - 1] = arguments[_key10];
      }

      return r.has(e) || (e && k(e.install) ? (r.add(e), e.install.apply(e, [o].concat(t))) : k(e) && (r.add(e), e.apply(void 0, [o].concat(t)))), o;
    },
    mixin: function mixin(e) {
      return n.mixins.includes(e) || n.mixins.push(e), o;
    },
    component: function component(e, t) {
      return t ? (n.components[e] = t, o) : n.components[e];
    },
    directive: function directive(e, t) {
      return t ? (n.directives[e] = t, o) : n.directives[e];
    },
    mount: function mount() {},
    unmount: function unmount() {},
    provide: function provide(e, t) {
      return n.provides[e] = t, o;
    }
  };
  return o;
};function hi(e) {
  var t = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : null;
  ("undefined" != typeof window ? window : "undefined" != typeof globalThis ? globalThis : "undefined" != typeof global ? global : "undefined" != typeof my ? my : void 0).__VUE__ = !0;
  var n = fi(e, t),
      r = n._context;

  r.config.globalProperties.$nextTick = function (e) {
    return Ys(this.$, e);
  };

  var o = function o(e) {
    return e.appContext = r, e.shapeFlag = 6, e;
  },
      s = function s(e, t) {
    return ii(o(e), t);
  },
      i = function i(e) {
    return e && function (e) {
      var t = e.bum,
          n = e.scope,
          r = e.update,
          o = e.um;
      t && F(t), n.stop(), r && (r.active = !1), o && si(o), si(function () {
        e.isUnmounted = !0;
      });
    }(e.$);
  };

  return n.mount = function () {
    e.render = l;
    var t = ii(o({
      type: e
    }), {
      mpType: ri.APP,
      mpInstance: null,
      parentComponent: null,
      slots: [],
      props: null
    });
    return n._instance = t.$, t.$app = n, t.$createComponent = s, t.$destroyComponent = i, r.$appInstance = t, t;
  }, n.unmount = function () {}, n;
}function di(e, t, n, r) {
  k(t) && qo(e, t.bind(n), r);
}function pi(e, t, n) {
  !function (e, t, n) {
    var r = e.mpType || n.$mpType;
    r && "component" !== r && Object.keys(e).forEach(function (r) {
      if (Se(r, e[r], !1)) {
        var _o17 = e[r];
        b(_o17) ? _o17.forEach(function (e) {
          return di(r, e, n, t);
        }) : di(r, _o17, n, t);
      }
    });
  }(e, t, n);
}function gi(e, t, n) {
  return e[t] = n;
}function mi(e) {
  return function (t, n, r) {
    if (!n) throw t;
    var o = e._instance;
    if (!o || !o.proxy) throw t;
    o.proxy.$callHook(W, t);
  };
}function yi(e, t) {
  return e ? _toConsumableArray2(new Set([].concat(e, t))) : t;
}var vi;var bi = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/=",
    _i = /^(?:[A-Za-z\d+/]{4})*?(?:[A-Za-z\d+/]{2}(?:==)?|[A-Za-z\d+/]{3}=?)?$/;function wi() {
  var e = On.getStorageSync("uni_id_token") || "",
      t = e.split(".");
  if (!e || 3 !== t.length) return {
    uid: null,
    role: [],
    permission: [],
    tokenExpired: 0
  };
  var n;

  try {
    n = JSON.parse((r = t[1], decodeURIComponent(vi(r).split("").map(function (e) {
      return "%" + ("00" + e.charCodeAt(0).toString(16)).slice(-2);
    }).join(""))));
  } catch (o) {
    throw new Error("获取当前用户信息出错，详细错误信息为：" + o.message);
  }

  var r;
  return n.tokenExpired = 1e3 * n.exp, delete n.exp, delete n.iat, n;
}function ki(e) {
  var t = e._context.config;
  var n;
  t.errorHandler = Oe(e, mi), n = t.optionMergeStrategies, ke.forEach(function (e) {
    n[e] = yi;
  });
  var r = t.globalProperties;
  !function (e) {
    e.uniIDHasRole = function (e) {
      var _wi = wi(),
          t = _wi.role;

      return t.indexOf(e) > -1;
    }, e.uniIDHasPermission = function (e) {
      var _wi2 = wi(),
          t = _wi2.permission;

      return this.uniIDHasRole("admin") || t.indexOf(e) > -1;
    }, e.uniIDTokenValid = function () {
      var _wi3 = wi(),
          e = _wi3.tokenExpired;

      return e > Date.now();
    };
  }(r), r.$set = gi, r.$applyOptions = pi, On.invokeCreateVueAppHook(e);
}vi = "function" != typeof atob ? function (e) {
  if (e = String(e).replace(/[\t\n\f\r ]+/g, ""), !_i.test(e)) throw new Error("Failed to execute 'atob' on 'Window': The string to be decoded is not correctly encoded.");
  var t;
  e += "==".slice(2 - (3 & e.length));

  for (var n, r, o = "", s = 0; s < e.length;) {
    t = bi.indexOf(e.charAt(s++)) << 18 | bi.indexOf(e.charAt(s++)) << 12 | (n = bi.indexOf(e.charAt(s++))) << 6 | (r = bi.indexOf(e.charAt(s++))), o += 64 === n ? String.fromCharCode(t >> 16 & 255) : 64 === r ? String.fromCharCode(t >> 16 & 255, t >> 8 & 255) : String.fromCharCode(t >> 16 & 255, t >> 8 & 255, 255 & t);
  }

  return o;
} : atob;var xi = Object.create(null);function Si(e) {
  delete xi[e];
}function Pi(e) {
  if (!e) return;

  var _e$split = e.split(","),
      _e$split2 = _slicedToArray2(_e$split, 2),
      t = _e$split2[0],
      n = _e$split2[1];

  return xi[t] ? xi[t][parseInt(n)] : void 0;
}var Ai = {
  install: function install(e) {
    ki(e), e.config.globalProperties.pruneComponentPropsCache = Si;
    var t = e.mount;

    e.mount = function (n) {
      var r = t.call(e, n),
          o = function () {
        var e = "createApp";
        if ("undefined" != typeof global) return global[e];
        if ("undefined" != typeof my) return my[e];
      }();

      return o ? o(r) : "undefined" != typeof createMiniProgramApp && createMiniProgramApp(r), r;
    };
  }
};function Oi(e, t) {
  var n = Ms(),
      r = n.ctx,
      o = void 0 === t || "mp-weixin" !== r.$mpPlatform && "mp-qq" !== r.$mpPlatform || !x(t) && "number" != typeof t ? "" : "_" + t,
      s = "e" + n.$ei++ + o,
      i = r.$scope;
  if (!e) return delete i[s], s;
  var a = i[s];
  return a ? a.value = e : i[s] = function (e, t) {
    var n = function n(e) {
      var r;
      (r = e).type && r.target && (r.preventDefault = l, r.stopPropagation = l, r.stopImmediatePropagation = l, v(r, "detail") || (r.detail = {}), v(r, "markerId") && (r.detail = "object" == _typeof2(r.detail) ? r.detail : {}, r.detail.markerId = r.markerId), T(r.detail) && v(r.detail, "checked") && !v(r.detail, "value") && (r.detail.value = r.detail.checked), T(r.detail) && (r.target = g({}, r.target, r.detail)));
      var o = [e];
      e.detail && e.detail.__args__ && (o = e.detail.__args__);

      var s = n.value,
          i = function i() {
        return so(function (e, t) {
          if (b(t)) {
            var _n26 = e.stopImmediatePropagation;
            return e.stopImmediatePropagation = function () {
              _n26 && _n26.call(e), e._stopped = !0;
            }, t.map(function (e) {
              return function (t) {
                return !t._stopped && e(t);
              };
            });
          }

          return t;
        }(e, s), t, 5, o);
      },
          a = e.target,
          c = !!a && !!a.dataset && "true" === a.dataset.eventsync;

      if (!Ii.includes(e.type) || c) {
        var _t30 = i();

        if ("input" === e.type && (b(_t30) || A(_t30))) return;
        return _t30;
      }

      setTimeout(i);
    };

    return n.value = e, n;
  }(e, n), s;
}var Ii = ["tap", "longpress", "longtap", "transitionend", "animationstart", "animationiteration", "animationend", "touchforcechange"];function Ti(e) {
  var t = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : {};
  var n = arguments.length > 2 ? arguments[2] : undefined;
  var r = Ms(),
      o = r.parent,
      s = r.isMounted,
      i = r.ctx.$scope,
      a = (i.properties || i.props).uI;
  if (!a) return;
  if (!o && !s) return void Ko(function () {
    Ti(e, t, n);
  }, r);

  var c = function (e, t) {
    var n = t.parent;

    for (; n;) {
      var _t31 = n.$ssi;
      if (_t31 && _t31[e]) return _t31[e];
      n = n.parent;
    }
  }(a, r);

  c && c(e, t, n);
}function Ci(e, _ref23) {
  var t = _ref23.name,
      n = _ref23.path,
      r = _ref23.vueId;
  var o = Ms();
  e.path = n;

  var s = o.$ssi || (o.$ssi = {}),
      i = s[r] || (s[r] = function (e) {
    var t = function t(n, r, o) {
      var s = t.slots[n];
      if (!s) return;
      var i = void 0 !== o;
      o = o || 0;
      var a = To(e),
          c = s.fn(r, n + (i ? "-" + o : ""), o),
          u = s.fn.path;
      To(a), (e.$scopedSlotsData || (e.$scopedSlotsData = [])).push({
        path: u,
        index: o,
        data: c
      }), e.$updateScopedSlots();
    };

    return t.slots = {}, t;
  }(o));

  return i.slots[t] ? i.slots[t].fn = e : i.slots[t] = {
    fn: e
  }, ye(o.ctx.$scope.data, n);
}function Ei(e) {
  return x(e) ? e : function (e) {
    var t = "";
    if (!e || x(e)) return t;

    for (var _n27 in e) {
      t += "".concat(_n27.startsWith("--") ? _n27 : N(_n27), ":").concat(e[_n27], ";");
    }

    return t;
  }(t(e));
}var Mi = function Mi(e) {
  var t = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : null;
  return e && (e.mpType = "app"), hi(e, t).use(Ai);
},
    Li = ["createSelectorQuery", "createIntersectionObserver", "selectAllComponents", "selectComponent"];function $i(e, t) {
  var n = e.ctx;
  n.mpType = t.mpType, n.$mpType = t.mpType, n.$mpPlatform = "mp-weixin", n.$scope = t.mpInstance, n.$mp = {}, n._self = {}, e.slots = {}, b(t.slots) && t.slots.length && (t.slots.forEach(function (t) {
    e.slots[t] = !0;
  }), e.slots.d && (e.slots.default = !0)), n.getOpenerEventChannel = function () {
    return t.mpInstance.getOpenerEventChannel();
  }, n.$hasHook = Ri, n.$callHook = Ni, e.emit = function (e, t) {
    return function (n) {
      var o = t.$scope;

      for (var _len11 = arguments.length, r = new Array(_len11 > 1 ? _len11 - 1 : 0), _key11 = 1; _key11 < _len11; _key11++) {
        r[_key11 - 1] = arguments[_key11];
      }

      if (o && n) {
        var _e33 = {
          __args__: r
        };
        o.triggerEvent(n, _e33);
      }

      return e.apply(this, [n].concat(r));
    };
  }(e.emit, n);
}function Ri(e) {
  var t = this.$[e];
  return !(!t || !t.length);
}function Ni(e, t) {
  "mounted" === e && (Ni.call(this, "bm"), this.$.isMounted = !0, e = "m");
  var n = this.$[e];
  return n && function (e, t) {
    var n;

    for (var _r26 = 0; _r26 < e.length; _r26++) {
      n = e[_r26](t);
    }

    return n;
  }(n, t);
}var ji = [Y, H, K, X, te, oe, se, ie, ce];function Di(e) {
  var t = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : new Set();

  if (e) {
    Object.keys(e).forEach(function (n) {
      Se(n, e[n]) && t.add(n);
    });
    {
      var _n28 = e.extends,
          _r27 = e.mixins;
      _r27 && _r27.forEach(function (e) {
        return Di(e, t);
      }), _n28 && Di(_n28, t);
    }
  }

  return t;
}function Ui(e, t, n) {
  -1 !== n.indexOf(t) || v(e, t) || (e[t] = function (e) {
    return this.$vm && this.$vm.$callHook(t, e);
  });
}var Fi = [Q];function qi(e, t) {
  var n = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : Fi;
  t.forEach(function (t) {
    return Ui(e, t, n);
  });
}function Bi(e, t) {
  var n = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : Fi;
  Di(t).forEach(function (t) {
    return Ui(e, t, n);
  });
}var Hi = me(function () {
  var e = [],
      t = k(getApp) && getApp({
    allowDefault: !0
  });

  if (t && t.$vm && t.$vm.$) {
    var _n29 = t.$vm.$.appContext.mixins;

    if (b(_n29)) {
      var _t32 = Object.keys(xe);

      _n29.forEach(function (n) {
        _t32.forEach(function (t) {
          v(n, t) && !e.includes(t) && e.push(t);
        });
      });
    }
  }

  return e;
});var Ki = [H, K, W, z, J, G];function Vi(e, t) {
  var n = e.$,
      r = {
    globalData: e.$options && e.$options.globalData || {},
    $vm: e,
    onLaunch: function onLaunch(t) {
      this.$vm = e;
      var r = n.ctx;
      this.$vm && r.$scope || ($i(n, {
        mpType: "app",
        mpInstance: this,
        slots: []
      }), r.globalData = this.globalData, e.$callHook(V, t));
    }
  };
  !function (e) {
    var t = Jr(Ue(wx.getSystemInfoSync().language) || Re);
    Object.defineProperty(e, "$locale", {
      get: function get() {
        return t.value;
      },
      set: function set(e) {
        t.value = e;
      }
    });
  }(e);
  var o = e.$.type;
  qi(r, Ki), Bi(r, o);
  {
    var _e34 = o.methods;
    _e34 && g(r, _e34);
  }
  return t && t.parse(r), r;
}function Wi(e, t) {
  if (k(e.onLaunch)) {
    var _t33 = wx.getLaunchOptionsSync && wx.getLaunchOptionsSync();

    e.onLaunch(_t33);
  }

  k(e.onShow) && wx.onAppShow && wx.onAppShow(function (e) {
    t.$callHook("onShow", e);
  }), k(e.onHide) && wx.onAppHide && wx.onAppHide(function (e) {
    t.$callHook("onHide", e);
  });
}var zi = ["externalClasses"];var Ji = /_(.*)_worklet_factory_/;function Gi(e, t) {
  var n = e.$children;

  for (var _o18 = n.length - 1; _o18 >= 0; _o18--) {
    var _e35 = n[_o18];
    if (_e35.$scope._$vueId === t) return _e35;
  }

  var r;

  for (var _o19 = n.length - 1; _o19 >= 0; _o19--) {
    if (r = Gi(n[_o19], t), r) return r;
  }
}var Yi = ["eO", "uR", "uRIF", "uI", "uT", "uP", "uS"];function Qi(e) {
  e.properties || (e.properties = {}), g(e.properties, function (e) {
    var t = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : !1;
    var n = {};
    return t || (Yi.forEach(function (e) {
      n[e] = {
        type: null,
        value: ""
      };
    }), n.uS = {
      type: null,
      value: [],
      observer: function observer(e) {
        var t = Object.create(null);
        e && e.forEach(function (e) {
          t[e] = !0;
        }), this.setData({
          $slots: t
        });
      }
    }), e.behaviors && e.behaviors.includes("wx://form-field") && (n.name = {
      type: null,
      value: ""
    }, n.value = {
      type: null,
      value: ""
    }), n;
  }(e), function (e) {
    var t = {};
    return e && e.virtualHost && (t.virtualHostStyle = {
      type: null,
      value: ""
    }, t.virtualHostClass = {
      type: null,
      value: ""
    }), t;
  }(e.options));
}var Xi = [String, Number, Boolean, Object, Array, null];function Zi(e, t) {
  var n = function (e, t) {
    return b(e) && 1 === e.length ? e[0] : e;
  }(e);

  return -1 !== Xi.indexOf(n) ? n : null;
}function ea(e, t) {
  return (t ? function (e) {
    var t = {};
    T(e) && Object.keys(e).forEach(function (n) {
      -1 === Yi.indexOf(n) && (t[n] = e[n]);
    });
    return t;
  }(e) : Pi(e.uP)) || {};
}function ta(e) {
  var t = function t() {
    var e = this.properties.uP;
    e && (this.$vm ? function (e, t) {
      var n = qr(t.props),
          r = Pi(e) || {};
      na(n, r) && (!function (e, t, n, r) {
        var o = e.props,
            s = e.attrs,
            i = e.vnode.patchFlag,
            a = qr(o),
            _e$propsOptions3 = _slicedToArray2(e.propsOptions, 1),
            c = _e$propsOptions3[0];

        var u = !1;

        if (!(r || i > 0) || 16 & i) {
          var _r28;

          ys(e, t, o, s) && (u = !0);

          for (var _s14 in a) {
            t && (v(t, _s14) || (_r28 = N(_s14)) !== _s14 && v(t, _r28)) || (c ? !n || void 0 === n[_s14] && void 0 === n[_r28] || (o[_s14] = vs(c, a, _s14, void 0, e, !0)) : delete o[_s14]);
          }

          if (s !== a) for (var _e36 in s) {
            t && v(t, _e36) || (delete s[_e36], u = !0);
          }
        } else if (8 & i) {
          var _n30 = e.vnode.dynamicProps;

          for (var _r29 = 0; _r29 < _n30.length; _r29++) {
            var _i12 = _n30[_r29];
            if (Oo(e.emitsOptions, _i12)) continue;
            var _l5 = t[_i12];
            if (c) {
              if (v(s, _i12)) _l5 !== s[_i12] && (s[_i12] = _l5, u = !0);else {
                var _t34 = $(_i12);

                o[_t34] = vs(c, a, _t34, _l5, e, !1);
              }
            } else _l5 !== s[_i12] && (s[_i12] = _l5, u = !0);
          }
        }

        u && zn(e, "set", "$attrs");
      }(t, r, n, !1), o = t.update, uo.indexOf(o) > -1 && function (e) {
        var t = uo.indexOf(e);
        t > lo && uo.splice(t, 1);
      }(t.update), t.update());
      var o;
    }(e, this.$vm.$) : "m" === this.properties.uT && function (e, t) {
      var n = t.properties,
          r = Pi(e) || {};
      na(n, r, !1) && t.setData(r);
    }(e, this));
  };

  e.observers || (e.observers = {}), e.observers.uP = t;
}function na(e, t) {
  var n = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : !0;
  var r = Object.keys(t);
  if (n && r.length !== Object.keys(e).length) return !0;

  for (var _o20 = 0; _o20 < r.length; _o20++) {
    var _n31 = r[_o20];
    if (t[_n31] !== e[_n31]) return !0;
  }

  return !1;
}function ra(e, t) {
  e.data = {}, e.behaviors = function (e) {
    var t = e.behaviors;
    var n = e.props;
    n || (e.props = n = []);
    var r = [];
    return b(t) && t.forEach(function (e) {
      r.push(e.replace("uni://", "wx://")), "uni://form-field" === e && (b(n) ? (n.push("name"), n.push("modelValue")) : (n.name = {
        type: String,
        default: ""
      }, n.modelValue = {
        type: [String, Number, Boolean, Array, Object, Date],
        default: ""
      }));
    }), r;
  }(t);
}function oa(e, _ref24) {
  var t = _ref24.parse,
      n = _ref24.mocks,
      r = _ref24.isPage,
      o = _ref24.initRelation,
      s = _ref24.handleLink,
      i = _ref24.initLifetimes;
  e = e.default || e;
  var a = {
    multipleSlots: !0,
    addGlobalClass: !0,
    pureDataPattern: /^uP$/
  };
  b(e.mixins) && e.mixins.forEach(function (e) {
    P(e.options) && g(a, e.options);
  }), e.options && g(a, e.options);
  var c = {
    options: a,
    lifetimes: i({
      mocks: n,
      isPage: r,
      initRelation: o,
      vueOptions: e
    }),
    pageLifetimes: {
      show: function show() {
        this.$vm && this.$vm.$callHook("onPageShow");
      },
      hide: function hide() {
        this.$vm && this.$vm.$callHook("onPageHide");
      },
      resize: function resize(e) {
        this.$vm && this.$vm.$callHook("onPageResize", e);
      }
    },
    methods: {
      __l: s
    }
  };
  var u, l, f, h;
  return ra(c, e), Qi(c), ta(c), function (e, t) {
    zi.forEach(function (n) {
      v(t, n) && (e[n] = t[n]);
    });
  }(c, e), u = c.methods, l = e.wxsCallMethods, b(l) && l.forEach(function (e) {
    u[e] = function (t) {
      return this.$vm[e](t);
    };
  }), f = c.methods, (h = e.methods) && Object.keys(h).forEach(function (e) {
    var t = e.match(Ji);

    if (t) {
      var _n32 = t[1];
      f[e] = h[e], f[_n32] = h[_n32];
    }
  }), t && t(c, {
    handleLink: s
  }), c;
}var sa, ia;function aa() {
  return getApp().$vm;
}function ca(e, t) {
  var n = t.parse,
      r = t.mocks,
      o = t.isPage,
      s = t.initRelation,
      i = t.handleLink,
      a = t.initLifetimes,
      c = oa(e, {
    mocks: r,
    isPage: o,
    initRelation: s,
    handleLink: i,
    initLifetimes: a
  });
  !function (_ref25, t) {
    var e = _ref25.properties;
    b(t) ? t.forEach(function (t) {
      e[t] = {
        type: String,
        value: ""
      };
    }) : T(t) && Object.keys(t).forEach(function (n) {
      var r = t[n];

      if (T(r)) {
        var _t35 = r.default;
        k(_t35) && (_t35 = _t35());
        var _o21 = r.type;
        r.type = Zi(_o21), e[n] = {
          type: r.type,
          value: _t35
        };
      } else e[n] = {
        type: Zi(r)
      };
    });
  }(c, (e.default || e).props);
  var u = c.methods;
  return u.onLoad = function (e) {
    var t;
    return this.options = e, this.$page = {
      fullPath: (t = this.route + _e(e), function (e) {
        return 0 === e.indexOf("/");
      }(t) ? t : "/" + t)
    }, this.$vm && this.$vm.$callHook(Y, e);
  }, qi(u, ji), Bi(u, e), function (e, t) {
    if (!t) return;
    Object.keys(xe).forEach(function (n) {
      t & xe[n] && Ui(e, n, []);
    });
  }(u, e.__runtimeHooks), qi(u, Hi()), n && n(c, {
    handleLink: i
  }), c;
}var ua = Page,
    la = Component;function fa(e) {
  var t = e.triggerEvent,
      n = function n(_n33) {
    for (var _len12 = arguments.length, r = new Array(_len12 > 1 ? _len12 - 1 : 0), _key12 = 1; _key12 < _len12; _key12++) {
      r[_key12 - 1] = arguments[_key12];
    }

    return t.apply(e, [(o = _n33, $(o.replace(ge, "-")))].concat(r));
    var o;
  };

  try {
    e.triggerEvent = n;
  } catch (r) {
    e._triggerEvent = n;
  }
}function ha(e, t, n) {
  var r = t[e];
  t[e] = r ? function () {
    for (var _len13 = arguments.length, e = new Array(_len13), _key13 = 0; _key13 < _len13; _key13++) {
      e[_key13] = arguments[_key13];
    }

    return fa(this), r.apply(this, e);
  } : function () {
    fa(this);
  };
}Page = function Page(e) {
  return ha(Y, e), ua(e);
}, Component = function Component(e) {
  ha("created", e);
  return e.properties && e.properties.uP || (Qi(e), ta(e)), la(e);
};var da = Object.freeze({
  __proto__: null,
  handleLink: function handleLink(e) {
    var t = e.detail || e.value,
        n = t.vuePid;
    var r;
    n && (r = Gi(this.$vm, n)), r || (r = this.$vm), t.parent = r;
  },
  initLifetimes: function initLifetimes(_ref26) {
    var e = _ref26.mocks,
        t = _ref26.isPage,
        n = _ref26.initRelation,
        r = _ref26.vueOptions;
    return {
      attached: function attached() {
        var o = this.properties;
        !function (e, t) {
          if (!e) return;
          var n = e.split(","),
              r = n.length;
          1 === r ? t._$vueId = n[0] : 2 === r && (t._$vueId = n[0], t._$vuePid = n[1]);
        }(o.uI, this);
        var s = {
          vuePid: this._$vuePid
        };
        n(this, s);
        var i = this,
            a = t(i);
        var c = o;
        this.$vm = function (e, t) {
          sa || (sa = aa().$createComponent);
          var n = sa(e, t);
          return Us(n.$) || n;
        }({
          type: r,
          props: ea(c, a)
        }, {
          mpType: a ? "page" : "component",
          mpInstance: i,
          slots: o.uS || {},
          parentComponent: s.parent && s.parent.$,
          onBeforeSetup: function onBeforeSetup(t, n) {
            !function (e, t) {
              Object.defineProperty(e, "refs", {
                get: function get() {
                  var e = {};
                  return function (e, t, n) {
                    e.selectAllComponents(t).forEach(function (e) {
                      var t = e.properties.uR;
                      n[t] = e.$vm || e;
                    });
                  }(t, ".r", e), t.selectAllComponents(".r-i-f").forEach(function (t) {
                    var n = t.properties.uR;
                    n && (e[n] || (e[n] = []), e[n].push(t.$vm || t));
                  }), e;
                }
              });
            }(t, i), function (e, t, n) {
              var r = e.ctx;
              n.forEach(function (n) {
                v(t, n) && (e[n] = r[n] = t[n]);
              });
            }(t, i, e), function (e, t) {
              $i(e, t);
              var n = e.ctx;
              Li.forEach(function (e) {
                n[e] = function () {
                  var r = n.$scope;

                  for (var _len14 = arguments.length, t = new Array(_len14), _key14 = 0; _key14 < _len14; _key14++) {
                    t[_key14] = arguments[_key14];
                  }

                  if (r && r[e]) return r[e].apply(r, t);
                };
              });
            }(t, n);
          }
        }), a || function (e) {
          var t = e.$options;
          b(t.behaviors) && t.behaviors.includes("uni://form-field") && e.$watch("modelValue", function () {
            e.$scope && e.$scope.setData({
              name: e.name,
              value: e.modelValue
            });
          }, {
            immediate: !0
          });
        }(this.$vm);
      },
      ready: function ready() {
        this.$vm && (this.$vm.$callHook("mounted"), this.$vm.$callHook(Q));
      },
      detached: function detached() {
        var e;
        this.$vm && (Si(this.$vm.$.uid), e = this.$vm, ia || (ia = aa().$destroyComponent), ia(e));
      }
    };
  },
  initRelation: function initRelation(e, t) {
    e.triggerEvent("__l", t);
  },
  isPage: function isPage(e) {
    return !!e.route;
  },
  mocks: ["__route__", "__wxExparserNodeId__", "__wxWebviewId__"]
});var pa = function pa(e) {
  return App(Vi(e, ga));
};var ga;var ma = (ya = da, function (e) {
  return Component(ca(e, ya));
});var ya;var va = function (e) {
  return function (t) {
    return Component(oa(t, e));
  };
}(da),
    ba = function (e) {
  return function (t) {
    Wi(Vi(t, e), t);
  };
}(),
    _a = function (e) {
  return function (t) {
    var n = Vi(t, e),
        r = k(getApp) && getApp({
      allowDefault: !0
    });
    if (!r) return;
    t.$.ctx.$scope = r;
    var o = r.globalData;
    o && Object.keys(n.globalData).forEach(function (e) {
      v(o, e) || (o[e] = n.globalData[e]);
    }), Object.keys(n).forEach(function (e) {
      v(r, e) || (r[e] = n[e]);
    }), Wi(n, t);
  };
}();wx.createApp = global.createApp = pa, wx.createPage = ma, wx.createComponent = va, wx.createPluginApp = global.createPluginApp = ba, wx.createSubpackageApp = global.createSubpackageApp = _a;var wa = {
  pages: [{
    path: "pages/index/index",
    style: {
      navigationBarTitleText: "大转盘",
      enablePullDownRefresh: !0
    }
  }, {
    path: "pages/add-wheel/add-wheel",
    style: {
      navigationBarTitleText: "",
      enablePullDownRefresh: !1
    }
  }, {
    path: "pages/detail-wheel/detail-wheel",
    style: {
      navigationBarTitleText: "",
      enablePullDownRefresh: !1,
      navigationStyle: "custom"
    }
  }, {
    path: "pages/other-wheels/other-wheels",
    style: {
      navigationBarTitleText: "转盘市场",
      enablePullDownRefresh: !0
    }
  }, {
    path: "pages/user-center/user-center",
    style: {
      navigationBarTitleText: "",
      enablePullDownRefresh: !1
    }
  }, {
    path: "pages/finger-wheel/finger-wheel",
    style: {
      navigationBarTitleText: "",
      enablePullDownRefresh: !1,
      navigationStyle: "custom",
      disableScroll: !0
    }
  }, {
    path: "pages/web-view/web-view",
    style: {
      navigationBarTitleText: "",
      enablePullDownRefresh: !1
    }
  }, {
    path: "pages/userinfo/userinfo",
    style: {
      navigationBarTitleText: "",
      enablePullDownRefresh: !1
    }
  }, {
    path: "uni_modules/uni-pay/pages/success/success",
    style: {
      backgroundColor: "#F8F8F8",
      navigationBarTitleText: "支付成功"
    }
  }, {
    path: "uni_modules/uni-pay/pages/ad-interactive-webview/ad-interactive-webview",
    style: {
      backgroundColor: "#F8F8F8",
      navigationBarTitleText: "ad"
    }
  }],
  tabBar: {
    list: [{
      pagePath: "pages/index/index",
      iconPath: "/static/home.png",
      selectedIconPath: "/static/home-s.png",
      text: "首页"
    }, {
      pagePath: "pages/other-wheels/other-wheels",
      iconPath: "/static/store.png",
      selectedIconPath: "/static/store-s.png",
      text: "转盘市场"
    }, {
      pagePath: "pages/finger-wheel/finger-wheel",
      iconPath: "/static/pointer.png",
      selectedIconPath: "/static/pointer-s.png",
      text: "指尖转盘"
    }, {
      pagePath: "pages/user-center/user-center",
      iconPath: "/static/my.png",
      selectedIconPath: "/static/my-s.png",
      text: "我的"
    }]
  },
  globalStyle: {
    navigationBarTextStyle: "black",
    navigationBarTitleText: "uni-app",
    navigationBarBackgroundColor: "#F8F8F8",
    backgroundColor: "#F8F8F8"
  },
  embeddedAppIdList: ["wx8abaf00ee8c3202e"],
  condition: {
    current: 0,
    list: [{
      name: "编辑转盘",
      path: "pages/add-wheel/add-wheel",
      query: "type=add"
    }]
  }
};function ka(e, t, n) {
  return e(n = {
    path: t,
    exports: {},
    require: function require(e, t) {
      return function () {
        throw new Error("Dynamic requires are not currently supported by @rollup/plugin-commonjs");
      }(null == t && n.path);
    }
  }, n.exports), n.exports;
}var xa = ka(function (e, t) {
  var n;
  e.exports = (n = n || function (e, t) {
    var n = Object.create || function () {
      function e() {}

      return function (t) {
        var n;
        return e.prototype = t, n = new e(), e.prototype = null, n;
      };
    }(),
        r = {},
        o = r.lib = {},
        s = o.Base = {
      extend: function extend(e) {
        var t = n(this);
        return e && t.mixIn(e), t.hasOwnProperty("init") && this.init !== t.init || (t.init = function () {
          t.$super.init.apply(this, arguments);
        }), t.init.prototype = t, t.$super = this, t;
      },
      create: function create() {
        var e = this.extend();
        return e.init.apply(e, arguments), e;
      },
      init: function init() {},
      mixIn: function mixIn(e) {
        for (var t in e) {
          e.hasOwnProperty(t) && (this[t] = e[t]);
        }

        e.hasOwnProperty("toString") && (this.toString = e.toString);
      },
      clone: function clone() {
        return this.init.prototype.extend(this);
      }
    },
        i = o.WordArray = s.extend({
      init: function init(e, t) {
        e = this.words = e || [], this.sigBytes = null != t ? t : 4 * e.length;
      },
      toString: function toString(e) {
        return (e || c).stringify(this);
      },
      concat: function concat(e) {
        var t = this.words,
            n = e.words,
            r = this.sigBytes,
            o = e.sigBytes;
        if (this.clamp(), r % 4) for (var s = 0; s < o; s++) {
          var i = n[s >>> 2] >>> 24 - s % 4 * 8 & 255;
          t[r + s >>> 2] |= i << 24 - (r + s) % 4 * 8;
        } else for (s = 0; s < o; s += 4) {
          t[r + s >>> 2] = n[s >>> 2];
        }
        return this.sigBytes += o, this;
      },
      clamp: function clamp() {
        var t = this.words,
            n = this.sigBytes;
        t[n >>> 2] &= 4294967295 << 32 - n % 4 * 8, t.length = e.ceil(n / 4);
      },
      clone: function clone() {
        var e = s.clone.call(this);
        return e.words = this.words.slice(0), e;
      },
      random: function random(t) {
        for (var n, r = [], o = function o(t) {
          var n = 987654321,
              r = 4294967295;
          return function () {
            var o = ((n = 36969 * (65535 & n) + (n >> 16) & r) << 16) + (t = 18e3 * (65535 & t) + (t >> 16) & r) & r;
            return o /= 4294967296, (o += .5) * (e.random() > .5 ? 1 : -1);
          };
        }, s = 0; s < t; s += 4) {
          var a = o(4294967296 * (n || e.random()));
          n = 987654071 * a(), r.push(4294967296 * a() | 0);
        }

        return new i.init(r, t);
      }
    }),
        a = r.enc = {},
        c = a.Hex = {
      stringify: function stringify(e) {
        for (var t = e.words, n = e.sigBytes, r = [], o = 0; o < n; o++) {
          var s = t[o >>> 2] >>> 24 - o % 4 * 8 & 255;
          r.push((s >>> 4).toString(16)), r.push((15 & s).toString(16));
        }

        return r.join("");
      },
      parse: function parse(e) {
        for (var t = e.length, n = [], r = 0; r < t; r += 2) {
          n[r >>> 3] |= parseInt(e.substr(r, 2), 16) << 24 - r % 8 * 4;
        }

        return new i.init(n, t / 2);
      }
    },
        u = a.Latin1 = {
      stringify: function stringify(e) {
        for (var t = e.words, n = e.sigBytes, r = [], o = 0; o < n; o++) {
          var s = t[o >>> 2] >>> 24 - o % 4 * 8 & 255;
          r.push(String.fromCharCode(s));
        }

        return r.join("");
      },
      parse: function parse(e) {
        for (var t = e.length, n = [], r = 0; r < t; r++) {
          n[r >>> 2] |= (255 & e.charCodeAt(r)) << 24 - r % 4 * 8;
        }

        return new i.init(n, t);
      }
    },
        l = a.Utf8 = {
      stringify: function stringify(e) {
        try {
          return decodeURIComponent(escape(u.stringify(e)));
        } catch (t) {
          throw new Error("Malformed UTF-8 data");
        }
      },
      parse: function parse(e) {
        return u.parse(unescape(encodeURIComponent(e)));
      }
    },
        f = o.BufferedBlockAlgorithm = s.extend({
      reset: function reset() {
        this._data = new i.init(), this._nDataBytes = 0;
      },
      _append: function _append(e) {
        "string" == typeof e && (e = l.parse(e)), this._data.concat(e), this._nDataBytes += e.sigBytes;
      },
      _process: function _process(t) {
        var n = this._data,
            r = n.words,
            o = n.sigBytes,
            s = this.blockSize,
            a = o / (4 * s),
            c = (a = t ? e.ceil(a) : e.max((0 | a) - this._minBufferSize, 0)) * s,
            u = e.min(4 * c, o);

        if (c) {
          for (var l = 0; l < c; l += s) {
            this._doProcessBlock(r, l);
          }

          var f = r.splice(0, c);
          n.sigBytes -= u;
        }

        return new i.init(f, u);
      },
      clone: function clone() {
        var e = s.clone.call(this);
        return e._data = this._data.clone(), e;
      },
      _minBufferSize: 0
    });

    o.Hasher = f.extend({
      cfg: s.extend(),
      init: function init(e) {
        this.cfg = this.cfg.extend(e), this.reset();
      },
      reset: function reset() {
        f.reset.call(this), this._doReset();
      },
      update: function update(e) {
        return this._append(e), this._process(), this;
      },
      finalize: function finalize(e) {
        return e && this._append(e), this._doFinalize();
      },
      blockSize: 16,
      _createHelper: function _createHelper(e) {
        return function (t, n) {
          return new e.init(n).finalize(t);
        };
      },
      _createHmacHelper: function _createHmacHelper(e) {
        return function (t, n) {
          return new h.HMAC.init(e, n).finalize(t);
        };
      }
    });
    var h = r.algo = {};
    return r;
  }(Math), n);
}),
    Sa = xa,
    Pa = (ka(function (e, t) {
  var n;
  e.exports = (n = Sa, function (e) {
    var t = n,
        r = t.lib,
        o = r.WordArray,
        s = r.Hasher,
        i = t.algo,
        a = [];
    !function () {
      for (var t = 0; t < 64; t++) {
        a[t] = 4294967296 * e.abs(e.sin(t + 1)) | 0;
      }
    }();
    var c = i.MD5 = s.extend({
      _doReset: function _doReset() {
        this._hash = new o.init([1732584193, 4023233417, 2562383102, 271733878]);
      },
      _doProcessBlock: function _doProcessBlock(e, t) {
        for (var n = 0; n < 16; n++) {
          var r = t + n,
              o = e[r];
          e[r] = 16711935 & (o << 8 | o >>> 24) | 4278255360 & (o << 24 | o >>> 8);
        }

        var s = this._hash.words,
            i = e[t + 0],
            c = e[t + 1],
            d = e[t + 2],
            p = e[t + 3],
            g = e[t + 4],
            m = e[t + 5],
            y = e[t + 6],
            v = e[t + 7],
            b = e[t + 8],
            _ = e[t + 9],
            w = e[t + 10],
            k = e[t + 11],
            x = e[t + 12],
            S = e[t + 13],
            P = e[t + 14],
            A = e[t + 15],
            O = s[0],
            I = s[1],
            T = s[2],
            C = s[3];
        O = u(O, I, T, C, i, 7, a[0]), C = u(C, O, I, T, c, 12, a[1]), T = u(T, C, O, I, d, 17, a[2]), I = u(I, T, C, O, p, 22, a[3]), O = u(O, I, T, C, g, 7, a[4]), C = u(C, O, I, T, m, 12, a[5]), T = u(T, C, O, I, y, 17, a[6]), I = u(I, T, C, O, v, 22, a[7]), O = u(O, I, T, C, b, 7, a[8]), C = u(C, O, I, T, _, 12, a[9]), T = u(T, C, O, I, w, 17, a[10]), I = u(I, T, C, O, k, 22, a[11]), O = u(O, I, T, C, x, 7, a[12]), C = u(C, O, I, T, S, 12, a[13]), T = u(T, C, O, I, P, 17, a[14]), O = l(O, I = u(I, T, C, O, A, 22, a[15]), T, C, c, 5, a[16]), C = l(C, O, I, T, y, 9, a[17]), T = l(T, C, O, I, k, 14, a[18]), I = l(I, T, C, O, i, 20, a[19]), O = l(O, I, T, C, m, 5, a[20]), C = l(C, O, I, T, w, 9, a[21]), T = l(T, C, O, I, A, 14, a[22]), I = l(I, T, C, O, g, 20, a[23]), O = l(O, I, T, C, _, 5, a[24]), C = l(C, O, I, T, P, 9, a[25]), T = l(T, C, O, I, p, 14, a[26]), I = l(I, T, C, O, b, 20, a[27]), O = l(O, I, T, C, S, 5, a[28]), C = l(C, O, I, T, d, 9, a[29]), T = l(T, C, O, I, v, 14, a[30]), O = f(O, I = l(I, T, C, O, x, 20, a[31]), T, C, m, 4, a[32]), C = f(C, O, I, T, b, 11, a[33]), T = f(T, C, O, I, k, 16, a[34]), I = f(I, T, C, O, P, 23, a[35]), O = f(O, I, T, C, c, 4, a[36]), C = f(C, O, I, T, g, 11, a[37]), T = f(T, C, O, I, v, 16, a[38]), I = f(I, T, C, O, w, 23, a[39]), O = f(O, I, T, C, S, 4, a[40]), C = f(C, O, I, T, i, 11, a[41]), T = f(T, C, O, I, p, 16, a[42]), I = f(I, T, C, O, y, 23, a[43]), O = f(O, I, T, C, _, 4, a[44]), C = f(C, O, I, T, x, 11, a[45]), T = f(T, C, O, I, A, 16, a[46]), O = h(O, I = f(I, T, C, O, d, 23, a[47]), T, C, i, 6, a[48]), C = h(C, O, I, T, v, 10, a[49]), T = h(T, C, O, I, P, 15, a[50]), I = h(I, T, C, O, m, 21, a[51]), O = h(O, I, T, C, x, 6, a[52]), C = h(C, O, I, T, p, 10, a[53]), T = h(T, C, O, I, w, 15, a[54]), I = h(I, T, C, O, c, 21, a[55]), O = h(O, I, T, C, b, 6, a[56]), C = h(C, O, I, T, A, 10, a[57]), T = h(T, C, O, I, y, 15, a[58]), I = h(I, T, C, O, S, 21, a[59]), O = h(O, I, T, C, g, 6, a[60]), C = h(C, O, I, T, k, 10, a[61]), T = h(T, C, O, I, d, 15, a[62]), I = h(I, T, C, O, _, 21, a[63]), s[0] = s[0] + O | 0, s[1] = s[1] + I | 0, s[2] = s[2] + T | 0, s[3] = s[3] + C | 0;
      },
      _doFinalize: function _doFinalize() {
        var t = this._data,
            n = t.words,
            r = 8 * this._nDataBytes,
            o = 8 * t.sigBytes;
        n[o >>> 5] |= 128 << 24 - o % 32;
        var s = e.floor(r / 4294967296),
            i = r;
        n[15 + (o + 64 >>> 9 << 4)] = 16711935 & (s << 8 | s >>> 24) | 4278255360 & (s << 24 | s >>> 8), n[14 + (o + 64 >>> 9 << 4)] = 16711935 & (i << 8 | i >>> 24) | 4278255360 & (i << 24 | i >>> 8), t.sigBytes = 4 * (n.length + 1), this._process();

        for (var a = this._hash, c = a.words, u = 0; u < 4; u++) {
          var l = c[u];
          c[u] = 16711935 & (l << 8 | l >>> 24) | 4278255360 & (l << 24 | l >>> 8);
        }

        return a;
      },
      clone: function clone() {
        var e = s.clone.call(this);
        return e._hash = this._hash.clone(), e;
      }
    });

    function u(e, t, n, r, o, s, i) {
      var a = e + (t & n | ~t & r) + o + i;
      return (a << s | a >>> 32 - s) + t;
    }

    function l(e, t, n, r, o, s, i) {
      var a = e + (t & r | n & ~r) + o + i;
      return (a << s | a >>> 32 - s) + t;
    }

    function f(e, t, n, r, o, s, i) {
      var a = e + (t ^ n ^ r) + o + i;
      return (a << s | a >>> 32 - s) + t;
    }

    function h(e, t, n, r, o, s, i) {
      var a = e + (n ^ (t | ~r)) + o + i;
      return (a << s | a >>> 32 - s) + t;
    }

    t.MD5 = s._createHelper(c), t.HmacMD5 = s._createHmacHelper(c);
  }(Math), n.MD5);
}), ka(function (e, t) {
  var n, r, o;
  e.exports = (r = (n = Sa).lib.Base, o = n.enc.Utf8, void (n.algo.HMAC = r.extend({
    init: function init(e, t) {
      e = this._hasher = new e.init(), "string" == typeof t && (t = o.parse(t));
      var n = e.blockSize,
          r = 4 * n;
      t.sigBytes > r && (t = e.finalize(t)), t.clamp();

      for (var s = this._oKey = t.clone(), i = this._iKey = t.clone(), a = s.words, c = i.words, u = 0; u < n; u++) {
        a[u] ^= 1549556828, c[u] ^= 909522486;
      }

      s.sigBytes = i.sigBytes = r, this.reset();
    },
    reset: function reset() {
      var e = this._hasher;
      e.reset(), e.update(this._iKey);
    },
    update: function update(e) {
      return this._hasher.update(e), this;
    },
    finalize: function finalize(e) {
      var t = this._hasher,
          n = t.finalize(e);
      return t.reset(), t.finalize(this._oKey.clone().concat(n));
    }
  })));
}), ka(function (e, t) {
  e.exports = Sa.HmacMD5;
})),
    Aa = ka(function (e, t) {
  e.exports = Sa.enc.Utf8;
}),
    Oa = ka(function (e, t) {
  var n, r, o;
  e.exports = (o = (r = n = Sa).lib.WordArray, r.enc.Base64 = {
    stringify: function stringify(e) {
      var t = e.words,
          n = e.sigBytes,
          r = this._map;
      e.clamp();

      for (var o = [], s = 0; s < n; s += 3) {
        for (var i = (t[s >>> 2] >>> 24 - s % 4 * 8 & 255) << 16 | (t[s + 1 >>> 2] >>> 24 - (s + 1) % 4 * 8 & 255) << 8 | t[s + 2 >>> 2] >>> 24 - (s + 2) % 4 * 8 & 255, a = 0; a < 4 && s + .75 * a < n; a++) {
          o.push(r.charAt(i >>> 6 * (3 - a) & 63));
        }
      }

      var c = r.charAt(64);
      if (c) for (; o.length % 4;) {
        o.push(c);
      }
      return o.join("");
    },
    parse: function parse(e) {
      var t = e.length,
          n = this._map,
          r = this._reverseMap;

      if (!r) {
        r = this._reverseMap = [];

        for (var s = 0; s < n.length; s++) {
          r[n.charCodeAt(s)] = s;
        }
      }

      var i = n.charAt(64);

      if (i) {
        var a = e.indexOf(i);
        -1 !== a && (t = a);
      }

      return function (e, t, n) {
        for (var r = [], s = 0, i = 0; i < t; i++) {
          if (i % 4) {
            var a = n[e.charCodeAt(i - 1)] << i % 4 * 2,
                c = n[e.charCodeAt(i)] >>> 6 - i % 4 * 2;
            r[s >>> 2] |= (a | c) << 24 - s % 4 * 8, s++;
          }
        }

        return o.create(r, s);
      }(e, t, r);
    },
    _map: "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/="
  }, n.enc.Base64);
});var Ia = "FUNCTION",
    Ta = "pending",
    Ca = "rejected";function Ea(e) {
  return Object.prototype.toString.call(e).slice(8, -1).toLowerCase();
}function Ma(e) {
  return "object" === Ea(e);
}function La(e) {
  return "function" == typeof e;
}function $a(e) {
  return function () {
    try {
      return e.apply(e, arguments);
    } catch (t) {
      console.error(t);
    }
  };
}var Ra = "REJECTED",
    Na = "NOT_PENDING";var ja = /*#__PURE__*/function () {
  function ja() {
    var _ref27 = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {},
        e = _ref27.createPromise,
        _ref27$retryRule = _ref27.retryRule,
        t = _ref27$retryRule === void 0 ? Ra : _ref27$retryRule;

    _classCallCheck2(this, ja);

    this.createPromise = e, this.status = null, this.promise = null, this.retryRule = t;
  }

  _createClass2(ja, [{
    key: "needRetry",
    get: function get() {
      if (!this.status) return !0;

      switch (this.retryRule) {
        case Ra:
          return this.status === Ca;

        case Na:
          return this.status !== Ta;
      }
    }
  }, {
    key: "exec",
    value: function exec() {
      var _this4 = this;

      return this.needRetry ? (this.status = Ta, this.promise = this.createPromise().then(function (e) {
        return _this4.status = "fullfilled", Promise.resolve(e);
      }, function (e) {
        return _this4.status = Ca, Promise.reject(e);
      }), this.promise) : this.promise;
    }
  }]);

  return ja;
}();function Da(e) {
  return e && "string" == typeof e ? JSON.parse(e) : e;
}var Ua = Da([]),
    Fa = "mp-weixin";Da("");var qa = Da('[{"provider":"aliyun","spaceName":"prod-p","spaceId":"mp-b0bc782c-0c1f-40c8-b350-19d11f5611aa","clientSecret":"frxjvTGy+oUlY65HtpPH+g==","endpoint":"https://api.next.bspapp.com"}]') || [];var Ba = "";try {
  Ba = "__UNI__BC0D321";
} catch (Mc) {}var Ha = {};function Ka(e) {
  var t = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : {};
  var n, r;
  return n = Ha, r = e, Object.prototype.hasOwnProperty.call(n, r) || (Ha[e] = t), Ha[e];
}var Va = ["invoke", "success", "fail", "complete"],
    Wa = Ka("_globalUniCloudInterceptor");function za(e, t) {
  Wa[e] || (Wa[e] = {}), Ma(t) && Object.keys(t).forEach(function (n) {
    Va.indexOf(n) > -1 && function (e, t, n) {
      var r = Wa[e][t];
      r || (r = Wa[e][t] = []), -1 === r.indexOf(n) && La(n) && r.push(n);
    }(e, n, t[n]);
  });
}function Ja(e, t) {
  Wa[e] || (Wa[e] = {}), Ma(t) ? Object.keys(t).forEach(function (n) {
    Va.indexOf(n) > -1 && function (e, t, n) {
      var r = Wa[e][t];
      if (!r) return;
      var o = r.indexOf(n);
      o > -1 && r.splice(o, 1);
    }(e, n, t[n]);
  }) : delete Wa[e];
}function Ga(e, t) {
  return e && 0 !== e.length ? e.reduce(function (e, n) {
    return e.then(function () {
      return n(t);
    });
  }, Promise.resolve()) : Promise.resolve();
}function Ya(e, t) {
  return Wa[e] && Wa[e][t] || [];
}function Qa(e) {
  za("callObject", e);
}var Xa = Ka("_globalUniCloudListener"),
    Za = "response",
    ec = "needLogin",
    tc = "refreshToken",
    nc = "clientdb",
    rc = "cloudfunction",
    oc = "cloudobject";function sc(e) {
  return Xa[e] || (Xa[e] = []), Xa[e];
}function ic(e, t) {
  var n = sc(e);
  n.includes(t) || n.push(t);
}function ac(e, t) {
  var n = sc(e),
      r = n.indexOf(t);
  -1 !== r && n.splice(r, 1);
}function cc(e, t) {
  var n = sc(e);

  for (var _r30 = 0; _r30 < n.length; _r30++) {
    (0, n[_r30])(t);
  }
}var uc,
    lc = !1;function fc() {
  return uc || (uc = new Promise(function (e) {
    lc && e(), function t() {
      if ("function" == typeof getCurrentPages) {
        var _t36 = getCurrentPages();

        _t36 && _t36[0] && (lc = !0, e());
      }

      lc || setTimeout(function () {
        t();
      }, 30);
    }();
  }), uc);
}function hc(e) {
  var t = {};

  for (var _n34 in e) {
    var _r31 = e[_n34];
    La(_r31) && (t[_n34] = $a(_r31));
  }

  return t;
}var dc = /*#__PURE__*/function (_Error) {
  _inherits2(dc, _Error);

  var _super = _createSuper2(dc);

  function dc(e) {
    var _this5;

    _classCallCheck2(this, dc);

    _this5 = _super.call(this, e.message), _this5.errMsg = e.message || e.errMsg || "unknown system error", _this5.code = _this5.errCode = e.code || e.errCode || "SYSTEM_ERROR", _this5.errSubject = _this5.subject = e.subject || e.errSubject, _this5.cause = e.cause, _this5.requestId = e.requestId;
    return _this5;
  }

  _createClass2(dc, [{
    key: "toJson",
    value: function toJson() {
      var e = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : 0;
      if (!(e >= 10)) return e++, {
        errCode: this.errCode,
        errMsg: this.errMsg,
        errSubject: this.errSubject,
        cause: this.cause && this.cause.toJson ? this.cause.toJson(e) : this.cause
      };
    }
  }]);

  return dc;
}( /*#__PURE__*/_wrapNativeSuper2(Error));var pc = {
  request: function request(e) {
    return On.request(e);
  },
  uploadFile: function uploadFile(e) {
    return On.uploadFile(e);
  },
  setStorageSync: function setStorageSync(e, t) {
    return On.setStorageSync(e, t);
  },
  getStorageSync: function getStorageSync(e) {
    return On.getStorageSync(e);
  },
  removeStorageSync: function removeStorageSync(e) {
    return On.removeStorageSync(e);
  },
  clearStorageSync: function clearStorageSync() {
    return On.clearStorageSync();
  }
};function gc(e) {
  return e && gc(e.__v_raw) || e;
}function mc() {
  return {
    token: pc.getStorageSync("uni_id_token") || pc.getStorageSync("uniIdToken"),
    tokenExpired: pc.getStorageSync("uni_id_token_expired")
  };
}function yc() {
  var _ref28 = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {},
      e = _ref28.token,
      t = _ref28.tokenExpired;

  e && pc.setStorageSync("uni_id_token", e), t && pc.setStorageSync("uni_id_token_expired", t);
}var vc, bc;function _c() {
  return vc || (vc = On.getSystemInfoSync()), vc;
}function wc() {
  var e, t;

  try {
    if (On.getLaunchOptionsSync) {
      if (On.getLaunchOptionsSync.toString().indexOf("not yet implemented") > -1) return;

      var _On$getLaunchOptionsS = On.getLaunchOptionsSync(),
          _n35 = _On$getLaunchOptionsS.scene,
          _r32 = _On$getLaunchOptionsS.channel;

      e = _r32, t = _n35;
    }
  } catch (n) {}

  return {
    channel: e,
    scene: t
  };
}function kc() {
  var e = On.getLocale && On.getLocale() || "en";
  if (bc) return _objectSpread2(_objectSpread2({}, bc), {}, {
    locale: e,
    LOCALE: e
  });

  var t = _c(),
      n = t.deviceId,
      r = t.osName,
      o = t.uniPlatform,
      s = t.appId,
      i = ["pixelRatio", "brand", "model", "system", "language", "version", "platform", "host", "SDKVersion", "swanNativeVersion", "app", "AppPlatform", "fontSizeSetting"];

  for (var _a6 = 0; _a6 < i.length; _a6++) {
    delete t[i[_a6]];
  }

  return bc = _objectSpread2(_objectSpread2({
    PLATFORM: o,
    OS: r,
    APPID: s,
    DEVICEID: n
  }, wc()), t), _objectSpread2(_objectSpread2({}, bc), {}, {
    locale: e,
    LOCALE: e
  });
}var xc = function xc(e, t) {
  var n = "";
  return Object.keys(e).sort().forEach(function (t) {
    e[t] && (n = n + "&" + t + "=" + e[t]);
  }), n = n.slice(1), Pa(n, t).toString();
},
    Sc = function Sc(e, t) {
  return new Promise(function (n, r) {
    t(Object.assign(e, {
      complete: function complete(e) {
        e || (e = {});
        var t = e.data && e.data.header && e.data.header["x-serverless-request-id"] || e.header && e.header["request-id"];
        if (!e.statusCode || e.statusCode >= 400) return r(new dc({
          code: "SYS_ERR",
          message: e.errMsg || "request:fail",
          requestId: t
        }));
        var o = e.data;
        if (o.error) return r(new dc({
          code: o.error.code,
          message: o.error.message,
          requestId: t
        }));
        o.result = o.data, o.requestId = t, delete o.data, n(o);
      }
    }));
  });
},
    Pc = function Pc(e) {
  return Oa.stringify(Aa.parse(e));
},
    Ac = {
  "uniCloud.init.paramRequired": "{param} required",
  "uniCloud.uploadFile.fileError": "filePath should be instance of File"
};var _qe = qe({
  "zh-Hans": {
    "uniCloud.init.paramRequired": "缺少参数：{param}",
    "uniCloud.uploadFile.fileError": "filePath应为File对象"
  },
  "zh-Hant": {
    "uniCloud.init.paramRequired": "缺少参数：{param}",
    "uniCloud.uploadFile.fileError": "filePath应为File对象"
  },
  en: Ac,
  fr: {
    "uniCloud.init.paramRequired": "{param} required",
    "uniCloud.uploadFile.fileError": "filePath should be instance of File"
  },
  es: {
    "uniCloud.init.paramRequired": "{param} required",
    "uniCloud.uploadFile.fileError": "filePath should be instance of File"
  },
  ja: Ac
}, "zh-Hans"),
    Oc = _qe.t;var Ic = /*#__PURE__*/function () {
  function Ic(e) {
    var _this6 = this;

    _classCallCheck2(this, Ic);

    ["spaceId", "clientSecret"].forEach(function (t) {
      if (!Object.prototype.hasOwnProperty.call(e, t)) throw new Error(Oc("uniCloud.init.paramRequired", {
        param: t
      }));
    }), this.config = Object.assign({}, {
      endpoint: 0 === e.spaceId.indexOf("mp-") ? "https://api.next.bspapp.com" : "https://api.bspapp.com"
    }, e), this.config.provider = "aliyun", this.config.requestUrl = this.config.endpoint + "/client", this.config.envType = this.config.envType || "public", this.config.accessTokenKey = "access_token_" + this.config.spaceId, this.adapter = pc, this._getAccessTokenPromiseHub = new ja({
      createPromise: function createPromise() {
        return _this6.requestAuth(_this6.setupRequest({
          method: "serverless.auth.user.anonymousAuthorize",
          params: "{}"
        }, "auth")).then(function (e) {
          if (!e.result || !e.result.accessToken) throw new dc({
            code: "AUTH_FAILED",
            message: "获取accessToken失败"
          });

          _this6.setAccessToken(e.result.accessToken);
        });
      },
      retryRule: Na
    });
  }

  _createClass2(Ic, [{
    key: "hasAccessToken",
    get: function get() {
      return !!this.accessToken;
    }
  }, {
    key: "setAccessToken",
    value: function setAccessToken(e) {
      this.accessToken = e;
    }
  }, {
    key: "requestWrapped",
    value: function requestWrapped(e) {
      return Sc(e, this.adapter.request);
    }
  }, {
    key: "requestAuth",
    value: function requestAuth(e) {
      return this.requestWrapped(e);
    }
  }, {
    key: "request",
    value: function request(e, t) {
      var _this7 = this;

      return Promise.resolve().then(function () {
        return _this7.hasAccessToken ? t ? _this7.requestWrapped(e) : _this7.requestWrapped(e).catch(function (t) {
          return new Promise(function (e, n) {
            !t || "GATEWAY_INVALID_TOKEN" !== t.code && "InvalidParameter.InvalidToken" !== t.code ? n(t) : e();
          }).then(function () {
            return _this7.getAccessToken();
          }).then(function () {
            var t = _this7.rebuildRequest(e);

            return _this7.request(t, !0);
          });
        }) : _this7.getAccessToken().then(function () {
          var t = _this7.rebuildRequest(e);

          return _this7.request(t, !0);
        });
      });
    }
  }, {
    key: "rebuildRequest",
    value: function rebuildRequest(e) {
      var t = Object.assign({}, e);
      return t.data.token = this.accessToken, t.header["x-basement-token"] = this.accessToken, t.header["x-serverless-sign"] = xc(t.data, this.config.clientSecret), t;
    }
  }, {
    key: "setupRequest",
    value: function setupRequest(e, t) {
      var n = Object.assign({}, e, {
        spaceId: this.config.spaceId,
        timestamp: Date.now()
      }),
          r = {
        "Content-Type": "application/json"
      };
      return "auth" !== t && (n.token = this.accessToken, r["x-basement-token"] = this.accessToken), r["x-serverless-sign"] = xc(n, this.config.clientSecret), {
        url: this.config.requestUrl,
        method: "POST",
        data: n,
        dataType: "json",
        header: r
      };
    }
  }, {
    key: "getAccessToken",
    value: function getAccessToken() {
      return this._getAccessTokenPromiseHub.exec();
    }
  }, {
    key: "authorize",
    value: function () {
      var _authorize = _asyncToGenerator2( /*#__PURE__*/_regenerator.default.mark(function _callee() {
        return _regenerator.default.wrap(function _callee$(_context) {
          while (1) {
            switch (_context.prev = _context.next) {
              case 0:
                _context.next = 2;
                return this.getAccessToken();

              case 2:
              case "end":
                return _context.stop();
            }
          }
        }, _callee, this);
      }));

      function authorize() {
        return _authorize.apply(this, arguments);
      }

      return authorize;
    }()
  }, {
    key: "callFunction",
    value: function callFunction(e) {
      var t = {
        method: "serverless.function.runtime.invoke",
        params: JSON.stringify({
          functionTarget: e.name,
          functionArgs: e.data || {}
        })
      };
      return this.request(this.setupRequest(t));
    }
  }, {
    key: "getOSSUploadOptionsFromPath",
    value: function getOSSUploadOptionsFromPath(e) {
      var t = {
        method: "serverless.file.resource.generateProximalSign",
        params: JSON.stringify(e)
      };
      return this.request(this.setupRequest(t));
    }
  }, {
    key: "uploadFileToOSS",
    value: function uploadFileToOSS(_ref29) {
      var _this8 = this;

      var e = _ref29.url,
          t = _ref29.formData,
          n = _ref29.name,
          r = _ref29.filePath,
          o = _ref29.fileType,
          s = _ref29.onUploadProgress;
      return new Promise(function (i, a) {
        var c = _this8.adapter.uploadFile({
          url: e,
          formData: t,
          name: n,
          filePath: r,
          fileType: o,
          header: {
            "X-OSS-server-side-encrpytion": "AES256"
          },
          success: function success(e) {
            e && e.statusCode < 400 ? i(e) : a(new dc({
              code: "UPLOAD_FAILED",
              message: "文件上传失败"
            }));
          },
          fail: function fail(e) {
            a(new dc({
              code: e.code || "UPLOAD_FAILED",
              message: e.message || e.errMsg || "文件上传失败"
            }));
          }
        });

        "function" == typeof s && c && "function" == typeof c.onProgressUpdate && c.onProgressUpdate(function (e) {
          s({
            loaded: e.totalBytesSent,
            total: e.totalBytesExpectedToSend
          });
        });
      });
    }
  }, {
    key: "reportOSSUpload",
    value: function reportOSSUpload(e) {
      var t = {
        method: "serverless.file.resource.report",
        params: JSON.stringify(e)
      };
      return this.request(this.setupRequest(t));
    }
  }, {
    key: "uploadFile",
    value: function () {
      var _uploadFile = _asyncToGenerator2( /*#__PURE__*/_regenerator.default.mark(function _callee2(_ref30) {
        var e, t, _ref30$fileType, n, r, o, s, i, a, c, u, l, f, h, d, p, g, m, _e37, y;

        return _regenerator.default.wrap(function _callee2$(_context2) {
          while (1) {
            switch (_context2.prev = _context2.next) {
              case 0:
                e = _ref30.filePath, t = _ref30.cloudPath, _ref30$fileType = _ref30.fileType, n = _ref30$fileType === void 0 ? "image" : _ref30$fileType, r = _ref30.onUploadProgress, o = _ref30.config;

                if (!("string" !== Ea(t))) {
                  _context2.next = 3;
                  break;
                }

                throw new dc({
                  code: "INVALID_PARAM",
                  message: "cloudPath必须为字符串类型"
                });

              case 3:
                if (t = t.trim()) {
                  _context2.next = 5;
                  break;
                }

                throw new dc({
                  code: "CLOUDPATH_REQUIRED",
                  message: "cloudPath不可为空"
                });

              case 5:
                if (!/:\/\//.test(t)) {
                  _context2.next = 7;
                  break;
                }

                throw new dc({
                  code: "INVALID_PARAM",
                  message: "cloudPath不合法"
                });

              case 7:
                s = o && o.envType || this.config.envType;
                _context2.next = 10;
                return this.getOSSUploadOptionsFromPath({
                  env: s,
                  filename: t
                });

              case 10:
                i = _context2.sent.result;
                a = "https://" + i.cdnDomain + "/" + i.ossPath;
                c = i.securityToken;
                u = i.accessKeyId;
                l = i.signature;
                f = i.host;
                h = i.ossPath;
                d = i.id;
                p = i.policy;
                g = i.ossCallbackUrl;
                m = {
                  "Cache-Control": "max-age=2592000",
                  "Content-Disposition": "attachment",
                  OSSAccessKeyId: u,
                  Signature: l,
                  host: f,
                  id: d,
                  key: h,
                  policy: p,
                  success_action_status: 200
                };

                if (c && (m["x-oss-security-token"] = c), g) {
                  _e37 = JSON.stringify({
                    callbackUrl: g,
                    callbackBody: JSON.stringify({
                      fileId: d,
                      spaceId: this.config.spaceId
                    }),
                    callbackBodyType: "application/json"
                  });
                  m.callback = Pc(_e37);
                }

                y = {
                  url: "https://" + i.host,
                  formData: m,
                  fileName: "file",
                  name: "file",
                  filePath: e,
                  fileType: n
                };
                _context2.next = 25;
                return this.uploadFileToOSS(Object.assign({}, y, {
                  onUploadProgress: r
                }));

              case 25:
                if (!g) {
                  _context2.next = 27;
                  break;
                }

                return _context2.abrupt("return", {
                  success: !0,
                  filePath: e,
                  fileID: a
                });

              case 27:
                _context2.next = 29;
                return this.reportOSSUpload({
                  id: d
                });

              case 29:
                if (!_context2.sent.success) {
                  _context2.next = 31;
                  break;
                }

                return _context2.abrupt("return", {
                  success: !0,
                  filePath: e,
                  fileID: a
                });

              case 31:
                throw new dc({
                  code: "UPLOAD_FAILED",
                  message: "文件上传失败"
                });

              case 32:
              case "end":
                return _context2.stop();
            }
          }
        }, _callee2, this);
      }));

      function uploadFile(_x) {
        return _uploadFile.apply(this, arguments);
      }

      return uploadFile;
    }()
  }, {
    key: "getTempFileURL",
    value: function getTempFileURL() {
      var _ref31 = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {},
          e = _ref31.fileList;

      return new Promise(function (t, n) {
        Array.isArray(e) && 0 !== e.length || n(new dc({
          code: "INVALID_PARAM",
          message: "fileList的元素必须是非空的字符串"
        })), t({
          fileList: e.map(function (e) {
            return {
              fileID: e,
              tempFileURL: e
            };
          })
        });
      });
    }
  }, {
    key: "getFileInfo",
    value: function () {
      var _getFileInfo = _asyncToGenerator2( /*#__PURE__*/_regenerator.default.mark(function _callee3() {
        var _ref32,
            e,
            t,
            _args3 = arguments;

        return _regenerator.default.wrap(function _callee3$(_context3) {
          while (1) {
            switch (_context3.prev = _context3.next) {
              case 0:
                _ref32 = _args3.length > 0 && _args3[0] !== undefined ? _args3[0] : {}, e = _ref32.fileList;

                if (!(!Array.isArray(e) || 0 === e.length)) {
                  _context3.next = 3;
                  break;
                }

                throw new dc({
                  code: "INVALID_PARAM",
                  message: "fileList的元素必须是非空的字符串"
                });

              case 3:
                t = {
                  method: "serverless.file.resource.info",
                  params: JSON.stringify({
                    id: e.map(function (e) {
                      return e.split("?")[0];
                    }).join(",")
                  })
                };
                _context3.next = 6;
                return this.request(this.setupRequest(t));

              case 6:
                _context3.t0 = _context3.sent.result;
                return _context3.abrupt("return", {
                  fileList: _context3.t0
                });

              case 8:
              case "end":
                return _context3.stop();
            }
          }
        }, _callee3, this);
      }));

      function getFileInfo() {
        return _getFileInfo.apply(this, arguments);
      }

      return getFileInfo;
    }()
  }]);

  return Ic;
}(),
    Tc = {
  init: function init(e) {
    var t = new Ic(e),
        n = {
      signInAnonymously: function signInAnonymously() {
        return t.authorize();
      },
      getLoginState: function getLoginState() {
        return Promise.resolve(!1);
      }
    };
    return t.auth = function () {
      return n;
    }, t.customAuth = t.auth, t;
  }
};var Cc = "undefined" != typeof location && "http:" === location.protocol ? "http:" : "https:";var Ec, Mc;(Mc = Ec || (Ec = {})).local = "local", Mc.none = "none", Mc.session = "session";var Lc = function Lc() {};var $c = function $c() {
  var e;

  if (!Promise) {
    e = function e() {}, e.promise = {};

    var _t37 = function _t37() {
      throw new dc({
        message: 'Your Node runtime does support ES6 Promises. Set "global.Promise" to your preferred implementation of promises.'
      });
    };

    return Object.defineProperty(e.promise, "then", {
      get: _t37
    }), Object.defineProperty(e.promise, "catch", {
      get: _t37
    }), e;
  }

  var t = new Promise(function (t, n) {
    e = function e(_e38, r) {
      return _e38 ? n(_e38) : t(r);
    };
  });
  return e.promise = t, e;
};function Rc(e) {
  return void 0 === e;
}function Nc(e) {
  return "[object Null]" === Object.prototype.toString.call(e);
}var jc;!function (e) {
  e.WEB = "web", e.WX_MP = "wx_mp";
}(jc || (jc = {}));var Dc = {
  adapter: null,
  runtime: void 0
},
    Uc = ["anonymousUuidKey"];var Fc = /*#__PURE__*/function (_Lc) {
  _inherits2(Fc, _Lc);

  var _super2 = _createSuper2(Fc);

  function Fc() {
    var _this9;

    _classCallCheck2(this, Fc);

    _this9 = _super2.call(this), Dc.adapter.root.tcbObject || (Dc.adapter.root.tcbObject = {});
    return _this9;
  }

  _createClass2(Fc, [{
    key: "setItem",
    value: function setItem(e, t) {
      Dc.adapter.root.tcbObject[e] = t;
    }
  }, {
    key: "getItem",
    value: function getItem(e) {
      return Dc.adapter.root.tcbObject[e];
    }
  }, {
    key: "removeItem",
    value: function removeItem(e) {
      delete Dc.adapter.root.tcbObject[e];
    }
  }, {
    key: "clear",
    value: function clear() {
      delete Dc.adapter.root.tcbObject;
    }
  }]);

  return Fc;
}(Lc);function qc(e, t) {
  switch (e) {
    case "local":
      return t.localStorage || new Fc();

    case "none":
      return new Fc();

    default:
      return t.sessionStorage || new Fc();
  }
}var Bc = /*#__PURE__*/function () {
  function Bc(e) {
    _classCallCheck2(this, Bc);

    if (!this._storage) {
      this._persistence = Dc.adapter.primaryStorage || e.persistence, this._storage = qc(this._persistence, Dc.adapter);

      var _t38 = "access_token_".concat(e.env),
          _n36 = "access_token_expire_".concat(e.env),
          _r33 = "refresh_token_".concat(e.env),
          _o22 = "anonymous_uuid_".concat(e.env),
          _s15 = "login_type_".concat(e.env),
          _i13 = "user_info_".concat(e.env);

      this.keys = {
        accessTokenKey: _t38,
        accessTokenExpireKey: _n36,
        refreshTokenKey: _r33,
        anonymousUuidKey: _o22,
        loginTypeKey: _s15,
        userInfoKey: _i13
      };
    }
  }

  _createClass2(Bc, [{
    key: "updatePersistence",
    value: function updatePersistence(e) {
      if (e === this._persistence) return;
      var t = "local" === this._persistence;
      this._persistence = e;
      var n = qc(e, Dc.adapter);

      for (var _r34 in this.keys) {
        var _e39 = this.keys[_r34];
        if (t && Uc.includes(_r34)) continue;

        var _o23 = this._storage.getItem(_e39);

        Rc(_o23) || Nc(_o23) || (n.setItem(_e39, _o23), this._storage.removeItem(_e39));
      }

      this._storage = n;
    }
  }, {
    key: "setStore",
    value: function setStore(e, t, n) {
      if (!this._storage) return;
      var r = {
        version: n || "localCachev1",
        content: t
      },
          o = JSON.stringify(r);

      try {
        this._storage.setItem(e, o);
      } catch (s) {
        throw s;
      }
    }
  }, {
    key: "getStore",
    value: function getStore(e, t) {
      try {
        if (!this._storage) return;
      } catch (r) {
        return "";
      }

      t = t || "localCachev1";

      var n = this._storage.getItem(e);

      return n && n.indexOf(t) >= 0 ? JSON.parse(n).content : "";
    }
  }, {
    key: "removeStore",
    value: function removeStore(e) {
      this._storage.removeItem(e);
    }
  }]);

  return Bc;
}();var Hc = {},
    Kc = {};function Vc(e) {
  return Hc[e];
}var Wc = /*#__PURE__*/_createClass2(function Wc(e, t) {
  _classCallCheck2(this, Wc);

  this.data = t || null, this.name = e;
});var zc = /*#__PURE__*/function (_Wc) {
  _inherits2(zc, _Wc);

  var _super3 = _createSuper2(zc);

  function zc(e, t) {
    var _this10;

    _classCallCheck2(this, zc);

    _this10 = _super3.call(this, "error", {
      error: e,
      data: t
    }), _this10.error = e;
    return _this10;
  }

  return _createClass2(zc);
}(Wc);var Jc = new ( /*#__PURE__*/function () {
  function _class2() {
    _classCallCheck2(this, _class2);

    this._listeners = {};
  }

  _createClass2(_class2, [{
    key: "on",
    value: function on(e, t) {
      return n = e, r = t, (o = this._listeners)[n] = o[n] || [], o[n].push(r), this;
      var n, r, o;
    }
  }, {
    key: "off",
    value: function off(e, t) {
      return function (e, t, n) {
        if (n && n[e]) {
          var _r35 = n[e].indexOf(t);

          -1 !== _r35 && n[e].splice(_r35, 1);
        }
      }(e, t, this._listeners), this;
    }
  }, {
    key: "fire",
    value: function fire(e, t) {
      if (e instanceof zc) return console.error(e.error), this;
      var n = "string" == typeof e ? new Wc(e, t || {}) : e,
          r = n.name;

      if (this._listens(r)) {
        n.target = this;

        var _e40 = this._listeners[r] ? _toConsumableArray2(this._listeners[r]) : [];

        var _iterator4 = _createForOfIteratorHelper2(_e40),
            _step4;

        try {
          for (_iterator4.s(); !(_step4 = _iterator4.n()).done;) {
            var _t39 = _step4.value;

            _t39.call(this, n);
          }
        } catch (err) {
          _iterator4.e(err);
        } finally {
          _iterator4.f();
        }
      }

      return this;
    }
  }, {
    key: "_listens",
    value: function _listens(e) {
      return this._listeners[e] && this._listeners[e].length > 0;
    }
  }]);

  return _class2;
}())();function Gc(e, t) {
  Jc.on(e, t);
}function Yc(e) {
  var t = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : {};
  Jc.fire(e, t);
}function Qc(e, t) {
  Jc.off(e, t);
}var Xc = "loginStateChanged",
    Zc = "loginStateExpire",
    eu = "loginTypeChanged",
    tu = "anonymousConverted",
    nu = "refreshAccessToken";var ru;!function (e) {
  e.ANONYMOUS = "ANONYMOUS", e.WECHAT = "WECHAT", e.WECHAT_PUBLIC = "WECHAT-PUBLIC", e.WECHAT_OPEN = "WECHAT-OPEN", e.CUSTOM = "CUSTOM", e.EMAIL = "EMAIL", e.USERNAME = "USERNAME", e.NULL = "NULL";
}(ru || (ru = {}));var ou = ["auth.getJwt", "auth.logout", "auth.signInWithTicket", "auth.signInAnonymously", "auth.signIn", "auth.fetchAccessTokenWithRefreshToken", "auth.signUpWithEmailAndPassword", "auth.activateEndUserMail", "auth.sendPasswordResetEmail", "auth.resetPasswordWithToken", "auth.isUsernameRegistered"],
    su = {
  "X-SDK-Version": "1.3.5"
};function iu(e, t, n) {
  var r = e[t];

  e[t] = function (t) {
    var o = {},
        s = {};
    n.forEach(function (n) {
      var _n$call = n.call(e, t),
          r = _n$call.data,
          i = _n$call.headers;

      Object.assign(o, r), Object.assign(s, i);
    });
    var i = t.data;
    return i && function () {
      var e;
      if (e = i, "[object FormData]" !== Object.prototype.toString.call(e)) t.data = _objectSpread2(_objectSpread2({}, i), o);else for (var _t40 in o) {
        i.append(_t40, o[_t40]);
      }
    }(), t.headers = _objectSpread2(_objectSpread2({}, t.headers || {}), s), r.call(e, t);
  };
}function au() {
  var e = Math.random().toString(16).slice(2);
  return {
    data: {
      seqId: e
    },
    headers: _objectSpread2(_objectSpread2({}, su), {}, {
      "x-seqid": e
    })
  };
}var cu = /*#__PURE__*/function () {
  function cu() {
    var e = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {};

    _classCallCheck2(this, cu);

    var t;
    this.config = e, this._reqClass = new Dc.adapter.reqClass({
      timeout: this.config.timeout,
      timeoutMsg: "\u8BF7\u6C42\u5728".concat(this.config.timeout / 1e3, "s\u5185\u672A\u5B8C\u6210\uFF0C\u5DF2\u4E2D\u65AD"),
      restrictedMethods: ["post"]
    }), this._cache = Vc(this.config.env), this._localCache = (t = this.config.env, Kc[t]), iu(this._reqClass, "post", [au]), iu(this._reqClass, "upload", [au]), iu(this._reqClass, "download", [au]);
  }

  _createClass2(cu, [{
    key: "post",
    value: function () {
      var _post = _asyncToGenerator2( /*#__PURE__*/_regenerator.default.mark(function _callee4(e) {
        return _regenerator.default.wrap(function _callee4$(_context4) {
          while (1) {
            switch (_context4.prev = _context4.next) {
              case 0:
                _context4.next = 2;
                return this._reqClass.post(e);

              case 2:
                return _context4.abrupt("return", _context4.sent);

              case 3:
              case "end":
                return _context4.stop();
            }
          }
        }, _callee4, this);
      }));

      function post(_x2) {
        return _post.apply(this, arguments);
      }

      return post;
    }()
  }, {
    key: "upload",
    value: function () {
      var _upload = _asyncToGenerator2( /*#__PURE__*/_regenerator.default.mark(function _callee5(e) {
        return _regenerator.default.wrap(function _callee5$(_context5) {
          while (1) {
            switch (_context5.prev = _context5.next) {
              case 0:
                _context5.next = 2;
                return this._reqClass.upload(e);

              case 2:
                return _context5.abrupt("return", _context5.sent);

              case 3:
              case "end":
                return _context5.stop();
            }
          }
        }, _callee5, this);
      }));

      function upload(_x3) {
        return _upload.apply(this, arguments);
      }

      return upload;
    }()
  }, {
    key: "download",
    value: function () {
      var _download = _asyncToGenerator2( /*#__PURE__*/_regenerator.default.mark(function _callee6(e) {
        return _regenerator.default.wrap(function _callee6$(_context6) {
          while (1) {
            switch (_context6.prev = _context6.next) {
              case 0:
                _context6.next = 2;
                return this._reqClass.download(e);

              case 2:
                return _context6.abrupt("return", _context6.sent);

              case 3:
              case "end":
                return _context6.stop();
            }
          }
        }, _callee6, this);
      }));

      function download(_x4) {
        return _download.apply(this, arguments);
      }

      return download;
    }()
  }, {
    key: "refreshAccessToken",
    value: function () {
      var _refreshAccessToken2 = _asyncToGenerator2( /*#__PURE__*/_regenerator.default.mark(function _callee7() {
        var e, t;
        return _regenerator.default.wrap(function _callee7$(_context7) {
          while (1) {
            switch (_context7.prev = _context7.next) {
              case 0:
                this._refreshAccessTokenPromise || (this._refreshAccessTokenPromise = this._refreshAccessToken());
                _context7.prev = 1;
                _context7.next = 4;
                return this._refreshAccessTokenPromise;

              case 4:
                e = _context7.sent;
                _context7.next = 10;
                break;

              case 7:
                _context7.prev = 7;
                _context7.t0 = _context7["catch"](1);
                t = _context7.t0;

              case 10:
                if (!(this._refreshAccessTokenPromise = null, this._shouldRefreshAccessTokenHook = null, t)) {
                  _context7.next = 12;
                  break;
                }

                throw t;

              case 12:
                return _context7.abrupt("return", e);

              case 13:
              case "end":
                return _context7.stop();
            }
          }
        }, _callee7, this, [[1, 7]]);
      }));

      function refreshAccessToken() {
        return _refreshAccessToken2.apply(this, arguments);
      }

      return refreshAccessToken;
    }()
  }, {
    key: "_refreshAccessToken",
    value: function () {
      var _refreshAccessToken3 = _asyncToGenerator2( /*#__PURE__*/_regenerator.default.mark(function _callee8() {
        var _this$_cache$keys, e, t, n, r, o, s, i, a, _e41, _e42, _t41, _r36;

        return _regenerator.default.wrap(function _callee8$(_context8) {
          while (1) {
            switch (_context8.prev = _context8.next) {
              case 0:
                _this$_cache$keys = this._cache.keys, e = _this$_cache$keys.accessTokenKey, t = _this$_cache$keys.accessTokenExpireKey, n = _this$_cache$keys.refreshTokenKey, r = _this$_cache$keys.loginTypeKey, o = _this$_cache$keys.anonymousUuidKey;
                this._cache.removeStore(e), this._cache.removeStore(t);
                s = this._cache.getStore(n);

                if (s) {
                  _context8.next = 5;
                  break;
                }

                throw new dc({
                  message: "未登录CloudBase"
                });

              case 5:
                i = {
                  refresh_token: s
                };
                _context8.next = 8;
                return this.request("auth.fetchAccessTokenWithRefreshToken", i);

              case 8:
                a = _context8.sent;

                if (!a.data.code) {
                  _context8.next = 21;
                  break;
                }

                _e41 = a.data.code;

                if (!("SIGN_PARAM_INVALID" === _e41 || "REFRESH_TOKEN_EXPIRED" === _e41 || "INVALID_REFRESH_TOKEN" === _e41)) {
                  _context8.next = 20;
                  break;
                }

                if (!(this._cache.getStore(r) === ru.ANONYMOUS && "INVALID_REFRESH_TOKEN" === _e41)) {
                  _context8.next = 19;
                  break;
                }

                _e42 = this._cache.getStore(o);
                _t41 = this._cache.getStore(n);
                _context8.next = 17;
                return this.send("auth.signInAnonymously", {
                  anonymous_uuid: _e42,
                  refresh_token: _t41
                });

              case 17:
                _r36 = _context8.sent;
                return _context8.abrupt("return", (this.setRefreshToken(_r36.refresh_token), this._refreshAccessToken()));

              case 19:
                Yc(Zc), this._cache.removeStore(n);

              case 20:
                throw new dc({
                  code: a.data.code,
                  message: "\u5237\u65B0access token\u5931\u8D25\uFF1A".concat(a.data.code)
                });

              case 21:
                if (!a.data.access_token) {
                  _context8.next = 23;
                  break;
                }

                return _context8.abrupt("return", (Yc(nu), this._cache.setStore(e, a.data.access_token), this._cache.setStore(t, a.data.access_token_expire + Date.now()), {
                  accessToken: a.data.access_token,
                  accessTokenExpire: a.data.access_token_expire
                }));

              case 23:
                a.data.refresh_token && (this._cache.removeStore(n), this._cache.setStore(n, a.data.refresh_token), this._refreshAccessToken());

              case 24:
              case "end":
                return _context8.stop();
            }
          }
        }, _callee8, this);
      }));

      function _refreshAccessToken() {
        return _refreshAccessToken3.apply(this, arguments);
      }

      return _refreshAccessToken;
    }()
  }, {
    key: "getAccessToken",
    value: function () {
      var _getAccessToken = _asyncToGenerator2( /*#__PURE__*/_regenerator.default.mark(function _callee9() {
        var _this$_cache$keys2, e, t, n, r, o, s;

        return _regenerator.default.wrap(function _callee9$(_context9) {
          while (1) {
            switch (_context9.prev = _context9.next) {
              case 0:
                _this$_cache$keys2 = this._cache.keys, e = _this$_cache$keys2.accessTokenKey, t = _this$_cache$keys2.accessTokenExpireKey, n = _this$_cache$keys2.refreshTokenKey;

                if (this._cache.getStore(n)) {
                  _context9.next = 3;
                  break;
                }

                throw new dc({
                  message: "refresh token不存在，登录状态异常"
                });

              case 3:
                r = this._cache.getStore(e), o = this._cache.getStore(t), s = !0;
                _context9.t0 = this._shouldRefreshAccessTokenHook;

                if (!_context9.t0) {
                  _context9.next = 9;
                  break;
                }

                _context9.next = 8;
                return this._shouldRefreshAccessTokenHook(r, o);

              case 8:
                _context9.t0 = !_context9.sent;

              case 9:
                _context9.t1 = _context9.t0;

                if (!_context9.t1) {
                  _context9.next = 12;
                  break;
                }

                s = !1;

              case 12:
                return _context9.abrupt("return", (!r || !o || o < Date.now()) && s ? this.refreshAccessToken() : {
                  accessToken: r,
                  accessTokenExpire: o
                });

              case 13:
              case "end":
                return _context9.stop();
            }
          }
        }, _callee9, this);
      }));

      function getAccessToken() {
        return _getAccessToken.apply(this, arguments);
      }

      return getAccessToken;
    }()
  }, {
    key: "request",
    value: function () {
      var _request = _asyncToGenerator2( /*#__PURE__*/_regenerator.default.mark(function _callee10(e, t, n) {
        var r, o, s, _e43, i, _e44, _e45, a, c, u, l, f, h, d, p, g;

        return _regenerator.default.wrap(function _callee10$(_context10) {
          while (1) {
            switch (_context10.prev = _context10.next) {
              case 0:
                r = "x-tcb-trace_".concat(this.config.env);
                o = "application/x-www-form-urlencoded";
                s = _objectSpread2({
                  action: e,
                  env: this.config.env,
                  dataVersion: "2019-08-16"
                }, t);

                if (!(-1 === ou.indexOf(e))) {
                  _context10.next = 10;
                  break;
                }

                _e43 = this._cache.keys.refreshTokenKey;
                _context10.t0 = this._cache.getStore(_e43);

                if (!_context10.t0) {
                  _context10.next = 10;
                  break;
                }

                _context10.next = 9;
                return this.getAccessToken();

              case 9:
                s.access_token = _context10.sent.accessToken;

              case 10:
                if ("storage.uploadFile" === e) {
                  i = new FormData();

                  for (_e44 in i) {
                    i.hasOwnProperty(_e44) && void 0 !== i[_e44] && i.append(_e44, s[_e44]);
                  }

                  o = "multipart/form-data";
                } else {
                  o = "application/json", i = {};

                  for (_e45 in s) {
                    void 0 !== s[_e45] && (i[_e45] = s[_e45]);
                  }
                }

                a = {
                  headers: {
                    "content-type": o
                  }
                };
                n && n.onUploadProgress && (a.onUploadProgress = n.onUploadProgress);
                c = this._localCache.getStore(r);
                c && (a.headers["X-TCB-Trace"] = c);
                u = t.parse, l = t.inQuery, f = t.search;
                h = {
                  env: this.config.env
                };
                u && (h.parse = !0), l && (h = _objectSpread2(_objectSpread2({}, l), h));

                d = function (e, t) {
                  var n = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : {};
                  var r = /\?/.test(t);
                  var o = "";

                  for (var _s16 in n) {
                    "" === o ? !r && (t += "?") : o += "&", o += "".concat(_s16, "=").concat(encodeURIComponent(n[_s16]));
                  }

                  return /^http(s)?\:\/\//.test(t += o) ? t : "".concat(e).concat(t);
                }(Cc, "//tcb-api.tencentcloudapi.com/web", h);

                f && (d += f);
                _context10.next = 22;
                return this.post(_objectSpread2({
                  url: d,
                  data: i
                }, a));

              case 22:
                p = _context10.sent;
                g = p.header && p.header["x-tcb-trace"];

                if (!(g && this._localCache.setStore(r, g), 200 !== Number(p.status) && 200 !== Number(p.statusCode) || !p.data)) {
                  _context10.next = 26;
                  break;
                }

                throw new dc({
                  code: "NETWORK_ERROR",
                  message: "network request error"
                });

              case 26:
                return _context10.abrupt("return", p);

              case 27:
              case "end":
                return _context10.stop();
            }
          }
        }, _callee10, this);
      }));

      function request(_x5, _x6, _x7) {
        return _request.apply(this, arguments);
      }

      return request;
    }()
  }, {
    key: "send",
    value: function () {
      var _send = _asyncToGenerator2( /*#__PURE__*/_regenerator.default.mark(function _callee11(e) {
        var t,
            n,
            _n37,
            _args11 = arguments;

        return _regenerator.default.wrap(function _callee11$(_context11) {
          while (1) {
            switch (_context11.prev = _context11.next) {
              case 0:
                t = _args11.length > 1 && _args11[1] !== undefined ? _args11[1] : {};
                _context11.next = 3;
                return this.request(e, t, {
                  onUploadProgress: t.onUploadProgress
                });

              case 3:
                n = _context11.sent;

                if (!("ACCESS_TOKEN_EXPIRED" === n.data.code && -1 === ou.indexOf(e))) {
                  _context11.next = 13;
                  break;
                }

                _context11.next = 7;
                return this.refreshAccessToken();

              case 7:
                _context11.next = 9;
                return this.request(e, t, {
                  onUploadProgress: t.onUploadProgress
                });

              case 9:
                _n37 = _context11.sent;

                if (!_n37.data.code) {
                  _context11.next = 12;
                  break;
                }

                throw new dc({
                  code: _n37.data.code,
                  message: _n37.data.message
                });

              case 12:
                return _context11.abrupt("return", _n37.data);

              case 13:
                if (!n.data.code) {
                  _context11.next = 15;
                  break;
                }

                throw new dc({
                  code: n.data.code,
                  message: n.data.message
                });

              case 15:
                return _context11.abrupt("return", n.data);

              case 16:
              case "end":
                return _context11.stop();
            }
          }
        }, _callee11, this);
      }));

      function send(_x8) {
        return _send.apply(this, arguments);
      }

      return send;
    }()
  }, {
    key: "setRefreshToken",
    value: function setRefreshToken(e) {
      var _this$_cache$keys3 = this._cache.keys,
          t = _this$_cache$keys3.accessTokenKey,
          n = _this$_cache$keys3.accessTokenExpireKey,
          r = _this$_cache$keys3.refreshTokenKey;
      this._cache.removeStore(t), this._cache.removeStore(n), this._cache.setStore(r, e);
    }
  }]);

  return cu;
}();var uu = {};function lu(e) {
  return uu[e];
}var fu = /*#__PURE__*/function () {
  function fu(e) {
    _classCallCheck2(this, fu);

    this.config = e, this._cache = Vc(e.env), this._request = lu(e.env);
  }

  _createClass2(fu, [{
    key: "setRefreshToken",
    value: function setRefreshToken(e) {
      var _this$_cache$keys4 = this._cache.keys,
          t = _this$_cache$keys4.accessTokenKey,
          n = _this$_cache$keys4.accessTokenExpireKey,
          r = _this$_cache$keys4.refreshTokenKey;
      this._cache.removeStore(t), this._cache.removeStore(n), this._cache.setStore(r, e);
    }
  }, {
    key: "setAccessToken",
    value: function setAccessToken(e, t) {
      var _this$_cache$keys5 = this._cache.keys,
          n = _this$_cache$keys5.accessTokenKey,
          r = _this$_cache$keys5.accessTokenExpireKey;
      this._cache.setStore(n, e), this._cache.setStore(r, t);
    }
  }, {
    key: "refreshUserInfo",
    value: function () {
      var _refreshUserInfo = _asyncToGenerator2( /*#__PURE__*/_regenerator.default.mark(function _callee12() {
        var _yield$this$_request$, e;

        return _regenerator.default.wrap(function _callee12$(_context12) {
          while (1) {
            switch (_context12.prev = _context12.next) {
              case 0:
                _context12.next = 2;
                return this._request.send("auth.getUserInfo", {});

              case 2:
                _yield$this$_request$ = _context12.sent;
                e = _yield$this$_request$.data;
                return _context12.abrupt("return", (this.setLocalUserInfo(e), e));

              case 5:
              case "end":
                return _context12.stop();
            }
          }
        }, _callee12, this);
      }));

      function refreshUserInfo() {
        return _refreshUserInfo.apply(this, arguments);
      }

      return refreshUserInfo;
    }()
  }, {
    key: "setLocalUserInfo",
    value: function setLocalUserInfo(e) {
      var t = this._cache.keys.userInfoKey;

      this._cache.setStore(t, e);
    }
  }]);

  return fu;
}();var hu = /*#__PURE__*/function () {
  function hu(e) {
    _classCallCheck2(this, hu);

    if (!e) throw new dc({
      code: "PARAM_ERROR",
      message: "envId is not defined"
    });
    this._envId = e, this._cache = Vc(this._envId), this._request = lu(this._envId), this.setUserInfo();
  }

  _createClass2(hu, [{
    key: "linkWithTicket",
    value: function linkWithTicket(e) {
      if ("string" != typeof e) throw new dc({
        code: "PARAM_ERROR",
        message: "ticket must be string"
      });
      return this._request.send("auth.linkWithTicket", {
        ticket: e
      });
    }
  }, {
    key: "linkWithRedirect",
    value: function linkWithRedirect(e) {
      e.signInWithRedirect();
    }
  }, {
    key: "updatePassword",
    value: function updatePassword(e, t) {
      return this._request.send("auth.updatePassword", {
        oldPassword: t,
        newPassword: e
      });
    }
  }, {
    key: "updateEmail",
    value: function updateEmail(e) {
      return this._request.send("auth.updateEmail", {
        newEmail: e
      });
    }
  }, {
    key: "updateUsername",
    value: function updateUsername(e) {
      if ("string" != typeof e) throw new dc({
        code: "PARAM_ERROR",
        message: "username must be a string"
      });
      return this._request.send("auth.updateUsername", {
        username: e
      });
    }
  }, {
    key: "getLinkedUidList",
    value: function () {
      var _getLinkedUidList = _asyncToGenerator2( /*#__PURE__*/_regenerator.default.mark(function _callee13() {
        var _yield$this$_request$2, e, t, n;

        return _regenerator.default.wrap(function _callee13$(_context13) {
          while (1) {
            switch (_context13.prev = _context13.next) {
              case 0:
                _context13.next = 2;
                return this._request.send("auth.getLinkedUidList", {});

              case 2:
                _yield$this$_request$2 = _context13.sent;
                e = _yield$this$_request$2.data;
                t = !1;
                n = e.users;
                return _context13.abrupt("return", (n.forEach(function (e) {
                  e.wxOpenId && e.wxPublicId && (t = !0);
                }), {
                  users: n,
                  hasPrimaryUid: t
                }));

              case 7:
              case "end":
                return _context13.stop();
            }
          }
        }, _callee13, this);
      }));

      function getLinkedUidList() {
        return _getLinkedUidList.apply(this, arguments);
      }

      return getLinkedUidList;
    }()
  }, {
    key: "setPrimaryUid",
    value: function setPrimaryUid(e) {
      return this._request.send("auth.setPrimaryUid", {
        uid: e
      });
    }
  }, {
    key: "unlink",
    value: function unlink(e) {
      return this._request.send("auth.unlink", {
        platform: e
      });
    }
  }, {
    key: "update",
    value: function () {
      var _update = _asyncToGenerator2( /*#__PURE__*/_regenerator.default.mark(function _callee14(e) {
        var t, n, r, o, s, i, _yield$this$_request$3, a;

        return _regenerator.default.wrap(function _callee14$(_context14) {
          while (1) {
            switch (_context14.prev = _context14.next) {
              case 0:
                t = e.nickName;
                n = e.gender;
                r = e.avatarUrl;
                o = e.province;
                s = e.country;
                i = e.city;
                _context14.next = 8;
                return this._request.send("auth.updateUserInfo", {
                  nickName: t,
                  gender: n,
                  avatarUrl: r,
                  province: o,
                  country: s,
                  city: i
                });

              case 8:
                _yield$this$_request$3 = _context14.sent;
                a = _yield$this$_request$3.data;
                this.setLocalUserInfo(a);

              case 11:
              case "end":
                return _context14.stop();
            }
          }
        }, _callee14, this);
      }));

      function update(_x9) {
        return _update.apply(this, arguments);
      }

      return update;
    }()
  }, {
    key: "refresh",
    value: function () {
      var _refresh = _asyncToGenerator2( /*#__PURE__*/_regenerator.default.mark(function _callee15() {
        var _yield$this$_request$4, e;

        return _regenerator.default.wrap(function _callee15$(_context15) {
          while (1) {
            switch (_context15.prev = _context15.next) {
              case 0:
                _context15.next = 2;
                return this._request.send("auth.getUserInfo", {});

              case 2:
                _yield$this$_request$4 = _context15.sent;
                e = _yield$this$_request$4.data;
                return _context15.abrupt("return", (this.setLocalUserInfo(e), e));

              case 5:
              case "end":
                return _context15.stop();
            }
          }
        }, _callee15, this);
      }));

      function refresh() {
        return _refresh.apply(this, arguments);
      }

      return refresh;
    }()
  }, {
    key: "setUserInfo",
    value: function setUserInfo() {
      var _this11 = this;

      var e = this._cache.keys.userInfoKey,
          t = this._cache.getStore(e);

      ["uid", "loginType", "openid", "wxOpenId", "wxPublicId", "unionId", "qqMiniOpenId", "email", "hasPassword", "customUserId", "nickName", "gender", "avatarUrl"].forEach(function (e) {
        _this11[e] = t[e];
      }), this.location = {
        country: t.country,
        province: t.province,
        city: t.city
      };
    }
  }, {
    key: "setLocalUserInfo",
    value: function setLocalUserInfo(e) {
      var t = this._cache.keys.userInfoKey;
      this._cache.setStore(t, e), this.setUserInfo();
    }
  }]);

  return hu;
}();var du = /*#__PURE__*/function () {
  function du(e) {
    _classCallCheck2(this, du);

    if (!e) throw new dc({
      code: "PARAM_ERROR",
      message: "envId is not defined"
    });
    this._cache = Vc(e);

    var _this$_cache$keys6 = this._cache.keys,
        t = _this$_cache$keys6.refreshTokenKey,
        n = _this$_cache$keys6.accessTokenKey,
        r = _this$_cache$keys6.accessTokenExpireKey,
        o = this._cache.getStore(t),
        s = this._cache.getStore(n),
        i = this._cache.getStore(r);

    this.credential = {
      refreshToken: o,
      accessToken: s,
      accessTokenExpire: i
    }, this.user = new hu(e);
  }

  _createClass2(du, [{
    key: "isAnonymousAuth",
    get: function get() {
      return this.loginType === ru.ANONYMOUS;
    }
  }, {
    key: "isCustomAuth",
    get: function get() {
      return this.loginType === ru.CUSTOM;
    }
  }, {
    key: "isWeixinAuth",
    get: function get() {
      return this.loginType === ru.WECHAT || this.loginType === ru.WECHAT_OPEN || this.loginType === ru.WECHAT_PUBLIC;
    }
  }, {
    key: "loginType",
    get: function get() {
      return this._cache.getStore(this._cache.keys.loginTypeKey);
    }
  }]);

  return du;
}();var pu = /*#__PURE__*/function (_fu) {
  _inherits2(pu, _fu);

  var _super4 = _createSuper2(pu);

  function pu() {
    _classCallCheck2(this, pu);

    return _super4.apply(this, arguments);
  }

  _createClass2(pu, [{
    key: "signIn",
    value: function () {
      var _signIn = _asyncToGenerator2( /*#__PURE__*/_regenerator.default.mark(function _callee16() {
        var _this$_cache$keys7, e, t, n, r, o, _e46;

        return _regenerator.default.wrap(function _callee16$(_context16) {
          while (1) {
            switch (_context16.prev = _context16.next) {
              case 0:
                this._cache.updatePersistence("local");

                _this$_cache$keys7 = this._cache.keys;
                e = _this$_cache$keys7.anonymousUuidKey;
                t = _this$_cache$keys7.refreshTokenKey;
                n = this._cache.getStore(e) || void 0;
                r = this._cache.getStore(t) || void 0;
                _context16.next = 8;
                return this._request.send("auth.signInAnonymously", {
                  anonymous_uuid: n,
                  refresh_token: r
                });

              case 8:
                o = _context16.sent;

                if (!(o.uuid && o.refresh_token)) {
                  _context16.next = 20;
                  break;
                }

                this._setAnonymousUUID(o.uuid);

                this.setRefreshToken(o.refresh_token);
                _context16.next = 14;
                return this._request.refreshAccessToken();

              case 14:
                Yc(Xc);
                Yc(eu, {
                  env: this.config.env,
                  loginType: ru.ANONYMOUS,
                  persistence: "local"
                });
                _e46 = new du(this.config.env);
                _context16.next = 19;
                return _e46.user.refresh();

              case 19:
                return _context16.abrupt("return", _e46);

              case 20:
                throw new dc({
                  message: "匿名登录失败"
                });

              case 21:
              case "end":
                return _context16.stop();
            }
          }
        }, _callee16, this);
      }));

      function signIn() {
        return _signIn.apply(this, arguments);
      }

      return signIn;
    }()
  }, {
    key: "linkAndRetrieveDataWithTicket",
    value: function () {
      var _linkAndRetrieveDataWithTicket = _asyncToGenerator2( /*#__PURE__*/_regenerator.default.mark(function _callee17(e) {
        var _this$_cache$keys8, t, n, r, o, s;

        return _regenerator.default.wrap(function _callee17$(_context17) {
          while (1) {
            switch (_context17.prev = _context17.next) {
              case 0:
                _this$_cache$keys8 = this._cache.keys;
                t = _this$_cache$keys8.anonymousUuidKey;
                n = _this$_cache$keys8.refreshTokenKey;
                r = this._cache.getStore(t);
                o = this._cache.getStore(n);
                _context17.next = 7;
                return this._request.send("auth.linkAndRetrieveDataWithTicket", {
                  anonymous_uuid: r,
                  refresh_token: o,
                  ticket: e
                });

              case 7:
                s = _context17.sent;

                if (!s.refresh_token) {
                  _context17.next = 16;
                  break;
                }

                this._clearAnonymousUUID();

                this.setRefreshToken(s.refresh_token);
                _context17.next = 13;
                return this._request.refreshAccessToken();

              case 13:
                Yc(tu, {
                  env: this.config.env
                });
                Yc(eu, {
                  loginType: ru.CUSTOM,
                  persistence: "local"
                });
                return _context17.abrupt("return", {
                  credential: {
                    refreshToken: s.refresh_token
                  }
                });

              case 16:
                throw new dc({
                  message: "匿名转化失败"
                });

              case 17:
              case "end":
                return _context17.stop();
            }
          }
        }, _callee17, this);
      }));

      function linkAndRetrieveDataWithTicket(_x10) {
        return _linkAndRetrieveDataWithTicket.apply(this, arguments);
      }

      return linkAndRetrieveDataWithTicket;
    }()
  }, {
    key: "_setAnonymousUUID",
    value: function _setAnonymousUUID(e) {
      var _this$_cache$keys9 = this._cache.keys,
          t = _this$_cache$keys9.anonymousUuidKey,
          n = _this$_cache$keys9.loginTypeKey;
      this._cache.removeStore(t), this._cache.setStore(t, e), this._cache.setStore(n, ru.ANONYMOUS);
    }
  }, {
    key: "_clearAnonymousUUID",
    value: function _clearAnonymousUUID() {
      this._cache.removeStore(this._cache.keys.anonymousUuidKey);
    }
  }]);

  return pu;
}(fu);var gu = /*#__PURE__*/function (_fu2) {
  _inherits2(gu, _fu2);

  var _super5 = _createSuper2(gu);

  function gu() {
    _classCallCheck2(this, gu);

    return _super5.apply(this, arguments);
  }

  _createClass2(gu, [{
    key: "signIn",
    value: function () {
      var _signIn2 = _asyncToGenerator2( /*#__PURE__*/_regenerator.default.mark(function _callee18(e) {
        var t, n;
        return _regenerator.default.wrap(function _callee18$(_context18) {
          while (1) {
            switch (_context18.prev = _context18.next) {
              case 0:
                if (!("string" != typeof e)) {
                  _context18.next = 2;
                  break;
                }

                throw new dc({
                  code: "PARAM_ERROR",
                  message: "ticket must be a string"
                });

              case 2:
                t = this._cache.keys.refreshTokenKey;
                _context18.next = 5;
                return this._request.send("auth.signInWithTicket", {
                  ticket: e,
                  refresh_token: this._cache.getStore(t) || ""
                });

              case 5:
                n = _context18.sent;

                if (!n.refresh_token) {
                  _context18.next = 15;
                  break;
                }

                this.setRefreshToken(n.refresh_token);
                _context18.next = 10;
                return this._request.refreshAccessToken();

              case 10:
                Yc(Xc);
                Yc(eu, {
                  env: this.config.env,
                  loginType: ru.CUSTOM,
                  persistence: this.config.persistence
                });
                _context18.next = 14;
                return this.refreshUserInfo();

              case 14:
                return _context18.abrupt("return", new du(this.config.env));

              case 15:
                throw new dc({
                  message: "自定义登录失败"
                });

              case 16:
              case "end":
                return _context18.stop();
            }
          }
        }, _callee18, this);
      }));

      function signIn(_x11) {
        return _signIn2.apply(this, arguments);
      }

      return signIn;
    }()
  }]);

  return gu;
}(fu);var mu = /*#__PURE__*/function (_fu3) {
  _inherits2(mu, _fu3);

  var _super6 = _createSuper2(mu);

  function mu() {
    _classCallCheck2(this, mu);

    return _super6.apply(this, arguments);
  }

  _createClass2(mu, [{
    key: "signIn",
    value: function () {
      var _signIn3 = _asyncToGenerator2( /*#__PURE__*/_regenerator.default.mark(function _callee19(e, t) {
        var n, r, o, s, i;
        return _regenerator.default.wrap(function _callee19$(_context19) {
          while (1) {
            switch (_context19.prev = _context19.next) {
              case 0:
                if (!("string" != typeof e)) {
                  _context19.next = 2;
                  break;
                }

                throw new dc({
                  code: "PARAM_ERROR",
                  message: "email must be a string"
                });

              case 2:
                n = this._cache.keys.refreshTokenKey;
                _context19.next = 5;
                return this._request.send("auth.signIn", {
                  loginType: "EMAIL",
                  email: e,
                  password: t,
                  refresh_token: this._cache.getStore(n) || ""
                });

              case 5:
                r = _context19.sent;
                o = r.refresh_token;
                s = r.access_token;
                i = r.access_token_expire;

                if (!o) {
                  _context19.next = 22;
                  break;
                }

                this.setRefreshToken(o);

                if (!(s && i)) {
                  _context19.next = 15;
                  break;
                }

                this.setAccessToken(s, i);
                _context19.next = 17;
                break;

              case 15:
                _context19.next = 17;
                return this._request.refreshAccessToken();

              case 17:
                _context19.next = 19;
                return this.refreshUserInfo();

              case 19:
                Yc(Xc);
                Yc(eu, {
                  env: this.config.env,
                  loginType: ru.EMAIL,
                  persistence: this.config.persistence
                });
                return _context19.abrupt("return", new du(this.config.env));

              case 22:
                throw r.code ? new dc({
                  code: r.code,
                  message: "\u90AE\u7BB1\u767B\u5F55\u5931\u8D25: ".concat(r.message)
                }) : new dc({
                  message: "邮箱登录失败"
                });

              case 23:
              case "end":
                return _context19.stop();
            }
          }
        }, _callee19, this);
      }));

      function signIn(_x12, _x13) {
        return _signIn3.apply(this, arguments);
      }

      return signIn;
    }()
  }, {
    key: "activate",
    value: function () {
      var _activate = _asyncToGenerator2( /*#__PURE__*/_regenerator.default.mark(function _callee20(e) {
        return _regenerator.default.wrap(function _callee20$(_context20) {
          while (1) {
            switch (_context20.prev = _context20.next) {
              case 0:
                return _context20.abrupt("return", this._request.send("auth.activateEndUserMail", {
                  token: e
                }));

              case 1:
              case "end":
                return _context20.stop();
            }
          }
        }, _callee20, this);
      }));

      function activate(_x14) {
        return _activate.apply(this, arguments);
      }

      return activate;
    }()
  }, {
    key: "resetPasswordWithToken",
    value: function () {
      var _resetPasswordWithToken = _asyncToGenerator2( /*#__PURE__*/_regenerator.default.mark(function _callee21(e, t) {
        return _regenerator.default.wrap(function _callee21$(_context21) {
          while (1) {
            switch (_context21.prev = _context21.next) {
              case 0:
                return _context21.abrupt("return", this._request.send("auth.resetPasswordWithToken", {
                  token: e,
                  newPassword: t
                }));

              case 1:
              case "end":
                return _context21.stop();
            }
          }
        }, _callee21, this);
      }));

      function resetPasswordWithToken(_x15, _x16) {
        return _resetPasswordWithToken.apply(this, arguments);
      }

      return resetPasswordWithToken;
    }()
  }]);

  return mu;
}(fu);var yu = /*#__PURE__*/function (_fu4) {
  _inherits2(yu, _fu4);

  var _super7 = _createSuper2(yu);

  function yu() {
    _classCallCheck2(this, yu);

    return _super7.apply(this, arguments);
  }

  _createClass2(yu, [{
    key: "signIn",
    value: function () {
      var _signIn4 = _asyncToGenerator2( /*#__PURE__*/_regenerator.default.mark(function _callee22(e, t) {
        var n, r, o, s, i;
        return _regenerator.default.wrap(function _callee22$(_context22) {
          while (1) {
            switch (_context22.prev = _context22.next) {
              case 0:
                if (!("string" != typeof e)) {
                  _context22.next = 2;
                  break;
                }

                throw new dc({
                  code: "PARAM_ERROR",
                  message: "username must be a string"
                });

              case 2:
                "string" != typeof t && (t = "", console.warn("password is empty"));
                n = this._cache.keys.refreshTokenKey;
                _context22.next = 6;
                return this._request.send("auth.signIn", {
                  loginType: ru.USERNAME,
                  username: e,
                  password: t,
                  refresh_token: this._cache.getStore(n) || ""
                });

              case 6:
                r = _context22.sent;
                o = r.refresh_token;
                s = r.access_token_expire;
                i = r.access_token;

                if (!o) {
                  _context22.next = 23;
                  break;
                }

                this.setRefreshToken(o);

                if (!(i && s)) {
                  _context22.next = 16;
                  break;
                }

                this.setAccessToken(i, s);
                _context22.next = 18;
                break;

              case 16:
                _context22.next = 18;
                return this._request.refreshAccessToken();

              case 18:
                _context22.next = 20;
                return this.refreshUserInfo();

              case 20:
                Yc(Xc);
                Yc(eu, {
                  env: this.config.env,
                  loginType: ru.USERNAME,
                  persistence: this.config.persistence
                });
                return _context22.abrupt("return", new du(this.config.env));

              case 23:
                throw r.code ? new dc({
                  code: r.code,
                  message: "\u7528\u6237\u540D\u5BC6\u7801\u767B\u5F55\u5931\u8D25: ".concat(r.message)
                }) : new dc({
                  message: "用户名密码登录失败"
                });

              case 24:
              case "end":
                return _context22.stop();
            }
          }
        }, _callee22, this);
      }));

      function signIn(_x17, _x18) {
        return _signIn4.apply(this, arguments);
      }

      return signIn;
    }()
  }]);

  return yu;
}(fu);var vu = /*#__PURE__*/function () {
  function vu(e) {
    _classCallCheck2(this, vu);

    this.config = e, this._cache = Vc(e.env), this._request = lu(e.env), this._onAnonymousConverted = this._onAnonymousConverted.bind(this), this._onLoginTypeChanged = this._onLoginTypeChanged.bind(this), Gc(eu, this._onLoginTypeChanged);
  }

  _createClass2(vu, [{
    key: "currentUser",
    get: function get() {
      var e = this.hasLoginState();
      return e && e.user || null;
    }
  }, {
    key: "loginType",
    get: function get() {
      return this._cache.getStore(this._cache.keys.loginTypeKey);
    }
  }, {
    key: "anonymousAuthProvider",
    value: function anonymousAuthProvider() {
      return new pu(this.config);
    }
  }, {
    key: "customAuthProvider",
    value: function customAuthProvider() {
      return new gu(this.config);
    }
  }, {
    key: "emailAuthProvider",
    value: function emailAuthProvider() {
      return new mu(this.config);
    }
  }, {
    key: "usernameAuthProvider",
    value: function usernameAuthProvider() {
      return new yu(this.config);
    }
  }, {
    key: "signInAnonymously",
    value: function () {
      var _signInAnonymously = _asyncToGenerator2( /*#__PURE__*/_regenerator.default.mark(function _callee23() {
        return _regenerator.default.wrap(function _callee23$(_context23) {
          while (1) {
            switch (_context23.prev = _context23.next) {
              case 0:
                return _context23.abrupt("return", new pu(this.config).signIn());

              case 1:
              case "end":
                return _context23.stop();
            }
          }
        }, _callee23, this);
      }));

      function signInAnonymously() {
        return _signInAnonymously.apply(this, arguments);
      }

      return signInAnonymously;
    }()
  }, {
    key: "signInWithEmailAndPassword",
    value: function () {
      var _signInWithEmailAndPassword = _asyncToGenerator2( /*#__PURE__*/_regenerator.default.mark(function _callee24(e, t) {
        return _regenerator.default.wrap(function _callee24$(_context24) {
          while (1) {
            switch (_context24.prev = _context24.next) {
              case 0:
                return _context24.abrupt("return", new mu(this.config).signIn(e, t));

              case 1:
              case "end":
                return _context24.stop();
            }
          }
        }, _callee24, this);
      }));

      function signInWithEmailAndPassword(_x19, _x20) {
        return _signInWithEmailAndPassword.apply(this, arguments);
      }

      return signInWithEmailAndPassword;
    }()
  }, {
    key: "signInWithUsernameAndPassword",
    value: function signInWithUsernameAndPassword(e, t) {
      return new yu(this.config).signIn(e, t);
    }
  }, {
    key: "linkAndRetrieveDataWithTicket",
    value: function () {
      var _linkAndRetrieveDataWithTicket2 = _asyncToGenerator2( /*#__PURE__*/_regenerator.default.mark(function _callee25(e) {
        return _regenerator.default.wrap(function _callee25$(_context25) {
          while (1) {
            switch (_context25.prev = _context25.next) {
              case 0:
                this._anonymousAuthProvider || (this._anonymousAuthProvider = new pu(this.config));
                Gc(tu, this._onAnonymousConverted);
                _context25.next = 4;
                return this._anonymousAuthProvider.linkAndRetrieveDataWithTicket(e);

              case 4:
                return _context25.abrupt("return", _context25.sent);

              case 5:
              case "end":
                return _context25.stop();
            }
          }
        }, _callee25, this);
      }));

      function linkAndRetrieveDataWithTicket(_x21) {
        return _linkAndRetrieveDataWithTicket2.apply(this, arguments);
      }

      return linkAndRetrieveDataWithTicket;
    }()
  }, {
    key: "signOut",
    value: function () {
      var _signOut = _asyncToGenerator2( /*#__PURE__*/_regenerator.default.mark(function _callee26() {
        var _this$_cache$keys10, e, t, n, r, o;

        return _regenerator.default.wrap(function _callee26$(_context26) {
          while (1) {
            switch (_context26.prev = _context26.next) {
              case 0:
                if (!(this.loginType === ru.ANONYMOUS)) {
                  _context26.next = 2;
                  break;
                }

                throw new dc({
                  message: "匿名用户不支持登出操作"
                });

              case 2:
                _this$_cache$keys10 = this._cache.keys, e = _this$_cache$keys10.refreshTokenKey, t = _this$_cache$keys10.accessTokenKey, n = _this$_cache$keys10.accessTokenExpireKey, r = this._cache.getStore(e);

                if (r) {
                  _context26.next = 5;
                  break;
                }

                return _context26.abrupt("return");

              case 5:
                _context26.next = 7;
                return this._request.send("auth.logout", {
                  refresh_token: r
                });

              case 7:
                o = _context26.sent;
                return _context26.abrupt("return", (this._cache.removeStore(e), this._cache.removeStore(t), this._cache.removeStore(n), Yc(Xc), Yc(eu, {
                  env: this.config.env,
                  loginType: ru.NULL,
                  persistence: this.config.persistence
                }), o));

              case 9:
              case "end":
                return _context26.stop();
            }
          }
        }, _callee26, this);
      }));

      function signOut() {
        return _signOut.apply(this, arguments);
      }

      return signOut;
    }()
  }, {
    key: "signUpWithEmailAndPassword",
    value: function () {
      var _signUpWithEmailAndPassword = _asyncToGenerator2( /*#__PURE__*/_regenerator.default.mark(function _callee27(e, t) {
        return _regenerator.default.wrap(function _callee27$(_context27) {
          while (1) {
            switch (_context27.prev = _context27.next) {
              case 0:
                return _context27.abrupt("return", this._request.send("auth.signUpWithEmailAndPassword", {
                  email: e,
                  password: t
                }));

              case 1:
              case "end":
                return _context27.stop();
            }
          }
        }, _callee27, this);
      }));

      function signUpWithEmailAndPassword(_x22, _x23) {
        return _signUpWithEmailAndPassword.apply(this, arguments);
      }

      return signUpWithEmailAndPassword;
    }()
  }, {
    key: "sendPasswordResetEmail",
    value: function () {
      var _sendPasswordResetEmail = _asyncToGenerator2( /*#__PURE__*/_regenerator.default.mark(function _callee28(e) {
        return _regenerator.default.wrap(function _callee28$(_context28) {
          while (1) {
            switch (_context28.prev = _context28.next) {
              case 0:
                return _context28.abrupt("return", this._request.send("auth.sendPasswordResetEmail", {
                  email: e
                }));

              case 1:
              case "end":
                return _context28.stop();
            }
          }
        }, _callee28, this);
      }));

      function sendPasswordResetEmail(_x24) {
        return _sendPasswordResetEmail.apply(this, arguments);
      }

      return sendPasswordResetEmail;
    }()
  }, {
    key: "onLoginStateChanged",
    value: function onLoginStateChanged(e) {
      var _this12 = this;

      Gc(Xc, function () {
        var t = _this12.hasLoginState();

        e.call(_this12, t);
      });
      var t = this.hasLoginState();
      e.call(this, t);
    }
  }, {
    key: "onLoginStateExpired",
    value: function onLoginStateExpired(e) {
      Gc(Zc, e.bind(this));
    }
  }, {
    key: "onAccessTokenRefreshed",
    value: function onAccessTokenRefreshed(e) {
      Gc(nu, e.bind(this));
    }
  }, {
    key: "onAnonymousConverted",
    value: function onAnonymousConverted(e) {
      Gc(tu, e.bind(this));
    }
  }, {
    key: "onLoginTypeChanged",
    value: function onLoginTypeChanged(e) {
      var _this13 = this;

      Gc(eu, function () {
        var t = _this13.hasLoginState();

        e.call(_this13, t);
      });
    }
  }, {
    key: "getAccessToken",
    value: function () {
      var _getAccessToken2 = _asyncToGenerator2( /*#__PURE__*/_regenerator.default.mark(function _callee29() {
        return _regenerator.default.wrap(function _callee29$(_context29) {
          while (1) {
            switch (_context29.prev = _context29.next) {
              case 0:
                _context29.next = 2;
                return this._request.getAccessToken();

              case 2:
                _context29.t0 = _context29.sent.accessToken;
                _context29.t1 = this.config.env;
                return _context29.abrupt("return", {
                  accessToken: _context29.t0,
                  env: _context29.t1
                });

              case 5:
              case "end":
                return _context29.stop();
            }
          }
        }, _callee29, this);
      }));

      function getAccessToken() {
        return _getAccessToken2.apply(this, arguments);
      }

      return getAccessToken;
    }()
  }, {
    key: "hasLoginState",
    value: function hasLoginState() {
      var e = this._cache.keys.refreshTokenKey;
      return this._cache.getStore(e) ? new du(this.config.env) : null;
    }
  }, {
    key: "isUsernameRegistered",
    value: function () {
      var _isUsernameRegistered = _asyncToGenerator2( /*#__PURE__*/_regenerator.default.mark(function _callee30(e) {
        var _yield$this$_request$5, t;

        return _regenerator.default.wrap(function _callee30$(_context30) {
          while (1) {
            switch (_context30.prev = _context30.next) {
              case 0:
                if (!("string" != typeof e)) {
                  _context30.next = 2;
                  break;
                }

                throw new dc({
                  code: "PARAM_ERROR",
                  message: "username must be a string"
                });

              case 2:
                _context30.next = 4;
                return this._request.send("auth.isUsernameRegistered", {
                  username: e
                });

              case 4:
                _yield$this$_request$5 = _context30.sent;
                t = _yield$this$_request$5.data;
                return _context30.abrupt("return", t && t.isRegistered);

              case 7:
              case "end":
                return _context30.stop();
            }
          }
        }, _callee30, this);
      }));

      function isUsernameRegistered(_x25) {
        return _isUsernameRegistered.apply(this, arguments);
      }

      return isUsernameRegistered;
    }()
  }, {
    key: "getLoginState",
    value: function getLoginState() {
      return Promise.resolve(this.hasLoginState());
    }
  }, {
    key: "signInWithTicket",
    value: function () {
      var _signInWithTicket = _asyncToGenerator2( /*#__PURE__*/_regenerator.default.mark(function _callee31(e) {
        return _regenerator.default.wrap(function _callee31$(_context31) {
          while (1) {
            switch (_context31.prev = _context31.next) {
              case 0:
                return _context31.abrupt("return", new gu(this.config).signIn(e));

              case 1:
              case "end":
                return _context31.stop();
            }
          }
        }, _callee31, this);
      }));

      function signInWithTicket(_x26) {
        return _signInWithTicket.apply(this, arguments);
      }

      return signInWithTicket;
    }()
  }, {
    key: "shouldRefreshAccessToken",
    value: function shouldRefreshAccessToken(e) {
      this._request._shouldRefreshAccessTokenHook = e.bind(this);
    }
  }, {
    key: "getUserInfo",
    value: function getUserInfo() {
      return this._request.send("auth.getUserInfo", {}).then(function (e) {
        return e.code ? e : _objectSpread2(_objectSpread2({}, e.data), {}, {
          requestId: e.seqId
        });
      });
    }
  }, {
    key: "getAuthHeader",
    value: function getAuthHeader() {
      var _this$_cache$keys11 = this._cache.keys,
          e = _this$_cache$keys11.refreshTokenKey,
          t = _this$_cache$keys11.accessTokenKey,
          n = this._cache.getStore(e);

      return {
        "x-cloudbase-credentials": this._cache.getStore(t) + "/@@/" + n
      };
    }
  }, {
    key: "_onAnonymousConverted",
    value: function _onAnonymousConverted(e) {
      var t = e.data.env;
      t === this.config.env && this._cache.updatePersistence(this.config.persistence);
    }
  }, {
    key: "_onLoginTypeChanged",
    value: function _onLoginTypeChanged(e) {
      var _e$data = e.data,
          t = _e$data.loginType,
          n = _e$data.persistence,
          r = _e$data.env;
      r === this.config.env && (this._cache.updatePersistence(n), this._cache.setStore(this._cache.keys.loginTypeKey, t));
    }
  }]);

  return vu;
}();var bu = function bu(e, t) {
  t = t || $c();
  var n = lu(this.config.env),
      r = e.cloudPath,
      o = e.filePath,
      s = e.onUploadProgress,
      _e$fileType = e.fileType,
      i = _e$fileType === void 0 ? "image" : _e$fileType;
  return n.send("storage.getUploadMetadata", {
    path: r
  }).then(function (e) {
    var _e$data2 = e.data,
        a = _e$data2.url,
        c = _e$data2.authorization,
        u = _e$data2.token,
        l = _e$data2.fileId,
        f = _e$data2.cosFileId,
        h = e.requestId,
        d = {
      key: r,
      signature: c,
      "x-cos-meta-fileid": f,
      success_action_status: "201",
      "x-cos-security-token": u
    };
    n.upload({
      url: a,
      data: d,
      file: o,
      name: r,
      fileType: i,
      onUploadProgress: s
    }).then(function (e) {
      201 === e.statusCode ? t(null, {
        fileID: l,
        requestId: h
      }) : t(new dc({
        code: "STORAGE_REQUEST_FAIL",
        message: "STORAGE_REQUEST_FAIL: ".concat(e.data)
      }));
    }).catch(function (e) {
      t(e);
    });
  }).catch(function (e) {
    t(e);
  }), t.promise;
},
    _u = function _u(e, t) {
  t = t || $c();
  var n = lu(this.config.env),
      r = e.cloudPath;
  return n.send("storage.getUploadMetadata", {
    path: r
  }).then(function (e) {
    t(null, e);
  }).catch(function (e) {
    t(e);
  }), t.promise;
},
    wu = function wu(_ref33, t) {
  var e = _ref33.fileList;
  if (t = t || $c(), !e || !Array.isArray(e)) return {
    code: "INVALID_PARAM",
    message: "fileList必须是非空的数组"
  };

  var _iterator5 = _createForOfIteratorHelper2(e),
      _step5;

  try {
    for (_iterator5.s(); !(_step5 = _iterator5.n()).done;) {
      var _r37 = _step5.value;
      if (!_r37 || "string" != typeof _r37) return {
        code: "INVALID_PARAM",
        message: "fileList的元素必须是非空的字符串"
      };
    }
  } catch (err) {
    _iterator5.e(err);
  } finally {
    _iterator5.f();
  }

  var n = {
    fileid_list: e
  };
  return lu(this.config.env).send("storage.batchDeleteFile", n).then(function (e) {
    e.code ? t(null, e) : t(null, {
      fileList: e.data.delete_list,
      requestId: e.requestId
    });
  }).catch(function (e) {
    t(e);
  }), t.promise;
},
    ku = function ku(_ref34, t) {
  var e = _ref34.fileList;
  t = t || $c(), e && Array.isArray(e) || t(null, {
    code: "INVALID_PARAM",
    message: "fileList必须是非空的数组"
  });
  var n = [];

  var _iterator6 = _createForOfIteratorHelper2(e),
      _step6;

  try {
    for (_iterator6.s(); !(_step6 = _iterator6.n()).done;) {
      var _o24 = _step6.value;
      "object" == _typeof2(_o24) ? (_o24.hasOwnProperty("fileID") && _o24.hasOwnProperty("maxAge") || t(null, {
        code: "INVALID_PARAM",
        message: "fileList的元素必须是包含fileID和maxAge的对象"
      }), n.push({
        fileid: _o24.fileID,
        max_age: _o24.maxAge
      })) : "string" == typeof _o24 ? n.push({
        fileid: _o24
      }) : t(null, {
        code: "INVALID_PARAM",
        message: "fileList的元素必须是字符串"
      });
    }
  } catch (err) {
    _iterator6.e(err);
  } finally {
    _iterator6.f();
  }

  var r = {
    file_list: n
  };
  return lu(this.config.env).send("storage.batchGetDownloadUrl", r).then(function (e) {
    e.code ? t(null, e) : t(null, {
      fileList: e.data.download_list,
      requestId: e.requestId
    });
  }).catch(function (e) {
    t(e);
  }), t.promise;
},
    xu = /*#__PURE__*/function () {
  var _ref36 = _asyncToGenerator2( /*#__PURE__*/_regenerator.default.mark(function _callee32(_ref35, t) {
    var e, n, r, o;
    return _regenerator.default.wrap(function _callee32$(_context32) {
      while (1) {
        switch (_context32.prev = _context32.next) {
          case 0:
            e = _ref35.fileID;
            _context32.next = 3;
            return ku.call(this, {
              fileList: [{
                fileID: e,
                maxAge: 600
              }]
            });

          case 3:
            n = _context32.sent.fileList[0];

            if (!("SUCCESS" !== n.code)) {
              _context32.next = 6;
              break;
            }

            return _context32.abrupt("return", t ? t(n) : new Promise(function (e) {
              e(n);
            }));

          case 6:
            r = lu(this.config.env);
            o = n.download_url;

            if (!(o = encodeURI(o), !t)) {
              _context32.next = 10;
              break;
            }

            return _context32.abrupt("return", r.download({
              url: o
            }));

          case 10:
            _context32.t0 = t;
            _context32.next = 13;
            return r.download({
              url: o
            });

          case 13:
            _context32.t1 = _context32.sent;
            (0, _context32.t0)(_context32.t1);

          case 15:
          case "end":
            return _context32.stop();
        }
      }
    }, _callee32, this);
  }));

  return function xu(_x27, _x28) {
    return _ref36.apply(this, arguments);
  };
}(),
    Su = function Su(_ref37, s) {
  var e = _ref37.name,
      t = _ref37.data,
      n = _ref37.query,
      r = _ref37.parse,
      o = _ref37.search;
  var i = s || $c();
  var a;

  try {
    a = t ? JSON.stringify(t) : "";
  } catch (u) {
    return Promise.reject(u);
  }

  if (!e) return Promise.reject(new dc({
    code: "PARAM_ERROR",
    message: "函数名不能为空"
  }));
  var c = {
    inQuery: n,
    parse: r,
    search: o,
    function_name: e,
    request_data: a
  };
  return lu(this.config.env).send("functions.invokeFunction", c).then(function (e) {
    if (e.code) i(null, e);else {
      var _n38 = e.data.response_data;
      if (r) i(null, {
        result: _n38,
        requestId: e.requestId
      });else try {
        _n38 = JSON.parse(e.data.response_data), i(null, {
          result: _n38,
          requestId: e.requestId
        });
      } catch (t) {
        i(new dc({
          message: "response data must be json"
        }));
      }
    }
    return i.promise;
  }).catch(function (e) {
    i(e);
  }), i.promise;
},
    Pu = {
  timeout: 15e3,
  persistence: "session"
},
    Au = {};var Ou = /*#__PURE__*/function () {
  function Ou(e) {
    _classCallCheck2(this, Ou);

    this.config = e || this.config, this.authObj = void 0;
  }

  _createClass2(Ou, [{
    key: "init",
    value: function init(e) {
      switch (Dc.adapter || (this.requestClient = new Dc.adapter.reqClass({
        timeout: e.timeout || 5e3,
        timeoutMsg: "\u8BF7\u6C42\u5728".concat((e.timeout || 5e3) / 1e3, "s\u5185\u672A\u5B8C\u6210\uFF0C\u5DF2\u4E2D\u65AD")
      })), this.config = _objectSpread2(_objectSpread2({}, Pu), e), !0) {
        case this.config.timeout > 6e5:
          console.warn("timeout大于可配置上限[10分钟]，已重置为上限数值"), this.config.timeout = 6e5;
          break;

        case this.config.timeout < 100:
          console.warn("timeout小于可配置下限[100ms]，已重置为下限数值"), this.config.timeout = 100;
      }

      return new Ou(this.config);
    }
  }, {
    key: "auth",
    value: function auth() {
      var _ref38 = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {},
          e = _ref38.persistence;

      if (this.authObj) return this.authObj;
      var t = e || Dc.adapter.primaryStorage || Pu.persistence;
      var n;
      return t !== this.config.persistence && (this.config.persistence = t), function (e) {
        var t = e.env;
        Hc[t] = new Bc(e), Kc[t] = new Bc(_objectSpread2(_objectSpread2({}, e), {}, {
          persistence: "local"
        }));
      }(this.config), n = this.config, uu[n.env] = new cu(n), this.authObj = new vu(this.config), this.authObj;
    }
  }, {
    key: "on",
    value: function on(e, t) {
      return Gc.apply(this, [e, t]);
    }
  }, {
    key: "off",
    value: function off(e, t) {
      return Qc.apply(this, [e, t]);
    }
  }, {
    key: "callFunction",
    value: function callFunction(e, t) {
      return Su.apply(this, [e, t]);
    }
  }, {
    key: "deleteFile",
    value: function deleteFile(e, t) {
      return wu.apply(this, [e, t]);
    }
  }, {
    key: "getTempFileURL",
    value: function getTempFileURL(e, t) {
      return ku.apply(this, [e, t]);
    }
  }, {
    key: "downloadFile",
    value: function downloadFile(e, t) {
      return xu.apply(this, [e, t]);
    }
  }, {
    key: "uploadFile",
    value: function uploadFile(e, t) {
      return bu.apply(this, [e, t]);
    }
  }, {
    key: "getUploadMetadata",
    value: function getUploadMetadata(e, t) {
      return _u.apply(this, [e, t]);
    }
  }, {
    key: "registerExtension",
    value: function registerExtension(e) {
      Au[e.name] = e;
    }
  }, {
    key: "invokeExtension",
    value: function () {
      var _invokeExtension = _asyncToGenerator2( /*#__PURE__*/_regenerator.default.mark(function _callee33(e, t) {
        var n;
        return _regenerator.default.wrap(function _callee33$(_context33) {
          while (1) {
            switch (_context33.prev = _context33.next) {
              case 0:
                n = Au[e];

                if (n) {
                  _context33.next = 3;
                  break;
                }

                throw new dc({
                  message: "\u6269\u5C55".concat(e, " \u5FC5\u987B\u5148\u6CE8\u518C")
                });

              case 3:
                _context33.next = 5;
                return n.invoke(t, this);

              case 5:
                return _context33.abrupt("return", _context33.sent);

              case 6:
              case "end":
                return _context33.stop();
            }
          }
        }, _callee33, this);
      }));

      function invokeExtension(_x29, _x30) {
        return _invokeExtension.apply(this, arguments);
      }

      return invokeExtension;
    }()
  }, {
    key: "useAdapters",
    value: function useAdapters(e) {
      var _ref39 = function (e) {
        var t = (n = e, "[object Array]" === Object.prototype.toString.call(n) ? e : [e]);
        var n;

        var _iterator7 = _createForOfIteratorHelper2(t),
            _step7;

        try {
          for (_iterator7.s(); !(_step7 = _iterator7.n()).done;) {
            var _r38 = _step7.value;
            var _e47 = _r38.isMatch,
                _t42 = _r38.genAdapter,
                _n39 = _r38.runtime;
            if (_e47()) return {
              adapter: _t42(),
              runtime: _n39
            };
          }
        } catch (err) {
          _iterator7.e(err);
        } finally {
          _iterator7.f();
        }
      }(e) || {},
          t = _ref39.adapter,
          n = _ref39.runtime;

      t && (Dc.adapter = t), n && (Dc.runtime = n);
    }
  }]);

  return Ou;
}();var Iu = new Ou();function Tu(e, t, n) {
  void 0 === n && (n = {});
  var r = /\?/.test(t),
      o = "";

  for (var s in n) {
    "" === o ? !r && (t += "?") : o += "&", o += s + "=" + encodeURIComponent(n[s]);
  }

  return /^http(s)?:\/\//.test(t += o) ? t : "" + e + t;
}var Cu = /*#__PURE__*/function () {
  function Cu() {
    _classCallCheck2(this, Cu);
  }

  _createClass2(Cu, [{
    key: "post",
    value: function post(e) {
      var t = e.url,
          n = e.data,
          r = e.headers;
      return new Promise(function (e, o) {
        pc.request({
          url: Tu("https:", t),
          data: n,
          method: "POST",
          header: r,
          success: function success(t) {
            e(t);
          },
          fail: function fail(e) {
            o(e);
          }
        });
      });
    }
  }, {
    key: "upload",
    value: function upload(e) {
      return new Promise(function (t, n) {
        var r = e.url,
            o = e.file,
            s = e.data,
            i = e.headers,
            a = e.fileType,
            c = pc.uploadFile({
          url: Tu("https:", r),
          name: "file",
          formData: Object.assign({}, s),
          filePath: o,
          fileType: a,
          header: i,
          success: function success(e) {
            var n = {
              statusCode: e.statusCode,
              data: e.data || {}
            };
            200 === e.statusCode && s.success_action_status && (n.statusCode = parseInt(s.success_action_status, 10)), t(n);
          },
          fail: function fail(e) {
            n(new Error(e.errMsg || "uploadFile:fail"));
          }
        });
        "function" == typeof e.onUploadProgress && c && "function" == typeof c.onProgressUpdate && c.onProgressUpdate(function (t) {
          e.onUploadProgress({
            loaded: t.totalBytesSent,
            total: t.totalBytesExpectedToSend
          });
        });
      });
    }
  }]);

  return Cu;
}();var Eu = {
  setItem: function setItem(e, t) {
    pc.setStorageSync(e, t);
  },
  getItem: function getItem(e) {
    return pc.getStorageSync(e);
  },
  removeItem: function removeItem(e) {
    pc.removeStorageSync(e);
  },
  clear: function clear() {
    pc.clearStorageSync();
  }
};var Mu = {
  genAdapter: function genAdapter() {
    return {
      root: {},
      reqClass: Cu,
      localStorage: Eu,
      primaryStorage: "local"
    };
  },
  isMatch: function isMatch() {
    return !0;
  },
  runtime: "uni_app"
};Iu.useAdapters(Mu);var Lu = Iu,
    $u = Lu.init;Lu.init = function (e) {
  e.env = e.spaceId;
  var t = $u.call(this, e);
  t.config.provider = "tencent", t.config.spaceId = e.spaceId;
  var n = t.auth;
  return t.auth = function (e) {
    var t = n.call(this, e);
    return ["linkAndRetrieveDataWithTicket", "signInAnonymously", "signOut", "getAccessToken", "getLoginState", "signInWithTicket", "getUserInfo"].forEach(function (e) {
      var n;
      t[e] = (n = t[e], function (e) {
        e = e || {};

        var _hc = hc(e),
            t = _hc.success,
            r = _hc.fail,
            o = _hc.complete;

        if (!(t || r || o)) return n.call(this, e);
        n.call(this, e).then(function (e) {
          t && t(e), o && o(e);
        }, function (e) {
          r && r(e), o && o(e);
        });
      }).bind(t);
    }), t;
  }, t.customAuth = t.auth, t;
};var Ru = Lu,
    Nu = /*#__PURE__*/function (_Ic) {
  _inherits2(Nu, _Ic);

  var _super8 = _createSuper2(Nu);

  function Nu() {
    _classCallCheck2(this, Nu);

    return _super8.apply(this, arguments);
  }

  _createClass2(Nu, [{
    key: "getAccessToken",
    value: function getAccessToken() {
      var _this14 = this;

      return new Promise(function (e, t) {
        var n = "Anonymous_Access_token";
        _this14.setAccessToken(n), e(n);
      });
    }
  }, {
    key: "setupRequest",
    value: function setupRequest(e, t) {
      var n = Object.assign({}, e, {
        spaceId: this.config.spaceId,
        timestamp: Date.now()
      }),
          r = {
        "Content-Type": "application/json"
      };
      "auth" !== t && (n.token = this.accessToken, r["x-basement-token"] = this.accessToken), r["x-serverless-sign"] = xc(n, this.config.clientSecret);
      var o = kc();
      r["x-client-info"] = encodeURIComponent(JSON.stringify(o));

      var _mc = mc(),
          s = _mc.token;

      return r["x-client-token"] = s, {
        url: this.config.requestUrl,
        method: "POST",
        data: n,
        dataType: "json",
        header: JSON.parse(JSON.stringify(r))
      };
    }
  }, {
    key: "uploadFileToOSS",
    value: function uploadFileToOSS(_ref40) {
      var _this15 = this;

      var e = _ref40.url,
          t = _ref40.formData,
          n = _ref40.name,
          r = _ref40.filePath,
          o = _ref40.fileType,
          s = _ref40.onUploadProgress;
      return new Promise(function (i, a) {
        var c = _this15.adapter.uploadFile({
          url: e,
          formData: t,
          name: n,
          filePath: r,
          fileType: o,
          success: function success(e) {
            e && e.statusCode < 400 ? i(e) : a(new dc({
              code: "UPLOAD_FAILED",
              message: "文件上传失败"
            }));
          },
          fail: function fail(e) {
            a(new dc({
              code: e.code || "UPLOAD_FAILED",
              message: e.message || e.errMsg || "文件上传失败"
            }));
          }
        });

        "function" == typeof s && c && "function" == typeof c.onProgressUpdate && c.onProgressUpdate(function (e) {
          s({
            loaded: e.totalBytesSent,
            total: e.totalBytesExpectedToSend
          });
        });
      });
    }
  }, {
    key: "uploadFile",
    value: function uploadFile(_ref41) {
      var _this16 = this;

      var e = _ref41.filePath,
          t = _ref41.cloudPath,
          _ref41$fileType = _ref41.fileType,
          n = _ref41$fileType === void 0 ? "image" : _ref41$fileType,
          r = _ref41.onUploadProgress;
      if (!t) throw new dc({
        code: "CLOUDPATH_REQUIRED",
        message: "cloudPath不可为空"
      });
      var o;
      return this.getOSSUploadOptionsFromPath({
        cloudPath: t
      }).then(function (t) {
        var _t$result = t.result,
            s = _t$result.url,
            i = _t$result.formData,
            a = _t$result.name;
        o = t.result.fileUrl;
        var c = {
          url: s,
          formData: i,
          name: a,
          filePath: e,
          fileType: n
        };
        return _this16.uploadFileToOSS(Object.assign({}, c, {
          onUploadProgress: r
        }));
      }).then(function () {
        return _this16.reportOSSUpload({
          cloudPath: t
        });
      }).then(function (t) {
        return new Promise(function (n, r) {
          t.success ? n({
            success: !0,
            filePath: e,
            fileID: o
          }) : r(new dc({
            code: "UPLOAD_FAILED",
            message: "文件上传失败"
          }));
        });
      });
    }
  }, {
    key: "deleteFile",
    value: function deleteFile(_ref42) {
      var e = _ref42.fileList;
      var t = {
        method: "serverless.file.resource.delete",
        params: JSON.stringify({
          fileList: e
        })
      };
      return this.request(this.setupRequest(t)).then(function (e) {
        if (e.success) return e.result;
        throw new dc({
          code: "DELETE_FILE_FAILED",
          message: "删除文件失败"
        });
      });
    }
  }, {
    key: "getTempFileURL",
    value: function getTempFileURL() {
      var _ref43 = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {},
          e = _ref43.fileList;

      if (!Array.isArray(e) || 0 === e.length) throw new dc({
        code: "INVALID_PARAM",
        message: "fileList的元素必须是非空的字符串"
      });
      var t = {
        method: "serverless.file.resource.getTempFileURL",
        params: JSON.stringify({
          fileList: e
        })
      };
      return this.request(this.setupRequest(t)).then(function (e) {
        if (e.success) return {
          fileList: e.result.fileList.map(function (e) {
            return {
              fileID: e.fileID,
              tempFileURL: e.tempFileURL
            };
          })
        };
        throw new dc({
          code: "GET_TEMP_FILE_URL_FAILED",
          message: "获取临时文件链接失败"
        });
      });
    }
  }]);

  return Nu;
}(Ic),
    ju = {
  init: function init(e) {
    var t = new Nu(e),
        n = {
      signInAnonymously: function signInAnonymously() {
        return t.authorize();
      },
      getLoginState: function getLoginState() {
        return Promise.resolve(!1);
      }
    };
    return t.auth = function () {
      return n;
    }, t.customAuth = t.auth, t;
  }
};function Du(_ref44) {
  var e = _ref44.data;
  var t;
  t = kc();
  var n = JSON.parse(JSON.stringify(e || {}));

  if (Object.assign(n, {
    clientInfo: t
  }), !n.uniIdToken) {
    var _mc2 = mc(),
        _e48 = _mc2.token;

    _e48 && (n.uniIdToken = _e48);
  }

  return n;
}var Uu = [{
  rule: /fc_function_not_found|FUNCTION_NOT_FOUND/,
  content: "，云函数[{functionName}]在云端不存在，请检查此云函数名称是否正确以及该云函数是否已上传到服务空间",
  mode: "append"
}];var Fu = /[\\^$.*+?()[\]{}|]/g,
    qu = RegExp(Fu.source);function Bu(e, t, n) {
  return e.replace(new RegExp((r = t) && qu.test(r) ? r.replace(Fu, "\\$&") : r, "g"), n);
  var r;
}var Hu = 2e4,
    Ku = {
  code: 20101,
  message: "Invalid client"
};function Vu(e) {
  var _ref45 = e || {},
      t = _ref45.errSubject,
      n = _ref45.subject,
      r = _ref45.errCode,
      o = _ref45.errMsg,
      s = _ref45.code,
      i = _ref45.message,
      a = _ref45.cause;

  return new dc({
    subject: t || n || "uni-secure-network",
    code: r || s || Hu,
    message: o || i,
    cause: a
  });
}var Wu;function zu() {
  var _ref46 = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {},
      e = _ref46.secretType;

  return "request" === e || "response" === e || "both" === e;
}function Ju(_ref47) {
  var e = _ref47.functionName,
      t = _ref47.result,
      n = _ref47.logPvd;
}function Gu(e) {
  var t = e.callFunction,
      n = function n(_n40) {
    var _this17 = this;

    var r = _n40.name;
    _n40.data = Du.call(e, {
      data: _n40.data
    });
    var o = {
      aliyun: "aliyun",
      tencent: "tcb",
      tcb: "tcb"
    }[this.config.provider],
        s = zu(_n40) || false;
    return t.call(this, _n40).then(function (e) {
      return e.errCode = 0, !s && Ju.call(_this17, {
        functionName: r,
        result: e,
        logPvd: o
      }), Promise.resolve(e);
    }, function (e) {
      return !s && Ju.call(_this17, {
        functionName: r,
        result: e,
        logPvd: o
      }), e && e.message && (e.message = function () {
        var _ref48 = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {},
            _ref48$message = _ref48.message,
            e = _ref48$message === void 0 ? "" : _ref48$message,
            _ref48$extraInfo = _ref48.extraInfo,
            t = _ref48$extraInfo === void 0 ? {} : _ref48$extraInfo,
            _ref48$formatter = _ref48.formatter,
            n = _ref48$formatter === void 0 ? [] : _ref48$formatter;

        for (var _r39 = 0; _r39 < n.length; _r39++) {
          var _n$_r = n[_r39],
              _o25 = _n$_r.rule,
              _s17 = _n$_r.content,
              i = _n$_r.mode,
              _a7 = e.match(_o25);

          if (!_a7) continue;
          var _c5 = _s17;

          for (var _e49 = 1; _e49 < _a7.length; _e49++) {
            _c5 = Bu(_c5, "{$".concat(_e49, "}"), _a7[_e49]);
          }

          for (var _e50 in t) {
            _c5 = Bu(_c5, "{".concat(_e50, "}"), t[_e50]);
          }

          return "replace" === i ? _c5 : e + _c5;
        }

        return e;
      }({
        message: "[".concat(_n40.name, "]: ").concat(e.message),
        formatter: Uu,
        extraInfo: {
          functionName: r
        }
      })), Promise.reject(e);
    });
  };

  e.callFunction = function (t) {
    var _e$config = e.config,
        r = _e$config.provider,
        o = _e$config.spaceId,
        s = t.name;
    var i, a;
    return t.data = t.data || {}, i = n, i = i.bind(e), a = function (_ref49) {
      var e = _ref49.name,
          _ref49$data = _ref49.data,
          t = _ref49$data === void 0 ? {} : _ref49$data;
      return "uni-id-co" === e && "secureNetworkHandshakeByWeixin" === t.method;
    }(t) ? i.call(e, t) : zu(t) ? new Wu({
      secretType: t.secretType,
      uniCloudIns: e
    }).wrapEncryptDataCallFunction(n.bind(e))(t) : function () {
      var _ref50 = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {},
          e = _ref50.provider,
          t = _ref50.spaceId,
          n = _ref50.functionName;

      var _c6 = _c(),
          r = _c6.appId,
          o = _c6.uniPlatform,
          s = _c6.osName;

      var i = o;
      "app" === o && (i = s);

      var a = function () {
        var _ref51 = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {},
            e = _ref51.provider,
            t = _ref51.spaceId;

        if (!Ua) return {};
        var n;
        e = "tencent" === (n = e) ? "tcb" : n;
        var r = Ua.find(function (n) {
          return n.provider === e && n.spaceId === t;
        });
        return r && r.config;
      }({
        provider: e,
        spaceId: t
      });

      if (!a || !a.accessControl || !a.accessControl.enable) return !1;
      var c = a.accessControl.function || {},
          u = Object.keys(c);
      if (0 === u.length) return !0;

      var l = function (e, t) {
        var n, r, o;

        for (var _s18 = 0; _s18 < e.length; _s18++) {
          var _i14 = e[_s18];
          _i14 !== t ? "*" !== _i14 ? _i14.split(",").map(function (e) {
            return e.trim();
          }).indexOf(t) > -1 && (r = _i14) : o = _i14 : n = _i14;
        }

        return n || r || o;
      }(u, n);

      if (!l) return !1;
      if ((c[l] || []).find(function () {
        var e = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {};
        return e.appId === r && (e.platform || "").toLowerCase() === i.toLowerCase();
      })) return !0;
      throw console.error("\u6B64\u5E94\u7528[appId: ".concat(r, ", platform: ").concat(i, "]\u4E0D\u5728\u4E91\u7AEF\u914D\u7F6E\u7684\u5141\u8BB8\u8BBF\u95EE\u7684\u5E94\u7528\u5217\u8868\u5185\uFF0C\u53C2\u8003\uFF1Ahttps://uniapp.dcloud.net.cn/uniCloud/secure-network.html#verify-client")), Vu(Ku);
    }({
      provider: r,
      spaceId: o,
      functionName: s
    }) ? new Wu({
      secretType: t.secretType,
      uniCloudIns: e
    }).wrapVerifyClientCallFunction(n.bind(e))(t) : i(t), Object.defineProperty(a, "result", {
      get: function get() {
        return console.warn("当前返回结果为Promise类型，不可直接访问其result属性，详情请参考：https://uniapp.dcloud.net.cn/uniCloud/faq?id=promise"), {};
      }
    }), a;
  };
}Wu = /*#__PURE__*/_createClass2(function Wu() {
  _classCallCheck2(this, Wu);

  throw Vu({
    message: "Platform ".concat(Fa, " is not enabled, please check whether secure network module is enabled in your manifest.json")
  });
});var Yu = Symbol("CLIENT_DB_INTERNAL");function Qu(e, t) {
  return e.then = "DoNotReturnProxyWithAFunctionNamedThen", e._internalType = Yu, e.inspect = null, e.__v_raw = void 0, new Proxy(e, {
    get: function get(e, n, r) {
      if ("_uniClient" === n) return null;
      if ("symbol" == _typeof2(n)) return e[n];

      if (n in e || "string" != typeof n) {
        var _t43 = e[n];
        return "function" == typeof _t43 ? _t43.bind(e) : _t43;
      }

      return t.get(e, n, r);
    }
  });
}function Xu(e) {
  return {
    on: function on(t, n) {
      e[t] = e[t] || [], e[t].indexOf(n) > -1 || e[t].push(n);
    },
    off: function off(t, n) {
      e[t] = e[t] || [];
      var r = e[t].indexOf(n);
      -1 !== r && e[t].splice(r, 1);
    }
  };
}var Zu = ["db.Geo", "db.command", "command.aggregate"];function el(e, t) {
  return Zu.indexOf("".concat(e, ".").concat(t)) > -1;
}function tl(e) {
  switch (Ea(e = gc(e))) {
    case "array":
      return e.map(function (e) {
        return tl(e);
      });

    case "object":
      return e._internalType === Yu || Object.keys(e).forEach(function (t) {
        e[t] = tl(e[t]);
      }), e;

    case "regexp":
      return {
        $regexp: {
          source: e.source,
          flags: e.flags
        }
      };

    case "date":
      return {
        $date: e.toISOString()
      };

    default:
      return e;
  }
}function nl(e) {
  return e && e.content && e.content.$method;
}var rl = /*#__PURE__*/function () {
  function rl(e, t, n) {
    _classCallCheck2(this, rl);

    this.content = e, this.prevStage = t || null, this.udb = null, this._database = n;
  }

  _createClass2(rl, [{
    key: "toJSON",
    value: function toJSON() {
      var e = this;
      var t = [e.content];

      for (; e.prevStage;) {
        e = e.prevStage, t.push(e.content);
      }

      return {
        $db: t.reverse().map(function (e) {
          return {
            $method: e.$method,
            $param: tl(e.$param)
          };
        })
      };
    }
  }, {
    key: "toString",
    value: function toString() {
      return JSON.stringify(this.toJSON());
    }
  }, {
    key: "getAction",
    value: function getAction() {
      var e = this.toJSON().$db.find(function (e) {
        return "action" === e.$method;
      });
      return e && e.$param && e.$param[0];
    }
  }, {
    key: "getCommand",
    value: function getCommand() {
      return {
        $db: this.toJSON().$db.filter(function (e) {
          return "action" !== e.$method;
        })
      };
    }
  }, {
    key: "isAggregate",
    get: function get() {
      var e = this;

      for (; e;) {
        var t = nl(e),
            _n41 = nl(e.prevStage);

        if ("aggregate" === t && "collection" === _n41 || "pipeline" === t) return !0;
        e = e.prevStage;
      }

      return !1;
    }
  }, {
    key: "isCommand",
    get: function get() {
      var e = this;

      for (; e;) {
        if ("command" === nl(e)) return !0;
        e = e.prevStage;
      }

      return !1;
    }
  }, {
    key: "isAggregateCommand",
    get: function get() {
      var e = this;

      for (; e;) {
        var t = nl(e),
            _n42 = nl(e.prevStage);

        if ("aggregate" === t && "command" === _n42) return !0;
        e = e.prevStage;
      }

      return !1;
    }
  }, {
    key: "getNextStageFn",
    value: function getNextStageFn(e) {
      var t = this;
      return function () {
        return ol({
          $method: e,
          $param: tl(Array.from(arguments))
        }, t, t._database);
      };
    }
  }, {
    key: "count",
    get: function get() {
      return this.isAggregate ? this.getNextStageFn("count") : function () {
        return this._send("count", Array.from(arguments));
      };
    }
  }, {
    key: "remove",
    get: function get() {
      return this.isCommand ? this.getNextStageFn("remove") : function () {
        return this._send("remove", Array.from(arguments));
      };
    }
  }, {
    key: "get",
    value: function get() {
      return this._send("get", Array.from(arguments));
    }
  }, {
    key: "add",
    get: function get() {
      return this.isCommand ? this.getNextStageFn("add") : function () {
        return this._send("add", Array.from(arguments));
      };
    }
  }, {
    key: "update",
    value: function update() {
      return this._send("update", Array.from(arguments));
    }
  }, {
    key: "end",
    value: function end() {
      return this._send("end", Array.from(arguments));
    }
  }, {
    key: "set",
    get: function get() {
      return this.isCommand ? this.getNextStageFn("set") : function () {
        throw new Error("JQL禁止使用set方法");
      };
    }
  }, {
    key: "_send",
    value: function _send(e, t) {
      var n = this.getAction(),
          r = this.getCommand();
      return r.$db.push({
        $method: e,
        $param: tl(t)
      }), this._database._callCloudFunction({
        action: n,
        command: r
      });
    }
  }]);

  return rl;
}();function ol(e, t, n) {
  return Qu(new rl(e, t, n), {
    get: function get(e, t) {
      var r = "db";
      return e && e.content && (r = e.content.$method), el(r, t) ? ol({
        $method: t
      }, e, n) : function () {
        return ol({
          $method: t,
          $param: tl(Array.from(arguments))
        }, e, n);
      };
    }
  });
}function sl(_ref52) {
  var e = _ref52.path,
      t = _ref52.method;
  return /*#__PURE__*/function () {
    function _class3() {
      _classCallCheck2(this, _class3);

      this.param = Array.from(arguments);
    }

    _createClass2(_class3, [{
      key: "toJSON",
      value: function toJSON() {
        return {
          $newDb: [].concat(_toConsumableArray2(e.map(function (e) {
            return {
              $method: e
            };
          })), [{
            $method: t,
            $param: this.param
          }])
        };
      }
    }, {
      key: "toString",
      value: function toString() {
        return JSON.stringify(this.toJSON());
      }
    }]);

    return _class3;
  }();
}function il(e) {
  var t = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : {};
  return Qu(new e(t), {
    get: function get(e, t) {
      return el("db", t) ? ol({
        $method: t
      }, null, e) : function () {
        return ol({
          $method: t,
          $param: tl(Array.from(arguments))
        }, null, e);
      };
    }
  });
}var al = /*#__PURE__*/function (_ref53) {
  _inherits2(al, _ref53);

  var _super9 = _createSuper2(al);

  function al() {
    _classCallCheck2(this, al);

    return _super9.apply(this, arguments);
  }

  _createClass2(al, [{
    key: "_parseResult",
    value: function _parseResult(e) {
      return this._isJQL ? e.result : e;
    }
  }, {
    key: "_callCloudFunction",
    value: function _callCloudFunction(_ref54) {
      var _this18 = this;

      var e = _ref54.action,
          t = _ref54.command,
          n = _ref54.multiCommand,
          r = _ref54.queryList;

      function o(e, t) {
        if (n && r) for (var _n43 = 0; _n43 < r.length; _n43++) {
          var _o26 = r[_n43];
          _o26.udb && "function" == typeof _o26.udb.setResult && (t ? _o26.udb.setResult(t) : _o26.udb.setResult(e.result.dataList[_n43]));
        }
      }

      var s = this,
          i = this._isJQL ? "databaseForJQL" : "database";

      function a(e) {
        return s._callback("error", [e]), Ga(Ya(i, "fail"), e).then(function () {
          return Ga(Ya(i, "complete"), e);
        }).then(function () {
          return o(null, e), cc(Za, {
            type: nc,
            content: e
          }), Promise.reject(e);
        });
      }

      var c = Ga(Ya(i, "invoke")),
          u = this._uniClient;
      return c.then(function () {
        return u.callFunction({
          name: "DCloud-clientDB",
          type: "CLIENT_DB",
          data: {
            action: e,
            command: t,
            multiCommand: n
          }
        });
      }).then(function (e) {
        var _e$result = e.result,
            t = _e$result.code,
            n = _e$result.message,
            r = _e$result.token,
            c = _e$result.tokenExpired,
            _e$result$systemInfo = _e$result.systemInfo,
            u = _e$result$systemInfo === void 0 ? [] : _e$result$systemInfo;
        if (u) for (var _o27 = 0; _o27 < u.length; _o27++) {
          var _u$_o = u[_o27],
              _e51 = _u$_o.level,
              _t44 = _u$_o.message,
              _n44 = _u$_o.detail;

          var _r40 = "[System Info]" + _t44;

          _n44 && (_r40 = "".concat(_r40, "\n\u8BE6\u7EC6\u4FE1\u606F\uFF1A").concat(_n44)), (console[_e51] || console.log)(_r40);
        }
        if (t) return a(new dc({
          code: t,
          message: n,
          requestId: e.requestId
        }));
        e.result.errCode = e.result.errCode || e.result.code, e.result.errMsg = e.result.errMsg || e.result.message, r && c && (yc({
          token: r,
          tokenExpired: c
        }), _this18._callbackAuth("refreshToken", [{
          token: r,
          tokenExpired: c
        }]), _this18._callback("refreshToken", [{
          token: r,
          tokenExpired: c
        }]), cc(tc, {
          token: r,
          tokenExpired: c
        }));
        var l = [{
          prop: "affectedDocs",
          tips: "affectedDocs不再推荐使用，请使用inserted/deleted/updated/data.length替代"
        }, {
          prop: "code",
          tips: "code不再推荐使用，请使用errCode替代"
        }, {
          prop: "message",
          tips: "message不再推荐使用，请使用errMsg替代"
        }];

        var _loop4 = function _loop4(_o28) {
          var _l$_o = l[_o28],
              t = _l$_o.prop,
              n = _l$_o.tips;

          if (t in e.result) {
            var _r41 = e.result[t];
            Object.defineProperty(e.result, t, {
              get: function get() {
                return console.warn(n), _r41;
              }
            });
          }
        };

        for (var _o28 = 0; _o28 < l.length; _o28++) {
          _loop4(_o28);
        }

        return f = e, Ga(Ya(i, "success"), f).then(function () {
          return Ga(Ya(i, "complete"), f);
        }).then(function () {
          o(f, null);

          var e = s._parseResult(f);

          return cc(Za, {
            type: nc,
            content: e
          }), Promise.resolve(e);
        });
        var f;
      }, function (e) {
        return /fc_function_not_found|FUNCTION_NOT_FOUND/g.test(e.message) && console.warn("clientDB未初始化，请在web控制台保存一次schema以开启clientDB"), a(new dc({
          code: e.code || "SYSTEM_ERROR",
          message: e.message,
          requestId: e.requestId
        }));
      });
    }
  }]);

  return al;
}( /*#__PURE__*/function () {
  function _class4() {
    var _ref55 = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {},
        _ref55$uniClient = _ref55.uniClient,
        e = _ref55$uniClient === void 0 ? {} : _ref55$uniClient,
        _ref55$isJQL = _ref55.isJQL,
        t = _ref55$isJQL === void 0 ? !1 : _ref55$isJQL;

    _classCallCheck2(this, _class4);

    this._uniClient = e, this._authCallBacks = {}, this._dbCallBacks = {}, e._isDefault && (this._dbCallBacks = Ka("_globalUniCloudDatabaseCallback")), t || (this.auth = Xu(this._authCallBacks)), this._isJQL = t, Object.assign(this, Xu(this._dbCallBacks)), this.env = Qu({}, {
      get: function get(e, t) {
        return {
          $env: t
        };
      }
    }), this.Geo = Qu({}, {
      get: function get(e, t) {
        return sl({
          path: ["Geo"],
          method: t
        });
      }
    }), this.serverDate = sl({
      path: [],
      method: "serverDate"
    }), this.RegExp = sl({
      path: [],
      method: "RegExp"
    });
  }

  _createClass2(_class4, [{
    key: "getCloudEnv",
    value: function getCloudEnv(e) {
      if ("string" != typeof e || !e.trim()) throw new Error("getCloudEnv参数错误");
      return {
        $env: e.replace("$cloudEnv_", "")
      };
    }
  }, {
    key: "_callback",
    value: function _callback(e, t) {
      var n = this._dbCallBacks;
      n[e] && n[e].forEach(function (e) {
        e.apply(void 0, _toConsumableArray2(t));
      });
    }
  }, {
    key: "_callbackAuth",
    value: function _callbackAuth(e, t) {
      var n = this._authCallBacks;
      n[e] && n[e].forEach(function (e) {
        e.apply(void 0, _toConsumableArray2(t));
      });
    }
  }, {
    key: "multiSend",
    value: function multiSend() {
      var e = Array.from(arguments),
          t = e.map(function (e) {
        var t = e.getAction(),
            n = e.getCommand();
        if ("getTemp" !== n.$db[n.$db.length - 1].$method) throw new Error("multiSend只支持子命令内使用getTemp");
        return {
          action: t,
          command: n
        };
      });
      return this._callCloudFunction({
        multiCommand: t,
        queryList: e
      });
    }
  }]);

  return _class4;
}());var cl = "token无效，跳转登录页面",
    ul = "token过期，跳转登录页面",
    ll = {
  TOKEN_INVALID_TOKEN_EXPIRED: ul,
  TOKEN_INVALID_INVALID_CLIENTID: cl,
  TOKEN_INVALID: cl,
  TOKEN_INVALID_WRONG_TOKEN: cl,
  TOKEN_INVALID_ANONYMOUS_USER: cl
},
    fl = {
  "uni-id-token-expired": ul,
  "uni-id-check-token-failed": cl,
  "uni-id-token-not-exist": cl,
  "uni-id-check-device-feature-failed": cl
};function hl(e, t) {
  var n = "";
  return n = e ? "".concat(e, "/").concat(t) : t, n.replace(/^\//, "");
}function dl() {
  var e = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : [];
  var t = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : "";
  var n = [],
      r = [];
  return e.forEach(function (e) {
    !0 === e.needLogin ? n.push(hl(t, e.path)) : !1 === e.needLogin && r.push(hl(t, e.path));
  }), {
    needLoginPage: n,
    notNeedLoginPage: r
  };
}function pl(e) {
  return e.split("?")[0].replace(/^\//, "");
}function gl() {
  return function (e) {
    var t = e && e.$page && e.$page.fullPath || "";
    return t ? ("/" !== t.charAt(0) && (t = "/" + t), t) : t;
  }(function () {
    var e = getCurrentPages();
    return e[e.length - 1];
  }());
}function ml() {
  return pl(gl());
}function yl() {
  var e = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : "";
  var t = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : {};
  if (!e) return !1;
  if (!(t && t.list && t.list.length)) return !1;
  var n = t.list,
      r = pl(e);
  return n.some(function (e) {
    return e.pagePath === r;
  });
}var vl = !!wa.uniIdRouter,
    _ref56 = function () {
  var _ref57 = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : wa,
      _ref57$pages = _ref57.pages,
      e = _ref57$pages === void 0 ? [] : _ref57$pages,
      _ref57$subPackages = _ref57.subPackages,
      t = _ref57$subPackages === void 0 ? [] : _ref57$subPackages,
      _ref57$uniIdRouter = _ref57.uniIdRouter,
      n = _ref57$uniIdRouter === void 0 ? {} : _ref57$uniIdRouter,
      _ref57$tabBar = _ref57.tabBar,
      r = _ref57$tabBar === void 0 ? {} : _ref57$tabBar;

  var o = n.loginPage,
      _n$needLogin = n.needLogin,
      s = _n$needLogin === void 0 ? [] : _n$needLogin,
      _n$resToLogin = n.resToLogin,
      i = _n$resToLogin === void 0 ? !0 : _n$resToLogin,
      _dl = dl(e),
      a = _dl.needLoginPage,
      c = _dl.notNeedLoginPage,
      _ref58 = function () {
    var e = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : [];
    var t = [],
        n = [];
    return e.forEach(function (e) {
      var r = e.root,
          _e$pages = e.pages,
          o = _e$pages === void 0 ? [] : _e$pages,
          _dl2 = dl(o, r),
          s = _dl2.needLoginPage,
          i = _dl2.notNeedLoginPage;

      t.push.apply(t, _toConsumableArray2(s)), n.push.apply(n, _toConsumableArray2(i));
    }), {
      needLoginPage: t,
      notNeedLoginPage: n
    };
  }(t),
      u = _ref58.needLoginPage,
      l = _ref58.notNeedLoginPage;

  return {
    loginPage: o,
    routerNeedLogin: s,
    resToLogin: i,
    needLoginPage: [].concat(_toConsumableArray2(a), _toConsumableArray2(u)),
    notNeedLoginPage: [].concat(_toConsumableArray2(c), _toConsumableArray2(l)),
    loginPageInTabBar: yl(o, r)
  };
}(),
    bl = _ref56.loginPage,
    _l = _ref56.routerNeedLogin,
    wl = _ref56.resToLogin,
    kl = _ref56.needLoginPage,
    xl = _ref56.notNeedLoginPage,
    Sl = _ref56.loginPageInTabBar;if (kl.indexOf(bl) > -1) throw new Error("Login page [".concat(bl, "] should not be \"needLogin\", please check your pages.json"));function Pl(e) {
  var t = ml();
  if ("/" === e.charAt(0)) return e;

  var _e$split3 = e.split("?"),
      _e$split4 = _slicedToArray2(_e$split3, 2),
      n = _e$split4[0],
      r = _e$split4[1],
      o = n.replace(/^\//, "").split("/"),
      s = t.split("/");

  s.pop();

  for (var i = 0; i < o.length; i++) {
    var _e52 = o[i];
    ".." === _e52 ? s.pop() : "." !== _e52 && s.push(_e52);
  }

  return "" === s[0] && s.shift(), "/" + s.join("/") + (r ? "?" + r : "");
}function Al(_ref59) {
  var e = _ref59.redirect;
  var t = pl(e),
      n = pl(bl);
  return ml() !== n && t !== n;
}function Ol() {
  var _ref60 = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {},
      e = _ref60.api,
      t = _ref60.redirect;

  if (!t || !Al({
    redirect: t
  })) return;
  var n = (o = t, "/" !== (r = bl).charAt(0) && (r = "/" + r), o ? r.indexOf("?") > -1 ? r + "&uniIdRedirectUrl=".concat(encodeURIComponent(o)) : r + "?uniIdRedirectUrl=".concat(encodeURIComponent(o)) : r);
  var r, o;
  Sl ? "navigateTo" !== e && "redirectTo" !== e || (e = "switchTab") : "switchTab" === e && (e = "navigateTo");
  var s = {
    navigateTo: On.navigateTo,
    redirectTo: On.redirectTo,
    switchTab: On.switchTab,
    reLaunch: On.reLaunch
  };
  setTimeout(function () {
    s[e]({
      url: n
    });
  });
}function Il() {
  var _ref61 = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {},
      e = _ref61.url;

  var t = {
    abortLoginPageJump: !1,
    autoToLoginPage: !1
  },
      n = function () {
    var _mc3 = mc(),
        e = _mc3.token,
        t = _mc3.tokenExpired;

    var n;

    if (e) {
      if (t < Date.now()) {
        var _e53 = "uni-id-token-expired";
        n = {
          errCode: _e53,
          errMsg: fl[_e53]
        };
      }
    } else {
      var _e54 = "uni-id-check-token-failed";
      n = {
        errCode: _e54,
        errMsg: fl[_e54]
      };
    }

    return n;
  }();

  if (function (e) {
    var t = pl(Pl(e));
    return !(xl.indexOf(t) > -1) && (kl.indexOf(t) > -1 || _l.some(function (t) {
      return n = e, new RegExp(t).test(n);
      var n;
    }));
  }(e) && n) {
    if (n.uniIdRedirectUrl = e, sc(ec).length > 0) return setTimeout(function () {
      cc(ec, n);
    }, 0), t.abortLoginPageJump = !0, t;
    t.autoToLoginPage = !0;
  }

  return t;
}function Tl() {
  !function () {
    var e = gl(),
        _Il = Il({
      url: e
    }),
        t = _Il.abortLoginPageJump,
        n = _Il.autoToLoginPage;

    t || n && Ol({
      api: "redirectTo",
      redirect: e
    });
  }();
  var e = ["navigateTo", "redirectTo", "reLaunch", "switchTab"];

  var _loop5 = function _loop5(t) {
    var n = e[t];
    On.addInterceptor(n, {
      invoke: function invoke(e) {
        var _Il2 = Il({
          url: e.url
        }),
            t = _Il2.abortLoginPageJump,
            r = _Il2.autoToLoginPage;

        return t ? e : r ? (Ol({
          api: n,
          redirect: Pl(e.url)
        }), !1) : e;
      }
    });
  };

  for (var t = 0; t < e.length; t++) {
    _loop5(t);
  }
}function Cl() {
  this.onResponse(function (e) {
    var t = e.type,
        n = e.content;
    var r = !1;

    switch (t) {
      case "cloudobject":
        r = function (e) {
          if ("object" != _typeof2(e)) return !1;

          var _ref62 = e || {},
              t = _ref62.errCode;

          return t in fl;
        }(n);

        break;

      case "clientdb":
        r = function (e) {
          if ("object" != _typeof2(e)) return !1;

          var _ref63 = e || {},
              t = _ref63.errCode;

          return t in ll;
        }(n);

    }

    r && function () {
      var e = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {};
      var t = sc(ec);
      fc().then(function () {
        var n = gl();
        if (n && Al({
          redirect: n
        })) return t.length > 0 ? cc(ec, Object.assign({
          uniIdRedirectUrl: n
        }, e)) : void (bl && Ol({
          api: "navigateTo",
          redirect: n
        }));
      });
    }(n);
  });
}function El(e) {
  var t;
  (t = e).onResponse = function (e) {
    ic(Za, e);
  }, t.offResponse = function (e) {
    ac(Za, e);
  }, function (e) {
    e.onNeedLogin = function (e) {
      ic(ec, e);
    }, e.offNeedLogin = function (e) {
      ac(ec, e);
    }, vl && (Ka("_globalUniCloudStatus").needLoginInit || (Ka("_globalUniCloudStatus").needLoginInit = !0, fc().then(function () {
      Tl.call(e);
    }), wl && Cl.call(e)));
  }(e), function (e) {
    e.onRefreshToken = function (e) {
      ic(tc, e);
    }, e.offRefreshToken = function (e) {
      ac(tc, e);
    };
  }(e);
}var Ml;var Ll = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/=",
    $l = /^(?:[A-Za-z\d+/]{4})*?(?:[A-Za-z\d+/]{2}(?:==)?|[A-Za-z\d+/]{3}=?)?$/;function Rl() {
  var e = mc().token || "",
      t = e.split(".");
  if (!e || 3 !== t.length) return {
    uid: null,
    role: [],
    permission: [],
    tokenExpired: 0
  };
  var n;

  try {
    n = JSON.parse((r = t[1], decodeURIComponent(Ml(r).split("").map(function (e) {
      return "%" + ("00" + e.charCodeAt(0).toString(16)).slice(-2);
    }).join(""))));
  } catch (o) {
    throw new Error("获取当前用户信息出错，详细错误信息为：" + o.message);
  }

  var r;
  return n.tokenExpired = 1e3 * n.exp, delete n.exp, delete n.iat, n;
}Ml = "function" != typeof atob ? function (e) {
  if (e = String(e).replace(/[\t\n\f\r ]+/g, ""), !$l.test(e)) throw new Error("Failed to execute 'atob' on 'Window': The string to be decoded is not correctly encoded.");
  var t;
  e += "==".slice(2 - (3 & e.length));

  for (var n, r, o = "", s = 0; s < e.length;) {
    t = Ll.indexOf(e.charAt(s++)) << 18 | Ll.indexOf(e.charAt(s++)) << 12 | (n = Ll.indexOf(e.charAt(s++))) << 6 | (r = Ll.indexOf(e.charAt(s++))), o += 64 === n ? String.fromCharCode(t >> 16 & 255) : 64 === r ? String.fromCharCode(t >> 16 & 255, t >> 8 & 255) : String.fromCharCode(t >> 16 & 255, t >> 8 & 255, 255 & t);
  }

  return o;
} : atob;var Nl = function (e) {
  return e && e.__esModule && Object.prototype.hasOwnProperty.call(e, "default") ? e.default : e;
}(ka(function (e, t) {
  Object.defineProperty(t, "__esModule", {
    value: !0
  });
  var n = "chooseAndUploadFile:ok",
      r = "chooseAndUploadFile:fail";

  function o(e, t) {
    return e.tempFiles.forEach(function (e, n) {
      e.name || (e.name = e.path.substring(e.path.lastIndexOf("/") + 1)), t && (e.fileType = t), e.cloudPath = Date.now() + "_" + n + e.name.substring(e.name.lastIndexOf("."));
    }), e.tempFilePaths || (e.tempFilePaths = e.tempFiles.map(function (e) {
      return e.path;
    })), e;
  }

  function s(e, t, _ref64) {
    var r = _ref64.onChooseFile,
        o = _ref64.onUploadProgress;
    return t.then(function (e) {
      if (r) {
        var _t45 = r(e);

        if (void 0 !== _t45) return Promise.resolve(_t45).then(function (t) {
          return void 0 === t ? e : t;
        });
      }

      return e;
    }).then(function (t) {
      return !1 === t ? {
        errMsg: n,
        tempFilePaths: [],
        tempFiles: []
      } : function (e, t) {
        var r = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : 5;
        var o = arguments.length > 3 ? arguments[3] : undefined;
        (t = Object.assign({}, t)).errMsg = n;
        var s = t.tempFiles,
            i = s.length;
        var a = 0;
        return new Promise(function (n) {
          for (; a < r;) {
            c();
          }

          function c() {
            var r = a++;
            if (r >= i) return void (!s.find(function (e) {
              return !e.url && !e.errMsg;
            }) && n(t));
            var u = s[r];
            e.uploadFile({
              filePath: u.path,
              cloudPath: u.cloudPath,
              fileType: u.fileType,
              onUploadProgress: function onUploadProgress(e) {
                e.index = r, e.tempFile = u, e.tempFilePath = u.path, o && o(e);
              }
            }).then(function (e) {
              u.url = e.fileID, r < i && c();
            }).catch(function (e) {
              u.errMsg = e.errMsg || e.message, r < i && c();
            });
          }
        });
      }(e, t, 5, o);
    });
  }

  t.initChooseAndUploadFile = function (e) {
    return function () {
      var t = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {
        type: "all"
      };
      return "image" === t.type ? s(e, function (e) {
        var t = e.count,
            n = e.sizeType,
            _e$sourceType = e.sourceType,
            s = _e$sourceType === void 0 ? ["album", "camera"] : _e$sourceType,
            i = e.extension;
        return new Promise(function (e, a) {
          On.chooseImage({
            count: t,
            sizeType: n,
            sourceType: s,
            extension: i,
            success: function success(t) {
              e(o(t, "image"));
            },
            fail: function fail(e) {
              a({
                errMsg: e.errMsg.replace("chooseImage:fail", r)
              });
            }
          });
        });
      }(t), t) : "video" === t.type ? s(e, function (e) {
        var t = e.camera,
            n = e.compressed,
            s = e.maxDuration,
            _e$sourceType2 = e.sourceType,
            i = _e$sourceType2 === void 0 ? ["album", "camera"] : _e$sourceType2,
            a = e.extension;
        return new Promise(function (e, c) {
          On.chooseVideo({
            camera: t,
            compressed: n,
            maxDuration: s,
            sourceType: i,
            extension: a,
            success: function success(t) {
              var n = t.tempFilePath,
                  r = t.duration,
                  s = t.size,
                  i = t.height,
                  a = t.width;
              e(o({
                errMsg: "chooseVideo:ok",
                tempFilePaths: [n],
                tempFiles: [{
                  name: t.tempFile && t.tempFile.name || "",
                  path: n,
                  size: s,
                  type: t.tempFile && t.tempFile.type || "",
                  width: a,
                  height: i,
                  duration: r,
                  fileType: "video",
                  cloudPath: ""
                }]
              }, "video"));
            },
            fail: function fail(e) {
              c({
                errMsg: e.errMsg.replace("chooseVideo:fail", r)
              });
            }
          });
        });
      }(t), t) : s(e, function (e) {
        var t = e.count,
            n = e.extension;
        return new Promise(function (e, s) {
          var i = On.chooseFile;
          if (void 0 !== An && "function" == typeof An.chooseMessageFile && (i = An.chooseMessageFile), "function" != typeof i) return s({
            errMsg: r + " 请指定 type 类型，该平台仅支持选择 image 或 video。"
          });
          i({
            type: "all",
            count: t,
            extension: n,
            success: function success(t) {
              e(o(t));
            },
            fail: function fail(e) {
              s({
                errMsg: e.errMsg.replace("chooseFile:fail", r)
              });
            }
          });
        });
      }(t), t);
    };
  };
}));function jl(e) {
  return {
    props: {
      localdata: {
        type: Array,
        default: function _default() {
          return [];
        }
      },
      options: {
        type: [Object, Array],
        default: function _default() {
          return {};
        }
      },
      spaceInfo: {
        type: Object,
        default: function _default() {
          return {};
        }
      },
      collection: {
        type: [String, Array],
        default: ""
      },
      action: {
        type: String,
        default: ""
      },
      field: {
        type: String,
        default: ""
      },
      orderby: {
        type: String,
        default: ""
      },
      where: {
        type: [String, Object],
        default: ""
      },
      pageData: {
        type: String,
        default: "add"
      },
      pageCurrent: {
        type: Number,
        default: 1
      },
      pageSize: {
        type: Number,
        default: 20
      },
      getcount: {
        type: [Boolean, String],
        default: !1
      },
      gettree: {
        type: [Boolean, String],
        default: !1
      },
      gettreepath: {
        type: [Boolean, String],
        default: !1
      },
      startwith: {
        type: String,
        default: ""
      },
      limitlevel: {
        type: Number,
        default: 10
      },
      groupby: {
        type: String,
        default: ""
      },
      groupField: {
        type: String,
        default: ""
      },
      distinct: {
        type: [Boolean, String],
        default: !1
      },
      foreignKey: {
        type: String,
        default: ""
      },
      loadtime: {
        type: String,
        default: "auto"
      },
      manual: {
        type: Boolean,
        default: !1
      }
    },
    data: function data() {
      return {
        mixinDatacomLoading: !1,
        mixinDatacomHasMore: !1,
        mixinDatacomResData: [],
        mixinDatacomErrorMessage: "",
        mixinDatacomPage: {}
      };
    },
    created: function created() {
      var _this19 = this;

      this.mixinDatacomPage = {
        current: this.pageCurrent,
        size: this.pageSize,
        count: 0
      }, this.$watch(function () {
        var e = [];
        return ["pageCurrent", "pageSize", "localdata", "collection", "action", "field", "orderby", "where", "getont", "getcount", "gettree", "groupby", "groupField", "distinct"].forEach(function (t) {
          e.push(_this19[t]);
        }), e;
      }, function (e, t) {
        if ("manual" === _this19.loadtime) return;
        var n = !1;
        var r = [];

        for (var _o29 = 2; _o29 < e.length; _o29++) {
          e[_o29] !== t[_o29] && (r.push(e[_o29]), n = !0);
        }

        e[0] !== t[0] && (_this19.mixinDatacomPage.current = _this19.pageCurrent), _this19.mixinDatacomPage.size = _this19.pageSize, _this19.onMixinDatacomPropsChange(n, r);
      });
    },
    methods: {
      onMixinDatacomPropsChange: function onMixinDatacomPropsChange(e, t) {},
      mixinDatacomEasyGet: function mixinDatacomEasyGet() {
        var _this20 = this;

        var _ref65 = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {},
            _ref65$getone = _ref65.getone,
            e = _ref65$getone === void 0 ? !1 : _ref65$getone,
            t = _ref65.success,
            n = _ref65.fail;

        this.mixinDatacomLoading || (this.mixinDatacomLoading = !0, this.mixinDatacomErrorMessage = "", this.mixinDatacomGet().then(function (n) {
          _this20.mixinDatacomLoading = !1;
          var _n$result = n.result,
              r = _n$result.data,
              o = _n$result.count;
          _this20.getcount && (_this20.mixinDatacomPage.count = o), _this20.mixinDatacomHasMore = r.length < _this20.pageSize;
          var s = e ? r.length ? r[0] : void 0 : r;
          _this20.mixinDatacomResData = s, t && t(s);
        }).catch(function (e) {
          _this20.mixinDatacomLoading = !1, _this20.mixinDatacomErrorMessage = e, n && n(e);
        }));
      },
      mixinDatacomGet: function mixinDatacomGet() {
        var _n45;

        var t = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {};
        var n = e.database(this.spaceInfo);
        var r = t.action || this.action;
        r && (n = n.action(r));
        var o = t.collection || this.collection;
        n = Array.isArray(o) ? (_n45 = n).collection.apply(_n45, _toConsumableArray2(o)) : n.collection(o);
        var s = t.where || this.where;
        s && Object.keys(s).length && (n = n.where(s));
        var i = t.field || this.field;
        i && (n = n.field(i));
        var a = t.foreignKey || this.foreignKey;
        a && (n = n.foreignKey(a));
        var c = t.groupby || this.groupby;
        c && (n = n.groupBy(c));
        var u = t.groupField || this.groupField;
        u && (n = n.groupField(u)), !0 === (void 0 !== t.distinct ? t.distinct : this.distinct) && (n = n.distinct());
        var l = t.orderby || this.orderby;
        l && (n = n.orderBy(l));
        var f = void 0 !== t.pageCurrent ? t.pageCurrent : this.mixinDatacomPage.current,
            h = void 0 !== t.pageSize ? t.pageSize : this.mixinDatacomPage.size,
            d = void 0 !== t.getcount ? t.getcount : this.getcount,
            p = void 0 !== t.gettree ? t.gettree : this.gettree,
            g = void 0 !== t.gettreepath ? t.gettreepath : this.gettreepath,
            m = {
          getCount: d
        },
            y = {
          limitLevel: void 0 !== t.limitlevel ? t.limitlevel : this.limitlevel,
          startWith: void 0 !== t.startwith ? t.startwith : this.startwith
        };
        return p && (m.getTree = y), g && (m.getTreePath = y), n = n.skip(h * (f - 1)).limit(h).get(m), n;
      }
    }
  };
}function Dl(e) {
  return Ka("_globalUniCloudSecureNetworkCache__{spaceId}".replace("{spaceId}", e.config.spaceId));
}function Ul() {
  return _Ul.apply(this, arguments);
}function _Ul() {
  _Ul = _asyncToGenerator2( /*#__PURE__*/_regenerator.default.mark(function _callee38() {
    var _ref78,
        e,
        _ref78$callLoginByWei,
        t,
        n,
        r,
        o,
        _args38 = arguments;

    return _regenerator.default.wrap(function _callee38$(_context38) {
      while (1) {
        switch (_context38.prev = _context38.next) {
          case 0:
            _ref78 = _args38.length > 0 && _args38[0] !== undefined ? _args38[0] : {}, e = _ref78.openid, _ref78$callLoginByWei = _ref78.callLoginByWeixin, t = _ref78$callLoginByWei === void 0 ? !1 : _ref78$callLoginByWei;
            n = Dl(this);

            if (!(e && t)) {
              _context38.next = 4;
              break;
            }

            throw new Error("[SecureNetwork] openid and callLoginByWeixin cannot be passed at the same time");

          case 4:
            if (!e) {
              _context38.next = 6;
              break;
            }

            return _context38.abrupt("return", (n.mpWeixinOpenid = e, {}));

          case 6:
            _context38.next = 8;
            return new Promise(function (e, t) {
              On.login({
                success: function success(t) {
                  e(t.code);
                },
                fail: function fail(e) {
                  t(new Error(e.errMsg));
                }
              });
            });

          case 8:
            r = _context38.sent;
            o = this.importObject("uni-id-co", {
              customUI: !0
            });
            _context38.next = 12;
            return o.secureNetworkHandshakeByWeixin({
              code: r,
              callLoginByWeixin: t
            });

          case 12:
            n.mpWeixinCode = r;
            return _context38.abrupt("return", {
              code: r
            });

          case 14:
          case "end":
            return _context38.stop();
        }
      }
    }, _callee38, this);
  }));
  return _Ul.apply(this, arguments);
}function Fl(_x31) {
  return _Fl.apply(this, arguments);
}function _Fl() {
  _Fl = _asyncToGenerator2( /*#__PURE__*/_regenerator.default.mark(function _callee39(e) {
    var t;
    return _regenerator.default.wrap(function _callee39$(_context39) {
      while (1) {
        switch (_context39.prev = _context39.next) {
          case 0:
            t = Dl(this);
            return _context39.abrupt("return", (t.initPromise || (t.initPromise = Ul.call(this, e)), t.initPromise));

          case 2:
          case "end":
            return _context39.stop();
        }
      }
    }, _callee39, this);
  }));
  return _Fl.apply(this, arguments);
}function ql(e) {
  var t = {
    getSystemInfo: On.getSystemInfo,
    getPushClientId: On.getPushClientId
  };
  return function (n) {
    return new Promise(function (r, o) {
      t[e](_objectSpread2(_objectSpread2({}, n), {}, {
        success: function success(e) {
          r(e);
        },
        fail: function fail(e) {
          o(e);
        }
      }));
    });
  };
}var Bl = /*#__PURE__*/function (_ref66) {
  _inherits2(Bl, _ref66);

  var _super10 = _createSuper2(Bl);

  function Bl() {
    var _this21;

    _classCallCheck2(this, Bl);

    _this21 = _super10.call(this), _this21._uniPushMessageCallback = _this21._receivePushMessage.bind(_assertThisInitialized2(_this21)), _this21._currentMessageId = -1, _this21._payloadQueue = [];
    return _this21;
  }

  _createClass2(Bl, [{
    key: "init",
    value: function init() {
      var _this22 = this;

      return Promise.all([ql("getSystemInfo")(), ql("getPushClientId")()]).then(function () {
        var _ref67 = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : [],
            _ref68 = _slicedToArray2(_ref67, 2),
            _ref68$ = _ref68[0];

        _ref68$ = _ref68$ === void 0 ? {} : _ref68$;
        var e = _ref68$.appId,
            _ref68$2 = _ref68[1];
        _ref68$2 = _ref68$2 === void 0 ? {} : _ref68$2;
        var t = _ref68$2.cid;
        if (!e) throw new Error("Invalid appId, please check the manifest.json file");
        if (!t) throw new Error("Invalid push client id");
        _this22._appId = e, _this22._pushClientId = t, _this22._seqId = Date.now() + "-" + Math.floor(9e5 * Math.random() + 1e5), _this22.emit("open"), _this22._initMessageListener();
      }, function (e) {
        throw _this22.emit("error", e), _this22.close(), e;
      });
    }
  }, {
    key: "open",
    value: function () {
      var _open = _asyncToGenerator2( /*#__PURE__*/_regenerator.default.mark(function _callee34() {
        return _regenerator.default.wrap(function _callee34$(_context34) {
          while (1) {
            switch (_context34.prev = _context34.next) {
              case 0:
                return _context34.abrupt("return", this.init());

              case 1:
              case "end":
                return _context34.stop();
            }
          }
        }, _callee34, this);
      }));

      function open() {
        return _open.apply(this, arguments);
      }

      return open;
    }()
  }, {
    key: "_isUniCloudSSE",
    value: function _isUniCloudSSE(e) {
      if ("receive" !== e.type) return !1;
      var t = e && e.data && e.data.payload;
      return !(!t || "UNI_CLOUD_SSE" !== t.channel || t.seqId !== this._seqId);
    }
  }, {
    key: "_receivePushMessage",
    value: function _receivePushMessage(e) {
      if (!this._isUniCloudSSE(e)) return;
      var t = e && e.data && e.data.payload,
          n = t.action,
          r = t.messageId,
          o = t.message;
      this._payloadQueue.push({
        action: n,
        messageId: r,
        message: o
      }), this._consumMessage();
    }
  }, {
    key: "_consumMessage",
    value: function _consumMessage() {
      var _this23 = this;

      for (;;) {
        var e = this._payloadQueue.find(function (e) {
          return e.messageId === _this23._currentMessageId + 1;
        });

        if (!e) break;
        this._currentMessageId++, this._parseMessagePayload(e);
      }
    }
  }, {
    key: "_parseMessagePayload",
    value: function _parseMessagePayload(e) {
      var t = e.action,
          n = e.messageId,
          r = e.message;
      "end" === t ? this._end({
        messageId: n,
        message: r
      }) : "message" === t && this._appendMessage({
        messageId: n,
        message: r
      });
    }
  }, {
    key: "_appendMessage",
    value: function _appendMessage() {
      var _ref69 = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {},
          e = _ref69.messageId,
          t = _ref69.message;

      this.emit("message", t);
    }
  }, {
    key: "_end",
    value: function _end() {
      var _ref70 = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {},
          e = _ref70.messageId,
          t = _ref70.message;

      this.emit("end", t), this.close();
    }
  }, {
    key: "_initMessageListener",
    value: function _initMessageListener() {
      On.onPushMessage(this._uniPushMessageCallback);
    }
  }, {
    key: "_destroy",
    value: function _destroy() {
      On.offPushMessage(this._uniPushMessageCallback);
    }
  }, {
    key: "toJSON",
    value: function toJSON() {
      return {
        appId: this._appId,
        pushClientId: this._pushClientId,
        seqId: this._seqId
      };
    }
  }, {
    key: "close",
    value: function close() {
      this._destroy(), this.emit("close");
    }
  }]);

  return Bl;
}( /*#__PURE__*/function () {
  function _class5() {
    _classCallCheck2(this, _class5);

    this._callback = {};
  }

  _createClass2(_class5, [{
    key: "addListener",
    value: function addListener(e, t) {
      this._callback[e] || (this._callback[e] = []), this._callback[e].push(t);
    }
  }, {
    key: "on",
    value: function on(e, t) {
      return this.addListener(e, t);
    }
  }, {
    key: "removeListener",
    value: function removeListener(e, t) {
      if (!t) throw new Error('The "listener" argument must be of type function. Received undefined');
      var n = this._callback[e];
      if (!n) return;

      var r = function (e, t) {
        for (var _n46 = e.length - 1; _n46 >= 0; _n46--) {
          if (e[_n46] === t) return _n46;
        }

        return -1;
      }(n, t);

      n.splice(r, 1);
    }
  }, {
    key: "off",
    value: function off(e, t) {
      return this.removeListener(e, t);
    }
  }, {
    key: "removeAllListener",
    value: function removeAllListener(e) {
      delete this._callback[e];
    }
  }, {
    key: "emit",
    value: function emit(e) {
      var n = this._callback[e];

      for (var _len15 = arguments.length, t = new Array(_len15 > 1 ? _len15 - 1 : 0), _key15 = 1; _key15 < _len15; _key15++) {
        t[_key15 - 1] = arguments[_key15];
      }

      if (n) for (var _r42 = 0; _r42 < n.length; _r42++) {
        n[_r42].apply(n, t);
      }
    }
  }]);

  return _class5;
}());var Hl = {
  tcb: Ru,
  tencent: Ru,
  aliyun: Tc,
  private: ju
};var Kl = new ( /*#__PURE__*/function () {
  function _class6() {
    _classCallCheck2(this, _class6);
  }

  _createClass2(_class6, [{
    key: "init",
    value: function init(e) {
      var t = {};
      var n = Hl[e.provider];
      if (!n) throw new Error("未提供正确的provider参数");
      var r;
      return t = n.init(e), function (e) {
        e._initPromiseHub || (e._initPromiseHub = new ja({
          createPromise: function createPromise() {
            var t = Promise.resolve();
            t = new Promise(function (e) {
              setTimeout(function () {
                e();
              }, 1);
            });
            var n = e.auth();
            return t.then(function () {
              return n.getLoginState();
            }).then(function (e) {
              return e ? Promise.resolve() : n.signInAnonymously();
            });
          }
        }));
      }(t), Gu(t), function (e) {
        var t = e.uploadFile;

        e.uploadFile = function (e) {
          return t.call(this, e);
        };
      }(t), (r = t).database = function (e) {
        if (e && Object.keys(e).length > 0) return r.init(e).database();
        if (this._database) return this._database;
        var t = il(al, {
          uniClient: r
        });
        return this._database = t, t;
      }, r.databaseForJQL = function (e) {
        if (e && Object.keys(e).length > 0) return r.init(e).databaseForJQL();
        if (this._databaseForJQL) return this._databaseForJQL;
        var t = il(al, {
          uniClient: r,
          isJQL: !0
        });
        return this._databaseForJQL = t, t;
      }, function (e) {
        e.getCurrentUserInfo = Rl, e.chooseAndUploadFile = Nl.initChooseAndUploadFile(e), Object.assign(e, {
          get mixinDatacom() {
            return jl(e);
          }

        }), e.SSEChannel = Bl, e.initSecureNetworkByWeixin = function (e) {
          return function () {
            var _ref71 = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {},
                t = _ref71.openid,
                _ref71$callLoginByWei = _ref71.callLoginByWeixin,
                n = _ref71$callLoginByWei === void 0 ? !1 : _ref71$callLoginByWei;

            return Fl.call(e, {
              openid: t,
              callLoginByWeixin: n
            });
          };
        }(e), e.importObject = function (t) {
          return function (n) {
            var r = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : {};

            r = function (e) {
              var t = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : {};
              return e.customUI = t.customUI || e.customUI, e.parseSystemError = t.parseSystemError || e.parseSystemError, Object.assign(e.loadingOptions, t.loadingOptions), Object.assign(e.errorOptions, t.errorOptions), "object" == _typeof2(t.secretMethods) && (e.secretMethods = t.secretMethods), e;
            }({
              customUI: !1,
              loadingOptions: {
                title: "加载中...",
                mask: !0
              },
              errorOptions: {
                type: "modal",
                retry: !1
              }
            }, r);

            var _r43 = r,
                o = _r43.customUI,
                s = _r43.loadingOptions,
                i = _r43.errorOptions,
                a = _r43.parseSystemError,
                c = !o;
            return new Proxy({}, {
              get: function get(o, u) {
                return function () {
                  var _ref72 = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {},
                      e = _ref72.fn,
                      t = _ref72.interceptorName,
                      n = _ref72.getCallbackArgs;

                  return /*#__PURE__*/_asyncToGenerator2( /*#__PURE__*/_regenerator.default.mark(function _callee35() {
                    var _len16,
                        r,
                        _key16,
                        o,
                        s,
                        i,
                        _args35 = arguments;

                    return _regenerator.default.wrap(function _callee35$(_context35) {
                      while (1) {
                        switch (_context35.prev = _context35.next) {
                          case 0:
                            for (_len16 = _args35.length, r = new Array(_len16), _key16 = 0; _key16 < _len16; _key16++) {
                              r[_key16] = _args35[_key16];
                            }

                            o = n ? n({
                              params: r
                            }) : {};
                            _context35.prev = 2;
                            _context35.next = 5;
                            return Ga(Ya(t, "invoke"), _objectSpread2({}, o));

                          case 5:
                            _context35.next = 7;
                            return e.apply(void 0, r);

                          case 7:
                            s = _context35.sent;
                            _context35.next = 10;
                            return Ga(Ya(t, "success"), _objectSpread2(_objectSpread2({}, o), {}, {
                              result: s
                            }));

                          case 10:
                            return _context35.abrupt("return", s);

                          case 13:
                            _context35.prev = 13;
                            _context35.t0 = _context35["catch"](2);
                            i = _context35.t0;
                            _context35.next = 18;
                            return Ga(Ya(t, "fail"), _objectSpread2(_objectSpread2({}, o), {}, {
                              error: i
                            }));

                          case 18:
                            throw i;

                          case 19:
                            _context35.prev = 19;
                            _context35.next = 22;
                            return Ga(Ya(t, "complete"), i ? _objectSpread2(_objectSpread2({}, o), {}, {
                              error: i
                            }) : _objectSpread2(_objectSpread2({}, o), {}, {
                              result: s
                            }));

                          case 22:
                            return _context35.finish(19);

                          case 23:
                          case "end":
                            return _context35.stop();
                        }
                      }
                    }, _callee35, null, [[2, 13, 19, 23]]);
                  }));
                }({
                  fn: function () {
                    var _o30 = _asyncToGenerator2( /*#__PURE__*/_regenerator.default.mark(function _callee37() {
                      var f,
                          _len17,
                          l,
                          _key17,
                          h,
                          d,
                          _ref74,
                          p,
                          g,
                          m,
                          y,
                          _e55,
                          _yield,
                          _t47,
                          _t46,
                          _args37 = arguments;

                      return _regenerator.default.wrap(function _callee37$(_context37) {
                        while (1) {
                          switch (_context37.prev = _context37.next) {
                            case 0:
                              c && On.showLoading({
                                title: s.title,
                                mask: s.mask
                              });

                              for (_len17 = _args37.length, l = new Array(_len17), _key17 = 0; _key17 < _len17; _key17++) {
                                l[_key17] = _args37[_key17];
                              }

                              h = {
                                name: n,
                                type: "OBJECT",
                                data: {
                                  method: u,
                                  params: l
                                }
                              };
                              "object" == _typeof2(r.secretMethods) && function (e, t) {
                                var n = t.data.method,
                                    r = e.secretMethods || {},
                                    o = r[n] || r["*"];
                                o && (t.secretType = o);
                              }(r, h);
                              d = !1;
                              _context37.prev = 5;
                              _context37.next = 8;
                              return t.callFunction(h);

                            case 8:
                              f = _context37.sent;
                              _context37.next = 14;
                              break;

                            case 11:
                              _context37.prev = 11;
                              _context37.t0 = _context37["catch"](5);
                              d = !0, f = {
                                result: new dc(_context37.t0)
                              };

                            case 14:
                              _ref74 = f.result || {}, p = _ref74.errSubject, g = _ref74.errCode, m = _ref74.errMsg, y = _ref74.newToken;

                              if (!(c && On.hideLoading(), y && y.token && y.tokenExpired && (yc(y), cc(tc, _objectSpread2({}, y))), g)) {
                                _context37.next = 40;
                                break;
                              }

                              _e55 = m;
                              _context37.t1 = d && a;

                              if (!_context37.t1) {
                                _context37.next = 25;
                                break;
                              }

                              _context37.next = 21;
                              return a({
                                objectName: n,
                                methodName: u,
                                params: l,
                                errSubject: p,
                                errCode: g,
                                errMsg: m
                              });

                            case 21:
                              _context37.t2 = _context37.sent.errMsg;

                              if (_context37.t2) {
                                _context37.next = 24;
                                break;
                              }

                              _context37.t2 = m;

                            case 24:
                              _e55 = _context37.t2;

                            case 25:
                              if (!c) {
                                _context37.next = 38;
                                break;
                              }

                              if (!("toast" === i.type)) {
                                _context37.next = 30;
                                break;
                              }

                              On.showToast({
                                title: _e55,
                                icon: "none"
                              });
                              _context37.next = 38;
                              break;

                            case 30:
                              if (!("modal" !== i.type)) {
                                _context37.next = 32;
                                break;
                              }

                              throw new Error("Invalid errorOptions.type: ".concat(i.type));

                            case 32:
                              _context37.next = 34;
                              return _asyncToGenerator2( /*#__PURE__*/_regenerator.default.mark(function _callee36() {
                                var _ref76,
                                    e,
                                    t,
                                    n,
                                    r,
                                    o,
                                    _args36 = arguments;

                                return _regenerator.default.wrap(function _callee36$(_context36) {
                                  while (1) {
                                    switch (_context36.prev = _context36.next) {
                                      case 0:
                                        _ref76 = _args36.length > 0 && _args36[0] !== undefined ? _args36[0] : {}, e = _ref76.title, t = _ref76.content, n = _ref76.showCancel, r = _ref76.cancelText, o = _ref76.confirmText;
                                        return _context36.abrupt("return", new Promise(function (s, i) {
                                          On.showModal({
                                            title: e,
                                            content: t,
                                            showCancel: n,
                                            cancelText: r,
                                            confirmText: o,
                                            success: function success(e) {
                                              s(e);
                                            },
                                            fail: function fail() {
                                              s({
                                                confirm: !1,
                                                cancel: !0
                                              });
                                            }
                                          });
                                        }));

                                      case 2:
                                      case "end":
                                        return _context36.stop();
                                    }
                                  }
                                }, _callee36);
                              }))({
                                title: "提示",
                                content: _e55,
                                showCancel: i.retry,
                                cancelText: "取消",
                                confirmText: i.retry ? "重试" : "确定"
                              });

                            case 34:
                              _yield = _context37.sent;
                              _t47 = _yield.confirm;

                              if (!(i.retry && _t47)) {
                                _context37.next = 38;
                                break;
                              }

                              return _context37.abrupt("return", o.apply(void 0, l));

                            case 38:
                              _t46 = new dc({
                                subject: p,
                                code: g,
                                message: m,
                                requestId: f.requestId
                              });
                              throw _t46.detail = f.result, cc(Za, {
                                type: oc,
                                content: _t46
                              }), _t46;

                            case 40:
                              return _context37.abrupt("return", (cc(Za, {
                                type: oc,
                                content: f.result
                              }), f.result));

                            case 41:
                            case "end":
                              return _context37.stop();
                          }
                        }
                      }, _callee37, null, [[5, 11]]);
                    }));

                    function o() {
                      return _o30.apply(this, arguments);
                    }

                    return o;
                  }(),
                  interceptorName: "callObject",
                  getCallbackArgs: function getCallbackArgs() {
                    var _ref77 = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {},
                        e = _ref77.params;

                    return {
                      objectName: n,
                      methodName: u,
                      params: e
                    };
                  }
                });
              }
            });
          };
        }(e);
      }(t), ["callFunction", "uploadFile", "deleteFile", "getTempFileURL", "downloadFile", "chooseAndUploadFile"].forEach(function (e) {
        if (!t[e]) return;
        var n = t[e];
        var r, o;
        t[e] = function () {
          return n.apply(t, Array.from(arguments));
        }, t[e] = (r = t[e], o = e, function (e) {
          var _this24 = this;

          var t = !1;

          if ("callFunction" === o) {
            var _n47 = e && e.type || Ia;

            t = _n47 !== Ia;
          }

          var n = "callFunction" === o && !t,
              s = this._initPromiseHub.exec();

          e = e || {};

          var _hc2 = hc(e),
              i = _hc2.success,
              a = _hc2.fail,
              c = _hc2.complete,
              u = s.then(function () {
            return t ? Promise.resolve() : Ga(Ya(o, "invoke"), e);
          }).then(function () {
            return r.call(_this24, e);
          }).then(function (e) {
            return t ? Promise.resolve(e) : Ga(Ya(o, "success"), e).then(function () {
              return Ga(Ya(o, "complete"), e);
            }).then(function () {
              return n && cc(Za, {
                type: rc,
                content: e
              }), Promise.resolve(e);
            });
          }, function (e) {
            return t ? Promise.reject(e) : Ga(Ya(o, "fail"), e).then(function () {
              return Ga(Ya(o, "complete"), e);
            }).then(function () {
              return cc(Za, {
                type: rc,
                content: e
              }), Promise.reject(e);
            });
          });

          if (!(i || a || c)) return u;
          u.then(function (e) {
            i && i(e), c && c(e), n && cc(Za, {
              type: rc,
              content: e
            });
          }, function (e) {
            a && a(e), c && c(e), n && cc(Za, {
              type: rc,
              content: e
            });
          });
        }).bind(t);
      }), t.init = this.init, t;
    }
  }]);

  return _class6;
}())();(function () {
  var e = qa;
  var t = {};
  if (e && 1 === e.length) t = e[0], Kl = Kl.init(t), Kl._isDefault = !0;else {
    var _t48 = ["auth", "callFunction", "uploadFile", "deleteFile", "getTempFileURL", "downloadFile", "database", "getCurrentUSerInfo", "importObject"];

    var _n48;

    _n48 = e && e.length > 0 ? "应用有多个服务空间，请通过uniCloud.init方法指定要使用的服务空间" : "应用未关联服务空间，请在uniCloud目录右键关联服务空间", _t48.forEach(function (e) {
      Kl[e] = function () {
        return console.error(_n48), Promise.reject(new dc({
          code: "SYS_ERR",
          message: _n48
        }));
      };
    });
  }
  Object.assign(Kl, {
    get mixinDatacom() {
      return jl(Kl);
    }

  }), El(Kl), Kl.addInterceptor = za, Kl.removeInterceptor = Ja, Kl.interceptObject = Qa;
})();var Vl = Kl;function Wl(e, t) {
  Object.keys(e).forEach(function (n) {
    return t(e[n], n);
  });
}function zl(e) {
  return null !== e && "object" == _typeof2(e);
}function Jl(e, t, n) {
  return t.indexOf(e) < 0 && (n && n.prepend ? t.unshift(e) : t.push(e)), function () {
    var n = t.indexOf(e);
    n > -1 && t.splice(n, 1);
  };
}function Gl(e, t) {
  e._actions = Object.create(null), e._mutations = Object.create(null), e._wrappedGetters = Object.create(null), e._modulesNamespaceMap = Object.create(null);
  var n = e.state;
  Ql(e, n, [], e._modules.root, !0), Yl(e, n, t);
}function Yl(e, t, n) {
  var r = e._state,
      o = e._scope;
  e.getters = {}, e._makeLocalGettersCache = Object.create(null);
  var s = e._wrappedGetters,
      i = {},
      a = {},
      c = new Tn(!0);
  c.run(function () {
    Wl(s, function (t, n) {
      i[n] = function (e, t) {
        return function () {
          return e(t);
        };
      }(t, e), a[n] = Fs(function () {
        return i[n]();
      }), Object.defineProperty(e.getters, n, {
        get: function get() {
          return a[n].value;
        },
        enumerable: !0
      });
    });
  }), e._state = Rr({
    data: t
  }), e._scope = c, e.strict && function (e) {
    Mo(function () {
      return e._state.data;
    }, function () {}, {
      deep: !0,
      flush: "sync"
    });
  }(e), r && n && e._withCommit(function () {
    r.data = null;
  }), o && o.stop();
}function Ql(e, t, n, r, o) {
  var s = !n.length,
      i = e._modules.getNamespace(n);

  if (r.namespaced && (e._modulesNamespaceMap[i], e._modulesNamespaceMap[i] = r), !s && !o) {
    var a = Xl(t, n.slice(0, -1)),
        c = n[n.length - 1];

    e._withCommit(function () {
      a[c] = r.state;
    });
  }

  var u = r.context = function (e, t, n) {
    var r = "" === t,
        o = {
      dispatch: r ? e.dispatch : function (n, r, o) {
        var s = Zl(n, r, o),
            i = s.payload,
            a = s.options,
            c = s.type;
        return a && a.root || (c = t + c), e.dispatch(c, i);
      },
      commit: r ? e.commit : function (n, r, o) {
        var s = Zl(n, r, o),
            i = s.payload,
            a = s.options,
            c = s.type;
        a && a.root || (c = t + c), e.commit(c, i, a);
      }
    };
    return Object.defineProperties(o, {
      getters: {
        get: r ? function () {
          return e.getters;
        } : function () {
          return function (e, t) {
            if (!e._makeLocalGettersCache[t]) {
              var n = {},
                  r = t.length;
              Object.keys(e.getters).forEach(function (o) {
                if (o.slice(0, r) === t) {
                  var s = o.slice(r);
                  Object.defineProperty(n, s, {
                    get: function get() {
                      return e.getters[o];
                    },
                    enumerable: !0
                  });
                }
              }), e._makeLocalGettersCache[t] = n;
            }

            return e._makeLocalGettersCache[t];
          }(e, t);
        }
      },
      state: {
        get: function get() {
          return Xl(e.state, n);
        }
      }
    }), o;
  }(e, i, n);

  r.forEachMutation(function (t, n) {
    !function (e, t, n, r) {
      var o = e._mutations[t] || (e._mutations[t] = []);
      o.push(function (t) {
        n.call(e, r.state, t);
      });
    }(e, i + n, t, u);
  }), r.forEachAction(function (t, n) {
    var r = t.root ? n : i + n,
        o = t.handler || t;
    !function (e, t, n, r) {
      var o = e._actions[t] || (e._actions[t] = []);
      o.push(function (t) {
        var o,
            s = n.call(e, {
          dispatch: r.dispatch,
          commit: r.commit,
          getters: r.getters,
          state: r.state,
          rootGetters: e.getters,
          rootState: e.state
        }, t);
        return (o = s) && "function" == typeof o.then || (s = Promise.resolve(s)), e._devtoolHook ? s.catch(function (t) {
          throw e._devtoolHook.emit("vuex:error", t), t;
        }) : s;
      });
    }(e, r, o, u);
  }), r.forEachGetter(function (t, n) {
    !function (e, t, n, r) {
      if (e._wrappedGetters[t]) return;

      e._wrappedGetters[t] = function (e) {
        return n(r.state, r.getters, e.state, e.getters);
      };
    }(e, i + n, t, u);
  }), r.forEachChild(function (r, s) {
    Ql(e, t, n.concat(s), r, o);
  });
}function Xl(e, t) {
  return t.reduce(function (e, t) {
    return e[t];
  }, e);
}function Zl(e, t, n) {
  return zl(e) && e.type && (n = t, t = e, e = e.type), {
    type: e,
    payload: t,
    options: n
  };
}var ef = function ef(e, t) {
  this.runtime = t, this._children = Object.create(null), this._rawModule = e;
  var n = e.state;
  this.state = ("function" == typeof n ? n() : n) || {};
},
    tf = {
  namespaced: {
    configurable: !0
  }
};tf.namespaced.get = function () {
  return !!this._rawModule.namespaced;
}, ef.prototype.addChild = function (e, t) {
  this._children[e] = t;
}, ef.prototype.removeChild = function (e) {
  delete this._children[e];
}, ef.prototype.getChild = function (e) {
  return this._children[e];
}, ef.prototype.hasChild = function (e) {
  return e in this._children;
}, ef.prototype.update = function (e) {
  this._rawModule.namespaced = e.namespaced, e.actions && (this._rawModule.actions = e.actions), e.mutations && (this._rawModule.mutations = e.mutations), e.getters && (this._rawModule.getters = e.getters);
}, ef.prototype.forEachChild = function (e) {
  Wl(this._children, e);
}, ef.prototype.forEachGetter = function (e) {
  this._rawModule.getters && Wl(this._rawModule.getters, e);
}, ef.prototype.forEachAction = function (e) {
  this._rawModule.actions && Wl(this._rawModule.actions, e);
}, ef.prototype.forEachMutation = function (e) {
  this._rawModule.mutations && Wl(this._rawModule.mutations, e);
}, Object.defineProperties(ef.prototype, tf);var nf = function nf(e) {
  this.register([], e, !1);
};function rf(e, t, n) {
  if (t.update(n), n.modules) for (var r in n.modules) {
    if (!t.getChild(r)) return;
    rf(e.concat(r), t.getChild(r), n.modules[r]);
  }
}nf.prototype.get = function (e) {
  return e.reduce(function (e, t) {
    return e.getChild(t);
  }, this.root);
}, nf.prototype.getNamespace = function (e) {
  var t = this.root;
  return e.reduce(function (e, n) {
    return e + ((t = t.getChild(n)).namespaced ? n + "/" : "");
  }, "");
}, nf.prototype.update = function (e) {
  rf([], this.root, e);
}, nf.prototype.register = function (e, t, n) {
  var r = this;
  void 0 === n && (n = !0);
  var o = new ef(t, n);
  0 === e.length ? this.root = o : this.get(e.slice(0, -1)).addChild(e[e.length - 1], o);
  t.modules && Wl(t.modules, function (t, o) {
    r.register(e.concat(o), t, n);
  });
}, nf.prototype.unregister = function (e) {
  var t = this.get(e.slice(0, -1)),
      n = e[e.length - 1],
      r = t.getChild(n);
  r && r.runtime && t.removeChild(n);
}, nf.prototype.isRegistered = function (e) {
  var t = this.get(e.slice(0, -1)),
      n = e[e.length - 1];
  return !!t && t.hasChild(n);
};var of = function of(e) {
  var t = this;
  void 0 === e && (e = {});
  var n = e.plugins;
  void 0 === n && (n = []);
  var r = e.strict;
  void 0 === r && (r = !1);
  var o = e.devtools;
  this._committing = !1, this._actions = Object.create(null), this._actionSubscribers = [], this._mutations = Object.create(null), this._wrappedGetters = Object.create(null), this._modules = new nf(e), this._modulesNamespaceMap = Object.create(null), this._subscribers = [], this._makeLocalGettersCache = Object.create(null), this._scope = null, this._devtools = o;
  var s = this,
      i = this.dispatch,
      a = this.commit;
  this.dispatch = function (e, t) {
    return i.call(s, e, t);
  }, this.commit = function (e, t, n) {
    return a.call(s, e, t, n);
  }, this.strict = r;
  var c = this._modules.root.state;
  Ql(this, c, [], this._modules.root), Yl(this, c), n.forEach(function (e) {
    return e(t);
  });
},
    sf = {
  state: {
    configurable: !0
  }
};of.prototype.install = function (e, t) {
  e.provide(t || "store", this), e.config.globalProperties.$store = this, void 0 !== this._devtools && this._devtools;
}, sf.state.get = function () {
  return this._state.data;
}, sf.state.set = function (e) {}, of.prototype.commit = function (e, t, n) {
  var r = this,
      o = Zl(e, t, n),
      s = o.type,
      i = o.payload,
      a = {
    type: s,
    payload: i
  },
      c = this._mutations[s];
  c && (this._withCommit(function () {
    c.forEach(function (e) {
      e(i);
    });
  }), this._subscribers.slice().forEach(function (e) {
    return e(a, r.state);
  }));
}, of.prototype.dispatch = function (e, t) {
  var n = this,
      r = Zl(e, t),
      o = r.type,
      s = r.payload,
      i = {
    type: o,
    payload: s
  },
      a = this._actions[o];

  if (a) {
    try {
      this._actionSubscribers.slice().filter(function (e) {
        return e.before;
      }).forEach(function (e) {
        return e.before(i, n.state);
      });
    } catch (Mc) {}

    var c = a.length > 1 ? Promise.all(a.map(function (e) {
      return e(s);
    })) : a[0](s);
    return new Promise(function (e, t) {
      c.then(function (t) {
        try {
          n._actionSubscribers.filter(function (e) {
            return e.after;
          }).forEach(function (e) {
            return e.after(i, n.state);
          });
        } catch (Mc) {}

        e(t);
      }, function (e) {
        try {
          n._actionSubscribers.filter(function (e) {
            return e.error;
          }).forEach(function (t) {
            return t.error(i, n.state, e);
          });
        } catch (Mc) {}

        t(e);
      });
    });
  }
}, of.prototype.subscribe = function (e, t) {
  return Jl(e, this._subscribers, t);
}, of.prototype.subscribeAction = function (e, t) {
  return Jl("function" == typeof e ? {
    before: e
  } : e, this._actionSubscribers, t);
}, of.prototype.watch = function (e, t, n) {
  var r = this;
  return Mo(function () {
    return e(r.state, r.getters);
  }, t, Object.assign({}, n));
}, of.prototype.replaceState = function (e) {
  var t = this;

  this._withCommit(function () {
    t._state.data = e;
  });
}, of.prototype.registerModule = function (e, t, n) {
  void 0 === n && (n = {}), "string" == typeof e && (e = [e]), this._modules.register(e, t), Ql(this, this.state, e, this._modules.get(e), n.preserveState), Yl(this, this.state);
}, of.prototype.unregisterModule = function (e) {
  var t = this;
  "string" == typeof e && (e = [e]), this._modules.unregister(e), this._withCommit(function () {
    delete Xl(t.state, e.slice(0, -1))[e[e.length - 1]];
  }), Gl(this);
}, of.prototype.hasModule = function (e) {
  return "string" == typeof e && (e = [e]), this._modules.isRegistered(e);
}, of.prototype.hotUpdate = function (e) {
  this._modules.update(e), Gl(this, !0);
}, of.prototype._withCommit = function (e) {
  var t = this._committing;
  this._committing = !0, e(), this._committing = t;
}, Object.defineProperties(of.prototype, sf);var af = ff(function (e, t) {
  var n = {};
  return lf(t).forEach(function (t) {
    var r = t.key,
        o = t.val;
    n[r] = function () {
      var t = this.$store.state,
          n = this.$store.getters;

      if (e) {
        var r = hf(this.$store, "mapState", e);
        if (!r) return;
        t = r.context.state, n = r.context.getters;
      }

      return "function" == typeof o ? o.call(this, t, n) : t[o];
    }, n[r].vuex = !0;
  }), n;
}),
    cf = ff(function (e, t) {
  var n = {};
  return lf(t).forEach(function (t) {
    var r = t.key,
        o = t.val;

    n[r] = function () {
      for (var t = [], n = arguments.length; n--;) {
        t[n] = arguments[n];
      }

      var r = this.$store.commit;

      if (e) {
        var s = hf(this.$store, "mapMutations", e);
        if (!s) return;
        r = s.context.commit;
      }

      return "function" == typeof o ? o.apply(this, [r].concat(t)) : r.apply(this.$store, [o].concat(t));
    };
  }), n;
}),
    uf = ff(function (e, t) {
  var n = {};
  return lf(t).forEach(function (t) {
    var r = t.key,
        o = t.val;
    o = e + o, n[r] = function () {
      if (!e || hf(this.$store, "mapGetters", e)) return this.$store.getters[o];
    }, n[r].vuex = !0;
  }), n;
});function lf(e) {
  return function (e) {
    return Array.isArray(e) || zl(e);
  }(e) ? Array.isArray(e) ? e.map(function (e) {
    return {
      key: e,
      val: e
    };
  }) : Object.keys(e).map(function (t) {
    return {
      key: t,
      val: e[t]
    };
  }) : [];
}function ff(e) {
  return function (t, n) {
    return "string" != typeof t ? (n = t, t = "") : "/" !== t.charAt(t.length - 1) && (t += "/"), e(t, n);
  };
}function hf(e, t, n) {
  return e._modulesNamespaceMap[n];
}var df = function df(e, t) {
  var n = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : !1;
  var r = n ? function (e) {
    return Gr(e, !0);
  }(e) : Jr(e);
  if ("undefined" == typeof window) return r;
  var o = window.__uniSSR;
  if (!o) return r;
  var s = Ms() ? B : "globalData";
  return function (e) {
    var t = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : !1;
    if (!e) throw new Error((t ? "shallowSsrRef" : "ssrRef") + ": You must provide a key.");
  }(t, n), v(o[s], t) && (r.value = o[s][t], s === B && delete o[s][t]), r;
},
    pf = {
  en: {
    "uniCloud.component.add.success": "Success",
    "uniCloud.component.update.success": "Success",
    "uniCloud.component.remove.showModal.title": "Tips",
    "uniCloud.component.remove.showModal.content": "是否删除该数据"
  },
  es: {
    "uniCloud.component.add.success": "新增成功",
    "uniCloud.component.update.success": "修改成功",
    "uniCloud.component.remove.showModal.title": "提示",
    "uniCloud.component.remove.showModal.content": "是否删除该数据"
  },
  fr: {
    "uniCloud.component.add.success": "新增成功",
    "uniCloud.component.update.success": "修改成功",
    "uniCloud.component.remove.showModal.title": "提示",
    "uniCloud.component.remove.showModal.content": "是否删除该数据"
  },
  "zh-Hans": {
    "uniCloud.component.add.success": "新增成功",
    "uniCloud.component.update.success": "修改成功",
    "uniCloud.component.remove.showModal.title": "提示",
    "uniCloud.component.remove.showModal.content": "是否删除该数据"
  },
  "zh-Hant": {
    "uniCloud.component.add.success": "新增成功",
    "uniCloud.component.update.success": "修改成功",
    "uniCloud.component.remove.showModal.title": "提示",
    "uniCloud.component.remove.showModal.content": "是否刪除數據"
  }
};"undefined" != typeof globalThis ? globalThis : "undefined" != typeof window ? window : "undefined" != typeof global ? global : "undefined" != typeof self && self;var gf = {};({
  get exports() {
    return gf;
  },

  set exports(e) {
    gf = e;
  }

}).exports = function () {
  for (var e = function e(_e56, t, n) {
    return void 0 === t && (t = 0), void 0 === n && (n = 1), _e56 < t ? t : _e56 > n ? n : _e56;
  }, t = e, n = function n(e) {
    e._clipped = !1, e._unclipped = e.slice(0);

    for (var n = 0; n <= 3; n++) {
      n < 3 ? ((e[n] < 0 || e[n] > 255) && (e._clipped = !0), e[n] = t(e[n], 0, 255)) : 3 === n && (e[n] = t(e[n], 0, 1));
    }

    return e;
  }, r = {}, o = 0, s = ["Boolean", "Number", "String", "Function", "Array", "Date", "RegExp", "Undefined", "Null"]; o < s.length; o += 1) {
    var i = s[o];
    r["[object " + i + "]"] = i.toLowerCase();
  }

  var a = function a(e) {
    return r[Object.prototype.toString.call(e)] || "object";
  },
      c = a,
      u = function u(e, t) {
    return void 0 === t && (t = null), e.length >= 3 ? Array.prototype.slice.call(e) : "object" == c(e[0]) && t ? t.split("").filter(function (t) {
      return void 0 !== e[0][t];
    }).map(function (t) {
      return e[0][t];
    }) : e[0];
  },
      l = a,
      f = function f(e) {
    if (e.length < 2) return null;
    var t = e.length - 1;
    return "string" == l(e[t]) ? e[t].toLowerCase() : null;
  },
      h = Math.PI,
      d = {
    clip_rgb: n,
    limit: e,
    type: a,
    unpack: u,
    last: f,
    PI: h,
    TWOPI: 2 * h,
    PITHIRD: h / 3,
    DEG2RAD: h / 180,
    RAD2DEG: 180 / h
  },
      p = {
    format: {},
    autodetect: []
  },
      g = d.last,
      m = d.clip_rgb,
      y = d.type,
      v = p,
      b = function b() {
    for (var e = [], t = arguments.length; t--;) {
      e[t] = arguments[t];
    }

    var n = this;
    if ("object" === y(e[0]) && e[0].constructor && e[0].constructor === this.constructor) return e[0];
    var r = g(e),
        o = !1;

    if (!r) {
      o = !0, v.sorted || (v.autodetect = v.autodetect.sort(function (e, t) {
        return t.p - e.p;
      }), v.sorted = !0);

      for (var s = 0, i = v.autodetect; s < i.length; s += 1) {
        var a = i[s];
        if (r = a.test.apply(a, e)) break;
      }
    }

    if (!v.format[r]) throw new Error("unknown format: " + e);
    var c = v.format[r].apply(null, o ? e : e.slice(0, -1));
    n._rgb = m(c), 3 === n._rgb.length && n._rgb.push(1);
  };

  b.prototype.toString = function () {
    return "function" == y(this.hex) ? this.hex() : "[" + this._rgb.join(",") + "]";
  };

  var _ = b,
      w = function w() {
    for (var e = [], t = arguments.length; t--;) {
      e[t] = arguments[t];
    }

    return new (Function.prototype.bind.apply(w.Color, [null].concat(e)))();
  };

  w.Color = _, w.version = "2.4.2";

  var k = w,
      x = d.unpack,
      S = Math.max,
      P = function P() {
    for (var e = [], t = arguments.length; t--;) {
      e[t] = arguments[t];
    }

    var n = x(e, "rgb"),
        r = n[0],
        o = n[1],
        s = n[2],
        i = 1 - S(r /= 255, S(o /= 255, s /= 255)),
        a = i < 1 ? 1 / (1 - i) : 0;
    return [(1 - r - i) * a, (1 - o - i) * a, (1 - s - i) * a, i];
  },
      A = P,
      O = d.unpack,
      I = function I() {
    for (var e = [], t = arguments.length; t--;) {
      e[t] = arguments[t];
    }

    var n = (e = O(e, "cmyk"))[0],
        r = e[1],
        o = e[2],
        s = e[3],
        i = e.length > 4 ? e[4] : 1;
    return 1 === s ? [0, 0, 0, i] : [n >= 1 ? 0 : 255 * (1 - n) * (1 - s), r >= 1 ? 0 : 255 * (1 - r) * (1 - s), o >= 1 ? 0 : 255 * (1 - o) * (1 - s), i];
  },
      T = I,
      C = k,
      E = _,
      M = p,
      L = d.unpack,
      $ = d.type,
      R = A;

  E.prototype.cmyk = function () {
    return R(this._rgb);
  }, C.cmyk = function () {
    for (var e = [], t = arguments.length; t--;) {
      e[t] = arguments[t];
    }

    return new (Function.prototype.bind.apply(E, [null].concat(e, ["cmyk"])))();
  }, M.format.cmyk = T, M.autodetect.push({
    p: 2,
    test: function test() {
      for (var e = [], t = arguments.length; t--;) {
        e[t] = arguments[t];
      }

      if (e = L(e, "cmyk"), "array" === $(e) && 4 === e.length) return "cmyk";
    }
  });

  var N = d.unpack,
      j = d.last,
      D = function D(e) {
    return Math.round(100 * e) / 100;
  },
      U = function U() {
    for (var e = [], t = arguments.length; t--;) {
      e[t] = arguments[t];
    }

    var n = N(e, "hsla"),
        r = j(e) || "lsa";
    return n[0] = D(n[0] || 0), n[1] = D(100 * n[1]) + "%", n[2] = D(100 * n[2]) + "%", "hsla" === r || n.length > 3 && n[3] < 1 ? (n[3] = n.length > 3 ? n[3] : 1, r = "hsla") : n.length = 3, r + "(" + n.join(",") + ")";
  },
      F = U,
      q = d.unpack,
      B = function B() {
    for (var e = [], t = arguments.length; t--;) {
      e[t] = arguments[t];
    }

    var n = (e = q(e, "rgba"))[0],
        r = e[1],
        o = e[2];
    n /= 255, r /= 255, o /= 255;
    var s,
        i,
        a = Math.min(n, r, o),
        c = Math.max(n, r, o),
        u = (c + a) / 2;
    return c === a ? (s = 0, i = Number.NaN) : s = u < .5 ? (c - a) / (c + a) : (c - a) / (2 - c - a), n == c ? i = (r - o) / (c - a) : r == c ? i = 2 + (o - n) / (c - a) : o == c && (i = 4 + (n - r) / (c - a)), (i *= 60) < 0 && (i += 360), e.length > 3 && void 0 !== e[3] ? [i, s, u, e[3]] : [i, s, u];
  },
      H = B,
      K = d.unpack,
      V = d.last,
      W = F,
      z = H,
      J = Math.round,
      G = function G() {
    for (var e = [], t = arguments.length; t--;) {
      e[t] = arguments[t];
    }

    var n = K(e, "rgba"),
        r = V(e) || "rgb";
    return "hsl" == r.substr(0, 3) ? W(z(n), r) : (n[0] = J(n[0]), n[1] = J(n[1]), n[2] = J(n[2]), ("rgba" === r || n.length > 3 && n[3] < 1) && (n[3] = n.length > 3 ? n[3] : 1, r = "rgba"), r + "(" + n.slice(0, "rgb" === r ? 3 : 4).join(",") + ")");
  },
      Y = G,
      Q = d.unpack,
      X = Math.round,
      Z = function Z() {
    for (var e, t = [], n = arguments.length; n--;) {
      t[n] = arguments[n];
    }

    var r,
        o,
        s,
        i = (t = Q(t, "hsl"))[0],
        a = t[1],
        c = t[2];
    if (0 === a) r = o = s = 255 * c;else {
      var u = [0, 0, 0],
          l = [0, 0, 0],
          f = c < .5 ? c * (1 + a) : c + a - c * a,
          h = 2 * c - f,
          d = i / 360;
      u[0] = d + 1 / 3, u[1] = d, u[2] = d - 1 / 3;

      for (var p = 0; p < 3; p++) {
        u[p] < 0 && (u[p] += 1), u[p] > 1 && (u[p] -= 1), 6 * u[p] < 1 ? l[p] = h + 6 * (f - h) * u[p] : 2 * u[p] < 1 ? l[p] = f : 3 * u[p] < 2 ? l[p] = h + (f - h) * (2 / 3 - u[p]) * 6 : l[p] = h;
      }

      r = (e = [X(255 * l[0]), X(255 * l[1]), X(255 * l[2])])[0], o = e[1], s = e[2];
    }
    return t.length > 3 ? [r, o, s, t[3]] : [r, o, s, 1];
  },
      ee = Z,
      te = ee,
      ne = p,
      re = /^rgb\(\s*(-?\d+),\s*(-?\d+)\s*,\s*(-?\d+)\s*\)$/,
      oe = /^rgba\(\s*(-?\d+),\s*(-?\d+)\s*,\s*(-?\d+)\s*,\s*([01]|[01]?\.\d+)\)$/,
      se = /^rgb\(\s*(-?\d+(?:\.\d+)?)%,\s*(-?\d+(?:\.\d+)?)%\s*,\s*(-?\d+(?:\.\d+)?)%\s*\)$/,
      ie = /^rgba\(\s*(-?\d+(?:\.\d+)?)%,\s*(-?\d+(?:\.\d+)?)%\s*,\s*(-?\d+(?:\.\d+)?)%\s*,\s*([01]|[01]?\.\d+)\)$/,
      ae = /^hsl\(\s*(-?\d+(?:\.\d+)?),\s*(-?\d+(?:\.\d+)?)%\s*,\s*(-?\d+(?:\.\d+)?)%\s*\)$/,
      ce = /^hsla\(\s*(-?\d+(?:\.\d+)?),\s*(-?\d+(?:\.\d+)?)%\s*,\s*(-?\d+(?:\.\d+)?)%\s*,\s*([01]|[01]?\.\d+)\)$/,
      ue = Math.round,
      le = function le(e) {
    var t;
    if (e = e.toLowerCase().trim(), ne.format.named) try {
      return ne.format.named(e);
    } catch (Mc) {}

    if (t = e.match(re)) {
      for (var n = t.slice(1, 4), r = 0; r < 3; r++) {
        n[r] = +n[r];
      }

      return n[3] = 1, n;
    }

    if (t = e.match(oe)) {
      for (var o = t.slice(1, 5), s = 0; s < 4; s++) {
        o[s] = +o[s];
      }

      return o;
    }

    if (t = e.match(se)) {
      for (var i = t.slice(1, 4), a = 0; a < 3; a++) {
        i[a] = ue(2.55 * i[a]);
      }

      return i[3] = 1, i;
    }

    if (t = e.match(ie)) {
      for (var c = t.slice(1, 5), u = 0; u < 3; u++) {
        c[u] = ue(2.55 * c[u]);
      }

      return c[3] = +c[3], c;
    }

    if (t = e.match(ae)) {
      var l = t.slice(1, 4);
      l[1] *= .01, l[2] *= .01;
      var f = te(l);
      return f[3] = 1, f;
    }

    if (t = e.match(ce)) {
      var h = t.slice(1, 4);
      h[1] *= .01, h[2] *= .01;
      var d = te(h);
      return d[3] = +t[4], d;
    }
  };

  le.test = function (e) {
    return re.test(e) || oe.test(e) || se.test(e) || ie.test(e) || ae.test(e) || ce.test(e);
  };

  var fe = le,
      he = k,
      de = _,
      pe = p,
      ge = d.type,
      me = Y,
      ye = fe;
  de.prototype.css = function (e) {
    return me(this._rgb, e);
  }, he.css = function () {
    for (var e = [], t = arguments.length; t--;) {
      e[t] = arguments[t];
    }

    return new (Function.prototype.bind.apply(de, [null].concat(e, ["css"])))();
  }, pe.format.css = ye, pe.autodetect.push({
    p: 5,
    test: function test(e) {
      for (var t = [], n = arguments.length - 1; n-- > 0;) {
        t[n] = arguments[n + 1];
      }

      if (!t.length && "string" === ge(e) && ye.test(e)) return "css";
    }
  });
  var ve = _,
      be = k,
      _e = p,
      we = d.unpack;
  _e.format.gl = function () {
    for (var e = [], t = arguments.length; t--;) {
      e[t] = arguments[t];
    }

    var n = we(e, "rgba");
    return n[0] *= 255, n[1] *= 255, n[2] *= 255, n;
  }, be.gl = function () {
    for (var e = [], t = arguments.length; t--;) {
      e[t] = arguments[t];
    }

    return new (Function.prototype.bind.apply(ve, [null].concat(e, ["gl"])))();
  }, ve.prototype.gl = function () {
    var e = this._rgb;
    return [e[0] / 255, e[1] / 255, e[2] / 255, e[3]];
  };

  var ke = d.unpack,
      xe = function xe() {
    for (var e = [], t = arguments.length; t--;) {
      e[t] = arguments[t];
    }

    var n,
        r = ke(e, "rgb"),
        o = r[0],
        s = r[1],
        i = r[2],
        a = Math.min(o, s, i),
        c = Math.max(o, s, i),
        u = c - a,
        l = 100 * u / 255,
        f = a / (255 - u) * 100;
    return 0 === u ? n = Number.NaN : (o === c && (n = (s - i) / u), s === c && (n = 2 + (i - o) / u), i === c && (n = 4 + (o - s) / u), (n *= 60) < 0 && (n += 360)), [n, l, f];
  },
      Se = xe,
      Pe = d.unpack,
      Ae = Math.floor,
      Oe = function Oe() {
    for (var e, t, n, r, o, s, i = [], a = arguments.length; a--;) {
      i[a] = arguments[a];
    }

    var c,
        u,
        l,
        f = (i = Pe(i, "hcg"))[0],
        h = i[1],
        d = i[2];
    d *= 255;
    var p = 255 * h;
    if (0 === h) c = u = l = d;else {
      360 === f && (f = 0), f > 360 && (f -= 360), f < 0 && (f += 360);

      var g = Ae(f /= 60),
          m = f - g,
          y = d * (1 - h),
          v = y + p * (1 - m),
          b = y + p * m,
          _ = y + p;

      switch (g) {
        case 0:
          c = (e = [_, b, y])[0], u = e[1], l = e[2];
          break;

        case 1:
          c = (t = [v, _, y])[0], u = t[1], l = t[2];
          break;

        case 2:
          c = (n = [y, _, b])[0], u = n[1], l = n[2];
          break;

        case 3:
          c = (r = [y, v, _])[0], u = r[1], l = r[2];
          break;

        case 4:
          c = (o = [b, y, _])[0], u = o[1], l = o[2];
          break;

        case 5:
          c = (s = [_, y, v])[0], u = s[1], l = s[2];
      }
    }
    return [c, u, l, i.length > 3 ? i[3] : 1];
  },
      Ie = Oe,
      Te = d.unpack,
      Ce = d.type,
      Ee = k,
      Me = _,
      Le = p,
      $e = Se;

  Me.prototype.hcg = function () {
    return $e(this._rgb);
  }, Ee.hcg = function () {
    for (var e = [], t = arguments.length; t--;) {
      e[t] = arguments[t];
    }

    return new (Function.prototype.bind.apply(Me, [null].concat(e, ["hcg"])))();
  }, Le.format.hcg = Ie, Le.autodetect.push({
    p: 1,
    test: function test() {
      for (var e = [], t = arguments.length; t--;) {
        e[t] = arguments[t];
      }

      if (e = Te(e, "hcg"), "array" === Ce(e) && 3 === e.length) return "hcg";
    }
  });

  var Re = d.unpack,
      Ne = d.last,
      je = Math.round,
      De = function De() {
    for (var e = [], t = arguments.length; t--;) {
      e[t] = arguments[t];
    }

    var n = Re(e, "rgba"),
        r = n[0],
        o = n[1],
        s = n[2],
        i = n[3],
        a = Ne(e) || "auto";
    void 0 === i && (i = 1), "auto" === a && (a = i < 1 ? "rgba" : "rgb");
    var c = "000000" + ((r = je(r)) << 16 | (o = je(o)) << 8 | (s = je(s))).toString(16);
    c = c.substr(c.length - 6);
    var u = "0" + je(255 * i).toString(16);

    switch (u = u.substr(u.length - 2), a.toLowerCase()) {
      case "rgba":
        return "#" + c + u;

      case "argb":
        return "#" + u + c;

      default:
        return "#" + c;
    }
  },
      Ue = De,
      Fe = /^#?([A-Fa-f0-9]{6}|[A-Fa-f0-9]{3})$/,
      qe = /^#?([A-Fa-f0-9]{8}|[A-Fa-f0-9]{4})$/,
      Be = function Be(e) {
    if (e.match(Fe)) {
      4 !== e.length && 7 !== e.length || (e = e.substr(1)), 3 === e.length && (e = (e = e.split(""))[0] + e[0] + e[1] + e[1] + e[2] + e[2]);
      var t = parseInt(e, 16);
      return [t >> 16, t >> 8 & 255, 255 & t, 1];
    }

    if (e.match(qe)) {
      5 !== e.length && 9 !== e.length || (e = e.substr(1)), 4 === e.length && (e = (e = e.split(""))[0] + e[0] + e[1] + e[1] + e[2] + e[2] + e[3] + e[3]);
      var n = parseInt(e, 16);
      return [n >> 24 & 255, n >> 16 & 255, n >> 8 & 255, Math.round((255 & n) / 255 * 100) / 100];
    }

    throw new Error("unknown hex color: " + e);
  },
      He = k,
      Ke = _,
      Ve = d.type,
      We = p,
      ze = Ue;

  Ke.prototype.hex = function (e) {
    return ze(this._rgb, e);
  }, He.hex = function () {
    for (var e = [], t = arguments.length; t--;) {
      e[t] = arguments[t];
    }

    return new (Function.prototype.bind.apply(Ke, [null].concat(e, ["hex"])))();
  }, We.format.hex = Be, We.autodetect.push({
    p: 4,
    test: function test(e) {
      for (var t = [], n = arguments.length - 1; n-- > 0;) {
        t[n] = arguments[n + 1];
      }

      if (!t.length && "string" === Ve(e) && [3, 4, 5, 6, 7, 8, 9].indexOf(e.length) >= 0) return "hex";
    }
  });

  var Je = d.unpack,
      Ge = d.TWOPI,
      Ye = Math.min,
      Qe = Math.sqrt,
      Xe = Math.acos,
      Ze = function Ze() {
    for (var e = [], t = arguments.length; t--;) {
      e[t] = arguments[t];
    }

    var n,
        r = Je(e, "rgb"),
        o = r[0],
        s = r[1],
        i = r[2],
        a = Ye(o /= 255, s /= 255, i /= 255),
        c = (o + s + i) / 3,
        u = c > 0 ? 1 - a / c : 0;
    return 0 === u ? n = NaN : (n = (o - s + (o - i)) / 2, n /= Qe((o - s) * (o - s) + (o - i) * (s - i)), n = Xe(n), i > s && (n = Ge - n), n /= Ge), [360 * n, u, c];
  },
      et = Ze,
      tt = d.unpack,
      nt = d.limit,
      rt = d.TWOPI,
      ot = d.PITHIRD,
      st = Math.cos,
      it = function it() {
    for (var e = [], t = arguments.length; t--;) {
      e[t] = arguments[t];
    }

    var n,
        r,
        o,
        s = (e = tt(e, "hsi"))[0],
        i = e[1],
        a = e[2];
    return isNaN(s) && (s = 0), isNaN(i) && (i = 0), s > 360 && (s -= 360), s < 0 && (s += 360), (s /= 360) < 1 / 3 ? r = 1 - ((o = (1 - i) / 3) + (n = (1 + i * st(rt * s) / st(ot - rt * s)) / 3)) : s < 2 / 3 ? o = 1 - ((n = (1 - i) / 3) + (r = (1 + i * st(rt * (s -= 1 / 3)) / st(ot - rt * s)) / 3)) : n = 1 - ((r = (1 - i) / 3) + (o = (1 + i * st(rt * (s -= 2 / 3)) / st(ot - rt * s)) / 3)), [255 * (n = nt(a * n * 3)), 255 * (r = nt(a * r * 3)), 255 * (o = nt(a * o * 3)), e.length > 3 ? e[3] : 1];
  },
      at = it,
      ct = d.unpack,
      ut = d.type,
      lt = k,
      ft = _,
      ht = p,
      dt = et;

  ft.prototype.hsi = function () {
    return dt(this._rgb);
  }, lt.hsi = function () {
    for (var e = [], t = arguments.length; t--;) {
      e[t] = arguments[t];
    }

    return new (Function.prototype.bind.apply(ft, [null].concat(e, ["hsi"])))();
  }, ht.format.hsi = at, ht.autodetect.push({
    p: 2,
    test: function test() {
      for (var e = [], t = arguments.length; t--;) {
        e[t] = arguments[t];
      }

      if (e = ct(e, "hsi"), "array" === ut(e) && 3 === e.length) return "hsi";
    }
  });
  var pt = d.unpack,
      gt = d.type,
      mt = k,
      yt = _,
      vt = p,
      bt = H;
  yt.prototype.hsl = function () {
    return bt(this._rgb);
  }, mt.hsl = function () {
    for (var e = [], t = arguments.length; t--;) {
      e[t] = arguments[t];
    }

    return new (Function.prototype.bind.apply(yt, [null].concat(e, ["hsl"])))();
  }, vt.format.hsl = ee, vt.autodetect.push({
    p: 2,
    test: function test() {
      for (var e = [], t = arguments.length; t--;) {
        e[t] = arguments[t];
      }

      if (e = pt(e, "hsl"), "array" === gt(e) && 3 === e.length) return "hsl";
    }
  });

  var _t = d.unpack,
      wt = Math.min,
      kt = Math.max,
      xt = function xt() {
    for (var e = [], t = arguments.length; t--;) {
      e[t] = arguments[t];
    }

    var n,
        r,
        o,
        s = (e = _t(e, "rgb"))[0],
        i = e[1],
        a = e[2],
        c = wt(s, i, a),
        u = kt(s, i, a),
        l = u - c;

    return o = u / 255, 0 === u ? (n = Number.NaN, r = 0) : (r = l / u, s === u && (n = (i - a) / l), i === u && (n = 2 + (a - s) / l), a === u && (n = 4 + (s - i) / l), (n *= 60) < 0 && (n += 360)), [n, r, o];
  },
      St = xt,
      Pt = d.unpack,
      At = Math.floor,
      Ot = function Ot() {
    for (var e, t, n, r, o, s, i = [], a = arguments.length; a--;) {
      i[a] = arguments[a];
    }

    var c,
        u,
        l,
        f = (i = Pt(i, "hsv"))[0],
        h = i[1],
        d = i[2];
    if (d *= 255, 0 === h) c = u = l = d;else {
      360 === f && (f = 0), f > 360 && (f -= 360), f < 0 && (f += 360);
      var p = At(f /= 60),
          g = f - p,
          m = d * (1 - h),
          y = d * (1 - h * g),
          v = d * (1 - h * (1 - g));

      switch (p) {
        case 0:
          c = (e = [d, v, m])[0], u = e[1], l = e[2];
          break;

        case 1:
          c = (t = [y, d, m])[0], u = t[1], l = t[2];
          break;

        case 2:
          c = (n = [m, d, v])[0], u = n[1], l = n[2];
          break;

        case 3:
          c = (r = [m, y, d])[0], u = r[1], l = r[2];
          break;

        case 4:
          c = (o = [v, m, d])[0], u = o[1], l = o[2];
          break;

        case 5:
          c = (s = [d, m, y])[0], u = s[1], l = s[2];
      }
    }
    return [c, u, l, i.length > 3 ? i[3] : 1];
  },
      It = Ot,
      Tt = d.unpack,
      Ct = d.type,
      Et = k,
      Mt = _,
      Lt = p,
      $t = St;

  Mt.prototype.hsv = function () {
    return $t(this._rgb);
  }, Et.hsv = function () {
    for (var e = [], t = arguments.length; t--;) {
      e[t] = arguments[t];
    }

    return new (Function.prototype.bind.apply(Mt, [null].concat(e, ["hsv"])))();
  }, Lt.format.hsv = It, Lt.autodetect.push({
    p: 2,
    test: function test() {
      for (var e = [], t = arguments.length; t--;) {
        e[t] = arguments[t];
      }

      if (e = Tt(e, "hsv"), "array" === Ct(e) && 3 === e.length) return "hsv";
    }
  });

  var Rt = {
    Kn: 18,
    Xn: .95047,
    Yn: 1,
    Zn: 1.08883,
    t0: .137931034,
    t1: .206896552,
    t2: .12841855,
    t3: .008856452
  },
      Nt = Rt,
      jt = d.unpack,
      Dt = Math.pow,
      Ut = function Ut() {
    for (var e = [], t = arguments.length; t--;) {
      e[t] = arguments[t];
    }

    var n = jt(e, "rgb"),
        r = n[0],
        o = n[1],
        s = n[2],
        i = Bt(r, o, s),
        a = i[0],
        c = i[1],
        u = 116 * c - 16;
    return [u < 0 ? 0 : u, 500 * (a - c), 200 * (c - i[2])];
  },
      Ft = function Ft(e) {
    return (e /= 255) <= .04045 ? e / 12.92 : Dt((e + .055) / 1.055, 2.4);
  },
      qt = function qt(e) {
    return e > Nt.t3 ? Dt(e, 1 / 3) : e / Nt.t2 + Nt.t0;
  },
      Bt = function Bt(e, t, n) {
    return e = Ft(e), t = Ft(t), n = Ft(n), [qt((.4124564 * e + .3575761 * t + .1804375 * n) / Nt.Xn), qt((.2126729 * e + .7151522 * t + .072175 * n) / Nt.Yn), qt((.0193339 * e + .119192 * t + .9503041 * n) / Nt.Zn)];
  },
      Ht = Ut,
      Kt = Rt,
      Vt = d.unpack,
      Wt = Math.pow,
      zt = function zt() {
    for (var e = [], t = arguments.length; t--;) {
      e[t] = arguments[t];
    }

    var n,
        r,
        o,
        s = (e = Vt(e, "lab"))[0],
        i = e[1],
        a = e[2];
    return r = (s + 16) / 116, n = isNaN(i) ? r : r + i / 500, o = isNaN(a) ? r : r - a / 200, r = Kt.Yn * Gt(r), n = Kt.Xn * Gt(n), o = Kt.Zn * Gt(o), [Jt(3.2404542 * n - 1.5371385 * r - .4985314 * o), Jt(-.969266 * n + 1.8760108 * r + .041556 * o), Jt(.0556434 * n - .2040259 * r + 1.0572252 * o), e.length > 3 ? e[3] : 1];
  },
      Jt = function Jt(e) {
    return 255 * (e <= .00304 ? 12.92 * e : 1.055 * Wt(e, 1 / 2.4) - .055);
  },
      Gt = function Gt(e) {
    return e > Kt.t1 ? e * e * e : Kt.t2 * (e - Kt.t0);
  },
      Yt = zt,
      Qt = d.unpack,
      Xt = d.type,
      Zt = k,
      en = _,
      tn = p,
      nn = Ht;

  en.prototype.lab = function () {
    return nn(this._rgb);
  }, Zt.lab = function () {
    for (var e = [], t = arguments.length; t--;) {
      e[t] = arguments[t];
    }

    return new (Function.prototype.bind.apply(en, [null].concat(e, ["lab"])))();
  }, tn.format.lab = Yt, tn.autodetect.push({
    p: 2,
    test: function test() {
      for (var e = [], t = arguments.length; t--;) {
        e[t] = arguments[t];
      }

      if (e = Qt(e, "lab"), "array" === Xt(e) && 3 === e.length) return "lab";
    }
  });

  var rn = d.unpack,
      on = d.RAD2DEG,
      sn = Math.sqrt,
      an = Math.atan2,
      cn = Math.round,
      un = function un() {
    for (var e = [], t = arguments.length; t--;) {
      e[t] = arguments[t];
    }

    var n = rn(e, "lab"),
        r = n[0],
        o = n[1],
        s = n[2],
        i = sn(o * o + s * s),
        a = (an(s, o) * on + 360) % 360;
    return 0 === cn(1e4 * i) && (a = Number.NaN), [r, i, a];
  },
      ln = un,
      fn = d.unpack,
      hn = Ht,
      dn = ln,
      pn = function pn() {
    for (var e = [], t = arguments.length; t--;) {
      e[t] = arguments[t];
    }

    var n = fn(e, "rgb"),
        r = n[0],
        o = n[1],
        s = n[2],
        i = hn(r, o, s),
        a = i[0],
        c = i[1],
        u = i[2];
    return dn(a, c, u);
  },
      gn = pn,
      mn = d.unpack,
      yn = d.DEG2RAD,
      vn = Math.sin,
      bn = Math.cos,
      _n = function _n() {
    for (var e = [], t = arguments.length; t--;) {
      e[t] = arguments[t];
    }

    var n = mn(e, "lch"),
        r = n[0],
        o = n[1],
        s = n[2];
    return isNaN(s) && (s = 0), [r, bn(s *= yn) * o, vn(s) * o];
  },
      wn = _n,
      kn = d.unpack,
      xn = wn,
      Sn = Yt,
      Pn = function Pn() {
    for (var e = [], t = arguments.length; t--;) {
      e[t] = arguments[t];
    }

    var n = (e = kn(e, "lch"))[0],
        r = e[1],
        o = e[2],
        s = xn(n, r, o),
        i = s[0],
        a = s[1],
        c = s[2],
        u = Sn(i, a, c);
    return [u[0], u[1], u[2], e.length > 3 ? e[3] : 1];
  },
      An = Pn,
      On = d.unpack,
      In = An,
      Tn = function Tn() {
    for (var e = [], t = arguments.length; t--;) {
      e[t] = arguments[t];
    }

    var n = On(e, "hcl").reverse();
    return In.apply(void 0, n);
  },
      Cn = Tn,
      En = d.unpack,
      Mn = d.type,
      Ln = k,
      $n = _,
      Rn = p,
      Nn = gn;

  $n.prototype.lch = function () {
    return Nn(this._rgb);
  }, $n.prototype.hcl = function () {
    return Nn(this._rgb).reverse();
  }, Ln.lch = function () {
    for (var e = [], t = arguments.length; t--;) {
      e[t] = arguments[t];
    }

    return new (Function.prototype.bind.apply($n, [null].concat(e, ["lch"])))();
  }, Ln.hcl = function () {
    for (var e = [], t = arguments.length; t--;) {
      e[t] = arguments[t];
    }

    return new (Function.prototype.bind.apply($n, [null].concat(e, ["hcl"])))();
  }, Rn.format.lch = An, Rn.format.hcl = Cn, ["lch", "hcl"].forEach(function (e) {
    return Rn.autodetect.push({
      p: 2,
      test: function test() {
        for (var t = [], n = arguments.length; n--;) {
          t[n] = arguments[n];
        }

        if (t = En(t, e), "array" === Mn(t) && 3 === t.length) return e;
      }
    });
  });
  var jn = {
    aliceblue: "#f0f8ff",
    antiquewhite: "#faebd7",
    aqua: "#00ffff",
    aquamarine: "#7fffd4",
    azure: "#f0ffff",
    beige: "#f5f5dc",
    bisque: "#ffe4c4",
    black: "#000000",
    blanchedalmond: "#ffebcd",
    blue: "#0000ff",
    blueviolet: "#8a2be2",
    brown: "#a52a2a",
    burlywood: "#deb887",
    cadetblue: "#5f9ea0",
    chartreuse: "#7fff00",
    chocolate: "#d2691e",
    coral: "#ff7f50",
    cornflower: "#6495ed",
    cornflowerblue: "#6495ed",
    cornsilk: "#fff8dc",
    crimson: "#dc143c",
    cyan: "#00ffff",
    darkblue: "#00008b",
    darkcyan: "#008b8b",
    darkgoldenrod: "#b8860b",
    darkgray: "#a9a9a9",
    darkgreen: "#006400",
    darkgrey: "#a9a9a9",
    darkkhaki: "#bdb76b",
    darkmagenta: "#8b008b",
    darkolivegreen: "#556b2f",
    darkorange: "#ff8c00",
    darkorchid: "#9932cc",
    darkred: "#8b0000",
    darksalmon: "#e9967a",
    darkseagreen: "#8fbc8f",
    darkslateblue: "#483d8b",
    darkslategray: "#2f4f4f",
    darkslategrey: "#2f4f4f",
    darkturquoise: "#00ced1",
    darkviolet: "#9400d3",
    deeppink: "#ff1493",
    deepskyblue: "#00bfff",
    dimgray: "#696969",
    dimgrey: "#696969",
    dodgerblue: "#1e90ff",
    firebrick: "#b22222",
    floralwhite: "#fffaf0",
    forestgreen: "#228b22",
    fuchsia: "#ff00ff",
    gainsboro: "#dcdcdc",
    ghostwhite: "#f8f8ff",
    gold: "#ffd700",
    goldenrod: "#daa520",
    gray: "#808080",
    green: "#008000",
    greenyellow: "#adff2f",
    grey: "#808080",
    honeydew: "#f0fff0",
    hotpink: "#ff69b4",
    indianred: "#cd5c5c",
    indigo: "#4b0082",
    ivory: "#fffff0",
    khaki: "#f0e68c",
    laserlemon: "#ffff54",
    lavender: "#e6e6fa",
    lavenderblush: "#fff0f5",
    lawngreen: "#7cfc00",
    lemonchiffon: "#fffacd",
    lightblue: "#add8e6",
    lightcoral: "#f08080",
    lightcyan: "#e0ffff",
    lightgoldenrod: "#fafad2",
    lightgoldenrodyellow: "#fafad2",
    lightgray: "#d3d3d3",
    lightgreen: "#90ee90",
    lightgrey: "#d3d3d3",
    lightpink: "#ffb6c1",
    lightsalmon: "#ffa07a",
    lightseagreen: "#20b2aa",
    lightskyblue: "#87cefa",
    lightslategray: "#778899",
    lightslategrey: "#778899",
    lightsteelblue: "#b0c4de",
    lightyellow: "#ffffe0",
    lime: "#00ff00",
    limegreen: "#32cd32",
    linen: "#faf0e6",
    magenta: "#ff00ff",
    maroon: "#800000",
    maroon2: "#7f0000",
    maroon3: "#b03060",
    mediumaquamarine: "#66cdaa",
    mediumblue: "#0000cd",
    mediumorchid: "#ba55d3",
    mediumpurple: "#9370db",
    mediumseagreen: "#3cb371",
    mediumslateblue: "#7b68ee",
    mediumspringgreen: "#00fa9a",
    mediumturquoise: "#48d1cc",
    mediumvioletred: "#c71585",
    midnightblue: "#191970",
    mintcream: "#f5fffa",
    mistyrose: "#ffe4e1",
    moccasin: "#ffe4b5",
    navajowhite: "#ffdead",
    navy: "#000080",
    oldlace: "#fdf5e6",
    olive: "#808000",
    olivedrab: "#6b8e23",
    orange: "#ffa500",
    orangered: "#ff4500",
    orchid: "#da70d6",
    palegoldenrod: "#eee8aa",
    palegreen: "#98fb98",
    paleturquoise: "#afeeee",
    palevioletred: "#db7093",
    papayawhip: "#ffefd5",
    peachpuff: "#ffdab9",
    peru: "#cd853f",
    pink: "#ffc0cb",
    plum: "#dda0dd",
    powderblue: "#b0e0e6",
    purple: "#800080",
    purple2: "#7f007f",
    purple3: "#a020f0",
    rebeccapurple: "#663399",
    red: "#ff0000",
    rosybrown: "#bc8f8f",
    royalblue: "#4169e1",
    saddlebrown: "#8b4513",
    salmon: "#fa8072",
    sandybrown: "#f4a460",
    seagreen: "#2e8b57",
    seashell: "#fff5ee",
    sienna: "#a0522d",
    silver: "#c0c0c0",
    skyblue: "#87ceeb",
    slateblue: "#6a5acd",
    slategray: "#708090",
    slategrey: "#708090",
    snow: "#fffafa",
    springgreen: "#00ff7f",
    steelblue: "#4682b4",
    tan: "#d2b48c",
    teal: "#008080",
    thistle: "#d8bfd8",
    tomato: "#ff6347",
    turquoise: "#40e0d0",
    violet: "#ee82ee",
    wheat: "#f5deb3",
    white: "#ffffff",
    whitesmoke: "#f5f5f5",
    yellow: "#ffff00",
    yellowgreen: "#9acd32"
  },
      Dn = _,
      Un = p,
      Fn = d.type,
      qn = jn,
      Bn = Be,
      Hn = Ue;
  Dn.prototype.name = function () {
    for (var e = Hn(this._rgb, "rgb"), t = 0, n = Object.keys(qn); t < n.length; t += 1) {
      var r = n[t];
      if (qn[r] === e) return r.toLowerCase();
    }

    return e;
  }, Un.format.named = function (e) {
    if (e = e.toLowerCase(), qn[e]) return Bn(qn[e]);
    throw new Error("unknown color name: " + e);
  }, Un.autodetect.push({
    p: 5,
    test: function test(e) {
      for (var t = [], n = arguments.length - 1; n-- > 0;) {
        t[n] = arguments[n + 1];
      }

      if (!t.length && "string" === Fn(e) && qn[e.toLowerCase()]) return "named";
    }
  });

  var Kn = d.unpack,
      Vn = function Vn() {
    for (var e = [], t = arguments.length; t--;) {
      e[t] = arguments[t];
    }

    var n = Kn(e, "rgb");
    return (n[0] << 16) + (n[1] << 8) + n[2];
  },
      Wn = Vn,
      zn = d.type,
      Jn = function Jn(e) {
    if ("number" == zn(e) && e >= 0 && e <= 16777215) return [e >> 16, e >> 8 & 255, 255 & e, 1];
    throw new Error("unknown num color: " + e);
  },
      Gn = k,
      Yn = _,
      Qn = p,
      Xn = d.type,
      Zn = Wn;

  Yn.prototype.num = function () {
    return Zn(this._rgb);
  }, Gn.num = function () {
    for (var e = [], t = arguments.length; t--;) {
      e[t] = arguments[t];
    }

    return new (Function.prototype.bind.apply(Yn, [null].concat(e, ["num"])))();
  }, Qn.format.num = Jn, Qn.autodetect.push({
    p: 5,
    test: function test() {
      for (var e = [], t = arguments.length; t--;) {
        e[t] = arguments[t];
      }

      if (1 === e.length && "number" === Xn(e[0]) && e[0] >= 0 && e[0] <= 16777215) return "num";
    }
  });
  var er = k,
      tr = _,
      nr = p,
      rr = d.unpack,
      or = d.type,
      sr = Math.round;
  tr.prototype.rgb = function (e) {
    return void 0 === e && (e = !0), !1 === e ? this._rgb.slice(0, 3) : this._rgb.slice(0, 3).map(sr);
  }, tr.prototype.rgba = function (e) {
    return void 0 === e && (e = !0), this._rgb.slice(0, 4).map(function (t, n) {
      return n < 3 ? !1 === e ? t : sr(t) : t;
    });
  }, er.rgb = function () {
    for (var e = [], t = arguments.length; t--;) {
      e[t] = arguments[t];
    }

    return new (Function.prototype.bind.apply(tr, [null].concat(e, ["rgb"])))();
  }, nr.format.rgb = function () {
    for (var e = [], t = arguments.length; t--;) {
      e[t] = arguments[t];
    }

    var n = rr(e, "rgba");
    return void 0 === n[3] && (n[3] = 1), n;
  }, nr.autodetect.push({
    p: 3,
    test: function test() {
      for (var e = [], t = arguments.length; t--;) {
        e[t] = arguments[t];
      }

      if (e = rr(e, "rgba"), "array" === or(e) && (3 === e.length || 4 === e.length && "number" == or(e[3]) && e[3] >= 0 && e[3] <= 1)) return "rgb";
    }
  });

  var ir = Math.log,
      ar = function ar(e) {
    var t,
        n,
        r,
        o = e / 100;
    return o < 66 ? (t = 255, n = o < 6 ? 0 : -155.25485562709179 - .44596950469579133 * (n = o - 2) + 104.49216199393888 * ir(n), r = o < 20 ? 0 : .8274096064007395 * (r = o - 10) - 254.76935184120902 + 115.67994401066147 * ir(r)) : (t = 351.97690566805693 + .114206453784165 * (t = o - 55) - 40.25366309332127 * ir(t), n = 325.4494125711974 + .07943456536662342 * (n = o - 50) - 28.0852963507957 * ir(n), r = 255), [t, n, r, 1];
  },
      cr = ar,
      ur = d.unpack,
      lr = Math.round,
      fr = function fr() {
    for (var e = [], t = arguments.length; t--;) {
      e[t] = arguments[t];
    }

    for (var n, r = ur(e, "rgb"), o = r[0], s = r[2], i = 1e3, a = 4e4, c = .4; a - i > c;) {
      var u = cr(n = .5 * (a + i));
      u[2] / u[0] >= s / o ? a = n : i = n;
    }

    return lr(n);
  },
      hr = k,
      dr = _,
      pr = p,
      gr = fr;

  dr.prototype.temp = dr.prototype.kelvin = dr.prototype.temperature = function () {
    return gr(this._rgb);
  }, hr.temp = hr.kelvin = hr.temperature = function () {
    for (var e = [], t = arguments.length; t--;) {
      e[t] = arguments[t];
    }

    return new (Function.prototype.bind.apply(dr, [null].concat(e, ["temp"])))();
  }, pr.format.temp = pr.format.kelvin = pr.format.temperature = ar;

  var mr = d.unpack,
      yr = Math.cbrt,
      vr = Math.pow,
      br = Math.sign,
      _r = function _r() {
    for (var e = [], t = arguments.length; t--;) {
      e[t] = arguments[t];
    }

    var n = mr(e, "rgb"),
        r = n[0],
        o = n[1],
        s = n[2],
        i = [kr(r / 255), kr(o / 255), kr(s / 255)],
        a = i[0],
        c = i[1],
        u = i[2],
        l = yr(.4122214708 * a + .5363325363 * c + .0514459929 * u),
        f = yr(.2119034982 * a + .6806995451 * c + .1073969566 * u),
        h = yr(.0883024619 * a + .2817188376 * c + .6299787005 * u);
    return [.2104542553 * l + .793617785 * f - .0040720468 * h, 1.9779984951 * l - 2.428592205 * f + .4505937099 * h, .0259040371 * l + .7827717662 * f - .808675766 * h];
  },
      wr = _r;

  function kr(e) {
    var t = Math.abs(e);
    return t < .04045 ? e / 12.92 : (br(e) || 1) * vr((t + .055) / 1.055, 2.4);
  }

  var xr = d.unpack,
      Sr = Math.pow,
      Pr = Math.sign,
      Ar = function Ar() {
    for (var e = [], t = arguments.length; t--;) {
      e[t] = arguments[t];
    }

    var n = (e = xr(e, "lab"))[0],
        r = e[1],
        o = e[2],
        s = Sr(n + .3963377774 * r + .2158037573 * o, 3),
        i = Sr(n - .1055613458 * r - .0638541728 * o, 3),
        a = Sr(n - .0894841775 * r - 1.291485548 * o, 3);
    return [255 * Ir(4.0767416621 * s - 3.3077115913 * i + .2309699292 * a), 255 * Ir(-1.2684380046 * s + 2.6097574011 * i - .3413193965 * a), 255 * Ir(-.0041960863 * s - .7034186147 * i + 1.707614701 * a), e.length > 3 ? e[3] : 1];
  },
      Or = Ar;

  function Ir(e) {
    var t = Math.abs(e);
    return t > .0031308 ? (Pr(e) || 1) * (1.055 * Sr(t, 1 / 2.4) - .055) : 12.92 * e;
  }

  var Tr = d.unpack,
      Cr = d.type,
      Er = k,
      Mr = _,
      Lr = p,
      $r = wr;
  Mr.prototype.oklab = function () {
    return $r(this._rgb);
  }, Er.oklab = function () {
    for (var e = [], t = arguments.length; t--;) {
      e[t] = arguments[t];
    }

    return new (Function.prototype.bind.apply(Mr, [null].concat(e, ["oklab"])))();
  }, Lr.format.oklab = Or, Lr.autodetect.push({
    p: 3,
    test: function test() {
      for (var e = [], t = arguments.length; t--;) {
        e[t] = arguments[t];
      }

      if (e = Tr(e, "oklab"), "array" === Cr(e) && 3 === e.length) return "oklab";
    }
  });

  var Rr = d.unpack,
      Nr = wr,
      jr = ln,
      Dr = function Dr() {
    for (var e = [], t = arguments.length; t--;) {
      e[t] = arguments[t];
    }

    var n = Rr(e, "rgb"),
        r = n[0],
        o = n[1],
        s = n[2],
        i = Nr(r, o, s),
        a = i[0],
        c = i[1],
        u = i[2];
    return jr(a, c, u);
  },
      Ur = Dr,
      Fr = d.unpack,
      qr = wn,
      Br = Or,
      Hr = function Hr() {
    for (var e = [], t = arguments.length; t--;) {
      e[t] = arguments[t];
    }

    var n = (e = Fr(e, "lch"))[0],
        r = e[1],
        o = e[2],
        s = qr(n, r, o),
        i = s[0],
        a = s[1],
        c = s[2],
        u = Br(i, a, c);
    return [u[0], u[1], u[2], e.length > 3 ? e[3] : 1];
  },
      Kr = Hr,
      Vr = d.unpack,
      Wr = d.type,
      zr = k,
      Jr = _,
      Gr = p,
      Yr = Ur;

  Jr.prototype.oklch = function () {
    return Yr(this._rgb);
  }, zr.oklch = function () {
    for (var e = [], t = arguments.length; t--;) {
      e[t] = arguments[t];
    }

    return new (Function.prototype.bind.apply(Jr, [null].concat(e, ["oklch"])))();
  }, Gr.format.oklch = Kr, Gr.autodetect.push({
    p: 3,
    test: function test() {
      for (var e = [], t = arguments.length; t--;) {
        e[t] = arguments[t];
      }

      if (e = Vr(e, "oklch"), "array" === Wr(e) && 3 === e.length) return "oklch";
    }
  });
  var Qr = _,
      Xr = d.type;
  Qr.prototype.alpha = function (e, t) {
    return void 0 === t && (t = !1), void 0 !== e && "number" === Xr(e) ? t ? (this._rgb[3] = e, this) : new Qr([this._rgb[0], this._rgb[1], this._rgb[2], e], "rgb") : this._rgb[3];
  }, _.prototype.clipped = function () {
    return this._rgb._clipped || !1;
  };
  var Zr = _,
      eo = Rt;
  Zr.prototype.darken = function (e) {
    void 0 === e && (e = 1);
    var t = this,
        n = t.lab();
    return n[0] -= eo.Kn * e, new Zr(n, "lab").alpha(t.alpha(), !0);
  }, Zr.prototype.brighten = function (e) {
    return void 0 === e && (e = 1), this.darken(-e);
  }, Zr.prototype.darker = Zr.prototype.darken, Zr.prototype.brighter = Zr.prototype.brighten, _.prototype.get = function (e) {
    var t = e.split("."),
        n = t[0],
        r = t[1],
        o = this[n]();

    if (r) {
      var s = n.indexOf(r) - ("ok" === n.substr(0, 2) ? 2 : 0);
      if (s > -1) return o[s];
      throw new Error("unknown channel " + r + " in mode " + n);
    }

    return o;
  };
  var to = _,
      no = d.type,
      ro = Math.pow,
      oo = 1e-7,
      so = 20;

  to.prototype.luminance = function (e) {
    if (void 0 !== e && "number" === no(e)) {
      if (0 === e) return new to([0, 0, 0, this._rgb[3]], "rgb");
      if (1 === e) return new to([255, 255, 255, this._rgb[3]], "rgb");

      var t = this.luminance(),
          n = "rgb",
          r = so,
          o = function o(t, s) {
        var i = t.interpolate(s, .5, n),
            a = i.luminance();
        return Math.abs(e - a) < oo || !r-- ? i : a > e ? o(t, i) : o(i, s);
      },
          s = (t > e ? o(new to([0, 0, 0]), this) : o(this, new to([255, 255, 255]))).rgb();

      return new to(s.concat([this._rgb[3]]));
    }

    return io.apply(void 0, this._rgb.slice(0, 3));
  };

  var io = function io(e, t, n) {
    return .2126 * (e = ao(e)) + .7152 * (t = ao(t)) + .0722 * (n = ao(n));
  },
      ao = function ao(e) {
    return (e /= 255) <= .03928 ? e / 12.92 : ro((e + .055) / 1.055, 2.4);
  },
      co = {},
      uo = _,
      lo = d.type,
      fo = co,
      ho = function ho(e, t, n) {
    void 0 === n && (n = .5);

    for (var r = [], o = arguments.length - 3; o-- > 0;) {
      r[o] = arguments[o + 3];
    }

    var s = r[0] || "lrgb";
    if (fo[s] || r.length || (s = Object.keys(fo)[0]), !fo[s]) throw new Error("interpolation mode " + s + " is not defined");
    return "object" !== lo(e) && (e = new uo(e)), "object" !== lo(t) && (t = new uo(t)), fo[s](e, t, n).alpha(e.alpha() + n * (t.alpha() - e.alpha()));
  },
      po = _,
      go = ho;

  po.prototype.mix = po.prototype.interpolate = function (e, t) {
    void 0 === t && (t = .5);

    for (var n = [], r = arguments.length - 2; r-- > 0;) {
      n[r] = arguments[r + 2];
    }

    return go.apply(void 0, [this, e, t].concat(n));
  };

  var mo = _;

  mo.prototype.premultiply = function (e) {
    void 0 === e && (e = !1);
    var t = this._rgb,
        n = t[3];
    return e ? (this._rgb = [t[0] * n, t[1] * n, t[2] * n, n], this) : new mo([t[0] * n, t[1] * n, t[2] * n, n], "rgb");
  };

  var yo = _,
      vo = Rt;
  yo.prototype.saturate = function (e) {
    void 0 === e && (e = 1);
    var t = this,
        n = t.lch();
    return n[1] += vo.Kn * e, n[1] < 0 && (n[1] = 0), new yo(n, "lch").alpha(t.alpha(), !0);
  }, yo.prototype.desaturate = function (e) {
    return void 0 === e && (e = 1), this.saturate(-e);
  };
  var bo = _,
      _o = d.type;

  bo.prototype.set = function (e, t, n) {
    void 0 === n && (n = !1);
    var r = e.split("."),
        o = r[0],
        s = r[1],
        i = this[o]();

    if (s) {
      var a = o.indexOf(s) - ("ok" === o.substr(0, 2) ? 2 : 0);

      if (a > -1) {
        if ("string" == _o(t)) switch (t.charAt(0)) {
          case "+":
          case "-":
            i[a] += +t;
            break;

          case "*":
            i[a] *= +t.substr(1);
            break;

          case "/":
            i[a] /= +t.substr(1);
            break;

          default:
            i[a] = +t;
        } else {
          if ("number" !== _o(t)) throw new Error("unsupported value for Color.set");
          i[a] = t;
        }
        var c = new bo(i, o);
        return n ? (this._rgb = c._rgb, this) : c;
      }

      throw new Error("unknown channel " + s + " in mode " + o);
    }

    return i;
  };

  var wo = _,
      ko = function ko(e, t, n) {
    var r = e._rgb,
        o = t._rgb;
    return new wo(r[0] + n * (o[0] - r[0]), r[1] + n * (o[1] - r[1]), r[2] + n * (o[2] - r[2]), "rgb");
  };

  co.rgb = ko;

  var xo = _,
      So = Math.sqrt,
      Po = Math.pow,
      Ao = function Ao(e, t, n) {
    var r = e._rgb,
        o = r[0],
        s = r[1],
        i = r[2],
        a = t._rgb,
        c = a[0],
        u = a[1],
        l = a[2];
    return new xo(So(Po(o, 2) * (1 - n) + Po(c, 2) * n), So(Po(s, 2) * (1 - n) + Po(u, 2) * n), So(Po(i, 2) * (1 - n) + Po(l, 2) * n), "rgb");
  };

  co.lrgb = Ao;

  var Oo = _,
      Io = function Io(e, t, n) {
    var r = e.lab(),
        o = t.lab();
    return new Oo(r[0] + n * (o[0] - r[0]), r[1] + n * (o[1] - r[1]), r[2] + n * (o[2] - r[2]), "lab");
  };

  co.lab = Io;

  var To = _,
      Co = function Co(e, t, n, r) {
    var o, s, i, a, c, u, l, f, h, d, p, g, m;
    return "hsl" === r ? (i = e.hsl(), a = t.hsl()) : "hsv" === r ? (i = e.hsv(), a = t.hsv()) : "hcg" === r ? (i = e.hcg(), a = t.hcg()) : "hsi" === r ? (i = e.hsi(), a = t.hsi()) : "lch" === r || "hcl" === r ? (r = "hcl", i = e.hcl(), a = t.hcl()) : "oklch" === r && (i = e.oklch().reverse(), a = t.oklch().reverse()), "h" !== r.substr(0, 1) && "oklch" !== r || (c = (o = i)[0], l = o[1], h = o[2], u = (s = a)[0], f = s[1], d = s[2]), isNaN(c) || isNaN(u) ? isNaN(c) ? isNaN(u) ? g = Number.NaN : (g = u, 1 != h && 0 != h || "hsv" == r || (p = f)) : (g = c, 1 != d && 0 != d || "hsv" == r || (p = l)) : g = c + n * (u > c && u - c > 180 ? u - (c + 360) : u < c && c - u > 180 ? u + 360 - c : u - c), void 0 === p && (p = l + n * (f - l)), m = h + n * (d - h), new To("oklch" === r ? [m, p, g] : [g, p, m], r);
  },
      Eo = Co,
      Mo = function Mo(e, t, n) {
    return Eo(e, t, n, "lch");
  };

  co.lch = Mo, co.hcl = Mo;

  var Lo = _,
      $o = function $o(e, t, n) {
    var r = e.num(),
        o = t.num();
    return new Lo(r + n * (o - r), "num");
  };

  co.num = $o;

  var Ro = Co,
      No = function No(e, t, n) {
    return Ro(e, t, n, "hcg");
  };

  co.hcg = No;

  var jo = Co,
      Do = function Do(e, t, n) {
    return jo(e, t, n, "hsi");
  };

  co.hsi = Do;

  var Uo = Co,
      Fo = function Fo(e, t, n) {
    return Uo(e, t, n, "hsl");
  };

  co.hsl = Fo;

  var qo = Co,
      Bo = function Bo(e, t, n) {
    return qo(e, t, n, "hsv");
  };

  co.hsv = Bo;

  var Ho = _,
      Ko = function Ko(e, t, n) {
    var r = e.oklab(),
        o = t.oklab();
    return new Ho(r[0] + n * (o[0] - r[0]), r[1] + n * (o[1] - r[1]), r[2] + n * (o[2] - r[2]), "oklab");
  };

  co.oklab = Ko;

  var Vo = Co,
      Wo = function Wo(e, t, n) {
    return Vo(e, t, n, "oklch");
  };

  co.oklch = Wo;

  var zo = _,
      Jo = d.clip_rgb,
      Go = Math.pow,
      Yo = Math.sqrt,
      Qo = Math.PI,
      Xo = Math.cos,
      Zo = Math.sin,
      es = Math.atan2,
      ts = function ts(e, t, n) {
    void 0 === t && (t = "lrgb"), void 0 === n && (n = null);
    var r = e.length;
    n || (n = Array.from(new Array(r)).map(function () {
      return 1;
    }));
    var o = r / n.reduce(function (e, t) {
      return e + t;
    });
    if (n.forEach(function (e, t) {
      n[t] *= o;
    }), e = e.map(function (e) {
      return new zo(e);
    }), "lrgb" === t) return ns(e, n);

    for (var s = e.shift(), i = s.get(t), a = [], c = 0, u = 0, l = 0; l < i.length; l++) {
      if (i[l] = (i[l] || 0) * n[0], a.push(isNaN(i[l]) ? 0 : n[0]), "h" === t.charAt(l) && !isNaN(i[l])) {
        var f = i[l] / 180 * Qo;
        c += Xo(f) * n[0], u += Zo(f) * n[0];
      }
    }

    var h = s.alpha() * n[0];
    e.forEach(function (e, r) {
      var o = e.get(t);
      h += e.alpha() * n[r + 1];

      for (var s = 0; s < i.length; s++) {
        if (!isNaN(o[s])) if (a[s] += n[r + 1], "h" === t.charAt(s)) {
          var l = o[s] / 180 * Qo;
          c += Xo(l) * n[r + 1], u += Zo(l) * n[r + 1];
        } else i[s] += o[s] * n[r + 1];
      }
    });

    for (var d = 0; d < i.length; d++) {
      if ("h" === t.charAt(d)) {
        for (var p = es(u / a[d], c / a[d]) / Qo * 180; p < 0;) {
          p += 360;
        }

        for (; p >= 360;) {
          p -= 360;
        }

        i[d] = p;
      } else i[d] = i[d] / a[d];
    }

    return h /= r, new zo(i, t).alpha(h > .99999 ? 1 : h, !0);
  },
      ns = function ns(e, t) {
    for (var n = e.length, r = [0, 0, 0, 0], o = 0; o < e.length; o++) {
      var s = e[o],
          i = t[o] / n,
          a = s._rgb;
      r[0] += Go(a[0], 2) * i, r[1] += Go(a[1], 2) * i, r[2] += Go(a[2], 2) * i, r[3] += a[3] * i;
    }

    return r[0] = Yo(r[0]), r[1] = Yo(r[1]), r[2] = Yo(r[2]), r[3] > .9999999 && (r[3] = 1), new zo(Jo(r));
  },
      rs = k,
      os = d.type,
      ss = Math.pow,
      is = function is(e) {
    var t = "rgb",
        n = rs("#ccc"),
        r = 0,
        o = [0, 1],
        s = [],
        i = [0, 0],
        a = !1,
        c = [],
        u = !1,
        l = 0,
        f = 1,
        h = !1,
        d = {},
        p = !0,
        g = 1,
        m = function m(e) {
      if ((e = e || ["#fff", "#000"]) && "string" === os(e) && rs.brewer && rs.brewer[e.toLowerCase()] && (e = rs.brewer[e.toLowerCase()]), "array" === os(e)) {
        1 === e.length && (e = [e[0], e[0]]), e = e.slice(0);

        for (var t = 0; t < e.length; t++) {
          e[t] = rs(e[t]);
        }

        s.length = 0;

        for (var n = 0; n < e.length; n++) {
          s.push(n / (e.length - 1));
        }
      }

      return w(), c = e;
    },
        y = function y(e) {
      if (null != a) {
        for (var t = a.length - 1, n = 0; n < t && e >= a[n];) {
          n++;
        }

        return n - 1;
      }

      return 0;
    },
        v = function v(e) {
      return e;
    },
        b = function b(e) {
      return e;
    },
        _ = function _(e, r) {
      var o, u;
      if (null == r && (r = !1), isNaN(e) || null === e) return n;
      u = r ? e : a && a.length > 2 ? y(e) / (a.length - 2) : f !== l ? (e - l) / (f - l) : 1, u = b(u), r || (u = v(u)), 1 !== g && (u = ss(u, g)), u = i[0] + u * (1 - i[0] - i[1]), u = Math.min(1, Math.max(0, u));
      var h = Math.floor(1e4 * u);
      if (p && d[h]) o = d[h];else {
        if ("array" === os(c)) for (var m = 0; m < s.length; m++) {
          var _ = s[m];

          if (u <= _) {
            o = c[m];
            break;
          }

          if (u >= _ && m === s.length - 1) {
            o = c[m];
            break;
          }

          if (u > _ && u < s[m + 1]) {
            u = (u - _) / (s[m + 1] - _), o = rs.interpolate(c[m], c[m + 1], u, t);
            break;
          }
        } else "function" === os(c) && (o = c(u));
        p && (d[h] = o);
      }
      return o;
    },
        w = function w() {
      return d = {};
    };

    m(e);

    var k = function k(e) {
      var t = rs(_(e));
      return u && t[u] ? t[u]() : t;
    };

    return k.classes = function (e) {
      if (null != e) {
        if ("array" === os(e)) a = e, o = [e[0], e[e.length - 1]];else {
          var t = rs.analyze(o);
          a = 0 === e ? [t.min, t.max] : rs.limits(t, "e", e);
        }
        return k;
      }

      return a;
    }, k.domain = function (e) {
      if (!arguments.length) return o;
      l = e[0], f = e[e.length - 1], s = [];
      var t = c.length;
      if (e.length === t && l !== f) for (var n = 0, r = Array.from(e); n < r.length; n += 1) {
        var i = r[n];
        s.push((i - l) / (f - l));
      } else {
        for (var a = 0; a < t; a++) {
          s.push(a / (t - 1));
        }

        if (e.length > 2) {
          var u = e.map(function (t, n) {
            return n / (e.length - 1);
          }),
              h = e.map(function (e) {
            return (e - l) / (f - l);
          });
          h.every(function (e, t) {
            return u[t] === e;
          }) || (b = function b(e) {
            if (e <= 0 || e >= 1) return e;

            for (var t = 0; e >= h[t + 1];) {
              t++;
            }

            var n = (e - h[t]) / (h[t + 1] - h[t]);
            return u[t] + n * (u[t + 1] - u[t]);
          });
        }
      }
      return o = [l, f], k;
    }, k.mode = function (e) {
      return arguments.length ? (t = e, w(), k) : t;
    }, k.range = function (e, t) {
      return m(e), k;
    }, k.out = function (e) {
      return u = e, k;
    }, k.spread = function (e) {
      return arguments.length ? (r = e, k) : r;
    }, k.correctLightness = function (e) {
      return null == e && (e = !0), h = e, w(), v = h ? function (e) {
        for (var t = _(0, !0).lab()[0], n = _(1, !0).lab()[0], r = t > n, o = _(e, !0).lab()[0], s = t + (n - t) * e, i = o - s, a = 0, c = 1, u = 20; Math.abs(i) > .01 && u-- > 0;) {
          r && (i *= -1), i < 0 ? (a = e, e += .5 * (c - e)) : (c = e, e += .5 * (a - e)), o = _(e, !0).lab()[0], i = o - s;
        }

        return e;
      } : function (e) {
        return e;
      }, k;
    }, k.padding = function (e) {
      return null != e ? ("number" === os(e) && (e = [e, e]), i = e, k) : i;
    }, k.colors = function (t, n) {
      arguments.length < 2 && (n = "hex");
      var r = [];
      if (0 === arguments.length) r = c.slice(0);else if (1 === t) r = [k(.5)];else if (t > 1) {
        var s = o[0],
            i = o[1] - s;
        r = as(0, t, !1).map(function (e) {
          return k(s + e / (t - 1) * i);
        });
      } else {
        e = [];
        var u = [];
        if (a && a.length > 2) for (var l = 1, f = a.length, h = 1 <= f; h ? l < f : l > f; h ? l++ : l--) {
          u.push(.5 * (a[l - 1] + a[l]));
        } else u = o;
        r = u.map(function (e) {
          return k(e);
        });
      }
      return rs[n] && (r = r.map(function (e) {
        return e[n]();
      })), r;
    }, k.cache = function (e) {
      return null != e ? (p = e, k) : p;
    }, k.gamma = function (e) {
      return null != e ? (g = e, k) : g;
    }, k.nodata = function (e) {
      return null != e ? (n = rs(e), k) : n;
    }, k;
  };

  function as(e, t, n) {
    for (var r = [], o = e < t, s = n ? o ? t + 1 : t - 1 : t, i = e; o ? i < s : i > s; o ? i++ : i--) {
      r.push(i);
    }

    return r;
  }

  var cs = _,
      us = is,
      ls = function ls(e) {
    for (var t = [1, 1], n = 1; n < e; n++) {
      for (var r = [1], o = 1; o <= t.length; o++) {
        r[o] = (t[o] || 0) + t[o - 1];
      }

      t = r;
    }

    return t;
  },
      fs = function fs(e) {
    var t, n, r, o, s, i, a;
    if (2 === (e = e.map(function (e) {
      return new cs(e);
    })).length) t = e.map(function (e) {
      return e.lab();
    }), s = t[0], i = t[1], o = function o(e) {
      var t = [0, 1, 2].map(function (t) {
        return s[t] + e * (i[t] - s[t]);
      });
      return new cs(t, "lab");
    };else if (3 === e.length) n = e.map(function (e) {
      return e.lab();
    }), s = n[0], i = n[1], a = n[2], o = function o(e) {
      var t = [0, 1, 2].map(function (t) {
        return (1 - e) * (1 - e) * s[t] + 2 * (1 - e) * e * i[t] + e * e * a[t];
      });
      return new cs(t, "lab");
    };else if (4 === e.length) {
      var c;
      r = e.map(function (e) {
        return e.lab();
      }), s = r[0], i = r[1], a = r[2], c = r[3], o = function o(e) {
        var t = [0, 1, 2].map(function (t) {
          return (1 - e) * (1 - e) * (1 - e) * s[t] + 3 * (1 - e) * (1 - e) * e * i[t] + 3 * (1 - e) * e * e * a[t] + e * e * e * c[t];
        });
        return new cs(t, "lab");
      };
    } else {
      if (!(e.length >= 5)) throw new RangeError("No point in running bezier with only one color.");
      var u, l, f;
      u = e.map(function (e) {
        return e.lab();
      }), f = e.length - 1, l = ls(f), o = function o(e) {
        var t = 1 - e,
            n = [0, 1, 2].map(function (n) {
          return u.reduce(function (r, o, s) {
            return r + l[s] * Math.pow(t, f - s) * Math.pow(e, s) * o[n];
          }, 0);
        });
        return new cs(n, "lab");
      };
    }
    return o;
  },
      hs = function hs(e) {
    var t = fs(e);
    return t.scale = function () {
      return us(t);
    }, t;
  },
      ds = k,
      ps = function ps(e, t, n) {
    if (!ps[n]) throw new Error("unknown blend mode " + n);
    return ps[n](e, t);
  },
      gs = function gs(e) {
    return function (t, n) {
      var r = ds(n).rgb(),
          o = ds(t).rgb();
      return ds.rgb(e(r, o));
    };
  },
      ms = function ms(e) {
    return function (t, n) {
      var r = [];
      return r[0] = e(t[0], n[0]), r[1] = e(t[1], n[1]), r[2] = e(t[2], n[2]), r;
    };
  },
      ys = function ys(e) {
    return e;
  },
      vs = function vs(e, t) {
    return e * t / 255;
  },
      bs = function bs(e, t) {
    return e > t ? t : e;
  },
      _s = function _s(e, t) {
    return e > t ? e : t;
  },
      ws = function ws(e, t) {
    return 255 * (1 - (1 - e / 255) * (1 - t / 255));
  },
      ks = function ks(e, t) {
    return t < 128 ? 2 * e * t / 255 : 255 * (1 - 2 * (1 - e / 255) * (1 - t / 255));
  },
      xs = function xs(e, t) {
    return 255 * (1 - (1 - t / 255) / (e / 255));
  },
      Ss = function Ss(e, t) {
    return 255 === e || (e = t / 255 * 255 / (1 - e / 255)) > 255 ? 255 : e;
  };

  ps.normal = gs(ms(ys)), ps.multiply = gs(ms(vs)), ps.screen = gs(ms(ws)), ps.overlay = gs(ms(ks)), ps.darken = gs(ms(bs)), ps.lighten = gs(ms(_s)), ps.dodge = gs(ms(Ss)), ps.burn = gs(ms(xs));

  for (var Ps = ps, As = d.type, Os = d.clip_rgb, Is = d.TWOPI, Ts = Math.pow, Cs = Math.sin, Es = Math.cos, Ms = k, Ls = function Ls(e, t, n, r, o) {
    void 0 === e && (e = 300), void 0 === t && (t = -1.5), void 0 === n && (n = 1), void 0 === r && (r = 1), void 0 === o && (o = [0, 1]);
    var s,
        i = 0;
    "array" === As(o) ? s = o[1] - o[0] : (s = 0, o = [o, o]);

    var a = function a(_a8) {
      var c = Is * ((e + 120) / 360 + t * _a8),
          u = Ts(o[0] + s * _a8, r),
          l = (0 !== i ? n[0] + _a8 * i : n) * u * (1 - u) / 2,
          f = Es(c),
          h = Cs(c);
      return Ms(Os([255 * (u + l * (-.14861 * f + 1.78277 * h)), 255 * (u + l * (-.29227 * f - .90649 * h)), 255 * (u + l * (1.97294 * f)), 1]));
    };

    return a.start = function (t) {
      return null == t ? e : (e = t, a);
    }, a.rotations = function (e) {
      return null == e ? t : (t = e, a);
    }, a.gamma = function (e) {
      return null == e ? r : (r = e, a);
    }, a.hue = function (e) {
      return null == e ? n : ("array" === As(n = e) ? 0 == (i = n[1] - n[0]) && (n = n[1]) : i = 0, a);
    }, a.lightness = function (e) {
      return null == e ? o : ("array" === As(e) ? (o = e, s = e[1] - e[0]) : (o = [e, e], s = 0), a);
    }, a.scale = function () {
      return Ms.scale(a);
    }, a.hue(n), a;
  }, $s = _, Rs = "0123456789abcdef", Ns = Math.floor, js = Math.random, Ds = function Ds() {
    for (var e = "#", t = 0; t < 6; t++) {
      e += Rs.charAt(Ns(16 * js()));
    }

    return new $s(e, "hex");
  }, Us = a, Fs = Math.log, qs = Math.pow, Bs = Math.floor, Hs = Math.abs, Ks = function Ks(e, t) {
    void 0 === t && (t = null);
    var n = {
      min: Number.MAX_VALUE,
      max: -1 * Number.MAX_VALUE,
      sum: 0,
      values: [],
      count: 0
    };
    return "object" === Us(e) && (e = Object.values(e)), e.forEach(function (e) {
      t && "object" === Us(e) && (e = e[t]), null == e || isNaN(e) || (n.values.push(e), n.sum += e, e < n.min && (n.min = e), e > n.max && (n.max = e), n.count += 1);
    }), n.domain = [n.min, n.max], n.limits = function (e, t) {
      return Vs(n, e, t);
    }, n;
  }, Vs = function Vs(e, t, n) {
    void 0 === t && (t = "equal"), void 0 === n && (n = 7), "array" == Us(e) && (e = Ks(e));
    var r = e.min,
        o = e.max,
        s = e.values.sort(function (e, t) {
      return e - t;
    });
    if (1 === n) return [r, o];
    var i = [];

    if ("c" === t.substr(0, 1) && (i.push(r), i.push(o)), "e" === t.substr(0, 1)) {
      i.push(r);

      for (var a = 1; a < n; a++) {
        i.push(r + a / n * (o - r));
      }

      i.push(o);
    } else if ("l" === t.substr(0, 1)) {
      if (r <= 0) throw new Error("Logarithmic scales are only possible for values > 0");
      var c = Math.LOG10E * Fs(r),
          u = Math.LOG10E * Fs(o);
      i.push(r);

      for (var l = 1; l < n; l++) {
        i.push(qs(10, c + l / n * (u - c)));
      }

      i.push(o);
    } else if ("q" === t.substr(0, 1)) {
      i.push(r);

      for (var f = 1; f < n; f++) {
        var h = (s.length - 1) * f / n,
            d = Bs(h);
        if (d === h) i.push(s[d]);else {
          var p = h - d;
          i.push(s[d] * (1 - p) + s[d + 1] * p);
        }
      }

      i.push(o);
    } else if ("k" === t.substr(0, 1)) {
      var g,
          m = s.length,
          y = new Array(m),
          v = new Array(n),
          b = !0,
          _ = 0,
          w = null;
      (w = []).push(r);

      for (var k = 1; k < n; k++) {
        w.push(r + k / n * (o - r));
      }

      for (w.push(o); b;) {
        for (var x = 0; x < n; x++) {
          v[x] = 0;
        }

        for (var S = 0; S < m; S++) {
          for (var P = s[S], A = Number.MAX_VALUE, O = void 0, I = 0; I < n; I++) {
            var T = Hs(w[I] - P);
            T < A && (A = T, O = I), v[O]++, y[S] = O;
          }
        }

        for (var C = new Array(n), E = 0; E < n; E++) {
          C[E] = null;
        }

        for (var M = 0; M < m; M++) {
          null === C[g = y[M]] ? C[g] = s[M] : C[g] += s[M];
        }

        for (var L = 0; L < n; L++) {
          C[L] *= 1 / v[L];
        }

        b = !1;

        for (var $ = 0; $ < n; $++) {
          if (C[$] !== w[$]) {
            b = !0;
            break;
          }
        }

        w = C, ++_ > 200 && (b = !1);
      }

      for (var R = {}, N = 0; N < n; N++) {
        R[N] = [];
      }

      for (var j = 0; j < m; j++) {
        R[g = y[j]].push(s[j]);
      }

      for (var D = [], U = 0; U < n; U++) {
        D.push(R[U][0]), D.push(R[U][R[U].length - 1]);
      }

      D = D.sort(function (e, t) {
        return e - t;
      }), i.push(D[0]);

      for (var F = 1; F < D.length; F += 2) {
        var q = D[F];
        isNaN(q) || -1 !== i.indexOf(q) || i.push(q);
      }
    }

    return i;
  }, Ws = {
    analyze: Ks,
    limits: Vs
  }, zs = _, Js = function Js(e, t) {
    e = new zs(e), t = new zs(t);
    var n = e.luminance(),
        r = t.luminance();
    return n > r ? (n + .05) / (r + .05) : (r + .05) / (n + .05);
  }, Gs = _, Ys = Math.sqrt, Qs = Math.pow, Xs = Math.min, Zs = Math.max, ei = Math.atan2, ti = Math.abs, ni = Math.cos, ri = Math.sin, oi = Math.exp, si = Math.PI, ii = function ii(e, t, n, r, o) {
    void 0 === n && (n = 1), void 0 === r && (r = 1), void 0 === o && (o = 1);

    var s = function s(e) {
      return 360 * e / (2 * si);
    },
        i = function i(e) {
      return 2 * si * e / 360;
    };

    e = new Gs(e), t = new Gs(t);

    var a = Array.from(e.lab()),
        c = a[0],
        u = a[1],
        l = a[2],
        f = Array.from(t.lab()),
        h = f[0],
        d = f[1],
        p = f[2],
        g = (c + h) / 2,
        m = (Ys(Qs(u, 2) + Qs(l, 2)) + Ys(Qs(d, 2) + Qs(p, 2))) / 2,
        y = .5 * (1 - Ys(Qs(m, 7) / (Qs(m, 7) + Qs(25, 7)))),
        v = u * (1 + y),
        b = d * (1 + y),
        _ = Ys(Qs(v, 2) + Qs(l, 2)),
        w = Ys(Qs(b, 2) + Qs(p, 2)),
        k = (_ + w) / 2,
        x = s(ei(l, v)),
        S = s(ei(p, b)),
        P = x >= 0 ? x : x + 360,
        A = S >= 0 ? S : S + 360,
        O = ti(P - A) > 180 ? (P + A + 360) / 2 : (P + A) / 2,
        I = 1 - .17 * ni(i(O - 30)) + .24 * ni(i(2 * O)) + .32 * ni(i(3 * O + 6)) - .2 * ni(i(4 * O - 63)),
        T = A - P;

    T = ti(T) <= 180 ? T : A <= P ? T + 360 : T - 360, T = 2 * Ys(_ * w) * ri(i(T) / 2);
    var C = h - c,
        E = w - _,
        M = 1 + .015 * Qs(g - 50, 2) / Ys(20 + Qs(g - 50, 2)),
        L = 1 + .045 * k,
        $ = 1 + .015 * k * I,
        R = 30 * oi(-Qs((O - 275) / 25, 2)),
        N = -2 * Ys(Qs(k, 7) / (Qs(k, 7) + Qs(25, 7))) * ri(2 * i(R)),
        j = Ys(Qs(C / (n * M), 2) + Qs(E / (r * L), 2) + Qs(T / (o * $), 2) + N * (E / (r * L)) * (T / (o * $)));
    return Zs(0, Xs(100, j));
  }, ai = _, ci = function ci(e, t, n) {
    void 0 === n && (n = "lab"), e = new ai(e), t = new ai(t);
    var r = e.get(n),
        o = t.get(n),
        s = 0;

    for (var i in r) {
      var a = (r[i] || 0) - (o[i] || 0);
      s += a * a;
    }

    return Math.sqrt(s);
  }, ui = _, li = function li() {
    for (var e = [], t = arguments.length; t--;) {
      e[t] = arguments[t];
    }

    try {
      return new (Function.prototype.bind.apply(ui, [null].concat(e)))(), !0;
    } catch (Mc) {
      return !1;
    }
  }, fi = k, hi = is, di = {
    cool: function cool() {
      return hi([fi.hsl(180, 1, .9), fi.hsl(250, .7, .4)]);
    },
    hot: function hot() {
      return hi(["#000", "#f00", "#ff0", "#fff"]).mode("rgb");
    }
  }, pi = {
    OrRd: ["#fff7ec", "#fee8c8", "#fdd49e", "#fdbb84", "#fc8d59", "#ef6548", "#d7301f", "#b30000", "#7f0000"],
    PuBu: ["#fff7fb", "#ece7f2", "#d0d1e6", "#a6bddb", "#74a9cf", "#3690c0", "#0570b0", "#045a8d", "#023858"],
    BuPu: ["#f7fcfd", "#e0ecf4", "#bfd3e6", "#9ebcda", "#8c96c6", "#8c6bb1", "#88419d", "#810f7c", "#4d004b"],
    Oranges: ["#fff5eb", "#fee6ce", "#fdd0a2", "#fdae6b", "#fd8d3c", "#f16913", "#d94801", "#a63603", "#7f2704"],
    BuGn: ["#f7fcfd", "#e5f5f9", "#ccece6", "#99d8c9", "#66c2a4", "#41ae76", "#238b45", "#006d2c", "#00441b"],
    YlOrBr: ["#ffffe5", "#fff7bc", "#fee391", "#fec44f", "#fe9929", "#ec7014", "#cc4c02", "#993404", "#662506"],
    YlGn: ["#ffffe5", "#f7fcb9", "#d9f0a3", "#addd8e", "#78c679", "#41ab5d", "#238443", "#006837", "#004529"],
    Reds: ["#fff5f0", "#fee0d2", "#fcbba1", "#fc9272", "#fb6a4a", "#ef3b2c", "#cb181d", "#a50f15", "#67000d"],
    RdPu: ["#fff7f3", "#fde0dd", "#fcc5c0", "#fa9fb5", "#f768a1", "#dd3497", "#ae017e", "#7a0177", "#49006a"],
    Greens: ["#f7fcf5", "#e5f5e0", "#c7e9c0", "#a1d99b", "#74c476", "#41ab5d", "#238b45", "#006d2c", "#00441b"],
    YlGnBu: ["#ffffd9", "#edf8b1", "#c7e9b4", "#7fcdbb", "#41b6c4", "#1d91c0", "#225ea8", "#253494", "#081d58"],
    Purples: ["#fcfbfd", "#efedf5", "#dadaeb", "#bcbddc", "#9e9ac8", "#807dba", "#6a51a3", "#54278f", "#3f007d"],
    GnBu: ["#f7fcf0", "#e0f3db", "#ccebc5", "#a8ddb5", "#7bccc4", "#4eb3d3", "#2b8cbe", "#0868ac", "#084081"],
    Greys: ["#ffffff", "#f0f0f0", "#d9d9d9", "#bdbdbd", "#969696", "#737373", "#525252", "#252525", "#000000"],
    YlOrRd: ["#ffffcc", "#ffeda0", "#fed976", "#feb24c", "#fd8d3c", "#fc4e2a", "#e31a1c", "#bd0026", "#800026"],
    PuRd: ["#f7f4f9", "#e7e1ef", "#d4b9da", "#c994c7", "#df65b0", "#e7298a", "#ce1256", "#980043", "#67001f"],
    Blues: ["#f7fbff", "#deebf7", "#c6dbef", "#9ecae1", "#6baed6", "#4292c6", "#2171b5", "#08519c", "#08306b"],
    PuBuGn: ["#fff7fb", "#ece2f0", "#d0d1e6", "#a6bddb", "#67a9cf", "#3690c0", "#02818a", "#016c59", "#014636"],
    Viridis: ["#440154", "#482777", "#3f4a8a", "#31678e", "#26838f", "#1f9d8a", "#6cce5a", "#b6de2b", "#fee825"],
    Spectral: ["#9e0142", "#d53e4f", "#f46d43", "#fdae61", "#fee08b", "#ffffbf", "#e6f598", "#abdda4", "#66c2a5", "#3288bd", "#5e4fa2"],
    RdYlGn: ["#a50026", "#d73027", "#f46d43", "#fdae61", "#fee08b", "#ffffbf", "#d9ef8b", "#a6d96a", "#66bd63", "#1a9850", "#006837"],
    RdBu: ["#67001f", "#b2182b", "#d6604d", "#f4a582", "#fddbc7", "#f7f7f7", "#d1e5f0", "#92c5de", "#4393c3", "#2166ac", "#053061"],
    PiYG: ["#8e0152", "#c51b7d", "#de77ae", "#f1b6da", "#fde0ef", "#f7f7f7", "#e6f5d0", "#b8e186", "#7fbc41", "#4d9221", "#276419"],
    PRGn: ["#40004b", "#762a83", "#9970ab", "#c2a5cf", "#e7d4e8", "#f7f7f7", "#d9f0d3", "#a6dba0", "#5aae61", "#1b7837", "#00441b"],
    RdYlBu: ["#a50026", "#d73027", "#f46d43", "#fdae61", "#fee090", "#ffffbf", "#e0f3f8", "#abd9e9", "#74add1", "#4575b4", "#313695"],
    BrBG: ["#543005", "#8c510a", "#bf812d", "#dfc27d", "#f6e8c3", "#f5f5f5", "#c7eae5", "#80cdc1", "#35978f", "#01665e", "#003c30"],
    RdGy: ["#67001f", "#b2182b", "#d6604d", "#f4a582", "#fddbc7", "#ffffff", "#e0e0e0", "#bababa", "#878787", "#4d4d4d", "#1a1a1a"],
    PuOr: ["#7f3b08", "#b35806", "#e08214", "#fdb863", "#fee0b6", "#f7f7f7", "#d8daeb", "#b2abd2", "#8073ac", "#542788", "#2d004b"],
    Set2: ["#66c2a5", "#fc8d62", "#8da0cb", "#e78ac3", "#a6d854", "#ffd92f", "#e5c494", "#b3b3b3"],
    Accent: ["#7fc97f", "#beaed4", "#fdc086", "#ffff99", "#386cb0", "#f0027f", "#bf5b17", "#666666"],
    Set1: ["#e41a1c", "#377eb8", "#4daf4a", "#984ea3", "#ff7f00", "#ffff33", "#a65628", "#f781bf", "#999999"],
    Set3: ["#8dd3c7", "#ffffb3", "#bebada", "#fb8072", "#80b1d3", "#fdb462", "#b3de69", "#fccde5", "#d9d9d9", "#bc80bd", "#ccebc5", "#ffed6f"],
    Dark2: ["#1b9e77", "#d95f02", "#7570b3", "#e7298a", "#66a61e", "#e6ab02", "#a6761d", "#666666"],
    Paired: ["#a6cee3", "#1f78b4", "#b2df8a", "#33a02c", "#fb9a99", "#e31a1c", "#fdbf6f", "#ff7f00", "#cab2d6", "#6a3d9a", "#ffff99", "#b15928"],
    Pastel2: ["#b3e2cd", "#fdcdac", "#cbd5e8", "#f4cae4", "#e6f5c9", "#fff2ae", "#f1e2cc", "#cccccc"],
    Pastel1: ["#fbb4ae", "#b3cde3", "#ccebc5", "#decbe4", "#fed9a6", "#ffffcc", "#e5d8bd", "#fddaec", "#f2f2f2"]
  }, gi = 0, mi = Object.keys(pi); gi < mi.length; gi += 1) {
    var yi = mi[gi];
    pi[yi.toLowerCase()] = pi[yi];
  }

  var vi = pi,
      bi = k;
  return bi.average = ts, bi.bezier = hs, bi.blend = Ps, bi.cubehelix = Ls, bi.mix = bi.interpolate = ho, bi.random = Ds, bi.scale = is, bi.analyze = Ws.analyze, bi.contrast = Js, bi.deltaE = ii, bi.distance = ci, bi.limits = Ws.limits, bi.valid = li, bi.scales = di, bi.colors = jn, bi.brewer = vi, bi;
}();var mf = gf;exports.Ds = Vl, exports._export_sfc = function (e, t) {
  var n = e.__vccOpts || e;

  var _iterator8 = _createForOfIteratorHelper2(t),
      _step8;

  try {
    for (_iterator8.s(); !(_step8 = _iterator8.n()).done;) {
      var _step8$value = _slicedToArray2(_step8.value, 2),
          _r44 = _step8$value[0],
          _o31 = _step8$value[1];

      n[_r44] = _o31;
    }
  } catch (err) {
    _iterator8.e(err);
  } finally {
    _iterator8.f();
  }

  return n;
}, exports.chroma = mf, exports.computed = Fs, exports.createSSRApp = Mi, exports.createStore = function (e) {
  return new of(e);
}, exports.e = function (e) {
  for (var _len18 = arguments.length, t = new Array(_len18 > 1 ? _len18 - 1 : 0), _key18 = 1; _key18 < _len18; _key18++) {
    t[_key18 - 1] = arguments[_key18];
  }

  return g.apply(void 0, [e].concat(t));
}, exports.f = function (e, t) {
  return function (e, t) {
    var n;

    if (b(e) || x(e)) {
      n = new Array(e.length);

      for (var _r45 = 0, _o32 = e.length; _r45 < _o32; _r45++) {
        n[_r45] = t(e[_r45], _r45, _r45);
      }
    } else if ("number" == typeof e) {
      n = new Array(e);

      for (var _r46 = 0; _r46 < e; _r46++) {
        n[_r46] = t(_r46 + 1, _r46, _r46);
      }
    } else if (P(e)) {
      if (e[Symbol.iterator]) n = Array.from(e, function (e, n) {
        return t(e, n, n);
      });else {
        var _r47 = Object.keys(e);

        n = new Array(_r47.length);

        for (var _o33 = 0, _s19 = _r47.length; _o33 < _s19; _o33++) {
          var _s20 = _r47[_o33];
          n[_o33] = t(e[_s20], _s20, _o33);
        }
      }
    } else n = [];

    return n;
  }(e, t);
}, exports.getCurrentInstance = Ms, exports.index = On, exports.initVueI18n = qe, exports.mapGetters = uf, exports.mapMutations = cf, exports.mapState = af, exports.messages = pf, exports.n = function (e) {
  return i(e);
}, exports.nextTick$1 = yo, exports.o = function (e, t) {
  return Oi(e, t);
}, exports.onMounted = Ko, exports.onUnmounted = Jo, exports.p = function (e) {
  return function (e) {
    var _Ms = Ms(),
        t = _Ms.uid,
        n = _Ms.__counter;

    return t + "," + ((xi[t] || (xi[t] = [])).push(Os(e)) - 1) + "," + n;
  }(e);
}, exports.r = function (e, t, n) {
  return Ti(e, t, n);
}, exports.ref = Jr, exports.resolveComponent = function (e, t) {
  return function (e, t) {
    var n = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : !0;
    var r = arguments.length > 3 && arguments[3] !== undefined ? arguments[3] : !1;
    var o = Io || Es;

    if (o) {
      var _n49 = o.type;

      if (e === Zo) {
        var _e57 = function (e) {
          var t = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : !0;
          return k(e) ? e.displayName || e.name : e.name || t && e.__name;
        }(_n49, !1);

        if (_e57 && (_e57 === t || _e57 === $(t) || _e57 === j($(t)))) return _n49;
      }

      var _s21 = es(o[e] || _n49[e], t) || es(o.appContext[e], t);

      return !_s21 && r ? _n49 : _s21;
    }
  }(Zo, e, !0, t) || e;
}, exports.s = function (e) {
  return Ei(e);
}, exports.shallowSsrRef = function (e, t) {
  return df(e, t, !0);
}, exports.sr = function (e, t, n) {
  return function (e, t) {
    var n = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : {};

    var _Ms2 = Ms(),
        r = _Ms2.$templateRefs;

    r.push({
      i: t,
      r: e,
      k: n.k,
      f: n.f
    });
  }(e, t, n);
}, exports.ssrRef = function (e, t) {
  return df(e, t);
}, exports.t = function (e) {
  return function (e) {
    return x(e) ? e : null == e ? "" : b(e) || P(e) && (e.toString === O || !k(e.toString)) ? JSON.stringify(e, a, 2) : String(e);
  }(e);
}, exports.toRefs = function (e) {
  var t = b(e) ? new Array(e.length) : {};

  for (var _n50 in e) {
    t[_n50] = to(e, _n50);
  }

  return t;
}, exports.w = function (e, t) {
  return Ci(e, t);
}, exports.watch = Mo, exports.wx$1 = An;