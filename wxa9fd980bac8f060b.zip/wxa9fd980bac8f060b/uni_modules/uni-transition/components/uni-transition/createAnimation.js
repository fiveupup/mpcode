var _objectSpread2 = require("../../../../@babel/runtime/helpers/objectSpread2");require("../../../../@babel/runtime/helpers/Arrayincludes");var _classCallCheck2 = require("../../../../@babel/runtime/helpers/classCallCheck");var _createClass2 = require("../../../../@babel/runtime/helpers/createClass");var t = require("../../../../common/vendor.js");var e = /*#__PURE__*/function () {
  function e(_e, i) {
    _classCallCheck2(this, e);

    this.options = _e, this.animation = t.index.createAnimation(_e), this.currentStepAnimates = {}, this.next = 0, this.$ = i;
  }

  _createClass2(e, [{
    key: "_nvuePushAnimates",
    value: function _nvuePushAnimates(t, _e2) {
      var n = this.currentStepAnimates[this.next],
          s = {};

      if (s = n || {
        styles: {},
        config: {}
      }, i.includes(t)) {
        s.styles.transform || (s.styles.transform = "");
        var _i = "";
        "rotate" === t && (_i = "deg"), s.styles.transform += "".concat(t, "(").concat(_e2 + _i, ") ");
      } else s.styles[t] = "".concat(_e2);

      this.currentStepAnimates[this.next] = s;
    }
  }, {
    key: "_animateRun",
    value: function _animateRun() {
      var t = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {};

      var _e3 = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : {};

      var i = this.$.$refs.ani.ref;
      if (i) return new Promise(function (n, s) {
        nvueAnimation.transition(i, _objectSpread2({
          styles: t
        }, _e3), function (t) {
          n();
        });
      });
    }
  }, {
    key: "_nvueNextAnimate",
    value: function _nvueNextAnimate(t) {
      var _this = this;

      var _e4 = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : 0;

      var i = arguments.length > 2 ? arguments[2] : undefined;
      var n = t[_e4];

      if (n) {
        var s = n.styles,
            a = n.config;

        this._animateRun(s, a).then(function () {
          _e4 += 1, _this._nvueNextAnimate(t, _e4, i);
        });
      } else this.currentStepAnimates = {}, "function" == typeof i && i(), this.isEnd = !0;
    }
  }, {
    key: "step",
    value: function step() {
      var t = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {};
      return this.animation.step(t), this;
    }
  }, {
    key: "run",
    value: function run(t) {
      this.$.animationData = this.animation.export(), this.$.timer = setTimeout(function () {
        "function" == typeof t && t();
      }, this.$.durationTime);
    }
  }]);

  return e;
}();var i = ["matrix", "matrix3d", "rotate", "rotate3d", "rotateX", "rotateY", "rotateZ", "scale", "scale3d", "scaleX", "scaleY", "scaleZ", "skew", "skewX", "skewY", "translate", "translate3d", "translateX", "translateY", "translateZ"];i.concat(["opacity", "backgroundColor"], ["width", "height", "left", "right", "top", "bottom"]).forEach(function (t) {
  e.prototype[t] = function () {
    var _this$animation;

    return (_this$animation = this.animation)[t].apply(_this$animation, arguments), this;
  };
}), exports.createAnimation = function (t, i) {
  if (i) return clearTimeout(i.timer), new e(t, i);
};