var e = require("../../../../common/vendor.js"),
    t = {
  name: "uniCollapse",
  emits: ["change", "activeItem", "input", "update:modelValue"],
  props: {
    value: {
      type: [String, Array],
      default: ""
    },
    modelValue: {
      type: [String, Array],
      default: ""
    },
    accordion: {
      type: [Boolean, String],
      default: !1
    }
  },
  data: function data() {
    return {};
  },
  computed: {
    dataValue: function dataValue() {
      var e = "string" == typeof this.value && "" === this.value || Array.isArray(this.value) && 0 === this.value.length;
      "string" == typeof this.modelValue && "" === this.modelValue || Array.isArray(this.modelValue) && this.modelValue.length;
      return e ? this.modelValue : this.value;
    }
  },
  watch: {
    dataValue: function dataValue(e) {
      this.setOpen(e);
    }
  },
  created: function created() {
    this.childrens = [], this.names = [];
  },
  mounted: function mounted() {
    var _this = this;

    this.$nextTick(function () {
      _this.setOpen(_this.dataValue);
    });
  },
  methods: {
    setOpen: function setOpen(e) {
      var _this2 = this;

      var t = "string" == typeof e,
          i = Array.isArray(e);
      this.childrens.forEach(function (a, n) {
        if (t && e === a.nameSync) {
          if (!_this2.accordion) return void console.warn("accordion 属性为 false ,v-model 类型应该为 array");
          a.isOpen = !0;
        }

        i && e.forEach(function (e) {
          if (e === a.nameSync) {
            if (_this2.accordion) return void console.warn("accordion 属性为 true ,v-model 类型应该为 string");
            a.isOpen = !0;
          }
        });
      }), this.emit(e);
    },
    setAccordion: function setAccordion(e) {
      this.accordion && this.childrens.forEach(function (t, i) {
        e !== t && (t.isOpen = !1);
      });
    },
    resize: function resize() {
      this.childrens.forEach(function (e, t) {
        e.getCollapseHeight();
      });
    },
    onChange: function onChange(e, t) {
      var i = [];
      this.accordion ? i = e ? t.nameSync : "" : this.childrens.forEach(function (e, t) {
        e.isOpen && i.push(e.nameSync);
      }), this.$emit("change", i), this.emit(i);
    },
    emit: function emit(e) {
      this.$emit("input", e), this.$emit("update:modelValue", e);
    }
  }
};var i = e._export_sfc(t, [["render", function (e, t, i, a, n, s) {
  return {};
}]]);wx.createComponent(i);