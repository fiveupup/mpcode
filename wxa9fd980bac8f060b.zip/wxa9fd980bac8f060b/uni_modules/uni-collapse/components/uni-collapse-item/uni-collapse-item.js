var e = require("../../../../common/vendor.js"),
    t = {
  name: "uniCollapseItem",
  props: {
    title: {
      type: String,
      default: ""
    },
    name: {
      type: [Number, String],
      default: ""
    },
    disabled: {
      type: Boolean,
      default: !1
    },
    showAnimation: {
      type: Boolean,
      default: !0
    },
    open: {
      type: Boolean,
      default: !1
    },
    thumb: {
      type: String,
      default: ""
    },
    titleBorder: {
      type: String,
      default: "auto"
    },
    border: {
      type: Boolean,
      default: !0
    },
    showArrow: {
      type: Boolean,
      default: !0
    }
  },
  data: function data() {
    return {
      isOpen: !1,
      isheight: null,
      height: 0,
      elId: "Uni_".concat(Math.ceil(1e6 * Math.random()).toString(36)),
      nameSync: 0
    };
  },
  watch: {
    open: function open(e) {
      this.isOpen = e, this.onClick(e, "init");
    }
  },
  updated: function updated(e) {
    var _this = this;

    this.$nextTick(function () {
      _this.init(!0);
    });
  },
  created: function created() {
    this.collapse = this.getCollapse(), this.oldHeight = 0, this.onClick(this.open, "init");
  },
  unmounted: function unmounted() {
    this.__isUnmounted = !0, this.uninstall();
  },
  mounted: function mounted() {
    this.collapse && ("" !== this.name ? this.nameSync = this.name : this.nameSync = this.collapse.childrens.length + "", -1 === this.collapse.names.indexOf(this.nameSync) ? this.collapse.names.push(this.nameSync) : console.warn("name \u503C ".concat(this.nameSync, " \u91CD\u590D")), -1 === this.collapse.childrens.indexOf(this) && this.collapse.childrens.push(this), this.init());
  },
  methods: {
    init: function init(e) {
      this.getCollapseHeight(e);
    },
    uninstall: function uninstall() {
      var _this2 = this;

      this.collapse && (this.collapse.childrens.forEach(function (e, t) {
        e === _this2 && _this2.collapse.childrens.splice(t, 1);
      }), this.collapse.names.forEach(function (e, t) {
        e === _this2.nameSync && _this2.collapse.names.splice(t, 1);
      }));
    },
    onClick: function onClick(e, t) {
      this.disabled || (this.isOpen = e, this.isOpen && this.collapse && this.collapse.setAccordion(this), "init" !== t && this.collapse.onChange(e, this));
    },
    getCollapseHeight: function getCollapseHeight(t) {
      var _this3 = this;

      var i = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : 0;
      e.index.createSelectorQuery().in(this).select("#".concat(this.elId)).fields({
        size: !0
      }, function (e) {
        if (!(i >= 10)) {
          if (!e) return i++, void _this3.getCollapseHeight(!1, i);
          _this3.height = e.height, _this3.isheight = !0, t || _this3.onClick(_this3.isOpen, "init");
        }
      }).exec();
    },
    getNvueHwight: function getNvueHwight(e) {
      var _this4 = this;

      dom.getComponentRect(this.$refs["collapse--hook"], function (t) {
        if (t && t.result && t.size) {
          if (_this4.height = t.size.height, _this4.isheight = !0, e) return;

          _this4.onClick(_this4.open, "init");
        }
      });
    },
    getCollapse: function getCollapse() {
      var e = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : "uniCollapse";
      var t = this.$parent,
          i = t.$options.name;

      for (; i !== e;) {
        if (t = t.$parent, !t) return !1;
        i = t.$options.name;
      }

      return t;
    }
  }
};if (!Array) {
  e.resolveComponent("uni-icons")();
}Math;var i = e._export_sfc(t, [["render", function (t, i, s, n, h, o) {
  return e.e({
    a: s.thumb
  }, s.thumb ? {
    b: s.thumb
  } : {}, {
    c: e.t(s.title),
    d: s.disabled ? 1 : "",
    e: s.showArrow
  }, s.showArrow ? {
    f: e.p({
      color: s.disabled ? "#ddd" : "#bbb",
      size: "14",
      type: "bottom"
    }),
    g: h.isOpen ? 1 : "",
    h: !0 === s.showAnimation ? 1 : ""
  } : {}, {
    i: e.o(function (e) {
      return o.onClick(!h.isOpen);
    }),
    j: h.isOpen && "auto" === s.titleBorder ? 1 : "",
    k: "none" !== s.titleBorder ? 1 : "",
    l: h.elId,
    m: h.isheight ? 1 : "",
    n: s.border && h.isOpen ? 1 : "",
    o: s.showAnimation ? 1 : "",
    p: (h.isOpen ? h.height : 0) + "px"
  });
}]]);wx.createComponent(i);