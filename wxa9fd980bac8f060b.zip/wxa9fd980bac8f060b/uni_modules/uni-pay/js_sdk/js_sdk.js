var e = require("../../../common/vendor.js");var t = {
  getWeixinCode: function getWeixinCode() {
    return new Promise(function (t, i) {
      e.index.login({
        provider: "weixin",
        success: function success(e) {
          t(e.code);
        },
        fail: function fail(e) {
          i(new Error("获取微信code失败"));
        }
      });
    });
  },
  getAlipayCode: function getAlipayCode() {},
  checkPlatform: function checkPlatform() {},
  getH5Env: function getH5Env() {
    var e = window.navigator.userAgent.toLowerCase();
    return "micromessenger" == e.match(/MicroMessenger/i) && "miniprogram" == e.match(/miniprogram/i) ? "mp-weixin" : "micromessenger" == e.match(/MicroMessenger/i) ? "h5-weixin" : "alipay" == e.match(/alipay/i) && "miniprogram" == e.match(/miniprogram/i) ? "mp-alipay" : "alipay" == e.match(/alipay/i) ? "h5-alipay" : "h5";
  },
  timeFormat: function timeFormat(e) {
    var t = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : "yyyy-MM-dd hh:mm:ss";
    var i = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : 8;

    try {
      if (!e) return "";
      var n;
      "string" != typeof e || isNaN(e) || (e = Number(e)), "number" == typeof e ? (10 == e.toString().length && (e *= 1e3), n = new Date(e)) : n = e;
      var r = 60 * n.getTimezoneOffset() * 1e3 + 60 * i * 60 * 1e3,
          o = n.getTime() + r;
      n = new Date(o);
      var a = {
        "M+": n.getMonth() + 1,
        "d+": n.getDate(),
        "h+": n.getHours(),
        "m+": n.getMinutes(),
        "s+": n.getSeconds(),
        "q+": Math.floor((n.getMonth() + 3) / 3),
        S: n.getMilliseconds()
      };
      /(y+)/.test(t) && (t = t.replace(RegExp.$1, (n.getFullYear() + "").substr(4 - RegExp.$1.length)));

      for (var _e in a) {
        new RegExp("(" + _e + ")").test(t) && (t = t.replace(RegExp.$1, 1 == RegExp.$1.length ? a[_e] : ("00" + a[_e]).substr(("" + a[_e]).length)));
      }

      return t;
    } catch (n) {
      return e;
    }
  }
};exports.util = t;