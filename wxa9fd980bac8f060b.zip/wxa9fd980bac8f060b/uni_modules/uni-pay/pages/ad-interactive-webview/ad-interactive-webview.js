var r = {
  data: function data() {
    return {
      url: ""
    };
  },
  onLoad: function onLoad(r) {
    r && r.url && (this.url = decodeURIComponent(r.url));
  }
};var e = require("../../../../common/vendor.js")._export_sfc(r, [["render", function (r, e, o, n, t, u) {
  return {
    a: t.url
  };
}]]);wx.createPage(e);