var _interopRequireDefault = require("../../../../@babel/runtime/helpers/interopRequireDefault");var _objectSpread2 = require("../../../../@babel/runtime/helpers/objectSpread2");var _regenerator = _interopRequireDefault(require("../../../../@babel/runtime/regenerator"));var _asyncToGenerator2 = require("../../../../@babel/runtime/helpers/asyncToGenerator");var e = require("../../../../common/vendor.js"),
    t = require("../../js_sdk/js_sdk.js"),
    r = e.Ds.importObject("uni-pay-co");var i;var o = {
  name: "uni-pay",
  emits: ["success", "cancel", "fail", "create", "mounted", "qrcode"],
  props: {
    adpid: {
      Type: String,
      default: ""
    },
    toSuccessPage: {
      Type: Boolean,
      default: !0
    },
    returnUrl: {
      Type: String,
      default: ""
    },
    mainColor: {
      Type: String,
      default: ""
    },
    mode: {
      Type: String,
      default: ""
    },
    logo: {
      Type: String,
      default: "/static/logo.png"
    },
    height: {
      Type: [String],
      default: "70vh"
    },
    debug: {
      Type: Boolean,
      default: !1
    }
  },
  data: function data() {
    return {
      options: {},
      res: {},
      images: {
        wxpay: "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAEAAAABACAYAAACqaXHeAAAAAXNSR0IArs4c6QAABC9JREFUeF7tWk1a20AMlUzv0bDr13AAYAOcpLCBcoqQU1DYEE6C2QAHIP26q3sPPOqniU2cZMYj+SeGxN5kEXlm9ObpjaQxwpY/uOX+Qw9Az4AtR6APgS0nQC+CfQi0FQLfrvcHXwAGPP4bQMK/fy5f7O9HehphwPfb/dOIogEhHQHBcamDCDESPoIxMQPTNSi1ABj+OrwDpNMaO5og4P2bMZOugFADwNTewWhU0/FVzAgnKZnxuoFQAbB3vX9MET7U2PHgq4R09vv8ZRI0bMhADMDw9uAhGN8NLQrWyAYRAGt1PgcRIU5TOms7JIIAdOL8nElJauikTRBKAdi7ObwioFFTzHaMw3mBzRV8DwKOXy+ertpagxcAq/YR/g2d6TlNrUDu4EiiE0Why4T1rgyINoXRC4DgjE+mF8+7RYAkp4RrRyVztRUKTgCkuz89fz4pAiB5z7WbklBrKxScAEgWxI6joZPXy5c4B0H0nkPdhzcHFIxxhHgZ8OA7AgMnAMObA479UnF6H5twQpF5RBMdibPDvB4AAAL6IZ0rNbTb9IngAyC8IwJ0K5okQBgzqFEKSV4wcXg17bxl8fIiJXFc0bHAgYLjYlHEFaZlVUQDoAIbcVZaN1VRrgAgUfImASiKW6Yh4pAohmHVQqpLABI0dMYiKhJPCeoV0ueuQsDmEJrkSeJ/bqNJnOqfApqVzWznzrdYWkvzhnUDYGnPKLTdV5gpfLiOqJUIaTefF8RKH6wxtAOX2IdA8NcCmmRItmBLfVF5jRBnR58kGQtWlGUJlBeAxpQ5A4eFKTu/ufLzPQv1f2mRRDiZ/nyyYwYrypI0OlQOc/9PsgshDsh2v+BUwTFnD3K5DglVlD4WlDZEsqywNgiK2F9gQBkLi7EtyV59WhBsiTURCjy5QZMgYRn9cxbZWgCQ+IKlnH2sFQYTURHmCYMgAJaKs9aYPkXNXGK6QhQdt9xeC4UhTC+eV/wVASASmrKj6IMA4NIBMQDsX1VN4IlbuU0K7vmiQS0G5EOpmiW6I1Dpjtp8pYc5yxYVj0RtXcMJcwDFSiqYLh2x+QgqAJwnAuEEydxbkZtdj+fKPVfwbPIq7KngqvMVX4WoAmDBAcH9HTMmXw23s0LJSlPOOsZx0l8VAu/0Fzjuc2Td3aY5zf1VoZgBvPgmvuhoIrFSMSXQThcDoJo0YLxGLfBSv5IINgVC1XxCOb/oZrkTBtRJqkQgKG6ROgPgPbGq/6HVIiYK51WngAj5ikbBhoZi3FALbHmozhlQXFChTc75g6wRM2ufzb9N/IwMcG0wg8HZJf9HBF/tFZnBBBH+cW/BpBDnd4XLDNJcon4oBiiY7jS194mEI0IaSz+12ygAclSYEcXvFsqA3UgANEzqAdCgtYm2PQM2cVc1PvUM0KC1ibY9AzZxVzU+bT0D/gPs/oxfcUEcJAAAAABJRU5ErkJggg==",
        alipay: "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAEAAAABACAYAAACqaXHeAAAAAXNSR0IArs4c6QAAA2FJREFUeF7tmU122jAQx2cMB2hp9yULeK+naHISwhJyiIRDBJaQkwRO0fdgEWff0h4ANH0yFc+m+hhbckKNvJUsaX76z4ckhAv/8MLthwggKuDCCUQXuHABxCAYXSC6wIUTiC7wFgL4MPveTaj9optrO+696ya8yeQRQFRAdIEYAxoVBD/PNtdCwHWpDIJwr+1PMCk1DgAkCSx/jHrLsv/p+lfKAp3HzQOYDAqxKtcYBJPtXe/B1Y3TXgmATGst0WIrgAC7JmBINOQsNN8HE0zfVQFlFxzrgFgHNLQOkNJuQ7vrcgkS1CXEua5fgnDj+l+172CX/h59Tbn9Of0qBUE1cGe2ngPhLWeiEH0krFDBT63HC8Cnx/VtFuFDfgl90UOldDvuX4WcSo7lBSD0YuR4H6ebZwRNkRUw9xdSah1G+IzZmW5IW7ERDX/e9Rc+YwerBEMvQo1nrhfqkf/ZuYCxxK5J/t4AjkFQBi71CXxFoFSWq2XTlkn+AndXodNf5SwgT4J7gnttoNL6BqUEmCZET/tkvzQZYj5g1Sf/0goIkfcJYIkEK5HsFnkYnen6BXQptUb5lwJgMz4zCihXD/BqAwVDuoy+Uqx399kACrkZaYECVjY5qxJZXpoQwrcDHB6UghfVvPssAMo35W4R7oZVg5EMmAJxUCZ2CNzfVJ2Pm6qdleDBNwFClaHZdRrQAEhWe25VSPCuAMo1tnQhdIzMNUixfDYBqAOGVQEKQB15OFMCwXPV3QsFww7g73E39Pudr/Gn0EyplQPXCkBF/5AKsBtPKRA+AdKAEx/0BhYLL9nHFkhZLiBvbkOcxFzG5wPtoe7gBUrrTiMttqO+8ebZCkAtWErs17jHvrrSLcj+lkCpKeV5g/ABIA05lqgVM4Er2nPhZgev7DHGnToLG+ALIC9budgWwoRzyuMUPlzj8waVBuELIFOB5iksi7xIKQh8PS4wu8/j+a3vBScbRAgABVfg5BZbH6SFgP0kVIl7UCjNja4RCkAGwecaPLDhp4yNsSYkADlp/mncdNLLu8fpud9XQK7//wERGoBrAefSfgRBsLI9pTtPg+diUNV1yLuJypVg1Un/p/8arwDXZkQALkJNb48KaPoOu+yLCnARanp7VEDTd9hlX1SAi1DT2/8AaakVXysj5qkAAAAASUVORK5CYII="
      },
      originalRroviders: ["wxpay", "alipay"],
      currentProviders: ["wxpay", "alipay"]
    };
  },
  mounted: function mounted() {
    var _this = this;

    return _asyncToGenerator2( /*#__PURE__*/_regenerator.default.mark(function _callee() {
      var e, t;
      return _regenerator.default.wrap(function _callee$(_context) {
        while (1) {
          switch (_context.prev = _context.next) {
            case 0:
              _context.t0 = i;

              if (_context.t0) {
                _context.next = 9;
                break;
              }

              _context.next = 4;
              return _this.getCode();

            case 4:
              e = _context.sent;
              _context.next = 7;
              return _this.getOpenid({
                provider: "wxpay",
                code: e
              });

            case 7:
              t = _context.sent;
              t && (i = t.openid);

            case 9:
              _this.originalRroviders = ["wxpay"];
              _this.currentProviders = JSON.parse(JSON.stringify(_this.originalRroviders));

              _this.$emit("mounted", {
                images: _this.images,
                originalRroviders: _this.originalRroviders,
                currentProviders: _this.currentProviders
              });

            case 12:
            case "end":
              return _context.stop();
          }
        }
      }, _callee);
    }))();
  },
  methods: {
    open: function open() {
      var _arguments = arguments,
          _this2 = this;

      return _asyncToGenerator2( /*#__PURE__*/_regenerator.default.mark(function _callee2() {
        var e, t;
        return _regenerator.default.wrap(function _callee2$(_context2) {
          while (1) {
            switch (_context2.prev = _context2.next) {
              case 0:
                e = _arguments.length > 0 && _arguments[0] !== undefined ? _arguments[0] : {};

                if (e.provider) {
                  t = [];
                  _this2.originalRroviders.map(function (r, i) {
                    e.provider.indexOf(r) > -1 && t.push(r);
                  }), _this2.currentProviders = t, delete e.provider;
                } else _this2.currentProviders = JSON.parse(JSON.stringify(_this2.originalRroviders));

                _this2.options = e;

                if (!(1 === _this2.currentProviders.length)) {
                  _context2.next = 7;
                  break;
                }

                _this2.createOrder({
                  provider: _this2.currentProviders[0]
                });

                _context2.next = 12;
                break;

              case 7:
                _context2.t0 = "pc" === _this2.modeCom;

                if (!_context2.t0) {
                  _context2.next = 11;
                  break;
                }

                _context2.next = 11;
                return _this2._pcChooseProvider(_this2.currentProviders[0]);

              case 11:
                _this2.openPopup("payPopup");

              case 12:
              case "end":
                return _context2.stop();
            }
          }
        }, _callee2);
      }))();
    },
    createOrder: function createOrder() {
      var _arguments2 = arguments,
          _this3 = this;

      return _asyncToGenerator2( /*#__PURE__*/_regenerator.default.mark(function _callee3() {
        var e, t, o, a;
        return _regenerator.default.wrap(function _callee3$(_context3) {
          while (1) {
            switch (_context3.prev = _context3.next) {
              case 0:
                e = _arguments2.length > 0 && _arguments2[0] !== undefined ? _arguments2[0] : {};
                t = _this3.options;

                if (!(Object.assign(t, e), "appleiap" === t.provider)) {
                  _context3.next = 4;
                  break;
                }

                return _context3.abrupt("return", _this3._appleiapCreateOrder(t));

              case 4:
                o = {
                  provider: t.provider,
                  total_fee: t.total_fee,
                  openid: i,
                  order_no: t.order_no || _this3.res.order_no,
                  out_trade_no: t.out_trade_no || _this3.res.out_trade_no,
                  description: t.description,
                  type: t.type,
                  qr_code: t.qr_code,
                  custom: t.custom,
                  other: t.other
                };
                i && (o.openid = i);
                _context3.next = 8;
                return r.createOrder(o);

              case 8:
                a = _context3.sent;
                a.errCode || (_this3.$emit("create", a), a.qr_code && !t.cancel_popup ? (_this3.res = a, "pc" === _this3.modeCom ? (_this3.openPopup("payPopup"), _this3._pcChooseProvider(t.provider)) : _this3.openPopup("qrcodePopup")) : _this3.orderPayment(a));

              case 10:
              case "end":
                return _context3.stop();
            }
          }
        }, _callee3);
      }))();
    },
    orderPayment: function orderPayment(t) {
      var _this4 = this;

      this.res = t, t.qr_code ? this.$emit("qrcode", t) : t.order && e.index.requestPayment(_objectSpread2(_objectSpread2(_objectSpread2({}, t.order), t.order), {}, {
        success: function success(e) {
          _this4._getOrder();
        },
        fail: function fail(e) {
          -1 == e.errMsg.indexOf("fail cancel") ? (console.error("uni.requestPayment:fail", e), _this4.$emit("fail", e)) : _this4.$emit("cancel", e);
        }
      }));
    },
    openPopup: function openPopup(e) {
      this.$refs[e].showPopup || this.$refs[e].open();
    },
    closePopup: function closePopup(e) {
      this.$refs[e].close();
    },
    getOrder: function getOrder() {
      var _arguments3 = arguments;
      return _asyncToGenerator2( /*#__PURE__*/_regenerator.default.mark(function _callee4() {
        var e, t;
        return _regenerator.default.wrap(function _callee4$(_context4) {
          while (1) {
            switch (_context4.prev = _context4.next) {
              case 0:
                e = _arguments3.length > 0 && _arguments3[0] !== undefined ? _arguments3[0] : {};
                _context4.prev = 1;
                _context4.next = 4;
                return r.getOrder(e);

              case 4:
                t = _context4.sent;
                return _context4.abrupt("return", ("function" == typeof e.success && e.success(t), t));

              case 8:
                _context4.prev = 8;
                _context4.t0 = _context4["catch"](1);
                "function" == typeof e.fail && e.fail(_context4.t0);

              case 11:
              case "end":
                return _context4.stop();
            }
          }
        }, _callee4, null, [[1, 8]]);
      }))();
    },
    refund: function refund() {
      var _arguments4 = arguments;
      return _asyncToGenerator2( /*#__PURE__*/_regenerator.default.mark(function _callee5() {
        var e, t;
        return _regenerator.default.wrap(function _callee5$(_context5) {
          while (1) {
            switch (_context5.prev = _context5.next) {
              case 0:
                e = _arguments4.length > 0 && _arguments4[0] !== undefined ? _arguments4[0] : {};
                _context5.prev = 1;
                _context5.next = 4;
                return r.refund(e);

              case 4:
                t = _context5.sent;
                return _context5.abrupt("return", ("function" == typeof e.success && e.success(t), t));

              case 8:
                _context5.prev = 8;
                _context5.t0 = _context5["catch"](1);
                "function" == typeof e.fail && e.fail(_context5.t0);

              case 11:
              case "end":
                return _context5.stop();
            }
          }
        }, _callee5, null, [[1, 8]]);
      }))();
    },
    getRefund: function getRefund() {
      var _arguments5 = arguments;
      return _asyncToGenerator2( /*#__PURE__*/_regenerator.default.mark(function _callee6() {
        var e, t;
        return _regenerator.default.wrap(function _callee6$(_context6) {
          while (1) {
            switch (_context6.prev = _context6.next) {
              case 0:
                e = _arguments5.length > 0 && _arguments5[0] !== undefined ? _arguments5[0] : {};
                _context6.prev = 1;
                _context6.next = 4;
                return r.getRefund(e);

              case 4:
                t = _context6.sent;
                return _context6.abrupt("return", ("function" == typeof e.success && e.success(t), t));

              case 8:
                _context6.prev = 8;
                _context6.t0 = _context6["catch"](1);
                "function" == typeof e.fail && e.fail(_context6.t0);

              case 11:
              case "end":
                return _context6.stop();
            }
          }
        }, _callee6, null, [[1, 8]]);
      }))();
    },
    closeOrder: function closeOrder() {
      var _arguments6 = arguments;
      return _asyncToGenerator2( /*#__PURE__*/_regenerator.default.mark(function _callee7() {
        var e, t;
        return _regenerator.default.wrap(function _callee7$(_context7) {
          while (1) {
            switch (_context7.prev = _context7.next) {
              case 0:
                e = _arguments6.length > 0 && _arguments6[0] !== undefined ? _arguments6[0] : {};
                _context7.prev = 1;
                _context7.next = 4;
                return r.closeOrder(e);

              case 4:
                t = _context7.sent;
                return _context7.abrupt("return", ("function" == typeof e.success && e.success(t), t));

              case 8:
                _context7.prev = 8;
                _context7.t0 = _context7["catch"](1);
                "function" == typeof e.fail && e.fail(_context7.t0);

              case 11:
              case "end":
                return _context7.stop();
            }
          }
        }, _callee7, null, [[1, 8]]);
      }))();
    },
    getPayProviderFromCloud: function getPayProviderFromCloud() {
      var _arguments7 = arguments;
      return _asyncToGenerator2( /*#__PURE__*/_regenerator.default.mark(function _callee8() {
        var e, t;
        return _regenerator.default.wrap(function _callee8$(_context8) {
          while (1) {
            switch (_context8.prev = _context8.next) {
              case 0:
                e = _arguments7.length > 0 && _arguments7[0] !== undefined ? _arguments7[0] : {};
                _context8.prev = 1;
                _context8.next = 4;
                return r.getPayProviderFromCloud(e);

              case 4:
                t = _context8.sent;
                return _context8.abrupt("return", ("function" == typeof e.success && e.success(t), t));

              case 8:
                _context8.prev = 8;
                _context8.t0 = _context8["catch"](1);
                "function" == typeof e.fail && e.fail(_context8.t0);

              case 11:
              case "end":
                return _context8.stop();
            }
          }
        }, _callee8, null, [[1, 8]]);
      }))();
    },
    getProviderAppId: function getProviderAppId() {
      var _arguments8 = arguments;
      return _asyncToGenerator2( /*#__PURE__*/_regenerator.default.mark(function _callee9() {
        var e, t;
        return _regenerator.default.wrap(function _callee9$(_context9) {
          while (1) {
            switch (_context9.prev = _context9.next) {
              case 0:
                e = _arguments8.length > 0 && _arguments8[0] !== undefined ? _arguments8[0] : {};
                _context9.prev = 1;
                _context9.next = 4;
                return r.getProviderAppId(e);

              case 4:
                t = _context9.sent;
                return _context9.abrupt("return", ("function" == typeof e.success && e.success(t), t));

              case 8:
                _context9.prev = 8;
                _context9.t0 = _context9["catch"](1);
                "function" == typeof e.fail && e.fail(_context9.t0);

              case 11:
              case "end":
                return _context9.stop();
            }
          }
        }, _callee9, null, [[1, 8]]);
      }))();
    },
    getOpenid: function getOpenid() {
      var _arguments9 = arguments;
      return _asyncToGenerator2( /*#__PURE__*/_regenerator.default.mark(function _callee10() {
        var e, t;
        return _regenerator.default.wrap(function _callee10$(_context10) {
          while (1) {
            switch (_context10.prev = _context10.next) {
              case 0:
                e = _arguments9.length > 0 && _arguments9[0] !== undefined ? _arguments9[0] : {};
                _context10.prev = 1;
                _context10.next = 4;
                return r.getOpenid(e);

              case 4:
                t = _context10.sent;
                return _context10.abrupt("return", ("function" == typeof e.success && e.success(t), t));

              case 8:
                _context10.prev = 8;
                _context10.t0 = _context10["catch"](1);
                "function" == typeof e.fail && e.fail(_context10.t0);

              case 11:
              case "end":
                return _context10.stop();
            }
          }
        }, _callee10, null, [[1, 8]]);
      }))();
    },
    verifyReceiptFromAppleiap: function verifyReceiptFromAppleiap() {
      var _arguments10 = arguments;
      return _asyncToGenerator2( /*#__PURE__*/_regenerator.default.mark(function _callee11() {
        var e, t;
        return _regenerator.default.wrap(function _callee11$(_context11) {
          while (1) {
            switch (_context11.prev = _context11.next) {
              case 0:
                e = _arguments10.length > 0 && _arguments10[0] !== undefined ? _arguments10[0] : {};
                _context11.prev = 1;
                _context11.next = 4;
                return r.verifyReceiptFromAppleiap(e);

              case 4:
                t = _context11.sent;
                return _context11.abrupt("return", ("function" == typeof e.success && e.success(t), t));

              case 8:
                _context11.prev = 8;
                _context11.t0 = _context11["catch"](1);
                "function" == typeof e.fail && e.fail(_context11.t0);

              case 11:
              case "end":
                return _context11.stop();
            }
          }
        }, _callee11, null, [[1, 8]]);
      }))();
    },
    getCode: function () {
      var _getCode = _asyncToGenerator2( /*#__PURE__*/_regenerator.default.mark(function _callee12() {
        return _regenerator.default.wrap(function _callee12$(_context12) {
          while (1) {
            switch (_context12.prev = _context12.next) {
              case 0:
                return _context12.abrupt("return", t.util.getWeixinCode());

              case 1:
              case "end":
                return _context12.stop();
            }
          }
        }, _callee12);
      }));

      function getCode() {
        return _getCode.apply(this, arguments);
      }

      return getCode;
    }(),
    paySuccess: function paySuccess() {
      var e = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {};
      this.closePopup("payPopup"), this.closePopup("payConfirmPopup"), this.clearQrcode(), this.toSuccessPage && this.pageToSuccess(e), this.$emit("success", e);
    },
    pageToSuccess: function pageToSuccess(t) {
      if ("pc" !== this.modeCom) e.index.navigateTo({
        url: "/uni_modules/uni-pay/pages/success/success?out_trade_no=".concat(t.out_trade_no, "&order_no=").concat(t.pay_order.order_no, "&pay_date=").concat(t.pay_order.pay_date, "&total_fee=").concat(t.pay_order.total_fee, "&adpid=").concat(this.adpid, "&return_url=").concat(this.returnUrl, "&main_color=").concat(this.mainColor)
      });else if (this.returnUrl) {
        var _r = this.returnUrl + "?out_trade_no=".concat(t.out_trade_no, "&order_no=").concat(t.pay_order.order_no);

        0 !== _r.indexOf("/") && (_r = "/".concat(_r)), e.index.navigateTo({
          url: _r
        });
      }
    },
    clearQrcode: function clearQrcode() {
      this.res.codeUrl = "", this.res.qr_code_image = "";
    },
    _getOrder: function _getOrder() {
      var _this5 = this;

      return _asyncToGenerator2( /*#__PURE__*/_regenerator.default.mark(function _callee13() {
        return _regenerator.default.wrap(function _callee13$(_context13) {
          while (1) {
            switch (_context13.prev = _context13.next) {
              case 0:
                _this5.getOrder({
                  out_trade_no: _this5.res.out_trade_no,
                  await_notify: !0,
                  success: function success(e) {
                    e.has_paid && (_this5.closePopup("qrcodePopup"), _this5.paySuccess(e));
                  }
                });

              case 1:
              case "end":
                return _context13.stop();
            }
          }
        }, _callee13);
      }))();
    },
    _afreshPayment: function _afreshPayment() {
      this.orderPayment(this.res);
    },
    _pcChooseProvider: function _pcChooseProvider(e) {
      if (e !== this.options.provider) return this.createOrder({
        provider: e
      });
    },
    _appleiapCreateOrder: function _appleiapCreateOrder(t) {
      var _this6 = this;

      return _asyncToGenerator2( /*#__PURE__*/_regenerator.default.mark(function _callee14() {
        var i, o, a, s, _r2, _o;

        return _regenerator.default.wrap(function _callee14$(_context14) {
          while (1) {
            switch (_context14.prev = _context14.next) {
              case 0:
                i = new appleiapSdk.Iap({
                  products: [t.productid]
                });
                e.index.showLoading({
                  title: "加载中..."
                });
                _context14.next = 4;
                return i.init();

              case 4:
                _context14.next = 6;
                return i.getProduct();

              case 6:
                o = _context14.sent[0];
                t.total_fee = 100 * o.price, t.description = o.description;
                a = {
                  provider: t.provider,
                  total_fee: t.total_fee,
                  order_no: t.order_no || _this6.res.order_no,
                  out_trade_no: t.out_trade_no || _this6.res.out_trade_no,
                  description: t.description,
                  type: t.type,
                  custom: t.custom
                };
                _context14.next = 11;
                return r.createOrder(a);

              case 11:
                s = _context14.sent;

                if (!(0 === s.errCode)) {
                  _context14.next = 34;
                  break;
                }

                _this6.$emit("create", s), _this6.res = s, e.index.showLoading({
                  title: "支付请求中..."
                });
                _context14.prev = 14;
                _this6.debug && console.log("正在请求苹果服务器", t.productid, s.out_trade_no);
                _context14.next = 18;
                return i.requestPayment({
                  productid: t.productid,
                  username: s.out_trade_no
                });

              case 18:
                _r2 = _context14.sent;
                _this6.debug && console.log("用户支付成功", _r2), e.index.showLoading({
                  title: "正在处理支付结果..."
                });
                _context14.next = 22;
                return _this6.verifyReceiptFromAppleiap({
                  out_trade_no: _r2.payment.username,
                  transaction_receipt: _r2.transactionReceipt,
                  transaction_identifier: _r2.transactionIdentifier
                });

              case 22:
                _o = _context14.sent;
                _context14.t0 = 0 === _o.errCode;

                if (!_context14.t0) {
                  _context14.next = 29;
                  break;
                }

                _context14.next = 27;
                return i.finishTransaction(_r2);

              case 27:
                e.index.hideLoading();

                _this6.paySuccess(_o);

              case 29:
                _context14.next = 34;
                break;

              case 31:
                _context14.prev = 31;
                _context14.t1 = _context14["catch"](14);
                2 === (_context14.t1.errCode || _context14.t1.code) ? (_this6.debug && console.log("用户取消支付"), _this6.$emit("cancel", _context14.t1)) : (console.error("appleiapCreateOrder:fail", _context14.t1), _this6.$emit("fail", _context14.t1)), e.index.hideLoading();

              case 34:
              case "end":
                return _context14.stop();
            }
          }
        }, _callee14, null, [[14, 31]]);
      }))();
    },
    appleiapRestore: function appleiapRestore() {
      var _this7 = this;

      return _asyncToGenerator2( /*#__PURE__*/_regenerator.default.mark(function _callee15() {
        var t, _r3, _e, _i;

        return _regenerator.default.wrap(function _callee15$(_context15) {
          while (1) {
            switch (_context15.prev = _context15.next) {
              case 0:
                e.index.showLoading({
                  title: "检测支付环境..."
                });
                t = new appleiapSdk.Iap();
                _context15.next = 4;
                return t.init();

              case 4:
                _context15.prev = 4;
                _this7.debug && console.log("正在查询是否有漏单信息");
                _context15.next = 8;
                return t.restoreCompletedTransactions({
                  username: ""
                });

              case 8:
                _r3 = _context15.sent;

                if (!(_this7.debug && console.log("漏单查询结果：" + (0 === _r3.length ? "未漏单" : "有漏单"), _r3), !_r3.length)) {
                  _context15.next = 11;
                  break;
                }

                return _context15.abrupt("return");

              case 11:
                _e = 0;

              case 12:
                if (!(_e < _r3.length)) {
                  _context15.next = 30;
                  break;
                }

                _i = _r3[_e];
                _context15.t0 = _i.transactionState;
                _context15.next = _context15.t0 === appleiapSdk.IapTransactionState.purchased ? 17 : _context15.t0 === appleiapSdk.IapTransactionState.failed ? 25 : 27;
                break;

              case 17:
                _context15.next = 19;
                return _this7.verifyReceiptFromAppleiap({
                  out_trade_no: _i.payment.username,
                  transaction_receipt: _i.transactionReceipt,
                  transaction_identifier: _i.transactionIdentifier
                });

              case 19:
                _context15.t1 = _context15.sent.errCode;
                _context15.t2 = 0 === _context15.t1;

                if (!_context15.t2) {
                  _context15.next = 24;
                  break;
                }

                _context15.next = 24;
                return t.finishTransaction(_i);

              case 24:
                return _context15.abrupt("break", 27);

              case 25:
                _context15.next = 27;
                return t.finishTransaction(_i);

              case 27:
                _e++;
                _context15.next = 12;
                break;

              case 30:
                _context15.next = 35;
                break;

              case 32:
                _context15.prev = 32;
                _context15.t3 = _context15["catch"](4);
                console.error(_context15.t3);

              case 35:
                _context15.prev = 35;
                e.index.hideLoading();
                return _context15.finish(35);

              case 38:
              case "end":
                return _context15.stop();
            }
          }
        }, _callee15, null, [[4, 32, 35, 38]]);
      }))();
    }
  },
  watch: {},
  computed: {
    modeCom: function modeCom() {
      if (this.mode) return this.mode;
      var t = e.index.getSystemInfoSync();
      return t && "pc" === t.deviceType ? "pc" : "mobile";
    }
  }
};if (!Array) {
  (e.resolveComponent("uni-popup") + e.resolveComponent("uni-list-item") + e.resolveComponent("uni-list"))();
}Math || (function () {
  return "../../../uni-popup/components/uni-popup/uni-popup.js";
} + function () {
  return "../../../uni-list/components/uni-list-item/uni-list-item.js";
} + function () {
  return "../../../uni-list/components/uni-list/uni-list.js";
})();var a = e._export_sfc(o, [["render", function (t, r, i, o, a, s) {
  return e.e({
    a: "pc" === s.modeCom
  }, "pc" === s.modeCom ? e.e({
    b: a.res.qr_code_image,
    c: e.t((a.options.total_fee / 100).toFixed(2)),
    d: a.res.qr_code_image
  }, a.res.qr_code_image ? {
    e: e.o(function (e) {
      return s._getOrder();
    })
  } : {}, {
    f: a.currentProviders.indexOf("wxpay") > -1
  }, a.currentProviders.indexOf("wxpay") > -1 ? {
    g: a.images.wxpay,
    h: e.n("wxpay" == a.options.provider ? "active" : ""),
    i: e.o(function (e) {
      return s._pcChooseProvider("wxpay");
    })
  } : {}, {
    j: a.currentProviders.indexOf("alipay") > -1
  }, a.currentProviders.indexOf("alipay") > -1 ? {
    k: a.images.alipay,
    l: e.n("alipay" == a.options.provider ? "active" : ""),
    m: e.o(function (e) {
      return s._pcChooseProvider("alipay");
    })
  } : {}, {
    n: i.logo,
    o: e.sr("payPopup", "95a25107-0"),
    p: e.p({
      type: "center",
      "safe-area": !1
    })
  }) : e.e({
    q: e.t((a.options.total_fee / 100).toFixed(2)),
    r: a.currentProviders.indexOf("wxpay") > -1
  }, a.currentProviders.indexOf("wxpay") > -1 ? {
    s: e.o(function (e) {
      return s.createOrder({
        provider: "wxpay"
      });
    }),
    t: e.p({
      thumb: a.images.wxpay,
      title: "微信支付",
      clickable: !0,
      link: !0
    })
  } : {}, {
    v: e.s("min-height: " + i.height + ";"),
    w: e.sr("payPopup", "95a25107-1"),
    x: e.p({
      type: "bottom",
      "safe-area": !1
    })
  }), {
    y: a.res.qr_code_image,
    z: e.t((a.options.total_fee / 100).toFixed(2)),
    A: "wxpay" == a.options.provider
  }, ("wxpay" == a.options.provider || a.options.provider, {}), {
    B: "alipay" == a.options.provider,
    C: e.o(function (e) {
      return s._getOrder();
    }),
    D: e.o(function (e) {
      return s.closePopup("qrcodePopup");
    }),
    E: e.sr("qrcodePopup", "95a25107-4"),
    F: e.o(s.clearQrcode),
    G: e.p({
      type: "center",
      "safe-area": !1,
      animation: !1,
      "mask-click": !1
    }),
    H: e.o(function (e) {
      return s._getOrder();
    }),
    I: e.o(function (e) {
      return s._afreshPayment();
    }),
    J: e.o(function (e) {
      return s.closePopup("payConfirmPopup");
    }),
    K: e.sr("payConfirmPopup", "95a25107-5"),
    L: e.p({
      type: "center",
      "safe-area": !1,
      animation: !1,
      "mask-click": !1
    })
  });
}], ["__scopeId", "data-v-95a25107"]]);wx.createComponent(a);