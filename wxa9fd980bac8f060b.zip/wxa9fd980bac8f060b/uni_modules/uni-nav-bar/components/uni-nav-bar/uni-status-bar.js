var t = require("../../../../common/vendor.js"),
    e = {
  name: "UniStatusBar",
  data: function data() {
    return {
      statusBarHeight: 20
    };
  },
  mounted: function mounted() {
    this.statusBarHeight = t.index.getSystemInfoSync().statusBarHeight + "px";
  }
};var s = t._export_sfc(e, [["render", function (t, e, s, n, a, r) {
  return {
    a: a.statusBarHeight
  };
}]]);wx.createComponent(s);