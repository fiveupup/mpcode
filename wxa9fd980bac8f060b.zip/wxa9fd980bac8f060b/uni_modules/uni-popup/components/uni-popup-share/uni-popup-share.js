var e = require("../uni-popup/popup.js"),
    t = require("../../../../common/vendor.js"),
    o = require("../uni-popup/i18n/index.js"),
    _t$initVueI18n = t.initVueI18n(o.messages),
    i = _t$initVueI18n.t,
    n = {
  name: "UniPopupShare",
  mixins: [e.popup],
  emits: ["select"],
  props: {
    title: {
      type: String,
      default: ""
    },
    beforeClose: {
      type: Boolean,
      default: !1
    }
  },
  data: function data() {
    return {
      bottomData: [{
        text: "空白模版",
        icon: "/static/wheel-w.png",
        name: "empty"
      }, {
        text: "快捷模版",
        icon: "/static/wheel-q.png",
        name: "quick"
      }, {
        text: "黑白模版",
        icon: "/static/wheel-wb.png",
        name: "lightdark"
      }, {
        text: "彩色模版",
        icon: "/static/wheel-c.png",
        name: "colorful"
      }]
    };
  },
  created: function created() {},
  computed: {
    cancelText: function cancelText() {
      return i("uni-popup.cancel");
    },
    shareTitleText: function shareTitleText() {
      return this.title || i("uni-popup.shareTitle");
    }
  },
  methods: {
    select: function select(e, t) {
      this.$emit("select", {
        item: e,
        index: t
      }), this.close();
    },
    close: function close() {
      this.beforeClose || this.popup.close();
    }
  }
};var c = t._export_sfc(n, [["render", function (e, o, i, n, c, s) {
  return {
    a: t.t(s.shareTitleText),
    b: t.f(c.bottomData, function (e, o, i) {
      return {
        a: e.icon,
        b: t.t(e.text),
        c: o,
        d: t.o(function (t) {
          return s.select(e, o);
        }, o)
      };
    }),
    c: t.t(s.cancelText),
    d: t.o(function () {
      return s.close && s.close.apply(s, arguments);
    })
  };
}]]);wx.createComponent(c);