var t = {
  data: function data() {
    return {};
  },
  created: function created() {
    this.popup = this.getParent();
  },
  methods: {
    getParent: function getParent() {
      var t = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : "uniPopup";
      var e = this.$parent,
          p = e.$options.name;

      for (; p !== t;) {
        if (e = e.$parent, !e) return !1;
        p = e.$options.name;
      }

      return e;
    }
  }
};exports.popup = t;