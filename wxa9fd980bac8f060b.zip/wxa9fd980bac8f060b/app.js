var _interopRequireDefault = require("@babel/runtime/helpers/interopRequireDefault");var _regenerator = _interopRequireDefault(require("@babel/runtime/regenerator"));var _asyncToGenerator2 = require("@babel/runtime/helpers/asyncToGenerator");Object.defineProperty(exports, Symbol.toStringTag, {
  value: "Module"
});var e = require("./common/vendor.js"),
    t = require("./store/index.js");Math;var o = e.Ds.database();o.on("refreshToken", function () {});var n = o.collection("uni-id-scores"),
    s = o.collection("uni-id-users"),
    i = e.index.getUpdateManager();i.onCheckForUpdate(function (e) {}), i.onUpdateReady(function (t) {
  e.index.showModal({
    title: "更新提示",
    content: "新版本已经准备好，是否重启应用？",
    success: function success(e) {
      e.confirm && i.applyUpdate();
    }
  });
}), i.onUpdateFailed(function (e) {});function r() {
  return _r.apply(this, arguments);
}function _r() {
  _r = _asyncToGenerator2( /*#__PURE__*/_regenerator.default.mark(function _callee4() {
    var _yield$n$where$field$, e;

    return _regenerator.default.wrap(function _callee4$(_context4) {
      while (1) {
        switch (_context4.prev = _context4.next) {
          case 0:
            _context4.next = 2;
            return n.where("user_id==$cloudEnv_uid&&comment=='幸运转盘'").field({
              create_date: !0
            }).orderBy("create_date", "desc").limit(1).get();

          case 2:
            _yield$n$where$field$ = _context4.sent;
            e = _yield$n$where$field$.result;
            e.data.length > 0 && function (e) {
              var t = new Date(e),
                  o = new Date();
              return t.getDate() == o.getDate() && t.getMonth() == o.getMonth() && t.getFullYear() == o.getFullYear();
            }(e.data[0].create_date) ? t.store.commit("setIsSpinLucky", !0) : t.store.commit("setIsSpinLucky", !1);

          case 5:
          case "end":
            return _context4.stop();
        }
      }
    }, _callee4);
  }));
  return _r.apply(this, arguments);
}var c = e.Ds.importObject("user", {
  customUI: !0
}),
    a = e.Ds.importObject("setting", {
  customUI: !0
}),
    d = e.index.getStorageSync("uni_id_token_expired"),
    m = {
  onLaunch: function () {
    var _onLaunch = _asyncToGenerator2( /*#__PURE__*/_regenerator.default.mark(function _callee2() {
      var _yield$s$where$field$, _e, o;

      return _regenerator.default.wrap(function _callee2$(_context2) {
        while (1) {
          switch (_context2.prev = _context2.next) {
            case 0:
              if (!(d < Date.now())) {
                _context2.next = 4;
                break;
              }

              e.index.login({
                success: function () {
                  var _success = _asyncToGenerator2( /*#__PURE__*/_regenerator.default.mark(function _callee(o) {
                    var n;
                    return _regenerator.default.wrap(function _callee$(_context) {
                      while (1) {
                        switch (_context.prev = _context.next) {
                          case 0:
                            _context.next = 2;
                            return c.login(o.code);

                          case 2:
                            n = _context.sent;
                            t.store.commit("setUserid", n.userInfo._id), t.store.commit("setRole", n.userInfo.role), t.store.commit("setWheels", n.userInfo.wheels), t.store.commit("setScore", n.userInfo.score), t.store.commit("setLike", n.userInfo.like || []), t.store.commit("updateUserinfo", {
                              nickname: n.userInfo.nickname,
                              avatar: n.userInfo.avatar
                            }), e.index.setStorageSync("uni_id_token", n.token), e.index.setStorageSync("uni_id_token_expired", n.tokenExpired), t.store.commit("login"), r();

                          case 4:
                          case "end":
                            return _context.stop();
                        }
                      }
                    }, _callee);
                  }));

                  function success(_x) {
                    return _success.apply(this, arguments);
                  }

                  return success;
                }()
              });
              _context2.next = 10;
              break;

            case 4:
              t.store.commit("login");
              _context2.next = 7;
              return s.where("_id==$cloudEnv_uid").field({
                wheels: !0,
                score: !0,
                like: !0,
                nickname: !0,
                avatar: !0,
                role: !0
              }).get({
                getOne: !0
              });

            case 7:
              _yield$s$where$field$ = _context2.sent;
              _e = _yield$s$where$field$.result.data;
              t.store.commit("updateUserinfo", {
                nickname: _e.nickname,
                avatar: _e.avatar
              }), t.store.commit("setWheels", _e.wheels), t.store.commit("setLike", _e.like || []), t.store.commit("setScore", _e.score), t.store.commit("setRole", _e.role), r();

            case 10:
              e.index.getStorageSync("showAddtip") || t.store.commit("setShowAddtip", !0);
              _context2.next = 13;
              return a.getCommon();

            case 13:
              o = _context2.sent;
              t.store.commit("setCommonSetting", o);

            case 15:
            case "end":
              return _context2.stop();
          }
        }
      }, _callee2);
    }));

    function onLaunch() {
      return _onLaunch.apply(this, arguments);
    }

    return onLaunch;
  }(),
  onShow: function () {
    var _onShow = _asyncToGenerator2( /*#__PURE__*/_regenerator.default.mark(function _callee3() {
      return _regenerator.default.wrap(function _callee3$(_context3) {
        while (1) {
          switch (_context3.prev = _context3.next) {
            case 0:
              console.log("App Show");

            case 1:
            case "end":
              return _context3.stop();
          }
        }
      }, _callee3);
    }));

    function onShow() {
      return _onShow.apply(this, arguments);
    }

    return onShow;
  }(),
  onHide: function onHide() {
    console.log("App Hide");
  }
};function u() {
  var o = e.createSSRApp(m);
  return o.use(t.store), {
    app: o
  };
}u().app.mount("#app"), exports.createApp = u;