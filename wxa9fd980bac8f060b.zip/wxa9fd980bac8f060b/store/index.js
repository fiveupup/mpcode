var e = require("../common/vendor.js"),
    s = e.index.getSystemInfoSync();var t = Boolean(e.index.getStorageSync("isMute")),
    i = e.index.getStorageSync("isVibrate");"boolean" != typeof i && (i = !0);var o = e.createStore({
  state: {
    userid: "",
    isLogin: !1,
    wheels: [],
    score: 0,
    isSpinLucky: !0,
    needFresh: !1,
    role: [],
    wheelList: [],
    showAddtip: !1,
    sysInfo: s,
    showSound: !0,
    like: [],
    isVibrate: i,
    isMute: t,
    nickname: "微信用户",
    avatar: "/static/defult-avatvr.png",
    commonSetting: {
      downloadScore: 5,
      shareScore: 5
    }
  },
  getters: {
    isMember: function isMember(e) {
      return e.role.includes("MEMBER");
    },
    wheelCount: function wheelCount(e) {
      return e.wheels.length;
    }
  },
  mutations: {
    updateUserinfo: function updateUserinfo(e, s) {
      e.nickname = s.nickname, e.avatar = s.avatar;
    },
    login: function login(e) {
      e.isLogin = !0;
    },
    loginOut: function loginOut(e) {
      e.isLogin = !1;
    },
    setUserid: function setUserid(e, s) {
      e.userid = s;
    },
    setVibrate: function setVibrate(s, t) {
      e.index.setStorageSync("isVibrate", t), s.isVibrate = t;
    },
    setRole: function setRole(e, s) {
      e.role = s;
    },
    addRole: function addRole(e, s) {
      e.role.push(s);
    },
    setWheels: function setWheels(e, s) {
      Array.isArray(s) && (e.wheels = s);
    },
    setWheelList: function setWheelList(e, s) {
      e.wheelList = s;
    },
    setScore: function setScore(e, s) {
      e.score = s;
    },
    setNeedFresh: function setNeedFresh(e, s) {
      e.needFresh = s;
    },
    increScore: function increScore(e, s) {
      e.score += s;
    },
    decreScore: function decreScore(e, s) {
      e.score -= s;
    },
    setIsSpinLucky: function setIsSpinLucky(e, s) {
      e.isSpinLucky = s;
    },
    addWheel: function addWheel(e, s) {
      e.wheels.push(s);
    },
    removeWheel: function removeWheel(e, s) {
      e.wheels.splice(s, 1);
    },
    addLike: function addLike(e, s) {
      e.like.push(s);
    },
    removeLike: function removeLike(e, s) {
      e.like = e.like.filter(function (e) {
        return e !== s;
      });
    },
    setShowAddtip: function setShowAddtip(e, s) {
      e.showAddtip = s;
    },
    setMute: function setMute(s, t) {
      e.index.setStorageSync("isMute", t), s.isMute = t;
    },
    setLike: function setLike(e, s) {
      e.like = s;
    },
    setCommonSetting: function setCommonSetting(e, s) {
      e.commonSetting = s;
    }
  }
});exports.store = o;