var e = require("../../composables/useColorPicker.js"),
    o = require("../../common/vendor.js"),
    t = {
  props: ["color", "title", "current"],
  emits: ["change", "close", "currentChange"],
  name: "color-picker",
  setup: function setup(o, t) {
    var _e$useColorPicker = e.useColorPicker(o, t),
        i = _e$useColorPicker.position,
        n = _e$useColorPicker.bindPositionchange,
        r = _e$useColorPicker.saturationBg,
        c = _e$useColorPicker.palette,
        s = _e$useColorPicker.displayColor,
        a = _e$useColorPicker.init;

    return {
      position: i,
      bindPositionchange: n,
      saturationBg: r,
      palette: c,
      displayColor: s,
      init: a
    };
  },
  data: function data() {
    return {
      presets: ["#845EC2", "#D65DB1", "#FF6F91", "#FF9671", "#FFC75F", "#F9F871", "#0081CF", "#2C73D2", "#0089BA", "#008E9B", "#008F7A"]
    };
  },
  methods: {
    changeColor: function changeColor(e) {
      this.init(e), this.$emit("change", e);
    },
    hidePicker: function hidePicker() {
      this.$emit("close");
    },
    currentChange: function currentChange(e) {
      this.$emit("currentChange", e);
    }
  }
};if (!Array) {
  o.resolveComponent("uni-icons")();
}Math;var i = o._export_sfc(t, [["render", function (e, t, i, n, r, c) {
  return {
    a: o.n(1 === i.current ? "inactive" : "active"),
    b: o.o(function (e) {
      return c.currentChange(0);
    }),
    c: o.n(0 === i.current ? "inactive" : "active"),
    d: o.o(function (e) {
      return c.currentChange(1);
    }),
    e: o.f(n.palette, function (e, t, i) {
      return o.e({
        a: n.displayColor === e
      }, n.displayColor === e ? {
        b: "0b1b7c57-0-" + i,
        c: o.p({
          color: "#fff",
          type: "checkmarkempty",
          size: "24"
        })
      } : {}, {
        d: t,
        e: e,
        f: o.o(function (o) {
          return c.changeColor(e);
        }, t)
      });
    }),
    f: 0 === i.current,
    g: n.position[0].x,
    h: n.position[0].y,
    i: o.o(function (e) {
      return n.bindPositionchange(e, 0);
    }),
    j: n.displayColor,
    k: 1 === i.current,
    l: n.saturationBg,
    m: n.position[1].x,
    n: n.position[1].y,
    o: o.o(function (e) {
      return n.bindPositionchange(e, 1);
    }),
    p: n.saturationBg,
    q: 1 === i.current
  };
}]]);wx.createComponent(i);