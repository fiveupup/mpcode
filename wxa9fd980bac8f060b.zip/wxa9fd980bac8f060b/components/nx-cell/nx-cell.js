var e = require("../../common/vendor.js"),
    r = {
  data: function data() {
    return {};
  },
  props: {
    icon: String,
    title: String,
    border: {
      type: Boolean,
      value: !0
    }
  }
};if (!Array) {
  e.resolveComponent("uni-icons")();
}Math;var t = e._export_sfc(r, [["render", function (r, t, o, n, i, c) {
  return {
    a: o.icon,
    b: e.t(o.title),
    c: e.p({
      type: "right"
    }),
    d: e.n(o.border ? "border-b" : "")
  };
}], ["__scopeId", "data-v-6486ee42"]]);wx.createComponent(t);