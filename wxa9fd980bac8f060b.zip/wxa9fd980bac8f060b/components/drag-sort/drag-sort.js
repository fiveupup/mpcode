var _interopRequireDefault = require("../../@babel/runtime/helpers/interopRequireDefault");var _regenerator = _interopRequireDefault(require("../../@babel/runtime/regenerator"));var _asyncToGenerator2 = require("../../@babel/runtime/helpers/asyncToGenerator");var t = require("../../common/vendor.js"),
    i = {
  props: ["items", "rowHeight", "isDisable"],
  emits: ["change", "rowClick"],
  name: "drag-sort",
  data: function data() {
    return {
      position: {},
      levelPosition: [],
      mapLevel: [],
      activeItem: "",
      translate: 0,
      copyItems: []
    };
  },
  watch: {
    items: {
      handler: function handler(t) {
        var _this = this;

        var i = t.length;
        this.activeItem = "", this.translate = 0, this.levelPosition = Array.from(Array(i).keys()).map(function (t) {
          return t * _this.rowHeight;
        }), this.initList();
      },
      immediate: !0,
      deep: !0
    }
  },
  methods: {
    initList: function initList() {
      var t = JSON.parse(JSON.stringify(this.items));
      this.copyItems = [], this.mapLevel = [], this.position = {};

      for (var _i = 0, _e = t.length; _i < _e; _i++) {
        var _e2 = "HMDragId_" + this.getGuid();

        t[_i].id = _e2, this.copyItems.push(t[_i]), this.mapLevel.push(_e2), this.position[_e2] = _i * this.rowHeight;
      }
    },
    getGuid: function getGuid() {
      function t() {
        return (65536 * (1 + Math.random()) | 0).toString(16).substring(1);
      }

      return t() + t() + "_" + t() + "_" + t() + "_" + t() + "_" + t() + t() + t();
    },
    change: function change(_ref, e) {
      var _ref$detail = _ref.detail,
          t = _ref$detail.y,
          i = _ref$detail.source;

      if ("touch" === i) {
        this.activeItem = e;

        var _i2 = this.mapLevel.findIndex(function (t) {
          return t === e;
        }),
            s = t - this.levelPosition[_i2],
            o = Math.round(s / this.rowHeight);

        this.translate += o;
        if (Math.abs(o) > 0) if (o > 0) {
          var _t = this.mapLevel[_i2 + 1];
          this.position[_t] = this.levelPosition[_i2], this.mapLevel[_i2] = _t, this.mapLevel[_i2 + 1] = e;
        } else {
          var _t2 = this.mapLevel[_i2 - 1];
          this.position[_t2] = this.levelPosition[_i2], this.mapLevel[_i2] = _t2, this.mapLevel[_i2 - 1] = e;
        }
      }
    },
    touchend: function touchend(i) {
      var _this2 = this;

      return _asyncToGenerator2( /*#__PURE__*/_regenerator.default.mark(function _callee() {
        var e, s;
        return _regenerator.default.wrap(function _callee$(_context) {
          while (1) {
            switch (_context.prev = _context.next) {
              case 0:
                if (!("" === _this2.activeItem)) {
                  _context.next = 2;
                  break;
                }

                return _context.abrupt("return");

              case 2:
                _this2.activeItem;
                e = _this2.mapLevel.findIndex(function (t) {
                  return t === _this2.activeItem;
                });
                _this2.position[_this2.activeItem] = _this2.levelPosition[e];
                _context.next = 7;
                return t.nextTick$1();

              case 7:
                s = _this2.mapLevel.map(function (t) {
                  return _this2.copyItems.find(function (i) {
                    return i.id === t;
                  });
                });

                _this2.$emit("change", s);

              case 9:
              case "end":
                return _context.stop();
            }
          }
        }, _callee);
      }))();
    },
    clickItem: function clickItem(t, i) {
      this.$emit("rowClick", t, i);
    }
  }
};var e = t._export_sfc(i, [["render", function (i, e, s, o, h, n) {
  return {
    a: t.f(h.copyItems, function (i, e, s) {
      return {
        a: t.t(i.sliceText),
        b: i.backgroundColor,
        c: i.textColor,
        d: t.o(function (t) {
          return n.clickItem(i, e);
        }, i.id),
        e: h.position[i.id],
        f: i.id,
        g: t.n(h.activeItem === i.id ? "active" : ""),
        h: t.o(function (t) {
          return n.change(t, i.id);
        }, i.id),
        i: t.o(function () {
          return n.touchend && n.touchend.apply(n, arguments);
        }, i.id)
      };
    }),
    b: s.rowHeight,
    c: s.isDisable,
    d: s.rowHeight * h.copyItems.length + "px",
    e: t.o(function () {
      return i.startSort && i.startSort.apply(i, arguments);
    })
  };
}]]);wx.createComponent(e);