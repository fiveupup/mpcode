var e = require("../../common/vendor.js"),
    n = {
  name: "member-popup",
  emits: ["success"],
  props: {
    contentVal: ""
  },
  data: function data() {
    return {
      memberPackages: [{
        value: "month",
        name: "包月",
        price: 900
      }, {
        value: "year",
        name: "包年",
        checked: !0,
        price: 3900
      }, {
        value: "lifetime",
        name: "永久",
        price: 9900
      }],
      selectedPackageIndex: 0,
      myContentVal: this.contentVal
    };
  },
  methods: {
    showMembershipPopup: function showMembershipPopup() {
      var _this = this;

      e.index.showModal({
        title: "提示",
        content: "".concat(this.myContentVal, "\u5F00\u901A\u4F1A\u5458\u53EF\u4EAB\u53D7\u65E0\u9650\u8F6C\u76D8\u6570\u91CF\uFF0C\u514D\u9664\u6240\u6709\u5E7F\u544A\uFF0C\u65E0\u9700\u79EF\u5206\u4E0B\u8F7D\u8F6C\u76D8\uFF0C\u65B0\u529F\u80FD\u62A2\u5148\u4F53\u9A8C\u3002\u5305\u67089\u5143\uFF0C\u5305\u5E7439\u5143\uFF0C\u6C38\u4E4599\u5143"),
        confirmText: "选择套餐",
        cancelText: "我再想想",
        success: function success(n) {
          n.confirm && e.index.getSystemInfo({
            success: function success(n) {
              "ios" === n.platform ? e.index.showModal({
                title: "提示",
                content: "iOS 用户暂不支持在小程序渠道开通会员，如有疑问请联系客服",
                confirmText: "好的",
                cancelText: "联系客服",
                success: function success(e) {
                  e.cancel && _this.$refs.qrcode.open();
                }
              }) : _this.$refs.popupMember.open();
            }
          });
        }
      });
    },
    onPackageChange: function onPackageChange(e) {
      for (var _n = 0; _n < this.memberPackages.length; _n++) {
        if (this.memberPackages[_n].value === e.detail.value) {
          this.selectedPackageIndex = _n;
          break;
        }
      }
    },
    generateOrderNo: function generateOrderNo() {
      var e = new Date();
      return "".concat(e.getFullYear()).concat(e.getMonth() + 1).concat(e.getDate()).concat(e.getTime()).concat(Math.floor(1e6 * Math.random()));
    },
    onSuccess: function onSuccess(e) {
      this.$refs.popupMember.close(), this.$emit("success", e);
    },
    openPayment: function openPayment() {
      var e = this.memberPackages[this.selectedPackageIndex].price,
          n = this.generateOrderNo(),
          t = "".concat(n, "-1");
      this.$refs.uniPay.open({
        total_fee: e,
        type: "recharge",
        order_no: n,
        out_trade_no: t,
        description: "\u5927\u8F6C\u76D8pro".concat(this.memberPackages[this.selectedPackageIndex].name, "\u5957\u9910")
      });
    }
  }
};if (!Array) {
  (e.resolveComponent("uni-popup") + e.resolveComponent("uni-pay"))();
}Math || (function () {
  return "../../uni_modules/uni-popup/components/uni-popup/uni-popup.js";
} + function () {
  return "../../uni_modules/uni-pay/components/uni-pay/uni-pay.js";
})();var t = e._export_sfc(n, [["render", function (n, t, a, o, s, c) {
  return {
    a: e.f(s.memberPackages, function (n, t, a) {
      return {
        a: n.value,
        b: t === s.selectedPackageIndex,
        c: e.t(n.name),
        d: n.value
      };
    }),
    b: e.o(function () {
      return c.onPackageChange && c.onPackageChange.apply(c, arguments);
    }),
    c: e.o(function () {
      return c.openPayment && c.openPayment.apply(c, arguments);
    }),
    d: e.sr("popupMember", "39ae65f7-0"),
    e: e.p({
      "background-color": "#fff",
      type: "center"
    }),
    f: e.sr("qrcode", "39ae65f7-1"),
    g: e.p({
      "background-color": "#fff",
      type: "center"
    }),
    h: e.sr("uniPay", "39ae65f7-2"),
    i: e.o(c.onSuccess)
  };
}]]);wx.createComponent(t);