var _interopRequireDefault = require("../../@babel/runtime/helpers/interopRequireDefault");var _regenerator = _interopRequireDefault(require("../../@babel/runtime/regenerator"));var _asyncToGenerator2 = require("../../@babel/runtime/helpers/asyncToGenerator");var _objectSpread2 = require("../../@babel/runtime/helpers/objectSpread2");var e = require("../../common/vendor.js"),
    o = e.Ds.importObject("wheel", {
  customUI: !0
}),
    t = e.Ds.importObject("user", {
  customUI: !0
});e.Ds.database();var i = !0,
    s = null;var n = {
  data: function data() {
    return {
      range: ["全部", "棋盘游戏", "机会与财富", "喜剧和乐趣", "娱乐活动", "食物和饮料", "聚会游戏", "音乐", "体育", "工具", "旅游与世界", "电子游戏", "其它"],
      isOwn: !1,
      active: {
        title: "未命名的转盘",
        thumbnail: ""
      },
      category: 0,
      sortList: ["下载数量", "发布日期"],
      sort: 0,
      orderBy: ["downloadCount desc", "create_time desc", "rate desc"],
      contentVal: "存储转盘数量已达到上限，"
    };
  },
  computed: _objectSpread2(_objectSpread2(_objectSpread2({}, e.mapState({
    commonSetting: function commonSetting(e) {
      return e.commonSetting;
    },
    wheels: function wheels(e) {
      return e.wheels;
    },
    score: function score(e) {
      return e.score;
    },
    isSpinLucky: function isSpinLucky(e) {
      return e.isSpinLucky;
    }
  })), e.mapGetters(["isMember", "wheelCount"])), {}, {
    where: function where() {
      var e = "_id != '".concat(this.commonSetting.luckyId, "'&&reviewState == true");
      return 0 !== this.category ? e + "&&category==" + (this.category - 1) : e;
    }
  }),
  onLoad: function onLoad() {
    var _this = this;

    e.wx$1.createRewardedVideoAd && (s = e.wx$1.createRewardedVideoAd({
      adUnitId: "adunit-2625e8757cdf7646"
    }), s.onLoad(function () {}), s.onError(function (e) {}), s.onClose(function (o) {
      if (o && o.isEnded) {
        console.log("看广告增加积分");
        var _o = 30,
            _i = {
          balance: _this.score + _o,
          comment: "看广告增加积分",
          score: _o,
          type: 1
        };
        t.setScore(_i).then(function () {
          _this.increScore(_o), e.index.showModal({
            showCancel: !1,
            content: "\u606D\u559C\u4F60\uFF0C\u589E\u52A0\u4E86".concat(_o, "\u79EF\u5206\uFF01")
          });
        });
      } else e.index.showToast({
        icon: "none",
        title: "未看完广告，无奖励"
      });
    }));
  },
  onShow: function onShow() {
    if (i || this.isMember) i = !1;else {
      var _o2 = e.wx$1.createInterstitialAd({
        adUnitId: "adunit-e426816de95452de"
      });

      _o2.onLoad(function () {
        _o2.show().catch(function (e) {});
      });
    }
  },
  onReachBottom: function onReachBottom() {
    this.$refs.udb.loadMore();
  },
  onShareAppMessage: function onShareAppMessage() {
    return {
      title: "快来和我一起转转转",
      path: "/pages/index/index",
      imageUrl: "/static/share-logo.png"
    };
  },
  onPullDownRefresh: function onPullDownRefresh() {
    this.$refs.udb.reset(), this.$refs.udb.refresh();
  },
  methods: _objectSpread2(_objectSpread2({}, e.mapMutations(["addWheel", "decreScore", "increScore", "addRole"])), {}, {
    onSuccess: function onSuccess(e) {
      console.log("success: ", e), e.user_order_success ? this.addRole("MEMBER") : (this.addRole("MEMBER"), console.log("支付成功，但报错了"));
    },
    watchVideo: function watchVideo() {
      s && s.show().catch(function () {
        s.load().then(function () {
          return s.show();
        }).catch(function (o) {
          e.index.showToast({
            icon: "none",
            title: "广告展示失败"
          });
        });
      });
    },
    toDetail: function toDetail(o) {
      e.index.navigateTo({
        url: "../detail-wheel/detail-wheel?id=".concat(o)
      });
    },
    close: function close() {
      this.$refs.popup.close();
    },
    open: function open() {
      this.$refs.popup.open();
    },
    handLoad: function handLoad() {
      e.index.stopPullDownRefresh();
    },
    pickCategory: function pickCategory(e) {
      this.category = Number(e.detail.value);
    },
    pickSort: function pickSort() {
      var _this2 = this;

      e.index.showActionSheet({
        itemList: this.sortList,
        success: function success(e) {
          var o = e.tapIndex;
          _this2.sort = o;
        }
      });
    },
    showSave: function showSave(e) {
      this.active = e, this.open();
    },
    add: function add() {
      var _this3 = this;

      return _asyncToGenerator2( /*#__PURE__*/_regenerator.default.mark(function _callee() {
        var i;
        return _regenerator.default.wrap(function _callee$(_context) {
          while (1) {
            switch (_context.prev = _context.next) {
              case 0:
                if (!_this3.isMember) {
                  _context.next = 6;
                  break;
                }

                e.index.showLoading({
                  mask: !0
                });
                _context.next = 4;
                return Promise.all([o.increaseDownload(_this3.active._id), t.addWheel(_this3.active._id)]);

              case 4:
                _this3.addWheel(_this3.active._id);

                return _context.abrupt("return", void e.index.hideLoading());

              case 6:
                if (!(_this3.wheelCount > 9)) {
                  _context.next = 8;
                  break;
                }

                return _context.abrupt("return", void _this3.$refs.popupMember.showMembershipPopup());

              case 8:
                e.index.showLoading({
                  mask: !0
                });
                i = {
                  balance: _this3.score - _this3.commonSetting.downloadScore,
                  comment: "下载转盘",
                  score: _this3.commonSetting.downloadScore,
                  type: 2
                };
                _context.next = 12;
                return Promise.all([o.increaseDownload(_this3.active._id), t.addWheel(_this3.active._id), t.setScore(i)]);

              case 12:
                _this3.decreScore(_this3.commonSetting.downloadScore);

                _this3.addWheel(_this3.active._id);

                e.index.hideLoading();
                e.index.showToast({
                  title: "添加成功"
                });

              case 16:
              case "end":
                return _context.stop();
            }
          }
        }, _callee);
      }))();
    },
    copyAccount: function copyAccount() {
      e.index.setClipboardData({
        data: this.account,
        success: function success() {
          e.index.showToast({
            title: "账号已复制，快去发给客服吧",
            icon: "none"
          });
        }
      });
    },
    spin: function spin(o) {
      this.close(), e.index.navigateTo({
        url: "../detail-wheel/detail-wheel?id=".concat(o)
      });
    },
    onReachBottom: function onReachBottom() {
      this.$refs.udb.loadMore();
    }
  })
};if (!Array) {
  (e.resolveComponent("uni-tag") + e.resolveComponent("uni-load-more") + e.resolveComponent("unicloud-db") + e.resolveComponent("uni-popup") + e.resolveComponent("member-popup"))();
}Math || (function () {
  return "../../uni_modules/uni-tag/components/uni-tag/uni-tag.js";
} + function () {
  return "../../uni_modules/uni-load-more/components/uni-load-more/uni-load-more.js";
} + function () {
  return "../../node-modules/@dcloudio/uni-components/lib/unicloud-db/unicloud-db.js";
} + function () {
  return "../../uni_modules/uni-popup/components/uni-popup/uni-popup.js";
} + function () {
  return "../../components/member-popup/member-popup.js";
})();var d = e._export_sfc(n, [["render", function (o, t, i, s, n, d) {
  return e.e({
    a: e.t(n.range[n.category]),
    b: n.category,
    c: n.range,
    d: e.o(function () {
      return d.pickCategory && d.pickCategory.apply(d, arguments);
    }),
    e: e.t(n.sortList[n.sort]),
    f: e.o(function () {
      return d.pickSort && d.pickSort.apply(d, arguments);
    }),
    g: e.w(function (_ref, n, a) {
      var t = _ref.data,
          i = _ref.loading,
          s = _ref.error;
      return e.e({
        a: s
      }, s ? {
        b: e.t(s.message)
      } : {
        c: e.f(t, function (t, i, s) {
          return e.e({
            a: e.t(i + 1),
            b: e.t(t.title),
            c: t.thumbnail,
            d: o.wheels.includes(t._id)
          }, o.wheels.includes(t._id) ? {
            e: "0a48de73-1-" + a + "-" + s + ",0a48de73-0",
            f: e.p({
              text: "已添加",
              type: ""
            })
          } : {}, {
            g: e.o(function (e) {
              return d.showSave(t);
            }, i),
            h: (i + 2) % 6 == 3 && !o.isMember
          }, ((i + 2) % 6 != 3 || o.isMember, {}), {
            i: i
          });
        })
      }, {
        d: i
      }, i ? {
        e: "0a48de73-2-" + a + ",0a48de73-0",
        f: e.p({
          status: "loading"
        })
      } : {}, {
        g: a,
        h: n
      });
    }, {
      name: "d",
      path: "g",
      vueId: "0a48de73-0"
    }),
    h: e.sr("udb", "0a48de73-0"),
    i: e.o(d.handLoad),
    j: e.p({
      orderby: n.orderBy[n.sort],
      collection: "spin-list",
      where: d.where
    }),
    k: e.t(n.active.title),
    l: n.active.thumbnail,
    m: !o.wheels.includes(n.active._id) && !o.isMember
  }, o.wheels.includes(n.active._id) || o.isMember ? {} : e.e({
    n: e.t(o.commonSetting.downloadScore),
    o: e.t(o.score),
    p: !o.isSpinLucky
  }, o.isSpinLucky ? {
    r: e.o(function () {
      return d.watchVideo && d.watchVideo.apply(d, arguments);
    })
  } : {
    q: e.o(function (e) {
      return d.toDetail(o.commonSetting.luckyId);
    })
  }), {
    s: e.o(function () {
      return d.close && d.close.apply(d, arguments);
    }),
    t: o.wheels.includes(n.active._id)
  }, o.wheels.includes(n.active._id) ? {
    v: e.o(function (e) {
      return d.spin(n.active._id);
    })
  } : e.e({
    w: !o.isMember
  }, o.isMember ? {
    A: e.o(function () {
      return d.add && d.add.apply(d, arguments);
    })
  } : {
    x: e.t(o.score < o.commonSetting.downloadScore ? "积分不足" : "下载"),
    y: e.o(function () {
      return d.add && d.add.apply(d, arguments);
    }),
    z: o.score < o.commonSetting.downloadScore
  }), {
    B: e.sr("popup", "0a48de73-3"),
    C: e.p({
      safeArea: !1,
      "background-color": "#fff",
      type: "bottom"
    }),
    D: e.sr("popupMember", "0a48de73-4"),
    E: e.o(d.onSuccess),
    F: e.p({
      contentVal: n.contentVal
    })
  });
}]]);n.__runtimeHooks = 2, wx.createPage(d);