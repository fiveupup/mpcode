var _interopRequireDefault = require("../../@babel/runtime/helpers/interopRequireDefault");var _regenerator = _interopRequireDefault(require("../../@babel/runtime/regenerator"));var _asyncToGenerator2 = require("../../@babel/runtime/helpers/asyncToGenerator");var _objectSpread2 = require("../../@babel/runtime/helpers/objectSpread2");var a = require("../../common/vendor.js"),
    t = a.Ds.importObject("user"),
    e = a.Ds.importObject("file", {
  customUI: !0
}),
    i = {
  data: function data() {
    return {
      newNickName: "",
      newAvatar: ""
    };
  },
  onLoad: function onLoad() {
    this.newAvatar = this.avatar, this.newNickName = this.nickname;
  },
  computed: a.mapState(["avatar", "nickname"]),
  methods: _objectSpread2(_objectSpread2({}, a.mapMutations(["updateUserinfo"])), {}, {
    chooseavatar: function chooseavatar(a) {
      this.newAvatar = a.detail.avatarUrl;
    },
    nicknameInput: function nicknameInput(a) {
      this.newNickName = a.detail.value;
    },
    save: function save() {
      var _this = this;

      return _asyncToGenerator2( /*#__PURE__*/_regenerator.default.mark(function _callee() {
        var i, n;
        return _regenerator.default.wrap(function _callee$(_context) {
          while (1) {
            switch (_context.prev = _context.next) {
              case 0:
                i = _this.avatar;

                if (!(_this.avatar !== _this.newAvatar)) {
                  _context.next = 8;
                  break;
                }

                _context.next = 4;
                return e.delete(_this.avatar);

              case 4:
                _context.next = 6;
                return a.Ds.uploadFile({
                  filePath: _this.newAvatar,
                  cloudPath: "avatar.png"
                });

              case 6:
                _context.t0 = _context.sent.fileID;
                i = _context.t0 + "?x-oss-process=image/crop,w_132,h_132";

              case 8:
                n = {
                  nickname: _this.newNickName,
                  avatar: i
                };
                _context.next = 11;
                return t.updateInfo(n);

              case 11:
                _this.updateUserinfo(n);

                a.index.showToast({
                  title: "修改成功",
                  success: function success() {
                    a.index.navigateBack();
                  }
                });

              case 13:
              case "end":
                return _context.stop();
            }
          }
        }, _callee);
      }))();
    }
  })
};var n = a._export_sfc(i, [["render", function (t, e, i, n, s, o) {
  return {
    a: s.newAvatar,
    b: a.o(function () {
      return o.chooseavatar && o.chooseavatar.apply(o, arguments);
    }),
    c: s.newNickName,
    d: a.o(function () {
      return o.nicknameInput && o.nicknameInput.apply(o, arguments);
    }),
    e: a.o(function () {
      return o.save && o.save.apply(o, arguments);
    })
  };
}]]);wx.createPage(n);