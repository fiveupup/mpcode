var _interopRequireDefault = require("../../@babel/runtime/helpers/interopRequireDefault");var _regenerator = _interopRequireDefault(require("../../@babel/runtime/regenerator"));var _asyncToGenerator2 = require("../../@babel/runtime/helpers/asyncToGenerator");require("../../@babel/runtime/helpers/Arrayincludes");var _objectSpread2 = require("../../@babel/runtime/helpers/objectSpread2");var _defineProperty2 = require("../../@babel/runtime/helpers/defineProperty");var _n;var e = require("../../common/vendor.js"),
    t = require("../../composables/useCanvasWheel.js");require("../../store/index.js");var o = e.Ds.database().collection("spin-list"),
    i = e.Ds.importObject("user", {
  customUI: !0
}),
    s = e.Ds.importObject("file", {
  customUI: !0
}),
    r = e.Ds.importObject("content", {
  customUI: !0
}),
    l = "BG_COLOR",
    a = "TEXT_COLOR",
    n = (_n = {}, _defineProperty2(_n, l, ["#ff0000", "#ff8700", "#ffd300", "#deff0a", "#a1ff0a", "#0aff99", "#0aefff", "#147df5", "#580aff", "#be0aff", "#fbf8cc", "#fde4cf", "#ffcfd2", "#f1c0e8", "#cfbaf0", "#a3c4f3", "#90dbf4", "#8eecf5", "#98f5e1", "#b9fbc0"]), _defineProperty2(_n, a, ["#664d00", "#6e2a0c", "#691312", "#5d0933", "#431136", "#291938", "#042d3a", "#12403c", "#2d491e", "#475200", "#0d0e14", "#252933", "#404556", "#60515c", "#777076", "#597d7c", "#386775", "#20504e", "#193d31", "#17292b"]), _n),
    c = {
  setup: function setup() {
    var _t$useCanvasWheel = t.useCanvasWheel("saveCavas", !0),
        e = _t$useCanvasWheel.getTempFilePath,
        o = _t$useCanvasWheel.sectors,
        i = _t$useCanvasWheel.textSize,
        s = _t$useCanvasWheel.sliceRepeat,
        r = _t$useCanvasWheel.pathText,
        l = _t$useCanvasWheel.wheelTouchEnd,
        a = _t$useCanvasWheel.onSectorClick;

    return {
      getTempFilePath: e,
      sectors: o,
      textSize: i,
      sliceRepeat: s,
      pathText: r,
      wheelTouchEnd: l,
      onSectorClick: a
    };
  },
  data: function data() {
    return {
      pickBgColor: "#000",
      pickTxColor: "#fff",
      bgcurrent: 0,
      txcurrent: 0,
      bgColorOpen: !1,
      txColorOpen: !1,
      scrollTop: 0,
      isDisable: !0,
      isShowBgColorPicker: !1,
      isShowTextColorPicker: !1,
      spinTime: 3,
      fairMode: !1,
      title: "",
      type: "add",
      swipeOptions: [{
        text: "删除",
        style: {
          backgroundColor: "red"
        }
      }],
      activeSector: {
        sliceText: "",
        textColor: "#ffffff",
        backgroundColor: "#000000",
        probability: 1
      },
      activeSectorIndex: 0,
      isEdit: !1,
      activeColor: "",
      oldColor: "",
      thumbnail: "",
      mode: 0,
      showtransition: !1
    };
  },
  computed: _objectSpread2(_objectSpread2({}, e.mapState(["wheels"])), {}, {
    max: function max() {
      var e = this.sectors.length;
      return 0 === e ? 12 : e > 0 && e < 13 ? Math.floor(24 / e) : e > 12 ? 1 : 2;
    }
  }),
  onLoad: function onLoad(t) {
    var _this = this;

    if ("add" === t.type) switch (this.type = "add", this.sectors = [], this.mode = Number(t.mode) || 0, this.mode) {
      case 0:
        break;

      case 1:
        e.index.showModal({
          title: "输入扇叶名称，用中文逗号分隔",
          editable: !0,
          placeholderText: "名称1，名称2，名称3",
          success: function success(t) {
            t.confirm ? _this.sectors = t.content.split("，").map(function (e, t) {
              return {
                sliceText: e,
                textColor: _this.getColor(a, t),
                backgroundColor: _this.getColor(l, t)
              };
            }) : e.index.navigateBack();
          }
        });
        break;

      case 2:
        this.sectors = [{
          sliceText: "黑",
          textColor: "#E3E0F3",
          backgroundColor: "#3B3B3B"
        }, {
          sliceText: "白",
          textColor: "#3B3B3B",
          backgroundColor: "#E3E0F3"
        }], this.sliceRepeat = 8;
        break;

      case 3:
        this.sectors = new Array(8).fill("").map(function (e, t) {
          return {
            sliceText: "",
            textColor: _this.getColor(a, t),
            backgroundColor: _this.getColor(l, t)
          };
        }), this.sliceRepeat = 2;
    } else "edit" !== t.type && "clone" !== t.type || (this.type = t.type, this.id = t.id, this.where = "_id=='".concat(t.id, "'"), o.where(this.where).get().then(function (_ref) {
      var e = _ref.result.data;
      _this.title = e[0].title + ("clone" === t.type ? "克隆" : ""), _this.pathText = e[0].pathText, _this.textSize = e[0].textSize, _this.sliceRepeat = e[0].sliceRepeat, _this.spinTime = e[0].spinTime, _this.fairMode = e[0].fairMode, _this.sectors = e[0].slices, "edit" === t.type && (_this.thumbnail = e[0].thumbnail);
    }));
    this.onSectorClick = this.editSector;
  },
  methods: _objectSpread2(_objectSpread2({}, e.mapMutations(["addWheel", "setNeedFresh"])), {}, {
    probabilityChange: function probabilityChange(e) {
      this.activeSector.probability = e;
    },
    close: function close() {
      this.bgcurrent = 0, this.txcurrent = 0, this.bgColorOpen = !1, this.txColorOpen = !1, this.$refs.popup.close();
    },
    open: function open() {
      this.$refs.popup.open();
    },
    currentChange: function currentChange(e, t) {
      this[t] = e;
    },
    bgColorChange: function bgColorChange(e) {
      this.bgColorOpen = !1, this.txColorOpen = !1, e.includes("0") && (this.bgColorOpen = !0), e.includes("1") && (this.txColorOpen = !0);
    },
    togole: function togole() {
      this.showtransition = !this.showtransition;
    },
    startSort: function startSort() {
      this.isDisable = !this.isDisable;
    },
    sortChange: function sortChange(e) {
      this.sectors = e;
    },
    handleColorChange: function handleColorChange(e, t) {
      this.activeSector[t] = e;
    },
    rotateText: function rotateText() {
      this.pathText = !this.pathText;
    },
    sliderChange: function sliderChange(e, t) {
      this[t] = e.detail.value;
    },
    showColorPicker: function showColorPicker(e) {
      this.oldColor = this.activeSector[e];
    },
    shuffle: function shuffle() {
      var _this2 = this;

      0 !== this.sectors.length ? e.index.showModal({
        title: "提示",
        content: "确认打乱扇叶排序吗？",
        success: function success(e) {
          e.confirm && (_this2.sectors = _this2.sectors.sort(function () {
            return Math.random() - .5;
          }));
        }
      }) : e.index.showToast({
        icon: "none",
        title: "请先添加扇叶"
      });
    },
    editSector: function editSector(e, t) {
      this.activeSector = _objectSpread2({
        probability: 1
      }, e), this.activeSectorIndex = t, this.pickBgColor = e.backgroundColor, this.pickTxColor = e.textColor, this.isEdit = !0, this.open();
    },
    getColor: function getColor() {
      var e = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : l;
      var t = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : -1;
      var o = n[e].length;
      return t > 0 && t < o ? n[e][t] : n[e][Math.floor(Math.random() * o)];
    },
    showContainer: function showContainer() {
      var e = this.getColor(a),
          t = this.getColor(l);
      this.activeSector = {
        probability: 1,
        sliceText: "",
        textColor: e,
        backgroundColor: t
      }, this.pickBgColor = t, this.pickTxColor = e, this.isEdit = !1, this.open();
    },
    add: function add() {
      var _this3 = this;

      return _asyncToGenerator2( /*#__PURE__*/_regenerator.default.mark(function _callee() {
        return _regenerator.default.wrap(function _callee$(_context) {
          while (1) {
            switch (_context.prev = _context.next) {
              case 0:
                _this3.close();

                if (!_this3.isEdit) {
                  _context.next = 5;
                  break;
                }

                _this3.sectors.splice(_this3.activeSectorIndex, 1, _this3.activeSector);

                _context.next = 9;
                break;

              case 5:
                _this3.sectors.push(_this3.activeSector);

                _context.next = 8;
                return e.nextTick$1();

              case 8:
                _this3.scrollTop = 48 * _this3.sectors.length;

              case 9:
              case "end":
                return _context.stop();
            }
          }
        }, _callee);
      }))();
    },
    deleteSlice: function deleteSlice() {
      var _this4 = this;

      e.index.showModal({
        content: "确认删除吗？",
        success: function success(e) {
          e.confirm && (_this4.sectors.splice(_this4.activeSectorIndex, 1), _this4.close());
        }
      });
    },
    save: function save() {
      var _this5 = this;

      return _asyncToGenerator2( /*#__PURE__*/_regenerator.default.mark(function _callee2() {
        var t, l, _yield$e$Ds$uploadFil, a, n, _yield$o$add, _t;

        return _regenerator.default.wrap(function _callee2$(_context2) {
          while (1) {
            switch (_context2.prev = _context2.next) {
              case 0:
                if (!(_this5.sectors.length < 2)) {
                  _context2.next = 2;
                  break;
                }

                return _context2.abrupt("return", void e.index.showToast({
                  icon: "none",
                  title: "最少添加两个扇叶"
                }));

              case 2:
                e.index.showLoading({
                  mask: !0
                });
                t = _this5.sectors.map(function (e) {
                  return e.sliceText;
                });
                _context2.next = 6;
                return r.check(_this5.title + t.toString());

              case 6:
                if (_context2.sent) {
                  _context2.next = 8;
                  break;
                }

                return _context2.abrupt("return", (e.index.hideLoading(), void e.index.showToast({
                  icon: "none",
                  title: "内容违规，请检查文本后重新输入"
                })));

              case 8:
                _context2.next = 10;
                return _this5.getTempFilePath();

              case 10:
                l = _context2.sent;
                _context2.next = 13;
                return e.Ds.uploadFile({
                  filePath: l,
                  cloudPath: "wheelThumbnail.png"
                });

              case 13:
                _yield$e$Ds$uploadFil = _context2.sent;
                a = _yield$e$Ds$uploadFil.fileID;
                n = {
                  pathText: _this5.pathText,
                  textSize: _this5.textSize,
                  sliceRepeat: _this5.sliceRepeat,
                  spinTime: _this5.spinTime,
                  fairMode: _this5.fairMode,
                  title: _this5.title || "未命名的转盘",
                  slices: _this5.sectors,
                  thumbnail: a
                };

                if (!("add" === _this5.type || "clone" === _this5.type)) {
                  _context2.next = 31;
                  break;
                }

                _context2.next = 19;
                return o.add(n);

              case 19:
                _yield$o$add = _context2.sent;
                _t = _yield$o$add.result;
                _context2.next = 23;
                return i.addWheel(_t.id);

              case 23:
                _this5.addWheel(_t.id);

                _this5.type = "edit";
                _this5.thumbnail = a;
                _this5.id = _t.id;
                e.index.hideLoading();
                e.index.navigateTo({
                  url: "../detail-wheel/detail-wheel?id=" + _t.id
                });
                _context2.next = 40;
                break;

              case 31:
                _context2.t0 = "edit" === _this5.type;

                if (!_context2.t0) {
                  _context2.next = 40;
                  break;
                }

                _this5.setNeedFresh(!0);

                o.where({
                  _id: _this5.id
                }).update(n);
                _context2.next = 37;
                return s.delete(_this5.thumbnail);

              case 37:
                _this5.thumbnail = a;
                e.index.hideLoading();
                e.index.navigateTo({
                  url: "../detail-wheel/detail-wheel?id=" + _this5.id
                });

              case 40:
              case "end":
                return _context2.stop();
            }
          }
        }, _callee2);
      }))();
    },
    sliceInput: function sliceInput(e, t) {
      this.sectors[e].sliceText = t.detail.value;
    }
  })
};if (!Array) {
  (e.resolveComponent("drag-sort") + e.resolveComponent("uni-number-box") + e.resolveComponent("color-picker") + e.resolveComponent("uni-collapse-item") + e.resolveComponent("uni-collapse") + e.resolveComponent("uni-popup"))();
}Math || (function () {
  return "../../components/drag-sort/drag-sort.js";
} + function () {
  return "../../uni_modules/uni-number-box/components/uni-number-box/uni-number-box.js";
} + function () {
  return "../../components/color-picker/color-picker.js";
} + function () {
  return "../../uni_modules/uni-collapse/components/uni-collapse-item/uni-collapse-item.js";
} + function () {
  return "../../uni_modules/uni-collapse/components/uni-collapse/uni-collapse.js";
} + function () {
  return "../../uni_modules/uni-popup/components/uni-popup/uni-popup.js";
})();var h = e._export_sfc(c, [["render", function (t, o, i, s, r, l) {
  return e.e({
    a: r.title,
    b: e.o(function (e) {
      return r.title = e.detail.value;
    }),
    c: e.o(function () {
      return l.rotateText && l.rotateText.apply(l, arguments);
    }),
    d: e.o(function () {
      return s.wheelTouchEnd && s.wheelTouchEnd.apply(s, arguments);
    }),
    e: e.t(s.textSize),
    f: s.textSize,
    g: e.o(function (e) {
      return l.sliderChange(e, "textSize");
    }),
    h: e.o(function (e) {
      return l.sliderChange(e, "textSize");
    }),
    i: e.t(s.sliceRepeat),
    j: s.sliceRepeat,
    k: e.o(function (e) {
      return l.sliderChange(e, "sliceRepeat");
    }),
    l: e.o(function (e) {
      return l.sliderChange(e, "sliceRepeat");
    }),
    m: l.max,
    n: e.t(r.spinTime),
    o: r.spinTime,
    p: e.o(function (e) {
      return l.sliderChange(e, "spinTime");
    }),
    q: e.o(function (e) {
      return l.sliderChange(e, "spinTime");
    }),
    r: e.o(function () {
      return l.shuffle && l.shuffle.apply(l, arguments);
    }),
    s: e.o(function () {
      return l.showContainer && l.showContainer.apply(l, arguments);
    }),
    t: e.o(l.sortChange),
    v: e.o(l.editSector),
    w: e.p({
      isDisable: r.isDisable,
      items: s.sectors,
      rowHeight: 48
    }),
    x: r.scrollTop,
    y: !r.isDisable,
    z: e.o(function () {
      return l.startSort && l.startSort.apply(l, arguments);
    }),
    A: e.o(function () {
      return l.showContainer && l.showContainer.apply(l, arguments);
    }),
    B: e.o(function () {
      return l.save && l.save.apply(l, arguments);
    }),
    C: e.t(r.activeSector.sliceText),
    D: r.activeSector.backgroundColor,
    E: r.activeSector.textColor,
    F: r.activeSector.sliceText,
    G: e.o(function (e) {
      return r.activeSector.sliceText = e.detail.value;
    }),
    H: e.o(l.probabilityChange),
    I: e.p({
      value: r.activeSector.probability,
      min: 1,
      max: 100
    }),
    J: r.bgColorOpen
  }, r.bgColorOpen ? {
    K: e.t(0 === r.bgcurrent ? "调色盘" : "自定义")
  } : {
    L: r.activeSector.backgroundColor
  }, {
    M: e.o(function (e) {
      return l.handleColorChange(e, "backgroundColor");
    }),
    N: e.o(function (e) {
      return l.currentChange(e, "bgcurrent");
    }),
    O: e.p({
      current: r.bgcurrent,
      color: r.pickBgColor
    }),
    P: e.n(r.bgColorOpen ? "border" : ""),
    Q: e.p({
      "title-border": "none",
      border: !1,
      showArrow: !1,
      open: r.bgColorOpen
    }),
    R: r.txColorOpen
  }, r.txColorOpen ? {
    S: e.t(0 === r.txcurrent ? "调色盘" : "自定义")
  } : {
    T: r.activeSector.textColor
  }, {
    U: e.o(function (e) {
      return l.handleColorChange(e, "textColor");
    }),
    V: e.o(function (e) {
      return l.currentChange(e, "txcurrent");
    }),
    W: e.p({
      current: r.txcurrent,
      color: r.pickTxColor
    }),
    X: e.n(r.txColorOpen ? "border" : ""),
    Y: e.p({
      "title-border": "none",
      border: !1,
      showArrow: !1,
      open: r.txColorOpen
    }),
    Z: e.o(l.bgColorChange),
    aa: r.isEdit
  }, r.isEdit ? {
    ab: e.o(function () {
      return l.deleteSlice && l.deleteSlice.apply(l, arguments);
    })
  } : {}, {
    ac: e.o(function () {
      return l.close && l.close.apply(l, arguments);
    }),
    ad: e.o(function () {
      return l.add && l.add.apply(l, arguments);
    }),
    ae: e.sr("popup", "58e28ff3-1"),
    af: e.p({
      safeArea: !1,
      "background-color": "#fff",
      type: "bottom"
    })
  });
}]]);wx.createPage(h);