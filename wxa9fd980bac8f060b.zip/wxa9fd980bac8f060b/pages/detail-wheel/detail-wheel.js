var _interopRequireDefault = require("../../@babel/runtime/helpers/interopRequireDefault");var _regenerator = _interopRequireDefault(require("../../@babel/runtime/regenerator"));var _toConsumableArray2 = require("../../@babel/runtime/helpers/toConsumableArray");var _asyncToGenerator2 = require("../../@babel/runtime/helpers/asyncToGenerator");var _objectSpread2 = require("../../@babel/runtime/helpers/objectSpread2");var e = require("../../common/vendor.js"),
    t = require("../../composables/videoAd.js"),
    i = require("../../composables/useCanvasWheel.js");require("../../store/index.js");var s = e.Ds.database(),
    o = s.collection("spin-list");s.collection("uni-id-scores");var n = e.Ds.importObject("user", {
  customUI: !0
}),
    a = e.Ds.importObject("wheel", {
  customUI: !0
});var c,
    h,
    r = "";var l = {
  setup: function setup() {
    var _i$useCanvasWheel = i.useCanvasWheel("canvas", !1, !1),
        e = _i$useCanvasWheel.sectors,
        t = _i$useCanvasWheel.wheelTouchEnd,
        s = _i$useCanvasWheel.onStart,
        o = _i$useCanvasWheel.onEnd,
        n = _i$useCanvasWheel.pointSector,
        a = _i$useCanvasWheel.restWheel,
        c = _i$useCanvasWheel.pathText,
        h = _i$useCanvasWheel.sliceRepeat,
        r = _i$useCanvasWheel.textSize,
        l = _i$useCanvasWheel.spinTime,
        d = _i$useCanvasWheel.disable,
        p = _i$useCanvasWheel.fairMode,
        u = _i$useCanvasWheel.hideSlice,
        m = _i$useCanvasWheel.tot,
        S = _i$useCanvasWheel.startSpin,
        w = _i$useCanvasWheel.animate,
        y = _i$useCanvasWheel.getTempFilePath,
        g = _i$useCanvasWheel.hideSliceEdit,
        x = _i$useCanvasWheel.draw,
        f = _i$useCanvasWheel.spinning,
        k = _i$useCanvasWheel.ang;

    return {
      sectors: e,
      wheelTouchEnd: t,
      onStart: s,
      onEnd: o,
      pointSector: n,
      restWheel: a,
      pathText: c,
      sliceRepeat: h,
      textSize: r,
      spinTime: l,
      disable: d,
      fairMode: p,
      hideSlice: u,
      tot: m,
      startSpin: S,
      animate: w,
      getTempFilePath: y,
      hideSliceEdit: g,
      draw: x,
      spinning: f,
      ang: k
    };
  },
  data: function data() {
    return {
      title: "",
      showBtn: !1,
      type: "",
      ismine: !1,
      isLucky: !1,
      bgcolor: "#f8f8f8",
      txcolor: "#444",
      isShare: !1,
      wheelData: {},
      isAdd: !1,
      history: [],
      showHistory: !1,
      showHome: !1,
      videoAd: !1,
      contentVal: ""
    };
  },
  computed: _objectSpread2(_objectSpread2(_objectSpread2(_objectSpread2({}, e.mapGetters(["isMember"])), e.mapState(["score", "isSpinLucky", "sysInfo", "showSound", "isMute"])), e.mapState({
    ilike: function ilike(e) {
      return e.like.some(function (e) {
        return e === r;
      });
    },
    showAddToMy: function showAddToMy(e) {
      return "share" === this.type && !e.wheels.includes(r);
    }
  })), {}, {
    showHideSlice: function showHideSlice() {
      return this.tot / this.sliceRepeat > 2;
    },
    displayText: function displayText() {
      var e = this.pointSector.sliceText;
      return e && e.length > 44 ? e.substr(0, 43) + "..." : e;
    },
    canvasSize: function canvasSize() {
      var _this$sysInfo = this.sysInfo,
          e = _this$sysInfo.screenWidth,
          t = _this$sysInfo.screenHeight;

      if (t / e < 2) {
        return t - function (t) {
          return t * e / 750;
        }(700) + "px";
      }

      return "750rpx";
    },
    miniPhone: function miniPhone() {
      var _this$sysInfo2 = this.sysInfo,
          e = _this$sysInfo2.screenWidth,
          t = _this$sysInfo2.screenHeight;
      return t / e < 2.1;
    },
    safeBottom: function safeBottom() {
      var e = this.sysInfo.safeAreaInsets.bottom;
      return e + "rpx";
    }
  }),
  onLoad: function onLoad(t) {
    var _this = this;

    return _asyncToGenerator2( /*#__PURE__*/_regenerator.default.mark(function _callee() {
      var i;
      return _regenerator.default.wrap(function _callee$(_context) {
        while (1) {
          switch (_context.prev = _context.next) {
            case 0:
              1 === getCurrentPages().length && (_this.showHome = !0), _this.animate = _this.$scope.animate, _this.clearAnimation = _this.$scope.clearAnimation, r = t.id, _this.type = t.type;
              _context.next = 3;
              return _this.getData();

            case 3:
              i = _context.sent;
              if (_this.wheelData = i, _this.pathText = i.pathText, _this.sliceRepeat = i.sliceRepeat, _this.textSize = i.textSize, _this.spinTime = i.spinTime, _this.sectors = i.slices, _this.isLucky = i.isLucky, _this.fairMode = i.fairMode, _this.isShare = i.isShare, i.isLucky && (_this.disable = _this.isSpinLucky), _this.onStart = function () {
                _this.showBtn = !1;
              }, _this.onEnd = function () {
                _this.isLucky && _this.addScore(), _this.showBtn = !0, _this.bgcolor = _this.pointSector.backgroundColor, _this.txcolor = _this.pointSector.textColor, _this.history = [{
                  index: _this.history.length + 1,
                  backgroundColor: _this.pointSector.backgroundColor,
                  textColor: _this.pointSector.textColor,
                  sliceText: _this.pointSector.sliceText,
                  time: Date.now()
                }].concat(_toConsumableArray2(_this.history));
              }, c = "num".concat(_this.getNewDate()), h = "ad".concat(_this.getNewDate()), e.wx$1.getStorageSync(h)) ;else {
                try {
                  e.wx$1.getStorageInfoSync().keys.filter(function (e) {
                    return e.startsWith("ad");
                  }).filter(function (t) {
                    e.wx$1.removeStorage({
                      key: t
                    });
                  });
                } catch (s) {}

                try {
                  e.wx$1.setStorageSync(h, 0);
                } catch (s) {}
              }
              if (e.wx$1.getStorageSync(c)) ;else if (0 !== e.wx$1.getStorageSync(c)) {
                try {
                  e.wx$1.getStorageInfoSync().keys.filter(function (e) {
                    return e.startsWith("num");
                  }).filter(function (t) {
                    e.wx$1.removeStorage({
                      key: t
                    });
                  });
                } catch (s) {}

                try {
                  e.wx$1.setStorageSync(c, 10);
                } catch (s) {}
              }

            case 6:
            case "end":
              return _context.stop();
          }
        }
      }, _callee);
    }))();
  },
  onShareAppMessage: function onShareAppMessage(_ref) {
    var e = _ref.from;
    return "button" === e ? {
      title: this.title,
      path: "/pages/detail-wheel/detail-wheel?type=share&id=".concat(r)
    } : {
      title: "快来和我一起转转转",
      path: "/pages/index/index",
      imageUrl: "/static/share-logo.png"
    };
  },
  methods: _objectSpread2(_objectSpread2({}, e.mapMutations(["increScore", "setIsSpinLucky", "setMute", "addLike", "removeLike", "addWheel", "addRole"])), {}, {
    spinClick: function spinClick() {
      var _this2 = this;

      if (this.hideSliceEdit) this.restWheel();else {
        if (this.tot < 2) return void e.index.showModal({
          title: "提示",
          content: "至少需要两个可用的扇叶",
          showCancel: !1
        });

        var _i = e.wx$1.getStorageSync(c),
            _s = e.wx$1.getStorageSync(h);

        this.isMember ? this.startSpin() : _s < 3 ? 0 === _i ? e.index.showModal({
          title: "提示",
          cancelText: "了解会员",
          confirmText: "看小视频",
          content: "今日次数已用完，看小视频或开通会员免费获取次数",
          success: function success(i) {
            i.confirm ? t.videoAd.showRewardVideoAd("adunit-3b171d8166dde59b", function () {
              e.wx$1.setStorageSync(c, 8), e.wx$1.setStorageSync(h, _s + 1), e.index.showModal({
                showCancel: !1,
                content: "恭喜你，获得8次旋转机会！观看三次小视频后不限旋转次数"
              });
            }, function () {
              e.index.showToast({
                title: "已关闭",
                icon: "none"
              });
            }) : i.cancel && _this2.$refs.popupMember.showMembershipPopup();
          }
        }) : (e.wx$1.setStorageSync(c, _i - 1), this.startSpin()) : this.startSpin();
      }
    },
    openEdit: function openEdit() {
      this.spinning ? e.index.showToast({
        icon: "none",
        title: "转盘正在旋转中"
      }) : (this.hideSliceEdit = !0, this.$scope.clearAnimation("#canvas"), this.ang = 0, this.showBtn = !1, this.pointSector = {
        sliceText: ""
      }, this.draw());
    },
    closeEdit: function closeEdit() {
      this.hideSliceEdit = !1, this.draw();
    },
    popupChange: function popupChange(_ref2) {
      var e = _ref2.show;
      this.showHistory = e;
    },
    openHistory: function openHistory() {
      0 !== this.history.length ? this.$refs.popup.open() : e.index.showToast({
        icon: "none",
        title: "还没有旋转记录"
      });
    },
    closeHistory: function closeHistory() {
      this.$refs.popup.close();
    },
    likeWheel: function likeWheel() {
      var _this3 = this;

      return _asyncToGenerator2( /*#__PURE__*/_regenerator.default.mark(function _callee2() {
        return _regenerator.default.wrap(function _callee2$(_context2) {
          while (1) {
            switch (_context2.prev = _context2.next) {
              case 0:
                _this3.addLike(r);

                _context2.next = 3;
                return Promise.all([a.increaseLike(r), n.like(r)]);

              case 3:
              case "end":
                return _context2.stop();
            }
          }
        }, _callee2);
      }))();
    },
    unlikeWheel: function unlikeWheel() {
      var _this4 = this;

      return _asyncToGenerator2( /*#__PURE__*/_regenerator.default.mark(function _callee3() {
        return _regenerator.default.wrap(function _callee3$(_context3) {
          while (1) {
            switch (_context3.prev = _context3.next) {
              case 0:
                _this4.removeLike(r);

                _context3.next = 3;
                return Promise.all([a.decreaseLike(r), n.unlike(r)]);

              case 3:
              case "end":
                return _context3.stop();
            }
          }
        }, _callee3);
      }))();
    },
    mute: function mute(e) {
      this.setMute(e);
    },
    clickLeft: function clickLeft() {
      this.showHome ? this.home() : this.back();
    },
    back: function back() {
      e.index.navigateBack();
    },
    home: function home() {
      e.index.switchTab({
        url: "/pages/index/index"
      });
    },
    isToday: function isToday(e) {
      return new Date().getTime() - e < 864e5;
    },
    hideSector: function hideSector() {
      this.hideSlice(), this.showBtn = !1;
    },
    addScore: function addScore() {
      var _this5 = this;

      this.disable = !0, this.setIsSpinLucky(!0);
      var t = this.pointSector.sliceValue,
          i = {
        balance: this.score + t,
        comment: "幸运转盘",
        score: t,
        type: 1
      };
      n.setScore(i).then(function () {
        _this5.increScore(t), e.index.showModal({
          showCancel: !1,
          content: "\u606D\u559C\u4F60\uFF0C\u589E\u52A0\u4E86".concat(t, "\u79EF\u5206\uFF01")
        });
      });
    },
    addToMy: function addToMy() {
      var _this6 = this;

      this.spinning ? e.index.showToast({
        icon: "none",
        title: "转盘正在旋转中"
      }) : e.index.showModal({
        title: "提示",
        content: "确认添加到我的转盘吗？添加后可以在首页看到此转盘",
        success: function () {
          var _success = _asyncToGenerator2( /*#__PURE__*/_regenerator.default.mark(function _callee4(t) {
            var _t, _yield$e$Ds$uploadFil, _i2, _s2, _yield$o$add, _a;

            return _regenerator.default.wrap(function _callee4$(_context4) {
              while (1) {
                switch (_context4.prev = _context4.next) {
                  case 0:
                    if (!t.confirm) {
                      _context4.next = 25;
                      break;
                    }

                    if (!(e.index.showLoading({
                      mask: !0
                    }), _this6.rest(), _this6.isShare)) {
                      _context4.next = 7;
                      break;
                    }

                    _context4.next = 4;
                    return Promise.all([a.increaseDownload(r), n.addWheel(r)]);

                  case 4:
                    _this6.addWheel(r);

                    _context4.next = 24;
                    break;

                  case 7:
                    _context4.next = 9;
                    return _this6.getTempFilePath(!0);

                  case 9:
                    _t = _context4.sent;
                    _context4.next = 12;
                    return e.Ds.uploadFile({
                      filePath: _t,
                      cloudPath: "wheelThumbnail.png"
                    });

                  case 12:
                    _yield$e$Ds$uploadFil = _context4.sent;
                    _i2 = _yield$e$Ds$uploadFil.fileID;

                    _this6.draw();

                    _s2 = _objectSpread2(_objectSpread2({}, _this6.wheelData), {}, {
                      thumbnail: _i2
                    });
                    delete _s2._id, delete _s2.user_id, delete _s2.create_time;
                    _context4.next = 19;
                    return o.add(_s2);

                  case 19:
                    _yield$o$add = _context4.sent;
                    _a = _yield$o$add.result;
                    _context4.next = 23;
                    return n.addWheel(_a.id);

                  case 23:
                    _this6.addWheel(_a.id);

                  case 24:
                    _this6.isAdd = !0, e.index.hideLoading(), e.index.showToast({
                      title: "添加成功"
                    });

                  case 25:
                  case "end":
                    return _context4.stop();
                }
              }
            }, _callee4);
          }));

          function success(_x) {
            return _success.apply(this, arguments);
          }

          return success;
        }()
      });
    },
    rest: function rest() {
      this.restWheel(), this.showBtn = !1, this.bgcolor = "#f8f8f8", this.txcolor = "#444", this.$scope.clearAnimation("#canvas");
    },
    getNewDate: function getNewDate() {
      var e = new Date();
      return "".concat(e.getUTCFullYear()).concat((e.getUTCMonth() + 1).toString().padStart(2, "0")).concat(e.getUTCDate().toString().padStart(2, "0"));
    },
    onSuccess: function onSuccess(e) {
      console.log("success: ", e), e.user_order_success ? this.addRole("MEMBER") : (this.addRole("MEMBER"), console.log("支付成功，但报错了"));
    },
    getData: function getData() {
      var _this7 = this;

      return _asyncToGenerator2( /*#__PURE__*/_regenerator.default.mark(function _callee5() {
        var _yield$o$where$get, t;

        return _regenerator.default.wrap(function _callee5$(_context5) {
          while (1) {
            switch (_context5.prev = _context5.next) {
              case 0:
                _context5.next = 2;
                return o.where("_id=='".concat(r, "'")).get();

              case 2:
                _yield$o$where$get = _context5.sent;
                t = _yield$o$where$get.result.data;
                _context5.prev = 4;
                _this7.title = t[0].title;
                _context5.next = 11;
                break;

              case 8:
                _context5.prev = 8;
                _context5.t0 = _context5["catch"](4);
                return _context5.abrupt("return", void e.index.showModal({
                  title: "提示",
                  content: "当前转盘已经被删除，点击确认回到首页",
                  showCancel: !1,
                  success: function success() {
                    e.index.switchTab({
                      url: "/pages/index/index"
                    });
                  }
                }));

              case 11:
                return _context5.abrupt("return", (e.index.setNavigationBarTitle({
                  title: t[0].title
                }), t[0]));

              case 12:
              case "end":
                return _context5.stop();
            }
          }
        }, _callee5, null, [[4, 8]]);
      }))();
    }
  })
};if (!Array) {
  (e.resolveComponent("uni-icons") + e.resolveComponent("uni-nav-bar") + e.resolveComponent("uni-popup") + e.resolveComponent("member-popup"))();
}Math || (function () {
  return "../../uni_modules/uni-icons/components/uni-icons/uni-icons.js";
} + function () {
  return "../../uni_modules/uni-nav-bar/components/uni-nav-bar/uni-nav-bar.js";
} + function () {
  return "../../uni_modules/uni-popup/components/uni-popup/uni-popup.js";
} + function () {
  return "../../components/member-popup/member-popup.js";
})();var d = e._export_sfc(l, [["render", function (t, i, s, o, n, a) {
  return e.e({
    a: e.o(a.clickLeft),
    b: e.p({
      type: n.showHome ? "home" : "back",
      size: "30"
    }),
    c: !n.showHome && n.isShare && !t.ilike,
    d: e.o(a.likeWheel),
    e: e.p({
      type: "hand-up",
      size: "30"
    }),
    f: !n.showHome && n.isShare && t.ilike,
    g: e.o(a.unlikeWheel),
    h: e.p({
      type: "hand-up-filled",
      size: "30"
    }),
    i: t.showAddToMy && !n.isAdd,
    j: e.o(a.addToMy),
    k: e.p({
      "custom-prefix": "iconfont",
      type: "icon-shoucang",
      size: "28"
    }),
    l: t.showAddToMy && n.isAdd,
    m: e.p({
      "custom-prefix": "iconfont",
      type: "icon-shoucang-fill",
      size: "28"
    }),
    n: !n.showHistory,
    o: e.o(a.openHistory),
    p: e.p({
      "custom-prefix": "iconfont",
      type: "icon-jilu",
      size: "25"
    }),
    q: n.showHistory,
    r: e.o(a.closeHistory),
    s: e.p({
      "custom-prefix": "iconfont",
      type: "icon-jilu-fill",
      size: "25"
    }),
    t: !o.hideSliceEdit,
    v: e.o(a.openEdit),
    w: e.p({
      "custom-prefix": "iconfont",
      type: "icon-slice-edit",
      size: "25"
    }),
    x: o.hideSliceEdit,
    y: e.o(a.closeEdit),
    z: e.p({
      "custom-prefix": "iconfont",
      type: "icon-slice-edit-fill",
      size: "25"
    }),
    A: t.showSound && !t.isMute,
    B: e.o(function (e) {
      return a.mute(!0);
    }),
    C: e.p({
      type: "sound",
      size: "30"
    }),
    D: t.showSound && t.isMute,
    E: e.o(function (e) {
      return a.mute(!1);
    }),
    F: e.p({
      "custom-prefix": "iconfont",
      type: "icon-mute",
      size: "30"
    }),
    G: !n.isLucky && n.showBtn,
    H: e.o(a.rest),
    I: e.p({
      type: "reload",
      size: "30"
    }),
    J: e.p({
      title: "导航栏组件",
      statusBar: !0,
      fixed: !0,
      rightWidth: "160rpx",
      leftWidth: "70rpx",
      backgroundColor: "#f8f8f8",
      border: !1
    }),
    K: o.hideSliceEdit,
    L: e.t(n.title),
    M: !o.hideSliceEdit,
    N: e.t(a.displayText),
    O: n.txcolor,
    P: e.n(o.pointSector.sliceText.length > 13 ? "small" : ""),
    Q: !o.hideSliceEdit,
    R: a.canvasSize,
    S: a.canvasSize,
    T: e.o(function () {
      return o.wheelTouchEnd && o.wheelTouchEnd.apply(o, arguments);
    }),
    U: e.t(o.hideSliceEdit ? "重置" : "转"),
    V: e.o(function () {
      return a.spinClick && a.spinClick.apply(a, arguments);
    }),
    W: e.n(o.hideSliceEdit ? "small-spin" : ""),
    X: n.isLucky && o.disable
  }, (n.isLucky && o.disable, {}), {
    Y: n.showBtn && !a.miniPhone
  }, n.showBtn && !a.miniPhone ? e.e({
    Z: !n.isLucky && a.showHideSlice
  }, !n.isLucky && a.showHideSlice ? {
    aa: e.o(function () {
      return a.hideSector && a.hideSector.apply(a, arguments);
    })
  } : {}, {
    ab: !n.isLucky && !a.showHideSlice
  }, n.isLucky || a.showHideSlice ? {} : {
    ac: e.o(function () {
      return a.rest && a.rest.apply(a, arguments);
    })
  }) : {}, {
    ad: n.showBtn && a.miniPhone
  }, n.showBtn && a.miniPhone ? e.e({
    ae: !n.isLucky && a.showHideSlice
  }, !n.isLucky && a.showHideSlice ? {
    af: e.o(function () {
      return a.hideSector && a.hideSector.apply(a, arguments);
    })
  } : {}, {
    ag: !n.isLucky && !a.showHideSlice
  }, n.isLucky || a.showHideSlice ? {} : {
    ah: e.o(function () {
      return a.rest && a.rest.apply(a, arguments);
    })
  }) : {}, {
    ai: !t.isMember
  }, t.isMember ? {} : {
    aj: a.safeBottom
  }, {
    ak: e.f(n.history, function (t, i, s) {
      return {
        a: e.t(t.index),
        b: e.t(t.sliceText),
        c: i,
        d: t.backgroundColor,
        e: t.textColor
      };
    }),
    al: e.sr("popup", "48afbeb3-13"),
    am: e.o(a.popupChange),
    an: e.p({
      "background-color": "#fff",
      type: "top"
    }),
    ao: e.sr("popupMember", "48afbeb3-14"),
    ap: e.o(a.onSuccess),
    aq: e.p({
      contentVal: n.contentVal
    }),
    ar: n.bgcolor
  });
}]]);l.__runtimeHooks = 2, wx.createPage(d);