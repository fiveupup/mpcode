var e = require("../../common/vendor.js"),
    r = {
  data: function data() {
    return {
      src: ""
    };
  },
  onLoad: function onLoad() {
    this.src = e.index.getStorageSync("src");
  },
  onShareAppMessage: function onShareAppMessage() {
    return {
      title: "快来和我一起转转转",
      path: "/pages/index/index",
      imageUrl: "/static/share-logo.png"
    };
  },
  methods: {}
};var t = e._export_sfc(r, [["render", function (e, r, t, s, n, o) {
  return {
    a: n.src
  };
}]]);r.__runtimeHooks = 2, wx.createPage(t);