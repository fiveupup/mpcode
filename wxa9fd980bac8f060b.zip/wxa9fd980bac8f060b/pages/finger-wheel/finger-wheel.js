var _interopRequireDefault = require("../../@babel/runtime/helpers/interopRequireDefault");var _regenerator = _interopRequireDefault(require("../../@babel/runtime/regenerator"));var _asyncToGenerator2 = require("../../@babel/runtime/helpers/asyncToGenerator");var _objectSpread2 = require("../../@babel/runtime/helpers/objectSpread2");var t = require("../../common/vendor.js"),
    s = function s(t, _s) {
  return t = Math.ceil(t), _s = Math.floor(_s), Math.floor(Math.random() * (_s - t + 1)) + t;
},
    e = t.index.createInnerAudioContext({
  useWebAudioImplement: !0
});e.src = "/static/tap.mp3";var i = t.index.createInnerAudioContext({
  useWebAudioImplement: !0
});i.src = "/static/countdown.wav";var n = t.index.createInnerAudioContext({
  useWebAudioImplement: !0
});n.src = "/static/ding.mp3";var o = {
  data: function data() {
    return {
      active: -1,
      points: [],
      palettes: ["#f94144", "#BE0AFF", "#FF8700", "#277da1", "#90be6d", "#f9c74f", "#4d908e", "#0AEFFF", "#580AFF", "#f3722c"],
      seconds: 3,
      status: 0,
      timer: null
    };
  },
  computed: _objectSpread2(_objectSpread2({}, t.mapGetters(["isMember"])), t.mapState(["sysInfo", "isVibrate", "isMute"])),
  onLoad: function onLoad() {},
  onHide: function onHide() {
    this.init(), this.points = [], t.index.showTabBar();
  },
  methods: {
    touchstart: function touchstart(s) {
      this.points = s.touches, this.isVibrate && t.index.vibrateShort({
        type: "medium"
      }), t.index.hideTabBar(), s.touches.length > 1 && (this.init(), this.startCountDown());
    },
    init: function init() {
      this.active = -1, this.status = 0, this.seconds = 3, clearInterval(this.timer);
    },
    touchmove: function touchmove(t) {
      this.points = t.touches;
    },
    touchend: function touchend(s) {
      this.points = s.touches, this.init(), s.touches.length > 1 ? this.startCountDown() : 0 === s.touches.length && t.index.showTabBar();
    },
    startCountDown: function startCountDown() {
      var _this = this;

      this.status = 1, this.timer = setInterval(function () {
        _this.seconds--, 0 === _this.seconds ? (clearInterval(_this.timer), _this.start()) : _this.isMute || (i.stop(), i.play());
      }, 1e3);
    },
    start: function start() {
      var _this2 = this;

      return _asyncToGenerator2( /*#__PURE__*/_regenerator.default.mark(function _callee() {
        var i, o, a, h;
        return _regenerator.default.wrap(function _callee$(_context) {
          while (1) {
            switch (_context.prev = _context.next) {
              case 0:
                _this2.status = 2;
                i = Date.now() + 4e3;
                o = 60, a = 0, h = -1;

              case 3:
                if (!(Date.now() < i && 2 === _this2.status)) {
                  _context.next = 15;
                  break;
                }

                a = s(0, _this2.points.length - 1);
                a === h && (a = s(0, _this2.points.length - 1));
                h = a;
                _this2.active = _this2.points[a].identifier;
                _this2.isVibrate && t.index.vibrateShort({
                  type: "medium"
                });
                _this2.isMute || (e.stop(), e.play());
                _context.next = 12;
                return _this2.sleep(o);

              case 12:
                o *= 1.1;

              case 13:
                _context.next = 3;
                break;

              case 15:
                2 === _this2.status && (_this2.status = 3, _this2.isVibrate && t.index.vibrateLong(), _this2.isMute || (n.stop(), n.play()));

              case 16:
              case "end":
                return _context.stop();
            }
          }
        }, _callee);
      }))();
    },
    sleep: function sleep(t) {
      return new Promise(function (s) {
        return setTimeout(s, t);
      });
    }
  }
};var a = t._export_sfc(o, [["render", function (s, e, i, n, o, a) {
  return t.e({
    a: t.f(o.points, function (s, e, i) {
      return {
        a: o.palettes[e],
        b: o.palettes[e],
        c: t.n(s.identifier === o.active ? "gradient" : 3 === o.status ? "inactive" : ""),
        d: s.identifier,
        e: s.clientY + "px",
        f: s.clientX + "px"
      };
    }),
    b: 0 === o.status
  }, 0 === o.status ? {
    c: t.t("ios" === s.sysInfo.osName ? 5 : 10)
  } : {}, {
    d: 1 === o.status && 0 !== o.seconds
  }, 1 === o.status && 0 !== o.seconds ? {
    e: t.t(o.seconds)
  } : {}, {
    f: t.o(function () {
      return a.touchstart && a.touchstart.apply(a, arguments);
    }),
    g: t.o(function () {
      return a.touchmove && a.touchmove.apply(a, arguments);
    }),
    h: t.o(function () {
      return a.touchend && a.touchend.apply(a, arguments);
    }),
    i: !s.isMember
  }, (s.isMember, {}));
}]]);wx.createPage(a);