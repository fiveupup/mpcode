var _interopRequireDefault = require("../../@babel/runtime/helpers/interopRequireDefault");var _regenerator = _interopRequireDefault(require("../../@babel/runtime/regenerator"));var _asyncToGenerator2 = require("../../@babel/runtime/helpers/asyncToGenerator");var _objectSpread2 = require("../../@babel/runtime/helpers/objectSpread2");var e = require("../../common/vendor.js"),
    t = e.Ds.importObject("setting", {
  customUI: !0
}),
    i = {
  data: function data() {
    return {};
  },
  computed: e.mapState(["isSpinLucky", "score", "isVibrate", "isMute", "avatar", "nickname", "commonSetting", "userid"]),
  onShareAppMessage: function onShareAppMessage() {
    return {
      title: "快来和我一起转转转",
      path: "/pages/index/index",
      imageUrl: "/static/share-logo.png"
    };
  },
  methods: _objectSpread2(_objectSpread2({}, e.mapMutations(["setVibrate", "setMute"])), {}, {
    toUserinfo: function toUserinfo() {
      e.index.navigateTo({
        url: "../userinfo/userinfo"
      });
    },
    toMp: function toMp() {
      return _asyncToGenerator2( /*#__PURE__*/_regenerator.default.mark(function _callee() {
        var i;
        return _regenerator.default.wrap(function _callee$(_context) {
          while (1) {
            switch (_context.prev = _context.next) {
              case 0:
                _context.next = 2;
                return t.getMpUrl();

              case 2:
                i = _context.sent;
                e.index.setStorageSync("src", i), e.index.navigateTo({
                  url: "../web-view/web-view"
                });

              case 4:
              case "end":
                return _context.stop();
            }
          }
        }, _callee);
      }))();
    },
    toChannels: function toChannels() {
      e.index.openChannelsUserProfile({
        finderUserName: "sphZMHCitBwe9LH"
      });
    },
    toLucky: function toLucky() {
      this.isSpinLucky ? e.index.showToast({
        icon: "none",
        title: "今天已经转过幸运转盘了，明天再来吧！"
      }) : e.index.navigateTo({
        url: "/pages/detail-wheel/detail-wheel?id=".concat(this.commonSetting.luckyId)
      });
    },
    showScore: function showScore() {
      e.index.showModal({
        title: "剩余积分",
        content: this.score + "",
        showCancel: !1
      });
    },
    vibrateChange: function vibrateChange(e) {
      this.setVibrate(e.detail.value);
    },
    muteChange: function muteChange(e) {
      this.setMute(!e.detail.value);
    },
    openTucao: function openTucao() {
      e.index.openEmbeddedMiniProgram({
        appId: "wx8abaf00ee8c3202e",
        extraData: {
          id: "527640"
        }
      });
    }
  })
};if (!Array) {
  e.resolveComponent("nx-cell")();
}Math;var n = e._export_sfc(i, [["render", function (t, i, n, o, a, s) {
  return {
    a: e.p({
      icon: "/static/logo.png",
      border: !0,
      title: "幸运转盘"
    }),
    b: e.o(function () {
      return s.toLucky && s.toLucky.apply(s, arguments);
    }),
    c: t.isVibrate,
    d: e.o(function () {
      return s.vibrateChange && s.vibrateChange.apply(s, arguments);
    }),
    e: e.p({
      icon: "/static/zhendong.png",
      border: !0,
      title: "触感"
    }),
    f: !t.isMute,
    g: e.o(function () {
      return s.muteChange && s.muteChange.apply(s, arguments);
    }),
    h: e.p({
      icon: "/static/volume-up.png",
      border: !0,
      title: "声音"
    }),
    i: e.p({
      icon: "/static/emblem.png",
      border: !0,
      title: "关注公众号"
    }),
    j: e.o(function () {
      return s.toMp && s.toMp.apply(s, arguments);
    }),
    k: e.p({
      icon: "/static/channels.png",
      border: !0,
      title: "关注视频号"
    }),
    l: e.o(function () {
      return s.toChannels && s.toChannels.apply(s, arguments);
    }),
    m: e.p({
      icon: "/static/feedback.png",
      border: !0,
      title: "反馈建议"
    }),
    n: e.o(function () {
      return s.openTucao && s.openTucao.apply(s, arguments);
    }),
    o: e.p({
      icon: "/static/service-icon.png",
      title: "联系客服"
    })
  };
}]]);i.__runtimeHooks = 2, wx.createPage(n);