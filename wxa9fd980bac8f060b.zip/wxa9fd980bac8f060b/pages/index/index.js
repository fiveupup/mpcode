var _interopRequireDefault = require("../../@babel/runtime/helpers/interopRequireDefault");var _regenerator = _interopRequireDefault(require("../../@babel/runtime/regenerator"));var _asyncToGenerator2 = require("../../@babel/runtime/helpers/asyncToGenerator");var _objectSpread2 = require("../../@babel/runtime/helpers/objectSpread2");var e = require("../../common/vendor.js"),
    t = require("../../composables/useCanvasWheel.js");require("../../store/index.js");var s = e.Ds.database().collection("spin-list"),
    i = e.Ds.importObject("user", {
  customUI: !0
}),
    o = e.Ds.importObject("file", {
  customUI: !0
}),
    a = e.Ds.importObject("setting", {
  customUI: !0
});var n = null,
    r = !0;var c = {
  setup: function setup() {
    var _t$useCanvasWheel = t.useCanvasWheel("shareCavas"),
        e = _t$useCanvasWheel.getTempFilePath,
        s = _t$useCanvasWheel.sectors,
        i = _t$useCanvasWheel.sliceRepeat;

    return {
      getTempFilePath: e,
      sectors: s,
      sliceRepeat: i
    };
  },
  data: function data() {
    return {
      shareFriend: !1,
      showLoadMore: !0,
      range: ["棋盘游戏", "机会与财富", "喜剧和乐趣", "娱乐活动", "食物和饮料", "聚会游戏", "音乐", "体育", "工具", "旅游与世界", "电子游戏", "其它"],
      isLoad: !1,
      active: {
        sliceRepeat: 1,
        slices: [],
        title: "",
        thumbnail: "",
        isShare: !1,
        category: 0
      },
      isShareItem: !1,
      content: [{
        iconPath: "/static/wheel-w.png",
        selectedIconPath: "/static/wheel-w.png",
        text: "空白模版",
        active: !1
      }, {
        iconPath: "/static/wheel-q.png",
        selectedIconPath: "/static/wheel-q.png",
        text: "快捷模版",
        active: !1
      }, {
        iconPath: "/static/wheel-wb.png",
        selectedIconPath: "/static/wheel-wb.png",
        text: "黑白模版",
        active: !1
      }, {
        iconPath: "/static/wheel-c.png",
        selectedIconPath: "/static/wheel-c.png",
        text: "彩色模版",
        active: !1
      }],
      pattern: {
        buttonColor: "#07C160"
      },
      contentVal: "存储转盘数量已达到上限，"
    };
  },
  computed: _objectSpread2(_objectSpread2({}, e.mapState({
    isManager: function isManager(e) {
      return e.role.includes("MANAGER");
    },
    wheels: function wheels(e) {
      return e.wheels;
    },
    score: function score(e) {
      return e.score;
    },
    needFresh: function needFresh(e) {
      return e.needFresh;
    },
    isSpinLucky: function isSpinLucky(e) {
      return e.isSpinLucky;
    },
    commonSetting: function commonSetting(e) {
      return e.commonSetting;
    },
    isLogin: function isLogin(e) {
      return e.isLogin;
    },
    where: function where(e) {
      return e.role.includes("MANAGER") ? "_id in ".concat(JSON.stringify(e.wheels), " || isShare==true") : "_id in ".concat(JSON.stringify(e.wheels));
    }
  })), e.mapGetters(["isMember", "wheelCount"])),
  watch: {
    isLogin: function isLogin() {
      this.getData();
    }
  },
  onLoad: function onLoad() {
    var _this = this;

    e.wx$1.createRewardedVideoAd && (n = e.wx$1.createRewardedVideoAd({
      adUnitId: "adunit-2625e8757cdf7646"
    }), n.onLoad(function () {}), n.onError(function (t) {
      e.index.showToast({
        icon: "none",
        title: "\u5C55\u793A\u5E7F\u544A\u5931\u8D25\uFF0C\u53EF\u4EE5\u5206\u4EAB\u6B64\u5C0F\u7A0B\u5E8F\u7ED9\u65B0\u7528\u6237\u83B7\u5F97".concat(_this.commonSetting.adScore, "\u79EF\u5206")
      }), _this.shareFriend = !0;
    }), n.onClose(function (t) {
      if (t && t.isEnded) {
        console.log("看广告增加积分");
        var _t = _this.commonSetting.adScore,
            _s = {
          balance: _this.score + _t,
          comment: "看广告增加积分",
          score: _t,
          type: 1
        };
        i.setScore(_s).then(function () {
          _this.increScore(_t), e.index.showModal({
            showCancel: !1,
            content: "\u606D\u559C\u4F60\uFF0C\u589E\u52A0\u4E86".concat(_t, "\u79EF\u5206\uFF01")
          });
        });
      }
    }));
  },
  onShow: function onShow() {
    if (this.needFresh && this.fresh(), r || this.isMember) r = !1;else {
      var _t2 = e.wx$1.createInterstitialAd({
        adUnitId: "adunit-e426816de95452de"
      });

      _t2.onLoad(function () {
        _t2.show().catch(function (e) {});
      });
    }
  },
  onReady: function onReady() {
    this.isLogin && this.getData();
  },
  onShareAppMessage: function onShareAppMessage(_ref) {
    var _this2 = this;

    var t = _ref.from,
        s = _ref.target;
    if ("button" === t) return this.close(), {
      title: this.active.title,
      path: "/pages/detail-wheel/detail-wheel?type=share&id=".concat(this.active._id),
      imageUrl: this.active.thumbnail
    };

    if (this.shareFriend && Date.now() - e.index.getStorageSync("shareFriendTime") > 864e5) {
      var _t3 = this.commonSetting.adScore,
          _s2 = {
        balance: this.score + _t3,
        comment: "分享新用户加积分",
        score: _t3,
        type: 1
      };
      i.setScore(_s2).then(function () {
        _this2.increScore(_t3);
      }), e.index.setStorageSync("shareFriendTime", Date.now());
    }

    return {
      title: "快来和我一起转转转",
      path: "/pages/index/index",
      imageUrl: "/static/share-logo.png"
    };
  },
  onShareTimeline: function onShareTimeline() {
    return {
      title: "超好玩！选择困难症的福音！聚会娱乐必备！"
    };
  },
  onReachBottom: function onReachBottom() {
    this.$refs.udb.loadMore();
  },
  onPullDownRefresh: function onPullDownRefresh() {
    this.$refs.udb.loadData({
      clear: !0
    }, function () {
      e.index.stopPullDownRefresh();
    });
  },
  methods: _objectSpread2(_objectSpread2({}, e.mapMutations(["setWheels", "decreScore", "setScore", "addRole", "setNeedFresh", "increScore"])), {}, {
    onSuccess: function onSuccess(e) {
      console.log("success: ", e), e.user_order_success ? this.addRole("MEMBER") : (this.addRole("MEMBER"), console.log("支付成功，但报错了"));
    },
    openAdd: function openAdd() {
      this.wheelCount > 9 && !this.isMember ? this.$refs.popupMember.showMembershipPopup() : this.$refs.add.open();
    },
    watchVideo: function watchVideo() {
      n && n.show().catch(function () {
        n.load().then(function () {
          return n.show();
        }).catch(function (e) {
          console.log("激励视频 广告显示失败");
        });
      });
    },
    close: function close() {
      this.$refs.popup.close();
    },
    open: function open() {
      this.$refs.popup.open();
    },
    getData: function getData() {
      var _this3 = this;

      return _asyncToGenerator2( /*#__PURE__*/_regenerator.default.mark(function _callee() {
        var _e;

        return _regenerator.default.wrap(function _callee$(_context) {
          while (1) {
            switch (_context.prev = _context.next) {
              case 0:
                if (!(0 === _this3.wheels.length)) {
                  _context.next = 5;
                  break;
                }

                _context.next = 3;
                return i.getWheels();

              case 3:
                _e = _context.sent;

                _this3.setWheels(_e);

              case 5:
                _context.next = 7;
                return e.nextTick$1();

              case 7:
                _this3.showLoadMore = !1;

                _this3.$refs.udb.loadData({
                  clear: !0
                });

              case 9:
              case "end":
                return _context.stop();
            }
          }
        }, _callee);
      }))();
    },
    fresh: function fresh() {
      this.$refs.udb.loadData({
        clear: !0
      }), this.setNeedFresh(!1);
    },
    handLoad: function handLoad() {
      this.isLoad = !0;
    },
    changeCategory: function changeCategory(e, t) {
      var _this4 = this;

      this.$refs.udb.update(t, {
        category: Number(e.detail.value)
      }, {
        success: function success() {
          _this4.fresh();
        }
      });
    },
    review: function review(t, s) {
      var _this5 = this;

      e.index.showModal({
        title: "审核转盘",
        content: s ? "确认允许发布？" : "确认拒绝发布？",
        confirmText: "确认",
        success: function success(e) {
          e.confirm && _this5.$refs.udb.update(t, {
            isReview: !0,
            reviewState: s
          }, {
            success: function success() {
              _this5.fresh();
            }
          });
        }
      });
    },
    onModeSelect: function onModeSelect(_ref2) {
      var t = _ref2.index;
      e.index.navigateTo({
        url: "../add-wheel/add-wheel?type=add&mode=".concat(t)
      }), this.$refs.add.close();
    },
    showTermsService: function showTermsService() {
      return _asyncToGenerator2( /*#__PURE__*/_regenerator.default.mark(function _callee2() {
        var t;
        return _regenerator.default.wrap(function _callee2$(_context2) {
          while (1) {
            switch (_context2.prev = _context2.next) {
              case 0:
                _context2.next = 2;
                return a.getServiceUrl();

              case 2:
                t = _context2.sent;
                e.index.setStorageSync("src", t), e.index.navigateTo({
                  url: "../web-view/web-view"
                });

              case 4:
              case "end":
                return _context2.stop();
            }
          }
        }, _callee2);
      }))();
    },
    selectCategory: function selectCategory(e) {
      this.active.category = Number(e.detail.value);
    },
    shareToMarket: function shareToMarket() {
      var _this6 = this;

      return _asyncToGenerator2( /*#__PURE__*/_regenerator.default.mark(function _callee4() {
        var t, _yield$e$Ds$uploadFil, s, o, a;

        return _regenerator.default.wrap(function _callee4$(_context4) {
          while (1) {
            switch (_context4.prev = _context4.next) {
              case 0:
                if (!(-1 === _this6.active.category)) {
                  _context4.next = 2;
                  break;
                }

                return _context4.abrupt("return", void e.index.showToast({
                  title: "请选择转盘分类",
                  icon: "none"
                }));

              case 2:
                e.index.showLoading({
                  mask: !0
                });
                _context4.next = 5;
                return _this6.getTempFilePath();

              case 5:
                t = _context4.sent;
                _context4.next = 8;
                return e.Ds.uploadFile({
                  filePath: t,
                  cloudPath: "wheelThumbnail.png"
                });

              case 8:
                _yield$e$Ds$uploadFil = _context4.sent;
                s = _yield$e$Ds$uploadFil.fileID;
                o = _objectSpread2(_objectSpread2({}, _this6.active), {}, {
                  thumbnail: s
                });
                delete o._id, delete o.create_time;
                a = {
                  balance: _this6.score - _this6.commonSetting.shareScore,
                  comment: "分享转盘",
                  score: _this6.commonSetting.shareScore,
                  type: 2
                };

                _this6.$refs.udb.add(o, {
                  showToast: !1,
                  needLoading: !1,
                  success: function () {
                    var _success = _asyncToGenerator2( /*#__PURE__*/_regenerator.default.mark(function _callee3() {
                      return _regenerator.default.wrap(function _callee3$(_context3) {
                        while (1) {
                          switch (_context3.prev = _context3.next) {
                            case 0:
                              _context3.next = 2;
                              return i.setScore(a);

                            case 2:
                              _this6.decreScore(_this6.commonSetting.shareScore);

                              _this6.close();

                              e.index.hideLoading();
                              e.index.showToast({
                                title: "提交成功"
                              });

                            case 6:
                            case "end":
                              return _context3.stop();
                          }
                        }
                      }, _callee3);
                    }));

                    function success() {
                      return _success.apply(this, arguments);
                    }

                    return success;
                  }()
                });

              case 14:
              case "end":
                return _context4.stop();
            }
          }
        }, _callee4);
      }))();
    },
    showShare: function showShare(e) {
      this.open(), this.active = _objectSpread2({}, e), this.isShareItem = e.isShare, this.sectors = this.active.slices, this.sliceRepeat = this.active.sliceRepeat;
    },
    showMore: function showMore(t) {
      var _this7 = this;

      var s = t._id;
      e.index.showActionSheet({
        itemList: ["使用转盘", "编辑转盘", "克隆转盘", "分享转盘", "删除转盘"],
        success: function success(a) {
          var n = a.tapIndex;
          if (0 === n) _this7.toDetail(s);else if (1 === n) t.isShare ? _this7.toAddWheelPage("clone", s) : _this7.toAddWheelPage("edit", s);else if (2 === n) _this7.toAddWheelPage("clone", s);else if (3 === n) _this7.showShare(t);else if (4 === n) {
            var _a = _this7.wheels.filter(function (e) {
              return e !== s;
            });

            e.index.showModal({
              title: "提示",
              content: "确认删除转盘吗?",
              success: function () {
                var _success2 = _asyncToGenerator2( /*#__PURE__*/_regenerator.default.mark(function _callee5(n) {
                  return _regenerator.default.wrap(function _callee5$(_context5) {
                    while (1) {
                      switch (_context5.prev = _context5.next) {
                        case 0:
                          _context5.t0 = n.confirm;

                          if (!_context5.t0) {
                            _context5.next = 5;
                            break;
                          }

                          _context5.next = 4;
                          return i.removeWheel(s);

                        case 4:
                          !t.isShare || _this7.isManager && t.isShare ? (o.delete(t.thumbnail), _this7.$refs.udb.remove(s, {
                            needConfirm: !1,
                            success: function success() {
                              _this7.setWheels(_a), e.index.showToast({
                                title: "删除成功"
                              });
                            }
                          })) : (_this7.setWheels(_a), e.index.showToast({
                            title: "删除成功"
                          }));

                        case 5:
                        case "end":
                          return _context5.stop();
                      }
                    }
                  }, _callee5);
                }));

                function success(_x) {
                  return _success2.apply(this, arguments);
                }

                return success;
              }()
            });
          }
        },
        fail: function fail(e) {
          console.log(e.errMsg);
        }
      });
    },
    add: function add() {
      s.add({
        title: "转盘1",
        slices: [{
          sliceText: "选项1"
        }, {
          sliceText: "选项2"
        }]
      });
    },
    toAddWheelPage: function toAddWheelPage(t, s) {
      "add" === t ? e.index.navigateTo({
        url: "../add-wheel/add-wheel?type=add"
      }) : "edit" === t ? e.index.navigateTo({
        url: "../add-wheel/add-wheel?type=edit&id=".concat(s)
      }) : "clone" === t && e.index.navigateTo({
        url: "../add-wheel/add-wheel?type=clone&id=".concat(s)
      });
    },
    toDetail: function toDetail(t) {
      e.index.navigateTo({
        url: "../detail-wheel/detail-wheel?id=".concat(t)
      });
    }
  })
};if (!Array) {
  (e.resolveComponent("uni-popup-share") + e.resolveComponent("uni-popup") + e.resolveComponent("uni-load-more") + e.resolveComponent("unicloud-db") + e.resolveComponent("member-popup"))();
}Math || (function () {
  return "../../uni_modules/uni-popup/components/uni-popup-share/uni-popup-share.js";
} + function () {
  return "../../uni_modules/uni-popup/components/uni-popup/uni-popup.js";
} + function () {
  return "../../uni_modules/uni-load-more/components/uni-load-more/uni-load-more.js";
} + function () {
  return "../../node-modules/@dcloudio/uni-components/lib/unicloud-db/unicloud-db.js";
} + function () {
  return "../../components/member-popup/member-popup.js";
})();var h = e._export_sfc(c, [["render", function (t, s, i, o, a, n) {
  return e.e({
    a: e.o(function () {
      return n.openAdd && n.openAdd.apply(n, arguments);
    }),
    b: e.o(n.onModeSelect),
    c: e.p({
      title: "选择转盘模板"
    }),
    d: e.sr("add", "62e8adf9-0"),
    e: e.p({
      type: "share",
      safeArea: !1,
      backgroundColor: "#fff"
    }),
    f: e.w(function (_ref3, h, d) {
      var s = _ref3.data,
          i = _ref3.loading,
          o = _ref3.error,
          r = _ref3.options,
          c = _ref3.hasMore;
      return e.e({
        a: e.f(s, function (s, i, o) {
          return e.e({
            a: e.t(s.title),
            b: t.isManager && s.isShare
          }, t.isManager && s.isShare ? {
            c: e.t(-1 === s.category ? "选择分类" : a.range[s.category]),
            d: s.category,
            e: a.range,
            f: e.o(function (e) {
              return n.changeCategory(e, s._id);
            }, i),
            g: e.o(function () {}, i)
          } : {}, {
            h: t.isManager && s.isShare && s.isReview
          }, t.isManager && s.isShare && s.isReview ? {
            i: e.t(s.reviewState ? "已发布" : "已拒绝"),
            j: e.n(s.reviewState ? "operation resolve" : "operation reject")
          } : {}, {
            k: e.o(function (e) {
              return n.showMore(s);
            }, i),
            l: e.o(function (e) {
              return n.showShare(s);
            }, i),
            m: e.o(function (e) {
              return n.toAddWheelPage(s.isShare && !t.isManager ? "clone" : "edit", s._id);
            }, i),
            n: t.isManager && s.isShare && !s.isReview
          }, t.isManager && s.isShare && !s.isReview ? {
            o: e.o(function (e) {
              return n.review(s._id, !0);
            }, i)
          } : {}, {
            p: t.isManager && s.isShare && !s.isReview
          }, t.isManager && s.isShare && !s.isReview ? {
            q: e.o(function (e) {
              return n.review(s._id, !1);
            }, i)
          } : {}, {
            r: s.isShare
          }, (s.isShare, {}), {
            s: "url(".concat(s.thumbnail, ")"),
            t: (i + 3) % 4 == 3 && !t.isMember
          }, ((i + 3) % 4 != 3 || t.isMember, {}), {
            v: e.o(function (e) {
              return n.toDetail(s._id);
            }, i),
            w: i
          });
        }),
        b: 0 === s.length && a.isLoad && !i
      }, (0 === s.length && a.isLoad, {}), {
        c: 0 === s.length && !t.isMember
      }, (0 !== s.length || t.isMember, {}), {
        d: i,
        e: "62e8adf9-3-" + d + ",62e8adf9-2",
        f: d,
        g: h
      });
    }, {
      name: "d",
      path: "f",
      vueId: "62e8adf9-2"
    }),
    g: e.p({
      status: "loading"
    }),
    h: e.sr("udb", "62e8adf9-2"),
    i: e.o(n.handLoad),
    j: e.p({
      collection: "spin-list",
      where: t.where,
      loadtime: "onready",
      orderby: "create_time desc",
      getcount: !0
    }),
    k: e.t(a.active.title),
    l: a.active.thumbnail,
    m: !a.isShareItem
  }, a.isShareItem ? {} : e.e({
    n: e.t(t.commonSetting.shareScore),
    o: a.active.isShare,
    p: e.o(function (e) {
      return a.active.isShare = !a.active.isShare;
    }),
    q: e.t(-1 === a.active.category ? "选择分类" : a.range[a.active.category]),
    r: a.active.category,
    s: a.range,
    t: e.o(function () {
      return n.selectCategory && n.selectCategory.apply(n, arguments);
    }),
    v: e.o(function () {
      return n.showTermsService && n.showTermsService.apply(n, arguments);
    }),
    w: e.t(t.score),
    x: e.t(t.score < t.commonSetting.shareScore ? "，积分不足" : ""),
    y: !t.isSpinLucky
  }, t.isSpinLucky ? {
    A: e.o(function () {
      return n.watchVideo && n.watchVideo.apply(n, arguments);
    })
  } : {
    z: e.o(function (e) {
      return n.toDetail(t.commonSetting.luckyId);
    })
  }, {
    B: a.active.isShare
  }), {
    C: e.o(function () {
      return n.close && n.close.apply(n, arguments);
    }),
    D: a.active.isShare && !a.isShareItem
  }, a.active.isShare && !a.isShareItem ? {
    E: e.o(function () {
      return n.shareToMarket && n.shareToMarket.apply(n, arguments);
    }),
    F: t.score < t.commonSetting.shareScore
  } : {}, {
    G: e.sr("popup", "62e8adf9-4"),
    H: e.p({
      safeArea: !1,
      "background-color": "#fff",
      type: "bottom"
    }),
    I: e.sr("popupMember", "62e8adf9-5"),
    J: e.o(n.onSuccess),
    K: e.p({
      contentVal: a.contentVal
    })
  });
}]]);c.__runtimeHooks = 6, wx.createPage(h);