var _interopRequireDefault = require("../@babel/runtime/helpers/interopRequireDefault");var _toConsumableArray2 = require("../@babel/runtime/helpers/toConsumableArray");var _regenerator = _interopRequireDefault(require("../@babel/runtime/regenerator"));var _asyncToGenerator2 = require("../@babel/runtime/helpers/asyncToGenerator");var e = require("../common/vendor.js"),
    t = require("../store/index.js");exports.useCanvasWheel = function (l) {
  var a = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : !1;
  var o = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : !0;
  var r = Math.PI,
      u = 2 * r,
      s = e.ref(3),
      n = e.ref(0),
      v = e.ref(3);
  var i = {};
  var c = e.ref(!1);
  var f = null;
  var d = e.ref(400),
      h = e.ref(400),
      p = e.computed(function () {
    return Math.min(d.value, h.value) / 400;
  }),
      m = e.ref([]),
      x = e.ref(30),
      y = e.ref(1),
      g = e.ref([]),
      T = e.computed(function () {
    return m.value.filter(function (e) {
      return !g.value.includes(e);
    });
  }),
      M = e.ref(!1),
      w = e.computed(function () {
    return M.value ? Array(y.value).fill(m.value).flat() : Array(y.value).fill(T.value).flat();
  }),
      S = e.computed(function () {
    return w.value.length;
  }),
      P = e.computed(function () {
    return 180;
  });
  e.computed(function () {
    return u / S.value;
  });
  var A = e.computed(function () {
    var e = w.value.map(function (e) {
      return e.probability ? Number(e.probability) : 1;
    }),
        t = e.reduce(function (e, t) {
      return e + t;
    });
    var l = [];

    for (var _a = 0; _a < e.length; _a++) {
      l.push(e[_a] / t * u);
    }

    return l;
  }),
      b = e.computed(function () {
    var e = n.value + r / 2;
    e %= u;
    var t = 0;

    for (var _l = A.value.length; _l > 0; _l--) {
      if (t += A.value[_l - 1], e < t) return _l - 1;
    }
  }),
      C = e.ref(!1);
  var I = 0;

  var F = e.ref(!1),
      k = function k() {
    var e = [];

    for (var _t = 0; _t < S.value; _t++) {
      var _l2 = i.createPath2D();

      _l2.moveTo(0, 0), _l2.arc(0, 0, P.value, 0, A.value[_t]), e.push(_l2);
    }

    return e;
  },
      W = function W() {
    var e = i.createPath2D();
    return e.arc(0, 0, 33, 0, 2 * Math.PI), e.moveTo(-15, -20), e.lineTo(0, -50), e.lineTo(15, -20), e;
  },
      B = function B() {
    f.save();
    var e = W();
    f.save(), f.fillStyle = "#07C160", f.shadowColor = "#999A9F", f.shadowBlur = 10, f.fill(e), f.restore(), f.fillStyle = "#fff", f.font = "30px Arial", f.textAlign = "center", f.textBaseline = "middle", f.fillText("转", 0, 0), f.restore();
  },
      D = function D(e, t, l, a) {
    f.save(), f.beginPath();

    var o = function o(e) {
      var l = f.measureText(e).width;
      return 2 * Math.atan(l / 2 / (P.value - 20 - t));
    };

    var r = [],
        u = [],
        s = 0;

    for (var _f = 0; _f < e.length; _f++) {
      var _t2 = o(e[_f]);

      r.push(_t2), s += _t2, u.push(s);
    }

    var n = (a - s) / 2,
        v = 0,
        i = 0;

    var c = function c(t) {
      f.save(), f.translate(0, 20 - P.value), f.fillText(e[t], 0, 0), f.restore(), f.rotate(r[t]);
    };

    if (n < 0) {
      v = -1 * n, i = s + n;

      for (var _t3 = 0; _t3 < e.length; _t3++) {
        u[_t3] >= v && u[_t3] <= i + l / 2 && c(_t3);
      }
    } else {
      f.rotate(n);

      for (var _t4 = 0; _t4 < e.length; _t4++) {
        c(_t4);
      }
    }

    f.fill(), f.restore();
  },
      R = function R() {
    c.value && (f.save(), f.scale(1 / p.value, 1 / p.value), f.clearRect(-d.value / 2, -h.value / 2, d.value, h.value), f.restore(), f.save(), f.shadowColor = "#999A9F", f.shadowBlur = 20, f.fillStyle = "#ededed", f.arc(0, 0, P.value, 0, u), f.fill(), f.restore(), 0 !== S.value && (f.save(), function () {
      f.save();
      var e = k();

      for (var _t5 = 0; _t5 < S.value; _t5++) {
        f.fillStyle = w.value[_t5].backgroundColor, f.fill(e[_t5]), f.rotate(A.value[_t5]);
      }

      f.restore();
    }(), F.value ? function () {
      f.rotate(r / 2), f.save(), f.font = x.value + "px Arial", f.textAlign = "center", f.textBaseline = "top";
      var e = f.measureText("M").width,
          t = 2 * Math.atan(e / 2 / (P.value - 20 - e));
      f.rotate(t / 2);

      for (var _l3 = 0; _l3 < S.value; _l3++) {
        f.fillStyle = w.value[_l3].textColor, D(w.value[_l3].sliceText, e, t, A.value[_l3]), f.rotate(A.value[_l3]);
      }

      f.restore();
    }() : function () {
      f.save(), f.rotate(r), f.font = x.value + "px Arial", f.textBaseline = "middle";

      for (var _e = 0; _e < S.value; _e++) {
        var _t6 = w.value[_e].sliceText;
        var _l4 = f.measureText(_t6).width;
        _l4 > 150 && (_t6 = _t6.substr(0, Math.floor(150 / _l4 * _t6.length))), f.fillStyle = w.value[_e].textColor, f.rotate(A.value[_e] / 2), f.fillText(_t6, 20 - P.value, 0), f.rotate(A.value[_e] / 2);
      }

      f.restore();
    }(), f.restore()), o && B(), f.save(), f.beginPath(), f.globalAlpha = .5, f.lineWidth = 10, f.arc(0, 0, P.value - 5, 0, u), f.strokeStyle = "#FFF", f.stroke(), f.restore(), M.value && function () {
      f.save();
      var e = k();
      f.fillStyle = "#000000", f.globalAlpha = .5;

      for (var _t7 = 0; _t7 < S.value; _t7++) {
        g.value.includes(w.value[_t7]) && f.fill(e[_t7]), f.rotate(A.value[_t7]);
      }

      f.restore();
    }());
  };

  e.watch(m, R, {
    deep: !0
  }), e.watch([c, x, y, F], R);
  var q = e.ref({
    sliceText: ""
  }),
      E = e.ref(function () {}),
      N = e.ref(function () {}),
      j = e.ref(function () {});
  var z = 0,
      Q = e.ref(!1),
      H = "";
  var U = e.index.createInnerAudioContext({
    useWebAudioImplement: !0
  });
  U.src = "/static/tick.wav", "ios" === t.store.state.sysInfo.osName && (U.loop = !0, U.playbackRate = .5);
  var G = e.index.createInnerAudioContext({
    useWebAudioImplement: !0
  });
  G.src = "/static/result.wav";

  var J = function J() {
    U.stop(), U.play();
  },
      K = ["😂", "😝", "😁", "😱", "🙌", "🔥", "🐻", "🐶", "🐬", "🐟", "😍", "😉", "😓", "😳", "👽", "💀", "🐵", "🐮", "🐩", "👊", "💋", "😘", "😜", "😵", "⛄", "🎱"],
      L = function (e, t) {
    var l = !0;
    return function () {
      return !!l && (l = !1, new Promise(function (a) {
        setTimeout( /*#__PURE__*/_asyncToGenerator2( /*#__PURE__*/_regenerator.default.mark(function _callee() {
          return _regenerator.default.wrap(function _callee$(_context) {
            while (1) {
              switch (_context.prev = _context.next) {
                case 0:
                  _context.next = 2;
                  return e();

                case 2:
                  l = !0;
                  a();

                case 4:
                case "end":
                  return _context.stop();
              }
            }
          }, _callee);
        })), t);
      }));
    };
  }(function () {
    return new Promise(function (a) {
      e.index.createSelectorQuery().select("#" + l).fields({
        computedStyle: ["transform"]
      }).exec(function (e) {
        var l = e[0].transform;

        if ("none" !== l) {
          var o = l.split("(")[1].split(")")[0].split(","),
              r = o[0],
              s = o[1],
              v = Math.round(Math.atan2(s, r) * (180 / Math.PI));
          v < 0 && (v = 360 + v), n.value = u / 360 * v, b.value !== H ? (H = b.value, t.store.state.isMute || "ios" === t.store.state.sysInfo.osName || J(), q.value = w.value[H], a()) : a();
        } else a();
      });
    });
  }, 50),
      O = /*#__PURE__*/function () {
    var _ref2 = _asyncToGenerator2( /*#__PURE__*/_regenerator.default.mark(function _callee2() {
      var e, l;
      return _regenerator.default.wrap(function _callee2$(_context2) {
        while (1) {
          switch (_context2.prev = _context2.next) {
            case 0:
              _context2.next = 2;
              return L();

            case 2:
              t.store.state.isMute && !U.paused && U.stop();
              Date.now() > z || !Q.value ? (n.value = I, q.value = w.value[b.value], Q.value = !1, "" === q.value.sliceText && (q.value = {
                sliceText: K[(e = 0, l = K.length - 1, e = Math.ceil(e), l = Math.floor(l), Math.floor(Math.random() * (l - e + 1)) + e)],
                textColor: q.value.textColor
              }), t.store.state.isMute || (U.stop(), G.play(), U.stop()), N.value()) : i.requestAnimationFrame(O);

            case 4:
            case "end":
              return _context2.stop();
          }
        }
      }, _callee2);
    }));

    return function O() {
      return _ref2.apply(this, arguments);
    };
  }(),
      V = e.ref(!1),
      X = function X(e, t) {
    var l = W();
    return f.isPointInPath(l, e, t);
  },
      Y = e.ref(function () {}),
      Z = function Z(e, t) {
    f.save();
    var l = k();

    for (var _a2 = 0; _a2 < S.value; _a2++) {
      if (f.isPointInPath(l[_a2], e, t)) return f.restore(), _a2;
      f.rotate(A.value[_a2]);
    }

    return f.restore(), -1;
  };

  return e.onMounted(function () {
    e.index.createSelectorQuery().select("#" + l).fields({
      node: !0,
      size: !0
    }).exec(function (t) {
      v.value = e.index.getSystemInfoSync().pixelRatio, i = t[0].node, f = i.getContext("2d"), d.value = t[0].width, h.value = t[0].height, i.width = d.value * v.value, i.height = h.value * v.value, f.scale(v.value, v.value), f.translate(d.value / 2, h.value / 2), f.scale(p.value, p.value), c.value = !0;
    });
  }), e.onUnmounted(function () {
    Q.value = !1, U.stop();
  }), {
    startSpin: function startSpin() {
      if (Q.value || V.value) return;
      Q.value = !0;
      var e = 2 * u + s.value * u + (a = 0, o = u, Math.random() * (o - a) + a);
      var a, o;
      I = e % u;
      var r = Math.floor(360 / u * n.value),
          v = Math.floor(360 / u * e);
      j.value("#" + l, [{
        rotate: r
      }, {
        rotate: v,
        ease: "ease"
      }], 1e3 * s.value), z = Date.now() + 1e3 * s.value, O(), t.store.state.isMute || U.play(), E.value();
    },
    getTempFilePath: function getTempFilePath() {
      var t = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : !1;
      return t && B(), new Promise(function (t) {
        e.index.canvasToTempFilePath({
          canvas: i,
          destHeight: 500,
          destWidth: 500,
          success: function success(e) {
            t(e.tempFilePath);
          }
        });
      });
    },
    sectors: m,
    wheelTouchEnd: function wheelTouchEnd(_ref3) {
      var e = _ref3.changedTouches;
      var t = e[0].x * v.value,
          l = e[0].y * v.value;

      if (!X(t, l)) {
        var _e2 = Z(t, l);

        if (-1 !== _e2) {
          var _t8 = _e2 % m.value.length;

          Y.value(m.value[_t8], _t8), M.value && (g.value.includes(m.value[_t8]) ? g.value = g.value.filter(function (e) {
            return e !== m.value[_t8];
          }) : g.value = [].concat(_toConsumableArray2(g.value), [m.value[_t8]]), R());
        }
      }
    },
    onStart: E,
    onEnd: N,
    pointSector: q,
    restWheel: function restWheel() {
      n.value = 0, q.value = {
        sliceText: ""
      }, g.value = [], R();
    },
    textSize: x,
    sliceRepeat: y,
    spinTime: s,
    fairMode: C,
    pathText: F,
    onSectorClick: Y,
    disable: V,
    hideSlice: function hideSlice() {
      g.value = [].concat(_toConsumableArray2(g.value), [w.value[b.value]]), q.value = {
        sliceText: ""
      }, R();
    },
    tot: S,
    animate: j,
    hideSliceEdit: M,
    draw: R,
    spinning: Q,
    ang: n
  };
};