var o = require("../common/vendor.js");var e = null;var n = {
  showRewardVideoAd: function showRewardVideoAd(e, n, t) {
    var r = getCurrentPages(),
        s = r[r.length - 1],
        d = s[e];
    d || (d = o.wx$1.createRewardedVideoAd({
      adUnitId: e,
      multiton: !0
    }), s[e] = d), d.offError(), d.offClose(), d.onError(function (e) {
      console.error(e), o.index.showToast({
        title: "正在加载，请稍后再试",
        icon: "none"
      });
    }), d.onClose(function (o) {
      o && o.isEnded || void 0 === o ? n && n() : t && t();
    }), o.index.showToast({
      title: "获取中",
      icon: "loading",
      mask: !0
    }), d.show().catch(function () {
      d.load().then(function () {
        return d.show();
      }).catch(function (e) {
        o.index.showToast({
          title: "激励视频 广告显示失败",
          icon: "none"
        });
      });
    });
  },
  load: function load(n) {
    o.index.createInterstitialAd && ((e = o.index.createInterstitialAd({
      adUnitId: n
    })).onLoad(function () {
      console.log("插屏广告加载中");
    }), e.onError(function (o) {
      console.log("加载错误", o);
    }), e.onClose(function (o) {
      console.log("插屏广告关闭", o);
    }));
  },
  show: function show() {
    e && e.show().catch(function (o) {
      console.error(o);
    });
  }
};exports.videoAd = n;