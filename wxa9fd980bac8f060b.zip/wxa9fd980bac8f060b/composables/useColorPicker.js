var _toConsumableArray2 = require("../@babel/runtime/helpers/toConsumableArray");var _slicedToArray2 = require("../@babel/runtime/helpers/slicedToArray");var e = require("../common/vendor.js");exports.useColorPicker = function (o, t, c, a) {
  var _e$toRefs = e.toRefs(o),
      h = _e$toRefs.color,
      s = e.ref(0),
      i = e.computed(function () {
    return e.chroma.hsv(s.value, 1, 1).hex();
  }),
      r = e.ref("#fff"),
      l = function l(o) {
    return o * e.index.getSystemInfoSync().windowWidth / 750;
  },
      n = e.ref([{
    x: 0,
    y: 0,
    width: l(480),
    height: l(248)
  }, {
    x: 0,
    y: 0,
    height: l(248)
  }]),
      u = function u(o) {
    r.value = o || h.value, function () {
      var o = e.chroma(r.value).get("hsl.h");
      Number.isNaN(o) || (s.value = o);
    }(), function () {
      var _e$chroma$hsv = e.chroma(r.value).hsv(),
          _e$chroma$hsv2 = _slicedToArray2(_e$chroma$hsv, 3),
          o = _e$chroma$hsv2[1],
          t = _e$chroma$hsv2[2],
          c = n.value;

      c[0].x = parseInt(o * c[0].width), c[0].y = parseInt((1 - t) * c[0].height), c[1].y = s.value / 360 * c[1].height;
    }();
  };

  u(), e.watch(h, u);

  var f = function () {
    var o = ["#f00", "#ff0", "#4caf50", "#0ff", "#00f", "#f0f", "#ff5722"],
        t = o.map(function (o) {
      return e.chroma(o).brighten(2);
    }),
        c = o.map(function (o) {
      return e.chroma(o).darken(2);
    }),
        a = e.chroma.scale(o).colors(36),
        h = e.chroma.scale(t).colors(36),
        s = e.chroma.scale(c).colors(36);
    a.splice(-1), h.splice(-1), s.splice(-1);

    var _e$chroma$scale$color = e.chroma.scale(["eee", "333"]).colors(3),
        _e$chroma$scale$color2 = _slicedToArray2(_e$chroma$scale$color, 3),
        i = _e$chroma$scale$color2[0],
        r = _e$chroma$scale$color2[1],
        l = _e$chroma$scale$color2[2];

    return h.splice(0, 0, i), a.splice(0, 0, r), s.splice(0, 0, l), [].concat(_toConsumableArray2(h), _toConsumableArray2(a), _toConsumableArray2(s));
  }();

  return {
    init: u,
    position: n,
    bindPositionchange: function bindPositionchange(_ref, c) {
      var o = _ref.detail;
      var a = n.value,
          h = o.x,
          i = o.y;
      var l = 0,
          u = 1,
          f = 1;
      0 === c ? (a[0].x = h, a[0].y = i, l = s.value, u = h / a[0].width, f = 1 - i / a[0].height) : (a[1].y = i, l = i / a[1].height * 360, u = a[0].x / a[0].width, f = 1 - a[0].y / a[0].height, s.value = l), r.value = e.chroma.hsv(l, u, f).hex(), t.emit("change", r.value);
    },
    saturationBg: i,
    palette: f,
    displayColor: r
  };
};