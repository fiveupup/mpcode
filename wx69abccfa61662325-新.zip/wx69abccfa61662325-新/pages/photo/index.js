(wx["webpackJsonp"] = wx["webpackJsonp"] || []).push([ [ 174 ], {
    8820: function(e, a, i) {
        var n = i(2180), s = i(9439), r = i(7294), c = i(1515), l = i(2954), o = i.n(l), t = i(9572), p = i(3817), g = i(9610), m = i(4841), d = i(8340), k = "data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMjQiIGhlaWdodD0iMjQiIHZpZXdCb3g9IjAgMCAyNCAyNCIgZmlsbD0ibm9uZSIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj4KPHBhdGggZmlsbC1ydWxlPSJldmVub2RkIiBjbGlwLXJ1bGU9ImV2ZW5vZGQiIGQ9Ik0yMS4xMzAzIDE0LjE0NjlDMjIuMjg5OSAxMi45MjY4IDIyLjI4OTkgMTEuMDczMiAyMS4xMzAzIDkuODUzMUMxOS4xNzQ1IDcuNzk1MzUgMTUuODE1NSA1LjAwMDAzIDEyIDUuMDAwMDNDOC4xODQ0OCA1LjAwMDAzIDQuODI1NDkgNy43OTUzNSAyLjg2OTcxIDkuODUzMUMxLjcxMDEgMTEuMDczMiAxLjcxMDEgMTIuOTI2OCAyLjg2OTcxIDE0LjE0NjlDNC44MjU0OSAxNi4yMDQ2IDguMTg0NDggMTguOTk5OSAxMiAxOC45OTk5QzE1LjgxNTUgMTguOTk5OSAxOS4xNzQ1IDE2LjIwNDYgMjEuMTMwMyAxNC4xNDY5Wk0xMiAxNUMxMy42NTY5IDE1IDE1IDEzLjY1NjggMTUgMTJDMTUgMTAuMzQzMSAxMy42NTY5IDkuMDAwMDEgMTIgOS4wMDAwMUMxMC4zNDMxIDkuMDAwMDEgOSAxMC4zNDMxIDkgMTJDOSAxMy42NTY4IDEwLjM0MzEgMTUgMTIgMTVaIiBmaWxsPSIjMUMxRDIwIiBzdHlsZT0iZmlsbDojMUMxRDIwO2ZpbGw6Y29sb3IoZGlzcGxheS1wMyAwLjEwOTggMC4xMTM3IDAuMTI1NSk7ZmlsbC1vcGFjaXR5OjE7Ii8+Cjwvc3ZnPgo=", u = i.p + "images/icon-refresh.svg", _ = i(8869), h = i(8262), M = i(2939), w = i(7989), x = i(4810), v = i(2360), j = i(7584), I = i(5271), D = i(3165), N = i(2602), A = i(966), b = i(1174), f = i(3079), T = i(885), S = i(7264), z = i(1175), O = i(8708), y = i.p + "images/china/sticker_china_16.png", E = i.p + "images/china/sticker_china_17.png", C = i.p + "images/china/sticker_china_18.png", G = i.p + "images/panda/sticker_panda_01.png", Z = i.p + "images/panda/sticker_panda_02.png", L = i.p + "images/panda/sticker_panda_03.png", U = i.p + "images/panda/sticker_panda_04.png", P = i.p + "images/panda/sticker_panda_05.png", Q = i.p + "images/panda/sticker_panda_06.png", B = i.p + "images/panda/sticker_panda_07.png", Y = i.p + "images/panda/sticker_panda_08.png", J = i.p + "images/panda/sticker_panda_09.png", W = i.p + "images/panda/sticker_panda_10.png", F = i.p + "images/panda/sticker_panda_11.png", R = i.p + "images/panda/sticker_panda_12.png", V = i.p + "images/panda/sticker_panda_13.png", X = i.p + "images/worker/sticker_worker_01.png", H = i.p + "images/worker/sticker_worker_02.png", K = i.p + "images/worker/sticker_worker_03.png", q = i.p + "images/worker/sticker_worker_04.png", $ = i.p + "images/worker/sticker_worker_05.png", ee = i.p + "images/worker/sticker_worker_06.png", ae = i.p + "images/worker/sticker_worker_07.png", ie = i.p + "images/worker/sticker_worker_08.png", ne = i.p + "images/worker/sticker_worker_09.png", se = i.p + "images/worker/sticker_worker_10.png", re = i.p + "images/worker/sticker_worker_11.png", ce = i.p + "images/worker/sticker_worker_12.png", le = i.p + "images/worker/sticker_worker_13.png", oe = i.p + "images/worker/sticker_worker_14.png", te = i.p + "images/worker/sticker_worker_15.png", pe = i.p + "images/worker/sticker_worker_16.png", ge = i.p + "images/worker/sticker_worker_17.png", me = i.p + "images/animal/sticker_animal_01.png", de = i.p + "images/animal/sticker_animal_02.png", ke = i.p + "images/animal/sticker_animal_03.png", ue = i.p + "images/animal/sticker_animal_04.png", _e = i.p + "images/animal/sticker_animal_05.png", he = i.p + "images/animal/sticker_animal_06.png", Me = i.p + "images/animal/sticker_animal_07.png", we = i.p + "images/animal/sticker_animal_08.png", xe = i.p + "images/animal/sticker_animal_09.png", ve = i.p + "images/animal/sticker_animal_10.png", je = i.p + "images/animal/sticker_animal_11.png", Ie = i.p + "images/animal/sticker_animal_12.png", De = i.p + "images/animal/sticker_animal_13.png", Ne = i.p + "images/animal/sticker_animal_14.png", Ae = i.p + "images/animal/sticker_animal_15.png", be = i.p + "images/animal/sticker_animal_16.png", fe = i.p + "images/animal/sticker_animal_17.png", Te = i.p + "images/animal/sticker_animal_18.png", Se = i.p + "images/animal/sticker_animal_19.png", ze = i(5893), Oe = [ {
            label: "热门",
            children: [ M, w, G, Z, L, x, v, j, h, xe, ve, je, Ie ]
        }, {
            label: "中华",
            children: [ M, w, x, v, j, I, D, N, A, b, f, T, S, z, O, y, E, C ]
        }, {
            label: "熊猫",
            children: [ G, Z, L, U, P, Q, B, Y, J, W, F, R, V ]
        }, {
            label: "打工人",
            children: [ X, H, K, q, $, ee, ae, ie, ne, se, re, ce, le, oe, te, pe, ge ]
        }, {
            label: "动物园",
            children: [ me, de, ke, ue, _e, he, Me, we, xe, ve, je, Ie, De, Ne, Ae, be, fe, Te, Se ]
        } ], ye = "canvas", Ee = function(e) {
            var a, i, n, h = (0, r.useState)(""), M = (0, s.Z)(h, 2), w = M[0], x = M[1], v = (0, 
            r.useState)(""), j = (0, s.Z)(v, 2), I = j[0], D = j[1], N = (0, r.useState)(0), A = (0, 
            s.Z)(N, 2), b = A[0], f = A[1], T = (0, r.useState)(-1), S = (0, s.Z)(T, 2), z = S[0], O = S[1], y = (0, 
            r.useState)(""), E = (0, s.Z)(y, 2), C = E[0], G = E[1], Z = (0, r.useState)(!1), L = (0, 
            s.Z)(Z, 2), U = L[0], P = L[1], Q = (0, g.W)(w), B = (0, r.useState)(0), Y = (0, 
            s.Z)(B, 2), J = (Y[0], Y[1], (0, l.useRouter)()), W = function() {
                return {
                    title: "给头像换新颖",
                    path: "/pages/photo/index",
                    imageUrl: "https://zm-1253465948.cos.ap-nanjing.myqcloud.com/static/photo/share_common.png"
                };
            };
            return (0, l.useShareAppMessage)(W), (0, l.useShareTimeline)(W), (0, l.useLoad)(function() {
                var e, a;
                null !== J && void 0 !== J && null !== (e = J.params) && void 0 !== e && e.imagePath && o().downloadFile({
                    url: null === J || void 0 === J || null === (a = J.params) || void 0 === a ? void 0 : a.imagePath,
                    success: function(e) {
                        (0, p.KF)(null === e || void 0 === e ? void 0 : e.tempFilePath, function(a) {
                            D((null === e || void 0 === e ? void 0 : e.tempFilePath) || ""), x("data:image/png;base64," + a);
                        });
                    },
                    fail: function(e) {
                        console.log(e);
                    }
                });
            }), (0, ze.jsxs)(c.G7, {
                className: "wrapper",
                children: [ (0, ze.jsx)("privacy-popup", {}), (0, ze.jsx)(t.Z, {
                    showBackBtn: !0,
                    title: "头像挂件"
                }), (0, ze.jsxs)(c.G7, {
                    className: "photo-top",
                    children: [ (0, ze.jsx)(c.G7, {
                        className: "photo-compose-container",
                        children: w ? (0, ze.jsxs)(c.G7, {
                            style: {
                                background: "url(".concat(w, ") no-repeat center"),
                                backgroundSize: "100%"
                            },
                            className: "user-view",
                            children: [ (null === (a = Oe[b]) || void 0 === a || null === (a = a.children) || void 0 === a ? void 0 : a[z]) && (0, 
                            ze.jsx)(c.Ee, {
                                src: null === (i = Oe[b]) || void 0 === i || null === (i = i.children) || void 0 === i ? void 0 : i[z],
                                style: {
                                    width: "100%",
                                    height: "100%"
                                }
                            }), (0, ze.jsx)(c.Xz, {
                                id: "canvas",
                                canvasId: ye
                            }) ]
                        }) : (0, ze.jsxs)(c.G7, {
                            children: [ (0, ze.jsx)(c.zx, {
                                className: "avatar-wrapper select-btn",
                                "open-type": "chooseAvatar",
                                onChooseAvatar: function(e) {
                                    var a = e.detail.avatarUrl;
                                    (0, p.KF)(a, function(e) {
                                        D(a), x("data:image/png;base64," + e);
                                    });
                                },
                                children: "使用微信头像"
                            }), (0, ze.jsxs)(c.zx, {
                                className: "select-btn local-album",
                                onClick: function() {
                                    (0, p.l7)(function(e, a) {
                                        D(e), x("data:image/png;base64," + a);
                                    });
                                },
                                children: [ "本地相册上传 ", (0, ze.jsx)(c.G7, {
                                    className: "recommend",
                                    children: "推荐"
                                }) ]
                            }), (0, ze.jsx)(c.xv, {
                                children: " 本地上传图片更清晰"
                            }) ]
                        })
                    }), (0, ze.jsxs)(c.G7, {
                        className: I ? "preview" : "preview dd-disable",
                        children: [ (0, ze.jsxs)(c.G7, {
                            onClick: function() {
                                var e;
                                (0, p.s1)({
                                    canvasInfo: Q,
                                    canvasId: ye,
                                    bgImg: I,
                                    coverImg: null === (e = Oe[b]) || void 0 === e || null === (e = e.children) || void 0 === e ? void 0 : e[z],
                                    cb: function(e) {
                                        G(e), P(!0);
                                    },
                                    showGarden: !0
                                });
                            },
                            children: [ (0, ze.jsx)(c.Ee, {
                                src: k
                            }), " 查看预览" ]
                        }), (0, ze.jsxs)(c.G7, {
                            onClick: function() {
                                var e = o().createCanvasContext("canvas");
                                x(""), O(-1), f(0), D(""), e.restore();
                            },
                            children: [ (0, ze.jsx)(c.Ee, {
                                src: u
                            }), "重新上传" ]
                        }) ]
                    }) ]
                }), (0, ze.jsxs)(c.G7, {
                    className: "photo-bottom",
                    children: [ (0, ze.jsx)(c.pf, {
                        className: "themes-scrollview",
                        scrollX: !0,
                        style: {
                            whiteSpace: "nowrap"
                        },
                        scrollIntoViewAlignment: "nearest",
                        children: Oe.map(function(e, a) {
                            return (0, ze.jsx)(c.G7, {
                                className: b === a ? "active scroll-item" : "scroll-item",
                                style: {
                                    marginLeft: 0 === a ? "20px" : 0
                                },
                                onClick: function() {
                                    a !== b && (f(a), O(-1), o().createSelectorQuery().select(".photo-scrollview").node().exec(function(e) {
                                        var a;
                                        null === (a = e[0]) || void 0 === a || null === (a = a.node) || void 0 === a || a.scrollTo({
                                            left: 0
                                        });
                                    }));
                                },
                                children: e.label
                            }, a);
                        })
                    }), (0, ze.jsx)(c.pf, {
                        className: "photo-scrollview",
                        scrollX: !0,
                        style: {
                            whiteSpace: "nowrap"
                        },
                        scrollIntoViewAlignment: "nearest",
                        enhanced: !0,
                        children: null === (n = Oe[b]) || void 0 === n ? void 0 : n.children.map(function(e, a) {
                            return (0, ze.jsx)(c.G7, {
                                className: z === a ? "scroll-item active" : "scroll-item",
                                style: {
                                    marginLeft: 0 === a ? "20px" : 0
                                },
                                onClick: function() {
                                    if (!I) return o().showToast({
                                        title: "请先设置图像",
                                        icon: "error"
                                    });
                                    O(z !== a ? a : -1);
                                },
                                children: (0, ze.jsx)(c.Ee, {
                                    src: e,
                                    style: {
                                        width: "100%",
                                        height: "100%"
                                    }
                                })
                            }, a);
                        })
                    }), (0, ze.jsxs)(c.G7, {
                        className: "photo-operation",
                        children: [ (0, ze.jsxs)(c.G7, {
                            className: "create-img",
                            onClick: function() {
                                var e, a;
                                return I ? null !== (e = Oe[b]) && void 0 !== e && null !== (e = e.children) && void 0 !== e && e[z] ? void (0, 
                                p.s1)({
                                    canvasInfo: Q,
                                    canvasId: ye,
                                    bgImg: I,
                                    coverImg: null === (a = Oe[b]) || void 0 === a || null === (a = a.children) || void 0 === a ? void 0 : a[z],
                                    cb: function(e) {
                                        o().getSetting({
                                            success: function(a) {
                                                a.authSetting["scope.writePhotosAlbum"] ? (0, p.DB)(e) : o().authorize({
                                                    scope: "scope.writePhotosAlbum",
                                                    success: function() {
                                                        (0, p.DB)(e);
                                                    }
                                                });
                                            },
                                            fail: function(e) {
                                                console.log(e);
                                            }
                                        });
                                    }
                                }) : o().showToast({
                                    title: "请先设置挂件",
                                    icon: "error"
                                }) : o().showToast({
                                    title: "请先设置图像",
                                    icon: "error"
                                });
                            },
                            children: [ (0, ze.jsx)(c.Ee, {
                                src: d
                            }), " 保存至相册" ]
                        }), (0, ze.jsx)(c.zx, {
                            "open-type": "share",
                            className: "share",
                            children: (0, ze.jsx)(c.Ee, {
                                src: _
                            })
                        }) ]
                    }) ]
                }), (0, ze.jsx)(m.Z, {
                    showModal: U,
                    setShowModal: P,
                    preViewImg: C
                }) ]
            });
        }, Ce = Ee, Ge = {
            enableShareAppMessage: !0
        };
        Ce.enableShareTimeline = !0, Ce.enableShareAppMessage = !0;
        Page((0, n.createPageConfig)(Ce, "pages/photo/index", {
            root: {
                cn: []
            }
        }, Ge || {}));
    }
}, function(e) {
    var a = function(a) {
        return e(e.s = a);
    };
    e.O(0, [ 107, 216, 592 ], function() {
        return a(8820);
    });
    e.O();
} ]);