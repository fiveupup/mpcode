(wx["webpackJsonp"] = wx["webpackJsonp"] || []).push([ [ 911 ], {
    5493: function(e, s, n) {
        var a = n(2180), i = n(1515), M = n(2954), c = n.n(M), g = n(9572), o = n.p + "images/icon-folder.svg", l = n.p + "images/icon-pizza.svg", r = "data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMjQiIGhlaWdodD0iMjQiIHZpZXdCb3g9IjAgMCAyNCAyNCIgZmlsbD0ibm9uZSIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj4KPHBhdGggZmlsbC1ydWxlPSJldmVub2RkIiBjbGlwLXJ1bGU9ImV2ZW5vZGQiIGQ9Ik05LjA1OTMgNC4xNzY4NkM5LjUxMzkgMy42NTczMSAxMC4zMDM2IDMuNjA0NjYgMTAuODIzMSA0LjA1OTI3TDE4LjgyMzEgMTEuMDU5M0MxOS4wOTQ0IDExLjI5NjYgMTkuMjUgMTEuNjM5NSAxOS4yNSAxMkMxOS4yNSAxMi4zNjA0IDE5LjA5NDQgMTIuNzAzMyAxOC44MjMxIDEyLjk0MDdMMTAuODIzMSAxOS45NDA3QzEwLjMwMzYgMjAuMzk1MyA5LjUxMzkgMjAuMzQyNyA5LjA1OTMgMTkuODIzMUM4LjYwNDY5IDE5LjMwMzYgOC42NTczNCAxOC41MTM5IDkuMTc2ODkgMTguMDU5M0wxNi4xMDE4IDEyTDkuMTc2ODkgNS45NDA3MUM4LjY1NzM0IDUuNDg2MSA4LjYwNDY5IDQuNjk2NCA5LjA1OTMgNC4xNzY4NloiIGZpbGw9ImJsYWNrIiBzdHlsZT0iZmlsbDpibGFjaztmaWxsOmJsYWNrO2ZpbGwtb3BhY2l0eToxOyIvPgo8L3N2Zz4K", j = n.p + "images/icon-dingdongTool.png", t = n.p + "images/icon-linkOpen.svg", x = n(5893), p = function() {
            var e = function() {
                return {
                    title: "给头像换新颖",
                    path: "/pages/personal/index",
                    imageUrl: "https://zm-1253465948.cos.ap-nanjing.myqcloud.com/static/photo/share_common.png"
                };
            };
            return (0, M.useShareAppMessage)(e), (0, M.useShareTimeline)(e), (0, x.jsxs)(i.G7, {
                className: "wrapper",
                children: [ (0, x.jsx)(g.Z, {
                    title: "个人中心"
                }), (0, x.jsxs)(i.G7, {
                    className: "components-warper",
                    children: [ (0, x.jsxs)(i.G7, {
                        className: "collect",
                        onClick: function() {
                            c().navigateTo({
                                url: "/pages/collect/index"
                            });
                        },
                        children: [ (0, x.jsx)(i.Ee, {
                            src: o
                        }), "收藏夹" ]
                    }), (0, x.jsxs)(i.G7, {
                        className: "collect",
                        onClick: function() {
                            c().navigateTo({
                                url: "/pages/activity/index"
                            });
                        },
                        children: [ (0, x.jsx)(i.Ee, {
                            src: l
                        }), "活动页" ]
                    }), (0, x.jsxs)(i.G7, {
                        className: "personal-info",
                        children: [ (0, x.jsxs)(i.G7, {
                            onClick: function() {
                                c().navigateTo({
                                    url: "/pages/about/index"
                                });
                            },
                            children: [ "关于", (0, x.jsx)(i.Ee, {
                                src: r
                            }) ]
                        }), (0, x.jsxs)(i.G7, {
                            onClick: function() {
                                c().navigateToMiniProgram({
                                    appId: "wxcda8f0f389481b34",
                                    path: "pages/index/index",
                                    success: function(e) {}
                                });
                            },
                            children: [ " ", (0, x.jsxs)(i.G7, {
                                className: "dd-tips",
                                children: [ " ", (0, x.jsx)(i.Ee, {
                                    src: j
                                }), "叮咚决策器" ]
                            }), " ", (0, x.jsx)(i.Ee, {
                                src: t
                            }) ]
                        }) ]
                    }) ]
                }) ]
            });
        }, u = p, N = {
            enableShareAppMessage: !0
        };
        u.enableShareTimeline = !0, u.enableShareAppMessage = !0;
        Page((0, a.createPageConfig)(u, "pages/personal/index", {
            root: {
                cn: []
            }
        }, N || {}));
    }
}, function(e) {
    var s = function(s) {
        return e(e.s = s);
    };
    e.O(0, [ 107, 216, 592 ], function() {
        return s(5493);
    });
    e.O();
} ]);