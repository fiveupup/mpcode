(wx["webpackJsonp"] = wx["webpackJsonp"] || []).push([ [ 495 ], {
    6434: function(e, n, a) {
        var t = a(2180), i = a(9439), o = a(1515), r = a(2954), s = a.n(r), p = a(7294), c = a(9572), u = a(1301), l = a(5893);
        function g() {
            var e = (0, p.useState)(""), n = (0, i.Z)(e, 2), a = n[0], t = n[1], g = (0, p.useState)([]), h = (0, 
            i.Z)(g, 2), d = h[0], v = h[1];
            (0, r.useLoad)(function() {
                var e = s().getCurrentPages(), n = e[e.length - 1], a = n.getOpenerEventChannel();
                a.on("sendPicLibInfo", function(e) {
                    t(null === e || void 0 === e ? void 0 : e.title), v(null === e || void 0 === e ? void 0 : e.data);
                });
            });
            var f = function() {
                return {
                    title: "给头像换新颖",
                    path: "/pages/picloader/index",
                    imageUrl: "https://zm-1253465948.cos.ap-nanjing.myqcloud.com/static/photo/share_common.png"
                };
            };
            return (0, r.useShareAppMessage)(f), (0, r.useShareTimeline)(f), (0, l.jsxs)(o.G7, {
                className: "wrapper",
                children: [ (0, l.jsx)("privacy-popup", {}), (0, l.jsx)(c.Z, {
                    title: a,
                    showBackBtn: !0
                }), (0, l.jsx)(u.Z, {
                    photoList: d
                }) ]
            });
        }
        var h = {
            navigationBarTitleText: "首页"
        };
        g.enableShareTimeline = !0, g.enableShareAppMessage = !0;
        Page((0, t.createPageConfig)(g, "pages/picloader/index", {
            root: {
                cn: []
            }
        }, h || {}));
    }
}, function(e) {
    var n = function(n) {
        return e(e.s = n);
    };
    e.O(0, [ 107, 216, 592 ], function() {
        return n(6434);
    });
    e.O();
} ]);