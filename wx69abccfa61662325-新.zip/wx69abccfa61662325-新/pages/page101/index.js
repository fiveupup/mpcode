(wx["webpackJsonp"] = wx["webpackJsonp"] || []).push([ [ 501 ], {
    1355: function(e, s, a) {
        var n = a(2180), t = a(9439), c = a(7294), i = a(1515), o = a(2954), r = a.n(o), l = a(9572), g = a(3817), M = a(9610), p = a(4841), x = "data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMjQiIGhlaWdodD0iMjQiIHZpZXdCb3g9IjAgMCAyNCAyNCIgZmlsbD0ibm9uZSIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj4KPHBhdGggZmlsbC1ydWxlPSJldmVub2RkIiBjbGlwLXJ1bGU9ImV2ZW5vZGQiIGQ9Ik0yMS4xMzAzIDE0LjE0NjlDMjIuMjg5OSAxMi45MjY4IDIyLjI4OTkgMTEuMDczMiAyMS4xMzAzIDkuODUzMUMxOS4xNzQ1IDcuNzk1MzUgMTUuODE1NSA1LjAwMDAzIDEyIDUuMDAwMDNDOC4xODQ0OCA1LjAwMDAzIDQuODI1NDkgNy43OTUzNSAyLjg2OTcxIDkuODUzMUMxLjcxMDEgMTEuMDczMiAxLjcxMDEgMTIuOTI2OCAyLjg2OTcxIDE0LjE0NjlDNC44MjU0OSAxNi4yMDQ2IDguMTg0NDggMTguOTk5OSAxMiAxOC45OTk5QzE1LjgxNTUgMTguOTk5OSAxOS4xNzQ1IDE2LjIwNDYgMjEuMTMwMyAxNC4xNDY5Wk0xMiAxNUMxMy42NTY5IDE1IDE1IDEzLjY1NjggMTUgMTJDMTUgMTAuMzQzMSAxMy42NTY5IDkuMDAwMDEgMTIgOS4wMDAwMUMxMC4zNDMxIDkuMDAwMDEgOSAxMC4zNDMxIDkgMTJDOSAxMy42NTY4IDEwLjM0MzEgMTUgMTIgMTVaIiBmaWxsPSIjZmZmIiBzdHlsZT0iZmlsbDojZmZmO2ZpbGwtb3BhY2l0eToxOyIvPgo8L3N2Zz4K", u = a.p + "images/icon-refresh_white.svg", m = a.p + "images/101/sticker_nd_01.png", h = a.p + "images/101/sticker_nd_02.png", d = a.p + "images/101/sticker_nd_03.png", j = a(8262), D = a.p + "images/101/sticker_nd_05.png", I = a.p + "images/101/sticker_nd_06.png", N = a.p + "images/101/sticker_nd_07.png", A = a(2939), w = a(7989), T = a(4810), v = a(2360), b = a(7584), z = a(5271), S = a(3165), k = a(2602), O = a(966), f = a(1174), y = a(3079), E = a(885), Z = a(7264), G = a(1175), C = a(8708), L = a.p + "pages/page101/imgs/selector-mask.png", U = a(8340), _ = a(8869), Q = a.p + "images/101/title_nd.png", B = a(5893), P = [ m, h, d, j, D, I, N, A, w, T, v, b, z, S, k, O, f, y, E, Z, G, C, L ], Y = "canvas", J = function() {
            var e = (0, c.useState)(""), s = (0, t.Z)(e, 2), a = s[0], n = s[1], m = (0, c.useState)(""), h = (0, 
            t.Z)(m, 2), d = h[0], j = h[1], D = (0, c.useState)(-1), I = (0, t.Z)(D, 2), N = I[0], A = I[1], w = (0, 
            c.useState)(!1), T = (0, t.Z)(w, 2), v = T[0], b = T[1], z = (0, c.useState)(""), S = (0, 
            t.Z)(z, 2), k = S[0], O = S[1], f = (0, M.W)(a), y = function(e) {
                return "button" === e.from && console.log(e.target), {
                    title: "欢度国庆，给头像换新颖",
                    path: "/pages/page101/index",
                    imageUrl: "https://zm-1253465948.cos.ap-nanjing.myqcloud.com/static/photo/share_101_large.png"
                };
            };
            return (0, o.useShareAppMessage)(y), (0, o.useShareTimeline)(y), (0, B.jsxs)(i.G7, {
                className: "wrapper",
                children: [ (0, B.jsx)("privacy-popup", {}), (0, B.jsx)(l.Z, {
                    showBackBtn: !0,
                    title: "叮咚头像生成器",
                    customHeader: !0
                }), (0, B.jsxs)(i.G7, {
                    className: "photo-top",
                    children: [ (0, B.jsx)(i.G7, {
                        className: "title",
                        children: (0, B.jsx)(i.Ee, {
                            src: Q
                        })
                    }), (0, B.jsx)(i.G7, {
                        className: "photo-compose-container",
                        children: a ? (0, B.jsxs)(i.G7, {
                            style: {
                                background: "url(".concat(a, ") no-repeat center"),
                                backgroundSize: "100%"
                            },
                            className: "user-view",
                            children: [ P[N] && (0, B.jsx)(i.Ee, {
                                src: P[N],
                                style: {
                                    width: "100%",
                                    height: "100%"
                                }
                            }), (0, B.jsx)(i.Xz, {
                                id: "canvas",
                                canvasId: "canvas"
                            }) ]
                        }) : (0, B.jsxs)(i.G7, {
                            children: [ (0, B.jsx)(i.zx, {
                                className: "avatar-wrapper select-btn",
                                "open-type": "chooseAvatar",
                                onChooseAvatar: function(e) {
                                    var s = e.detail.avatarUrl;
                                    (0, g.KF)(s, function(e) {
                                        j(s), n("data:image/png;base64," + e);
                                    });
                                },
                                children: "使用微信头像"
                            }), (0, B.jsxs)(i.zx, {
                                className: "select-btn local-album",
                                onClick: function() {
                                    (0, g.l7)(function(e, s) {
                                        j(e), n("data:image/png;base64," + s);
                                    });
                                },
                                children: [ "本地相册上传 ", (0, B.jsx)(i.G7, {
                                    className: "recommend",
                                    children: "推荐"
                                }) ]
                            }), (0, B.jsx)(i.xv, {
                                children: " 本地上传图片更清晰"
                            }) ]
                        })
                    }), (0, B.jsxs)(i.G7, {
                        className: d ? "preview" : "preview dd-disable",
                        children: [ (0, B.jsxs)(i.G7, {
                            onClick: function() {
                                (0, g.s1)({
                                    canvasInfo: f,
                                    canvasId: Y,
                                    bgImg: d,
                                    coverImg: P[N],
                                    cb: function(e) {
                                        O(e), b(!0);
                                    },
                                    showGarden: !0
                                });
                            },
                            children: [ (0, B.jsx)(i.Ee, {
                                src: x
                            }), " 查看预览" ]
                        }), (0, B.jsxs)(i.G7, {
                            onClick: function() {
                                var e = r().createCanvasContext("canvas");
                                n(""), A(-1), j(""), e.restore();
                            },
                            children: [ (0, B.jsx)(i.Ee, {
                                src: u
                            }), "重新上传" ]
                        }) ]
                    }) ]
                }), (0, B.jsxs)(i.G7, {
                    className: "photo-bottom",
                    children: [ (0, B.jsx)(i.pf, {
                        className: "photo-scrollview",
                        scrollX: !0,
                        style: {
                            whiteSpace: "nowrap"
                        },
                        scrollIntoViewAlignment: "nearest",
                        children: P.map(function(e, s) {
                            return (0, B.jsx)(i.G7, {
                                className: N === s ? "scroll-item active" : "scroll-item",
                                style: {
                                    marginLeft: 0 === s ? "20px" : 0
                                },
                                onClick: function() {
                                    return s === P.length - 1 ? r().navigateTo({
                                        url: "../photo/index"
                                    }) : d ? void A(N !== s ? s : -1) : r().showToast({
                                        title: "请先设置图像",
                                        icon: "error"
                                    });
                                },
                                children: (0, B.jsx)(i.Ee, {
                                    src: e,
                                    style: {
                                        width: "100%",
                                        height: "100%"
                                    }
                                })
                            }, s);
                        })
                    }), (0, B.jsxs)(i.G7, {
                        className: "photo-operation",
                        children: [ (0, B.jsxs)(i.G7, {
                            className: "create-img",
                            onClick: function() {
                                return d ? P[N] ? void (0, g.s1)({
                                    canvasInfo: f,
                                    canvasId: Y,
                                    bgImg: d,
                                    coverImg: P[N],
                                    cb: function(e) {
                                        r().getSetting({
                                            success: function(s) {
                                                s.authSetting["scope.writePhotosAlbum"] ? (0, g.DB)(e) : r().authorize({
                                                    scope: "scope.writePhotosAlbum",
                                                    success: function() {
                                                        (0, g.DB)(e);
                                                    }
                                                });
                                            },
                                            fail: function(e) {
                                                console.log(e);
                                            }
                                        });
                                    }
                                }) : r().showToast({
                                    title: "请先设置挂件",
                                    icon: "error"
                                }) : r().showToast({
                                    title: "请先设置图像",
                                    icon: "error"
                                });
                            },
                            children: [ (0, B.jsx)(i.Ee, {
                                src: U
                            }), " 保存至相册" ]
                        }), (0, B.jsx)(i.zx, {
                            "open-type": "share",
                            className: "share",
                            children: (0, B.jsx)(i.Ee, {
                                src: _
                            })
                        }) ]
                    }) ]
                }), (0, B.jsx)(p.Z, {
                    showModal: v,
                    setShowModal: b,
                    preViewImg: k
                }) ]
            });
        }, W = J, H = {
            enableShareAppMessage: !0
        };
        W.enableShareTimeline = !0, W.enableShareAppMessage = !0;
        Page((0, n.createPageConfig)(W, "pages/page101/index", {
            root: {
                cn: []
            }
        }, H || {}));
    }
}, function(e) {
    var s = function(s) {
        return e(e.s = s);
    };
    e.O(0, [ 107, 216, 592 ], function() {
        return s(1355);
    });
    e.O();
} ]);