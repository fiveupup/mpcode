(wx["webpackJsonp"] = wx["webpackJsonp"] || []).push([ [ 753 ], {
    2867: function(e, i, g) {
        var c = g(2180), n = g(9439), t = g(7294), a = g(2954), s = g.n(a), o = g(1515), M = "data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMjQiIGhlaWdodD0iMjQiIHZpZXdCb3g9IjAgMCAyNCAyNCIgZmlsbD0ibm9uZSIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj4KPHBhdGggZmlsbC1ydWxlPSJldmVub2RkIiBjbGlwLXJ1bGU9ImV2ZW5vZGQiIGQ9Ik0yMiAxMkMyMiAxNy41MjI4IDE3LjUyMjggMjIgMTIgMjJDNi40NzcxNSAyMiAyIDE3LjUyMjggMiAxMkMyIDYuNDc3MTUgNi40NzcxNSAyIDEyIDJDMTcuNTIyOCAyIDIyIDYuNDc3MTUgMjIgMTJaTTEzIDdDMTMgNy41NTIyOCAxMi41NTIzIDggMTIgOEMxMS40NDc3IDggMTEgNy41NTIyOCAxMSA3QzExIDYuNDQ3NzIgMTEuNDQ3NyA2IDEyIDZDMTIuNTUyMyA2IDEzIDYuNDQ3NzIgMTMgN1pNMTEgOS4yNUMxMC41ODU4IDkuMjUgMTAuMjUgOS41ODU3OSAxMC4yNSAxMEMxMC4yNSAxMC40MTQyIDEwLjU4NTggMTAuNzUgMTEgMTAuNzVIMTEuMjVWMTdDMTEuMjUgMTcuNDE0MiAxMS41ODU4IDE3Ljc1IDEyIDE3Ljc1QzEyLjQxNDIgMTcuNzUgMTIuNzUgMTcuNDE0MiAxMi43NSAxN1YxMEMxMi43NSA5LjU4NTc5IDEyLjQxNDIgOS4yNSAxMiA5LjI1SDExWiIgZmlsbD0iIzFDMUQyMCIgc3R5bGU9ImZpbGw6IzFDMUQyMDtmaWxsOmNvbG9yKGRpc3BsYXktcDMgMC4xMDk4IDAuMTEzNyAwLjEyNTUpO2ZpbGwtb3BhY2l0eToxOyIvPgo8L3N2Zz4K", l = g(9572), r = g.p + "images/cover/cover-cat.png", p = g.p + "images/cover/cover-cp.png", u = g.p + "images/cover/cover-crazy.png", m = g.p + "images/cover/cover-dog.png", I = g.p + "images/cover/cover-intimidating.png", N = g.p + "images/cover/cover-lucky.png", y = g.p + "images/cover/cover-mature.png", D = g.p + "images/cover/cover-panda.png", d = g.p + "images/cover/cover-qq.png", v = g.p + "images/cover/cover-y2k.png", x = g.p + "images/cover/cover-hungry.png", T = g.p + "pages/piclib/imgs/dogs.png", j = g(5893), A = {
            dog: {
                title: "修狗狗",
                img: m
            },
            cat: {
                title: "猫猫头",
                img: r
            },
            cp: {
                title: "CP头像",
                img: p
            },
            panda: {
                title: "圆滚滚熊猫",
                img: D
            },
            lineDog: {
                title: "线条小狗",
                img: T
            },
            hungry: {
                title: "好饿啊",
                img: x
            },
            crazy: {
                title: "人哪有不疯的",
                img: u
            },
            intimidating: {
                title: "看起来不好惹",
                img: I
            },
            y2k: {
                title: "千禧年",
                img: v
            },
            lucky: {
                title: "时来运转",
                img: N
            },
            mature: {
                title: "成熟人士专用",
                img: y
            },
            qq: {
                title: "QQ怀旧头像",
                img: d
            }
        }, h = function() {
            var e, i = (0, t.useState)({}), g = (0, n.Z)(i, 2), c = g[0], r = g[1];
            (0, t.useEffect)(function() {
                console.log("开始发送请求"), s().request({
                    url: "https://ziming.online/ddphoto/getPics",
                    success: function(e) {
                        var i = e.data;
                        r(null === i || void 0 === i ? void 0 : i.themesMap);
                    },
                    fail: function(e) {
                        console.log(e);
                    }
                });
            }, []);
            var p = function() {
                return {
                    title: "给头像换新颖",
                    path: "/pages/piclib/index",
                    imageUrl: "https://zm-1253465948.cos.ap-nanjing.myqcloud.com/static/photo/share_common.png"
                };
            };
            return (0, a.useShareAppMessage)(p), (0, a.useShareTimeline)(p), (0, j.jsxs)(o.G7, {
                className: "wrapper",
                children: [ (0, j.jsx)(l.Z, {
                    title: "头像库"
                }), (0, j.jsxs)(o.G7, {
                    className: "components-warper",
                    children: [ (0, j.jsxs)(o.G7, {
                        className: "user-tips",
                        children: [ (0, j.jsx)(o.Ee, {
                            src: M
                        }), "头像收集于网络，仅供个人娱乐使用，请勿商业用途。" ]
                    }), (0, j.jsx)(o.G7, {
                        className: "theme-card",
                        children: null === (e = Object.keys(c)) || void 0 === e ? void 0 : e.map(function(e, i) {
                            var g, n, t, a;
                            return (0, j.jsxs)(o.G7, {
                                style: {
                                    marginRight: (null === (g = Object.keys(c)) || void 0 === g ? void 0 : g.length) % 2 > 0 && i === (null === (n = Object.keys(c)) || void 0 === n ? void 0 : n.length) - 1 ? "178px" : ""
                                },
                                onClick: function() {
                                    s().navigateTo({
                                        url: "/pages/picloader/index?title=12313",
                                        success: function(i) {
                                            var g;
                                            i.eventChannel.emit("sendPicLibInfo", {
                                                title: (null === (g = A[e]) || void 0 === g ? void 0 : g.title) || e,
                                                data: c[e]
                                            });
                                        }
                                    });
                                },
                                children: [ (0, j.jsx)(o.G7, {
                                    className: "title",
                                    children: (null === (t = A[e]) || void 0 === t ? void 0 : t.title) || e
                                }), (0, j.jsx)(o.Ee, {
                                    src: null === (a = A[e]) || void 0 === a ? void 0 : a.img
                                }) ]
                            }, i);
                        })
                    }) ]
                }) ]
            });
        }, E = h, b = {
            enableShareAppMessage: !0
        };
        E.enableShareTimeline = !0, E.enableShareAppMessage = !0;
        Page((0, c.createPageConfig)(E, "pages/piclib/index", {
            root: {
                cn: []
            }
        }, b || {}));
    }
}, function(e) {
    var i = function(i) {
        return e(e.s = i);
    };
    e.O(0, [ 107, 216, 592 ], function() {
        return i(2867);
    });
    e.O();
} ]);