(wx["webpackJsonp"] = wx["webpackJsonp"] || []).push([ [ 722 ], {
    9812: function(t, n, e) {
        var a = e(2180), o = e(9439), r = e(1515), c = e(2954), s = e.n(c), i = e(9572), u = e(559), p = e(7294), l = e(1301), x = e(5893);
        function f() {
            var t = (0, p.useState)([]), n = (0, o.Z)(t, 2), e = n[0], a = n[1];
            return (0, c.useLoad)(function() {
                var t = s().getStorageSync(u.F);
                t && a(t);
            }), (0, x.jsxs)(r.G7, {
                className: "wrapper",
                children: [ (0, x.jsx)("privacy-popup", {}), (0, x.jsx)(i.Z, {
                    title: "收藏夹",
                    showBackBtn: !0
                }), (0, x.jsx)(l.Z, {
                    photoList: e,
                    isCollect: !0
                }) ]
            });
        }
        var g = {
            navigationBarTitleText: "首页"
        };
        Page((0, a.createPageConfig)(f, "pages/collect/index", {
            root: {
                cn: []
            }
        }, g || {}));
    }
}, function(t) {
    var n = function(n) {
        return t(t.s = n);
    };
    t.O(0, [ 107, 216, 592 ], function() {
        return n(9812);
    });
    t.O();
} ]);