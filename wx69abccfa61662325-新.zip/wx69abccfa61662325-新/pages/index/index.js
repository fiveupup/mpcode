(wx["webpackJsonp"] = wx["webpackJsonp"] || []).push([ [ 539 ], {
    6067: function(e, s, n) {
        var a = n(2180), i = n(1515), t = n(2954), o = n.n(t), r = n(9572), c = n(5413), l = n.p + "pages/index/imgs/photo.png", p = n.p + "pages/index/imgs/photo_top.png", m = n.p + "pages/index/imgs/photo_bottom.png", g = n.p + "images/icon-shootingStar.svg", d = n(5893), u = [ {
            url: "../page101/index",
            bannerImage: c
        } ], h = function() {
            var e = function() {
                return {
                    title: "给头像换新颖",
                    path: "/pages/index/index",
                    imageUrl: "https://zm-1253465948.cos.ap-nanjing.myqcloud.com/static/photo/share_common.png"
                };
            };
            return (0, t.useShareAppMessage)(e), (0, t.useShareTimeline)(e), (0, d.jsxs)(i.G7, {
                className: "wrapper",
                children: [ (0, d.jsx)(r.Z, {
                    title: "头像工具"
                }), (0, d.jsxs)(i.G7, {
                    className: "components-warpper",
                    children: [ (0, d.jsx)(i.G7, {
                        className: "banner",
                        children: (0, d.jsx)(i.tq, {
                            indicatorColor: "#999",
                            indicatorActiveColor: "#333",
                            circular: !0,
                            indicatorDots: (null === u || void 0 === u ? void 0 : u.length) > 1,
                            autoplay: !0,
                            activeClass: "active-swiper-item",
                            children: u.map(function(e, s) {
                                return (0, d.jsx)(i.t3, {
                                    className: "swiper-item",
                                    children: (0, d.jsx)(i.Ee, {
                                        src: null === e || void 0 === e ? void 0 : e.bannerImage,
                                        onClick: function() {
                                            o().navigateTo({
                                                url: null === e || void 0 === e ? void 0 : e.url
                                            });
                                        }
                                    })
                                }, s);
                            })
                        })
                    }), (0, d.jsxs)(i.G7, {
                        className: "components-card",
                        onClick: function() {
                            o().navigateTo({
                                url: "/pages/photo/index"
                            });
                        },
                        children: [ (0, d.jsxs)(i.G7, {
                            className: "item-left",
                            children: [ (0, d.jsx)(i.Ee, {
                                src: l
                            }), (0, d.jsxs)(i.G7, {
                                className: "tips",
                                children: [ (0, d.jsx)(i.Ee, {
                                    src: g
                                }), "头像挂件" ]
                            }) ]
                        }), (0, d.jsxs)(i.G7, {
                            className: "item-right",
                            children: [ (0, d.jsx)(i.Ee, {
                                className: "list-item-top",
                                src: p
                            }), (0, d.jsx)(i.Ee, {
                                className: "list-item-bottom",
                                src: m
                            }) ]
                        }) ]
                    }) ]
                }) ]
            });
        }, x = h, j = {
            enableShareAppMessage: !0
        };
        x.enableShareTimeline = !0, x.enableShareAppMessage = !0;
        Page((0, a.createPageConfig)(x, "pages/index/index", {
            root: {
                cn: []
            }
        }, j || {}));
    }
}, function(e) {
    var s = function(s) {
        return e(e.s = s);
    };
    e.O(0, [ 107, 216, 592 ], function() {
        return s(6067);
    });
    e.O();
} ]);