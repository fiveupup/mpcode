var e = require("../lib/es6-promise").Promise;

wx.pro = {}, [ "login", "getUserInfo", "navigateTo", "checkSession", "getStorageInfo", "removeStorage", "clearStorage", "getNetworkType", "getSystemInfo" ].forEach(function(t) {
    wx.pro[t] = function() {
        var o = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {};
        return new e(function(e, n) {
            o.success = function(o) {
                console.log("wx.".concat(t, " success"), o), e(o);
            }, o.fail = function(e) {
                console.error("wx.".concat(t, " fail"), e), n(e);
            }, wx[t](o);
        });
    };
}), wx.pro.getStorage = function(t) {
    return new e(function(e, o) {
        wx.getStorage({
            key: t,
            success: function(t) {
                e(t.data);
            },
            fail: function(t) {
                e();
            }
        });
    });
}, wx.pro.setStorage = function(t, o) {
    return new e(function(e, n) {
        wx.setStorage({
            key: t,
            data: o,
            success: function(t) {
                e(o);
            },
            fail: function(e) {
                n(e);
            }
        });
    });
}, wx.pro.request = function(t) {
    return t.toast && wx.showToast({
        title: t.toast.title || "加载中",
        icon: "loading"
    }), new e(function(e, o) {
        wx.request({
            url: t.url,
            method: t.method || "GET",
            data: t.data,
            success: function(n) {
                n.statusCode >= 400 ? (console.error("wx.request fail [business]", t, n.statusCode, n.data), 
                o(n)) : (console.log("wx.request success", t, n.data), e(n.data));
            },
            fail: function(e) {
                console.error("wx.request fail [network]", t, e), o(e);
            }
        });
    });
}, module.exports = e;