var e = require("./api"), o = !1, t = {
    timeout: 1e4,
    timeoutObj: null,
    serverTimeoutObj: null,
    reset: function() {
        return clearTimeout(this.timeoutObj), clearTimeout(this.serverTimeoutObj), this;
    },
    start: function() {
        this.timeoutObj = setTimeout(function() {
            console.log("heartCheck start"), console.log("发送ping"), wx.sendSocketMessage({
                data: JSON.stringify({
                    socketCmd: 999,
                    socketAction: "ping"
                }),
                success: function() {
                    console.log("发送ping成功");
                }
            });
        }, this.timeout);
    }
}, n = function() {
    console.log("openWebsocket"), wx.connectSocket({
        url: "".concat(e.websocketUrl),
        success: function() {
            console.log("连接成功"), c();
        }
    });
}, c = function() {
    t.reset().start(), wx.onSocketMessage(function(e) {
        console.log("get msg in util"), "pong" == e.data ? t.reset().start() : console.log(e);
    }), wx.onSocketOpen(function() {
        console.log("WebSocket连接打开"), o = !0, 0;
    }), wx.onSocketError(function(e) {
        console.log("WebSocket连接打开失败"), o = !1, !1, s();
    }), wx.onSocketClose(function(e) {
        console.log("WebSocket 已关闭！"), o = !1, !1, s();
    });
}, s = function() {};

module.exports = {
    setOpenState: function(e) {
        e ? (o = !0, 0) : (o = !1, !1, s());
    },
    heartCheck: t,
    openWebsocket: n,
    closeWebsocket: function() {
        console.log("closeWebsocket..."), wx.closeSocket({});
    },
    initWebsocketEventHandle: c,
    reconnect: s,
    sendMsg: function(e) {
        o && (e.version = 1, wx.sendSocketMessage({
            data: JSON.stringify(e),
            success: function() {
                console.log("发送msg成功", e);
            }
        }));
    }
};