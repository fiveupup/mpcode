var o = wx.createInnerAudioContext();

module.exports = {
    play: function(a) {
        console.log("play:", a);
        var e = !1, n = "";
        switch (a) {
          case "正确答案":
            n = "/audio/1.mp3";
            break;

          case "错误答案":
            n = "/audio/2.wav";
            break;

          case "等待界面":
            e = !0, n = "/audio/3.mp3";
            break;

          case "排行榜":
            n = "/audio/4.mp3";
            break;

          case "我的荣誉":
            n = "/audio/5.mp3";
            break;

          case "匹配成功":
            n = "/audio/6.wav";
            break;

          case "挑战成功":
            n = "/audio/7.wav";
            break;

          case "挑战失败":
            n = "/audio/8.mp3";
        }
        o.src = n, o.autoplay = !1, o.loop = e, o.play(), o.onPlay(function() {
            console.log("audio onPlay"), console.log("开始播放:", a);
        }), o.onError(function(o) {
            console.log("audio onError"), console.log(o.errMsg), console.log(o.errCode);
        });
    },
    stop: function() {
        o.stop(), o.src = "", o.autoplay = !1, o.loop = !1;
    },
    pause: function() {
        o.pause();
    },
    continuePlay: function() {
        o.play();
    }
};