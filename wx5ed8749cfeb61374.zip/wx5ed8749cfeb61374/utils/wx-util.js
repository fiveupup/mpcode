require("../lib/es6-promise").Promise;

var o = require("./api"), e = function() {
    wx.getSetting({
        success: function(o) {
            console.log("wx.getSetting"), o.authSetting["scope.userInfo"] ? wx.getUserInfo({
                success: function(o) {
                    console.log("wx.getUserInfo"), getApp().globalData.userInfo = o.userInfo, WXUtil.updateUserInfo(o.userInfo);
                }
            }) : console.log("未授权");
        }
    });
};

module.exports = {
    doTest: function() {
        console.log("tom: dotest...");
    },
    doLogin: function() {
        console.log("tom: dologin... ");
        wx.login({
            success: function(n) {
                console.log("tom: ", n), n.code ? (console.log("code:", n.code), console.log("invoke code2openid"), 
                wx.request({
                    url: o.getUrl("code2openid"),
                    data: {
                        code: n.code
                    },
                    success: function(o) {
                        console.log("tom: login success", o), console.log("res data:", o.data);
                        var n = o.data.data;
                        console.log("openid:" + n), wx.setStorageSync("openid", n);
                        var t = o.data.userid;
                        console.log("userid:", t), wx.setStorageSync("userid", t), e();
                    },
                    fail: function(o) {
                        console.log("tom: login fail", o);
                    }
                })) : console.log("获取用户登录态失败！" + n.errMsg);
            }
        });
    },
    doUserInfo: e,
    updateUserInfo: function(e) {
        var n = wx.getStorageSync("openid") || "";
        console.log("tom: updateUserInfo 用户信息2", e, n), n.length > 0 && o.updateUserInfo(n, e.nickName, e.avatarUrl).then(function(o) {
            console.log("tom: updateUserInfo() ->", o);
        }).catch(function(o) {
            console.log("tom: updateUserInfo() err ->", o);
        }).finally(function(o) {
            console.log("updateUserInfo finally~");
        });
    },
    getUserNickname: function() {
        return wx.getStorageSync("nickname") || "";
    },
    getOpenId: function() {
        return wx.getStorageSync("openid") || "";
    },
    getUserId: function() {
        return wx.getStorageSync("userid") || "";
    }
};