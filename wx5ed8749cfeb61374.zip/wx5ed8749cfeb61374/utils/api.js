var e = require("../lib/es6-promise").Promise, n = "ws://bfytech.natapp1.cc";

n = "wss://www.bfytech.com:9001";

var t = "";

t = "https://www.bfytech.com/";

var i = {
    code2openid: "dati_server302/public/index.php/wxapi/index/code2openid",
    updateuserinfo: "dati_server302/public/index.php/wxapi/index/updateUserInfo",
    getrating: "dati_server302/public/index.php/wxapi/index/getRating",
    getranking: "dati_server302/public/index.php/wxapi/index/getRanking",
    getgrouping: "dati_server302/public/index.php/wxapi/index/getgrouplist",
    updateusergroup: "dati_server302/public/index.php/wxapi/index/updateUserGroup",
    gettraingquestion: "dati_server302/public/index.php/wxapi/index/getTraingQuestion",
    getannounce: "dati_server302/public/index.php/wxapi/index/getAnnounce",
    getgamestatus: "dati_server302/public/index.php/wxapi/index/getGameStatus",
    getchallenge: "dati_server302/public/index.php/wxapi/index/getChallenge",
    sendresult: "dati_server302/public/index.php/wxapi/index/sendResult",
    updateusertrain: "dati_server302/public/index.php/wxapi/index/updateUserTrain",
    changerealname: "dati_server302/public/index.php/wxapi/index/changeRealname",
    changemobile: "dati_server302/public/index.php/wxapi/index/changeMobile"
}, r = function(e) {
    return t + i[e];
};

function u(n) {
    return function() {
        var t = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {};
        return new e(function(e, i) {
            t.success = function(n) {
                e(n);
            }, t.fail = function(e) {
                i(e);
            }, n(t);
        });
    };
}

function a(e, n) {
    return u(wx.request)({
        url: e,
        method: "GET",
        data: n,
        header: {
            "Content-Type": "application/json"
        }
    });
}

function p(e, n) {
    return u(wx.request)({
        url: e,
        method: "POST",
        data: n,
        header: {
            "Content-Type": "application/json"
        }
    });
}

e.prototype.finally = function(e) {
    var n = this.constructor;
    return this.then(function(t) {
        return n.resolve(e()).then(function() {
            return t;
        });
    }, function(t) {
        return n.resolve(e()).then(function() {
            throw t;
        });
    });
};

module.exports = {
    websocketUrl: n,
    getUrl: r,
    getRating: function(e) {
        return a(r("getrating"), {
            openid: e
        });
    },
    updateUserInfo: function(e, n, t) {
        return p(r("updateuserinfo"), {
            openid: e,
            name: n,
            avatar: t
        });
    },
    getRanking: function() {
        return a(r("getranking"), {});
    },
    getGrouplist: function() {
        return a(r("getgrouping"), {});
    },
    updateUserGroup: function(e, n, t, i) {
        return p(r("updateusergroup"), {
            openid: e,
            group: n,
            realname: t,
            mobile: i
        });
    },
    getTraingQuestion: function(e, n, t) {
        return a(r("gettraingquestion"), {
            openid: e,
            challenge_id: n,
            question_idx: t,
            version: 2
        });
    },
    getAnnounce: function() {
        return a(r("getannounce"), {});
    },
    getGameStatus: function() {
        return a(r("getgamestatus"), {});
    },
    getChallenge: function(e) {
        return p(r("getchallenge"), {
            openid: e
        });
    },
    sendResult: function(e, n, t, i) {
        return p(r("sendresult"), {
            openid: e,
            score: n,
            time_consuming: t,
            subject_type: i
        });
    },
    updateUserTrain: function(e, n) {
        return p(r("updateusertrain"), {
            openid: e,
            subject_type: n
        });
    },
    changeRealname: function(e, n) {
        return p(r("changerealname"), {
            openid: e,
            realname: n
        });
    },
    changeMobile: function(e, n) {
        return p(r("changemobile"), {
            openid: e,
            mobile: n
        });
    }
};