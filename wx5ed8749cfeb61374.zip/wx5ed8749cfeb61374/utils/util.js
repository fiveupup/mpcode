var e = require("../@babel/runtime/helpers/objectSpread2"), t = require("../lib/es6-promise").Promise, n = function(e) {
    return (e = e.toString())[1] ? e : "0" + e;
};

module.exports = {
    formatTime: function(e) {
        var t = e.getFullYear(), r = e.getMonth() + 1, o = e.getDate(), i = e.getHours(), s = e.getMinutes(), u = e.getSeconds();
        return [ t, r, o ].map(n).join("/") + " " + [ i, s, u ].map(n).join(":");
    },
    formatTimeYMD: function(e) {
        return e.getFullYear() + "-" + (e.getMonth() + 1) + "-" + e.getDate();
    },
    formatAudioTime: function(e) {
        var t = parseInt(e), r = parseInt(t / 60), o = parseInt(t % 60);
        return n(r) + ":" + n(o);
    },
    promiseify: function(n) {
        return function(r) {
            return new t(function(t, o) {
                return n(e(e({}, r), {}, {
                    success: t,
                    fail: o
                }));
            });
        };
    },
    showBusy: function(e) {
        return wx.showToast({
            title: e,
            icon: "loading",
            duration: 5e3
        });
    },
    showSuccess: function(e) {
        return wx.showToast({
            title: e,
            icon: "success"
        });
    },
    showModel: function(e, t) {
        wx.hideToast(), wx.showModal({
            title: e,
            content: JSON.stringify(t),
            showCancel: !1
        });
    }
};