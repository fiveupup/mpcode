require("./utils/wx-pro");

var n = require("./utils/api");

require("./utils/wx-util");

App({
    onLaunch: function() {
        this.updateApp();
        var n = wx.getStorageSync("userInfo");
        n && (this.globalData.userInfo = n);
    },
    onShow: function(n) {
        this.getAnnounce(), this.preDoLogin();
    },
    onHide: function() {},
    onError: function(n) {
        console.log(n);
    },
    globalData: {
        userInfo: {},
        scene: "",
        version: "version:1.0.1124",
        inService: 0,
        inProcess: !1
    },
    countLevel: function(n) {
        var o = Math.floor((Math.log(n) - Math.log(30)) / Math.log(2) + 1);
        return o < 1 ? 1 : o;
    },
    updateApp: function() {
        wx.getUpdateManager().onCheckForUpdate(function(n) {
            console.log("是否有新版本：" + n.hasUpdate), n.hasUpdate && (wx.getUpdateManager().onUpdateReady(function() {
                wx.showModal({
                    title: "更新提示",
                    content: "新版本已经准备好，单击确定重启应用",
                    showCancel: !1,
                    success: function(n) {
                        n.confirm && wx.getUpdateManager().applyUpdate();
                    }
                });
            }), wx.getUpdateManager().onUpdateFailed(function() {
                wx.showModal({
                    title: "提示",
                    content: "检查到有新版本，但下载失败，请检查网络设置",
                    showCancel: !1
                });
            }));
        });
    },
    preDoLogin: function() {
        var n = this;
        (wx.getStorageSync("openid") || "").length > 0 ? wx.checkSession({
            success: function() {},
            fail: function() {
                n.doLogin();
            }
        }) : this.doLogin();
    },
    doLogin: function(o) {
        wx.login({
            success: function(o) {
                wx.request({
                    url: n.getUrl("code2openid"),
                    data: {
                        code: o.code
                    },
                    success: function(n) {
                        console.log("tom: login success", n);
                        var o = n.data.data;
                        console.log("openid:" + o), wx.setStorageSync("openid", o);
                    },
                    fail: function(n) {
                        console.log("tom: login fail", n);
                    }
                });
            }
        });
    },
    getAnnounce: function() {
        var o = this;
        n.getAnnounce().then(function(n) {
            console.log("tom: getAnnounce() ->", n);
            var e = JSON.parse(n.data);
            o.globalData.inService = e.inservice;
        }).catch(function(n) {
            console.log("tom: getAnnounce() err ->", n);
        }).finally(function(n) {
            console.log("getAnnounce finally~");
        });
    }
});