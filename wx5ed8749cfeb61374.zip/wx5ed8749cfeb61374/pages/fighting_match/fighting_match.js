var o, a = require("../../utils/audio-util"), e = require("../../utils/websocket-util"), t = (require("../../utils/util.js"), 
getApp());

Page({
    data: {
        avatarUrl: ""
    },
    onLoad: function(o) {
        var a = wx.getStorageSync("openid") || "";
        "" !== a && (t.globalData.userInfo.openid = a), this.setData({
            avatarUrl: t.globalData.userInfo.avatarUrl
        }), wx.setStorage({
            key: "user_me",
            data: t.globalData.userInfo
        });
    },
    onReady: function() {},
    onShow: function() {
        wx.setNavigationBarTitle({
            title: "等待对手加入"
        }), console.log("show fighting_match"), a.play("等待界面"), this.match_room();
    },
    onHide: function() {
        clearInterval(o), a.stop();
    },
    onUnload: function() {
        a.stop(), clearInterval(o), this.cancel_match(), console.log("fighting_match page onUnload...");
    },
    onPullDownRefresh: function() {},
    onReachBottom: function() {},
    onShareAppMessage: function() {},
    cancel_match: function() {
        console.log("cancel_match...");
        var o = {
            socketCmd: 101,
            socketAction: "cancel_match",
            data: {
                openid: t.globalData.userInfo.openid
            }
        };
        e.sendMsg(o), e.closeWebsocket();
    },
    match_room: function() {
        var a = this, n = {
            socketCmd: 100,
            socketAction: "match_room",
            data: {
                openid: t.globalData.userInfo.openid
            }
        };
        console.log("match_room send data", n), e.sendMsg(n), clearInterval(o), o = setTimeout(function() {
            wx.showModal({
                title: "提示",
                content: "还没有对手加入挑战",
                confirmText: "退出等待",
                cancelText: "继续等待",
                success: function(o) {
                    o.confirm ? (a.cancel_match(), wx.navigateBack({
                        delta: 1
                    })) : console.log("用户点击继续等待");
                }
            });
        }, 4e4), wx.onSocketMessage(function(o) {
            if (console.log("get msg in match_room", o), "pong" == o.data) return console.log("receive pong..."), 
            void e.heartCheck.reset().start();
            var t = JSON.parse(o.data);
            switch (console.log("res", t), t.action) {
              case "match_room":
                wx.setStorageSync("user_others", t.data.player_other), wx.navigateTo({
                    url: "../fighting_room/fighting_room?roomName=" + t.data.roomName
                });
                break;

              case "match_room_wait":
                console.log("匹配用户失败，服务器回复201,请客户端等待");
                break;

              case "match_room_server_busy":
                console.log("匹配用户失败，服务器回复202,服务器忙");
                break;

              case "match_room_game_not_start":
                console.log("匹配用户失败，服务器回复203,请客户端等待"), wx.showModal({
                    title: "提示",
                    content: "挑战还没开始",
                    confirmText: "退出等待",
                    success: function(o) {
                        o.confirm ? (a.cancel_match(), wx.navigateBack({
                            delta: 1
                        })) : console.log("用户点击继续等待");
                    }
                });
            }
        });
    }
});