var n = require("../../utils/api"), o = require("../../utils/audio-util");

Page({
    data: {
        showRankingWorld: !0,
        worldList: [],
        groupList: [],
        flagLoaded: !1
    },
    onLoad: function(n) {
        this.getRanking();
    },
    onReady: function() {},
    onShow: function() {
        wx.setNavigationBarTitle({
            title: "排行榜"
        }), o.play("排行榜");
    },
    onHide: function() {
        o.stop();
    },
    onUnload: function() {},
    onPullDownRefresh: function() {},
    onReachBottom: function() {},
    onShareAppMessage: function() {},
    switchShowRankingWorld: function() {
        this.setData({
            showRankingWorld: !0
        });
    },
    switchShowRankingPerson: function() {
        this.setData({
            showRankingWorld: !1
        });
    },
    getRanking: function() {
        wx.showToast({
            title: "",
            icon: "loading",
            duration: 1e4
        });
        var o = this;
        n.getRanking().then(function(n) {
            console.log("tom: getRanking() ->", n);
            var t = n.data;
            o.setData({
                worldList: t.world,
                groupList: t.group
            });
        }).catch(function(n) {
            console.log("tom: getRankingList() err ->", n);
        }).finally(function(n) {
            console.log("getRankingList finally~"), wx.hideToast(), wx.stopPullDownRefresh(), 
            o.setData({
                flagLoaded: !0
            });
        });
    }
});