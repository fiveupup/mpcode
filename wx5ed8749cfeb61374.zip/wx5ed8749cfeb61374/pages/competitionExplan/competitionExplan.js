require("../../utils/wx-util");

var n = getApp();

Page({
    data: {
        version: "Version1"
    },
    onLoad: function(o) {
        this.setData({
            version: n.globalData.version
        });
    },
    onReady: function() {},
    onShow: function() {
        wx.setNavigationBarTitle({
            title: "参赛说明"
        });
    },
    onHide: function() {},
    onUnload: function() {},
    onPullDownRefresh: function() {},
    onReachBottom: function() {},
    onShareAppMessage: function() {},
    onGotUserInfo: function(n) {}
});