Page({
    data: {},
    onLoad: function(n) {},
    onReady: function() {},
    onShow: function() {
        wx.setNavigationBarTitle({
            title: "奖项说明"
        });
    },
    onHide: function() {},
    onUnload: function() {},
    onPullDownRefresh: function() {},
    onReachBottom: function() {},
    onShareAppMessage: function() {}
});