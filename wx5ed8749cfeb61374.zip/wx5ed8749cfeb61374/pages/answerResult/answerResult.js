var e = require("../../utils/audio-util"), o = require("../../utils/websocket-util");

Page({
    data: {
        userInfo_me: "",
        userInfo_others: "",
        scoreMyself: 0,
        score_others: 0,
        win: !1
    },
    onLoad: function(e) {
        this.setData({
            userInfo_me: wx.getStorageSync("user_me"),
            userInfo_others: wx.getStorageSync("user_others"),
            scoreMyself: parseInt(e.scoreMyself),
            score_others: parseInt(e.score_others),
            win: parseInt(e.scoreMyself) >= parseInt(e.score_others)
        }), console.log(this.data);
    },
    onReady: function() {},
    onShow: function() {
        var o = this;
        wx.setNavigationBarTitle({
            title: "挑战结果"
        }), setTimeout(function() {
            o.data.win ? e.play("挑战成功") : e.play("挑战失败");
        }, 1e3);
    },
    onHide: function() {},
    onUnload: function() {},
    onPullDownRefresh: function() {},
    onReachBottom: function() {},
    onShareAppMessage: function() {},
    try_again: function(e) {
        wx.navigateBack({
            delta: 2
        });
    },
    back_home_page: function(e) {
        o.closeWebsocket(), wx.navigateBack({
            delta: 2
        });
    }
});