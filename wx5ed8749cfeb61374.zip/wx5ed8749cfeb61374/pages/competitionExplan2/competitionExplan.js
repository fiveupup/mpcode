var o = require("../../utils/wx-util"), e = getApp();

Page({
    data: {},
    onLoad: function(o) {},
    onReady: function() {},
    onShow: function() {
        wx.setNavigationBarTitle({
            title: "参赛说明"
        });
    },
    onHide: function() {},
    onUnload: function() {},
    onPullDownRefresh: function() {},
    onReachBottom: function() {},
    onShareAppMessage: function() {},
    getUserProfile: function() {
        console.log("getUserProfile..."), wx.getUserProfile({
            desc: "用于展示用户信息",
            success: function(n) {
                console.log("getUserProfile success."), e.globalData.userInfo = n.userInfo, console.log("app.globalData.userInfo", e.globalData.userInfo), 
                wx.setStorageSync("showReadme", "true"), wx.setStorageSync("userInfo", n.userInfo), 
                o.updateUserInfo(n.userInfo), wx.redirectTo({
                    url: "../index/index"
                });
            },
            fail: function(o) {
                console.log("getUserProfile fail."), console.log(o);
            }
        });
    }
});