var e, t, a, n = require("../../utils/audio-util"), i = require("../../utils/api"), o = (require("../../utils/util.js"), 
require("../../utils/base64.js")), s = getApp(), r = 500, c = 20;

Page({
    data: {
        userInfo_me: "",
        countdown: c,
        question: "",
        hasClick: !1,
        localClick: !1,
        clickIndex: "",
        answerColor: "",
        isGaming: !1,
        challenge_id: -1,
        question_num: 100,
        question_idx: 1,
        question_idx_dis: 1,
        score: 0,
        time_consuming: 0,
        over_with_wrong_answer: !1,
        game_over: !1
    },
    onLoad: function(e) {
        console.log("训练场。。。"), this.setData({
            userInfo_me: wx.getStorageSync("user_me"),
            challenge_id: e.challenge_id || -1
        }), this.data.challenge_id > 0 && this.setData({
            isGaming: !0
        }), this.getTraingQuestion();
    },
    onReady: function() {},
    onShow: function() {
        var e = "训练场";
        1 == this.data.isGaming && (e = "挑战赛"), wx.setNavigationBarTitle({
            title: e
        }), s.globalData.inProcess = !0;
    },
    onHide: function() {},
    onUnload: function() {
        s.globalData.inProcess = !1, clearInterval(e), clearInterval(t), clearInterval(a), 
        clearTimeout(e), clearTimeout(t), clearTimeout(a), n.stop(), 1 == this.data.isGaming && 0 == this.data.over_with_wrong_answer && this.sendResult();
    },
    onPullDownRefresh: function() {},
    onReachBottom: function() {},
    onShareAppMessage: function() {},
    beginGame: function() {
        var e = this;
        clearInterval(t), setTimeout(function() {
            e.setData({
                question: "",
                animate_showChoice: "",
                countdown: c,
                clickIndex: "",
                answerColor: "",
                animate_rightAnswer: "",
                question_idx_dis: e.data.question_idx
            }), e.getTraingQuestion();
        }, 500);
    },
    getTraingQuestion: function() {
        if (1 == this.data.isGaming && 1 == this.data.game_over) return clearInterval(e), 
        clearInterval(t), clearInterval(a), void wx.showModal({
            title: "提示",
            content: "已答完20题，本次挑战结束",
            showCancel: !1,
            confirmText: "知道了",
            success: function(e) {
                e.confirm && wx.navigateBack({});
            }
        });
        wx.showToast({
            title: "",
            icon: "loading",
            duration: 1e4
        });
        var n = this, l = wx.getStorageSync("openid") || "";
        0 == this.data.isGaming && (l = ""), console.log("getTraingQuestion question_idx =", this.data.question_idx), 
        i.getTraingQuestion(l, this.data.challenge_id, this.data.question_idx).then(function(i) {
            console.log("tom: getTraingQuestion() ->", i);
            try {
                var l = JSON.parse(i.data);
                l = l.question;
                var u = {}, d = [];
                u.ask = o.decode(l.ask), l.answer.forEach(function(e) {
                    var t = {};
                    t.answer = o.decode(e.answer), t.right = e.right, d.push(t);
                }), u.answer = d, n.setData({
                    question: u
                });
            } catch (e) {
                return void wx.showModal({
                    title: "提示",
                    content: "获取当前题目异常，直接进入下一题",
                    showCancel: !1,
                    confirmText: "知道了",
                    success: function(e) {
                        if (e.confirm) {
                            var t = n.data.question_idx;
                            n.setData({
                                question_idx: t + 1 > 20 ? 20 : t + 1
                            }), n.beginGame();
                        }
                    }
                });
            }
            if (0 == s.globalData.inProcess) return clearInterval(e), clearInterval(t), clearInterval(a), 
            clearTimeout(e), clearTimeout(t), void clearTimeout(a);
            clearTimeout(e), n.data.question.hasOwnProperty("ask") && (e = setTimeout(function() {
                !function(e) {
                    e.setData({
                        animate_showChoice: "fadeIn",
                        countdown: c,
                        localClick: !1,
                        hasClick: !1,
                        clickIndex: "",
                        answerColor: "",
                        animate_rightAnswer: ""
                    });
                }(n);
            }, 500)), clearInterval(t);
            var g = n.data.countdown;
            setTimeout(function() {
                n.setData({
                    localClick: !1,
                    hasClick: !1
                }), n.setData({
                    animate_showChoice: "fadeIn"
                }), t = setInterval(function() {
                    g--, n.setData({
                        countdown: g
                    }), g <= 0 && clearInterval(t);
                }, 1e3);
            }, r), clearTimeout(a), a = setTimeout(function() {
                if (!n.data.localClick && !n.data.hasClick) {
                    console.log("用户无选择，请求下一题");
                    var e = n.data.question_idx;
                    n.data.countdown, n.data.time_consuming;
                    n.setData({
                        question_idx: e + 1,
                        game_over: e + 1 > 20
                    }), n.beginGame();
                }
            }, 1e3 * (c + .9));
        }).catch(function(e) {
            console.log("tom: getTraingQuestionList() err ->", e);
        }).finally(function(e) {
            console.log("getTraingQuestionList finally~"), wx.hideToast(), wx.stopPullDownRefresh();
        });
    },
    answer: function(e) {
        var t = this;
        if (0 == t.data.localClick) {
            console.log("answer clicked...."), t.setData({
                localClick: !0
            }), e.currentTarget.dataset.right ? t.setData({
                clickIndex: e.currentTarget.dataset.index,
                answerColor: "right"
            }) : t.setData({
                clickIndex: e.currentTarget.dataset.index,
                answerColor: "error"
            });
            var a = t.data.question_idx, i = c - t.data.countdown + t.data.time_consuming;
            if (t.setData({
                question_idx: a + 1,
                game_over: a + 1 > 20
            }), "right" == t.data.answerColor) {
                n.play("正确答案");
                var o = t.data.score;
                1 == t.data.isGaming && t.setData({
                    score: o + 5,
                    time_consuming: i
                });
            } else n.play("错误答案");
            t.setData({
                localClick: !0,
                animate_rightAnswer: "right"
            }), setTimeout(function() {
                t.beginGame();
            }, 2e3);
        }
    },
    sendResult: function() {}
});