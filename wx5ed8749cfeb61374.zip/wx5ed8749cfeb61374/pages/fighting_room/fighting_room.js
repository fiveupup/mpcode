var e = require("../../utils/audio-util"), a = require("../../utils/websocket-util"), t = require("../../utils/util.js"), o = (getApp(), 
1500);

Page({
    data: {
        roomName: "",
        userInfo_me: "",
        userInfo_others: "",
        countdown: 10,
        question: "",
        hasClick: !1,
        localClick: !1,
        clickIndex: "",
        answerColor: "",
        scoreMyself: 0,
        status_users_others: {
            openid: "",
            userChoose: "",
            answerColor: ""
        },
        score_others: 0,
        game_over: !1,
        win: 2,
        sendNumber: 0,
        questionNumber: 0
    },
    onLoad: function(a) {
        e.stop(), wx.setNavigationBarTitle({
            title: "青春智上"
        }), wx.showShareMenu({
            withShareTicket: !0
        }), this.setData({
            roomName: a.roomName,
            userInfo_me: wx.getStorageSync("user_me"),
            userInfo_others: wx.getStorageSync("user_others")
        }), console.log("userInfo_me :", this.data.userInfo_me), this.startAnimate(), this.fightingReady(a.roomName);
    },
    onUnload: function() {
        wx.navigateBack({
            delta: 2
        }), console.log("fighting_room page onUnload...");
    },
    onShareAppMessage: function(e) {
        return {
            title: "谁学富五车？比比看吧！",
            path: "/pages/entry/entry?currentClickId=0",
            success: function(e) {
                wx.redirectTo({
                    url: "../entry/entry"
                });
            }
        };
    },
    fightingReady: function(s) {
        var r, n, i, c = this;
        a.sendMsg({
            socketCmd: 300,
            socketAction: "ready_to_answer",
            data: {
                openid: this.data.userInfo_me.openid,
                roomName: this.data.roomName
            }
        }), wx.onSocketMessage(function(s) {
            var l = JSON.parse(s.data);
            switch (console.log("res", l), l.action) {
              case "GameOver":
                r = setTimeout(function() {
                    c.data.scoreMyself > c.data.score_others ? c.setData({
                        game_over: !0,
                        win: 1
                    }) : c.data.scoreMyself < c.data.score_others ? c.setData({
                        game_over: !0,
                        win: 0
                    }) : c.setData({
                        game_over: !0
                    });
                    var e = {
                        socketAction: "fightingResult",
                        data: {
                            openid: c.data.userInfo_me.openid,
                            fightingResult: c.data.win
                        }
                    };
                    a.sendMsg(e), wx.navigateTo({
                        url: "../answerResult/answerResult?scoreMyself=" + c.data.scoreMyself + "&score_others=" + c.data.score_others
                    });
                }, 1e3);
                break;

              case "getAnswer":
                c.setData({
                    hasClick: !0
                });
                break;

              case "runawayNotice":
                console.log("对手已逃跑"), t.showSuccess(l.msg), c.setData({
                    game_over: !0,
                    win: 1
                });
                break;

              case "question":
                console.log("收到题目"), e.stop();
                var d = l.data.question;
                console.log("res.data.choicePlayer1[0]", l.data.choicePlayer1[0]), console.log("my openid", c.data.userInfo_me.openid), 
                l.data.choicePlayer1[0] !== c.data.userInfo_me.openid ? (c.setData({
                    status_users_others: {
                        openid: l.data.choicePlayer1[0],
                        userChoose: l.data.choicePlayer1[1],
                        answerColor: l.data.choicePlayer1[2]
                    },
                    score_others: l.data.choicePlayer1[3],
                    animate_rightAnswer: "right"
                }), console.log("player1 ", c.data.status_users_others)) : (c.setData({
                    status_users_others: {
                        openid: l.data.choicePlayer2[0],
                        userChoose: l.data.choicePlayer2[1],
                        answerColor: l.data.choicePlayer2[2]
                    },
                    score_others: l.data.choicePlayer2[3],
                    animate_rightAnswer: "right"
                }), console.log("player2 ", c.data.status_users_others)), "" !== c.data.clickIndex && ("right" == c.data.answerColor ? e.play("正确答案") : e.play("错误答案")), 
                clearTimeout(r), Object.getOwnPropertyNames(d).length ? (c.setData({
                    questionNumber: c.data.questionNumber + 1
                }), r = setTimeout(function() {
                    u(c);
                }, 2e3)) : r = setTimeout(function() {
                    c.data.scoreMyself > c.data.score_others ? c.setData({
                        game_over: !0,
                        win: 1
                    }) : c.data.scoreMyself < c.data.score_others ? c.setData({
                        game_over: !0,
                        win: 0
                    }) : c.setData({
                        game_over: !0
                    });
                    var e = {
                        socketAction: "fightingResult",
                        data: {
                            openid: c.data.userInfo_me.openid,
                            fightingResult: c.data.win
                        }
                    };
                    a.sendMsg(e), wx.navigateTo({
                        url: "../answerResult/answerResult?scoreMyself=" + c.data.scoreMyself + "&score_others=" + c.data.score_others
                    });
                }, 2e3);
                var u = function(e) {
                    e.setData({
                        question: d,
                        animate_showChoice: "",
                        countdown: 10,
                        localClick: !1,
                        hasClick: !1,
                        clickIndex: "",
                        answerColor: "",
                        status_users_others: {
                            openid: "",
                            userChoose: "",
                            answerColor: ""
                        },
                        sendNumber: 0,
                        animate_rightAnswer: ""
                    }), clearInterval(n);
                    var a = e.data.countdown;
                    setTimeout(function() {
                        e.setData({
                            animate_showChoice: "fadeIn"
                        }), n = setInterval(function() {
                            a--, e.setData({
                                countdown: a
                            }), 0 == a && clearInterval(n);
                        }, 1e3);
                    }, o), clearTimeout(i), i = setTimeout(function() {
                        e.data.localClick || e.data.hasClick || e.sendAnswer(e);
                    }, 11e3);
                };
                break;

              default:
                console.log("default action", l.data.action);
            }
        });
    },
    answer: function(e) {
        this.data.localClick || (e.currentTarget.dataset.right ? (this.setData({
            clickIndex: e.currentTarget.dataset.index,
            answerColor: "right"
        }), this.setData({
            scoreMyself: this.data.scoreMyself + 1 * this.data.countdown
        })) : this.setData({
            clickIndex: e.currentTarget.dataset.index,
            answerColor: "error"
        }), this.setData({
            localClick: !0
        }), this.sendAnswer(this));
    },
    sendAnswer: function(e) {
        if (!(e.data.sendNumber > 0)) {
            var t = {
                socketCmd: 500,
                socketAction: "answer",
                data: {
                    roomName: e.data.roomName,
                    choice: {
                        openid: e.data.userInfo_me.openid,
                        userChoose: e.data.clickIndex,
                        answerColor: e.data.answerColor,
                        scoreMyself: e.data.scoreMyself
                    }
                }
            };
            a.sendMsg(t);
            var o = e.data.sendNumber + 1;
            e.setData({
                sendNumber: o
            });
        }
    },
    continue_fighting: function() {
        wx.reLaunch({
            url: "../entry/entry"
        });
    },
    startAnimate: function() {
        var e = this;
        e.setData({
            zoomIn: "zoomIn"
        }), setTimeout(function() {
            e.setData({
                zoomOut: "zoomOut"
            });
        }, 1500);
    }
});