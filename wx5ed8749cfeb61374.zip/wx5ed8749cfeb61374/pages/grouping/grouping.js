var t = require("../../utils/api"), o = getApp();

Page({
    data: {
        userInfo: {},
        groupList: [],
        selectIdx: -1,
        realName: "",
        mobile: "",
        group_id: "",
        group_name: ""
    },
    onLoad: function(t) {
        this.setData({
            userInfo: o.globalData.userInfo
        }), this.getGrouping();
    },
    onReady: function() {},
    onShow: function() {
        wx.setNavigationBarTitle({
            title: "输入姓名或昵称、选择地区"
        });
    },
    onHide: function() {},
    onUnload: function() {},
    onPullDownRefresh: function() {},
    onReachBottom: function() {},
    onShareAppMessage: function() {},
    inputChangeName: function(t) {
        console.log(t.detail.value), this.setData({
            realName: t.detail.value
        });
    },
    inputChangeMobile: function(t) {
        console.log(t.detail.value), this.setData({
            mobile: t.detail.value
        });
    },
    selectGroup: function(t) {
        if (0 != this.data.realName.trim().length) {
            this.setData({
                selectIdx: t.currentTarget.dataset.index,
                group_id: t.currentTarget.dataset.group_id,
                group_name: t.currentTarget.dataset.group_name
            });
            var o = this;
            wx.showModal({
                title: "提示",
                content: "选择分组后不能修改，你确定选择吗？",
                confirmText: "确定",
                cancelText: "再想想",
                success: function(t) {
                    t.confirm ? o.updateGrouping() : console.log("再想想");
                }
            });
        } else wx.showModal({
            title: "提示",
            content: "请输入您的真实姓名",
            confirmText: "确定",
            showCancel: !1,
            success: function(t) {
                t.confirm;
            }
        });
    },
    updateGrouping: function() {
        wx.showToast({
            title: "",
            icon: "loading",
            duration: 1e4
        });
        var o = this, e = wx.getStorageSync("openid") || "";
        console.log("openid:" + e), t.updateUserGroup(e, this.data.group_id, this.data.realName, this.data.mobile).then(function(t) {
            console.log("tom: updateGrouping() call updateUserGroup() ->", t), "0" == t.data.code ? (getApp().globalData.userInfo.group_name = o.data.group_name, 
            wx.navigateBack({
                delta: 1
            })) : wx.showToast({
                title: "选择分组错误",
                icon: "none",
                duration: 3e3
            });
        }).catch(function(t) {
            console.log("tom: updateGrouping() err ->", t);
        }).finally(function(t) {
            console.log("updateGrouping finally~");
        });
    },
    getGrouping: function() {
        wx.showToast({
            title: "",
            icon: "loading",
            duration: 1e4
        });
        var o = this;
        t.getGrouplist().then(function(t) {
            console.log("tom: getGrouping() ->", t);
            var e = t.data;
            o.setData({
                groupList: e
            });
        }).catch(function(t) {
            console.log("tom: getGroupingList() err ->", t);
        }).finally(function(t) {
            console.log("getGroupingList finally~"), wx.hideToast(), wx.stopPullDownRefresh();
        });
    }
});