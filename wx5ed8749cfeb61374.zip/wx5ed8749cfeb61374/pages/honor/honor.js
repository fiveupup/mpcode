var e, o = require("../../@babel/runtime/helpers/defineProperty"), n = require("../../utils/api"), a = require("../../utils/audio-util");

Page((o(e = {
    data: {
        userInfo: {},
        group_name: "",
        score: 0,
        Ranking: 0,
        win_game: 0,
        total_game: 0,
        level: 1,
        win_rate: 0,
        realname: "",
        mobile: "",
        showModal: !1,
        modalType: "",
        inputvalue: ""
    },
    onLoad: function(e) {
        this.setData({
            userInfo: getApp().globalData.userInfo
        }), this.getRating();
    },
    onReady: function() {},
    onShow: function() {
        wx.setNavigationBarTitle({
            title: "我的分数"
        }), a.play("我的荣誉");
    },
    onHide: function() {
        a.stop();
    },
    onUnload: function() {},
    onPullDownRefresh: function() {},
    onReachBottom: function() {},
    onShareAppMessage: function() {}
}, "onShareAppMessage", function(e) {
    return {
        title: "谁学富五车？比比看吧！",
        path: "/pages/index/index?currentClickId=0",
        success: function(e) {
            console.log("分享成功", e), wx.navigateBack({
                delta: 1
            });
        },
        fail: function(e) {
            console.log("分享失败", e);
        }
    };
}), o(e, "countWinRate", function(e, o) {
    return 0 == e || 0 == o ? 0 : Math.floor(100 * e / o);
}), o(e, "getRating", function() {
    wx.showToast({
        title: "",
        icon: "loading",
        duration: 1e4
    });
    var e = wx.getStorageSync("openid") || "";
    console.log("openid", e);
    var o = this;
    n.getRating(e).then(function(e) {
        console.log("tom: getRating() ->", e);
        var n = e.data;
        o.setData({
            group_name: n.group_name,
            score: n.score,
            Ranking: 0 == n.Ranking ? "无" : n.Ranking,
            win_game: n.win_game,
            total_game: n.total_game,
            level: getApp().countLevel(n.score),
            win_rate: o.countWinRate(n.win_game, n.total_game),
            realname: n.realname,
            mobile: n.mobile
        });
    }).catch(function(e) {
        console.log("tom: getRatingList() err ->", e);
    }).finally(function(e) {
        console.log("getRatingList finally~"), wx.hideToast(), wx.stopPullDownRefresh();
    });
}), o(e, "showDialogBtn", function(e) {
    console.log("user press show dialog.");
    var o = e.target.dataset.type;
    console.log("type=", o), null == o && (o = "mobile"), this.setData({
        showModal: !0,
        modalType: o
    });
}), o(e, "preventTouchMove", function() {}), o(e, "hideModal", function() {
    this.setData({
        showModal: !1
    });
}), o(e, "onCancel", function() {
    console.log("user press cancel."), this.hideModal();
}), o(e, "onConfirm", function() {
    console.log("user press OK.", this.data.modalType), this.hideModal(), wx.showToast({
        title: "",
        icon: "loading",
        duration: 1e4
    });
    var e = wx.getStorageSync("openid") || "", o = this.data.inputvalue;
    console.log(this.data.modalType), "realname" == this.data.modalType ? this.requestChangeRealname(e, o) : "mobile" == this.data.modalType && this.requestChangeMobile(e, o);
}), o(e, "inputChange", function(e) {
    console.log(e.detail.value), this.setData({
        inputvalue: e.detail.value
    });
}), o(e, "requestChangeRealname", function(e, o) {
    var a = this;
    n.changeRealname(e, o).then(function(e) {
        console.log("tony: changeRealname() ->", e);
        var n = e.data;
        0 == n.code ? a.setData({
            realname: o
        }) : console.log("tony: changeRealname()  code =", n.code);
    }).catch(function(e) {
        console.log("tony: changeRealname()  err ->", e);
    }).finally(function(e) {
        console.log("tony: changeRealname finally~"), wx.hideToast(), wx.stopPullDownRefresh();
    });
}), o(e, "requestChangeMobile", function(e, o) {
    var a = this;
    n.changeMobile(e, o).then(function(e) {
        console.log("tony: changeMobile() ->", e);
        var n = e.data;
        0 == n.code ? a.setData({
            mobile: o
        }) : console.log("tony: changeMobile()  code =", n.code);
    }).catch(function(e) {
        console.log("tony: changeMobile()  err ->", e);
    }).finally(function(e) {
        console.log("tony: changeMobile finally~"), wx.hideToast(), wx.stopPullDownRefresh();
    });
}), e));