var e = require("../../utils/websocket-util"), t = require("../../utils/util.js"), a = (getApp(), 
1500);

Page({
    data: {
        roomName: "",
        userInfo_me: "",
        userInfo_others: "",
        countdown: 10,
        question: "",
        hasClick: !1,
        localClick: !1,
        tunnelIdReplacing: 0,
        clickIndex: "",
        answerColor: "",
        scoreMyself: 0,
        status_users_others: {
            openid: "",
            userChoose: "",
            answerColor: ""
        },
        score_others: 0,
        game_over: !1,
        win: 2,
        sendNumber: 0
    },
    onLoad: function(e) {
        wx.showShareMenu({
            withShareTicket: !0
        }), this.setData({
            roomName: e.roomName,
            userInfo_me: wx.getStorageSync("user_me"),
            userInfo_others: wx.getStorageSync("user_others")
        }), console.log("userInfo_me :", this.data.userInfo_me), wx.removeStorageSync("user_me"), 
        wx.removeStorageSync("user_others"), this.startAnimate(), this.fightingReady(e.roomName);
    },
    onShareAppMessage: function(e) {
        return {
            title: "谁学富五车？比比看吧！",
            path: "/pages/entry/entry?currentClickId=0",
            success: function(e) {
                wx.redirectTo({
                    url: "../entry/entry"
                });
            }
        };
    },
    fightingReady: function(o) {
        var s, r, n, i = this;
        e.sendMsg({
            socketCmd: 300,
            socketAction: "ready_to_answer",
            data: {
                openid: this.data.userInfo_me.openid,
                roomName: this.data.roomName
            }
        }), wx.onSocketMessage(function(o) {
            var c = JSON.parse(o.data);
            switch (console.log("res", c), c.action) {
              case "getAnswer":
                i.setData({
                    hasClick: !0
                });
                break;

              case "runawayNotice":
                console.log("对手已逃跑"), t.showSuccess(c.msg), i.setData({
                    game_over: !0,
                    win: 1
                });
                break;

              case "question":
                console.log("收到题目");
                var u = c.data.question;
                console.log("res.data.choicePlayer1[0]", c.data.choicePlayer1[0]), console.log("my openid", i.data.userInfo_me.openid), 
                c.data.choicePlayer1[0] !== i.data.userInfo_me.openid ? (i.setData({
                    status_users_others: {
                        openid: c.data.choicePlayer1[0],
                        userChoose: c.data.choicePlayer1[1],
                        answerColor: c.data.choicePlayer1[2]
                    },
                    score_others: c.data.choicePlayer1[3],
                    animate_rightAnswer: "right"
                }), console.log("player1 ", i.data.status_users_others)) : (i.setData({
                    status_users_others: {
                        openid: c.data.choicePlayer2[0],
                        userChoose: c.data.choicePlayer2[1],
                        answerColor: c.data.choicePlayer2[2]
                    },
                    score_others: c.data.choicePlayer2[3],
                    animate_rightAnswer: "right"
                }), console.log("player2 ", i.data.status_users_others)), clearTimeout(s), s = Object.getOwnPropertyNames(u).length ? setTimeout(function() {
                    d(i);
                }, 2e3) : setTimeout(function() {
                    i.data.scoreMyself > i.data.score_others ? i.setData({
                        game_over: !0,
                        win: 1
                    }) : i.data.scoreMyself < i.data.score_others ? i.setData({
                        game_over: !0,
                        win: 0
                    }) : i.setData({
                        game_over: !0
                    });
                    var t = {
                        socketAction: "fightingResult",
                        data: {
                            openid: i.data.userInfo_me.openid,
                            fightingResult: i.data.win
                        }
                    };
                    e.sendMsg(t);
                }, 2e3);
                var d = function(e) {
                    e.setData({
                        question: u,
                        animate_showChoice: "",
                        countdown: 10,
                        localClick: !1,
                        hasClick: !1,
                        clickIndex: "",
                        answerColor: "",
                        status_users_others: {
                            openid: "",
                            userChoose: "",
                            answerColor: ""
                        },
                        sendNumber: 0,
                        animate_rightAnswer: ""
                    }), clearInterval(r);
                    var t = e.data.countdown;
                    setTimeout(function() {
                        e.setData({
                            animate_showChoice: "fadeIn"
                        }), r = setInterval(function() {
                            t--, e.setData({
                                countdown: t
                            }), 0 == t && clearInterval(r);
                        }, 1e3);
                    }, a), clearTimeout(n), n = setTimeout(function() {
                        e.data.localClick || e.data.hasClick || e.sendAnswer(e);
                    }, 11e3);
                };
                break;

              default:
                console.log("default action", c.data.action);
            }
        });
    },
    answer: function(e) {
        this.data.localClick || (e.currentTarget.dataset.right ? (this.setData({
            clickIndex: e.currentTarget.dataset.index,
            answerColor: "right"
        }), this.setData({
            scoreMyself: this.data.scoreMyself + 10 * this.data.countdown
        })) : this.setData({
            clickIndex: e.currentTarget.dataset.index,
            answerColor: "error"
        }), this.setData({
            localClick: !0
        }), this.sendAnswer(this));
    },
    sendAnswer: function(t) {
        if (!(t.data.sendNumber > 0)) {
            var a = {
                socketCmd: 500,
                socketAction: "answer",
                data: {
                    roomName: t.data.roomName,
                    choice: {
                        openid: t.data.userInfo_me.openid,
                        userChoose: t.data.clickIndex,
                        answerColor: t.data.answerColor,
                        scoreMyself: t.data.scoreMyself
                    }
                }
            };
            e.sendMsg(a);
            var o = t.data.sendNumber + 1;
            t.setData({
                sendNumber: o
            });
        }
    },
    continue_fighting: function() {
        wx.reLaunch({
            url: "../entry/entry"
        });
    },
    startAnimate: function() {
        var e = this;
        e.setData({
            zoomIn: "zoomIn"
        }), setTimeout(function() {
            e.setData({
                zoomOut: "zoomOut"
            });
        }, 1500);
    }
});