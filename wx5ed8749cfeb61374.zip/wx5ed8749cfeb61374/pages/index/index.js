var n = require("../../utils/api"), o = require("../../utils/audio-util"), e = getApp();

Page({
    data: {
        userInfo: {},
        group_name: "",
        realname: "",
        mobile: "",
        userdetail: "",
        score: 0,
        level: 1,
        announceSwitch: 0,
        announceContent: "",
        gameSwitch: 0,
        tryGetGameStatus: !0
    },
    onLoad: function() {
        console.log("onLoad app.globalData.userInfo", e.globalData.userInfo), e.globalData.userInfo.hasOwnProperty("nickName") && this.setData({
            userInfo: e.globalData.userInfo
        }), this.setData({
            group_name: wx.getStorageSync("group_name") || ""
        }), "" == (wx.getStorageSync("showReadme") || "") && wx.redirectTo({
            url: "../competitionExplan2/competitionExplan"
        });
    },
    onShow: function() {
        this.getAnnounce(), this.getGameStatus(), console.log("onshow app.globalData.userInfo", e.globalData.userInfo), 
        e.globalData.userInfo.hasOwnProperty("group_name") && this.setData({
            userInfo: e.globalData.userInfo
        }), this.getRating(), o.stop();
    },
    onShareAppMessage: function() {
        return {
            title: "谁学富五车？比比看吧！",
            path: "/pages/index/index?currentClickId=0",
            success: function(n) {
                console.log("分享成功", n);
            },
            fail: function(n) {
                console.log("分享失败", n);
            }
        };
    },
    open_challenge: function() {
        0 != this.data.gameSwitch ? this.getChallenge() : 1 == this.tryGetGameStatus ? wx.showToast({
            title: "正在获取比赛状态"
        }) : wx.showModal({
            title: "提示",
            content: "挑战还未开始，请先在训练场训练",
            showCancel: !1,
            confirmText: "知道了",
            success: function(n) {
                n.confirm;
            }
        });
    },
    open_readme: function() {
        wx.navigateTo({
            url: "../competitionExplan/competitionExplan"
        });
    },
    open_honor: function() {
        wx.navigateTo({
            url: "../honor/honor"
        });
    },
    open_ranking: function() {
        wx.navigateTo({
            url: "../ranking/ranking"
        });
    },
    open_group: function() {
        wx.navigateTo({
            url: "../grouping/grouping"
        });
    },
    open_training: function() {
        wx.navigateTo({
            url: "../trainingGround2/trainingGround"
        });
    },
    open_award: function() {
        wx.navigateTo({
            url: "../award/award"
        });
    },
    getRating: function() {
        var o = wx.getStorageSync("openid") || "";
        if ("" != o) {
            var t = this;
            n.getRating(o).then(function(n) {
                console.log("tom: getRating() ->", n);
                var o = n.data;
                e.globalData.userInfo.group_name = o.group_name, e.globalData.userInfo.score = o.score, 
                e.globalData.userInfo.level = getApp().countLevel(o.score), e.globalData.userInfo.realname = o.realname, 
                e.globalData.userInfo.mobile = o.realname, t.setData({
                    group_name: o.group_name,
                    score: o.score,
                    realname: o.realname,
                    mobile: o.mobile,
                    level: getApp().countLevel(o.score)
                }), wx.setStorageSync("group_name", o.group_name);
            }).catch(function(n) {
                console.log("tom: getRatingList() err ->", n);
            }).finally(function(n) {
                console.log("getRatingList finally~");
            });
        }
    },
    getAnnounce: function() {
        var o = this;
        n.getAnnounce().then(function(n) {
            console.log("tom: getAnnounce() ->", n);
            var e = JSON.parse(n.data);
            o.setData({
                announceSwitch: e.switch,
                announceContent: e.content
            });
        }).catch(function(n) {
            console.log("tom: getAnnounce() err ->", n);
        }).finally(function(n) {
            console.log("getAnnounce finally~");
        });
    },
    getGameStatus: function() {
        var o = this;
        n.getGameStatus().then(function(n) {
            console.log("tom: getGameStatus() ->", n);
            var e = JSON.parse(n.data);
            o.setData({
                gameSwitch: e.switch
            });
        }).catch(function(n) {
            console.log("tom: getGameStatus() err ->", n);
        }).finally(function(n) {
            console.log("getGameStatus finally~");
        });
    },
    getChallenge: function() {
        wx.showToast({
            title: "",
            icon: "loading",
            duration: 1e4
        });
        var o = this, e = wx.getStorageSync("openid") || "";
        console.log("openid:", e), n.getChallenge(e).then(function(n) {
            var e = n.data;
            console.log(e), 0 == e.code ? wx.navigateTo({
                url: "../trainingGround/trainingGround?challenge_id=" + e.challenge_id
            }) : -8 == e.code ? wx.showModal({
                title: "提示",
                content: e.msg,
                confirmText: "去选择",
                cancelText: "知道了",
                success: function(n) {
                    n.confirm && o.open_group();
                }
            }) : wx.showModal({
                title: "提示",
                content: e.msg,
                showCancel: !1,
                confirmText: "知道了",
                success: function(n) {
                    n.confirm;
                }
            });
        }).catch(function(n) {
            console.log("tom: getChallenge() err ->", n);
        }).finally(function(n) {
            console.log("getChallenge finally~"), wx.hideToast();
        });
    },
    open_company_name: function() {
        wx.navigateTo({
            url: "../about/about"
        });
    }
});