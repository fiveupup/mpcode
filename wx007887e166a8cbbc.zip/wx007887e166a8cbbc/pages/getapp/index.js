(wx["webpackJsonp"] = wx["webpackJsonp"] || []).push([ [ "pages/getapp/index" ], {
    /***/
    "./node_modules/babel-loader/lib/index.js??ruleSet[1].rules[5].use[0]!./src/pages/getapp/index.tsx": 
    /*!*********************************************************************************************************!*\
    !*** ./node_modules/babel-loader/lib/index.js??ruleSet[1].rules[5].use[0]!./src/pages/getapp/index.tsx ***!
    \*********************************************************************************************************/
    /***/
    function node_modulesBabelLoaderLibIndexJsRuleSet1Rules5Use0SrcPagesGetappIndexTsx(__unused_webpack_module, __webpack_exports__, __webpack_require__) {
        /* harmony export */
        __webpack_require__.d(__webpack_exports__, {
            /* harmony export */
            default: function _default() {
                /* binding */
                return Index;
            }
            /* harmony export */        });
        /* harmony import */        var _Users_Nix_Developer_DecisionTaro_node_modules_babel_runtime_helpers_esm_classCallCheck_js__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(
        /*! ./node_modules/@babel/runtime/helpers/esm/classCallCheck.js */
        "./node_modules/@babel/runtime/helpers/esm/classCallCheck.js");
        /* harmony import */        var _Users_Nix_Developer_DecisionTaro_node_modules_babel_runtime_helpers_esm_createClass_js__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(
        /*! ./node_modules/@babel/runtime/helpers/esm/createClass.js */
        "./node_modules/@babel/runtime/helpers/esm/createClass.js");
        /* harmony import */        var _Users_Nix_Developer_DecisionTaro_node_modules_babel_runtime_helpers_esm_inherits_js__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(
        /*! ./node_modules/@babel/runtime/helpers/esm/inherits.js */
        "./node_modules/@babel/runtime/helpers/esm/inherits.js");
        /* harmony import */        var _Users_Nix_Developer_DecisionTaro_node_modules_babel_runtime_helpers_esm_createSuper_js__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(
        /*! ./node_modules/@babel/runtime/helpers/esm/createSuper.js */
        "./node_modules/@babel/runtime/helpers/esm/createSuper.js");
        /* harmony import */        var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
        /*! react */
        "webpack/container/remote/react");
        /* harmony import */        var react__WEBPACK_IMPORTED_MODULE_0___default = /* */ __webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
        /* harmony import */        var _tarojs_components__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(
        /*! @tarojs/components */
        "./node_modules/@tarojs/plugin-platform-weapp/dist/components-react.js");
        /* harmony import */        var _components_cell_cell__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
        /*! ../../components/cell/cell */
        "./src/components/cell/cell.tsx");
        /* harmony import */        var _resources_common_appicon_png__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
        /*! ../../resources/common_appicon.png */
        "./src/resources/common_appicon.png");
        /* harmony import */        var _resources_purchase_weight_png__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
        /*! ../../resources/purchase_weight.png */
        "./src/resources/purchase_weight.png");
        /* harmony import */        var _resources_purchase_theme_png__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
        /*! ../../resources/purchase_theme.png */
        "./src/resources/purchase_theme.png");
        /* harmony import */        var _resources_purchase_tag_png__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
        /*! ../../resources/purchase_tag.png */
        "./src/resources/purchase_tag.png");
        /* harmony import */        var _resources_purchase_touch_png__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
        /*! ../../resources/purchase_touch.png */
        "./src/resources/purchase_touch.png");
        /* harmony import */        var _resources_purchase_number_png__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(
        /*! ../../resources/purchase_number.png */
        "./src/resources/purchase_number.png");
        /* harmony import */        var _resources_purchase_coin_png__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(
        /*! ../../resources/purchase_coin.png */
        "./src/resources/purchase_coin.png");
        /* harmony import */        var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(
        /*! react/jsx-runtime */
        "webpack/container/remote/react/jsx-runtime");
        /* harmony import */        var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9___default = /* */ __webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__);
        var Index = /* */ function(_Component) {
            (0, _Users_Nix_Developer_DecisionTaro_node_modules_babel_runtime_helpers_esm_inherits_js__WEBPACK_IMPORTED_MODULE_10__["default"])(Index, _Component);
            var _super = (0, _Users_Nix_Developer_DecisionTaro_node_modules_babel_runtime_helpers_esm_createSuper_js__WEBPACK_IMPORTED_MODULE_11__["default"])(Index);
            function Index() {
                (0, _Users_Nix_Developer_DecisionTaro_node_modules_babel_runtime_helpers_esm_classCallCheck_js__WEBPACK_IMPORTED_MODULE_12__["default"])(this, Index);
                return _super.apply(this, arguments);
            }
            (0, _Users_Nix_Developer_DecisionTaro_node_modules_babel_runtime_helpers_esm_createClass_js__WEBPACK_IMPORTED_MODULE_13__["default"])(Index, [ {
                key: "componentWillMount",
                value: function componentWillMount() {}
            }, {
                key: "componentDidMount",
                value: function componentDidMount() {}
            }, {
                key: "componentWillUnmount",
                value: function componentWillUnmount() {}
            }, {
                key: "componentDidShow",
                value: function componentDidShow() {}
            }, {
                key: "componentDidHide",
                value: function componentDidHide() {}
            }, {
                key: "render",
                value: function render() {
                    /* */
                    return (0, react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsx)(_tarojs_components__WEBPACK_IMPORTED_MODULE_14__.ScrollView, {
                        type: "list",
                        scrollY: true,
                        className: "index",
                        children: /* */ (0, react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsxs)(_tarojs_components__WEBPACK_IMPORTED_MODULE_14__.View, {
                            className: "container",
                            children: [ /* */ (0, react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsx)(_components_cell_cell__WEBPACK_IMPORTED_MODULE_1__.Cell, {
                                children: /* */ (0, react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsx)(_tarojs_components__WEBPACK_IMPORTED_MODULE_14__.Text, {
                                    className: "downloadHint",
                                    children: "在应用商店搜索「小决定」下载 app 体验更多功能"
                                })
                            }), /* */ (0, react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsxs)(_tarojs_components__WEBPACK_IMPORTED_MODULE_14__.View, {
                                className: "appContainer",
                                children: [ /* */ (0, react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsx)(_tarojs_components__WEBPACK_IMPORTED_MODULE_14__.Image, {
                                    className: "appIcon",
                                    src: _resources_common_appicon_png__WEBPACK_IMPORTED_MODULE_2__
                                }), /* */ (0, react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsxs)(_tarojs_components__WEBPACK_IMPORTED_MODULE_14__.View, {
                                    className: "appTextContainer",
                                    children: [ /* */ (0, react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsx)(_tarojs_components__WEBPACK_IMPORTED_MODULE_14__.Text, {
                                        className: "appTitle",
                                        children: "小决定 - 选择困难症克星"
                                    }), /* */ (0, react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsx)(_tarojs_components__WEBPACK_IMPORTED_MODULE_14__.Text, {
                                        className: "appDesc",
                                        children: "快乐做决定"
                                    }), /* */ (0, react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsx)(_tarojs_components__WEBPACK_IMPORTED_MODULE_14__.Text, {
                                        className: "appRating",
                                        children: "★★★★★ 9.5万"
                                    }) ]
                                }) ]
                            }), /* */ (0, react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsx)(_tarojs_components__WEBPACK_IMPORTED_MODULE_14__.Text, {
                                className: "featureHeader",
                                children: "App 独享功能"
                            }), /* */ (0, react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsx)(Feature, {
                                imageUrl: _resources_purchase_weight_png__WEBPACK_IMPORTED_MODULE_3__,
                                name: "权重",
                                desc: "控制选项被抽中的概率"
                            }), /* */ (0, react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsx)(Feature, {
                                imageUrl: _resources_purchase_theme_png__WEBPACK_IMPORTED_MODULE_4__,
                                name: "主题",
                                desc: "更多转盘配色"
                            }), /* */ (0, react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsx)(Feature, {
                                imageUrl: _resources_purchase_tag_png__WEBPACK_IMPORTED_MODULE_5__,
                                name: "标签",
                                desc: "为转盘添加标签来管理（仅限 iOS）"
                            }), /* */ (0, react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsx)(Feature, {
                                imageUrl: _resources_purchase_touch_png__WEBPACK_IMPORTED_MODULE_6__,
                                name: "指尖轮盘",
                                desc: "动动手指抽取赢家"
                            }), /* */ (0, react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsx)(Feature, {
                                imageUrl: _resources_purchase_number_png__WEBPACK_IMPORTED_MODULE_7__,
                                name: "生成随机数",
                                desc: "在指定范围内生成一个或多个随机数"
                            }), /* */ (0, react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsx)(Feature, {
                                imageUrl: _resources_purchase_coin_png__WEBPACK_IMPORTED_MODULE_8__,
                                name: "抛硬币",
                                desc: "抛硬币决胜负（仅限 iOS）"
                            }) ]
                        })
                    });
                }
            } ]);
            return Index;
        }(react__WEBPACK_IMPORTED_MODULE_0__.Component);
        function Feature(props) {
            /* */
            return (0, react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsxs)(_tarojs_components__WEBPACK_IMPORTED_MODULE_14__.View, {
                className: "feature",
                children: [ /* */ (0, react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsx)(_tarojs_components__WEBPACK_IMPORTED_MODULE_14__.Image, {
                    className: "featureIcon",
                    src: props.imageUrl
                }), /* */ (0, react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsxs)(_tarojs_components__WEBPACK_IMPORTED_MODULE_14__.View, {
                    className: "featureTextContainer",
                    children: [ /* */ (0, react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsx)(_tarojs_components__WEBPACK_IMPORTED_MODULE_14__.Text, {
                        className: "featureName",
                        children: props.name
                    }), /* */ (0, react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsx)(_tarojs_components__WEBPACK_IMPORTED_MODULE_14__.Text, {
                        className: "featureDesc",
                        children: props.desc
                    }) ]
                }) ]
            });
        }
        /***/    },
    /***/
    "./src/pages/getapp/index.tsx": 
    /*!************************************!*\
    !*** ./src/pages/getapp/index.tsx ***!
    \************************************/
    /***/
    function srcPagesGetappIndexTsx(__unused_webpack_module, __unused_webpack___webpack_exports__, __webpack_require__) {
        /* harmony import */
        var _tarojs_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
        /*! @tarojs/runtime */
        "webpack/container/remote/@tarojs/runtime");
        /* harmony import */        var _tarojs_runtime__WEBPACK_IMPORTED_MODULE_0___default = /* */ __webpack_require__.n(_tarojs_runtime__WEBPACK_IMPORTED_MODULE_0__);
        /* harmony import */        var _node_modules_babel_loader_lib_index_js_ruleSet_1_rules_5_use_0_index_tsx__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
        /*! ../../../node_modules/babel-loader/lib/index.js??ruleSet[1].rules[5].use[0]!./index.tsx */
        "./node_modules/babel-loader/lib/index.js??ruleSet[1].rules[5].use[0]!./src/pages/getapp/index.tsx");
        var config = {
            navigationBarTitleText: "下载 app"
        };
        var inst = Page((0, _tarojs_runtime__WEBPACK_IMPORTED_MODULE_0__.createPageConfig)(_node_modules_babel_loader_lib_index_js_ruleSet_1_rules_5_use_0_index_tsx__WEBPACK_IMPORTED_MODULE_1__["default"], "pages/getapp/index", {
            root: {
                cn: []
            }
        }, config || {}));
        /* unused harmony default export */        var __WEBPACK_DEFAULT_EXPORT__ = _node_modules_babel_loader_lib_index_js_ruleSet_1_rules_5_use_0_index_tsx__WEBPACK_IMPORTED_MODULE_1__["default"];
        /***/    },
    /***/
    "./src/resources/common_appicon.png": 
    /*!******************************************!*\
    !*** ./src/resources/common_appicon.png ***!
    \******************************************/
    /***/
    function srcResourcesCommon_appiconPng(module, __unused_webpack_exports, __webpack_require__) {
        module.exports = __webpack_require__.p + "resources/common_appicon.png";
        /***/    },
    /***/
    "./src/resources/purchase_coin.png": 
    /*!*****************************************!*\
    !*** ./src/resources/purchase_coin.png ***!
    \*****************************************/
    /***/
    function srcResourcesPurchase_coinPng(module) {
        module.exports = "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAEgAAABICAMAAABiM0N1AAAAflBMVEUAAAD/MFj/MFD/LVX/LVX/LVX/LVX/Llb/LlX/LVb/LVX/LFP/LVb/LFT/LlX/LVP/LFX/MFj/LVb/MFX/Llb/MFr/Llb/LlX/LVT/LFT/K1X/Llb/Llb/LlX/KFj/Llf/MFb/LVb/MFX/K1X/LFX/LVX/LlT/Llb/Llf/LVXMoXA0AAAAKXRSTlMAIBCfYL/v38+P35DfQN9QkECvMIAwf++ggDCPX5AgcFBQYGDPsHCgb6wp2xYAAALTSURBVHhe5Zhre9owDIUjX3KDEAKBFEqBde02/f8/uKdzPEfmYC5fq4/BvD5HQo5F9k2D3qtVWTAzF+WqOm+eo3RVzlHU+vywlm2gRCx6BKM5EXej1KsAPI1qpSls0Dwoxy7N/vhFPzbt0k5RlUpz6GNCMdFiZSasOmlvPfeUYQe3pJe7SOvcc2YCg1H5/uoaz1k0SfvFDRLNgRwUapZ0pzxnl92M3Ugq0Za+7j+zO8KMpAp+hDlpUosThH1Zfd1dHpvTY56RAGb0dAbN0Vh3dT9IFY5ESBAqJ22YO7RB40AaCLrMRadzf6Btrpmj24K6j+QppNwm/QQ0h4L+sIw6boneFS5wWijIcBw5RZLc4yZyZmHrDfrE3FtGSzL3+C1yZpCgBbny//KbizDS29otikq8Gu060Eg6QW/ecQtll//yG36QJVCdWeHlTTgVfnP1H0SF2Ex8VZj4gRRxNWmRo8KHAH+KrzRwM64N6jWZ3lIUjXArMeei11Cz1yPIrUetFKKsNpDkFkgQIgmWeRaUmUKiqjtBCLUSJJ0ChWTjaE4cwuBki/L7ZCL5+1OBu7YT5V/JzfCZvYMN2YofJG4RVVlLIyi0FaVaxEDVejzJPOg3AlnRXQRVhzIxhwREqlmmNxdJErU8eNDayYaHX+TUopOddfcF6raw/NbLlv2pwJtUxgK0rDiA/AtKxD6/4FBcj5jew5sFRZosQUFaPMJNacoJppEY/H5+CW8bGdT2mln3rVOLBKGH9SPXmjkQhK9NadCrFwRvFrwFoHwBOFtYyHCR4MMliIDhAzyggjlMus6ZoeSVjN1BX6k7JxVoFsMzHUgQ6on0LNb5WWMQHEhiTTfl8LBOTlBplApj/AJwAAmOou82fFrSHbNYYFXnjtyt/b0KFDzT4fd0OoYWANDUCgLJeR6Fy5BGYYM87AAmHe0la1g22VOxb5fhj6ilOWbfM/4CcHfk0vVtnQIAAAAASUVORK5CYII=";
        /***/    },
    /***/
    "./src/resources/purchase_number.png": 
    /*!*******************************************!*\
    !*** ./src/resources/purchase_number.png ***!
    \*******************************************/
    /***/
    function srcResourcesPurchase_numberPng(module) {
        module.exports = "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAEgAAABICAMAAABiM0N1AAAAeFBMVEUAAABgYOdgXOdfXeZeXOVgYN9eXeZeXOZgWOdeXORfXOZeXOZeXOdfXeZfXeZfW+VfXOVdXeRgWupfXedfXeVeW+dgXOZgXedcXOZgYOpdXeZfXOZdW+ZgXeRfXOZfXeZeXeZdXedeXOhhW+dgXeZeXOZgYOReXOaHuQwVAAAAJ3RSTlMAIEDfgBDf7yCQv6B/j++fz2Awn59fUGBQMHDPcGCvr+9gb19wzzAHrtJ+AAABm0lEQVR42u3WyXLCMBBFUUuy8IQn5ikh8/v/PwzuatwFxcJtpcjGd4UoOFggyURTU1PPzdYO6pqVvWNMjpG9mhtnhtHNTKAjku+hJYJa9ReEwBYMZaAyHynzMaiYxzmPlMk1HHmU0MhoEflWEh6BikYF6kmQ38YbmW96KOvyYJSQrNJTRO1zgMqNBhIHCa2JNaRPFSSr3fa/TeUqoo0KartpzBjKO2ZzeRDTwlVANLHKEMQveKHnCwAzDbSkt16hBHiNqHdcUkAt7ekeWtTXfXgCkAyBZGLOCCSd6RMGQTKxB9AHHRqDoQWAJnoA7fmUGATx+41A4rwByIev7JbXyj207pzGD4f4mxaIHbAzFNoBKC2VAMi2RpzCK3Z/DEn27Zwc1Xm0wX1WHA3EB7rk2MnUJ6RPOVzapey4mGv1ZzbPy0MiWw0lj6FYDX0Bjn7ICpAao4A4a/1/3tfCoYQGafi9/5tG5Rhojq78dnfN9f+PSlAZj38QmIm4AkGt5BIdAqJTkDMu0BHpjJHl7PTZ4gh1rrbR1NTU1N/0C++92PplUrd2AAAAAElFTkSuQmCC";
        /***/    },
    /***/
    "./src/resources/purchase_tag.png": 
    /*!****************************************!*\
    !*** ./src/resources/purchase_tag.png ***!
    \****************************************/
    /***/
    function srcResourcesPurchase_tagPng(module) {
        module.exports = "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAEgAAABICAMAAABiM0N1AAAAP1BMVEUAAAD/LVX/LVT/MFD/LlX/L1X/LVX/MFj/LFP/Llb/Llb/LVb/LVX/Llb/LFX/LlX/LVX/LFT/LVb/Llb/LVUB+9YIAAAAFHRSTlMAn6AQz5/vIJCAf4+/j5Dv34Cv3+SUfxUAAAEXSURBVHhe3dTLTsQwEAXRDh7szJuH//9bQVlQYgE1yl1Bre2jliV3/fNOff5aPz/mXKe2PAQxTygBhNKMJaBcAqofe0LKIKQUQkohpBRCSiGXHHLJIZcccsmhU+9LE0kgtspZZhKIrdJLJYdwRRLoyEGRBKr1fl9bqSQQqZRCSCmElEJIKYSUQkgphJRCSCmEFEJIxwxC6u0btOyVGKnvly4b9MLe2CuNuaW/0ANKJCaKpbfNOVQqPXPJJXfmqETCWe3vuMMLueROK5H2OS6545I7LrkTSOa45I5L7rjkjkviBJI7LrnjkjvkkjsuuUMuueNS6CBdRjVxVCKcTMLJJJxIwgl6/XJWcaxxO3wq77dRedXq7/UBB9RSuM/mjU4AAAAASUVORK5CYII=";
        /***/    },
    /***/
    "./src/resources/purchase_theme.png": 
    /*!******************************************!*\
    !*** ./src/resources/purchase_theme.png ***!
    \******************************************/
    /***/
    function srcResourcesPurchase_themePng(module) {
        module.exports = "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAEgAAABICAMAAABiM0N1AAAAkFBMVEUAAAA1x1k4x1gzx1kwv2A0x1g0x1o0x1lAz1Azxlk0x1gwz1A0x1o0x1w1x1o0xlo0yFk0yVg1yFk1x1o0xlo0xlk1x1kzxlk0yFk1yFo1yFkyx1o1xlo0yFk0yFk1x1g1yFk0xlo1ylozxlk0xVo1ylU1xls2xlk1xVo0xls0xlg2yVk0yFo0yFczyVk0x1k/7uYbAAAAL3RSTlMA3yDfEIB/vxCQQBCAQJ/Pz3/PYO9woFDvn49gz6+PYJCvMKCAMI9QMHCwX69wUOR/AzoAAAKQSURBVHhe5Zdbd9owEIQl2UZYxIZgwAmUAknT60X//9+1AcEcM7ogXjMPvHD8nZ1djbwWH1Rqs97OCvtfxUyvfzT3UZp1Ya+00J3KpIxHC+uX7nIstTYi2d1cDQHuQjXSpiVVspzPFrLT/ea7Opo1/YMetG2U6M4cFL0ci6HMSoK0VTHOxdZi7y++12QvynkO98BMQUpxpBEx7SRIUc7rOBUdHSWdOV98R6uwcjQBqnKk2YQ557kvPZy5e4pJX4nTgUN6RK1EaqhB8EVe5DujslYKJsmJ19iz14u19vILHXwtVZiCx0vxnojHq4pEeTLxNCjJ3RvG76Xyz9NwSQrGfF7K02GeX2dPu5KoIGeMvZSVtEXlOFRSB5BEQeSFRCVpkFEQeYnKXHlrASYvUZULHEo424mUOHd6kAYFZ6RE7paD5vZHzqc4gHPHj9ZHUJ0gcO6cGWRwewR9S0M4d+VpbA40ResT4tzZo/Afeo2hsDh3JUCg0lBInLs39AggGgqJc9cjIwDxUNJqMXCAeChpSQwczaahJIQ3xmQw/pfABZJeFX6KwYHseCjpDrnwU0QwlIzYoQsbCm1WfF9gFS0jRVc7CntBL+vbN0157gKapG+njGjZoss/qKadFU6R7XZBbpM7M3NwDJ+CJf2yXv2mU+KulTbAUYQIbpornFFvNFl6508NtiaW4c+tyoiAqoi5h9PTvXKK5qeU4U+MVcZ5Rf3LEKgTN6oOkurE+4BfDwF3G/9Knf6kaZV3ebEv2STZDEl/cGFkkbioV1x9OSRGKewK+SSruwvrLQeEWUOz9d9GCTE+ZNx89H3IqkWeVB0AKZErtbq7IEaRwbm4U2bIqsfifql+f5gW1tpib8TH1T982uhTl8Wg7AAAAABJRU5ErkJggg==";
        /***/    },
    /***/
    "./src/resources/purchase_touch.png": 
    /*!******************************************!*\
    !*** ./src/resources/purchase_touch.png ***!
    \******************************************/
    /***/
    function srcResourcesPurchase_touchPng(module, __unused_webpack_exports, __webpack_require__) {
        module.exports = __webpack_require__.p + "resources/purchase_touch.png";
        /***/    },
    /***/
    "./src/resources/purchase_weight.png": 
    /*!*******************************************!*\
    !*** ./src/resources/purchase_weight.png ***!
    \*******************************************/
    /***/
    function srcResourcesPurchase_weightPng(module) {
        module.exports = "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAEgAAABICAMAAABiM0N1AAAARVBMVEUAAAD/lwD/lgD/lQD/lAD/lQD/mgD/lwD/lgD/lgD/lgD/lQD/lwD/lQD/lQD/lQD/kwD/lQD/lAD/lQD/kwD/lQD/kwCKftCrAAAAF3RSTlMAQI/P7/8wIL+vX+9/n4AwgJCgf0BgkHEPbIMAAAEpSURBVHgB7daLSsNAEEbhaTLTSbrRJNr6/o+qZCzWJTnACFJgD9dF+FizUH555lqtU9erad+d5U/5YPdGl3wXtZ/KJe/Y70iaVDs5yLWCistRL/bVq+w3Wt2AjhXZbbYtXVx8KXE4HToAreHMoYa0knPwV+nt8f9etlNPzpvsF3dwiTwun3DEtuojOdkbgQPf6D2+ETv0auX71TTeJeHI1UKaXHwKx87gHDdY3QgO5KVy1MmBbhV0Y4ekxzspO5yPdm/wrBPN6/abvV4l70DNaU5z/t3hJUZOfomBw0sMnfQSI4eXGDrpJYYOLzFy0kuMHV5i4KSXGDu8xNjJ34gdXGJVHTm4xKoKObzEaggcXGJVCzq4xKo+VJf0EuN4iaWDJcbxEmu1nrdPdWEbsP0h+QUAAAAASUVORK5CYII=";
        /***/    }
}, 
/******/
function(__webpack_require__) {
    // webpackRuntimeModules
    /******/
    var __webpack_exec__ = function __webpack_exec__(moduleId) {
        return __webpack_require__(__webpack_require__.s = moduleId);
    };
    /******/    __webpack_require__.O(0, [ "taro", "vendors", "common" ], function() {
        return __webpack_exec__("./src/pages/getapp/index.tsx");
    });
    /******/    var __webpack_exports__ = __webpack_require__.O();
    /******/} ]); //# sourceMappingURL=index.js.map