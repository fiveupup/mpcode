(wx["webpackJsonp"] = wx["webpackJsonp"] || []).push([ [ "pages/decisioncenter/index" ], {
    /***/
    "./node_modules/babel-loader/lib/index.js??ruleSet[1].rules[5].use[0]!./src/pages/decisioncenter/index.tsx": 
    /*!*****************************************************************************************************************!*\
    !*** ./node_modules/babel-loader/lib/index.js??ruleSet[1].rules[5].use[0]!./src/pages/decisioncenter/index.tsx ***!
    \*****************************************************************************************************************/
    /***/
    function node_modulesBabelLoaderLibIndexJsRuleSet1Rules5Use0SrcPagesDecisioncenterIndexTsx(__unused_webpack_module, __webpack_exports__, __webpack_require__) {
        /* harmony export */
        __webpack_require__.d(__webpack_exports__, {
            /* harmony export */
            default: function _default() {
                /* export default binding */
                return __WEBPACK_DEFAULT_EXPORT__;
            }
            /* harmony export */        });
        /* harmony import */        var _tarojs_components__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(
        /*! @tarojs/components */
        "./node_modules/@tarojs/plugin-platform-weapp/dist/components-react.js");
        /* harmony import */        var _components_cell_cell__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
        /*! ../../components/cell/cell */
        "./src/components/cell/cell.tsx");
        /* harmony import */        var _models_decision__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
        /*! ../../models/decision */
        "./src/models/decision.ts");
        /* harmony import */        var _tarojs_taro__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
        /*! @tarojs/taro */
        "webpack/container/remote/@tarojs/taro");
        /* harmony import */        var _tarojs_taro__WEBPACK_IMPORTED_MODULE_2___default = /* */ __webpack_require__.n(_tarojs_taro__WEBPACK_IMPORTED_MODULE_2__);
        /* harmony import */        var _decision_templates__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
        /*! ./decision_templates */
        "./src/pages/decisioncenter/decision_templates.ts");
        /* harmony import */        var _state_hooks__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
        /*! ../../state/hooks */
        "./src/state/hooks.ts");
        /* harmony import */        var _state_reducers_decision__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
        /*! ../../state/reducers/decision */
        "./src/state/reducers/decision.ts");
        /* harmony import */        var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
        /*! react/jsx-runtime */
        "webpack/container/remote/react/jsx-runtime");
        /* harmony import */        var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_6___default = /* */ __webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_6__);
        function CategoryHeader(_ref) {
            var name = _ref.name;
            return /* */ (0, react_jsx_runtime__WEBPACK_IMPORTED_MODULE_6__.jsx)(_tarojs_components__WEBPACK_IMPORTED_MODULE_7__.View, {
                className: "categoryName",
                children: /* */ (0, react_jsx_runtime__WEBPACK_IMPORTED_MODULE_6__.jsx)(_tarojs_components__WEBPACK_IMPORTED_MODULE_7__.Text, {
                    children: name
                })
            });
        }
        /* harmony default export */        function __WEBPACK_DEFAULT_EXPORT__() {
            var dispatch = (0, _state_hooks__WEBPACK_IMPORTED_MODULE_4__.useAppDispatch)();
            function onSave(decision) {
                if (decision === undefined) {
                    return;
                }
                // Change UUIDs
                                var d = _models_decision__WEBPACK_IMPORTED_MODULE_1__.Decision.init(decision.toJSON());
                dispatch((0, _state_reducers_decision__WEBPACK_IMPORTED_MODULE_5__.updateDecision)(d));
                _tarojs_taro__WEBPACK_IMPORTED_MODULE_2___default().showToast({
                    title: "保存成功"
                });
            }
            var templates = _decision_templates__WEBPACK_IMPORTED_MODULE_3__["default"];
            var rows = [];
            var adInserted = false;
            while (templates.length > 0) {
                var category = templates.shift();
                if (category === undefined) {
                    continue;
                }
                rows.push(/* */ (0, react_jsx_runtime__WEBPACK_IMPORTED_MODULE_6__.jsx)(CategoryHeader, {
                    name: (category === null || category === void 0 ? void 0 : category.name) || ""
                }));
                var decisions = category === null || category === void 0 ? void 0 : category.decisions;
                if (decisions !== undefined) {
                    var _loop = function _loop() {
                        var first = decisions.shift();
                        var second = decisions.shift();
                        rows.push(/* */ (0, react_jsx_runtime__WEBPACK_IMPORTED_MODULE_6__.jsx)(_components_cell_cell__WEBPACK_IMPORTED_MODULE_0__.DecisionCardMiniRow, {
                            decision1: first,
                            decision2: second,
                            onSave1: function onSave1() {
                                onSave(first);
                            },
                            onSave2: function onSave2() {
                                onSave(second);
                            }
                        }));
                    };
                    while (decisions.length > 0) {
                        _loop();
                    }
                }
                if (!adInserted) {
                    adInserted = true;
                    rows.push(/* */ (0, react_jsx_runtime__WEBPACK_IMPORTED_MODULE_6__.jsx)(_components_cell_cell__WEBPACK_IMPORTED_MODULE_0__.CustomAdCell, {
                        unitId: "adunit-fc01a8e414879a55",
                        onError: function onError() {}
                    }));
                }
            }
            return /* */ (0, react_jsx_runtime__WEBPACK_IMPORTED_MODULE_6__.jsx)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_6__.Fragment, {
                children: /* */ (0, react_jsx_runtime__WEBPACK_IMPORTED_MODULE_6__.jsx)(_tarojs_components__WEBPACK_IMPORTED_MODULE_7__.ScrollView, {
                    children: rows
                })
            });
        }
        /***/    },
    /***/
    "./src/pages/decisioncenter/decision_templates.ts": 
    /*!********************************************************!*\
    !*** ./src/pages/decisioncenter/decision_templates.ts ***!
    \********************************************************/
    /***/
    function srcPagesDecisioncenterDecision_templatesTs(__unused_webpack_module, __webpack_exports__, __webpack_require__) {
        /* harmony import */
        var _models_decision__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
        /*! ../../models/decision */
        "./src/models/decision.ts");
        var decisionTemplates = [ {
            name: "真心话 & 大冒险",
            decisions: [ new _models_decision__WEBPACK_IMPORTED_MODULE_0__.Decision("🍺", "真心话 & 大冒险", [ new _models_decision__WEBPACK_IMPORTED_MODULE_0__.Option("真心话"), new _models_decision__WEBPACK_IMPORTED_MODULE_0__.Option("大冒险"), new _models_decision__WEBPACK_IMPORTED_MODULE_0__.Option("Pass") ]), new _models_decision__WEBPACK_IMPORTED_MODULE_0__.Decision("❤️", "真心话", [ new _models_decision__WEBPACK_IMPORTED_MODULE_0__.Option("你最讨厌自己身上哪一点？"), new _models_decision__WEBPACK_IMPORTED_MODULE_0__.Option("最喜欢在坐哪位异性？"), new _models_decision__WEBPACK_IMPORTED_MODULE_0__.Option("最反感别人的什么行为？"), new _models_decision__WEBPACK_IMPORTED_MODULE_0__.Option("做过最丢脸的事是什么？"), new _models_decision__WEBPACK_IMPORTED_MODULE_0__.Option("你的初吻年龄？"), new _models_decision__WEBPACK_IMPORTED_MODULE_0__.Option("写过多少封情书？"), new _models_decision__WEBPACK_IMPORTED_MODULE_0__.Option("最近浮现在你脑海的邪恶念头是什么？"), new _models_decision__WEBPACK_IMPORTED_MODULE_0__.Option("你哭的最惨的一次是为了什么？"), new _models_decision__WEBPACK_IMPORTED_MODULE_0__.Option("理想型男/女朋友的3个条件"), new _models_decision__WEBPACK_IMPORTED_MODULE_0__.Option("说出一件最社死的事情") ]), new _models_decision__WEBPACK_IMPORTED_MODULE_0__.Decision("🍺", "大冒险", [ new _models_decision__WEBPACK_IMPORTED_MODULE_0__.Option("找一个陌生人邀请他自拍，并且对方准备自拍的时候跑走"), new _models_decision__WEBPACK_IMPORTED_MODULE_0__.Option("从现在开始说出 10 句假话"), new _models_decision__WEBPACK_IMPORTED_MODULE_0__.Option("打给一位异性，邀请他明天一起吃晚餐"), new _models_decision__WEBPACK_IMPORTED_MODULE_0__.Option("给喜欢的人发一张自拍照"), new _models_decision__WEBPACK_IMPORTED_MODULE_0__.Option("当个复读机 15 分钟，重复在场每一位说过的话"), new _models_decision__WEBPACK_IMPORTED_MODULE_0__.Option("选一位在场的异性，十指紧扣、深情对望，对着他唱《两只老虎》"), new _models_decision__WEBPACK_IMPORTED_MODULE_0__.Option("抱一位异性 18 秒"), new _models_decision__WEBPACK_IMPORTED_MODULE_0__.Option("哭腔朗诵「恭喜你发财」"), new _models_decision__WEBPACK_IMPORTED_MODULE_0__.Option("打给妈妈说「我/我女朋友怀孕了」"), new _models_decision__WEBPACK_IMPORTED_MODULE_0__.Option("模仿脑白金广告，边唱边跳") ]) ]
        }, {
            name: "关于爱情",
            decisions: [ new _models_decision__WEBPACK_IMPORTED_MODULE_0__.Decision("😘", "怎样原谅男朋友？", [ new _models_decision__WEBPACK_IMPORTED_MODULE_0__.Option("写 1000 个我爱你"), new _models_decision__WEBPACK_IMPORTED_MODULE_0__.Option("小 CK"), new _models_decision__WEBPACK_IMPORTED_MODULE_0__.Option("跪搓衣板"), new _models_decision__WEBPACK_IMPORTED_MODULE_0__.Option("巴宝莉 93"), new _models_decision__WEBPACK_IMPORTED_MODULE_0__.Option("阿玛尼红管 201"), new _models_decision__WEBPACK_IMPORTED_MODULE_0__.Option("Colourpop 眼影"), new _models_decision__WEBPACK_IMPORTED_MODULE_0__.Option("带我吃大餐"), new _models_decision__WEBPACK_IMPORTED_MODULE_0__.Option("TF80"), new _models_decision__WEBPACK_IMPORTED_MODULE_0__.Option("带我去美甲"), new _models_decision__WEBPACK_IMPORTED_MODULE_0__.Option("一顿火锅"), new _models_decision__WEBPACK_IMPORTED_MODULE_0__.Option("夸我 35 个词不重样"), new _models_decision__WEBPACK_IMPORTED_MODULE_0__.Option("无条件原谅") ]), new _models_decision__WEBPACK_IMPORTED_MODULE_0__.Decision("❤️", "TA 爱我吗？", [ new _models_decision__WEBPACK_IMPORTED_MODULE_0__.Option("爱❤️"), new _models_decision__WEBPACK_IMPORTED_MODULE_0__.Option("不爱💔") ]), new _models_decision__WEBPACK_IMPORTED_MODULE_0__.Decision("🎁", "送女朋友什么礼物？", [ new _models_decision__WEBPACK_IMPORTED_MODULE_0__.Option("包包"), new _models_decision__WEBPACK_IMPORTED_MODULE_0__.Option("花"), new _models_decision__WEBPACK_IMPORTED_MODULE_0__.Option("小裙子"), new _models_decision__WEBPACK_IMPORTED_MODULE_0__.Option("鞋子"), new _models_decision__WEBPACK_IMPORTED_MODULE_0__.Option("唇膏"), new _models_decision__WEBPACK_IMPORTED_MODULE_0__.Option("iPhone"), new _models_decision__WEBPACK_IMPORTED_MODULE_0__.Option("吊坠"), new _models_decision__WEBPACK_IMPORTED_MODULE_0__.Option("Dyson") ]), new _models_decision__WEBPACK_IMPORTED_MODULE_0__.Decision("🎁", "男朋友的礼物", [ new _models_decision__WEBPACK_IMPORTED_MODULE_0__.Option("Switch"), new _models_decision__WEBPACK_IMPORTED_MODULE_0__.Option("AirPods"), new _models_decision__WEBPACK_IMPORTED_MODULE_0__.Option("机械键盘"), new _models_decision__WEBPACK_IMPORTED_MODULE_0__.Option("Apple Watch"), new _models_decision__WEBPACK_IMPORTED_MODULE_0__.Option("电动牙刷"), new _models_decision__WEBPACK_IMPORTED_MODULE_0__.Option("照相机"), new _models_decision__WEBPACK_IMPORTED_MODULE_0__.Option("三年高考五年模拟") ]), new _models_decision__WEBPACK_IMPORTED_MODULE_0__.Decision("🧹", "谁来做家务？", [ new _models_decision__WEBPACK_IMPORTED_MODULE_0__.Option("老公"), new _models_decision__WEBPACK_IMPORTED_MODULE_0__.Option("老婆") ]) ]
        }, {
            name: "吃喝玩乐",
            decisions: [ new _models_decision__WEBPACK_IMPORTED_MODULE_0__.Decision("✈️", "放假去哪里玩？", [ new _models_decision__WEBPACK_IMPORTED_MODULE_0__.Option("杭州"), new _models_decision__WEBPACK_IMPORTED_MODULE_0__.Option("苏州"), new _models_decision__WEBPACK_IMPORTED_MODULE_0__.Option("南京"), new _models_decision__WEBPACK_IMPORTED_MODULE_0__.Option("上海"), new _models_decision__WEBPACK_IMPORTED_MODULE_0__.Option("北京"), new _models_decision__WEBPACK_IMPORTED_MODULE_0__.Option("长沙"), new _models_decision__WEBPACK_IMPORTED_MODULE_0__.Option("西安"), new _models_decision__WEBPACK_IMPORTED_MODULE_0__.Option("三亚"), new _models_decision__WEBPACK_IMPORTED_MODULE_0__.Option("丽江"), new _models_decision__WEBPACK_IMPORTED_MODULE_0__.Option("黄山") ]), new _models_decision__WEBPACK_IMPORTED_MODULE_0__.Decision("🍜", "聚餐吃什么？", [ new _models_decision__WEBPACK_IMPORTED_MODULE_0__.Option("海底捞"), new _models_decision__WEBPACK_IMPORTED_MODULE_0__.Option("日料"), new _models_decision__WEBPACK_IMPORTED_MODULE_0__.Option("海鲜"), new _models_decision__WEBPACK_IMPORTED_MODULE_0__.Option("烤鱼"), new _models_decision__WEBPACK_IMPORTED_MODULE_0__.Option("拉面"), new _models_decision__WEBPACK_IMPORTED_MODULE_0__.Option("麻辣烫") ]), new _models_decision__WEBPACK_IMPORTED_MODULE_0__.Decision("🥣", "做什么泥？", [ new _models_decision__WEBPACK_IMPORTED_MODULE_0__.Option("泡沫球"), new _models_decision__WEBPACK_IMPORTED_MODULE_0__.Option("胶水"), new _models_decision__WEBPACK_IMPORTED_MODULE_0__.Option("闪粉"), new _models_decision__WEBPACK_IMPORTED_MODULE_0__.Option("绿色"), new _models_decision__WEBPACK_IMPORTED_MODULE_0__.Option("紫色"), new _models_decision__WEBPACK_IMPORTED_MODULE_0__.Option("橙色"), new _models_decision__WEBPACK_IMPORTED_MODULE_0__.Option("洗面奶"), new _models_decision__WEBPACK_IMPORTED_MODULE_0__.Option("沐浴露"), new _models_decision__WEBPACK_IMPORTED_MODULE_0__.Option("牙膏"), new _models_decision__WEBPACK_IMPORTED_MODULE_0__.Option("卸妆水"), new _models_decision__WEBPACK_IMPORTED_MODULE_0__.Option("水"), new _models_decision__WEBPACK_IMPORTED_MODULE_0__.Option("搅拌棒"), new _models_decision__WEBPACK_IMPORTED_MODULE_0__.Option("BB 霜") ]) ]
        }, {
            name: "游戏",
            decisions: [ new _models_decision__WEBPACK_IMPORTED_MODULE_0__.Decision("🧙", "第五人格人物", [ new _models_decision__WEBPACK_IMPORTED_MODULE_0__.Option("祭祀"), new _models_decision__WEBPACK_IMPORTED_MODULE_0__.Option("牛仔"), new _models_decision__WEBPACK_IMPORTED_MODULE_0__.Option("盲女"), new _models_decision__WEBPACK_IMPORTED_MODULE_0__.Option("红蝶"), new _models_decision__WEBPACK_IMPORTED_MODULE_0__.Option("园丁"), new _models_decision__WEBPACK_IMPORTED_MODULE_0__.Option("医生"), new _models_decision__WEBPACK_IMPORTED_MODULE_0__.Option("律师"), new _models_decision__WEBPACK_IMPORTED_MODULE_0__.Option("慈善家"), new _models_decision__WEBPACK_IMPORTED_MODULE_0__.Option("冒险家"), new _models_decision__WEBPACK_IMPORTED_MODULE_0__.Option("空军"), new _models_decision__WEBPACK_IMPORTED_MODULE_0__.Option("前锋"), new _models_decision__WEBPACK_IMPORTED_MODULE_0__.Option("佣兵"), new _models_decision__WEBPACK_IMPORTED_MODULE_0__.Option("调香师"), new _models_decision__WEBPACK_IMPORTED_MODULE_0__.Option("厂长"), new _models_decision__WEBPACK_IMPORTED_MODULE_0__.Option("蜘蛛"), new _models_decision__WEBPACK_IMPORTED_MODULE_0__.Option("杰克"), new _models_decision__WEBPACK_IMPORTED_MODULE_0__.Option("鹿头"), new _models_decision__WEBPACK_IMPORTED_MODULE_0__.Option("黄衣之王"), new _models_decision__WEBPACK_IMPORTED_MODULE_0__.Option("幸运儿"), new _models_decision__WEBPACK_IMPORTED_MODULE_0__.Option("小丑"), new _models_decision__WEBPACK_IMPORTED_MODULE_0__.Option("魔术师"), new _models_decision__WEBPACK_IMPORTED_MODULE_0__.Option("机械师"), new _models_decision__WEBPACK_IMPORTED_MODULE_0__.Option("宿魂之伞"), new _models_decision__WEBPACK_IMPORTED_MODULE_0__.Option("摄影师"), new _models_decision__WEBPACK_IMPORTED_MODULE_0__.Option("调香师"), new _models_decision__WEBPACK_IMPORTED_MODULE_0__.Option("舞者") ]), new _models_decision__WEBPACK_IMPORTED_MODULE_0__.Decision("🧙‍♂️", "凹凸世界角色", [ new _models_decision__WEBPACK_IMPORTED_MODULE_0__.Option("金"), new _models_decision__WEBPACK_IMPORTED_MODULE_0__.Option("格瑞"), new _models_decision__WEBPACK_IMPORTED_MODULE_0__.Option("卡米尔"), new _models_decision__WEBPACK_IMPORTED_MODULE_0__.Option("帕洛斯"), new _models_decision__WEBPACK_IMPORTED_MODULE_0__.Option("紫堂幻"), new _models_decision__WEBPACK_IMPORTED_MODULE_0__.Option("凯莉"), new _models_decision__WEBPACK_IMPORTED_MODULE_0__.Option("佩利"), new _models_decision__WEBPACK_IMPORTED_MODULE_0__.Option("艾比"), new _models_decision__WEBPACK_IMPORTED_MODULE_0__.Option("丹尼尔"), new _models_decision__WEBPACK_IMPORTED_MODULE_0__.Option("黑洞"), new _models_decision__WEBPACK_IMPORTED_MODULE_0__.Option("埃米"), new _models_decision__WEBPACK_IMPORTED_MODULE_0__.Option("鬼狐天冲"), new _models_decision__WEBPACK_IMPORTED_MODULE_0__.Option("嘉德罗斯"), new _models_decision__WEBPACK_IMPORTED_MODULE_0__.Option("蒙特祖玛"), new _models_decision__WEBPACK_IMPORTED_MODULE_0__.Option("莱娜"), new _models_decision__WEBPACK_IMPORTED_MODULE_0__.Option("银爵"), new _models_decision__WEBPACK_IMPORTED_MODULE_0__.Option("雷德"), new _models_decision__WEBPACK_IMPORTED_MODULE_0__.Option("雷狮"), new _models_decision__WEBPACK_IMPORTED_MODULE_0__.Option("维德"), new _models_decision__WEBPACK_IMPORTED_MODULE_0__.Option("安特"), new _models_decision__WEBPACK_IMPORTED_MODULE_0__.Option("安莉洁"), new _models_decision__WEBPACK_IMPORTED_MODULE_0__.Option("安迷修") ]) ]
        }, {
            name: "图一乐",
            decisions: [ new _models_decision__WEBPACK_IMPORTED_MODULE_0__.Decision("🤩", "你的男爱豆", [ new _models_decision__WEBPACK_IMPORTED_MODULE_0__.Option("杨洋"), new _models_decision__WEBPACK_IMPORTED_MODULE_0__.Option("范丞丞"), new _models_decision__WEBPACK_IMPORTED_MODULE_0__.Option("蔡徐坤"), new _models_decision__WEBPACK_IMPORTED_MODULE_0__.Option("王源"), new _models_decision__WEBPACK_IMPORTED_MODULE_0__.Option("王俊凯"), new _models_decision__WEBPACK_IMPORTED_MODULE_0__.Option("易洋千玺"), new _models_decision__WEBPACK_IMPORTED_MODULE_0__.Option("朱正廷"), new _models_decision__WEBPACK_IMPORTED_MODULE_0__.Option("王琳凯"), new _models_decision__WEBPACK_IMPORTED_MODULE_0__.Option("王子异"), new _models_decision__WEBPACK_IMPORTED_MODULE_0__.Option("尤长靖"), new _models_decision__WEBPACK_IMPORTED_MODULE_0__.Option("鹿晗"), new _models_decision__WEBPACK_IMPORTED_MODULE_0__.Option("朱一龙") ]), new _models_decision__WEBPACK_IMPORTED_MODULE_0__.Decision("🎓", "考哪个大学？", [ new _models_decision__WEBPACK_IMPORTED_MODULE_0__.Option("清华"), new _models_decision__WEBPACK_IMPORTED_MODULE_0__.Option("北大"), new _models_decision__WEBPACK_IMPORTED_MODULE_0__.Option("上交"), new _models_decision__WEBPACK_IMPORTED_MODULE_0__.Option("复旦"), new _models_decision__WEBPACK_IMPORTED_MODULE_0__.Option("蓝翔") ]), new _models_decision__WEBPACK_IMPORTED_MODULE_0__.Decision("🐔", "你的爱好？", [ new _models_decision__WEBPACK_IMPORTED_MODULE_0__.Option("唱"), new _models_decision__WEBPACK_IMPORTED_MODULE_0__.Option("跳"), new _models_decision__WEBPACK_IMPORTED_MODULE_0__.Option("Rap"), new _models_decision__WEBPACK_IMPORTED_MODULE_0__.Option("篮球") ]) ]
        } ];
        /* harmony default export */        __webpack_exports__["default"] = decisionTemplates;
        /***/    },
    /***/
    "./src/pages/decisioncenter/index.tsx": 
    /*!********************************************!*\
    !*** ./src/pages/decisioncenter/index.tsx ***!
    \********************************************/
    /***/
    function srcPagesDecisioncenterIndexTsx(__unused_webpack_module, __unused_webpack___webpack_exports__, __webpack_require__) {
        /* harmony import */
        var _tarojs_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
        /*! @tarojs/runtime */
        "webpack/container/remote/@tarojs/runtime");
        /* harmony import */        var _tarojs_runtime__WEBPACK_IMPORTED_MODULE_0___default = /* */ __webpack_require__.n(_tarojs_runtime__WEBPACK_IMPORTED_MODULE_0__);
        /* harmony import */        var _node_modules_babel_loader_lib_index_js_ruleSet_1_rules_5_use_0_index_tsx__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
        /*! ../../../node_modules/babel-loader/lib/index.js??ruleSet[1].rules[5].use[0]!./index.tsx */
        "./node_modules/babel-loader/lib/index.js??ruleSet[1].rules[5].use[0]!./src/pages/decisioncenter/index.tsx");
        var config = {
            navigationBarTitleText: "决定中心"
        };
        var inst = Page((0, _tarojs_runtime__WEBPACK_IMPORTED_MODULE_0__.createPageConfig)(_node_modules_babel_loader_lib_index_js_ruleSet_1_rules_5_use_0_index_tsx__WEBPACK_IMPORTED_MODULE_1__["default"], "pages/decisioncenter/index", {
            root: {
                cn: []
            }
        }, config || {}));
        /* unused harmony default export */        var __WEBPACK_DEFAULT_EXPORT__ = _node_modules_babel_loader_lib_index_js_ruleSet_1_rules_5_use_0_index_tsx__WEBPACK_IMPORTED_MODULE_1__["default"];
        /***/    }
}, 
/******/
function(__webpack_require__) {
    // webpackRuntimeModules
    /******/
    var __webpack_exec__ = function __webpack_exec__(moduleId) {
        return __webpack_require__(__webpack_require__.s = moduleId);
    };
    /******/    __webpack_require__.O(0, [ "taro", "vendors", "common" ], function() {
        return __webpack_exec__("./src/pages/decisioncenter/index.tsx");
    });
    /******/    var __webpack_exports__ = __webpack_require__.O();
    /******/} ]); //# sourceMappingURL=index.js.map