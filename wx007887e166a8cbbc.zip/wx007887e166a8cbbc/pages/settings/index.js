(wx["webpackJsonp"] = wx["webpackJsonp"] || []).push([ [ "pages/settings/index" ], {
    /***/
    "./node_modules/babel-loader/lib/index.js??ruleSet[1].rules[5].use[0]!./src/pages/settings/index.tsx": 
    /*!***********************************************************************************************************!*\
    !*** ./node_modules/babel-loader/lib/index.js??ruleSet[1].rules[5].use[0]!./src/pages/settings/index.tsx ***!
    \***********************************************************************************************************/
    /***/
    function node_modulesBabelLoaderLibIndexJsRuleSet1Rules5Use0SrcPagesSettingsIndexTsx(__unused_webpack_module, __webpack_exports__, __webpack_require__) {
        /* harmony export */
        __webpack_require__.d(__webpack_exports__, {
            /* harmony export */
            default: function _default() {
                /* export default binding */
                return __WEBPACK_DEFAULT_EXPORT__;
            }
            /* harmony export */        });
        /* harmony import */        var _tarojs_components__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(
        /*! @tarojs/components */
        "./node_modules/@tarojs/plugin-platform-weapp/dist/components-react.js");
        /* harmony import */        var _tarojs_taro__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
        /*! @tarojs/taro */
        "webpack/container/remote/@tarojs/taro");
        /* harmony import */        var _tarojs_taro__WEBPACK_IMPORTED_MODULE_0___default = /* */ __webpack_require__.n(_tarojs_taro__WEBPACK_IMPORTED_MODULE_0__);
        /* harmony import */        var _components_cell_cell__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
        /*! ../../components/cell/cell */
        "./src/components/cell/cell.tsx");
        /* harmony import */        var _components_stepper_stepper__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
        /*! ../../components/stepper/stepper */
        "./src/components/stepper/stepper.tsx");
        /* harmony import */        var _state_hooks__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
        /*! ../../state/hooks */
        "./src/state/hooks.ts");
        /* harmony import */        var _state_reducers_settings__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
        /*! ../../state/reducers/settings */
        "./src/state/reducers/settings.ts");
        /* harmony import */        var _resources_settings_sound_png__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
        /*! ../../resources/settings_sound.png */
        "./src/resources/settings_sound.png");
        /* harmony import */        var _resources_settings_haptic_png__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
        /*! ../../resources/settings_haptic.png */
        "./src/resources/settings_haptic.png");
        /* harmony import */        var _resources_settings_appicon_png__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(
        /*! ../../resources/settings_appicon.png */
        "./src/resources/settings_appicon.png");
        /* harmony import */        var _resources_settings_share_png__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(
        /*! ../../resources/settings_share.png */
        "./src/resources/settings_share.png");
        /* harmony import */        var _resources_settings_feedback_png__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(
        /*! ../../resources/settings_feedback.png */
        "./src/resources/settings_feedback.png");
        /* harmony import */        var _resources_common_duration_png__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(
        /*! ../../resources/common_duration.png */
        "./src/resources/common_duration.png");
        /* harmony import */        var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(
        /*! react/jsx-runtime */
        "webpack/container/remote/react/jsx-runtime");
        /* harmony import */        var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_11___default = /* */ __webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_11__);
        /* harmony default export */        function __WEBPACK_DEFAULT_EXPORT__() {
            var dispatch = (0, _state_hooks__WEBPACK_IMPORTED_MODULE_3__.useAppDispatch)();
            (0, _tarojs_taro__WEBPACK_IMPORTED_MODULE_0__.useShareAppMessage)(function() {
                return {
                    title: "推荐超好玩的「小决定」给你，快试试吧",
                    path: "/pages/wheel/index",
                    imageUrl: "/resources/share_banner.png"
                };
            });
            (0, _tarojs_taro__WEBPACK_IMPORTED_MODULE_0__.useShareTimeline)(function() {
                return {
                    title: "小决定 - 选择困难症克星"
                };
            });
            function onSoundSwitchChange(event) {
                var enabled = event.detail.value;
                console.log("[settings] onSoundSwitchChange", enabled);
                dispatch((0, _state_reducers_settings__WEBPACK_IMPORTED_MODULE_4__.setSoundEnabled)(enabled));
            }
            function onHapticSwitchChange(event) {
                var enabled = event.detail.value;
                console.log("[settings page] onHapticSwitchChange", enabled);
                dispatch((0, _state_reducers_settings__WEBPACK_IMPORTED_MODULE_4__.setHapticEnabled)(enabled));
            }
            function onDurationChange(duration) {
                console.log("[settings page] Update spin duration", duration);
                dispatch((0, _state_reducers_settings__WEBPACK_IMPORTED_MODULE_4__.setWheelSpinDuration)(duration));
            }
            function onGetApp() {
                console.log("onGetApp");
                _tarojs_taro__WEBPACK_IMPORTED_MODULE_0___default().navigateTo({
                    url: "/pages/getapp/index"
                });
            }
            var isSoundEnabled = (0, _state_hooks__WEBPACK_IMPORTED_MODULE_3__.useAppSelector)(_state_reducers_settings__WEBPACK_IMPORTED_MODULE_4__.selectIsSoundEnabled);
            var isHapticEnabled = (0, _state_hooks__WEBPACK_IMPORTED_MODULE_3__.useAppSelector)(_state_reducers_settings__WEBPACK_IMPORTED_MODULE_4__.selectIsHapticEnabled);
            var spinDuration = (0, _state_hooks__WEBPACK_IMPORTED_MODULE_3__.useAppSelector)(_state_reducers_settings__WEBPACK_IMPORTED_MODULE_4__.selectWheelSpinDuration);
            console.log("[settings] sound:", isSoundEnabled, "haptic:", isHapticEnabled);
            return /* */ (0, react_jsx_runtime__WEBPACK_IMPORTED_MODULE_11__.jsxs)(_tarojs_components__WEBPACK_IMPORTED_MODULE_12__.ScrollView, {
                type: "list",
                scrollY: true,
                className: "index",
                children: [ /* */ (0, react_jsx_runtime__WEBPACK_IMPORTED_MODULE_11__.jsx)(_components_cell_cell__WEBPACK_IMPORTED_MODULE_1__.SectionHeader, {
                    title: "通用"
                }), /* */ (0, react_jsx_runtime__WEBPACK_IMPORTED_MODULE_11__.jsxs)(_components_cell_cell__WEBPACK_IMPORTED_MODULE_1__.Cell, {
                    children: [ /* */ (0, react_jsx_runtime__WEBPACK_IMPORTED_MODULE_11__.jsx)(_tarojs_components__WEBPACK_IMPORTED_MODULE_12__.Image, {
                        className: "cellIcon",
                        src: _resources_settings_sound_png__WEBPACK_IMPORTED_MODULE_5__
                    }), /* */ (0, react_jsx_runtime__WEBPACK_IMPORTED_MODULE_11__.jsx)(_tarojs_components__WEBPACK_IMPORTED_MODULE_12__.Text, {
                        children: "声音"
                    }), /* */ (0, react_jsx_runtime__WEBPACK_IMPORTED_MODULE_11__.jsx)(_tarojs_components__WEBPACK_IMPORTED_MODULE_12__.Switch, {
                        checked: isSoundEnabled,
                        onChange: onSoundSwitchChange
                    }) ]
                }), /* */ (0, react_jsx_runtime__WEBPACK_IMPORTED_MODULE_11__.jsxs)(_components_cell_cell__WEBPACK_IMPORTED_MODULE_1__.Cell, {
                    children: [ /* */ (0, react_jsx_runtime__WEBPACK_IMPORTED_MODULE_11__.jsx)(_tarojs_components__WEBPACK_IMPORTED_MODULE_12__.Image, {
                        className: "cellIcon",
                        src: _resources_settings_haptic_png__WEBPACK_IMPORTED_MODULE_6__
                    }), /* */ (0, react_jsx_runtime__WEBPACK_IMPORTED_MODULE_11__.jsx)(_tarojs_components__WEBPACK_IMPORTED_MODULE_12__.Text, {
                        children: "震动"
                    }), /* */ (0, react_jsx_runtime__WEBPACK_IMPORTED_MODULE_11__.jsx)(_tarojs_components__WEBPACK_IMPORTED_MODULE_12__.Switch, {
                        checked: isHapticEnabled,
                        onChange: onHapticSwitchChange
                    }) ]
                }), /* */ (0, react_jsx_runtime__WEBPACK_IMPORTED_MODULE_11__.jsxs)(_components_cell_cell__WEBPACK_IMPORTED_MODULE_1__.Cell, {
                    children: [ /* */ (0, react_jsx_runtime__WEBPACK_IMPORTED_MODULE_11__.jsx)(_tarojs_components__WEBPACK_IMPORTED_MODULE_12__.Image, {
                        className: "cellIcon",
                        src: _resources_common_duration_png__WEBPACK_IMPORTED_MODULE_10__
                    }), /* */ (0, react_jsx_runtime__WEBPACK_IMPORTED_MODULE_11__.jsx)(_tarojs_components__WEBPACK_IMPORTED_MODULE_12__.Text, {
                        children: "转盘旋转时长"
                    }), /* */ (0, react_jsx_runtime__WEBPACK_IMPORTED_MODULE_11__.jsx)(_components_stepper_stepper__WEBPACK_IMPORTED_MODULE_2__.Stepper, {
                        value: spinDuration,
                        unit: "s",
                        minValue: 2,
                        maxValue: 30,
                        onChange: onDurationChange
                    }) ]
                }), /* */ (0, react_jsx_runtime__WEBPACK_IMPORTED_MODULE_11__.jsx)(_components_cell_cell__WEBPACK_IMPORTED_MODULE_1__.SectionHeader, {
                    title: "其他"
                }), /* */ (0, react_jsx_runtime__WEBPACK_IMPORTED_MODULE_11__.jsxs)(_components_cell_cell__WEBPACK_IMPORTED_MODULE_1__.Cell, {
                    onTap: onGetApp,
                    children: [ /* */ (0, react_jsx_runtime__WEBPACK_IMPORTED_MODULE_11__.jsx)(_tarojs_components__WEBPACK_IMPORTED_MODULE_12__.Image, {
                        className: "cellIcon",
                        src: _resources_settings_appicon_png__WEBPACK_IMPORTED_MODULE_7__
                    }), /* */ (0, react_jsx_runtime__WEBPACK_IMPORTED_MODULE_11__.jsx)(_tarojs_components__WEBPACK_IMPORTED_MODULE_12__.Text, {
                        className: "actionTitle",
                        children: "升级到小决定 app"
                    }) ]
                }), /* */ (0, react_jsx_runtime__WEBPACK_IMPORTED_MODULE_11__.jsxs)(_components_cell_cell__WEBPACK_IMPORTED_MODULE_1__.Cell, {
                    children: [ /* */ (0, react_jsx_runtime__WEBPACK_IMPORTED_MODULE_11__.jsx)(_tarojs_components__WEBPACK_IMPORTED_MODULE_12__.Button, {
                        className: "customButton",
                        openType: "share"
                    }), /* */ (0, react_jsx_runtime__WEBPACK_IMPORTED_MODULE_11__.jsx)(_tarojs_components__WEBPACK_IMPORTED_MODULE_12__.Image, {
                        className: "cellIcon",
                        src: _resources_settings_share_png__WEBPACK_IMPORTED_MODULE_8__
                    }), /* */ (0, react_jsx_runtime__WEBPACK_IMPORTED_MODULE_11__.jsx)(_tarojs_components__WEBPACK_IMPORTED_MODULE_12__.Text, {
                        children: "分享小决定给朋友"
                    }) ]
                }), /* */ (0, react_jsx_runtime__WEBPACK_IMPORTED_MODULE_11__.jsxs)(_components_cell_cell__WEBPACK_IMPORTED_MODULE_1__.Cell, {
                    children: [ /* */ (0, react_jsx_runtime__WEBPACK_IMPORTED_MODULE_11__.jsx)(_tarojs_components__WEBPACK_IMPORTED_MODULE_12__.Button, {
                        className: "customButton",
                        openType: "feedback"
                    }), /* */ (0, react_jsx_runtime__WEBPACK_IMPORTED_MODULE_11__.jsx)(_tarojs_components__WEBPACK_IMPORTED_MODULE_12__.Image, {
                        className: "cellIcon",
                        src: _resources_settings_feedback_png__WEBPACK_IMPORTED_MODULE_9__
                    }), /* */ (0, react_jsx_runtime__WEBPACK_IMPORTED_MODULE_11__.jsx)(_tarojs_components__WEBPACK_IMPORTED_MODULE_12__.Text, {
                        children: "反馈与建议"
                    }) ]
                }), /* */ (0, react_jsx_runtime__WEBPACK_IMPORTED_MODULE_11__.jsx)(_tarojs_components__WEBPACK_IMPORTED_MODULE_12__.Text, {
                    className: "footNote",
                    children: "Tiny Decisions made with ❤️ by Nix"
                }) ]
            });
        }
        /***/    },
    /***/
    "./src/components/stepper/stepper.tsx": 
    /*!********************************************!*\
    !*** ./src/components/stepper/stepper.tsx ***!
    \********************************************/
    /***/
    function srcComponentsStepperStepperTsx(__unused_webpack_module, __webpack_exports__, __webpack_require__) {
        /* harmony export */
        __webpack_require__.d(__webpack_exports__, {
            /* harmony export */
            Stepper: function Stepper() {
                /* binding */
                return _Stepper;
            }
            /* harmony export */        });
        /* harmony import */        var _tarojs_components__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
        /*! @tarojs/components */
        "./node_modules/@tarojs/plugin-platform-weapp/dist/components-react.js");
        /* harmony import */        var _resources_stepper_plus_png__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
        /*! ./resources/stepper_plus.png */
        "./src/components/stepper/resources/stepper_plus.png");
        /* harmony import */        var _resources_stepper_minus_png__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
        /*! ./resources/stepper_minus.png */
        "./src/components/stepper/resources/stepper_minus.png");
        /* harmony import */        var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
        /*! react/jsx-runtime */
        "webpack/container/remote/react/jsx-runtime");
        /* harmony import */        var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2___default = /* */ __webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__);
        function _Stepper(_ref) {
            var _ref$value = _ref.value, value = _ref$value === void 0 ? 3 : _ref$value, _ref$unit = _ref.unit, unit = _ref$unit === void 0 ? "" : _ref$unit, minValue = _ref.minValue, maxValue = _ref.maxValue, onChange = _ref.onChange;
            function onReduce() {
                console.log("[stepper] Reduce");
                if (value > minValue) {
                    onChange(value - 1);
                }
            }
            function onAdd() {
                console.log("[stepper] Add");
                if (value < maxValue) {
                    onChange(value + 1);
                }
            }
            return /* */ (0, react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsxs)(_tarojs_components__WEBPACK_IMPORTED_MODULE_3__.View, {
                className: "stepperContainer",
                children: [ /* */ (0, react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx)(_tarojs_components__WEBPACK_IMPORTED_MODULE_3__.Button, {
                    className: "stepperButton",
                    onTap: onReduce,
                    children: /* */ (0, react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx)(_tarojs_components__WEBPACK_IMPORTED_MODULE_3__.Image, {
                        src: _resources_stepper_minus_png__WEBPACK_IMPORTED_MODULE_1__
                    })
                }), /* */ (0, react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx)(_tarojs_components__WEBPACK_IMPORTED_MODULE_3__.Text, {
                    children: "".concat(value).concat(unit)
                }), /* */ (0, react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx)(_tarojs_components__WEBPACK_IMPORTED_MODULE_3__.Button, {
                    className: "stepperButton",
                    onTap: onAdd,
                    children: /* */ (0, react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx)(_tarojs_components__WEBPACK_IMPORTED_MODULE_3__.Image, {
                        src: _resources_stepper_plus_png__WEBPACK_IMPORTED_MODULE_0__
                    })
                }) ]
            });
        }
        /***/    },
    /***/
    "./src/pages/settings/index.tsx": 
    /*!**************************************!*\
    !*** ./src/pages/settings/index.tsx ***!
    \**************************************/
    /***/
    function srcPagesSettingsIndexTsx(__unused_webpack_module, __unused_webpack___webpack_exports__, __webpack_require__) {
        /* harmony import */
        var _tarojs_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
        /*! @tarojs/runtime */
        "webpack/container/remote/@tarojs/runtime");
        /* harmony import */        var _tarojs_runtime__WEBPACK_IMPORTED_MODULE_0___default = /* */ __webpack_require__.n(_tarojs_runtime__WEBPACK_IMPORTED_MODULE_0__);
        /* harmony import */        var _node_modules_babel_loader_lib_index_js_ruleSet_1_rules_5_use_0_index_tsx__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
        /*! ../../../node_modules/babel-loader/lib/index.js??ruleSet[1].rules[5].use[0]!./index.tsx */
        "./node_modules/babel-loader/lib/index.js??ruleSet[1].rules[5].use[0]!./src/pages/settings/index.tsx");
        var config = {
            navigationBarTitleText: "设置",
            enableShareAppMessage: true
        };
        _node_modules_babel_loader_lib_index_js_ruleSet_1_rules_5_use_0_index_tsx__WEBPACK_IMPORTED_MODULE_1__["default"].enableShareTimeline = true;
        _node_modules_babel_loader_lib_index_js_ruleSet_1_rules_5_use_0_index_tsx__WEBPACK_IMPORTED_MODULE_1__["default"].enableShareAppMessage = true;
        var inst = Page((0, _tarojs_runtime__WEBPACK_IMPORTED_MODULE_0__.createPageConfig)(_node_modules_babel_loader_lib_index_js_ruleSet_1_rules_5_use_0_index_tsx__WEBPACK_IMPORTED_MODULE_1__["default"], "pages/settings/index", {
            root: {
                cn: []
            }
        }, config || {}));
        /* unused harmony default export */        var __WEBPACK_DEFAULT_EXPORT__ = _node_modules_babel_loader_lib_index_js_ruleSet_1_rules_5_use_0_index_tsx__WEBPACK_IMPORTED_MODULE_1__["default"];
        /***/    },
    /***/
    "./src/components/stepper/resources/stepper_minus.png": 
    /*!************************************************************!*\
    !*** ./src/components/stepper/resources/stepper_minus.png ***!
    \************************************************************/
    /***/
    function srcComponentsStepperResourcesStepper_minusPng(module) {
        module.exports = "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAADwAAAA8CAYAAAA6/NlyAAAAZUlEQVR42u3UOxGAMBRFwScBCUhAArIYoMAROEICEh6JBj6TYnfm1MktkgAAAAAAAOAfW3ax5thS9U5fje1jySvmzMY6S0O8bs29HtBoh8GPzTmUzubG1mc2Ze/TAgAAAAAA4G03fDUJAwD8A3QAAAAASUVORK5CYII=";
        /***/    },
    /***/
    "./src/components/stepper/resources/stepper_plus.png": 
    /*!***********************************************************!*\
    !*** ./src/components/stepper/resources/stepper_plus.png ***!
    \***********************************************************/
    /***/
    function srcComponentsStepperResourcesStepper_plusPng(module) {
        module.exports = "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAADwAAAA8BAMAAADI0sRBAAAALVBMVEUAAAAAev8Aev8AgP8AgP8Aev8Aev8Aev8AfP8Ae/8Aef8Ae/8AfP8Aev8AeP9qO9jvAAAAD3RSTlMAMK8gEN//70BwcO+vsCCGH5GSAAAAVUlEQVR4AWOgHIwCIWV8sixh6Q54pDnS0hqGgfSoNEsHBHSmpa2AMpHj3ToNAwQiSR/DlM4lXloUU3ofdqfNgDlt+EfJqDTLtlQHBjzgkSIDxWAUAAAlkV84Y87XTAAAAABJRU5ErkJggg==";
        /***/    },
    /***/
    "./src/resources/common_duration.png": 
    /*!*******************************************!*\
    !*** ./src/resources/common_duration.png ***!
    \*******************************************/
    /***/
    function srcResourcesCommon_durationPng(module) {
        module.exports = "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAEgAAABICAMAAABiM0N1AAAAP1BMVEUAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAACzJYIvAAAAFHRSTlMAIN8Q75CfYI+/MFCAoEDPf69fsEOjdwoAAAIsSURBVHhe5ZjbkuMgDES5CIPBi51Z/v9bd2soVWL3GCG/Tj+6yIlasiIU80tlY3rtrv2X21+p5GeUmqhd5JaijuVgCrCsBrO0gaZRPgHgEapQE+WiMpw1xPxtxNYS1k9U8kJ29g9KvBz28YPlhvayYwptTDnJ/pkiZWJOAAyiKN+eYY6rQ/sOSXgAw0H5MHTnmbNdAAdRuqC21rV7g+K6R3yO8Ni6EnIicrq+E0d3xwsmCH11dX4HoDu6mls6J5hZkAk/mrOd47wEwuJYCAgejkGmdtACAfEzAQTmrBCQDPIE9XEckAzCytGbUzggJch3I/XibDVakFl7b16cRT0onr3lftbrQf6ck4LOEDTyFk/vQ9CC8KMv7GMEjZL013TtXEQtiNO7n4pm9SDuLTdz1OCURuMKEKD0IGqAUoCgMxGFIEw2viuIwmRz+bMRpzROoHoq/4t7VkLhoCn8QmKLyCi6bZEITTtEETRtOc8ib+ZQAX5GMnOJkySjiDboWXdxuhq11svQqOxNKQsXCR5QSi3dGQ4o/yigBR8lI0uYz72wrT4JSL7WoORrjQlqc+kjILxZtGOWc9xtEqV1fc1xvvDuygpIkjnBoPzept0dbVQc6yZ3MZ+EBSnT1C5W+QvJymvWYoVwYDkCd2OUf6/xDjhAmlpFdzu1izErldqX4xwTU3inkxRdE0UFAOI8RGE4ehSWQUbdGKTNGqUKsihU80i5hPcfUSFa8zv1D+SuZEK9lDU1AAAAAElFTkSuQmCC";
        /***/    },
    /***/
    "./src/resources/settings_appicon.png": 
    /*!********************************************!*\
    !*** ./src/resources/settings_appicon.png ***!
    \********************************************/
    /***/
    function srcResourcesSettings_appiconPng(module) {
        module.exports = "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAEgAAABICAMAAABiM0N1AAAAUVBMVEUAAAAAev8AgP8Aev8AfP8AgP8Aev8AeP8Ae/8Ae/8Ae/8Aev8Aev8Ae/8Ae/8Aev8Aev8Aef8Ae/8Aev8Aev8Aef8AfP8Aev8Aev8AfP8Aev/hjG5vAAAAGnRSTlMA3xBgQCCQII+/78+Az3B/73CfrzCgr5+wb0n0RUUAAAIfSURBVHhe5ZbblpwgFETlJgpqT7o7N/7/Q7MmkpPDKqZLXuZl6lFwy0X2Yfo6CcfdpEKS8uMILzFuLZeT3YcYb8pQTB9llzKcxSInZATwmAAcMq2rJCuctPkwkVg/S//czm6pGOOni3H/UEvztHJmwfPYuZL0tyt96wN+f+ujtjoLGNDc54Ty9uyT6picgPaTbPsc0zbhFq3SVYEx9/e2R7/Nn2/GCjrUVCG3s+8Hy5Saxh8vVuhZYG9wvX82S+S7HIOHAedmmvFZZpXVISj+Bb1V0NmPWAW9ge8KiFtlsaOgkLk3OAitgiQOQquANwiIWAW8wUFoFfQGB6FV0BsEBFYh3uCgFawC3qAgtIq9rbWqgjcYyGmrBCNnVnuDgdAqct6M1d4gILSKK5JNe4OA0Cq7sgh4g4GEK0345HNBSe2wUmQ+NTUwNaMUvhWJU5LOl0DfZZO0T4w+JL8ugQ49+lhJJurhukug2MrC7aWsm20EEz/30E6uNSGa0w2K7Qb3gEGxTV5XMax0joIksyqtUHjnkXK0iz0Wb6cp+FtqfcJB8vtg5IfiIE7KcfgSMQMEKh0FSWmVYOFFkHhj9KKFVhFvYKJ77KmUZO7Hi6tfBm8MBa0i3hiPkTIH3hiKWAW9wYNWycQbNGIV4g0Mtwp6gwetgt7gQav0vUGCVkFv8KBVxkncKugNDLEKeoMHrYKonQCIVVTi8e4NErHK18gfalHANTF/vycAAAAASUVORK5CYII=";
        /***/    },
    /***/
    "./src/resources/settings_feedback.png": 
    /*!*********************************************!*\
    !*** ./src/resources/settings_feedback.png ***!
    \*********************************************/
    /***/
    function srcResourcesSettings_feedbackPng(module) {
        module.exports = "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAEgAAABICAMAAABiM0N1AAAAP1BMVEUAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAACzJYIvAAAAFXRSTlMAQJ/f/89QIL8w74AQcGBvf4+gkK9zXJEDAAABWElEQVR4Ae3Xi4qDMBCF4RPnmKQxtq7t+z/rUrOLHUhDEgsU8ONO4WdwpqD4SqeTGYTNxsFCc56dxOHFJbBbuLzME3hA2GcSHuKRwPIgg2TgZopoFGduBiQjn2Z0mNLmkHAT0SFyo0Lokgld0cFmQhwcGjnPXIhhRpNboA7pP06tiyezoWRBnbiQxRDFoIIRlkN1Dz3+UNEh2Ye6osgG/vOZEGapGsp5vqw5F4JbWb4EvXN6h3wIuErxEtTOxQLvQmooLsWd3yNKIcDJ20sw+qdCKJnUJeR2HiagIgQ3Zi7BqodcF0oPXQ2ld47akL6EJcZlH+fh0BBSQ2X+iS0huDu1tPO2UOIkM05HKF2C2nl3CO6hdt4XSsw6kjIY4GBIO0MdzhDO0KdfRoVPEzrc+DQiWbmZIxrFRb+wGx5k8cfzEPn8Z9bhD7+dE3byDppdRzaTweAbnU6/a2od/dsW2vgAAAAASUVORK5CYII=";
        /***/    },
    /***/
    "./src/resources/settings_haptic.png": 
    /*!*******************************************!*\
    !*** ./src/resources/settings_haptic.png ***!
    \*******************************************/
    /***/
    function srcResourcesSettings_hapticPng(module) {
        module.exports = "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAEgAAABICAMAAABiM0N1AAAALVBMVEUAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAADBoCg+AAAADnRSTlMAn6DvgN+Qj8+/EGAgfxZylcEAAADhSURBVHja7ddLDsMgDEVRiEn4Jd7/cqsOqlfJFNkZFLXyHSbiDEIsQfA8b2ntqjyodKNz7vyh/TRBcKTUDE7nSckAlRlUDRBPM0NB9HvQRZTtkFybn2/jPSi+/xDEkPQQHCZAkLQQHECJIekhOHy8HmyQ9BCcLQQhqSDpSCnpoQxnIJEeoqET4l0oDh0+VJDca/n99RB2aORYICllOAZI7jW+vxqC5LPms+aztmLW4OghSIASHAMECbN2EKVghrD2fw5aKw6jdeYUA5RmUDdAbXaF+O6lBvUyYmpqwfO8lT0AL/Q+l7XbhdIAAAAASUVORK5CYII=";
        /***/    },
    /***/
    "./src/resources/settings_share.png": 
    /*!******************************************!*\
    !*** ./src/resources/settings_share.png ***!
    \******************************************/
    /***/
    function srcResourcesSettings_sharePng(module) {
        module.exports = "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAEgAAABICAMAAABiM0N1AAAAP1BMVEUAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAACzJYIvAAAAFHRSTlMAIO/fv3CAn0AQfzCgb89gr1CQjxc76zsAAAFwSURBVHhe7Zdhi8MwCIY1JmnS7rru5v//rQeXcpbKQaKDwejzTcERTfb6FoSLOkdiDjEheMDIf0wIZr4CHwgJjMx8YjaehxWmM2FgRbDMadprcwFYbtyIMAy2SsI9pBZXGCW1Qjx1mmGU2B6PJLKxt3aARRKltQqj8C86874fardUJLG012AcdpbEZBt2odNTRtOfpD65oR4k2uVjWgDKHPZgqKuV/yOgSRQ9MlJn6SpsfCJ3C/uDpOq7QlJS2yfs5ZCJ5bfP2yGDncJenxLSA3YwxcBMMddeYd8Ow8nVIexCRIewC2txCbvMyifscuUvEXYqny7sl7DLJQXU72qQqoTd6hOjFvYGJb8bEykaIbHG1l9W5STBXKEbLexHfab7gPPXwo6rZFYccP5a2O90LFQLwjg72mzOX3fsdf6F3CZCjcrr/KU/v/NHupy/4loQCV60IFroXxDTOz/XITllRMgdzt+4IGzoBWFHL4jP5wd521lJb/EkfQAAAABJRU5ErkJggg==";
        /***/    },
    /***/
    "./src/resources/settings_sound.png": 
    /*!******************************************!*\
    !*** ./src/resources/settings_sound.png ***!
    \******************************************/
    /***/
    function srcResourcesSettings_soundPng(module) {
        module.exports = "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAEgAAABICAMAAABiM0N1AAAARVBMVEUAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAADc6ur3AAAAFnRSTlMA3yAQ70CQn2CAz3CPMH+/oLBvUK9fUUUX0gAAAchJREFUeF7tl9FuwyAMRQ0YCAlJu3Xj/z913RLVwollaDftJfctsnTiXC6GwJ/o1KlT1ncB3IKYjwqxFDN3vHYsd6V9YSp3YTPJY/kW7iuXn4KxbZz3smlf+lgLowNdLhYZ5LdKbrNHBsGwlW5t9sggSGsJnWqPAoJAH6fYo4CcWYu2xZ4rgUTDY4M9EzDQECdLpO01TrMHPTBQrEPosLDgL1j2Gi0w0BoeQx0kFvxcDnR1wEEDN8WuZQ+bjvqZAHageat5tuUCbNpj0FclFkJDQ6B+PrCnLvEQDg+76yjxdpIDBmIhvDzqYwWWUkclHkJbtxj6QWBoKWgh354AJUoALeTYC6JQ1kkynSBaJ2TL1gyS0f8K4p+mg3Szx9fNDhQcxn0tkNOzgRz0LULCrG3akW3amzRGjBVAmY0RK4wRIvlD0MIH20DP0qhdOIjeXwY2amO1o7myOPyDOPwhHPVk9OMoVnHkSmQU9+haH5BWObO9IaP4kR0m6geidouwD1Im0F4zNSTJhc5rjaykgzJrSDRKAS1sEyhGiaBPFk7FKPV6HKBFSQZdCgunZlTPL4RuVBCaReI0GIWYhFu2meE3ZHswp06d+gIb1WH5Z472sgAAAABJRU5ErkJggg==";
        /***/    }
}, 
/******/
function(__webpack_require__) {
    // webpackRuntimeModules
    /******/
    var __webpack_exec__ = function __webpack_exec__(moduleId) {
        return __webpack_require__(__webpack_require__.s = moduleId);
    };
    /******/    __webpack_require__.O(0, [ "taro", "common" ], function() {
        return __webpack_exec__("./src/pages/settings/index.tsx");
    });
    /******/    var __webpack_exports__ = __webpack_require__.O();
    /******/} ]); //# sourceMappingURL=index.js.map