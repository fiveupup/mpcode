(wx["webpackJsonp"] = wx["webpackJsonp"] || []).push([ [ "common" ], {
    /***/
    "./src/components/button/button.tsx": 
    /*!******************************************!*\
    !*** ./src/components/button/button.tsx ***!
    \******************************************/
    /***/
    function srcComponentsButtonButtonTsx(__unused_webpack_module, __webpack_exports__, __webpack_require__) {
        /* harmony export */
        __webpack_require__.d(__webpack_exports__, {
            /* harmony export */
            ActionButton: function ActionButton() {
                /* binding */
                return _ActionButton;
            },
            /* harmony export */
            OptionButton: function OptionButton() {
                /* binding */
                return _OptionButton;
            }
            /* harmony export */        });
        /* unused harmony export CloseButton */
        /* harmony import */        var _tarojs_components__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
        /*! @tarojs/components */
        "./node_modules/@tarojs/plugin-platform-weapp/dist/components-react.js");
        /* harmony import */        var _resources_common_close_png__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
        /*! ../../resources/common_close.png */
        "./src/resources/common_close.png");
        /* harmony import */        var _resources_common_options_png__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
        /*! ../../resources/common_options.png */
        "./src/resources/common_options.png");
        /* harmony import */        var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
        /*! react/jsx-runtime */
        "webpack/container/remote/react/jsx-runtime");
        /* harmony import */        var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2___default = /* */ __webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__);
        function _ActionButton(_ref) {
            var _ref$type = _ref.type, type = _ref$type === void 0 ? "icon" : _ref$type, _ref$onTap = _ref.onTap, onTap = _ref$onTap === void 0 ? function() {} : _ref$onTap, _ref$title = _ref.title, title = _ref$title === void 0 ? "" : _ref$title, _ref$src = _ref.src, src = _ref$src === void 0 ? "" : _ref$src, _ref$enabled = _ref.enabled, enabled = _ref$enabled === void 0 ? true : _ref$enabled;
            var buttonClass = type === "icon" ? ".iconButton" : ".textButton";
            if (!enabled) {
                buttonClass = buttonClass + " .disabled";
            }
            var content = type === "icon" ? /* */ (0, react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx)(_tarojs_components__WEBPACK_IMPORTED_MODULE_3__.Image, {
                src: src
            }) : /* */ (0, react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx)(_tarojs_components__WEBPACK_IMPORTED_MODULE_3__.Text, {
                children: title
            });
            return /* */ (0, react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx)(_tarojs_components__WEBPACK_IMPORTED_MODULE_3__.View, {
                onTap: onTap,
                className: buttonClass,
                children: content
            });
        }
        function CloseButton(_ref2) {
            var onTap = _ref2.onTap;
            return /* */ (0, react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx)(_tarojs_components__WEBPACK_IMPORTED_MODULE_3__.View, {
                className: "closeButton",
                onTap: onTap,
                children: /* */ (0, react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx)(_tarojs_components__WEBPACK_IMPORTED_MODULE_3__.Image, {
                    src: _resources_common_close_png__WEBPACK_IMPORTED_MODULE_0__
                })
            });
        }
        function _OptionButton(_ref3) {
            var onTap = _ref3.onTap;
            return /* */ (0, react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx)(_tarojs_components__WEBPACK_IMPORTED_MODULE_3__.View, {
                className: "optionButton",
                onTap: onTap,
                children: /* */ (0, react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx)(_tarojs_components__WEBPACK_IMPORTED_MODULE_3__.Image, {
                    src: _resources_common_options_png__WEBPACK_IMPORTED_MODULE_1__
                })
            });
        }
        /***/    },
    /***/
    "./src/components/cell/cell.tsx": 
    /*!**************************************!*\
    !*** ./src/components/cell/cell.tsx ***!
    \**************************************/
    /***/
    function srcComponentsCellCellTsx(__unused_webpack_module, __webpack_exports__, __webpack_require__) {
        /* harmony export */
        __webpack_require__.d(__webpack_exports__, {
            /* harmony export */
            SectionHeader: function SectionHeader() {
                /* binding */
                return _SectionHeader;
            },
            /* harmony export */
            Cell: function Cell() {
                /* binding */
                return _Cell;
            },
            /* harmony export */
            Spacer: function Spacer() {
                /* binding */
                return _Spacer;
            },
            /* harmony export */
            DecisionCardMiniRow: function DecisionCardMiniRow() {
                /* binding */
                return _DecisionCardMiniRow;
            },
            /* harmony export */
            CustomAdCell: function CustomAdCell() {
                /* binding */
                return _CustomAdCell;
            }
            /* harmony export */        });
        /* unused harmony export DecisionCardMini */
        /* harmony import */        var _tarojs_components__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
        /*! @tarojs/components */
        "./node_modules/@tarojs/plugin-platform-weapp/dist/components-react.js");
        /* harmony import */        var _resources_common_add_png__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
        /*! ../../resources/common_add.png */
        "./src/resources/common_add.png");
        /* harmony import */        var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
        /*! react/jsx-runtime */
        "webpack/container/remote/react/jsx-runtime");
        /* harmony import */        var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1___default = /* */ __webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__);
        function _SectionHeader(props) {
            /* */
            return (0, react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsx)(_tarojs_components__WEBPACK_IMPORTED_MODULE_2__.View, {
                className: "sectionHeader",
                children: /* */ (0, react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsx)(_tarojs_components__WEBPACK_IMPORTED_MODULE_2__.Text, {
                    children: props.title
                })
            });
        }
        function _Cell(_ref) {
            var children = _ref.children, _ref$selected = _ref.selected, selected = _ref$selected === void 0 ? false : _ref$selected, _ref$onTap = _ref.onTap, onTap = _ref$onTap === void 0 ? function() {} : _ref$onTap;
            return /* */ (0, react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsx)(_tarojs_components__WEBPACK_IMPORTED_MODULE_2__.View, {
                className: "cellContainer" + (selected ? " selected" : " unselected"),
                onTap: onTap,
                children: children
            });
        }
        function _Spacer(_ref2) {
            var height = _ref2.height;
            return /* */ (0, react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsx)(_tarojs_components__WEBPACK_IMPORTED_MODULE_2__.View, {
                style: {
                    height: "".concat(height, "px")
                }
            });
        }
        function DecisionCardMini(_ref3) {
            var decision = _ref3.decision, onSave = _ref3.onSave;
            return /* */ (0, react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxs)(_tarojs_components__WEBPACK_IMPORTED_MODULE_2__.View, {
                className: "decisonCardMini",
                children: [ /* */ (0, react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxs)(_tarojs_components__WEBPACK_IMPORTED_MODULE_2__.View, {
                    className: "top",
                    children: [ /* */ (0, react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsx)(_tarojs_components__WEBPACK_IMPORTED_MODULE_2__.Text, {
                        className: "decisionEmoji",
                        children: decision.icon
                    }), /* */ (0, react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsx)(_tarojs_components__WEBPACK_IMPORTED_MODULE_2__.Image, {
                        onTap: onSave,
                        className: "actionButton",
                        src: _resources_common_add_png__WEBPACK_IMPORTED_MODULE_0__
                    }) ]
                }), /* */ (0, react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsx)(_tarojs_components__WEBPACK_IMPORTED_MODULE_2__.Text, {
                    className: "decisionTitle",
                    children: decision.name
                }) ]
            });
        }
        function _DecisionCardMiniRow(_ref4) {
            var decision1 = _ref4.decision1, decision2 = _ref4.decision2, onSave1 = _ref4.onSave1, onSave2 = _ref4.onSave2;
            return /* */ (0, react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxs)(_tarojs_components__WEBPACK_IMPORTED_MODULE_2__.View, {
                className: "decisionCardMiniRow",
                children: [ /* */ (0, react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsx)(DecisionCardMini, {
                    decision: decision1,
                    onSave: onSave1
                }), decision2 !== undefined ? /* */ (0, react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsx)(DecisionCardMini, {
                    decision: decision2,
                    onSave: onSave2
                }) : /* */ (0, react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsx)(_tarojs_components__WEBPACK_IMPORTED_MODULE_2__.View, {
                    className: "decisonCardMini",
                    style: {
                        opacity: "0"
                    }
                }) ]
            });
        }
        function _CustomAdCell(_ref5) {
            var unitId = _ref5.unitId, onError = _ref5.onError;
            return /* */ (0, react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsx)(_tarojs_components__WEBPACK_IMPORTED_MODULE_2__.View, {
                className: "adWrapper",
                children: /* */ (0, react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsx)(_tarojs_components__WEBPACK_IMPORTED_MODULE_2__.AdCustom, {
                    unitId: unitId,
                    adIntervals: 30,
                    onError: onError
                })
            });
        }
        /***/    },
    /***/
    "./src/components/wheel/models.ts": 
    /*!****************************************!*\
    !*** ./src/components/wheel/models.ts ***!
    \****************************************/
    /***/
    function srcComponentsWheelModelsTs(__unused_webpack_module, __webpack_exports__, __webpack_require__) {
        /* harmony export */
        __webpack_require__.d(__webpack_exports__, {
            /* harmony export */
            Slice: function Slice() {
                /* binding */
                return _Slice;
            },
            /* harmony export */
            WheelState: function WheelState() {
                /* binding */
                return _WheelState;
            },
            /* harmony export */
            SliceState: function SliceState() {
                /* binding */
                return _SliceState;
            },
            /* harmony export */
            DefaultTheme: function DefaultTheme() {
                /* binding */
                return _DefaultTheme;
            }
            /* harmony export */        });
        /* harmony import */        var _Users_Nix_Developer_DecisionTaro_node_modules_babel_runtime_helpers_esm_createClass_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
        /*! ./node_modules/@babel/runtime/helpers/esm/createClass.js */
        "./node_modules/@babel/runtime/helpers/esm/createClass.js");
        /* harmony import */        var _Users_Nix_Developer_DecisionTaro_node_modules_babel_runtime_helpers_esm_classCallCheck_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
        /*! ./node_modules/@babel/runtime/helpers/esm/classCallCheck.js */
        "./node_modules/@babel/runtime/helpers/esm/classCallCheck.js");
        /* harmony import */        var _Users_Nix_Developer_DecisionTaro_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
        /*! ./node_modules/@babel/runtime/helpers/esm/defineProperty.js */
        "./node_modules/@babel/runtime/helpers/esm/defineProperty.js");
        var _Slice = /* */ (0, _Users_Nix_Developer_DecisionTaro_node_modules_babel_runtime_helpers_esm_createClass_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function Slice(title, startDeg, endDeg, color) {
            (0, _Users_Nix_Developer_DecisionTaro_node_modules_babel_runtime_helpers_esm_classCallCheck_js__WEBPACK_IMPORTED_MODULE_1__["default"])(this, Slice);
            (0, _Users_Nix_Developer_DecisionTaro_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_2__["default"])(this, "title", void 0);
            (0, _Users_Nix_Developer_DecisionTaro_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_2__["default"])(this, "startDeg", void 0);
            (0, _Users_Nix_Developer_DecisionTaro_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_2__["default"])(this, "midDeg", void 0);
            (0, _Users_Nix_Developer_DecisionTaro_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_2__["default"])(this, "endDeg", void 0);
            (0, _Users_Nix_Developer_DecisionTaro_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_2__["default"])(this, "color", void 0);
            this.title = title;
            this.startDeg = startDeg;
            this.midDeg = (startDeg + endDeg) / 2;
            this.endDeg = endDeg;
            this.color = color;
        });
        var _WheelState = /* */ function(WheelState) {
            WheelState[WheelState["normal"] = 0] = "normal";
            WheelState[WheelState["spinning"] = 1] = "spinning";
            WheelState[WheelState["hilighted"] = 2] = "hilighted";
            return WheelState;
        }({});
        var _SliceState = /* */ function(SliceState) {
            SliceState[SliceState["normal"] = 0] = "normal";
            SliceState[SliceState["disabled"] = 1] = "disabled";
            SliceState[SliceState["dimmed"] = 2] = "dimmed";
            SliceState[SliceState["disabledDimmed"] = 3] = "disabledDimmed";
            SliceState[SliceState["hilighted"] = 4] = "hilighted";
            return SliceState;
        }({});
        var _DefaultTheme = /* */ function() {
            function DefaultTheme() {
                (0, _Users_Nix_Developer_DecisionTaro_node_modules_babel_runtime_helpers_esm_classCallCheck_js__WEBPACK_IMPORTED_MODULE_1__["default"])(this, DefaultTheme);
                (0, _Users_Nix_Developer_DecisionTaro_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_2__["default"])(this, "name", void 0);
                (0, _Users_Nix_Developer_DecisionTaro_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_2__["default"])(this, "colors", void 0);
                this.name = "default";
                this.colors = [ "#D63339", "#EB6F3E", "#82AF48", "#3F90BB", "#1F59CE", "#7C36D3", "#B930C4" ];
            }
            (0, _Users_Nix_Developer_DecisionTaro_node_modules_babel_runtime_helpers_esm_createClass_js__WEBPACK_IMPORTED_MODULE_0__["default"])(DefaultTheme, [ {
                key: "colorForSlice",
                value: function colorForSlice(index, total, state) {
                    switch (state) {
                      case _SliceState.hilighted:
                        return this.colors[index % total % this.colors.length];

                      case _SliceState.dimmed:
                        return this.colors[index % total % this.colors.length] + "77";

                      case _SliceState.disabled:
                        return "black";

                      default:
                        return this.colors[index % total % this.colors.length];
                    }
                }
            } ]);
            return DefaultTheme;
        }();
        /***/    },
    /***/
    "./src/components/wheel/wheel.tsx": 
    /*!****************************************!*\
    !*** ./src/components/wheel/wheel.tsx ***!
    \****************************************/
    /***/
    function srcComponentsWheelWheelTsx(__unused_webpack_module, __webpack_exports__, __webpack_require__) {
        /* harmony export */
        __webpack_require__.d(__webpack_exports__, {
            /* harmony export */
            default: function _default() {
                /* binding */
                return Wheel;
            }
            /* harmony export */        });
        /* harmony import */        var _Users_Nix_Developer_DecisionTaro_node_modules_babel_runtime_helpers_esm_slicedToArray_js__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
        /*! ./node_modules/@babel/runtime/helpers/esm/slicedToArray.js */
        "./node_modules/@babel/runtime/helpers/esm/slicedToArray.js");
        /* harmony import */        var _tarojs_components__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(
        /*! @tarojs/components */
        "./node_modules/@tarojs/plugin-platform-weapp/dist/components-react.js");
        /* harmony import */        var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
        /*! react */
        "webpack/container/remote/react");
        /* harmony import */        var react__WEBPACK_IMPORTED_MODULE_0___default = /* */ __webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
        /* harmony import */        var _models__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
        /*! ./models */
        "./src/components/wheel/models.ts");
        /* harmony import */        var _models_decision__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
        /*! ../../models/decision */
        "./src/models/decision.ts");
        /* harmony import */        var _tarojs_taro__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
        /*! @tarojs/taro */
        "webpack/container/remote/@tarojs/taro");
        /* harmony import */        var _tarojs_taro__WEBPACK_IMPORTED_MODULE_3___default = /* */ __webpack_require__.n(_tarojs_taro__WEBPACK_IMPORTED_MODULE_3__);
        /* harmony import */        var _resources_wheel_spin_button_png__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
        /*! ./resources/wheel_spin_button.png */
        "./src/components/wheel/resources/wheel_spin_button.png");
        /* harmony import */        var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
        /*! react/jsx-runtime */
        "webpack/container/remote/react/jsx-runtime");
        /* harmony import */        var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5___default = /* */ __webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__);
        function randomDegForIndex(index, decision) {
            var slices = makeSlices(decision);
            if (index < 0 || index >= slices.length) {
                console.log("[wheel] 💣 invalid index");
                return 0;
            }
            var slice = slices[index];
            var ratio = Math.max(Math.min(.95, Math.random()), .05);
            var randomDeg = slice.startDeg + ratio * (slice.endDeg - slice.startDeg);
            console.log("[wheel] Target slice: ".concat(slice.title, "@").concat(randomDeg));
            return randomDeg;
        }
        function makeSlices(decision, wheelState, luckyIndex) {
            console.log("[wheel] Make slices");
            if (!(decision instanceof _models_decision__WEBPACK_IMPORTED_MODULE_2__.Decision)) {
                decision = _models_decision__WEBPACK_IMPORTED_MODULE_2__.Decision.demo;
            }
            var totalWeight = decision.totalWeight;
            var totalDeg = 0;
            var index = 0;
            var count = decision.options.length;
            var theme = new _models__WEBPACK_IMPORTED_MODULE_1__.DefaultTheme();
            return decision.options.map(function(option) {
                var sliceDeg = option.weight / totalWeight * 360;
                var endDeg = totalDeg + sliceDeg;
                var sliceState = _models__WEBPACK_IMPORTED_MODULE_1__.SliceState.normal;
                if (wheelState == _models__WEBPACK_IMPORTED_MODULE_1__.WheelState.hilighted) {
                    sliceState = luckyIndex === index ? _models__WEBPACK_IMPORTED_MODULE_1__.SliceState.hilighted : _models__WEBPACK_IMPORTED_MODULE_1__.SliceState.dimmed;
                }
                var slice = new _models__WEBPACK_IMPORTED_MODULE_1__.Slice(option.name, totalDeg, endDeg, theme.colorForSlice(index, count, sliceState));
                totalDeg = endDeg;
                index += 1;
                return slice;
            });
        }
        function makeSliceGradient(slices) {
            var gradient = slices.map(function(slice) {
                return "".concat(slice.color, " ").concat(slice.startDeg, "deg ").concat(slice.endDeg, "deg");
            }).join(", ");
            return "conic-gradient(".concat(gradient, ")");
        }
        function Wheel(_ref) {
            var decision = _ref.decision, spinDuration = _ref.spinDuration, onSpinStart = _ref.onSpinStart, onSpinEnd = _ref.onSpinEnd, resetTrigger = _ref.resetTrigger;
            var _useState = (0, react__WEBPACK_IMPORTED_MODULE_0__.useState)(0), _useState2 = (0, 
            _Users_Nix_Developer_DecisionTaro_node_modules_babel_runtime_helpers_esm_slicedToArray_js__WEBPACK_IMPORTED_MODULE_6__["default"])(_useState, 2), currentDeg = _useState2[0], setCurrentDeg = _useState2[1];
            var _useState3 = (0, react__WEBPACK_IMPORTED_MODULE_0__.useState)(_models__WEBPACK_IMPORTED_MODULE_1__.WheelState.normal), _useState4 = (0, 
            _Users_Nix_Developer_DecisionTaro_node_modules_babel_runtime_helpers_esm_slicedToArray_js__WEBPACK_IMPORTED_MODULE_6__["default"])(_useState3, 2), wheelState = _useState4[0], setWheelState = _useState4[1];
            var _useState5 = (0, react__WEBPACK_IMPORTED_MODULE_0__.useState)(0), _useState6 = (0, 
            _Users_Nix_Developer_DecisionTaro_node_modules_babel_runtime_helpers_esm_slicedToArray_js__WEBPACK_IMPORTED_MODULE_6__["default"])(_useState5, 2), luckyIndex = _useState6[0], setLuckyIndex = _useState6[1];
            var _useState7 = (0, react__WEBPACK_IMPORTED_MODULE_0__.useState)({}), _useState8 = (0, 
            _Users_Nix_Developer_DecisionTaro_node_modules_babel_runtime_helpers_esm_slicedToArray_js__WEBPACK_IMPORTED_MODULE_6__["default"])(_useState7, 2), animationData = _useState8[0], setAnimationData = _useState8[1];
            (0, react__WEBPACK_IMPORTED_MODULE_0__.useEffect)(function() {
                resetWheel();
            }, [ resetTrigger ]);
            var animation = _tarojs_taro__WEBPACK_IMPORTED_MODULE_3___default().createAnimation({
                duration: spinDuration * 1e3,
                timingFunction: "ease-out"
            });
            function onSpin() {
                console.log("[wheel] onSpin");
                if (wheelState == _models__WEBPACK_IMPORTED_MODULE_1__.WheelState.spinning) {
                    console.log("[wheel] Overlapped spin, skip");
                    return;
                }
                console.log("[wheel] Spin started");
                setWheelState(_models__WEBPACK_IMPORTED_MODULE_1__.WheelState.spinning);
                onSpinStart();
                var index = decision.draw();
                setLuckyIndex(index);
                var randomDeg = 360 - randomDegForIndex(index, decision);
                var endDeg = spinDuration * 2 * 360 + randomDeg;
                console.log("Spin startDeg: ".concat(currentDeg % 360, ", endDeg: ").concat(endDeg, " (").concat(endDeg % 360, ")"));
                setCurrentDeg(endDeg);
                animation.rotateZ(endDeg).step();
                setAnimationData(animation.export());
            }
            function onTransitionEnd() {
                console.log("[wheel] Spin ended at ".concat(luckyIndex));
                setWheelState(_models__WEBPACK_IMPORTED_MODULE_1__.WheelState.hilighted);
                // Reset rotateZ
                                setAnimationData(animation.rotateZ(currentDeg % 360).step({
                    duration: 0
                }).export());
                var result = decision.options[luckyIndex].name;
                onSpinEnd(result);
            }
            function resetWheel() {
                console.log("[wheel] Reset wheel");
                setWheelState(_models__WEBPACK_IMPORTED_MODULE_1__.WheelState.normal);
            }
            var slices = makeSlices(decision, wheelState, luckyIndex);
            var wheelStyle = {
                background: makeSliceGradient(slices)
            };
            var separators = slices.map(function(slice) {
                var deg = slice.endDeg + 90;
                var style = {
                    transform: "rotate(".concat(deg, "deg)")
                };
                return /* */ (0, react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__.jsx)(_tarojs_components__WEBPACK_IMPORTED_MODULE_7__.View, {
                    className: "separator",
                    style: style
                });
            });
            var optionNames = slices.map(function(slice) {
                var deg = slice.midDeg + 90;
                var style = {
                    transform: "rotate(".concat(deg, "deg)")
                };
                return /* */ (0, react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__.jsx)(_tarojs_components__WEBPACK_IMPORTED_MODULE_7__.Text, {
                    className: "optionName",
                    style: style,
                    children: slice.title
                });
            });
            return /* */ (0, react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__.jsxs)(_tarojs_components__WEBPACK_IMPORTED_MODULE_7__.View, {
                className: "wheelContainer",
                children: [ /* */ (0, react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__.jsxs)(_tarojs_components__WEBPACK_IMPORTED_MODULE_7__.View, {
                    className: "wheel",
                    animation: animationData,
                    onTransitionEnd: onTransitionEnd,
                    style: wheelStyle,
                    children: [ separators, optionNames ]
                }), /* */ (0, react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__.jsx)(_tarojs_components__WEBPACK_IMPORTED_MODULE_7__.Image, {
                    onTap: onSpin,
                    className: "spinButton",
                    src: _resources_wheel_spin_button_png__WEBPACK_IMPORTED_MODULE_4__
                }) ]
            });
        }
        /***/    },
    /***/
    "./src/models/decision.ts": 
    /*!********************************!*\
    !*** ./src/models/decision.ts ***!
    \********************************/
    /***/
    function srcModelsDecisionTs(__unused_webpack_module, __webpack_exports__, __webpack_require__) {
        /* harmony export */
        __webpack_require__.d(__webpack_exports__, {
            /* harmony export */
            Option: function Option() {
                /* binding */
                return _Option;
            },
            /* harmony export */
            ValidateType: function ValidateType() {
                /* binding */
                return _ValidateType;
            },
            /* harmony export */
            Decision: function Decision() {
                /* binding */
                return _Decision;
            }
            /* harmony export */        });
        /* harmony import */        var _Users_Nix_Developer_DecisionTaro_node_modules_babel_runtime_helpers_esm_classCallCheck_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
        /*! ./node_modules/@babel/runtime/helpers/esm/classCallCheck.js */
        "./node_modules/@babel/runtime/helpers/esm/classCallCheck.js");
        /* harmony import */        var _Users_Nix_Developer_DecisionTaro_node_modules_babel_runtime_helpers_esm_createClass_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
        /*! ./node_modules/@babel/runtime/helpers/esm/createClass.js */
        "./node_modules/@babel/runtime/helpers/esm/createClass.js");
        /* harmony import */        var _Users_Nix_Developer_DecisionTaro_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
        /*! ./node_modules/@babel/runtime/helpers/esm/defineProperty.js */
        "./node_modules/@babel/runtime/helpers/esm/defineProperty.js");
        /* harmony import */        var class_transformer__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
        /*! class-transformer */
        "webpack/container/remote/class-transformer");
        /* harmony import */        var class_transformer__WEBPACK_IMPORTED_MODULE_0___default = /* */ __webpack_require__.n(class_transformer__WEBPACK_IMPORTED_MODULE_0__);
        function generateUUID() {
            var alphabet = "0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ";
            var idLength = 6;
            var id = "";
            for (var i = 0; i < idLength; i++) {
                var randomIndex = Math.floor(Math.random() * alphabet.length);
                id += alphabet[randomIndex];
            }
            return id;
        }
        var _Option = /* */ function() {
            function Option(name) {
                var weight = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : undefined;
                (0, _Users_Nix_Developer_DecisionTaro_node_modules_babel_runtime_helpers_esm_classCallCheck_js__WEBPACK_IMPORTED_MODULE_1__["default"])(this, Option);
                (0, _Users_Nix_Developer_DecisionTaro_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_2__["default"])(this, "id", void 0);
                (0, _Users_Nix_Developer_DecisionTaro_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_2__["default"])(this, "name", void 0);
                (0, _Users_Nix_Developer_DecisionTaro_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_2__["default"])(this, "_weight", void 0);
                (0, _Users_Nix_Developer_DecisionTaro_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_2__["default"])(this, "enabled", void 0);
                this.id = generateUUID();
                this.name = name;
                this._weight = weight;
                this.enabled = true;
            }
            // Mini object for compress
                        (0, _Users_Nix_Developer_DecisionTaro_node_modules_babel_runtime_helpers_esm_createClass_js__WEBPACK_IMPORTED_MODULE_3__["default"])(Option, [ {
                key: "weight",
                get: function get() {
                    return Math.max(0, this._weight || 1);
                },
                set: function set(weight) {
                    if (weight >= 0) {
                        this._weight = weight;
                    }
                }
            }, {
                key: "isValid",
                get: function get() {
                    return this.name.length > 0 && this.weight >= Option.minWeight && this.weight <= Option.maxWeight;
                }
            }, {
                key: "mini",
                get: function get() {
                    return {
                        n: this.name,
                        w: this.weight
                    };
                }
            } ], [ {
                key: "initFromMini",
                value: function initFromMini(mini) {
                    return new Option(mini.n, mini.w);
                }
            } ]);
            return Option;
        }();
        (0, _Users_Nix_Developer_DecisionTaro_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_2__["default"])(_Option, "minWeight", 0);
        (0, _Users_Nix_Developer_DecisionTaro_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_2__["default"])(_Option, "maxWeight", 9999);
        var _ValidateType = /* */ function(ValidateType) {
            ValidateType[ValidateType["valid"] = 0] = "valid";
            ValidateType[ValidateType["emptyName"] = 1] = "emptyName";
            ValidateType[ValidateType["notEnoughOption"] = 2] = "notEnoughOption";
            return ValidateType;
        }({});
        var _Decision = /* */ function() {
            function Decision(icon, name, options) {
                (0, _Users_Nix_Developer_DecisionTaro_node_modules_babel_runtime_helpers_esm_classCallCheck_js__WEBPACK_IMPORTED_MODULE_1__["default"])(this, Decision);
                (0, _Users_Nix_Developer_DecisionTaro_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_2__["default"])(this, "id", void 0);
                (0, _Users_Nix_Developer_DecisionTaro_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_2__["default"])(this, "icon", void 0);
                (0, _Users_Nix_Developer_DecisionTaro_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_2__["default"])(this, "name", void 0);
                (0, _Users_Nix_Developer_DecisionTaro_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_2__["default"])(this, "options", void 0);
                this.id = generateUUID();
                this.icon = icon;
                this.name = name;
                this.options = options;
            }
            // Init class instance with object
                        (0, _Users_Nix_Developer_DecisionTaro_node_modules_babel_runtime_helpers_esm_createClass_js__WEBPACK_IMPORTED_MODULE_3__["default"])(Decision, [ {
                key: "toJSON",
                value: // Get object
                function toJSON() {
                    return (0, class_transformer__WEBPACK_IMPORTED_MODULE_0__.instanceToPlain)(this);
                }
                // Convert to mini string for sharing
                        }, {
                key: "miniString",
                get: function get() {
                    var miniOptions = this.options.map(function(option) {
                        return option.mini;
                    });
                    var miniDecision = {
                        n: this.name,
                        o: miniOptions
                    };
                    return encodeURIComponent(JSON.stringify(miniDecision));
                }
            }, {
                key: "contentString",
                get: function get() {
                    return [ this.name ].concat(this.options.map(function(option) {
                        return option.name;
                    })).join(",");
                }
                // Init Decision from mini string
                        }, {
                key: "totalWeight",
                get: function get() {
                    return this.options.reduce(function(result, current) {
                        return result + current.weight;
                    }, 0);
                }
            }, {
                key: "validOptions",
                get: function get() {
                    return this.options.filter(function(option) {
                        return option.isValid;
                    });
                }
            }, {
                key: "validateType",
                get: function get() {
                    if (this.name.length == 0) {
                        return _ValidateType.emptyName;
                    }
                    if (this.validOptions.length < 2) {
                        return _ValidateType.notEnoughOption;
                    }
                    return _ValidateType.valid;
                }
            }, {
                key: "isValid",
                get: function get() {
                    return this.validateType == _ValidateType.valid;
                }
            }, {
                key: "draw",
                value: function draw() {
                    var totalEnabledWeight = this.options.reduce(function(result, current) {
                        return result + (current.enabled ? current.weight : 0);
                    }, 0);
                    if (totalEnabledWeight <= 0) {
                        return 0;
                    }
                    var luckyNumber = Math.ceil(Math.random() * totalEnabledWeight);
                    var tempIndex = 0;
                    var tempWeight = 0;
                    while (tempIndex < this.options.length) {
                        var option = this.options[tempIndex];
                        var optionWeight = option.weight;
                        if (option.enabled && optionWeight > 0) {
                            tempWeight = tempWeight + optionWeight;
                            if (tempWeight >= luckyNumber) {
                                break;
                            }
                        }
                        tempIndex = tempIndex + 1;
                    }
                    console.log("[decision] 🎲 draw result: total weight: ".concat(totalEnabledWeight, ", lucky number: ").concat(luckyNumber, ", index: ").concat(tempIndex));
                    return tempIndex;
                }
            } ], [ {
                key: "init",
                value: function init(object) {
                    var decision = (0, class_transformer__WEBPACK_IMPORTED_MODULE_0__.plainToInstance)(Decision, [ object ])[0];
                    decision.options = (0, class_transformer__WEBPACK_IMPORTED_MODULE_0__.plainToInstance)(_Option, decision.options);
                    return decision;
                }
            }, {
                key: "initFromMiniString",
                value: function initFromMiniString(miniString) {
                    try {
                        var miniDecision = JSON.parse(decodeURIComponent(miniString));
                        var options = miniDecision.o.map(function(option) {
                            return _Option.initFromMini(option);
                        });
                        return new Decision(undefined, miniDecision.n, options);
                    } catch (e) {
                        return undefined;
                    }
                }
            } ]);
            return Decision;
        }();
        (0, _Users_Nix_Developer_DecisionTaro_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_2__["default"])(_Decision, "demo", new _Decision("🤔", "今天吃什么？", [ new _Option("火锅", 1), new _Option("日本料理", 1), new _Option("泰国菜", 1), new _Option("火锅底料", 1), new _Option("拉面", 1), new _Option("饺子", 1) ]));
        /***/    },
    /***/
    "./src/state/hooks.ts": 
    /*!****************************!*\
    !*** ./src/state/hooks.ts ***!
    \****************************/
    /***/
    function srcStateHooksTs(__unused_webpack_module, __webpack_exports__, __webpack_require__) {
        /* harmony export */
        __webpack_require__.d(__webpack_exports__, {
            /* harmony export */
            useAppDispatch: function useAppDispatch() {
                /* binding */
                return _useAppDispatch;
            },
            /* harmony export */
            useAppSelector: function useAppSelector() {
                /* binding */
                return _useAppSelector;
            }
            /* harmony export */        });
        /* harmony import */        var react_redux__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
        /*! react-redux */
        "webpack/container/remote/react-redux");
        /* harmony import */        var react_redux__WEBPACK_IMPORTED_MODULE_0___default = /* */ __webpack_require__.n(react_redux__WEBPACK_IMPORTED_MODULE_0__);
        // https://redux.js.org/usage/usage-with-typescript
        // Use throughout your app instead of plain `useDispatch` and `useSelector`
                var _useAppDispatch = react_redux__WEBPACK_IMPORTED_MODULE_0__.useDispatch;
        var _useAppSelector = react_redux__WEBPACK_IMPORTED_MODULE_0__.useSelector;
        /***/    },
    /***/
    "./src/state/reducers/decision.ts": 
    /*!****************************************!*\
    !*** ./src/state/reducers/decision.ts ***!
    \****************************************/
    /***/
    function srcStateReducersDecisionTs(__unused_webpack_module, __webpack_exports__, __webpack_require__) {
        /* harmony export */
        __webpack_require__.d(__webpack_exports__, {
            /* harmony export */
            updateDecision: function updateDecision() {
                /* binding */
                return _updateDecision;
            },
            /* harmony export */
            removeDecision: function removeDecision() {
                /* binding */
                return _removeDecision;
            },
            /* harmony export */
            makeKeyDecision: function makeKeyDecision() {
                /* binding */
                return _makeKeyDecision;
            },
            /* harmony export */
            findDecision: function findDecision() {
                /* binding */
                return _findDecision;
            },
            /* harmony export */
            selectDecisions: function selectDecisions() {
                /* binding */
                return _selectDecisions;
            },
            /* harmony export */
            selectKeyDecisionId: function selectKeyDecisionId() {
                /* binding */
                return _selectKeyDecisionId;
            },
            /* harmony export */
            selectKeyDecision: function selectKeyDecision() {
                /* binding */
                return _selectKeyDecision;
            }
            /* harmony export */        });
        /* harmony import */        var _models_decision__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
        /*! ../../models/decision */
        "./src/models/decision.ts");
        /* harmony import */        var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
        /*! @reduxjs/toolkit */
        "webpack/container/remote/@reduxjs/toolkit");
        /* harmony import */        var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_1___default = /* */ __webpack_require__.n(_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_1__);
        var initialState = {
            decisions: [],
            keyDecisionId: undefined
        };
        var decisionSlice = (0, _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_1__.createSlice)({
            name: "decision",
            initialState: initialState,
            reducers: {
                updateDecision: function updateDecision(state, action) {
                    var decisions = state.decisions;
                    var newDecision = action.payload;
                    var index = decisions.map(function(e) {
                        return e.id;
                    }).indexOf(action.payload.id);
                    if (index >= 0) {
                        // Update
                        decisions.splice(index, 1, newDecision);
                    } else {
                        // New
                        decisions.splice(0, 0, newDecision);
                        state.keyDecisionId = newDecision.id;
                    }
                },
                removeDecision: function removeDecision(state, action) {
                    var decisions = state.decisions;
                    var id = action.payload;
                    var index = decisions.map(function(e) {
                        return e.id;
                    }).indexOf(id);
                    if (index >= 0) {
                        decisions.splice(index, 1);
                        if (state.keyDecisionId === id) {
                            if (decisions.length > 0) {
                                state.keyDecisionId = decisions[0].id;
                            } else {
                                state.keyDecisionId = undefined;
                            }
                        }
                    }
                },
                makeKeyDecision: function makeKeyDecision(state, action) {
                    state.keyDecisionId = action.payload;
                }
            }
        });
        var _decisionSlice$action = decisionSlice.actions, _updateDecision = _decisionSlice$action.updateDecision, _removeDecision = _decisionSlice$action.removeDecision, _makeKeyDecision = _decisionSlice$action.makeKeyDecision;
        /* harmony default export */        __webpack_exports__["default"] = decisionSlice.reducer;
        function findIndexOfDecision(decisions, id) {
            if (id === undefined) {
                return -1;
            }
            return decisions.map(function(e) {
                return e.id;
            }).indexOf(id);
        }
        function _findDecision(decisions, id) {
            if (id === undefined) {
                return undefined;
            }
            var index = findIndexOfDecision(decisions, id);
            if (index >= 0) {
                return decisions[index];
            }
            return undefined;
        }
        function getDecisions(state) {
            return state.decision.decisions.map(function(d) {
                return _models_decision__WEBPACK_IMPORTED_MODULE_0__.Decision.init(d);
            });
        }
        var _selectDecisions = function selectDecisions(state) {
            return getDecisions(state);
        };
        var _selectKeyDecisionId = function selectKeyDecisionId(state) {
            return state.decision.keyDecisionId;
        };
        var _selectKeyDecision = function selectKeyDecision(state) {
            return _findDecision(getDecisions(state), state.decision.keyDecisionId) || _models_decision__WEBPACK_IMPORTED_MODULE_0__.Decision.demo;
        };
        /***/    },
    /***/
    "./src/state/reducers/settings.ts": 
    /*!****************************************!*\
    !*** ./src/state/reducers/settings.ts ***!
    \****************************************/
    /***/
    function srcStateReducersSettingsTs(__unused_webpack_module, __webpack_exports__, __webpack_require__) {
        /* harmony export */
        __webpack_require__.d(__webpack_exports__, {
            /* harmony export */
            setSoundEnabled: function setSoundEnabled() {
                /* binding */
                return _setSoundEnabled;
            },
            /* harmony export */
            setHapticEnabled: function setHapticEnabled() {
                /* binding */
                return _setHapticEnabled;
            },
            /* harmony export */
            setWheelSpinDuration: function setWheelSpinDuration() {
                /* binding */
                return _setWheelSpinDuration;
            },
            /* harmony export */
            selectIsSoundEnabled: function selectIsSoundEnabled() {
                /* binding */
                return _selectIsSoundEnabled;
            },
            /* harmony export */
            selectIsHapticEnabled: function selectIsHapticEnabled() {
                /* binding */
                return _selectIsHapticEnabled;
            },
            /* harmony export */
            selectWheelSpinDuration: function selectWheelSpinDuration() {
                /* binding */
                return _selectWheelSpinDuration;
            }
            /* harmony export */        });
        /* harmony import */        var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
        /*! @reduxjs/toolkit */
        "webpack/container/remote/@reduxjs/toolkit");
        /* harmony import */        var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0___default = /* */ __webpack_require__.n(_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__);
        var initialState = {
            isSoundEnabled: true,
            isHapticEnabled: true,
            wheelSpinDuration: 5
        };
        var settingsSlice = (0, _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.createSlice)({
            name: "settings",
            initialState: initialState,
            reducers: {
                setSoundEnabled: function setSoundEnabled(state, action) {
                    state.isSoundEnabled = action.payload;
                },
                setHapticEnabled: function setHapticEnabled(state, action) {
                    state.isHapticEnabled = action.payload;
                },
                setWheelSpinDuration: function setWheelSpinDuration(state, action) {
                    state.wheelSpinDuration = action.payload;
                }
            }
        });
        var _settingsSlice$action = settingsSlice.actions, _setSoundEnabled = _settingsSlice$action.setSoundEnabled, _setHapticEnabled = _settingsSlice$action.setHapticEnabled, _setWheelSpinDuration = _settingsSlice$action.setWheelSpinDuration;
        /* harmony default export */        __webpack_exports__["default"] = settingsSlice.reducer;
        var _selectIsSoundEnabled = function selectIsSoundEnabled(state) {
            return state.settings.isSoundEnabled;
        };
        var _selectIsHapticEnabled = function selectIsHapticEnabled(state) {
            return state.settings.isHapticEnabled;
        };
        var _selectWheelSpinDuration = function selectWheelSpinDuration(state) {
            return state.settings.wheelSpinDuration;
        };
        /***/    },
    /***/
    "./src/components/wheel/resources/wheel_spin_button.png": 
    /*!**************************************************************!*\
    !*** ./src/components/wheel/resources/wheel_spin_button.png ***!
    \**************************************************************/
    /***/
    function srcComponentsWheelResourcesWheel_spin_buttonPng(module, __unused_webpack_exports, __webpack_require__) {
        module.exports = __webpack_require__.p + "components/wheel/resources/wheel_spin_button.png";
        /***/    },
    /***/
    "./src/resources/common_add.png": 
    /*!**************************************!*\
    !*** ./src/resources/common_add.png ***!
    \**************************************/
    /***/
    function srcResourcesCommon_addPng(module, __unused_webpack_exports, __webpack_require__) {
        module.exports = __webpack_require__.p + "resources/common_add.png";
        /***/    },
    /***/
    "./src/resources/common_close.png": 
    /*!****************************************!*\
    !*** ./src/resources/common_close.png ***!
    \****************************************/
    /***/
    function srcResourcesCommon_closePng(module) {
        module.exports = "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAC0AAAAtCAYAAAA6GuKaAAAACXBIWXMAACE4AAAhOAFFljFgAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAJtSURBVHgBzdk/b9NAGAbw93xKhLxUomtVJIvCGsliaJoy1DBmZWbtzOdg5UN0YQgjFhkalcVSV7pk7ELXoKZqDj+Bk1K3/nN3r315Fl/ss/XT5RK/ZwvKE8dxGIbPD9Hu91eXaZre0BYFPmyzLFtgK5Ik2V0u6ZNStLveIeim36fP2wI/Onr3QQiVoK2USGez72dyb+/lUCn1ZqNfuFrR4OAgupzP53/IY46PTz7mm7f6cz6g0f5+dBU81RmjjtHHt0CeAnA+soePj6jXwWLx7AJT4tEhj/ByMCJ+yevrqztMBUyJfE9Y6NH5VKkG0+T8PL2QaAG0DfAG4G9oSL3HN7wpmDbRiC+4CZiKaKRruCmYnkIjXcFtwFSGRtqG24KpCo20BXcBUx0a4Ya7gqkJGuGCc4CpKRpxhXOByQSN2MI5wWSKRkzh3GBEkGWKi4cHF/2/kFgu1ZgbvL4+OaQaLhb54iIsOdUajBhPj83UTJVeyWlOYMQJjdTAi3EGI85oRMPv7ykp6/NvUZp+JYYExBT86KqOB4EacC3dWEa65m9Nh606dEY3BOuwwJ3QVWClVmkQiB1qoay1ntN1d7rZ7McZbjBtPJ6wGummt+a26nFjtGkt0QbcCG1b/HDDG6NdqzVOeCM0V3nJBa9Fc9fDHHDZJVjHFS67Buu4wKUPsI4tXPoC69jApU+wjilc+gbrmMDXBRNee/kE6+A1YFWRdXsrTtGWcTwOe72705LrdAbWqRnxnSh68bOqNO0crFM24vg8nU5/B1k2wavbSeE8b2CdIhzPUaTsf3nQaTh8PxiNTsajUfKKtizFxcJfBhwAztVTqeUAAAAASUVORK5CYII=";
        /***/    },
    /***/
    "./src/resources/common_options.png": 
    /*!******************************************!*\
    !*** ./src/resources/common_options.png ***!
    \******************************************/
    /***/
    function srcResourcesCommon_optionsPng(module) {
        module.exports = "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAEgAAABICAYAAABV7bNHAAAArklEQVR4Ae3WgQXDQBQG4IyQETpaxqgEvc0yQkbIKK8ngkDrhaKe7+NXOP9Pq+4GygAAAAAAAAAAaDEOc7yGJdb+GWe2nqluZ3700Qf2nviQ/ThTsTPl++h1fCzXmRideiKZVqozZYktPbzEWqUz7yjNp1SnL+gXzusyma1KZ94c7cbwVKoz//BKXp/FOvOeiQdYP1Oy8/ab6HKdnv/7dvx61TsBAAAAAAAAAPgzb+B0iU2ihtPJAAAAAElFTkSuQmCC";
        /***/    },
    /***/
    "./src/resources/wheel_edit.png": 
    /*!**************************************!*\
    !*** ./src/resources/wheel_edit.png ***!
    \**************************************/
    /***/
    function srcResourcesWheel_editPng(module) {
        module.exports = "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAEIAAABCCAMAAADUivDaAAAAVFBMVEUAAAAAfP8Ae/8Ae/8Aev8Ae/8Aef8Aev8Ae/8Aev8Aev8Aev8Aev8Aef8Ae/8AgP8Aev8Aev8AeP8AgP8Aev8Aef8AgP8Ae/8Aev8AfP8AfP8Aev8X4T0pAAAAG3RSTlMAQL/vMJ+gYHDff5CAcI8Q758gIK9QMM+wr29AiH+IAAABXklEQVR4Xu3Wy27DIBCG0RlICji+tGnSG+//npWwfmEHHDKeTSvlW3hjzTG2F0D/N/bj6FkDmJgKbq8wRhS7fcJbXDQqBMT7BWtnwlBuckdTy9UEy0TO3izjx8aN+opwSD8mEUPWN3utCan01BPNdbFFrIWSeI936rcEt3yR4wx8mrLLsCUcVp8zAYGpVkMIlPpIhJMLeYqxIrnQU0EIhRdaEwoBhEIAoRBAKAQQCgGEQgChEEAoBBAKAYRCAKEQQCgEEDKhTXQtoU3YhtAmuCF01nYNwifiuiU4bEJ3CIMdpCLg9td9Ig2ZugDClESBDoUgIHxGOQsSAp+CvbERgpCYB9MVgoCAiSAICV8IYsKsANuTnPjO48aDlhFcjIsJcuaC8b0EehJP4qohzhHoQ+HMflqiIRlHfrDOlsflPu4o0LIpRHmOELYKaSe66RwUAnICxBqmahM/2GGiP9gv8C2DzngfJdAAAAAASUVORK5CYII=";
        /***/    }
} ]); //# sourceMappingURL=common.js.map