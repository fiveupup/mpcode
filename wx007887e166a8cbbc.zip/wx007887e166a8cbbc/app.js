require("./prebundle/vendors-node_modules_taro_weapp_prebundle_taro-ui_js.js");

require("./prebundle/vendors-node_modules_taro_weapp_prebundle_chunk-T2AYW4TD_js.js");

require("./prebundle/vendors-node_modules_taro_weapp_prebundle_chunk-QJTHDQW2_js.js");

require("./prebundle/vendors-node_modules_taro_weapp_prebundle_reduxjs_toolkit_js.js");

require("./prebundle/vendors-node_modules_taro_weapp_prebundle_react-redux_js.js");

require("./prebundle/vendors-node_modules_taro_weapp_prebundle_chunk-SDA3B354_js.js");

require("./prebundle/vendors-node_modules_taro_weapp_prebundle_chunk-MPOY2A6B_js.js");

require("./prebundle/vendors-node_modules_taro_weapp_prebundle_class-transformer_js.js");

require("./prebundle/vendors-node_modules_taro_weapp_prebundle_tarojs_plugin-framework-react_dist_runtime_js.js");

require("./prebundle/vendors-node_modules_taro_weapp_prebundle_tarojs_plugin-platform-weapp_dist_runtime_js.js");

require("./prebundle/vendors-node_modules_taro_weapp_prebundle_chunk-LNJCN3VW_js.js");

require("./prebundle/remoteEntry.js");

require("./prebundle/node_modules_taro_weapp_prebundle_tarojs_runtime_js.js");

require("./prebundle/node_modules_taro_weapp_prebundle_react_jsx-runtime_js.js");

require("./prebundle/node_modules_taro_weapp_prebundle_react_js.js");

require("./prebundle/node_modules_taro_weapp_prebundle_react-dom_js.js");

require("./prebundle/node_modules_taro_weapp_prebundle_tarojs_taro_js.js");

require("./common");

require("./vendors");

require("./taro");

require("./runtime");

(wx["webpackJsonp"] = wx["webpackJsonp"] || []).push([ [ "app" ], {
    /***/
    "./node_modules/babel-loader/lib/index.js??ruleSet[1].rules[5].use[0]!./src/app.tsx": 
    /*!******************************************************************************************!*\
    !*** ./node_modules/babel-loader/lib/index.js??ruleSet[1].rules[5].use[0]!./src/app.tsx ***!
    \******************************************************************************************/
    /***/
    function node_modulesBabelLoaderLibIndexJsRuleSet1Rules5Use0SrcAppTsx(__unused_webpack_module, __webpack_exports__, __webpack_require__) {
        /* harmony import */
        var _Users_Nix_Developer_DecisionTaro_node_modules_babel_runtime_helpers_esm_classCallCheck_js__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(
        /*! ./node_modules/@babel/runtime/helpers/esm/classCallCheck.js */
        "./node_modules/@babel/runtime/helpers/esm/classCallCheck.js");
        /* harmony import */        var _Users_Nix_Developer_DecisionTaro_node_modules_babel_runtime_helpers_esm_createClass_js__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(
        /*! ./node_modules/@babel/runtime/helpers/esm/createClass.js */
        "./node_modules/@babel/runtime/helpers/esm/createClass.js");
        /* harmony import */        var _Users_Nix_Developer_DecisionTaro_node_modules_babel_runtime_helpers_esm_inherits_js__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
        /*! ./node_modules/@babel/runtime/helpers/esm/inherits.js */
        "./node_modules/@babel/runtime/helpers/esm/inherits.js");
        /* harmony import */        var _Users_Nix_Developer_DecisionTaro_node_modules_babel_runtime_helpers_esm_createSuper_js__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(
        /*! ./node_modules/@babel/runtime/helpers/esm/createSuper.js */
        "./node_modules/@babel/runtime/helpers/esm/createSuper.js");
        /* harmony import */        var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
        /*! react */
        "webpack/container/remote/react");
        /* harmony import */        var react__WEBPACK_IMPORTED_MODULE_0___default = /* */ __webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
        /* harmony import */        var react_redux__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
        /*! react-redux */
        "webpack/container/remote/react-redux");
        /* harmony import */        var react_redux__WEBPACK_IMPORTED_MODULE_1___default = /* */ __webpack_require__.n(react_redux__WEBPACK_IMPORTED_MODULE_1__);
        /* harmony import */        var _state_store__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
        /*! ./state/store */
        "./src/state/store.ts");
        /* harmony import */        var _state_persistent__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
        /*! ./state/persistent */
        "./src/state/persistent.ts");
        /* harmony import */        var _tarojs_taro__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
        /*! @tarojs/taro */
        "webpack/container/remote/@tarojs/taro");
        /* harmony import */        var _tarojs_taro__WEBPACK_IMPORTED_MODULE_4___default = /* */ __webpack_require__.n(_tarojs_taro__WEBPACK_IMPORTED_MODULE_4__);
        /* harmony import */        var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
        /*! react/jsx-runtime */
        "webpack/container/remote/react/jsx-runtime");
        /* harmony import */        var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5___default = /* */ __webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__);
        var App = /* */ function(_Component) {
            (0, _Users_Nix_Developer_DecisionTaro_node_modules_babel_runtime_helpers_esm_inherits_js__WEBPACK_IMPORTED_MODULE_6__["default"])(App, _Component);
            var _super = (0, _Users_Nix_Developer_DecisionTaro_node_modules_babel_runtime_helpers_esm_createSuper_js__WEBPACK_IMPORTED_MODULE_7__["default"])(App);
            function App() {
                (0, _Users_Nix_Developer_DecisionTaro_node_modules_babel_runtime_helpers_esm_classCallCheck_js__WEBPACK_IMPORTED_MODULE_8__["default"])(this, App);
                return _super.apply(this, arguments);
            }
            (0, _Users_Nix_Developer_DecisionTaro_node_modules_babel_runtime_helpers_esm_createClass_js__WEBPACK_IMPORTED_MODULE_9__["default"])(App, [ {
                key: "componentDidMount",
                value: function componentDidMount() {
                    _state_store__WEBPACK_IMPORTED_MODULE_2__["default"].subscribe(function() {
                        (0, _state_persistent__WEBPACK_IMPORTED_MODULE_3__.saveState)(_state_store__WEBPACK_IMPORTED_MODULE_2__["default"].getState());
                    });
                    if (true) {
                        console.log("[app] Init cloud for weapp");
                        _tarojs_taro__WEBPACK_IMPORTED_MODULE_4___default().cloud.init({
                            env: "decision-mini-4gds6nmd40ed7a03"
                        });
                    }
                }
            }, {
                key: "componentDidShow",
                value: function componentDidShow() {}
            }, {
                key: "componentDidHide",
                value: function componentDidHide() {}
            }, {
                key: "render",
                value: function render() {
                    /* */
                    return (0, react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__.jsx)(react_redux__WEBPACK_IMPORTED_MODULE_1__.Provider, {
                        store: _state_store__WEBPACK_IMPORTED_MODULE_2__["default"],
                        children: this.props.children
                    });
                }
            } ]);
            return App;
        }(react__WEBPACK_IMPORTED_MODULE_0__.Component);
        /* harmony default export */        __webpack_exports__["default"] = App;
        /***/    },
    /***/
    "./src/app.tsx": 
    /*!*********************!*\
    !*** ./src/app.tsx ***!
    \*********************/
    /***/
    function srcAppTsx(__unused_webpack_module, __unused_webpack___webpack_exports__, __webpack_require__) {
        /* harmony import */
        var _tarojs_plugin_platform_weapp_dist_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
        /*! @tarojs/plugin-platform-weapp/dist/runtime */
        "webpack/container/remote/@tarojs/plugin-platform-weapp/dist/runtime");
        /* harmony import */        var _tarojs_plugin_platform_weapp_dist_runtime__WEBPACK_IMPORTED_MODULE_0___default = /* */ __webpack_require__.n(_tarojs_plugin_platform_weapp_dist_runtime__WEBPACK_IMPORTED_MODULE_0__);
        /* harmony import */        var _tarojs_runtime__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
        /*! @tarojs/runtime */
        "webpack/container/remote/@tarojs/runtime");
        /* harmony import */        var _tarojs_runtime__WEBPACK_IMPORTED_MODULE_1___default = /* */ __webpack_require__.n(_tarojs_runtime__WEBPACK_IMPORTED_MODULE_1__);
        /* harmony import */        var _tarojs_plugin_framework_react_dist_runtime__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
        /*! @tarojs/plugin-framework-react/dist/runtime */
        "webpack/container/remote/@tarojs/plugin-framework-react/dist/runtime");
        /* harmony import */        var _tarojs_plugin_framework_react_dist_runtime__WEBPACK_IMPORTED_MODULE_2___default = /* */ __webpack_require__.n(_tarojs_plugin_framework_react_dist_runtime__WEBPACK_IMPORTED_MODULE_2__);
        /* harmony import */        var _tarojs_taro__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
        /*! @tarojs/taro */
        "webpack/container/remote/@tarojs/taro");
        /* harmony import */        var _tarojs_taro__WEBPACK_IMPORTED_MODULE_3___default = /* */ __webpack_require__.n(_tarojs_taro__WEBPACK_IMPORTED_MODULE_3__);
        /* harmony import */        var _node_modules_babel_loader_lib_index_js_ruleSet_1_rules_5_use_0_app_tsx__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
        /*! ../node_modules/babel-loader/lib/index.js??ruleSet[1].rules[5].use[0]!./app.tsx */
        "./node_modules/babel-loader/lib/index.js??ruleSet[1].rules[5].use[0]!./src/app.tsx");
        /* harmony import */        var react__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
        /*! react */
        "webpack/container/remote/react");
        /* harmony import */        var react__WEBPACK_IMPORTED_MODULE_5___default = /* */ __webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_5__);
        /* harmony import */        var react_dom__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
        /*! react-dom */
        "webpack/container/remote/react-dom");
        /* harmony import */        var react_dom__WEBPACK_IMPORTED_MODULE_6___default = /* */ __webpack_require__.n(react_dom__WEBPACK_IMPORTED_MODULE_6__);
        var config = {
            pages: [ "pages/wheel/index", "pages/decisionlist/index", "pages/decisioncenter/index", "pages/settings/index", "pages/edit/index", "pages/getapp/index" ],
            tabBar: {
                color: "#000000",
                backgroundColor: "#f9f9f9",
                selectedColor: "#007aff",
                list: [ {
                    pagePath: "pages/wheel/index",
                    text: "转盘",
                    iconPath: "resources/tab_wheel.png",
                    selectedIconPath: "resources/tab_wheel_selected.png"
                }, {
                    pagePath: "pages/decisionlist/index",
                    text: "决定",
                    iconPath: "resources/tab_list.png",
                    selectedIconPath: "resources/tab_list_selected.png"
                }, {
                    pagePath: "pages/decisioncenter/index",
                    text: "决定中心",
                    iconPath: "resources/tab_center.png",
                    selectedIconPath: "resources/tab_center_selected.png"
                }, {
                    pagePath: "pages/settings/index",
                    text: "设置",
                    iconPath: "resources/tab_settings.png",
                    selectedIconPath: "resources/tab_settings_selected.png"
                } ]
            },
            window: {
                backgroundTextStyle: "light",
                navigationBarBackgroundColor: "#fff",
                navigationBarTitleText: "WeChat",
                navigationBarTextStyle: "black"
            }
        };
        _tarojs_runtime__WEBPACK_IMPORTED_MODULE_1__.window.__taroAppConfig = config;
        var inst = App((0, _tarojs_plugin_framework_react_dist_runtime__WEBPACK_IMPORTED_MODULE_2__.createReactApp)(_node_modules_babel_loader_lib_index_js_ruleSet_1_rules_5_use_0_app_tsx__WEBPACK_IMPORTED_MODULE_4__["default"], react__WEBPACK_IMPORTED_MODULE_5__, react_dom__WEBPACK_IMPORTED_MODULE_6___default(), config));
        (0, _tarojs_taro__WEBPACK_IMPORTED_MODULE_3__.initPxTransform)({
            designWidth: 750,
            deviceRatio: {
                640: 1.17,
                750: 1,
                828: .905
            }
        });
        /***/    },
    /***/
    "./src/state/migration.ts": 
    /*!********************************!*\
    !*** ./src/state/migration.ts ***!
    \********************************/
    /***/
    function srcStateMigrationTs(__unused_webpack_module, __webpack_exports__, __webpack_require__) {
        /* harmony export */
        __webpack_require__.d(__webpack_exports__, {
            /* harmony export */
            migrateIfNeeded: function migrateIfNeeded() {
                /* binding */
                return _migrateIfNeeded;
            }
            /* harmony export */        });
        /* harmony import */        var _tarojs_taro__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
        /*! @tarojs/taro */
        "webpack/container/remote/@tarojs/taro");
        /* harmony import */        var _tarojs_taro__WEBPACK_IMPORTED_MODULE_0___default = /* */ __webpack_require__.n(_tarojs_taro__WEBPACK_IMPORTED_MODULE_0__);
        /* harmony import */        var _persistent__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
        /*! ./persistent */
        "./src/state/persistent.ts");
        function _migrateIfNeeded() {
            var fs = _tarojs_taro__WEBPACK_IMPORTED_MODULE_0___default().getFileSystemManager();
            var filePath = "".concat(_tarojs_taro__WEBPACK_IMPORTED_MODULE_0___default().env.USER_DATA_PATH, "/decision_user_data.json");
            try {
                var content = fs.readFileSync(filePath, "utf-8");
                var userData = JSON.parse(content);
                console.log("[migration] Loaded ".concat(userData.decisions.length, " decisions"));
                var state = {
                    decision: {
                        decisions: userData.decisions,
                        keyDecisionId: userData.keyDecisionId
                    },
                    settings: {
                        isSoundEnabled: userData.settings.isSoundEnabled,
                        isHapticEnabled: userData.settings.isHapticEnabled,
                        wheelSpinDuration: userData.settings.wheelSpinDuration
                    }
                };
                (0, _persistent__WEBPACK_IMPORTED_MODULE_1__.saveState)(state);
                return state;
            } catch (e) {
                console.log("[migration] Legacy file not exist, skip");
                return undefined;
            }
        }
        /***/    },
    /***/
    "./src/state/persistent.ts": 
    /*!*********************************!*\
    !*** ./src/state/persistent.ts ***!
    \*********************************/
    /***/
    function srcStatePersistentTs(__unused_webpack_module, __webpack_exports__, __webpack_require__) {
        /* harmony export */
        __webpack_require__.d(__webpack_exports__, {
            /* harmony export */
            saveState: function saveState() {
                /* binding */
                return _saveState;
            },
            /* harmony export */
            loadState: function loadState() {
                /* binding */
                return _loadState;
            }
            /* harmony export */        });
        /* harmony import */        var _tarojs_taro__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
        /*! @tarojs/taro */
        "webpack/container/remote/@tarojs/taro");
        /* harmony import */        var _tarojs_taro__WEBPACK_IMPORTED_MODULE_0___default = /* */ __webpack_require__.n(_tarojs_taro__WEBPACK_IMPORTED_MODULE_0__);
        /* harmony import */        var _migration__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
        /*! ./migration */
        "./src/state/migration.ts");
        // https://dev.to/igorovic/simplest-way-to-persist-redux-state-to-localstorage-e67
                function getFilePath() {
            return "".concat(_tarojs_taro__WEBPACK_IMPORTED_MODULE_0___default().env.USER_DATA_PATH, "/decision_state.json");
        }
        function _saveState(state) {
            console.log("[persistent] Save state");
            var fs = _tarojs_taro__WEBPACK_IMPORTED_MODULE_0___default().getFileSystemManager();
            fs.writeFile({
                filePath: getFilePath(),
                data: JSON.stringify(state),
                encoding: "utf8"
            });
        }
        function _loadState() {
            console.log("[persistent] Load state");
            var fs = _tarojs_taro__WEBPACK_IMPORTED_MODULE_0___default().getFileSystemManager();
            try {
                var stateString = fs.readFileSync(getFilePath(), "utf-8");
                var state = JSON.parse(stateString);
                if (state !== undefined) {
                    console.log("[persistent] Load state successfully");
                }
                return state;
            } catch (e) {
                console.log("[persistent] Failed to read file, try load legacy data");
                var _state = (0, _migration__WEBPACK_IMPORTED_MODULE_1__.migrateIfNeeded)();
                if (_state !== undefined) {
                    console.log("[persistent] Use migrated state");
                    return _state;
                }
                console.log("[persistent] No legacy data loaded");
                return undefined;
            }
        }
        /***/    },
    /***/
    "./src/state/store.ts": 
    /*!****************************!*\
    !*** ./src/state/store.ts ***!
    \****************************/
    /***/
    function srcStateStoreTs(__unused_webpack_module, __webpack_exports__, __webpack_require__) {
        /* harmony import */
        var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
        /*! @reduxjs/toolkit */
        "webpack/container/remote/@reduxjs/toolkit");
        /* harmony import */        var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0___default = /* */ __webpack_require__.n(_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__);
        /* harmony import */        var _reducers_decision__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
        /*! ./reducers/decision */
        "./src/state/reducers/decision.ts");
        /* harmony import */        var _reducers_settings__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
        /*! ./reducers/settings */
        "./src/state/reducers/settings.ts");
        /* harmony import */        var _persistent__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
        /*! ./persistent */
        "./src/state/persistent.ts");
        // https://redux-toolkit.js.org/usage/usage-guide
                var store = (0, _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.configureStore)({
            reducer: {
                decision: _reducers_decision__WEBPACK_IMPORTED_MODULE_1__["default"],
                settings: _reducers_settings__WEBPACK_IMPORTED_MODULE_2__["default"]
            },
            preloadedState: (0, _persistent__WEBPACK_IMPORTED_MODULE_3__.loadState)()
        });
        // 导出 Store 中的状态（state）类型
        // 导出更改状态的 Dispatch 方法类型
        // 默认导出 store，用于全局的 Provieder 消费
        /* harmony default export */        __webpack_exports__["default"] = store;
        /***/    }
}, 
/******/
function(__webpack_require__) {
    // webpackRuntimeModules
    /******/
    var __webpack_exec__ = function __webpack_exec__(moduleId) {
        return __webpack_require__(__webpack_require__.s = moduleId);
    };
    /******/    __webpack_require__.O(0, [ "vendors", "common" ], function() {
        return __webpack_exec__("./src/app.tsx");
    });
    /******/    var __webpack_exports__ = __webpack_require__.O();
    /******/} ]);
//# sourceMappingURL=app.js.map