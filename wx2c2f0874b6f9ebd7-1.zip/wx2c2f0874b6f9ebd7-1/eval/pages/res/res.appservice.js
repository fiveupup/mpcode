$gwx0_XC_3=function(_,_v,_n,_p,_s,_wp,_wl,$gwn,$gwl,$gwh,wh,$gstack,$gwrt,gra,grb,TestTest,wfor,_ca,_da,_r,_rz,_o,_oz,_1,_1z,_2,_2z,_m,_mz,nv_getDate,nv_getRegExp,nv_console,nv_parseInt,nv_parseFloat,nv_isNaN,nv_isFinite,nv_decodeURI,nv_decodeURIComponent,nv_encodeURI,nv_encodeURIComponent,$gdc,nv_JSON,_af,_gv,_ai,_grp,_gd,_gapi,$ixc,_ic,_w,_ev,_tsd){return function(path,global){
if(typeof global==='undefined'){if (typeof __GWX_GLOBAL__==='undefined')global={};else global=__GWX_GLOBAL__;}if(typeof __WXML_GLOBAL__ === 'undefined') {__WXML_GLOBAL__={};
}__WXML_GLOBAL__.modules = __WXML_GLOBAL__.modules || {};
var e_={}
if(typeof(global.entrys)==='undefined')global.entrys={};e_=global.entrys;
var d_={}
if(typeof(global.defines)==='undefined')global.defines={};d_=global.defines;
var f_={}
if(typeof(global.modules)==='undefined')global.modules={};f_=global.modules || {};
var p_={}
__WXML_GLOBAL__.ops_cached = __WXML_GLOBAL__.ops_cached || {}
__WXML_GLOBAL__.ops_set = __WXML_GLOBAL__.ops_set || {};
__WXML_GLOBAL__.ops_init = __WXML_GLOBAL__.ops_init || {};
var z=__WXML_GLOBAL__.ops_set.$gwx0_XC_3 || [];
function gz$gwx0_XC_3_1(){
if( __WXML_GLOBAL__.ops_cached.$gwx0_XC_3_1)return __WXML_GLOBAL__.ops_cached.$gwx0_XC_3_1
__WXML_GLOBAL__.ops_cached.$gwx0_XC_3_1=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
Z([3,'backPress'])
Z([3,'background: #FEE7DF'])
Z([3,'测评结果'])
Z([[2,'==='],[[7],[3,'scaleType']],[1,1]])
Z([3,'flex justify-between py-2'])
Z([3,'againHandle'])
Z([3,'#E13F37'])
Z([3,'width: 330rpx;'])
Z(z[6])
Z(z[7])
})(__WXML_GLOBAL__.ops_cached.$gwx0_XC_3_1);return __WXML_GLOBAL__.ops_cached.$gwx0_XC_3_1
}
__WXML_GLOBAL__.ops_set.$gwx0_XC_3=z;
__WXML_GLOBAL__.ops_init.$gwx0_XC_3=true;
var x=['./eval/pages/res/res.wxml'];d_[x[0]]={}
var m0=function(e,s,r,gg){
var z=gz$gwx0_XC_3_1()
var b3=_n('van-sticky')
var o4=_mz(z,'van-nav-bar',['leftArrow',-1,'bind:click-left',0,'customStyle',1,'title',1],[],e,s,gg)
_(b3,o4)
_(r,b3)
var e2=_v()
_(r,e2)
if(_oz(z,3,e,s,gg)){e2.wxVkey=1
}
var x5=_n('view')
_rz(z,x5,'class',4,e,s,gg)
var o6=_mz(z,'van-button',['block',-1,'plain',-1,'round',-1,'bind:tap',5,'color',1,'style',2],[],e,s,gg)
_(x5,o6)
var f7=_mz(z,'van-button',['block',-1,'round',-1,'color',8,'style',1],[],e,s,gg)
_(x5,f7)
_(r,x5)
e2.wxXCkey=1
return r
}
e_[x[0]]={f:m0,j:[],i:[],ti:[],ic:[]}
if(path&&e_[path]){
return function(env,dd,global){$gwxc=0;var root={"tag":"wx-page"};root.children=[]
;g="$gwx0_XC_3";var main=e_[path].f
if (typeof global==="undefined")global={};global.f=$gdc(f_[path],"",1);
try{
main(env,{},root,global);
_tsd(root)
}catch(err){
console.log(err)
}
;g="";
return root;
}
}
}
}(__g.a,__g.b,__g.c,__g.d,__g.e,__g.f,__g.g,__g.h,__g.i,__g.j,__g.k,__g.l,__g.m,__g.n,__g.o,__g.p,__g.q,__g.r,__g.s,__g.t,__g.u,__g.v,__g.w,__g.x,__g.y,__g.z,__g.A,__g.B,__g.C,__g.D,__g.E,__g.F,__g.G,__g.H,__g.I,__g.J,__g.K,__g.L,__g.M,__g.N,__g.O,__g.P,__g.Q,__g.R,__g.S,__g.T,__g.U,__g.V,__g.W,__g.X,__g.Y,__g.Z,__g.aa);if(__vd_version_info__.delayedGwx||false)$gwx0_XC_3();	if (__vd_version_info__.delayedGwx) __wxAppCode__['eval/pages/res/res.wxml'] = [$gwx0_XC_3, './eval/pages/res/res.wxml'];else __wxAppCode__['eval/pages/res/res.wxml'] = $gwx0_XC_3( './eval/pages/res/res.wxml' );
	;__wxRoute = "eval/pages/res/res";__wxRouteBegin = true;__wxAppCurrentFile__="eval/pages/res/res.js";define("eval/pages/res/res.js",function(require,module,exports,window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){
"use strict";var e=require("../../../@babel/runtime/helpers/interopRequireWildcard").default,t=require("../../../@babel/runtime/helpers/regeneratorRuntime"),a=require("../../../@babel/runtime/helpers/objectSpread2"),r=require("../../../@babel/runtime/helpers/asyncToGenerator"),i=(e(require("components/ec-canvas/echarts")),require("../../../requset/index")),s=require("../../../utils/index");Page({data:{imgBaseUrl:s.imgBaseUrl,ec:{onInit:""},type:"1",scaId:"",safeAreaBottomHeight:"0px",scaTitle:"",scaPicture:""},onLoad:function(e){var t=e.id,a=e.type,r=wx.getSystemInfoSync(),i=r.safeArea,s=r.windowHeight;this.setData({type:a,safeAreaBottomHeight:s-i.bottom+"px"}),this.init(t)},backPress:function(){var e=this.data,t=e.type,a=e.scaId;"1"===t?(0,s.authReLaunchJump)("/eval/pages/start/start?id="+a):wx.navigateBack()},init:function(e){var s=this;return r(t().mark((function r(){var n,c,u;return t().wrap((function(t){for(;;)switch(t.prev=t.next){case 0:if("1"!==s.data.type){t.next=4;break}return t.next=4,(0,i.saveReport)(e);case 4:return t.next=6,(0,i.getReport)(e);case 6:n=t.sent,c=n.code,u=n.data,1e4===c&&s.setData(a({scaTitle:u.scaleRecord.scaleTitle},u));case 10:case"end":return t.stop()}}),r)})))()},againHandle:function(){var e=this.data.scaId;(0,s.authReLaunchJump)("/eval/pages/start/start?id="+e)},onShareAppMessage:function(){return{title:this.data.scaTitle,path:"/eval/pages/start/start?id="+this.data.scaId,imageUrl:this.data.scaPicture}},onShareTimeline:function(){return{title:this.data.scaTitle,path:"/eval/pages/start/start?id="+this.data.scaId,imageUrl:this.data.scaPicture}}});
},{isPage:true,isComponent:true,currentFile:'eval/pages/res/res.js'});require("eval/pages/res/res.js");