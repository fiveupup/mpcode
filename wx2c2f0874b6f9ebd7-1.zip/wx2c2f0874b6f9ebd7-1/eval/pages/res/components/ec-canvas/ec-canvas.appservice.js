$gwx0_XC_2=function(_,_v,_n,_p,_s,_wp,_wl,$gwn,$gwl,$gwh,wh,$gstack,$gwrt,gra,grb,TestTest,wfor,_ca,_da,_r,_rz,_o,_oz,_1,_1z,_2,_2z,_m,_mz,nv_getDate,nv_getRegExp,nv_console,nv_parseInt,nv_parseFloat,nv_isNaN,nv_isFinite,nv_decodeURI,nv_decodeURIComponent,nv_encodeURI,nv_encodeURIComponent,$gdc,nv_JSON,_af,_gv,_ai,_grp,_gd,_gapi,$ixc,_ic,_w,_ev,_tsd){return function(path,global){
if(typeof global==='undefined'){if (typeof __GWX_GLOBAL__==='undefined')global={};else global=__GWX_GLOBAL__;}if(typeof __WXML_GLOBAL__ === 'undefined') {__WXML_GLOBAL__={};
}__WXML_GLOBAL__.modules = __WXML_GLOBAL__.modules || {};
var e_={}
if(typeof(global.entrys)==='undefined')global.entrys={};e_=global.entrys;
var d_={}
if(typeof(global.defines)==='undefined')global.defines={};d_=global.defines;
var f_={}
if(typeof(global.modules)==='undefined')global.modules={};f_=global.modules || {};
var p_={}
__WXML_GLOBAL__.ops_cached = __WXML_GLOBAL__.ops_cached || {}
__WXML_GLOBAL__.ops_set = __WXML_GLOBAL__.ops_set || {};
__WXML_GLOBAL__.ops_init = __WXML_GLOBAL__.ops_init || {};
var z=__WXML_GLOBAL__.ops_set.$gwx0_XC_2 || [];
function gz$gwx0_XC_2_1(){
if( __WXML_GLOBAL__.ops_cached.$gwx0_XC_2_1)return __WXML_GLOBAL__.ops_cached.$gwx0_XC_2_1
__WXML_GLOBAL__.ops_cached.$gwx0_XC_2_1=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
})(__WXML_GLOBAL__.ops_cached.$gwx0_XC_2_1);return __WXML_GLOBAL__.ops_cached.$gwx0_XC_2_1
}
__WXML_GLOBAL__.ops_set.$gwx0_XC_2=z;
__WXML_GLOBAL__.ops_init.$gwx0_XC_2=true;
var x=['./eval/pages/res/components/ec-canvas/ec-canvas.wxml'];d_[x[0]]={}
var m0=function(e,s,r,gg){
var z=gz$gwx0_XC_2_1()
return r
}
e_[x[0]]={f:m0,j:[],i:[],ti:[],ic:[]}
if(path&&e_[path]){
return function(env,dd,global){$gwxc=0;var root={"tag":"wx-page"};root.children=[]
;g="$gwx0_XC_2";var main=e_[path].f
if (typeof global==="undefined")global={};global.f=$gdc(f_[path],"",1);
try{
main(env,{},root,global);
_tsd(root)
}catch(err){
console.log(err)
}
;g="";
return root;
}
}
}
}(__g.a,__g.b,__g.c,__g.d,__g.e,__g.f,__g.g,__g.h,__g.i,__g.j,__g.k,__g.l,__g.m,__g.n,__g.o,__g.p,__g.q,__g.r,__g.s,__g.t,__g.u,__g.v,__g.w,__g.x,__g.y,__g.z,__g.A,__g.B,__g.C,__g.D,__g.E,__g.F,__g.G,__g.H,__g.I,__g.J,__g.K,__g.L,__g.M,__g.N,__g.O,__g.P,__g.Q,__g.R,__g.S,__g.T,__g.U,__g.V,__g.W,__g.X,__g.Y,__g.Z,__g.aa);if(__vd_version_info__.delayedGwx||false)$gwx0_XC_2();	if (__vd_version_info__.delayedGwx) __wxAppCode__['eval/pages/res/components/ec-canvas/ec-canvas.wxml'] = [$gwx0_XC_2, './eval/pages/res/components/ec-canvas/ec-canvas.wxml'];else __wxAppCode__['eval/pages/res/components/ec-canvas/ec-canvas.wxml'] = $gwx0_XC_2( './eval/pages/res/components/ec-canvas/ec-canvas.wxml' );
	;__wxRoute = "eval/pages/res/components/ec-canvas/ec-canvas";__wxRouteBegin = true;__wxAppCurrentFile__="eval/pages/res/components/ec-canvas/ec-canvas.js";define("eval/pages/res/components/ec-canvas/ec-canvas.js",function(require,module,exports,window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){
"use strict";var e,t=require("../../../../../@babel/runtime/helpers/interopRequireWildcard").default,a=require("../../../../../@babel/runtime/helpers/interopRequireDefault").default,n=require("../../../../../@babel/runtime/helpers/typeof"),i=a(require("./wx-canvas")),r=t(require("./echarts"));function o(e,t){e=e.split("."),t=t.split(".");for(var a=Math.max(e.length,t.length);e.length<a;)e.push("0");for(;t.length<a;)t.push("0");for(var n=0;n<a;n++){var i=parseInt(e[n]),r=parseInt(t[n]);if(i>r)return 1;if(i<r)return-1}return 0}function s(e){for(var t=0;t<e.touches.length;++t){var a=e.touches[t];a.offsetX=a.x,a.offsetY=a.y}return e}Component({properties:{canvasId:{type:String,value:"ec-canvas"},ec:{type:Object},forceUseOldCanvas:{type:Boolean,value:!1}},data:{isUseNewCanvas:!1},ready:function(){r.registerPreprocessor((function(e){e&&e.series&&(e.series.length>0?e.series.forEach((function(e){e.progressive=0})):"object"===n(e.series)&&(e.series.progressive=0))})),this.data.ec?this.data.ec.lazyLoad||this.init():console.warn('组件需绑定 ec 变量，例：<ec-canvas id="mychart-dom-bar" canvas-id="mychart-bar" ec="{{ ec }}"></ec-canvas>')},methods:{init:function(e){var t=wx.getSystemInfoSync().SDKVersion,a=o(t,"2.9.0")>=0,n=this.data.forceUseOldCanvas,i=a&&!n;if(this.setData({isUseNewCanvas:i}),n&&a&&console.warn("开发者强制使用旧canvas,建议关闭"),i)this.initByNewWay(e);else{if(!(o(t,"1.9.91")>=0))return void console.error("微信基础库版本过低，需大于等于 1.9.91。参见：https://github.com/ecomfe/echarts-for-weixin#%E5%BE%AE%E4%BF%A1%E7%89%88%E6%9C%AC%E8%A6%81%E6%B1%82");console.warn("建议将微信基础库调整大于等于2.9.0版本。升级后绘图将有更好性能"),this.initByOldWay(e)}},initByOldWay:function(t){var a=this;e=wx.createCanvasContext(this.data.canvasId,this);var n=new i.default(e,this.data.canvasId,!1);r.setCanvasCreator((function(){return n}));wx.createSelectorQuery().in(this).select(".ec-canvas").boundingClientRect((function(e){"function"==typeof t?a.chart=t(n,e.width,e.height,1):a.data.ec&&"function"==typeof a.data.ec.onInit?a.chart=a.data.ec.onInit(n,e.width,e.height,1):a.triggerEvent("init",{canvas:n,width:e.width,height:e.height,canvasDpr:1})})).exec()},initByNewWay:function(e){var t=this;wx.createSelectorQuery().in(this).select(".ec-canvas").fields({node:!0,size:!0}).exec((function(a){var n=a[0].node;t.canvasNode=n;var o=wx.getSystemInfoSync().pixelRatio,s=a[0].width,c=a[0].height,h=n.getContext("2d"),u=new i.default(h,t.data.canvasId,!0,n);r.setCanvasCreator((function(){return u})),"function"==typeof e?t.chart=e(u,s,c,o):t.data.ec&&"function"==typeof t.data.ec.onInit?t.chart=t.data.ec.onInit(u,s,c,o):t.triggerEvent("init",{canvas:u,width:s,height:c,dpr:o})}))},canvasToTempFilePath:function(t){var a=this;this.data.isUseNewCanvas?wx.createSelectorQuery().in(this).select(".ec-canvas").fields({node:!0,size:!0}).exec((function(e){var a=e[0].node;t.canvas=a,wx.canvasToTempFilePath(t)})):(t.canvasId||(t.canvasId=this.data.canvasId),e.draw(!0,(function(){wx.canvasToTempFilePath(t,a)})))},touchStart:function(e){if(this.chart&&e.touches.length>0){var t=e.touches[0],a=this.chart.getZr().handler;a.dispatch("mousedown",{zrX:t.x,zrY:t.y,preventDefault:function(){},stopImmediatePropagation:function(){},stopPropagation:function(){}}),a.dispatch("mousemove",{zrX:t.x,zrY:t.y,preventDefault:function(){},stopImmediatePropagation:function(){},stopPropagation:function(){}}),a.processGesture(s(e),"start")}},touchMove:function(e){if(this.chart&&e.touches.length>0){var t=e.touches[0],a=this.chart.getZr().handler;a.dispatch("mousemove",{zrX:t.x,zrY:t.y,preventDefault:function(){},stopImmediatePropagation:function(){},stopPropagation:function(){}}),a.processGesture(s(e),"change")}},touchEnd:function(e){if(this.chart){var t=e.changedTouches?e.changedTouches[0]:{},a=this.chart.getZr().handler;a.dispatch("mouseup",{zrX:t.x,zrY:t.y,preventDefault:function(){},stopImmediatePropagation:function(){},stopPropagation:function(){}}),a.dispatch("click",{zrX:t.x,zrY:t.y,preventDefault:function(){},stopImmediatePropagation:function(){},stopPropagation:function(){}}),a.processGesture(s(e),"end")}}}});
},{isPage:false,isComponent:true,currentFile:'eval/pages/res/components/ec-canvas/ec-canvas.js'});require("eval/pages/res/components/ec-canvas/ec-canvas.js");