$gwx0_XC_4=function(_,_v,_n,_p,_s,_wp,_wl,$gwn,$gwl,$gwh,wh,$gstack,$gwrt,gra,grb,TestTest,wfor,_ca,_da,_r,_rz,_o,_oz,_1,_1z,_2,_2z,_m,_mz,nv_getDate,nv_getRegExp,nv_console,nv_parseInt,nv_parseFloat,nv_isNaN,nv_isFinite,nv_decodeURI,nv_decodeURIComponent,nv_encodeURI,nv_encodeURIComponent,$gdc,nv_JSON,_af,_gv,_ai,_grp,_gd,_gapi,$ixc,_ic,_w,_ev,_tsd){return function(path,global){
if(typeof global==='undefined'){if (typeof __GWX_GLOBAL__==='undefined')global={};else global=__GWX_GLOBAL__;}if(typeof __WXML_GLOBAL__ === 'undefined') {__WXML_GLOBAL__={};
}__WXML_GLOBAL__.modules = __WXML_GLOBAL__.modules || {};
var e_={}
if(typeof(global.entrys)==='undefined')global.entrys={};e_=global.entrys;
var d_={}
if(typeof(global.defines)==='undefined')global.defines={};d_=global.defines;
var f_={}
if(typeof(global.modules)==='undefined')global.modules={};f_=global.modules || {};
var p_={}
__WXML_GLOBAL__.ops_cached = __WXML_GLOBAL__.ops_cached || {}
__WXML_GLOBAL__.ops_set = __WXML_GLOBAL__.ops_set || {};
__WXML_GLOBAL__.ops_init = __WXML_GLOBAL__.ops_init || {};
var z=__WXML_GLOBAL__.ops_set.$gwx0_XC_4 || [];
function gz$gwx0_XC_4_1(){
if( __WXML_GLOBAL__.ops_cached.$gwx0_XC_4_1)return __WXML_GLOBAL__.ops_cached.$gwx0_XC_4_1
__WXML_GLOBAL__.ops_cached.$gwx0_XC_4_1=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
Z([3,'backPress'])
Z([3,'测评详情'])
Z([3,'main-con'])
Z([3,'img'])
Z([3,'aspectFill'])
Z([[7],[3,'scaPicture']])
Z([3,'flex flex-column position-relative align-center info-con bg-white text-2E323C'])
Z([3,'font-lgr mt-5'])
Z([a,[[7],[3,'scaTitle']]])
Z([3,'font-small mt-1'])
Z([a,[[7],[3,'scaUserCount']],[3,'人已测']])
Z([3,'line my-4'])
Z([3,'flex align-center justify-around'])
Z([3,'width: 680rpx;'])
Z([3,'flex flex-column align-center'])
Z([3,'font-lgr font-weight-bolder'])
Z([a,[[7],[3,'scaScaleCount']]])
Z([3,'font-small'])
Z([3,' 道'])
Z([3,'font-small pt-1'])
Z([3,'测试题'])
Z(z[14])
Z(z[15])
Z([a,[[7],[3,'scaAverageFinishTime']]])
Z(z[17])
Z([3,' min'])
Z(z[19])
Z([3,'预计耗时'])
Z(z[14])
Z(z[15])
Z([3,'免费'])
Z(z[19])
Z([3,'价格'])
Z([3,'mt-1 bg-white'])
Z([3,'flex align-center justify-center p-3'])
Z([3,'icon'])
Z([3,'widthFix'])
Z([[2,'+'],[[7],[3,'imgBaseUrl']],[1,'/hejihua-ceping/eval/icon-lt.png']])
Z([3,'font-md font-weight-bolder text-2E323C px-1'])
Z([3,'测评介绍'])
Z(z[35])
Z(z[36])
Z([[2,'+'],[[7],[3,'imgBaseUrl']],[1,'/hejihua-ceping/eval/icon-rt.png']])
Z([3,''])
Z([3,'font-sm'])
Z([[7],[3,'content']])
Z([3,'h-100'])
Z([3,'bg-white fixed-bottom px-3 py-2'])
Z([3,'navigateToHandle'])
Z([3,'#E13F37'])
Z([3,'开始测评'])
})(__WXML_GLOBAL__.ops_cached.$gwx0_XC_4_1);return __WXML_GLOBAL__.ops_cached.$gwx0_XC_4_1
}
__WXML_GLOBAL__.ops_set.$gwx0_XC_4=z;
__WXML_GLOBAL__.ops_init.$gwx0_XC_4=true;
var x=['./eval/pages/start/start.wxml'];d_[x[0]]={}
var m0=function(e,s,r,gg){
var z=gz$gwx0_XC_4_1()
var oVC=_n('van-sticky')
var lWC=_mz(z,'van-nav-bar',['leftArrow',-1,'bind:click-left',0,'title',1],[],e,s,gg)
_(oVC,lWC)
_(r,oVC)
var aXC=_n('view')
_rz(z,aXC,'class',2,e,s,gg)
var tYC=_mz(z,'image',['class',3,'mode',1,'src',2],[],e,s,gg)
_(aXC,tYC)
var eZC=_n('view')
_rz(z,eZC,'class',6,e,s,gg)
var b1C=_n('text')
_rz(z,b1C,'class',7,e,s,gg)
var o2C=_oz(z,8,e,s,gg)
_(b1C,o2C)
_(eZC,b1C)
var x3C=_n('text')
_rz(z,x3C,'class',9,e,s,gg)
var o4C=_oz(z,10,e,s,gg)
_(x3C,o4C)
_(eZC,x3C)
var f5C=_n('view')
_rz(z,f5C,'class',11,e,s,gg)
_(eZC,f5C)
var c6C=_mz(z,'view',['class',12,'style',1],[],e,s,gg)
var h7C=_n('view')
_rz(z,h7C,'class',14,e,s,gg)
var o8C=_n('view')
var c9C=_n('text')
_rz(z,c9C,'class',15,e,s,gg)
var o0C=_oz(z,16,e,s,gg)
_(c9C,o0C)
_(o8C,c9C)
var lAD=_n('text')
_rz(z,lAD,'class',17,e,s,gg)
var aBD=_oz(z,18,e,s,gg)
_(lAD,aBD)
_(o8C,lAD)
_(h7C,o8C)
var tCD=_n('text')
_rz(z,tCD,'class',19,e,s,gg)
var eDD=_oz(z,20,e,s,gg)
_(tCD,eDD)
_(h7C,tCD)
_(c6C,h7C)
var bED=_n('view')
_rz(z,bED,'class',21,e,s,gg)
var oFD=_n('view')
var xGD=_n('text')
_rz(z,xGD,'class',22,e,s,gg)
var oHD=_oz(z,23,e,s,gg)
_(xGD,oHD)
_(oFD,xGD)
var fID=_n('text')
_rz(z,fID,'class',24,e,s,gg)
var cJD=_oz(z,25,e,s,gg)
_(fID,cJD)
_(oFD,fID)
_(bED,oFD)
var hKD=_n('text')
_rz(z,hKD,'class',26,e,s,gg)
var oLD=_oz(z,27,e,s,gg)
_(hKD,oLD)
_(bED,hKD)
_(c6C,bED)
var cMD=_n('view')
_rz(z,cMD,'class',28,e,s,gg)
var oND=_n('text')
_rz(z,oND,'class',29,e,s,gg)
var lOD=_oz(z,30,e,s,gg)
_(oND,lOD)
_(cMD,oND)
var aPD=_n('text')
_rz(z,aPD,'class',31,e,s,gg)
var tQD=_oz(z,32,e,s,gg)
_(aPD,tQD)
_(cMD,aPD)
_(c6C,cMD)
_(eZC,c6C)
_(aXC,eZC)
var eRD=_n('view')
_rz(z,eRD,'class',33,e,s,gg)
var bSD=_n('view')
_rz(z,bSD,'class',34,e,s,gg)
var oTD=_mz(z,'image',['class',35,'mode',1,'src',2],[],e,s,gg)
_(bSD,oTD)
var xUD=_n('text')
_rz(z,xUD,'class',38,e,s,gg)
var oVD=_oz(z,39,e,s,gg)
_(xUD,oVD)
_(bSD,xUD)
var fWD=_mz(z,'image',['class',40,'mode',1,'src',2],[],e,s,gg)
_(bSD,fWD)
_(eRD,bSD)
var cXD=_n('view')
_rz(z,cXD,'class',43,e,s,gg)
var hYD=_mz(z,'rich-text',['class',44,'nodes',1],[],e,s,gg)
_(cXD,hYD)
_(eRD,cXD)
_(aXC,eRD)
_(r,aXC)
var oZD=_n('view')
_rz(z,oZD,'class',46,e,s,gg)
_(r,oZD)
var c1D=_n('view')
_rz(z,c1D,'class',47,e,s,gg)
var o2D=_mz(z,'van-button',['block',-1,'round',-1,'bindtap',48,'color',1],[],e,s,gg)
var l3D=_oz(z,50,e,s,gg)
_(o2D,l3D)
_(c1D,o2D)
_(r,c1D)
return r
}
e_[x[0]]={f:m0,j:[],i:[],ti:[],ic:[]}
if(path&&e_[path]){
outerGlobal.__wxml_comp_version__=0.02
return function(env,dd,global){$gwxc=0;var root={"tag":"wx-page"};root.children=[]
;g="$gwx0_XC_4";var main=e_[path].f
if (typeof global==="undefined")global={};global.f=$gdc(f_[path],"",1);
if(typeof(outerGlobal.__webview_engine_version__)!='undefined'&&outerGlobal.__webview_engine_version__+1e-6>=0.02+1e-6&&outerGlobal.__mergeData__)
{
env=outerGlobal.__mergeData__(env,dd);
}
try{
main(env,{},root,global);
_tsd(root)
if(typeof(outerGlobal.__webview_engine_version__)=='undefined'|| outerGlobal.__webview_engine_version__+1e-6<0.01+1e-6){return _ev(root);}
}catch(err){
console.log(err)
}
;g="";
return root;
}
}
}
}(__g.a,__g.b,__g.c,__g.d,__g.e,__g.f,__g.g,__g.h,__g.i,__g.j,__g.k,__g.l,__g.m,__g.n,__g.o,__g.p,__g.q,__g.r,__g.s,__g.t,__g.u,__g.v,__g.w,__g.x,__g.y,__g.z,__g.A,__g.B,__g.C,__g.D,__g.E,__g.F,__g.G,__g.H,__g.I,__g.J,__g.K,__g.L,__g.M,__g.N,__g.O,__g.P,__g.Q,__g.R,__g.S,__g.T,__g.U,__g.V,__g.W,__g.X,__g.Y,__g.Z,__g.aa);if(__vd_version_info__.delayedGwx||false)$gwx0_XC_4();	if (__vd_version_info__.delayedGwx) __wxAppCode__['eval/pages/start/start.wxml'] = [$gwx0_XC_4, './eval/pages/start/start.wxml'];else __wxAppCode__['eval/pages/start/start.wxml'] = $gwx0_XC_4( './eval/pages/start/start.wxml' );
	
var noCss=typeof __vd_version_info__!=='undefined'&&__vd_version_info__.noCss===true;if(!noCss){__wxAppCode__['eval/pages/start/start.wxss'] = setCssToHead(["body{background-color:#f1f6f7}\n.",[1],"customImg{width:100%}\n.",[1],"img{height:",[0,420],";width:",[0,750],"}\n.",[1],"line{background:#f1f3f8;border-radius:",[0,2],";height:",[0,1],";width:",[0,680],"}\n.",[1],"info-con{border-radius:",[0,16]," ",[0,16]," 0 0;height:",[0,360],";margin-top:",[0,-20],"}\n.",[1],"icon{height:",[0,24],";width:",[0,30],"}\n.",[1],"h-100{height:",[0,100],"}\n",],"Some selectors are not allowed in component wxss, including tag name selectors, ID selectors, and attribute selectors.(./eval/pages/start/start.wxss:1:1)",{path:"./eval/pages/start/start.wxss"});
}