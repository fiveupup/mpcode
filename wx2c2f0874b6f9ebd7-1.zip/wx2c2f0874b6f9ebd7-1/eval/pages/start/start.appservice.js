$gwx0_XC_4=function(_,_v,_n,_p,_s,_wp,_wl,$gwn,$gwl,$gwh,wh,$gstack,$gwrt,gra,grb,TestTest,wfor,_ca,_da,_r,_rz,_o,_oz,_1,_1z,_2,_2z,_m,_mz,nv_getDate,nv_getRegExp,nv_console,nv_parseInt,nv_parseFloat,nv_isNaN,nv_isFinite,nv_decodeURI,nv_decodeURIComponent,nv_encodeURI,nv_encodeURIComponent,$gdc,nv_JSON,_af,_gv,_ai,_grp,_gd,_gapi,$ixc,_ic,_w,_ev,_tsd){return function(path,global){
if(typeof global==='undefined'){if (typeof __GWX_GLOBAL__==='undefined')global={};else global=__GWX_GLOBAL__;}if(typeof __WXML_GLOBAL__ === 'undefined') {__WXML_GLOBAL__={};
}__WXML_GLOBAL__.modules = __WXML_GLOBAL__.modules || {};
var e_={}
if(typeof(global.entrys)==='undefined')global.entrys={};e_=global.entrys;
var d_={}
if(typeof(global.defines)==='undefined')global.defines={};d_=global.defines;
var f_={}
if(typeof(global.modules)==='undefined')global.modules={};f_=global.modules || {};
var p_={}
__WXML_GLOBAL__.ops_cached = __WXML_GLOBAL__.ops_cached || {}
__WXML_GLOBAL__.ops_set = __WXML_GLOBAL__.ops_set || {};
__WXML_GLOBAL__.ops_init = __WXML_GLOBAL__.ops_init || {};
var z=__WXML_GLOBAL__.ops_set.$gwx0_XC_4 || [];
function gz$gwx0_XC_4_1(){
if( __WXML_GLOBAL__.ops_cached.$gwx0_XC_4_1)return __WXML_GLOBAL__.ops_cached.$gwx0_XC_4_1
__WXML_GLOBAL__.ops_cached.$gwx0_XC_4_1=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
Z([3,'backPress'])
Z([3,'测评详情'])
Z([3,'navigateToHandle'])
Z([3,'#E13F37'])
})(__WXML_GLOBAL__.ops_cached.$gwx0_XC_4_1);return __WXML_GLOBAL__.ops_cached.$gwx0_XC_4_1
}
__WXML_GLOBAL__.ops_set.$gwx0_XC_4=z;
__WXML_GLOBAL__.ops_init.$gwx0_XC_4=true;
var x=['./eval/pages/start/start.wxml'];d_[x[0]]={}
var m0=function(e,s,r,gg){
var z=gz$gwx0_XC_4_1()
var h9=_n('van-sticky')
var o0=_mz(z,'van-nav-bar',['leftArrow',-1,'bind:click-left',0,'title',1],[],e,s,gg)
_(h9,o0)
_(r,h9)
var cAB=_mz(z,'van-button',['block',-1,'round',-1,'bindtap',2,'color',1],[],e,s,gg)
_(r,cAB)
return r
}
e_[x[0]]={f:m0,j:[],i:[],ti:[],ic:[]}
if(path&&e_[path]){
return function(env,dd,global){$gwxc=0;var root={"tag":"wx-page"};root.children=[]
;g="$gwx0_XC_4";var main=e_[path].f
if (typeof global==="undefined")global={};global.f=$gdc(f_[path],"",1);
try{
main(env,{},root,global);
_tsd(root)
}catch(err){
console.log(err)
}
;g="";
return root;
}
}
}
}(__g.a,__g.b,__g.c,__g.d,__g.e,__g.f,__g.g,__g.h,__g.i,__g.j,__g.k,__g.l,__g.m,__g.n,__g.o,__g.p,__g.q,__g.r,__g.s,__g.t,__g.u,__g.v,__g.w,__g.x,__g.y,__g.z,__g.A,__g.B,__g.C,__g.D,__g.E,__g.F,__g.G,__g.H,__g.I,__g.J,__g.K,__g.L,__g.M,__g.N,__g.O,__g.P,__g.Q,__g.R,__g.S,__g.T,__g.U,__g.V,__g.W,__g.X,__g.Y,__g.Z,__g.aa);if(__vd_version_info__.delayedGwx||false)$gwx0_XC_4();	if (__vd_version_info__.delayedGwx) __wxAppCode__['eval/pages/start/start.wxml'] = [$gwx0_XC_4, './eval/pages/start/start.wxml'];else __wxAppCode__['eval/pages/start/start.wxml'] = $gwx0_XC_4( './eval/pages/start/start.wxml' );
	;__wxRoute = "eval/pages/start/start";__wxRouteBegin = true;__wxAppCurrentFile__="eval/pages/start/start.js";define("eval/pages/start/start.js",function(require,module,exports,window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){
"use strict";var t=require("../../../@babel/runtime/helpers/objectSpread2"),a=require("../../../requset/index"),e=require("../../../utils/index");Page({data:{imgBaseUrl:e.imgBaseUrl,id:"",safeAreaBottomHeight:"0px",content:""},onLoad:function(t){var a=t.id,e=wx.getSystemInfoSync(),i=e.safeArea,s=e.windowHeight;this.setData({safeAreaBottomHeight:s-i.bottom+"px",id:a}),this.init(a)},backPress:function(){(0,e.authReLaunchJump)("/pages/tabbar/index/index")},init:function(e){var i=this;(0,a.getScaDetail)(e).then((function(a){var e=a.code,s=a.data;if(1e4===e){var r=s.scaSummary.replace(/<img/gi,'<img class="customImg"');i.setData(t({content:r},s))}}))},navigateToHandle:function(){var t="/eval/pages/answer/answer?scaId="+this.data.id;(0,e.authJump)(t)},onShareAppMessage:function(){return{title:this.data.scaTitle,path:"/eval/pages/start/start?id="+this.data.id,imageUrl:this.data.scaPicture}},onShareTimeline:function(){return{title:this.data.scaTitle,path:"/eval/pages/start/start?id="+this.data.id,imageUrl:this.data.scaPicture}}});
},{isPage:true,isComponent:true,currentFile:'eval/pages/start/start.js'});require("eval/pages/start/start.js");