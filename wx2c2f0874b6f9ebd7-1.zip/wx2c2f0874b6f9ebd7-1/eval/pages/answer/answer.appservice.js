$gwx0_XC_0=function(_,_v,_n,_p,_s,_wp,_wl,$gwn,$gwl,$gwh,wh,$gstack,$gwrt,gra,grb,TestTest,wfor,_ca,_da,_r,_rz,_o,_oz,_1,_1z,_2,_2z,_m,_mz,nv_getDate,nv_getRegExp,nv_console,nv_parseInt,nv_parseFloat,nv_isNaN,nv_isFinite,nv_decodeURI,nv_decodeURIComponent,nv_encodeURI,nv_encodeURIComponent,$gdc,nv_JSON,_af,_gv,_ai,_grp,_gd,_gapi,$ixc,_ic,_w,_ev,_tsd){return function(path,global){
if(typeof global==='undefined'){if (typeof __GWX_GLOBAL__==='undefined')global={};else global=__GWX_GLOBAL__;}if(typeof __WXML_GLOBAL__ === 'undefined') {__WXML_GLOBAL__={};
}__WXML_GLOBAL__.modules = __WXML_GLOBAL__.modules || {};
var e_={}
if(typeof(global.entrys)==='undefined')global.entrys={};e_=global.entrys;
var d_={}
if(typeof(global.defines)==='undefined')global.defines={};d_=global.defines;
var f_={}
if(typeof(global.modules)==='undefined')global.modules={};f_=global.modules || {};
var p_={}
__WXML_GLOBAL__.ops_cached = __WXML_GLOBAL__.ops_cached || {}
__WXML_GLOBAL__.ops_set = __WXML_GLOBAL__.ops_set || {};
__WXML_GLOBAL__.ops_init = __WXML_GLOBAL__.ops_init || {};
var z=__WXML_GLOBAL__.ops_set.$gwx0_XC_0 || [];
function gz$gwx0_XC_0_1(){
if( __WXML_GLOBAL__.ops_cached.$gwx0_XC_0_1)return __WXML_GLOBAL__.ops_cached.$gwx0_XC_0_1
__WXML_GLOBAL__.ops_cached.$gwx0_XC_0_1=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
Z([3,'backPress'])
Z([3,'sh'])
Z([[7],[3,'scaTitle']])
Z([3,'#E13F37'])
Z([3,'#eeeeee'])
Z([3,'84'])
Z([3,'5'])
Z([[2,'/'],[[2,'*'],[[2,'+'],[[7],[3,'current']],[1,1]],[1,100]],[[7],[3,'totalCount']]])
Z([3,'true'])
Z([1,false])
Z([[7],[3,'current']])
Z([1,250])
Z(z[9])
Z([a,[3,'height: '],[[7],[3,'sch']],[3,'px;']])
Z([3,'index'])
Z([3,'item'])
Z([[7],[3,'lists']])
Z(z[14])
Z([3,'stopChange'])
Z([a,z[13][1],z[13][2],z[13][3]])
Z([3,'main-body px-3 py-5 rounded-md mx-3 bg-white'])
Z(z[14])
Z([3,'subItem'])
Z([[6],[[7],[3,'item']],[3,'subjectItem']])
Z([3,'id'])
Z([3,'selectOptionHandle'])
Z([[2,'==='],[[6],[[7],[3,'currentItem']],[3,'userValue']],[[6],[[7],[3,'subItem']],[3,'id']]])
Z([[6],[[7],[3,'subItem']],[3,'id']])
Z([[6],[[7],[3,'subItem']],[3,'optionsKey']])
Z([[6],[[7],[3,'subItem']],[3,'optionsValue']])
Z([[2,'==='],[[7],[3,'preStatus']],[1,true]])
Z([3,'paginationHandle'])
Z([3,'pre'])
Z([[7],[3,'submitStatus']])
Z([3,'submitHandle'])
Z(z[3])
})(__WXML_GLOBAL__.ops_cached.$gwx0_XC_0_1);return __WXML_GLOBAL__.ops_cached.$gwx0_XC_0_1
}
__WXML_GLOBAL__.ops_set.$gwx0_XC_0=z;
__WXML_GLOBAL__.ops_init.$gwx0_XC_0=true;
var x=['./eval/pages/answer/answer.wxml'];d_[x[0]]={}
var m0=function(e,s,r,gg){
var z=gz$gwx0_XC_0_1()
var xC=_n('van-sticky')
var oD=_mz(z,'van-nav-bar',['leftArrow',-1,'bind:click-left',0,'class',1,'title',1],[],e,s,gg)
_(xC,oD)
_(r,xC)
var fE=_mz(z,'van-circle',['color',3,'layerColor',1,'size',2,'strokeWidth',3,'value',4],[],e,s,gg)
_(r,fE)
var cF=_mz(z,'swiper',['catchtouchmove',8,'circular',1,'current',2,'duration',3,'indicatorDots',4,'style',5],[],e,s,gg)
var hG=_v()
_(cF,hG)
var oH=function(oJ,cI,lK,gg){
var tM=_mz(z,'swiper-item',['catchtouchmove',18,'style',1],[],oJ,cI,gg)
var eN=_n('view')
_rz(z,eN,'class',20,oJ,cI,gg)
var oP=_v()
_(eN,oP)
var xQ=function(fS,oR,cT,gg){
var oV=_mz(z,'item',['bind:selectOptionHandle',25,'checked',1,'optionsId',2,'optionsKey',3,'optionsValue',4],[],fS,oR,gg)
_(cT,oV)
return cT
}
oP.wxXCkey=4
_2z(z,23,xQ,oJ,cI,gg,oP,'subItem','index','id')
var bO=_v()
_(eN,bO)
if(_oz(z,30,oJ,cI,gg)){bO.wxVkey=1
var cW=_mz(z,'van-button',['block',-1,'plain',-1,'round',-1,'bind:tap',31,'data-type',1],[],oJ,cI,gg)
_(bO,cW)
}
bO.wxXCkey=1
bO.wxXCkey=3
_(tM,eN)
_(lK,tM)
return lK
}
hG.wxXCkey=4
_2z(z,16,oH,e,s,gg,hG,'item','index','index')
_(r,cF)
var oB=_v()
_(r,oB)
if(_oz(z,33,e,s,gg)){oB.wxVkey=1
var oX=_mz(z,'van-button',['block',-1,'bindtap',34,'color',1],[],e,s,gg)
_(oB,oX)
}
oB.wxXCkey=1
oB.wxXCkey=3
return r
}
e_[x[0]]={f:m0,j:[],i:[],ti:[],ic:[]}
if(path&&e_[path]){
return function(env,dd,global){$gwxc=0;var root={"tag":"wx-page"};root.children=[]
;g="$gwx0_XC_0";var main=e_[path].f
if (typeof global==="undefined")global={};global.f=$gdc(f_[path],"",1);
try{
main(env,{},root,global);
_tsd(root)
}catch(err){
console.log(err)
}
;g="";
return root;
}
}
}
}(__g.a,__g.b,__g.c,__g.d,__g.e,__g.f,__g.g,__g.h,__g.i,__g.j,__g.k,__g.l,__g.m,__g.n,__g.o,__g.p,__g.q,__g.r,__g.s,__g.t,__g.u,__g.v,__g.w,__g.x,__g.y,__g.z,__g.A,__g.B,__g.C,__g.D,__g.E,__g.F,__g.G,__g.H,__g.I,__g.J,__g.K,__g.L,__g.M,__g.N,__g.O,__g.P,__g.Q,__g.R,__g.S,__g.T,__g.U,__g.V,__g.W,__g.X,__g.Y,__g.Z,__g.aa);if(__vd_version_info__.delayedGwx||false)$gwx0_XC_0();	if (__vd_version_info__.delayedGwx) __wxAppCode__['eval/pages/answer/answer.wxml'] = [$gwx0_XC_0, './eval/pages/answer/answer.wxml'];else __wxAppCode__['eval/pages/answer/answer.wxml'] = $gwx0_XC_0( './eval/pages/answer/answer.wxml' );
	;__wxRoute = "eval/pages/answer/answer";__wxRouteBegin = true;__wxAppCurrentFile__="eval/pages/answer/answer.js";define("eval/pages/answer/answer.js",function(require,module,exports,window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){
"use strict";require("../../../@babel/runtime/helpers/Objectvalues");var t=require("../../../requset/index"),e=require("../../../utils/index");Page({data:{imgBaseUrl:e.imgBaseUrl,safeAreaBottomHeight:"0px",current:0,windowHeight:0,scaId:"",scaTitle:"",lists:[],mapKey:"",currentItem:{},totalCount:0,selectItemOptions:{},preStatus:!1,nextStaus:!1,submitStatus:!1,submitLoadingStatus:!1},onLoad:function(t){var e=t.scaId,a=wx.getSystemInfoSync(),s=a.safeArea,i=a.windowHeight;this.init(e,i),this.setData({safeAreaBottomHeight:i-s.bottom+"px",mapKey:"selectResList_"+e})},backPress:function(){wx.navigateBack()},init:function(e,a){var s=this;(0,t.getQuestionList)(e).then((function(t){var e=t.code,a=t.data,i=a.scaId,n=a.scaTitle,u=a.subjectList;1e4===e&&(u.map((function(t){t.userValue="",t.subjectItem.map((function(t){t.optionsKey=t.itemTitle.slice(0,1),t.optionsValue=t.itemTitle.slice(1)}))})),s.setData({scaId:i,scaTitle:n,lists:u,totalCount:u.length,currentItem:u[0]}))}));var i=wx.createSelectorQuery(),n=[],u=this;wx.nextTick((function(){i.selectAll(".sh").boundingClientRect((function(t){t.map((function(t){console.log(t.height),n.push(t.height)})),u.setData({sch:a-(n[0]+n[1])+40})})).exec()}))},selectOptionHandle:function(t){var e=t.detail,a=e.optionsid,s=e.optionskey,i=this.data,n=i.current,u=i.selectItemOptions,r=i.currentItem,c=i.mapKey;this.setData({"currentItem.userValue":a}),this.getBtnStatus();var o={itemId:r.id,itemKey:s,itemVal:a};u[n]=JSON.parse(JSON.stringify(o)),wx.setStorageSync(c,JSON.stringify(u));this.paginationHandle({currentTarget:{dataset:{type:"next"}}})},getBtnStatus:function(){var t,e,a=this.data,s=a.current,i=a.currentItem,n=a.totalCount,u=!1;0===s?u=!1:1!==n&&(u=!0),t=s!==n-1&&""!==i.userValue,e=s===n-1&&""!==i.userValue,this.setData({preStatus:u,nextStatus:t,submitStatus:e,submitLoadingStatus:!1})},stopChange:function(){return!1},paginationHandle:function(t){var e=this.data,a=e.current,s=e.nextStatus,i=e.lists,n=e.preStatus,u=t.currentTarget.dataset.type;if("pre"===u&&!0===n&&a--,"next"===u&&!0===s&&a++,!0===n||!0===s){var r=this;setTimeout((function(){r.setData({current:a,currentItem:i[a]}),r.getBtnStatus()}),250)}},submitHandle:function(){this.setData({submitLoadingStatus:!0});var a=this.data,s=a.mapKey,i=a.scaId,n=JSON.parse(wx.getStorageSync(s)),u={scaId:i,itemDtoList:Object.values(n)};(0,t.saveSubject)(u).then((function(t){var a=t.code,i=t.data;1e4===a&&i&&(wx.removeStorageSync(s),(0,e.authJump)("/eval/pages/res/res?id="+i.id+"&type=1"))})).finally((function(){}))}});
},{isPage:true,isComponent:true,currentFile:'eval/pages/answer/answer.js'});require("eval/pages/answer/answer.js");