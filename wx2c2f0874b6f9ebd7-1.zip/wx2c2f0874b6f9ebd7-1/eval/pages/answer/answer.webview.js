$gwx0_XC_0=function(_,_v,_n,_p,_s,_wp,_wl,$gwn,$gwl,$gwh,wh,$gstack,$gwrt,gra,grb,TestTest,wfor,_ca,_da,_r,_rz,_o,_oz,_1,_1z,_2,_2z,_m,_mz,nv_getDate,nv_getRegExp,nv_console,nv_parseInt,nv_parseFloat,nv_isNaN,nv_isFinite,nv_decodeURI,nv_decodeURIComponent,nv_encodeURI,nv_encodeURIComponent,$gdc,nv_JSON,_af,_gv,_ai,_grp,_gd,_gapi,$ixc,_ic,_w,_ev,_tsd){return function(path,global){
if(typeof global==='undefined'){if (typeof __GWX_GLOBAL__==='undefined')global={};else global=__GWX_GLOBAL__;}if(typeof __WXML_GLOBAL__ === 'undefined') {__WXML_GLOBAL__={};
}__WXML_GLOBAL__.modules = __WXML_GLOBAL__.modules || {};
var e_={}
if(typeof(global.entrys)==='undefined')global.entrys={};e_=global.entrys;
var d_={}
if(typeof(global.defines)==='undefined')global.defines={};d_=global.defines;
var f_={}
if(typeof(global.modules)==='undefined')global.modules={};f_=global.modules || {};
var p_={}
__WXML_GLOBAL__.ops_cached = __WXML_GLOBAL__.ops_cached || {}
__WXML_GLOBAL__.ops_set = __WXML_GLOBAL__.ops_set || {};
__WXML_GLOBAL__.ops_init = __WXML_GLOBAL__.ops_init || {};
var z=__WXML_GLOBAL__.ops_set.$gwx0_XC_0 || [];
function gz$gwx0_XC_0_1(){
if( __WXML_GLOBAL__.ops_cached.$gwx0_XC_0_1)return __WXML_GLOBAL__.ops_cached.$gwx0_XC_0_1
__WXML_GLOBAL__.ops_cached.$gwx0_XC_0_1=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
Z([3,'backPress'])
Z([3,'sh'])
Z([[7],[3,'scaTitle']])
Z([3,'flex sh align-center justify-center position-relative pt-3'])
Z([3,'margin-bottom: -80rpx;z-index: 111;'])
Z([3,'bg-white p-1 rounded-circle'])
Z([3,'font-size: 0;'])
Z([3,'#E13F37'])
Z([3,'#eeeeee'])
Z([3,'84'])
Z([3,'5'])
Z([[2,'/'],[[2,'*'],[[2,'+'],[[7],[3,'current']],[1,1]],[1,100]],[[7],[3,'totalCount']]])
Z([3,'flex flex-column align-center justify-center'])
Z([3,'font-lgr text-E13F37 font-weight-bolder'])
Z([a,[3,' '],[[2,'+'],[[7],[3,'current']],[1,1]]])
Z([3,'line bg-F1F3F8'])
Z([3,'font-small text-8D92A3'])
Z([a,[3,'共'],[[7],[3,'totalCount']],[3,'题']])
Z([3,'true'])
Z([1,false])
Z([[7],[3,'current']])
Z([1,250])
Z(z[19])
Z([a,[3,'height: '],[[7],[3,'sch']],[3,'px;']])
Z([3,'index'])
Z([3,'item'])
Z([[7],[3,'lists']])
Z(z[24])
Z([3,'stopChange'])
Z([a,z[23][1],z[23][2],z[23][3]])
Z(z[19])
Z([a,z[23][1],z[23][2],z[23][3]])
Z([3,'main-body px-3 py-5 rounded-md mx-3 bg-white'])
Z([3,'mb-3 flex'])
Z([3,'font-md text-102327'])
Z([a,[[6],[[7],[3,'item']],[3,'subject']]])
Z(z[24])
Z([3,'subItem'])
Z([[6],[[7],[3,'item']],[3,'subjectItem']])
Z([3,'id'])
Z([3,'selectOptionHandle'])
Z([[2,'==='],[[6],[[7],[3,'currentItem']],[3,'userValue']],[[6],[[7],[3,'subItem']],[3,'id']]])
Z([[6],[[7],[3,'subItem']],[3,'id']])
Z([[6],[[7],[3,'subItem']],[3,'optionsKey']])
Z([[6],[[7],[3,'subItem']],[3,'optionsValue']])
Z([[2,'==='],[[7],[3,'preStatus']],[1,true]])
Z([3,'pt-2'])
Z([3,'paginationHandle'])
Z([3,'pre'])
Z([3,'上一题'])
Z([[7],[3,'submitStatus']])
Z([3,'fixed-bottom '])
Z([3,'submitHandle'])
Z(z[7])
Z([3,'查看我的测评报告'])
Z([a,[3,'height:'],[[7],[3,'safeAreaBottomHeight']]])
})(__WXML_GLOBAL__.ops_cached.$gwx0_XC_0_1);return __WXML_GLOBAL__.ops_cached.$gwx0_XC_0_1
}
__WXML_GLOBAL__.ops_set.$gwx0_XC_0=z;
__WXML_GLOBAL__.ops_init.$gwx0_XC_0=true;
var x=['./eval/pages/answer/answer.wxml'];d_[x[0]]={}
var m0=function(e,s,r,gg){
var z=gz$gwx0_XC_0_1()
var xC=_n('van-sticky')
var oD=_mz(z,'van-nav-bar',['leftArrow',-1,'bind:click-left',0,'class',1,'title',1],[],e,s,gg)
_(xC,oD)
_(r,xC)
var fE=_mz(z,'view',['class',3,'style',1],[],e,s,gg)
var cF=_mz(z,'view',['class',5,'style',1],[],e,s,gg)
var hG=_mz(z,'van-circle',['color',7,'layerColor',1,'size',2,'strokeWidth',3,'value',4],[],e,s,gg)
var oH=_n('view')
_rz(z,oH,'class',12,e,s,gg)
var cI=_n('text')
_rz(z,cI,'class',13,e,s,gg)
var oJ=_oz(z,14,e,s,gg)
_(cI,oJ)
_(oH,cI)
var lK=_n('view')
_rz(z,lK,'class',15,e,s,gg)
_(oH,lK)
var aL=_n('text')
_rz(z,aL,'class',16,e,s,gg)
var tM=_oz(z,17,e,s,gg)
_(aL,tM)
_(oH,aL)
_(hG,oH)
_(cF,hG)
_(fE,cF)
_(r,fE)
var eN=_mz(z,'swiper',['catchtouchmove',18,'circular',1,'current',2,'duration',3,'indicatorDots',4,'style',5],[],e,s,gg)
var bO=_v()
_(eN,bO)
var oP=function(oR,xQ,fS,gg){
var hU=_mz(z,'swiper-item',['catchtouchmove',28,'style',1],[],oR,xQ,gg)
var oV=_mz(z,'scroll-view',['enhanced',-1,'scrollY',-1,'showScrollbar',30,'style',1],[],oR,xQ,gg)
var cW=_n('view')
_rz(z,cW,'class',32,oR,xQ,gg)
var lY=_n('view')
_rz(z,lY,'class',33,oR,xQ,gg)
var aZ=_n('text')
_rz(z,aZ,'class',34,oR,xQ,gg)
var t1=_oz(z,35,oR,xQ,gg)
_(aZ,t1)
_(lY,aZ)
_(cW,lY)
var e2=_v()
_(cW,e2)
var b3=function(x5,o4,o6,gg){
var c8=_mz(z,'item',['bind:selectOptionHandle',40,'checked',1,'optionsId',2,'optionsKey',3,'optionsValue',4],[],x5,o4,gg)
_(o6,c8)
return o6
}
e2.wxXCkey=4
_2z(z,38,b3,oR,xQ,gg,e2,'subItem','index','id')
var oX=_v()
_(cW,oX)
if(_oz(z,45,oR,xQ,gg)){oX.wxVkey=1
var h9=_n('view')
_rz(z,h9,'class',46,oR,xQ,gg)
var o0=_mz(z,'van-button',['block',-1,'plain',-1,'round',-1,'bind:tap',47,'data-type',1],[],oR,xQ,gg)
var cAB=_oz(z,49,oR,xQ,gg)
_(o0,cAB)
_(h9,o0)
_(oX,h9)
}
oX.wxXCkey=1
oX.wxXCkey=3
_(oV,cW)
_(hU,oV)
_(fS,hU)
return fS
}
bO.wxXCkey=4
_2z(z,26,oP,e,s,gg,bO,'item','index','index')
_(r,eN)
var oB=_v()
_(r,oB)
if(_oz(z,50,e,s,gg)){oB.wxVkey=1
var oBB=_n('view')
_rz(z,oBB,'class',51,e,s,gg)
var lCB=_mz(z,'van-button',['block',-1,'bindtap',52,'color',1],[],e,s,gg)
var aDB=_oz(z,54,e,s,gg)
_(lCB,aDB)
_(oBB,lCB)
var tEB=_n('view')
_rz(z,tEB,'style',55,e,s,gg)
_(oBB,tEB)
_(oB,oBB)
}
oB.wxXCkey=1
oB.wxXCkey=3
return r
}
e_[x[0]]={f:m0,j:[],i:[],ti:[],ic:[]}
if(path&&e_[path]){
outerGlobal.__wxml_comp_version__=0.02
return function(env,dd,global){$gwxc=0;var root={"tag":"wx-page"};root.children=[]
;g="$gwx0_XC_0";var main=e_[path].f
if (typeof global==="undefined")global={};global.f=$gdc(f_[path],"",1);
if(typeof(outerGlobal.__webview_engine_version__)!='undefined'&&outerGlobal.__webview_engine_version__+1e-6>=0.02+1e-6&&outerGlobal.__mergeData__)
{
env=outerGlobal.__mergeData__(env,dd);
}
try{
main(env,{},root,global);
_tsd(root)
if(typeof(outerGlobal.__webview_engine_version__)=='undefined'|| outerGlobal.__webview_engine_version__+1e-6<0.01+1e-6){return _ev(root);}
}catch(err){
console.log(err)
}
;g="";
return root;
}
}
}
}(__g.a,__g.b,__g.c,__g.d,__g.e,__g.f,__g.g,__g.h,__g.i,__g.j,__g.k,__g.l,__g.m,__g.n,__g.o,__g.p,__g.q,__g.r,__g.s,__g.t,__g.u,__g.v,__g.w,__g.x,__g.y,__g.z,__g.A,__g.B,__g.C,__g.D,__g.E,__g.F,__g.G,__g.H,__g.I,__g.J,__g.K,__g.L,__g.M,__g.N,__g.O,__g.P,__g.Q,__g.R,__g.S,__g.T,__g.U,__g.V,__g.W,__g.X,__g.Y,__g.Z,__g.aa);if(__vd_version_info__.delayedGwx||false)$gwx0_XC_0();	if (__vd_version_info__.delayedGwx) __wxAppCode__['eval/pages/answer/answer.wxml'] = [$gwx0_XC_0, './eval/pages/answer/answer.wxml'];else __wxAppCode__['eval/pages/answer/answer.wxml'] = $gwx0_XC_0( './eval/pages/answer/answer.wxml' );
	
var noCss=typeof __vd_version_info__!=='undefined'&&__vd_version_info__.noCss===true;if(!noCss){__wxAppCode__['eval/pages/answer/answer.wxss'] = setCssToHead(["body{background-color:#f1f6f7}\n.",[1],"main-body{padding-top:",[0,100],"}\n.",[1],"swiper-item{height:70vh}\n.",[1],"w-300{width:",[0,300],"}\n.",[1],"icon{height:",[0,48],";width:",[0,48],"}\n.",[1],"line{height:",[0,1],";margin-bottom:",[0,5],";margin-top:",[0,5],";width:",[0,80],"}\n",],"Some selectors are not allowed in component wxss, including tag name selectors, ID selectors, and attribute selectors.(./eval/pages/answer/answer.wxss:1:1)",{path:"./eval/pages/answer/answer.wxss"});
}