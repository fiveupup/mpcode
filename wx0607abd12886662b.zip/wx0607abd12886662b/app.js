var e = require("./utils/request");

require("./utils/util.js");

App({
    globalData: {
        checkLogin: !1,
        userToken: null,
        addressId: null,
        productId: null,
        userInfo: {},
        museumRule: {},
        topicInfo: {},
        museumId: null,
        fid: "",
        museumImg: "",
        museumStatus: "",
        museumList: []
    },
    onLaunch: function() {
        console.log("小程序初始化完成");
        var o = this;
        wx.login({
            success: function(n) {
                var l = n.code;
                (0, e.requestLogin)(l).then(function(e) {
                    console.log(e.data), console.log(wx.getStorageSync("FID")), o.globalData.userToken = e.data, 
                    o.globalData.checkLogin = !0, o.checkLoginReadyCallback && o.checkLoginReadyCallback(e.data);
                });
            }
        }), (0, e.registerCheckUpdate)();
    },
    onShow: function(e) {
        wx.setKeepScreenOn({
            keepScreenOn: !0
        }), console.log("小程序进入前台", wx.getStorageSync("markers")), e.query.fid && (console.log(e.query.fid), 
        this.globalData.fid = e.query, console.log(this.globalData.fid), wx.switchTab({
            url: "/pages/index/index"
        }));
    },
    onHide: function() {
        console.log("小程序进入后台");
    }
});