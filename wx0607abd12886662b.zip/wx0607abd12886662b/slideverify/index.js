var t = require("../utils/util.js"), e = 0;

Component({
    properties: {
        enableClose: {
            type: Boolean,
            value: !1
        }
    },
    data: {
        backImg: [ "".concat(t.img_url, "code/1.jpg"), "".concat(t.img_url, "code/2.jpg"), "".concat(t.img_url, "code/3.jpg"), "".concat(t.img_url, "code/4.jpg"), "".concat(t.img_url, "code/5.jpg") ],
        backIndex: 0,
        isShow: !0,
        isMove: !1,
        status: -1,
        box: {
            width: 100,
            height: 100,
            back: ""
        },
        position: {
            left: 200,
            top: 29,
            left2: 0
        }
    },
    methods: {
        getRandomUniqueNumber: function() {
            var t = [ 0, 1, 2, 3, 4 ];
            if (0 === t.length) return null;
            var e = Math.floor(Math.random() * t.length), o = t[e];
            return t.splice(e, 1), o;
        },
        startClick: function(t) {
            this.setData({
                isMove: !0
            }), t.touches.length > 0 && (e = t.touches[0].pageX);
        },
        moveClick: function(t) {
            var o = 0;
            t.touches.length > 0 && (o = t.touches[0].pageX);
            var s = o - e;
            s = Math.max(s, 0), s = Math.min(s, this.data.box.width - 50), this.setData({
                "position.left2": s
            });
        },
        endClick: function() {
            var t = this, e = t.data.position;
            Math.abs(e.left2 - e.left) > 3 ? (t.setData({
                isMove: !1,
                status: 0
            }), setTimeout(function() {
                t.refereshClick();
            }, 1e3), t.triggerEvent("onerror", {}, {
                bubbles: !1,
                composed: !1
            })) : (t.setData({
                isMove: !1,
                status: 1
            }), setTimeout(function() {
                t.setData({
                    isShow: !1
                });
            }, 1e3), t.triggerEvent("onsuccess", {}, {
                bubbles: !1,
                composed: !1
            }));
        },
        refereshClick: function() {
            var t = this.data.box, e = Math.round(Math.random() * (t.width - 100)) + 50, o = Math.round(Math.random() * (t.height - 60)) + 20;
            this.setData({
                "position.left": e,
                "position.top": o,
                "position.left2": 0,
                status: -1,
                isMove: !1,
                "box.back": this.data.backImg[this.getRandomUniqueNumber()]
            });
        },
        closeClick: function() {
            this.setData({
                isShow: !1
            });
        }
    },
    lifetimes: {
        ready: function() {
            var t = this;
            wx.getSystemInfo({
                success: function(e) {
                    var o = e.screenWidth - 20 - 20, s = o / 16 * 9;
                    t.setData({
                        box: {
                            width: o,
                            height: s
                        }
                    }), t.refereshClick();
                }
            }), console.log(this.data.enableClose, "this.enableClose"), t.setData({
                isShow: this.data.enableClose
            });
        }
    }
});