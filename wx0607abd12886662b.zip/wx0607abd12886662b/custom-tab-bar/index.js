require("../utils/serverList.js");

var e = getApp();

Component({
    properties: {},
    data: {
        active: 0,
        list: [ {
            pagePath: "/pages/index/index",
            iconPath: "../icon/index.png",
            selectedIconPath: "../icon/index-active.png",
            text: "首页"
        }, {
            pagePath: "/pages/answer/answer",
            iconPath: "../icon/answer.png",
            selectedIconPath: "../icon/answer-active.png",
            text: "答题"
        }, {
            pagePath: "/pages/exchange/exchange",
            iconPath: "../icon/exchange.png",
            selectedIconPath: "../icon/exchange-active.png",
            text: "兑换"
        }, {
            pagePath: "/pages/ranking/ranking",
            iconPath: "../icon/ranking.png",
            selectedIconPath: "../icon/ranking-active.png",
            text: "排行"
        }, {
            pagePath: "/pages/mine/mine",
            iconPath: "../icon/mine.png",
            selectedIconPath: "../icon/mine-active.png",
            text: "我的"
        } ]
    },
    methods: {
        onChange: function(a) {
            console.log(e.globalData.userInfo.privacy, "app"), e.globalData.userInfo.privacy ? (this.setData({
                active: a.detail
            }), wx.switchTab({
                url: this.data.list[a.detail].pagePath
            })) : wx.switchTab({
                url: this.data.list[0].pagePath
            });
        },
        init: function() {
            var e = getCurrentPages().pop();
            this.setData({
                active: this.data.list.findIndex(function(a) {
                    return a.pagePath === "/".concat(e.route);
                })
            });
        }
    }
});