Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.uploadImage = exports.requestLogin = exports.requestApi = exports.registerCheckUpdate = void 0;

var e = "release" === wx.getAccountInfoSync().miniProgram.envVersion ? "https://wbdh.jiiimo.cn/api" : "https://wenbo.ruiccm.com/api", t = (exports.requestLogin = function(t) {
    var o = {
        code: t,
        fid: wx.getStorageSync("FID")
    };
    return new Promise(function(t, a) {
        wx.request({
            url: e + "/login",
            data: o,
            method: "POST",
            header: {
                "content-type": "application/x-www-form-urlencoded",
                cookie: wx.getStorageSync("cookieKey")
            },
            success: function(e) {
                wx.setStorageSync("cookieKey", e.header["Set-Cookie"]), 0 === e.data.code ? (wx.setStorageSync("TOKEN", e.data.data.token), 
                wx.setStorageSync("UUIDTOKEN", e.data.data.uuidtoken), wx.setStorageSync("Signature", e.data.data.signature), 
                t(e.data)) : (console.log(e.data.msg), wx.showToast({
                    title: e.data.msg,
                    icon: "none",
                    duration: 2e3
                }), a());
            }
        });
    });
}, exports.requestApi = function(t, o) {
    return (o = o || {}).uuid = wx.getStorageSync("UUIDTOKEN"), o.sign = wx.getStorageSync("Signature"), 
    new Promise(function(a, n) {
        wx.request({
            url: e + "/" + t,
            data: o,
            method: "POST",
            header: {
                "content-type": "application/x-www-form-urlencoded",
                cookie: wx.getStorageSync("cookieKey"),
                Token: wx.getStorageSync("TOKEN")
            },
            success: function(e) {
                wx.setStorageSync("cookieKey", e.header["Set-Cookie"]), 0 === e.data.code ? a(e.data.data) : wx.showToast({
                    title: e.data.msg,
                    icon: "none",
                    duration: 2e3
                });
            }
        });
    });
}, exports.uploadImage = function(t) {
    return new Promise(function(o, a) {
        wx.uploadFile({
            url: e + "/index/upload",
            filePath: t,
            name: "file",
            success: function(e) {
                console.log(e);
                var t = JSON.parse(e.data);
                o(t.data);
            }
        });
    });
}, !1);

exports.registerCheckUpdate = function() {
    t || (t = !0, wx.onAppShow(function() {
        var e = wx.getUpdateManager();
        e.onCheckForUpdate(function(e) {
            console.log(e.hasUpdate);
        }), e.onUpdateReady(function() {
            wx.showModal({
                title: "更新提示",
                content: "新版本已经准备好，是否重启应用？",
                success: function(t) {
                    t.confirm && e.applyUpdate();
                }
            });
        }), e.onUpdateFailed(function() {});
    }));
};