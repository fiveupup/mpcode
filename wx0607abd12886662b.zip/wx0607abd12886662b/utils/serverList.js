Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.addToCart = function(e) {
    return new Promise(function(n, o) {
        var t = wx.getStorageSync("CART_LIST"), r = (t = t || []).findIndex(function(n) {
            return n.id === e;
        });
        -1 != r ? t[r].num = t[r].num + 1 : t.push({
            id: e,
            num: 1
        }), wx.setStorageSync("CART_LIST", t), n(!0);
    });
}, exports.answerEnd = function(n) {
    return new Promise(function(o, t) {
        (0, e.requestApi)("museum/first", {
            mid: n
        }).then(function(e) {
            console.log(e), o(e);
        });
    });
}, exports.answerSubmission = function(n, o, t, r) {
    return new Promise(function(s, i) {
        console.log("answerSubmission"), console.log(Date.now());
        var u = Object.values(o).sort().join(",");
        (0, e.requestApi)("question/post", {
            id: n,
            select: u,
            wyy: t,
            wyy_point: r
        }).then(function(e) {
            console.log(e), s(e);
        });
    });
}, exports.cancelOrder = function(n) {
    return new Promise(function(o, t) {
        console.log("cancelOrder"), (0, e.requestApi)("order/cancel", {
            id: n
        }).then(function(e) {
            console.log(e), o(e);
        });
    });
}, exports.cashDrawing = function(n) {
    return new Promise(function(o, t) {
        console.log("cashDrawing"), (0, e.requestApi)("prize/get", {
            mid: n
        }).then(function(e) {
            console.log(e), o(e);
        });
    });
}, exports.confirmConversion = function(n) {
    return new Promise(function(o, t) {
        console.log("confirmConversion"), n.list = JSON.stringify(n.list), (0, e.requestApi)("goods/order", n).then(function(e) {
            console.log(e), o(e);
        });
    });
}, exports.downTel = function() {
    return new Promise(function(n, o) {
        (0, e.requestApi)("home/rejecttel", {}).then(function(e) {
            n(e);
        });
    });
}, exports.getAddress = function() {
    return new Promise(function(n, o) {
        console.log("getAddress"), (0, e.requestApi)("address/get", {}).then(function(e) {
            console.log(e), n(e);
        });
    });
}, exports.getArticleDetails = function(n) {
    return new Promise(function(o, t) {
        console.log("getArticleDetails"), (0, e.requestApi)("banner/detail", {
            id: n
        }).then(function(e) {
            console.log(e), o(e);
        });
    });
}, exports.getBalance = function(n) {
    return new Promise(function(n, o) {
        (0, e.requestApi)("user/tixian", {}).then(function(e) {
            console.log(e), n(e);
        });
    });
}, exports.getBalanceList = function() {
    return new Promise(function(n, o) {
        console.log("getBalanceList"), (0, e.requestApi)("user/amount", {}).then(function(e) {
            console.log(e), n(e);
        });
    });
}, exports.getBanner = function() {
    return new Promise(function(n, o) {
        console.log("getBanner"), (0, e.requestApi)("home/banner", {}).then(function(e) {
            console.log(e), n(e);
        });
    });
}, exports.getIndexTopic = function() {
    return new Promise(function(n, o) {
        console.log("getIndexTopic"), (0, e.requestApi)("home/question", {}).then(function(e) {
            console.log(e), n(e);
        });
    });
}, exports.getIntegralDetail = function(n) {
    return new Promise(function(n, o) {
        console.log("getIntegralDetail"), (0, e.requestApi)("order/point", {}).then(function(e) {
            console.log(e), n(e);
        });
    });
}, exports.getIntegralRule = function() {
    return new Promise(function(n, o) {
        (0, e.requestApi)("home/pointrule", {}).then(function(e) {
            console.log(e), n(e);
        });
    });
}, exports.getLeaderboard = function() {
    return new Promise(function(n, o) {
        console.log("getLeaderboard"), (0, e.requestApi)("user/userrank", {}).then(function(e) {
            console.log(e), n(e);
        });
    });
}, exports.getMall = function(n) {
    return new Promise(function(o, t) {
        console.log("getMall"), (0, e.requestApi)("goods/list", {
            type: n
        }).then(function(e) {
            console.log(e), o(e);
        });
    });
}, exports.getMallBanner = function() {
    return new Promise(function(n, o) {
        console.log("getMallBanner"), (0, e.requestApi)("goods/banner", {}).then(function(e) {
            console.log(e), n(e);
        });
    });
}, exports.getMedal = function() {
    return new Promise(function(n, o) {
        (0, e.requestApi)("user/medal", {}).then(function(e) {
            console.log(e), n(e);
        });
    });
}, exports.getMessage = function() {
    return new Promise(function(n, o) {
        console.log("getMessage"), (0, e.requestApi)("notice/list", {}).then(function(e) {
            console.log(e), n(e);
        });
    });
}, exports.getMuseumList = function() {
    return new Promise(function(n, o) {
        console.log("getMuseumList"), (0, e.requestApi)("museum/list", {}).then(function(e) {
            console.log(e), n(e);
        });
    });
}, exports.getMuseumRule = void 0, exports.getOrder = function(n) {
    return new Promise(function(o, t) {
        console.log("getOrder"), (0, e.requestApi)("order/list", {
            type: n.type - 1,
            page: n.page
        }).then(function(e) {
            console.log(e), o(e);
        });
    });
}, exports.getOrderDetails = function(n) {
    return new Promise(function(o, t) {
        console.log("getOrderDetails"), (0, e.requestApi)("order/detail", {
            id: n
        }).then(function(e) {
            console.log(e), o(e);
        });
    });
}, exports.getPioneer = function() {
    return new Promise(function(n, o) {
        console.log("prorank"), (0, e.requestApi)("user/prorank", {}).then(function(e) {
            console.log(e), n(e);
        });
    });
}, exports.getPoints = function() {
    return new Promise(function(n, o) {
        console.log("getPoints"), (0, e.requestApi)("user/point", {}).then(function(e) {
            console.log(e), n(e);
        });
    });
}, exports.getPrize = function() {
    return new Promise(function(n, o) {
        console.log("getPrize"), (0, e.requestApi)("home/log", {}).then(function(e) {
            console.log(e), n(e);
        });
    });
}, exports.getProductDetails = function(n) {
    return new Promise(function(o, t) {
        console.log("getProductDetails"), (0, e.requestApi)("goods/detail", {
            id: n
        }).then(function(e) {
            console.log(e), o(e);
        });
    });
}, exports.getRegulations = function() {
    return new Promise(function(n, o) {
        console.log("getRegulations"), (0, e.requestApi)("home/rule", {}).then(function(e) {
            console.log(e), n(e);
        });
    });
}, exports.getSchools = function(n) {
    return new Promise(function(o, t) {
        console.log("getSchools"), (0, e.requestApi)("home/school", {
            search: n
        }).then(function(e) {
            console.log(e), o(e);
        });
    });
}, exports.getStrategy = function() {
    return new Promise(function(n, o) {
        (0, e.requestApi)("home/guide", {}).then(function(e) {
            console.log(e), n(e);
        });
    });
}, exports.getTel = function(n) {
    return new Promise(function(o, t) {
        (0, e.requestApi)("home/tel", {
            code: n
        }).then(function(e) {
            o(e);
        });
    });
}, exports.getTopic = function(n, o) {
    return console.log("mid:" + n), new Promise(function(t, r) {
        console.log("getTopic"), (0, e.requestApi)("question/get", {
            mid: n,
            qid: o
        }).then(function(e) {
            console.log(e);
            var n = e.options, o = [];
            for (var r in n) o.push({
                options: r,
                title: n[r]
            });
            console.log(o), e.options = o, console.log(e), t(e);
        });
    });
}, exports.getUserIpAddress = exports.getUserInfo = void 0, exports.getshoppingCart = function(n) {
    return new Promise(function(n, o) {
        console.log("getshoppingCart");
        var t = wx.getStorageSync("CART_LIST");
        t = JSON.stringify(t), console.log(t), (0, e.requestApi)("goods/cart", {
            cart: t
        }).then(function(e) {
            console.log(e), n(e);
        });
    });
}, exports.isCodeNum = function() {
    return new Promise(function(n, o) {
        (0, e.requestApi)("home/yzm", {}).then(function(e) {
            console.log(e), n(e);
        });
    });
}, exports.myCertification = function() {
    return new Promise(function(n, o) {
        (0, e.requestApi)("user/authorinfo", {}).then(function(e) {
            console.log(e), n(e);
        });
    });
}, exports.myPrize = function() {
    return new Promise(function(n, o) {
        (0, e.requestApi)("user/myprize", {}).then(function(e) {
            console.log(e), n(e);
        });
    });
}, exports.orderInformation = function(n) {
    return new Promise(function(o, t) {
        console.log("getProductDetails"), (0, e.requestApi)("goods/info", {
            id: n
        }).then(function(e) {
            console.log(e), o(e);
        });
    });
}, exports.setAddress = function(n) {
    return new Promise(function(o, t) {
        console.log("setAddress"), n.checked = n.checked ? 1 : 0, (0, e.requestApi)("address/post", n).then(function(e) {
            console.log(e), o(e);
        });
    });
}, exports.setAddressIp = function(n) {
    return new Promise(function(o, t) {
        console.log(n), (0, e.requestApi)("home/address", n).then(function(e) {
            console.log(e), o(e);
        });
    });
}, exports.setAppeal = function(n) {
    return new Promise(function(o, t) {
        console.log("setAppeal"), (0, e.requestApi)("user/appeal", n).then(function(e) {
            console.log(e), o(e);
        });
    });
}, exports.setCertifiedMajor = function(n) {
    return new Promise(function(o, t) {
        console.log("setCertifiedMajor"), console.log(n), (0, e.requestApi)("user/author", n).then(function(e) {
            console.log(e), o(e);
        });
    });
}, exports.setInvite = function(n) {
    return new Promise(function(o, t) {
        (0, e.requestApi)("user/invite", {
            fid: n
        }).then(function(e) {
            console.log(e), o(e);
        });
    });
}, exports.setRevivalCard = function() {
    return new Promise(function(n, o) {
        console.log("setRevivalCard"), (0, e.requestApi)("user/revive", {}).then(function(e) {
            console.log(e), n(e);
        });
    });
}, exports.setUserAgree = void 0, exports.shareQuery = function() {
    return new Promise(function(n, o) {
        (0, e.requestApi)("user/share", {}).then(function(e) {
            console.log(e), n(e);
        });
    });
}, exports.signIn = function() {
    return new Promise(function(n, o) {
        console.log("signIn"), (0, e.requestApi)("home/checkin", {}).then(function(e) {
            console.log(e), n(e);
        });
    });
}, exports.submissionPrize = function(n) {
    return new Promise(function(o, t) {
        (0, e.requestApi)("user/prizeaddress", n).then(function(e) {
            console.log(e), o(e);
        });
    });
}, exports.turntableRaffle = function() {
    return new Promise(function(n, o) {
        (0, e.requestApi)("user/pointprize", {}).then(function(e) {
            console.log(e), n(e);
        });
    });
}, exports.userInfo = function(n) {
    return new Promise(function(o, t) {
        console.log(n), (0, e.requestApi)("user/nick", n).then(function(e) {
            console.log(e), o(e);
        });
    });
}, require("../@babel/runtime/helpers/Objectvalues");

var e = require("./request");

exports.getUserIpAddress = function() {
    return new Promise(function(n, o) {
        console.log("getUserIpAddress"), (0, e.requestApi)("user/ip", {}).then(function(e) {
            console.log(e), n(e);
        });
    });
}, exports.setUserAgree = function() {
    return new Promise(function(n, o) {
        console.log("setUserAgree"), (0, e.requestApi)("user/agree", {}).then(function(e) {
            console.log(e), n(e);
        });
    });
}, exports.getUserInfo = function() {
    return new Promise(function(n, o) {
        console.log("getUserInfo"), (0, e.requestApi)("user/info", {}).then(function(e) {
            console.log(e), n(e);
        });
    });
}, exports.getMuseumRule = function() {
    return new Promise(function(n, o) {
        console.log("getMuseumRule"), (0, e.requestApi)("user/rule", {}).then(function(e) {
            console.log(e), n(e);
        });
    });
};