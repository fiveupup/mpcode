var t = require("../../utils/serverList.js"), n = require("../../utils/util.js"), i = getApp();

Page({
    data: {
        type: "1",
        list: [],
        img_url: n.img_url,
        userInfo: {},
        pioneerList: []
    },
    answer: function() {
        "1" != this.data.type && (this.setData({
            type: "1"
        }), this.init());
    },
    points: function() {
        "2" != this.data.type && (this.setData({
            type: "2"
        }), this.initgetPioneer());
    },
    init: function() {
        var n = this;
        (0, t.getLeaderboard)().then(function(t) {
            n.setData({
                list: t
            });
        });
    },
    initgetPioneer: function() {
        var n = this;
        (0, t.getPioneer)().then(function(t) {
            n.setData({
                pioneerList: t
            });
        });
    },
    initUser: function() {
        var n = this;
        (0, t.getUserInfo)().then(function(t) {
            i.globalData.userInfo = t, n.setData({
                userInfo: t
            });
        });
    },
    onLoad: function(t) {},
    onReady: function() {},
    onShow: function() {
        this.init(), this.getTabBar().init();
    },
    onHide: function() {},
    onUnload: function() {},
    onPullDownRefresh: function() {},
    onReachBottom: function() {},
    onShareAppMessage: function() {
        return {
            title: "文博大会call你啦~挑战12题，赢现金，奖金直接提现！",
            path: "/pages/index/index",
            imageUrl: "".concat(n.img_url, "share1.png")
        };
    },
    onShareTimeline: function() {
        return {
            title: "文博大会-每天答题参与幸运抽奖，瓜分百万现金！",
            imageUrl: "".concat(n.img_url, "share.png")
        };
    }
});