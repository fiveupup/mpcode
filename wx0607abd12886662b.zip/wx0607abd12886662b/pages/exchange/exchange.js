var t = require("../../utils/serverList.js"), a = require("../../utils/util.js");

Page({
    data: {
        indicatorDots: !1,
        circular: !0,
        autoplay: !0,
        interval: 2e3,
        duration: 1e3,
        img_url: a.img_url,
        banner: [],
        type: "1",
        list: []
    },
    bannerDetails: function(t) {
        t.currentTarget.dataset.id;
        var a = t.currentTarget.dataset.type, i = t.currentTarget.dataset.link;
        0 != a && (1 == a ? wx.navigateTo({
            url: "/pages/product/productDetails/productDetails?id=".concat(i)
        }) : 2 == a && wx.navigateTo({
            url: "/pages/viewPage/viewPage?link=".concat(i)
        }));
    },
    tabs: function(t) {
        var a = t.currentTarget.dataset.type;
        this.data.type != a && (this.setData({
            type: a
        }), "1" == a ? (console.log("实物"), this.initList(this.data.type)) : "2" == a && (console.log("2"), 
        this.initList(this.data.type)));
    },
    cart: function() {
        wx.navigateTo({
            url: "/pages/product/shoppingCart/shoppingCart"
        });
    },
    details: function(t) {
        var a = t.currentTarget.dataset.id;
        wx.navigateTo({
            url: "/pages/product/productDetails/productDetails?id=".concat(a)
        });
    },
    initList: function(a) {
        var i = this;
        (0, t.getMall)(a).then(function(t) {
            i.setData({
                list: t
            });
        });
    },
    init: function() {
        var a = this;
        (0, t.getMallBanner)().then(function(t) {
            a.setData({
                banner: t
            });
        });
    },
    onLoad: function(t) {
        this.init(), this.initList(this.data.type);
    },
    onReady: function() {},
    onShow: function() {
        this.getTabBar().init();
    },
    onHide: function() {},
    onUnload: function() {},
    onPullDownRefresh: function() {},
    onReachBottom: function() {},
    onShareAppMessage: function() {
        return {
            title: "文博大会call你啦~挑战12题，赢现金，奖金直接提现！",
            path: "/pages/index/index",
            imageUrl: "".concat(a.img_url, "share1.png")
        };
    },
    onShareTimeline: function() {
        return {
            title: "文博大会-每天答题参与幸运抽奖，瓜分百万现金！",
            imageUrl: "".concat(a.img_url, "share.png")
        };
    }
});