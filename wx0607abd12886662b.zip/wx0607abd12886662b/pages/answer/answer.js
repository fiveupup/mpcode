var t = require("../../utils/serverList.js"), e = require("../../utils/util.js"), n = getApp();

Page({
    data: {
        list: [],
        isOff: !1,
        img_url: e.img_url,
        money: {},
        museumRule: {},
        countdown: 604800,
        days: "",
        hours: "",
        minutes: "",
        seconds: "",
        countdownInterval: null,
        currentDelayTime: null,
        currentDelayTime2: null,
        address: "",
        isAddress: !1,
        isAccredit: !1,
        isAddressTwo: !0
    },
    click: function(a) {
        var s = this;
        if ((0, e.debounce)(1e3, s.data.currentDelayTime)) {
            console.log("跳转执行次数");
            var o = a.currentTarget.dataset.status, i = a.currentTarget.dataset.id, u = a.currentTarget.dataset.img;
            if ("2" == o) return void (0, t.cashDrawing)(i).then(function(t) {
                s.init(), s.setData({
                    money: t,
                    isOff: !0
                });
            });
            if (this.data.museumRule.number <= 0) return void wx.showToast({
                title: "今日答题次数已用完",
                icon: "none",
                duration: 2e3
            });
            "1" != o && "3" != o || (n.globalData.museumImg = u, n.globalData.museumStatus = o, 
            wx.navigateTo({
                url: "/pages/answerPage/answerPage?id=".concat(i)
            })), s.setData({
                currentDelayTime: new Date().getTime()
            });
        }
    },
    off: function() {
        this.setData({
            isOff: !1
        });
    },
    init: function() {
        var e = this;
        (0, t.getMuseumList)().then(function(t) {
            e.updateCountdown(), e.setData({
                list: t
            });
        });
        var a = setInterval(this.updateCountdown, 1e3);
        this.setData({
            countdownInterval: a
        }), (0, t.getMuseumRule)().then(function(t) {
            n.globalData.museumRule = t, e.setData({
                museumRule: t,
                countdown: t.countdown
            });
        });
    },
    updateCountdown: function() {
        var t = this.data.countdown, n = (0, e.formatTime)(t), a = n.days.toString().padStart(2, "0"), s = n.hours.toString().padStart(2, "0"), o = n.minutes.toString().padStart(2, "0"), i = n.seconds.toString().padStart(2, "0");
        t > 0 ? (this.data.countdown--, this.setData({
            countdown: this.data.countdown--
        })) : clearInterval(this.data.countdownInterval), this.setData({
            days: a,
            hours: s,
            minutes: o,
            seconds: i
        });
    },
    onLoad: function(e) {
        var n = this, a = this;
        (0, t.getUserInfo)().then(function(t) {
            console.log(t, "resres"), t.city || (n.setData({
                isAccredit: !0,
                address: t.address
            }), wx.getSetting({
                success: function(t) {
                    t.authSetting.hasOwnProperty("scope.userFuzzyLocation") && !t.authSetting["scope.userFuzzyLocation"] ? a.setData({
                        isAddressTwo: !1
                    }) : a.setData({
                        isAddressTwo: !0
                    });
                }
            }));
        });
    },
    getAddress: function() {
        var e = this;
        wx.getFuzzyLocation({
            type: "wgs84",
            success: function(n) {
                console.log(n, "resres");
                var a = "".concat(Number(n.latitude), ",").concat(Number(n.longitude));
                wx.request({
                    url: "https://apis.map.qq.com/ws/geocoder/v1/?location=".concat(a, "&key=2BQBZ-KXLEG-QHMQL-QHZWL-ZIT2Q-HGB6Z&get_poi=0"),
                    success: function(n) {
                        console.log(n.data.result.ad_info), (0, t.setAddressIp)(n.data.result.ad_info).then(function(t) {
                            e.setData({
                                address: "".concat(n.data.result.ad_info.province, "-").concat(n.data.result.ad_info.city),
                                isAddress: !0,
                                isAccredit: !1
                            });
                        });
                    }
                });
            },
            fail: function() {
                e.setData({
                    isAddressTwo: !1
                });
            }
        });
    },
    getAddressTwo: function() {
        wx.openSetting({
            success: function(t) {
                console.log(t.authSetting);
            },
            fail: function(t) {
                console.log(t);
            }
        });
    },
    onReady: function() {},
    onShow: function() {
        var t = this;
        this.init(), this.getTabBar().init(), wx.getSetting({
            success: function(e) {
                e.authSetting.hasOwnProperty("scope.userFuzzyLocation") && !e.authSetting["scope.userFuzzyLocation"] ? t.setData({
                    isAddressTwo: !1
                }) : t.setData({
                    isAddressTwo: !0
                });
            }
        });
    },
    onHide: function() {
        clearInterval(this.data.countdownInterval);
    },
    onUnload: function() {
        clearInterval(this.data.countdownInterval);
    },
    onPullDownRefresh: function() {},
    onReachBottom: function() {},
    onShareAppMessage: function() {
        return {
            title: "文博大会call你啦~挑战12题，赢现金，奖金直接提现！",
            path: "/pages/index/index",
            imageUrl: "".concat(e.img_url, "share1.png")
        };
    },
    onShareTimeline: function() {
        return {
            title: "文博大会-每天答题参与幸运抽奖，瓜分百万现金！",
            imageUrl: "".concat(e.img_url, "share.png")
        };
    }
});