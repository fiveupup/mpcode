var n = require("../../utils/serverList.js"), i = require("../../utils/util.js");

Page({
    data: {
        list: [],
        img_url: i.img_url,
        userInfo: {}
    },
    init: function() {
        var i = this;
        (0, n.getMessage)().then(function(n) {
            i.setData({
                list: n
            });
        });
    },
    onLoad: function(n) {
        this.init();
    },
    onReady: function() {},
    onShow: function() {},
    onHide: function() {},
    onUnload: function() {},
    onPullDownRefresh: function() {},
    onReachBottom: function() {},
    onShareAppMessage: function() {
        return {
            title: "文博大会call你啦~挑战12题，赢现金，奖金直接提现！",
            path: "/pages/index/index",
            imageUrl: "".concat(i.img_url, "share1.png")
        };
    },
    onShareTimeline: function() {
        return {
            title: "文博大会-每天答题参与幸运抽奖，瓜分百万现金！",
            imageUrl: "".concat(i.img_url, "share.png")
        };
    }
});