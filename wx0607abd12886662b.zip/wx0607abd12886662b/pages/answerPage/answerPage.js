var t = require("../../@babel/runtime/helpers/defineProperty");

require("../../@babel/runtime/helpers/Objectvalues");

var e = require("../../utils/serverList.js"), a = require("../../utils/util.js"), n = getApp();

Page({
    data: {
        topic: {},
        num: 0,
        mid: null,
        time: n.globalData.museumRule.time,
        numberAnswers: 0,
        img_url: a.img_url,
        countdownInterval: null,
        isFailToAnswer: !1,
        isAnswerSuccessfully: !1,
        isAnswerSuccessfullyTwo: !1,
        isOff: !1,
        isPromote: !1,
        money: {},
        type: "1",
        active: {
            select: "1",
            answer: "",
            answerList: {}
        },
        userInfo: {},
        img: "",
        isAnswer: !1,
        notAnswer: !1,
        scrollTop: 0,
        times: null,
        keys: "",
        isWyy: !1,
        answerPoints: 0,
        currentDelayTime: null,
        currentDelayTime2: null,
        opacity: 0,
        isCode: !1,
        startTime: null,
        number: 0,
        optionsList: [],
        optionsListTwo: [ "A", "B", "C", "D" ],
        level: "",
        isCash: !0
    },
    verifySuccess: function() {
        this.init(this.data.mid, "");
    },
    verifyError: function() {
        wx.showToast({
            title: "失败",
            icon: "error"
        });
    },
    clickSelect: function(t) {
        if (!this.data.isFailToAnswer) {
            console.log(t, "454564656");
            var i = this;
            if (clearInterval(i.data.countdownInterval), (0, a.debounce)(1e3, i.data.currentDelayTime)) {
                i.data.times && clearInterval(i.data.times);
                var s = t.currentTarget.dataset.type, o = t.currentTarget.dataset.key, r = t.currentTarget.dataset.id;
                if (console.log(s, "type", o, "key", r, "id"), i.setData({
                    keys: o
                }), "1" == s) {
                    var l = {};
                    this.setData({
                        type: s,
                        num: r,
                        active: {
                            select: "1",
                            answer: o
                        }
                    }), l[i.data.active.answer] = i.data.active.answer, (0, e.answerSubmission)(i.data.topic.id, l, 0, 0).then(function(t) {
                        if (console.log(i.data.active.answer, "that.data.active.answer", Object.keys(t.answer)[0]), 
                        i.data.active.answer == Object.keys(t.answer)[0]) {
                            if (i.setData({
                                number: i.data.number + 1
                            }), 1 === t.allend) return i.setData({
                                isPromote: !0
                            }), void clearInterval(i.data.countdownInterval);
                            1 === t.end && ((0, e.answerEnd)(n.globalData.museumId).then(function(t) {
                                "1" == t.answerNum ? i.setData({
                                    isAnswerSuccessfully: !0
                                }) : i.setData({
                                    isAnswerSuccessfullyTwo: !0,
                                    answerPoints: t.answerPoints
                                }), clearInterval(i.data.countdownInterval);
                            }), i.setData({
                                isCash: !1
                            })), clearInterval(i.data.countdownInterval);
                            var s = wx.createInnerAudioContext({
                                useWebAudioImplement: !0
                            });
                            s.src = "".concat(a.audio_url, "correct.mp3"), s.play(), setTimeout(function() {
                                s.stop(), n.globalData.topicInfo = {};
                                var t = Math.floor(Date.now() / 1e3) - i.data.startTime;
                                console.log(t, "111", i.data.number, "222", t / i.data.number), t / i.data.number < 2 ? i.setData({
                                    isCode: !0
                                }) : i.init(i.data.mid, "");
                            }, 1e3);
                        } else {
                            clearInterval(i.data.countdownInterval);
                            var o = wx.createInnerAudioContext({
                                useWebAudioImplement: !0
                            });
                            o.src = "".concat(a.audio_url, "mistake1.mp3"), o.play(), setTimeout(function() {
                                i.setData({
                                    isFailToAnswer: !0
                                }), n.globalData.topicInfo = {}, o.stop();
                            }, 2e3);
                        }
                        i.setData({
                            active: {
                                select: "2",
                                answer: Object.keys(t.answer)[0],
                                notAnswer: !0
                            }
                        });
                    });
                }
                i.setData({
                    currentDelayTime: new Date().getTime()
                });
            }
        }
    },
    revivalCard: function() {
        var t = this;
        clearInterval(this.data.countdownInterval), this.data.userInfo.revive <= 0 ? wx.showModal({
            title: "获取复活卡",
            content: "分享获取复活卡",
            success: function(t) {
                t.confirm ? wx.navigateTo({
                    url: "/pages/revivalCardPage/revivalCardPage?type=lose"
                }) : t.cancel && console.log("用户点击取消");
            }
        }) : (0, e.setRevivalCard)().then(function(e) {
            e >= 0 && (t.initUser(), t.setData({
                time: n.globalData.museumRule.time,
                isFailToAnswer: !1
            }), console.log(t.data.mid, t.data.topic.id, "1111"), t.init(t.data.mid, t.data.topic.id));
        });
    },
    reanswer: function() {
        clearInterval(this.data.countdownInterval), this.initUser(), this.setData({
            isFailToAnswer: !1,
            num: 0
        }), n.globalData.topicInfo = {}, this.init(this.data.mid, ""), this.initNum();
    },
    resume: function() {
        clearInterval(this.data.countdownInterval), this.initUser(), this.setData({
            isOff: !1
        }), n.globalData.topicInfo = {}, this.init(this.data.mid, ""), this.initNum();
    },
    reselection: function() {
        clearInterval(this.data.countdownInterval), this.setData({
            isAnswerSuccessfullyTwo: !1
        }), wx.switchTab({
            url: "/pages/answer/answer"
        });
    },
    getCard: function(t) {
        console.log(t, "eeeeeeeeeeeee", this.data.money);
        var e = t.currentTarget.dataset.type, a = t.currentTarget.dataset.money, n = t.currentTarget.dataset.moneytype, i = "/pages/revivalCardPage/revivalCardPage";
        "1" == e ? i = "/pages/revivalCardPage/revivalCardPage?type=lose" : "2" == e && (i = "/pages/revivalCardPage/revivalCardPage?type=successful&money=".concat(a, "&moneyType=").concat(n)), 
        wx.navigateTo({
            url: i
        });
    },
    prizeDraw: function() {
        var t = this, i = this;
        "3" != n.globalData.museumStatus ? (0, a.debounce)(5e3, i.data.currentDelayTime2) && (0, 
        e.cashDrawing)(this.data.mid).then(function(e) {
            t.setData({
                money: e,
                isAnswerSuccessfully: !1,
                isPromote: !1,
                isOff: !0
            }), i.setData({
                currentDelayTime2: new Date().getTime()
            });
        }) : wx.showModal({
            title: "答题成功",
            content: "您已抽奖,请重选题库",
            showCancel: !1,
            success: function(t) {
                t.confirm ? wx.switchTab({
                    url: "/pages/answer/answer"
                }) : t.cancel && console.log("用户点击取消");
            }
        });
    },
    init: function(a, i) {
        var s = this;
        if (!this.data.isAnswerSuccessfully && !this.data.isAnswerSuccessfullyTwo) {
            console.log(a, i, "456456465");
            var o = null;
            clearInterval(o), this.setData({
                time: n.globalData.museumRule.time,
                isAnswer: !1,
                opacity: 0,
                isCode: !1
            });
            var r = this;
            if (Object.values(n.globalData.topicInfo).length > 0) {
                this.setData({
                    active: {
                        select: "1",
                        answer: "",
                        answerList: {}
                    }
                }), wx.nextTick(function() {
                    r.setData(t(t(t({
                        topic: {}
                    }, "topic", n.globalData.topicInfo), "optionsList", Object.keys(n.globalData.topicInfo.options)), "opacity", 1));
                }.bind(r));
                var l = this.data.time;
                o = setInterval(function() {
                    l--, console.log(l), r.setData({
                        time: l
                    }), l <= 0 && (clearInterval(o), (0, e.answerSubmission)(r.data.topic.id, {}, 0, 0).then(function(t) {}), 
                    r.setData({
                        isFailToAnswer: !0
                    }), n.globalData.topicInfo = {});
                }, 1e3), this.setData({
                    countdownInterval: o
                });
            } else (0, e.getTopic)(a, i).then(function(a) {
                if (s.setData({
                    active: {
                        select: "1",
                        answer: "",
                        answerList: {}
                    },
                    notAnswer: !1
                }), "1" == a.wyy) return n.globalData.topicInfo = a, r.setData({
                    isWyy: !0
                }), void wx.redirectTo({
                    url: "/pages/sendPoints/sendPoints"
                });
                r.setData({
                    isWyy: !1
                }), wx.nextTick(function() {
                    r.setData(t(t(t({
                        topic: {}
                    }, "topic", a), "optionsList", Object.keys(a.options)), "opacity", 1));
                }.bind(r));
                var i = s.data.time;
                o = setInterval(function() {
                    i--, console.log(i), r.setData({
                        time: i
                    }), i <= 0 && (clearInterval(o), (0, e.answerSubmission)(r.data.topic.id, {}, 0, 0).then(function(t) {}), 
                    r.setData({
                        isFailToAnswer: !0
                    }));
                }, 1e3), s.setData({
                    countdownInterval: o
                });
            });
            var c = 0, u = setInterval(function() {
                c > 20 ? clearInterval(r.data.times) : (c++, r.setData({
                    scrollTop: c
                }));
            }, 100);
            r.setData({
                times: u
            });
        }
    },
    initUser: function() {
        var t = this;
        (0, e.getUserInfo)().then(function(e) {
            n.globalData.userInfo = e, t.setData({
                userInfo: e
            });
        });
    },
    initNum: function() {
        var t = this;
        (0, e.getMuseumRule)().then(function(e) {
            t.setData({
                numberAnswers: e.number,
                level: e.level
            });
        });
    },
    onLoad: function(t) {
        t.id && (n.globalData.museumId = t.id), t.id2 && this.setData({
            time: Number(n.globalData.museumRule.time)
        }), this.setData({
            mid: t.id ? t.id : n.globalData.museumId,
            startTime: Math.floor(Date.now() / 1e3)
        });
        var e = t.id2 ? t.id2 : "";
        console.log(t, "111", this.data.mid, "id", e), this.init(this.data.mid, e), this.initUser(), 
        this.initNum();
    },
    onReady: function() {},
    onShow: function() {
        var t = this;
        n.globalData.museumList.forEach(function(e) {
            console.log(e.id, "item.img1111", t.data.mid), e.id == t.data.mid && (console.log(e.img, "item.img"), 
            n.globalData.museumImg = e.img, t.setData({
                img: e.img
            }));
        }), console.log(wx.getStorageSync("markers"), "执行打印");
        var a = this;
        if (wx.getStorageSync("markers")) {
            var i = Number(wx.getStorageSync("markers")), s = setInterval(function() {
                i--, console.log(i), a.setData({
                    time: i
                }), i <= 0 && (clearInterval(s), (0, e.answerSubmission)(a.data.topic.id, {}, 0, 0).then(function(t) {}), 
                a.setData({
                    isFailToAnswer: !0
                }));
            }, 1e3);
            this.setData({
                countdownInterval: s
            }), wx.removeStorageSync("markers");
        }
    },
    onHide: function() {
        console.log("执行了", this.data.time), wx.setStorageSync("markers", this.data.time), 
        clearInterval(this.data.countdownInterval);
    },
    onUnload: function() {
        clearInterval(this.data.countdownInterval), this.data.isCash ? ((this.data.topic.number > 1 && !this.data.isWyy || !this.data.isAnswer && this.data.notAnswer) && (0, 
        e.answerSubmission)(this.data.topic.id, {}, 0, 0).then(function(t) {}), wx.removeStorageSync("markers")) : this.setData({
            isCash: !0
        });
    },
    onPullDownRefresh: function() {},
    onReachBottom: function() {},
    onShareAppMessage: function() {
        return {
            title: "文博大会call你啦~挑战12题，赢现金，奖金直接提现！",
            path: "/pages/index/index",
            imageUrl: "".concat(a.img_url, "share1.png")
        };
    },
    onShareTimeline: function() {
        return {
            title: "文博大会-每天答题参与幸运抽奖，瓜分百万现金！",
            imageUrl: "".concat(a.img_url, "share.png")
        };
    }
});