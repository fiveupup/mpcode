var n = require("../../utils/util.js"), i = require("../../utils/serverList.js");

Page({
    data: {
        img_url: n.img_url,
        info: {}
    },
    appeal: function() {
        wx.navigateTo({
            url: "/pages/appeal/appeal"
        });
    },
    recertification: function() {
        wx.navigateTo({
            url: "/pages/authenticationPage/authenticationPage"
        });
    },
    init: function() {
        var n = this;
        (0, i.myCertification)().then(function(i) {
            console.log(i), n.setData({
                info: i
            });
        });
    },
    onLoad: function(n) {
        this.init();
    },
    onReady: function() {},
    onShow: function() {},
    onHide: function() {},
    onUnload: function() {},
    onPullDownRefresh: function() {},
    onReachBottom: function() {},
    onShareAppMessage: function() {
        return {
            title: "文博大会call你啦~挑战12题，赢现金，奖金直接提现！",
            path: "/pages/index/index",
            imageUrl: "".concat(n.img_url, "share1.png")
        };
    },
    onShareTimeline: function() {
        return {
            title: "文博大会-每天答题参与幸运抽奖，瓜分百万现金！",
            imageUrl: "".concat(n.img_url, "share.png")
        };
    }
});