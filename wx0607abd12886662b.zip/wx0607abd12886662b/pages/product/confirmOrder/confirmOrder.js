var t = require("../../../utils/util.js"), a = require("../../../utils/serverList.js"), e = getApp();

Page({
    data: {
        img_url: t.img_url,
        item: {},
        totality: 0,
        totalScore: 0,
        id: null,
        addressInfo: {},
        type: 0
    },
    add: function() {
        wx.navigateTo({
            url: "/pages/addAddress/addAddress"
        });
    },
    selectAddress: function() {
        e.globalData.addressId = this.data.addressInfo.id, wx.navigateTo({
            url: "/pages/product/selectAddress/selectAddress"
        });
    },
    subtract: function(t) {
        var a = this.data.item;
        a.num--, a.points = a.num * a.unitPrice, a.num <= 0 && (a.num = 1, a.points = a.num * a.unitPrice), 
        this.setData({
            item: a,
            totality: a.num,
            totalScore: a.points
        });
    },
    append: function(t) {
        var a = this.data.item;
        a.num++, a.points = a.num * a.unitPrice, this.setData({
            item: a,
            totality: a.num,
            totalScore: a.points
        });
    },
    confirm: function() {
        var t = this, n = [ {
            id: this.data.item.id,
            num: this.data.item.num
        } ], i = {};
        1 == this.data.type ? i = {
            addressId: e.globalData.addressId,
            list: n
        } : 2 == this.data.type && (i = {
            addressId: "",
            list: n
        }), 1 != this.data.type || e.globalData.addressId ? ((0, a.confirmConversion)(i).then(function(a) {
            if (a) {
                wx.showToast({
                    title: "兑换成功",
                    icon: "success",
                    duration: 2e3
                });
                var n = getCurrentPages(), i = n[n.length - 2];
                wx.navigateBack({
                    success: function() {
                        i.onLoad({
                            id: e.globalData.productId
                        });
                    }
                }), t.setData({
                    totality: 0,
                    totalScore: 0
                });
            } else wx.showToast({
                title: "兑换失败",
                icon: "error",
                duration: 2e3
            });
        }), console.log("确认兑换", i)) : wx.showToast({
            title: "地址不能为空",
            icon: "none",
            duration: 2e3
        });
    },
    init: function(t) {
        var n = this, i = this;
        (0, a.orderInformation)(t).then(function(t) {
            console.log(t), n.setData({
                item: t,
                totality: t.num,
                totalScore: t.points,
                type: t.type
            });
        }), (0, a.getAddress)().then(function(t) {
            t.length > 0 && (e.globalData.addressId ? t.forEach(function(t) {
                t.id == e.globalData.addressId && i.setData({
                    addressInfo: t
                });
            }) : t.forEach(function(a) {
                a.checked ? (e.globalData.addressId = a.id, i.setData({
                    addressInfo: a
                })) : (e.globalData.addressId = a.id, i.setData({
                    addressInfo: t[0]
                }));
            }));
        });
    },
    onLoad: function(t) {
        var a = e.globalData.productId;
        this.init(a), this.setData({
            id: a
        });
    },
    onReady: function() {},
    onShow: function() {},
    onHide: function() {},
    onUnload: function() {},
    onPullDownRefresh: function() {},
    onReachBottom: function() {},
    onShareAppMessage: function() {
        return {
            title: "文博大会call你啦~挑战12题，赢现金，奖金直接提现！",
            path: "/pages/index/index",
            imageUrl: "".concat(t.img_url, "share1.png")
        };
    },
    onShareTimeline: function() {
        return {
            title: "文博大会-每天答题参与幸运抽奖，瓜分百万现金！",
            imageUrl: "".concat(t.img_url, "share.png")
        };
    }
});