var t = require("../../../utils/util.js"), a = require("../../../utils/serverList.js"), i = getApp();

Page({
    data: {
        img_url: t.img_url,
        page: 1,
        radio: [],
        result: [],
        list: [],
        totality: 0,
        totalScore: 0,
        addressInfo: {}
    },
    add: function() {
        wx.navigateTo({
            url: "/pages/addAddress/addAddress"
        });
    },
    selectAddress: function() {
        i.globalData.addressId = this.data.addressInfo.id, wx.navigateTo({
            url: "/pages/product/selectAddress/selectAddress"
        });
    },
    onChange: function(t) {
        var a = this;
        console.log(t);
        this.setData({
            result: t.detail
        }), this.data.result.length == this.data.list.length ? this.setData({
            radio: [ "1" ]
        }) : this.setData({
            radio: []
        });
        var i = 0, e = 0;
        this.data.list.forEach(function(t) {
            a.data.result.forEach(function(a) {
                a == t.id && (i += Number(t.num), e += Number(t.points));
            });
        }), this.setData({
            totality: i,
            totalScore: e
        });
    },
    onChangeTwo: function(t) {
        this.setData({
            radio: t.detail
        });
        var a = 0, i = 0;
        if ("1" == this.data.radio.length) {
            if (this.data.result.length == this.data.list.length) return;
            var e = [];
            this.data.list.forEach(function(t) {
                e.push(String(t.id)), a += Number(t.num), i += Number(t.points);
            }), this.setData({
                result: e,
                totality: a,
                totalScore: i
            });
        } else this.setData({
            result: [],
            totality: 0,
            totalScore: 0
        });
    },
    subtract: function(t) {
        var a = t.currentTarget.dataset.index, i = (t.currentTarget.dataset.id, this.data.list), e = this.data.totality, s = this.data.totalScore;
        if (i[a].num--, i[a].num <= 0) return i[a].num = 1, i[a].points = i[a].num * i[a].unitPrice, 
        void (this.data.result.includes(String(i[a].id)) && (e -= 1, s -= Number(i[a].unitPrice)));
        i[a].points = i[a].num * i[a].unitPrice, this.data.result.includes(String(i[a].id)) && (e -= 1, 
        s -= Number(i[a].unitPrice)), this.setData({
            list: i,
            totality: e,
            totalScore: s
        });
    },
    append: function(t) {
        var a = t.currentTarget.dataset.index, i = (t.currentTarget.dataset.id, this.data.list), e = this.data.totality, s = this.data.totalScore;
        if (i[a].num++, i[a].num <= 0) return i[a].num = 1, i[a].points = i[a].num * i[a].unitPrice, 
        void (this.data.result.includes(String(i[a].id)) && (e += 1, s += Number(i[a].unitPrice)));
        i[a].points = i[a].num * i[a].unitPrice, console.log(i[a], "1111", this.data.result.includes(String(i[a].id)), "222", this.data.result), 
        this.data.result.includes(String(i[a].id)) && (e += 1, s += Number(i[a].unitPrice)), 
        this.setData({
            list: i,
            totality: e,
            totalScore: s
        });
    },
    confirm: function() {
        var t = this, e = this;
        if (this.data.result.length > 0) {
            var s = [];
            this.data.list.forEach(function(a) {
                t.data.result.forEach(function(t) {
                    a.id == t && s.push({
                        id: a.id,
                        num: a.num
                    });
                });
            });
            var n = {
                addressId: i.globalData.addressId,
                list: s
            };
            (0, a.confirmConversion)(n).then(function(a) {
                a ? (wx.showToast({
                    title: "兑换成功",
                    icon: "success",
                    duration: 2e3
                }), e.init(), t.setData({
                    totality: 0,
                    totalScore: 0,
                    radio: [],
                    result: []
                })) : wx.showToast({
                    title: "兑换失败",
                    icon: "error",
                    duration: 2e3
                });
            });
        } else wx.showToast({
            title: "请选择商品",
            icon: "error",
            duration: 2e3
        });
    },
    init: function() {
        var t = this, e = this;
        (0, a.getshoppingCart)(this.data.page).then(function(a) {
            t.setData({
                list: a
            });
        }), (0, a.getAddress)().then(function(t) {
            t.length > 0 && (i.globalData.addressId ? t.forEach(function(t) {
                t.id == i.globalData.addressId && e.setData({
                    addressInfo: t
                });
            }) : t.forEach(function(a) {
                a.checked ? (i.globalData.addressId = a.id, e.setData({
                    addressInfo: a
                })) : (i.globalData.addressId = a.id, e.setData({
                    addressInfo: t[0]
                }));
            }));
        });
    },
    onLoad: function(t) {
        this.init();
    },
    onReady: function() {},
    onShow: function() {},
    onHide: function() {},
    onUnload: function() {
        this.setData({
            page: 1
        });
    },
    onPullDownRefresh: function() {},
    onReachBottom: function() {
        this.setData({
            page: this.data.page++
        }), this.init();
    },
    onShareAppMessage: function() {
        return {
            title: "文博大会call你啦~挑战12题，赢现金，奖金直接提现！",
            path: "/pages/index/index",
            imageUrl: "".concat(t.img_url, "share1.png")
        };
    },
    onShareTimeline: function() {
        return {
            title: "文博大会-每天答题参与幸运抽奖，瓜分百万现金！",
            imageUrl: "".concat(t.img_url, "share.png")
        };
    }
});