var n = require("../../../utils/serverList.js"), i = require("../../../utils/util.js");

Page({
    data: {
        img_url: i.img_url,
        info: {}
    },
    copy: function() {
        wx.setClipboardData({
            data: this.data.info.trackingNumber,
            success: function() {
                wx.showToast({
                    title: "复制成功",
                    icon: "success",
                    duration: 2e3
                });
            }
        });
    },
    init: function(i) {
        var t = this;
        (0, n.getOrderDetails)(i).then(function(n) {
            console.log(n), t.setData({
                info: n
            });
        });
    },
    onLoad: function(n) {
        console.log(n), this.init(n.id);
    },
    onReady: function() {},
    onShow: function() {},
    onHide: function() {},
    onUnload: function() {},
    onPullDownRefresh: function() {},
    onReachBottom: function() {},
    onShareAppMessage: function() {
        return {
            title: "文博大会call你啦~挑战12题，赢现金，奖金直接提现！",
            path: "/pages/index/index",
            imageUrl: "".concat(i.img_url, "share1.png")
        };
    },
    onShareTimeline: function() {
        return {
            title: "文博大会-每天答题参与幸运抽奖，瓜分百万现金！",
            imageUrl: "".concat(i.img_url, "share.png")
        };
    }
});