var t = require("../../../utils/serverList.js"), n = require("../../../utils/util.js"), a = getApp();

Page({
    data: {
        img_url: n.img_url,
        list: [],
        radio: "1"
    },
    onChange: function(t) {
        this.setData({
            radio: t.detail
        }), a.globalData.addressId = t.detail;
        var n = getCurrentPages(), e = n[n.length - 2];
        wx.navigateBack({
            success: function() {
                e.onLoad();
            }
        });
    },
    add: function() {
        wx.navigateTo({
            url: "/pages/addAddress/addAddress"
        });
    },
    edit: function(t) {
        var n = t.currentTarget.dataset.item;
        wx.navigateTo({
            url: "/pages/addAddress/addAddress?info=".concat(JSON.stringify(n))
        });
    },
    init: function() {
        var n = this;
        (0, t.getAddress)().then(function(t) {
            n.setData({
                list: t
            });
        });
    },
    onLoad: function(t) {
        this.setData({
            radio: a.globalData.addressId
        }), this.init();
    },
    onReady: function() {},
    onShow: function() {},
    onHide: function() {},
    onUnload: function() {},
    onPullDownRefresh: function() {},
    onReachBottom: function() {},
    onShareAppMessage: function() {
        return {
            title: "文博大会call你啦~挑战12题，赢现金，奖金直接提现！",
            path: "/pages/index/index",
            imageUrl: "".concat(n.img_url, "share1.png")
        };
    },
    onShareTimeline: function() {
        return {
            title: "文博大会-每天答题参与幸运抽奖，瓜分百万现金！",
            imageUrl: "".concat(n.img_url, "share.png")
        };
    }
});