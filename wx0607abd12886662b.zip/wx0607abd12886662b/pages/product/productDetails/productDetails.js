var t = require("../../../utils/util.js"), i = require("../../../utils/serverList.js"), n = getApp();

Page({
    data: {
        indicatorDots: !1,
        circular: !0,
        autoplay: !1,
        img_url: t.img_url,
        info: {},
        id: null
    },
    cart: function() {
        wx.navigateTo({
            url: "/pages/product/shoppingCart/shoppingCart"
        });
    },
    addCart: function(t) {
        (0, i.addToCart)(this.data.id).then(function(t) {
            t ? wx.showToast({
                title: "加入购物车成功",
                icon: "success",
                duration: 2e3
            }) : wx.showToast({
                title: "加入购物车失败",
                icon: "error",
                duration: 2e3
            });
        });
    },
    exchange: function() {
        n.globalData.productId = this.data.id, wx.navigateTo({
            url: "/pages/product/confirmOrder/confirmOrder"
        });
    },
    init: function(t) {
        var n = this;
        (0, i.getProductDetails)(t).then(function(t) {
            var i = t.details.replace(/\<img/gi, '<img style="max-width:100% !important;height:auto !important;"');
            n.setData({
                info: t,
                "info.details": i.replace(/\n/g, "<br>")
            });
        });
    },
    onLoad: function(t) {
        this.setData({
            id: t.id
        }), this.init(t.id);
    },
    onReady: function() {},
    onShow: function() {},
    onHide: function() {},
    onUnload: function() {},
    onPullDownRefresh: function() {},
    onReachBottom: function() {},
    onShareAppMessage: function() {
        return {
            title: "文博大会call你啦~挑战12题，赢现金，奖金直接提现！",
            path: "/pages/index/index",
            imageUrl: "".concat(t.img_url, "share1.png")
        };
    },
    onShareTimeline: function() {
        return {
            title: "文博大会-每天答题参与幸运抽奖，瓜分百万现金！",
            imageUrl: "".concat(t.img_url, "share.png")
        };
    }
});