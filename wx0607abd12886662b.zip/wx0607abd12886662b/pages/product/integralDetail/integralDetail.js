var t = require("../../../utils/serverList.js"), n = require("../../../utils/util.js");

Page({
    data: {
        page: 1,
        list: [],
        img_url: n.img_url
    },
    init: function() {
        var n = this;
        (0, t.getIntegralDetail)(this.data.page).then(function(t) {
            console.log(t), n.setData({
                list: t
            });
        });
    },
    onLoad: function(t) {
        this.init();
    },
    onReady: function() {},
    onShow: function() {},
    onHide: function() {},
    onUnload: function() {
        this.setData({
            page: 1
        });
    },
    onPullDownRefresh: function() {},
    onReachBottom: function() {
        this.setData({
            page: this.data.page++
        }), this.init();
    },
    onShareAppMessage: function() {
        return {
            title: "文博大会call你啦~挑战12题，赢现金，奖金直接提现！",
            path: "/pages/index/index",
            imageUrl: "".concat(n.img_url, "share1.png")
        };
    },
    onShareTimeline: function() {
        return {
            title: "文博大会-每天答题参与幸运抽奖，瓜分百万现金！",
            imageUrl: "".concat(n.img_url, "share.png")
        };
    }
});