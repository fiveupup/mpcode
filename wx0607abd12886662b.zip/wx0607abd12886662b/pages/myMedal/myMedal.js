var t = require("../../utils/util.js"), n = require("../../utils/serverList.js"), e = getApp(), i = "".concat(t.img_url, "mine/avatar.png");

Page({
    data: {
        img_url: t.img_url,
        userInfo: {},
        defaultAvatarUrl: i,
        list: [],
        popUp: !1,
        type: "0"
    },
    unpack: function(t) {
        var n = t.currentTarget.dataset.type;
        this.setData({
            popUp: !0,
            type: n
        });
    },
    off: function() {
        this.setData({
            popUp: !1
        });
    },
    init: function() {
        var t = this;
        (0, n.getMedal)().then(function(n) {
            console.log(n), t.setData({
                list: n
            });
        });
    },
    onLoad: function(t) {
        this.init(), this.setData({
            userInfo: e.globalData.userInfo
        });
    },
    onReady: function() {},
    onShow: function() {},
    onHide: function() {},
    onUnload: function() {},
    onPullDownRefresh: function() {},
    onReachBottom: function() {},
    onShareAppMessage: function() {
        return {
            title: "文博大会call你啦~挑战12题，赢现金，奖金直接提现！",
            path: "/pages/index/index",
            imageUrl: "".concat(t.img_url, "share1.png")
        };
    },
    onShareTimeline: function() {
        return {
            title: "文博大会-每天答题参与幸运抽奖，瓜分百万现金！",
            imageUrl: "".concat(t.img_url, "share.png")
        };
    }
});