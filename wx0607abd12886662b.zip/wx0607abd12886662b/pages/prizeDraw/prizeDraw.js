var t = require("../../utils/util.js"), e = require("../../utils/serverList.js"), i = getApp();

Page({
    data: {
        img_url: t.img_url,
        draw: !1,
        rotationDegree: 0,
        points: !1,
        lottery: !1,
        losingIottery: !1,
        userInfo: {},
        name: "",
        tel: "",
        address: "",
        list: [],
        isPrize: !1,
        virtual: !1,
        id: "",
        point: 0,
        pointsImg: "",
        pointsName: ""
    },
    go: function() {
        var i = this, a = "".concat(t.img_url, "prizeDraw/product.png"), n = "".concat(t.img_url, "prizeDraw/product2.png"), s = "".concat(t.img_url, "prizeDraw/product3.png"), o = "".concat(t.img_url, "prizeDraw/product4.png"), r = this;
        this.data.userInfo.point + this.data.userInfo.professionPoint < 1e3 ? this.setData({
            points: !0
        }) : this.data.draw || (this.setData({
            point: this.data.point - 1e3
        }), (0, e.turntableRaffle)().then(function(t) {
            console.log(t), i.setData({
                draw: !0
            }), setTimeout(function() {
                setTimeout(function() {
                    var e = "";
                    "5" == t.prize || "1" == t.prize ? r.setData({
                        losingIottery: !0,
                        id: t.id
                    }) : "4" == t.prize || "8" == t.prize ? (e = "爷爷的传家宝", r.setData({
                        lottery: !0,
                        id: t.id,
                        pointsImg: o
                    })) : "2" != t.prize && "3" != t.prize && "6" != t.prize && "7" != t.prize || (r.setData({
                        virtual: !0,
                        id: t.id
                    }), "2" == t.prize || "6" == t.prize ? ("2" == t.prize && (e = "积分500"), "6" == t.prize && (e = "积分2000"), 
                    r.setData({
                        pointsImg: s
                    })) : "3" == t.prize || "7" == t.prize ? (e = "复活卡x1", r.setData({
                        pointsImg: n
                    })) : r.setData({
                        pointsImg: a
                    })), r.setData({
                        pointsName: e
                    });
                }, 800), r.setData({
                    draw: !1,
                    rotationDegree: 45 * t.prize - 22.5
                });
            }, 5500);
        }));
    },
    answer: function() {
        wx.switchTab({
            url: "/pages/answer/answer"
        }), this.setData({
            points: !1
        });
    },
    cancel: function() {
        this.setData({
            points: !1
        });
    },
    off: function() {
        this.setData({
            lottery: !1,
            losingIottery: !1,
            isPrize: !1,
            virtual: !1
        }), this.init();
    },
    inputChange: function(t) {
        var e = t.currentTarget.dataset.type, i = t.detail.value;
        "name" == e ? this.setData({
            name: i
        }) : "tel" == e ? this.setData({
            tel: i
        }) : "address" == e && this.setData({
            address: i
        });
    },
    submit: function() {
        var i = {
            name: this.data.name,
            tel: this.data.tel,
            address: this.data.address,
            id: this.data.id
        }, a = this;
        this.init(), i.name && i.tel && i.address ? (0, t.validateTel)(i.tel) ? (0, e.submissionPrize)(i).then(function(t) {
            a.setData({
                lottery: !1
            });
        }) : wx.showToast({
            title: "手机号格式错误",
            icon: "none",
            duration: 2e3
        }) : wx.showToast({
            title: "请将信息填写完整",
            icon: "none",
            duration: 2e3
        });
    },
    prizeBtn: function() {
        var t = this;
        (0, e.myPrize)().then(function(e) {
            console.log(e), t.setData({
                isPrize: !0,
                list: e
            });
        });
    },
    copy: function(t) {
        var e = t.currentTarget.dataset.number;
        wx.setClipboardData({
            data: e,
            success: function() {
                wx.showToast({
                    title: "复制成功",
                    icon: "success",
                    duration: 2e3
                });
            }
        });
    },
    init: function() {
        var t = this;
        (0, e.getUserInfo)().then(function(e) {
            i.globalData.userInfo = e, t.setData({
                userInfo: e,
                point: Number(e.point) + Number(e.professionPoint)
            });
        });
    },
    onLoad: function(t) {
        this.setData({
            userInfo: i.globalData.userInfo,
            point: Number(i.globalData.userInfo.point) + Number(i.globalData.userInfo.professionPoint)
        });
    },
    onReady: function() {},
    onShow: function() {},
    onHide: function() {},
    onUnload: function() {},
    onPullDownRefresh: function() {},
    onReachBottom: function() {},
    onShareAppMessage: function() {
        return {
            title: "文博大会call你啦~挑战12题，赢现金，奖金直接提现！",
            path: "/pages/index/index",
            imageUrl: "".concat(t.img_url, "share1.png")
        };
    },
    onShareTimeline: function() {
        return {
            title: "文博大会-每天答题参与幸运抽奖，瓜分百万现金！",
            imageUrl: "".concat(t.img_url, "share.png")
        };
    }
});