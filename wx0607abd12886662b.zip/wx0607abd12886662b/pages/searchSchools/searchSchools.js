var e = require("../../@babel/runtime/helpers/objectSpread2"), t = require("../../utils/serverList.js"), n = require("../../utils/util.js");

Page({
    data: {
        searchValue: "",
        list: [],
        img_url: n.img_url
    },
    handleInput: function(e) {
        var t = e.detail.value;
        this.setData({
            searchValue: t
        });
    },
    search: function() {
        this.data.searchValue ? this.init(this.data.searchValue) : wx.showToast({
            title: "请输入学校名称",
            icon: "none",
            duration: 2e3
        });
    },
    details: function(t) {
        var n = t.currentTarget.dataset.info, a = e({}, n), i = getCurrentPages(), o = i[i.length - 2];
        wx.navigateBack({
            success: function() {
                o.onLoad(a);
            }
        });
    },
    init: function(e) {
        var n = this;
        (0, t.getSchools)(e).then(function(e) {
            n.setData({
                list: e
            });
        });
    },
    onLoad: function(e) {},
    onReady: function() {},
    onShow: function() {},
    onHide: function() {},
    onUnload: function() {},
    onPullDownRefresh: function() {},
    onReachBottom: function() {},
    onShareAppMessage: function() {
        return {
            title: "文博大会call你啦~挑战12题，赢现金，奖金直接提现！",
            path: "/pages/index/index",
            imageUrl: "".concat(n.img_url, "share1.png")
        };
    },
    onShareTimeline: function() {
        return {
            title: "文博大会-每天答题参与幸运抽奖，瓜分百万现金！",
            imageUrl: "".concat(n.img_url, "share.png")
        };
    }
});