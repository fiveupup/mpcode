var n = require("../../utils/util.js"), t = require("../../utils/serverList.js"), e = "".concat(n.img_url, "mine/avatar.png"), i = getApp();

Page({
    data: {
        img_url: n.img_url,
        userInfo: {},
        defaultAvatarUrl: e,
        point: 0
    },
    fullOrder: function() {
        wx.navigateTo({
            url: "/pages/orderList/orderList?type=1"
        });
    },
    await: function() {
        wx.navigateTo({
            url: "/pages/orderList/orderList?type=2"
        });
    },
    points: function() {
        wx.navigateTo({
            url: "/pages/points/points"
        });
    },
    shipped: function() {
        wx.navigateTo({
            url: "/pages/orderList/orderList?type=3"
        });
    },
    cancelled: function() {
        wx.navigateTo({
            url: "/pages/orderList/orderList?type=4"
        });
    },
    integralDetail: function() {
        wx.navigateTo({
            url: "/pages/product/integralDetail/integralDetail"
        });
    },
    initUser: function() {
        var n = this;
        (0, t.getUserInfo)().then(function(t) {
            i.globalData.userInfo = t, n.setData({
                userInfo: t,
                point: Number(t.point) + Number(t.professionPoint)
            });
        });
    },
    onLoad: function(n) {},
    onReady: function() {},
    onShow: function() {
        this.initUser();
    },
    onHide: function() {},
    onUnload: function() {},
    onPullDownRefresh: function() {},
    onReachBottom: function() {},
    onShareAppMessage: function() {
        return {
            title: "文博大会call你啦~挑战12题，赢现金，奖金直接提现！",
            path: "/pages/index/index",
            imageUrl: "".concat(n.img_url, "share1.png")
        };
    },
    onShareTimeline: function() {
        return {
            title: "文博大会-每天答题参与幸运抽奖，瓜分百万现金！",
            imageUrl: "".concat(n.img_url, "share.png")
        };
    }
});