var n = require("../../utils/serverList.js"), t = require("../../utils/util.js");

Page({
    data: {
        list: [],
        img_url: t.img_url
    },
    add: function() {
        wx.navigateTo({
            url: "/pages/addAddress/addAddress"
        });
    },
    edit: function(n) {
        var t = n.currentTarget.dataset.item;
        wx.navigateTo({
            url: "/pages/addAddress/addAddress?info=".concat(JSON.stringify(t))
        });
    },
    init: function() {
        var t = this;
        (0, n.getAddress)().then(function(n) {
            t.setData({
                list: n
            });
        });
    },
    onLoad: function(n) {
        this.init();
    },
    onReady: function() {},
    onShow: function() {},
    onHide: function() {},
    onUnload: function() {},
    onPullDownRefresh: function() {},
    onReachBottom: function() {},
    onShareAppMessage: function() {
        return {
            title: "文博大会call你啦~挑战12题，赢现金，奖金直接提现！",
            path: "/pages/index/index",
            imageUrl: "".concat(t.img_url, "share1.png")
        };
    },
    onShareTimeline: function() {
        return {
            title: "文博大会-每天答题参与幸运抽奖，瓜分百万现金！",
            imageUrl: "".concat(t.img_url, "share.png")
        };
    }
});