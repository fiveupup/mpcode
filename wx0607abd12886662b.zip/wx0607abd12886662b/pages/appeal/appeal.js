var t = require("../../utils/util.js"), e = require("../../utils/serverList.js");

Page({
    data: {
        email: "",
        text: "",
        img_url: t.img_url
    },
    handleInput: function(t) {
        var e = t.detail.value;
        this.setData({
            email: e
        });
    },
    handleText: function(t) {
        var e = t.detail.value;
        this.setData({
            text: e
        });
    },
    submit: function() {
        if (this.data.email && this.data.text) if ((0, t.validateEmail)(this.data.email)) {
            var i = {
                email: this.data.email,
                text: this.data.text
            };
            (0, e.setAppeal)(i).then(function(t) {
                t ? wx.showToast({
                    title: "提交成功",
                    icon: "success",
                    duration: 2e3
                }) : wx.showToast({
                    title: "提交失败",
                    icon: "none",
                    duration: 2e3
                });
            });
        } else wx.showToast({
            title: "邮箱格式错误",
            icon: "none",
            duration: 2e3
        }); else wx.showToast({
            title: "请将信息填写完整",
            icon: "none",
            duration: 2e3
        });
    },
    onLoad: function(t) {},
    onReady: function() {},
    onShow: function() {},
    onHide: function() {},
    onUnload: function() {},
    onPullDownRefresh: function() {},
    onReachBottom: function() {},
    onShareAppMessage: function() {
        return {
            title: "文博大会call你啦~挑战12题，赢现金，奖金直接提现！",
            path: "/pages/index/index",
            imageUrl: "".concat(t.img_url, "share1.png")
        };
    },
    onShareTimeline: function() {
        return {
            title: "文博大会-每天答题参与幸运抽奖，瓜分百万现金！",
            imageUrl: "".concat(t.img_url, "share.png")
        };
    }
});