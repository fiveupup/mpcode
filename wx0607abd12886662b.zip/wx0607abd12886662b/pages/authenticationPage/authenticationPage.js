var a = require("../../utils/request.js"), t = require("../../utils/serverList.js"), e = require("../../utils/util.js");

Page({
    data: {
        radio: "1",
        checked: !1,
        school: {},
        name: "",
        certificate: "",
        upload1: "".concat(e.img_url, "authenticationPage/upload.png"),
        urlUpload1: "",
        upload2: "".concat(e.img_url, "authenticationPage/upload.png"),
        urlUpload2: "",
        upload3: "".concat(e.img_url, "authenticationPage/upload.png"),
        urlUpload3: "",
        upload4: "".concat(e.img_url, "authenticationPage/upload.png"),
        urlUpload4: "",
        img_url: e.img_url
    },
    handleInput: function(a) {
        var t = a.currentTarget.dataset.type, e = a.detail.value;
        "name" == t ? this.setData({
            name: e
        }) : "certificate" == t && this.setData({
            certificate: e
        });
    },
    agreement: function() {
        wx.navigateTo({
            url: "/pages/agreementPage/agreementPage"
        });
    },
    radioChange: function(a) {
        this.setData({
            radio: a.detail.value
        });
    },
    select: function() {
        wx.navigateTo({
            url: "/pages/searchSchools/searchSchools"
        });
    },
    upload: function(t) {
        var e = t.currentTarget.dataset.type, i = this;
        wx.chooseMedia({
            count: 1,
            mediaType: [ "image" ],
            sourceType: [ "album", "camera" ],
            sizeType: [ "original", "compressed" ],
            camera: "back",
            success: function(t) {
                (0, a.uploadImage)(t.tempFiles[0].tempFilePath).then(function(a) {
                    "a1" == e ? i.setData({
                        urlUpload1: a,
                        upload1: a
                    }) : "a2" == e ? i.setData({
                        urlUpload2: a,
                        upload2: a
                    }) : "b1" == e ? i.setData({
                        urlUpload3: a,
                        upload3: a
                    }) : "b2" == e && i.setData({
                        urlUpload4: a,
                        upload4: a
                    });
                });
            }
        });
    },
    onChange: function(a) {
        this.setData({
            checked: a.detail
        });
    },
    submit: function() {
        var a = {};
        "1" == this.data.radio ? (a = {
            type: this.data.radio,
            name: this.data.name,
            certificate: this.data.certificate,
            school: this.data.school.name,
            img_list: [ this.data.urlUpload1, this.data.urlUpload2 ],
            agreement: this.data.checked
        }, console.log(a, "info"), a.name && a.certificate && "选择" != a.school && a.img_list[0] && a.img_list[1] && a.agreement ? (0, 
        t.setCertifiedMajor)(a).then(function(a) {
            a ? wx.navigateTo({
                url: "/pages/examine/examine"
            }) : wx.showToast({
                title: "提交失败",
                icon: "error",
                duration: 2e3
            });
        }) : wx.showToast({
            title: "请将信息填写完整",
            icon: "none",
            duration: 2e3
        })) : "2" == this.data.radio && ((a = {
            type: this.data.radio,
            name: this.data.name,
            certificate: this.data.certificate,
            school: "",
            img_list: [ this.data.urlUpload3, this.data.urlUpload4 ],
            agreement: this.data.checked
        }).name && a.certificate && a.img_list[0] && a.img_list[1] && a.agreement ? (0, 
        t.setCertifiedMajor)(a).then(function(a) {
            a ? wx.navigateTo({
                url: "/pages/examine/examine"
            }) : wx.showToast({
                title: "提交失败",
                icon: "error",
                duration: 2e3
            });
        }) : wx.showToast({
            title: "请将信息填写完整",
            icon: "none",
            duration: 2e3
        }));
    },
    onLoad: function(a) {
        a.name ? this.setData({
            school: a
        }) : this.setData({
            school: {
                name: "选择"
            }
        });
    },
    onReady: function() {},
    onShow: function() {},
    onHide: function() {},
    onUnload: function() {},
    onPullDownRefresh: function() {},
    onReachBottom: function() {},
    onShareAppMessage: function() {
        return {
            title: "文博大会call你啦~挑战12题，赢现金，奖金直接提现！",
            path: "/pages/index/index",
            imageUrl: "".concat(e.img_url, "share1.png")
        };
    },
    onShareTimeline: function() {
        return {
            title: "文博大会-每天答题参与幸运抽奖，瓜分百万现金！",
            imageUrl: "".concat(e.img_url, "share.png")
        };
    }
});