var t = require("../../utils/util.js"), e = require("../../utils/serverList.js");

Page({
    data: {
        page: 1,
        img_url: t.img_url,
        type: "",
        list: [],
        active: 0
    },
    onChange: function(t) {
        console.log(t.detail.name), this.setData({
            active: t.detail.name,
            type: t.detail.name + 1
        }), this.init(this.data.type);
    },
    cancel: function(t) {
        var i = t.currentTarget.dataset.id, a = this;
        wx.showModal({
            title: "提示",
            content: "您确定取消订单吗?",
            success: function(t) {
                t.confirm ? (0, e.cancelOrder)(i).then(function(t) {
                    t && a.init(a.data.type);
                }) : t.cancel && console.log("用户点击取消");
            }
        });
    },
    details: function(t) {
        var e = t.currentTarget.dataset.id;
        "4" != t.currentTarget.dataset.type && wx.navigateTo({
            url: "/pages/product/orderDetails/orderDetails?id=".concat(e)
        });
    },
    init: function(t) {
        var i = this;
        (0, e.getOrder)({
            type: t,
            page: this.data.page
        }).then(function(t) {
            console.log(t), i.setData({
                list: t
            });
        });
    },
    onLoad: function(t) {
        "1" == t.type ? wx.setNavigationBarTitle({
            title: "全部订单"
        }) : "2" == t.type ? wx.setNavigationBarTitle({
            title: "待发货"
        }) : "3" == t.type ? wx.setNavigationBarTitle({
            title: "已发货"
        }) : "4" == t.type && wx.setNavigationBarTitle({
            title: "已取消"
        }), this.init(t.type), this.setData({
            type: t.type,
            active: t.type - 1
        });
    },
    onReady: function() {},
    onShow: function() {},
    onHide: function() {},
    onUnload: function() {
        this.setData({
            page: 1
        });
    },
    onPullDownRefresh: function() {},
    onReachBottom: function() {
        this.setData({
            page: this.data.page++
        }), this.init(this.data.type);
    },
    onShareAppMessage: function() {
        return {
            title: "文博大会call你啦~挑战12题，赢现金，奖金直接提现！",
            path: "/pages/index/index",
            imageUrl: "".concat(t.img_url, "share1.png")
        };
    },
    onShareTimeline: function() {
        return {
            title: "文博大会-每天答题参与幸运抽奖，瓜分百万现金！",
            imageUrl: "".concat(t.img_url, "share.png")
        };
    }
});