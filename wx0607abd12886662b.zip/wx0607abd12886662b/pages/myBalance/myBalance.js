var n = require("../../utils/serverList.js"), t = require("../../utils/util.js"), e = getApp();

Page({
    data: {
        list: [],
        img_url: t.img_url,
        userInfo: {}
    },
    init: function() {
        var t = this;
        (0, n.getBalanceList)().then(function(n) {
            t.setData({
                list: n
            });
        });
    },
    withdraw: function() {
        var t = this;
        t.data.userInfo.balance >= "0.3" ? wx.showModal({
            title: "提现",
            content: "提现到零钱",
            success: function(e) {
                e.confirm ? (0, n.getBalance)(t.data.userInfo.balance).then(function(n) {
                    n ? wx.showToast({
                        title: "提现成功",
                        icon: "success",
                        duration: 2e3
                    }) : wx.showToast({
                        title: "提现失败",
                        icon: "error",
                        duration: 2e3
                    });
                }) : e.cancel && console.log("用户点击取消");
            }
        }) : wx.showToast({
            title: "余额不足",
            icon: "none",
            duration: 2e3
        });
    },
    onLoad: function(n) {
        this.init(), this.setData({
            userInfo: e.globalData.userInfo
        });
    },
    onReady: function() {},
    onShow: function() {},
    onHide: function() {},
    onUnload: function() {},
    onPullDownRefresh: function() {},
    onReachBottom: function() {},
    onShareAppMessage: function() {
        return {
            title: "文博大会call你啦~挑战12题，赢现金，奖金直接提现！",
            path: "/pages/index/index",
            imageUrl: "".concat(t.img_url, "share1.png")
        };
    },
    onShareTimeline: function() {
        return {
            title: "文博大会-每天答题参与幸运抽奖，瓜分百万现金！",
            imageUrl: "".concat(t.img_url, "share.png")
        };
    }
});