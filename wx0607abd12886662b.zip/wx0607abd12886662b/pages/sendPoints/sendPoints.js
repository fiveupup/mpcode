var t = require("../../@babel/runtime/helpers/defineProperty");

require("../../@babel/runtime/helpers/Objectvalues");

var e = require("../../utils/util.js"), a = require("../../utils/serverList.js"), n = getApp();

Page({
    data: {
        topic: {},
        time: n.globalData.museumRule.time,
        img_url: e.img_url,
        countdownInterval: null,
        isFailToAnswer: !1,
        isAnswerSuccessfully: !1,
        type: "1",
        active: {
            select: "1",
            answer: "",
            answerList: {}
        },
        scrollTop: 0,
        times: null,
        keys: "",
        currentDelayTime: null
    },
    clickSelect: function(t) {
        var i = this;
        if ((0, e.debounce)(1e3, i.data.currentDelayTime)) {
            var s = t.currentTarget.dataset.type, r = t.currentTarget.dataset.key, o = t.currentTarget.dataset.id;
            if (i.setData({
                keys: r
            }), "1" == s) {
                this.setData({
                    type: s,
                    num: o,
                    active: {
                        select: "1",
                        answer: r
                    }
                });
                var c = {};
                c[i.data.active.answer] = i.data.active.answer, (0, a.answerSubmission)(i.data.topic.id, c, i.data.topic.wyy, i.data.topic.wyy_point).then(function(t) {
                    if (i.data.active.answer == Object.keys(t.answer)[0]) {
                        clearInterval(i.data.countdownInterval);
                        var a = wx.createInnerAudioContext({
                            useWebAudioImplement: !0
                        });
                        a.src = "".concat(e.audio_url, "correct.mp3"), a.play(), setTimeout(function() {
                            i.setData({
                                isAnswerSuccessfully: !0
                            }), a.stop(), n.globalData.topicInfo = {}, i.init(n.globalData.museumId, "");
                        }, 1e3);
                    } else {
                        clearInterval(i.data.countdownInterval);
                        var s = wx.createInnerAudioContext({
                            useWebAudioImplement: !0
                        });
                        s.src = "".concat(e.audio_url, "mistake1.mp3"), s.play(), setTimeout(function() {
                            i.setData({
                                isFailToAnswer: !0
                            }), n.globalData.topicInfo = {}, s.stop();
                        }, 2e3);
                    }
                    i.setData({
                        active: {
                            select: "2",
                            answer: Object.keys(t.answer)[0]
                        }
                    });
                });
            }
            i.setData({
                currentDelayTime: new Date().getTime()
            });
        }
    },
    submit: function() {
        var t = this;
        if ("1" == t.data.type) {
            var e = {};
            if (e[t.data.active.answer] = t.data.active.answer, !t.data.active.answer) return void wx.showToast({
                title: "请选择答案",
                icon: "none"
            });
            (0, a.answerSubmission)(t.data.topic.id, e, t.data.topic.wyy, t.data.topic.wyy_point).then(function(e) {
                t.data.active.answer == Object.keys(e.answer)[0] ? (clearInterval(t.data.countdownInterval), 
                t.setData({
                    isAnswerSuccessfully: !0
                }), t.init(n.globalData.museumId, "")) : (clearInterval(t.data.countdownInterval), 
                t.setData({
                    isFailToAnswer: !0
                })), t.setData({
                    active: {
                        select: "2",
                        answer: Object.keys(e.answer)[0]
                    }
                });
            });
        } else if ("2" == t.data.type) {
            var i = Object.keys(t.data.active.answerList);
            if (i.length <= 0) return void wx.showToast({
                title: "请选择答案"
            });
            (0, a.answerSubmission)(t.data.topic.id, i, t.data.topic.wyy, t.data.topic.wyy_point).then(function(e) {
                console.log(t.data.active.answerList, "5555", e, "666", i), JSON.stringify(t.data.active.answerList) == JSON.stringify(e.answer) ? (console.log("答案正确"), 
                clearInterval(t.data.countdownInterval), t.setData({
                    isAnswerSuccessfully: !0
                }), t.init(n.globalData.museumId, "")) : (clearInterval(t.data.countdownInterval), 
                t.setData({
                    isFailToAnswer: !0
                })), t.setData({
                    active: {
                        select: "2",
                        answer: e.answer
                    }
                });
            });
        }
    },
    resume: function() {
        wx.redirectTo({
            url: "/pages/answerPage/answerPage"
        });
    },
    init: function(e, i) {
        var s = this, r = null;
        clearInterval(r), this.setData({
            time: n.globalData.museumRule.time
        });
        var o = this, c = Object.values(n.globalData.topicInfo);
        if (console.log(c, "789"), c.length > 0) {
            this.setData(t({
                active: {
                    select: "1",
                    answer: "",
                    answerList: {}
                },
                topic: {}
            }, "topic", n.globalData.topicInfo));
            var l = Number(this.data.time);
            r = setInterval(function() {
                l--, console.log(l), o.setData({
                    time: l
                }), l <= 0 && (clearInterval(r), console.log(o.data.topic, "44456465"), (0, a.answerSubmission)(o.data.topic.id, {}, o.data.topic.wyy, o.data.topic.wyy_point).then(function(t) {
                    console.log(t, "456465");
                }), o.setData({
                    isFailToAnswer: !0
                }));
            }, 1e3), this.setData({
                countdownInterval: r
            }), n.globalData.topicInfo = {};
        } else (0, a.getTopic)(e, i).then(function(e) {
            s.setData({
                active: {
                    select: "1",
                    answer: "",
                    answerList: {}
                }
            }), "1" == e.wyy ? s.setData(t({
                topic: {}
            }, "topic", e)) : n.globalData.topicInfo = e;
        });
        var u = 0, d = setInterval(function() {
            u > 20 ? clearInterval(o.data.times) : (u++, o.setData({
                scrollTop: u
            }));
        }, 100);
        o.setData({
            times: d
        });
    },
    onLoad: function(t) {
        this.init(n.globalData.museumId, "");
    },
    onReady: function() {},
    onShow: function() {
        console.log(wx.getStorageSync("markers"), "执行打印");
        var t = this;
        if (wx.getStorageSync("markers")) {
            var e = Number(wx.getStorageSync("markers")), n = setInterval(function() {
                e--, console.log(e), t.setData({
                    time: e
                }), e <= 0 && (clearInterval(n), (0, a.answerSubmission)(t.data.topic.id, {}, 0, 0).then(function(t) {}), 
                t.setData({
                    isFailToAnswer: !0
                }));
            }, 1e3);
            this.setData({
                countdownInterval: n
            }), wx.removeStorageSync("markers");
        }
    },
    onHide: function() {
        console.log("执行了", this.data.time), wx.setStorageSync("markers", this.data.time), 
        clearInterval(this.data.countdownInterval);
    },
    onUnload: function() {
        clearInterval(this.data.countdownInterval), wx.removeStorageSync("markers");
    },
    onPullDownRefresh: function() {},
    onReachBottom: function() {},
    onShareAppMessage: function() {
        return {
            title: "文博大会call你啦~挑战12题，赢现金，奖金直接提现！",
            path: "/pages/index/index",
            imageUrl: "".concat(e.img_url, "share1.png")
        };
    },
    onShareTimeline: function() {
        return {
            title: "文博大会-每天答题参与幸运抽奖，瓜分百万现金！",
            imageUrl: "".concat(e.img_url, "share.png")
        };
    }
});