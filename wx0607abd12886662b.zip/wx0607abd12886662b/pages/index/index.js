var t = require("../../utils/serverList.js"), e = require("../../utils/util.js"), a = getApp(), n = "".concat(e.img_url, "mine/avatar.png");

Page({
    data: {
        indicatorDots: !1,
        circular: !0,
        autoplay: !0,
        interval: 4e3,
        duration: 1e3,
        banner: [],
        text: "",
        topic: {},
        content: "",
        isOff: !1,
        img_url: e.img_url,
        userInfo: {},
        privacy: !1,
        privacyValue: 0,
        museumRule: {},
        show: !1,
        avatarUrl: n,
        imgUser: "",
        nickname: "",
        query: {},
        music: !0,
        innerAudioContext: null,
        isStrategy: !1,
        strategyValue: "",
        nextPop: !1,
        nextValue: 1,
        isCode: !1,
        resolvePrivacyAuthorization: null,
        isAddressTwo: !0
    },
    musicPlay: function(t) {
        var a = t.currentTarget.dataset.type, n = null;
        this.data.innerAudioContext || ((n = wx.createInnerAudioContext({
            useWebAudioImplement: !1
        })).loop = !0, this.setData({
            innerAudioContext: n
        })), this.data.innerAudioContext.src = "".concat(e.audio_url, "bg2.mp3"), "1" == a ? (console.log("停止"), 
        this.data.innerAudioContext.stop(), this.setData({
            music: !1
        })) : (console.log("播放"), this.data.innerAudioContext.play(), this.data.innerAudioContext.loop = !0, 
        this.setData({
            music: !0
        }));
    },
    balance: function() {
        console.log(a.globalData.userInfo, "app.globalData.userInfo"), a.globalData.userInfo.tel ? wx.navigateTo({
            url: "/pages/myBalance/myBalance"
        }) : wx.switchTab({
            url: "/pages/mine/mine"
        });
    },
    strategy: function() {
        this.setData({
            isStrategy: !0
        });
    },
    offStrategy: function() {
        this.setData({
            isStrategy: !1
        }), this.initUser(), this.data.privacyValue ? this.setData({
            nextPop: !1
        }) : this.setData({
            nextPop: !0
        });
    },
    next: function(t) {
        var e = t.currentTarget.dataset.type;
        this.setData({
            nextValue: Number(e) + 1
        }), console.log(this.data.nextValue);
    },
    complete: function() {
        this.setData({
            nextPop: !1
        });
        var e = this;
        (0, t.isCodeNum)().then(function(t) {
            t && e.setData({
                isCode: !0
            });
        });
    },
    verifySuccess: function() {
        this.data.userInfo.nickname || this.data.userInfo.headimg || this.setData({
            show: !0
        });
    },
    verifyError: function() {
        wx.showToast({
            title: "失败",
            icon: "error"
        });
    },
    details: function(t) {
        var a = t.currentTarget.dataset.item.id, n = t.currentTarget.dataset.item.type, i = t.currentTarget.dataset.item.link, o = t.currentTarget.dataset.item.appid, s = t.currentTarget.dataset.item.pages;
        0 == n ? wx.navigateTo({
            url: "/pages/indexDetails/indexDetails?id=".concat(a)
        }) : 1 == n ? wx.navigateTo({
            url: "/pages/product/productDetails/productDetails?id=".concat(i)
        }) : 2 == n ? wx.navigateTo({
            url: "/pages/viewPage/viewPage?link=".concat(i)
        }) : 3 == n && wx.navigateToMiniProgram({
            appId: o,
            path: s,
            envVersion: e.envVersion,
            extraData: {},
            success: function(t) {
                console.log("打开");
            },
            fail: function(t) {}
        });
    },
    onChooseAvatar: function(t) {
        var e = this, a = t.detail.avatarUrl;
        e.setData({
            avatarUrl: a
        }), wx.getFileSystemManager().readFile({
            filePath: a,
            encoding: "base64",
            position: 0,
            success: function(t) {
                e.setData({
                    imgUser: t.data
                });
            },
            fail: function(t) {
                console.error(t);
            }
        });
    },
    nickname: function(t) {
        this.setData({
            nickname: t.detail.value
        });
    },
    save: function() {
        var e = this;
        if (this.data.nickname && this.data.avatarUrl != n) {
            var a = {
                nickname: this.data.nickname,
                avatarUrl: this.data.imgUser
            };
            (0, t.userInfo)(a).then(function(t) {
                t ? (e.setData({
                    show: !1
                }), e.initUser()) : wx.showToast({
                    title: "保存失败",
                    icon: "none"
                });
            });
        } else wx.showToast({
            title: "请授权头像、昵称",
            icon: "none"
        });
    },
    answer: function() {
        this.data.museumRule.number <= 0 ? wx.showToast({
            title: "今日答题次数已用完",
            icon: "none",
            duration: 2e3
        }) : wx.navigateTo({
            url: "/pages/answerPage/answerPage?id=".concat(this.data.topic.mid, "&id2=").concat(this.data.topic.id)
        });
    },
    revivalCard: function() {
        wx.navigateTo({
            url: "/pages/revivalCardPage/revivalCardPage?type=index&fid=".concat(a.globalData.fid)
        });
    },
    regulations: function() {
        var e = this;
        (0, t.getRegulations)().then(function(t) {
            e.setData({
                content: t
            });
        }), this.setData({
            isOff: !0
        });
    },
    signIn: function() {
        (0, t.signIn)().then(function(t) {
            t.signIn ? wx.showToast({
                title: "签到成功 获得100积分",
                icon: "none",
                duration: 2e3
            }) : wx.showToast({
                title: "签到失败",
                icon: "error",
                duration: 2e3
            });
        }), this.initUser();
    },
    exchange: function() {
        wx.switchTab({
            url: "/pages/exchange/exchange"
        });
    },
    off: function() {
        this.setData({
            isOff: !1
        });
    },
    privacy: function() {
        console.log("隐私"), wx.downloadFile({
            url: "".concat(e.document_url, "privacy1.docx"),
            success: function(t) {
                var e = t.tempFilePath;
                wx.openDocument({
                    filePath: e,
                    fileType: "docx",
                    success: function(t) {
                        console.log("打开文档成功");
                    },
                    fail: function(t) {
                        console.log("打开文档失败");
                    }
                });
            }
        });
    },
    notAgree: function() {
        wx.exitMiniProgram({
            success: function(t) {
                console.log("关闭小程序");
            }
        });
    },
    agree: function() {
        var e = this;
        (0, t.setUserAgree)().then(function(a) {
            a ? wx.getFuzzyLocation({
                type: "wgs84",
                success: function(a) {
                    console.log(a, "resres");
                    var n = "".concat(Number(a.latitude), ",").concat(Number(a.longitude));
                    wx.request({
                        url: "https://apis.map.qq.com/ws/geocoder/v1/?location=".concat(n, "&key=2BQBZ-KXLEG-QHMQL-QHZWL-ZIT2Q-HGB6Z&get_poi=0"),
                        success: function(a) {
                            console.log(a.data.result.ad_info, "resres"), (0, t.setAddressIp)(a.data.result.ad_info).then(function(a) {
                                console.log(a);
                                var n = e.data.query.fid;
                                n && (0, t.setInvite)(n).then(function(t) {}), e.setData({
                                    privacy: !1,
                                    isStrategy: !0
                                });
                            });
                        }
                    });
                },
                fail: function(t) {
                    e.setData({
                        privacy: !1,
                        isStrategy: !0,
                        isAddressTwo: !1
                    });
                }
            }) : wx.showToast({
                title: "隐私政策同意失败",
                icon: "none"
            });
        });
    },
    getAddressTwo: function() {
        wx.openSetting({
            success: function(t) {
                console.log(t.authSetting);
            },
            fail: function(t) {
                console.log(t);
            }
        });
    },
    init: function() {
        var e = this;
        (0, t.getBanner)().then(function(t) {
            e.setData({
                banner: t
            });
        }), (0, t.getMuseumList)().then(function(t) {
            a.globalData.museumList = t;
        }), this.initUser(), (0, t.getPrize)().then(function(t) {
            var a = "";
            t.forEach(function(t) {
                a += "用户 ".concat(t.name, " 刚刚挑战成功 获得了").concat(t.amount, "元 ");
            }), e.setData({
                text: a
            });
        }), (0, t.getIndexTopic)().then(function(t) {
            e.setData({
                topic: t
            });
        }), (0, t.getUserIpAddress)().then(function(t) {
            console.log(t);
        }), (0, t.shareQuery)().then(function(t) {
            a.globalData.fid = t, wx.setStorageSync("FID", t);
        }), (0, t.getStrategy)().then(function(t) {
            e.setData({
                strategyValue: t
            });
        });
    },
    initUser: function() {
        var e = this, n = this;
        (0, t.getMuseumRule)().then(function(t) {
            a.globalData.museumRule = t, e.setData({
                museumRule: t
            });
        }), (0, t.getUserInfo)().then(function(i) {
            console.log(i, "res111"), a.globalData.userInfo = i, i.headimg || i.nickname || e.setData({
                show: !0
            });
            var o = e.data.query.fid ? e.data.query.fid : "";
            i.privacy && o && (0, t.setInvite)(o).then(function(t) {}), e.setData({
                userInfo: i
            }), i.privacy ? e.setData({
                privacy: !1,
                privacyValue: i.privacy
            }) : (e.setData({
                privacy: !0,
                privacyValue: i.privacy
            }), wx.getSetting({
                success: function(t) {
                    t.authSetting.hasOwnProperty("scope.userFuzzyLocation") && !t.authSetting["scope.userFuzzyLocation"] ? n.setData({
                        isAddressTwo: !1
                    }) : n.setData({
                        isAddressTwo: !0
                    });
                }
            }));
        });
    },
    onLoad: function(t) {
        var n = this, i = 0 === Object.keys(t).length ? a.globalData.fid : t;
        this.setData({
            query: i
        });
        a.globalData.checkLogin ? this.init() : a.checkLoginReadyCallback = function(t) {
            console.log("checkLoginReadyCallback"), console.log(t), n.init();
        };
        var o = null;
        this.data.innerAudioContext || ((o = wx.createInnerAudioContext({
            useWebAudioImplement: !1
        })).loop = !0, this.setData({
            innerAudioContext: o
        })), this.data.innerAudioContext.src = "".concat(e.audio_url, "bg2.mp3"), this.data.innerAudioContext.play();
    },
    handleAgree: function(t) {
        console.log(t, "执行"), this.triggerEvent("agree");
    },
    onShow: function() {
        a.globalData.userToken && (this.initUser(), this.init()), this.getTabBar().init();
    },
    onHide: function() {},
    onUnload: function() {},
    onShareAppMessage: function() {
        return {
            title: "文博大会call你啦~挑战12题，赢现金，奖金直接提现！",
            path: "/pages/index/index",
            imageUrl: "".concat(e.img_url, "share1.png")
        };
    },
    onShareTimeline: function() {
        return {
            title: "文博大会-每天答题参与幸运抽奖，瓜分百万现金！",
            imageUrl: "".concat(e.img_url, "share.png")
        };
    }
});