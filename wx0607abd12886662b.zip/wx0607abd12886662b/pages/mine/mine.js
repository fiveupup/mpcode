var a = require("../../utils/util.js"), e = require("../../utils/serverList.js"), t = "".concat(a.img_url, "mine/avatar.png"), n = getApp();

Page({
    data: {
        img_url: a.img_url,
        show: !1,
        avatarUrl: t,
        imgUser: "",
        defaultAvatarUrl: t,
        nickname: "默认昵称",
        userInfo: {},
        imgNum: 1,
        point: 0,
        tel: "",
        isAccredit: !1,
        currentDelayTime: null
    },
    message: function() {
        wx.navigateTo({
            url: "/pages/message/message"
        });
    },
    withdraw: function() {
        var a = this;
        a.data.userInfo.balance >= "0.3" ? wx.showModal({
            title: "提现",
            content: "提现到零钱",
            success: function(t) {
                t.confirm ? (0, e.getBalance)(a.data.userInfo.balance).then(function(a) {
                    a ? wx.showToast({
                        title: "提现成功",
                        icon: "success",
                        duration: 2e3
                    }) : wx.showToast({
                        title: "提现失败",
                        icon: "error",
                        duration: 2e3
                    });
                }) : t.cancel && console.log("用户点击取消");
            }
        }) : wx.showToast({
            title: "余额不足",
            icon: "none",
            duration: 2e3
        });
    },
    exchange: function() {
        wx.switchTab({
            url: "/pages/exchange/exchange"
        });
    },
    accredit: function() {
        this.data.userInfo.nickname || this.data.userInfo.headimg || this.setData({
            show: !0
        });
    },
    onChooseAvatar: function(a) {
        var e = this, t = a.detail.avatarUrl;
        e.setData({
            avatarUrl: t
        }), wx.getFileSystemManager().readFile({
            filePath: t,
            encoding: "base64",
            position: 0,
            success: function(a) {
                e.setData({
                    imgUser: a.data
                });
            },
            fail: function(a) {
                console.error(a);
            }
        });
    },
    nickname: function(a) {
        this.setData({
            nickname: a.detail.value
        });
    },
    handleInput: function(a) {
        this.setData({
            tel: a.detail.value
        });
    },
    save: function() {
        var a = this;
        if (this.data.nickname && this.data.avatarUrl != t) {
            var n = {
                nickname: this.data.nickname,
                avatarUrl: this.data.imgUser
            };
            (0, e.userInfo)(n).then(function(e) {
                e ? (a.setData({
                    show: !1
                }), a.init()) : wx.showToast({
                    title: "保存失败",
                    icon: "none"
                });
            });
        } else wx.showToast({
            title: "请授权头像、昵称",
            icon: "none"
        });
    },
    onGetPhoneNumberTel: function(a) {
        var t = this;
        if ("getPhoneNumber:ok" === a.detail.errMsg) {
            console.log(a.detail);
            var n = a.detail.code;
            a.detail.iv;
            (0, e.getTel)(n).then(function(a) {
                t.setData({
                    tel: a,
                    isAccredit: !1
                });
            });
        } else console.log("拒绝"), (0, e.downTel)().then(function(a) {
            a && t.setData({
                isAccredit: !1
            });
        });
    },
    points: function() {
        wx.navigateTo({
            url: "/pages/points/points"
        });
    },
    balance: function() {
        wx.navigateTo({
            url: "/pages/myBalance/myBalance"
        });
    },
    badge: function() {
        wx.navigateTo({
            url: "/pages/myMedal/myMedal"
        });
    },
    prizeDraw: function() {
        wx.navigateTo({
            url: "/pages/prizeDraw/prizeDraw"
        });
    },
    order: function() {
        wx.navigateTo({
            url: "/pages/myOrder/myOrder"
        });
    },
    address: function() {
        wx.navigateTo({
            url: "/pages/myAddress/myAddress"
        });
    },
    authentication: function() {
        "1" == this.data.userInfo.isAuthor ? wx.navigateTo({
            url: "/pages/examine/examine"
        }) : wx.navigateTo({
            url: "/pages/authenticationPage/authenticationPage"
        });
    },
    init: function() {
        var a = this;
        console.log("调用个人信息接口");
        (0, e.getUserInfo)().then(function(e) {
            if (e.tel || e.isTel || a.setData({
                isAccredit: !0
            }), n.globalData.userInfo = e, a.setData({
                userInfo: e,
                point: Number(e.point) + Number(e.professionPoint),
                avatarUrl: e.headimg,
                nickname: e.nickname,
                tel: e.tel
            }), a.data.userInfo.nickname || a.data.userInfo.headimg || a.setData({
                show: !0
            }), e.medal) {
                var t = e.medal.substring(e.medal.length - 2);
                "文博分享家" == e.medal ? a.setData({
                    imgNum: 1
                }) : "文博分享家II" == e.medal ? a.setData({
                    imgNum: 2
                }) : "文博分享家III" == e.medal ? a.setData({
                    imgNum: 3
                }) : "文博签到使" == e.medal ? a.setData({
                    imgNum: 4
                }) : "文博签到使II" == e.medal ? a.setData({
                    imgNum: 5
                }) : "文博签到使III" == e.medal ? a.setData({
                    imgNum: 6
                }) : "学士" == t ? a.setData({
                    imgNum: 7
                }) : "硕士" == t ? a.setData({
                    imgNum: 8
                }) : "博士" == t && a.setData({
                    imgNum: 9
                });
            }
        });
    },
    onLoad: function(a) {},
    onReady: function() {},
    onShow: function() {
        this.getTabBar().init(), this.init();
    },
    onHide: function() {},
    onUnload: function() {},
    onPullDownRefresh: function() {},
    onReachBottom: function() {},
    onShareAppMessage: function() {
        return {
            title: "文博大会call你啦~挑战12题，赢现金，奖金直接提现！",
            path: "/pages/index/index",
            imageUrl: "".concat(a.img_url, "share1.png")
        };
    },
    onShareTimeline: function() {
        return {
            title: "文博大会-每天答题参与幸运抽奖，瓜分百万现金！",
            imageUrl: "".concat(a.img_url, "share.png")
        };
    }
});