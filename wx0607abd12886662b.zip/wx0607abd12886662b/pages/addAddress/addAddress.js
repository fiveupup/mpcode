var e = require("../../utils/util.js"), t = require("../../utils/serverList.js"), a = (0, 
e.mapJson)();

Page({
    data: {
        show: !1,
        options: a,
        cascaderValue: "",
        fieldValue: "",
        name: "",
        tel: "",
        address: "",
        checked: !1,
        img_url: e.img_url,
        id: null
    },
    onClick: function() {
        this.setData({
            show: !0
        });
    },
    onClose: function() {
        this.setData({
            show: !1
        });
    },
    onFinish: function(e) {
        var t = e.detail, a = t.selectedOptions, i = t.value, n = a.map(function(e) {
            return e.text || e.name;
        }).join("/");
        this.setData({
            fieldValue: n,
            cascaderValue: i,
            show: !1
        });
    },
    handleInput: function(e) {
        var t = e.currentTarget.dataset.type, a = e.detail.value;
        "name" == t ? this.setData({
            name: a
        }) : "tel" == t ? this.setData({
            tel: a
        }) : "address" == t && this.setData({
            address: a
        });
    },
    onChange: function(e) {
        var t = e.detail;
        this.setData({
            checked: t
        });
    },
    save: function() {
        var a = {};
        (a = this.data.id ? {
            name: this.data.name,
            tel: this.data.tel,
            district: this.data.fieldValue,
            address: this.data.address,
            checked: this.data.checked ? 1 : 0,
            id: this.data.id
        } : {
            name: this.data.name,
            tel: this.data.tel,
            district: this.data.fieldValue,
            address: this.data.address,
            checked: this.data.checked ? 1 : 0,
            id: ""
        }).name && a.tel && a.district && a.address ? (0, e.validateTel)(a.tel) ? (0, t.setAddress)(a).then(function(e) {
            if (e) {
                var t = getCurrentPages(), a = t[t.length - 2];
                wx.navigateBack({
                    success: function() {
                        a.onLoad();
                    }
                });
            } else wx.showToast({
                title: "保存失败",
                icon: "none",
                duration: 2e3
            });
        }) : wx.showToast({
            title: "手机号格式有误",
            icon: "none",
            duration: 2e3
        }) : wx.showToast({
            title: "请将信息填写完整",
            icon: "none",
            duration: 2e3
        });
    },
    onLoad: function(e) {
        if (e.info) {
            wx.setNavigationBarTitle({
                title: "编辑收货地址"
            });
            var t = JSON.parse(e.info);
            this.setData({
                fieldValue: t.district,
                name: t.name,
                tel: t.tel,
                address: t.address,
                checked: "1" == t.checked,
                id: t.id
            });
        } else wx.setNavigationBarTitle({
            title: "新增收货地址"
        });
    },
    onReady: function() {},
    onShow: function() {},
    onHide: function() {},
    onUnload: function() {
        this.setData({
            id: null
        });
    },
    onPullDownRefresh: function() {},
    onReachBottom: function() {},
    onShareAppMessage: function() {
        return {
            title: "文博大会call你啦~挑战12题，赢现金，奖金直接提现！",
            path: "/pages/index/index",
            imageUrl: "".concat(e.img_url, "share1.png")
        };
    },
    onShareTimeline: function() {
        return {
            title: "文博大会-每天答题参与幸运抽奖，瓜分百万现金！",
            imageUrl: "".concat(e.img_url, "share.png")
        };
    }
});