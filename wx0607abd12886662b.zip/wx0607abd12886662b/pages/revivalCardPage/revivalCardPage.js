var e = require("../../@babel/runtime/helpers/defineProperty"), n = require("../../utils/util.js");

getApp();

Page(e({
    data: {
        pop: !1,
        img_url: n.img_url,
        query: "",
        type: "",
        money: "",
        moneyType: ""
    },
    share: function() {},
    cloneShare: function() {
        this.setData({
            pop: !1
        });
    },
    save: function() {
        wx.downloadFile({
            url: "".concat(n.img_url, "revivalCardPage/long-press-save3.jpg?v1"),
            success: function(e) {
                if (console.log(e, "11111"), 200 === e.statusCode) {
                    var n = e.tempFilePath;
                    wx.saveImageToPhotosAlbum({
                        filePath: n,
                        success: function() {
                            wx.showToast({
                                title: "保存成功",
                                icon: "success",
                                duration: 2e3
                            });
                        },
                        fail: function() {
                            wx.showToast({
                                title: "保存失败",
                                icon: "error",
                                duration: 2e3
                            });
                        }
                    });
                }
            },
            fail: function(e) {
                wx.showToast({
                    title: "下载失败",
                    icon: "error",
                    duration: 2e3
                });
            }
        });
    },
    onLoad: function(e) {
        console.log(e), this.setData({
            type: e.type,
            money: e.money,
            moneyType: e.moneyType,
            query: e.fid
        });
    },
    onShareTimeline: function() {
        return {
            title: "文博大会",
            query: "fid=".concat(this.data.query),
            imageUrl: "".concat(n.img_url, "share1.png"),
            success: function(e) {
                console.log("分享朋友圈成功");
            },
            fail: function(e) {
                console.log("分享朋友圈失败");
            }
        };
    },
    onReady: function() {},
    onShow: function() {},
    onHide: function() {},
    onUnload: function() {},
    onPullDownRefresh: function() {},
    onReachBottom: function() {},
    onShareAppMessage: function() {
        console.log(this.data.moneyType, "分享类型");
        var e = "";
        return "lose" == this.data.type ? e = "我在文博大会挑战遭遇知识瓶颈，好兄弟，速来救我！" : "successful" == this.data.type ? e = "1" == this.data.moneyType ? "我在文博大会赢取了".concat(this.data.money, "元，仅需12题，你也快来赢吧！") : "我在文博大会赢取了".concat(this.data.money, "积分，仅需12题，你也快来赢吧！") : "index" == this.data.type && (e = "文博大会call你啦~挑战12题，赢现金，奖金直接提现！"), 
        {
            title: e,
            path: "/pages/index/index?fid=".concat(this.data.query),
            imageUrl: "".concat(n.img_url, "share1.png")
        };
    }
}, "onShareTimeline", function() {
    return {
        title: "文博大会-每天答题参与幸运抽奖，瓜分百万现金！",
        imageUrl: "".concat(n.img_url, "share.png")
    };
}));