require("@babel/runtime/helpers/Arrayincludes.js");

getApp();

var t = require("42D23E741787E8AF24B45673136A8927.js");

require("380689321787E8AF5E60E135F37A8927.js").checkIsInBlack;

module.exports = Behavior({
    behaviors: [ t ],
    data: {
        style: ""
    },
    maskItem: {},
    lifetimes: {
        attached: function() {
            this.$bus.event.on("page:zpInfoLoaded", this.resetZp.bind(this));
        }
    },
    methods: {
        resetZp: function() {
            console.log("resetZp"), this.state = "stopped", this.lastTurn = 0, this.result = "", 
            this.setData({
                style: "",
                maskItem: {
                    show: !1
                }
            });
        },
        start: function() {
            var t = this;
            if ("running" !== this.$bus.get("state")) {
                this.$bus.set("state", "running"), this.setData({
                    "maskItem.show": !1
                });
                var e = this.$bus.store.get("allWeightItems"), s = this.$bus.store.get("realItems"), r = Math.floor(Math.random() * e.length), a = e[r];
                if (!this.$bus.get("settings").repeat) {
                    var i = wx.getStorageSync("blackItems_" + this.$bus.get("zpInfo").id) || [], n = e.filter(function(e) {
                        return !i.includes(t.$bus.get("realItems")[e].text);
                    });
                    console.log("filteredItems", n), n.length > 0 ? a = n[r = Math.floor(Math.random() * n.length)] : this.$bus.event.call("jindu:clear");
                }
                this.currentTurn = 3 + (s[a].startDeg + s[a].deg / 2) / 360 + (1 - this.lastTurn % 1), 
                this.result = s[a];
                var u = 1e3 * this.currentTurn, o = "transform: rotate(".concat(this.lastTurn + this.currentTurn, "turn);transition: all ").concat(u, "ms cubic-bezier(0, 0.55, 0.45, 1);");
                this.setData({
                    style: o
                });
                var h = Date.now();
                !function r() {
                    var a = Date.now() - h;
                    if (!(a >= u)) {
                        var i, n = 360 * (i = a / u, Math.sqrt(1 - Math.pow(i - 1, 2)) * t.currentTurn) + t.lastTurn % 1 * 360;
                        n %= 360, n = (n -= 1 / e.length * 360 / 2) < 0 ? n + 360 : n;
                        var o = Math.ceil(n / 360 * e.length) % e.length, l = s[e[o]];
                        t.$bus.emit("zhuanpan:step", l), setTimeout(function() {
                            r();
                        }, 100);
                    }
                }();
            } else wx.vibrateShort();
        },
        shotResult: function() {
            var t = this.$bus.get("result");
            console.log(t), this.setData({
                maskItem: {
                    deg: 360 - t.deg,
                    startDeg: t.deg / 2,
                    endDeg: 360 - t.deg / 2,
                    text: "mask",
                    type: "mask",
                    show: !0,
                    color: "rgba(0,0,0,0.5)"
                }
            });
        },
        onZpStopped: function(t) {
            this.lastTurn += this.currentTurn, this.$bus.set("state", "stopped"), this.$bus.set("result", this.result), 
            this.shotResult(), this.$bus.emit("zhuanpan:stop", this.result), this.$bus.event.call("jindu:addToBlackList", this.result.text), 
            this.addRecord();
        },
        addRecord: function() {
            var t = this.$bus.store.get("zpInfo"), e = this.$bus.get("result"), s = wx.getStorageSync("records_" + t.id) || [];
            s.length >= 100 && s.pop(), s.unshift(e.text), wx.setStorageSync("records_" + t.id, s);
        }
    }
});