var e = require("../../../@babel/runtime/helpers/toConsumableArray"), t = require("../../../@babel/runtime/helpers/defineProperty");

require("../../../@babel/runtime/helpers/Arrayincludes"), Page({
    data: {
        id: "",
        blackList: [],
        leftList: [],
        showNum: !1,
        records: []
    },
    onLoad: function(e) {
        var t = e.id;
        this.data.id = t;
        var a = JSON.parse(decodeURIComponent(e.allList));
        if (e.showNum) {
            this.setData({
                showNum: !0
            }), console.log(t, a);
            var r = wx.getStorageSync("blackItems_" + t) || [], s = a.filter(function(e) {
                return !r.includes(e);
            });
            this.setData({
                blackList: r.reverse(),
                leftList: s.reverse()
            });
        }
        var i = wx.getStorageSync("records_" + t) || [];
        this.setData({
            records: i
        });
    },
    delItem: function(a) {
        var r = a.currentTarget.dataset, s = r.type, i = r.index;
        console.log(s, i);
        var n = this.data[s];
        (n.splice(i, 1), this.setData(t({}, s, n)), "blackList" === s) && (wx.setStorageSync("blackItems_" + this.data.id, e(this.data.blackList).reverse()), 
        this.getOpenerEventChannel().emit("updateBlackItems"));
        "records" === s && wx.setStorageSync("records_" + this.data.id, this.data.records);
    },
    clearList: function(e) {
        var a = e.currentTarget.dataset.type;
        (this.setData(t({}, a, [])), "blackList" === a) && (wx.setStorageSync("blackItems_" + this.data.id, []), 
        this.getOpenerEventChannel().emit("updateBlackItems"));
        "records" === a && wx.setStorageSync("records_" + this.data.id, []);
    },
    onReady: function() {},
    onShow: function() {},
    onHide: function() {},
    onUnload: function() {},
    onPullDownRefresh: function() {},
    onReachBottom: function() {}
});