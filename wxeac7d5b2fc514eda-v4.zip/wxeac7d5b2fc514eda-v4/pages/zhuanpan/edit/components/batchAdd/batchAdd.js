Component({
    behaviors: [ wx.Bus ],
    properties: {
        show: {
            type: Boolean
        }
    },
    data: {
        line: 0,
        rows: [],
        text: ""
    },
    methods: {
        textChange: function(t) {
            var e = t.detail.value.split("\n"), s = e.length;
            "" === e[e.length - 1] && (s -= 1, e.pop()), this.setData({
                line: s,
                rows: e
            });
        },
        batchAdd: function(t) {
            var e = this.data.rows;
            this.triggerEvent("batchAdd", {
                rows: e
            }), this.setData({
                show: !1,
                text: ""
            });
        },
        cancel: function() {
            this.setData({
                show: !1
            });
        }
    },
    lifetimes: {
        attached: function() {
            var t = this;
            this.$bus.event.export("batchAdd:show", function(e) {
                t.setData({
                    show: !0
                });
            });
        }
    }
});