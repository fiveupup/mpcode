require("../../../../../@babel/runtime/helpers/Objectvalues");

var e = require("../../../../../42D23E741787E8AF24B45673136A8927.js"), o = require("../../../../../A08FCA871787E8AFC6E9A280C6D88927.js");

Component({
    behaviors: [ e ],
    properties: {},
    data: {
        showColors: !1
    },
    methods: {
        closeSetting: function() {
            this.setData({
                showColors: !1
            });
        },
        initColorsMap: function() {
            for (var e = {}, t = 0; t < o.length; t++) e[o[t]] = {
                color: o[t],
                selected: !1,
                checked: !1,
                index: t
            };
            this.setData({
                colors_map: e
            }), this.$bus.store.set("colors_map", e);
        },
        selectColor: function(e) {
            var o = e.currentTarget.dataset.color;
            this.setData({
                showColors: !1
            }), this.$bus.event.call("page:setColor", {
                color: o,
                index: this.$bus.store.get("current_zp_item_index")
            });
        }
    },
    lifetimes: {
        attached: function() {
            var e = this;
            this.$bus.event.export("colors:showColors", function(o) {
                var t = o.index, s = o.selectedColor;
                e.$bus.store.set("current_zp_item_index", t), Object.values(e.data.colors_map).forEach(function(e) {
                    e.checked = !1, e.selected = !1;
                });
                var r = s[t];
                e.data.colors_map[r].selected = !0, s.forEach(function(o) {
                    e.data.colors_map[o].checked = !0;
                }), e.setData({
                    showColors: !0,
                    colors_map: e.data.colors_map
                });
            }), this.initColorsMap();
        }
    }
});