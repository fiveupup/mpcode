var t, e = require("../../../@babel/runtime/helpers/interopRequireDefault"), a = require("../../../@babel/runtime/helpers/defineProperty"), i = require("../../../@babel/runtime/helpers/createForOfIteratorHelper"), n = e(require("../../../@babel/runtime/regenerator")), s = require("../../../@babel/runtime/helpers/asyncToGenerator"), r = require("../../../63A178451787E8AF05C7104268E88927.js"), o = (r.all_zps, 
r.empty_zp), l = require("../../../A08FCA871787E8AFC6E9A280C6D88927.js"), u = require("../../../42D23E741787E8AF24B45673136A8927.js"), c = require("../../../42931B651787E8AF24F57362AE8A8927.js"), d = require("../../../196A17A11787E8AF7F0C7FA606BA8927.js").draws, p = getApp();

Page({
    behaviors: [ u, c ],
    data: {
        zp_info: {},
        focus: !1
    },
    onLoad: (t = s(n.default.mark(function t(e) {
        var a;
        return n.default.wrap(function(t) {
            for (;;) switch (t.prev = t.next) {
              case 0:
                if ("add" !== e.type && p.globalData.current_edit_zp) {
                    t.next = 5;
                    break;
                }
                return wx.setNavigationBarTitle({
                    title: "创建转盘"
                }), this.setData({
                    zp_info: o
                }), this.createType = "add", t.abrupt("return");

              case 5:
                a = JSON.parse(JSON.stringify(p.globalData.current_edit_zp)), p.globalData.current_edit_zp = null, 
                "hot" === a.from ? (wx.setNavigationBarTitle({
                    title: "创建转盘"
                }), this.createType = "add", this.setData({
                    zp_info: a
                })) : this.loadZpFromServer(a.id00), this.editStatus = 0;

              case 9:
              case "end":
                return t.stop();
            }
        }, t, this);
    })), function(e) {
        return t.apply(this, arguments);
    }),
    loadZpFromServer: function(t) {
        var e = this;
        return s(n.default.mark(function a() {
            var i, s;
            return n.default.wrap(function(a) {
                for (;;) switch (a.prev = a.next) {
                  case 0:
                    return a.next = 2, d.getDraw(t);

                  case 2:
                    0 === (i = a.sent).code && ((s = i.data).openid !== p.globalData.openid && wx.setNavigationBarTitle({
                        title: "创建转盘"
                    }), e.setData({
                        zp_info: s
                    }));

                  case 4:
                  case "end":
                    return a.stop();
                }
            }, a);
        }))();
    },
    delItem: function(t) {
        if (this.data.zp_info.items.length < 3) wx.showToast({
            title: "至少保留两个选项呀",
            icon: "none"
        }); else {
            var e = t.currentTarget.dataset.index, a = this.data.zp_info;
            a.items.splice(e, 1), this.setData({
                zp_info: a,
                focus: !1
            });
        }
    },
    showBatchAdd: function() {
        this.$bus.event.call("batchAdd:show", !0);
    },
    onBatchAdd: function(t) {
        var e = t.detail.rows;
        if (e && 0 !== e.length) {
            console.log("接收到批量添加事件", t.detail);
            var n, s = this.data.zp_info, r = i(e);
            try {
                for (r.s(); !(n = r.n()).done; ) {
                    var o = n.value, u = l[0];
                    if (s.items.length > 0) {
                        var c = s.items[s.items.length - 1], d = this.$bus.store.get("colors_map")[c.color].index + 1;
                        u = d < l.length ? l[d] : l[0];
                    }
                    this.data.zp_info.items.push({
                        text: o,
                        color: u,
                        weight: 1
                    });
                }
            } catch (t) {
                r.e(t);
            } finally {
                r.f();
            }
            this.setData(a({}, "zp_info.items", this.data.zp_info.items));
        }
    },
    addNewItem: function() {
        var t, e = l[0], i = this.data.zp_info;
        if (i.items.length > 0) {
            var n = i.items[i.items.length - 1], s = this.$bus.store.get("colors_map")[n.color].index + 1;
            e = s < l.length ? l[s] : l[0];
        }
        this.data.zp_info.items.push({
            text: "",
            color: e,
            weight: 1
        }), this.setData((a(t = {}, "zp_info.items", this.data.zp_info.items), a(t, "focus", !0), 
        t));
    },
    onInput: function(t) {
        var e = t.currentTarget.dataset, i = e.index, n = e.type, s = t.detail.value;
        "weight" === n && (s = parseInt(s)), this.setData(a({}, "zp_info.items[".concat(i, "].").concat(n), s)), 
        this.editStatus = 1;
    },
    onBlur: function(t) {
        var e, i = t.currentTarget.dataset, n = i.index, s = i.type;
        t.detail.value || this.setData((a(e = {}, "zp_info.items[".concat(n, "].").concat(s), 1), 
        a(e, "focus", !1), e));
    },
    onChangeTitle: function(t) {
        this.setData(a({}, "zp_info.title", t.detail.value)), this.editStatus = 1;
    },
    onChangeSetting: function(t) {},
    onSelColor: function(t) {
        var e = t.currentTarget.dataset.index, a = this.data.zp_info.items.map(function(t) {
            return t.color;
        });
        this.$bus.event.call("colors:showColors", {
            index: e,
            selectedColor: a
        });
    },
    saveZp: function() {
        var t = this;
        return s(n.default.mark(function e() {
            var a;
            return n.default.wrap(function(e) {
                for (;;) switch (e.prev = e.next) {
                  case 0:
                    if (console.log("保存转盘"), !(t.data.zp_info.items.length < 2)) {
                        e.next = 4;
                        break;
                    }
                    return wx.showToast({
                        title: "至少两个选项才能保存",
                        icon: "none"
                    }), e.abrupt("return");

                  case 4:
                    t.$bus.event.call("loading:show", !0), t.$bus.event.call("loading:setText", {
                        text: "保存中...",
                        status: 0
                    });
                    try {
                        p.loadMini();
                    } catch (t) {}
                    return e.prev = 7, e.next = 10, d.updateDraw(t.data.zp_info);

                  case 10:
                    a = e.sent, console.log(a), 0 === a.code ? (t.editStatus = 2, t.$bus.event.call("loading:setText", {
                        text: "保存成功",
                        status: 1
                    }), "add" === t.createType && (a.data.isAdd = !0), p.globalData.current_edit_zp = a.data, 
                    p.globalData.zp_list_chacheId = Date.now()) : t.$bus.event.call("loading:setText", {
                        text: "保存失败",
                        status: 2
                    }), e.next = 18;
                    break;

                  case 15:
                    e.prev = 15, e.t0 = e.catch(7), t.$bus.event.call("loading:setText", {
                        text: "保存出错了，请重试一次吧",
                        status: 2
                    });

                  case 18:
                  case "end":
                    return e.stop();
                }
            }, e, null, [ [ 7, 15 ] ]);
        }))();
    },
    shuffleZp: function() {
        for (var t = this.data.zp_info, e = t.items, a = e.length - 1; a > 0; a--) {
            var i = Math.floor(Math.random() * (a + 1)), n = [ e[i], e[a] ];
            e[a] = n[0], e[i] = n[1];
        }
        t.items = e, this.setData({
            zp_info: t
        });
    },
    copyZp: function() {
        var t = this, e = this.data.zp_info, a = JSON.parse(JSON.stringify(e));
        a.id00 = "copy", this.setData({
            zp_info: a
        }, function() {
            t.saveZp();
        });
    },
    showMore: function() {
        var t = this;
        wx.showActionSheet({
            itemList: [ "打乱顺序", "复制所有选项到粘贴板" ],
            success: function(e) {
                if (0 === e.tapIndex) t.shuffleZp(); else if (1 === e.tapIndex) {
                    var a = t.data.zp_info.items.map(function(t) {
                        return t.text;
                    }).join("\n");
                    wx.setClipboardData({
                        data: a
                    }), p.loadMini();
                }
            }
        });
    },
    onUnload: function() {
        var t = this.data.zp_info;
        1 === this.editStatus && t.items.length > 0 && (wx.setStorageSync("draft_zp", t), 
        wx.setStorageSync("draft_zp_ts", new Date().getTime()));
    }
});