var e = require("../../../@babel/runtime/helpers/interopRequireDefault")(require("../../../@babel/runtime/regenerator")), t = require("../../../@babel/runtime/helpers/asyncToGenerator"), a = getApp(), r = require("../../../42D23E741787E8AF24B45673136A8927.js"), n = require("../../../63A178451787E8AF05C7104268E88927.js"), i = require("../../../196A17A11787E8AF7F0C7FA606BA8927.js").draws;

Page({
    behaviors: [ r ],
    data: {
        showResetZp: !1
    },
    onShareAppMessage: function(e) {
        var t;
        console.log("onShareAppMessage", e);
        var r = this.$bus.store.get("zpInfo");
        return "result" === (null === (t = e.target) || void 0 === t ? void 0 : t.dataset.detail) ? {
            title: this.$bus.get("result").text,
            path: "/pages/zhuanpan/index/index?type=share&id=".concat(r.id00 || r.id, "&top_c=分享结果&sub_c=").concat(a.globalData.openid)
        } : {
            title: r.title,
            path: "/pages/zhuanpan/index/index?type=share&id=".concat(r.id00 || r.id, "&top_c=分享转盘&sub_c=").concat(a.globalData.openid)
        };
    },
    tapMore: function() {
        this.checkZpIsReady() && this.$bus.event.call("more:showMore");
    },
    onShareTimeline: function() {
        var e = this.$bus.store.get("zpInfo");
        return {
            title: e.title,
            query: "type=share&id=".concat(e.id00 || e.id)
        };
    },
    store: function() {
        return {
            state: "stopped",
            zpInfo: {
                items: []
            },
            result: "??"
        };
    },
    onLoad: function(r) {
        var i = this;
        return t(e.default.mark(function t() {
            var s, o, u;
            return e.default.wrap(function(e) {
                for (;;) switch (e.prev = e.next) {
                  case 0:
                    if ("share" !== r.type) {
                        e.next = 14;
                        break;
                    }
                    if (!(s = r.id).startsWith("template_")) {
                        e.next = 12;
                        break;
                    }
                    return console.log(s), o = n.all_zps[s], console.log(n), i.initZp(o), e.next = 9, 
                    a.initLogin();

                  case 9:
                    return e.abrupt("return");

                  case 12:
                    return i.loadZpFromServer(s), e.abrupt("return");

                  case 14:
                    if (!(u = wx.getStorageSync("lastZp"))) {
                        e.next = 20;
                        break;
                    }
                    i.initZp(u), i.loadZpFromServer(u.id00), e.next = 24;
                    break;

                  case 20:
                    return i.initZp(n.default), e.next = 23, a.initLogin();

                  case 23:
                    wx.navigateTo({
                        url: "../zp_list/zp_list"
                    });

                  case 24:
                  case "end":
                    return e.stop();
                }
            }, t);
        }))();
    },
    initZp: function(e) {
        this.$bus.store.set("zpInfo", e), this.$bus.emit("page:zpInfoLoaded"), this.setData({
            title: e.title
        }), a.globalData.main_zp = e, wx.setStorageSync("lastZp", e);
    },
    navigateTo: function(e) {
        if (this.checkZpIsReady()) switch (e.currentTarget.dataset.target) {
          case "zp_list":
            wx.switchTab({
                url: "/pages/zhuanpan/zp_list/zp_list"
            });
            break;

          case "edit":
            a.globalData.current_edit_zp = this.$bus.store.get("zpInfo"), wx.navigateTo({
                url: "../edit/edit"
            });
            break;

          case "add":
            wx.navigateTo({
                url: "../edit/edit?type=add"
            });
        }
    },
    pageCallback: function(a) {
        var r = this;
        return t(e.default.mark(function t() {
            return e.default.wrap(function(e) {
                for (;;) switch (e.prev = e.next) {
                  case 0:
                    "selectZp" === a.type && ("hot" === a.data.from ? r.initZp(a.data) : r.loadZpFromServer(a.data.id00));

                  case 1:
                  case "end":
                    return e.stop();
                }
            }, t);
        }))();
    },
    loadZpFromServer: function(r) {
        var n = this;
        return t(e.default.mark(function t() {
            var s;
            return e.default.wrap(function(e) {
                for (;;) switch (e.prev = e.next) {
                  case 0:
                    return e.next = 2, a.initLogin();

                  case 2:
                    return e.next = 4, i.getDraw(r);

                  case 4:
                    0 === (s = e.sent).code && n.initZp(s.data);

                  case 6:
                  case "end":
                    return e.stop();
                }
            }, t);
        }))();
    },
    checkZpIsReady: function() {
        return "running" !== this.$bus.store.get("state");
    },
    onShow: function() {
        console.log("onShow", a.globalData.__switch_selectzp), a.globalData.current_edit_zp && (this.initZp(a.globalData.current_edit_zp), 
        a.globalData.current_edit_zp = null), a.globalData.__switch_selectzp && (this.pageCallback(a.globalData.__switch_selectzp), 
        a.globalData.__switch_selectzp = null);
    },
    onReady: function() {}
});