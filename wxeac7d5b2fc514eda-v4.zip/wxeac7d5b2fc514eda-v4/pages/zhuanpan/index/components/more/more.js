var e = require("../../../../../@babel/runtime/helpers/interopRequireDefault")(require("../../../../../@babel/runtime/regenerator")), t = require("../../../../../@babel/runtime/helpers/defineProperty"), s = require("../../../../../@babel/runtime/helpers/asyncToGenerator"), r = require("../../../../../42D23E741787E8AF24B45673136A8927.js"), a = require("../../../../../196A17A11787E8AF7F0C7FA606BA8927.js").getTTS;

Component({
    behaviors: [ r ],
    properties: {},
    data: {
        showMore: !1,
        settings: {
            vibrate: !0,
            sound: !0,
            records: !0,
            speaker: "1001",
            repeat: !1
        },
        speakers: [ {
            text: "不需要语音播报",
            value: "none"
        }, {
            text: "情感女声-智瑜",
            value: "1001"
        }, {
            text: "知性女声-智娜",
            value: "1007"
        }, {
            text: "通用女声-智莉",
            value: "1005"
        }, {
            text: "通用男声-智华",
            value: "1"
        }, {
            text: "情感男声-智靖",
            value: "1018"
        }, {
            text: "情感男声-智云",
            value: "1004"
        } ]
    },
    methods: {
        showMore: function() {
            this.setData({
                showMore: !0
            });
        },
        hideMore: function() {
            this.setData({
                showMore: !1
            });
        },
        showShare: function() {
            this.$bus.event.call("share:showShare");
        },
        settingsChange: function(r) {
            var i = this;
            return s(e.default.mark(function s() {
                var n, o, u;
                return e.default.wrap(function(e) {
                    for (;;) switch (e.prev = e.next) {
                      case 0:
                        if (n = r.currentTarget.dataset.type, o = r.detail, i.setData(t({}, "settings.".concat(n), o)), 
                        i.updateSettings(), "speaker" !== n) {
                            e.next = 11;
                            break;
                        }
                        if ("none" !== o) {
                            e.next = 7;
                            break;
                        }
                        return e.abrupt("return");

                      case 7:
                        return e.next = 9, a("万能小转盘真棒", o);

                      case 9:
                        0 === (u = e.sent).code && (i.audioCtx.src = u.data, i.audioCtx.play());

                      case 11:
                      case "end":
                        return e.stop();
                    }
                }, s);
            }))();
        },
        updateSettings: function() {
            this.$bus.store.set("settings", this.data.settings), wx.setStorageSync("settings", this.data.settings), 
            this.$bus.emit("settings:change", this.data.settings);
        }
    },
    lifetimes: {
        attached: function() {
            var e = this;
            this.$bus.store.get("settings") || this.$bus.store.set("settings", wx.getStorageSync("settings") || this.data.settings), 
            this.$bus.event.export("more:showMore", function() {
                e.showMore();
                var t = wx.getStorageSync("settings") || e.data.settings;
                e.setData({
                    settings: t
                });
            }), this.$bus.event.export("more:hiddenMore", function() {
                e.hideMore();
            }), this.audioCtx = wx.createInnerAudioContext();
        },
        detached: function() {
            this.audioCtx && this.audioCtx.destroy();
        }
    }
});