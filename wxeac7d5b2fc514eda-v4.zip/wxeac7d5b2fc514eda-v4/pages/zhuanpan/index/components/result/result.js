var t = require("../../../../../@babel/runtime/helpers/interopRequireDefault")(require("../../../../../@babel/runtime/regenerator")), e = require("../../../../../@babel/runtime/helpers/asyncToGenerator"), s = require("../../../../../42D23E741787E8AF24B45673136A8927.js"), a = require("../../../../../196A17A11787E8AF7F0C7FA606BA8927.js").getTTS;

Component({
    behaviors: [ s ],
    properties: {},
    data: {
        result: "??",
        showShare: !1
    },
    methods: {
        onTapResult: function() {
            var t = this;
            this.data.result && this.data.showShare && wx.showActionSheet({
                itemList: [ "复制结果" ],
                success: function(e) {
                    0 === e.tapIndex && t.toCopy();
                }
            });
        },
        toCopy: function() {
            this.data.result && this.data.showShare && wx.setClipboardData({
                data: this.data.result,
                success: function() {
                    wx.showToast({
                        title: "转盘结果复制成功",
                        icon: "none"
                    });
                }
            });
        }
    },
    lifetimes: {
        attached: function() {
            var s = this;
            this.$bus.on("zhuanpan:step", function(t) {
                t.text !== s.data.result && (s.$bus.get("settings").vibrate && wx.vibrateShort(), 
                s.setData({
                    result: t.text,
                    showShare: !1
                }));
            }), this.$bus.on("zhuanpan:stop", function() {
                var r = e(t.default.mark(function e(r) {
                    var n;
                    return t.default.wrap(function(t) {
                        for (;;) switch (t.prev = t.next) {
                          case 0:
                            if (s.$bus.get("settings").vibrate && wx.vibrateShort(), !r.text || !s.$bus.store.get("settings").speaker || "none" === s.$bus.store.get("settings").speaker) {
                                t.next = 6;
                                break;
                            }
                            return t.next = 4, a(r.text, s.$bus.store.get("settings").speaker);

                          case 4:
                            0 === (n = t.sent).code && (s.audioCtx.src = n.data, s.audioCtx.play());

                          case 6:
                            s.setData({
                                result: r.text,
                                showShare: !0
                            });

                          case 7:
                          case "end":
                            return t.stop();
                        }
                    }, e);
                }));
                return function(t) {
                    return r.apply(this, arguments);
                };
            }()), this.$bus.on("page:zpInfoLoaded", function() {
                s.setData({
                    result: "??",
                    showShare: !1
                });
            }), this.audioCtx = wx.createInnerAudioContext();
        },
        detached: function() {
            this.audioCtx && this.audioCtx.destroy();
        }
    }
});