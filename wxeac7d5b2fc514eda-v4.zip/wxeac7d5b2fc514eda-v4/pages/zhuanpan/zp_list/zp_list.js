var t, e = require("../../../@babel/runtime/helpers/interopRequireDefault"), a = require("../../../@babel/runtime/helpers/objectSpread2"), r = e(require("../../../@babel/runtime/regenerator")), n = require("../../../@babel/runtime/helpers/asyncToGenerator"), s = require("../../../63A178451787E8AF05C7104268E88927.js"), i = require("../../../42D23E741787E8AF24B45673136A8927.js"), o = require("../../../196A17A11787E8AF7F0C7FA606BA8927.js").draws, c = getApp();

Page({
    behaviors: [ i ],
    data: {
        loaded: !1,
        list1: [],
        list2: [],
        list3: [],
        currentTab: 1,
        cacheId: 111
    },
    onLoad: (t = n(r.default.mark(function t(e) {
        var a;
        return r.default.wrap(function(t) {
            for (;;) switch (t.prev = t.next) {
              case 0:
                a = s.hot, this.loadMyZps(), this.setData({
                    list2: a
                });

              case 3:
              case "end":
                return t.stop();
            }
        }, t, this);
    })), function(e) {
        return t.apply(this, arguments);
    }),
    loadMyZps: function() {
        var t = this;
        return n(r.default.mark(function e() {
            var n, s;
            return r.default.wrap(function(e) {
                for (;;) switch (e.prev = e.next) {
                  case 0:
                    return e.next = 2, o.getDraws();

                  case 2:
                    if (0 !== (n = e.sent).code) {
                        e.next = 10;
                        break;
                    }
                    return (s = n.data.map(function(t) {
                        return a(a({}, t), {}, {
                            from: "mine"
                        });
                    })).length > 0 ? t.setData({
                        list3: s
                    }) : 111 === t.data.cacheId && t.setData({
                        currentTab: 0
                    }), t.setData({
                        loaded: !0
                    }), e.abrupt("return", s);

                  case 10:
                    wx.showToast({
                        title: "获取我的转盘失败",
                        icon: "none"
                    });

                  case 11:
                  case "end":
                    return e.stop();
                }
            }, e);
        }))();
    },
    selectZp: function(t) {
        var e = t.currentTarget.dataset, a = e.index, r = e.type;
        console.log("selectZp", a, r);
        var n = this.data.list3[a];
        "hot" === r && (n = this.data.list2[a], console.log("hot转盘", n, a, this.data.list2)), 
        n && (console.log("selectZp", n), c.globalData.__switch_selectzp = {
            type: "selectZp",
            data: JSON.parse(JSON.stringify(n))
        }, wx.switchTab({
            url: "/pages/zhuanpan/index/index"
        }), c.loadMini());
    },
    showMoreSheet: function(t) {
        var e = this;
        return n(r.default.mark(function a() {
            var s, i, o, c;
            return r.default.wrap(function(a) {
                for (;;) switch (a.prev = a.next) {
                  case 0:
                    s = t.currentTarget.dataset.index, i = {
                        DELETE: "🗑️  删除",
                        EDIT: "📝  编辑",
                        COPY: "📋  复制"
                    }, o = e.data.list3[s], c = [ i.EDIT, i.COPY, i.DELETE ], wx.showActionSheet({
                        itemList: c,
                        success: function() {
                            var t = n(r.default.mark(function t(a) {
                                return r.default.wrap(function(t) {
                                    for (;;) switch (t.prev = t.next) {
                                      case 0:
                                        console.log(a), t.t0 = c[a.tapIndex], t.next = t.t0 === i.EDIT ? 4 : t.t0 === i.COPY ? 6 : t.t0 === i.DELETE ? 8 : 10;
                                        break;

                                      case 4:
                                        return e.editItem(o), t.abrupt("break", 10);

                                      case 6:
                                        return e.copyZp(o), t.abrupt("break", 10);

                                      case 8:
                                        return e.delZp(o), t.abrupt("break", 10);

                                      case 10:
                                      case "end":
                                        return t.stop();
                                    }
                                }, t);
                            }));
                            return function(e) {
                                return t.apply(this, arguments);
                            };
                        }()
                    });

                  case 5:
                  case "end":
                    return a.stop();
                }
            }, a);
        }))();
    },
    editItem: function(t) {
        c.globalData.current_edit_zp = t, wx.navigateTo({
            url: "/pages/zhuanpan/edit/edit"
        });
    },
    delZp: function(t) {
        var e = this;
        return n(r.default.mark(function a() {
            return r.default.wrap(function(a) {
                for (;;) switch (a.prev = a.next) {
                  case 0:
                    return a.next = 2, o.deleteDraw({
                        id: t.id00
                    });

                  case 2:
                    0 === a.sent.code && e.loadMyZps();

                  case 4:
                  case "end":
                    return a.stop();
                }
            }, a);
        }))();
    },
    handleCopyZp: function(t) {
        var e = this;
        return n(r.default.mark(function a() {
            var n, s;
            return r.default.wrap(function(a) {
                for (;;) switch (a.prev = a.next) {
                  case 0:
                    n = t.currentTarget.dataset.index, s = e.data.list2[n], e.copyZp(s);

                  case 3:
                  case "end":
                    return a.stop();
                }
            }, a);
        }))();
    },
    copyZp: function(t) {
        var e = this;
        return n(r.default.mark(function n() {
            var s;
            return r.default.wrap(function(r) {
                for (;;) switch (r.prev = r.next) {
                  case 0:
                    return wx.showLoading({
                        title: "保存中..."
                    }), r.next = 3, o.updateDraw(t);

                  case 3:
                    0 === (s = r.sent).code ? (wx.hideLoading(), e.data.list3.unshift(a({}, s.data)), 
                    e.setData({
                        list3: e.data.list3
                    }), wx.showModal({
                        title: "保存成功",
                        content: "已保存到【我的转盘】",
                        confirmText: "去查看",
                        success: function(t) {
                            t.confirm && (e.setData({
                                currentTab: 0
                            }), e.setData({
                                currentTab: 1
                            }));
                        }
                    })) : wx.showToast({
                        title: "保存失败，请重试",
                        icon: "none"
                    });

                  case 5:
                  case "end":
                    return r.stop();
                }
            }, n);
        }))();
    },
    toAdd: function() {
        wx.navigateTo({
            url: "../edit/edit?type=add"
        });
    },
    onShow: function() {
        c.globalData.zp_list_chacheId && c.globalData.zp_list_chacheId !== this.data.cacheId && (this.loadMyZps(), 
        c.globalData.zp_list_chacheId = this.data.cacheId);
    },
    onShareAppMessage: function(t) {
        if ("button" === t.from) {
            console.log(t);
            var e = t.target.dataset.detail;
            return console.log(e), {
                title: e.title,
                path: "/pages/zhuanpan/index/index?type=share&id=".concat(e.id00 || e.id, "&top_c=列表分享&sub_c=").concat(c.globalData.openid),
                imageUrl: "http://pan.jialidun.vip/zp/wnxzp.png",
                success: function(t) {
                    wx.showToast({
                        title: "分享成功～"
                    });
                }
            };
        }
    }
});