Page({
    data: {
        src: ""
    },
    onLoad: function(n) {
        var o = decodeURIComponent(n.url);
        this.setData({
            src: o
        });
    },
    onReady: function() {},
    onShow: function() {},
    onHide: function() {},
    onUnload: function() {},
    onPullDownRefresh: function() {},
    onReachBottom: function() {},
    onShareAppMessage: function() {}
});