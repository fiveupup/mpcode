var e = require("../../@babel/runtime/helpers/interopRequireDefault")(require("../../@babel/runtime/regenerator")), t = require("../../@babel/runtime/helpers/asyncToGenerator"), n = require("../../196A17A11787E8AF7F0C7FA606BA8927.js"), r = n.wxPay, a = n.getUser;

getApp();

Page({
    data: {
        userInfo: {}
    },
    pay: function(n) {
        var a = this;
        return t(e.default.mark(function u() {
            var o, s, c, i, f;
            return e.default.wrap(function(u) {
                for (;;) switch (u.prev = u.next) {
                  case 0:
                    return o = n.currentTarget.dataset, s = o.amount, c = o.desc, u.next = 3, r.createOrder({
                        amount: s,
                        description: c
                    });

                  case 3:
                    0 === (i = u.sent).code && (f = i.data, wx.requestPayment({
                        timeStamp: f.timeStamp,
                        nonceStr: f.nonceStr,
                        package: f.package,
                        signType: "RSA",
                        paySign: f.paySign,
                        success: function() {
                            var n = t(e.default.mark(function t(n) {
                                return e.default.wrap(function(e) {
                                    for (;;) switch (e.prev = e.next) {
                                      case 0:
                                        return wx.showModal({
                                            title: "支付成功，感谢赞助",
                                            content: "祝你心想事成、寿与天齐、万事如意、幸福平安、财源广进，步步高升，恭喜发财，吉祥如意，吉星高照"
                                        }), e.next = 3, a.refresh();

                                      case 3:
                                      case "end":
                                        return e.stop();
                                    }
                                }, t);
                            }));
                            return function(e) {
                                return n.apply(this, arguments);
                            };
                        }()
                    }));

                  case 5:
                  case "end":
                    return u.stop();
                }
            }, u);
        }))();
    },
    refresh: function() {
        var n = this;
        return t(e.default.mark(function t() {
            var r;
            return e.default.wrap(function(e) {
                for (;;) switch (e.prev = e.next) {
                  case 0:
                    return e.next = 2, a();

                  case 2:
                    if (0 === (r = e.sent).code) {
                        e.next = 5;
                        break;
                    }
                    return e.abrupt("return");

                  case 5:
                    r.data.vip_expired_at, wx.setStorageSync("userInfo", r.data), n.setData({
                        userInfo: wx.getStorageSync("userInfo")
                    });

                  case 8:
                  case "end":
                    return e.stop();
                }
            }, t);
        }))();
    },
    onLoad: function(e) {
        this.setData({
            userInfo: wx.getStorageSync("userInfo")
        });
    },
    onReady: function() {},
    onShow: function() {},
    onHide: function() {},
    onUnload: function() {},
    onPullDownRefresh: function() {},
    onReachBottom: function() {},
    onShareAppMessage: function() {}
});