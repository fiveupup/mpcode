var e = require("@babel/runtime/helpers/defineProperty.js"), t = require("42D23E741787E8AF24B45673136A8927.js");

module.exports = Behavior({
    behaviors: [ t ],
    properties: {},
    lifetimes: {
        attached: function() {
            var t = this;
            this.$bus.event.export("page:setColor", function(i) {
                var r = i.color, o = i.index;
                t.setData(e({}, "zp_info.items[".concat(o, "].color"), r));
            }), this.$bus.on("loading:hide", function(e) {
                1 === e.status && wx.navigateBack();
            });
        }
    }
});