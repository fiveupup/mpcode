Object.defineProperty(exports, "__esModule", {
    value: !0
});

var t = require("../../../4C48BB651787E8AF2A2ED362CF198927.js"), e = require("../../../839823711787E8AFE5FE4B762F298927.js"), n = require("../../../0179D3621787E8AF671FBB65C1498927.js"), i = [];

(0, t.VantComponent)({
    field: !0,
    relation: (0, e.useChildren)("dropdown-item", function() {
        this.updateItemListData();
    }),
    props: {
        activeColor: {
            type: String,
            observer: "updateChildrenData"
        },
        overlay: {
            type: Boolean,
            value: !0,
            observer: "updateChildrenData"
        },
        zIndex: {
            type: Number,
            value: 10
        },
        duration: {
            type: Number,
            value: 200,
            observer: "updateChildrenData"
        },
        direction: {
            type: String,
            value: "down",
            observer: "updateChildrenData"
        },
        closeOnClickOverlay: {
            type: Boolean,
            value: !0,
            observer: "updateChildrenData"
        },
        closeOnClickOutside: {
            type: Boolean,
            value: !0
        }
    },
    data: {
        itemListData: []
    },
    beforeCreate: function() {
        var t = (0, n.getSystemInfoSync)().windowHeight;
        this.windowHeight = t, i.push(this);
    },
    destroyed: function() {
        var t = this;
        i = i.filter(function(e) {
            return e !== t;
        });
    },
    methods: {
        updateItemListData: function() {
            this.setData({
                itemListData: this.children.map(function(t) {
                    return t.data;
                })
            });
        },
        updateChildrenData: function() {
            this.children.forEach(function(t) {
                t.updateDataFromParent();
            });
        },
        toggleItem: function(t) {
            this.children.forEach(function(e, n) {
                var i = e.data.showPopup;
                n === t ? e.toggle() : i && e.toggle(!1, {
                    immediate: !0
                });
            });
        },
        close: function() {
            this.children.forEach(function(t) {
                t.toggle(!1, {
                    immediate: !0
                });
            });
        },
        getChildWrapperStyle: function() {
            var t = this, e = this.data, i = e.zIndex, o = e.direction;
            return (0, n.getRect)(this, ".van-dropdown-menu").then(function(e) {
                var a = e.top, r = void 0 === a ? 0 : a, d = e.bottom, u = "down" === o ? void 0 === d ? 0 : d : t.windowHeight - r, c = "z-index: ".concat(i, ";");
                return c += "down" === o ? "top: ".concat((0, n.addUnit)(u), ";") : "bottom: ".concat((0, 
                n.addUnit)(u), ";");
            });
        },
        onTitleTap: function(t) {
            var e = this, n = t.currentTarget.dataset.index;
            this.children[n].data.disabled || (i.forEach(function(t) {
                t && t.data.closeOnClickOutside && t !== e && t.close();
            }), this.toggleItem(n));
        }
    }
});