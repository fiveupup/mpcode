Object.defineProperty(exports, "__esModule", {
    value: !0
}), (0, require("../../../4C48BB651787E8AF2A2ED362CF198927.js").VantComponent)({
    props: {
        color: String,
        vertical: Boolean,
        type: {
            type: String,
            value: "circular"
        },
        size: String,
        textSize: String
    },
    data: {
        array12: Array.from({
            length: 12
        })
    }
});