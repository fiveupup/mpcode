Object.defineProperty(exports, "__esModule", {
    value: !0
}), (0, require("../../../4C48BB651787E8AF2A2ED362CF198927.js").VantComponent)({
    props: {
        dot: Boolean,
        info: null,
        size: null,
        color: String,
        customStyle: String,
        classPrefix: {
            type: String,
            value: "van-icon"
        },
        name: String
    },
    methods: {
        onClick: function() {
            this.$emit("click");
        }
    }
});