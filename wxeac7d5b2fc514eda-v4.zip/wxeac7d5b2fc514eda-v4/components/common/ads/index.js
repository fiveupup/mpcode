getApp();

Component({
    lifetimes: {
        attached: function() {}
    },
    properties: {
        adType: {
            type: String,
            value: "banner"
        },
        unitId: {
            type: String
        },
        adWidth: {
            type: Number,
            value: 686
        },
        adIntervals: {
            type: Number,
            value: 30
        },
        showBtn: {
            type: Boolean,
            value: !0
        },
        articleId: {
            type: String
        },
        showTopBtn: {
            type: Boolean,
            value: !1
        },
        showBottomBtn: {
            type: Boolean,
            value: !1
        }
    },
    data: {
        show: !0,
        logs: {
            id: "广点通广告",
            page: "打卡/作业成功页面"
        },
        showPopup: !1
    },
    methods: {
        onClose: function() {
            this.setData({
                show: !1
            });
        },
        topClose: function() {
            this.setData({
                show: !1
            });
        },
        adLoad: function() {},
        adError: function(o) {
            this.setData({
                show: !1
            }), console.log("Banner 广告加载失败", o);
        },
        adClose: function() {
            console.log("Banner 广告关闭");
        },
        onAdplay: function(o) {
            console.log("onAdplay", o);
        },
        onAdload: function(o) {
            console.log("onAdload", o);
        },
        onAdclose: function(o) {
            console.log("onAdclose", o);
        },
        onAdError: function(o) {
            console.log("onAdError", o), this.setData({
                show: !1
            });
        }
    }
});