var e = require("@babel/runtime/helpers/interopRequireDefault"), t = require("@babel/runtime/helpers/objectSpread2"), o = require("@babel/runtime/helpers/createForOfIteratorHelper"), n = e(require("@babel/runtime/regenerator")), a = require("@babel/runtime/helpers/asyncToGenerator"), i = require("196A17A11787E8AF7F0C7FA606BA8927.js").login;

require("42D23E741787E8AF24B45673136A8927.js"), App({
    onLaunch: function(e) {
        var t = this;
        return a(n.default.mark(function o() {
            var a, i, r, s;
            return n.default.wrap(function(o) {
                for (;;) switch (o.prev = o.next) {
                  case 0:
                    console.log("启动参数", e), a = e.scene, i = e.query, r = i.top_c, s = i.sub_c, t.globalData.scene = a, 
                    t.globalData.top_c = r, t.globalData.sub_c = s, t.globalData.deviceInfo = wx.getSystemInfoSync(), 
                    t.globalData.start_ts = Date.now(), t.loadConfig();

                  case 9:
                  case "end":
                    return o.stop();
                }
            }, o);
        }))();
    },
    globalData: {
        userInfo: null
    },
    pushLog: function() {
        console.log("开始上传埋点");
        var e = wx.getStorageSync("logs") || [], t = wx.getStorageSync("openid"), n = wx.getStorageSync("unionid"), a = wx.getAccountInfoSync().miniProgram;
        if (!(e.length < 1)) {
            var i, r = o(e);
            try {
                for (r.s(); !(i = r.n()).done; ) {
                    var s = i.value;
                    s.openid = t, s.unionid = n, s.appid = a.appId, s.version = a.version, s.scene = this.globalData.scene, 
                    s.top_c = this.globalData.top_c, s.sub_c = this.globalData.sub_c, this.globalData.userInfo && (s.ftop_c = this.globalData.userInfo.top_c, 
                    s.fsub_c = this.globalData.userInfo.sub_c);
                }
            } catch (e) {
                r.e(e);
            } finally {
                r.f();
            }
            wx.request({
                url: "https://a.jialidun.vip/logs",
                method: "POST",
                data: e,
                success: function(e) {
                    console.log("上传埋点成功", e), wx.setStorageSync("logs", []);
                },
                fail: function(e) {
                    console.log("上传埋点失败", e);
                }
            });
        }
    },
    addEvent: function(e) {
        e.ts = new Date().toLocaleString(), console.log("====addEvent 添加埋点===="), console.log(e), 
        console.log("========");
        var t = wx.getStorageSync("logs") || [];
        t.push(e), wx.setStorageSync("logs", t);
    },
    initLogin: function() {
        var e = this;
        return a(n.default.mark(function t() {
            return n.default.wrap(function(t) {
                for (;;) switch (t.prev = t.next) {
                  case 0:
                    if (console.log("--登录--"), t.prev = 1, wx.getStorageSync("token")) {
                        t.next = 8;
                        break;
                    }
                    return console.log("用户未登录"), t.next = 6, e.wxLogin();

                  case 6:
                    t.next = 10;
                    break;

                  case 8:
                    e.globalData.userInfo = wx.getStorageSync("userInfo"), e.globalData.openid = wx.getStorageSync("openid");

                  case 10:
                    t.next = 16;
                    break;

                  case 12:
                    return t.prev = 12, t.t0 = t.catch(1), console.log("检查登录异常了"), t.abrupt("return", !1);

                  case 16:
                  case "end":
                    return t.stop();
                }
            }, t, null, [ [ 1, 12 ] ]);
        }))();
    },
    wxLogin: function() {
        var e = this, o = this.globalData.deviceInfo, r = o.brand, s = o.system, c = o.platform, l = o.version, d = o.model, u = {
            scene: this.globalData.scene,
            sub_c: this.globalData.sub_c,
            top_c: this.globalData.top_c,
            brand: r,
            system: s,
            platform: c,
            model: d,
            version: l
        };
        return new Promise(function(o, r) {
            var s;
            wx.login({
                success: (s = a(n.default.mark(function a(s) {
                    var c, l, d, g, p, f;
                    return n.default.wrap(function(n) {
                        for (;;) switch (n.prev = n.next) {
                          case 0:
                            return c = s.code, n.next = 3, i(t({
                                code: c
                            }, u));

                          case 3:
                            0 == (l = n.sent).code ? (console.log("登录成功", l), d = l.data, g = d.openid, p = d.token, 
                            f = d.user, e.globalData.userInfo = f, e.globalData.openid = g, wx.setStorageSync("token", p), 
                            wx.setStorageSync("openid", g), wx.setStorageSync("userInfo", f), o(!0)) : (console.log("登录失败", l), 
                            r(!1));

                          case 5:
                          case "end":
                            return n.stop();
                        }
                    }, a);
                })), function(e) {
                    return s.apply(this, arguments);
                })
            });
        });
    },
    onHide: function() {
        console.log("onHide"), this.addEvent({
            id: "onHide",
            duration: Date.now() - this.globalData.start_ts
        }), this.pushLog();
    },
    loadConfig: function() {
        wx.request({
            url: "https://file.jialidun.vip/config.json?t=" + Date.now(),
            success: function(e) {
                e.data && wx.setStorageSync("config", e.data);
            }
        });
    },
    getAd: function() {},
    getSettings: function() {},
    loadMini: function() {
        if (console.log("加载半屏"), wx.openEmbeddedMiniProgram && wx.getStorageSync("config").showMiniAd2) {
            var e = wx.getStorageSync("userInfo");
            if (e && e.vip_expired_at && new Date(e.vip_expired_at).getTime() > Date.now()) console.log("vip用户"); else {
                wx.showToast({
                    title: "请关闭广告继续使用",
                    icon: "none",
                    duration: 5e3
                });
                var t = wx.getStorageSync("didiTs");
                if (!t || t <= Date.now()) {
                    this.addEvent({
                        id: "loadMiniAd",
                        type: "didi"
                    });
                    return wx.openEmbeddedMiniProgram({
                        appId: "wxaf35009675aa0b2a",
                        path: "/pages/index/index?scene=w5R3LB2&source_id=1"
                    }), void wx.setStorageSync("didiTs", new Date().setHours(0, 0, 0, 0) + 864e5);
                }
                if (wx.getStorageSync("config").showBaiLe) {
                    var o = wx.getStorageSync("bailets");
                    if (!o || o <= Date.now()) {
                        this.addEvent({
                            id: "loadMiniAd",
                            type: "baile"
                        });
                        return wx.openEmbeddedMiniProgram({
                            appId: "wx2db3e92239e6ab8e",
                            path: "/pages/list/index?mediaId=6368&adId=10067"
                        }), void wx.setStorageSync("bailets", new Date().setHours(0, 0, 0, 0) + 864e5);
                    }
                }
                this.addEvent({
                    id: "loadMiniAd"
                }), wx.openEmbeddedMiniProgram({
                    appId: "wxece3a9a4c82f58c9",
                    path: "commercialize/pages/taoke-guide/index?scene=78a98a9b2d544d18bd2b52f5276c0467"
                });
            }
        }
    }
});