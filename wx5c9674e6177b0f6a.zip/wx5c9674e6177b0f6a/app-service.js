var __wxAppData=__wxAppData||{};var __wxAppCode__=__wxAppCode__||{};var global=global||{};var __WXML_GLOBAL__=__WXML_GLOBAL__||{entrys:{},defines:{},modules:{},ops:[],wxs_nf_init:undefined,total_ops:0};var Component=Component||function(){};var definePlugin=definePlugin||function(){};var requirePlugin=requirePlugin||function(){};var Behavior=Behavior||function(){};var __vd_version_info__=__vd_version_info__||{};var __GWX_GLOBAL__=__GWX_GLOBAL__||{};if(this&&this.__g===undefined)Object.defineProperty(this,"__g",{configurable:false,enumerable:false,writable:false,value:function(){function D(e,t){if(typeof t!="undefined")e.children.push(t)}function S(e){if(typeof e!="undefined")return{tag:"virtual",wxKey:e,children:[]};return{tag:"virtual",children:[]}}function v(e){$gwxc++;if($gwxc>=16e3){throw"Dom limit exceeded, please check if there's any mistake you've made."}return{tag:"wx-"+e,attr:{},children:[],n:[],raw:{},generics:{}}}function e(e,t){t&&e.properities.push(t)}function t(e,t,r){return typeof e[r]!="undefined"?e[r]:t[r]}function u(e){console.warn("WXMLRT_"+g+":"+e)}function r(e,t){u(t+":-1:-1:-1: Template `"+e+"` is being called recursively, will be stop.")}var s=console.warn;var n=console.log;function o(){function e(){}e.prototype={hn:function(e,t){if(typeof e=="object"){var r=0;var n=false,o=false;for(var a in e){n=n|a==="__value__";o=o|a==="__wxspec__";r++;if(r>2)break}return r==2&&n&&o&&(t||e.__wxspec__!=="m"||this.hn(e.__value__)==="h")?"h":"n"}return"n"},nh:function(e,t){return{__value__:e,__wxspec__:t?t:true}},rv:function(e){return this.hn(e,true)==="n"?e:this.rv(e.__value__)},hm:function(e){if(typeof e=="object"){var t=0;var r=false,n=false;for(var o in e){r=r|o==="__value__";n=n|o==="__wxspec__";t++;if(t>2)break}return t==2&&r&&n&&(e.__wxspec__==="m"||this.hm(e.__value__))}return false}};return new e}var A=o();function T(e){var t=e.split("\n "+" "+" "+" ");for(var r=0;r<t.length;++r){if(0==r)continue;if(")"===t[r][t[r].length-1])t[r]=t[r].replace(/\s\(.*\)$/,"");else t[r]="at anonymous function"}return t.join("\n "+" "+" "+" ")}function a(M){function m(e,t,r,n,o){var a=false;var i=e[0][1];var p,u,l,f,v,c;switch(i){case"?:":p=x(e[1],t,r,n,o,a);l=M&&A.hn(p)==="h";f=A.rv(p)?x(e[2],t,r,n,o,a):x(e[3],t,r,n,o,a);f=l&&A.hn(f)==="n"?A.nh(f,"c"):f;return f;break;case"&&":p=x(e[1],t,r,n,o,a);l=M&&A.hn(p)==="h";f=A.rv(p)?x(e[2],t,r,n,o,a):A.rv(p);f=l&&A.hn(f)==="n"?A.nh(f,"c"):f;return f;break;case"||":p=x(e[1],t,r,n,o,a);l=M&&A.hn(p)==="h";f=A.rv(p)?A.rv(p):x(e[2],t,r,n,o,a);f=l&&A.hn(f)==="n"?A.nh(f,"c"):f;return f;break;case"+":case"*":case"/":case"%":case"|":case"^":case"&":case"===":case"==":case"!=":case"!==":case">=":case"<=":case">":case"<":case"<<":case">>":p=x(e[1],t,r,n,o,a);u=x(e[2],t,r,n,o,a);l=M&&(A.hn(p)==="h"||A.hn(u)==="h");switch(i){case"+":f=A.rv(p)+A.rv(u);break;case"*":f=A.rv(p)*A.rv(u);break;case"/":f=A.rv(p)/A.rv(u);break;case"%":f=A.rv(p)%A.rv(u);break;case"|":f=A.rv(p)|A.rv(u);break;case"^":f=A.rv(p)^A.rv(u);break;case"&":f=A.rv(p)&A.rv(u);break;case"===":f=A.rv(p)===A.rv(u);break;case"==":f=A.rv(p)==A.rv(u);break;case"!=":f=A.rv(p)!=A.rv(u);break;case"!==":f=A.rv(p)!==A.rv(u);break;case">=":f=A.rv(p)>=A.rv(u);break;case"<=":f=A.rv(p)<=A.rv(u);break;case">":f=A.rv(p)>A.rv(u);break;case"<":f=A.rv(p)<A.rv(u);break;case"<<":f=A.rv(p)<<A.rv(u);break;case">>":f=A.rv(p)>>A.rv(u);break;default:break}return l?A.nh(f,"c"):f;break;case"-":p=e.length===3?x(e[1],t,r,n,o,a):0;u=e.length===3?x(e[2],t,r,n,o,a):x(e[1],t,r,n,o,a);l=M&&(A.hn(p)==="h"||A.hn(u)==="h");f=l?A.rv(p)-A.rv(u):p-u;return l?A.nh(f,"c"):f;break;case"!":p=x(e[1],t,r,n,o,a);l=M&&A.hn(p)=="h";f=!A.rv(p);return l?A.nh(f,"c"):f;case"~":p=x(e[1],t,r,n,o,a);l=M&&A.hn(p)=="h";f=~A.rv(p);return l?A.nh(f,"c"):f;default:s("unrecognized op"+i)}}function x(e,t,r,n,o,a){var i=e[0];var p=false;if(typeof a!=="undefined")o.ap=a;if(typeof i==="object"){var u=i[0];var l,f,v,c,s,y,b,d,h,_,g;switch(u){case 2:return m(e,t,r,n,o);break;case 4:return x(e[1],t,r,n,o,p);break;case 5:switch(e.length){case 2:l=x(e[1],t,r,n,o,p);return M?[l]:[A.rv(l)];return[l];break;case 1:return[];break;default:l=x(e[1],t,r,n,o,p);v=x(e[2],t,r,n,o,p);l.push(M?v:A.rv(v));return l;break}break;case 6:l=x(e[1],t,r,n,o);var w=o.ap;h=A.hn(l)==="h";f=h?A.rv(l):l;o.is_affected|=h;if(M){if(f===null||typeof f==="undefined"){return h?A.nh(undefined,"e"):undefined}v=x(e[2],t,r,n,o,p);_=A.hn(v)==="h";c=_?A.rv(v):v;o.ap=w;o.is_affected|=_;if(c===null||typeof c==="undefined"||c==="__proto__"||c==="prototype"||c==="caller"){return h||_?A.nh(undefined,"e"):undefined}y=f[c];if(typeof y==="function"&&!w)y=undefined;g=A.hn(y)==="h";o.is_affected|=g;return h||_?g?y:A.nh(y,"e"):y}else{if(f===null||typeof f==="undefined"){return undefined}v=x(e[2],t,r,n,o,p);_=A.hn(v)==="h";c=_?A.rv(v):v;o.ap=w;o.is_affected|=_;if(c===null||typeof c==="undefined"||c==="__proto__"||c==="prototype"||c==="caller"){return undefined}y=f[c];if(typeof y==="function"&&!w)y=undefined;g=A.hn(y)==="h";o.is_affected|=g;return g?A.rv(y):y}case 7:switch(e[1][0]){case 11:o.is_affected|=A.hn(n)==="h";return n;case 3:b=A.rv(r);d=A.rv(t);v=e[1][1];if(n&&n.f&&n.f.hasOwnProperty(v)){l=n.f;o.ap=true}else{l=b&&b.hasOwnProperty(v)?r:d&&d.hasOwnProperty(v)?t:undefined}if(M){if(l){h=A.hn(l)==="h";f=h?A.rv(l):l;y=f[v];g=A.hn(y)==="h";o.is_affected|=h||g;y=h&&!g?A.nh(y,"e"):y;return y}}else{if(l){h=A.hn(l)==="h";f=h?A.rv(l):l;y=f[v];g=A.hn(y)==="h";o.is_affected|=h||g;return A.rv(y)}}return undefined}break;case 8:l={};l[e[1]]=x(e[2],t,r,n,o,p);return l;break;case 9:l=x(e[1],t,r,n,o,p);v=x(e[2],t,r,n,o,p);function O(e,t,r){var n,o;h=A.hn(e)==="h";_=A.hn(t)==="h";f=A.rv(e);c=A.rv(t);for(var a in c){if(r||!f.hasOwnProperty(a)){f[a]=M?_?A.nh(c[a],"e"):c[a]:A.rv(c[a])}}return e}var s=l;var j=true;if(typeof e[1][0]==="object"&&e[1][0][0]===10){l=v;v=s;j=false}if(typeof e[1][0]==="object"&&e[1][0][0]===10){var P={};return O(O(P,l,j),v,j)}else return O(l,v,j);break;case 10:l=x(e[1],t,r,n,o,p);l=M?l:A.rv(l);return l;break;case 12:var P;l=x(e[1],t,r,n,o);if(!o.ap){return M&&A.hn(l)==="h"?A.nh(P,"f"):P}var w=o.ap;v=x(e[2],t,r,n,o,p);o.ap=w;h=A.hn(l)==="h";_=N(v);f=A.rv(l);c=A.rv(v);snap_bb=K(c,"nv_");try{P=typeof f==="function"?K(f.apply(null,snap_bb)):undefined}catch(t){t.message=t.message.replace(/nv_/g,"");t.stack=t.stack.substring(0,t.stack.indexOf("\n",t.stack.lastIndexOf("at nv_")));t.stack=t.stack.replace(/\snv_/g," ");t.stack=T(t.stack);if(n.debugInfo){t.stack+="\n "+" "+" "+" at "+n.debugInfo[0]+":"+n.debugInfo[1]+":"+n.debugInfo[2];console.error(t)}P=undefined}return M&&(_||h)?A.nh(P,"f"):P}}else{if(i===3||i===1)return e[1];else if(i===11){var l="";for(var D=1;D<e.length;D++){var S=A.rv(x(e[D],t,r,n,o,p));l+=typeof S==="undefined"?"":S}return l}}}function e(e,t,r,n,o,a){if(e[0]=="11182016"){n.debugInfo=e[2];return x(e[1],t,r,n,o,a)}else{n.debugInfo=null;return x(e,t,r,n,o,a)}}return e}var f=a(true);var c=a(false);function i(e,t,r,n,o,a,i,p){{var u={is_affected:false};var l=f(t,r,n,o,u);if(JSON.stringify(l)!=JSON.stringify(a)||u.is_affected!=p){console.warn("A. "+e+" get result "+JSON.stringify(l)+", "+u.is_affected+", but "+JSON.stringify(a)+", "+p+" is expected")}}{var u={is_affected:false};var l=c(t,r,n,o,u);if(JSON.stringify(l)!=JSON.stringify(i)||u.is_affected!=p){console.warn("B. "+e+" get result "+JSON.stringify(l)+", "+u.is_affected+", but "+JSON.stringify(i)+", "+p+" is expected")}}}function y(e,t,r,n,o,a,i,p,u){var l=A.hn(e)==="n";var f=A.rv(n);var v=f.hasOwnProperty(i);var c=f.hasOwnProperty(p);var s=f[i];var y=f[p];var b=Object.prototype.toString.call(A.rv(e));var d=b[8];if(d==="N"&&b[10]==="l")d="X";var h;if(l){if(d==="A"){var _;for(var g=0;g<e.length;g++){f[i]=e[g];f[p]=l?g:A.nh(g,"h");_=A.rv(e[g]);var w=u&&_?u==="*this"?_:A.rv(_[u]):undefined;h=S(w);D(a,h);t(r,f,h,o)}}else if(d==="O"){var g=0;var _;for(var O in e){f[i]=e[O];f[p]=l?O:A.nh(O,"h");_=A.rv(e[O]);var w=u&&_?u==="*this"?_:A.rv(_[u]):undefined;h=S(w);D(a,h);t(r,f,h,o);g++}}else if(d==="S"){for(var g=0;g<e.length;g++){f[i]=e[g];f[p]=l?g:A.nh(g,"h");h=S(e[g]+g);D(a,h);t(r,f,h,o)}}else if(d==="N"){for(var g=0;g<e;g++){f[i]=g;f[p]=l?g:A.nh(g,"h");h=S(g);D(a,h);t(r,f,h,o)}}else{}}else{var j=A.rv(e);var _,P;if(d==="A"){for(var g=0;g<j.length;g++){P=j[g];P=A.hn(P)==="n"?A.nh(P,"h"):P;_=A.rv(P);f[i]=P;f[p]=l?g:A.nh(g,"h");var w=u&&_?u==="*this"?_:A.rv(_[u]):undefined;h=S(w);D(a,h);t(r,f,h,o)}}else if(d==="O"){var g=0;for(var O in j){P=j[O];P=A.hn(P)==="n"?A.nh(P,"h"):P;_=A.rv(P);f[i]=P;f[p]=l?O:A.nh(O,"h");var w=u&&_?u==="*this"?_:A.rv(_[u]):undefined;h=S(w);D(a,h);t(r,f,h,o);g++}}else if(d==="S"){for(var g=0;g<j.length;g++){P=A.nh(j[g],"h");f[i]=P;f[p]=l?g:A.nh(g,"h");h=S(e[g]+g);D(a,h);t(r,f,h,o)}}else if(d==="N"){for(var g=0;g<j;g++){P=A.nh(g,"h");f[i]=P;f[p]=l?g:A.nh(g,"h");h=S(g);D(a,h);t(r,f,h,o)}}else{}}if(v){f[i]=s}else{delete f[i]}if(c){f[p]=y}else{delete f[p]}}function N(e){if(A.hn(e)=="h")return true;if(typeof e!=="object")return false;for(var t in e){if(e.hasOwnProperty(t)){if(N(e[t]))return true}}return false}function b(e,t,r,n,o){var a=false;var i=K(n,"",2);if(o.ap&&i&&i.constructor===Function){t="$wxs:"+t;e.attr["$gdc"]=K}if(o.is_affected||N(n)){e.n.push(t);e.raw[t]=n}e.attr[t]=i}function d(e,t,r,n,o,a){a.opindex=r;var i={},p;var u=c(z[r],n,o,a,i);b(e,t,r,u,i)}function h(e,t,r,n,o,a,i){i.opindex=n;var p={},u;var l=c(e[n],o,a,i,p);b(t,r,n,l,p)}function p(e,t,r,n){n.opindex=e;var o={};var a=c(z[e],t,r,n,o);return a&&a.constructor===Function?undefined:a}function l(e,t,r,n,o){o.opindex=t;var a={};var i=c(e[t],r,n,o,a);return i&&i.constructor===Function?undefined:i}function _(e,t,r,n,o){var o=o||{};n.opindex=e;return f(z[e],t,r,n,o)}function w(e,t,r,n,o,a){var a=a||{};o.opindex=t;return f(e[t],r,n,o,a)}function O(e,t,r,n,o,a,i,p,u){var l={};var f=_(e,r,n,o);y(f,t,r,n,o,a,i,p,u)}function j(e,t,r,n,o,a,i,p,u,l){var f={};var v=w(e,t,n,o,a);y(v,r,n,o,a,i,p,u,l)}function P(e,t,r,n,o,a){var i=v(e);var p=0;for(var u=0;u<t.length;u+=2){if(p+t[u+1]<0){i.attr[t[u]]=true}else{d(i,t[u],p+t[u+1],n,o,a);if(p===0)p=t[u+1]}}for(var u=0;u<r.length;u+=2){if(p+r[u+1]<0){i.generics[r[u]]=""}else{var l=c(z[p+r[u+1]],n,o,a);if(l!="")l="wx-"+l;i.generics[r[u]]=l;if(p===0)p=r[u+1]}}return i}function M(e,t,r,n,o,a,i){var p=v(t);var u=0;for(var l=0;l<r.length;l+=2){if(u+r[l+1]<0){p.attr[r[l]]=true}else{h(e,p,r[l],u+r[l+1],o,a,i);if(u===0)u=r[l+1]}}for(var l=0;l<n.length;l+=2){if(u+n[l+1]<0){p.generics[n[l]]=""}else{var f=c(e[u+n[l+1]],o,a,i);if(f!="")f="wx-"+f;p.generics[n[l]]=f;if(u===0)u=n[l+1]}}return p}var m=function(){if(typeof __WXML_GLOBAL__==="undefined"||undefined===__WXML_GLOBAL__.wxs_nf_init){x();C();k();U();I();L();E();R();F()}if(typeof __WXML_GLOBAL__!=="undefined")__WXML_GLOBAL__.wxs_nf_init=true};var x=function(){Object.defineProperty(Object.prototype,"nv_constructor",{writable:true,value:"Object"});Object.defineProperty(Object.prototype,"nv_toString",{writable:true,value:function(){return"[object Object]"}})};var C=function(){Object.defineProperty(Function.prototype,"nv_constructor",{writable:true,value:"Function"});Object.defineProperty(Function.prototype,"nv_length",{get:function(){return this.length},set:function(){}});Object.defineProperty(Function.prototype,"nv_toString",{writable:true,value:function(){return"[function Function]"}})};var k=function(){Object.defineProperty(Array.prototype,"nv_toString",{writable:true,value:function(){return this.nv_join()}});Object.defineProperty(Array.prototype,"nv_join",{writable:true,value:function(e){e=undefined==e?",":e;var t="";for(var r=0;r<this.length;++r){if(0!=r)t+=e;if(null==this[r]||undefined==this[r])t+="";else if(typeof this[r]=="function")t+=this[r].nv_toString();else if(typeof this[r]=="object"&&this[r].nv_constructor==="Array")t+=this[r].nv_join();else t+=this[r].toString()}return t}});Object.defineProperty(Array.prototype,"nv_constructor",{writable:true,value:"Array"});Object.defineProperty(Array.prototype,"nv_concat",{writable:true,value:Array.prototype.concat});Object.defineProperty(Array.prototype,"nv_pop",{writable:true,value:Array.prototype.pop});Object.defineProperty(Array.prototype,"nv_push",{writable:true,value:Array.prototype.push});Object.defineProperty(Array.prototype,"nv_reverse",{writable:true,value:Array.prototype.reverse});Object.defineProperty(Array.prototype,"nv_shift",{writable:true,value:Array.prototype.shift});Object.defineProperty(Array.prototype,"nv_slice",{writable:true,value:Array.prototype.slice});Object.defineProperty(Array.prototype,"nv_sort",{writable:true,value:Array.prototype.sort});Object.defineProperty(Array.prototype,"nv_splice",{writable:true,value:Array.prototype.splice});Object.defineProperty(Array.prototype,"nv_unshift",{writable:true,value:Array.prototype.unshift});Object.defineProperty(Array.prototype,"nv_indexOf",{writable:true,value:Array.prototype.indexOf});Object.defineProperty(Array.prototype,"nv_lastIndexOf",{writable:true,value:Array.prototype.lastIndexOf});Object.defineProperty(Array.prototype,"nv_every",{writable:true,value:Array.prototype.every});Object.defineProperty(Array.prototype,"nv_some",{writable:true,value:Array.prototype.some});Object.defineProperty(Array.prototype,"nv_forEach",{writable:true,value:Array.prototype.forEach});Object.defineProperty(Array.prototype,"nv_map",{writable:true,value:Array.prototype.map});Object.defineProperty(Array.prototype,"nv_filter",{writable:true,value:Array.prototype.filter});Object.defineProperty(Array.prototype,"nv_reduce",{writable:true,value:Array.prototype.reduce});Object.defineProperty(Array.prototype,"nv_reduceRight",{writable:true,value:Array.prototype.reduceRight});Object.defineProperty(Array.prototype,"nv_length",{get:function(){return this.length},set:function(e){this.length=e}})};var U=function(){Object.defineProperty(String.prototype,"nv_constructor",{writable:true,value:"String"});Object.defineProperty(String.prototype,"nv_toString",{writable:true,value:String.prototype.toString});Object.defineProperty(String.prototype,"nv_valueOf",{writable:true,value:String.prototype.valueOf});Object.defineProperty(String.prototype,"nv_charAt",{writable:true,value:String.prototype.charAt});Object.defineProperty(String.prototype,"nv_charCodeAt",{writable:true,value:String.prototype.charCodeAt});Object.defineProperty(String.prototype,"nv_concat",{writable:true,value:String.prototype.concat});Object.defineProperty(String.prototype,"nv_indexOf",{writable:true,value:String.prototype.indexOf});Object.defineProperty(String.prototype,"nv_lastIndexOf",{writable:true,value:String.prototype.lastIndexOf});Object.defineProperty(String.prototype,"nv_localeCompare",{writable:true,value:String.prototype.localeCompare});Object.defineProperty(String.prototype,"nv_match",{writable:true,value:String.prototype.match});Object.defineProperty(String.prototype,"nv_replace",{writable:true,value:String.prototype.replace});Object.defineProperty(String.prototype,"nv_search",{writable:true,value:String.prototype.search});Object.defineProperty(String.prototype,"nv_slice",{writable:true,value:String.prototype.slice});Object.defineProperty(String.prototype,"nv_split",{writable:true,value:String.prototype.split});Object.defineProperty(String.prototype,"nv_substring",{writable:true,value:String.prototype.substring});Object.defineProperty(String.prototype,"nv_toLowerCase",{writable:true,value:String.prototype.toLowerCase});Object.defineProperty(String.prototype,"nv_toLocaleLowerCase",{writable:true,value:String.prototype.toLocaleLowerCase});Object.defineProperty(String.prototype,"nv_toUpperCase",{writable:true,value:String.prototype.toUpperCase});Object.defineProperty(String.prototype,"nv_toLocaleUpperCase",{writable:true,value:String.prototype.toLocaleUpperCase});Object.defineProperty(String.prototype,"nv_trim",{writable:true,value:String.prototype.trim});Object.defineProperty(String.prototype,"nv_length",{get:function(){return this.length},set:function(e){this.length=e}})};var I=function(){Object.defineProperty(Boolean.prototype,"nv_constructor",{writable:true,value:"Boolean"});Object.defineProperty(Boolean.prototype,"nv_toString",{writable:true,value:Boolean.prototype.toString});Object.defineProperty(Boolean.prototype,"nv_valueOf",{writable:true,value:Boolean.prototype.valueOf})};var L=function(){Object.defineProperty(Number,"nv_MAX_VALUE",{writable:false,value:Number.MAX_VALUE});Object.defineProperty(Number,"nv_MIN_VALUE",{writable:false,value:Number.MIN_VALUE});Object.defineProperty(Number,"nv_NEGATIVE_INFINITY",{writable:false,value:Number.NEGATIVE_INFINITY});Object.defineProperty(Number,"nv_POSITIVE_INFINITY",{writable:false,value:Number.POSITIVE_INFINITY});Object.defineProperty(Number.prototype,"nv_constructor",{writable:true,value:"Number"});Object.defineProperty(Number.prototype,"nv_toString",{writable:true,value:Number.prototype.toString});Object.defineProperty(Number.prototype,"nv_toLocaleString",{writable:true,value:Number.prototype.toLocaleString});Object.defineProperty(Number.prototype,"nv_valueOf",{writable:true,value:Number.prototype.valueOf});Object.defineProperty(Number.prototype,"nv_toFixed",{writable:true,value:Number.prototype.toFixed});Object.defineProperty(Number.prototype,"nv_toExponential",{writable:true,value:Number.prototype.toExponential});Object.defineProperty(Number.prototype,"nv_toPrecision",{writable:true,value:Number.prototype.toPrecision})};var E=function(){Object.defineProperty(Math,"nv_E",{writable:false,value:Math.E});Object.defineProperty(Math,"nv_LN10",{writable:false,value:Math.LN10});Object.defineProperty(Math,"nv_LN2",{writable:false,value:Math.LN2});Object.defineProperty(Math,"nv_LOG2E",{writable:false,value:Math.LOG2E});Object.defineProperty(Math,"nv_LOG10E",{writable:false,value:Math.LOG10E});Object.defineProperty(Math,"nv_PI",{writable:false,value:Math.PI});Object.defineProperty(Math,"nv_SQRT1_2",{writable:false,value:Math.SQRT1_2});Object.defineProperty(Math,"nv_SQRT2",{writable:false,value:Math.SQRT2});Object.defineProperty(Math,"nv_abs",{writable:false,value:Math.abs});Object.defineProperty(Math,"nv_acos",{writable:false,value:Math.acos});Object.defineProperty(Math,"nv_asin",{writable:false,value:Math.asin});Object.defineProperty(Math,"nv_atan",{writable:false,value:Math.atan});Object.defineProperty(Math,"nv_atan2",{writable:false,value:Math.atan2});Object.defineProperty(Math,"nv_ceil",{writable:false,value:Math.ceil});Object.defineProperty(Math,"nv_cos",{writable:false,value:Math.cos});Object.defineProperty(Math,"nv_exp",{writable:false,value:Math.exp});Object.defineProperty(Math,"nv_floor",{writable:false,value:Math.floor});Object.defineProperty(Math,"nv_log",{writable:false,value:Math.log});Object.defineProperty(Math,"nv_max",{writable:false,value:Math.max});Object.defineProperty(Math,"nv_min",{writable:false,value:Math.min});Object.defineProperty(Math,"nv_pow",{writable:false,value:Math.pow});Object.defineProperty(Math,"nv_random",{writable:false,value:Math.random});Object.defineProperty(Math,"nv_round",{writable:false,value:Math.round});Object.defineProperty(Math,"nv_sin",{writable:false,value:Math.sin});Object.defineProperty(Math,"nv_sqrt",{writable:false,value:Math.sqrt});Object.defineProperty(Math,"nv_tan",{writable:false,value:Math.tan})};var R=function(){Object.defineProperty(Date.prototype,"nv_constructor",{writable:true,value:"Date"});Object.defineProperty(Date,"nv_parse",{writable:true,value:Date.parse});Object.defineProperty(Date,"nv_UTC",{writable:true,value:Date.UTC});Object.defineProperty(Date,"nv_now",{writable:true,value:Date.now});Object.defineProperty(Date.prototype,"nv_toString",{writable:true,value:Date.prototype.toString});Object.defineProperty(Date.prototype,"nv_toDateString",{writable:true,value:Date.prototype.toDateString});Object.defineProperty(Date.prototype,"nv_toTimeString",{writable:true,value:Date.prototype.toTimeString});Object.defineProperty(Date.prototype,"nv_toLocaleString",{writable:true,value:Date.prototype.toLocaleString});Object.defineProperty(Date.prototype,"nv_toLocaleDateString",{writable:true,value:Date.prototype.toLocaleDateString});Object.defineProperty(Date.prototype,"nv_toLocaleTimeString",{writable:true,value:Date.prototype.toLocaleTimeString});Object.defineProperty(Date.prototype,"nv_valueOf",{writable:true,value:Date.prototype.valueOf});Object.defineProperty(Date.prototype,"nv_getTime",{writable:true,value:Date.prototype.getTime});Object.defineProperty(Date.prototype,"nv_getFullYear",{writable:true,value:Date.prototype.getFullYear});Object.defineProperty(Date.prototype,"nv_getUTCFullYear",{writable:true,value:Date.prototype.getUTCFullYear});Object.defineProperty(Date.prototype,"nv_getMonth",{writable:true,value:Date.prototype.getMonth});Object.defineProperty(Date.prototype,"nv_getUTCMonth",{writable:true,value:Date.prototype.getUTCMonth});Object.defineProperty(Date.prototype,"nv_getDate",{writable:true,value:Date.prototype.getDate});Object.defineProperty(Date.prototype,"nv_getUTCDate",{writable:true,value:Date.prototype.getUTCDate});Object.defineProperty(Date.prototype,"nv_getDay",{writable:true,value:Date.prototype.getDay});Object.defineProperty(Date.prototype,"nv_getUTCDay",{writable:true,value:Date.prototype.getUTCDay});Object.defineProperty(Date.prototype,"nv_getHours",{writable:true,value:Date.prototype.getHours});Object.defineProperty(Date.prototype,"nv_getUTCHours",{writable:true,value:Date.prototype.getUTCHours});Object.defineProperty(Date.prototype,"nv_getMinutes",{writable:true,value:Date.prototype.getMinutes});Object.defineProperty(Date.prototype,"nv_getUTCMinutes",{writable:true,value:Date.prototype.getUTCMinutes});Object.defineProperty(Date.prototype,"nv_getSeconds",{writable:true,value:Date.prototype.getSeconds});Object.defineProperty(Date.prototype,"nv_getUTCSeconds",{writable:true,value:Date.prototype.getUTCSeconds});Object.defineProperty(Date.prototype,"nv_getMilliseconds",{writable:true,value:Date.prototype.getMilliseconds});Object.defineProperty(Date.prototype,"nv_getUTCMilliseconds",{writable:true,value:Date.prototype.getUTCMilliseconds});Object.defineProperty(Date.prototype,"nv_getTimezoneOffset",{writable:true,value:Date.prototype.getTimezoneOffset});Object.defineProperty(Date.prototype,"nv_setTime",{writable:true,value:Date.prototype.setTime});Object.defineProperty(Date.prototype,"nv_setMilliseconds",{writable:true,value:Date.prototype.setMilliseconds});Object.defineProperty(Date.prototype,"nv_setUTCMilliseconds",{writable:true,value:Date.prototype.setUTCMilliseconds});Object.defineProperty(Date.prototype,"nv_setSeconds",{writable:true,value:Date.prototype.setSeconds});Object.defineProperty(Date.prototype,"nv_setUTCSeconds",{writable:true,value:Date.prototype.setUTCSeconds});Object.defineProperty(Date.prototype,"nv_setMinutes",{writable:true,value:Date.prototype.setMinutes});Object.defineProperty(Date.prototype,"nv_setUTCMinutes",{writable:true,value:Date.prototype.setUTCMinutes});Object.defineProperty(Date.prototype,"nv_setHours",{writable:true,value:Date.prototype.setHours});Object.defineProperty(Date.prototype,"nv_setUTCHours",{writable:true,value:Date.prototype.setUTCHours});Object.defineProperty(Date.prototype,"nv_setDate",{writable:true,value:Date.prototype.setDate});Object.defineProperty(Date.prototype,"nv_setUTCDate",{writable:true,value:Date.prototype.setUTCDate});Object.defineProperty(Date.prototype,"nv_setMonth",{writable:true,value:Date.prototype.setMonth});Object.defineProperty(Date.prototype,"nv_setUTCMonth",{writable:true,value:Date.prototype.setUTCMonth});Object.defineProperty(Date.prototype,"nv_setFullYear",{writable:true,value:Date.prototype.setFullYear});Object.defineProperty(Date.prototype,"nv_setUTCFullYear",{writable:true,value:Date.prototype.setUTCFullYear});Object.defineProperty(Date.prototype,"nv_toUTCString",{writable:true,value:Date.prototype.toUTCString});Object.defineProperty(Date.prototype,"nv_toISOString",{writable:true,value:Date.prototype.toISOString});Object.defineProperty(Date.prototype,"nv_toJSON",{writable:true,value:Date.prototype.toJSON})};var F=function(){Object.defineProperty(RegExp.prototype,"nv_constructor",{writable:true,value:"RegExp"});Object.defineProperty(RegExp.prototype,"nv_exec",{writable:true,value:RegExp.prototype.exec});Object.defineProperty(RegExp.prototype,"nv_test",{writable:true,value:RegExp.prototype.test});Object.defineProperty(RegExp.prototype,"nv_toString",{writable:true,value:RegExp.prototype.toString});Object.defineProperty(RegExp.prototype,"nv_source",{get:function(){return this.source},set:function(){}});Object.defineProperty(RegExp.prototype,"nv_global",{get:function(){return this.global},set:function(){}});Object.defineProperty(RegExp.prototype,"nv_ignoreCase",{get:function(){return this.ignoreCase},set:function(){}});Object.defineProperty(RegExp.prototype,"nv_multiline",{get:function(){return this.multiline},set:function(){}});Object.defineProperty(RegExp.prototype,"nv_lastIndex",{get:function(){return this.lastIndex},set:function(e){this.lastIndex=e}})};m();var J=function(){var e=Array.prototype.slice.call(arguments);e.unshift(Date);return new(Function.prototype.bind.apply(Date,e))};var B=function(){var e=Array.prototype.slice.call(arguments);e.unshift(RegExp);return new(Function.prototype.bind.apply(RegExp,e))};var Y={};Y.nv_log=function(){var e="WXSRT:";for(var t=0;t<arguments.length;++t)e+=arguments[t]+" ";console.log(e)};var G=parseInt,X=parseFloat,H=isNaN,V=isFinite,$=decodeURI,W=decodeURIComponent,Q=encodeURI,q=encodeURIComponent;function K(e,t,r){e=A.rv(e);if(e===null||e===undefined)return e;if(typeof e==="string"||typeof e==="boolean"||typeof e==="number")return e;if(e.constructor===Object){var n={};for(var o in e)if(Object.prototype.hasOwnProperty.call(e,o))if(undefined===t)n[o.substring(3)]=K(e[o],t,r);else n[t+o]=K(e[o],t,r);return n}if(e.constructor===Array){var n=[];for(var a=0;a<e.length;a++)n.push(K(e[a],t,r));return n}if(e.constructor===Date){var n=new Date;n.setTime(e.getTime());return n}if(e.constructor===RegExp){var i="";if(e.global)i+="g";if(e.ignoreCase)i+="i";if(e.multiline)i+="m";return new RegExp(e.source,i)}if(r&&typeof e==="function"){if(r==1)return K(e(),undefined,2);if(r==2)return e}return null}var Z={};Z.nv_stringify=function(e){JSON.stringify(e);return JSON.stringify(K(e))};Z.nv_parse=function(e){if(e===undefined)return undefined;var t=JSON.parse(e);return K(t,"nv_")};function ee(e,t,r,n){e.extraAttr={t_action:t,t_rawid:r};if(typeof n!="undefined")e.extraAttr.t_cid=n}function te(){if(typeof __globalThis.__webview_engine_version__=="undefined")return 0;return __globalThis.__webview_engine_version__}function re(e,t,r,n,o,a){var i=ne(t,r,n);if(i)e.push(i);else{e.push("");u(n+":import:"+o+":"+a+": Path `"+t+"` not found from `"+n+"`.")}}function ne(e,t,r){if(e[0]!="/"){var n=r.split("/");n.pop();var o=e.split("/");for(var a=0;a<o.length;a++){if(o[a]=="..")n.pop();else if(!o[a]||o[a]==".")continue;else n.push(o[a])}e=n.join("/")}if(r[0]=="."&&e[0]=="/")e="."+e;if(t[e])return e;if(t[e+".wxml"])return e+".wxml"}function oe(e,t,r,n){if(!t)return;if(n[e][t])return n[e][t];for(var o=r[e].i.length-1;o>=0;o--){if(r[e].i[o]&&n[r[e].i[o]][t])return n[r[e].i[o]][t]}for(var o=r[e].ti.length-1;o>=0;o--){var a=ne(r[e].ti[o],r,e);if(a&&n[a][t])return n[a][t]}var i=ae(r,e);for(var o=0;o<i.length;o++){if(i[o]&&n[i[o]][t])return n[i[o]][t]}for(var p=r[e].j.length-1;p>=0;p--)if(r[e].j[p]){for(var a=r[r[e].j[p]].ti.length-1;a>=0;a--){var u=ne(r[r[e].j[p]].ti[a],r,e);if(u&&n[u][t]){return n[u][t]}}}}function ae(e,t){if(!t)return[];if($gaic[t]){return $gaic[t]}var r=[],n=[],o=0,a=0,i={},p={};n.push(t);p[t]=true;a++;while(o<a){var u=n[o++];for(var l=0;l<e[u].ic.length;l++){var f=e[u].ic[l];var v=ne(f,e,u);if(v&&!p[v]){p[v]=true;n.push(v);a++}}for(var l=0;u!=t&&l<e[u].ti.length;l++){var c=e[u].ti[l];var s=ne(c,e,u);if(s&&!i[s]){i[s]=true;r.push(s)}}}$gaic[t]=r;return r}var ie={};function pe(e,t,r,n,o,a,i){var p=ne(e,t,r);t[r].j.push(p);if(p){if(ie[p]){u("-1:include:-1:-1: `"+e+"` is being included in a loop, will be stop.");return}ie[p]=true;try{t[p].f(n,o,a,i)}catch(n){}ie[p]=false}else{u(r+":include:-1:-1: Included path `"+e+"` not found from `"+r+"`.")}}function ue(e,t,r,n){u(t+":template:"+r+":"+n+": Template `"+e+"` not found.")}function le(e){var t=false;delete e.properities;delete e.n;if(e.children){do{t=false;var r=[];for(var n=0;n<e.children.length;n++){var o=e.children[n];if(o.tag=="virtual"){t=true;for(var a=0;o.children&&a<o.children.length;a++){r.push(o.children[a])}}else{r.push(o)}}e.children=r}while(t);for(var n=0;n<e.children.length;n++){le(e.children[n])}}return e}function fe(e){if(e.tag=="wx-wx-scope"){e.tag="virtual";e.wxCkey="11";e["wxScopeData"]=e.attr["wx:scope-data"];delete e.n;delete e.raw;delete e.generics;delete e.attr}for(var t=0;e.children&&t<e.children.length;t++){fe(e.children[t])}return e}return{a:D,b:S,c:v,d:e,e:t,f:u,g:r,h:s,i:n,j:o,k:A,l:T,m:a,n:f,o:c,p:i,q:y,r:N,s:b,t:d,u:h,v:p,w:l,x:_,y:w,z:O,A:j,B:P,C:M,D:J,E:B,F:Y,G:G,H:X,I:H,J:V,K:$,L:W,M:Q,N:q,O:K,P:Z,Q:ee,R:te,S:re,T:ne,U:oe,V:ae,W:ie,X:pe,Y:ue,Z:le,aa:fe}}()});Object.freeze(__g);g="";	__wxAppCode__['call.json'] = {"usingComponents":{"footer":"/components/footer/footer","van-action-sheet":"/components/vant/action-sheet/index","my-privacy":"/components/privacy/privacy"},"disableScroll":true,"navigationBarTitleText":"小正方助手"};
		__wxAppCode__['components/footer/footer.json'] = {"component":true,"usingComponents":{}};
		__wxAppCode__['components/privacy/privacy.json'] = {"component":true,"usingComponents":{"van-popup":"/components/vant/popup/index"}};
		__wxAppCode__['components/vant/action-sheet/index.json'] = {"component":true,"usingComponents":{"van-icon":"../icon/index","van-popup":"../popup/index","van-loading":"../loading/index"}};
		__wxAppCode__['components/vant/button/index.json'] = {"component":true,"usingComponents":{"van-icon":"../icon/index","van-loading":"../loading/index"}};
		__wxAppCode__['components/vant/cell-group/index.json'] = {"component":true,"usingComponents":{}};
		__wxAppCode__['components/vant/cell/index.json'] = {"component":true,"usingComponents":{"van-icon":"../icon/index"}};
		__wxAppCode__['components/vant/checkbox/index.json'] = {"component":true,"usingComponents":{"van-icon":"../icon/index"}};
		__wxAppCode__['components/vant/circle/index.json'] = {"component":true,"usingComponents":{}};
		__wxAppCode__['components/vant/dialog/index.json'] = {"component":true,"usingComponents":{"van-popup":"../popup/index","van-button":"../button/index","van-goods-action":"../goods-action//index","van-goods-action-button":"../goods-action-button/index"}};
		__wxAppCode__['components/vant/divider/index.json'] = {"component":true,"usingComponents":{}};
		__wxAppCode__['components/vant/field/index.json'] = {"component":true,"usingComponents":{"van-cell":"../cell/index","van-icon":"../icon/index"}};
		__wxAppCode__['components/vant/goods-action-button/index.json'] = {"component":true,"usingComponents":{"van-button":"../button/index"}};
		__wxAppCode__['components/vant/goods-action/index.json'] = {"component":true,"usingComponents":{}};
		__wxAppCode__['components/vant/icon/index.json'] = {"component":true,"usingComponents":{"van-info":"../info/index"}};
		__wxAppCode__['components/vant/info/index.json'] = {"component":true,"usingComponents":{}};
		__wxAppCode__['components/vant/loading/index.json'] = {"component":true,"usingComponents":{}};
		__wxAppCode__['components/vant/notice-bar/index.json'] = {"component":true,"usingComponents":{"van-icon":"../icon/index"}};
		__wxAppCode__['components/vant/overlay/index.json'] = {"component":true,"usingComponents":{"van-transition":"../transition/index"}};
		__wxAppCode__['components/vant/popup/index.json'] = {"component":true,"usingComponents":{"van-icon":"../icon/index","van-overlay":"../overlay/index"}};
		__wxAppCode__['components/vant/search/index.json'] = {"component":true,"usingComponents":{"van-field":"../field/index"}};
		__wxAppCode__['components/vant/steps/index.json'] = {"component":true,"usingComponents":{"van-icon":"../icon/index"}};
		__wxAppCode__['components/vant/sticky/index.json'] = {"component":true,"usingComponents":{}};
		__wxAppCode__['components/vant/tag/index.json'] = {"component":true,"usingComponents":{"van-icon":"../icon/index"}};
		__wxAppCode__['components/vant/transition/index.json'] = {"component":true,"usingComponents":{}};
		__wxAppCode__['pages/file/cloudFile/index.json'] = {"usingComponents":{"van-popup":"/components/vant/popup/index","van-button":"/components/vant/button/index","van-cell":"/components/vant/cell/index","van-action-sheet":"/components/vant/action-sheet/index","van-icon":"/components/vant/icon/index","van-divider":"/components/vant/divider/index","van-search":"/components/vant/search/index","van-overlay":"/components/vant/overlay/index","van-circle":"/components/vant/circle/index","van-dialog":"/components/vant/dialog/index","van-transition":"/components/vant/transition/index","van-notice-bar":"/components/vant/notice-bar/index","my-privacy":"/components/privacy/privacy"},"navigationBarTitleText":"小正方助手","enablePullDownRefresh":true};
		__wxAppCode__['pages/home/home.json'] = {"usingComponents":{"van-cell":"/components/vant/cell/index","van-cell-group":"/components/vant/cell-group/index","van-divider":"/components/vant/divider/index","van-transition":"/components/vant/transition/index","van-icon":"/components/vant/icon/index","van-sticky":"/components/vant/sticky/index"},"navigationBarBackgroundColor":"#f4f4f4","backgroundColor":"#f4f4f4","navigationBarTitleText":""};
		__wxAppCode__['pages/icall/icall.json'] = {"usingComponents":{"footer":"/components/footer/footer","van-icon":"/components/vant/icon/index","van-steps":"/components/vant/steps/index","van-field":"/components/vant/field/index","van-cell":"/components/vant/cell/index","van-cell-group":"/components/vant/cell-group/index","my-privacy":"/components/privacy/privacy"},"navigationBarTitleText":"位置路径"};
		__wxAppCode__['pages/methodD/methodD.json'] = {"usingComponents":{"my-privacy":"/components/privacy/privacy"},"navigationBarTitleText":""};
		__wxAppCode__['pages/msg/list/list.json'] = {"usingComponents":{"van-button":"/components/vant/button/index","van-popup":"/components/vant/popup/index","van-cell":"/components/vant/cell/index","van-tag":"/components/vant/tag/index","van-action-sheet":"/components/vant/action-sheet/index","van-icon":"/components/vant/icon/index","van-divider":"/components/vant/divider/index","van-loading":"/components/vant/loading/index","van-checkbox":"/components/vant/checkbox/index","van-notice-bar":"/components/vant/notice-bar/index","van-transition":"/components/vant/transition/index","my-privacy":"/components/privacy/privacy","van-sticky":"/components/vant/sticky/index"},"navigationBarTitleText":"","enablePullDownRefresh":true,"navigationBarBackgroundColor":"#ededed"};
		__wxAppCode__['pages/safeIndex/safeIndex.json'] = {"usingComponents":{"van-search":"/components/vant/search/index","van-button":"/components/vant/button/index","my-privacy":"/components/privacy/privacy"},"navigationBarTitleText":"专属电话码"};
		__wxAppCode__['pages/webview/webview.json'] = {"usingComponents":{}};
		__wxAppCode__['pages/work/method.json'] = {"usingComponents":{"van-divider":"/components/vant/divider/index","van-icon":"/components/vant/icon/index","van-dialog":"/components/vant/dialog/index","my-privacy":"/components/privacy/privacy","van-notice-bar":"/components/vant/notice-bar/index"},"navigationBarTitleText":""};
		__wxAppCode__['paste_path_here.json'] = {"usingComponents":{}};
		__wxAppCode__['sc/c.json'] = {"usingComponents":{"my-privacy":"/components/privacy/privacy"},"navigationBarTitleText":"扫码呼叫","disableScroll":true};
	;var __WXML_DEP__=__WXML_DEP__||{};var __wxAppData=__wxAppData||{};var __wxRoute=__wxRoute||"";var __wxRouteBegin=__wxRouteBegin||"";var __wxAppCode__=__wxAppCode__||{};var global=global||{};var __WXML_GLOBAL__=__WXML_GLOBAL__||{entrys:{},defines:{},modules:{},ops:[],wxs_nf_init:undefined,total_ops:0};var __wxAppCurrentFile__=__wxAppCurrentFile__||"";var Component=Component||function(){};var definePlugin=definePlugin||function(){};var requirePlugin=requirePlugin||function(){};var Behavior=Behavior||function(){};var __vd_version_info__=__vd_version_info__||{};var __GWX_GLOBAL__=__GWX_GLOBAL__||{};
/*v0.5vv_20211229_syb_scopedata*/global.__wcc_version__='v0.5vv_20211229_syb_scopedata';global.__wcc_version_info__={"customComponents":true,"fixZeroRpx":true,"propValueDeepCopy":false};
var $gwxc
var $gaic={}
$gwx=function(_,_v,_n,_p,_s,_wp,_wl,$gwn,$gwl,$gwh,wh,$gstack,$gwrt,gra,grb,TestTest,wfor,_ca,_da,_r,_rz,_o,_oz,_1,_1z,_2,_2z,_m,_mz,nv_getDate,nv_getRegExp,nv_console,nv_parseInt,nv_parseFloat,nv_isNaN,nv_isFinite,nv_decodeURI,nv_decodeURIComponent,nv_encodeURI,nv_encodeURIComponent,$gdc,nv_JSON,_af,_gv,_ai,_grp,_gd,_gapi,$ixc,_ic,_w,_ev,_tsd){return function(path,global){
if(typeof global==='undefined'){if (typeof __GWX_GLOBAL__==='undefined')global={};else global=__GWX_GLOBAL__;}if(typeof __WXML_GLOBAL__ === 'undefined') {__WXML_GLOBAL__={};
}__WXML_GLOBAL__.modules = __WXML_GLOBAL__.modules || {};
var e_={}
if(typeof(global.entrys)==='undefined')global.entrys={};e_=global.entrys;
var d_={}
if(typeof(global.defines)==='undefined')global.defines={};d_=global.defines;
var f_={}
if(typeof(global.modules)==='undefined')global.modules={};f_=global.modules || {};
var p_={}
__WXML_GLOBAL__.ops_cached = __WXML_GLOBAL__.ops_cached || {}
__WXML_GLOBAL__.ops_set = __WXML_GLOBAL__.ops_set || {};
__WXML_GLOBAL__.ops_init = __WXML_GLOBAL__.ops_init || {};
var z=__WXML_GLOBAL__.ops_set.$gwx || [];
__WXML_GLOBAL__.ops_set.$gwx=z;
__WXML_GLOBAL__.ops_init.$gwx=true;
var nv_require=function(){var nnm={"m_./components/vant/steps/index.wxml:status":np_1,"m_./pages/file/cloudFile/index.wxml:myutil":np_9,"m_./pages/msg/list/list.wxml:msgutil":np_10,"m_./pages/safeIndex/safeIndex.wxml:safeindexutil":np_11,"m_./pages/work/method.wxml:msgutil":np_12,"m_./sc/c.wxml:myutil":np_13,"p_./components/vant/checkbox/index.wxs":np_0,"p_./components/vant/sticky/index.wxs":np_2,"p_./components/vant/wxs/add-unit.wxs":np_3,"p_./components/vant/wxs/array.wxs":np_4,"p_./components/vant/wxs/bem.wxs":np_5,"p_./components/vant/wxs/memoize.wxs":np_6,"p_./components/vant/wxs/object.wxs":np_7,"p_./components/vant/wxs/utils.wxs":np_8,};var nom={};return function(n){if(n[0]==='p'&&n[1]==='_'&&f_[n.slice(2)])return f_[n.slice(2)];return function(){if(!nnm[n]) return undefined;try{if(!nom[n])nom[n]=nnm[n]();return nom[n];}catch(e){e.message=e.message.replace(/nv_/g,'');var tmp = e.stack.substring(0,e.stack.lastIndexOf(n));e.stack = tmp.substring(0,tmp.lastIndexOf('\n'));e.stack = e.stack.replace(/\snv_/g,' ');e.stack = $gstack(e.stack);e.stack += '\n    at ' + n.substring(2);console.error(e);}
}}}()
f_['./components/vant/action-sheet/index.wxml']={};
f_['./components/vant/action-sheet/index.wxml']['utils'] =f_['./components/vant/wxs/utils.wxs'] || nv_require("p_./components/vant/wxs/utils.wxs");
f_['./components/vant/action-sheet/index.wxml']['utils']();

f_['./components/vant/button/index.wxml']={};
f_['./components/vant/button/index.wxml']['utils'] =f_['./components/vant/wxs/utils.wxs'] || nv_require("p_./components/vant/wxs/utils.wxs");
f_['./components/vant/button/index.wxml']['utils']();

f_['./components/vant/cell/index.wxml']={};
f_['./components/vant/cell/index.wxml']['utils'] =f_['./components/vant/wxs/utils.wxs'] || nv_require("p_./components/vant/wxs/utils.wxs");
f_['./components/vant/cell/index.wxml']['utils']();

f_['./components/vant/checkbox/index.wxml']={};
f_['./components/vant/checkbox/index.wxml']['utils'] =f_['./components/vant/wxs/utils.wxs'] || nv_require("p_./components/vant/wxs/utils.wxs");
f_['./components/vant/checkbox/index.wxml']['utils']();
f_['./components/vant/checkbox/index.wxml']['computed'] =f_['./components/vant/checkbox/index.wxs'] || nv_require("p_./components/vant/checkbox/index.wxs");
f_['./components/vant/checkbox/index.wxml']['computed']();

f_['./components/vant/checkbox/index.wxs'] = nv_require("p_./components/vant/checkbox/index.wxs");
function np_0(){var nv_module={nv_exports:{}};var nv_utils = nv_require('p_./components/vant/wxs/utils.wxs')();function nv_iconStyle(nv_checkedColor,nv_value,nv_disabled,nv_parentDisabled,nv_iconSize){var nv_styles = [['font-size',nv_utils.nv_addUnit(nv_iconSize)]];if (nv_checkedColor && nv_value && !nv_disabled && !nv_parentDisabled){nv_styles.nv_push(['border-color',nv_checkedColor]);nv_styles.nv_push(['background-color',nv_checkedColor])};return(nv_styles.nv_map((function (nv_item){return(nv_item.nv_join(':'))})).nv_join(';'))};nv_module.nv_exports = ({nv_iconStyle:nv_iconStyle,});return nv_module.nv_exports;}

f_['./components/vant/circle/index.wxml']={};
f_['./components/vant/circle/index.wxml']['utils'] =f_['./components/vant/wxs/utils.wxs'] || nv_require("p_./components/vant/wxs/utils.wxs");
f_['./components/vant/circle/index.wxml']['utils']();

f_['./components/vant/dialog/index.wxml']={};
f_['./components/vant/dialog/index.wxml']['utils'] =f_['./components/vant/wxs/utils.wxs'] || nv_require("p_./components/vant/wxs/utils.wxs");
f_['./components/vant/dialog/index.wxml']['utils']();

f_['./components/vant/divider/index.wxml']={};
f_['./components/vant/divider/index.wxml']['utils'] =f_['./components/vant/wxs/utils.wxs'] || nv_require("p_./components/vant/wxs/utils.wxs");
f_['./components/vant/divider/index.wxml']['utils']();

f_['./components/vant/field/index.wxml']={};
f_['./components/vant/field/index.wxml']['utils'] =f_['./components/vant/wxs/utils.wxs'] || nv_require("p_./components/vant/wxs/utils.wxs");
f_['./components/vant/field/index.wxml']['utils']();

f_['./components/vant/goods-action-button/index.wxml']={};
f_['./components/vant/goods-action-button/index.wxml']['utils'] =f_['./components/vant/wxs/utils.wxs'] || nv_require("p_./components/vant/wxs/utils.wxs");
f_['./components/vant/goods-action-button/index.wxml']['utils']();

f_['./components/vant/goods-action/index.wxml']={};
f_['./components/vant/goods-action/index.wxml']['utils'] =f_['./components/vant/wxs/utils.wxs'] || nv_require("p_./components/vant/wxs/utils.wxs");
f_['./components/vant/goods-action/index.wxml']['utils']();

f_['./components/vant/icon/index.wxml']={};
f_['./components/vant/icon/index.wxml']['utils'] =f_['./components/vant/wxs/utils.wxs'] || nv_require("p_./components/vant/wxs/utils.wxs");
f_['./components/vant/icon/index.wxml']['utils']();

f_['./components/vant/info/index.wxml']={};
f_['./components/vant/info/index.wxml']['utils'] =f_['./components/vant/wxs/utils.wxs'] || nv_require("p_./components/vant/wxs/utils.wxs");
f_['./components/vant/info/index.wxml']['utils']();

f_['./components/vant/loading/index.wxml']={};
f_['./components/vant/loading/index.wxml']['utils'] =f_['./components/vant/wxs/utils.wxs'] || nv_require("p_./components/vant/wxs/utils.wxs");
f_['./components/vant/loading/index.wxml']['utils']();

f_['./components/vant/notice-bar/index.wxml']={};
f_['./components/vant/notice-bar/index.wxml']['utils'] =f_['./components/vant/wxs/utils.wxs'] || nv_require("p_./components/vant/wxs/utils.wxs");
f_['./components/vant/notice-bar/index.wxml']['utils']();

f_['./components/vant/popup/index.wxml']={};
f_['./components/vant/popup/index.wxml']['utils'] =f_['./components/vant/wxs/utils.wxs'] || nv_require("p_./components/vant/wxs/utils.wxs");
f_['./components/vant/popup/index.wxml']['utils']();

f_['./components/vant/search/index.wxml']={};
f_['./components/vant/search/index.wxml']['utils'] =f_['./components/vant/wxs/utils.wxs'] || nv_require("p_./components/vant/wxs/utils.wxs");
f_['./components/vant/search/index.wxml']['utils']();

f_['./components/vant/steps/index.wxml']={};
f_['./components/vant/steps/index.wxml']['utils'] =f_['./components/vant/wxs/utils.wxs'] || nv_require("p_./components/vant/wxs/utils.wxs");
f_['./components/vant/steps/index.wxml']['utils']();
f_['./components/vant/steps/index.wxml']['status'] =nv_require("m_./components/vant/steps/index.wxml:status");
function np_1(){var nv_module={nv_exports:{}};function nv_get(nv_index,nv_active){if (nv_index < nv_active){return('finish')} else if (nv_index === nv_active){return('process')};return('inactive')};nv_module.nv_exports = nv_get;return nv_module.nv_exports;}

f_['./components/vant/sticky/index.wxml']={};
f_['./components/vant/sticky/index.wxml']['utils'] =f_['./components/vant/wxs/utils.wxs'] || nv_require("p_./components/vant/wxs/utils.wxs");
f_['./components/vant/sticky/index.wxml']['utils']();
f_['./components/vant/sticky/index.wxml']['computed'] =f_['./components/vant/sticky/index.wxs'] || nv_require("p_./components/vant/sticky/index.wxs");
f_['./components/vant/sticky/index.wxml']['computed']();

f_['./components/vant/sticky/index.wxs'] = nv_require("p_./components/vant/sticky/index.wxs");
function np_2(){var nv_module={nv_exports:{}};function nv_wrapStyle(nv_data){var nv_style = '';if (nv_data.nv_transform){nv_style += 'transform: translate3d(0, ' + nv_data.nv_transform + 'px, 0);'};if (nv_data.nv_fixed){nv_style += 'top: ' + nv_data.nv_offsetTop + 'px;'};if (nv_data.nv_zIndex){nv_style += 'z-index: ' + nv_data.nv_zIndex + ';'};return(nv_style)};function nv_containerStyle(nv_data){var nv_style = '';if (nv_data.nv_fixed){nv_style += 'height: ' + nv_data.nv_height + 'px;'};if (nv_data.nv_zIndex){nv_style += 'z-index: ' + nv_data.nv_zIndex + ';'};return(nv_style)};nv_module.nv_exports = ({nv_wrapStyle:nv_wrapStyle,nv_containerStyle:nv_containerStyle,});return nv_module.nv_exports;}

f_['./components/vant/tag/index.wxml']={};
f_['./components/vant/tag/index.wxml']['utils'] =f_['./components/vant/wxs/utils.wxs'] || nv_require("p_./components/vant/wxs/utils.wxs");
f_['./components/vant/tag/index.wxml']['utils']();

f_['./components/vant/wxs/add-unit.wxs'] = nv_require("p_./components/vant/wxs/add-unit.wxs");
function np_3(){var nv_module={nv_exports:{}};var nv_REGEXP = nv_getRegExp('^\x5cd+(\x5c.\x5cd+)?$');function nv_addUnit(nv_value){if (nv_value == null){return(undefined)};return(nv_REGEXP.nv_test('' + nv_value) ? nv_value + 'px':nv_value)};nv_module.nv_exports = ({nv_addUnit:nv_addUnit,});return nv_module.nv_exports;}

f_['./components/vant/wxs/array.wxs'] = nv_require("p_./components/vant/wxs/array.wxs");
function np_4(){var nv_module={nv_exports:{}};function nv_isArray(nv_array){return(nv_array && nv_array.nv_constructor === 'Array')};nv_module.nv_exports.nv_isArray = nv_isArray;return nv_module.nv_exports;}

f_['./components/vant/wxs/bem.wxs'] = nv_require("p_./components/vant/wxs/bem.wxs");
function np_5(){var nv_module={nv_exports:{}};var nv_array = nv_require('p_./components/vant/wxs/array.wxs')();var nv_object = nv_require('p_./components/vant/wxs/object.wxs')();var nv_PREFIX = 'van-';function nv_join(nv_name,nv_mods){nv_name = nv_PREFIX + nv_name;nv_mods = nv_mods.nv_map((function (nv_mod){return(nv_name + '--' + nv_mod)}));nv_mods.nv_unshift(nv_name);return(nv_mods.nv_join(' '))};function nv_traversing(nv_mods,nv_conf){if (!nv_conf){return};if (typeof nv_conf === 'string' || typeof nv_conf === 'number'){nv_mods.nv_push(nv_conf)} else if (nv_array.nv_isArray(nv_conf)){nv_conf.nv_forEach((function (nv_item){nv_traversing(nv_mods,nv_item)}))} else if (typeof nv_conf === 'object'){nv_object.nv_keys(nv_conf).nv_forEach((function (nv_key){nv_conf[((nt_0=(nv_key),null==nt_0?undefined:'number'=== typeof nt_0?nt_0:"nv_"+nt_0))] && nv_mods.nv_push(nv_key)}))}};function nv_bem(nv_name,nv_conf){var nv_mods = [];nv_traversing(nv_mods,nv_conf);return(nv_join(nv_name,nv_mods))};nv_module.nv_exports.nv_bem = nv_bem;return nv_module.nv_exports;}

f_['./components/vant/wxs/memoize.wxs'] = nv_require("p_./components/vant/wxs/memoize.wxs");
function np_6(){var nv_module={nv_exports:{}};function nv_isPrimitive(nv_value){var nv_type = typeof nv_value;return((nv_type === 'boolean' || nv_type === 'number' || nv_type === 'string' || nv_type === 'undefined' || nv_value === null))};function nv_call(nv_fn,nv_args){if (nv_args.nv_length === 2){return(nv_fn(nv_args[(0)],nv_args[(1)]))};if (nv_args.nv_length === 1){return(nv_fn(nv_args[(0)]))};return(nv_fn())};function nv_serializer(nv_args){if (nv_args.nv_length === 1 && nv_isPrimitive(nv_args[(0)])){return(nv_args[(0)])};var nv_obj = ({});for(var nv_i = 0;nv_i < nv_args.nv_length;nv_i++){nv_obj[((nt_5=('key' + nv_i),null==nt_5?undefined:'number'=== typeof nt_5?nt_5:"nv_"+nt_5))] = nv_args[((nt_6=(nv_i),null==nt_6?undefined:'number'=== typeof nt_6?nt_6:"nv_"+nt_6))]};return(nv_JSON.nv_stringify(nv_obj))};function nv_memoize(nv_fn){arguments.nv_length=arguments.length;var nv_cache = ({});return((function (){arguments.nv_length=arguments.length;var nv_key = nv_serializer(arguments);if (nv_cache[((nt_7=(nv_key),null==nt_7?undefined:'number'=== typeof nt_7?nt_7:"nv_"+nt_7))] === undefined){nv_cache[((nt_8=(nv_key),null==nt_8?undefined:'number'=== typeof nt_8?nt_8:"nv_"+nt_8))] = nv_call(nv_fn,arguments)};return(nv_cache[((nt_9=(nv_key),null==nt_9?undefined:'number'=== typeof nt_9?nt_9:"nv_"+nt_9))])}))};nv_module.nv_exports.nv_memoize = nv_memoize;return nv_module.nv_exports;}

f_['./components/vant/wxs/object.wxs'] = nv_require("p_./components/vant/wxs/object.wxs");
function np_7(){var nv_module={nv_exports:{}};var nv_REGEXP = nv_getRegExp('{|}|\x22','g');function nv_keys(nv_obj){return(nv_JSON.nv_stringify(nv_obj).nv_replace(nv_REGEXP,'').nv_split(',').nv_map((function (nv_item){return(nv_item.nv_split(':')[(0)])})))};nv_module.nv_exports.nv_keys = nv_keys;return nv_module.nv_exports;}

f_['./components/vant/wxs/utils.wxs'] = nv_require("p_./components/vant/wxs/utils.wxs");
function np_8(){var nv_module={nv_exports:{}};var nv_bem = nv_require('p_./components/vant/wxs/bem.wxs')().nv_bem;var nv_memoize = nv_require('p_./components/vant/wxs/memoize.wxs')().nv_memoize;var nv_addUnit = nv_require('p_./components/vant/wxs/add-unit.wxs')().nv_addUnit;nv_module.nv_exports = ({nv_bem:nv_memoize(nv_bem),nv_memoize:nv_memoize,nv_addUnit:nv_addUnit,});return nv_module.nv_exports;}

f_['./pages/file/cloudFile/index.wxml']={};
f_['./pages/file/cloudFile/index.wxml']['myutil'] =nv_require("m_./pages/file/cloudFile/index.wxml:myutil");
function np_9(){var nv_module={nv_exports:{}};var nv_canOpen = (function (nv_fileID){if (nv_fileID){var nv_extension = ["doc","docx","xls","xlsx","ppt","pptx","pdf","DOC","DOCX","XLS","XLSX","PPT","PPTX","PDF"];var nv_index = nv_fileID.nv_lastIndexOf(".");var nv_suffix = nv_fileID.nv_substring(nv_index + 1);if (nv_extension.nv_indexOf(nv_suffix) > -1){return(true)}};return(false)});nv_module.nv_exports = ({nv_canOpen:nv_canOpen,});return nv_module.nv_exports;}

f_['./pages/msg/list/list.wxml']={};
f_['./pages/msg/list/list.wxml']['msgutil'] =nv_require("m_./pages/msg/list/list.wxml:msgutil");
function np_10(){var nv_module={nv_exports:{}};var nv_nameFormat = (function (nv_name,nv_ip_ad_info){var nv_ip = "";var nv_max = 7;if (!nv_ip_ad_info){return(nv_name)};if (nv_name && nv_name.nv_length > nv_max){nv_name = nv_name.nv_substring(0,nv_max) + '...'};if (nv_ip_ad_info){if (nv_ip_ad_info.nv_province){nv_ip = "\x3cspan style\x3d\x27font-size:0.7rem;color:#cccccc;margin-left:0.5rem;\x27\x3eIP:" + nv_ip_ad_info.nv_province + "\x3c/span\x3e"} else if (nv_ip_ad_info.nv_nation){nv_ip = "\x3cspan style\x3d\x27font-size:0.7rem;color:#cccccc;margin-left:0.5rem;\x27\x3eIP:" + nv_ip_ad_info.nv_nation + "\x3c/span\x3e"}};return(nv_name + nv_ip)});var nv_compareVersion = (function (nv_v1,nv_v2){nv_v1 = nv_v1.nv_split('.');nv_v2 = nv_v2.nv_split('.');var nv_len = Math.nv_max(nv_v1.nv_length,nv_v2.nv_length);while(nv_v1.nv_length < nv_len){nv_v1.nv_push('0')};while(nv_v2.nv_length < nv_len){nv_v2.nv_push('0')};for(var nv_i = 0;nv_i < nv_len;nv_i++){var nv_num1 = nv_parseInt(nv_v1[((nt_0=(nv_i),null==nt_0?undefined:'number'=== typeof nt_0?nt_0:"nv_"+nt_0))]);var nv_num2 = nv_parseInt(nv_v2[((nt_1=(nv_i),null==nt_1?undefined:'number'=== typeof nt_1?nt_1:"nv_"+nt_1))]);if (nv_num1 > nv_num2){return(1)} else if (nv_num1 < nv_num2){return(-1)}};return(0)});var nv_avatarUrlFormat = (function (nv_avatarUrl){if (nv_avatarUrl && nv_avatarUrl.nv_indexOf('cloud://') == -1 && nv_avatarUrl.nv_indexOf('http') == -1){return("https://" + nv_avatarUrl)};return(nv_avatarUrl)});nv_module.nv_exports = ({nv_nameFormat:nv_nameFormat,nv_compareVersion:nv_compareVersion,nv_avatarUrlFormat:nv_avatarUrlFormat,});return nv_module.nv_exports;}

f_['./pages/safeIndex/safeIndex.wxml']={};
f_['./pages/safeIndex/safeIndex.wxml']['safeindexutil'] =nv_require("m_./pages/safeIndex/safeIndex.wxml:safeindexutil");
function np_11(){var nv_module={nv_exports:{}};var nv_idHide = (function (nv_id){if (nv_id && nv_id.nv_length > 12){var nv_idArr = nv_toCharArray(nv_id);var nv_starCount = 0;for(var nv_i = 0;nv_i < nv_id.nv_length;nv_i++){if (nv_i >= 4 && nv_i < nv_id.nv_length - 4){nv_starCount++;nv_idArr[((nt_0=(nv_i),null==nt_0?undefined:'number'=== typeof nt_0?nt_0:"nv_"+nt_0))] = '*';if (nv_starCount > 4){nv_idArr[((nt_1=(nv_i),null==nt_1?undefined:'number'=== typeof nt_1?nt_1:"nv_"+nt_1))] = ''}}};nv_id = nv_idArr.nv_join("")};return(nv_id)});var nv_phoneFormat = (function (nv_phone){if (nv_phone){return(nv_phone.nv_substring(0,3) + "****" + nv_phone.nv_substring(nv_phone.nv_length - 4))};return(nv_phone)});function nv_toCharArray(nv_str){nv_charArray = [];for(var nv_i = 0;nv_i < nv_str.nv_length;nv_i++){nv_charArray.nv_push(nv_str[((nt_2=(nv_i),null==nt_2?undefined:'number'=== typeof nt_2?nt_2:"nv_"+nt_2))])};return(nv_charArray)};nv_module.nv_exports = ({nv_idHide:nv_idHide,nv_phoneFormat:nv_phoneFormat,});return nv_module.nv_exports;}

f_['./pages/work/method.wxml']={};
f_['./pages/work/method.wxml']['msgutil'] =nv_require("m_./pages/work/method.wxml:msgutil");
function np_12(){var nv_module={nv_exports:{}};var nv_avatarUrlFormat = (function (nv_avatarUrl){if (nv_avatarUrl && nv_avatarUrl.nv_indexOf('cloud://') == -1 && nv_avatarUrl.nv_indexOf('http') == -1){return("https://" + nv_avatarUrl)};return(nv_avatarUrl)});var nv_telFormat = (function (nv_tel){return(nv_tel.nv_substring(0,3) + "****" + nv_tel.nv_substring(nv_tel.nv_length - 4))});var nv_compareVersion = (function (nv_v1,nv_v2){nv_v1 = nv_v1.nv_split('.');nv_v2 = nv_v2.nv_split('.');var nv_len = Math.nv_max(nv_v1.nv_length,nv_v2.nv_length);while(nv_v1.nv_length < nv_len){nv_v1.nv_push('0')};while(nv_v2.nv_length < nv_len){nv_v2.nv_push('0')};for(var nv_i = 0;nv_i < nv_len;nv_i++){var nv_num1 = nv_parseInt(nv_v1[((nt_0=(nv_i),null==nt_0?undefined:'number'=== typeof nt_0?nt_0:"nv_"+nt_0))]);var nv_num2 = nv_parseInt(nv_v2[((nt_1=(nv_i),null==nt_1?undefined:'number'=== typeof nt_1?nt_1:"nv_"+nt_1))]);if (nv_num1 > nv_num2){return(1)} else if (nv_num1 < nv_num2){return(-1)}};return(0)});nv_module.nv_exports = ({nv_avatarUrlFormat:nv_avatarUrlFormat,nv_compareVersion:nv_compareVersion,nv_telFormat:nv_telFormat,});return nv_module.nv_exports;}

f_['./sc/c.wxml']={};
f_['./sc/c.wxml']['myutil'] =nv_require("m_./sc/c.wxml:myutil");
function np_13(){var nv_module={nv_exports:{}};var nv_phoneFormat = (function (nv_phone){if (nv_phone){return(nv_phone.nv_substring(0,3) + "****" + nv_phone.nv_substring(nv_phone.nv_length - 4))};return(nv_phone)});nv_module.nv_exports = ({nv_phoneFormat:nv_phoneFormat,});return nv_module.nv_exports;}

var x=[];if(path&&e_[path]){
return function(env,dd,global){$gwxc=0;var root={"tag":"wx-page"};root.children=[]
;g="$gwx";var main=e_[path].f
if (typeof global==="undefined")global={};global.f=$gdc(f_[path],"",1);
try{
main(env,{},root,global);
_tsd(root)
}catch(err){
console.log(err)
}
;g="";
return root;
}
}
}
}(__g.a,__g.b,__g.c,__g.d,__g.e,__g.f,__g.g,__g.h,__g.i,__g.j,__g.k,__g.l,__g.m,__g.n,__g.o,__g.p,__g.q,__g.r,__g.s,__g.t,__g.u,__g.v,__g.w,__g.x,__g.y,__g.z,__g.A,__g.B,__g.C,__g.D,__g.E,__g.F,__g.G,__g.H,__g.I,__g.J,__g.K,__g.L,__g.M,__g.N,__g.O,__g.P,__g.Q,__g.R,__g.S,__g.T,__g.U,__g.V,__g.W,__g.X,__g.Y,__g.Z,__g.aa);if(__vd_version_info__.delayedGwx||true)$gwx();;__wxRoute = undefined;__wxRouteBegin = undefined;__wxAppCurrentFile__=undefined;define("@babel/runtime/helpers/arrayLikeToArray.js",function(require,module,exports,window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){
function _arrayLikeToArray(r,a){(null==a||a>r.length)&&(a=r.length);for(var e=0,n=new Array(a);e<a;e++)n[e]=r[e];return n}module.exports=_arrayLikeToArray;
},{isPage:false,isComponent:false,currentFile:'@babel/runtime/helpers/arrayLikeToArray.js'});;__wxRoute = undefined;__wxRouteBegin = undefined;__wxAppCurrentFile__=undefined;define("@babel/runtime/helpers/arrayWithHoles.js",function(require,module,exports,window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){
function _arrayWithHoles(r){if(Array.isArray(r))return r}module.exports=_arrayWithHoles;
},{isPage:false,isComponent:false,currentFile:'@babel/runtime/helpers/arrayWithHoles.js'});;__wxRoute = undefined;__wxRouteBegin = undefined;__wxAppCurrentFile__=undefined;define("@babel/runtime/helpers/asyncToGenerator.js",function(require,module,exports,window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){
function asyncGeneratorStep(n,e,r,t,o,a,c){try{var i=n[a](c),u=i.value}catch(n){return void r(n)}i.done?e(u):Promise.resolve(u).then(t,o)}function _asyncToGenerator(n){return function(){var e=this,r=arguments;return new Promise((function(t,o){var a=n.apply(e,r);function c(n){asyncGeneratorStep(a,t,o,c,i,"next",n)}function i(n){asyncGeneratorStep(a,t,o,c,i,"throw",n)}c(void 0)}))}}module.exports=_asyncToGenerator;
},{isPage:false,isComponent:false,currentFile:'@babel/runtime/helpers/asyncToGenerator.js'});;__wxRoute = undefined;__wxRouteBegin = undefined;__wxAppCurrentFile__=undefined;define("@babel/runtime/helpers/classCallCheck.js",function(require,module,exports,window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){
function _classCallCheck(a,l){if(!(a instanceof l))throw new TypeError("Cannot call a class as a function")}module.exports=_classCallCheck;
},{isPage:false,isComponent:false,currentFile:'@babel/runtime/helpers/classCallCheck.js'});;__wxRoute = undefined;__wxRouteBegin = undefined;__wxAppCurrentFile__=undefined;define("@babel/runtime/helpers/createClass.js",function(require,module,exports,window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){
var toPropertyKey=require("./toPropertyKey");function _defineProperties(e,r){for(var t=0;t<r.length;t++){var o=r[t];o.enumerable=o.enumerable||!1,o.configurable=!0,"value"in o&&(o.writable=!0),Object.defineProperty(e,toPropertyKey(o.key),o)}}function _createClass(e,r,t){return r&&_defineProperties(e.prototype,r),t&&_defineProperties(e,t),Object.defineProperty(e,"prototype",{writable:!1}),e}module.exports=_createClass;
},{isPage:false,isComponent:false,currentFile:'@babel/runtime/helpers/createClass.js'});;__wxRoute = undefined;__wxRouteBegin = undefined;__wxAppCurrentFile__=undefined;define("@babel/runtime/helpers/defineProperty.js",function(require,module,exports,window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){
var toPropertyKey=require("./toPropertyKey");function _defineProperty(e,r,t){return(r=toPropertyKey(r))in e?Object.defineProperty(e,r,{value:t,enumerable:!0,configurable:!0,writable:!0}):e[r]=t,e}module.exports=_defineProperty;
},{isPage:false,isComponent:false,currentFile:'@babel/runtime/helpers/defineProperty.js'});;__wxRoute = undefined;__wxRouteBegin = undefined;__wxAppCurrentFile__=undefined;define("@babel/runtime/helpers/iterableToArrayLimit.js",function(require,module,exports,window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){
function _iterableToArrayLimit(r,e){var l=null==r?null:"undefined"!=typeof Symbol&&r[Symbol.iterator]||r["@@iterator"];if(null!=l){var t,n,i,a,u=[],o=!0,f=!1;try{if(i=(l=l.call(r)).next,0===e){if(Object(l)!==l)return;o=!1}else for(;!(o=(t=i.call(l)).done)&&(u.push(t.value),u.length!==e);o=!0);}catch(r){f=!0,n=r}finally{try{if(!o&&null!=l.return&&(a=l.return(),Object(a)!==a))return}finally{if(f)throw n}}return u}}module.exports=_iterableToArrayLimit;
},{isPage:false,isComponent:false,currentFile:'@babel/runtime/helpers/iterableToArrayLimit.js'});;__wxRoute = undefined;__wxRouteBegin = undefined;__wxAppCurrentFile__=undefined;define("@babel/runtime/helpers/nonIterableRest.js",function(require,module,exports,window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){
function _nonIterableRest(){throw new TypeError("Invalid attempt to destructure non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.")}module.exports=_nonIterableRest;
},{isPage:false,isComponent:false,currentFile:'@babel/runtime/helpers/nonIterableRest.js'});;__wxRoute = undefined;__wxRouteBegin = undefined;__wxAppCurrentFile__=undefined;define("@babel/runtime/helpers/objectSpread2.js",function(require,module,exports,window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){
var defineProperty=require("./defineProperty");function ownKeys(e,r){var t=Object.keys(e);if(Object.getOwnPropertySymbols){var o=Object.getOwnPropertySymbols(e);r&&(o=o.filter((function(r){return Object.getOwnPropertyDescriptor(e,r).enumerable}))),t.push.apply(t,o)}return t}function _objectSpread2(e){for(var r=1;r<arguments.length;r++){var t=null!=arguments[r]?arguments[r]:{};r%2?ownKeys(Object(t),!0).forEach((function(r){defineProperty(e,r,t[r])})):Object.getOwnPropertyDescriptors?Object.defineProperties(e,Object.getOwnPropertyDescriptors(t)):ownKeys(Object(t)).forEach((function(r){Object.defineProperty(e,r,Object.getOwnPropertyDescriptor(t,r))}))}return e}module.exports=_objectSpread2;
},{isPage:false,isComponent:false,currentFile:'@babel/runtime/helpers/objectSpread2.js'});;__wxRoute = undefined;__wxRouteBegin = undefined;__wxAppCurrentFile__=undefined;define("@babel/runtime/helpers/regeneratorRuntime.js",function(require,module,exports,window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){
var t=require("./typeof");function r(){module.exports=r=function(){return e},module.exports.__esModule=!0,module.exports.default=module.exports;var e={},n=Object.prototype,o=n.hasOwnProperty,i=Object.defineProperty||function(t,r,e){t[r]=e.value},a="function"==typeof Symbol?Symbol:{},c=a.iterator||"@@iterator",u=a.asyncIterator||"@@asyncIterator",l=a.toStringTag||"@@toStringTag";function h(t,r,e){return Object.defineProperty(t,r,{value:e,enumerable:!0,configurable:!0,writable:!0}),t[r]}try{h({},"")}catch(t){h=function(t,r,e){return t[r]=e}}function f(t,r,e,n){var o=r&&r.prototype instanceof d?r:d,a=Object.create(o.prototype),c=new k(n||[]);return i(a,"_invoke",{value:E(t,e,c)}),a}function s(t,r,e){try{return{type:"normal",arg:t.call(r,e)}}catch(t){return{type:"throw",arg:t}}}e.wrap=f;var p={};function d(){}function v(){}function y(){}var g={};h(g,c,(function(){return this}));var m=Object.getPrototypeOf,w=m&&m(m(G([])));w&&w!==n&&o.call(w,c)&&(g=w);var x=y.prototype=d.prototype=Object.create(g);function L(t){["next","throw","return"].forEach((function(r){h(t,r,(function(t){return this._invoke(r,t)}))}))}function b(r,e){function n(i,a,c,u){var l=s(r[i],r,a);if("throw"!==l.type){var h=l.arg,f=h.value;return f&&"object"==t(f)&&o.call(f,"__await")?e.resolve(f.__await).then((function(t){n("next",t,c,u)}),(function(t){n("throw",t,c,u)})):e.resolve(f).then((function(t){h.value=t,c(h)}),(function(t){return n("throw",t,c,u)}))}u(l.arg)}var a;i(this,"_invoke",{value:function(t,r){function o(){return new e((function(e,o){n(t,r,e,o)}))}return a=a?a.then(o,o):o()}})}function E(t,r,e){var n="suspendedStart";return function(o,i){if("executing"===n)throw new Error("Generator is already running");if("completed"===n){if("throw"===o)throw i;return N()}for(e.method=o,e.arg=i;;){var a=e.delegate;if(a){var c=_(a,e);if(c){if(c===p)continue;return c}}if("next"===e.method)e.sent=e._sent=e.arg;else if("throw"===e.method){if("suspendedStart"===n)throw n="completed",e.arg;e.dispatchException(e.arg)}else"return"===e.method&&e.abrupt("return",e.arg);n="executing";var u=s(t,r,e);if("normal"===u.type){if(n=e.done?"completed":"suspendedYield",u.arg===p)continue;return{value:u.arg,done:e.done}}"throw"===u.type&&(n="completed",e.method="throw",e.arg=u.arg)}}}function _(t,r){var e=r.method,n=t.iterator[e];if(void 0===n)return r.delegate=null,"throw"===e&&t.iterator.return&&(r.method="return",r.arg=void 0,_(t,r),"throw"===r.method)||"return"!==e&&(r.method="throw",r.arg=new TypeError("The iterator does not provide a '"+e+"' method")),p;var o=s(n,t.iterator,r.arg);if("throw"===o.type)return r.method="throw",r.arg=o.arg,r.delegate=null,p;var i=o.arg;return i?i.done?(r[t.resultName]=i.value,r.next=t.nextLoc,"return"!==r.method&&(r.method="next",r.arg=void 0),r.delegate=null,p):i:(r.method="throw",r.arg=new TypeError("iterator result is not an object"),r.delegate=null,p)}function O(t){var r={tryLoc:t[0]};1 in t&&(r.catchLoc=t[1]),2 in t&&(r.finallyLoc=t[2],r.afterLoc=t[3]),this.tryEntries.push(r)}function j(t){var r=t.completion||{};r.type="normal",delete r.arg,t.completion=r}function k(t){this.tryEntries=[{tryLoc:"root"}],t.forEach(O,this),this.reset(!0)}function G(t){if(t){var r=t[c];if(r)return r.call(t);if("function"==typeof t.next)return t;if(!isNaN(t.length)){var e=-1,n=function r(){for(;++e<t.length;)if(o.call(t,e))return r.value=t[e],r.done=!1,r;return r.value=void 0,r.done=!0,r};return n.next=n}}return{next:N}}function N(){return{value:void 0,done:!0}}return v.prototype=y,i(x,"constructor",{value:y,configurable:!0}),i(y,"constructor",{value:v,configurable:!0}),v.displayName=h(y,l,"GeneratorFunction"),e.isGeneratorFunction=function(t){var r="function"==typeof t&&t.constructor;return!!r&&(r===v||"GeneratorFunction"===(r.displayName||r.name))},e.mark=function(t){return Object.setPrototypeOf?Object.setPrototypeOf(t,y):(t.__proto__=y,h(t,l,"GeneratorFunction")),t.prototype=Object.create(x),t},e.awrap=function(t){return{__await:t}},L(b.prototype),h(b.prototype,u,(function(){return this})),e.AsyncIterator=b,e.async=function(t,r,n,o,i){void 0===i&&(i=Promise);var a=new b(f(t,r,n,o),i);return e.isGeneratorFunction(r)?a:a.next().then((function(t){return t.done?t.value:a.next()}))},L(x),h(x,l,"Generator"),h(x,c,(function(){return this})),h(x,"toString",(function(){return"[object Generator]"})),e.keys=function(t){var r=Object(t),e=[];for(var n in r)e.push(n);return e.reverse(),function t(){for(;e.length;){var n=e.pop();if(n in r)return t.value=n,t.done=!1,t}return t.done=!0,t}},e.values=G,k.prototype={constructor:k,reset:function(t){if(this.prev=0,this.next=0,this.sent=this._sent=void 0,this.done=!1,this.delegate=null,this.method="next",this.arg=void 0,this.tryEntries.forEach(j),!t)for(var r in this)"t"===r.charAt(0)&&o.call(this,r)&&!isNaN(+r.slice(1))&&(this[r]=void 0)},stop:function(){this.done=!0;var t=this.tryEntries[0].completion;if("throw"===t.type)throw t.arg;return this.rval},dispatchException:function(t){if(this.done)throw t;var r=this;function e(e,n){return a.type="throw",a.arg=t,r.next=e,n&&(r.method="next",r.arg=void 0),!!n}for(var n=this.tryEntries.length-1;n>=0;--n){var i=this.tryEntries[n],a=i.completion;if("root"===i.tryLoc)return e("end");if(i.tryLoc<=this.prev){var c=o.call(i,"catchLoc"),u=o.call(i,"finallyLoc");if(c&&u){if(this.prev<i.catchLoc)return e(i.catchLoc,!0);if(this.prev<i.finallyLoc)return e(i.finallyLoc)}else if(c){if(this.prev<i.catchLoc)return e(i.catchLoc,!0)}else{if(!u)throw new Error("try statement without catch or finally");if(this.prev<i.finallyLoc)return e(i.finallyLoc)}}}},abrupt:function(t,r){for(var e=this.tryEntries.length-1;e>=0;--e){var n=this.tryEntries[e];if(n.tryLoc<=this.prev&&o.call(n,"finallyLoc")&&this.prev<n.finallyLoc){var i=n;break}}i&&("break"===t||"continue"===t)&&i.tryLoc<=r&&r<=i.finallyLoc&&(i=null);var a=i?i.completion:{};return a.type=t,a.arg=r,i?(this.method="next",this.next=i.finallyLoc,p):this.complete(a)},complete:function(t,r){if("throw"===t.type)throw t.arg;return"break"===t.type||"continue"===t.type?this.next=t.arg:"return"===t.type?(this.rval=this.arg=t.arg,this.method="return",this.next="end"):"normal"===t.type&&r&&(this.next=r),p},finish:function(t){for(var r=this.tryEntries.length-1;r>=0;--r){var e=this.tryEntries[r];if(e.finallyLoc===t)return this.complete(e.completion,e.afterLoc),j(e),p}},catch:function(t){for(var r=this.tryEntries.length-1;r>=0;--r){var e=this.tryEntries[r];if(e.tryLoc===t){var n=e.completion;if("throw"===n.type){var o=n.arg;j(e)}return o}}throw new Error("illegal catch attempt")},delegateYield:function(t,r,e){return this.delegate={iterator:G(t),resultName:r,nextLoc:e},"next"===this.method&&(this.arg=void 0),p}},e}module.exports=r,module.exports.__esModule=!0,module.exports.default=module.exports;

},{isPage:false,isComponent:false,currentFile:'@babel/runtime/helpers/regeneratorRuntime.js'});;__wxRoute = undefined;__wxRouteBegin = undefined;__wxAppCurrentFile__=undefined;define("@babel/runtime/helpers/slicedToArray.js",function(require,module,exports,window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){
var arrayWithHoles=require("./arrayWithHoles"),iterableToArrayLimit=require("./iterableToArrayLimit"),unsupportedIterableToArray=require("./unsupportedIterableToArray"),nonIterableRest=require("./nonIterableRest");function _slicedToArray(r,e){return arrayWithHoles(r)||iterableToArrayLimit(r,e)||unsupportedIterableToArray(r,e)||nonIterableRest()}module.exports=_slicedToArray;
},{isPage:false,isComponent:false,currentFile:'@babel/runtime/helpers/slicedToArray.js'});;__wxRoute = undefined;__wxRouteBegin = undefined;__wxAppCurrentFile__=undefined;define("@babel/runtime/helpers/toPrimitive.js",function(require,module,exports,window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){
var _typeof=require("./typeof");function _toPrimitive(r,t){if("object"!==_typeof(r)||null===r)return r;var e=r[Symbol.toPrimitive];if(void 0!==e){var i=e.call(r,t||"default");if("object"!==_typeof(i))return i;throw new TypeError("@@toPrimitive must return a primitive value.")}return("string"===t?String:Number)(r)}module.exports=_toPrimitive;
},{isPage:false,isComponent:false,currentFile:'@babel/runtime/helpers/toPrimitive.js'});;__wxRoute = undefined;__wxRouteBegin = undefined;__wxAppCurrentFile__=undefined;define("@babel/runtime/helpers/toPropertyKey.js",function(require,module,exports,window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){
var _typeof=require("./typeof"),toPrimitive=require("./toPrimitive");function _toPropertyKey(r){var t=toPrimitive(r,"string");return"symbol"===_typeof(t)?t:String(t)}module.exports=_toPropertyKey;
},{isPage:false,isComponent:false,currentFile:'@babel/runtime/helpers/toPropertyKey.js'});;__wxRoute = undefined;__wxRouteBegin = undefined;__wxAppCurrentFile__=undefined;define("@babel/runtime/helpers/typeof.js",function(require,module,exports,window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){
function _typeof(o){return module.exports=_typeof="function"==typeof Symbol&&"symbol"==typeof Symbol.iterator?function(o){return typeof o}:function(o){return o&&"function"==typeof Symbol&&o.constructor===Symbol&&o!==Symbol.prototype?"symbol":typeof o},_typeof(o)}module.exports=_typeof;
},{isPage:false,isComponent:false,currentFile:'@babel/runtime/helpers/typeof.js'});;__wxRoute = undefined;__wxRouteBegin = undefined;__wxAppCurrentFile__=undefined;define("@babel/runtime/helpers/unsupportedIterableToArray.js",function(require,module,exports,window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){
var arrayLikeToArray=require("./arrayLikeToArray");function _unsupportedIterableToArray(r,e){if(r){if("string"==typeof r)return arrayLikeToArray(r,e);var t=Object.prototype.toString.call(r).slice(8,-1);return"Object"===t&&r.constructor&&(t=r.constructor.name),"Map"===t||"Set"===t?Array.from(r):"Arguments"===t||/^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(t)?arrayLikeToArray(r,e):void 0}}module.exports=_unsupportedIterableToArray;
},{isPage:false,isComponent:false,currentFile:'@babel/runtime/helpers/unsupportedIterableToArray.js'});;__wxRoute = undefined;__wxRouteBegin = undefined;__wxAppCurrentFile__=undefined;define("components/cos/cos-wx-sdk-v5.min.js",function(require,module,exports,window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){
"use strict";var _typeof3=require("../../@babel/runtime/helpers/typeof"),e,t;e="undefined"!=typeof self?self:void 0,t=function(){return function(e){function t(i){if(n[i])return n[i].exports;var a=n[i]={i:i,l:!1,exports:{}};return e[i].call(a.exports,a,a.exports,t),a.l=!0,a.exports}var n={};return t.m=e,t.c=n,t.d=function(e,n,i){t.o(e,n)||Object.defineProperty(e,n,{configurable:!1,enumerable:!0,get:i})},t.n=function(e){var n=e&&e.__esModule?function(){return e.default}:function(){return e};return t.d(n,"a",n),n},t.o=function(e,t){return Object.prototype.hasOwnProperty.call(e,t)},t.p="/Users/tianfeng/Documents/项目/sdk/cos-wx-sdk-v5/demo/lib",t(t.s=7)}([function(e,t,n){(function(t){function i(e){return encodeURIComponent(e).replace(/!/g,"%21").replace(/'/g,"%27").replace(/\(/g,"%28").replace(/\)/g,"%29").replace(/\*/g,"%2A")}function a(e,t){var n=[];for(var a in e)e.hasOwnProperty(a)&&n.push(t?i(a).toLowerCase():a);return n.sort((function(e,t){return(e=e.toLowerCase())===(t=t.toLowerCase())?0:e>t?1:-1}))}function o(e){return l(e,(function(e){return"object"===(void 0===e?"undefined":p(e))&&null!==e?o(e):e}))}function r(e,t){return c(t,(function(n,i){e[i]=t[i]})),e}function s(e){return e instanceof Array}function c(e,t){for(var n in e)e.hasOwnProperty(n)&&t(e[n],n)}function l(e,t){var n=s(e)?[]:{};for(var i in e)e.hasOwnProperty(i)&&(n[i]=t(e[i],i));return n}var p="function"==typeof Symbol&&"symbol"==_typeof3(Symbol.iterator)?function(e){return _typeof3(e)}:function(e){return e&&"function"==typeof Symbol&&e.constructor===Symbol&&e!==Symbol.prototype?"symbol":_typeof3(e)},u=n(9),d=n(13),m=n(14),f=n(19),h=n(4).btoa,g=wx.getFileSystemManager(),v=["content-disposition","content-encoding","content-length","content-md5","expect","expires","host","if-match","if-modified-since","if-none-match","if-unmodified-since","origin","range","response-cache-control","response-content-disposition","response-content-encoding","response-content-language","response-content-type","response-expires","transfer-encoding","versionid"],x=function(e){var t={};for(var n in e){var i=n.toLowerCase();(i.indexOf("x-cos-")>-1||v.indexOf(i)>-1)&&(t[n]=e[n])}return t},y=function(){},b=function(e){var t={};for(var n in e)e.hasOwnProperty(n)&&void 0!==e[n]&&null!==e[n]&&(t[n]=e[n]);return t},k=function(e,t){if(t=r({},t),"getAuth"!==e&&"getV4Auth"!==e&&"getObjectUrl"!==e){var n=t.Headers||{};t&&"object"===(void 0===t?"undefined":p(t))&&(!function(){for(var e in t)t.hasOwnProperty(e)&&e.indexOf("x-cos-")>-1&&(n[e]=t[e])}(),A.each({"x-cos-mfa":"MFA","Content-MD5":"ContentMD5","Content-Length":"ContentLength","Content-Type":"ContentType",Expect:"Expect",Expires:"Expires","Cache-Control":"CacheControl","Content-Disposition":"ContentDisposition","Content-Encoding":"ContentEncoding",Range:"Range","If-Modified-Since":"IfModifiedSince","If-Unmodified-Since":"IfUnmodifiedSince","If-Match":"IfMatch","If-None-Match":"IfNoneMatch","x-cos-copy-source":"CopySource","x-cos-copy-source-Range":"CopySourceRange","x-cos-metadata-directive":"MetadataDirective","x-cos-copy-source-If-Modified-Since":"CopySourceIfModifiedSince","x-cos-copy-source-If-Unmodified-Since":"CopySourceIfUnmodifiedSince","x-cos-copy-source-If-Match":"CopySourceIfMatch","x-cos-copy-source-If-None-Match":"CopySourceIfNoneMatch","x-cos-acl":"ACL","x-cos-grant-read":"GrantRead","x-cos-grant-write":"GrantWrite","x-cos-grant-full-control":"GrantFullControl","x-cos-grant-read-acp":"GrantReadAcp","x-cos-grant-write-acp":"GrantWriteAcp","x-cos-storage-class":"StorageClass","x-cos-server-side-encryption-customer-algorithm":"SSECustomerAlgorithm","x-cos-server-side-encryption-customer-key":"SSECustomerKey","x-cos-server-side-encryption-customer-key-MD5":"SSECustomerKeyMD5","x-cos-server-side-encryption":"ServerSideEncryption","x-cos-server-side-encryption-cos-kms-key-id":"SSEKMSKeyId","x-cos-server-side-encryption-context":"SSEContext"},(function(e,i){void 0!==t[e]&&(n[i]=t[e])})),t.Headers=b(n))}return t},C=function(e){return Date.now()+(e||0)},S=function(e,t){e=e.split("."),t=t.split(".");for(var n=Math.max(e.length,t.length);e.length<n;)e.push("0");for(;t.length<n;)t.push("0");for(var i=0;i<n;i++){var a=parseInt(e[i]),o=parseInt(t[i]);if(a>o)return 1;if(a<o)return-1}return 0},R=function(){var e=wx.getSystemInfoSync(),t=S(e.SDKVersion,"2.10.0")>=0,n=!t&&"devtools"===e.platform;return function(){return n&&console.warn("当前小程序版本小于 2.10.0，不支持分片上传，请更新软件。"),n=!1,t}}(),A={noop:y,formatParams:k,apiWrapper:function(e,n){return function(i,a){var o=this;"function"==typeof i&&(a=i,i={}),i=k(e,i);var r=function(e){return e&&e.headers&&(e.headers["x-cos-request-id"]&&(e.RequestId=e.headers["x-cos-request-id"]),e.headers["x-ci-request-id"]&&(e.RequestId=e.headers["x-ci-request-id"]),e.headers["x-cos-version-id"]&&(e.VersionId=e.headers["x-cos-version-id"]),e.headers["x-cos-delete-marker"]&&(e.DeleteMarker=e.headers["x-cos-delete-marker"])),e},s=function(e,t){a&&a(r(e),r(t))},c=function(){if("getService"!==e&&"abortUploadTask"!==e){var t=function(e,t){var n=t.Bucket,i=t.Region,a=t.Key;if(e.indexOf("Bucket")>-1||"deleteMultipleObject"===e||"multipartList"===e||"listObjectVersions"===e){if(!n)return"Bucket";if(!i)return"Region"}else if(e.indexOf("Object")>-1||e.indexOf("multipart")>-1||"sliceUploadFile"===e||"abortUploadTask"===e){if(!n)return"Bucket";if(!i)return"Region";if(!a)return"Key"}return!1}(e,i);if(t)return"missing param "+t;if(i.Region){if(i.Region.indexOf("cos.")>-1)return'param Region should not be start with "cos."';if(!/^([a-z\d-]+)$/.test(i.Region))return"Region format error.";o.options.CompatibilityMode||-1!==i.Region.indexOf("-")||"yfb"===i.Region||"default"===i.Region||"accelerate"===i.Region||console.warn("warning: param Region format error, find help here: https://cloud.tencent.com/document/product/436/6224")}if(i.Bucket){if(!/^([a-z\d-]+)-(\d+)$/.test(i.Bucket))if(i.AppId)i.Bucket=i.Bucket+"-"+i.AppId;else{if(!o.options.AppId)return'Bucket should format as "test-1250000000".';i.Bucket=i.Bucket+"-"+o.options.AppId}i.AppId&&(console.warn('warning: AppId has been deprecated, Please put it at the end of parameter Bucket(E.g Bucket:"test-1250000000" ).'),delete i.AppId)}i.Key&&"/"===i.Key.substr(0,1)&&(i.Key=i.Key.substr(1))}}(),l="getAuth"===e||"getObjectUrl"===e,p=t.Promise;if(!l&&p&&!a)return new p((function(e,t){if(a=function(n,i){n?t(n):e(i)},c)return s({error:c});n.call(o,i,s)}));if(c)return s({error:c});var u=n.call(o,i,s);return l?u:void 0}},xml2json:m,json2xml:f,md5:u,clearKey:b,fileSlice:function(e,t,n,i){e?g.readFile({filePath:e,position:t,length:n-t,success:function(e){i(e.data)},fail:function(){i(null)}}):i(null)},getBodyMd5:function(e,t,n){n=n||y,e&&t&&t instanceof ArrayBuffer?A.getFileMd5(t,(function(e,t){n(t)})):n()},getFileMd5:function(e,t){var n=u(e);return t&&t(n),n},binaryBase64:function(e){var t,n,i,a="";for(t=0,n=e.length/2;t<n;t++)i=parseInt(e[2*t]+e[2*t+1],16),a+=String.fromCharCode(i);return h(a)},extend:r,isArray:s,isInArray:function(e,t){for(var n=!1,i=0;i<e.length;i++)if(t===e[i]){n=!0;break}return n},makeArray:function(e){return s(e)?e:[e]},each:c,map:l,filter:function(e,t){var n=s(e),i=n?[]:{};for(var a in e)e.hasOwnProperty(a)&&t(e[a],a)&&(n?i.push(e[a]):i[a]=e[a]);return i},clone:o,attr:function(e,t,n){return e&&t in e?e[t]:n},uuid:function(){var e=function(){return(65536*(1+Math.random())|0).toString(16).substring(1)};return e()+e()+"-"+e()+"-"+e()+"-"+e()+"-"+e()+e()+e()},camSafeUrlEncode:i,throttleOnProgress:function(e,t){function n(){if(a=0,t&&"function"==typeof t){i=Date.now();var n,o=Math.max(0,Math.round((s-r)/((i-c)/1e3)*100)/100)||0;n=0===s&&0===e?1:Math.floor(s/e*100)/100||0,c=i,r=s;try{t({loaded:s,total:e,speed:o,percent:n})}catch(e){}}}var i,a,o=this,r=0,s=0,c=Date.now();return function(t,i){if(t&&(s=t.loaded,e=t.total),i)clearTimeout(a),n();else{if(a)return;a=setTimeout(n,o.options.ProgressInterval)}}},getFileSize:function(e,t,n){"postObject"===e?n():"putObject"===e?void 0!==t.Body?(t.ContentLength=t.Body.byteLength,n(null,t.ContentLength)):n({error:"missing param Body"}):t.FilePath?g.stat({path:t.FilePath,success:function(e){var i=e.stats;t.FileStat=i,t.FileStat.FilePath=t.FilePath;var a=i.isDirectory()?0:i.size;t.ContentLength=a=a||0,n(null,a)},fail:function(e){n(e)}}):n({error:"missing param FilePath"})},getSkewTime:C,obj2str:function(e,t){var n,o,r,s=[],c=a(e);for(n=0;n<c.length;n++)r=void 0===e[o=c[n]]||null===e[o]?"":""+e[o],o=t?i(o).toLowerCase():i(o),r=i(r)||"",s.push(o+"="+r);return s.join("&")},getAuth:function(e){var t,n=(e=e||{}).SecretId,i=e.SecretKey,r=e.KeyTime,s=(e.method||e.Method||"get").toLowerCase(),c=o(e.Query||e.params||{}),l=x(o(e.Headers||e.headers||{})),p=e.Key||"";e.UseRawKey?t=e.Pathname||e.pathname||"/"+p:0!==(t=e.Pathname||e.pathname||p).indexOf("/")&&(t="/"+t);var u=!1!==e.ForceSignHost;if(!l.Host&&!l.host&&e.Bucket&&e.Region&&u&&(l.Host=e.Bucket+".cos."+e.Region+".myqcloud.com"),!n)return console.error("missing param SecretId");if(!i)return console.error("missing param SecretKey");var m=Math.round(C(e.SystemClockOffset)/1e3)-1,f=m,h=e.Expires||e.expires;f+=void 0===h?900:1*h||0;var g=n,v=r||m+";"+f,y=r||m+";"+f,b=a(l,!0).join(";").toLowerCase(),k=a(c,!0).join(";").toLowerCase(),S=d.HmacSHA1(y,i).toString(),R=[s,t,A.obj2str(c,!0),A.obj2str(l,!0),""].join("\n"),_=["sha1",v,d.SHA1(R).toString(),""].join("\n");return["q-sign-algorithm=sha1","q-ak="+g,"q-sign-time="+v,"q-key-time="+y,"q-header-list="+b,"q-url-param-list="+k,"q-signature="+d.HmacSHA1(_,S).toString()].join("&")},compareVersion:S,canFileSlice:R,isCIHost:function(e){return/^https?:\/\/([^/]+\.)?ci\.[^/]+/.test(e)},error:function(e,t){var n=e;return e.message=e.message||null,"string"==typeof t?(e.error=t,e.message=t):"object"===(void 0===t?"undefined":p(t))&&null!==t&&(r(e,t),(t.code||t.name)&&(e.code=t.code||t.name),t.message&&(e.message=t.message),t.stack&&(e.stack=t.stack)),"function"==typeof Object.defineProperty&&(Object.defineProperty(e,"name",{writable:!0,enumerable:!1}),Object.defineProperty(e,"message",{enumerable:!0})),e.name=t&&t.name||e.name||e.code||"Error",e.code||(e.code=e.name),e.error||(e.error=o(n)),e}};e.exports=A}).call(t,n(2))},function(e,t,n){function i(e,t){return void 0===t&&(t=Object),t&&"function"==typeof t.freeze?t.freeze(e):e}var a="function"==typeof Symbol&&"symbol"==_typeof3(Symbol.iterator)?function(e){return _typeof3(e)}:function(e){return e&&"function"==typeof Symbol&&e.constructor===Symbol&&e!==Symbol.prototype?"symbol":_typeof3(e)},o=i({HTML:"text/html",isHTML:function(e){return e===o.HTML},XML_APPLICATION:"application/xml",XML_TEXT:"text/xml",XML_XHTML_APPLICATION:"application/xhtml+xml",XML_SVG_IMAGE:"image/svg+xml"}),r=i({HTML:"http://www.w3.org/1999/xhtml",isHTML:function(e){return e===r.HTML},SVG:"http://www.w3.org/2000/svg",XML:"http://www.w3.org/XML/1998/namespace",XMLNS:"http://www.w3.org/2000/xmlns/"});t.assign=function(e,t){if(null===e||"object"!==(void 0===e?"undefined":a(e)))throw new TypeError("target is not an object");for(var n in t)Object.prototype.hasOwnProperty.call(t,n)&&(e[n]=t[n]);return e},t.freeze=i,t.MIME_TYPE=o,t.NAMESPACE=r},function(e,t,n){var i,a="function"==typeof Symbol&&"symbol"==_typeof3(Symbol.iterator)?function(e){return _typeof3(e)}:function(e){return e&&"function"==typeof Symbol&&e.constructor===Symbol&&e!==Symbol.prototype?"symbol":_typeof3(e)};i=function(){return this}();try{i=i||Function("return this")()||(0,eval)("this")}catch(e){"object"===("undefined"==typeof window?"undefined":a(window))&&(i=window)}e.exports=i},function(e,t,n){function i(e){return""!==e}function a(e,t){return e.hasOwnProperty(t)||(e[t]=!0),e}function o(e){if(!e)return[];var t=function(e){return e?e.split(/[\t\n\f\r ]+/).filter(i):[]}(e);return Object.keys(t.reduce(a,{}))}function r(e,t){for(var n in e)t[n]=e[n]}function s(e,t){var n=e.prototype;if(!(n instanceof t)){var i=function(){};i.prototype=t.prototype,r(n,i=new i),e.prototype=n=i}n.constructor!=e&&("function"!=typeof e&&console.error("unknown Class:"+e),n.constructor=e)}function c(e,t){if(t instanceof Error)var n=t;else n=this,Error.call(this,oe[e]),this.message=oe[e],Error.captureStackTrace&&Error.captureStackTrace(this,c);return n.code=e,t&&(this.message=this.message+": "+t),n}function l(){}function p(e,t){this._node=e,this._refresh=t,u(this)}function u(e){var t=e._node._inc||e._node.ownerDocument._inc;if(e._inc!=t){var n=e._refresh(e._node);z(e,"length",n.length),r(n,e),e._inc=t}}function d(){}function m(e,t){for(var n=e.length;n--;)if(e[n]===t)return n}function f(e,t,n,i){if(i?t[m(t,i)]=n:t[t.length++]=n,e){n.ownerElement=e;var a=e.ownerDocument;a&&(i&&k(a,e,i),function(e,t,n){e&&e._inc++,n.namespaceURI===q.XMLNS&&(t._nsMap[n.prefix?n.localName:""]=n.value)}(a,e,n))}}function h(e,t,n){var i=m(t,n);if(!(i>=0))throw c(se,new Error(e.tagName+"@"+n));for(var a=t.length-1;i<a;)t[i]=t[++i];if(t.length=a,e){var o=e.ownerDocument;o&&(k(o,e,n),n.ownerElement=null)}}function g(){}function v(){}function x(e){return("<"==e?"&lt;":">"==e&&"&gt;")||"&"==e&&"&amp;"||'"'==e&&"&quot;"||"&#"+e.charCodeAt()+";"}function y(e,t){if(t(e))return!0;if(e=e.firstChild)do{if(y(e,t))return!0}while(e=e.nextSibling)}function b(){}function k(e,t,n,i){e&&e._inc++,n.namespaceURI===q.XMLNS&&delete t._nsMap[n.prefix?n.localName:""]}function C(e,t,n){if(e&&e._inc){e._inc++;var i=t.childNodes;if(n)i[i.length++]=n;else{for(var a=t.firstChild,o=0;a;)i[o++]=a,a=a.nextSibling;i.length=o,delete i[i.length]}}}function S(e,t){var n=t.previousSibling,i=t.nextSibling;return n?n.nextSibling=i:e.firstChild=i,i?i.previousSibling=n:e.lastChild=n,t.parentNode=null,t.previousSibling=null,t.nextSibling=null,C(e.ownerDocument,e),t}function R(e,t,n){var i=t.parentNode;if(i&&i.removeChild(t),t.nodeType===ne){var a=t.firstChild;if(null==a)return t;var o=t.lastChild}else a=o=t;var r=n?n.previousSibling:e.lastChild;a.previousSibling=r,o.nextSibling=n,r?r.nextSibling=a:e.firstChild=a,null==n?e.lastChild=o:n.previousSibling=o;do{a.parentNode=e}while(a!==o&&(a=a.nextSibling));return C(e.ownerDocument||e,e),t.nodeType==ne&&(t.firstChild=t.lastChild=null),t}function A(){this._nsMap={}}function _(){}function w(){}function T(){}function E(){}function B(){}function O(){}function I(){}function N(){}function D(){}function P(){}function M(){}function j(){}function U(e,t){var n=[],i=9==this.nodeType&&this.documentElement||this,a=i.prefix,o=i.namespaceURI;if(o&&null==a&&null==(a=i.lookupPrefix(o)))var r=[{namespace:o,prefix:null}];return F(this,n,e,t,r),n.join("")}function H(e,t,n){var i=e.prefix||"",a=e.namespaceURI;if(!a)return!1;if("xml"===i&&a===q.XML||a===q.XMLNS)return!1;for(var o=n.length;o--;){var r=n[o];if(r.prefix===i)return r.namespace!==a}return!0}function L(e,t,n){e.push(" ",t,'="',n.replace(/[<>&"\t\n\r]/g,x),'"')}function F(e,t,n,i,a){if(a||(a=[]),i){if(!(e=i(e)))return;if("string"==typeof e)return void t.push(e)}switch(e.nodeType){case V:var o=e.attributes,r=o.length,s=e.firstChild,c=e.tagName,l=c;if(!(n=q.isHTML(e.namespaceURI)||n)&&!e.prefix&&e.namespaceURI){for(var p,u=0;u<o.length;u++)if("xmlns"===o.item(u).name){p=o.item(u).value;break}if(!p)for(var d=a.length-1;d>=0;d--)if(""===(m=a[d]).prefix&&m.namespace===e.namespaceURI){p=m.namespace;break}if(p!==e.namespaceURI)for(d=a.length-1;d>=0;d--){var m;if((m=a[d]).namespace===e.namespaceURI){m.prefix&&(l=m.prefix+":"+c);break}}}t.push("<",l);for(var f=0;f<r;f++)"xmlns"==(h=o.item(f)).prefix?a.push({prefix:h.localName,namespace:h.value}):"xmlns"==h.nodeName&&a.push({prefix:"",namespace:h.value});for(f=0;f<r;f++){var h,g,v;H(h=o.item(f),0,a)&&(L(t,(g=h.prefix||"")?"xmlns:"+g:"xmlns",v=h.namespaceURI),a.push({prefix:g,namespace:v})),F(h,t,n,i,a)}if(c===l&&H(e,0,a)&&(L(t,(g=e.prefix||"")?"xmlns:"+g:"xmlns",v=e.namespaceURI),a.push({prefix:g,namespace:v})),s||n&&!/^(?:meta|link|img|br|hr|input)$/i.test(c)){if(t.push(">"),n&&/^script$/i.test(c))for(;s;)s.data?t.push(s.data):F(s,t,n,i,a.slice()),s=s.nextSibling;else for(;s;)F(s,t,n,i,a.slice()),s=s.nextSibling;t.push("</",l,">")}else t.push("/>");return;case ee:case ne:for(s=e.firstChild;s;)F(s,t,n,i,a.slice()),s=s.nextSibling;return;case X:return L(t,e.name,e.value);case W:return t.push(e.data.replace(/[<&>]/g,x));case Q:return t.push("<![CDATA[",e.data,"]]>");case Z:return t.push("\x3c!--",e.data,"--\x3e");case te:var y=e.publicId,b=e.systemId;if(t.push("<!DOCTYPE ",e.name),y)t.push(" PUBLIC ",y),b&&"."!=b&&t.push(" ",b),t.push(">");else if(b&&"."!=b)t.push(" SYSTEM ",b,">");else{var k=e.internalSubset;k&&t.push(" [",k,"]"),t.push(">")}return;case J:return t.push("<?",e.target," ",e.data,"?>");case $:return t.push("&",e.nodeName,";");default:t.push("??",e.nodeName)}}function z(e,t,n){e[t]=n}var K="function"==typeof Symbol&&"symbol"==_typeof3(Symbol.iterator)?function(e){return _typeof3(e)}:function(e){return e&&"function"==typeof Symbol&&e.constructor===Symbol&&e!==Symbol.prototype?"symbol":_typeof3(e)},q=n(1).NAMESPACE,G={},V=G.ELEMENT_NODE=1,X=G.ATTRIBUTE_NODE=2,W=G.TEXT_NODE=3,Q=G.CDATA_SECTION_NODE=4,$=G.ENTITY_REFERENCE_NODE=5,Y=G.ENTITY_NODE=6,J=G.PROCESSING_INSTRUCTION_NODE=7,Z=G.COMMENT_NODE=8,ee=G.DOCUMENT_NODE=9,te=G.DOCUMENT_TYPE_NODE=10,ne=G.DOCUMENT_FRAGMENT_NODE=11,ie=G.NOTATION_NODE=12,ae={},oe={},re=(ae.INDEX_SIZE_ERR=(oe[1]="Index size error",1),ae.DOMSTRING_SIZE_ERR=(oe[2]="DOMString size error",2),ae.HIERARCHY_REQUEST_ERR=(oe[3]="Hierarchy request error",3)),se=(ae.WRONG_DOCUMENT_ERR=(oe[4]="Wrong document",4),ae.INVALID_CHARACTER_ERR=(oe[5]="Invalid character",5),ae.NO_DATA_ALLOWED_ERR=(oe[6]="No data allowed",6),ae.NO_MODIFICATION_ALLOWED_ERR=(oe[7]="No modification allowed",7),ae.NOT_FOUND_ERR=(oe[8]="Not found",8)),ce=(ae.NOT_SUPPORTED_ERR=(oe[9]="Not supported",9),ae.INUSE_ATTRIBUTE_ERR=(oe[10]="Attribute in use",10));ae.INVALID_STATE_ERR=(oe[11]="Invalid state",11),ae.SYNTAX_ERR=(oe[12]="Syntax error",12),ae.INVALID_MODIFICATION_ERR=(oe[13]="Invalid modification",13),ae.NAMESPACE_ERR=(oe[14]="Invalid namespace",14),ae.INVALID_ACCESS_ERR=(oe[15]="Invalid access",15),c.prototype=Error.prototype,r(ae,c),l.prototype={length:0,item:function(e){return this[e]||null},toString:function(e,t){for(var n=[],i=0;i<this.length;i++)F(this[i],n,e,t);return n.join("")}},p.prototype.item=function(e){return u(this),this[e]},s(p,l),d.prototype={length:0,item:l.prototype.item,getNamedItem:function(e){for(var t=this.length;t--;){var n=this[t];if(n.nodeName==e)return n}},setNamedItem:function(e){var t=e.ownerElement;if(t&&t!=this._ownerElement)throw new c(ce);var n=this.getNamedItem(e.nodeName);return f(this._ownerElement,this,e,n),n},setNamedItemNS:function(e){var t,n=e.ownerElement;if(n&&n!=this._ownerElement)throw new c(ce);return t=this.getNamedItemNS(e.namespaceURI,e.localName),f(this._ownerElement,this,e,t),t},removeNamedItem:function(e){var t=this.getNamedItem(e);return h(this._ownerElement,this,t),t},removeNamedItemNS:function(e,t){var n=this.getNamedItemNS(e,t);return h(this._ownerElement,this,n),n},getNamedItemNS:function(e,t){for(var n=this.length;n--;){var i=this[n];if(i.localName==t&&i.namespaceURI==e)return i}return null}},g.prototype={hasFeature:function(e,t){return!0},createDocument:function(e,t,n){var i=new b;if(i.implementation=this,i.childNodes=new l,i.doctype=n||null,n&&i.appendChild(n),t){var a=i.createElementNS(e,t);i.appendChild(a)}return i},createDocumentType:function(e,t,n){var i=new O;return i.name=e,i.nodeName=e,i.publicId=t||"",i.systemId=n||"",i}},v.prototype={firstChild:null,lastChild:null,previousSibling:null,nextSibling:null,attributes:null,parentNode:null,childNodes:null,ownerDocument:null,nodeValue:null,namespaceURI:null,prefix:null,localName:null,insertBefore:function(e,t){return R(this,e,t)},replaceChild:function(e,t){this.insertBefore(e,t),t&&this.removeChild(t)},removeChild:function(e){return S(this,e)},appendChild:function(e){return this.insertBefore(e,null)},hasChildNodes:function(){return null!=this.firstChild},cloneNode:function(e){return function e(t,n,i){var a=new n.constructor;for(var o in n){var r=n[o];"object"!=(void 0===r?"undefined":K(r))&&r!=a[o]&&(a[o]=r)}switch(n.childNodes&&(a.childNodes=new l),a.ownerDocument=t,a.nodeType){case V:var s=n.attributes,c=a.attributes=new d,p=s.length;c._ownerElement=a;for(var u=0;u<p;u++)a.setAttributeNode(e(t,s.item(u),!0));break;case X:i=!0}if(i)for(var m=n.firstChild;m;)a.appendChild(e(t,m,i)),m=m.nextSibling;return a}(this.ownerDocument||this,this,e)},normalize:function(){for(var e=this.firstChild;e;){var t=e.nextSibling;t&&t.nodeType==W&&e.nodeType==W?(this.removeChild(t),e.appendData(t.data)):(e.normalize(),e=t)}},isSupported:function(e,t){return this.ownerDocument.implementation.hasFeature(e,t)},hasAttributes:function(){return this.attributes.length>0},lookupPrefix:function(e){for(var t=this;t;){var n=t._nsMap;if(n)for(var i in n)if(n[i]==e)return i;t=t.nodeType==X?t.ownerDocument:t.parentNode}return null},lookupNamespaceURI:function(e){for(var t=this;t;){var n=t._nsMap;if(n&&e in n)return n[e];t=t.nodeType==X?t.ownerDocument:t.parentNode}return null},isDefaultNamespace:function(e){return null==this.lookupPrefix(e)}},r(G,v),r(G,v.prototype),b.prototype={nodeName:"#document",nodeType:ee,doctype:null,documentElement:null,_inc:1,insertBefore:function(e,t){if(e.nodeType==ne){for(var n=e.firstChild;n;){var i=n.nextSibling;this.insertBefore(n,t),n=i}return e}return null==this.documentElement&&e.nodeType==V&&(this.documentElement=e),R(this,e,t),e.ownerDocument=this,e},removeChild:function(e){return this.documentElement==e&&(this.documentElement=null),S(this,e)},importNode:function(e,t){return function e(t,n,i){var a;switch(n.nodeType){case V:(a=n.cloneNode(!1)).ownerDocument=t;case ne:break;case X:i=!0}if(a||(a=n.cloneNode(!1)),a.ownerDocument=t,a.parentNode=null,i)for(var o=n.firstChild;o;)a.appendChild(e(t,o,i)),o=o.nextSibling;return a}(this,e,t)},getElementById:function(e){var t=null;return y(this.documentElement,(function(n){if(n.nodeType==V&&n.getAttribute("id")==e)return t=n,!0})),t},getElementsByClassName:function(e){var t=o(e);return new p(this,(function(n){var i=[];return t.length>0&&y(n.documentElement,(function(a){if(a!==n&&a.nodeType===V){var r=a.getAttribute("class");if(r){var s=e===r;if(!s){var c=o(r);s=t.every(function(e){return function(t){return e&&-1!==e.indexOf(t)}}(c))}s&&i.push(a)}}})),i}))},createElement:function(e){var t=new A;return t.ownerDocument=this,t.nodeName=e,t.tagName=e,t.localName=e,t.childNodes=new l,(t.attributes=new d)._ownerElement=t,t},createDocumentFragment:function(){var e=new P;return e.ownerDocument=this,e.childNodes=new l,e},createTextNode:function(e){var t=new T;return t.ownerDocument=this,t.appendData(e),t},createComment:function(e){var t=new E;return t.ownerDocument=this,t.appendData(e),t},createCDATASection:function(e){var t=new B;return t.ownerDocument=this,t.appendData(e),t},createProcessingInstruction:function(e,t){var n=new M;return n.ownerDocument=this,n.tagName=n.target=e,n.nodeValue=n.data=t,n},createAttribute:function(e){var t=new _;return t.ownerDocument=this,t.name=e,t.nodeName=e,t.localName=e,t.specified=!0,t},createEntityReference:function(e){var t=new D;return t.ownerDocument=this,t.nodeName=e,t},createElementNS:function(e,t){var n=new A,i=t.split(":"),a=n.attributes=new d;return n.childNodes=new l,n.ownerDocument=this,n.nodeName=t,n.tagName=t,n.namespaceURI=e,2==i.length?(n.prefix=i[0],n.localName=i[1]):n.localName=t,a._ownerElement=n,n},createAttributeNS:function(e,t){var n=new _,i=t.split(":");return n.ownerDocument=this,n.nodeName=t,n.name=t,n.namespaceURI=e,n.specified=!0,2==i.length?(n.prefix=i[0],n.localName=i[1]):n.localName=t,n}},s(b,v),A.prototype={nodeType:V,hasAttribute:function(e){return null!=this.getAttributeNode(e)},getAttribute:function(e){var t=this.getAttributeNode(e);return t&&t.value||""},getAttributeNode:function(e){return this.attributes.getNamedItem(e)},setAttribute:function(e,t){var n=this.ownerDocument.createAttribute(e);n.value=n.nodeValue=""+t,this.setAttributeNode(n)},removeAttribute:function(e){var t=this.getAttributeNode(e);t&&this.removeAttributeNode(t)},appendChild:function(e){return e.nodeType===ne?this.insertBefore(e,null):function(e,t){return t.parentNode&&t.parentNode.removeChild(t),t.parentNode=e,t.previousSibling=e.lastChild,t.nextSibling=null,t.previousSibling?t.previousSibling.nextSibling=t:e.firstChild=t,e.lastChild=t,C(e.ownerDocument,e,t),t}(this,e)},setAttributeNode:function(e){return this.attributes.setNamedItem(e)},setAttributeNodeNS:function(e){return this.attributes.setNamedItemNS(e)},removeAttributeNode:function(e){return this.attributes.removeNamedItem(e.nodeName)},removeAttributeNS:function(e,t){var n=this.getAttributeNodeNS(e,t);n&&this.removeAttributeNode(n)},hasAttributeNS:function(e,t){return null!=this.getAttributeNodeNS(e,t)},getAttributeNS:function(e,t){var n=this.getAttributeNodeNS(e,t);return n&&n.value||""},setAttributeNS:function(e,t,n){var i=this.ownerDocument.createAttributeNS(e,t);i.value=i.nodeValue=""+n,this.setAttributeNode(i)},getAttributeNodeNS:function(e,t){return this.attributes.getNamedItemNS(e,t)},getElementsByTagName:function(e){return new p(this,(function(t){var n=[];return y(t,(function(i){i===t||i.nodeType!=V||"*"!==e&&i.tagName!=e||n.push(i)})),n}))},getElementsByTagNameNS:function(e,t){return new p(this,(function(n){var i=[];return y(n,(function(a){a===n||a.nodeType!==V||"*"!==e&&a.namespaceURI!==e||"*"!==t&&a.localName!=t||i.push(a)})),i}))}},b.prototype.getElementsByTagName=A.prototype.getElementsByTagName,b.prototype.getElementsByTagNameNS=A.prototype.getElementsByTagNameNS,s(A,v),_.prototype.nodeType=X,s(_,v),w.prototype={data:"",substringData:function(e,t){return this.data.substring(e,e+t)},appendData:function(e){e=this.data+e,this.nodeValue=this.data=e,this.length=e.length},insertData:function(e,t){this.replaceData(e,0,t)},appendChild:function(e){throw new Error(oe[re])},deleteData:function(e,t){this.replaceData(e,t,"")},replaceData:function(e,t,n){n=this.data.substring(0,e)+n+this.data.substring(e+t),this.nodeValue=this.data=n,this.length=n.length}},s(w,v),T.prototype={nodeName:"#text",nodeType:W,splitText:function(e){var t=this.data,n=t.substring(e);t=t.substring(0,e),this.data=this.nodeValue=t,this.length=t.length;var i=this.ownerDocument.createTextNode(n);return this.parentNode&&this.parentNode.insertBefore(i,this.nextSibling),i}},s(T,w),E.prototype={nodeName:"#comment",nodeType:Z},s(E,w),B.prototype={nodeName:"#cdata-section",nodeType:Q},s(B,w),O.prototype.nodeType=te,s(O,v),I.prototype.nodeType=ie,s(I,v),N.prototype.nodeType=Y,s(N,v),D.prototype.nodeType=$,s(D,v),P.prototype.nodeName="#document-fragment",P.prototype.nodeType=ne,s(P,v),M.prototype.nodeType=J,s(M,v),j.prototype.serializeToString=function(e,t,n){return U.call(e,t,n)},v.prototype.toString=U;try{Object.defineProperty&&(Object.defineProperty(p.prototype,"length",{get:function(){return u(this),this.$$length}}),Object.defineProperty(v.prototype,"textContent",{get:function(){return function e(t){switch(t.nodeType){case V:case ne:var n=[];for(t=t.firstChild;t;)7!==t.nodeType&&8!==t.nodeType&&n.push(e(t)),t=t.nextSibling;return n.join("");default:return t.nodeValue}}(this)},set:function(e){switch(this.nodeType){case V:case ne:for(;this.firstChild;)this.removeChild(this.firstChild);(e||String(e))&&this.appendChild(this.ownerDocument.createTextNode(e));break;default:this.data=e,this.value=e,this.nodeValue=e}}}),z=function(e,t,n){e["$$"+t]=n})}catch(e){}t.DocumentType=O,t.DOMException=c,t.DOMImplementation=g,t.Element=A,t.Node=v,t.NodeList=l,t.XMLSerializer=j},function(e,t,n){var i=function(e){var t=(e=e||{}).Base64,n="ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/",i=function(e){for(var t={},n=0,i=e.length;n<i;n++)t[e.charAt(n)]=n;return t}(n),a=String.fromCharCode,o=function(e){if(e.length<2)return(t=e.charCodeAt(0))<128?e:t<2048?a(192|t>>>6)+a(128|63&t):a(224|t>>>12&15)+a(128|t>>>6&63)+a(128|63&t);var t=65536+1024*(e.charCodeAt(0)-55296)+(e.charCodeAt(1)-56320);return a(240|t>>>18&7)+a(128|t>>>12&63)+a(128|t>>>6&63)+a(128|63&t)},r=/[\uD800-\uDBFF][\uDC00-\uDFFFF]|[^\x00-\x7F]/g,s=function(e){return e.replace(r,o)},c=function(e){var t=[0,2,1][e.length%3],i=e.charCodeAt(0)<<16|(e.length>1?e.charCodeAt(1):0)<<8|(e.length>2?e.charCodeAt(2):0);return[n.charAt(i>>>18),n.charAt(i>>>12&63),t>=2?"=":n.charAt(i>>>6&63),t>=1?"=":n.charAt(63&i)].join("")},l=e.btoa?function(t){return e.btoa(t)}:function(e){return e.replace(/[\s\S]{1,3}/g,c)},p=function(e){return l(s(e))},u=function(e,t){return t?p(String(e)).replace(/[+\/]/g,(function(e){return"+"==e?"-":"_"})).replace(/=/g,""):p(String(e))},d=new RegExp(["[À-ß][-¿]","[à-ï][-¿]{2}","[ð-÷][-¿]{3}"].join("|"),"g"),m=function(e){switch(e.length){case 4:var t=((7&e.charCodeAt(0))<<18|(63&e.charCodeAt(1))<<12|(63&e.charCodeAt(2))<<6|63&e.charCodeAt(3))-65536;return a(55296+(t>>>10))+a(56320+(1023&t));case 3:return a((15&e.charCodeAt(0))<<12|(63&e.charCodeAt(1))<<6|63&e.charCodeAt(2));default:return a((31&e.charCodeAt(0))<<6|63&e.charCodeAt(1))}},f=function(e){return e.replace(d,m)},h=function(e){var t=e.length,n=t%4,o=(t>0?i[e.charAt(0)]<<18:0)|(t>1?i[e.charAt(1)]<<12:0)|(t>2?i[e.charAt(2)]<<6:0)|(t>3?i[e.charAt(3)]:0),r=[a(o>>>16),a(o>>>8&255),a(255&o)];return r.length-=[0,0,2,1][n],r.join("")},g=e.atob?function(t){return e.atob(t)}:function(e){return e.replace(/[\s\S]{1,4}/g,h)},v=function(e){return f(g(e))},x=function(e){return v(String(e).replace(/[-_]/g,(function(e){return"-"==e?"+":"/"})).replace(/[^A-Za-z0-9\+\/]/g,""))};return{VERSION:"2.1.9",atob:g,btoa:l,fromBase64:x,toBase64:u,utob:s,encode:u,encodeURI:function(e){return u(e,!0)},btou:f,decode:x,noConflict:function(){var n=e.Base64;return e.Base64=t,n}}}();e.exports=i},function(e,t,n){var i=function(e){var t={},n=function(e){return!t[e]&&(t[e]=[]),t[e]};e.on=function(e,t){n(e).push(t)},e.off=function(e,t){for(var i=n(e),a=i.length-1;a>=0;a--)t===i[a]&&i.splice(a,1)},e.emit=function(e,t){for(var i=n(e).map((function(e){return e})),a=0;a<i.length;a++)i[a](t)}};e.exports.init=i,e.exports.EventProxy=function(){i(this)}},function(e,t,n){var i,a,o=n(0),r=function(){try{wx.setStorageSync("cos_sdk_upload_cache",JSON.stringify(i))}catch(e){}},s=function(){if(!i){i=function(){try{var e=JSON.parse(wx.getStorageSync("cos_sdk_upload_cache"))}catch(e){}return e||(e=[]),e}();for(var e=!1,t=Math.round(Date.now()/1e3),n=i.length-1;n>=0;n--){var a=i[n][2];(!a||a+2592e3<t)&&(i.splice(n,1),e=!0)}e&&r()}},c=function(){a||(a=setTimeout((function(){r(),a=null}),400))},l={using:{},setUsing:function(e){l.using[e]=!0},removeUsing:function(e){delete l.using[e]},getFileId:function(e,t,n,i){return e.FilePath&&e.size&&e.lastModifiedTime&&t?o.md5([e.FilePath].join("::"))+"-"+o.md5([e.size,e.mode,e.lastAccessedTime,e.lastModifiedTime,t,n,i].join("::")):null},getUploadIdList:function(e){if(!e)return null;s();for(var t=[],n=0;n<i.length;n++)i[n][0]===e&&t.push(i[n][1]);return t.length?t:null},saveUploadId:function(e,t,n){if(s(),e){for(var a=e.substr(0,e.indexOf("-")+1),o=i.length-1;o>=0;o--){var r=i[o];(r[0]===e&&r[1]===t||e!==r[0]&&0===r[0].indexOf(a))&&i.splice(o,1)}i.unshift([e,t,Math.round(Date.now()/1e3)]),i.length>n&&i.splice(n),c()}},removeUploadId:function(e){s(),delete l.using[e];for(var t=i.length-1;t>=0;t--)i[t][1]===e&&i.splice(t,1);c()}};e.exports=l},function(e,t,n){var i=n(8);e.exports=i},function(e,t,n){var i=n(0),a=n(5),o=n(20),r=n(21),s=n(27),c={SecretId:"",SecretKey:"",SecurityToken:"",ChunkRetryTimes:2,FileParallelLimit:3,ChunkParallelLimit:3,ChunkSize:1048576,SliceSize:1048576,CopyChunkParallelLimit:20,CopyChunkSize:10485760,CopySliceSize:10485760,MaxPartNumber:1e4,ProgressInterval:1e3,UploadQueueSize:1e4,Domain:"",ServiceDomain:"",Protocol:"",CompatibilityMode:!1,ForcePathStyle:!1,Timeout:0,CorrectClockSkew:!0,SystemClockOffset:0,UploadCheckContentMd5:!1,UploadIdCacheLimit:50,UseAccelerate:!1,ForceSignHost:!0,HttpDNSServiceId:""},l=function(e){this.options=i.extend(i.clone(c),e||{}),this.options.FileParallelLimit=Math.max(1,this.options.FileParallelLimit),this.options.ChunkParallelLimit=Math.max(1,this.options.ChunkParallelLimit),this.options.ChunkRetryTimes=Math.max(0,this.options.ChunkRetryTimes),this.options.ChunkSize=Math.max(1048576,this.options.ChunkSize),this.options.CopyChunkParallelLimit=Math.max(1,this.options.CopyChunkParallelLimit),this.options.CopyChunkSize=Math.max(1048576,this.options.CopyChunkSize),this.options.CopySliceSize=Math.max(0,this.options.CopySliceSize),this.options.MaxPartNumber=Math.max(1024,Math.min(1e4,this.options.MaxPartNumber)),this.options.Timeout=Math.max(0,this.options.Timeout),this.options.AppId&&console.warn('warning: AppId has been deprecated, Please put it at the end of parameter Bucket(E.g: "test-1250000000").'),this.options.SecretId&&this.options.SecretId.indexOf(" ")>-1&&(console.error("error: SecretId格式错误，请检查"),console.error("error: SecretId format is incorrect. Please check")),this.options.SecretKey&&this.options.SecretKey.indexOf(" ")>-1&&(console.error("error: SecretKey格式错误，请检查"),console.error("error: SecretKey format is incorrect. Please check")),a.init(this),o.init(this)};r.init(l,o),s.init(l,o),l.util={md5:i.md5,xml2json:i.xml2json,json2xml:i.json2xml},l.getAuthorization=i.getAuth,l.version="1.2.1",e.exports=l},function(module,exports,__webpack_require__){(function(process,global,module){var __WEBPACK_AMD_DEFINE_RESULT__,_typeof="function"==typeof Symbol&&"symbol"==_typeof3(Symbol.iterator)?function(e){return _typeof3(e)}:function(e){return e&&"function"==typeof Symbol&&e.constructor===Symbol&&e!==Symbol.prototype?"symbol":_typeof3(e)};!function(){function Md5(e){if(e)blocks[0]=blocks[16]=blocks[1]=blocks[2]=blocks[3]=blocks[4]=blocks[5]=blocks[6]=blocks[7]=blocks[8]=blocks[9]=blocks[10]=blocks[11]=blocks[12]=blocks[13]=blocks[14]=blocks[15]=0,this.blocks=blocks,this.buffer8=buffer8;else if(ARRAY_BUFFER){var t=new ArrayBuffer(68);this.buffer8=new Uint8Array(t),this.blocks=new Uint32Array(t)}else this.blocks=[0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0];this.h0=this.h1=this.h2=this.h3=this.start=this.bytes=this.hBytes=0,this.finalized=this.hashed=!1,this.first=!0}var ERROR="input is invalid type",WINDOW="object"===("undefined"==typeof window?"undefined":_typeof(window)),root=WINDOW?window:{};root.JS_MD5_NO_WINDOW&&(WINDOW=!1);var WEB_WORKER=!WINDOW&&"object"===("undefined"==typeof self?"undefined":_typeof(self)),NODE_JS=!root.JS_MD5_NO_NODE_JS&&"object"===(void 0===process?"undefined":_typeof(process))&&process.versions&&process.versions.node;NODE_JS?root=global:WEB_WORKER&&(root=self);var COMMON_JS=!root.JS_MD5_NO_COMMON_JS&&"object"===_typeof(module)&&module.exports,AMD=__webpack_require__(12),ARRAY_BUFFER=!root.JS_MD5_NO_ARRAY_BUFFER&&"undefined"!=typeof ArrayBuffer,HEX_CHARS="0123456789abcdef".split(""),EXTRA=[128,32768,8388608,-2147483648],SHIFT=[0,8,16,24],OUTPUT_TYPES=["hex","array","digest","buffer","arrayBuffer","base64"],BASE64_ENCODE_CHAR="ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/".split(""),blocks=[],buffer8;if(ARRAY_BUFFER){var buffer=new ArrayBuffer(68);buffer8=new Uint8Array(buffer),blocks=new Uint32Array(buffer)}!root.JS_MD5_NO_NODE_JS&&Array.isArray||(Array.isArray=function(e){return"[object Array]"===Object.prototype.toString.call(e)}),!ARRAY_BUFFER||!root.JS_MD5_NO_ARRAY_BUFFER_IS_VIEW&&ArrayBuffer.isView||(ArrayBuffer.isView=function(e){return"object"===(void 0===e?"undefined":_typeof(e))&&e.buffer&&e.buffer.constructor===ArrayBuffer});var createOutputMethod=function(e){return function(t){return new Md5(!0).update(t)[e]()}},createMethod=function(){var e=createOutputMethod("hex");NODE_JS&&(e=nodeWrap(e)),e.getCtx=e.create=function(){return new Md5},e.update=function(t){return e.create().update(t)};for(var t=0;t<OUTPUT_TYPES.length;++t){var n=OUTPUT_TYPES[t];e[n]=createOutputMethod(n)}return e},nodeWrap=function nodeWrap(method){var crypto=eval("require('crypto')"),Buffer=eval("require('buffer').Buffer"),nodeMethod=function(e){if("string"==typeof e)return crypto.createHash("md5").update(e,"utf8").digest("hex");if(null==e)throw ERROR;return e.constructor===ArrayBuffer&&(e=new Uint8Array(e)),Array.isArray(e)||ArrayBuffer.isView(e)||e.constructor===Buffer?crypto.createHash("md5").update(new Buffer(e)).digest("hex"):method(e)};return nodeMethod};Md5.prototype.update=function(e){if(!this.finalized){var t,n=void 0===e?"undefined":_typeof(e);if("string"!==n){if("object"!==n)throw ERROR;if(null===e)throw ERROR;if(!ARRAY_BUFFER||e.constructor!==ArrayBuffer&&"ArrayBuffer"!==e.constructor.name){if(!(Array.isArray(e)||ARRAY_BUFFER&&ArrayBuffer.isView(e)))throw ERROR}else e=new Uint8Array(e);t=!0}for(var i,a,o=0,r=e.length,s=this.blocks,c=this.buffer8;o<r;){if(this.hashed&&(this.hashed=!1,s[0]=s[16],s[16]=s[1]=s[2]=s[3]=s[4]=s[5]=s[6]=s[7]=s[8]=s[9]=s[10]=s[11]=s[12]=s[13]=s[14]=s[15]=0),t)if(ARRAY_BUFFER)for(a=this.start;o<r&&a<64;++o)c[a++]=e[o];else for(a=this.start;o<r&&a<64;++o)s[a>>2]|=e[o]<<SHIFT[3&a++];else if(ARRAY_BUFFER)for(a=this.start;o<r&&a<64;++o)(i=e.charCodeAt(o))<128?c[a++]=i:i<2048?(c[a++]=192|i>>6,c[a++]=128|63&i):i<55296||i>=57344?(c[a++]=224|i>>12,c[a++]=128|i>>6&63,c[a++]=128|63&i):(i=65536+((1023&i)<<10|1023&e.charCodeAt(++o)),c[a++]=240|i>>18,c[a++]=128|i>>12&63,c[a++]=128|i>>6&63,c[a++]=128|63&i);else for(a=this.start;o<r&&a<64;++o)(i=e.charCodeAt(o))<128?s[a>>2]|=i<<SHIFT[3&a++]:i<2048?(s[a>>2]|=(192|i>>6)<<SHIFT[3&a++],s[a>>2]|=(128|63&i)<<SHIFT[3&a++]):i<55296||i>=57344?(s[a>>2]|=(224|i>>12)<<SHIFT[3&a++],s[a>>2]|=(128|i>>6&63)<<SHIFT[3&a++],s[a>>2]|=(128|63&i)<<SHIFT[3&a++]):(i=65536+((1023&i)<<10|1023&e.charCodeAt(++o)),s[a>>2]|=(240|i>>18)<<SHIFT[3&a++],s[a>>2]|=(128|i>>12&63)<<SHIFT[3&a++],s[a>>2]|=(128|i>>6&63)<<SHIFT[3&a++],s[a>>2]|=(128|63&i)<<SHIFT[3&a++]);this.lastByteIndex=a,this.bytes+=a-this.start,a>=64?(this.start=a-64,this.hash(),this.hashed=!0):this.start=a}return this.bytes>4294967295&&(this.hBytes+=this.bytes/4294967296<<0,this.bytes=this.bytes%4294967296),this}},Md5.prototype.finalize=function(){if(!this.finalized){this.finalized=!0;var e=this.blocks,t=this.lastByteIndex;e[t>>2]|=EXTRA[3&t],t>=56&&(this.hashed||this.hash(),e[0]=e[16],e[16]=e[1]=e[2]=e[3]=e[4]=e[5]=e[6]=e[7]=e[8]=e[9]=e[10]=e[11]=e[12]=e[13]=e[14]=e[15]=0),e[14]=this.bytes<<3,e[15]=this.hBytes<<3|this.bytes>>>29,this.hash()}},Md5.prototype.hash=function(){var e,t,n,i,a,o,r=this.blocks;this.first?t=((t=((e=((e=r[0]-680876937)<<7|e>>>25)-271733879<<0)^(n=((n=(-271733879^(i=((i=(-1732584194^2004318071&e)+r[1]-117830708)<<12|i>>>20)+e<<0)&(-271733879^e))+r[2]-1126478375)<<17|n>>>15)+i<<0)&(i^e))+r[3]-1316259209)<<22|t>>>10)+n<<0:(e=this.h0,t=this.h1,n=this.h2,t=((t+=((e=((e+=((i=this.h3)^t&(n^i))+r[0]-680876936)<<7|e>>>25)+t<<0)^(n=((n+=(t^(i=((i+=(n^e&(t^n))+r[1]-389564586)<<12|i>>>20)+e<<0)&(e^t))+r[2]+606105819)<<17|n>>>15)+i<<0)&(i^e))+r[3]-1044525330)<<22|t>>>10)+n<<0),t=((t+=((e=((e+=(i^t&(n^i))+r[4]-176418897)<<7|e>>>25)+t<<0)^(n=((n+=(t^(i=((i+=(n^e&(t^n))+r[5]+1200080426)<<12|i>>>20)+e<<0)&(e^t))+r[6]-1473231341)<<17|n>>>15)+i<<0)&(i^e))+r[7]-45705983)<<22|t>>>10)+n<<0,t=((t+=((e=((e+=(i^t&(n^i))+r[8]+1770035416)<<7|e>>>25)+t<<0)^(n=((n+=(t^(i=((i+=(n^e&(t^n))+r[9]-1958414417)<<12|i>>>20)+e<<0)&(e^t))+r[10]-42063)<<17|n>>>15)+i<<0)&(i^e))+r[11]-1990404162)<<22|t>>>10)+n<<0,t=((t+=((e=((e+=(i^t&(n^i))+r[12]+1804603682)<<7|e>>>25)+t<<0)^(n=((n+=(t^(i=((i+=(n^e&(t^n))+r[13]-40341101)<<12|i>>>20)+e<<0)&(e^t))+r[14]-1502002290)<<17|n>>>15)+i<<0)&(i^e))+r[15]+1236535329)<<22|t>>>10)+n<<0,t=((t+=((i=((i+=(t^n&((e=((e+=(n^i&(t^n))+r[1]-165796510)<<5|e>>>27)+t<<0)^t))+r[6]-1069501632)<<9|i>>>23)+e<<0)^e&((n=((n+=(e^t&(i^e))+r[11]+643717713)<<14|n>>>18)+i<<0)^i))+r[0]-373897302)<<20|t>>>12)+n<<0,t=((t+=((i=((i+=(t^n&((e=((e+=(n^i&(t^n))+r[5]-701558691)<<5|e>>>27)+t<<0)^t))+r[10]+38016083)<<9|i>>>23)+e<<0)^e&((n=((n+=(e^t&(i^e))+r[15]-660478335)<<14|n>>>18)+i<<0)^i))+r[4]-405537848)<<20|t>>>12)+n<<0,t=((t+=((i=((i+=(t^n&((e=((e+=(n^i&(t^n))+r[9]+568446438)<<5|e>>>27)+t<<0)^t))+r[14]-1019803690)<<9|i>>>23)+e<<0)^e&((n=((n+=(e^t&(i^e))+r[3]-187363961)<<14|n>>>18)+i<<0)^i))+r[8]+1163531501)<<20|t>>>12)+n<<0,t=((t+=((i=((i+=(t^n&((e=((e+=(n^i&(t^n))+r[13]-1444681467)<<5|e>>>27)+t<<0)^t))+r[2]-51403784)<<9|i>>>23)+e<<0)^e&((n=((n+=(e^t&(i^e))+r[7]+1735328473)<<14|n>>>18)+i<<0)^i))+r[12]-1926607734)<<20|t>>>12)+n<<0,t=((t+=((o=(i=((i+=((a=t^n)^(e=((e+=(a^i)+r[5]-378558)<<4|e>>>28)+t<<0))+r[8]-2022574463)<<11|i>>>21)+e<<0)^e)^(n=((n+=(o^t)+r[11]+1839030562)<<16|n>>>16)+i<<0))+r[14]-35309556)<<23|t>>>9)+n<<0,t=((t+=((o=(i=((i+=((a=t^n)^(e=((e+=(a^i)+r[1]-1530992060)<<4|e>>>28)+t<<0))+r[4]+1272893353)<<11|i>>>21)+e<<0)^e)^(n=((n+=(o^t)+r[7]-155497632)<<16|n>>>16)+i<<0))+r[10]-1094730640)<<23|t>>>9)+n<<0,t=((t+=((o=(i=((i+=((a=t^n)^(e=((e+=(a^i)+r[13]+681279174)<<4|e>>>28)+t<<0))+r[0]-358537222)<<11|i>>>21)+e<<0)^e)^(n=((n+=(o^t)+r[3]-722521979)<<16|n>>>16)+i<<0))+r[6]+76029189)<<23|t>>>9)+n<<0,t=((t+=((o=(i=((i+=((a=t^n)^(e=((e+=(a^i)+r[9]-640364487)<<4|e>>>28)+t<<0))+r[12]-421815835)<<11|i>>>21)+e<<0)^e)^(n=((n+=(o^t)+r[15]+530742520)<<16|n>>>16)+i<<0))+r[2]-995338651)<<23|t>>>9)+n<<0,t=((t+=((i=((i+=(t^((e=((e+=(n^(t|~i))+r[0]-198630844)<<6|e>>>26)+t<<0)|~n))+r[7]+1126891415)<<10|i>>>22)+e<<0)^((n=((n+=(e^(i|~t))+r[14]-1416354905)<<15|n>>>17)+i<<0)|~e))+r[5]-57434055)<<21|t>>>11)+n<<0,t=((t+=((i=((i+=(t^((e=((e+=(n^(t|~i))+r[12]+1700485571)<<6|e>>>26)+t<<0)|~n))+r[3]-1894986606)<<10|i>>>22)+e<<0)^((n=((n+=(e^(i|~t))+r[10]-1051523)<<15|n>>>17)+i<<0)|~e))+r[1]-2054922799)<<21|t>>>11)+n<<0,t=((t+=((i=((i+=(t^((e=((e+=(n^(t|~i))+r[8]+1873313359)<<6|e>>>26)+t<<0)|~n))+r[15]-30611744)<<10|i>>>22)+e<<0)^((n=((n+=(e^(i|~t))+r[6]-1560198380)<<15|n>>>17)+i<<0)|~e))+r[13]+1309151649)<<21|t>>>11)+n<<0,t=((t+=((i=((i+=(t^((e=((e+=(n^(t|~i))+r[4]-145523070)<<6|e>>>26)+t<<0)|~n))+r[11]-1120210379)<<10|i>>>22)+e<<0)^((n=((n+=(e^(i|~t))+r[2]+718787259)<<15|n>>>17)+i<<0)|~e))+r[9]-343485551)<<21|t>>>11)+n<<0,this.first?(this.h0=e+1732584193<<0,this.h1=t-271733879<<0,this.h2=n-1732584194<<0,this.h3=i+271733878<<0,this.first=!1):(this.h0=this.h0+e<<0,this.h1=this.h1+t<<0,this.h2=this.h2+n<<0,this.h3=this.h3+i<<0)},Md5.prototype.hex=function(){this.finalize();var e=this.h0,t=this.h1,n=this.h2,i=this.h3;return HEX_CHARS[e>>4&15]+HEX_CHARS[15&e]+HEX_CHARS[e>>12&15]+HEX_CHARS[e>>8&15]+HEX_CHARS[e>>20&15]+HEX_CHARS[e>>16&15]+HEX_CHARS[e>>28&15]+HEX_CHARS[e>>24&15]+HEX_CHARS[t>>4&15]+HEX_CHARS[15&t]+HEX_CHARS[t>>12&15]+HEX_CHARS[t>>8&15]+HEX_CHARS[t>>20&15]+HEX_CHARS[t>>16&15]+HEX_CHARS[t>>28&15]+HEX_CHARS[t>>24&15]+HEX_CHARS[n>>4&15]+HEX_CHARS[15&n]+HEX_CHARS[n>>12&15]+HEX_CHARS[n>>8&15]+HEX_CHARS[n>>20&15]+HEX_CHARS[n>>16&15]+HEX_CHARS[n>>28&15]+HEX_CHARS[n>>24&15]+HEX_CHARS[i>>4&15]+HEX_CHARS[15&i]+HEX_CHARS[i>>12&15]+HEX_CHARS[i>>8&15]+HEX_CHARS[i>>20&15]+HEX_CHARS[i>>16&15]+HEX_CHARS[i>>28&15]+HEX_CHARS[i>>24&15]},Md5.prototype.toString=Md5.prototype.hex,Md5.prototype.digest=function(){this.finalize();var e=this.h0,t=this.h1,n=this.h2,i=this.h3;return[255&e,e>>8&255,e>>16&255,e>>24&255,255&t,t>>8&255,t>>16&255,t>>24&255,255&n,n>>8&255,n>>16&255,n>>24&255,255&i,i>>8&255,i>>16&255,i>>24&255]},Md5.prototype.array=Md5.prototype.digest,Md5.prototype.arrayBuffer=function(){this.finalize();var e=new ArrayBuffer(16),t=new Uint32Array(e);return t[0]=this.h0,t[1]=this.h1,t[2]=this.h2,t[3]=this.h3,e},Md5.prototype.buffer=Md5.prototype.arrayBuffer,Md5.prototype.base64=function(){for(var e,t,n,i="",a=this.array(),o=0;o<15;)e=a[o++],t=a[o++],n=a[o++],i+=BASE64_ENCODE_CHAR[e>>>2]+BASE64_ENCODE_CHAR[63&(e<<4|t>>>4)]+BASE64_ENCODE_CHAR[63&(t<<2|n>>>6)]+BASE64_ENCODE_CHAR[63&n];return e=a[o],i+(BASE64_ENCODE_CHAR[e>>>2]+BASE64_ENCODE_CHAR[e<<4&63]+"==")};var exports=createMethod();COMMON_JS?module.exports=exports:(root.md5=exports,AMD&&void 0!==(__WEBPACK_AMD_DEFINE_RESULT__=function(){return exports}.call(exports,__webpack_require__,exports,module))&&(module.exports=__WEBPACK_AMD_DEFINE_RESULT__))}()}).call(exports,__webpack_require__(10),__webpack_require__(2),__webpack_require__(11)(module))},function(e,t,n){function i(){throw new Error("setTimeout has not been defined")}function a(){throw new Error("clearTimeout has not been defined")}function o(e){if(p===setTimeout)return setTimeout(e,0);if((p===i||!p)&&setTimeout)return p=setTimeout,setTimeout(e,0);try{return p(e,0)}catch(t){try{return p.call(null,e,0)}catch(t){return p.call(this,e,0)}}}function r(){h&&m&&(h=!1,m.length?f=m.concat(f):g=-1,f.length&&s())}function s(){if(!h){var e=o(r);h=!0;for(var t=f.length;t;){for(m=f,f=[];++g<t;)m&&m[g].run();g=-1,t=f.length}m=null,h=!1,function(e){if(u===clearTimeout)return clearTimeout(e);if((u===a||!u)&&clearTimeout)return u=clearTimeout,clearTimeout(e);try{u(e)}catch(t){try{return u.call(null,e)}catch(t){return u.call(this,e)}}}(e)}}function c(e,t){this.fun=e,this.array=t}function l(){}var p,u,d=e.exports={};!function(){try{p="function"==typeof setTimeout?setTimeout:i}catch(e){p=i}try{u="function"==typeof clearTimeout?clearTimeout:a}catch(e){u=a}}();var m,f=[],h=!1,g=-1;d.nextTick=function(e){var t=new Array(arguments.length-1);if(arguments.length>1)for(var n=1;n<arguments.length;n++)t[n-1]=arguments[n];f.push(new c(e,t)),1!==f.length||h||o(s)},c.prototype.run=function(){this.fun.apply(null,this.array)},d.title="browser",d.browser=!0,d.env={},d.argv=[],d.version="",d.versions={},d.on=l,d.addListener=l,d.once=l,d.off=l,d.removeListener=l,d.removeAllListeners=l,d.emit=l,d.prependListener=l,d.prependOnceListener=l,d.listeners=function(e){return[]},d.binding=function(e){throw new Error("process.binding is not supported")},d.cwd=function(){return"/"},d.chdir=function(e){throw new Error("process.chdir is not supported")},d.umask=function(){return 0}},function(e,t,n){e.exports=function(e){return e.webpackPolyfill||(e.deprecate=function(){},e.paths=[],e.children||(e.children=[]),Object.defineProperty(e,"loaded",{enumerable:!0,get:function(){return e.l}}),Object.defineProperty(e,"id",{enumerable:!0,get:function(){return e.i}}),e.webpackPolyfill=1),e}},function(e,t){(function(t){e.exports=t}).call(t,{})},function(e,t,n){var i=i||function(e,t){var n={},i=n.lib={},a=function(){},o=i.Base={extend:function(e){a.prototype=this;var t=new a;return e&&t.mixIn(e),t.hasOwnProperty("init")||(t.init=function(){t.$super.init.apply(this,arguments)}),t.init.prototype=t,t.$super=this,t},create:function(){var e=this.extend();return e.init.apply(e,arguments),e},init:function(){},mixIn:function(e){for(var t in e)e.hasOwnProperty(t)&&(this[t]=e[t]);e.hasOwnProperty("toString")&&(this.toString=e.toString)},clone:function(){return this.init.prototype.extend(this)}},r=i.WordArray=o.extend({init:function(e,t){e=this.words=e||[],this.sigBytes=null!=t?t:4*e.length},toString:function(e){return(e||c).stringify(this)},concat:function(e){var t=this.words,n=e.words,i=this.sigBytes;if(e=e.sigBytes,this.clamp(),i%4)for(var a=0;a<e;a++)t[i+a>>>2]|=(n[a>>>2]>>>24-a%4*8&255)<<24-(i+a)%4*8;else if(65535<n.length)for(a=0;a<e;a+=4)t[i+a>>>2]=n[a>>>2];else t.push.apply(t,n);return this.sigBytes+=e,this},clamp:function(){var t=this.words,n=this.sigBytes;t[n>>>2]&=4294967295<<32-n%4*8,t.length=e.ceil(n/4)},clone:function(){var e=o.clone.call(this);return e.words=this.words.slice(0),e},random:function(t){for(var n=[],i=0;i<t;i+=4)n.push(4294967296*e.random()|0);return new r.init(n,t)}}),s=n.enc={},c=s.Hex={stringify:function(e){var t=e.words;e=e.sigBytes;for(var n=[],i=0;i<e;i++){var a=t[i>>>2]>>>24-i%4*8&255;n.push((a>>>4).toString(16)),n.push((15&a).toString(16))}return n.join("")},parse:function(e){for(var t=e.length,n=[],i=0;i<t;i+=2)n[i>>>3]|=parseInt(e.substr(i,2),16)<<24-i%8*4;return new r.init(n,t/2)}},l=s.Latin1={stringify:function(e){var t=e.words;e=e.sigBytes;for(var n=[],i=0;i<e;i++)n.push(String.fromCharCode(t[i>>>2]>>>24-i%4*8&255));return n.join("")},parse:function(e){for(var t=e.length,n=[],i=0;i<t;i++)n[i>>>2]|=(255&e.charCodeAt(i))<<24-i%4*8;return new r.init(n,t)}},p=s.Utf8={stringify:function(e){try{return decodeURIComponent(escape(l.stringify(e)))}catch(e){throw Error("Malformed UTF-8 data")}},parse:function(e){return l.parse(unescape(encodeURIComponent(e)))}},u=i.BufferedBlockAlgorithm=o.extend({reset:function(){this._data=new r.init,this._nDataBytes=0},_append:function(e){"string"==typeof e&&(e=p.parse(e)),this._data.concat(e),this._nDataBytes+=e.sigBytes},_process:function(t){var n=this._data,i=n.words,a=n.sigBytes,o=this.blockSize,s=a/(4*o);if(t=(s=t?e.ceil(s):e.max((0|s)-this._minBufferSize,0))*o,a=e.min(4*t,a),t){for(var c=0;c<t;c+=o)this._doProcessBlock(i,c);c=i.splice(0,t),n.sigBytes-=a}return new r.init(c,a)},clone:function(){var e=o.clone.call(this);return e._data=this._data.clone(),e},_minBufferSize:0});i.Hasher=u.extend({cfg:o.extend(),init:function(e){this.cfg=this.cfg.extend(e),this.reset()},reset:function(){u.reset.call(this),this._doReset()},update:function(e){return this._append(e),this._process(),this},finalize:function(e){return e&&this._append(e),this._doFinalize()},blockSize:16,_createHelper:function(e){return function(t,n){return new e.init(n).finalize(t)}},_createHmacHelper:function(e){return function(t,n){return new d.HMAC.init(e,n).finalize(t)}}});var d=n.algo={};return n}(Math);!function(){var e=i,t=(o=e.lib).WordArray,n=o.Hasher,a=[],o=e.algo.SHA1=n.extend({_doReset:function(){this._hash=new t.init([1732584193,4023233417,2562383102,271733878,3285377520])},_doProcessBlock:function(e,t){for(var n=this._hash.words,i=n[0],o=n[1],r=n[2],s=n[3],c=n[4],l=0;80>l;l++){if(16>l)a[l]=0|e[t+l];else{var p=a[l-3]^a[l-8]^a[l-14]^a[l-16];a[l]=p<<1|p>>>31}p=(i<<5|i>>>27)+c+a[l],p=20>l?p+(1518500249+(o&r|~o&s)):40>l?p+(1859775393+(o^r^s)):60>l?p+((o&r|o&s|r&s)-1894007588):p+((o^r^s)-899497514),c=s,s=r,r=o<<30|o>>>2,o=i,i=p}n[0]=n[0]+i|0,n[1]=n[1]+o|0,n[2]=n[2]+r|0,n[3]=n[3]+s|0,n[4]=n[4]+c|0},_doFinalize:function(){var e=this._data,t=e.words,n=8*this._nDataBytes,i=8*e.sigBytes;return t[i>>>5]|=128<<24-i%32,t[14+(i+64>>>9<<4)]=Math.floor(n/4294967296),t[15+(i+64>>>9<<4)]=n,e.sigBytes=4*t.length,this._process(),this._hash},clone:function(){var e=n.clone.call(this);return e._hash=this._hash.clone(),e}});e.SHA1=n._createHelper(o),e.HmacSHA1=n._createHmacHelper(o)}(),function(){var e=i,t=e.enc.Utf8;e.algo.HMAC=e.lib.Base.extend({init:function(e,n){e=this._hasher=new e.init,"string"==typeof n&&(n=t.parse(n));var i=e.blockSize,a=4*i;n.sigBytes>a&&(n=e.finalize(n)),n.clamp();for(var o=this._oKey=n.clone(),r=this._iKey=n.clone(),s=o.words,c=r.words,l=0;l<i;l++)s[l]^=1549556828,c[l]^=909522486;o.sigBytes=r.sigBytes=a,this.reset()},reset:function(){var e=this._hasher;e.reset(),e.update(this._iKey)},update:function(e){return this._hasher.update(e),this},finalize:function(e){var t=this._hasher;return e=t.finalize(e),t.reset(),t.finalize(this._oKey.clone().concat(e))}})}(),function(){var e=i,t=e.lib.WordArray;e.enc.Base64={stringify:function(e){var t=e.words,n=e.sigBytes,i=this._map;e.clamp();for(var a=[],o=0;o<n;o+=3)for(var r=(t[o>>>2]>>>24-o%4*8&255)<<16|(t[o+1>>>2]>>>24-(o+1)%4*8&255)<<8|t[o+2>>>2]>>>24-(o+2)%4*8&255,s=0;s<4&&o+.75*s<n;s++)a.push(i.charAt(r>>>6*(3-s)&63));var c=i.charAt(64);if(c)for(;a.length%4;)a.push(c);return a.join("")},parse:function(e){var n=e.length,i=this._map,a=i.charAt(64);if(a){var o=e.indexOf(a);-1!=o&&(n=o)}for(var r=[],s=0,c=0;c<n;c++)if(c%4){var l=i.indexOf(e.charAt(c-1))<<c%4*2,p=i.indexOf(e.charAt(c))>>>6-c%4*2;r[s>>>2]|=(l|p)<<24-s%4*8,s++}return t.create(r,s)},_map:"ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/="}}(),e.exports=i},function(e,t,n){var i=n(15).DOMParser,a=function(e){function t(e){var t=e.localName;return null==t&&(t=e.baseName),null!=t&&""!=t||(t=e.nodeName),t}function n(e){return"string"==typeof e?e.replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;").replace(/"/g,"&quot;").replace(/'/g,"&apos;"):e}function a(e,t,n,i){for(var a=0;a<e.length;a++){var o=e[a];if("string"==typeof o){if(o==i)break}else if(o instanceof RegExp){if(o.test(i))break}else if("function"==typeof o&&o(t,n,i))break}return a!=e.length}function o(t,n,i){switch(e.arrayAccessForm){case"property":t[n]instanceof Array?t[n+"_asArray"]=t[n]:t[n+"_asArray"]=[t[n]]}!(t[n]instanceof Array)&&e.arrayAccessFormPaths.length>0&&a(e.arrayAccessFormPaths,t,n,i)&&(t[n]=[t[n]])}function r(e){var t=e.split(/[-T:+Z]/g),n=new Date(t[0],t[1]-1,t[2]),i=t[5].split(".");if(n.setHours(t[3],t[4],i[0]),i.length>1&&n.setMilliseconds(i[1]),t[6]&&t[7]){var a=60*t[6]+Number(t[7]);a=0+("-"==(/\d\d-\d\d:\d\d$/.test(e)?"-":"+")?-1*a:a),n.setMinutes(n.getMinutes()-a-n.getTimezoneOffset())}else-1!==e.indexOf("Z",e.length-1)&&(n=new Date(Date.UTC(n.getFullYear(),n.getMonth(),n.getDate(),n.getHours(),n.getMinutes(),n.getSeconds(),n.getMilliseconds())));return n}function s(t,n,i){if(e.datetimeAccessFormPaths.length>0){var o=i.split(".#")[0];return a(e.datetimeAccessFormPaths,t,n,o)?r(t):t}return t}function c(t,n,i,o){return!(n==b.ELEMENT_NODE&&e.xmlElementsFilter.length>0)||a(e.xmlElementsFilter,t,i,o)}function l(n,i){if(n.nodeType==b.DOCUMENT_NODE){for(var a=new Object,r=n.childNodes,p=0;p<r.length;p++)(u=r.item(p)).nodeType==b.ELEMENT_NODE&&(a[d=t(u)]=l(u,d));return a}if(n.nodeType==b.ELEMENT_NODE){for((a=new Object).__cnt=0,r=n.childNodes,p=0;p<r.length;p++){var u,d=t(u=r.item(p));if(u.nodeType!=b.COMMENT_NODE){var m=i+"."+d;c(a,u.nodeType,d,m)&&(a.__cnt++,null==a[d]?(a[d]=l(u,m),o(a,d,m)):(null!=a[d]&&(a[d]instanceof Array||(a[d]=[a[d]],o(a,d,m))),a[d][a[d].length]=l(u,m)))}}for(var f=0;f<n.attributes.length;f++){var h=n.attributes.item(f);a.__cnt++,a[e.attributePrefix+h.name]=h.value}var g=function(e){return e.prefix}(n);return null!=g&&""!=g&&(a.__cnt++,a.__prefix=g),null!=a["#text"]&&(a.__text=a["#text"],a.__text instanceof Array&&(a.__text=a.__text.join("\n")),e.stripWhitespaces&&(a.__text=a.__text.trim()),delete a["#text"],"property"==e.arrayAccessForm&&delete a["#text_asArray"],a.__text=s(a.__text,d,i+"."+d)),null!=a["#cdata-section"]&&(a.__cdata=a["#cdata-section"],delete a["#cdata-section"],"property"==e.arrayAccessForm&&delete a["#cdata-section_asArray"]),0==a.__cnt&&"text"==e.emptyNodeForm?a="":1==a.__cnt&&null!=a.__text?a=a.__text:1!=a.__cnt||null==a.__cdata||e.keepCData?a.__cnt>1&&null!=a.__text&&e.skipEmptyTextNodesForObj&&(e.stripWhitespaces&&""==a.__text||""==a.__text.trim())&&delete a.__text:a=a.__cdata,delete a.__cnt,!e.enableToStringFunc||null==a.__text&&null==a.__cdata||(a.toString=function(){return(null!=this.__text?this.__text:"")+(null!=this.__cdata?this.__cdata:"")}),a}if(n.nodeType==b.TEXT_NODE||n.nodeType==b.CDATA_SECTION_NODE)return n.nodeValue}function p(t,i,a,o){var r="<"+(null!=t&&null!=t.__prefix?t.__prefix+":":"")+i;if(null!=a)for(var s=0;s<a.length;s++){var c=a[s],l=t[c];e.escapeMode&&(l=n(l)),r+=" "+c.substr(e.attributePrefix.length)+"=",e.useDoubleQuotes?r+='"'+l+'"':r+="'"+l+"'"}return r+(o?"/>":">")}function u(e,t){return"</"+(null!=e.__prefix?e.__prefix+":":"")+t+">"}function d(t,n){return!!("property"==e.arrayAccessForm&&function(e,t){return-1!==e.indexOf(t,e.length-t.length)}(n.toString(),"_asArray")||0==n.toString().indexOf(e.attributePrefix)||0==n.toString().indexOf("__")||t[n]instanceof Function)}function m(e){var t=0;if(e instanceof Object)for(var n in e)d(e,n)||t++;return t}function f(t,n,i){return 0==e.jsonPropertiesFilter.length||""==i||a(e.jsonPropertiesFilter,t,n,i)}function h(t){var n=[];if(t instanceof Object)for(var i in t)-1==i.toString().indexOf("__")&&0==i.toString().indexOf(e.attributePrefix)&&n.push(i);return n}function g(t){var i="";return t instanceof Object?i+=function(t){var i="";return null!=t.__cdata&&(i+="<![CDATA["+t.__cdata+"]]>"),null!=t.__text&&(e.escapeMode?i+=n(t.__text):i+=t.__text),i}(t):null!=t&&(e.escapeMode?i+=n(t):i+=t),i}function v(e,t){return""===e?t:e+"."+t}function x(e,t,n,i){var a="";if(0==e.length)a+=p(e,t,n,!0);else for(var o=0;o<e.length;o++)a+=p(e[o],t,h(e[o]),!1),a+=y(e[o],v(i,t)),a+=u(e[o],t);return a}function y(e,t){var n="";if(m(e)>0)for(var i in e)if(!d(e,i)&&(""==t||f(e,i,v(t,i)))){var a=e[i],o=h(a);null==a||null==a?n+=p(a,i,o,!0):a instanceof Object?a instanceof Array?n+=x(a,i,o,t):a instanceof Date?(n+=p(a,i,o,!1),n+=a.toISOString(),n+=u(a,i)):m(a)>0||null!=a.__text||null!=a.__cdata?(n+=p(a,i,o,!1),n+=y(a,v(t,i)),n+=u(a,i)):n+=p(a,i,o,!0):(n+=p(a,i,o,!1),n+=g(a),n+=u(a,i))}return n+g(e)}void 0===(e=e||{}).escapeMode&&(e.escapeMode=!0),e.attributePrefix=e.attributePrefix||"_",e.arrayAccessForm=e.arrayAccessForm||"none",e.emptyNodeForm=e.emptyNodeForm||"text",void 0===e.enableToStringFunc&&(e.enableToStringFunc=!0),e.arrayAccessFormPaths=e.arrayAccessFormPaths||[],void 0===e.skipEmptyTextNodesForObj&&(e.skipEmptyTextNodesForObj=!0),void 0===e.stripWhitespaces&&(e.stripWhitespaces=!0),e.datetimeAccessFormPaths=e.datetimeAccessFormPaths||[],void 0===e.useDoubleQuotes&&(e.useDoubleQuotes=!1),e.xmlElementsFilter=e.xmlElementsFilter||[],e.jsonPropertiesFilter=e.jsonPropertiesFilter||[],void 0===e.keepCData&&(e.keepCData=!1);var b={ELEMENT_NODE:1,TEXT_NODE:3,CDATA_SECTION_NODE:4,COMMENT_NODE:8,DOCUMENT_NODE:9};this.parseXmlString=function(e){if(void 0===e)return null;var t;if(i){var n=new i,a=null;try{a=n.parseFromString("INVALID","text/xml").getElementsByTagName("parsererror")[0].namespaceURI}catch(e){a=null}try{t=n.parseFromString(e,"text/xml"),null!=a&&t.getElementsByTagNameNS(a,"parsererror").length>0&&(t=null)}catch(e){t=null}}else 0==e.indexOf("<?")&&(e=e.substr(e.indexOf("?>")+2)),(t=new ActiveXObject("Microsoft.XMLDOM")).async="false",t.loadXML(e);return t},this.asArray=function(e){return void 0===e||null==e?[]:e instanceof Array?e:[e]},this.toXmlDateTime=function(e){return e instanceof Date?e.toISOString():"number"==typeof e?new Date(e).toISOString():null},this.asDateTime=function(e){return"string"==typeof e?r(e):e},this.xml2json=function(e){return l(e)},this.xml_str2json=function(e){var t=this.parseXmlString(e);return null!=t?this.xml2json(t):null},this.json2xml_str=function(e){return y(e,"")},this.json2xml=function(e){var t=this.json2xml_str(e);return this.parseXmlString(t)},this.getVersion=function(){return"1.2.0"}};e.exports=function(e){if(!e)return null;var t=(new i).parseFromString(e,"text/xml"),n=new a,o=n.xml2json(t);return o.html&&o.getElementsByTagName("parsererror").length?null:o}},function(e,t,n){var i=n(3);t.DOMImplementation=i.DOMImplementation,t.XMLSerializer=i.XMLSerializer,t.DOMParser=n(16).DOMParser},function(e,t,n){function i(e){return e.replace(/\r[\n\u0085]/g,"\n").replace(/[\r\u0085\u2028]/g,"\n")}function a(e){this.options=e||{locator:{}}}function o(e,t,n){function i(t){var i=e[t];!i&&o&&(i=2==e.length?function(n){e(t,n)}:e),a[t]=i&&function(e){i("[xmldom "+t+"]\t"+e+c(n))}||function(){}}if(!e){if(t instanceof r)return t;e=t}var a={},o=e instanceof Function;return n=n||{},i("warning"),i("error"),i("fatalError"),a}function r(){this.cdata=!1}function s(e,t){t.lineNumber=e.lineNumber,t.columnNumber=e.columnNumber}function c(e){if(e)return"\n@"+(e.systemId||"")+"#[line:"+e.lineNumber+",col:"+e.columnNumber+"]"}function l(e,t,n){return"string"==typeof e?e.substr(t,n):e.length>=t+n||t?new java.lang.String(e,t,n)+"":e}function p(e,t){e.currentElement?e.currentElement.appendChild(t):e.doc.appendChild(t)}var u=n(1),d=n(3),m=n(17),f=n(18),h=d.DOMImplementation,g=u.NAMESPACE,v=f.ParseError,x=f.XMLReader;a.prototype.parseFromString=function(e,t){var n=this.options,a=new x,s=n.domBuilder||new r,c=n.errorHandler,l=n.locator,p=n.xmlns||{},u=/\/x?html?$/.test(t),d=u?m.HTML_ENTITIES:m.XML_ENTITIES;l&&s.setDocumentLocator(l),a.errorHandler=o(c,s,l),a.domBuilder=n.domBuilder||s,u&&(p[""]=g.HTML),p.xml=p.xml||g.XML;var f=n.normalizeLineEndings||i;return e&&"string"==typeof e?a.parse(f(e),p,d):a.errorHandler.error("invalid doc source"),s.doc},r.prototype={startDocument:function(){this.doc=(new h).createDocument(null,null,null),this.locator&&(this.doc.documentURI=this.locator.systemId)},startElement:function(e,t,n,i){var a=this.doc,o=a.createElementNS(e,n||t),r=i.length;p(this,o),this.currentElement=o,this.locator&&s(this.locator,o);for(var c=0;c<r;c++){e=i.getURI(c);var l=i.getValue(c),u=(n=i.getQName(c),a.createAttributeNS(e,n));this.locator&&s(i.getLocator(c),u),u.value=u.nodeValue=l,o.setAttributeNode(u)}},endElement:function(e,t,n){var i=this.currentElement;i.tagName,this.currentElement=i.parentNode},startPrefixMapping:function(e,t){},endPrefixMapping:function(e){},processingInstruction:function(e,t){var n=this.doc.createProcessingInstruction(e,t);this.locator&&s(this.locator,n),p(this,n)},ignorableWhitespace:function(e,t,n){},characters:function(e,t,n){if(e=l.apply(this,arguments)){if(this.cdata)var i=this.doc.createCDATASection(e);else i=this.doc.createTextNode(e);this.currentElement?this.currentElement.appendChild(i):/^\s*$/.test(e)&&this.doc.appendChild(i),this.locator&&s(this.locator,i)}},skippedEntity:function(e){},endDocument:function(){this.doc.normalize()},setDocumentLocator:function(e){(this.locator=e)&&(e.lineNumber=0)},comment:function(e,t,n){e=l.apply(this,arguments);var i=this.doc.createComment(e);this.locator&&s(this.locator,i),p(this,i)},startCDATA:function(){this.cdata=!0},endCDATA:function(){this.cdata=!1},startDTD:function(e,t,n){var i=this.doc.implementation;if(i&&i.createDocumentType){var a=i.createDocumentType(e,t,n);this.locator&&s(this.locator,a),p(this,a),this.doc.doctype=a}},warning:function(e){console.warn("[xmldom warning]\t"+e,c(this.locator))},error:function(e){console.error("[xmldom error]\t"+e,c(this.locator))},fatalError:function(e){throw new v(e,this.locator)}},"endDTD,startEntity,endEntity,attributeDecl,elementDecl,externalEntityDecl,internalEntityDecl,resolveEntity,getExternalSubset,notationDecl,unparsedEntityDecl".replace(/\w+/g,(function(e){r.prototype[e]=function(){return null}})),t.__DOMHandler=r,t.normalizeLineEndings=i,t.DOMParser=a},function(e,t,n){var i=n(1).freeze;t.XML_ENTITIES=i({amp:"&",apos:"'",gt:">",lt:"<",quot:'"'}),t.HTML_ENTITIES=i({lt:"<",gt:">",amp:"&",quot:'"',apos:"'",Agrave:"À",Aacute:"Á",Acirc:"Â",Atilde:"Ã",Auml:"Ä",Aring:"Å",AElig:"Æ",Ccedil:"Ç",Egrave:"È",Eacute:"É",Ecirc:"Ê",Euml:"Ë",Igrave:"Ì",Iacute:"Í",Icirc:"Î",Iuml:"Ï",ETH:"Ð",Ntilde:"Ñ",Ograve:"Ò",Oacute:"Ó",Ocirc:"Ô",Otilde:"Õ",Ouml:"Ö",Oslash:"Ø",Ugrave:"Ù",Uacute:"Ú",Ucirc:"Û",Uuml:"Ü",Yacute:"Ý",THORN:"Þ",szlig:"ß",agrave:"à",aacute:"á",acirc:"â",atilde:"ã",auml:"ä",aring:"å",aelig:"æ",ccedil:"ç",egrave:"è",eacute:"é",ecirc:"ê",euml:"ë",igrave:"ì",iacute:"í",icirc:"î",iuml:"ï",eth:"ð",ntilde:"ñ",ograve:"ò",oacute:"ó",ocirc:"ô",otilde:"õ",ouml:"ö",oslash:"ø",ugrave:"ù",uacute:"ú",ucirc:"û",uuml:"ü",yacute:"ý",thorn:"þ",yuml:"ÿ",nbsp:" ",iexcl:"¡",cent:"¢",pound:"£",curren:"¤",yen:"¥",brvbar:"¦",sect:"§",uml:"¨",copy:"©",ordf:"ª",laquo:"«",not:"¬",shy:"­­",reg:"®",macr:"¯",deg:"°",plusmn:"±",sup2:"²",sup3:"³",acute:"´",micro:"µ",para:"¶",middot:"·",cedil:"¸",sup1:"¹",ordm:"º",raquo:"»",frac14:"¼",frac12:"½",frac34:"¾",iquest:"¿",times:"×",divide:"÷",forall:"∀",part:"∂",exist:"∃",empty:"∅",nabla:"∇",isin:"∈",notin:"∉",ni:"∋",prod:"∏",sum:"∑",minus:"−",lowast:"∗",radic:"√",prop:"∝",infin:"∞",ang:"∠",and:"∧",or:"∨",cap:"∩",cup:"∪",int:"∫",there4:"∴",sim:"∼",cong:"≅",asymp:"≈",ne:"≠",equiv:"≡",le:"≤",ge:"≥",sub:"⊂",sup:"⊃",nsub:"⊄",sube:"⊆",supe:"⊇",oplus:"⊕",otimes:"⊗",perp:"⊥",sdot:"⋅",Alpha:"Α",Beta:"Β",Gamma:"Γ",Delta:"Δ",Epsilon:"Ε",Zeta:"Ζ",Eta:"Η",Theta:"Θ",Iota:"Ι",Kappa:"Κ",Lambda:"Λ",Mu:"Μ",Nu:"Ν",Xi:"Ξ",Omicron:"Ο",Pi:"Π",Rho:"Ρ",Sigma:"Σ",Tau:"Τ",Upsilon:"Υ",Phi:"Φ",Chi:"Χ",Psi:"Ψ",Omega:"Ω",alpha:"α",beta:"β",gamma:"γ",delta:"δ",epsilon:"ε",zeta:"ζ",eta:"η",theta:"θ",iota:"ι",kappa:"κ",lambda:"λ",mu:"μ",nu:"ν",xi:"ξ",omicron:"ο",pi:"π",rho:"ρ",sigmaf:"ς",sigma:"σ",tau:"τ",upsilon:"υ",phi:"φ",chi:"χ",psi:"ψ",omega:"ω",thetasym:"ϑ",upsih:"ϒ",piv:"ϖ",OElig:"Œ",oelig:"œ",Scaron:"Š",scaron:"š",Yuml:"Ÿ",fnof:"ƒ",circ:"ˆ",tilde:"˜",ensp:" ",emsp:" ",thinsp:" ",zwnj:"‌",zwj:"‍",lrm:"‎",rlm:"‏",ndash:"–",mdash:"—",lsquo:"‘",rsquo:"’",sbquo:"‚",ldquo:"“",rdquo:"”",bdquo:"„",dagger:"†",Dagger:"‡",bull:"•",hellip:"…",permil:"‰",prime:"′",Prime:"″",lsaquo:"‹",rsaquo:"›",oline:"‾",euro:"€",trade:"™",larr:"←",uarr:"↑",rarr:"→",darr:"↓",harr:"↔",crarr:"↵",lceil:"⌈",rceil:"⌉",lfloor:"⌊",rfloor:"⌋",loz:"◊",spades:"♠",clubs:"♣",hearts:"♥",diams:"♦"}),t.entityMap=t.HTML_ENTITIES},function(e,t,n){function i(e,t){this.message=e,this.locator=t,Error.captureStackTrace&&Error.captureStackTrace(this,i)}function a(){}function o(e,t,n,a,o){function u(e){var t=e.slice(1,-1);return Object.hasOwnProperty.call(n,t)?n[t]:"#"===t.charAt(0)?function(e){if(e>65535){var t=55296+((e-=65536)>>10),n=56320+(1023&e);return String.fromCharCode(t,n)}return String.fromCharCode(e)}(parseInt(t.substr(1).replace("x","0x"))):(o.error("entity not found:"+e),e)}function g(t){if(t>R){var n=e.substring(R,t).replace(/&#?\w+;/g,u);k&&v(R),a.characters(n,0,t-R),R=t}}function v(t,n){for(;t>=y&&(n=b.exec(e));)x=n.index,y=x+n[0].length,k.lineNumber++;k.columnNumber=t-x+1}for(var x=0,y=0,b=/.*(?:\r\n?|\n)|.*$/g,k=a.locator,C=[{currentNSMap:t}],S={},R=0;;){try{var A=e.indexOf("<",R);if(A<0){if(!e.substr(R).match(/^\s*$/)){var _=a.doc,w=_.createTextNode(e.substr(R));_.appendChild(w),a.currentElement=w}return}switch(A>R&&g(A),e.charAt(A+1)){case"/":var T=e.indexOf(">",A+3),E=e.substring(A+2,T).replace(/[ \t\n\r]+$/g,""),B=C.pop();T<0?(E=e.substring(A+2).replace(/[\s<].*/,""),o.error("end tag name: "+E+" is not complete:"+B.tagName),T=A+1+E.length):E.match(/\s</)&&(E=E.replace(/[\s<].*/,""),o.error("end tag name: "+E+" maybe not complete"),T=A+1+E.length);var O=B.localNSMap,I=B.tagName==E;if(I||B.tagName&&B.tagName.toLowerCase()==E.toLowerCase()){if(a.endElement(B.uri,B.localName,E),O)for(var N in O)a.endPrefixMapping(N);I||o.fatalError("end tag name: "+E+" is not match the current start tagName:"+B.tagName)}else C.push(B);T++;break;case"?":k&&v(A),T=m(e,A,a);break;case"!":k&&v(A),T=d(e,A,a,o);break;default:k&&v(A);var D=new f,P=C[C.length-1].currentNSMap,M=(T=s(e,A,D,P,u,o),D.length);if(!D.closed&&p(e,T,D.tagName,S)&&(D.closed=!0,n.nbsp||o.warning("unclosed xml attribute")),k&&M){for(var j=r(k,{}),U=0;U<M;U++){var H=D[U];v(H.offset),H.locator=r(k,{})}a.locator=j,c(D,a,P)&&C.push(D),a.locator=k}else c(D,a,P)&&C.push(D);h.isHTML(D.uri)&&!D.closed?T=l(e,T,D.tagName,u,a):T++}}catch(e){if(e instanceof i)throw e;o.error("element parse error: "+e),T=-1}T>R?R=T:g(Math.max(A,R)+1)}}function r(e,t){return t.lineNumber=e.lineNumber,t.columnNumber=e.columnNumber,t}function s(e,t,n,i,a,o){function r(e,t,i){n.attributeNames.hasOwnProperty(e)&&o.fatalError("Attribute "+e+" redefined"),n.addValue(e,t.replace(/[\t\n\r]/g," ").replace(/&#?\w+;/g,a),i)}for(var s,c=++t,l=y;;){var p=e.charAt(c);switch(p){case"=":if(l===b)s=e.slice(t,c),l=C;else{if(l!==k)throw new Error("attribute equal must after attrName");l=C}break;case"'":case'"':if(l===C||l===b){if(l===b&&(o.warning('attribute value must after "="'),s=e.slice(t,c)),t=c+1,!((c=e.indexOf(p,t))>0))throw new Error("attribute value no end '"+p+"' match");r(s,u=e.slice(t,c),t-1),l=R}else{if(l!=S)throw new Error('attribute value must after "="');r(s,u=e.slice(t,c),t),o.warning('attribute "'+s+'" missed start quot('+p+")!!"),t=c+1,l=R}break;case"/":switch(l){case y:n.setTagName(e.slice(t,c));case R:case A:case _:l=_,n.closed=!0;case S:case b:case k:break;default:throw new Error("attribute invalid close char('/')")}break;case"":return o.error("unexpected end of input"),l==y&&n.setTagName(e.slice(t,c)),c;case">":switch(l){case y:n.setTagName(e.slice(t,c));case R:case A:case _:break;case S:case b:"/"===(u=e.slice(t,c)).slice(-1)&&(n.closed=!0,u=u.slice(0,-1));case k:l===k&&(u=s),l==S?(o.warning('attribute "'+u+'" missed quot(")!'),r(s,u,t)):(h.isHTML(i[""])&&u.match(/^(?:disabled|checked|selected)$/i)||o.warning('attribute "'+u+'" missed value!! "'+u+'" instead!!'),r(u,u,t));break;case C:throw new Error("attribute value missed!!")}return c;case"":p=" ";default:if(p<=" ")switch(l){case y:n.setTagName(e.slice(t,c)),l=A;break;case b:s=e.slice(t,c),l=k;break;case S:var u=e.slice(t,c);o.warning('attribute "'+u+'" missed quot(")!!'),r(s,u,t);case R:l=A}else switch(l){case k:n.tagName,h.isHTML(i[""])&&s.match(/^(?:disabled|checked|selected)$/i)||o.warning('attribute "'+s+'" missed value!! "'+s+'" instead2!!'),r(s,s,t),t=c,l=b;break;case R:o.warning('attribute space is required"'+s+'"!!');case A:l=b,t=c;break;case C:l=S,t=c;break;case _:throw new Error("elements closed character '/' and '>' must be connected to")}}c++}}function c(e,t,n){for(var i=e.tagName,a=null,o=e.length;o--;){var r=e[o],s=r.qName,c=r.value;if((m=s.indexOf(":"))>0)var l=r.prefix=s.slice(0,m),p=s.slice(m+1),d="xmlns"===l&&p;else p=s,l=null,d="xmlns"===s&&"";r.localName=p,!1!==d&&(null==a&&(a={},u(n,n={})),n[d]=a[d]=c,r.uri=h.XMLNS,t.startPrefixMapping(d,c))}for(o=e.length;o--;)(l=(r=e[o]).prefix)&&("xml"===l&&(r.uri=h.XML),"xmlns"!==l&&(r.uri=n[l||""]));var m;(m=i.indexOf(":"))>0?(l=e.prefix=i.slice(0,m),p=e.localName=i.slice(m+1)):(l=null,p=e.localName=i);var f=e.uri=n[l||""];if(t.startElement(f,p,i,e),!e.closed)return e.currentNSMap=n,e.localNSMap=a,!0;if(t.endElement(f,p,i),a)for(l in a)t.endPrefixMapping(l)}function l(e,t,n,i,a){if(/^(?:script|textarea)$/i.test(n)){var o=e.indexOf("</"+n+">",t),r=e.substring(t+1,o);if(/[&<]/.test(r))return/^script$/i.test(n)?(a.characters(r,0,r.length),o):(r=r.replace(/&#?\w+;/g,i),a.characters(r,0,r.length),o)}return t+1}function p(e,t,n,i){var a=i[n];return null==a&&((a=e.lastIndexOf("</"+n+">"))<t&&(a=e.lastIndexOf("</"+n)),i[n]=a),a<t}function u(e,t){for(var n in e)t[n]=e[n]}function d(e,t,n,i){switch(e.charAt(t+2)){case"-":return"-"===e.charAt(t+3)?(a=e.indexOf("--\x3e",t+4))>t?(n.comment(e,t+4,a-t-4),a+3):(i.error("Unclosed comment"),-1):-1;default:if("CDATA["==e.substr(t+3,6)){var a=e.indexOf("]]>",t+9);return n.startCDATA(),n.characters(e,t+9,a-t-9),n.endCDATA(),a+3}var o=function(e,t){var n,i=[],a=/'[^']+'|"[^"]+"|[^\s<>\/=]+=?|(\/?\s*>|<)/g;for(a.lastIndex=t,a.exec(e);n=a.exec(e);)if(i.push(n),n[1])return i}(e,t),r=o.length;if(r>1&&/!doctype/i.test(o[0][0])){var s=o[1][0],c=!1,l=!1;r>3&&(/^public$/i.test(o[2][0])?(c=o[3][0],l=r>4&&o[4][0]):/^system$/i.test(o[2][0])&&(l=o[3][0]));var p=o[r-1];return n.startDTD(s,c,l),n.endDTD(),p.index+p[0].length}}return-1}function m(e,t,n){var i=e.indexOf("?>",t);if(i){var a=e.substring(t,i).match(/^<\?(\S*)\s*([\s\S]*?)\s*$/);return a?(a[0].length,n.processingInstruction(a[1],a[2]),i+2):-1}return-1}function f(){this.attributeNames={}}var h=n(1).NAMESPACE,g=/[A-Z_a-z\xC0-\xD6\xD8-\xF6\u00F8-\u02FF\u0370-\u037D\u037F-\u1FFF\u200C-\u200D\u2070-\u218F\u2C00-\u2FEF\u3001-\uD7FF\uF900-\uFDCF\uFDF0-\uFFFD]/,v=new RegExp("[\\-\\.0-9"+g.source.slice(1,-1)+"\\u00B7\\u0300-\\u036F\\u203F-\\u2040]"),x=new RegExp("^"+g.source+v.source+"*(?::"+g.source+v.source+"*)?$"),y=0,b=1,k=2,C=3,S=4,R=5,A=6,_=7;i.prototype=new Error,i.prototype.name=i.name,a.prototype={parse:function(e,t,n){var i=this.domBuilder;i.startDocument(),u(t,t={}),o(e,t,n,i,this.errorHandler),i.endDocument()}},f.prototype={setTagName:function(e){if(!x.test(e))throw new Error("invalid tagName:"+e);this.tagName=e},addValue:function(e,t,n){if(!x.test(e))throw new Error("invalid attribute:"+e);this.attributeNames[e]=this.length,this[this.length++]={qName:e,value:t,offset:n}},length:0,getLocalName:function(e){return this[e].localName},getLocator:function(e){return this[e].locator},getQName:function(e){return this[e].qName},getURI:function(e){return this[e].uri},getValue:function(e){return this[e].value}},t.XMLReader=a,t.ParseError=i},function(e,t,n){function i(e){return(""+e).replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;").replace(/'/g,"&apos;").replace(/"/g,"&quot;").replace(r,"")}var a="function"==typeof Symbol&&"symbol"==_typeof3(Symbol.iterator)?function(e){return _typeof3(e)}:function(e){return e&&"function"==typeof Symbol&&e.constructor===Symbol&&e!==Symbol.prototype?"symbol":_typeof3(e)},o=new RegExp("^([^a-zA-Z_À-ÖØ-öø-ÿͰ-ͽͿ-῿‌-‍⁰-↏Ⰰ-⿿、-퟿豈-﷏ﷰ-�])|^((x|X)(m|M)(l|L))|([^a-zA-Z_À-ÖØ-öø-ÿͰ-ͽͿ-῿‌-‍⁰-↏Ⰰ-⿿、-퟿豈-﷏ﷰ-�-.0-9·̀-ͯ‿⁀])","g"),r=/[^\x09\x0A\x0D\x20-\xFF\x85\xA0-\uD7FF\uE000-\uFDCF\uFDE0-\uFFFD]/gm,s=function(e){var t=[];if(e instanceof Object)for(var n in e)e.hasOwnProperty(n)&&t.push(n);return t},c=function(e,t){var n=function(e,n,i,a,r){var s=void 0!==t.indent?t.indent:"\t",c=t.prettyPrint?"\n"+new Array(a).join(s):"";t.removeIllegalNameCharacters&&(e=e.replace(o,"_"));var l=[c,"<",e,i||""];return n&&n.length>0?(l.push(">"),l.push(n),r&&l.push(c),l.push("</"),l.push(e),l.push(">")):l.push("/>"),l.join("")};return function e(o,r,c){var l=void 0===o?"undefined":a(o);switch((Array.isArray?Array.isArray(o):o instanceof Array)?l="array":o instanceof Date&&(l="date"),l){case"array":var p=[];return o.map((function(t){p.push(e(t,0,c+1))})),t.prettyPrint&&p.push("\n"),p.join("");case"date":return o.toJSON?o.toJSON():o+"";case"object":var u=[];for(var d in o)if(o.hasOwnProperty(d))if(o[d]instanceof Array)for(var m in o[d])o[d].hasOwnProperty(m)&&u.push(n(d,e(o[d][m],0,c+1),null,c+1,s(o[d][m]).length));else u.push(n(d,e(o[d],0,c+1),null,c+1));return t.prettyPrint&&u.length>0&&u.push("\n"),u.join("");case"function":return o();default:return t.escape?i(o):""+o}}(e,0,0)},l=function(e){var t=['<?xml version="1.0" encoding="UTF-8"'];return e&&t.push(' standalone="yes"'),t.push("?>"),t.join("")};e.exports=function(e,t){if(t||(t={xmlHeader:{standalone:!0},prettyPrint:!0,indent:"  "}),"string"==typeof e)try{e=JSON.parse(e.toString())}catch(e){return!1}var n="",i="";return t&&("object"==(void 0===t?"undefined":a(t))?(t.xmlHeader&&(n=l(!!t.xmlHeader.standalone)),void 0!==t.docType&&(i="<!DOCTYPE "+t.docType+">")):n=l()),[n,(t=t||{}).prettyPrint&&i?"\n":"",i,c(e,t)].join("").replace(/\n{2,}/g,"\n").replace(/\s+$/g,"")}},function(e,t,n){var i=n(6),a=n(0),o={};e.exports.transferToTaskMethod=function(e,t){o[t]=e[t],e[t]=function(e,n){e.SkipTask?o[t].call(this,e,n):this._addTask(t,e,n)}},e.exports.init=function(e){var t=[],n={},r=0,s=0,c=function(e){var t={id:e.id,Bucket:e.Bucket,Region:e.Region,Key:e.Key,FilePath:e.FilePath,state:e.state,loaded:e.loaded,size:e.size,speed:e.speed,percent:e.percent,hashPercent:e.hashPercent,error:e.error};return e.FilePath&&(t.FilePath=e.FilePath),t},l=function(){var n,i=function(){n=0,e.emit("task-list-update",{list:a.map(t,c)}),e.emit("list-update",{list:a.map(t,c)})};return function(){n||(n=setTimeout(i))}}(),p=function(){if(!(t.length<=e.options.UploadQueueSize)){for(var i=0;i<s&&i<t.length&&t.length>e.options.UploadQueueSize;){var a="waiting"===t[i].state||"checking"===t[i].state||"uploading"===t[i].state;t[i]&&a?i++:(n[t[i].id]&&delete n[t[i].id],t.splice(i,1),s--)}l()}},u=function n(){if(!(r>=e.options.FileParallelLimit)){for(;t[s]&&"waiting"!==t[s].state;)s++;if(!(s>=t.length)){var i=t[s];s++,r++,i.state="checking",i.params.onTaskStart&&i.params.onTaskStart(c(i)),!i.params.UploadData&&(i.params.UploadData={});var u=a.formatParams(i.api,i.params);o[i.api].call(e,u,(function(t,a){e._isRunningTask(i.id)&&("checking"!==i.state&&"uploading"!==i.state||(i.state=t?"error":"success",t&&(i.error=t),r--,l(),n(),i.callback&&i.callback(t,a),"success"===i.state&&(i.params&&(delete i.params.UploadData,delete i.params.Body,delete i.params),delete i.callback)),p())})),l(),setTimeout(n)}}},d=function(t,a){var o=n[t];if(o){var s=o&&"waiting"===o.state,c=o&&("checking"===o.state||"uploading"===o.state);if("canceled"===a&&"canceled"!==o.state||"paused"===a&&s||"paused"===a&&c){if("paused"===a&&o.params.Body&&"function"==typeof o.params.Body.pipe)return void console.error("stream not support pause");o.state=a,e.emit("inner-kill-task",{TaskId:t,toState:a});try{var d=o&&o.params&&o.params.UploadData.UploadId}catch(e){}"canceled"===a&&d&&i.removeUsing(d),l(),c&&(r--,u()),"canceled"===a&&(o.params&&(delete o.params.UploadData,delete o.params.Body,delete o.params),delete o.callback)}p()}};e._addTasks=function(t){a.each(t,(function(t){e._addTask(t.api,t.params,t.callback,!0)})),l()},e._addTask=function(i,o,r,s){"sliceUploadFile"!==i||a.canFileSlice()||(i="postObject"),o=a.formatParams(i,o);var c=a.uuid();o.TaskId=c,o.onTaskReady&&o.onTaskReady(c);var d={params:o,callback:r,api:i,index:t.length,id:c,Bucket:o.Bucket,Region:o.Region,Key:o.Key,FilePath:o.FilePath||"",state:"waiting",loaded:0,size:0,speed:0,percent:0,hashPercent:0,error:null},m=o.onHashProgress;o.onHashProgress=function(t){e._isRunningTask(d.id)&&(d.hashPercent=t.percent,m&&m(t),l())};var f=o.onProgress;return o.onProgress=function(t){e._isRunningTask(d.id)&&("checking"===d.state&&(d.state="uploading"),d.loaded=t.loaded,d.size=t.total,d.speed=t.speed,d.percent=t.percent,f&&f(t),l())},a.getFileSize(i,o,(function(e,i){e?r(e):(n[c]=d,t.push(d),d.size=i,!s&&l(),u(),p())})),c},e._isRunningTask=function(e){var t=n[e];return!(!t||"checking"!==t.state&&"uploading"!==t.state)},e.getTaskList=function(){return a.map(t,c)},e.cancelTask=function(e){d(e,"canceled")},e.pauseTask=function(e){d(e,"paused")},e.restartTask=function(e){var t=n[e];!t||"paused"!==t.state&&"error"!==t.state||(t.state="waiting",l(),s=Math.min(s,t.index),u())},e.isUploadRunning=function(){return r||s<t.length}}},function(e,t,n){function i(e){var t={GrantFullControl:[],GrantWrite:[],GrantRead:[],GrantReadAcp:[],GrantWriteAcp:[],ACL:""},n={FULL_CONTROL:"GrantFullControl",WRITE:"GrantWrite",READ:"GrantRead",READ_ACP:"GrantReadAcp",WRITE_ACP:"GrantWriteAcp"},i=(e&&e.AccessControlList||{}).Grant;i&&(i=u.isArray(i)?i:[i]);var o={READ:0,WRITE:0,FULL_CONTROL:0};return i&&i.length&&u.each(i,(function(i){"qcs::cam::anyone:anyone"===i.Grantee.ID||"http://cam.qcloud.com/groups/global/AllUsers"===i.Grantee.URI?o[i.Permission]=1:i.Grantee.ID!==e.Owner.ID&&t[n[i.Permission]].push('id="'+i.Grantee.ID+'"')})),o.FULL_CONTROL||o.WRITE&&o.READ?t.ACL="public-read-write":o.READ?t.ACL="public-read":t.ACL="private",u.each(n,(function(e){t[e]=a(t[e].join(","))})),t}function a(e){var t,n,i=e.split(","),a={};for(t=0;t<i.length;)a[n=i[t].trim()]?i.splice(t,1):(a[n]=!0,i[t]=n,t++);return i.join(",")}function o(e){var t=e.bucket,n=t.substr(0,t.lastIndexOf("-")),i=t.substr(t.lastIndexOf("-")+1),a=e.domain,o=e.region,r=e.object;a||(a=["cn-south","cn-south-2","cn-north","cn-east","cn-southwest","sg"].indexOf(o)>-1?"{Region}.myqcloud.com":"cos.{Region}.myqcloud.com",e.ForcePathStyle||(a="{Bucket}."+a)),a=(a=a.replace(/\{\{AppId\}\}/gi,i).replace(/\{\{Bucket\}\}/gi,n).replace(/\{\{Region\}\}/gi,o).replace(/\{\{.*?\}\}/gi,"")).replace(/\{AppId\}/gi,i).replace(/\{BucketName\}/gi,n).replace(/\{Bucket\}/gi,t).replace(/\{Region\}/gi,o).replace(/\{.*?\}/gi,""),/^[a-zA-Z]+:\/\//.test(a)||(a="https://"+a),"/"===a.slice(-1)&&(a=a.slice(0,-1));var s=a;return e.ForcePathStyle&&(s+="/"+t),s+="/",r&&(s+=u.camSafeUrlEncode(r).replace(/%2F/g,"/")),e.isLocation&&(s=s.replace(/^https?:\/\//,"")),s}function r(e,t){var n=u.clone(e.Headers),i="";u.each(n,(function(e,t){(""===e||["content-type","cache-control"].indexOf(t.toLowerCase())>-1)&&delete n[t],"host"===t.toLowerCase()&&(i=e)}));var a=!1!==e.ForceSignHost;!i&&e.SignHost&&a&&(n.Host=e.SignHost);var o=!1,r=function(e,n){o||(o=!0,n&&n.XCosSecurityToken&&!n.SecurityToken&&((n=u.clone(n)).SecurityToken=n.XCosSecurityToken,delete n.XCosSecurityToken),t&&t(e,n))},s=this,c=e.Bucket||"",l=e.Region||"",p="name/cos:PostObject"!==e.Action&&e.Key?e.Key:"";s.options.ForcePathStyle&&c&&(p=c+"/"+p);var d="/"+p,m={},f=e.Scope;if(!f){var h=e.Action||"",g=e.ResourceKey||e.Key||"";f=e.Scope||[{action:h,bucket:c,region:l,prefix:g}]}var v=u.md5(JSON.stringify(f));s._StsCache=s._StsCache||[],function(){var e,t;for(e=s._StsCache.length-1;e>=0;e--){t=s._StsCache[e];var n=Math.round(u.getSkewTime(s.options.SystemClockOffset)/1e3)+30;if(t.StartTime&&n<t.StartTime||n>=t.ExpiredTime)s._StsCache.splice(e,1);else if(!t.ScopeLimit||t.ScopeLimit&&t.ScopeKey===v){m=t;break}}}();var x=function(){var t="";m.StartTime&&e.Expires?t=m.StartTime+";"+(m.StartTime+1*e.Expires):m.StartTime&&m.ExpiredTime&&(t=m.StartTime+";"+m.ExpiredTime);var i={Authorization:u.getAuth({SecretId:m.TmpSecretId,SecretKey:m.TmpSecretKey,Method:e.Method,Pathname:d,Query:e.Query,Headers:n,Expires:e.Expires,SystemClockOffset:s.options.SystemClockOffset,KeyTime:t,ForceSignHost:a}),SecurityToken:m.SecurityToken||m.XCosSecurityToken||"",Token:m.Token||"",ClientIP:m.ClientIP||"",ClientUA:m.ClientUA||""};r(null,i)},y=function(e){if(e.Authorization){var t=!1,n=e.Authorization;if(n)if(n.indexOf(" ")>-1)t=!1;else if(n.indexOf("q-sign-algorithm=")>-1&&n.indexOf("q-ak=")>-1&&n.indexOf("q-sign-time=")>-1&&n.indexOf("q-key-time=")>-1&&n.indexOf("q-url-param-list=")>-1)t=!0;else try{(n=atob(n)).indexOf("a=")>-1&&n.indexOf("k=")>-1&&n.indexOf("t=")>-1&&n.indexOf("r=")>-1&&n.indexOf("b=")>-1&&(t=!0)}catch(e){}if(!t)return u.error(new Error("getAuthorization callback params format error"))}else{if(!e.TmpSecretId)return u.error(new Error('getAuthorization callback params missing "TmpSecretId"'));if(!e.TmpSecretKey)return u.error(new Error('getAuthorization callback params missing "TmpSecretKey"'));if(!e.SecurityToken&&!e.XCosSecurityToken)return u.error(new Error('getAuthorization callback params missing "SecurityToken"'));if(!e.ExpiredTime)return u.error(new Error('getAuthorization callback params missing "ExpiredTime"'));if(e.ExpiredTime&&10!==e.ExpiredTime.toString().length)return u.error(new Error('getAuthorization callback params "ExpiredTime" should be 10 digits'));if(e.StartTime&&10!==e.StartTime.toString().length)return u.error(new Error('getAuthorization callback params "StartTime" should be 10 StartTime'))}return!1};if(m.ExpiredTime&&m.ExpiredTime-u.getSkewTime(s.options.SystemClockOffset)/1e3>60)x();else if(s.options.getAuthorization)s.options.getAuthorization.call(s,{Bucket:c,Region:l,Method:e.Method,Key:p,Pathname:d,Query:e.Query,Headers:n,Scope:f,SystemClockOffset:s.options.SystemClockOffset,ForceSignHost:a},(function(e){"string"==typeof e&&(e={Authorization:e});var t=y(e);if(t)return r(t);e.Authorization?r(null,e):((m=e||{}).Scope=f,m.ScopeKey=v,s._StsCache.push(m),x())}));else{if(!s.options.getSTS)return function(){var t={Authorization:u.getAuth({SecretId:e.SecretId||s.options.SecretId,SecretKey:e.SecretKey||s.options.SecretKey,Method:e.Method,Pathname:d,Query:e.Query,Headers:n,Expires:e.Expires,SystemClockOffset:s.options.SystemClockOffset,ForceSignHost:a}),SecurityToken:s.options.SecurityToken||s.options.XCosSecurityToken};return r(null,t),t}();s.options.getSTS.call(s,{Bucket:c,Region:l},(function(e){(m=e||{}).Scope=f,m.ScopeKey=v,m.TmpSecretId||(m.TmpSecretId=m.SecretId),m.TmpSecretKey||(m.TmpSecretKey=m.SecretKey);var t=y(m);if(t)return r(t);s._StsCache.push(m),x()}))}return""}function s(e){var t=!1,n=!1,i=e.headers&&(e.headers.date||e.headers.Date)||e.error&&e.error.ServerTime;try{var a=e.error.Code,o=e.error.Message;("RequestTimeTooSkewed"===a||"AccessDenied"===a&&"Request has expired"===o)&&(n=!0)}catch(e){}if(e)if(n&&i){var r=Date.parse(i);this.options.CorrectClockSkew&&Math.abs(u.getSkewTime(this.options.SystemClockOffset)-r)>=3e4&&(console.error("error: Local time is too skewed."),this.options.SystemClockOffset=r-Date.now(),t=!0)}else 5===Math.floor(e.statusCode/100)&&(t=!0);return t}function c(e,t){var n=this;!e.headers&&(e.headers={}),!e.qs&&(e.qs={}),e.VersionId&&(e.qs.versionId=e.VersionId),e.qs=u.clearKey(e.qs),e.headers&&(e.headers=u.clearKey(e.headers)),e.qs&&(e.qs=u.clearKey(e.qs));var i=u.clone(e.qs);e.action&&(i[e.action]="");var a=e.url||e.Url,o=e.SignHost||m.call(this,{Bucket:e.Bucket,Region:e.Region,Url:a});!function a(c){var p=n.options.SystemClockOffset;r.call(n,{Bucket:e.Bucket||"",Region:e.Region||"",Method:e.method,Key:e.Key,Query:i,Headers:e.headers,SignHost:o,Action:e.Action,ResourceKey:e.ResourceKey,Scope:e.Scope,ForceSignHost:n.options.ForceSignHost},(function(i,o){i?t(i):(e.AuthData=o,l.call(n,e,(function(i,o){i&&c<2&&(p!==n.options.SystemClockOffset||s.call(n,i))?(e.headers&&(delete e.headers.Authorization,delete e.headers.token,delete e.headers.clientIP,delete e.headers.clientUA,delete e.headers["x-cos-security-token"]),a(c+1)):t(i,o)})))}))}(1)}function l(e,t){var n=this,i=e.TaskId;if(!i||n._isRunningTask(i)){var a=e.Bucket,r=e.Region,s=e.Key,c=e.method||"GET",l=e.url||e.Url,d=e.body,m=e.json,f=e.rawBody,h=n.options.HttpDNSServiceId;n.options.UseAccelerate&&(r="accelerate"),l=l||o({ForcePathStyle:n.options.ForcePathStyle,protocol:n.options.Protocol,domain:n.options.Domain,bucket:a,region:r,object:s}),e.action&&(l=l+"?"+e.action),e.qsStr&&(l=l.indexOf("?")>-1?l+"&"+e.qsStr:l+"?"+e.qsStr);var g={method:c,url:l,headers:e.headers,qs:e.qs,filePath:e.filePath,body:d,json:m,httpDNSServiceId:h},v="x-cos-security-token";u.isCIHost(l)&&(v="x-ci-security-token"),g.headers.Authorization=e.AuthData.Authorization,e.AuthData.Token&&(g.headers.token=e.AuthData.Token),e.AuthData.ClientIP&&(g.headers.clientIP=e.AuthData.ClientIP),e.AuthData.ClientUA&&(g.headers.clientUA=e.AuthData.ClientUA),e.AuthData.SecurityToken&&(g.headers[v]=e.AuthData.SecurityToken),g.headers&&(g.headers=u.clearKey(g.headers)),g=u.clearKey(g),e.onProgress&&"function"==typeof e.onProgress&&(g.onProgress=function(t){if(!i||n._isRunningTask(i)){var a=t?t.loaded:0;e.onProgress({loaded:a,total:t.total})}}),this.options.Timeout&&(g.timeout=this.options.Timeout),n.options.ForcePathStyle&&(g.pathStyle=n.options.ForcePathStyle),n.emit("before-send",g);var x=p(g,(function(e,a,o){if("abort"!==e){var r,s,c=function(e,o){if(i&&n.off("inner-kill-task",y),!r){r=!0;var s={};a&&a.statusCode&&(s.statusCode=a.statusCode),a&&a.headers&&(s.headers=a.headers),e?(e=u.extend(e||{},s),t(e,null)):(o=u.extend(o||{},s),t(null,o)),x=null}};if(e)return void c({error:e});if(f)(s={}).body=o;else try{s=o&&o.indexOf("<")>-1&&o.indexOf(">")>-1&&u.xml2json(o)||{}}catch(e){s=o||{}}var l=a.statusCode;return 2===Math.floor(l/100)?s.Error?void c({error:s.Error}):void c(null,s):void c({error:s.Error||s})}})),y=function e(t){t.TaskId===i&&(x&&x.abort&&x.abort(),n.off("inner-kill-task",e))};i&&n.on("inner-kill-task",y)}}var p=n(22),u=(n(4),n(0)),d=n(23),m=function(e){if(!e.Bucket||!e.Region)return"";var t=void 0===e.UseAccelerate?this.options.UseAccelerate:e.UseAccelerate,n=(e.Url||o({ForcePathStyle:this.options.ForcePathStyle,protocol:this.options.Protocol,domain:this.options.Domain,bucket:e.Bucket,region:t?"accelerate":e.Region})).replace(/^https?:\/\/([^/]+)(\/.*)?$/,"$1");return new RegExp("^([a-z\\d-]+-\\d+\\.)?(cos|cosv6|ci|pic)\\.([a-z\\d-]+)\\.myqcloud\\.com$").test(n)?n:""},f={getService:function(e,t){"function"==typeof e&&(t=e,e={});var n=this.options.ServiceDomain,i=e.Region;n?(n=n.replace(/\{\{Region\}\}/gi,i||"").replace(/\{\{.*?\}\}/gi,""),/^[a-zA-Z]+:\/\//.test(n)||(n="https://"+n),"/"===n.slice(-1)&&(n=n.slice(0,-1))):n=i?"https://cos."+i+".myqcloud.com":"https://service.cos.myqcloud.com",n.replace(/^https?:\/\/([^/]+)(\/.*)?$/,"$1"),c.call(this,{Action:"name/cos:GetService",url:n,method:"GET",headers:e.Headers},(function(e,n){if(e)return t(e);var i=n&&n.ListAllMyBucketsResult&&n.ListAllMyBucketsResult.Buckets&&n.ListAllMyBucketsResult.Buckets.Bucket||[];i=u.isArray(i)?i:[i];var a=n&&n.ListAllMyBucketsResult&&n.ListAllMyBucketsResult.Owner||{};t(null,{Buckets:i,Owner:a,statusCode:n.statusCode,headers:n.headers})}))},putBucket:function(e,t){var n=this,i="";if(e.BucketAZConfig){var a={BucketAZConfig:e.BucketAZConfig};i=u.json2xml({CreateBucketConfiguration:a})}c.call(this,{Action:"name/cos:PutBucket",method:"PUT",Bucket:e.Bucket,Region:e.Region,headers:e.Headers,body:i},(function(i,a){if(i)return t(i);var r=o({protocol:n.options.Protocol,domain:n.options.Domain,bucket:e.Bucket,region:e.Region,isLocation:!0});t(null,{Location:r,statusCode:a.statusCode,headers:a.headers})}))},headBucket:function(e,t){c.call(this,{Action:"name/cos:HeadBucket",Bucket:e.Bucket,Region:e.Region,headers:e.Headers,method:"HEAD"},(function(e,n){t(e,n)}))},getBucket:function(e,t){var n={};n.prefix=e.Prefix||"",n.delimiter=e.Delimiter,n.marker=e.Marker,n["max-keys"]=e.MaxKeys,n["encoding-type"]=e.EncodingType,c.call(this,{Action:"name/cos:GetBucket",ResourceKey:n.prefix,method:"GET",Bucket:e.Bucket,Region:e.Region,headers:e.Headers,qs:n},(function(e,n){if(e)return t(e);var i=n.ListBucketResult||{},a=i.Contents||[],o=i.CommonPrefixes||[];a=u.isArray(a)?a:[a],o=u.isArray(o)?o:[o];var r=u.clone(i);u.extend(r,{Contents:a,CommonPrefixes:o,statusCode:n.statusCode,headers:n.headers}),t(null,r)}))},deleteBucket:function(e,t){c.call(this,{Action:"name/cos:DeleteBucket",Bucket:e.Bucket,Region:e.Region,headers:e.Headers,method:"DELETE"},(function(e,n){return e&&204===e.statusCode?t(null,{statusCode:e.statusCode}):e?t(e):void t(null,{statusCode:n.statusCode,headers:n.headers})}))},putBucketAcl:function(e,t){var n=e.Headers,i="";if(e.AccessControlPolicy){var o=u.clone(e.AccessControlPolicy||{}),r=o.Grants||o.Grant;r=u.isArray(r)?r:[r],delete o.Grant,delete o.Grants,o.AccessControlList={Grant:r},i=u.json2xml({AccessControlPolicy:o}),n["Content-Type"]="application/xml",n["Content-MD5"]=u.binaryBase64(u.md5(i))}u.each(n,(function(e,t){0===t.indexOf("x-cos-grant-")&&(n[t]=a(n[t]))})),c.call(this,{Action:"name/cos:PutBucketACL",method:"PUT",Bucket:e.Bucket,Region:e.Region,headers:n,action:"acl",body:i},(function(e,n){if(e)return t(e);t(null,{statusCode:n.statusCode,headers:n.headers})}))},getBucketAcl:function(e,t){c.call(this,{Action:"name/cos:GetBucketACL",method:"GET",Bucket:e.Bucket,Region:e.Region,headers:e.Headers,action:"acl"},(function(e,n){if(e)return t(e);var a=n.AccessControlPolicy||{},o=a.Owner||{},r=a.AccessControlList.Grant||[];r=u.isArray(r)?r:[r];var s=i(a);n.headers&&n.headers["x-cos-acl"]&&(s.ACL=n.headers["x-cos-acl"]),s=u.extend(s,{Owner:o,Grants:r,statusCode:n.statusCode,headers:n.headers}),t(null,s)}))},putBucketCors:function(e,t){var n=(e.CORSConfiguration||{}).CORSRules||e.CORSRules||[];n=u.clone(u.isArray(n)?n:[n]),u.each(n,(function(e){u.each(["AllowedOrigin","AllowedHeader","AllowedMethod","ExposeHeader"],(function(t){var n=t+"s",i=e[n]||e[t]||[];delete e[n],e[t]=u.isArray(i)?i:[i]}))}));var i={CORSRule:n};e.ResponseVary&&(i.ResponseVary=e.ResponseVary);var a=u.json2xml({CORSConfiguration:i}),o=e.Headers;o["Content-Type"]="application/xml",o["Content-MD5"]=u.binaryBase64(u.md5(a)),c.call(this,{Action:"name/cos:PutBucketCORS",method:"PUT",Bucket:e.Bucket,Region:e.Region,body:a,action:"cors",headers:o},(function(e,n){if(e)return t(e);t(null,{statusCode:n.statusCode,headers:n.headers})}))},getBucketCors:function(e,t){c.call(this,{Action:"name/cos:GetBucketCORS",method:"GET",Bucket:e.Bucket,Region:e.Region,headers:e.Headers,action:"cors"},(function(e,n){if(e)if(404===e.statusCode&&e.error&&"NoSuchCORSConfiguration"===e.error.Code){var i={CORSRules:[],statusCode:e.statusCode};e.headers&&(i.headers=e.headers),t(null,i)}else t(e);else{var a=n.CORSConfiguration||{},o=a.CORSRules||a.CORSRule||[];o=u.clone(u.isArray(o)?o:[o]);var r=a.ResponseVary;u.each(o,(function(e){u.each(["AllowedOrigin","AllowedHeader","AllowedMethod","ExposeHeader"],(function(t){var n=t+"s",i=e[n]||e[t]||[];delete e[t],e[n]=u.isArray(i)?i:[i]}))})),t(null,{CORSRules:o,ResponseVary:r,statusCode:n.statusCode,headers:n.headers})}}))},deleteBucketCors:function(e,t){c.call(this,{Action:"name/cos:DeleteBucketCORS",method:"DELETE",Bucket:e.Bucket,Region:e.Region,headers:e.Headers,action:"cors"},(function(e,n){return e&&204===e.statusCode?t(null,{statusCode:e.statusCode}):e?t(e):void t(null,{statusCode:n.statusCode||e.statusCode,headers:n.headers})}))},getBucketLocation:function(e,t){c.call(this,{Action:"name/cos:GetBucketLocation",method:"GET",Bucket:e.Bucket,Region:e.Region,headers:e.Headers,action:"location"},(function(e,n){if(e)return t(e);t(null,n)}))},getBucketPolicy:function(e,t){c.call(this,{Action:"name/cos:GetBucketPolicy",method:"GET",Bucket:e.Bucket,Region:e.Region,headers:e.Headers,action:"policy",rawBody:!0},(function(e,n){if(e)return t(e.statusCode&&403===e.statusCode?{ErrorStatus:"Access Denied"}:e.statusCode&&405===e.statusCode?{ErrorStatus:"Method Not Allowed"}:e.statusCode&&404===e.statusCode?{ErrorStatus:"Policy Not Found"}:e);var i={};try{i=JSON.parse(n.body)}catch(e){}t(null,{Policy:i,statusCode:n.statusCode,headers:n.headers})}))},putBucketPolicy:function(e,t){var n=e.Policy,i=n;try{"string"==typeof n?n=JSON.parse(i):i=JSON.stringify(n)}catch(e){t({error:"Policy format error"})}var a=e.Headers;a["Content-Type"]="application/json",a["Content-MD5"]=u.binaryBase64(u.md5(i)),c.call(this,{Action:"name/cos:PutBucketPolicy",method:"PUT",Bucket:e.Bucket,Region:e.Region,action:"policy",body:i,headers:a,json:!0},(function(e,n){return e&&204===e.statusCode?t(null,{statusCode:e.statusCode}):e?t(e):void t(null,{statusCode:n.statusCode,headers:n.headers})}))},deleteBucketPolicy:function(e,t){c.call(this,{Action:"name/cos:DeleteBucketPolicy",method:"DELETE",Bucket:e.Bucket,Region:e.Region,headers:e.Headers,action:"policy"},(function(e,n){return e&&204===e.statusCode?t(null,{statusCode:e.statusCode}):e?t(e):void t(null,{statusCode:n.statusCode||e.statusCode,headers:n.headers})}))},putBucketTagging:function(e,t){var n=e.Tagging||{},i=n.TagSet||n.Tags||e.Tags||[];i=u.clone(u.isArray(i)?i:[i]);var a=u.json2xml({Tagging:{TagSet:{Tag:i}}}),o=e.Headers;o["Content-Type"]="application/xml",o["Content-MD5"]=u.binaryBase64(u.md5(a)),c.call(this,{Action:"name/cos:PutBucketTagging",method:"PUT",Bucket:e.Bucket,Region:e.Region,body:a,action:"tagging",headers:o},(function(e,n){return e&&204===e.statusCode?t(null,{statusCode:e.statusCode}):e?t(e):void t(null,{statusCode:n.statusCode,headers:n.headers})}))},getBucketTagging:function(e,t){c.call(this,{Action:"name/cos:GetBucketTagging",method:"GET",Bucket:e.Bucket,Region:e.Region,headers:e.Headers,action:"tagging"},(function(e,n){if(e)if(404!==e.statusCode||!e.error||"Not Found"!==e.error&&"NoSuchTagSet"!==e.error.Code)t(e);else{var i={Tags:[],statusCode:e.statusCode};e.headers&&(i.headers=e.headers),t(null,i)}else{var a=[];try{a=n.Tagging.TagSet.Tag||[]}catch(e){}a=u.clone(u.isArray(a)?a:[a]),t(null,{Tags:a,statusCode:n.statusCode,headers:n.headers})}}))},deleteBucketTagging:function(e,t){c.call(this,{Action:"name/cos:DeleteBucketTagging",method:"DELETE",Bucket:e.Bucket,Region:e.Region,headers:e.Headers,action:"tagging"},(function(e,n){return e&&204===e.statusCode?t(null,{statusCode:e.statusCode}):e?t(e):void t(null,{statusCode:n.statusCode,headers:n.headers})}))},putBucketLifecycle:function(e,t){var n=(e.LifecycleConfiguration||{}).Rules||e.Rules||[];n=u.clone(n);var i=u.json2xml({LifecycleConfiguration:{Rule:n}}),a=e.Headers;a["Content-Type"]="application/xml",a["Content-MD5"]=u.binaryBase64(u.md5(i)),c.call(this,{Action:"name/cos:PutBucketLifecycle",method:"PUT",Bucket:e.Bucket,Region:e.Region,body:i,action:"lifecycle",headers:a},(function(e,n){return e&&204===e.statusCode?t(null,{statusCode:e.statusCode}):e?t(e):void t(null,{statusCode:n.statusCode,headers:n.headers})}))},getBucketLifecycle:function(e,t){c.call(this,{Action:"name/cos:GetBucketLifecycle",method:"GET",Bucket:e.Bucket,Region:e.Region,headers:e.Headers,action:"lifecycle"},(function(e,n){if(e)if(404===e.statusCode&&e.error&&"NoSuchLifecycleConfiguration"===e.error.Code){var i={Rules:[],statusCode:e.statusCode};e.headers&&(i.headers=e.headers),t(null,i)}else t(e);else{var a=[];try{a=n.LifecycleConfiguration.Rule||[]}catch(e){}a=u.clone(u.isArray(a)?a:[a]),t(null,{Rules:a,statusCode:n.statusCode,headers:n.headers})}}))},deleteBucketLifecycle:function(e,t){c.call(this,{Action:"name/cos:DeleteBucketLifecycle",method:"DELETE",Bucket:e.Bucket,Region:e.Region,headers:e.Headers,action:"lifecycle"},(function(e,n){return e&&204===e.statusCode?t(null,{statusCode:e.statusCode}):e?t(e):void t(null,{statusCode:n.statusCode,headers:n.headers})}))},putBucketVersioning:function(e,t){if(e.VersioningConfiguration){var n=e.VersioningConfiguration||{},i=u.json2xml({VersioningConfiguration:n}),a=e.Headers;a["Content-Type"]="application/xml",a["Content-MD5"]=u.binaryBase64(u.md5(i)),c.call(this,{Action:"name/cos:PutBucketVersioning",method:"PUT",Bucket:e.Bucket,Region:e.Region,body:i,action:"versioning",headers:a},(function(e,n){return e&&204===e.statusCode?t(null,{statusCode:e.statusCode}):e?t(e):void t(null,{statusCode:n.statusCode,headers:n.headers})}))}else t({error:"missing param VersioningConfiguration"})},getBucketVersioning:function(e,t){c.call(this,{Action:"name/cos:GetBucketVersioning",method:"GET",Bucket:e.Bucket,Region:e.Region,headers:e.Headers,action:"versioning"},(function(e,n){e||!n.VersioningConfiguration&&(n.VersioningConfiguration={}),t(e,n)}))},putBucketReplication:function(e,t){var n=u.clone(e.ReplicationConfiguration),i=u.json2xml({ReplicationConfiguration:n});i=(i=i.replace(/<(\/?)Rules>/gi,"<$1Rule>")).replace(/<(\/?)Tags>/gi,"<$1Tag>");var a=e.Headers;a["Content-Type"]="application/xml",a["Content-MD5"]=u.binaryBase64(u.md5(i)),c.call(this,{Action:"name/cos:PutBucketReplication",method:"PUT",Bucket:e.Bucket,Region:e.Region,body:i,action:"replication",headers:a},(function(e,n){return e&&204===e.statusCode?t(null,{statusCode:e.statusCode}):e?t(e):void t(null,{statusCode:n.statusCode,headers:n.headers})}))},getBucketReplication:function(e,t){c.call(this,{Action:"name/cos:GetBucketReplication",method:"GET",Bucket:e.Bucket,Region:e.Region,headers:e.Headers,action:"replication"},(function(e,n){if(e)if(404!==e.statusCode||!e.error||"Not Found"!==e.error&&"ReplicationConfigurationnotFoundError"!==e.error.Code)t(e);else{var i={ReplicationConfiguration:{Rules:[]},statusCode:e.statusCode};e.headers&&(i.headers=e.headers),t(null,i)}else e||!n.ReplicationConfiguration&&(n.ReplicationConfiguration={}),n.ReplicationConfiguration.Rule&&(n.ReplicationConfiguration.Rules=n.ReplicationConfiguration.Rule,delete n.ReplicationConfiguration.Rule),t(e,n)}))},deleteBucketReplication:function(e,t){c.call(this,{Action:"name/cos:DeleteBucketReplication",method:"DELETE",Bucket:e.Bucket,Region:e.Region,headers:e.Headers,action:"replication"},(function(e,n){return e&&204===e.statusCode?t(null,{statusCode:e.statusCode}):e?t(e):void t(null,{statusCode:n.statusCode,headers:n.headers})}))},putBucketWebsite:function(e,t){if(e.WebsiteConfiguration){var n=u.clone(e.WebsiteConfiguration||{}),i=n.RoutingRules||n.RoutingRule||[];i=u.isArray(i)?i:[i],delete n.RoutingRule,delete n.RoutingRules,i.length&&(n.RoutingRules={RoutingRule:i});var a=u.json2xml({WebsiteConfiguration:n}),o=e.Headers;o["Content-Type"]="application/xml",o["Content-MD5"]=u.binaryBase64(u.md5(a)),c.call(this,{Action:"name/cos:PutBucketWebsite",method:"PUT",Bucket:e.Bucket,Region:e.Region,body:a,action:"website",headers:o},(function(e,n){return e&&204===e.statusCode?t(null,{statusCode:e.statusCode}):e?t(e):void t(null,{statusCode:n.statusCode,headers:n.headers})}))}else t({error:"missing param WebsiteConfiguration"})},getBucketWebsite:function(e,t){c.call(this,{Action:"name/cos:GetBucketWebsite",method:"GET",Bucket:e.Bucket,Region:e.Region,Key:e.Key,headers:e.Headers,action:"website"},(function(e,n){if(e)if(404===e.statusCode&&"NoSuchWebsiteConfiguration"===e.error.Code){var i={WebsiteConfiguration:{},statusCode:e.statusCode};e.headers&&(i.headers=e.headers),t(null,i)}else t(e);else{var a=n.WebsiteConfiguration||{};if(a.RoutingRules){var o=u.clone(a.RoutingRules.RoutingRule||[]);o=u.makeArray(o),a.RoutingRules=o}t(null,{WebsiteConfiguration:a,statusCode:n.statusCode,headers:n.headers})}}))},deleteBucketWebsite:function(e,t){c.call(this,{Action:"name/cos:DeleteBucketWebsite",method:"DELETE",Bucket:e.Bucket,Region:e.Region,headers:e.Headers,action:"website"},(function(e,n){return e&&204===e.statusCode?t(null,{statusCode:e.statusCode}):e?t(e):void t(null,{statusCode:n.statusCode,headers:n.headers})}))},putBucketReferer:function(e,t){if(e.RefererConfiguration){var n=u.clone(e.RefererConfiguration||{}),i=n.DomainList||{},a=i.Domains||i.Domain||[];(a=u.isArray(a)?a:[a]).length&&(n.DomainList={Domain:a});var o=u.json2xml({RefererConfiguration:n}),r=e.Headers;r["Content-Type"]="application/xml",r["Content-MD5"]=u.binaryBase64(u.md5(o)),c.call(this,{Action:"name/cos:PutBucketReferer",method:"PUT",Bucket:e.Bucket,Region:e.Region,body:o,action:"referer",headers:r},(function(e,n){return e&&204===e.statusCode?t(null,{statusCode:e.statusCode}):e?t(e):void t(null,{statusCode:n.statusCode,headers:n.headers})}))}else t({error:"missing param RefererConfiguration"})},getBucketReferer:function(e,t){c.call(this,{Action:"name/cos:GetBucketReferer",method:"GET",Bucket:e.Bucket,Region:e.Region,Key:e.Key,headers:e.Headers,action:"referer"},(function(e,n){if(e)if(404===e.statusCode&&"NoSuchRefererConfiguration"===e.error.Code){var i={WebsiteConfiguration:{},statusCode:e.statusCode};e.headers&&(i.headers=e.headers),t(null,i)}else t(e);else{var a=n.RefererConfiguration||{};if(a.DomainList){var o=u.makeArray(a.DomainList.Domain||[]);a.DomainList={Domains:o}}t(null,{RefererConfiguration:a,statusCode:n.statusCode,headers:n.headers})}}))},putBucketDomain:function(e,t){var n=(e.DomainConfiguration||{}).DomainRule||e.DomainRule||[];n=u.clone(n);var i=u.json2xml({DomainConfiguration:{DomainRule:n}}),a=e.Headers;a["Content-Type"]="application/xml",a["Content-MD5"]=u.binaryBase64(u.md5(i)),c.call(this,{Action:"name/cos:PutBucketDomain",method:"PUT",Bucket:e.Bucket,Region:e.Region,body:i,action:"domain",headers:a},(function(e,n){return e&&204===e.statusCode?t(null,{statusCode:e.statusCode}):e?t(e):void t(null,{statusCode:n.statusCode,headers:n.headers})}))},getBucketDomain:function(e,t){c.call(this,{Action:"name/cos:GetBucketDomain",method:"GET",Bucket:e.Bucket,Region:e.Region,headers:e.Headers,action:"domain"},(function(e,n){if(e)return t(e);var i=[];try{i=n.DomainConfiguration.DomainRule||[]}catch(e){}i=u.clone(u.isArray(i)?i:[i]),t(null,{DomainRule:i,statusCode:n.statusCode,headers:n.headers})}))},deleteBucketDomain:function(e,t){c.call(this,{Action:"name/cos:DeleteBucketDomain",method:"DELETE",Bucket:e.Bucket,Region:e.Region,headers:e.Headers,action:"domain"},(function(e,n){return e&&204===e.statusCode?t(null,{statusCode:e.statusCode}):e?t(e):void t(null,{statusCode:n.statusCode,headers:n.headers})}))},putBucketOrigin:function(e,t){var n=(e.OriginConfiguration||{}).OriginRule||e.OriginRule||[];n=u.clone(n);var i=u.json2xml({OriginConfiguration:{OriginRule:n}}),a=e.Headers;a["Content-Type"]="application/xml",a["Content-MD5"]=u.binaryBase64(u.md5(i)),c.call(this,{Action:"name/cos:PutBucketOrigin",method:"PUT",Bucket:e.Bucket,Region:e.Region,body:i,action:"origin",headers:a},(function(e,n){return e&&204===e.statusCode?t(null,{statusCode:e.statusCode}):e?t(e):void t(null,{statusCode:n.statusCode,headers:n.headers})}))},getBucketOrigin:function(e,t){c.call(this,{Action:"name/cos:GetBucketOrigin",method:"GET",Bucket:e.Bucket,Region:e.Region,headers:e.Headers,action:"origin"},(function(e,n){if(e)return t(e);var i=[];try{i=n.OriginConfiguration.OriginRule||[]}catch(e){}i=u.clone(u.isArray(i)?i:[i]),t(null,{OriginRule:i,statusCode:n.statusCode,headers:n.headers})}))},deleteBucketOrigin:function(e,t){c.call(this,{Action:"name/cos:DeleteBucketOrigin",method:"DELETE",Bucket:e.Bucket,Region:e.Region,headers:e.Headers,action:"origin"},(function(e,n){return e&&204===e.statusCode?t(null,{statusCode:e.statusCode}):e?t(e):void t(null,{statusCode:n.statusCode,headers:n.headers})}))},putBucketLogging:function(e,t){var n=u.json2xml({BucketLoggingStatus:e.BucketLoggingStatus||""}),i=e.Headers;i["Content-Type"]="application/xml",i["Content-MD5"]=u.binaryBase64(u.md5(n)),c.call(this,{Action:"name/cos:PutBucketLogging",method:"PUT",Bucket:e.Bucket,Region:e.Region,body:n,action:"logging",headers:i},(function(e,n){return e&&204===e.statusCode?t(null,{statusCode:e.statusCode}):e?t(e):void t(null,{statusCode:n.statusCode,headers:n.headers})}))},getBucketLogging:function(e,t){c.call(this,{Action:"name/cos:GetBucketLogging",method:"GET",Bucket:e.Bucket,Region:e.Region,headers:e.Headers,action:"logging"},(function(e,n){if(e)return t(e);delete n.BucketLoggingStatus._xmlns,t(null,{BucketLoggingStatus:n.BucketLoggingStatus,statusCode:n.statusCode,headers:n.headers})}))},putBucketInventory:function(e,t){var n=u.clone(e.InventoryConfiguration);if(n.OptionalFields){var i=n.OptionalFields||[];n.OptionalFields={Field:i}}if(n.Destination&&n.Destination.COSBucketDestination&&n.Destination.COSBucketDestination.Encryption){var a=n.Destination.COSBucketDestination.Encryption;Object.keys(a).indexOf("SSECOS")>-1&&(a["SSE-COS"]=a.SSECOS,delete a.SSECOS)}var o=u.json2xml({InventoryConfiguration:n}),r=e.Headers;r["Content-Type"]="application/xml",r["Content-MD5"]=u.binaryBase64(u.md5(o)),c.call(this,{Action:"name/cos:PutBucketInventory",method:"PUT",Bucket:e.Bucket,Region:e.Region,body:o,action:"inventory",qs:{id:e.Id},headers:r},(function(e,n){return e&&204===e.statusCode?t(null,{statusCode:e.statusCode}):e?t(e):void t(null,{statusCode:n.statusCode,headers:n.headers})}))},getBucketInventory:function(e,t){c.call(this,{Action:"name/cos:GetBucketInventory",method:"GET",Bucket:e.Bucket,Region:e.Region,headers:e.Headers,action:"inventory",qs:{id:e.Id}},(function(e,n){if(e)return t(e);var i=n.InventoryConfiguration;if(i&&i.OptionalFields&&i.OptionalFields.Field){var a=i.OptionalFields.Field;u.isArray(a)||(a=[a]),i.OptionalFields=a}if(i.Destination&&i.Destination.COSBucketDestination&&i.Destination.COSBucketDestination.Encryption){var o=i.Destination.COSBucketDestination.Encryption;Object.keys(o).indexOf("SSE-COS")>-1&&(o.SSECOS=o["SSE-COS"],delete o["SSE-COS"])}t(null,{InventoryConfiguration:i,statusCode:n.statusCode,headers:n.headers})}))},listBucketInventory:function(e,t){c.call(this,{Action:"name/cos:ListBucketInventory",method:"GET",Bucket:e.Bucket,Region:e.Region,headers:e.Headers,action:"inventory",qs:{"continuation-token":e.ContinuationToken}},(function(e,n){if(e)return t(e);var i=n.ListInventoryConfigurationResult,a=i.InventoryConfiguration||[];a=u.isArray(a)?a:[a],delete i.InventoryConfiguration,u.each(a,(function(e){if(e&&e.OptionalFields&&e.OptionalFields.Field){var t=e.OptionalFields.Field;u.isArray(t)||(t=[t]),e.OptionalFields=t}if(e.Destination&&e.Destination.COSBucketDestination&&e.Destination.COSBucketDestination.Encryption){var n=e.Destination.COSBucketDestination.Encryption;Object.keys(n).indexOf("SSE-COS")>-1&&(n.SSECOS=n["SSE-COS"],delete n["SSE-COS"])}})),i.InventoryConfigurations=a,u.extend(i,{statusCode:n.statusCode,headers:n.headers}),t(null,i)}))},deleteBucketInventory:function(e,t){c.call(this,{Action:"name/cos:DeleteBucketInventory",method:"DELETE",Bucket:e.Bucket,Region:e.Region,headers:e.Headers,action:"inventory",qs:{id:e.Id}},(function(e,n){return e&&204===e.statusCode?t(null,{statusCode:e.statusCode}):e?t(e):void t(null,{statusCode:n.statusCode,headers:n.headers})}))},putBucketAccelerate:function(e,t){if(e.AccelerateConfiguration){var n={AccelerateConfiguration:e.AccelerateConfiguration||{}},i=u.json2xml(n),a={"Content-Type":"application/xml"};a["Content-MD5"]=u.binaryBase64(u.md5(i)),c.call(this,{Interface:"putBucketAccelerate",Action:"name/cos:PutBucketAccelerate",method:"PUT",Bucket:e.Bucket,Region:e.Region,body:i,action:"accelerate",headers:a},(function(e,n){if(e)return t(e);t(null,{statusCode:n.statusCode,headers:n.headers})}))}else t({error:"missing param AccelerateConfiguration"})},getBucketAccelerate:function(e,t){c.call(this,{Interface:"getBucketAccelerate",Action:"name/cos:GetBucketAccelerate",method:"GET",Bucket:e.Bucket,Region:e.Region,action:"accelerate"},(function(e,n){e||!n.AccelerateConfiguration&&(n.AccelerateConfiguration={}),t(e,n)}))},getObject:function(e,t){var n=e.Query||{},i=e.QueryString||"";n["response-content-type"]=e.ResponseContentType,n["response-content-language"]=e.ResponseContentLanguage,n["response-expires"]=e.ResponseExpires,n["response-cache-control"]=e.ResponseCacheControl,n["response-content-disposition"]=e.ResponseContentDisposition,n["response-content-encoding"]=e.ResponseContentEncoding,c.call(this,{Action:"name/cos:GetObject",method:"GET",Bucket:e.Bucket,Region:e.Region,Key:e.Key,VersionId:e.VersionId,headers:e.Headers,qs:n,qsStr:i,rawBody:!0},(function(n,i){if(n){var a=n.statusCode;return e.Headers["If-Modified-Since"]&&a&&304===a?t(null,{NotModified:!0}):t(n)}t(null,{Body:i.body,ETag:u.attr(i.headers,"etag",""),statusCode:i.statusCode,headers:i.headers})}))},headObject:function(e,t){c.call(this,{Action:"name/cos:HeadObject",method:"HEAD",Bucket:e.Bucket,Region:e.Region,Key:e.Key,VersionId:e.VersionId,headers:e.Headers},(function(n,i){if(n){var a=n.statusCode;return e.Headers["If-Modified-Since"]&&a&&304===a?t(null,{NotModified:!0,statusCode:a}):t(n)}i.ETag=u.attr(i.headers,"etag",""),t(null,i)}))},listObjectVersions:function(e,t){var n={};n.prefix=e.Prefix||"",n.delimiter=e.Delimiter,n["key-marker"]=e.KeyMarker,n["version-id-marker"]=e.VersionIdMarker,n["max-keys"]=e.MaxKeys,n["encoding-type"]=e.EncodingType,c.call(this,{Action:"name/cos:GetBucketObjectVersions",ResourceKey:n.prefix,method:"GET",Bucket:e.Bucket,Region:e.Region,headers:e.Headers,qs:n,action:"versions"},(function(e,n){if(e)return t(e);var i=n.ListVersionsResult||{},a=i.DeleteMarker||[];a=u.isArray(a)?a:[a];var o=i.Version||[];o=u.isArray(o)?o:[o];var r=u.clone(i);delete r.DeleteMarker,delete r.Version,u.extend(r,{DeleteMarkers:a,Versions:o,statusCode:n.statusCode,headers:n.headers}),t(null,r)}))},putObject:function(e,t){var n=this,i=e.ContentLength,a=u.throttleOnProgress.call(n,i,e.onProgress),r=e.Headers;r["Cache-Control"]||r["cache-control"]||(r["Cache-Control"]=""),r["Content-Type"]||r["content-type"]||(r["Content-Type"]=d.getType(e.Key)||"application/octet-stream"),u.getBodyMd5(n.options.UploadCheckContentMd5,e.Body,(function(s){s&&(r["Content-MD5"]=u.binaryBase64(s)),void 0!==e.ContentLength&&(r["Content-Length"]=e.ContentLength),a(null,!0),c.call(n,{Action:"name/cos:PutObject",TaskId:e.TaskId,method:"PUT",Bucket:e.Bucket,Region:e.Region,Key:e.Key,headers:e.Headers,qs:e.Query,body:e.Body,onProgress:a},(function(r,s){if(r)return a(null,!0),t(r);a({loaded:i,total:i},!0);var c=o({ForcePathStyle:n.options.ForcePathStyle,protocol:n.options.Protocol,domain:n.options.Domain,bucket:e.Bucket,region:n.options.UseAccelerate?"accelerate":e.Region,object:e.Key});c=c.substr(c.indexOf("://")+3),s.Location=c,s.ETag=u.attr(s.headers,"etag",""),t(null,s)}))}))},postObject:function(e,t){var n=this,i={},a=e.FilePath;if(a){for(var r in i["Cache-Control"]=e.CacheControl,i["Content-Disposition"]=e.ContentDisposition,i["Content-Encoding"]=e.ContentEncoding,i["Content-MD5"]=e.ContentMD5,i["Content-Length"]=e.ContentLength,i["Content-Type"]=e.ContentType,i.Expect=e.Expect,i.Expires=e.Expires,i["x-cos-acl"]=e.ACL,i["x-cos-grant-read"]=e.GrantRead,i["x-cos-grant-write"]=e.GrantWrite,i["x-cos-grant-full-control"]=e.GrantFullControl,i["x-cos-storage-class"]=e.StorageClass,i["x-cos-mime-limit"]=e.MimeLimit,i["x-cos-traffic-limit"]=e.TrafficLimit,i["x-cos-server-side-encryption-customer-algorithm"]=e.SSECustomerAlgorithm,i["x-cos-server-side-encryption-customer-key"]=e.SSECustomerKey,i["x-cos-server-side-encryption-customer-key-MD5"]=e.SSECustomerKeyMD5,i["x-cos-server-side-encryption"]=e.ServerSideEncryption,i["x-cos-server-side-encryption-cos-kms-key-id"]=e.SSEKMSKeyId,i["x-cos-server-side-encryption-context"]=e.SSEContext,delete i["Content-Length"],delete i["content-length"],e)r.indexOf("x-cos-meta-")>-1&&(i[r]=e[r]);var s=u.throttleOnProgress.call(n,i["Content-Length"],e.onProgress);c.call(this,{Action:"name/cos:PostObject",method:"POST",Bucket:e.Bucket,Region:e.Region,Key:e.Key,headers:i,qs:e.Query,filePath:a,TaskId:e.TaskId,onProgress:s},(function(i,r){if(s(null,!0),i)return t(i);if(r&&r.headers){var c=r.headers,l=c.etag||c.Etag||c.ETag||"",p=a.substr(a.lastIndexOf("/")+1),u=o({ForcePathStyle:n.options.ForcePathStyle,protocol:n.options.Protocol,domain:n.options.Domain,bucket:e.Bucket,region:e.Region,object:e.Key.replace(/\$\{filename\}/g,p),isLocation:!0});return t(null,{Location:u,statusCode:r.statusCode,headers:c,ETag:l})}t(null,r)}))}else t({error:"missing param FilePath"})},deleteObject:function(e,t){c.call(this,{Action:"name/cos:DeleteObject",method:"DELETE",Bucket:e.Bucket,Region:e.Region,Key:e.Key,headers:e.Headers,VersionId:e.VersionId},(function(e,n){if(e){var i=e.statusCode;return i&&204===i?t(null,{statusCode:i}):i&&404===i?t(null,{BucketNotFound:!0,statusCode:i}):t(e)}t(null,{statusCode:n.statusCode,headers:n.headers})}))},getObjectAcl:function(e,t){c.call(this,{Action:"name/cos:GetObjectACL",method:"GET",Bucket:e.Bucket,Region:e.Region,Key:e.Key,headers:e.Headers,action:"acl"},(function(e,n){if(e)return t(e);var a=n.AccessControlPolicy||{},o=a.Owner||{},r=a.AccessControlList&&a.AccessControlList.Grant||[];r=u.isArray(r)?r:[r];var s=i(a);n.headers&&n.headers["x-cos-acl"]&&(s.ACL=n.headers["x-cos-acl"]),s=u.extend(s,{Owner:o,Grants:r,statusCode:n.statusCode,headers:n.headers}),t(null,s)}))},putObjectAcl:function(e,t){var n=e.Headers,i="";if(e.AccessControlPolicy){var o=u.clone(e.AccessControlPolicy||{}),r=o.Grants||o.Grant;r=u.isArray(r)?r:[r],delete o.Grant,delete o.Grants,o.AccessControlList={Grant:r},i=u.json2xml({AccessControlPolicy:o}),n["Content-Type"]="application/xml",n["Content-MD5"]=u.binaryBase64(u.md5(i))}u.each(n,(function(e,t){0===t.indexOf("x-cos-grant-")&&(n[t]=a(n[t]))})),c.call(this,{Action:"name/cos:PutObjectACL",method:"PUT",Bucket:e.Bucket,Region:e.Region,Key:e.Key,action:"acl",headers:n,body:i},(function(e,n){if(e)return t(e);t(null,{statusCode:n.statusCode,headers:n.headers})}))},optionsObject:function(e,t){var n=e.Headers;n.Origin=e.Origin,n["Access-Control-Request-Method"]=e.AccessControlRequestMethod,n["Access-Control-Request-Headers"]=e.AccessControlRequestHeaders,c.call(this,{Action:"name/cos:OptionsObject",method:"OPTIONS",Bucket:e.Bucket,Region:e.Region,Key:e.Key,headers:n},(function(e,n){if(e)return e.statusCode&&403===e.statusCode?t(null,{OptionsForbidden:!0,statusCode:e.statusCode}):t(e);var i=n.headers||{};t(null,{AccessControlAllowOrigin:i["access-control-allow-origin"],AccessControlAllowMethods:i["access-control-allow-methods"],AccessControlAllowHeaders:i["access-control-allow-headers"],AccessControlExposeHeaders:i["access-control-expose-headers"],AccessControlMaxAge:i["access-control-max-age"],statusCode:n.statusCode,headers:n.headers})}))},putObjectCopy:function(e,t){var n=e.Headers;!n["Cache-Control"]&&n["cache-control"]&&(n["Cache-Control"]="");var i=(e.CopySource||"").match(/^([^.]+-\d+)\.cos(v6)?\.([^.]+)\.[^/]+\/(.+)$/);if(i){var a=i[1],o=i[3],r=decodeURIComponent(i[4]);c.call(this,{Scope:[{action:"name/cos:GetObject",bucket:a,region:o,prefix:r},{action:"name/cos:PutObject",bucket:e.Bucket,region:e.Region,prefix:e.Key}],method:"PUT",Bucket:e.Bucket,Region:e.Region,Key:e.Key,VersionId:e.VersionId,headers:e.Headers},(function(e,n){if(e)return t(e);var i=u.clone(n.CopyObjectResult||{});u.extend(i,{statusCode:n.statusCode,headers:n.headers}),t(null,i)}))}else t({error:"CopySource format error"})},deleteMultipleObject:function(e,t){var n=e.Objects||[],i=e.Quiet;n=u.isArray(n)?n:[n];var a=u.json2xml({Delete:{Object:n,Quiet:i||!1}}),o=e.Headers;o["Content-Type"]="application/xml",o["Content-MD5"]=u.binaryBase64(u.md5(a));var r=u.map(n,(function(t){return{action:"name/cos:DeleteObject",bucket:e.Bucket,region:e.Region,prefix:t.Key}}));c.call(this,{Scope:r,method:"POST",Bucket:e.Bucket,Region:e.Region,body:a,action:"delete",headers:o},(function(e,n){if(e)return t(e);var i=n.DeleteResult||{},a=i.Deleted||[],o=i.Error||[];a=u.isArray(a)?a:[a],o=u.isArray(o)?o:[o];var r=u.clone(i);u.extend(r,{Error:o,Deleted:a,statusCode:n.statusCode,headers:n.headers}),t(null,r)}))},restoreObject:function(e,t){var n=e.Headers;if(e.RestoreRequest){var i=e.RestoreRequest||{},a=u.json2xml({RestoreRequest:i});n["Content-Type"]="application/xml",n["Content-MD5"]=u.binaryBase64(u.md5(a)),c.call(this,{Action:"name/cos:RestoreObject",method:"POST",Bucket:e.Bucket,Region:e.Region,Key:e.Key,VersionId:e.VersionId,body:a,action:"restore",headers:n},(function(e,n){t(e,n)}))}else t({error:"missing param RestoreRequest"})},putObjectTagging:function(e,t){var n=e.Tagging||{},i=n.TagSet||n.Tags||e.Tags||[];i=u.clone(u.isArray(i)?i:[i]);var a=u.json2xml({Tagging:{TagSet:{Tag:i}}}),o=e.Headers;o["Content-Type"]="application/xml",o["Content-MD5"]=u.binaryBase64(u.md5(a)),c.call(this,{Interface:"putObjectTagging",Action:"name/cos:PutObjectTagging",method:"PUT",Bucket:e.Bucket,Key:e.Key,Region:e.Region,body:a,action:"tagging",headers:o,VersionId:e.VersionId},(function(e,n){return e&&204===e.statusCode?t(null,{statusCode:e.statusCode}):e?t(e):void t(null,{statusCode:n.statusCode,headers:n.headers})}))},getObjectTagging:function(e,t){c.call(this,{Interface:"getObjectTagging",Action:"name/cos:GetObjectTagging",method:"GET",Key:e.Key,Bucket:e.Bucket,Region:e.Region,headers:e.Headers,action:"tagging",VersionId:e.VersionId},(function(e,n){if(e)if(404!==e.statusCode||!e.error||"Not Found"!==e.error&&"NoSuchTagSet"!==e.error.Code)t(e);else{var i={Tags:[],statusCode:e.statusCode};e.headers&&(i.headers=e.headers),t(null,i)}else{var a=[];try{a=n.Tagging.TagSet.Tag||[]}catch(e){}a=u.clone(u.isArray(a)?a:[a]),t(null,{Tags:a,statusCode:n.statusCode,headers:n.headers})}}))},deleteObjectTagging:function(e,t){c.call(this,{Interface:"deleteObjectTagging",Action:"name/cos:DeleteObjectTagging",method:"DELETE",Bucket:e.Bucket,Region:e.Region,Key:e.Key,headers:e.Headers,action:"tagging",VersionId:e.VersionId},(function(e,n){return e&&204===e.statusCode?t(null,{statusCode:e.statusCode}):e?t(e):void t(null,{statusCode:n.statusCode,headers:n.headers})}))},appendObject:function(e,t){c.call(this,{Action:"name/cos:AppendObject",method:"POST",Bucket:e.Bucket,Region:e.Region,action:"append",Key:e.Key,body:e.Body,qs:{position:e.Position},headers:e.Headers},(function(e,n){if(e)return t(e);t(null,n)}))},uploadPartCopy:function(e,t){var n=(e.CopySource||"").match(/^([^.]+-\d+)\.cos(v6)?\.([^.]+)\.[^/]+\/(.+)$/);if(n){var i=n[1],a=n[3],o=decodeURIComponent(n[4]);c.call(this,{Scope:[{action:"name/cos:GetObject",bucket:i,region:a,prefix:o},{action:"name/cos:PutObject",bucket:e.Bucket,region:e.Region,prefix:e.Key}],method:"PUT",Bucket:e.Bucket,Region:e.Region,Key:e.Key,VersionId:e.VersionId,qs:{partNumber:e.PartNumber,uploadId:e.UploadId},headers:e.Headers},(function(e,n){if(e)return t(e);var i=u.clone(n.CopyPartResult||{});u.extend(i,{statusCode:n.statusCode,headers:n.headers}),t(null,i)}))}else t({error:"CopySource format error"})},multipartInit:function(e,t){var n=e.Headers;n["Cache-Control"]||n["cache-control"]||(n["Cache-Control"]=""),n["Content-Type"]||n["content-type"]||(n["Content-Type"]=d.getType(e.Key)||"application/octet-stream"),c.call(this,{Action:"name/cos:InitiateMultipartUpload",method:"POST",Bucket:e.Bucket,Region:e.Region,Key:e.Key,action:"uploads",headers:e.Headers,qs:e.Query},(function(e,n){return e?t(e):(n=u.clone(n||{}))&&n.InitiateMultipartUploadResult?t(null,u.extend(n.InitiateMultipartUploadResult,{statusCode:n.statusCode,headers:n.headers})):void t(null,n)}))},multipartUpload:function(e,t){var n=this;u.getFileSize("multipartUpload",e,(function(){u.getBodyMd5(n.options.UploadCheckContentMd5,e.Body,(function(i){i&&(e.Headers["Content-MD5"]=u.binaryBase64(i)),c.call(n,{Action:"name/cos:UploadPart",TaskId:e.TaskId,method:"PUT",Bucket:e.Bucket,Region:e.Region,Key:e.Key,qs:{partNumber:e.PartNumber,uploadId:e.UploadId},headers:e.Headers,onProgress:e.onProgress,body:e.Body||null},(function(e,n){if(e)return t(e);t(null,{ETag:u.attr(n.headers,"etag",{}),statusCode:n.statusCode,headers:n.headers})}))}))}))},multipartComplete:function(e,t){for(var n=this,i=e.UploadId,a=e.Parts,r=0,s=a.length;r<s;r++)0!==a[r].ETag.indexOf('"')&&(a[r].ETag='"'+a[r].ETag+'"');var l=u.json2xml({CompleteMultipartUpload:{Part:a}}),p=e.Headers;p["Content-Type"]="application/xml",p["Content-MD5"]=u.binaryBase64(u.md5(l)),c.call(this,{Action:"name/cos:CompleteMultipartUpload",method:"POST",Bucket:e.Bucket,Region:e.Region,Key:e.Key,qs:{uploadId:i},body:l,headers:p},(function(i,a){if(i)return t(i);var r=o({ForcePathStyle:n.options.ForcePathStyle,protocol:n.options.Protocol,domain:n.options.Domain,bucket:e.Bucket,region:e.Region,object:e.Key,isLocation:!0}),s=a.CompleteMultipartUploadResult||{},c=u.extend(s,{Location:r,statusCode:a.statusCode,headers:a.headers});t(null,c)}))},multipartList:function(e,t){var n={};n.delimiter=e.Delimiter,n["encoding-type"]=e.EncodingType,n.prefix=e.Prefix||"",n["max-uploads"]=e.MaxUploads,n["key-marker"]=e.KeyMarker,n["upload-id-marker"]=e.UploadIdMarker,n=u.clearKey(n),c.call(this,{Action:"name/cos:ListMultipartUploads",ResourceKey:n.prefix,method:"GET",Bucket:e.Bucket,Region:e.Region,headers:e.Headers,qs:n,action:"uploads"},(function(e,n){if(e)return t(e);if(n&&n.ListMultipartUploadsResult){var i=n.ListMultipartUploadsResult.Upload||[],a=n.ListMultipartUploadsResult.CommonPrefixes||[];a=u.isArray(a)?a:[a],i=u.isArray(i)?i:[i],n.ListMultipartUploadsResult.Upload=i,n.ListMultipartUploadsResult.CommonPrefixes=a}var o=u.clone(n.ListMultipartUploadsResult||{});u.extend(o,{statusCode:n.statusCode,headers:n.headers}),t(null,o)}))},multipartListPart:function(e,t){var n={};n.uploadId=e.UploadId,n["encoding-type"]=e.EncodingType,n["max-parts"]=e.MaxParts,n["part-number-marker"]=e.PartNumberMarker,c.call(this,{Action:"name/cos:ListParts",method:"GET",Bucket:e.Bucket,Region:e.Region,Key:e.Key,headers:e.Headers,qs:n},(function(e,n){if(e)return t(e);var i=n.ListPartsResult||{},a=i.Part||[];a=u.isArray(a)?a:[a],i.Part=a;var o=u.clone(i);u.extend(o,{statusCode:n.statusCode,headers:n.headers}),t(null,o)}))},multipartAbort:function(e,t){var n={};n.uploadId=e.UploadId,c.call(this,{Action:"name/cos:AbortMultipartUpload",method:"DELETE",Bucket:e.Bucket,Region:e.Region,Key:e.Key,headers:e.Headers,qs:n},(function(e,n){if(e)return t(e);t(null,{statusCode:n.statusCode,headers:n.headers})}))},request:function(e,t){c.call(this,{method:e.Method,Bucket:e.Bucket,Region:e.Region,Key:e.Key,action:e.Action,headers:e.Headers,qs:e.Query,body:e.Body,Url:e.Url,rawBody:e.RawBody},(function(e,n){if(e)return t(e);n&&n.body&&(n.Body=n.body,delete n.body),t(e,n)}))},getObjectUrl:function(e,t){var n=this,i=void 0===e.UseAccelerate?n.options.UseAccelerate:e.UseAccelerate,a=o({ForcePathStyle:n.options.ForcePathStyle,protocol:e.Protocol||n.options.Protocol,domain:e.Domain||n.options.Domain,bucket:e.Bucket,region:i?"accelerate":e.Region,object:e.Key}),s="";e.Query&&(s+=u.obj2str(e.Query)),e.QueryString&&(s+=(s?"&":"")+e.QueryString);var c=a;if(void 0!==e.Sign&&!e.Sign)return s&&(c+="?"+s),t(null,{Url:c}),c;var l=m.call(this,{Bucket:e.Bucket,Region:e.Region,UseAccelerate:e.UseAccelerate,Url:a}),p=r.call(this,{Action:"PUT"===(e.Method||"").toUpperCase()?"name/cos:PutObject":"name/cos:GetObject",Bucket:e.Bucket||"",Region:e.Region||"",Method:e.Method||"get",Key:e.Key,Expires:e.Expires,Headers:e.Headers,Query:e.Query,SignHost:l,ForceSignHost:!1!==e.ForceSignHost&&n.options.ForceSignHost},(function(e,n){if(t){if(e)return void t(e);var i=a;i+="?"+(n.Authorization.indexOf("q-signature")>-1?function(e){var t=e.match(/q-url-param-list.*?(?=&)/g)[0],n="q-url-param-list="+encodeURIComponent(t.replace(/q-url-param-list=/,"")).toLowerCase(),i=new RegExp(t,"g");return e.replace(i,n)}(n.Authorization):"sign="+encodeURIComponent(n.Authorization)),n.SecurityToken&&(i+="&x-cos-security-token="+n.SecurityToken),n.ClientIP&&(i+="&clientIP="+n.ClientIP),n.ClientUA&&(i+="&clientUA="+n.ClientUA),n.Token&&(i+="&token="+n.Token),s&&(i+="&"+s),setTimeout((function(){t(null,{Url:i})}))}}));return p?(c+="?"+p.Authorization+(p.SecurityToken?"&x-cos-security-token="+p.SecurityToken:""),s&&(c+="&"+s)):s&&(c+="?"+s),c},getAuth:function(e){return u.getAuth({SecretId:e.SecretId||this.options.SecretId||"",SecretKey:e.SecretKey||this.options.SecretKey||"",Bucket:e.Bucket,Region:e.Region,Method:e.Method,Key:e.Key,Query:e.Query,Headers:e.Headers,Expires:e.Expires,SystemClockOffset:this.options.SystemClockOffset})}};e.exports.init=function(e,t){t.transferToTaskMethod(f,"postObject"),t.transferToTaskMethod(f,"putObject"),u.each(f,(function(t,n){e.prototype[n]=u.apiWrapper(n,t)}))}},function(e,t,n){function i(e){return encodeURIComponent(e).replace(/!/g,"%21").replace(/'/g,"%27").replace(/\(/g,"%28").replace(/\)/g,"%29").replace(/\*/g,"%2A")}var a=function(e,t){var n,a,o,r=[],s=function(e,t){var n=[];for(var a in e)e.hasOwnProperty(a)&&n.push(t?i(a).toLowerCase():a);return n.sort((function(e,t){return(e=e.toLowerCase())===(t=t.toLowerCase())?0:e>t?1:-1}))}(e);for(n=0;n<s.length;n++)a=s[n],o=void 0===e[a]||null===e[a]?"":""+e[a],a=t?i(a).toLowerCase():i(a),o=i(o)||"",r.push(a+"="+o);return r.join("&")};e.exports=function(e,t){var n,i=e.filePath,o=e.headers||{},r=e.url||e.Url,s=e.method,c=e.onProgress,l=e.httpDNSServiceId,p=function(e,n){var i=n.header,a={};if(i)for(var o in i)i.hasOwnProperty(o)&&(a[o.toLowerCase()]=i[o]);t(e,{statusCode:n.statusCode,headers:a},n.data)};if(i){var u,d=r.match(/^(https?:\/\/[^/]+\/)([^/]*\/?)(.*)$/);e.pathStyle?(u=decodeURIComponent(d[3]||""),r=d[1]+d[2]):(u=decodeURIComponent(d[2]+d[3]||""),r=d[1]);var m={key:u,success_action_status:200,Signature:o.Authorization},f=["Cache-Control","Content-Type","Content-Disposition","Content-Encoding","Expires","x-cos-storage-class","x-cos-security-token","x-ci-security-token"];for(var h in e.headers)e.headers.hasOwnProperty(h)&&(h.indexOf("x-cos-meta-")>-1||f.indexOf(h)>-1)&&(m[h]=e.headers[h]);o["x-cos-acl"]&&(m.acl=o["x-cos-acl"]),!m["Content-Type"]&&(m["Content-Type"]=""),(n=wx.uploadFile({url:r,method:s,name:"file",header:o,filePath:i,formData:m,timeout:e.timeout,success:function(e){p(null,e)},fail:function(e){p(e.errMsg,e)}})).onProgressUpdate((function(e){c&&c({loaded:e.totalBytesSent,total:e.totalBytesExpectedToSend,progress:e.progress/100})}))}else{var g=e.qs&&a(e.qs)||"";g&&(r+=(r.indexOf("?")>-1?"&":"?")+g),o["Content-Length"]&&delete o["Content-Length"];var v={url:r,method:s,header:o,dataType:"text",data:e.body,timeout:e.timeout,success:function(e){p(null,e)},fail:function(e){p(e.errMsg,e)}};l&&Object.assign(v,{enableHttpDNS:!0,httpDNSServiceId:l}),n=wx.request(v)}return n}},function(e,t,n){var i=n(24);e.exports=new i(n(25),n(26))},function(e,t,n){function i(){this._types=Object.create(null),this._extensions=Object.create(null);for(var e=0;e<arguments.length;e++)this.define(arguments[e]);this.define=this.define.bind(this),this.getType=this.getType.bind(this),this.getExtension=this.getExtension.bind(this)}i.prototype.define=function(e,t){for(var n in e){var i=e[n].map((function(e){return e.toLowerCase()}));n=n.toLowerCase();for(var a=0;a<i.length;a++){var o=i[a];if("*"!==o[0]){if(!t&&o in this._types)throw new Error('Attempt to change mapping for "'+o+'" extension from "'+this._types[o]+'" to "'+n+'". Pass `force=true` to allow this, otherwise remove "'+o+'" from the list of extensions for "'+n+'".');this._types[o]=n}}if(t||!this._extensions[n]){var r=i[0];this._extensions[n]="*"!==r[0]?r:r.substr(1)}}},i.prototype.getType=function(e){var t=(e=String(e)).replace(/^.*[/\\]/,"").toLowerCase(),n=t.replace(/^.*\./,"").toLowerCase(),i=t.length<e.length;return(n.length<t.length-1||!i)&&this._types[n]||null},i.prototype.getExtension=function(e){return(e=/^\s*([^;\s]*)/.test(e)&&RegExp.$1)&&this._extensions[e.toLowerCase()]||null},e.exports=i},function(e,t,n){e.exports={"application/andrew-inset":["ez"],"application/applixware":["aw"],"application/atom+xml":["atom"],"application/atomcat+xml":["atomcat"],"application/atomdeleted+xml":["atomdeleted"],"application/atomsvc+xml":["atomsvc"],"application/atsc-dwd+xml":["dwd"],"application/atsc-held+xml":["held"],"application/atsc-rsat+xml":["rsat"],"application/bdoc":["bdoc"],"application/calendar+xml":["xcs"],"application/ccxml+xml":["ccxml"],"application/cdfx+xml":["cdfx"],"application/cdmi-capability":["cdmia"],"application/cdmi-container":["cdmic"],"application/cdmi-domain":["cdmid"],"application/cdmi-object":["cdmio"],"application/cdmi-queue":["cdmiq"],"application/cu-seeme":["cu"],"application/dash+xml":["mpd"],"application/davmount+xml":["davmount"],"application/docbook+xml":["dbk"],"application/dssc+der":["dssc"],"application/dssc+xml":["xdssc"],"application/ecmascript":["es","ecma"],"application/emma+xml":["emma"],"application/emotionml+xml":["emotionml"],"application/epub+zip":["epub"],"application/exi":["exi"],"application/express":["exp"],"application/fdt+xml":["fdt"],"application/font-tdpfr":["pfr"],"application/geo+json":["geojson"],"application/gml+xml":["gml"],"application/gpx+xml":["gpx"],"application/gxf":["gxf"],"application/gzip":["gz"],"application/hjson":["hjson"],"application/hyperstudio":["stk"],"application/inkml+xml":["ink","inkml"],"application/ipfix":["ipfix"],"application/its+xml":["its"],"application/java-archive":["jar","war","ear"],"application/java-serialized-object":["ser"],"application/java-vm":["class"],"application/javascript":["js","mjs"],"application/json":["json","map"],"application/json5":["json5"],"application/jsonml+json":["jsonml"],"application/ld+json":["jsonld"],"application/lgr+xml":["lgr"],"application/lost+xml":["lostxml"],"application/mac-binhex40":["hqx"],"application/mac-compactpro":["cpt"],"application/mads+xml":["mads"],"application/manifest+json":["webmanifest"],"application/marc":["mrc"],"application/marcxml+xml":["mrcx"],"application/mathematica":["ma","nb","mb"],"application/mathml+xml":["mathml"],"application/mbox":["mbox"],"application/mediaservercontrol+xml":["mscml"],"application/metalink+xml":["metalink"],"application/metalink4+xml":["meta4"],"application/mets+xml":["mets"],"application/mmt-aei+xml":["maei"],"application/mmt-usd+xml":["musd"],"application/mods+xml":["mods"],"application/mp21":["m21","mp21"],"application/mp4":["mp4s","m4p"],"application/msword":["doc","dot"],"application/mxf":["mxf"],"application/n-quads":["nq"],"application/n-triples":["nt"],"application/node":["cjs"],"application/octet-stream":["bin","dms","lrf","mar","so","dist","distz","pkg","bpk","dump","elc","deploy","exe","dll","deb","dmg","iso","img","msi","msp","msm","buffer"],"application/oda":["oda"],"application/oebps-package+xml":["opf"],"application/ogg":["ogx"],"application/omdoc+xml":["omdoc"],"application/onenote":["onetoc","onetoc2","onetmp","onepkg"],"application/oxps":["oxps"],"application/p2p-overlay+xml":["relo"],"application/patch-ops-error+xml":["xer"],"application/pdf":["pdf"],"application/pgp-encrypted":["pgp"],"application/pgp-signature":["asc","sig"],"application/pics-rules":["prf"],"application/pkcs10":["p10"],"application/pkcs7-mime":["p7m","p7c"],"application/pkcs7-signature":["p7s"],"application/pkcs8":["p8"],"application/pkix-attr-cert":["ac"],"application/pkix-cert":["cer"],"application/pkix-crl":["crl"],"application/pkix-pkipath":["pkipath"],"application/pkixcmp":["pki"],"application/pls+xml":["pls"],"application/postscript":["ai","eps","ps"],"application/provenance+xml":["provx"],"application/pskc+xml":["pskcxml"],"application/raml+yaml":["raml"],"application/rdf+xml":["rdf","owl"],"application/reginfo+xml":["rif"],"application/relax-ng-compact-syntax":["rnc"],"application/resource-lists+xml":["rl"],"application/resource-lists-diff+xml":["rld"],"application/rls-services+xml":["rs"],"application/route-apd+xml":["rapd"],"application/route-s-tsid+xml":["sls"],"application/route-usd+xml":["rusd"],"application/rpki-ghostbusters":["gbr"],"application/rpki-manifest":["mft"],"application/rpki-roa":["roa"],"application/rsd+xml":["rsd"],"application/rss+xml":["rss"],"application/rtf":["rtf"],"application/sbml+xml":["sbml"],"application/scvp-cv-request":["scq"],"application/scvp-cv-response":["scs"],"application/scvp-vp-request":["spq"],"application/scvp-vp-response":["spp"],"application/sdp":["sdp"],"application/senml+xml":["senmlx"],"application/sensml+xml":["sensmlx"],"application/set-payment-initiation":["setpay"],"application/set-registration-initiation":["setreg"],"application/shf+xml":["shf"],"application/sieve":["siv","sieve"],"application/smil+xml":["smi","smil"],"application/sparql-query":["rq"],"application/sparql-results+xml":["srx"],"application/srgs":["gram"],"application/srgs+xml":["grxml"],"application/sru+xml":["sru"],"application/ssdl+xml":["ssdl"],"application/ssml+xml":["ssml"],"application/swid+xml":["swidtag"],"application/tei+xml":["tei","teicorpus"],"application/thraud+xml":["tfi"],"application/timestamped-data":["tsd"],"application/toml":["toml"],"application/trig":["trig"],"application/ttml+xml":["ttml"],"application/ubjson":["ubj"],"application/urc-ressheet+xml":["rsheet"],"application/urc-targetdesc+xml":["td"],"application/voicexml+xml":["vxml"],"application/wasm":["wasm"],"application/widget":["wgt"],"application/winhlp":["hlp"],"application/wsdl+xml":["wsdl"],"application/wspolicy+xml":["wspolicy"],"application/xaml+xml":["xaml"],"application/xcap-att+xml":["xav"],"application/xcap-caps+xml":["xca"],"application/xcap-diff+xml":["xdf"],"application/xcap-el+xml":["xel"],"application/xcap-ns+xml":["xns"],"application/xenc+xml":["xenc"],"application/xhtml+xml":["xhtml","xht"],"application/xliff+xml":["xlf"],"application/xml":["xml","xsl","xsd","rng"],"application/xml-dtd":["dtd"],"application/xop+xml":["xop"],"application/xproc+xml":["xpl"],"application/xslt+xml":["*xsl","xslt"],"application/xspf+xml":["xspf"],"application/xv+xml":["mxml","xhvml","xvml","xvm"],"application/yang":["yang"],"application/yin+xml":["yin"],"application/zip":["zip"],"audio/3gpp":["*3gpp"],"audio/adpcm":["adp"],"audio/amr":["amr"],"audio/basic":["au","snd"],"audio/midi":["mid","midi","kar","rmi"],"audio/mobile-xmf":["mxmf"],"audio/mp3":["*mp3"],"audio/mp4":["m4a","mp4a"],"audio/mpeg":["mpga","mp2","mp2a","mp3","m2a","m3a"],"audio/ogg":["oga","ogg","spx","opus"],"audio/s3m":["s3m"],"audio/silk":["sil"],"audio/wav":["wav"],"audio/wave":["*wav"],"audio/webm":["weba"],"audio/xm":["xm"],"font/collection":["ttc"],"font/otf":["otf"],"font/ttf":["ttf"],"font/woff":["woff"],"font/woff2":["woff2"],"image/aces":["exr"],"image/apng":["apng"],"image/avif":["avif"],"image/bmp":["bmp"],"image/cgm":["cgm"],"image/dicom-rle":["drle"],"image/emf":["emf"],"image/fits":["fits"],"image/g3fax":["g3"],"image/gif":["gif"],"image/heic":["heic"],"image/heic-sequence":["heics"],"image/heif":["heif"],"image/heif-sequence":["heifs"],"image/hej2k":["hej2"],"image/hsj2":["hsj2"],"image/ief":["ief"],"image/jls":["jls"],"image/jp2":["jp2","jpg2"],"image/jpeg":["jpeg","jpg","jpe"],"image/jph":["jph"],"image/jphc":["jhc"],"image/jpm":["jpm"],"image/jpx":["jpx","jpf"],"image/jxr":["jxr"],"image/jxra":["jxra"],"image/jxrs":["jxrs"],"image/jxs":["jxs"],"image/jxsc":["jxsc"],"image/jxsi":["jxsi"],"image/jxss":["jxss"],"image/ktx":["ktx"],"image/ktx2":["ktx2"],"image/png":["png"],"image/sgi":["sgi"],"image/svg+xml":["svg","svgz"],"image/t38":["t38"],"image/tiff":["tif","tiff"],"image/tiff-fx":["tfx"],"image/webp":["webp"],"image/wmf":["wmf"],"message/disposition-notification":["disposition-notification"],"message/global":["u8msg"],"message/global-delivery-status":["u8dsn"],"message/global-disposition-notification":["u8mdn"],"message/global-headers":["u8hdr"],"message/rfc822":["eml","mime"],"model/3mf":["3mf"],"model/gltf+json":["gltf"],"model/gltf-binary":["glb"],"model/iges":["igs","iges"],"model/mesh":["msh","mesh","silo"],"model/mtl":["mtl"],"model/obj":["obj"],"model/step+xml":["stpx"],"model/step+zip":["stpz"],"model/step-xml+zip":["stpxz"],"model/stl":["stl"],"model/vrml":["wrl","vrml"],"model/x3d+binary":["*x3db","x3dbz"],"model/x3d+fastinfoset":["x3db"],"model/x3d+vrml":["*x3dv","x3dvz"],"model/x3d+xml":["x3d","x3dz"],"model/x3d-vrml":["x3dv"],"text/cache-manifest":["appcache","manifest"],"text/calendar":["ics","ifb"],"text/coffeescript":["coffee","litcoffee"],"text/css":["css"],"text/csv":["csv"],"text/html":["html","htm","shtml"],"text/jade":["jade"],"text/jsx":["jsx"],"text/less":["less"],"text/markdown":["markdown","md"],"text/mathml":["mml"],"text/mdx":["mdx"],"text/n3":["n3"],"text/plain":["txt","text","conf","def","list","log","in","ini"],"text/richtext":["rtx"],"text/rtf":["*rtf"],"text/sgml":["sgml","sgm"],"text/shex":["shex"],"text/slim":["slim","slm"],"text/spdx":["spdx"],"text/stylus":["stylus","styl"],"text/tab-separated-values":["tsv"],"text/troff":["t","tr","roff","man","me","ms"],"text/turtle":["ttl"],"text/uri-list":["uri","uris","urls"],"text/vcard":["vcard"],"text/vtt":["vtt"],"text/xml":["*xml"],"text/yaml":["yaml","yml"],"video/3gpp":["3gp","3gpp"],"video/3gpp2":["3g2"],"video/h261":["h261"],"video/h263":["h263"],"video/h264":["h264"],"video/iso.segment":["m4s"],"video/jpeg":["jpgv"],"video/jpm":["*jpm","jpgm"],"video/mj2":["mj2","mjp2"],"video/mp2t":["ts"],"video/mp4":["mp4","mp4v","mpg4"],"video/mpeg":["mpeg","mpg","mpe","m1v","m2v"],"video/ogg":["ogv"],"video/quicktime":["qt","mov"],"video/webm":["webm"]}},function(e,t,n){e.exports={"application/prs.cww":["cww"],"application/vnd.1000minds.decision-model+xml":["1km"],"application/vnd.3gpp.pic-bw-large":["plb"],"application/vnd.3gpp.pic-bw-small":["psb"],"application/vnd.3gpp.pic-bw-var":["pvb"],"application/vnd.3gpp2.tcap":["tcap"],"application/vnd.3m.post-it-notes":["pwn"],"application/vnd.accpac.simply.aso":["aso"],"application/vnd.accpac.simply.imp":["imp"],"application/vnd.acucobol":["acu"],"application/vnd.acucorp":["atc","acutc"],"application/vnd.adobe.air-application-installer-package+zip":["air"],"application/vnd.adobe.formscentral.fcdt":["fcdt"],"application/vnd.adobe.fxp":["fxp","fxpl"],"application/vnd.adobe.xdp+xml":["xdp"],"application/vnd.adobe.xfdf":["xfdf"],"application/vnd.ahead.space":["ahead"],"application/vnd.airzip.filesecure.azf":["azf"],"application/vnd.airzip.filesecure.azs":["azs"],"application/vnd.amazon.ebook":["azw"],"application/vnd.americandynamics.acc":["acc"],"application/vnd.amiga.ami":["ami"],"application/vnd.android.package-archive":["apk"],"application/vnd.anser-web-certificate-issue-initiation":["cii"],"application/vnd.anser-web-funds-transfer-initiation":["fti"],"application/vnd.antix.game-component":["atx"],"application/vnd.apple.installer+xml":["mpkg"],"application/vnd.apple.keynote":["key"],"application/vnd.apple.mpegurl":["m3u8"],"application/vnd.apple.numbers":["numbers"],"application/vnd.apple.pages":["pages"],"application/vnd.apple.pkpass":["pkpass"],"application/vnd.aristanetworks.swi":["swi"],"application/vnd.astraea-software.iota":["iota"],"application/vnd.audiograph":["aep"],"application/vnd.balsamiq.bmml+xml":["bmml"],"application/vnd.blueice.multipass":["mpm"],"application/vnd.bmi":["bmi"],"application/vnd.businessobjects":["rep"],"application/vnd.chemdraw+xml":["cdxml"],"application/vnd.chipnuts.karaoke-mmd":["mmd"],"application/vnd.cinderella":["cdy"],"application/vnd.citationstyles.style+xml":["csl"],"application/vnd.claymore":["cla"],"application/vnd.cloanto.rp9":["rp9"],"application/vnd.clonk.c4group":["c4g","c4d","c4f","c4p","c4u"],"application/vnd.cluetrust.cartomobile-config":["c11amc"],"application/vnd.cluetrust.cartomobile-config-pkg":["c11amz"],"application/vnd.commonspace":["csp"],"application/vnd.contact.cmsg":["cdbcmsg"],"application/vnd.cosmocaller":["cmc"],"application/vnd.crick.clicker":["clkx"],"application/vnd.crick.clicker.keyboard":["clkk"],"application/vnd.crick.clicker.palette":["clkp"],"application/vnd.crick.clicker.template":["clkt"],"application/vnd.crick.clicker.wordbank":["clkw"],"application/vnd.criticaltools.wbs+xml":["wbs"],"application/vnd.ctc-posml":["pml"],"application/vnd.cups-ppd":["ppd"],"application/vnd.curl.car":["car"],"application/vnd.curl.pcurl":["pcurl"],"application/vnd.dart":["dart"],"application/vnd.data-vision.rdz":["rdz"],"application/vnd.dbf":["dbf"],"application/vnd.dece.data":["uvf","uvvf","uvd","uvvd"],"application/vnd.dece.ttml+xml":["uvt","uvvt"],"application/vnd.dece.unspecified":["uvx","uvvx"],"application/vnd.dece.zip":["uvz","uvvz"],"application/vnd.denovo.fcselayout-link":["fe_launch"],"application/vnd.dna":["dna"],"application/vnd.dolby.mlp":["mlp"],"application/vnd.dpgraph":["dpg"],"application/vnd.dreamfactory":["dfac"],"application/vnd.ds-keypoint":["kpxx"],"application/vnd.dvb.ait":["ait"],"application/vnd.dvb.service":["svc"],"application/vnd.dynageo":["geo"],"application/vnd.ecowin.chart":["mag"],"application/vnd.enliven":["nml"],"application/vnd.epson.esf":["esf"],"application/vnd.epson.msf":["msf"],"application/vnd.epson.quickanime":["qam"],"application/vnd.epson.salt":["slt"],"application/vnd.epson.ssf":["ssf"],"application/vnd.eszigno3+xml":["es3","et3"],"application/vnd.ezpix-album":["ez2"],"application/vnd.ezpix-package":["ez3"],"application/vnd.fdf":["fdf"],"application/vnd.fdsn.mseed":["mseed"],"application/vnd.fdsn.seed":["seed","dataless"],"application/vnd.flographit":["gph"],"application/vnd.fluxtime.clip":["ftc"],"application/vnd.framemaker":["fm","frame","maker","book"],"application/vnd.frogans.fnc":["fnc"],"application/vnd.frogans.ltf":["ltf"],"application/vnd.fsc.weblaunch":["fsc"],"application/vnd.fujitsu.oasys":["oas"],"application/vnd.fujitsu.oasys2":["oa2"],"application/vnd.fujitsu.oasys3":["oa3"],"application/vnd.fujitsu.oasysgp":["fg5"],"application/vnd.fujitsu.oasysprs":["bh2"],"application/vnd.fujixerox.ddd":["ddd"],"application/vnd.fujixerox.docuworks":["xdw"],"application/vnd.fujixerox.docuworks.binder":["xbd"],"application/vnd.fuzzysheet":["fzs"],"application/vnd.genomatix.tuxedo":["txd"],"application/vnd.geogebra.file":["ggb"],"application/vnd.geogebra.tool":["ggt"],"application/vnd.geometry-explorer":["gex","gre"],"application/vnd.geonext":["gxt"],"application/vnd.geoplan":["g2w"],"application/vnd.geospace":["g3w"],"application/vnd.gmx":["gmx"],"application/vnd.google-apps.document":["gdoc"],"application/vnd.google-apps.presentation":["gslides"],"application/vnd.google-apps.spreadsheet":["gsheet"],"application/vnd.google-earth.kml+xml":["kml"],"application/vnd.google-earth.kmz":["kmz"],"application/vnd.grafeq":["gqf","gqs"],"application/vnd.groove-account":["gac"],"application/vnd.groove-help":["ghf"],"application/vnd.groove-identity-message":["gim"],"application/vnd.groove-injector":["grv"],"application/vnd.groove-tool-message":["gtm"],"application/vnd.groove-tool-template":["tpl"],"application/vnd.groove-vcard":["vcg"],"application/vnd.hal+xml":["hal"],"application/vnd.handheld-entertainment+xml":["zmm"],"application/vnd.hbci":["hbci"],"application/vnd.hhe.lesson-player":["les"],"application/vnd.hp-hpgl":["hpgl"],"application/vnd.hp-hpid":["hpid"],"application/vnd.hp-hps":["hps"],"application/vnd.hp-jlyt":["jlt"],"application/vnd.hp-pcl":["pcl"],"application/vnd.hp-pclxl":["pclxl"],"application/vnd.hydrostatix.sof-data":["sfd-hdstx"],"application/vnd.ibm.minipay":["mpy"],"application/vnd.ibm.modcap":["afp","listafp","list3820"],"application/vnd.ibm.rights-management":["irm"],"application/vnd.ibm.secure-container":["sc"],"application/vnd.iccprofile":["icc","icm"],"application/vnd.igloader":["igl"],"application/vnd.immervision-ivp":["ivp"],"application/vnd.immervision-ivu":["ivu"],"application/vnd.insors.igm":["igm"],"application/vnd.intercon.formnet":["xpw","xpx"],"application/vnd.intergeo":["i2g"],"application/vnd.intu.qbo":["qbo"],"application/vnd.intu.qfx":["qfx"],"application/vnd.ipunplugged.rcprofile":["rcprofile"],"application/vnd.irepository.package+xml":["irp"],"application/vnd.is-xpr":["xpr"],"application/vnd.isac.fcs":["fcs"],"application/vnd.jam":["jam"],"application/vnd.jcp.javame.midlet-rms":["rms"],"application/vnd.jisp":["jisp"],"application/vnd.joost.joda-archive":["joda"],"application/vnd.kahootz":["ktz","ktr"],"application/vnd.kde.karbon":["karbon"],"application/vnd.kde.kchart":["chrt"],"application/vnd.kde.kformula":["kfo"],"application/vnd.kde.kivio":["flw"],"application/vnd.kde.kontour":["kon"],"application/vnd.kde.kpresenter":["kpr","kpt"],"application/vnd.kde.kspread":["ksp"],"application/vnd.kde.kword":["kwd","kwt"],"application/vnd.kenameaapp":["htke"],"application/vnd.kidspiration":["kia"],"application/vnd.kinar":["kne","knp"],"application/vnd.koan":["skp","skd","skt","skm"],"application/vnd.kodak-descriptor":["sse"],"application/vnd.las.las+xml":["lasxml"],"application/vnd.llamagraphics.life-balance.desktop":["lbd"],"application/vnd.llamagraphics.life-balance.exchange+xml":["lbe"],"application/vnd.lotus-1-2-3":["123"],"application/vnd.lotus-approach":["apr"],"application/vnd.lotus-freelance":["pre"],"application/vnd.lotus-notes":["nsf"],"application/vnd.lotus-organizer":["org"],"application/vnd.lotus-screencam":["scm"],"application/vnd.lotus-wordpro":["lwp"],"application/vnd.macports.portpkg":["portpkg"],"application/vnd.mapbox-vector-tile":["mvt"],"application/vnd.mcd":["mcd"],"application/vnd.medcalcdata":["mc1"],"application/vnd.mediastation.cdkey":["cdkey"],"application/vnd.mfer":["mwf"],"application/vnd.mfmp":["mfm"],"application/vnd.micrografx.flo":["flo"],"application/vnd.micrografx.igx":["igx"],"application/vnd.mif":["mif"],"application/vnd.mobius.daf":["daf"],"application/vnd.mobius.dis":["dis"],"application/vnd.mobius.mbk":["mbk"],"application/vnd.mobius.mqy":["mqy"],"application/vnd.mobius.msl":["msl"],"application/vnd.mobius.plc":["plc"],"application/vnd.mobius.txf":["txf"],"application/vnd.mophun.application":["mpn"],"application/vnd.mophun.certificate":["mpc"],"application/vnd.mozilla.xul+xml":["xul"],"application/vnd.ms-artgalry":["cil"],"application/vnd.ms-cab-compressed":["cab"],"application/vnd.ms-excel":["xls","xlm","xla","xlc","xlt","xlw"],"application/vnd.ms-excel.addin.macroenabled.12":["xlam"],"application/vnd.ms-excel.sheet.binary.macroenabled.12":["xlsb"],"application/vnd.ms-excel.sheet.macroenabled.12":["xlsm"],"application/vnd.ms-excel.template.macroenabled.12":["xltm"],"application/vnd.ms-fontobject":["eot"],"application/vnd.ms-htmlhelp":["chm"],"application/vnd.ms-ims":["ims"],"application/vnd.ms-lrm":["lrm"],"application/vnd.ms-officetheme":["thmx"],"application/vnd.ms-outlook":["msg"],"application/vnd.ms-pki.seccat":["cat"],"application/vnd.ms-pki.stl":["*stl"],"application/vnd.ms-powerpoint":["ppt","pps","pot"],"application/vnd.ms-powerpoint.addin.macroenabled.12":["ppam"],"application/vnd.ms-powerpoint.presentation.macroenabled.12":["pptm"],"application/vnd.ms-powerpoint.slide.macroenabled.12":["sldm"],"application/vnd.ms-powerpoint.slideshow.macroenabled.12":["ppsm"],"application/vnd.ms-powerpoint.template.macroenabled.12":["potm"],"application/vnd.ms-project":["mpp","mpt"],"application/vnd.ms-word.document.macroenabled.12":["docm"],"application/vnd.ms-word.template.macroenabled.12":["dotm"],"application/vnd.ms-works":["wps","wks","wcm","wdb"],"application/vnd.ms-wpl":["wpl"],"application/vnd.ms-xpsdocument":["xps"],"application/vnd.mseq":["mseq"],"application/vnd.musician":["mus"],"application/vnd.muvee.style":["msty"],"application/vnd.mynfc":["taglet"],"application/vnd.neurolanguage.nlu":["nlu"],"application/vnd.nitf":["ntf","nitf"],"application/vnd.noblenet-directory":["nnd"],"application/vnd.noblenet-sealer":["nns"],"application/vnd.noblenet-web":["nnw"],"application/vnd.nokia.n-gage.ac+xml":["*ac"],"application/vnd.nokia.n-gage.data":["ngdat"],"application/vnd.nokia.n-gage.symbian.install":["n-gage"],"application/vnd.nokia.radio-preset":["rpst"],"application/vnd.nokia.radio-presets":["rpss"],"application/vnd.novadigm.edm":["edm"],"application/vnd.novadigm.edx":["edx"],"application/vnd.novadigm.ext":["ext"],"application/vnd.oasis.opendocument.chart":["odc"],"application/vnd.oasis.opendocument.chart-template":["otc"],"application/vnd.oasis.opendocument.database":["odb"],"application/vnd.oasis.opendocument.formula":["odf"],"application/vnd.oasis.opendocument.formula-template":["odft"],"application/vnd.oasis.opendocument.graphics":["odg"],"application/vnd.oasis.opendocument.graphics-template":["otg"],"application/vnd.oasis.opendocument.image":["odi"],"application/vnd.oasis.opendocument.image-template":["oti"],"application/vnd.oasis.opendocument.presentation":["odp"],"application/vnd.oasis.opendocument.presentation-template":["otp"],"application/vnd.oasis.opendocument.spreadsheet":["ods"],"application/vnd.oasis.opendocument.spreadsheet-template":["ots"],"application/vnd.oasis.opendocument.text":["odt"],"application/vnd.oasis.opendocument.text-master":["odm"],"application/vnd.oasis.opendocument.text-template":["ott"],"application/vnd.oasis.opendocument.text-web":["oth"],"application/vnd.olpc-sugar":["xo"],"application/vnd.oma.dd2+xml":["dd2"],"application/vnd.openblox.game+xml":["obgx"],"application/vnd.openofficeorg.extension":["oxt"],"application/vnd.openstreetmap.data+xml":["osm"],"application/vnd.openxmlformats-officedocument.presentationml.presentation":["pptx"],"application/vnd.openxmlformats-officedocument.presentationml.slide":["sldx"],"application/vnd.openxmlformats-officedocument.presentationml.slideshow":["ppsx"],"application/vnd.openxmlformats-officedocument.presentationml.template":["potx"],"application/vnd.openxmlformats-officedocument.spreadsheetml.sheet":["xlsx"],"application/vnd.openxmlformats-officedocument.spreadsheetml.template":["xltx"],"application/vnd.openxmlformats-officedocument.wordprocessingml.document":["docx"],"application/vnd.openxmlformats-officedocument.wordprocessingml.template":["dotx"],"application/vnd.osgeo.mapguide.package":["mgp"],"application/vnd.osgi.dp":["dp"],"application/vnd.osgi.subsystem":["esa"],"application/vnd.palm":["pdb","pqa","oprc"],"application/vnd.pawaafile":["paw"],"application/vnd.pg.format":["str"],"application/vnd.pg.osasli":["ei6"],"application/vnd.picsel":["efif"],"application/vnd.pmi.widget":["wg"],"application/vnd.pocketlearn":["plf"],"application/vnd.powerbuilder6":["pbd"],"application/vnd.previewsystems.box":["box"],"application/vnd.proteus.magazine":["mgz"],"application/vnd.publishare-delta-tree":["qps"],"application/vnd.pvi.ptid1":["ptid"],"application/vnd.quark.quarkxpress":["qxd","qxt","qwd","qwt","qxl","qxb"],"application/vnd.rar":["rar"],"application/vnd.realvnc.bed":["bed"],"application/vnd.recordare.musicxml":["mxl"],"application/vnd.recordare.musicxml+xml":["musicxml"],"application/vnd.rig.cryptonote":["cryptonote"],"application/vnd.rim.cod":["cod"],"application/vnd.rn-realmedia":["rm"],"application/vnd.rn-realmedia-vbr":["rmvb"],"application/vnd.route66.link66+xml":["link66"],"application/vnd.sailingtracker.track":["st"],"application/vnd.seemail":["see"],"application/vnd.sema":["sema"],"application/vnd.semd":["semd"],"application/vnd.semf":["semf"],"application/vnd.shana.informed.formdata":["ifm"],"application/vnd.shana.informed.formtemplate":["itp"],"application/vnd.shana.informed.interchange":["iif"],"application/vnd.shana.informed.package":["ipk"],"application/vnd.simtech-mindmapper":["twd","twds"],"application/vnd.smaf":["mmf"],"application/vnd.smart.teacher":["teacher"],"application/vnd.software602.filler.form+xml":["fo"],"application/vnd.solent.sdkm+xml":["sdkm","sdkd"],"application/vnd.spotfire.dxp":["dxp"],"application/vnd.spotfire.sfs":["sfs"],"application/vnd.stardivision.calc":["sdc"],"application/vnd.stardivision.draw":["sda"],"application/vnd.stardivision.impress":["sdd"],"application/vnd.stardivision.math":["smf"],"application/vnd.stardivision.writer":["sdw","vor"],"application/vnd.stardivision.writer-global":["sgl"],"application/vnd.stepmania.package":["smzip"],"application/vnd.stepmania.stepchart":["sm"],"application/vnd.sun.wadl+xml":["wadl"],"application/vnd.sun.xml.calc":["sxc"],"application/vnd.sun.xml.calc.template":["stc"],"application/vnd.sun.xml.draw":["sxd"],"application/vnd.sun.xml.draw.template":["std"],"application/vnd.sun.xml.impress":["sxi"],"application/vnd.sun.xml.impress.template":["sti"],"application/vnd.sun.xml.math":["sxm"],"application/vnd.sun.xml.writer":["sxw"],"application/vnd.sun.xml.writer.global":["sxg"],"application/vnd.sun.xml.writer.template":["stw"],"application/vnd.sus-calendar":["sus","susp"],"application/vnd.svd":["svd"],"application/vnd.symbian.install":["sis","sisx"],"application/vnd.syncml+xml":["xsm"],"application/vnd.syncml.dm+wbxml":["bdm"],"application/vnd.syncml.dm+xml":["xdm"],"application/vnd.syncml.dmddf+xml":["ddf"],"application/vnd.tao.intent-module-archive":["tao"],"application/vnd.tcpdump.pcap":["pcap","cap","dmp"],"application/vnd.tmobile-livetv":["tmo"],"application/vnd.trid.tpt":["tpt"],"application/vnd.triscape.mxs":["mxs"],"application/vnd.trueapp":["tra"],"application/vnd.ufdl":["ufd","ufdl"],"application/vnd.uiq.theme":["utz"],"application/vnd.umajin":["umj"],"application/vnd.unity":["unityweb"],"application/vnd.uoml+xml":["uoml"],"application/vnd.vcx":["vcx"],"application/vnd.visio":["vsd","vst","vss","vsw"],"application/vnd.visionary":["vis"],"application/vnd.vsf":["vsf"],"application/vnd.wap.wbxml":["wbxml"],"application/vnd.wap.wmlc":["wmlc"],"application/vnd.wap.wmlscriptc":["wmlsc"],"application/vnd.webturbo":["wtb"],"application/vnd.wolfram.player":["nbp"],"application/vnd.wordperfect":["wpd"],"application/vnd.wqd":["wqd"],"application/vnd.wt.stf":["stf"],"application/vnd.xara":["xar"],"application/vnd.xfdl":["xfdl"],"application/vnd.yamaha.hv-dic":["hvd"],"application/vnd.yamaha.hv-script":["hvs"],"application/vnd.yamaha.hv-voice":["hvp"],"application/vnd.yamaha.openscoreformat":["osf"],"application/vnd.yamaha.openscoreformat.osfpvg+xml":["osfpvg"],"application/vnd.yamaha.smaf-audio":["saf"],"application/vnd.yamaha.smaf-phrase":["spf"],"application/vnd.yellowriver-custom-menu":["cmp"],"application/vnd.zul":["zir","zirz"],"application/vnd.zzazz.deck+xml":["zaz"],"application/x-7z-compressed":["7z"],"application/x-abiword":["abw"],"application/x-ace-compressed":["ace"],"application/x-apple-diskimage":["*dmg"],"application/x-arj":["arj"],"application/x-authorware-bin":["aab","x32","u32","vox"],"application/x-authorware-map":["aam"],"application/x-authorware-seg":["aas"],"application/x-bcpio":["bcpio"],"application/x-bdoc":["*bdoc"],"application/x-bittorrent":["torrent"],"application/x-blorb":["blb","blorb"],"application/x-bzip":["bz"],"application/x-bzip2":["bz2","boz"],"application/x-cbr":["cbr","cba","cbt","cbz","cb7"],"application/x-cdlink":["vcd"],"application/x-cfs-compressed":["cfs"],"application/x-chat":["chat"],"application/x-chess-pgn":["pgn"],"application/x-chrome-extension":["crx"],"application/x-cocoa":["cco"],"application/x-conference":["nsc"],"application/x-cpio":["cpio"],"application/x-csh":["csh"],"application/x-debian-package":["*deb","udeb"],"application/x-dgc-compressed":["dgc"],"application/x-director":["dir","dcr","dxr","cst","cct","cxt","w3d","fgd","swa"],"application/x-doom":["wad"],"application/x-dtbncx+xml":["ncx"],"application/x-dtbook+xml":["dtb"],"application/x-dtbresource+xml":["res"],"application/x-dvi":["dvi"],"application/x-envoy":["evy"],"application/x-eva":["eva"],"application/x-font-bdf":["bdf"],"application/x-font-ghostscript":["gsf"],"application/x-font-linux-psf":["psf"],"application/x-font-pcf":["pcf"],"application/x-font-snf":["snf"],"application/x-font-type1":["pfa","pfb","pfm","afm"],"application/x-freearc":["arc"],"application/x-futuresplash":["spl"],"application/x-gca-compressed":["gca"],"application/x-glulx":["ulx"],"application/x-gnumeric":["gnumeric"],"application/x-gramps-xml":["gramps"],"application/x-gtar":["gtar"],"application/x-hdf":["hdf"],"application/x-httpd-php":["php"],"application/x-install-instructions":["install"],"application/x-iso9660-image":["*iso"],"application/x-iwork-keynote-sffkey":["*key"],"application/x-iwork-numbers-sffnumbers":["*numbers"],"application/x-iwork-pages-sffpages":["*pages"],"application/x-java-archive-diff":["jardiff"],"application/x-java-jnlp-file":["jnlp"],"application/x-keepass2":["kdbx"],"application/x-latex":["latex"],"application/x-lua-bytecode":["luac"],"application/x-lzh-compressed":["lzh","lha"],"application/x-makeself":["run"],"application/x-mie":["mie"],"application/x-mobipocket-ebook":["prc","mobi"],"application/x-ms-application":["application"],"application/x-ms-shortcut":["lnk"],"application/x-ms-wmd":["wmd"],"application/x-ms-wmz":["wmz"],"application/x-ms-xbap":["xbap"],"application/x-msaccess":["mdb"],"application/x-msbinder":["obd"],"application/x-mscardfile":["crd"],"application/x-msclip":["clp"],"application/x-msdos-program":["*exe"],"application/x-msdownload":["*exe","*dll","com","bat","*msi"],"application/x-msmediaview":["mvb","m13","m14"],"application/x-msmetafile":["*wmf","*wmz","*emf","emz"],"application/x-msmoney":["mny"],"application/x-mspublisher":["pub"],"application/x-msschedule":["scd"],"application/x-msterminal":["trm"],"application/x-mswrite":["wri"],"application/x-netcdf":["nc","cdf"],"application/x-ns-proxy-autoconfig":["pac"],"application/x-nzb":["nzb"],"application/x-perl":["pl","pm"],"application/x-pilot":["*prc","*pdb"],"application/x-pkcs12":["p12","pfx"],"application/x-pkcs7-certificates":["p7b","spc"],"application/x-pkcs7-certreqresp":["p7r"],"application/x-rar-compressed":["*rar"],"application/x-redhat-package-manager":["rpm"],"application/x-research-info-systems":["ris"],"application/x-sea":["sea"],"application/x-sh":["sh"],"application/x-shar":["shar"],"application/x-shockwave-flash":["swf"],"application/x-silverlight-app":["xap"],"application/x-sql":["sql"],"application/x-stuffit":["sit"],"application/x-stuffitx":["sitx"],"application/x-subrip":["srt"],"application/x-sv4cpio":["sv4cpio"],"application/x-sv4crc":["sv4crc"],"application/x-t3vm-image":["t3"],"application/x-tads":["gam"],"application/x-tar":["tar"],"application/x-tcl":["tcl","tk"],"application/x-tex":["tex"],"application/x-tex-tfm":["tfm"],"application/x-texinfo":["texinfo","texi"],"application/x-tgif":["*obj"],"application/x-ustar":["ustar"],"application/x-virtualbox-hdd":["hdd"],"application/x-virtualbox-ova":["ova"],"application/x-virtualbox-ovf":["ovf"],"application/x-virtualbox-vbox":["vbox"],"application/x-virtualbox-vbox-extpack":["vbox-extpack"],"application/x-virtualbox-vdi":["vdi"],"application/x-virtualbox-vhd":["vhd"],"application/x-virtualbox-vmdk":["vmdk"],"application/x-wais-source":["src"],"application/x-web-app-manifest+json":["webapp"],"application/x-x509-ca-cert":["der","crt","pem"],"application/x-xfig":["fig"],"application/x-xliff+xml":["*xlf"],"application/x-xpinstall":["xpi"],"application/x-xz":["xz"],"application/x-zmachine":["z1","z2","z3","z4","z5","z6","z7","z8"],"audio/vnd.dece.audio":["uva","uvva"],"audio/vnd.digital-winds":["eol"],"audio/vnd.dra":["dra"],"audio/vnd.dts":["dts"],"audio/vnd.dts.hd":["dtshd"],"audio/vnd.lucent.voice":["lvp"],"audio/vnd.ms-playready.media.pya":["pya"],"audio/vnd.nuera.ecelp4800":["ecelp4800"],"audio/vnd.nuera.ecelp7470":["ecelp7470"],"audio/vnd.nuera.ecelp9600":["ecelp9600"],"audio/vnd.rip":["rip"],"audio/x-aac":["aac"],"audio/x-aiff":["aif","aiff","aifc"],"audio/x-caf":["caf"],"audio/x-flac":["flac"],"audio/x-m4a":["*m4a"],"audio/x-matroska":["mka"],"audio/x-mpegurl":["m3u"],"audio/x-ms-wax":["wax"],"audio/x-ms-wma":["wma"],"audio/x-pn-realaudio":["ram","ra"],"audio/x-pn-realaudio-plugin":["rmp"],"audio/x-realaudio":["*ra"],"audio/x-wav":["*wav"],"chemical/x-cdx":["cdx"],"chemical/x-cif":["cif"],"chemical/x-cmdf":["cmdf"],"chemical/x-cml":["cml"],"chemical/x-csml":["csml"],"chemical/x-xyz":["xyz"],"image/prs.btif":["btif"],"image/prs.pti":["pti"],"image/vnd.adobe.photoshop":["psd"],"image/vnd.airzip.accelerator.azv":["azv"],"image/vnd.dece.graphic":["uvi","uvvi","uvg","uvvg"],"image/vnd.djvu":["djvu","djv"],"image/vnd.dvb.subtitle":["*sub"],"image/vnd.dwg":["dwg"],"image/vnd.dxf":["dxf"],"image/vnd.fastbidsheet":["fbs"],"image/vnd.fpx":["fpx"],"image/vnd.fst":["fst"],"image/vnd.fujixerox.edmics-mmr":["mmr"],"image/vnd.fujixerox.edmics-rlc":["rlc"],"image/vnd.microsoft.icon":["ico"],"image/vnd.ms-dds":["dds"],"image/vnd.ms-modi":["mdi"],"image/vnd.ms-photo":["wdp"],"image/vnd.net-fpx":["npx"],"image/vnd.pco.b16":["b16"],"image/vnd.tencent.tap":["tap"],"image/vnd.valve.source.texture":["vtf"],"image/vnd.wap.wbmp":["wbmp"],"image/vnd.xiff":["xif"],"image/vnd.zbrush.pcx":["pcx"],"image/x-3ds":["3ds"],"image/x-cmu-raster":["ras"],"image/x-cmx":["cmx"],"image/x-freehand":["fh","fhc","fh4","fh5","fh7"],"image/x-icon":["*ico"],"image/x-jng":["jng"],"image/x-mrsid-image":["sid"],"image/x-ms-bmp":["*bmp"],"image/x-pcx":["*pcx"],"image/x-pict":["pic","pct"],"image/x-portable-anymap":["pnm"],"image/x-portable-bitmap":["pbm"],"image/x-portable-graymap":["pgm"],"image/x-portable-pixmap":["ppm"],"image/x-rgb":["rgb"],"image/x-tga":["tga"],"image/x-xbitmap":["xbm"],"image/x-xpixmap":["xpm"],"image/x-xwindowdump":["xwd"],"message/vnd.wfa.wsc":["wsc"],"model/vnd.collada+xml":["dae"],"model/vnd.dwf":["dwf"],"model/vnd.gdl":["gdl"],"model/vnd.gtw":["gtw"],"model/vnd.mts":["mts"],"model/vnd.opengex":["ogex"],"model/vnd.parasolid.transmit.binary":["x_b"],"model/vnd.parasolid.transmit.text":["x_t"],"model/vnd.sap.vds":["vds"],"model/vnd.usdz+zip":["usdz"],"model/vnd.valve.source.compiled-map":["bsp"],"model/vnd.vtu":["vtu"],"text/prs.lines.tag":["dsc"],"text/vnd.curl":["curl"],"text/vnd.curl.dcurl":["dcurl"],"text/vnd.curl.mcurl":["mcurl"],"text/vnd.curl.scurl":["scurl"],"text/vnd.dvb.subtitle":["sub"],"text/vnd.fly":["fly"],"text/vnd.fmi.flexstor":["flx"],"text/vnd.graphviz":["gv"],"text/vnd.in3d.3dml":["3dml"],"text/vnd.in3d.spot":["spot"],"text/vnd.sun.j2me.app-descriptor":["jad"],"text/vnd.wap.wml":["wml"],"text/vnd.wap.wmlscript":["wmls"],"text/x-asm":["s","asm"],"text/x-c":["c","cc","cxx","cpp","h","hh","dic"],"text/x-component":["htc"],"text/x-fortran":["f","for","f77","f90"],"text/x-handlebars-template":["hbs"],"text/x-java-source":["java"],"text/x-lua":["lua"],"text/x-markdown":["mkd"],"text/x-nfo":["nfo"],"text/x-opml":["opml"],"text/x-org":["*org"],"text/x-pascal":["p","pas"],"text/x-processing":["pde"],"text/x-sass":["sass"],"text/x-scss":["scss"],"text/x-setext":["etx"],"text/x-sfv":["sfv"],"text/x-suse-ymp":["ymp"],"text/x-uuencode":["uu"],"text/x-vcalendar":["vcs"],"text/x-vcard":["vcf"],"video/vnd.dece.hd":["uvh","uvvh"],"video/vnd.dece.mobile":["uvm","uvvm"],"video/vnd.dece.pd":["uvp","uvvp"],"video/vnd.dece.sd":["uvs","uvvs"],"video/vnd.dece.video":["uvv","uvvv"],"video/vnd.dvb.file":["dvb"],"video/vnd.fvt":["fvt"],"video/vnd.mpegurl":["mxu","m4u"],"video/vnd.ms-playready.media.pyv":["pyv"],"video/vnd.uvvu.mp4":["uvu","uvvu"],"video/vnd.vivo":["viv"],"video/x-f4v":["f4v"],"video/x-fli":["fli"],"video/x-flv":["flv"],"video/x-m4v":["m4v"],"video/x-matroska":["mkv","mk3d","mks"],"video/x-mng":["mng"],"video/x-ms-asf":["asf","asx"],"video/x-ms-vob":["vob"],"video/x-ms-wm":["wm"],"video/x-ms-wmv":["wmv"],"video/x-ms-wmx":["wmx"],"video/x-ms-wvx":["wvx"],"video/x-msvideo":["avi"],"video/x-sgi-movie":["movie"],"video/x-smv":["smv"],"x-conference/x-cooltalk":["ice"]}},function(e,t,n){function i(e,t){var n=e.TaskId,i=e.Bucket,r=e.Region,s=e.Key,c=e.StorageClass,l=this,p={},u=e.FileSize,g=e.SliceSize,v=Math.ceil(u/g),x=0,y=h.throttleOnProgress.call(l,u,e.onHashProgress),b=function(t,n){var i=g*(t-1),a=Math.min(i+g,u),o=a-i;p[t]?n(null,{PartNumber:t,ETag:p[t],Size:o}):h.fileSlice(e.FilePath,i,a,(function(e){try{var i=h.getFileMd5(e)}catch(e){return n(e)}var a='"'+i+'"';p[t]=a,x+=o,n(null,{PartNumber:t,ETag:a,Size:o}),y({loaded:x,total:u})}))},k=new f;k.on("error",(function(e){if(l._isRunningTask(n))return t(e)})),k.on("upload_id_available",(function(e){var n={},i=[];h.each(e.PartList,(function(e){n[e.PartNumber]=e}));for(var a=1;a<=v;a++){var o=n[a];o?(o.PartNumber=a,o.Uploaded=!0):o={PartNumber:a,ETag:null,Uploaded:!1},i.push(o)}e.PartList=i,t(null,e)})),k.on("no_available_upload_id",(function(){if(l._isRunningTask(n)){var a=h.extend({Bucket:i,Region:r,Key:s,Headers:h.clone(e.Headers),Query:h.clone(e.Query),StorageClass:c},e);l.multipartInit(a,(function(e,i){if(l._isRunningTask(n)){if(e)return k.emit("error",e);var a=i.UploadId;if(!a)return t({Message:"no upload id"});k.emit("upload_id_available",{UploadId:a,PartList:[]})}}))}})),k.on("has_and_check_upload_id",(function(e){e=e.reverse(),m.eachLimit(e,1,(function(e,t){if(l._isRunningTask(n))return d.using[e]?void t():void o.call(l,{Bucket:i,Region:r,Key:s,UploadId:e},(function(i,a){if(l._isRunningTask(n)){if(i)return d.removeUsing(e),k.emit("error",i);var o=a.PartList;o.forEach((function(e){e.PartNumber*=1,e.Size*=1,e.ETag=e.ETag||""})),function(e,t){var n=e.length;0===n?t(null,!0):n>v||n>1&&Math.max(e[0].Size,e[1].Size)!==g?t(null,!1):function i(a){if(a<n){var o=e[a];b(o.PartNumber,(function(e,n){n&&n.ETag===o.ETag&&n.Size===o.Size?i(a+1):t(null,!1)}))}else t(null,!0)}(0)}(o,(function(i,a){if(l._isRunningTask(n))return i?k.emit("error",i):void(a?t({UploadId:e,PartList:o}):t())}))}}))}),(function(e){l._isRunningTask(n)&&(y(null,!0),e&&e.UploadId?k.emit("upload_id_available",e):k.emit("no_available_upload_id"))}))})),k.on("seek_local_avail_upload_id",(function(t){var a=d.getFileId(e.FileStat,e.ChunkSize,i,s),c=d.getUploadIdList(a);a&&c?function e(a){if(!(a>=c.length)){var p=c[a];return h.isInArray(t,p)?d.using[p]?void e(a+1):void o.call(l,{Bucket:i,Region:r,Key:s,UploadId:p},(function(t,i){l._isRunningTask(n)&&(t?(d.removeUploadId(p),e(a+1)):k.emit("upload_id_available",{UploadId:p,PartList:i.PartList}))})):(d.removeUploadId(p),void e(a+1))}k.emit("has_and_check_upload_id",t)}(0):k.emit("has_and_check_upload_id",t)})),k.on("get_remote_upload_id_list",(function(){a.call(l,{Bucket:i,Region:r,Key:s},(function(t,a){if(l._isRunningTask(n)){if(t)return k.emit("error",t);var o=h.filter(a.UploadList,(function(e){return e.Key===s&&(!c||e.StorageClass.toUpperCase()===c.toUpperCase())})).reverse().map((function(e){return e.UploadId||e.UploadID}));if(o.length)k.emit("seek_local_avail_upload_id",o);else{var r,p=d.getFileId(e.FileStat,e.ChunkSize,i,s);p&&(r=d.getUploadIdList(p))&&h.each(r,(function(e){d.removeUploadId(e)})),k.emit("no_available_upload_id")}}}))})),k.emit("get_remote_upload_id_list")}function a(e,t){var n=this,i=[],a={Bucket:e.Bucket,Region:e.Region,Prefix:e.Key};!function e(){n.multipartList(a,(function(n,o){if(n)return t(n);i.push.apply(i,o.Upload||[]),"true"===o.IsTruncated?(a.KeyMarker=o.NextKeyMarker,a.UploadIdMarker=o.NextUploadIdMarker,e()):t(null,{UploadList:i})}))}()}function o(e,t){var n=this,i=[],a={Bucket:e.Bucket,Region:e.Region,Key:e.Key,UploadId:e.UploadId};!function e(){n.multipartListPart(a,(function(n,o){if(n)return t(n);i.push.apply(i,o.Part||[]),"true"===o.IsTruncated?(a.PartNumberMarker=o.NextPartNumberMarker,e()):t(null,{PartList:i})}))}()}function r(e,t){var n=this,i=e.TaskId,a=e.Bucket,o=e.Region,r=e.Key,c=e.UploadData,l=e.FileSize,p=e.SliceSize,u=Math.min(e.AsyncLimit||n.options.ChunkParallelLimit||1,256),d=e.FilePath,f=Math.ceil(l/p),g=0,v=e.ServerSideEncryption,x=h.filter(c.PartList,(function(e){return e.Uploaded&&(g+=e.PartNumber>=f&&l%p||p),!e.Uploaded})),y=e.onProgress;m.eachLimit(x,u,(function(e,t){if(n._isRunningTask(i)){var u=e.PartNumber,m=Math.min(l,e.PartNumber*p)-(e.PartNumber-1)*p,f=0;s.call(n,{TaskId:i,Bucket:a,Region:o,Key:r,SliceSize:p,FileSize:l,PartNumber:u,ServerSideEncryption:v,FilePath:d,UploadData:c,onProgress:function(e){g+=e.loaded-f,f=e.loaded,y({loaded:g,total:l})}},(function(a,o){n._isRunningTask(i)&&(a?g-=f:(g+=m-f,e.ETag=o.ETag),y({loaded:g,total:l}),t(a||null,o))}))}}),(function(e){if(n._isRunningTask(i))return e?t(e):void t(null,{UploadId:c.UploadId,SliceList:c.PartList})}))}function s(e,t){var n=this,i=e.TaskId,a=e.Bucket,o=e.Region,r=e.Key,s=e.FileSize,c=e.FilePath,l=1*e.PartNumber,p=e.SliceSize,u=e.ServerSideEncryption,d=e.UploadData,f=n.options.ChunkRetryTimes+1,g=e.Headers||{},v=p*(l-1),x=p,y=v+p;y>s&&(x=(y=s)-v);var b=["x-cos-traffic-limit","x-cos-mime-limit"],k={};h.each(g,(function(e,t){b.indexOf(t)>-1&&(k[t]=e)})),h.fileSlice(c,v,y,(function(s){var c=h.getFileMd5(s),p=c?h.binaryBase64(c):null,g=d.PartList[l-1];m.retry(f,(function(t){n._isRunningTask(i)&&n.multipartUpload({TaskId:i,Bucket:a,Region:o,Key:r,ContentLength:x,PartNumber:l,UploadId:d.UploadId,ServerSideEncryption:u,Body:s,Headers:k,onProgress:e.onProgress,ContentMD5:p},(function(e,a){if(n._isRunningTask(i))return e?t(e):(g.Uploaded=!0,t(null,a))}))}),(function(e,a){if(n._isRunningTask(i))return t(e,a)}))}))}function c(e,t){var n=e.Bucket,i=e.Region,a=e.Key,o=e.UploadId,r=e.SliceList,s=this,c=this.options.ChunkRetryTimes+1,l=r.map((function(e){return{PartNumber:e.PartNumber,ETag:e.ETag}}));m.retry(c,(function(e){s.multipartComplete({Bucket:n,Region:i,Key:a,UploadId:o,Parts:l},e)}),(function(e,n){t(e,n)}))}function l(e,t){var n=e.Bucket,i=e.Region,a=e.Key,o=e.AbortArray,r=e.AsyncLimit||1,s=this,c=0,l=new Array(o.length);m.eachLimit(o,r,(function(t,o){var r=c;if(a&&a!==t.Key)return l[r]={error:{KeyNotMatch:!0}},void o(null);var p=t.UploadId||t.UploadID;s.multipartAbort({Bucket:n,Region:i,Key:t.Key,Headers:e.Headers,UploadId:p},(function(e){var a={Bucket:n,Region:i,Key:t.Key,UploadId:p};l[r]={error:e,task:a},o(null)})),c++}),(function(e){if(e)return t(e);for(var n=[],i=[],a=0,o=l.length;a<o;a++){var r=l[a];r.task&&(r.error?i.push(r.task):n.push(r.task))}return t(null,{successList:n,errorList:i})}))}function p(e,t){var n=e.TaskId,i=e.Bucket,a=e.Region,o=e.Key,r=e.CopySource,s=e.UploadId,c=1*e.PartNumber,l=e.CopySourceRange,p=this.options.ChunkRetryTimes+1,u=this;m.retry(p,(function(t){u.uploadPartCopy({TaskId:n,Bucket:i,Region:a,Key:o,CopySource:r,UploadId:s,PartNumber:c,CopySourceRange:l,onProgress:e.onProgress},(function(e,n){t(e||null,n)}))}),(function(e,n){return t(e,n)}))}var u="function"==typeof Symbol&&"symbol"==_typeof3(Symbol.iterator)?function(e){return _typeof3(e)}:function(e){return e&&"function"==typeof Symbol&&e.constructor===Symbol&&e!==Symbol.prototype?"symbol":_typeof3(e)},d=n(6),m=n(28),f=n(5).EventProxy,h=n(0),g={sliceUploadFile:function(e,t){var n=this;if(!h.canFileSlice())return e.SkipTask=!0,void n.postObject(e,t);var a,o,s=new f,l=e.TaskId,p=e.Bucket,u=e.Region,m=e.Key,g=e.FilePath,v=e.ChunkSize||e.SliceSize||n.options.ChunkSize,x=e.AsyncLimit,y=e.StorageClass,b=e.ServerSideEncryption,k=e.onHashProgress;s.on("error",(function(i){if(n._isRunningTask(l)){var a={UploadId:e.UploadData.UploadId||"",err:i};return t(a)}})),s.on("upload_complete",(function(n){var i=h.extend({UploadId:e.UploadData.UploadId||""},n);t(null,i)})),s.on("upload_slice_complete",(function(e){c.call(n,{Bucket:p,Region:u,Key:m,UploadId:e.UploadId,SliceList:e.SliceList},(function(t,i){if(n._isRunningTask(l)){if(d.removeUsing(e.UploadId),t)return o(null,!0),s.emit("error",t);d.removeUploadId(e.UploadId),o({loaded:a,total:a},!0),s.emit("upload_complete",i)}}))})),s.on("get_upload_data_finish",(function(t){var i=d.getFileId(e.FileStat,e.ChunkSize,p,m);i&&d.saveUploadId(i,t.UploadId,n.options.UploadIdCacheLimit),d.setUsing(t.UploadId),o(null,!0),r.call(n,{TaskId:l,Bucket:p,Region:u,Key:m,FilePath:g,FileSize:a,SliceSize:v,AsyncLimit:x,ServerSideEncryption:b,UploadData:t,onProgress:o},(function(e,t){if(n._isRunningTask(l))return e?(o(null,!0),s.emit("error",e)):void s.emit("upload_slice_complete",t)}))})),s.on("get_file_size_finish",(function(){if(o=h.throttleOnProgress.call(n,a,e.onProgress),e.UploadData.UploadId)s.emit("get_upload_data_finish",e.UploadData);else{var t=h.extend({TaskId:l,Bucket:p,Region:u,Key:m,Headers:e.Headers,StorageClass:y,FilePath:g,FileSize:a,SliceSize:v,onHashProgress:k},e);i.call(n,t,(function(t,i){if(n._isRunningTask(l)){if(t)return s.emit("error",t);e.UploadData.UploadId=i.UploadId,e.UploadData.PartList=i.PartList,s.emit("get_upload_data_finish",e.UploadData)}}))}})),a=e.ContentLength,delete e.ContentLength,!e.Headers&&(e.Headers={}),h.each(e.Headers,(function(t,n){"content-length"===n.toLowerCase()&&delete e.Headers[n]})),function(){for(var t=[1,2,4,8,16,32,64,128,256,512,1024,2048,4096,5120],i=1048576,o=0;o<t.length&&!(a/(i=1024*t[o]*1024)<=n.options.MaxPartNumber);o++);e.ChunkSize=e.SliceSize=v=Math.max(v,i)}(),0===a?(e.Body="",e.ContentLength=0,e.SkipTask=!0,n.putObject(e,(function(e,n){if(e)return t(e);t(null,n)}))):s.emit("get_file_size_finish")},abortUploadTask:function(e,t){var n=e.Bucket,i=e.Region,o=e.Key,r=e.UploadId,s=e.Level||"task",c=e.AsyncLimit,p=this,u=new f;if(u.on("error",(function(e){return t(e)})),u.on("get_abort_array",(function(a){l.call(p,{Bucket:n,Region:i,Key:o,Headers:e.Headers,AsyncLimit:c,AbortArray:a},(function(e,n){if(e)return t(e);t(null,n)}))})),"bucket"===s)a.call(p,{Bucket:n,Region:i},(function(e,n){if(e)return t(e);u.emit("get_abort_array",n.UploadList||[])}));else if("file"===s){if(!o)return t({error:"abort_upload_task_no_key"});a.call(p,{Bucket:n,Region:i,Key:o},(function(e,n){if(e)return t(e);u.emit("get_abort_array",n.UploadList||[])}))}else{if("task"!==s)return t({error:"abort_unknown_level"});if(!r)return t({error:"abort_upload_task_no_id"});if(!o)return t({error:"abort_upload_task_no_key"});u.emit("get_abort_array",[{Key:o,UploadId:r}])}},uploadFile:function(e,t){var n=void 0===e.SliceSize?this.options.SliceSize:e.SliceSize,i=[],a=e.FileSize,o={TaskId:""};h.each(e,(function(e,t){"object"!==(void 0===e?"undefined":u(e))&&"function"!=typeof e&&(o[t]=e)}));var r=e.onTaskReady;e.onTaskReady=function(e){o.TaskId=e,r&&r(e)};var s=e.onFileFinish,c=a>n?"sliceUploadFile":"postObject";i.push({api:c,params:e,callback:function(e,n){s&&s(e,n,o),t&&t(e,n)}}),this._addTasks(i)},uploadFiles:function(e,t){var n=this,i=void 0===e.SliceSize?n.options.SliceSize:e.SliceSize,a=0,o=0,r=h.throttleOnProgress.call(n,o,e.onProgress),s=e.files.length,c=e.onFileFinish,l=Array(s),p=function(e,n,i){r(null,!0),c&&c(e,n,i),l[i.Index]={options:i,error:e,data:n},--s<=0&&t&&t(null,{files:l})},d=[];h.each(e.files,(function(e,t){var n=e.FileSize,s={Index:t,TaskId:""};a+=n,h.each(e,(function(e,t){"object"!==(void 0===e?"undefined":u(e))&&"function"!=typeof e&&(s[t]=e)}));var c=e.onTaskReady;e.onTaskReady=function(e){s.TaskId=e,c&&c(e)};var l=0,m=e.onProgress;e.onProgress=function(e){o=o-l+e.loaded,l=e.loaded,m&&m(e),r({loaded:o,total:a})};var f=e.onFileFinish,g=n>i?"sliceUploadFile":"postObject";d.push({api:g,params:e,callback:function(e,t){f&&f(e,t),p&&p(e,t,s)}})})),n._addTasks(d)},sliceCopyFile:function(e,t){var n=new f,i=this,a=e.Bucket,o=e.Region,r=e.Key,s=e.CopySource,c=s.match(/^([^.]+-\d+)\.cos(v6)?\.([^.]+)\.[^/]+\/(.+)$/);if(c){var l=c[1],u=c[3],d=decodeURIComponent(c[4]),g=void 0===e.CopySliceSize?i.options.CopySliceSize:e.CopySliceSize;g=Math.max(0,g);var v,x,y=e.CopyChunkSize||this.options.CopyChunkSize,b=this.options.CopyChunkParallelLimit,k=0;n.on("copy_slice_complete",(function(e){i.multipartComplete({Bucket:a,Region:o,Key:r,UploadId:e.UploadId,Parts:e.PartList},(function(e,n){if(e)return x(null,!0),t(e);x({loaded:v,total:v},!0),t(null,n)}))})),n.on("get_copy_data_finish",(function(e){m.eachLimit(e.PartList,b,(function(t,n){var c=t.PartNumber,l=t.CopySourceRange,u=t.end-t.start,d=0;p.call(i,{Bucket:a,Region:o,Key:r,CopySource:s,UploadId:e.UploadId,PartNumber:c,CopySourceRange:l,onProgress:function(e){k+=e.loaded-d,d=e.loaded,x({loaded:k,total:v})}},(function(e,i){if(e)return n(e);x({loaded:k,total:v}),k+=u-d,t.ETag=i.ETag,n(e||null,i)}))}),(function(i){if(i)return x(null,!0),t(i);n.emit("copy_slice_complete",e)}))})),n.on("get_file_size_finish",(function(s){var c;if(function(){for(var t=[1,2,4,8,16,32,64,128,256,512,1024,2048,4096,5120],n=1048576,a=0;a<t.length&&!(v/(n=1024*t[a]*1024)<=i.options.MaxPartNumber);a++);e.ChunkSize=y=Math.max(y,n);for(var o=Math.ceil(v/y),r=[],s=1;s<=o;s++){var c=(s-1)*y,l=s*y<v?s*y-1:v-1,p={PartNumber:s,start:c,end:l,CopySourceRange:"bytes="+c+"-"+l};r.push(p)}e.PartList=r}(),(c="Replaced"===e.Headers["x-cos-metadata-directive"]?e.Headers:s)["x-cos-storage-class"]=e.Headers["x-cos-storage-class"]||s["x-cos-storage-class"],c=h.clearKey(c),"ARCHIVE"===s["x-cos-storage-class"]||"DEEP_ARCHIVE"===s["x-cos-storage-class"]){var l=s["x-cos-restore"];if(!l||'ongoing-request="true"'===l)return void t({error:"Unrestored archive object is not allowed to be copied"})}delete c["x-cos-copy-source"],delete c["x-cos-metadata-directive"],delete c["x-cos-copy-source-If-Modified-Since"],delete c["x-cos-copy-source-If-Unmodified-Since"],delete c["x-cos-copy-source-If-Match"],delete c["x-cos-copy-source-If-None-Match"],i.multipartInit({Bucket:a,Region:o,Key:r,Headers:c},(function(i,a){if(i)return t(i);e.UploadId=a.UploadId,n.emit("get_copy_data_finish",e)}))})),i.headObject({Bucket:l,Region:u,Key:d},(function(a,o){if(a)t(a.statusCode&&404===a.statusCode?{ErrorStatus:d+" Not Exist"}:a);else if(void 0!==(v=e.FileSize=o.headers["content-length"])&&v)if(x=h.throttleOnProgress.call(i,v,e.onProgress),v<=g)e.Headers["x-cos-metadata-directive"]||(e.Headers["x-cos-metadata-directive"]="Copy"),i.putObjectCopy(e,(function(e,n){if(e)return x(null,!0),t(e);x({loaded:v,total:v},!0),t(e,n)}));else{var r=o.headers,s={"Cache-Control":r["cache-control"],"Content-Disposition":r["content-disposition"],"Content-Encoding":r["content-encoding"],"Content-Type":r["content-type"],Expires:r.expires,"x-cos-storage-class":r["x-cos-storage-class"]};h.each(r,(function(e,t){0===t.indexOf("x-cos-meta-")&&t.length>"x-cos-meta-".length&&(s[t]=e)})),n.emit("get_file_size_finish",s)}else t({error:'get Content-Length error, please add "Content-Length" to CORS ExposeHeader setting.'})}))}else t({error:"CopySource format error"})}};e.exports.init=function(e,t){t.transferToTaskMethod(g,"sliceUploadFile"),h.each(g,(function(t,n){e.prototype[n]=h.apiWrapper(n,t)}))}},function(e,t,n){var i={eachLimit:function(e,t,n,i){if(i=i||function(){},!e.length||t<=0)return i();var a=0,o=0,r=0;!function s(){if(a>=e.length)return i();for(;r<t&&o<e.length;)r+=1,n(e[(o+=1)-1],(function(t){t?(i(t),i=function(){}):(r-=1,(a+=1)>=e.length?i():s())}))}()},retry:function(e,t,n){e<1?n():function i(a){t((function(t,o){t&&a<e?i(a+1):n(t,o)}))}(1)}};e.exports=i}])},"object"==("undefined"==typeof exports?"undefined":_typeof3(exports))&&"object"==("undefined"==typeof module?"undefined":_typeof3(module))?module.exports=t():"function"==typeof define&&define.amd?define([],t):"object"==("undefined"==typeof exports?"undefined":_typeof3(exports))?exports.COS=t():e.COS=t();
},{isPage:false,isComponent:false,currentFile:'components/cos/cos-wx-sdk-v5.min.js'});;__wxRoute = undefined;__wxRouteBegin = undefined;__wxAppCurrentFile__=undefined;define("components/emoji/emoji-parser.esm.js",function(require,module,exports,window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){
"use strict";Object.defineProperty(exports,"__esModule",{value:!0}),exports.configParseEmoji=function(e){e&&Object.assign(y,e)},exports.getEmojis=void 0,exports.parseEmoji=function(o){return o?(k.search(o).reverse().map((function(i){var c=e(i,2),d=c[0],n=c[1],s=r[n],t=function(e,o){var i=o.tag,c="",d=x(e,o);d&&Object.keys(d).forEach((function(e){void 0!==d[e]&&(c+="".concat(e,": ").concat(d[e],";"))}));return"<".concat(i,' style="').concat(c,'margin:0 1px;vertical-align:middle;"></').concat(i,">")}(p[s],y);o=function(e,o,i,c){return e.slice(0,o)+c+e.slice(o+i)}(o,d,s.length,t)})),o):o};var e=require("../../@babel/runtime/helpers/slicedToArray"),o=require("../../@babel/runtime/helpers/classCallCheck"),i=require("../../@babel/runtime/helpers/createClass"),c="https://cos.wsqytec.com/emoji/emoji-sprite.png",d=function(){function e(i){o(this,e),this.tier=0,this.matched=!0,this.wordsIndex=0,this.children={},i&&this.build(i)}return i(e,[{key:"build",value:function(e){for(var o=e.length,i=0;i<o;i++)this.insert(e[i],0,i)}},{key:"insert",value:function(o){var i=arguments.length>1&&void 0!==arguments[1]?arguments[1]:0,c=arguments.length>2?arguments[2]:void 0;if(0!==o.length){var d,n=this;i!==o.length?(d=o[i],void 0===n.children[d]&&(n.children[d]=new e,n.matched=!1,n.children[d].tier=this.tier+1),n.children[d].insert(o,i+1,c)):n.wordsIndex=c}}},{key:"searchOne",value:function(e){var o=arguments.length>1&&void 0!==arguments[1]?arguments[1]:0;if(0===e.length)return null;var i,c,d=this;return c=e[o],void 0!==(i=d.children[c])&&o<e.length?i.searchOne(e,o+1):(void 0!==i||d.matched)&&d.matched?{matchedPosition:[o-d.tier,d.wordsIndex],tier:d.tier}:null}},{key:"search",value:function(e){if(this.matched)return[];for(var o,i=e.length,c=[],d=0;d<i-1;d++)(o=this.searchOne(e,d))&&(c.push(o.matchedPosition),d=d+o.tier-1);return c}}]),e}(),n={width:724,height:658,x:11,y:10,paddingTop:0,paddingBottom:0,paddingLeft:0,paddingRight:0,gapX:0,gapY:0},s=[{position:{x:0,y:0},id:0,cn:"[右哼哼]",hk:"[右哼哼]",us:"[Bah！R]",code:"/:@>",web_code:"/右哼哼"},{position:{x:1,y:0},id:1,cn:"[奸笑]",hk:"[奸笑]",us:"[Smirk]",code:"",web_code:""},{position:{x:2,y:0},id:2,cn:"[红包]",hk:"[Packet]",us:"[Packet]",code:"",web_code:""},{position:{x:3,y:0},id:3,cn:"[生病]",emoji:"😷",hk:"",us:"",code:"\\ue40c",web_code:""},{position:{x:4,y:0},id:4,cn:"[冷汗]",hk:"[冷汗]",us:"[Blush]",code:"/:--b",web_code:"/冷汗"},{position:{x:5,y:0},id:5,cn:"[惊恐]",hk:"[驚恐]",us:"[Panic]",code:"/::!",web_code:"/惊恐"},{position:{x:6,y:0},id:6,cn:"[Emm]",hk:"[]",us:"[]",code:"",web_code:""},{position:{x:7,y:0},id:7,cn:"[得意]",hk:"[得意]",us:"[CoolGuy]",code:"/:8-)",web_code:"/得意"},{position:{x:8,y:0},id:8,cn:"[菜刀]",hk:"[菜刀]",us:"[Cleaver]",code:"/:pd",web_code:"/菜刀"},{position:{x:9,y:0},id:9,cn:"[太阳]",hk:"[太陽]",us:"[Sun]",code:"/:sun",web_code:"/太阳"},{position:{x:10,y:0},id:10,cn:"[强壮]",emoji:"💪",hk:"",us:"",code:"\\ue14c",web_code:""},{position:{x:0,y:1},id:11,cn:"[捂脸]",hk:"[掩面]",us:"[Facepalm]",code:"",web_code:""},{position:{x:1,y:1},id:12,cn:"[机智]",hk:"[機智]",us:"[Smart]",code:"",web_code:""},{position:{x:2,y:1},id:13,cn:"[耶]",hk:"[歐耶]",us:"[Yeah!]",code:"",web_code:""},{position:{x:3,y:1},id:14,cn:"[尴尬]",hk:"[尷尬]",us:"[Awkward]",code:"/::-|",web_code:"/尴尬"},{position:{x:4,y:1},id:15,cn:"[抓狂]",hk:"[抓狂]",us:"[Scream]",code:"/::Q",web_code:"/抓狂"},{position:{x:5,y:1},id:16,cn:"[流汗]",hk:"[流汗]",us:"[Sweat]",code:"/::L",web_code:"/流汗"},{position:{x:6,y:1},id:17,cn:"[社会社会]",hk:"[]",us:"[]",code:"",web_code:""},{position:{x:7,y:1},id:18,cn:"[擦汗]",hk:"[擦汗]",us:"[Speechless]",code:"/:wipe",web_code:"/擦汗"},{position:{x:8,y:1},id:19,cn:"[西瓜]",hk:"[西瓜]",us:"[Watermelon]",code:"/:<W>",web_code:"/西瓜"},{position:{x:9,y:1},id:20,cn:"[拥抱]",hk:"[擁抱]",us:"[Hug]",code:"/:hug",web_code:"/拥抱"},{position:{x:10,y:1},id:21,cn:"[破涕为笑]",emoji:"😂",hk:"",us:"",code:"\\ue412",web_code:""},{position:{x:0,y:2},id:22,cn:"[皱眉]",hk:"[皺眉]",us:"[Moue]",code:"",web_code:""},{position:{x:1,y:2},id:23,cn:"[鸡]",hk:"[小雞]",us:"[Chick]",code:"",web_code:""},{position:{x:2,y:2},id:24,cn:"[微笑]",hk:"[微笑]",us:"[Smile]",code:"/::)",web_code:"/微笑"},{position:{x:3,y:2},id:25,cn:"[发怒]",hk:"[發怒]",us:"[Angry]",code:"/::@",web_code:"/发怒"},{position:{x:4,y:2},id:26,cn:"[吐]",hk:"[吐]",us:"[Puke]",code:"/::T",web_code:"/吐"},{position:{x:5,y:2},id:27,cn:"[憨笑]",hk:"[大笑]",us:"[Laugh]",code:"/::>",web_code:"/憨笑"},{position:{x:6,y:2},id:28,cn:"[旺柴]",hk:"[]",us:"[]",code:"",web_code:""},{position:{x:7,y:2},id:29,cn:"[抠鼻]",hk:"[摳鼻]",us:"[NosePick]",code:"/:dig",web_code:"/抠鼻"},{position:{x:8,y:2},id:30,cn:"[啤酒]",hk:"[啤酒]",us:"[Beer]",code:"/:beer",web_code:"/啤酒"},{position:{x:9,y:2},id:31,cn:"[强]",hk:"[強]",us:"[ThumbsUp]",code:"/:strong",web_code:"/强"},{position:{x:10,y:2},id:32,cn:"[笑脸]",emoji:"😄",hk:"",us:"",code:"\\ue415",web_code:""},{position:{x:0,y:3},id:33,cn:"[调皮]",hk:"[調皮]",us:"[Tongue]",code:"/::P",web_code:"/调皮"},{position:{x:1,y:3},id:34,cn:"[呲牙]",hk:"[呲牙]",us:"[Grin]",code:"/::D",web_code:"/呲牙"},{position:{x:2,y:3},id:35,cn:"[惊讶]",hk:"[驚訝]",us:"[Surprise]",code:"/::O",web_code:"/惊讶"},{position:{x:3,y:3},id:36,cn:"[难过]",hk:"[難過]",us:"[Frown]",code:"/::(",web_code:"/难过"},{position:{x:4,y:3},id:37,cn:"[色]",hk:"[色]",us:"[Drool]",code:"/::B",web_code:"/色"},{position:{x:5,y:3},id:38,cn:"[悠闲]",hk:"[悠閑]",us:"[Commando]",code:"/::,@",web_code:"/大兵"},{position:{x:6,y:3},id:39,cn:"[疑问]",hk:"[疑問]",us:"[Shocked]",code:"/:?",web_code:"/疑问"},{position:{x:7,y:3},id:40,cn:"[鼓掌]",hk:"[鼓掌]",us:"[Clap]",code:"/:handclap",web_code:"/鼓掌"},{position:{x:8,y:3},id:41,cn:"[害羞]",hk:"[害羞]",us:"[Shy]",code:"/::$",web_code:"/害羞"},{position:{x:9,y:3},id:42,cn:"[睡]",hk:"[睡]",us:"[Sleep]",code:"/::Z",web_code:"/睡"},{position:{x:10,y:3},id:43,cn:"[无语]",emoji:"😒",hk:"",us:"",code:"\\ue40e",web_code:""},{position:{x:0,y:4},id:44,cn:"[偷笑]",hk:"[偷笑]",us:"[Chuckle]",code:"/:,@P",web_code:"/偷笑"},{position:{x:1,y:4},id:45,cn:"[愉快]",hk:"[愉快]",us:"[Joyful]",code:"/:,@-D",web_code:"/可爱"},{position:{x:2,y:4},id:46,cn:"[白眼]",hk:"[白眼]",us:"[Slight]",code:"/::d",web_code:"/白眼"},{position:{x:3,y:4},id:47,cn:"[傲慢]",hk:"[傲慢]",us:"[Smug]",code:"/:,@o",web_code:"/傲慢"},{position:{x:4,y:4},id:48,cn:"[困]",hk:"[累]",us:"[Drowsy]",code:"/:|-)",web_code:"/困"},{position:{x:5,y:4},id:49,cn:"[发呆]",hk:"[發呆]",us:"[Scowl]",code:"/::|",web_code:"/发呆"},{position:{x:6,y:4},id:50,cn:"[好的]",hk:"[]",us:"[]",code:"",web_code:""},{position:{x:7,y:4},id:51,cn:"[坏笑]",hk:"[壞笑]",us:"[Trick]",code:"/:B-)",web_code:"/坏笑"},{position:{x:8,y:4},id:52,cn:"[咖啡]",hk:"[咖啡]",us:"[Coffee]",code:"/:coffee",web_code:"/咖啡"},{position:{x:9,y:4},id:53,cn:"[弱]",hk:"[弱]",us:"[ThumbsDown]",code:"/:weak",web_code:"/弱"},{position:{x:10,y:4},id:54,cn:"[失望]",emoji:"😔",hk:"",us:"",code:"\\ue403",web_code:""},{position:{x:0,y:5},id:55,cn:"[奋斗]",hk:"[奮鬥]",us:"[Determined]",code:"/:,@f",web_code:"/奋斗"},{position:{x:1,y:5},id:56,cn:"[咒骂]",hk:"[咒罵]",us:"[Scold]",code:"/::-S",web_code:"/咒骂"},{position:{x:2,y:5},id:57,cn:"[吃瓜]",hk:"[]",us:"[]",code:"",web_code:""},{position:{x:3,y:5},id:58,cn:"[加油]",hk:"[]",us:"[]",code:"",web_code:""},{position:{x:4,y:5},id:59,cn:"[汗]",hk:"[]",us:"[]",code:"",web_code:""},{position:{x:5,y:5},id:60,cn:"[天啊]",hk:"[]",us:"[]",code:"",web_code:""},{position:{x:6,y:5},id:61,cn:"[打脸]",hk:"[]",us:"[]",code:"",web_code:""},{position:{x:7,y:5},id:62,cn:"[左哼哼]",hk:"[左哼哼]",us:"[Bah！L]",code:"/:<@",web_code:"/左哼哼"},{position:{x:8,y:5},id:63,cn:"[饭]",hk:"[飯]",us:"[Rice]",code:"/:eat",web_code:"/饭"},{position:{x:9,y:5},id:64,cn:"[握手]",hk:"[握手]",us:"[Shake]",code:"/:share",web_code:"/握手"},{position:{x:10,y:5},id:65,cn:"[吐舌]",emoji:"😝",hk:"",us:"",code:"\\ue409",web_code:""},{position:{x:0,y:6},id:66,cn:"[哇]",hk:"[]",us:"[]",code:"",web_code:""},{position:{x:1,y:6},id:67,cn:"[嘘]",hk:"[噓]",us:"[Shhh]",code:"/:,@x",web_code:"/嘘"},{position:{x:2,y:6},id:68,cn:"[晕]",hk:"[暈]",us:"[Dizzy]",code:"/:,@@",web_code:"/晕"},{position:{x:3,y:6},id:69,cn:"[衰]",hk:"[衰]",us:"[Toasted]",code:"/:,@!",web_code:"/衰"},{position:{x:4,y:6},id:70,cn:"[骷髅]",hk:"[骷髏頭]",us:"[Skull]",code:"/:!!!",web_code:"/骷髅"},{position:{x:5,y:6},id:71,cn:"[敲打]",hk:"[敲打]",us:"[Hammer]",code:"/:xx",web_code:"/敲打"},{position:{x:6,y:6},id:72,cn:"[再见]",hk:"[再見]",us:"[Wave]",code:"/:bye",web_code:"/再见"},{position:{x:7,y:6},id:73,cn:"[嘿哈]",hk:"[吼嘿]",us:"[Hey]",code:"",web_code:""},{position:{x:8,y:6},id:74,cn:"[猪头]",hk:"[豬頭]",us:"[Pig]",code:"/:pig",web_code:"/猪头"},{position:{x:9,y:6},id:75,cn:"[胜利]",hk:"[勝利]",us:"[Peace]",code:"/:v",web_code:"/胜利"},{position:{x:10,y:6},id:76,cn:"[恐惧]",emoji:"😱",hk:"",us:"",code:"\\ue107",web_code:""},{position:{x:0,y:7},id:77,cn:"[哈欠]",hk:"[哈欠]",us:"[Yawn]",code:"/::-O",web_code:"/哈欠"},{position:{x:1,y:7},id:78,cn:"[鄙视]",hk:"[鄙視]",us:"[Pooh-pooh]",code:"/:>-|",web_code:"/鄙视"},{position:{x:2,y:7},id:79,cn:"[委屈]",hk:"[委屈]",us:"[Shrunken]",code:"/:P-(",web_code:"/委屈"},{position:{x:3,y:7},id:80,cn:"[流泪]",hk:"[流淚]",us:"[Sob]",code:"/::<",web_code:"/流泪"},{position:{x:4,y:7},id:81,cn:"[快哭了]",hk:"[快哭了]",us:"[TearingUp]",code:'/::"|',web_code:"/快哭了"},{position:{x:5,y:7},id:82,cn:"[阴险]",hk:"[陰險]",us:"[Sly]",code:"/:X-)",web_code:"/阴险"},{position:{x:6,y:7},id:83,cn:"[亲亲]",hk:"[親親]",us:"[Kiss]",code:"/::*",web_code:"/亲亲"},{position:{x:7,y:7},id:84,cn:"[可怜]",hk:"[可憐]",us:"[Whimper]",code:"/:8*",web_code:"/可怜"},{position:{x:8,y:7},id:85,cn:"[玫瑰]",hk:"[玫瑰]",us:"[Rose]",code:"/:rose",web_code:"/玫瑰"},{position:{x:9,y:7},id:86,cn:"[抱拳]",hk:"[抱拳]",us:"[Fight]",code:"/:@)",web_code:"/抱拳"},{position:{x:10,y:7},id:87,cn:"[脸红]",emoji:"😳",hk:"",us:"",code:"\\ue40d",web_code:""},{position:{x:0,y:8},id:88,cn:"[凋谢]",hk:"[枯萎]",us:"[Wilt]",code:"/:fade",web_code:"/凋谢"},{position:{x:1,y:8},id:89,cn:"[嘴唇]",hk:"[嘴唇]",us:"[Lips]",code:"/:showlove",web_code:"/示爱"},{position:{x:2,y:8},id:90,cn:"[爱心]",hk:"[愛心]",us:"[Heart]",code:"/:heart",web_code:"/爱心"},{position:{x:3,y:8},id:91,cn:"[心碎]",hk:"[心碎]",us:"[BrokenHeart]",code:"/:break",web_code:"/心碎"},{position:{x:4,y:8},id:92,cn:"[蛋糕]",hk:"[蛋糕]",us:"[Cake]",code:"/:cake",web_code:"/蛋糕"},{position:{x:5,y:8},id:93,cn:"[闭嘴]",hk:"[閉嘴]",us:"[Silent]",code:"/::X",web_code:"/闭嘴"},{position:{x:6,y:8},id:94,cn:"[炸弹]",hk:"[炸彈]",us:"[Bomb]",code:"/:bome",web_code:"/炸弹"},{position:{x:7,y:8},id:95,cn:"[便便]",hk:"[便便]",us:"[Poop]",code:"/:shit",web_code:"/便便"},{position:{x:8,y:8},id:96,cn:"[月亮]",hk:"[月亮]",us:"[Moon]",code:"/:moon",web_code:"/月亮"},{position:{x:9,y:8},id:97,cn:"[勾引]",hk:"[勾引]",us:"[Beckon]",code:"/:jj",web_code:"/勾引"},{position:{x:10,y:8},id:98,cn:"[合十]",emoji:"🙏",hk:"",us:"",code:"\\ue41d",web_code:""},{position:{x:0,y:9},id:99,cn:"[拳头]",hk:"[拳頭]",us:"[Fist]",code:"/:@@",web_code:"/拳头"},{position:{x:1,y:9},id:100,cn:"[OK]",hk:"[OK]",us:"[OK]",code:"/:ok",web_code:"/OK"},{position:{x:2,y:9},id:101,cn:"[大哭]",hk:"[大哭]",us:"[Cry]",code:'/::"(',web_code:"/大哭"},{position:{x:3,y:9},id:102,cn:"[跳跳]",hk:"[跳跳]",us:"[Waddle]",code:"/:jump",web_code:"/跳跳"},{position:{x:4,y:9},id:103,cn:"[发抖]",hk:"[發抖]",us:"[Tremble]",code:"/:shake",web_code:"/发抖"},{position:{x:5,y:9},id:104,cn:"[怄火]",hk:"[噴火]",us:"[Aaagh!]",code:"/:<O>",web_code:"/怄火"},{position:{x:6,y:9},id:105,cn:"[转圈]",hk:"[轉圈]",us:"[Twirl]",code:"/:circle",web_code:"/转圈"},{position:{x:7,y:9},id:106,cn:"[礼物]",hk:"",us:"",code:"\\ue112",web_code:""},{position:{x:8,y:9},id:107,cn:"[庆祝]",emoji:"🎉",hk:"",us:"",code:"\\ue312",web_code:""},{position:{x:9,y:9},id:108,cn:"[鬼魂]",emoji:"👻",hk:"",us:"",code:"\\ue11b",web_code:""},{position:{x:10,y:9},id:109,cn:"[撇嘴]",hk:"[撇嘴]",us:"[Grimace]",code:"/::~",web_code:"/撇嘴"}];var t,h,u,p=(h=["cn","us","code","web_code"],u={},(t=s)&&t.forEach((function(e){h.forEach((function(o){var i=e[o];i&&"[]"!==i&&!(i in u)&&(u[i]=e.position)}))})),u);var r=Object.keys(p),k=new d(r),b={};function x(e,o){var i=n.gapX,c=n.gapY,d=o.size,s=o.emojiSpriteUrl,t=function(e,o){if(b[o])return b[o];var i=e.width,c=e.x,d=o/((i-e.paddingLeft-e.paddingRight-e.gapX*(c-1))/c),n=+(i*d).toFixed(2);return b[o]={scale:d,bgSize:n},b[o]}(n,d),h=t.scale,u=t.bgSize,p="";if(e){var r=e.x,k=e.y,x=-(r*(d+h*i)).toFixed(2),y=-(k*(d+h*c)).toFixed(2);p="".concat(x,"px ").concat(y,"px")}return{display:"inline-block",background:"url(".concat(s,") no-repeat"),width:"".concat(d,"px"),height:"".concat(d,"px"),"background-position":"".concat(p),"background-size":"".concat(u,"px")}}var y={size:64,tag:"a",emojiSpriteUrl:c};var a;exports.getEmojis=(a=s,function(e){var o={size:64,emojiSpriteUrl:c};return e&&(o=Object.assign(o,e)),a.map((function(e){var i=e.position,c=e.code,d=e.cn,n=i&&x(i,o)||{};return{style:n=JSON.stringify(n).replace(new RegExp(",","g"),";").replace(new RegExp('"',"g"),"").replace("{","").replace("}",""),code:c,cn:d}}))});
},{isPage:false,isComponent:false,currentFile:'components/emoji/emoji-parser.esm.js'});;__wxRoute = undefined;__wxRouteBegin = undefined;__wxAppCurrentFile__=undefined;define("components/vant/common/color.js",function(require,module,exports,window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){
"use strict";Object.defineProperty(exports,"__esModule",{value:!0}),exports.RED="#ee0a24",exports.BLUE="#1989fa",exports.WHITE="#fff",exports.GREEN="#07c160",exports.ORANGE="#ff976a",exports.GRAY="#323233",exports.GRAY_DARK="#969799";
},{isPage:false,isComponent:false,currentFile:'components/vant/common/color.js'});;__wxRoute = undefined;__wxRouteBegin = undefined;__wxAppCurrentFile__=undefined;define("components/vant/common/component.js",function(require,module,exports,window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){
"use strict";Object.defineProperty(exports,"__esModule",{value:!0});var e=require("../mixins/basic");exports.VantComponent=function(s){var a;void 0===s&&(s={});var t,r,o,i={};t=s,r=i,o={data:"data",props:"properties",mixins:"behaviors",methods:"methods",beforeCreate:"created",created:"attached",mounted:"ready",relations:"relations",destroyed:"detached",classes:"externalClasses"},Object.keys(o).forEach((function(e){t[e]&&(r[o[e]]=t[e])}));var n=s.relation;n&&(i.relations=Object.assign(i.relations||{},((a={})["../"+n.name+"/index"]=n,a))),i.externalClasses=i.externalClasses||[],i.externalClasses.push("custom-class"),i.behaviors=i.behaviors||[],i.behaviors.push(e.basic),s.field&&i.behaviors.push("wx://form-field"),i.options={multipleSlots:!0,addGlobalClass:!0},Component(i)};
},{isPage:false,isComponent:false,currentFile:'components/vant/common/component.js'});;__wxRoute = undefined;__wxRouteBegin = undefined;__wxAppCurrentFile__=undefined;define("components/vant/common/utils.js",function(require,module,exports,window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){
"use strict";var t=require("../../../@babel/runtime/helpers/typeof");function e(t){return null!=t}function n(t){return/^\d+(\.\d+)?$/.test(t)}Object.defineProperty(exports,"__esModule",{value:!0}),exports.isDef=e,exports.isObj=function(e){var n=t(e);return null!==e&&("object"===n||"function"===n)},exports.isNumber=n,exports.range=function(t,e,n){return Math.min(Math.max(t,e),n)},exports.nextTick=function(t){setTimeout((function(){t()}),1e3/30)};var r=null;exports.getSystemInfoSync=function(){return null==r&&(r=wx.getSystemInfoSync()),r},exports.addUnit=function(t){if(e(t))return n(t=String(t))?t+"px":t};
},{isPage:false,isComponent:false,currentFile:'components/vant/common/utils.js'});;__wxRoute = undefined;__wxRouteBegin = undefined;__wxAppCurrentFile__=undefined;define("components/vant/mixins/basic.js",function(require,module,exports,window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){
"use strict";Object.defineProperty(exports,"__esModule",{value:!0}),exports.basic=Behavior({methods:{$emit:function(){for(var e=[],t=0;t<arguments.length;t++)e[t]=arguments[t];this.triggerEvent.apply(this,e)},set:function(e,t){return this.setData(e,t),new Promise((function(e){return wx.nextTick(e)}))},getRect:function(e,t){var n=this;return new Promise((function(r){wx.createSelectorQuery().in(n)[t?"selectAll":"select"](e).boundingClientRect((function(e){t&&Array.isArray(e)&&e.length&&r(e),!t&&e&&r(e)})).exec()}))}}});
},{isPage:false,isComponent:false,currentFile:'components/vant/mixins/basic.js'});;__wxRoute = undefined;__wxRouteBegin = undefined;__wxAppCurrentFile__=undefined;define("components/vant/mixins/button.js",function(require,module,exports,window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){
"use strict";Object.defineProperty(exports,"__esModule",{value:!0}),exports.button=Behavior({externalClasses:["hover-class"],properties:{id:String,lang:{type:String,value:"en"},businessId:Number,sessionFrom:String,sendMessageTitle:String,sendMessagePath:String,sendMessageImg:String,showMessageCard:Boolean,appParameter:String,ariaLabel:String}});
},{isPage:false,isComponent:false,currentFile:'components/vant/mixins/button.js'});;__wxRoute = undefined;__wxRouteBegin = undefined;__wxAppCurrentFile__=undefined;define("components/vant/mixins/link.js",function(require,module,exports,window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){
"use strict";Object.defineProperty(exports,"__esModule",{value:!0}),exports.link=Behavior({properties:{url:String,linkType:{type:String,value:"navigateTo"}},methods:{jumpLink:function(e){void 0===e&&(e="url");var t=this.data[e];t&&wx[this.data.linkType]({url:t})}}});
},{isPage:false,isComponent:false,currentFile:'components/vant/mixins/link.js'});;__wxRoute = undefined;__wxRouteBegin = undefined;__wxAppCurrentFile__=undefined;define("components/vant/mixins/open-type.js",function(require,module,exports,window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){
"use strict";Object.defineProperty(exports,"__esModule",{value:!0}),exports.openType=Behavior({properties:{openType:String},methods:{bindGetUserInfo:function(e){this.$emit("getuserinfo",e.detail)},bindContact:function(e){this.$emit("contact",e.detail)},bindGetPhoneNumber:function(e){this.$emit("getphonenumber",e.detail)},bindError:function(e){this.$emit("error",e.detail)},bindLaunchApp:function(e){this.$emit("launchapp",e.detail)},bindOpenSetting:function(e){this.$emit("opensetting",e.detail)}}});
},{isPage:false,isComponent:false,currentFile:'components/vant/mixins/open-type.js'});;__wxRoute = undefined;__wxRouteBegin = undefined;__wxAppCurrentFile__=undefined;define("components/vant/mixins/page-scroll.js",function(require,module,exports,window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){
"use strict";function e(){var e=getCurrentPages();return e[e.length-1]||{}}function r(r){var n=e().vanPageScroller;(void 0===n?[]:n).forEach((function(e){"function"==typeof e&&e(r)}))}Object.defineProperty(exports,"__esModule",{value:!0}),exports.pageScrollMixin=void 0,exports.pageScrollMixin=function(n){return Behavior({attached:function(){var o=e();Array.isArray(o.vanPageScroller)?o.vanPageScroller.push(n.bind(this)):o.vanPageScroller="function"==typeof o.onPageScroll?[o.onPageScroll.bind(o),n.bind(this)]:[n.bind(this)],o.onPageScroll=r},detached:function(){var r=e();r.vanPageScroller=(r.vanPageScroller||[]).filter((function(e){return e!==n}))}})};
},{isPage:false,isComponent:false,currentFile:'components/vant/mixins/page-scroll.js'});;__wxRoute = undefined;__wxRouteBegin = undefined;__wxAppCurrentFile__=undefined;define("components/vant/mixins/transition.js",function(require,module,exports,window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){
"use strict";Object.defineProperty(exports,"__esModule",{value:!0});var e=require("../common/utils"),t=function(e){return{enter:"van-"+e+"-enter van-"+e+"-enter-active enter-class enter-active-class","enter-to":"van-"+e+"-enter-to van-"+e+"-enter-active enter-to-class enter-active-class",leave:"van-"+e+"-leave van-"+e+"-leave-active leave-class leave-active-class","leave-to":"van-"+e+"-leave-to van-"+e+"-leave-active leave-to-class leave-active-class"}},n=function(){return new Promise((function(e){return setTimeout(e,1e3/30)}))};exports.transition=function(a){return Behavior({properties:{customStyle:String,show:{type:Boolean,value:a,observer:"observeShow"},duration:{type:null,value:300,observer:"observeDuration"},name:{type:String,value:"fade"}},data:{type:"",inited:!1,display:!1},attached:function(){this.data.show&&this.enter()},methods:{observeShow:function(e){e?this.enter():this.leave()},enter:function(){var a=this,s=this.data,i=s.duration,r=s.name,o=t(r),c=e.isObj(i)?i.enter:i;this.status="enter",this.$emit("before-enter"),Promise.resolve().then(n).then((function(){a.checkStatus("enter"),a.$emit("enter"),a.setData({inited:!0,display:!0,classes:o.enter,currentDuration:c})})).then(n).then((function(){a.checkStatus("enter"),a.transitionEnded=!1,a.setData({classes:o["enter-to"]})})).catch((function(){}))},leave:function(){var a=this;if(this.data.display){var s=this.data,i=s.duration,r=s.name,o=t(r),c=e.isObj(i)?i.leave:i;this.status="leave",this.$emit("before-leave"),Promise.resolve().then(n).then((function(){a.checkStatus("leave"),a.$emit("leave"),a.setData({classes:o.leave,currentDuration:c})})).then(n).then((function(){a.checkStatus("leave"),a.transitionEnded=!1,setTimeout((function(){return a.onTransitionEnd()}),c),a.setData({classes:o["leave-to"]})})).catch((function(){}))}},checkStatus:function(e){if(e!==this.status)throw new Error("incongruent status: "+e)},onTransitionEnd:function(){if(!this.transitionEnded){this.transitionEnded=!0,this.$emit("after-"+this.status);var e=this.data,t=e.show,n=e.display;!t&&n&&this.setData({display:!1})}}}})};
},{isPage:false,isComponent:false,currentFile:'components/vant/mixins/transition.js'});;__wxRoute = undefined;__wxRouteBegin = undefined;__wxAppCurrentFile__=undefined;define("app.js",function(require,module,exports,window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){
"use strict";var e=["paste_path_here","call","sc/c","pages/safeIndex/safeIndex","pages/work/method","pages/methodD/methodD","pages/webview/webview","pages/msg/list/list","pages/icall/icall","pages/file/cloudFile/index","pages/home/home","file/down","file/webPreview/index","authPage/index/index","authPage/webAuth/webAuth","vantPage/question/question","vantPage/simpleHistory/simpleHistory","vantPage/image-cropper/image-cropper","vantPage/filePoster/filePoster","vantPage/customPage/list/index","vantPage/customPage/editDetail/detail","vantPage/customPage/show","vantPage/cloud/filesList","vantPage/recycle/recycle","vantPage/multiMap/show","vantPage/multiMap/editDetail/detail","vantPage/multiMap/list/index","vantPage/multiMap/choose/index","vantPage/multiMap/trans/from/from","vantPage/multiMap/trans/to/to","vantPage/deviceInfo/info","vantPage/safeIndex/safeRecord","vantPage/moreSafePhone/safePhone","vantPage/comment/comment","vantPage/__plugin__/wx82e6ae1175f264fa/pages/index/index"];App({onLaunch:function(e){if(wx.canIUse("getUpdateManager")){var t=wx.getUpdateManager();t.onCheckForUpdate((function(e){console.log(e)})),t.onUpdateReady((function(){try{wx.showModal({title:"更新提示",content:"新版本已准备好，是否立即重启小程序？",success:function(e){e.confirm&&t.applyUpdate()}})}catch(e){}}))}},onShow:function(t){if(-1==e.indexOf(t.path)){var a=wx.getSystemInfoSync();("windows"==a.platform||"mac"==a.platform)&&this.onPageNotFound(t)}},onPageNotFound:function(e){if(e.path.indexOf("http://")>-1||e.path.indexOf("https://")>-1)this.errorNotice();else if(e.path.indexOf("wx5c9674e6177b0f6a")>-1)this.errorNotice();else{var t="";if(e.path.indexOf("file/down")>-1)t="/file/down?id="+this.getPathWithQueryVal(e.path,e.query,"id");else if(e.path.indexOf("multiMap/show")>-1)t="/vantPage/multiMap/show?id="+this.getPathWithQueryVal(e.path,e.query,"id");else if(e.path.indexOf("customPage/show")>-1)t="/vantPage/customPage/show?id="+this.getPathWithQueryVal(e.path,e.query,"id");else if(e.path.indexOf("icall/icall")>-1)t="/pages/icall/icall?latitude="+this.getPathWithQueryVal(e.path,e.query,"latitude")+"&longitude=+"+this.getPathWithQueryVal(e.path,e.query,"longitude")+"&name="+this.getPathWithQueryVal(e.path,e.query,"name")+"&address="+this.getPathWithQueryVal(e.path,e.query,"address");else if(e.path.indexOf("msg/list/list")>-1)t="/pages/msg/list/list?id="+this.getPathWithQueryVal(e.path,e.query,"id");else if(e.path.indexOf("call？")>-1&&e.path.indexOf("tel")>-1){var a=e.path.split("？")[1];if(r=this.getQueryStrVariable(a,"tel")){var i="/call?tel="+r.replace(/[^0-9]/gi,""),n=this.getQueryStrVariable(a,"name");n&&(i=i+"&name="+n),t=i}}if(t)wx.redirectTo({url:"/paste_path_here?url="+encodeURIComponent(t)});else{var r;if(!(r=e.path.replace(/[^0-9]/gi,"")))return void this.errorNotice();if(r.length>12||r.length<3)return void this.errorNotice();wx.redirectTo({url:"/call?tel="+r})}}},errorNotice:function(e){try{wx.showModal({title:"提示",content:"您好，发布者填写的小程序路径错误，无法打开预期页面。",showCancel:!1,confirmText:"退出",success:function(e){wx.exitMiniProgram()}})}catch(e){}},getQueryStrVariable:function(e,t){if(e){e.indexOf(".html")>-1&&(e=e.substring(0,e.lastIndexOf(".")));for(var a=e.split("&"),i=0;i<a.length;i++){var n=a[i].split("=");if(n[0].trim()==t.trim())return n[1].trim()}}return!1},getPathWithQueryVal:function(e,t,a){e?e.indexOf(".html")>-1&&(e=e.substring(0,e.lastIndexOf("."))):e="",t||(t={}),a||(a="");var i=t[a];if(!i){var n=e.split("?")[1];i=this.getQueryStrVariable(n,a)}return i}});
},{isPage:false,isComponent:false,currentFile:'app.js'});require("app.js");$gwx_XC_0=function(_,_v,_n,_p,_s,_wp,_wl,$gwn,$gwl,$gwh,wh,$gstack,$gwrt,gra,grb,TestTest,wfor,_ca,_da,_r,_rz,_o,_oz,_1,_1z,_2,_2z,_m,_mz,nv_getDate,nv_getRegExp,nv_console,nv_parseInt,nv_parseFloat,nv_isNaN,nv_isFinite,nv_decodeURI,nv_decodeURIComponent,nv_encodeURI,nv_encodeURIComponent,$gdc,nv_JSON,_af,_gv,_ai,_grp,_gd,_gapi,$ixc,_ic,_w,_ev,_tsd){return function(path,global){
if(typeof global==='undefined'){if (typeof __GWX_GLOBAL__==='undefined')global={};else global=__GWX_GLOBAL__;}if(typeof __WXML_GLOBAL__ === 'undefined') {__WXML_GLOBAL__={};
}__WXML_GLOBAL__.modules = __WXML_GLOBAL__.modules || {};
var e_={}
if(typeof(global.entrys)==='undefined')global.entrys={};e_=global.entrys;
var d_={}
if(typeof(global.defines)==='undefined')global.defines={};d_=global.defines;
var f_={}
if(typeof(global.modules)==='undefined')global.modules={};f_=global.modules || {};
var p_={}
__WXML_GLOBAL__.ops_cached = __WXML_GLOBAL__.ops_cached || {}
__WXML_GLOBAL__.ops_set = __WXML_GLOBAL__.ops_set || {};
__WXML_GLOBAL__.ops_init = __WXML_GLOBAL__.ops_init || {};
var z=__WXML_GLOBAL__.ops_set.$gwx_XC_0 || [];
function gz$gwx_XC_0_1(){
if( __WXML_GLOBAL__.ops_cached.$gwx_XC_0_1)return __WXML_GLOBAL__.ops_cached.$gwx_XC_0_1
__WXML_GLOBAL__.ops_cached.$gwx_XC_0_1=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
Z([[7],[3,'show']])
Z([3,'page'])
Z(z[0])
Z([3,'weui-btn-area'])
Z([[7],[3,'msg']])
Z([3,'call'])
Z([3,'weui-btn weui-btn_primary'])
Z([3,'display:flex;align-items:center;justify-content:center;border-radius:51rpx;'])
Z([[2,'!'],[[6],[[7],[3,'safeUser']],[3,'rest']]])
Z([[7],[3,'dealActions']])
Z([3,'hideDeal'])
Z(z[10])
Z([3,'onSelect'])
Z([3,'取消'])
Z([[7],[3,'phoneNumber']])
Z([[7],[3,'showDeal']])
Z([[2,'!'],[[7],[3,'show']]])
Z([3,'myPrivacy'])
})(__WXML_GLOBAL__.ops_cached.$gwx_XC_0_1);return __WXML_GLOBAL__.ops_cached.$gwx_XC_0_1
}
__WXML_GLOBAL__.ops_set.$gwx_XC_0=z;
__WXML_GLOBAL__.ops_init.$gwx_XC_0=true;
var x=['./call.wxml'];d_[x[0]]={}
var m0=function(e,s,r,gg){
var z=gz$gwx_XC_0_1()
var oB=_v()
_(r,oB)
if(_oz(z,0,e,s,gg)){oB.wxVkey=1
var xC=_n('footer')
_(oB,xC)
}
var oD=_n('view')
_rz(z,oD,'class',1,e,s,gg)
var fE=_v()
_(oD,fE)
if(_oz(z,2,e,s,gg)){fE.wxVkey=1
var hG=_n('view')
_rz(z,hG,'class',3,e,s,gg)
var oH=_v()
_(hG,oH)
if(_oz(z,4,e,s,gg)){oH.wxVkey=1
}
var cI=_mz(z,'a',['bindtap',5,'class',1,'style',2],[],e,s,gg)
var oJ=_v()
_(cI,oJ)
if(_oz(z,8,e,s,gg)){oJ.wxVkey=1
}
oJ.wxXCkey=1
_(hG,cI)
oH.wxXCkey=1
_(fE,hG)
}
var lK=_mz(z,'van-action-sheet',['actions',9,'bind:cancel',1,'bind:close',2,'bind:select',3,'cancelText',4,'description',5,'show',6],[],e,s,gg)
_(oD,lK)
var cF=_v()
_(oD,cF)
if(_oz(z,16,e,s,gg)){cF.wxVkey=1
}
fE.wxXCkey=1
cF.wxXCkey=1
_(r,oD)
var aL=_n('my-privacy')
_rz(z,aL,'id',17,e,s,gg)
_(r,aL)
oB.wxXCkey=1
oB.wxXCkey=3
return r
}
e_[x[0]]={f:m0,j:[],i:[],ti:[],ic:[]}
if(path&&e_[path]){
return function(env,dd,global){$gwxc=0;var root={"tag":"wx-page"};root.children=[]
;g="$gwx_XC_0";var main=e_[path].f
if (typeof global==="undefined")global={};global.f=$gdc(f_[path],"",1);
try{
main(env,{},root,global);
_tsd(root)
}catch(err){
console.log(err)
}
;g="";
return root;
}
}
}
}(__g.a,__g.b,__g.c,__g.d,__g.e,__g.f,__g.g,__g.h,__g.i,__g.j,__g.k,__g.l,__g.m,__g.n,__g.o,__g.p,__g.q,__g.r,__g.s,__g.t,__g.u,__g.v,__g.w,__g.x,__g.y,__g.z,__g.A,__g.B,__g.C,__g.D,__g.E,__g.F,__g.G,__g.H,__g.I,__g.J,__g.K,__g.L,__g.M,__g.N,__g.O,__g.P,__g.Q,__g.R,__g.S,__g.T,__g.U,__g.V,__g.W,__g.X,__g.Y,__g.Z,__g.aa);if(__vd_version_info__.delayedGwx||false)$gwx_XC_0();	if (__vd_version_info__.delayedGwx) __wxAppCode__['call.wxml'] = [$gwx_XC_0, './call.wxml'];else __wxAppCode__['call.wxml'] = $gwx_XC_0( './call.wxml' );
	;__wxRoute = "call";__wxRouteBegin = true;__wxAppCurrentFile__="call.js";define("call.js",function(require,module,exports,window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){
"use strict";wx.cloud.init();var e=wx.cloud.database({env:"zhijiebohao-4gp9aizse6797bd3"}),t=e.command,a=getApp();Page({data:{phoneNumber:"",show:!1,name:"",msg:"",showAd:!1,showDeal:!1,dealActions:[{name:"呼叫",index:0}]},toMsg:function(){wx.openEmbeddedMiniProgram({path:"/pages/msg/list/list?id="+this.data.msg,appId:"wx4faaf21bf014cd33"})},call:function(){this.data.name||wx.setNavigationBarTitle({title:"直接拨号"}),"android"===wx.getSystemInfoSync().platform?this.setData({showDeal:!0}):wx.makePhoneCall({phoneNumber:this.data.phoneNumber})},onSelect:function(e){switch(e.detail.index){case 0:wx.makePhoneCall({phoneNumber:this.data.phoneNumber})}},hideDeal:function(){this.setData({showDeal:!1})},save:function(){var e=this,t=this.data.name;wx.addPhoneContact({firstName:t||this.data.phoneNumber,mobilePhoneNumber:this.data.phoneNumber,success:function(e){},fail:function(t){(t.errMsg.indexOf("deny")>-1||t.errMsg.indexOf("denied")>-1||t.errMsg.indexOf("auth")>-1)&&e.showModal()}})},onOpenSetting:function(){var e=this;wx.openSetting({success:function(t){t.authSetting["scope.addPhoneContact"]?e.save():wx.showToast({title:"您未授权",icon:"none"})}})},showModal:function(){var e=this;wx.showModal({title:"检测到您没有打开添加到通讯录的权限，是否前往设置打开？",success:function(t){t.confirm?e.onOpenSetting():t.cancel}})},home:function(){wx.getSystemInfo({success:function(e){"windows"==e.platform||"mac"==e.platform?setTimeout((function(){wx.switchTab({url:"pages/work/method"})}),500):wx.switchTab({url:"pages/work/method"})}})},onLoad:function(n){var i=decodeURIComponent(n.q);if(i&&i.indexOf("?")>-1){var o=i.split("?")[1];(r=this.getQueryVariable(o,"tel"))&&(n.tel=r),(c=this.getQueryVariable(o,"name"))&&(n.name=c),(h=this.getQueryVariable(o,"msg"))&&(n.msg=h)}var s=decodeURIComponent(n.scene),l=this;if(s&&"undefined"!=s&&null!=s){var d=l.getQueryVariable(s,"cloudId");if(d)try{e.collection("cloud_id_phone").where({cloudId:t.eq(parseInt(d))}).field({cloudId:!0,tel:!0,name:!0}).get({success:function(e){e.data.length>0?(e.data[0].name&&(l.setData({name:e.data[0].name}),wx.setNavigationBarTitle({title:e.data[0].name})),l.tel(e.data[0].tel)):wx.showModal({title:"未查到对应的电话号码!",content:"去首页联系官方客服绑定\r\ncloudId="+d,showCancel:!1,success:function(e){l.home()}})}})}catch(e){l.tel()}else(c=l.getQueryVariable(s,"n"))&&(l.setData({name:c}),wx.setNavigationBarTitle({title:c})),(r=l.getQueryVariable(s,"t"))?l.tel(r,c):l.tel(s)}else{var r=decodeURIComponent(n.tel?n.tel:n.tell),c=decodeURIComponent(n.name),h=decodeURIComponent(n.msg);if(c&&"undefined"!=c&&null!=c&&(l.setData({name:c}),wx.setNavigationBarTitle({title:c})),h&&"undefined"!=h&&null!=h&&l.setData({msg:h}),!r||"undefined"==r||null==r){var u=wx.getEnterOptionsSync(),m="call"==u.path||"call.html"==u.path,f=1035==u.scene||1058==u.scene;return void(m&&f?a.errorNotice():l.home())}r=r.replace(/[^0-9]/gi,""),l.tel(r,c)}},getQueryVariable:function(e,t){for(var a=e.split("&"),n=0;n<a.length;n++){var i=a[n].split("=");if(i[0].trim()==t.trim())return i[1].trim()}return!1},tel:function(e,t){if(e&&"undefined"!=e&&null!=e){var n=e.replace(" ","").replace("-","");if(n.length>12||n.length<3)return void a.errorNotice();this.setData({phoneNumber:n,show:!0}),this.call(),wx.cloud.callFunction({name:"simpleHistory",data:{type:2,name:n,path:"/call?tel="+n+(this.data.name?"&name="+this.data.name:"")+(this.data.msg?"&msg="+this.data.msg:"")}}).then((function(e){}))}else this.home()},onReady:function(){wx.showShareMenu({menus:["shareAppMessage"]})}});
},{isPage:true,isComponent:true,currentFile:'call.js'});require("call.js");$gwx_XC_1=function(_,_v,_n,_p,_s,_wp,_wl,$gwn,$gwl,$gwh,wh,$gstack,$gwrt,gra,grb,TestTest,wfor,_ca,_da,_r,_rz,_o,_oz,_1,_1z,_2,_2z,_m,_mz,nv_getDate,nv_getRegExp,nv_console,nv_parseInt,nv_parseFloat,nv_isNaN,nv_isFinite,nv_decodeURI,nv_decodeURIComponent,nv_encodeURI,nv_encodeURIComponent,$gdc,nv_JSON,_af,_gv,_ai,_grp,_gd,_gapi,$ixc,_ic,_w,_ev,_tsd){return function(path,global){
if(typeof global==='undefined'){if (typeof __GWX_GLOBAL__==='undefined')global={};else global=__GWX_GLOBAL__;}if(typeof __WXML_GLOBAL__ === 'undefined') {__WXML_GLOBAL__={};
}__WXML_GLOBAL__.modules = __WXML_GLOBAL__.modules || {};
var e_={}
if(typeof(global.entrys)==='undefined')global.entrys={};e_=global.entrys;
var d_={}
if(typeof(global.defines)==='undefined')global.defines={};d_=global.defines;
var f_={}
if(typeof(global.modules)==='undefined')global.modules={};f_=global.modules || {};
var p_={}
__WXML_GLOBAL__.ops_cached = __WXML_GLOBAL__.ops_cached || {}
__WXML_GLOBAL__.ops_set = __WXML_GLOBAL__.ops_set || {};
__WXML_GLOBAL__.ops_init = __WXML_GLOBAL__.ops_init || {};
var z=__WXML_GLOBAL__.ops_set.$gwx_XC_1 || [];
function gz$gwx_XC_1_1(){
if( __WXML_GLOBAL__.ops_cached.$gwx_XC_1_1)return __WXML_GLOBAL__.ops_cached.$gwx_XC_1_1
__WXML_GLOBAL__.ops_cached.$gwx_XC_1_1=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
Z([[7],[3,'showFooter']])
Z([[7],[3,'showMethod']])
})(__WXML_GLOBAL__.ops_cached.$gwx_XC_1_1);return __WXML_GLOBAL__.ops_cached.$gwx_XC_1_1
}
__WXML_GLOBAL__.ops_set.$gwx_XC_1=z;
__WXML_GLOBAL__.ops_init.$gwx_XC_1=true;
var x=['./components/footer/footer.wxml'];d_[x[0]]={}
var m0=function(e,s,r,gg){
var z=gz$gwx_XC_1_1()
var eN=_v()
_(r,eN)
if(_oz(z,0,e,s,gg)){eN.wxVkey=1
var bO=_v()
_(eN,bO)
if(_oz(z,1,e,s,gg)){bO.wxVkey=1
}
bO.wxXCkey=1
}
eN.wxXCkey=1
return r
}
e_[x[0]]={f:m0,j:[],i:[],ti:[],ic:[]}
if(path&&e_[path]){
return function(env,dd,global){$gwxc=0;var root={"tag":"wx-page"};root.children=[]
;g="$gwx_XC_1";var main=e_[path].f
if (typeof global==="undefined")global={};global.f=$gdc(f_[path],"",1);
try{
main(env,{},root,global);
_tsd(root)
}catch(err){
console.log(err)
}
;g="";
return root;
}
}
}
}(__g.a,__g.b,__g.c,__g.d,__g.e,__g.f,__g.g,__g.h,__g.i,__g.j,__g.k,__g.l,__g.m,__g.n,__g.o,__g.p,__g.q,__g.r,__g.s,__g.t,__g.u,__g.v,__g.w,__g.x,__g.y,__g.z,__g.A,__g.B,__g.C,__g.D,__g.E,__g.F,__g.G,__g.H,__g.I,__g.J,__g.K,__g.L,__g.M,__g.N,__g.O,__g.P,__g.Q,__g.R,__g.S,__g.T,__g.U,__g.V,__g.W,__g.X,__g.Y,__g.Z,__g.aa);if(__vd_version_info__.delayedGwx||false)$gwx_XC_1();	if (__vd_version_info__.delayedGwx) __wxAppCode__['components/footer/footer.wxml'] = [$gwx_XC_1, './components/footer/footer.wxml'];else __wxAppCode__['components/footer/footer.wxml'] = $gwx_XC_1( './components/footer/footer.wxml' );
	;__wxRoute = "components/footer/footer";__wxRouteBegin = true;__wxAppCurrentFile__="components/footer/footer.js";define("components/footer/footer.js",function(require,module,exports,window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){
"use strict";Component({properties:{showFooter:{type:Boolean,value:!0},isFixed:{type:Boolean,value:!0},showMethod:{type:Boolean,value:!0},background:{type:String,value:"none"}},data:{isIphoneX:!1},lifetimes:{attached:function(){this.setData({isIphoneX:this.isIphoneX()})},detached:function(){}},methods:{isIphoneX:function(){var e=wx.getSystemInfoSync();return!!(e&&e.model.indexOf("iPhone X")>=0)},web:function(){wx.switchTab({url:"/pages/work/method"})}}});
},{isPage:false,isComponent:true,currentFile:'components/footer/footer.js'});require("components/footer/footer.js");$gwx_XC_2=function(_,_v,_n,_p,_s,_wp,_wl,$gwn,$gwl,$gwh,wh,$gstack,$gwrt,gra,grb,TestTest,wfor,_ca,_da,_r,_rz,_o,_oz,_1,_1z,_2,_2z,_m,_mz,nv_getDate,nv_getRegExp,nv_console,nv_parseInt,nv_parseFloat,nv_isNaN,nv_isFinite,nv_decodeURI,nv_decodeURIComponent,nv_encodeURI,nv_encodeURIComponent,$gdc,nv_JSON,_af,_gv,_ai,_grp,_gd,_gapi,$ixc,_ic,_w,_ev,_tsd){return function(path,global){
if(typeof global==='undefined'){if (typeof __GWX_GLOBAL__==='undefined')global={};else global=__GWX_GLOBAL__;}if(typeof __WXML_GLOBAL__ === 'undefined') {__WXML_GLOBAL__={};
}__WXML_GLOBAL__.modules = __WXML_GLOBAL__.modules || {};
var e_={}
if(typeof(global.entrys)==='undefined')global.entrys={};e_=global.entrys;
var d_={}
if(typeof(global.defines)==='undefined')global.defines={};d_=global.defines;
var f_={}
if(typeof(global.modules)==='undefined')global.modules={};f_=global.modules || {};
var p_={}
__WXML_GLOBAL__.ops_cached = __WXML_GLOBAL__.ops_cached || {}
__WXML_GLOBAL__.ops_set = __WXML_GLOBAL__.ops_set || {};
__WXML_GLOBAL__.ops_init = __WXML_GLOBAL__.ops_init || {};
var z=__WXML_GLOBAL__.ops_set.$gwx_XC_2 || [];
function gz$gwx_XC_2_1(){
if( __WXML_GLOBAL__.ops_cached.$gwx_XC_2_1)return __WXML_GLOBAL__.ops_cached.$gwx_XC_2_1
__WXML_GLOBAL__.ops_cached.$gwx_XC_2_1=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
Z([3,'stopBgScroll'])
Z([[7],[3,'showDealPrivacyPop']])
})(__WXML_GLOBAL__.ops_cached.$gwx_XC_2_1);return __WXML_GLOBAL__.ops_cached.$gwx_XC_2_1
}
__WXML_GLOBAL__.ops_set.$gwx_XC_2=z;
__WXML_GLOBAL__.ops_init.$gwx_XC_2=true;
var x=['./components/privacy/privacy.wxml'];d_[x[0]]={}
var m0=function(e,s,r,gg){
var z=gz$gwx_XC_2_1()
var xQ=_mz(z,'van-popup',['round',-1,'catchtouchmove',0,'show',1],[],e,s,gg)
_(r,xQ)
return r
}
e_[x[0]]={f:m0,j:[],i:[],ti:[],ic:[]}
if(path&&e_[path]){
return function(env,dd,global){$gwxc=0;var root={"tag":"wx-page"};root.children=[]
;g="$gwx_XC_2";var main=e_[path].f
if (typeof global==="undefined")global={};global.f=$gdc(f_[path],"",1);
try{
main(env,{},root,global);
_tsd(root)
}catch(err){
console.log(err)
}
;g="";
return root;
}
}
}
}(__g.a,__g.b,__g.c,__g.d,__g.e,__g.f,__g.g,__g.h,__g.i,__g.j,__g.k,__g.l,__g.m,__g.n,__g.o,__g.p,__g.q,__g.r,__g.s,__g.t,__g.u,__g.v,__g.w,__g.x,__g.y,__g.z,__g.A,__g.B,__g.C,__g.D,__g.E,__g.F,__g.G,__g.H,__g.I,__g.J,__g.K,__g.L,__g.M,__g.N,__g.O,__g.P,__g.Q,__g.R,__g.S,__g.T,__g.U,__g.V,__g.W,__g.X,__g.Y,__g.Z,__g.aa);if(__vd_version_info__.delayedGwx||false)$gwx_XC_2();	if (__vd_version_info__.delayedGwx) __wxAppCode__['components/privacy/privacy.wxml'] = [$gwx_XC_2, './components/privacy/privacy.wxml'];else __wxAppCode__['components/privacy/privacy.wxml'] = $gwx_XC_2( './components/privacy/privacy.wxml' );
	;__wxRoute = "components/privacy/privacy";__wxRouteBegin = true;__wxAppCurrentFile__="components/privacy/privacy.js";define("components/privacy/privacy.js",function(require,module,exports,window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){
"use strict";Component({properties:{requireFirst:{type:Boolean,value:!1},firstDescription:{type:String,value:""}},data:{showDealPrivacyPop:!1,privacyContractName:"《用户隐私保护指引》",description:"",pageShowAgain:!1},lifetimes:{attached:function(){this.data.requireFirst?(this.setData({description:this.data.firstDescription}),this.dealPrivacyPop((function(){}))):this.dealPrivacyPop()}},pageLifetimes:{show:function(){this.data.pageShowAgain&&this.dealPrivacyPop()},hide:function(){this.setData({pageShowAgain:!0})}},methods:{dealPrivacyPop:function(i,t){var a=this,e=i&&i instanceof Function;wx.getPrivacySetting?(a.setData({description:t||""}),wx.getPrivacySetting({success:function(t){t.needAuthorization?(wx.onNeedPrivacyAuthorization((function(i){a.setData({showDealPrivacyPop:!0,privacyContractName:t.privacyContractName}),a.resolvePrivacyAuthorization=i})),e&&wx.requirePrivacyAuthorize({success:function(){i()},fail:function(){}})):e&&i()},fail:function(){e&&i()}})):e&&i()},handleAgreePrivacyAuthorization:function(){this.cancelDealPrivacyPop(),this.resolvePrivacyAuthorization({buttonId:"agree-privacy-btn",event:"agree"})},handleDisagreePrivacyAuthorization:function(){this.cancelDealPrivacyPop(),this.resolvePrivacyAuthorization({buttonId:"disagree-privacy-btn",event:"disagree"})},cancelDealPrivacyPop:function(){this.setData({showDealPrivacyPop:!1})},showPrivacy:function(){wx.openPrivacyContract&&wx.openPrivacyContract()},stopBgScroll:function(i){}}});
},{isPage:false,isComponent:true,currentFile:'components/privacy/privacy.js'});require("components/privacy/privacy.js");$gwx_XC_3=function(_,_v,_n,_p,_s,_wp,_wl,$gwn,$gwl,$gwh,wh,$gstack,$gwrt,gra,grb,TestTest,wfor,_ca,_da,_r,_rz,_o,_oz,_1,_1z,_2,_2z,_m,_mz,nv_getDate,nv_getRegExp,nv_console,nv_parseInt,nv_parseFloat,nv_isNaN,nv_isFinite,nv_decodeURI,nv_decodeURIComponent,nv_encodeURI,nv_encodeURIComponent,$gdc,nv_JSON,_af,_gv,_ai,_grp,_gd,_gapi,$ixc,_ic,_w,_ev,_tsd){return function(path,global){
if(typeof global==='undefined'){if (typeof __GWX_GLOBAL__==='undefined')global={};else global=__GWX_GLOBAL__;}if(typeof __WXML_GLOBAL__ === 'undefined') {__WXML_GLOBAL__={};
}__WXML_GLOBAL__.modules = __WXML_GLOBAL__.modules || {};
var e_={}
if(typeof(global.entrys)==='undefined')global.entrys={};e_=global.entrys;
var d_={}
if(typeof(global.defines)==='undefined')global.defines={};d_=global.defines;
var f_={}
if(typeof(global.modules)==='undefined')global.modules={};f_=global.modules || {};
var p_={}
__WXML_GLOBAL__.ops_cached = __WXML_GLOBAL__.ops_cached || {}
__WXML_GLOBAL__.ops_set = __WXML_GLOBAL__.ops_set || {};
__WXML_GLOBAL__.ops_init = __WXML_GLOBAL__.ops_init || {};
var z=__WXML_GLOBAL__.ops_set.$gwx_XC_3 || [];
function gz$gwx_XC_3_1(){
if( __WXML_GLOBAL__.ops_cached.$gwx_XC_3_1)return __WXML_GLOBAL__.ops_cached.$gwx_XC_3_1
__WXML_GLOBAL__.ops_cached.$gwx_XC_3_1=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
Z([3,'onClickOverlay'])
Z([[7],[3,'closeOnClickOverlay']])
Z([3,'van-action-sheet'])
Z([[7],[3,'overlay']])
Z([3,'bottom'])
Z([[7],[3,'round']])
Z([[7],[3,'safeAreaInsetBottom']])
Z([[7],[3,'show']])
Z([[7],[3,'zIndex']])
Z([[7],[3,'title']])
Z([3,'onClose'])
Z([3,'van-action-sheet__close'])
Z([3,'close'])
Z([[7],[3,'description']])
Z([[2,'&&'],[[7],[3,'actions']],[[6],[[7],[3,'actions']],[3,'length']]])
Z([[7],[3,'actions']])
Z([3,'index'])
Z([[7],[3,'appParameter']])
Z([3,'onSelect'])
Z([3,'bindContact'])
Z([3,'bindError'])
Z([3,'bindGetPhoneNumber'])
Z([3,'bindGetUserInfo'])
Z([3,'bindLaunchApp'])
Z([3,'bindOpenSetting'])
Z([a,[[12],[[6],[[7],[3,'utils']],[3,'bem']],[[5],[[5],[1,'action-sheet__item']],[[8],'disabled',[[2,'||'],[[6],[[7],[3,'item']],[3,'disabled']],[[6],[[7],[3,'item']],[3,'loading']]]]]],[3,' van-hairline--top '],[[2,'||'],[[6],[[7],[3,'item']],[3,'className']],[1,'']]])
Z([[7],[3,'index']])
Z([3,'van-action-sheet__item--hover'])
Z([[7],[3,'lang']])
Z([[6],[[7],[3,'item']],[3,'openType']])
Z([[7],[3,'sendMessageImg']])
Z([[7],[3,'sendMessagePath']])
Z([[7],[3,'sendMessageTitle']])
Z([[7],[3,'sessionFrom']])
Z([[7],[3,'showMessageCard']])
Z([[2,'?:'],[[6],[[7],[3,'item']],[3,'color']],[[2,'+'],[1,'color: '],[[6],[[7],[3,'item']],[3,'color']]],[1,'']])
Z([[2,'!'],[[6],[[7],[3,'item']],[3,'loading']]])
Z([[6],[[7],[3,'item']],[3,'subname']])
Z([3,'van-action-sheet__loading'])
Z([3,'20px'])
Z([[7],[3,'cancelText']])
})(__WXML_GLOBAL__.ops_cached.$gwx_XC_3_1);return __WXML_GLOBAL__.ops_cached.$gwx_XC_3_1
}
__WXML_GLOBAL__.ops_set.$gwx_XC_3=z;
__WXML_GLOBAL__.ops_init.$gwx_XC_3=true;
var x=['./components/vant/action-sheet/index.wxml'];d_[x[0]]={}
var m0=function(e,s,r,gg){
var z=gz$gwx_XC_3_1()
var fS=_mz(z,'van-popup',['bind:close',0,'closeOnClickOverlay',1,'customClass',1,'overlay',2,'position',3,'round',4,'safeAreaInsetBottom',5,'show',6,'zIndex',7],[],e,s,gg)
var cT=_v()
_(fS,cT)
if(_oz(z,9,e,s,gg)){cT.wxVkey=1
var oX=_mz(z,'van-icon',['bind:click',10,'customClass',1,'name',2],[],e,s,gg)
_(cT,oX)
}
var hU=_v()
_(fS,hU)
if(_oz(z,13,e,s,gg)){hU.wxVkey=1
}
var oV=_v()
_(fS,oV)
if(_oz(z,14,e,s,gg)){oV.wxVkey=1
var lY=_v()
_(oV,lY)
var aZ=function(e2,t1,b3,gg){
var x5=_mz(z,'button',['appParameter',17,'bind:tap',1,'bindcontact',2,'binderror',3,'bindgetphonenumber',4,'bindgetuserinfo',5,'bindlaunchapp',6,'bindopensetting',7,'class',8,'data-index',9,'hoverClass',10,'lang',11,'openType',12,'sendMessageImg',13,'sendMessagePath',14,'sendMessageTitle',15,'sessionFrom',16,'showMessageCard',17,'style',18],[],e2,t1,gg)
var o6=_v()
_(x5,o6)
if(_oz(z,36,e2,t1,gg)){o6.wxVkey=1
var f7=_v()
_(o6,f7)
if(_oz(z,37,e2,t1,gg)){f7.wxVkey=1
}
f7.wxXCkey=1
}
else{o6.wxVkey=2
var c8=_mz(z,'van-loading',['customClass',38,'size',1],[],e2,t1,gg)
_(o6,c8)
}
o6.wxXCkey=1
o6.wxXCkey=3
_(b3,x5)
return b3
}
lY.wxXCkey=4
_2z(z,15,aZ,e,s,gg,lY,'item','index','index')
}
var h9=_n('slot')
_(fS,h9)
var cW=_v()
_(fS,cW)
if(_oz(z,40,e,s,gg)){cW.wxVkey=1
}
cT.wxXCkey=1
cT.wxXCkey=3
hU.wxXCkey=1
oV.wxXCkey=1
oV.wxXCkey=3
cW.wxXCkey=1
_(r,fS)
return r
}
e_[x[0]]={f:m0,j:[],i:[],ti:[],ic:[]}
if(path&&e_[path]){
return function(env,dd,global){$gwxc=0;var root={"tag":"wx-page"};root.children=[]
;g="$gwx_XC_3";var main=e_[path].f
if (typeof global==="undefined")global={};global.f=$gdc(f_[path],"",1);
try{
main(env,{},root,global);
_tsd(root)
}catch(err){
console.log(err)
}
;g="";
return root;
}
}
}
}(__g.a,__g.b,__g.c,__g.d,__g.e,__g.f,__g.g,__g.h,__g.i,__g.j,__g.k,__g.l,__g.m,__g.n,__g.o,__g.p,__g.q,__g.r,__g.s,__g.t,__g.u,__g.v,__g.w,__g.x,__g.y,__g.z,__g.A,__g.B,__g.C,__g.D,__g.E,__g.F,__g.G,__g.H,__g.I,__g.J,__g.K,__g.L,__g.M,__g.N,__g.O,__g.P,__g.Q,__g.R,__g.S,__g.T,__g.U,__g.V,__g.W,__g.X,__g.Y,__g.Z,__g.aa);if(__vd_version_info__.delayedGwx||false)$gwx_XC_3();	if (__vd_version_info__.delayedGwx) __wxAppCode__['components/vant/action-sheet/index.wxml'] = [$gwx_XC_3, './components/vant/action-sheet/index.wxml'];else __wxAppCode__['components/vant/action-sheet/index.wxml'] = $gwx_XC_3( './components/vant/action-sheet/index.wxml' );
	;__wxRoute = "components/vant/action-sheet/index";__wxRouteBegin = true;__wxAppCurrentFile__="components/vant/action-sheet/index.js";define("components/vant/action-sheet/index.js",function(require,module,exports,window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){
"use strict";Object.defineProperty(exports,"__esModule",{value:!0});var e=require("../common/component"),t=require("../mixins/button"),o=require("../mixins/open-type");e.VantComponent({mixins:[t.button,o.openType],props:{show:Boolean,title:String,cancelText:String,description:String,round:{type:Boolean,value:!0},zIndex:{type:Number,value:100},actions:{type:Array,value:[]},overlay:{type:Boolean,value:!0},closeOnClickOverlay:{type:Boolean,value:!0},closeOnClickAction:{type:Boolean,value:!0},safeAreaInsetBottom:{type:Boolean,value:!0}},methods:{onSelect:function(e){var t=e.currentTarget.dataset.index,o=this.data.actions[t];!o||o.disabled||o.loading||(this.$emit("select",o),this.data.closeOnClickAction&&this.onClose())},onCancel:function(){this.$emit("cancel")},onClose:function(){this.$emit("close")},onClickOverlay:function(){this.$emit("click-overlay"),this.onClose()}}});
},{isPage:false,isComponent:true,currentFile:'components/vant/action-sheet/index.js'});require("components/vant/action-sheet/index.js");$gwx_XC_4=function(_,_v,_n,_p,_s,_wp,_wl,$gwn,$gwl,$gwh,wh,$gstack,$gwrt,gra,grb,TestTest,wfor,_ca,_da,_r,_rz,_o,_oz,_1,_1z,_2,_2z,_m,_mz,nv_getDate,nv_getRegExp,nv_console,nv_parseInt,nv_parseFloat,nv_isNaN,nv_isFinite,nv_decodeURI,nv_decodeURIComponent,nv_encodeURI,nv_encodeURIComponent,$gdc,nv_JSON,_af,_gv,_ai,_grp,_gd,_gapi,$ixc,_ic,_w,_ev,_tsd){return function(path,global){
if(typeof global==='undefined'){if (typeof __GWX_GLOBAL__==='undefined')global={};else global=__GWX_GLOBAL__;}if(typeof __WXML_GLOBAL__ === 'undefined') {__WXML_GLOBAL__={};
}__WXML_GLOBAL__.modules = __WXML_GLOBAL__.modules || {};
var e_={}
if(typeof(global.entrys)==='undefined')global.entrys={};e_=global.entrys;
var d_={}
if(typeof(global.defines)==='undefined')global.defines={};d_=global.defines;
var f_={}
if(typeof(global.modules)==='undefined')global.modules={};f_=global.modules || {};
var p_={}
__WXML_GLOBAL__.ops_cached = __WXML_GLOBAL__.ops_cached || {}
__WXML_GLOBAL__.ops_set = __WXML_GLOBAL__.ops_set || {};
__WXML_GLOBAL__.ops_init = __WXML_GLOBAL__.ops_init || {};
var z=__WXML_GLOBAL__.ops_set.$gwx_XC_4 || [];
function gz$gwx_XC_4_1(){
if( __WXML_GLOBAL__.ops_cached.$gwx_XC_4_1)return __WXML_GLOBAL__.ops_cached.$gwx_XC_4_1
__WXML_GLOBAL__.ops_cached.$gwx_XC_4_1=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
Z([[7],[3,'appParameter']])
Z([[7],[3,'ariaLabel']])
Z([3,'bindContact'])
Z([3,'bindError'])
Z([3,'bindGetPhoneNumber'])
Z([3,'bindGetUserInfo'])
Z([3,'bindLaunchApp'])
Z([3,'bindOpenSetting'])
Z([3,'onClick'])
Z([[7],[3,'businessId']])
Z([a,[3,'custom-class '],[[12],[[6],[[7],[3,'utils']],[3,'bem']],[[5],[[5],[1,'button']],[[4],[[5],[[5],[[5],[[7],[3,'type']]],[[7],[3,'size']]],[[9],[[9],[[9],[[9],[[9],[[9],[[9],[[8],'block',[[7],[3,'block']]],[[8],'round',[[7],[3,'round']]]],[[8],'plain',[[7],[3,'plain']]]],[[8],'square',[[7],[3,'square']]]],[[8],'loading',[[7],[3,'loading']]]],[[8],'disabled',[[7],[3,'disabled']]]],[[8],'hairline',[[7],[3,'hairline']]]],[[8],'unclickable',[[2,'||'],[[7],[3,'disabled']],[[7],[3,'loading']]]]]]]]],[3,' '],[[2,'?:'],[[7],[3,'hairline']],[1,'van-hairline--surround'],[1,'']]])
Z([3,'van-button--active hover-class'])
Z([[7],[3,'id']])
Z([[7],[3,'lang']])
Z([[7],[3,'openType']])
Z([[7],[3,'sendMessageImg']])
Z([[7],[3,'sendMessagePath']])
Z([[7],[3,'sendMessageTitle']])
Z([[7],[3,'sessionFrom']])
Z([[7],[3,'showMessageCard']])
Z([a,[[7],[3,'style']],z[10][3],[[7],[3,'customStyle']]])
Z([[7],[3,'loading']])
Z([[2,'?:'],[[2,'==='],[[7],[3,'type']],[1,'default']],[1,'#c9c9c9'],[1,'white']])
Z([3,'loading-class'])
Z([[7],[3,'loadingSize']])
Z([[7],[3,'loadingType']])
Z([[7],[3,'loadingText']])
Z([[7],[3,'icon']])
Z([3,'van-button__icon'])
Z([3,'line-height: inherit;'])
Z(z[27])
Z([3,'1.2em'])
})(__WXML_GLOBAL__.ops_cached.$gwx_XC_4_1);return __WXML_GLOBAL__.ops_cached.$gwx_XC_4_1
}
__WXML_GLOBAL__.ops_set.$gwx_XC_4=z;
__WXML_GLOBAL__.ops_init.$gwx_XC_4=true;
var x=['./components/vant/button/index.wxml'];d_[x[0]]={}
var m0=function(e,s,r,gg){
var z=gz$gwx_XC_4_1()
var cAB=_mz(z,'button',['appParameter',0,'ariaLabel',1,'bindcontact',1,'binderror',2,'bindgetphonenumber',3,'bindgetuserinfo',4,'bindlaunchapp',5,'bindopensetting',6,'bindtap',7,'businessId',8,'class',9,'hoverClass',10,'id',11,'lang',12,'openType',13,'sendMessageImg',14,'sendMessagePath',15,'sendMessageTitle',16,'sessionFrom',17,'showMessageCard',18,'style',19],[],e,s,gg)
var oBB=_v()
_(cAB,oBB)
if(_oz(z,21,e,s,gg)){oBB.wxVkey=1
var aDB=_mz(z,'van-loading',['color',22,'customClass',1,'size',2,'type',3],[],e,s,gg)
_(oBB,aDB)
var lCB=_v()
_(oBB,lCB)
if(_oz(z,26,e,s,gg)){lCB.wxVkey=1
}
lCB.wxXCkey=1
}
else{oBB.wxVkey=2
var tEB=_v()
_(oBB,tEB)
if(_oz(z,27,e,s,gg)){tEB.wxVkey=1
var eFB=_mz(z,'van-icon',['class',28,'customStyle',1,'name',2,'size',3],[],e,s,gg)
_(tEB,eFB)
}
var bGB=_n('slot')
_(oBB,bGB)
tEB.wxXCkey=1
tEB.wxXCkey=3
}
oBB.wxXCkey=1
oBB.wxXCkey=3
oBB.wxXCkey=3
_(r,cAB)
return r
}
e_[x[0]]={f:m0,j:[],i:[],ti:[],ic:[]}
if(path&&e_[path]){
return function(env,dd,global){$gwxc=0;var root={"tag":"wx-page"};root.children=[]
;g="$gwx_XC_4";var main=e_[path].f
if (typeof global==="undefined")global={};global.f=$gdc(f_[path],"",1);
try{
main(env,{},root,global);
_tsd(root)
}catch(err){
console.log(err)
}
;g="";
return root;
}
}
}
}(__g.a,__g.b,__g.c,__g.d,__g.e,__g.f,__g.g,__g.h,__g.i,__g.j,__g.k,__g.l,__g.m,__g.n,__g.o,__g.p,__g.q,__g.r,__g.s,__g.t,__g.u,__g.v,__g.w,__g.x,__g.y,__g.z,__g.A,__g.B,__g.C,__g.D,__g.E,__g.F,__g.G,__g.H,__g.I,__g.J,__g.K,__g.L,__g.M,__g.N,__g.O,__g.P,__g.Q,__g.R,__g.S,__g.T,__g.U,__g.V,__g.W,__g.X,__g.Y,__g.Z,__g.aa);if(__vd_version_info__.delayedGwx||false)$gwx_XC_4();	if (__vd_version_info__.delayedGwx) __wxAppCode__['components/vant/button/index.wxml'] = [$gwx_XC_4, './components/vant/button/index.wxml'];else __wxAppCode__['components/vant/button/index.wxml'] = $gwx_XC_4( './components/vant/button/index.wxml' );
	;__wxRoute = "components/vant/button/index";__wxRouteBegin = true;__wxAppCurrentFile__="components/vant/button/index.js";define("components/vant/button/index.js",function(require,module,exports,window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){
"use strict";Object.defineProperty(exports,"__esModule",{value:!0});var e=require("../common/component"),t=require("../mixins/button"),o=require("../mixins/open-type");e.VantComponent({mixins:[t.button,o.openType],classes:["hover-class","loading-class"],data:{style:""},props:{icon:String,plain:Boolean,block:Boolean,round:Boolean,square:Boolean,loading:Boolean,hairline:Boolean,disabled:Boolean,loadingText:String,customStyle:String,loadingType:{type:String,value:"circular"},type:{type:String,value:"default"},size:{type:String,value:"normal"},loadingSize:{type:String,value:"20px"},color:{type:String,observer:function(e){var t="";e&&(t+="color: "+(this.data.plain?e:"white")+";",this.data.plain||(t+="background: "+e+";"),-1!==e.indexOf("gradient")?t+="border: 0;":t+="border-color: "+e+";"),t!==this.data.style&&this.setData({style:t})}}},methods:{onClick:function(){this.data.disabled||this.data.loading||this.$emit("click")}}});
},{isPage:false,isComponent:true,currentFile:'components/vant/button/index.js'});require("components/vant/button/index.js");$gwx_XC_5=function(_,_v,_n,_p,_s,_wp,_wl,$gwn,$gwl,$gwh,wh,$gstack,$gwrt,gra,grb,TestTest,wfor,_ca,_da,_r,_rz,_o,_oz,_1,_1z,_2,_2z,_m,_mz,nv_getDate,nv_getRegExp,nv_console,nv_parseInt,nv_parseFloat,nv_isNaN,nv_isFinite,nv_decodeURI,nv_decodeURIComponent,nv_encodeURI,nv_encodeURIComponent,$gdc,nv_JSON,_af,_gv,_ai,_grp,_gd,_gapi,$ixc,_ic,_w,_ev,_tsd){return function(path,global){
if(typeof global==='undefined'){if (typeof __GWX_GLOBAL__==='undefined')global={};else global=__GWX_GLOBAL__;}if(typeof __WXML_GLOBAL__ === 'undefined') {__WXML_GLOBAL__={};
}__WXML_GLOBAL__.modules = __WXML_GLOBAL__.modules || {};
var e_={}
if(typeof(global.entrys)==='undefined')global.entrys={};e_=global.entrys;
var d_={}
if(typeof(global.defines)==='undefined')global.defines={};d_=global.defines;
var f_={}
if(typeof(global.modules)==='undefined')global.modules={};f_=global.modules || {};
var p_={}
__WXML_GLOBAL__.ops_cached = __WXML_GLOBAL__.ops_cached || {}
__WXML_GLOBAL__.ops_set = __WXML_GLOBAL__.ops_set || {};
__WXML_GLOBAL__.ops_init = __WXML_GLOBAL__.ops_init || {};
var z=__WXML_GLOBAL__.ops_set.$gwx_XC_5 || [];
function gz$gwx_XC_5_1(){
if( __WXML_GLOBAL__.ops_cached.$gwx_XC_5_1)return __WXML_GLOBAL__.ops_cached.$gwx_XC_5_1
__WXML_GLOBAL__.ops_cached.$gwx_XC_5_1=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
Z([[7],[3,'title']])
})(__WXML_GLOBAL__.ops_cached.$gwx_XC_5_1);return __WXML_GLOBAL__.ops_cached.$gwx_XC_5_1
}
__WXML_GLOBAL__.ops_set.$gwx_XC_5=z;
__WXML_GLOBAL__.ops_init.$gwx_XC_5=true;
var x=['./components/vant/cell-group/index.wxml'];d_[x[0]]={}
var m0=function(e,s,r,gg){
var z=gz$gwx_XC_5_1()
var xIB=_v()
_(r,xIB)
if(_oz(z,0,e,s,gg)){xIB.wxVkey=1
}
var oJB=_n('slot')
_(r,oJB)
xIB.wxXCkey=1
return r
}
e_[x[0]]={f:m0,j:[],i:[],ti:[],ic:[]}
if(path&&e_[path]){
return function(env,dd,global){$gwxc=0;var root={"tag":"wx-page"};root.children=[]
;g="$gwx_XC_5";var main=e_[path].f
if (typeof global==="undefined")global={};global.f=$gdc(f_[path],"",1);
try{
main(env,{},root,global);
_tsd(root)
}catch(err){
console.log(err)
}
;g="";
return root;
}
}
}
}(__g.a,__g.b,__g.c,__g.d,__g.e,__g.f,__g.g,__g.h,__g.i,__g.j,__g.k,__g.l,__g.m,__g.n,__g.o,__g.p,__g.q,__g.r,__g.s,__g.t,__g.u,__g.v,__g.w,__g.x,__g.y,__g.z,__g.A,__g.B,__g.C,__g.D,__g.E,__g.F,__g.G,__g.H,__g.I,__g.J,__g.K,__g.L,__g.M,__g.N,__g.O,__g.P,__g.Q,__g.R,__g.S,__g.T,__g.U,__g.V,__g.W,__g.X,__g.Y,__g.Z,__g.aa);if(__vd_version_info__.delayedGwx||false)$gwx_XC_5();	if (__vd_version_info__.delayedGwx) __wxAppCode__['components/vant/cell-group/index.wxml'] = [$gwx_XC_5, './components/vant/cell-group/index.wxml'];else __wxAppCode__['components/vant/cell-group/index.wxml'] = $gwx_XC_5( './components/vant/cell-group/index.wxml' );
	;__wxRoute = "components/vant/cell-group/index";__wxRouteBegin = true;__wxAppCurrentFile__="components/vant/cell-group/index.js";define("components/vant/cell-group/index.js",function(require,module,exports,window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){
"use strict";Object.defineProperty(exports,"__esModule",{value:!0}),require("../common/component").VantComponent({props:{title:String,border:{type:Boolean,value:!0}}});
},{isPage:false,isComponent:true,currentFile:'components/vant/cell-group/index.js'});require("components/vant/cell-group/index.js");$gwx_XC_6=function(_,_v,_n,_p,_s,_wp,_wl,$gwn,$gwl,$gwh,wh,$gstack,$gwrt,gra,grb,TestTest,wfor,_ca,_da,_r,_rz,_o,_oz,_1,_1z,_2,_2z,_m,_mz,nv_getDate,nv_getRegExp,nv_console,nv_parseInt,nv_parseFloat,nv_isNaN,nv_isFinite,nv_decodeURI,nv_decodeURIComponent,nv_encodeURI,nv_encodeURIComponent,$gdc,nv_JSON,_af,_gv,_ai,_grp,_gd,_gapi,$ixc,_ic,_w,_ev,_tsd){return function(path,global){
if(typeof global==='undefined'){if (typeof __GWX_GLOBAL__==='undefined')global={};else global=__GWX_GLOBAL__;}if(typeof __WXML_GLOBAL__ === 'undefined') {__WXML_GLOBAL__={};
}__WXML_GLOBAL__.modules = __WXML_GLOBAL__.modules || {};
var e_={}
if(typeof(global.entrys)==='undefined')global.entrys={};e_=global.entrys;
var d_={}
if(typeof(global.defines)==='undefined')global.defines={};d_=global.defines;
var f_={}
if(typeof(global.modules)==='undefined')global.modules={};f_=global.modules || {};
var p_={}
__WXML_GLOBAL__.ops_cached = __WXML_GLOBAL__.ops_cached || {}
__WXML_GLOBAL__.ops_set = __WXML_GLOBAL__.ops_set || {};
__WXML_GLOBAL__.ops_init = __WXML_GLOBAL__.ops_init || {};
var z=__WXML_GLOBAL__.ops_set.$gwx_XC_6 || [];
function gz$gwx_XC_6_1(){
if( __WXML_GLOBAL__.ops_cached.$gwx_XC_6_1)return __WXML_GLOBAL__.ops_cached.$gwx_XC_6_1
__WXML_GLOBAL__.ops_cached.$gwx_XC_6_1=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
Z([3,'onClick'])
Z([a,[3,'custom-class '],[[12],[[6],[[7],[3,'utils']],[3,'bem']],[[5],[[5],[1,'cell']],[[4],[[5],[[5],[[7],[3,'size']]],[[9],[[9],[[9],[[8],'center',[[7],[3,'center']]],[[8],'required',[[7],[3,'required']]]],[[8],'borderless',[[2,'!'],[[7],[3,'border']]]]],[[8],'clickable',[[2,'||'],[[7],[3,'isLink']],[[7],[3,'clickable']]]]]]]]]])
Z([3,'van-cell--hover hover-class'])
Z([3,'70'])
Z([[7],[3,'customStyle']])
Z([[7],[3,'icon']])
Z([3,'van-cell__left-icon-wrap'])
Z([3,'van-cell__left-icon'])
Z(z[5])
Z([3,'icon'])
Z([3,'van-cell__title title-class'])
Z([[2,'?:'],[[7],[3,'titleWidth']],[[2,'+'],[[2,'+'],[[2,'+'],[1,'max-width:'],[[7],[3,'titleWidth']]],[1,';min-width:']],[[7],[3,'titleWidth']]],[1,'']])
Z([[7],[3,'title']])
Z([3,'title'])
Z([[2,'||'],[[7],[3,'label']],[[7],[3,'useLabelSlot']]])
Z([3,'van-cell__label label-class'])
Z([[7],[3,'useLabelSlot']])
Z([3,'label'])
Z([[7],[3,'label']])
Z([3,'van-cell__value value-class'])
Z([[2,'||'],[[7],[3,'value']],[[2,'==='],[[7],[3,'value']],[1,0]]])
Z([[7],[3,'isLink']])
Z([3,'van-cell__right-icon-wrap right-icon-class'])
Z([3,'van-cell__right-icon'])
Z([[2,'?:'],[[7],[3,'arrowDirection']],[[2,'+'],[[2,'+'],[1,'arrow'],[1,'-']],[[7],[3,'arrowDirection']]],[1,'arrow']])
Z([3,'right-icon'])
Z([3,'extra'])
})(__WXML_GLOBAL__.ops_cached.$gwx_XC_6_1);return __WXML_GLOBAL__.ops_cached.$gwx_XC_6_1
}
__WXML_GLOBAL__.ops_set.$gwx_XC_6=z;
__WXML_GLOBAL__.ops_init.$gwx_XC_6=true;
var x=['./components/vant/cell/index.wxml'];d_[x[0]]={}
var m0=function(e,s,r,gg){
var z=gz$gwx_XC_6_1()
var cLB=_mz(z,'view',['bind:tap',0,'class',1,'hoverClass',1,'hoverStayTime',2,'style',3],[],e,s,gg)
var hMB=_v()
_(cLB,hMB)
if(_oz(z,5,e,s,gg)){hMB.wxVkey=1
var cOB=_mz(z,'van-icon',['class',6,'customClass',1,'name',2],[],e,s,gg)
_(hMB,cOB)
}
else{hMB.wxVkey=2
var oPB=_n('slot')
_rz(z,oPB,'name',9,e,s,gg)
_(hMB,oPB)
}
var lQB=_mz(z,'view',['class',10,'style',1],[],e,s,gg)
var aRB=_v()
_(lQB,aRB)
if(_oz(z,12,e,s,gg)){aRB.wxVkey=1
}
else{aRB.wxVkey=2
var eTB=_n('slot')
_rz(z,eTB,'name',13,e,s,gg)
_(aRB,eTB)
}
var tSB=_v()
_(lQB,tSB)
if(_oz(z,14,e,s,gg)){tSB.wxVkey=1
var bUB=_n('view')
_rz(z,bUB,'class',15,e,s,gg)
var oVB=_v()
_(bUB,oVB)
if(_oz(z,16,e,s,gg)){oVB.wxVkey=1
var xWB=_n('slot')
_rz(z,xWB,'name',17,e,s,gg)
_(oVB,xWB)
}
else if(_oz(z,18,e,s,gg)){oVB.wxVkey=2
}
oVB.wxXCkey=1
_(tSB,bUB)
}
aRB.wxXCkey=1
tSB.wxXCkey=1
_(cLB,lQB)
var oXB=_n('view')
_rz(z,oXB,'class',19,e,s,gg)
var fYB=_v()
_(oXB,fYB)
if(_oz(z,20,e,s,gg)){fYB.wxVkey=1
}
else{fYB.wxVkey=2
var cZB=_n('slot')
_(fYB,cZB)
}
fYB.wxXCkey=1
_(cLB,oXB)
var oNB=_v()
_(cLB,oNB)
if(_oz(z,21,e,s,gg)){oNB.wxVkey=1
var h1B=_mz(z,'van-icon',['class',22,'customClass',1,'name',2],[],e,s,gg)
_(oNB,h1B)
}
else{oNB.wxVkey=2
var o2B=_n('slot')
_rz(z,o2B,'name',25,e,s,gg)
_(oNB,o2B)
}
var c3B=_n('slot')
_rz(z,c3B,'name',26,e,s,gg)
_(cLB,c3B)
hMB.wxXCkey=1
hMB.wxXCkey=3
oNB.wxXCkey=1
oNB.wxXCkey=3
_(r,cLB)
return r
}
e_[x[0]]={f:m0,j:[],i:[],ti:[],ic:[]}
if(path&&e_[path]){
return function(env,dd,global){$gwxc=0;var root={"tag":"wx-page"};root.children=[]
;g="$gwx_XC_6";var main=e_[path].f
if (typeof global==="undefined")global={};global.f=$gdc(f_[path],"",1);
try{
main(env,{},root,global);
_tsd(root)
}catch(err){
console.log(err)
}
;g="";
return root;
}
}
}
}(__g.a,__g.b,__g.c,__g.d,__g.e,__g.f,__g.g,__g.h,__g.i,__g.j,__g.k,__g.l,__g.m,__g.n,__g.o,__g.p,__g.q,__g.r,__g.s,__g.t,__g.u,__g.v,__g.w,__g.x,__g.y,__g.z,__g.A,__g.B,__g.C,__g.D,__g.E,__g.F,__g.G,__g.H,__g.I,__g.J,__g.K,__g.L,__g.M,__g.N,__g.O,__g.P,__g.Q,__g.R,__g.S,__g.T,__g.U,__g.V,__g.W,__g.X,__g.Y,__g.Z,__g.aa);if(__vd_version_info__.delayedGwx||false)$gwx_XC_6();	if (__vd_version_info__.delayedGwx) __wxAppCode__['components/vant/cell/index.wxml'] = [$gwx_XC_6, './components/vant/cell/index.wxml'];else __wxAppCode__['components/vant/cell/index.wxml'] = $gwx_XC_6( './components/vant/cell/index.wxml' );
	;__wxRoute = "components/vant/cell/index";__wxRouteBegin = true;__wxAppCurrentFile__="components/vant/cell/index.js";define("components/vant/cell/index.js",function(require,module,exports,window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){
"use strict";Object.defineProperty(exports,"__esModule",{value:!0});var e=require("../mixins/link");require("../common/component").VantComponent({classes:["title-class","label-class","value-class","right-icon-class","hover-class"],mixins:[e.link],props:{title:null,value:null,icon:String,size:String,label:String,center:Boolean,isLink:Boolean,required:Boolean,clickable:Boolean,titleWidth:String,customStyle:String,arrowDirection:String,useLabelSlot:Boolean,border:{type:Boolean,value:!0}},methods:{onClick:function(e){this.$emit("click",e.detail),this.jumpLink()}}});
},{isPage:false,isComponent:true,currentFile:'components/vant/cell/index.js'});require("components/vant/cell/index.js");$gwx_XC_7=function(_,_v,_n,_p,_s,_wp,_wl,$gwn,$gwl,$gwh,wh,$gstack,$gwrt,gra,grb,TestTest,wfor,_ca,_da,_r,_rz,_o,_oz,_1,_1z,_2,_2z,_m,_mz,nv_getDate,nv_getRegExp,nv_console,nv_parseInt,nv_parseFloat,nv_isNaN,nv_isFinite,nv_decodeURI,nv_decodeURIComponent,nv_encodeURI,nv_encodeURIComponent,$gdc,nv_JSON,_af,_gv,_ai,_grp,_gd,_gapi,$ixc,_ic,_w,_ev,_tsd){return function(path,global){
if(typeof global==='undefined'){if (typeof __GWX_GLOBAL__==='undefined')global={};else global=__GWX_GLOBAL__;}if(typeof __WXML_GLOBAL__ === 'undefined') {__WXML_GLOBAL__={};
}__WXML_GLOBAL__.modules = __WXML_GLOBAL__.modules || {};
var e_={}
if(typeof(global.entrys)==='undefined')global.entrys={};e_=global.entrys;
var d_={}
if(typeof(global.defines)==='undefined')global.defines={};d_=global.defines;
var f_={}
if(typeof(global.modules)==='undefined')global.modules={};f_=global.modules || {};
var p_={}
__WXML_GLOBAL__.ops_cached = __WXML_GLOBAL__.ops_cached || {}
__WXML_GLOBAL__.ops_set = __WXML_GLOBAL__.ops_set || {};
__WXML_GLOBAL__.ops_init = __WXML_GLOBAL__.ops_init || {};
var z=__WXML_GLOBAL__.ops_set.$gwx_XC_7 || [];
function gz$gwx_XC_7_1(){
if( __WXML_GLOBAL__.ops_cached.$gwx_XC_7_1)return __WXML_GLOBAL__.ops_cached.$gwx_XC_7_1
__WXML_GLOBAL__.ops_cached.$gwx_XC_7_1=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
Z([3,'van-checkbox custom-class'])
Z([3,'toggle'])
Z([3,'van-checkbox__icon-wrap'])
Z([[7],[3,'useIconSlot']])
Z([3,'icon'])
Z([[12],[[6],[[7],[3,'utils']],[3,'bem']],[[5],[[5],[1,'checkbox__icon']],[[4],[[5],[[5],[[7],[3,'shape']]],[[9],[[8],'disabled',[[2,'||'],[[7],[3,'disabled']],[[7],[3,'parentDisabled']]]],[[8],'checked',[[7],[3,'value']]]]]]]])
Z([3,'icon-class'])
Z([3,'line-height: 1.25em;'])
Z([3,'success'])
Z([3,'0.8em'])
Z([[12],[[6],[[7],[3,'computed']],[3,'iconStyle']],[[5],[[5],[[5],[[5],[[5],[[7],[3,'checkedColor']]],[[7],[3,'value']]],[[7],[3,'disabled']]],[[7],[3,'parentDisabled']]],[[7],[3,'iconSize']]]])
Z([3,'onClickLabel'])
Z([a,[3,'label-class '],[[12],[[6],[[7],[3,'utils']],[3,'bem']],[[5],[[5],[1,'checkbox__label']],[[4],[[5],[[5],[[7],[3,'labelPosition']]],[[8],'disabled',[[2,'||'],[[7],[3,'disabled']],[[7],[3,'parentDisabled']]]]]]]]])
})(__WXML_GLOBAL__.ops_cached.$gwx_XC_7_1);return __WXML_GLOBAL__.ops_cached.$gwx_XC_7_1
}
__WXML_GLOBAL__.ops_set.$gwx_XC_7=z;
__WXML_GLOBAL__.ops_init.$gwx_XC_7=true;
var x=['./components/vant/checkbox/index.wxml'];d_[x[0]]={}
var m0=function(e,s,r,gg){
var z=gz$gwx_XC_7_1()
var l5B=_n('view')
_rz(z,l5B,'class',0,e,s,gg)
var a6B=_mz(z,'view',['bindtap',1,'class',1],[],e,s,gg)
var t7B=_v()
_(a6B,t7B)
if(_oz(z,3,e,s,gg)){t7B.wxVkey=1
var e8B=_n('slot')
_rz(z,e8B,'name',4,e,s,gg)
_(t7B,e8B)
}
else{t7B.wxVkey=2
var b9B=_mz(z,'van-icon',['class',5,'customClass',1,'customStyle',2,'name',3,'size',4,'style',5],[],e,s,gg)
_(t7B,b9B)
}
t7B.wxXCkey=1
t7B.wxXCkey=3
_(l5B,a6B)
var o0B=_mz(z,'view',['bindtap',11,'class',1],[],e,s,gg)
var xAC=_n('slot')
_(o0B,xAC)
_(l5B,o0B)
_(r,l5B)
return r
}
e_[x[0]]={f:m0,j:[],i:[],ti:[],ic:[]}
if(path&&e_[path]){
return function(env,dd,global){$gwxc=0;var root={"tag":"wx-page"};root.children=[]
;g="$gwx_XC_7";var main=e_[path].f
if (typeof global==="undefined")global={};global.f=$gdc(f_[path],"",1);
try{
main(env,{},root,global);
_tsd(root)
}catch(err){
console.log(err)
}
;g="";
return root;
}
}
}
}(__g.a,__g.b,__g.c,__g.d,__g.e,__g.f,__g.g,__g.h,__g.i,__g.j,__g.k,__g.l,__g.m,__g.n,__g.o,__g.p,__g.q,__g.r,__g.s,__g.t,__g.u,__g.v,__g.w,__g.x,__g.y,__g.z,__g.A,__g.B,__g.C,__g.D,__g.E,__g.F,__g.G,__g.H,__g.I,__g.J,__g.K,__g.L,__g.M,__g.N,__g.O,__g.P,__g.Q,__g.R,__g.S,__g.T,__g.U,__g.V,__g.W,__g.X,__g.Y,__g.Z,__g.aa);if(__vd_version_info__.delayedGwx||false)$gwx_XC_7();	if (__vd_version_info__.delayedGwx) __wxAppCode__['components/vant/checkbox/index.wxml'] = [$gwx_XC_7, './components/vant/checkbox/index.wxml'];else __wxAppCode__['components/vant/checkbox/index.wxml'] = $gwx_XC_7( './components/vant/checkbox/index.wxml' );
	;__wxRoute = "components/vant/checkbox/index";__wxRouteBegin = true;__wxAppCurrentFile__="components/vant/checkbox/index.js";define("components/vant/checkbox/index.js",function(require,module,exports,window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){
"use strict";function e(e,a){e.$emit("input",a),e.$emit("change",a)}Object.defineProperty(exports,"__esModule",{value:!0}),require("../common/component").VantComponent({field:!0,relation:{name:"checkbox-group",type:"ancestor",current:"checkbox"},classes:["icon-class","label-class"],props:{value:Boolean,disabled:Boolean,useIconSlot:Boolean,checkedColor:String,labelPosition:String,labelDisabled:Boolean,shape:{type:String,value:"round"},iconSize:{type:null,value:20}},data:{parentDisabled:!1},methods:{emitChange:function(a){this.parent?this.setParentValue(this.parent,a):e(this,a)},toggle:function(){var e=this.data,a=e.parentDisabled,t=e.disabled,n=e.value;t||a||this.emitChange(!n)},onClickLabel:function(){var e=this.data,a=e.labelDisabled,t=e.parentDisabled,n=e.disabled,i=e.value;n||a||t||this.emitChange(!i)},setParentValue:function(a,t){var n=a.data.value.slice(),i=this.data.name,l=a.data.max;if(t){if(l&&n.length>=l)return;-1===n.indexOf(i)&&(n.push(i),e(a,n))}else{var o=n.indexOf(i);-1!==o&&(n.splice(o,1),e(a,n))}}}});
},{isPage:false,isComponent:true,currentFile:'components/vant/checkbox/index.js'});require("components/vant/checkbox/index.js");$gwx_XC_8=function(_,_v,_n,_p,_s,_wp,_wl,$gwn,$gwl,$gwh,wh,$gstack,$gwrt,gra,grb,TestTest,wfor,_ca,_da,_r,_rz,_o,_oz,_1,_1z,_2,_2z,_m,_mz,nv_getDate,nv_getRegExp,nv_console,nv_parseInt,nv_parseFloat,nv_isNaN,nv_isFinite,nv_decodeURI,nv_decodeURIComponent,nv_encodeURI,nv_encodeURIComponent,$gdc,nv_JSON,_af,_gv,_ai,_grp,_gd,_gapi,$ixc,_ic,_w,_ev,_tsd){return function(path,global){
if(typeof global==='undefined'){if (typeof __GWX_GLOBAL__==='undefined')global={};else global=__GWX_GLOBAL__;}if(typeof __WXML_GLOBAL__ === 'undefined') {__WXML_GLOBAL__={};
}__WXML_GLOBAL__.modules = __WXML_GLOBAL__.modules || {};
var e_={}
if(typeof(global.entrys)==='undefined')global.entrys={};e_=global.entrys;
var d_={}
if(typeof(global.defines)==='undefined')global.defines={};d_=global.defines;
var f_={}
if(typeof(global.modules)==='undefined')global.modules={};f_=global.modules || {};
var p_={}
__WXML_GLOBAL__.ops_cached = __WXML_GLOBAL__.ops_cached || {}
__WXML_GLOBAL__.ops_set = __WXML_GLOBAL__.ops_set || {};
__WXML_GLOBAL__.ops_init = __WXML_GLOBAL__.ops_init || {};
var z=__WXML_GLOBAL__.ops_set.$gwx_XC_8 || [];
function gz$gwx_XC_8_1(){
if( __WXML_GLOBAL__.ops_cached.$gwx_XC_8_1)return __WXML_GLOBAL__.ops_cached.$gwx_XC_8_1
__WXML_GLOBAL__.ops_cached.$gwx_XC_8_1=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
Z([3,'van-circle'])
Z([[2,'!'],[[7],[3,'text']]])
})(__WXML_GLOBAL__.ops_cached.$gwx_XC_8_1);return __WXML_GLOBAL__.ops_cached.$gwx_XC_8_1
}
__WXML_GLOBAL__.ops_set.$gwx_XC_8=z;
__WXML_GLOBAL__.ops_init.$gwx_XC_8=true;
var x=['./components/vant/circle/index.wxml'];d_[x[0]]={}
var m0=function(e,s,r,gg){
var z=gz$gwx_XC_8_1()
var fCC=_n('view')
_rz(z,fCC,'class',0,e,s,gg)
var cDC=_v()
_(fCC,cDC)
if(_oz(z,1,e,s,gg)){cDC.wxVkey=1
var hEC=_n('slot')
_(cDC,hEC)
}
else{cDC.wxVkey=2
}
cDC.wxXCkey=1
_(r,fCC)
return r
}
e_[x[0]]={f:m0,j:[],i:[],ti:[],ic:[]}
if(path&&e_[path]){
return function(env,dd,global){$gwxc=0;var root={"tag":"wx-page"};root.children=[]
;g="$gwx_XC_8";var main=e_[path].f
if (typeof global==="undefined")global={};global.f=$gdc(f_[path],"",1);
try{
main(env,{},root,global);
_tsd(root)
}catch(err){
console.log(err)
}
;g="";
return root;
}
}
}
}(__g.a,__g.b,__g.c,__g.d,__g.e,__g.f,__g.g,__g.h,__g.i,__g.j,__g.k,__g.l,__g.m,__g.n,__g.o,__g.p,__g.q,__g.r,__g.s,__g.t,__g.u,__g.v,__g.w,__g.x,__g.y,__g.z,__g.A,__g.B,__g.C,__g.D,__g.E,__g.F,__g.G,__g.H,__g.I,__g.J,__g.K,__g.L,__g.M,__g.N,__g.O,__g.P,__g.Q,__g.R,__g.S,__g.T,__g.U,__g.V,__g.W,__g.X,__g.Y,__g.Z,__g.aa);if(__vd_version_info__.delayedGwx||false)$gwx_XC_8();	if (__vd_version_info__.delayedGwx) __wxAppCode__['components/vant/circle/index.wxml'] = [$gwx_XC_8, './components/vant/circle/index.wxml'];else __wxAppCode__['components/vant/circle/index.wxml'] = $gwx_XC_8( './components/vant/circle/index.wxml' );
	;__wxRoute = "components/vant/circle/index";__wxRouteBegin = true;__wxAppCurrentFile__="components/vant/circle/index.js";define("components/vant/circle/index.js",function(require,module,exports,window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){
"use strict";Object.defineProperty(exports,"__esModule",{value:!0});var e=require("../common/component"),t=require("../common/utils"),r=require("../common/color");var a=2*Math.PI,n=-Math.PI/2;e.VantComponent({props:{text:String,lineCap:{type:String,value:"round"},value:{type:Number,value:0,observer:"reRender"},speed:{type:Number,value:50},size:{type:Number,value:100},fill:String,layerColor:{type:String,value:r.WHITE},color:{type:[String,Object],value:r.BLUE,observer:"setHoverColor"},type:{type:String,value:""},strokeWidth:{type:Number,value:4},clockwise:{type:Boolean,value:!0}},data:{hoverColor:r.BLUE},methods:{getContext:function(){return this.ctx||(this.ctx=wx.createCanvasContext("van-circle",this)),this.ctx},setHoverColor:function(){var e=this.data,r=e.color,a=e.size,n=e.type,i=n?this.getContext(n):this.getContext(),o=r;if(t.isObj(r)){var l=i.createLinearGradient(a,0,0,0);Object.keys(r).sort((function(e,t){return parseFloat(e)-parseFloat(t)})).map((function(e){return l.addColorStop(parseFloat(e)/100,r[e])})),o=l}this.setData({hoverColor:o})},presetCanvas:function(e,t,r,a,n){var i=this.data,o=i.strokeWidth,l=i.lineCap,s=i.clockwise,c=i.size/2,u=c-o/2;e.setStrokeStyle(t),e.setLineWidth(o),e.setLineCap(l),e.beginPath(),e.arc(c,c,u,r,a,!s),e.stroke(),n&&(e.setFillStyle(n),e.fill())},renderLayerCircle:function(e){var t=this.data,r=t.layerColor,n=t.fill;this.presetCanvas(e,r,0,a,n)},renderHoverCircle:function(e,t){var r=this.data,i=r.clockwise,o=r.hoverColor,l=a*(t/100),s=i?n+l:3*Math.PI-(n+l);this.presetCanvas(e,o,n,s)},drawCircle:function(e){var t=this.data,r=t.size,a=t.type,n=a?this.getContext(a):this.getContext();n.clearRect(0,0,r,r),this.renderLayerCircle(n);var i,o=(i=e,Math.min(Math.max(i,0),100));0!==o&&this.renderHoverCircle(n,o),n.draw()},reRender:function(){var e=this,t=this.data,r=t.value,a=t.speed;a<=0||a>1e3?this.drawCircle(r):(this.clearInterval(),this.currentValue=this.currentValue||0,this.interval=setInterval((function(){e.currentValue!==r?(e.currentValue<r?e.currentValue+=1:e.currentValue-=1,e.drawCircle(e.currentValue)):e.clearInterval()}),1e3/a))},clearInterval:function(e){function t(){return e.apply(this,arguments)}return t.toString=function(){return e.toString()},t}((function(){this.interval&&(clearInterval(this.interval),this.interval=null)}))},created:function(){var e=this.data.value;this.currentValue=e,this.drawCircle(e)},destroyed:function(){this.ctx=null,this.clearInterval()}});
},{isPage:false,isComponent:true,currentFile:'components/vant/circle/index.js'});require("components/vant/circle/index.js");$gwx_XC_9=function(_,_v,_n,_p,_s,_wp,_wl,$gwn,$gwl,$gwh,wh,$gstack,$gwrt,gra,grb,TestTest,wfor,_ca,_da,_r,_rz,_o,_oz,_1,_1z,_2,_2z,_m,_mz,nv_getDate,nv_getRegExp,nv_console,nv_parseInt,nv_parseFloat,nv_isNaN,nv_isFinite,nv_decodeURI,nv_decodeURIComponent,nv_encodeURI,nv_encodeURIComponent,$gdc,nv_JSON,_af,_gv,_ai,_grp,_gd,_gapi,$ixc,_ic,_w,_ev,_tsd){return function(path,global){
if(typeof global==='undefined'){if (typeof __GWX_GLOBAL__==='undefined')global={};else global=__GWX_GLOBAL__;}if(typeof __WXML_GLOBAL__ === 'undefined') {__WXML_GLOBAL__={};
}__WXML_GLOBAL__.modules = __WXML_GLOBAL__.modules || {};
var e_={}
if(typeof(global.entrys)==='undefined')global.entrys={};e_=global.entrys;
var d_={}
if(typeof(global.defines)==='undefined')global.defines={};d_=global.defines;
var f_={}
if(typeof(global.modules)==='undefined')global.modules={};f_=global.modules || {};
var p_={}
__WXML_GLOBAL__.ops_cached = __WXML_GLOBAL__.ops_cached || {}
__WXML_GLOBAL__.ops_set = __WXML_GLOBAL__.ops_set || {};
__WXML_GLOBAL__.ops_init = __WXML_GLOBAL__.ops_init || {};
var z=__WXML_GLOBAL__.ops_set.$gwx_XC_9 || [];
function gz$gwx_XC_9_1(){
if( __WXML_GLOBAL__.ops_cached.$gwx_XC_9_1)return __WXML_GLOBAL__.ops_cached.$gwx_XC_9_1
__WXML_GLOBAL__.ops_cached.$gwx_XC_9_1=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
Z([3,'onClickOverlay'])
Z([[7],[3,'closeOnClickOverlay']])
Z([a,[3,'van-dialog van-dialog--'],[[7],[3,'theme']],[3,' '],[[7],[3,'className']]])
Z([a,[3,'width: '],[[12],[[6],[[7],[3,'utils']],[3,'addUnit']],[[5],[[7],[3,'width']]]],[3,';'],[[7],[3,'customStyle']]])
Z([[7],[3,'overlay']])
Z([[7],[3,'overlayStyle']])
Z([[7],[3,'show']])
Z([[7],[3,'transition']])
Z([[7],[3,'zIndex']])
Z([[2,'||'],[[7],[3,'title']],[[7],[3,'useTitleSlot']]])
Z([[12],[[6],[[7],[3,'utils']],[3,'bem']],[[5],[[5],[1,'dialog__header']],[[8],'isolated',[[2,'!'],[[2,'||'],[[7],[3,'message']],[[7],[3,'useSlot']]]]]]])
Z([[7],[3,'useTitleSlot']])
Z([3,'title'])
Z([[7],[3,'title']])
Z([[7],[3,'useSlot']])
Z([[7],[3,'message']])
Z([[2,'==='],[[7],[3,'theme']],[1,'round-button']])
Z([3,'van-dialog__footer--round-button'])
Z([[7],[3,'showCancelButton']])
Z([3,'onCancel'])
Z([3,'van-dialog__button van-hairline--right'])
Z([3,'van-dialog__cancel'])
Z([a,[3,'color: '],[[7],[3,'cancelButtonColor']]])
Z([[6],[[7],[3,'loading']],[3,'cancel']])
Z([3,'large'])
Z([[7],[3,'showConfirmButton']])
Z([[7],[3,'appParameter']])
Z([3,'onConfirm'])
Z([3,'bindContact'])
Z([3,'bindError'])
Z([3,'bindGetPhoneNumber'])
Z([3,'bindGetUserInfo'])
Z([3,'bindLaunchApp'])
Z([3,'bindOpenSetting'])
Z([[7],[3,'businessId']])
Z([3,'van-dialog__button'])
Z([3,'van-dialog__confirm'])
Z([a,z[22][1],[[7],[3,'confirmButtonColor']]])
Z([[7],[3,'lang']])
Z([[6],[[7],[3,'loading']],[3,'confirm']])
Z([[7],[3,'confirmButtonOpenType']])
Z([[7],[3,'sendMessageImg']])
Z([[7],[3,'sendMessagePath']])
Z([[7],[3,'sendMessageTitle']])
Z([[7],[3,'sessionFrom']])
Z([[7],[3,'showMessageCard']])
Z(z[24])
Z([3,'van-hairline--top van-dialog__footer'])
Z(z[18])
Z(z[19])
Z(z[20])
Z(z[21])
Z([a,z[22][1],z[22][2]])
Z(z[23])
Z(z[24])
Z(z[25])
Z(z[26])
Z(z[27])
Z(z[28])
Z(z[29])
Z(z[30])
Z(z[31])
Z(z[32])
Z(z[33])
Z(z[34])
Z(z[35])
Z(z[36])
Z([a,z[22][1],z[37][2]])
Z(z[38])
Z(z[39])
Z(z[40])
Z(z[41])
Z(z[42])
Z(z[43])
Z(z[44])
Z(z[45])
Z(z[24])
})(__WXML_GLOBAL__.ops_cached.$gwx_XC_9_1);return __WXML_GLOBAL__.ops_cached.$gwx_XC_9_1
}
__WXML_GLOBAL__.ops_set.$gwx_XC_9=z;
__WXML_GLOBAL__.ops_init.$gwx_XC_9=true;
var x=['./components/vant/dialog/index.wxml'];d_[x[0]]={}
var m0=function(e,s,r,gg){
var z=gz$gwx_XC_9_1()
var cGC=_mz(z,'van-popup',['bind:close',0,'closeOnClickOverlay',1,'customClass',1,'customStyle',2,'overlay',3,'overlayStyle',4,'show',5,'transition',6,'zIndex',7],[],e,s,gg)
var oHC=_v()
_(cGC,oHC)
if(_oz(z,9,e,s,gg)){oHC.wxVkey=1
var tKC=_n('view')
_rz(z,tKC,'class',10,e,s,gg)
var eLC=_v()
_(tKC,eLC)
if(_oz(z,11,e,s,gg)){eLC.wxVkey=1
var bMC=_n('slot')
_rz(z,bMC,'name',12,e,s,gg)
_(eLC,bMC)
}
else if(_oz(z,13,e,s,gg)){eLC.wxVkey=2
}
eLC.wxXCkey=1
_(oHC,tKC)
}
var lIC=_v()
_(cGC,lIC)
if(_oz(z,14,e,s,gg)){lIC.wxVkey=1
var oNC=_n('slot')
_(lIC,oNC)
}
else if(_oz(z,15,e,s,gg)){lIC.wxVkey=2
}
var aJC=_v()
_(cGC,aJC)
if(_oz(z,16,e,s,gg)){aJC.wxVkey=1
var xOC=_n('van-goods-action')
_rz(z,xOC,'customClass',17,e,s,gg)
var oPC=_v()
_(xOC,oPC)
if(_oz(z,18,e,s,gg)){oPC.wxVkey=1
var cRC=_mz(z,'van-goods-action-button',['bind:click',19,'class',1,'customClass',2,'customStyle',3,'loading',4,'size',5],[],e,s,gg)
_(oPC,cRC)
}
var fQC=_v()
_(xOC,fQC)
if(_oz(z,25,e,s,gg)){fQC.wxVkey=1
var hSC=_mz(z,'van-goods-action-button',['appParameter',26,'bind:click',1,'bindcontact',2,'binderror',3,'bindgetphonenumber',4,'bindgetuserinfo',5,'bindlaunchapp',6,'bindopensetting',7,'businessId',8,'class',9,'customClass',10,'customStyle',11,'lang',12,'loading',13,'openType',14,'sendMessageImg',15,'sendMessagePath',16,'sendMessageTitle',17,'sessionFrom',18,'showMessageCard',19,'size',20],[],e,s,gg)
_(fQC,hSC)
}
oPC.wxXCkey=1
oPC.wxXCkey=3
fQC.wxXCkey=1
fQC.wxXCkey=3
_(aJC,xOC)
}
else{aJC.wxVkey=2
var oTC=_n('view')
_rz(z,oTC,'class',47,e,s,gg)
var cUC=_v()
_(oTC,cUC)
if(_oz(z,48,e,s,gg)){cUC.wxVkey=1
var lWC=_mz(z,'van-button',['bind:click',49,'class',1,'customClass',2,'customStyle',3,'loading',4,'size',5],[],e,s,gg)
_(cUC,lWC)
}
var oVC=_v()
_(oTC,oVC)
if(_oz(z,55,e,s,gg)){oVC.wxVkey=1
var aXC=_mz(z,'van-button',['appParameter',56,'bind:click',1,'bindcontact',2,'binderror',3,'bindgetphonenumber',4,'bindgetuserinfo',5,'bindlaunchapp',6,'bindopensetting',7,'businessId',8,'class',9,'customClass',10,'customStyle',11,'lang',12,'loading',13,'openType',14,'sendMessageImg',15,'sendMessagePath',16,'sendMessageTitle',17,'sessionFrom',18,'showMessageCard',19,'size',20],[],e,s,gg)
_(oVC,aXC)
}
cUC.wxXCkey=1
cUC.wxXCkey=3
oVC.wxXCkey=1
oVC.wxXCkey=3
_(aJC,oTC)
}
oHC.wxXCkey=1
lIC.wxXCkey=1
aJC.wxXCkey=1
aJC.wxXCkey=3
aJC.wxXCkey=3
_(r,cGC)
return r
}
e_[x[0]]={f:m0,j:[],i:[],ti:[],ic:[]}
if(path&&e_[path]){
return function(env,dd,global){$gwxc=0;var root={"tag":"wx-page"};root.children=[]
;g="$gwx_XC_9";var main=e_[path].f
if (typeof global==="undefined")global={};global.f=$gdc(f_[path],"",1);
try{
main(env,{},root,global);
_tsd(root)
}catch(err){
console.log(err)
}
;g="";
return root;
}
}
}
}(__g.a,__g.b,__g.c,__g.d,__g.e,__g.f,__g.g,__g.h,__g.i,__g.j,__g.k,__g.l,__g.m,__g.n,__g.o,__g.p,__g.q,__g.r,__g.s,__g.t,__g.u,__g.v,__g.w,__g.x,__g.y,__g.z,__g.A,__g.B,__g.C,__g.D,__g.E,__g.F,__g.G,__g.H,__g.I,__g.J,__g.K,__g.L,__g.M,__g.N,__g.O,__g.P,__g.Q,__g.R,__g.S,__g.T,__g.U,__g.V,__g.W,__g.X,__g.Y,__g.Z,__g.aa);if(__vd_version_info__.delayedGwx||false)$gwx_XC_9();	if (__vd_version_info__.delayedGwx) __wxAppCode__['components/vant/dialog/index.wxml'] = [$gwx_XC_9, './components/vant/dialog/index.wxml'];else __wxAppCode__['components/vant/dialog/index.wxml'] = $gwx_XC_9( './components/vant/dialog/index.wxml' );
	;__wxRoute = "components/vant/dialog/index";__wxRouteBegin = true;__wxAppCurrentFile__="components/vant/dialog/index.js";define("components/vant/dialog/index.js",function(require,module,exports,window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){
"use strict";Object.defineProperty(exports,"__esModule",{value:!0});var t=require("../common/component"),e=require("../mixins/button"),n=require("../mixins/open-type"),o=require("../common/color");t.VantComponent({mixins:[e.button,n.openType],props:{show:{type:Boolean,observer:function(t){!t&&this.stopLoading()}},title:String,message:String,theme:{type:String,value:"default"},useSlot:Boolean,className:String,customStyle:String,asyncClose:Boolean,messageAlign:String,overlayStyle:String,useTitleSlot:Boolean,showCancelButton:Boolean,closeOnClickOverlay:Boolean,confirmButtonOpenType:String,width:null,zIndex:{type:Number,value:2e3},confirmButtonText:{type:String,value:"确认"},cancelButtonText:{type:String,value:"取消"},confirmButtonColor:{type:String,value:o.RED},cancelButtonColor:{type:String,value:o.GRAY},showConfirmButton:{type:Boolean,value:!0},overlay:{type:Boolean,value:!0},transition:{type:String,value:"scale"}},data:{loading:{confirm:!1,cancel:!1}},methods:{onConfirm:function(){this.handleAction("confirm")},onCancel:function(){this.handleAction("cancel")},onClickOverlay:function(){this.onClose("overlay")},handleAction:function(t){var e;this.data.asyncClose&&this.setData(((e={})["loading."+t]=!0,e)),this.onClose(t)},close:function(){this.setData({show:!1})},stopLoading:function(){this.setData({loading:{confirm:!1,cancel:!1}})},onClose:function(t){this.data.asyncClose||this.close(),this.$emit("close",t),this.$emit(t,{dialog:this});var e=this.data["confirm"===t?"onConfirm":"onCancel"];e&&e(this)}}});
},{isPage:false,isComponent:true,currentFile:'components/vant/dialog/index.js'});require("components/vant/dialog/index.js");$gwx_XC_10=function(_,_v,_n,_p,_s,_wp,_wl,$gwn,$gwl,$gwh,wh,$gstack,$gwrt,gra,grb,TestTest,wfor,_ca,_da,_r,_rz,_o,_oz,_1,_1z,_2,_2z,_m,_mz,nv_getDate,nv_getRegExp,nv_console,nv_parseInt,nv_parseFloat,nv_isNaN,nv_isFinite,nv_decodeURI,nv_decodeURIComponent,nv_encodeURI,nv_encodeURIComponent,$gdc,nv_JSON,_af,_gv,_ai,_grp,_gd,_gapi,$ixc,_ic,_w,_ev,_tsd){return function(path,global){
if(typeof global==='undefined'){if (typeof __GWX_GLOBAL__==='undefined')global={};else global=__GWX_GLOBAL__;}if(typeof __WXML_GLOBAL__ === 'undefined') {__WXML_GLOBAL__={};
}__WXML_GLOBAL__.modules = __WXML_GLOBAL__.modules || {};
var e_={}
if(typeof(global.entrys)==='undefined')global.entrys={};e_=global.entrys;
var d_={}
if(typeof(global.defines)==='undefined')global.defines={};d_=global.defines;
var f_={}
if(typeof(global.modules)==='undefined')global.modules={};f_=global.modules || {};
var p_={}
__WXML_GLOBAL__.ops_cached = __WXML_GLOBAL__.ops_cached || {}
__WXML_GLOBAL__.ops_set = __WXML_GLOBAL__.ops_set || {};
__WXML_GLOBAL__.ops_init = __WXML_GLOBAL__.ops_init || {};
var z=__WXML_GLOBAL__.ops_set.$gwx_XC_10 || [];
function gz$gwx_XC_10_1(){
if( __WXML_GLOBAL__.ops_cached.$gwx_XC_10_1)return __WXML_GLOBAL__.ops_cached.$gwx_XC_10_1
__WXML_GLOBAL__.ops_cached.$gwx_XC_10_1=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
})(__WXML_GLOBAL__.ops_cached.$gwx_XC_10_1);return __WXML_GLOBAL__.ops_cached.$gwx_XC_10_1
}
__WXML_GLOBAL__.ops_set.$gwx_XC_10=z;
__WXML_GLOBAL__.ops_init.$gwx_XC_10=true;
var x=['./components/vant/divider/index.wxml'];d_[x[0]]={}
var m0=function(e,s,r,gg){
var z=gz$gwx_XC_10_1()
var eZC=_n('slot')
_(r,eZC)
return r
}
e_[x[0]]={f:m0,j:[],i:[],ti:[],ic:[]}
if(path&&e_[path]){
return function(env,dd,global){$gwxc=0;var root={"tag":"wx-page"};root.children=[]
;g="$gwx_XC_10";var main=e_[path].f
if (typeof global==="undefined")global={};global.f=$gdc(f_[path],"",1);
try{
main(env,{},root,global);
_tsd(root)
}catch(err){
console.log(err)
}
;g="";
return root;
}
}
}
}(__g.a,__g.b,__g.c,__g.d,__g.e,__g.f,__g.g,__g.h,__g.i,__g.j,__g.k,__g.l,__g.m,__g.n,__g.o,__g.p,__g.q,__g.r,__g.s,__g.t,__g.u,__g.v,__g.w,__g.x,__g.y,__g.z,__g.A,__g.B,__g.C,__g.D,__g.E,__g.F,__g.G,__g.H,__g.I,__g.J,__g.K,__g.L,__g.M,__g.N,__g.O,__g.P,__g.Q,__g.R,__g.S,__g.T,__g.U,__g.V,__g.W,__g.X,__g.Y,__g.Z,__g.aa);if(__vd_version_info__.delayedGwx||false)$gwx_XC_10();	if (__vd_version_info__.delayedGwx) __wxAppCode__['components/vant/divider/index.wxml'] = [$gwx_XC_10, './components/vant/divider/index.wxml'];else __wxAppCode__['components/vant/divider/index.wxml'] = $gwx_XC_10( './components/vant/divider/index.wxml' );
	;__wxRoute = "components/vant/divider/index";__wxRouteBegin = true;__wxAppCurrentFile__="components/vant/divider/index.js";define("components/vant/divider/index.js",function(require,module,exports,window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){
"use strict";Object.defineProperty(exports,"__esModule",{value:!0}),require("../common/component").VantComponent({props:{dashed:{type:Boolean,value:!1},hairline:{type:Boolean,value:!1},contentPosition:{type:String,value:""},fontSize:{type:Number,value:""},borderColor:{type:String,value:""},textColor:{type:String,value:""},customStyle:{type:String,value:""}}});
},{isPage:false,isComponent:true,currentFile:'components/vant/divider/index.js'});require("components/vant/divider/index.js");$gwx_XC_11=function(_,_v,_n,_p,_s,_wp,_wl,$gwn,$gwl,$gwh,wh,$gstack,$gwrt,gra,grb,TestTest,wfor,_ca,_da,_r,_rz,_o,_oz,_1,_1z,_2,_2z,_m,_mz,nv_getDate,nv_getRegExp,nv_console,nv_parseInt,nv_parseFloat,nv_isNaN,nv_isFinite,nv_decodeURI,nv_decodeURIComponent,nv_encodeURI,nv_encodeURIComponent,$gdc,nv_JSON,_af,_gv,_ai,_grp,_gd,_gapi,$ixc,_ic,_w,_ev,_tsd){return function(path,global){
if(typeof global==='undefined'){if (typeof __GWX_GLOBAL__==='undefined')global={};else global=__GWX_GLOBAL__;}if(typeof __WXML_GLOBAL__ === 'undefined') {__WXML_GLOBAL__={};
}__WXML_GLOBAL__.modules = __WXML_GLOBAL__.modules || {};
var e_={}
if(typeof(global.entrys)==='undefined')global.entrys={};e_=global.entrys;
var d_={}
if(typeof(global.defines)==='undefined')global.defines={};d_=global.defines;
var f_={}
if(typeof(global.modules)==='undefined')global.modules={};f_=global.modules || {};
var p_={}
__WXML_GLOBAL__.ops_cached = __WXML_GLOBAL__.ops_cached || {}
__WXML_GLOBAL__.ops_set = __WXML_GLOBAL__.ops_set || {};
__WXML_GLOBAL__.ops_init = __WXML_GLOBAL__.ops_init || {};
var z=__WXML_GLOBAL__.ops_set.$gwx_XC_11 || [];
function gz$gwx_XC_11_1(){
if( __WXML_GLOBAL__.ops_cached.$gwx_XC_11_1)return __WXML_GLOBAL__.ops_cached.$gwx_XC_11_1
__WXML_GLOBAL__.ops_cached.$gwx_XC_11_1=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
Z([[7],[3,'arrowDirection']])
Z([[7],[3,'border']])
Z([[7],[3,'center']])
Z([[7],[3,'clickable']])
Z([3,'van-field'])
Z([[7],[3,'customStyle']])
Z([[7],[3,'leftIcon']])
Z([[7],[3,'isLink']])
Z([[7],[3,'required']])
Z([[7],[3,'size']])
Z([[7],[3,'label']])
Z([[7],[3,'titleWidth']])
Z([3,'left-icon'])
Z([3,'icon'])
Z([3,'label'])
Z([3,'title'])
Z([[12],[[6],[[7],[3,'utils']],[3,'bem']],[[5],[[5],[1,'field__body']],[[4],[[5],[[5],[[7],[3,'type']]],[[7],[3,'system']]]]]])
Z([[2,'&&'],[[7],[3,'clearable']],[[7],[3,'value']]])
Z([3,'onClear'])
Z([3,'van-field__clear-root van-field__icon-root'])
Z([3,'clear'])
Z([3,'16px'])
Z([3,'onClickIcon'])
Z([3,'van-field__icon-container'])
Z([[2,'||'],[[7],[3,'rightIcon']],[[7],[3,'icon']]])
Z([a,[3,'van-field__icon-root '],[[7],[3,'iconClass']]])
Z([3,'right-icon-class'])
Z(z[24])
Z(z[21])
Z([3,'right-icon'])
Z(z[13])
Z([3,'button'])
Z([[7],[3,'errorMessage']])
})(__WXML_GLOBAL__.ops_cached.$gwx_XC_11_1);return __WXML_GLOBAL__.ops_cached.$gwx_XC_11_1
}
__WXML_GLOBAL__.ops_set.$gwx_XC_11=z;
__WXML_GLOBAL__.ops_init.$gwx_XC_11=true;
var x=['./components/vant/field/index.wxml'];d_[x[0]]={}
var m0=function(e,s,r,gg){
var z=gz$gwx_XC_11_1()
var o2C=_mz(z,'van-cell',['arrowDirection',0,'border',1,'center',1,'clickable',2,'customClass',3,'customStyle',4,'icon',5,'isLink',6,'required',7,'size',8,'title',9,'titleWidth',10],[],e,s,gg)
var o4C=_mz(z,'slot',['name',12,'slot',1],[],e,s,gg)
_(o2C,o4C)
var f5C=_mz(z,'slot',['name',14,'slot',1],[],e,s,gg)
_(o2C,f5C)
var c6C=_n('view')
_rz(z,c6C,'class',16,e,s,gg)
var h7C=_v()
_(c6C,h7C)
if(_oz(z,17,e,s,gg)){h7C.wxVkey=1
var o8C=_mz(z,'van-icon',['catch:touchstart',18,'class',1,'name',2,'size',3],[],e,s,gg)
_(h7C,o8C)
}
var c9C=_mz(z,'view',['bind:tap',22,'class',1],[],e,s,gg)
var o0C=_v()
_(c9C,o0C)
if(_oz(z,24,e,s,gg)){o0C.wxVkey=1
var lAD=_mz(z,'van-icon',['class',25,'customClass',1,'name',2,'size',3],[],e,s,gg)
_(o0C,lAD)
}
var aBD=_n('slot')
_rz(z,aBD,'name',29,e,s,gg)
_(c9C,aBD)
var tCD=_n('slot')
_rz(z,tCD,'name',30,e,s,gg)
_(c9C,tCD)
o0C.wxXCkey=1
o0C.wxXCkey=3
_(c6C,c9C)
var eDD=_n('slot')
_rz(z,eDD,'name',31,e,s,gg)
_(c6C,eDD)
h7C.wxXCkey=1
h7C.wxXCkey=3
_(o2C,c6C)
var x3C=_v()
_(o2C,x3C)
if(_oz(z,32,e,s,gg)){x3C.wxVkey=1
}
x3C.wxXCkey=1
_(r,o2C)
return r
}
e_[x[0]]={f:m0,j:[],i:[],ti:[],ic:[]}
if(path&&e_[path]){
return function(env,dd,global){$gwxc=0;var root={"tag":"wx-page"};root.children=[]
;g="$gwx_XC_11";var main=e_[path].f
if (typeof global==="undefined")global={};global.f=$gdc(f_[path],"",1);
try{
main(env,{},root,global);
_tsd(root)
}catch(err){
console.log(err)
}
;g="";
return root;
}
}
}
}(__g.a,__g.b,__g.c,__g.d,__g.e,__g.f,__g.g,__g.h,__g.i,__g.j,__g.k,__g.l,__g.m,__g.n,__g.o,__g.p,__g.q,__g.r,__g.s,__g.t,__g.u,__g.v,__g.w,__g.x,__g.y,__g.z,__g.A,__g.B,__g.C,__g.D,__g.E,__g.F,__g.G,__g.H,__g.I,__g.J,__g.K,__g.L,__g.M,__g.N,__g.O,__g.P,__g.Q,__g.R,__g.S,__g.T,__g.U,__g.V,__g.W,__g.X,__g.Y,__g.Z,__g.aa);if(__vd_version_info__.delayedGwx||false)$gwx_XC_11();	if (__vd_version_info__.delayedGwx) __wxAppCode__['components/vant/field/index.wxml'] = [$gwx_XC_11, './components/vant/field/index.wxml'];else __wxAppCode__['components/vant/field/index.wxml'] = $gwx_XC_11( './components/vant/field/index.wxml' );
	;__wxRoute = "components/vant/field/index";__wxRouteBegin = true;__wxAppCurrentFile__="components/vant/field/index.js";define("components/vant/field/index.js",function(require,module,exports,window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){
"use strict";Object.defineProperty(exports,"__esModule",{value:!0});var e=require("../common/component"),t=require("../common/utils");e.VantComponent({field:!0,classes:["input-class","right-icon-class"],props:{size:String,icon:String,label:String,error:Boolean,fixed:Boolean,focus:Boolean,center:Boolean,isLink:Boolean,leftIcon:String,rightIcon:String,disabled:Boolean,autosize:Boolean,readonly:Boolean,required:Boolean,password:Boolean,iconClass:String,clearable:Boolean,clickable:Boolean,inputAlign:String,placeholder:String,customStyle:String,confirmType:String,confirmHold:Boolean,holdKeyboard:Boolean,errorMessage:String,arrowDirection:String,placeholderStyle:String,errorMessageAlign:String,selectionEnd:{type:Number,value:-1},selectionStart:{type:Number,value:-1},showConfirmBar:{type:Boolean,value:!0},adjustPosition:{type:Boolean,value:!0},cursorSpacing:{type:Number,value:50},maxlength:{type:Number,value:-1},type:{type:String,value:"text"},border:{type:Boolean,value:!0},titleWidth:{type:String,value:"90px"}},data:{focused:!1,system:t.getSystemInfoSync().system.split(" ").shift().toLowerCase()},methods:{onInput:function(e){var t=this,o=(e.detail||{}).value,n=void 0===o?"":o;this.setData({value:n}),wx.nextTick((function(){t.emitChange(n)}))},onFocus:function(e){this.setData({focused:!0}),this.$emit("focus",e.detail)},onBlur:function(e){this.setData({focused:!1}),this.$emit("blur",e.detail)},onClickIcon:function(){this.$emit("click-icon")},onClear:function(){var e=this;this.setData({value:""}),wx.nextTick((function(){e.emitChange(""),e.$emit("clear","")}))},onConfirm:function(){this.$emit("confirm",this.data.value)},emitChange:function(e){this.$emit("input",e),this.$emit("change",e)},noop:function(){}}});
},{isPage:false,isComponent:true,currentFile:'components/vant/field/index.js'});require("components/vant/field/index.js");$gwx_XC_12=function(_,_v,_n,_p,_s,_wp,_wl,$gwn,$gwl,$gwh,wh,$gstack,$gwrt,gra,grb,TestTest,wfor,_ca,_da,_r,_rz,_o,_oz,_1,_1z,_2,_2z,_m,_mz,nv_getDate,nv_getRegExp,nv_console,nv_parseInt,nv_parseFloat,nv_isNaN,nv_isFinite,nv_decodeURI,nv_decodeURIComponent,nv_encodeURI,nv_encodeURIComponent,$gdc,nv_JSON,_af,_gv,_ai,_grp,_gd,_gapi,$ixc,_ic,_w,_ev,_tsd){return function(path,global){
if(typeof global==='undefined'){if (typeof __GWX_GLOBAL__==='undefined')global={};else global=__GWX_GLOBAL__;}if(typeof __WXML_GLOBAL__ === 'undefined') {__WXML_GLOBAL__={};
}__WXML_GLOBAL__.modules = __WXML_GLOBAL__.modules || {};
var e_={}
if(typeof(global.entrys)==='undefined')global.entrys={};e_=global.entrys;
var d_={}
if(typeof(global.defines)==='undefined')global.defines={};d_=global.defines;
var f_={}
if(typeof(global.modules)==='undefined')global.modules={};f_=global.modules || {};
var p_={}
__WXML_GLOBAL__.ops_cached = __WXML_GLOBAL__.ops_cached || {}
__WXML_GLOBAL__.ops_set = __WXML_GLOBAL__.ops_set || {};
__WXML_GLOBAL__.ops_init = __WXML_GLOBAL__.ops_init || {};
var z=__WXML_GLOBAL__.ops_set.$gwx_XC_12 || [];
function gz$gwx_XC_12_1(){
if( __WXML_GLOBAL__.ops_cached.$gwx_XC_12_1)return __WXML_GLOBAL__.ops_cached.$gwx_XC_12_1
__WXML_GLOBAL__.ops_cached.$gwx_XC_12_1=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
Z([[7],[3,'appParameter']])
Z([3,'onClick'])
Z([3,'bindContact'])
Z([3,'bindError'])
Z([3,'bindGetPhoneNumber'])
Z([3,'bindGetUserInfo'])
Z([3,'bindLaunchApp'])
Z([3,'bindOpenSetting'])
Z([[7],[3,'businessId']])
Z([[12],[[6],[[7],[3,'utils']],[3,'bem']],[[5],[[5],[1,'goods-action-button']],[[4],[[5],[[5],[[7],[3,'type']]],[[9],[[9],[[8],'first',[[7],[3,'isFirst']]],[[8],'last',[[7],[3,'isLast']]]],[[8],'plain',[[7],[3,'plain']]]]]]]])
Z([[7],[3,'color']])
Z([3,'van-goods-action-button__inner'])
Z([[7],[3,'disabled']])
Z([[7],[3,'id']])
Z([[7],[3,'lang']])
Z([[7],[3,'loading']])
Z([[7],[3,'openType']])
Z([[7],[3,'plain']])
Z([[7],[3,'sendMessageImg']])
Z([[7],[3,'sendMessagePath']])
Z([[7],[3,'sendMessageTitle']])
Z([[7],[3,'sessionFrom']])
Z([[7],[3,'showMessageCard']])
Z([[7],[3,'type']])
})(__WXML_GLOBAL__.ops_cached.$gwx_XC_12_1);return __WXML_GLOBAL__.ops_cached.$gwx_XC_12_1
}
__WXML_GLOBAL__.ops_set.$gwx_XC_12=z;
__WXML_GLOBAL__.ops_init.$gwx_XC_12=true;
var x=['./components/vant/goods-action-button/index.wxml'];d_[x[0]]={}
var m0=function(e,s,r,gg){
var z=gz$gwx_XC_12_1()
var oFD=_mz(z,'van-button',['appParameter',0,'bind:click',1,'bindcontact',1,'binderror',2,'bindgetphonenumber',3,'bindgetuserinfo',4,'bindlaunchapp',5,'bindopensetting',6,'businessId',7,'class',8,'color',9,'customClass',10,'disabled',11,'id',12,'lang',13,'loading',14,'openType',15,'plain',16,'sendMessageImg',17,'sendMessagePath',18,'sendMessageTitle',19,'sessionFrom',20,'showMessageCard',21,'type',22],[],e,s,gg)
var xGD=_n('slot')
_(oFD,xGD)
_(r,oFD)
return r
}
e_[x[0]]={f:m0,j:[],i:[],ti:[],ic:[]}
if(path&&e_[path]){
return function(env,dd,global){$gwxc=0;var root={"tag":"wx-page"};root.children=[]
;g="$gwx_XC_12";var main=e_[path].f
if (typeof global==="undefined")global={};global.f=$gdc(f_[path],"",1);
try{
main(env,{},root,global);
_tsd(root)
}catch(err){
console.log(err)
}
;g="";
return root;
}
}
}
}(__g.a,__g.b,__g.c,__g.d,__g.e,__g.f,__g.g,__g.h,__g.i,__g.j,__g.k,__g.l,__g.m,__g.n,__g.o,__g.p,__g.q,__g.r,__g.s,__g.t,__g.u,__g.v,__g.w,__g.x,__g.y,__g.z,__g.A,__g.B,__g.C,__g.D,__g.E,__g.F,__g.G,__g.H,__g.I,__g.J,__g.K,__g.L,__g.M,__g.N,__g.O,__g.P,__g.Q,__g.R,__g.S,__g.T,__g.U,__g.V,__g.W,__g.X,__g.Y,__g.Z,__g.aa);if(__vd_version_info__.delayedGwx||false)$gwx_XC_12();	if (__vd_version_info__.delayedGwx) __wxAppCode__['components/vant/goods-action-button/index.wxml'] = [$gwx_XC_12, './components/vant/goods-action-button/index.wxml'];else __wxAppCode__['components/vant/goods-action-button/index.wxml'] = $gwx_XC_12( './components/vant/goods-action-button/index.wxml' );
	;__wxRoute = "components/vant/goods-action-button/index";__wxRouteBegin = true;__wxAppCurrentFile__="components/vant/goods-action-button/index.js";define("components/vant/goods-action-button/index.js",function(require,module,exports,window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){
"use strict";Object.defineProperty(exports,"__esModule",{value:!0});var e=require("../common/component"),t=require("../mixins/link"),i=require("../mixins/button"),n=require("../mixins/open-type");e.VantComponent({mixins:[t.link,i.button,n.openType],relation:{type:"ancestor",name:"goods-action",current:"goods-action-button"},props:{text:String,color:String,loading:Boolean,disabled:Boolean,plain:Boolean,type:{type:String,value:"danger"}},methods:{onClick:function(e){this.$emit("click",e.detail),this.jumpLink()},updateStyle:function(){if(null!=this.parent){var e=this.parent.children,t=void 0===e?[]:e,i=t.length,n=t.indexOf(this);this.setData({isFirst:0===n,isLast:n===i-1})}}}});
},{isPage:false,isComponent:true,currentFile:'components/vant/goods-action-button/index.js'});require("components/vant/goods-action-button/index.js");$gwx_XC_13=function(_,_v,_n,_p,_s,_wp,_wl,$gwn,$gwl,$gwh,wh,$gstack,$gwrt,gra,grb,TestTest,wfor,_ca,_da,_r,_rz,_o,_oz,_1,_1z,_2,_2z,_m,_mz,nv_getDate,nv_getRegExp,nv_console,nv_parseInt,nv_parseFloat,nv_isNaN,nv_isFinite,nv_decodeURI,nv_decodeURIComponent,nv_encodeURI,nv_encodeURIComponent,$gdc,nv_JSON,_af,_gv,_ai,_grp,_gd,_gapi,$ixc,_ic,_w,_ev,_tsd){return function(path,global){
if(typeof global==='undefined'){if (typeof __GWX_GLOBAL__==='undefined')global={};else global=__GWX_GLOBAL__;}if(typeof __WXML_GLOBAL__ === 'undefined') {__WXML_GLOBAL__={};
}__WXML_GLOBAL__.modules = __WXML_GLOBAL__.modules || {};
var e_={}
if(typeof(global.entrys)==='undefined')global.entrys={};e_=global.entrys;
var d_={}
if(typeof(global.defines)==='undefined')global.defines={};d_=global.defines;
var f_={}
if(typeof(global.modules)==='undefined')global.modules={};f_=global.modules || {};
var p_={}
__WXML_GLOBAL__.ops_cached = __WXML_GLOBAL__.ops_cached || {}
__WXML_GLOBAL__.ops_set = __WXML_GLOBAL__.ops_set || {};
__WXML_GLOBAL__.ops_init = __WXML_GLOBAL__.ops_init || {};
var z=__WXML_GLOBAL__.ops_set.$gwx_XC_13 || [];
function gz$gwx_XC_13_1(){
if( __WXML_GLOBAL__.ops_cached.$gwx_XC_13_1)return __WXML_GLOBAL__.ops_cached.$gwx_XC_13_1
__WXML_GLOBAL__.ops_cached.$gwx_XC_13_1=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
})(__WXML_GLOBAL__.ops_cached.$gwx_XC_13_1);return __WXML_GLOBAL__.ops_cached.$gwx_XC_13_1
}
__WXML_GLOBAL__.ops_set.$gwx_XC_13=z;
__WXML_GLOBAL__.ops_init.$gwx_XC_13=true;
var x=['./components/vant/goods-action/index.wxml'];d_[x[0]]={}
var m0=function(e,s,r,gg){
var z=gz$gwx_XC_13_1()
var fID=_n('slot')
_(r,fID)
return r
}
e_[x[0]]={f:m0,j:[],i:[],ti:[],ic:[]}
if(path&&e_[path]){
return function(env,dd,global){$gwxc=0;var root={"tag":"wx-page"};root.children=[]
;g="$gwx_XC_13";var main=e_[path].f
if (typeof global==="undefined")global={};global.f=$gdc(f_[path],"",1);
try{
main(env,{},root,global);
_tsd(root)
}catch(err){
console.log(err)
}
;g="";
return root;
}
}
}
}(__g.a,__g.b,__g.c,__g.d,__g.e,__g.f,__g.g,__g.h,__g.i,__g.j,__g.k,__g.l,__g.m,__g.n,__g.o,__g.p,__g.q,__g.r,__g.s,__g.t,__g.u,__g.v,__g.w,__g.x,__g.y,__g.z,__g.A,__g.B,__g.C,__g.D,__g.E,__g.F,__g.G,__g.H,__g.I,__g.J,__g.K,__g.L,__g.M,__g.N,__g.O,__g.P,__g.Q,__g.R,__g.S,__g.T,__g.U,__g.V,__g.W,__g.X,__g.Y,__g.Z,__g.aa);if(__vd_version_info__.delayedGwx||false)$gwx_XC_13();	if (__vd_version_info__.delayedGwx) __wxAppCode__['components/vant/goods-action/index.wxml'] = [$gwx_XC_13, './components/vant/goods-action/index.wxml'];else __wxAppCode__['components/vant/goods-action/index.wxml'] = $gwx_XC_13( './components/vant/goods-action/index.wxml' );
	;__wxRoute = "components/vant/goods-action/index";__wxRouteBegin = true;__wxAppCurrentFile__="components/vant/goods-action/index.js";define("components/vant/goods-action/index.js",function(require,module,exports,window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){
"use strict";Object.defineProperty(exports,"__esModule",{value:!0}),require("../common/component").VantComponent({relation:{type:"descendant",name:"goods-action-button",current:"goods-action",linked:function(){this.updateStyle()},unlinked:function(){this.updateStyle()},linkChanged:function(){this.updateStyle()}},props:{safeAreaInsetBottom:{type:Boolean,value:!0}},methods:{updateStyle:function(){var t=this;wx.nextTick((function(){t.children.forEach((function(t){t.updateStyle()}))}))}}});
},{isPage:false,isComponent:true,currentFile:'components/vant/goods-action/index.js'});require("components/vant/goods-action/index.js");$gwx_XC_14=function(_,_v,_n,_p,_s,_wp,_wl,$gwn,$gwl,$gwh,wh,$gstack,$gwrt,gra,grb,TestTest,wfor,_ca,_da,_r,_rz,_o,_oz,_1,_1z,_2,_2z,_m,_mz,nv_getDate,nv_getRegExp,nv_console,nv_parseInt,nv_parseFloat,nv_isNaN,nv_isFinite,nv_decodeURI,nv_decodeURIComponent,nv_encodeURI,nv_encodeURIComponent,$gdc,nv_JSON,_af,_gv,_ai,_grp,_gd,_gapi,$ixc,_ic,_w,_ev,_tsd){return function(path,global){
if(typeof global==='undefined'){if (typeof __GWX_GLOBAL__==='undefined')global={};else global=__GWX_GLOBAL__;}if(typeof __WXML_GLOBAL__ === 'undefined') {__WXML_GLOBAL__={};
}__WXML_GLOBAL__.modules = __WXML_GLOBAL__.modules || {};
var e_={}
if(typeof(global.entrys)==='undefined')global.entrys={};e_=global.entrys;
var d_={}
if(typeof(global.defines)==='undefined')global.defines={};d_=global.defines;
var f_={}
if(typeof(global.modules)==='undefined')global.modules={};f_=global.modules || {};
var p_={}
__WXML_GLOBAL__.ops_cached = __WXML_GLOBAL__.ops_cached || {}
__WXML_GLOBAL__.ops_set = __WXML_GLOBAL__.ops_set || {};
__WXML_GLOBAL__.ops_init = __WXML_GLOBAL__.ops_init || {};
var z=__WXML_GLOBAL__.ops_set.$gwx_XC_14 || [];
function gz$gwx_XC_14_1(){
if( __WXML_GLOBAL__.ops_cached.$gwx_XC_14_1)return __WXML_GLOBAL__.ops_cached.$gwx_XC_14_1
__WXML_GLOBAL__.ops_cached.$gwx_XC_14_1=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
Z([3,'onClick'])
Z([a,[3,'custom-class '],[[7],[3,'classPrefix']],[3,' '],[[2,'?:'],[[7],[3,'isImageName']],[1,'van-icon--image'],[[2,'+'],[[2,'+'],[[7],[3,'classPrefix']],[1,'-']],[[7],[3,'name']]]]])
Z([a,[3,'color: '],[[7],[3,'color']],[3,';font-size: '],[[12],[[6],[[7],[3,'utils']],[3,'addUnit']],[[5],[[7],[3,'size']]]],[3,';'],[[7],[3,'customStyle']]])
Z([[2,'||'],[[2,'!=='],[[7],[3,'info']],[1,null]],[[7],[3,'dot']]])
Z([3,'van-icon__info'])
Z([[7],[3,'dot']])
Z([[7],[3,'info']])
Z([[7],[3,'isImageName']])
})(__WXML_GLOBAL__.ops_cached.$gwx_XC_14_1);return __WXML_GLOBAL__.ops_cached.$gwx_XC_14_1
}
__WXML_GLOBAL__.ops_set.$gwx_XC_14=z;
__WXML_GLOBAL__.ops_init.$gwx_XC_14=true;
var x=['./components/vant/icon/index.wxml'];d_[x[0]]={}
var m0=function(e,s,r,gg){
var z=gz$gwx_XC_14_1()
var hKD=_mz(z,'view',['bind:tap',0,'class',1,'style',1],[],e,s,gg)
var oLD=_v()
_(hKD,oLD)
if(_oz(z,3,e,s,gg)){oLD.wxVkey=1
var oND=_mz(z,'van-info',['customClass',4,'dot',1,'info',2],[],e,s,gg)
_(oLD,oND)
}
var cMD=_v()
_(hKD,cMD)
if(_oz(z,7,e,s,gg)){cMD.wxVkey=1
}
oLD.wxXCkey=1
oLD.wxXCkey=3
cMD.wxXCkey=1
_(r,hKD)
return r
}
e_[x[0]]={f:m0,j:[],i:[],ti:[],ic:[]}
if(path&&e_[path]){
return function(env,dd,global){$gwxc=0;var root={"tag":"wx-page"};root.children=[]
;g="$gwx_XC_14";var main=e_[path].f
if (typeof global==="undefined")global={};global.f=$gdc(f_[path],"",1);
try{
main(env,{},root,global);
_tsd(root)
}catch(err){
console.log(err)
}
;g="";
return root;
}
}
}
}(__g.a,__g.b,__g.c,__g.d,__g.e,__g.f,__g.g,__g.h,__g.i,__g.j,__g.k,__g.l,__g.m,__g.n,__g.o,__g.p,__g.q,__g.r,__g.s,__g.t,__g.u,__g.v,__g.w,__g.x,__g.y,__g.z,__g.A,__g.B,__g.C,__g.D,__g.E,__g.F,__g.G,__g.H,__g.I,__g.J,__g.K,__g.L,__g.M,__g.N,__g.O,__g.P,__g.Q,__g.R,__g.S,__g.T,__g.U,__g.V,__g.W,__g.X,__g.Y,__g.Z,__g.aa);if(__vd_version_info__.delayedGwx||false)$gwx_XC_14();	if (__vd_version_info__.delayedGwx) __wxAppCode__['components/vant/icon/index.wxml'] = [$gwx_XC_14, './components/vant/icon/index.wxml'];else __wxAppCode__['components/vant/icon/index.wxml'] = $gwx_XC_14( './components/vant/icon/index.wxml' );
	;__wxRoute = "components/vant/icon/index";__wxRouteBegin = true;__wxAppCurrentFile__="components/vant/icon/index.js";define("components/vant/icon/index.js",function(require,module,exports,window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){
"use strict";Object.defineProperty(exports,"__esModule",{value:!0}),require("../common/component").VantComponent({props:{dot:Boolean,info:null,size:null,color:String,customStyle:String,classPrefix:{type:String,value:"van-icon"},name:{type:String,observer:function(e){this.setData({isImageName:-1!==e.indexOf("/")})}}},methods:{onClick:function(){this.$emit("click")}}});
},{isPage:false,isComponent:true,currentFile:'components/vant/icon/index.js'});require("components/vant/icon/index.js");$gwx_XC_15=function(_,_v,_n,_p,_s,_wp,_wl,$gwn,$gwl,$gwh,wh,$gstack,$gwrt,gra,grb,TestTest,wfor,_ca,_da,_r,_rz,_o,_oz,_1,_1z,_2,_2z,_m,_mz,nv_getDate,nv_getRegExp,nv_console,nv_parseInt,nv_parseFloat,nv_isNaN,nv_isFinite,nv_decodeURI,nv_decodeURIComponent,nv_encodeURI,nv_encodeURIComponent,$gdc,nv_JSON,_af,_gv,_ai,_grp,_gd,_gapi,$ixc,_ic,_w,_ev,_tsd){return function(path,global){
if(typeof global==='undefined'){if (typeof __GWX_GLOBAL__==='undefined')global={};else global=__GWX_GLOBAL__;}if(typeof __WXML_GLOBAL__ === 'undefined') {__WXML_GLOBAL__={};
}__WXML_GLOBAL__.modules = __WXML_GLOBAL__.modules || {};
var e_={}
if(typeof(global.entrys)==='undefined')global.entrys={};e_=global.entrys;
var d_={}
if(typeof(global.defines)==='undefined')global.defines={};d_=global.defines;
var f_={}
if(typeof(global.modules)==='undefined')global.modules={};f_=global.modules || {};
var p_={}
__WXML_GLOBAL__.ops_cached = __WXML_GLOBAL__.ops_cached || {}
__WXML_GLOBAL__.ops_set = __WXML_GLOBAL__.ops_set || {};
__WXML_GLOBAL__.ops_init = __WXML_GLOBAL__.ops_init || {};
var z=__WXML_GLOBAL__.ops_set.$gwx_XC_15 || [];
function gz$gwx_XC_15_1(){
if( __WXML_GLOBAL__.ops_cached.$gwx_XC_15_1)return __WXML_GLOBAL__.ops_cached.$gwx_XC_15_1
__WXML_GLOBAL__.ops_cached.$gwx_XC_15_1=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
Z([[2,'||'],[[2,'&&'],[[2,'!=='],[[7],[3,'info']],[1,null]],[[2,'!=='],[[7],[3,'info']],[1,'']]],[[7],[3,'dot']]])
})(__WXML_GLOBAL__.ops_cached.$gwx_XC_15_1);return __WXML_GLOBAL__.ops_cached.$gwx_XC_15_1
}
__WXML_GLOBAL__.ops_set.$gwx_XC_15=z;
__WXML_GLOBAL__.ops_init.$gwx_XC_15=true;
var x=['./components/vant/info/index.wxml'];d_[x[0]]={}
var m0=function(e,s,r,gg){
var z=gz$gwx_XC_15_1()
var aPD=_v()
_(r,aPD)
if(_oz(z,0,e,s,gg)){aPD.wxVkey=1
}
aPD.wxXCkey=1
return r
}
e_[x[0]]={f:m0,j:[],i:[],ti:[],ic:[]}
if(path&&e_[path]){
return function(env,dd,global){$gwxc=0;var root={"tag":"wx-page"};root.children=[]
;g="$gwx_XC_15";var main=e_[path].f
if (typeof global==="undefined")global={};global.f=$gdc(f_[path],"",1);
try{
main(env,{},root,global);
_tsd(root)
}catch(err){
console.log(err)
}
;g="";
return root;
}
}
}
}(__g.a,__g.b,__g.c,__g.d,__g.e,__g.f,__g.g,__g.h,__g.i,__g.j,__g.k,__g.l,__g.m,__g.n,__g.o,__g.p,__g.q,__g.r,__g.s,__g.t,__g.u,__g.v,__g.w,__g.x,__g.y,__g.z,__g.A,__g.B,__g.C,__g.D,__g.E,__g.F,__g.G,__g.H,__g.I,__g.J,__g.K,__g.L,__g.M,__g.N,__g.O,__g.P,__g.Q,__g.R,__g.S,__g.T,__g.U,__g.V,__g.W,__g.X,__g.Y,__g.Z,__g.aa);if(__vd_version_info__.delayedGwx||false)$gwx_XC_15();	if (__vd_version_info__.delayedGwx) __wxAppCode__['components/vant/info/index.wxml'] = [$gwx_XC_15, './components/vant/info/index.wxml'];else __wxAppCode__['components/vant/info/index.wxml'] = $gwx_XC_15( './components/vant/info/index.wxml' );
	;__wxRoute = "components/vant/info/index";__wxRouteBegin = true;__wxAppCurrentFile__="components/vant/info/index.js";define("components/vant/info/index.js",function(require,module,exports,window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){
"use strict";Object.defineProperty(exports,"__esModule",{value:!0}),require("../common/component").VantComponent({props:{dot:Boolean,info:null,customStyle:String}});
},{isPage:false,isComponent:true,currentFile:'components/vant/info/index.js'});require("components/vant/info/index.js");$gwx_XC_16=function(_,_v,_n,_p,_s,_wp,_wl,$gwn,$gwl,$gwh,wh,$gstack,$gwrt,gra,grb,TestTest,wfor,_ca,_da,_r,_rz,_o,_oz,_1,_1z,_2,_2z,_m,_mz,nv_getDate,nv_getRegExp,nv_console,nv_parseInt,nv_parseFloat,nv_isNaN,nv_isFinite,nv_decodeURI,nv_decodeURIComponent,nv_encodeURI,nv_encodeURIComponent,$gdc,nv_JSON,_af,_gv,_ai,_grp,_gd,_gapi,$ixc,_ic,_w,_ev,_tsd){return function(path,global){
if(typeof global==='undefined'){if (typeof __GWX_GLOBAL__==='undefined')global={};else global=__GWX_GLOBAL__;}if(typeof __WXML_GLOBAL__ === 'undefined') {__WXML_GLOBAL__={};
}__WXML_GLOBAL__.modules = __WXML_GLOBAL__.modules || {};
var e_={}
if(typeof(global.entrys)==='undefined')global.entrys={};e_=global.entrys;
var d_={}
if(typeof(global.defines)==='undefined')global.defines={};d_=global.defines;
var f_={}
if(typeof(global.modules)==='undefined')global.modules={};f_=global.modules || {};
var p_={}
__WXML_GLOBAL__.ops_cached = __WXML_GLOBAL__.ops_cached || {}
__WXML_GLOBAL__.ops_set = __WXML_GLOBAL__.ops_set || {};
__WXML_GLOBAL__.ops_init = __WXML_GLOBAL__.ops_init || {};
var z=__WXML_GLOBAL__.ops_set.$gwx_XC_16 || [];
function gz$gwx_XC_16_1(){
if( __WXML_GLOBAL__.ops_cached.$gwx_XC_16_1)return __WXML_GLOBAL__.ops_cached.$gwx_XC_16_1
__WXML_GLOBAL__.ops_cached.$gwx_XC_16_1=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
Z([a,[3,'custom-class van-loading '],[[2,'?:'],[[7],[3,'vertical']],[1,'van-loading--vertical'],[1,'']]])
Z([3,'item in 12'])
Z([3,'index'])
Z([[2,'==='],[[7],[3,'type']],[1,'spinner']])
})(__WXML_GLOBAL__.ops_cached.$gwx_XC_16_1);return __WXML_GLOBAL__.ops_cached.$gwx_XC_16_1
}
__WXML_GLOBAL__.ops_set.$gwx_XC_16=z;
__WXML_GLOBAL__.ops_init.$gwx_XC_16=true;
var x=['./components/vant/loading/index.wxml'];d_[x[0]]={}
var m0=function(e,s,r,gg){
var z=gz$gwx_XC_16_1()
var eRD=_n('view')
_rz(z,eRD,'class',0,e,s,gg)
var bSD=_v()
_(eRD,bSD)
var oTD=function(oVD,xUD,fWD,gg){
var hYD=_v()
_(fWD,hYD)
if(_oz(z,3,oVD,xUD,gg)){hYD.wxVkey=1
}
hYD.wxXCkey=1
return fWD
}
bSD.wxXCkey=2
_2z(z,1,oTD,e,s,gg,bSD,'item','index','index')
var oZD=_n('slot')
_(eRD,oZD)
_(r,eRD)
return r
}
e_[x[0]]={f:m0,j:[],i:[],ti:[],ic:[]}
if(path&&e_[path]){
return function(env,dd,global){$gwxc=0;var root={"tag":"wx-page"};root.children=[]
;g="$gwx_XC_16";var main=e_[path].f
if (typeof global==="undefined")global={};global.f=$gdc(f_[path],"",1);
try{
main(env,{},root,global);
_tsd(root)
}catch(err){
console.log(err)
}
;g="";
return root;
}
}
}
}(__g.a,__g.b,__g.c,__g.d,__g.e,__g.f,__g.g,__g.h,__g.i,__g.j,__g.k,__g.l,__g.m,__g.n,__g.o,__g.p,__g.q,__g.r,__g.s,__g.t,__g.u,__g.v,__g.w,__g.x,__g.y,__g.z,__g.A,__g.B,__g.C,__g.D,__g.E,__g.F,__g.G,__g.H,__g.I,__g.J,__g.K,__g.L,__g.M,__g.N,__g.O,__g.P,__g.Q,__g.R,__g.S,__g.T,__g.U,__g.V,__g.W,__g.X,__g.Y,__g.Z,__g.aa);if(__vd_version_info__.delayedGwx||false)$gwx_XC_16();	if (__vd_version_info__.delayedGwx) __wxAppCode__['components/vant/loading/index.wxml'] = [$gwx_XC_16, './components/vant/loading/index.wxml'];else __wxAppCode__['components/vant/loading/index.wxml'] = $gwx_XC_16( './components/vant/loading/index.wxml' );
	;__wxRoute = "components/vant/loading/index";__wxRouteBegin = true;__wxAppCurrentFile__="components/vant/loading/index.js";define("components/vant/loading/index.js",function(require,module,exports,window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){
"use strict";Object.defineProperty(exports,"__esModule",{value:!0}),require("../common/component").VantComponent({props:{color:String,vertical:Boolean,type:{type:String,value:"circular"},size:String,textSize:String}});
},{isPage:false,isComponent:true,currentFile:'components/vant/loading/index.js'});require("components/vant/loading/index.js");$gwx_XC_17=function(_,_v,_n,_p,_s,_wp,_wl,$gwn,$gwl,$gwh,wh,$gstack,$gwrt,gra,grb,TestTest,wfor,_ca,_da,_r,_rz,_o,_oz,_1,_1z,_2,_2z,_m,_mz,nv_getDate,nv_getRegExp,nv_console,nv_parseInt,nv_parseFloat,nv_isNaN,nv_isFinite,nv_decodeURI,nv_decodeURIComponent,nv_encodeURI,nv_encodeURIComponent,$gdc,nv_JSON,_af,_gv,_ai,_grp,_gd,_gapi,$ixc,_ic,_w,_ev,_tsd){return function(path,global){
if(typeof global==='undefined'){if (typeof __GWX_GLOBAL__==='undefined')global={};else global=__GWX_GLOBAL__;}if(typeof __WXML_GLOBAL__ === 'undefined') {__WXML_GLOBAL__={};
}__WXML_GLOBAL__.modules = __WXML_GLOBAL__.modules || {};
var e_={}
if(typeof(global.entrys)==='undefined')global.entrys={};e_=global.entrys;
var d_={}
if(typeof(global.defines)==='undefined')global.defines={};d_=global.defines;
var f_={}
if(typeof(global.modules)==='undefined')global.modules={};f_=global.modules || {};
var p_={}
__WXML_GLOBAL__.ops_cached = __WXML_GLOBAL__.ops_cached || {}
__WXML_GLOBAL__.ops_set = __WXML_GLOBAL__.ops_set || {};
__WXML_GLOBAL__.ops_init = __WXML_GLOBAL__.ops_init || {};
var z=__WXML_GLOBAL__.ops_set.$gwx_XC_17 || [];
function gz$gwx_XC_17_1(){
if( __WXML_GLOBAL__.ops_cached.$gwx_XC_17_1)return __WXML_GLOBAL__.ops_cached.$gwx_XC_17_1
__WXML_GLOBAL__.ops_cached.$gwx_XC_17_1=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
Z([[7],[3,'show']])
Z([3,'onClick'])
Z([a,[3,'custom-class '],[[12],[[6],[[7],[3,'utils']],[3,'bem']],[[5],[[5],[1,'notice-bar']],[[9],[[8],'withicon',[[7],[3,'mode']]],[[8],'wrapable',[[7],[3,'wrapable']]]]]]])
Z([a,[3,'color: '],[[7],[3,'color']],[3,'; background-color: '],[[7],[3,'backgroundColor']],[3,'; background: '],[[7],[3,'background']]])
Z([[7],[3,'leftIcon']])
Z([3,'van-notice-bar__left-icon'])
Z(z[4])
Z([3,'16px'])
Z([3,'left-icon'])
Z([[2,'==='],[[7],[3,'mode']],[1,'closeable']])
Z([3,'onClickIcon'])
Z([3,'van-notice-bar__right-icon'])
Z([3,'cross'])
Z([[2,'==='],[[7],[3,'mode']],[1,'link']])
Z(z[11])
Z([3,'arrow'])
Z([3,'right-icon'])
})(__WXML_GLOBAL__.ops_cached.$gwx_XC_17_1);return __WXML_GLOBAL__.ops_cached.$gwx_XC_17_1
}
__WXML_GLOBAL__.ops_set.$gwx_XC_17=z;
__WXML_GLOBAL__.ops_init.$gwx_XC_17=true;
var x=['./components/vant/notice-bar/index.wxml'];d_[x[0]]={}
var m0=function(e,s,r,gg){
var z=gz$gwx_XC_17_1()
var o2D=_v()
_(r,o2D)
if(_oz(z,0,e,s,gg)){o2D.wxVkey=1
var l3D=_mz(z,'view',['bind:tap',1,'class',1,'style',2],[],e,s,gg)
var a4D=_v()
_(l3D,a4D)
if(_oz(z,4,e,s,gg)){a4D.wxVkey=1
var e6D=_mz(z,'van-icon',['class',5,'name',1,'size',2],[],e,s,gg)
_(a4D,e6D)
}
else{a4D.wxVkey=2
var b7D=_n('slot')
_rz(z,b7D,'name',8,e,s,gg)
_(a4D,b7D)
}
var t5D=_v()
_(l3D,t5D)
if(_oz(z,9,e,s,gg)){t5D.wxVkey=1
var o8D=_mz(z,'van-icon',['catch:tap',10,'class',1,'name',2],[],e,s,gg)
_(t5D,o8D)
}
else if(_oz(z,13,e,s,gg)){t5D.wxVkey=2
var x9D=_mz(z,'van-icon',['class',14,'name',1],[],e,s,gg)
_(t5D,x9D)
}
else{t5D.wxVkey=3
var o0D=_n('slot')
_rz(z,o0D,'name',16,e,s,gg)
_(t5D,o0D)
}
a4D.wxXCkey=1
a4D.wxXCkey=3
t5D.wxXCkey=1
t5D.wxXCkey=3
t5D.wxXCkey=3
_(o2D,l3D)
}
o2D.wxXCkey=1
o2D.wxXCkey=3
return r
}
e_[x[0]]={f:m0,j:[],i:[],ti:[],ic:[]}
if(path&&e_[path]){
return function(env,dd,global){$gwxc=0;var root={"tag":"wx-page"};root.children=[]
;g="$gwx_XC_17";var main=e_[path].f
if (typeof global==="undefined")global={};global.f=$gdc(f_[path],"",1);
try{
main(env,{},root,global);
_tsd(root)
}catch(err){
console.log(err)
}
;g="";
return root;
}
}
}
}(__g.a,__g.b,__g.c,__g.d,__g.e,__g.f,__g.g,__g.h,__g.i,__g.j,__g.k,__g.l,__g.m,__g.n,__g.o,__g.p,__g.q,__g.r,__g.s,__g.t,__g.u,__g.v,__g.w,__g.x,__g.y,__g.z,__g.A,__g.B,__g.C,__g.D,__g.E,__g.F,__g.G,__g.H,__g.I,__g.J,__g.K,__g.L,__g.M,__g.N,__g.O,__g.P,__g.Q,__g.R,__g.S,__g.T,__g.U,__g.V,__g.W,__g.X,__g.Y,__g.Z,__g.aa);if(__vd_version_info__.delayedGwx||false)$gwx_XC_17();	if (__vd_version_info__.delayedGwx) __wxAppCode__['components/vant/notice-bar/index.wxml'] = [$gwx_XC_17, './components/vant/notice-bar/index.wxml'];else __wxAppCode__['components/vant/notice-bar/index.wxml'] = $gwx_XC_17( './components/vant/notice-bar/index.wxml' );
	;__wxRoute = "components/vant/notice-bar/index";__wxRouteBegin = true;__wxAppCurrentFile__="components/vant/notice-bar/index.js";define("components/vant/notice-bar/index.js",function(require,module,exports,window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){
"use strict";Object.defineProperty(exports,"__esModule",{value:!0}),require("../common/component").VantComponent({props:{text:{type:String,value:"",observer:function(){var t=this;wx.nextTick((function(){t.init()}))}},mode:{type:String,value:""},url:{type:String,value:""},openType:{type:String,value:"navigate"},delay:{type:Number,value:1},speed:{type:Number,value:50,observer:function(){var t=this;wx.nextTick((function(){t.init()}))}},scrollable:{type:Boolean,value:!0},leftIcon:{type:String,value:""},color:String,backgroundColor:String,background:String,wrapable:Boolean},data:{show:!0},created:function(){this.resetAnimation=wx.createAnimation({duration:0,timingFunction:"linear"})},destroyed:function(){this.timer&&clearTimeout(this.timer)},methods:{init:function(){var t=this;Promise.all([this.getRect(".van-notice-bar__content"),this.getRect(".van-notice-bar__wrap")]).then((function(i){var e=i[0],n=i[1];if(null!=e&&null!=n&&e.width&&n.width){var a=t.data,o=a.speed,r=a.scrollable,l=a.delay;if(r&&n.width<e.width){var s=e.width/o*1e3;t.wrapWidth=n.width,t.contentWidth=e.width,t.duration=s,t.animation=wx.createAnimation({duration:s,timingFunction:"linear",delay:l}),t.scroll()}}}))},scroll:function(){var t=this;this.timer&&clearTimeout(this.timer),this.timer=null,this.setData({animationData:this.resetAnimation.translateX(this.wrapWidth).step().export()}),setTimeout((function(){t.setData({animationData:t.animation.translateX(-t.contentWidth).step().export()})}),20),this.timer=setTimeout((function(){t.scroll()}),this.duration)},onClickIcon:function(t){"closeable"===this.data.mode&&(this.timer&&clearTimeout(this.timer),this.timer=null,this.setData({show:!1}),this.$emit("close",t.detail))},onClick:function(t){this.$emit("click",t)}}});
},{isPage:false,isComponent:true,currentFile:'components/vant/notice-bar/index.js'});require("components/vant/notice-bar/index.js");$gwx_XC_18=function(_,_v,_n,_p,_s,_wp,_wl,$gwn,$gwl,$gwh,wh,$gstack,$gwrt,gra,grb,TestTest,wfor,_ca,_da,_r,_rz,_o,_oz,_1,_1z,_2,_2z,_m,_mz,nv_getDate,nv_getRegExp,nv_console,nv_parseInt,nv_parseFloat,nv_isNaN,nv_isFinite,nv_decodeURI,nv_decodeURIComponent,nv_encodeURI,nv_encodeURIComponent,$gdc,nv_JSON,_af,_gv,_ai,_grp,_gd,_gapi,$ixc,_ic,_w,_ev,_tsd){return function(path,global){
if(typeof global==='undefined'){if (typeof __GWX_GLOBAL__==='undefined')global={};else global=__GWX_GLOBAL__;}if(typeof __WXML_GLOBAL__ === 'undefined') {__WXML_GLOBAL__={};
}__WXML_GLOBAL__.modules = __WXML_GLOBAL__.modules || {};
var e_={}
if(typeof(global.entrys)==='undefined')global.entrys={};e_=global.entrys;
var d_={}
if(typeof(global.defines)==='undefined')global.defines={};d_=global.defines;
var f_={}
if(typeof(global.modules)==='undefined')global.modules={};f_=global.modules || {};
var p_={}
__WXML_GLOBAL__.ops_cached = __WXML_GLOBAL__.ops_cached || {}
__WXML_GLOBAL__.ops_set = __WXML_GLOBAL__.ops_set || {};
__WXML_GLOBAL__.ops_init = __WXML_GLOBAL__.ops_init || {};
var z=__WXML_GLOBAL__.ops_set.$gwx_XC_18 || [];
function gz$gwx_XC_18_1(){
if( __WXML_GLOBAL__.ops_cached.$gwx_XC_18_1)return __WXML_GLOBAL__.ops_cached.$gwx_XC_18_1
__WXML_GLOBAL__.ops_cached.$gwx_XC_18_1=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
Z([3,'onClick'])
Z([3,'noop'])
Z([3,'van-overlay'])
Z([a,[3,'z-index: '],[[7],[3,'zIndex']],[3,'; '],[[7],[3,'customStyle']]])
Z([[7],[3,'duration']])
Z([[7],[3,'show']])
})(__WXML_GLOBAL__.ops_cached.$gwx_XC_18_1);return __WXML_GLOBAL__.ops_cached.$gwx_XC_18_1
}
__WXML_GLOBAL__.ops_set.$gwx_XC_18=z;
__WXML_GLOBAL__.ops_init.$gwx_XC_18=true;
var x=['./components/vant/overlay/index.wxml'];d_[x[0]]={}
var m0=function(e,s,r,gg){
var z=gz$gwx_XC_18_1()
var cBE=_mz(z,'van-transition',['bind:tap',0,'catch:touchmove',1,'customClass',1,'customStyle',2,'duration',3,'show',4],[],e,s,gg)
var hCE=_n('slot')
_(cBE,hCE)
_(r,cBE)
return r
}
e_[x[0]]={f:m0,j:[],i:[],ti:[],ic:[]}
if(path&&e_[path]){
return function(env,dd,global){$gwxc=0;var root={"tag":"wx-page"};root.children=[]
;g="$gwx_XC_18";var main=e_[path].f
if (typeof global==="undefined")global={};global.f=$gdc(f_[path],"",1);
try{
main(env,{},root,global);
_tsd(root)
}catch(err){
console.log(err)
}
;g="";
return root;
}
}
}
}(__g.a,__g.b,__g.c,__g.d,__g.e,__g.f,__g.g,__g.h,__g.i,__g.j,__g.k,__g.l,__g.m,__g.n,__g.o,__g.p,__g.q,__g.r,__g.s,__g.t,__g.u,__g.v,__g.w,__g.x,__g.y,__g.z,__g.A,__g.B,__g.C,__g.D,__g.E,__g.F,__g.G,__g.H,__g.I,__g.J,__g.K,__g.L,__g.M,__g.N,__g.O,__g.P,__g.Q,__g.R,__g.S,__g.T,__g.U,__g.V,__g.W,__g.X,__g.Y,__g.Z,__g.aa);if(__vd_version_info__.delayedGwx||false)$gwx_XC_18();	if (__vd_version_info__.delayedGwx) __wxAppCode__['components/vant/overlay/index.wxml'] = [$gwx_XC_18, './components/vant/overlay/index.wxml'];else __wxAppCode__['components/vant/overlay/index.wxml'] = $gwx_XC_18( './components/vant/overlay/index.wxml' );
	;__wxRoute = "components/vant/overlay/index";__wxRouteBegin = true;__wxAppCurrentFile__="components/vant/overlay/index.js";define("components/vant/overlay/index.js",function(require,module,exports,window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){
"use strict";Object.defineProperty(exports,"__esModule",{value:!0}),require("../common/component").VantComponent({props:{show:Boolean,customStyle:String,duration:{type:null,value:300},zIndex:{type:Number,value:1}},methods:{onClick:function(){this.$emit("click")},noop:function(){}}});
},{isPage:false,isComponent:true,currentFile:'components/vant/overlay/index.js'});require("components/vant/overlay/index.js");$gwx_XC_19=function(_,_v,_n,_p,_s,_wp,_wl,$gwn,$gwl,$gwh,wh,$gstack,$gwrt,gra,grb,TestTest,wfor,_ca,_da,_r,_rz,_o,_oz,_1,_1z,_2,_2z,_m,_mz,nv_getDate,nv_getRegExp,nv_console,nv_parseInt,nv_parseFloat,nv_isNaN,nv_isFinite,nv_decodeURI,nv_decodeURIComponent,nv_encodeURI,nv_encodeURIComponent,$gdc,nv_JSON,_af,_gv,_ai,_grp,_gd,_gapi,$ixc,_ic,_w,_ev,_tsd){return function(path,global){
if(typeof global==='undefined'){if (typeof __GWX_GLOBAL__==='undefined')global={};else global=__GWX_GLOBAL__;}if(typeof __WXML_GLOBAL__ === 'undefined') {__WXML_GLOBAL__={};
}__WXML_GLOBAL__.modules = __WXML_GLOBAL__.modules || {};
var e_={}
if(typeof(global.entrys)==='undefined')global.entrys={};e_=global.entrys;
var d_={}
if(typeof(global.defines)==='undefined')global.defines={};d_=global.defines;
var f_={}
if(typeof(global.modules)==='undefined')global.modules={};f_=global.modules || {};
var p_={}
__WXML_GLOBAL__.ops_cached = __WXML_GLOBAL__.ops_cached || {}
__WXML_GLOBAL__.ops_set = __WXML_GLOBAL__.ops_set || {};
__WXML_GLOBAL__.ops_init = __WXML_GLOBAL__.ops_init || {};
var z=__WXML_GLOBAL__.ops_set.$gwx_XC_19 || [];
function gz$gwx_XC_19_1(){
if( __WXML_GLOBAL__.ops_cached.$gwx_XC_19_1)return __WXML_GLOBAL__.ops_cached.$gwx_XC_19_1
__WXML_GLOBAL__.ops_cached.$gwx_XC_19_1=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
Z([[7],[3,'overlay']])
Z([3,'onClickOverlay'])
Z([[7],[3,'overlayStyle']])
Z([[7],[3,'duration']])
Z([[7],[3,'show']])
Z([[7],[3,'zIndex']])
Z([[7],[3,'inited']])
Z([3,'onTransitionEnd'])
Z([a,[3,'custom-class '],[[7],[3,'classes']],[3,' '],[[12],[[6],[[7],[3,'utils']],[3,'bem']],[[5],[[5],[1,'popup']],[[4],[[5],[[5],[[7],[3,'position']]],[[9],[[9],[[8],'round',[[7],[3,'round']]],[[8],'safe',[[7],[3,'safeAreaInsetBottom']]]],[[8],'safeTop',[[7],[3,'safeAreaInsetTop']]]]]]]]])
Z([a,[3,'z-index: '],z[5],[3,'; -webkit-transition-duration:'],[[7],[3,'currentDuration']],[3,'ms; transition-duration:'],[[7],[3,'currentDuration']],[3,'ms; '],[[2,'?:'],[[7],[3,'display']],[1,''],[1,'display: none;']],[3,';'],[[7],[3,'customStyle']]])
Z([[7],[3,'closeable']])
Z([3,'onClickCloseIcon'])
Z([a,[3,'van-popup__close-icon van-popup__close-icon--'],[[7],[3,'closeIconPosition']]])
Z([[7],[3,'closeIcon']])
})(__WXML_GLOBAL__.ops_cached.$gwx_XC_19_1);return __WXML_GLOBAL__.ops_cached.$gwx_XC_19_1
}
__WXML_GLOBAL__.ops_set.$gwx_XC_19=z;
__WXML_GLOBAL__.ops_init.$gwx_XC_19=true;
var x=['./components/vant/popup/index.wxml'];d_[x[0]]={}
var m0=function(e,s,r,gg){
var z=gz$gwx_XC_19_1()
var cEE=_v()
_(r,cEE)
if(_oz(z,0,e,s,gg)){cEE.wxVkey=1
var lGE=_mz(z,'van-overlay',['bind:click',1,'customStyle',1,'duration',2,'show',3,'zIndex',4],[],e,s,gg)
_(cEE,lGE)
}
var oFE=_v()
_(r,oFE)
if(_oz(z,6,e,s,gg)){oFE.wxVkey=1
var aHE=_mz(z,'view',['bind:transitionend',7,'class',1,'style',2],[],e,s,gg)
var eJE=_n('slot')
_(aHE,eJE)
var tIE=_v()
_(aHE,tIE)
if(_oz(z,10,e,s,gg)){tIE.wxVkey=1
var bKE=_mz(z,'van-icon',['bind:tap',11,'class',1,'name',2],[],e,s,gg)
_(tIE,bKE)
}
tIE.wxXCkey=1
tIE.wxXCkey=3
_(oFE,aHE)
}
cEE.wxXCkey=1
cEE.wxXCkey=3
oFE.wxXCkey=1
oFE.wxXCkey=3
return r
}
e_[x[0]]={f:m0,j:[],i:[],ti:[],ic:[]}
if(path&&e_[path]){
return function(env,dd,global){$gwxc=0;var root={"tag":"wx-page"};root.children=[]
;g="$gwx_XC_19";var main=e_[path].f
if (typeof global==="undefined")global={};global.f=$gdc(f_[path],"",1);
try{
main(env,{},root,global);
_tsd(root)
}catch(err){
console.log(err)
}
;g="";
return root;
}
}
}
}(__g.a,__g.b,__g.c,__g.d,__g.e,__g.f,__g.g,__g.h,__g.i,__g.j,__g.k,__g.l,__g.m,__g.n,__g.o,__g.p,__g.q,__g.r,__g.s,__g.t,__g.u,__g.v,__g.w,__g.x,__g.y,__g.z,__g.A,__g.B,__g.C,__g.D,__g.E,__g.F,__g.G,__g.H,__g.I,__g.J,__g.K,__g.L,__g.M,__g.N,__g.O,__g.P,__g.Q,__g.R,__g.S,__g.T,__g.U,__g.V,__g.W,__g.X,__g.Y,__g.Z,__g.aa);if(__vd_version_info__.delayedGwx||false)$gwx_XC_19();	if (__vd_version_info__.delayedGwx) __wxAppCode__['components/vant/popup/index.wxml'] = [$gwx_XC_19, './components/vant/popup/index.wxml'];else __wxAppCode__['components/vant/popup/index.wxml'] = $gwx_XC_19( './components/vant/popup/index.wxml' );
	;__wxRoute = "components/vant/popup/index";__wxRouteBegin = true;__wxAppCurrentFile__="components/vant/popup/index.js";define("components/vant/popup/index.js",function(require,module,exports,window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){
"use strict";Object.defineProperty(exports,"__esModule",{value:!0});var e=require("../common/component"),t=require("../mixins/transition");e.VantComponent({classes:["enter-class","enter-active-class","enter-to-class","leave-class","leave-active-class","leave-to-class"],mixins:[t.transition(!1)],props:{round:Boolean,closeable:Boolean,customStyle:String,overlayStyle:String,transition:{type:String,observer:"observeClass"},zIndex:{type:Number,value:100},overlay:{type:Boolean,value:!0},closeIcon:{type:String,value:"cross"},closeIconPosition:{type:String,value:"top-right"},closeOnClickOverlay:{type:Boolean,value:!0},position:{type:String,value:"center",observer:"observeClass"},safeAreaInsetBottom:{type:Boolean,value:!0},safeAreaInsetTop:{type:Boolean,value:!1}},created:function(){this.observeClass()},methods:{onClickCloseIcon:function(){this.$emit("close")},onClickOverlay:function(){this.$emit("click-overlay"),this.data.closeOnClickOverlay&&this.$emit("close")},observeClass:function(){var e=this.data,t=e.transition,o=e.position,s={name:t||o};"none"===t&&(s.duration=0),this.setData(s)}}});
},{isPage:false,isComponent:true,currentFile:'components/vant/popup/index.js'});require("components/vant/popup/index.js");$gwx_XC_20=function(_,_v,_n,_p,_s,_wp,_wl,$gwn,$gwl,$gwh,wh,$gstack,$gwrt,gra,grb,TestTest,wfor,_ca,_da,_r,_rz,_o,_oz,_1,_1z,_2,_2z,_m,_mz,nv_getDate,nv_getRegExp,nv_console,nv_parseInt,nv_parseFloat,nv_isNaN,nv_isFinite,nv_decodeURI,nv_decodeURIComponent,nv_encodeURI,nv_encodeURIComponent,$gdc,nv_JSON,_af,_gv,_ai,_grp,_gd,_gapi,$ixc,_ic,_w,_ev,_tsd){return function(path,global){
if(typeof global==='undefined'){if (typeof __GWX_GLOBAL__==='undefined')global={};else global=__GWX_GLOBAL__;}if(typeof __WXML_GLOBAL__ === 'undefined') {__WXML_GLOBAL__={};
}__WXML_GLOBAL__.modules = __WXML_GLOBAL__.modules || {};
var e_={}
if(typeof(global.entrys)==='undefined')global.entrys={};e_=global.entrys;
var d_={}
if(typeof(global.defines)==='undefined')global.defines={};d_=global.defines;
var f_={}
if(typeof(global.modules)==='undefined')global.modules={};f_=global.modules || {};
var p_={}
__WXML_GLOBAL__.ops_cached = __WXML_GLOBAL__.ops_cached || {}
__WXML_GLOBAL__.ops_set = __WXML_GLOBAL__.ops_set || {};
__WXML_GLOBAL__.ops_init = __WXML_GLOBAL__.ops_init || {};
var z=__WXML_GLOBAL__.ops_set.$gwx_XC_20 || [];
function gz$gwx_XC_20_1(){
if( __WXML_GLOBAL__.ops_cached.$gwx_XC_20_1)return __WXML_GLOBAL__.ops_cached.$gwx_XC_20_1
__WXML_GLOBAL__.ops_cached.$gwx_XC_20_1=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
Z([a,[[12],[[6],[[7],[3,'utils']],[3,'bem']],[[5],[[5],[1,'search']],[[8],'withaction',[[2,'||'],[[7],[3,'showAction']],[[7],[3,'useActionSlot']]]]]],[3,' custom-class']])
Z([a,[3,'background: '],[[7],[3,'background']]])
Z([[12],[[6],[[7],[3,'utils']],[3,'bem']],[[5],[[5],[1,'search__content']],[[4],[[5],[[7],[3,'shape']]]]]])
Z([[7],[3,'label']])
Z([3,'label'])
Z([3,'onBlur'])
Z([3,'onChange'])
Z([3,'onClear'])
Z([3,'onSearch'])
Z([3,'onFocus'])
Z([1,false])
Z([3,'van-search__field field-class'])
Z([[7],[3,'clearable']])
Z([[7],[3,'confirmType']])
Z([3,'padding: 5px 10px 5px 0; background-color: transparent;'])
Z([[7],[3,'disabled']])
Z([[7],[3,'error']])
Z([[7],[3,'focus']])
Z([[7],[3,'inputAlign']])
Z([3,'input-class'])
Z([[2,'?:'],[[2,'!'],[[7],[3,'useLeftIconSlot']]],[[7],[3,'leftIcon']],[1,'']])
Z([[7],[3,'maxlength']])
Z([[7],[3,'placeholder']])
Z([[7],[3,'placeholderStyle']])
Z([[7],[3,'readonly']])
Z([[2,'?:'],[[2,'!'],[[7],[3,'useRightIconSlot']]],[[7],[3,'rightIcon']],[1,'']])
Z([3,'search'])
Z([[7],[3,'value']])
Z([[7],[3,'useLeftIconSlot']])
Z([3,'left-icon'])
Z(z[29])
Z([[7],[3,'useRightIconSlot']])
Z([3,'right-icon'])
Z(z[32])
Z([[2,'||'],[[7],[3,'showAction']],[[7],[3,'useActionSlot']]])
Z([3,'van-search__action'])
Z([3,'van-search__action--hover'])
Z([3,'70'])
Z([[7],[3,'useActionSlot']])
Z([3,'action'])
})(__WXML_GLOBAL__.ops_cached.$gwx_XC_20_1);return __WXML_GLOBAL__.ops_cached.$gwx_XC_20_1
}
__WXML_GLOBAL__.ops_set.$gwx_XC_20=z;
__WXML_GLOBAL__.ops_init.$gwx_XC_20=true;
var x=['./components/vant/search/index.wxml'];d_[x[0]]={}
var m0=function(e,s,r,gg){
var z=gz$gwx_XC_20_1()
var xME=_mz(z,'view',['class',0,'style',1],[],e,s,gg)
var fOE=_n('view')
_rz(z,fOE,'class',2,e,s,gg)
var cPE=_v()
_(fOE,cPE)
if(_oz(z,3,e,s,gg)){cPE.wxVkey=1
}
else{cPE.wxVkey=2
var hQE=_n('slot')
_rz(z,hQE,'name',4,e,s,gg)
_(cPE,hQE)
}
var oRE=_mz(z,'van-field',['bind:blur',5,'bind:change',1,'bind:clear',2,'bind:confirm',3,'bind:focus',4,'border',5,'class',6,'clearable',7,'confirmType',8,'customStyle',9,'disabled',10,'error',11,'focus',12,'inputAlign',13,'inputClass',14,'leftIcon',15,'maxlength',16,'placeholder',17,'placeholderStyle',18,'readonly',19,'rightIcon',20,'type',21,'value',22],[],e,s,gg)
var cSE=_v()
_(oRE,cSE)
if(_oz(z,28,e,s,gg)){cSE.wxVkey=1
var lUE=_mz(z,'slot',['name',29,'slot',1],[],e,s,gg)
_(cSE,lUE)
}
var oTE=_v()
_(oRE,oTE)
if(_oz(z,31,e,s,gg)){oTE.wxVkey=1
var aVE=_mz(z,'slot',['name',32,'slot',1],[],e,s,gg)
_(oTE,aVE)
}
cSE.wxXCkey=1
oTE.wxXCkey=1
_(fOE,oRE)
cPE.wxXCkey=1
_(xME,fOE)
var oNE=_v()
_(xME,oNE)
if(_oz(z,34,e,s,gg)){oNE.wxVkey=1
var tWE=_mz(z,'view',['class',35,'hoverClass',1,'hoverStayTime',2],[],e,s,gg)
var eXE=_v()
_(tWE,eXE)
if(_oz(z,38,e,s,gg)){eXE.wxVkey=1
var bYE=_n('slot')
_rz(z,bYE,'name',39,e,s,gg)
_(eXE,bYE)
}
else{eXE.wxVkey=2
}
eXE.wxXCkey=1
_(oNE,tWE)
}
oNE.wxXCkey=1
_(r,xME)
return r
}
e_[x[0]]={f:m0,j:[],i:[],ti:[],ic:[]}
if(path&&e_[path]){
return function(env,dd,global){$gwxc=0;var root={"tag":"wx-page"};root.children=[]
;g="$gwx_XC_20";var main=e_[path].f
if (typeof global==="undefined")global={};global.f=$gdc(f_[path],"",1);
try{
main(env,{},root,global);
_tsd(root)
}catch(err){
console.log(err)
}
;g="";
return root;
}
}
}
}(__g.a,__g.b,__g.c,__g.d,__g.e,__g.f,__g.g,__g.h,__g.i,__g.j,__g.k,__g.l,__g.m,__g.n,__g.o,__g.p,__g.q,__g.r,__g.s,__g.t,__g.u,__g.v,__g.w,__g.x,__g.y,__g.z,__g.A,__g.B,__g.C,__g.D,__g.E,__g.F,__g.G,__g.H,__g.I,__g.J,__g.K,__g.L,__g.M,__g.N,__g.O,__g.P,__g.Q,__g.R,__g.S,__g.T,__g.U,__g.V,__g.W,__g.X,__g.Y,__g.Z,__g.aa);if(__vd_version_info__.delayedGwx||false)$gwx_XC_20();	if (__vd_version_info__.delayedGwx) __wxAppCode__['components/vant/search/index.wxml'] = [$gwx_XC_20, './components/vant/search/index.wxml'];else __wxAppCode__['components/vant/search/index.wxml'] = $gwx_XC_20( './components/vant/search/index.wxml' );
	;__wxRoute = "components/vant/search/index";__wxRouteBegin = true;__wxAppCurrentFile__="components/vant/search/index.js";define("components/vant/search/index.js",function(require,module,exports,window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){
"use strict";Object.defineProperty(exports,"__esModule",{value:!0}),require("../common/component").VantComponent({field:!0,classes:["field-class","input-class","cancel-class"],props:{label:String,focus:Boolean,error:Boolean,disabled:Boolean,readonly:Boolean,inputAlign:String,showAction:Boolean,useActionSlot:Boolean,useLeftIconSlot:Boolean,useRightIconSlot:Boolean,confirmType:{type:String,value:"search"},leftIcon:{type:String,value:"search"},rightIcon:String,placeholder:String,placeholderStyle:String,actionText:{type:String,value:"取消"},background:{type:String,value:"#ffffff"},maxlength:{type:Number,value:-1},shape:{type:String,value:"square"},clearable:{type:Boolean,value:!0}},methods:{onChange:function(e){this.setData({value:e.detail}),this.$emit("change",e.detail)},onCancel:function(){var e=this;setTimeout((function(){e.setData({value:""}),e.$emit("cancel"),e.$emit("change","")}),200)},onSearch:function(){this.$emit("search",this.data.value)},onFocus:function(){this.$emit("focus")},onBlur:function(){this.$emit("blur")},onClear:function(){this.$emit("clear")}}});
},{isPage:false,isComponent:true,currentFile:'components/vant/search/index.js'});require("components/vant/search/index.js");$gwx_XC_21=function(_,_v,_n,_p,_s,_wp,_wl,$gwn,$gwl,$gwh,wh,$gstack,$gwrt,gra,grb,TestTest,wfor,_ca,_da,_r,_rz,_o,_oz,_1,_1z,_2,_2z,_m,_mz,nv_getDate,nv_getRegExp,nv_console,nv_parseInt,nv_parseFloat,nv_isNaN,nv_isFinite,nv_decodeURI,nv_decodeURIComponent,nv_encodeURI,nv_encodeURIComponent,$gdc,nv_JSON,_af,_gv,_ai,_grp,_gd,_gapi,$ixc,_ic,_w,_ev,_tsd){return function(path,global){
if(typeof global==='undefined'){if (typeof __GWX_GLOBAL__==='undefined')global={};else global=__GWX_GLOBAL__;}if(typeof __WXML_GLOBAL__ === 'undefined') {__WXML_GLOBAL__={};
}__WXML_GLOBAL__.modules = __WXML_GLOBAL__.modules || {};
var e_={}
if(typeof(global.entrys)==='undefined')global.entrys={};e_=global.entrys;
var d_={}
if(typeof(global.defines)==='undefined')global.defines={};d_=global.defines;
var f_={}
if(typeof(global.modules)==='undefined')global.modules={};f_=global.modules || {};
var p_={}
__WXML_GLOBAL__.ops_cached = __WXML_GLOBAL__.ops_cached || {}
__WXML_GLOBAL__.ops_set = __WXML_GLOBAL__.ops_set || {};
__WXML_GLOBAL__.ops_init = __WXML_GLOBAL__.ops_init || {};
var z=__WXML_GLOBAL__.ops_set.$gwx_XC_21 || [];
function gz$gwx_XC_21_1(){
if( __WXML_GLOBAL__.ops_cached.$gwx_XC_21_1)return __WXML_GLOBAL__.ops_cached.$gwx_XC_21_1
__WXML_GLOBAL__.ops_cached.$gwx_XC_21_1=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
Z([[7],[3,'steps']])
Z([3,'index'])
Z([3,'onClick'])
Z([a,[[12],[[6],[[7],[3,'utils']],[3,'bem']],[[5],[[5],[1,'step']],[[4],[[5],[[5],[[7],[3,'direction']]],[[12],[[7],[3,'status']],[[5],[[5],[[7],[3,'index']]],[[7],[3,'active']]]]]]]],[3,' van-hairline']])
Z([[7],[3,'index']])
Z([[2,'?:'],[[2,'==='],[[12],[[7],[3,'status']],[[5],[[5],[[7],[3,'index']]],[[7],[3,'active']]]],[1,'inactive']],[[2,'+'],[1,'color: '],[[7],[3,'inactiveColor']]],[1,'']])
Z([3,'van-step__circle-container'])
Z([[2,'!=='],[[7],[3,'index']],[[7],[3,'active']]])
Z([[7],[3,'inactiveIcon']])
Z([[2,'?:'],[[2,'==='],[[12],[[7],[3,'status']],[[5],[[5],[[7],[3,'index']]],[[7],[3,'active']]]],[1,'inactive']],[[7],[3,'inactiveColor']],[[7],[3,'activeColor']]])
Z([3,'van-step__icon'])
Z(z[8])
Z([[7],[3,'activeColor']])
Z(z[10])
Z([[7],[3,'activeIcon']])
Z([[2,'!=='],[[7],[3,'index']],[[2,'-'],[[6],[[7],[3,'steps']],[3,'length']],[1,1]]])
})(__WXML_GLOBAL__.ops_cached.$gwx_XC_21_1);return __WXML_GLOBAL__.ops_cached.$gwx_XC_21_1
}
__WXML_GLOBAL__.ops_set.$gwx_XC_21=z;
__WXML_GLOBAL__.ops_init.$gwx_XC_21=true;
var x=['./components/vant/steps/index.wxml'];d_[x[0]]={}
var m0=function(e,s,r,gg){
var z=gz$gwx_XC_21_1()
var x1E=_v()
_(r,x1E)
var o2E=function(c4E,f3E,h5E,gg){
var c7E=_mz(z,'view',['bindtap',2,'class',1,'data-index',2,'style',3],[],c4E,f3E,gg)
var l9E=_n('view')
_rz(z,l9E,'class',6,c4E,f3E,gg)
var a0E=_v()
_(l9E,a0E)
if(_oz(z,7,c4E,f3E,gg)){a0E.wxVkey=1
var tAF=_v()
_(a0E,tAF)
if(_oz(z,8,c4E,f3E,gg)){tAF.wxVkey=1
var eBF=_mz(z,'van-icon',['color',9,'customClass',1,'name',2],[],c4E,f3E,gg)
_(tAF,eBF)
}
else{tAF.wxVkey=2
}
tAF.wxXCkey=1
tAF.wxXCkey=3
}
else{a0E.wxVkey=2
var bCF=_mz(z,'van-icon',['color',12,'customClass',1,'name',2],[],c4E,f3E,gg)
_(a0E,bCF)
}
a0E.wxXCkey=1
a0E.wxXCkey=3
a0E.wxXCkey=3
_(c7E,l9E)
var o8E=_v()
_(c7E,o8E)
if(_oz(z,15,c4E,f3E,gg)){o8E.wxVkey=1
}
o8E.wxXCkey=1
_(h5E,c7E)
return h5E
}
x1E.wxXCkey=4
_2z(z,0,o2E,e,s,gg,x1E,'item','index','index')
return r
}
e_[x[0]]={f:m0,j:[],i:[],ti:[],ic:[]}
if(path&&e_[path]){
return function(env,dd,global){$gwxc=0;var root={"tag":"wx-page"};root.children=[]
;g="$gwx_XC_21";var main=e_[path].f
if (typeof global==="undefined")global={};global.f=$gdc(f_[path],"",1);
try{
main(env,{},root,global);
_tsd(root)
}catch(err){
console.log(err)
}
;g="";
return root;
}
}
}
}(__g.a,__g.b,__g.c,__g.d,__g.e,__g.f,__g.g,__g.h,__g.i,__g.j,__g.k,__g.l,__g.m,__g.n,__g.o,__g.p,__g.q,__g.r,__g.s,__g.t,__g.u,__g.v,__g.w,__g.x,__g.y,__g.z,__g.A,__g.B,__g.C,__g.D,__g.E,__g.F,__g.G,__g.H,__g.I,__g.J,__g.K,__g.L,__g.M,__g.N,__g.O,__g.P,__g.Q,__g.R,__g.S,__g.T,__g.U,__g.V,__g.W,__g.X,__g.Y,__g.Z,__g.aa);if(__vd_version_info__.delayedGwx||false)$gwx_XC_21();	if (__vd_version_info__.delayedGwx) __wxAppCode__['components/vant/steps/index.wxml'] = [$gwx_XC_21, './components/vant/steps/index.wxml'];else __wxAppCode__['components/vant/steps/index.wxml'] = $gwx_XC_21( './components/vant/steps/index.wxml' );
	;__wxRoute = "components/vant/steps/index";__wxRouteBegin = true;__wxAppCurrentFile__="components/vant/steps/index.js";define("components/vant/steps/index.js",function(require,module,exports,window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){
"use strict";Object.defineProperty(exports,"__esModule",{value:!0});var e=require("../common/component"),t=require("../common/color");e.VantComponent({classes:["desc-class"],props:{icon:String,steps:Array,active:Number,direction:{type:String,value:"horizontal"},activeColor:{type:String,value:t.GREEN},inactiveColor:{type:String,value:t.GRAY_DARK},activeIcon:{type:String,value:"checked"},inactiveIcon:String},methods:{onClick:function(e){var t=e.currentTarget.dataset.index;this.$emit("click-step",t)}}});
},{isPage:false,isComponent:true,currentFile:'components/vant/steps/index.js'});require("components/vant/steps/index.js");$gwx_XC_22=function(_,_v,_n,_p,_s,_wp,_wl,$gwn,$gwl,$gwh,wh,$gstack,$gwrt,gra,grb,TestTest,wfor,_ca,_da,_r,_rz,_o,_oz,_1,_1z,_2,_2z,_m,_mz,nv_getDate,nv_getRegExp,nv_console,nv_parseInt,nv_parseFloat,nv_isNaN,nv_isFinite,nv_decodeURI,nv_decodeURIComponent,nv_encodeURI,nv_encodeURIComponent,$gdc,nv_JSON,_af,_gv,_ai,_grp,_gd,_gapi,$ixc,_ic,_w,_ev,_tsd){return function(path,global){
if(typeof global==='undefined'){if (typeof __GWX_GLOBAL__==='undefined')global={};else global=__GWX_GLOBAL__;}if(typeof __WXML_GLOBAL__ === 'undefined') {__WXML_GLOBAL__={};
}__WXML_GLOBAL__.modules = __WXML_GLOBAL__.modules || {};
var e_={}
if(typeof(global.entrys)==='undefined')global.entrys={};e_=global.entrys;
var d_={}
if(typeof(global.defines)==='undefined')global.defines={};d_=global.defines;
var f_={}
if(typeof(global.modules)==='undefined')global.modules={};f_=global.modules || {};
var p_={}
__WXML_GLOBAL__.ops_cached = __WXML_GLOBAL__.ops_cached || {}
__WXML_GLOBAL__.ops_set = __WXML_GLOBAL__.ops_set || {};
__WXML_GLOBAL__.ops_init = __WXML_GLOBAL__.ops_init || {};
var z=__WXML_GLOBAL__.ops_set.$gwx_XC_22 || [];
function gz$gwx_XC_22_1(){
if( __WXML_GLOBAL__.ops_cached.$gwx_XC_22_1)return __WXML_GLOBAL__.ops_cached.$gwx_XC_22_1
__WXML_GLOBAL__.ops_cached.$gwx_XC_22_1=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
})(__WXML_GLOBAL__.ops_cached.$gwx_XC_22_1);return __WXML_GLOBAL__.ops_cached.$gwx_XC_22_1
}
__WXML_GLOBAL__.ops_set.$gwx_XC_22=z;
__WXML_GLOBAL__.ops_init.$gwx_XC_22=true;
var x=['./components/vant/sticky/index.wxml'];d_[x[0]]={}
var m0=function(e,s,r,gg){
var z=gz$gwx_XC_22_1()
var xEF=_n('slot')
_(r,xEF)
return r
}
e_[x[0]]={f:m0,j:[],i:[],ti:[],ic:[]}
if(path&&e_[path]){
return function(env,dd,global){$gwxc=0;var root={"tag":"wx-page"};root.children=[]
;g="$gwx_XC_22";var main=e_[path].f
if (typeof global==="undefined")global={};global.f=$gdc(f_[path],"",1);
try{
main(env,{},root,global);
_tsd(root)
}catch(err){
console.log(err)
}
;g="";
return root;
}
}
}
}(__g.a,__g.b,__g.c,__g.d,__g.e,__g.f,__g.g,__g.h,__g.i,__g.j,__g.k,__g.l,__g.m,__g.n,__g.o,__g.p,__g.q,__g.r,__g.s,__g.t,__g.u,__g.v,__g.w,__g.x,__g.y,__g.z,__g.A,__g.B,__g.C,__g.D,__g.E,__g.F,__g.G,__g.H,__g.I,__g.J,__g.K,__g.L,__g.M,__g.N,__g.O,__g.P,__g.Q,__g.R,__g.S,__g.T,__g.U,__g.V,__g.W,__g.X,__g.Y,__g.Z,__g.aa);if(__vd_version_info__.delayedGwx||false)$gwx_XC_22();	if (__vd_version_info__.delayedGwx) __wxAppCode__['components/vant/sticky/index.wxml'] = [$gwx_XC_22, './components/vant/sticky/index.wxml'];else __wxAppCode__['components/vant/sticky/index.wxml'] = $gwx_XC_22( './components/vant/sticky/index.wxml' );
	;__wxRoute = "components/vant/sticky/index";__wxRouteBegin = true;__wxAppCurrentFile__="components/vant/sticky/index.js";define("components/vant/sticky/index.js",function(require,module,exports,window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){
"use strict";Object.defineProperty(exports,"__esModule",{value:!0});var t=require("../common/component"),e=require("../mixins/page-scroll");t.VantComponent({props:{zIndex:{type:Number,value:99},offsetTop:{type:Number,value:0,observer:"onScroll"},disabled:{type:Boolean,observer:"onScroll"},container:{type:null,observer:"onScroll"},scrollTop:{type:null,observer:function(t){this.onScroll({scrollTop:t})}}},mixins:[e.pageScrollMixin((function(t){null==this.data.scrollTop&&this.onScroll(t)}))],data:{height:0,fixed:!1,transform:0},mounted:function(){this.onScroll()},methods:{onScroll:function(t){var e=this,o=(void 0===t?{}:t).scrollTop,i=this.data,r=i.container,n=i.offsetTop;i.disabled?this.setDataAfterDiff({fixed:!1,transform:0}):(this.scrollTop=o||this.scrollTop,"function"!=typeof r?this.getRect(".van-sticky").then((function(t){n>=t.top?(e.setDataAfterDiff({fixed:!0,height:t.height}),e.transform=0):e.setDataAfterDiff({fixed:!1})})):Promise.all([this.getRect(".van-sticky"),this.getContainerRect()]).then((function(t){var o=t[0],i=t[1];n+o.height>i.height+i.top?e.setDataAfterDiff({fixed:!1,transform:i.height-o.height}):n>=o.top?e.setDataAfterDiff({fixed:!0,height:o.height,transform:0}):e.setDataAfterDiff({fixed:!1,transform:0})})))},setDataAfterDiff:function(t){var e=this;wx.nextTick((function(){var o=Object.keys(t).reduce((function(o,i){return t[i]!==e.data[i]&&(o[i]=t[i]),o}),{});e.setData(o),e.$emit("scroll",{scrollTop:e.scrollTop,isFixed:t.fixed||e.data.fixed})}))},getContainerRect:function(){var t=this.data.container();return new Promise((function(e){return t.boundingClientRect(e).exec()}))}}});
},{isPage:false,isComponent:true,currentFile:'components/vant/sticky/index.js'});require("components/vant/sticky/index.js");$gwx_XC_23=function(_,_v,_n,_p,_s,_wp,_wl,$gwn,$gwl,$gwh,wh,$gstack,$gwrt,gra,grb,TestTest,wfor,_ca,_da,_r,_rz,_o,_oz,_1,_1z,_2,_2z,_m,_mz,nv_getDate,nv_getRegExp,nv_console,nv_parseInt,nv_parseFloat,nv_isNaN,nv_isFinite,nv_decodeURI,nv_decodeURIComponent,nv_encodeURI,nv_encodeURIComponent,$gdc,nv_JSON,_af,_gv,_ai,_grp,_gd,_gapi,$ixc,_ic,_w,_ev,_tsd){return function(path,global){
if(typeof global==='undefined'){if (typeof __GWX_GLOBAL__==='undefined')global={};else global=__GWX_GLOBAL__;}if(typeof __WXML_GLOBAL__ === 'undefined') {__WXML_GLOBAL__={};
}__WXML_GLOBAL__.modules = __WXML_GLOBAL__.modules || {};
var e_={}
if(typeof(global.entrys)==='undefined')global.entrys={};e_=global.entrys;
var d_={}
if(typeof(global.defines)==='undefined')global.defines={};d_=global.defines;
var f_={}
if(typeof(global.modules)==='undefined')global.modules={};f_=global.modules || {};
var p_={}
__WXML_GLOBAL__.ops_cached = __WXML_GLOBAL__.ops_cached || {}
__WXML_GLOBAL__.ops_set = __WXML_GLOBAL__.ops_set || {};
__WXML_GLOBAL__.ops_init = __WXML_GLOBAL__.ops_init || {};
var z=__WXML_GLOBAL__.ops_set.$gwx_XC_23 || [];
function gz$gwx_XC_23_1(){
if( __WXML_GLOBAL__.ops_cached.$gwx_XC_23_1)return __WXML_GLOBAL__.ops_cached.$gwx_XC_23_1
__WXML_GLOBAL__.ops_cached.$gwx_XC_23_1=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
Z([a,[3,'custom-class '],[[12],[[6],[[7],[3,'utils']],[3,'bem']],[[5],[[5],[1,'tag']],[[4],[[5],[[5],[[5],[[7],[3,'type']]],[[7],[3,'size']]],[[9],[[9],[[8],'mark',[[7],[3,'mark']]],[[8],'plain',[[7],[3,'plain']]]],[[8],'round',[[7],[3,'round']]]]]]]],[3,' '],[[2,'?:'],[[7],[3,'plain']],[1,'van-hairline--surround'],[1,'']]])
Z([a,[[2,'?:'],[[2,'&&'],[[7],[3,'color']],[[2,'!'],[[7],[3,'plain']]]],[[2,'+'],[[2,'+'],[1,'background-color: '],[[7],[3,'color']]],[1,';']],[1,'']],[[2,'?:'],[[2,'||'],[[7],[3,'textColor']],[[2,'&&'],[[7],[3,'color']],[[7],[3,'plain']]]],[[2,'+'],[1,'color: '],[[2,'||'],[[7],[3,'textColor']],[[7],[3,'color']]]],[1,'']]])
Z([[7],[3,'closeable']])
Z([3,'onClose'])
Z([3,'van-tag__close'])
Z([3,'cross'])
})(__WXML_GLOBAL__.ops_cached.$gwx_XC_23_1);return __WXML_GLOBAL__.ops_cached.$gwx_XC_23_1
}
__WXML_GLOBAL__.ops_set.$gwx_XC_23=z;
__WXML_GLOBAL__.ops_init.$gwx_XC_23=true;
var x=['./components/vant/tag/index.wxml'];d_[x[0]]={}
var m0=function(e,s,r,gg){
var z=gz$gwx_XC_23_1()
var fGF=_mz(z,'view',['class',0,'style',1],[],e,s,gg)
var hIF=_n('slot')
_(fGF,hIF)
var cHF=_v()
_(fGF,cHF)
if(_oz(z,2,e,s,gg)){cHF.wxVkey=1
var oJF=_mz(z,'van-icon',['bind:click',3,'customClass',1,'name',2],[],e,s,gg)
_(cHF,oJF)
}
cHF.wxXCkey=1
cHF.wxXCkey=3
_(r,fGF)
return r
}
e_[x[0]]={f:m0,j:[],i:[],ti:[],ic:[]}
if(path&&e_[path]){
return function(env,dd,global){$gwxc=0;var root={"tag":"wx-page"};root.children=[]
;g="$gwx_XC_23";var main=e_[path].f
if (typeof global==="undefined")global={};global.f=$gdc(f_[path],"",1);
try{
main(env,{},root,global);
_tsd(root)
}catch(err){
console.log(err)
}
;g="";
return root;
}
}
}
}(__g.a,__g.b,__g.c,__g.d,__g.e,__g.f,__g.g,__g.h,__g.i,__g.j,__g.k,__g.l,__g.m,__g.n,__g.o,__g.p,__g.q,__g.r,__g.s,__g.t,__g.u,__g.v,__g.w,__g.x,__g.y,__g.z,__g.A,__g.B,__g.C,__g.D,__g.E,__g.F,__g.G,__g.H,__g.I,__g.J,__g.K,__g.L,__g.M,__g.N,__g.O,__g.P,__g.Q,__g.R,__g.S,__g.T,__g.U,__g.V,__g.W,__g.X,__g.Y,__g.Z,__g.aa);if(__vd_version_info__.delayedGwx||false)$gwx_XC_23();	if (__vd_version_info__.delayedGwx) __wxAppCode__['components/vant/tag/index.wxml'] = [$gwx_XC_23, './components/vant/tag/index.wxml'];else __wxAppCode__['components/vant/tag/index.wxml'] = $gwx_XC_23( './components/vant/tag/index.wxml' );
	;__wxRoute = "components/vant/tag/index";__wxRouteBegin = true;__wxAppCurrentFile__="components/vant/tag/index.js";define("components/vant/tag/index.js",function(require,module,exports,window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){
"use strict";Object.defineProperty(exports,"__esModule",{value:!0}),require("../common/component").VantComponent({props:{size:String,mark:Boolean,color:String,plain:Boolean,round:Boolean,textColor:String,type:{type:String,value:"default"},closeable:Boolean},methods:{onClose:function(){this.$emit("close")}}});
},{isPage:false,isComponent:true,currentFile:'components/vant/tag/index.js'});require("components/vant/tag/index.js");$gwx_XC_24=function(_,_v,_n,_p,_s,_wp,_wl,$gwn,$gwl,$gwh,wh,$gstack,$gwrt,gra,grb,TestTest,wfor,_ca,_da,_r,_rz,_o,_oz,_1,_1z,_2,_2z,_m,_mz,nv_getDate,nv_getRegExp,nv_console,nv_parseInt,nv_parseFloat,nv_isNaN,nv_isFinite,nv_decodeURI,nv_decodeURIComponent,nv_encodeURI,nv_encodeURIComponent,$gdc,nv_JSON,_af,_gv,_ai,_grp,_gd,_gapi,$ixc,_ic,_w,_ev,_tsd){return function(path,global){
if(typeof global==='undefined'){if (typeof __GWX_GLOBAL__==='undefined')global={};else global=__GWX_GLOBAL__;}if(typeof __WXML_GLOBAL__ === 'undefined') {__WXML_GLOBAL__={};
}__WXML_GLOBAL__.modules = __WXML_GLOBAL__.modules || {};
var e_={}
if(typeof(global.entrys)==='undefined')global.entrys={};e_=global.entrys;
var d_={}
if(typeof(global.defines)==='undefined')global.defines={};d_=global.defines;
var f_={}
if(typeof(global.modules)==='undefined')global.modules={};f_=global.modules || {};
var p_={}
__WXML_GLOBAL__.ops_cached = __WXML_GLOBAL__.ops_cached || {}
__WXML_GLOBAL__.ops_set = __WXML_GLOBAL__.ops_set || {};
__WXML_GLOBAL__.ops_init = __WXML_GLOBAL__.ops_init || {};
var z=__WXML_GLOBAL__.ops_set.$gwx_XC_24 || [];
function gz$gwx_XC_24_1(){
if( __WXML_GLOBAL__.ops_cached.$gwx_XC_24_1)return __WXML_GLOBAL__.ops_cached.$gwx_XC_24_1
__WXML_GLOBAL__.ops_cached.$gwx_XC_24_1=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
Z([[7],[3,'inited']])
Z([3,'onTransitionEnd'])
Z([a,[3,'van-transition custom-class '],[[7],[3,'classes']]])
Z([a,[3,'-webkit-transition-duration:'],[[7],[3,'currentDuration']],[3,'ms; transition-duration:'],[[7],[3,'currentDuration']],[3,'ms; '],[[2,'?:'],[[7],[3,'display']],[1,''],[1,'display: none;']],[3,' '],[[7],[3,'customStyle']]])
})(__WXML_GLOBAL__.ops_cached.$gwx_XC_24_1);return __WXML_GLOBAL__.ops_cached.$gwx_XC_24_1
}
__WXML_GLOBAL__.ops_set.$gwx_XC_24=z;
__WXML_GLOBAL__.ops_init.$gwx_XC_24=true;
var x=['./components/vant/transition/index.wxml'];d_[x[0]]={}
var m0=function(e,s,r,gg){
var z=gz$gwx_XC_24_1()
var oLF=_v()
_(r,oLF)
if(_oz(z,0,e,s,gg)){oLF.wxVkey=1
var lMF=_mz(z,'view',['bind:transitionend',1,'class',1,'style',2],[],e,s,gg)
var aNF=_n('slot')
_(lMF,aNF)
_(oLF,lMF)
}
oLF.wxXCkey=1
return r
}
e_[x[0]]={f:m0,j:[],i:[],ti:[],ic:[]}
if(path&&e_[path]){
return function(env,dd,global){$gwxc=0;var root={"tag":"wx-page"};root.children=[]
;g="$gwx_XC_24";var main=e_[path].f
if (typeof global==="undefined")global={};global.f=$gdc(f_[path],"",1);
try{
main(env,{},root,global);
_tsd(root)
}catch(err){
console.log(err)
}
;g="";
return root;
}
}
}
}(__g.a,__g.b,__g.c,__g.d,__g.e,__g.f,__g.g,__g.h,__g.i,__g.j,__g.k,__g.l,__g.m,__g.n,__g.o,__g.p,__g.q,__g.r,__g.s,__g.t,__g.u,__g.v,__g.w,__g.x,__g.y,__g.z,__g.A,__g.B,__g.C,__g.D,__g.E,__g.F,__g.G,__g.H,__g.I,__g.J,__g.K,__g.L,__g.M,__g.N,__g.O,__g.P,__g.Q,__g.R,__g.S,__g.T,__g.U,__g.V,__g.W,__g.X,__g.Y,__g.Z,__g.aa);if(__vd_version_info__.delayedGwx||false)$gwx_XC_24();	if (__vd_version_info__.delayedGwx) __wxAppCode__['components/vant/transition/index.wxml'] = [$gwx_XC_24, './components/vant/transition/index.wxml'];else __wxAppCode__['components/vant/transition/index.wxml'] = $gwx_XC_24( './components/vant/transition/index.wxml' );
	;__wxRoute = "components/vant/transition/index";__wxRouteBegin = true;__wxAppCurrentFile__="components/vant/transition/index.js";define("components/vant/transition/index.js",function(require,module,exports,window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){
"use strict";Object.defineProperty(exports,"__esModule",{value:!0});var e=require("../common/component"),s=require("../mixins/transition");e.VantComponent({classes:["enter-class","enter-active-class","enter-to-class","leave-class","leave-active-class","leave-to-class"],mixins:[s.transition(!0)]});
},{isPage:false,isComponent:true,currentFile:'components/vant/transition/index.js'});require("components/vant/transition/index.js");$gwx_XC_25=function(_,_v,_n,_p,_s,_wp,_wl,$gwn,$gwl,$gwh,wh,$gstack,$gwrt,gra,grb,TestTest,wfor,_ca,_da,_r,_rz,_o,_oz,_1,_1z,_2,_2z,_m,_mz,nv_getDate,nv_getRegExp,nv_console,nv_parseInt,nv_parseFloat,nv_isNaN,nv_isFinite,nv_decodeURI,nv_decodeURIComponent,nv_encodeURI,nv_encodeURIComponent,$gdc,nv_JSON,_af,_gv,_ai,_grp,_gd,_gapi,$ixc,_ic,_w,_ev,_tsd){return function(path,global){
if(typeof global==='undefined'){if (typeof __GWX_GLOBAL__==='undefined')global={};else global=__GWX_GLOBAL__;}if(typeof __WXML_GLOBAL__ === 'undefined') {__WXML_GLOBAL__={};
}__WXML_GLOBAL__.modules = __WXML_GLOBAL__.modules || {};
var e_={}
if(typeof(global.entrys)==='undefined')global.entrys={};e_=global.entrys;
var d_={}
if(typeof(global.defines)==='undefined')global.defines={};d_=global.defines;
var f_={}
if(typeof(global.modules)==='undefined')global.modules={};f_=global.modules || {};
var p_={}
__WXML_GLOBAL__.ops_cached = __WXML_GLOBAL__.ops_cached || {}
__WXML_GLOBAL__.ops_set = __WXML_GLOBAL__.ops_set || {};
__WXML_GLOBAL__.ops_init = __WXML_GLOBAL__.ops_init || {};
var z=__WXML_GLOBAL__.ops_set.$gwx_XC_25 || [];
function gz$gwx_XC_25_1(){
if( __WXML_GLOBAL__.ops_cached.$gwx_XC_25_1)return __WXML_GLOBAL__.ops_cached.$gwx_XC_25_1
__WXML_GLOBAL__.ops_cached.$gwx_XC_25_1=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
Z([[7],[3,'addtip']])
Z([3,'closeAddTipNoticeBar'])
Z([3,'volume-o'])
Z([3,'closeable'])
Z([1,true])
Z(z[0])
Z([3,'dialogGetQr'])
Z(z[6])
Z([3,'#576b95'])
Z([3,'普通二维码'])
Z(z[4])
Z([3,'#07c160'])
Z([3,'圆形码'])
Z([3,'即将生成该文件二维码并保存到手机相册，请选择类型？（点击遮罩可取消）'])
Z(z[4])
Z([[7],[3,'showDialog']])
Z([3,'选择二维码类型'])
Z([[2,'&&'],[[7],[3,'userInfo']],[[6],[[7],[3,'userInfo']],[3,'superAuth']]])
Z([3,'padding: 0 32rpx;margin-bottom: 10rpx;margin-top: 10rpx;'])
Z([1,500])
Z([3,'fade-up'])
Z([[2,'!'],[[7],[3,'showSearch']]])
Z([3,'showSearch'])
Z([3,'search'])
Z([3,'46rpx'])
Z([3,'color: #969799;font-size: 30rpx;display:flex;justify-content:flex-start;align-items:center;'])
Z([3,'toQuestion'])
Z(z[8])
Z([3,'question-o'])
Z([3,'42rpx'])
Z([3,'margin-left: 28rpx;color: #576b95;font-weight: 500;'])
Z([3,'toRecycle'])
Z([3,'my-icon'])
Z(z[8])
Z([3,'recycle'])
Z(z[29])
Z(z[30])
Z([3,'toNotice'])
Z(z[32])
Z([3,'tongzhi'])
Z([3,'38rpx'])
Z(z[30])
Z(z[19])
Z([3,'fade-down'])
Z([[7],[3,'showSearch']])
Z([[7],[3,'pageList']])
Z([3,'onSearchCancel'])
Z([3,'onSearchChange'])
Z([3,'onSearch'])
Z([[2,'||'],[[7],[3,'showEdit']],[[7],[3,'showOriginUrlPopup']]])
Z([3,'搜索我添加的文件'])
Z([3,'round'])
Z([[7],[3,'searchKey']])
Z([[2,'&&'],[[7],[3,'pageList']],[[2,'=='],[[6],[[7],[3,'pageList']],[3,'length']],[1,0]]])
Z([[7],[3,'openid']])
Z([3,'chooseFile'])
Z(z[32])
Z(z[11])
Z([3,'shangchuan'])
Z([3,'110rpx'])
Z([3,'position:fixed;right:40rpx;bottom:40rpx;height:120rpx;width:120rpx;background-color: #ffffff;border-radius: 50%;'])
Z([3,'showPopupAfter'])
Z([3,'onClosePopup'])
Z([3,'height:90%;'])
Z([3,'bottom'])
Z([[7],[3,'showEdit']])
Z([3,'writeView'])
Z(z[62])
Z([3,'cross'])
Z([3,'36rpx'])
Z([3,'padding:6rpx;'])
Z([[7],[3,'showPopupTextarea']])
Z([[12],[[6],[[7],[3,'myutil']],[3,'canOpen']],[[5],[[7],[3,'fileID']]]])
Z([[4],[[5],[[5],[[5],[[5],[1,1]],[1,2]],[1,3]],[1,4]]])
Z([3,'_id'])
Z([3,'width:100%;box-sizing:border-box;'])
Z([[2,'!'],[[7],[3,'pageList']]])
Z([[2,'<'],[[7],[3,'index']],[1,3]])
Z(z[45])
Z(z[74])
Z(z[75])
Z([3,'showActionSheet'])
Z([3,'activeEnd'])
Z([3,'activeStart'])
Z([[2,'?:'],[[2,'=='],[[7],[3,'currentItemId']],[[6],[[7],[3,'item']],[3,'_id']]],[1,'actived-item'],[1,'']])
Z([[6],[[7],[3,'item']],[3,'_id']])
Z([[7],[3,'index']])
Z([3,'padding:16rpx 32rpx 16rpx 24rpx;display:flex;justify-content:flex-start;box-sizing:border-box;'])
Z([3,'calcTypeImgFontScale'])
Z(z[86])
Z([[2,'?:'],[[2,'&&'],[[6],[[7],[3,'item']],[3,'pwd']],[[6],[[7],[3,'item']],[3,'readOnly']]],[1,true],[1,false]])
Z(z[4])
Z([[6],[[7],[3,'item']],[3,'typeImg']])
Z([a,[3,'height: '],[[7],[3,'typeImgWidth']],[3,'rpx;width: '],[[7],[3,'typeImgWidth']],[3,'rpx;position: relative;']])
Z([[2,'||'],[[6],[[7],[3,'item']],[3,'pwd']],[[6],[[7],[3,'item']],[3,'readOnly']]])
Z([a,[3,'typeImgFont_'],z[86]])
Z([a,[3,'font-size:14rpx;color: #ffffff;transform-origin: 50% 100%;transform: scale('],[[7],[3,'typeImgFontScale']],[3,');']])
Z([[6],[[7],[3,'item']],[3,'pwd']])
Z([[2,'&&'],[[6],[[7],[3,'item']],[3,'pwd']],[[6],[[7],[3,'item']],[3,'readOnly']]])
Z([[6],[[7],[3,'item']],[3,'readOnly']])
Z([[2,'>'],[[6],[[7],[3,'pageList']],[3,'length']],[[2,'+'],[[7],[3,'index']],[1,1]]])
Z([[2,'&&'],[[7],[3,'allShow']],[[2,'>'],[[7],[3,'pageNum']],[1,1]]])
Z([3,'center'])
Z([3,'border:0;'])
Z([[2,'&&'],[[7],[3,'pageList']],[[7],[3,'loadTitle']]])
Z(z[102])
Z(z[103])
Z([[7],[3,'dealActions']])
Z([3,'onCloseActionSheet'])
Z(z[108])
Z([3,'onSelect'])
Z([3,'取消'])
Z([[6],[[7],[3,'selectMsgInfo']],[3,'name']])
Z([[7],[3,'showDeal']])
Z([3,'0'])
Z([[7],[3,'showOverlay']])
Z([3,'wrapper'])
Z(z[11])
Z([3,'130'])
Z([3,'500'])
Z([[7],[3,'rate']])
Z([3,'cancelUpload'])
Z(z[68])
Z([3,'small'])
Z([3,'default'])
Z([3,'clickAgree'])
Z([3,'getPhoneNumber'])
Z(z[111])
Z(z[11])
Z([[2,'?:'],[[7],[3,'clickAgree']],[1,'getPhoneNumber'],[1,'']])
Z([3,'确定'])
Z([[7],[3,'showPhone']])
Z([3,'绑定手机号'])
Z([3,'myPrivacy'])
})(__WXML_GLOBAL__.ops_cached.$gwx_XC_25_1);return __WXML_GLOBAL__.ops_cached.$gwx_XC_25_1
}
__WXML_GLOBAL__.ops_set.$gwx_XC_25=z;
__WXML_GLOBAL__.ops_init.$gwx_XC_25=true;
var x=['./pages/file/cloudFile/index.wxml'];d_[x[0]]={}
var m0=function(e,s,r,gg){
var z=gz$gwx_XC_25_1()
var ePF=_v()
_(r,ePF)
if(_oz(z,0,e,s,gg)){ePF.wxVkey=1
var bQF=_mz(z,'van-notice-bar',['bind:close',1,'leftIcon',1,'mode',2,'scrollable',3,'text',4],[],e,s,gg)
_(ePF,bQF)
}
var oRF=_mz(z,'van-dialog',['showCancelButton',-1,'showConfirmButton',-1,'bind:cancel',6,'bind:confirm',1,'cancelButtonColor',2,'cancelButtonText',3,'closeOnClickOverlay',4,'confirmButtonColor',5,'confirmButtonText',6,'message',7,'overlay',8,'show',9,'title',10],[],e,s,gg)
_(r,oRF)
var xSF=_n('view')
var oTF=_v()
_(xSF,oTF)
if(_oz(z,17,e,s,gg)){oTF.wxVkey=1
}
var fUF=_n('view')
_rz(z,fUF,'style',18,e,s,gg)
var cVF=_mz(z,'van-transition',['duration',19,'name',1,'show',2],[],e,s,gg)
var hWF=_mz(z,'van-icon',['bindtap',22,'name',1,'size',2],[],e,s,gg)
_(cVF,hWF)
_(fUF,cVF)
var oXF=_n('view')
_rz(z,oXF,'style',25,e,s,gg)
var cYF=_mz(z,'van-icon',['bind:click',26,'color',1,'name',2,'size',3,'style',4],[],e,s,gg)
_(oXF,cYF)
var oZF=_mz(z,'van-icon',['bind:click',31,'classPrefix',1,'color',2,'name',3,'size',4,'style',5],[],e,s,gg)
_(oXF,oZF)
var l1F=_mz(z,'van-icon',['bindtap',37,'classPrefix',1,'name',2,'size',3,'style',4],[],e,s,gg)
_(oXF,l1F)
_(fUF,oXF)
_(xSF,fUF)
var a2F=_n('view')
var x7F=_mz(z,'van-transition',['duration',42,'name',1,'show',2],[],e,s,gg)
var o8F=_v()
_(x7F,o8F)
if(_oz(z,45,e,s,gg)){o8F.wxVkey=1
var f9F=_mz(z,'van-search',['showAction',-1,'bind:cancel',46,'bind:change',1,'bind:search',2,'disabled',3,'placeholder',4,'shape',5,'value',6],[],e,s,gg)
_(o8F,f9F)
}
o8F.wxXCkey=1
o8F.wxXCkey=3
_(a2F,x7F)
var t3F=_v()
_(a2F,t3F)
if(_oz(z,53,e,s,gg)){t3F.wxVkey=1
}
var e4F=_v()
_(a2F,e4F)
if(_oz(z,54,e,s,gg)){e4F.wxVkey=1
var c0F=_mz(z,'van-icon',['bindtap',55,'classPrefix',1,'color',2,'name',3,'size',4,'style',5],[],e,s,gg)
_(e4F,c0F)
}
var hAG=_mz(z,'van-popup',['round',-1,'bind:after-enter',61,'bind:close',1,'customStyle',2,'position',3,'show',4],[],e,s,gg)
var oBG=_n('view')
_rz(z,oBG,'class',66,e,s,gg)
var lEG=_mz(z,'van-icon',['bindtap',67,'name',1,'size',2,'style',3],[],e,s,gg)
_(oBG,lEG)
var cCG=_v()
_(oBG,cCG)
if(_oz(z,71,e,s,gg)){cCG.wxVkey=1
}
var oDG=_v()
_(oBG,oDG)
if(_oz(z,72,e,s,gg)){oDG.wxVkey=1
}
cCG.wxXCkey=1
oDG.wxXCkey=1
_(hAG,oBG)
_(a2F,hAG)
var aFG=_v()
_(a2F,aFG)
var tGG=function(bIG,eHG,oJG,gg){
var oLG=_v()
_(oJG,oLG)
if(_oz(z,76,bIG,eHG,gg)){oLG.wxVkey=1
var fMG=_v()
_(oLG,fMG)
if(_oz(z,77,bIG,eHG,gg)){fMG.wxVkey=1
}
fMG.wxXCkey=1
}
oLG.wxXCkey=1
return oJG
}
aFG.wxXCkey=2
_2z(z,73,tGG,e,s,gg,aFG,'item','index','_id')
var cNG=_v()
_(a2F,cNG)
var hOG=function(cQG,oPG,oRG,gg){
var tUG=_mz(z,'view',['bindtap',81,'bindtouchend',1,'bindtouchstart',2,'class',3,'data-id',4,'data-index',5,'style',6],[],cQG,oPG,gg)
var eVG=_mz(z,'image',['bindload',88,'data-index',1,'data-need',2,'lazyLoad',3,'src',4,'style',5],[],cQG,oPG,gg)
var bWG=_v()
_(eVG,bWG)
if(_oz(z,94,cQG,oPG,gg)){bWG.wxVkey=1
var oXG=_mz(z,'view',['id',95,'style',1],[],cQG,oPG,gg)
var xYG=_v()
_(oXG,xYG)
if(_oz(z,97,cQG,oPG,gg)){xYG.wxVkey=1
}
var oZG=_v()
_(oXG,oZG)
if(_oz(z,98,cQG,oPG,gg)){oZG.wxVkey=1
}
var f1G=_v()
_(oXG,f1G)
if(_oz(z,99,cQG,oPG,gg)){f1G.wxVkey=1
}
xYG.wxXCkey=1
oZG.wxXCkey=1
f1G.wxXCkey=1
_(bWG,oXG)
}
bWG.wxXCkey=1
_(tUG,eVG)
_(oRG,tUG)
var aTG=_v()
_(oRG,aTG)
if(_oz(z,100,cQG,oPG,gg)){aTG.wxVkey=1
}
aTG.wxXCkey=1
return oRG
}
cNG.wxXCkey=2
_2z(z,78,hOG,e,s,gg,cNG,'item','index','_id')
var b5F=_v()
_(a2F,b5F)
if(_oz(z,101,e,s,gg)){b5F.wxVkey=1
var c2G=_mz(z,'van-divider',['dashed',-1,'contentPosition',102,'customStyle',1],[],e,s,gg)
_(b5F,c2G)
}
var o6F=_v()
_(a2F,o6F)
if(_oz(z,104,e,s,gg)){o6F.wxVkey=1
var h3G=_mz(z,'van-divider',['dashed',-1,'contentPosition',105,'customStyle',1],[],e,s,gg)
_(o6F,h3G)
}
var o4G=_mz(z,'van-action-sheet',['actions',107,'bind:cancel',1,'bind:close',2,'bind:select',3,'cancelText',4,'description',5,'show',6],[],e,s,gg)
_(a2F,o4G)
t3F.wxXCkey=1
e4F.wxXCkey=1
e4F.wxXCkey=3
b5F.wxXCkey=1
b5F.wxXCkey=3
o6F.wxXCkey=1
o6F.wxXCkey=3
_(xSF,a2F)
var c5G=_mz(z,'van-overlay',['duration',114,'show',1],[],e,s,gg)
var o6G=_n('view')
_rz(z,o6G,'class',116,e,s,gg)
var l7G=_mz(z,'van-circle',['color',117,'size',1,'speed',2,'value',3],[],e,s,gg)
_(o6G,l7G)
var a8G=_mz(z,'van-button',['round',-1,'bindtap',121,'icon',1,'size',2,'type',3],[],e,s,gg)
_(o6G,a8G)
_(c5G,o6G)
_(xSF,c5G)
var t9G=_mz(z,'van-dialog',['showCancelButton',-1,'useSlot',-1,'bind:confirm',125,'bind:getphonenumber',1,'cancelButtonText',2,'confirmButtonColor',3,'confirmButtonOpenType',4,'confirmButtonText',5,'show',6,'title',7],[],e,s,gg)
_(xSF,t9G)
oTF.wxXCkey=1
_(r,xSF)
var e0G=_n('my-privacy')
_rz(z,e0G,'id',133,e,s,gg)
_(r,e0G)
ePF.wxXCkey=1
ePF.wxXCkey=3
return r
}
e_[x[0]]={f:m0,j:[],i:[],ti:[],ic:[]}
if(path&&e_[path]){
return function(env,dd,global){$gwxc=0;var root={"tag":"wx-page"};root.children=[]
;g="$gwx_XC_25";var main=e_[path].f
if (typeof global==="undefined")global={};global.f=$gdc(f_[path],"",1);
try{
main(env,{},root,global);
_tsd(root)
}catch(err){
console.log(err)
}
;g="";
return root;
}
}
}
}(__g.a,__g.b,__g.c,__g.d,__g.e,__g.f,__g.g,__g.h,__g.i,__g.j,__g.k,__g.l,__g.m,__g.n,__g.o,__g.p,__g.q,__g.r,__g.s,__g.t,__g.u,__g.v,__g.w,__g.x,__g.y,__g.z,__g.A,__g.B,__g.C,__g.D,__g.E,__g.F,__g.G,__g.H,__g.I,__g.J,__g.K,__g.L,__g.M,__g.N,__g.O,__g.P,__g.Q,__g.R,__g.S,__g.T,__g.U,__g.V,__g.W,__g.X,__g.Y,__g.Z,__g.aa);if(__vd_version_info__.delayedGwx||false)$gwx_XC_25();	if (__vd_version_info__.delayedGwx) __wxAppCode__['pages/file/cloudFile/index.wxml'] = [$gwx_XC_25, './pages/file/cloudFile/index.wxml'];else __wxAppCode__['pages/file/cloudFile/index.wxml'] = $gwx_XC_25( './pages/file/cloudFile/index.wxml' );
	;__wxRoute = "pages/file/cloudFile/index";__wxRouteBegin = true;__wxAppCurrentFile__="pages/file/cloudFile/index.js";define("pages/file/cloudFile/index.js",function(require,module,exports,window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){
"use strict";var e=require("../../../@babel/runtime/helpers/typeof");wx.cloud.init();var t=wx.cloud.database(),a=t.command,o=t.collection("files"),n=t.collection("msg_user"),i=t.collection("user_inc_id"),s=require("../../../components/cos/cos-wx-sdk-v5.min"),c=void 0,d=void 0;Page({data:{parasitifer:"",showSearch:!1,showPhone:!1,showDialog:!1,showOriginUrlPopup:!1,showOriginUrlPopupTextarea:!1,originUrlPopupTextareaFocus:!1,webviewBack:!1,extension:["doc","docx","xls","xlsx","ppt","pptx","pdf","txt","zip","rar","7z","mp3","mid","wav","wma","DOC","DOCX","XLS","XLSX","PPT","PPTX","PDF","TXT","ZIP","RAR","7Z","MP3","MID","WAV","WMA"],showOverlay:!1,rate:0,openid:"",loadTitle:"",currentItemId:"",src:"",showPopupTextarea:!1,focus:!1,pageNum:1,pageSize:20,allShow:!1,showEdit:!1,showDeal:!1,_index:0,_id:"",msgName:"",msgID:"",pwd:"",source:"",readOnly:!1,pageList:null,msgPopTitle:"文件设置",selectMsgInfo:{},dealActions:[{name:"查看",index:0},{name:"设置(名字/简介/密码/只读)",index:1},{name:"修改(替换)文件",index:6},{name:"复制路径",index:2,className:"important-action"},{name:"复制快捷粘贴",index:12,className:"important-action"},{name:"海报",index:10},{name:"二维码",index:7},{name:"复制自动回复",index:11},{name:"删除",index:4,color:"red"}],userInfo:void 0,searchKey:"",systemInfo:{},addtip:"",clickAgree:!1,typeImgWidth:90,typeImgInnerWidth:0,need:!0,typeImgFontScale:1},toNotice:function(){var e="/pages/webview/webview?url="+encodeURIComponent("https://zhijiebohao-4gp9aizse6797bd3-1257150849.tcloudbaseapp.com/gzh.html?miniAppId=wx5c9674e6177b0f6a&miniEnvId=zhijiebohao-4gp9aizse6797bd3&authorized="+(!(!this.data.userInfo||!this.data.userInfo.xzffw_openid)||"")+"&type=file");wx.navigateTo({url:e})},toRecycle:function(){this.setData({webviewBack:!0}),wx.navigateTo({url:"/vantPage/recycle/recycle"})},clickAgreeChange:function(e){this.setData({clickAgree:!this.data.clickAgree})},closeAddTipNoticeBar:function(){var e=this;n.doc(e.data.userInfo._id).update({data:{addTipShowed:!0},success:function(t){e.setData({addtip:""})}})},showSearch:function(){this.setData({showSearch:!0})},showProtocol:function(){wx.navigateTo({url:"/pages/methodD/methodD?id=18"})},showPrivacy:function(){wx.navigateTo({url:"/pages/methodD/methodD?id=19"})},delRec:function(){wx.navigateTo({url:"/pages/webview/webview?url=https://bohao.wsqytec.com/delRecovery.html"})},showOriginUrlPopup:function(){this.setData({showOriginUrlPopup:!0})},showOriginUrlPopupAfter:function(){var e=this;e.setData({showOriginUrlPopupTextarea:!0},(function(){e.setData({originUrlPopupTextareaFocus:!0})}))},onCloseOriginUrlPopup:function(){this.setData({showOriginUrlPopup:!1,showOriginUrlPopupTextarea:!1,originUrlPopupTextareaFocus:!1})},originUrlChange:function(e){var t=this.data.selectMsgInfo;t.originUrl=e.detail.value,this.setData({selectMsgInfo:t})},onSubmitOriginUrl:function(){var e=this,t=e.data.selectMsgInfo,a=t.originUrl;a||(a=""),""==(a=a.replace(/\s*/g,""))||0==a.indexOf("https://mp.weixin.qq.com/s/")?o.doc(t._id).update({data:{originUrl:a},success:function(a){var o=e.data.pageList;o[e.data._index]=t,e.setData({pageList:o}),e.onCloseOriginUrlPopup(),wx.showToast({title:"保存成功！",icon:"none"})}}):wx.showToast({title:"请粘贴文章的原始链接！",icon:"none",duration:3e3})},howToRelative:function(){wx.navigateTo({url:"/pages/methodD/methodD?id=12"})},howToGetUrl:function(){wx.navigateTo({url:"/pages/methodD/methodD?id=13"})},buy:function(){wx.navigateTo({url:"/pages/methodD/methodD?id=6"})},addFileData:function(e,t,a,n,i,s){var c=this;o.add({data:{_id:e,name:t,size:a,fileID:n,createTime:i,readCount:0,downloadCount:0,msgID:"",pwd:"",source:"",readOnly:!1,unionid:s,del_flag:!1}}).then((function(e){c.getData(!0),c.setData({showOverlay:!1,rate:0}),wx.showToast({title:"保存成功",icon:"none"}),e._id&&wx.cloud.callFunction({name:"addIpProvince",data:{db:"files",id:e._id}})}))},toQuestion:function(){wx.navigateTo({url:"/vantPage/question/question?type=0"})},initCOS:function(){wx.cloud.callFunction({name:"cosSts",complete:function(e){c=new s({getAuthorization:function(t,a){a({TmpSecretId:e.result.credentials.tmpSecretId,TmpSecretKey:e.result.credentials.tmpSecretKey,SecurityToken:e.result.credentials.sessionToken,StartTime:e.result.startTime,ExpiredTime:e.result.expiredTime})}})}})},chooseFileUploadDo:function(e,t){var a=this,n=52428800,i="单个文件大小限制：50M！";if(a.data.userInfo&&a.data.userInfo.isGov&&(n*=4,i="单个文件大小限制：200M！"),t.size>n)wx.showToast({title:i,icon:"none",duration:3e3});else if(0!=t.size){var s=a.data.extension,r=t.name.lastIndexOf("."),l=t.name.substr(r+1);if(s.indexOf(l)<0)wx.showToast({title:"限制格式："+s.join(", ")+"!",icon:"none",duration:3e3});else{wx.showLoading({title:"名字检测中",mask:!0});var u=a.getUUID();wx.cloud.callFunction({name:"msgSecCheck",data:{content:t.name,type:"files",id:e&&e.currentTarget?u:e||""}}).then((function(n){if(wx.hideLoading(),0==n.result.errCode){a.setData({showOverlay:!0});var i="file/"+a.data.openid+"/"+u+"."+l;c.uploadFile({Bucket:"lg-h5g2gu1y-1257150849",Region:"ap-shanghai",Key:i,FilePath:t.path,FileSize:t.size,SliceSize:5242880,onTaskReady:function(e){d=e},onProgress:function(e){a.setData({rate:(100*e.percent).toFixed(1)})}},(function(n,i){if(i){d=void 0;var s=a.renderSize(t.size),c=a.formatTime(new Date);e&&e.currentTarget?a.addFileData(u,t.name,s,i.Location.replace("lg-h5g2gu1y-1257150849.cos.ap-shanghai.myqcloud.com","cos.wsqytec.com"),c,a.data.userInfo.unionid?a.data.userInfo.unionid:a.data.userInfo.reAuth.unionid):e&&(u=e,o.doc(u).update({data:{name:t.name,size:s,fileID:i.Location.replace("lg-h5g2gu1y-1257150849.cos.ap-shanghai.myqcloud.com","cos.wsqytec.com")},success:function(e){var o=a.data.selectMsgInfo;o.name=t.name,o.size=s,o.fileID=i.Location.replace("lg-h5g2gu1y-1257150849.cos.ap-shanghai.myqcloud.com","cos.wsqytec.com");var n=a.data.pageList;n[a.data._index]=o,a.setData({pageList:n}),a.onClosePopup(),a.setData({showOverlay:!1,rate:0}),wx.showToast({title:"替换保存成功",icon:"none"})}}))}else a.cancelUpload(null,"上传失败，网络异常！"),a.initCOS()}))}else wx.showToast({title:"名字存在违法违规风险，请重新上传！",icon:"none",duration:3e3})}))}}else wx.showToast({title:"不支持上传空文件",icon:"none",duration:3e3})},cancelUpload:function(e,t){var a=this;if(d){c.cancelTask(d),d=void 0;var o=setTimeout((function(){a.setData({showOverlay:!1,rate:0},(function(){clearTimeout(o),wx.showToast({title:t||"已取消",icon:"none"})}))}),500)}},chooseFile:function(e){var t=this,a="windows"==t.data.systemInfo.platform||"mac"==t.data.systemInfo.platform;if(a||!t.data.parasitifer||"微信"==t.data.parasitifer)if(t.data.userInfo.phone&&t.data.userInfo.agreeProtocol)if(a){t.setData({webviewBack:!0});var o="https://zhijiebohao-4gp9aizse6797bd3-1257150849.tcloudbaseapp.com/uploadByCosUrlWithStaticWeb-v1.html?miniAppId=wx5c9674e6177b0f6a&miniEnvId=zhijiebohao-4gp9aizse6797bd3&tabPage=/pages/file/cloudFile/index&openId="+t.data.openid+"&updateId="+(e&&e.currentTarget?"":e.id)+"&updateName="+(e&&e.currentTarget?"":e.name);wx.navigateTo({url:"/pages/webview/webview?url="+encodeURIComponent(o)})}else wx.chooseMessageFile({count:1,type:"file",extension:t.data.extension,success:function(a){var o=a.tempFiles[0];t.chooseFileUploadDo(e&&e.currentTarget?e:e.id,o)},fail:function(e){}});else t.setData({showPhone:!0});else wx.showToast({title:"不支持在"+t.data.parasitifer+"中上传，请发送分享到微信中使用！",icon:"none"})},activeStart:function(e){this.setData({currentItemId:e.currentTarget.dataset.id})},activeEnd:function(){this.setData({currentItemId:""})},onSearchChange:function(e){this.setData({searchKey:e.detail})},onSearch:function(){this.getData(!0)},onSearchCancel:function(){this.setData({searchKey:"",showSearch:!1}),this.getData(!0)},inputMsgName:function(e){this.setData({msgName:e.detail.value})},inputMsgID:function(e){this.setData({msgID:e.detail.value})},inputPwd:function(e){this.setData({pwd:e.detail.value})},readOnlyChange:function(e){this.setData({readOnly:e.detail.value})},inputSource:function(e){this.setData({source:e.detail.value})},onSubmit:function(){var e=this;e.data.msgName?(wx.showLoading({title:"名字检测中",mask:!0}),wx.cloud.callFunction({name:"msgSecCheck",data:{content:e.data.msgName+e.data.msgID+e.data.source,type:"files",id:e.data._id}}).then((function(t){wx.hideLoading(),0==t.result.errCode?e.onSubmitDo():wx.showToast({title:"名字存在违法违规风险，请重新输入！",icon:"none",duration:3e3})}))):wx.showToast({title:"请输入文件名字！",icon:"none"})},onSubmitDo:function(){var e=this;o.doc(e.data._id).update({data:{name:e.data.msgName,msgID:e.data.msgID,pwd:e.data.pwd,source:e.data.source,readOnly:e.data.readOnly},success:function(t){var a=e.data.selectMsgInfo;a.name=e.data.msgName,a.msgID=e.data.msgID,a.pwd=e.data.pwd,a.source=e.data.source,a.readOnly=e.data.readOnly;var o=e.data.pageList;o[e.data._index]=a,e.setData({pageList:o},(function(){a.pwd&&a.readOnly&&e.resetTypeImgFontScale(e.data._index,e.data.typeImgInnerWidth,e.data.typeImgFontScale)})),e.onClosePopup(),wx.showToast({title:"修改成功",icon:"none"})}})},getData:function(e){var t=this;wx.stopPullDownRefresh();var a="加载中...";e&&(a="刷新中...",this.setData({pageNum:1,allShow:!1})),wx.showNavigationBarLoading&&wx.showNavigationBarLoading(),this.setData({loadTitle:a}),wx.cloud.callFunction({name:"getFileData",data:{id:null,pageNum:this.data.pageNum,pageSize:this.data.pageSize,searchKey:this.data.searchKey}}).then((function(a){if(wx.hideNavigationBarLoading&&wx.hideNavigationBarLoading(),0==a.result.data.length&&t.setData({allShow:!0}),a.result.data.map((function(e){return e.typeImg=t.judgeTypeImg(e.fileID),e})),e)t.setData({pageList:a.result.data});else{var o=[];t.data.pageList&&(o=t.data.pageList),t.setData({pageList:o.concat(a.result.data)})}t.setData({loadTitle:""})}))},onReachBottom:function(){this.data.allShow||(this.setData({pageNum:this.data.pageNum+1}),this.getData())},showPopupAfter:function(){var e=this;e.setData({showPopupTextarea:!0},(function(){e.setData({focus:!0})}))},showPopup:function(){this.setData({showEdit:!0})},showActionSheet:function(e){var t=this.data.pageList[e.currentTarget.dataset.index];"loading"!=t._id&&this.setData({showDeal:!0,selectMsgInfo:JSON.parse(JSON.stringify(t)),_index:e.currentTarget.dataset.index})},showExample:function(e){wx.navigateTo({url:"/file/down?id="+e.currentTarget.dataset.id})},onClosePopup:function(){var e=this;e.setData({showEdit:!1,focus:!1}),setTimeout((function(){e.setData({msgName:"",_id:"",msgID:"",pwd:"",source:"",readOnly:!1,msgPopTitle:"文件设置"})}),500)},onCloseActionSheet:function(){this.setData({showDeal:!1})},onSelect:function(e){var t=this;switch(e.detail.index){case 12:"windows"==t.data.systemInfo.platform||"mac"==t.data.systemInfo.platform?wx.navigateTo({url:"/pages/webview/webview?url="+encodeURIComponent("https://zhijiebohao-4gp9aizse6797bd3-1257150849.tcloudbaseapp.com/copyToEditor.html?appId=wx5c9674e6177b0f6a&name="+encodeURIComponent(t.data.selectMsgInfo.name)+"&path="+encodeURIComponent("file/down?id="+t.data.selectMsgInfo._id))}):wx.showToast({title:"此功能仅支持在电脑端小程序中使用",icon:"none",duration:3e3});break;case 0:wx.navigateTo({url:"/file/down?id="+t.data.selectMsgInfo._id});break;case 1:t.setData({msgName:t.data.selectMsgInfo.name,_id:t.data.selectMsgInfo._id,fileID:t.data.selectMsgInfo.fileID,msgID:t.data.selectMsgInfo.msgID,pwd:t.data.selectMsgInfo.pwd,source:t.data.selectMsgInfo.source,readOnly:t.data.selectMsgInfo.readOnly,msgPopTitle:"文件设置"}),t.showPopup();break;case 2:wx.setClipboardData({data:"file/down?id="+t.data.selectMsgInfo._id,success:function(){wx.hideLoading(),wx.showToast({title:"路径复制成功",icon:"none"})}});break;case 6:t.chooseFile({id:t.data.selectMsgInfo._id,name:t.data.selectMsgInfo.name});break;case 3:break;case 10:wx.setStorageSync("full_info_"+t.data.selectMsgInfo._id,JSON.stringify(t.data.selectMsgInfo)),wx.navigateTo({url:"/vantPage/filePoster/filePoster?id="+t.data.selectMsgInfo._id});break;case 7:t.setData({showDialog:!0});break;case 4:wx.showModal({title:"确定要删除该文件吗？",content:"【特别注意】如果文件已添加到文章或菜单等地方，删除后读者将无法查看！",success:function(e){e.confirm&&o.doc(t.data.selectMsgInfo._id).update({data:{del_flag:!0,delTime:new Date},success:function(e){var a=t.data.pageList;a.splice(t.data._index,1),t.setData({pageList:a}),wx.showToast({title:"删除成功",icon:"none"})}})}});break;case 5:break;case 9:t.showOriginUrlPopup();break;case 11:var a=t.data.selectMsgInfo,n="/file/down?id="+a._id,i="https://bohao.wsqytec.com/f.html?id="+a._id,s=a.name,c='<a data-miniprogram-appid="autoMsgAppId" data-miniprogram-path="autoMsgPath" data-miniprogram-type="text" href="autoWebsite">autoMsgContent</a>'.replace(new RegExp("autoMsgAppId","g"),"wx5c9674e6177b0f6a").replace(new RegExp("autoMsgPath","g"),n).replace(new RegExp("autoWebsite","g"),i).replace(new RegExp("autoMsgContent","g"),s);wx.setClipboardData({data:c,success:function(){wx.hideLoading(),wx.showToast({title:"自动回复内容复制成功，请先确保已关联小程序小正方助手",icon:"none"})}})}},dialogGetQr:function(e){"confirm"==e.type?this.getQr():(e.type="cancel")&&this.getQr("old")},getQr:function(e){var t=this;wx.showLoading({title:"生成中",mask:!0});var a={scene:t.data.selectMsgInfo._id,page:"file/down"};e&&"old"==e&&(a={type:e,content:"https://bohao.wsqytec.com/f.html?id="+t.data.selectMsgInfo._id}),wx.cloud.callFunction({name:"getUnlimitedCode",data:a,success:function(a){if(wx.hideLoading(),0==a.result.errCode){var o=wx.getFileSystemManager(),n=wx.env.USER_DATA_PATH+"/"+(e?e+"qr":"wxacode")+".png";o.writeFile({filePath:n,data:a.result.buffer,encoding:"binary",success:function(){t.setData({src:n},(function(){t.savedownloadFile()}))}})}else wx.showToast({title:"网络异常，请稍后重试。",icon:"none",mask:!0})},fail:function(){wx.hideLoading(),wx.showToast({title:"网络异常，请稍后重试。",icon:"none",mask:!0})}})},onShow:function(){this.data.webviewBack&&(this.getData(!0),this.setData({webviewBack:!1}));var e=wx.getEnterOptionsSync();if(1173==e.scene){var t=e.forwardMaterials;t&&t.length>0&&wx.showToast({title:"点击右下角“↑”按钮选择聊天文件上传",icon:"none",duration:3500})}},isForbid:function(){wx.showModal({title:"封禁文件",editable:!0,placeholderText:"请您输入文件路径",success:function(e){if(e.confirm)if(e.content){var t=e.content.split("id=");if(t&&2==t.length){var a=t[1];o.doc(a).update({data:{isForbid:!0},success:function(e){wx.showToast({title:"封禁成功",icon:"none"})}})}else wx.showToast({title:"路径错误",icon:"none"})}else wx.showToast({title:"错误,必须填写文件路径",icon:"none"})}})},isGov:function(){wx.showModal({title:"免广告设置",editable:!0,placeholderText:"请您输入文件路径",success:function(e){if(e.confirm)if(e.content){var t=e.content.split("id=");if(t&&2==t.length){var a=t[1];o.doc(a).update({data:{isGov:!0},success:function(e){wx.showToast({title:"免广告成功",icon:"none"})}})}else wx.showToast({title:"路径错误",icon:"none"})}else wx.showToast({title:"错误,必须填写文件路径",icon:"none"})}})},resetTypeImgFontScale:function(e,t,a){var o=this;try{wx.createSelectorQuery().select("#typeImgFont_"+e).boundingClientRect((function(n){var i=a-.05;n&&n.width>t&&i>.5&&o.setData({typeImgFontScale:i},(function(){o.resetTypeImgFontScale(e,t,i)}))})).exec()}catch(e){}},calcTypeImgFontScale:function(e){var t=this;if(0!=t.data.typeImgInnerWidth){if(t.data.need&&e.currentTarget.dataset.need){var a=e.currentTarget.dataset.index;t.resetTypeImgFontScale(a,t.data.typeImgInnerWidth,t.data.typeImgFontScale),t.setData({need:!1})}}else var o=setTimeout((function(){t.calcTypeImgFontScale(e),clearTimeout(o)}),100)},onLoad:function(e){var t=this,o=wx.getSystemInfoSync();t.setData({systemInfo:o,typeImgInnerWidth:o.windowWidth/750*t.data.typeImgWidth*(23/30)-2}),t.getParasitifer(),wx.cloud.callFunction({name:"login",complete:function(e){var o=e.result;t.setData({openid:o.openid,userInfo:o}),t.initCOS(),o.addTipShowed||i.where({_id:a.eq("addtip")}).field({text:!0}).get({success:function(e){if(e&&e.data.length>0){var a=e.data[0];t.setData({addtip:a.text})}}})}}),e.fileID?t.addFileData(e.id,decodeURIComponent(e.name),t.renderSize(e.size),decodeURIComponent(e.fileID),t.formatTime(new Date),e.unionid):t.getData()},getParasitifer:function(){var e=this.data.systemInfo,t="微信";if(e&&e.host&&e.host.appId)switch(e.host.appId){case"wxf0a80d0ac2e82aa7":t="QQ";break;case"wx4706a9fcbbca10f2":t="企业微信";break;case"wx64f9cf5b17af074d":t="QQ浏览器";break;case"wx5cd60c5d4817a188":t="电脑管家";break;default:t="微信"}this.setData({parasitifer:t})},onPageScroll:function(e){e.scrollTop>200&&"云上文件"!=this.navTitle?(this.navTitle="云上文件",wx.setNavigationBarTitle({title:"云上文件"})):e.scrollTop<=200&&"小正方助手"!=this.navTitle&&(this.navTitle="小正方助手",wx.setNavigationBarTitle({title:"小正方助手"}))},clickAgree:function(){if(!this.data.clickAgree)return wx.showToast({title:"请先阅读并勾选文件服务协议",icon:"none"}),void this.setData({showPhone:!0})},getPhoneNumber:function(e){var t=this;wx.hideLoading(),e.detail.cloudID&&(wx.showLoading({title:"获取中",mask:!0}),wx.cloud.callFunction({name:"login",data:{weRunData:wx.cloud.CloudID(e.detail.cloudID),code:!!e.detail.code&&e.detail.code}}).then((function(a){wx.hideLoading();var o=e.detail.code?a.result.phoneInfo.phoneNumber:a.result.event.weRunData.data.phoneNumber;wx.showLoading({title:"绑定中",mask:!0}),n.doc(t.data.userInfo._id).update({data:{phone:o,agreeProtocol:!0},success:function(e){wx.hideLoading();var a=t.data.userInfo;a.phone=o,a.agreeProtocol=!0,t.setData({userInfo:a}),wx.showToast({title:"绑定成功",icon:"none"})}})})))},onPullDownRefresh:function(){this.getData(!0)},onShareAppMessage:function(e){return"button"===e.from?{title:this.data.selectMsgInfo.name,path:"file/down?id="+this.data.selectMsgInfo._id,imageUrl:"cloud://zhijiebohao-4gp9aizse6797bd3.7a68-zhijiebohao-4gp9aizse6797bd3-1257150849/file.png"}:{title:"上传文件，多场景使用",imageUrl:"cloud://zhijiebohao-4gp9aizse6797bd3.7a68-zhijiebohao-4gp9aizse6797bd3-1257150849/file.png"}},showModal:function(){var e=this;wx.showModal({title:"检测到您没有打开保存到相册的权限，是否前往设置打开？",success:function(t){t.confirm?e.onOpenSetting():t.cancel}})},onOpenSetting:function(){var e=this;wx.openSetting({success:function(t){t.authSetting["scope.writePhotosAlbum"]?e.savedownloadFile():wx.showToast({title:"您未授权",icon:"none"})}})},savedownloadFile:function(){var e=this;wx.saveImageToPhotosAlbum({filePath:e.data.src,success:function(e){wx.showToast({title:"保存成功！",icon:"none"})},fail:function(t){(t.errMsg.indexOf("deny")>-1||t.errMsg.indexOf("denied")>-1||t.errMsg.indexOf("auth")>-1)&&e.showModal()}})},renderSize:function(e){if(null==e||""==e||null==e)return"0 Bytes";var t,a=new Array("Bytes","KB","MB","GB","TB","PB","EB","ZB","YB"),o=parseFloat(e);t=Math.floor(Math.log(o)/Math.log(1024));var n=o/Math.pow(1024,t);return(n=n.toFixed(2))+a[t]},judgeTypeImg:function(e){var t="https://cos.wsqytec.com/file_icon/";switch(e.substr(e.lastIndexOf(".")+1).toLowerCase()){case"doc":case"docx":return t+"word.png";case"xls":case"xlsx":return t+"excel.png";case"ppt":case"pptx":return t+"ppt.png";case"pdf":return t+"pdf.png";case"txt":return t+"txt.png";case"mp3":case"mid":case"wav":case"wma":return t+"mp3.png";case"zip":case"rar":case"7z":return t+"file.png";default:return t+"unkown.png"}},formatTime:function(t,a){if(t){switch(a||(a="yyyy-MM-dd HH:mm"),e(t)){case"string":var o=!1;t.indexOf("T")>-1&&t.indexOf("Z")>-1&&(o=!0,t=t.replace(/T/g," ").substring(0,t.lastIndexOf("."))),t=t.replace(/-/g,"/"),t=new Date(t),o&&(t=new Date(t.getTime()+288e5));break;case"number":t=new Date(t)}if(!(!t instanceof Date)){var n={yyyy:t.getFullYear(),M:t.getMonth()+1,d:t.getDate(),H:t.getHours(),m:t.getMinutes(),s:t.getSeconds(),MM:(""+(t.getMonth()+101)).substr(1),dd:(""+(t.getDate()+100)).substr(1),HH:(""+(t.getHours()+100)).substr(1),mm:(""+(t.getMinutes()+100)).substr(1),ss:(""+(t.getSeconds()+100)).substr(1)};return a.replace(/(yyyy|MM?|dd?|HH?|ss?|mm?)/g,(function(){return n[arguments[0]]}))}}},getUUID:function(){for(var e=[],t=0;t<36;t++)e[t]="0123456789abcdef".substr(Math.floor(16*Math.random()),1);return e[14]="4",e[19]="0123456789abcdef".substr(3&e[19]|8,1),e[8]=e[13]=e[18]=e[23]="-",e.join("").replace(new RegExp("-","g"),"")}});
},{isPage:true,isComponent:true,currentFile:'pages/file/cloudFile/index.js'});require("pages/file/cloudFile/index.js");$gwx_XC_26=function(_,_v,_n,_p,_s,_wp,_wl,$gwn,$gwl,$gwh,wh,$gstack,$gwrt,gra,grb,TestTest,wfor,_ca,_da,_r,_rz,_o,_oz,_1,_1z,_2,_2z,_m,_mz,nv_getDate,nv_getRegExp,nv_console,nv_parseInt,nv_parseFloat,nv_isNaN,nv_isFinite,nv_decodeURI,nv_decodeURIComponent,nv_encodeURI,nv_encodeURIComponent,$gdc,nv_JSON,_af,_gv,_ai,_grp,_gd,_gapi,$ixc,_ic,_w,_ev,_tsd){return function(path,global){
if(typeof global==='undefined'){if (typeof __GWX_GLOBAL__==='undefined')global={};else global=__GWX_GLOBAL__;}if(typeof __WXML_GLOBAL__ === 'undefined') {__WXML_GLOBAL__={};
}__WXML_GLOBAL__.modules = __WXML_GLOBAL__.modules || {};
var e_={}
if(typeof(global.entrys)==='undefined')global.entrys={};e_=global.entrys;
var d_={}
if(typeof(global.defines)==='undefined')global.defines={};d_=global.defines;
var f_={}
if(typeof(global.modules)==='undefined')global.modules={};f_=global.modules || {};
var p_={}
__WXML_GLOBAL__.ops_cached = __WXML_GLOBAL__.ops_cached || {}
__WXML_GLOBAL__.ops_set = __WXML_GLOBAL__.ops_set || {};
__WXML_GLOBAL__.ops_init = __WXML_GLOBAL__.ops_init || {};
var z=__WXML_GLOBAL__.ops_set.$gwx_XC_26 || [];
function gz$gwx_XC_26_1(){
if( __WXML_GLOBAL__.ops_cached.$gwx_XC_26_1)return __WXML_GLOBAL__.ops_cached.$gwx_XC_26_1
__WXML_GLOBAL__.ops_cached.$gwx_XC_26_1=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
Z([3,'showMore'])
Z([3,'#969799'])
Z([3,'ellipsis'])
Z([3,'44rpx'])
Z([3,'background-color: #ffffff;border-radius: 16rpx;overflow: hidden;padding: 24rpx 0;'])
Z([[7],[3,'show']])
Z([[2,'&&'],[[7],[3,'historys']],[[2,'=='],[[6],[[7],[3,'historys']],[3,'length']],[1,0]]])
Z([[7],[3,'historys']])
Z([3,'index'])
Z([1,false])
Z([3,'customClass'])
Z([[2,'?:'],[[2,'=='],[[6],[[7],[3,'item']],[3,'type']],[1,0]],[1,'orders-o'],[[2,'?:'],[[2,'=='],[[6],[[7],[3,'item']],[3,'type']],[1,1]],[1,'chat-o'],[[2,'?:'],[[2,'=='],[[6],[[7],[3,'item']],[3,'type']],[1,2]],[1,'phone-o'],[[2,'?:'],[[2,'=='],[[6],[[7],[3,'item']],[3,'type']],[1,3]],[1,'location-o'],[1,'newspaper-o']]]]])
Z([a,[[6],[[7],[3,'item']],[3,'createTime']],[3,'访问过']])
Z([3,'large'])
Z([[6],[[7],[3,'item']],[3,'name']])
Z([3,'titleClass'])
Z([[6],[[7],[3,'item']],[3,'path']])
Z([[2,'?:'],[[2,'=='],[[6],[[7],[3,'item']],[3,'type']],[1,0]],[1,'文件'],[[2,'?:'],[[2,'=='],[[6],[[7],[3,'item']],[3,'type']],[1,1]],[1,'互动卡'],[[2,'?:'],[[2,'=='],[[6],[[7],[3,'item']],[3,'type']],[1,2]],[1,'电话'],[[2,'?:'],[[2,'=='],[[6],[[7],[3,'item']],[3,'type']],[1,3]],[1,'地址'],[1,'集合']]]]])
Z([[2,'!'],[[7],[3,'show']]])
})(__WXML_GLOBAL__.ops_cached.$gwx_XC_26_1);return __WXML_GLOBAL__.ops_cached.$gwx_XC_26_1
}
__WXML_GLOBAL__.ops_set.$gwx_XC_26=z;
__WXML_GLOBAL__.ops_init.$gwx_XC_26=true;
var x=['./pages/home/home.wxml'];d_[x[0]]={}
var m0=function(e,s,r,gg){
var z=gz$gwx_XC_26_1()
var oBH=_n('van-sticky')
var xCH=_mz(z,'van-icon',['bindtap',0,'color',1,'name',1,'size',2],[],e,s,gg)
_(oBH,xCH)
_(r,oBH)
var oDH=_n('view')
_rz(z,oDH,'style',4,e,s,gg)
var fEH=_v()
_(oDH,fEH)
if(_oz(z,5,e,s,gg)){fEH.wxVkey=1
var hGH=_n('view')
var oHH=_v()
_(hGH,oHH)
if(_oz(z,6,e,s,gg)){oHH.wxVkey=1
}
var cIH=_v()
_(hGH,cIH)
var oJH=function(aLH,lKH,tMH,gg){
var bOH=_mz(z,'van-cell',['isLink',-1,'border',9,'customClass',1,'icon',2,'label',3,'size',4,'title',5,'titleClass',6,'url',7,'value',8],[],aLH,lKH,gg)
_(tMH,bOH)
return tMH
}
cIH.wxXCkey=4
_2z(z,7,oJH,e,s,gg,cIH,'item','index','index')
oHH.wxXCkey=1
_(fEH,hGH)
}
var cFH=_v()
_(oDH,cFH)
if(_oz(z,18,e,s,gg)){cFH.wxVkey=1
}
fEH.wxXCkey=1
fEH.wxXCkey=3
cFH.wxXCkey=1
_(r,oDH)
return r
}
e_[x[0]]={f:m0,j:[],i:[],ti:[],ic:[]}
if(path&&e_[path]){
return function(env,dd,global){$gwxc=0;var root={"tag":"wx-page"};root.children=[]
;g="$gwx_XC_26";var main=e_[path].f
if (typeof global==="undefined")global={};global.f=$gdc(f_[path],"",1);
try{
main(env,{},root,global);
_tsd(root)
}catch(err){
console.log(err)
}
;g="";
return root;
}
}
}
}(__g.a,__g.b,__g.c,__g.d,__g.e,__g.f,__g.g,__g.h,__g.i,__g.j,__g.k,__g.l,__g.m,__g.n,__g.o,__g.p,__g.q,__g.r,__g.s,__g.t,__g.u,__g.v,__g.w,__g.x,__g.y,__g.z,__g.A,__g.B,__g.C,__g.D,__g.E,__g.F,__g.G,__g.H,__g.I,__g.J,__g.K,__g.L,__g.M,__g.N,__g.O,__g.P,__g.Q,__g.R,__g.S,__g.T,__g.U,__g.V,__g.W,__g.X,__g.Y,__g.Z,__g.aa);if(__vd_version_info__.delayedGwx||false)$gwx_XC_26();	if (__vd_version_info__.delayedGwx) __wxAppCode__['pages/home/home.wxml'] = [$gwx_XC_26, './pages/home/home.wxml'];else __wxAppCode__['pages/home/home.wxml'] = $gwx_XC_26( './pages/home/home.wxml' );
	;__wxRoute = "pages/home/home";__wxRouteBegin = true;__wxAppCurrentFile__="pages/home/home.js";define("pages/home/home.js",function(require,module,exports,window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){
"use strict";var e=require("../../@babel/runtime/helpers/typeof"),t=require("../../@babel/runtime/helpers/regeneratorRuntime"),a=require("../../@babel/runtime/helpers/asyncToGenerator");wx.cloud.init();var n,s,i=wx.cloud.database({env:"zhijiebohao-4gp9aizse6797bd3"}),r=i.command;Page({data:{historys:[],show:!1,pageNum:1,pageSize:20,homeMethod:[]},toMethod:function(e){var t=e.currentTarget.dataset.index,a=this.data.homeMethod[t];1==a.type?wx.navigateTo({url:a.url}):2==a.type?wx.navigateToMiniProgram({appId:a.content,path:a.url}):5==a.type?wx.switchTab({url:a.url}):6==a.type?wx.openCustomerServiceChat?wx.openCustomerServiceChat({extInfo:{url:a.url},corpId:a.content,success:function(e){},fail:function(e){wx.showToast({title:"请使用最新版手机微信重试",icon:"none"})}}):wx.showToast({title:"请使用最新版手机微信重试",icon:"none"}):9==a.type?wx.openEmbeddedMiniProgram({path:a.url,appId:a.content}):10==a.type&&wx.setClipboardData({data:a.content})},onPageScroll:function(e){e.scrollTop>200&&"小正方助手"!=this.navTitle?(this.navTitle="小正方助手",wx.setNavigationBarTitle({title:"小正方助手"})):e.scrollTop<=200&&""!=this.navTitle&&(this.navTitle="",wx.setNavigationBarTitle({title:""}))},showMore:function(){this.setData({needRefresh:!0}),wx.navigateTo({url:"/vantPage/simpleHistory/simpleHistory"})},getData:function(e){var t=this;wx.stopPullDownRefresh(),e&&t.setData({pageNum:1}),wx.cloud.callFunction({name:"simpleHistory",data:{pageNum:t.data.pageNum,pageSize:t.data.pageSize}}).then((function(a){var n=a.result;if(n&&n.length>0&&n.map((function(e){e.createTime=t.formatTime(e.createTime)})),e)t.setData({historys:n});else{var s=[];t.data.historys&&(s=t.data.historys),t.setData({historys:s.concat(n)})}t.setData({show:!0})}))},onShow:function(){this.data.needRefresh&&(this.getData(!0),this.setData({needRefresh:!1}))},onLoad:(s=a(t().mark((function e(a){var n;return t().wrap((function(e){for(;;)switch(e.prev=e.next){case 0:n=this,wx.getStorage({key:"methodList",success:function(e){if(e.data){var t=JSON.parse(e.data).filter((function(e){return 1==e.isHome}));n.setData({homeMethod:t})}}}),n.getMethodList(),n.getData(!0);case 4:case"end":return e.stop()}}),e,this)}))),function(e){return s.apply(this,arguments)}),getMethodList:(n=a(t().mark((function e(){var a,n,s,o;return t().wrap((function(e){for(;;)switch(e.prev=e.next){case 0:return(a={}).status=r.eq(!0),e.next=4,i.collection("method_list").where(a).field({_id:!0,name:!0,content:!0,type:!0,url:!0,icon:!0,group:!0,isHome:!0,onlyHome:!0,homeIcon:!0,homeName:!0}).orderBy("sort","asc").get();case 4:n=e.sent,s=n.data,o=s.filter((function(e){return 1==e.isHome})),this.setData({homeMethod:o}),wx.setStorage({key:"methodList",data:JSON.stringify(s)});case 9:case"end":return e.stop()}}),e,this)}))),function(){return n.apply(this,arguments)}),formatTime:function(t,a){if(t){switch(a||(a="yyyy-MM-dd HH:mm"),e(t)){case"string":var n=!1;t.indexOf("T")>-1&&t.indexOf("Z")>-1&&(n=!0,t=t.replace(/T/g," ").substring(0,t.lastIndexOf("."))),t=t.replace(/-/g,"/"),t=new Date(t),n&&(t=new Date(t.getTime()+288e5));break;case"number":t=new Date(t)}if(!(!t instanceof Date)){var s={yyyy:t.getFullYear(),M:t.getMonth()+1,d:t.getDate(),H:t.getHours(),m:t.getMinutes(),s:t.getSeconds(),MM:(""+(t.getMonth()+101)).substr(1),dd:(""+(t.getDate()+100)).substr(1),HH:(""+(t.getHours()+100)).substr(1),mm:(""+(t.getMinutes()+100)).substr(1),ss:(""+(t.getSeconds()+100)).substr(1)};return a.replace(/(yyyy|MM?|dd?|HH?|ss?|mm?)/g,(function(){return s[arguments[0]]}))}}},onShareAppMessage:function(e){return{title:"专业的云服务平台，提供云文件、地址路径、安全通话等服务。",imageUrl:"cloud://zhijiebohao-4gp9aizse6797bd3.7a68-zhijiebohao-4gp9aizse6797bd3-1257150849/share-xzf.jpg"}}});
},{isPage:true,isComponent:true,currentFile:'pages/home/home.js'});require("pages/home/home.js");$gwx_XC_27=function(_,_v,_n,_p,_s,_wp,_wl,$gwn,$gwl,$gwh,wh,$gstack,$gwrt,gra,grb,TestTest,wfor,_ca,_da,_r,_rz,_o,_oz,_1,_1z,_2,_2z,_m,_mz,nv_getDate,nv_getRegExp,nv_console,nv_parseInt,nv_parseFloat,nv_isNaN,nv_isFinite,nv_decodeURI,nv_decodeURIComponent,nv_encodeURI,nv_encodeURIComponent,$gdc,nv_JSON,_af,_gv,_ai,_grp,_gd,_gapi,$ixc,_ic,_w,_ev,_tsd){return function(path,global){
if(typeof global==='undefined'){if (typeof __GWX_GLOBAL__==='undefined')global={};else global=__GWX_GLOBAL__;}if(typeof __WXML_GLOBAL__ === 'undefined') {__WXML_GLOBAL__={};
}__WXML_GLOBAL__.modules = __WXML_GLOBAL__.modules || {};
var e_={}
if(typeof(global.entrys)==='undefined')global.entrys={};e_=global.entrys;
var d_={}
if(typeof(global.defines)==='undefined')global.defines={};d_=global.defines;
var f_={}
if(typeof(global.modules)==='undefined')global.modules={};f_=global.modules || {};
var p_={}
__WXML_GLOBAL__.ops_cached = __WXML_GLOBAL__.ops_cached || {}
__WXML_GLOBAL__.ops_set = __WXML_GLOBAL__.ops_set || {};
__WXML_GLOBAL__.ops_init = __WXML_GLOBAL__.ops_init || {};
var z=__WXML_GLOBAL__.ops_set.$gwx_XC_27 || [];
function gz$gwx_XC_27_1(){
if( __WXML_GLOBAL__.ops_cached.$gwx_XC_27_1)return __WXML_GLOBAL__.ops_cached.$gwx_XC_27_1
__WXML_GLOBAL__.ops_cached.$gwx_XC_27_1=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
Z([[7],[3,'showRes']])
Z([3,''])
Z([[7],[3,'showSet']])
Z([[7],[3,'active']])
Z([3,'#07c160'])
Z([3,'success'])
Z([3,'clickStep'])
Z([3,'vertical'])
Z([3,'rgb(84, 115, 135)'])
Z([[7],[3,'steps']])
Z([[2,'&&'],[[2,'!'],[[7],[3,'miniPath']]],[[2,'!'],[[7],[3,'httpPath']]]])
Z([[7],[3,'editAddressShow']])
Z([3,'margin-left: -16px;margin-right: -16rpx;'])
Z([3,'nameChange'])
Z([1,false])
Z([3,'80'])
Z([3,'名字：'])
Z([3,'请输入名字'])
Z([3,'4em'])
Z([[6],[[7],[3,'location']],[3,'name']])
Z([[7],[3,'addressFocus']])
Z([3,'addressChange'])
Z(z[14])
Z(z[15])
Z([3,'地址：'])
Z([3,'请输入地址'])
Z(z[18])
Z([3,'textarea'])
Z([[6],[[7],[3,'location']],[3,'address']])
Z([3,'longitudeChange'])
Z(z[14])
Z(z[15])
Z([3,'经度：'])
Z([3,'请输入经度'])
Z(z[18])
Z([3,'number'])
Z([[6],[[7],[3,'location']],[3,'longitude']])
Z([3,'latitudeChange'])
Z(z[14])
Z(z[15])
Z([3,'纬度：'])
Z([3,'请输入纬度'])
Z(z[18])
Z(z[35])
Z([[6],[[7],[3,'location']],[3,'latitude']])
Z(z[11])
Z(z[0])
Z([3,'myPrivacy'])
})(__WXML_GLOBAL__.ops_cached.$gwx_XC_27_1);return __WXML_GLOBAL__.ops_cached.$gwx_XC_27_1
}
__WXML_GLOBAL__.ops_set.$gwx_XC_27=z;
__WXML_GLOBAL__.ops_init.$gwx_XC_27=true;
var x=['./pages/icall/icall.wxml'];d_[x[0]]={}
var m0=function(e,s,r,gg){
var z=gz$gwx_XC_27_1()
var xQH=_v()
_(r,xQH)
if(_oz(z,0,e,s,gg)){xQH.wxVkey=1
var oRH=_n('footer')
_(xQH,oRH)
}
var fSH=_n('view')
_rz(z,fSH,'class',1,e,s,gg)
var cTH=_v()
_(fSH,cTH)
if(_oz(z,2,e,s,gg)){cTH.wxVkey=1
var oVH=_n('view')
var cWH=_mz(z,'van-steps',['active',3,'activeColor',1,'activeIcon',2,'bind:click-step',3,'direction',4,'inactiveColor',5,'steps',6],[],e,s,gg)
_(oVH,cWH)
var oXH=_n('view')
var lYH=_v()
_(oXH,lYH)
if(_oz(z,10,e,s,gg)){lYH.wxVkey=1
}
else{lYH.wxVkey=2
var aZH=_n('view')
var t1H=_v()
_(aZH,t1H)
if(_oz(z,11,e,s,gg)){t1H.wxVkey=1
var b3H=_n('view')
_rz(z,b3H,'style',12,e,s,gg)
var o4H=_mz(z,'van-field',['clearable',-1,'bind:change',13,'border',1,'cursorSpacing',2,'label',3,'placeholder',4,'titleWidth',5,'value',6],[],e,s,gg)
_(b3H,o4H)
var x5H=_mz(z,'van-field',['clearable',-1,'autosize',20,'bind:change',1,'border',2,'cursorSpacing',3,'label',4,'placeholder',5,'titleWidth',6,'type',7,'value',8],[],e,s,gg)
_(b3H,x5H)
var o6H=_mz(z,'van-field',['clearable',-1,'bind:change',29,'border',1,'cursorSpacing',2,'label',3,'placeholder',4,'titleWidth',5,'type',6,'value',7],[],e,s,gg)
_(b3H,o6H)
var f7H=_mz(z,'van-field',['clearable',-1,'bind:change',37,'border',1,'cursorSpacing',2,'label',3,'placeholder',4,'titleWidth',5,'type',6,'value',7],[],e,s,gg)
_(b3H,f7H)
_(t1H,b3H)
}
var e2H=_v()
_(aZH,e2H)
if(_oz(z,45,e,s,gg)){e2H.wxVkey=1
}
t1H.wxXCkey=1
t1H.wxXCkey=3
e2H.wxXCkey=1
_(lYH,aZH)
}
lYH.wxXCkey=1
lYH.wxXCkey=3
_(oVH,oXH)
_(cTH,oVH)
}
var hUH=_v()
_(fSH,hUH)
if(_oz(z,46,e,s,gg)){hUH.wxVkey=1
}
cTH.wxXCkey=1
cTH.wxXCkey=3
hUH.wxXCkey=1
_(r,fSH)
var c8H=_n('my-privacy')
_rz(z,c8H,'id',47,e,s,gg)
_(r,c8H)
xQH.wxXCkey=1
xQH.wxXCkey=3
return r
}
e_[x[0]]={f:m0,j:[],i:[],ti:[],ic:[]}
if(path&&e_[path]){
return function(env,dd,global){$gwxc=0;var root={"tag":"wx-page"};root.children=[]
;g="$gwx_XC_27";var main=e_[path].f
if (typeof global==="undefined")global={};global.f=$gdc(f_[path],"",1);
try{
main(env,{},root,global);
_tsd(root)
}catch(err){
console.log(err)
}
;g="";
return root;
}
}
}
}(__g.a,__g.b,__g.c,__g.d,__g.e,__g.f,__g.g,__g.h,__g.i,__g.j,__g.k,__g.l,__g.m,__g.n,__g.o,__g.p,__g.q,__g.r,__g.s,__g.t,__g.u,__g.v,__g.w,__g.x,__g.y,__g.z,__g.A,__g.B,__g.C,__g.D,__g.E,__g.F,__g.G,__g.H,__g.I,__g.J,__g.K,__g.L,__g.M,__g.N,__g.O,__g.P,__g.Q,__g.R,__g.S,__g.T,__g.U,__g.V,__g.W,__g.X,__g.Y,__g.Z,__g.aa);if(__vd_version_info__.delayedGwx||false)$gwx_XC_27();	if (__vd_version_info__.delayedGwx) __wxAppCode__['pages/icall/icall.wxml'] = [$gwx_XC_27, './pages/icall/icall.wxml'];else __wxAppCode__['pages/icall/icall.wxml'] = $gwx_XC_27( './pages/icall/icall.wxml' );
	;__wxRoute = "pages/icall/icall";__wxRouteBegin = true;__wxAppCurrentFile__="pages/icall/icall.js";define("pages/icall/icall.js",function(require,module,exports,window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){
"use strict";wx.cloud.init(),Page({data:{editAddressShow:!1,title:"小正方助手",showSet:!1,showRes:!1,location:null,active:-1,steps:[{text:"第1步",desc:"点击此处选择门店位置"},{text:"第2步",desc:"点击下方结果复制路径"}],miniUrl:"pages/icall/icall?latitude={latitude}&longitude={longitude}&name={name}&address={address}",httpUrl:"https://bohao.wsqytec.com/map.html?latitude={latitude}&longitude={longitude}&name={name}&address={address}",miniPath:"",httpPath:"",systemInfo:wx.getSystemInfoSync()},editAddress:function(){this.setData({editAddressShow:!0})},cancelEditAddress:function(){this.setData({editAddressShow:!1})},addressChange:function(t){var e=this.data.location;e.address=t.detail,this.buildUrl(e)},nameChange:function(t){var e=this.data.location;e.name=t.detail,this.buildUrl(e)},longitudeChange:function(t){var e=this.data.location;e.longitude=Number(t.detail),this.buildUrl(e)},latitudeChange:function(t){var e=this.data.location;e.latitude=Number(t.detail),this.buildUrl(e)},buildUrl:function(t){var e=this.data.miniUrl;e=e.replace("{latitude}",t.latitude).replace("{longitude}",t.longitude).replace("{name}",encodeURIComponent(t.name)).replace("{address}",encodeURIComponent(t.address));var a=this.data.httpUrl;a=a.replace("{latitude}",t.latitude).replace("{longitude}",t.longitude).replace("{name}",encodeURIComponent(t.name)).replace("{address}",encodeURIComponent(t.address)),this.setData({miniPath:e,httpPath:a,active:0,location:t})},clickStep:function(t){var e=this;switch(t.detail){case 0:wx.chooseLocation({success:function(t){e.buildUrl(t)},fail:function(t){t.errMsg.indexOf("deny")>-1&&wx.showModal({title:"检测到您没有打开位置权限，是否前往设置打开？",success:function(t){t.confirm&&wx.openSetting()}})}})}},toView:function(t){if("windows"!=this.data.systemInfo.platform&&"mac"!=this.data.systemInfo.platform)if(t&&t.latitude)wx.openLocation(t);else{if(!this.data.location&&this.data.location.latitude)return void wx.showToast({title:"请先选择地点获取路径",icon:"none"});wx.openLocation(this.data.location)}else wx.showToast({title:"该功能暂不支持电脑操作，请使用手机点击",icon:"none",duration:3e3})},exit:function(){wx.exitMiniProgram&&wx.exitMiniProgram()},toCopyMiniPath:function(){var t=this;t.data.miniPath?wx.setClipboardData({data:t.data.miniPath,success:function(){t.setData({active:1}),wx.hideLoading(),wx.showToast({title:"小正方助手路径复制成功",icon:"none",duration:3e3})}}):wx.showToast({title:"请先选择地点获取路径",icon:"none",duration:3e3})},toCopyHttpPath:function(){var t=this;t.data.httpPath?wx.setClipboardData({data:t.data.httpPath,success:function(){t.setData({active:1}),wx.hideLoading(),wx.showToast({title:"网址路径复制成功",icon:"none"})}}):wx.showToast({title:"请先选择地点获取路径",icon:"none"})},onLoad:function(t){if(t.latitude&&t.longitude){var e={latitude:Number(t.latitude),longitude:Number(t.longitude),name:t.name?decodeURIComponent(t.name):"",address:t.address?decodeURIComponent(t.address):""};this.toView(e),this.setData({showSet:!1,showRes:!0,location:e,title:"一键导航"});var a=this.data.miniUrl;a=a.replace("{latitude}",e.latitude).replace("{longitude}",e.longitude).replace("{name}",encodeURIComponent(e.name)).replace("{address}",encodeURIComponent(e.address)),wx.cloud.callFunction({name:"simpleHistory",data:{type:3,name:e.name,path:"/"+a}}).then((function(t){console.log(t)}))}else this.setData({showSet:!0,showRes:!1});var i=wx.getSystemInfoSync();if(this.setData({systemInfo:i}),wx.setNavigationBarTitle({title:this.data.title}),this.data.showSet){var n=this;this.watch(this,{editAddressShow:function(t){var e=n.data.location.address,a=n.data.location;a.address="",n.setData({location:a}),a.address=e;var i=setTimeout((function(){n.setData({addressFocus:t,location:a}),clearTimeout(i)}),300)}})}},watch:function(t,e){var a=this;Object.keys(e).forEach((function(i){a.observer(t.data,i,t.data[i],(function(a){e[i].call(t,a)}))}))},observer:function(t,e,a,i){Object.defineProperty(t,e,{configurable:!0,enumerable:!0,get:function(){return a},set:function(t){i&&i(t),a=t}})},onShow:function(){}});
},{isPage:true,isComponent:true,currentFile:'pages/icall/icall.js'});require("pages/icall/icall.js");$gwx_XC_28=function(_,_v,_n,_p,_s,_wp,_wl,$gwn,$gwl,$gwh,wh,$gstack,$gwrt,gra,grb,TestTest,wfor,_ca,_da,_r,_rz,_o,_oz,_1,_1z,_2,_2z,_m,_mz,nv_getDate,nv_getRegExp,nv_console,nv_parseInt,nv_parseFloat,nv_isNaN,nv_isFinite,nv_decodeURI,nv_decodeURIComponent,nv_encodeURI,nv_encodeURIComponent,$gdc,nv_JSON,_af,_gv,_ai,_grp,_gd,_gapi,$ixc,_ic,_w,_ev,_tsd){return function(path,global){
if(typeof global==='undefined'){if (typeof __GWX_GLOBAL__==='undefined')global={};else global=__GWX_GLOBAL__;}if(typeof __WXML_GLOBAL__ === 'undefined') {__WXML_GLOBAL__={};
}__WXML_GLOBAL__.modules = __WXML_GLOBAL__.modules || {};
var e_={}
if(typeof(global.entrys)==='undefined')global.entrys={};e_=global.entrys;
var d_={}
if(typeof(global.defines)==='undefined')global.defines={};d_=global.defines;
var f_={}
if(typeof(global.modules)==='undefined')global.modules={};f_=global.modules || {};
var p_={}
__WXML_GLOBAL__.ops_cached = __WXML_GLOBAL__.ops_cached || {}
__WXML_GLOBAL__.ops_set = __WXML_GLOBAL__.ops_set || {};
__WXML_GLOBAL__.ops_init = __WXML_GLOBAL__.ops_init || {};
var z=__WXML_GLOBAL__.ops_set.$gwx_XC_28 || [];
function gz$gwx_XC_28_1(){
if( __WXML_GLOBAL__.ops_cached.$gwx_XC_28_1)return __WXML_GLOBAL__.ops_cached.$gwx_XC_28_1
__WXML_GLOBAL__.ops_cached.$gwx_XC_28_1=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
Z([3,'width:100%;height:100%;box-sizing:border-box;'])
Z([[7],[3,'info']])
Z([[7],[3,'targetMethod']])
Z([3,'position:fixed;left:0;bottom:0;width:100%;background:#ffffff;display: flex;justify-content: center;align-items:center;padding:20rpx 0;'])
Z([[2,'||'],[[2,'||'],[[2,'=='],[[6],[[7],[3,'targetMethod']],[3,'type']],[1,1]],[[2,'=='],[[6],[[7],[3,'targetMethod']],[3,'type']],[1,2]]],[[2,'=='],[[6],[[7],[3,'targetMethod']],[3,'type']],[1,5]]])
Z([[2,'||'],[[2,'=='],[[6],[[7],[3,'targetMethod']],[3,'type']],[1,3]],[[2,'=='],[[6],[[7],[3,'targetMethod']],[3,'type']],[1,4]]])
Z([3,'myPrivacy'])
})(__WXML_GLOBAL__.ops_cached.$gwx_XC_28_1);return __WXML_GLOBAL__.ops_cached.$gwx_XC_28_1
}
__WXML_GLOBAL__.ops_set.$gwx_XC_28=z;
__WXML_GLOBAL__.ops_init.$gwx_XC_28=true;
var x=['./pages/methodD/methodD.wxml'];d_[x[0]]={}
var m0=function(e,s,r,gg){
var z=gz$gwx_XC_28_1()
var o0H=_n('view')
_rz(z,o0H,'style',0,e,s,gg)
var cAI=_v()
_(o0H,cAI)
if(_oz(z,1,e,s,gg)){cAI.wxVkey=1
}
var oBI=_v()
_(o0H,oBI)
if(_oz(z,2,e,s,gg)){oBI.wxVkey=1
var lCI=_n('view')
_rz(z,lCI,'style',3,e,s,gg)
var aDI=_v()
_(lCI,aDI)
if(_oz(z,4,e,s,gg)){aDI.wxVkey=1
}
var tEI=_v()
_(lCI,tEI)
if(_oz(z,5,e,s,gg)){tEI.wxVkey=1
}
aDI.wxXCkey=1
tEI.wxXCkey=1
_(oBI,lCI)
}
cAI.wxXCkey=1
oBI.wxXCkey=1
_(r,o0H)
var eFI=_n('my-privacy')
_rz(z,eFI,'id',6,e,s,gg)
_(r,eFI)
return r
}
e_[x[0]]={f:m0,j:[],i:[],ti:[],ic:[]}
if(path&&e_[path]){
return function(env,dd,global){$gwxc=0;var root={"tag":"wx-page"};root.children=[]
;g="$gwx_XC_28";var main=e_[path].f
if (typeof global==="undefined")global={};global.f=$gdc(f_[path],"",1);
try{
main(env,{},root,global);
_tsd(root)
}catch(err){
console.log(err)
}
;g="";
return root;
}
}
}
}(__g.a,__g.b,__g.c,__g.d,__g.e,__g.f,__g.g,__g.h,__g.i,__g.j,__g.k,__g.l,__g.m,__g.n,__g.o,__g.p,__g.q,__g.r,__g.s,__g.t,__g.u,__g.v,__g.w,__g.x,__g.y,__g.z,__g.A,__g.B,__g.C,__g.D,__g.E,__g.F,__g.G,__g.H,__g.I,__g.J,__g.K,__g.L,__g.M,__g.N,__g.O,__g.P,__g.Q,__g.R,__g.S,__g.T,__g.U,__g.V,__g.W,__g.X,__g.Y,__g.Z,__g.aa);if(__vd_version_info__.delayedGwx||false)$gwx_XC_28();	if (__vd_version_info__.delayedGwx) __wxAppCode__['pages/methodD/methodD.wxml'] = [$gwx_XC_28, './pages/methodD/methodD.wxml'];else __wxAppCode__['pages/methodD/methodD.wxml'] = $gwx_XC_28( './pages/methodD/methodD.wxml' );
	;__wxRoute = "pages/methodD/methodD";__wxRouteBegin = true;__wxAppCurrentFile__="pages/methodD/methodD.js";define("pages/methodD/methodD.js",function(require,module,exports,window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){
"use strict";var t=require("../../@babel/runtime/helpers/regeneratorRuntime"),e=require("../../@babel/runtime/helpers/asyncToGenerator");wx.cloud.init();var a,n,p,r=wx.cloud.database({env:"zhijiebohao-4gp9aizse6797bd3"}),i=r.command;Page({data:{showReplaceCopy:!1,title:"",nodes:"加载中...",info:!1,url:"",name:"",miniInfo:{name:"小正方助手",appid:"wx5c9674e6177b0f6a"},targetMethod:void 0,close_ad:!0,rPhone:"",rName:"",rMsg:"",res:"",focus:!1,systemInfo:{},methodD_5:{_id:"5",close_ad:!1,content:'<div style="line-height: 1.7;font-size:24rpx;margin-top: 5px;">     <p style="font-weight: bold;">免责声明</p>     <p> 　　访问者在接受小正方助手小程序（以下简称本小程序）的服务之前，请务必仔细阅读本条款并同意本声明。访问者访问本小程序的行为以及通过各类方式利用本小程序的行为，都将被视作是对本声明全部内容的无异议的认可;如有异议，请立即跟本小程序协商，并取得本小程序的书面同意意见。     </p><br>     <p> 　　第一条、访问者在从事与本小程序相关的所有行为(包括但不限于访问浏览、利用、转载、宣传介绍)时，必须以善意且谨慎的态度行事，访问者不得故意或者过失的损害或者弱化本小程序的各类合法权利与利益，不得利用本小程序以任何方式直接或者间接的从事违反中国法律、国际公约以及社会公德的行为，且访问者应当恪守下述承诺：     </p><br>     <p>　　1、传输和利用信息符合中国法律、国际公约的规定、符合公序良俗; </p><br>     <p>　　2、不将本小程序以及与之相关的网络服务用作非法用途以及非正当用途; </p><br>     <p>　　3、不干扰和扰乱本小程序以及与之相关的网络服务; </p><br>     <p>　　4、遵守与本小程序以及与之相关的网络服务的协议、规定、程序和惯例等。</p><br>     <p>　　第二条、本小程序郑重提醒访问者：请在转载、上载或者下载有关作品时务必尊重该作品的版权、著作权。</p><br>     <p>　　第三条、本小程序用户原创的作品，作者享有独家版权，未经授权严禁转载或用于其它商业用途。</p><br>     <p>　　第四条、本小程序内容仅代表作者本人的观点，不代表本小程序的观点和看法，与本小程序立场无关，相关责任作者自负。</p><br>     <p>　　第五条、本小程序有权将在本小程序内发表的无版权作品用于其他用途，包括网站、电子杂志等，作品有附带版权声明者除外。</p><br>     <p>　　第六条、未经作者同意，其他任何机构不得以任何形式侵犯其作品著作权，包括但不限于：非法使用或转载，或以任何方式建立作品镜像。</p><br>     <p> 　　第七条、本小程序所刊载的各类形式(包括但不仅限于文字、图片、图表)的作品仅供参考使用，并不代表本小程序同意其说法或描述，仅为提供更多信息，也不构成任何投资建议。对于访问者根据本小程序提供的信息所做出的一切行为，除非另有明确的书面承诺文件，否则本小程序不承担任何形式的责任。     </p><br>     <p>　　第八条、当本小程序不保证使用者查看的任何内容、产品、服务或其他材料的真实性、合法性，对于任何因使用或信赖从此类网站或资源上获取的内容、产品、服务或其他材料而造成(或声称造成)的任何直接或间接损失，本小程序均不承担任何责任。     </p><br>     <p>　　第九条、访问者在本小程序注册时提供的一些个人资料，本小程序除您本人同意及第十条规定外不会将用户的任何资料以任何方式泄露给任何一方。</p><br>     <p>　　第十条、当政府部门、司法机关等依照法定程序要求本小程序披露个人资料时，本小程序将根据执法单位之要求或为公共安全之目的提供个人资料。在此情况下之任何披露，本小程序均得免责。</p><br>     <p>　　第十一条、由于用户将个人密码告知他人或与他人共享注册账户，由此导致的任何个人资料泄露，本小程序不负任何责任。</p> </div> <div style="line-height: 1.7;font-size:24rpx;margin-top: 15px;">     <p style="font-weight: bold;">广告说明</p>     <p style="margin:8px 0;">　　页面偶现弹出广告由微信提供，请访问者自主识别。</p> </div>',name:"免责声明",url:"/pages/methodD/methodD?id=5"},methodD_6:{_id:"6",close_ad:!1,content:'<div style="line-height: 1.75;"><p><span>上传并添加文件，多场景使用，支持doc、docx、xls、xlsx、ppt、pptx、pdf等文件格式（更多格式请将本小程序分享到电脑端微信中使用）。</span></p><br><p>注意：请勿上传违法违规内容，24h审核机制，一经发现，严肃处理！</p><br><p>您可以访问官网查看详细使用教程：https://bohao.wsqytec.com（长按网址复制）<br><br><p style="font-weight: bold;color: #07c160;">基本步骤：</p><p><span>1、将需要上传的文件发送到微信聊天列表。</span></p><p><span>2、在小程序“小正方助手”的“云上文件”页面点击上传。</span></p><p style="margin:8px 0;text-align: center;"><img style="width:75%;"src="https://cos.wsqytec.com/method/article_file/1.jpg"/></p><p><span>3、在弹出的选择聊天界面选择文件。</span></p><p style="margin:8px 0;text-align: center;"><img style="width:75%;"src="https://cos.wsqytec.com/mini_cloud/method/article_file/2.1.jpg"/></p><p><span>4、选择聊天中需要上传的文件。</span></p><p style="margin:8px 0;text-align: center;"><img style="width:75%;"src="https://cos.wsqytec.com/mini_cloud/method/article_file/3.jpg"/></p><p><span>5、上传成功后点击列表中上传的文件，选择“复制路径”。</span></p><p style="margin:8px 0;text-align: center;"><img style="width:75%;"src="https://cos.wsqytec.com/method/article_file/5.jpg"/></p><p><span style="font-weight: bold;line-height:2.5;">文章中使用</span></p><p><span>编辑文章，在需要插入附件的地方选择插入并搜索小程序“小正方助手”，在填写详细信息界面中，小程序路径填写第5步时复制的路径。</span></p><p><span>点击插入小程序，然后去搜索：</span></p><p style="margin:8px 0;text-align: center;"><img src="https://cos.wsqytec.com/mini_cloud/method/article_file/5.png"/></p><p style="margin:8px 0;text-align: center;"><img src="https://cos.wsqytec.com/method/article_file/5.0.png"/></p><p><span>搜索“小正方助手”：</span></p><p style="margin:8px 0;text-align: center;"><img src="https://cos.wsqytec.com/method/article_file/6.jpg"/></p><p><span>小程序路径只需要填写第5步时复制的路径，文字内容随便：</span></p><p style="margin:8px 0;text-align: center;"><img src="https://cos.wsqytec.com/method/article_file/7.jpg"/></p><p><span style="font-weight: bold;line-height:2.5;">菜单上使用</span></p><p><span>先关联小正方助手小程序，添加菜单时选择调跳转小程序到文件路径即可。</span></p></div>',name:"小正方助手小程序",target_method_id:"1",url:"/pages/methodD/methodD?id=6"},methodD_1:{_id:"1",content:"",name:"去上传",type:5,url:"/pages/file/cloudFile/index"}},copyInfo:function(t){wx.setClipboardData({data:t.currentTarget.dataset.value})},staticMethodD:function(t){var e=this,a=e.data["methodD_"+t];e.formatRichTextImg(a.content).then((function(t){e.setData({nodes:t,title:a.name,url:a.url,name:a.name}),wx.setNavigationBarTitle({title:a.name})})),6==t&&e.setData({targetMethod:e.data.methodD_1})},onLoad:(p=e(t().mark((function e(a){var n,p,s,o;return t().wrap((function(t){for(;;)switch(t.prev=t.next){case 0:if(5!=(n=a.id)&&6!=n){t.next=4;break}return this.staticMethodD(n),t.abrupt("return");case 4:p=a.info,s=this,o=wx.getSystemInfoSync(),r.collection("method_list").where({_id:i.eq(n)}).field({name:!0,content:!0,url:!0,target_method_id:!0,close_ad:!0}).get({success:function(t){s.setData({systemInfo:o,close_ad:t.data[0].close_ad});var e=t.data[0].content,a=t.data[0].name,n=t.data[0].url;e?s.formatRichTextImg(e).then((function(t){s.setData({nodes:t,info:p,title:a,url:n,name:a}),wx.setNavigationBarTitle({title:a})})):s.setData({nodes:"空空如也",info:p}),t.data[0].target_method_id&&r.collection("method_list").where({_id:i.eq(t.data[0].target_method_id)}).field({simple_name:!0,content:!0,url:!0,type:!0,name:!0}).get({success:function(t){s.setData({targetMethod:t.data[0]})}})}});case 8:case"end":return t.stop()}}),e,this)}))),function(t){return p.apply(this,arguments)}),toMethod:function(t){var e=this.data.targetMethod;1==e.type?wx.navigateTo({url:e.url}):2==e.type?wx.navigateToMiniProgram({appId:e.content,path:e.url}):5==e.type&&wx.switchTab({url:e.url})},formatRichTextImg:(n=e(t().mark((function e(a){var n,p,r,i,s;return t().wrap((function(t){for(;;)switch(t.prev=t.next){case 0:if(n=new RegExp('(class)="[^"]+"',"g"),a=a.replace(n,"").replace(new RegExp("<img","g"),'<img class="richImg"  ').replace(new RegExp("\ufeff","g"),""),!(p=this.getAllSrc(a))){t.next=8;break}return t.next=6,this.turnImageUrl(p);case 6:for(r=t.sent,i=0;i<r.fileList.length;i++)s=r.fileList[i],a=a.replace(s.fileID,s.tempFileURL);case 8:return t.abrupt("return",a);case 9:case"end":return t.stop()}}),e,this)}))),function(t){return n.apply(this,arguments)}),getAllSrc:function(t){var e=new RegExp("(src|SRC)=(\"|')(.*?)(\"|')","g");try{return t.match(e).map((function(t,e,a){return t.replace("src=","").replace(new RegExp("(\"|')","g"),"")})).filter((function(t){return t.indexOf("cloud://")>-1}))}catch(t){return}},turnImageUrl:(a=e(t().mark((function e(a){var n;return t().wrap((function(t){for(;;)switch(t.prev=t.next){case 0:return t.next=2,wx.cloud.getTempFileURL({fileList:a});case 2:return n=t.sent,t.abrupt("return",n);case 4:case"end":return t.stop()}}),e)}))),function(t){return a.apply(this,arguments)}),onShareAppMessage:function(t){return"button"===t.from&&console.log(t.target),{title:this.data.name,imageUrl:"cloud://zhijiebohao-4gp9aizse6797bd3.7a68-zhijiebohao-4gp9aizse6797bd3-1257150849/share-xzf.jpg",path:this.data.url}}});
},{isPage:true,isComponent:true,currentFile:'pages/methodD/methodD.js'});require("pages/methodD/methodD.js");$gwx_XC_29=function(_,_v,_n,_p,_s,_wp,_wl,$gwn,$gwl,$gwh,wh,$gstack,$gwrt,gra,grb,TestTest,wfor,_ca,_da,_r,_rz,_o,_oz,_1,_1z,_2,_2z,_m,_mz,nv_getDate,nv_getRegExp,nv_console,nv_parseInt,nv_parseFloat,nv_isNaN,nv_isFinite,nv_decodeURI,nv_decodeURIComponent,nv_encodeURI,nv_encodeURIComponent,$gdc,nv_JSON,_af,_gv,_ai,_grp,_gd,_gapi,$ixc,_ic,_w,_ev,_tsd){return function(path,global){
if(typeof global==='undefined'){if (typeof __GWX_GLOBAL__==='undefined')global={};else global=__GWX_GLOBAL__;}if(typeof __WXML_GLOBAL__ === 'undefined') {__WXML_GLOBAL__={};
}__WXML_GLOBAL__.modules = __WXML_GLOBAL__.modules || {};
var e_={}
if(typeof(global.entrys)==='undefined')global.entrys={};e_=global.entrys;
var d_={}
if(typeof(global.defines)==='undefined')global.defines={};d_=global.defines;
var f_={}
if(typeof(global.modules)==='undefined')global.modules={};f_=global.modules || {};
var p_={}
__WXML_GLOBAL__.ops_cached = __WXML_GLOBAL__.ops_cached || {}
__WXML_GLOBAL__.ops_set = __WXML_GLOBAL__.ops_set || {};
__WXML_GLOBAL__.ops_init = __WXML_GLOBAL__.ops_init || {};
var z=__WXML_GLOBAL__.ops_set.$gwx_XC_29 || [];
function gz$gwx_XC_29_1(){
if( __WXML_GLOBAL__.ops_cached.$gwx_XC_29_1)return __WXML_GLOBAL__.ops_cached.$gwx_XC_29_1
__WXML_GLOBAL__.ops_cached.$gwx_XC_29_1=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
Z([[7],[3,'absent']])
Z([[2,'&&'],[[7],[3,'authority']],[[2,'!'],[[6],[[7],[3,'info']],[3,'authorNoticeRead']]]])
Z([3,'#ffffff'])
Z([3,'closeNoticeBar'])
Z([3,'#07c160'])
Z([3,'flag-o'])
Z([3,'closeable'])
Z([3,'30'])
Z([3,'您是作者，可查看和管理全部互动。'])
Z([[7],[3,'show']])
Z([3,'font-size:32rpx;line-height:44rpx;width:100%;box-sizing:border-box;'])
Z([[2,'&&'],[[6],[[7],[3,'info']],[3,'description']],[[2,'!'],[[7],[3,'msgId']]]])
Z([[2,'&&'],[[2,'&&'],[[2,'&&'],[[6],[[7],[3,'info']],[3,'_id']],[[2,'!'],[[6],[[7],[3,'info']],[3,'closeInput']]]],[[2,'!'],[[7],[3,'msgId']]]],[[7],[3,'userInfo']]])
Z([[2,'&&'],[[2,'&&'],[[6],[[7],[3,'info']],[3,'_id']],[[2,'!'],[[6],[[7],[3,'info']],[3,'closeInput']]]],[[2,'!'],[[6],[[7],[3,'info']],[3,'fromMsgcard']]]])
Z([3,'onCloseShowBig'])
Z([3,'showBigClass'])
Z([[7],[3,'showBig']])
Z([[7],[3,'msgListTemp']])
Z([3,'_id'])
Z([[2,'!'],[[6],[[7],[3,'item']],[3,'isHide']]])
Z([3,'showDeal'])
Z([3,'msgContent'])
Z([[7],[3,'index']])
Z([3,'padding:0 16rpx;box-sizing:border-box;'])
Z([3,'msgText'])
Z([3,'nameView'])
Z([3,'display:flex;'])
Z([[6],[[7],[3,'item']],[3,'top']])
Z([3,'#808080'])
Z([3,'display:flex;align-items: center;width:auto;margin-right:6rpx;'])
Z([[2,'!'],[[6],[[7],[3,'item']],[3,'status']]])
Z([3,'#cccccc'])
Z([3,'display:flex;align-items: center;width:auto;margin-left:10rpx;margin-right:6rpx;'])
Z([[6],[[7],[3,'item']],[3,'secret']])
Z(z[4])
Z(z[29])
Z([[2,'>'],[[6],[[7],[3,'item']],[3,'myGoodCount']],[1,0]])
Z([3,'tapGood'])
Z(z[22])
Z([3,'display: flex;align-items: flex-start;'])
Z([3,'lightslategray'])
Z([3,'good-job'])
Z([3,'40rpx'])
Z([3,'display: flex;align-items: center;'])
Z(z[37])
Z(z[22])
Z(z[39])
Z(z[40])
Z([3,'good-job-o'])
Z(z[42])
Z(z[43])
Z([[2,'&&'],[[6],[[7],[3,'item']],[3,'reply']],[[2,'!'],[[6],[[7],[3,'item']],[3,'replyIsHide']]]])
Z([3,'display: flex;align-items: center;justify-content: flex-start;'])
Z([[2,'&&'],[[7],[3,'author']],[[6],[[7],[3,'author']],[3,'avatarUrl']]])
Z([3,'manager-o'])
Z([3,'36rpx'])
Z(z[43])
Z([3,'floorIndex'])
Z([3,'floorItem'])
Z([[6],[[7],[3,'item']],[3,'floorNumber']])
Z([3,'unique'])
Z(z[59])
Z([[2,'&&'],[[2,'&&'],[[6],[[7],[3,'item']],[[2,'+'],[1,'floor'],[[2,'+'],[[7],[3,'floorItem']],[1,1]]]],[[6],[[7],[3,'item']],[[2,'+'],[[2,'+'],[1,'floor'],[[2,'+'],[[7],[3,'floorItem']],[1,1]]],[1,'Type']]]],[[2,'!'],[[6],[[7],[3,'item']],[[2,'+'],[[2,'+'],[1,'floor'],[[2,'+'],[[7],[3,'floorItem']],[1,1]]],[1,'IsHide']]]]])
Z([3,'replyView'])
Z([[2,'=='],[[6],[[7],[3,'item']],[[2,'+'],[[2,'+'],[1,'floor'],[[2,'+'],[[7],[3,'floorItem']],[1,1]]],[1,'Type']]],[1,1]])
Z(z[52])
Z(z[53])
Z(z[54])
Z(z[55])
Z(z[43])
Z([[2,'=='],[[6],[[7],[3,'item']],[[2,'+'],[[2,'+'],[1,'floor'],[[2,'+'],[[7],[3,'floorItem']],[1,1]]],[1,'Type']]],[1,2]])
Z([[2,'&&'],[[7],[3,'allShow']],[[2,'>'],[[7],[3,'pageNum']],[1,1]]])
Z([3,'center'])
Z([3,'border:0;'])
Z([[7],[3,'showNavBarLoding']])
Z([[2,'&&'],[[7],[3,'msgList']],[[2,'=='],[[6],[[7],[3,'msgList']],[3,'length']],[1,0]]])
Z([[6],[[7],[3,'info']],[3,'fromMsgcard']])
Z([[7],[3,'dealActions']])
Z([3,'hideDeal'])
Z(z[78])
Z([3,'onSelect'])
Z([3,'取消'])
Z([a,[3,'@'],[[6],[[7],[3,'selectMsgInfo']],[3,'name']],[3,'的互动']])
Z([[7],[3,'showDeal']])
Z([3,'showToMsgAfter'])
Z([3,'onClosePopupMsg'])
Z([3,'height:92%;'])
Z([3,'bottom'])
Z([[7],[3,'showToMsg']])
Z([3,'writeView'])
Z([3,'display:flex;justify-content:space-between;align-items:center;margin:20rpx 40rpx 30rpx 40rpx;'])
Z([[2,'&&'],[[7],[3,'userInfo']],[[6],[[7],[3,'userInfo']],[3,'_openid']]])
Z(z[85])
Z([3,'cross'])
Z(z[55])
Z([3,'padding:6rpx;margin-left: 10rpx;'])
Z([[7],[3,'showToMsgTextarea']])
Z([3,'margin:0 40rpx 0 40rpx;display:flex;justify-content:space-between;align-items:center;'])
Z([3,'textEmojiShow'])
Z([3,'my-icon'])
Z([3,'#707070'])
Z([3,'xiaonian'])
Z([3,'50rpx'])
Z([3,'secretChange'])
Z(z[4])
Z([3,'34rpx'])
Z([3,'secret-check-label'])
Z([3,'square'])
Z([[7],[3,'secret']])
Z([[7],[3,'textEmoji']])
Z([3,'i'])
Z([[7],[3,'emojiPageArr']])
Z([3,'index'])
Z([3,'idx'])
Z([[7],[3,'emojis']])
Z(z[113])
Z([[2,'=='],[[2,'|'],[[2,'/'],[[7],[3,'idx']],[[7],[3,'emojiPageSize']]],[[7],[3,'Int']]],[[7],[3,'i']]])
Z([3,'showReplyAfter'])
Z([3,'closeRe'])
Z([3,'height:91%;'])
Z(z[87])
Z([[7],[3,'showReply']])
Z(z[89])
Z(z[90])
Z([3,'width:auto;'])
Z([[2,'!'],[[7],[3,'authority']]])
Z([[2,'&&'],[[7],[3,'author']],[[6],[[7],[3,'author']],[3,'_openid']]])
Z(z[118])
Z(z[93])
Z(z[55])
Z(z[95])
Z([[7],[3,'showReplyTextarea']])
Z([3,'replyEmojiShow'])
Z(z[99])
Z(z[100])
Z(z[101])
Z(z[102])
Z([[7],[3,'replyEmoji']])
Z(z[110])
Z(z[111])
Z(z[112])
Z(z[113])
Z(z[114])
Z(z[113])
Z(z[116])
Z([3,'backTop'])
Z([1,300])
Z([3,'slide-right'])
Z([[7],[3,'backTop']])
Z([3,'position: fixed;right:32rpx;bottom:60rpx;width:80rpx;height:80rpx;display:flex;justify-content:center;align-items:center;'])
Z(z[99])
Z(z[2])
Z([3,'width:48rpx;height:48rpx;display:flex;justify-content:center;align-items:center;'])
Z([3,'backtop'])
Z([3,'48rpx'])
Z([[2,'!'],[[7],[3,'show']]])
Z([3,'myPrivacy'])
})(__WXML_GLOBAL__.ops_cached.$gwx_XC_29_1);return __WXML_GLOBAL__.ops_cached.$gwx_XC_29_1
}
__WXML_GLOBAL__.ops_set.$gwx_XC_29=z;
__WXML_GLOBAL__.ops_init.$gwx_XC_29=true;
var x=['./pages/msg/list/list.wxml'];d_[x[0]]={}
var m0=function(e,s,r,gg){
var z=gz$gwx_XC_29_1()
var oHI=_v()
_(r,oHI)
if(_oz(z,0,e,s,gg)){oHI.wxVkey=1
}
var xII=_v()
_(r,xII)
if(_oz(z,1,e,s,gg)){xII.wxVkey=1
var cLI=_mz(z,'van-notice-bar',['background',2,'bind:close',1,'color',2,'leftIcon',3,'mode',4,'speed',5,'text',6],[],e,s,gg)
_(xII,cLI)
}
var oJI=_v()
_(r,oJI)
if(_oz(z,9,e,s,gg)){oJI.wxVkey=1
var hMI=_n('view')
_rz(z,hMI,'style',10,e,s,gg)
var oNI=_v()
_(hMI,oNI)
if(_oz(z,11,e,s,gg)){oNI.wxVkey=1
}
var cOI=_v()
_(hMI,cOI)
if(_oz(z,12,e,s,gg)){cOI.wxVkey=1
var bUI=_n('van-sticky')
_(cOI,bUI)
}
var oPI=_v()
_(hMI,oPI)
if(_oz(z,13,e,s,gg)){oPI.wxVkey=1
}
var oVI=_mz(z,'van-popup',['closeable',-1,'round',-1,'bind:close',14,'customClass',1,'show',2],[],e,s,gg)
_(hMI,oVI)
var xWI=_v()
_(hMI,xWI)
var oXI=function(cZI,fYI,h1I,gg){
var c3I=_v()
_(h1I,c3I)
if(_oz(z,19,cZI,fYI,gg)){c3I.wxVkey=1
var o4I=_mz(z,'view',['bindtap',20,'class',1,'data-index',2,'style',3],[],cZI,fYI,gg)
var l5I=_n('view')
_rz(z,l5I,'class',24,cZI,fYI,gg)
var t7I=_n('view')
_rz(z,t7I,'class',25,cZI,fYI,gg)
var b9I=_n('view')
_rz(z,b9I,'style',26,cZI,fYI,gg)
var o0I=_v()
_(b9I,o0I)
if(_oz(z,27,cZI,fYI,gg)){o0I.wxVkey=1
var fCJ=_mz(z,'van-tag',['color',28,'style',1],[],cZI,fYI,gg)
_(o0I,fCJ)
}
var xAJ=_v()
_(b9I,xAJ)
if(_oz(z,30,cZI,fYI,gg)){xAJ.wxVkey=1
var cDJ=_mz(z,'van-tag',['color',31,'style',1],[],cZI,fYI,gg)
_(xAJ,cDJ)
}
var oBJ=_v()
_(b9I,oBJ)
if(_oz(z,33,cZI,fYI,gg)){oBJ.wxVkey=1
var hEJ=_mz(z,'van-tag',['color',34,'style',1],[],cZI,fYI,gg)
_(oBJ,hEJ)
}
o0I.wxXCkey=1
o0I.wxXCkey=3
xAJ.wxXCkey=1
xAJ.wxXCkey=3
oBJ.wxXCkey=1
oBJ.wxXCkey=3
_(t7I,b9I)
var e8I=_v()
_(t7I,e8I)
if(_oz(z,36,cZI,fYI,gg)){e8I.wxVkey=1
var oFJ=_mz(z,'view',['catchtap',37,'data-index',1,'style',2],[],cZI,fYI,gg)
var cGJ=_mz(z,'van-icon',['color',40,'name',1,'size',2,'style',3],[],cZI,fYI,gg)
_(oFJ,cGJ)
_(e8I,oFJ)
}
else{e8I.wxVkey=2
var oHJ=_mz(z,'view',['catchtap',44,'data-index',1,'style',2],[],cZI,fYI,gg)
var lIJ=_mz(z,'van-icon',['color',47,'name',1,'size',2,'style',3],[],cZI,fYI,gg)
_(oHJ,lIJ)
_(e8I,oHJ)
}
e8I.wxXCkey=1
e8I.wxXCkey=3
e8I.wxXCkey=3
_(l5I,t7I)
var a6I=_v()
_(l5I,a6I)
if(_oz(z,51,cZI,fYI,gg)){a6I.wxVkey=1
var aJJ=_n('view')
_rz(z,aJJ,'style',52,cZI,fYI,gg)
var tKJ=_v()
_(aJJ,tKJ)
if(_oz(z,53,cZI,fYI,gg)){tKJ.wxVkey=1
}
else{tKJ.wxVkey=2
var eLJ=_mz(z,'van-icon',['name',54,'size',1,'style',2],[],cZI,fYI,gg)
_(tKJ,eLJ)
}
tKJ.wxXCkey=1
tKJ.wxXCkey=3
_(a6I,aJJ)
}
var bMJ=_v()
_(l5I,bMJ)
var oNJ=function(oPJ,xOJ,fQJ,gg){
var hSJ=_v()
_(fQJ,hSJ)
if(_oz(z,61,oPJ,xOJ,gg)){hSJ.wxVkey=1
var oTJ=_v()
_(hSJ,oTJ)
if(_oz(z,62,oPJ,xOJ,gg)){oTJ.wxVkey=1
var cUJ=_n('view')
_rz(z,cUJ,'class',63,oPJ,xOJ,gg)
var oVJ=_v()
_(cUJ,oVJ)
if(_oz(z,64,oPJ,xOJ,gg)){oVJ.wxVkey=1
var aXJ=_n('view')
_rz(z,aXJ,'style',65,oPJ,xOJ,gg)
var tYJ=_v()
_(aXJ,tYJ)
if(_oz(z,66,oPJ,xOJ,gg)){tYJ.wxVkey=1
}
else{tYJ.wxVkey=2
var eZJ=_mz(z,'van-icon',['name',67,'size',1,'style',2],[],oPJ,xOJ,gg)
_(tYJ,eZJ)
}
tYJ.wxXCkey=1
tYJ.wxXCkey=3
_(oVJ,aXJ)
}
var lWJ=_v()
_(cUJ,lWJ)
if(_oz(z,70,oPJ,xOJ,gg)){lWJ.wxVkey=1
}
oVJ.wxXCkey=1
oVJ.wxXCkey=3
lWJ.wxXCkey=1
_(oTJ,cUJ)
}
oTJ.wxXCkey=1
oTJ.wxXCkey=3
}
hSJ.wxXCkey=1
hSJ.wxXCkey=3
return fQJ
}
bMJ.wxXCkey=4
_2z(z,59,oNJ,cZI,fYI,gg,bMJ,'floorItem','floorIndex','unique')
a6I.wxXCkey=1
a6I.wxXCkey=3
_(o4I,l5I)
_(c3I,o4I)
}
c3I.wxXCkey=1
c3I.wxXCkey=3
return h1I
}
xWI.wxXCkey=4
_2z(z,17,oXI,e,s,gg,xWI,'item','index','_id')
var lQI=_v()
_(hMI,lQI)
if(_oz(z,71,e,s,gg)){lQI.wxVkey=1
var b1J=_mz(z,'van-divider',['dashed',-1,'contentPosition',72,'customStyle',1],[],e,s,gg)
_(lQI,b1J)
}
var aRI=_v()
_(hMI,aRI)
if(_oz(z,74,e,s,gg)){aRI.wxVkey=1
}
var tSI=_v()
_(hMI,tSI)
if(_oz(z,75,e,s,gg)){tSI.wxVkey=1
}
var eTI=_v()
_(hMI,eTI)
if(_oz(z,76,e,s,gg)){eTI.wxVkey=1
}
var o2J=_mz(z,'van-action-sheet',['actions',77,'bind:cancel',1,'bind:close',2,'bind:select',3,'cancelText',4,'description',5,'show',6],[],e,s,gg)
_(hMI,o2J)
var x3J=_mz(z,'van-popup',['round',-1,'bind:after-enter',84,'bind:close',1,'customStyle',2,'position',3,'show',4],[],e,s,gg)
var o4J=_n('view')
_rz(z,o4J,'class',89,e,s,gg)
var h7J=_n('view')
_rz(z,h7J,'style',90,e,s,gg)
var o8J=_v()
_(h7J,o8J)
if(_oz(z,91,e,s,gg)){o8J.wxVkey=1
}
var c9J=_mz(z,'van-icon',['bindtap',92,'name',1,'size',2,'style',3],[],e,s,gg)
_(h7J,c9J)
o8J.wxXCkey=1
_(o4J,h7J)
var f5J=_v()
_(o4J,f5J)
if(_oz(z,96,e,s,gg)){f5J.wxVkey=1
}
var o0J=_n('view')
_rz(z,o0J,'style',97,e,s,gg)
var lAK=_mz(z,'van-icon',['bindtap',98,'classPrefix',1,'color',2,'name',3,'size',4],[],e,s,gg)
_(o0J,lAK)
var aBK=_mz(z,'van-checkbox',['bind:change',103,'checkedColor',1,'iconSize',2,'labelClass',3,'shape',4,'value',5],[],e,s,gg)
_(o0J,aBK)
_(o4J,o0J)
var c6J=_v()
_(o4J,c6J)
if(_oz(z,109,e,s,gg)){c6J.wxVkey=1
var tCK=_v()
_(c6J,tCK)
var eDK=function(oFK,bEK,xGK,gg){
var fIK=_v()
_(xGK,fIK)
var cJK=function(oLK,hKK,cMK,gg){
var lOK=_v()
_(cMK,lOK)
if(_oz(z,116,oLK,hKK,gg)){lOK.wxVkey=1
}
lOK.wxXCkey=1
return cMK
}
fIK.wxXCkey=2
_2z(z,114,cJK,oFK,bEK,gg,fIK,'item','idx','idx')
return xGK
}
tCK.wxXCkey=2
_2z(z,111,eDK,e,s,gg,tCK,'i','index','index')
}
f5J.wxXCkey=1
c6J.wxXCkey=1
_(x3J,o4J)
_(hMI,x3J)
var aPK=_mz(z,'van-popup',['round',-1,'bind:after-enter',117,'bind:close',1,'customStyle',2,'position',3,'show',4],[],e,s,gg)
var tQK=_n('view')
_rz(z,tQK,'class',122,e,s,gg)
var oTK=_n('view')
_rz(z,oTK,'style',123,e,s,gg)
var xUK=_n('view')
_rz(z,xUK,'style',124,e,s,gg)
var oVK=_v()
_(xUK,oVK)
if(_oz(z,125,e,s,gg)){oVK.wxVkey=1
}
else{oVK.wxVkey=2
var fWK=_v()
_(oVK,fWK)
if(_oz(z,126,e,s,gg)){fWK.wxVkey=1
}
fWK.wxXCkey=1
}
oVK.wxXCkey=1
_(oTK,xUK)
var cXK=_mz(z,'van-icon',['bindtap',127,'name',1,'size',2,'style',3],[],e,s,gg)
_(oTK,cXK)
_(tQK,oTK)
var eRK=_v()
_(tQK,eRK)
if(_oz(z,131,e,s,gg)){eRK.wxVkey=1
}
var hYK=_mz(z,'van-icon',['bindtap',132,'classPrefix',1,'color',2,'name',3,'size',4],[],e,s,gg)
_(tQK,hYK)
var bSK=_v()
_(tQK,bSK)
if(_oz(z,137,e,s,gg)){bSK.wxVkey=1
var oZK=_v()
_(bSK,oZK)
var c1K=function(l3K,o2K,a4K,gg){
var e6K=_v()
_(a4K,e6K)
var b7K=function(x9K,o8K,o0K,gg){
var cBL=_v()
_(o0K,cBL)
if(_oz(z,144,x9K,o8K,gg)){cBL.wxVkey=1
}
cBL.wxXCkey=1
return o0K
}
e6K.wxXCkey=2
_2z(z,142,b7K,l3K,o2K,gg,e6K,'item','idx','idx')
return a4K
}
oZK.wxXCkey=2
_2z(z,139,c1K,e,s,gg,oZK,'i','index','index')
}
eRK.wxXCkey=1
bSK.wxXCkey=1
_(aPK,tQK)
_(hMI,aPK)
oNI.wxXCkey=1
cOI.wxXCkey=1
cOI.wxXCkey=3
oPI.wxXCkey=1
lQI.wxXCkey=1
lQI.wxXCkey=3
aRI.wxXCkey=1
tSI.wxXCkey=1
eTI.wxXCkey=1
_(oJI,hMI)
}
var hCL=_mz(z,'van-transition',['bindtap',145,'duration',1,'name',2,'show',3,'style',4],[],e,s,gg)
var oDL=_mz(z,'van-icon',['classPrefix',150,'color',1,'customStyle',2,'name',3,'size',4],[],e,s,gg)
_(hCL,oDL)
_(r,hCL)
var fKI=_v()
_(r,fKI)
if(_oz(z,155,e,s,gg)){fKI.wxVkey=1
}
var cEL=_n('my-privacy')
_rz(z,cEL,'id',156,e,s,gg)
_(r,cEL)
oHI.wxXCkey=1
xII.wxXCkey=1
xII.wxXCkey=3
oJI.wxXCkey=1
oJI.wxXCkey=3
fKI.wxXCkey=1
return r
}
e_[x[0]]={f:m0,j:[],i:[],ti:[],ic:[]}
if(path&&e_[path]){
return function(env,dd,global){$gwxc=0;var root={"tag":"wx-page"};root.children=[]
;g="$gwx_XC_29";var main=e_[path].f
if (typeof global==="undefined")global={};global.f=$gdc(f_[path],"",1);
try{
main(env,{},root,global);
_tsd(root)
}catch(err){
console.log(err)
}
;g="";
return root;
}
}
}
}(__g.a,__g.b,__g.c,__g.d,__g.e,__g.f,__g.g,__g.h,__g.i,__g.j,__g.k,__g.l,__g.m,__g.n,__g.o,__g.p,__g.q,__g.r,__g.s,__g.t,__g.u,__g.v,__g.w,__g.x,__g.y,__g.z,__g.A,__g.B,__g.C,__g.D,__g.E,__g.F,__g.G,__g.H,__g.I,__g.J,__g.K,__g.L,__g.M,__g.N,__g.O,__g.P,__g.Q,__g.R,__g.S,__g.T,__g.U,__g.V,__g.W,__g.X,__g.Y,__g.Z,__g.aa);if(__vd_version_info__.delayedGwx||false)$gwx_XC_29();	if (__vd_version_info__.delayedGwx) __wxAppCode__['pages/msg/list/list.wxml'] = [$gwx_XC_29, './pages/msg/list/list.wxml'];else __wxAppCode__['pages/msg/list/list.wxml'] = $gwx_XC_29( './pages/msg/list/list.wxml' );
	;__wxRoute = "pages/msg/list/list";__wxRouteBegin = true;__wxAppCurrentFile__="pages/msg/list/list.js";define("pages/msg/list/list.js",function(require,module,exports,window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){
"use strict";var t=require("../../../@babel/runtime/helpers/typeof"),e=require("../../../@babel/runtime/helpers/regeneratorRuntime"),a=require("../../../@babel/runtime/helpers/asyncToGenerator");wx.cloud.init();var i,n,o=wx.cloud.database(),s=o.command,r=o.collection("message"),d=o.collection("msgpages"),c=o.collection("msg_user"),u=require("../../../components/emoji/emoji-parser.esm"),l=require("../../../components/cos/cos-wx-sdk-v5.min"),h=void 0,g=void 0;Page({data:{isFromMini:!1,systemInfo:wx.getSystemInfoSync(),userGetting:!1,emojiPageArr:[],emojiPageSize:0,emojiContainerMargin:0,emojis:u.getEmojis({size:31}),show:!1,showNavBarLoding:!1,pageNum:1,pageSize:20,allShow:!1,msgList:null,msgListTemp:null,selectMsgInfo:{},_index:0,title:"",maxNumber:140,numberText:0,numberReply:0,showToMsg:!1,showReply:!1,showReplyTextarea:!1,showToMsgTextarea:!1,toMsgFocus:!1,replyFocus:!1,authority:!1,replyMsgId:"",qr:"",userId:"",author:null,pageId:"",msgId:"",goodCount:0,info:{},text:"",secret:!1,anonymous:!1,reply:"",showDeal:!1,dealActionsInit:[{name:"置顶/取消置顶",index:0},{name:"添加回复",index:1},{name:"审核/取消审核",index:2},{name:"删除",index:3,color:"red"}],dealActions:[],textEmoji:!1,textCursor:0,replyEmoji:!1,replyCursor:0,currentItemId:"",currentReplyId:"",currentFloorId:"",onlyMe:!1,latest:!1,hot:!1,goodIndex:-1,backTop:!1,userInfo:void 0,saveusertype:0},onCloseShowBig:function(){this.setData({showBig:!1})},showBig:function(t){var e=this.data.msgList[t.currentTarget.dataset.index];e&&this.setData({showBig:!0,showBigImg:e.imageSrc,showBigName:e.name,showBigCreateTime:e.createTime})},showBigForReply:function(t){var e=t.currentTarget.dataset;e&&e.time&&this.setData({showBig:!0,showBigImg:e.image,showBigName:e.name,showBigCreateTime:e.time})},toComment:function(){wx.navigateTo({url:"/vantPage/comment/comment"})},copyPath:function(){wx.setClipboardData({data:"pages/msg/list/list?id="+this.data.pageId,success:function(){wx.hideLoading(),wx.showToast({title:"互动卡路径复制成功",icon:"none"})}})},onPageScroll:function(t){t.scrollTop>400&&!this.data.backTop?this.setData({backTop:!0}):t.scrollTop<=400&&this.data.backTop&&this.setData({backTop:!1})},backTop:function(){wx.pageScrollTo({scrollTop:0,duration:300})},closeNoticeBar:function(t){this.data.info.authorNoticeRead||d.doc(this.data.info._id).update({data:{authorNoticeRead:!0}})},readOrigin:function(){this.data.info.originUrl?wx.navigateTo({url:"/pages/webview/webview?url="+this.data.info.originUrl}):wx.showToast({title:"作者未设置原文链接！",icon:"none",duration:3e3})},diyAvatar:function(){wx.navigateToMiniProgram({appId:"wx1ab41a14fa705d27"})},allMsg:function(){var t=this;this.setData({onlyMe:!1,latest:!1,hot:!1},(function(){t.getData(!0)}))},onlyMe:function(){var t=this;this.setData({onlyMe:!0,latest:!1,hot:!1},(function(){t.getData(!0)}))},latest:function(){var t=this;this.setData({onlyMe:!1,latest:!0,hot:!1},(function(){t.getData(!0)}))},hot:function(){var t=this;this.setData({onlyMe:!1,latest:!1,hot:!0},(function(){t.getData(!0)}))},beginCopyText:function(t){var e=this.data.msgList[t.currentTarget.dataset.index];this.setData({currentItemId:e._id})},endCopyText:function(t){this.setData({currentItemId:""})},copyText:function(t){var e=this,a=["复制内容"];e.data.info.superAuth&&(a=["复制内容","违规隐藏"]);var i=e.data.msgList[t.currentTarget.dataset.index];wx.showActionSheet({alertText:i.text,itemList:a,success:function(t){0===t.tapIndex?wx.setClipboardData({data:i.text,success:function(){wx.hideLoading(),wx.showToast({title:"复制成功",icon:"none"})}}):r.doc(i._id).update({data:{isHide:!0}}).then((function(t){e.getData(!0)}))}}),e.data.currentItemId&&e.endCopyText()},beginCopyReply:function(t){var e=this.data.msgList[t.currentTarget.dataset.index];this.setData({currentReplyId:e._id})},endCopyReply:function(t){this.setData({currentReplyId:""})},copyReply:function(t){var e=this,a=["复制内容"];(e.data.info.superAuth||e.data.authority)&&(a=["复制内容","违规隐藏"]);var i=e.data.msgList[t.currentTarget.dataset.index];wx.showActionSheet({alertText:i.reply,itemList:a,success:function(t){0===t.tapIndex?wx.setClipboardData({data:i.reply,success:function(){wx.hideLoading(),wx.showToast({title:"复制成功",icon:"none"})}}):r.doc(i._id).update({data:{replyIsHide:!0}}).then((function(t){e.getData(!0)}))}}),e.data.currentReplyId&&e.endCopyReply()},beginCopyFloor:function(t){var e=this.data.msgList[t.currentTarget.dataset.index],a=t.currentTarget.dataset.item;this.setData({currentFloorId:e._id+a})},endCopyFloor:function(t){this.setData({currentFloorId:""})},copyFloor:function(t){var e=this,a=["复制内容"];(e.data.info.superAuth||e.data.authority)&&(a=["复制内容","违规隐藏"]);var i=e.data.msgList[t.currentTarget.dataset.index],n=t.currentTarget.dataset.floor;wx.showActionSheet({alertText:n,itemList:a,success:function(a){if(0===a.tapIndex)wx.setClipboardData({data:n,success:function(){wx.hideLoading(),wx.showToast({title:"复制成功",icon:"none"})}});else{var o={};o["floor"+t.currentTarget.dataset.item+"IsHide"]=!0,r.doc(i._id).update({data:o}).then((function(t){e.getData(!0)}))}}}),e.data.currentFloorId&&e.endCopyFloor()},textEmojiShow:function(){this.setData({textEmoji:!this.data.textEmoji}),this.data.textEmoji||this.setData({toMsgFocus:!0})},textFocus:function(){this.setData({textEmoji:!1})},textBlur:function(t){this.setData({textCursor:t.detail.cursor})},textInsertEmoji:function(t){var e=t.currentTarget.dataset.name,a=e.length,i=this.data.textCursor,n=this.data.text,o=n.slice(0,i)+e+n.slice(i);this.setData({text:o,textCursor:i+a})},replyEmojiShow:function(){this.setData({replyEmoji:!this.data.replyEmoji}),this.data.replyEmoji||this.setData({replyFocus:!0})},replyFocus:function(){this.setData({replyEmoji:!1})},replyBlur:function(t){this.setData({replyCursor:t.detail.cursor})},replyInsertEmoji:function(t){var e=t.currentTarget.dataset.name,a=e.length,i=this.data.replyCursor,n=this.data.reply,o=n.slice(0,i)+e+n.slice(i);this.setData({reply:o,replyCursor:i+a})},showDeal:function(t){var e=this,a=this.data.msgList[t.currentTarget.dataset.index];this.setData({selectMsgInfo:a},(function(){if(e.data.authority)(i=JSON.parse(JSON.stringify(e.data.dealActionsInit)))[0].name=a.top?"取消置顶":"置顶",i[2].name=a.status?"取消审核":"审核",e.setData({dealActions:i,showDeal:!0,_index:t.currentTarget.dataset.index});else if(a._openid==e.data.userId){var i;delete(i=JSON.parse(JSON.stringify(e.data.dealActionsInit)))[0],delete i[2],a.status||delete i[1],a.reply||e.data.authority||delete i[1],e.setData({dealActions:i,showDeal:!0,_index:t.currentTarget.dataset.index})}}))},hideDeal:function(){this.setData({showDeal:!1})},onSelect:function(t){var e=this;switch(t.detail.index){case 0:e.toTop();break;case 1:e.showRe();break;case 2:e.toCheck();break;case 3:wx.showModal({title:"提示",content:"确定删除该互动吗",success:function(t){t.confirm&&e.delect()}})}},toCheck:function(t){var e=this;this.data.selectMsgInfo.status?(wx.showLoading({title:"取消审核中",mask:!0}),wx.cloud.callFunction({name:"notCheck",data:{id:this.data.selectMsgInfo._id}}).then((function(t){wx.hideLoading();var a=e.data.selectMsgInfo;a.status=!1;var i=e.data.msgList;i[e.data._index]=a,e.setData({msgList:i}),wx.showToast({title:"取消审核成功",icon:"success"})}))):(wx.showLoading({title:"审核中",mask:!0}),wx.cloud.callFunction({name:"toCheck",data:{id:this.data.selectMsgInfo._id}}).then((function(t){wx.hideLoading();var a=e.data.selectMsgInfo;a.status=!0;var i=e.data.msgList;i[e.data._index]=a,e.setData({msgList:i}),wx.showToast({title:"审核成功",icon:"success"})})))},toTop:function(t){var e=this;this.data.selectMsgInfo.top?(wx.showLoading({title:"取消置顶中",mask:!0}),wx.cloud.callFunction({name:"notTop",data:{id:this.data.selectMsgInfo._id}}).then((function(t){wx.hideLoading(),wx.showToast({title:"取消置顶成功",icon:"success",success:function(t){e.getData(!0)}})}))):(wx.showLoading({title:"置顶中",mask:!0}),wx.cloud.callFunction({name:"toTop",data:{id:this.data.selectMsgInfo._id}}).then((function(t){wx.hideLoading(),wx.showToast({title:"置顶成功",icon:"success",success:function(t){e.getData(!0)}})})))},deleteSelf:function(t){var e=this;e.setData({selectMsgInfo:e.data.msgList[t.currentTarget.dataset.index],_index:t.currentTarget.dataset.index}),wx.showModal({title:"提示",content:"确定删除你的这条互动吗",success:function(t){t.confirm&&e.delect()}})},delect:function(t){var e=this;wx.showLoading({title:"删除中",mask:!0}),wx.cloud.callFunction({name:"delect",data:{id:this.data.selectMsgInfo._id}}).then((function(t){wx.hideLoading();var a=e.data.msgList;a.splice(e.data._index,1),e.setData({msgList:a}),wx.showToast({title:"删除成功",icon:"success"}),d.doc(e.data.info._id).update({data:{msgCount:s.inc(-1)}})}))},toWrite:function(){this.data.info.isForbid?wx.showToast({title:"该互动卡违规被禁访！",icon:"none"}):this.data.info.fromMsgcard?wx.openEmbeddedMiniProgram({path:"/pages/msg/list/list?id="+this.data.info._id,appId:"wx4faaf21bf014cd33"}):this.showPopup()},getUserInfo:function(){var t=this;wx.cloud.callFunction({name:"login",complete:function(e){var a=e.result;t.setData({userInfo:a})}})},authentication:function(){var t=this,e=this;wx.cloud.callFunction({name:"getDataWithTapGood",data:{id:e.data.pageId,db:"msgpages"}}).then((function(a){e.setData({show:!0});var i=a.result.data[0];if(i){i.isForbid&&(i.name="该互动卡违规被禁访！");var n=i._openid==i.userId;e.setData({userId:i.userId,info:i,title:i.name,authority:n},(function(){c.where({_openid:s.eq(i._openid)}).field({avatarUrl:!0,nickName:!0,unionid:!0,_openid:!0,_id:!0,xzffw_openid:!0}).get({success:function(t){t.data.length>0&&e.setData({author:t.data[0]},(function(){e.getData()}))}}),wx.setNavigationBarTitle({title:i.name})})),wx.cloud.callFunction({name:"simpleHistory",data:{type:1,name:i.name,path:"/pages/msg/list/list?id="+i._id}}).then((function(t){}))}else t.setData({absent:!0}),e.setData({title:"互动卡不存在"}),wx.setNavigationBarTitle({title:"互动卡不存在"})}))},reSubmit:function(){var t=this;this.data.reply?(wx.showLoading({title:"内容检测中",mask:!0}),wx.cloud.callFunction({name:"msgSecCheck",data:{content:t.data.reply,type:"message",pageId:t.data.pageId}}).then((function(e){wx.hideLoading(),0==e.result.errCode?t.reSubmitDo():wx.showToast({title:"内容存在违法违规风险，请重新输入！",icon:"none",duration:3e3})}))):wx.showToast({title:"请输入回复内容！",icon:"none"})},reSubmitDo:function(){var t=this;wx.showLoading({title:"回复中",mask:!0});var e=JSON.parse(JSON.stringify(this.data.selectMsgInfo)),a=e.floorNumber,i=this.data.reply.replace(new RegExp("\n","g"),"<br/>");if(a){a=a+1;e.floorNumber=a,e["floor"+a]=i,e["floor"+a+"Type"]=this.data.authority?1:2}else e.reply?(e.floorNumber=1,e.floor1=i,e.floor1Type=this.data.authority?1:2):e.reply=i;wx.cloud.callFunction({name:"reply",data:e}).then((function(a){wx.hideLoading();var n=t.data.msgList;n[t.data._index]=e,t.setData({reply:"",showRe:!1,numberReply:0,msgList:n}),t.closeRe(),wx.showToast({title:"回复成功",icon:"success"}),t.data.authority?wx.cloud.callFunction({name:"sendNotify",data:{type:2,toUser:e._openid,pageId:t.data.info._id,pageName:"互动卡："+t.data.title,text:t.data.selectMsgInfo.text,reply:i,createTime:t.formatTime(new Date)}}).then((function(t){})):wx.cloud.callFunction({name:"sendNotify",data:{type:3,pageId:t.data.info._id,pageName:t.data.title,userName:t.data.selectMsgInfo.name,text:i,createTime:t.formatTime(new Date),unionid:t.data.author.unionid,openid:t.data.author._openid,msgId:e._id}}).then((function(t){console.log(t)}))}))},attention:function(){wx.navigateTo({url:"/pages/methodD/methodD?id=5"})},onSubmit:function(t){var e=this,a=e.data.text.replace(/<\/?.+?>/g,"").replace(/ /g,"");a.replace(/\s+/g,"")?(wx.showLoading({title:"内容检测中",mask:!0}),wx.cloud.callFunction({name:"msgSecCheck",data:{content:a,type:"message",pageId:e.data.pageId}}).then((function(t){wx.hideLoading(),0==t.result.errCode?e.onSubmitDo():wx.showToast({title:"内容存在违法违规风险，请重新输入！",icon:"none",duration:3e3})}))):wx.showToast({title:"请输入互动内容！",icon:"none"})},onImageCropperConfirm:function(t,e){var a=this;if(t){var i=t,n=a.data.saveusertype,o=1==n?a.data.userInfo:a.data.author;e=e||i.substr(i.lastIndexOf("."));var r="avatar/"+o._openid+"/"+(new Date).getTime()+e;wx.showLoading({title:"头像上传中",mask:!0}),h.postObject({Bucket:"lg-h5g2gu1y-1257150849",Region:"ap-shanghai",Key:r,FilePath:i},(function(t,e){e?c.where({_openid:s.eq(o._openid)}).update({data:{avatarUrl:e.Location.replace("lg-h5g2gu1y-1257150849.cos.ap-shanghai.myqcloud.com","cos.wsqytec.com"),unionid:o.unionid?o.unionid:o.reAuth.unionid}}).then((function(t){wx.hideLoading(),o.avatarUrl=e.Location.replace("lg-h5g2gu1y-1257150849.cos.ap-shanghai.myqcloud.com","cos.wsqytec.com"),o.unionid=o.unionid?o.unionid:o.reAuth.unionid,1==n?a.setData({userInfo:o},(function(){wx.showToast({title:"头像保存成功",icon:"none"}),a.data.authority&&a.setData({author:o})})):a.setData({author:o},(function(){wx.showToast({title:"头像保存成功",icon:"none"}),a.data.authority&&a.setData({userInfo:o})}))})):(wx.hideLoading(),wx.showToast({title:"头像上传失败",icon:"none"}),a.initCOS())}))}},chooseAvatar:function(t){var e=t.currentTarget.dataset.usertype,a=this;wx.chooseMedia({count:1,mediaType:["image"],sizeType:["compressed"],sourceType:["album","camera"],success:function(t){var i=t.tempFiles[0].tempFilePath;a.saveAvatar({detail:{avatarUrl:i},currentTarget:{dataset:{usertype:e}}})}})},saveAvatar:function(t){var e=t.currentTarget.dataset.usertype,a=t.detail.avatarUrl;if(this.setData({saveusertype:e}),t.type){var i=a.substr(a.lastIndexOf("."));this.onImageCropperConfirm(a,i)}else wx.navigateTo({url:"/vantPage/image-cropper/image-cropper?initSrc="+a})},saveNickName:function(t){var e=t.currentTarget.dataset.usertype,a=this,i=t.detail.value,n=1==e?a.data.userInfo:a.data.author;i&&n.nickName!=i&&(wx.showLoading({title:"昵称检测中",mask:!0}),wx.cloud.callFunction({name:"msgSecCheck",data:{content:i}}).then((function(t){wx.hideLoading(),0==t.result.errCode?c.where({_openid:s.eq(n._openid)}).update({data:{nickName:i,unionid:n.unionid?n.unionid:n.reAuth.unionid}}).then((function(t){n.nickName=i,n.unionid=n.unionid?n.unionid:n.reAuth.unionid,1==e?a.setData({userInfo:n},(function(){wx.showToast({title:"昵称保存成功",icon:"none"}),a.data.authority&&a.setData({author:n})})):a.setData({author:n},(function(){wx.showToast({title:"昵称保存成功",icon:"none"}),a.data.authority&&a.setData({userInfo:n})}))})):wx.showToast({title:"昵称存在违法违规风险，请重新输入！",icon:"none",duration:3e3})})))},onSubmitDo:function(){var t=this,e=t.data.text,a=t.data.secret,i=t.data.anonymous;if(e){var n=t.formatTime(new Date),o={imageSrc:t.data.userInfo.avatarUrl,name:t.data.userInfo.nickName,text:e.replace(new RegExp("\n","g"),"<br/>"),secret:a,anonymous:i,pageId:t.data.pageId,status:!!a||!t.data.info.isCheck,createTime:n,goodCount:0,_openid:t.data.userId};wx.showLoading({title:"互动中",mask:!0}),r.add({data:o}).then((function(a){wx.hideLoading();var i="互动成功,审核后才会显示";(!t.data.info.isCheck||t.data.authority||t.data.onlyMe)&&(i="互动成功",t.getData(!0)),t.setData({text:"",secret:!1,anonymous:!1,numberText:0}),t.onClosePopupMsg(),wx.showToast({title:i,icon:"none",duration:3e3}),d.doc(t.data.info._id).update({data:{msgCount:s.inc(1)}}),wx.cloud.callFunction({name:"sendNotify",data:{type:3,pageId:t.data.info._id,pageName:t.data.title,userName:t.data.userInfo.nickName,text:e,createTime:n,unionid:t.data.author.unionid,openid:t.data.author._openid,msgId:a._id}}).then((function(t){console.log(t)})),a._id&&wx.cloud.callFunction({name:"addIpProvince",data:{db:"message",id:a._id}})}))}},addNotify:(n=a(e().mark((function t(a){var i,n;return e().wrap((function(t){for(;;)switch(t.prev=t.next){case 0:if(wx.showLoading({title:"提交中",mask:!0}),i=this,2!=(n=a.currentTarget.dataset.type)||!i.data.authority){t.next=10;break}if(wx.hideLoading(),i.data.author.nickName&&i.data.author.avatarUrl){t.next=8;break}return wx.showToast({title:"先点击完善左上角昵称和头像",icon:"none",duration:2500}),t.abrupt("return");case 8:return i.reSubmit(),t.abrupt("return");case 10:if(!(1==n&&i.data.info.perLimit&&i.data.info.perLimit>0)){t.next=18;break}return t.next=13,wx.cloud.callFunction({name:"getData",data:{id:i.data.pageId,db:"message",pageUserId:i.data.info._openid,pageNum:0,pageSize:20,onlyMe:!0}});case 13:if(!(t.sent.result.data.length>=i.data.info.perLimit)){t.next=18;break}return wx.hideLoading(),wx.showToast({title:"管理员限制单人可互动次数为"+i.data.info.perLimit+"次！",icon:"none",duration:3e3}),t.abrupt("return");case 18:if(1!=n){t.next=25;break}if(i.data.text){t.next=22;break}return wx.showToast({title:"内容不能为空",icon:"none"}),t.abrupt("return");case 22:if(i.data.userInfo.nickName&&i.data.userInfo.avatarUrl){t.next=25;break}return wx.showToast({title:"先点击完善左上角昵称和头像",icon:"none",duration:2500}),t.abrupt("return");case 25:wx.hideLoading(),wx.requestSubscribeMessage({tmplIds:["zaQ3x3ulTkJQfM0W4Vzyj1kIFDFp4B7GXS16Q4lJbX0"],complete:function(t){1==n?i.onSubmit():2==n&&i.reSubmit()}});case 28:case"end":return t.stop()}}),t,this)}))),function(t){return n.apply(this,arguments)}),tapGoodDo:function(t){var e=this.data.goodIndex,a=this.data.msgList[e],i=a.goodCount;null==i&&(i=0),-1==t?(a.goodCount=0==i?0:i-1,a.myGoodCount=0):(a.goodCount=i+1,a.myGoodCount=a.myGoodCount+1);var n=this.data.msgList;n[e]=a,this.setData({msgList:n}),wx.cloud.callFunction({name:"tapGoodToggle",data:{id:a._id}})},tapGood:(i=a(e().mark((function t(a){var i;return e().wrap((function(t){for(;;)switch(t.prev=t.next){case 0:(i=this).setData({goodIndex:a.currentTarget.dataset.index}),0==i.data.msgList[i.data.goodIndex].myGoodCount?i.tapGoodDo(1):i.tapGoodDo(-1);case 4:case"end":return t.stop()}}),t,this)}))),function(t){return i.apply(this,arguments)}),getAll:function(){var t=this;this.setData({msgId:""},(function(){t.getData(!0)}))},getData:function(t){if(wx.stopPullDownRefresh(),!this.data.absent){var e=this;e.setData({showNavBarLoding:!0},(function(){wx.showNavigationBarLoading&&wx.showNavigationBarLoading()})),1==t&&e.setData({pageNum:1,allShow:!1}),e.data.info.isForbid?e.setData({allShow:!0,msgList:[],showNavBarLoding:!1},(function(){wx.hideNavigationBarLoading&&wx.hideNavigationBarLoading()})):e.data.info._openid&&wx.cloud.callFunction({name:"getDataWithTapGood",data:{id:e.data.pageId,db:"message",pageUserId:e.data.info._openid,pageNum:e.data.pageNum,pageSize:e.data.pageSize,onlyMe:e.data.onlyMe,latest:e.data.latest,hot:e.data.hot,msgId:e.data.msgId}}).then((function(a){if(0==a.result.data.length&&e.setData({allShow:!0}),t)e.setData({msgList:a.result.data});else{var i=e.data.msgList?e.data.msgList:[];e.setData({msgList:i.concat(a.result.data)})}e.setData({showNavBarLoding:!1},(function(){wx.hideNavigationBarLoading&&wx.hideNavigationBarLoading()}))}))}},toNotice:function(){var t="/pages/webview/webview?url="+encodeURIComponent("https://zhijiebohao-4gp9aizse6797bd3-1257150849.tcloudbaseapp.com/gzh.html?miniAppId=wx5c9674e6177b0f6a&miniEnvId=zhijiebohao-4gp9aizse6797bd3&authorized="+(!(!this.data.author||!this.data.author.xzffw_openid)||"")+"&type=msg");wx.navigateTo({url:t})},onReachBottom:function(){this.data.allShow||(this.setData({pageNum:this.data.pageNum+1}),this.getData())},inputText:function(t){var e=t.detail.value,a=e.length;this.setData({numberText:a,text:e})},secretChange:function(t){this.setData({secret:!this.data.secret})},anonymousChange:function(t){this.setData({anonymous:!this.data.anonymous})},inputReply:function(t){var e=t.detail.value,a=e.length;this.setData({numberReply:a,reply:e})},showToMsgAfter:function(){var t=this,e=setTimeout((function(){clearTimeout(e),t.setData({showToMsgTextarea:!0},(function(){t.setData({toMsgFocus:!0})}))}),10)},showPopup:function(){var t=this;g.dealPrivacyPop((function(){t.setData({showToMsg:!0})}))},onClosePopupMsg:function(){this.setData({showToMsg:!1,toMsgFocus:!1,textCursor:0,textEmoji:!1})},showReplyAfter:function(){var t=this,e=setTimeout((function(){clearTimeout(e),t.setData({showReplyTextarea:!0},(function(){t.setData({replyFocus:!0})}))}),10)},showRe:function(t){if(this.data.selectMsgInfo.status)if(this.data.selectMsgInfo.reply||this.data.authority){var e=this;g.dealPrivacyPop((function(){e.setData({showReply:!0,replyMsgId:e.data.selectMsgInfo._id,reply:""})}))}else wx.showToast({title:"作者回复后才能继续回复！",icon:"none",duration:2500});else wx.showToast({title:"请先审核互动再回复！",icon:"none",duration:2500})},closeRe:function(){this.setData({showReply:!1,replyFocus:!1,reply:"",replyCursor:0,replyEmoji:!1})},onLoad:function(t){var e=this;g=this.selectComponent("#myPrivacy");var a=decodeURIComponent(t.q);if(a&&a.indexOf("?")>-1){var i=this.getQueryVariable(a.split("?")[1],"id");i&&(t.id=i)}t.scene&&(t.id=t.scene),t.id||(t.id="none");var n={pageId:t.id,msgId:t.msgId};t.fromReply&&(n.onlyMe=!0,n.latest=!1,n.hot=!1),this.setData(n,(function(){e.getUserInfo(),e.authentication()})),u.configParseEmoji({size:22});var o=this.data.systemInfo.windowWidth,s=o-80*(o/750),r=parseInt(s/40),d=4*r,c=110%d==0?110/d:parseInt(110/d)+1,l=Array.apply(null,{length:c}).map((function(t,e){return e})),h=(s-40*r)/(2*r);this.setData({emojiPageSize:d,emojiPageArr:l,emojiContainerMargin:h}),this.watch(this,{msgList:function(t){if(t){var e=[];t.forEach((function(t){var a=t.text,i=t.reply;a&&(a=u.parseEmoji(a)),i&&(i=u.parseEmoji(i));var n=JSON.parse(JSON.stringify(t));n.text=a,n.reply=i;var o=t.floorNumber;if(o)for(var s=1;s<=o;s++){var r="floor"+s;n[r]=u.parseEmoji(t[r])}e.push(n)})),this.setData({msgListTemp:e})}}}),1037==wx.getEnterOptionsSync().scene&&this.setData({isFromMini:!0}),this.initCOS()},initCOS:function(){wx.cloud.callFunction({name:"cosSts",complete:function(t){h=new l({getAuthorization:function(e,a){a({TmpSecretId:t.result.credentials.tmpSecretId,TmpSecretKey:t.result.credentials.tmpSecretKey,SecurityToken:t.result.credentials.sessionToken,StartTime:t.result.startTime,ExpiredTime:t.result.expiredTime})}})}})},onPullDownRefresh:function(){this.data.info.fromMsgcard?wx.stopPullDownRefresh():this.getData(!0)},onShareAppMessage:function(){return{title:this.data.title,path:"pages/msg/list/list?id="+this.data.info._id}},watch:function(t,e){var a=this;Object.keys(e).forEach((function(i){a.observer(t.data,i,t.data[i],(function(a){e[i].call(t,a)}))}))},observer:function(t,e,a,i){Object.defineProperty(t,e,{configurable:!0,enumerable:!0,get:function(){return a},set:function(t){i&&i(t),a=t}})},formatTime:function(e,a){if(e){switch(a||(a="yyyy-MM-dd HH:mm"),t(e)){case"string":var i=!1;e.indexOf("T")>-1&&e.indexOf("Z")>-1&&(i=!0,e=e.replace(/T/g," ").substring(0,e.lastIndexOf("."))),e=e.replace(/-/g,"/"),e=new Date(e),i&&(e=new Date(e.getTime()+288e5));break;case"number":e=new Date(e)}if(!(!e instanceof Date)){var n={yyyy:e.getFullYear(),M:e.getMonth()+1,d:e.getDate(),H:e.getHours(),m:e.getMinutes(),s:e.getSeconds(),MM:(""+(e.getMonth()+101)).substr(1),dd:(""+(e.getDate()+100)).substr(1),HH:(""+(e.getHours()+100)).substr(1),mm:(""+(e.getMinutes()+100)).substr(1),ss:(""+(e.getSeconds()+100)).substr(1)};return a.replace(/(yyyy|MM?|dd?|HH?|ss?|mm?)/g,(function(){return n[arguments[0]]}))}}},getQueryVariable:function(t,e){if(t)for(var a=t.split("&"),i=0;i<a.length;i++){var n=a[i].split("=");if(n[0].trim()==e.trim())return n[1].trim()}return!1},compareVersion:function(t,e){t=t.split("."),e=e.split(".");for(var a=Math.max(t.length,e.length);t.length<a;)t.push("0");for(;e.length<a;)e.push("0");for(var i=0;i<a;i++){var n=parseInt(t[i]),o=parseInt(e[i]);if(n>o)return 1;if(n<o)return-1}return 0}});
},{isPage:true,isComponent:true,currentFile:'pages/msg/list/list.js'});require("pages/msg/list/list.js");$gwx_XC_30=function(_,_v,_n,_p,_s,_wp,_wl,$gwn,$gwl,$gwh,wh,$gstack,$gwrt,gra,grb,TestTest,wfor,_ca,_da,_r,_rz,_o,_oz,_1,_1z,_2,_2z,_m,_mz,nv_getDate,nv_getRegExp,nv_console,nv_parseInt,nv_parseFloat,nv_isNaN,nv_isFinite,nv_decodeURI,nv_decodeURIComponent,nv_encodeURI,nv_encodeURIComponent,$gdc,nv_JSON,_af,_gv,_ai,_grp,_gd,_gapi,$ixc,_ic,_w,_ev,_tsd){return function(path,global){
if(typeof global==='undefined'){if (typeof __GWX_GLOBAL__==='undefined')global={};else global=__GWX_GLOBAL__;}if(typeof __WXML_GLOBAL__ === 'undefined') {__WXML_GLOBAL__={};
}__WXML_GLOBAL__.modules = __WXML_GLOBAL__.modules || {};
var e_={}
if(typeof(global.entrys)==='undefined')global.entrys={};e_=global.entrys;
var d_={}
if(typeof(global.defines)==='undefined')global.defines={};d_=global.defines;
var f_={}
if(typeof(global.modules)==='undefined')global.modules={};f_=global.modules || {};
var p_={}
__WXML_GLOBAL__.ops_cached = __WXML_GLOBAL__.ops_cached || {}
__WXML_GLOBAL__.ops_set = __WXML_GLOBAL__.ops_set || {};
__WXML_GLOBAL__.ops_init = __WXML_GLOBAL__.ops_init || {};
var z=__WXML_GLOBAL__.ops_set.$gwx_XC_30 || [];
function gz$gwx_XC_30_1(){
if( __WXML_GLOBAL__.ops_cached.$gwx_XC_30_1)return __WXML_GLOBAL__.ops_cached.$gwx_XC_30_1
__WXML_GLOBAL__.ops_cached.$gwx_XC_30_1=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
Z([[7],[3,'show']])
Z([3,'margin-top:32rpx;position:relative;'])
Z([[7],[3,'src']])
Z([3,'weui-cells'])
Z([[7],[3,'safe']])
Z(z[4])
Z(z[4])
Z(z[4])
Z([[7],[3,'msg']])
Z([3,'msgDone'])
Z([3,'always'])
Z([1,true])
Z([3,'去小互动卡创建并选择（可不填）'])
Z([3,'color:#ccc;font-size:24rpx;'])
Z(z[8])
Z(z[2])
Z([3,'display:flex;justify-content:center;align-items:center;width: 100%;margin:60rpx 0;'])
Z([3,'previewCall'])
Z([3,'#07c160'])
Z([3,'van-button-custom-class'])
Z([3,'savedownloadFile'])
Z(z[18])
Z(z[19])
Z([3,'text-align:center;font-size:32rpx;'])
Z(z[4])
Z(z[2])
Z([[2,'!'],[[7],[3,'show']]])
Z([3,'myPrivacy'])
})(__WXML_GLOBAL__.ops_cached.$gwx_XC_30_1);return __WXML_GLOBAL__.ops_cached.$gwx_XC_30_1
}
__WXML_GLOBAL__.ops_set.$gwx_XC_30=z;
__WXML_GLOBAL__.ops_init.$gwx_XC_30=true;
var x=['./pages/safeIndex/safeIndex.wxml'];d_[x[0]]={}
var m0=function(e,s,r,gg){
var z=gz$gwx_XC_30_1()
var lGL=_v()
_(r,lGL)
if(_oz(z,0,e,s,gg)){lGL.wxVkey=1
var tIL=_n('view')
_rz(z,tIL,'style',1,e,s,gg)
var eJL=_v()
_(tIL,eJL)
if(_oz(z,2,e,s,gg)){eJL.wxVkey=1
}
var oLL=_n('view')
_rz(z,oLL,'class',3,e,s,gg)
var xML=_v()
_(oLL,xML)
if(_oz(z,4,e,s,gg)){xML.wxVkey=1
}
var oNL=_v()
_(oLL,oNL)
if(_oz(z,5,e,s,gg)){oNL.wxVkey=1
}
var fOL=_v()
_(oLL,fOL)
if(_oz(z,6,e,s,gg)){fOL.wxVkey=1
}
var cPL=_v()
_(oLL,cPL)
if(_oz(z,7,e,s,gg)){cPL.wxVkey=1
}
var hQL=_v()
_(oLL,hQL)
if(_oz(z,8,e,s,gg)){hQL.wxVkey=1
var oRL=_mz(z,'van-search',['useActionSlot',-1,'useLeftIconSlot',-1,'bind:clear',9,'clearTrigger',1,'disabled',2,'placeholder',3,'placeholderStyle',4,'value',5],[],e,s,gg)
_(hQL,oRL)
}
xML.wxXCkey=1
oNL.wxXCkey=1
fOL.wxXCkey=1
cPL.wxXCkey=1
hQL.wxXCkey=1
hQL.wxXCkey=3
_(tIL,oLL)
var bKL=_v()
_(tIL,bKL)
if(_oz(z,15,e,s,gg)){bKL.wxVkey=1
var cSL=_n('view')
_rz(z,cSL,'style',16,e,s,gg)
var oTL=_mz(z,'van-button',['plain',-1,'round',-1,'bind:click',17,'color',1,'customClass',2],[],e,s,gg)
_(cSL,oTL)
var lUL=_mz(z,'van-button',['round',-1,'bind:click',20,'color',1,'customClass',2],[],e,s,gg)
_(cSL,lUL)
_(bKL,cSL)
}
else{bKL.wxVkey=2
}
var aVL=_n('view')
_rz(z,aVL,'style',23,e,s,gg)
var tWL=_v()
_(aVL,tWL)
if(_oz(z,24,e,s,gg)){tWL.wxVkey=1
}
var eXL=_v()
_(aVL,eXL)
if(_oz(z,25,e,s,gg)){eXL.wxVkey=1
}
tWL.wxXCkey=1
eXL.wxXCkey=1
_(tIL,aVL)
eJL.wxXCkey=1
bKL.wxXCkey=1
bKL.wxXCkey=3
_(lGL,tIL)
}
var aHL=_v()
_(r,aHL)
if(_oz(z,26,e,s,gg)){aHL.wxVkey=1
}
var bYL=_n('my-privacy')
_rz(z,bYL,'id',27,e,s,gg)
_(r,bYL)
lGL.wxXCkey=1
lGL.wxXCkey=3
aHL.wxXCkey=1
return r
}
e_[x[0]]={f:m0,j:[],i:[],ti:[],ic:[]}
if(path&&e_[path]){
return function(env,dd,global){$gwxc=0;var root={"tag":"wx-page"};root.children=[]
;g="$gwx_XC_30";var main=e_[path].f
if (typeof global==="undefined")global={};global.f=$gdc(f_[path],"",1);
try{
main(env,{},root,global);
_tsd(root)
}catch(err){
console.log(err)
}
;g="";
return root;
}
}
}
}(__g.a,__g.b,__g.c,__g.d,__g.e,__g.f,__g.g,__g.h,__g.i,__g.j,__g.k,__g.l,__g.m,__g.n,__g.o,__g.p,__g.q,__g.r,__g.s,__g.t,__g.u,__g.v,__g.w,__g.x,__g.y,__g.z,__g.A,__g.B,__g.C,__g.D,__g.E,__g.F,__g.G,__g.H,__g.I,__g.J,__g.K,__g.L,__g.M,__g.N,__g.O,__g.P,__g.Q,__g.R,__g.S,__g.T,__g.U,__g.V,__g.W,__g.X,__g.Y,__g.Z,__g.aa);if(__vd_version_info__.delayedGwx||false)$gwx_XC_30();	if (__vd_version_info__.delayedGwx) __wxAppCode__['pages/safeIndex/safeIndex.wxml'] = [$gwx_XC_30, './pages/safeIndex/safeIndex.wxml'];else __wxAppCode__['pages/safeIndex/safeIndex.wxml'] = $gwx_XC_30( './pages/safeIndex/safeIndex.wxml' );
	;__wxRoute = "pages/safeIndex/safeIndex";__wxRouteBegin = true;__wxAppCurrentFile__="pages/safeIndex/safeIndex.js";define("pages/safeIndex/safeIndex.js",function(require,module,exports,window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){
"use strict";var e=require("../../@babel/runtime/helpers/typeof"),t=require("../../@babel/runtime/helpers/objectSpread2");wx.cloud.init();var n=wx.cloud.database({env:"zhijiebohao-4gp9aizse6797bd3"}),a=n.command;Page({data:{author:null,showAd:!1,phone:"",name:"",msg:"",safe_text:"",inc_id:-1,security:"",safe:!0,rest:!1,safe_due_date:"",src:"",openid:"",show:!1,contactNumbers:void 0,fromMsg:!1},deletePhone:function(){var e=this;wx.showModal({title:"提示",content:"是否删除该号码？删除后您可以再重新获取号码绑定。",success:function(t){t.confirm&&e.data.inc_id&&wx.cloud.callFunction({name:"getUserInfo",data:{phone:"",inc_id:e.data.inc_id}}).then((function(t){e.setData({phone:""},(function(){wx.showToast({title:"删除成功",icon:"none"})}))}))}})},toMoreSafePhone:function(e){wx.navigateTo({url:"/vantPage/moreSafePhone/safePhone"})},toNotice:function(){var e="/pages/webview/webview?url="+encodeURIComponent("https://zhijiebohao-4gp9aizse6797bd3-1257150849.tcloudbaseapp.com/gzh.html?miniAppId=wx5c9674e6177b0f6a&miniEnvId=zhijiebohao-4gp9aizse6797bd3&authorized="+(!(!this.data.author||!this.data.author.xzffw_openid)||"")+"&type=safeIndex");wx.navigateTo({url:e})},toBlackList:function(){wx.navigateTo({url:"/vantPage/safeIndex/safeRecord?safeUserId="+this.data.security})},toMsg:function(){var e=this,t=wx.getSystemInfoSync();"windows"==t.platform||"mac"==t.platform?wx.showToast({title:"电脑端不支持该功能，请在手机端操作。",icon:"none"}):wx.openEmbeddedMiniProgram({path:"/vantPage/msgpagesList/msgpagesList?max=1",appId:"wx4faaf21bf014cd33",success:function(){e.setData({fromMsg:!0})}})},onShow:function(e){var t=wx.getEnterOptionsSync();if(this.data.fromMsg&&1038==t.scene&&"wx4faaf21bf014cd33"==t.referrerInfo.appId){var n=t.referrerInfo.extraData?t.referrerInfo.extraData.res:"cancel";if(n&&"cancel"!=n){var a=JSON.parse(n);if(a&&a.length>0){var o=a[0];this.msgDone({detail:o._id})}}this.setData({fromMsg:!1})}},goNuochema:function(){wx.navigateToMiniProgram({appId:"wx63dc31f506fb8095",path:"plugin-private://wx34345ae5855f892d/pages/productDetail/productDetail?productId=29640290"})},toXhdk:function(){wx.openEmbeddedMiniProgram({path:"/pages/msg/index/index",appId:"wx4faaf21bf014cd33"})},userKnow:function(){wx.navigateTo({url:"/pages/methodD/methodD?id=17453ede60725a19013d9b13631c047n"})},saveIndirectPhone:function(){var e=this;wx.showModal({title:"提示",content:"为避免漏接陌生来电，您可以备注小程序常用的虚拟中间号到手机通讯录中。",complete:function(t){t.confirm&&e.saveIndirectPhoneDo()}})},saveIndirectPhoneDo:function(){var e=this,o=e.data.contactNumbers;o?wx.addPhoneContact(t(t({},o),{},{success:function(){wx.showToast({title:"备注中间号成功",icon:"none"})},fail:function(t){(t.errMsg.indexOf("deny")>-1||t.errMsg.indexOf("denied")>-1||t.errMsg.indexOf("auth")>-1)&&e.showModal("scope.addPhoneContact",(function(){e.saveIndirectPhoneDo()}))}})):(wx.showLoading({title:"查询中间号",mask:!0}),n.collection("user_inc_id").where({_id:a.eq("indirect_phone")}).field({lastName:!0,firstName:!0,remark:!0,mobilePhoneNumber:!0,hostNumber:!0,workPhoneNumber:!0,homePhoneNumber:!0,workFaxNumber:!0,homeFaxNumber:!0}).get({success:function(n){o=n.data[0],e.setData({contactNumbers:o}),wx.addPhoneContact(t(t({},o),{},{success:function(){wx.showToast({title:"备注中间号成功",icon:"none"})},fail:function(t){(t.errMsg.indexOf("deny")>-1||t.errMsg.indexOf("denied")>-1||t.errMsg.indexOf("auth")>-1)&&e.showModal("scope.addPhoneContact",(function(){e.saveIndirectPhoneDo()}))}}))},complete:function(){wx.hideLoading()}}))},getQueryVariable:function(e,t){for(var n=e.split("&"),a=0;a<n.length;a++){var o=n[a].split("=");if(o[0].trim()==t.trim())return o[1].trim()}return!1},qrUnbind:function(){var e=this;wx.showModal({title:"立即解绑该拨号码",content:"将重新生成一张新拨号码，现有码信息将被清空！",success:function(t){t.confirm&&n.collection("phone_safe_user").doc(e.data.security).remove({success:function(t){wx.showToast({title:"解绑成功！",icon:"none"}),wx.cloud.callFunction({name:"getUserInfo",data:{}}).then((function(t){e.resetData(t.result),e.getQR(t.result.inc_id,!0)}))}})}})},qrChange:function(){var e=this;wx.showModal({title:"立即扫描目标码",content:"个人信息将转移到目标码，现有码信息将被清空！",success:function(t){t.confirm&&wx.scanCode({success:function(t){if(t.path&&t.path.indexOf("?")>-1&&t.path.indexOf("scene=")>-1){var n=e.getQueryVariable(t.path.split("?")[1],"scene");if(isNaN(n))return void wx.showToast({title:"请扫描正确的拨号码！",icon:"none"});var a=e.data.inc_id;a==n?wx.showToast({title:"您已绑定该目标码！",icon:"none",duration:3e3}):wx.showModal({title:"扫描成功",content:"您确认要换绑吗？",success:function(t){t.confirm&&(wx.showLoading({title:"换绑中...",mask:!0}),wx.cloud.callFunction({name:"qrChange",data:{new_inc_id:parseInt(n),old_inc_id:a},success:function(t){wx.hideLoading(),200==t.result?(wx.showToast({title:"换绑成功！",icon:"none"}),e.getQR(n,!0),e.setData({inc_id:n})):300==t.result?wx.showToast({title:"请扫描正确的拨号码！",icon:"none",duration:3e3}):400==t.result?wx.showToast({title:"该目标码已被其他用户绑定！",icon:"none",duration:3e3}):wx.showToast({title:"网络异常！",icon:"none",duration:3e3})}}))}})}else wx.showToast({title:"请扫描正确的拨号码！",icon:"none"})}})}})},safe_textDone:function(e){var t=this;e.detail.value!=t.data.safe_text&&(wx.showLoading({title:"文案检测中",mask:!0}),wx.cloud.callFunction({name:"msgSecCheck",data:{content:e.detail.value}}).then((function(n){wx.hideLoading(),0==n.result.errCode?wx.cloud.callFunction({name:"getUserInfo",data:{safe_text:e.detail.value,inc_id:t.data.inc_id}}).then((function(n){t.setData({safe_text:e.detail.value}),wx.showToast({title:"保存成功",icon:"none"})})):(wx.showToast({title:"文案存在违法违规风险，请重新输入！",icon:"none",duration:3e3}),t.setData({safe_text:""}))})))},nameDone:function(e){var t=this;e.detail.value!=t.data.name&&(wx.showLoading({title:"名字检测中",mask:!0}),wx.cloud.callFunction({name:"msgSecCheck",data:{content:e.detail.value}}).then((function(n){wx.hideLoading(),0==n.result.errCode?wx.cloud.callFunction({name:"getUserInfo",data:{name:e.detail.value,inc_id:t.data.inc_id}}).then((function(n){t.setData({name:e.detail.value}),wx.showToast({title:"保存成功",icon:"none"})})):(wx.showToast({title:"名字存在违法违规风险，请重新输入！",icon:"none",duration:3e3}),t.setData({name:""}))})))},phoneDone:function(e){var t=this;e.detail.value!=t.data.phone&&t.data.inc_id&&(wx.showLoading({title:"号码检测中",mask:!0}),wx.cloud.callFunction({name:"msgSecCheck",data:{content:e.detail.value}}).then((function(n){wx.hideLoading(),0==n.result.errCode?wx.cloud.callFunction({name:"getUserInfo",data:{phone:e.detail.value,inc_id:t.data.inc_id}}).then((function(n){t.setData({phone:e.detail.value}),wx.showToast({title:"保存成功",icon:"none"})})):(wx.showToast({title:"号码存在违法违规风险，请重新输入！",icon:"none",duration:3e3}),t.setData({phone:""}))})))},msgDone:function(e){var t=this;e.detail||(e.detail=""),e.detail!=this.data.msg&&wx.cloud.callFunction({name:"getUserInfo",data:{msg:e.detail,inc_id:this.data.inc_id}}).then((function(n){t.setData({msg:e.detail}),wx.showToast({title:"保存成功",icon:"none"})}))},preview:function(){wx.previewImage({urls:[this.data.src]})},previewCall:function(){wx.navigateTo({url:"/sc/c?scene="+this.data.inc_id})},getPhoneNumber:function(e){var t=this;wx.hideLoading();var n=this;e.detail.cloudID&&(wx.showLoading({title:"获取中",mask:!0}),wx.cloud.callFunction({name:"login",data:{weRunData:wx.cloud.CloudID(e.detail.cloudID),code:!!e.detail.code&&e.detail.code}}).then((function(a){wx.hideLoading();var o=e.detail.code?a.result.phoneInfo.phoneNumber:a.result.event.weRunData.data.phoneNumber;t.setData({phone:o}),n.data.inc_id&&wx.cloud.callFunction({name:"getUserInfo",data:{phone:o,inc_id:n.data.inc_id}}).then((function(e){wx.showToast({title:"绑定成功",icon:"none"})}))})))},copySecurity:function(){this.data.security&&wx.setClipboardData({data:this.data.security,success:function(){wx.hideLoading(),wx.showToast({title:"ID复制成功",icon:"none"})}})},safeChange:function(e){this.setData({safe:e.detail.value});var t=0;e.detail.value&&(t=1),this.data.inc_id&&wx.cloud.callFunction({name:"getUserInfo",data:{safe:t,inc_id:this.data.inc_id}}).then((function(e){wx.showToast({title:"切换成功",icon:"none"})}))},restChange:function(e){var t=this;e.detail.value?wx.showModal({title:"是否开启勿扰模式？",content:"开启后所有人将无法扫码联系到你哟！",confirmText:"开启",confirmColor:"#E64340",cancelText:"不开启",cancelColor:"#07c160",success:function(n){n.confirm?(t.setData({rest:e.detail.value}),t.data.inc_id&&wx.cloud.callFunction({name:"getUserInfo",data:{rest:1,inc_id:t.data.inc_id}}).then((function(e){wx.showToast({title:"切换成功",icon:"none"})}))):n.cancel&&t.setData({rest:!1})}}):(t.setData({rest:e.detail.value}),t.data.inc_id&&wx.cloud.callFunction({name:"getUserInfo",data:{rest:0,inc_id:t.data.inc_id}}).then((function(e){wx.showToast({title:"切换成功",icon:"none"})})))},onLoad:function(e){var t=this;wx.cloud.callFunction({name:"getUserInfo",data:{}}).then((function(n){t.setData({show:!0}),t.resetData(n.result),t.getQR(n.result.inc_id,e.qrChange)})),wx.cloud.callFunction({name:"login",complete:function(e){t.setData({author:e.result})}})},resetData:function(e){this.setData({inc_id:e.inc_id,phone:e.phone?e.phone:"",name:e.name,safe:e.safe,safe_due_date:this.formatTime(e.safe_due_date),rest:e.rest,showAd:e.showAd,security:e._id?e._id:"首次分配",msg:e.msg,safe_text:e.safe_text})},getQR:function(e,t){var n=this;if(isNaN(e))wx.showToast({title:"获取失败，请稍后重试！",icon:"none"});else{var a=wx.getFileSystemManager(),o=wx.getStorageSync("code_cache"+e);o&&!t?a.access({path:o.toString(),success:function(e){n.setData({src:o})},fail:function(t){n.getUnlimitedCode(a,e)}}):n.getUnlimitedCode(a,e)}},getUnlimitedCode:function(e,t){var n=this;n.setData({src:""}),wx.cloud.callFunction({name:"getUnlimitedCode",data:{scene:t,page:"sc/c",width:1280},success:function(a){if(0==a.result.errCode){var o=wx.env.USER_DATA_PATH+"/"+n.data.inc_id+".png";e.writeFile({filePath:o,data:a.result.buffer,encoding:"binary",success:function(){n.setData({src:o}),wx.setStorageSync("code_cache"+t,o)}})}else wx.showToast({title:"网络异常，请稍后重试。",icon:"none",mask:!0})},fail:function(e){wx.showToast({title:"网络异常，请稍后重试。",icon:"none",mask:!0})}})},onOpenSetting:function(e,t){wx.openSetting({success:function(n){n.authSetting[e]?t():wx.showToast({title:"您未授权",icon:"none"})}})},savedownloadFile:function(){var e=this;e.data.src.indexOf("loading")>-1?wx.showToast({title:"未获取到圆形码图片",icon:"none"}):wx.saveImageToPhotosAlbum({filePath:e.data.src,success:function(e){wx.showToast({title:"保存成功"})},fail:function(t){(t.errMsg.indexOf("deny")>-1||t.errMsg.indexOf("denied")>-1||t.errMsg.indexOf("auth")>-1)&&e.showModal("scope.writePhotosAlbum",(function(){e.savedownloadFile()}))}})},showModal:function(e,t){var n=this,a="";switch(e){case"scope.writePhotosAlbum":a="保存到相册";break;case"scope.addPhoneContact":a="添加到通讯录"}wx.showModal({title:"检测到您没有打开"+a+"的权限，是否前往设置打开？",success:function(a){a.confirm?n.onOpenSetting(e,t):a.cancel}})},formatTime:function(t,n){if(t){switch(n||(n="yyyy-MM-dd HH:mm"),e(t)){case"string":var a=!1;t.indexOf("T")>-1&&t.indexOf("Z")>-1&&(a=!0,t=t.replace(/T/g," ").substring(0,t.lastIndexOf("."))),t=t.replace(/-/g,"/"),t=new Date(t),a&&(t=new Date(t.getTime()+288e5));break;case"number":t=new Date(t)}if(!(!t instanceof Date)){var o={yyyy:t.getFullYear(),M:t.getMonth()+1,d:t.getDate(),H:t.getHours(),m:t.getMinutes(),s:t.getSeconds(),MM:(""+(t.getMonth()+101)).substr(1),dd:(""+(t.getDate()+100)).substr(1),HH:(""+(t.getHours()+100)).substr(1),mm:(""+(t.getMinutes()+100)).substr(1),ss:(""+(t.getSeconds()+100)).substr(1)};return n.replace(/(yyyy|MM?|dd?|HH?|ss?|mm?)/g,(function(){return o[arguments[0]]}))}}},onShareAppMessage:function(e){return"button"===e.from&&console.log(e.target),{title:"制作专属电话码，扫码虚拟号呼叫，保护真实号码安全",imageUrl:"cloud://zhijiebohao-4gp9aizse6797bd3.7a68-zhijiebohao-4gp9aizse6797bd3-1257150849/share.jpg",path:"/pages/safeIndex/safeIndex"}}});
},{isPage:true,isComponent:true,currentFile:'pages/safeIndex/safeIndex.js'});require("pages/safeIndex/safeIndex.js");$gwx_XC_31=function(_,_v,_n,_p,_s,_wp,_wl,$gwn,$gwl,$gwh,wh,$gstack,$gwrt,gra,grb,TestTest,wfor,_ca,_da,_r,_rz,_o,_oz,_1,_1z,_2,_2z,_m,_mz,nv_getDate,nv_getRegExp,nv_console,nv_parseInt,nv_parseFloat,nv_isNaN,nv_isFinite,nv_decodeURI,nv_decodeURIComponent,nv_encodeURI,nv_encodeURIComponent,$gdc,nv_JSON,_af,_gv,_ai,_grp,_gd,_gapi,$ixc,_ic,_w,_ev,_tsd){return function(path,global){
if(typeof global==='undefined'){if (typeof __GWX_GLOBAL__==='undefined')global={};else global=__GWX_GLOBAL__;}if(typeof __WXML_GLOBAL__ === 'undefined') {__WXML_GLOBAL__={};
}__WXML_GLOBAL__.modules = __WXML_GLOBAL__.modules || {};
var e_={}
if(typeof(global.entrys)==='undefined')global.entrys={};e_=global.entrys;
var d_={}
if(typeof(global.defines)==='undefined')global.defines={};d_=global.defines;
var f_={}
if(typeof(global.modules)==='undefined')global.modules={};f_=global.modules || {};
var p_={}
__WXML_GLOBAL__.ops_cached = __WXML_GLOBAL__.ops_cached || {}
__WXML_GLOBAL__.ops_set = __WXML_GLOBAL__.ops_set || {};
__WXML_GLOBAL__.ops_init = __WXML_GLOBAL__.ops_init || {};
var z=__WXML_GLOBAL__.ops_set.$gwx_XC_31 || [];
function gz$gwx_XC_31_1(){
if( __WXML_GLOBAL__.ops_cached.$gwx_XC_31_1)return __WXML_GLOBAL__.ops_cached.$gwx_XC_31_1
__WXML_GLOBAL__.ops_cached.$gwx_XC_31_1=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
})(__WXML_GLOBAL__.ops_cached.$gwx_XC_31_1);return __WXML_GLOBAL__.ops_cached.$gwx_XC_31_1
}
__WXML_GLOBAL__.ops_set.$gwx_XC_31=z;
__WXML_GLOBAL__.ops_init.$gwx_XC_31=true;
var x=['./pages/webview/webview.wxml'];d_[x[0]]={}
var m0=function(e,s,r,gg){
var z=gz$gwx_XC_31_1()
return r
}
e_[x[0]]={f:m0,j:[],i:[],ti:[],ic:[]}
if(path&&e_[path]){
return function(env,dd,global){$gwxc=0;var root={"tag":"wx-page"};root.children=[]
;g="$gwx_XC_31";var main=e_[path].f
if (typeof global==="undefined")global={};global.f=$gdc(f_[path],"",1);
try{
main(env,{},root,global);
_tsd(root)
}catch(err){
console.log(err)
}
;g="";
return root;
}
}
}
}(__g.a,__g.b,__g.c,__g.d,__g.e,__g.f,__g.g,__g.h,__g.i,__g.j,__g.k,__g.l,__g.m,__g.n,__g.o,__g.p,__g.q,__g.r,__g.s,__g.t,__g.u,__g.v,__g.w,__g.x,__g.y,__g.z,__g.A,__g.B,__g.C,__g.D,__g.E,__g.F,__g.G,__g.H,__g.I,__g.J,__g.K,__g.L,__g.M,__g.N,__g.O,__g.P,__g.Q,__g.R,__g.S,__g.T,__g.U,__g.V,__g.W,__g.X,__g.Y,__g.Z,__g.aa);if(__vd_version_info__.delayedGwx||false)$gwx_XC_31();	if (__vd_version_info__.delayedGwx) __wxAppCode__['pages/webview/webview.wxml'] = [$gwx_XC_31, './pages/webview/webview.wxml'];else __wxAppCode__['pages/webview/webview.wxml'] = $gwx_XC_31( './pages/webview/webview.wxml' );
	;__wxRoute = "pages/webview/webview";__wxRouteBegin = true;__wxAppCurrentFile__="pages/webview/webview.js";define("pages/webview/webview.js",function(require,module,exports,window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){
"use strict";wx.cloud.init();var e=wx.cloud.database({env:"zhijiebohao-4gp9aizse6797bd3"}),t=e.command;e.collection("files");Page({data:{url:""},messageSuccess:function(e){if(e&&e.detail&&e.detail.data.length>0){var t=e.detail.data[0];t.db&&t.id&&wx.cloud.callFunction({name:"addIpProvince",data:t})}},onLoad:function(a){var i=a.id,n=this;i?e.collection("method_list").where({_id:t.eq(i)}).field({name:!0,content:!0}).get({success:function(e){var t=e.data[0].content;t=t.replace(new RegExp("{VIRTUAL_VERSION}","g"),10);var i=a.unionId;i&&(t=t.replace(new RegExp("{UNION_ID}","g"),i)),n.setData({url:t})}}):n.setData({url:decodeURIComponent(a.url)})},getQueryVariable:function(e,t){if(e&&e.indexOf("?")>-1)for(var a=e.split("?")[1].split("&"),i=0;i<a.length;i++){var n=a[i].split("=");if(n[0].trim()==t.trim())return n[1].trim()}return!1}});
},{isPage:true,isComponent:true,currentFile:'pages/webview/webview.js'});require("pages/webview/webview.js");$gwx_XC_32=function(_,_v,_n,_p,_s,_wp,_wl,$gwn,$gwl,$gwh,wh,$gstack,$gwrt,gra,grb,TestTest,wfor,_ca,_da,_r,_rz,_o,_oz,_1,_1z,_2,_2z,_m,_mz,nv_getDate,nv_getRegExp,nv_console,nv_parseInt,nv_parseFloat,nv_isNaN,nv_isFinite,nv_decodeURI,nv_decodeURIComponent,nv_encodeURI,nv_encodeURIComponent,$gdc,nv_JSON,_af,_gv,_ai,_grp,_gd,_gapi,$ixc,_ic,_w,_ev,_tsd){return function(path,global){
if(typeof global==='undefined'){if (typeof __GWX_GLOBAL__==='undefined')global={};else global=__GWX_GLOBAL__;}if(typeof __WXML_GLOBAL__ === 'undefined') {__WXML_GLOBAL__={};
}__WXML_GLOBAL__.modules = __WXML_GLOBAL__.modules || {};
var e_={}
if(typeof(global.entrys)==='undefined')global.entrys={};e_=global.entrys;
var d_={}
if(typeof(global.defines)==='undefined')global.defines={};d_=global.defines;
var f_={}
if(typeof(global.modules)==='undefined')global.modules={};f_=global.modules || {};
var p_={}
__WXML_GLOBAL__.ops_cached = __WXML_GLOBAL__.ops_cached || {}
__WXML_GLOBAL__.ops_set = __WXML_GLOBAL__.ops_set || {};
__WXML_GLOBAL__.ops_init = __WXML_GLOBAL__.ops_init || {};
var z=__WXML_GLOBAL__.ops_set.$gwx_XC_32 || [];
function gz$gwx_XC_32_1(){
if( __WXML_GLOBAL__.ops_cached.$gwx_XC_32_1)return __WXML_GLOBAL__.ops_cached.$gwx_XC_32_1
__WXML_GLOBAL__.ops_cached.$gwx_XC_32_1=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
Z([[7],[3,'userInfo']])
Z([3,'position:relative;display:flex;align-items:center;justify-content:center;flex-direction: column;padding-top:30rpx;'])
Z([[2,'>='],[[12],[[6],[[7],[3,'msgutil']],[3,'compareVersion']],[[5],[[5],[[6],[[7],[3,'systemInfo']],[3,'SDKVersion']]],[1,'2.24.4']]],[1,0]])
Z([3,'saveAvatar'])
Z([3,'clear-button-style'])
Z([3,'1'])
Z([3,'chooseAvatar'])
Z([3,'flex-shrink:0;'])
Z([[2,'&&'],[[7],[3,'userInfo']],[[6],[[7],[3,'userInfo']],[3,'avatarUrl']]])
Z([3,'my-icon'])
Z([3,'#969696'])
Z([3,'xiugaitouxiang'])
Z([3,'44rpx'])
Z(z[6])
Z(z[4])
Z(z[5])
Z(z[7])
Z(z[8])
Z(z[9])
Z(z[10])
Z(z[11])
Z(z[12])
Z([[6],[[7],[3,'userInfo']],[3,'phone']])
Z([[7],[3,'addNotice']])
Z([3,'readNotice'])
Z([3,'volume-o'])
Z([3,'closeable'])
Z([1,true])
Z(z[23])
Z([[2,'&&'],[[7],[3,'group0']],[[2,'>'],[[6],[[7],[3,'group0']],[3,'length']],[1,0]]])
Z([3,'index'])
Z([3,'method'])
Z([[7],[3,'group0']])
Z(z[30])
Z([[2,'||'],[[2,'||'],[[2,'||'],[[2,'||'],[[2,'||'],[[2,'=='],[[6],[[7],[3,'method']],[3,'type']],[1,1]],[[2,'=='],[[6],[[7],[3,'method']],[3,'type']],[1,2]]],[[2,'=='],[[6],[[7],[3,'method']],[3,'type']],[1,5]]],[[2,'=='],[[6],[[7],[3,'method']],[3,'type']],[1,6]]],[[2,'=='],[[6],[[7],[3,'method']],[3,'type']],[1,9]]],[[2,'=='],[[6],[[7],[3,'method']],[3,'type']],[1,10]]])
Z([3,'toMethod'])
Z([[4],[[5],[[5],[1,'li']],[[2,'?:'],[[2,'=='],[[7],[3,'index']],[[2,'-'],[[6],[[7],[3,'group0']],[3,'length']],[1,1]]],[1,'noborder'],[1,'']]]])
Z([1,0])
Z([[7],[3,'index']])
Z([3,'hover'])
Z([[6],[[7],[3,'method']],[3,'icon']])
Z([[2,'||'],[[2,'||'],[[2,'||'],[[2,'=='],[[6],[[7],[3,'method']],[3,'type']],[1,3]],[[2,'=='],[[6],[[7],[3,'method']],[3,'type']],[1,4]]],[[2,'=='],[[6],[[7],[3,'method']],[3,'type']],[1,7]]],[[2,'=='],[[6],[[7],[3,'method']],[3,'type']],[1,8]]])
Z(z[40])
Z([[2,'>'],[[6],[[7],[3,'group0']],[3,'length']],[[2,'+'],[[7],[3,'index']],[1,1]]])
Z([[2,'&&'],[[7],[3,'group1']],[[2,'>'],[[6],[[7],[3,'group1']],[3,'length']],[1,0]]])
Z(z[30])
Z(z[31])
Z([[7],[3,'group1']])
Z(z[30])
Z(z[34])
Z(z[35])
Z([[4],[[5],[[5],[1,'li']],[[2,'?:'],[[2,'=='],[[7],[3,'index']],[[2,'-'],[[6],[[7],[3,'group1']],[3,'length']],[1,1]]],[1,'noborder'],[1,'']]]])
Z([1,1])
Z(z[38])
Z(z[39])
Z(z[40])
Z(z[41])
Z(z[40])
Z([[2,'>'],[[6],[[7],[3,'group1']],[3,'length']],[[2,'+'],[[7],[3,'index']],[1,1]]])
Z([[2,'&&'],[[7],[3,'group2']],[[2,'>'],[[6],[[7],[3,'group2']],[3,'length']],[1,0]]])
Z(z[30])
Z(z[31])
Z([[7],[3,'group2']])
Z(z[30])
Z([[2,'||'],[[2,'||'],[[2,'||'],[[2,'||'],[[2,'||'],[[2,'=='],[[6],[[7],[3,'method']],[3,'type']],[1,1]],[[2,'=='],[[6],[[7],[3,'method']],[3,'type']],[1,2]]],[[2,'=='],[[6],[[7],[3,'method']],[3,'type']],[1,5]]],[[2,'=='],[[6],[[7],[3,'method']],[3,'type']],[1,6]]],[[2,'=='],[[6],[[7],[3,'method']],[3,'type']],[1,9]]],[[2,'=='],[[6],[[7],[3,'method']],[3,'type']],[1,10]]])
Z(z[35])
Z([[4],[[5],[[5],[1,'li']],[[2,'?:'],[[2,'=='],[[7],[3,'index']],[[2,'-'],[[6],[[7],[3,'group2']],[3,'length']],[1,1]]],[1,'noborder'],[1,'']]]])
Z([1,2])
Z(z[38])
Z(z[39])
Z(z[40])
Z(z[41])
Z(z[40])
Z([[2,'>'],[[6],[[7],[3,'group2']],[3,'length']],[[2,'+'],[[7],[3,'index']],[1,1]]])
Z([[2,'&&'],[[7],[3,'group3']],[[2,'>'],[[6],[[7],[3,'group3']],[3,'length']],[1,0]]])
Z(z[30])
Z(z[31])
Z([[7],[3,'group3']])
Z(z[30])
Z(z[64])
Z(z[35])
Z([[4],[[5],[[5],[1,'li']],[[2,'?:'],[[2,'=='],[[7],[3,'index']],[[2,'-'],[[6],[[7],[3,'group3']],[3,'length']],[1,1]]],[1,'noborder'],[1,'']]]])
Z([1,3])
Z(z[38])
Z(z[39])
Z(z[40])
Z(z[41])
Z(z[40])
Z([[2,'>'],[[6],[[7],[3,'group3']],[3,'length']],[[2,'+'],[[7],[3,'index']],[1,1]]])
Z([[2,'&&'],[[7],[3,'group4']],[[2,'>'],[[6],[[7],[3,'group4']],[3,'length']],[1,0]]])
Z(z[30])
Z(z[31])
Z([[7],[3,'group4']])
Z(z[30])
Z(z[64])
Z(z[35])
Z([[4],[[5],[[5],[1,'li']],[[2,'?:'],[[2,'=='],[[7],[3,'index']],[[2,'-'],[[6],[[7],[3,'group4']],[3,'length']],[1,1]]],[1,'noborder'],[1,'']]]])
Z([1,4])
Z(z[38])
Z(z[39])
Z(z[40])
Z(z[41])
Z(z[40])
Z([[2,'>'],[[6],[[7],[3,'group4']],[3,'length']],[[2,'+'],[[7],[3,'index']],[1,1]]])
Z([[2,'&&'],[[7],[3,'methodList']],[[2,'>'],[[6],[[7],[3,'methodList']],[3,'length']],[1,0]]])
Z([3,'center'])
Z([3,'margin:0 20%;'])
Z([3,'clickAgree'])
Z([3,'getPhoneNumber'])
Z([3,'取消'])
Z([3,'#07c160'])
Z([[2,'?:'],[[7],[3,'clickAgree']],[1,'getPhoneNumber'],[1,'']])
Z([3,'确定'])
Z([[7],[3,'showPhone']])
Z([a,[[2,'?:'],[[6],[[7],[3,'userInfo']],[3,'phone']],[1,'更换'],[1,'绑定']],[3,'手机号']])
Z([3,'myPrivacy'])
Z(z[27])
})(__WXML_GLOBAL__.ops_cached.$gwx_XC_32_1);return __WXML_GLOBAL__.ops_cached.$gwx_XC_32_1
}
__WXML_GLOBAL__.ops_set.$gwx_XC_32=z;
__WXML_GLOBAL__.ops_init.$gwx_XC_32=true;
var x=['./pages/work/method.wxml'];d_[x[0]]={}
var m0=function(e,s,r,gg){
var z=gz$gwx_XC_32_1()
var o2L=_v()
_(r,o2L)
if(_oz(z,0,e,s,gg)){o2L.wxVkey=1
var a0L=_n('view')
_rz(z,a0L,'style',1,e,s,gg)
var tAM=_v()
_(a0L,tAM)
if(_oz(z,2,e,s,gg)){tAM.wxVkey=1
var bCM=_mz(z,'button',['bind:chooseavatar',3,'class',1,'data-usertype',2,'openType',3,'style',4],[],e,s,gg)
var oDM=_v()
_(bCM,oDM)
if(_oz(z,8,e,s,gg)){oDM.wxVkey=1
}
else{oDM.wxVkey=2
var xEM=_mz(z,'van-icon',['classPrefix',9,'color',1,'name',2,'size',3],[],e,s,gg)
_(oDM,xEM)
}
oDM.wxXCkey=1
oDM.wxXCkey=3
_(tAM,bCM)
}
else{tAM.wxVkey=2
var oFM=_mz(z,'button',['bindtap',13,'class',1,'data-usertype',2,'style',3],[],e,s,gg)
var fGM=_v()
_(oFM,fGM)
if(_oz(z,17,e,s,gg)){fGM.wxVkey=1
}
else{fGM.wxVkey=2
var cHM=_mz(z,'van-icon',['classPrefix',18,'color',1,'name',2,'size',3],[],e,s,gg)
_(fGM,cHM)
}
fGM.wxXCkey=1
fGM.wxXCkey=3
_(tAM,oFM)
}
var eBM=_v()
_(a0L,eBM)
if(_oz(z,22,e,s,gg)){eBM.wxVkey=1
}
tAM.wxXCkey=1
tAM.wxXCkey=3
tAM.wxXCkey=3
eBM.wxXCkey=1
_(o2L,a0L)
}
else{o2L.wxVkey=2
}
var f3L=_v()
_(r,f3L)
if(_oz(z,23,e,s,gg)){f3L.wxVkey=1
var hIM=_mz(z,'van-notice-bar',['bind:close',24,'leftIcon',1,'mode',2,'scrollable',3,'text',4],[],e,s,gg)
_(f3L,hIM)
}
var c4L=_v()
_(r,c4L)
if(_oz(z,29,e,s,gg)){c4L.wxVkey=1
var oJM=_v()
_(c4L,oJM)
var cKM=function(lMM,oLM,aNM,gg){
var ePM=_v()
_(aNM,ePM)
if(_oz(z,34,lMM,oLM,gg)){ePM.wxVkey=1
var xSM=_mz(z,'view',['bindtap',35,'class',1,'data-group',2,'data-index',3,'hoverClass',4],[],lMM,oLM,gg)
var oTM=_v()
_(xSM,oTM)
if(_oz(z,40,lMM,oLM,gg)){oTM.wxVkey=1
}
oTM.wxXCkey=1
_(ePM,xSM)
}
var bQM=_v()
_(aNM,bQM)
if(_oz(z,41,lMM,oLM,gg)){bQM.wxVkey=1
var fUM=_v()
_(bQM,fUM)
if(_oz(z,42,lMM,oLM,gg)){fUM.wxVkey=1
}
fUM.wxXCkey=1
}
var oRM=_v()
_(aNM,oRM)
if(_oz(z,43,lMM,oLM,gg)){oRM.wxVkey=1
}
ePM.wxXCkey=1
bQM.wxXCkey=1
oRM.wxXCkey=1
return aNM
}
oJM.wxXCkey=2
_2z(z,32,cKM,e,s,gg,oJM,'method','index','index')
}
var h5L=_v()
_(r,h5L)
if(_oz(z,44,e,s,gg)){h5L.wxVkey=1
var cVM=_v()
_(h5L,cVM)
var hWM=function(cYM,oXM,oZM,gg){
var a2M=_v()
_(oZM,a2M)
if(_oz(z,49,cYM,oXM,gg)){a2M.wxVkey=1
var b5M=_mz(z,'view',['bindtap',50,'class',1,'data-group',2,'data-index',3,'hoverClass',4],[],cYM,oXM,gg)
var o6M=_v()
_(b5M,o6M)
if(_oz(z,55,cYM,oXM,gg)){o6M.wxVkey=1
}
o6M.wxXCkey=1
_(a2M,b5M)
}
var t3M=_v()
_(oZM,t3M)
if(_oz(z,56,cYM,oXM,gg)){t3M.wxVkey=1
var x7M=_v()
_(t3M,x7M)
if(_oz(z,57,cYM,oXM,gg)){x7M.wxVkey=1
}
x7M.wxXCkey=1
}
var e4M=_v()
_(oZM,e4M)
if(_oz(z,58,cYM,oXM,gg)){e4M.wxVkey=1
}
a2M.wxXCkey=1
t3M.wxXCkey=1
e4M.wxXCkey=1
return oZM
}
cVM.wxXCkey=2
_2z(z,47,hWM,e,s,gg,cVM,'method','index','index')
}
var o6L=_v()
_(r,o6L)
if(_oz(z,59,e,s,gg)){o6L.wxVkey=1
var o8M=_v()
_(o6L,o8M)
var f9M=function(hAN,c0M,oBN,gg){
var oDN=_v()
_(oBN,oDN)
if(_oz(z,64,hAN,c0M,gg)){oDN.wxVkey=1
var tGN=_mz(z,'view',['bindtap',65,'class',1,'data-group',2,'data-index',3,'hoverClass',4],[],hAN,c0M,gg)
var eHN=_v()
_(tGN,eHN)
if(_oz(z,70,hAN,c0M,gg)){eHN.wxVkey=1
}
eHN.wxXCkey=1
_(oDN,tGN)
}
var lEN=_v()
_(oBN,lEN)
if(_oz(z,71,hAN,c0M,gg)){lEN.wxVkey=1
var bIN=_v()
_(lEN,bIN)
if(_oz(z,72,hAN,c0M,gg)){bIN.wxVkey=1
}
bIN.wxXCkey=1
}
var aFN=_v()
_(oBN,aFN)
if(_oz(z,73,hAN,c0M,gg)){aFN.wxVkey=1
}
oDN.wxXCkey=1
lEN.wxXCkey=1
aFN.wxXCkey=1
return oBN
}
o8M.wxXCkey=2
_2z(z,62,f9M,e,s,gg,o8M,'method','index','index')
}
var c7L=_v()
_(r,c7L)
if(_oz(z,74,e,s,gg)){c7L.wxVkey=1
var oJN=_v()
_(c7L,oJN)
var xKN=function(fMN,oLN,cNN,gg){
var oPN=_v()
_(cNN,oPN)
if(_oz(z,79,fMN,oLN,gg)){oPN.wxVkey=1
var lSN=_mz(z,'view',['bindtap',80,'class',1,'data-group',2,'data-index',3,'hoverClass',4],[],fMN,oLN,gg)
var aTN=_v()
_(lSN,aTN)
if(_oz(z,85,fMN,oLN,gg)){aTN.wxVkey=1
}
aTN.wxXCkey=1
_(oPN,lSN)
}
var cQN=_v()
_(cNN,cQN)
if(_oz(z,86,fMN,oLN,gg)){cQN.wxVkey=1
var tUN=_v()
_(cQN,tUN)
if(_oz(z,87,fMN,oLN,gg)){tUN.wxVkey=1
}
tUN.wxXCkey=1
}
var oRN=_v()
_(cNN,oRN)
if(_oz(z,88,fMN,oLN,gg)){oRN.wxVkey=1
}
oPN.wxXCkey=1
cQN.wxXCkey=1
oRN.wxXCkey=1
return cNN
}
oJN.wxXCkey=2
_2z(z,77,xKN,e,s,gg,oJN,'method','index','index')
}
var o8L=_v()
_(r,o8L)
if(_oz(z,89,e,s,gg)){o8L.wxVkey=1
var eVN=_v()
_(o8L,eVN)
var bWN=function(xYN,oXN,oZN,gg){
var c2N=_v()
_(oZN,c2N)
if(_oz(z,94,xYN,oXN,gg)){c2N.wxVkey=1
var c5N=_mz(z,'view',['bindtap',95,'class',1,'data-group',2,'data-index',3,'hoverClass',4],[],xYN,oXN,gg)
var o6N=_v()
_(c5N,o6N)
if(_oz(z,100,xYN,oXN,gg)){o6N.wxVkey=1
}
o6N.wxXCkey=1
_(c2N,c5N)
}
var h3N=_v()
_(oZN,h3N)
if(_oz(z,101,xYN,oXN,gg)){h3N.wxVkey=1
var l7N=_v()
_(h3N,l7N)
if(_oz(z,102,xYN,oXN,gg)){l7N.wxVkey=1
}
l7N.wxXCkey=1
}
var o4N=_v()
_(oZN,o4N)
if(_oz(z,103,xYN,oXN,gg)){o4N.wxVkey=1
}
c2N.wxXCkey=1
h3N.wxXCkey=1
o4N.wxXCkey=1
return oZN
}
eVN.wxXCkey=2
_2z(z,92,bWN,e,s,gg,eVN,'method','index','index')
}
var l9L=_v()
_(r,l9L)
if(_oz(z,104,e,s,gg)){l9L.wxVkey=1
var a8N=_mz(z,'van-divider',['contentPosition',105,'customStyle',1],[],e,s,gg)
_(l9L,a8N)
}
var t9N=_mz(z,'van-dialog',['showCancelButton',-1,'useSlot',-1,'bind:confirm',107,'bind:getphonenumber',1,'cancelButtonText',2,'confirmButtonColor',3,'confirmButtonOpenType',4,'confirmButtonText',5,'show',6,'title',7],[],e,s,gg)
_(r,t9N)
var e0N=_mz(z,'my-privacy',['id',115,'requireFirst',1],[],e,s,gg)
_(r,e0N)
o2L.wxXCkey=1
o2L.wxXCkey=3
f3L.wxXCkey=1
f3L.wxXCkey=3
c4L.wxXCkey=1
h5L.wxXCkey=1
o6L.wxXCkey=1
c7L.wxXCkey=1
o8L.wxXCkey=1
l9L.wxXCkey=1
l9L.wxXCkey=3
return r
}
e_[x[0]]={f:m0,j:[],i:[],ti:[],ic:[]}
if(path&&e_[path]){
return function(env,dd,global){$gwxc=0;var root={"tag":"wx-page"};root.children=[]
;g="$gwx_XC_32";var main=e_[path].f
if (typeof global==="undefined")global={};global.f=$gdc(f_[path],"",1);
try{
main(env,{},root,global);
_tsd(root)
}catch(err){
console.log(err)
}
;g="";
return root;
}
}
}
}(__g.a,__g.b,__g.c,__g.d,__g.e,__g.f,__g.g,__g.h,__g.i,__g.j,__g.k,__g.l,__g.m,__g.n,__g.o,__g.p,__g.q,__g.r,__g.s,__g.t,__g.u,__g.v,__g.w,__g.x,__g.y,__g.z,__g.A,__g.B,__g.C,__g.D,__g.E,__g.F,__g.G,__g.H,__g.I,__g.J,__g.K,__g.L,__g.M,__g.N,__g.O,__g.P,__g.Q,__g.R,__g.S,__g.T,__g.U,__g.V,__g.W,__g.X,__g.Y,__g.Z,__g.aa);if(__vd_version_info__.delayedGwx||false)$gwx_XC_32();	if (__vd_version_info__.delayedGwx) __wxAppCode__['pages/work/method.wxml'] = [$gwx_XC_32, './pages/work/method.wxml'];else __wxAppCode__['pages/work/method.wxml'] = $gwx_XC_32( './pages/work/method.wxml' );
	;__wxRoute = "pages/work/method";__wxRouteBegin = true;__wxAppCurrentFile__="pages/work/method.js";define("pages/work/method.js",function(require,module,exports,window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){
"use strict";var e=require("../../@babel/runtime/helpers/regeneratorRuntime"),t=require("../../@babel/runtime/helpers/asyncToGenerator");wx.cloud.init();var o,a,n=wx.cloud.database({env:"zhijiebohao-4gp9aizse6797bd3"}),i=n.command,r=n.collection("user_inc_id"),s=n.collection("msg_user"),u=require("../../components/cos/cos-wx-sdk-v5.min"),c=void 0;Page({data:{showPhone:!1,addNotice:"",userInfo:void 0,methodList:[],group0:[],group1:[],group2:[],group3:[],group4:[],systemInfo:wx.getSystemInfoSync(),clickAgree:!1},clickAgreeChange:function(e){this.setData({clickAgree:!this.data.clickAgree})},showProtocol:function(){wx.navigateTo({url:"/pages/methodD/methodD?id=18"})},clearCache:function(){wx.showLoading({title:"清理中",mask:!0});var e=setTimeout((function(){wx.hideLoading(),wx.clearStorage({success:function(){wx.showToast({title:"清理成功",icon:"none"}),clearTimeout(e)}})}),1e3)},toNotice:function(){var e="/pages/webview/webview?url="+encodeURIComponent("https://zhijiebohao-4gp9aizse6797bd3-1257150849.tcloudbaseapp.com/gzh.html?miniAppId=wx5c9674e6177b0f6a&miniEnvId=zhijiebohao-4gp9aizse6797bd3&authorized="+(!(!this.data.userInfo||!this.data.userInfo.xzffw_openid)||""));wx.navigateTo({url:e})},toMethod:function(e){var t=e.currentTarget.dataset.index,o={};switch(e.currentTarget.dataset.group){case 0:o=this.data.group0[t];break;case 1:o=this.data.group1[t];break;case 2:o=this.data.group2[t];break;case 3:o=this.data.group3[t];break;case 4:o=this.data.group4[t]}1==o.type?o.name.indexOf("通知")>-1||o.name.indexOf("消息")>-1?this.toNotice():wx.navigateTo({url:o.url}):2==o.type?wx.navigateToMiniProgram({appId:o.content,path:o.url}):5==o.type?wx.switchTab({url:o.url}):6==o.type?wx.openCustomerServiceChat?wx.openCustomerServiceChat({extInfo:{url:o.url},corpId:o.content,success:function(e){},fail:function(e){wx.showToast({title:"请使用最新版手机微信重试",icon:"none"})}}):wx.showToast({title:"请使用最新版手机微信重试",icon:"none"}):9==o.type?wx.openEmbeddedMiniProgram({path:o.url,appId:o.content}):10==o.type&&wx.setClipboardData({data:o.content})},onLoad:(a=t(e().mark((function t(o){var a;return e().wrap((function(e){for(;;)switch(e.prev=e.next){case 0:a=this,wx.getStorage({key:"methodList",success:function(e){if(e.data){var t=JSON.parse(e.data),o=t.filter((function(e){return 0==e.group&&!e.onlyHome})),n=t.filter((function(e){return 1==e.group&&!e.onlyHome})),i=t.filter((function(e){return 2==e.group&&!e.onlyHome})),r=t.filter((function(e){return 3==e.group&&!e.onlyHome})),s=t.filter((function(e){return 4==e.group&&!e.onlyHome}));a.setData({methodList:t,group0:o,group1:n,group2:i,group3:r,group4:s})}}}),wx.getStorage({key:"userInfo",success:function(e){if(e.data){var t=JSON.parse(e.data);a.setData({userInfo:t})}}}),a.getMethodList(),wx.cloud.callFunction({name:"login",complete:function(e){var t=e.result;a.setData({userInfo:t}),wx.setStorage({key:"userInfo",data:JSON.stringify(t)}),t&&!t.readNotice&&r.where({_id:i.eq("notice")}).field({text:!0}).get({success:function(e){if(e&&e.data.length>0){var t=e.data[0];a.setData({addNotice:t.text})}}})}}),this.initCOS();case 6:case"end":return e.stop()}}),t,this)}))),function(e){return a.apply(this,arguments)}),readNotice:function(){var e=this;e.data.userInfo.readNotice||s.doc(e.data.userInfo._id).update({data:{readNotice:!0},success:function(t){e.setData({addNotice:""})}})},getMethodList:(o=t(e().mark((function t(){var o,a,r,s,u,c,d,l;return e().wrap((function(e){for(;;)switch(e.prev=e.next){case 0:return(o={}).status=i.eq(!0),e.next=4,n.collection("method_list").where(o).field({_id:!0,name:!0,content:!0,type:!0,url:!0,icon:!0,group:!0,isHome:!0,onlyHome:!0,homeIcon:!0,homeName:!0}).orderBy("sort","asc").get();case 4:a=e.sent,r=a.data,s=r.filter((function(e){return 0==e.group&&!e.onlyHome})),u=r.filter((function(e){return 1==e.group&&!e.onlyHome})),c=r.filter((function(e){return 2==e.group&&!e.onlyHome})),d=r.filter((function(e){return 3==e.group&&!e.onlyHome})),l=r.filter((function(e){return 4==e.group&&!e.onlyHome})),this.setData({methodList:r,group0:s,group1:u,group2:c,group3:d,group4:l}),wx.setStorage({key:"methodList",data:JSON.stringify(r)});case 13:case"end":return e.stop()}}),t,this)}))),function(){return o.apply(this,arguments)}),onImageCropperConfirm:function(e,t){var o=this;if(e){var a=e,n=o.data.saveusertype,r=1==n?o.data.userInfo:o.data.author;t=t||a.substr(a.lastIndexOf("."));var u="avatar/"+r._openid+"/"+(new Date).getTime()+t;wx.showLoading({title:"头像上传中",mask:!0}),c.postObject({Bucket:"lg-h5g2gu1y-1257150849",Region:"ap-shanghai",Key:u,FilePath:a},(function(e,t){t?s.where({_openid:i.eq(r._openid)}).update({data:{avatarUrl:t.Location.replace("lg-h5g2gu1y-1257150849.cos.ap-shanghai.myqcloud.com","cos.wsqytec.com"),unionid:r.unionid?r.unionid:r.reAuth.unionid}}).then((function(e){wx.hideLoading(),r.avatarUrl=t.Location.replace("lg-h5g2gu1y-1257150849.cos.ap-shanghai.myqcloud.com","cos.wsqytec.com"),r.unionid=r.unionid?r.unionid:r.reAuth.unionid,1==n?o.setData({userInfo:r},(function(){wx.showToast({title:"头像保存成功",icon:"none"}),o.data.authority&&o.setData({author:r})})):o.setData({author:r},(function(){wx.showToast({title:"头像保存成功",icon:"none"}),o.data.authority&&o.setData({userInfo:r})}))})):(wx.hideLoading(),wx.showToast({title:"头像上传失败",icon:"none"}),o.initCOS())}))}},chooseAvatar:function(e){var t=e.currentTarget.dataset.usertype,o=this;wx.chooseMedia({count:1,mediaType:["image"],sizeType:["compressed"],sourceType:["album","camera"],success:function(e){var a=e.tempFiles[0].tempFilePath;o.saveAvatar({detail:{avatarUrl:a},currentTarget:{dataset:{usertype:t}}})}})},saveAvatar:function(e){var t=e.currentTarget.dataset.usertype,o=e.detail.avatarUrl;if(this.setData({saveusertype:t}),e.type){var a=o.substr(o.lastIndexOf("."));this.onImageCropperConfirm(o,a)}else wx.navigateTo({url:"/vantPage/image-cropper/image-cropper?initSrc="+o})},saveNickName:function(e){var t=e.currentTarget.dataset.usertype,o=this,a=e.detail.value,n=1==t?o.data.userInfo:o.data.author;a&&n.nickName!=a&&(wx.showLoading({title:"昵称检测中",mask:!0}),wx.cloud.callFunction({name:"msgSecCheck",data:{content:a}}).then((function(e){wx.hideLoading(),0==e.result.errCode?s.where({_openid:i.eq(n._openid)}).update({data:{nickName:a,unionid:n.unionid?n.unionid:n.reAuth.unionid}}).then((function(e){n.nickName=a,n.unionid=n.unionid?n.unionid:n.reAuth.unionid,1==t?o.setData({userInfo:n},(function(){wx.showToast({title:"昵称保存成功",icon:"none"}),o.data.authority&&o.setData({author:n})})):o.setData({author:n},(function(){wx.showToast({title:"昵称保存成功",icon:"none"}),o.data.authority&&o.setData({userInfo:n})}))})):wx.showToast({title:"昵称存在违法违规风险，请重新输入！",icon:"none",duration:3e3})})))},initCOS:function(){wx.cloud.callFunction({name:"cosSts",complete:function(e){c=new u({getAuthorization:function(t,o){o({TmpSecretId:e.result.credentials.tmpSecretId,TmpSecretKey:e.result.credentials.tmpSecretKey,SecurityToken:e.result.credentials.sessionToken,StartTime:e.result.startTime,ExpiredTime:e.result.expiredTime})}})}})},toFoot:function(){wx.navigateTo({url:"/vantPage/simpleHistory/simpleHistory"})},toDetail:function(){wx.navigateTo({url:"/pages/webview/webview?id=3"})},toVipDetail:function(){wx.navigateTo({url:"/pages/webview/webview?id=20&unionId="+this.data.userInfo.unionid})},toHelp:function(){wx.navigateTo({url:"/vantPage/question/question"})},showPhone:function(){this.setData({showPhone:!0})},clickAgree:function(){if(!this.data.clickAgree)return wx.showToast({title:"请先阅读并勾选文件服务协议",icon:"none"}),void this.setData({showPhone:!0})},getPhoneNumber:function(e){var t=this;wx.hideLoading(),e.detail.cloudID&&(wx.showLoading({title:"获取中",mask:!0}),wx.cloud.callFunction({name:"login",data:{weRunData:wx.cloud.CloudID(e.detail.cloudID),code:!!e.detail.code&&e.detail.code}}).then((function(o){wx.hideLoading();var a=e.detail.code?o.result.phoneInfo.phoneNumber:o.result.event.weRunData.data.phoneNumber;wx.showLoading({title:"绑定中",mask:!0}),s.doc(t.data.userInfo._id).update({data:{phone:a,agreeProtocol:!0},success:function(e){wx.hideLoading();var o=t.data.userInfo;o.phone=a,o.agreeProtocol=!0,t.setData({userInfo:o}),wx.showToast({title:"绑定成功",icon:"none"})}})})))},deviceInfo:function(){wx.navigateTo({url:"/vantPage/deviceInfo/info"})},onPageScroll:function(e){e.scrollTop>200&&"小正方助手"!=this.navTitle?(this.navTitle="小正方助手",wx.setNavigationBarTitle({title:"小正方助手"})):e.scrollTop<=200&&""!=this.navTitle&&(this.navTitle="",wx.setNavigationBarTitle({title:""}))},onShareAppMessage:function(e){return{title:"专业的云服务平台，提供云文件、地址路径、安全通话等服务。",imageUrl:"cloud://zhijiebohao-4gp9aizse6797bd3.7a68-zhijiebohao-4gp9aizse6797bd3-1257150849/share-xzf.jpg"}},compareVersion:function(e,t){e=e.split("."),t=t.split(".");for(var o=Math.max(e.length,t.length);e.length<o;)e.push("0");for(;t.length<o;)t.push("0");for(var a=0;a<o;a++){var n=parseInt(e[a]),i=parseInt(t[a]);if(n>i)return 1;if(n<i)return-1}return 0}});
},{isPage:true,isComponent:true,currentFile:'pages/work/method.js'});require("pages/work/method.js");$gwx_XC_33=function(_,_v,_n,_p,_s,_wp,_wl,$gwn,$gwl,$gwh,wh,$gstack,$gwrt,gra,grb,TestTest,wfor,_ca,_da,_r,_rz,_o,_oz,_1,_1z,_2,_2z,_m,_mz,nv_getDate,nv_getRegExp,nv_console,nv_parseInt,nv_parseFloat,nv_isNaN,nv_isFinite,nv_decodeURI,nv_decodeURIComponent,nv_encodeURI,nv_encodeURIComponent,$gdc,nv_JSON,_af,_gv,_ai,_grp,_gd,_gapi,$ixc,_ic,_w,_ev,_tsd){return function(path,global){
if(typeof global==='undefined'){if (typeof __GWX_GLOBAL__==='undefined')global={};else global=__GWX_GLOBAL__;}if(typeof __WXML_GLOBAL__ === 'undefined') {__WXML_GLOBAL__={};
}__WXML_GLOBAL__.modules = __WXML_GLOBAL__.modules || {};
var e_={}
if(typeof(global.entrys)==='undefined')global.entrys={};e_=global.entrys;
var d_={}
if(typeof(global.defines)==='undefined')global.defines={};d_=global.defines;
var f_={}
if(typeof(global.modules)==='undefined')global.modules={};f_=global.modules || {};
var p_={}
__WXML_GLOBAL__.ops_cached = __WXML_GLOBAL__.ops_cached || {}
__WXML_GLOBAL__.ops_set = __WXML_GLOBAL__.ops_set || {};
__WXML_GLOBAL__.ops_init = __WXML_GLOBAL__.ops_init || {};
var z=__WXML_GLOBAL__.ops_set.$gwx_XC_33 || [];
function gz$gwx_XC_33_1(){
if( __WXML_GLOBAL__.ops_cached.$gwx_XC_33_1)return __WXML_GLOBAL__.ops_cached.$gwx_XC_33_1
__WXML_GLOBAL__.ops_cached.$gwx_XC_33_1=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
})(__WXML_GLOBAL__.ops_cached.$gwx_XC_33_1);return __WXML_GLOBAL__.ops_cached.$gwx_XC_33_1
}
__WXML_GLOBAL__.ops_set.$gwx_XC_33=z;
__WXML_GLOBAL__.ops_init.$gwx_XC_33=true;
var x=['./paste_path_here.wxml'];d_[x[0]]={}
var m0=function(e,s,r,gg){
var z=gz$gwx_XC_33_1()
return r
}
e_[x[0]]={f:m0,j:[],i:[],ti:[],ic:[]}
if(path&&e_[path]){
return function(env,dd,global){$gwxc=0;var root={"tag":"wx-page"};root.children=[]
;g="$gwx_XC_33";var main=e_[path].f
if (typeof global==="undefined")global={};global.f=$gdc(f_[path],"",1);
try{
main(env,{},root,global);
_tsd(root)
}catch(err){
console.log(err)
}
;g="";
return root;
}
}
}
}(__g.a,__g.b,__g.c,__g.d,__g.e,__g.f,__g.g,__g.h,__g.i,__g.j,__g.k,__g.l,__g.m,__g.n,__g.o,__g.p,__g.q,__g.r,__g.s,__g.t,__g.u,__g.v,__g.w,__g.x,__g.y,__g.z,__g.A,__g.B,__g.C,__g.D,__g.E,__g.F,__g.G,__g.H,__g.I,__g.J,__g.K,__g.L,__g.M,__g.N,__g.O,__g.P,__g.Q,__g.R,__g.S,__g.T,__g.U,__g.V,__g.W,__g.X,__g.Y,__g.Z,__g.aa);if(__vd_version_info__.delayedGwx||false)$gwx_XC_33();	if (__vd_version_info__.delayedGwx) __wxAppCode__['paste_path_here.wxml'] = [$gwx_XC_33, './paste_path_here.wxml'];else __wxAppCode__['paste_path_here.wxml'] = $gwx_XC_33( './paste_path_here.wxml' );
	;__wxRoute = "paste_path_here";__wxRouteBegin = true;__wxAppCurrentFile__="paste_path_here.js";define("paste_path_here.js",function(require,module,exports,window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){
"use strict";Page({data:{},onLoad:function(e){var o=e.url;o?setTimeout((function(){wx.redirectTo({url:decodeURIComponent(o)})}),50):wx.reLaunch({url:"/pages/work/method"})}});
},{isPage:true,isComponent:true,currentFile:'paste_path_here.js'});require("paste_path_here.js");$gwx_XC_34=function(_,_v,_n,_p,_s,_wp,_wl,$gwn,$gwl,$gwh,wh,$gstack,$gwrt,gra,grb,TestTest,wfor,_ca,_da,_r,_rz,_o,_oz,_1,_1z,_2,_2z,_m,_mz,nv_getDate,nv_getRegExp,nv_console,nv_parseInt,nv_parseFloat,nv_isNaN,nv_isFinite,nv_decodeURI,nv_decodeURIComponent,nv_encodeURI,nv_encodeURIComponent,$gdc,nv_JSON,_af,_gv,_ai,_grp,_gd,_gapi,$ixc,_ic,_w,_ev,_tsd){return function(path,global){
if(typeof global==='undefined'){if (typeof __GWX_GLOBAL__==='undefined')global={};else global=__GWX_GLOBAL__;}if(typeof __WXML_GLOBAL__ === 'undefined') {__WXML_GLOBAL__={};
}__WXML_GLOBAL__.modules = __WXML_GLOBAL__.modules || {};
var e_={}
if(typeof(global.entrys)==='undefined')global.entrys={};e_=global.entrys;
var d_={}
if(typeof(global.defines)==='undefined')global.defines={};d_=global.defines;
var f_={}
if(typeof(global.modules)==='undefined')global.modules={};f_=global.modules || {};
var p_={}
__WXML_GLOBAL__.ops_cached = __WXML_GLOBAL__.ops_cached || {}
__WXML_GLOBAL__.ops_set = __WXML_GLOBAL__.ops_set || {};
__WXML_GLOBAL__.ops_init = __WXML_GLOBAL__.ops_init || {};
var z=__WXML_GLOBAL__.ops_set.$gwx_XC_34 || [];
function gz$gwx_XC_34_1(){
if( __WXML_GLOBAL__.ops_cached.$gwx_XC_34_1)return __WXML_GLOBAL__.ops_cached.$gwx_XC_34_1
__WXML_GLOBAL__.ops_cached.$gwx_XC_34_1=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
Z([3,'page'])
Z([[7],[3,'show']])
Z([3,'weui-msg'])
Z([3,'padding-top:0;'])
Z([[6],[[7],[3,'safeUser']],[3,'name']])
Z([3,'weui-btn-area'])
Z([[6],[[7],[3,'safeUser']],[3,'msg']])
Z([[7],[3,'showPhone']])
Z([[2,'&&'],[[2,'&&'],[[2,'!'],[[7],[3,'showPhone']]],[[2,'!'],[[6],[[7],[3,'safeUser']],[3,'rest']]]],[[2,'!'],[[7],[3,'scPhones']]]])
Z([[2,'&&'],[[2,'&&'],[[2,'!'],[[7],[3,'showPhone']]],[[2,'!'],[[6],[[7],[3,'safeUser']],[3,'rest']]]],[[7],[3,'scPhones']]])
Z([[2,'&&'],[[2,'!'],[[7],[3,'showPhone']]],[[6],[[7],[3,'safeUser']],[3,'rest']]])
Z([[2,'&&'],[[2,'!'],[[6],[[7],[3,'safeUser']],[3,'rest']]],[[2,'!'],[[7],[3,'showPhone']]]])
Z([3,'weui-msg__desc'])
Z([[2,'=='],[[6],[[7],[3,'safeUser']],[3,'curOpenid']],[[6],[[7],[3,'safeUser']],[3,'openid']]])
Z([[2,'!'],[[7],[3,'showPhone']]])
Z([[2,'!'],[[7],[3,'show']]])
Z([[7],[3,'scPhones']])
Z([3,'item'])
Z([[2,'=='],[[7],[3,'index']],[1,0]])
Z([3,'chooseScPhonesItem'])
Z([3,'myBtn'])
Z([[7],[3,'item']])
Z(z[18])
Z([3,'myPrivacy'])
})(__WXML_GLOBAL__.ops_cached.$gwx_XC_34_1);return __WXML_GLOBAL__.ops_cached.$gwx_XC_34_1
}
__WXML_GLOBAL__.ops_set.$gwx_XC_34=z;
__WXML_GLOBAL__.ops_init.$gwx_XC_34=true;
var x=['./sc/c.wxml'];d_[x[0]]={}
var m0=function(e,s,r,gg){
var z=gz$gwx_XC_34_1()
var xCO=_n('view')
_rz(z,xCO,'class',0,e,s,gg)
var oDO=_v()
_(xCO,oDO)
if(_oz(z,1,e,s,gg)){oDO.wxVkey=1
var cFO=_mz(z,'view',['class',2,'style',1],[],e,s,gg)
var hGO=_v()
_(cFO,hGO)
if(_oz(z,4,e,s,gg)){hGO.wxVkey=1
}
var oHO=_n('view')
_rz(z,oHO,'class',5,e,s,gg)
var cIO=_v()
_(oHO,cIO)
if(_oz(z,6,e,s,gg)){cIO.wxVkey=1
}
var oJO=_v()
_(oHO,oJO)
if(_oz(z,7,e,s,gg)){oJO.wxVkey=1
}
var lKO=_v()
_(oHO,lKO)
if(_oz(z,8,e,s,gg)){lKO.wxVkey=1
}
var aLO=_v()
_(oHO,aLO)
if(_oz(z,9,e,s,gg)){aLO.wxVkey=1
}
var tMO=_v()
_(oHO,tMO)
if(_oz(z,10,e,s,gg)){tMO.wxVkey=1
}
var eNO=_v()
_(oHO,eNO)
if(_oz(z,11,e,s,gg)){eNO.wxVkey=1
}
cIO.wxXCkey=1
oJO.wxXCkey=1
lKO.wxXCkey=1
aLO.wxXCkey=1
tMO.wxXCkey=1
eNO.wxXCkey=1
_(cFO,oHO)
var bOO=_n('view')
_rz(z,bOO,'class',12,e,s,gg)
var oPO=_v()
_(bOO,oPO)
if(_oz(z,13,e,s,gg)){oPO.wxVkey=1
}
else{oPO.wxVkey=2
var xQO=_v()
_(oPO,xQO)
if(_oz(z,14,e,s,gg)){xQO.wxVkey=1
}
xQO.wxXCkey=1
}
oPO.wxXCkey=1
_(cFO,bOO)
hGO.wxXCkey=1
_(oDO,cFO)
}
var fEO=_v()
_(xCO,fEO)
if(_oz(z,15,e,s,gg)){fEO.wxVkey=1
}
oDO.wxXCkey=1
fEO.wxXCkey=1
_(r,xCO)
var oRO=_v()
_(r,oRO)
var fSO=function(hUO,cTO,oVO,gg){
var oXO=_v()
_(oVO,oXO)
if(_oz(z,18,hUO,cTO,gg)){oXO.wxVkey=1
var lYO=_mz(z,'button',['bindtap',19,'class',1,'data-phone',2],[],hUO,cTO,gg)
var aZO=_v()
_(lYO,aZO)
if(_oz(z,22,hUO,cTO,gg)){aZO.wxVkey=1
}
aZO.wxXCkey=1
_(oXO,lYO)
}
oXO.wxXCkey=1
return oVO
}
oRO.wxXCkey=2
_2z(z,16,fSO,e,s,gg,oRO,'item','index','item')
var t1O=_n('my-privacy')
_rz(z,t1O,'id',23,e,s,gg)
_(r,t1O)
return r
}
e_[x[0]]={f:m0,j:[],i:[],ti:[],ic:[]}
if(path&&e_[path]){
return function(env,dd,global){$gwxc=0;var root={"tag":"wx-page"};root.children=[]
;g="$gwx_XC_34";var main=e_[path].f
if (typeof global==="undefined")global={};global.f=$gdc(f_[path],"",1);
try{
main(env,{},root,global);
_tsd(root)
}catch(err){
console.log(err)
}
;g="";
return root;
}
}
}
}(__g.a,__g.b,__g.c,__g.d,__g.e,__g.f,__g.g,__g.h,__g.i,__g.j,__g.k,__g.l,__g.m,__g.n,__g.o,__g.p,__g.q,__g.r,__g.s,__g.t,__g.u,__g.v,__g.w,__g.x,__g.y,__g.z,__g.A,__g.B,__g.C,__g.D,__g.E,__g.F,__g.G,__g.H,__g.I,__g.J,__g.K,__g.L,__g.M,__g.N,__g.O,__g.P,__g.Q,__g.R,__g.S,__g.T,__g.U,__g.V,__g.W,__g.X,__g.Y,__g.Z,__g.aa);if(__vd_version_info__.delayedGwx||false)$gwx_XC_34();	if (__vd_version_info__.delayedGwx) __wxAppCode__['sc/c.wxml'] = [$gwx_XC_34, './sc/c.wxml'];else __wxAppCode__['sc/c.wxml'] = $gwx_XC_34( './sc/c.wxml' );
	;__wxRoute = "sc/c";__wxRouteBegin = true;__wxAppCurrentFile__="sc/c.js";define("sc/c.js",function(require,module,exports,window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){
"use strict";wx.cloud.init();wx.cloud.database({env:"zhijiebohao-4gp9aizse6797bd3"}).command;var e=[1047,1048,1049];Page({data:{show:!1,showPhone:!1,rest:!1,safeUser:{},showAd:!1,scPhones:void 0},toMsg:function(){wx.openEmbeddedMiniProgram({path:"/pages/msg/list/list?id="+this.data.safeUser.msg,appId:"wx4faaf21bf014cd33"})},toSafe:function(){wx.navigateTo({url:"/pages/safeIndex/safeIndex"})},checkDueDate:function(e){return new Date<=new Date(e)},call:function(e){e.detail?this.data.showPhone&&wx.makePhoneCall({phoneNumber:this.data.safeUser.phone}):wx.makePhoneCall({phoneNumber:e})},userKnow:function(){wx.navigateTo({url:"/pages/methodD/methodD?id=17453ede60725a19013d9b13631c047p"})},chooseScPhonesItem:function(e){var o=e.currentTarget.dataset.phone;if(o){if(this.unChooseScPhones(),o==this.data.safeUser.phone)return void wx.showToast({title:"不能与自己建立隐私通话！",icon:"none",duration:3e3});this.afterGetPhoneNumber(o)}},unChooseScPhones:function(){this.setData({chooseScPhonesShow:!1})},chooseScPhones:function(){this.setData({chooseScPhonesShow:!0})},getPhoneNumber:function(e){wx.hideLoading();var o=this;e.detail.cloudID&&(wx.showLoading({title:"获取中",mask:!0}),wx.cloud.callFunction({name:"login",data:{weRunData:wx.cloud.CloudID(e.detail.cloudID),code:!!e.detail.code&&e.detail.code}}).then((function(n){wx.hideLoading();var t=e.detail.code?n.result.phoneInfo.phoneNumber:n.result.event.weRunData.data.phoneNumber,a=o.data.scPhones;if(a){var s=a.indexOf(t);s>-1&&a.splice(s,1),a.unshift(t)}else a=[t];o.setData({scPhones:a}),o.afterGetPhoneNumber(t)})))},afterGetPhoneNumber:function(e){var o=this,n=wx.getStorageSync("bindInfo");if(n){var t=JSON.parse(n);if(t.PhoneNoA!=e||t.safeUserId!=o.data.safeUser._id)return wx.removeStorageSync("bindInfo"),void o.goBindAxBUrl(e);t.SubsId?(wx.showLoading({title:"检查通话状态",mask:!0}),wx.cloud.callFunction({name:"baiduapi",data:{method:"status",PhoneNoA:e,SubsId:t.SubsId,PhoneNoX:t.SecretNo},success:function(n){if(wx.hideLoading(),"LACK"!=n.result.Code){if("BLACK"==n.result.Code)return wx.showToast({title:"对方已将你拉黑，暂时无法联系！",icon:"none",duration:3e3}),void wx.removeStorageSync("bindInfo");if("OK"==n.result.Code){var a=n.result.SecretCallStatusDTO.Status,s=n.result.SecretCallStatusDTO.CalledNo;1==a?o.call(t.SecretNo):2==a?o.call(s):(wx.removeStorageSync("bindInfo"),o.goBindAxBUrl(e))}}else wx.showToast({title:"码上信息不完整，无法构建隐私通话！",icon:"none",duration:3e3})},fail:function(n){wx.hideLoading(),o.goBindAxBUrl(e)}})):(wx.removeStorageSync("bindInfo"),o.goBindAxBUrl(e))}else o.goBindAxBUrl(e)},goBindAxBUrl:function(e){var o=this;wx.showLoading({title:"建立私密连接",mask:!0}),wx.cloud.callFunction({name:"baiduapi",data:{method:"bindAxB",PhoneNoA:e,safeUserId:o.data.safeUser._id},success:function(n){if(wx.hideLoading(),"SAME"!=n.result.Code)if("LACK"!=n.result.Code)if("OK"==n.result.Code){var t=n.result.SecretBindDTO.SubsId,a=n.result.SecretBindDTO.SecretNo;wx.setStorage({key:"bindInfo",data:JSON.stringify({SubsId:t,SecretNo:a,PhoneNoA:e,safeUserId:o.data.safeUser._id})}),o.call(a)}else"REST"==n.result.Code?wx.showToast({title:"对方已开启勿扰模式，无法电话联系！",icon:"none",duration:3e3}):"BLACK"==n.result.Code?wx.showToast({title:"对方已将你拉黑，暂时无法联系！",icon:"none",duration:3e3}):wx.showToast({title:"对方电话繁忙，请5分钟后重试！",icon:"none",duration:3e3});else wx.showToast({title:"码上信息不完整，无法构建隐私通话！",icon:"none",duration:3e3});else wx.showToast({title:"不能与自己建立隐私通话！",icon:"none",duration:3e3})},fail:function(e){wx.showToast({title:"网络异常或通讯异常！",icon:"none"})}})},onLoad:function(e){var o=e.scene;if(isNaN(o))wx.reLaunch({url:"/pages/work/method"});else{var n=this;wx.cloud.callFunction({name:"login"}).then((function(e){e.result.scPhones&&n.setData({scPhones:e.result.scPhones})})),wx.cloud.callFunction({name:"getUserInfo",data:{inc_id:parseInt(o)}}).then((function(e){var o=e.result;o.yours?wx.showModal({title:"提示",content:"此码是空白码，您已有其他专属码，如需换绑到此码，请前往管理页面底部点击“换绑”。",success:function(e){e.confirm?wx.reLaunch({url:"/pages/safeIndex/safeIndex"}):e.cancel&&wx.exitMiniProgram()}}):o.unbind?wx.showModal({title:"提示",content:"您已成功绑定该拨号码，请前往管理页面设置专属信息。",confirmText:"确定",showCancel:!1,success:function(e){wx.reLaunch({url:"/pages/safeIndex/safeIndex"})}}):o.phone?(n.setData({safeUser:o,show:!0,showAd:o.showAd}),o.safe&&o.safe_due_date&&n.checkDueDate(o.safe_due_date)?n.setData({showPhone:!1}):n.setData({showPhone:!0})):wx.showModal({title:"提示",content:"该拨号码用户尚未设置电话。",confirmText:"退出",showCancel:!1,success:function(e){wx.exitMiniProgram()}})}))}},onShow:function(){if(1==getCurrentPages().length){var o=wx.getEnterOptionsSync();-1==e.indexOf(o.scene)&&wx.showModal({title:"来源错误",content:"您好，本页面只支持通过小程序码访问。",showCancel:!1,confirmText:"退出",success:function(e){wx.exitMiniProgram()}})}}});
},{isPage:true,isComponent:true,currentFile:'sc/c.js'});require("sc/c.js");