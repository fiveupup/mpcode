$gwx_XC_0=function(_,_v,_n,_p,_s,_wp,_wl,$gwn,$gwl,$gwh,wh,$gstack,$gwrt,gra,grb,TestTest,wfor,_ca,_da,_r,_rz,_o,_oz,_1,_1z,_2,_2z,_m,_mz,nv_getDate,nv_getRegExp,nv_console,nv_parseInt,nv_parseFloat,nv_isNaN,nv_isFinite,nv_decodeURI,nv_decodeURIComponent,nv_encodeURI,nv_encodeURIComponent,$gdc,nv_JSON,_af,_gv,_ai,_grp,_gd,_gapi,$ixc,_ic,_w,_ev,_tsd){return function(path,global){
if(typeof global==='undefined'){if (typeof __GWX_GLOBAL__==='undefined')global={};else global=__GWX_GLOBAL__;}if(typeof __WXML_GLOBAL__ === 'undefined') {__WXML_GLOBAL__={};
}__WXML_GLOBAL__.modules = __WXML_GLOBAL__.modules || {};
var e_={}
if(typeof(global.entrys)==='undefined')global.entrys={};e_=global.entrys;
var d_={}
if(typeof(global.defines)==='undefined')global.defines={};d_=global.defines;
var f_={}
if(typeof(global.modules)==='undefined')global.modules={};f_=global.modules || {};
var p_={}
__WXML_GLOBAL__.ops_cached = __WXML_GLOBAL__.ops_cached || {}
__WXML_GLOBAL__.ops_set = __WXML_GLOBAL__.ops_set || {};
__WXML_GLOBAL__.ops_init = __WXML_GLOBAL__.ops_init || {};
var z=__WXML_GLOBAL__.ops_set.$gwx_XC_0 || [];
function gz$gwx_XC_0_1(){
if( __WXML_GLOBAL__.ops_cached.$gwx_XC_0_1)return __WXML_GLOBAL__.ops_cached.$gwx_XC_0_1
__WXML_GLOBAL__.ops_cached.$gwx_XC_0_1=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
Z([[7],[3,'show']])
Z([3,'page'])
Z(z[0])
Z([3,'weui-msg'])
Z([3,'padding-top:0;'])
Z([3,'weui-msg__text-area'])
Z([3,'weui-msg__title'])
Z([3,'true'])
Z([a,[[7],[3,'phoneNumber']]])
Z([3,'weui-msg__desc'])
Z([3,'save'])
Z([3,'保存联系人'])
Z([3,'weui-msg__opr-area'])
Z([3,'weui-btn-area'])
Z([[7],[3,'msg']])
Z([3,'toMsg'])
Z([3,'weui-btn weui-btn_default'])
Z([3,'display:flex;align-items:center;justify-content:center;border-radius:51rpx;'])
Z([3,'https://cos.wsqytec.com/static/msg.png'])
Z([3,'width:70rpx;height:70rpx;'])
Z([3,' 留言 '])
Z([3,'call'])
Z([3,'weui-btn weui-btn_primary'])
Z(z[17])
Z([[2,'!'],[[6],[[7],[3,'safeUser']],[3,'rest']]])
Z([3,'https://cos.wsqytec.com/static/call.png'])
Z(z[19])
Z([3,' 拨号 '])
Z([[7],[3,'dealActions']])
Z([3,'hideDeal'])
Z(z[29])
Z([3,'onSelect'])
Z([3,'取消'])
Z([[7],[3,'phoneNumber']])
Z([[7],[3,'showDeal']])
Z([[2,'!'],[[7],[3,'show']]])
Z([3,'display: flex;align-items: center;justify-content: center;width:100%;'])
Z([3,'box2'])
Z([3,'margin-top:25%;'])
Z([3,'myPrivacy'])
})(__WXML_GLOBAL__.ops_cached.$gwx_XC_0_1);return __WXML_GLOBAL__.ops_cached.$gwx_XC_0_1
}
__WXML_GLOBAL__.ops_set.$gwx_XC_0=z;
__WXML_GLOBAL__.ops_init.$gwx_XC_0=true;
var x=['./call.wxml'];d_[x[0]]={}
var m0=function(e,s,r,gg){
var z=gz$gwx_XC_0_1()
var oB=_v()
_(r,oB)
if(_oz(z,0,e,s,gg)){oB.wxVkey=1
var xC=_n('footer')
_(oB,xC)
}
var oD=_n('view')
_rz(z,oD,'class',1,e,s,gg)
var fE=_v()
_(oD,fE)
if(_oz(z,2,e,s,gg)){fE.wxVkey=1
var hG=_mz(z,'view',['class',3,'style',1],[],e,s,gg)
var oH=_n('view')
_rz(z,oH,'class',5,e,s,gg)
var cI=_n('h2')
_rz(z,cI,'class',6,e,s,gg)
var oJ=_n('text')
_rz(z,oJ,'userSelect',7,e,s,gg)
var lK=_oz(z,8,e,s,gg)
_(oJ,lK)
_(cI,oJ)
_(oH,cI)
var aL=_n('view')
_rz(z,aL,'class',9,e,s,gg)
var tM=_n('a')
_rz(z,tM,'bindtap',10,e,s,gg)
var eN=_oz(z,11,e,s,gg)
_(tM,eN)
_(aL,tM)
_(oH,aL)
_(hG,oH)
var bO=_n('view')
_rz(z,bO,'class',12,e,s,gg)
var oP=_n('view')
_rz(z,oP,'class',13,e,s,gg)
var xQ=_v()
_(oP,xQ)
if(_oz(z,14,e,s,gg)){xQ.wxVkey=1
var oR=_mz(z,'a',['bindtap',15,'class',1,'style',2],[],e,s,gg)
var fS=_mz(z,'image',['src',18,'style',1],[],e,s,gg)
_(oR,fS)
var cT=_oz(z,20,e,s,gg)
_(oR,cT)
_(xQ,oR)
}
var hU=_mz(z,'a',['bindtap',21,'class',1,'style',2],[],e,s,gg)
var oV=_v()
_(hU,oV)
if(_oz(z,24,e,s,gg)){oV.wxVkey=1
var cW=_mz(z,'image',['src',25,'style',1],[],e,s,gg)
_(oV,cW)
}
var oX=_oz(z,27,e,s,gg)
_(hU,oX)
oV.wxXCkey=1
_(oP,hU)
xQ.wxXCkey=1
_(bO,oP)
_(hG,bO)
_(fE,hG)
}
var lY=_mz(z,'van-action-sheet',['actions',28,'bind:cancel',1,'bind:close',2,'bind:select',3,'cancelText',4,'description',5,'show',6],[],e,s,gg)
_(oD,lY)
var cF=_v()
_(oD,cF)
if(_oz(z,35,e,s,gg)){cF.wxVkey=1
var aZ=_n('view')
_rz(z,aZ,'style',36,e,s,gg)
var t1=_mz(z,'view',['class',37,'style',1],[],e,s,gg)
_(aZ,t1)
_(cF,aZ)
}
fE.wxXCkey=1
cF.wxXCkey=1
_(r,oD)
var e2=_n('my-privacy')
_rz(z,e2,'id',39,e,s,gg)
_(r,e2)
oB.wxXCkey=1
oB.wxXCkey=3
return r
}
e_[x[0]]={f:m0,j:[],i:[],ti:[],ic:[]}
if(path&&e_[path]){
outerGlobal.__wxml_comp_version__=0.02
return function(env,dd,global){$gwxc=0;var root={"tag":"wx-page"};root.children=[]
;g="$gwx_XC_0";var main=e_[path].f
if (typeof global==="undefined")global={};global.f=$gdc(f_[path],"",1);
if(typeof(outerGlobal.__webview_engine_version__)!='undefined'&&outerGlobal.__webview_engine_version__+1e-6>=0.02+1e-6&&outerGlobal.__mergeData__)
{
env=outerGlobal.__mergeData__(env,dd);
}
try{
main(env,{},root,global);
_tsd(root)
if(typeof(outerGlobal.__webview_engine_version__)=='undefined'|| outerGlobal.__webview_engine_version__+1e-6<0.01+1e-6){return _ev(root);}
}catch(err){
console.log(err)
}
;g="";
return root;
}
}
}
}(__g.a,__g.b,__g.c,__g.d,__g.e,__g.f,__g.g,__g.h,__g.i,__g.j,__g.k,__g.l,__g.m,__g.n,__g.o,__g.p,__g.q,__g.r,__g.s,__g.t,__g.u,__g.v,__g.w,__g.x,__g.y,__g.z,__g.A,__g.B,__g.C,__g.D,__g.E,__g.F,__g.G,__g.H,__g.I,__g.J,__g.K,__g.L,__g.M,__g.N,__g.O,__g.P,__g.Q,__g.R,__g.S,__g.T,__g.U,__g.V,__g.W,__g.X,__g.Y,__g.Z,__g.aa);if(__vd_version_info__.delayedGwx||false)$gwx_XC_0();	if (__vd_version_info__.delayedGwx) __wxAppCode__['call.wxml'] = [$gwx_XC_0, './call.wxml'];else __wxAppCode__['call.wxml'] = $gwx_XC_0( './call.wxml' );
	
var noCss=typeof __vd_version_info__!=='undefined'&&__vd_version_info__.noCss===true;if(!noCss){__wxAppCode__['call.wxss'] = setCssToHead([".",[1],"weui-msg{-webkit-box-orient:vertical;-webkit-box-direction:normal;background-color:var(--weui-BG-2);box-sizing:border-box;display:-webkit-box;display:-webkit-flex;display:flex;-webkit-flex-direction:column;flex-direction:column;line-height:1.4;min-height:100%;padding:calc(",[0,96]," + env(safe-area-inset-top)) env(safe-area-inset-right) env(safe-area-inset-bottom) env(safe-area-inset-left);text-align:center}\n.",[1],"weui-msg wx-a:not(.",[1],"weui-btn){color:var(--weui-LINK);display:inline-block;vertical-align:baseline}\n.",[1],"weui-msg__icon-area{margin-bottom:",[0,64],"}\n.",[1],"weui-msg__text-area{-webkit-box-flex:1;-webkit-flex:1;flex:1;line-height:1.6;margin-bottom:",[0,64],";padding:0 ",[0,64],"}\n.",[1],"weui-msg__text-area:first-child{padding-top:",[0,172],"}\n.",[1],"weui-msg__title{font-size:",[0,56],";font-weight:700}\n.",[1],"weui-msg__desc,.",[1],"weui-msg__title{word-wrap:break-word;color:var(--weui-FG-0);margin-bottom:",[0,32],";word-break:break-all}\n.",[1],"weui-msg__desc{font-size:",[0,34],"}\n.",[1],"weui-msg__desc-primary{word-wrap:break-word;color:var(--weui-FG-1);font-size:",[0,28],";margin-bottom:",[0,32],";word-break:break-all}\n.",[1],"weui-msg__opr-area{margin-bottom:",[0,60],"}\n.",[1],"weui-msg__opr-area .",[1],"weui-btn-area{margin:0}\n.",[1],"weui-msg__opr-area .",[1],"weui-btn+.",[1],"weui-btn{margin-bottom:",[0,32],"}\n.",[1],"weui-msg__opr-area:last-child{margin-bottom:",[0,192],"}\n.",[1],"weui-msg__opr-area+.",[1],"weui-msg__extra-area{margin-top:",[0,96],"}\n.",[1],"weui-msg__tips-area{margin-bottom:",[0,32],";padding:0 ",[0,80],"}\n.",[1],"weui-msg__opr-area+.",[1],"weui-msg__tips-area{margin-bottom:",[0,96],"}\n.",[1],"weui-msg__tips-area:last-child{margin-bottom:",[0,128],"}\n.",[1],"weui-msg__extra-area,.",[1],"weui-msg__tips{color:var(--weui-FG-1);font-size:",[0,24],"}\n.",[1],"weui-msg__extra-area{margin-bottom:",[0,48],"}\n.",[1],"weui-msg__extra-area wx-a,.",[1],"weui-msg__extra-area wx-navigator{color:var(--weui-LINK)}\n.",[1],"weui-msg__extra-area wx-navigator{display:inline}\n.",[1],"weui-msg__extra-area{position:static}\n.",[1],"page{background-color:var(--weui-BG-2);height:100%}\n.",[1],"box2{-webkit-animation:spin 1s linear infinite;animation:spin 1s linear infinite;border:2px solid #ccc;border-radius:50%;border-top-color:#07c160;height:1.4em;width:1.4em}\n@-webkit-keyframes spin{to{-webkit-transform:rotate(1turn);transform:rotate(1turn)}\n}@keyframes spin{to{-webkit-transform:rotate(1turn);transform:rotate(1turn)}\n}",],"Some selectors are not allowed in component wxss, including tag name selectors, ID selectors, and attribute selectors.(./call.wxss:1:1680)",{path:"./call.wxss"});
}