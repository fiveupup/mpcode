$gwx_XC_0=function(_,_v,_n,_p,_s,_wp,_wl,$gwn,$gwl,$gwh,wh,$gstack,$gwrt,gra,grb,TestTest,wfor,_ca,_da,_r,_rz,_o,_oz,_1,_1z,_2,_2z,_m,_mz,nv_getDate,nv_getRegExp,nv_console,nv_parseInt,nv_parseFloat,nv_isNaN,nv_isFinite,nv_decodeURI,nv_decodeURIComponent,nv_encodeURI,nv_encodeURIComponent,$gdc,nv_JSON,_af,_gv,_ai,_grp,_gd,_gapi,$ixc,_ic,_w,_ev,_tsd){return function(path,global){
if(typeof global==='undefined'){if (typeof __GWX_GLOBAL__==='undefined')global={};else global=__GWX_GLOBAL__;}if(typeof __WXML_GLOBAL__ === 'undefined') {__WXML_GLOBAL__={};
}__WXML_GLOBAL__.modules = __WXML_GLOBAL__.modules || {};
var e_={}
if(typeof(global.entrys)==='undefined')global.entrys={};e_=global.entrys;
var d_={}
if(typeof(global.defines)==='undefined')global.defines={};d_=global.defines;
var f_={}
if(typeof(global.modules)==='undefined')global.modules={};f_=global.modules || {};
var p_={}
__WXML_GLOBAL__.ops_cached = __WXML_GLOBAL__.ops_cached || {}
__WXML_GLOBAL__.ops_set = __WXML_GLOBAL__.ops_set || {};
__WXML_GLOBAL__.ops_init = __WXML_GLOBAL__.ops_init || {};
var z=__WXML_GLOBAL__.ops_set.$gwx_XC_0 || [];
function gz$gwx_XC_0_1(){
if( __WXML_GLOBAL__.ops_cached.$gwx_XC_0_1)return __WXML_GLOBAL__.ops_cached.$gwx_XC_0_1
__WXML_GLOBAL__.ops_cached.$gwx_XC_0_1=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
Z([[7],[3,'show']])
Z([3,'page'])
Z(z[0])
Z([3,'weui-btn-area'])
Z([[7],[3,'msg']])
Z([3,'call'])
Z([3,'weui-btn weui-btn_primary'])
Z([3,'display:flex;align-items:center;justify-content:center;border-radius:51rpx;'])
Z([[2,'!'],[[6],[[7],[3,'safeUser']],[3,'rest']]])
Z([[7],[3,'dealActions']])
Z([3,'hideDeal'])
Z(z[10])
Z([3,'onSelect'])
Z([3,'取消'])
Z([[7],[3,'phoneNumber']])
Z([[7],[3,'showDeal']])
Z([[2,'!'],[[7],[3,'show']]])
Z([3,'myPrivacy'])
})(__WXML_GLOBAL__.ops_cached.$gwx_XC_0_1);return __WXML_GLOBAL__.ops_cached.$gwx_XC_0_1
}
__WXML_GLOBAL__.ops_set.$gwx_XC_0=z;
__WXML_GLOBAL__.ops_init.$gwx_XC_0=true;
var x=['./call.wxml'];d_[x[0]]={}
var m0=function(e,s,r,gg){
var z=gz$gwx_XC_0_1()
var oB=_v()
_(r,oB)
if(_oz(z,0,e,s,gg)){oB.wxVkey=1
var xC=_n('footer')
_(oB,xC)
}
var oD=_n('view')
_rz(z,oD,'class',1,e,s,gg)
var fE=_v()
_(oD,fE)
if(_oz(z,2,e,s,gg)){fE.wxVkey=1
var hG=_n('view')
_rz(z,hG,'class',3,e,s,gg)
var oH=_v()
_(hG,oH)
if(_oz(z,4,e,s,gg)){oH.wxVkey=1
}
var cI=_mz(z,'a',['bindtap',5,'class',1,'style',2],[],e,s,gg)
var oJ=_v()
_(cI,oJ)
if(_oz(z,8,e,s,gg)){oJ.wxVkey=1
}
oJ.wxXCkey=1
_(hG,cI)
oH.wxXCkey=1
_(fE,hG)
}
var lK=_mz(z,'van-action-sheet',['actions',9,'bind:cancel',1,'bind:close',2,'bind:select',3,'cancelText',4,'description',5,'show',6],[],e,s,gg)
_(oD,lK)
var cF=_v()
_(oD,cF)
if(_oz(z,16,e,s,gg)){cF.wxVkey=1
}
fE.wxXCkey=1
cF.wxXCkey=1
_(r,oD)
var aL=_n('my-privacy')
_rz(z,aL,'id',17,e,s,gg)
_(r,aL)
oB.wxXCkey=1
oB.wxXCkey=3
return r
}
e_[x[0]]={f:m0,j:[],i:[],ti:[],ic:[]}
if(path&&e_[path]){
return function(env,dd,global){$gwxc=0;var root={"tag":"wx-page"};root.children=[]
;g="$gwx_XC_0";var main=e_[path].f
if (typeof global==="undefined")global={};global.f=$gdc(f_[path],"",1);
try{
main(env,{},root,global);
_tsd(root)
}catch(err){
console.log(err)
}
;g="";
return root;
}
}
}
}(__g.a,__g.b,__g.c,__g.d,__g.e,__g.f,__g.g,__g.h,__g.i,__g.j,__g.k,__g.l,__g.m,__g.n,__g.o,__g.p,__g.q,__g.r,__g.s,__g.t,__g.u,__g.v,__g.w,__g.x,__g.y,__g.z,__g.A,__g.B,__g.C,__g.D,__g.E,__g.F,__g.G,__g.H,__g.I,__g.J,__g.K,__g.L,__g.M,__g.N,__g.O,__g.P,__g.Q,__g.R,__g.S,__g.T,__g.U,__g.V,__g.W,__g.X,__g.Y,__g.Z,__g.aa);if(__vd_version_info__.delayedGwx||false)$gwx_XC_0();	if (__vd_version_info__.delayedGwx) __wxAppCode__['call.wxml'] = [$gwx_XC_0, './call.wxml'];else __wxAppCode__['call.wxml'] = $gwx_XC_0( './call.wxml' );
	;__wxRoute = "call";__wxRouteBegin = true;__wxAppCurrentFile__="call.js";define("call.js",function(require,module,exports,window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){
"use strict";wx.cloud.init();var e=wx.cloud.database({env:"zhijiebohao-4gp9aizse6797bd3"}),t=e.command,a=getApp();Page({data:{phoneNumber:"",show:!1,name:"",msg:"",showAd:!1,showDeal:!1,dealActions:[{name:"呼叫",index:0}]},toMsg:function(){wx.openEmbeddedMiniProgram({path:"/pages/msg/list/list?id="+this.data.msg,appId:"wx4faaf21bf014cd33"})},call:function(){this.data.name||wx.setNavigationBarTitle({title:"直接拨号"}),"android"===wx.getSystemInfoSync().platform?this.setData({showDeal:!0}):wx.makePhoneCall({phoneNumber:this.data.phoneNumber})},onSelect:function(e){switch(e.detail.index){case 0:wx.makePhoneCall({phoneNumber:this.data.phoneNumber})}},hideDeal:function(){this.setData({showDeal:!1})},save:function(){var e=this,t=this.data.name;wx.addPhoneContact({firstName:t||this.data.phoneNumber,mobilePhoneNumber:this.data.phoneNumber,success:function(e){},fail:function(t){(t.errMsg.indexOf("deny")>-1||t.errMsg.indexOf("denied")>-1||t.errMsg.indexOf("auth")>-1)&&e.showModal()}})},onOpenSetting:function(){var e=this;wx.openSetting({success:function(t){t.authSetting["scope.addPhoneContact"]?e.save():wx.showToast({title:"您未授权",icon:"none"})}})},showModal:function(){var e=this;wx.showModal({title:"检测到您没有打开添加到通讯录的权限，是否前往设置打开？",success:function(t){t.confirm?e.onOpenSetting():t.cancel}})},home:function(){wx.getSystemInfo({success:function(e){"windows"==e.platform||"mac"==e.platform?setTimeout((function(){wx.switchTab({url:"pages/work/method"})}),500):wx.switchTab({url:"pages/work/method"})}})},onLoad:function(n){var i=decodeURIComponent(n.q);if(i&&i.indexOf("?")>-1){var o=i.split("?")[1];(r=this.getQueryVariable(o,"tel"))&&(n.tel=r),(c=this.getQueryVariable(o,"name"))&&(n.name=c),(h=this.getQueryVariable(o,"msg"))&&(n.msg=h)}var s=decodeURIComponent(n.scene),l=this;if(s&&"undefined"!=s&&null!=s){var d=l.getQueryVariable(s,"cloudId");if(d)try{e.collection("cloud_id_phone").where({cloudId:t.eq(parseInt(d))}).field({cloudId:!0,tel:!0,name:!0}).get({success:function(e){e.data.length>0?(e.data[0].name&&(l.setData({name:e.data[0].name}),wx.setNavigationBarTitle({title:e.data[0].name})),l.tel(e.data[0].tel)):wx.showModal({title:"未查到对应的电话号码!",content:"去首页联系官方客服绑定\r\ncloudId="+d,showCancel:!1,success:function(e){l.home()}})}})}catch(e){l.tel()}else(c=l.getQueryVariable(s,"n"))&&(l.setData({name:c}),wx.setNavigationBarTitle({title:c})),(r=l.getQueryVariable(s,"t"))?l.tel(r,c):l.tel(s)}else{var r=decodeURIComponent(n.tel?n.tel:n.tell),c=decodeURIComponent(n.name),h=decodeURIComponent(n.msg);if(c&&"undefined"!=c&&null!=c&&(l.setData({name:c}),wx.setNavigationBarTitle({title:c})),h&&"undefined"!=h&&null!=h&&l.setData({msg:h}),!r||"undefined"==r||null==r){var u=wx.getEnterOptionsSync(),m="call"==u.path||"call.html"==u.path,f=1035==u.scene||1058==u.scene;return void(m&&f?a.errorNotice():l.home())}r=r.replace(/[^0-9]/gi,""),l.tel(r,c)}},getQueryVariable:function(e,t){for(var a=e.split("&"),n=0;n<a.length;n++){var i=a[n].split("=");if(i[0].trim()==t.trim())return i[1].trim()}return!1},tel:function(e,t){if(e&&"undefined"!=e&&null!=e){var n=e.replace(" ","").replace("-","");if(n.length>12||n.length<3)return void a.errorNotice();this.setData({phoneNumber:n,show:!0}),this.call(),wx.cloud.callFunction({name:"simpleHistory",data:{type:2,name:n,path:"/call?tel="+n+(this.data.name?"&name="+this.data.name:"")+(this.data.msg?"&msg="+this.data.msg:"")}}).then((function(e){}))}else this.home()},onReady:function(){wx.showShareMenu({menus:["shareAppMessage"]})}});
},{isPage:true,isComponent:true,currentFile:'call.js'});require("call.js");