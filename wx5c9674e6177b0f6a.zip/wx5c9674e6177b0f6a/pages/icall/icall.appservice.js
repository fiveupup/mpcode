$gwx_XC_27=function(_,_v,_n,_p,_s,_wp,_wl,$gwn,$gwl,$gwh,wh,$gstack,$gwrt,gra,grb,TestTest,wfor,_ca,_da,_r,_rz,_o,_oz,_1,_1z,_2,_2z,_m,_mz,nv_getDate,nv_getRegExp,nv_console,nv_parseInt,nv_parseFloat,nv_isNaN,nv_isFinite,nv_decodeURI,nv_decodeURIComponent,nv_encodeURI,nv_encodeURIComponent,$gdc,nv_JSON,_af,_gv,_ai,_grp,_gd,_gapi,$ixc,_ic,_w,_ev,_tsd){return function(path,global){
if(typeof global==='undefined'){if (typeof __GWX_GLOBAL__==='undefined')global={};else global=__GWX_GLOBAL__;}if(typeof __WXML_GLOBAL__ === 'undefined') {__WXML_GLOBAL__={};
}__WXML_GLOBAL__.modules = __WXML_GLOBAL__.modules || {};
var e_={}
if(typeof(global.entrys)==='undefined')global.entrys={};e_=global.entrys;
var d_={}
if(typeof(global.defines)==='undefined')global.defines={};d_=global.defines;
var f_={}
if(typeof(global.modules)==='undefined')global.modules={};f_=global.modules || {};
var p_={}
__WXML_GLOBAL__.ops_cached = __WXML_GLOBAL__.ops_cached || {}
__WXML_GLOBAL__.ops_set = __WXML_GLOBAL__.ops_set || {};
__WXML_GLOBAL__.ops_init = __WXML_GLOBAL__.ops_init || {};
var z=__WXML_GLOBAL__.ops_set.$gwx_XC_27 || [];
function gz$gwx_XC_27_1(){
if( __WXML_GLOBAL__.ops_cached.$gwx_XC_27_1)return __WXML_GLOBAL__.ops_cached.$gwx_XC_27_1
__WXML_GLOBAL__.ops_cached.$gwx_XC_27_1=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
Z([[7],[3,'showRes']])
Z([3,''])
Z([[7],[3,'showSet']])
Z([[7],[3,'active']])
Z([3,'#07c160'])
Z([3,'success'])
Z([3,'clickStep'])
Z([3,'vertical'])
Z([3,'rgb(84, 115, 135)'])
Z([[7],[3,'steps']])
Z([[2,'&&'],[[2,'!'],[[7],[3,'miniPath']]],[[2,'!'],[[7],[3,'httpPath']]]])
Z([[7],[3,'editAddressShow']])
Z([3,'margin-left: -16px;margin-right: -16rpx;'])
Z([3,'nameChange'])
Z([1,false])
Z([3,'80'])
Z([3,'名字：'])
Z([3,'请输入名字'])
Z([3,'4em'])
Z([[6],[[7],[3,'location']],[3,'name']])
Z([[7],[3,'addressFocus']])
Z([3,'addressChange'])
Z(z[14])
Z(z[15])
Z([3,'地址：'])
Z([3,'请输入地址'])
Z(z[18])
Z([3,'textarea'])
Z([[6],[[7],[3,'location']],[3,'address']])
Z([3,'longitudeChange'])
Z(z[14])
Z(z[15])
Z([3,'经度：'])
Z([3,'请输入经度'])
Z(z[18])
Z([3,'number'])
Z([[6],[[7],[3,'location']],[3,'longitude']])
Z([3,'latitudeChange'])
Z(z[14])
Z(z[15])
Z([3,'纬度：'])
Z([3,'请输入纬度'])
Z(z[18])
Z(z[35])
Z([[6],[[7],[3,'location']],[3,'latitude']])
Z(z[11])
Z(z[0])
Z([3,'myPrivacy'])
})(__WXML_GLOBAL__.ops_cached.$gwx_XC_27_1);return __WXML_GLOBAL__.ops_cached.$gwx_XC_27_1
}
__WXML_GLOBAL__.ops_set.$gwx_XC_27=z;
__WXML_GLOBAL__.ops_init.$gwx_XC_27=true;
var x=['./pages/icall/icall.wxml'];d_[x[0]]={}
var m0=function(e,s,r,gg){
var z=gz$gwx_XC_27_1()
var xQH=_v()
_(r,xQH)
if(_oz(z,0,e,s,gg)){xQH.wxVkey=1
var oRH=_n('footer')
_(xQH,oRH)
}
var fSH=_n('view')
_rz(z,fSH,'class',1,e,s,gg)
var cTH=_v()
_(fSH,cTH)
if(_oz(z,2,e,s,gg)){cTH.wxVkey=1
var oVH=_n('view')
var cWH=_mz(z,'van-steps',['active',3,'activeColor',1,'activeIcon',2,'bind:click-step',3,'direction',4,'inactiveColor',5,'steps',6],[],e,s,gg)
_(oVH,cWH)
var oXH=_n('view')
var lYH=_v()
_(oXH,lYH)
if(_oz(z,10,e,s,gg)){lYH.wxVkey=1
}
else{lYH.wxVkey=2
var aZH=_n('view')
var t1H=_v()
_(aZH,t1H)
if(_oz(z,11,e,s,gg)){t1H.wxVkey=1
var b3H=_n('view')
_rz(z,b3H,'style',12,e,s,gg)
var o4H=_mz(z,'van-field',['clearable',-1,'bind:change',13,'border',1,'cursorSpacing',2,'label',3,'placeholder',4,'titleWidth',5,'value',6],[],e,s,gg)
_(b3H,o4H)
var x5H=_mz(z,'van-field',['clearable',-1,'autosize',20,'bind:change',1,'border',2,'cursorSpacing',3,'label',4,'placeholder',5,'titleWidth',6,'type',7,'value',8],[],e,s,gg)
_(b3H,x5H)
var o6H=_mz(z,'van-field',['clearable',-1,'bind:change',29,'border',1,'cursorSpacing',2,'label',3,'placeholder',4,'titleWidth',5,'type',6,'value',7],[],e,s,gg)
_(b3H,o6H)
var f7H=_mz(z,'van-field',['clearable',-1,'bind:change',37,'border',1,'cursorSpacing',2,'label',3,'placeholder',4,'titleWidth',5,'type',6,'value',7],[],e,s,gg)
_(b3H,f7H)
_(t1H,b3H)
}
var e2H=_v()
_(aZH,e2H)
if(_oz(z,45,e,s,gg)){e2H.wxVkey=1
}
t1H.wxXCkey=1
t1H.wxXCkey=3
e2H.wxXCkey=1
_(lYH,aZH)
}
lYH.wxXCkey=1
lYH.wxXCkey=3
_(oVH,oXH)
_(cTH,oVH)
}
var hUH=_v()
_(fSH,hUH)
if(_oz(z,46,e,s,gg)){hUH.wxVkey=1
}
cTH.wxXCkey=1
cTH.wxXCkey=3
hUH.wxXCkey=1
_(r,fSH)
var c8H=_n('my-privacy')
_rz(z,c8H,'id',47,e,s,gg)
_(r,c8H)
xQH.wxXCkey=1
xQH.wxXCkey=3
return r
}
e_[x[0]]={f:m0,j:[],i:[],ti:[],ic:[]}
if(path&&e_[path]){
return function(env,dd,global){$gwxc=0;var root={"tag":"wx-page"};root.children=[]
;g="$gwx_XC_27";var main=e_[path].f
if (typeof global==="undefined")global={};global.f=$gdc(f_[path],"",1);
try{
main(env,{},root,global);
_tsd(root)
}catch(err){
console.log(err)
}
;g="";
return root;
}
}
}
}(__g.a,__g.b,__g.c,__g.d,__g.e,__g.f,__g.g,__g.h,__g.i,__g.j,__g.k,__g.l,__g.m,__g.n,__g.o,__g.p,__g.q,__g.r,__g.s,__g.t,__g.u,__g.v,__g.w,__g.x,__g.y,__g.z,__g.A,__g.B,__g.C,__g.D,__g.E,__g.F,__g.G,__g.H,__g.I,__g.J,__g.K,__g.L,__g.M,__g.N,__g.O,__g.P,__g.Q,__g.R,__g.S,__g.T,__g.U,__g.V,__g.W,__g.X,__g.Y,__g.Z,__g.aa);if(__vd_version_info__.delayedGwx||false)$gwx_XC_27();	if (__vd_version_info__.delayedGwx) __wxAppCode__['pages/icall/icall.wxml'] = [$gwx_XC_27, './pages/icall/icall.wxml'];else __wxAppCode__['pages/icall/icall.wxml'] = $gwx_XC_27( './pages/icall/icall.wxml' );
	;__wxRoute = "pages/icall/icall";__wxRouteBegin = true;__wxAppCurrentFile__="pages/icall/icall.js";define("pages/icall/icall.js",function(require,module,exports,window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){
"use strict";wx.cloud.init(),Page({data:{editAddressShow:!1,title:"小正方助手",showSet:!1,showRes:!1,location:null,active:-1,steps:[{text:"第1步",desc:"点击此处选择门店位置"},{text:"第2步",desc:"点击下方结果复制路径"}],miniUrl:"pages/icall/icall?latitude={latitude}&longitude={longitude}&name={name}&address={address}",httpUrl:"https://bohao.wsqytec.com/map.html?latitude={latitude}&longitude={longitude}&name={name}&address={address}",miniPath:"",httpPath:"",systemInfo:wx.getSystemInfoSync()},editAddress:function(){this.setData({editAddressShow:!0})},cancelEditAddress:function(){this.setData({editAddressShow:!1})},addressChange:function(t){var e=this.data.location;e.address=t.detail,this.buildUrl(e)},nameChange:function(t){var e=this.data.location;e.name=t.detail,this.buildUrl(e)},longitudeChange:function(t){var e=this.data.location;e.longitude=Number(t.detail),this.buildUrl(e)},latitudeChange:function(t){var e=this.data.location;e.latitude=Number(t.detail),this.buildUrl(e)},buildUrl:function(t){var e=this.data.miniUrl;e=e.replace("{latitude}",t.latitude).replace("{longitude}",t.longitude).replace("{name}",encodeURIComponent(t.name)).replace("{address}",encodeURIComponent(t.address));var a=this.data.httpUrl;a=a.replace("{latitude}",t.latitude).replace("{longitude}",t.longitude).replace("{name}",encodeURIComponent(t.name)).replace("{address}",encodeURIComponent(t.address)),this.setData({miniPath:e,httpPath:a,active:0,location:t})},clickStep:function(t){var e=this;switch(t.detail){case 0:wx.chooseLocation({success:function(t){e.buildUrl(t)},fail:function(t){t.errMsg.indexOf("deny")>-1&&wx.showModal({title:"检测到您没有打开位置权限，是否前往设置打开？",success:function(t){t.confirm&&wx.openSetting()}})}})}},toView:function(t){if("windows"!=this.data.systemInfo.platform&&"mac"!=this.data.systemInfo.platform)if(t&&t.latitude)wx.openLocation(t);else{if(!this.data.location&&this.data.location.latitude)return void wx.showToast({title:"请先选择地点获取路径",icon:"none"});wx.openLocation(this.data.location)}else wx.showToast({title:"该功能暂不支持电脑操作，请使用手机点击",icon:"none",duration:3e3})},exit:function(){wx.exitMiniProgram&&wx.exitMiniProgram()},toCopyMiniPath:function(){var t=this;t.data.miniPath?wx.setClipboardData({data:t.data.miniPath,success:function(){t.setData({active:1}),wx.hideLoading(),wx.showToast({title:"小正方助手路径复制成功",icon:"none",duration:3e3})}}):wx.showToast({title:"请先选择地点获取路径",icon:"none",duration:3e3})},toCopyHttpPath:function(){var t=this;t.data.httpPath?wx.setClipboardData({data:t.data.httpPath,success:function(){t.setData({active:1}),wx.hideLoading(),wx.showToast({title:"网址路径复制成功",icon:"none"})}}):wx.showToast({title:"请先选择地点获取路径",icon:"none"})},onLoad:function(t){if(t.latitude&&t.longitude){var e={latitude:Number(t.latitude),longitude:Number(t.longitude),name:t.name?decodeURIComponent(t.name):"",address:t.address?decodeURIComponent(t.address):""};this.toView(e),this.setData({showSet:!1,showRes:!0,location:e,title:"一键导航"});var a=this.data.miniUrl;a=a.replace("{latitude}",e.latitude).replace("{longitude}",e.longitude).replace("{name}",encodeURIComponent(e.name)).replace("{address}",encodeURIComponent(e.address)),wx.cloud.callFunction({name:"simpleHistory",data:{type:3,name:e.name,path:"/"+a}}).then((function(t){console.log(t)}))}else this.setData({showSet:!0,showRes:!1});var i=wx.getSystemInfoSync();if(this.setData({systemInfo:i}),wx.setNavigationBarTitle({title:this.data.title}),this.data.showSet){var n=this;this.watch(this,{editAddressShow:function(t){var e=n.data.location.address,a=n.data.location;a.address="",n.setData({location:a}),a.address=e;var i=setTimeout((function(){n.setData({addressFocus:t,location:a}),clearTimeout(i)}),300)}})}},watch:function(t,e){var a=this;Object.keys(e).forEach((function(i){a.observer(t.data,i,t.data[i],(function(a){e[i].call(t,a)}))}))},observer:function(t,e,a,i){Object.defineProperty(t,e,{configurable:!0,enumerable:!0,get:function(){return a},set:function(t){i&&i(t),a=t}})},onShow:function(){}});
},{isPage:true,isComponent:true,currentFile:'pages/icall/icall.js'});require("pages/icall/icall.js");