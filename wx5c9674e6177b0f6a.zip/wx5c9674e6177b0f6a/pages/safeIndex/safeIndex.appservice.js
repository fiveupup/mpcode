$gwx_XC_30=function(_,_v,_n,_p,_s,_wp,_wl,$gwn,$gwl,$gwh,wh,$gstack,$gwrt,gra,grb,TestTest,wfor,_ca,_da,_r,_rz,_o,_oz,_1,_1z,_2,_2z,_m,_mz,nv_getDate,nv_getRegExp,nv_console,nv_parseInt,nv_parseFloat,nv_isNaN,nv_isFinite,nv_decodeURI,nv_decodeURIComponent,nv_encodeURI,nv_encodeURIComponent,$gdc,nv_JSON,_af,_gv,_ai,_grp,_gd,_gapi,$ixc,_ic,_w,_ev,_tsd){return function(path,global){
if(typeof global==='undefined'){if (typeof __GWX_GLOBAL__==='undefined')global={};else global=__GWX_GLOBAL__;}if(typeof __WXML_GLOBAL__ === 'undefined') {__WXML_GLOBAL__={};
}__WXML_GLOBAL__.modules = __WXML_GLOBAL__.modules || {};
var e_={}
if(typeof(global.entrys)==='undefined')global.entrys={};e_=global.entrys;
var d_={}
if(typeof(global.defines)==='undefined')global.defines={};d_=global.defines;
var f_={}
if(typeof(global.modules)==='undefined')global.modules={};f_=global.modules || {};
var p_={}
__WXML_GLOBAL__.ops_cached = __WXML_GLOBAL__.ops_cached || {}
__WXML_GLOBAL__.ops_set = __WXML_GLOBAL__.ops_set || {};
__WXML_GLOBAL__.ops_init = __WXML_GLOBAL__.ops_init || {};
var z=__WXML_GLOBAL__.ops_set.$gwx_XC_30 || [];
function gz$gwx_XC_30_1(){
if( __WXML_GLOBAL__.ops_cached.$gwx_XC_30_1)return __WXML_GLOBAL__.ops_cached.$gwx_XC_30_1
__WXML_GLOBAL__.ops_cached.$gwx_XC_30_1=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
Z([[7],[3,'show']])
Z([3,'margin-top:32rpx;position:relative;'])
Z([[7],[3,'src']])
Z([3,'weui-cells'])
Z([[7],[3,'safe']])
Z(z[4])
Z(z[4])
Z(z[4])
Z([[7],[3,'msg']])
Z([3,'msgDone'])
Z([3,'always'])
Z([1,true])
Z([3,'去小互动卡创建并选择（可不填）'])
Z([3,'color:#ccc;font-size:24rpx;'])
Z(z[8])
Z(z[2])
Z([3,'display:flex;justify-content:center;align-items:center;width: 100%;margin:60rpx 0;'])
Z([3,'previewCall'])
Z([3,'#07c160'])
Z([3,'van-button-custom-class'])
Z([3,'savedownloadFile'])
Z(z[18])
Z(z[19])
Z([3,'text-align:center;font-size:32rpx;'])
Z(z[4])
Z(z[2])
Z([[2,'!'],[[7],[3,'show']]])
Z([3,'myPrivacy'])
})(__WXML_GLOBAL__.ops_cached.$gwx_XC_30_1);return __WXML_GLOBAL__.ops_cached.$gwx_XC_30_1
}
__WXML_GLOBAL__.ops_set.$gwx_XC_30=z;
__WXML_GLOBAL__.ops_init.$gwx_XC_30=true;
var x=['./pages/safeIndex/safeIndex.wxml'];d_[x[0]]={}
var m0=function(e,s,r,gg){
var z=gz$gwx_XC_30_1()
var lGL=_v()
_(r,lGL)
if(_oz(z,0,e,s,gg)){lGL.wxVkey=1
var tIL=_n('view')
_rz(z,tIL,'style',1,e,s,gg)
var eJL=_v()
_(tIL,eJL)
if(_oz(z,2,e,s,gg)){eJL.wxVkey=1
}
var oLL=_n('view')
_rz(z,oLL,'class',3,e,s,gg)
var xML=_v()
_(oLL,xML)
if(_oz(z,4,e,s,gg)){xML.wxVkey=1
}
var oNL=_v()
_(oLL,oNL)
if(_oz(z,5,e,s,gg)){oNL.wxVkey=1
}
var fOL=_v()
_(oLL,fOL)
if(_oz(z,6,e,s,gg)){fOL.wxVkey=1
}
var cPL=_v()
_(oLL,cPL)
if(_oz(z,7,e,s,gg)){cPL.wxVkey=1
}
var hQL=_v()
_(oLL,hQL)
if(_oz(z,8,e,s,gg)){hQL.wxVkey=1
var oRL=_mz(z,'van-search',['useActionSlot',-1,'useLeftIconSlot',-1,'bind:clear',9,'clearTrigger',1,'disabled',2,'placeholder',3,'placeholderStyle',4,'value',5],[],e,s,gg)
_(hQL,oRL)
}
xML.wxXCkey=1
oNL.wxXCkey=1
fOL.wxXCkey=1
cPL.wxXCkey=1
hQL.wxXCkey=1
hQL.wxXCkey=3
_(tIL,oLL)
var bKL=_v()
_(tIL,bKL)
if(_oz(z,15,e,s,gg)){bKL.wxVkey=1
var cSL=_n('view')
_rz(z,cSL,'style',16,e,s,gg)
var oTL=_mz(z,'van-button',['plain',-1,'round',-1,'bind:click',17,'color',1,'customClass',2],[],e,s,gg)
_(cSL,oTL)
var lUL=_mz(z,'van-button',['round',-1,'bind:click',20,'color',1,'customClass',2],[],e,s,gg)
_(cSL,lUL)
_(bKL,cSL)
}
else{bKL.wxVkey=2
}
var aVL=_n('view')
_rz(z,aVL,'style',23,e,s,gg)
var tWL=_v()
_(aVL,tWL)
if(_oz(z,24,e,s,gg)){tWL.wxVkey=1
}
var eXL=_v()
_(aVL,eXL)
if(_oz(z,25,e,s,gg)){eXL.wxVkey=1
}
tWL.wxXCkey=1
eXL.wxXCkey=1
_(tIL,aVL)
eJL.wxXCkey=1
bKL.wxXCkey=1
bKL.wxXCkey=3
_(lGL,tIL)
}
var aHL=_v()
_(r,aHL)
if(_oz(z,26,e,s,gg)){aHL.wxVkey=1
}
var bYL=_n('my-privacy')
_rz(z,bYL,'id',27,e,s,gg)
_(r,bYL)
lGL.wxXCkey=1
lGL.wxXCkey=3
aHL.wxXCkey=1
return r
}
e_[x[0]]={f:m0,j:[],i:[],ti:[],ic:[]}
if(path&&e_[path]){
return function(env,dd,global){$gwxc=0;var root={"tag":"wx-page"};root.children=[]
;g="$gwx_XC_30";var main=e_[path].f
if (typeof global==="undefined")global={};global.f=$gdc(f_[path],"",1);
try{
main(env,{},root,global);
_tsd(root)
}catch(err){
console.log(err)
}
;g="";
return root;
}
}
}
}(__g.a,__g.b,__g.c,__g.d,__g.e,__g.f,__g.g,__g.h,__g.i,__g.j,__g.k,__g.l,__g.m,__g.n,__g.o,__g.p,__g.q,__g.r,__g.s,__g.t,__g.u,__g.v,__g.w,__g.x,__g.y,__g.z,__g.A,__g.B,__g.C,__g.D,__g.E,__g.F,__g.G,__g.H,__g.I,__g.J,__g.K,__g.L,__g.M,__g.N,__g.O,__g.P,__g.Q,__g.R,__g.S,__g.T,__g.U,__g.V,__g.W,__g.X,__g.Y,__g.Z,__g.aa);if(__vd_version_info__.delayedGwx||false)$gwx_XC_30();	if (__vd_version_info__.delayedGwx) __wxAppCode__['pages/safeIndex/safeIndex.wxml'] = [$gwx_XC_30, './pages/safeIndex/safeIndex.wxml'];else __wxAppCode__['pages/safeIndex/safeIndex.wxml'] = $gwx_XC_30( './pages/safeIndex/safeIndex.wxml' );
	;__wxRoute = "pages/safeIndex/safeIndex";__wxRouteBegin = true;__wxAppCurrentFile__="pages/safeIndex/safeIndex.js";define("pages/safeIndex/safeIndex.js",function(require,module,exports,window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){
"use strict";var e=require("../../@babel/runtime/helpers/typeof"),t=require("../../@babel/runtime/helpers/objectSpread2");wx.cloud.init();var n=wx.cloud.database({env:"zhijiebohao-4gp9aizse6797bd3"}),a=n.command;Page({data:{author:null,showAd:!1,phone:"",name:"",msg:"",safe_text:"",inc_id:-1,security:"",safe:!0,rest:!1,safe_due_date:"",src:"",openid:"",show:!1,contactNumbers:void 0,fromMsg:!1},deletePhone:function(){var e=this;wx.showModal({title:"提示",content:"是否删除该号码？删除后您可以再重新获取号码绑定。",success:function(t){t.confirm&&e.data.inc_id&&wx.cloud.callFunction({name:"getUserInfo",data:{phone:"",inc_id:e.data.inc_id}}).then((function(t){e.setData({phone:""},(function(){wx.showToast({title:"删除成功",icon:"none"})}))}))}})},toMoreSafePhone:function(e){wx.navigateTo({url:"/vantPage/moreSafePhone/safePhone"})},toNotice:function(){var e="/pages/webview/webview?url="+encodeURIComponent("https://zhijiebohao-4gp9aizse6797bd3-1257150849.tcloudbaseapp.com/gzh.html?miniAppId=wx5c9674e6177b0f6a&miniEnvId=zhijiebohao-4gp9aizse6797bd3&authorized="+(!(!this.data.author||!this.data.author.xzffw_openid)||"")+"&type=safeIndex");wx.navigateTo({url:e})},toBlackList:function(){wx.navigateTo({url:"/vantPage/safeIndex/safeRecord?safeUserId="+this.data.security})},toMsg:function(){var e=this,t=wx.getSystemInfoSync();"windows"==t.platform||"mac"==t.platform?wx.showToast({title:"电脑端不支持该功能，请在手机端操作。",icon:"none"}):wx.openEmbeddedMiniProgram({path:"/vantPage/msgpagesList/msgpagesList?max=1",appId:"wx4faaf21bf014cd33",success:function(){e.setData({fromMsg:!0})}})},onShow:function(e){var t=wx.getEnterOptionsSync();if(this.data.fromMsg&&1038==t.scene&&"wx4faaf21bf014cd33"==t.referrerInfo.appId){var n=t.referrerInfo.extraData?t.referrerInfo.extraData.res:"cancel";if(n&&"cancel"!=n){var a=JSON.parse(n);if(a&&a.length>0){var o=a[0];this.msgDone({detail:o._id})}}this.setData({fromMsg:!1})}},goNuochema:function(){wx.navigateToMiniProgram({appId:"wx63dc31f506fb8095",path:"plugin-private://wx34345ae5855f892d/pages/productDetail/productDetail?productId=29640290"})},toXhdk:function(){wx.openEmbeddedMiniProgram({path:"/pages/msg/index/index",appId:"wx4faaf21bf014cd33"})},userKnow:function(){wx.navigateTo({url:"/pages/methodD/methodD?id=17453ede60725a19013d9b13631c047n"})},saveIndirectPhone:function(){var e=this;wx.showModal({title:"提示",content:"为避免漏接陌生来电，您可以备注小程序常用的虚拟中间号到手机通讯录中。",complete:function(t){t.confirm&&e.saveIndirectPhoneDo()}})},saveIndirectPhoneDo:function(){var e=this,o=e.data.contactNumbers;o?wx.addPhoneContact(t(t({},o),{},{success:function(){wx.showToast({title:"备注中间号成功",icon:"none"})},fail:function(t){(t.errMsg.indexOf("deny")>-1||t.errMsg.indexOf("denied")>-1||t.errMsg.indexOf("auth")>-1)&&e.showModal("scope.addPhoneContact",(function(){e.saveIndirectPhoneDo()}))}})):(wx.showLoading({title:"查询中间号",mask:!0}),n.collection("user_inc_id").where({_id:a.eq("indirect_phone")}).field({lastName:!0,firstName:!0,remark:!0,mobilePhoneNumber:!0,hostNumber:!0,workPhoneNumber:!0,homePhoneNumber:!0,workFaxNumber:!0,homeFaxNumber:!0}).get({success:function(n){o=n.data[0],e.setData({contactNumbers:o}),wx.addPhoneContact(t(t({},o),{},{success:function(){wx.showToast({title:"备注中间号成功",icon:"none"})},fail:function(t){(t.errMsg.indexOf("deny")>-1||t.errMsg.indexOf("denied")>-1||t.errMsg.indexOf("auth")>-1)&&e.showModal("scope.addPhoneContact",(function(){e.saveIndirectPhoneDo()}))}}))},complete:function(){wx.hideLoading()}}))},getQueryVariable:function(e,t){for(var n=e.split("&"),a=0;a<n.length;a++){var o=n[a].split("=");if(o[0].trim()==t.trim())return o[1].trim()}return!1},qrUnbind:function(){var e=this;wx.showModal({title:"立即解绑该拨号码",content:"将重新生成一张新拨号码，现有码信息将被清空！",success:function(t){t.confirm&&n.collection("phone_safe_user").doc(e.data.security).remove({success:function(t){wx.showToast({title:"解绑成功！",icon:"none"}),wx.cloud.callFunction({name:"getUserInfo",data:{}}).then((function(t){e.resetData(t.result),e.getQR(t.result.inc_id,!0)}))}})}})},qrChange:function(){var e=this;wx.showModal({title:"立即扫描目标码",content:"个人信息将转移到目标码，现有码信息将被清空！",success:function(t){t.confirm&&wx.scanCode({success:function(t){if(t.path&&t.path.indexOf("?")>-1&&t.path.indexOf("scene=")>-1){var n=e.getQueryVariable(t.path.split("?")[1],"scene");if(isNaN(n))return void wx.showToast({title:"请扫描正确的拨号码！",icon:"none"});var a=e.data.inc_id;a==n?wx.showToast({title:"您已绑定该目标码！",icon:"none",duration:3e3}):wx.showModal({title:"扫描成功",content:"您确认要换绑吗？",success:function(t){t.confirm&&(wx.showLoading({title:"换绑中...",mask:!0}),wx.cloud.callFunction({name:"qrChange",data:{new_inc_id:parseInt(n),old_inc_id:a},success:function(t){wx.hideLoading(),200==t.result?(wx.showToast({title:"换绑成功！",icon:"none"}),e.getQR(n,!0),e.setData({inc_id:n})):300==t.result?wx.showToast({title:"请扫描正确的拨号码！",icon:"none",duration:3e3}):400==t.result?wx.showToast({title:"该目标码已被其他用户绑定！",icon:"none",duration:3e3}):wx.showToast({title:"网络异常！",icon:"none",duration:3e3})}}))}})}else wx.showToast({title:"请扫描正确的拨号码！",icon:"none"})}})}})},safe_textDone:function(e){var t=this;e.detail.value!=t.data.safe_text&&(wx.showLoading({title:"文案检测中",mask:!0}),wx.cloud.callFunction({name:"msgSecCheck",data:{content:e.detail.value}}).then((function(n){wx.hideLoading(),0==n.result.errCode?wx.cloud.callFunction({name:"getUserInfo",data:{safe_text:e.detail.value,inc_id:t.data.inc_id}}).then((function(n){t.setData({safe_text:e.detail.value}),wx.showToast({title:"保存成功",icon:"none"})})):(wx.showToast({title:"文案存在违法违规风险，请重新输入！",icon:"none",duration:3e3}),t.setData({safe_text:""}))})))},nameDone:function(e){var t=this;e.detail.value!=t.data.name&&(wx.showLoading({title:"名字检测中",mask:!0}),wx.cloud.callFunction({name:"msgSecCheck",data:{content:e.detail.value}}).then((function(n){wx.hideLoading(),0==n.result.errCode?wx.cloud.callFunction({name:"getUserInfo",data:{name:e.detail.value,inc_id:t.data.inc_id}}).then((function(n){t.setData({name:e.detail.value}),wx.showToast({title:"保存成功",icon:"none"})})):(wx.showToast({title:"名字存在违法违规风险，请重新输入！",icon:"none",duration:3e3}),t.setData({name:""}))})))},phoneDone:function(e){var t=this;e.detail.value!=t.data.phone&&t.data.inc_id&&(wx.showLoading({title:"号码检测中",mask:!0}),wx.cloud.callFunction({name:"msgSecCheck",data:{content:e.detail.value}}).then((function(n){wx.hideLoading(),0==n.result.errCode?wx.cloud.callFunction({name:"getUserInfo",data:{phone:e.detail.value,inc_id:t.data.inc_id}}).then((function(n){t.setData({phone:e.detail.value}),wx.showToast({title:"保存成功",icon:"none"})})):(wx.showToast({title:"号码存在违法违规风险，请重新输入！",icon:"none",duration:3e3}),t.setData({phone:""}))})))},msgDone:function(e){var t=this;e.detail||(e.detail=""),e.detail!=this.data.msg&&wx.cloud.callFunction({name:"getUserInfo",data:{msg:e.detail,inc_id:this.data.inc_id}}).then((function(n){t.setData({msg:e.detail}),wx.showToast({title:"保存成功",icon:"none"})}))},preview:function(){wx.previewImage({urls:[this.data.src]})},previewCall:function(){wx.navigateTo({url:"/sc/c?scene="+this.data.inc_id})},getPhoneNumber:function(e){var t=this;wx.hideLoading();var n=this;e.detail.cloudID&&(wx.showLoading({title:"获取中",mask:!0}),wx.cloud.callFunction({name:"login",data:{weRunData:wx.cloud.CloudID(e.detail.cloudID),code:!!e.detail.code&&e.detail.code}}).then((function(a){wx.hideLoading();var o=e.detail.code?a.result.phoneInfo.phoneNumber:a.result.event.weRunData.data.phoneNumber;t.setData({phone:o}),n.data.inc_id&&wx.cloud.callFunction({name:"getUserInfo",data:{phone:o,inc_id:n.data.inc_id}}).then((function(e){wx.showToast({title:"绑定成功",icon:"none"})}))})))},copySecurity:function(){this.data.security&&wx.setClipboardData({data:this.data.security,success:function(){wx.hideLoading(),wx.showToast({title:"ID复制成功",icon:"none"})}})},safeChange:function(e){this.setData({safe:e.detail.value});var t=0;e.detail.value&&(t=1),this.data.inc_id&&wx.cloud.callFunction({name:"getUserInfo",data:{safe:t,inc_id:this.data.inc_id}}).then((function(e){wx.showToast({title:"切换成功",icon:"none"})}))},restChange:function(e){var t=this;e.detail.value?wx.showModal({title:"是否开启勿扰模式？",content:"开启后所有人将无法扫码联系到你哟！",confirmText:"开启",confirmColor:"#E64340",cancelText:"不开启",cancelColor:"#07c160",success:function(n){n.confirm?(t.setData({rest:e.detail.value}),t.data.inc_id&&wx.cloud.callFunction({name:"getUserInfo",data:{rest:1,inc_id:t.data.inc_id}}).then((function(e){wx.showToast({title:"切换成功",icon:"none"})}))):n.cancel&&t.setData({rest:!1})}}):(t.setData({rest:e.detail.value}),t.data.inc_id&&wx.cloud.callFunction({name:"getUserInfo",data:{rest:0,inc_id:t.data.inc_id}}).then((function(e){wx.showToast({title:"切换成功",icon:"none"})})))},onLoad:function(e){var t=this;wx.cloud.callFunction({name:"getUserInfo",data:{}}).then((function(n){t.setData({show:!0}),t.resetData(n.result),t.getQR(n.result.inc_id,e.qrChange)})),wx.cloud.callFunction({name:"login",complete:function(e){t.setData({author:e.result})}})},resetData:function(e){this.setData({inc_id:e.inc_id,phone:e.phone?e.phone:"",name:e.name,safe:e.safe,safe_due_date:this.formatTime(e.safe_due_date),rest:e.rest,showAd:e.showAd,security:e._id?e._id:"首次分配",msg:e.msg,safe_text:e.safe_text})},getQR:function(e,t){var n=this;if(isNaN(e))wx.showToast({title:"获取失败，请稍后重试！",icon:"none"});else{var a=wx.getFileSystemManager(),o=wx.getStorageSync("code_cache"+e);o&&!t?a.access({path:o.toString(),success:function(e){n.setData({src:o})},fail:function(t){n.getUnlimitedCode(a,e)}}):n.getUnlimitedCode(a,e)}},getUnlimitedCode:function(e,t){var n=this;n.setData({src:""}),wx.cloud.callFunction({name:"getUnlimitedCode",data:{scene:t,page:"sc/c",width:1280},success:function(a){if(0==a.result.errCode){var o=wx.env.USER_DATA_PATH+"/"+n.data.inc_id+".png";e.writeFile({filePath:o,data:a.result.buffer,encoding:"binary",success:function(){n.setData({src:o}),wx.setStorageSync("code_cache"+t,o)}})}else wx.showToast({title:"网络异常，请稍后重试。",icon:"none",mask:!0})},fail:function(e){wx.showToast({title:"网络异常，请稍后重试。",icon:"none",mask:!0})}})},onOpenSetting:function(e,t){wx.openSetting({success:function(n){n.authSetting[e]?t():wx.showToast({title:"您未授权",icon:"none"})}})},savedownloadFile:function(){var e=this;e.data.src.indexOf("loading")>-1?wx.showToast({title:"未获取到圆形码图片",icon:"none"}):wx.saveImageToPhotosAlbum({filePath:e.data.src,success:function(e){wx.showToast({title:"保存成功"})},fail:function(t){(t.errMsg.indexOf("deny")>-1||t.errMsg.indexOf("denied")>-1||t.errMsg.indexOf("auth")>-1)&&e.showModal("scope.writePhotosAlbum",(function(){e.savedownloadFile()}))}})},showModal:function(e,t){var n=this,a="";switch(e){case"scope.writePhotosAlbum":a="保存到相册";break;case"scope.addPhoneContact":a="添加到通讯录"}wx.showModal({title:"检测到您没有打开"+a+"的权限，是否前往设置打开？",success:function(a){a.confirm?n.onOpenSetting(e,t):a.cancel}})},formatTime:function(t,n){if(t){switch(n||(n="yyyy-MM-dd HH:mm"),e(t)){case"string":var a=!1;t.indexOf("T")>-1&&t.indexOf("Z")>-1&&(a=!0,t=t.replace(/T/g," ").substring(0,t.lastIndexOf("."))),t=t.replace(/-/g,"/"),t=new Date(t),a&&(t=new Date(t.getTime()+288e5));break;case"number":t=new Date(t)}if(!(!t instanceof Date)){var o={yyyy:t.getFullYear(),M:t.getMonth()+1,d:t.getDate(),H:t.getHours(),m:t.getMinutes(),s:t.getSeconds(),MM:(""+(t.getMonth()+101)).substr(1),dd:(""+(t.getDate()+100)).substr(1),HH:(""+(t.getHours()+100)).substr(1),mm:(""+(t.getMinutes()+100)).substr(1),ss:(""+(t.getSeconds()+100)).substr(1)};return n.replace(/(yyyy|MM?|dd?|HH?|ss?|mm?)/g,(function(){return o[arguments[0]]}))}}},onShareAppMessage:function(e){return"button"===e.from&&console.log(e.target),{title:"制作专属电话码，扫码虚拟号呼叫，保护真实号码安全",imageUrl:"cloud://zhijiebohao-4gp9aizse6797bd3.7a68-zhijiebohao-4gp9aizse6797bd3-1257150849/share.jpg",path:"/pages/safeIndex/safeIndex"}}});
},{isPage:true,isComponent:true,currentFile:'pages/safeIndex/safeIndex.js'});require("pages/safeIndex/safeIndex.js");