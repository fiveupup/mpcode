$gwx_XC_28=function(_,_v,_n,_p,_s,_wp,_wl,$gwn,$gwl,$gwh,wh,$gstack,$gwrt,gra,grb,TestTest,wfor,_ca,_da,_r,_rz,_o,_oz,_1,_1z,_2,_2z,_m,_mz,nv_getDate,nv_getRegExp,nv_console,nv_parseInt,nv_parseFloat,nv_isNaN,nv_isFinite,nv_decodeURI,nv_decodeURIComponent,nv_encodeURI,nv_encodeURIComponent,$gdc,nv_JSON,_af,_gv,_ai,_grp,_gd,_gapi,$ixc,_ic,_w,_ev,_tsd){return function(path,global){
if(typeof global==='undefined'){if (typeof __GWX_GLOBAL__==='undefined')global={};else global=__GWX_GLOBAL__;}if(typeof __WXML_GLOBAL__ === 'undefined') {__WXML_GLOBAL__={};
}__WXML_GLOBAL__.modules = __WXML_GLOBAL__.modules || {};
var e_={}
if(typeof(global.entrys)==='undefined')global.entrys={};e_=global.entrys;
var d_={}
if(typeof(global.defines)==='undefined')global.defines={};d_=global.defines;
var f_={}
if(typeof(global.modules)==='undefined')global.modules={};f_=global.modules || {};
var p_={}
__WXML_GLOBAL__.ops_cached = __WXML_GLOBAL__.ops_cached || {}
__WXML_GLOBAL__.ops_set = __WXML_GLOBAL__.ops_set || {};
__WXML_GLOBAL__.ops_init = __WXML_GLOBAL__.ops_init || {};
var z=__WXML_GLOBAL__.ops_set.$gwx_XC_28 || [];
function gz$gwx_XC_28_1(){
if( __WXML_GLOBAL__.ops_cached.$gwx_XC_28_1)return __WXML_GLOBAL__.ops_cached.$gwx_XC_28_1
__WXML_GLOBAL__.ops_cached.$gwx_XC_28_1=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
Z([3,'width:100%;height:100%;box-sizing:border-box;'])
Z([[7],[3,'info']])
Z([[7],[3,'targetMethod']])
Z([3,'position:fixed;left:0;bottom:0;width:100%;background:#ffffff;display: flex;justify-content: center;align-items:center;padding:20rpx 0;'])
Z([[2,'||'],[[2,'||'],[[2,'=='],[[6],[[7],[3,'targetMethod']],[3,'type']],[1,1]],[[2,'=='],[[6],[[7],[3,'targetMethod']],[3,'type']],[1,2]]],[[2,'=='],[[6],[[7],[3,'targetMethod']],[3,'type']],[1,5]]])
Z([[2,'||'],[[2,'=='],[[6],[[7],[3,'targetMethod']],[3,'type']],[1,3]],[[2,'=='],[[6],[[7],[3,'targetMethod']],[3,'type']],[1,4]]])
Z([3,'myPrivacy'])
})(__WXML_GLOBAL__.ops_cached.$gwx_XC_28_1);return __WXML_GLOBAL__.ops_cached.$gwx_XC_28_1
}
__WXML_GLOBAL__.ops_set.$gwx_XC_28=z;
__WXML_GLOBAL__.ops_init.$gwx_XC_28=true;
var x=['./pages/methodD/methodD.wxml'];d_[x[0]]={}
var m0=function(e,s,r,gg){
var z=gz$gwx_XC_28_1()
var o0H=_n('view')
_rz(z,o0H,'style',0,e,s,gg)
var cAI=_v()
_(o0H,cAI)
if(_oz(z,1,e,s,gg)){cAI.wxVkey=1
}
var oBI=_v()
_(o0H,oBI)
if(_oz(z,2,e,s,gg)){oBI.wxVkey=1
var lCI=_n('view')
_rz(z,lCI,'style',3,e,s,gg)
var aDI=_v()
_(lCI,aDI)
if(_oz(z,4,e,s,gg)){aDI.wxVkey=1
}
var tEI=_v()
_(lCI,tEI)
if(_oz(z,5,e,s,gg)){tEI.wxVkey=1
}
aDI.wxXCkey=1
tEI.wxXCkey=1
_(oBI,lCI)
}
cAI.wxXCkey=1
oBI.wxXCkey=1
_(r,o0H)
var eFI=_n('my-privacy')
_rz(z,eFI,'id',6,e,s,gg)
_(r,eFI)
return r
}
e_[x[0]]={f:m0,j:[],i:[],ti:[],ic:[]}
if(path&&e_[path]){
return function(env,dd,global){$gwxc=0;var root={"tag":"wx-page"};root.children=[]
;g="$gwx_XC_28";var main=e_[path].f
if (typeof global==="undefined")global={};global.f=$gdc(f_[path],"",1);
try{
main(env,{},root,global);
_tsd(root)
}catch(err){
console.log(err)
}
;g="";
return root;
}
}
}
}(__g.a,__g.b,__g.c,__g.d,__g.e,__g.f,__g.g,__g.h,__g.i,__g.j,__g.k,__g.l,__g.m,__g.n,__g.o,__g.p,__g.q,__g.r,__g.s,__g.t,__g.u,__g.v,__g.w,__g.x,__g.y,__g.z,__g.A,__g.B,__g.C,__g.D,__g.E,__g.F,__g.G,__g.H,__g.I,__g.J,__g.K,__g.L,__g.M,__g.N,__g.O,__g.P,__g.Q,__g.R,__g.S,__g.T,__g.U,__g.V,__g.W,__g.X,__g.Y,__g.Z,__g.aa);if(__vd_version_info__.delayedGwx||false)$gwx_XC_28();	if (__vd_version_info__.delayedGwx) __wxAppCode__['pages/methodD/methodD.wxml'] = [$gwx_XC_28, './pages/methodD/methodD.wxml'];else __wxAppCode__['pages/methodD/methodD.wxml'] = $gwx_XC_28( './pages/methodD/methodD.wxml' );
	;__wxRoute = "pages/methodD/methodD";__wxRouteBegin = true;__wxAppCurrentFile__="pages/methodD/methodD.js";define("pages/methodD/methodD.js",function(require,module,exports,window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){
"use strict";var t=require("../../@babel/runtime/helpers/regeneratorRuntime"),e=require("../../@babel/runtime/helpers/asyncToGenerator");wx.cloud.init();var a,n,p,r=wx.cloud.database({env:"zhijiebohao-4gp9aizse6797bd3"}),i=r.command;Page({data:{showReplaceCopy:!1,title:"",nodes:"加载中...",info:!1,url:"",name:"",miniInfo:{name:"小正方助手",appid:"wx5c9674e6177b0f6a"},targetMethod:void 0,close_ad:!0,rPhone:"",rName:"",rMsg:"",res:"",focus:!1,systemInfo:{},methodD_5:{_id:"5",close_ad:!1,content:'<div style="line-height: 1.7;font-size:24rpx;margin-top: 5px;">     <p style="font-weight: bold;">免责声明</p>     <p> 　　访问者在接受小正方助手小程序（以下简称本小程序）的服务之前，请务必仔细阅读本条款并同意本声明。访问者访问本小程序的行为以及通过各类方式利用本小程序的行为，都将被视作是对本声明全部内容的无异议的认可;如有异议，请立即跟本小程序协商，并取得本小程序的书面同意意见。     </p><br>     <p> 　　第一条、访问者在从事与本小程序相关的所有行为(包括但不限于访问浏览、利用、转载、宣传介绍)时，必须以善意且谨慎的态度行事，访问者不得故意或者过失的损害或者弱化本小程序的各类合法权利与利益，不得利用本小程序以任何方式直接或者间接的从事违反中国法律、国际公约以及社会公德的行为，且访问者应当恪守下述承诺：     </p><br>     <p>　　1、传输和利用信息符合中国法律、国际公约的规定、符合公序良俗; </p><br>     <p>　　2、不将本小程序以及与之相关的网络服务用作非法用途以及非正当用途; </p><br>     <p>　　3、不干扰和扰乱本小程序以及与之相关的网络服务; </p><br>     <p>　　4、遵守与本小程序以及与之相关的网络服务的协议、规定、程序和惯例等。</p><br>     <p>　　第二条、本小程序郑重提醒访问者：请在转载、上载或者下载有关作品时务必尊重该作品的版权、著作权。</p><br>     <p>　　第三条、本小程序用户原创的作品，作者享有独家版权，未经授权严禁转载或用于其它商业用途。</p><br>     <p>　　第四条、本小程序内容仅代表作者本人的观点，不代表本小程序的观点和看法，与本小程序立场无关，相关责任作者自负。</p><br>     <p>　　第五条、本小程序有权将在本小程序内发表的无版权作品用于其他用途，包括网站、电子杂志等，作品有附带版权声明者除外。</p><br>     <p>　　第六条、未经作者同意，其他任何机构不得以任何形式侵犯其作品著作权，包括但不限于：非法使用或转载，或以任何方式建立作品镜像。</p><br>     <p> 　　第七条、本小程序所刊载的各类形式(包括但不仅限于文字、图片、图表)的作品仅供参考使用，并不代表本小程序同意其说法或描述，仅为提供更多信息，也不构成任何投资建议。对于访问者根据本小程序提供的信息所做出的一切行为，除非另有明确的书面承诺文件，否则本小程序不承担任何形式的责任。     </p><br>     <p>　　第八条、当本小程序不保证使用者查看的任何内容、产品、服务或其他材料的真实性、合法性，对于任何因使用或信赖从此类网站或资源上获取的内容、产品、服务或其他材料而造成(或声称造成)的任何直接或间接损失，本小程序均不承担任何责任。     </p><br>     <p>　　第九条、访问者在本小程序注册时提供的一些个人资料，本小程序除您本人同意及第十条规定外不会将用户的任何资料以任何方式泄露给任何一方。</p><br>     <p>　　第十条、当政府部门、司法机关等依照法定程序要求本小程序披露个人资料时，本小程序将根据执法单位之要求或为公共安全之目的提供个人资料。在此情况下之任何披露，本小程序均得免责。</p><br>     <p>　　第十一条、由于用户将个人密码告知他人或与他人共享注册账户，由此导致的任何个人资料泄露，本小程序不负任何责任。</p> </div> <div style="line-height: 1.7;font-size:24rpx;margin-top: 15px;">     <p style="font-weight: bold;">广告说明</p>     <p style="margin:8px 0;">　　页面偶现弹出广告由微信提供，请访问者自主识别。</p> </div>',name:"免责声明",url:"/pages/methodD/methodD?id=5"},methodD_6:{_id:"6",close_ad:!1,content:'<div style="line-height: 1.75;"><p><span>上传并添加文件，多场景使用，支持doc、docx、xls、xlsx、ppt、pptx、pdf等文件格式（更多格式请将本小程序分享到电脑端微信中使用）。</span></p><br><p>注意：请勿上传违法违规内容，24h审核机制，一经发现，严肃处理！</p><br><p>您可以访问官网查看详细使用教程：https://bohao.wsqytec.com（长按网址复制）<br><br><p style="font-weight: bold;color: #07c160;">基本步骤：</p><p><span>1、将需要上传的文件发送到微信聊天列表。</span></p><p><span>2、在小程序“小正方助手”的“云上文件”页面点击上传。</span></p><p style="margin:8px 0;text-align: center;"><img style="width:75%;"src="https://cos.wsqytec.com/method/article_file/1.jpg"/></p><p><span>3、在弹出的选择聊天界面选择文件。</span></p><p style="margin:8px 0;text-align: center;"><img style="width:75%;"src="https://cos.wsqytec.com/mini_cloud/method/article_file/2.1.jpg"/></p><p><span>4、选择聊天中需要上传的文件。</span></p><p style="margin:8px 0;text-align: center;"><img style="width:75%;"src="https://cos.wsqytec.com/mini_cloud/method/article_file/3.jpg"/></p><p><span>5、上传成功后点击列表中上传的文件，选择“复制路径”。</span></p><p style="margin:8px 0;text-align: center;"><img style="width:75%;"src="https://cos.wsqytec.com/method/article_file/5.jpg"/></p><p><span style="font-weight: bold;line-height:2.5;">文章中使用</span></p><p><span>编辑文章，在需要插入附件的地方选择插入并搜索小程序“小正方助手”，在填写详细信息界面中，小程序路径填写第5步时复制的路径。</span></p><p><span>点击插入小程序，然后去搜索：</span></p><p style="margin:8px 0;text-align: center;"><img src="https://cos.wsqytec.com/mini_cloud/method/article_file/5.png"/></p><p style="margin:8px 0;text-align: center;"><img src="https://cos.wsqytec.com/method/article_file/5.0.png"/></p><p><span>搜索“小正方助手”：</span></p><p style="margin:8px 0;text-align: center;"><img src="https://cos.wsqytec.com/method/article_file/6.jpg"/></p><p><span>小程序路径只需要填写第5步时复制的路径，文字内容随便：</span></p><p style="margin:8px 0;text-align: center;"><img src="https://cos.wsqytec.com/method/article_file/7.jpg"/></p><p><span style="font-weight: bold;line-height:2.5;">菜单上使用</span></p><p><span>先关联小正方助手小程序，添加菜单时选择调跳转小程序到文件路径即可。</span></p></div>',name:"小正方助手小程序",target_method_id:"1",url:"/pages/methodD/methodD?id=6"},methodD_1:{_id:"1",content:"",name:"去上传",type:5,url:"/pages/file/cloudFile/index"}},copyInfo:function(t){wx.setClipboardData({data:t.currentTarget.dataset.value})},staticMethodD:function(t){var e=this,a=e.data["methodD_"+t];e.formatRichTextImg(a.content).then((function(t){e.setData({nodes:t,title:a.name,url:a.url,name:a.name}),wx.setNavigationBarTitle({title:a.name})})),6==t&&e.setData({targetMethod:e.data.methodD_1})},onLoad:(p=e(t().mark((function e(a){var n,p,s,o;return t().wrap((function(t){for(;;)switch(t.prev=t.next){case 0:if(5!=(n=a.id)&&6!=n){t.next=4;break}return this.staticMethodD(n),t.abrupt("return");case 4:p=a.info,s=this,o=wx.getSystemInfoSync(),r.collection("method_list").where({_id:i.eq(n)}).field({name:!0,content:!0,url:!0,target_method_id:!0,close_ad:!0}).get({success:function(t){s.setData({systemInfo:o,close_ad:t.data[0].close_ad});var e=t.data[0].content,a=t.data[0].name,n=t.data[0].url;e?s.formatRichTextImg(e).then((function(t){s.setData({nodes:t,info:p,title:a,url:n,name:a}),wx.setNavigationBarTitle({title:a})})):s.setData({nodes:"空空如也",info:p}),t.data[0].target_method_id&&r.collection("method_list").where({_id:i.eq(t.data[0].target_method_id)}).field({simple_name:!0,content:!0,url:!0,type:!0,name:!0}).get({success:function(t){s.setData({targetMethod:t.data[0]})}})}});case 8:case"end":return t.stop()}}),e,this)}))),function(t){return p.apply(this,arguments)}),toMethod:function(t){var e=this.data.targetMethod;1==e.type?wx.navigateTo({url:e.url}):2==e.type?wx.navigateToMiniProgram({appId:e.content,path:e.url}):5==e.type&&wx.switchTab({url:e.url})},formatRichTextImg:(n=e(t().mark((function e(a){var n,p,r,i,s;return t().wrap((function(t){for(;;)switch(t.prev=t.next){case 0:if(n=new RegExp('(class)="[^"]+"',"g"),a=a.replace(n,"").replace(new RegExp("<img","g"),'<img class="richImg"  ').replace(new RegExp("\ufeff","g"),""),!(p=this.getAllSrc(a))){t.next=8;break}return t.next=6,this.turnImageUrl(p);case 6:for(r=t.sent,i=0;i<r.fileList.length;i++)s=r.fileList[i],a=a.replace(s.fileID,s.tempFileURL);case 8:return t.abrupt("return",a);case 9:case"end":return t.stop()}}),e,this)}))),function(t){return n.apply(this,arguments)}),getAllSrc:function(t){var e=new RegExp("(src|SRC)=(\"|')(.*?)(\"|')","g");try{return t.match(e).map((function(t,e,a){return t.replace("src=","").replace(new RegExp("(\"|')","g"),"")})).filter((function(t){return t.indexOf("cloud://")>-1}))}catch(t){return}},turnImageUrl:(a=e(t().mark((function e(a){var n;return t().wrap((function(t){for(;;)switch(t.prev=t.next){case 0:return t.next=2,wx.cloud.getTempFileURL({fileList:a});case 2:return n=t.sent,t.abrupt("return",n);case 4:case"end":return t.stop()}}),e)}))),function(t){return a.apply(this,arguments)}),onShareAppMessage:function(t){return"button"===t.from&&console.log(t.target),{title:this.data.name,imageUrl:"cloud://zhijiebohao-4gp9aizse6797bd3.7a68-zhijiebohao-4gp9aizse6797bd3-1257150849/share-xzf.jpg",path:this.data.url}}});
},{isPage:true,isComponent:true,currentFile:'pages/methodD/methodD.js'});require("pages/methodD/methodD.js");