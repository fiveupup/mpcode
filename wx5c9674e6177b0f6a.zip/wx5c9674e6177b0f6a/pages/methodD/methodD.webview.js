$gwx_XC_28=function(_,_v,_n,_p,_s,_wp,_wl,$gwn,$gwl,$gwh,wh,$gstack,$gwrt,gra,grb,TestTest,wfor,_ca,_da,_r,_rz,_o,_oz,_1,_1z,_2,_2z,_m,_mz,nv_getDate,nv_getRegExp,nv_console,nv_parseInt,nv_parseFloat,nv_isNaN,nv_isFinite,nv_decodeURI,nv_decodeURIComponent,nv_encodeURI,nv_encodeURIComponent,$gdc,nv_JSON,_af,_gv,_ai,_grp,_gd,_gapi,$ixc,_ic,_w,_ev,_tsd){return function(path,global){
if(typeof global==='undefined'){if (typeof __GWX_GLOBAL__==='undefined')global={};else global=__GWX_GLOBAL__;}if(typeof __WXML_GLOBAL__ === 'undefined') {__WXML_GLOBAL__={};
}__WXML_GLOBAL__.modules = __WXML_GLOBAL__.modules || {};
var e_={}
if(typeof(global.entrys)==='undefined')global.entrys={};e_=global.entrys;
var d_={}
if(typeof(global.defines)==='undefined')global.defines={};d_=global.defines;
var f_={}
if(typeof(global.modules)==='undefined')global.modules={};f_=global.modules || {};
var p_={}
__WXML_GLOBAL__.ops_cached = __WXML_GLOBAL__.ops_cached || {}
__WXML_GLOBAL__.ops_set = __WXML_GLOBAL__.ops_set || {};
__WXML_GLOBAL__.ops_init = __WXML_GLOBAL__.ops_init || {};
var z=__WXML_GLOBAL__.ops_set.$gwx_XC_28 || [];
function gz$gwx_XC_28_1(){
if( __WXML_GLOBAL__.ops_cached.$gwx_XC_28_1)return __WXML_GLOBAL__.ops_cached.$gwx_XC_28_1
__WXML_GLOBAL__.ops_cached.$gwx_XC_28_1=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
Z([3,'width:100%;height:100%;box-sizing:border-box;'])
Z([[7],[3,'info']])
Z([3,'box-shadow:0 0 10rpx #cccccc;border-radius:10rpx;margin:20rpx;padding:16rpx;font-size:30rpx;letter-spacing:0.3px;line-height: 1.75em;'])
Z([a,[3,'小程序名称：'],[[6],[[7],[3,'miniInfo']],[3,'name']]])
Z([3,'copyInfo'])
Z([3,'weui-msg__desc'])
Z([[6],[[7],[3,'miniInfo']],[3,'name']])
Z([3,'border:1px solid #ccc;padding:4rpx 10rpx;font-size:24rpx;border-radius:10rpx;margin-left:20rpx;'])
Z([3,'复制'])
Z([a,[3,'小程序appid：'],[[6],[[7],[3,'miniInfo']],[3,'appid']]])
Z(z[4])
Z(z[5])
Z([[6],[[7],[3,'miniInfo']],[3,'appid']])
Z(z[7])
Z(z[8])
Z([3,'padding:10rpx 20rpx;width:100%;box-sizing:border-box;border-radius:20rpx;margin-bottom:calc(env(safe-area-inset-bottom));'])
Z([[7],[3,'nodes']])
Z([1,true])
Z([3,'height:120rpx;width:100%'])
Z([[7],[3,'targetMethod']])
Z([3,'position:fixed;left:0;bottom:0;width:100%;background:#ffffff;display: flex;justify-content: center;align-items:center;padding:20rpx 0;'])
Z([[2,'||'],[[2,'||'],[[2,'=='],[[6],[[7],[3,'targetMethod']],[3,'type']],[1,1]],[[2,'=='],[[6],[[7],[3,'targetMethod']],[3,'type']],[1,2]]],[[2,'=='],[[6],[[7],[3,'targetMethod']],[3,'type']],[1,5]]])
Z([3,'toMethod'])
Z([3,'weui-btn weui-btn_primary'])
Z([3,'width:80%;margin-bottom:calc(env(safe-area-inset-bottom)/3); border-radius:46rpx;'])
Z([a,[[2,'?:'],[[6],[[7],[3,'targetMethod']],[3,'simple_name']],[[6],[[7],[3,'targetMethod']],[3,'simple_name']],[[6],[[7],[3,'targetMethod']],[3,'name']]]])
Z([[2,'||'],[[2,'=='],[[6],[[7],[3,'targetMethod']],[3,'type']],[1,3]],[[2,'=='],[[6],[[7],[3,'targetMethod']],[3,'type']],[1,4]]])
Z(z[23])
Z([[2,'?:'],[[2,'=='],[[6],[[7],[3,'targetMethod']],[3,'type']],[1,3]],[1,'contact'],[1,'feedback']])
Z(z[24])
Z([a,z[25][1]])
Z([3,'myPrivacy'])
})(__WXML_GLOBAL__.ops_cached.$gwx_XC_28_1);return __WXML_GLOBAL__.ops_cached.$gwx_XC_28_1
}
__WXML_GLOBAL__.ops_set.$gwx_XC_28=z;
__WXML_GLOBAL__.ops_init.$gwx_XC_28=true;
var x=['./pages/methodD/methodD.wxml'];d_[x[0]]={}
var m0=function(e,s,r,gg){
var z=gz$gwx_XC_28_1()
var cZP=_n('view')
_rz(z,cZP,'style',0,e,s,gg)
var h1P=_v()
_(cZP,h1P)
if(_oz(z,1,e,s,gg)){h1P.wxVkey=1
var c3P=_n('view')
_rz(z,c3P,'style',2,e,s,gg)
var o4P=_n('view')
var l5P=_n('span')
var a6P=_oz(z,3,e,s,gg)
_(l5P,a6P)
_(o4P,l5P)
var t7P=_mz(z,'a',['bindtap',4,'class',1,'data-value',2,'style',3],[],e,s,gg)
var e8P=_oz(z,8,e,s,gg)
_(t7P,e8P)
_(o4P,t7P)
_(c3P,o4P)
var b9P=_n('view')
var o0P=_n('span')
var xAQ=_oz(z,9,e,s,gg)
_(o0P,xAQ)
_(b9P,o0P)
var oBQ=_mz(z,'a',['bindtap',10,'class',1,'data-value',2,'style',3],[],e,s,gg)
var fCQ=_oz(z,14,e,s,gg)
_(oBQ,fCQ)
_(b9P,oBQ)
_(c3P,b9P)
_(h1P,c3P)
}
var cDQ=_n('view')
_rz(z,cDQ,'style',15,e,s,gg)
var hEQ=_mz(z,'rich-text',['nodes',16,'userSelect',1],[],e,s,gg)
_(cDQ,hEQ)
_(cZP,cDQ)
var oFQ=_n('view')
_rz(z,oFQ,'style',18,e,s,gg)
_(cZP,oFQ)
var o2P=_v()
_(cZP,o2P)
if(_oz(z,19,e,s,gg)){o2P.wxVkey=1
var cGQ=_n('view')
_rz(z,cGQ,'style',20,e,s,gg)
var oHQ=_v()
_(cGQ,oHQ)
if(_oz(z,21,e,s,gg)){oHQ.wxVkey=1
var aJQ=_mz(z,'button',['bindtap',22,'class',1,'style',2],[],e,s,gg)
var tKQ=_oz(z,25,e,s,gg)
_(aJQ,tKQ)
_(oHQ,aJQ)
}
var lIQ=_v()
_(cGQ,lIQ)
if(_oz(z,26,e,s,gg)){lIQ.wxVkey=1
var eLQ=_mz(z,'button',['class',27,'openType',1,'style',2],[],e,s,gg)
var bMQ=_oz(z,30,e,s,gg)
_(eLQ,bMQ)
_(lIQ,eLQ)
}
oHQ.wxXCkey=1
lIQ.wxXCkey=1
_(o2P,cGQ)
}
h1P.wxXCkey=1
o2P.wxXCkey=1
_(r,cZP)
var oNQ=_n('my-privacy')
_rz(z,oNQ,'id',31,e,s,gg)
_(r,oNQ)
return r
}
e_[x[0]]={f:m0,j:[],i:[],ti:[],ic:[]}
if(path&&e_[path]){
outerGlobal.__wxml_comp_version__=0.02
return function(env,dd,global){$gwxc=0;var root={"tag":"wx-page"};root.children=[]
;g="$gwx_XC_28";var main=e_[path].f
if (typeof global==="undefined")global={};global.f=$gdc(f_[path],"",1);
if(typeof(outerGlobal.__webview_engine_version__)!='undefined'&&outerGlobal.__webview_engine_version__+1e-6>=0.02+1e-6&&outerGlobal.__mergeData__)
{
env=outerGlobal.__mergeData__(env,dd);
}
try{
main(env,{},root,global);
_tsd(root)
if(typeof(outerGlobal.__webview_engine_version__)=='undefined'|| outerGlobal.__webview_engine_version__+1e-6<0.01+1e-6){return _ev(root);}
}catch(err){
console.log(err)
}
;g="";
return root;
}
}
}
}(__g.a,__g.b,__g.c,__g.d,__g.e,__g.f,__g.g,__g.h,__g.i,__g.j,__g.k,__g.l,__g.m,__g.n,__g.o,__g.p,__g.q,__g.r,__g.s,__g.t,__g.u,__g.v,__g.w,__g.x,__g.y,__g.z,__g.A,__g.B,__g.C,__g.D,__g.E,__g.F,__g.G,__g.H,__g.I,__g.J,__g.K,__g.L,__g.M,__g.N,__g.O,__g.P,__g.Q,__g.R,__g.S,__g.T,__g.U,__g.V,__g.W,__g.X,__g.Y,__g.Z,__g.aa);if(__vd_version_info__.delayedGwx||false)$gwx_XC_28();	if (__vd_version_info__.delayedGwx) __wxAppCode__['pages/methodD/methodD.wxml'] = [$gwx_XC_28, './pages/methodD/methodD.wxml'];else __wxAppCode__['pages/methodD/methodD.wxml'] = $gwx_XC_28( './pages/methodD/methodD.wxml' );
	
var noCss=typeof __vd_version_info__!=='undefined'&&__vd_version_info__.noCss===true;if(!noCss){__wxAppCode__['pages/methodD/methodD.wxss'] = setCssToHead(["wx-rich-text .",[1],"richImg{border-radius:",[0,20],";max-height:100%;max-width:100%;vertical-align:middle}\nwx-button,wx-button::after{border:0!important}\n",],"Some selectors are not allowed in component wxss, including tag name selectors, ID selectors, and attribute selectors.(./pages/methodD/methodD.wxss:1:93)",{path:"./pages/methodD/methodD.wxss"});
}