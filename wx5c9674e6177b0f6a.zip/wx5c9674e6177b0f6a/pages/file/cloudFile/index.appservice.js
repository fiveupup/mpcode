$gwx_XC_25=function(_,_v,_n,_p,_s,_wp,_wl,$gwn,$gwl,$gwh,wh,$gstack,$gwrt,gra,grb,TestTest,wfor,_ca,_da,_r,_rz,_o,_oz,_1,_1z,_2,_2z,_m,_mz,nv_getDate,nv_getRegExp,nv_console,nv_parseInt,nv_parseFloat,nv_isNaN,nv_isFinite,nv_decodeURI,nv_decodeURIComponent,nv_encodeURI,nv_encodeURIComponent,$gdc,nv_JSON,_af,_gv,_ai,_grp,_gd,_gapi,$ixc,_ic,_w,_ev,_tsd){return function(path,global){
if(typeof global==='undefined'){if (typeof __GWX_GLOBAL__==='undefined')global={};else global=__GWX_GLOBAL__;}if(typeof __WXML_GLOBAL__ === 'undefined') {__WXML_GLOBAL__={};
}__WXML_GLOBAL__.modules = __WXML_GLOBAL__.modules || {};
var e_={}
if(typeof(global.entrys)==='undefined')global.entrys={};e_=global.entrys;
var d_={}
if(typeof(global.defines)==='undefined')global.defines={};d_=global.defines;
var f_={}
if(typeof(global.modules)==='undefined')global.modules={};f_=global.modules || {};
var p_={}
__WXML_GLOBAL__.ops_cached = __WXML_GLOBAL__.ops_cached || {}
__WXML_GLOBAL__.ops_set = __WXML_GLOBAL__.ops_set || {};
__WXML_GLOBAL__.ops_init = __WXML_GLOBAL__.ops_init || {};
var z=__WXML_GLOBAL__.ops_set.$gwx_XC_25 || [];
function gz$gwx_XC_25_1(){
if( __WXML_GLOBAL__.ops_cached.$gwx_XC_25_1)return __WXML_GLOBAL__.ops_cached.$gwx_XC_25_1
__WXML_GLOBAL__.ops_cached.$gwx_XC_25_1=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
Z([[7],[3,'addtip']])
Z([3,'closeAddTipNoticeBar'])
Z([3,'volume-o'])
Z([3,'closeable'])
Z([1,true])
Z(z[0])
Z([3,'dialogGetQr'])
Z(z[6])
Z([3,'#576b95'])
Z([3,'普通二维码'])
Z(z[4])
Z([3,'#07c160'])
Z([3,'圆形码'])
Z([3,'即将生成该文件二维码并保存到手机相册，请选择类型？（点击遮罩可取消）'])
Z(z[4])
Z([[7],[3,'showDialog']])
Z([3,'选择二维码类型'])
Z([[2,'&&'],[[7],[3,'userInfo']],[[6],[[7],[3,'userInfo']],[3,'superAuth']]])
Z([3,'padding: 0 32rpx;margin-bottom: 10rpx;margin-top: 10rpx;'])
Z([1,500])
Z([3,'fade-up'])
Z([[2,'!'],[[7],[3,'showSearch']]])
Z([3,'showSearch'])
Z([3,'search'])
Z([3,'46rpx'])
Z([3,'color: #969799;font-size: 30rpx;display:flex;justify-content:flex-start;align-items:center;'])
Z([3,'toQuestion'])
Z(z[8])
Z([3,'question-o'])
Z([3,'42rpx'])
Z([3,'margin-left: 28rpx;color: #576b95;font-weight: 500;'])
Z([3,'toRecycle'])
Z([3,'my-icon'])
Z(z[8])
Z([3,'recycle'])
Z(z[29])
Z(z[30])
Z([3,'toNotice'])
Z(z[32])
Z([3,'tongzhi'])
Z([3,'38rpx'])
Z(z[30])
Z(z[19])
Z([3,'fade-down'])
Z([[7],[3,'showSearch']])
Z([[7],[3,'pageList']])
Z([3,'onSearchCancel'])
Z([3,'onSearchChange'])
Z([3,'onSearch'])
Z([[2,'||'],[[7],[3,'showEdit']],[[7],[3,'showOriginUrlPopup']]])
Z([3,'搜索我添加的文件'])
Z([3,'round'])
Z([[7],[3,'searchKey']])
Z([[2,'&&'],[[7],[3,'pageList']],[[2,'=='],[[6],[[7],[3,'pageList']],[3,'length']],[1,0]]])
Z([[7],[3,'openid']])
Z([3,'chooseFile'])
Z(z[32])
Z(z[11])
Z([3,'shangchuan'])
Z([3,'110rpx'])
Z([3,'position:fixed;right:40rpx;bottom:40rpx;height:120rpx;width:120rpx;background-color: #ffffff;border-radius: 50%;'])
Z([3,'showPopupAfter'])
Z([3,'onClosePopup'])
Z([3,'height:90%;'])
Z([3,'bottom'])
Z([[7],[3,'showEdit']])
Z([3,'writeView'])
Z(z[62])
Z([3,'cross'])
Z([3,'36rpx'])
Z([3,'padding:6rpx;'])
Z([[7],[3,'showPopupTextarea']])
Z([[12],[[6],[[7],[3,'myutil']],[3,'canOpen']],[[5],[[7],[3,'fileID']]]])
Z([[4],[[5],[[5],[[5],[[5],[1,1]],[1,2]],[1,3]],[1,4]]])
Z([3,'_id'])
Z([3,'width:100%;box-sizing:border-box;'])
Z([[2,'!'],[[7],[3,'pageList']]])
Z([[2,'<'],[[7],[3,'index']],[1,3]])
Z(z[45])
Z(z[74])
Z(z[75])
Z([3,'showActionSheet'])
Z([3,'activeEnd'])
Z([3,'activeStart'])
Z([[2,'?:'],[[2,'=='],[[7],[3,'currentItemId']],[[6],[[7],[3,'item']],[3,'_id']]],[1,'actived-item'],[1,'']])
Z([[6],[[7],[3,'item']],[3,'_id']])
Z([[7],[3,'index']])
Z([3,'padding:16rpx 32rpx 16rpx 24rpx;display:flex;justify-content:flex-start;box-sizing:border-box;'])
Z([3,'calcTypeImgFontScale'])
Z(z[86])
Z([[2,'?:'],[[2,'&&'],[[6],[[7],[3,'item']],[3,'pwd']],[[6],[[7],[3,'item']],[3,'readOnly']]],[1,true],[1,false]])
Z(z[4])
Z([[6],[[7],[3,'item']],[3,'typeImg']])
Z([a,[3,'height: '],[[7],[3,'typeImgWidth']],[3,'rpx;width: '],[[7],[3,'typeImgWidth']],[3,'rpx;position: relative;']])
Z([[2,'||'],[[6],[[7],[3,'item']],[3,'pwd']],[[6],[[7],[3,'item']],[3,'readOnly']]])
Z([a,[3,'typeImgFont_'],z[86]])
Z([a,[3,'font-size:14rpx;color: #ffffff;transform-origin: 50% 100%;transform: scale('],[[7],[3,'typeImgFontScale']],[3,');']])
Z([[6],[[7],[3,'item']],[3,'pwd']])
Z([[2,'&&'],[[6],[[7],[3,'item']],[3,'pwd']],[[6],[[7],[3,'item']],[3,'readOnly']]])
Z([[6],[[7],[3,'item']],[3,'readOnly']])
Z([[2,'>'],[[6],[[7],[3,'pageList']],[3,'length']],[[2,'+'],[[7],[3,'index']],[1,1]]])
Z([[2,'&&'],[[7],[3,'allShow']],[[2,'>'],[[7],[3,'pageNum']],[1,1]]])
Z([3,'center'])
Z([3,'border:0;'])
Z([[2,'&&'],[[7],[3,'pageList']],[[7],[3,'loadTitle']]])
Z(z[102])
Z(z[103])
Z([[7],[3,'dealActions']])
Z([3,'onCloseActionSheet'])
Z(z[108])
Z([3,'onSelect'])
Z([3,'取消'])
Z([[6],[[7],[3,'selectMsgInfo']],[3,'name']])
Z([[7],[3,'showDeal']])
Z([3,'0'])
Z([[7],[3,'showOverlay']])
Z([3,'wrapper'])
Z(z[11])
Z([3,'130'])
Z([3,'500'])
Z([[7],[3,'rate']])
Z([3,'cancelUpload'])
Z(z[68])
Z([3,'small'])
Z([3,'default'])
Z([3,'clickAgree'])
Z([3,'getPhoneNumber'])
Z(z[111])
Z(z[11])
Z([[2,'?:'],[[7],[3,'clickAgree']],[1,'getPhoneNumber'],[1,'']])
Z([3,'确定'])
Z([[7],[3,'showPhone']])
Z([3,'绑定手机号'])
Z([3,'myPrivacy'])
})(__WXML_GLOBAL__.ops_cached.$gwx_XC_25_1);return __WXML_GLOBAL__.ops_cached.$gwx_XC_25_1
}
__WXML_GLOBAL__.ops_set.$gwx_XC_25=z;
__WXML_GLOBAL__.ops_init.$gwx_XC_25=true;
var x=['./pages/file/cloudFile/index.wxml'];d_[x[0]]={}
var m0=function(e,s,r,gg){
var z=gz$gwx_XC_25_1()
var ePF=_v()
_(r,ePF)
if(_oz(z,0,e,s,gg)){ePF.wxVkey=1
var bQF=_mz(z,'van-notice-bar',['bind:close',1,'leftIcon',1,'mode',2,'scrollable',3,'text',4],[],e,s,gg)
_(ePF,bQF)
}
var oRF=_mz(z,'van-dialog',['showCancelButton',-1,'showConfirmButton',-1,'bind:cancel',6,'bind:confirm',1,'cancelButtonColor',2,'cancelButtonText',3,'closeOnClickOverlay',4,'confirmButtonColor',5,'confirmButtonText',6,'message',7,'overlay',8,'show',9,'title',10],[],e,s,gg)
_(r,oRF)
var xSF=_n('view')
var oTF=_v()
_(xSF,oTF)
if(_oz(z,17,e,s,gg)){oTF.wxVkey=1
}
var fUF=_n('view')
_rz(z,fUF,'style',18,e,s,gg)
var cVF=_mz(z,'van-transition',['duration',19,'name',1,'show',2],[],e,s,gg)
var hWF=_mz(z,'van-icon',['bindtap',22,'name',1,'size',2],[],e,s,gg)
_(cVF,hWF)
_(fUF,cVF)
var oXF=_n('view')
_rz(z,oXF,'style',25,e,s,gg)
var cYF=_mz(z,'van-icon',['bind:click',26,'color',1,'name',2,'size',3,'style',4],[],e,s,gg)
_(oXF,cYF)
var oZF=_mz(z,'van-icon',['bind:click',31,'classPrefix',1,'color',2,'name',3,'size',4,'style',5],[],e,s,gg)
_(oXF,oZF)
var l1F=_mz(z,'van-icon',['bindtap',37,'classPrefix',1,'name',2,'size',3,'style',4],[],e,s,gg)
_(oXF,l1F)
_(fUF,oXF)
_(xSF,fUF)
var a2F=_n('view')
var x7F=_mz(z,'van-transition',['duration',42,'name',1,'show',2],[],e,s,gg)
var o8F=_v()
_(x7F,o8F)
if(_oz(z,45,e,s,gg)){o8F.wxVkey=1
var f9F=_mz(z,'van-search',['showAction',-1,'bind:cancel',46,'bind:change',1,'bind:search',2,'disabled',3,'placeholder',4,'shape',5,'value',6],[],e,s,gg)
_(o8F,f9F)
}
o8F.wxXCkey=1
o8F.wxXCkey=3
_(a2F,x7F)
var t3F=_v()
_(a2F,t3F)
if(_oz(z,53,e,s,gg)){t3F.wxVkey=1
}
var e4F=_v()
_(a2F,e4F)
if(_oz(z,54,e,s,gg)){e4F.wxVkey=1
var c0F=_mz(z,'van-icon',['bindtap',55,'classPrefix',1,'color',2,'name',3,'size',4,'style',5],[],e,s,gg)
_(e4F,c0F)
}
var hAG=_mz(z,'van-popup',['round',-1,'bind:after-enter',61,'bind:close',1,'customStyle',2,'position',3,'show',4],[],e,s,gg)
var oBG=_n('view')
_rz(z,oBG,'class',66,e,s,gg)
var lEG=_mz(z,'van-icon',['bindtap',67,'name',1,'size',2,'style',3],[],e,s,gg)
_(oBG,lEG)
var cCG=_v()
_(oBG,cCG)
if(_oz(z,71,e,s,gg)){cCG.wxVkey=1
}
var oDG=_v()
_(oBG,oDG)
if(_oz(z,72,e,s,gg)){oDG.wxVkey=1
}
cCG.wxXCkey=1
oDG.wxXCkey=1
_(hAG,oBG)
_(a2F,hAG)
var aFG=_v()
_(a2F,aFG)
var tGG=function(bIG,eHG,oJG,gg){
var oLG=_v()
_(oJG,oLG)
if(_oz(z,76,bIG,eHG,gg)){oLG.wxVkey=1
var fMG=_v()
_(oLG,fMG)
if(_oz(z,77,bIG,eHG,gg)){fMG.wxVkey=1
}
fMG.wxXCkey=1
}
oLG.wxXCkey=1
return oJG
}
aFG.wxXCkey=2
_2z(z,73,tGG,e,s,gg,aFG,'item','index','_id')
var cNG=_v()
_(a2F,cNG)
var hOG=function(cQG,oPG,oRG,gg){
var tUG=_mz(z,'view',['bindtap',81,'bindtouchend',1,'bindtouchstart',2,'class',3,'data-id',4,'data-index',5,'style',6],[],cQG,oPG,gg)
var eVG=_mz(z,'image',['bindload',88,'data-index',1,'data-need',2,'lazyLoad',3,'src',4,'style',5],[],cQG,oPG,gg)
var bWG=_v()
_(eVG,bWG)
if(_oz(z,94,cQG,oPG,gg)){bWG.wxVkey=1
var oXG=_mz(z,'view',['id',95,'style',1],[],cQG,oPG,gg)
var xYG=_v()
_(oXG,xYG)
if(_oz(z,97,cQG,oPG,gg)){xYG.wxVkey=1
}
var oZG=_v()
_(oXG,oZG)
if(_oz(z,98,cQG,oPG,gg)){oZG.wxVkey=1
}
var f1G=_v()
_(oXG,f1G)
if(_oz(z,99,cQG,oPG,gg)){f1G.wxVkey=1
}
xYG.wxXCkey=1
oZG.wxXCkey=1
f1G.wxXCkey=1
_(bWG,oXG)
}
bWG.wxXCkey=1
_(tUG,eVG)
_(oRG,tUG)
var aTG=_v()
_(oRG,aTG)
if(_oz(z,100,cQG,oPG,gg)){aTG.wxVkey=1
}
aTG.wxXCkey=1
return oRG
}
cNG.wxXCkey=2
_2z(z,78,hOG,e,s,gg,cNG,'item','index','_id')
var b5F=_v()
_(a2F,b5F)
if(_oz(z,101,e,s,gg)){b5F.wxVkey=1
var c2G=_mz(z,'van-divider',['dashed',-1,'contentPosition',102,'customStyle',1],[],e,s,gg)
_(b5F,c2G)
}
var o6F=_v()
_(a2F,o6F)
if(_oz(z,104,e,s,gg)){o6F.wxVkey=1
var h3G=_mz(z,'van-divider',['dashed',-1,'contentPosition',105,'customStyle',1],[],e,s,gg)
_(o6F,h3G)
}
var o4G=_mz(z,'van-action-sheet',['actions',107,'bind:cancel',1,'bind:close',2,'bind:select',3,'cancelText',4,'description',5,'show',6],[],e,s,gg)
_(a2F,o4G)
t3F.wxXCkey=1
e4F.wxXCkey=1
e4F.wxXCkey=3
b5F.wxXCkey=1
b5F.wxXCkey=3
o6F.wxXCkey=1
o6F.wxXCkey=3
_(xSF,a2F)
var c5G=_mz(z,'van-overlay',['duration',114,'show',1],[],e,s,gg)
var o6G=_n('view')
_rz(z,o6G,'class',116,e,s,gg)
var l7G=_mz(z,'van-circle',['color',117,'size',1,'speed',2,'value',3],[],e,s,gg)
_(o6G,l7G)
var a8G=_mz(z,'van-button',['round',-1,'bindtap',121,'icon',1,'size',2,'type',3],[],e,s,gg)
_(o6G,a8G)
_(c5G,o6G)
_(xSF,c5G)
var t9G=_mz(z,'van-dialog',['showCancelButton',-1,'useSlot',-1,'bind:confirm',125,'bind:getphonenumber',1,'cancelButtonText',2,'confirmButtonColor',3,'confirmButtonOpenType',4,'confirmButtonText',5,'show',6,'title',7],[],e,s,gg)
_(xSF,t9G)
oTF.wxXCkey=1
_(r,xSF)
var e0G=_n('my-privacy')
_rz(z,e0G,'id',133,e,s,gg)
_(r,e0G)
ePF.wxXCkey=1
ePF.wxXCkey=3
return r
}
e_[x[0]]={f:m0,j:[],i:[],ti:[],ic:[]}
if(path&&e_[path]){
return function(env,dd,global){$gwxc=0;var root={"tag":"wx-page"};root.children=[]
;g="$gwx_XC_25";var main=e_[path].f
if (typeof global==="undefined")global={};global.f=$gdc(f_[path],"",1);
try{
main(env,{},root,global);
_tsd(root)
}catch(err){
console.log(err)
}
;g="";
return root;
}
}
}
}(__g.a,__g.b,__g.c,__g.d,__g.e,__g.f,__g.g,__g.h,__g.i,__g.j,__g.k,__g.l,__g.m,__g.n,__g.o,__g.p,__g.q,__g.r,__g.s,__g.t,__g.u,__g.v,__g.w,__g.x,__g.y,__g.z,__g.A,__g.B,__g.C,__g.D,__g.E,__g.F,__g.G,__g.H,__g.I,__g.J,__g.K,__g.L,__g.M,__g.N,__g.O,__g.P,__g.Q,__g.R,__g.S,__g.T,__g.U,__g.V,__g.W,__g.X,__g.Y,__g.Z,__g.aa);if(__vd_version_info__.delayedGwx||false)$gwx_XC_25();	if (__vd_version_info__.delayedGwx) __wxAppCode__['pages/file/cloudFile/index.wxml'] = [$gwx_XC_25, './pages/file/cloudFile/index.wxml'];else __wxAppCode__['pages/file/cloudFile/index.wxml'] = $gwx_XC_25( './pages/file/cloudFile/index.wxml' );
	;__wxRoute = "pages/file/cloudFile/index";__wxRouteBegin = true;__wxAppCurrentFile__="pages/file/cloudFile/index.js";define("pages/file/cloudFile/index.js",function(require,module,exports,window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){
"use strict";var e=require("../../../@babel/runtime/helpers/typeof");wx.cloud.init();var t=wx.cloud.database(),a=t.command,o=t.collection("files"),n=t.collection("msg_user"),i=t.collection("user_inc_id"),s=require("../../../components/cos/cos-wx-sdk-v5.min"),c=void 0,d=void 0;Page({data:{parasitifer:"",showSearch:!1,showPhone:!1,showDialog:!1,showOriginUrlPopup:!1,showOriginUrlPopupTextarea:!1,originUrlPopupTextareaFocus:!1,webviewBack:!1,extension:["doc","docx","xls","xlsx","ppt","pptx","pdf","txt","zip","rar","7z","mp3","mid","wav","wma","DOC","DOCX","XLS","XLSX","PPT","PPTX","PDF","TXT","ZIP","RAR","7Z","MP3","MID","WAV","WMA"],showOverlay:!1,rate:0,openid:"",loadTitle:"",currentItemId:"",src:"",showPopupTextarea:!1,focus:!1,pageNum:1,pageSize:20,allShow:!1,showEdit:!1,showDeal:!1,_index:0,_id:"",msgName:"",msgID:"",pwd:"",source:"",readOnly:!1,pageList:null,msgPopTitle:"文件设置",selectMsgInfo:{},dealActions:[{name:"查看",index:0},{name:"设置(名字/简介/密码/只读)",index:1},{name:"修改(替换)文件",index:6},{name:"复制路径",index:2,className:"important-action"},{name:"复制快捷粘贴",index:12,className:"important-action"},{name:"海报",index:10},{name:"二维码",index:7},{name:"复制自动回复",index:11},{name:"删除",index:4,color:"red"}],userInfo:void 0,searchKey:"",systemInfo:{},addtip:"",clickAgree:!1,typeImgWidth:90,typeImgInnerWidth:0,need:!0,typeImgFontScale:1},toNotice:function(){var e="/pages/webview/webview?url="+encodeURIComponent("https://zhijiebohao-4gp9aizse6797bd3-1257150849.tcloudbaseapp.com/gzh.html?miniAppId=wx5c9674e6177b0f6a&miniEnvId=zhijiebohao-4gp9aizse6797bd3&authorized="+(!(!this.data.userInfo||!this.data.userInfo.xzffw_openid)||"")+"&type=file");wx.navigateTo({url:e})},toRecycle:function(){this.setData({webviewBack:!0}),wx.navigateTo({url:"/vantPage/recycle/recycle"})},clickAgreeChange:function(e){this.setData({clickAgree:!this.data.clickAgree})},closeAddTipNoticeBar:function(){var e=this;n.doc(e.data.userInfo._id).update({data:{addTipShowed:!0},success:function(t){e.setData({addtip:""})}})},showSearch:function(){this.setData({showSearch:!0})},showProtocol:function(){wx.navigateTo({url:"/pages/methodD/methodD?id=18"})},showPrivacy:function(){wx.navigateTo({url:"/pages/methodD/methodD?id=19"})},delRec:function(){wx.navigateTo({url:"/pages/webview/webview?url=https://bohao.wsqytec.com/delRecovery.html"})},showOriginUrlPopup:function(){this.setData({showOriginUrlPopup:!0})},showOriginUrlPopupAfter:function(){var e=this;e.setData({showOriginUrlPopupTextarea:!0},(function(){e.setData({originUrlPopupTextareaFocus:!0})}))},onCloseOriginUrlPopup:function(){this.setData({showOriginUrlPopup:!1,showOriginUrlPopupTextarea:!1,originUrlPopupTextareaFocus:!1})},originUrlChange:function(e){var t=this.data.selectMsgInfo;t.originUrl=e.detail.value,this.setData({selectMsgInfo:t})},onSubmitOriginUrl:function(){var e=this,t=e.data.selectMsgInfo,a=t.originUrl;a||(a=""),""==(a=a.replace(/\s*/g,""))||0==a.indexOf("https://mp.weixin.qq.com/s/")?o.doc(t._id).update({data:{originUrl:a},success:function(a){var o=e.data.pageList;o[e.data._index]=t,e.setData({pageList:o}),e.onCloseOriginUrlPopup(),wx.showToast({title:"保存成功！",icon:"none"})}}):wx.showToast({title:"请粘贴文章的原始链接！",icon:"none",duration:3e3})},howToRelative:function(){wx.navigateTo({url:"/pages/methodD/methodD?id=12"})},howToGetUrl:function(){wx.navigateTo({url:"/pages/methodD/methodD?id=13"})},buy:function(){wx.navigateTo({url:"/pages/methodD/methodD?id=6"})},addFileData:function(e,t,a,n,i,s){var c=this;o.add({data:{_id:e,name:t,size:a,fileID:n,createTime:i,readCount:0,downloadCount:0,msgID:"",pwd:"",source:"",readOnly:!1,unionid:s,del_flag:!1}}).then((function(e){c.getData(!0),c.setData({showOverlay:!1,rate:0}),wx.showToast({title:"保存成功",icon:"none"}),e._id&&wx.cloud.callFunction({name:"addIpProvince",data:{db:"files",id:e._id}})}))},toQuestion:function(){wx.navigateTo({url:"/vantPage/question/question?type=0"})},initCOS:function(){wx.cloud.callFunction({name:"cosSts",complete:function(e){c=new s({getAuthorization:function(t,a){a({TmpSecretId:e.result.credentials.tmpSecretId,TmpSecretKey:e.result.credentials.tmpSecretKey,SecurityToken:e.result.credentials.sessionToken,StartTime:e.result.startTime,ExpiredTime:e.result.expiredTime})}})}})},chooseFileUploadDo:function(e,t){var a=this,n=52428800,i="单个文件大小限制：50M！";if(a.data.userInfo&&a.data.userInfo.isGov&&(n*=4,i="单个文件大小限制：200M！"),t.size>n)wx.showToast({title:i,icon:"none",duration:3e3});else if(0!=t.size){var s=a.data.extension,r=t.name.lastIndexOf("."),l=t.name.substr(r+1);if(s.indexOf(l)<0)wx.showToast({title:"限制格式："+s.join(", ")+"!",icon:"none",duration:3e3});else{wx.showLoading({title:"名字检测中",mask:!0});var u=a.getUUID();wx.cloud.callFunction({name:"msgSecCheck",data:{content:t.name,type:"files",id:e&&e.currentTarget?u:e||""}}).then((function(n){if(wx.hideLoading(),0==n.result.errCode){a.setData({showOverlay:!0});var i="file/"+a.data.openid+"/"+u+"."+l;c.uploadFile({Bucket:"lg-h5g2gu1y-1257150849",Region:"ap-shanghai",Key:i,FilePath:t.path,FileSize:t.size,SliceSize:5242880,onTaskReady:function(e){d=e},onProgress:function(e){a.setData({rate:(100*e.percent).toFixed(1)})}},(function(n,i){if(i){d=void 0;var s=a.renderSize(t.size),c=a.formatTime(new Date);e&&e.currentTarget?a.addFileData(u,t.name,s,i.Location.replace("lg-h5g2gu1y-1257150849.cos.ap-shanghai.myqcloud.com","cos.wsqytec.com"),c,a.data.userInfo.unionid?a.data.userInfo.unionid:a.data.userInfo.reAuth.unionid):e&&(u=e,o.doc(u).update({data:{name:t.name,size:s,fileID:i.Location.replace("lg-h5g2gu1y-1257150849.cos.ap-shanghai.myqcloud.com","cos.wsqytec.com")},success:function(e){var o=a.data.selectMsgInfo;o.name=t.name,o.size=s,o.fileID=i.Location.replace("lg-h5g2gu1y-1257150849.cos.ap-shanghai.myqcloud.com","cos.wsqytec.com");var n=a.data.pageList;n[a.data._index]=o,a.setData({pageList:n}),a.onClosePopup(),a.setData({showOverlay:!1,rate:0}),wx.showToast({title:"替换保存成功",icon:"none"})}}))}else a.cancelUpload(null,"上传失败，网络异常！"),a.initCOS()}))}else wx.showToast({title:"名字存在违法违规风险，请重新上传！",icon:"none",duration:3e3})}))}}else wx.showToast({title:"不支持上传空文件",icon:"none",duration:3e3})},cancelUpload:function(e,t){var a=this;if(d){c.cancelTask(d),d=void 0;var o=setTimeout((function(){a.setData({showOverlay:!1,rate:0},(function(){clearTimeout(o),wx.showToast({title:t||"已取消",icon:"none"})}))}),500)}},chooseFile:function(e){var t=this,a="windows"==t.data.systemInfo.platform||"mac"==t.data.systemInfo.platform;if(a||!t.data.parasitifer||"微信"==t.data.parasitifer)if(t.data.userInfo.phone&&t.data.userInfo.agreeProtocol)if(a){t.setData({webviewBack:!0});var o="https://zhijiebohao-4gp9aizse6797bd3-1257150849.tcloudbaseapp.com/uploadByCosUrlWithStaticWeb-v1.html?miniAppId=wx5c9674e6177b0f6a&miniEnvId=zhijiebohao-4gp9aizse6797bd3&tabPage=/pages/file/cloudFile/index&openId="+t.data.openid+"&updateId="+(e&&e.currentTarget?"":e.id)+"&updateName="+(e&&e.currentTarget?"":e.name);wx.navigateTo({url:"/pages/webview/webview?url="+encodeURIComponent(o)})}else wx.chooseMessageFile({count:1,type:"file",extension:t.data.extension,success:function(a){var o=a.tempFiles[0];t.chooseFileUploadDo(e&&e.currentTarget?e:e.id,o)},fail:function(e){}});else t.setData({showPhone:!0});else wx.showToast({title:"不支持在"+t.data.parasitifer+"中上传，请发送分享到微信中使用！",icon:"none"})},activeStart:function(e){this.setData({currentItemId:e.currentTarget.dataset.id})},activeEnd:function(){this.setData({currentItemId:""})},onSearchChange:function(e){this.setData({searchKey:e.detail})},onSearch:function(){this.getData(!0)},onSearchCancel:function(){this.setData({searchKey:"",showSearch:!1}),this.getData(!0)},inputMsgName:function(e){this.setData({msgName:e.detail.value})},inputMsgID:function(e){this.setData({msgID:e.detail.value})},inputPwd:function(e){this.setData({pwd:e.detail.value})},readOnlyChange:function(e){this.setData({readOnly:e.detail.value})},inputSource:function(e){this.setData({source:e.detail.value})},onSubmit:function(){var e=this;e.data.msgName?(wx.showLoading({title:"名字检测中",mask:!0}),wx.cloud.callFunction({name:"msgSecCheck",data:{content:e.data.msgName+e.data.msgID+e.data.source,type:"files",id:e.data._id}}).then((function(t){wx.hideLoading(),0==t.result.errCode?e.onSubmitDo():wx.showToast({title:"名字存在违法违规风险，请重新输入！",icon:"none",duration:3e3})}))):wx.showToast({title:"请输入文件名字！",icon:"none"})},onSubmitDo:function(){var e=this;o.doc(e.data._id).update({data:{name:e.data.msgName,msgID:e.data.msgID,pwd:e.data.pwd,source:e.data.source,readOnly:e.data.readOnly},success:function(t){var a=e.data.selectMsgInfo;a.name=e.data.msgName,a.msgID=e.data.msgID,a.pwd=e.data.pwd,a.source=e.data.source,a.readOnly=e.data.readOnly;var o=e.data.pageList;o[e.data._index]=a,e.setData({pageList:o},(function(){a.pwd&&a.readOnly&&e.resetTypeImgFontScale(e.data._index,e.data.typeImgInnerWidth,e.data.typeImgFontScale)})),e.onClosePopup(),wx.showToast({title:"修改成功",icon:"none"})}})},getData:function(e){var t=this;wx.stopPullDownRefresh();var a="加载中...";e&&(a="刷新中...",this.setData({pageNum:1,allShow:!1})),wx.showNavigationBarLoading&&wx.showNavigationBarLoading(),this.setData({loadTitle:a}),wx.cloud.callFunction({name:"getFileData",data:{id:null,pageNum:this.data.pageNum,pageSize:this.data.pageSize,searchKey:this.data.searchKey}}).then((function(a){if(wx.hideNavigationBarLoading&&wx.hideNavigationBarLoading(),0==a.result.data.length&&t.setData({allShow:!0}),a.result.data.map((function(e){return e.typeImg=t.judgeTypeImg(e.fileID),e})),e)t.setData({pageList:a.result.data});else{var o=[];t.data.pageList&&(o=t.data.pageList),t.setData({pageList:o.concat(a.result.data)})}t.setData({loadTitle:""})}))},onReachBottom:function(){this.data.allShow||(this.setData({pageNum:this.data.pageNum+1}),this.getData())},showPopupAfter:function(){var e=this;e.setData({showPopupTextarea:!0},(function(){e.setData({focus:!0})}))},showPopup:function(){this.setData({showEdit:!0})},showActionSheet:function(e){var t=this.data.pageList[e.currentTarget.dataset.index];"loading"!=t._id&&this.setData({showDeal:!0,selectMsgInfo:JSON.parse(JSON.stringify(t)),_index:e.currentTarget.dataset.index})},showExample:function(e){wx.navigateTo({url:"/file/down?id="+e.currentTarget.dataset.id})},onClosePopup:function(){var e=this;e.setData({showEdit:!1,focus:!1}),setTimeout((function(){e.setData({msgName:"",_id:"",msgID:"",pwd:"",source:"",readOnly:!1,msgPopTitle:"文件设置"})}),500)},onCloseActionSheet:function(){this.setData({showDeal:!1})},onSelect:function(e){var t=this;switch(e.detail.index){case 12:"windows"==t.data.systemInfo.platform||"mac"==t.data.systemInfo.platform?wx.navigateTo({url:"/pages/webview/webview?url="+encodeURIComponent("https://zhijiebohao-4gp9aizse6797bd3-1257150849.tcloudbaseapp.com/copyToEditor.html?appId=wx5c9674e6177b0f6a&name="+encodeURIComponent(t.data.selectMsgInfo.name)+"&path="+encodeURIComponent("file/down?id="+t.data.selectMsgInfo._id))}):wx.showToast({title:"此功能仅支持在电脑端小程序中使用",icon:"none",duration:3e3});break;case 0:wx.navigateTo({url:"/file/down?id="+t.data.selectMsgInfo._id});break;case 1:t.setData({msgName:t.data.selectMsgInfo.name,_id:t.data.selectMsgInfo._id,fileID:t.data.selectMsgInfo.fileID,msgID:t.data.selectMsgInfo.msgID,pwd:t.data.selectMsgInfo.pwd,source:t.data.selectMsgInfo.source,readOnly:t.data.selectMsgInfo.readOnly,msgPopTitle:"文件设置"}),t.showPopup();break;case 2:wx.setClipboardData({data:"file/down?id="+t.data.selectMsgInfo._id,success:function(){wx.hideLoading(),wx.showToast({title:"路径复制成功",icon:"none"})}});break;case 6:t.chooseFile({id:t.data.selectMsgInfo._id,name:t.data.selectMsgInfo.name});break;case 3:break;case 10:wx.setStorageSync("full_info_"+t.data.selectMsgInfo._id,JSON.stringify(t.data.selectMsgInfo)),wx.navigateTo({url:"/vantPage/filePoster/filePoster?id="+t.data.selectMsgInfo._id});break;case 7:t.setData({showDialog:!0});break;case 4:wx.showModal({title:"确定要删除该文件吗？",content:"【特别注意】如果文件已添加到文章或菜单等地方，删除后读者将无法查看！",success:function(e){e.confirm&&o.doc(t.data.selectMsgInfo._id).update({data:{del_flag:!0,delTime:new Date},success:function(e){var a=t.data.pageList;a.splice(t.data._index,1),t.setData({pageList:a}),wx.showToast({title:"删除成功",icon:"none"})}})}});break;case 5:break;case 9:t.showOriginUrlPopup();break;case 11:var a=t.data.selectMsgInfo,n="/file/down?id="+a._id,i="https://bohao.wsqytec.com/f.html?id="+a._id,s=a.name,c='<a data-miniprogram-appid="autoMsgAppId" data-miniprogram-path="autoMsgPath" data-miniprogram-type="text" href="autoWebsite">autoMsgContent</a>'.replace(new RegExp("autoMsgAppId","g"),"wx5c9674e6177b0f6a").replace(new RegExp("autoMsgPath","g"),n).replace(new RegExp("autoWebsite","g"),i).replace(new RegExp("autoMsgContent","g"),s);wx.setClipboardData({data:c,success:function(){wx.hideLoading(),wx.showToast({title:"自动回复内容复制成功，请先确保已关联小程序小正方助手",icon:"none"})}})}},dialogGetQr:function(e){"confirm"==e.type?this.getQr():(e.type="cancel")&&this.getQr("old")},getQr:function(e){var t=this;wx.showLoading({title:"生成中",mask:!0});var a={scene:t.data.selectMsgInfo._id,page:"file/down"};e&&"old"==e&&(a={type:e,content:"https://bohao.wsqytec.com/f.html?id="+t.data.selectMsgInfo._id}),wx.cloud.callFunction({name:"getUnlimitedCode",data:a,success:function(a){if(wx.hideLoading(),0==a.result.errCode){var o=wx.getFileSystemManager(),n=wx.env.USER_DATA_PATH+"/"+(e?e+"qr":"wxacode")+".png";o.writeFile({filePath:n,data:a.result.buffer,encoding:"binary",success:function(){t.setData({src:n},(function(){t.savedownloadFile()}))}})}else wx.showToast({title:"网络异常，请稍后重试。",icon:"none",mask:!0})},fail:function(){wx.hideLoading(),wx.showToast({title:"网络异常，请稍后重试。",icon:"none",mask:!0})}})},onShow:function(){this.data.webviewBack&&(this.getData(!0),this.setData({webviewBack:!1}));var e=wx.getEnterOptionsSync();if(1173==e.scene){var t=e.forwardMaterials;t&&t.length>0&&wx.showToast({title:"点击右下角“↑”按钮选择聊天文件上传",icon:"none",duration:3500})}},isForbid:function(){wx.showModal({title:"封禁文件",editable:!0,placeholderText:"请您输入文件路径",success:function(e){if(e.confirm)if(e.content){var t=e.content.split("id=");if(t&&2==t.length){var a=t[1];o.doc(a).update({data:{isForbid:!0},success:function(e){wx.showToast({title:"封禁成功",icon:"none"})}})}else wx.showToast({title:"路径错误",icon:"none"})}else wx.showToast({title:"错误,必须填写文件路径",icon:"none"})}})},isGov:function(){wx.showModal({title:"免广告设置",editable:!0,placeholderText:"请您输入文件路径",success:function(e){if(e.confirm)if(e.content){var t=e.content.split("id=");if(t&&2==t.length){var a=t[1];o.doc(a).update({data:{isGov:!0},success:function(e){wx.showToast({title:"免广告成功",icon:"none"})}})}else wx.showToast({title:"路径错误",icon:"none"})}else wx.showToast({title:"错误,必须填写文件路径",icon:"none"})}})},resetTypeImgFontScale:function(e,t,a){var o=this;try{wx.createSelectorQuery().select("#typeImgFont_"+e).boundingClientRect((function(n){var i=a-.05;n&&n.width>t&&i>.5&&o.setData({typeImgFontScale:i},(function(){o.resetTypeImgFontScale(e,t,i)}))})).exec()}catch(e){}},calcTypeImgFontScale:function(e){var t=this;if(0!=t.data.typeImgInnerWidth){if(t.data.need&&e.currentTarget.dataset.need){var a=e.currentTarget.dataset.index;t.resetTypeImgFontScale(a,t.data.typeImgInnerWidth,t.data.typeImgFontScale),t.setData({need:!1})}}else var o=setTimeout((function(){t.calcTypeImgFontScale(e),clearTimeout(o)}),100)},onLoad:function(e){var t=this,o=wx.getSystemInfoSync();t.setData({systemInfo:o,typeImgInnerWidth:o.windowWidth/750*t.data.typeImgWidth*(23/30)-2}),t.getParasitifer(),wx.cloud.callFunction({name:"login",complete:function(e){var o=e.result;t.setData({openid:o.openid,userInfo:o}),t.initCOS(),o.addTipShowed||i.where({_id:a.eq("addtip")}).field({text:!0}).get({success:function(e){if(e&&e.data.length>0){var a=e.data[0];t.setData({addtip:a.text})}}})}}),e.fileID?t.addFileData(e.id,decodeURIComponent(e.name),t.renderSize(e.size),decodeURIComponent(e.fileID),t.formatTime(new Date),e.unionid):t.getData()},getParasitifer:function(){var e=this.data.systemInfo,t="微信";if(e&&e.host&&e.host.appId)switch(e.host.appId){case"wxf0a80d0ac2e82aa7":t="QQ";break;case"wx4706a9fcbbca10f2":t="企业微信";break;case"wx64f9cf5b17af074d":t="QQ浏览器";break;case"wx5cd60c5d4817a188":t="电脑管家";break;default:t="微信"}this.setData({parasitifer:t})},onPageScroll:function(e){e.scrollTop>200&&"云上文件"!=this.navTitle?(this.navTitle="云上文件",wx.setNavigationBarTitle({title:"云上文件"})):e.scrollTop<=200&&"小正方助手"!=this.navTitle&&(this.navTitle="小正方助手",wx.setNavigationBarTitle({title:"小正方助手"}))},clickAgree:function(){if(!this.data.clickAgree)return wx.showToast({title:"请先阅读并勾选文件服务协议",icon:"none"}),void this.setData({showPhone:!0})},getPhoneNumber:function(e){var t=this;wx.hideLoading(),e.detail.cloudID&&(wx.showLoading({title:"获取中",mask:!0}),wx.cloud.callFunction({name:"login",data:{weRunData:wx.cloud.CloudID(e.detail.cloudID),code:!!e.detail.code&&e.detail.code}}).then((function(a){wx.hideLoading();var o=e.detail.code?a.result.phoneInfo.phoneNumber:a.result.event.weRunData.data.phoneNumber;wx.showLoading({title:"绑定中",mask:!0}),n.doc(t.data.userInfo._id).update({data:{phone:o,agreeProtocol:!0},success:function(e){wx.hideLoading();var a=t.data.userInfo;a.phone=o,a.agreeProtocol=!0,t.setData({userInfo:a}),wx.showToast({title:"绑定成功",icon:"none"})}})})))},onPullDownRefresh:function(){this.getData(!0)},onShareAppMessage:function(e){return"button"===e.from?{title:this.data.selectMsgInfo.name,path:"file/down?id="+this.data.selectMsgInfo._id,imageUrl:"cloud://zhijiebohao-4gp9aizse6797bd3.7a68-zhijiebohao-4gp9aizse6797bd3-1257150849/file.png"}:{title:"上传文件，多场景使用",imageUrl:"cloud://zhijiebohao-4gp9aizse6797bd3.7a68-zhijiebohao-4gp9aizse6797bd3-1257150849/file.png"}},showModal:function(){var e=this;wx.showModal({title:"检测到您没有打开保存到相册的权限，是否前往设置打开？",success:function(t){t.confirm?e.onOpenSetting():t.cancel}})},onOpenSetting:function(){var e=this;wx.openSetting({success:function(t){t.authSetting["scope.writePhotosAlbum"]?e.savedownloadFile():wx.showToast({title:"您未授权",icon:"none"})}})},savedownloadFile:function(){var e=this;wx.saveImageToPhotosAlbum({filePath:e.data.src,success:function(e){wx.showToast({title:"保存成功！",icon:"none"})},fail:function(t){(t.errMsg.indexOf("deny")>-1||t.errMsg.indexOf("denied")>-1||t.errMsg.indexOf("auth")>-1)&&e.showModal()}})},renderSize:function(e){if(null==e||""==e||null==e)return"0 Bytes";var t,a=new Array("Bytes","KB","MB","GB","TB","PB","EB","ZB","YB"),o=parseFloat(e);t=Math.floor(Math.log(o)/Math.log(1024));var n=o/Math.pow(1024,t);return(n=n.toFixed(2))+a[t]},judgeTypeImg:function(e){var t="https://cos.wsqytec.com/file_icon/";switch(e.substr(e.lastIndexOf(".")+1).toLowerCase()){case"doc":case"docx":return t+"word.png";case"xls":case"xlsx":return t+"excel.png";case"ppt":case"pptx":return t+"ppt.png";case"pdf":return t+"pdf.png";case"txt":return t+"txt.png";case"mp3":case"mid":case"wav":case"wma":return t+"mp3.png";case"zip":case"rar":case"7z":return t+"file.png";default:return t+"unkown.png"}},formatTime:function(t,a){if(t){switch(a||(a="yyyy-MM-dd HH:mm"),e(t)){case"string":var o=!1;t.indexOf("T")>-1&&t.indexOf("Z")>-1&&(o=!0,t=t.replace(/T/g," ").substring(0,t.lastIndexOf("."))),t=t.replace(/-/g,"/"),t=new Date(t),o&&(t=new Date(t.getTime()+288e5));break;case"number":t=new Date(t)}if(!(!t instanceof Date)){var n={yyyy:t.getFullYear(),M:t.getMonth()+1,d:t.getDate(),H:t.getHours(),m:t.getMinutes(),s:t.getSeconds(),MM:(""+(t.getMonth()+101)).substr(1),dd:(""+(t.getDate()+100)).substr(1),HH:(""+(t.getHours()+100)).substr(1),mm:(""+(t.getMinutes()+100)).substr(1),ss:(""+(t.getSeconds()+100)).substr(1)};return a.replace(/(yyyy|MM?|dd?|HH?|ss?|mm?)/g,(function(){return n[arguments[0]]}))}}},getUUID:function(){for(var e=[],t=0;t<36;t++)e[t]="0123456789abcdef".substr(Math.floor(16*Math.random()),1);return e[14]="4",e[19]="0123456789abcdef".substr(3&e[19]|8,1),e[8]=e[13]=e[18]=e[23]="-",e.join("").replace(new RegExp("-","g"),"")}});
},{isPage:true,isComponent:true,currentFile:'pages/file/cloudFile/index.js'});require("pages/file/cloudFile/index.js");