$gwx_XC_26=function(_,_v,_n,_p,_s,_wp,_wl,$gwn,$gwl,$gwh,wh,$gstack,$gwrt,gra,grb,TestTest,wfor,_ca,_da,_r,_rz,_o,_oz,_1,_1z,_2,_2z,_m,_mz,nv_getDate,nv_getRegExp,nv_console,nv_parseInt,nv_parseFloat,nv_isNaN,nv_isFinite,nv_decodeURI,nv_decodeURIComponent,nv_encodeURI,nv_encodeURIComponent,$gdc,nv_JSON,_af,_gv,_ai,_grp,_gd,_gapi,$ixc,_ic,_w,_ev,_tsd){return function(path,global){
if(typeof global==='undefined'){if (typeof __GWX_GLOBAL__==='undefined')global={};else global=__GWX_GLOBAL__;}if(typeof __WXML_GLOBAL__ === 'undefined') {__WXML_GLOBAL__={};
}__WXML_GLOBAL__.modules = __WXML_GLOBAL__.modules || {};
var e_={}
if(typeof(global.entrys)==='undefined')global.entrys={};e_=global.entrys;
var d_={}
if(typeof(global.defines)==='undefined')global.defines={};d_=global.defines;
var f_={}
if(typeof(global.modules)==='undefined')global.modules={};f_=global.modules || {};
var p_={}
__WXML_GLOBAL__.ops_cached = __WXML_GLOBAL__.ops_cached || {}
__WXML_GLOBAL__.ops_set = __WXML_GLOBAL__.ops_set || {};
__WXML_GLOBAL__.ops_init = __WXML_GLOBAL__.ops_init || {};
var z=__WXML_GLOBAL__.ops_set.$gwx_XC_26 || [];
function gz$gwx_XC_26_1(){
if( __WXML_GLOBAL__.ops_cached.$gwx_XC_26_1)return __WXML_GLOBAL__.ops_cached.$gwx_XC_26_1
__WXML_GLOBAL__.ops_cached.$gwx_XC_26_1=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
Z([3,'padding:0 32rpx;'])
Z([3,'display:flex;align-items:center;justify-content:flex-start;margin-bottom: 26rpx;margin-top: 0;'])
Z([3,'https://cos.wsqytec.com/home/logo.png'])
Z([3,'width: 76rpx;height: 76rpx;margin-right: 16rpx;'])
Z([3,'display:flex;align-items:flex-start;flex-direction: column'])
Z([3,'font-size: 36rpx;font-weight: bold;'])
Z([3,'小正方助手'])
Z([3,'color: #999999;font-size: 28rpx;'])
Z([3,'提供云文件、地址路径、安全通话等服务'])
Z([3,'background-color: #ffffff;border-radius: 16rpx;overflow: hidden;padding: 16rpx 0;'])
Z([3,'display:flex;flex-wrap: wrap;justify-content:space-between'])
Z([3,'index'])
Z([3,'method'])
Z([[7],[3,'homeMethod']])
Z(z[11])
Z([3,'toMethod'])
Z([[7],[3,'index']])
Z([3,'width: 33.33%;display:flex;align-items:center;justify-content:center;'])
Z([3,'methodItem'])
Z([3,'hover'])
Z([[6],[[7],[3,'method']],[3,'homeIcon']])
Z([3,'width: 54rpx;height: 54rpx;margin-bottom: 10rpx;'])
Z([a,[[2,'?:'],[[6],[[7],[3,'method']],[3,'homeName']],[[6],[[7],[3,'method']],[3,'homeName']],[[6],[[7],[3,'method']],[3,'name']]]])
Z([3,'height: 40rpx;'])
Z([3,'background-color: #f4f4f4;padding: 26rpx 32rpx;'])
Z([3,'display:flex;align-items:center;justify-content:space-between;'])
Z([3,'font-size: 38rpx;font-weight: bold;'])
Z([3,'最近访问'])
Z([3,'showMore'])
Z([3,'#969799'])
Z([3,'ellipsis'])
Z([3,'44rpx'])
Z(z[0])
Z([3,'background-color: #ffffff;border-radius: 16rpx;overflow: hidden;padding: 24rpx 0;'])
Z([[7],[3,'show']])
Z([[2,'&&'],[[7],[3,'historys']],[[2,'=='],[[6],[[7],[3,'historys']],[3,'length']],[1,0]]])
Z([3,'text-align:center;padding:0 20rpx;box-sizing:border-box;'])
Z([3,'widthFix'])
Z([3,'https://cos.wsqytec.com/static/nothing.png'])
Z([3,'width:70%;height:auto;'])
Z([3,'font-size:30rpx;color:#969799;'])
Z([3,'暂无三个月内的访问足迹'])
Z([[7],[3,'historys']])
Z(z[11])
Z([1,false])
Z([3,'customClass'])
Z([[2,'?:'],[[2,'=='],[[6],[[7],[3,'item']],[3,'type']],[1,0]],[1,'orders-o'],[[2,'?:'],[[2,'=='],[[6],[[7],[3,'item']],[3,'type']],[1,1]],[1,'chat-o'],[[2,'?:'],[[2,'=='],[[6],[[7],[3,'item']],[3,'type']],[1,2]],[1,'phone-o'],[[2,'?:'],[[2,'=='],[[6],[[7],[3,'item']],[3,'type']],[1,3]],[1,'location-o'],[1,'newspaper-o']]]]])
Z([a,[[6],[[7],[3,'item']],[3,'createTime']],[3,'访问过']])
Z([3,'large'])
Z([[6],[[7],[3,'item']],[3,'name']])
Z([3,'titleClass'])
Z([[6],[[7],[3,'item']],[3,'path']])
Z([[2,'?:'],[[2,'=='],[[6],[[7],[3,'item']],[3,'type']],[1,0]],[1,'文件'],[[2,'?:'],[[2,'=='],[[6],[[7],[3,'item']],[3,'type']],[1,1]],[1,'互动卡'],[[2,'?:'],[[2,'=='],[[6],[[7],[3,'item']],[3,'type']],[1,2]],[1,'电话'],[[2,'?:'],[[2,'=='],[[6],[[7],[3,'item']],[3,'type']],[1,3]],[1,'地址'],[1,'集合']]]]])
Z([[2,'!'],[[7],[3,'show']]])
Z([3,'padding:0 24rpx;margin-top:24rpx;'])
Z([1,4])
Z(z[11])
Z([3,'skeleton-view'])
Z([a,[3,'height: 26rpx;width:'],[[2,'?:'],[[2,'=='],[[2,'%'],[[7],[3,'index']],[1,4]],[1,0]],[1,'40%'],[[2,'?:'],[[2,'=='],[[2,'%'],[[2,'+'],[[7],[3,'index']],[1,1]],[1,4]],[1,0]],[1,'60%'],[1,'100%']]],[3,';margin-bottom: 24rpx;border-radius: 8rpx;']])
Z([3,'height: 48rpx;'])
})(__WXML_GLOBAL__.ops_cached.$gwx_XC_26_1);return __WXML_GLOBAL__.ops_cached.$gwx_XC_26_1
}
__WXML_GLOBAL__.ops_set.$gwx_XC_26=z;
__WXML_GLOBAL__.ops_init.$gwx_XC_26=true;
var x=['./pages/home/home.wxml'];d_[x[0]]={}
var m0=function(e,s,r,gg){
var z=gz$gwx_XC_26_1()
var aNM=_n('view')
_rz(z,aNM,'style',0,e,s,gg)
var tOM=_n('view')
_rz(z,tOM,'style',1,e,s,gg)
var ePM=_mz(z,'image',['src',2,'style',1],[],e,s,gg)
_(tOM,ePM)
var bQM=_n('view')
_rz(z,bQM,'style',4,e,s,gg)
var oRM=_n('view')
_rz(z,oRM,'style',5,e,s,gg)
var xSM=_oz(z,6,e,s,gg)
_(oRM,xSM)
_(bQM,oRM)
var oTM=_n('view')
_rz(z,oTM,'style',7,e,s,gg)
var fUM=_oz(z,8,e,s,gg)
_(oTM,fUM)
_(bQM,oTM)
_(tOM,bQM)
_(aNM,tOM)
var cVM=_n('view')
_rz(z,cVM,'style',9,e,s,gg)
var hWM=_n('view')
_rz(z,hWM,'style',10,e,s,gg)
var oXM=_v()
_(hWM,oXM)
var cYM=function(l1M,oZM,a2M,gg){
var e4M=_mz(z,'view',['bindtap',15,'data-index',1,'style',2],[],l1M,oZM,gg)
var b5M=_mz(z,'view',['class',18,'hoverClass',1],[],l1M,oZM,gg)
var o6M=_mz(z,'image',['src',20,'style',1],[],l1M,oZM,gg)
_(b5M,o6M)
var x7M=_n('view')
var o8M=_oz(z,22,l1M,oZM,gg)
_(x7M,o8M)
_(b5M,x7M)
_(e4M,b5M)
_(a2M,e4M)
return a2M
}
oXM.wxXCkey=2
_2z(z,13,cYM,e,s,gg,oXM,'method','index','index')
_(cVM,hWM)
_(aNM,cVM)
_(r,aNM)
var f9M=_n('view')
_rz(z,f9M,'style',23,e,s,gg)
_(r,f9M)
var c0M=_n('van-sticky')
var hAN=_n('view')
_rz(z,hAN,'style',24,e,s,gg)
var oBN=_n('view')
_rz(z,oBN,'style',25,e,s,gg)
var cCN=_n('view')
_rz(z,cCN,'style',26,e,s,gg)
var oDN=_oz(z,27,e,s,gg)
_(cCN,oDN)
_(oBN,cCN)
var lEN=_mz(z,'van-icon',['bindtap',28,'color',1,'name',2,'size',3],[],e,s,gg)
_(oBN,lEN)
_(hAN,oBN)
_(c0M,hAN)
_(r,c0M)
var aFN=_n('view')
_rz(z,aFN,'style',32,e,s,gg)
var tGN=_n('view')
_rz(z,tGN,'style',33,e,s,gg)
var eHN=_v()
_(tGN,eHN)
if(_oz(z,34,e,s,gg)){eHN.wxVkey=1
var oJN=_n('view')
var xKN=_v()
_(oJN,xKN)
if(_oz(z,35,e,s,gg)){xKN.wxVkey=1
var oLN=_n('view')
_rz(z,oLN,'style',36,e,s,gg)
var fMN=_mz(z,'image',['mode',37,'src',1,'style',2],[],e,s,gg)
_(oLN,fMN)
var cNN=_n('view')
_rz(z,cNN,'style',40,e,s,gg)
var hON=_oz(z,41,e,s,gg)
_(cNN,hON)
_(oLN,cNN)
_(xKN,oLN)
}
var oPN=_v()
_(oJN,oPN)
var cQN=function(lSN,oRN,aTN,gg){
var eVN=_mz(z,'van-cell',['isLink',-1,'border',44,'customClass',1,'icon',2,'label',3,'size',4,'title',5,'titleClass',6,'url',7,'value',8],[],lSN,oRN,gg)
_(aTN,eVN)
return aTN
}
oPN.wxXCkey=4
_2z(z,42,cQN,e,s,gg,oPN,'item','index','index')
xKN.wxXCkey=1
_(eHN,oJN)
}
var bIN=_v()
_(tGN,bIN)
if(_oz(z,53,e,s,gg)){bIN.wxVkey=1
var bWN=_n('view')
_rz(z,bWN,'style',54,e,s,gg)
var oXN=_v()
_(bWN,oXN)
var xYN=function(f1N,oZN,c2N,gg){
var o4N=_mz(z,'view',['class',57,'style',1],[],f1N,oZN,gg)
_(c2N,o4N)
return c2N
}
oXN.wxXCkey=2
_2z(z,55,xYN,e,s,gg,oXN,'item','index','index')
_(bIN,bWN)
}
eHN.wxXCkey=1
eHN.wxXCkey=3
bIN.wxXCkey=1
_(aFN,tGN)
_(r,aFN)
var c5N=_n('view')
_rz(z,c5N,'style',59,e,s,gg)
_(r,c5N)
return r
}
e_[x[0]]={f:m0,j:[],i:[],ti:[],ic:[]}
if(path&&e_[path]){
outerGlobal.__wxml_comp_version__=0.02
return function(env,dd,global){$gwxc=0;var root={"tag":"wx-page"};root.children=[]
;g="$gwx_XC_26";var main=e_[path].f
if (typeof global==="undefined")global={};global.f=$gdc(f_[path],"",1);
if(typeof(outerGlobal.__webview_engine_version__)!='undefined'&&outerGlobal.__webview_engine_version__+1e-6>=0.02+1e-6&&outerGlobal.__mergeData__)
{
env=outerGlobal.__mergeData__(env,dd);
}
try{
main(env,{},root,global);
_tsd(root)
if(typeof(outerGlobal.__webview_engine_version__)=='undefined'|| outerGlobal.__webview_engine_version__+1e-6<0.01+1e-6){return _ev(root);}
}catch(err){
console.log(err)
}
;g="";
return root;
}
}
}
}(__g.a,__g.b,__g.c,__g.d,__g.e,__g.f,__g.g,__g.h,__g.i,__g.j,__g.k,__g.l,__g.m,__g.n,__g.o,__g.p,__g.q,__g.r,__g.s,__g.t,__g.u,__g.v,__g.w,__g.x,__g.y,__g.z,__g.A,__g.B,__g.C,__g.D,__g.E,__g.F,__g.G,__g.H,__g.I,__g.J,__g.K,__g.L,__g.M,__g.N,__g.O,__g.P,__g.Q,__g.R,__g.S,__g.T,__g.U,__g.V,__g.W,__g.X,__g.Y,__g.Z,__g.aa);if(__vd_version_info__.delayedGwx||false)$gwx_XC_26();	if (__vd_version_info__.delayedGwx) __wxAppCode__['pages/home/home.wxml'] = [$gwx_XC_26, './pages/home/home.wxml'];else __wxAppCode__['pages/home/home.wxml'] = $gwx_XC_26( './pages/home/home.wxml' );
	
var noCss=typeof __vd_version_info__!=='undefined'&&__vd_version_info__.noCss===true;if(!noCss){__wxAppCode__['pages/home/home.wxss'] = setCssToHead(["body{background-color:#f4f4f4}\n.",[1],"titleClass{-webkit-flex:3!important;flex:3!important}\n.",[1],"methodItem{-webkit-align-items:center;align-items:center;border-radius:",[0,16],";display:-webkit-flex;display:flex;-webkit-flex-direction:column;flex-direction:column;-webkit-justify-content:center;justify-content:center;margin:",[0,8]," 0;padding:",[0,30]," ",[0,15],"}\n.",[1],"hover{background-color:#eee}\n.",[1],"skeleton-view{-webkit-animation:skeleton-loading 2s ease infinite;animation:skeleton-loading 2s ease infinite;background-image:linear-gradient(90deg,#f2f2f2 25%,#e4e4e4 45%,#f2f2f2 70%);background-position:0 50%;background-size:400% 100%;border-radius:",[0,6],"}\n@-webkit-keyframes skeleton-loading{0%{background-position:0 50%}\n100%{background-position:100% 50%}\n}@keyframes skeleton-loading{0%{background-position:0 50%}\n100%{background-position:100% 50%}\n}.",[1],"skeleton-text{-webkit-text-fill-color:transparent;-webkit-animation:skeleton-loading 2s ease infinite;animation:skeleton-loading 2s ease infinite;background-clip:text;-webkit-background-clip:text;background-image:linear-gradient(90deg,#666 25%,#e4e4e4 45%,#666 70%);background-position:0 50%;background-size:400% 100%;font-size:",[0,28],";margin-top:15%;text-align:center}\n",],"Some selectors are not allowed in component wxss, including tag name selectors, ID selectors, and attribute selectors.(./pages/home/home.wxss:1:1)",{path:"./pages/home/home.wxss"});
}