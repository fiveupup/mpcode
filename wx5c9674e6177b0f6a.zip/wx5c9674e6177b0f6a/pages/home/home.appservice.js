$gwx_XC_26=function(_,_v,_n,_p,_s,_wp,_wl,$gwn,$gwl,$gwh,wh,$gstack,$gwrt,gra,grb,TestTest,wfor,_ca,_da,_r,_rz,_o,_oz,_1,_1z,_2,_2z,_m,_mz,nv_getDate,nv_getRegExp,nv_console,nv_parseInt,nv_parseFloat,nv_isNaN,nv_isFinite,nv_decodeURI,nv_decodeURIComponent,nv_encodeURI,nv_encodeURIComponent,$gdc,nv_JSON,_af,_gv,_ai,_grp,_gd,_gapi,$ixc,_ic,_w,_ev,_tsd){return function(path,global){
if(typeof global==='undefined'){if (typeof __GWX_GLOBAL__==='undefined')global={};else global=__GWX_GLOBAL__;}if(typeof __WXML_GLOBAL__ === 'undefined') {__WXML_GLOBAL__={};
}__WXML_GLOBAL__.modules = __WXML_GLOBAL__.modules || {};
var e_={}
if(typeof(global.entrys)==='undefined')global.entrys={};e_=global.entrys;
var d_={}
if(typeof(global.defines)==='undefined')global.defines={};d_=global.defines;
var f_={}
if(typeof(global.modules)==='undefined')global.modules={};f_=global.modules || {};
var p_={}
__WXML_GLOBAL__.ops_cached = __WXML_GLOBAL__.ops_cached || {}
__WXML_GLOBAL__.ops_set = __WXML_GLOBAL__.ops_set || {};
__WXML_GLOBAL__.ops_init = __WXML_GLOBAL__.ops_init || {};
var z=__WXML_GLOBAL__.ops_set.$gwx_XC_26 || [];
function gz$gwx_XC_26_1(){
if( __WXML_GLOBAL__.ops_cached.$gwx_XC_26_1)return __WXML_GLOBAL__.ops_cached.$gwx_XC_26_1
__WXML_GLOBAL__.ops_cached.$gwx_XC_26_1=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
Z([3,'showMore'])
Z([3,'#969799'])
Z([3,'ellipsis'])
Z([3,'44rpx'])
Z([3,'background-color: #ffffff;border-radius: 16rpx;overflow: hidden;padding: 24rpx 0;'])
Z([[7],[3,'show']])
Z([[2,'&&'],[[7],[3,'historys']],[[2,'=='],[[6],[[7],[3,'historys']],[3,'length']],[1,0]]])
Z([[7],[3,'historys']])
Z([3,'index'])
Z([1,false])
Z([3,'customClass'])
Z([[2,'?:'],[[2,'=='],[[6],[[7],[3,'item']],[3,'type']],[1,0]],[1,'orders-o'],[[2,'?:'],[[2,'=='],[[6],[[7],[3,'item']],[3,'type']],[1,1]],[1,'chat-o'],[[2,'?:'],[[2,'=='],[[6],[[7],[3,'item']],[3,'type']],[1,2]],[1,'phone-o'],[[2,'?:'],[[2,'=='],[[6],[[7],[3,'item']],[3,'type']],[1,3]],[1,'location-o'],[1,'newspaper-o']]]]])
Z([a,[[6],[[7],[3,'item']],[3,'createTime']],[3,'访问过']])
Z([3,'large'])
Z([[6],[[7],[3,'item']],[3,'name']])
Z([3,'titleClass'])
Z([[6],[[7],[3,'item']],[3,'path']])
Z([[2,'?:'],[[2,'=='],[[6],[[7],[3,'item']],[3,'type']],[1,0]],[1,'文件'],[[2,'?:'],[[2,'=='],[[6],[[7],[3,'item']],[3,'type']],[1,1]],[1,'互动卡'],[[2,'?:'],[[2,'=='],[[6],[[7],[3,'item']],[3,'type']],[1,2]],[1,'电话'],[[2,'?:'],[[2,'=='],[[6],[[7],[3,'item']],[3,'type']],[1,3]],[1,'地址'],[1,'集合']]]]])
Z([[2,'!'],[[7],[3,'show']]])
})(__WXML_GLOBAL__.ops_cached.$gwx_XC_26_1);return __WXML_GLOBAL__.ops_cached.$gwx_XC_26_1
}
__WXML_GLOBAL__.ops_set.$gwx_XC_26=z;
__WXML_GLOBAL__.ops_init.$gwx_XC_26=true;
var x=['./pages/home/home.wxml'];d_[x[0]]={}
var m0=function(e,s,r,gg){
var z=gz$gwx_XC_26_1()
var oBH=_n('van-sticky')
var xCH=_mz(z,'van-icon',['bindtap',0,'color',1,'name',1,'size',2],[],e,s,gg)
_(oBH,xCH)
_(r,oBH)
var oDH=_n('view')
_rz(z,oDH,'style',4,e,s,gg)
var fEH=_v()
_(oDH,fEH)
if(_oz(z,5,e,s,gg)){fEH.wxVkey=1
var hGH=_n('view')
var oHH=_v()
_(hGH,oHH)
if(_oz(z,6,e,s,gg)){oHH.wxVkey=1
}
var cIH=_v()
_(hGH,cIH)
var oJH=function(aLH,lKH,tMH,gg){
var bOH=_mz(z,'van-cell',['isLink',-1,'border',9,'customClass',1,'icon',2,'label',3,'size',4,'title',5,'titleClass',6,'url',7,'value',8],[],aLH,lKH,gg)
_(tMH,bOH)
return tMH
}
cIH.wxXCkey=4
_2z(z,7,oJH,e,s,gg,cIH,'item','index','index')
oHH.wxXCkey=1
_(fEH,hGH)
}
var cFH=_v()
_(oDH,cFH)
if(_oz(z,18,e,s,gg)){cFH.wxVkey=1
}
fEH.wxXCkey=1
fEH.wxXCkey=3
cFH.wxXCkey=1
_(r,oDH)
return r
}
e_[x[0]]={f:m0,j:[],i:[],ti:[],ic:[]}
if(path&&e_[path]){
return function(env,dd,global){$gwxc=0;var root={"tag":"wx-page"};root.children=[]
;g="$gwx_XC_26";var main=e_[path].f
if (typeof global==="undefined")global={};global.f=$gdc(f_[path],"",1);
try{
main(env,{},root,global);
_tsd(root)
}catch(err){
console.log(err)
}
;g="";
return root;
}
}
}
}(__g.a,__g.b,__g.c,__g.d,__g.e,__g.f,__g.g,__g.h,__g.i,__g.j,__g.k,__g.l,__g.m,__g.n,__g.o,__g.p,__g.q,__g.r,__g.s,__g.t,__g.u,__g.v,__g.w,__g.x,__g.y,__g.z,__g.A,__g.B,__g.C,__g.D,__g.E,__g.F,__g.G,__g.H,__g.I,__g.J,__g.K,__g.L,__g.M,__g.N,__g.O,__g.P,__g.Q,__g.R,__g.S,__g.T,__g.U,__g.V,__g.W,__g.X,__g.Y,__g.Z,__g.aa);if(__vd_version_info__.delayedGwx||false)$gwx_XC_26();	if (__vd_version_info__.delayedGwx) __wxAppCode__['pages/home/home.wxml'] = [$gwx_XC_26, './pages/home/home.wxml'];else __wxAppCode__['pages/home/home.wxml'] = $gwx_XC_26( './pages/home/home.wxml' );
	;__wxRoute = "pages/home/home";__wxRouteBegin = true;__wxAppCurrentFile__="pages/home/home.js";define("pages/home/home.js",function(require,module,exports,window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){
"use strict";var e=require("../../@babel/runtime/helpers/typeof"),t=require("../../@babel/runtime/helpers/regeneratorRuntime"),a=require("../../@babel/runtime/helpers/asyncToGenerator");wx.cloud.init();var n,s,i=wx.cloud.database({env:"zhijiebohao-4gp9aizse6797bd3"}),r=i.command;Page({data:{historys:[],show:!1,pageNum:1,pageSize:20,homeMethod:[]},toMethod:function(e){var t=e.currentTarget.dataset.index,a=this.data.homeMethod[t];1==a.type?wx.navigateTo({url:a.url}):2==a.type?wx.navigateToMiniProgram({appId:a.content,path:a.url}):5==a.type?wx.switchTab({url:a.url}):6==a.type?wx.openCustomerServiceChat?wx.openCustomerServiceChat({extInfo:{url:a.url},corpId:a.content,success:function(e){},fail:function(e){wx.showToast({title:"请使用最新版手机微信重试",icon:"none"})}}):wx.showToast({title:"请使用最新版手机微信重试",icon:"none"}):9==a.type?wx.openEmbeddedMiniProgram({path:a.url,appId:a.content}):10==a.type&&wx.setClipboardData({data:a.content})},onPageScroll:function(e){e.scrollTop>200&&"小正方助手"!=this.navTitle?(this.navTitle="小正方助手",wx.setNavigationBarTitle({title:"小正方助手"})):e.scrollTop<=200&&""!=this.navTitle&&(this.navTitle="",wx.setNavigationBarTitle({title:""}))},showMore:function(){this.setData({needRefresh:!0}),wx.navigateTo({url:"/vantPage/simpleHistory/simpleHistory"})},getData:function(e){var t=this;wx.stopPullDownRefresh(),e&&t.setData({pageNum:1}),wx.cloud.callFunction({name:"simpleHistory",data:{pageNum:t.data.pageNum,pageSize:t.data.pageSize}}).then((function(a){var n=a.result;if(n&&n.length>0&&n.map((function(e){e.createTime=t.formatTime(e.createTime)})),e)t.setData({historys:n});else{var s=[];t.data.historys&&(s=t.data.historys),t.setData({historys:s.concat(n)})}t.setData({show:!0})}))},onShow:function(){this.data.needRefresh&&(this.getData(!0),this.setData({needRefresh:!1}))},onLoad:(s=a(t().mark((function e(a){var n;return t().wrap((function(e){for(;;)switch(e.prev=e.next){case 0:n=this,wx.getStorage({key:"methodList",success:function(e){if(e.data){var t=JSON.parse(e.data).filter((function(e){return 1==e.isHome}));n.setData({homeMethod:t})}}}),n.getMethodList(),n.getData(!0);case 4:case"end":return e.stop()}}),e,this)}))),function(e){return s.apply(this,arguments)}),getMethodList:(n=a(t().mark((function e(){var a,n,s,o;return t().wrap((function(e){for(;;)switch(e.prev=e.next){case 0:return(a={}).status=r.eq(!0),e.next=4,i.collection("method_list").where(a).field({_id:!0,name:!0,content:!0,type:!0,url:!0,icon:!0,group:!0,isHome:!0,onlyHome:!0,homeIcon:!0,homeName:!0}).orderBy("sort","asc").get();case 4:n=e.sent,s=n.data,o=s.filter((function(e){return 1==e.isHome})),this.setData({homeMethod:o}),wx.setStorage({key:"methodList",data:JSON.stringify(s)});case 9:case"end":return e.stop()}}),e,this)}))),function(){return n.apply(this,arguments)}),formatTime:function(t,a){if(t){switch(a||(a="yyyy-MM-dd HH:mm"),e(t)){case"string":var n=!1;t.indexOf("T")>-1&&t.indexOf("Z")>-1&&(n=!0,t=t.replace(/T/g," ").substring(0,t.lastIndexOf("."))),t=t.replace(/-/g,"/"),t=new Date(t),n&&(t=new Date(t.getTime()+288e5));break;case"number":t=new Date(t)}if(!(!t instanceof Date)){var s={yyyy:t.getFullYear(),M:t.getMonth()+1,d:t.getDate(),H:t.getHours(),m:t.getMinutes(),s:t.getSeconds(),MM:(""+(t.getMonth()+101)).substr(1),dd:(""+(t.getDate()+100)).substr(1),HH:(""+(t.getHours()+100)).substr(1),mm:(""+(t.getMinutes()+100)).substr(1),ss:(""+(t.getSeconds()+100)).substr(1)};return a.replace(/(yyyy|MM?|dd?|HH?|ss?|mm?)/g,(function(){return s[arguments[0]]}))}}},onShareAppMessage:function(e){return{title:"专业的云服务平台，提供云文件、地址路径、安全通话等服务。",imageUrl:"cloud://zhijiebohao-4gp9aizse6797bd3.7a68-zhijiebohao-4gp9aizse6797bd3-1257150849/share-xzf.jpg"}}});
},{isPage:true,isComponent:true,currentFile:'pages/home/home.js'});require("pages/home/home.js");