$gwx_XC_29=function(_,_v,_n,_p,_s,_wp,_wl,$gwn,$gwl,$gwh,wh,$gstack,$gwrt,gra,grb,TestTest,wfor,_ca,_da,_r,_rz,_o,_oz,_1,_1z,_2,_2z,_m,_mz,nv_getDate,nv_getRegExp,nv_console,nv_parseInt,nv_parseFloat,nv_isNaN,nv_isFinite,nv_decodeURI,nv_decodeURIComponent,nv_encodeURI,nv_encodeURIComponent,$gdc,nv_JSON,_af,_gv,_ai,_grp,_gd,_gapi,$ixc,_ic,_w,_ev,_tsd){return function(path,global){
if(typeof global==='undefined'){if (typeof __GWX_GLOBAL__==='undefined')global={};else global=__GWX_GLOBAL__;}if(typeof __WXML_GLOBAL__ === 'undefined') {__WXML_GLOBAL__={};
}__WXML_GLOBAL__.modules = __WXML_GLOBAL__.modules || {};
var e_={}
if(typeof(global.entrys)==='undefined')global.entrys={};e_=global.entrys;
var d_={}
if(typeof(global.defines)==='undefined')global.defines={};d_=global.defines;
var f_={}
if(typeof(global.modules)==='undefined')global.modules={};f_=global.modules || {};
var p_={}
__WXML_GLOBAL__.ops_cached = __WXML_GLOBAL__.ops_cached || {}
__WXML_GLOBAL__.ops_set = __WXML_GLOBAL__.ops_set || {};
__WXML_GLOBAL__.ops_init = __WXML_GLOBAL__.ops_init || {};
var z=__WXML_GLOBAL__.ops_set.$gwx_XC_29 || [];
function gz$gwx_XC_29_1(){
if( __WXML_GLOBAL__.ops_cached.$gwx_XC_29_1)return __WXML_GLOBAL__.ops_cached.$gwx_XC_29_1
__WXML_GLOBAL__.ops_cached.$gwx_XC_29_1=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
Z([[7],[3,'absent']])
Z([[2,'&&'],[[7],[3,'authority']],[[2,'!'],[[6],[[7],[3,'info']],[3,'authorNoticeRead']]]])
Z([3,'#ffffff'])
Z([3,'closeNoticeBar'])
Z([3,'#07c160'])
Z([3,'flag-o'])
Z([3,'closeable'])
Z([3,'30'])
Z([3,'您是作者，可查看和管理全部互动。'])
Z([[7],[3,'show']])
Z([3,'font-size:32rpx;line-height:44rpx;width:100%;box-sizing:border-box;'])
Z([[2,'&&'],[[6],[[7],[3,'info']],[3,'description']],[[2,'!'],[[7],[3,'msgId']]]])
Z([[2,'&&'],[[2,'&&'],[[2,'&&'],[[6],[[7],[3,'info']],[3,'_id']],[[2,'!'],[[6],[[7],[3,'info']],[3,'closeInput']]]],[[2,'!'],[[7],[3,'msgId']]]],[[7],[3,'userInfo']]])
Z([[2,'&&'],[[2,'&&'],[[6],[[7],[3,'info']],[3,'_id']],[[2,'!'],[[6],[[7],[3,'info']],[3,'closeInput']]]],[[2,'!'],[[6],[[7],[3,'info']],[3,'fromMsgcard']]]])
Z([3,'onCloseShowBig'])
Z([3,'showBigClass'])
Z([[7],[3,'showBig']])
Z([[7],[3,'msgListTemp']])
Z([3,'_id'])
Z([[2,'!'],[[6],[[7],[3,'item']],[3,'isHide']]])
Z([3,'showDeal'])
Z([3,'msgContent'])
Z([[7],[3,'index']])
Z([3,'padding:0 16rpx;box-sizing:border-box;'])
Z([3,'msgText'])
Z([3,'nameView'])
Z([3,'display:flex;'])
Z([[6],[[7],[3,'item']],[3,'top']])
Z([3,'#808080'])
Z([3,'display:flex;align-items: center;width:auto;margin-right:6rpx;'])
Z([[2,'!'],[[6],[[7],[3,'item']],[3,'status']]])
Z([3,'#cccccc'])
Z([3,'display:flex;align-items: center;width:auto;margin-left:10rpx;margin-right:6rpx;'])
Z([[6],[[7],[3,'item']],[3,'secret']])
Z(z[4])
Z(z[29])
Z([[2,'>'],[[6],[[7],[3,'item']],[3,'myGoodCount']],[1,0]])
Z([3,'tapGood'])
Z(z[22])
Z([3,'display: flex;align-items: flex-start;'])
Z([3,'lightslategray'])
Z([3,'good-job'])
Z([3,'40rpx'])
Z([3,'display: flex;align-items: center;'])
Z(z[37])
Z(z[22])
Z(z[39])
Z(z[40])
Z([3,'good-job-o'])
Z(z[42])
Z(z[43])
Z([[2,'&&'],[[6],[[7],[3,'item']],[3,'reply']],[[2,'!'],[[6],[[7],[3,'item']],[3,'replyIsHide']]]])
Z([3,'display: flex;align-items: center;justify-content: flex-start;'])
Z([[2,'&&'],[[7],[3,'author']],[[6],[[7],[3,'author']],[3,'avatarUrl']]])
Z([3,'manager-o'])
Z([3,'36rpx'])
Z(z[43])
Z([3,'floorIndex'])
Z([3,'floorItem'])
Z([[6],[[7],[3,'item']],[3,'floorNumber']])
Z([3,'unique'])
Z(z[59])
Z([[2,'&&'],[[2,'&&'],[[6],[[7],[3,'item']],[[2,'+'],[1,'floor'],[[2,'+'],[[7],[3,'floorItem']],[1,1]]]],[[6],[[7],[3,'item']],[[2,'+'],[[2,'+'],[1,'floor'],[[2,'+'],[[7],[3,'floorItem']],[1,1]]],[1,'Type']]]],[[2,'!'],[[6],[[7],[3,'item']],[[2,'+'],[[2,'+'],[1,'floor'],[[2,'+'],[[7],[3,'floorItem']],[1,1]]],[1,'IsHide']]]]])
Z([3,'replyView'])
Z([[2,'=='],[[6],[[7],[3,'item']],[[2,'+'],[[2,'+'],[1,'floor'],[[2,'+'],[[7],[3,'floorItem']],[1,1]]],[1,'Type']]],[1,1]])
Z(z[52])
Z(z[53])
Z(z[54])
Z(z[55])
Z(z[43])
Z([[2,'=='],[[6],[[7],[3,'item']],[[2,'+'],[[2,'+'],[1,'floor'],[[2,'+'],[[7],[3,'floorItem']],[1,1]]],[1,'Type']]],[1,2]])
Z([[2,'&&'],[[7],[3,'allShow']],[[2,'>'],[[7],[3,'pageNum']],[1,1]]])
Z([3,'center'])
Z([3,'border:0;'])
Z([[7],[3,'showNavBarLoding']])
Z([[2,'&&'],[[7],[3,'msgList']],[[2,'=='],[[6],[[7],[3,'msgList']],[3,'length']],[1,0]]])
Z([[6],[[7],[3,'info']],[3,'fromMsgcard']])
Z([[7],[3,'dealActions']])
Z([3,'hideDeal'])
Z(z[78])
Z([3,'onSelect'])
Z([3,'取消'])
Z([a,[3,'@'],[[6],[[7],[3,'selectMsgInfo']],[3,'name']],[3,'的互动']])
Z([[7],[3,'showDeal']])
Z([3,'showToMsgAfter'])
Z([3,'onClosePopupMsg'])
Z([3,'height:92%;'])
Z([3,'bottom'])
Z([[7],[3,'showToMsg']])
Z([3,'writeView'])
Z([3,'display:flex;justify-content:space-between;align-items:center;margin:20rpx 40rpx 30rpx 40rpx;'])
Z([[2,'&&'],[[7],[3,'userInfo']],[[6],[[7],[3,'userInfo']],[3,'_openid']]])
Z(z[85])
Z([3,'cross'])
Z(z[55])
Z([3,'padding:6rpx;margin-left: 10rpx;'])
Z([[7],[3,'showToMsgTextarea']])
Z([3,'margin:0 40rpx 0 40rpx;display:flex;justify-content:space-between;align-items:center;'])
Z([3,'textEmojiShow'])
Z([3,'my-icon'])
Z([3,'#707070'])
Z([3,'xiaonian'])
Z([3,'50rpx'])
Z([3,'secretChange'])
Z(z[4])
Z([3,'34rpx'])
Z([3,'secret-check-label'])
Z([3,'square'])
Z([[7],[3,'secret']])
Z([[7],[3,'textEmoji']])
Z([3,'i'])
Z([[7],[3,'emojiPageArr']])
Z([3,'index'])
Z([3,'idx'])
Z([[7],[3,'emojis']])
Z(z[113])
Z([[2,'=='],[[2,'|'],[[2,'/'],[[7],[3,'idx']],[[7],[3,'emojiPageSize']]],[[7],[3,'Int']]],[[7],[3,'i']]])
Z([3,'showReplyAfter'])
Z([3,'closeRe'])
Z([3,'height:91%;'])
Z(z[87])
Z([[7],[3,'showReply']])
Z(z[89])
Z(z[90])
Z([3,'width:auto;'])
Z([[2,'!'],[[7],[3,'authority']]])
Z([[2,'&&'],[[7],[3,'author']],[[6],[[7],[3,'author']],[3,'_openid']]])
Z(z[118])
Z(z[93])
Z(z[55])
Z(z[95])
Z([[7],[3,'showReplyTextarea']])
Z([3,'replyEmojiShow'])
Z(z[99])
Z(z[100])
Z(z[101])
Z(z[102])
Z([[7],[3,'replyEmoji']])
Z(z[110])
Z(z[111])
Z(z[112])
Z(z[113])
Z(z[114])
Z(z[113])
Z(z[116])
Z([3,'backTop'])
Z([1,300])
Z([3,'slide-right'])
Z([[7],[3,'backTop']])
Z([3,'position: fixed;right:32rpx;bottom:60rpx;width:80rpx;height:80rpx;display:flex;justify-content:center;align-items:center;'])
Z(z[99])
Z(z[2])
Z([3,'width:48rpx;height:48rpx;display:flex;justify-content:center;align-items:center;'])
Z([3,'backtop'])
Z([3,'48rpx'])
Z([[2,'!'],[[7],[3,'show']]])
Z([3,'myPrivacy'])
})(__WXML_GLOBAL__.ops_cached.$gwx_XC_29_1);return __WXML_GLOBAL__.ops_cached.$gwx_XC_29_1
}
__WXML_GLOBAL__.ops_set.$gwx_XC_29=z;
__WXML_GLOBAL__.ops_init.$gwx_XC_29=true;
var x=['./pages/msg/list/list.wxml'];d_[x[0]]={}
var m0=function(e,s,r,gg){
var z=gz$gwx_XC_29_1()
var oHI=_v()
_(r,oHI)
if(_oz(z,0,e,s,gg)){oHI.wxVkey=1
}
var xII=_v()
_(r,xII)
if(_oz(z,1,e,s,gg)){xII.wxVkey=1
var cLI=_mz(z,'van-notice-bar',['background',2,'bind:close',1,'color',2,'leftIcon',3,'mode',4,'speed',5,'text',6],[],e,s,gg)
_(xII,cLI)
}
var oJI=_v()
_(r,oJI)
if(_oz(z,9,e,s,gg)){oJI.wxVkey=1
var hMI=_n('view')
_rz(z,hMI,'style',10,e,s,gg)
var oNI=_v()
_(hMI,oNI)
if(_oz(z,11,e,s,gg)){oNI.wxVkey=1
}
var cOI=_v()
_(hMI,cOI)
if(_oz(z,12,e,s,gg)){cOI.wxVkey=1
var bUI=_n('van-sticky')
_(cOI,bUI)
}
var oPI=_v()
_(hMI,oPI)
if(_oz(z,13,e,s,gg)){oPI.wxVkey=1
}
var oVI=_mz(z,'van-popup',['closeable',-1,'round',-1,'bind:close',14,'customClass',1,'show',2],[],e,s,gg)
_(hMI,oVI)
var xWI=_v()
_(hMI,xWI)
var oXI=function(cZI,fYI,h1I,gg){
var c3I=_v()
_(h1I,c3I)
if(_oz(z,19,cZI,fYI,gg)){c3I.wxVkey=1
var o4I=_mz(z,'view',['bindtap',20,'class',1,'data-index',2,'style',3],[],cZI,fYI,gg)
var l5I=_n('view')
_rz(z,l5I,'class',24,cZI,fYI,gg)
var t7I=_n('view')
_rz(z,t7I,'class',25,cZI,fYI,gg)
var b9I=_n('view')
_rz(z,b9I,'style',26,cZI,fYI,gg)
var o0I=_v()
_(b9I,o0I)
if(_oz(z,27,cZI,fYI,gg)){o0I.wxVkey=1
var fCJ=_mz(z,'van-tag',['color',28,'style',1],[],cZI,fYI,gg)
_(o0I,fCJ)
}
var xAJ=_v()
_(b9I,xAJ)
if(_oz(z,30,cZI,fYI,gg)){xAJ.wxVkey=1
var cDJ=_mz(z,'van-tag',['color',31,'style',1],[],cZI,fYI,gg)
_(xAJ,cDJ)
}
var oBJ=_v()
_(b9I,oBJ)
if(_oz(z,33,cZI,fYI,gg)){oBJ.wxVkey=1
var hEJ=_mz(z,'van-tag',['color',34,'style',1],[],cZI,fYI,gg)
_(oBJ,hEJ)
}
o0I.wxXCkey=1
o0I.wxXCkey=3
xAJ.wxXCkey=1
xAJ.wxXCkey=3
oBJ.wxXCkey=1
oBJ.wxXCkey=3
_(t7I,b9I)
var e8I=_v()
_(t7I,e8I)
if(_oz(z,36,cZI,fYI,gg)){e8I.wxVkey=1
var oFJ=_mz(z,'view',['catchtap',37,'data-index',1,'style',2],[],cZI,fYI,gg)
var cGJ=_mz(z,'van-icon',['color',40,'name',1,'size',2,'style',3],[],cZI,fYI,gg)
_(oFJ,cGJ)
_(e8I,oFJ)
}
else{e8I.wxVkey=2
var oHJ=_mz(z,'view',['catchtap',44,'data-index',1,'style',2],[],cZI,fYI,gg)
var lIJ=_mz(z,'van-icon',['color',47,'name',1,'size',2,'style',3],[],cZI,fYI,gg)
_(oHJ,lIJ)
_(e8I,oHJ)
}
e8I.wxXCkey=1
e8I.wxXCkey=3
e8I.wxXCkey=3
_(l5I,t7I)
var a6I=_v()
_(l5I,a6I)
if(_oz(z,51,cZI,fYI,gg)){a6I.wxVkey=1
var aJJ=_n('view')
_rz(z,aJJ,'style',52,cZI,fYI,gg)
var tKJ=_v()
_(aJJ,tKJ)
if(_oz(z,53,cZI,fYI,gg)){tKJ.wxVkey=1
}
else{tKJ.wxVkey=2
var eLJ=_mz(z,'van-icon',['name',54,'size',1,'style',2],[],cZI,fYI,gg)
_(tKJ,eLJ)
}
tKJ.wxXCkey=1
tKJ.wxXCkey=3
_(a6I,aJJ)
}
var bMJ=_v()
_(l5I,bMJ)
var oNJ=function(oPJ,xOJ,fQJ,gg){
var hSJ=_v()
_(fQJ,hSJ)
if(_oz(z,61,oPJ,xOJ,gg)){hSJ.wxVkey=1
var oTJ=_v()
_(hSJ,oTJ)
if(_oz(z,62,oPJ,xOJ,gg)){oTJ.wxVkey=1
var cUJ=_n('view')
_rz(z,cUJ,'class',63,oPJ,xOJ,gg)
var oVJ=_v()
_(cUJ,oVJ)
if(_oz(z,64,oPJ,xOJ,gg)){oVJ.wxVkey=1
var aXJ=_n('view')
_rz(z,aXJ,'style',65,oPJ,xOJ,gg)
var tYJ=_v()
_(aXJ,tYJ)
if(_oz(z,66,oPJ,xOJ,gg)){tYJ.wxVkey=1
}
else{tYJ.wxVkey=2
var eZJ=_mz(z,'van-icon',['name',67,'size',1,'style',2],[],oPJ,xOJ,gg)
_(tYJ,eZJ)
}
tYJ.wxXCkey=1
tYJ.wxXCkey=3
_(oVJ,aXJ)
}
var lWJ=_v()
_(cUJ,lWJ)
if(_oz(z,70,oPJ,xOJ,gg)){lWJ.wxVkey=1
}
oVJ.wxXCkey=1
oVJ.wxXCkey=3
lWJ.wxXCkey=1
_(oTJ,cUJ)
}
oTJ.wxXCkey=1
oTJ.wxXCkey=3
}
hSJ.wxXCkey=1
hSJ.wxXCkey=3
return fQJ
}
bMJ.wxXCkey=4
_2z(z,59,oNJ,cZI,fYI,gg,bMJ,'floorItem','floorIndex','unique')
a6I.wxXCkey=1
a6I.wxXCkey=3
_(o4I,l5I)
_(c3I,o4I)
}
c3I.wxXCkey=1
c3I.wxXCkey=3
return h1I
}
xWI.wxXCkey=4
_2z(z,17,oXI,e,s,gg,xWI,'item','index','_id')
var lQI=_v()
_(hMI,lQI)
if(_oz(z,71,e,s,gg)){lQI.wxVkey=1
var b1J=_mz(z,'van-divider',['dashed',-1,'contentPosition',72,'customStyle',1],[],e,s,gg)
_(lQI,b1J)
}
var aRI=_v()
_(hMI,aRI)
if(_oz(z,74,e,s,gg)){aRI.wxVkey=1
}
var tSI=_v()
_(hMI,tSI)
if(_oz(z,75,e,s,gg)){tSI.wxVkey=1
}
var eTI=_v()
_(hMI,eTI)
if(_oz(z,76,e,s,gg)){eTI.wxVkey=1
}
var o2J=_mz(z,'van-action-sheet',['actions',77,'bind:cancel',1,'bind:close',2,'bind:select',3,'cancelText',4,'description',5,'show',6],[],e,s,gg)
_(hMI,o2J)
var x3J=_mz(z,'van-popup',['round',-1,'bind:after-enter',84,'bind:close',1,'customStyle',2,'position',3,'show',4],[],e,s,gg)
var o4J=_n('view')
_rz(z,o4J,'class',89,e,s,gg)
var h7J=_n('view')
_rz(z,h7J,'style',90,e,s,gg)
var o8J=_v()
_(h7J,o8J)
if(_oz(z,91,e,s,gg)){o8J.wxVkey=1
}
var c9J=_mz(z,'van-icon',['bindtap',92,'name',1,'size',2,'style',3],[],e,s,gg)
_(h7J,c9J)
o8J.wxXCkey=1
_(o4J,h7J)
var f5J=_v()
_(o4J,f5J)
if(_oz(z,96,e,s,gg)){f5J.wxVkey=1
}
var o0J=_n('view')
_rz(z,o0J,'style',97,e,s,gg)
var lAK=_mz(z,'van-icon',['bindtap',98,'classPrefix',1,'color',2,'name',3,'size',4],[],e,s,gg)
_(o0J,lAK)
var aBK=_mz(z,'van-checkbox',['bind:change',103,'checkedColor',1,'iconSize',2,'labelClass',3,'shape',4,'value',5],[],e,s,gg)
_(o0J,aBK)
_(o4J,o0J)
var c6J=_v()
_(o4J,c6J)
if(_oz(z,109,e,s,gg)){c6J.wxVkey=1
var tCK=_v()
_(c6J,tCK)
var eDK=function(oFK,bEK,xGK,gg){
var fIK=_v()
_(xGK,fIK)
var cJK=function(oLK,hKK,cMK,gg){
var lOK=_v()
_(cMK,lOK)
if(_oz(z,116,oLK,hKK,gg)){lOK.wxVkey=1
}
lOK.wxXCkey=1
return cMK
}
fIK.wxXCkey=2
_2z(z,114,cJK,oFK,bEK,gg,fIK,'item','idx','idx')
return xGK
}
tCK.wxXCkey=2
_2z(z,111,eDK,e,s,gg,tCK,'i','index','index')
}
f5J.wxXCkey=1
c6J.wxXCkey=1
_(x3J,o4J)
_(hMI,x3J)
var aPK=_mz(z,'van-popup',['round',-1,'bind:after-enter',117,'bind:close',1,'customStyle',2,'position',3,'show',4],[],e,s,gg)
var tQK=_n('view')
_rz(z,tQK,'class',122,e,s,gg)
var oTK=_n('view')
_rz(z,oTK,'style',123,e,s,gg)
var xUK=_n('view')
_rz(z,xUK,'style',124,e,s,gg)
var oVK=_v()
_(xUK,oVK)
if(_oz(z,125,e,s,gg)){oVK.wxVkey=1
}
else{oVK.wxVkey=2
var fWK=_v()
_(oVK,fWK)
if(_oz(z,126,e,s,gg)){fWK.wxVkey=1
}
fWK.wxXCkey=1
}
oVK.wxXCkey=1
_(oTK,xUK)
var cXK=_mz(z,'van-icon',['bindtap',127,'name',1,'size',2,'style',3],[],e,s,gg)
_(oTK,cXK)
_(tQK,oTK)
var eRK=_v()
_(tQK,eRK)
if(_oz(z,131,e,s,gg)){eRK.wxVkey=1
}
var hYK=_mz(z,'van-icon',['bindtap',132,'classPrefix',1,'color',2,'name',3,'size',4],[],e,s,gg)
_(tQK,hYK)
var bSK=_v()
_(tQK,bSK)
if(_oz(z,137,e,s,gg)){bSK.wxVkey=1
var oZK=_v()
_(bSK,oZK)
var c1K=function(l3K,o2K,a4K,gg){
var e6K=_v()
_(a4K,e6K)
var b7K=function(x9K,o8K,o0K,gg){
var cBL=_v()
_(o0K,cBL)
if(_oz(z,144,x9K,o8K,gg)){cBL.wxVkey=1
}
cBL.wxXCkey=1
return o0K
}
e6K.wxXCkey=2
_2z(z,142,b7K,l3K,o2K,gg,e6K,'item','idx','idx')
return a4K
}
oZK.wxXCkey=2
_2z(z,139,c1K,e,s,gg,oZK,'i','index','index')
}
eRK.wxXCkey=1
bSK.wxXCkey=1
_(aPK,tQK)
_(hMI,aPK)
oNI.wxXCkey=1
cOI.wxXCkey=1
cOI.wxXCkey=3
oPI.wxXCkey=1
lQI.wxXCkey=1
lQI.wxXCkey=3
aRI.wxXCkey=1
tSI.wxXCkey=1
eTI.wxXCkey=1
_(oJI,hMI)
}
var hCL=_mz(z,'van-transition',['bindtap',145,'duration',1,'name',2,'show',3,'style',4],[],e,s,gg)
var oDL=_mz(z,'van-icon',['classPrefix',150,'color',1,'customStyle',2,'name',3,'size',4],[],e,s,gg)
_(hCL,oDL)
_(r,hCL)
var fKI=_v()
_(r,fKI)
if(_oz(z,155,e,s,gg)){fKI.wxVkey=1
}
var cEL=_n('my-privacy')
_rz(z,cEL,'id',156,e,s,gg)
_(r,cEL)
oHI.wxXCkey=1
xII.wxXCkey=1
xII.wxXCkey=3
oJI.wxXCkey=1
oJI.wxXCkey=3
fKI.wxXCkey=1
return r
}
e_[x[0]]={f:m0,j:[],i:[],ti:[],ic:[]}
if(path&&e_[path]){
return function(env,dd,global){$gwxc=0;var root={"tag":"wx-page"};root.children=[]
;g="$gwx_XC_29";var main=e_[path].f
if (typeof global==="undefined")global={};global.f=$gdc(f_[path],"",1);
try{
main(env,{},root,global);
_tsd(root)
}catch(err){
console.log(err)
}
;g="";
return root;
}
}
}
}(__g.a,__g.b,__g.c,__g.d,__g.e,__g.f,__g.g,__g.h,__g.i,__g.j,__g.k,__g.l,__g.m,__g.n,__g.o,__g.p,__g.q,__g.r,__g.s,__g.t,__g.u,__g.v,__g.w,__g.x,__g.y,__g.z,__g.A,__g.B,__g.C,__g.D,__g.E,__g.F,__g.G,__g.H,__g.I,__g.J,__g.K,__g.L,__g.M,__g.N,__g.O,__g.P,__g.Q,__g.R,__g.S,__g.T,__g.U,__g.V,__g.W,__g.X,__g.Y,__g.Z,__g.aa);if(__vd_version_info__.delayedGwx||false)$gwx_XC_29();	if (__vd_version_info__.delayedGwx) __wxAppCode__['pages/msg/list/list.wxml'] = [$gwx_XC_29, './pages/msg/list/list.wxml'];else __wxAppCode__['pages/msg/list/list.wxml'] = $gwx_XC_29( './pages/msg/list/list.wxml' );
	;__wxRoute = "pages/msg/list/list";__wxRouteBegin = true;__wxAppCurrentFile__="pages/msg/list/list.js";define("pages/msg/list/list.js",function(require,module,exports,window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){
"use strict";var t=require("../../../@babel/runtime/helpers/typeof"),e=require("../../../@babel/runtime/helpers/regeneratorRuntime"),a=require("../../../@babel/runtime/helpers/asyncToGenerator");wx.cloud.init();var i,n,o=wx.cloud.database(),s=o.command,r=o.collection("message"),d=o.collection("msgpages"),c=o.collection("msg_user"),u=require("../../../components/emoji/emoji-parser.esm"),l=require("../../../components/cos/cos-wx-sdk-v5.min"),h=void 0,g=void 0;Page({data:{isFromMini:!1,systemInfo:wx.getSystemInfoSync(),userGetting:!1,emojiPageArr:[],emojiPageSize:0,emojiContainerMargin:0,emojis:u.getEmojis({size:31}),show:!1,showNavBarLoding:!1,pageNum:1,pageSize:20,allShow:!1,msgList:null,msgListTemp:null,selectMsgInfo:{},_index:0,title:"",maxNumber:140,numberText:0,numberReply:0,showToMsg:!1,showReply:!1,showReplyTextarea:!1,showToMsgTextarea:!1,toMsgFocus:!1,replyFocus:!1,authority:!1,replyMsgId:"",qr:"",userId:"",author:null,pageId:"",msgId:"",goodCount:0,info:{},text:"",secret:!1,anonymous:!1,reply:"",showDeal:!1,dealActionsInit:[{name:"置顶/取消置顶",index:0},{name:"添加回复",index:1},{name:"审核/取消审核",index:2},{name:"删除",index:3,color:"red"}],dealActions:[],textEmoji:!1,textCursor:0,replyEmoji:!1,replyCursor:0,currentItemId:"",currentReplyId:"",currentFloorId:"",onlyMe:!1,latest:!1,hot:!1,goodIndex:-1,backTop:!1,userInfo:void 0,saveusertype:0},onCloseShowBig:function(){this.setData({showBig:!1})},showBig:function(t){var e=this.data.msgList[t.currentTarget.dataset.index];e&&this.setData({showBig:!0,showBigImg:e.imageSrc,showBigName:e.name,showBigCreateTime:e.createTime})},showBigForReply:function(t){var e=t.currentTarget.dataset;e&&e.time&&this.setData({showBig:!0,showBigImg:e.image,showBigName:e.name,showBigCreateTime:e.time})},toComment:function(){wx.navigateTo({url:"/vantPage/comment/comment"})},copyPath:function(){wx.setClipboardData({data:"pages/msg/list/list?id="+this.data.pageId,success:function(){wx.hideLoading(),wx.showToast({title:"互动卡路径复制成功",icon:"none"})}})},onPageScroll:function(t){t.scrollTop>400&&!this.data.backTop?this.setData({backTop:!0}):t.scrollTop<=400&&this.data.backTop&&this.setData({backTop:!1})},backTop:function(){wx.pageScrollTo({scrollTop:0,duration:300})},closeNoticeBar:function(t){this.data.info.authorNoticeRead||d.doc(this.data.info._id).update({data:{authorNoticeRead:!0}})},readOrigin:function(){this.data.info.originUrl?wx.navigateTo({url:"/pages/webview/webview?url="+this.data.info.originUrl}):wx.showToast({title:"作者未设置原文链接！",icon:"none",duration:3e3})},diyAvatar:function(){wx.navigateToMiniProgram({appId:"wx1ab41a14fa705d27"})},allMsg:function(){var t=this;this.setData({onlyMe:!1,latest:!1,hot:!1},(function(){t.getData(!0)}))},onlyMe:function(){var t=this;this.setData({onlyMe:!0,latest:!1,hot:!1},(function(){t.getData(!0)}))},latest:function(){var t=this;this.setData({onlyMe:!1,latest:!0,hot:!1},(function(){t.getData(!0)}))},hot:function(){var t=this;this.setData({onlyMe:!1,latest:!1,hot:!0},(function(){t.getData(!0)}))},beginCopyText:function(t){var e=this.data.msgList[t.currentTarget.dataset.index];this.setData({currentItemId:e._id})},endCopyText:function(t){this.setData({currentItemId:""})},copyText:function(t){var e=this,a=["复制内容"];e.data.info.superAuth&&(a=["复制内容","违规隐藏"]);var i=e.data.msgList[t.currentTarget.dataset.index];wx.showActionSheet({alertText:i.text,itemList:a,success:function(t){0===t.tapIndex?wx.setClipboardData({data:i.text,success:function(){wx.hideLoading(),wx.showToast({title:"复制成功",icon:"none"})}}):r.doc(i._id).update({data:{isHide:!0}}).then((function(t){e.getData(!0)}))}}),e.data.currentItemId&&e.endCopyText()},beginCopyReply:function(t){var e=this.data.msgList[t.currentTarget.dataset.index];this.setData({currentReplyId:e._id})},endCopyReply:function(t){this.setData({currentReplyId:""})},copyReply:function(t){var e=this,a=["复制内容"];(e.data.info.superAuth||e.data.authority)&&(a=["复制内容","违规隐藏"]);var i=e.data.msgList[t.currentTarget.dataset.index];wx.showActionSheet({alertText:i.reply,itemList:a,success:function(t){0===t.tapIndex?wx.setClipboardData({data:i.reply,success:function(){wx.hideLoading(),wx.showToast({title:"复制成功",icon:"none"})}}):r.doc(i._id).update({data:{replyIsHide:!0}}).then((function(t){e.getData(!0)}))}}),e.data.currentReplyId&&e.endCopyReply()},beginCopyFloor:function(t){var e=this.data.msgList[t.currentTarget.dataset.index],a=t.currentTarget.dataset.item;this.setData({currentFloorId:e._id+a})},endCopyFloor:function(t){this.setData({currentFloorId:""})},copyFloor:function(t){var e=this,a=["复制内容"];(e.data.info.superAuth||e.data.authority)&&(a=["复制内容","违规隐藏"]);var i=e.data.msgList[t.currentTarget.dataset.index],n=t.currentTarget.dataset.floor;wx.showActionSheet({alertText:n,itemList:a,success:function(a){if(0===a.tapIndex)wx.setClipboardData({data:n,success:function(){wx.hideLoading(),wx.showToast({title:"复制成功",icon:"none"})}});else{var o={};o["floor"+t.currentTarget.dataset.item+"IsHide"]=!0,r.doc(i._id).update({data:o}).then((function(t){e.getData(!0)}))}}}),e.data.currentFloorId&&e.endCopyFloor()},textEmojiShow:function(){this.setData({textEmoji:!this.data.textEmoji}),this.data.textEmoji||this.setData({toMsgFocus:!0})},textFocus:function(){this.setData({textEmoji:!1})},textBlur:function(t){this.setData({textCursor:t.detail.cursor})},textInsertEmoji:function(t){var e=t.currentTarget.dataset.name,a=e.length,i=this.data.textCursor,n=this.data.text,o=n.slice(0,i)+e+n.slice(i);this.setData({text:o,textCursor:i+a})},replyEmojiShow:function(){this.setData({replyEmoji:!this.data.replyEmoji}),this.data.replyEmoji||this.setData({replyFocus:!0})},replyFocus:function(){this.setData({replyEmoji:!1})},replyBlur:function(t){this.setData({replyCursor:t.detail.cursor})},replyInsertEmoji:function(t){var e=t.currentTarget.dataset.name,a=e.length,i=this.data.replyCursor,n=this.data.reply,o=n.slice(0,i)+e+n.slice(i);this.setData({reply:o,replyCursor:i+a})},showDeal:function(t){var e=this,a=this.data.msgList[t.currentTarget.dataset.index];this.setData({selectMsgInfo:a},(function(){if(e.data.authority)(i=JSON.parse(JSON.stringify(e.data.dealActionsInit)))[0].name=a.top?"取消置顶":"置顶",i[2].name=a.status?"取消审核":"审核",e.setData({dealActions:i,showDeal:!0,_index:t.currentTarget.dataset.index});else if(a._openid==e.data.userId){var i;delete(i=JSON.parse(JSON.stringify(e.data.dealActionsInit)))[0],delete i[2],a.status||delete i[1],a.reply||e.data.authority||delete i[1],e.setData({dealActions:i,showDeal:!0,_index:t.currentTarget.dataset.index})}}))},hideDeal:function(){this.setData({showDeal:!1})},onSelect:function(t){var e=this;switch(t.detail.index){case 0:e.toTop();break;case 1:e.showRe();break;case 2:e.toCheck();break;case 3:wx.showModal({title:"提示",content:"确定删除该互动吗",success:function(t){t.confirm&&e.delect()}})}},toCheck:function(t){var e=this;this.data.selectMsgInfo.status?(wx.showLoading({title:"取消审核中",mask:!0}),wx.cloud.callFunction({name:"notCheck",data:{id:this.data.selectMsgInfo._id}}).then((function(t){wx.hideLoading();var a=e.data.selectMsgInfo;a.status=!1;var i=e.data.msgList;i[e.data._index]=a,e.setData({msgList:i}),wx.showToast({title:"取消审核成功",icon:"success"})}))):(wx.showLoading({title:"审核中",mask:!0}),wx.cloud.callFunction({name:"toCheck",data:{id:this.data.selectMsgInfo._id}}).then((function(t){wx.hideLoading();var a=e.data.selectMsgInfo;a.status=!0;var i=e.data.msgList;i[e.data._index]=a,e.setData({msgList:i}),wx.showToast({title:"审核成功",icon:"success"})})))},toTop:function(t){var e=this;this.data.selectMsgInfo.top?(wx.showLoading({title:"取消置顶中",mask:!0}),wx.cloud.callFunction({name:"notTop",data:{id:this.data.selectMsgInfo._id}}).then((function(t){wx.hideLoading(),wx.showToast({title:"取消置顶成功",icon:"success",success:function(t){e.getData(!0)}})}))):(wx.showLoading({title:"置顶中",mask:!0}),wx.cloud.callFunction({name:"toTop",data:{id:this.data.selectMsgInfo._id}}).then((function(t){wx.hideLoading(),wx.showToast({title:"置顶成功",icon:"success",success:function(t){e.getData(!0)}})})))},deleteSelf:function(t){var e=this;e.setData({selectMsgInfo:e.data.msgList[t.currentTarget.dataset.index],_index:t.currentTarget.dataset.index}),wx.showModal({title:"提示",content:"确定删除你的这条互动吗",success:function(t){t.confirm&&e.delect()}})},delect:function(t){var e=this;wx.showLoading({title:"删除中",mask:!0}),wx.cloud.callFunction({name:"delect",data:{id:this.data.selectMsgInfo._id}}).then((function(t){wx.hideLoading();var a=e.data.msgList;a.splice(e.data._index,1),e.setData({msgList:a}),wx.showToast({title:"删除成功",icon:"success"}),d.doc(e.data.info._id).update({data:{msgCount:s.inc(-1)}})}))},toWrite:function(){this.data.info.isForbid?wx.showToast({title:"该互动卡违规被禁访！",icon:"none"}):this.data.info.fromMsgcard?wx.openEmbeddedMiniProgram({path:"/pages/msg/list/list?id="+this.data.info._id,appId:"wx4faaf21bf014cd33"}):this.showPopup()},getUserInfo:function(){var t=this;wx.cloud.callFunction({name:"login",complete:function(e){var a=e.result;t.setData({userInfo:a})}})},authentication:function(){var t=this,e=this;wx.cloud.callFunction({name:"getDataWithTapGood",data:{id:e.data.pageId,db:"msgpages"}}).then((function(a){e.setData({show:!0});var i=a.result.data[0];if(i){i.isForbid&&(i.name="该互动卡违规被禁访！");var n=i._openid==i.userId;e.setData({userId:i.userId,info:i,title:i.name,authority:n},(function(){c.where({_openid:s.eq(i._openid)}).field({avatarUrl:!0,nickName:!0,unionid:!0,_openid:!0,_id:!0,xzffw_openid:!0}).get({success:function(t){t.data.length>0&&e.setData({author:t.data[0]},(function(){e.getData()}))}}),wx.setNavigationBarTitle({title:i.name})})),wx.cloud.callFunction({name:"simpleHistory",data:{type:1,name:i.name,path:"/pages/msg/list/list?id="+i._id}}).then((function(t){}))}else t.setData({absent:!0}),e.setData({title:"互动卡不存在"}),wx.setNavigationBarTitle({title:"互动卡不存在"})}))},reSubmit:function(){var t=this;this.data.reply?(wx.showLoading({title:"内容检测中",mask:!0}),wx.cloud.callFunction({name:"msgSecCheck",data:{content:t.data.reply,type:"message",pageId:t.data.pageId}}).then((function(e){wx.hideLoading(),0==e.result.errCode?t.reSubmitDo():wx.showToast({title:"内容存在违法违规风险，请重新输入！",icon:"none",duration:3e3})}))):wx.showToast({title:"请输入回复内容！",icon:"none"})},reSubmitDo:function(){var t=this;wx.showLoading({title:"回复中",mask:!0});var e=JSON.parse(JSON.stringify(this.data.selectMsgInfo)),a=e.floorNumber,i=this.data.reply.replace(new RegExp("\n","g"),"<br/>");if(a){a=a+1;e.floorNumber=a,e["floor"+a]=i,e["floor"+a+"Type"]=this.data.authority?1:2}else e.reply?(e.floorNumber=1,e.floor1=i,e.floor1Type=this.data.authority?1:2):e.reply=i;wx.cloud.callFunction({name:"reply",data:e}).then((function(a){wx.hideLoading();var n=t.data.msgList;n[t.data._index]=e,t.setData({reply:"",showRe:!1,numberReply:0,msgList:n}),t.closeRe(),wx.showToast({title:"回复成功",icon:"success"}),t.data.authority?wx.cloud.callFunction({name:"sendNotify",data:{type:2,toUser:e._openid,pageId:t.data.info._id,pageName:"互动卡："+t.data.title,text:t.data.selectMsgInfo.text,reply:i,createTime:t.formatTime(new Date)}}).then((function(t){})):wx.cloud.callFunction({name:"sendNotify",data:{type:3,pageId:t.data.info._id,pageName:t.data.title,userName:t.data.selectMsgInfo.name,text:i,createTime:t.formatTime(new Date),unionid:t.data.author.unionid,openid:t.data.author._openid,msgId:e._id}}).then((function(t){console.log(t)}))}))},attention:function(){wx.navigateTo({url:"/pages/methodD/methodD?id=5"})},onSubmit:function(t){var e=this,a=e.data.text.replace(/<\/?.+?>/g,"").replace(/ /g,"");a.replace(/\s+/g,"")?(wx.showLoading({title:"内容检测中",mask:!0}),wx.cloud.callFunction({name:"msgSecCheck",data:{content:a,type:"message",pageId:e.data.pageId}}).then((function(t){wx.hideLoading(),0==t.result.errCode?e.onSubmitDo():wx.showToast({title:"内容存在违法违规风险，请重新输入！",icon:"none",duration:3e3})}))):wx.showToast({title:"请输入互动内容！",icon:"none"})},onImageCropperConfirm:function(t,e){var a=this;if(t){var i=t,n=a.data.saveusertype,o=1==n?a.data.userInfo:a.data.author;e=e||i.substr(i.lastIndexOf("."));var r="avatar/"+o._openid+"/"+(new Date).getTime()+e;wx.showLoading({title:"头像上传中",mask:!0}),h.postObject({Bucket:"lg-h5g2gu1y-1257150849",Region:"ap-shanghai",Key:r,FilePath:i},(function(t,e){e?c.where({_openid:s.eq(o._openid)}).update({data:{avatarUrl:e.Location.replace("lg-h5g2gu1y-1257150849.cos.ap-shanghai.myqcloud.com","cos.wsqytec.com"),unionid:o.unionid?o.unionid:o.reAuth.unionid}}).then((function(t){wx.hideLoading(),o.avatarUrl=e.Location.replace("lg-h5g2gu1y-1257150849.cos.ap-shanghai.myqcloud.com","cos.wsqytec.com"),o.unionid=o.unionid?o.unionid:o.reAuth.unionid,1==n?a.setData({userInfo:o},(function(){wx.showToast({title:"头像保存成功",icon:"none"}),a.data.authority&&a.setData({author:o})})):a.setData({author:o},(function(){wx.showToast({title:"头像保存成功",icon:"none"}),a.data.authority&&a.setData({userInfo:o})}))})):(wx.hideLoading(),wx.showToast({title:"头像上传失败",icon:"none"}),a.initCOS())}))}},chooseAvatar:function(t){var e=t.currentTarget.dataset.usertype,a=this;wx.chooseMedia({count:1,mediaType:["image"],sizeType:["compressed"],sourceType:["album","camera"],success:function(t){var i=t.tempFiles[0].tempFilePath;a.saveAvatar({detail:{avatarUrl:i},currentTarget:{dataset:{usertype:e}}})}})},saveAvatar:function(t){var e=t.currentTarget.dataset.usertype,a=t.detail.avatarUrl;if(this.setData({saveusertype:e}),t.type){var i=a.substr(a.lastIndexOf("."));this.onImageCropperConfirm(a,i)}else wx.navigateTo({url:"/vantPage/image-cropper/image-cropper?initSrc="+a})},saveNickName:function(t){var e=t.currentTarget.dataset.usertype,a=this,i=t.detail.value,n=1==e?a.data.userInfo:a.data.author;i&&n.nickName!=i&&(wx.showLoading({title:"昵称检测中",mask:!0}),wx.cloud.callFunction({name:"msgSecCheck",data:{content:i}}).then((function(t){wx.hideLoading(),0==t.result.errCode?c.where({_openid:s.eq(n._openid)}).update({data:{nickName:i,unionid:n.unionid?n.unionid:n.reAuth.unionid}}).then((function(t){n.nickName=i,n.unionid=n.unionid?n.unionid:n.reAuth.unionid,1==e?a.setData({userInfo:n},(function(){wx.showToast({title:"昵称保存成功",icon:"none"}),a.data.authority&&a.setData({author:n})})):a.setData({author:n},(function(){wx.showToast({title:"昵称保存成功",icon:"none"}),a.data.authority&&a.setData({userInfo:n})}))})):wx.showToast({title:"昵称存在违法违规风险，请重新输入！",icon:"none",duration:3e3})})))},onSubmitDo:function(){var t=this,e=t.data.text,a=t.data.secret,i=t.data.anonymous;if(e){var n=t.formatTime(new Date),o={imageSrc:t.data.userInfo.avatarUrl,name:t.data.userInfo.nickName,text:e.replace(new RegExp("\n","g"),"<br/>"),secret:a,anonymous:i,pageId:t.data.pageId,status:!!a||!t.data.info.isCheck,createTime:n,goodCount:0,_openid:t.data.userId};wx.showLoading({title:"互动中",mask:!0}),r.add({data:o}).then((function(a){wx.hideLoading();var i="互动成功,审核后才会显示";(!t.data.info.isCheck||t.data.authority||t.data.onlyMe)&&(i="互动成功",t.getData(!0)),t.setData({text:"",secret:!1,anonymous:!1,numberText:0}),t.onClosePopupMsg(),wx.showToast({title:i,icon:"none",duration:3e3}),d.doc(t.data.info._id).update({data:{msgCount:s.inc(1)}}),wx.cloud.callFunction({name:"sendNotify",data:{type:3,pageId:t.data.info._id,pageName:t.data.title,userName:t.data.userInfo.nickName,text:e,createTime:n,unionid:t.data.author.unionid,openid:t.data.author._openid,msgId:a._id}}).then((function(t){console.log(t)})),a._id&&wx.cloud.callFunction({name:"addIpProvince",data:{db:"message",id:a._id}})}))}},addNotify:(n=a(e().mark((function t(a){var i,n;return e().wrap((function(t){for(;;)switch(t.prev=t.next){case 0:if(wx.showLoading({title:"提交中",mask:!0}),i=this,2!=(n=a.currentTarget.dataset.type)||!i.data.authority){t.next=10;break}if(wx.hideLoading(),i.data.author.nickName&&i.data.author.avatarUrl){t.next=8;break}return wx.showToast({title:"先点击完善左上角昵称和头像",icon:"none",duration:2500}),t.abrupt("return");case 8:return i.reSubmit(),t.abrupt("return");case 10:if(!(1==n&&i.data.info.perLimit&&i.data.info.perLimit>0)){t.next=18;break}return t.next=13,wx.cloud.callFunction({name:"getData",data:{id:i.data.pageId,db:"message",pageUserId:i.data.info._openid,pageNum:0,pageSize:20,onlyMe:!0}});case 13:if(!(t.sent.result.data.length>=i.data.info.perLimit)){t.next=18;break}return wx.hideLoading(),wx.showToast({title:"管理员限制单人可互动次数为"+i.data.info.perLimit+"次！",icon:"none",duration:3e3}),t.abrupt("return");case 18:if(1!=n){t.next=25;break}if(i.data.text){t.next=22;break}return wx.showToast({title:"内容不能为空",icon:"none"}),t.abrupt("return");case 22:if(i.data.userInfo.nickName&&i.data.userInfo.avatarUrl){t.next=25;break}return wx.showToast({title:"先点击完善左上角昵称和头像",icon:"none",duration:2500}),t.abrupt("return");case 25:wx.hideLoading(),wx.requestSubscribeMessage({tmplIds:["zaQ3x3ulTkJQfM0W4Vzyj1kIFDFp4B7GXS16Q4lJbX0"],complete:function(t){1==n?i.onSubmit():2==n&&i.reSubmit()}});case 28:case"end":return t.stop()}}),t,this)}))),function(t){return n.apply(this,arguments)}),tapGoodDo:function(t){var e=this.data.goodIndex,a=this.data.msgList[e],i=a.goodCount;null==i&&(i=0),-1==t?(a.goodCount=0==i?0:i-1,a.myGoodCount=0):(a.goodCount=i+1,a.myGoodCount=a.myGoodCount+1);var n=this.data.msgList;n[e]=a,this.setData({msgList:n}),wx.cloud.callFunction({name:"tapGoodToggle",data:{id:a._id}})},tapGood:(i=a(e().mark((function t(a){var i;return e().wrap((function(t){for(;;)switch(t.prev=t.next){case 0:(i=this).setData({goodIndex:a.currentTarget.dataset.index}),0==i.data.msgList[i.data.goodIndex].myGoodCount?i.tapGoodDo(1):i.tapGoodDo(-1);case 4:case"end":return t.stop()}}),t,this)}))),function(t){return i.apply(this,arguments)}),getAll:function(){var t=this;this.setData({msgId:""},(function(){t.getData(!0)}))},getData:function(t){if(wx.stopPullDownRefresh(),!this.data.absent){var e=this;e.setData({showNavBarLoding:!0},(function(){wx.showNavigationBarLoading&&wx.showNavigationBarLoading()})),1==t&&e.setData({pageNum:1,allShow:!1}),e.data.info.isForbid?e.setData({allShow:!0,msgList:[],showNavBarLoding:!1},(function(){wx.hideNavigationBarLoading&&wx.hideNavigationBarLoading()})):e.data.info._openid&&wx.cloud.callFunction({name:"getDataWithTapGood",data:{id:e.data.pageId,db:"message",pageUserId:e.data.info._openid,pageNum:e.data.pageNum,pageSize:e.data.pageSize,onlyMe:e.data.onlyMe,latest:e.data.latest,hot:e.data.hot,msgId:e.data.msgId}}).then((function(a){if(0==a.result.data.length&&e.setData({allShow:!0}),t)e.setData({msgList:a.result.data});else{var i=e.data.msgList?e.data.msgList:[];e.setData({msgList:i.concat(a.result.data)})}e.setData({showNavBarLoding:!1},(function(){wx.hideNavigationBarLoading&&wx.hideNavigationBarLoading()}))}))}},toNotice:function(){var t="/pages/webview/webview?url="+encodeURIComponent("https://zhijiebohao-4gp9aizse6797bd3-1257150849.tcloudbaseapp.com/gzh.html?miniAppId=wx5c9674e6177b0f6a&miniEnvId=zhijiebohao-4gp9aizse6797bd3&authorized="+(!(!this.data.author||!this.data.author.xzffw_openid)||"")+"&type=msg");wx.navigateTo({url:t})},onReachBottom:function(){this.data.allShow||(this.setData({pageNum:this.data.pageNum+1}),this.getData())},inputText:function(t){var e=t.detail.value,a=e.length;this.setData({numberText:a,text:e})},secretChange:function(t){this.setData({secret:!this.data.secret})},anonymousChange:function(t){this.setData({anonymous:!this.data.anonymous})},inputReply:function(t){var e=t.detail.value,a=e.length;this.setData({numberReply:a,reply:e})},showToMsgAfter:function(){var t=this,e=setTimeout((function(){clearTimeout(e),t.setData({showToMsgTextarea:!0},(function(){t.setData({toMsgFocus:!0})}))}),10)},showPopup:function(){var t=this;g.dealPrivacyPop((function(){t.setData({showToMsg:!0})}))},onClosePopupMsg:function(){this.setData({showToMsg:!1,toMsgFocus:!1,textCursor:0,textEmoji:!1})},showReplyAfter:function(){var t=this,e=setTimeout((function(){clearTimeout(e),t.setData({showReplyTextarea:!0},(function(){t.setData({replyFocus:!0})}))}),10)},showRe:function(t){if(this.data.selectMsgInfo.status)if(this.data.selectMsgInfo.reply||this.data.authority){var e=this;g.dealPrivacyPop((function(){e.setData({showReply:!0,replyMsgId:e.data.selectMsgInfo._id,reply:""})}))}else wx.showToast({title:"作者回复后才能继续回复！",icon:"none",duration:2500});else wx.showToast({title:"请先审核互动再回复！",icon:"none",duration:2500})},closeRe:function(){this.setData({showReply:!1,replyFocus:!1,reply:"",replyCursor:0,replyEmoji:!1})},onLoad:function(t){var e=this;g=this.selectComponent("#myPrivacy");var a=decodeURIComponent(t.q);if(a&&a.indexOf("?")>-1){var i=this.getQueryVariable(a.split("?")[1],"id");i&&(t.id=i)}t.scene&&(t.id=t.scene),t.id||(t.id="none");var n={pageId:t.id,msgId:t.msgId};t.fromReply&&(n.onlyMe=!0,n.latest=!1,n.hot=!1),this.setData(n,(function(){e.getUserInfo(),e.authentication()})),u.configParseEmoji({size:22});var o=this.data.systemInfo.windowWidth,s=o-80*(o/750),r=parseInt(s/40),d=4*r,c=110%d==0?110/d:parseInt(110/d)+1,l=Array.apply(null,{length:c}).map((function(t,e){return e})),h=(s-40*r)/(2*r);this.setData({emojiPageSize:d,emojiPageArr:l,emojiContainerMargin:h}),this.watch(this,{msgList:function(t){if(t){var e=[];t.forEach((function(t){var a=t.text,i=t.reply;a&&(a=u.parseEmoji(a)),i&&(i=u.parseEmoji(i));var n=JSON.parse(JSON.stringify(t));n.text=a,n.reply=i;var o=t.floorNumber;if(o)for(var s=1;s<=o;s++){var r="floor"+s;n[r]=u.parseEmoji(t[r])}e.push(n)})),this.setData({msgListTemp:e})}}}),1037==wx.getEnterOptionsSync().scene&&this.setData({isFromMini:!0}),this.initCOS()},initCOS:function(){wx.cloud.callFunction({name:"cosSts",complete:function(t){h=new l({getAuthorization:function(e,a){a({TmpSecretId:t.result.credentials.tmpSecretId,TmpSecretKey:t.result.credentials.tmpSecretKey,SecurityToken:t.result.credentials.sessionToken,StartTime:t.result.startTime,ExpiredTime:t.result.expiredTime})}})}})},onPullDownRefresh:function(){this.data.info.fromMsgcard?wx.stopPullDownRefresh():this.getData(!0)},onShareAppMessage:function(){return{title:this.data.title,path:"pages/msg/list/list?id="+this.data.info._id}},watch:function(t,e){var a=this;Object.keys(e).forEach((function(i){a.observer(t.data,i,t.data[i],(function(a){e[i].call(t,a)}))}))},observer:function(t,e,a,i){Object.defineProperty(t,e,{configurable:!0,enumerable:!0,get:function(){return a},set:function(t){i&&i(t),a=t}})},formatTime:function(e,a){if(e){switch(a||(a="yyyy-MM-dd HH:mm"),t(e)){case"string":var i=!1;e.indexOf("T")>-1&&e.indexOf("Z")>-1&&(i=!0,e=e.replace(/T/g," ").substring(0,e.lastIndexOf("."))),e=e.replace(/-/g,"/"),e=new Date(e),i&&(e=new Date(e.getTime()+288e5));break;case"number":e=new Date(e)}if(!(!e instanceof Date)){var n={yyyy:e.getFullYear(),M:e.getMonth()+1,d:e.getDate(),H:e.getHours(),m:e.getMinutes(),s:e.getSeconds(),MM:(""+(e.getMonth()+101)).substr(1),dd:(""+(e.getDate()+100)).substr(1),HH:(""+(e.getHours()+100)).substr(1),mm:(""+(e.getMinutes()+100)).substr(1),ss:(""+(e.getSeconds()+100)).substr(1)};return a.replace(/(yyyy|MM?|dd?|HH?|ss?|mm?)/g,(function(){return n[arguments[0]]}))}}},getQueryVariable:function(t,e){if(t)for(var a=t.split("&"),i=0;i<a.length;i++){var n=a[i].split("=");if(n[0].trim()==e.trim())return n[1].trim()}return!1},compareVersion:function(t,e){t=t.split("."),e=e.split(".");for(var a=Math.max(t.length,e.length);t.length<a;)t.push("0");for(;e.length<a;)e.push("0");for(var i=0;i<a;i++){var n=parseInt(t[i]),o=parseInt(e[i]);if(n>o)return 1;if(n<o)return-1}return 0}});
},{isPage:true,isComponent:true,currentFile:'pages/msg/list/list.js'});require("pages/msg/list/list.js");