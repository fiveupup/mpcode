$gwx_XC_32=function(_,_v,_n,_p,_s,_wp,_wl,$gwn,$gwl,$gwh,wh,$gstack,$gwrt,gra,grb,TestTest,wfor,_ca,_da,_r,_rz,_o,_oz,_1,_1z,_2,_2z,_m,_mz,nv_getDate,nv_getRegExp,nv_console,nv_parseInt,nv_parseFloat,nv_isNaN,nv_isFinite,nv_decodeURI,nv_decodeURIComponent,nv_encodeURI,nv_encodeURIComponent,$gdc,nv_JSON,_af,_gv,_ai,_grp,_gd,_gapi,$ixc,_ic,_w,_ev,_tsd){return function(path,global){
if(typeof global==='undefined'){if (typeof __GWX_GLOBAL__==='undefined')global={};else global=__GWX_GLOBAL__;}if(typeof __WXML_GLOBAL__ === 'undefined') {__WXML_GLOBAL__={};
}__WXML_GLOBAL__.modules = __WXML_GLOBAL__.modules || {};
var e_={}
if(typeof(global.entrys)==='undefined')global.entrys={};e_=global.entrys;
var d_={}
if(typeof(global.defines)==='undefined')global.defines={};d_=global.defines;
var f_={}
if(typeof(global.modules)==='undefined')global.modules={};f_=global.modules || {};
var p_={}
__WXML_GLOBAL__.ops_cached = __WXML_GLOBAL__.ops_cached || {}
__WXML_GLOBAL__.ops_set = __WXML_GLOBAL__.ops_set || {};
__WXML_GLOBAL__.ops_init = __WXML_GLOBAL__.ops_init || {};
var z=__WXML_GLOBAL__.ops_set.$gwx_XC_32 || [];
function gz$gwx_XC_32_1(){
if( __WXML_GLOBAL__.ops_cached.$gwx_XC_32_1)return __WXML_GLOBAL__.ops_cached.$gwx_XC_32_1
__WXML_GLOBAL__.ops_cached.$gwx_XC_32_1=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
Z([[7],[3,'userInfo']])
Z([3,'position:relative;display:flex;align-items:center;justify-content:center;flex-direction: column;padding-top:30rpx;'])
Z([[2,'>='],[[12],[[6],[[7],[3,'msgutil']],[3,'compareVersion']],[[5],[[5],[[6],[[7],[3,'systemInfo']],[3,'SDKVersion']]],[1,'2.24.4']]],[1,0]])
Z([3,'saveAvatar'])
Z([3,'clear-button-style'])
Z([3,'1'])
Z([3,'chooseAvatar'])
Z([3,'flex-shrink:0;'])
Z([[2,'&&'],[[7],[3,'userInfo']],[[6],[[7],[3,'userInfo']],[3,'avatarUrl']]])
Z([3,'my-icon'])
Z([3,'#969696'])
Z([3,'xiugaitouxiang'])
Z([3,'44rpx'])
Z(z[6])
Z(z[4])
Z(z[5])
Z(z[7])
Z(z[8])
Z(z[9])
Z(z[10])
Z(z[11])
Z(z[12])
Z([[6],[[7],[3,'userInfo']],[3,'phone']])
Z([[7],[3,'addNotice']])
Z([3,'readNotice'])
Z([3,'volume-o'])
Z([3,'closeable'])
Z([1,true])
Z(z[23])
Z([[2,'&&'],[[7],[3,'group0']],[[2,'>'],[[6],[[7],[3,'group0']],[3,'length']],[1,0]]])
Z([3,'index'])
Z([3,'method'])
Z([[7],[3,'group0']])
Z(z[30])
Z([[2,'||'],[[2,'||'],[[2,'||'],[[2,'||'],[[2,'||'],[[2,'=='],[[6],[[7],[3,'method']],[3,'type']],[1,1]],[[2,'=='],[[6],[[7],[3,'method']],[3,'type']],[1,2]]],[[2,'=='],[[6],[[7],[3,'method']],[3,'type']],[1,5]]],[[2,'=='],[[6],[[7],[3,'method']],[3,'type']],[1,6]]],[[2,'=='],[[6],[[7],[3,'method']],[3,'type']],[1,9]]],[[2,'=='],[[6],[[7],[3,'method']],[3,'type']],[1,10]]])
Z([3,'toMethod'])
Z([[4],[[5],[[5],[1,'li']],[[2,'?:'],[[2,'=='],[[7],[3,'index']],[[2,'-'],[[6],[[7],[3,'group0']],[3,'length']],[1,1]]],[1,'noborder'],[1,'']]]])
Z([1,0])
Z([[7],[3,'index']])
Z([3,'hover'])
Z([[6],[[7],[3,'method']],[3,'icon']])
Z([[2,'||'],[[2,'||'],[[2,'||'],[[2,'=='],[[6],[[7],[3,'method']],[3,'type']],[1,3]],[[2,'=='],[[6],[[7],[3,'method']],[3,'type']],[1,4]]],[[2,'=='],[[6],[[7],[3,'method']],[3,'type']],[1,7]]],[[2,'=='],[[6],[[7],[3,'method']],[3,'type']],[1,8]]])
Z(z[40])
Z([[2,'>'],[[6],[[7],[3,'group0']],[3,'length']],[[2,'+'],[[7],[3,'index']],[1,1]]])
Z([[2,'&&'],[[7],[3,'group1']],[[2,'>'],[[6],[[7],[3,'group1']],[3,'length']],[1,0]]])
Z(z[30])
Z(z[31])
Z([[7],[3,'group1']])
Z(z[30])
Z(z[34])
Z(z[35])
Z([[4],[[5],[[5],[1,'li']],[[2,'?:'],[[2,'=='],[[7],[3,'index']],[[2,'-'],[[6],[[7],[3,'group1']],[3,'length']],[1,1]]],[1,'noborder'],[1,'']]]])
Z([1,1])
Z(z[38])
Z(z[39])
Z(z[40])
Z(z[41])
Z(z[40])
Z([[2,'>'],[[6],[[7],[3,'group1']],[3,'length']],[[2,'+'],[[7],[3,'index']],[1,1]]])
Z([[2,'&&'],[[7],[3,'group2']],[[2,'>'],[[6],[[7],[3,'group2']],[3,'length']],[1,0]]])
Z(z[30])
Z(z[31])
Z([[7],[3,'group2']])
Z(z[30])
Z([[2,'||'],[[2,'||'],[[2,'||'],[[2,'||'],[[2,'||'],[[2,'=='],[[6],[[7],[3,'method']],[3,'type']],[1,1]],[[2,'=='],[[6],[[7],[3,'method']],[3,'type']],[1,2]]],[[2,'=='],[[6],[[7],[3,'method']],[3,'type']],[1,5]]],[[2,'=='],[[6],[[7],[3,'method']],[3,'type']],[1,6]]],[[2,'=='],[[6],[[7],[3,'method']],[3,'type']],[1,9]]],[[2,'=='],[[6],[[7],[3,'method']],[3,'type']],[1,10]]])
Z(z[35])
Z([[4],[[5],[[5],[1,'li']],[[2,'?:'],[[2,'=='],[[7],[3,'index']],[[2,'-'],[[6],[[7],[3,'group2']],[3,'length']],[1,1]]],[1,'noborder'],[1,'']]]])
Z([1,2])
Z(z[38])
Z(z[39])
Z(z[40])
Z(z[41])
Z(z[40])
Z([[2,'>'],[[6],[[7],[3,'group2']],[3,'length']],[[2,'+'],[[7],[3,'index']],[1,1]]])
Z([[2,'&&'],[[7],[3,'group3']],[[2,'>'],[[6],[[7],[3,'group3']],[3,'length']],[1,0]]])
Z(z[30])
Z(z[31])
Z([[7],[3,'group3']])
Z(z[30])
Z(z[64])
Z(z[35])
Z([[4],[[5],[[5],[1,'li']],[[2,'?:'],[[2,'=='],[[7],[3,'index']],[[2,'-'],[[6],[[7],[3,'group3']],[3,'length']],[1,1]]],[1,'noborder'],[1,'']]]])
Z([1,3])
Z(z[38])
Z(z[39])
Z(z[40])
Z(z[41])
Z(z[40])
Z([[2,'>'],[[6],[[7],[3,'group3']],[3,'length']],[[2,'+'],[[7],[3,'index']],[1,1]]])
Z([[2,'&&'],[[7],[3,'group4']],[[2,'>'],[[6],[[7],[3,'group4']],[3,'length']],[1,0]]])
Z(z[30])
Z(z[31])
Z([[7],[3,'group4']])
Z(z[30])
Z(z[64])
Z(z[35])
Z([[4],[[5],[[5],[1,'li']],[[2,'?:'],[[2,'=='],[[7],[3,'index']],[[2,'-'],[[6],[[7],[3,'group4']],[3,'length']],[1,1]]],[1,'noborder'],[1,'']]]])
Z([1,4])
Z(z[38])
Z(z[39])
Z(z[40])
Z(z[41])
Z(z[40])
Z([[2,'>'],[[6],[[7],[3,'group4']],[3,'length']],[[2,'+'],[[7],[3,'index']],[1,1]]])
Z([[2,'&&'],[[7],[3,'methodList']],[[2,'>'],[[6],[[7],[3,'methodList']],[3,'length']],[1,0]]])
Z([3,'center'])
Z([3,'margin:0 20%;'])
Z([3,'clickAgree'])
Z([3,'getPhoneNumber'])
Z([3,'取消'])
Z([3,'#07c160'])
Z([[2,'?:'],[[7],[3,'clickAgree']],[1,'getPhoneNumber'],[1,'']])
Z([3,'确定'])
Z([[7],[3,'showPhone']])
Z([a,[[2,'?:'],[[6],[[7],[3,'userInfo']],[3,'phone']],[1,'更换'],[1,'绑定']],[3,'手机号']])
Z([3,'myPrivacy'])
Z(z[27])
})(__WXML_GLOBAL__.ops_cached.$gwx_XC_32_1);return __WXML_GLOBAL__.ops_cached.$gwx_XC_32_1
}
__WXML_GLOBAL__.ops_set.$gwx_XC_32=z;
__WXML_GLOBAL__.ops_init.$gwx_XC_32=true;
var x=['./pages/work/method.wxml'];d_[x[0]]={}
var m0=function(e,s,r,gg){
var z=gz$gwx_XC_32_1()
var o2L=_v()
_(r,o2L)
if(_oz(z,0,e,s,gg)){o2L.wxVkey=1
var a0L=_n('view')
_rz(z,a0L,'style',1,e,s,gg)
var tAM=_v()
_(a0L,tAM)
if(_oz(z,2,e,s,gg)){tAM.wxVkey=1
var bCM=_mz(z,'button',['bind:chooseavatar',3,'class',1,'data-usertype',2,'openType',3,'style',4],[],e,s,gg)
var oDM=_v()
_(bCM,oDM)
if(_oz(z,8,e,s,gg)){oDM.wxVkey=1
}
else{oDM.wxVkey=2
var xEM=_mz(z,'van-icon',['classPrefix',9,'color',1,'name',2,'size',3],[],e,s,gg)
_(oDM,xEM)
}
oDM.wxXCkey=1
oDM.wxXCkey=3
_(tAM,bCM)
}
else{tAM.wxVkey=2
var oFM=_mz(z,'button',['bindtap',13,'class',1,'data-usertype',2,'style',3],[],e,s,gg)
var fGM=_v()
_(oFM,fGM)
if(_oz(z,17,e,s,gg)){fGM.wxVkey=1
}
else{fGM.wxVkey=2
var cHM=_mz(z,'van-icon',['classPrefix',18,'color',1,'name',2,'size',3],[],e,s,gg)
_(fGM,cHM)
}
fGM.wxXCkey=1
fGM.wxXCkey=3
_(tAM,oFM)
}
var eBM=_v()
_(a0L,eBM)
if(_oz(z,22,e,s,gg)){eBM.wxVkey=1
}
tAM.wxXCkey=1
tAM.wxXCkey=3
tAM.wxXCkey=3
eBM.wxXCkey=1
_(o2L,a0L)
}
else{o2L.wxVkey=2
}
var f3L=_v()
_(r,f3L)
if(_oz(z,23,e,s,gg)){f3L.wxVkey=1
var hIM=_mz(z,'van-notice-bar',['bind:close',24,'leftIcon',1,'mode',2,'scrollable',3,'text',4],[],e,s,gg)
_(f3L,hIM)
}
var c4L=_v()
_(r,c4L)
if(_oz(z,29,e,s,gg)){c4L.wxVkey=1
var oJM=_v()
_(c4L,oJM)
var cKM=function(lMM,oLM,aNM,gg){
var ePM=_v()
_(aNM,ePM)
if(_oz(z,34,lMM,oLM,gg)){ePM.wxVkey=1
var xSM=_mz(z,'view',['bindtap',35,'class',1,'data-group',2,'data-index',3,'hoverClass',4],[],lMM,oLM,gg)
var oTM=_v()
_(xSM,oTM)
if(_oz(z,40,lMM,oLM,gg)){oTM.wxVkey=1
}
oTM.wxXCkey=1
_(ePM,xSM)
}
var bQM=_v()
_(aNM,bQM)
if(_oz(z,41,lMM,oLM,gg)){bQM.wxVkey=1
var fUM=_v()
_(bQM,fUM)
if(_oz(z,42,lMM,oLM,gg)){fUM.wxVkey=1
}
fUM.wxXCkey=1
}
var oRM=_v()
_(aNM,oRM)
if(_oz(z,43,lMM,oLM,gg)){oRM.wxVkey=1
}
ePM.wxXCkey=1
bQM.wxXCkey=1
oRM.wxXCkey=1
return aNM
}
oJM.wxXCkey=2
_2z(z,32,cKM,e,s,gg,oJM,'method','index','index')
}
var h5L=_v()
_(r,h5L)
if(_oz(z,44,e,s,gg)){h5L.wxVkey=1
var cVM=_v()
_(h5L,cVM)
var hWM=function(cYM,oXM,oZM,gg){
var a2M=_v()
_(oZM,a2M)
if(_oz(z,49,cYM,oXM,gg)){a2M.wxVkey=1
var b5M=_mz(z,'view',['bindtap',50,'class',1,'data-group',2,'data-index',3,'hoverClass',4],[],cYM,oXM,gg)
var o6M=_v()
_(b5M,o6M)
if(_oz(z,55,cYM,oXM,gg)){o6M.wxVkey=1
}
o6M.wxXCkey=1
_(a2M,b5M)
}
var t3M=_v()
_(oZM,t3M)
if(_oz(z,56,cYM,oXM,gg)){t3M.wxVkey=1
var x7M=_v()
_(t3M,x7M)
if(_oz(z,57,cYM,oXM,gg)){x7M.wxVkey=1
}
x7M.wxXCkey=1
}
var e4M=_v()
_(oZM,e4M)
if(_oz(z,58,cYM,oXM,gg)){e4M.wxVkey=1
}
a2M.wxXCkey=1
t3M.wxXCkey=1
e4M.wxXCkey=1
return oZM
}
cVM.wxXCkey=2
_2z(z,47,hWM,e,s,gg,cVM,'method','index','index')
}
var o6L=_v()
_(r,o6L)
if(_oz(z,59,e,s,gg)){o6L.wxVkey=1
var o8M=_v()
_(o6L,o8M)
var f9M=function(hAN,c0M,oBN,gg){
var oDN=_v()
_(oBN,oDN)
if(_oz(z,64,hAN,c0M,gg)){oDN.wxVkey=1
var tGN=_mz(z,'view',['bindtap',65,'class',1,'data-group',2,'data-index',3,'hoverClass',4],[],hAN,c0M,gg)
var eHN=_v()
_(tGN,eHN)
if(_oz(z,70,hAN,c0M,gg)){eHN.wxVkey=1
}
eHN.wxXCkey=1
_(oDN,tGN)
}
var lEN=_v()
_(oBN,lEN)
if(_oz(z,71,hAN,c0M,gg)){lEN.wxVkey=1
var bIN=_v()
_(lEN,bIN)
if(_oz(z,72,hAN,c0M,gg)){bIN.wxVkey=1
}
bIN.wxXCkey=1
}
var aFN=_v()
_(oBN,aFN)
if(_oz(z,73,hAN,c0M,gg)){aFN.wxVkey=1
}
oDN.wxXCkey=1
lEN.wxXCkey=1
aFN.wxXCkey=1
return oBN
}
o8M.wxXCkey=2
_2z(z,62,f9M,e,s,gg,o8M,'method','index','index')
}
var c7L=_v()
_(r,c7L)
if(_oz(z,74,e,s,gg)){c7L.wxVkey=1
var oJN=_v()
_(c7L,oJN)
var xKN=function(fMN,oLN,cNN,gg){
var oPN=_v()
_(cNN,oPN)
if(_oz(z,79,fMN,oLN,gg)){oPN.wxVkey=1
var lSN=_mz(z,'view',['bindtap',80,'class',1,'data-group',2,'data-index',3,'hoverClass',4],[],fMN,oLN,gg)
var aTN=_v()
_(lSN,aTN)
if(_oz(z,85,fMN,oLN,gg)){aTN.wxVkey=1
}
aTN.wxXCkey=1
_(oPN,lSN)
}
var cQN=_v()
_(cNN,cQN)
if(_oz(z,86,fMN,oLN,gg)){cQN.wxVkey=1
var tUN=_v()
_(cQN,tUN)
if(_oz(z,87,fMN,oLN,gg)){tUN.wxVkey=1
}
tUN.wxXCkey=1
}
var oRN=_v()
_(cNN,oRN)
if(_oz(z,88,fMN,oLN,gg)){oRN.wxVkey=1
}
oPN.wxXCkey=1
cQN.wxXCkey=1
oRN.wxXCkey=1
return cNN
}
oJN.wxXCkey=2
_2z(z,77,xKN,e,s,gg,oJN,'method','index','index')
}
var o8L=_v()
_(r,o8L)
if(_oz(z,89,e,s,gg)){o8L.wxVkey=1
var eVN=_v()
_(o8L,eVN)
var bWN=function(xYN,oXN,oZN,gg){
var c2N=_v()
_(oZN,c2N)
if(_oz(z,94,xYN,oXN,gg)){c2N.wxVkey=1
var c5N=_mz(z,'view',['bindtap',95,'class',1,'data-group',2,'data-index',3,'hoverClass',4],[],xYN,oXN,gg)
var o6N=_v()
_(c5N,o6N)
if(_oz(z,100,xYN,oXN,gg)){o6N.wxVkey=1
}
o6N.wxXCkey=1
_(c2N,c5N)
}
var h3N=_v()
_(oZN,h3N)
if(_oz(z,101,xYN,oXN,gg)){h3N.wxVkey=1
var l7N=_v()
_(h3N,l7N)
if(_oz(z,102,xYN,oXN,gg)){l7N.wxVkey=1
}
l7N.wxXCkey=1
}
var o4N=_v()
_(oZN,o4N)
if(_oz(z,103,xYN,oXN,gg)){o4N.wxVkey=1
}
c2N.wxXCkey=1
h3N.wxXCkey=1
o4N.wxXCkey=1
return oZN
}
eVN.wxXCkey=2
_2z(z,92,bWN,e,s,gg,eVN,'method','index','index')
}
var l9L=_v()
_(r,l9L)
if(_oz(z,104,e,s,gg)){l9L.wxVkey=1
var a8N=_mz(z,'van-divider',['contentPosition',105,'customStyle',1],[],e,s,gg)
_(l9L,a8N)
}
var t9N=_mz(z,'van-dialog',['showCancelButton',-1,'useSlot',-1,'bind:confirm',107,'bind:getphonenumber',1,'cancelButtonText',2,'confirmButtonColor',3,'confirmButtonOpenType',4,'confirmButtonText',5,'show',6,'title',7],[],e,s,gg)
_(r,t9N)
var e0N=_mz(z,'my-privacy',['id',115,'requireFirst',1],[],e,s,gg)
_(r,e0N)
o2L.wxXCkey=1
o2L.wxXCkey=3
f3L.wxXCkey=1
f3L.wxXCkey=3
c4L.wxXCkey=1
h5L.wxXCkey=1
o6L.wxXCkey=1
c7L.wxXCkey=1
o8L.wxXCkey=1
l9L.wxXCkey=1
l9L.wxXCkey=3
return r
}
e_[x[0]]={f:m0,j:[],i:[],ti:[],ic:[]}
if(path&&e_[path]){
return function(env,dd,global){$gwxc=0;var root={"tag":"wx-page"};root.children=[]
;g="$gwx_XC_32";var main=e_[path].f
if (typeof global==="undefined")global={};global.f=$gdc(f_[path],"",1);
try{
main(env,{},root,global);
_tsd(root)
}catch(err){
console.log(err)
}
;g="";
return root;
}
}
}
}(__g.a,__g.b,__g.c,__g.d,__g.e,__g.f,__g.g,__g.h,__g.i,__g.j,__g.k,__g.l,__g.m,__g.n,__g.o,__g.p,__g.q,__g.r,__g.s,__g.t,__g.u,__g.v,__g.w,__g.x,__g.y,__g.z,__g.A,__g.B,__g.C,__g.D,__g.E,__g.F,__g.G,__g.H,__g.I,__g.J,__g.K,__g.L,__g.M,__g.N,__g.O,__g.P,__g.Q,__g.R,__g.S,__g.T,__g.U,__g.V,__g.W,__g.X,__g.Y,__g.Z,__g.aa);if(__vd_version_info__.delayedGwx||false)$gwx_XC_32();	if (__vd_version_info__.delayedGwx) __wxAppCode__['pages/work/method.wxml'] = [$gwx_XC_32, './pages/work/method.wxml'];else __wxAppCode__['pages/work/method.wxml'] = $gwx_XC_32( './pages/work/method.wxml' );
	;__wxRoute = "pages/work/method";__wxRouteBegin = true;__wxAppCurrentFile__="pages/work/method.js";define("pages/work/method.js",function(require,module,exports,window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){
"use strict";var e=require("../../@babel/runtime/helpers/regeneratorRuntime"),t=require("../../@babel/runtime/helpers/asyncToGenerator");wx.cloud.init();var o,a,n=wx.cloud.database({env:"zhijiebohao-4gp9aizse6797bd3"}),i=n.command,r=n.collection("user_inc_id"),s=n.collection("msg_user"),u=require("../../components/cos/cos-wx-sdk-v5.min"),c=void 0;Page({data:{showPhone:!1,addNotice:"",userInfo:void 0,methodList:[],group0:[],group1:[],group2:[],group3:[],group4:[],systemInfo:wx.getSystemInfoSync(),clickAgree:!1},clickAgreeChange:function(e){this.setData({clickAgree:!this.data.clickAgree})},showProtocol:function(){wx.navigateTo({url:"/pages/methodD/methodD?id=18"})},clearCache:function(){wx.showLoading({title:"清理中",mask:!0});var e=setTimeout((function(){wx.hideLoading(),wx.clearStorage({success:function(){wx.showToast({title:"清理成功",icon:"none"}),clearTimeout(e)}})}),1e3)},toNotice:function(){var e="/pages/webview/webview?url="+encodeURIComponent("https://zhijiebohao-4gp9aizse6797bd3-1257150849.tcloudbaseapp.com/gzh.html?miniAppId=wx5c9674e6177b0f6a&miniEnvId=zhijiebohao-4gp9aizse6797bd3&authorized="+(!(!this.data.userInfo||!this.data.userInfo.xzffw_openid)||""));wx.navigateTo({url:e})},toMethod:function(e){var t=e.currentTarget.dataset.index,o={};switch(e.currentTarget.dataset.group){case 0:o=this.data.group0[t];break;case 1:o=this.data.group1[t];break;case 2:o=this.data.group2[t];break;case 3:o=this.data.group3[t];break;case 4:o=this.data.group4[t]}1==o.type?o.name.indexOf("通知")>-1||o.name.indexOf("消息")>-1?this.toNotice():wx.navigateTo({url:o.url}):2==o.type?wx.navigateToMiniProgram({appId:o.content,path:o.url}):5==o.type?wx.switchTab({url:o.url}):6==o.type?wx.openCustomerServiceChat?wx.openCustomerServiceChat({extInfo:{url:o.url},corpId:o.content,success:function(e){},fail:function(e){wx.showToast({title:"请使用最新版手机微信重试",icon:"none"})}}):wx.showToast({title:"请使用最新版手机微信重试",icon:"none"}):9==o.type?wx.openEmbeddedMiniProgram({path:o.url,appId:o.content}):10==o.type&&wx.setClipboardData({data:o.content})},onLoad:(a=t(e().mark((function t(o){var a;return e().wrap((function(e){for(;;)switch(e.prev=e.next){case 0:a=this,wx.getStorage({key:"methodList",success:function(e){if(e.data){var t=JSON.parse(e.data),o=t.filter((function(e){return 0==e.group&&!e.onlyHome})),n=t.filter((function(e){return 1==e.group&&!e.onlyHome})),i=t.filter((function(e){return 2==e.group&&!e.onlyHome})),r=t.filter((function(e){return 3==e.group&&!e.onlyHome})),s=t.filter((function(e){return 4==e.group&&!e.onlyHome}));a.setData({methodList:t,group0:o,group1:n,group2:i,group3:r,group4:s})}}}),wx.getStorage({key:"userInfo",success:function(e){if(e.data){var t=JSON.parse(e.data);a.setData({userInfo:t})}}}),a.getMethodList(),wx.cloud.callFunction({name:"login",complete:function(e){var t=e.result;a.setData({userInfo:t}),wx.setStorage({key:"userInfo",data:JSON.stringify(t)}),t&&!t.readNotice&&r.where({_id:i.eq("notice")}).field({text:!0}).get({success:function(e){if(e&&e.data.length>0){var t=e.data[0];a.setData({addNotice:t.text})}}})}}),this.initCOS();case 6:case"end":return e.stop()}}),t,this)}))),function(e){return a.apply(this,arguments)}),readNotice:function(){var e=this;e.data.userInfo.readNotice||s.doc(e.data.userInfo._id).update({data:{readNotice:!0},success:function(t){e.setData({addNotice:""})}})},getMethodList:(o=t(e().mark((function t(){var o,a,r,s,u,c,d,l;return e().wrap((function(e){for(;;)switch(e.prev=e.next){case 0:return(o={}).status=i.eq(!0),e.next=4,n.collection("method_list").where(o).field({_id:!0,name:!0,content:!0,type:!0,url:!0,icon:!0,group:!0,isHome:!0,onlyHome:!0,homeIcon:!0,homeName:!0}).orderBy("sort","asc").get();case 4:a=e.sent,r=a.data,s=r.filter((function(e){return 0==e.group&&!e.onlyHome})),u=r.filter((function(e){return 1==e.group&&!e.onlyHome})),c=r.filter((function(e){return 2==e.group&&!e.onlyHome})),d=r.filter((function(e){return 3==e.group&&!e.onlyHome})),l=r.filter((function(e){return 4==e.group&&!e.onlyHome})),this.setData({methodList:r,group0:s,group1:u,group2:c,group3:d,group4:l}),wx.setStorage({key:"methodList",data:JSON.stringify(r)});case 13:case"end":return e.stop()}}),t,this)}))),function(){return o.apply(this,arguments)}),onImageCropperConfirm:function(e,t){var o=this;if(e){var a=e,n=o.data.saveusertype,r=1==n?o.data.userInfo:o.data.author;t=t||a.substr(a.lastIndexOf("."));var u="avatar/"+r._openid+"/"+(new Date).getTime()+t;wx.showLoading({title:"头像上传中",mask:!0}),c.postObject({Bucket:"lg-h5g2gu1y-1257150849",Region:"ap-shanghai",Key:u,FilePath:a},(function(e,t){t?s.where({_openid:i.eq(r._openid)}).update({data:{avatarUrl:t.Location.replace("lg-h5g2gu1y-1257150849.cos.ap-shanghai.myqcloud.com","cos.wsqytec.com"),unionid:r.unionid?r.unionid:r.reAuth.unionid}}).then((function(e){wx.hideLoading(),r.avatarUrl=t.Location.replace("lg-h5g2gu1y-1257150849.cos.ap-shanghai.myqcloud.com","cos.wsqytec.com"),r.unionid=r.unionid?r.unionid:r.reAuth.unionid,1==n?o.setData({userInfo:r},(function(){wx.showToast({title:"头像保存成功",icon:"none"}),o.data.authority&&o.setData({author:r})})):o.setData({author:r},(function(){wx.showToast({title:"头像保存成功",icon:"none"}),o.data.authority&&o.setData({userInfo:r})}))})):(wx.hideLoading(),wx.showToast({title:"头像上传失败",icon:"none"}),o.initCOS())}))}},chooseAvatar:function(e){var t=e.currentTarget.dataset.usertype,o=this;wx.chooseMedia({count:1,mediaType:["image"],sizeType:["compressed"],sourceType:["album","camera"],success:function(e){var a=e.tempFiles[0].tempFilePath;o.saveAvatar({detail:{avatarUrl:a},currentTarget:{dataset:{usertype:t}}})}})},saveAvatar:function(e){var t=e.currentTarget.dataset.usertype,o=e.detail.avatarUrl;if(this.setData({saveusertype:t}),e.type){var a=o.substr(o.lastIndexOf("."));this.onImageCropperConfirm(o,a)}else wx.navigateTo({url:"/vantPage/image-cropper/image-cropper?initSrc="+o})},saveNickName:function(e){var t=e.currentTarget.dataset.usertype,o=this,a=e.detail.value,n=1==t?o.data.userInfo:o.data.author;a&&n.nickName!=a&&(wx.showLoading({title:"昵称检测中",mask:!0}),wx.cloud.callFunction({name:"msgSecCheck",data:{content:a}}).then((function(e){wx.hideLoading(),0==e.result.errCode?s.where({_openid:i.eq(n._openid)}).update({data:{nickName:a,unionid:n.unionid?n.unionid:n.reAuth.unionid}}).then((function(e){n.nickName=a,n.unionid=n.unionid?n.unionid:n.reAuth.unionid,1==t?o.setData({userInfo:n},(function(){wx.showToast({title:"昵称保存成功",icon:"none"}),o.data.authority&&o.setData({author:n})})):o.setData({author:n},(function(){wx.showToast({title:"昵称保存成功",icon:"none"}),o.data.authority&&o.setData({userInfo:n})}))})):wx.showToast({title:"昵称存在违法违规风险，请重新输入！",icon:"none",duration:3e3})})))},initCOS:function(){wx.cloud.callFunction({name:"cosSts",complete:function(e){c=new u({getAuthorization:function(t,o){o({TmpSecretId:e.result.credentials.tmpSecretId,TmpSecretKey:e.result.credentials.tmpSecretKey,SecurityToken:e.result.credentials.sessionToken,StartTime:e.result.startTime,ExpiredTime:e.result.expiredTime})}})}})},toFoot:function(){wx.navigateTo({url:"/vantPage/simpleHistory/simpleHistory"})},toDetail:function(){wx.navigateTo({url:"/pages/webview/webview?id=3"})},toVipDetail:function(){wx.navigateTo({url:"/pages/webview/webview?id=20&unionId="+this.data.userInfo.unionid})},toHelp:function(){wx.navigateTo({url:"/vantPage/question/question"})},showPhone:function(){this.setData({showPhone:!0})},clickAgree:function(){if(!this.data.clickAgree)return wx.showToast({title:"请先阅读并勾选文件服务协议",icon:"none"}),void this.setData({showPhone:!0})},getPhoneNumber:function(e){var t=this;wx.hideLoading(),e.detail.cloudID&&(wx.showLoading({title:"获取中",mask:!0}),wx.cloud.callFunction({name:"login",data:{weRunData:wx.cloud.CloudID(e.detail.cloudID),code:!!e.detail.code&&e.detail.code}}).then((function(o){wx.hideLoading();var a=e.detail.code?o.result.phoneInfo.phoneNumber:o.result.event.weRunData.data.phoneNumber;wx.showLoading({title:"绑定中",mask:!0}),s.doc(t.data.userInfo._id).update({data:{phone:a,agreeProtocol:!0},success:function(e){wx.hideLoading();var o=t.data.userInfo;o.phone=a,o.agreeProtocol=!0,t.setData({userInfo:o}),wx.showToast({title:"绑定成功",icon:"none"})}})})))},deviceInfo:function(){wx.navigateTo({url:"/vantPage/deviceInfo/info"})},onPageScroll:function(e){e.scrollTop>200&&"小正方助手"!=this.navTitle?(this.navTitle="小正方助手",wx.setNavigationBarTitle({title:"小正方助手"})):e.scrollTop<=200&&""!=this.navTitle&&(this.navTitle="",wx.setNavigationBarTitle({title:""}))},onShareAppMessage:function(e){return{title:"专业的云服务平台，提供云文件、地址路径、安全通话等服务。",imageUrl:"cloud://zhijiebohao-4gp9aizse6797bd3.7a68-zhijiebohao-4gp9aizse6797bd3-1257150849/share-xzf.jpg"}},compareVersion:function(e,t){e=e.split("."),t=t.split(".");for(var o=Math.max(e.length,t.length);e.length<o;)e.push("0");for(;t.length<o;)t.push("0");for(var a=0;a<o;a++){var n=parseInt(e[a]),i=parseInt(t[a]);if(n>i)return 1;if(n<i)return-1}return 0}});
},{isPage:true,isComponent:true,currentFile:'pages/work/method.js'});require("pages/work/method.js");