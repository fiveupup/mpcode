$gwx_XC_11=function(_,_v,_n,_p,_s,_wp,_wl,$gwn,$gwl,$gwh,wh,$gstack,$gwrt,gra,grb,TestTest,wfor,_ca,_da,_r,_rz,_o,_oz,_1,_1z,_2,_2z,_m,_mz,nv_getDate,nv_getRegExp,nv_console,nv_parseInt,nv_parseFloat,nv_isNaN,nv_isFinite,nv_decodeURI,nv_decodeURIComponent,nv_encodeURI,nv_encodeURIComponent,$gdc,nv_JSON,_af,_gv,_ai,_grp,_gd,_gapi,$ixc,_ic,_w,_ev,_tsd){return function(path,global){
if(typeof global==='undefined'){if (typeof __GWX_GLOBAL__==='undefined')global={};else global=__GWX_GLOBAL__;}if(typeof __WXML_GLOBAL__ === 'undefined') {__WXML_GLOBAL__={};
}__WXML_GLOBAL__.modules = __WXML_GLOBAL__.modules || {};
var e_={}
if(typeof(global.entrys)==='undefined')global.entrys={};e_=global.entrys;
var d_={}
if(typeof(global.defines)==='undefined')global.defines={};d_=global.defines;
var f_={}
if(typeof(global.modules)==='undefined')global.modules={};f_=global.modules || {};
var p_={}
__WXML_GLOBAL__.ops_cached = __WXML_GLOBAL__.ops_cached || {}
__WXML_GLOBAL__.ops_set = __WXML_GLOBAL__.ops_set || {};
__WXML_GLOBAL__.ops_init = __WXML_GLOBAL__.ops_init || {};
var z=__WXML_GLOBAL__.ops_set.$gwx_XC_11 || [];
function gz$gwx_XC_11_1(){
if( __WXML_GLOBAL__.ops_cached.$gwx_XC_11_1)return __WXML_GLOBAL__.ops_cached.$gwx_XC_11_1
__WXML_GLOBAL__.ops_cached.$gwx_XC_11_1=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
Z([[7],[3,'arrowDirection']])
Z([[7],[3,'border']])
Z([[7],[3,'center']])
Z([[7],[3,'clickable']])
Z([3,'van-field'])
Z([[7],[3,'customStyle']])
Z([[7],[3,'leftIcon']])
Z([[7],[3,'isLink']])
Z([[7],[3,'required']])
Z([[7],[3,'size']])
Z([[7],[3,'label']])
Z([[7],[3,'titleWidth']])
Z([3,'left-icon'])
Z([3,'icon'])
Z([3,'label'])
Z([3,'title'])
Z([[12],[[6],[[7],[3,'utils']],[3,'bem']],[[5],[[5],[1,'field__body']],[[4],[[5],[[5],[[7],[3,'type']]],[[7],[3,'system']]]]]])
Z([[2,'&&'],[[7],[3,'clearable']],[[7],[3,'value']]])
Z([3,'onClear'])
Z([3,'van-field__clear-root van-field__icon-root'])
Z([3,'clear'])
Z([3,'16px'])
Z([3,'onClickIcon'])
Z([3,'van-field__icon-container'])
Z([[2,'||'],[[7],[3,'rightIcon']],[[7],[3,'icon']]])
Z([a,[3,'van-field__icon-root '],[[7],[3,'iconClass']]])
Z([3,'right-icon-class'])
Z(z[24])
Z(z[21])
Z([3,'right-icon'])
Z(z[13])
Z([3,'button'])
Z([[7],[3,'errorMessage']])
})(__WXML_GLOBAL__.ops_cached.$gwx_XC_11_1);return __WXML_GLOBAL__.ops_cached.$gwx_XC_11_1
}
__WXML_GLOBAL__.ops_set.$gwx_XC_11=z;
__WXML_GLOBAL__.ops_init.$gwx_XC_11=true;
var x=['./components/vant/field/index.wxml'];d_[x[0]]={}
var m0=function(e,s,r,gg){
var z=gz$gwx_XC_11_1()
var o2C=_mz(z,'van-cell',['arrowDirection',0,'border',1,'center',1,'clickable',2,'customClass',3,'customStyle',4,'icon',5,'isLink',6,'required',7,'size',8,'title',9,'titleWidth',10],[],e,s,gg)
var o4C=_mz(z,'slot',['name',12,'slot',1],[],e,s,gg)
_(o2C,o4C)
var f5C=_mz(z,'slot',['name',14,'slot',1],[],e,s,gg)
_(o2C,f5C)
var c6C=_n('view')
_rz(z,c6C,'class',16,e,s,gg)
var h7C=_v()
_(c6C,h7C)
if(_oz(z,17,e,s,gg)){h7C.wxVkey=1
var o8C=_mz(z,'van-icon',['catch:touchstart',18,'class',1,'name',2,'size',3],[],e,s,gg)
_(h7C,o8C)
}
var c9C=_mz(z,'view',['bind:tap',22,'class',1],[],e,s,gg)
var o0C=_v()
_(c9C,o0C)
if(_oz(z,24,e,s,gg)){o0C.wxVkey=1
var lAD=_mz(z,'van-icon',['class',25,'customClass',1,'name',2,'size',3],[],e,s,gg)
_(o0C,lAD)
}
var aBD=_n('slot')
_rz(z,aBD,'name',29,e,s,gg)
_(c9C,aBD)
var tCD=_n('slot')
_rz(z,tCD,'name',30,e,s,gg)
_(c9C,tCD)
o0C.wxXCkey=1
o0C.wxXCkey=3
_(c6C,c9C)
var eDD=_n('slot')
_rz(z,eDD,'name',31,e,s,gg)
_(c6C,eDD)
h7C.wxXCkey=1
h7C.wxXCkey=3
_(o2C,c6C)
var x3C=_v()
_(o2C,x3C)
if(_oz(z,32,e,s,gg)){x3C.wxVkey=1
}
x3C.wxXCkey=1
_(r,o2C)
return r
}
e_[x[0]]={f:m0,j:[],i:[],ti:[],ic:[]}
if(path&&e_[path]){
return function(env,dd,global){$gwxc=0;var root={"tag":"wx-page"};root.children=[]
;g="$gwx_XC_11";var main=e_[path].f
if (typeof global==="undefined")global={};global.f=$gdc(f_[path],"",1);
try{
main(env,{},root,global);
_tsd(root)
}catch(err){
console.log(err)
}
;g="";
return root;
}
}
}
}(__g.a,__g.b,__g.c,__g.d,__g.e,__g.f,__g.g,__g.h,__g.i,__g.j,__g.k,__g.l,__g.m,__g.n,__g.o,__g.p,__g.q,__g.r,__g.s,__g.t,__g.u,__g.v,__g.w,__g.x,__g.y,__g.z,__g.A,__g.B,__g.C,__g.D,__g.E,__g.F,__g.G,__g.H,__g.I,__g.J,__g.K,__g.L,__g.M,__g.N,__g.O,__g.P,__g.Q,__g.R,__g.S,__g.T,__g.U,__g.V,__g.W,__g.X,__g.Y,__g.Z,__g.aa);if(__vd_version_info__.delayedGwx||false)$gwx_XC_11();	if (__vd_version_info__.delayedGwx) __wxAppCode__['components/vant/field/index.wxml'] = [$gwx_XC_11, './components/vant/field/index.wxml'];else __wxAppCode__['components/vant/field/index.wxml'] = $gwx_XC_11( './components/vant/field/index.wxml' );
	;__wxRoute = "components/vant/field/index";__wxRouteBegin = true;__wxAppCurrentFile__="components/vant/field/index.js";define("components/vant/field/index.js",function(require,module,exports,window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){
"use strict";Object.defineProperty(exports,"__esModule",{value:!0});var e=require("../common/component"),t=require("../common/utils");e.VantComponent({field:!0,classes:["input-class","right-icon-class"],props:{size:String,icon:String,label:String,error:Boolean,fixed:Boolean,focus:Boolean,center:Boolean,isLink:Boolean,leftIcon:String,rightIcon:String,disabled:Boolean,autosize:Boolean,readonly:Boolean,required:Boolean,password:Boolean,iconClass:String,clearable:Boolean,clickable:Boolean,inputAlign:String,placeholder:String,customStyle:String,confirmType:String,confirmHold:Boolean,holdKeyboard:Boolean,errorMessage:String,arrowDirection:String,placeholderStyle:String,errorMessageAlign:String,selectionEnd:{type:Number,value:-1},selectionStart:{type:Number,value:-1},showConfirmBar:{type:Boolean,value:!0},adjustPosition:{type:Boolean,value:!0},cursorSpacing:{type:Number,value:50},maxlength:{type:Number,value:-1},type:{type:String,value:"text"},border:{type:Boolean,value:!0},titleWidth:{type:String,value:"90px"}},data:{focused:!1,system:t.getSystemInfoSync().system.split(" ").shift().toLowerCase()},methods:{onInput:function(e){var t=this,o=(e.detail||{}).value,n=void 0===o?"":o;this.setData({value:n}),wx.nextTick((function(){t.emitChange(n)}))},onFocus:function(e){this.setData({focused:!0}),this.$emit("focus",e.detail)},onBlur:function(e){this.setData({focused:!1}),this.$emit("blur",e.detail)},onClickIcon:function(){this.$emit("click-icon")},onClear:function(){var e=this;this.setData({value:""}),wx.nextTick((function(){e.emitChange(""),e.$emit("clear","")}))},onConfirm:function(){this.$emit("confirm",this.data.value)},emitChange:function(e){this.$emit("input",e),this.$emit("change",e)},noop:function(){}}});
},{isPage:false,isComponent:true,currentFile:'components/vant/field/index.js'});require("components/vant/field/index.js");