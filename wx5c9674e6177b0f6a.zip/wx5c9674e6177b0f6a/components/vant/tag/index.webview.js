$gwx_XC_23=function(_,_v,_n,_p,_s,_wp,_wl,$gwn,$gwl,$gwh,wh,$gstack,$gwrt,gra,grb,TestTest,wfor,_ca,_da,_r,_rz,_o,_oz,_1,_1z,_2,_2z,_m,_mz,nv_getDate,nv_getRegExp,nv_console,nv_parseInt,nv_parseFloat,nv_isNaN,nv_isFinite,nv_decodeURI,nv_decodeURIComponent,nv_encodeURI,nv_encodeURIComponent,$gdc,nv_JSON,_af,_gv,_ai,_grp,_gd,_gapi,$ixc,_ic,_w,_ev,_tsd){return function(path,global){
if(typeof global==='undefined'){if (typeof __GWX_GLOBAL__==='undefined')global={};else global=__GWX_GLOBAL__;}if(typeof __WXML_GLOBAL__ === 'undefined') {__WXML_GLOBAL__={};
}__WXML_GLOBAL__.modules = __WXML_GLOBAL__.modules || {};
var e_={}
if(typeof(global.entrys)==='undefined')global.entrys={};e_=global.entrys;
var d_={}
if(typeof(global.defines)==='undefined')global.defines={};d_=global.defines;
var f_={}
if(typeof(global.modules)==='undefined')global.modules={};f_=global.modules || {};
var p_={}
__WXML_GLOBAL__.ops_cached = __WXML_GLOBAL__.ops_cached || {}
__WXML_GLOBAL__.ops_set = __WXML_GLOBAL__.ops_set || {};
__WXML_GLOBAL__.ops_init = __WXML_GLOBAL__.ops_init || {};
var z=__WXML_GLOBAL__.ops_set.$gwx_XC_23 || [];
function gz$gwx_XC_23_1(){
if( __WXML_GLOBAL__.ops_cached.$gwx_XC_23_1)return __WXML_GLOBAL__.ops_cached.$gwx_XC_23_1
__WXML_GLOBAL__.ops_cached.$gwx_XC_23_1=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
Z([a,[3,'custom-class '],[[12],[[6],[[7],[3,'utils']],[3,'bem']],[[5],[[5],[1,'tag']],[[4],[[5],[[5],[[5],[[7],[3,'type']]],[[7],[3,'size']]],[[9],[[9],[[8],'mark',[[7],[3,'mark']]],[[8],'plain',[[7],[3,'plain']]]],[[8],'round',[[7],[3,'round']]]]]]]],[3,' '],[[2,'?:'],[[7],[3,'plain']],[1,'van-hairline--surround'],[1,'']]])
Z([a,[[2,'?:'],[[2,'&&'],[[7],[3,'color']],[[2,'!'],[[7],[3,'plain']]]],[[2,'+'],[[2,'+'],[1,'background-color: '],[[7],[3,'color']]],[1,';']],[1,'']],[[2,'?:'],[[2,'||'],[[7],[3,'textColor']],[[2,'&&'],[[7],[3,'color']],[[7],[3,'plain']]]],[[2,'+'],[1,'color: '],[[2,'||'],[[7],[3,'textColor']],[[7],[3,'color']]]],[1,'']]])
Z([[7],[3,'closeable']])
Z([3,'onClose'])
Z([3,'van-tag__close'])
Z([3,'cross'])
})(__WXML_GLOBAL__.ops_cached.$gwx_XC_23_1);return __WXML_GLOBAL__.ops_cached.$gwx_XC_23_1
}
__WXML_GLOBAL__.ops_set.$gwx_XC_23=z;
__WXML_GLOBAL__.ops_init.$gwx_XC_23=true;
var x=['./components/vant/tag/index.wxml'];d_[x[0]]={}
var m0=function(e,s,r,gg){
var z=gz$gwx_XC_23_1()
var oBI=_mz(z,'view',['class',0,'style',1],[],e,s,gg)
var aDI=_n('slot')
_(oBI,aDI)
var lCI=_v()
_(oBI,lCI)
if(_oz(z,2,e,s,gg)){lCI.wxVkey=1
var tEI=_mz(z,'van-icon',['bind:click',3,'customClass',1,'name',2],[],e,s,gg)
_(lCI,tEI)
}
lCI.wxXCkey=1
lCI.wxXCkey=3
_(r,oBI)
return r
}
e_[x[0]]={f:m0,j:[],i:[],ti:[],ic:[]}
if(path&&e_[path]){
outerGlobal.__wxml_comp_version__=0.02
return function(env,dd,global){$gwxc=0;var root={"tag":"wx-page"};root.children=[]
;g="$gwx_XC_23";var main=e_[path].f
if (typeof global==="undefined")global={};global.f=$gdc(f_[path],"",1);
if(typeof(outerGlobal.__webview_engine_version__)!='undefined'&&outerGlobal.__webview_engine_version__+1e-6>=0.02+1e-6&&outerGlobal.__mergeData__)
{
env=outerGlobal.__mergeData__(env,dd);
}
try{
main(env,{},root,global);
_tsd(root)
if(typeof(outerGlobal.__webview_engine_version__)=='undefined'|| outerGlobal.__webview_engine_version__+1e-6<0.01+1e-6){return _ev(root);}
}catch(err){
console.log(err)
}
;g="";
return root;
}
}
}
}(__g.a,__g.b,__g.c,__g.d,__g.e,__g.f,__g.g,__g.h,__g.i,__g.j,__g.k,__g.l,__g.m,__g.n,__g.o,__g.p,__g.q,__g.r,__g.s,__g.t,__g.u,__g.v,__g.w,__g.x,__g.y,__g.z,__g.A,__g.B,__g.C,__g.D,__g.E,__g.F,__g.G,__g.H,__g.I,__g.J,__g.K,__g.L,__g.M,__g.N,__g.O,__g.P,__g.Q,__g.R,__g.S,__g.T,__g.U,__g.V,__g.W,__g.X,__g.Y,__g.Z,__g.aa);if(__vd_version_info__.delayedGwx||false)$gwx_XC_23();	if (__vd_version_info__.delayedGwx) __wxAppCode__['components/vant/tag/index.wxml'] = [$gwx_XC_23, './components/vant/tag/index.wxml'];else __wxAppCode__['components/vant/tag/index.wxml'] = $gwx_XC_23( './components/vant/tag/index.wxml' );
	
var noCss=typeof __vd_version_info__!=='undefined'&&__vd_version_info__.noCss===true;if(!noCss){__wxAppCode__['components/vant/tag/index.wxss'] = setCssToHead([[2,"./components/vant/common/index.wxss"],".",[1],"van-tag{-webkit-align-items:center;align-items:center;border-radius:.2em;border-radius:var(--tag-border-radius,.2em);color:#fff;color:var(--tag-text-color,#fff);display:-webkit-inline-flex;display:inline-flex;font-size:10px;font-size:var(--tag-font-size,10px);line-height:normal;padding:.2em .5em;padding:var(--tag-padding,.2em .5em)}\n.",[1],"van-tag:after{border-color:currentColor;border-radius:.2em * 2;border-radius:var(--tag-border-radius,.2em) * 2}\n.",[1],"van-tag--default{background-color:#969799;background-color:var(--tag-default-color,#969799)}\n.",[1],"van-tag--default.",[1],"van-tag--plain{color:#969799;color:var(--tag-default-color,#969799)}\n.",[1],"van-tag--danger{background-color:#ee0a24;background-color:var(--tag-dander-color,#ee0a24)}\n.",[1],"van-tag--danger.",[1],"van-tag--plain{color:#ee0a24;color:var(--tag-dander-color,#ee0a24)}\n.",[1],"van-tag--primary{background-color:#1989fa;background-color:var(--tag-primary-color,#1989fa)}\n.",[1],"van-tag--primary.",[1],"van-tag--plain{color:#1989fa;color:var(--tag-primary-color,#1989fa)}\n.",[1],"van-tag--success{background-color:#07c160;background-color:var(--tag-success-color,#07c160)}\n.",[1],"van-tag--success.",[1],"van-tag--plain{color:#07c160;color:var(--tag-success-color,#07c160)}\n.",[1],"van-tag--warning{background-color:#ff976a;background-color:var(--tag-warning-color,#ff976a)}\n.",[1],"van-tag--warning.",[1],"van-tag--plain{color:#ff976a;color:var(--tag-warning-color,#ff976a)}\n.",[1],"van-tag--plain{background-color:#fff;background-color:var(--tag-plain-background-color,#fff)}\n.",[1],"van-tag--mark{padding-right:.7em}\n.",[1],"van-tag--mark,.",[1],"van-tag--mark:after{border-radius:0 999px 999px 0;border-radius:0 var(--tag-round-border-radius,999px) var(--tag-round-border-radius,999px) 0}\n.",[1],"van-tag--round,.",[1],"van-tag--round:after{border-radius:999px;border-radius:var(--tag-round-border-radius,999px)}\n.",[1],"van-tag--medium{font-size:12px;font-size:var(--tag-medium-font-size,12px)}\n.",[1],"van-tag--large{font-size:14px;font-size:var(--tag-large-font-size,14px)}\n.",[1],"van-tag__close{margin-left:2px}\n",],undefined,{path:"./components/vant/tag/index.wxss"});
}