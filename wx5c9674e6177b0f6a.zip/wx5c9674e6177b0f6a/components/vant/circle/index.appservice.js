$gwx_XC_8=function(_,_v,_n,_p,_s,_wp,_wl,$gwn,$gwl,$gwh,wh,$gstack,$gwrt,gra,grb,TestTest,wfor,_ca,_da,_r,_rz,_o,_oz,_1,_1z,_2,_2z,_m,_mz,nv_getDate,nv_getRegExp,nv_console,nv_parseInt,nv_parseFloat,nv_isNaN,nv_isFinite,nv_decodeURI,nv_decodeURIComponent,nv_encodeURI,nv_encodeURIComponent,$gdc,nv_JSON,_af,_gv,_ai,_grp,_gd,_gapi,$ixc,_ic,_w,_ev,_tsd){return function(path,global){
if(typeof global==='undefined'){if (typeof __GWX_GLOBAL__==='undefined')global={};else global=__GWX_GLOBAL__;}if(typeof __WXML_GLOBAL__ === 'undefined') {__WXML_GLOBAL__={};
}__WXML_GLOBAL__.modules = __WXML_GLOBAL__.modules || {};
var e_={}
if(typeof(global.entrys)==='undefined')global.entrys={};e_=global.entrys;
var d_={}
if(typeof(global.defines)==='undefined')global.defines={};d_=global.defines;
var f_={}
if(typeof(global.modules)==='undefined')global.modules={};f_=global.modules || {};
var p_={}
__WXML_GLOBAL__.ops_cached = __WXML_GLOBAL__.ops_cached || {}
__WXML_GLOBAL__.ops_set = __WXML_GLOBAL__.ops_set || {};
__WXML_GLOBAL__.ops_init = __WXML_GLOBAL__.ops_init || {};
var z=__WXML_GLOBAL__.ops_set.$gwx_XC_8 || [];
function gz$gwx_XC_8_1(){
if( __WXML_GLOBAL__.ops_cached.$gwx_XC_8_1)return __WXML_GLOBAL__.ops_cached.$gwx_XC_8_1
__WXML_GLOBAL__.ops_cached.$gwx_XC_8_1=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
Z([3,'van-circle'])
Z([[2,'!'],[[7],[3,'text']]])
})(__WXML_GLOBAL__.ops_cached.$gwx_XC_8_1);return __WXML_GLOBAL__.ops_cached.$gwx_XC_8_1
}
__WXML_GLOBAL__.ops_set.$gwx_XC_8=z;
__WXML_GLOBAL__.ops_init.$gwx_XC_8=true;
var x=['./components/vant/circle/index.wxml'];d_[x[0]]={}
var m0=function(e,s,r,gg){
var z=gz$gwx_XC_8_1()
var fCC=_n('view')
_rz(z,fCC,'class',0,e,s,gg)
var cDC=_v()
_(fCC,cDC)
if(_oz(z,1,e,s,gg)){cDC.wxVkey=1
var hEC=_n('slot')
_(cDC,hEC)
}
else{cDC.wxVkey=2
}
cDC.wxXCkey=1
_(r,fCC)
return r
}
e_[x[0]]={f:m0,j:[],i:[],ti:[],ic:[]}
if(path&&e_[path]){
return function(env,dd,global){$gwxc=0;var root={"tag":"wx-page"};root.children=[]
;g="$gwx_XC_8";var main=e_[path].f
if (typeof global==="undefined")global={};global.f=$gdc(f_[path],"",1);
try{
main(env,{},root,global);
_tsd(root)
}catch(err){
console.log(err)
}
;g="";
return root;
}
}
}
}(__g.a,__g.b,__g.c,__g.d,__g.e,__g.f,__g.g,__g.h,__g.i,__g.j,__g.k,__g.l,__g.m,__g.n,__g.o,__g.p,__g.q,__g.r,__g.s,__g.t,__g.u,__g.v,__g.w,__g.x,__g.y,__g.z,__g.A,__g.B,__g.C,__g.D,__g.E,__g.F,__g.G,__g.H,__g.I,__g.J,__g.K,__g.L,__g.M,__g.N,__g.O,__g.P,__g.Q,__g.R,__g.S,__g.T,__g.U,__g.V,__g.W,__g.X,__g.Y,__g.Z,__g.aa);if(__vd_version_info__.delayedGwx||false)$gwx_XC_8();	if (__vd_version_info__.delayedGwx) __wxAppCode__['components/vant/circle/index.wxml'] = [$gwx_XC_8, './components/vant/circle/index.wxml'];else __wxAppCode__['components/vant/circle/index.wxml'] = $gwx_XC_8( './components/vant/circle/index.wxml' );
	;__wxRoute = "components/vant/circle/index";__wxRouteBegin = true;__wxAppCurrentFile__="components/vant/circle/index.js";define("components/vant/circle/index.js",function(require,module,exports,window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){
"use strict";Object.defineProperty(exports,"__esModule",{value:!0});var e=require("../common/component"),t=require("../common/utils"),r=require("../common/color");var a=2*Math.PI,n=-Math.PI/2;e.VantComponent({props:{text:String,lineCap:{type:String,value:"round"},value:{type:Number,value:0,observer:"reRender"},speed:{type:Number,value:50},size:{type:Number,value:100},fill:String,layerColor:{type:String,value:r.WHITE},color:{type:[String,Object],value:r.BLUE,observer:"setHoverColor"},type:{type:String,value:""},strokeWidth:{type:Number,value:4},clockwise:{type:Boolean,value:!0}},data:{hoverColor:r.BLUE},methods:{getContext:function(){return this.ctx||(this.ctx=wx.createCanvasContext("van-circle",this)),this.ctx},setHoverColor:function(){var e=this.data,r=e.color,a=e.size,n=e.type,i=n?this.getContext(n):this.getContext(),o=r;if(t.isObj(r)){var l=i.createLinearGradient(a,0,0,0);Object.keys(r).sort((function(e,t){return parseFloat(e)-parseFloat(t)})).map((function(e){return l.addColorStop(parseFloat(e)/100,r[e])})),o=l}this.setData({hoverColor:o})},presetCanvas:function(e,t,r,a,n){var i=this.data,o=i.strokeWidth,l=i.lineCap,s=i.clockwise,c=i.size/2,u=c-o/2;e.setStrokeStyle(t),e.setLineWidth(o),e.setLineCap(l),e.beginPath(),e.arc(c,c,u,r,a,!s),e.stroke(),n&&(e.setFillStyle(n),e.fill())},renderLayerCircle:function(e){var t=this.data,r=t.layerColor,n=t.fill;this.presetCanvas(e,r,0,a,n)},renderHoverCircle:function(e,t){var r=this.data,i=r.clockwise,o=r.hoverColor,l=a*(t/100),s=i?n+l:3*Math.PI-(n+l);this.presetCanvas(e,o,n,s)},drawCircle:function(e){var t=this.data,r=t.size,a=t.type,n=a?this.getContext(a):this.getContext();n.clearRect(0,0,r,r),this.renderLayerCircle(n);var i,o=(i=e,Math.min(Math.max(i,0),100));0!==o&&this.renderHoverCircle(n,o),n.draw()},reRender:function(){var e=this,t=this.data,r=t.value,a=t.speed;a<=0||a>1e3?this.drawCircle(r):(this.clearInterval(),this.currentValue=this.currentValue||0,this.interval=setInterval((function(){e.currentValue!==r?(e.currentValue<r?e.currentValue+=1:e.currentValue-=1,e.drawCircle(e.currentValue)):e.clearInterval()}),1e3/a))},clearInterval:function(e){function t(){return e.apply(this,arguments)}return t.toString=function(){return e.toString()},t}((function(){this.interval&&(clearInterval(this.interval),this.interval=null)}))},created:function(){var e=this.data.value;this.currentValue=e,this.drawCircle(e)},destroyed:function(){this.ctx=null,this.clearInterval()}});
},{isPage:false,isComponent:true,currentFile:'components/vant/circle/index.js'});require("components/vant/circle/index.js");