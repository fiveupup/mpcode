$gwx_XC_17=function(_,_v,_n,_p,_s,_wp,_wl,$gwn,$gwl,$gwh,wh,$gstack,$gwrt,gra,grb,TestTest,wfor,_ca,_da,_r,_rz,_o,_oz,_1,_1z,_2,_2z,_m,_mz,nv_getDate,nv_getRegExp,nv_console,nv_parseInt,nv_parseFloat,nv_isNaN,nv_isFinite,nv_decodeURI,nv_decodeURIComponent,nv_encodeURI,nv_encodeURIComponent,$gdc,nv_JSON,_af,_gv,_ai,_grp,_gd,_gapi,$ixc,_ic,_w,_ev,_tsd){return function(path,global){
if(typeof global==='undefined'){if (typeof __GWX_GLOBAL__==='undefined')global={};else global=__GWX_GLOBAL__;}if(typeof __WXML_GLOBAL__ === 'undefined') {__WXML_GLOBAL__={};
}__WXML_GLOBAL__.modules = __WXML_GLOBAL__.modules || {};
var e_={}
if(typeof(global.entrys)==='undefined')global.entrys={};e_=global.entrys;
var d_={}
if(typeof(global.defines)==='undefined')global.defines={};d_=global.defines;
var f_={}
if(typeof(global.modules)==='undefined')global.modules={};f_=global.modules || {};
var p_={}
__WXML_GLOBAL__.ops_cached = __WXML_GLOBAL__.ops_cached || {}
__WXML_GLOBAL__.ops_set = __WXML_GLOBAL__.ops_set || {};
__WXML_GLOBAL__.ops_init = __WXML_GLOBAL__.ops_init || {};
var z=__WXML_GLOBAL__.ops_set.$gwx_XC_17 || [];
function gz$gwx_XC_17_1(){
if( __WXML_GLOBAL__.ops_cached.$gwx_XC_17_1)return __WXML_GLOBAL__.ops_cached.$gwx_XC_17_1
__WXML_GLOBAL__.ops_cached.$gwx_XC_17_1=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
Z([[7],[3,'show']])
Z([3,'onClick'])
Z([a,[3,'custom-class '],[[12],[[6],[[7],[3,'utils']],[3,'bem']],[[5],[[5],[1,'notice-bar']],[[9],[[8],'withicon',[[7],[3,'mode']]],[[8],'wrapable',[[7],[3,'wrapable']]]]]]])
Z([a,[3,'color: '],[[7],[3,'color']],[3,'; background-color: '],[[7],[3,'backgroundColor']],[3,'; background: '],[[7],[3,'background']]])
Z([[7],[3,'leftIcon']])
Z([3,'van-notice-bar__left-icon'])
Z(z[4])
Z([3,'16px'])
Z([3,'left-icon'])
Z([[2,'==='],[[7],[3,'mode']],[1,'closeable']])
Z([3,'onClickIcon'])
Z([3,'van-notice-bar__right-icon'])
Z([3,'cross'])
Z([[2,'==='],[[7],[3,'mode']],[1,'link']])
Z(z[11])
Z([3,'arrow'])
Z([3,'right-icon'])
})(__WXML_GLOBAL__.ops_cached.$gwx_XC_17_1);return __WXML_GLOBAL__.ops_cached.$gwx_XC_17_1
}
__WXML_GLOBAL__.ops_set.$gwx_XC_17=z;
__WXML_GLOBAL__.ops_init.$gwx_XC_17=true;
var x=['./components/vant/notice-bar/index.wxml'];d_[x[0]]={}
var m0=function(e,s,r,gg){
var z=gz$gwx_XC_17_1()
var o2D=_v()
_(r,o2D)
if(_oz(z,0,e,s,gg)){o2D.wxVkey=1
var l3D=_mz(z,'view',['bind:tap',1,'class',1,'style',2],[],e,s,gg)
var a4D=_v()
_(l3D,a4D)
if(_oz(z,4,e,s,gg)){a4D.wxVkey=1
var e6D=_mz(z,'van-icon',['class',5,'name',1,'size',2],[],e,s,gg)
_(a4D,e6D)
}
else{a4D.wxVkey=2
var b7D=_n('slot')
_rz(z,b7D,'name',8,e,s,gg)
_(a4D,b7D)
}
var t5D=_v()
_(l3D,t5D)
if(_oz(z,9,e,s,gg)){t5D.wxVkey=1
var o8D=_mz(z,'van-icon',['catch:tap',10,'class',1,'name',2],[],e,s,gg)
_(t5D,o8D)
}
else if(_oz(z,13,e,s,gg)){t5D.wxVkey=2
var x9D=_mz(z,'van-icon',['class',14,'name',1],[],e,s,gg)
_(t5D,x9D)
}
else{t5D.wxVkey=3
var o0D=_n('slot')
_rz(z,o0D,'name',16,e,s,gg)
_(t5D,o0D)
}
a4D.wxXCkey=1
a4D.wxXCkey=3
t5D.wxXCkey=1
t5D.wxXCkey=3
t5D.wxXCkey=3
_(o2D,l3D)
}
o2D.wxXCkey=1
o2D.wxXCkey=3
return r
}
e_[x[0]]={f:m0,j:[],i:[],ti:[],ic:[]}
if(path&&e_[path]){
return function(env,dd,global){$gwxc=0;var root={"tag":"wx-page"};root.children=[]
;g="$gwx_XC_17";var main=e_[path].f
if (typeof global==="undefined")global={};global.f=$gdc(f_[path],"",1);
try{
main(env,{},root,global);
_tsd(root)
}catch(err){
console.log(err)
}
;g="";
return root;
}
}
}
}(__g.a,__g.b,__g.c,__g.d,__g.e,__g.f,__g.g,__g.h,__g.i,__g.j,__g.k,__g.l,__g.m,__g.n,__g.o,__g.p,__g.q,__g.r,__g.s,__g.t,__g.u,__g.v,__g.w,__g.x,__g.y,__g.z,__g.A,__g.B,__g.C,__g.D,__g.E,__g.F,__g.G,__g.H,__g.I,__g.J,__g.K,__g.L,__g.M,__g.N,__g.O,__g.P,__g.Q,__g.R,__g.S,__g.T,__g.U,__g.V,__g.W,__g.X,__g.Y,__g.Z,__g.aa);if(__vd_version_info__.delayedGwx||false)$gwx_XC_17();	if (__vd_version_info__.delayedGwx) __wxAppCode__['components/vant/notice-bar/index.wxml'] = [$gwx_XC_17, './components/vant/notice-bar/index.wxml'];else __wxAppCode__['components/vant/notice-bar/index.wxml'] = $gwx_XC_17( './components/vant/notice-bar/index.wxml' );
	;__wxRoute = "components/vant/notice-bar/index";__wxRouteBegin = true;__wxAppCurrentFile__="components/vant/notice-bar/index.js";define("components/vant/notice-bar/index.js",function(require,module,exports,window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){
"use strict";Object.defineProperty(exports,"__esModule",{value:!0}),require("../common/component").VantComponent({props:{text:{type:String,value:"",observer:function(){var t=this;wx.nextTick((function(){t.init()}))}},mode:{type:String,value:""},url:{type:String,value:""},openType:{type:String,value:"navigate"},delay:{type:Number,value:1},speed:{type:Number,value:50,observer:function(){var t=this;wx.nextTick((function(){t.init()}))}},scrollable:{type:Boolean,value:!0},leftIcon:{type:String,value:""},color:String,backgroundColor:String,background:String,wrapable:Boolean},data:{show:!0},created:function(){this.resetAnimation=wx.createAnimation({duration:0,timingFunction:"linear"})},destroyed:function(){this.timer&&clearTimeout(this.timer)},methods:{init:function(){var t=this;Promise.all([this.getRect(".van-notice-bar__content"),this.getRect(".van-notice-bar__wrap")]).then((function(i){var e=i[0],n=i[1];if(null!=e&&null!=n&&e.width&&n.width){var a=t.data,o=a.speed,r=a.scrollable,l=a.delay;if(r&&n.width<e.width){var s=e.width/o*1e3;t.wrapWidth=n.width,t.contentWidth=e.width,t.duration=s,t.animation=wx.createAnimation({duration:s,timingFunction:"linear",delay:l}),t.scroll()}}}))},scroll:function(){var t=this;this.timer&&clearTimeout(this.timer),this.timer=null,this.setData({animationData:this.resetAnimation.translateX(this.wrapWidth).step().export()}),setTimeout((function(){t.setData({animationData:t.animation.translateX(-t.contentWidth).step().export()})}),20),this.timer=setTimeout((function(){t.scroll()}),this.duration)},onClickIcon:function(t){"closeable"===this.data.mode&&(this.timer&&clearTimeout(this.timer),this.timer=null,this.setData({show:!1}),this.$emit("close",t.detail))},onClick:function(t){this.$emit("click",t)}}});
},{isPage:false,isComponent:true,currentFile:'components/vant/notice-bar/index.js'});require("components/vant/notice-bar/index.js");