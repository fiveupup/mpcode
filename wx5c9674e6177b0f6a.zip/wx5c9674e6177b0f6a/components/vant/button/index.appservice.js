$gwx_XC_4=function(_,_v,_n,_p,_s,_wp,_wl,$gwn,$gwl,$gwh,wh,$gstack,$gwrt,gra,grb,TestTest,wfor,_ca,_da,_r,_rz,_o,_oz,_1,_1z,_2,_2z,_m,_mz,nv_getDate,nv_getRegExp,nv_console,nv_parseInt,nv_parseFloat,nv_isNaN,nv_isFinite,nv_decodeURI,nv_decodeURIComponent,nv_encodeURI,nv_encodeURIComponent,$gdc,nv_JSON,_af,_gv,_ai,_grp,_gd,_gapi,$ixc,_ic,_w,_ev,_tsd){return function(path,global){
if(typeof global==='undefined'){if (typeof __GWX_GLOBAL__==='undefined')global={};else global=__GWX_GLOBAL__;}if(typeof __WXML_GLOBAL__ === 'undefined') {__WXML_GLOBAL__={};
}__WXML_GLOBAL__.modules = __WXML_GLOBAL__.modules || {};
var e_={}
if(typeof(global.entrys)==='undefined')global.entrys={};e_=global.entrys;
var d_={}
if(typeof(global.defines)==='undefined')global.defines={};d_=global.defines;
var f_={}
if(typeof(global.modules)==='undefined')global.modules={};f_=global.modules || {};
var p_={}
__WXML_GLOBAL__.ops_cached = __WXML_GLOBAL__.ops_cached || {}
__WXML_GLOBAL__.ops_set = __WXML_GLOBAL__.ops_set || {};
__WXML_GLOBAL__.ops_init = __WXML_GLOBAL__.ops_init || {};
var z=__WXML_GLOBAL__.ops_set.$gwx_XC_4 || [];
function gz$gwx_XC_4_1(){
if( __WXML_GLOBAL__.ops_cached.$gwx_XC_4_1)return __WXML_GLOBAL__.ops_cached.$gwx_XC_4_1
__WXML_GLOBAL__.ops_cached.$gwx_XC_4_1=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
Z([[7],[3,'appParameter']])
Z([[7],[3,'ariaLabel']])
Z([3,'bindContact'])
Z([3,'bindError'])
Z([3,'bindGetPhoneNumber'])
Z([3,'bindGetUserInfo'])
Z([3,'bindLaunchApp'])
Z([3,'bindOpenSetting'])
Z([3,'onClick'])
Z([[7],[3,'businessId']])
Z([a,[3,'custom-class '],[[12],[[6],[[7],[3,'utils']],[3,'bem']],[[5],[[5],[1,'button']],[[4],[[5],[[5],[[5],[[7],[3,'type']]],[[7],[3,'size']]],[[9],[[9],[[9],[[9],[[9],[[9],[[9],[[8],'block',[[7],[3,'block']]],[[8],'round',[[7],[3,'round']]]],[[8],'plain',[[7],[3,'plain']]]],[[8],'square',[[7],[3,'square']]]],[[8],'loading',[[7],[3,'loading']]]],[[8],'disabled',[[7],[3,'disabled']]]],[[8],'hairline',[[7],[3,'hairline']]]],[[8],'unclickable',[[2,'||'],[[7],[3,'disabled']],[[7],[3,'loading']]]]]]]]],[3,' '],[[2,'?:'],[[7],[3,'hairline']],[1,'van-hairline--surround'],[1,'']]])
Z([3,'van-button--active hover-class'])
Z([[7],[3,'id']])
Z([[7],[3,'lang']])
Z([[7],[3,'openType']])
Z([[7],[3,'sendMessageImg']])
Z([[7],[3,'sendMessagePath']])
Z([[7],[3,'sendMessageTitle']])
Z([[7],[3,'sessionFrom']])
Z([[7],[3,'showMessageCard']])
Z([a,[[7],[3,'style']],z[10][3],[[7],[3,'customStyle']]])
Z([[7],[3,'loading']])
Z([[2,'?:'],[[2,'==='],[[7],[3,'type']],[1,'default']],[1,'#c9c9c9'],[1,'white']])
Z([3,'loading-class'])
Z([[7],[3,'loadingSize']])
Z([[7],[3,'loadingType']])
Z([[7],[3,'loadingText']])
Z([[7],[3,'icon']])
Z([3,'van-button__icon'])
Z([3,'line-height: inherit;'])
Z(z[27])
Z([3,'1.2em'])
})(__WXML_GLOBAL__.ops_cached.$gwx_XC_4_1);return __WXML_GLOBAL__.ops_cached.$gwx_XC_4_1
}
__WXML_GLOBAL__.ops_set.$gwx_XC_4=z;
__WXML_GLOBAL__.ops_init.$gwx_XC_4=true;
var x=['./components/vant/button/index.wxml'];d_[x[0]]={}
var m0=function(e,s,r,gg){
var z=gz$gwx_XC_4_1()
var cAB=_mz(z,'button',['appParameter',0,'ariaLabel',1,'bindcontact',1,'binderror',2,'bindgetphonenumber',3,'bindgetuserinfo',4,'bindlaunchapp',5,'bindopensetting',6,'bindtap',7,'businessId',8,'class',9,'hoverClass',10,'id',11,'lang',12,'openType',13,'sendMessageImg',14,'sendMessagePath',15,'sendMessageTitle',16,'sessionFrom',17,'showMessageCard',18,'style',19],[],e,s,gg)
var oBB=_v()
_(cAB,oBB)
if(_oz(z,21,e,s,gg)){oBB.wxVkey=1
var aDB=_mz(z,'van-loading',['color',22,'customClass',1,'size',2,'type',3],[],e,s,gg)
_(oBB,aDB)
var lCB=_v()
_(oBB,lCB)
if(_oz(z,26,e,s,gg)){lCB.wxVkey=1
}
lCB.wxXCkey=1
}
else{oBB.wxVkey=2
var tEB=_v()
_(oBB,tEB)
if(_oz(z,27,e,s,gg)){tEB.wxVkey=1
var eFB=_mz(z,'van-icon',['class',28,'customStyle',1,'name',2,'size',3],[],e,s,gg)
_(tEB,eFB)
}
var bGB=_n('slot')
_(oBB,bGB)
tEB.wxXCkey=1
tEB.wxXCkey=3
}
oBB.wxXCkey=1
oBB.wxXCkey=3
oBB.wxXCkey=3
_(r,cAB)
return r
}
e_[x[0]]={f:m0,j:[],i:[],ti:[],ic:[]}
if(path&&e_[path]){
return function(env,dd,global){$gwxc=0;var root={"tag":"wx-page"};root.children=[]
;g="$gwx_XC_4";var main=e_[path].f
if (typeof global==="undefined")global={};global.f=$gdc(f_[path],"",1);
try{
main(env,{},root,global);
_tsd(root)
}catch(err){
console.log(err)
}
;g="";
return root;
}
}
}
}(__g.a,__g.b,__g.c,__g.d,__g.e,__g.f,__g.g,__g.h,__g.i,__g.j,__g.k,__g.l,__g.m,__g.n,__g.o,__g.p,__g.q,__g.r,__g.s,__g.t,__g.u,__g.v,__g.w,__g.x,__g.y,__g.z,__g.A,__g.B,__g.C,__g.D,__g.E,__g.F,__g.G,__g.H,__g.I,__g.J,__g.K,__g.L,__g.M,__g.N,__g.O,__g.P,__g.Q,__g.R,__g.S,__g.T,__g.U,__g.V,__g.W,__g.X,__g.Y,__g.Z,__g.aa);if(__vd_version_info__.delayedGwx||false)$gwx_XC_4();	if (__vd_version_info__.delayedGwx) __wxAppCode__['components/vant/button/index.wxml'] = [$gwx_XC_4, './components/vant/button/index.wxml'];else __wxAppCode__['components/vant/button/index.wxml'] = $gwx_XC_4( './components/vant/button/index.wxml' );
	;__wxRoute = "components/vant/button/index";__wxRouteBegin = true;__wxAppCurrentFile__="components/vant/button/index.js";define("components/vant/button/index.js",function(require,module,exports,window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){
"use strict";Object.defineProperty(exports,"__esModule",{value:!0});var e=require("../common/component"),t=require("../mixins/button"),o=require("../mixins/open-type");e.VantComponent({mixins:[t.button,o.openType],classes:["hover-class","loading-class"],data:{style:""},props:{icon:String,plain:Boolean,block:Boolean,round:Boolean,square:Boolean,loading:Boolean,hairline:Boolean,disabled:Boolean,loadingText:String,customStyle:String,loadingType:{type:String,value:"circular"},type:{type:String,value:"default"},size:{type:String,value:"normal"},loadingSize:{type:String,value:"20px"},color:{type:String,observer:function(e){var t="";e&&(t+="color: "+(this.data.plain?e:"white")+";",this.data.plain||(t+="background: "+e+";"),-1!==e.indexOf("gradient")?t+="border: 0;":t+="border-color: "+e+";"),t!==this.data.style&&this.setData({style:t})}}},methods:{onClick:function(){this.data.disabled||this.data.loading||this.$emit("click")}}});
},{isPage:false,isComponent:true,currentFile:'components/vant/button/index.js'});require("components/vant/button/index.js");