$gwx_XC_20=function(_,_v,_n,_p,_s,_wp,_wl,$gwn,$gwl,$gwh,wh,$gstack,$gwrt,gra,grb,TestTest,wfor,_ca,_da,_r,_rz,_o,_oz,_1,_1z,_2,_2z,_m,_mz,nv_getDate,nv_getRegExp,nv_console,nv_parseInt,nv_parseFloat,nv_isNaN,nv_isFinite,nv_decodeURI,nv_decodeURIComponent,nv_encodeURI,nv_encodeURIComponent,$gdc,nv_JSON,_af,_gv,_ai,_grp,_gd,_gapi,$ixc,_ic,_w,_ev,_tsd){return function(path,global){
if(typeof global==='undefined'){if (typeof __GWX_GLOBAL__==='undefined')global={};else global=__GWX_GLOBAL__;}if(typeof __WXML_GLOBAL__ === 'undefined') {__WXML_GLOBAL__={};
}__WXML_GLOBAL__.modules = __WXML_GLOBAL__.modules || {};
var e_={}
if(typeof(global.entrys)==='undefined')global.entrys={};e_=global.entrys;
var d_={}
if(typeof(global.defines)==='undefined')global.defines={};d_=global.defines;
var f_={}
if(typeof(global.modules)==='undefined')global.modules={};f_=global.modules || {};
var p_={}
__WXML_GLOBAL__.ops_cached = __WXML_GLOBAL__.ops_cached || {}
__WXML_GLOBAL__.ops_set = __WXML_GLOBAL__.ops_set || {};
__WXML_GLOBAL__.ops_init = __WXML_GLOBAL__.ops_init || {};
var z=__WXML_GLOBAL__.ops_set.$gwx_XC_20 || [];
function gz$gwx_XC_20_1(){
if( __WXML_GLOBAL__.ops_cached.$gwx_XC_20_1)return __WXML_GLOBAL__.ops_cached.$gwx_XC_20_1
__WXML_GLOBAL__.ops_cached.$gwx_XC_20_1=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
Z([a,[[12],[[6],[[7],[3,'utils']],[3,'bem']],[[5],[[5],[1,'search']],[[8],'withaction',[[2,'||'],[[7],[3,'showAction']],[[7],[3,'useActionSlot']]]]]],[3,' custom-class']])
Z([a,[3,'background: '],[[7],[3,'background']]])
Z([[12],[[6],[[7],[3,'utils']],[3,'bem']],[[5],[[5],[1,'search__content']],[[4],[[5],[[7],[3,'shape']]]]]])
Z([[7],[3,'label']])
Z([3,'label'])
Z([3,'onBlur'])
Z([3,'onChange'])
Z([3,'onClear'])
Z([3,'onSearch'])
Z([3,'onFocus'])
Z([1,false])
Z([3,'van-search__field field-class'])
Z([[7],[3,'clearable']])
Z([[7],[3,'confirmType']])
Z([3,'padding: 5px 10px 5px 0; background-color: transparent;'])
Z([[7],[3,'disabled']])
Z([[7],[3,'error']])
Z([[7],[3,'focus']])
Z([[7],[3,'inputAlign']])
Z([3,'input-class'])
Z([[2,'?:'],[[2,'!'],[[7],[3,'useLeftIconSlot']]],[[7],[3,'leftIcon']],[1,'']])
Z([[7],[3,'maxlength']])
Z([[7],[3,'placeholder']])
Z([[7],[3,'placeholderStyle']])
Z([[7],[3,'readonly']])
Z([[2,'?:'],[[2,'!'],[[7],[3,'useRightIconSlot']]],[[7],[3,'rightIcon']],[1,'']])
Z([3,'search'])
Z([[7],[3,'value']])
Z([[7],[3,'useLeftIconSlot']])
Z([3,'left-icon'])
Z(z[29])
Z([[7],[3,'useRightIconSlot']])
Z([3,'right-icon'])
Z(z[32])
Z([[2,'||'],[[7],[3,'showAction']],[[7],[3,'useActionSlot']]])
Z([3,'van-search__action'])
Z([3,'van-search__action--hover'])
Z([3,'70'])
Z([[7],[3,'useActionSlot']])
Z([3,'action'])
})(__WXML_GLOBAL__.ops_cached.$gwx_XC_20_1);return __WXML_GLOBAL__.ops_cached.$gwx_XC_20_1
}
__WXML_GLOBAL__.ops_set.$gwx_XC_20=z;
__WXML_GLOBAL__.ops_init.$gwx_XC_20=true;
var x=['./components/vant/search/index.wxml'];d_[x[0]]={}
var m0=function(e,s,r,gg){
var z=gz$gwx_XC_20_1()
var xME=_mz(z,'view',['class',0,'style',1],[],e,s,gg)
var fOE=_n('view')
_rz(z,fOE,'class',2,e,s,gg)
var cPE=_v()
_(fOE,cPE)
if(_oz(z,3,e,s,gg)){cPE.wxVkey=1
}
else{cPE.wxVkey=2
var hQE=_n('slot')
_rz(z,hQE,'name',4,e,s,gg)
_(cPE,hQE)
}
var oRE=_mz(z,'van-field',['bind:blur',5,'bind:change',1,'bind:clear',2,'bind:confirm',3,'bind:focus',4,'border',5,'class',6,'clearable',7,'confirmType',8,'customStyle',9,'disabled',10,'error',11,'focus',12,'inputAlign',13,'inputClass',14,'leftIcon',15,'maxlength',16,'placeholder',17,'placeholderStyle',18,'readonly',19,'rightIcon',20,'type',21,'value',22],[],e,s,gg)
var cSE=_v()
_(oRE,cSE)
if(_oz(z,28,e,s,gg)){cSE.wxVkey=1
var lUE=_mz(z,'slot',['name',29,'slot',1],[],e,s,gg)
_(cSE,lUE)
}
var oTE=_v()
_(oRE,oTE)
if(_oz(z,31,e,s,gg)){oTE.wxVkey=1
var aVE=_mz(z,'slot',['name',32,'slot',1],[],e,s,gg)
_(oTE,aVE)
}
cSE.wxXCkey=1
oTE.wxXCkey=1
_(fOE,oRE)
cPE.wxXCkey=1
_(xME,fOE)
var oNE=_v()
_(xME,oNE)
if(_oz(z,34,e,s,gg)){oNE.wxVkey=1
var tWE=_mz(z,'view',['class',35,'hoverClass',1,'hoverStayTime',2],[],e,s,gg)
var eXE=_v()
_(tWE,eXE)
if(_oz(z,38,e,s,gg)){eXE.wxVkey=1
var bYE=_n('slot')
_rz(z,bYE,'name',39,e,s,gg)
_(eXE,bYE)
}
else{eXE.wxVkey=2
}
eXE.wxXCkey=1
_(oNE,tWE)
}
oNE.wxXCkey=1
_(r,xME)
return r
}
e_[x[0]]={f:m0,j:[],i:[],ti:[],ic:[]}
if(path&&e_[path]){
return function(env,dd,global){$gwxc=0;var root={"tag":"wx-page"};root.children=[]
;g="$gwx_XC_20";var main=e_[path].f
if (typeof global==="undefined")global={};global.f=$gdc(f_[path],"",1);
try{
main(env,{},root,global);
_tsd(root)
}catch(err){
console.log(err)
}
;g="";
return root;
}
}
}
}(__g.a,__g.b,__g.c,__g.d,__g.e,__g.f,__g.g,__g.h,__g.i,__g.j,__g.k,__g.l,__g.m,__g.n,__g.o,__g.p,__g.q,__g.r,__g.s,__g.t,__g.u,__g.v,__g.w,__g.x,__g.y,__g.z,__g.A,__g.B,__g.C,__g.D,__g.E,__g.F,__g.G,__g.H,__g.I,__g.J,__g.K,__g.L,__g.M,__g.N,__g.O,__g.P,__g.Q,__g.R,__g.S,__g.T,__g.U,__g.V,__g.W,__g.X,__g.Y,__g.Z,__g.aa);if(__vd_version_info__.delayedGwx||false)$gwx_XC_20();	if (__vd_version_info__.delayedGwx) __wxAppCode__['components/vant/search/index.wxml'] = [$gwx_XC_20, './components/vant/search/index.wxml'];else __wxAppCode__['components/vant/search/index.wxml'] = $gwx_XC_20( './components/vant/search/index.wxml' );
	;__wxRoute = "components/vant/search/index";__wxRouteBegin = true;__wxAppCurrentFile__="components/vant/search/index.js";define("components/vant/search/index.js",function(require,module,exports,window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){
"use strict";Object.defineProperty(exports,"__esModule",{value:!0}),require("../common/component").VantComponent({field:!0,classes:["field-class","input-class","cancel-class"],props:{label:String,focus:Boolean,error:Boolean,disabled:Boolean,readonly:Boolean,inputAlign:String,showAction:Boolean,useActionSlot:Boolean,useLeftIconSlot:Boolean,useRightIconSlot:Boolean,confirmType:{type:String,value:"search"},leftIcon:{type:String,value:"search"},rightIcon:String,placeholder:String,placeholderStyle:String,actionText:{type:String,value:"取消"},background:{type:String,value:"#ffffff"},maxlength:{type:Number,value:-1},shape:{type:String,value:"square"},clearable:{type:Boolean,value:!0}},methods:{onChange:function(e){this.setData({value:e.detail}),this.$emit("change",e.detail)},onCancel:function(){var e=this;setTimeout((function(){e.setData({value:""}),e.$emit("cancel"),e.$emit("change","")}),200)},onSearch:function(){this.$emit("search",this.data.value)},onFocus:function(){this.$emit("focus")},onBlur:function(){this.$emit("blur")},onClear:function(){this.$emit("clear")}}});
},{isPage:false,isComponent:true,currentFile:'components/vant/search/index.js'});require("components/vant/search/index.js");