$gwx_XC_7=function(_,_v,_n,_p,_s,_wp,_wl,$gwn,$gwl,$gwh,wh,$gstack,$gwrt,gra,grb,TestTest,wfor,_ca,_da,_r,_rz,_o,_oz,_1,_1z,_2,_2z,_m,_mz,nv_getDate,nv_getRegExp,nv_console,nv_parseInt,nv_parseFloat,nv_isNaN,nv_isFinite,nv_decodeURI,nv_decodeURIComponent,nv_encodeURI,nv_encodeURIComponent,$gdc,nv_JSON,_af,_gv,_ai,_grp,_gd,_gapi,$ixc,_ic,_w,_ev,_tsd){return function(path,global){
if(typeof global==='undefined'){if (typeof __GWX_GLOBAL__==='undefined')global={};else global=__GWX_GLOBAL__;}if(typeof __WXML_GLOBAL__ === 'undefined') {__WXML_GLOBAL__={};
}__WXML_GLOBAL__.modules = __WXML_GLOBAL__.modules || {};
var e_={}
if(typeof(global.entrys)==='undefined')global.entrys={};e_=global.entrys;
var d_={}
if(typeof(global.defines)==='undefined')global.defines={};d_=global.defines;
var f_={}
if(typeof(global.modules)==='undefined')global.modules={};f_=global.modules || {};
var p_={}
__WXML_GLOBAL__.ops_cached = __WXML_GLOBAL__.ops_cached || {}
__WXML_GLOBAL__.ops_set = __WXML_GLOBAL__.ops_set || {};
__WXML_GLOBAL__.ops_init = __WXML_GLOBAL__.ops_init || {};
var z=__WXML_GLOBAL__.ops_set.$gwx_XC_7 || [];
function gz$gwx_XC_7_1(){
if( __WXML_GLOBAL__.ops_cached.$gwx_XC_7_1)return __WXML_GLOBAL__.ops_cached.$gwx_XC_7_1
__WXML_GLOBAL__.ops_cached.$gwx_XC_7_1=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
Z([3,'van-checkbox custom-class'])
Z([3,'toggle'])
Z([3,'van-checkbox__icon-wrap'])
Z([[7],[3,'useIconSlot']])
Z([3,'icon'])
Z([[12],[[6],[[7],[3,'utils']],[3,'bem']],[[5],[[5],[1,'checkbox__icon']],[[4],[[5],[[5],[[7],[3,'shape']]],[[9],[[8],'disabled',[[2,'||'],[[7],[3,'disabled']],[[7],[3,'parentDisabled']]]],[[8],'checked',[[7],[3,'value']]]]]]]])
Z([3,'icon-class'])
Z([3,'line-height: 1.25em;'])
Z([3,'success'])
Z([3,'0.8em'])
Z([[12],[[6],[[7],[3,'computed']],[3,'iconStyle']],[[5],[[5],[[5],[[5],[[5],[[7],[3,'checkedColor']]],[[7],[3,'value']]],[[7],[3,'disabled']]],[[7],[3,'parentDisabled']]],[[7],[3,'iconSize']]]])
Z([3,'onClickLabel'])
Z([a,[3,'label-class '],[[12],[[6],[[7],[3,'utils']],[3,'bem']],[[5],[[5],[1,'checkbox__label']],[[4],[[5],[[5],[[7],[3,'labelPosition']]],[[8],'disabled',[[2,'||'],[[7],[3,'disabled']],[[7],[3,'parentDisabled']]]]]]]]])
})(__WXML_GLOBAL__.ops_cached.$gwx_XC_7_1);return __WXML_GLOBAL__.ops_cached.$gwx_XC_7_1
}
__WXML_GLOBAL__.ops_set.$gwx_XC_7=z;
__WXML_GLOBAL__.ops_init.$gwx_XC_7=true;
var x=['./components/vant/checkbox/index.wxml'];d_[x[0]]={}
var m0=function(e,s,r,gg){
var z=gz$gwx_XC_7_1()
var l5B=_n('view')
_rz(z,l5B,'class',0,e,s,gg)
var a6B=_mz(z,'view',['bindtap',1,'class',1],[],e,s,gg)
var t7B=_v()
_(a6B,t7B)
if(_oz(z,3,e,s,gg)){t7B.wxVkey=1
var e8B=_n('slot')
_rz(z,e8B,'name',4,e,s,gg)
_(t7B,e8B)
}
else{t7B.wxVkey=2
var b9B=_mz(z,'van-icon',['class',5,'customClass',1,'customStyle',2,'name',3,'size',4,'style',5],[],e,s,gg)
_(t7B,b9B)
}
t7B.wxXCkey=1
t7B.wxXCkey=3
_(l5B,a6B)
var o0B=_mz(z,'view',['bindtap',11,'class',1],[],e,s,gg)
var xAC=_n('slot')
_(o0B,xAC)
_(l5B,o0B)
_(r,l5B)
return r
}
e_[x[0]]={f:m0,j:[],i:[],ti:[],ic:[]}
if(path&&e_[path]){
return function(env,dd,global){$gwxc=0;var root={"tag":"wx-page"};root.children=[]
;g="$gwx_XC_7";var main=e_[path].f
if (typeof global==="undefined")global={};global.f=$gdc(f_[path],"",1);
try{
main(env,{},root,global);
_tsd(root)
}catch(err){
console.log(err)
}
;g="";
return root;
}
}
}
}(__g.a,__g.b,__g.c,__g.d,__g.e,__g.f,__g.g,__g.h,__g.i,__g.j,__g.k,__g.l,__g.m,__g.n,__g.o,__g.p,__g.q,__g.r,__g.s,__g.t,__g.u,__g.v,__g.w,__g.x,__g.y,__g.z,__g.A,__g.B,__g.C,__g.D,__g.E,__g.F,__g.G,__g.H,__g.I,__g.J,__g.K,__g.L,__g.M,__g.N,__g.O,__g.P,__g.Q,__g.R,__g.S,__g.T,__g.U,__g.V,__g.W,__g.X,__g.Y,__g.Z,__g.aa);if(__vd_version_info__.delayedGwx||false)$gwx_XC_7();	if (__vd_version_info__.delayedGwx) __wxAppCode__['components/vant/checkbox/index.wxml'] = [$gwx_XC_7, './components/vant/checkbox/index.wxml'];else __wxAppCode__['components/vant/checkbox/index.wxml'] = $gwx_XC_7( './components/vant/checkbox/index.wxml' );
	;__wxRoute = "components/vant/checkbox/index";__wxRouteBegin = true;__wxAppCurrentFile__="components/vant/checkbox/index.js";define("components/vant/checkbox/index.js",function(require,module,exports,window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){
"use strict";function e(e,a){e.$emit("input",a),e.$emit("change",a)}Object.defineProperty(exports,"__esModule",{value:!0}),require("../common/component").VantComponent({field:!0,relation:{name:"checkbox-group",type:"ancestor",current:"checkbox"},classes:["icon-class","label-class"],props:{value:Boolean,disabled:Boolean,useIconSlot:Boolean,checkedColor:String,labelPosition:String,labelDisabled:Boolean,shape:{type:String,value:"round"},iconSize:{type:null,value:20}},data:{parentDisabled:!1},methods:{emitChange:function(a){this.parent?this.setParentValue(this.parent,a):e(this,a)},toggle:function(){var e=this.data,a=e.parentDisabled,t=e.disabled,n=e.value;t||a||this.emitChange(!n)},onClickLabel:function(){var e=this.data,a=e.labelDisabled,t=e.parentDisabled,n=e.disabled,i=e.value;n||a||t||this.emitChange(!i)},setParentValue:function(a,t){var n=a.data.value.slice(),i=this.data.name,l=a.data.max;if(t){if(l&&n.length>=l)return;-1===n.indexOf(i)&&(n.push(i),e(a,n))}else{var o=n.indexOf(i);-1!==o&&(n.splice(o,1),e(a,n))}}}});
},{isPage:false,isComponent:true,currentFile:'components/vant/checkbox/index.js'});require("components/vant/checkbox/index.js");