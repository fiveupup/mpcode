$gwx_XC_1=function(_,_v,_n,_p,_s,_wp,_wl,$gwn,$gwl,$gwh,wh,$gstack,$gwrt,gra,grb,TestTest,wfor,_ca,_da,_r,_rz,_o,_oz,_1,_1z,_2,_2z,_m,_mz,nv_getDate,nv_getRegExp,nv_console,nv_parseInt,nv_parseFloat,nv_isNaN,nv_isFinite,nv_decodeURI,nv_decodeURIComponent,nv_encodeURI,nv_encodeURIComponent,$gdc,nv_JSON,_af,_gv,_ai,_grp,_gd,_gapi,$ixc,_ic,_w,_ev,_tsd){return function(path,global){
if(typeof global==='undefined'){if (typeof __GWX_GLOBAL__==='undefined')global={};else global=__GWX_GLOBAL__;}if(typeof __WXML_GLOBAL__ === 'undefined') {__WXML_GLOBAL__={};
}__WXML_GLOBAL__.modules = __WXML_GLOBAL__.modules || {};
var e_={}
if(typeof(global.entrys)==='undefined')global.entrys={};e_=global.entrys;
var d_={}
if(typeof(global.defines)==='undefined')global.defines={};d_=global.defines;
var f_={}
if(typeof(global.modules)==='undefined')global.modules={};f_=global.modules || {};
var p_={}
__WXML_GLOBAL__.ops_cached = __WXML_GLOBAL__.ops_cached || {}
__WXML_GLOBAL__.ops_set = __WXML_GLOBAL__.ops_set || {};
__WXML_GLOBAL__.ops_init = __WXML_GLOBAL__.ops_init || {};
var z=__WXML_GLOBAL__.ops_set.$gwx_XC_1 || [];
function gz$gwx_XC_1_1(){
if( __WXML_GLOBAL__.ops_cached.$gwx_XC_1_1)return __WXML_GLOBAL__.ops_cached.$gwx_XC_1_1
__WXML_GLOBAL__.ops_cached.$gwx_XC_1_1=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
Z([[7],[3,'showFooter']])
Z([a,[3,'background:'],[[7],[3,'background']],[3,';padding:10rpx 16rpx '],[[2,'?:'],[[7],[3,'isIphoneX']],[1,'calc(env(safe-area-inset-bottom))'],[1,'calc(env(safe-area-inset-bottom) + 24rpx)']],[3,' 16rpx;text-align:center;position:'],[[2,'?:'],[[7],[3,'isFixed']],[1,'fixed'],[1,'absolute']],[3,';bottom:0;width:100%;box-sizing:border-box;display:flex;justify-content:center;']])
Z([[7],[3,'showMethod']])
Z([3,'footerBtn'])
Z([3,'color: #707070;display:flex;justify-content:center;align-items: center;'])
Z([3,' 本页由小正方助手技术支持 '])
})(__WXML_GLOBAL__.ops_cached.$gwx_XC_1_1);return __WXML_GLOBAL__.ops_cached.$gwx_XC_1_1
}
__WXML_GLOBAL__.ops_set.$gwx_XC_1=z;
__WXML_GLOBAL__.ops_init.$gwx_XC_1=true;
var x=['./components/footer/footer.wxml'];d_[x[0]]={}
var m0=function(e,s,r,gg){
var z=gz$gwx_XC_1_1()
var o4=_v()
_(r,o4)
if(_oz(z,0,e,s,gg)){o4.wxVkey=1
var x5=_n('view')
_rz(z,x5,'style',1,e,s,gg)
var o6=_v()
_(x5,o6)
if(_oz(z,2,e,s,gg)){o6.wxVkey=1
var f7=_n('view')
_rz(z,f7,'class',3,e,s,gg)
var c8=_n('view')
_rz(z,c8,'style',4,e,s,gg)
var h9=_oz(z,5,e,s,gg)
_(c8,h9)
_(f7,c8)
_(o6,f7)
}
o6.wxXCkey=1
_(o4,x5)
}
o4.wxXCkey=1
return r
}
e_[x[0]]={f:m0,j:[],i:[],ti:[],ic:[]}
if(path&&e_[path]){
outerGlobal.__wxml_comp_version__=0.02
return function(env,dd,global){$gwxc=0;var root={"tag":"wx-page"};root.children=[]
;g="$gwx_XC_1";var main=e_[path].f
if (typeof global==="undefined")global={};global.f=$gdc(f_[path],"",1);
if(typeof(outerGlobal.__webview_engine_version__)!='undefined'&&outerGlobal.__webview_engine_version__+1e-6>=0.02+1e-6&&outerGlobal.__mergeData__)
{
env=outerGlobal.__mergeData__(env,dd);
}
try{
main(env,{},root,global);
_tsd(root)
if(typeof(outerGlobal.__webview_engine_version__)=='undefined'|| outerGlobal.__webview_engine_version__+1e-6<0.01+1e-6){return _ev(root);}
}catch(err){
console.log(err)
}
;g="";
return root;
}
}
}
}(__g.a,__g.b,__g.c,__g.d,__g.e,__g.f,__g.g,__g.h,__g.i,__g.j,__g.k,__g.l,__g.m,__g.n,__g.o,__g.p,__g.q,__g.r,__g.s,__g.t,__g.u,__g.v,__g.w,__g.x,__g.y,__g.z,__g.A,__g.B,__g.C,__g.D,__g.E,__g.F,__g.G,__g.H,__g.I,__g.J,__g.K,__g.L,__g.M,__g.N,__g.O,__g.P,__g.Q,__g.R,__g.S,__g.T,__g.U,__g.V,__g.W,__g.X,__g.Y,__g.Z,__g.aa);if(__vd_version_info__.delayedGwx||false)$gwx_XC_1();	if (__vd_version_info__.delayedGwx) __wxAppCode__['components/footer/footer.wxml'] = [$gwx_XC_1, './components/footer/footer.wxml'];else __wxAppCode__['components/footer/footer.wxml'] = $gwx_XC_1( './components/footer/footer.wxml' );
	
var noCss=typeof __vd_version_info__!=='undefined'&&__vd_version_info__.noCss===true;if(!noCss){__wxAppCode__['components/footer/footer.wxss'] = setCssToHead([".",[1],"footerBtn{background:none;border:0!important;border-radius:0;box-sizing:content-box;color:#547387;font-size:",[0,24],";font-weight:400;line-height:inherit;margin:0 ",[0,10],";padding:0;width:-webkit-max-content;width:max-content}\nwx-button.",[1],"footerBtn::after{border:none}\n",],"Some selectors are not allowed in component wxss, including tag name selectors, ID selectors, and attribute selectors.(./components/footer/footer.wxss:1:221)",{path:"./components/footer/footer.wxss"});
}