$gwx_XC_34=function(_,_v,_n,_p,_s,_wp,_wl,$gwn,$gwl,$gwh,wh,$gstack,$gwrt,gra,grb,TestTest,wfor,_ca,_da,_r,_rz,_o,_oz,_1,_1z,_2,_2z,_m,_mz,nv_getDate,nv_getRegExp,nv_console,nv_parseInt,nv_parseFloat,nv_isNaN,nv_isFinite,nv_decodeURI,nv_decodeURIComponent,nv_encodeURI,nv_encodeURIComponent,$gdc,nv_JSON,_af,_gv,_ai,_grp,_gd,_gapi,$ixc,_ic,_w,_ev,_tsd){return function(path,global){
if(typeof global==='undefined'){if (typeof __GWX_GLOBAL__==='undefined')global={};else global=__GWX_GLOBAL__;}if(typeof __WXML_GLOBAL__ === 'undefined') {__WXML_GLOBAL__={};
}__WXML_GLOBAL__.modules = __WXML_GLOBAL__.modules || {};
var e_={}
if(typeof(global.entrys)==='undefined')global.entrys={};e_=global.entrys;
var d_={}
if(typeof(global.defines)==='undefined')global.defines={};d_=global.defines;
var f_={}
if(typeof(global.modules)==='undefined')global.modules={};f_=global.modules || {};
var p_={}
__WXML_GLOBAL__.ops_cached = __WXML_GLOBAL__.ops_cached || {}
__WXML_GLOBAL__.ops_set = __WXML_GLOBAL__.ops_set || {};
__WXML_GLOBAL__.ops_init = __WXML_GLOBAL__.ops_init || {};
var z=__WXML_GLOBAL__.ops_set.$gwx_XC_34 || [];
function gz$gwx_XC_34_1(){
if( __WXML_GLOBAL__.ops_cached.$gwx_XC_34_1)return __WXML_GLOBAL__.ops_cached.$gwx_XC_34_1
__WXML_GLOBAL__.ops_cached.$gwx_XC_34_1=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
Z([3,'page'])
Z([[7],[3,'show']])
Z([3,'weui-msg'])
Z([3,'padding-top:0;'])
Z([3,'weui-msg__text-area'])
Z([3,'weui-msg__title'])
Z([3,'color:#07c160;'])
Z([[2,'!'],[[7],[3,'showPhone']]])
Z([3,'true'])
Z([a,[[2,'?:'],[[6],[[7],[3,'safeUser']],[3,'safe_text']],[[6],[[7],[3,'safeUser']],[3,'safe_text']],[1,'对方号码保护中']]])
Z(z[8])
Z([a,[[6],[[7],[3,'safeUser']],[3,'phone']]])
Z([3,'weui-cells__title'])
Z([3,'font-size:32rpx;text-align:center;margin-bottom:30rpx;'])
Z([[6],[[7],[3,'safeUser']],[3,'name']])
Z([a,[[6],[[7],[3,'safeUser']],[3,'name']]])
Z([3,'weui-msg__opr-area'])
Z([3,'weui-btn-area'])
Z([[6],[[7],[3,'safeUser']],[3,'msg']])
Z([3,'toMsg'])
Z([3,'weui-btn weui-btn_default'])
Z([3,'display:flex;align-items:center;justify-content:center;border-radius:51rpx;'])
Z([3,'https://cos.wsqytec.com/static/msg.png'])
Z([3,'width:70rpx;height:70rpx;'])
Z([3,' 留言 '])
Z([[7],[3,'showPhone']])
Z([3,'call'])
Z([3,'weui-btn weui-btn_primary'])
Z(z[21])
Z([3,'https://cos.wsqytec.com/static/call.png'])
Z(z[23])
Z([3,' 呼叫 '])
Z([[2,'&&'],[[2,'&&'],[[2,'!'],[[7],[3,'showPhone']]],[[2,'!'],[[6],[[7],[3,'safeUser']],[3,'rest']]]],[[2,'!'],[[7],[3,'scPhones']]]])
Z([3,'getPhoneNumber'])
Z([3,'unChooseScPhones'])
Z([3,'footerBtn weui-btn weui-btn_primary'])
Z(z[33])
Z([3,'border:0;display:flex;align-items:center;justify-content:center;border-radius:51rpx;'])
Z(z[29])
Z(z[23])
Z([3,' 虚拟号呼叫 '])
Z([[2,'&&'],[[2,'&&'],[[2,'!'],[[7],[3,'showPhone']]],[[2,'!'],[[6],[[7],[3,'safeUser']],[3,'rest']]]],[[7],[3,'scPhones']]])
Z([3,'chooseScPhones'])
Z(z[35])
Z(z[37])
Z(z[29])
Z(z[23])
Z(z[40])
Z([[2,'&&'],[[2,'!'],[[7],[3,'showPhone']]],[[6],[[7],[3,'safeUser']],[3,'rest']]])
Z(z[20])
Z([3,'display:flex;align-items:center;justify-content:center;border-radius:51px;'])
Z([3,'免打扰中'])
Z([3,'clear:both;'])
Z([[2,'&&'],[[2,'!'],[[6],[[7],[3,'safeUser']],[3,'rest']]],[[2,'!'],[[7],[3,'showPhone']]]])
Z([3,'font-size:30rpx;margin-top:20rpx;color:#707070;padding:0 10%;'])
Z([3,'保护双方隐私，通话将启用虚拟号码'])
Z([3,'font-size:22rpx;margin-top: 6rpx;display:flex;align-items:center;justify-content:center;'])
Z([3,'color: #e99e00;font-size: 18rpx;margin-right: 8rpx;'])
Z([3,'✱'])
Z([3,'双卡用户请使用手机默认语音号码授权建立安全连接'])
Z([3,'weui-msg__desc'])
Z([[2,'=='],[[6],[[7],[3,'safeUser']],[3,'curOpenid']],[[6],[[7],[3,'safeUser']],[3,'openid']]])
Z([3,'toSafe'])
Z([3,'我的设置'])
Z([3,'color: #707070;font-size: 24rpx;'])
Z([3,'本页由小正方助手技术支持'])
Z(z[7])
Z([3,'userKnow'])
Z([3,'color:rgb(84, 115, 135);margin-left:10rpx;font-weight: bold;'])
Z([3,'用户须知'])
Z([[2,'!'],[[7],[3,'show']]])
Z([3,'display: flex;align-items: center;justify-content: center;width:100%;'])
Z([3,'box2'])
Z([3,'margin-top:25%;'])
Z([3,'bottom'])
Z([1,true])
Z([[2,'&&'],[[7],[3,'chooseScPhonesShow']],[[7],[3,'scPhones']]])
Z([3,'999999'])
Z([3,'padding:40rpx 36rpx;background-color: #ededed;'])
Z([3,'margin-bottom: 40rpx;'])
Z([3,'color: #202020;font-size: 34rpx;font-weight: bold;'])
Z([3,'安全通话'])
Z([3,'color:#707070;font-size: 30rpx;'])
Z([3,'选择手机默认语音号码与对方建立虚拟号连接'])
Z([[7],[3,'scPhones']])
Z([3,'item'])
Z([[2,'=='],[[7],[3,'index']],[1,0]])
Z([3,'chooseScPhonesItem'])
Z([3,'myBtn'])
Z([[7],[3,'item']])
Z([a,[[12],[[6],[[7],[3,'myutil']],[3,'phoneFormat']],[[5],[[7],[3,'item']]]],[3,' ']])
Z(z[86])
Z([3,'font-size: 24rpx;color:#707070;'])
Z([3,'(上次)'])
Z(z[33])
Z(z[34])
Z(z[88])
Z(z[33])
Z([3,'其他号码 '])
Z(z[34])
Z(z[88])
Z([3,'margin-top: 40rpx;'])
Z([3,'取消'])
Z([3,'text-align: center;margin:26rpx;font-size: 28rpx;'])
Z(z[67])
Z([3,'color:rgb(84, 115, 135);font-weight: bold;'])
Z(z[69])
Z([3,'myPrivacy'])
})(__WXML_GLOBAL__.ops_cached.$gwx_XC_34_1);return __WXML_GLOBAL__.ops_cached.$gwx_XC_34_1
}
__WXML_GLOBAL__.ops_set.$gwx_XC_34=z;
__WXML_GLOBAL__.ops_init.$gwx_XC_34=true;
var x=['./sc/c.wxml'];d_[x[0]]={}
var m0=function(e,s,r,gg){
var z=gz$gwx_XC_34_1()
var a07=_n('view')
_rz(z,a07,'class',0,e,s,gg)
var tA8=_v()
_(a07,tA8)
if(_oz(z,1,e,s,gg)){tA8.wxVkey=1
var bC8=_mz(z,'view',['class',2,'style',1],[],e,s,gg)
var oD8=_n('view')
_rz(z,oD8,'class',4,e,s,gg)
var xE8=_mz(z,'h2',['class',5,'style',1],[],e,s,gg)
var oF8=_v()
_(xE8,oF8)
if(_oz(z,7,e,s,gg)){oF8.wxVkey=1
var fG8=_n('text')
_rz(z,fG8,'userSelect',8,e,s,gg)
var cH8=_oz(z,9,e,s,gg)
_(fG8,cH8)
_(oF8,fG8)
}
else{oF8.wxVkey=2
var hI8=_n('text')
_rz(z,hI8,'userSelect',10,e,s,gg)
var oJ8=_oz(z,11,e,s,gg)
_(hI8,oJ8)
_(oF8,hI8)
}
oF8.wxXCkey=1
_(oD8,xE8)
var cK8=_mz(z,'view',['class',12,'style',1],[],e,s,gg)
var oL8=_v()
_(cK8,oL8)
if(_oz(z,14,e,s,gg)){oL8.wxVkey=1
var lM8=_n('text')
var aN8=_oz(z,15,e,s,gg)
_(lM8,aN8)
_(oL8,lM8)
}
oL8.wxXCkey=1
_(oD8,cK8)
_(bC8,oD8)
var tO8=_n('view')
_rz(z,tO8,'class',16,e,s,gg)
var eP8=_n('view')
_rz(z,eP8,'class',17,e,s,gg)
var bQ8=_v()
_(eP8,bQ8)
if(_oz(z,18,e,s,gg)){bQ8.wxVkey=1
var hW8=_mz(z,'a',['bindtap',19,'class',1,'style',2],[],e,s,gg)
var oX8=_mz(z,'image',['src',22,'style',1],[],e,s,gg)
_(hW8,oX8)
var cY8=_oz(z,24,e,s,gg)
_(hW8,cY8)
_(bQ8,hW8)
}
var oR8=_v()
_(eP8,oR8)
if(_oz(z,25,e,s,gg)){oR8.wxVkey=1
var oZ8=_mz(z,'a',['bindtap',26,'class',1,'style',2],[],e,s,gg)
var l18=_mz(z,'image',['src',29,'style',1],[],e,s,gg)
_(oZ8,l18)
var a28=_oz(z,31,e,s,gg)
_(oZ8,a28)
_(oR8,oZ8)
}
var xS8=_v()
_(eP8,xS8)
if(_oz(z,32,e,s,gg)){xS8.wxVkey=1
var t38=_mz(z,'button',['bindgetphonenumber',33,'bindtap',1,'class',2,'openType',3,'style',4],[],e,s,gg)
var e48=_mz(z,'image',['src',38,'style',1],[],e,s,gg)
_(t38,e48)
var b58=_oz(z,40,e,s,gg)
_(t38,b58)
_(xS8,t38)
}
var oT8=_v()
_(eP8,oT8)
if(_oz(z,41,e,s,gg)){oT8.wxVkey=1
var o68=_mz(z,'button',['bindtap',42,'class',1,'style',2],[],e,s,gg)
var x78=_mz(z,'image',['src',45,'style',1],[],e,s,gg)
_(o68,x78)
var o88=_oz(z,47,e,s,gg)
_(o68,o88)
_(oT8,o68)
}
var fU8=_v()
_(eP8,fU8)
if(_oz(z,48,e,s,gg)){fU8.wxVkey=1
var f98=_mz(z,'a',['class',49,'style',1],[],e,s,gg)
var c08=_n('text')
var hA9=_oz(z,51,e,s,gg)
_(c08,hA9)
_(f98,c08)
_(fU8,f98)
}
var oB9=_n('view')
_rz(z,oB9,'style',52,e,s,gg)
_(eP8,oB9)
var cV8=_v()
_(eP8,cV8)
if(_oz(z,53,e,s,gg)){cV8.wxVkey=1
var cC9=_n('view')
_rz(z,cC9,'style',54,e,s,gg)
var oD9=_n('view')
var lE9=_oz(z,55,e,s,gg)
_(oD9,lE9)
_(cC9,oD9)
var aF9=_n('view')
_rz(z,aF9,'style',56,e,s,gg)
var tG9=_n('text')
_rz(z,tG9,'style',57,e,s,gg)
var eH9=_oz(z,58,e,s,gg)
_(tG9,eH9)
_(aF9,tG9)
var bI9=_oz(z,59,e,s,gg)
_(aF9,bI9)
_(cC9,aF9)
_(cV8,cC9)
}
bQ8.wxXCkey=1
oR8.wxXCkey=1
xS8.wxXCkey=1
oT8.wxXCkey=1
fU8.wxXCkey=1
cV8.wxXCkey=1
_(tO8,eP8)
_(bC8,tO8)
var oJ9=_n('view')
_rz(z,oJ9,'class',60,e,s,gg)
var xK9=_v()
_(oJ9,xK9)
if(_oz(z,61,e,s,gg)){xK9.wxVkey=1
var oL9=_n('a')
_rz(z,oL9,'bindtap',62,e,s,gg)
var fM9=_oz(z,63,e,s,gg)
_(oL9,fM9)
_(xK9,oL9)
}
else{xK9.wxVkey=2
var cN9=_n('view')
_rz(z,cN9,'style',64,e,s,gg)
var oP9=_oz(z,65,e,s,gg)
_(cN9,oP9)
var hO9=_v()
_(cN9,hO9)
if(_oz(z,66,e,s,gg)){hO9.wxVkey=1
var cQ9=_mz(z,'text',['bindtap',67,'style',1],[],e,s,gg)
var oR9=_oz(z,69,e,s,gg)
_(cQ9,oR9)
_(hO9,cQ9)
}
hO9.wxXCkey=1
_(xK9,cN9)
}
xK9.wxXCkey=1
_(bC8,oJ9)
_(tA8,bC8)
}
var eB8=_v()
_(a07,eB8)
if(_oz(z,70,e,s,gg)){eB8.wxVkey=1
var lS9=_n('view')
_rz(z,lS9,'style',71,e,s,gg)
var aT9=_mz(z,'view',['class',72,'style',1],[],e,s,gg)
_(lS9,aT9)
_(eB8,lS9)
}
tA8.wxXCkey=1
eB8.wxXCkey=1
_(r,a07)
var tU9=_mz(z,'page-container',['position',74,'round',1,'show',2,'zIndex',3],[],e,s,gg)
var eV9=_n('view')
_rz(z,eV9,'style',78,e,s,gg)
var bW9=_n('view')
_rz(z,bW9,'style',79,e,s,gg)
var oX9=_n('view')
_rz(z,oX9,'style',80,e,s,gg)
var xY9=_oz(z,81,e,s,gg)
_(oX9,xY9)
_(bW9,oX9)
var oZ9=_n('view')
_rz(z,oZ9,'style',82,e,s,gg)
var f19=_oz(z,83,e,s,gg)
_(oZ9,f19)
_(bW9,oZ9)
_(eV9,bW9)
var c29=_v()
_(eV9,c29)
var h39=function(c59,o49,o69,gg){
var a89=_v()
_(o69,a89)
if(_oz(z,86,c59,o49,gg)){a89.wxVkey=1
var t99=_mz(z,'button',['bindtap',87,'class',1,'data-phone',2],[],c59,o49,gg)
var bA0=_oz(z,90,c59,o49,gg)
_(t99,bA0)
var e09=_v()
_(t99,e09)
if(_oz(z,91,c59,o49,gg)){e09.wxVkey=1
var oB0=_n('text')
_rz(z,oB0,'style',92,c59,o49,gg)
var xC0=_oz(z,93,c59,o49,gg)
_(oB0,xC0)
_(e09,oB0)
}
e09.wxXCkey=1
_(a89,t99)
}
a89.wxXCkey=1
return o69
}
c29.wxXCkey=2
_2z(z,84,h39,e,s,gg,c29,'item','index','item')
var oD0=_mz(z,'button',['bindgetphonenumber',94,'bindtap',1,'class',2,'openType',3],[],e,s,gg)
var fE0=_oz(z,98,e,s,gg)
_(oD0,fE0)
_(eV9,oD0)
var cF0=_mz(z,'button',['bindtap',99,'class',1,'style',2],[],e,s,gg)
var hG0=_oz(z,102,e,s,gg)
_(cF0,hG0)
_(eV9,cF0)
var oH0=_n('view')
_rz(z,oH0,'style',103,e,s,gg)
var cI0=_mz(z,'text',['bindtap',104,'style',1],[],e,s,gg)
var oJ0=_oz(z,106,e,s,gg)
_(cI0,oJ0)
_(oH0,cI0)
_(eV9,oH0)
_(tU9,eV9)
_(r,tU9)
var lK0=_n('my-privacy')
_rz(z,lK0,'id',107,e,s,gg)
_(r,lK0)
return r
}
e_[x[0]]={f:m0,j:[],i:[],ti:[],ic:[]}
if(path&&e_[path]){
outerGlobal.__wxml_comp_version__=0.02
return function(env,dd,global){$gwxc=0;var root={"tag":"wx-page"};root.children=[]
;g="$gwx_XC_34";var main=e_[path].f
if (typeof global==="undefined")global={};global.f=$gdc(f_[path],"",1);
if(typeof(outerGlobal.__webview_engine_version__)!='undefined'&&outerGlobal.__webview_engine_version__+1e-6>=0.02+1e-6&&outerGlobal.__mergeData__)
{
env=outerGlobal.__mergeData__(env,dd);
}
try{
main(env,{},root,global);
_tsd(root)
if(typeof(outerGlobal.__webview_engine_version__)=='undefined'|| outerGlobal.__webview_engine_version__+1e-6<0.01+1e-6){return _ev(root);}
}catch(err){
console.log(err)
}
;g="";
return root;
}
}
}
}(__g.a,__g.b,__g.c,__g.d,__g.e,__g.f,__g.g,__g.h,__g.i,__g.j,__g.k,__g.l,__g.m,__g.n,__g.o,__g.p,__g.q,__g.r,__g.s,__g.t,__g.u,__g.v,__g.w,__g.x,__g.y,__g.z,__g.A,__g.B,__g.C,__g.D,__g.E,__g.F,__g.G,__g.H,__g.I,__g.J,__g.K,__g.L,__g.M,__g.N,__g.O,__g.P,__g.Q,__g.R,__g.S,__g.T,__g.U,__g.V,__g.W,__g.X,__g.Y,__g.Z,__g.aa);if(__vd_version_info__.delayedGwx||false)$gwx_XC_34();	if (__vd_version_info__.delayedGwx) __wxAppCode__['sc/c.wxml'] = [$gwx_XC_34, './sc/c.wxml'];else __wxAppCode__['sc/c.wxml'] = $gwx_XC_34( './sc/c.wxml' );
	
var noCss=typeof __vd_version_info__!=='undefined'&&__vd_version_info__.noCss===true;if(!noCss){__wxAppCode__['sc/c.wxss'] = setCssToHead([".",[1],"weui-msg{-webkit-box-orient:vertical;-webkit-box-direction:normal;background-color:var(--weui-BG-2);box-sizing:border-box;display:-webkit-box;display:-webkit-flex;display:flex;-webkit-flex-direction:column;flex-direction:column;line-height:1.4;min-height:100%;padding:calc(",[0,96]," + env(safe-area-inset-top)) env(safe-area-inset-right) env(safe-area-inset-bottom) env(safe-area-inset-left);text-align:center}\n.",[1],"weui-msg wx-a:not(.",[1],"weui-btn){color:var(--weui-LINK);display:inline-block;vertical-align:baseline}\n.",[1],"weui-msg__icon-area{margin-bottom:",[0,64],"}\n.",[1],"weui-msg__text-area{-webkit-box-flex:1;-webkit-flex:1;flex:1;line-height:1.6;margin-bottom:",[0,64],";padding:0 ",[0,64],"}\n.",[1],"weui-msg__text-area:first-child{padding-top:",[0,140],"}\n.",[1],"weui-msg__title{font-size:",[0,52],";font-weight:550}\n.",[1],"weui-msg__desc,.",[1],"weui-msg__title{word-wrap:break-word;color:var(--weui-FG-0);margin-bottom:",[0,32],";word-break:break-all}\n.",[1],"weui-msg__desc{font-size:",[0,30],"}\n.",[1],"weui-msg__desc-primary{word-wrap:break-word;color:var(--weui-FG-1);font-size:",[0,28],";margin-bottom:",[0,32],";word-break:break-all}\n.",[1],"weui-msg__opr-area{margin-bottom:",[0,100],"}\n.",[1],"weui-msg__opr-area .",[1],"weui-btn-area{margin:0}\n.",[1],"weui-msg__opr-area .",[1],"weui-btn+.",[1],"weui-btn{margin-bottom:",[0,32],"}\n.",[1],"weui-msg__opr-area:last-child{margin-bottom:144px}\n.",[1],"weui-msg__opr-area+.",[1],"weui-msg__extra-area{margin-top:",[0,96],"}\n.",[1],"weui-msg__tips-area{margin-bottom:",[0,32],";padding:0 ",[0,80],"}\n.",[1],"weui-msg__opr-area+.",[1],"weui-msg__tips-area{margin-bottom:",[0,96],"}\n.",[1],"weui-msg__tips-area:last-child{margin-bottom:",[0,128],"}\n.",[1],"weui-msg__extra-area,.",[1],"weui-msg__tips{color:var(--weui-FG-1);font-size:",[0,24],"}\n.",[1],"weui-msg__extra-area{margin-bottom:",[0,48],"}\n.",[1],"weui-msg__extra-area wx-a,.",[1],"weui-msg__extra-area wx-navigator{color:var(--weui-LINK)}\n.",[1],"weui-msg__extra-area wx-navigator{display:inline}\n.",[1],"weui-msg__extra-area{position:static}\n.",[1],"page{background-color:var(--weui-BG-2);height:100%}\n.",[1],"footerBtn{border:0!important;min-width:184px;width:56%!important}\nwx-button.",[1],"footerBtn::after{border:none}\n.",[1],"box2{-webkit-animation:spin 1s linear infinite;animation:spin 1s linear infinite;border:2px solid #ccc;border-radius:50%;border-top-color:#07c160;height:1.4em;width:1.4em}\n@-webkit-keyframes spin{to{-webkit-transform:rotate(1turn);transform:rotate(1turn)}\n}@keyframes spin{to{-webkit-transform:rotate(1turn);transform:rotate(1turn)}\n}.",[1],"myBtn{border-radius:",[0,16],";color:#202020;font-size:",[0,34],";margin-bottom:",[0,15],";padding:",[0,14],"}\nwx-button.",[1],"myBtn::after{border:none}\n",],"Some selectors are not allowed in component wxss, including tag name selectors, ID selectors, and attribute selectors.(./sc/c.wxss:1:2320)",{path:"./sc/c.wxss"});
}