$gwx_XC_34=function(_,_v,_n,_p,_s,_wp,_wl,$gwn,$gwl,$gwh,wh,$gstack,$gwrt,gra,grb,TestTest,wfor,_ca,_da,_r,_rz,_o,_oz,_1,_1z,_2,_2z,_m,_mz,nv_getDate,nv_getRegExp,nv_console,nv_parseInt,nv_parseFloat,nv_isNaN,nv_isFinite,nv_decodeURI,nv_decodeURIComponent,nv_encodeURI,nv_encodeURIComponent,$gdc,nv_JSON,_af,_gv,_ai,_grp,_gd,_gapi,$ixc,_ic,_w,_ev,_tsd){return function(path,global){
if(typeof global==='undefined'){if (typeof __GWX_GLOBAL__==='undefined')global={};else global=__GWX_GLOBAL__;}if(typeof __WXML_GLOBAL__ === 'undefined') {__WXML_GLOBAL__={};
}__WXML_GLOBAL__.modules = __WXML_GLOBAL__.modules || {};
var e_={}
if(typeof(global.entrys)==='undefined')global.entrys={};e_=global.entrys;
var d_={}
if(typeof(global.defines)==='undefined')global.defines={};d_=global.defines;
var f_={}
if(typeof(global.modules)==='undefined')global.modules={};f_=global.modules || {};
var p_={}
__WXML_GLOBAL__.ops_cached = __WXML_GLOBAL__.ops_cached || {}
__WXML_GLOBAL__.ops_set = __WXML_GLOBAL__.ops_set || {};
__WXML_GLOBAL__.ops_init = __WXML_GLOBAL__.ops_init || {};
var z=__WXML_GLOBAL__.ops_set.$gwx_XC_34 || [];
function gz$gwx_XC_34_1(){
if( __WXML_GLOBAL__.ops_cached.$gwx_XC_34_1)return __WXML_GLOBAL__.ops_cached.$gwx_XC_34_1
__WXML_GLOBAL__.ops_cached.$gwx_XC_34_1=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
Z([3,'page'])
Z([[7],[3,'show']])
Z([3,'weui-msg'])
Z([3,'padding-top:0;'])
Z([[6],[[7],[3,'safeUser']],[3,'name']])
Z([3,'weui-btn-area'])
Z([[6],[[7],[3,'safeUser']],[3,'msg']])
Z([[7],[3,'showPhone']])
Z([[2,'&&'],[[2,'&&'],[[2,'!'],[[7],[3,'showPhone']]],[[2,'!'],[[6],[[7],[3,'safeUser']],[3,'rest']]]],[[2,'!'],[[7],[3,'scPhones']]]])
Z([[2,'&&'],[[2,'&&'],[[2,'!'],[[7],[3,'showPhone']]],[[2,'!'],[[6],[[7],[3,'safeUser']],[3,'rest']]]],[[7],[3,'scPhones']]])
Z([[2,'&&'],[[2,'!'],[[7],[3,'showPhone']]],[[6],[[7],[3,'safeUser']],[3,'rest']]])
Z([[2,'&&'],[[2,'!'],[[6],[[7],[3,'safeUser']],[3,'rest']]],[[2,'!'],[[7],[3,'showPhone']]]])
Z([3,'weui-msg__desc'])
Z([[2,'=='],[[6],[[7],[3,'safeUser']],[3,'curOpenid']],[[6],[[7],[3,'safeUser']],[3,'openid']]])
Z([[2,'!'],[[7],[3,'showPhone']]])
Z([[2,'!'],[[7],[3,'show']]])
Z([[7],[3,'scPhones']])
Z([3,'item'])
Z([[2,'=='],[[7],[3,'index']],[1,0]])
Z([3,'chooseScPhonesItem'])
Z([3,'myBtn'])
Z([[7],[3,'item']])
Z(z[18])
Z([3,'myPrivacy'])
})(__WXML_GLOBAL__.ops_cached.$gwx_XC_34_1);return __WXML_GLOBAL__.ops_cached.$gwx_XC_34_1
}
__WXML_GLOBAL__.ops_set.$gwx_XC_34=z;
__WXML_GLOBAL__.ops_init.$gwx_XC_34=true;
var x=['./sc/c.wxml'];d_[x[0]]={}
var m0=function(e,s,r,gg){
var z=gz$gwx_XC_34_1()
var xCO=_n('view')
_rz(z,xCO,'class',0,e,s,gg)
var oDO=_v()
_(xCO,oDO)
if(_oz(z,1,e,s,gg)){oDO.wxVkey=1
var cFO=_mz(z,'view',['class',2,'style',1],[],e,s,gg)
var hGO=_v()
_(cFO,hGO)
if(_oz(z,4,e,s,gg)){hGO.wxVkey=1
}
var oHO=_n('view')
_rz(z,oHO,'class',5,e,s,gg)
var cIO=_v()
_(oHO,cIO)
if(_oz(z,6,e,s,gg)){cIO.wxVkey=1
}
var oJO=_v()
_(oHO,oJO)
if(_oz(z,7,e,s,gg)){oJO.wxVkey=1
}
var lKO=_v()
_(oHO,lKO)
if(_oz(z,8,e,s,gg)){lKO.wxVkey=1
}
var aLO=_v()
_(oHO,aLO)
if(_oz(z,9,e,s,gg)){aLO.wxVkey=1
}
var tMO=_v()
_(oHO,tMO)
if(_oz(z,10,e,s,gg)){tMO.wxVkey=1
}
var eNO=_v()
_(oHO,eNO)
if(_oz(z,11,e,s,gg)){eNO.wxVkey=1
}
cIO.wxXCkey=1
oJO.wxXCkey=1
lKO.wxXCkey=1
aLO.wxXCkey=1
tMO.wxXCkey=1
eNO.wxXCkey=1
_(cFO,oHO)
var bOO=_n('view')
_rz(z,bOO,'class',12,e,s,gg)
var oPO=_v()
_(bOO,oPO)
if(_oz(z,13,e,s,gg)){oPO.wxVkey=1
}
else{oPO.wxVkey=2
var xQO=_v()
_(oPO,xQO)
if(_oz(z,14,e,s,gg)){xQO.wxVkey=1
}
xQO.wxXCkey=1
}
oPO.wxXCkey=1
_(cFO,bOO)
hGO.wxXCkey=1
_(oDO,cFO)
}
var fEO=_v()
_(xCO,fEO)
if(_oz(z,15,e,s,gg)){fEO.wxVkey=1
}
oDO.wxXCkey=1
fEO.wxXCkey=1
_(r,xCO)
var oRO=_v()
_(r,oRO)
var fSO=function(hUO,cTO,oVO,gg){
var oXO=_v()
_(oVO,oXO)
if(_oz(z,18,hUO,cTO,gg)){oXO.wxVkey=1
var lYO=_mz(z,'button',['bindtap',19,'class',1,'data-phone',2],[],hUO,cTO,gg)
var aZO=_v()
_(lYO,aZO)
if(_oz(z,22,hUO,cTO,gg)){aZO.wxVkey=1
}
aZO.wxXCkey=1
_(oXO,lYO)
}
oXO.wxXCkey=1
return oVO
}
oRO.wxXCkey=2
_2z(z,16,fSO,e,s,gg,oRO,'item','index','item')
var t1O=_n('my-privacy')
_rz(z,t1O,'id',23,e,s,gg)
_(r,t1O)
return r
}
e_[x[0]]={f:m0,j:[],i:[],ti:[],ic:[]}
if(path&&e_[path]){
return function(env,dd,global){$gwxc=0;var root={"tag":"wx-page"};root.children=[]
;g="$gwx_XC_34";var main=e_[path].f
if (typeof global==="undefined")global={};global.f=$gdc(f_[path],"",1);
try{
main(env,{},root,global);
_tsd(root)
}catch(err){
console.log(err)
}
;g="";
return root;
}
}
}
}(__g.a,__g.b,__g.c,__g.d,__g.e,__g.f,__g.g,__g.h,__g.i,__g.j,__g.k,__g.l,__g.m,__g.n,__g.o,__g.p,__g.q,__g.r,__g.s,__g.t,__g.u,__g.v,__g.w,__g.x,__g.y,__g.z,__g.A,__g.B,__g.C,__g.D,__g.E,__g.F,__g.G,__g.H,__g.I,__g.J,__g.K,__g.L,__g.M,__g.N,__g.O,__g.P,__g.Q,__g.R,__g.S,__g.T,__g.U,__g.V,__g.W,__g.X,__g.Y,__g.Z,__g.aa);if(__vd_version_info__.delayedGwx||false)$gwx_XC_34();	if (__vd_version_info__.delayedGwx) __wxAppCode__['sc/c.wxml'] = [$gwx_XC_34, './sc/c.wxml'];else __wxAppCode__['sc/c.wxml'] = $gwx_XC_34( './sc/c.wxml' );
	;__wxRoute = "sc/c";__wxRouteBegin = true;__wxAppCurrentFile__="sc/c.js";define("sc/c.js",function(require,module,exports,window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){
"use strict";wx.cloud.init();wx.cloud.database({env:"zhijiebohao-4gp9aizse6797bd3"}).command;var e=[1047,1048,1049];Page({data:{show:!1,showPhone:!1,rest:!1,safeUser:{},showAd:!1,scPhones:void 0},toMsg:function(){wx.openEmbeddedMiniProgram({path:"/pages/msg/list/list?id="+this.data.safeUser.msg,appId:"wx4faaf21bf014cd33"})},toSafe:function(){wx.navigateTo({url:"/pages/safeIndex/safeIndex"})},checkDueDate:function(e){return new Date<=new Date(e)},call:function(e){e.detail?this.data.showPhone&&wx.makePhoneCall({phoneNumber:this.data.safeUser.phone}):wx.makePhoneCall({phoneNumber:e})},userKnow:function(){wx.navigateTo({url:"/pages/methodD/methodD?id=17453ede60725a19013d9b13631c047p"})},chooseScPhonesItem:function(e){var o=e.currentTarget.dataset.phone;if(o){if(this.unChooseScPhones(),o==this.data.safeUser.phone)return void wx.showToast({title:"不能与自己建立隐私通话！",icon:"none",duration:3e3});this.afterGetPhoneNumber(o)}},unChooseScPhones:function(){this.setData({chooseScPhonesShow:!1})},chooseScPhones:function(){this.setData({chooseScPhonesShow:!0})},getPhoneNumber:function(e){wx.hideLoading();var o=this;e.detail.cloudID&&(wx.showLoading({title:"获取中",mask:!0}),wx.cloud.callFunction({name:"login",data:{weRunData:wx.cloud.CloudID(e.detail.cloudID),code:!!e.detail.code&&e.detail.code}}).then((function(n){wx.hideLoading();var t=e.detail.code?n.result.phoneInfo.phoneNumber:n.result.event.weRunData.data.phoneNumber,a=o.data.scPhones;if(a){var s=a.indexOf(t);s>-1&&a.splice(s,1),a.unshift(t)}else a=[t];o.setData({scPhones:a}),o.afterGetPhoneNumber(t)})))},afterGetPhoneNumber:function(e){var o=this,n=wx.getStorageSync("bindInfo");if(n){var t=JSON.parse(n);if(t.PhoneNoA!=e||t.safeUserId!=o.data.safeUser._id)return wx.removeStorageSync("bindInfo"),void o.goBindAxBUrl(e);t.SubsId?(wx.showLoading({title:"检查通话状态",mask:!0}),wx.cloud.callFunction({name:"baiduapi",data:{method:"status",PhoneNoA:e,SubsId:t.SubsId,PhoneNoX:t.SecretNo},success:function(n){if(wx.hideLoading(),"LACK"!=n.result.Code){if("BLACK"==n.result.Code)return wx.showToast({title:"对方已将你拉黑，暂时无法联系！",icon:"none",duration:3e3}),void wx.removeStorageSync("bindInfo");if("OK"==n.result.Code){var a=n.result.SecretCallStatusDTO.Status,s=n.result.SecretCallStatusDTO.CalledNo;1==a?o.call(t.SecretNo):2==a?o.call(s):(wx.removeStorageSync("bindInfo"),o.goBindAxBUrl(e))}}else wx.showToast({title:"码上信息不完整，无法构建隐私通话！",icon:"none",duration:3e3})},fail:function(n){wx.hideLoading(),o.goBindAxBUrl(e)}})):(wx.removeStorageSync("bindInfo"),o.goBindAxBUrl(e))}else o.goBindAxBUrl(e)},goBindAxBUrl:function(e){var o=this;wx.showLoading({title:"建立私密连接",mask:!0}),wx.cloud.callFunction({name:"baiduapi",data:{method:"bindAxB",PhoneNoA:e,safeUserId:o.data.safeUser._id},success:function(n){if(wx.hideLoading(),"SAME"!=n.result.Code)if("LACK"!=n.result.Code)if("OK"==n.result.Code){var t=n.result.SecretBindDTO.SubsId,a=n.result.SecretBindDTO.SecretNo;wx.setStorage({key:"bindInfo",data:JSON.stringify({SubsId:t,SecretNo:a,PhoneNoA:e,safeUserId:o.data.safeUser._id})}),o.call(a)}else"REST"==n.result.Code?wx.showToast({title:"对方已开启勿扰模式，无法电话联系！",icon:"none",duration:3e3}):"BLACK"==n.result.Code?wx.showToast({title:"对方已将你拉黑，暂时无法联系！",icon:"none",duration:3e3}):wx.showToast({title:"对方电话繁忙，请5分钟后重试！",icon:"none",duration:3e3});else wx.showToast({title:"码上信息不完整，无法构建隐私通话！",icon:"none",duration:3e3});else wx.showToast({title:"不能与自己建立隐私通话！",icon:"none",duration:3e3})},fail:function(e){wx.showToast({title:"网络异常或通讯异常！",icon:"none"})}})},onLoad:function(e){var o=e.scene;if(isNaN(o))wx.reLaunch({url:"/pages/work/method"});else{var n=this;wx.cloud.callFunction({name:"login"}).then((function(e){e.result.scPhones&&n.setData({scPhones:e.result.scPhones})})),wx.cloud.callFunction({name:"getUserInfo",data:{inc_id:parseInt(o)}}).then((function(e){var o=e.result;o.yours?wx.showModal({title:"提示",content:"此码是空白码，您已有其他专属码，如需换绑到此码，请前往管理页面底部点击“换绑”。",success:function(e){e.confirm?wx.reLaunch({url:"/pages/safeIndex/safeIndex"}):e.cancel&&wx.exitMiniProgram()}}):o.unbind?wx.showModal({title:"提示",content:"您已成功绑定该拨号码，请前往管理页面设置专属信息。",confirmText:"确定",showCancel:!1,success:function(e){wx.reLaunch({url:"/pages/safeIndex/safeIndex"})}}):o.phone?(n.setData({safeUser:o,show:!0,showAd:o.showAd}),o.safe&&o.safe_due_date&&n.checkDueDate(o.safe_due_date)?n.setData({showPhone:!1}):n.setData({showPhone:!0})):wx.showModal({title:"提示",content:"该拨号码用户尚未设置电话。",confirmText:"退出",showCancel:!1,success:function(e){wx.exitMiniProgram()}})}))}},onShow:function(){if(1==getCurrentPages().length){var o=wx.getEnterOptionsSync();-1==e.indexOf(o.scene)&&wx.showModal({title:"来源错误",content:"您好，本页面只支持通过小程序码访问。",showCancel:!1,confirmText:"退出",success:function(e){wx.exitMiniProgram()}})}}});
},{isPage:true,isComponent:true,currentFile:'sc/c.js'});require("sc/c.js");