var e = require("@babel/runtime/helpers/typeof.js");

!function(n, t) {
    "object" == ("undefined" == typeof exports ? "undefined" : e(exports)) && "undefined" != typeof module ? module.exports = t() : "function" == typeof define && define.amd ? define(t) : (n = n || self).uni = t();
}(void 0, function() {
    try {
        var e = {};
        Object.defineProperty(e, "passive", {
            get: function() {}
        }), window.addEventListener("test-passive", null, e);
    } catch (e) {}
    var n = Object.prototype.hasOwnProperty;
    function t(e, t) {
        return n.call(e, t);
    }
    for (var i, o = [], a = function(e, n) {
        var t = {
            options: {
                timestamp: +new Date()
            },
            name: e,
            arg: n
        };
        if (window.__dcloud_weex_postMessage || window.__dcloud_weex_) {
            if ("postMessage" === e) {
                var i = {
                    data: [ n ]
                };
                return window.__dcloud_weex_postMessage ? window.__dcloud_weex_postMessage(i) : window.__dcloud_weex_.postMessage(JSON.stringify(i));
            }
            var a = {
                type: "WEB_INVOKE_APPSERVICE",
                args: {
                    data: t,
                    webviewIds: o
                }
            };
            window.__dcloud_weex_postMessage ? window.__dcloud_weex_postMessageToService(a) : window.__dcloud_weex_.postMessageToService(JSON.stringify(a));
        }
        if (!window.plus) return window.parent.postMessage({
            type: "WEB_INVOKE_APPSERVICE",
            data: t,
            pageId: ""
        }, "*");
        if (0 === o.length) {
            var r = plus.webview.currentWebview();
            if (!r) throw new Error("plus.webview.currentWebview() is undefined");
            var d, s = r.parent();
            d = s ? s.id : r.id, o.push(d);
        }
        if (plus.webview.getWebviewById("__uniapp__service")) plus.webview.postMessageToUniNView({
            type: "WEB_INVOKE_APPSERVICE",
            args: {
                data: t,
                webviewIds: o
            }
        }, "__uniapp__service"); else {
            var w = JSON.stringify(t);
            plus.webview.getLaunchWebview().evalJS('UniPlusBridge.subscribeHandler("'.concat("WEB_INVOKE_APPSERVICE", '",').concat(w, ",").concat(JSON.stringify(o), ");"));
        }
    }, r = {
        navigateTo: function() {
            var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {}, n = e.url;
            a("navigateTo", {
                url: encodeURI(n)
            });
        },
        navigateBack: function() {
            var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {}, n = e.delta;
            a("navigateBack", {
                delta: parseInt(n) || 1
            });
        },
        switchTab: function() {
            var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {}, n = e.url;
            a("switchTab", {
                url: encodeURI(n)
            });
        },
        reLaunch: function() {
            var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {}, n = e.url;
            a("reLaunch", {
                url: encodeURI(n)
            });
        },
        redirectTo: function() {
            var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {}, n = e.url;
            a("redirectTo", {
                url: encodeURI(n)
            });
        },
        getEnv: function(e) {
            window.plus ? e({
                plus: !0
            }) : e({
                h5: !0
            });
        },
        postMessage: function() {
            var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {};
            a("postMessage", e.data || {});
        }
    }, d = /uni-app/i.test(navigator.userAgent), s = /Html5Plus/i.test(navigator.userAgent), w = /complete|loaded|interactive/, u = window.my && navigator.userAgent.indexOf("AlipayClient") > -1, c = window.swan && window.swan.webView && /swan/i.test(navigator.userAgent), g = window.qq && window.qq.miniProgram && /QQ/i.test(navigator.userAgent) && /miniProgram/i.test(navigator.userAgent), v = window.tt && window.tt.miniProgram && /toutiaomicroapp/i.test(navigator.userAgent), p = window.wx && window.wx.miniProgram && /micromessenger/i.test(navigator.userAgent) && /miniProgram/i.test(navigator.userAgent), l = window.qa && /quickapp/i.test(navigator.userAgent), f = function() {
        window.UniAppJSBridge = !0, document.dispatchEvent(new CustomEvent("UniAppJSBridgeReady", {
            bubbles: !0,
            cancelable: !0
        }));
    }, _ = [ function(e) {
        if (d || s) return window.__dcloud_weex_postMessage || window.__dcloud_weex_ ? document.addEventListener("DOMContentLoaded", e) : window.plus && w.test(document.readyState) ? setTimeout(e, 0) : document.addEventListener("plusready", e), 
        r;
    }, function(e) {
        if (p) return window.WeixinJSBridge && window.WeixinJSBridge.invoke ? setTimeout(e, 0) : document.addEventListener("WeixinJSBridgeReady", e), 
        window.wx.miniProgram;
    }, function(e) {
        if (g) return window.QQJSBridge && window.QQJSBridge.invoke ? setTimeout(e, 0) : document.addEventListener("QQJSBridgeReady", e), 
        window.qq.miniProgram;
    }, function(e) {
        if (u) {
            document.addEventListener("DOMContentLoaded", e);
            var n = window.my;
            return {
                navigateTo: n.navigateTo,
                navigateBack: n.navigateBack,
                switchTab: n.switchTab,
                reLaunch: n.reLaunch,
                redirectTo: n.redirectTo,
                postMessage: n.postMessage,
                getEnv: n.getEnv
            };
        }
    }, function(e) {
        if (c) return document.addEventListener("DOMContentLoaded", e), window.swan.webView;
    }, function(e) {
        if (v) return document.addEventListener("DOMContentLoaded", e), window.tt.miniProgram;
    }, function(e) {
        if (l) {
            window.QaJSBridge && window.QaJSBridge.invoke ? setTimeout(e, 0) : document.addEventListener("QaJSBridgeReady", e);
            var n = window.qa;
            return {
                navigateTo: n.navigateTo,
                navigateBack: n.navigateBack,
                switchTab: n.switchTab,
                reLaunch: n.reLaunch,
                redirectTo: n.redirectTo,
                postMessage: n.postMessage,
                getEnv: n.getEnv
            };
        }
    }, function(e) {
        return document.addEventListener("DOMContentLoaded", e), r;
    } ], m = 0; m < _.length && !(i = _[m](f)); m++) ;
    i || (i = {});
    var E = "undefined" != typeof uni ? uni : {};
    if (!E.navigateTo) for (var b in i) t(i, b) && (E[b] = i[b]);
    return E.webView = i, E;
});