(global.webpackChunktest_uni = global.webpackChunktest_uni || []).push([ [ "common/main" ], {
    "./src/App.vue": 
    /*!*********************!*\
    !*** ./src/App.vue ***!
    \*********************/
    function(e, o, u) {
        u.r(o);
        var n = u(/*! ./App.vue?vue&type=script&lang=js& */ "./src/App.vue?vue&type=script&lang=js&"), l = (0, 
        u(/*! !../node_modules/@dcloudio/vue-cli-plugin-uni/packages/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/@dcloudio/vue-cli-plugin-uni/packages/vue-loader/lib/runtime/componentNormalizer.js").default)(n.default, void 0, void 0, !1, null, null, null, !1, void 0, void 0);
        l.options.__file = "App.vue", o.default = l.exports;
    },
    "./src/App.vue?vue&type=script&lang=js&": 
    /*!**********************************************!*\
    !*** ./src/App.vue?vue&type=script&lang=js& ***!
    \**********************************************/
    function(e, o, u) {
        u.r(o);
        var n = u(/*! -!../node_modules/babel-loader/lib/index.js??clonedRuleSet-40[0].rules[0].use[0]!../node_modules/@dcloudio/vue-cli-plugin-uni/packages/webpack-preprocess-loader/index.js??clonedRuleSet-40[0].rules[0].use[1]!../node_modules/@dcloudio/webpack-uni-mp-loader/lib/script.js!../node_modules/@dcloudio/vue-cli-plugin-uni/packages/vue-loader/lib/index.js??vue-loader-options!../node_modules/@dcloudio/webpack-uni-mp-loader/lib/style.js!./App.vue?vue&type=script&lang=js& */ "./node_modules/babel-loader/lib/index.js??clonedRuleSet-40[0].rules[0].use[0]!./node_modules/@dcloudio/vue-cli-plugin-uni/packages/webpack-preprocess-loader/index.js??clonedRuleSet-40[0].rules[0].use[1]!./node_modules/@dcloudio/webpack-uni-mp-loader/lib/script.js!./node_modules/@dcloudio/vue-cli-plugin-uni/packages/vue-loader/lib/index.js??vue-loader-options!./node_modules/@dcloudio/webpack-uni-mp-loader/lib/style.js!./src/App.vue?vue&type=script&lang=js&");
        o.default = n.default;
    },
    "./src/main.js": 
    /*!*********************!*\
    !*** ./src/main.js ***!
    \*********************/
    function(e, o, u) {
        u.r(o);
        var n = u(/*! @babel/runtime/helpers/defineProperty */ "./node_modules/@babel/runtime/helpers/esm/defineProperty.js"), l = (u(/*! uni-pages */ "./src/pages.json"), 
        u(/*! ./App */ "./src/App.vue")), i = u(/*! vue */ "./node_modules/@dcloudio/vue-cli-plugin-uni/packages/mp-vue/dist/mp.runtime.esm.js"), r = (u(/*! ./uni.promisify.adaptor */ "./src/uni.promisify.adaptor.js"), 
        u(/*! ./router/router.js */ "./src/router/router.js")), s = u(/*! ./node_modules/@dcloudio/uni-mp-weixin/dist/wx.js */ "./node_modules/@dcloudio/uni-mp-weixin/dist/wx.js").default, d = u(/*! ./node_modules/@dcloudio/uni-mp-weixin/dist/index.js */ "./node_modules/@dcloudio/uni-mp-weixin/dist/index.js").createApp;
        function t(e, o) {
            var u = Object.keys(e);
            if (Object.getOwnPropertySymbols) {
                var n = Object.getOwnPropertySymbols(e);
                o && (n = n.filter(function(o) {
                    return Object.getOwnPropertyDescriptor(e, o).enumerable;
                })), u.push.apply(u, n);
            }
            return u;
        }
        s.__webpack_require_UNI_MP_PLUGIN__ = u, i.default.config.productionTip = !1, i.default.use(r.router), 
        l.default.mpType = "app", d(new i.default(function(e) {
            for (var o = 1; o < arguments.length; o++) {
                var u = null != arguments[o] ? arguments[o] : {};
                o % 2 ? t(Object(u), !0).forEach(function(o) {
                    (0, n.default)(e, o, u[o]);
                }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(u)) : t(Object(u)).forEach(function(o) {
                    Object.defineProperty(e, o, Object.getOwnPropertyDescriptor(u, o));
                });
            }
            return e;
        }({}, l.default))).$mount();
    },
    "./node_modules/babel-loader/lib/index.js??clonedRuleSet-40[0].rules[0].use[0]!./node_modules/@dcloudio/vue-cli-plugin-uni/packages/webpack-preprocess-loader/index.js??clonedRuleSet-40[0].rules[0].use[1]!./node_modules/@dcloudio/webpack-uni-mp-loader/lib/script.js!./node_modules/@dcloudio/vue-cli-plugin-uni/packages/vue-loader/lib/index.js??vue-loader-options!./node_modules/@dcloudio/webpack-uni-mp-loader/lib/style.js!./src/App.vue?vue&type=script&lang=js&": 
    /*!***********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
    !*** ./node_modules/babel-loader/lib/index.js??clonedRuleSet-40[0].rules[0].use[0]!./node_modules/@dcloudio/vue-cli-plugin-uni/packages/webpack-preprocess-loader/index.js??clonedRuleSet-40[0].rules[0].use[1]!./node_modules/@dcloudio/webpack-uni-mp-loader/lib/script.js!./node_modules/@dcloudio/vue-cli-plugin-uni/packages/vue-loader/lib/index.js??vue-loader-options!./node_modules/@dcloudio/webpack-uni-mp-loader/lib/style.js!./src/App.vue?vue&type=script&lang=js& ***!
    \***********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
    function(e, o, u) {
        u.r(o), o.default = {
            onLaunch: function() {
                console.log("App Launch");
            },
            onShow: function() {
                console.log("App Show");
            },
            onHide: function() {
                console.log("App Hide");
            }
        };
    }
}, function(e) {
    e.O(0, [ "common/vendor" ], function() {
        return o = "./src/main.js", e(e.s = o);
        var o;
    });
    e.O();
} ]);