(global.webpackChunktest_uni = global.webpackChunktest_uni || []).push([ [ "pages/mine/mine" ], {
    "./src/pages/mine/mine.vue": 
    /*!*********************************!*\
    !*** ./src/pages/mine/mine.vue ***!
    \*********************************/
    function(e, n, t) {
        t.r(n);
        var o = t(/*! ./mine.vue?vue&type=template&id=dcbcfe34& */ "./src/pages/mine/mine.vue?vue&type=template&id=dcbcfe34&"), a = t(/*! ./mine.vue?vue&type=script&lang=js& */ "./src/pages/mine/mine.vue?vue&type=script&lang=js&"), i = (t(/*! ./mine.vue?vue&type=style&index=0&lang=css& */ "./src/pages/mine/mine.vue?vue&type=style&index=0&lang=css&"), 
        (0, t(/*! !../../../node_modules/@dcloudio/vue-cli-plugin-uni/packages/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/@dcloudio/vue-cli-plugin-uni/packages/vue-loader/lib/runtime/componentNormalizer.js").default)(a.default, o.render, o.staticRenderFns, !1, null, null, null, !1, o.components, void 0));
        i.options.__file = "pages/mine/mine.vue", n.default = i.exports;
    },
    "./src/pages/mine/mine.vue?vue&type=template&id=dcbcfe34&": 
    /*!****************************************************************!*\
    !*** ./src/pages/mine/mine.vue?vue&type=template&id=dcbcfe34& ***!
    \****************************************************************/
    function(e, n, t) {
        t.r(n), t.d(n, {
            components: function() {
                return o.components;
            },
            recyclableRender: function() {
                return o.recyclableRender;
            },
            render: function() {
                return o.render;
            },
            staticRenderFns: function() {
                return o.staticRenderFns;
            }
        });
        var o = t(/*! -!../../../node_modules/@dcloudio/vue-cli-plugin-uni/packages/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!../../../node_modules/@dcloudio/vue-cli-plugin-uni/packages/webpack-preprocess-loader/index.js??clonedRuleSet-42[0].rules[0].use[0]!../../../node_modules/@dcloudio/webpack-uni-mp-loader/lib/template.js!../../../node_modules/@dcloudio/vue-cli-plugin-uni/packages/webpack-uni-app-loader/page-meta.js!../../../node_modules/@dcloudio/vue-cli-plugin-uni/packages/vue-loader/lib/index.js??vue-loader-options!../../../node_modules/@dcloudio/webpack-uni-mp-loader/lib/style.js!./mine.vue?vue&type=template&id=dcbcfe34& */ "./node_modules/@dcloudio/vue-cli-plugin-uni/packages/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/@dcloudio/vue-cli-plugin-uni/packages/webpack-preprocess-loader/index.js??clonedRuleSet-42[0].rules[0].use[0]!./node_modules/@dcloudio/webpack-uni-mp-loader/lib/template.js!./node_modules/@dcloudio/vue-cli-plugin-uni/packages/webpack-uni-app-loader/page-meta.js!./node_modules/@dcloudio/vue-cli-plugin-uni/packages/vue-loader/lib/index.js??vue-loader-options!./node_modules/@dcloudio/webpack-uni-mp-loader/lib/style.js!./src/pages/mine/mine.vue?vue&type=template&id=dcbcfe34&");
    },
    "./src/pages/mine/mine.vue?vue&type=script&lang=js&": 
    /*!**********************************************************!*\
    !*** ./src/pages/mine/mine.vue?vue&type=script&lang=js& ***!
    \**********************************************************/
    function(e, n, t) {
        t.r(n);
        var o = t(/*! -!../../../node_modules/babel-loader/lib/index.js??clonedRuleSet-40[0].rules[0].use[0]!../../../node_modules/@dcloudio/vue-cli-plugin-uni/packages/webpack-preprocess-loader/index.js??clonedRuleSet-40[0].rules[0].use[1]!../../../node_modules/@dcloudio/webpack-uni-mp-loader/lib/script.js!../../../node_modules/@dcloudio/vue-cli-plugin-uni/packages/vue-loader/lib/index.js??vue-loader-options!../../../node_modules/@dcloudio/webpack-uni-mp-loader/lib/style.js!./mine.vue?vue&type=script&lang=js& */ "./node_modules/babel-loader/lib/index.js??clonedRuleSet-40[0].rules[0].use[0]!./node_modules/@dcloudio/vue-cli-plugin-uni/packages/webpack-preprocess-loader/index.js??clonedRuleSet-40[0].rules[0].use[1]!./node_modules/@dcloudio/webpack-uni-mp-loader/lib/script.js!./node_modules/@dcloudio/vue-cli-plugin-uni/packages/vue-loader/lib/index.js??vue-loader-options!./node_modules/@dcloudio/webpack-uni-mp-loader/lib/style.js!./src/pages/mine/mine.vue?vue&type=script&lang=js&");
        n.default = o.default;
    },
    "./src/pages/mine/mine.vue?vue&type=style&index=0&lang=css&": 
    /*!******************************************************************!*\
    !*** ./src/pages/mine/mine.vue?vue&type=style&index=0&lang=css& ***!
    \******************************************************************/
    function(e, n, t) {
        t.r(n);
        var o = t(/*! -!../../../node_modules/mini-css-extract-plugin/dist/loader.js??clonedRuleSet-12[0].rules[0].use[0]!../../../node_modules/@vue/cli-service/node_modules/css-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[1]!../../../node_modules/@dcloudio/vue-cli-plugin-uni/packages/vue-loader/lib/loaders/stylePostLoader.js!../../../node_modules/@dcloudio/vue-cli-plugin-uni/packages/webpack-preprocess-loader/index.js??clonedRuleSet-12[0].rules[0].use[2]!../../../node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[3]!../../../node_modules/@dcloudio/vue-cli-plugin-uni/packages/vue-loader/lib/index.js??vue-loader-options!../../../node_modules/@dcloudio/webpack-uni-mp-loader/lib/style.js!./mine.vue?vue&type=style&index=0&lang=css& */ "./node_modules/mini-css-extract-plugin/dist/loader.js??clonedRuleSet-12[0].rules[0].use[0]!./node_modules/@vue/cli-service/node_modules/css-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[1]!./node_modules/@dcloudio/vue-cli-plugin-uni/packages/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/@dcloudio/vue-cli-plugin-uni/packages/webpack-preprocess-loader/index.js??clonedRuleSet-12[0].rules[0].use[2]!./node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[3]!./node_modules/@dcloudio/vue-cli-plugin-uni/packages/vue-loader/lib/index.js??vue-loader-options!./node_modules/@dcloudio/webpack-uni-mp-loader/lib/style.js!./src/pages/mine/mine.vue?vue&type=style&index=0&lang=css&"), a = t.n(o), i = {};
        for (var s in o) "default" !== s && (i[s] = function(e) {
            return o[e];
        }.bind(0, s));
        t.d(n, i), n.default = a();
    },
    "./node_modules/@dcloudio/vue-cli-plugin-uni/packages/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/@dcloudio/vue-cli-plugin-uni/packages/webpack-preprocess-loader/index.js??clonedRuleSet-42[0].rules[0].use[0]!./node_modules/@dcloudio/webpack-uni-mp-loader/lib/template.js!./node_modules/@dcloudio/vue-cli-plugin-uni/packages/webpack-uni-app-loader/page-meta.js!./node_modules/@dcloudio/vue-cli-plugin-uni/packages/vue-loader/lib/index.js??vue-loader-options!./node_modules/@dcloudio/webpack-uni-mp-loader/lib/style.js!./src/pages/mine/mine.vue?vue&type=template&id=dcbcfe34&": 
    /*!************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
    !*** ./node_modules/@dcloudio/vue-cli-plugin-uni/packages/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/@dcloudio/vue-cli-plugin-uni/packages/webpack-preprocess-loader/index.js??clonedRuleSet-42[0].rules[0].use[0]!./node_modules/@dcloudio/webpack-uni-mp-loader/lib/template.js!./node_modules/@dcloudio/vue-cli-plugin-uni/packages/webpack-uni-app-loader/page-meta.js!./node_modules/@dcloudio/vue-cli-plugin-uni/packages/vue-loader/lib/index.js??vue-loader-options!./node_modules/@dcloudio/webpack-uni-mp-loader/lib/style.js!./src/pages/mine/mine.vue?vue&type=template&id=dcbcfe34& ***!
    \************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
    function(e, n, t) {
        var o;
        t.r(n), t.d(n, {
            components: function() {
                return o;
            },
            recyclableRender: function() {
                return i;
            },
            render: function() {
                return a;
            },
            staticRenderFns: function() {
                return s;
            }
        });
        try {
            o = {
                zwyPopup: function() {
                    return t.e(/*! import() | uni_modules/zwy-popup/components/zwy-popup/zwy-popup */ "uni_modules/zwy-popup/components/zwy-popup/zwy-popup").then(t.bind(t, /*! @/uni_modules/zwy-popup/components/zwy-popup/zwy-popup.vue */ "./src/uni_modules/zwy-popup/components/zwy-popup/zwy-popup.vue"));
                }
            };
        } catch (e) {
            if (-1 === e.message.indexOf("Cannot find module") || -1 === e.message.indexOf(".vue")) throw e;
            console.error(e.message), console.error("1. 排查组件名称拼写是否正确"), console.error("2. 排查组件是否符合 easycom 规范，文档：https://uniapp.dcloud.net.cn/collocation/pages?id=easycom"), 
            console.error("3. 若组件不符合 easycom 规范，需手动引入，并在 components 中注册该组件");
        }
        var a = function() {
            var e = this, n = e.$createElement, t = (e._self._c, e.__map(e.records, function(n, t) {
                return {
                    $orig: e.__get_orig(n),
                    m0: e.joinDescriptions(n)
                };
            }));
            e._isMounted || (e.e0 = function(n) {
                e.isshow = !1;
            }, e.e1 = function(n) {
                e.isshow = !1;
            }), e.$mp.data = Object.assign({}, {
                $root: {
                    a0: {},
                    l0: t
                }
            });
        }, i = !1, s = [];
        a._withStripped = !0;
    },
    './src/main.js?{"page":"pages%2Fmine%2Fmine"}': 
    /*!****************************************************!*\
    !*** ./src/main.js?{"page":"pages%2Fmine%2Fmine"} ***!
    \****************************************************/
    function(e, n, t) {
        t.r(n);
        t(/*! uni-pages */ "./src/pages.json"), t(/*! vue */ "./node_modules/@dcloudio/vue-cli-plugin-uni/packages/mp-vue/dist/mp.runtime.esm.js");
        var o = t(/*! ./pages/mine/mine.vue */ "./src/pages/mine/mine.vue"), a = t(/*! ./node_modules/@dcloudio/uni-mp-weixin/dist/wx.js */ "./node_modules/@dcloudio/uni-mp-weixin/dist/wx.js").default, i = t(/*! ./node_modules/@dcloudio/uni-mp-weixin/dist/index.js */ "./node_modules/@dcloudio/uni-mp-weixin/dist/index.js").createPage;
        a.__webpack_require_UNI_MP_PLUGIN__ = t, i(o.default);
    },
    "./node_modules/babel-loader/lib/index.js??clonedRuleSet-40[0].rules[0].use[0]!./node_modules/@dcloudio/vue-cli-plugin-uni/packages/webpack-preprocess-loader/index.js??clonedRuleSet-40[0].rules[0].use[1]!./node_modules/@dcloudio/webpack-uni-mp-loader/lib/script.js!./node_modules/@dcloudio/vue-cli-plugin-uni/packages/vue-loader/lib/index.js??vue-loader-options!./node_modules/@dcloudio/webpack-uni-mp-loader/lib/style.js!./src/pages/mine/mine.vue?vue&type=script&lang=js&": 
    /*!***********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
    !*** ./node_modules/babel-loader/lib/index.js??clonedRuleSet-40[0].rules[0].use[0]!./node_modules/@dcloudio/vue-cli-plugin-uni/packages/webpack-preprocess-loader/index.js??clonedRuleSet-40[0].rules[0].use[1]!./node_modules/@dcloudio/webpack-uni-mp-loader/lib/script.js!./node_modules/@dcloudio/vue-cli-plugin-uni/packages/vue-loader/lib/index.js??vue-loader-options!./node_modules/@dcloudio/webpack-uni-mp-loader/lib/style.js!./src/pages/mine/mine.vue?vue&type=script&lang=js& ***!
    \***********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
    function(e, n, t) {
        t.r(n);
        var o = t(/*! @babel/runtime/helpers/asyncToGenerator */ "./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js"), a = t(/*! @babel/runtime/regenerator */ "./node_modules/@dcloudio/vue-cli-plugin-uni/packages/@babel/runtime/regenerator/index.js"), i = t.n(a), s = t(/*! ../../custom/config.js */ "./src/custom/config.js"), r = t(/*! ./node_modules/@dcloudio/uni-mp-weixin/dist/wx.js */ "./node_modules/@dcloudio/uni-mp-weixin/dist/wx.js").default, u = t(/*! ./node_modules/@dcloudio/uni-mp-weixin/dist/index.js */ "./node_modules/@dcloudio/uni-mp-weixin/dist/index.js").default;
        n.default = {
            components: {
                zsyCalendarV2: function() {
                    t.e(/*! require.ensure | components/zsy-calendar-v2/zsy-calendar-v2 */ "components/zsy-calendar-v2/zsy-calendar-v2").then(function() {
                        return resolve(t(/*! ../../components/zsy-calendar-v2/zsy-calendar-v2.vue */ "./src/components/zsy-calendar-v2/zsy-calendar-v2.vue"));
                    }.bind(null, t)).catch(t.oe);
                }
            },
            data: function() {
                return {
                    records: [],
                    currentPage: 0,
                    isshow: !1,
                    pageSize: 10,
                    totalPages: 999,
                    canIUse: r.canIUse("button.open-type.getUserInfo"),
                    signature: "",
                    avatarUrl: null,
                    phoneNumber: null,
                    nickname: "",
                    email: "",
                    tokens: 0,
                    code: "",
                    apiAddr: s.default.apiAddr,
                    libraryType: "",
                    statistics: [ {
                        name: "小学",
                        value: "计算中...",
                        zh2en: "计算中...",
                        en2audio: "计算中...",
                        zh2audio: "计算中...",
                        audio2en: "计算中...",
                        audio2zh: "计算中..."
                    } ],
                    libraryOptions: [],
                    selectedOption: null,
                    isModalVisible: !1,
                    fau: null,
                    stayMinePage: !1,
                    leftTime: 60,
                    leftTimeForWordStatus: 60,
                    leftTimeForDailyInfo: 60,
                    shareStories: !1,
                    storyTypeName: "中文",
                    audioTypeName: "美音",
                    currentYear: 0,
                    currentMonth: 0,
                    dailyMemories: {},
                    dailyMemoriesV2: {}
                };
            },
            onLoad: function() {
                this.initParams(), this.initUpdater(this.fetchWordsStatus, "fwsu", "leftTimeForWordStatus"), 
                this.initUpdater(this.fetchDailyMemories, "fdiu", "leftTimeForDailyInfo"), this.initUpdater(this.fetchAuth, "fau", "leftTime");
            },
            onShow: function() {
                this.stayMinePage = !0, this.fetchUserData();
            },
            onHide: function() {
                this.stayMinePage = !1, this.isshow = !1;
            },
            methods: {
                joinDescriptions: function(e) {
                    var n = [];
                    if (e.descV2 && e.descV2.length > 0) n = n.concat(e.descV2.map(function(e) {
                        return e.desc;
                    })); else if (e.descV1 && e.descV1.length > 0) n = n.concat(e.descV1); else if (0 === n.length) return e.desc;
                    return n.join("; ");
                },
                fetchRecords: function(e, n) {
                    if (!(e < 1)) {
                        this.currentPage = e;
                        var t = this;
                        r.request({
                            url: "".concat(t.apiAddr, "/user/records2"),
                            method: "POST",
                            header: {
                                Authorization: "Bearer ".concat(t.commonValidToken),
                                "content-type": "application/json"
                            },
                            data: {
                                userid: t.userId,
                                date: this.leastDate,
                                page: t.currentPage,
                                pageSize: t.pageSize
                            },
                            success: function(e) {
                                t.records = e.data.records.sort(function(e, n) {
                                    return e.count - n.count;
                                }), t.totalPages = Math.ceil(e.data.total / t.pageSize), t.totalPages <= 0 && (t.currentPage = 0), 
                                n && n();
                            },
                            fail: function(e) {
                                console.error("请求失败:", e);
                            }
                        });
                    }
                },
                nicknameInput: function(e) {
                    e.detail.value.length > 0 && (this.nickname = e.detail.value), this.onChangeUserSettings();
                },
                nicknameBlur: function(e) {
                    e.detail.value.length > 0 && (this.nickname = e.detail.value), this.onChangeUserSettings();
                },
                onGetPhoneNumber: function(e) {
                    var n = this;
                    if (e.detail.iv && e.detail.encryptedData) {
                        u.showLoading();
                        r.request({
                            url: "".concat(this.apiAddr, "/user/info/phonenumber"),
                            method: "POST",
                            header: {
                                Authorization: "Bearer ".concat(this.commonValidToken),
                                "content-type": "application/json"
                            },
                            data: {
                                iv: e.detail.iv,
                                encryptedData: e.detail.encryptedData
                            },
                            success: function(e) {
                                u.hideLoading(), n.phoneNumber = "" + e.data, n.onChangeUserSettings();
                            },
                            fail: function(e) {
                                u.hideLoading(), console.log("e", e);
                            }
                        });
                    }
                },
                onChooseAvatar: function(e) {
                    var n = this;
                    u.showLoading(), u.uploadFile({
                        url: "".concat(this.apiAddr, "/user/info/avatar/update"),
                        filePath: e.detail.avatarUrl,
                        name: "file",
                        formData: {
                            userid: this.userId
                        },
                        success: function(e) {
                            u.hideLoading(), n.avatarUrl = e.data;
                        },
                        fail: function(e) {
                            u.hideLoading(), console.log("e", e);
                        }
                    });
                },
                switchRate: function(e) {
                    e.currentShow++, e.currentShow > 5 && (e.currentShow = 0);
                },
                copyText: function(e) {
                    r.request({
                        url: "".concat(this.apiAddr, "/app/cms"),
                        method: "POST",
                        header: {
                            Authorization: "Bearer ".concat(this.commonValidToken),
                            "content-type": "application/json"
                        },
                        data: {},
                        success: function(n) {
                            if (200 === n.statusCode) {
                                var t = n.data.pc;
                                1 === e && (t = n.data.chrome), t ? u.setClipboardData({
                                    data: t,
                                    success: function() {
                                        u.showToast({
                                            title: "复制成功！",
                                            icon: "success",
                                            duration: 1e3
                                        });
                                    }
                                }) : u.showToast({
                                    title: "复制失败！",
                                    icon: "none",
                                    duration: 2e3
                                });
                            }
                        }
                    });
                },
                getDate: function(e) {
                    console.log("选中的月份：" + e.value);
                },
                checkDate: function(e) {
                    console.log("选中的日期：" + e.value);
                },
                change: function(e) {
                    this.currentYear = new Date(e.value).getFullYear(), this.currentMonth = new Date(e.value).getMonth() + 1, 
                    this.fetchDailyMemories(), this.leastDate || (this.leastDate = e.value);
                },
                click2Event: function(e) {
                    if (this.leastDate === e.value) {
                        var n = this;
                        this.fetchRecords(1, function() {
                            n.isshow = !0;
                        });
                    }
                    this.leastDate = e.value;
                },
                initParams: function() {
                    try {
                        this.libraryType = u.getStorageSync("libraryType"), this.commonValidToken = u.getStorageSync("commonValidToken"), 
                        this.userId = u.getStorageSync("userId");
                    } catch (e) {}
                },
                initUpdater: function(e, n, t) {
                    var o = this;
                    this[n] && (clearInterval(this[n]), this[n] = null), e.call(this), this[n] = setInterval(function() {
                        o[t] <= 1 && o.stayMinePage && (e.call(o), o[t] = 60), o[t] = o[t] - 1;
                    }, 1e3);
                },
                selectAudioType: function() {
                    "美音" === this.audioTypeName ? this.audioTypeName = "英音" : this.audioTypeName = "美音", 
                    this.onChangeUserSettings();
                },
                selectStoryType: function() {
                    "中文" === this.storyTypeName ? this.storyTypeName = "英文" : this.storyTypeName = "中文", 
                    this.onChangeUserSettings();
                },
                editLibrary: function() {
                    var e = this, n = this.libraryOptions.filter(function(n) {
                        return n !== e.libraryType;
                    }).splice(0, 6), t = this;
                    r.showActionSheet({
                        itemList: n,
                        success: function(e) {
                            var o = n[e.tapIndex];
                            t.libraryType !== o && (t.libraryType = o, t.onChangeUserSettings());
                        },
                        fail: function(e) {}
                    });
                },
                editSwiper: function() {
                    this.shareStories = !this.shareStories, this.onChangeUserSettings();
                },
                editInfo: function(e, n, t) {
                    var o = this;
                    r.showModal({
                        title: "编辑".concat(n),
                        content: "" + t,
                        editable: !0,
                        success: function(n) {
                            n.confirm && n.content && o[e] !== n.content && (o[e] = n.content, o.onChangeUserSettings());
                        }
                    });
                },
                onChangeUserSettings: function() {
                    var e = this;
                    r.request({
                        url: "".concat(this.apiAddr, "/user/info/update"),
                        method: "POST",
                        header: {
                            Authorization: "Bearer ".concat(this.commonValidToken),
                            "content-type": "application/json"
                        },
                        data: {
                            libraryType: this.libraryType,
                            signature: this.signature,
                            email: this.email,
                            shareStories: this.shareStories,
                            storyTypeName: this.storyTypeName,
                            audioTypeName: this.audioTypeName,
                            nickname: this.nickname,
                            phoneNumber: this.phoneNumber
                        },
                        success: function(n) {
                            if (200 !== n.statusCode) throw new Error("更新失败: " + n.data.message);
                            u.showToast({
                                title: "更新成功",
                                icon: "success"
                            }), e.shareStories = n.data.shareStories || e.shareStories, e.libraryType = n.data.libraryType || e.libraryType, 
                            e.signature = n.data.signature || e.signature, e.email = n.data.email || e.email, 
                            e.storyTypeName = n.data.storyTypeName || e.storyTypeName, e.audioTypeName = n.data.audioTypeName || e.audioTypeName, 
                            e.phoneNumber = n.data.phoneNumber || e.phoneNumber, u.setStorageSync("libraryType", e.libraryType), 
                            u.setStorageSync("storyTypeName", e.storyTypeName), u.setStorageSync("audioTypeName", e.audioTypeName);
                        },
                        fail: function(e) {
                            u.showToast({
                                title: "更新失败: " + e.message,
                                icon: "none"
                            });
                        }
                    });
                },
                fetchDailyMemories: function() {
                    var e = this;
                    return (0, o.default)(i().mark(function n() {
                        var t, o, a;
                        return i().wrap(function(n) {
                            for (;;) switch (n.prev = n.next) {
                              case 0:
                                if (n.prev = 0, t = e.currentYear, (o = e.currentMonth) && t && e.beforeMonth !== o) {
                                    n.next = 5;
                                    break;
                                }
                                return n.abrupt("return");

                              case 5:
                                e.beforeMonth = o, a = e, r.request({
                                    url: "".concat(e.apiAddr, "/user/daily"),
                                    method: "POST",
                                    header: {
                                        Authorization: "Bearer ".concat(a.commonValidToken),
                                        "content-type": "application/json"
                                    },
                                    data: {
                                        year: t,
                                        month: o
                                    },
                                    success: function(n) {
                                        var t = {};
                                        n.data.map(function(e) {
                                            t[e.year] || (t[e.year] = {}), t[e.year][e.month] || (t[e.year][e.month] = {}), 
                                            t[e.year][e.month][e.day] = e.memoriesCount;
                                        });
                                        var o = {};
                                        n.data.map(function(e) {
                                            o[e.year] || (o[e.year] = {}), o[e.year][e.month] || (o[e.year][e.month] = {}), 
                                            o[e.year][e.month][e.day] = e.memoriesInfoV2;
                                        }), e.dailyMemories = t, e.dailyMemoriesV2 = o;
                                    },
                                    fail: function() {
                                        throw new Error("获取用户每天的记忆量失败");
                                    }
                                }), n.next = 13;
                                break;

                              case 10:
                                n.prev = 10, n.t0 = n.catch(0), u.showToast({
                                    title: n.t0.message,
                                    icon: "none"
                                });

                              case 13:
                              case "end":
                                return n.stop();
                            }
                        }, n, null, [ [ 0, 10 ] ]);
                    }))();
                },
                fetchWordsStatus: function() {
                    var e = this;
                    return (0, o.default)(i().mark(function n() {
                        var t;
                        return i().wrap(function(n) {
                            for (;;) switch (n.prev = n.next) {
                              case 0:
                                try {
                                    t = e, r.request({
                                        url: "".concat(e.apiAddr, "/user/libraries/rates"),
                                        method: "POST",
                                        header: {
                                            Authorization: "Bearer ".concat(t.commonValidToken),
                                            "content-type": "application/json"
                                        },
                                        data: {},
                                        success: function(n) {
                                            e.statistics = n.data.map(function(e) {
                                                return {
                                                    name: e.libraryType,
                                                    value: "".concat((100 * e.learningRate).toFixed(2), "%"),
                                                    en2zh: e.memV1Counts.en2zhOver90,
                                                    zh2en: e.memV1Counts.zh2enOver90,
                                                    en2audio: e.memV1Counts.en2audioOver90,
                                                    zh2audio: e.memV1Counts.zh2audioOver90,
                                                    audio2zh: e.memV1Counts.audio2zhOver90,
                                                    audio2en: e.memV1Counts.audio2enOver90,
                                                    count: e.count,
                                                    currentShow: 0
                                                };
                                            }), e.libraryOptions = n.data.map(function(e) {
                                                return e.libraryType;
                                            });
                                        },
                                        fail: function() {
                                            throw new Error("获取用户词库状态信息失败");
                                        }
                                    });
                                } catch (e) {
                                    u.showToast({
                                        title: e.message,
                                        icon: "none"
                                    });
                                }

                              case 1:
                              case "end":
                                return n.stop();
                            }
                        }, n);
                    }))();
                },
                fetchAuth: function() {
                    var e = this;
                    return (0, o.default)(i().mark(function n() {
                        var t;
                        return i().wrap(function(n) {
                            for (;;) switch (n.prev = n.next) {
                              case 0:
                                try {
                                    t = e, r.request({
                                        url: "".concat(e.apiAddr, "/user/auth/bind/generate-code"),
                                        method: "POST",
                                        header: {
                                            Authorization: "Bearer ".concat(t.commonValidToken),
                                            "content-type": "application/json"
                                        },
                                        data: {},
                                        success: function(n) {
                                            var t = n.data;
                                            e.code = t.code;
                                        },
                                        fail: function() {
                                            throw new Error("获取动态码失败");
                                        }
                                    });
                                } catch (e) {
                                    u.showToast({
                                        title: e.message,
                                        icon: "none"
                                    });
                                }

                              case 1:
                              case "end":
                                return n.stop();
                            }
                        }, n);
                    }))();
                },
                fetchUserData: function() {
                    var e = this;
                    return (0, o.default)(i().mark(function n() {
                        var t;
                        return i().wrap(function(n) {
                            for (;;) switch (n.prev = n.next) {
                              case 0:
                                try {
                                    t = e, r.request({
                                        url: "".concat(e.apiAddr, "/user/info"),
                                        method: "POST",
                                        header: {
                                            Authorization: "Bearer ".concat(t.commonValidToken),
                                            "content-type": "application/json"
                                        },
                                        data: {
                                            noNeedAvatarUrl: !!e.avatarUrl
                                        },
                                        success: function(n) {
                                            var t = n.data;
                                            e.signature = t.signature, e.email = t.email, e.tokens = t.tokens, e.libraryType = t.setting.libraryType, 
                                            e.shareStories = t.setting.shareStories, e.audioTypeName = t.setting.audioTypeName, 
                                            e.nickname = t.setting.nickname, e.phoneNumber = t.setting.phoneNumber, t.avatarUrl && (e.avatarUrl = t.avatarUrl);
                                        },
                                        fail: function() {
                                            throw new Error("获取个人数据失败");
                                        }
                                    });
                                } catch (e) {
                                    u.showToast({
                                        title: e.message,
                                        icon: "none"
                                    });
                                }

                              case 1:
                              case "end":
                                return n.stop();
                            }
                        }, n);
                    }))();
                }
            }
        };
    },
    "./node_modules/mini-css-extract-plugin/dist/loader.js??clonedRuleSet-12[0].rules[0].use[0]!./node_modules/@vue/cli-service/node_modules/css-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[1]!./node_modules/@dcloudio/vue-cli-plugin-uni/packages/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/@dcloudio/vue-cli-plugin-uni/packages/webpack-preprocess-loader/index.js??clonedRuleSet-12[0].rules[0].use[2]!./node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[3]!./node_modules/@dcloudio/vue-cli-plugin-uni/packages/vue-loader/lib/index.js??vue-loader-options!./node_modules/@dcloudio/webpack-uni-mp-loader/lib/style.js!./src/pages/mine/mine.vue?vue&type=style&index=0&lang=css&": 
    /*!**********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
    !*** ./node_modules/mini-css-extract-plugin/dist/loader.js??clonedRuleSet-12[0].rules[0].use[0]!./node_modules/@vue/cli-service/node_modules/css-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[1]!./node_modules/@dcloudio/vue-cli-plugin-uni/packages/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/@dcloudio/vue-cli-plugin-uni/packages/webpack-preprocess-loader/index.js??clonedRuleSet-12[0].rules[0].use[2]!./node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[3]!./node_modules/@dcloudio/vue-cli-plugin-uni/packages/vue-loader/lib/index.js??vue-loader-options!./node_modules/@dcloudio/webpack-uni-mp-loader/lib/style.js!./src/pages/mine/mine.vue?vue&type=style&index=0&lang=css& ***!
    \**********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
    function() {}
}, function(e) {
    e.O(0, [ "common/vendor" ], function() {
        return n = './src/main.js?{"page":"pages%2Fmine%2Fmine"}', e(e.s = n);
        var n;
    });
    e.O();
} ]);