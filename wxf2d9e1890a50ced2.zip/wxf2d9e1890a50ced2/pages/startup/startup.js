(global.webpackChunktest_uni = global.webpackChunktest_uni || []).push([ [ "pages/startup/startup" ], {
    "./src/pages/startup/startup.vue": 
    /*!***************************************!*\
    !*** ./src/pages/startup/startup.vue ***!
    \***************************************/
    function(e, o, s) {
        s.r(o);
        var u = s(/*! ./startup.vue?vue&type=template&id=8fde9ffc& */ "./src/pages/startup/startup.vue?vue&type=template&id=8fde9ffc&"), n = s(/*! ./startup.vue?vue&type=script&lang=js& */ "./src/pages/startup/startup.vue?vue&type=script&lang=js&"), d = (s(/*! ./startup.vue?vue&type=style&index=0&lang=css& */ "./src/pages/startup/startup.vue?vue&type=style&index=0&lang=css&"), 
        (0, s(/*! !../../../node_modules/@dcloudio/vue-cli-plugin-uni/packages/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/@dcloudio/vue-cli-plugin-uni/packages/vue-loader/lib/runtime/componentNormalizer.js").default)(n.default, u.render, u.staticRenderFns, !1, null, null, null, !1, u.components, void 0));
        d.options.__file = "pages/startup/startup.vue", o.default = d.exports;
    },
    "./src/pages/startup/startup.vue?vue&type=template&id=8fde9ffc&": 
    /*!**********************************************************************!*\
    !*** ./src/pages/startup/startup.vue?vue&type=template&id=8fde9ffc& ***!
    \**********************************************************************/
    function(e, o, s) {
        s.r(o), s.d(o, {
            components: function() {
                return u.components;
            },
            recyclableRender: function() {
                return u.recyclableRender;
            },
            render: function() {
                return u.render;
            },
            staticRenderFns: function() {
                return u.staticRenderFns;
            }
        });
        var u = s(/*! -!../../../node_modules/@dcloudio/vue-cli-plugin-uni/packages/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!../../../node_modules/@dcloudio/vue-cli-plugin-uni/packages/webpack-preprocess-loader/index.js??clonedRuleSet-42[0].rules[0].use[0]!../../../node_modules/@dcloudio/webpack-uni-mp-loader/lib/template.js!../../../node_modules/@dcloudio/vue-cli-plugin-uni/packages/webpack-uni-app-loader/page-meta.js!../../../node_modules/@dcloudio/vue-cli-plugin-uni/packages/vue-loader/lib/index.js??vue-loader-options!../../../node_modules/@dcloudio/webpack-uni-mp-loader/lib/style.js!./startup.vue?vue&type=template&id=8fde9ffc& */ "./node_modules/@dcloudio/vue-cli-plugin-uni/packages/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/@dcloudio/vue-cli-plugin-uni/packages/webpack-preprocess-loader/index.js??clonedRuleSet-42[0].rules[0].use[0]!./node_modules/@dcloudio/webpack-uni-mp-loader/lib/template.js!./node_modules/@dcloudio/vue-cli-plugin-uni/packages/webpack-uni-app-loader/page-meta.js!./node_modules/@dcloudio/vue-cli-plugin-uni/packages/vue-loader/lib/index.js??vue-loader-options!./node_modules/@dcloudio/webpack-uni-mp-loader/lib/style.js!./src/pages/startup/startup.vue?vue&type=template&id=8fde9ffc&");
    },
    "./src/pages/startup/startup.vue?vue&type=script&lang=js&": 
    /*!****************************************************************!*\
    !*** ./src/pages/startup/startup.vue?vue&type=script&lang=js& ***!
    \****************************************************************/
    function(e, o, s) {
        s.r(o);
        var u = s(/*! -!../../../node_modules/babel-loader/lib/index.js??clonedRuleSet-40[0].rules[0].use[0]!../../../node_modules/@dcloudio/vue-cli-plugin-uni/packages/webpack-preprocess-loader/index.js??clonedRuleSet-40[0].rules[0].use[1]!../../../node_modules/@dcloudio/webpack-uni-mp-loader/lib/script.js!../../../node_modules/@dcloudio/vue-cli-plugin-uni/packages/vue-loader/lib/index.js??vue-loader-options!../../../node_modules/@dcloudio/webpack-uni-mp-loader/lib/style.js!./startup.vue?vue&type=script&lang=js& */ "./node_modules/babel-loader/lib/index.js??clonedRuleSet-40[0].rules[0].use[0]!./node_modules/@dcloudio/vue-cli-plugin-uni/packages/webpack-preprocess-loader/index.js??clonedRuleSet-40[0].rules[0].use[1]!./node_modules/@dcloudio/webpack-uni-mp-loader/lib/script.js!./node_modules/@dcloudio/vue-cli-plugin-uni/packages/vue-loader/lib/index.js??vue-loader-options!./node_modules/@dcloudio/webpack-uni-mp-loader/lib/style.js!./src/pages/startup/startup.vue?vue&type=script&lang=js&");
        o.default = u.default;
    },
    "./src/pages/startup/startup.vue?vue&type=style&index=0&lang=css&": 
    /*!************************************************************************!*\
    !*** ./src/pages/startup/startup.vue?vue&type=style&index=0&lang=css& ***!
    \************************************************************************/
    function(e, o, s) {
        s.r(o);
        var u = s(/*! -!../../../node_modules/mini-css-extract-plugin/dist/loader.js??clonedRuleSet-12[0].rules[0].use[0]!../../../node_modules/@vue/cli-service/node_modules/css-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[1]!../../../node_modules/@dcloudio/vue-cli-plugin-uni/packages/vue-loader/lib/loaders/stylePostLoader.js!../../../node_modules/@dcloudio/vue-cli-plugin-uni/packages/webpack-preprocess-loader/index.js??clonedRuleSet-12[0].rules[0].use[2]!../../../node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[3]!../../../node_modules/@dcloudio/vue-cli-plugin-uni/packages/vue-loader/lib/index.js??vue-loader-options!../../../node_modules/@dcloudio/webpack-uni-mp-loader/lib/style.js!./startup.vue?vue&type=style&index=0&lang=css& */ "./node_modules/mini-css-extract-plugin/dist/loader.js??clonedRuleSet-12[0].rules[0].use[0]!./node_modules/@vue/cli-service/node_modules/css-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[1]!./node_modules/@dcloudio/vue-cli-plugin-uni/packages/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/@dcloudio/vue-cli-plugin-uni/packages/webpack-preprocess-loader/index.js??clonedRuleSet-12[0].rules[0].use[2]!./node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[3]!./node_modules/@dcloudio/vue-cli-plugin-uni/packages/vue-loader/lib/index.js??vue-loader-options!./node_modules/@dcloudio/webpack-uni-mp-loader/lib/style.js!./src/pages/startup/startup.vue?vue&type=style&index=0&lang=css&"), n = s.n(u), d = {};
        for (var t in u) "default" !== t && (d[t] = function(e) {
            return u[e];
        }.bind(0, t));
        s.d(o, d), o.default = n();
    },
    "./node_modules/@dcloudio/vue-cli-plugin-uni/packages/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/@dcloudio/vue-cli-plugin-uni/packages/webpack-preprocess-loader/index.js??clonedRuleSet-42[0].rules[0].use[0]!./node_modules/@dcloudio/webpack-uni-mp-loader/lib/template.js!./node_modules/@dcloudio/vue-cli-plugin-uni/packages/webpack-uni-app-loader/page-meta.js!./node_modules/@dcloudio/vue-cli-plugin-uni/packages/vue-loader/lib/index.js??vue-loader-options!./node_modules/@dcloudio/webpack-uni-mp-loader/lib/style.js!./src/pages/startup/startup.vue?vue&type=template&id=8fde9ffc&": 
    /*!******************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
    !*** ./node_modules/@dcloudio/vue-cli-plugin-uni/packages/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/@dcloudio/vue-cli-plugin-uni/packages/webpack-preprocess-loader/index.js??clonedRuleSet-42[0].rules[0].use[0]!./node_modules/@dcloudio/webpack-uni-mp-loader/lib/template.js!./node_modules/@dcloudio/vue-cli-plugin-uni/packages/webpack-uni-app-loader/page-meta.js!./node_modules/@dcloudio/vue-cli-plugin-uni/packages/vue-loader/lib/index.js??vue-loader-options!./node_modules/@dcloudio/webpack-uni-mp-loader/lib/style.js!./src/pages/startup/startup.vue?vue&type=template&id=8fde9ffc& ***!
    \******************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
    function(e, o, s) {
        var u;
        s.r(o), s.d(o, {
            components: function() {
                return u;
            },
            recyclableRender: function() {
                return d;
            },
            render: function() {
                return n;
            },
            staticRenderFns: function() {
                return t;
            }
        });
        try {
            u = {
                smhCountDown: function() {
                    return s.e(/*! import() | uni_modules/smh-countDown/components/smh-countDown/smh-countDown */ "uni_modules/smh-countDown/components/smh-countDown/smh-countDown").then(s.bind(s, /*! @/uni_modules/smh-countDown/components/smh-countDown/smh-countDown.vue */ "./src/uni_modules/smh-countDown/components/smh-countDown/smh-countDown.vue"));
                }
            };
        } catch (e) {
            if (-1 === e.message.indexOf("Cannot find module") || -1 === e.message.indexOf(".vue")) throw e;
            console.error(e.message), console.error("1. 排查组件名称拼写是否正确"), console.error("2. 排查组件是否符合 easycom 规范，文档：https://uniapp.dcloud.net.cn/collocation/pages?id=easycom"), 
            console.error("3. 若组件不符合 easycom 规范，需手动引入，并在 components 中注册该组件");
        }
        var n = function() {
            var e = this.$createElement;
            this._self._c;
        }, d = !1, t = [];
        n._withStripped = !0;
    },
    './src/main.js?{"page":"pages%2Fstartup%2Fstartup"}': 
    /*!**********************************************************!*\
    !*** ./src/main.js?{"page":"pages%2Fstartup%2Fstartup"} ***!
    \**********************************************************/
    function(e, o, s) {
        s.r(o);
        s(/*! uni-pages */ "./src/pages.json"), s(/*! vue */ "./node_modules/@dcloudio/vue-cli-plugin-uni/packages/mp-vue/dist/mp.runtime.esm.js");
        var u = s(/*! ./pages/startup/startup.vue */ "./src/pages/startup/startup.vue"), n = s(/*! ./node_modules/@dcloudio/uni-mp-weixin/dist/wx.js */ "./node_modules/@dcloudio/uni-mp-weixin/dist/wx.js").default, d = s(/*! ./node_modules/@dcloudio/uni-mp-weixin/dist/index.js */ "./node_modules/@dcloudio/uni-mp-weixin/dist/index.js").createPage;
        n.__webpack_require_UNI_MP_PLUGIN__ = s, d(u.default);
    },
    "./node_modules/babel-loader/lib/index.js??clonedRuleSet-40[0].rules[0].use[0]!./node_modules/@dcloudio/vue-cli-plugin-uni/packages/webpack-preprocess-loader/index.js??clonedRuleSet-40[0].rules[0].use[1]!./node_modules/@dcloudio/webpack-uni-mp-loader/lib/script.js!./node_modules/@dcloudio/vue-cli-plugin-uni/packages/vue-loader/lib/index.js??vue-loader-options!./node_modules/@dcloudio/webpack-uni-mp-loader/lib/style.js!./src/pages/startup/startup.vue?vue&type=script&lang=js&": 
    /*!*****************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
    !*** ./node_modules/babel-loader/lib/index.js??clonedRuleSet-40[0].rules[0].use[0]!./node_modules/@dcloudio/vue-cli-plugin-uni/packages/webpack-preprocess-loader/index.js??clonedRuleSet-40[0].rules[0].use[1]!./node_modules/@dcloudio/webpack-uni-mp-loader/lib/script.js!./node_modules/@dcloudio/vue-cli-plugin-uni/packages/vue-loader/lib/index.js??vue-loader-options!./node_modules/@dcloudio/webpack-uni-mp-loader/lib/style.js!./src/pages/startup/startup.vue?vue&type=script&lang=js& ***!
    \*****************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
    function(e, o, s) {
        s.r(o);
        var u = s(/*! ../../custom/config.js */ "./src/custom/config.js"), n = s(/*! ./node_modules/@dcloudio/uni-mp-weixin/dist/wx.js */ "./node_modules/@dcloudio/uni-mp-weixin/dist/wx.js").default, d = s(/*! ./node_modules/@dcloudio/uni-mp-weixin/dist/index.js */ "./node_modules/@dcloudio/uni-mp-weixin/dist/index.js").default;
        o.default = {
            data: function() {
                return {
                    timeData: {},
                    isSkip: !1,
                    apiAddr: u.default.apiAddr
                };
            },
            methods: {
                getUserInfo: function() {
                    n.getUserInfo({
                        success: function(e) {
                            var o = e.userInfo;
                            o.nickName, o.avatarUrl, o.gender, o.province, o.city, o.country;
                        },
                        fail: function(e) {
                            console.error("获取用户信息失败", e);
                        }
                    });
                },
                loginAndFetchData: function() {
                    var e = this;
                    n.login({
                        success: function(o) {
                            e.fetchData(o.code);
                        },
                        fail: function(e) {
                            console.error("登录失败", e);
                        }
                    });
                },
                fetchData: function(e) {
                    var o = this;
                    n.request({
                        url: "".concat(o.apiAddr, "/app/getwxdata"),
                        data: {
                            code: e
                        },
                        method: "POST",
                        header: {
                            Authorization: "Bearer ".concat(o.commonValidToken),
                            "content-type": "application/json"
                        },
                        success: function(e) {
                            if (e.data && e.data._id) {
                                var s = e.data, u = s._id, n = s.setting, d = n.libraryType, t = n.audioTypeName, l = s.commonValidToken;
                                o.saveData(u, d, t, l), o.navigateToHome();
                            } else console.error("无效的服务器响应");
                        },
                        fail: function() {
                            console.error("网络请求失败");
                        }
                    });
                },
                saveData: function(e, o, s, u) {
                    try {
                        d.setStorageSync("userId", e), d.setStorageSync("libraryType", o), d.setStorageSync("audioTypeName", s), 
                        d.setStorageSync("commonValidToken", u);
                    } catch (e) {
                        console.error("保存数据失败", e);
                    }
                },
                navigateToHome: function() {
                    d.switchTab({
                        url: "/pages/index/index"
                    });
                },
                end: function() {
                    this.isSkip || (this.getUserInfo(), this.loginAndFetchData());
                },
                click: function() {
                    this.isSkip = !0, this.getUserInfo(), this.loginAndFetchData();
                }
            }
        };
    },
    "./node_modules/mini-css-extract-plugin/dist/loader.js??clonedRuleSet-12[0].rules[0].use[0]!./node_modules/@vue/cli-service/node_modules/css-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[1]!./node_modules/@dcloudio/vue-cli-plugin-uni/packages/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/@dcloudio/vue-cli-plugin-uni/packages/webpack-preprocess-loader/index.js??clonedRuleSet-12[0].rules[0].use[2]!./node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[3]!./node_modules/@dcloudio/vue-cli-plugin-uni/packages/vue-loader/lib/index.js??vue-loader-options!./node_modules/@dcloudio/webpack-uni-mp-loader/lib/style.js!./src/pages/startup/startup.vue?vue&type=style&index=0&lang=css&": 
    /*!****************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
    !*** ./node_modules/mini-css-extract-plugin/dist/loader.js??clonedRuleSet-12[0].rules[0].use[0]!./node_modules/@vue/cli-service/node_modules/css-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[1]!./node_modules/@dcloudio/vue-cli-plugin-uni/packages/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/@dcloudio/vue-cli-plugin-uni/packages/webpack-preprocess-loader/index.js??clonedRuleSet-12[0].rules[0].use[2]!./node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[3]!./node_modules/@dcloudio/vue-cli-plugin-uni/packages/vue-loader/lib/index.js??vue-loader-options!./node_modules/@dcloudio/webpack-uni-mp-loader/lib/style.js!./src/pages/startup/startup.vue?vue&type=style&index=0&lang=css& ***!
    \****************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
    function() {}
}, function(e) {
    e.O(0, [ "common/vendor" ], function() {
        return o = './src/main.js?{"page":"pages%2Fstartup%2Fstartup"}', e(e.s = o);
        var o;
    });
    e.O();
} ]);