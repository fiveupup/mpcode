(global.webpackChunktest_uni = global.webpackChunktest_uni || []).push([ [ "pages/story/list" ], {
    "./src/pages/story/list.vue": 
    /*!**********************************!*\
    !*** ./src/pages/story/list.vue ***!
    \**********************************/
    function(e, o, s) {
        s.r(o);
        var t = s(/*! ./list.vue?vue&type=template&id=77c9d29e& */ "./src/pages/story/list.vue?vue&type=template&id=77c9d29e&"), n = s(/*! ./list.vue?vue&type=script&lang=js& */ "./src/pages/story/list.vue?vue&type=script&lang=js&"), i = (s(/*! ./list.vue?vue&type=style&index=0&lang=css& */ "./src/pages/story/list.vue?vue&type=style&index=0&lang=css&"), 
        (0, s(/*! !../../../node_modules/@dcloudio/vue-cli-plugin-uni/packages/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/@dcloudio/vue-cli-plugin-uni/packages/vue-loader/lib/runtime/componentNormalizer.js").default)(n.default, t.render, t.staticRenderFns, !1, null, null, null, !1, t.components, void 0));
        i.options.__file = "pages/story/list.vue", o.default = i.exports;
    },
    "./src/pages/story/list.vue?vue&type=template&id=77c9d29e&": 
    /*!*****************************************************************!*\
    !*** ./src/pages/story/list.vue?vue&type=template&id=77c9d29e& ***!
    \*****************************************************************/
    function(e, o, s) {
        s.r(o), s.d(o, {
            components: function() {
                return t.components;
            },
            recyclableRender: function() {
                return t.recyclableRender;
            },
            render: function() {
                return t.render;
            },
            staticRenderFns: function() {
                return t.staticRenderFns;
            }
        });
        var t = s(/*! -!../../../node_modules/@dcloudio/vue-cli-plugin-uni/packages/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!../../../node_modules/@dcloudio/vue-cli-plugin-uni/packages/webpack-preprocess-loader/index.js??clonedRuleSet-42[0].rules[0].use[0]!../../../node_modules/@dcloudio/webpack-uni-mp-loader/lib/template.js!../../../node_modules/@dcloudio/vue-cli-plugin-uni/packages/webpack-uni-app-loader/page-meta.js!../../../node_modules/@dcloudio/vue-cli-plugin-uni/packages/vue-loader/lib/index.js??vue-loader-options!../../../node_modules/@dcloudio/webpack-uni-mp-loader/lib/style.js!./list.vue?vue&type=template&id=77c9d29e& */ "./node_modules/@dcloudio/vue-cli-plugin-uni/packages/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/@dcloudio/vue-cli-plugin-uni/packages/webpack-preprocess-loader/index.js??clonedRuleSet-42[0].rules[0].use[0]!./node_modules/@dcloudio/webpack-uni-mp-loader/lib/template.js!./node_modules/@dcloudio/vue-cli-plugin-uni/packages/webpack-uni-app-loader/page-meta.js!./node_modules/@dcloudio/vue-cli-plugin-uni/packages/vue-loader/lib/index.js??vue-loader-options!./node_modules/@dcloudio/webpack-uni-mp-loader/lib/style.js!./src/pages/story/list.vue?vue&type=template&id=77c9d29e&");
    },
    "./src/pages/story/list.vue?vue&type=script&lang=js&": 
    /*!***********************************************************!*\
    !*** ./src/pages/story/list.vue?vue&type=script&lang=js& ***!
    \***********************************************************/
    function(e, o, s) {
        s.r(o);
        var t = s(/*! -!../../../node_modules/babel-loader/lib/index.js??clonedRuleSet-40[0].rules[0].use[0]!../../../node_modules/@dcloudio/vue-cli-plugin-uni/packages/webpack-preprocess-loader/index.js??clonedRuleSet-40[0].rules[0].use[1]!../../../node_modules/@dcloudio/webpack-uni-mp-loader/lib/script.js!../../../node_modules/@dcloudio/vue-cli-plugin-uni/packages/vue-loader/lib/index.js??vue-loader-options!../../../node_modules/@dcloudio/webpack-uni-mp-loader/lib/style.js!./list.vue?vue&type=script&lang=js& */ "./node_modules/babel-loader/lib/index.js??clonedRuleSet-40[0].rules[0].use[0]!./node_modules/@dcloudio/vue-cli-plugin-uni/packages/webpack-preprocess-loader/index.js??clonedRuleSet-40[0].rules[0].use[1]!./node_modules/@dcloudio/webpack-uni-mp-loader/lib/script.js!./node_modules/@dcloudio/vue-cli-plugin-uni/packages/vue-loader/lib/index.js??vue-loader-options!./node_modules/@dcloudio/webpack-uni-mp-loader/lib/style.js!./src/pages/story/list.vue?vue&type=script&lang=js&");
        o.default = t.default;
    },
    "./src/pages/story/list.vue?vue&type=style&index=0&lang=css&": 
    /*!*******************************************************************!*\
    !*** ./src/pages/story/list.vue?vue&type=style&index=0&lang=css& ***!
    \*******************************************************************/
    function(e, o, s) {
        s.r(o);
        var t = s(/*! -!../../../node_modules/mini-css-extract-plugin/dist/loader.js??clonedRuleSet-12[0].rules[0].use[0]!../../../node_modules/@vue/cli-service/node_modules/css-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[1]!../../../node_modules/@dcloudio/vue-cli-plugin-uni/packages/vue-loader/lib/loaders/stylePostLoader.js!../../../node_modules/@dcloudio/vue-cli-plugin-uni/packages/webpack-preprocess-loader/index.js??clonedRuleSet-12[0].rules[0].use[2]!../../../node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[3]!../../../node_modules/@dcloudio/vue-cli-plugin-uni/packages/vue-loader/lib/index.js??vue-loader-options!../../../node_modules/@dcloudio/webpack-uni-mp-loader/lib/style.js!./list.vue?vue&type=style&index=0&lang=css& */ "./node_modules/mini-css-extract-plugin/dist/loader.js??clonedRuleSet-12[0].rules[0].use[0]!./node_modules/@vue/cli-service/node_modules/css-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[1]!./node_modules/@dcloudio/vue-cli-plugin-uni/packages/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/@dcloudio/vue-cli-plugin-uni/packages/webpack-preprocess-loader/index.js??clonedRuleSet-12[0].rules[0].use[2]!./node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[3]!./node_modules/@dcloudio/vue-cli-plugin-uni/packages/vue-loader/lib/index.js??vue-loader-options!./node_modules/@dcloudio/webpack-uni-mp-loader/lib/style.js!./src/pages/story/list.vue?vue&type=style&index=0&lang=css&"), n = s.n(t), i = {};
        for (var u in t) "default" !== u && (i[u] = function(e) {
            return t[e];
        }.bind(0, u));
        s.d(o, i), o.default = n();
    },
    "./node_modules/@dcloudio/vue-cli-plugin-uni/packages/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/@dcloudio/vue-cli-plugin-uni/packages/webpack-preprocess-loader/index.js??clonedRuleSet-42[0].rules[0].use[0]!./node_modules/@dcloudio/webpack-uni-mp-loader/lib/template.js!./node_modules/@dcloudio/vue-cli-plugin-uni/packages/webpack-uni-app-loader/page-meta.js!./node_modules/@dcloudio/vue-cli-plugin-uni/packages/vue-loader/lib/index.js??vue-loader-options!./node_modules/@dcloudio/webpack-uni-mp-loader/lib/style.js!./src/pages/story/list.vue?vue&type=template&id=77c9d29e&": 
    /*!*************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
    !*** ./node_modules/@dcloudio/vue-cli-plugin-uni/packages/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/@dcloudio/vue-cli-plugin-uni/packages/webpack-preprocess-loader/index.js??clonedRuleSet-42[0].rules[0].use[0]!./node_modules/@dcloudio/webpack-uni-mp-loader/lib/template.js!./node_modules/@dcloudio/vue-cli-plugin-uni/packages/webpack-uni-app-loader/page-meta.js!./node_modules/@dcloudio/vue-cli-plugin-uni/packages/vue-loader/lib/index.js??vue-loader-options!./node_modules/@dcloudio/webpack-uni-mp-loader/lib/style.js!./src/pages/story/list.vue?vue&type=template&id=77c9d29e& ***!
    \*************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
    function(e, o, s) {
        s.r(o), s.d(o, {
            components: function() {},
            recyclableRender: function() {
                return n;
            },
            render: function() {
                return t;
            },
            staticRenderFns: function() {
                return i;
            }
        });
        var t = function() {
            var e = this.$createElement;
            this._self._c;
        }, n = !1, i = [];
        t._withStripped = !0;
    },
    './src/main.js?{"page":"pages%2Fstory%2Flist"}': 
    /*!*****************************************************!*\
    !*** ./src/main.js?{"page":"pages%2Fstory%2Flist"} ***!
    \*****************************************************/
    function(e, o, s) {
        s.r(o);
        s(/*! uni-pages */ "./src/pages.json"), s(/*! vue */ "./node_modules/@dcloudio/vue-cli-plugin-uni/packages/mp-vue/dist/mp.runtime.esm.js");
        var t = s(/*! ./pages/story/list.vue */ "./src/pages/story/list.vue"), n = s(/*! ./node_modules/@dcloudio/uni-mp-weixin/dist/wx.js */ "./node_modules/@dcloudio/uni-mp-weixin/dist/wx.js").default, i = s(/*! ./node_modules/@dcloudio/uni-mp-weixin/dist/index.js */ "./node_modules/@dcloudio/uni-mp-weixin/dist/index.js").createPage;
        n.__webpack_require_UNI_MP_PLUGIN__ = s, i(t.default);
    },
    "./node_modules/babel-loader/lib/index.js??clonedRuleSet-40[0].rules[0].use[0]!./node_modules/@dcloudio/vue-cli-plugin-uni/packages/webpack-preprocess-loader/index.js??clonedRuleSet-40[0].rules[0].use[1]!./node_modules/@dcloudio/webpack-uni-mp-loader/lib/script.js!./node_modules/@dcloudio/vue-cli-plugin-uni/packages/vue-loader/lib/index.js??vue-loader-options!./node_modules/@dcloudio/webpack-uni-mp-loader/lib/style.js!./src/pages/story/list.vue?vue&type=script&lang=js&": 
    /*!************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
    !*** ./node_modules/babel-loader/lib/index.js??clonedRuleSet-40[0].rules[0].use[0]!./node_modules/@dcloudio/vue-cli-plugin-uni/packages/webpack-preprocess-loader/index.js??clonedRuleSet-40[0].rules[0].use[1]!./node_modules/@dcloudio/webpack-uni-mp-loader/lib/script.js!./node_modules/@dcloudio/vue-cli-plugin-uni/packages/vue-loader/lib/index.js??vue-loader-options!./node_modules/@dcloudio/webpack-uni-mp-loader/lib/style.js!./src/pages/story/list.vue?vue&type=script&lang=js& ***!
    \************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
    function(e, o, s) {
        s.r(o);
        var t = s(/*! @babel/runtime/helpers/asyncToGenerator */ "./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js"), n = s(/*! @babel/runtime/regenerator */ "./node_modules/@dcloudio/vue-cli-plugin-uni/packages/@babel/runtime/regenerator/index.js"), i = s.n(n), u = s(/*! ../../custom/config.js */ "./src/custom/config.js"), r = s(/*! ./node_modules/@dcloudio/uni-mp-weixin/dist/wx.js */ "./node_modules/@dcloudio/uni-mp-weixin/dist/wx.js").default, a = s(/*! ./node_modules/@dcloudio/uni-mp-weixin/dist/index.js */ "./node_modules/@dcloudio/uni-mp-weixin/dist/index.js").default;
        o.default = {
            components: {
                StoryBlock: function() {
                    s.e(/*! require.ensure | components/StoryBlock */ "components/StoryBlock").then(function() {
                        return resolve(s(/*! ../../components/StoryBlock.vue */ "./src/components/StoryBlock.vue"));
                    }.bind(null, s)).catch(s.oe);
                }
            },
            data: function() {
                return {
                    userid: "",
                    apiAddr: u.default.apiAddr,
                    stories: [],
                    tokens: 0,
                    storyTypeName: "中文",
                    isIos: !1
                };
            },
            computed: {
                splitStories: function() {
                    var e = [], o = [];
                    return this.stories.forEach(function(s, t) {
                        t % 2 == 0 ? e.push(s) : o.push(s);
                    }), [ e, o ];
                }
            },
            onLoad: function() {
                "ios" === r.getSystemInfoSync().platform && (this.isIos = !0);
                try {
                    this.libraryType = a.getStorageSync("libraryType"), this.commonValidToken = a.getStorageSync("commonValidToken"), 
                    this.userId = a.getStorageSync("userId"), this.commonValidToken = a.getStorageSync("commonValidToken");
                } catch (e) {}
                this.fetchUserData(), this.firstFetchUserData = !0, this.fetchStories();
            },
            onShow: function() {
                this.libraryType = a.getStorageSync("libraryType"), this.storyTypeName = a.getStorageSync("storyTypeName"), 
                this.fetchStories(), !0 === this.firstFetchUserData && (this.firstFetchUserData = !1, 
                this.fetchUserData());
            },
            methods: {
                payForTokens: function() {
                    var e = this;
                    a.request({
                        url: "".concat(this.apiAddr, "/app/wxpayunifiedOrder"),
                        method: "POST",
                        header: {
                            Authorization: "Bearer ".concat(e.commonValidToken)
                        },
                        dataType: "JSON",
                        data: {
                            userid: this.userId
                        },
                        success: function(o) {
                            var s = JSON.parse(o.data);
                            a.requestPayment({
                                provider: "wxpay",
                                timeStamp: s.timeStamp,
                                nonceStr: s.nonceStr,
                                package: s.Ppackage,
                                signType: s.signType,
                                paySign: s.paySign,
                                success: function(o) {
                                    setTimeout(function() {
                                        e.fetchUserData();
                                    }, 500);
                                }
                            });
                        }
                    });
                },
                fetchStories: function() {
                    var e = this;
                    r.request({
                        url: "".concat(this.apiAddr, "/user/stories"),
                        method: "POST",
                        header: {
                            Authorization: "Bearer ".concat(this.commonValidToken),
                            "content-type": "application/json"
                        },
                        data: {
                            libraryType: this.libraryType
                        },
                        success: function(o) {
                            var s = 1;
                            e.stories = o.data.map(function(e) {
                                return e.number = s++, e;
                            });
                        },
                        fail: function() {
                            throw new Error("网络出错");
                        }
                    });
                },
                shuffle: function(e) {
                    for (var o = e.length - 1; o > 0; o--) {
                        var s = Math.floor(Math.random() * (o + 1)), t = [ e[s], e[o] ];
                        e[o] = t[0], e[s] = t[1];
                    }
                    return e;
                },
                fetchUserData: function() {
                    var e = this;
                    return (0, t.default)(i().mark(function o() {
                        var s;
                        return i().wrap(function(o) {
                            for (;;) switch (o.prev = o.next) {
                              case 0:
                                try {
                                    s = e, r.request({
                                        url: "".concat(e.apiAddr, "/user/info"),
                                        method: "POST",
                                        header: {
                                            Authorization: "Bearer ".concat(s.commonValidToken),
                                            "content-type": "application/json"
                                        },
                                        data: {},
                                        success: function(o) {
                                            var s = o.data;
                                            e.tokens = s.tokens, e.storyTypeName = s.storyTypeName || e.storyTypeName;
                                        },
                                        fail: function() {
                                            throw new Error("获取个人数据失败");
                                        }
                                    });
                                } catch (e) {
                                    a.showToast({
                                        title: e.message,
                                        icon: "none"
                                    });
                                }

                              case 1:
                              case "end":
                                return o.stop();
                            }
                        }, o);
                    }))();
                },
                generateStory: function() {
                    var e = this;
                    return (0, t.default)(i().mark(function o() {
                        var s;
                        return i().wrap(function(o) {
                            for (;;) switch (o.prev = o.next) {
                              case 0:
                                if (!(e.tokens <= 0)) {
                                    o.next = 3;
                                    break;
                                }
                                return a.showToast({
                                    title: "代币不足！",
                                    icon: "none"
                                }), o.abrupt("return");

                              case 3:
                                try {
                                    s = e, r.request({
                                        url: "".concat(e.apiAddr, "/user/story/generate"),
                                        method: "POST",
                                        header: {
                                            Authorization: "Bearer ".concat(s.commonValidToken),
                                            "content-type": "application/json"
                                        },
                                        data: {
                                            storyTypeName: e.storyTypeName,
                                            libraryType: e.libraryType
                                        },
                                        success: function(o) {
                                            var s = o.data.error, t = o.data.reason;
                                            s ? a.showToast({
                                                title: t || "未知错误",
                                                icon: "error"
                                            }) : (e.tokens = o.data.tokens, a.showToast({
                                                title: "启动故事生成！",
                                                icon: "success"
                                            }), e.fetchStories());
                                        },
                                        fail: function() {
                                            throw new Error("生成故事失败");
                                        }
                                    });
                                } catch (e) {
                                    a.showToast({
                                        title: e.message,
                                        icon: "none"
                                    });
                                }

                              case 4:
                              case "end":
                                return o.stop();
                            }
                        }, o);
                    }))();
                }
            }
        };
    },
    "./node_modules/mini-css-extract-plugin/dist/loader.js??clonedRuleSet-12[0].rules[0].use[0]!./node_modules/@vue/cli-service/node_modules/css-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[1]!./node_modules/@dcloudio/vue-cli-plugin-uni/packages/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/@dcloudio/vue-cli-plugin-uni/packages/webpack-preprocess-loader/index.js??clonedRuleSet-12[0].rules[0].use[2]!./node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[3]!./node_modules/@dcloudio/vue-cli-plugin-uni/packages/vue-loader/lib/index.js??vue-loader-options!./node_modules/@dcloudio/webpack-uni-mp-loader/lib/style.js!./src/pages/story/list.vue?vue&type=style&index=0&lang=css&": 
    /*!***********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
    !*** ./node_modules/mini-css-extract-plugin/dist/loader.js??clonedRuleSet-12[0].rules[0].use[0]!./node_modules/@vue/cli-service/node_modules/css-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[1]!./node_modules/@dcloudio/vue-cli-plugin-uni/packages/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/@dcloudio/vue-cli-plugin-uni/packages/webpack-preprocess-loader/index.js??clonedRuleSet-12[0].rules[0].use[2]!./node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[3]!./node_modules/@dcloudio/vue-cli-plugin-uni/packages/vue-loader/lib/index.js??vue-loader-options!./node_modules/@dcloudio/webpack-uni-mp-loader/lib/style.js!./src/pages/story/list.vue?vue&type=style&index=0&lang=css& ***!
    \***********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
    function() {}
}, function(e) {
    e.O(0, [ "common/vendor" ], function() {
        return o = './src/main.js?{"page":"pages%2Fstory%2Flist"}', e(e.s = o);
        var o;
    });
    e.O();
} ]);