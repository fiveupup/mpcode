require("../../@babel/runtime/helpers/Objectvalues"), (global.webpackChunktest_uni = global.webpackChunktest_uni || []).push([ [ "pages/story/watch" ], {
    "./src/pages/story/watch.vue": 
    /*!***********************************!*\
    !*** ./src/pages/story/watch.vue ***!
    \***********************************/
    function(e, t, o) {
        o.r(t);
        var n = o(/*! ./watch.vue?vue&type=template&id=0bb8d668& */ "./src/pages/story/watch.vue?vue&type=template&id=0bb8d668&"), s = o(/*! ./watch.vue?vue&type=script&lang=js& */ "./src/pages/story/watch.vue?vue&type=script&lang=js&"), a = (o(/*! ./watch.vue?vue&type=style&index=0&lang=css& */ "./src/pages/story/watch.vue?vue&type=style&index=0&lang=css&"), 
        (0, o(/*! !../../../node_modules/@dcloudio/vue-cli-plugin-uni/packages/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/@dcloudio/vue-cli-plugin-uni/packages/vue-loader/lib/runtime/componentNormalizer.js").default)(s.default, n.render, n.staticRenderFns, !1, null, null, null, !1, n.components, void 0));
        a.options.__file = "pages/story/watch.vue", t.default = a.exports;
    },
    "./src/pages/story/watch.vue?vue&type=template&id=0bb8d668&": 
    /*!******************************************************************!*\
    !*** ./src/pages/story/watch.vue?vue&type=template&id=0bb8d668& ***!
    \******************************************************************/
    function(e, t, o) {
        o.r(t), o.d(t, {
            components: function() {
                return n.components;
            },
            recyclableRender: function() {
                return n.recyclableRender;
            },
            render: function() {
                return n.render;
            },
            staticRenderFns: function() {
                return n.staticRenderFns;
            }
        });
        var n = o(/*! -!../../../node_modules/@dcloudio/vue-cli-plugin-uni/packages/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!../../../node_modules/@dcloudio/vue-cli-plugin-uni/packages/webpack-preprocess-loader/index.js??clonedRuleSet-42[0].rules[0].use[0]!../../../node_modules/@dcloudio/webpack-uni-mp-loader/lib/template.js!../../../node_modules/@dcloudio/vue-cli-plugin-uni/packages/webpack-uni-app-loader/page-meta.js!../../../node_modules/@dcloudio/vue-cli-plugin-uni/packages/vue-loader/lib/index.js??vue-loader-options!../../../node_modules/@dcloudio/webpack-uni-mp-loader/lib/style.js!./watch.vue?vue&type=template&id=0bb8d668& */ "./node_modules/@dcloudio/vue-cli-plugin-uni/packages/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/@dcloudio/vue-cli-plugin-uni/packages/webpack-preprocess-loader/index.js??clonedRuleSet-42[0].rules[0].use[0]!./node_modules/@dcloudio/webpack-uni-mp-loader/lib/template.js!./node_modules/@dcloudio/vue-cli-plugin-uni/packages/webpack-uni-app-loader/page-meta.js!./node_modules/@dcloudio/vue-cli-plugin-uni/packages/vue-loader/lib/index.js??vue-loader-options!./node_modules/@dcloudio/webpack-uni-mp-loader/lib/style.js!./src/pages/story/watch.vue?vue&type=template&id=0bb8d668&");
    },
    "./src/pages/story/watch.vue?vue&type=script&lang=js&": 
    /*!************************************************************!*\
    !*** ./src/pages/story/watch.vue?vue&type=script&lang=js& ***!
    \************************************************************/
    function(e, t, o) {
        o.r(t);
        var n = o(/*! -!../../../node_modules/babel-loader/lib/index.js??clonedRuleSet-40[0].rules[0].use[0]!../../../node_modules/@dcloudio/vue-cli-plugin-uni/packages/webpack-preprocess-loader/index.js??clonedRuleSet-40[0].rules[0].use[1]!../../../node_modules/@dcloudio/webpack-uni-mp-loader/lib/script.js!../../../node_modules/@dcloudio/vue-cli-plugin-uni/packages/vue-loader/lib/index.js??vue-loader-options!../../../node_modules/@dcloudio/webpack-uni-mp-loader/lib/style.js!./watch.vue?vue&type=script&lang=js& */ "./node_modules/babel-loader/lib/index.js??clonedRuleSet-40[0].rules[0].use[0]!./node_modules/@dcloudio/vue-cli-plugin-uni/packages/webpack-preprocess-loader/index.js??clonedRuleSet-40[0].rules[0].use[1]!./node_modules/@dcloudio/webpack-uni-mp-loader/lib/script.js!./node_modules/@dcloudio/vue-cli-plugin-uni/packages/vue-loader/lib/index.js??vue-loader-options!./node_modules/@dcloudio/webpack-uni-mp-loader/lib/style.js!./src/pages/story/watch.vue?vue&type=script&lang=js&");
        t.default = n.default;
    },
    "./src/pages/story/watch.vue?vue&type=style&index=0&lang=css&": 
    /*!********************************************************************!*\
    !*** ./src/pages/story/watch.vue?vue&type=style&index=0&lang=css& ***!
    \********************************************************************/
    function(e, t, o) {
        o.r(t);
        var n = o(/*! -!../../../node_modules/mini-css-extract-plugin/dist/loader.js??clonedRuleSet-12[0].rules[0].use[0]!../../../node_modules/@vue/cli-service/node_modules/css-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[1]!../../../node_modules/@dcloudio/vue-cli-plugin-uni/packages/vue-loader/lib/loaders/stylePostLoader.js!../../../node_modules/@dcloudio/vue-cli-plugin-uni/packages/webpack-preprocess-loader/index.js??clonedRuleSet-12[0].rules[0].use[2]!../../../node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[3]!../../../node_modules/@dcloudio/vue-cli-plugin-uni/packages/vue-loader/lib/index.js??vue-loader-options!../../../node_modules/@dcloudio/webpack-uni-mp-loader/lib/style.js!./watch.vue?vue&type=style&index=0&lang=css& */ "./node_modules/mini-css-extract-plugin/dist/loader.js??clonedRuleSet-12[0].rules[0].use[0]!./node_modules/@vue/cli-service/node_modules/css-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[1]!./node_modules/@dcloudio/vue-cli-plugin-uni/packages/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/@dcloudio/vue-cli-plugin-uni/packages/webpack-preprocess-loader/index.js??clonedRuleSet-12[0].rules[0].use[2]!./node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[3]!./node_modules/@dcloudio/vue-cli-plugin-uni/packages/vue-loader/lib/index.js??vue-loader-options!./node_modules/@dcloudio/webpack-uni-mp-loader/lib/style.js!./src/pages/story/watch.vue?vue&type=style&index=0&lang=css&"), s = o.n(n), a = {};
        for (var i in n) "default" !== i && (a[i] = function(e) {
            return n[e];
        }.bind(0, i));
        o.d(t, a), t.default = s();
    },
    "./node_modules/@dcloudio/vue-cli-plugin-uni/packages/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/@dcloudio/vue-cli-plugin-uni/packages/webpack-preprocess-loader/index.js??clonedRuleSet-42[0].rules[0].use[0]!./node_modules/@dcloudio/webpack-uni-mp-loader/lib/template.js!./node_modules/@dcloudio/vue-cli-plugin-uni/packages/webpack-uni-app-loader/page-meta.js!./node_modules/@dcloudio/vue-cli-plugin-uni/packages/vue-loader/lib/index.js??vue-loader-options!./node_modules/@dcloudio/webpack-uni-mp-loader/lib/style.js!./src/pages/story/watch.vue?vue&type=template&id=0bb8d668&": 
    /*!**************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
    !*** ./node_modules/@dcloudio/vue-cli-plugin-uni/packages/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/@dcloudio/vue-cli-plugin-uni/packages/webpack-preprocess-loader/index.js??clonedRuleSet-42[0].rules[0].use[0]!./node_modules/@dcloudio/webpack-uni-mp-loader/lib/template.js!./node_modules/@dcloudio/vue-cli-plugin-uni/packages/webpack-uni-app-loader/page-meta.js!./node_modules/@dcloudio/vue-cli-plugin-uni/packages/vue-loader/lib/index.js??vue-loader-options!./node_modules/@dcloudio/webpack-uni-mp-loader/lib/style.js!./src/pages/story/watch.vue?vue&type=template&id=0bb8d668& ***!
    \**************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
    function(e, t, o) {
        var n;
        o.r(t), o.d(t, {
            components: function() {
                return n;
            },
            recyclableRender: function() {
                return a;
            },
            render: function() {
                return s;
            },
            staticRenderFns: function() {
                return i;
            }
        });
        try {
            n = {
                mpHtml: function() {
                    return Promise.all(/*! import() | uni_modules/mp-html/components/mp-html/mp-html */ [ o.e("common/vendor"), o.e("uni_modules/mp-html/components/mp-html/mp-html") ]).then(o.bind(o, /*! @/uni_modules/mp-html/components/mp-html/mp-html.vue */ "./src/uni_modules/mp-html/components/mp-html/mp-html.vue"));
                }
            };
        } catch (e) {
            if (-1 === e.message.indexOf("Cannot find module") || -1 === e.message.indexOf(".vue")) throw e;
            console.error(e.message), console.error("1. 排查组件名称拼写是否正确"), console.error("2. 排查组件是否符合 easycom 规范，文档：https://uniapp.dcloud.net.cn/collocation/pages?id=easycom"), 
            console.error("3. 若组件不符合 easycom 规范，需手动引入，并在 components 中注册该组件");
        }
        var s = function() {
            var e = this.$createElement;
            this._self._c;
        }, a = !1, i = [];
        s._withStripped = !0;
    },
    './src/main.js?{"page":"pages%2Fstory%2Fwatch"}': 
    /*!******************************************************!*\
    !*** ./src/main.js?{"page":"pages%2Fstory%2Fwatch"} ***!
    \******************************************************/
    function(e, t, o) {
        o.r(t);
        o(/*! uni-pages */ "./src/pages.json"), o(/*! vue */ "./node_modules/@dcloudio/vue-cli-plugin-uni/packages/mp-vue/dist/mp.runtime.esm.js");
        var n = o(/*! ./pages/story/watch.vue */ "./src/pages/story/watch.vue"), s = o(/*! ./node_modules/@dcloudio/uni-mp-weixin/dist/wx.js */ "./node_modules/@dcloudio/uni-mp-weixin/dist/wx.js").default, a = o(/*! ./node_modules/@dcloudio/uni-mp-weixin/dist/index.js */ "./node_modules/@dcloudio/uni-mp-weixin/dist/index.js").createPage;
        s.__webpack_require_UNI_MP_PLUGIN__ = o, a(n.default);
    },
    "./node_modules/babel-loader/lib/index.js??clonedRuleSet-40[0].rules[0].use[0]!./node_modules/@dcloudio/vue-cli-plugin-uni/packages/webpack-preprocess-loader/index.js??clonedRuleSet-40[0].rules[0].use[1]!./node_modules/@dcloudio/webpack-uni-mp-loader/lib/script.js!./node_modules/@dcloudio/vue-cli-plugin-uni/packages/vue-loader/lib/index.js??vue-loader-options!./node_modules/@dcloudio/webpack-uni-mp-loader/lib/style.js!./src/pages/story/watch.vue?vue&type=script&lang=js&": 
    /*!*************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
    !*** ./node_modules/babel-loader/lib/index.js??clonedRuleSet-40[0].rules[0].use[0]!./node_modules/@dcloudio/vue-cli-plugin-uni/packages/webpack-preprocess-loader/index.js??clonedRuleSet-40[0].rules[0].use[1]!./node_modules/@dcloudio/webpack-uni-mp-loader/lib/script.js!./node_modules/@dcloudio/vue-cli-plugin-uni/packages/vue-loader/lib/index.js??vue-loader-options!./node_modules/@dcloudio/webpack-uni-mp-loader/lib/style.js!./src/pages/story/watch.vue?vue&type=script&lang=js& ***!
    \*************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
    function(e, t, o) {
        o.r(t);
        var n = o(/*! @babel/runtime/helpers/defineProperty */ "./node_modules/@babel/runtime/helpers/esm/defineProperty.js"), s = o(/*! ../../custom/config.js */ "./src/custom/config.js"), a = o(/*! ./node_modules/@dcloudio/uni-mp-weixin/dist/wx.js */ "./node_modules/@dcloudio/uni-mp-weixin/dist/wx.js").default, i = o(/*! ./node_modules/@dcloudio/uni-mp-weixin/dist/index.js */ "./node_modules/@dcloudio/uni-mp-weixin/dist/index.js").default;
        function r(e, t) {
            var o = Object.keys(e);
            if (Object.getOwnPropertySymbols) {
                var n = Object.getOwnPropertySymbols(e);
                t && (n = n.filter(function(t) {
                    return Object.getOwnPropertyDescriptor(e, t).enumerable;
                })), o.push.apply(o, n);
            }
            return o;
        }
        function l(e) {
            for (var t = 1; t < arguments.length; t++) {
                var o = null != arguments[t] ? arguments[t] : {};
                t % 2 ? r(Object(o), !0).forEach(function(t) {
                    (0, n.default)(e, t, o[t]);
                }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(o)) : r(Object(o)).forEach(function(t) {
                    Object.defineProperty(e, t, Object.getOwnPropertyDescriptor(o, t));
                });
            }
            return e;
        }
        function u(e, t) {
            var o = "undefined" != typeof Symbol && e[Symbol.iterator] || e["@@iterator"];
            if (!o) {
                if (Array.isArray(e) || (o = function(e, t) {
                    if (!e) return;
                    if ("string" == typeof e) return c(e, t);
                    var o = Object.prototype.toString.call(e).slice(8, -1);
                    "Object" === o && e.constructor && (o = e.constructor.name);
                    if ("Map" === o || "Set" === o) return Array.from(e);
                    if ("Arguments" === o || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(o)) return c(e, t);
                }(e)) || t && e && "number" == typeof e.length) {
                    o && (e = o);
                    var n = 0, s = function() {};
                    return {
                        s: s,
                        n: function() {
                            return n >= e.length ? {
                                done: !0
                            } : {
                                done: !1,
                                value: e[n++]
                            };
                        },
                        e: function(e) {
                            throw e;
                        },
                        f: s
                    };
                }
                throw new TypeError("Invalid attempt to iterate non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.");
            }
            var a, i = !0, r = !1;
            return {
                s: function() {
                    o = o.call(e);
                },
                n: function() {
                    var e = o.next();
                    return i = e.done, e;
                },
                e: function(e) {
                    r = !0, a = e;
                },
                f: function() {
                    try {
                        i || null == o.return || o.return();
                    } finally {
                        if (r) throw a;
                    }
                }
            };
        }
        function c(e, t) {
            (null == t || t > e.length) && (t = e.length);
            for (var o = 0, n = new Array(t); o < t; o++) n[o] = e[o];
            return n;
        }
        var d = a.getBackgroundAudioManager();
        t.default = {
            data: function() {
                return {
                    userId: "",
                    storyName: "",
                    storyId: "",
                    storyContent: "这是故事的详细内容...",
                    contentV1: [],
                    apiAddr: s.default.apiAddr,
                    html: "<div>Hello World!</div>",
                    wordDetails: new Map(),
                    formattedStoryContent: [],
                    progressBarWidth: 0,
                    tempOssUrl: null,
                    totalHeight: 0,
                    randomFontClass: "",
                    playState: 0,
                    audioTypeName: "美音",
                    loopAudio: !1,
                    playEnum: {
                        STOPPING: 0,
                        PLAYING: 1,
                        PAUSING: 2
                    },
                    leastWord: null,
                    currentBundleWords: []
                };
            },
            computed: {
                audioTypeIndex: function() {
                    return "美音" === this.audioTypeName ? "1" : "0";
                }
            },
            onLoad: function() {
                var e = this;
                try {
                    this.storyId = i.getStorageSync("storyId"), this.storyName = i.getStorageSync("storyName"), 
                    this.commonValidToken = i.getStorageSync("commonValidToken"), this.userId = i.getStorageSync("userId"), 
                    this.audioTypeName = i.getStorageSync("audioTypeName");
                } catch (e) {}
                setTimeout(function() {
                    e.calculateTotalHeight();
                }, 1500), this.fetchStory(this.storyId), this.randomFontStyle();
            },
            onPageScroll: function(e) {
                var t = e.scrollTop, o = i.getSystemInfoSync().windowHeight, n = t / (this.totalHeight - o) * 100;
                this.progressBarWidth = n;
            },
            onUnload: function() {
                console.log("onHideStory"), this.internalPushMemV1 && (clearInterval(this.internalPushMemV1), 
                this.internalPushMemV1 = null, this.pushStoryMemV1()), d.stop();
            },
            methods: {
                onLongPressPlay: function() {
                    var e = this;
                    switch (this.playState) {
                      case this.playEnum.PLAYING:
                        d.stop(), d.onStop(function() {
                            e.playState = e.playEnum.STOPPING;
                        });
                        break;

                      case this.playEnum.STOPPING:
                        this.loopAudio = !0, this.playStoryMusic(), this.playState = this.playEnum.PLAYING;
                        break;

                      case this.playEnum.PAUSING:
                    }
                },
                onPressPlay: function() {
                    switch (this.playState) {
                      case this.playEnum.PLAYING:
                        d.pause(), this.playState = this.playEnum.PAUSING;
                        break;

                      case this.playEnum.STOPPING:
                        this.loopAudio = !1, this.playStoryMusic(), this.playState = this.playEnum.PLAYING;
                        break;

                      case this.playEnum.PAUSING:
                      default:
                        d.play(), this.playState = this.playEnum.PLAYING;
                    }
                },
                initPlayer: function() {
                    var e = this;
                    d.onPlay(function() {
                        e.playing = !0;
                    }), d.onEnded(function(t) {
                        this.loopAudio && e.playStoryMusic();
                    }), d.onTimeUpdate(function(t) {
                        var o = d.duration, n = d.currentTime;
                        var s = function(e, t) {
                            var o, n = null, s = u(e);
                            try {
                                for (s.s(); !(o = s.n()).done; ) {
                                    var a = o.value;
                                    if (a.percentage >= t) {
                                        n = a;
                                        break;
                                    }
                                }
                            } catch (e) {
                                s.e(e);
                            } finally {
                                s.f();
                            }
                            return n;
                        }(e.wordPositions, n / o * 100);
                        s !== e.leastWord && (e.leastWord = s, e.currentBundleWords.push(e.leastWord));
                    }), this.internalPushMemV1 = setInterval(function() {
                        e.pushStoryMemV1();
                    }, 1e4);
                },
                pushStoryMemV1: function() {
                    var e = this.currentBundleWords.map(function(e) {
                        return {
                            word: e,
                            memV1: {
                                audio2self: 0,
                                audio2en: 0,
                                audio2zh: 0,
                                en2audio: 0,
                                en2self: 0,
                                en2zh: 0,
                                zh2audio: 0,
                                zh2en: 1
                            }
                        };
                    });
                    this.memV1Logs(e), this.currentBundleWords = [];
                },
                memV1Logs: function(e) {
                    a.request({
                        url: "".concat(this.apiAddr, "/user/log/mp"),
                        method: "POST",
                        header: {
                            Authorization: "Bearer ".concat(this.commonValidToken),
                            "content-type": "application/json"
                        },
                        data: {
                            wordsArray: [],
                            logV1: e
                        },
                        success: function(e) {
                            console.log(e);
                        },
                        fail: function() {
                            a.showToast({
                                title: "网络出错",
                                icon: "none",
                                duration: 2e3
                            });
                        }
                    });
                },
                playStoryMusic: function() {
                    d.title = this.storyName, d.epname = "AI单词故事", d.singer = "AI单词故事", d.coverImgUrl = "http://y.gtimg.cn/music/photo_new/T002R300x300M000003rsKF44GyaSk.jpg?max_age=2592000", 
                    d.src = this.tempOssUrl;
                },
                randomFontStyle: function() {
                    function e(e, t) {
                        return "".concat(e).concat(Math.floor(Math.random() * t) + 1);
                    }
                    var t = e("font-type", 22), o = e("weight-type", 4), n = e("style-type", 2), s = e("size-type", 4);
                    this.randomFontClass = t + " " + o + " " + n + " " + s;
                },
                calculateTotalHeight: function() {
                    var e = this;
                    i.createSelectorQuery().in(this).select(".story-content").boundingClientRect(function(t) {
                        t && (e.totalHeight = t.height);
                    }).exec();
                },
                updateStoryContentByContentV1: function(e) {
                    var t = this, o = [], n = function(e, t) {
                        var n = '<span class="'.concat(t, '">').concat(e, "</span>");
                        return o.push({
                            content: n
                        }), n;
                    };
                    this.mainLang = "zh", e.forEach(function(e) {
                        if ("normal" === e.type) n(e.content, "non-italic-word"); else if ("word" === e.type) {
                            var s = t.wordDetails.get(e.en);
                            if (s) if ("en" === t.mainLang) !function(e, t, n, s) {
                                var a = '<span>(<span class="'.concat(n, '" style="font-size:').concat(s.fontSize, "vh; visibility: ").concat(s.isShow ? "visible" : "hidden", '">').concat(t, "</span>)[<span>").concat(e, "</span>]</span>");
                                o.push({
                                    content: a,
                                    word: t
                                });
                            }(e.zh, e.en, "italic-word ".concat(t.randomFontClass), s); else {
                                var a = s.memInfo && s.memInfo.memV1;
                                a && a.en2zh >= 90 ? function(e, t, n, s) {
                                    var a = '<span><span class="'.concat(n, '" style="font-size:').concat(s.fontSize, 'vh}">').concat(t, "</span></span>");
                                    o.push({
                                        content: a,
                                        word: t
                                    });
                                }(e.zh, e.en, "italic-word ".concat(t.randomFontClass), s) : function(e, t, n, s) {
                                    var a = "<span>[<span>".concat(e, '</span>](<span class="').concat(n, '" style="font-size:').concat(s.fontSize, "vh; visibility: ").concat(s.isShow ? "visible" : "hidden", '">').concat(t, "</span>)</span>");
                                    o.push({
                                        content: a,
                                        word: t
                                    });
                                }(e.zh, e.en, "italic-word ".concat(t.randomFontClass), s);
                            } else n("".concat(e.zh, " (").concat(e.en, ")"), "non-italic-word");
                        } else "meta" === e.type && "title" === e.key ? t.storyName = e.value : "meta" === e.type && "main_lang" === e.key && (t.mainLang = e.value);
                    }), this.formattedStoryContent = o;
                },
                updateStoryContent: function() {
                    if (this.contentV1.length) this.updateStoryContentByContentV1(this.contentV1); else {
                        var e = [], t = function(t, o, n) {
                            var s = '<span class="'.concat(o, '">').concat(t, "</span>");
                            return e.push({
                                content: s,
                                word: n
                            }), s;
                        }, o = this, n = !1;
                        this.storyContent.replace(/(\([a-zA-Z\-]+\))|([^\(\)]+)/g, function(s, a, i) {
                            if (a) {
                                var r = a.slice(1, -1), l = o.wordDetails.get(r);
                                l ? function(t, o, n, s) {
                                    var a = '<span class="'.concat(o, '" style="font-size:').concat(s.fontSize, "vh; visibility: ").concat(s.isShow ? "visible" : "hidden", '">').concat(t, "</span>");
                                    e.push({
                                        content: a,
                                        word: n
                                    });
                                }(r, "italic-word ".concat(o.randomFontClass), r, l) : t(r, "non-italic-word", null);
                            } else i && (n ? t(")" + i + "(", "non-italic-word", null) : (t(i + "(", "non-italic-word", null), 
                            n = !0));
                            return s;
                        }), this.formattedStoryContent = e;
                    }
                },
                contentTouchStart: function(e) {},
                contentTouchMove: function(e) {},
                contentTouchEnd: function(e) {},
                calculateWordPositions: function(e) {
                    var t, o = 0, n = [], s = function(e) {
                        var t = e.split("").reduce(function(e, t) {
                            return e + (/[a-zA-Z]/.test(t) ? .2 : 1);
                        }, 0);
                        t = Math.ceil(t), o += t;
                    }, a = u(e);
                    try {
                        for (a.s(); !(t = a.n()).done; ) {
                            var i = t.value;
                            "meta" === i.type && "main_lang" === i.key ? i.value : "meta" === i.type && "title" === i.key ? s(i.value) : "normal" === i.type ? s(i.content) : "word" === i.type && (s(i.zh + i.en), 
                            n.push({
                                word: i.en,
                                position: o
                            }));
                        }
                    } catch (e) {
                        a.e(e);
                    } finally {
                        a.f();
                    }
                    return n.map(function(e) {
                        return l(l({}, e), {}, {
                            percentage: e.position / o * 100
                        });
                    });
                },
                clickWord: function(e) {
                    if (this.wordDetails.has(e.target.dataset.word)) {
                        var t = this.wordDetails.get(e.target.dataset.word), o = t._audioV1[this.audioTypeIndex];
                        if (o) a.setInnerAudioOption({
                            obeyMuteSwitch: !1
                        }), o.play(); else {
                            var n = t.audio;
                            a.setInnerAudioOption({
                                obeyMuteSwitch: !1
                            }), n.play();
                        }
                        t.fontSize *= 1;
                        var s = t.isShow;
                        t.isShow = !0, t.audioTimes || (t.audioTimes = 0), t.audioTimes++, s ? t.audioTimes <= 3 && this.mpLog(t.word, {
                            audio2self: 1,
                            audio2en: 1,
                            audio2zh: 0,
                            en2audio: 1,
                            en2self: 1,
                            en2zh: 1,
                            zh2audio: 1,
                            zh2en: 1
                        }) : this.mpLog(t.word, {
                            audio2self: 1,
                            audio2en: 1,
                            audio2zh: 0,
                            en2audio: 0,
                            en2self: 1,
                            en2zh: 0,
                            zh2audio: 1,
                            zh2en: 5
                        });
                    }
                    this.updateStoryContent(), console.log(this.wordDetails);
                },
                fetchStory: function() {
                    var e = this;
                    a.request({
                        url: "".concat(this.apiAddr, "/user/story"),
                        method: "POST",
                        header: {
                            Authorization: "Bearer ".concat(this.commonValidToken),
                            "content-type": "application/json"
                        },
                        data: {
                            storyid: this.storyId
                        },
                        success: function(t) {
                            e.storyContent = t.data.story.content, e.contentV1 = t.data.story.contentV1 || [], 
                            e.tempOssUrl = t.data.tempOssUrl;
                            for (var o = 0, n = Object.values(t.data.wordDetails); o < n.length; o++) {
                                var s = n[o], a = i.createInnerAudioContext();
                                a.src = s.mp3;
                                var r = i.createInnerAudioContext();
                                r.src = "https://dict.youdao.com/dictvoice?audio=".concat(s.word, "&type=1");
                                var l = i.createInnerAudioContext();
                                l.src = "https://dict.youdao.com/dictvoice?audio=".concat(s.word, "&type=2"), s.audio = a, 
                                s._audioV1 = [ r, l ], s.fontSize = 5, e.wordDetails.set(s.word, s);
                            }
                            e.updateStoryContent(), e.wordPositions = e.calculateWordPositions(e.contentV1), 
                            e.initPlayer();
                        },
                        fail: function() {
                            a.showToast({
                                title: "网络出错",
                                icon: "none",
                                duration: 2e3
                            });
                        }
                    });
                },
                mpLog: function(e, t) {
                    a.request({
                        url: "".concat(this.apiAddr, "/user/log/mp"),
                        method: "POST",
                        header: {
                            Authorization: "Bearer ".concat(this.commonValidToken),
                            "content-type": "application/json"
                        },
                        data: {
                            wordsArray: [ e ],
                            logV1: [ {
                                word: e,
                                memV1: t
                            } ]
                        },
                        success: function(e) {
                            console.log(e);
                        },
                        fail: function() {
                            a.showToast({
                                title: "网络出错",
                                icon: "none",
                                duration: 2e3
                            });
                        }
                    });
                }
            }
        };
    },
    "./node_modules/mini-css-extract-plugin/dist/loader.js??clonedRuleSet-12[0].rules[0].use[0]!./node_modules/@vue/cli-service/node_modules/css-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[1]!./node_modules/@dcloudio/vue-cli-plugin-uni/packages/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/@dcloudio/vue-cli-plugin-uni/packages/webpack-preprocess-loader/index.js??clonedRuleSet-12[0].rules[0].use[2]!./node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[3]!./node_modules/@dcloudio/vue-cli-plugin-uni/packages/vue-loader/lib/index.js??vue-loader-options!./node_modules/@dcloudio/webpack-uni-mp-loader/lib/style.js!./src/pages/story/watch.vue?vue&type=style&index=0&lang=css&": 
    /*!************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
    !*** ./node_modules/mini-css-extract-plugin/dist/loader.js??clonedRuleSet-12[0].rules[0].use[0]!./node_modules/@vue/cli-service/node_modules/css-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[1]!./node_modules/@dcloudio/vue-cli-plugin-uni/packages/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/@dcloudio/vue-cli-plugin-uni/packages/webpack-preprocess-loader/index.js??clonedRuleSet-12[0].rules[0].use[2]!./node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-12[0].rules[0].use[3]!./node_modules/@dcloudio/vue-cli-plugin-uni/packages/vue-loader/lib/index.js??vue-loader-options!./node_modules/@dcloudio/webpack-uni-mp-loader/lib/style.js!./src/pages/story/watch.vue?vue&type=style&index=0&lang=css& ***!
    \************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
    function() {}
}, function(e) {
    e.O(0, [ "common/vendor" ], function() {
        return t = './src/main.js?{"page":"pages%2Fstory%2Fwatch"}', e(e.s = t);
        var t;
    });
    e.O();
} ]);