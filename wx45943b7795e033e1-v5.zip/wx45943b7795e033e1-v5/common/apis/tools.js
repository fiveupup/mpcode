var _require = require("../../utils/requests"),
  request = _require.request;function getUploadToken(data) {
  return request.post('/v2/qiniu/getUploadToken', data);
}function updateAvatar(data) {
  return request.post('/v2/user/updateUserAvatar', data);
}function updateUserInfo(data) {
  return request.post('/v2/user/updateUserInfo', data);
}function getUser() {
  return request.post('/v2/getUser');
}module.exports = {
  getUploadToken: getUploadToken,
  updateAvatar: updateAvatar,
  updateUserInfo: updateUserInfo,
  getUser: getUser
};