var _regeneratorRuntime2 = require("../../@babel/runtime/helpers/regeneratorRuntime");var _asyncToGenerator2 = require("../../@babel/runtime/helpers/asyncToGenerator");var _require = require("../../utils/requests"),
  request = _require.request;function list(offset) {
  return request.post('/v2/draws/list2', {
    offset: offset
  });
}function findOneById(id) {
  return request.post('/v2/draws/findOneById', {
    id: id
  });
}function deleteOneById(id) {
  return request.post('/v2/draws/deleteOneById', {
    id: id
  });
}function updateOne(data) {
  return request.post('/v2/draws/updateOne', data);
}function UpdateShareSettings(data) {
  return request.post('/v2/draws/UpdateShareSettings', data);
}function MyZPRecordsCount(data) {
  return request.post("/v2/draws_result/userRecordsCount", data);
}function createZpRecord(data) {
  return request.post('/v2/draws_result/create', data);
}function checkMsg(_x) {
  return _checkMsg.apply(this, arguments);
}function _checkMsg() {
  _checkMsg = _asyncToGenerator2( /*#__PURE__*/_regeneratorRuntime2().mark(function _callee(msg) {
    var r;
    return _regeneratorRuntime2().wrap(function _callee$(_context) {
      while (1) switch (_context.prev = _context.next) {
        case 0:
          _context.prev = 0;
          _context.next = 3;
          return request.post('/v2/checkMsg', {
            msg: msg
          });
        case 3:
          r = _context.sent;
          if (!(r.code === 0 && r.data.result.suggest === 'pass')) {
            _context.next = 6;
            break;
          }
          return _context.abrupt("return", true);
        case 6:
          _context.next = 10;
          break;
        case 8:
          _context.prev = 8;
          _context.t0 = _context["catch"](0);
        case 10:
          return _context.abrupt("return", false);
        case 11:
        case "end":
          return _context.stop();
      }
    }, _callee, null, [[0, 8]]);
  }));
  return _checkMsg.apply(this, arguments);
}function copy(_x2) {
  return _copy.apply(this, arguments);
}function _copy() {
  _copy = _asyncToGenerator2( /*#__PURE__*/_regeneratorRuntime2().mark(function _callee2(id) {
    return _regeneratorRuntime2().wrap(function _callee2$(_context2) {
      while (1) switch (_context2.prev = _context2.next) {
        case 0:
          return _context2.abrupt("return", request.post('/v2/draws/copy', {
            id: id
          }));
        case 1:
        case "end":
          return _context2.stop();
      }
    }, _callee2);
  }));
  return _copy.apply(this, arguments);
}function MyZPRecords(data) {
  return request.post('/v2/draws_result/userRecords', data);
}function allRecords(data) {
  return request.post('/v2/draws_result/all', data);
}function delRecord(data) {
  return request.post('/v2/draws_result/deleteOneById', data);
}function loadTemplates(data) {
  return request.post('/templates/list', data);
}function getTemplateById(id) {
  return request.post('/templates/getOne', {
    id: id
  });
}function addToHot(id) {
  return request.post('/templates/storeByDrawId', {
    drawId: id
  });
}module.exports = {
  list: list,
  findOneById: findOneById,
  deleteOneById: deleteOneById,
  updateOne: updateOne,
  checkMsg: checkMsg,
  copy: copy,
  createZpRecord: createZpRecord,
  MyZPRecordsCount: MyZPRecordsCount,
  MyZPRecords: MyZPRecords,
  allRecords: allRecords,
  delRecord: delRecord,
  UpdateShareSettings: UpdateShareSettings,
  loadTemplates: loadTemplates,
  addToHot: addToHot,
  getTemplateById: getTemplateById
};