var _objectSpread2 = require("../@babel/runtime/helpers/objectSpread2");var colors = require("./zp_colors");var all_zps = {
  template_index000: {
    id: "template_index000",
    title: "自定义转盘",
    icon: "sjzp-shouye",
    items: ["选项1", "选项2", "选项3"],
    top_c: "template",
    sub_c: "自定义转盘"
  },
  template_index001: {
    id: "template_index001",
    title: "选人转盘",
    icon: "sjzp-shouye2",
    items: ['小美', '阿强', '小明'],
    top_c: "template",
    sub_c: "选人转盘"
  },
  template_index002: {
    id: "template_index002",
    title: "选数字转盘",
    icon: "sjzp-suijishushengcheng",
    items: ['1', '2', '3', '4', '5', '6'],
    top_c: "template",
    sub_c: "选数字转盘"
  },
  template_index003: {
    id: "template_index003",
    title: "吃什么转盘",
    icon: "sjzp-icon-",
    items: ["火锅 🍲", "水饺 🥟", "🍜 面条", "酸辣粉", "重庆小面", "🍗 🍔  炸鸡汉堡", "麻辣烫", "川菜  🌶️"],
    top_c: "template",
    sub_c: "吃什么转盘"
  },
  template_index005: {
    id: "template_index005",
    title: "大冒险转盘",
    icon: "sjzp-xiaolian",
    items: ["发朋友圈丑照", "唱一首歌", "模仿猪叫", "跳个舞", "蹲起15个", "模仿小狗叫", "原地转5圈", "再转一次", "模仿五种动物的声音"],
    top_c: "template",
    sub_c: "大冒险转盘"
  },
  template_index004: {
    id: "template_index004",
    title: "真心话大冒险",
    icon: "sjzp-xiaolian",
    items: ["真心话", "跳过", "大冒险", "再转一次"],
    top_c: "template",
    sub_c: "真心话大冒险"
  },
  template_index006: {
    id: "template_index006",
    title: "玩什么转盘",
    icon: "sjzp-shoubing",
    items: ["和平精英🐔", "不玩了，我爱学习📖", "看电影", "玩小游戏", "王者荣耀", "刷抖音"],
    top_c: "template",
    sub_c: "玩什么转盘"
  },
  template_index007: {
    id: "template_index007",
    title: "去哪玩转盘",
    icon: "sjzp-chuchalvyouchuxing",
    items: ["西安", "长沙", "南京", "秦皇岛", "北京", "哈尔滨", "河北", "深圳"]
  },
  template_index008: {
    id: "template_index008",
    title: "大冒险转盘",
    icon: "sjzp-wanle",
    items: ["背一首古诗", "做鬼脸", "绕口令：我爸是我爸我爸儿是我我是我爸儿", "打自己一下", "模仿五种动物的声音", "大笑五秒再大哭五秒，然后说：我该吃药了", "双手握拳高举说：我是超人，我要回家了", "唱一首歌", "模仿猪叫", "对你身边的人三秒咧嘴直到他笑为止", "跳个舞", "蹲起15个", "模仿小狗叫", "原地转5圈", "再转一次", "打开抖音模仿推荐的第一个人", "和椅子吵架", "走模特步回眸一笑", "平板撑15秒"]
  },
  template_index009: {
    id: "template_index009",
    title: "真心话转盘",
    icon: "sjzp-shouye1",
    items: ["说一个你不敢告诉爸妈的事", "你最喜欢哪三种颜色", "如果你知道有人暗恋你你会怎么做", "对未来的男（女）朋友说一句话吧", "如果有来生，你选择当？", "从在座的选一个人作为对象你会选谁？", "你会选择爱你的人还是你爱的人？", "一见钟情和日久生情你更喜欢哪一个？", "你想做但一直没做的事是什么？", "你最受不了别人对你做什么？", "你选男朋友首先看中什么", "在座的各位你看哪位异性最舒服", "你最喜欢的小说是什么？", "你希望你现在是多少岁？", "近一个星期让你最开心的事", "最反感别人的什么行为？", "你最想从头来过的一件事是什么？", "你最想养的宠物是什么？", "收到过最难忘的礼物是什么？", "目前为止，你做过最疯狂的事是什么", "你会做饭吗", "如果从天而降99枚金币 你的第一反应是什么？", "走错过男女厕所吗？", "最喜欢哪部电影？", "让你拥有隐身的超能力5分钟，你会干什么？", "上次哭是什么时候？", "做过最浪漫的事是什么？"]
  },
  template_gailv: {
    id: "template_gailv",
    title: "有概率的转盘",
    icon: "sjzp-shouye",
    from: "hot",
    items: ['A 20%', 'B 10%', 'C 30%', 'D 15%', 'E 5%', 'F 20%'],
    items_obj: ['A 20% 概率', 'B 10% 概率', 'C 20% 概率', 'D 15% 概率', 'E 5% 概率', 'F 30% 概率'].map(function (item, index) {
      return {
        text: item,
        weight: [20, 10, 20, 15, 5, 30][index],
        id: index,
        color: colors[index % colors.length]
      };
    })
  },
  template_zidingyi: {
    // randomId
    id: "template_zidingyi",
    from: "hot",
    title: "☝️ 自定义转盘",
    items: fillItems(["选项1", "选项2"])
  },
  template_number: {
    id: "template_number",
    from: "hot",
    title: "🔢 选数字转盘",
    items: fillItems(["1", "2", "3", "4", "5", "6", "7", "8", "9", "10"])
  },
  template_where_to_go: {
    id: "template_where_to_go",
    from: "hot",
    title: "🌍 去哪玩转盘",
    items: fillItems(["西安", "长沙", "南京", "秦皇岛", "北京", "哈尔滨", "河北", "深圳"])
  },
  template_eat: {
    id: "template_eat",
    from: "hot",
    title: "🍚 吃什么转盘",
    items: fillItems(["火锅🍲", "水饺🥟", "🍜面条", "酸辣粉", "重庆小面", "🍗 🍔 炸鸡汉堡", "麻辣烫", "川菜 🌶️"])
  },
  template_who_buy: {
    id: "template_who_buy",
    from: "hot",
    title: "💰 谁买单转盘",
    items: fillItems(["头发最长的", "最瘦的", "头发最短的", "手机电量最多的", "最高的", "最矮的", "年龄最小的", "年龄最大的"])
  },
  template_zhenxinghuaanddamaoxian: {
    id: "template_damaoxian",
    from: "hot",
    title: "❓ 真心话&大冒险",
    items: fillItems(["真心话", "大冒险", "真心话", "大冒险", "再转一次"])
  },
  template_wangzhe_hero: {
    id: "template_wangzhe_hero",
    from: "hot",
    title: "王者荣耀玩什么英雄🤔",
    items: fillItems(["公孙离", "鲁班七号", "娜可露露", "曜", "西施", "杨玉环", "小乔", "李白", "貂蝉", "嫦娥", "猴子"])
  },
  template_eat_breakfast: {
    id: "template_eat_breakfast",
    from: "hot",
    title: "🥣 吃什么早餐",
    items: fillItems(["豆浆", "油条", "包子", "馒头", "面条", "鸡蛋", "煎饼果子"])
  },
  template_damaoxian: {
    id: "template_damaoxian",
    from: "hot",
    title: "👍 大冒险转盘",
    items: fillItems(["做鬼脸", "绕口令：我爸是我爸我爸儿是我我是我爸儿", "模仿五种动物的声音", "大笑五秒再大哭五秒，然后说：我该吃药了", "双手握拳高举说：我是超人，我要回家了", "唱一首歌", "模仿猪叫", "对你身边的人三秒咧嘴直到他笑为止", "跳个舞", "蹲起15个", "模仿小狗叫", "原地转5圈", "再转一次", "打开抖音模仿推荐的第一个人", "和椅子吵架", "走模特步回眸一笑", "平板撑15秒"])
  },
  template_zhenxinhua: {
    id: "template_zhenxinhua",
    from: "hot",
    title: "👂 真心话转盘",
    items: fillItems(["说一个你不敢告诉爸妈的事", "你最喜欢哪三种颜色", "如果你知道有人暗恋你你会怎么做", "对未来的男（女）朋友说一句话吧", "如果有来生，你选择当？", "从在座的选一个人作为对象你会选谁？", "你会选择爱你的人还是你爱的人？", "一见钟情和日久生情你更喜欢哪一个？", "你想做但一直没做的事是什么？", "你最受不了别人对你做什么？", "你选男朋友首先看中什么", "在座的各位你看哪位异性最舒服", "你最喜欢的小说是什么？", "你希望你现在是多少岁？", "近一个星期让你最开心的事", "最反感别人的什么行为？", "你最想从头来过的一件事是什么？", "你最想养的宠物是什么？", "收到过最难忘的礼物是什么？", "目前为止，你做过最疯狂的事是什么", "你会做饭吗", "如果从天而降99枚金币 你的第一反应是什么？", "走错过男女厕所吗？", "最喜欢哪部电影？", "让你拥有隐身的超能力5分钟，你会干什么？", "上次哭是什么时候？", "做过最浪漫的事是什么？"])
  },
  "template_gift_to_gf": {
    id: "template_gift_to_gf",
    icon: "sjzp-liwu1",
    title: "七夕礼物-女",
    items: ["鲜花 🌹", "吹风机", "一包辣条", "香水", "口红💄", "鞋", "玩偶", "巧克力", "耳机🎧", "王者荣耀皮肤", "电动牙刷", "保温杯", "手机壳", "电纸书", "糖果🍬", "零食大礼包"]
  },
  "template_gift_to_bf": {
    id: "template_gift_to_bf",
    icon: "sjzp-liwu1",
    title: "七夕礼物-男",
    items: ["一包辣条", "秋天的第一根金条", "保温杯", "枸杞", "鞋", "衣服", "手机壳", "打火机", "王者荣耀皮肤", "电动牙刷", "电动剃须刀", "洗面奶", "双肩包", "游戏机", "手环/手表", "鼠标", "键盘", "RTX 4090显卡", "一款游戏", "男德经", "情侣T恤", "充电宝"]
  },
  "template_empty": {
    id: "template_empty",
    from: "hot",
    title: "😄 我的转盘",
    items: ['', '']
  }
};function fillItems(items) {
  return items;
}module.exports = {
  all_zps: all_zps,
  default: _objectSpread2(_objectSpread2({}, all_zps.template_lianxisheng), {}, {
    title: "点击选择转盘"
  }),
  hot: [all_zps.template_zidingyi, all_zps.template_eat_breakfast, all_zps.template_damaoxian, all_zps.template_zhenxinhua, all_zps.template_zhenxinghuaanddamaoxian, all_zps.template_number, all_zps.template_where_to_go, all_zps.template_eat, all_zps.template_who_buy, all_zps.template_wangzhe_hero],
  index: [all_zps.template_index000, all_zps.template_index003, all_zps.template_index006, all_zps.template_index007, all_zps.template_index002, all_zps.template_index001, all_zps.template_index004, all_zps.template_index008, all_zps.template_index009, all_zps.template_gailv]
};function initZpItemsObj(zpInfo) {
  var items = zpInfo.items;
  if (!zpInfo.items_obj) {
    zpInfo.items_obj = items.map(function (item, index) {
      return {
        text: item,
        weight: 1,
        id: index,
        color: colors[index % colors.length]
      };
    });
  }
}module.exports.initZpItemsObj = initZpItemsObj;module.exports.getTemplateZpInfo = function () {
  var id = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : "template_empty";
  var zpInfo = all_zps[id];
  if (!zpInfo) {
    zpInfo = all_zps.template_empty;
  }
  if (!zpInfo.items_obj) {
    initZpItemsObj(zpInfo);
  }
  return zpInfo;
};