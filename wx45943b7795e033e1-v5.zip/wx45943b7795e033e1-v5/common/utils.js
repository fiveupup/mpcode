function checkIsInBlack(item, blacks) {
  if (blacks.length === 0) return false;
  var black = blacks.find(function (black) {
    return black.index === item.index;
  });
  return !!black;
}module.exports = {
  checkIsInBlack: checkIsInBlack
};