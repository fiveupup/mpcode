module.exports = {
  "index": [{
    key: "turnable_index000",
    title: "自定义转盘",
    icon: "sjzp-shouye",
    items: ["选项1", "选项2", "选项3"],
    top_c: "template",
    sub_c: "自定义转盘"
  }, {
    key: "turnable_index001",
    title: "选人转盘",
    icon: "sjzp-duoren-renqun",
    items: ['张三', '李四', '王五'],
    top_c: "template",
    sub_c: "选人转盘"
  }, {
    key: "turnable_index002",
    title: "选数字转盘",
    icon: "sjzp-shuzi6",
    items: ['1', '2', '3', '4', '5', '6'],
    top_c: "template",
    sub_c: "选数字转盘"
  }, {
    key: "turnable_index003",
    title: "吃什么转盘",
    icon: "sjzp-naichaxiaochi",
    items: ["米饭", "面", "火锅", "川菜", "鸡公煲"],
    top_c: "template",
    sub_c: "吃什么转盘"
  }, {
    key: "turnable_index005",
    title: "大冒险转盘",
    icon: "sjzp-xiaolian",
    items: ["发朋友圈丑照", "唱一首歌", "模仿猪叫", "跳个舞", "蹲起15个", "模仿小狗叫", "原地转5圈", "再转一次", "平板撑15秒"],
    top_c: "template",
    sub_c: "大冒险转盘"
  }, {
    key: "turnable_index004",
    title: "真心话大冒险",
    icon: "sjzp-xiaolian",
    items: ["真心话", "跳过", "大冒险", "再转一次"],
    top_c: "template",
    sub_c: "真心话大冒险"
  }, {
    key: "turnable_index006",
    title: "玩什么转盘",
    icon: "sjzp-wanjuquan",
    items: ["公园", "电影院", "逛商场", "王者荣耀", "找朋友玩"],
    top_c: "template",
    sub_c: "玩什么转盘"
  }],
  initNewItem: function initNewItem(key) {
    return {
      title: "默认转盘",
      icon: "sjzp-shouye",
      items: ["选项1", "选项2", "选项3"],
      key: key,
      top_c: "template",
      sub_c: "默认转盘"
    };
  }
};