var _createForOfIteratorHelper2 = require("@babel/runtime/helpers/createForOfIteratorHelper");var _objectSpread2 = require("@babel/runtime/helpers/objectSpread2");var _regeneratorRuntime2 = require("@babel/runtime/helpers/regeneratorRuntime");var _asyncToGenerator2 = require("@babel/runtime/helpers/asyncToGenerator");var _require = require("./utils/requests"),
  login = _require.login;var _require2 = require("./common/apis/tools"),
  _getUser = _require2.getUser;var bus = require("./utils/bus");var utils = require("./utils/utils");App({
  onLaunch: function onLaunch(options) {
    var _this = this;
    return _asyncToGenerator2( /*#__PURE__*/_regeneratorRuntime2().mark(function _callee() {
      var scene, _options$query, top_c, sub_c;
      return _regeneratorRuntime2().wrap(function _callee$(_context) {
        while (1) switch (_context.prev = _context.next) {
          case 0:
            console.log("启动参数", options);
            scene = options.scene;
            if (options.query) {
              _options$query = options.query, top_c = _options$query.top_c, sub_c = _options$query.sub_c;
              _this.globalData.top_c = top_c;
              _this.globalData.sub_c = sub_c;
            }
            _this.globalData.scene = scene;
            _this.globalData.deviceInfo = wx.getSystemInfoSync();
            utils.loadConfig();
          case 6:
          case "end":
            return _context.stop();
        }
      }, _callee);
    }))();
  },
  globalData: {
    userInfo: null,
    settings: {}
  },
  initLogin: function initLogin() {
    var _this2 = this;
    return _asyncToGenerator2( /*#__PURE__*/_regeneratorRuntime2().mark(function _callee2() {
      return _regeneratorRuntime2().wrap(function _callee2$(_context2) {
        while (1) switch (_context2.prev = _context2.next) {
          case 0:
            console.log("--登录--");
            _context2.prev = 1;
            if (wx.getStorageSync("token")) {
              _context2.next = 7;
              break;
            }
            console.log("用户未登录");
            return _context2.abrupt("return", _this2.wxLogin());
          case 7:
            _this2.globalData.userInfo = wx.getStorageSync("userInfo");
            _this2.globalData.openid = wx.getStorageSync("openid");
            return _context2.abrupt("return", true);
          case 10:
            _context2.next = 16;
            break;
          case 12:
            _context2.prev = 12;
            _context2.t0 = _context2["catch"](1);
            console.log("检查登录异常了");
            return _context2.abrupt("return", false);
          case 16:
          case "end":
            return _context2.stop();
        }
      }, _callee2, null, [[1, 12]]);
    }))();
  },
  wxLogin: function wxLogin() {
    var _this3 = this;
    var _this$globalData$devi = this.globalData.deviceInfo,
      brand = _this$globalData$devi.brand,
      system = _this$globalData$devi.system,
      platform = _this$globalData$devi.platform,
      version = _this$globalData$devi.version,
      model = _this$globalData$devi.model;
    var userInfo = {
      scene: this.globalData.scene,
      sub_c: this.globalData.sub_c,
      top_c: this.globalData.top_c,
      brand: brand,
      system: system,
      platform: platform,
      model: model,
      version: version
    };
    return new Promise(function (resolve, reject) {
      wx.login({
        success: function () {
          var _success = _asyncToGenerator2( /*#__PURE__*/_regeneratorRuntime2().mark(function _callee3(res) {
            var code, r, _r$data, openid, token, user;
            return _regeneratorRuntime2().wrap(function _callee3$(_context3) {
              while (1) switch (_context3.prev = _context3.next) {
                case 0:
                  code = res.code;
                  _context3.next = 3;
                  return login(_objectSpread2({
                    code: code
                  }, userInfo));
                case 3:
                  r = _context3.sent;
                  if (r.code == 0) {
                    console.log("登录成功", r);
                    _r$data = r.data, openid = _r$data.openid, token = _r$data.token, user = _r$data.user;
                    _this3.globalData.userInfo = user;
                    _this3.globalData.openid = openid;
                    wx.setStorageSync("token", token);
                    wx.setStorageSync("openid", openid);
                    wx.setStorageSync("userInfo", user);
                    resolve(true);
                  } else {
                    console.log("登录失败", r);
                    reject(false);
                  }
                case 5:
                case "end":
                  return _context3.stop();
              }
            }, _callee3);
          }));
          function success(_x) {
            return _success.apply(this, arguments);
          }
          return success;
        }()
      });
    });
  },
  getUser: function getUser() {
    var _this4 = this;
    return _asyncToGenerator2( /*#__PURE__*/_regeneratorRuntime2().mark(function _callee4() {
      var userInfo, res;
      return _regeneratorRuntime2().wrap(function _callee4$(_context4) {
        while (1) switch (_context4.prev = _context4.next) {
          case 0:
            if (!_this4.globalData.userInfo) {
              _context4.next = 2;
              break;
            }
            return _context4.abrupt("return", _this4.globalData.userInfo);
          case 2:
            userInfo = wx.getStorageSync("userInfo");
            if (!userInfo) {
              _context4.next = 6;
              break;
            }
            _this4.globalData.userInfo = userInfo;
            return _context4.abrupt("return", userInfo);
          case 6:
            _context4.next = 8;
            return _getUser();
          case 8:
            res = _context4.sent;
            if (!(res.code === 0)) {
              _context4.next = 15;
              break;
            }
            _this4.globalData.userInfo = res.data;
            wx.setStorageSync("userInfo", res.data);
            return _context4.abrupt("return", res.data);
          case 15:
            return _context4.abrupt("return", null);
          case 16:
          case "end":
            return _context4.stop();
        }
      }, _callee4);
    }))();
  },
  getAd: function getAd() {},
  getSettings: function getSettings() {},
  pushLog: function pushLog() {
    console.log("开始上传埋点");
    var logs = wx.getStorageSync("logs") || [];
    var openid = wx.getStorageSync("openid");
    var unionid = wx.getStorageSync("unionid");
    var _wx$getAccountInfoSyn = wx.getAccountInfoSync(),
      miniProgram = _wx$getAccountInfoSyn.miniProgram;
    if (logs.length < 1) {
      return;
    }
    var _iterator = _createForOfIteratorHelper2(logs),
      _step;
    try {
      for (_iterator.s(); !(_step = _iterator.n()).done;) {
        var log = _step.value;
        log.openid = openid;
        log.unionid = unionid;
        log.appid = miniProgram.appId;
        log.version = miniProgram.version;
        log.scene = this.globalData.scene;
        log.top_c = this.globalData.top_c;
        log.sub_c = this.globalData.sub_c;
        if (this.globalData.userInfo) {
          log.ftop_c = this.globalData.userInfo.top_c;
          log.fsub_c = this.globalData.userInfo.sub_c;
        }
      }
    } catch (err) {
      _iterator.e(err);
    } finally {
      _iterator.f();
    }
    wx.request({
      url: 'https://a.jialidun.vip/logs',
      method: "POST",
      data: logs,
      success: function success(res) {
        console.log("上传埋点成功", res);
        wx.setStorageSync("logs", []);
      },
      fail: function fail(e) {
        console.log("上传埋点失败", e);
      }
    });
  },
  addEvent: function addEvent(log) {
    console.log("====addEvent 添加埋点====");
    console.log(log);
    console.log("========");
    try {
      var newLog = _objectSpread2({}, log);
      delete newLog.id;
      wx.reportEvent(log.id, newLog);
    } catch (e) {
      console.error("埋点异常", e);
    }
  },
  addLog: function addLog(log) {
    log.ts = new Date().toLocaleString();
    console.log("====addLog 添加埋点====");
    console.log(log);
    console.log("========");
    var logs = wx.getStorageSync("logs") || [];
    logs.push(log);
    wx.setStorageSync("logs", logs);
  },
  onHide: function onHide() {
    console.log("onHide");
    this.addLog({
      id: "onHide",
      duration: Date.now() - this.globalData.start_ts
    });
    this.pushLog();
  },
  onError: function onError(err) {
    console.log("onError", err);
    this.addLog({
      id: "onError",
      msg: err
    });
    this.pushLog();
  },
  loadMini: function loadMini() {
    console.log("加载半屏");
    if (!wx.openEmbeddedMiniProgram) {
      return;
    }
    if (!wx.getStorageSync("config").showMiniAd2) {
      return;
    }

    // 每天只展示一次滴滴
    var didiTs = wx.getStorageSync("didiTs");
    if (!didiTs || didiTs <= Date.now()) {
      this.addLog({
        id: "loadMiniAd",
        type: "didi"
      });
      var appid = "wxaf35009675aa0b2a";
      var appPath = "/pages/index/index?scene=w5R3QAd&source_id=1";
      wx.openEmbeddedMiniProgram({
        appId: appid,
        path: appPath
      });
      wx.setStorageSync("didiTs", new Date().setHours(0, 0, 0, 0) + 24 * 60 * 60 * 1000); // 一天
      return;
    }

    // let userInfo = wx.getStorageSync("userInfo")
    // if (userInfo && userInfo.vip_expired_at && new Date(userInfo.vip_expired_at).getTime() > Date.now()){
    //   console.log("vip用户")
    //   return;
    // }
    this.addLog({
      id: "loadMiniAd"
    });
    wx.openEmbeddedMiniProgram({
      appId: "wxece3a9a4c82f58c9",
      path: "commercialize/pages/taoke-guide/index?scene=2a9e24d62e544ddb9a6bcb9a119105d1"
    });
  }
});