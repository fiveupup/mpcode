var _require = require('gulp'),
  src = _require.src,
  dest = _require.dest;var GulpWechatWxs = require('gulp-wechat-wxs');function defaultTask(cb) {
  return src(["./components/**/*.wxml"]).pipe(GulpWechatWxs()).pipe(dest("./components"));
}exports.default = defaultTask;