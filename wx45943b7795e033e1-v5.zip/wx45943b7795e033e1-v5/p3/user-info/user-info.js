var _regeneratorRuntime2 = require("../../@babel/runtime/helpers/regeneratorRuntime");var _asyncToGenerator2 = require("../../@babel/runtime/helpers/asyncToGenerator");var _require = require("../../common/apis/tools"),
  getUploadToken = _require.getUploadToken,
  updateAvatar = _require.updateAvatar,
  updateUserInfo = _require.updateUserInfo;var app = getApp();Page({
  /**
   * 页面的初始数据
   */
  data: {
    userInfo: {}
  },
  showAvatar: function showAvatar() {
    var imgUrl = "http://pan.jialidun.vip/".concat(this.data.userInfo.wx_avatar, "?imageMogr2/thumbnail/500x");
    console.log("imgUrl", imgUrl);
    wx.previewImage({
      urls: [imgUrl]
    });
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function onLoad(options) {
    this.getUserInfo();
  },
  onChooseAvatar: function onChooseAvatar(e) {
    var _this = this;
    return _asyncToGenerator2( /*#__PURE__*/_regeneratorRuntime2().mark(function _callee2() {
      var avatarUrl, fileId, fileName, res;
      return _regeneratorRuntime2().wrap(function _callee2$(_context2) {
        while (1) switch (_context2.prev = _context2.next) {
          case 0:
            avatarUrl = e.detail.avatarUrl; // 随机id名字
            fileId = Math.random().toString(36).substr(2);
            fileName = "avatars/".concat(fileId, ".png");
            _context2.next = 5;
            return getUploadToken({
              key: fileName
            });
          case 5:
            res = _context2.sent;
            wx.uploadFile({
              url: 'https://upload-z1.qiniup.com',
              filePath: avatarUrl,
              name: 'file',
              formData: {
                key: fileName,
                token: res.data
              },
              success: function () {
                var _success = _asyncToGenerator2( /*#__PURE__*/_regeneratorRuntime2().mark(function _callee() {
                  var res;
                  return _regeneratorRuntime2().wrap(function _callee$(_context) {
                    while (1) switch (_context.prev = _context.next) {
                      case 0:
                        console.log("上传成功", res);
                        _context.next = 3;
                        return updateAvatar({
                          avatar: fileName
                        });
                      case 3:
                        res = _context.sent;
                        wx.showToast({
                          title: '头像修改成功'
                        });
                        wx.removeStorageSync('userInfo');
                        app.globalData.userInfo = null;
                        _this.getUserInfo();
                      case 8:
                      case "end":
                        return _context.stop();
                    }
                  }, _callee);
                }));
                function success() {
                  return _success.apply(this, arguments);
                }
                return success;
              }(),
              fail: function fail(res) {
                console.log("上传失败", res);
              }
            });
          case 7:
          case "end":
            return _context2.stop();
        }
      }, _callee2);
    }))();
  },
  getUserInfo: function getUserInfo(e) {
    var _this2 = this;
    return _asyncToGenerator2( /*#__PURE__*/_regeneratorRuntime2().mark(function _callee3() {
      var userInfo;
      return _regeneratorRuntime2().wrap(function _callee3$(_context3) {
        while (1) switch (_context3.prev = _context3.next) {
          case 0:
            _context3.next = 2;
            return app.getUser();
          case 2:
            userInfo = _context3.sent;
            _this2.setData({
              userInfo: userInfo
            });
          case 4:
          case "end":
            return _context3.stop();
        }
      }, _callee3);
    }))();
  },
  onInputChange: function onInputChange(e) {
    var _this3 = this;
    return _asyncToGenerator2( /*#__PURE__*/_regeneratorRuntime2().mark(function _callee4() {
      var value, r;
      return _regeneratorRuntime2().wrap(function _callee4$(_context4) {
        while (1) switch (_context4.prev = _context4.next) {
          case 0:
            value = e.detail.value;
            console.log(value);
            if (!(value === _this3.data.userInfo.wx_name)) {
              _context4.next = 4;
              break;
            }
            return _context4.abrupt("return");
          case 4:
            _context4.next = 6;
            return updateUserInfo({
              wx_name: value
            });
          case 6:
            r = _context4.sent;
            if (r.code === 0) {
              wx.showToast({
                title: '修改成功'
              });
              wx.removeStorageSync('userInfo');
              app.globalData.userInfo = null;
              _this3.getUserInfo();
            }
          case 8:
          case "end":
            return _context4.stop();
        }
      }, _callee4);
    }))();
  }
});