var _defineProperty2 = require("../../../@babel/runtime/helpers/defineProperty");module.exports = Behavior({
  behaviors: [wx.Bus],
  properties: {},
  lifetimes: {
    attached: function attached() {
      var _this = this;
      this.$bus.event.export("page:setColor", function (_ref) {
        var color = _ref.color,
          index = _ref.index;
        _this.setData(_defineProperty2({}, "zp_info.items_obj[".concat(index, "].color"), color));
      });
      this.$bus.on('loading:hide', function (_ref2) {
        var status = _ref2.status;
        if (status === 1) {
          wx.navigateBack();
        }
      });
    }
  }
});