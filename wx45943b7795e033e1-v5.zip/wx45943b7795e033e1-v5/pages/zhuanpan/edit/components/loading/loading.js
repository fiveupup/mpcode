Component({
  behaviors: [wx.Bus],
  data: {
    show: false,
    text: '',
    status: 0,
    ad: "adunit-5a63853e89fdbca5"
  },
  methods: {
    onHide: function onHide() {
      this.setData({
        show: false
      });
      this.$bus.emit("loading:hide", {
        status: this.data.status
      });
    },
    redo: function redo() {
      this.setData({
        show: false
      });
    }
  },
  lifetimes: {
    attached: function attached() {
      var _this = this;
      this.$bus.event.export("loading:show", function () {
        _this.setData({
          show: true
        });
      });
      this.$bus.event.export("loading:setText", function (_ref) {
        var text = _ref.text,
          status = _ref.status;
        _this.setData({
          text: text,
          status: status
        });
      });
    }
  }
});