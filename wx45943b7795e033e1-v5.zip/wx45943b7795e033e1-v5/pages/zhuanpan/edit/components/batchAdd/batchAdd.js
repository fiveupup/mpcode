Component({
  behaviors: [wx.Bus],
  properties: {
    show: {
      type: Boolean
    }
  },
  data: {
    line: 0,
    rows: [],
    text: ""
  },
  methods: {
    textChange: function textChange(e) {
      var rows = e.detail.value.split("\n");
      var line = rows.length;
      if (rows[rows.length - 1] === "") {
        line = line - 1;
        rows.pop();
      }
      this.setData({
        line: line,
        rows: rows
      });
    },
    batchAdd: function batchAdd(e) {
      var rows = this.data.rows;
      this.triggerEvent("batchAdd", {
        rows: rows
      });
      this.setData({
        show: false,
        text: ""
      });
    },
    cancel: function cancel() {
      this.setData({
        show: false
      });
    }
  },
  lifetimes: {
    attached: function attached() {
      var _this = this;
      this.$bus.event.export("batchAdd:show", function (data) {
        _this.setData({
          show: true
        });
      });
    }
  }
});