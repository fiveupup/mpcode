require("../../../../../@babel/runtime/helpers/Objectvalues");var zp_colors = require("../../../../../common/zp_colors");Component({
  behaviors: [wx.Bus],
  properties: {},
  data: {
    showColors: false
  },
  methods: {
    closeSetting: function closeSetting() {
      this.setData({
        showColors: false
      });
    },
    initColorsMap: function initColorsMap() {
      var colors_map = {};
      for (var i = 0; i < zp_colors.length; i++) {
        colors_map[zp_colors[i]] = {
          color: zp_colors[i],
          selected: false,
          checked: false,
          index: i
        };
      }
      this.setData({
        colors_map: colors_map
      });
      this.$bus.store.set("colors_map", colors_map);
    },
    selectColor: function selectColor(e) {
      var color = e.currentTarget.dataset.color;
      this.setData({
        showColors: false
      });
      this.$bus.event.call("page:setColor", {
        color: color,
        index: this.$bus.store.get('current_zp_item_index')
      });
    }
  },
  lifetimes: {
    attached: function attached() {
      var _this = this;
      this.$bus.event.export("colors:showColors", function (_ref) {
        var index = _ref.index,
          selectedColor = _ref.selectedColor;
        _this.$bus.store.set('current_zp_item_index', index);
        Object.values(_this.data.colors_map).forEach(function (color) {
          color.checked = false;
          color.selected = false;
        });
        var currentColor = selectedColor[index];
        if (currentColor && _this.data.colors_map[currentColor]) {
          _this.data.colors_map[currentColor].selected = true;
        }
        selectedColor.forEach(function (color) {
          var checkColor = _this.data.colors_map[color];
          checkColor && (checkColor.checked = true);
        });
        _this.setData({
          showColors: true,
          colors_map: _this.data.colors_map
        });
      });
      this.initColorsMap();
    }
  }
});