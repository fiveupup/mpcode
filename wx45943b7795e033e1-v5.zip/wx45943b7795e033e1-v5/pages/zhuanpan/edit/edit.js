var _createForOfIteratorHelper2 = require("../../../@babel/runtime/helpers/createForOfIteratorHelper");var _defineProperty2 = require("../../../@babel/runtime/helpers/defineProperty");var _regeneratorRuntime2 = require("../../../@babel/runtime/helpers/regeneratorRuntime");var _asyncToGenerator2 = require("../../../@babel/runtime/helpers/asyncToGenerator");var _require = require("../../../common/zps"),
  getTemplateZpInfo = _require.getTemplateZpInfo,
  empty_zp = _require.empty_zp;var zp_colors = require("../../../common/zp_colors");var editBus = require("./edit_bus");var ZhuanpanApi = require("../../../common/apis/zhuanpan");var app = getApp();Page({
  behaviors: [wx.Bus, editBus],
  /**
   * 页面的初始数据
   */
  data: {
    zp_info: {},
    focus: false,
    showSetting: false,
    hideWeight: false
  },
  checkHideWeight: function checkHideWeight() {
    var hasWeightNot1 = this.data.zp_info.items_obj.some(function (item) {
      return item.weight !== 1;
    });
    console.log("hasWeightNot1", hasWeightNot1);
    if (hasWeightNot1) {
      this.setData({
        hideWeight: true
      });
    } else {
      this.setData({
        hideWeight: false
      });
    }
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function () {
    var _onLoad = _asyncToGenerator2( /*#__PURE__*/_regeneratorRuntime2().mark(function _callee(options) {
      var zp_id, zp_info, data;
      return _regeneratorRuntime2().wrap(function _callee$(_context) {
        while (1) switch (_context.prev = _context.next) {
          case 0:
            if (!(options.type === "add")) {
              _context.next = 8;
              break;
            }
            this.setData({
              zp_info: JSON.parse(JSON.stringify(getTemplateZpInfo()))
            });
            wx.setNavigationBarTitle({
              title: '创建转盘'
            });
            this.createType = "add";
            app.addLog({
              id: "进入编辑",
              title: this.data.zp_info.title,
              type: "创建转盘"
            });
            this.top_c = "创建新的";
            this.sub_c = "空白转盘";
            return _context.abrupt("return");
          case 8:
            zp_id = options.id;
            if (!zp_id.startsWith("template_")) {
              _context.next = 23;
              break;
            }
            zp_info = getTemplateZpInfo(zp_id);
            if (!zp_id.startsWith("template_server_")) {
              _context.next = 16;
              break;
            }
            _context.next = 14;
            return ZhuanpanApi.getTemplateById(zp_id);
          case 14:
            data = _context.sent;
            if (data.code === 0) {
              zp_info = data.data;
            } else {
              wx.showToast({
                title: "加载模板失败",
                icon: "none"
              });
            }
          case 16:
            this.setData({
              zp_info: zp_info
            });
            app.addLog({
              id: "进入编辑",
              title: this.data.zp_info.title,
              type: "编辑转盘",
              p1: "系统模板"
            });
            this.top_c = "系统模板";
            this.sub_c = this.data.zp_info.title;
            this.checkHideWeight();
            _context.next = 24;
            break;
          case 23:
            this.loadZpFromServer(zp_id);
          case 24:
            this.editStatus = 0; // 0:未编辑 1:编辑过 2:已保存
          case 25:
          case "end":
            return _context.stop();
        }
      }, _callee, this);
    }));
    function onLoad(_x) {
      return _onLoad.apply(this, arguments);
    }
    return onLoad;
  }(),
  loadZpFromServer: function loadZpFromServer(id) {
    var _this = this;
    return _asyncToGenerator2( /*#__PURE__*/_regeneratorRuntime2().mark(function _callee2() {
      var data, zp_info;
      return _regeneratorRuntime2().wrap(function _callee2$(_context2) {
        while (1) switch (_context2.prev = _context2.next) {
          case 0:
            wx.showLoading({
              title: "加载中..."
            });
            _context2.next = 3;
            return ZhuanpanApi.findOneById(id);
          case 3:
            data = _context2.sent;
            wx.hideLoading();
            if (data.code === 0) {
              zp_info = data.data;
              if (zp_info.openid !== app.globalData.openid) {
                wx.setNavigationBarTitle({
                  title: "创建转盘"
                });
              }
              _this.setData({
                zp_info: zp_info
              });
              app.addLog({
                id: "进入编辑",
                title: _this.data.zp_info.title,
                type: "编辑转盘",
                p1: "server"
              });
              _this.sub_c = _this.data.zp_info.title;
              _this.top_c = _this.data.zp_info.openid === app.globalData.openid ? '自己的转盘' : '别人的转盘';
            }
            _this.checkHideWeight();
          case 7:
          case "end":
            return _context2.stop();
        }
      }, _callee2);
    }))();
  },
  clearTitle: function clearTitle() {
    this.setData(_defineProperty2({}, "zp_info.title", ""));
  },
  delItem: function delItem(e) {
    var _this$setData2;
    console.log("e", e);
    if (this.data.zp_info.items_obj.length < 3) {
      wx.showToast({
        title: "至少保留两个选项呀",
        icon: "none"
      });
      return;
    }
    var index = e.currentTarget.dataset.index - 0;
    var zp_info = this.data.zp_info;
    zp_info.items_obj.splice(index, 1);
    this.setData((_this$setData2 = {}, _defineProperty2(_this$setData2, "zp_info.items_obj", zp_info.items_obj), _defineProperty2(_this$setData2, "focus", false), _this$setData2));
  },
  addNewItem: function addNewItem() {
    var _this$setData3;
    var nextColor = zp_colors[0];
    var zp_info = this.data.zp_info;
    if (zp_info.items_obj.length > 0) {
      var lastZpItem = zp_info.items_obj[zp_info.items_obj.length - 1];
      var lastZpItemColor = this.$bus.store.get("colors_map")[lastZpItem.color];
      var nextColorIndex = lastZpItemColor ? lastZpItemColor.index + 1 : 0;
      if (nextColorIndex && nextColorIndex < zp_colors.length) {
        nextColor = zp_colors[nextColorIndex];
      } else {
        nextColor = zp_colors[0];
      }
    }
    var len = this.data.zp_info.items_obj.length;
    // 生成5 位随机数
    var id = Math.random().toString(36).substr(2, 5);
    this.setData((_this$setData3 = {}, _defineProperty2(_this$setData3, "zp_info.items_obj[".concat(len, "]"), {
      id: id,
      text: "",
      color: nextColor,
      weight: 1
    }), _defineProperty2(_this$setData3, "focus", true), _this$setData3));
    this.checkHideWeight();
  },
  onEditOption: function onEditOption(e) {
    var _e$currentTarget$data = e.currentTarget.dataset,
      index = _e$currentTarget$data.index,
      type = _e$currentTarget$data.type;
    var value = e.detail.value;
    this.setData(_defineProperty2({}, "zp_info.items_obj[".concat(index, "].").concat(type), value));
    this.checkHideWeight();
  },
  onBlur: function onBlur(e) {
    var _e$currentTarget$data2 = e.currentTarget.dataset,
      index = _e$currentTarget$data2.index,
      type = _e$currentTarget$data2.type;
    var value = parseInt(e.detail.value);
    if (Number.isNaN(value) || value < 1) {
      var _this$setData5;
      this.setData((_this$setData5 = {}, _defineProperty2(_this$setData5, "zp_info.items_obj[".concat(index, "].").concat(type), 1), _defineProperty2(_this$setData5, "focus", false), _this$setData5));
    } else {
      var _this$setData6;
      this.setData((_this$setData6 = {}, _defineProperty2(_this$setData6, "zp_info.items_obj[".concat(index, "].").concat(type), value), _defineProperty2(_this$setData6, "focus", false), _this$setData6));
    }
  },
  optionMore: function optionMore(e) {
    var _this2 = this;
    var index = e.currentTarget.dataset.index;
    var zpItems = this.data.zp_info.items_obj;
    var item = zpItems[index];
    wx.showActionSheet({
      itemList: ["📋 复制", "👆 上移", "👇 下移"],
      success: function success(res) {
        switch (res.tapIndex) {
          case 0:
            var newItem = Object.assign({}, item);
            zpItems.splice(index + 1, 0, newItem);
            break;
          case 1:
            if (index === 0) {
              wx.showToast({
                title: "已经是第一个了",
                icon: "none"
              });
              return;
            }
            var temp = zpItems[index];
            zpItems[index] = zpItems[index - 1];
            zpItems[index - 1] = temp;
            break;
          case 2:
            if (index === zpItems.length - 1) {
              wx.showToast({
                title: "已经是最后一个了",
                icon: "none"
              });
              return;
            }
            var temp2 = zpItems[index];
            zpItems[index] = zpItems[index + 1];
            zpItems[index + 1] = temp2;
            break;
        }
        _this2.setData(_defineProperty2({}, "zp_info.items_obj", zpItems));
      }
    });
  },
  onChangeTitle: function onChangeTitle(e) {
    this.setData(_defineProperty2({}, "zp_info.title", e.detail.value));
    this.editStatus = 1;
  },
  onChangeSetting: function onChangeSetting(e) {
    var type = e.currentTarget.dataset.type;
    var value = e.detail;
    this.setData(_defineProperty2({}, "zp_info.settings.".concat(type), value));
  },
  onSelColor: function onSelColor(e) {
    // 选择颜色
    var index = e.currentTarget.dataset.index;
    var selectedColor = this.data.zp_info.items_obj.map(function (item) {
      return item.color;
    });
    this.$bus.event.call("colors:showColors", {
      index: index,
      selectedColor: selectedColor
    });
  },
  showSetting: function showSetting() {
    this.setData({
      showSetting: true
    });
  },
  saveZp: function saveZp() {
    var _this3 = this;
    return _asyncToGenerator2( /*#__PURE__*/_regeneratorRuntime2().mark(function _callee3() {
      var _this3$data$zp_info$s, _this3$data$zp_info$s2, _this3$data$zp_info$s3;
      var res;
      return _regeneratorRuntime2().wrap(function _callee3$(_context3) {
        while (1) switch (_context3.prev = _context3.next) {
          case 0:
            console.log("保存转盘");
            if (!(_this3.data.zp_info.items_obj.length < 2)) {
              _context3.next = 4;
              break;
            }
            wx.showToast({
              title: "至少两个选项才能保存",
              icon: "none"
            });
            return _context3.abrupt("return");
          case 4:
            _this3.$bus.event.call("loading:show", true);
            _this3.$bus.event.call("loading:setText", {
              text: "保存中...",
              status: 0
            });
            try {
              app.loadMini();
            } catch (e) {}
            console.log("即将保存转盘", _this3.data.zp_info);
            // todo: 埋点： 转盘名称
            _context3.prev = 8;
            _context3.next = 11;
            return ZhuanpanApi.updateOne(_this3.data.zp_info);
          case 11:
            res = _context3.sent;
            console.log(res);
            if (res.code === 0) {
              _this3.editStatus = 2;
              _this3.$bus.event.call("loading:setText", {
                text: "保存成功",
                status: 1
              });
              app.globalData.current_edit_zp = res.data;
              app.globalData._updateZpList = true;
              _this3.addEvent("ok", "保存成功");
            } else {
              _this3.$bus.event.call("loading:setText", {
                text: "保存失败",
                status: 2
              });
              _this3.addEvent("error", JSON.stringify(res));
            }
            _context3.next = 20;
            break;
          case 16:
            _context3.prev = 16;
            _context3.t0 = _context3["catch"](8);
            _this3.addEvent("error", JSON.stringify(_context3.t0));
            _this3.$bus.event.call("loading:setText", {
              text: JSON.stringify(_context3.t0),
              status: 2
            });
          case 20:
            app.addLog({
              id: "编辑转盘",
              title: _this3.data.zp_info.title,
              type: "保存成功",
              c1: _this3.data.zp_info.items_obj.length,
              c2: ((_this3$data$zp_info$s = _this3.data.zp_info.settings) === null || _this3$data$zp_info$s === void 0 ? void 0 : _this3$data$zp_info$s.seconds) || 5,
              p1: (_this3$data$zp_info$s2 = _this3.data.zp_info.settings) !== null && _this3$data$zp_info$s2 !== void 0 && _this3$data$zp_info$s2.no_repeat ? '不允许重复' : '允许重复',
              p2: (_this3$data$zp_info$s3 = _this3.data.zp_info.settings) !== null && _this3$data$zp_info$s3 !== void 0 && _this3$data$zp_info$s3.hide_weight ? '隐藏概率' : '不隐藏',
              top_c: _this3.top_c,
              sub_c: _this3.sub_c
            });
          case 21:
          case "end":
            return _context3.stop();
        }
      }, _callee3, null, [[8, 16]]);
    }))();
  },
  addEvent: function addEvent(status, msg) {
    app.addEvent({
      id: "save_zp",
      title: this.data.zp_info.title,
      status: status,
      msg: msg
    });
  },
  onBatchAdd: function onBatchAdd(e) {
    var rows = e.detail.rows;
    if (!rows || rows.length === 0) {
      return;
    }
    console.log("接收到批量添加事件", e.detail);
    var zp_info = this.data.zp_info;
    var _iterator = _createForOfIteratorHelper2(rows),
      _step;
    try {
      for (_iterator.s(); !(_step = _iterator.n()).done;) {
        var row = _step.value;
        var nextColor = zp_colors[0];
        if (zp_info.items_obj.length > 0) {
          var lastZpItem = zp_info.items_obj[zp_info.items_obj.length - 1];
          var nextColorIndex = this.$bus.store.get("colors_map")[lastZpItem.color].index + 1;
          if (nextColorIndex < zp_colors.length) {
            nextColor = zp_colors[nextColorIndex];
          } else {
            nextColor = zp_colors[0];
          }
        }
        this.data.zp_info.items_obj.push({
          id: Math.random().toString(36).substr(2, 5),
          text: row,
          color: nextColor,
          weight: 1
        });
      }
    } catch (err) {
      _iterator.e(err);
    } finally {
      _iterator.f();
    }
    this.setData(_defineProperty2({}, "zp_info.items_obj", this.data.zp_info.items_obj));
  },
  showBatchAdd: function showBatchAdd() {
    this.$bus.event.call("batchAdd:show", true);
  },
  onUnload: function onUnload() {
    // 退出前保存草稿，下次进来时检测，如果有草稿，并且这次编辑的转盘id和草稿的转盘id一致，则提示是否恢复草稿
    // let zp_info = this.data.zp_info
    // if (this.editStatus === 1 && zp_info.items.length > 0) {
    //     wx.setStorageSync("draft_zp", zp_info)
    //     wx.setStorageSync("draft_zp_ts", new Date().getTime())
    // }
  }
});