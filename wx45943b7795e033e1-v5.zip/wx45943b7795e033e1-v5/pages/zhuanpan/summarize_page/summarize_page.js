var _createForOfIteratorHelper2 = require("../../../@babel/runtime/helpers/createForOfIteratorHelper");Page({
  /**
   * 页面的初始数据
   */
  data: {
    black: [],
    rest: []
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function onLoad(options) {
    var _this = this;
    var eventChannel = this.getOpenerEventChannel();
    // 监听acceptDataFromOpenerPage事件，获取上一页面通过eventChannel传送到当前页面的数据
    eventChannel.on('getData', function (data) {
      _this.initData(data);
    });
  },
  initData: function initData(data) {
    var blackList = wx.getStorageSync(data.cacheKey) || [];
    var list = data.zpItems;
    console.log("initData", blackList, list);
    this.cacheKey = data.cacheKey;
    // 分出来两个数组： 一个是黑名单，一个是剩余的
    var black = [];
    var rest = [];
    var _iterator = _createForOfIteratorHelper2(blackList),
      _step;
    try {
      var _loop = function _loop() {
        var item = _step.value;
        var index = list.findIndex(function (it) {
          return it.id === item;
        });
        if (index !== -1) {
          black.push(list[index]);
          list.splice(index, 1);
        }
      };
      for (_iterator.s(); !(_step = _iterator.n()).done;) {
        _loop();
      }
    } catch (err) {
      _iterator.e(err);
    } finally {
      _iterator.f();
    }
    black = black.reverse();
    rest = list;
    this.setData({
      black: black,
      rest: rest
    });
  },
  handleDelete: function handleDelete(e) {
    var id = e.currentTarget.dataset.id;
    var black = this.data.black;
    var rest = this.data.rest;
    var index = black.findIndex(function (item) {
      return item.id === id;
    });
    var item = black.splice(index, 1)[0];
    rest.push(item);
    wx.setStorageSync(this.cacheKey, black.map(function (item) {
      return item.id;
    }));
    getApp().globalData._needupdateBlackList = true;
    this.setData({
      black: black,
      rest: rest
    });
  },
  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function onReady() {},
  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function onShow() {},
  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function onHide() {},
  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function onUnload() {},
  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function onPullDownRefresh() {},
  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function onReachBottom() {}
});