var _regeneratorRuntime2 = require("../../../@babel/runtime/helpers/regeneratorRuntime");var _asyncToGenerator2 = require("../../../@babel/runtime/helpers/asyncToGenerator");var ZhuanpanApi = require("../../../common/apis/zhuanpan");module.exports = Behavior({
  behaviors: [wx.Bus],
  properties: {},
  data: {},
  methods: {
    updateMain: function updateMain(zpInfo) {
      // 编辑了转盘名称，需要更新页面标题
      var currentPages = getCurrentPages();
      if (currentPages.length < 2) return;
      var prePage = currentPages[currentPages.length - 2];
      var list = prePage.data.list;
      var target = list.find(function (item) {
        return item.id === zpInfo.id;
      });
      if (!target) return;
      target.title = zpInfo.title;
      prePage.setData({
        list: list
      });
    },
    tapMore: function tapMore() {
      if (!this.checkZpIsReady()) {
        return;
      }
      this.$bus.event.call("more:showMore");
    },
    saveZp: function saveZp() {
      var _this = this;
      return _asyncToGenerator2( /*#__PURE__*/_regeneratorRuntime2().mark(function _callee() {
        var zpInfo, res;
        return _regeneratorRuntime2().wrap(function _callee$(_context) {
          while (1) switch (_context.prev = _context.next) {
            case 0:
              zpInfo = _this.$bus.get("zpInfo");
              _context.next = 3;
              return ZhuanpanApi.copy(zpInfo.id);
            case 3:
              res = _context.sent;
              if (res.code == 0) {
                wx.showToast({
                  title: "已保存到我的转盘",
                  icon: "none"
                });
                _this.initZp(res.data);
              }
            case 5:
            case "end":
              return _context.stop();
          }
        }, _callee);
      }))();
    },
    showSaveZp: function showSaveZp() {
      var _this2 = this;
      wx.showModal({
        title: "提示",
        content: "保存后，你可以自由编辑当前转盘，在首页【我的转盘】可以找到当前转盘",
        confirm: "保存",
        cancel: "取消",
        success: function success(res) {
          if (res.confirm) {
            _this2.saveZp();
          }
        }
      });
    },
    tapEdit: function tapEdit() {
      // if (!this.checkZpIsReady()) {
      //     return
      // }
      // this.$bus.event.call("edit:showEdit", {
      //     zpInfo: this.$bus.store.get("zpInfo")
      // })

      wx.navigateTo({
        url: "/pages/zhuanpan/edit/edit?type=edit&id=".concat(this.$bus.store.get("zpInfo").id)
      });
    }
  },
  lifetimes: {
    attached: function attached() {
      var _this3 = this;
      this.$bus.event.on("edit:saveSuccess", function (_ref) {
        var zpInfo = _ref.zpInfo;
        if (zpInfo.title !== _this3.$bus.store.get("zpInfo").title) {
          wx.nextTick(function () {
            _this3.updateMain(zpInfo);
          });
        }
        _this3.initZp(zpInfo);
      });
      this.$bus.event.on("zhuanpan:start", function () {
        _this3.setData({
          zpState: 2
        });
      });
      this.$bus.event.on("zhuanpan:stop", function (data) {
        _this3.setData({
          zpState: 1
        });
      });
      this.$bus.event.export("page:updateRecordsTimes", function () {
        var zpInfo = _this3.$bus.get("zpInfo");
        _this3.getZPRecordsTimes(zpInfo);
      });
    }
  }
});