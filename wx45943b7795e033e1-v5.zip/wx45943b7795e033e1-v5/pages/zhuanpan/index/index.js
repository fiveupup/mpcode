var _regeneratorRuntime2 = require("../../../@babel/runtime/helpers/regeneratorRuntime");var _asyncToGenerator2 = require("../../../@babel/runtime/helpers/asyncToGenerator");var app = getApp();var zps = require("../../../common/zps");var Zhuanpan = require('../../../common/apis/zhuanpan');var Base = require("./base");Page({
  behaviors: [wx.Bus, Base],
  data: {
    zpState: 0,
    zpLoad: false,
    isTemplate: false,
    isMineZp: true,
    share_type: 0,
    shouldSaveResult: false,
    share_settings: {},
    have_join_times: 0
  },
  moreShare: function moreShare() {
    var _this = this;
    var zpInfo = this.$bus.store.get('zpInfo');
    if (!zpInfo.openid || zpInfo.openid !== app.globalData.openid) {
      return {};
    }
    return new Promise(function (resolve) {
      wx.showActionSheet({
        itemList: ['分享当前转盘方案', '邀请别人参与此转盘'],
        // 查看转盘记录
        success: function success(res) {
          if (res.tapIndex === 0) {
            return resolve({
              title: zpInfo.title,
              path: "/pages/zhuanpan/index/index?type=share&id=".concat(zpInfo.id, "&top_c=\u5206\u4EAB\u8F6C\u76D8&sub_c=").concat(app.globalData.openid)
            });
          }
          if (res.tapIndex === 1) {
            _this.$bus.event.emit("share-settings:show");
            return false;
          }
        }
      });
    });
  },
  onShareAppMessage: function onShareAppMessage(options) {
    var _this2 = this;
    return _asyncToGenerator2( /*#__PURE__*/_regeneratorRuntime2().mark(function _callee2() {
      var zpInfo, shareConfig, _shareConfig;
      return _regeneratorRuntime2().wrap(function _callee2$(_context2) {
        while (1) switch (_context2.prev = _context2.next) {
          case 0:
            console.log("onShareAppMessage", options);
            zpInfo = _this2.$bus.store.get('zpInfo');
            if (!(options.from === "menu")) {
              _context2.next = 8;
              break;
            }
            _context2.next = 5;
            return _this2.moreShare();
          case 5:
            shareConfig = _context2.sent;
            if (!shareConfig) {
              _context2.next = 8;
              break;
            }
            return _context2.abrupt("return", shareConfig);
          case 8:
            if (!(options.from === "button")) {
              _context2.next = 26;
              break;
            }
            if (!(options.target.dataset.detail === "btn_share_more")) {
              _context2.next = 17;
              break;
            }
            _context2.next = 12;
            return _this2.moreShare();
          case 12:
            _shareConfig = _context2.sent;
            if (!_shareConfig) {
              _context2.next = 16;
              break;
            }
            console.log('fengxiang', _shareConfig);
            return _context2.abrupt("return", _shareConfig);
          case 16:
            return _context2.abrupt("return", {
              title: zpInfo.title,
              path: "/pages/zhuanpan/index/index?type=share&share_type=2&id=".concat(zpInfo.id, "&top_c=share_setting&sub_c=").concat(app.globalData.openid)
            });
          case 17:
            if (!(options.target.dataset.detail === "result")) {
              _context2.next = 21;
              break;
            }
            return _context2.abrupt("return", {
              title: _this2.$bus.get('result').text,
              path: "/pages/zhuanpan/index/index?type=share&id=".concat(zpInfo.id, "&top_c=\u5206\u4EAB\u7ED3\u679C&sub_c=").concat(app.globalData.openid)
            });
          case 21:
            if (!(options.target.dataset.detail === "saveShareSetting")) {
              _context2.next = 26;
              break;
            }
            console.log("saveShareSetting");
            _context2.next = 25;
            return new Promise( /*#__PURE__*/function () {
              var _ref = _asyncToGenerator2( /*#__PURE__*/_regeneratorRuntime2().mark(function _callee(resolve, reject) {
                var _zpInfo$share_setting;
                var rr;
                return _regeneratorRuntime2().wrap(function _callee$(_context) {
                  while (1) switch (_context.prev = _context.next) {
                    case 0:
                      wx.showLoading({
                        title: '保存中...'
                      });
                      _context.next = 3;
                      return Zhuanpan.UpdateShareSettings({
                        id: zpInfo.id,
                        p_times: ((_zpInfo$share_setting = zpInfo.share_settings) === null || _zpInfo$share_setting === void 0 ? void 0 : _zpInfo$share_setting.p_times) || 1
                      });
                    case 3:
                      rr = _context.sent;
                      // 如果这个转盘不是自己的，就创建一个。并且以返回的为主
                      if (rr && rr.code === 0) {
                        _this2.$bus.store.set("zpInfo", rr.data);
                        wx.hideLoading();
                        _this2.$bus.event.emit("share-settings:hide");
                        resolve();
                      }
                    case 5:
                    case "end":
                      return _context.stop();
                  }
                }, _callee);
              }));
              return function (_x, _x2) {
                return _ref.apply(this, arguments);
              };
            }());
          case 25:
            return _context2.abrupt("return", {
              title: zpInfo.title,
              path: "/pages/zhuanpan/index/index?type=share&share_type=2&id=".concat(zpInfo.id, "&top_c=share_setting&sub_c=").concat(app.globalData.openid)
            });
          case 26:
            return _context2.abrupt("return", {
              title: zpInfo.title,
              path: "/pages/zhuanpan/index/index?type=share&id=".concat(zpInfo.id, "&top_c=\u5206\u4EAB\u8F6C\u76D8&sub_c=").concat(app.globalData.openid)
            });
          case 27:
          case "end":
            return _context2.stop();
        }
      }, _callee2);
    }))();
  },
  onShareTimeline: function onShareTimeline() {
    var zpInfo = this.$bus.store.get('zpInfo');
    return {
      title: zpInfo.title,
      query: "type=share&id=".concat(zpInfo.id)
    };
  },
  onLoad: function onLoad(options) {
    var _this3 = this;
    return _asyncToGenerator2( /*#__PURE__*/_regeneratorRuntime2().mark(function _callee3() {
      return _regeneratorRuntime2().wrap(function _callee3$(_context3) {
        while (1) switch (_context3.prev = _context3.next) {
          case 0:
            if (options.id.startsWith("template_")) {
              _this3.loadFromTemplate(options.id);
            } else {
              _this3.loadZpFromServer(options.id);
            }
            _this3.$bus.store.set("options", options);
            if (options.share_type && options.share_type == 2) {
              _this3.setData({
                share_type: 2
              });
            }
          case 3:
          case "end":
            return _context3.stop();
        }
      }, _callee3);
    }))();
  },
  loadFromTemplate: function loadFromTemplate(id) {
    var zpInfo = zps.all_zps[id];
    if (!zpInfo) {
      this.loadZpFromServer(id);
      return;
    }
    this.initZp(zpInfo);
    app.addLog({
      id: "打开转盘",
      title: zpInfo.title,
      type: "template"
    });
  },
  initZp: function initZp(zpInfo) {
    zps.initZpItemsObj(zpInfo);
    this.$bus.store.set("zpInfo", zpInfo);
    this.setData({
      title: zpInfo.title,
      zpState: 1,
      zpLoad: true,
      share_settings: zpInfo.share_settings,
      isTemplate: zpInfo.id.startsWith("template_")
    });
    // 保存到 storage: 上次使用的转盘
    wx.setStorageSync("lastZp", zpInfo);
    if (zpInfo.openid !== app.globalData.openid) {
      this.setData({
        isMineZp: false
      });
    } else {
      this.setData({
        isMineZp: true
      });
    }
    if ((this.data.share_type === 2 || zpInfo.openid === app.globalData.openid) && zpInfo.share_settings && zpInfo.share_settings.p_times > 0) {
      this.setData({
        shouldSaveResult: true
      });
      this.$bus.store.set("shouldSaveResult", true);
    }
    this.$bus.emit("page:zpInfoLoaded");
    this.getZPRecordsTimes(zpInfo);
  },
  getZPRecordsTimes: function getZPRecordsTimes(zpInfo) {
    var _this4 = this;
    return _asyncToGenerator2( /*#__PURE__*/_regeneratorRuntime2().mark(function _callee4() {
      var r;
      return _regeneratorRuntime2().wrap(function _callee4$(_context4) {
        while (1) switch (_context4.prev = _context4.next) {
          case 0:
            if (!(zpInfo.share_settings && zpInfo.share_settings.p_times > 0)) {
              _context4.next = 5;
              break;
            }
            _context4.next = 3;
            return Zhuanpan.MyZPRecordsCount({
              zp_id: zpInfo.id
            });
          case 3:
            r = _context4.sent;
            if (r.code === 0) {
              _this4.setData({
                have_join_times: r.data
              });
              _this4.$bus.store.set("recordsTimes", r.data);
              if (r.data >= zpInfo.share_settings.p_times) {
                _this4.$bus.store.set("shouldSaveResult", false);
              }
              _this4.$bus.event.call("summarize_bar:updateShow");
            }
          case 5:
          case "end":
            return _context4.stop();
        }
      }, _callee4);
    }))();
  },
  loadZpFromServer: function loadZpFromServer(id) {
    var _this5 = this;
    return _asyncToGenerator2( /*#__PURE__*/_regeneratorRuntime2().mark(function _callee5() {
      var data;
      return _regeneratorRuntime2().wrap(function _callee5$(_context5) {
        while (1) switch (_context5.prev = _context5.next) {
          case 0:
            wx.showLoading({
              title: '转盘加载中..'
            });
            _context5.next = 3;
            return app.initLogin();
          case 3:
            _context5.prev = 3;
            if (!id.startsWith("template_server_")) {
              _context5.next = 10;
              break;
            }
            _context5.next = 7;
            return Zhuanpan.getTemplateById(id);
          case 7:
            data = _context5.sent;
            _context5.next = 13;
            break;
          case 10:
            _context5.next = 12;
            return Zhuanpan.findOneById(id);
          case 12:
            data = _context5.sent;
          case 13:
            wx.hideLoading();
            if (data.code === 0) {
              _this5.initZp(data.data);
              app.addLog({
                id: "打开转盘",
                title: data.data.title,
                type: "server"
              });
            }
            _context5.next = 21;
            break;
          case 17:
            _context5.prev = 17;
            _context5.t0 = _context5["catch"](3);
            wx.showModal({
              title: '加载出错了，请稍后重试',
              content: _context5.t0.toString(),
              showCancel: false,
              complete: function complete(res) {
                wx.navigateBack();
              }
            });
            app.addLog({
              id: "加载转盘出错",
              status: "error",
              msg: _context5.t0
            });
          case 21:
          case "end":
            return _context5.stop();
        }
      }, _callee5, null, [[3, 17]]);
    }))();
  },
  toResetZp: function toResetZp() {
    var _this6 = this;
    return _asyncToGenerator2( /*#__PURE__*/_regeneratorRuntime2().mark(function _callee6() {
      return _regeneratorRuntime2().wrap(function _callee6$(_context6) {
        while (1) switch (_context6.prev = _context6.next) {
          case 0:
            if (_this6.checkZpIsReady()) {
              _context6.next = 2;
              break;
            }
            return _context6.abrupt("return");
          case 2:
            _this6.$bus.emit("page:recoveryZp");
            _this6.setData({
              showResetZp: false
            });
          case 4:
          case "end":
            return _context6.stop();
        }
      }, _callee6);
    }))();
  },
  toResults: function toResults() {
    var zpInfo = this.$bus.store.get('zpInfo');
    wx.navigateTo({
      url: '/pages/zhuanpan/results/results' + "?id=".concat(zpInfo.id, "&openid=").concat(zpInfo.openid)
    });
  },
  checkZpIsReady: function checkZpIsReady() {
    if (this.data.zpState !== 1) {
      return false;
    }
    return true;
  },
  onShow: function onShow() {
    console.log("onShow", app.globalData.current_edit_zp);
    if (app.globalData.current_edit_zp) {
      this.initZp(app.globalData.current_edit_zp);
      app.globalData.current_edit_zp = null;
    }

    // 二级页面删除黑名单后，需要更新黑名单
    if (app.globalData._needupdateBlackList) {
      this.$bus.event.call("black:initBlack");
      app.globalData._needupdateBlackList = false;
    }
  },
  onReady: function onReady() {}
});