var _regeneratorRuntime2 = require("../../../../../@babel/runtime/helpers/regeneratorRuntime");var _asyncToGenerator2 = require("../../../../../@babel/runtime/helpers/asyncToGenerator");var Zhuanpan = require("../../../../../common/apis/zhuanpan");Component({
  behaviors: [wx.Bus],
  properties: {},
  data: {
    show: false,
    allow_share: true,
    p_times: 1
  },
  methods: {
    changeShareStatus: function changeShareStatus(e) {
      console.log(e.detail);
      this.setData({
        allow_share: e.detail
      });
    },
    saveShareSettings: function saveShareSettings() {
      var _this = this;
      return _asyncToGenerator2( /*#__PURE__*/_regeneratorRuntime2().mark(function _callee() {
        var zpInfo, rr;
        return _regeneratorRuntime2().wrap(function _callee$(_context) {
          while (1) switch (_context.prev = _context.next) {
            case 0:
              zpInfo = _this.$bus.get("zpInfo");
              wx.showLoading({
                title: '保存中..'
              });
              _context.next = 4;
              return Zhuanpan.UpdateShareSettings({
                id: zpInfo.id,
                p_times: 0
              });
            case 4:
              rr = _context.sent;
              if (rr && rr.code === 0) {
                _this.$bus.store.set("zpInfo", rr.data);
                wx.showModal({
                  title: "提示",
                  content: "保存成功",
                  showCancel: false,
                  success: function success() {
                    wx.navigateBack();
                  }
                });
              }
            case 6:
            case "end":
              return _context.stop();
          }
        }, _callee);
      }))();
    },
    handleClose: function handleClose() {
      this.setData({
        show: false
      });
    },
    onSave: function onSave() {
      console.log("onSave");
    },
    onStepperChange: function onStepperChange(e) {
      this.setData({
        p_times: e.detail
      });
      var zpInfo = this.$bus.get("zpInfo");
      if (!zpInfo.share_settings) zpInfo.share_settings = {};
      this.$bus.get("zpInfo").share_settings.p_times = e.detail;
      console.log("zpInfo", zpInfo);
    }
  },
  lifetimes: {
    attached: function attached() {
      var _this2 = this;
      this.$bus.event.on("share-settings:show", function () {
        var _zpInfo$share_setting;
        var zpInfo = _this2.$bus.get("zpInfo");
        _this2.setData({
          show: true,
          p_times: ((_zpInfo$share_setting = zpInfo.share_settings) === null || _zpInfo$share_setting === void 0 ? void 0 : _zpInfo$share_setting.p_times) || 1
        });
      });
      this.$bus.event.on("share-settings:hide", function () {
        _this2.setData({
          show: false
        });
      });
    }
  }
});