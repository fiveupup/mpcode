var _toConsumableArray2 = require("../../../@babel/runtime/helpers/toConsumableArray");var _regeneratorRuntime2 = require("../../../@babel/runtime/helpers/regeneratorRuntime");var _asyncToGenerator2 = require("../../../@babel/runtime/helpers/asyncToGenerator");var ZhuanPanApi = require("../../../common/apis/zhuanpan");var app = getApp();Page({
  /**
   * 页面的初始数据
   */
  data: {
    myList: [],
    myListCount: 0,
    myListOffset: 0,
    allList: [],
    limit: 15,
    allListCount: 0,
    allListOffset: 0
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function onLoad(options) {
    console.log(options);
    this.setData({
      id: options.id
    });
    wx.showLoading();
    this.loadMyList();
    this.loadAllList();
    console.log(options.openid);
    if (options.openid === app.globalData.openid) {
      this.setData({
        showDelete: true
      });
    }
  },
  delResult: function delResult(e) {
    var _this = this;
    console.log(e.currentTarget.dataset);
    var id = e.currentTarget.dataset.id;
    wx.showModal({
      title: '提示',
      content: '确定删除此条记录？',
      success: function () {
        var _success = _asyncToGenerator2( /*#__PURE__*/_regeneratorRuntime2().mark(function _callee(res) {
          var r, index;
          return _regeneratorRuntime2().wrap(function _callee$(_context) {
            while (1) switch (_context.prev = _context.next) {
              case 0:
                if (!res.confirm) {
                  _context.next = 5;
                  break;
                }
                _context.next = 3;
                return ZhuanPanApi.delRecord({
                  id: id,
                  zp_id: _this.data.id
                });
              case 3:
                r = _context.sent;
                if (r.code === 0) {
                  wx.showToast({
                    title: '删除成功'
                  });
                  _this.setData({
                    allList: _this.data.allList.filter(function (item) {
                      return item.id !== id;
                    }),
                    allListCount: _this.data.allListCount - 1
                  });
                  // 看 myList 有无此条记录
                  index = _this.data.myList.findIndex(function (item) {
                    return item.id === id;
                  });
                  if (index !== -1) {
                    _this.setData({
                      myList: _this.data.myList.filter(function (item) {
                        return item.id !== id;
                      }),
                      myListCount: _this.data.myListCount - 1
                    });
                  }
                }
              case 5:
              case "end":
                return _context.stop();
            }
          }, _callee);
        }));
        function success(_x) {
          return _success.apply(this, arguments);
        }
        return success;
      }()
    });
  },
  loadMoreMyList: function loadMoreMyList() {
    var _this2 = this;
    return _asyncToGenerator2( /*#__PURE__*/_regeneratorRuntime2().mark(function _callee2() {
      var r;
      return _regeneratorRuntime2().wrap(function _callee2$(_context2) {
        while (1) switch (_context2.prev = _context2.next) {
          case 0:
            if (!(_this2.data.myListOffset > _this2.data.myListCount)) {
              _context2.next = 3;
              break;
            }
            wx.showToast({
              title: '没有更多了',
              icon: 'none'
            });
            return _context2.abrupt("return", false);
          case 3:
            _context2.next = 5;
            return ZhuanPanApi.MyZPRecords({
              zp_id: _this2.data.id,
              offset: _this2.data.myListOffset + _this2.data.limit
            });
          case 5:
            r = _context2.sent;
            if (r.code === 0) {
              console.log(r.data.list);
              _this2.data.myList = [].concat(_toConsumableArray2(_this2.data.myList), _toConsumableArray2(r.data.list));
              console.log(_this2.data.myList);
              _this2.setData({
                myList: _this2.data.myList,
                myListCount: r.data.count,
                myListOffset: _this2.data.myListOffset + _this2.data.limit
              });
            }
          case 7:
          case "end":
            return _context2.stop();
        }
      }, _callee2);
    }))();
  },
  loadMoreAllList: function loadMoreAllList() {
    var _this3 = this;
    return _asyncToGenerator2( /*#__PURE__*/_regeneratorRuntime2().mark(function _callee3() {
      var r;
      return _regeneratorRuntime2().wrap(function _callee3$(_context3) {
        while (1) switch (_context3.prev = _context3.next) {
          case 0:
            if (!(_this3.data.allListOffset > _this3.data.allListCount)) {
              _context3.next = 3;
              break;
            }
            wx.showToast({
              title: '没有更多了',
              icon: 'none'
            });
            return _context3.abrupt("return", false);
          case 3:
            _context3.next = 5;
            return ZhuanPanApi.allRecords({
              zp_id: _this3.data.id,
              offset: _this3.data.allListOffset + _this3.data.limit
            });
          case 5:
            r = _context3.sent;
            if (r.code === 0) {
              console.log(r.data.list);
              _this3.data.allList = [].concat(_toConsumableArray2(_this3.data.allList), _toConsumableArray2(r.data.list));
              console.log(_this3.data.allList);
              _this3.setData({
                allList: _this3.data.allList,
                allListCount: r.data.count,
                allListOffset: _this3.data.allListOffset + _this3.data.limit
              });
            }
          case 7:
          case "end":
            return _context3.stop();
        }
      }, _callee3);
    }))();
  },
  loadMyList: function loadMyList() {
    var _this4 = this;
    return _asyncToGenerator2( /*#__PURE__*/_regeneratorRuntime2().mark(function _callee4() {
      var r;
      return _regeneratorRuntime2().wrap(function _callee4$(_context4) {
        while (1) switch (_context4.prev = _context4.next) {
          case 0:
            _context4.next = 2;
            return ZhuanPanApi.MyZPRecords({
              zp_id: _this4.data.id
            });
          case 2:
            r = _context4.sent;
            wx.hideLoading();
            if (r.code === 0) {
              _this4.setData({
                myList: r.data.list,
                myListCount: r.data.count
              });
            }
          case 5:
          case "end":
            return _context4.stop();
        }
      }, _callee4);
    }))();
  },
  loadAllList: function loadAllList() {
    var _this5 = this;
    return _asyncToGenerator2( /*#__PURE__*/_regeneratorRuntime2().mark(function _callee5() {
      var r;
      return _regeneratorRuntime2().wrap(function _callee5$(_context5) {
        while (1) switch (_context5.prev = _context5.next) {
          case 0:
            _context5.next = 2;
            return ZhuanPanApi.allRecords({
              zp_id: _this5.data.id
            });
          case 2:
            r = _context5.sent;
            if (r.code === 0) {
              _this5.setData({
                allList: r.data.list,
                allListCount: r.data.count
              });
            }
          case 4:
          case "end":
            return _context5.stop();
        }
      }, _callee5);
    }))();
  }
});