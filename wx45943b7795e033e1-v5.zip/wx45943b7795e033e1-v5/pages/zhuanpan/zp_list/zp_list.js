var _objectSpread2 = require("../../../@babel/runtime/helpers/objectSpread2");var _regeneratorRuntime2 = require("../../../@babel/runtime/helpers/regeneratorRuntime");var _asyncToGenerator2 = require("../../../@babel/runtime/helpers/asyncToGenerator");var bus = require('../../../utils/bus');var app = getApp();Page({
  behaviors: [wx.Bus],
  /**
   * 页面的初始数据
   */
  data: {
    list1: [],
    list2: [],
    list3: [],
    currentTab: 0
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function () {
    var _onLoad = _asyncToGenerator2( /*#__PURE__*/_regeneratorRuntime2().mark(function _callee(options) {
      var list2;
      return _regeneratorRuntime2().wrap(function _callee$(_context) {
        while (1) switch (_context.prev = _context.next) {
          case 0:
            list2 = zps.hot;
            this.loadMyZps();
            this.setData({
              list2: list2,
              currentTab: app.globalData.currentTab || 0
            });
            this.initEvents();
          case 4:
          case "end":
            return _context.stop();
        }
      }, _callee, this);
    }));
    function onLoad(_x) {
      return _onLoad.apply(this, arguments);
    }
    return onLoad;
  }(),
  loadMyZps: function loadMyZps() {
    var _this = this;
    return _asyncToGenerator2( /*#__PURE__*/_regeneratorRuntime2().mark(function _callee2() {
      var data, list;
      return _regeneratorRuntime2().wrap(function _callee2$(_context2) {
        while (1) switch (_context2.prev = _context2.next) {
          case 0:
            _context2.next = 2;
            return draws.getDraws();
          case 2:
            data = _context2.sent;
            if (!(data.code === 0)) {
              _context2.next = 9;
              break;
            }
            list = data.data.map(function (item) {
              return _objectSpread2(_objectSpread2({}, item), {}, {
                from: "mine"
              });
            });
            if (list.length > 0) {
              if (_this.data.currentTab === 1 && list.length === 15) {
                wx.showToast({
                  title: "免费用户最多可展示15个转盘，你可联系客服开通会员",
                  icon: "none"
                });
              }
              _this.setData({
                list3: list
              });
            }
            return _context2.abrupt("return", list);
          case 9:
            return _context2.abrupt("return", []);
          case 10:
          case "end":
            return _context2.stop();
        }
      }, _callee2);
    }))();
  },
  initEvents: function initEvents() {
    var _this2 = this;
    this.$bus.event.export("page:selectZp", function (item) {
      var prePage = getCurrentPages()[getCurrentPages().length - 2];
      prePage.pageCallback && prePage.pageCallback({
        type: "selectZp",
        data: item
      });
      wx.navigateBack({
        delta: 1
      });
    });
    this.$bus.event.export("page:delZp", /*#__PURE__*/function () {
      var _ref = _asyncToGenerator2( /*#__PURE__*/_regeneratorRuntime2().mark(function _callee3(item) {
        var data, list3;
        return _regeneratorRuntime2().wrap(function _callee3$(_context3) {
          while (1) switch (_context3.prev = _context3.next) {
            case 0:
              _context3.next = 2;
              return draws.deleteDraw({
                id: item.id00
              });
            case 2:
              data = _context3.sent;
              if (!(data.code === 0)) {
                _context3.next = 8;
                break;
              }
              _context3.next = 6;
              return _this2.loadMyZps();
            case 6:
              list3 = _context3.sent;
              _this2.setData({
                list3: list3
              });
            case 8:
            case "end":
              return _context3.stop();
          }
        }, _callee3);
      }));
      return function (_x2) {
        return _ref.apply(this, arguments);
      };
    }());
    this.$bus.event.export("page:copyZp", /*#__PURE__*/function () {
      var _ref2 = _asyncToGenerator2( /*#__PURE__*/_regeneratorRuntime2().mark(function _callee4(item) {
        var r;
        return _regeneratorRuntime2().wrap(function _callee4$(_context4) {
          while (1) switch (_context4.prev = _context4.next) {
            case 0:
              wx.showLoading({
                title: '保存中...'
              });
              _context4.next = 3;
              return draws.updateDraw(item);
            case 3:
              r = _context4.sent;
              if (r.code === 0) {
                _this2.data.list3.unshift(_objectSpread2({}, r.data));
                _this2.setData({
                  list3: _this2.data.list3
                });
                wx.showToast({
                  title: '保存成功'
                });
              } else {
                wx.showToast({
                  title: '保存失败'
                });
              }
            case 5:
            case "end":
              return _context4.stop();
          }
        }, _callee4);
      }));
      return function (_x3) {
        return _ref2.apply(this, arguments);
      };
    }());
    this.$bus.event.export("page:toAdd", function () {
      _this2.toAdd();
    });
  },
  toAdd: function toAdd() {
    wx.navigateTo({
      url: "../edit/edit?type=add"
    });
  },
  onShow: function onShow() {
    if (app.globalData.current_edit_zp) {
      this.loadMyZps();
      var topPage = getCurrentPages()[0];
      if (topPage && topPage.route === "pages/zhuanpan/index/index") {
        var edit_zp = app.globalData.current_edit_zp;
        var main_zp = app.globalData.main_zp;
        if (main_zp && main_zp.id00 === edit_zp.id00 || !main_zp.id00 || edit_zp.isAdd) {
          topPage.initZp(app.globalData.current_edit_zp);
          this.$bus.emit("page:refreshMainZp");
        }
      }
      app.globalData.current_edit_zp = null;
    }
  },
  onTabChange: function onTabChange(e) {
    console.log(e.detail.index);
    app.globalData.currentTab = e.detail.index;
  }
});