var _regeneratorRuntime2 = require("../../../../../@babel/runtime/helpers/regeneratorRuntime");var _asyncToGenerator2 = require("../../../../../@babel/runtime/helpers/asyncToGenerator");var app = getApp();Component({
  behaviors: [wx.Bus],
  properties: {
    list: {
      type: Array,
      value: [],
      observer: function observer(newVal) {
        // if (this.data.type==='hot') return
        for (var i = 0; i < newVal.length; i++) {
          var idEquel = newVal[i].id && newVal[i].id === app.globalData.main_zp.id;
          var id00Equel = newVal[i].id00 && newVal[i].id00 === app.globalData.main_zp.id00;
          if (idEquel || id00Equel) {
            this.setData({
              currentSelect: i
            });
          }
        }
      }
    },
    type: {
      type: String
    }
  },
  data: {
    currentSelect: -1
  },
  methods: {
    tapItem: function tapItem(e) {
      var index = e.currentTarget.dataset.index;
      var item = this.data.list[index];
      if (e.detail === "cell") {
        this.$bus.event.call('page:selectZp', item);
      } else if (e.detail === "right") {
        if (this.data.type === "hot") {
          this.copyItem(item);
        } else if (this.data.type === "mine") {
          this.delItem(item);
        }
      }
    },
    copyItem: function copyItem(item) {
      var _this = this;
      return _asyncToGenerator2( /*#__PURE__*/_regeneratorRuntime2().mark(function _callee() {
        return _regeneratorRuntime2().wrap(function _callee$(_context) {
          while (1) switch (_context.prev = _context.next) {
            case 0:
              _this.$bus.event.call('page:copyZp', item);
            case 1:
            case "end":
              return _context.stop();
          }
        }, _callee);
      }))();
    },
    delItem: function delItem(item) {
      if (!item.id00) return;
      this.$bus.event.call('page:delZp', item);
    },
    editItem: function editItem(e) {
      var index = e.currentTarget.dataset.index;
      var item = this.data.list[index];
      app.globalData.current_edit_zp = item;
      wx.navigateTo({
        url: "/pages/zhuanpan/edit/edit"
      });
    },
    toAdd: function toAdd() {
      this.$bus.event.call('page:toAdd');
    }
  },
  lifetimes: {
    attached: function attached() {
      var _this2 = this;
      this.$bus.event.on('page:refreshMainZp', function (item) {
        if (_this2.data.type === "mine") {
          _this2.setData({
            currentSelect: 0
          });
        }
      });
    }
  },
  options: {
    styleIsolation: 'apply-shared'
  }
});