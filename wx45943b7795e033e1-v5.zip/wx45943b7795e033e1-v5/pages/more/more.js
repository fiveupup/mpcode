var _regeneratorRuntime2 = require("../../@babel/runtime/helpers/regeneratorRuntime");var _asyncToGenerator2 = require("../../@babel/runtime/helpers/asyncToGenerator");var _require = require('../../common/apis/zhuanpan'),
  loadTemplates = _require.loadTemplates;Page({
  /**
   * 页面的初始数据
   */
  data: {
    templates: [],
    all_count: 0,
    limit: 20,
    offset: 0
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function onLoad(options) {
    var _this = this;
    return _asyncToGenerator2( /*#__PURE__*/_regeneratorRuntime2().mark(function _callee() {
      var res;
      return _regeneratorRuntime2().wrap(function _callee$(_context) {
        while (1) switch (_context.prev = _context.next) {
          case 0:
            _context.next = 2;
            return loadTemplates({
              offset: _this.data.offset,
              limit: _this.data.limit
            });
          case 2:
            res = _context.sent;
            console.log(res);
            if (res.code === 0) {
              _this.setData({
                all_count: res.data.count,
                templates: res.data.list
              });
            }
          case 5:
          case "end":
            return _context.stop();
        }
      }, _callee);
    }))();
  },
  toZp: function toZp(e) {
    var id = e.currentTarget.dataset.id;
    wx.navigateTo({
      url: "/pages/zhuanpan/index/index?id=".concat(id, "&from=template")
    });
  },
  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function onReady() {},
  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function onShow() {},
  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function onHide() {},
  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function onUnload() {},
  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function onPullDownRefresh() {},
  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function onReachBottom() {},
  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function onShareAppMessage() {}
});