var _toConsumableArray2 = require("../../@babel/runtime/helpers/toConsumableArray");var _regeneratorRuntime2 = require("../../@babel/runtime/helpers/regeneratorRuntime");var _asyncToGenerator2 = require("../../@babel/runtime/helpers/asyncToGenerator");var app = getApp();var zps = require('../../common/zps');var zhuanpanApi = require('../../common/apis/zhuanpan');Page({
  data: {
    hotList: [],
    mineList: [],
    showNotice: false,
    loading: true,
    offset: 0,
    count: 0
  },
  toZp: function toZp(e) {
    var _e$currentTarget$data = e.currentTarget.dataset,
      id = _e$currentTarget$data.id,
      from = _e$currentTarget$data.from;
    // wx.navigateTo({
    //   url: `/p1/newTurnable/index?id=${id}&from=${from}`,
    // })
    wx.navigateTo({
      url: "/pages/zhuanpan/index/index?id=".concat(id, "&from=").concat(from)
    });
  },
  loadHotList: function loadHotList() {
    var list = zps.index;
    this.setData({
      hotList: list
    });
  },
  onLoad: function onLoad() {
    // 1. 初始化模板列表
    this.loadHotList();
    // 2. 初始化我的转盘列表
    this.loadMyList();
  },
  loadMyList: function loadMyList() {
    var _this = this;
    return _asyncToGenerator2( /*#__PURE__*/_regeneratorRuntime2().mark(function _callee() {
      var res, list, count;
      return _regeneratorRuntime2().wrap(function _callee$(_context) {
        while (1) switch (_context.prev = _context.next) {
          case 0:
            wx.showNavigationBarLoading();
            _context.next = 3;
            return app.initLogin();
          case 3:
            if (_context.sent) {
              _context.next = 7;
              break;
            }
            _this.setData({
              showNotice: true
            });
            wx.hideNavigationBarLoading();
            return _context.abrupt("return");
          case 7:
            console.log("登录成功");
            _context.prev = 8;
            _context.next = 11;
            return zhuanpanApi.list();
          case 11:
            res = _context.sent;
            _this.setData({
              loading: false
            });
            if (!(res.code === 0)) {
              _context.next = 19;
              break;
            }
            list = res.data.list;
            count = res.data.count;
            wx.hideNavigationBarLoading();
            _this.setData({
              list: list,
              showNotice: false,
              count: count,
              offset: 0
            });
            return _context.abrupt("return");
          case 19:
            _context.next = 23;
            break;
          case 21:
            _context.prev = 21;
            _context.t0 = _context["catch"](8);
          case 23:
            _this.setData({
              showNotice: true
            });
          case 24:
          case "end":
            return _context.stop();
        }
      }, _callee, null, [[8, 21]]);
    }))();
  },
  showMore: function showMore() {
    var _this2 = this;
    return _asyncToGenerator2( /*#__PURE__*/_regeneratorRuntime2().mark(function _callee2() {
      var res, _this2$data$list, list;
      return _regeneratorRuntime2().wrap(function _callee2$(_context2) {
        while (1) switch (_context2.prev = _context2.next) {
          case 0:
            wx.showLoading({
              title: "加载中.."
            });
            _context2.next = 3;
            return zhuanpanApi.list(_this2.data.offset + 30);
          case 3:
            res = _context2.sent;
            wx.hideLoading();
            if (res.code === 0) {
              list = res.data.list;
              (_this2$data$list = _this2.data.list).push.apply(_this2$data$list, _toConsumableArray2(list));
              wx.hideNavigationBarLoading();
              _this2.setData({
                list: _this2.data.list,
                offset: _this2.data.offset + 30
              });
            }
          case 6:
          case "end":
            return _context2.stop();
        }
      }, _callee2);
    }))();
  },
  showMoreSheet: function showMoreSheet(e) {
    var _this3 = this;
    return _asyncToGenerator2( /*#__PURE__*/_regeneratorRuntime2().mark(function _callee4() {
      var id, OPTIONS, itemList;
      return _regeneratorRuntime2().wrap(function _callee4$(_context4) {
        while (1) switch (_context4.prev = _context4.next) {
          case 0:
            id = e.currentTarget.dataset.id;
            OPTIONS = {
              'DELETE': '🗑️  删除',
              'EDIT': '📝  编辑',
              'COPY': '📋  复制',
              'SHARE_TO_HOT': '分享到热门转盘'
            };
            itemList = [OPTIONS.EDIT, OPTIONS.COPY, OPTIONS.DELETE, OPTIONS.SHARE_TO_HOT];
            wx.showActionSheet({
              itemList: itemList,
              success: function () {
                var _success = _asyncToGenerator2( /*#__PURE__*/_regeneratorRuntime2().mark(function _callee3(res) {
                  return _regeneratorRuntime2().wrap(function _callee3$(_context3) {
                    while (1) switch (_context3.prev = _context3.next) {
                      case 0:
                        console.log(res);
                        _context3.t0 = itemList[res.tapIndex];
                        _context3.next = _context3.t0 === OPTIONS.EDIT ? 4 : _context3.t0 === OPTIONS.COPY ? 6 : _context3.t0 === OPTIONS.DELETE ? 8 : _context3.t0 === OPTIONS.SHARE_TO_HOT ? 10 : 11;
                        break;
                      case 4:
                        _this3.editZp(id);
                        return _context3.abrupt("break", 11);
                      case 6:
                        _this3.copyZp(id);
                        return _context3.abrupt("break", 11);
                      case 8:
                        _this3.deleteZp(id);
                        return _context3.abrupt("break", 11);
                      case 10:
                        _this3.shareToHot(id);
                      case 11:
                      case "end":
                        return _context3.stop();
                    }
                  }, _callee3);
                }));
                function success(_x) {
                  return _success.apply(this, arguments);
                }
                return success;
              }()
            });
          case 4:
          case "end":
            return _context4.stop();
        }
      }, _callee4);
    }))();
  },
  copyZp: function copyZp(id) {
    var _this4 = this;
    return _asyncToGenerator2( /*#__PURE__*/_regeneratorRuntime2().mark(function _callee5() {
      var res;
      return _regeneratorRuntime2().wrap(function _callee5$(_context5) {
        while (1) switch (_context5.prev = _context5.next) {
          case 0:
            _context5.next = 2;
            return zhuanpanApi.copy(id);
          case 2:
            res = _context5.sent;
            if (res.code === 0) {
              wx.showToast({
                title: '复制成功！',
                icon: 'success',
                duration: 2000
              });
              _this4.loadMyList();
            }
          case 4:
          case "end":
            return _context5.stop();
        }
      }, _callee5);
    }))();
  },
  shareToHot: function shareToHot(id) {
    wx.showModal({
      title: "将转盘分享至【热门转盘】",
      content: "分享后，所有人都能看到该转盘。人工审核通过后才会出现在热门转盘列表，且分享后不可撤销！",
      confirmText: "确认分享",
      success: function () {
        var _success2 = _asyncToGenerator2( /*#__PURE__*/_regeneratorRuntime2().mark(function _callee6(res) {
          var _res;
          return _regeneratorRuntime2().wrap(function _callee6$(_context6) {
            while (1) switch (_context6.prev = _context6.next) {
              case 0:
                if (!res.confirm) {
                  _context6.next = 5;
                  break;
                }
                _context6.next = 3;
                return zhuanpanApi.addToHot(id);
              case 3:
                _res = _context6.sent;
                if (_res.code === 0) {
                  wx.showToast({
                    title: '分享成功，感谢您！',
                    icon: 'none',
                    duration: 5000
                  });
                } else {
                  wx.showToast({
                    title: '分享失败！同转盘只能分享一次哦~',
                    icon: 'none',
                    duration: 2000
                  });
                }
              case 5:
              case "end":
                return _context6.stop();
            }
          }, _callee6);
        }));
        function success(_x2) {
          return _success2.apply(this, arguments);
        }
        return success;
      }()
    });
  },
  addZp: function addZp() {
    wx.navigateTo({
      url: "/pages/zhuanpan/edit/edit?type=add"
    });
  },
  editZp: function editZp(zpId) {
    wx.navigateTo({
      url: "/pages/zhuanpan/edit/edit?type=edit&id=".concat(zpId)
    });
  },
  deleteZp: function deleteZp(id) {
    var _this5 = this;
    return _asyncToGenerator2( /*#__PURE__*/_regeneratorRuntime2().mark(function _callee7() {
      var res;
      return _regeneratorRuntime2().wrap(function _callee7$(_context7) {
        while (1) switch (_context7.prev = _context7.next) {
          case 0:
            _context7.next = 2;
            return zhuanpanApi.deleteOneById(id);
          case 2:
            res = _context7.sent;
            if (res.code === 0) {
              wx.showToast({
                title: '删除成功！',
                icon: 'success',
                duration: 2000
              });
              _this5.loadMyList();
            }
          case 4:
          case "end":
            return _context7.stop();
        }
      }, _callee7);
    }))();
  },
  onShareAppMessage: function onShareAppMessage(options) {
    if (options.from === 'button') {
      console.log(options);
      var zpInfo = options.target.dataset.detail;
      var url = "/pages/zhuanpan/index/index?id=".concat(zpInfo.id, "&from=share") + (zpInfo.share_type_is_2 ? "&share_type=2" : '');
      console.log(url);
      return {
        title: zpInfo.title,
        path: url,
        imageUrl: "http://pan00.jialidun.vip/zp/zplogo.jpeg",
        success: function success(e) {
          wx.showToast({
            title: "分享成功～"
          });
        }
      };
    }
    return {
      title: "全能小转盘！",
      path: "/pages/index/index",
      imageUrl: "http://pan00.jialidun.vip/zp/zplogo.jpeg",
      success: function success(e) {
        wx.showToast({
          title: "分享成功！"
        });
      }
    };
  },
  onShareTimeline: function onShareTimeline() {
    return {
      title: "全能小转盘！",
      query: "top_c=相互推荐&sub_c=朋友圈"
    };
  },
  onShow: function onShow() {
    if (app.globalData._updateZpList) {
      this.loadMyList();
      app.globalData._updateZpList = false;
    }
  },
  toMoreZp: function toMoreZp() {
    wx.navigateTo({
      url: '/pages/more/more'
    });
  },
  onReady: function onReady() {}
});