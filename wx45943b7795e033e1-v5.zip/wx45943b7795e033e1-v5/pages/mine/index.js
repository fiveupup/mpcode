var _regeneratorRuntime2 = require("../../@babel/runtime/helpers/regeneratorRuntime");var _asyncToGenerator2 = require("../../@babel/runtime/helpers/asyncToGenerator");var videoAd = null;var _require = require("../../common/apis/tools"),
  getUploadToken = _require.getUploadToken,
  updateAvatar = _require.updateAvatar;var app = getApp();Page({
  /**
   * 页面的初始数据
   */
  data: {
    SHOW_TOP: false,
    showSetting: false,
    userInfo: {}
  },
  toUserInfo: function toUserInfo() {
    wx.navigateTo({
      url: '/p3/user-info/user-info'
    });
  },
  getUserInfo: function getUserInfo(e) {
    var _this = this;
    return _asyncToGenerator2( /*#__PURE__*/_regeneratorRuntime2().mark(function _callee() {
      var userInfo;
      return _regeneratorRuntime2().wrap(function _callee$(_context) {
        while (1) switch (_context.prev = _context.next) {
          case 0:
            _context.next = 2;
            return app.getUser();
          case 2:
            userInfo = _context.sent;
            _this.setData({
              userInfo: userInfo
            });
          case 4:
          case "end":
            return _context.stop();
        }
      }, _callee);
    }))();
  },
  hideTop: function hideTop() {
    this.setData({
      SHOW_TOP: false
    });
  },
  showTop: function showTop() {
    this.setData({
      SHOW_TOP: true
    });
  },
  toSetting: function toSetting() {
    this.setData({
      showSetting: true
    });
  },
  closeSetting: function closeSetting() {
    this.setData({
      showSetting: false
    });
  },
  toZs: function toZs() {
    wx.navigateTo({
      url: "/pages/webview/webview?url=".concat(encodeURIComponent('https://mp.weixin.qq.com/s/crtWaRZGrSh_DUOT9T48Dw'))
    });
    // wx.previewImage({
    //     urls: ['http://pan00.jialidun.vip/zp/dyh.jpg'],
    // })
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function onLoad(options) {
    this.getUserInfo();
    return;

    // 在页面onLoad回调事件中创建激励视频广告实例
    if (wx.createRewardedVideoAd) {
      videoAd = wx.createRewardedVideoAd({
        adUnitId: 'adunit-31246ed1ad2c012c'
      });
      videoAd.onLoad(function () {});
      videoAd.onError(function (err) {});
      videoAd.onClose(function (res) {});
    }
  },
  copyMyId: function copyMyId() {
    wx.setClipboardData({
      data: getApp().globalData.userInfo.id,
      success: function success(res) {
        wx.showToast({
          title: 'id已复制'
        });
      }
    });
    app.addEvent({
      id: "user",
      type: "复制id"
    });
  },
  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function onReady() {},
  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function onShow() {
    this.getUserInfo();
  },
  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function onHide() {},
  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function onUnload() {},
  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function onPullDownRefresh() {},
  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function onReachBottom() {},
  export: function _export() {
    wx.showModal({
      title: "提醒",
      content: "导出属于会员专属功能，您需要观看广告才可使用",
      confirmText: "去使用",
      cancelText: "不用啦",
      success: function success() {
        // 用户触发广告后，显示激励视频广告
        if (videoAd) {
          videoAd.show().catch(function () {
            // 失败重试
            videoAd.load().then(function () {
              return videoAd.show(function (res) {
                console.log("激励广告看完了？", res);
              });
            }).catch(function (err) {
              console.log('激励视频 广告显示失败');
            });
          });
        }
      }
    });
  },
  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function onShareAppMessage() {
    return {
      title: "快来用全能小转盘！",
      path: "/pages/index/index",
      imageUrl: "http://pan00.jialidun.vip/zp/zplogo.jpeg",
      success: function success(e) {
        wx.showToast({
          title: "分享成功！"
        });
      }
    };
  }
});