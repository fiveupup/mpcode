var _regeneratorRuntime2 = require("../../@babel/runtime/helpers/regeneratorRuntime");var _asyncToGenerator2 = require("../../@babel/runtime/helpers/asyncToGenerator");var _require = require("../../utils/requests"),
  login = _require.login,
  getUser = _require.getUser,
  _signUp = _require.signUp;var app = getApp();Page({
  /**
   * 页面的初始数据
   */
  data: {},
  relaunch: function relaunch() {
    wx.reLaunch({
      url: '/pages/start/index'
    });
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function () {
    var _onLoad = _asyncToGenerator2( /*#__PURE__*/_regeneratorRuntime2().mark(function _callee() {
      return _regeneratorRuntime2().wrap(function _callee$(_context) {
        while (1) switch (_context.prev = _context.next) {
          case 0:
            _context.prev = 0;
            wx.showLoading({
              title: '加载中..'
            });
            _context.next = 4;
            return login();
          case 4:
            _context.next = 6;
            return this.getUserInfo();
          case 6:
            wx.hideLoading();
            _context.next = 13;
            break;
          case 9:
            _context.prev = 9;
            _context.t0 = _context["catch"](0);
            console.error(_context.t0);
            app.addEvent({
              id: "login",
              type: "onLoad异常",
              status: "error",
              message: _context.t0
            });
          case 13:
          case "end":
            return _context.stop();
        }
      }, _callee, this, [[0, 9]]);
    }));
    function onLoad() {
      return _onLoad.apply(this, arguments);
    }
    return onLoad;
  }(),
  getUserInfo: function getUserInfo() {
    var _this = this;
    return _asyncToGenerator2( /*#__PURE__*/_regeneratorRuntime2().mark(function _callee2() {
      var data;
      return _regeneratorRuntime2().wrap(function _callee2$(_context2) {
        while (1) switch (_context2.prev = _context2.next) {
          case 0:
            _context2.next = 2;
            return getUser();
          case 2:
            data = _context2.sent;
            if (!(data.code === 4031)) {
              _context2.next = 9;
              break;
            }
            // 用户未注册
            app.addEvent({
              id: "login",
              type: "getUser",
              status: "error",
              msg: "用户未注册"
            });
            _context2.next = 7;
            return _this.signUp();
          case 7:
            _context2.next = 10;
            break;
          case 9:
            if (data.code === 0) {
              app.addEvent({
                id: "login",
                type: "getUser",
                status: "success",
                msg: ""
              });
              console.log("获取到用户信息了", data);
              app.globalData.userInfo = data.data;
              wx.switchTab({
                url: '/pages/index/index'
              });
            } else {
              app.addEvent({
                id: "login",
                type: "getUser",
                status: "error",
                msg: data
              });
              wx.showModal({
                title: '提示',
                content: '拉取数据出错了，请检查网络并重试',
                showCancel: false,
                confirmText: "重试",
                success: function success() {
                  wx.showLoading({
                    title: '加载中..'
                  });
                  _this.getUserInfo();
                }
              });
            }
          case 10:
          case "end":
            return _context2.stop();
        }
      }, _callee2);
    }))();
  },
  signUp: function signUp() {
    var _this2 = this;
    return _asyncToGenerator2( /*#__PURE__*/_regeneratorRuntime2().mark(function _callee3() {
      var _wx$getSystemInfoSync, brand, system, platform, version, model, userInfo, data;
      return _regeneratorRuntime2().wrap(function _callee3$(_context3) {
        while (1) switch (_context3.prev = _context3.next) {
          case 0:
            _wx$getSystemInfoSync = wx.getSystemInfoSync(), brand = _wx$getSystemInfoSync.brand, system = _wx$getSystemInfoSync.system, platform = _wx$getSystemInfoSync.platform, version = _wx$getSystemInfoSync.version, model = _wx$getSystemInfoSync.model;
            userInfo = {
              scene: app.globalData.scene,
              sub_c: app.globalData.sub_c,
              top_c: app.globalData.top_c,
              brand: brand,
              system: system,
              platform: platform,
              model: model,
              version: version
            };
            _context3.next = 4;
            return _signUp(userInfo);
          case 4:
            data = _context3.sent;
            if (data.code == 0) {
              app.addEvent({
                id: "login",
                type: "新用户注册",
                status: "success",
                msg: ""
              });
              app.globalData.userInfo = data.data;
              wx.switchTab({
                url: '/pages/index/index'
              });
            } else {
              wx.showModal({
                title: '提示',
                content: '进入失败，请检查网络并重试',
                showCancel: false,
                confirmText: "重试",
                success: function success() {
                  wx.showLoading({
                    title: '加载中..'
                  });
                  _this2.signUp();
                }
              });
              app.addEvent({
                id: "login",
                type: "新用户注册",
                status: "error",
                msg: data
              });
            }
          case 6:
          case "end":
            return _context3.stop();
        }
      }, _callee3);
    }))();
  },
  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function onReady() {},
  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function onShow() {},
  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function onHide() {},
  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function onUnload() {},
  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function onPullDownRefresh() {},
  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function onReachBottom() {},
  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function onShareAppMessage() {}
});