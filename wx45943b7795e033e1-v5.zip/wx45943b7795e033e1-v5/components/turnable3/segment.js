Component({
  properties: {
    all_num: {
      type: Number
    },
    item: {
      type: Object,
      observer: function observer(value) {
        if (value) {
          var options = {
            color: value.color,
            text: value.text.length > 15 ? value.text.substring(0, 15) + '...' : value.text,
            all_deg: value.deg,
            deg: value.deg > 180 ? [value.deg / 2, value.deg / 2] : [value.deg],
            text_class: "",
            bg_class: ""
          };
          if (value.status === -1) {
            options.text_class = "text-blur";
            options.bg_class = "bg-blur";
          } else if (value.status === -2) {
            options.color = "#333";
            options.text_class = "text-blur";
          } else if (value.status === 0) {
            options.color = value.color;
            options.text_class = "";
            options.bg_class = "";
          }
          this.setData(options);
        }
      }
    },
    radius: {
      type: Number
    }
  },
  data: {
    color: '#000',
    all_deg: 30,
    deg: [30],
    text: "👌🏻",
    text_class: "",
    bg_class: ""
  },
  methods: {}
});