var _regeneratorRuntime2 = require("../../../@babel/runtime/helpers/regeneratorRuntime");var _asyncToGenerator2 = require("../../../@babel/runtime/helpers/asyncToGenerator");var _defineProperty2 = require("../../../@babel/runtime/helpers/defineProperty");var ZhuanPan = require("../../../common/apis/zhuanpan.js");var zp_colors = require("../../../common/zp_colors.js");Component({
  behaviors: [wx.Bus],
  properties: {
    showEdit: {
      type: Boolean
    }
  },
  data: {
    title: "",
    items_obj: [],
    showLoading: false,
    loadingInfo: {
      status: 0,
      text: "加载中..."
    }
  },
  methods: {
    close: function close() {
      var _this = this;
      var zpInfo = this.$bus.store.get("zpInfo");
      // 如果没有修改，直接关闭
      var itemStr = this.data.items_obj.map(function (item) {
        return item.text;
      }).join("");
      var originItemStr = zpInfo.items_obj.map(function (item) {
        return item.text;
      }).join("");
      if (this.data.title === zpInfo.title && itemStr === originItemStr) {
        this.setData({
          showEdit: false
        });
        return;
      }
      // 如果修改了，弹窗提示
      wx.showModal({
        title: "提示",
        content: "您的更改尚未保存，是否放弃编辑转盘？",
        success: function success(res) {
          if (res.confirm) {
            _this.setData({
              showEdit: false
            });
          }
        }
      });
    },
    itemChange: function itemChange(e) {
      var index = e.currentTarget.dataset.index;
      var text = e.detail.value;
      this.setData(_defineProperty2({}, "items_obj[".concat(index, "].text"), text));
    },
    changeTitle: function changeTitle(e) {
      var text = e.detail.value;
      this.setData({
        title: text
      });
    },
    delItem: function delItem(e) {
      if (this.data.items_obj.length < 3) {
        wx.showToast({
          title: "至少保留两个选项哦~",
          icon: "none"
        });
        return;
      }
      var index = e.currentTarget.dataset.index;
      this.data.items_obj.splice(index, 1);
      wx.vibrateShort();
      this.setData({
        focus: false,
        items_obj: this.data.items_obj
      });
      // this.addEvent("删除选项",this.data.items[index],"","success")
    },
    addNewItem: function addNewItem(e) {
      var _this$setData2,
        _this2 = this;
      var items_obj = this.data.items_obj;
      // if (items[items.length - 1] === "") {
      //     this.setData({
      //         focus: true
      //     })
      //     return
      // }
      // 4 位随机数 + 2 位当前 length
      var id = Math.random().toString(36).substr(2, 4) + items_obj.length;
      var newItem = {
        id: id,
        text: "",
        color: zp_colors[items_obj.length % zp_colors.length],
        weight: 1
      };
      this.setData((_this$setData2 = {}, _defineProperty2(_this$setData2, "items_obj[".concat(items_obj.length, "]"), newItem), _defineProperty2(_this$setData2, "focus", true), _this$setData2));
      var query = this.createSelectorQuery();
      query.select('#innerView').boundingClientRect(function (res) {
        _this2.setData({
          scrollTop: res.height + 20
        });
      });
      wx.nextTick(function () {
        query.exec();
      });
    },
    saveItems: function saveItems(e) {
      var _this3 = this;
      return _asyncToGenerator2( /*#__PURE__*/_regeneratorRuntime2().mark(function _callee() {
        var _this3$setData;
        var checkStr, checkPass, res, _this3$setData3, _this3$setData4, _this3$setData5;
        return _regeneratorRuntime2().wrap(function _callee$(_context) {
          while (1) switch (_context.prev = _context.next) {
            case 0:
              // this.data.items = this.data.items.filter(item => item)
              _this3.setData((_this3$setData = {
                showLoading: true
              }, _defineProperty2(_this3$setData, "loadingInfo.status", 0), _defineProperty2(_this3$setData, "loadingInfo.text", "保存中.."), _this3$setData));
              checkStr = _this3.data.items_obj.map(function (item) {
                return item.text;
              }).join("") + _this3.data.title;
              _context.next = 4;
              return ZhuanPan.checkMsg(checkStr);
            case 4:
              checkPass = _context.sent;
              if (!checkPass) {
                _this3.setData(_defineProperty2({}, "loadingInfo.text", "转盘中存在敏感词汇，正在逐个检查.."));
              }
              _context.prev = 6;
              _context.next = 9;
              return ZhuanPan.updateOne({
                id: _this3.$bus.store.get("zpInfo").id,
                title: _this3.data.title,
                items_obj: _this3.data.items_obj
              });
            case 9:
              res = _context.sent;
              if (res.code === 0) {
                _this3.setData((_this3$setData3 = {}, _defineProperty2(_this3$setData3, "loadingInfo.status", 1), _defineProperty2(_this3$setData3, "loadingInfo.text", "保存成功"), _this3$setData3));
                _this3.$bus.event.emit("edit:saveSuccess", {
                  zpInfo: res.data
                });
                getApp().globalData._updateZpList = true;
              } else {
                _this3.setData((_this3$setData4 = {}, _defineProperty2(_this3$setData4, "loadingInfo.status", -1), _defineProperty2(_this3$setData4, "loadingInfo.text", JSON.stringify(res)), _this3$setData4));
              }
              _context.next = 17;
              break;
            case 13:
              _context.prev = 13;
              _context.t0 = _context["catch"](6);
              _this3.setData((_this3$setData5 = {}, _defineProperty2(_this3$setData5, "loadingInfo.status", -1), _defineProperty2(_this3$setData5, "loadingInfo.text", JSON.stringify(_context.t0)), _this3$setData5));
              throw _context.t0;
            case 17:
            case "end":
              return _context.stop();
          }
        }, _callee, null, [[6, 13]]);
      }))();
    },
    hideLoading: function hideLoading() {
      this.setData({
        showLoading: false,
        showEdit: false
      });
    }
  },
  lifetimes: {
    attached: function attached() {
      var _this4 = this;
      this.$bus.event.export("edit:showEdit", function (_ref) {
        var zpInfo = _ref.zpInfo;
        console.log(zpInfo);
        _this4.setData({
          items_obj: JSON.parse(JSON.stringify(zpInfo.items_obj)),
          title: zpInfo.title,
          showEdit: true
        });
      });
      this.$bus.event.on("edit:hideEdit", function () {
        _this4.setData({
          showEdit: false
        });
      });
    }
  }
});