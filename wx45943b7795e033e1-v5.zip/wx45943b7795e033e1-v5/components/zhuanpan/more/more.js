var _regeneratorRuntime2 = require("../../../@babel/runtime/helpers/regeneratorRuntime");var _defineProperty2 = require("../../../@babel/runtime/helpers/defineProperty");var _asyncToGenerator2 = require("../../../@babel/runtime/helpers/asyncToGenerator");var _require = require("../../../utils/requests"),
  getTTS = _require.getTTS;var app = getApp();Component({
  behaviors: [wx.Bus],
  properties: {},
  data: {
    showMore: false,
    settings: {
      vibrate: true,
      sound: true,
      speaker: "1"
    },
    speakers: [{
      text: "不需要播报转盘结果",
      value: "none"
    }, {
      text: "情感女声-智瑜",
      value: "1001"
    }, {
      text: "知性女声-智娜",
      value: "1007"
    }, {
      text: "通用女声-智莉",
      value: "1005"
    }, {
      text: "通用男声-智华",
      value: "1"
    }, {
      text: "情感男声-智靖",
      value: "1018"
    }, {
      text: "情感男声-智云",
      value: "1004"
    }]
  },
  methods: {
    showMore: function showMore() {
      this.setData({
        showMore: true
      });
    },
    hideMore: function hideMore() {
      this.setData({
        showMore: false
      });
    },
    showShare: function showShare() {
      this.$bus.event.call("share:showShare");
    },
    shareMyZp: function shareMyZp() {
      var zpInfo = this.$bus.get("zpInfo");
      if (zpInfo.id.startsWith("template_") || zpInfo.openid !== app.globalData.openid) {
        wx.showToast({
          title: '请先保存当前转盘，才可以分享哦！',
          icon: 'none'
        });
        return;
      }
      this.setData({
        showMore: false
      });
      this.$bus.event.emit("share-settings:show");
    },
    settingsChange: function settingsChange(e) {
      var _this = this;
      return _asyncToGenerator2( /*#__PURE__*/_regeneratorRuntime2().mark(function _callee() {
        var type, value, res;
        return _regeneratorRuntime2().wrap(function _callee$(_context) {
          while (1) switch (_context.prev = _context.next) {
            case 0:
              type = e.currentTarget.dataset.type;
              value = e.detail;
              _this.setData(_defineProperty2({}, "settings.".concat(type), value));
              if (!(type === "speaker")) {
                _context.next = 10;
                break;
              }
              if (!(value === "none")) {
                _context.next = 6;
                break;
              }
              return _context.abrupt("return");
            case 6:
              _context.next = 8;
              return getTTS("欢迎使用全能小转盘", value);
            case 8:
              res = _context.sent;
              if (res.code === 0) {
                _this.audioCtx.src = res.data;
                _this.audioCtx.play();
              }
            case 10:
              _this.updateSettings();
            case 11:
            case "end":
              return _context.stop();
          }
        }, _callee);
      }))();
    },
    updateSettings: function updateSettings() {
      this.$bus.store.set('settings', this.data.settings);
      wx.setStorageSync('settings', this.data.settings);
    },
    showDyh: function showDyh() {
      wx.navigateTo({
        url: "/pages/webview/webview?url=".concat(encodeURIComponent('https://mp.weixin.qq.com/s/crtWaRZGrSh_DUOT9T48Dw'))
      });
    }
  },
  lifetimes: {
    attached: function attached() {
      var _this2 = this;
      var settings = wx.getStorageSync('settings') || this.data.settings;
      this.$bus.store.set('settings', settings);
      this.$bus.event.export('more:showMore', function () {
        _this2.showMore();
        _this2.setData({
          settings: settings
        });
      });
      this.$bus.event.export('more:hiddenMore', function () {
        _this2.hideMore();
      });
      this.audioCtx = wx.createInnerAudioContext();
    },
    detached: function detached() {
      if (this.audioCtx) {
        this.audioCtx.destroy();
      }
    }
  }
});