Component({
  behaviors: [wx.Bus],
  properties: {},
  data: {
    show: false,
    all: 0,
    used: 0
  },
  methods: {
    toReset: function toReset() {
      this.$bus.event.call("black:clearBlack");
    },
    toDetail: function toDetail() {
      var zpItems = JSON.parse(JSON.stringify(this.$bus.get('zpInfo').items_obj));
      var cacheKey = "zp_".concat(this.$bus.get('zpInfo').id);
      wx.navigateTo({
        url: "/pages/zhuanpan/summarize_page/summarize_page",
        success: function success(res) {
          res.eventChannel.emit('getData', {
            zpItems: zpItems,
            cacheKey: cacheKey
          });
        }
      });
    }
  },
  lifetimes: {
    attached: function attached() {
      var _this = this;
      this.$bus.event.export("summarize_bar:updateCount", function (count) {
        var zpInfo = _this.$bus.store.get("zpInfo");
        console.log("summarize_bar:updateCount", count, zpInfo);
        _this.setData({
          used: count,
          all: zpInfo.items_obj.length
        });
      });
      this.$bus.event.on("page:zpInfoLoaded", function () {
        var zpInfo = _this.$bus.store.get("zpInfo");
        if (_this.$bus.store.get("shouldSaveResult")) {
          return;
        }
        _this.setData({
          show: zpInfo.settings && zpInfo.settings.no_repeat
        });
      });
      this.$bus.event.export("summarize_bar:updateShow", function () {
        var zpInfo = _this.$bus.store.get("zpInfo");
        if (!_this.$bus.store.get("shouldSaveResult")) {
          _this.setData({
            show: zpInfo.settings && zpInfo.settings.no_repeat
          });
        }
      });
    }
  }
});