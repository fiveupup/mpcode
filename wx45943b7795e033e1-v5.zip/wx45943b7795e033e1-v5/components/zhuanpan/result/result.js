var _regeneratorRuntime2 = require("../../../@babel/runtime/helpers/regeneratorRuntime");var _asyncToGenerator2 = require("../../../@babel/runtime/helpers/asyncToGenerator");var _require = require("../../../utils/hash"),
  sensitiveHash = _require.sensitiveHash;var ZhuanpanApi = require("../../../common/apis/zhuanpan");var app = getApp();Component({
  behaviors: [wx.Bus],
  /**
   * 组件的属性列表
   */
  properties: {},
  /**
   * 组件的初始数据
   */
  data: {
    result: "??",
    showShare: false
  },
  /**
   * 组件的方法列表
   */
  methods: {
    onTapResult: function onTapResult() {
      var _this = this;
      if (!this.data.result) return;
      if (!this.data.showShare) return;
      wx.showActionSheet({
        itemList: ['复制结果'],
        // 查看转盘记录
        success: function success(res) {
          if (res.tapIndex === 0) {
            _this.toCopy();
          }
        }
      });
    },
    toCopy: function toCopy() {
      if (!this.data.result) return;
      if (!this.data.showShare) return;
      wx.setClipboardData({
        data: this.data.result,
        success: function success() {
          wx.showToast({
            title: '转盘结果复制成功',
            icon: 'none'
          });
        }
      });
    },
    uploadResult: function uploadResult(data) {
      var _this2 = this;
      return _asyncToGenerator2( /*#__PURE__*/_regeneratorRuntime2().mark(function _callee() {
        var zpInfo, zp_id, text, weight, id, hash, res;
        return _regeneratorRuntime2().wrap(function _callee$(_context) {
          while (1) switch (_context.prev = _context.next) {
            case 0:
              console.log("uploadResult", data);
              zpInfo = _this2.$bus.get("zpInfo");
              zp_id = zpInfo.id;
              text = data.text, weight = data.weight, id = data.id;
              hash = sensitiveHash(zp_id + id + weight + text);
              _context.next = 7;
              return ZhuanpanApi.createZpRecord({
                zp_id: zp_id,
                item_id: id,
                item_text: text,
                weight: weight,
                key: hash
              });
            case 7:
              res = _context.sent;
            case 8:
            case "end":
              return _context.stop();
          }
        }, _callee);
      }))();
    }
  },
  lifetimes: {
    attached: function attached() {
      var _this3 = this;
      this.$bus.on('zhuanpan:step', function (data) {
        if (!data) return;
        if (data.text === _this3.data.result) return;
        if (_this3.$bus.get('settings').vibrate) {
          wx.vibrateShort();
        }
        _this3.setData({
          result: data.text,
          showShare: false
        });
      });
      this.$bus.on('zhuanpan:stop', function (data) {
        if (!data) return;
        if (_this3.$bus.store.get('shouldSaveResult') && _this3.$bus.store.get('recordsTimes') <= _this3.$bus.store.get('zpInfo').share_settings.p_times) {
          // 上传结果
          _this3.uploadResult(data).then( /*#__PURE__*/_asyncToGenerator2( /*#__PURE__*/_regeneratorRuntime2().mark(function _callee2() {
            var userInfo;
            return _regeneratorRuntime2().wrap(function _callee2$(_context2) {
              while (1) switch (_context2.prev = _context2.next) {
                case 0:
                  _this3.$bus.event.call("page:updateRecordsTimes");
                  _context2.next = 3;
                  return app.getUser();
                case 3:
                  userInfo = _context2.sent;
                  if (!userInfo.wx_name) {
                    wx.showModal({
                      title: '未设置昵称',
                      content: '检测到您尚未设置昵称，设置昵称后，您的转盘结果将会显示在转盘记录中',
                      confirmText: "去设置",
                      cancelText: "暂不设置",
                      success: function success(res) {
                        if (res.confirm) {
                          wx.navigateTo({
                            url: '/p3/user-info/user-info'
                          });
                        }
                      }
                    });
                  }
                case 5:
                case "end":
                  return _context2.stop();
              }
            }, _callee2);
          })));
        }
        if (_this3.$bus.get('settings').vibrate) {
          wx.vibrateLong();
        }
        _this3.setData({
          result: data.text,
          showShare: true
        });
      });
      this.$bus.on("page:zpInfoLoaded", function () {
        _this3.setData({
          result: "??",
          showShare: false
        });
      });
      this.$bus.on("page:recoveryZp", function () {
        _this3.setData({
          result: "??",
          showShare: false
        });
      });
    }
  }
});