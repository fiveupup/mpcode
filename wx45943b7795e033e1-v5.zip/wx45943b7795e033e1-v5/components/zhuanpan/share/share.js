var _regeneratorRuntime2 = require("../../../@babel/runtime/helpers/regeneratorRuntime");var _asyncToGenerator2 = require("../../../@babel/runtime/helpers/asyncToGenerator");var _require = require("../../../utils/requests"),
  draws = _require.draws;Component({
  behaviors: [wx.Bus],
  properties: {},
  data: {
    showShare: false,
    options: [{
      name: '微信',
      icon: 'wechat',
      openType: 'share'
    }, {
      name: '复制页面路径',
      icon: 'link'
    }
    // { name: '小程序码', icon: 'weapp-qrcode' },
    ]
  },

  methods: {
    onSelectShare: function onSelectShare(option) {
      console.log(option);
      if (option.detail.index === 0) {
        this.onCloseShare();
        this.$bus.event.call("more:hiddenMore");
      }
      if (option.detail.index === 1) {
        this.copyPath();
        // this.genWXQrcode()
      }
    },
    copyPath: function copyPath() {
      var zpInfo = this.$bus.store.get('zpInfo');
      wx.setClipboardData({
        data: "/pages/zhuanpan/index/index?type=share&id=".concat(zpInfo.id00 || zpInfo.id),
        success: function success() {
          wx.showModal({
            title: '复制成功',
            content: '你可以将当前转盘添加到公众号文章或者小程序里面',
            cancelText: '关闭',
            confirmText: '查看教程',
            success: function success(res) {
              if (res.confirm) {
                wx.navigateTo({
                  url: "/pages/webview/webview?url=".concat(encodeURIComponent('https://mp.weixin.qq.com/s/_pMYjUnZ6R5zD7I__SlQZQ'))
                });
              }
            }
          });
        }
      });
    },
    genWXQrcode: function genWXQrcode() {
      var _this = this;
      return _asyncToGenerator2( /*#__PURE__*/_regeneratorRuntime2().mark(function _callee() {
        var r, url;
        return _regeneratorRuntime2().wrap(function _callee$(_context) {
          while (1) switch (_context.prev = _context.next) {
            case 0:
              _context.next = 2;
              return draws.getWXQrcode({
                id: _this.$bus.store.get('zpInfo').id
              });
            case 2:
              r = _context.sent;
              url = wx.createBufferURL(r.data);
              console.log("url11", url);
              wx.previewImage({
                urls: [url]
              });
            case 6:
            case "end":
              return _context.stop();
          }
        }, _callee);
      }))();
    },
    onCloseShare: function onCloseShare() {
      this.setData({
        showShare: false
      });
    }
  },
  lifetimes: {
    attached: function attached() {
      var _this2 = this;
      this.$bus.event.export('share:showShare', function () {
        _this2.setData({
          showShare: true
        });
      });
    }
  }
});