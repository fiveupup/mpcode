module.exports = Behavior({
  behaviors: [wx.Bus],
  data: {},
  methods: {
    initBlack: function initBlack() {
      this.cacheKey = "zp_".concat(this.$bus.get('zpInfo').id);
      this.blackItems = wx.getStorageSync(this.cacheKey) || [];
      this.blackItems = this.blackItems.filter(function (i) {
        return i;
      });
      this.$bus.store.set("blackItemsId", this.blackItems);
      console.log("初始化转盘黑名单", this.blackItems);
      if (this.blackItems.length >= 0) {
        this.$bus.event.call("summarize_bar:updateCount", this.blackItems.length);
      }
    },
    clearBlack: function clearBlack() {
      wx.removeStorageSync(this.cacheKey);
      this.blackItems = [];
      this.$bus.store.set("blackItemsId", this.blackItems);
      this.$bus.event.call("summarize_bar:updateCount", this.blackItems.length);
    },
    addBlack: function addBlack(item) {
      var zpInfo = this.$bus.get('zpInfo');
      if (!zpInfo.settings || !zpInfo.settings.no_repeat) return;
      this.blackItems.push(item.id);
      wx.setStorageSync(this.cacheKey, this.blackItems);
      this.$bus.event.call("summarize_bar:updateCount", this.blackItems.length);
    },
    removeBlack: function removeBlack(item) {
      var index = this.blackItems.findIndex(function (i) {
        return i.id === item.id;
      });
      if (index > -1) {
        this.blackItems.splice(index, 1);
        wx.setStorageSync(this.cacheKey, this.blackItems);
        this.$bus.event.call("summarize_bar:updateCount", this.blackItems.length);
      }
    },
    getBlackLength: function getBlackLength() {
      return this.blackItems.length;
    },
    checkIsInBlack: function checkIsInBlack(item) {
      if (!item) return false;
      return this.blackItems.includes(item.id);
    }
  },
  lifetimes: {
    attached: function attached() {
      var _this = this;
      this.$bus.event.on("page:zpInfoLoaded", this.initBlack.bind(this));
      this.$bus.event.on("page:recoveryZp", this.clearBlack.bind(this));
      this.$bus.event.on("zhuanpan:stop", function (result) {
        _this.addBlack(result);
      });
      this.$bus.event.export("black:addBlack", this.addBlack.bind(this));
      this.$bus.event.export("black:removeBlack", this.removeBlack.bind(this));
      this.$bus.event.export("black:getBlackLength", this.getBlackLength.bind(this));
      this.$bus.event.export("black:checkIsInBlack", this.checkIsInBlack.bind(this));
      this.$bus.event.export("black:clearBlack", this.clearBlack.bind(this));
      this.$bus.event.export("black:initBlack", this.initBlack.bind(this));
      this.$bus.event.export("black:getBlackItemsIndex", function (item_map) {
        var res = [];
        _this.blackItems.forEach(function (item) {
          if (item_map[item]) {
            res.push(item_map[item].index);
          }
        });
        return res;
      });
    }
  }
});