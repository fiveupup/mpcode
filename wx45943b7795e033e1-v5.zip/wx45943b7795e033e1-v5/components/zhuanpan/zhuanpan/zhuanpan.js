var _createForOfIteratorHelper2 = require("../../../@babel/runtime/helpers/createForOfIteratorHelper");var _objectSpread2 = require("../../../@babel/runtime/helpers/objectSpread2");var Black = require("./black");Component({
  /**
   * 页面的初始数据
   */
  data: {
    all_weight: 0,
    showItems: []
  },
  properties: {
    radius: {
      type: Number,
      value: 158
    }
  },
  behaviors: [require('./audio.js'), require('./control.js'), wx.Bus, Black],
  methods: {
    initItems: function initItems() {
      var item_map = {};
      var items = this.$bus.get("zpInfo").items_obj;
      items = items.map(function (item, index) {
        var obj = _objectSpread2({}, item);
        obj.index = index;
        item_map[item.id] = obj;
        return obj;
      });
      var showItems = JSON.parse(JSON.stringify(items));
      var all_weight = 0;
      showItems.forEach(function (item) {
        all_weight += item.weight;
      });
      var showItemsCurrentDeg = 0;
      var allWeightItems = [];
      for (var i = 0; i < showItems.length; i++) {
        var item = showItems[i];
        item.deg = item.weight / all_weight * 360;
        if (showItemsCurrentDeg === 0) {
          showItemsCurrentDeg = item.deg / 2;
        }
        item.endDeg = showItemsCurrentDeg;
        item.startDeg = showItemsCurrentDeg - item.deg;
        item.status = 0;
        showItemsCurrentDeg = item.startDeg;
        for (var j = 0; j < item.weight; j++) {
          allWeightItems.push(i);
        }
      }
      var realItems = JSON.parse(JSON.stringify(items));
      var realItemsCurrentDeg = 0;
      var _iterator = _createForOfIteratorHelper2(realItems),
        _step;
      try {
        for (_iterator.s(); !(_step = _iterator.n()).done;) {
          var _item = _step.value;
          _item.deg = _item.weight / all_weight * 360;
          if (realItemsCurrentDeg === 0) {
            realItemsCurrentDeg = -_item.deg / 2;
          }
          _item.startDeg = realItemsCurrentDeg;
          _item.status = 0;
          _item.deg = _item.weight / all_weight * 360;
          _item.endDeg = realItemsCurrentDeg + _item.deg;
          realItemsCurrentDeg = _item.endDeg;
        }
        // console.log("realItems",realItems)
        // console.log("showItems",showItems)
      } catch (err) {
        _iterator.e(err);
      } finally {
        _iterator.f();
      }
      this.$bus.set('showItems', showItems);
      this.$bus.set('realItems', realItems);
      this.$bus.set('allWeightItems', allWeightItems);
      this.$bus.set('item_map', item_map);
      this.setData({
        showItems: showItems,
        all_weight: all_weight
      });
    },
    initZpItems2: function initZpItems2() {
      var zpInfo = this.$bus.get("zpInfo");
      if (!zpInfo.settings || !zpInfo.settings.hide_weight) {
        this.initItems();
        return;
      }
      var item_map = {};
      var items = zpInfo.items_obj;
      items = items.map(function (item, index) {
        var obj = _objectSpread2({}, item);
        obj.index = index;
        item_map[item.id] = obj;
        return obj;
      });
      var showItems = JSON.parse(JSON.stringify(items));
      var all_weight = 0;
      showItems.forEach(function (item) {
        all_weight += item.weight;
      });
      var showItemsCurrentDeg = 0;
      var allWeightItems = [];
      for (var i = 0; i < showItems.length; i++) {
        var item = showItems[i];
        item.deg = 360 / showItems.length;
        if (showItemsCurrentDeg === 0) {
          showItemsCurrentDeg = item.deg / 2;
        }
        item.endDeg = showItemsCurrentDeg;
        item.startDeg = showItemsCurrentDeg - item.deg;
        item.status = 0;
        showItemsCurrentDeg = item.startDeg;
        for (var j = 0; j < item.weight; j++) {
          allWeightItems.push(i);
        }
      }

      // showitem是反着的，
      var realItems = JSON.parse(JSON.stringify(items));
      var realItemsCurrentDeg = 0;
      for (var _i = 0; _i < realItems.length; _i++) {
        var _item2 = realItems[_i];
        _item2.deg = 360 / showItems.length;
        if (realItemsCurrentDeg === 0) {
          realItemsCurrentDeg = -_item2.deg / 2;
        }
        _item2.startDeg = realItemsCurrentDeg;
        _item2.status = 0;
        _item2.endDeg = realItemsCurrentDeg + _item2.deg;
        realItemsCurrentDeg = _item2.endDeg;
      }
      console.log("realItems", realItems);
      console.log("showItems", showItems);
      this.$bus.set('showItems', showItems);
      this.$bus.set('realItems', realItems);
      this.$bus.set('allWeightItems', allWeightItems);
      this.$bus.set('item_map', item_map);
      this.setData({
        showItems: showItems,
        all_weight: all_weight
      });
    },
    initZpRadius: function initZpRadius() {
      var _wx$getSystemInfoSync = wx.getSystemInfoSync(),
        windowWidth = _wx$getSystemInfoSync.windowWidth,
        windowHeight = _wx$getSystemInfoSync.windowHeight;
      var radius = Math.floor(Math.min(windowWidth, windowHeight) * 0.93 / 2);
      radius = Math.min(radius, windowHeight / 3);
      this.setData({
        radius: radius
      });
    }
  },
  lifetimes: {
    attached: function attached() {
      this.$bus.on("page:zpInfoLoaded", this.initZpItems2.bind(this));
      this.initZpRadius();
    }
  }
});