require("../../../@babel/runtime/helpers/Arrayincludes");var app = getApp();var _require = require("../../../common/utils"),
  checkIsInBlack = _require.checkIsInBlack;function easeInOutSine(x) {
  return Math.sqrt(1 - Math.pow(x - 1, 2));
}module.exports = Behavior({
  behaviors: [wx.Bus],
  data: {
    style: ""
  },
  lifetimes: {
    detached: function detached() {
      console.log("control detached");
      this.clearTimer();
    },
    attached: function attached() {
      // 初始化数据
      this.$bus.event.on("page:zpInfoLoaded", this.resetZp.bind(this));
      this.$bus.on("page:recoveryZp", this.recoveryZp.bind(this));
    }
  },
  methods: {
    recoveryZp: function recoveryZp() {
      // 还原转盘
      var showItems = this.$bus.get('showItems');
      showItems.forEach(function (item) {
        item.status = 0;
      });
      this.setData({
        showItems: showItems
      });
    },
    resetZp: function resetZp() {
      console.log("resetZp");
      this.state = "stopped"; // stopped, running 转盘状态
      this.lastTurn = 0; // 上一次转动的角度
      this.result = ""; // 转盘结果
      // 随机3位数字
      this.turnId = Math.floor(Math.random() * 1000);
      this.setData({
        style: ""
      });
    },
    clearTimer: function clearTimer() {
      if (this.timer) {
        clearTimeout(this.timer);
        this.timer = null;
      }
    },
    checkLeftTimes: function checkLeftTimes() {
      if (!this.$bus.store.get('shouldSaveResult')) {
        return;
      }
      console.log("检查次数", this.$bus.store.get('recordsTimes'), this.$bus.store.get('zpInfo').share_settings.p_times);
      if (this.$bus.store.get('recordsTimes') >= this.$bus.store.get('zpInfo').share_settings.p_times) {
        console.log("您的数已用完");
        wx.showToast({
          title: "您的数已用完",
          icon: "none"
        });
      }
    },
    start: function start() {
      var _this = this;
      this.checkLeftTimes();
      this.clearTimer();
      this.turnId = Math.floor(Math.random() * 1000);
      var showItems = this.$bus.get('showItems');
      showItems.forEach(function (item) {
        item.status = 0;
      });
      this.setData({
        showItems: showItems
      });
      var blackItemsId = this.$bus.get('blackItemsId');
      if (blackItemsId.length === showItems.length) {
        this.$bus.event.call("black:clearBlack");
        return;
      }
      this.$bus.set('state', 'running');
      this.$bus.emit("zhuanpan:start");
      var allWeightItems = this.$bus.store.get('allWeightItems');
      var resultAllWeightItems = allWeightItems;
      var items = this.$bus.store.get('realItems');
      var blackItemsIndex = this.$bus.event.call("black:getBlackItemsIndex", this.$bus.get('item_map'));
      console.log("blackItemsIndex", blackItemsIndex);
      if (blackItemsIndex.length > 0) {
        // 过滤黑名单
        resultAllWeightItems = allWeightItems.filter(function (index) {
          return !blackItemsIndex.includes(index);
        });
        console.log("过滤黑名单", resultAllWeightItems);
      }

      // 额外旋转的圈数
      var extraTurn = 3;
      // 计算随机的选项和时间
      var randomIndex = Math.floor(Math.random() * resultAllWeightItems.length);
      var resultIndex = resultAllWeightItems[randomIndex];
      // 此次要转动的角度
      // (items[resultIndex].startDeg + items[resultIndex].deg/2)
      // 开始值 + 当前值/2 表示在当前扇形中间
      if (!items[resultIndex]) return;
      this.currentTurn = extraTurn + (items[resultIndex].startDeg + items[resultIndex].deg / 2) / 360 + (1 - this.lastTurn % 1);
      var _lastTurn = this.lastTurn;
      this.lastTurn += this.currentTurn;
      // 此次的结果
      this.result = items[resultIndex];
      // console.log("result", this.result)

      // 此次转动的时间
      var turnSeconds;
      if (this.$bus.store.get('zpInfo').settings && this.$bus.store.get('zpInfo').settings.seconds) {
        turnSeconds = this.$bus.store.get('zpInfo').settings.seconds;
      }
      var turnTime = turnSeconds ? turnSeconds * 1000 : this.currentTurn * 1000;
      var style = "transform: rotate(".concat(_lastTurn + this.currentTurn, "turn);transition: all ").concat(turnTime, "ms cubic-bezier(0, 0.55, 0.45, 1);");
      this.setData({
        style: style
      });
      var startT = Date.now();
      var timeGap = 120;
      var turnId = this.turnId;
      var newframe = function newframe() {
        if (!_this.$bus) {
          return;
        }
        var currentT = Date.now() - startT;
        if (currentT >= turnTime) {
          return;
        }
        if (turnId !== _this.turnId) {
          // wx.showToast({
          //     title: "哎哟,你干嘛～",
          //     icon: "none"
          // })
          wx.vibrateShort();
          _this.notShowResult = true;
          return;
        }
        var currentDeg = easeInOutSine(currentT / turnTime) * _this.currentTurn * 360 + _lastTurn % 1 * 360;
        currentDeg = currentDeg % 360;
        currentDeg -= items[0].deg / 2;
        currentDeg = currentDeg < 0 ? currentDeg + 360 : currentDeg;
        var currentItemIndex = Math.ceil(currentDeg / 360 * allWeightItems.length) % allWeightItems.length;
        var currentItem = items[allWeightItems[currentItemIndex]];
        var zpInfo = _this.$bus.store.get('zpInfo');
        if (zpInfo.settings && zpInfo.settings.hide_weight) {
          currentItemIndex = Math.ceil(currentDeg / 360 * zpInfo.items_obj.length) % zpInfo.items_obj.length;
          currentItem = zpInfo.items_obj[currentItemIndex];
        }
        if (!_this.notShowResult) {
          _this.$bus.emit("zhuanpan:step", currentItem);
        } else {
          _this.$bus.emit("zhuanpan:step", {
            text: "??"
          });
        }
        _this.timer = setTimeout(function () {
          newframe();
        }, timeGap);
      };
      newframe();

      // let query= this.createSelectorQuery()
      // let frame = ()=>{
      //     query.select('#zhuanpan').fields({
      //         computedStyle: ['transform'],
      //     },  ({transform})=>{
      //         // 提取matrix变换中的a、b、c和d值
      //         const matrix = transform.match(/^matrix\((.+)\)$/)[1].split(",");
      //         const a = parseFloat(matrix[0]);
      //         const b = parseFloat(matrix[1]);
      //
      //         // 计算旋转角度，并转换为turn
      //         let angle = Math.atan2(b, a) * (180 / Math.PI);
      //         angle -= items[0].deg/2
      //         angle = angle < 0 ? angle + 360 : angle;
      //         let currentItemIndex = Math.ceil(angle/360 * allWeightItems.length)%allWeightItems.length
      //         let currentItem = items[allWeightItems[currentItemIndex]]
      //         this.$bus.emit("zhuanpan:step", currentItem)
      //     }).exec()
      //     if (this.$bus.store.get('state') === "stopped") return
      //     this.$bus.setTimeout(frame,timeGap)
      // }
      // frame()
    },
    shotResult: function shotResult() {
      var result = this.$bus.get('result');
      console.log(result);
      var showItems = this.$bus.get('showItems');
      showItems.forEach(function (item) {
        if (item.index === result.index) {
          item.status = 0;
        } else {
          item.status = -1;
        }
      });
      this.setData({
        showItems: showItems
      });
    },
    onZpStopped: function onZpStopped(e) {
      this.notShowResult = false;
      this.$bus.set('state', 'stopped');
      this.$bus.set('result', this.result);
      this.$bus.emit("zhuanpan:stop", this.result);
      this.shotResult();
    },
    longtap: function longtap(e) {
      wx.vibrateLong();
      this.start();
    }
  }
});