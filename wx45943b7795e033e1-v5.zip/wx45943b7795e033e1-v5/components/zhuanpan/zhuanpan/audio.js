var _regeneratorRuntime2 = require("../../../@babel/runtime/helpers/regeneratorRuntime");var _asyncToGenerator2 = require("../../../@babel/runtime/helpers/asyncToGenerator");var _require = require("../../../utils/requests"),
  getTTS = _require.getTTS;module.exports = Behavior({
  behaviors: [wx.Bus],
  properties: {},
  data: {
    audioCtx: {
      audio: null
    },
    audioIndex: 0
  },
  methods: {
    playAudio: function playAudio() {
      this.data.audioCtx.audio.seek(0);
      this.data.audioCtx.audio.play();
    }
  },
  lifetimes: {
    attached: function attached() {
      var _this = this;
      if (!this.data.audioCtx.audio) {
        this.data.audioCtx.audio = wx.createInnerAudioContext();
        this.data.audioCtx.audio.src = "http://pan00.jialidun.vip/audio/win.mp3";
        this.data.audioCtx.audio.volume = 0.8;
      }
      this.$bus.event.on("zhuanpan:stop", /*#__PURE__*/function () {
        var _ref = _asyncToGenerator2( /*#__PURE__*/_regeneratorRuntime2().mark(function _callee(data) {
          var tts, link;
          return _regeneratorRuntime2().wrap(function _callee$(_context) {
            while (1) switch (_context.prev = _context.next) {
              case 0:
                if (!_this.$bus.get('settings').sound) {
                  _context.next = 13;
                  break;
                }
                _this.playAudio();
                if (!(_this.$bus.get('settings').speaker === "none")) {
                  _context.next = 4;
                  break;
                }
                return _context.abrupt("return");
              case 4:
                _context.next = 6;
                return getTTS(data.text, _this.$bus.get('settings').speaker || 1);
              case 6:
                tts = _context.sent;
                if (!(tts.code !== 0)) {
                  _context.next = 9;
                  break;
                }
                return _context.abrupt("return");
              case 9:
                link = tts.data;
                if (!_this.ttsAudio) {
                  _this.ttsAudio = wx.createInnerAudioContext();
                }
                _this.ttsAudio.src = link;
                _this.ttsAudio.play();
              case 13:
              case "end":
                return _context.stop();
            }
          }, _callee);
        }));
        return function (_x) {
          return _ref.apply(this, arguments);
        };
      }());
    },
    ready: function ready() {
      console.log("result ready");
      if (!this.ttsAudio) {
        this.ttsAudio = wx.createInnerAudioContext();
      }
    },
    detached: function detached() {
      if (!this.$bus) return;
      this.$bus.event.off("zhuanpan:stop");
      if (this.ttsAudio) {
        this.ttsAudio.destroy();
      }
    }
  }
});