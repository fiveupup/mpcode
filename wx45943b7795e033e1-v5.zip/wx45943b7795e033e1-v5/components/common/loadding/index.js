var app = getApp();Component({
  properties: {
    text: {
      type: String,
      value: "加载中.."
    },
    successText: {
      type: String,
      value: "已成功"
    },
    show: {
      type: Boolean,
      value: false,
      observer: function observer(newVal) {
        if (newVal === false) {
          this.setData({
            status: 1
          });
        } else {
          this.setData({
            showLoading: true,
            status: 0
          });
        }
      }
    }
  },
  data: {
    ad: app.getAd('loading'),
    showLoading: false,
    status: 0
  },
  methods: {
    hideThis: function hideThis() {
      clearTimeout(this.timer ? this.timer : null);
      this.setData({
        showLoading: false
      });
    }
  }
});