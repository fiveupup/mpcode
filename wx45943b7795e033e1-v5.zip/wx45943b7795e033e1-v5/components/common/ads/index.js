var app = getApp();Component({
  lifetimes: {
    attached: function attached() {}
  },
  /**
   * 组件的属性列表
   */
  properties: {
    position: {
      type: String
    },
    adWidth: {
      type: String
    }
  },
  /**
   * 组件的初始数据
   */
  data: {
    show: true,
    ad_id: 'adunit-a004f1f9f9c42946'
  },
  /**
   * 组件的方法列表
   */
  methods: {
    onClose: function onClose() {
      this.setData({
        show: false
      });
    },
    // 广告生命周期
    adLoad: function adLoad() {},
    adError: function adError(err) {
      this.setData({
        show: false
      });
      console.log('Banner 广告加载失败', err);
    },
    onAdError: function onAdError(e) {
      console.log('onAdError', e);
      //  有错误时，不显示广点通广告
      this.setData({
        show: false
      });
    }
  }
});