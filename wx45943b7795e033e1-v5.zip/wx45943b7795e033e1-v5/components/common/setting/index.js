var app = getApp();Component({
  properties: {
    showSetting: {
      type: Boolean,
      value: false,
      observer: function observer(newVal, oldVal, changedPath) {
        this.setData({
          settings: app.getSettings()
        });
      }
    }
  },
  data: {
    settings: app.getSettings(),
    ad: app.getAd('setting')
  },
  methods: {
    changeSetting: function changeSetting(e) {
      var key = e.currentTarget.dataset.key;
      app.globalData.settings[key] = e.detail;
      wx.setStorageSync("settings", app.globalData.settings);
      this.setData({
        settings: app.getSettings()
      });
      this.triggerEvent("updateSetting");
    },
    closeSetting: function closeSetting() {
      this.triggerEvent("closeSetting");
    }
  }
});