Component({
  properties: {
    showClose: {
      type: Boolean
    }
  },
  data: {
    show: true
  },
  methods: {
    close: function close() {
      this.setData({
        show: false
      });
    }
  }
});