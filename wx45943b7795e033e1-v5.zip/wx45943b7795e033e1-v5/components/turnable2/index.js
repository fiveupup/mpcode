var app = getApp();Component({
  properties: {
    items: {
      type: Array,
      value: ["唱", "跳", "rap"]
    },
    colors: {
      type: Array,
      value: ['rgb(237,111,111)', 'rgb(250,141,111)', 'rgb(255,209,86)', 'rgb(131,200,131)', 'rgb(105,177,246)', "rgb(121,130,200)"]
    },
    items_color_map: {
      type: Object
    },
    radius: {
      type: Number,
      value: 180
    }
  },
  data: {},
  methods: {}
});