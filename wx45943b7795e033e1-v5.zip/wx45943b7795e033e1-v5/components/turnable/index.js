Component({
  properties: {
    state: {
      type: Number
    },
    items: {
      type: Array
    },
    colors: {
      type: Array,
      value: ["black", "white"]
    }
  },
  data: {
    radius: 155,
    rotate: 0
  },
  methods: {
    start: function start() {
      var _this = this;
      if (this.data.state == 1) return;
      this.triggerEvent("start");
      setTimeout(function () {
        var items = _this.data.items;
        var value = Math.floor(Math.random() * 200) % items.length;
        // console.log("结果是",value)
        _this.triggerEvent("stop", items[value]);
        _this.setData({
          rotate: -(1 / items.length) * value /*+ (Math.random()*0.35)/items.length*/
        });
      }, 1800);
    }
  }
});