Component({
  properties: {
    radius: {
      type: Number,
      observer: function observer(v) {}
    },
    count: {
      type: Number
    },
    colors: {
      type: Array,
      value: ['#00b9f1', '#C5E99B', '#D499B9']
      // value: [ "#5B8FF9", "#6DC8EC", "#E8684A", "#F6BD16", "#5D7092", "#5AD8A6", "#9270CA", "#FEB7D5", "#C8DAFC", "#F6BD16", "#5D7092", "#5AD8A6" ]
    }
  },

  data: {},
  methods: {}
});