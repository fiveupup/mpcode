function createBus() {
  var data = {};
  var store = {
    data: data,
    get: function get(key) {
      if (key) {
        return data[key];
      }
      return data;
    },
    set: function set(key, value) {
      data[key] = value;
    },
    remove: function remove(key) {
      delete data[key];
    },
    init: function init(obj) {
      Object.assign(data, obj);
    }
  };
  var listeners = {};
  var functions = [];
  var event = {
    on: function on(key, fn) {
      if (!listeners[key]) {
        listeners[key] = [];
      }
      listeners[key].push(fn);
    },
    off: function off(key, fn) {
      if (!listeners[key]) {
        return;
      }
      if (!fn) {
        listeners[key] = [];
        return;
      }
      listeners[key] = listeners[key].filter(function (item) {
        return item !== fn;
      });
    },
    emit: function emit(key) {
      for (var _len = arguments.length, args = new Array(_len > 1 ? _len - 1 : 0), _key = 1; _key < _len; _key++) {
        args[_key - 1] = arguments[_key];
      }
      if (!listeners[key]) {
        return;
      }
      listeners[key].forEach(function (item) {
        return item.apply(void 0, args);
      });
    },
    export: function _export(key, fn) {
      functions.push({
        key: key,
        fn: fn
      });
    },
    call: function call(key) {
      var fn = functions.find(function (item) {
        return item.key === key;
      });
      if (fn) {
        for (var _len2 = arguments.length, args = new Array(_len2 > 1 ? _len2 - 1 : 0), _key2 = 1; _key2 < _len2; _key2++) {
          args[_key2 - 1] = arguments[_key2];
        }
        return fn.fn.apply(fn, args);
      } else {
        console.error("\u6CA1\u6709\u627E\u5230".concat(key, "\u5BF9\u5E94\u7684\u51FD\u6570"));
      }
    }
  };
  var timers = [];
  function _setTimeout() {
    var timer = setTimeout.apply(null, arguments);
    timers.push(timer);
    return timer;
  }
  function _clearTimeout() {
    timers.forEach(function (item) {
      return clearTimeout(item);
    });
  }
  function sleep(ts) {
    return new Promise(function (resolve) {
      setTimeout(resolve, ts);
    });
  }
  return {
    store: store,
    event: event,
    get: store.get,
    set: store.set,
    emit: event.emit,
    on: event.on,
    setTimeout: _setTimeout,
    clearTimeout: _clearTimeout,
    sleep: sleep
  };
}var Bus = Behavior({
  lifetimes: {
    attached: function attached() {
      var currentPage = getCurrentPages().pop();
      if (!currentPage.$bus) {
        currentPage.$bus = createBus();
        if (currentPage.store && currentPage.store.constructor === Function) {
          currentPage.$bus.store.init(currentPage.store());
        }
        wx.$bus = currentPage.$bus;
      }
      this.$bus = currentPage.$bus;
    },
    detached: function detached() {
      this.$bus.clearTimeout();
      this.$bus = null;
    }
  }
});wx.Bus = Bus;