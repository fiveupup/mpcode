function sensitiveHash(input) {
  var charset = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";
  var hash = 0;
  for (var i = 0; i < input.length; i++) {
    var charCode = input.charCodeAt(i);
    hash = (hash << 5) - hash + charCode;
    hash |= 0; // Convert to 32-bit integer
  }

  var result = '';
  for (var _i = 0; _i < 8; _i++) {
    var index = hash & 0x3F; // Use the last 6 bits
    result += charset.charAt(index);
    hash >>= 6;
  }
  return result;
}module.exports = {
  sensitiveHash: sensitiveHash
};