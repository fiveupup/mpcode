var _regeneratorRuntime2 = require("../@babel/runtime/helpers/regeneratorRuntime");var _asyncToGenerator2 = require("../@babel/runtime/helpers/asyncToGenerator");var _require = require("./requests"),
  checkMsg = _require.checkMsg,
  getConfig = _require.getConfig;var checkMsgPass = /*#__PURE__*/function () {
  var _ref = _asyncToGenerator2( /*#__PURE__*/_regeneratorRuntime2().mark(function _callee(msg) {
    var r;
    return _regeneratorRuntime2().wrap(function _callee$(_context) {
      while (1) switch (_context.prev = _context.next) {
        case 0:
          _context.next = 2;
          return checkMsg(msg);
        case 2:
          r = _context.sent;
          if (!(r.code != 0)) {
            _context.next = 5;
            break;
          }
          return _context.abrupt("return", -1);
        case 5:
          if (!(r.data.result && r.data.result.suggest == "pass")) {
            _context.next = 7;
            break;
          }
          return _context.abrupt("return", 1);
        case 7:
          return _context.abrupt("return", 0);
        case 8:
        case "end":
          return _context.stop();
      }
    }, _callee);
  }));
  return function checkMsgPass(_x) {
    return _ref.apply(this, arguments);
  };
}();function loadConfig() {
  return _loadConfig.apply(this, arguments);
}function _loadConfig() {
  _loadConfig = _asyncToGenerator2( /*#__PURE__*/_regeneratorRuntime2().mark(function _callee2() {
    var res;
    return _regeneratorRuntime2().wrap(function _callee2$(_context2) {
      while (1) switch (_context2.prev = _context2.next) {
        case 0:
          _context2.next = 2;
          return getConfig();
        case 2:
          res = _context2.sent;
          if (res.code == 0) {
            console.log("加载配置成功", res);
            wx.setStorageSync("config", res.data);
          }
        case 4:
        case "end":
          return _context2.stop();
      }
    }, _callee2);
  }));
  return _loadConfig.apply(this, arguments);
}module.exports = {
  checkMsgPass: checkMsgPass,
  loadConfig: loadConfig
};