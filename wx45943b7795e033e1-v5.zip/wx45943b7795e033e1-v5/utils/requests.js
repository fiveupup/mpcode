var _regeneratorRuntime2 = require("../@babel/runtime/helpers/regeneratorRuntime");var _asyncToGenerator2 = require("../@babel/runtime/helpers/asyncToGenerator");var _require = require("../config"),
  hosts = _require.hosts,
  env = _require.env;var app = getApp();var request = {
  req: function req(url, data, method) {
    var header = arguments.length > 3 && arguments[3] !== undefined ? arguments[3] : {};
    if (!app) {
      app = getApp();
    }
    var tryTimes = 0;
    var reportEvent = function reportEvent(type, code, status, msg) {
      try {
        app.addEvent({
          id: "request",
          type: type,
          // 请求， 重试, 登陆
          code: code,
          // http 请求返回的 code
          status: status,
          // ok, error
          c0: tryTimes,
          //
          path: url,
          msg: JSON.stringify(msg)
        });
      } catch (e) {}
    };
    return new Promise(function (resolve, reject) {
      var type = tryTimes > 0 ? '重试' : '请求';
      var requestFunc = function requestFunc() {
        header.token = wx.getStorageSync('token');
        wx.request({
          url: hosts[env].api + url,
          data: data,
          method: method,
          header: header,
          timeout: 15000,
          success: function () {
            var _success = _asyncToGenerator2( /*#__PURE__*/_regeneratorRuntime2().mark(function _callee(res) {
              return _regeneratorRuntime2().wrap(function _callee$(_context) {
                while (1) switch (_context.prev = _context.next) {
                  case 0:
                    if (!(res.statusCode === 401 || res.statusCode === 403)) {
                      _context.next = 18;
                      break;
                    }
                    reportEvent(type, res.statusCode, "error", "");
                    if (!(res.statusCode === 401)) {
                      _context.next = 12;
                      break;
                    }
                    if (!(tryTimes > 3)) {
                      _context.next = 7;
                      break;
                    }
                    wx.showModel({
                      title: '登录失效',
                      content: '请截图并联系客服'
                    });
                    reject(res.data);
                    return _context.abrupt("return");
                  case 7:
                    tryTimes++;
                    _context.next = 10;
                    return app.wxLogin();
                  case 10:
                    requestFunc();
                    return _context.abrupt("return");
                  case 12:
                    if (!(res.statusCode === 403)) {
                      _context.next = 18;
                      break;
                    }
                    if (wx.getStorageSync('token')) {
                      _context.next = 18;
                      break;
                    }
                    _context.next = 16;
                    return app.wxLogin();
                  case 16:
                    requestFunc();
                    return _context.abrupt("return");
                  case 18:
                    resolve(res.data);
                  case 19:
                  case "end":
                    return _context.stop();
                }
              }, _callee);
            }));
            function success(_x) {
              return _success.apply(this, arguments);
            }
            return success;
          }(),
          fail: function fail(err) {
            if (tryTimes < 3) {
              requestFunc();
              tryTimes++;
              return;
            }
            console.log("request fail", err);
            reportEvent(type, err.code, "error", err);
            reject(err);
          }
        });
      };
      requestFunc();
    });
  },
  get: function get(url, header) {
    return this.req(url, "", "get", header);
  },
  post: function post(url, data, header) {
    return this.req(url, data, "post", header);
  }
};function login(data) {
  return request.post('/login', data);
}function getConfig() {
  return request.get("/getConfig");
}function getTTS(word) {
  var voice_type = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : 1001;
  return request.post('/v2/tts', {
    text: word,
    voice_type: voice_type
  });
}module.exports = {
  request: request,
  login: login,
  getConfig: getConfig,
  getTTS: getTTS
};