	var __wxAppData = __wxAppData || {}; 	var __wxRoute = __wxRoute || ""; 	var __wxRouteBegin = __wxRouteBegin || ""; 	var __wxAppCode__ = __wxAppCode__ || {};	var global = global || {};	var __WXML_GLOBAL__=__WXML_GLOBAL__ || {};	var __wxAppCurrentFile__=__wxAppCurrentFile__||""; 	var Component = Component || function(){};	var definePlugin = definePlugin || function(){};	var requirePlugin = requirePlugin || function(){};	var Behavior = Behavior || function(){};	var __vd_version_info__ = __vd_version_info__ || {};
	/*v0.5vv_20211229_syb_scopedata*/global.__wcc_version__='v0.5vv_20211229_syb_scopedata';global.__wcc_version_info__={"customComponents":true,"fixZeroRpx":true,"propValueDeepCopy":false};
var $gwxc
var $gaic={}
$gwx=function(path,global){
if(typeof global === 'undefined') global={};if(typeof __WXML_GLOBAL__ === 'undefined') {__WXML_GLOBAL__={};
}__WXML_GLOBAL__.modules = __WXML_GLOBAL__.modules || {};
function _(a,b){if(typeof(b)!='undefined')a.children.push(b);}
function _v(k){if(typeof(k)!='undefined')return {tag:'virtual','wxKey':k,children:[]};return {tag:'virtual',children:[]};}
function _n(tag){$gwxc++;if($gwxc>=16000){throw 'Dom limit exceeded, please check if there\'s any mistake you\'ve made.'};return {tag:'wx-'+tag,attr:{},children:[],n:[],raw:{},generics:{}}}
function _p(a,b){b&&a.properities.push(b);}
function _s(scope,env,key){return typeof(scope[key])!='undefined'?scope[key]:env[key]}
function _wp(m){console.warn("WXMLRT_$gwx:"+m)}
function _wl(tname,prefix){_wp(prefix+':-1:-1:-1: Template `' + tname + '` is being called recursively, will be stop.')}
$gwn=console.warn;
$gwl=console.log;
function $gwh()
{
function x()
{
}
x.prototype = 
{
hn: function( obj, all )
{
if( typeof(obj) == 'object' )
{
var cnt=0;
var any1=false,any2=false;
for(var x in obj)
{
any1=any1|x==='__value__';
any2=any2|x==='__wxspec__';
cnt++;
if(cnt>2)break;
}
return cnt == 2 && any1 && any2 && ( all || obj.__wxspec__ !== 'm' || this.hn(obj.__value__) === 'h' ) ? "h" : "n";
}
return "n";
},
nh: function( obj, special )
{
return { __value__: obj, __wxspec__: special ? special : true }
},
rv: function( obj )
{
return this.hn(obj,true)==='n'?obj:this.rv(obj.__value__);
},
hm: function( obj )
{
if( typeof(obj) == 'object' )
{
var cnt=0;
var any1=false,any2=false;
for(var x in obj)
{
any1=any1|x==='__value__';
any2=any2|x==='__wxspec__';
cnt++;
if(cnt>2)break;
}
return cnt == 2 && any1 && any2 && (obj.__wxspec__ === 'm' || this.hm(obj.__value__) );
}
return false;
}
}
return new x;
}
wh=$gwh();
function $gstack(s){
var tmp=s.split('\n '+' '+' '+' ');
for(var i=0;i<tmp.length;++i){
if(0==i) continue;
if(")"===tmp[i][tmp[i].length-1])
tmp[i]=tmp[i].replace(/\s\(.*\)$/,"");
else
tmp[i]="at anonymous function";
}
return tmp.join('\n '+' '+' '+' ');
}
function $gwrt( should_pass_type_info )
{
function ArithmeticEv( ops, e, s, g, o )
{
var _f = false;
var rop = ops[0][1];
var _a,_b,_c,_d, _aa, _bb;
switch( rop )
{
case '?:':
_a = rev( ops[1], e, s, g, o, _f );
_c = should_pass_type_info && ( wh.hn(_a) === 'h' );
_d = wh.rv( _a ) ? rev( ops[2], e, s, g, o, _f ) : rev( ops[3], e, s, g, o, _f );
_d = _c && wh.hn( _d ) === 'n' ? wh.nh( _d, 'c' ) : _d;
return _d;
break;
case '&&':
_a = rev( ops[1], e, s, g, o, _f );
_c = should_pass_type_info && ( wh.hn(_a) === 'h' );
_d = wh.rv( _a ) ? rev( ops[2], e, s, g, o, _f ) : wh.rv( _a );
_d = _c && wh.hn( _d ) === 'n' ? wh.nh( _d, 'c' ) : _d;
return _d;
break;
case '||':
_a = rev( ops[1], e, s, g, o, _f );
_c = should_pass_type_info && ( wh.hn(_a) === 'h' );
_d = wh.rv( _a ) ? wh.rv(_a) : rev( ops[2], e, s, g, o, _f );
_d = _c && wh.hn( _d ) === 'n' ? wh.nh( _d, 'c' ) : _d;
return _d;
break;
case '+':
case '*':
case '/':
case '%':
case '|':
case '^':
case '&':
case '===':
case '==':
case '!=':
case '!==':
case '>=':
case '<=':
case '>':
case '<':
case '<<':
case '>>':
_a = rev( ops[1], e, s, g, o, _f );
_b = rev( ops[2], e, s, g, o, _f );
_c = should_pass_type_info && (wh.hn( _a ) === 'h' || wh.hn( _b ) === 'h');
switch( rop )
{
case '+':
_d = wh.rv( _a ) + wh.rv( _b );
break;
case '*':
_d = wh.rv( _a ) * wh.rv( _b );
break;
case '/':
_d = wh.rv( _a ) / wh.rv( _b );
break;
case '%':
_d = wh.rv( _a ) % wh.rv( _b );
break;
case '|':
_d = wh.rv( _a ) | wh.rv( _b );
break;
case '^':
_d = wh.rv( _a ) ^ wh.rv( _b );
break;
case '&':
_d = wh.rv( _a ) & wh.rv( _b );
break;
case '===':
_d = wh.rv( _a ) === wh.rv( _b );
break;
case '==':
_d = wh.rv( _a ) == wh.rv( _b );
break;
case '!=':
_d = wh.rv( _a ) != wh.rv( _b );
break;
case '!==':
_d = wh.rv( _a ) !== wh.rv( _b );
break;
case '>=':
_d = wh.rv( _a ) >= wh.rv( _b );
break;
case '<=':
_d = wh.rv( _a ) <= wh.rv( _b );
break;
case '>':
_d = wh.rv( _a ) > wh.rv( _b );
break;
case '<':
_d = wh.rv( _a ) < wh.rv( _b );
break;
case '<<':
_d = wh.rv( _a ) << wh.rv( _b );
break;
case '>>':
_d = wh.rv( _a ) >> wh.rv( _b );
break;
default:
break;
}
return _c ? wh.nh( _d, "c" ) : _d;
break;
case '-':
_a = ops.length === 3 ? rev( ops[1], e, s, g, o, _f ) : 0;
_b = ops.length === 3 ? rev( ops[2], e, s, g, o, _f ) : rev( ops[1], e, s, g, o, _f );
_c = should_pass_type_info && (wh.hn( _a ) === 'h' || wh.hn( _b ) === 'h');
_d = _c ? wh.rv( _a ) - wh.rv( _b ) : _a - _b;
return _c ? wh.nh( _d, "c" ) : _d;
break;
case '!':
_a = rev( ops[1], e, s, g, o, _f );
_c = should_pass_type_info && (wh.hn( _a ) == 'h');
_d = !wh.rv(_a);
return _c ? wh.nh( _d, "c" ) : _d;
case '~':
_a = rev( ops[1], e, s, g, o, _f );
_c = should_pass_type_info && (wh.hn( _a ) == 'h');
_d = ~wh.rv(_a);
return _c ? wh.nh( _d, "c" ) : _d;
default:
$gwn('unrecognized op' + rop );
}
}
function rev( ops, e, s, g, o, newap )
{
var op = ops[0];
var _f = false;
if ( typeof newap !== "undefined" ) o.ap = newap;
if( typeof(op)==='object' )
{
var vop=op[0];
var _a, _aa, _b, _bb, _c, _d, _s, _e, _ta, _tb, _td;
switch(vop)
{
case 2:
return ArithmeticEv(ops,e,s,g,o);
break;
case 4: 
return rev( ops[1], e, s, g, o, _f );
break;
case 5: 
switch( ops.length )
{
case 2: 
_a = rev( ops[1],e,s,g,o,_f );
return should_pass_type_info?[_a]:[wh.rv(_a)];
return [_a];
break;
case 1: 
return [];
break;
default:
_a = rev( ops[1],e,s,g,o,_f );
_b = rev( ops[2],e,s,g,o,_f );
_a.push( 
should_pass_type_info ?
_b :
wh.rv( _b )
);
return _a;
break;
}
break;
case 6:
_a = rev(ops[1],e,s,g,o);
var ap = o.ap;
_ta = wh.hn(_a)==='h';
_aa = _ta ? wh.rv(_a) : _a;
o.is_affected |= _ta;
if( should_pass_type_info )
{
if( _aa===null || typeof(_aa) === 'undefined' )
{
return _ta ? wh.nh(undefined, 'e') : undefined;
}
_b = rev(ops[2],e,s,g,o,_f);
_tb = wh.hn(_b) === 'h';
_bb = _tb ? wh.rv(_b) : _b;
o.ap = ap;
o.is_affected |= _tb;
if( _bb===null || typeof(_bb) === 'undefined' || 
_bb === "__proto__" || _bb === "prototype" || _bb === "caller" ) 
{
return (_ta || _tb) ? wh.nh(undefined, 'e') : undefined;
}
_d = _aa[_bb];
if ( typeof _d === 'function' && !ap ) _d = undefined;
_td = wh.hn(_d)==='h';
o.is_affected |= _td;
return (_ta || _tb) ? (_td ? _d : wh.nh(_d, 'e')) : _d;
}
else
{
if( _aa===null || typeof(_aa) === 'undefined' )
{
return undefined;
}
_b = rev(ops[2],e,s,g,o,_f);
_tb = wh.hn(_b) === 'h';
_bb = _tb ? wh.rv(_b) : _b;
o.ap = ap;
o.is_affected |= _tb;
if( _bb===null || typeof(_bb) === 'undefined' || 
_bb === "__proto__" || _bb === "prototype" || _bb === "caller" ) 
{
return undefined;
}
_d = _aa[_bb];
if ( typeof _d === 'function' && !ap ) _d = undefined;
_td = wh.hn(_d)==='h';
o.is_affected |= _td;
return _td ? wh.rv(_d) : _d;
}
case 7: 
switch(ops[1][0])
{
case 11:
o.is_affected |= wh.hn(g)==='h';
return g;
case 3:
_s = wh.rv( s );
_e = wh.rv( e );
_b = ops[1][1];
if (g && g.f && g.f.hasOwnProperty(_b) )
{
_a = g.f;
o.ap = true;
}
else
{
_a = _s && _s.hasOwnProperty(_b) ? 
s : (_e && _e.hasOwnProperty(_b) ? e : undefined );
}
if( should_pass_type_info )
{
if( _a )
{
_ta = wh.hn(_a) === 'h';
_aa = _ta ? wh.rv( _a ) : _a;
_d = _aa[_b];
_td = wh.hn(_d) === 'h';
o.is_affected |= _ta || _td;
_d = _ta && !_td ? wh.nh(_d,'e') : _d;
return _d;
}
}
else
{
if( _a )
{
_ta = wh.hn(_a) === 'h';
_aa = _ta ? wh.rv( _a ) : _a;
_d = _aa[_b];
_td = wh.hn(_d) === 'h';
o.is_affected |= _ta || _td;
return wh.rv(_d);
}
}
return undefined;
}
break;
case 8: 
_a = {};
_a[ops[1]] = rev(ops[2],e,s,g,o,_f);
return _a;
break;
case 9: 
_a = rev(ops[1],e,s,g,o,_f);
_b = rev(ops[2],e,s,g,o,_f);
function merge( _a, _b, _ow )
{
var ka, _bbk;
_ta = wh.hn(_a)==='h';
_tb = wh.hn(_b)==='h';
_aa = wh.rv(_a);
_bb = wh.rv(_b);
for(var k in _bb)
{
if ( _ow || !_aa.hasOwnProperty(k) )
{
_aa[k] = should_pass_type_info ? (_tb ? wh.nh(_bb[k],'e') : _bb[k]) : wh.rv(_bb[k]);
}
}
return _a;
}
var _c = _a
var _ow = true
if ( typeof(ops[1][0]) === "object" && ops[1][0][0] === 10 ) {
_a = _b
_b = _c
_ow = false
}
if ( typeof(ops[1][0]) === "object" && ops[1][0][0] === 10 ) {
var _r = {}
return merge( merge( _r, _a, _ow ), _b, _ow );
}
else
return merge( _a, _b, _ow );
break;
case 10:
_a = rev(ops[1],e,s,g,o,_f);
_a = should_pass_type_info ? _a : wh.rv( _a );
return _a ;
break;
case 12:
var _r;
_a = rev(ops[1],e,s,g,o);
if ( !o.ap )
{
return should_pass_type_info && wh.hn(_a)==='h' ? wh.nh( _r, 'f' ) : _r;
}
var ap = o.ap;
_b = rev(ops[2],e,s,g,o,_f);
o.ap = ap;
_ta = wh.hn(_a)==='h';
_tb = _ca(_b);
_aa = wh.rv(_a);	
_bb = wh.rv(_b); snap_bb=$gdc(_bb,"nv_");
try{
_r = typeof _aa === "function" ? $gdc(_aa.apply(null, snap_bb)) : undefined;
} catch (e){
e.message = e.message.replace(/nv_/g,"");
e.stack = e.stack.substring(0,e.stack.indexOf("\n", e.stack.lastIndexOf("at nv_")));
e.stack = e.stack.replace(/\snv_/g," "); 
e.stack = $gstack(e.stack);	
if(g.debugInfo)
{
e.stack += "\n "+" "+" "+" at "+g.debugInfo[0]+":"+g.debugInfo[1]+":"+g.debugInfo[2];
console.error(e);
}
_r = undefined;
}
return should_pass_type_info && (_tb || _ta) ? wh.nh( _r, 'f' ) : _r;
}
}
else
{
if( op === 3 || op === 1) return ops[1];
else if( op === 11 ) 
{
var _a='';
for( var i = 1 ; i < ops.length ; i++ )
{
var xp = wh.rv(rev(ops[i],e,s,g,o,_f));
_a += typeof(xp) === 'undefined' ? '' : xp;
}
return _a;
}
}
}
function wrapper( ops, e, s, g, o, newap )
{
if( ops[0] == '11182016' )
{
g.debugInfo = ops[2];
return rev( ops[1], e, s, g, o, newap );
}
else
{
g.debugInfo = null;
return rev( ops, e, s, g, o, newap );
}
}
return wrapper;
}
gra=$gwrt(true); 
grb=$gwrt(false); 
function TestTest( expr, ops, e,s,g, expect_a, expect_b, expect_affected )
{
{
var o = {is_affected:false};
var a = gra( ops, e,s,g, o );
if( JSON.stringify(a) != JSON.stringify( expect_a )
|| o.is_affected != expect_affected )
{
console.warn( "A. " + expr + " get result " + JSON.stringify(a) + ", " + o.is_affected + ", but " + JSON.stringify( expect_a ) + ", " + expect_affected + " is expected" );
}
}
{
var o = {is_affected:false};
var a = grb( ops, e,s,g, o );
if( JSON.stringify(a) != JSON.stringify( expect_b )
|| o.is_affected != expect_affected )
{
console.warn( "B. " + expr + " get result " + JSON.stringify(a) + ", " + o.is_affected + ", but " + JSON.stringify( expect_b ) + ", " + expect_affected + " is expected" );
}
}
}

function wfor( to_iter, func, env, _s, global, father, itemname, indexname, keyname )
{
var _n = wh.hn( to_iter ) === 'n'; 
var scope = wh.rv( _s ); 
var has_old_item = scope.hasOwnProperty(itemname);
var has_old_index = scope.hasOwnProperty(indexname);
var old_item = scope[itemname];
var old_index = scope[indexname];
var full = Object.prototype.toString.call(wh.rv(to_iter));
var type = full[8]; 
if( type === 'N' && full[10] === 'l' ) type = 'X'; 
var _y;
if( _n )
{
if( type === 'A' ) 
{
var r_iter_item;
for( var i = 0 ; i < to_iter.length ; i++ )
{
scope[itemname] = to_iter[i];
scope[indexname] = _n ? i : wh.nh(i, 'h');
r_iter_item = wh.rv(to_iter[i]);
var key = keyname && r_iter_item ? (keyname==="*this" ? r_iter_item : wh.rv(r_iter_item[keyname])) : undefined;
_y = _v(key);
_(father,_y);
func( env, scope, _y, global );
}
}
else if( type === 'O' ) 
{
var i = 0;
var r_iter_item;
for( var k in to_iter )
{
scope[itemname] = to_iter[k];
scope[indexname] = _n ? k : wh.nh(k, 'h');
r_iter_item = wh.rv(to_iter[k]);
var key = keyname && r_iter_item ? (keyname==="*this" ? r_iter_item : wh.rv(r_iter_item[keyname])) : undefined;
_y = _v(key);
_(father,_y);
func( env,scope,_y,global );
i++;
}
}
else if( type === 'S' ) 
{
for( var i = 0 ; i < to_iter.length ; i++ )
{
scope[itemname] = to_iter[i];
scope[indexname] = _n ? i : wh.nh(i, 'h');
_y = _v( to_iter[i] + i );
_(father,_y);
func( env,scope,_y,global );
}
}
else if( type === 'N' ) 
{
for( var i = 0 ; i < to_iter ; i++ )
{
scope[itemname] = i;
scope[indexname] = _n ? i : wh.nh(i, 'h');
_y = _v( i );
_(father,_y);
func(env,scope,_y,global);
}
}
else
{
}
}
else
{
var r_to_iter = wh.rv(to_iter);
var r_iter_item, iter_item;
if( type === 'A' ) 
{
for( var i = 0 ; i < r_to_iter.length ; i++ )
{
iter_item = r_to_iter[i];
iter_item = wh.hn(iter_item)==='n' ? wh.nh(iter_item,'h') : iter_item;
r_iter_item = wh.rv( iter_item );
scope[itemname] = iter_item
scope[indexname] = _n ? i : wh.nh(i, 'h');
var key = keyname && r_iter_item ? (keyname==="*this" ? r_iter_item : wh.rv(r_iter_item[keyname])) : undefined;
_y = _v(key);
_(father,_y);
func( env, scope, _y, global );
}
}
else if( type === 'O' ) 
{
var i=0;
for( var k in r_to_iter )
{
iter_item = r_to_iter[k];
iter_item = wh.hn(iter_item)==='n'? wh.nh(iter_item,'h') : iter_item;
r_iter_item = wh.rv( iter_item );
scope[itemname] = iter_item;
scope[indexname] = _n ? k : wh.nh(k, 'h');
var key = keyname && r_iter_item ? (keyname==="*this" ? r_iter_item : wh.rv(r_iter_item[keyname])) : undefined;
_y=_v(key);
_(father,_y);
func( env, scope, _y, global );
i++
}
}
else if( type === 'S' ) 
{
for( var i = 0 ; i < r_to_iter.length ; i++ )
{
iter_item = wh.nh(r_to_iter[i],'h');
scope[itemname] = iter_item;
scope[indexname] = _n ? i : wh.nh(i, 'h');
_y = _v( to_iter[i] + i );
_(father,_y);
func( env, scope, _y, global );
}
}
else if( type === 'N' ) 
{
for( var i = 0 ; i < r_to_iter ; i++ )
{
iter_item = wh.nh(i,'h');
scope[itemname] = iter_item;
scope[indexname]= _n ? i : wh.nh(i,'h');
_y = _v( i );
_(father,_y);
func(env,scope,_y,global);
}
}
else
{
}
}
if(has_old_item)
{
scope[itemname]=old_item;
}
else
{
delete scope[itemname];
}
if(has_old_index)
{
scope[indexname]=old_index;
}
else
{
delete scope[indexname];
}
}

function _ca(o)
{ 
if ( wh.hn(o) == 'h' ) return true;
if ( typeof o !== "object" ) return false;
for(var i in o){ 
if ( o.hasOwnProperty(i) ){
if (_ca(o[i])) return true;
}
}
return false;
}
function _da( node, attrname, opindex, raw, o )
{
var isaffected = false;
var value = $gdc( raw, "", 2 );
if ( o.ap && value && value.constructor===Function ) 
{
attrname = "$wxs:" + attrname; 
node.attr["$gdc"] = $gdc;
}
if ( o.is_affected || _ca(raw) ) 
{
node.n.push( attrname );
node.raw[attrname] = raw;
}
node.attr[attrname] = value;
}
function _r( node, attrname, opindex, env, scope, global ) 
{
global.opindex=opindex;
var o = {}, _env;
var a = grb( z[opindex], env, scope, global, o );
_da( node, attrname, opindex, a, o );
}
function _rz( z, node, attrname, opindex, env, scope, global ) 
{
global.opindex=opindex;
var o = {}, _env;
var a = grb( z[opindex], env, scope, global, o );
_da( node, attrname, opindex, a, o );
}
function _o( opindex, env, scope, global )
{
global.opindex=opindex;
var nothing = {};
var r = grb( z[opindex], env, scope, global, nothing );
return (r&&r.constructor===Function) ? undefined : r;
}
function _oz( z, opindex, env, scope, global )
{
global.opindex=opindex;
var nothing = {};
var r = grb( z[opindex], env, scope, global, nothing );
return (r&&r.constructor===Function) ? undefined : r;
}
function _1( opindex, env, scope, global, o )
{
var o = o || {};
global.opindex=opindex;
return gra( z[opindex], env, scope, global, o );
}
function _1z( z, opindex, env, scope, global, o )
{
var o = o || {};
global.opindex=opindex;
return gra( z[opindex], env, scope, global, o );
}
function _2( opindex, func, env, scope, global, father, itemname, indexname, keyname )
{
var o = {};
var to_iter = _1( opindex, env, scope, global );
wfor( to_iter, func, env, scope, global, father, itemname, indexname, keyname );
}
function _2z( z, opindex, func, env, scope, global, father, itemname, indexname, keyname )
{
var o = {};
var to_iter = _1z( z, opindex, env, scope, global );
wfor( to_iter, func, env, scope, global, father, itemname, indexname, keyname );
}


function _m(tag,attrs,generics,env,scope,global)
{
var tmp=_n(tag);
var base=0;
for(var i = 0 ; i < attrs.length ; i+=2 )
{
if(base+attrs[i+1]<0)
{
tmp.attr[attrs[i]]=true;
}
else
{
_r(tmp,attrs[i],base+attrs[i+1],env,scope,global);
if(base===0)base=attrs[i+1];
}
}
for(var i=0;i<generics.length;i+=2)
{
if(base+generics[i+1]<0)
{
tmp.generics[generics[i]]="";
}
else
{
var $t=grb(z[base+generics[i+1]],env,scope,global);
if ($t!="") $t="wx-"+$t;
tmp.generics[generics[i]]=$t;
if(base===0)base=generics[i+1];
}
}
return tmp;
}
function _mz(z,tag,attrs,generics,env,scope,global)
{
var tmp=_n(tag);
var base=0;
for(var i = 0 ; i < attrs.length ; i+=2 )
{
if(base+attrs[i+1]<0)
{
tmp.attr[attrs[i]]=true;
}
else
{
_rz(z, tmp,attrs[i],base+attrs[i+1],env,scope,global);
if(base===0)base=attrs[i+1];
}
}
for(var i=0;i<generics.length;i+=2)
{
if(base+generics[i+1]<0)
{
tmp.generics[generics[i]]="";
}
else
{
var $t=grb(z[base+generics[i+1]],env,scope,global);
if ($t!="") $t="wx-"+$t;
tmp.generics[generics[i]]=$t;
if(base===0)base=generics[i+1];
}
}
return tmp;
}

var nf_init=function(){
if(typeof __WXML_GLOBAL__==="undefined"||undefined===__WXML_GLOBAL__.wxs_nf_init){
nf_init_Object();nf_init_Function();nf_init_Array();nf_init_String();nf_init_Boolean();nf_init_Number();nf_init_Math();nf_init_Date();nf_init_RegExp();
}
if(typeof __WXML_GLOBAL__!=="undefined") __WXML_GLOBAL__.wxs_nf_init=true;
};
var nf_init_Object=function(){
Object.defineProperty(Object.prototype,"nv_constructor",{writable:true,value:"Object"})
Object.defineProperty(Object.prototype,"nv_toString",{writable:true,value:function(){return "[object Object]"}})
}
var nf_init_Function=function(){
Object.defineProperty(Function.prototype,"nv_constructor",{writable:true,value:"Function"})
Object.defineProperty(Function.prototype,"nv_length",{get:function(){return this.length;},set:function(){}});
Object.defineProperty(Function.prototype,"nv_toString",{writable:true,value:function(){return "[function Function]"}})
}
var nf_init_Array=function(){
Object.defineProperty(Array.prototype,"nv_toString",{writable:true,value:function(){return this.nv_join();}})
Object.defineProperty(Array.prototype,"nv_join",{writable:true,value:function(s){
s=undefined==s?',':s;
var r="";
for(var i=0;i<this.length;++i){
if(0!=i) r+=s;
if(null==this[i]||undefined==this[i]) r+='';	
else if(typeof this[i]=='function') r+=this[i].nv_toString();
else if(typeof this[i]=='object'&&this[i].nv_constructor==="Array") r+=this[i].nv_join();
else r+=this[i].toString();
}
return r;
}})
Object.defineProperty(Array.prototype,"nv_constructor",{writable:true,value:"Array"})
Object.defineProperty(Array.prototype,"nv_concat",{writable:true,value:Array.prototype.concat})
Object.defineProperty(Array.prototype,"nv_pop",{writable:true,value:Array.prototype.pop})
Object.defineProperty(Array.prototype,"nv_push",{writable:true,value:Array.prototype.push})
Object.defineProperty(Array.prototype,"nv_reverse",{writable:true,value:Array.prototype.reverse})
Object.defineProperty(Array.prototype,"nv_shift",{writable:true,value:Array.prototype.shift})
Object.defineProperty(Array.prototype,"nv_slice",{writable:true,value:Array.prototype.slice})
Object.defineProperty(Array.prototype,"nv_sort",{writable:true,value:Array.prototype.sort})
Object.defineProperty(Array.prototype,"nv_splice",{writable:true,value:Array.prototype.splice})
Object.defineProperty(Array.prototype,"nv_unshift",{writable:true,value:Array.prototype.unshift})
Object.defineProperty(Array.prototype,"nv_indexOf",{writable:true,value:Array.prototype.indexOf})
Object.defineProperty(Array.prototype,"nv_lastIndexOf",{writable:true,value:Array.prototype.lastIndexOf})
Object.defineProperty(Array.prototype,"nv_every",{writable:true,value:Array.prototype.every})
Object.defineProperty(Array.prototype,"nv_some",{writable:true,value:Array.prototype.some})
Object.defineProperty(Array.prototype,"nv_forEach",{writable:true,value:Array.prototype.forEach})
Object.defineProperty(Array.prototype,"nv_map",{writable:true,value:Array.prototype.map})
Object.defineProperty(Array.prototype,"nv_filter",{writable:true,value:Array.prototype.filter})
Object.defineProperty(Array.prototype,"nv_reduce",{writable:true,value:Array.prototype.reduce})
Object.defineProperty(Array.prototype,"nv_reduceRight",{writable:true,value:Array.prototype.reduceRight})
Object.defineProperty(Array.prototype,"nv_length",{get:function(){return this.length;},set:function(value){this.length=value;}});
}
var nf_init_String=function(){
Object.defineProperty(String.prototype,"nv_constructor",{writable:true,value:"String"})
Object.defineProperty(String.prototype,"nv_toString",{writable:true,value:String.prototype.toString})
Object.defineProperty(String.prototype,"nv_valueOf",{writable:true,value:String.prototype.valueOf})
Object.defineProperty(String.prototype,"nv_charAt",{writable:true,value:String.prototype.charAt})
Object.defineProperty(String.prototype,"nv_charCodeAt",{writable:true,value:String.prototype.charCodeAt})
Object.defineProperty(String.prototype,"nv_concat",{writable:true,value:String.prototype.concat})
Object.defineProperty(String.prototype,"nv_indexOf",{writable:true,value:String.prototype.indexOf})
Object.defineProperty(String.prototype,"nv_lastIndexOf",{writable:true,value:String.prototype.lastIndexOf})
Object.defineProperty(String.prototype,"nv_localeCompare",{writable:true,value:String.prototype.localeCompare})
Object.defineProperty(String.prototype,"nv_match",{writable:true,value:String.prototype.match})
Object.defineProperty(String.prototype,"nv_replace",{writable:true,value:String.prototype.replace})
Object.defineProperty(String.prototype,"nv_search",{writable:true,value:String.prototype.search})
Object.defineProperty(String.prototype,"nv_slice",{writable:true,value:String.prototype.slice})
Object.defineProperty(String.prototype,"nv_split",{writable:true,value:String.prototype.split})
Object.defineProperty(String.prototype,"nv_substring",{writable:true,value:String.prototype.substring})
Object.defineProperty(String.prototype,"nv_toLowerCase",{writable:true,value:String.prototype.toLowerCase})
Object.defineProperty(String.prototype,"nv_toLocaleLowerCase",{writable:true,value:String.prototype.toLocaleLowerCase})
Object.defineProperty(String.prototype,"nv_toUpperCase",{writable:true,value:String.prototype.toUpperCase})
Object.defineProperty(String.prototype,"nv_toLocaleUpperCase",{writable:true,value:String.prototype.toLocaleUpperCase})
Object.defineProperty(String.prototype,"nv_trim",{writable:true,value:String.prototype.trim})
Object.defineProperty(String.prototype,"nv_length",{get:function(){return this.length;},set:function(value){this.length=value;}});
}
var nf_init_Boolean=function(){
Object.defineProperty(Boolean.prototype,"nv_constructor",{writable:true,value:"Boolean"})
Object.defineProperty(Boolean.prototype,"nv_toString",{writable:true,value:Boolean.prototype.toString})
Object.defineProperty(Boolean.prototype,"nv_valueOf",{writable:true,value:Boolean.prototype.valueOf})
}
var nf_init_Number=function(){
Object.defineProperty(Number,"nv_MAX_VALUE",{writable:false,value:Number.MAX_VALUE})
Object.defineProperty(Number,"nv_MIN_VALUE",{writable:false,value:Number.MIN_VALUE})
Object.defineProperty(Number,"nv_NEGATIVE_INFINITY",{writable:false,value:Number.NEGATIVE_INFINITY})
Object.defineProperty(Number,"nv_POSITIVE_INFINITY",{writable:false,value:Number.POSITIVE_INFINITY})
Object.defineProperty(Number.prototype,"nv_constructor",{writable:true,value:"Number"})
Object.defineProperty(Number.prototype,"nv_toString",{writable:true,value:Number.prototype.toString})
Object.defineProperty(Number.prototype,"nv_toLocaleString",{writable:true,value:Number.prototype.toLocaleString})
Object.defineProperty(Number.prototype,"nv_valueOf",{writable:true,value:Number.prototype.valueOf})
Object.defineProperty(Number.prototype,"nv_toFixed",{writable:true,value:Number.prototype.toFixed})
Object.defineProperty(Number.prototype,"nv_toExponential",{writable:true,value:Number.prototype.toExponential})
Object.defineProperty(Number.prototype,"nv_toPrecision",{writable:true,value:Number.prototype.toPrecision})
}
var nf_init_Math=function(){
Object.defineProperty(Math,"nv_E",{writable:false,value:Math.E})
Object.defineProperty(Math,"nv_LN10",{writable:false,value:Math.LN10})
Object.defineProperty(Math,"nv_LN2",{writable:false,value:Math.LN2})
Object.defineProperty(Math,"nv_LOG2E",{writable:false,value:Math.LOG2E})
Object.defineProperty(Math,"nv_LOG10E",{writable:false,value:Math.LOG10E})
Object.defineProperty(Math,"nv_PI",{writable:false,value:Math.PI})
Object.defineProperty(Math,"nv_SQRT1_2",{writable:false,value:Math.SQRT1_2})
Object.defineProperty(Math,"nv_SQRT2",{writable:false,value:Math.SQRT2})
Object.defineProperty(Math,"nv_abs",{writable:false,value:Math.abs})
Object.defineProperty(Math,"nv_acos",{writable:false,value:Math.acos})
Object.defineProperty(Math,"nv_asin",{writable:false,value:Math.asin})
Object.defineProperty(Math,"nv_atan",{writable:false,value:Math.atan})
Object.defineProperty(Math,"nv_atan2",{writable:false,value:Math.atan2})
Object.defineProperty(Math,"nv_ceil",{writable:false,value:Math.ceil})
Object.defineProperty(Math,"nv_cos",{writable:false,value:Math.cos})
Object.defineProperty(Math,"nv_exp",{writable:false,value:Math.exp})
Object.defineProperty(Math,"nv_floor",{writable:false,value:Math.floor})
Object.defineProperty(Math,"nv_log",{writable:false,value:Math.log})
Object.defineProperty(Math,"nv_max",{writable:false,value:Math.max})
Object.defineProperty(Math,"nv_min",{writable:false,value:Math.min})
Object.defineProperty(Math,"nv_pow",{writable:false,value:Math.pow})
Object.defineProperty(Math,"nv_random",{writable:false,value:Math.random})
Object.defineProperty(Math,"nv_round",{writable:false,value:Math.round})
Object.defineProperty(Math,"nv_sin",{writable:false,value:Math.sin})
Object.defineProperty(Math,"nv_sqrt",{writable:false,value:Math.sqrt})
Object.defineProperty(Math,"nv_tan",{writable:false,value:Math.tan})
}
var nf_init_Date=function(){
Object.defineProperty(Date.prototype,"nv_constructor",{writable:true,value:"Date"})
Object.defineProperty(Date,"nv_parse",{writable:true,value:Date.parse})
Object.defineProperty(Date,"nv_UTC",{writable:true,value:Date.UTC})
Object.defineProperty(Date,"nv_now",{writable:true,value:Date.now})
Object.defineProperty(Date.prototype,"nv_toString",{writable:true,value:Date.prototype.toString})
Object.defineProperty(Date.prototype,"nv_toDateString",{writable:true,value:Date.prototype.toDateString})
Object.defineProperty(Date.prototype,"nv_toTimeString",{writable:true,value:Date.prototype.toTimeString})
Object.defineProperty(Date.prototype,"nv_toLocaleString",{writable:true,value:Date.prototype.toLocaleString})
Object.defineProperty(Date.prototype,"nv_toLocaleDateString",{writable:true,value:Date.prototype.toLocaleDateString})
Object.defineProperty(Date.prototype,"nv_toLocaleTimeString",{writable:true,value:Date.prototype.toLocaleTimeString})
Object.defineProperty(Date.prototype,"nv_valueOf",{writable:true,value:Date.prototype.valueOf})
Object.defineProperty(Date.prototype,"nv_getTime",{writable:true,value:Date.prototype.getTime})
Object.defineProperty(Date.prototype,"nv_getFullYear",{writable:true,value:Date.prototype.getFullYear})
Object.defineProperty(Date.prototype,"nv_getUTCFullYear",{writable:true,value:Date.prototype.getUTCFullYear})
Object.defineProperty(Date.prototype,"nv_getMonth",{writable:true,value:Date.prototype.getMonth})
Object.defineProperty(Date.prototype,"nv_getUTCMonth",{writable:true,value:Date.prototype.getUTCMonth})
Object.defineProperty(Date.prototype,"nv_getDate",{writable:true,value:Date.prototype.getDate})
Object.defineProperty(Date.prototype,"nv_getUTCDate",{writable:true,value:Date.prototype.getUTCDate})
Object.defineProperty(Date.prototype,"nv_getDay",{writable:true,value:Date.prototype.getDay})
Object.defineProperty(Date.prototype,"nv_getUTCDay",{writable:true,value:Date.prototype.getUTCDay})
Object.defineProperty(Date.prototype,"nv_getHours",{writable:true,value:Date.prototype.getHours})
Object.defineProperty(Date.prototype,"nv_getUTCHours",{writable:true,value:Date.prototype.getUTCHours})
Object.defineProperty(Date.prototype,"nv_getMinutes",{writable:true,value:Date.prototype.getMinutes})
Object.defineProperty(Date.prototype,"nv_getUTCMinutes",{writable:true,value:Date.prototype.getUTCMinutes})
Object.defineProperty(Date.prototype,"nv_getSeconds",{writable:true,value:Date.prototype.getSeconds})
Object.defineProperty(Date.prototype,"nv_getUTCSeconds",{writable:true,value:Date.prototype.getUTCSeconds})
Object.defineProperty(Date.prototype,"nv_getMilliseconds",{writable:true,value:Date.prototype.getMilliseconds})
Object.defineProperty(Date.prototype,"nv_getUTCMilliseconds",{writable:true,value:Date.prototype.getUTCMilliseconds})
Object.defineProperty(Date.prototype,"nv_getTimezoneOffset",{writable:true,value:Date.prototype.getTimezoneOffset})
Object.defineProperty(Date.prototype,"nv_setTime",{writable:true,value:Date.prototype.setTime})
Object.defineProperty(Date.prototype,"nv_setMilliseconds",{writable:true,value:Date.prototype.setMilliseconds})
Object.defineProperty(Date.prototype,"nv_setUTCMilliseconds",{writable:true,value:Date.prototype.setUTCMilliseconds})
Object.defineProperty(Date.prototype,"nv_setSeconds",{writable:true,value:Date.prototype.setSeconds})
Object.defineProperty(Date.prototype,"nv_setUTCSeconds",{writable:true,value:Date.prototype.setUTCSeconds})
Object.defineProperty(Date.prototype,"nv_setMinutes",{writable:true,value:Date.prototype.setMinutes})
Object.defineProperty(Date.prototype,"nv_setUTCMinutes",{writable:true,value:Date.prototype.setUTCMinutes})
Object.defineProperty(Date.prototype,"nv_setHours",{writable:true,value:Date.prototype.setHours})
Object.defineProperty(Date.prototype,"nv_setUTCHours",{writable:true,value:Date.prototype.setUTCHours})
Object.defineProperty(Date.prototype,"nv_setDate",{writable:true,value:Date.prototype.setDate})
Object.defineProperty(Date.prototype,"nv_setUTCDate",{writable:true,value:Date.prototype.setUTCDate})
Object.defineProperty(Date.prototype,"nv_setMonth",{writable:true,value:Date.prototype.setMonth})
Object.defineProperty(Date.prototype,"nv_setUTCMonth",{writable:true,value:Date.prototype.setUTCMonth})
Object.defineProperty(Date.prototype,"nv_setFullYear",{writable:true,value:Date.prototype.setFullYear})
Object.defineProperty(Date.prototype,"nv_setUTCFullYear",{writable:true,value:Date.prototype.setUTCFullYear})
Object.defineProperty(Date.prototype,"nv_toUTCString",{writable:true,value:Date.prototype.toUTCString})
Object.defineProperty(Date.prototype,"nv_toISOString",{writable:true,value:Date.prototype.toISOString})
Object.defineProperty(Date.prototype,"nv_toJSON",{writable:true,value:Date.prototype.toJSON})
}
var nf_init_RegExp=function(){
Object.defineProperty(RegExp.prototype,"nv_constructor",{writable:true,value:"RegExp"})
Object.defineProperty(RegExp.prototype,"nv_exec",{writable:true,value:RegExp.prototype.exec})
Object.defineProperty(RegExp.prototype,"nv_test",{writable:true,value:RegExp.prototype.test})
Object.defineProperty(RegExp.prototype,"nv_toString",{writable:true,value:RegExp.prototype.toString})
Object.defineProperty(RegExp.prototype,"nv_source",{get:function(){return this.source;},set:function(){}});
Object.defineProperty(RegExp.prototype,"nv_global",{get:function(){return this.global;},set:function(){}});
Object.defineProperty(RegExp.prototype,"nv_ignoreCase",{get:function(){return this.ignoreCase;},set:function(){}});
Object.defineProperty(RegExp.prototype,"nv_multiline",{get:function(){return this.multiline;},set:function(){}});
Object.defineProperty(RegExp.prototype,"nv_lastIndex",{get:function(){return this.lastIndex;},set:function(v){this.lastIndex=v;}});
}
nf_init();
var nv_getDate=function(){var args=Array.prototype.slice.call(arguments);args.unshift(Date);return new(Function.prototype.bind.apply(Date, args));}
var nv_getRegExp=function(){var args=Array.prototype.slice.call(arguments);args.unshift(RegExp);return new(Function.prototype.bind.apply(RegExp, args));}
var nv_console={}
nv_console.nv_log=function(){var res="WXSRT:";for(var i=0;i<arguments.length;++i)res+=arguments[i]+" ";console.log(res);}
var nv_parseInt = parseInt, nv_parseFloat = parseFloat, nv_isNaN = isNaN, nv_isFinite = isFinite, nv_decodeURI = decodeURI, nv_decodeURIComponent = decodeURIComponent, nv_encodeURI = encodeURI, nv_encodeURIComponent = encodeURIComponent;
function $gdc(o,p,r) {
o=wh.rv(o);
if(o===null||o===undefined) return o;
if(typeof o==="string"||typeof o==="boolean"||typeof o==="number") return o;
if(o.constructor===Object){
var copy={};
for(var k in o)
if(Object.prototype.hasOwnProperty.call(o,k))
if(undefined===p) copy[k.substring(3)]=$gdc(o[k],p,r);
else copy[p+k]=$gdc(o[k],p,r);
return copy;
}
if(o.constructor===Array){
var copy=[];
for(var i=0;i<o.length;i++) copy.push($gdc(o[i],p,r));
return copy;
}
if(o.constructor===Date){
var copy=new Date();
copy.setTime(o.getTime());
return copy;
}
if(o.constructor===RegExp){
var f="";
if(o.global) f+="g";
if(o.ignoreCase) f+="i";
if(o.multiline) f+="m";
return (new RegExp(o.source,f));
}
if(r&&typeof o==="function"){
if ( r == 1 ) return $gdc(o(),undefined, 2);
if ( r == 2 ) return o;
}
return null;
}
var nv_JSON={}
nv_JSON.nv_stringify=function(o){
JSON.stringify(o);
return JSON.stringify($gdc(o));
}
nv_JSON.nv_parse=function(o){
if(o===undefined) return undefined;
var t=JSON.parse(o);
return $gdc(t,'nv_');
}

function _af(p, a, r, c){
p.extraAttr = {"t_action": a, "t_rawid": r };
if ( typeof(c) != 'undefined' ) p.extraAttr.t_cid = c;
}

function _ai(i,p,e,me,r,c){var x=_grp(p,e,me);if(x)i.push(x);else{i.push('');_wp(me+':import:'+r+':'+c+': Path `'+p+'` not found from `'+me+'`.')}}
function _grp(p,e,me){if(p[0]!='/'){var mepart=me.split('/');mepart.pop();var ppart=p.split('/');for(var i=0;i<ppart.length;i++){if( ppart[i]=='..')mepart.pop();else if(!ppart[i]||ppart[i]=='.')continue;else mepart.push(ppart[i]);}p=mepart.join('/');}if(me[0]=='.'&&p[0]=='/')p='.'+p;if(e[p])return p;if(e[p+'.wxml'])return p+'.wxml';}
function _gd(p,c,e,d){if(!c)return;if(d[p][c])return d[p][c];for(var x=e[p].i.length-1;x>=0;x--){if(e[p].i[x]&&d[e[p].i[x]][c])return d[e[p].i[x]][c]};for(var x=e[p].ti.length-1;x>=0;x--){var q=_grp(e[p].ti[x],e,p);if(q&&d[q][c])return d[q][c]}var ii=_gapi(e,p);for(var x=0;x<ii.length;x++){if(ii[x]&&d[ii[x]][c])return d[ii[x]][c]}for(var k=e[p].j.length-1;k>=0;k--)if(e[p].j[k]){for(var q=e[e[p].j[k]].ti.length-1;q>=0;q--){var pp=_grp(e[e[p].j[k]].ti[q],e,p);if(pp&&d[pp][c]){return d[pp][c]}}}}
function _gapi(e,p){if(!p)return [];if($gaic[p]){return $gaic[p]};var ret=[],q=[],h=0,t=0,put={},visited={};q.push(p);visited[p]=true;t++;while(h<t){var a=q[h++];for(var i=0;i<e[a].ic.length;i++){var nd=e[a].ic[i];var np=_grp(nd,e,a);if(np&&!visited[np]){visited[np]=true;q.push(np);t++;}}for(var i=0;a!=p&&i<e[a].ti.length;i++){var ni=e[a].ti[i];var nm=_grp(ni,e,a);if(nm&&!put[nm]){put[nm]=true;ret.push(nm);}}}$gaic[p]=ret;return ret;}
var $ixc={};function _ic(p,ent,me,e,s,r,gg){var x=_grp(p,ent,me);ent[me].j.push(x);if(x){if($ixc[x]){_wp('-1:include:-1:-1: `'+p+'` is being included in a loop, will be stop.');return;}$ixc[x]=true;try{ent[x].f(e,s,r,gg)}catch(e){}$ixc[x]=false;}else{_wp(me+':include:-1:-1: Included path `'+p+'` not found from `'+me+'`.')}}
function _w(tn,f,line,c){_wp(f+':template:'+line+':'+c+': Template `'+tn+'` not found.');}function _ev(dom){var changed=false;delete dom.properities;delete dom.n;if(dom.children){do{changed=false;var newch = [];for(var i=0;i<dom.children.length;i++){var ch=dom.children[i];if( ch.tag=='virtual'){changed=true;for(var j=0;ch.children&&j<ch.children.length;j++){newch.push(ch.children[j]);}}else { newch.push(ch); } } dom.children = newch; }while(changed);for(var i=0;i<dom.children.length;i++){_ev(dom.children[i]);}} return dom; }
function _tsd( root )
{
if( root.tag == "wx-wx-scope" ) 
{
root.tag = "virtual";
root.wxCkey = "11";
root['wxScopeData'] = root.attr['wx:scope-data'];
delete root.n;
delete root.raw;
delete root.generics;
delete root.attr;
}
for( var i = 0 ; root.children && i < root.children.length ; i++ )
{
_tsd( root.children[i] );
}
return root;
}

var e_={}
if(typeof(global.entrys)==='undefined')global.entrys={};e_=global.entrys;
var d_={}
if(typeof(global.defines)==='undefined')global.defines={};d_=global.defines;
var f_={}
if(typeof(global.modules)==='undefined')global.modules={};f_=global.modules || {};
var p_={}
__WXML_GLOBAL__.ops_cached = __WXML_GLOBAL__.ops_cached || {}
__WXML_GLOBAL__.ops_set = __WXML_GLOBAL__.ops_set || {};
__WXML_GLOBAL__.ops_init = __WXML_GLOBAL__.ops_init || {};
var z=__WXML_GLOBAL__.ops_set.$gwx || [];
function gz$gwx_1(){
if( __WXML_GLOBAL__.ops_cached.$gwx_1)return __WXML_GLOBAL__.ops_cached.$gwx_1
__WXML_GLOBAL__.ops_cached.$gwx_1=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
})(__WXML_GLOBAL__.ops_cached.$gwx_1);return __WXML_GLOBAL__.ops_cached.$gwx_1
}
function gz$gwx_2(){
if( __WXML_GLOBAL__.ops_cached.$gwx_2)return __WXML_GLOBAL__.ops_cached.$gwx_2
__WXML_GLOBAL__.ops_cached.$gwx_2=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
Z([[7],[3,'showMask']])
Z([[7],[3,'unlockModle']])
Z([[7],[3,'noUpModle']])
Z([[7],[3,'showPrivacy']])
Z([[2,'?:'],[[7],[3,'isSubscribeShow']],[1,'index hasBottom'],[1,'index']])
Z([3,'avatarTextWrap'])
Z([[2,'&&'],[[7],[3,'hasVip']],[[7],[3,'isAuth']]])
Z([[2,'&&'],[[7],[3,'isAuth']],[[2,'!'],[[7],[3,'hasVip']]]])
Z([[2,'!'],[[7],[3,'isAuth']]])
Z([[7],[3,'showShare']])
Z([[2,'!'],[[7],[3,'selectSubjectShow']]])
Z([3,'exam'])
Z([[7],[3,'isAuth']])
Z(z[12])
Z([[7],[3,'selectSubjectShow']])
Z([3,'selectSubject'])
Z([[7],[3,'subjectList']])
Z([3,'goLearn'])
Z([3,'subjectWrap'])
Z([[6],[[7],[3,'item']],[3,'subjectId']])
Z([[6],[[7],[3,'item']],[3,'stage']])
Z([[6],[[7],[3,'item']],[3,'unlockDays']])
Z([[6],[[7],[3,'item']],[3,'totalDays']])
Z([[2,'=='],[[6],[[7],[3,'item']],[3,'subjectId']],[1,1]])
Z([[2,'=='],[[6],[[7],[3,'item']],[3,'subjectId']],[1,2]])
Z([[2,'=='],[[6],[[7],[3,'item']],[3,'subjectId']],[1,3]])
Z([[2,'=='],[[6],[[7],[3,'item']],[3,'subjectId']],[1,4]])
Z([3,'tagWrap'])
Z([[2,'&&'],[[2,'!'],[[7],[3,'isAuth']]],[[2,'!='],[[6],[[7],[3,'item']],[3,'subjectId']],[1,3]]])
Z([[2,'&&'],[[2,'!'],[[7],[3,'isAuth']]],[[2,'=='],[[6],[[7],[3,'item']],[3,'subjectId']],[1,3]]])
Z([[2,'&&'],[[2,'&&'],[[2,'&&'],[[2,'>='],[[6],[[7],[3,'item']],[3,'stage']],[[6],[[7],[3,'item']],[3,'unlockDays']]],[[2,'!='],[[6],[[7],[3,'item']],[3,'stage']],[[6],[[7],[3,'item']],[3,'totalDays']]]],[[7],[3,'isAuth']]],[[2,'!'],[[7],[3,'hasVip']]]])
Z([[2,'&&'],[[2,'&&'],[[6],[[7],[3,'item']],[3,'lastStudy']],[[7],[3,'isAuth']]],[[2,'!'],[[2,'>='],[[6],[[7],[3,'item']],[3,'stage']],[[6],[[7],[3,'item']],[3,'unlockDays']]]]])
Z(z[7])
Z(z[7])
Z([[2,'!'],[[7],[3,'checkStatus']]])
Z([[7],[3,'$KcShowGuide$show']])
Z([[2,'&&'],[[7],[3,'isSubscribeShow']],[[2,'!'],[[7],[3,'selectSubjectShow']]]])
Z([[2,'!'],[[7],[3,'$KcLoading$loadingHide']]])
Z([[7],[3,'$KcErrorModal$show']])
Z([[7],[3,'$kcUpdateModle$show']])
Z([[7],[3,'$vipModle$show']])
Z([3,'modal'])
Z([[7],[3,'$vipModle$hasVip']])
Z(z[42])
Z([[2,'!'],[[7],[3,'$vipModle$hasVip']]])
Z([[7],[3,'$receiveVipModal$show']])
Z([[7],[3,'$receiveVipModal$KcErrorModal$show']])
Z([[2,'!'],[[7],[3,'$receiveVipModal$KcLoading$loadingHide']]])
Z([[7],[3,'$KcUpValue$show']])
Z([3,'btnWrap'])
Z([[7],[3,'$KcUpValue$leftBtnText']])
Z([[7],[3,'$KcUpValue$rightBtnText']])
Z([[7],[3,'$KcUpValue$rightBtnTips']])
})(__WXML_GLOBAL__.ops_cached.$gwx_2);return __WXML_GLOBAL__.ops_cached.$gwx_2
}
function gz$gwx_3(){
if( __WXML_GLOBAL__.ops_cached.$gwx_3)return __WXML_GLOBAL__.ops_cached.$gwx_3
__WXML_GLOBAL__.ops_cached.$gwx_3=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
Z([3,'container'])
Z([[2,'&&'],[[2,'&&'],[[7],[3,'tipsShow']],[[2,'=='],[[7],[3,'sid']],[1,1]]],[[2,'=='],[[7],[3,'day']],[1,1]]])
Z([[7],[3,'content']])
Z([3,'point'])
Z([[6],[[7],[3,'item']],[3,'points']])
Z(z[3])
Z([[2,'>'],[[6],[[7],[3,'point']],[3,'questionNum']],[1,1]])
Z([[2,'!'],[[7],[3,'$KcLoading$loadingHide']]])
Z([[7],[3,'$KcErrorModal$show']])
})(__WXML_GLOBAL__.ops_cached.$gwx_3);return __WXML_GLOBAL__.ops_cached.$gwx_3
}
function gz$gwx_4(){
if( __WXML_GLOBAL__.ops_cached.$gwx_4)return __WXML_GLOBAL__.ops_cached.$gwx_4
__WXML_GLOBAL__.ops_cached.$gwx_4=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
Z([3,'points-ctn _9b0f65d'])
Z([[7],[3,'success']])
Z(z[1])
Z([[7],[3,'$KcShowError$show']])
})(__WXML_GLOBAL__.ops_cached.$gwx_4);return __WXML_GLOBAL__.ops_cached.$gwx_4
}
function gz$gwx_5(){
if( __WXML_GLOBAL__.ops_cached.$gwx_5)return __WXML_GLOBAL__.ops_cached.$gwx_5
__WXML_GLOBAL__.ops_cached.$gwx_5=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
Z([[7],[3,'ranking']])
Z([[7],[3,'index']])
Z([a,[3,'ranking '],[[2,'?:'],[[6],[[7],[3,'item']],[3,'userLocation']],[1,'special'],[1,'']],[3,' _c7b0ee0']])
Z([[2,'<'],[[7],[3,'index']],[1,3]])
Z([[2,'>='],[[6],[[6],[[7],[3,'item']],[3,'heads']],[3,'length']],[1,5]])
Z([[2,'!'],[[7],[3,'$KcLoading$loadingHide']]])
Z([[7],[3,'$KcErrorModal$show']])
})(__WXML_GLOBAL__.ops_cached.$gwx_5);return __WXML_GLOBAL__.ops_cached.$gwx_5
}
function gz$gwx_6(){
if( __WXML_GLOBAL__.ops_cached.$gwx_6)return __WXML_GLOBAL__.ops_cached.$gwx_6
__WXML_GLOBAL__.ops_cached.$gwx_6=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
Z([3,'touchEnd'])
Z([3,'touchMove'])
Z([3,'touchStart'])
Z([3,'container report'])
Z([3,'head-data'])
Z([3,'canvasWrap'])
Z([[7],[3,'showCanvas']])
Z([[2,'&&'],[[7],[3,'showCanvas']],[[2,'!='],[[7],[3,'accNum']],[[7],[3,'NaN']]]])
Z([[2,'=='],[[7],[3,'type']],[1,1]])
Z([3,'main'])
Z([3,'titleWrap'])
Z(z[8])
Z([[2,'&&'],[[2,'&&'],[[2,'&&'],[[2,'=='],[[7],[3,'type']],[1,1]],[[7],[3,'tipsShow']]],[[2,'=='],[[7],[3,'sid']],[1,1]]],[[2,'=='],[[6],[[7],[3,'days']],[1,0]],[1,1]]])
Z([[2,'&&'],[[7],[3,'wrongSectionShow']],[[2,'!'],[[2,'&&'],[[2,'&&'],[[2,'=='],[[7],[3,'type']],[1,1]],[[2,'=='],[[7],[3,'sid']],[1,1]]],[[2,'=='],[[6],[[7],[3,'days']],[1,0]],[1,1]]]]])
Z([[7],[3,'content']])
Z([3,'pointIndex'])
Z([3,'point'])
Z([[6],[[7],[3,'item']],[3,'points']])
Z(z[16])
Z([3,'pointDetailToggle'])
Z([3,'pointsBox'])
Z([[6],[[7],[3,'point']],[3,'pointId']])
Z([3,'rfShow'])
Z([[2,'>'],[[6],[[7],[3,'point']],[3,'questionNum']],[1,1]])
Z([[2,'&&'],[[2,'>'],[[2,'/'],[[6],[[7],[3,'point']],[3,'fnum']],[[6],[[7],[3,'point']],[3,'questionNum']]],[1,0.4]],[[2,'>'],[[6],[[7],[3,'point']],[3,'questionNum']],[1,1]]])
Z([[6],[[7],[3,'pointToggleState']],[[7],[3,'pointIndex']]])
Z([[2,'||'],[[2,'=='],[[7],[3,'type']],[1,1]],[[2,'=='],[[7],[3,'type']],[1,3]]])
Z([[2,'!=='],[[7],[3,'allDay']],[[7],[3,'day']]])
Z([[2,'!'],[[7],[3,'$KcLoading$loadingHide']]])
Z([[7],[3,'$KcErrorModal$show']])
Z([[7],[3,'$KcUpValue$show']])
Z([3,'btnWrap'])
Z([[7],[3,'$KcUpValue$leftBtnText']])
Z([[7],[3,'$KcUpValue$rightBtnText']])
Z([[7],[3,'$KcUpValue$rightBtnTips']])
})(__WXML_GLOBAL__.ops_cached.$gwx_6);return __WXML_GLOBAL__.ops_cached.$gwx_6
}
function gz$gwx_7(){
if( __WXML_GLOBAL__.ops_cached.$gwx_7)return __WXML_GLOBAL__.ops_cached.$gwx_7
__WXML_GLOBAL__.ops_cached.$gwx_7=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
Z([3,'review-filter-ctn _ee9cc2c'])
Z([3,'_ee9cc2c'])
Z([[2,'!'],[[6],[[6],[[7],[3,'subjectList']],[[7],[3,'current']]],[3,'did']]])
Z(z[1])
Z([3,'dindex'])
Z([3,'ditem'])
Z([[6],[[6],[[7],[3,'subjectList']],[[7],[3,'current']]],[3,'dayList']])
Z([[7],[3,'dindex']])
Z([3,'itemDayTap'])
Z([a,[3,'item-day '],[[2,'?:'],[[6],[[6],[[7],[3,'subjectList']],[[7],[3,'current']]],[3,'active']],[[2,'?:'],[[2,'&&'],[[2,'=='],[[7],[3,'reviewMode']],[1,1]],[[2,'<='],[[6],[[7],[3,'ditem']],[3,'cumulativeWrongNum']],[1,0]]],[1,'unable'],[[2,'?:'],[[6],[[7],[3,'ditem']],[3,'select']],[1,'select'],[1,'']]],[1,'unable']],[3,' _ee9cc2c']])
Z(z[7])
Z([[6],[[7],[3,'ditem']],[3,'lastStudy']])
Z([[7],[3,'showChangeMode']])
})(__WXML_GLOBAL__.ops_cached.$gwx_7);return __WXML_GLOBAL__.ops_cached.$gwx_7
}
function gz$gwx_8(){
if( __WXML_GLOBAL__.ops_cached.$gwx_8)return __WXML_GLOBAL__.ops_cached.$gwx_8
__WXML_GLOBAL__.ops_cached.$gwx_8=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
Z([3,'touchEnd'])
Z([3,'touchMove'])
Z([3,'touchStart'])
Z([3,'container'])
Z([3,'head'])
Z([[7],[3,'showFilterTip']])
Z([[7],[3,'showCanvas']])
Z([[2,'&&'],[[7],[3,'showCanvas']],[[2,'!='],[[7],[3,'accNum']],[[7],[3,'NaN']]]])
Z([[7],[3,'content']])
Z([3,'item'])
Z([3,'pointIndex'])
Z([3,'point'])
Z([[6],[[7],[3,'item']],[3,'points']])
Z(z[11])
Z([3,'pointDetailToggle'])
Z([3,'pointsBox'])
Z([[6],[[7],[3,'point']],[3,'pointId']])
Z([3,'rfShow'])
Z([[2,'>'],[[6],[[7],[3,'point']],[3,'questionNum']],[1,1]])
Z([[2,'&&'],[[2,'>'],[[2,'/'],[[6],[[7],[3,'point']],[3,'fnum']],[[6],[[7],[3,'point']],[3,'questionNum']]],[1,0.4]],[[2,'>'],[[6],[[7],[3,'point']],[3,'questionNum']],[1,1]]])
Z([[6],[[7],[3,'pointToggleState']],[[7],[3,'pointIndex']]])
Z([[2,'!'],[[7],[3,'$KcLoading$loadingHide']]])
Z([[7],[3,'$KcErrorModal$show']])
})(__WXML_GLOBAL__.ops_cached.$gwx_8);return __WXML_GLOBAL__.ops_cached.$gwx_8
}
function gz$gwx_9(){
if( __WXML_GLOBAL__.ops_cached.$gwx_9)return __WXML_GLOBAL__.ops_cached.$gwx_9
__WXML_GLOBAL__.ops_cached.$gwx_9=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
Z([3,'share'])
Z([[7],[3,'successShow']])
Z([[7],[3,'maskShow']])
Z([[7],[3,'errorShow']])
})(__WXML_GLOBAL__.ops_cached.$gwx_9);return __WXML_GLOBAL__.ops_cached.$gwx_9
}
function gz$gwx_10(){
if( __WXML_GLOBAL__.ops_cached.$gwx_10)return __WXML_GLOBAL__.ops_cached.$gwx_10
__WXML_GLOBAL__.ops_cached.$gwx_10=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
Z([[7],[3,'showPrivacy']])
Z([a,[3,'container studyPage '],[[2,'?:'],[[2,'=='],[[7],[3,'status']],[1,0]],[1,'fixed'],[1,'']]])
Z([[7],[3,'tipsShow']])
Z([[2,'=='],[[7],[3,'status']],[1,0]])
Z(z[3])
Z([[2,'&&'],[[2,'=='],[[7],[3,'type']],[1,2]],[[2,'!='],[[6],[[7],[3,'nowTopic']],[3,'falseNum']],[1,0]]])
Z([[2,'&&'],[[2,'<'],[[7],[3,'handTipShowTime']],[1,3]],[[7],[3,'handTips']]])
Z([[6],[[7],[3,'nowTopic']],[3,'option']])
Z([3,'option'])
Z([3,'tapOption'])
Z([3,'answerItem'])
Z([a,[3,'status'],[[6],[[7],[3,'optionStatus']],[[7],[3,'index']]]])
Z([[7],[3,'index']])
Z([[2,'||'],[[2,'||'],[[2,'=='],[[6],[[7],[3,'optionStatus']],[[7],[3,'index']]],[1,3]],[[2,'=='],[[6],[[7],[3,'optionStatus']],[[7],[3,'index']]],[1,4]]],[[2,'=='],[[6],[[7],[3,'optionStatus']],[[7],[3,'index']]],[1,5]]])
Z([[2,'=='],[[6],[[7],[3,'optionStatus']],[[7],[3,'index']]],[1,2]])
Z([[2,'=='],[[7],[3,'status']],[1,2]])
Z([3,'answerList'])
Z([3,'answerHead'])
Z([[2,'&&'],[[2,'=='],[[7],[3,'type']],[1,1]],[[2,'||'],[[2,'=='],[[6],[[7],[3,'answerList']],[[7],[3,'index']]],[1,1]],[[2,'=='],[[6],[[7],[3,'answerList']],[[7],[3,'index']]],[1,2]]]])
Z([3,'markBox'])
Z([[2,'=='],[[6],[[7],[3,'answerList']],[[7],[3,'index']]],[1,1]])
Z([[2,'=='],[[6],[[7],[3,'answerList']],[[7],[3,'index']]],[1,2]])
Z([[2,'&&'],[[2,'&&'],[[2,'=='],[[7],[3,'type']],[1,2]],[[7],[3,'onlyFalse']]],[[2,'||'],[[2,'||'],[[2,'=='],[[6],[[7],[3,'answerList']],[[7],[3,'index']]],[1,0]],[[2,'=='],[[6],[[7],[3,'answerList']],[[7],[3,'index']]],[1,1]]],[[2,'=='],[[6],[[7],[3,'answerList']],[[7],[3,'index']]],[1,3]]]])
Z(z[19])
Z([[2,'||'],[[2,'=='],[[6],[[7],[3,'answerList']],[[7],[3,'index']]],[1,0]],[[2,'=='],[[6],[[7],[3,'answerList']],[[7],[3,'index']]],[1,1]]])
Z([[2,'=='],[[6],[[7],[3,'answerList']],[[7],[3,'index']]],[1,3]])
Z(z[15])
Z([3,'longpress'])
Z([3,'analysis'])
Z([[6],[[7],[3,'nowTopic']],[3,'easyWrongPoint']])
Z([[2,'&&'],[[2,'=='],[[7],[3,'status']],[1,2]],[[6],[[7],[3,'nowTopic']],[3,'videoUrl']]])
Z([3,'video'])
Z([[7],[3,'hasVip']])
Z([[2,'&&'],[[2,'!'],[[7],[3,'hasVip']]],[[7],[3,'firstVideoPlay']]])
Z([[7],[3,'firstVideoClick']])
Z([[2,'=='],[[6],[[7],[3,'nowTopic']],[3,'videoState']],[1,0]])
Z(z[15])
Z([[2,'>'],[[6],[[7],[3,'nowTopic']],[3,'pointQuestionNum']],[1,1]])
Z([a,[3,'endAlert '],[[2,'?:'],[[7],[3,'endAlertShow']],[1,'endAlertShow'],[1,'']]])
Z([[2,'>='],[[7],[3,'changeValue']],[1,0]])
Z([[2,'<'],[[7],[3,'changeValue']],[1,0]])
Z([[2,'=='],[[7],[3,'type']],[1,1]])
Z([[2,'!='],[[7],[3,'changeValue']],[1,0]])
Z([[2,'=='],[[7],[3,'type']],[1,2]])
Z(z[42])
Z(z[40])
Z(z[39])
Z([[7],[3,'maskShow']])
Z([[7],[3,'markTips']])
Z([[7],[3,'longtips']])
Z([[2,'!'],[[7],[3,'$KcLoading$loadingHide']]])
Z([[7],[3,'$KcErrorModal$show']])
Z([[7],[3,'$KcUpValue$show']])
Z([3,'btnWrap'])
Z([[7],[3,'$KcUpValue$leftBtnText']])
Z([[7],[3,'$KcUpValue$rightBtnText']])
Z([[7],[3,'$KcUpValue$rightBtnTips']])
})(__WXML_GLOBAL__.ops_cached.$gwx_10);return __WXML_GLOBAL__.ops_cached.$gwx_10
}
function gz$gwx_11(){
if( __WXML_GLOBAL__.ops_cached.$gwx_11)return __WXML_GLOBAL__.ops_cached.$gwx_11
__WXML_GLOBAL__.ops_cached.$gwx_11=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
Z([3,'content _0f35b3d'])
Z([[7],[3,'noData']])
Z([3,'chapterIndex'])
Z([[6],[[6],[[7],[3,'couresData']],[[7],[3,'subjectIndex']]],[3,'chapters']])
Z([[6],[[7],[3,'item']],[3,'sections']])
Z([3,'toggleLesson'])
Z([3,'lessonWrap _0f35b3d'])
Z([[7],[3,'index']])
Z([[7],[3,'chapterIndex']])
Z(z[5])
Z([3,'_0f35b3d'])
Z([[6],[[7],[3,'item']],[3,'toggle']])
Z([[6],[[7],[3,'item']],[3,'points']])
Z([3,'title _0f35b3d'])
Z([[2,'>'],[[6],[[7],[3,'item']],[3,'questionNum']],[1,1]])
Z([[2,'&&'],[[2,'>'],[[2,'/'],[[6],[[7],[3,'item']],[3,'fnum']],[[6],[[7],[3,'item']],[3,'questionNum']]],[1,0.4]],[[2,'>'],[[6],[[7],[3,'item']],[3,'questionNum']],[1,1]]])
})(__WXML_GLOBAL__.ops_cached.$gwx_11);return __WXML_GLOBAL__.ops_cached.$gwx_11
}
function gz$gwx_12(){
if( __WXML_GLOBAL__.ops_cached.$gwx_12)return __WXML_GLOBAL__.ops_cached.$gwx_12
__WXML_GLOBAL__.ops_cached.$gwx_12=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
Z([3,'up _e6de380'])
Z([[7],[3,'taskList']])
Z([[2,'=='],[[6],[[7],[3,'item']],[3,'taskAct']],[1,3]])
Z([[7],[3,'$KcModulForHelp$show']])
Z([[2,'!'],[[7],[3,'$KcLoading$loadingHide']]])
Z([[7],[3,'$KcErrorModal$show']])
})(__WXML_GLOBAL__.ops_cached.$gwx_12);return __WXML_GLOBAL__.ops_cached.$gwx_12
}
function gz$gwx_13(){
if( __WXML_GLOBAL__.ops_cached.$gwx_13)return __WXML_GLOBAL__.ops_cached.$gwx_13
__WXML_GLOBAL__.ops_cached.$gwx_13=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
Z([[7],[3,'noData']])
})(__WXML_GLOBAL__.ops_cached.$gwx_13);return __WXML_GLOBAL__.ops_cached.$gwx_13
}
function gz$gwx_14(){
if( __WXML_GLOBAL__.ops_cached.$gwx_14)return __WXML_GLOBAL__.ops_cached.$gwx_14
__WXML_GLOBAL__.ops_cached.$gwx_14=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
})(__WXML_GLOBAL__.ops_cached.$gwx_14);return __WXML_GLOBAL__.ops_cached.$gwx_14
}
function gz$gwx_15(){
if( __WXML_GLOBAL__.ops_cached.$gwx_15)return __WXML_GLOBAL__.ops_cached.$gwx_15
__WXML_GLOBAL__.ops_cached.$gwx_15=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
Z([3,'container studyPage'])
Z([[6],[[7],[3,'nowTopic']],[3,'option']])
Z([3,'option'])
Z([3,'tapOption'])
Z([3,'answerItem'])
Z([a,[3,'status'],[[6],[[7],[3,'optionStatus']],[[7],[3,'index']]]])
Z([[7],[3,'index']])
Z([[2,'||'],[[2,'||'],[[2,'=='],[[6],[[7],[3,'optionStatus']],[[7],[3,'index']]],[1,3]],[[2,'=='],[[6],[[7],[3,'optionStatus']],[[7],[3,'index']]],[1,4]]],[[2,'=='],[[6],[[7],[3,'optionStatus']],[[7],[3,'index']]],[1,5]]])
Z([[2,'=='],[[6],[[7],[3,'optionStatus']],[[7],[3,'index']]],[1,2]])
Z([[2,'=='],[[7],[3,'status']],[1,2]])
Z([3,'answerList'])
Z([3,'answerHead'])
Z([[2,'&&'],[[2,'=='],[[7],[3,'type']],[1,1]],[[2,'||'],[[2,'=='],[[6],[[7],[3,'answerList']],[[7],[3,'index']]],[1,1]],[[2,'=='],[[6],[[7],[3,'answerList']],[[7],[3,'index']]],[1,2]]]])
Z([3,'markBox'])
Z([[2,'=='],[[6],[[7],[3,'answerList']],[[7],[3,'index']]],[1,1]])
Z([[2,'=='],[[6],[[7],[3,'answerList']],[[7],[3,'index']]],[1,2]])
Z([[2,'&&'],[[2,'&&'],[[2,'=='],[[7],[3,'type']],[1,2]],[[7],[3,'onlyFalse']]],[[2,'||'],[[2,'||'],[[2,'=='],[[6],[[7],[3,'answerList']],[[7],[3,'index']]],[1,0]],[[2,'=='],[[6],[[7],[3,'answerList']],[[7],[3,'index']]],[1,1]]],[[2,'=='],[[6],[[7],[3,'answerList']],[[7],[3,'index']]],[1,3]]]])
Z(z[13])
Z([[2,'||'],[[2,'=='],[[6],[[7],[3,'answerList']],[[7],[3,'index']]],[1,0]],[[2,'=='],[[6],[[7],[3,'answerList']],[[7],[3,'index']]],[1,1]]])
Z([[2,'=='],[[6],[[7],[3,'answerList']],[[7],[3,'index']]],[1,3]])
Z(z[9])
Z([3,'longpress'])
Z([3,'analysis'])
Z([[6],[[7],[3,'nowTopic']],[3,'easyWrongPoint']])
Z(z[9])
Z([[2,'>'],[[6],[[7],[3,'nowTopic']],[3,'pointQuestionNum']],[1,1]])
Z([[7],[3,'maskShow']])
Z([[7],[3,'markTips']])
Z([[7],[3,'longtips']])
Z([[2,'!'],[[7],[3,'$KcLoading$loadingHide']]])
Z([[7],[3,'$KcErrorModal$show']])
})(__WXML_GLOBAL__.ops_cached.$gwx_15);return __WXML_GLOBAL__.ops_cached.$gwx_15
}
__WXML_GLOBAL__.ops_set.$gwx=z;
__WXML_GLOBAL__.ops_init.$gwx=true;
var nv_require=function(){var nnm={};var nom={};return function(n){if(n[0]==='p'&&n[1]==='_'&&f_[n.slice(2)])return f_[n.slice(2)];return function(){if(!nnm[n]) return undefined;try{if(!nom[n])nom[n]=nnm[n]();return nom[n];}catch(e){e.message=e.message.replace(/nv_/g,'');var tmp = e.stack.substring(0,e.stack.lastIndexOf(n));e.stack = tmp.substring(0,tmp.lastIndexOf('\n'));e.stack = e.stack.replace(/\snv_/g,' ');e.stack = $gstack(e.stack);e.stack += '\n    at ' + n.substring(2);console.error(e);}
}}}()
var x=['./pages/activate.wxml','./pages/index.wxml','./pages/learnIndex.wxml','./pages/points.wxml','./pages/ranking.wxml','./pages/report.wxml','./pages/reviewFilter.wxml','./pages/reviewIndex.wxml','./pages/share.wxml','./pages/study.wxml','./pages/studyData.wxml','./pages/upValue.wxml','./pages/upValueList.wxml','./pages/web.wxml','./pages/wrongTopic.wxml'];d_[x[0]]={}
var m0=function(e,s,r,gg){
var z=gz$gwx_1()
return r
}
e_[x[0]]={f:m0,j:[],i:[],ti:[],ic:[]}
d_[x[1]]={}
var m1=function(e,s,r,gg){
var z=gz$gwx_2()
var xC=_v()
_(r,xC)
if(_oz(z,0,e,s,gg)){xC.wxVkey=1
}
var oD=_v()
_(r,oD)
if(_oz(z,1,e,s,gg)){oD.wxVkey=1
}
var fE=_v()
_(r,fE)
if(_oz(z,2,e,s,gg)){fE.wxVkey=1
}
var cF=_v()
_(r,cF)
if(_oz(z,3,e,s,gg)){cF.wxVkey=1
}
var oR=_n('view')
_rz(z,oR,'class',4,e,s,gg)
var cT=_n('view')
var oV=_n('view')
_rz(z,oV,'class',5,e,s,gg)
var cW=_v()
_(oV,cW)
if(_oz(z,6,e,s,gg)){cW.wxVkey=1
}
var oX=_v()
_(oV,oX)
if(_oz(z,7,e,s,gg)){oX.wxVkey=1
}
var lY=_v()
_(oV,lY)
if(_oz(z,8,e,s,gg)){lY.wxVkey=1
}
cW.wxXCkey=1
oX.wxXCkey=1
lY.wxXCkey=1
_(cT,oV)
var hU=_v()
_(cT,hU)
if(_oz(z,9,e,s,gg)){hU.wxVkey=1
}
hU.wxXCkey=1
_(oR,cT)
var fS=_v()
_(oR,fS)
if(_oz(z,10,e,s,gg)){fS.wxVkey=1
var aZ=_n('view')
_rz(z,aZ,'class',11,e,s,gg)
var t1=_v()
_(aZ,t1)
if(_oz(z,12,e,s,gg)){t1.wxVkey=1
}
var e2=_v()
_(aZ,e2)
if(_oz(z,13,e,s,gg)){e2.wxVkey=1
}
t1.wxXCkey=1
e2.wxXCkey=1
_(fS,aZ)
}
fS.wxXCkey=1
_(r,oR)
var hG=_v()
_(r,hG)
if(_oz(z,14,e,s,gg)){hG.wxVkey=1
var b3=_n('view')
_rz(z,b3,'class',15,e,s,gg)
var o6=_v()
_(b3,o6)
var f7=function(h9,c8,o0,gg){
var oBB=_mz(z,'view',['bindtap',17,'class',1,'data-wpygolearn-a',2,'data-wpygolearn-b',3,'data-wpygolearn-c',4,'data-wpygolearn-d',5],[],h9,c8,gg)
var lCB=_v()
_(oBB,lCB)
if(_oz(z,23,h9,c8,gg)){lCB.wxVkey=1
}
var aDB=_v()
_(oBB,aDB)
if(_oz(z,24,h9,c8,gg)){aDB.wxVkey=1
}
var tEB=_v()
_(oBB,tEB)
if(_oz(z,25,h9,c8,gg)){tEB.wxVkey=1
}
var eFB=_v()
_(oBB,eFB)
if(_oz(z,26,h9,c8,gg)){eFB.wxVkey=1
}
var bGB=_n('view')
_rz(z,bGB,'class',27,h9,c8,gg)
var oHB=_v()
_(bGB,oHB)
if(_oz(z,28,h9,c8,gg)){oHB.wxVkey=1
}
var xIB=_v()
_(bGB,xIB)
if(_oz(z,29,h9,c8,gg)){xIB.wxVkey=1
}
var oJB=_v()
_(bGB,oJB)
if(_oz(z,30,h9,c8,gg)){oJB.wxVkey=1
}
var fKB=_v()
_(bGB,fKB)
if(_oz(z,31,h9,c8,gg)){fKB.wxVkey=1
}
oHB.wxXCkey=1
xIB.wxXCkey=1
oJB.wxXCkey=1
fKB.wxXCkey=1
_(oBB,bGB)
lCB.wxXCkey=1
aDB.wxXCkey=1
tEB.wxXCkey=1
eFB.wxXCkey=1
_(o0,oBB)
return o0
}
o6.wxXCkey=2
_2z(z,16,f7,e,s,gg,o6,'item','index','')
var o4=_v()
_(b3,o4)
if(_oz(z,32,e,s,gg)){o4.wxVkey=1
}
var x5=_v()
_(b3,x5)
if(_oz(z,33,e,s,gg)){x5.wxVkey=1
var cLB=_v()
_(x5,cLB)
if(_oz(z,34,e,s,gg)){cLB.wxVkey=1
}
cLB.wxXCkey=1
}
o4.wxXCkey=1
x5.wxXCkey=1
_(hG,b3)
}
var oH=_v()
_(r,oH)
if(_oz(z,35,e,s,gg)){oH.wxVkey=1
}
var cI=_v()
_(r,cI)
if(_oz(z,36,e,s,gg)){cI.wxVkey=1
}
var oJ=_v()
_(r,oJ)
if(_oz(z,37,e,s,gg)){oJ.wxVkey=1
}
var lK=_v()
_(r,lK)
if(_oz(z,38,e,s,gg)){lK.wxVkey=1
}
var aL=_v()
_(r,aL)
if(_oz(z,39,e,s,gg)){aL.wxVkey=1
}
var tM=_v()
_(r,tM)
if(_oz(z,40,e,s,gg)){tM.wxVkey=1
var hMB=_n('view')
_rz(z,hMB,'class',41,e,s,gg)
var oNB=_v()
_(hMB,oNB)
if(_oz(z,42,e,s,gg)){oNB.wxVkey=1
}
var cOB=_v()
_(hMB,cOB)
if(_oz(z,43,e,s,gg)){cOB.wxVkey=1
}
var oPB=_v()
_(hMB,oPB)
if(_oz(z,44,e,s,gg)){oPB.wxVkey=1
}
oNB.wxXCkey=1
cOB.wxXCkey=1
oPB.wxXCkey=1
_(tM,hMB)
}
var eN=_v()
_(r,eN)
if(_oz(z,45,e,s,gg)){eN.wxVkey=1
}
var bO=_v()
_(r,bO)
if(_oz(z,46,e,s,gg)){bO.wxVkey=1
}
var oP=_v()
_(r,oP)
if(_oz(z,47,e,s,gg)){oP.wxVkey=1
}
var xQ=_v()
_(r,xQ)
if(_oz(z,48,e,s,gg)){xQ.wxVkey=1
var lQB=_n('view')
_rz(z,lQB,'class',49,e,s,gg)
var aRB=_v()
_(lQB,aRB)
if(_oz(z,50,e,s,gg)){aRB.wxVkey=1
}
var tSB=_v()
_(lQB,tSB)
if(_oz(z,51,e,s,gg)){tSB.wxVkey=1
var eTB=_v()
_(tSB,eTB)
if(_oz(z,52,e,s,gg)){eTB.wxVkey=1
}
eTB.wxXCkey=1
}
aRB.wxXCkey=1
tSB.wxXCkey=1
_(xQ,lQB)
}
xC.wxXCkey=1
oD.wxXCkey=1
fE.wxXCkey=1
cF.wxXCkey=1
hG.wxXCkey=1
oH.wxXCkey=1
cI.wxXCkey=1
oJ.wxXCkey=1
lK.wxXCkey=1
aL.wxXCkey=1
tM.wxXCkey=1
eN.wxXCkey=1
bO.wxXCkey=1
oP.wxXCkey=1
xQ.wxXCkey=1
return r
}
e_[x[1]]={f:m1,j:[],i:[],ti:[],ic:[]}
d_[x[2]]={}
var m2=function(e,s,r,gg){
var z=gz$gwx_3()
var oXB=_n('view')
_rz(z,oXB,'class',0,e,s,gg)
var fYB=_v()
_(oXB,fYB)
if(_oz(z,1,e,s,gg)){fYB.wxVkey=1
}
var cZB=_v()
_(oXB,cZB)
var h1B=function(c3B,o2B,o4B,gg){
var a6B=_v()
_(o4B,a6B)
var t7B=function(b9B,e8B,o0B,gg){
var oBC=_v()
_(o0B,oBC)
if(_oz(z,6,b9B,e8B,gg)){oBC.wxVkey=1
}
oBC.wxXCkey=1
return o0B
}
a6B.wxXCkey=2
_2z(z,4,t7B,c3B,o2B,gg,a6B,'point','index','point')
return o4B
}
cZB.wxXCkey=2
_2z(z,2,h1B,e,s,gg,cZB,'item','index','')
fYB.wxXCkey=1
_(r,oXB)
var oVB=_v()
_(r,oVB)
if(_oz(z,7,e,s,gg)){oVB.wxVkey=1
}
var xWB=_v()
_(r,xWB)
if(_oz(z,8,e,s,gg)){xWB.wxVkey=1
}
oVB.wxXCkey=1
xWB.wxXCkey=1
return r
}
e_[x[2]]={f:m2,j:[],i:[],ti:[],ic:[]}
d_[x[3]]={}
var m3=function(e,s,r,gg){
var z=gz$gwx_4()
var cDC=_n('view')
_rz(z,cDC,'class',0,e,s,gg)
var hEC=_v()
_(cDC,hEC)
if(_oz(z,1,e,s,gg)){hEC.wxVkey=1
}
var oFC=_v()
_(cDC,oFC)
if(_oz(z,2,e,s,gg)){oFC.wxVkey=1
}
var cGC=_v()
_(cDC,cGC)
if(_oz(z,3,e,s,gg)){cGC.wxVkey=1
}
hEC.wxXCkey=1
oFC.wxXCkey=1
cGC.wxXCkey=1
_(r,cDC)
return r
}
e_[x[3]]={f:m3,j:[],i:[],ti:[],ic:[]}
d_[x[4]]={}
var m4=function(e,s,r,gg){
var z=gz$gwx_5()
var tKC=_v()
_(r,tKC)
var eLC=function(oNC,bMC,xOC,gg){
var fQC=_n('view')
_rz(z,fQC,'class',2,oNC,bMC,gg)
var cRC=_v()
_(fQC,cRC)
if(_oz(z,3,oNC,bMC,gg)){cRC.wxVkey=1
}
var hSC=_v()
_(fQC,hSC)
if(_oz(z,4,oNC,bMC,gg)){hSC.wxVkey=1
}
cRC.wxXCkey=1
hSC.wxXCkey=1
_(xOC,fQC)
return xOC
}
tKC.wxXCkey=2
_2z(z,0,eLC,e,s,gg,tKC,'item','index','{{index}}')
var lIC=_v()
_(r,lIC)
if(_oz(z,5,e,s,gg)){lIC.wxVkey=1
}
var aJC=_v()
_(r,aJC)
if(_oz(z,6,e,s,gg)){aJC.wxVkey=1
}
lIC.wxXCkey=1
aJC.wxXCkey=1
return r
}
e_[x[4]]={f:m4,j:[],i:[],ti:[],ic:[]}
d_[x[5]]={}
var m5=function(e,s,r,gg){
var z=gz$gwx_6()
var aXC=_mz(z,'view',['bindtouchend',0,'bindtouchmove',1,'bindtouchstart',1,'class',2],[],e,s,gg)
var eZC=_n('view')
_rz(z,eZC,'class',4,e,s,gg)
var o2C=_n('view')
_rz(z,o2C,'class',5,e,s,gg)
var x3C=_v()
_(o2C,x3C)
if(_oz(z,6,e,s,gg)){x3C.wxVkey=1
}
var o4C=_v()
_(o2C,o4C)
if(_oz(z,7,e,s,gg)){o4C.wxVkey=1
}
x3C.wxXCkey=1
o4C.wxXCkey=1
_(eZC,o2C)
var b1C=_v()
_(eZC,b1C)
if(_oz(z,8,e,s,gg)){b1C.wxVkey=1
}
b1C.wxXCkey=1
_(aXC,eZC)
var f5C=_n('view')
_rz(z,f5C,'class',9,e,s,gg)
var c6C=_n('view')
_rz(z,c6C,'class',10,e,s,gg)
var h7C=_v()
_(c6C,h7C)
if(_oz(z,11,e,s,gg)){h7C.wxVkey=1
}
var o8C=_v()
_(c6C,o8C)
if(_oz(z,12,e,s,gg)){o8C.wxVkey=1
}
var c9C=_v()
_(c6C,c9C)
if(_oz(z,13,e,s,gg)){c9C.wxVkey=1
}
h7C.wxXCkey=1
o8C.wxXCkey=1
c9C.wxXCkey=1
_(f5C,c6C)
var o0C=_v()
_(f5C,o0C)
var lAD=function(tCD,aBD,eDD,gg){
var oFD=_v()
_(eDD,oFD)
var xGD=function(fID,oHD,cJD,gg){
var oLD=_mz(z,'view',['bindtap',19,'class',1,'data-wpypointdetailtoggle-a',2],[],fID,oHD,gg)
var oND=_n('view')
_rz(z,oND,'class',22,fID,oHD,gg)
var lOD=_v()
_(oND,lOD)
if(_oz(z,23,fID,oHD,gg)){lOD.wxVkey=1
}
var aPD=_v()
_(oND,aPD)
if(_oz(z,24,fID,oHD,gg)){aPD.wxVkey=1
}
lOD.wxXCkey=1
aPD.wxXCkey=1
_(oLD,oND)
var cMD=_v()
_(oLD,cMD)
if(_oz(z,25,fID,oHD,gg)){cMD.wxVkey=1
}
cMD.wxXCkey=1
_(cJD,oLD)
return cJD
}
oFD.wxXCkey=2
_2z(z,17,xGD,tCD,aBD,gg,oFD,'point','pointIndex','point')
return eDD
}
o0C.wxXCkey=2
_2z(z,14,lAD,e,s,gg,o0C,'item','index','')
_(aXC,f5C)
var tYC=_v()
_(aXC,tYC)
if(_oz(z,26,e,s,gg)){tYC.wxVkey=1
var tQD=_v()
_(tYC,tQD)
if(_oz(z,27,e,s,gg)){tQD.wxVkey=1
}
tQD.wxXCkey=1
}
tYC.wxXCkey=1
_(r,aXC)
var cUC=_v()
_(r,cUC)
if(_oz(z,28,e,s,gg)){cUC.wxVkey=1
}
var oVC=_v()
_(r,oVC)
if(_oz(z,29,e,s,gg)){oVC.wxVkey=1
}
var lWC=_v()
_(r,lWC)
if(_oz(z,30,e,s,gg)){lWC.wxVkey=1
var eRD=_n('view')
_rz(z,eRD,'class',31,e,s,gg)
var bSD=_v()
_(eRD,bSD)
if(_oz(z,32,e,s,gg)){bSD.wxVkey=1
}
var oTD=_v()
_(eRD,oTD)
if(_oz(z,33,e,s,gg)){oTD.wxVkey=1
var xUD=_v()
_(oTD,xUD)
if(_oz(z,34,e,s,gg)){xUD.wxVkey=1
}
xUD.wxXCkey=1
}
bSD.wxXCkey=1
oTD.wxXCkey=1
_(lWC,eRD)
}
cUC.wxXCkey=1
oVC.wxXCkey=1
lWC.wxXCkey=1
return r
}
e_[x[5]]={f:m5,j:[],i:[],ti:[],ic:[]}
d_[x[6]]={}
var m6=function(e,s,r,gg){
var z=gz$gwx_7()
var fWD=_n('view')
_rz(z,fWD,'class',0,e,s,gg)
var cXD=_v()
_(fWD,cXD)
if(_oz(z,2,e,s,gg)){cXD.wxVkey=1
}
else{cXD.wxVkey=2
var oZD=_v()
_(cXD,oZD)
var c1D=function(l3D,o2D,a4D,gg){
var e6D=_mz(z,'view',['bindtap',8,'class',1,'data-wpyitemdaytap-a',2],[],l3D,o2D,gg)
var b7D=_v()
_(e6D,b7D)
if(_oz(z,11,l3D,o2D,gg)){b7D.wxVkey=1
}
b7D.wxXCkey=1
_(a4D,e6D)
return a4D
}
oZD.wxXCkey=2
_2z(z,6,c1D,e,s,gg,oZD,'ditem','dindex','{{dindex}}')
var hYD=_v()
_(cXD,hYD)
if(_oz(z,12,e,s,gg)){hYD.wxVkey=1
}
hYD.wxXCkey=1
}
cXD.wxXCkey=1
_(r,fWD)
return r
}
e_[x[6]]={f:m6,j:[],i:[],ti:[],ic:[]}
d_[x[7]]={}
var m7=function(e,s,r,gg){
var z=gz$gwx_8()
var fAE=_mz(z,'view',['bindtouchend',0,'bindtouchmove',1,'bindtouchstart',1,'class',2],[],e,s,gg)
var cBE=_n('view')
_rz(z,cBE,'class',4,e,s,gg)
var hCE=_v()
_(cBE,hCE)
if(_oz(z,5,e,s,gg)){hCE.wxVkey=1
}
var oDE=_v()
_(cBE,oDE)
if(_oz(z,6,e,s,gg)){oDE.wxVkey=1
}
var cEE=_v()
_(cBE,cEE)
if(_oz(z,7,e,s,gg)){cEE.wxVkey=1
}
hCE.wxXCkey=1
oDE.wxXCkey=1
cEE.wxXCkey=1
_(fAE,cBE)
var oFE=_v()
_(fAE,oFE)
var lGE=function(tIE,aHE,eJE,gg){
var oLE=_v()
_(eJE,oLE)
var xME=function(fOE,oNE,cPE,gg){
var oRE=_mz(z,'view',['bindtap',14,'class',1,'data-wpypointdetailtoggle-a',2],[],fOE,oNE,gg)
var oTE=_n('view')
_rz(z,oTE,'class',17,fOE,oNE,gg)
var lUE=_v()
_(oTE,lUE)
if(_oz(z,18,fOE,oNE,gg)){lUE.wxVkey=1
}
var aVE=_v()
_(oTE,aVE)
if(_oz(z,19,fOE,oNE,gg)){aVE.wxVkey=1
}
lUE.wxXCkey=1
aVE.wxXCkey=1
_(oRE,oTE)
var cSE=_v()
_(oRE,cSE)
if(_oz(z,20,fOE,oNE,gg)){cSE.wxVkey=1
}
cSE.wxXCkey=1
_(cPE,oRE)
return cPE
}
oLE.wxXCkey=2
_2z(z,12,xME,tIE,aHE,gg,oLE,'point','pointIndex','point')
return eJE
}
oFE.wxXCkey=2
_2z(z,8,lGE,e,s,gg,oFE,'item','index','item')
_(r,fAE)
var x9D=_v()
_(r,x9D)
if(_oz(z,21,e,s,gg)){x9D.wxVkey=1
}
var o0D=_v()
_(r,o0D)
if(_oz(z,22,e,s,gg)){o0D.wxVkey=1
}
x9D.wxXCkey=1
o0D.wxXCkey=1
return r
}
e_[x[7]]={f:m7,j:[],i:[],ti:[],ic:[]}
d_[x[8]]={}
var m8=function(e,s,r,gg){
var z=gz$gwx_9()
var eXE=_n('view')
_rz(z,eXE,'class',0,e,s,gg)
var bYE=_v()
_(eXE,bYE)
if(_oz(z,1,e,s,gg)){bYE.wxVkey=1
}
var oZE=_v()
_(eXE,oZE)
if(_oz(z,2,e,s,gg)){oZE.wxVkey=1
}
var x1E=_v()
_(eXE,x1E)
if(_oz(z,3,e,s,gg)){x1E.wxVkey=1
}
bYE.wxXCkey=1
oZE.wxXCkey=1
x1E.wxXCkey=1
_(r,eXE)
return r
}
e_[x[8]]={f:m8,j:[],i:[],ti:[],ic:[]}
d_[x[9]]={}
var m9=function(e,s,r,gg){
var z=gz$gwx_10()
var f3E=_v()
_(r,f3E)
if(_oz(z,0,e,s,gg)){f3E.wxVkey=1
}
var c7E=_n('view')
_rz(z,c7E,'class',1,e,s,gg)
var o8E=_v()
_(c7E,o8E)
if(_oz(z,2,e,s,gg)){o8E.wxVkey=1
}
var l9E=_v()
_(c7E,l9E)
if(_oz(z,3,e,s,gg)){l9E.wxVkey=1
}
var a0E=_v()
_(c7E,a0E)
if(_oz(z,4,e,s,gg)){a0E.wxVkey=1
}
var tAF=_v()
_(c7E,tAF)
if(_oz(z,5,e,s,gg)){tAF.wxVkey=1
}
var eBF=_v()
_(c7E,eBF)
if(_oz(z,6,e,s,gg)){eBF.wxVkey=1
}
var hIF=_v()
_(c7E,hIF)
var oJF=function(oLF,cKF,lMF,gg){
var tOF=_mz(z,'view',['bindtap',9,'class',1,'data-status',2,'data-wpytapoption-a',3],[],oLF,cKF,gg)
var ePF=_v()
_(tOF,ePF)
if(_oz(z,13,oLF,cKF,gg)){ePF.wxVkey=1
}
var bQF=_v()
_(tOF,bQF)
if(_oz(z,14,oLF,cKF,gg)){bQF.wxVkey=1
}
ePF.wxXCkey=1
bQF.wxXCkey=1
_(lMF,tOF)
return lMF
}
hIF.wxXCkey=2
_2z(z,7,oJF,e,s,gg,hIF,'item','index','option')
var bCF=_v()
_(c7E,bCF)
if(_oz(z,15,e,s,gg)){bCF.wxVkey=1
var oRF=_n('view')
_rz(z,oRF,'class',16,e,s,gg)
var oTF=_n('view')
_rz(z,oTF,'class',17,e,s,gg)
var fUF=_v()
_(oTF,fUF)
if(_oz(z,18,e,s,gg)){fUF.wxVkey=1
var hWF=_n('view')
_rz(z,hWF,'class',19,e,s,gg)
var oXF=_v()
_(hWF,oXF)
if(_oz(z,20,e,s,gg)){oXF.wxVkey=1
}
var cYF=_v()
_(hWF,cYF)
if(_oz(z,21,e,s,gg)){cYF.wxVkey=1
}
oXF.wxXCkey=1
cYF.wxXCkey=1
_(fUF,hWF)
}
var cVF=_v()
_(oTF,cVF)
if(_oz(z,22,e,s,gg)){cVF.wxVkey=1
var oZF=_n('view')
_rz(z,oZF,'class',23,e,s,gg)
var l1F=_v()
_(oZF,l1F)
if(_oz(z,24,e,s,gg)){l1F.wxVkey=1
}
var a2F=_v()
_(oZF,a2F)
if(_oz(z,25,e,s,gg)){a2F.wxVkey=1
}
l1F.wxXCkey=1
a2F.wxXCkey=1
_(cVF,oZF)
}
fUF.wxXCkey=1
cVF.wxXCkey=1
_(oRF,oTF)
var xSF=_v()
_(oRF,xSF)
if(_oz(z,26,e,s,gg)){xSF.wxVkey=1
var t3F=_mz(z,'view',['bindlongpress',27,'class',1],[],e,s,gg)
var e4F=_v()
_(t3F,e4F)
if(_oz(z,29,e,s,gg)){e4F.wxVkey=1
}
e4F.wxXCkey=1
_(xSF,t3F)
}
xSF.wxXCkey=1
_(bCF,oRF)
}
var oDF=_v()
_(c7E,oDF)
if(_oz(z,30,e,s,gg)){oDF.wxVkey=1
var b5F=_n('view')
_rz(z,b5F,'class',31,e,s,gg)
var o6F=_v()
_(b5F,o6F)
if(_oz(z,32,e,s,gg)){o6F.wxVkey=1
}
var x7F=_v()
_(b5F,x7F)
if(_oz(z,33,e,s,gg)){x7F.wxVkey=1
}
var o8F=_v()
_(b5F,o8F)
if(_oz(z,34,e,s,gg)){o8F.wxVkey=1
}
var f9F=_v()
_(b5F,f9F)
if(_oz(z,35,e,s,gg)){f9F.wxVkey=1
}
o6F.wxXCkey=1
x7F.wxXCkey=1
o8F.wxXCkey=1
f9F.wxXCkey=1
_(oDF,b5F)
}
var xEF=_v()
_(c7E,xEF)
if(_oz(z,36,e,s,gg)){xEF.wxVkey=1
var c0F=_v()
_(xEF,c0F)
if(_oz(z,37,e,s,gg)){c0F.wxVkey=1
}
c0F.wxXCkey=1
}
var hAG=_n('view')
_rz(z,hAG,'class',38,e,s,gg)
var oBG=_v()
_(hAG,oBG)
if(_oz(z,39,e,s,gg)){oBG.wxVkey=1
}
var cCG=_v()
_(hAG,cCG)
if(_oz(z,40,e,s,gg)){cCG.wxVkey=1
}
var oDG=_v()
_(hAG,oDG)
if(_oz(z,41,e,s,gg)){oDG.wxVkey=1
var eHG=_v()
_(oDG,eHG)
if(_oz(z,42,e,s,gg)){eHG.wxVkey=1
}
eHG.wxXCkey=1
}
var lEG=_v()
_(hAG,lEG)
if(_oz(z,43,e,s,gg)){lEG.wxVkey=1
var bIG=_v()
_(lEG,bIG)
if(_oz(z,44,e,s,gg)){bIG.wxVkey=1
}
bIG.wxXCkey=1
}
var aFG=_v()
_(hAG,aFG)
if(_oz(z,45,e,s,gg)){aFG.wxVkey=1
}
var tGG=_v()
_(hAG,tGG)
if(_oz(z,46,e,s,gg)){tGG.wxVkey=1
}
oBG.wxXCkey=1
cCG.wxXCkey=1
oDG.wxXCkey=1
lEG.wxXCkey=1
aFG.wxXCkey=1
tGG.wxXCkey=1
_(c7E,hAG)
var oFF=_v()
_(c7E,oFF)
if(_oz(z,47,e,s,gg)){oFF.wxVkey=1
}
var fGF=_v()
_(c7E,fGF)
if(_oz(z,48,e,s,gg)){fGF.wxVkey=1
}
var cHF=_v()
_(c7E,cHF)
if(_oz(z,49,e,s,gg)){cHF.wxVkey=1
}
o8E.wxXCkey=1
l9E.wxXCkey=1
a0E.wxXCkey=1
tAF.wxXCkey=1
eBF.wxXCkey=1
bCF.wxXCkey=1
oDF.wxXCkey=1
xEF.wxXCkey=1
oFF.wxXCkey=1
fGF.wxXCkey=1
cHF.wxXCkey=1
_(r,c7E)
var c4E=_v()
_(r,c4E)
if(_oz(z,50,e,s,gg)){c4E.wxVkey=1
}
var h5E=_v()
_(r,h5E)
if(_oz(z,51,e,s,gg)){h5E.wxVkey=1
}
var o6E=_v()
_(r,o6E)
if(_oz(z,52,e,s,gg)){o6E.wxVkey=1
var oJG=_n('view')
_rz(z,oJG,'class',53,e,s,gg)
var xKG=_v()
_(oJG,xKG)
if(_oz(z,54,e,s,gg)){xKG.wxVkey=1
}
var oLG=_v()
_(oJG,oLG)
if(_oz(z,55,e,s,gg)){oLG.wxVkey=1
var fMG=_v()
_(oLG,fMG)
if(_oz(z,56,e,s,gg)){fMG.wxVkey=1
}
fMG.wxXCkey=1
}
xKG.wxXCkey=1
oLG.wxXCkey=1
_(o6E,oJG)
}
f3E.wxXCkey=1
c4E.wxXCkey=1
h5E.wxXCkey=1
o6E.wxXCkey=1
return r
}
e_[x[9]]={f:m9,j:[],i:[],ti:[],ic:[]}
d_[x[10]]={}
var m10=function(e,s,r,gg){
var z=gz$gwx_11()
var hOG=_n('view')
_rz(z,hOG,'class',0,e,s,gg)
var oPG=_v()
_(hOG,oPG)
if(_oz(z,1,e,s,gg)){oPG.wxVkey=1
}
else{oPG.wxVkey=2
var cQG=_v()
_(oPG,cQG)
var oRG=function(aTG,lSG,tUG,gg){
var bWG=_v()
_(tUG,bWG)
var oXG=function(oZG,xYG,f1G,gg){
var h3G=_mz(z,'view',['bindtap',5,'class',1,'data-wpytogglelesson-a',2,'data-wpytogglelesson-b',3,'id',4],[],oZG,xYG,gg)
var o4G=_v()
_(h3G,o4G)
if(_oz(z,11,oZG,xYG,gg)){o4G.wxVkey=1
var c5G=_v()
_(o4G,c5G)
var o6G=function(a8G,l7G,t9G,gg){
var bAH=_n('view')
_rz(z,bAH,'class',13,a8G,l7G,gg)
var oBH=_v()
_(bAH,oBH)
if(_oz(z,14,a8G,l7G,gg)){oBH.wxVkey=1
}
var xCH=_v()
_(bAH,xCH)
if(_oz(z,15,a8G,l7G,gg)){xCH.wxVkey=1
}
oBH.wxXCkey=1
xCH.wxXCkey=1
_(t9G,bAH)
return t9G
}
c5G.wxXCkey=2
_2z(z,12,o6G,oZG,xYG,gg,c5G,'item','index','')
}
o4G.wxXCkey=1
_(f1G,h3G)
return f1G
}
bWG.wxXCkey=2
_2z(z,4,oXG,aTG,lSG,gg,bWG,'item','index','')
return tUG
}
cQG.wxXCkey=2
_2z(z,3,oRG,e,s,gg,cQG,'item','chapterIndex','')
}
oPG.wxXCkey=1
_(r,hOG)
return r
}
e_[x[10]]={f:m10,j:[],i:[],ti:[],ic:[]}
d_[x[11]]={}
var m11=function(e,s,r,gg){
var z=gz$gwx_12()
var fEH=_n('view')
_rz(z,fEH,'class',0,e,s,gg)
var cIH=_v()
_(fEH,cIH)
var oJH=function(aLH,lKH,tMH,gg){
var bOH=_v()
_(tMH,bOH)
if(_oz(z,2,aLH,lKH,gg)){bOH.wxVkey=1
}
bOH.wxXCkey=1
return tMH
}
cIH.wxXCkey=2
_2z(z,1,oJH,e,s,gg,cIH,'item','index','')
var cFH=_v()
_(fEH,cFH)
if(_oz(z,3,e,s,gg)){cFH.wxVkey=1
}
var hGH=_v()
_(fEH,hGH)
if(_oz(z,4,e,s,gg)){hGH.wxVkey=1
}
var oHH=_v()
_(fEH,oHH)
if(_oz(z,5,e,s,gg)){oHH.wxVkey=1
}
cFH.wxXCkey=1
hGH.wxXCkey=1
oHH.wxXCkey=1
_(r,fEH)
return r
}
e_[x[11]]={f:m11,j:[],i:[],ti:[],ic:[]}
d_[x[12]]={}
var m12=function(e,s,r,gg){
var z=gz$gwx_13()
var xQH=_v()
_(r,xQH)
if(_oz(z,0,e,s,gg)){xQH.wxVkey=1
}
xQH.wxXCkey=1
return r
}
e_[x[12]]={f:m12,j:[],i:[],ti:[],ic:[]}
d_[x[13]]={}
var m13=function(e,s,r,gg){
var z=gz$gwx_14()
return r
}
e_[x[13]]={f:m13,j:[],i:[],ti:[],ic:[]}
d_[x[14]]={}
var m14=function(e,s,r,gg){
var z=gz$gwx_15()
var oVH=_n('view')
_rz(z,oVH,'class',0,e,s,gg)
var e2H=_v()
_(oVH,e2H)
var b3H=function(x5H,o4H,o6H,gg){
var c8H=_mz(z,'view',['bindtap',3,'class',1,'data-status',2,'data-wpytapoption-a',3],[],x5H,o4H,gg)
var h9H=_v()
_(c8H,h9H)
if(_oz(z,7,x5H,o4H,gg)){h9H.wxVkey=1
}
var o0H=_v()
_(c8H,o0H)
if(_oz(z,8,x5H,o4H,gg)){o0H.wxVkey=1
}
h9H.wxXCkey=1
o0H.wxXCkey=1
_(o6H,c8H)
return o6H
}
e2H.wxXCkey=2
_2z(z,1,b3H,e,s,gg,e2H,'item','index','option')
var cWH=_v()
_(oVH,cWH)
if(_oz(z,9,e,s,gg)){cWH.wxVkey=1
var cAI=_n('view')
_rz(z,cAI,'class',10,e,s,gg)
var lCI=_n('view')
_rz(z,lCI,'class',11,e,s,gg)
var aDI=_v()
_(lCI,aDI)
if(_oz(z,12,e,s,gg)){aDI.wxVkey=1
var eFI=_n('view')
_rz(z,eFI,'class',13,e,s,gg)
var bGI=_v()
_(eFI,bGI)
if(_oz(z,14,e,s,gg)){bGI.wxVkey=1
}
var oHI=_v()
_(eFI,oHI)
if(_oz(z,15,e,s,gg)){oHI.wxVkey=1
}
bGI.wxXCkey=1
oHI.wxXCkey=1
_(aDI,eFI)
}
var tEI=_v()
_(lCI,tEI)
if(_oz(z,16,e,s,gg)){tEI.wxVkey=1
var xII=_n('view')
_rz(z,xII,'class',17,e,s,gg)
var oJI=_v()
_(xII,oJI)
if(_oz(z,18,e,s,gg)){oJI.wxVkey=1
}
var fKI=_v()
_(xII,fKI)
if(_oz(z,19,e,s,gg)){fKI.wxVkey=1
}
oJI.wxXCkey=1
fKI.wxXCkey=1
_(tEI,xII)
}
aDI.wxXCkey=1
tEI.wxXCkey=1
_(cAI,lCI)
var oBI=_v()
_(cAI,oBI)
if(_oz(z,20,e,s,gg)){oBI.wxVkey=1
var cLI=_mz(z,'view',['bindlongpress',21,'class',1],[],e,s,gg)
var hMI=_v()
_(cLI,hMI)
if(_oz(z,23,e,s,gg)){hMI.wxVkey=1
}
hMI.wxXCkey=1
_(oBI,cLI)
}
oBI.wxXCkey=1
_(cWH,cAI)
}
var oXH=_v()
_(oVH,oXH)
if(_oz(z,24,e,s,gg)){oXH.wxVkey=1
var oNI=_v()
_(oXH,oNI)
if(_oz(z,25,e,s,gg)){oNI.wxVkey=1
}
oNI.wxXCkey=1
}
var lYH=_v()
_(oVH,lYH)
if(_oz(z,26,e,s,gg)){lYH.wxVkey=1
}
var aZH=_v()
_(oVH,aZH)
if(_oz(z,27,e,s,gg)){aZH.wxVkey=1
}
var t1H=_v()
_(oVH,t1H)
if(_oz(z,28,e,s,gg)){t1H.wxVkey=1
}
cWH.wxXCkey=1
oXH.wxXCkey=1
lYH.wxXCkey=1
aZH.wxXCkey=1
t1H.wxXCkey=1
_(r,oVH)
var cTH=_v()
_(r,cTH)
if(_oz(z,29,e,s,gg)){cTH.wxVkey=1
}
var hUH=_v()
_(r,hUH)
if(_oz(z,30,e,s,gg)){hUH.wxVkey=1
}
cTH.wxXCkey=1
hUH.wxXCkey=1
return r
}
e_[x[14]]={f:m14,j:[],i:[],ti:[],ic:[]}
if(path&&e_[path]){
return function(env,dd,global){$gwxc=0;var root={"tag":"wx-page"};root.children=[]
var main=e_[path].f
if (typeof global==="undefined")global={};global.f=$gdc(f_[path],"",1);
try{
main(env,{},root,global);
_tsd(root)
}catch(err){
console.log(err)
}
return root;
}
}
}
	__wxAppCode__['pages/activate.json'] = {"usingComponents":{}};
		if (__vd_version_info__.delayedGwx) __wxAppCode__['pages/activate.wxml'] = [$gwx, './pages/activate.wxml'];else __wxAppCode__['pages/activate.wxml'] = $gwx( './pages/activate.wxml' );
		__wxAppCode__['pages/index.json'] = {"navigationBarTitleText":"","navigationBarTextStyle":"black","navigationBarBackgroundColor":"#6787FF","usingComponents":{}};
		if (__vd_version_info__.delayedGwx) __wxAppCode__['pages/index.wxml'] = [$gwx, './pages/index.wxml'];else __wxAppCode__['pages/index.wxml'] = $gwx( './pages/index.wxml' );
		__wxAppCode__['pages/learnIndex.json'] = {"navigationBarTitleText":"考点预览","navigationBarTextStyle":"white","navigationBarBackgroundColor":"#7B99FF","usingComponents":{}};
		if (__vd_version_info__.delayedGwx) __wxAppCode__['pages/learnIndex.wxml'] = [$gwx, './pages/learnIndex.wxml'];else __wxAppCode__['pages/learnIndex.wxml'] = $gwx( './pages/learnIndex.wxml' );
		__wxAppCode__['pages/points.json'] = {"navigationBarTitleText":"回顾本题考察的考点","navigationBarBackgroundColor":"#F9FAFC","usingComponents":{}};
		if (__vd_version_info__.delayedGwx) __wxAppCode__['pages/points.wxml'] = [$gwx, './pages/points.wxml'];else __wxAppCode__['pages/points.wxml'] = $gwx( './pages/points.wxml' );
		__wxAppCode__['pages/ranking.json'] = {"navigationBarTitleText":"看看排名情况","usingComponents":{}};
		if (__vd_version_info__.delayedGwx) __wxAppCode__['pages/ranking.wxml'] = [$gwx, './pages/ranking.wxml'];else __wxAppCode__['pages/ranking.wxml'] = $gwx( './pages/ranking.wxml' );
		__wxAppCode__['pages/report.json'] = {"navigationBarTitleText":"刷题报告","usingComponents":{}};
		if (__vd_version_info__.delayedGwx) __wxAppCode__['pages/report.wxml'] = [$gwx, './pages/report.wxml'];else __wxAppCode__['pages/report.wxml'] = $gwx( './pages/report.wxml' );
		__wxAppCode__['pages/reviewFilter.json'] = {"navigationBarTitleText":"选择复习题目","navigationBarBackgroundColor":"#fff","usingComponents":{}};
		if (__vd_version_info__.delayedGwx) __wxAppCode__['pages/reviewFilter.wxml'] = [$gwx, './pages/reviewFilter.wxml'];else __wxAppCode__['pages/reviewFilter.wxml'] = $gwx( './pages/reviewFilter.wxml' );
		__wxAppCode__['pages/reviewIndex.json'] = {"navigationBarTitleText":"考点复习","navigationBarTextStyle":"black","navigationBarBackgroundColor":"#fff","usingComponents":{}};
		if (__vd_version_info__.delayedGwx) __wxAppCode__['pages/reviewIndex.wxml'] = [$gwx, './pages/reviewIndex.wxml'];else __wxAppCode__['pages/reviewIndex.wxml'] = $gwx( './pages/reviewIndex.wxml' );
		__wxAppCode__['pages/share.json'] = {"navigationBarTitleText":"活动详情","usingComponents":{}};
		if (__vd_version_info__.delayedGwx) __wxAppCode__['pages/share.wxml'] = [$gwx, './pages/share.wxml'];else __wxAppCode__['pages/share.wxml'] = $gwx( './pages/share.wxml' );
		__wxAppCode__['pages/study.json'] = {"navigationBarTitleText":"正在答题","navigationBarTextStyle":"black","navigationBarBackgroundColor":"#F9FAFC","usingComponents":{}};
		if (__vd_version_info__.delayedGwx) __wxAppCode__['pages/study.wxml'] = [$gwx, './pages/study.wxml'];else __wxAppCode__['pages/study.wxml'] = $gwx( './pages/study.wxml' );
		__wxAppCode__['pages/studyData.json'] = {"navigationBarTitleText":"","navigationBarBackgroundColor":"#7B99FF","navigationBarTextStyle":"white","usingComponents":{}};
		if (__vd_version_info__.delayedGwx) __wxAppCode__['pages/studyData.wxml'] = [$gwx, './pages/studyData.wxml'];else __wxAppCode__['pages/studyData.wxml'] = $gwx( './pages/studyData.wxml' );
		__wxAppCode__['pages/upValue.json'] = {"navigationBarTitleText":"我的UP值","navigationBarBackgroundColor":"#7B99FF","navigationBarTextStyle":"white","usingComponents":{}};
		if (__vd_version_info__.delayedGwx) __wxAppCode__['pages/upValue.wxml'] = [$gwx, './pages/upValue.wxml'];else __wxAppCode__['pages/upValue.wxml'] = $gwx( './pages/upValue.wxml' );
		__wxAppCode__['pages/upValueList.json'] = {"navigationBarTitleText":"收支明细","usingComponents":{}};
		if (__vd_version_info__.delayedGwx) __wxAppCode__['pages/upValueList.wxml'] = [$gwx, './pages/upValueList.wxml'];else __wxAppCode__['pages/upValueList.wxml'] = $gwx( './pages/upValueList.wxml' );
		__wxAppCode__['pages/web.json'] = {"navigationBarTitleText":"","usingComponents":{}};
		if (__vd_version_info__.delayedGwx) __wxAppCode__['pages/web.wxml'] = [$gwx, './pages/web.wxml'];else __wxAppCode__['pages/web.wxml'] = $gwx( './pages/web.wxml' );
		__wxAppCode__['pages/wrongTopic.json'] = {"navigationBarTitleText":"正在复习错过的题","navigationBarTextStyle":"black","navigationBarBackgroundColor":"#F9FAFC","usingComponents":{}};
		if (__vd_version_info__.delayedGwx) __wxAppCode__['pages/wrongTopic.wxml'] = [$gwx, './pages/wrongTopic.wxml'];else __wxAppCode__['pages/wrongTopic.wxml'] = $gwx( './pages/wrongTopic.wxml' );
	
	define("common/api.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			
"use strict";function _interopRequireDefault(t){return t&&t.__esModule?t:{default:t}}function getOpenId(t){return _http2.default.get("/wx/authNew",t)}function login(t){return _http2.default.Login(t,!0)}function register(t){return _http2.default.register(t,!0)}function indexInfo(t){return _http2.default.get("/indexInfo",t)}function indexBanner(t){return _http2.default.get("/banner",t)}function learnInfo(t){return _http2.default.get("/getLearnInfoNew",t)}function getReviewDays(t){return _http2.default.get("/getReviewDaysNew",t)}function unlockCourse(t){return _http2.default.get("/unlockCourse",t)}function upValue(t){return _http2.default.get("/userShareTask",t)}function saveScore(t){return _http2.default.get("/saveScore",t)}function activityInfo(t){return _http2.default.get("/edge/acceding",t)}function activityHelp(t){return _http2.default.post("/edge/acceding",t)}function getDayInfo(t){return _http2.default.get("/getDayInfo",t)}function submitAnswers(t){return _http2.default.post("/submitAnswers",t)}function submitAnswersBehaviour(t){return _http2.default.post("/submitAnswersBehaviour",t)}function submitFormId(t){return _http2.default.post("/collect",t)}function pay(t){return _http2.default.get("/pay",t)}function getPointDetail(t){return _http2.default.get("/getPointDetail",t)}function submitShareStats(t){return _http2.default.post("/shareStats",t)}function updateAppUserStatus(t){return _http2.default.post("/updateAppUserStatus",t)}function getQRCodeForUpValue(t){return _http2.default.get("/getQRCodeForUpValue",t)}function getRankingDetail(t){return _http2.default.get("/userRankingDetail",t)}function subscribeMessage(t){return _http2.default.post("/subscribeMessage",t)}function getUserIndex(t){return _http2.default.get("/userTaskList",t)}function getMyUpValue(t){return _http2.default.get("/myUpValue",t)}function posterHelp(t){return _http2.default.get("/posterHelp",t)}function unlockVideo(t){return _http2.default.get("/unlockVideo",t)}function userLearnData(t){return _http2.default.get("/userLearnData",t)}function clickPublicCourse(t){return _http2.default.get("/clickPublicCourse",t)}function wrongSection(t){return _http2.default.get("/wrongSection",t)}function getUserInfo(t){return _http2.default.get("/user",t)}function setPhoneNumber(t){return _http2.default.post("/wx/phoneNumber",t)}function shareHelp(){return _http2.default.get("/shareHelp")}function postShareHelp(){return _http2.default.post("/shareHelp")}Object.defineProperty(exports,"__esModule",{value:!0});var _http=require("./http.js"),_http2=_interopRequireDefault(_http);exports.default={getOpenId:getOpenId,login:login,indexInfo:indexInfo,learnInfo:learnInfo,getReviewDays:getReviewDays,unlockCourse:unlockCourse,saveScore:saveScore,upValue:upValue,activityInfo:activityInfo,activityHelp:activityHelp,getDayInfo:getDayInfo,submitAnswers:submitAnswers,submitAnswersBehaviour:submitAnswersBehaviour,submitFormId:submitFormId,pay:pay,getPointDetail:getPointDetail,submitShareStats:submitShareStats,updateAppUserStatus:updateAppUserStatus,getQRCodeForUpValue:getQRCodeForUpValue,getRankingDetail:getRankingDetail,subscribeMessage:subscribeMessage,getUserIndex:getUserIndex,getMyUpValue:getMyUpValue,posterHelp:posterHelp,unlockVideo:unlockVideo,userLearnData:userLearnData,clickPublicCourse:clickPublicCourse,wrongSection:wrongSection,getUserInfo:getUserInfo,register:register,indexBanner:indexBanner,setPhoneNumber:setPhoneNumber,shareHelp:shareHelp,postShareHelp:postShareHelp}; 
 			}); 
		define("common/common.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			
"use strict";function _interopRequireDefault(e){return e&&e.__esModule?e:{default:e}}function business(e){try{var r=wx.getStorageSync(_constant2.default.KEY_UNIONID),t=wx.getStorageSync(_constant2.default.KEY_OPENID);_report2.default.init("zhengzhiyiqianti",_constant2.default.KEY_VERSION,r,t).send(e)}catch(e){console.log(e)}}function getErrorWarnMsg(e){if(!e)return null;var r=[{code:1001,msg:"downloadFile",warnMsg:"网络加载失败(1001)"},{code:1002,msg:"connect to",warnMsg:"网络加载失败(1002)"},{code:1003,msg:"timed out",warnMsg:"网络加载失败(1003)"},{code:1004,msg:"timeout",warnMsg:"网络加载失败(1004)"},{code:1005,msg:"服务器",warnMsg:"网络加载失败(1005)"},{code:1006,msg:"互联网",warnMsg:"网络加载失败(1006)"},{code:1007,msg:"saveFile",warnMsg:"网络加载失败(1007)"},{code:1008,msg:"request",warnMsg:"网络加载失败(1008)"},{code:1009,msg:"getImageInfo",warnMsg:"网络加载失败(1008)"}],t=r.find(function(r){return e.includes(r.msg)});return t?t.warnMsg:null}function showModal(e){var r=arguments.length>1&&void 0!==arguments[1]?arguments[1]:"提示",t=!(arguments.length>2&&void 0!==arguments[2])||arguments[2];return new Promise(function(o,n){wx.showModal({title:r,content:e,showCancel:t,success:function(e){o(e.confirm?1:0)}})})}function shareTxt(e){var r=arguments.length>1&&void 0!==arguments[1]?arguments[1]:"安利一个政治刷题小程序给你，290万考研人都用过！",t=arguments.length>2&&void 0!==arguments[2]?arguments[2]:"../images/img_share@2x.png";e||(e={}),e.from="share";try{if(!e.openId){var o=wx.getStorageSync(_constant2.default.KEY_OPENID)||"";o&&(e.openId=o)}}catch(e){}var n="/pages/index";return Object.keys(e).forEach(function(r,t){n+=(0===t?"?":"&")+r+"="+e[r]}),console.log(n),{title:r,imageUrl:t,path:n}}function collectFormID(e){var r=arguments.length>1&&void 0!==arguments[1]&&arguments[1];if(e&&allFormIds.push({formId:e}),console.log("收集 formId ---- ",allFormIds),Array.isArray(allFormIds)&&(allFormIds.length>=5||r)){if(flagFormId)return;flagFormId=!0;var t=allFormIds;allFormIds=[],t.length>0&&_api2.default.submitFormId({formIds:JSON.stringify(t)}).then(function(e){flagFormId=!1,console.log("submitFormId success")}).catch(function(e){flagFormId=!1,console.log(e,"submitFormId failed")})}}function getQueryParam(e,r){var t=new RegExp("(\\?|^|&)"+r+"=([^&]*)(&|$)","i"),o=e.match(t);return null!=o?unescape(o[2]):null}function obj2url(e){var r="?";return Object.keys(e).forEach(function(t){r+=t+"="+e[t]+"&"}),r.substring(0,r.length-1)}Object.defineProperty(exports,"__esModule",{value:!0});var _api=require("./api.js"),_api2=_interopRequireDefault(_api),_constant=require("./constant.js"),_constant2=_interopRequireDefault(_constant),_report=require("./report.js"),_report2=_interopRequireDefault(_report),allFormIds=[],flagFormId=!1;exports.default={getErrorWarnMsg:getErrorWarnMsg,showModal:showModal,shareTxt:shareTxt,collectFormID:collectFormID,getQueryParam:getQueryParam,obj2url:obj2url,business:business}; 
 			}); 
		define("common/constant.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			
"use strict";Object.defineProperty(exports,"__esModule",{value:!0});var KEY_TOKEN="token",KEY_IS_AUTH="is_auth",KEY_IS_NEW="is_new",KEY_OPENID="opendId",KEY_UNIONID="unionId",KEY_VERSION="1.3.1",KEY_INDEX_PAID_WELCOME="indexPaidWelcomed",KEY_REVIEW_LAST_STUDY="reviewLastStudy",KEY_REVIEW_FILTER_TIP_SHOWED="reviewFilterTipShowed";exports.default={KEY_TOKEN:KEY_TOKEN,KEY_IS_AUTH:KEY_IS_AUTH,KEY_IS_NEW:KEY_IS_NEW,KEY_OPENID:KEY_OPENID,KEY_UNIONID:KEY_UNIONID,KEY_VERSION:KEY_VERSION,KEY_INDEX_PAID_WELCOME:KEY_INDEX_PAID_WELCOME,KEY_REVIEW_LAST_STUDY:KEY_REVIEW_LAST_STUDY,KEY_REVIEW_FILTER_TIP_SHOWED:KEY_REVIEW_FILTER_TIP_SHOWED}; 
 			}); 
		define("common/decorator.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			
"use strict";function _toConsumableArray(r){if(Array.isArray(r)){for(var e=0,t=Array(r.length);e<r.length;e++)t[e]=r[e];return t}return Array.from(r)}function _asyncToGenerator(r){return function(){var e=r.apply(this,arguments);return new Promise(function(r,t){function n(a,o){try{var c=e[a](o),u=c.value}catch(r){return void t(r)}if(!c.done)return Promise.resolve(u).then(function(r){n("next",r)},function(r){n("throw",r)});r(u)}return n("next")})}}function trycatch(){var r=arguments.length>0&&void 0!==arguments[0]?arguments[0]:"handleError",e=!(arguments.length>1&&void 0!==arguments[1])||arguments[1];return function(t,n,a){var o=a.value;return a.value=_asyncToGenerator(regeneratorRuntime.mark(function a(){var c,u,i,s=arguments;return regeneratorRuntime.wrap(function(a){for(;;)switch(a.prev=a.next){case 0:for(a.prev=0,c=s.length,u=Array(c),i=0;i<c;i++)u[i]=s[i];if(!e){a.next=7;break}return a.next=5,o.call.apply(o,[this].concat(_toConsumableArray(u)));case 5:a.next=8;break;case 7:o.call.apply(o,[this].concat(_toConsumableArray(u)));case 8:a.next=19;break;case 10:if(a.prev=10,a.t0=a.catch(0),console.log("错误监控 捕获错误信息 err=",a.t0),!e){a.next=18;break}return a.next=16,t[r].call(this,a.t0,n);case 16:a.next=19;break;case 18:t[r].call(this,a.t0,n);case 19:case"end":return a.stop()}},a,this,[[0,10]])})),a}}Object.defineProperty(exports,"__esModule",{value:!0}),exports.trycatch=trycatch; 
 			}); 
		define("common/e-chart.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			
"use strict";function assign(t,e){if(null==t)throw new TypeError("Cannot convert undefined or null to object");for(var i=Object(t),a=1;a<arguments.length;a++){var n=arguments[a];if(null!=n)for(var o in n)Object.prototype.hasOwnProperty.call(n,o)&&(i[o]=n[o])}return i}function findRange(t,e,i){if(isNaN(t))throw new Error("[wxCharts] unvalid series data!");i=i||10,e=e||"upper";for(var a=1;i<1;)i*=10,a*=10;for(t="upper"===e?Math.ceil(t*a):Math.floor(t*a);t%i!=0;)"upper"===e?t++:t--;return t/a}function calValidDistance(t,e,i,a){var n=a.width-i.padding-e.xAxisPoints[0],o=e.eachSpacing*a.categories.length,r=t;return t>=0?r=0:Math.abs(t)>=o-n&&(r=n-o),r}function isInAngleRange(t,e,i){function a(t){for(;t<0;)t+=2*Math.PI;for(;t>2*Math.PI;)t-=2*Math.PI;return t}return t=a(t),e=a(e),i=a(i),e>i&&(i+=2*Math.PI,t<e&&(t+=2*Math.PI)),t>=e&&t<=i}function calRotateTranslate(t,e,i){var a=t,n=i-e,o=a+(i-n-a)/Math.sqrt(2);return o*=-1,{transX:o,transY:(i-n)*(Math.sqrt(2)-1)-(i-n-a)/Math.sqrt(2)}}function createCurveControlPoints(t,e){function i(t,e){return!(!t[e-1]||!t[e+1])&&(t[e].y>=Math.max(t[e-1].y,t[e+1].y)||t[e].y<=Math.min(t[e-1].y,t[e+1].y))}var a=null,n=null,o=null,r=null;if(e<1?(a=t[0].x+.2*(t[1].x-t[0].x),n=t[0].y+.2*(t[1].y-t[0].y)):(a=t[e].x+.2*(t[e+1].x-t[e-1].x),n=t[e].y+.2*(t[e+1].y-t[e-1].y)),e>t.length-3){var s=t.length-1;o=t[s].x-.2*(t[s].x-t[s-1].x),r=t[s].y-.2*(t[s].y-t[s-1].y)}else o=t[e+1].x-.2*(t[e+2].x-t[e].x),r=t[e+1].y-.2*(t[e+2].y-t[e].y);return i(t,e+1)&&(r=t[e+1].y),i(t,e)&&(n=t[e].y),{ctrA:{x:a,y:n},ctrB:{x:o,y:r}}}function convertCoordinateOrigin(t,e,i){return{x:i.x+t,y:i.y-e}}function avoidCollision(t,e){if(e)for(;util.isCollision(t,e);)t.start.x>0?t.start.y--:t.start.x<0?t.start.y++:t.start.y>0?t.start.y++:t.start.y--;return t}function fillSeriesColor(t,e){var i=0;return t.map(function(t){return t.color||(t.color=e.colors[i],i=(i+1)%e.colors.length),t})}function getDataRange(t,e){var i=0,a=e-t;return i=a>=1e4?1e3:a>=1e3?100:a>=100?10:a>=10?5:a>=1?1:a>=.1?.1:.01,{minRange:findRange(t,"lower",i),maxRange:findRange(e,"upper",i)}}function measureText(t){var e=arguments.length>1&&void 0!==arguments[1]?arguments[1]:14;t=String(t);var t=t.split(""),i=0;return t.forEach(function(t){/[a-zA-Z]/.test(t)?i+=7:/[0-9]/.test(t)?i+=5.5:/\./.test(t)?i+=2.7:/-/.test(t)?i+=3.25:/[\u4e00-\u9fa5]/.test(t)?i+=10:/\(|\)/.test(t)?i+=3.73:/\s/.test(t)?i+=2.5:/%/.test(t)?i+=8:i+=10}),i*e/10}function dataCombine(t){return t.reduce(function(t,e){return(t.data?t.data:t).concat(e.data)},[])}function getSeriesDataItem(t,e){var i=[];return t.forEach(function(t){if(null!==t.data[e]&&void 0!==t.data[e]){var a={};a.color=t.color,a.name=t.name,a.data=t.format?t.format(t.data[e]):t.data[e],i.push(a)}}),i}function getMaxTextListLength(t){var e=t.map(function(t){return measureText(t)});return Math.max.apply(null,e)}function getRadarCoordinateSeries(t){for(var e=2*Math.PI/t,i=[],a=0;a<t;a++)i.push(e*a);return i.map(function(t){return-1*t+Math.PI/2})}function getToolTipData(t,e,i,a){var n=arguments.length>4&&void 0!==arguments[4]?arguments[4]:{},o=t.map(function(t){return{text:n.format?n.format(t,a[i]):t.name+": "+t.data,color:t.color}}),r=[],s={x:0,y:0};return e.forEach(function(t){void 0!==t[i]&&null!==t[i]&&r.push(t[i])}),r.forEach(function(t){s.x=Math.round(t.x),s.y+=t.y}),s.y/=r.length,{textList:o,offset:s}}function findCurrentIndex(t,e,i,a){var n=arguments.length>4&&void 0!==arguments[4]?arguments[4]:0,o=-1;return isInExactChartArea(t,i,a)&&e.forEach(function(e,i){t.x+n>e&&(o=i)}),o}function isInExactChartArea(t,e,i){return t.x<e.width-i.padding&&t.x>i.padding+i.yAxisWidth+i.yAxisTitleWidth&&t.y>i.padding&&t.y<e.height-i.legendHeight-i.xAxisHeight-i.padding}function findRadarChartCurrentIndex(t,e,i){var a=2*Math.PI/i,n=-1;if(isInExactPieChartArea(t,e.center,e.radius)){var o=function(t){return t<0&&(t+=2*Math.PI),t>2*Math.PI&&(t-=2*Math.PI),t},r=Math.atan2(e.center.y-t.y,t.x-e.center.x);r*=-1,r<0&&(r+=2*Math.PI);e.angleList.map(function(t){return t=o(-1*t)}).forEach(function(t,e){var i=o(t-a/2),s=o(t+a/2);s<i&&(s+=2*Math.PI),(r>=i&&r<=s||r+2*Math.PI>=i&&r+2*Math.PI<=s)&&(n=e)})}return n}function findPieChartCurrentIndex(t,e){var i=-1;if(isInExactPieChartArea(t,e.center,e.radius)){var a=Math.atan2(e.center.y-t.y,t.x-e.center.x);a=-a;for(var n=0,o=e.series.length;n<o;n++){var r=e.series[n];if(isInAngleRange(a,r._start_,r._start_+2*r._proportion_*Math.PI)){i=n;break}}}return i}function isInExactPieChartArea(t,e,i){return Math.pow(t.x-e.x,2)+Math.pow(t.y-e.y,2)<=Math.pow(i,2)}function splitPoints(t){var e=[],i=[];return t.forEach(function(t,a){null!==t?i.push(t):(i.length&&e.push(i),i=[])}),i.length&&e.push(i),e}function calLegendData(t,e,i){if(!1===e.legend)return{legendList:[],legendHeight:0};var a=[],n=0,o=[];return t.forEach(function(t){var i=30+measureText(t.name||"undefined");n+i>e.width?(a.push(o),n=i,o=[t]):(n+=i,o.push(t))}),o.length&&a.push(o),{legendList:a,legendHeight:a.length*(i.fontSize+8)+5}}function calCategoriesData(t,e,i){var a={angle:0,xAxisHeight:i.xAxisHeight},n=getXAxisPoints(t,e,i),o=n.eachSpacing,r=t.map(function(t){return measureText(t)}),s=Math.max.apply(this,r);return s+2*i.xAxisTextPadding>o&&(a.angle=45*Math.PI/180,a.xAxisHeight=2*i.xAxisTextPadding+s*Math.sin(a.angle)),a}function getRadarDataPoints(t,e,i,a,n){var o=arguments.length>5&&void 0!==arguments[5]?arguments[5]:1,r=n.extra.radar||{};r.max=r.max||0;var s=Math.max(r.max,Math.max.apply(null,dataCombine(a))),l=[];return a.forEach(function(a){var n={};n.color=a.color,n.data=[],a.data.forEach(function(a,r){var l={};l.angle=t[r],l.proportion=a/s,l.position=convertCoordinateOrigin(i*l.proportion*o*Math.cos(l.angle),i*l.proportion*o*Math.sin(l.angle),e),n.data.push(l)}),l.push(n)}),l}function getPieDataPoints(t){var e=arguments.length>1&&void 0!==arguments[1]?arguments[1]:1,i=0,a=0;return t.forEach(function(t){t.data=null===t.data?0:t.data,i+=t.data}),t.forEach(function(t){t.data=null===t.data?0:t.data,t._proportion_=t.data/i*e}),t.forEach(function(t){t._start_=a,a+=2*t._proportion_*Math.PI}),t}function getPieTextMaxLength(t){t=getPieDataPoints(t);var e=0;return t.forEach(function(t){var i=t.format?t.format(+t._proportion_.toFixed(2)):util.toFixed(100*t._proportion_)+"%";e=Math.max(e,measureText(i))}),e}function fixColumeData(t,e,i,a,n,o){return t.map(function(t){return null===t?null:(t.width=(e-2*n.columePadding)/i,o.extra.column&&o.extra.column.width&&+o.extra.column.width>0?t.width=Math.min(t.width,+o.extra.column.width):t.width=Math.min(t.width,25),t.x+=(a+.5-i/2)*t.width,t)})}function getXAxisPoints(t,e,i){var a=i.yAxisWidth+i.yAxisTitleWidth,n=e.width-2*i.padding-a,o=e.enableScroll?Math.min(5,t.length):t.length,r=n/o,s=[],l=i.padding+a,h=e.width-i.padding;return t.forEach(function(t,e){s.push(l+e*r)}),!0===e.enableScroll?s.push(l+t.length*r):s.push(h),{xAxisPoints:s,startX:l,endX:h,eachSpacing:r}}function getDataPoints(t,e,i,a,n,o,r){var s=arguments.length>7&&void 0!==arguments[7]?arguments[7]:1,l=[],h=o.height-2*r.padding-r.xAxisHeight-r.legendHeight;return t.forEach(function(t,c){if(null===t)l.push(null);else{var d={};d.x=a[c]+Math.round(n/2);var x=h*(t-e)/(i-e);x*=s,d.y=o.height-r.xAxisHeight-r.legendHeight-Math.round(x)-r.padding,l.push(d)}}),l}function getYAxisTextList(t,e,i){var a=dataCombine(t);a=a.filter(function(t){return null!==t});var n=Math.min.apply(this,a),o=Math.max.apply(this,a);if("number"==typeof e.yAxis.min&&(n=Math.min(e.yAxis.min,n)),"number"==typeof e.yAxis.max&&(o=Math.max(e.yAxis.max,o)),n===o){var r=o||1;n-=r,o+=r}for(var s=getDataRange(n,o),l=s.minRange,h=s.maxRange,c=[],d=(h-l)/i.yAxisSplit,x=0;x<=i.yAxisSplit;x++)c.push(l+d*x);return c.reverse()}function calYAxisData(t,e,i){var a=getYAxisTextList(t,e,i),n=i.yAxisWidth,o=a.map(function(t){return t=util.toFixed(t,2),t=e.yAxis.format?e.yAxis.format(Number(t)):t,n=Math.max(n,measureText(t)+5),t});return!0===e.yAxis.disabled&&(n=0),{rangesFormat:o,ranges:a,yAxisWidth:n}}function drawPointShape(t,e,i,a){a.beginPath(),a.setStrokeStyle("#ffffff"),a.setLineWidth(1),a.setFillStyle(e),"diamond"===i?t.forEach(function(t,e){null!==t&&(a.moveTo(t.x,t.y-4.5),a.lineTo(t.x-4.5,t.y),a.lineTo(t.x,t.y+4.5),a.lineTo(t.x+4.5,t.y),a.lineTo(t.x,t.y-4.5))}):"circle"===i?t.forEach(function(t,e){null!==t&&(a.moveTo(t.x+3.5,t.y),a.arc(t.x,t.y,4,0,2*Math.PI,!1))}):"rect"===i?t.forEach(function(t,e){null!==t&&(a.moveTo(t.x-3.5,t.y-3.5),a.rect(t.x-3.5,t.y-3.5,7,7))}):"triangle"===i&&t.forEach(function(t,e){null!==t&&(a.moveTo(t.x,t.y-4.5),a.lineTo(t.x-4.5,t.y+4.5),a.lineTo(t.x+4.5,t.y+4.5),a.lineTo(t.x,t.y-4.5))}),a.closePath(),a.fill(),a.stroke()}function drawRingTitle(t,e,i){var a=t.title.fontSize||e.titleFontSize,n=t.subtitle.fontSize||e.subtitleFontSize,o=t.title.name||"",r=t.subtitle.name||"",s=t.title.color||e.titleColor,l=t.subtitle.color||e.subtitleColor,h=o?a:0,c=r?n:0;if(r){var d=measureText(r,n),x=(t.width-d)/2+(t.subtitle.offsetX||0),f=(t.height-e.legendHeight+n)/2;o&&(f-=(h+5)/2),i.beginPath(),i.setFontSize(n),i.setFillStyle(l),i.fillText(r,x,f),i.stroke(),i.closePath()}if(o){var g=measureText(o,a),u=(t.width-g)/2+(t.title.offsetX||0),p=(t.height-e.legendHeight+a)/2;r&&(p+=(c+5)/2),i.beginPath(),i.setFontSize(a),i.setFillStyle(s),i.fillText(o,u,p),i.stroke(),i.closePath()}}function drawPointText(t,e,i,a){var n=e.data;a.beginPath(),a.font="bold 14px Arial",a.setFillStyle("#333333"),t.forEach(function(t,i){if(null!==t){var o=e.format?e.format(n[i]):n[i];a.fillText(o,t.x-measureText(o)/2,t.y-7)}}),a.closePath(),a.stroke()}function drawRadarLabel(t,e,i,a,n,o){var r=a.extra.radar||{};e+=n.radarLabelTextMargin,o.beginPath(),o.setFontSize(n.fontSize),o.setFillStyle(r.labelColor||"#666666"),t.forEach(function(t,r){var s={x:e*Math.cos(t),y:e*Math.sin(t)},l=convertCoordinateOrigin(s.x,s.y,i),h=l.x,c=l.y;util.approximatelyEqual(s.x,0)?h-=measureText(a.categories[r]||"")/2:s.x<0&&(h-=measureText(a.categories[r]||"")),o.fillText(a.categories[r]||"",h,c+n.fontSize/2)}),o.stroke(),o.closePath()}function drawPieText(t,e,i,a,n,o){var r=n+i.pieChartLinePadding,s=[],l=null;t.map(function(t){return{arc:2*Math.PI-(t._start_+2*Math.PI*t._proportion_/2),text:t.format?t.format(+t._proportion_.toFixed(2)):util.toFixed(100*t._proportion_)+"%",color:t.color}}).forEach(function(t){var e=Math.cos(t.arc)*r,a=Math.sin(t.arc)*r,o=Math.cos(t.arc)*n,h=Math.sin(t.arc)*n,c=e>=0?e+i.pieChartTextPadding:e-i.pieChartTextPadding,d=a,x=measureText(t.text),f=d;l&&util.isSameXCoordinateArea(l.start,{x:c})&&(f=c>0?Math.min(d,l.start.y):e<0?Math.max(d,l.start.y):d>0?Math.max(d,l.start.y):Math.min(d,l.start.y)),c<0&&(c-=x);var g={lineStart:{x:o,y:h},lineEnd:{x:e,y:a},start:{x:c,y:f},width:x,height:i.fontSize,text:t.text,color:t.color};l=avoidCollision(g,l),s.push(l)}),s.forEach(function(t){var e=convertCoordinateOrigin(t.lineStart.x,t.lineStart.y,o),n=convertCoordinateOrigin(t.lineEnd.x,t.lineEnd.y,o),r=convertCoordinateOrigin(t.start.x,t.start.y,o);a.setLineWidth(1),a.setFontSize(i.fontSize),a.beginPath(),a.setStrokeStyle(t.color),a.setFillStyle(t.color),a.moveTo(e.x,e.y);var s=t.start.x<0?r.x+t.width:r.x,l=t.start.x<0?r.x-5:r.x+5;a.quadraticCurveTo(n.x,n.y,s,r.y),a.moveTo(e.x,e.y),a.stroke(),a.closePath(),a.beginPath(),a.moveTo(r.x+t.width,r.y),a.arc(s,r.y,2,0,2*Math.PI),a.closePath(),a.fill(),a.beginPath(),a.setFillStyle("#666666"),a.fillText(t.text,l,r.y+3),a.closePath(),a.stroke(),a.closePath()})}function drawToolTipSplitLine(t,e,i,a){var n=i.padding,o=e.height-i.padding-i.xAxisHeight-i.legendHeight;a.beginPath(),a.setStrokeStyle("#cccccc"),a.setLineWidth(1),a.moveTo(t,n),a.lineTo(t,o),a.stroke(),a.closePath()}function drawToolTip(t,e,i,a,n){var o=!1;e=assign({x:0,y:0},e),e.y-=8;var r=t.map(function(t){return measureText(t.text)}),s=9+4*a.toolTipPadding+Math.max.apply(null,r),l=2*a.toolTipPadding+t.length*a.toolTipLineHeight;e.x-Math.abs(i._scrollDistance_)+8+s>i.width&&(o=!0),n.beginPath(),n.setFillStyle(i.tooltip.option.background||a.toolTipBackground),n.setGlobalAlpha(a.toolTipOpacity),o?(n.moveTo(e.x,e.y+10),n.lineTo(e.x-8,e.y+10-5),n.lineTo(e.x-8,e.y+10+5),n.moveTo(e.x,e.y+10),n.fillRect(e.x-s-8,e.y,s,l)):(n.moveTo(e.x,e.y+10),n.lineTo(e.x+8,e.y+10-5),n.lineTo(e.x+8,e.y+10+5),n.moveTo(e.x,e.y+10),n.fillRect(e.x+8,e.y,s,l)),n.closePath(),n.fill(),n.setGlobalAlpha(1),t.forEach(function(t,i){n.beginPath(),n.setFillStyle(t.color);var r=e.x+8+2*a.toolTipPadding,l=e.y+(a.toolTipLineHeight-a.fontSize)/2+a.toolTipLineHeight*i+a.toolTipPadding;o&&(r=e.x-s-8+2*a.toolTipPadding),n.fillRect(r,l,4,a.fontSize),n.closePath()}),n.beginPath(),n.setFontSize(a.fontSize),n.setFillStyle("#ffffff"),t.forEach(function(t,i){var r=e.x+8+2*a.toolTipPadding+4+5;o&&(r=e.x-s-8+2*a.toolTipPadding+4+5);var l=e.y+(a.toolTipLineHeight-a.fontSize)/2+a.toolTipLineHeight*i+a.toolTipPadding;n.fillText(t.text,r,l+a.fontSize)}),n.stroke(),n.closePath()}function drawYAxisTitle(t,e,i,a){var n=i.xAxisHeight+(e.height-i.xAxisHeight-measureText(t))/2;a.save(),a.beginPath(),a.setFontSize(i.fontSize),a.setFillStyle(e.yAxis.titleFontColor||"#333333"),a.translate(0,e.height),a.rotate(-90*Math.PI/180),a.fillText(t,n,i.padding+.5*i.fontSize),a.stroke(),a.closePath(),a.restore()}function drawColumnDataPoints(t,e,i,a){var n=arguments.length>4&&void 0!==arguments[4]?arguments[4]:1,o=calYAxisData(t,e,i),r=o.ranges,s=getXAxisPoints(e.categories,e,i),l=s.xAxisPoints,h=s.eachSpacing,c=r.pop(),d=r.shift();return a.save(),e._scrollDistance_&&0!==e._scrollDistance_&&!0===e.enableScroll&&a.translate(e._scrollDistance_,0),t.forEach(function(o,r){var s=o.data,x=getDataPoints(s,c,d,l,h,e,i,n);x=fixColumeData(x,h,t.length,r,i,e),a.beginPath(),a.setFillStyle(o.color),x.forEach(function(t,n){if(null!==t){var o=t.x-t.width/2+1,r=e.height-t.y-i.padding-i.xAxisHeight-i.legendHeight;a.moveTo(o,t.y),a.rect(o,t.y,t.width-2,r)}}),a.closePath(),a.fill()}),t.forEach(function(o,r){var s=o.data,x=getDataPoints(s,c,d,l,h,e,i,n);x=fixColumeData(x,h,t.length,r,i,e),!1!==e.dataLabel&&1===n&&drawPointText(x,o,i,a)}),a.restore(),{xAxisPoints:l,eachSpacing:h}}function drawAreaDataPoints(t,e,i,a){var n=arguments.length>4&&void 0!==arguments[4]?arguments[4]:1,o=calYAxisData(t,e,i),r=o.ranges,s=getXAxisPoints(e.categories,e,i),l=s.xAxisPoints,h=s.eachSpacing,c=r.pop(),d=r.shift(),x=e.height-i.padding-i.xAxisHeight-i.legendHeight,f=[];return a.save(),e._scrollDistance_&&0!==e._scrollDistance_&&!0===e.enableScroll&&a.translate(e._scrollDistance_,0),e.tooltip&&e.tooltip.textList&&e.tooltip.textList.length&&1===n&&drawToolTipSplitLine(e.tooltip.offset.x,e,i,a),t.forEach(function(t,o){var r=t.data,s=getDataPoints(r,c,d,l,h,e,i,n);if(f.push(s),splitPoints(s).forEach(function(i){if(a.beginPath(),a.setStrokeStyle(t.color),a.setFillStyle(t.color),a.setGlobalAlpha(.6),a.setLineWidth(2),i.length>1){var n=i[0],o=i[i.length-1];a.moveTo(n.x,n.y),"curve"===e.extra.lineStyle?i.forEach(function(t,e){if(e>0){var n=createCurveControlPoints(i,e-1);a.bezierCurveTo(n.ctrA.x,n.ctrA.y,n.ctrB.x,n.ctrB.y,t.x,t.y)}}):i.forEach(function(t,e){e>0&&a.lineTo(t.x,t.y)}),a.lineTo(o.x,x),a.lineTo(n.x,x),a.lineTo(n.x,n.y)}else{var r=i[0];a.moveTo(r.x-h/2,r.y),a.lineTo(r.x+h/2,r.y),a.lineTo(r.x+h/2,x),a.lineTo(r.x-h/2,x),a.moveTo(r.x-h/2,r.y)}a.closePath(),a.fill(),a.setGlobalAlpha(1)}),!1!==e.dataPointShape){var g=i.dataPointShape[o%i.dataPointShape.length];drawPointShape(s,t.color,g,a)}}),!1!==e.dataLabel&&1===n&&t.forEach(function(t,o){drawPointText(getDataPoints(t.data,c,d,l,h,e,i,n),t,i,a)}),a.restore(),{xAxisPoints:l,calPoints:f,eachSpacing:h}}function drawLineDataPoints(t,e,i,a){var n=arguments.length>4&&void 0!==arguments[4]?arguments[4]:1,o=calYAxisData(t,e,i),r=o.ranges,s=getXAxisPoints(e.categories,e,i),l=s.xAxisPoints,h=s.eachSpacing,c=r.pop(),d=r.shift(),x=[];return a.save(),e._scrollDistance_&&0!==e._scrollDistance_&&!0===e.enableScroll&&a.translate(e._scrollDistance_,0),e.tooltip&&e.tooltip.textList&&e.tooltip.textList.length&&1===n&&drawToolTipSplitLine(e.tooltip.offset.x,e,i,a),t.forEach(function(t,o){var r=t.data,s=getDataPoints(r,c,d,l,h,e,i,n);if(x.push(s),splitPoints(s).forEach(function(i,n){a.beginPath(),a.setStrokeStyle(t.color),a.setLineWidth(2),1===i.length?(a.moveTo(i[0].x,i[0].y),a.arc(i[0].x,i[0].y,1,0,2*Math.PI)):(a.moveTo(i[0].x,i[0].y),"curve"===e.extra.lineStyle?i.forEach(function(t,e){if(e>0){var n=createCurveControlPoints(i,e-1);a.bezierCurveTo(n.ctrA.x,n.ctrA.y,n.ctrB.x,n.ctrB.y,t.x,t.y)}}):i.forEach(function(t,e){e>0&&a.lineTo(t.x,t.y)}),a.moveTo(i[0].x,i[0].y)),a.closePath(),a.stroke()}),!1!==e.dataPointShape){var f=i.dataPointShape[o%i.dataPointShape.length];drawPointShape(s,t.color,f,a)}}),!1!==e.dataLabel&&1===n&&t.forEach(function(t,o){drawPointText(getDataPoints(t.data,c,d,l,h,e,i,n),t,i,a)}),a.restore(),{xAxisPoints:l,calPoints:x,eachSpacing:h}}function drawToolTipBridge(t,e,i,a){i.save(),t._scrollDistance_&&0!==t._scrollDistance_&&!0===t.enableScroll&&i.translate(t._scrollDistance_,0),t.tooltip&&t.tooltip.textList&&t.tooltip.textList.length&&1===a&&drawToolTip(t.tooltip.textList,t.tooltip.offset,t,e,i),i.restore()}function drawXAxis(t,e,i,a){var n=getXAxisPoints(t,e,i),o=n.xAxisPoints,r=(n.startX,n.endX,n.eachSpacing),s=e.height-i.padding-i.xAxisHeight-i.legendHeight;i.xAxisLineHeight;a.save(),e._scrollDistance_&&0!==e._scrollDistance_&&a.translate(e._scrollDistance_,0);var l=e.width-2*i.padding-i.yAxisWidth-i.yAxisTitleWidth,h=Math.min(t.length,Math.ceil(l/i.fontSize/1.5)),c=Math.ceil(t.length/h);t=t.map(function(t,e){return e%c!=0?"":t}),0===i._xAxisTextAngle_?(a.beginPath(),a.setFontSize(i.fontSize),a.setFillStyle(e.xAxis.fontColor||"#68707B"),t.forEach(function(t,e){var n=r/2-measureText(t)/2;a.fillText(t,o[e]+n,s+i.fontSize+5)}),a.closePath(),a.stroke()):t.forEach(function(t,n){a.save(),a.beginPath(),a.setFontSize(i.fontSize),a.setFillStyle(e.xAxis.fontColor||"#666666");var l=measureText(t),h=r/2-l,c=calRotateTranslate(o[n]+r/2,s+i.fontSize/2+5,e.height),d=c.transX,x=c.transY;a.rotate(-1*i._xAxisTextAngle_),a.translate(d,x),a.fillText(t,o[n]+h,s+i.fontSize+5),a.closePath(),a.stroke(),a.restore()}),a.restore()}function drawYAxisGrid(t,e,i){for(var a=t.height-2*e.padding-e.xAxisHeight-e.legendHeight,n=Math.floor(a/e.yAxisSplit),o=e.yAxisWidth+e.yAxisTitleWidth,r=e.padding+o,s=t.width-e.padding,l=[],h=0;h<e.yAxisSplit;h++)l.push(e.padding+n*h);l.push(e.padding+n*e.yAxisSplit+2),i.beginPath(),i.setStrokeStyle(t.yAxis.gridColor||"#DEE1E4"),i.setLineWidth(1),l.forEach(function(t,e){e!=l.length-1&&(i.setLineDash([8,6]),i.moveTo(r,t),i.lineTo(s,t),i.closePath(),i.stroke())}),i.beginPath(),i.setStrokeStyle(t.yAxis.gridColor||"#DEE1E4"),i.setLineWidth(1),i.setLineDash([]),i.moveTo(r,l[l.length-1]),i.lineTo(s,l[l.length-1]),i.closePath(),i.stroke()}function drawYAxis(t,e,i,a){if(!0!==e.yAxis.disabled){var n=calYAxisData(t,e,i),o=n.rangesFormat,r=i.yAxisWidth+i.yAxisTitleWidth,s=e.height-2*i.padding-i.xAxisHeight-i.legendHeight,l=Math.floor(s/i.yAxisSplit),h=i.padding+r,c=e.width-i.padding,d=e.height-i.padding-i.xAxisHeight-i.legendHeight;a.setFillStyle(e.background||"#ffffff"),e._scrollDistance_<0&&a.fillRect(0,0,h,d+i.xAxisHeight+5),a.fillRect(c,0,e.width,d+i.xAxisHeight+5);for(var x=[],f=0;f<=i.yAxisSplit;f++)x.push(i.padding+l*f);a.stroke(),a.beginPath(),a.setFontSize(i.fontSize),a.setFillStyle(e.yAxis.fontColor||"#666666"),o.forEach(function(t,e){var n=x[e]?x[e]:d;a.fillText(t,i.padding+i.yAxisTitleWidth,n+i.fontSize/2)}),a.closePath(),a.stroke(),e.yAxis.title&&drawYAxisTitle(e.yAxis.title,e,i,a)}}function drawLegend(t,e,i,a){if(e.legend){var n=calLegendData(t,e,i),o=n.legendList;o.forEach(function(t,n){var o=0;t.forEach(function(t){t.name=t.name||"undefined",o+=15+measureText(t.name)+15});var r=(e.width-o)/2+5,s=e.height-i.padding-i.legendHeight+n*(i.fontSize+8)+5+8;a.setFontSize(i.fontSize),t.forEach(function(t){switch(e.type){case"line":a.beginPath(),a.setLineWidth(1),a.setStrokeStyle(t.color),a.moveTo(r-2,s+5),a.lineTo(r+17,s+5),a.stroke(),a.closePath(),a.beginPath(),a.setLineWidth(1),a.setStrokeStyle("#ffffff"),a.setFillStyle(t.color),a.moveTo(r+7.5,s+5),a.arc(r+7.5,s+5,4,0,2*Math.PI),a.fill(),a.stroke(),a.closePath();break;case"pie":case"ring":a.beginPath(),a.setFillStyle(t.color),a.moveTo(r+7.5,s+5),a.arc(r+7.5,s+5,7,0,2*Math.PI),a.closePath(),a.fill();break;default:a.beginPath(),a.setFillStyle(t.color),a.moveTo(r,s),a.rect(r,s,15,10),a.closePath(),a.fill()}r+=20,a.beginPath(),a.setFillStyle(e.extra.legendTextColor||"#333333"),a.fillText(t.name,r,s+9),a.closePath(),a.stroke(),r+=measureText(t.name)+10})})}}function drawPieDataPoints(t,e,i,a){var n=arguments.length>4&&void 0!==arguments[4]?arguments[4]:1,o=e.extra.pie||{};t=getPieDataPoints(t,n);var r={x:e.width/2,y:(e.height-i.legendHeight)/2},s=Math.min(r.x-i.pieChartLinePadding-i.pieChartTextPadding-i._pieTextMaxLength_,r.y-i.pieChartLinePadding-i.pieChartTextPadding);if(e.dataLabel?s-=10:s-=2*i.padding,t=t.map(function(t){return t._start_+=(o.offsetAngle||0)*Math.PI/180,t}),t.forEach(function(t){a.beginPath(),a.setLineWidth(2),a.setStrokeStyle("#ffffff"),a.setFillStyle(t.color),a.moveTo(r.x,r.y),a.arc(r.x,r.y,s,t._start_,t._start_+2*t._proportion_*Math.PI),a.closePath(),a.fill(),!0!==e.disablePieStroke&&a.stroke()}),"ring"===e.type){var l=.6*s;"number"==typeof e.extra.ringWidth&&e.extra.ringWidth>0&&(l=Math.max(0,s-e.extra.ringWidth)),a.beginPath(),a.setFillStyle(e.background||"#ffffff"),a.moveTo(r.x,r.y),a.arc(r.x,r.y,l,0,2*Math.PI),a.closePath(),a.fill()}if(!1!==e.dataLabel&&1===n){for(var h=!1,c=0,d=t.length;c<d;c++)if(t[c].data>0){h=!0;break}h&&drawPieText(t,e,i,a,s,r)}return 1===n&&"ring"===e.type&&drawRingTitle(e,i,a),{center:r,radius:s,series:t}}function drawRadarDataPoints(t,e,i,a){var n=arguments.length>4&&void 0!==arguments[4]?arguments[4]:1,o=e.extra.radar||{},r=getRadarCoordinateSeries(e.categories.length),s={x:e.width/2,y:(e.height-i.legendHeight)/2},l=Math.min(s.x-(getMaxTextListLength(e.categories)+i.radarLabelTextMargin),s.y-i.radarLabelTextMargin);l-=i.padding,a.beginPath(),a.setLineWidth(1),a.setStrokeStyle(o.gridColor||"#cccccc"),r.forEach(function(t){var e=convertCoordinateOrigin(l*Math.cos(t),l*Math.sin(t),s);a.moveTo(s.x,s.y),a.lineTo(e.x,e.y)}),a.stroke(),a.closePath();for(var h=1;h<=i.radarGridCount;h++)!function(t){var e={};a.beginPath(),a.setLineWidth(1),a.setStrokeStyle(o.gridColor||"#cccccc"),r.forEach(function(n,o){var r=convertCoordinateOrigin(l/i.radarGridCount*t*Math.cos(n),l/i.radarGridCount*t*Math.sin(n),s);0===o?(e=r,a.moveTo(r.x,r.y)):a.lineTo(r.x,r.y)}),a.lineTo(e.x,e.y),a.stroke(),a.closePath()}(h);return getRadarDataPoints(r,s,l,t,e,n).forEach(function(t,n){if(a.beginPath(),a.setFillStyle(t.color),a.setGlobalAlpha(.6),t.data.forEach(function(t,e){0===e?a.moveTo(t.position.x,t.position.y):a.lineTo(t.position.x,t.position.y)}),a.closePath(),a.fill(),a.setGlobalAlpha(1),!1!==e.dataPointShape){var o=i.dataPointShape[n%i.dataPointShape.length];drawPointShape(t.data.map(function(t){return t.position}),t.color,o,a)}}),drawRadarLabel(r,l,s,e,i,a),{center:s,radius:l,angleList:r}}function drawRoundedRect(t,e,i,a,n,o,r,s){t.save(),t.beginPath(),t.moveTo(e+o,i),t.arcTo(e+a,i,e+a,i+o,o),t.arcTo(e+a,i+n,e+a,i+n,o),t.arcTo(e,i+n,e,i+n,o),t.arcTo(e,i,e+o,i,o),r&&t.fill(),s&&t.stroke(),t.restore()}function drawCanvas(t,e){e.draw()}function Animation(t){this.isStop=!1,t.duration=void 0===t.duration?1e3:t.duration,t.timing=t.timing||"linear";var e=function(){return"undefined"!=typeof requestAnimationFrame?requestAnimationFrame:"undefined"!=typeof setTimeout?function(t,e){setTimeout(function(){var e=+new Date;t(e)},e)}:function(t){t(null)}}(),i=null,a=function(n){if(null===n||!0===this.isStop)return t.onProcess&&t.onProcess(1),void(t.onAnimationFinish&&t.onAnimationFinish());if(null===i&&(i=n),n-i<t.duration){var o=(n-i)/t.duration;o=(0,Timing[t.timing])(o),t.onProcess&&t.onProcess(o),e(a,17)}else t.onProcess&&t.onProcess(1),t.onAnimationFinish&&t.onAnimationFinish()};a=a.bind(this),e(a,17)}function drawCharts(t,e,i,a){var n=this,o=e.series,r=e.categories;o=fillSeriesColor(o,i);var s=calLegendData(o,e,i),l=s.legendHeight;i.legendHeight=l;var h=calYAxisData(o,e,i),c=h.yAxisWidth;if(i.yAxisWidth=c,r&&r.length){var d=calCategoriesData(r,e,i),x=d.xAxisHeight,f=d.angle;i.xAxisHeight=x,i._xAxisTextAngle_=f}"pie"!==t&&"ring"!==t||(i._pieTextMaxLength_=!1===e.dataLabel?0:getPieTextMaxLength(o));var g=e.animation?1e3:0;switch(this.animationInstance&&this.animationInstance.stop(),t){case"line":this.animationInstance=new Animation({timing:"easeIn",duration:g,onProcess:function(t){drawYAxisGrid(e,i,a);var s=drawLineDataPoints(o,e,i,a,t),l=s.xAxisPoints,h=s.calPoints,c=s.eachSpacing;n.chartData.xAxisPoints=l,n.chartData.calPoints=h,n.chartData.eachSpacing=c,drawXAxis(r,e,i,a),drawLegend(e.series,e,i,a),drawYAxis(o,e,i,a),drawToolTipBridge(e,i,a,t),drawCanvas(e,a)},onAnimationFinish:function(){n.event.trigger("renderComplete")}});break;case"column":this.animationInstance=new Animation({timing:"easeIn",duration:g,onProcess:function(t){drawYAxisGrid(e,i,a);var s=drawColumnDataPoints(o,e,i,a,t),l=s.xAxisPoints,h=s.eachSpacing;n.chartData.xAxisPoints=l,n.chartData.eachSpacing=h,drawXAxis(r,e,i,a),drawLegend(e.series,e,i,a),drawYAxis(o,e,i,a),drawCanvas(e,a)},onAnimationFinish:function(){n.event.trigger("renderComplete")}});break;case"area":this.animationInstance=new Animation({timing:"easeIn",duration:g,onProcess:function(t){drawYAxisGrid(e,i,a);var s=drawAreaDataPoints(o,e,i,a,t),l=s.xAxisPoints,h=s.calPoints,c=s.eachSpacing;n.chartData.xAxisPoints=l,n.chartData.calPoints=h,n.chartData.eachSpacing=c,drawXAxis(r,e,i,a),drawLegend(e.series,e,i,a),drawYAxis(o,e,i,a),drawToolTipBridge(e,i,a,t),drawCanvas(e,a)},onAnimationFinish:function(){n.event.trigger("renderComplete")}});break;case"ring":case"pie":this.animationInstance=new Animation({timing:"easeInOut",duration:g,onProcess:function(t){n.chartData.pieData=drawPieDataPoints(o,e,i,a,t),drawLegend(e.series,e,i,a),drawCanvas(e,a)},onAnimationFinish:function(){n.event.trigger("renderComplete")}});break;case"radar":this.animationInstance=new Animation({timing:"easeInOut",duration:g,onProcess:function(t){n.chartData.radarData=drawRadarDataPoints(o,e,i,a,t),drawLegend(e.series,e,i,a),drawCanvas(e,a)},onAnimationFinish:function(){n.event.trigger("renderComplete")}})}}function Event(){this.events={}}var config={yAxisWidth:15,yAxisSplit:4,xAxisHeight:15,xAxisLineHeight:15,legendHeight:15,yAxisTitleWidth:15,padding:17,columePadding:3,fontSize:14,dataPointShape:["diamond","circle","triangle","rect"],colors:["#7cb5ec","#f7a35c","#434348","#90ed7d","#f15c80","#8085e9"],pieChartLinePadding:25,pieChartTextPadding:15,xAxisTextPadding:3,titleColor:"#333333",titleFontSize:20,subtitleColor:"#999999",subtitleFontSize:15,toolTipPadding:3,toolTipBackground:"#333000",toolTipOpacity:.7,toolTipLineHeight:14,radarGridCount:3,radarLabelTextMargin:15},util={toFixed:function(t,e){return e=e||2,this.isFloat(t)&&(t=t.toFixed(e)),t},isFloat:function(t){return t%1!=0},approximatelyEqual:function(t,e){return Math.abs(t-e)<1e-10},isSameSign:function(t,e){return Math.abs(t)===t&&Math.abs(e)===e||Math.abs(t)!==t&&Math.abs(e)!==e},isSameXCoordinateArea:function(t,e){return this.isSameSign(t.x,e.x)},isCollision:function(t,e){return t.end={},t.end.x=t.start.x+t.width,t.end.y=t.start.y-t.height,e.end={},e.end.x=e.start.x+e.width,e.end.y=e.start.y-e.height,!(e.start.x>t.end.x||e.end.x<t.start.x||e.end.y>t.start.y||e.start.y<t.end.y)}},Timing={easeIn:function(t){return Math.pow(t,3)},easeOut:function(t){return Math.pow(t-1,3)+1},easeInOut:function(t){return(t/=.5)<1?.5*Math.pow(t,3):.5*(Math.pow(t-2,3)+2)},linear:function(t){return t}};Animation.prototype.stop=function(){this.isStop=!0},Event.prototype.addEventListener=function(t,e){this.events[t]=this.events[t]||[],this.events[t].push(e)},Event.prototype.trigger=function(){for(var t=arguments.length,e=Array(t),i=0;i<t;i++)e[i]=arguments[i];var a=e[0],n=e.slice(1);this.events[a]&&this.events[a].forEach(function(t){try{t.apply(null,n)}catch(t){console.error(t)}})};var Charts=function(t){t.title=t.title||{},t.subtitle=t.subtitle||{},t.yAxis=t.yAxis||{},t.xAxis=t.xAxis||{},t.extra=t.extra||{},t.legend=!1!==t.legend,t.animation=!1!==t.animation;var e=assign({},config);e.yAxisTitleWidth=!0!==t.yAxis.disabled&&t.yAxis.title?e.yAxisTitleWidth:0,e.pieChartLinePadding=!1===t.dataLabel?0:e.pieChartLinePadding,e.pieChartTextPadding=!1===t.dataLabel?0:e.pieChartTextPadding,this.opts=t,this.config=e,this.context=wx.createCanvasContext(t.canvasId),this.chartData={},this.event=new Event,this.scrollOption={currentOffset:0,startTouchX:0,distance:0},drawCharts.call(this,t.type,t,e,this.context)};Charts.prototype.updateData=function(){var t=arguments.length>0&&void 0!==arguments[0]?arguments[0]:{};this.opts.series=t.series||this.opts.series,this.opts.categories=t.categories||this.opts.categories,this.opts.title=assign({},this.opts.title,t.title||{}),this.opts.subtitle=assign({},this.opts.subtitle,t.subtitle||{}),drawCharts.call(this,this.opts.type,this.opts,this.config,this.context)},Charts.prototype.stopAnimation=function(){this.animationInstance&&this.animationInstance.stop()},Charts.prototype.addEventListener=function(t,e){this.event.addEventListener(t,e)},Charts.prototype.getCurrentDataIndex=function(t){var e=t.touches&&t.touches.length?t.touches:t.changedTouches;if(e&&e.length){var i=e[0],a=i.x,n=i.y;return"pie"===this.opts.type||"ring"===this.opts.type?findPieChartCurrentIndex({x:a,y:n},this.chartData.pieData):"radar"===this.opts.type?findRadarChartCurrentIndex({x:a,y:n},this.chartData.radarData,this.opts.categories.length):findCurrentIndex({x:a,y:n},this.chartData.xAxisPoints,this.opts,this.config,Math.abs(this.scrollOption.currentOffset))}return-1},Charts.prototype.showToolTip=function(t){var e=arguments.length>1&&void 0!==arguments[1]?arguments[1]:{};if("line"===this.opts.type||"area"===this.opts.type){var i=this.getCurrentDataIndex(t),a=this.scrollOption.currentOffset,n=assign({},this.opts,{_scrollDistance_:a,animation:!1});if(i>-1){var o=getSeriesDataItem(this.opts.series,i);if(0!==o.length){var r=getToolTipData(o,this.chartData.calPoints,i,this.opts.categories,e),s=r.textList,l=r.offset;n.tooltip={textList:s,offset:l,option:e}}}drawCharts.call(this,n.type,n,this.config,this.context)}},Charts.prototype.scrollStart=function(t){t.touches[0]&&!0===this.opts.enableScroll&&(this.scrollOption.startTouchX=t.touches[0].x)},Charts.prototype.scroll=function(t){if(t.touches[0]&&!0===this.opts.enableScroll){var e=t.touches[0].x-this.scrollOption.startTouchX,i=this.scrollOption.currentOffset,a=calValidDistance(i+e,this.chartData,this.config,this.opts);this.scrollOption.distance=e=a-i;var n=assign({},this.opts,{_scrollDistance_:i+e,animation:!1});drawCharts.call(this,n.type,n,this.config,this.context)}},Charts.prototype.scrollEnd=function(t){if(!0===this.opts.enableScroll){var e=this.scrollOption,i=e.currentOffset,a=e.distance;this.scrollOption.currentOffset=i+a,this.scrollOption.distance=0}},module.exports=Charts; 
 			}); 
		define("common/http.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			
"use strict";function _interopRequireDefault(e){return e&&e.__esModule?e:{default:e}}function HttpRequest(e){var t=arguments.length>1&&void 0!==arguments[1]?arguments[1]:{},o=arguments.length>2&&void 0!==arguments[2]?arguments[2]:"GET",n=arguments.length>3&&void 0!==arguments[3]?arguments[3]:"form";return new Promise(function(a,s){e=_wepy2.default.$appConfig.rootURL+e,t=Object.assign(t,{version:_constant2.default.KEY_VERSION}),_wepy2.default.request({url:e,method:o,header:sessionType[n],data:t,dataType:"json"}).then(function(e){200===e.statusCode&&0===e.data.errorCode?a(e.data.results):(console.log("HttpRequest status !== 1, detail:",e),s(e.data))}).catch(function(e){console.log("HttpRequest error:",e),s(e)})})}function Login(e){var t=arguments.length>1&&void 0!==arguments[1]&&arguments[1];return new Promise(function(o,n){_wepy2.default.login().then(function(a){HttpRequest("/wx/authNew",{code:a.code,appKey:"politicalExamServer"},"GET").then(function(a){e.openId=a.openId;var s=_wepy2.default.$instance.globalData.scene||"";if(a.isAuth||t)_kcLog2.default.send({pagename:"HomePage",name:"loginSuccess",category:"login",pt:"mini"}),e.scene=s,HttpRequest("/wx/loginNew",e,"POST","json").then(function(e){var t=_storage2.default.set(_constant2.default.KEY_IS_AUTH,!0),r=_storage2.default.set(_constant2.default.KEY_TOKEN,e.token),u=_storage2.default.set(_constant2.default.KEY_OPENID,a.openId),c=_storage2.default.set(_constant2.default.KEY_UNIONID,e.unionId);Promise.all([t,r,u,c]).then(function(e){reportNewUser(a.isNew,s,a.openId),o()}).catch(function(e){console.log("Login storage-token error:",e),n(e)})}).catch(function(e){console.log("Login request-login error:",e),n(e)});else{var r=_storage2.default.set(_constant2.default.KEY_TOKEN,a.token),u=_storage2.default.set(_constant2.default.KEY_IS_AUTH,!1),c=_storage2.default.set(_constant2.default.KEY_IS_NEW,a.isNew),i=_storage2.default.set(_constant2.default.KEY_OPENID,a.openId);_kcLog2.default.send({pagename:"HomePage",name:"signupSuccess",category:"signUp",pt:"mini"}),Promise.all([r,u,c,i]).then(function(e){reportNewUser(a.isNew,s,a.openId),o()}).catch(function(e){console.log("Login storage-all error:",e),n(e)})}}).catch(function(e){console.log("Login request-auth error:",e),n(e)})}).catch(function(e){console.log("Login wx-login error:",e),n(e)})})}function register(e){var t=arguments.length>1&&void 0!==arguments[1]&&arguments[1];return new Promise(function(o,n){HttpRequest("/wx/authNew",{code:e.code,appKey:"politicalExamServer"},"GET").then(function(a){e.openId=a.openId;var s=_wepy2.default.$instance.globalData.scene||"";if(a.isAuth||t)e.scene=s,HttpRequest("/wx/loginNew",e,"POST","json").then(function(e){var t=_storage2.default.set(_constant2.default.KEY_IS_AUTH,!0),r=_storage2.default.set(_constant2.default.KEY_TOKEN,e.token),u=_storage2.default.set(_constant2.default.KEY_OPENID,a.openId),c=_storage2.default.set(_constant2.default.KEY_UNIONID,e.unionId);Promise.all([t,r,u,c]).then(function(e){reportNewUser(a.isNew,s,a.openId),o()}).catch(function(e){console.log("Login storage-token error:",e),n(e)})}).catch(function(e){console.log("Login request-login error:",e),n(e)});else{var r=_storage2.default.set(_constant2.default.KEY_TOKEN,a.token),u=_storage2.default.set(_constant2.default.KEY_IS_AUTH,!1),c=_storage2.default.set(_constant2.default.KEY_IS_NEW,a.isNew),i=_storage2.default.set(_constant2.default.KEY_OPENID,a.openId);Promise.all([r,u,c,i]).then(function(e){reportNewUser(a.isNew,s,a.openId),o()}).catch(function(e){console.log("Login storage-all error:",e),n(e)})}}).catch(function(e){console.log("Login request-auth error:",e),n(e)})})}function reportNewUser(e,t,o){var n=getCurrentPages(),a=n[n.length-1].options,s={BSceneCode:"auth",BDescribe:"授权成功",BIsNew:e?1:0,ext:{scene:t}},r="share"===a.from&&a.openId;r&&r!==o&&(s.ext=Object.assign(s.ext,{shareUser:r}))}function HttpRequestV2(e){var t=arguments.length>1&&void 0!==arguments[1]?arguments[1]:{},o=arguments.length>2&&void 0!==arguments[2]?arguments[2]:"GET",n=arguments.length>3&&void 0!==arguments[3]?arguments[3]:"form";return new Promise(function(a,s){-1===e.indexOf("http")&&(e=_wepy2.default.$appConfig.rootURL+e),t=Object.assign(t,{version:_constant2.default.KEY_VERSION});var r=wx.getStorageSync(_constant2.default.KEY_TOKEN)||"",u=sessionType[n];u.token=r,_wepy2.default.request({url:e,method:o,header:u,data:t,dataType:"json"}).then(function(n){200===n.statusCode&&0===n.data.errorCode?a(n.data.results):200===n.statusCode&&4===n.data.errorCode?(_wepy2.default.removeStorage({key:_constant2.default.KEY_TOKEN}),Login({}).then(function(){var n=wx.getStorageSync(_constant2.default.KEY_TOKEN)||"";u.token=n,_wepy2.default.request({url:e,method:o,header:u,data:t,dataType:"json"}).then(function(e){200===e.statusCode&&0===e.data.errorCode?a(e.data.results):(console.log("HttpRequestV2 retry status !== 1, detail:",e),s(e.data))}).catch(function(e){console.log("HttpRequestV2 retry error:",e),s(e)})}).catch(function(e){console.log("HttpRequestV2 Login, error:",e),s(e)})):200===n.statusCode&&5022===n.data.errorCode?wx.reLaunch({url:"login"}):(console.log("HttpRequestV2 status !== 1, detail:",n),s(n.data))}).catch(function(e){s(e)})})}function get(e,t){return HttpRequestV2(e,t)}function post(e,t,o){return HttpRequestV2(e,t,"POST",o)}var _wepy=require("./../npm/wepy/lib/wepy.js"),_wepy2=_interopRequireDefault(_wepy),_storage=require("./storage.js"),_storage2=_interopRequireDefault(_storage),_constant=require("./constant.js"),_constant2=_interopRequireDefault(_constant),_common=require("./common.js"),_common2=_interopRequireDefault(_common),_kcLog=require("./../npm/@kc-base/kc-log/dist/kc-log.js"),_kcLog2=_interopRequireDefault(_kcLog),sessionType={json:{"content-type":"application/json"},form:{"content-type":"application/x-www-form-urlencoded"}};module.exports={get:get,post:post,Login:Login,register:register}; 
 			}); 
		define("common/log.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			
"use strict";var log=wx.getRealtimeLogManager?wx.getRealtimeLogManager():null;module.exports={info:function(){log&&log.info.apply(log,arguments)},warn:function(){log&&log.warn.apply(log,arguments)},error:function(){log&&log.error.apply(log,arguments)},setFilterMsg:function(o){log&&log.setFilterMsg&&"string"==typeof o&&log.setFilterMsg(o)},addFilterMsg:function(o){log&&log.addFilterMsg&&"string"==typeof o&&log.addFilterMsg(o)}}; 
 			}); 
		define("common/report.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			
"use strict";function _interopRequireDefault(e){return e&&e.__esModule?e:{default:e}}function _classCallCheck(e,n){if(!(e instanceof n))throw new TypeError("Cannot call a class as a function")}Object.defineProperty(exports,"__esModule",{value:!0});var _createClass=function(){function e(e,n){for(var t=0;t<n.length;t++){var r=n[t];r.enumerable=r.enumerable||!1,r.configurable=!0,"value"in r&&(r.writable=!0),Object.defineProperty(e,r.key,r)}}return function(n,t,r){return t&&e(n.prototype,t),r&&e(n,r),n}}(),_wepy=require("./../npm/wepy/lib/wepy.js"),_wepy2=_interopRequireDefault(_wepy),reportURL="https://analyze.kaochong.com/business",Report=function(){function e(n,t,r){_classCallCheck(this,e),this.instance=null,this.BSource=n,this.BVersion=t,this.idObj=r}return _createClass(e,[{key:"send",value:function(e){var n=getCurrentPages(),t=n[n.length-1].route;e=Object.assign({BSource:this.BSource,BVersion:this.BVersion,BClientSource:"FE",BCreateTime:+(new Date).getTime(),BPage:t},this.idObj,e),_wepy2.default.request({data:e,url:reportURL,method:"POST",header:{"content-type":"application/json"},dataType:"json"}),console.log("【send】complete data... \n "+JSON.stringify(e,null,2))}}],[{key:"init",value:function(n,t,r,i,o){if(!this.instance||this.instance&&r&&"noAuth"===this.instance.idObj.BUserId){if(!n)throw Error("Report.init需传入项目标识 【BSource】");if(!t)throw Error("Report.init需传入项目版本号【BVersion】");if(!r&&(r="noAuth",console.warn("------------------------------------ \n*\n* Report.init需传入用户unionId【BUserId】\n*\n* 您目前没有传入 \n*\n* 如果存在unionID请补充 \n*\n* 如果不存在请务必传入openID \n*\n ------------------------------------"),!i))throw Error("Report.init需传入用户标识【BOpenId】");console.log("【init】"+n+"_"+t+" reportor...["+r+"]");var s={BUserId:r};i&&Object.assign(s,{BOpenId:i}),o&&Object.assign(s,{BUID:o}),this.instance=new e(n,t,s)}return this.instance}}]),e}();exports.default=Report; 
 			}); 
		define("common/storage.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			
"use strict";function _interopRequireDefault(e){return e&&e.__esModule?e:{default:e}}function set(e,t){return new Promise(function(n,r){_wepy2.default.setStorage({key:e,data:t}).then(function(e){n()}).catch(function(e){n()})})}function get(e){return new Promise(function(t,n){_wepy2.default.getStorage({key:e}).then(function(e){t(e.data)}).catch(function(e){t()})})}function remove(e){return new Promise(function(t,n){_wepy2.default.removeStorage({key:e}).then(function(e){t()}).catch(function(e){t()})})}function clear(){return new Promise(function(e,t){_wepy2.default.clearStorage().then(function(t){e()}).catch(function(t){e()})})}Object.defineProperty(exports,"__esModule",{value:!0});var _wepy=require("./../npm/wepy/lib/wepy.js"),_wepy2=_interopRequireDefault(_wepy);exports.default={set:set,get:get,remove:remove,clear:clear}; 
 			}); 
		define("components/KcErrorModal.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			
"use strict";function _interopRequireDefault(e){return e&&e.__esModule?e:{default:e}}function _classCallCheck(e,t){if(!(e instanceof t))throw new TypeError("Cannot call a class as a function")}function _possibleConstructorReturn(e,t){if(!e)throw new ReferenceError("this hasn't been initialised - super() hasn't been called");return!t||"object"!=typeof t&&"function"!=typeof t?e:t}function _inherits(e,t){if("function"!=typeof t&&null!==t)throw new TypeError("Super expression must either be null or a function, not "+typeof t);e.prototype=Object.create(t&&t.prototype,{constructor:{value:e,enumerable:!1,writable:!0,configurable:!0}}),t&&(Object.setPrototypeOf?Object.setPrototypeOf(e,t):e.__proto__=t)}Object.defineProperty(exports,"__esModule",{value:!0}),exports.default=void 0;var _wepy=require("./../npm/wepy/lib/wepy.js"),_wepy2=_interopRequireDefault(_wepy),KcErrorModal=function(e){function t(){var e,r,o,n;_classCallCheck(this,t);for(var s=arguments.length,i=Array(s),c=0;c<s;c++)i[c]=arguments[c];return r=o=_possibleConstructorReturn(this,(e=t.__proto__||Object.getPrototypeOf(t)).call.apply(e,[this].concat(i))),o.props={},o.data={errorType:1,show:!1,cb:null,btnMsg:"重新加载",text:"(>﹏<)小程序出了点问题"},o.methods={showModal:function(e){var t=e.err,r=e.btnMsg,o=e.cb;t&&t.errMsg&&t.errMsg.indexOf("fail")>=0&&!t.code?this.errorType=1:this.errorType=2,this.show=!0,this.btnMsg=r||"重新加载",this.cb=o,this.$apply()},reLoad:function(){this.show=!1,(0,this.cb)()},close:function(){this.show=!1}},n=r,_possibleConstructorReturn(o,n)}return _inherits(t,e),t}(_wepy2.default.component);exports.default=KcErrorModal; 
 			}); 
		define("components/KcLoading.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			
"use strict";function _interopRequireDefault(e){return e&&e.__esModule?e:{default:e}}function _classCallCheck(e,t){if(!(e instanceof t))throw new TypeError("Cannot call a class as a function")}function _possibleConstructorReturn(e,t){if(!e)throw new ReferenceError("this hasn't been initialised - super() hasn't been called");return!t||"object"!=typeof t&&"function"!=typeof t?e:t}function _inherits(e,t){if("function"!=typeof t&&null!==t)throw new TypeError("Super expression must either be null or a function, not "+typeof t);e.prototype=Object.create(t&&t.prototype,{constructor:{value:e,enumerable:!1,writable:!0,configurable:!0}}),t&&(Object.setPrototypeOf?Object.setPrototypeOf(e,t):e.__proto__=t)}Object.defineProperty(exports,"__esModule",{value:!0}),exports.default=void 0;var _wepy=require("./../npm/wepy/lib/wepy.js"),_wepy2=_interopRequireDefault(_wepy),KcLoading=function(e){function t(){var e,o,r,n;_classCallCheck(this,t);for(var i=arguments.length,u=Array(i),s=0;s<i;s++)u[s]=arguments[s];return o=r=_possibleConstructorReturn(this,(e=t.__proto__||Object.getPrototypeOf(t)).call.apply(e,[this].concat(u))),r.props={loadingHide:{default:!1,type:Boolean}},n=o,_possibleConstructorReturn(r,n)}return _inherits(t,e),t}(_wepy2.default.component);exports.default=KcLoading; 
 			}); 
		define("components/KcModle.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			
"use strict";function _interopRequireDefault(t){return t&&t.__esModule?t:{default:t}}function _classCallCheck(t,e){if(!(t instanceof e))throw new TypeError("Cannot call a class as a function")}function _possibleConstructorReturn(t,e){if(!t)throw new ReferenceError("this hasn't been initialised - super() hasn't been called");return!e||"object"!=typeof e&&"function"!=typeof e?t:e}function _inherits(t,e){if("function"!=typeof e&&null!==e)throw new TypeError("Super expression must either be null or a function, not "+typeof e);t.prototype=Object.create(e&&e.prototype,{constructor:{value:t,enumerable:!1,writable:!0,configurable:!0}}),e&&(Object.setPrototypeOf?Object.setPrototypeOf(t,e):t.__proto__=e)}Object.defineProperty(exports,"__esModule",{value:!0}),exports.default=void 0;var _wepy=require("./../npm/wepy/lib/wepy.js"),_wepy2=_interopRequireDefault(_wepy),KcModal=function(t){function e(){var t,o,r,n;_classCallCheck(this,e);for(var s=arguments.length,i=Array(s),c=0;c<s;c++)i[c]=arguments[c];return o=r=_possibleConstructorReturn(this,(t=e.__proto__||Object.getPrototypeOf(e)).call.apply(t,[this].concat(i))),r.props={},r.data={cb:null,show:!1,tips:["同学，你目前的网络状况不好","建议切换至稳定的网络环境",""],btnMsg:"",src:""},r.methods={showModal:function(t){var e=t.msg,o=t.src,r=t.btnMsg,n=t.cb;console.log(e),this.show=!0,this.src=o,this.tips=e,this.btnMsg=r,this.cb=n,this.$apply()},close:function(){this.show=!1,(0,this.cb)()}},n=o,_possibleConstructorReturn(r,n)}return _inherits(e,t),e}(_wepy2.default.component);exports.default=KcModal; 
 			}); 
		define("components/KcModulForHelp.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			
"use strict";function _interopRequireDefault(e){return e&&e.__esModule?e:{default:e}}function _classCallCheck(e,t){if(!(e instanceof t))throw new TypeError("Cannot call a class as a function")}function _possibleConstructorReturn(e,t){if(!e)throw new ReferenceError("this hasn't been initialised - super() hasn't been called");return!t||"object"!=typeof t&&"function"!=typeof t?e:t}function _inherits(e,t){if("function"!=typeof t&&null!==t)throw new TypeError("Super expression must either be null or a function, not "+typeof t);e.prototype=Object.create(t&&t.prototype,{constructor:{value:e,enumerable:!1,writable:!0,configurable:!0}}),t&&(Object.setPrototypeOf?Object.setPrototypeOf(e,t):e.__proto__=t)}Object.defineProperty(exports,"__esModule",{value:!0}),exports.default=void 0;var _wepy=require("./../npm/wepy/lib/wepy.js"),_wepy2=_interopRequireDefault(_wepy),KcModulForHelp=function(e){function t(){var e,o,r,n;_classCallCheck(this,t);for(var u=arguments.length,s=Array(u),l=0;l<u;l++)s[l]=arguments[l];return o=r=_possibleConstructorReturn(this,(e=t.__proto__||Object.getPrototypeOf(t)).call.apply(e,[this].concat(s))),r.props={show:{type:Boolean,default:!1,twoWay:!0}},r.methods={closeModul:function(){this.show=!1},stopTouch:function(){console.log("no touch")}},n=o,_possibleConstructorReturn(r,n)}return _inherits(t,e),t}(_wepy2.default.component);exports.default=KcModulForHelp; 
 			}); 
		define("components/KcShowError.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			
"use strict";function _interopRequireDefault(e){return e&&e.__esModule?e:{default:e}}function _classCallCheck(e,t){if(!(e instanceof t))throw new TypeError("Cannot call a class as a function")}function _possibleConstructorReturn(e,t){if(!e)throw new ReferenceError("this hasn't been initialised - super() hasn't been called");return!t||"object"!=typeof t&&"function"!=typeof t?e:t}function _inherits(e,t){if("function"!=typeof t&&null!==t)throw new TypeError("Super expression must either be null or a function, not "+typeof t);e.prototype=Object.create(t&&t.prototype,{constructor:{value:e,enumerable:!1,writable:!0,configurable:!0}}),t&&(Object.setPrototypeOf?Object.setPrototypeOf(e,t):e.__proto__=t)}Object.defineProperty(exports,"__esModule",{value:!0}),exports.default=void 0;var _wepy=require("./../npm/wepy/lib/wepy.js"),_wepy2=_interopRequireDefault(_wepy),KcShowError=function(e){function t(){var e,o,r,n;_classCallCheck(this,t);for(var s=arguments.length,i=Array(s),u=0;u<s;u++)i[u]=arguments[u];return o=r=_possibleConstructorReturn(this,(e=t.__proto__||Object.getPrototypeOf(t)).call.apply(e,[this].concat(i))),r.props={show:{type:Boolean,default:!1,twoWay:!0},type:{type:Number,default:1}},r.data={text:"(>﹏<)小程序出了点问题"},r.methods={reStart:function(){this.show=!1,1===this.type?this.$emit("reLoad"):wx.reLaunch({url:"../pages/index"})},closeModul:function(){this.show=!1}},n=o,_possibleConstructorReturn(r,n)}return _inherits(t,e),t}(_wepy2.default.component);exports.default=KcShowError; 
 			}); 
		define("components/KcShowGuide.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			
"use strict";function _interopRequireDefault(e){return e&&e.__esModule?e:{default:e}}function _classCallCheck(e,t){if(!(e instanceof t))throw new TypeError("Cannot call a class as a function")}function _possibleConstructorReturn(e,t){if(!e)throw new ReferenceError("this hasn't been initialised - super() hasn't been called");return!t||"object"!=typeof t&&"function"!=typeof t?e:t}function _inherits(e,t){if("function"!=typeof t&&null!==t)throw new TypeError("Super expression must either be null or a function, not "+typeof t);e.prototype=Object.create(t&&t.prototype,{constructor:{value:e,enumerable:!1,writable:!0,configurable:!0}}),t&&(Object.setPrototypeOf?Object.setPrototypeOf(e,t):e.__proto__=t)}Object.defineProperty(exports,"__esModule",{value:!0}),exports.default=void 0;var _wepy=require("./../npm/wepy/lib/wepy.js"),_wepy2=_interopRequireDefault(_wepy),KcShowGuide=function(e){function t(){var e,o,r,n;_classCallCheck(this,t);for(var s=arguments.length,u=Array(s),i=0;i<s;i++)u[i]=arguments[i];return o=r=_possibleConstructorReturn(this,(e=t.__proto__||Object.getPrototypeOf(t)).call.apply(e,[this].concat(u))),r.props={show:{type:Boolean,default:!1,twoWay:!0}},r.methods={closeModul:function(){this.show=!1,wx.setStorageSync("hasShowGuide",!0)}},n=o,_possibleConstructorReturn(r,n)}return _inherits(t,e),t}(_wepy2.default.component);exports.default=KcShowGuide; 
 			}); 
		define("components/KcUpValue.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			
"use strict";function _interopRequireDefault(e){return e&&e.__esModule?e:{default:e}}function _asyncToGenerator(e){return function(){var t=e.apply(this,arguments);return new Promise(function(e,n){function r(o,i){try{var a=t[o](i),u=a.value}catch(e){return void n(e)}if(!a.done)return Promise.resolve(u).then(function(e){r("next",e)},function(e){r("throw",e)});e(u)}return r("next")})}}function _classCallCheck(e,t){if(!(e instanceof t))throw new TypeError("Cannot call a class as a function")}function _possibleConstructorReturn(e,t){if(!e)throw new ReferenceError("this hasn't been initialised - super() hasn't been called");return!t||"object"!=typeof t&&"function"!=typeof t?e:t}function _inherits(e,t){if("function"!=typeof t&&null!==t)throw new TypeError("Super expression must either be null or a function, not "+typeof t);e.prototype=Object.create(t&&t.prototype,{constructor:{value:e,enumerable:!1,writable:!0,configurable:!0}}),t&&(Object.setPrototypeOf?Object.setPrototypeOf(e,t):e.__proto__=t)}Object.defineProperty(exports,"__esModule",{value:!0}),exports.default=void 0;var _createClass=function(){function e(e,t){for(var n=0;n<t.length;n++){var r=t[n];r.enumerable=r.enumerable||!1,r.configurable=!0,"value"in r&&(r.writable=!0),Object.defineProperty(e,r.key,r)}}return function(t,n,r){return n&&e(t.prototype,n),r&&e(t,r),t}}(),_wepy=require("./../npm/wepy/lib/wepy.js"),_wepy2=_interopRequireDefault(_wepy),_api=require("./../common/api.js"),_api2=_interopRequireDefault(_api),_storage=require("./../common/storage.js"),_storage2=_interopRequireDefault(_storage),log=require("./../common/log.js"),KcUpValue=function(e){function t(){var e,n,r,o;_classCallCheck(this,t);for(var i=arguments.length,a=Array(i),u=0;u<i;u++)a[u]=arguments[u];return n=r=_possibleConstructorReturn(this,(e=t.__proto__||Object.getPrototypeOf(t)).call.apply(e,[this].concat(a))),r.props={},r.data={cb:null,show:!1,imgSrc:"",title:"",text1:"",text2:"",text3:"",leftBtnText:"",rightBtnText:"",leftCb:null,rightCb:null,rightBtnTips:""},r.methods={showModal:function(e){var t=e.cb;this.show=!0,this.cb=t,this.$apply()},close:function(){this.show=!1},leftBtn:function(){this.leftCb()},rightBtn:function(){this.rightCb()}},o=n,_possibleConstructorReturn(r,o)}return _inherits(t,e),_createClass(t,[{key:"unlockVideo",value:function(){function e(e){return t.apply(this,arguments)}var t=_asyncToGenerator(regeneratorRuntime.mark(function e(t){var n;return regeneratorRuntime.wrap(function(e){for(;;)switch(e.prev=e.next){case 0:return e.prev=0,e.next=3,_storage2.default.get("token");case 3:if(e.t0=e.sent,e.t0){e.next=6;break}e.t0=0;case 6:return n=e.t0,e.next=9,_api2.default.unlockVideo({questionId:t,token:n});case 9:this.show=!1,this.$apply(),this.$emit("unlockVideoSuccess"),e.next=18;break;case 14:e.prev=14,e.t1=e.catch(0),console.log(e.t1),wx.showToast({title:"解锁失败,请重试",icon:"none",duration:3e3});case 18:case"end":return e.stop()}},e,this,[[0,14]])}));return e}()},{key:"close",value:function(){this.$apply(),this.show=!1}},{key:"modalCloseCb",value:function(){this.$emit("modalCloseCb")}},{key:"unlockCourse",value:function(){function e(e,n){return t.apply(this,arguments)}var t=_asyncToGenerator(regeneratorRuntime.mark(function e(t,n){var r;return regeneratorRuntime.wrap(function(e){for(;;)switch(e.prev=e.next){case 0:return e.next=2,_storage2.default.get("token");case 2:if(e.t0=e.sent,e.t0){e.next=5;break}e.t0=0;case 5:return r=e.t0,e.prev=6,e.next=9,_api2.default.unlockCourse({subjectId:t,stage:n,token:r});case 9:log.info("解锁弹窗去列表页","learnIndex?sid="+t+"&day="+n),wx.redirectTo({url:"learnIndex?sid="+t+"&day="+n}),e.next=17;break;case 13:e.prev=13,e.t1=e.catch(6),console.log(e.t1),wx.showToast({title:"解锁失败,请重试",icon:"none",duration:3e3});case 17:case"end":return e.stop()}},e,this,[[6,13]])}));return e}()}]),t}(_wepy2.default.component);exports.default=KcUpValue; 
 			}); 
		define("components/KcVipModal.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			
"use strict";function _interopRequireDefault(t){return t&&t.__esModule?t:{default:t}}function _classCallCheck(t,e){if(!(t instanceof e))throw new TypeError("Cannot call a class as a function")}function _possibleConstructorReturn(t,e){if(!t)throw new ReferenceError("this hasn't been initialised - super() hasn't been called");return!e||"object"!=typeof e&&"function"!=typeof e?t:e}function _inherits(t,e){if("function"!=typeof e&&null!==e)throw new TypeError("Super expression must either be null or a function, not "+typeof e);t.prototype=Object.create(e&&e.prototype,{constructor:{value:t,enumerable:!1,writable:!0,configurable:!0}}),e&&(Object.setPrototypeOf?Object.setPrototypeOf(t,e):t.__proto__=e)}Object.defineProperty(exports,"__esModule",{value:!0}),exports.default=void 0;var _wepy=require("./../npm/wepy/lib/wepy.js"),_wepy2=_interopRequireDefault(_wepy),_storage=require("./../common/storage.js"),_storage2=_interopRequireDefault(_storage),kcUpdateModle=function(t){function e(){var t,o,n,r;_classCallCheck(this,e);for(var s=arguments.length,i=Array(s),a=0;a<s;a++)i[a]=arguments[a];return o=n=_possibleConstructorReturn(this,(t=e.__proto__||Object.getPrototypeOf(e)).call.apply(t,[this].concat(i))),n.props={hasVip:{default:!1,type:Boolean},status:{default:!1,type:Boolean}},n.data={cb:null,show:!1,tips:["同学，你目前的网络状况不好","建议切换至稳定的网络环境",""],btnMsg:""},n.methods={showModal:function(t){var e=t.cb;this.show=!0,this.cb=e,this.$apply()},closeModal:function(){this.show=!1},close:function(){this.show=!1,wx.reportAnalytics("index_20_click_vipclose",{})},handleContact:function(t){wx.reportAnalytics("index_20_click_vipcontact",{}),this.show=!1,_storage2.default.set("contactBack",!0)}},n.computed={bgSrc:function(){return this.status?"../images/activate/vip_success.png":"../images/activate/vip_fail.png"}},r=o,_possibleConstructorReturn(n,r)}return _inherits(e,t),e}(_wepy2.default.component);exports.default=kcUpdateModle; 
 			}); 
		define("components/OnlineModal.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			
"use strict";function _interopRequireDefault(e){return e&&e.__esModule?e:{default:e}}function _classCallCheck(e,t){if(!(e instanceof t))throw new TypeError("Cannot call a class as a function")}function _possibleConstructorReturn(e,t){if(!e)throw new ReferenceError("this hasn't been initialised - super() hasn't been called");return!t||"object"!=typeof t&&"function"!=typeof t?e:t}function _inherits(e,t){if("function"!=typeof t&&null!==t)throw new TypeError("Super expression must either be null or a function, not "+typeof t);e.prototype=Object.create(t&&t.prototype,{constructor:{value:e,enumerable:!1,writable:!0,configurable:!0}}),t&&(Object.setPrototypeOf?Object.setPrototypeOf(e,t):e.__proto__=t)}Object.defineProperty(exports,"__esModule",{value:!0}),exports.default=void 0;var _wepy=require("./../npm/wepy/lib/wepy.js"),_wepy2=_interopRequireDefault(_wepy),_storage=require("./../common/storage.js"),_storage2=_interopRequireDefault(_storage),OnlineModal=function(e){function t(){var e,o,r,n;_classCallCheck(this,t);for(var s=arguments.length,a=Array(s),i=0;i<s;i++)a[i]=arguments[i];return o=r=_possibleConstructorReturn(this,(e=t.__proto__||Object.getPrototypeOf(t)).call.apply(e,[this].concat(a))),r.components={},r.props={show:{type:Boolean,default:!1,twoWay:!0}},r.data={},r.methods={confirmTap:function(){this.show=!1,_storage2.default.set("onlineModalShowed",!0)}},n=o,_possibleConstructorReturn(r,n)}return _inherits(t,e),t}(_wepy2.default.component);exports.default=OnlineModal; 
 			}); 
		define("components/PointTips.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			
"use strict";function _interopRequireDefault(e){return e&&e.__esModule?e:{default:e}}function _classCallCheck(e,t){if(!(e instanceof t))throw new TypeError("Cannot call a class as a function")}function _possibleConstructorReturn(e,t){if(!e)throw new ReferenceError("this hasn't been initialised - super() hasn't been called");return!t||"object"!=typeof t&&"function"!=typeof t?e:t}function _inherits(e,t){if("function"!=typeof t&&null!==t)throw new TypeError("Super expression must either be null or a function, not "+typeof t);e.prototype=Object.create(t&&t.prototype,{constructor:{value:e,enumerable:!1,writable:!0,configurable:!0}}),t&&(Object.setPrototypeOf?Object.setPrototypeOf(e,t):e.__proto__=t)}Object.defineProperty(exports,"__esModule",{value:!0}),exports.default=void 0;var _wepy=require("./../npm/wepy/lib/wepy.js"),_wepy2=_interopRequireDefault(_wepy),PointTips=function(e){function t(){var e,o,r,n;_classCallCheck(this,t);for(var i=arguments.length,s=Array(i),p=0;p<i;p++)s[p]=arguments[p];return o=r=_possibleConstructorReturn(this,(e=t.__proto__||Object.getPrototypeOf(t)).call.apply(e,[this].concat(s))),r.components={},r.props={title:{type:String,default:"先看下题目对应的考点哦，做到心里有数~"},icon:{type:String,default:"../images/learn/icon_tips.png"}},r.data={},r.methods={},n=o,_possibleConstructorReturn(r,n)}return _inherits(t,e),t}(_wepy2.default.component);exports.default=PointTips; 
 			}); 
		define("components/kcUpdateModle.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			
"use strict";function _interopRequireDefault(e){return e&&e.__esModule?e:{default:e}}function _classCallCheck(e,t){if(!(e instanceof t))throw new TypeError("Cannot call a class as a function")}function _possibleConstructorReturn(e,t){if(!e)throw new ReferenceError("this hasn't been initialised - super() hasn't been called");return!t||"object"!=typeof t&&"function"!=typeof t?e:t}function _inherits(e,t){if("function"!=typeof t&&null!==t)throw new TypeError("Super expression must either be null or a function, not "+typeof t);e.prototype=Object.create(t&&t.prototype,{constructor:{value:e,enumerable:!1,writable:!0,configurable:!0}}),t&&(Object.setPrototypeOf?Object.setPrototypeOf(e,t):e.__proto__=t)}Object.defineProperty(exports,"__esModule",{value:!0}),exports.default=void 0;var _wepy=require("./../npm/wepy/lib/wepy.js"),_wepy2=_interopRequireDefault(_wepy),kcUpdateModle=function(e){function t(){var e,o,r,n;_classCallCheck(this,t);for(var s=arguments.length,i=Array(s),c=0;c<s;c++)i[c]=arguments[c];return o=r=_possibleConstructorReturn(this,(e=t.__proto__||Object.getPrototypeOf(t)).call.apply(e,[this].concat(i))),r.props={},r.data={cb:null,show:!1,tips:["同学，你目前的网络状况不好","建议切换至稳定的网络环境",""],btnMsg:"",src:""},r.methods={showModal:function(e){var t=e.cb;this.show=!0,this.cb=t,this.$apply()},close:function(){this.show=!1,(0,this.cb)()}},n=o,_possibleConstructorReturn(r,n)}return _inherits(t,e),t}(_wepy2.default.component);exports.default=kcUpdateModle; 
 			}); 
		define("components/receiveVipModal.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			
"use strict";function _interopRequireDefault(e){return e&&e.__esModule?e:{default:e}}function _asyncToGenerator(e){return function(){var r=e.apply(this,arguments);return new Promise(function(e,t){function n(o,i){try{var a=r[o](i),c=a.value}catch(e){return void t(e)}if(!a.done)return Promise.resolve(c).then(function(e){n("next",e)},function(e){n("throw",e)});e(c)}return n("next")})}}function _classCallCheck(e,r){if(!(e instanceof r))throw new TypeError("Cannot call a class as a function")}function _possibleConstructorReturn(e,r){if(!e)throw new ReferenceError("this hasn't been initialised - super() hasn't been called");return!r||"object"!=typeof r&&"function"!=typeof r?e:r}function _inherits(e,r){if("function"!=typeof r&&null!==r)throw new TypeError("Super expression must either be null or a function, not "+typeof r);e.prototype=Object.create(r&&r.prototype,{constructor:{value:e,enumerable:!1,writable:!0,configurable:!0}}),r&&(Object.setPrototypeOf?Object.setPrototypeOf(e,r):e.__proto__=r)}function _applyDecoratedDescriptor(e,r,t,n,o){var i={};return Object.keys(n).forEach(function(e){i[e]=n[e]}),i.enumerable=!!i.enumerable,i.configurable=!!i.configurable,("value"in i||i.initializer)&&(i.writable=!0),i=t.slice().reverse().reduce(function(t,n){return n(e,r,t)||t},i),o&&void 0!==i.initializer&&(i.value=i.initializer?i.initializer.call(o):void 0,i.initializer=void 0),void 0===i.initializer&&(Object.defineProperty(e,r,i),i=null),i}Object.defineProperty(exports,"__esModule",{value:!0}),exports.default=void 0;var _createClass=function(){function e(e,r){for(var t=0;t<r.length;t++){var n=r[t];n.enumerable=n.enumerable||!1,n.configurable=!0,"value"in n&&(n.writable=!0),Object.defineProperty(e,n.key,n)}}return function(r,t,n){return t&&e(r.prototype,t),n&&e(r,n),r}}(),_dec,_desc,_value,_class,_wepy=require("./../npm/wepy/lib/wepy.js"),_wepy2=_interopRequireDefault(_wepy),_api=require("./../common/api.js"),_api2=_interopRequireDefault(_api),_decorator=require("./../common/decorator.js"),_KcLoading=require("./KcLoading.js"),_KcLoading2=_interopRequireDefault(_KcLoading),_KcErrorModal=require("./KcErrorModal.js"),_KcErrorModal2=_interopRequireDefault(_KcErrorModal),kcUpdateModle=(_dec=(0,_decorator.trycatch)(),_class=function(e){function r(){var e,t,n,o,i=this;_classCallCheck(this,r);for(var a=arguments.length,c=Array(a),s=0;s<a;s++)c[s]=arguments[s];return t=n=_possibleConstructorReturn(this,(e=r.__proto__||Object.getPrototypeOf(r)).call.apply(e,[this].concat(c))),n.props={isAuth:{default:!1,type:Boolean}},n.$repeat={},n.$props={KcLoading:{"xmlns:v-bind":"","v-bind:loadingHide.sync":"loadingHide"}},n.$events={},n.components={KcErrorModal:_KcErrorModal2.default,KcLoading:_KcLoading2.default},n.data={cb:null,show:!1,loadingHide:!0},n.methods={startAuth:function(){function e(e){return r.apply(this,arguments)}var r=_asyncToGenerator(regeneratorRuntime.mark(function e(r){return regeneratorRuntime.wrap(function(e){for(;;)switch(e.prev=e.next){case 0:n.isAuth?console.log("ok"):r.detail.errMsg.indexOf("ok")>-1&&n.loginTo();case 1:case"end":return e.stop()}},e,i)}));return e}(),showModal:function(e){var r=e.cb;this.show=!0,this.cb=r,this.$apply()},close:function(){this.show=!1,(0,this.cb)()}},o=t,_possibleConstructorReturn(n,o)}return _inherits(r,e),_createClass(r,[{key:"loginTo",value:function(){function e(){return r.apply(this,arguments)}var r=_asyncToGenerator(regeneratorRuntime.mark(function e(){var r,t,n;return regeneratorRuntime.wrap(function(e){for(;;)switch(e.prev=e.next){case 0:return e.next=2,_wepy2.default.getUserInfo();case 2:return r=e.sent,t=r.encryptedData,n=r.iv,e.next=7,_api2.default.login({encryptedData:t,iv:n});case 7:this.show=!1,this.$apply(),wx.showToast({title:"领取成功！快把这个活动分享给你的研友吧！",icon:"none",duration:3e3});case 10:case"end":return e.stop()}},e,this)}));return e}()},{key:"handleError",value:function(){function e(e){return r.apply(this,arguments)}var r=_asyncToGenerator(regeneratorRuntime.mark(function e(r){var t=this;return regeneratorRuntime.wrap(function(e){for(;;)switch(e.prev=e.next){case 0:this.loadingHide=!0,this.$apply(),this.$invoke("KcErrorModal","showModal",{err:r,btnMsg:"重新加载",cb:function(){t.loginTo()}});case 3:case"end":return e.stop()}},e,this)}));return e}()}]),r}(_wepy2.default.component),_applyDecoratedDescriptor(_class.prototype,"loginTo",[_dec],Object.getOwnPropertyDescriptor(_class.prototype,"loginTo"),_class.prototype),_class);exports.default=kcUpdateModle; 
 			}); 
		define("mixins/error.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			
"use strict";function _interopRequireDefault(e){return e&&e.__esModule?e:{default:e}}function _classCallCheck(e,t){if(!(e instanceof t))throw new TypeError("Cannot call a class as a function")}function _possibleConstructorReturn(e,t){if(!e)throw new ReferenceError("this hasn't been initialised - super() hasn't been called");return!t||"object"!=typeof t&&"function"!=typeof t?e:t}function _inherits(e,t){if("function"!=typeof t&&null!==t)throw new TypeError("Super expression must either be null or a function, not "+typeof t);e.prototype=Object.create(t&&t.prototype,{constructor:{value:e,enumerable:!1,writable:!0,configurable:!0}}),t&&(Object.setPrototypeOf?Object.setPrototypeOf(e,t):e.__proto__=t)}Object.defineProperty(exports,"__esModule",{value:!0}),exports.default=void 0;var _createClass=function(){function e(e,t){for(var r=0;r<t.length;r++){var o=t[r];o.enumerable=o.enumerable||!1,o.configurable=!0,"value"in o&&(o.writable=!0),Object.defineProperty(e,o.key,o)}}return function(t,r,o){return r&&e(t.prototype,r),o&&e(t,o),t}}(),_wepy=require("./../npm/wepy/lib/wepy.js"),_wepy2=_interopRequireDefault(_wepy),Error=function(e){function t(){var e,r,o,n;_classCallCheck(this,t);for(var i=arguments.length,s=Array(i),u=0;u<i;u++)s[u]=arguments[u];return r=o=_possibleConstructorReturn(this,(e=t.__proto__||Object.getPrototypeOf(t)).call.apply(e,[this].concat(s))),o.data={showErrorModul:!1,errorType:1,options:{}},o.events={reLoad:function(){this.onLoad(this.options),this.onShow&&this.onShow()}},n=r,_possibleConstructorReturn(o,n)}return _inherits(t,e),_createClass(t,[{key:"onLoad",value:function(e){var t=this;this.options=e,wx.onNetworkStatusChange(function(e){e.isConnected||(t.errorType=1,t.showErrorModul=!0,t.$apply())})}},{key:"onShow",value:function(){}},{key:"showError",value:function(e){e.errMsg&&e.errMsg.indexOf("fail")>=0?this.errorType=1:this.errorType=2,this.showErrorModul=!0,this.$apply()}}]),t}(_wepy2.default.mixin);exports.default=Error; 
 			}); 
		define("npm/@kc-base/kc-log/dist/kc-log.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			
!function(e,t){"object"==typeof exports&&"object"==typeof module?module.exports=t():"function"==typeof define&&define.amd?define([],t):"object"==typeof exports?exports._kcLog=t():e._kcLog=t()}(window,function(){return function(e){function t(r){if(n[r])return n[r].exports;var o=n[r]={i:r,l:!1,exports:{}};return e[r].call(o.exports,o,o.exports,t),o.l=!0,o.exports}var n={};return t.m=e,t.c=n,t.d=function(e,n,r){t.o(e,n)||Object.defineProperty(e,n,{enumerable:!0,get:r})},t.r=function(e){"undefined"!=typeof Symbol&&Symbol.toStringTag&&Object.defineProperty(e,Symbol.toStringTag,{value:"Module"}),Object.defineProperty(e,"__esModule",{value:!0})},t.t=function(e,n){if(1&n&&(e=t(e)),8&n)return e;if(4&n&&"object"==typeof e&&e&&e.__esModule)return e;var r=Object.create(null);if(t.r(r),Object.defineProperty(r,"default",{enumerable:!0,value:e}),2&n&&"string"!=typeof e)for(var o in e)t.d(r,o,function(t){return e[t]}.bind(null,o));return r},t.n=function(e){var n=e&&e.__esModule?function(){return e.default}:function(){return e};return t.d(n,"a",n),n},t.o=function(e,t){return Object.prototype.hasOwnProperty.call(e,t)},t.p="",t(t.s=46)}([function(e,t){var n=e.exports="undefined"!=typeof window&&window.Math==Math?window:"undefined"!=typeof self&&self.Math==Math?self:Function("return this")();"number"==typeof __g&&(__g=n)},function(e,t){var n=e.exports={version:"2.6.5"};"number"==typeof __e&&(__e=n)},function(e,t,n){var r=n(30)("wks"),o=n(31),i=n(0).Symbol,a="function"==typeof i;(e.exports=function(e){return r[e]||(r[e]=a&&i[e]||(a?i:o)("Symbol."+e))}).store=r},function(e,t,n){e.exports={default:n(84),__esModule:!0}},function(e,t,n){var r=n(7);e.exports=function(e){if(!r(e))throw TypeError(e+" is not an object!");return e}},function(e,t,n){var r=n(0),o=n(1),i=n(10),a=n(6),c=n(14),s=function(e,t,n){var u,f,d,l=e&s.F,p=e&s.G,g=e&s.S,v=e&s.P,h=e&s.B,m=e&s.W,w=p?o:o[t]||(o[t]={}),_=w.prototype,y=p?r:g?r[t]:(r[t]||{}).prototype;for(u in p&&(n=t),n)(f=!l&&y&&void 0!==y[u])&&c(w,u)||(d=f?y[u]:n[u],w[u]=p&&"function"!=typeof y[u]?n[u]:h&&f?i(d,r):m&&y[u]==d?function(e){var t=function(t,n,r){if(this instanceof e){switch(arguments.length){case 0:return new e;case 1:return new e(t);case 2:return new e(t,n)}return new e(t,n,r)}return e.apply(this,arguments)};return t.prototype=e.prototype,t}(d):v&&"function"==typeof d?i(Function.call,d):d,v&&((w.virtual||(w.virtual={}))[u]=d,e&s.R&&_&&!_[u]&&a(_,u,d)))};s.F=1,s.G=2,s.S=4,s.P=8,s.B=16,s.W=32,s.U=64,s.R=128,e.exports=s},function(e,t,n){var r=n(12),o=n(27);e.exports=n(8)?function(e,t,n){return r.f(e,t,o(1,n))}:function(e,t,n){return e[t]=n,e}},function(e,t){e.exports=function(e){return"object"==typeof e?null!==e:"function"==typeof e}},function(e,t,n){e.exports=!n(13)(function(){return 7!=Object.defineProperty({},"a",{get:function(){return 7}}).a})},function(e,t){e.exports={}},function(e,t,n){var r=n(11);e.exports=function(e,t,n){if(r(e),void 0===t)return e;switch(n){case 1:return function(n){return e.call(t,n)};case 2:return function(n,r){return e.call(t,n,r)};case 3:return function(n,r,o){return e.call(t,n,r,o)}}return function(){return e.apply(t,arguments)}}},function(e,t){e.exports=function(e){if("function"!=typeof e)throw TypeError(e+" is not a function!");return e}},function(e,t,n){var r=n(4),o=n(49),i=n(50),a=Object.defineProperty;t.f=n(8)?Object.defineProperty:function(e,t,n){if(r(e),t=i(t,!0),r(n),o)try{return a(e,t,n)}catch(e){}if("get"in n||"set"in n)throw TypeError("Accessors not supported!");return"value"in n&&(e[t]=n.value),e}},function(e,t){e.exports=function(e){try{return!!e()}catch(e){return!0}}},function(e,t){var n={}.hasOwnProperty;e.exports=function(e,t){return n.call(e,t)}},function(e,t){var n={}.toString;e.exports=function(e){return n.call(e).slice(8,-1)}},function(e,t,n){var r=n(7),o=n(0).document,i=r(o)&&r(o.createElement);e.exports=function(e){return i?o.createElement(e):{}}},function(e,t,n){var r=n(52),o=n(32);e.exports=Object.keys||function(e){return r(e,o)}},function(e,t,n){var r=n(28),o=n(19);e.exports=function(e){return r(o(e))}},function(e,t){e.exports=function(e){if(null==e)throw TypeError("Can't call method on  "+e);return e}},function(e,t){var n=Math.ceil,r=Math.floor;e.exports=function(e){return isNaN(e=+e)?0:(e>0?r:n)(e)}},function(e,t,n){var r=n(30)("keys"),o=n(31);e.exports=function(e){return r[e]||(r[e]=o(e))}},function(e,t){e.exports=!0},function(e,t,n){var r=n(19);e.exports=function(e){return Object(r(e))}},function(e,t,n){var r=n(12).f,o=n(14),i=n(2)("toStringTag");e.exports=function(e,t,n){e&&!o(e=n?e:e.prototype,i)&&r(e,i,{configurable:!0,value:t})}},function(e,t,n){"use strict";function r(e){var t,n;this.promise=new e(function(e,r){if(void 0!==t||void 0!==n)throw TypeError("Bad Promise constructor");t=e,n=r}),this.resolve=o(t),this.reject=o(n)}var o=n(11);e.exports.f=function(e){return new r(e)}},function(e,t,n){e.exports={default:n(57),__esModule:!0}},function(e,t){e.exports=function(e,t){return{enumerable:!(1&e),configurable:!(2&e),writable:!(4&e),value:t}}},function(e,t,n){var r=n(15);e.exports=Object("z").propertyIsEnumerable(0)?Object:function(e){return"String"==r(e)?e.split(""):Object(e)}},function(e,t,n){var r=n(20),o=Math.min;e.exports=function(e){return e>0?o(r(e),9007199254740991):0}},function(e,t,n){var r=n(1),o=n(0),i=o["__core-js_shared__"]||(o["__core-js_shared__"]={});(e.exports=function(e,t){return i[e]||(i[e]=void 0!==t?t:{})})("versions",[]).push({version:r.version,mode:n(22)?"pure":"global",copyright:"© 2019 Denis Pushkarev (zloirock.ru)"})},function(e,t){var n=0,r=Math.random();e.exports=function(e){return"Symbol(".concat(void 0===e?"":e,")_",(++n+r).toString(36))}},function(e,t){e.exports="constructor,hasOwnProperty,isPrototypeOf,propertyIsEnumerable,toLocaleString,toString,valueOf".split(",")},function(e,t,n){"use strict";var r=n(62)(!0);n(34)(String,"String",function(e){this._t=String(e),this._i=0},function(){var e,t=this._t,n=this._i;return n>=t.length?{value:void 0,done:!0}:(e=r(t,n),this._i+=e.length,{value:e,done:!1})})},function(e,t,n){"use strict";var r=n(22),o=n(5),i=n(63),a=n(6),c=n(9),s=n(64),u=n(24),f=n(67),d=n(2)("iterator"),l=!([].keys&&"next"in[].keys()),p=function(){return this};e.exports=function(e,t,n,g,v,h,m){s(n,t,g);var w,_,y,b=function(e){if(!l&&e in L)return L[e];switch(e){case"keys":case"values":return function(){return new n(this,e)}}return function(){return new n(this,e)}},x=t+" Iterator",k="values"==v,S=!1,L=e.prototype,P=L[d]||L["@@iterator"]||v&&L[v],O=P||b(v),T=v?k?b("entries"):O:void 0,M="Array"==t&&L.entries||P;if(M&&(y=f(M.call(new e)))!==Object.prototype&&y.next&&(u(y,x,!0),r||"function"==typeof y[d]||a(y,d,p)),k&&P&&"values"!==P.name&&(S=!0,O=function(){return P.call(this)}),r&&!m||!l&&!S&&L[d]||a(L,d,O),c[t]=O,c[x]=p,v)if(w={values:k?O:b("values"),keys:h?O:b("keys"),entries:T},m)for(_ in w)_ in L||i(L,_,w[_]);else o(o.P+o.F*(l||S),t,w);return w}},function(e,t,n){var r=n(0).document;e.exports=r&&r.documentElement},function(e,t,n){n(68);for(var r=n(0),o=n(6),i=n(9),a=n(2)("toStringTag"),c="CSSRuleList,CSSStyleDeclaration,CSSValueList,ClientRectList,DOMRectList,DOMStringList,DOMTokenList,DataTransferItemList,FileList,HTMLAllCollection,HTMLCollection,HTMLFormElement,HTMLSelectElement,MediaList,MimeTypeArray,NamedNodeMap,NodeList,PaintRequestList,Plugin,PluginArray,SVGLengthList,SVGNumberList,SVGPathSegList,SVGPointList,SVGStringList,SVGTransformList,SourceBufferList,StyleSheetList,TextTrackCueList,TextTrackList,TouchList".split(","),s=0;s<c.length;s++){var u=c[s],f=r[u],d=f&&f.prototype;d&&!d[a]&&o(d,a,u),i[u]=i.Array}},function(e,t,n){var r=n(15),o=n(2)("toStringTag"),i="Arguments"==r(function(){return arguments}());e.exports=function(e){var t,n,a;return void 0===e?"Undefined":null===e?"Null":"string"==typeof(n=function(e,t){try{return e[t]}catch(e){}}(t=Object(e),o))?n:i?r(t):"Object"==(a=r(t))&&"function"==typeof t.callee?"Arguments":a}},function(e,t,n){var r=n(37),o=n(2)("iterator"),i=n(9);e.exports=n(1).getIteratorMethod=function(e){if(null!=e)return e[o]||e["@@iterator"]||i[r(e)]}},function(e,t,n){var r=n(4),o=n(11),i=n(2)("species");e.exports=function(e,t){var n,a=r(e).constructor;return void 0===a||null==(n=r(a)[i])?t:o(n)}},function(e,t,n){var r,o,i,a=n(10),c=n(76),s=n(35),u=n(16),f=n(0),d=f.process,l=f.setImmediate,p=f.clearImmediate,g=f.MessageChannel,v=f.Dispatch,h=0,m={},w=function(){var e=+this;if(m.hasOwnProperty(e)){var t=m[e];delete m[e],t()}},_=function(e){w.call(e.data)};l&&p||(l=function(e){for(var t=[],n=1;arguments.length>n;)t.push(arguments[n++]);return m[++h]=function(){c("function"==typeof e?e:Function(e),t)},r(h),h},p=function(e){delete m[e]},"process"==n(15)(d)?r=function(e){d.nextTick(a(w,e,1))}:v&&v.now?r=function(e){v.now(a(w,e,1))}:g?(i=(o=new g).port2,o.port1.onmessage=_,r=a(i.postMessage,i,1)):f.addEventListener&&"function"==typeof postMessage&&!f.importScripts?(r=function(e){f.postMessage(e+"","*")},f.addEventListener("message",_,!1)):r="onreadystatechange"in u("script")?function(e){s.appendChild(u("script")).onreadystatechange=function(){s.removeChild(this),w.call(e)}}:function(e){setTimeout(a(w,e,1),0)}),e.exports={set:l,clear:p}},function(e,t){e.exports=function(e){try{return{e:!1,v:e()}}catch(e){return{e:!0,v:e}}}},function(e,t,n){var r=n(4),o=n(7),i=n(25);e.exports=function(e,t){if(r(e),o(t)&&t.constructor===e)return t;var n=i.f(e);return(0,n.resolve)(t),n.promise}},function(e,t,n){e.exports={default:n(47),__esModule:!0}},function(e,t,n){e.exports={default:n(60),__esModule:!0}},function(e,t,n){e.exports={default:n(85),__esModule:!0}},function(e,t,n){e.exports=n(87)},function(e,t,n){n(48),e.exports=n(1).Object.assign},function(e,t,n){var r=n(5);r(r.S+r.F,"Object",{assign:n(51)})},function(e,t,n){e.exports=!n(8)&&!n(13)(function(){return 7!=Object.defineProperty(n(16)("div"),"a",{get:function(){return 7}}).a})},function(e,t,n){var r=n(7);e.exports=function(e,t){if(!r(e))return e;var n,o;if(t&&"function"==typeof(n=e.toString)&&!r(o=n.call(e)))return o;if("function"==typeof(n=e.valueOf)&&!r(o=n.call(e)))return o;if(!t&&"function"==typeof(n=e.toString)&&!r(o=n.call(e)))return o;throw TypeError("Can't convert object to primitive value")}},function(e,t,n){"use strict";var r=n(17),o=n(55),i=n(56),a=n(23),c=n(28),s=Object.assign;e.exports=!s||n(13)(function(){var e={},t={},n=Symbol(),r="abcdefghijklmnopqrst";return e[n]=7,r.split("").forEach(function(e){t[e]=e}),7!=s({},e)[n]||Object.keys(s({},t)).join("")!=r})?function(e,t){for(var n=a(e),s=arguments.length,u=1,f=o.f,d=i.f;s>u;)for(var l,p=c(arguments[u++]),g=f?r(p).concat(f(p)):r(p),v=g.length,h=0;v>h;)d.call(p,l=g[h++])&&(n[l]=p[l]);return n}:s},function(e,t,n){var r=n(14),o=n(18),i=n(53)(!1),a=n(21)("IE_PROTO");e.exports=function(e,t){var n,c=o(e),s=0,u=[];for(n in c)n!=a&&r(c,n)&&u.push(n);for(;t.length>s;)r(c,n=t[s++])&&(~i(u,n)||u.push(n));return u}},function(e,t,n){var r=n(18),o=n(29),i=n(54);e.exports=function(e){return function(t,n,a){var c,s=r(t),u=o(s.length),f=i(a,u);if(e&&n!=n){for(;u>f;)if((c=s[f++])!=c)return!0}else for(;u>f;f++)if((e||f in s)&&s[f]===n)return e||f||0;return!e&&-1}}},function(e,t,n){var r=n(20),o=Math.max,i=Math.min;e.exports=function(e,t){return(e=r(e))<0?o(e+t,0):i(e,t)}},function(e,t){t.f=Object.getOwnPropertySymbols},function(e,t){t.f={}.propertyIsEnumerable},function(e,t,n){n(58),e.exports=n(1).Object.keys},function(e,t,n){var r=n(23),o=n(17);n(59)("keys",function(){return function(e){return o(r(e))}})},function(e,t,n){var r=n(5),o=n(1),i=n(13);e.exports=function(e,t){var n=(o.Object||{})[e]||Object[e],a={};a[e]=t(n),r(r.S+r.F*i(function(){n(1)}),"Object",a)}},function(e,t,n){n(61),n(33),n(36),n(71),n(82),n(83),e.exports=n(1).Promise},function(e,t){},function(e,t,n){var r=n(20),o=n(19);e.exports=function(e){return function(t,n){var i,a,c=String(o(t)),s=r(n),u=c.length;return s<0||s>=u?e?"":void 0:(i=c.charCodeAt(s))<55296||i>56319||s+1===u||(a=c.charCodeAt(s+1))<56320||a>57343?e?c.charAt(s):i:e?c.slice(s,s+2):a-56320+(i-55296<<10)+65536}}},function(e,t,n){e.exports=n(6)},function(e,t,n){"use strict";var r=n(65),o=n(27),i=n(24),a={};n(6)(a,n(2)("iterator"),function(){return this}),e.exports=function(e,t,n){e.prototype=r(a,{next:o(1,n)}),i(e,t+" Iterator")}},function(e,t,n){var r=n(4),o=n(66),i=n(32),a=n(21)("IE_PROTO"),c=function(){},s=function(){var e,t=n(16)("iframe"),r=i.length;for(t.style.display="none",n(35).appendChild(t),t.src="javascript:",(e=t.contentWindow.document).open(),e.write("<script>document.F=Object<\/script>"),e.close(),s=e.F;r--;)delete s.prototype[i[r]];return s()};e.exports=Object.create||function(e,t){var n;return null!==e?(c.prototype=r(e),n=new c,c.prototype=null,n[a]=e):n=s(),void 0===t?n:o(n,t)}},function(e,t,n){var r=n(12),o=n(4),i=n(17);e.exports=n(8)?Object.defineProperties:function(e,t){o(e);for(var n,a=i(t),c=a.length,s=0;c>s;)r.f(e,n=a[s++],t[n]);return e}},function(e,t,n){var r=n(14),o=n(23),i=n(21)("IE_PROTO"),a=Object.prototype;e.exports=Object.getPrototypeOf||function(e){return e=o(e),r(e,i)?e[i]:"function"==typeof e.constructor&&e instanceof e.constructor?e.constructor.prototype:e instanceof Object?a:null}},function(e,t,n){"use strict";var r=n(69),o=n(70),i=n(9),a=n(18);e.exports=n(34)(Array,"Array",function(e,t){this._t=a(e),this._i=0,this._k=t},function(){var e=this._t,t=this._k,n=this._i++;return!e||n>=e.length?(this._t=void 0,o(1)):o(0,"keys"==t?n:"values"==t?e[n]:[n,e[n]])},"values"),i.Arguments=i.Array,r("keys"),r("values"),r("entries")},function(e,t){e.exports=function(){}},function(e,t){e.exports=function(e,t){return{value:t,done:!!e}}},function(e,t,n){"use strict";var r,o,i,a,c=n(22),s=n(0),u=n(10),f=n(37),d=n(5),l=n(7),p=n(11),g=n(72),v=n(73),h=n(39),m=n(40).set,w=n(77)(),_=n(25),y=n(41),b=n(78),x=n(42),k=s.TypeError,S=s.process,L=S&&S.versions,P=L&&L.v8||"",O=s.Promise,T="process"==f(S),M=function(){},E=o=_.f,j=!!function(){try{var e=O.resolve(1),t=(e.constructor={})[n(2)("species")]=function(e){e(M,M)};return(T||"function"==typeof PromiseRejectionEvent)&&e.then(M)instanceof t&&0!==P.indexOf("6.6")&&-1===b.indexOf("Chrome/66")}catch(e){}}(),C=function(e){var t;return!(!l(e)||"function"!=typeof(t=e.then))&&t},N=function(e,t){if(!e._n){e._n=!0;var n=e._c;w(function(){for(var r=e._v,o=1==e._s,i=0;n.length>i;)!function(t){var n,i,a,c=o?t.ok:t.fail,s=t.resolve,u=t.reject,f=t.domain;try{c?(o||(2==e._h&&q(e),e._h=1),!0===c?n=r:(f&&f.enter(),n=c(r),f&&(f.exit(),a=!0)),n===t.promise?u(k("Promise-chain cycle")):(i=C(n))?i.call(n,s,u):s(n)):u(r)}catch(e){f&&!a&&f.exit(),u(e)}}(n[i++]);e._c=[],e._n=!1,t&&!e._h&&A(e)})}},A=function(e){m.call(s,function(){var t,n,r,o=e._v,i=R(e);if(i&&(t=y(function(){T?S.emit("unhandledRejection",o,e):(n=s.onunhandledrejection)?n({promise:e,reason:o}):(r=s.console)&&r.error&&r.error("Unhandled promise rejection",o)}),e._h=T||R(e)?2:1),e._a=void 0,i&&t.e)throw t.v})},R=function(e){return 1!==e._h&&0===(e._a||e._c).length},q=function(e){m.call(s,function(){var t;T?S.emit("rejectionHandled",e):(t=s.onrejectionhandled)&&t({promise:e,reason:e._v})})},I=function(e){var t=this;t._d||(t._d=!0,(t=t._w||t)._v=e,t._s=2,t._a||(t._a=t._c.slice()),N(t,!0))},V=function(e){var t,n=this;if(!n._d){n._d=!0,n=n._w||n;try{if(n===e)throw k("Promise can't be resolved itself");(t=C(e))?w(function(){var r={_w:n,_d:!1};try{t.call(e,u(V,r,1),u(I,r,1))}catch(e){I.call(r,e)}}):(n._v=e,n._s=1,N(n,!1))}catch(e){I.call({_w:n,_d:!1},e)}}};j||(O=function(e){g(this,O,"Promise","_h"),p(e),r.call(this);try{e(u(V,this,1),u(I,this,1))}catch(e){I.call(this,e)}},(r=function(e){this._c=[],this._a=void 0,this._s=0,this._d=!1,this._v=void 0,this._h=0,this._n=!1}).prototype=n(79)(O.prototype,{then:function(e,t){var n=E(h(this,O));return n.ok="function"!=typeof e||e,n.fail="function"==typeof t&&t,n.domain=T?S.domain:void 0,this._c.push(n),this._a&&this._a.push(n),this._s&&N(this,!1),n.promise},catch:function(e){return this.then(void 0,e)}}),i=function(){var e=new r;this.promise=e,this.resolve=u(V,e,1),this.reject=u(I,e,1)},_.f=E=function(e){return e===O||e===a?new i(e):o(e)}),d(d.G+d.W+d.F*!j,{Promise:O}),n(24)(O,"Promise"),n(80)("Promise"),a=n(1).Promise,d(d.S+d.F*!j,"Promise",{reject:function(e){var t=E(this);return(0,t.reject)(e),t.promise}}),d(d.S+d.F*(c||!j),"Promise",{resolve:function(e){return x(c&&this===a?O:this,e)}}),d(d.S+d.F*!(j&&n(81)(function(e){O.all(e).catch(M)})),"Promise",{all:function(e){var t=this,n=E(t),r=n.resolve,o=n.reject,i=y(function(){var n=[],i=0,a=1;v(e,!1,function(e){var c=i++,s=!1;n.push(void 0),a++,t.resolve(e).then(function(e){s||(s=!0,n[c]=e,--a||r(n))},o)}),--a||r(n)});return i.e&&o(i.v),n.promise},race:function(e){var t=this,n=E(t),r=n.reject,o=y(function(){v(e,!1,function(e){t.resolve(e).then(n.resolve,r)})});return o.e&&r(o.v),n.promise}})},function(e,t){e.exports=function(e,t,n,r){if(!(e instanceof t)||void 0!==r&&r in e)throw TypeError(n+": incorrect invocation!");return e}},function(e,t,n){var r=n(10),o=n(74),i=n(75),a=n(4),c=n(29),s=n(38),u={},f={};(t=e.exports=function(e,t,n,d,l){var p,g,v,h,m=l?function(){return e}:s(e),w=r(n,d,t?2:1),_=0;if("function"!=typeof m)throw TypeError(e+" is not iterable!");if(i(m)){for(p=c(e.length);p>_;_++)if((h=t?w(a(g=e[_])[0],g[1]):w(e[_]))===u||h===f)return h}else for(v=m.call(e);!(g=v.next()).done;)if((h=o(v,w,g.value,t))===u||h===f)return h}).BREAK=u,t.RETURN=f},function(e,t,n){var r=n(4);e.exports=function(e,t,n,o){try{return o?t(r(n)[0],n[1]):t(n)}catch(t){var i=e.return;throw void 0!==i&&r(i.call(e)),t}}},function(e,t,n){var r=n(9),o=n(2)("iterator"),i=Array.prototype;e.exports=function(e){return void 0!==e&&(r.Array===e||i[o]===e)}},function(e,t){e.exports=function(e,t,n){var r=void 0===n;switch(t.length){case 0:return r?e():e.call(n);case 1:return r?e(t[0]):e.call(n,t[0]);case 2:return r?e(t[0],t[1]):e.call(n,t[0],t[1]);case 3:return r?e(t[0],t[1],t[2]):e.call(n,t[0],t[1],t[2]);case 4:return r?e(t[0],t[1],t[2],t[3]):e.call(n,t[0],t[1],t[2],t[3])}return e.apply(n,t)}},function(e,t,n){var r=n(0),o=n(40).set,i=r.MutationObserver||r.WebKitMutationObserver,a=r.process,c=r.Promise,s="process"==n(15)(a);e.exports=function(){var e,t,n,u=function(){var r,o;for(s&&(r=a.domain)&&r.exit();e;){o=e.fn,e=e.next;try{o()}catch(r){throw e?n():t=void 0,r}}t=void 0,r&&r.enter()};if(s)n=function(){a.nextTick(u)};else if(!i||r.navigator&&r.navigator.standalone)if(c&&c.resolve){var f=c.resolve(void 0);n=function(){f.then(u)}}else n=function(){o.call(r,u)};else{var d=!0,l=document.createTextNode("");new i(u).observe(l,{characterData:!0}),n=function(){l.data=d=!d}}return function(r){var o={fn:r,next:void 0};t&&(t.next=o),e||(e=o,n()),t=o}}},function(e,t,n){var r=n(0).navigator;e.exports=r&&r.userAgent||""},function(e,t,n){var r=n(6);e.exports=function(e,t,n){for(var o in t)n&&e[o]?e[o]=t[o]:r(e,o,t[o]);return e}},function(e,t,n){"use strict";var r=n(0),o=n(1),i=n(12),a=n(8),c=n(2)("species");e.exports=function(e){var t="function"==typeof o[e]?o[e]:r[e];a&&t&&!t[c]&&i.f(t,c,{configurable:!0,get:function(){return this}})}},function(e,t,n){var r=n(2)("iterator"),o=!1;try{var i=[7][r]();i.return=function(){o=!0},Array.from(i,function(){throw 2})}catch(e){}e.exports=function(e,t){if(!t&&!o)return!1;var n=!1;try{var i=[7],a=i[r]();a.next=function(){return{done:n=!0}},i[r]=function(){return a},e(i)}catch(e){}return n}},function(e,t,n){"use strict";var r=n(5),o=n(1),i=n(0),a=n(39),c=n(42);r(r.P+r.R,"Promise",{finally:function(e){var t=a(this,o.Promise||i.Promise),n="function"==typeof e;return this.then(n?function(n){return c(t,e()).then(function(){return n})}:e,n?function(n){return c(t,e()).then(function(){throw n})}:e)}})},function(e,t,n){"use strict";var r=n(5),o=n(25),i=n(41);r(r.S,"Promise",{try:function(e){var t=o.f(this),n=i(e);return(n.e?t.reject:t.resolve)(n.v),t.promise}})},function(e,t,n){var r=n(1),o=r.JSON||(r.JSON={stringify:JSON.stringify});e.exports=function(e){return o.stringify.apply(o,arguments)}},function(e,t,n){n(36),n(33),e.exports=n(86)},function(e,t,n){var r=n(4),o=n(38);e.exports=n(1).getIterator=function(e){var t=o(e);if("function"!=typeof t)throw TypeError(e+" is not iterable!");return r(t.call(e))}},function(e,t,n){"use strict";function r(e){try{e=JSON.parse(e)}catch(e){console.error("NA params format error.")}x.device_id||_(x,e)}n.r(t);var o=n(43),i=n.n(o),a=n(26),c=n.n(a),s=n(44),u=n.n(s),f=n(3),d=n.n(f),l=n(45),p=n.n(l),g={isArray:function(e){return!!e&&"[object Array]"===Object.prototype.toString.call(e)},isPlainObject:function(e){return!!e&&"[object Object]"===Object.prototype.toString.call(e)},isEmptyObject:function(e){var t;for(t in e)return!1;return!0},type:function(e){return null==e?e+"":Object.prototype.toString.call(e).slice(8,-1).toLowerCase()},queryToJson:function(e,t){function n(e){var n=e;if(t)try{n=decodeURIComponent(e)}catch(e){}return n}e=(e||window.location.href.replace(window.location.hash,""))+"",t="boolean"!=typeof t||t;for(var r={},o=e.substr(e.lastIndexOf("?")+1).split("&"),i=0;i<o.length;++i)if(o[i]){var a=o[i].split("=");if(a.length>1){var c=a[0],s=a[1];void 0===r[c]?r[c]=n(s):(g.isArray(r[c])||(r[c]=[r[c]]),r[c].push(n(s)))}}return r},jsonToQuery:function(e,t){function n(e,r){var o;switch(g.type(r)){case"boolean":case"number":case"string":o=e+"="+(t?encodeURIComponent(r):r);break;case"regexp":o=e+"="+(t?encodeURIComponent(r.source):r.source);break;case"date":o=e+"="+r.getTime();break;case"array":o=[];for(var i=0;i<r.length;++i)/^boolean|number|string|regexp|date$/.test(g.type(r[i]))&&o.push(n(e,r[i]));break;default:o=void 0}return o}t="boolean"!=typeof t||t;var r=[];if("object"==g.type(e)&&g.isPlainObject(e))for(var o in e){var i=n(o,e[o]);i&&(r=r.concat(i))}return r.join("&")},getQuery:function(e,t){e=e?e+"":"",t=t||window.location.href.replace(window.location.hash,"");var n=g.queryToJson(t);return e?n[e]||"":g.isEmptyObject(n)?"":n},setQuery:function(e,t,n){var r="";if(e){var o,i={},a="";switch(g.type(e)){case"string":case"number":n=(n||window.location.href)+"",(e+="")&&(i[e]=t);break;case"object":n=(t||window.location.href)+"",i=e}for(var c in/(#.+)$/i.test(n)&&(a=RegExp.$1,n=n.replace(a,"")),o=g.queryToJson(n),i)o[c]=i[c];for(var c in i)null==i[c]&&delete o[c];r=g.jsonToQuery(o)+a}return r}},v=g,h=navigator&&navigator.userAgent||"",m={chrome:function(){return/\b(?:Chrome|CriOS)\/(\d+)/i.test(h)?+RegExp.$1:void 0},firefox:function(){return/\bFirefox\/(\d+)/i.test(h)?+RegExp.$1:void 0},opera:function(){return/\bOpera\/(\d+)/i.test(h)?+RegExp.$1:void 0},ie:function(){return/\b(?:MSIE |rv:|Edge\/)(\d+)/i.test(h)&&!this.firefox()?document.documentMode||+RegExp.$1:void 0},edge:function(){return/\bEdge\/(\d+)/i.test(h)?document.documentMode||+RegExp.$1:void 0},safari:function(){return/\bSafari\/?(\d+)?/i.test(h)&&!/chrome/i.test(h)?+(/\bVersion\/?([\d\.]+)?/i.exec(h)&&/\bVersion\/?([\d\.]+)?/i.exec(h)[1]||RegExp.$1):void 0},lb:function(){return/lbbrowser/.test(h.toLowerCase())},qq:function(){return/tencenttraveler|qqbrowser|qq/.test(h.toLowerCase())},baidu:function(){return/bidubrowser\/(\d+)/i.test(h.toLowerCase())?+RegExp.$1:void 0},sogo:function(){return/metasr (\d+)/i.test(h.toLowerCase())?+RegExp.$1:void 0},uc:function(){return/ucweb|ubrowser\/(\d+)/i.test(h.toLowerCase())?+RegExp.$1:void 0},isStandard:function(){return"CSS1Compat"==document.compatMode},isGecko:function(){return/gecko/i.test(h)&&!/like gecko/i.test(h)},isWebkit:function(){return/webkit/i.test(h)},isNativeMiniProgram:function(){var e=!1;try{e=!!wx}catch(t){e=!1}return!!e&&!!wx.request},isMiniProgram:function(){var e=!1;try{e=!!wx}catch(t){e=!1}return!(!e||!wx.request&&!/miniProgram/i.test(h))},pt:function(){return this.isMiniProgram()?"mini":/(iphone)|(ipad)|(android)|(phone)/g.test(h.toLowerCase())?/KaochongApp/g.test(h)?"app":"wap":"web"},os:function(){var e="other";return/\bMac/i.test(h)?e=/iPhone/i.test(h)?"iphone os_"+(/iPhone OS (\d+(?:_\d+)?)/i.test(h)?RegExp.$1.replace("_","."):"unknown"):/iPad/i.test(h)?"ipad os_"+(/iPad.*OS (\d+(?:_\d+)?)/i.test(h)?RegExp.$1.replace("_","."):"unknown"):"mac os_"+(/Mac OS X (\d+(?:_\d+)?)/i.test(h)?RegExp.$1.replace("_","."):"unknown"):/Android/i.test(h)?e="android os_"+(/Android (\d+(?:\.\d+)?)/i.test(h)?RegExp.$1:"unknown"):/\bWindows/i.test(h)&&(e="windows os_"+(/Windows NT (\d+)/i.test(h)?RegExp.$1:"unknown")+"_"+(/win64|x64|wow64/i.test(h)?"64":"32")+"bit"),e},osVersion:function(){var e="other";return/\bMac/i.test(h)?e=/iPhone/i.test(h)?/iPhone OS (\d+(?:_\d+)?)/i.test(h)?RegExp.$1.replace("_","."):"unknown":/iPad/i.test(h)?/iPad.*OS (\d+(?:_\d+)?)/i.test(h)?RegExp.$1.replace("_","."):"unknown":/Mac OS X (\d+(?:_\d+)?)/i.test(h)?RegExp.$1.replace("_","."):"unknown":/Android/i.test(h)?e=/Android (\d+(?:\.\d+)?)/i.test(h)?RegExp.$1:"unknown":/\bWindows/i.test(h)&&(e=(/Windows NT (\d+)/i.test(h)?RegExp.$1:"unknown")+"_"+(/win64|x64|wow64/i.test(h)?"64":"32")+"bit"),e},version:function(){var e="unknown";return this.baidu()?e="baidu_"+this.baidu():this.sogo()?e="sogo_"+this.sogo():this.uc()?e="uc_"+this.uc():this.edge()?e="edge_"+this.edge():this.ie()?e="ie_"+this.ie():this.chrome()?e="chrome_"+this.chrome():this.opera()?e="opera_"+this.opera():this.safari()?e="safari_"+this.safari():this.firefox()&&(e="firefox_"+this.firefox()),e},type:function(){var e="other";return this.lb()?e="lb":this.qq()?e="qq":this.baidu()?e="baidu":this.sogo()?e="sogo":this.uc()?e="uc":this.edge()?e="edge":this.ie()?e="ie":this.chrome()?e="chrome":this.safari()?e="safari":this.firefox()?e="firefox":this.opera()?e="opera":this.isMiniProgram()&&(e="mini"),e}},w={get:function(e){var t=""+document.cookie,n=t.indexOf(e);if(-1===n||""===e)return"";var r=t.indexOf("; ",n);return-1===r&&(r=t.length),unescape(t.substring(n+e.length+1,r))},set:function(e,t,n,r){var o=new Date,i=new Date;r=r||1,i.setTime(o.getTime()+36e5*r*24*30),document.cookie=n?e+"="+escape(t)+"; domain="+n+"; path=/; expires="+i.toGMTString():e+"="+escape(t)+"; path=/; expires="+i.toGMTString()},remove:function(e){var t=new Date;t.setTime(-1e3),document.cookie=e+"=; expires="+t.toGMTString()},clear:function(){var e=new Date;e.setTime(-1e3);for(var t=document.cookie.split("; "),n=0;n<t.length;n++){var r=t[n].split("=");document.cookie=r[0]+"=; expires="+e.toGMTString()}}},_=i.a||function(e){for(var t=1;t<arguments.length;t++){var n=arguments[t];for(var r in n)Object.prototype.hasOwnProperty.call(n,r)&&(e[r]=n[r])}return e},y=navigator&&navigator.userAgent||"",b={},x={u_id:"",device_id:"",app_version:"",ip:"",imei:"",bundleid:m.isNativeMiniProgram()&&wx.getStorageSync&&wx.getStorageSync("bdId")||v.getQuery("bdId"),manufacturer:"",model:"",wifi:"",carrier:"",network_type:""},k={},S=[],L={Timer:null,totalTimeSecond:"",getLastVendor:!0},P=m.edge(),O=0,T="",M={setStorage:function(e,t){window&&window.localStorage&&!M.isPrivateMode()?(window.localStorage.setItem(e,t),["__kc_log_keel","refreshRemainTime"].indexOf(e)>=0&&m.isMiniProgram()&&wx.miniProgram.postMessage({data:{__kc_log_keel:t}})):m.isNativeMiniProgram()?wx.setStorageSync(e,t):w.set(e,t)},getStorage:function(e){return window&&window.localStorage&&!M.isPrivateMode()?window.localStorage.getItem(e):m.isNativeMiniProgram()?wx.getStorageSync(e):w.get(e)},isPrivateMode:function(){try{return localStorage.setItem("tryStorage","test"),!1}catch(e){return!0}},queryToObj:function(){var e={};if(location&&""!==location.search){var t=location.search.slice(1).split("&"),n=!0,r=!1,o=void 0;try{for(var i,a=p()(t);!(n=(i=a.next()).done);n=!0){var c=i.value;e[c.split("=")[0]]=c.split("=")[1]}}catch(e){r=!0,o=e}finally{try{!n&&a.return&&a.return()}finally{if(r)throw o}}}return e},resetTime:function(){var e=!1;L.getLastVendor=!1;var t=M.queryToObj();if("{}"!==d()(t))for(var n in t)/kcm_|c/.test(n)&&t[n]&&(e=!0);(e||m.isNativeMiniProgram())&&(L.totalTimeSecond=28800,M.setStorage("refreshRemainTime",L.totalTimeSecond),M.handleTimeMinus())},initTime:function(){var e=M.getStorage("refreshRemainTime");null!==e&&e>0?(L.totalTimeSecond=e,M.handleTimeMinus()):M.resetTime()},handleTimeMinus:function(){L.Timer=setInterval(function(){L.totalTimeSecond>0?L.totalTimeSecond--:(clearInterval(L.Timer),L.getLastVendor=!1,M.setStorage("refreshRemainTime",L.totalTimeSecond))},1e3)},getKcVersion:function(){var e=/kaochongapp\/([\d\.]+)/g.exec(window.navigator.userAgent.toLocaleLowerCase());return e&&e[1]||null},isOldVersion:function(){var e=M.getKcVersion()&&M.getKcVersion().split(".")||[];return e[0]<2||e[0]<=2&&e[1]<3},buildBridge:function(e){var t=document.createElement("iframe");t.setAttribute("style","display:none;"),t.setAttribute("height","0"),t.setAttribute("width","0"),t.setAttribute("frameborder","0"),t.setAttribute("src",e),document.documentElement.appendChild(t)},getNaData:function(){var e=M.platform();try{if("kaochong"===e)if(M.isOldVersion())/iphone|ipad|ipod/.test(y.toLocaleLowerCase())?window.webkit.messageHandlers&&window.webkit.messageHandlers.getKaoChongData&&window.webkit.messageHandlers.getKaoChongData.postMessage('{"type":"getAppInfo","callback":"window.initNaData"}'):/android/.test(y.toLocaleLowerCase())&&window.kaochong&&window.kaochong.getData&&window.kaochong.getData('{"type":"getAppInfo","callback":"window.initNaData"}');else{var t="kaochong://webviewmessage?action="+encodeURIComponent('{"action":"getAppInfo","extra":{"callback":"window.initNaData"}}');M.buildBridge(t)}else"kc_word"===e?/iphone|ipad|ipod/.test(y.toLocaleLowerCase())?window.addEventListener("flutterInAppWebViewPlatformReady",function(e){window.flutter_inappwebview&&window.flutter_inappwebview.callHandler&&window.flutter_inappwebview.callHandler("kaochong",d()({action:"getAppInfo",extra:{callback:"window.initNaData"}}))}):/android/.test(y.toLocaleLowerCase())&&(t='kaochongword://kaochongword?action={"action":"getAppInfo","extra":{"callback":"window.initNaData"}}',M.buildBridge(t)):"kc_answer"===e&&(t="kuaidaan://webviewmessage?action="+encodeURIComponent('{"action":"getAppInfo","extra":{"callback":"window.initNaData"}}'),M.buildBridge(t))}catch(e){console.error(d()(e))}},initCommonData:function(){var e={},t={};if(m.isNativeMiniProgram())try{e=wx.getSystemInfoSync(),t=wx.getStorageSync("userInfo")}catch(e){console.error(new Error("[wechat error] Can not get the device info"))}return{u_id:"",device_id:"",app_version:"",ip:"",imei:"",bundleid:m.isNativeMiniProgram()&&wx.getStorageSync&&wx.getStorageSync("bdId")||v.getQuery("bdId"),pt:m.pt(),manufacturer:e.brand||"",model:e.model||"",os:m.os(),os_version:m.osVersion(),screen_width:e.screenWidth||screen.width||0,screen_height:e.screenHeight||screen.height||0,wifi:"",UA:navigator&&navigator.userAgent,browser:m.type(),browser_version:m.version(),carrier:"",network_type:"",platform:M.platform(),url:location&&location.href,dot_version:2,kc_token:t.token}},platform:function(){return/micromessenger/gi.test(y)?"wechat":/weibo/gi.test(y)?"weibo":/bili/gi.test(y)?"bilibili":/aweme/gi.test(y)?"douyin":/kaochongapp/gi.test(y)?"kaochong":/kaochongdanciapp/gi.test(y)?"kc_word":/kuaidaanapp/gi.test(y)?"kc_answer":/ganweixueyuanapp/gi.test(y)?"kc_ganwei":/kaochongjiaoziapp/gi.test(y)?"kc_jiaozi":/qqbrowser/gi.test(y)?"qqbrowser":m.type()},getLatestReferrer:function(){var e=document&&document.referrer;if(!/xuanke\.com|kaochong\.com/g.test(e))return e},updateLogKeel:function(e,t){for(var n=!0,r={pagename:e.pagename,url:location.href,courseid:e.courseid||"",skuid:e.skuid||""},o=t.length&&t[t.length-2]||{},i=0,a=t.length;i<a;i++)if(t[i]&&t[i].pagename==e.pagename&&t[i].url==r.url){n=!1;break}for(var i in n?(r.firstrefer=e.firstrefer&&e.firstrefer.value||o.firstrefer,t.push(_({},r,k))):t=t.slice(0,i+1),e)e[i].keel&&(r[i]=e[i].value);M.setStorage("__kc_log_keel",d()(t))},fixPageLeaveEnter:function(e){return e.ext&&("string"==typeof e.ext?(e.ext=JSON.parse(e.ext),e.ext.enter=e.enter):e.ext.enter=e.enter,e.ext=d()(e.ext)),e},parseParams:function(e,t,n){if(!e.category||!e.name)return console.error(new Error('[Params Error] The "category" and "name" must be a value.')),!1;var r,o={},i=n.length,a=n.length&&n[n.length-2]||{},c={refer_page:a.pagename||"",
refer_url:a.url||"",refer_courseid:a.courseid||"",refer_skuid:a.skuid||""};for(var s in e)e[s].keel&&(e[s]=e[s].value);return e.ext&&(o=JSON.parse(e.ext||{}),delete e.ext),e=_({},e,o),delete(o=_({},o,e)).firstrefer,delete o.pagename,delete o.category,delete o.name,e.ext=d()(o),!(r=_(c,n[i-1],e,t)).webPageViewData&&("webPageView"==r.category||r.pageView)&&i>0&&1==r.enter&&(n[i-1].webPageViewData=r,M.setStorage("__kc_log_keel",d()(n))),r},parseUrlQuery:function(){var e=S.length;k={vendor:!m.isNativeMiniProgram()&&v.getQuery("c")||L.getLastVendor&&e>0&&S[e-1].vendor||"",vendor_content:!m.isNativeMiniProgram()&&v.getQuery("kcm_content")||L.getLastVendor&&e>0&&S[e-1].vendor_content||"",vendor_term:!m.isNativeMiniProgram()&&v.getQuery("kcm_term")||L.getLastVendor&&e>0&&S[e-1].vendor_term||"",vendor_medium:!m.isNativeMiniProgram()&&v.getQuery("kcm_medium")||L.getLastVendor&&e>0&&S[e-1].vendor_medium||"",vendor_time:!m.isNativeMiniProgram()&&v.getQuery("kcm_time")||L.getLastVendor&&e>0&&S[e-1].vendor_time||"",vendor_et:!m.isNativeMiniProgram()&&v.getQuery("kcm_et")||L.getLastVendor&&e>0&&S[e-1].vendor_et||"",vendor_layer:!m.isNativeMiniProgram()&&v.getQuery("kcm_layer")||L.getLastVendor&&e>0&&S[e-1].vendor_layer||"",vendor_des:!m.isNativeMiniProgram()&&v.getQuery("kcm_des")||L.getLastVendor&&e>0&&S[e-1].vendor_des||""}},handleDotHost:function(){var e=window.location.host;return/rdtest|localhost|127\.0\.0\.1|10\.0\.101\.216/.test(e)?"//kclog.rdtest.xuanke.com":/qatest/.test(e)?"//dot.qatest.xuanke.com":/yuanqi46\.com/.test(e)?"//dotlog.yuanqi46.com":/letus\.mobi/.test(e)?"//dotlog.letus.mobi":/www\.kuaidaan\.net/.test(e)?"//dotlog.kuaidaan.net":"//dotlog.kaochong.com"},startHTBT:function(e){T=setInterval(function(){e&&e()},1500)},listenVisibility:function(e){document.addEventListener&&document.addEventListener("visibilitychange",function(){switch(document.visibilityState){case"hidden":case"unloaded":e&&e()}})},pageLog:function(e){var t=M.getStorage("__kc_log_record__");if(t)for(var n in t=JSON.parse(t))M.sendLog(t[n],{},!1,n);"/operation/create_conf_page/index.html"==window.location.pathname&&(71==v.getQuery("plan_id")?M.startHTBT(function(){M.enterLog()}):70==v.getQuery("plan_id")&&M.listenVisibility(function(){M.enterLog()})),M.sendLog(_({enter:1,category:"webPageView",pageView:!0},e)),S[S.length-2]&&M.sendLog(_({name:"unknown"},S[S.length-2].webPageViewData,{enter:0,category:"webPageView"}),!0)},enterLog:function(){S[S.length-2]&&M.sendLog(_({name:"unknown"},S[S.length-2].webPageViewData,{enter:1,category:"webPageView",scrollTop:document.documentElement.scrollTop||window.pageYOffset||document.body.scrollTop||0}),!0)},doSendLog:function(e,t,n,r){m.isNativeMiniProgram()||!t&&M.updateLogKeel(e,S),e=r||t?M.fixPageLeaveEnter(e):M.parseParams(e,k,S);var o=_({},b,x,e,{time:(new Date).getTime()}),i="",a="/api/record/point?"+v.jsonToQuery(o);if(P){i=M.handleDotHost()+a;try{var s=new Image;s.onload=function(){},s.src=i}catch(e){console.error(e||"[Network Error] The image request failed.")}}else"mini"==M.platform()?(i=(M.getStorage("__KC_LOG_H")||__KC_LOG_H)+a,M.wxRequest(i)):function(e,t,n){var r=arguments.length>3&&void 0!==arguments[3]&&arguments[3],o="";try{var i=new XMLHttpRequest;i.withCredentials=!0,t?i.open("get",e,!1):i.open("get",e,!0),i.onreadystatechange=function(){if(4===i.readyState){if(200===i.status){var t=M.getStorage("__kc_log_record__")||"{}";t=JSON.parse(t),r?(t[r]&&delete t[r],M.setStorage("__kc_log_record__",d()(t))):(t[o]&&delete t[o],M.setStorage("__kc_log_record__",d()(t)))}else{var a=v.queryToJson(e.split("?")[1]),s=M.getStorage("__kc_log_record__")||"{}";if(s=JSON.parse(s),r)s[r].time<3?s[r].time+=1:s[r].time>=3?s[r]&&delete s[r]:s[r].time=0;else{o=function(e){for(var t="ABCDEFGHJKMNPQRSTWXYZabcdefhijkmnprstwxyz2345678",n=t.length,r="",o=0;o<32;o++)r+=t.charAt(Math.floor(Math.random()*n));return r}();var u=M.getStorage("__kc_log_record__")||"{}";u=JSON.parse(u),c()(u)&&c()(u).length>=50&&(u={}),u[o]=a}M.setStorage("__kc_log_record__",d()(s))}n&&n(i.responseText)}},i.send()}catch(e){console.error(new Error(e||"[Network Error] Can not get response"))}}(i=M.handleDotHost()+a,n,function(){},r)},registeEvent:function(e){var t=history[e];return function(){var n=t.apply(this,arguments),r=new Event(e);return r.arguments=arguments,window.dispatchEvent(r),n}},wxRequest:function(e){return new u.a(function(t,n){wx.request({url:e,method:"GET",header:{"content-type":"application/json"},dataType:"json",success:function(e){t(e.data)},fail:function(e){n(e)}})})},markHTML:function(e,t){document.querySelector(e).setAttribute(t,1)},sendLog:function(e,t,n,r){var o=window&&window.location&&window.location.href||"",i="."+o.replace(/https?:\/\/.*?([^\.]+\.(com|mobi)).+/,"$1");if("kaochong"===M.platform()||"kc_word"===M.platform()){if(""===x.device_id&&O<30){var a=setInterval(function(){++O,(""!==x.device_id||O>=30)&&(M.sendLog(e,t,n,r),a&&clearInterval(a),O=0)},100);return!1}w.set("kc_puid",x.device_id,i,1200),M.doSendLog(e,t,n,r)}else if(m.isNativeMiniProgram()){try{var c=wx.getStorageSync("userInfo");b.kc_token=c.token||void 0}catch(e){console.error(new Error("[wechat error] Can not get the device info"))}if(wx.getStorageSync("kc_puid"))x.device_id=wx.getStorageSync("kc_puid"),M.doSendLog(e,t,n,r);else{var s=(M.getStorage("__KC_LOG_H")||__KC_LOG_H)+"/api/getPuid";M.wxRequest(s).then(function(o){try{wx.setStorageSync("kc_puid",o.data.puid),x.device_id||(x.device_id=o.data.puid),M.doSendLog(e,t,n,r)}catch(o){console.error(o),console.error(new Error("[Netwrok error] Can not set storage.")),M.doSendLog(e,t,n,r)}})}}else{m.isMiniProgram()&&v.getQuery("puid",o)&&"-1"!=v.getQuery("puid",o)&&w.set("kc_puid",v.getQuery("puid",o),i,1200);var u=M.handleDotHost();w.get("kc_puid")?(x.device_id=w.get("kc_puid"),"-1"==v.getQuery("puid",o)&&wx.miniProgram.postMessage({data:{__kc_puid:x.device_id}}),M.doSendLog(e,t,n,r)):function(e,t,n){try{var r=new XMLHttpRequest;r.withCredentials=!0,r.open("get",e,!0),r.onreadystatechange=function(){4===r.readyState&&n&&n(r.responseText)},r.send()}catch(e){console.error(new Error(e||"[Network Error] Can not get response"))}}(u+"/api/getPuid"+window.location.search,0,function(a){try{a=JSON.parse(a),w.set("kc_puid",a.data.puid,i,1200),x.device_id||(x.device_id=a.data.puid||w.get("kc_puid")),"-1"==v.getQuery("puid",o)&&wx.miniProgram.postMessage({data:{__kc_puid:x.device_id}}),M.doSendLog(e,t,n,r)}catch(o){console.error(o),console.error(new Error("[Netwrok error] Can not set cookie.")),M.doSendLog(e,t,n,r)}})}}};!function(){b=M.initCommonData();try{S=JSON.parse(M.getStorage("__kc_log_keel")||"[]")}catch(e){console.error(e)}if(M.initTime(),M.parseUrlQuery(),m.isNativeMiniProgram());else{window.initNaData=r,M.getNaData(),history.pushState=M.registeEvent("pushState"),history.replaceState=M.registeEvent("replaceState");var e=document.body,t={childList:!0,subtree:!0},n=new MutationObserver(function(e){if(document.querySelector("[kc-log-single-page]")){var t=v.queryToJson(document.querySelector("[kc-log-single-page]").getAttribute("kc-log-single-page"));M.pageLog(t),n.disconnect()}});["pushState","popstate","replaceState"].forEach(function(r,o){window.addEventListener(r,function(r){n.observe(e,t)})}),document.querySelector("body").hasAttribute("page-show")||(document&&document.addEventListener&&document.addEventListener("DOMContentLoaded",function(){document.querySelector("body").hasAttribute("kc-log-page-show")&&M.pageLog(v.queryToJson(document.querySelector("body").getAttribute("kc-log-page-show")))},!1),M.markHTML("body","page-show")),document.querySelector("body").hasAttribute("ele-click")||(document&&document.addEventListener&&document.addEventListener("DOMContentLoaded",function(){if(!document.querySelector("body [kc-log-ele-click]"))return!1;for(var e=document.querySelectorAll("body [kc-log-ele-click]"),t=0,n=e.length;t<n;t++)e[t].addEventListener("click",function(e){var t=e.currentTarget,n=v.queryToJson(t.getAttribute("kc-log-ele-click"));for(var r in n)r.indexOf("__fr")>=0&&(n[r.slice(0,r.indexOf("__fr"))]={value:n[r],keel:!0});M.sendLog(_({category:"webClick"},n))})}),M.markHTML("body","ele-click")),window.onbeforeunload=function(e){clearInterval(L.Timer),T&&clearInterval(T),""!==L.totalTimeSecond&&M.setStorage("refreshRemainTime",L.totalTimeSecond),S[S.length-1]&&M.sendLog(_({},S[S.length-1].webPageViewData,{enter:0,category:"webPageView"}),!0)}}}(window),t.default={send:M.sendLog}}])}); 
 			}); 
		define("npm/promise-polyfill/promise.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			
!function(e){function n(){}function t(e,n){return function(){e.apply(n,arguments)}}function o(e){if(!(this instanceof o))throw new TypeError("Promises must be constructed via new");if("function"!=typeof e)throw new TypeError("not a function");this._state=0,this._handled=!1,this._value=void 0,this._deferreds=[],a(e,this)}function i(e,n){for(;3===e._state;)e=e._value;if(0===e._state)return void e._deferreds.push(n);e._handled=!0,o._immediateFn(function(){var t=1===e._state?n.onFulfilled:n.onRejected;if(null===t)return void(1===e._state?r:u)(n.promise,e._value);var o;try{o=t(e._value)}catch(e){return void u(n.promise,e)}r(n.promise,o)})}function r(e,n){try{if(n===e)throw new TypeError("A promise cannot be resolved with itself.");if(n&&("object"==typeof n||"function"==typeof n)){var i=n.then;if(n instanceof o)return e._state=3,e._value=n,void f(e);if("function"==typeof i)return void a(t(i,n),e)}e._state=1,e._value=n,f(e)}catch(n){u(e,n)}}function u(e,n){e._state=2,e._value=n,f(e)}function f(e){2===e._state&&0===e._deferreds.length&&o._immediateFn(function(){e._handled||o._unhandledRejectionFn(e._value)});for(var n=0,t=e._deferreds.length;n<t;n++)i(e,e._deferreds[n]);e._deferreds=null}function c(e,n,t){this.onFulfilled="function"==typeof e?e:null,this.onRejected="function"==typeof n?n:null,this.promise=t}function a(e,n){var t=!1;try{e(function(e){t||(t=!0,r(n,e))},function(e){t||(t=!0,u(n,e))})}catch(e){if(t)return;t=!0,u(n,e)}}var s=setTimeout;o.prototype.catch=function(e){return this.then(null,e)},o.prototype.then=function(e,t){var o=new this.constructor(n);return i(this,new c(e,t,o)),o},o.all=function(e){return new o(function(n,t){function o(e,u){try{if(u&&("object"==typeof u||"function"==typeof u)){var f=u.then;if("function"==typeof f)return void f.call(u,function(n){o(e,n)},t)}i[e]=u,0==--r&&n(i)}catch(e){t(e)}}if(!e||void 0===e.length)throw new TypeError("Promise.all accepts an array");var i=Array.prototype.slice.call(e);if(0===i.length)return n([]);for(var r=i.length,u=0;u<i.length;u++)o(u,i[u])})},o.resolve=function(e){return e&&"object"==typeof e&&e.constructor===o?e:new o(function(n){n(e)})},o.reject=function(e){return new o(function(n,t){t(e)})},o.race=function(e){return new o(function(n,t){for(var o=0,i=e.length;o<i;o++)e[o].then(n,t)})},o._immediateFn="function"==typeof setImmediate&&function(e){setImmediate(e)}||function(e){s(e,0)},o._unhandledRejectionFn=function(e){"undefined"!=typeof console&&console&&console.warn("Possible Unhandled Promise Rejection:",e)},o._setImmediateFn=function(e){o._immediateFn=e},o._setUnhandledRejectionFn=function(e){o._unhandledRejectionFn=e},"undefined"!=typeof module&&module.exports?module.exports=o:e.Promise||(e.Promise=o)}(this); 
 			}); 
		define("npm/regenerator-runtime/runtime.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			
!function(t){"use strict";function r(t,r,e,o){var i=r&&r.prototype instanceof n?r:n,a=Object.create(i.prototype),c=new l(o||[]);return a._invoke=u(t,e,c),a}function e(t,r,e){try{return{type:"normal",arg:t.call(r,e)}}catch(t){return{type:"throw",arg:t}}}function n(){}function o(){}function i(){}function a(t){["next","throw","return"].forEach(function(r){t[r]=function(t){return this._invoke(r,t)}})}function c(r){function n(t,o,i,a){var c=e(r[t],r,o);if("throw"!==c.type){var u=c.arg,h=u.value;return h&&"object"==typeof h&&g.call(h,"__await")?Promise.resolve(h.__await).then(function(t){n("next",t,i,a)},function(t){n("throw",t,i,a)}):Promise.resolve(h).then(function(t){u.value=t,i(u)},a)}a(c.arg)}function o(t,r){function e(){return new Promise(function(e,o){n(t,r,e,o)})}return i=i?i.then(e,e):e()}"object"==typeof t.process&&t.process.domain&&(n=t.process.domain.bind(n));var i;this._invoke=o}function u(t,r,n){var o=j;return function(i,a){if(o===O)throw new Error("Generator is already running");if(o===k){if("throw"===i)throw a;return y()}for(n.method=i,n.arg=a;;){var c=n.delegate;if(c){var u=h(c,n);if(u){if(u===G)continue;return u}}if("next"===n.method)n.sent=n._sent=n.arg;else if("throw"===n.method){if(o===j)throw o=k,n.arg;n.dispatchException(n.arg)}else"return"===n.method&&n.abrupt("return",n.arg);o=O;var s=e(t,r,n);if("normal"===s.type){if(o=n.done?k:_,s.arg===G)continue;return{value:s.arg,done:n.done}}"throw"===s.type&&(o=k,n.method="throw",n.arg=s.arg)}}}function h(t,r){var n=t.iterator[r.method];if(n===d){if(r.delegate=null,"throw"===r.method){if(t.iterator.return&&(r.method="return",r.arg=d,h(t,r),"throw"===r.method))return G;r.method="throw",r.arg=new TypeError("The iterator does not provide a 'throw' method")}return G}var o=e(n,t.iterator,r.arg);if("throw"===o.type)return r.method="throw",r.arg=o.arg,r.delegate=null,G;var i=o.arg;return i?i.done?(r[t.resultName]=i.value,r.next=t.nextLoc,"return"!==r.method&&(r.method="next",r.arg=d),r.delegate=null,G):i:(r.method="throw",r.arg=new TypeError("iterator result is not an object"),r.delegate=null,G)}function s(t){var r={tryLoc:t[0]};1 in t&&(r.catchLoc=t[1]),2 in t&&(r.finallyLoc=t[2],r.afterLoc=t[3]),this.tryEntries.push(r)}function f(t){var r=t.completion||{};r.type="normal",delete r.arg,t.completion=r}function l(t){this.tryEntries=[{tryLoc:"root"}],t.forEach(s,this),this.reset(!0)}function p(t){if(t){var r=t[w];if(r)return r.call(t);if("function"==typeof t.next)return t;if(!isNaN(t.length)){var e=-1,n=function r(){for(;++e<t.length;)if(g.call(t,e))return r.value=t[e],r.done=!1,r;return r.value=d,r.done=!0,r};return n.next=n}}return{next:y}}function y(){return{value:d,done:!0}}var d,v=Object.prototype,g=v.hasOwnProperty,m="function"==typeof Symbol?Symbol:{},w=m.iterator||"@@iterator",L=m.asyncIterator||"@@asyncIterator",x=m.toStringTag||"@@toStringTag",b="object"==typeof module,E=t.regeneratorRuntime;if(E)return void(b&&(module.exports=E));E=t.regeneratorRuntime=b?module.exports:{},E.wrap=r;var j="suspendedStart",_="suspendedYield",O="executing",k="completed",G={},N={};N[w]=function(){return this};var P=Object.getPrototypeOf,S=P&&P(P(p([])));S&&S!==v&&g.call(S,w)&&(N=S);var F=i.prototype=n.prototype=Object.create(N);o.prototype=F.constructor=i,i.constructor=o,i[x]=o.displayName="GeneratorFunction",E.isGeneratorFunction=function(t){var r="function"==typeof t&&t.constructor;return!!r&&(r===o||"GeneratorFunction"===(r.displayName||r.name))},E.mark=function(t){return Object.setPrototypeOf?Object.setPrototypeOf(t,i):(t.__proto__=i,x in t||(t[x]="GeneratorFunction")),t.prototype=Object.create(F),t},E.awrap=function(t){return{__await:t}},a(c.prototype),c.prototype[L]=function(){return this},E.AsyncIterator=c,E.async=function(t,e,n,o){var i=new c(r(t,e,n,o));return E.isGeneratorFunction(e)?i:i.next().then(function(t){return t.done?t.value:i.next()})},a(F),F[x]="Generator",F[w]=function(){return this},F.toString=function(){return"[object Generator]"},E.keys=function(t){var r=[];for(var e in t)r.push(e);return r.reverse(),function e(){for(;r.length;){var n=r.pop();if(n in t)return e.value=n,e.done=!1,e}return e.done=!0,e}},E.values=p,l.prototype={constructor:l,reset:function(t){if(this.prev=0,this.next=0,this.sent=this._sent=d,this.done=!1,this.delegate=null,this.method="next",this.arg=d,this.tryEntries.forEach(f),!t)for(var r in this)"t"===r.charAt(0)&&g.call(this,r)&&!isNaN(+r.slice(1))&&(this[r]=d)},stop:function(){this.done=!0;var t=this.tryEntries[0],r=t.completion;if("throw"===r.type)throw r.arg;return this.rval},dispatchException:function(t){function r(r,n){return i.type="throw",i.arg=t,e.next=r,n&&(e.method="next",e.arg=d),!!n}if(this.done)throw t;for(var e=this,n=this.tryEntries.length-1;n>=0;--n){var o=this.tryEntries[n],i=o.completion;if("root"===o.tryLoc)return r("end");if(o.tryLoc<=this.prev){var a=g.call(o,"catchLoc"),c=g.call(o,"finallyLoc");if(a&&c){if(this.prev<o.catchLoc)return r(o.catchLoc,!0);if(this.prev<o.finallyLoc)return r(o.finallyLoc)}else if(a){if(this.prev<o.catchLoc)return r(o.catchLoc,!0)}else{if(!c)throw new Error("try statement without catch or finally");if(this.prev<o.finallyLoc)return r(o.finallyLoc)}}}},abrupt:function(t,r){for(var e=this.tryEntries.length-1;e>=0;--e){var n=this.tryEntries[e];if(n.tryLoc<=this.prev&&g.call(n,"finallyLoc")&&this.prev<n.finallyLoc){var o=n;break}}o&&("break"===t||"continue"===t)&&o.tryLoc<=r&&r<=o.finallyLoc&&(o=null);var i=o?o.completion:{};return i.type=t,i.arg=r,o?(this.method="next",this.next=o.finallyLoc,G):this.complete(i)},complete:function(t,r){if("throw"===t.type)throw t.arg;return"break"===t.type||"continue"===t.type?this.next=t.arg:"return"===t.type?(this.rval=this.arg=t.arg,this.method="return",this.next="end"):"normal"===t.type&&r&&(this.next=r),G},finish:function(t){for(var r=this.tryEntries.length-1;r>=0;--r){var e=this.tryEntries[r];if(e.finallyLoc===t)return this.complete(e.completion,e.afterLoc),f(e),G}},catch:function(t){for(var r=this.tryEntries.length-1;r>=0;--r){var e=this.tryEntries[r];if(e.tryLoc===t){var n=e.completion;if("throw"===n.type){var o=n.arg;f(e)}return o}}throw new Error("illegal catch attempt")},delegateYield:function(t,r,e){return this.delegate={iterator:p(t),resultName:r,nextLoc:e},"next"===this.method&&(this.arg=d),G}}}("object"==typeof global?global:"object"==typeof window?window:"object"==typeof self?self:this); 
 			}); 
		define("npm/wepy-async-function/global.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			
var global=module.exports="undefined"!=typeof window&&window.Math===Math?window:"undefined"!=typeof self&&self.Math===Math?self:this||Function("return this")(); 
 			}); 
		define("npm/wepy-async-function/index.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			
var g=require("./global.js");g?(g.Promise||(g.Promise=require("./../promise-polyfill/promise.js")),g.regeneratorRuntime||(g.regeneratorRuntime=require("./../regenerator-runtime/runtime.js"))):console.warn('请确认关闭小程序选项 "关闭ES6转ES5"'); 
 			}); 
		define("npm/wepy/lib/app.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			
"use strict";function _interopRequireDefault(e){return e&&e.__esModule?e:{default:e}}function _classCallCheck(e,t){if(!(e instanceof t))throw new TypeError("Cannot call a class as a function")}Object.defineProperty(exports,"__esModule",{value:!0});var _createClass=function(){function e(e,t){for(var n=0;n<t.length;n++){var r=t[n];r.enumerable=r.enumerable||!1,r.configurable=!0,"value"in r&&(r.writable=!0),Object.defineProperty(e,r.key,r)}}return function(t,n,r){return n&&e(t.prototype,n),r&&e(t,r),t}}(),_native=require("./native.js"),_native2=_interopRequireDefault(_native),RequestMQ={map:{},mq:[],running:[],MAX_REQUEST:5,push:function(e){for(e.t=+new Date;this.mq.indexOf(e.t)>-1||this.running.indexOf(e.t)>-1;)e.t+=10*Math.random()>>0;this.mq.push(e.t),this.map[e.t]=e},next:function(){var e=this;if(0!==this.mq.length&&this.running.length<this.MAX_REQUEST-1){var t=this.mq.shift(),n=this.map[t],r=n.complete;return n.complete=function(){for(var t=arguments.length,i=Array(t),a=0;a<t;a++)i[a]=arguments[a];e.running.splice(e.running.indexOf(n.t),1),delete e.map[n.t],r&&r.apply(n,i),e.next()},this.running.push(n.t),wx.request(n)}},request:function(e){return e=e||{},e="string"==typeof e?{url:e}:e,this.push(e),this.next()}},_class=function(){function e(){_classCallCheck(this,e),this.$addons={},this.$interceptors={},this.$pages={}}return _createClass(e,[{key:"$init",value:function(e){var t=arguments.length>1&&void 0!==arguments[1]?arguments[1]:{};this.$initAPI(e,t.noPromiseAPI),this.$wxapp=getApp()}},{key:"use",value:function(e){for(var t=arguments.length,n=Array(t>1?t-1:0),r=1;r<t;r++)n[r-1]=arguments[r];"string"==typeof e&&this[e]?(this.$addons[e]=1,this[e](n)):this.$addons[e.name]=new e(n)}},{key:"intercept",value:function(e,t){this.$interceptors[e]=t}},{key:"promisify",value:function(){}},{key:"requestfix",value:function(){}},{key:"$initAPI",value:function(e,t){var n=this,r={stopRecord:!0,getRecorderManager:!0,pauseVoice:!0,stopVoice:!0,pauseBackgroundAudio:!0,stopBackgroundAudio:!0,getBackgroundAudioManager:!0,createAudioContext:!0,createInnerAudioContext:!0,createVideoContext:!0,createCameraContext:!0,createMapContext:!0,canIUse:!0,startAccelerometer:!0,stopAccelerometer:!0,startCompass:!0,stopCompass:!0,onBLECharacteristicValueChange:!0,onBLEConnectionStateChange:!0,hideToast:!0,hideLoading:!0,showNavigationBarLoading:!0,hideNavigationBarLoading:!0,navigateBack:!0,createAnimation:!0,pageScrollTo:!0,createSelectorQuery:!0,createCanvasContext:!0,createContext:!0,drawCanvas:!0,hideKeyboard:!0,stopPullDownRefresh:!0,reportAnalytics:!0,arrayBufferToBase64:!0,base64ToArrayBuffer:!0};if(t)if(Array.isArray(t))t.forEach(function(e){return r[e]=!0});else for(var i in t)r[i]=t[i];Object.keys(wx).forEach(function(t){r[t]||"on"===t.substr(0,2)||/\w+Sync$/.test(t)?(Object.defineProperty(_native2.default,t,{get:function(){return function(){for(var e=arguments.length,n=Array(e),r=0;r<e;r++)n[r]=arguments[r];return wx[t].apply(wx,n)}}}),e[t]=_native2.default[t]):(Object.defineProperty(_native2.default,t,{get:function(){return function(e){if(e=e||{},n.$interceptors[t]&&n.$interceptors[t].config){var r=n.$interceptors[t].config.call(n,e);if(!1===r)return n.$addons.promisify?Promise.reject("aborted by interceptor"):void(e.fail&&e.fail("aborted by interceptor"));e=r}if("request"===t&&(e="string"==typeof e?{url:e}:e),"string"==typeof e)return wx[t](e);if(n.$addons.promisify){var i=void 0,a=new Promise(function(r,a){var o={};["fail","success","complete"].forEach(function(i){o[i]=e[i],e[i]=function(e){n.$interceptors[t]&&n.$interceptors[t][i]&&(e=n.$interceptors[t][i].call(n,e)),"success"===i?r(e):"fail"===i&&a(e)}}),n.$addons.requestfix&&"request"===t?RequestMQ.request(e):i=wx[t](e)});return"uploadFile"!==t&&"downloadFile"!==t||(a.progress=function(e){return i.onProgressUpdate(e),a},a.abort=function(e){return e&&e(),i.abort(),a}),a}var o={};if(["fail","success","complete"].forEach(function(r){o[r]=e[r],e[r]=function(e){n.$interceptors[t]&&n.$interceptors[t][r]&&(e=n.$interceptors[t][r].call(n,e)),o[r]&&o[r].call(n,e)}}),!n.$addons.requestfix||"request"!==t)return wx[t](e);RequestMQ.request(e)}}}),e[t]=_native2.default[t])})}}]),e}();exports.default=_class; 
 			}); 
		define("npm/wepy/lib/base.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			
"use strict";function _interopRequireDefault(e){return e&&e.__esModule?e:{default:e}}Object.defineProperty(exports,"__esModule",{value:!0});var _event=require("./event.js"),_event2=_interopRequireDefault(_event),_util=require("./util.js"),_util2=_interopRequireDefault(_util),PAGE_EVENT=["onLoad","onReady","onShow","onHide","onUnload","onPullDownRefresh","onReachBottom","onShareAppMessage","onPageScroll","onTabItemTap"],APP_EVENT=["onLaunch","onShow","onHide","onError","onPageNotFound"],$bindEvt=function e(n,t,o){t.$prefix=_util2.default.camelize(o||""),Object.getOwnPropertyNames(t.components||{}).forEach(function(a){var r=t.components[a],i=new r;i.$initMixins(),i.$name=a;var p=o?o+i.$name+"$":"$"+i.$name+"$";t.$com[a]=i,e(n,i,p)}),Object.getOwnPropertyNames(t.constructor.prototype||[]).forEach(function(e){"constructor"!==e&&-1===PAGE_EVENT.indexOf(e)&&(n[e]=function(){t.constructor.prototype[e].apply(t,arguments),t.$apply()})});var a=Object.getOwnPropertyNames(t.methods||[]);return t.$mixins.forEach(function(e){a=a.concat(Object.getOwnPropertyNames(e.methods||[]))}),a.forEach(function(e,o){n[t.$prefix+e]=function(n){for(var o=arguments.length,a=Array(o>1?o-1:0),r=1;r<o;r++)a[r-1]=arguments[r];var i=new _event2.default("system",this,n.type);i.$transfor(n);var p=[],c=0,s=void 0,u=void 0,f=void 0;if(n.currentTarget&&n.currentTarget.dataset){for(s=n.currentTarget.dataset;void 0!==s["wpy"+e.toLowerCase()+(u=String.fromCharCode(65+c++))];)p.push(s["wpy"+e.toLowerCase()+u]);void 0!==s.comIndex&&(f=s.comIndex)}if(void 0!==f){f=(""+f).split("-");for(var l=f.length,h=l;l-- >0;){h=l;for(var d=t;h-- >0;)d=d.$parent;d.$setIndex(f.shift())}}a=a.concat(p);var $=void 0,_=void 0,v=t.methods[e];return v&&($=v.apply(t,a.concat(i))),t.$mixins.forEach(function(n){n.methods[e]&&(_=n.methods[e].apply(t,a.concat(i)))}),t.$apply(),v?$:_}}),n};exports.default={$createApp:function(e,n){var t={},o=new e;return this.$instance||(o.$init(this,n),this.$instance=o,this.$appConfig=n),2===arguments.length&&!0===arguments[1]&&(t.$app=o),o.$wxapp=getApp(),APP_EVENT=APP_EVENT.concat(n.appEvents||[]),PAGE_EVENT=PAGE_EVENT.concat(n.pageEvents||[]),APP_EVENT.forEach(function(e){t[e]=function(){for(var n=arguments.length,t=Array(n),a=0;a<n;a++)t[a]=arguments[a];var r=void 0;return!o.$wxapp&&(o.$wxapp=getApp()),o[e]&&(r=o[e].apply(o,t)),r}}),t},$createPage:function(e,n){var t=this,o={},a=new e;return"string"==typeof n&&(this.$instance.$pages["/"+n]=a),a.$initMixins(),("boolean"==typeof n&&n||3===arguments.length&&!0===arguments[2])&&(o.$page=a),o.onLoad=function(){for(var n=arguments.length,o=Array(n),r=0;r<n;r++)o[r]=arguments[r];!("options"in this)&&(this.options=o.length?o[0]:{}),a.$name=e.name||"unnamed",a.$init(this,t.$instance,t.$instance);var i=t.$instance.__prevPage__,p={};p.from=i||void 0,i&&i.$preloadData&&(p.preload=i.$preloadData,i.$preloadData=void 0),a.$prefetchData&&(p.prefetch=a.$prefetchData,a.$prefetchData=void 0),o.push(p),a.$onLoad.apply(a,o),a.$apply()},o.onUnload=function(){for(var e=arguments.length,n=Array(e),t=0;t<e;t++)n[t]=arguments[t];a.$onUnload.apply(a,n)},o.onShow=function(){for(var e=arguments.length,n=Array(e),o=0;o<e;o++)n[o]=arguments[o];t.$instance.__prevPage__=a,[].concat(a.$mixins,a).forEach(function(e){e.onShow&&e.onShow.apply(a,n)});var r=getCurrentPages(),i=r[r.length-1].__route__,p=r[r.length-1].__wxWebviewId__;t.$instance.__wxWebviewId__!==p&&(a.$wxpage=this,t.$instance.__route__=i,t.$instance.__wxWebviewId__=p,[].concat(a.$mixins,a).forEach(function(e){e.onRoute&&e.onRoute.apply(a,n)})),a.$apply()},PAGE_EVENT.forEach(function(e){"onLoad"!==e&&"onUnload"!==e&&"onShow"!==e&&(o[e]=function(){for(var n=arguments.length,t=Array(n),o=0;o<n;o++)t[o]=arguments[o];var r=void 0;return"onShareAppMessage"===e?(a[e]&&(r=a[e].apply(a,t)),r):([].concat(a.$mixins,a).forEach(function(n){n[e]&&n[e].apply(a,t)}),"onPageScroll"!==e&&a.$apply(),r)})}),a.onShareAppMessage||delete o.onShareAppMessage,-1===[].concat(a.$mixins,a).findIndex(function(e){return e.onPageScroll})&&delete o.onPageScroll,$bindEvt(o,a,"")}}; 
 			}); 
		define("npm/wepy/lib/component.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			
"use strict";function _interopRequireDefault(t){return t&&t.__esModule?t:{default:t}}function _classCallCheck(t,e){if(!(t instanceof e))throw new TypeError("Cannot call a class as a function")}function keyCheck(t,e){return"function"==typeof t[e]?(console.warn('You are not allowed to define a function "'+e+'" in data.'),0):-1!==["data","props","methods","events","mixins"].indexOf(e)?(console.warn('"'+e+'" is reserved word, please fix it.'),0):"$"===e[0]?(console.warn('"'+e+': You can not define a property started with "$"'),0):1}function getEventsFn(t,e){var i=t.events?t.events[e]:t.$events[e]?t.$events[e]:void 0,n=void 0===i?"undefined":_typeof(i),o=void 0;if("string"===n){var a=t.methods&&t.methods[i];"function"==typeof a&&(o=a)}else("function"===n||Array.isArray(i))&&(o=i);return o}Object.defineProperty(exports,"__esModule",{value:!0});var _createClass=function(){function t(t,e){for(var i=0;i<e.length;i++){var n=e[i];n.enumerable=n.enumerable||!1,n.configurable=!0,"value"in n&&(n.writable=!0),Object.defineProperty(t,n.key,n)}}return function(e,i,n){return i&&t(e.prototype,i),n&&t(e,n),e}}(),_typeof="function"==typeof Symbol&&"symbol"==typeof Symbol.iterator?function(t){return typeof t}:function(t){return t&&"function"==typeof Symbol&&t.constructor===Symbol&&t!==Symbol.prototype?"symbol":typeof t},_event=require("./event.js"),_event2=_interopRequireDefault(_event),_util=require("./util.js"),_util2=_interopRequireDefault(_util),Props={check:function(t,e){switch(t){case String:return"string"==typeof e;case Number:return"number"==typeof e;case Boolean:return"boolean"==typeof e;case Function:return"function"==typeof e;case Object:return"object"===(void 0===e?"undefined":_typeof(e));case Array:return"[object Array]"===toString.call(e);default:return e instanceof t}},build:function(t){var e={};return"string"==typeof t?e[t]={}:"[object Array]"===toString.call(t)?t.forEach(function(t){e[t]={}}):Object.keys(t).forEach(function(i){"function"==typeof t[i]?e[i]={type:[t[i]]}:"[object Array]"===toString.call(t[i])?e[i]={type:t[i]}:e[i]=t[i],e[i].type&&"[object Array]"!==toString.call(e[i].type)&&(e[i].type=[e[i].type])}),e},valid:function(t,e,i){var n=this,o=!1;if(t[e]){if(t[e].type)return t[e].type.some(function(t){return n.check(t,i)});o=!0}return o},getValue:function(t,e,i,n){var o;return o=void 0!==i&&this.valid(t,e,i)?i:"function"==typeof t[e].default?t[e].default():t[e].default,t[e].coerce?t[e].coerce.call(n,o):o}},_class=function(){function t(){_classCallCheck(this,t),this.$com={},this.$events={},this.$mixins=[],this.$isComponent=!0,this.$prefix="",this.$mappingProps={},this.data={},this.methods={}}return _createClass(t,[{key:"$init",value:function(t,e,i){var n=this;this.$wxpage=t,this.$isComponent&&(this.$root=e||this.$root,this.$parent=i||this.$parent,this.$wxapp=this.$root.$parent.$wxapp),this.props&&(this.props=Props.build(this.props));var o=void 0,a={},r=this.props,s=void 0,p=void 0,f=void 0,h=!1,c=void 0;if(void 0===this.$initData?this.$initData=_util2.default.$copy(this.data,!0):this.data=_util2.default.$copy(this.$initData,!0),this.$props)for(s in this.$props)for(f in this.$props[s])/\.sync$/.test(f)&&(this.$mappingProps[this.$props[s][f]]||(this.$mappingProps[this.$props[s][f]]={}),this.$mappingProps[this.$props[s][f]][s]=f.substring(7,f.length-5));if(r)for(s in r)keyCheck(this,s)&&(p=void 0,i&&i.$props&&i.$props[this.$name]&&(p=i.$props[this.$name][s],f=i.$props[this.$name]["v-bind:"+s+".once"]||i.$props[this.$name]["v-bind:"+s+".sync"],f?"object"===(void 0===f?"undefined":_typeof(f))?function(){r[s].repeat=f.for,r[s].item=f.item,r[s].index=f.index,r[s].key=f.key,r[s].value=f.value,h=!0;var t=f.for,e=i;t.split(".").forEach(function(t){e=e?e[t]:{}}),!e||"object"!==(void 0===e?"undefined":_typeof(e))&&"string"!=typeof e||(c=Object.keys(e)[0]),n.$mappingProps[s]||(n.$mappingProps[s]={}),n.$mappingProps[s].parent={mapping:f.for,from:s}}():(p=i[f],r[s].twoWay&&(this.$mappingProps[s]||(this.$mappingProps[s]={}),this.$mappingProps[s].parent=f)):"object"===(void 0===p?"undefined":_typeof(p))&&void 0!==p.value&&(this.data[s]=p.value)),this.data[s]||r[s].repeat||(p=Props.getValue(r,s,p,this),this.data[s]=p));"function"==typeof this.data&&(this.data=this.data.apply(this.data));for(o in this.data)keyCheck(this,o)&&(a[""+this.$prefix+o]=this.data[o],this[o]=this.data[o]);if(this.$data=_util2.default.$copy(this.data,!0),h&&void 0!==c&&this.$setIndex(c),this.computed)for(o in this.computed)if(keyCheck(this,o)){var u=this.computed[o];a[""+this.$prefix+o]=u.call(this),this[o]=_util2.default.$copy(a[""+this.$prefix+o],!0)}this.setData(a);var $=Object.getOwnPropertyNames(this.$com);$.length&&$.forEach(function(t){n.$com[t].$init(n.getWxPage(),e,n)})}},{key:"$initMixins",value:function(){var t=this;this.mixins?"function"==typeof this.mixins&&(this.mixins=[this.mixins]):this.mixins=[],this.mixins.forEach(function(e){var i=new e;i.$init(t),t.$mixins.push(i)})}},{key:"$onLoad",value:function(){for(var t=this,e=arguments.length,i=Array(e),n=0;n<e;n++)i[n]=arguments[n];[].concat(this.$mixins,this).forEach(function(e){e.onLoad&&e.onLoad.apply(t,i)});var o=Object.getOwnPropertyNames(this.$com);o.length&&o.forEach(function(e){var i=t.$com[e];i.$onLoad.call(i)})}},{key:"$onUnload",value:function(){for(var t=this,e=arguments.length,i=Array(e),n=0;n<e;n++)i[n]=arguments[n];var o=Object.getOwnPropertyNames(this.$com);o.length&&o.forEach(function(e){var i=t.$com[e];i.$onUnload.call(i)}),[].concat(this.$mixins,this).forEach(function(e){e.onUnload&&e.onUnload.apply(t,i)})}},{key:"onLoad",value:function(){}},{key:"onUnload",value:function(){}},{key:"setData",value:function(t,e){if("string"==typeof t){if(e){var i={};i[t]=e,t=i}else{var n={};n[t]=this.data[""+t],t=n}return this.$wxpage.setData(t)}var o=null,a=new RegExp("^"+this.$prefix.replace(/\$/g,"\\$"),"ig");for(o in t){var r=o.replace(a,"");this.$data[r]=_util2.default.$copy(t[o],!0),_util2.default.isImmutable(t[o])&&(t[o]=t[o].toJS()),void 0===t[o]&&delete t[o]}return"function"==typeof e?this.$root.$wxpage.setData(t,e):this.$root.$wxpage.setData(t)}},{key:"getWxPage",value:function(){return this.$wxpage}},{key:"getCurrentPages",value:function(t){function e(){return t.apply(this,arguments)}return e.toString=function(){return t.toString()},e}(function(){return getCurrentPages()})},{key:"$setIndex",value:function(t){var e=this;this.$index=t;var i=this.props,n=this.$parent,o=void 0,a=void 0,r=void 0;if(i){for(o in i)a=void 0,n&&n.$props&&n.$props[this.$name]&&(a=n.$props[this.$name][o],(r=n.$props[this.$name]["v-bind:"+o+".once"]||n.$props[this.$name]["v-bind:"+o+".sync"])&&"object"===(void 0===r?"undefined":_typeof(r))&&function(){var s=r.for,p=n;if(0===s.indexOf("[")){var f=[];s=s.substr(1,s.length-2).trim(),s.split(",").forEach(function(t){var e=n;t.trim().split(".").forEach(function(t){e=e?e[t]:{}}),f.push(e)}),p=f}else s.split(".").forEach(function(t){p=p?p[t]:{}});t=Array.isArray(p)?+t:t,a=i[o].value===i[o].item?p[t]:i[o].value===i[o].index?t:i[o].value===i[o].key?t:n[i[o].value],e.$index=t,e.data[o]=a,e[o]=a,e.$data[o]=_util2.default.$copy(e[o],!0)}());for(o in this.$com)this.$com[o].$index=void 0}}},{key:"$getComponent",value:function(t){var e=this;if("string"==typeof t){if(-1===t.indexOf("/"))return this.$com[t];if("/"===t)return this.$parent;t.split("/").forEach(function(i,n){0===n?t=""===i?e.$root:"."===i?e:".."===i?e.$parent:e.$getComponent(i):i&&(t=t.$com[i])})}return"object"!==(void 0===t?"undefined":_typeof(t))?null:t}},{key:"$invoke",value:function(t,e){if(!(t=this.$getComponent(t)))throw new Error("Invalid path: "+t);for(var i=t.methods?t.methods[e]:"",n=arguments.length,o=Array(n>2?n-2:0),a=2;a<n;a++)o[a-2]=arguments[a];if("function"==typeof i){var r=new _event2.default("",this,"invoke"),s=i.apply(t,o.concat(r));return t.$apply(),s}if("function"==typeof(i=t[e]))return i.apply(t,o);throw new Error("Invalid method: "+e)}},{key:"$broadcast",value:function(t){for(var e=arguments.length,i=Array(e>1?e-1:0),n=1;n<e;n++)i[n-1]=arguments[n];for(var o=this,a="string"==typeof t?new _event2.default(t,this,"broadcast"):a,r=[o];r.length&&a.active;){var s=r.shift();for(var p in s.$com){if("break"===function(e){e=s.$com[e],r.push(e);var n=getEventsFn(e,t);if(n&&e.$apply(function(){n.apply(e,i.concat(a))}),!a.active)return"break";p=e}(p))break}}}},{key:"$emit",value:function(t){for(var e=this,i=arguments.length,n=Array(i>1?i-1:0),o=1;o<i;o++)n[o-1]=arguments[o];var a=this,r=this,s=new _event2.default(t,r,"emit");if(n=n.concat(s),this.$parent&&this.$parent.$events&&this.$parent.$events[this.$name]){var p=this.$parent.$events[this.$name]["v-on:"+t];if(p&&this.$parent.methods){var f=this.$parent.methods[p];if("function"==typeof f)return void this.$parent.$apply(function(){f.apply(e.$parent,n)});throw new Error("Invalid method from emit, component is "+this.$parent.$name+", method is "+p+". Make sure you defined it already.\n")}}for(;a&&void 0!==a.$isComponent&&s.active;)!function(){var e=a,i=getEventsFn(e,t);i&&("function"==typeof i?e.$apply(function(){i.apply(e,n)}):Array.isArray(i)&&(i.forEach(function(t){t.apply(e,n)}),e.$apply())),a=e.$parent}()}},{key:"$on",value:function(t,e){var i=this;if("string"==typeof t)(this.$events[t]||(this.$events[t]=[])).push(e);else if(Array.isArray(t))t.forEach(function(t){i.$on(t,e)});else if("object"===(void 0===t?"undefined":_typeof(t)))for(var n in t)this.$on(n,t[n]);return this}},{key:"$once",value:function(t,e){var i=this,n=function n(){i.$off(t,n),e.apply(i,arguments)};n.fn=e,this.$on(t,n)}},{key:"$off",value:function(t,e){var i=this;if(void 0===t)this.$events={};else if("string"==typeof t)if(e){for(var n=this.$events[t],o=n.length;o--;)if(e===n[o]||e===n[o].fn){n.splice(o,1);break}}else this.$events[t]=[];else Array.isArray(t)&&t.forEach(function(t){i.$off(t,e)});return this}},{key:"$apply",value:function(t){"function"==typeof t?(t.call(this),this.$apply()):this.$$phase?this.$$phase="$apply":this.$digest()}},{key:"$digest",value:function(){var t=this,e=void 0,i=this.$data;for(this.$$phase="$digest",this.$$dc=0;this.$$phase;){if(++this.$$dc>=3)throw new Error("Can not call $apply in $apply process");var n={};if(this.computed)for(e in this.computed){var o=this.computed[e],a=o.call(this);_util2.default.$isEqual(this[e],a)||(n[this.$prefix+e]=a,this[e]=_util2.default.$copy(a,!0))}for(e in i)if(!_util2.default.$isEqual(this[e],i[e])){if(this.watch&&this.watch[e]&&("function"==typeof this.watch[e]?this.watch[e].call(this,this[e],i[e]):"string"==typeof this.watch[e]&&"function"==typeof this.methods[e]&&this.methods[e].call(this,this[e],i[e])),n[this.$prefix+e]=this[e],this.data[e]=this[e],i[e]=_util2.default.$copy(this[e],!0),this.$repeat&&this.$repeat[e]){var r=this.$repeat[e];this.$com[r.com].data[r.props]=this[e],this.$com[r.com].$setIndex(0),this.$com[r.com].$apply()}this.$mappingProps[e]&&Object.keys(this.$mappingProps[e]).forEach(function(i){var n=t.$mappingProps[e][i];"object"===(void 0===n?"undefined":_typeof(n))?t.$parent.$apply():"parent"!==i||_util2.default.$isEqual(t.$parent.$data[n],t[e])?"parent"===i||_util2.default.$isEqual(t.$com[i].$data[n],t[e])||(t.$com[i][n]=t[e],t.$com[i].data[n]=t[e],t.$com[i].$apply()):(t.$parent[n]=t[e],t.$parent.data[n]=t[e],t.$parent.$apply())})}if(Object.keys(n).length)this.setData(n,function(){if(t.$$nextTick){var e=t.$$nextTick;t.$$nextTick=null,e.promise?e():e.call(t)}});else if(this.$$nextTick){var s=this.$$nextTick;this.$$nextTick=null,s.promise?s():s.call(this)}this.$$phase="$apply"===this.$$phase&&"$digest"}}},{key:"$nextTick",value:function(t){var e=this;if(void 0===t)return new Promise(function(t,i){e.$$nextTick=function(){t()},e.$$nextTick.promise=!0});this.$$nextTick=t}}]),t}();exports.default=_class; 
 			}); 
		define("npm/wepy/lib/event.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			
"use strict";function _classCallCheck(e,t){if(!(e instanceof t))throw new TypeError("Cannot call a class as a function")}Object.defineProperty(exports,"__esModule",{value:!0});var _createClass=function(){function e(e,t){for(var n=0;n<t.length;n++){var a=t[n];a.enumerable=a.enumerable||!1,a.configurable=!0,"value"in a&&(a.writable=!0),Object.defineProperty(e,a.key,a)}}return function(t,n,a){return n&&e(t.prototype,n),a&&e(t,a),t}}(),_class=function(){function e(t,n,a){_classCallCheck(this,e),this.active=!0,this.name=t,this.source=n,this.type=a}return _createClass(e,[{key:"$destroy",value:function(){this.active=!1}},{key:"$transfor",value:function(e){var t=0;for(t in e)this[t]=e[t]}}]),e}();exports.default=_class; 
 			}); 
		define("npm/wepy/lib/mixin.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			
"use strict";function _classCallCheck(t,e){if(!(t instanceof e))throw new TypeError("Cannot call a class as a function")}Object.defineProperty(exports,"__esModule",{value:!0});var _createClass=function(){function t(t,e){for(var n=0;n<e.length;n++){var o=e[n];o.enumerable=o.enumerable||!1,o.configurable=!0,"value"in o&&(o.writable=!0),Object.defineProperty(t,o.key,o)}}return function(e,n,o){return n&&t(e.prototype,n),o&&t(e,o),e}}(),_class=function(){function t(){_classCallCheck(this,t),this.data={},this.computed={},this.components={},this.methods={},this.events={}}return _createClass(t,[{key:"$init",value:function(t){var e=this;Object.getOwnPropertyNames(this).concat(Object.getOwnPropertyNames(Object.getPrototypeOf(this))).forEach(function(n){n[0]+n[1]!=="on"&&"constructor"!==n&&(t[n]||(t[n]=e[n]))}),["data","computed","events","components"].forEach(function(n){Object.getOwnPropertyNames(e[n]).forEach(function(o){"init"===o||t[n][o]||(t[n][o]=e[n][o])})})}}]),t}();exports.default=_class; 
 			}); 
		define("npm/wepy/lib/native.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			
"use strict";Object.defineProperty(exports,"__esModule",{value:!0}),exports.default={}; 
 			}); 
		define("npm/wepy/lib/page.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			
"use strict";function _interopRequireDefault(t){return t&&t.__esModule?t:{default:t}}function _classCallCheck(t,e){if(!(t instanceof e))throw new TypeError("Cannot call a class as a function")}function _possibleConstructorReturn(t,e){if(!t)throw new ReferenceError("this hasn't been initialised - super() hasn't been called");return!e||"object"!=typeof e&&"function"!=typeof e?t:e}function _inherits(t,e){if("function"!=typeof e&&null!==e)throw new TypeError("Super expression must either be null or a function, not "+typeof e);t.prototype=Object.create(e&&e.prototype,{constructor:{value:t,enumerable:!1,writable:!0,configurable:!0}}),e&&(Object.setPrototypeOf?Object.setPrototypeOf(t,e):t.__proto__=e)}Object.defineProperty(exports,"__esModule",{value:!0});var _typeof="function"==typeof Symbol&&"symbol"==typeof Symbol.iterator?function(t){return typeof t}:function(t){return t&&"function"==typeof Symbol&&t.constructor===Symbol&&t!==Symbol.prototype?"symbol":typeof t},_createClass=function(){function t(t,e){for(var r=0;r<e.length;r++){var o=e[r];o.enumerable=o.enumerable||!1,o.configurable=!0,"value"in o&&(o.writable=!0),Object.defineProperty(t,o.key,o)}}return function(e,r,o){return r&&t(e.prototype,r),o&&t(e,o),e}}(),_get=function t(e,r,o){null===e&&(e=Function.prototype);var n=Object.getOwnPropertyDescriptor(e,r);if(void 0===n){var a=Object.getPrototypeOf(e);return null===a?void 0:t(a,r,o)}if("value"in n)return n.value;var i=n.get;if(void 0!==i)return i.call(o)},_native=require("./native.js"),_native2=_interopRequireDefault(_native),_component2=require("./component.js"),_component3=_interopRequireDefault(_component2),_util=require("./util.js"),_util2=_interopRequireDefault(_util),_class=function(t){function e(){var t,r,o,n;_classCallCheck(this,e);for(var a=arguments.length,i=Array(a),u=0;u<a;u++)i[u]=arguments[u];return r=o=_possibleConstructorReturn(this,(t=e.__proto__||Object.getPrototypeOf(e)).call.apply(t,[this].concat(i))),o.$isComponent=!1,o.$preloadData=void 0,o.$prefetchData=void 0,n=r,_possibleConstructorReturn(o,n)}return _inherits(e,t),_createClass(e,[{key:"$init",value:function(t,r){this.$parent=r,this.$root=this,r.$wxapp||(r.$wxapp=getApp()),this.$wxapp=r.$wxapp,_get(e.prototype.__proto__||Object.getPrototypeOf(e.prototype),"$init",this).call(this,t,this)}},{key:"onLoad",value:function(){_get(e.prototype.__proto__||Object.getPrototypeOf(e.prototype),"onLoad",this).call(this)}},{key:"onUnload",value:function(){_get(e.prototype.__proto__||Object.getPrototypeOf(e.prototype),"onUnload",this).call(this)}},{key:"$preload",value:function(t,e){if("object"===(void 0===t?"undefined":_typeof(t))){var r=void 0;for(r in t)this.$preload(r,t[r])}else(this.$preloadData?this.$preloadData:this.$preloadData={})[t]=e}},{key:"$route",value:function(t,e){var r=arguments.length>2&&void 0!==arguments[2]?arguments[2]:{};if("string"==typeof e){var o=e+"?";if(r){var n=void 0;for(n in r)o+=n+"="+r[n]+"&"}o=o.substring(0,o.length-1),e={url:o}}else r=_util2.default.$getParams(e.url);this.$parent.__route__||(this.$parent.__route__=getCurrentPages()[0].__route__,this.$parent.__wxWebviewId__=getCurrentPages()[0].__wxWebviewId__);var a="/"!==this.$parent.__route__[0]?"/"+this.$parent.__route__:this.$parent.__route__,i=_util2.default.$resolvePath(a,e.url.split("?")[0]),u=this.$parent.$pages[i];if(u&&u.onPrefetch){var l=this.$parent.__prevPage__,p=void 0;l&&l.$preloadData&&(p=l.$preloadData),u.$prefetchData=u.onPrefetch(r,{from:this,preload:p})}return _native2.default[t](e)}},{key:"$redirect",value:function(t,e){return this.$route("redirectTo",t,e)}},{key:"$navigate",value:function(t,e){return this.$route("navigateTo",t,e)}},{key:"$switch",value:function(t){return"string"==typeof t&&(t={url:t}),_native2.default.switchTab(t)}},{key:"$back",value:function(t){var e=t||{};return"number"==typeof e&&(e={delta:e}),e.delta||(e.delta=1),_native2.default.navigateBack(e)}}]),e}(_component3.default);exports.default=_class; 
 			}); 
		define("npm/wepy/lib/util.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			
"use strict";function isImmutable(t){return!(!t||"object"!==(void 0===t?"undefined":_typeof(t)))&&!!["@@__IMMUTABLE_ITERABLE__@@","@@__IMMUTABLE_KEYED__@@","@@__IMMUTABLE_INDEXED__@@","@@__IMMUTABLE_ORDERED__@@","@@__IMMUTABLE_RECORD__@@"].filter(function(e){return t[e]}).length}Object.defineProperty(exports,"__esModule",{value:!0});var _typeof="function"==typeof Symbol&&"symbol"==typeof Symbol.iterator?function(t){return typeof t}:function(t){return t&&"function"==typeof Symbol&&t.constructor===Symbol&&t!==Symbol.prototype?"symbol":typeof t};exports.default={$isEmpty:function(t){return 0===Object.keys(t).length},$isEqual:function(t,e,r,n){if(isImmutable(t))return t.equals(e);if(isImmutable(e))return e.equals(t);if(t===e)return 0!==t||1/t==1/e;if(t!==t)return e!==e;if(!t||!e)return t===e;var o=void 0===t?"undefined":_typeof(t);return("function"===o||"object"===o||"object"===(void 0===e?"undefined":_typeof(e)))&&this.$isDeepEqual(t,e,r,n)},$isDeepEqual:function(t,e,r,n){isImmutable(t)&&(t=t.toJS()),isImmutable(e)&&(e=e.toJS());var o=this,i=toString.call(t);if(i!==toString.call(e))return!1;switch(i){case"[object RegExp]":case"[object String]":return""+t==""+e;case"[object Number]":return+t!=+t?+e!=+e:0==+t?1/+t==1/e:+t==+e;case"[object Date]":case"[object Boolean]":return+t==+e;case"[object Symbol]":var u="undefined"!=typeof Symbol?Symbol.prototype:null;return u.valueOf.call(t)===u.valueOf.call(e)}var c="[object Array]"===i;if(!c){if("object"!==(void 0===t?"undefined":_typeof(t))||"object"!==(void 0===e?"undefined":_typeof(e)))return t===e;var a=t.constructor,l=e.constructor;if(a!==l&&!("function"==typeof a&&a instanceof a&&"function"==typeof l&&l instanceof l)&&"constructor"in t&&"constructor"in e)return!1}r=r||[],n=n||[];for(var f=r.length;f--;)if(r[f]===t)return n[f]===e;if(r.push(t),n.push(e),c){if((f=t.length)!==e.length)return!1;for(;f--;)if(!o.$isEqual(t[f],e[f],r,n))return!1}else{var s,p=Object.keys(t);if(f=p.length,Object.keys(e).length!==f)return!1;for(;f--;)if(s=p[f],!o.$has(e,s)||!o.$isEqual(t[s],e[s],r,n))return!1}return r.pop(),n.pop(),!0},$has:function(t,e){if("[object Array]"!==toString.call(e))return t&&hasOwnProperty.call(t,e);for(var r=e.length,n=0;n<r;n++){var o=e[n];if(!t||!hasOwnProperty.call(t,o))return!1;t=t[o]}return!!r},$extend:function(){var t,e,r,n,o,i,u=arguments[0]||{},c=1,a=arguments.length,l=!1,f=this;for("boolean"==typeof u&&(l=u,u=arguments[c]||{},c++),"object"!==(void 0===u?"undefined":_typeof(u))&&"function"!=typeof u&&(u={}),c===a&&(u=this,c--);c<a;c++)if(t=arguments[c])for(e in t)r=u[e],n=t[e],u!==n&&(l&&n&&(f.$isPlainObject(n)||(o=Array.isArray(n)))?(o?(o=!1,i=r&&Array.isArray(r)?r:[]):i=r&&f.$isPlainObject(r)?r:{},u[e]=f.$extend(l,i,n)):u[e]=n);return u},$copy:function(t){var e=arguments.length>1&&void 0!==arguments[1]&&arguments[1];return Array.isArray(t)?this.$extend(e,[],t):""+t=="null"?t:"object"===(void 0===t?"undefined":_typeof(t))?isImmutable(t)?t:this.$extend(e,{},t):t},$isPlainObject:function(t){var e,r;return!(!t||"[object Object]"!==Object.prototype.toString.call(t))&&(!(e=Object.getPrototypeOf(t))||"function"==typeof(r=Object.prototype.hasOwnProperty.call(e,"constructor")&&e.constructor)&&Object.prototype.hasOwnProperty.toString.call(r)===Object.prototype.hasOwnProperty.toString.call(Object))},$resolvePath:function(t,e){if(!e)return t;if("/"===e[0])return e=e.substr(1),this.$resolvePath("",e);if("."!==e[0])return this.$resolvePath(t,"./"+e);var r=t.split("/");return"."===e[0]&&"/"===e[1]?(e=e.substr(2),"."!==e[0]?(r.length?r[r.length-1]=e:r=[e],1===r.length?"/"+r[0]:r.join("/")):this.$resolvePath(r.join("/"),e)):"."===e[0]&&"."===e[1]&&"/"===e[2]?(e=e.replace(/^\.*/gi,""),r.pop(),this.$resolvePath(r.join("/"),"."+e)):"."===e[0]?this.$resolvePath(t,e.substr(1)):void 0},$getParams:function(t){var e={},r=t.indexOf("?");if(-1!==r){var n=t.substr(r+1),o=void 0;n.split("&").forEach(function(t){o=t.split("="),e[o[0]]=decodeURIComponent(o[1])})}return e},isImmutable:isImmutable,hyphenate:function(t){return t.replace(/([^-])([A-Z])/g,"$1-$2").replace(/([^-])([A-Z])/g,"$1-$2").toLowerCase()},camelize:function(t){return t.replace(/-(\w)/g,function(t,e){return e?e.toUpperCase():""})}}; 
 			}); 
		define("npm/wepy/lib/wepy.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			
"use strict";function _interopRequireDefault(e){return e&&e.__esModule?e:{default:e}}Object.defineProperty(exports,"__esModule",{value:!0});var _app=require("./app.js"),_app2=_interopRequireDefault(_app),_page=require("./page.js"),_page2=_interopRequireDefault(_page),_component=require("./component.js"),_component2=_interopRequireDefault(_component),_event=require("./event.js"),_event2=_interopRequireDefault(_event),_base=require("./base.js"),_base2=_interopRequireDefault(_base),_util=require("./util.js"),_util2=_interopRequireDefault(_util),_mixin=require("./mixin.js"),_mixin2=_interopRequireDefault(_mixin);exports.default={event:_event2.default,app:_app2.default,component:_component2.default,page:_page2.default,mixin:_mixin2.default,$createApp:_base2.default.$createApp,$createPage:_base2.default.$createPage,$isEmpty:_util2.default.$isEmpty,$isEqual:_util2.default.$isEqual,$isDeepEqual:_util2.default.$isDeepEqual,$has:_util2.default.$has,$extend:_util2.default.$extend,$isPlainObject:_util2.default.$isPlainObject,$copy:_util2.default.$copy}; 
 			}); 
		define("app.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			
"use strict";function _interopRequireDefault(e){return e&&e.__esModule?e:{default:e}}function _asyncToGenerator(e){return function(){var t=e.apply(this,arguments);return new Promise(function(e,n){function r(a,o){try{var i=t[a](o),s=i.value}catch(e){return void n(e)}if(!i.done)return Promise.resolve(s).then(function(e){r("next",e)},function(e){r("throw",e)});e(s)}return r("next")})}}function _classCallCheck(e,t){if(!(e instanceof t))throw new TypeError("Cannot call a class as a function")}function _possibleConstructorReturn(e,t){if(!e)throw new ReferenceError("this hasn't been initialised - super() hasn't been called");return!t||"object"!=typeof t&&"function"!=typeof t?e:t}function _inherits(e,t){if("function"!=typeof t&&null!==t)throw new TypeError("Super expression must either be null or a function, not "+typeof t);e.prototype=Object.create(t&&t.prototype,{constructor:{value:e,enumerable:!1,writable:!0,configurable:!0}}),t&&(Object.setPrototypeOf?Object.setPrototypeOf(e,t):e.__proto__=t)}Object.defineProperty(exports,"__esModule",{value:!0});var _createClass=function(){function e(e,t){for(var n=0;n<t.length;n++){var r=t[n];r.enumerable=r.enumerable||!1,r.configurable=!0,"value"in r&&(r.writable=!0),Object.defineProperty(e,r.key,r)}}return function(t,n,r){return n&&e(t.prototype,n),r&&e(t,r),t}}(),_wepy=require("./npm/wepy/lib/wepy.js"),_wepy2=_interopRequireDefault(_wepy);require("./npm/wepy-async-function/index.js");var _default=function(e){function t(){_classCallCheck(this,t);var e=_possibleConstructorReturn(this,(t.__proto__||Object.getPrototypeOf(t)).call(this));return e.config={pages:["pages/index","pages/activate","pages/upValue","pages/learnIndex","pages/report","pages/reviewIndex","pages/reviewFilter","pages/points","pages/web","pages/ranking","pages/study","pages/upValueList","pages/studyData","pages/wrongTopic","pages/share"],subPackages:[{root:"pages/subPages",pages:["vip"]}],window:{backgroundTextStyle:"light",navigationBarBackgroundColor:"#fff",navigationBarTitleText:"WeChat",navigationBarTextStyle:"black",backgroundColor:"#FFFFFF",backgroundColorTop:"#FFFFFF",backgroundColorBottom:"#FFFFFF"},navigateToMiniProgramAppIdList:["wxfa0c84e2ddfb8989","wx8abaf00ee8c3202e"],__usePrivacyCheck__:!0},e.globalData={sence:null,userInfo:null,appid:"",appSecret:"",openId:"",hasPay:!1},e.use("promisify"),e}return _inherits(t,e),_createClass(t,[{key:"onShow",value:function(e){this.globalData.scene=e.scene}}]),_createClass(t,[{key:"onLaunch",value:function(){if(wx.setStorageSync("__KC_LOG_H",JSON.parse(_wepy2.default.$appConfig.__KC_LOG_H)),wx.setStorageSync("bdId","zhengzhi1000"),wx.canIUse("getUpdateManager")){var e=wx.getUpdateManager();e.onUpdateReady(function(){wx.showModal({title:"更新提示",content:"新版本已经准备好，是否重启应用",showCancel:!1,confirmText:"确定",success:function(){function t(e){return n.apply(this,arguments)}var n=_asyncToGenerator(regeneratorRuntime.mark(function t(n){return regeneratorRuntime.wrap(function(t){for(;;)switch(t.prev=t.next){case 0:n.confirm&&e.applyUpdate();case 1:case"end":return t.stop()}},t,this)}));return t}()})})}console.log("=========app onLaunch========")}}]),t}(_wepy2.default.app);App(require("./npm/wepy/lib/wepy.js").default.$createApp(_default,{__KC_LOG_H:'"https://dotlog.kaochong.com"',noPromiseAPI:["createSelectorQuery"],rootURL:"https://politics1000.kaochong.com/politics1000"})); 
 			}); 	require("app.js");
 		__wxRoute = 'pages/index';__wxRouteBegin = true; 	__wxAppCurrentFile__ = 'pages/index.js';	define("pages/index.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			
"use strict";function _interopRequireDefault(e){return e&&e.__esModule?e:{default:e}}function _asyncToGenerator(e){return function(){var t=e.apply(this,arguments);return new Promise(function(e,n){function a(r,i){try{var o=t[r](i),s=o.value}catch(e){return void n(e)}if(!o.done)return Promise.resolve(s).then(function(e){a("next",e)},function(e){a("throw",e)});e(s)}return a("next")})}}function _classCallCheck(e,t){if(!(e instanceof t))throw new TypeError("Cannot call a class as a function")}function _possibleConstructorReturn(e,t){if(!e)throw new ReferenceError("this hasn't been initialised - super() hasn't been called");return!t||"object"!=typeof t&&"function"!=typeof t?e:t}function _inherits(e,t){if("function"!=typeof t&&null!==t)throw new TypeError("Super expression must either be null or a function, not "+typeof t);e.prototype=Object.create(t&&t.prototype,{constructor:{value:e,enumerable:!1,writable:!0,configurable:!0}}),t&&(Object.setPrototypeOf?Object.setPrototypeOf(e,t):e.__proto__=t)}function _applyDecoratedDescriptor(e,t,n,a,r){var i={};return Object.keys(a).forEach(function(e){i[e]=a[e]}),i.enumerable=!!i.enumerable,i.configurable=!!i.configurable,("value"in i||i.initializer)&&(i.writable=!0),i=n.slice().reverse().reduce(function(n,a){return a(e,t,n)||n},i),r&&void 0!==i.initializer&&(i.value=i.initializer?i.initializer.call(r):void 0,i.initializer=void 0),void 0===i.initializer&&(Object.defineProperty(e,t,i),i=null),i}Object.defineProperty(exports,"__esModule",{value:!0});var _extends=Object.assign||function(e){for(var t=1;t<arguments.length;t++){var n=arguments[t];for(var a in n)Object.prototype.hasOwnProperty.call(n,a)&&(e[a]=n[a])}return e},_createClass=function(){function e(e,t){for(var n=0;n<t.length;n++){var a=t[n];a.enumerable=a.enumerable||!1,a.configurable=!0,"value"in a&&(a.writable=!0),Object.defineProperty(e,a.key,a)}}return function(t,n,a){return n&&e(t.prototype,n),a&&e(t,a),t}}(),_dec,_dec2,_dec3,_desc,_value,_class,_wepy=require("./../npm/wepy/lib/wepy.js"),_wepy2=_interopRequireDefault(_wepy),_api=require("./../common/api.js"),_api2=_interopRequireDefault(_api),_common=require("./../common/common.js"),_common2=_interopRequireDefault(_common),_storage=require("./../common/storage.js"),_storage2=_interopRequireDefault(_storage),_constant=require("./../common/constant.js"),_constant2=_interopRequireDefault(_constant),_KcShowGuide=require("./../components/KcShowGuide.js"),_KcShowGuide2=_interopRequireDefault(_KcShowGuide),_OnlineModal=require("./../components/OnlineModal.js"),_OnlineModal2=_interopRequireDefault(_OnlineModal),_decorator=require("./../common/decorator.js"),_KcLoading=require("./../components/KcLoading.js"),_KcLoading2=_interopRequireDefault(_KcLoading),_KcErrorModal=require("./../components/KcErrorModal.js"),_KcErrorModal2=_interopRequireDefault(_KcErrorModal),_kcUpdateModle=require("./../components/kcUpdateModle.js"),_kcUpdateModle2=_interopRequireDefault(_kcUpdateModle),_KcVipModal=require("./../components/KcVipModal.js"),_KcVipModal2=_interopRequireDefault(_KcVipModal),_receiveVipModal=require("./../components/receiveVipModal.js"),_receiveVipModal2=_interopRequireDefault(_receiveVipModal),_KcUpValue=require("./../components/KcUpValue.js"),_KcUpValue2=_interopRequireDefault(_KcUpValue),_eChart=require("./../common/e-chart.js"),_eChart2=_interopRequireDefault(_eChart),_kcLog=require("./../npm/@kc-base/kc-log/dist/kc-log.js"),_kcLog2=_interopRequireDefault(_kcLog),_hasChangeRoute=!1,Home=(_dec=(0,_decorator.trycatch)(),_dec2=(0,_decorator.trycatch)(),_dec3=(0,_decorator.trycatch)(),_class=function(e){function t(){var e,n,a,r;_classCallCheck(this,t);for(var i=arguments.length,o=Array(i),s=0;s<i;s++)o[s]=arguments[s];return n=a=_possibleConstructorReturn(this,(e=t.__proto__||Object.getPrototypeOf(t)).call.apply(e,[this].concat(o))),a.config={navigationBarTitleText:"",navigationBarTextStyle:"black",navigationBarBackgroundColor:"#6787FF"},a.$repeat={},a.$props={KcShowGuide:{"xmlns:v-bind":"","v-bind:show.sync":"showGuide"},KcLoading:{"xmlns:v-bind":"","v-bind:loadingHide.sync":"loadingHide"},vipModle:{"xmlns:v-bind":"","v-bind:hasVip.sync":"hasVip","v-bind:status.sync":"helpStatus"},receiveVipModal:{"xmlns:v-bind":"","v-bind:isAuth.sync":"isAuth"},KcUpValue:{"xmlns:v-bind":"","v-bind:title.sync":"title","v-bind:text1.sync":"text1","v-bind:text2.sync":"text2","v-bind:text3.sync":"text3","v-bind:leftBtnText.sync":"leftBtnText","v-bind:rightBtnText.sync":"rightBtnText","v-bind:leftCb.sync":"leftCb","v-bind:rightCb.sync":"rightCb","v-bind:imgSrc.sync":"imgSrc"}},a.$events={},a.components={KcShowGuide:_KcShowGuide2.default,OnlineModal:_OnlineModal2.default,KcLoading:_KcLoading2.default,KcErrorModal:_KcErrorModal2.default,kcUpdateModle:_kcUpdateModle2.default,vipModle:_KcVipModal2.default,receiveVipModal:_receiveVipModal2.default,KcUpValue:_KcUpValue2.default},a.mixins=[],a.data={lock:!1,selectSubjectShow:!1,loadingHide:!0,options:{},unlockInfo:{},showMask:!1,unlockModle:!1,noUpModle:!1,userInfo:{head:"",upValue:"",points:"",pointsRank:"",pointsChange:"",subject:"",subjectRank:"",subjectChange:""},learned:!1,canFree:!1,subjectList:[],online:"",isComplete:!1,firstAnswer:!1,isStart:!1,completeNum:0,banner:"",hasVip:!1,showGuide:!1,isFirstOnShow:!0,isAuth:!1,isNew:!0,subjectUnlearn:!1,welcomeShow:!1,payloadFromApp:{},payloadFromWeb:{},handleAPPWebSuccess:!1,helpStatus:!1,isSubscribeShow:!1,publicCourseCount:0,noPointsData:!1,swiperList:[],createTime:0,imgSrc:"",title:"",text1:"",text2:"",text3:"",leftBtnText:"",rightBtnText:"",leftCb:null,rightCb:null,isnewuser:0,animation:null,indexCourse:{},subjectData:[],pointData:[],bannerBtn:{},bannerPic:{},bannerMiniprogram:{},checkStatus:!1,showShare:!1,showPrivacy:!1},a.computed={},a.methods={handleOpenPrivacyContract:function(){wx.openPrivacyContract({success:function(){},fail:function(){},complete:function(){}})},handleAgreePrivacyAuthorization:function(){this.resolvePrivacyAuthorization({buttonId:"agree-btn",event:"agree"}),this.showPrivacy=!1},cancelPrivacy:function(){this.resolvePrivacyAuthorization({event:"disagree"}),this.showPrivacy=!1},goShare:function(){_kcLog2.default.send({pagename:"HomePage",name:"freeUnlockClick",category:"webClick",pt:"mini"});_wepy2.default.navigateTo({url:"web?url="+encodeURIComponent("https://mp.weixin.qq.com/s/GocmnuOPGzRBqUgvPFzpKw")})},handleContact:function(e){_kcLog2.default.send({pagename:"HomePage",name:"messageCardClick",category:"webClick",pt:"mini"}),_kcLog2.default.send({pagename:"HomePage",name:"joinGroupClick",category:"webClick",pt:"mini"})},goVip:function(){_kcLog2.default.send({pagename:"HomePage",name:"vipClick",category:"webClick",pt:"mini"});_wepy2.default.navigateTo({url:"web?url="+encodeURIComponent("https://mp.weixin.qq.com/s?__biz=MzU2ODcxNTYxNQ==&mid=2247709644&idx=1&sn=3c4d5f76282c25f9f002ec736bd29f51&chksm=fc8443fccbf3caea2eacaebff39971de1e76aa63c6a4d984c933830e6d9991137062adf7ae07#rd")})},LearnWxLogin:function(){function e(e){return t.apply(this,arguments)}var t=_asyncToGenerator(regeneratorRuntime.mark(function e(t){var n,a,r=this;return regeneratorRuntime.wrap(function(e){for(;;)switch(e.prev=e.next){case 0:if(!this.lock){e.next=2;break}return e.abrupt("return",!1);case 2:_kcLog2.default.send({pagename:"HomePage",name:"signupWindowShow",category:"webShow",pt:"mini",bundleid:"zhengzhi1000"}),this.lock=!0,n=this.wxSilentLogin(),a=this.wxGetUserProfile(),Promise.all([n,a]).then(function(){var e=_asyncToGenerator(regeneratorRuntime.mark(function e(t){var n,a,i,o;return regeneratorRuntime.wrap(function(e){for(;;)switch(e.prev=e.next){case 0:return _kcLog2.default.send({pagename:"HomePage",name:"loginClick",category:"login",pt:"mini",bundleid:"zhengzhi1000"}),n=t[0],a=t[1].iv,i=t[1].encryptedData,o={code:n,encryptedData:i,iv:a},console.log(o),e.next=8,_api2.default.register(o);case 8:r.lock=!1,wx.reLaunch({url:"index"});case 10:case"end":return e.stop()}},e,r)}));return function(t){return e.apply(this,arguments)}}()).catch(function(){r.showMask=!0,r.selectSubjectShow=!0,r.lock=!1,_kcLog2.default.send({pagename:"HomePage",name:"refuseClick",category:"webClick",pt:"mini",bundleid:"zhengzhi1000"}),r.$apply()});case 7:case"end":return e.stop()}},e,this)}));return e}(),wxLogin:function(){function e(e){return t.apply(this,arguments)}var t=_asyncToGenerator(regeneratorRuntime.mark(function e(t){var n,a,r=this;return regeneratorRuntime.wrap(function(e){for(;;)switch(e.prev=e.next){case 0:if(!this.lock){e.next=2;break}return e.abrupt("return",!1);case 2:_kcLog2.default.send({pagename:"HomePage",name:"signupWindowShow",category:"webShow",pt:"mini",bundleid:"zhengzhi1000"}),this.lock=!0,n=this.wxSilentLogin(),a=this.wxGetUserProfile(),Promise.all([n,a]).then(function(){var e=_asyncToGenerator(regeneratorRuntime.mark(function e(t){var n,a,i,o;return regeneratorRuntime.wrap(function(e){for(;;)switch(e.prev=e.next){case 0:return _kcLog2.default.send({pagename:"HomePage",name:"loginClick",category:"login",pt:"mini",bundleid:"zhengzhi1000"}),n=t[0],a=t[1].iv,i=t[1].encryptedData,o={code:n,encryptedData:i,iv:a},console.log(o),e.next=8,_api2.default.register(o);case 8:r.lock=!1,r.$apply(),wx.reLaunch({url:"index"});case 11:case"end":return e.stop()}},e,r)}));return function(t){return e.apply(this,arguments)}}()).catch(function(){_kcLog2.default.send({pagename:"HomePage",name:"refuseClick",category:"webClick",pt:"mini",bundleid:"zhengzhi1000"}),r.lock=!1,r.$apply()});case 7:case"end":return e.stop()}},e,this)}));return e}(),gotoRanking:function(e){_kcLog2.default.send({pagename:"HomePage",name:"rankClick",category:"webClick",pt:"mini",bundleid:"zhengzhi1000"});var t={rankType:e};this.$navigate("ranking",t),this.hasChangeRoute()},welcomeAnimationstart:function(){console.log("welcomeAnimationstart")},welcomeAnimationend:function(){console.log("welcomeAnimationend"),this.welcomeShow=!1},startReview:function(){function e(){return t.apply(this,arguments)}var t=_asyncToGenerator(regeneratorRuntime.mark(function e(){return regeneratorRuntime.wrap(function(e){for(;;)switch(e.prev=e.next){case 0:return e.next=2,_storage2.default.set("isStart",!0);case 2:this.isStart=!0,this.$apply();case 4:case"end":return e.stop()}},e,this)}));return e}(),gotoReview:function(e){_kcLog2.default.send({pagename:"HomePage",name:"reviewClick",category:"webClick",pt:"mini"}),this.learned&&this.isAuth&&(wx.navigateTo({url:"reviewIndex?sid="+e}),this.hasChangeRoute())},gotoUnlock:function(){function e(){return t.apply(this,arguments)}var t=_asyncToGenerator(regeneratorRuntime.mark(function e(){return regeneratorRuntime.wrap(function(e){for(;;)switch(e.prev=e.next){case 0:return e.next=2,this.unlockCourse();case 2:case"end":return e.stop()}},e,this)}));return e}(),hideModle:function(){this.showMask=!1,this.unlockModle=!1,this.noUpModle=!1,this.selectSubjectShow=!1,this.setChart()},goSentenceApp:function(){wx.reportAnalytics("index_20_click_gosentenceapp",{}),_wepy2.default.navigateToMiniProgram({appId:"wxfa0c84e2ddfb8989",envVersion:"release"})},goCourse:function(e){_kcLog2.default.send({pagename:"HomePage",name:"courseAdClick",category:"webClick",pt:"mini"}),_api2.default.clickPublicCourse(),_wepy2.default.navigateToMiniProgram({appId:e.appId,envVersion:"release",path:e.page})},goWeb:function(e){_kcLog2.default.send({pagename:"HomePage",name:"bannerClick",category:"webClick",pt:"mini",bundleid:"zhengzhi1000"}),_wepy2.default.navigateTo({url:"web?url="+encodeURIComponent(e)})},goAdvice:function(){wx.reportAnalytics("index_20_cttlick_goadvice",{});_wepy2.default.navigateTo({url:"web?url="+encodeURIComponent("https://mp.weixin.qq.com/s/1L1D1oqE3AFv-sUjnGc8aQ")})},selectSubject:function(){this.showMask=!0,this.selectSubjectShow=!0},goLearn:function(e,t,n,a){var r=["","马原","毛中特","史纲","思法"];if(console.log(e,t,n,a),_kcLog2.default.send({pagename:"HomePage",name:"subjectClick",category:"webClick",content:r[e],pt:"mini"}),!this.isAuth)return void(3===e&&0===t?(wx.navigateTo({url:"learnIndex?sid="+e+"&day=1"}),this.hasChangeRoute()):wx.showToast({title:"请授权登录",icon:"none",duration:3e3}));t<n&&n<=a?(console.log("已解锁首页去课程列表","learnIndex?sid="+e+"&day="+(t+1)),wx.navigateTo({url:"learnIndex?sid="+e+"&day="+(t+1)}),this.hasChangeRoute()):t===a?wx.showToast({title:"已全部学完",icon:"success",duration:3e3}):this.userInfo.upValue<20?wx.showToast({title:"剩余up值不够，去收集更多吧",icon:"none",duration:3e3}):this.unlockCourse(e,n+1)},tapAvatar:function(){!this.hasVip&&this.isAuth&&(_kcLog2.default.send({pagename:"HomePage",name:"myUpClick",category:"webClick",pt:"mini"}),this.gotoUpvalue())},imgError:function(e){console.log("图片错误",e)},subscribe:function(){_kcLog2.default.send({pagename:"HomePage",name:"remindClick",category:"webClick",pt:"mini"}),wx.requestSubscribeMessage({tmplIds:["CYWPM2zY4_XAQitSdB8a9vKNtH4rdIf08skg-LTKVH4"],success:function(e){_kcLog2.default.send({pagename:"HomePage",name:"remindAgreeClick",category:"webClick",pt:"mini"}),_api2.default.subscribeMessage(e)},fail:function(){_kcLog2.default.send({pagename:"HomePage",name:"remindRefuseClick",category:"webClick",pt:"mini"})}}),this.isSubscribeShow=!1,_storage2.default.set("subscribeClose",Math.round(new Date/1e3))},goStudyData:function(){_kcLog2.default.send({pagename:"HomePage",name:"wrongChapterClick",category:"webClick",pt:"mini"}),this.$navigate("studyData")}},r=n,_possibleConstructorReturn(a,r)}return _inherits(t,e),_createClass(t,[{key:"translate",value:function(){var e=this;setTimeout(function(){e.animation.translateY(-20).step(),e.setData({animation:e.animation.export()})},1e3),this.$apply()}},{key:"onLoad",value:function(){function e(e){return t.apply(this,arguments)}var t=_asyncToGenerator(regeneratorRuntime.mark(function e(t){var n=this;return regeneratorRuntime.wrap(function(e){for(;;)switch(e.prev=e.next){case 0:return _kcLog2.default.send({pagename:"HomePage",name:"homePageView",category:"webPageView",pt:"mini"}),wx.onNeedPrivacyAuthorization(function(e){console.log("onNeedPrivacyAuthorization"),n.showPrivacy=!0,n.resolvePrivacyAuthorization=e,n.$apply()}),this.width=750/wx.getSystemInfoSync().windowWidth,this.animation=wx.createAnimation(),this.options=t,_storage2.default.set("contactBack",!1),e.next=8,this.posterHelp();case 8:case"end":return e.stop()}},e,this)}));return e}()},{key:"onShow",value:function(){function e(){return t.apply(this,arguments)}var t=_asyncToGenerator(regeneratorRuntime.mark(function e(){var t,n,a,r,i=this;return regeneratorRuntime.wrap(function(e){for(;;)switch(e.prev=e.next){case 0:return this.handleShowGuide(),e.next=3,this.handleFromAPPWeb();case 3:return e.next=5,this.loadIndexData();case 5:return e.next=7,this.getIndexBanner();case 7:return e.next=9,_storage2.default.get(_constant2.default.KEY_IS_NEW);case 9:if(e.t0=e.sent,e.t0){e.next=12;break}e.t0=!1;case 12:if(this.isNew=e.t0,this.$apply(),!this.isFirstOnShow){e.next=18;break}return this.isFirstOnShow=!1,e.next=18,this.handleOptions();case 18:return e.next=20,_storage2.default.get(_constant2.default.KEY_INDEX_PAID_WELCOME);case 20:if(e.t1=e.sent,e.t1){e.next=23;break}e.t1=!1;case 23:return t=e.t1,!t&&this.hasVip&&this.isAuth&&setTimeout(function(){i.welcomeShow=!0,i.$apply(),_storage2.default.set(_constant2.default.KEY_INDEX_PAID_WELCOME,!0)},1e3),e.next=27,_storage2.default.get("subscribeClose");case 27:if(e.t2=e.sent,e.t2){e.next=30;break}e.t2=0;case 30:return n=e.t2,e.next=33,_storage2.default.get("studyTime");case 33:if(e.t3=e.sent,e.t3){e.next=36;break}e.t3=0;case 36:a=e.t3,r=Math.round(new Date/1e3),r-n>86400&&a<6&&a>0?(this.isSubscribeShow=!0,this.translate(),_kcLog2.default.send({pagename:"HomePage",name:"remindWindowShow",category:"webShow",pt:"mini"})):this.isSubscribeShow=!1,wx.reportAnalytics("index_20_show",{isnewuser:this.isnewuser});case 40:case"end":return e.stop()}},e,this)}));return e}()},{key:"posterHelp",value:function(){function e(){return t.apply(this,arguments)}var t=_asyncToGenerator(regeneratorRuntime.mark(function e(){var t,n,a;return regeneratorRuntime.wrap(function(e){for(;;)switch(e.prev=e.next){case 0:if(this.handleAPPWebSuccess){e.next=19;break}return t=decodeURIComponent(this.options.scene),this.payloadFromWeb.id=_common2.default.getQueryParam(t,"id"),e.next=5,_storage2.default.get("contactBack");case 5:if(e.t0=e.sent,e.t0){e.next=8;break}e.t0=!1;case 8:if(n=e.t0,this.$apply(),!this.payloadFromWeb.id||n){e.next=19;break}return e.next=13,_api2.default.posterHelp({mpOpenId:this.payloadFromWeb.id});case 13:return a=e.sent,5025===a.helpStatus?wx.showToast({title:"助力成功",icon:"none",duration:3e3}):wx.showToast({title:"助力失败",icon:"none",duration:3e3}),this.$apply(),this.handleAPPWebSuccess=!0,this.$apply(),e.abrupt("return",!1);case 19:case"end":return e.stop()}},e,this)}));return e}()},{key:"handleFromAPPWeb",value:function(){function e(){return t.apply(this,arguments)}var t=_asyncToGenerator(regeneratorRuntime.mark(function e(){var t;return regeneratorRuntime.wrap(function(e){for(;;)switch(e.prev=e.next){case 0:if(this.handleAPPWebSuccess){e.next=22;break}if(this.loadingHide=!1,this.payloadFromApp.uid=this.options.uid,this.payloadFromApp.security=this.options.security,this.payloadFromApp.source=this.options.source,this.payloadFromApp.timeStamp=this.options.timeStamp,this.payloadFromApp.teachingCourseId=this.options.teachingCourseId,this.payloadFromApp.tag=this.options.tag,t=decodeURIComponent(this.options.scene),this.payloadFromWeb.key=_common2.default.getQueryParam(t,"key"),this.payloadFromWeb.name=_common2.default.getQueryParam(t,"miniprogram"),this.$apply(),"2"!==this.payloadFromWeb.name||!this.payloadFromWeb.key){e.next=17;break}return e.next=15,_api2.default.updateAppUserStatus({key:this.payloadFromWeb.key});case 15:e.next=20;break;case 17:if(!this.payloadFromApp.uid){e.next=20;break}return e.next=20,_api2.default.updateAppUserStatus(_extends({},this.payloadFromApp));case 20:this.handleAPPWebSuccess=!0,this.$apply();case 22:case"end":return e.stop()}},e,this)}));return e}()},{key:"getIndexBanner",value:function(){function e(){return t.apply(this,arguments)}var t=_asyncToGenerator(regeneratorRuntime.mark(function e(){var t;return regeneratorRuntime.wrap(function(e){for(;;)switch(e.prev=e.next){case 0:return e.next=2,_api2.default.indexBanner();case 2:t=e.sent,this.bannerBtn=t.banners[0],this.bannerPic=t.banners[1],this.bannerMiniprogram=t.banners[2];case 6:case"end":return e.stop()}},e,this)}));return e}()},{key:"unlockCourse",value:function(){function e(e,n){return t.apply(this,arguments)}var t=_asyncToGenerator(regeneratorRuntime.mark(function e(t,n){var a;return regeneratorRuntime.wrap(function(e){for(;;)switch(e.prev=e.next){case 0:return e.prev=0,e.next=3,_storage2.default.get("token");case 3:if(e.t0=e.sent,e.t0){e.next=6;break}e.t0=0;case 6:return a=e.t0,e.next=9,_api2.default.unlockCourse({subjectId:t,stage:n,token:a});case 9:wx.showToast({title:"-20up值，解锁成功",icon:"none",duration:3e3}),setTimeout(function(){wx.navigateTo({url:"learnIndex?sid="+t+"&day="+n})},2e3),this.hasChangeRoute(),e.next=17;break;case 14:e.prev=14,e.t1=e.catch(0),wx.showToast({title:"解锁失败,请重试",icon:"none",duration:3e3});case 17:case"end":return e.stop()}},e,this,[[0,14]])}));return e}()},{key:"handleShowGuide",value:function(){function e(){return t.apply(this,arguments)}var t=_asyncToGenerator(regeneratorRuntime.mark(function e(){var t;return regeneratorRuntime.wrap(function(e){for(;;)switch(e.prev=e.next){case 0:return e.next=2,_storage2.default.get("hasShowGuide");case 2:if(e.t0=e.sent,e.t0){e.next=5;break}e.t0=!1;case 5:t=e.t0,_hasChangeRoute&&!t&&(this.showGuide=!0);case 7:case"end":return e.stop()}},e,this)}));return e}()},{key:"hasChangeRoute",value:function(){_hasChangeRoute=!0}},{key:"gotoLogin",value:function(){this.$navigate("login")}},{key:"goUpvalue",value:function(){_kcLog2.default.send({pagename:"HomePage",name:"guideClick",category:"webClick",pt:"mini"}),this.gotoUpvalue()}},{key:"gotoUpvalue",value:function(){wx.navigateTo({url:"upValue"}),this.hasChangeRoute()}},{key:"handleOptions",value:function(){function e(){return t.apply(this,arguments)}var t=_asyncToGenerator(regeneratorRuntime.mark(function e(){var t,n,a,r,i,o,s,c,u,l,p;return regeneratorRuntime.wrap(function(e){for(;;)switch(e.prev=e.next){case 0:if(e.prev=0,t=decodeURIComponent(this.options.scene),"1"!==(n=_common2.default.getQueryParam(t,"fr"))&&"share"!==this.options.from){e.next=26;break}return a=_common2.default.getQueryParam(t,"uid"),r=_common2.default.getQueryParam(t,"date"),i=this.options.openId,o=this.options.up,e.next=10,_storage2.default.get(_constant2.default.KEY_IS_NEW);case 10:if(e.t0=e.sent,e.t0){e.next=13;break}e.t0=!1;case 13:if(s=e.t0,s&&_storage2.default.set(_constant2.default.KEY_IS_NEW,!1),c={shareType:"1"===n?3:o?2:1,isNew:s},"1"===n?c.shareUserId=a:c.shareOpenId=i,_api2.default.submitShareStats(c),"1"!==n&&!o){e.next=25;break}return u={helpType:o?1:2},"1"===n?(u.shareUserId=a,u.qrCodeTime=r):u.sharerOpenId=i,e.next=23,_api2.default.upValue(u);case 23:l=e.sent,l.successMsg&&wx.showToast({title:l.successMsg,icon:"none",duration:3e3});case 25:this.options.link&&(p=decodeURIComponent(this.options.link),wx.navigateTo({url:decodeURIComponent(p)}),this.hasChangeRoute());case 26:e.next=30;break;case 28:e.prev=28,e.t1=e.catch(0);case 30:case"end":return e.stop()}},e,this,[[0,28]])}));return e}()},{key:"loadIndexData",value:function(){function e(){return t.apply(this,arguments)}var t=_asyncToGenerator(regeneratorRuntime.mark(function e(){var t,n,a,r=this;return regeneratorRuntime.wrap(function(e){for(;;)switch(e.prev=e.next){case 0:return this.loadingHide=!1,this.$apply(),this.unlockInfo={},this.showMask=!1,this.selectSubjectShow=!1,this.unlockModle=!1,this.noUpModle=!1,this.pointData=[],this.subjectData=[],e.next=11,_api2.default.indexInfo();case 11:return t=e.sent,e.next=14,_storage2.default.get("isStart");case 14:if(this.isStart=e.sent,!this.isFirstOnShow){e.next=23;break}if(!t.isAuth){e.next=23;break}return e.next=19,_storage2.default.get(_constant2.default.KEY_UNIONID);case 19:if(n=e.sent){e.next=23;break}return e.next=23,_storage2.default.set(_constant2.default.KEY_UNIONID,t.unionId);case 23:this.showShare=t.showShare,this.userInfo=t.userInfo,this.$parent.globalData.userInfo=t.userInfo,this.online=t.online,this.learned=t.userInfo.learned,this.isComplete=t.isComplete,this.firstAnswer=t.userInfo.firstAnswer,this.indexCourse=t.indexCourse,this.checkStatus=t.checkStatus,this.subjectList=t.subjectList,this.subjectList.forEach(function(e){r.subjectData.push(e.subjectName),r.pointData.push(parseInt(e.pointGraspRate))}),a=Array.isArray(t.subjectList)?t.subjectList.filter(function(e){return 0===e.learnDay&&0===e.unlockDay}):[],this.subjectUnlearn=4===a.length,this.completeNum=t.completeNum,this.banner=t.banner,this.isAuth=t.userInfo.isAuth,this.isAuthPhone=t.userInfo.isAuthPhone,_storage2.default.set("isAuthPhone",this.isAuthPhone),this.canFree=t.canFree,this.hasVip=t.userInfo.payFlag||!1,this.$parent.globalData.hasPay=t.payFlag||!1,this.publicCourseCount=t.publicCourseCount,this.createTime=t.userInfo.createTime,this.getTimeStamp()===this.createTime?this.isnewuser=1:this.isnewuser=0,this.loadingHide=!0,this.$apply(),this.setChart(),_storage2.default.set("upValue",this.userInfo.upValue),_storage2.default.set("hasVip",this.hasVip),_storage2.default.set("subjectList",this.subjectList),_storage2.default.set("isnewuser",this.isnewuser);case 54:case"end":return e.stop()}},e,this)}));return e}()},{key:"handleError",value:function(){function e(e,n){return t.apply(this,arguments)}var t=_asyncToGenerator(regeneratorRuntime.mark(function e(t,n){var a,r=this;return regeneratorRuntime.wrap(function(e){for(;;)switch(e.prev=e.next){case 0:if(this.loadingHide=!0,this.$apply(),"handleFromAPPWeb"!==n){e.next=5;break}return t&&5022===t.code?(a=encodeURIComponent("index"+_common2.default.obj2url(this.options)),this.$redirect("login",{link:a,hideCancel:1})):this.$invoke("KcErrorModal","showModal",{err:t,btnMsg:"重新加载",cb:function(){function e(){return t.apply(this,arguments)}var t=_asyncToGenerator(regeneratorRuntime.mark(function e(){return regeneratorRuntime.wrap(function(e){for(;;)switch(e.prev=e.next){case 0:return e.next=2,r.handleFromAPPWeb();case 2:r.loadIndexData();case 3:case"end":return e.stop()}},e,r)}));return e}()}),e.abrupt("return");case 5:this.$invoke("KcErrorModal","showModal",{err:t,btnMsg:"重新加载",cb:function(){r.loadIndexData()}});case 6:case"end":return e.stop()}},e,this)}));return e}()},{key:"onHide",value:function(){this.clearIsNew()}},{key:"onUnload",value:function(){this.clearIsNew()}},{key:"clearIsNew",value:function(){_storage2.default.get(_constant2.default.KEY_IS_NEW).then(function(e){e&&_storage2.default.set(_constant2.default.KEY_IS_NEW,!1)})}},{key:"onShareAppMessage",value:function(e){return _common2.default.shareTxt()}},{key:"setPointsData",value:function(){for(var e=0;e<this.subjectList.length;e++){if(this.subjectList[e].learnDay>0)return void(this.noPointsData=!1)}this.noPointsData=!0}},{key:"getTimeStamp",value:function(){var e=new Date,t=""+e.getFullYear(),n=""+(e.getMonth()+1),a=""+e.getDate();return parseInt(t,10)<10&&(t="0"+t),parseInt(n,10)<10&&(n="0"+n),parseInt(a,10)<10&&(a="0"+a),t+"-"+n+"-"+a}},{key:"setChart",value:function(){console.log(wx.getSystemInfoSync().windowWidth);var e=wx.getSystemInfoSync().windowWidth*(650/750),t=.44*wx.getSystemInfoSync().windowWidth,n={main:{data:this.pointData,categories:this.subjectData}};new _eChart2.default({canvasId:"columnCanvas",type:"column",categories:n.main.categories,series:[{name:"成交量",data:n.main.data,format:function(e,t){return e+"%"},color:"#6787FF"}],yAxis:{format:function(e){return e+"%"},min:0,max:100,disabled:!0},xAxis:{disableGrid:!1,type:"calibration"},extra:{column:{width:30}},width:e,height:t,legend:!1})}},{key:"wxSilentLogin",value:function(){return new Promise(function(e,t){wx.login({success:function(t){e(t.code)},fail:function(e){t(e)}})})}},{key:"wxGetUserProfile",value:function(){return new Promise(function(e,t){wx.getUserProfile({desc:"小程序需要您的授权才能正常使用",success:function(t){e(t)},fail:function(e){t(e)}})})}}]),t}(_wepy2.default.page),_applyDecoratedDescriptor(_class.prototype,"posterHelp",[_dec],Object.getOwnPropertyDescriptor(_class.prototype,"posterHelp"),_class.prototype),_applyDecoratedDescriptor(_class.prototype,"handleFromAPPWeb",[_dec2],Object.getOwnPropertyDescriptor(_class.prototype,"handleFromAPPWeb"),_class.prototype),_applyDecoratedDescriptor(_class.prototype,"loadIndexData",[_dec3],Object.getOwnPropertyDescriptor(_class.prototype,"loadIndexData"),_class.prototype),_class);Page(require("./../npm/wepy/lib/wepy.js").default.$createPage(Home,"pages/index")); 
 			}); 	require("pages/index.js");
 		__wxRoute = 'pages/activate';__wxRouteBegin = true; 	__wxAppCurrentFile__ = 'pages/activate.js';	define("pages/activate.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			
// pages/activate.js
Page({

  /**
   * 页面的初始数据
   */
  data: {

  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad(options) {

  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady() {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow() {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide() {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload() {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh() {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom() {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage() {

  }
}) 
 			}); 	require("pages/activate.js");
 		__wxRoute = 'pages/upValue';__wxRouteBegin = true; 	__wxAppCurrentFile__ = 'pages/upValue.js';	define("pages/upValue.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			
"use strict";function _interopRequireDefault(e){return e&&e.__esModule?e:{default:e}}function _asyncToGenerator(e){return function(){var t=e.apply(this,arguments);return new Promise(function(e,r){function n(a,o){try{var i=t[a](o),s=i.value}catch(e){return void r(e)}if(!i.done)return Promise.resolve(s).then(function(e){n("next",e)},function(e){n("throw",e)});e(s)}return n("next")})}}function _classCallCheck(e,t){if(!(e instanceof t))throw new TypeError("Cannot call a class as a function")}function _possibleConstructorReturn(e,t){if(!e)throw new ReferenceError("this hasn't been initialised - super() hasn't been called");return!t||"object"!=typeof t&&"function"!=typeof t?e:t}function _inherits(e,t){if("function"!=typeof t&&null!==t)throw new TypeError("Super expression must either be null or a function, not "+typeof t);e.prototype=Object.create(t&&t.prototype,{constructor:{value:e,enumerable:!1,writable:!0,configurable:!0}}),t&&(Object.setPrototypeOf?Object.setPrototypeOf(e,t):e.__proto__=t)}function _applyDecoratedDescriptor(e,t,r,n,a){var o={};return Object.keys(n).forEach(function(e){o[e]=n[e]}),o.enumerable=!!o.enumerable,o.configurable=!!o.configurable,("value"in o||o.initializer)&&(o.writable=!0),o=r.slice().reverse().reduce(function(r,n){return n(e,t,r)||r},o),a&&void 0!==o.initializer&&(o.value=o.initializer?o.initializer.call(a):void 0,o.initializer=void 0),void 0===o.initializer&&(Object.defineProperty(e,t,o),o=null),o}Object.defineProperty(exports,"__esModule",{value:!0});var _createClass=function(){function e(e,t){for(var r=0;r<t.length;r++){var n=t[r];n.enumerable=n.enumerable||!1,n.configurable=!0,"value"in n&&(n.writable=!0),Object.defineProperty(e,n.key,n)}}return function(t,r,n){return r&&e(t.prototype,r),n&&e(t,n),t}}(),_dec,_dec2,_desc,_value,_class,_wepy=require("./../npm/wepy/lib/wepy.js"),_wepy2=_interopRequireDefault(_wepy),_api=require("./../common/api.js"),_api2=_interopRequireDefault(_api),_storage=require("./../common/storage.js"),_storage2=_interopRequireDefault(_storage),_common=require("./../common/common.js"),_common2=_interopRequireDefault(_common),_decorator=require("./../common/decorator.js"),_KcModulForHelp=require("./../components/KcModulForHelp.js"),_KcModulForHelp2=_interopRequireDefault(_KcModulForHelp),_KcLoading=require("./../components/KcLoading.js"),_KcLoading2=_interopRequireDefault(_KcLoading),_KcErrorModal=require("./../components/KcErrorModal.js"),_KcErrorModal2=_interopRequireDefault(_KcErrorModal),_kcLog=require("./../npm/@kc-base/kc-log/dist/kc-log.js"),_kcLog2=_interopRequireDefault(_kcLog),UpValue=(_dec=(0,_decorator.trycatch)(),_dec2=(0,_decorator.trycatch)(),_class=function(e){function t(){var e,r,n,a;_classCallCheck(this,t);for(var o=arguments.length,i=Array(o),s=0;s<o;s++)i[s]=arguments[s];return r=n=_possibleConstructorReturn(this,(e=t.__proto__||Object.getPrototypeOf(t)).call.apply(e,[this].concat(i))),n.config={navigationBarTitleText:"我的UP值",navigationBarBackgroundColor:"#7B99FF",navigationBarTextStyle:"white"},n.$repeat={},n.$props={KcModulForHelp:{"xmlns:v-bind":"","v-bind:show.sync":"showModulForHelp"},KcLoading:{"v-bind:loadingHide.sync":"loadingHide"}},n.$events={},n.components={KcModulForHelp:_KcModulForHelp2.default,KcLoading:_KcLoading2.default,KcErrorModal:_KcErrorModal2.default},n.mixins=[],n.data={loadingHide:!0,openId:"",up:0,reduce:0,add:0,chosed:1,upValue:50,noFirst:!1,hasToday:!0,hasThreeDays:!1,hasFinishOnce:!1,fromUp:"",showModulForHelp:!1,successMsg:null,showShare:!1,closeBanner:!1,avatar:"",taskList:[],qrCodeUrl:""},n.methods={choseNav:function(e){this.chosed=e},showModul:function(){_kcLog2.default.send({pagename:"myUpPage",name:"shareClick",category:"webClick",pt:"mini"}),this.noFirst||(this.showModulForHelp=!0,this.noFirst=!0,wx.setStorageSync("noFirst",!0))},goIndex:function(){_wepy2.default.reLaunch({url:"index"})},goPay:function(){wx.navigateTo({url:"subPages/pay"})},goValueList:function(){_kcLog2.default.send({pagename:"myUpPage",name:"detailClick",category:"webClick",pt:"mini"}),wx.navigateTo({url:"upValueList"})},closeBannerTap:function(){this.closeBanner=!0,_storage2.default.set("upCloseBanner",!0)},goVip:function(){_kcLog2.default.send({pagename:"myUpPage",name:"vipClick",category:"webClick",pt:"mini"});_wepy2.default.navigateTo({url:"web?url="+encodeURIComponent("https://mp.weixin.qq.com/s?__biz=MzU2ODcxNTYxNQ==&mid=2247709644&idx=1&sn=3c4d5f76282c25f9f002ec736bd29f51&chksm=fc8443fccbf3caea2eacaebff39971de1e76aa63c6a4d984c933830e6d9991137062adf7ae07#rd")})}},a=r,_possibleConstructorReturn(n,a)}return _inherits(t,e),_createClass(t,[{key:"onLoad",value:function(){function e(e){return t.apply(this,arguments)}var t=_asyncToGenerator(regeneratorRuntime.mark(function e(t){var r;return regeneratorRuntime.wrap(function(e){for(;;)switch(e.prev=e.next){case 0:return _kcLog2.default.send({pagename:"myUpPage",name:"myUpPageView",category:"webPageView",pt:"mini"}),this.fromUp=t.openId||"",this.noFirst=wx.getStorageSync("noFirst")||!1,e.next=5,_api2.default.getUserInfo();case 5:return r=e.sent,this.up=r.user.upValue,e.next=9,_storage2.default.get("upCloseBanner");case 9:if(e.t0=e.sent,e.t0){e.next=12;break}e.t0=!1;case 12:return this.closeBanner=e.t0,e.next=15,this.getUserIndex();case 15:this.successMsg&&wx.showToast({title:this.successMsg,icon:"none",duration:3e3}),this.$apply();case 17:case"end":return e.stop()}},e,this)}));return e}()},{key:"getQRCodeUrl",value:function(){function e(){return t.apply(this,arguments)}var t=_asyncToGenerator(regeneratorRuntime.mark(function e(){var t,r;return regeneratorRuntime.wrap(function(e){for(;;)switch(e.prev=e.next){case 0:return e.prev=0,e.next=3,_api2.default.getQRCodeForUpValue();case 3:t=e.sent,r=t.qrCodeUrl,this.qrCodeUrl=r,this.$apply(),e.next=11;break;case 9:e.prev=9,e.t0=e.catch(0);case 11:case"end":return e.stop()}},e,this,[[0,9]])}));return e}()},{key:"initData",value:function(){function e(){return t.apply(this,arguments)}var t=_asyncToGenerator(regeneratorRuntime.mark(function e(){var t,r,n,a,o,i,s,c,u,l,p;return regeneratorRuntime.wrap(function(e){for(;;)switch(e.prev=e.next){case 0:return this.loadingHide=!1,e.next=3,_api2.default.upValue({sharerOpenId:this.fromUp});case 3:t=e.sent,r=t.showShare,n=t.openId,a=t.consume,o=t.gain,i=t.score,s=t.hasToday,c=t.hasThreeDays,u=t.hasFinishOnce,l=t.successMsg,this.showShare=r||!1,this.openId=n,this.up=i,this.add=o,this.reduce=a,this.hasToday=s||!1,this.hasThreeDays=c||!1,this.hasFinishOnce=u||!1,this.successMsg=l||!1,p=this.$parent.globalData.userInfo,this.avatar=p?p.head:"",this.loadingHide=!0,this.$apply();case 26:case"end":return e.stop()}},e,this)}));return e}()},{key:"addScore",value:function(){function e(e,r){return t.apply(this,arguments)}var t=_asyncToGenerator(regeneratorRuntime.mark(function e(t,r){return regeneratorRuntime.wrap(function(e){for(;;)switch(e.prev=e.next){case 0:return e.next=2,_api2.default.saveScore({type:t,score:r});case 2:case"end":return e.stop()}},e,this)}));return e}()},{key:"onShareAppMessage",value:function(e){return this.noFirst&&"button"===e.from?_common2.default.shareTxt({up:1,openId:this.openId},"@我的研友，推荐一个刷政治1000题的小程序给你","../images/activate/img_share.png"):_common2.default.shareTxt()}},{key:"handleError",value:function(){function e(e,r){return t.apply(this,arguments)}var t=_asyncToGenerator(regeneratorRuntime.mark(function e(t,r){var n=this;return regeneratorRuntime.wrap(function(e){for(;;)switch(e.prev=e.next){case 0:this.loadingHide=!0,this.$apply(),this.$invoke("KcErrorModal","showModal",{err:t,btnMsg:"重新加载",cb:function(){n.initData()}});case 3:case"end":return e.stop()}},e,this)}));return e}()},{key:"getUserIndex",value:function(){function e(){return t.apply(this,arguments)}var t=_asyncToGenerator(regeneratorRuntime.mark(function e(){var t;return regeneratorRuntime.wrap(function(e){for(;;)switch(e.prev=e.next){case 0:return e.next=2,_api2.default.getUserIndex();case 2:t=e.sent,this.taskList=t.tasks;case 4:case"end":return e.stop()}},e,this)}));return e}()}]),t}(_wepy2.default.page),_applyDecoratedDescriptor(_class.prototype,"initData",[_dec],Object.getOwnPropertyDescriptor(_class.prototype,"initData"),_class.prototype),_applyDecoratedDescriptor(_class.prototype,"getUserIndex",[_dec2],Object.getOwnPropertyDescriptor(_class.prototype,"getUserIndex"),_class.prototype),_class);Page(require("./../npm/wepy/lib/wepy.js").default.$createPage(UpValue,"pages/upValue")); 
 			}); 	require("pages/upValue.js");
 		__wxRoute = 'pages/learnIndex';__wxRouteBegin = true; 	__wxAppCurrentFile__ = 'pages/learnIndex.js';	define("pages/learnIndex.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			
"use strict";function _interopRequireDefault(e){return e&&e.__esModule?e:{default:e}}function _asyncToGenerator(e){return function(){var t=e.apply(this,arguments);return new Promise(function(e,n){function r(o,i){try{var a=t[o](i),s=a.value}catch(e){return void n(e)}if(!a.done)return Promise.resolve(s).then(function(e){r("next",e)},function(e){r("throw",e)});e(s)}return r("next")})}}function _classCallCheck(e,t){if(!(e instanceof t))throw new TypeError("Cannot call a class as a function")}function _possibleConstructorReturn(e,t){if(!e)throw new ReferenceError("this hasn't been initialised - super() hasn't been called");return!t||"object"!=typeof t&&"function"!=typeof t?e:t}function _inherits(e,t){if("function"!=typeof t&&null!==t)throw new TypeError("Super expression must either be null or a function, not "+typeof t);e.prototype=Object.create(t&&t.prototype,{constructor:{value:e,enumerable:!1,writable:!0,configurable:!0}}),t&&(Object.setPrototypeOf?Object.setPrototypeOf(e,t):e.__proto__=t)}function _applyDecoratedDescriptor(e,t,n,r,o){var i={};return Object.keys(r).forEach(function(e){i[e]=r[e]}),i.enumerable=!!i.enumerable,i.configurable=!!i.configurable,("value"in i||i.initializer)&&(i.writable=!0),i=n.slice().reverse().reduce(function(n,r){return r(e,t,n)||n},i),o&&void 0!==i.initializer&&(i.value=i.initializer?i.initializer.call(o):void 0,i.initializer=void 0),void 0===i.initializer&&(Object.defineProperty(e,t,i),i=null),i}Object.defineProperty(exports,"__esModule",{value:!0});var _createClass=function(){function e(e,t){for(var n=0;n<t.length;n++){var r=t[n];r.enumerable=r.enumerable||!1,r.configurable=!0,"value"in r&&(r.writable=!0),Object.defineProperty(e,r.key,r)}}return function(t,n,r){return n&&e(t.prototype,n),r&&e(t,r),t}}(),_dec,_desc,_value,_class,_wepy=require("./../npm/wepy/lib/wepy.js"),_wepy2=_interopRequireDefault(_wepy),_api=require("./../common/api.js"),_api2=_interopRequireDefault(_api),_common=require("./../common/common.js"),_common2=_interopRequireDefault(_common),_PointTips=require("./../components/PointTips.js"),_PointTips2=_interopRequireDefault(_PointTips),_decorator=require("./../common/decorator.js"),_KcLoading=require("./../components/KcLoading.js"),_KcLoading2=_interopRequireDefault(_KcLoading),_KcErrorModal=require("./../components/KcErrorModal.js"),_KcErrorModal2=_interopRequireDefault(_KcErrorModal),_storage=require("./../common/storage.js"),_storage2=_interopRequireDefault(_storage),log=require("./../common/log.js"),LearnIndex=(_dec=(0,_decorator.trycatch)(),_class=function(e){function t(){var e,n,r,o;_classCallCheck(this,t);for(var i=arguments.length,a=Array(i),s=0;s<i;s++)a[s]=arguments[s];return n=r=_possibleConstructorReturn(this,(e=t.__proto__||Object.getPrototypeOf(t)).call.apply(e,[this].concat(a))),r.config={navigationBarTitleText:"考点预览",navigationBarTextStyle:"white",navigationBarBackgroundColor:"#7B99FF"},r.$repeat={},r.$props={KcLoading:{"xmlns:v-bind":"","v-bind:loadingHide.sync":"loadingHide"},PointTips:{"xmlns:v-bind":"","v-bind:title.sync":"tipsTitle","v-bind:icon.sync":"tipsIcon","xmlns:wx":""}},r.$events={},r.components={KcLoading:_KcLoading2.default,KcErrorModal:_KcErrorModal2.default,PointTips:_PointTips2.default},r.mixins=[],r.data={loadingHide:!0,tipsTitle:"先看下题目对应的每章考点哦，做到心里有数~",tipsIcon:"../images/learn/icon_tips.png",tipsShow:!1,sid:"",day:"",name:"",allQuestion:"",content:[]},r.methods={goLearn:function(){function e(){return t.apply(this,arguments)}var t=_asyncToGenerator(regeneratorRuntime.mark(function e(){var t,n;return regeneratorRuntime.wrap(function(e){for(;;)switch(e.prev=e.next){case 0:return e.next=2,_storage2.default.get("isnewuser");case 2:if(e.t0=e.sent,e.t0){e.next=5;break}e.t0=0;case 5:return t=e.t0,log.info("课程列表去学习页","sid="+this.sid+"&days="+JSON.stringify([this.day])),wx.redirectTo({url:"study?sid="+this.sid+"&days="+JSON.stringify([this.day])+"&type=1&onlyFalse=false"}),_common2.default.business({BSceneCode:"startLearn",BDescribe:"点击学习按钮",BType:0,ext:{subjectId:parseInt(this.sid),stageIndex:parseInt(this.day)}}),e.next=11,_storage2.default.get("studyTime");case 11:if(e.t1=e.sent,e.t1){e.next=14;break}e.t1=0;case 14:n=e.t1,_storage2.default.set("studyTime",++n);case 16:case"end":return e.stop()}},e,this)}));return e}(),formSubmit:function(e){var t=e.detail.formId;_common2.default.collectFormID(t)}},o=n,_possibleConstructorReturn(r,o)}return _inherits(t,e),_createClass(t,[{key:"onLoad",value:function(e){this.sid=e.sid,this.day=e.day,this.getLearnInfo()}},{key:"getLearnInfo",value:function(){function e(){return t.apply(this,arguments)}var t=_asyncToGenerator(regeneratorRuntime.mark(function e(){var t,n,r=this;return regeneratorRuntime.wrap(function(e){for(;;)switch(e.prev=e.next){case 0:return this.loadingHide=!1,e.next=3,_storage2.default.get("token");case 3:if(e.t0=e.sent,e.t0){e.next=6;break}e.t0=0;case 6:return t=e.t0,e.next=9,_api2.default.learnInfo({subjectId:this.sid,stage:this.day,type:1,needProposal:!1,token:t});case 9:n=e.sent,this.name=n.abbreviationName,this.content=n.content,this.allQuestion=n.allQuestion,this.content.forEach(function(e,t){e.index=r.numToChinese(t+1)}),this.loadingHide=!0,this.$apply(),setTimeout(function(){r.tipsShow=!0,r.$apply()},500);case 17:case"end":return e.stop()}},e,this)}));return e}()},{key:"handleError",value:function(){function e(e,n){return t.apply(this,arguments)}var t=_asyncToGenerator(regeneratorRuntime.mark(function e(t,n){var r=this;return regeneratorRuntime.wrap(function(e){for(;;)switch(e.prev=e.next){case 0:this.loadingHide=!0,this.$apply(),this.$invoke("KcErrorModal","showModal",{err:t,btnMsg:"重新加载",cb:function(){r.getLearnInfo()}});case 3:case"end":return e.stop()}},e,this)}));return e}()},{key:"onShareAppMessage",value:function(){return _common2.default.shareTxt()}},{key:"numToChinese",value:function(e){for(var t=new Array("零","一","二","三","四","五","六","七","八","九"),n=new Array("","十","百","千","万","亿","点",""),r=(""+e).replace(/(^0*)/g,"").split("."),o=0,i="",a=r[0].length-1;a>=0;a--){switch(o){case 0:i=n[7]+i;break;case 4:new RegExp("0{4}\\d{"+(r[0].length-a-1)+"}$").test(r[0])||(i=n[4]+i);break;case 8:i=n[5]+i,n[7]=n[5],o=0}o%4==2&&0!=r[0].charAt(a+2)&&0==r[0].charAt(a+1)&&(i=t[0]+i),0!=r[0].charAt(a)&&(i=t[r[0].charAt(a)]+n[o%4]+i),o++}if(r.length>1){i+=n[6];for(var s=0;s<r[1].length;s++)i+=t[r[1].charAt(s)]}return i}}]),t}(_wepy2.default.page),_applyDecoratedDescriptor(_class.prototype,"getLearnInfo",[_dec],Object.getOwnPropertyDescriptor(_class.prototype,"getLearnInfo"),_class.prototype),_class);Page(require("./../npm/wepy/lib/wepy.js").default.$createPage(LearnIndex,"pages/learnIndex")); 
 			}); 	require("pages/learnIndex.js");
 		__wxRoute = 'pages/report';__wxRouteBegin = true; 	__wxAppCurrentFile__ = 'pages/report.js';	define("pages/report.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			
"use strict";function _interopRequireDefault(t){return t&&t.__esModule?t:{default:t}}function _asyncToGenerator(t){return function(){var e=t.apply(this,arguments);return new Promise(function(t,n){function i(r,o){try{var a=e[r](o),s=a.value}catch(t){return void n(t)}if(!a.done)return Promise.resolve(s).then(function(t){i("next",t)},function(t){i("throw",t)});t(s)}return i("next")})}}function _classCallCheck(t,e){if(!(t instanceof e))throw new TypeError("Cannot call a class as a function")}function _possibleConstructorReturn(t,e){if(!t)throw new ReferenceError("this hasn't been initialised - super() hasn't been called");return!e||"object"!=typeof e&&"function"!=typeof e?t:e}function _inherits(t,e){if("function"!=typeof e&&null!==e)throw new TypeError("Super expression must either be null or a function, not "+typeof e);t.prototype=Object.create(e&&e.prototype,{constructor:{value:t,enumerable:!1,writable:!0,configurable:!0}}),e&&(Object.setPrototypeOf?Object.setPrototypeOf(t,e):t.__proto__=e)}function _applyDecoratedDescriptor(t,e,n,i,r){var o={};return Object.keys(i).forEach(function(t){o[t]=i[t]}),o.enumerable=!!o.enumerable,o.configurable=!!o.configurable,("value"in o||o.initializer)&&(o.writable=!0),o=n.slice().reverse().reduce(function(n,i){return i(t,e,n)||n},o),r&&void 0!==o.initializer&&(o.value=o.initializer?o.initializer.call(r):void 0,o.initializer=void 0),void 0===o.initializer&&(Object.defineProperty(t,e,o),o=null),o}Object.defineProperty(exports,"__esModule",{value:!0});var _createClass=function(){function t(t,e){for(var n=0;n<e.length;n++){var i=e[n];i.enumerable=i.enumerable||!1,i.configurable=!0,"value"in i&&(i.writable=!0),Object.defineProperty(t,i.key,i)}}return function(e,n,i){return n&&t(e.prototype,n),i&&t(e,i),e}}(),_dec,_dec2,_dec3,_desc,_value,_class,_wepy=require("./../npm/wepy/lib/wepy.js"),_wepy2=_interopRequireDefault(_wepy),_api=require("./../common/api.js"),_api2=_interopRequireDefault(_api),_common=require("./../common/common.js"),_common2=_interopRequireDefault(_common),_PointTips=require("./../components/PointTips.js"),_PointTips2=_interopRequireDefault(_PointTips),_decorator=require("./../common/decorator.js"),_KcLoading=require("./../components/KcLoading.js"),_KcLoading2=_interopRequireDefault(_KcLoading),_KcErrorModal=require("./../components/KcErrorModal.js"),_KcErrorModal2=_interopRequireDefault(_KcErrorModal),_eChart=require("./../common/e-chart.js"),_eChart2=_interopRequireDefault(_eChart),_storage=require("./../common/storage.js"),_storage2=_interopRequireDefault(_storage),_KcUpValue=require("./../components/KcUpValue.js"),_KcUpValue2=_interopRequireDefault(_KcUpValue),_kcLog=require("./../npm/@kc-base/kc-log/dist/kc-log.js"),_kcLog2=_interopRequireDefault(_kcLog),log=require("./../common/log.js"),touchStartX=0,touchMoveX=0,touchStartY=0,touchMoveY=0,Report=(_dec=(0,_decorator.trycatch)(),_dec2=(0,_decorator.trycatch)(),_dec3=(0,_decorator.trycatch)(),_class=function(t){function e(){var t,n,i,r;_classCallCheck(this,e);for(var o=arguments.length,a=Array(o),s=0;s<o;s++)a[s]=arguments[s];return n=i=_possibleConstructorReturn(this,(t=e.__proto__||Object.getPrototypeOf(e)).call.apply(t,[this].concat(a))),i.config={navigationBarTitleText:"刷题报告"},i.data={loadingHide:!0,tipsTitle:"题目对应的考点掌握情况出炉啦，复习更高效",tipsIcon:"../images/report/icon_tips.png",tipsShow:!1,suggest:!1,onlyFalse:!1,sid:"",day:0,days:[],daysText:"",type:"",name:"",allTopic:"",rnum:"",fnum:"",fTopicNum:"",rTopicNum:"",overPercentage:0,proposal:[],content:[],hasPointDetail:0,showCanvas:!1,width:0,accNum:0,moved:!1,isSubscribeRead:!0,pointToggleState:[],learnDay:0,unlockDay:0,allDay:0,upValue:0,title:"",text1:"",text2:"",text3:"",leftBtnText:"",rightBtnText:"",rightBtnTips:"",leftCb:null,rightCb:null,imgSrc:"",wrongSectionShow:!1,wrongSectionNum:0,isAuth:!1,subjectList:[],addWrongSectionNum:0,link:{},hasVip:!1},i.$repeat={},i.$props={KcLoading:{"xmlns:v-bind":"","v-bind:loadingHide.sync":"loadingHide"},PointTips:{"xmlns:v-bind":"","v-bind:title.sync":"tipsTitle","v-bind:icon.sync":"tipsIcon"},KcUpValue:{"xmlns:v-bind":"","v-bind:title.sync":"title","v-bind:text1.sync":"text1","v-bind:text2.sync":"text2","v-bind:text3.sync":"text3","v-bind:leftBtnText.sync":"leftBtnText","v-bind:rightBtnText.sync":"rightBtnText","v-bind:leftCb.sync":"leftCb","v-bind:rightCb.sync":"rightCb","v-bind:imgSrc.sync":"imgSrc","v-bind:rightBtnTips.sync":"rightBtnTips"}},i.$events={},i.components={KcLoading:_KcLoading2.default,KcErrorModal:_KcErrorModal2.default,PointTips:_PointTips2.default,KcUpValue:_KcUpValue2.default},i.mixins=[],i.events={modalCloseCb:function(){this.showCanvas=!0,this.setEchart()}},i.methods={tapSuggest:function(){this.suggest=!0,wx.createSelectorQuery().select(".container").boundingClientRect(function(t){setTimeout(function(){wx.pageScrollTo({scrollTop:t.bottom})},100)}).exec()},back:function(){wx.navigateBack({delta:1})},formSubmit:function(t){var e=t.detail.formId;_common2.default.collectFormID(e)},touchStart:function(t){touchStartX=t.touches[0].pageX,touchStartY=t.touches[0].pageY},touchMove:function(t){touchMoveX=t.touches[0].pageX,touchMoveY=t.touches[0].pageY,this.moved=!0},touchEnd:function(t){var e=touchMoveX-touchStartX,n=touchMoveY-touchStartY;e>0&&n>-2&&n<2&&(this.moved=!1,this.$navigate("index"))},pointDetailToggle:function(t){1===this.type&&wx.reportAnalytics("report_20_click_toggle",{pointId:t});for(var e=0;e<this.content.length;e++)for(var n=0;n<this.content[e].points.length;n++){var i=this.content[e].points[n];if(i.pointId===t)return void(this.pointToggleState[i.index]=!this.pointToggleState[i.index])}},goReview:function(){_kcLog2.default.send({pagename:"reportPage",name:"reviewClick",category:"webClick",pt:"mini"}),wx.redirectTo({url:"reviewIndex?sid="+this.sid})},wrongTopic:function(){log.info("报告页回顾错题去学习","study?sid="+this.sid+"&days="+JSON.stringify(this.days)),wx.redirectTo({url:"study?sid="+this.sid+"&days="+JSON.stringify(this.days)+"&type=3&onlyFalse="+this.onlyFalse})},goNext:function(){if(_kcLog2.default.send({pagename:"reportPage",name:"nextClick",category:"webClick",pt:"mini"}),this.hasVip)wx.redirectTo({url:"learnIndex?sid="+this.sid+"&day="+(this.learnDay+1)});else if(this.learnDay<this.unlockDay&&this.unlockDay<=this.allDay)wx.redirectTo({url:"learnIndex?sid="+this.sid+"&day="+(this.learnDay+1)});else if(this.upValue>=20){this.imgSrc="../images/components/icon_lock@2x.png",this.title="解锁下一天题目",this.text1="需消耗",this.text2="20点UP值",this.text3="你目前拥有"+this.upValue+"点UP值",this.leftBtnText="消耗UP值解锁",this.rightBtnText="获取无限UP值",this.rightBtnTips="限时活动";var t=this.day+1,e=this.sid;this.leftCb=function(){this.unlockCourse(e,t)},this.rightCb=function(){_wepy2.default.navigateTo({url:"web?url="+encodeURIComponent("https://mp.weixin.qq.com/s?__biz=MzU2ODcxNTYxNQ==&mid=2247709644&idx=1&sn=3c4d5f76282c25f9f002ec736bd29f51&chksm=fc8443fccbf3caea2eacaebff39971de1e76aa63c6a4d984c933830e6d9991137062adf7ae07#rd")}),this.close(),this.modalCloseCb()},this.showCanvas=!1,this.$invoke("KcUpValue","showModal")}else this.imgSrc="../images/components/icon_face@2x.png",this.title="UP值不够无法解锁",this.text1="解锁题目需消耗",this.text2="20点UP值",this.text3="你目前拥有"+this.upValue+"点UP值",this.leftBtnText="收集UP值",this.rightBtnText="获取无限UP值",this.rightBtnTips="限时活动",this.leftCb=function(){wx.navigateTo({url:"upValue"}),this.close(),this.modalCloseCb()},this.rightCb=function(){_wepy2.default.navigateTo({url:"web?url="+encodeURIComponent("https://mp.weixin.qq.com/s?__biz=MzU2ODcxNTYxNQ==&mid=2247709644&idx=1&sn=3c4d5f76282c25f9f002ec736bd29f51&chksm=fc8443fccbf3caea2eacaebff39971de1e76aa63c6a4d984c933830e6d9991137062adf7ae07#rd")}),this.close(),this.modalCloseCb()},this.showCanvas=!1,this.$invoke("KcUpValue","showModal")},goStudyData:function(){wx.redirectTo({url:"studyData"})}},r=n,_possibleConstructorReturn(i,r)}return _inherits(e,t),_createClass(e,[{key:"onLoad",value:function(){function t(t){return e.apply(this,arguments)}var e=_asyncToGenerator(regeneratorRuntime.mark(function t(e){return regeneratorRuntime.wrap(function(t){for(;;)switch(t.prev=t.next){case 0:return _kcLog2.default.send({pagename:"reportPage",name:"reportPageView",category:"webPageView",pt:"mini"}),this.link=e,this.sid=e.sid,this.days=e.days?JSON.parse(e.days):[],this.day=parseInt(this.days[0]),this.daysText=this.days.reduce(function(t,e,n){return t+(0===n?"":"/")+e},"DAY"),this.type=Number(e.type),this.onlyFalse=JSON.parse(e.onlyFalse),this.width=750/wx.getSystemInfoSync().windowWidth,"2"===this.type&&wx.setNavigationBarTitle({title:"复习报告"}),this.getData(),this.wrongSection(),this.getUserInfo(),t.next=15,_storage2.default.get("is_auth");case 15:if(t.t0=t.sent,t.t0){t.next=18;break}t.t0=!1;case 18:return this.isAuth=t.t0,t.next=21,_storage2.default.get("hasVip");case 21:this.hasVip=t.sent;case 22:case"end":return t.stop()}},t,this)}));return t}()},{key:"getData",value:function(){function t(){return e.apply(this,arguments)}var e=_asyncToGenerator(regeneratorRuntime.mark(function t(){var e,n,i=this;return regeneratorRuntime.wrap(function(t){for(;;)switch(t.prev=t.next){case 0:return this.loadingHide=!1,t.next=3,_storage2.default.get("token");case 3:if(t.t0=t.sent,t.t0){t.next=6;break}t.t0=0;case 6:return e=t.t0,t.next=9,_api2.default.learnInfo({subjectId:this.sid,stage:this.days.join(","),type:this.type,needProposal:!0,token:e});case 9:n=t.sent,this.name=n.abbreviationName,this.rnum=n.rnum,this.fnum=n.fnum,this.fTopicNum=n.fTopicNum,this.rTopicNum=n.rTopicNum,this.proposal=n.proposal,this.content=n.content,this.allTopic=n.allTopic,this.overPercentage=n.overPercentage,this.hasPointDetail=n.hasPointDetail,this.loadingHide=!0,this.showCanvas=!0,this.accNum=parseInt(n.rnum/n.allQuestion*100),this.$apply(),this.setEchart(),this.content.forEach(function(t){t.points.forEach(function(t,e){t.index=e,i.pointToggleState.push(!1)})}),this.fnum?wx.reportAnalytics("report_20_show_wrongtopic",{}):wx.reportAnalytics("report_20_show_gore",{}),this.allDay!==this.day&&wx.reportAnalytics("report_20_show_next",{}),setTimeout(function(){i.tipsShow=!0,i.$apply()},500);case 29:case"end":return t.stop()}},t,this)}));return t}()},{key:"wrongSection",value:function(){function t(){return e.apply(this,arguments)}var e=_asyncToGenerator(regeneratorRuntime.mark(function t(){var e,n;return regeneratorRuntime.wrap(function(t){for(;;)switch(t.prev=t.next){case 0:return t.next=2,_storage2.default.get("wrongSectionNum");case 2:if(t.t0=t.sent,t.t0){t.next=5;break}t.t0=0;case 5:return e=t.t0,t.next=8,_api2.default.wrongSection();case 8:n=t.sent,this.wrongSectionNum=n.length,this.wrongSectionNum-e>0&&(this.addWrongSectionNum=this.wrongSectionNum-e,this.wrongSectionShow=!0,wx.reportAnalytics("report_20_show_wrongsection",{})),_storage2.default.set("wrongSectionNum",this.wrongSectionNum);case 12:case"end":return t.stop()}},t,this)}));return t}()},{key:"getUserInfo",value:function(){function t(){return e.apply(this,arguments)}var e=_asyncToGenerator(regeneratorRuntime.mark(function t(){var e,n=this;return regeneratorRuntime.wrap(function(t){for(;;)switch(t.prev=t.next){case 0:return t.next=2,_api2.default.getUserInfo();case 2:e=t.sent,this.subjectList=e.subjectList,this.subjectList.forEach(function(t){t.subjectId===parseInt(n.sid)&&(n.learnDay=t.stage,n.unlockDay=t.unlockDays,n.allDay=t.totalDays)}),this.upValue=e.user.upValue;case 6:case"end":return t.stop()}},t,this)}));return t}()},{key:"handleError",value:function(){function t(t,n){return e.apply(this,arguments)}var e=_asyncToGenerator(regeneratorRuntime.mark(function t(e,n){var i=this;return regeneratorRuntime.wrap(function(t){for(;;)switch(t.prev=t.next){case 0:this.loadingHide=!0,this.$apply(),this.$invoke("KcErrorModal","showModal",{err:e,btnMsg:"重新加载",cb:function(){i.getData()}});case 3:case"end":return t.stop()}},t,this)}));return t}()},{key:"onShareAppMessage",value:function(t){return _common2.default.shareTxt()}},{key:"setEchart",value:function(){var t=this;new _eChart2.default({canvasId:"ringCanvas",type:"ring",extra:{ringWidth:15/t.width,pie:{offsetAngle:-90}},series:[{name:"错误",data:t.fnum,color:"#FF9C79"},{name:"正确",data:t.rnum,color:"#D2F5E2"}],width:310/t.width,height:310/t.width,dataLabel:!1,legend:!1})}}]),e}(_wepy2.default.page),_applyDecoratedDescriptor(_class.prototype,"getData",[_dec],Object.getOwnPropertyDescriptor(_class.prototype,"getData"),_class.prototype),_applyDecoratedDescriptor(_class.prototype,"wrongSection",[_dec2],Object.getOwnPropertyDescriptor(_class.prototype,"wrongSection"),_class.prototype),_applyDecoratedDescriptor(_class.prototype,"getUserInfo",[_dec3],Object.getOwnPropertyDescriptor(_class.prototype,"getUserInfo"),_class.prototype),_class);Page(require("./../npm/wepy/lib/wepy.js").default.$createPage(Report,"pages/report")); 
 			}); 	require("pages/report.js");
 		__wxRoute = 'pages/reviewIndex';__wxRouteBegin = true; 	__wxAppCurrentFile__ = 'pages/reviewIndex.js';	define("pages/reviewIndex.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			
"use strict";function _interopRequireDefault(t){return t&&t.__esModule?t:{default:t}}function _asyncToGenerator(t){return function(){var e=t.apply(this,arguments);return new Promise(function(t,n){function r(a,i){try{var o=e[a](i),s=o.value}catch(t){return void n(t)}if(!o.done)return Promise.resolve(s).then(function(t){r("next",t)},function(t){r("throw",t)});t(s)}return r("next")})}}function _classCallCheck(t,e){if(!(t instanceof e))throw new TypeError("Cannot call a class as a function")}function _possibleConstructorReturn(t,e){if(!t)throw new ReferenceError("this hasn't been initialised - super() hasn't been called");return!e||"object"!=typeof e&&"function"!=typeof e?t:e}function _inherits(t,e){if("function"!=typeof e&&null!==e)throw new TypeError("Super expression must either be null or a function, not "+typeof e);t.prototype=Object.create(e&&e.prototype,{constructor:{value:t,enumerable:!1,writable:!0,configurable:!0}}),e&&(Object.setPrototypeOf?Object.setPrototypeOf(t,e):t.__proto__=e)}function _applyDecoratedDescriptor(t,e,n,r,a){var i={};return Object.keys(r).forEach(function(t){i[t]=r[t]}),i.enumerable=!!i.enumerable,i.configurable=!!i.configurable,("value"in i||i.initializer)&&(i.writable=!0),i=n.slice().reverse().reduce(function(n,r){return r(t,e,n)||n},i),a&&void 0!==i.initializer&&(i.value=i.initializer?i.initializer.call(a):void 0,i.initializer=void 0),void 0===i.initializer&&(Object.defineProperty(t,e,i),i=null),i}Object.defineProperty(exports,"__esModule",{value:!0});var _createClass=function(){function t(t,e){for(var n=0;n<e.length;n++){var r=e[n];r.enumerable=r.enumerable||!1,r.configurable=!0,"value"in r&&(r.writable=!0),Object.defineProperty(t,r.key,r)}}return function(e,n,r){return n&&t(e.prototype,n),r&&t(e,r),e}}(),_dec,_desc,_value,_class,_wepy=require("./../npm/wepy/lib/wepy.js"),_wepy2=_interopRequireDefault(_wepy),_api=require("./../common/api.js"),_api2=_interopRequireDefault(_api),_common=require("./../common/common.js"),_common2=_interopRequireDefault(_common),_storage=require("./../common/storage.js"),_storage2=_interopRequireDefault(_storage),_constant=require("./../common/constant.js"),_constant2=_interopRequireDefault(_constant),_eChart=require("./../common/e-chart.js"),_eChart2=_interopRequireDefault(_eChart),_decorator=require("./../common/decorator.js"),_KcLoading=require("./../components/KcLoading.js"),_KcLoading2=_interopRequireDefault(_KcLoading),_KcErrorModal=require("./../components/KcErrorModal.js"),_KcErrorModal2=_interopRequireDefault(_KcErrorModal),_kcLog=require("./../npm/@kc-base/kc-log/dist/kc-log.js"),_kcLog2=_interopRequireDefault(_kcLog),log=require("./../common/log.js"),touchStartX=0,touchMoveX=0,touchStartY=0,touchMoveY=0,Home=(_dec=(0,_decorator.trycatch)(),_class=function(t){function e(){var t,n,r,a;_classCallCheck(this,e);for(var i=arguments.length,o=Array(i),s=0;s<i;s++)o[s]=arguments[s];return n=r=_possibleConstructorReturn(this,(t=e.__proto__||Object.getPrototypeOf(e)).call.apply(t,[this].concat(o))),r.config={navigationBarTitleText:"考点复习",navigationBarTextStyle:"black",navigationBarBackgroundColor:"#fff"},r.data={loadingHide:!0,width:0,onlyFalse:!0,subjectList:[],current:-1,lastStudy:{},rnum:0,fnum:0,totalWrongNum:0,allQuestion:0,accNum:0,content:[],hasPointDetail:0,showCanvas:!1,showFilterTip:!1,moved:!1,pointToggleState:[]},r.$repeat={},r.$props={KcLoading:{"xmlns:v-bind":"","v-bind:loadingHide.sync":"loadingHide"}},r.$events={},r.components={KcLoading:_KcLoading2.default,KcErrorModal:_KcErrorModal2.default},r.mixins=[],r.events={},r.computed={lastStudyText:function(){var t=Array.isArray(this.lastStudy.dayList)&&this.lastStudy.dayList.length>0?"DAY"+this.lastStudy.dayList[0]+(this.lastStudy.dayList.length>1?"等":""):"";return(this.lastStudy.name||"")+t+(this.lastStudy.last?"(上次复习)":"")}},r.methods={filterTap:function(){_kcLog2.default.send({pagename:"reviewPage",name:"selectRangeclick",category:"webClick",pt:"mini"}),this.showFilterTip&&(this.showFilterTip=!1,_storage2.default.set(_constant2.default.KEY_REVIEW_FILTER_TIP_SHOWED,!0)),Array.isArray(this.subjectList)&&this.subjectList.length>0?this.$navigate("reviewFilter",{current:this.current,reviewMode:this.lastStudy.filterMode}):wx.showToast({title:"暂无可选择的复习",icon:"none",duration:3e3})},goReview:function(t){if("true"===t?_kcLog2.default.send({pagename:"reviewPage",name:"reviewWrongClick",category:"webClick",pt:"mini"}):_kcLog2.default.send({pagename:"reviewPage",name:"reviewAllClick",category:"webClick",pt:"mini"}),!("true"===t&&this.totalWrongNum<=0)){var e={sid:this.lastStudy.sid,days:JSON.stringify(this.lastStudy.dayList),onlyFalse:t,type:2};log.info("复习页去学习页参数",e),this.$navigate("study",e)}},formSubmit:function(t){var e=t.detail.formId;_common2.default.collectFormID(e)},touchStart:function(t){touchStartX=t.touches[0].pageX,touchStartY=t.touches[0].pageY},touchMove:function(t){touchMoveX=t.touches[0].pageX,touchMoveY=t.touches[0].pageY,this.moved=!0},touchEnd:function(t){var e=touchMoveX-touchStartX,n=touchMoveY-touchStartY;e>0&&n>-2&&n<2&&(this.moved=!1,this.$navigate("index"))},pointDetailToggle:function(t){wx.reportAnalytics("reviewindex_20_click_toggle",{pointid:t});for(var e=0;e<this.content.length;e++)for(var n=0;n<this.content[e].points.length;n++){var r=this.content[e].points[n];if(r.pointId===t)return void(this.pointToggleState[r.index]=!this.pointToggleState[r.index])}}},a=n,_possibleConstructorReturn(r,a)}return _inherits(e,t),_createClass(e,[{key:"onLoad",value:function(){function t(t){return e.apply(this,arguments)}var e=_asyncToGenerator(regeneratorRuntime.mark(function t(e){return regeneratorRuntime.wrap(function(t){for(;;)switch(t.prev=t.next){case 0:_kcLog2.default.send({pagename:"reviewPage",name:"reviewPageView",category:"webPageView",pt:"mini"}),this.sid=parseInt(e.sid),this.day=parseInt(e.day),this.width=750/wx.getSystemInfoSync().windowWidth;case 4:case"end":return t.stop()}},t,this)}));return t}()},{key:"onShow",value:function(){function t(){return e.apply(this,arguments)}var e=_asyncToGenerator(regeneratorRuntime.mark(function t(){return regeneratorRuntime.wrap(function(t){for(;;)switch(t.prev=t.next){case 0:this.loadReviewData();case 1:case"end":return t.stop()}},t,this)}));return t}()},{key:"loadReviewData",value:function(){function t(){return e.apply(this,arguments)}var e=_asyncToGenerator(regeneratorRuntime.mark(function t(){return regeneratorRuntime.wrap(function(t){for(;;)switch(t.prev=t.next){case 0:return this.loadingHide=!1,this.$apply(),t.next=4,this.getReviewDays();case 4:return t.next=6,this.getLearnInfo();case 6:return t.next=8,_storage2.default.get(_constant2.default.KEY_REVIEW_FILTER_TIP_SHOWED);case 8:if(t.t0=t.sent,t.t0){t.next=11;break}t.t0=!1;case 11:this.showFilterTip=!t.t0,this.$apply();case 13:case"end":return t.stop()}},t,this)}));return t}()},{key:"getReviewDays",value:function(){function t(){return e.apply(this,arguments)}var e=_asyncToGenerator(regeneratorRuntime.mark(function t(){var e,n,r,a,i,o,s,u,c;return regeneratorRuntime.wrap(function(t){for(;;)switch(t.prev=t.next){case 0:return t.next=2,_storage2.default.get(_constant2.default.KEY_REVIEW_LAST_STUDY);case 2:if(t.t0=t.sent,t.t0){t.next=5;break}t.t0={name:"暂无可复习考点",dayList:[]};case 5:return e=t.t0,n=Array.isArray(e.dayList)?e.dayList:[],t.next=9,_storage2.default.get("token");case 9:if(t.t1=t.sent,t.t1){t.next=12;break}t.t1=0;case 12:return r=t.t1,t.next=15,_api2.default.getReviewDays({token:r});case 15:a=t.sent,i=-1,o={},Array.isArray(a.subjectList)&&a.subjectList.length>0?(s=-1,log.info("data.subjectList",a.subjectList),u=a.subjectList.map(function(t,r){return Array.isArray(t.dayList)&&t.dayList.length>0?(t.sid===e.sid&&(i=r),t.did=!0,s=s>=0?s:r,t.dayList=t.dayList.map(function(a){return t.sid===e.sid&&n.indexOf(a.day)>-1?(a.select=!0,t.active=!0):a.select=!1,a.accuracy=parseInt((a.allQuestion-a.fnum)/a.allQuestion*100),a.lastStudy&&(0===Object.keys(o).length&&0!==a.cumulativeWrongNum?o={name:t.name,sid:t.sid,dayList:[a.day],current:r}:o.sid===t.sid&&Array.isArray(o.dayList)&&0!==a.cumulativeWrongNum&&o.dayList.push(a.day)),a})):t.did=!1,t}),c=u.every(function(t){return!t.active}),this.subjectList=c?u.map(function(t){return t.active=!0,t}):u,n.length>0?(e.last=!1,this.lastStudy=e,console.log("localLastStudy",this.lastStudy),this.current=i>=0?i:s>=0?s:-1):Object.keys(o).length>0?(o.last=!0,this.lastStudy=o,this.current=o.current,console.log("remoteLastStudy",this.lastStudy)):(this.current=s>=0?s:0,s>-1?(this.lastStudy={name:a.subjectList[s].name,sid:a.subjectList[s].sid,dayList:[a.subjectList[s].dayList[0].day],last:!1},console.log("otherLastStudy",this.lastStudy)):(this.lastStudy={name:"暂无可复习考点",dayList:[]},console.log("暂无可复习考点",this.lastStudy)))):(this.subjectList=[],this.current=-1,this.lastStudy=e,console.log("localLastStudy2",this.lastStudy)),this.$apply();case 20:case"end":return t.stop()}},t,this)}));return t}()},{key:"getLearnInfo",value:function(){function t(){return e.apply(this,arguments)}var e=_asyncToGenerator(regeneratorRuntime.mark(function t(){var e,n,r,a=this;return regeneratorRuntime.wrap(function(t){for(;;)switch(t.prev=t.next){case 0:return this.loadingHide=!1,this.$apply(),t.next=4,_storage2.default.get("token");case 4:if(t.t0=t.sent,t.t0){t.next=7;break}t.t0=0;case 7:return e=t.t0,n={subjectId:this.lastStudy.sid,stage:this.lastStudy.dayList.join(","),type:2,needProposal:!1,token:e},t.next=11,_api2.default.learnInfo(n);case 11:r=t.sent,this.rnum=r.rnum||0,this.fnum=r.fnum||0,console.log(r.rnum,r.fnum),this.totalWrongNum=r.cumulativeWrongNum,this.allQuestion=r.allQuestion,this.accNum=parseInt(r.rnum/r.allQuestion*100),this.content=r.content,this.hasPointDetail=r.hasPointDetail,this.showCanvas=!0,this.loadingHide=!0,this.$apply(),this.setEchart(),this.content.forEach(function(t){t.points.forEach(function(t,e){t.index=e,a.pointToggleState.push(!1)})});case 25:case"end":return t.stop()}},t,this)}));return t}()},{key:"setEchart",value:function(){var t=this;new _eChart2.default({canvasId:"ringCanvas",type:"ring",extra:{ringWidth:15/t.width,pie:{offsetAngle:-90}},series:[{name:"错误",data:t.fnum,color:"#FF9C79"},{name:"正确",data:t.rnum,color:"#D2F5E2"}],width:310/t.width,height:310/t.width,dataLabel:!1,legend:!1})}},{key:"handleError",value:function(){function t(t,n){return e.apply(this,arguments)}var e=_asyncToGenerator(regeneratorRuntime.mark(function t(e,n){var r=this;return regeneratorRuntime.wrap(function(t){for(;;)switch(t.prev=t.next){case 0:console.log(e),this.loadingHide=!0,this.$apply(),this.$invoke("KcErrorModal","showModal",{err:e,btnMsg:"重新加载",cb:function(){r.loadReviewData()}});case 4:case"end":return t.stop()}},t,this)}));return t}()},{key:"onShareAppMessage",value:function(){return _common2.default.shareTxt()}}]),e}(_wepy2.default.page),_applyDecoratedDescriptor(_class.prototype,"loadReviewData",[_dec],Object.getOwnPropertyDescriptor(_class.prototype,"loadReviewData"),_class.prototype),_class);Page(require("./../npm/wepy/lib/wepy.js").default.$createPage(Home,"pages/reviewIndex")); 
 			}); 	require("pages/reviewIndex.js");
 		__wxRoute = 'pages/reviewFilter';__wxRouteBegin = true; 	__wxAppCurrentFile__ = 'pages/reviewFilter.js';	define("pages/reviewFilter.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			
"use strict";function _interopRequireDefault(e){return e&&e.__esModule?e:{default:e}}function _asyncToGenerator(e){return function(){var t=e.apply(this,arguments);return new Promise(function(e,r){function n(i,s){try{var a=t[i](s),o=a.value}catch(e){return void r(e)}if(!a.done)return Promise.resolve(o).then(function(e){n("next",e)},function(e){n("throw",e)});e(o)}return n("next")})}}function _classCallCheck(e,t){if(!(e instanceof t))throw new TypeError("Cannot call a class as a function")}function _possibleConstructorReturn(e,t){if(!e)throw new ReferenceError("this hasn't been initialised - super() hasn't been called");return!t||"object"!=typeof t&&"function"!=typeof t?e:t}function _inherits(e,t){if("function"!=typeof t&&null!==t)throw new TypeError("Super expression must either be null or a function, not "+typeof t);e.prototype=Object.create(t&&t.prototype,{constructor:{value:e,enumerable:!1,writable:!0,configurable:!0}}),t&&(Object.setPrototypeOf?Object.setPrototypeOf(e,t):e.__proto__=t)}Object.defineProperty(exports,"__esModule",{value:!0});var _createClass=function(){function e(e,t){for(var r=0;r<t.length;r++){var n=t[r];n.enumerable=n.enumerable||!1,n.configurable=!0,"value"in n&&(n.writable=!0),Object.defineProperty(e,n.key,n)}}return function(t,r,n){return r&&e(t.prototype,r),n&&e(t,n),t}}(),_wepy=require("./../npm/wepy/lib/wepy.js"),_wepy2=_interopRequireDefault(_wepy),_storage=require("./../common/storage.js"),_storage2=_interopRequireDefault(_storage),_constant=require("./../common/constant.js"),_constant2=_interopRequireDefault(_constant),Points=function(e){function t(){var e,r,n,i;_classCallCheck(this,t);for(var s=arguments.length,a=Array(s),o=0;o<s;o++)a[o]=arguments[o];return r=n=_possibleConstructorReturn(this,(e=t.__proto__||Object.getPrototypeOf(t)).call.apply(e,[this].concat(a))),n.config={navigationBarTitleText:"选择复习题目",navigationBarBackgroundColor:"#fff"},n.components={},n.mixins=[],n.data={subjectList:[],current:-1,reviewMode:1,showChangeMode:!1},n.computed={selectNum:function(){var e=this,t=0,r=!0,n=!1,i=void 0;try{for(var s,a=this.subjectList[Symbol.iterator]();!(r=(s=a.next()).done);r=!0){var o=s.value;if(o.active&&Array.isArray(o.dayList)&&o.dayList.length>0){t+=o.dayList.reduce(function(t,r){return t+(r.select?1===e.reviewMode?r.cumulativeWrongNum||0:r.allQuestion||0:0)},0)}}}catch(e){n=!0,i=e}finally{try{!r&&a.return&&a.return()}finally{if(n)throw i}}return t}},n.methods={filterConfirm:function(){function e(){return t.apply(this,arguments)}var t=_asyncToGenerator(regeneratorRuntime.mark(function e(){var t,r,n,i,s,a,o,u,c,l,f,h,p;return regeneratorRuntime.wrap(function(e){for(;;)switch(e.prev=e.next){case 0:if(wx.reportAnalytics("reviewfilter_20_click_confirm",{}),!(this.selectNum>0)){e.next=56;break}t={},r=!0,n=!1,i=void 0,e.prev=6,s=this.subjectList[Symbol.iterator]();case 8:if(r=(a=s.next()).done){e.next=39;break}if(o=a.value,!o.active){e.next=36;break}for(t.name=o.name,t.sid=o.sid,t.dayList=[],t.filterMode=this.reviewMode,t.last=!1,u=!0,c=!1,l=void 0,e.prev=19,f=o.dayList[Symbol.iterator]();!(u=(h=f.next()).done);u=!0)p=h.value,p.select&&t.dayList.push(p.day);e.next=27;break;case 23:e.prev=23,e.t0=e.catch(19),c=!0,l=e.t0;case 27:e.prev=27,e.prev=28,!u&&f.return&&f.return();case 30:if(e.prev=30,!c){e.next=33;break}throw l;case 33:return e.finish(30);case 34:return e.finish(27);case 35:return e.abrupt("break",39);case 36:r=!0,e.next=8;break;case 39:e.next=45;break;case 41:e.prev=41,e.t1=e.catch(6),n=!0,i=e.t1;case 45:e.prev=45,e.prev=46,!r&&s.return&&s.return();case 48:if(e.prev=48,!n){e.next=51;break}throw i;case 51:return e.finish(48);case 52:return e.finish(45);case 53:return e.next=55,_storage2.default.set(_constant2.default.KEY_REVIEW_LAST_STUDY,t);case 55:_wepy2.default.navigateBack({delta:1});case 56:case"end":return e.stop()}},e,this,[[6,41,45,53],[19,23,27,35],[28,,30,34],[46,,48,52]])}));return e}(),itemDayTap:function(e){var t=this,r=Number(e);if(this.subjectList[this.current].active){if(1===this.reviewMode&&this.subjectList[this.current].dayList[r].cumulativeWrongNum<=0)return;var n=!this.subjectList[this.current].dayList[r].select,i=this.subjectList[this.current].dayList.filter(function(e){return e.select});if(n)i.length>7?wx.showToast({title:"最多只能选8天哦",icon:"none",duration:3e3}):this.subjectList[this.current].dayList[r].select=n,this.subjectList=this.subjectList.map(function(e,r){return t.current===r?e.active=!0:e.active=!1,e});else{this.subjectList[this.current].dayList[r].select=n;0===this.subjectList[this.current].dayList.filter(function(e){return e.select}).length&&(this.subjectList=this.subjectList.map(function(e,t){return e.active=!0,e}))}}else wx.showToast({title:"你已经选了一个科目的题目\n暂不支持多科目同时复习哦",icon:"none",duration:3e3})},changeModeCtnTap:function(){this.showChangeMode=!1},changeModeMainTap:function(){},changeModeTap:function(e){var t=Number(e);t!==this.reviewMode&&(this.reviewMode=t,1===this.reviewMode&&(this.subjectList=this.subjectList.map(function(e,t){return e.active&&(e.dayList=e.dayList.map(function(e){return e.select&&e.cumulativeWrongNum<=0&&(e.select=!1),e})),e})),this.showChangeMode=!1)},modeMainTap:function(){this.showChangeMode=!this.showChangeMode},filterTabTap:function(e){this.current=Number(e),this.showChangeMode=!1}},i=r,_possibleConstructorReturn(n,i)}return _inherits(t,e),_createClass(t,[{key:"onLoad",value:function(){function e(e){return t.apply(this,arguments)}var t=_asyncToGenerator(regeneratorRuntime.mark(function e(t){return regeneratorRuntime.wrap(function(e){for(;;)switch(e.prev=e.next){case 0:this.current=Number(t.current||-1),this.reviewMode=Number(t.reviewMode)||1,this.getFilterData();case 3:case"end":return e.stop()}},e,this)}));return e}()},{key:"getFilterData",value:function(){var e=this.getCurrentPages();if(Array.isArray(e)&&e.length>1){var t=e.reverse()[1],r=t.data&&Array.isArray(t.data.subjectList)?t.data.subjectList:[];this.subjectList=JSON.parse(JSON.stringify(r))}}}]),t}(_wepy2.default.page);Page(require("./../npm/wepy/lib/wepy.js").default.$createPage(Points,"pages/reviewFilter")); 
 			}); 	require("pages/reviewFilter.js");
 		__wxRoute = 'pages/points';__wxRouteBegin = true; 	__wxAppCurrentFile__ = 'pages/points.js';	define("pages/points.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			
"use strict";function _interopRequireDefault(e){return e&&e.__esModule?e:{default:e}}function _asyncToGenerator(e){return function(){var t=e.apply(this,arguments);return new Promise(function(e,r){function n(o,i){try{var s=t[o](i),a=s.value}catch(e){return void r(e)}if(!s.done)return Promise.resolve(a).then(function(e){n("next",e)},function(e){n("throw",e)});e(a)}return n("next")})}}function _classCallCheck(e,t){if(!(e instanceof t))throw new TypeError("Cannot call a class as a function")}function _possibleConstructorReturn(e,t){if(!e)throw new ReferenceError("this hasn't been initialised - super() hasn't been called");return!t||"object"!=typeof t&&"function"!=typeof t?e:t}function _inherits(e,t){if("function"!=typeof t&&null!==t)throw new TypeError("Super expression must either be null or a function, not "+typeof t);e.prototype=Object.create(t&&t.prototype,{constructor:{value:e,enumerable:!1,writable:!0,configurable:!0}}),t&&(Object.setPrototypeOf?Object.setPrototypeOf(e,t):e.__proto__=t)}Object.defineProperty(exports,"__esModule",{value:!0});var _createClass=function(){function e(e,t){for(var r=0;r<t.length;r++){var n=t[r];n.enumerable=n.enumerable||!1,n.configurable=!0,"value"in n&&(n.writable=!0),Object.defineProperty(e,n.key,n)}}return function(t,r,n){return r&&e(t.prototype,r),n&&e(t,n),t}}(),_wepy=require("./../npm/wepy/lib/wepy.js"),_wepy2=_interopRequireDefault(_wepy),_common=require("./../common/common.js"),_common2=_interopRequireDefault(_common),_api=require("./../common/api.js"),_api2=_interopRequireDefault(_api),_KcShowError=require("./../components/KcShowError.js"),_KcShowError2=_interopRequireDefault(_KcShowError),_error=require("./../mixins/error.js"),_error2=_interopRequireDefault(_error),Points=function(e){function t(){var e,r,n,o;_classCallCheck(this,t);for(var i=arguments.length,s=Array(i),a=0;a<i;a++)s[a]=arguments[a];return r=n=_possibleConstructorReturn(this,(e=t.__proto__||Object.getPrototypeOf(t)).call.apply(e,[this].concat(s))),n.config={navigationBarTitleText:"回顾本题考察的考点",navigationBarBackgroundColor:"#F9FAFC"},n.$repeat={},n.$props={KcShowError:{"xmlns:v-bind":"","v-bind:show.sync":"showErrorModul","v-bind:type.sync":"errorType"}},n.$events={},n.components={KcShowError:_KcShowError2.default},n.mixins=[_error2.default],n.data={source:"",points:[],current:0,success:!1,sectionId:"",subjectId:"",stage:"",pointId:""},n.methods={gotoNextQues:function(){var e=this.getCurrentPages();if(Array.isArray(e)&&e.length>1){var t=e[e.length-2];t.nextTapEvent&&t.nextTapEvent()}_wepy2.default.navigateBack({delta:1})},backToPrePage:function(){_wepy2.default.navigateBack({delta:1})},gotoNextPoit:function(){this.current<0||this.current>=this.points.length-1?this.current=0:this.current++}},o=r,_possibleConstructorReturn(n,o)}return _inherits(t,e),_createClass(t,[{key:"onLoad",value:function(){function e(e){return t.apply(this,arguments)}var t=_asyncToGenerator(regeneratorRuntime.mark(function e(t){return regeneratorRuntime.wrap(function(e){for(;;)switch(e.prev=e.next){case 0:this.source=t.source||"",this.sectionId=t.sectionId,this.subjectId=t.subjectId,this.stage=t.stage,this.pointId=t.pointId;case 5:case"end":return e.stop()}},e,this)}));return e}()},{key:"getPointsData",value:function(){function e(){return t.apply(this,arguments)}var t=_asyncToGenerator(regeneratorRuntime.mark(function e(){var t,r;return regeneratorRuntime.wrap(function(e){for(;;)switch(e.prev=e.next){case 0:return e.prev=0,wx.showLoading({}),t={},this.sectionId&&(t.sectionId=this.sectionId,t.subjectId=this.subjectId,t.stage=this.stage),this.pointId&&(t.pointId=this.pointId),e.next=7,_api2.default.getPointDetail(t);case 7:r=e.sent,Array.isArray(r.points)&&r.points.length>0?(this.points=r.points,this.success=!0,this.$apply()):this.showError({errMsg:"fail data empty"}),wx.hideLoading(),e.next=16;break;case 12:e.prev=12,e.t0=e.catch(0),this.showError(e.t0),wx.hideLoading();case 16:case"end":return e.stop()}},e,this,[[0,12]])}));return e}()},{key:"onShareAppMessage",value:function(e){return _common2.default.shareTxt()}}]),t}(_wepy2.default.page);Page(require("./../npm/wepy/lib/wepy.js").default.$createPage(Points,"pages/points")); 
 			}); 	require("pages/points.js");
 		__wxRoute = 'pages/web';__wxRouteBegin = true; 	__wxAppCurrentFile__ = 'pages/web.js';	define("pages/web.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			
"use strict";function _interopRequireDefault(e){return e&&e.__esModule?e:{default:e}}function _classCallCheck(e,t){if(!(e instanceof t))throw new TypeError("Cannot call a class as a function")}function _possibleConstructorReturn(e,t){if(!e)throw new ReferenceError("this hasn't been initialised - super() hasn't been called");return!t||"object"!=typeof t&&"function"!=typeof t?e:t}function _inherits(e,t){if("function"!=typeof t&&null!==t)throw new TypeError("Super expression must either be null or a function, not "+typeof t);e.prototype=Object.create(t&&t.prototype,{constructor:{value:e,enumerable:!1,writable:!0,configurable:!0}}),t&&(Object.setPrototypeOf?Object.setPrototypeOf(e,t):e.__proto__=t)}Object.defineProperty(exports,"__esModule",{value:!0});var _createClass=function(){function e(e,t){for(var r=0;r<t.length;r++){var n=t[r];n.enumerable=n.enumerable||!1,n.configurable=!0,"value"in n&&(n.writable=!0),Object.defineProperty(e,n.key,n)}}return function(t,r,n){return r&&e(t.prototype,r),n&&e(t,n),t}}(),_wepy=require("./../npm/wepy/lib/wepy.js"),_wepy2=_interopRequireDefault(_wepy),Web=function(e){function t(){var e,r,n,o;_classCallCheck(this,t);for(var a=arguments.length,i=Array(a),u=0;u<a;u++)i[u]=arguments[u];return r=n=_possibleConstructorReturn(this,(e=t.__proto__||Object.getPrototypeOf(t)).call.apply(e,[this].concat(i))),n.config={navigationBarTitleText:""},n.data={url:""},o=r,_possibleConstructorReturn(n,o)}return _inherits(t,e),_createClass(t,[{key:"onLoad",value:function(e){this.url=decodeURIComponent(e.url)}}]),t}(_wepy2.default.page);Page(require("./../npm/wepy/lib/wepy.js").default.$createPage(Web,"pages/web")); 
 			}); 	require("pages/web.js");
 		__wxRoute = 'pages/ranking';__wxRouteBegin = true; 	__wxAppCurrentFile__ = 'pages/ranking.js';	define("pages/ranking.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			
"use strict";function _interopRequireDefault(e){return e&&e.__esModule?e:{default:e}}function _asyncToGenerator(e){return function(){var r=e.apply(this,arguments);return new Promise(function(e,n){function t(a,o){try{var i=r[a](o),c=i.value}catch(e){return void n(e)}if(!i.done)return Promise.resolve(c).then(function(e){t("next",e)},function(e){t("throw",e)});e(c)}return t("next")})}}function _classCallCheck(e,r){if(!(e instanceof r))throw new TypeError("Cannot call a class as a function")}function _possibleConstructorReturn(e,r){if(!e)throw new ReferenceError("this hasn't been initialised - super() hasn't been called");return!r||"object"!=typeof r&&"function"!=typeof r?e:r}function _inherits(e,r){if("function"!=typeof r&&null!==r)throw new TypeError("Super expression must either be null or a function, not "+typeof r);e.prototype=Object.create(r&&r.prototype,{constructor:{value:e,enumerable:!1,writable:!0,configurable:!0}}),r&&(Object.setPrototypeOf?Object.setPrototypeOf(e,r):e.__proto__=r)}function _applyDecoratedDescriptor(e,r,n,t,a){var o={};return Object.keys(t).forEach(function(e){o[e]=t[e]}),o.enumerable=!!o.enumerable,o.configurable=!!o.configurable,("value"in o||o.initializer)&&(o.writable=!0),o=n.slice().reverse().reduce(function(n,t){return t(e,r,n)||n},o),a&&void 0!==o.initializer&&(o.value=o.initializer?o.initializer.call(a):void 0,o.initializer=void 0),void 0===o.initializer&&(Object.defineProperty(e,r,o),o=null),o}Object.defineProperty(exports,"__esModule",{value:!0});var _createClass=function(){function e(e,r){for(var n=0;n<r.length;n++){var t=r[n];t.enumerable=t.enumerable||!1,t.configurable=!0,"value"in t&&(t.writable=!0),Object.defineProperty(e,t.key,t)}}return function(r,n,t){return n&&e(r.prototype,n),t&&e(r,t),r}}(),_dec,_desc,_value,_class,_wepy=require("./../npm/wepy/lib/wepy.js"),_wepy2=_interopRequireDefault(_wepy),_common=require("./../common/common.js"),_common2=_interopRequireDefault(_common),_api=require("./../common/api.js"),_api2=_interopRequireDefault(_api),_decorator=require("./../common/decorator.js"),_KcLoading=require("./../components/KcLoading.js"),_KcLoading2=_interopRequireDefault(_KcLoading),_KcErrorModal=require("./../components/KcErrorModal.js"),_KcErrorModal2=_interopRequireDefault(_KcErrorModal),TITLE_RANK=["为100%","为90%-100%","为80%-90%","为70%-80%","为60%-70%","为60%以下"],Ranking=(_dec=(0,_decorator.trycatch)(),_class=function(e){function r(){var e,n,t,a;_classCallCheck(this,r);for(var o=arguments.length,i=Array(o),c=0;c<o;c++)i[c]=arguments[c];return n=t=_possibleConstructorReturn(this,(e=r.__proto__||Object.getPrototypeOf(r)).call.apply(e,[this].concat(i))),t.config={navigationBarTitleText:"看看排名情况"},t.$repeat={},t.$props={KcLoading:{"xmlns:v-bind":"","v-bind:loadingHide.sync":"loadingHide"}},t.$events={},t.components={KcLoading:_KcLoading2.default,KcErrorModal:_KcErrorModal2.default},t.mixins=[],t.data={loadingHide:!0,rankType:1,avatar:"",percent:0,rank:0,sameRankingNum:0,beyondRate:0,ranking:[]},t.methods={},a=n,_possibleConstructorReturn(t,a)}return _inherits(r,e),_createClass(r,[{key:"onLoad",value:function(e){this.rankType=parseInt(e.rankType)||1;var r=this.$parent.globalData.userInfo;this.avatar=r?r.head:"",this.loadRankData()}},{key:"loadRankData",value:function(){function e(){return r.apply(this,arguments)}var r=_asyncToGenerator(regeneratorRuntime.mark(function e(){var r,n,t,a,o,i;return regeneratorRuntime.wrap(function(e){for(;;)switch(e.prev=e.next){case 0:return this.loadingHide=!1,e.next=3,_api2.default.getRankingDetail({rankingType:this.rankType,graspRate:this.percent});case 3:r=e.sent,n=r.sameRankingNum,t=r.beyondRate,a=r.ranking,o=r.graspRate,i=r.rank,this.percent=o,this.rank=i,this.sameRankingNum=n,this.beyondRate=t,this.ranking=this.formatDataRanking(a),this.loadingHide=!0,this.$apply();case 16:case"end":return e.stop()}},e,this)}));return e}()},{key:"formatDataRanking",value:function(e){var r=this;return Array.isArray(e)?(e.length>6&&(e=e.slice(0,6)),e=e.map(function(e,n){return e.title=(1===r.rankType?"掌握率":"准确率")+TITLE_RANK[n>5?5:n],Array.isArray(e.heads)&&e.heads.length>5&&(e.heads=e.heads.slice(0,5)),e})):[]}},{key:"handleError",value:function(){function e(e,n){return r.apply(this,arguments)}var r=_asyncToGenerator(regeneratorRuntime.mark(function e(r,n){var t=this;return regeneratorRuntime.wrap(function(e){for(;;)switch(e.prev=e.next){case 0:this.loadingHide=!0,this.$apply(),this.$invoke("KcErrorModal","showModal",{err:r,btnMsg:"重新加载",cb:function(){t.loadRankData()}});case 3:case"end":return e.stop()}},e,this)}));return e}()},{key:"onShareAppMessage",value:function(e){return _common2.default.shareTxt()}}]),r}(_wepy2.default.page),_applyDecoratedDescriptor(_class.prototype,"loadRankData",[_dec],Object.getOwnPropertyDescriptor(_class.prototype,"loadRankData"),_class.prototype),_class);Page(require("./../npm/wepy/lib/wepy.js").default.$createPage(Ranking,"pages/ranking")); 
 			}); 	require("pages/ranking.js");
 		__wxRoute = 'pages/study';__wxRouteBegin = true; 	__wxAppCurrentFile__ = 'pages/study.js';	define("pages/study.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			
"use strict";function _interopRequireDefault(t){return t&&t.__esModule?t:{default:t}}function _asyncToGenerator(t){return function(){var e=t.apply(this,arguments);return new Promise(function(t,i){function n(s,r){try{var a=e[s](r),o=a.value}catch(t){return void i(t)}if(!a.done)return Promise.resolve(o).then(function(t){n("next",t)},function(t){n("throw",t)});t(o)}return n("next")})}}function _classCallCheck(t,e){if(!(t instanceof e))throw new TypeError("Cannot call a class as a function")}function _possibleConstructorReturn(t,e){if(!t)throw new ReferenceError("this hasn't been initialised - super() hasn't been called");return!e||"object"!=typeof e&&"function"!=typeof e?t:e}function _inherits(t,e){if("function"!=typeof e&&null!==e)throw new TypeError("Super expression must either be null or a function, not "+typeof e);t.prototype=Object.create(e&&e.prototype,{constructor:{value:t,enumerable:!1,writable:!0,configurable:!0}}),e&&(Object.setPrototypeOf?Object.setPrototypeOf(t,e):t.__proto__=e)}function _applyDecoratedDescriptor(t,e,i,n,s){var r={};return Object.keys(n).forEach(function(t){r[t]=n[t]}),r.enumerable=!!r.enumerable,r.configurable=!!r.configurable,("value"in r||r.initializer)&&(r.writable=!0),r=i.slice().reverse().reduce(function(i,n){return n(t,e,i)||i},r),s&&void 0!==r.initializer&&(r.value=r.initializer?r.initializer.call(s):void 0,r.initializer=void 0),void 0===r.initializer&&(Object.defineProperty(t,e,r),r=null),r}Object.defineProperty(exports,"__esModule",{value:!0});var _createClass=function(){function t(t,e){for(var i=0;i<e.length;i++){var n=e[i];n.enumerable=n.enumerable||!1,n.configurable=!0,"value"in n&&(n.writable=!0),Object.defineProperty(t,n.key,n)}}return function(e,i,n){return i&&t(e.prototype,i),n&&t(e,n),e}}(),_dec,_desc,_value,_class,_wepy=require("./../npm/wepy/lib/wepy.js"),_wepy2=_interopRequireDefault(_wepy),_api=require("./../common/api.js"),_api2=_interopRequireDefault(_api),_common=require("./../common/common.js"),_common2=_interopRequireDefault(_common),_storage=require("./../common/storage.js"),_storage2=_interopRequireDefault(_storage),_constant=require("./../common/constant.js"),_constant2=_interopRequireDefault(_constant),_decorator=require("./../common/decorator.js"),_KcLoading=require("./../components/KcLoading.js"),_KcLoading2=_interopRequireDefault(_KcLoading),_KcErrorModal=require("./../components/KcErrorModal.js"),_KcErrorModal2=_interopRequireDefault(_KcErrorModal),_KcUpValue=require("./../components/KcUpValue.js"),_KcUpValue2=_interopRequireDefault(_KcUpValue),_kcLog=require("./../npm/@kc-base/kc-log/dist/kc-log.js"),_kcLog2=_interopRequireDefault(_kcLog),log=require("./../common/log.js"),Study=(_dec=(0,_decorator.trycatch)(),_class=function(t){function e(){var t,i,n,s;_classCallCheck(this,e);for(var r=arguments.length,a=Array(r),o=0;o<r;o++)a[o]=arguments[o];return i=n=_possibleConstructorReturn(this,(t=e.__proto__||Object.getPrototypeOf(e)).call.apply(t,[this].concat(a))),n.config={navigationBarTitleText:"正在答题",navigationBarTextStyle:"black",navigationBarBackgroundColor:"#F9FAFC"},n.data={loadingHide:!0,tipsShow:!1,index:0,btn:"对答案",sid:"",days:[],type:"",topicNum:"",status:0,handTipShowTime:0,onlyFalse:!1,handTips:!0,optionStatus:[0,0,0,0],currentAnswerStatus:0,hasPointDetail:0,topicList:[],answerList:[],endAlertShow:!1,accuracyRate:0,changeValue:0,eggShow:!1,markTips:!1,longtips:!1,needMarkTips:!0,needLongTips:!0,maskShow:!1,submitStatus:0,wrongTopic:[],hasVip:!1,firstVideoPlay:!1,videoContext:null,imgSrc:"",title:"",text1:"",text2:"",text3:"",leftBtnText:"",rightBtnText:"",leftCb:null,rightCb:null,firstVideoClick:!1,upValue:0,videoMaskShow:!0,lock:!1,isnewuser:0,isAuth:!1,isAuthPhone:!1,isLast:!1,loginLock:!1,code:"",showPrivacy:!1},n.$repeat={},n.$props={KcLoading:{"xmlns:v-bind":"","v-bind:loadingHide.sync":"loadingHide"},KcUpValue:{"xmlns:v-bind":"","v-bind:title.sync":"title","v-bind:text1.sync":"text1","v-bind:text2.sync":"text2","v-bind:text3.sync":"text3","v-bind:leftBtnText.sync":"leftBtnText","v-bind:rightBtnText.sync":"rightBtnText","v-bind:leftCb.sync":"leftCb","v-bind:rightCb.sync":"rightCb","v-bind:imgSrc.sync":"imgSrc"}},n.$events={},n.components={KcLoading:_KcLoading2.default,KcErrorModal:_KcErrorModal2.default,KcUpValue:_KcUpValue2.default},n.mixins=[],n.computed={percent:function(){return parseInt((this.index+1)/this.topicNum*100)},nowTopic:function(){return this.topicList[this.index]},canClick:function(){if(1===this.status){for(var t=0,e=0,i=this.optionStatus.length;e<i;e++)0!==this.optionStatus[e]&&t++;return 0!==t&&(1!==t||!this.nowTopic.isCheckbox)}return!0},yourAnswer:function(){for(var t="",e=this.optionStatus,i=0;i<4;i++)if(1===e[i]||2===e[i]||3===e[i])switch(i){case 0:t+="A";break;case 1:t+="B";break;case 2:t+="C";break;case 3:t+="D"}return t},rightAnswer:function(){var t="";if(this.nowTopic)for(var e=this.nowTopic.rightOption,i=0;i<e.length;i++)switch(e[i]-1){case 0:t+="A";break;case 1:t+="B";break;case 2:t+="C";break;case 3:t+="D"}return t}},n.methods={handleOpenPrivacyContract:function(){wx.openPrivacyContract({success:function(){},fail:function(){},complete:function(){}})},handleAgreePrivacyAuthorization:function(){this.resolvePrivacyAuthorization({buttonId:"agree-btn",event:"agree"}),this.showPrivacy=!1},cancelPrivacy:function(){this.resolvePrivacyAuthorization({event:"disagree"}),this.showPrivacy=!1},getPhoneNumber:function(){function t(t){return e.apply(this,arguments)}var e=_asyncToGenerator(regeneratorRuntime.mark(function t(e){var i,n,s;return regeneratorRuntime.wrap(function(t){for(;;)switch(t.prev=t.next){case 0:if(_kcLog2.default.send({pagename:"studyPage",name:"phoneWindowShow",category:"webShow",pt:"mini",bundleid:"zhengzhi1000"}),"getPhoneNumber:ok"!==e.detail.errMsg){t.next=13;break}return _kcLog2.default.send({pagename:"studyPage",name:"phoneAgreeClick",category:"webClick",pt:"mini",bundleid:"zhengzhi1000"}),i={code:this.code},t.next=6,_api2.default.getOpenId(i);case 6:return n=t.sent,s=n.openId,t.next=10,_api2.default.setPhoneNumber({iv:e.detail.iv,encryptedData:e.detail.encryptedData,openId:s});case 10:_storage2.default.set("isAuthPhone",!0),t.next=15;break;case 13:_kcLog2.default.send({pagename:"studyPage",name:"phoneRefuseClick",category:"webClick",pt:"mini",bundleid:"zhengzhi1000"}),wx.showToast({title:"授权手机号失败请稍后再试"});case 15:return t.next=17,this.submitAnswers();case 17:case"end":return t.stop()}},t,this)}));return t}(),wxLogin:function(){function t(t){return e.apply(this,arguments)}var e=_asyncToGenerator(regeneratorRuntime.mark(function t(e){var i,n,s=this;return regeneratorRuntime.wrap(function(t){for(;;)switch(t.prev=t.next){case 0:if(!this.loginLock){t.next=2;break}return t.abrupt("return",!1);case 2:_kcLog2.default.send({pagename:"studyPage",name:"signupWindowShow",category:"webShow",pt:"mini",bundleid:"zhengzhi1000"}),this.loginLock=!0,i=this.wxSilentLogin(),n=this.wxGetUserProfile(),Promise.all([i,n]).then(function(){var t=_asyncToGenerator(regeneratorRuntime.mark(function t(e){var i,n,r,a;return regeneratorRuntime.wrap(function(t){for(;;)switch(t.prev=t.next){case 0:return _kcLog2.default.send({pagename:"studyPage",name:"loginClick",category:"login",pt:"mini",bundleid:"zhengzhi1000"}),i=e[0],n=e[1].iv,r=e[1].encryptedData,a={code:i,encryptedData:r,iv:n},t.next=7,_api2.default.register(a);case 7:return t.next=9,s.submitAnswers();case 9:s.$apply();case 10:case"end":return t.stop()}},t,s)}));return function(e){return t.apply(this,arguments)}}()).catch(function(){_kcLog2.default.send({pagename:"studyPage",name:"refuseClick",category:"webClick",pt:"mini",bundleid:"zhengzhi1000"}),s.loginLock=!1,s.$apply()});case 7:case"end":return t.stop()}},t,this)}));return t}(),hideMask:function(){this.maskShow=!1,this.longtips=!1,this.markTips=!1},formSubmit:function(t){var e=t.detail.formId;_common2.default.collectFormID(e)},markCancel:function(){this.markTips=!1,this.maskShow=!1,this.$apply()},longCancel:function(){this.longtips=!1,this.maskShow=!1,this.$apply()},goReport:function(){wx.redirectTo({url:"report?sid="+this.sid+"&days="+JSON.stringify(this.days)+"&type="+this.type+"&onlyFalse="+this.onlyFalse})},removeWrong:function(){this.answerList[this.index]=3},unremoveWrong:function(){this.answerList[this.index]=this.currentAnswerStatus},mark:function(){1===this.type&&wx.reportAnalytics("study_20_click_mark",{}),this.needMarkTips&&(this.markTips=!0,this.maskShow=!0,_storage2.default.set("needMarkTips",!1),this.needMarkTips=!1),this.answerList[this.index]=2},unmark:function(){this.answerList[this.index]=1},mainTap:function(){function t(){return e.apply(this,arguments)}var e=_asyncToGenerator(regeneratorRuntime.mark(function t(){return regeneratorRuntime.wrap(function(t){for(;;)switch(t.prev=t.next){case 0:if(3!==this.type){t.next=12;break}if(this.index!==this.topicList.length-1){t.next=4;break}return wx.redirectTo({url:"report?sid="+this.sid+"&days="+JSON.stringify(this.days)+"&type="+this.type+"&onlyFalse="+this.onlyFalse}),t.abrupt("return");case 4:return this.videoContext&&this.videoContext.stop(),this.index=this.index+1,this.optionStatus=this.wrongTopic[this.index].optionStatus,log.info("index",this.index),log.info("optionStatus",this.optionStatus),this.index===this.topicList.length-1?this.btn="回报告页":this.btn="下一题",this.$apply(),t.abrupt("return");case 12:this.firstVideoClick=!1,this.videoMaskShow=!0,this.nextTapEvent();case 15:case"end":return t.stop()}},t,this)}));return t}(),tapOption:function(t){1===this.status&&(this.nowTopic.isCheckbox?1===this.optionStatus[t]?this.optionStatus[t]=0:this.optionStatus[t]=1:(this.optionStatus=[0,0,0,0],this.optionStatus[t]=1))},touchEnd:function(){function t(t){return e.apply(this,arguments)}var e=_asyncToGenerator(regeneratorRuntime.mark(function t(e){return regeneratorRuntime.wrap(function(t){for(;;)switch(t.prev=t.next){case 0:this.status=1,this.handTips=!1,this.handTipShowTime<10&&this.handTipShowTime++,_storage2.default.set("handTipShowTime",this.handTipShowTime),wx.reportAnalytics("study_20_click_main",{isnewuser:this.isnewuser});case 5:case"end":return t.stop()}},t,this)}));return t}(),longpress:function(){this.eggShow=!0,this.needLongTips&&(this.maskShow=!0,this.longtips=!0,_storage2.default.set("needLongTips",!1),this.needLongTips=!1),wx.reportAnalytics("study_19_longpress",{})},videoPlay:function(){function t(){return e.apply(this,arguments)}var e=_asyncToGenerator(regeneratorRuntime.mark(function t(){var e;return regeneratorRuntime.wrap(function(t){for(;;)switch(t.prev=t.next){case 0:if(!this.hasVip&&this.firstVideoPlay&&wx.reportAnalytics("study_20_click_novipfirst",{}),this.hasVip||this.firstVideoPlay||wx.reportAnalytics("study_20_click_novipnofirst",{}),1!==this.nowTopic.videoState){t.next=4;break}return t.abrupt("return");case 4:this.hasVip||(this.firstVideoPlay?(this.firstVideoPlay=!1,this.firstVideoClick=!0,this.topicList[this.index].videoState=1,this.unlockVideo(this.nowTopic.id),log.info("firstfree unlock")):(e=this,this.upValue>=10?(this.imgSrc="../images/components/icon_lock@2x.png",this.title="解锁当前视频",this.text1="需消耗",this.text2="10点UP值",this.text3="你目前拥有"+this.upValue+"点UP值",this.leftBtnText="取消",this.rightBtnText="确定",this.leftCb=function(){this.close()},this.rightCb=function(){this.unlockVideo(e.nowTopic.id),log.info("rightbtn unlock"),wx.reportAnalytics("study_20_show_unlockok",{})},this.$invoke("KcUpValue","showModal"),wx.reportAnalytics("study_20_show_unlock",{})):(this.imgSrc="../images/components/icon_face@2x.png",this.title="解锁当前视频",this.text1="需消耗",this.text2="10点UP值",this.text3="你的up值不够",this.leftBtnText="",this.rightBtnText="知道了",this.rightCb=function(){this.close()},this.$invoke("KcUpValue","showModal"),wx.reportAnalytics("study_20_show_nounlockok",{}))));case 5:case"end":return t.stop()}},t,this)}));return t}(),loadedmetadata:function(){!this.hasVip&&this.firstVideoPlay&&wx.reportAnalytics("study_20_show_novipfirst",{}),this.hasVip||this.firstVideoPlay||wx.reportAnalytics("study_20_show_novipnofirst",{}),this.hasVip&&wx.reportAnalytics("study_20_show_vipvideo",{})},videoErrorCallback:function(t){log.info("视频错误信息:",t.detail.errMsg)},onVideoPlay:function(){this.hasVip&&!this.lock&&(wx.reportAnalytics("study_20_click_vipvideo",{}),this.lock=!0)}},n.events={unlockVideoSuccess:function(){n.getUserInfo(),n.topicList[n.index].videoState=1,n.videoMaskShow=!1,n.$apply(),n.videoContext.play()}},s=i,_possibleConstructorReturn(n,s)}return _inherits(e,t),_createClass(e,[{key:"checkAnswer",value:function(){for(var t=1,e=0;e<4;e++){var i=this.nowTopic.rightOption.indexOf(e+1)>=0;1===this.optionStatus[e]?i?this.optionStatus[e]=3:(this.optionStatus[e]=2,t=0):i&&(this.nowTopic.isCheckbox?this.optionStatus[e]=4:this.optionStatus[e]=5,t=0)}this.currentAnswerStatus=t,this.answerList[this.index]=t}},{key:"nextTapEvent",value:function(){function t(){return e.apply(this,arguments)}var e=_asyncToGenerator(regeneratorRuntime.mark(function t(){var e,i,n,s,r;return regeneratorRuntime.wrap(function(t){for(;;)switch(t.prev=t.next){case 0:if(t.prev=0,1!==this.status||!this.canClick){t.next=31;break}return wx.reportAnalytics("study_20_click_maintap",{isnewuser:this.isnewuser}),t.next=5,_storage2.default.get("learnStorage");case 5:if(e=t.sent,i=new Date,i.setTime(i.getTime()-36e5),n=""+i.getFullYear()+i.getMonth()+i.getDay(),e.nowDay=n,this.checkAnswer(),wx.setNavigationBarTitle({title:"答案解析"}),this.index!==this.topicList.length-1){t.next=22;break}return this.isLast=!0,t.next=16,_wepy2.default.login();case 16:s=t.sent,r=s.code,this.code=r,this.btn="提交本次答题数据",t.next=23;break;case 22:this.btn="下一题";case 23:this.status=2,1===this.type?this.index===this.topicList.length-1?(e.learn.index=0,e.learn.sid=-1,e.learn.answerList=[]):(e.learn.index=this.index+1,e.learn.sid=this.sid,e.learn.answerList=this.answerList):this.index===this.topicList.length-1?(e.review["sid"+this.sid].days=[],e.review["sid"+this.sid].index=0,e.review["sid"+this.sid].onlyFalse=this.onlyFalse,e.review["sid"+this.sid].answerList=[]):(e.review["sid"+this.sid].days=this.days,e.review["sid"+this.sid].onlyFalse=this.onlyFalse,e.review["sid"+this.sid].index=this.index+1,e.review["sid"+this.sid].answerList=this.answerList),0===this.answerList[this.index]&&this.wrongTopic.push({index:this.index,optionStatus:this.optionStatus}),_storage2.default.set("learnStorage",e),_storage2.default.set("wrongTopic",this.wrongTopic),log.info("setwrongTopic",this.wrongTopic),t.next=49;break;case 31:if(2!==this.status){t.next=49;break}if(wx.reportAnalytics("study_20_click_next",{isnewuser:this.isnewuser}),this.index!==this.topicList.length-1){t.next=39;break}return 1===this.type&&wx.reportAnalytics("study_20_click_submit",{}),t.next=37,this.submitAnswers();case 37:t.next=49;break;case 39:this.status=0,this.btn="对答案",this.eggShow=!1,this.handTips=!0,_wepy2.default.setNavigationBarTitle({title:2===this.type?this.onlyFalse?"正在复习错过的题":"正在复习当天所有题目":"正在答题"}),this.lock=!1,this.videoContext.stop(),this.index=this.index+1,this.eggAlertShow=!1,this.optionStatus=[0,0,0,0];case 49:this.$apply(),t.next=54;break;case 52:t.prev=52,t.t0=t.catch(0);case 54:case"end":return t.stop()}},t,this,[[0,52]])}));return t}()},{key:"submitAnswers",value:function(){function t(){return e.apply(this,arguments)}var e=_asyncToGenerator(regeneratorRuntime.mark(function t(){var e,i,n;return regeneratorRuntime.wrap(function(t){for(;;)switch(t.prev=t.next){case 0:if(1!==this.submitStatus){t.next=2;break}return t.abrupt("return");case 2:return t.prev=2,this.submitStatus=1,this.$apply(),t.next=7,_storage2.default.get("token");case 7:if(t.t0=t.sent,t.t0){t.next=10;break}t.t0=0;case 10:return e=t.t0,log.info("学习页提交答案","subjectId",this.sid,"stage",this.days.join(","),"type",this.type,"answers",this.getFormatAnswerList(this.answerList)),t.next=14,_api2.default.submitAnswers({subjectId:this.sid,stage:this.days.join(","),type:this.type,answers:this.getFormatAnswerList(this.answerList),onlyFalse:this.onlyFalse,token:e});case 14:i=t.sent,this.accuracyRate=i.accuracyRate,this.changeValue=i.changeValue,this.submitStatus=0,2===this.type&&_storage2.default.remove(_constant2.default.KEY_REVIEW_LAST_STUDY),this.type,wx.redirectTo({url:"report?sid="+this.sid+"&days="+JSON.stringify(this.days)+"&type="+this.type+"&onlyFalse="+this.onlyFalse}),t.next=29;break;case 23:t.prev=23,t.t1=t.catch(2),this.submitStatus=0,n="提交答案失败，请稍后再试",t.t1&&5010===t.t1.code&&(n="重复提交，请稍后再试"),wx.showToast({title:n,icon:"none",duration:3e3});case 29:this.$apply();case 30:case"end":return t.stop()}},t,this,[[2,23]])}));return t}()},{key:"getFormatAnswerList",value:function(t){var e=this,i=[],n={};return t.forEach(function(t,i){var s=e.topicList[i].stage;n.hasOwnProperty(s)?n[s].push(t):n[s]=[t]}),Object.keys(n).forEach(function(t){i.push({stage:t,answerList:n[t]})}),JSON.stringify(i)}},{key:"onLoad",value:function(){function t(t){return e.apply(this,arguments)}var e=_asyncToGenerator(regeneratorRuntime.mark(function t(e){var i,n,s=this;return regeneratorRuntime.wrap(function(t){for(;;)switch(t.prev=t.next){case 0:return wx.onNeedPrivacyAuthorization(function(t){console.log("onNeedPrivacyAuthorization"),s.showPrivacy=!0,s.resolvePrivacyAuthorization=t,s.$apply()}),this.sid=Number(e.sid),this.days=e.days?JSON.parse(e.days):[],this.type=Number(e.type),this.onlyFalse=JSON.parse(e.onlyFalse),this.isLast=!1,_wepy2.default.setNavigationBarTitle({title:2===this.type?this.onlyFalse?"正在复习错过的题":"正在复习当天所有题目":"正在答题"}),3===this.type&&(this.status=2,this.btn="下一题"),t.next=10,this.getStorageData();case 10:return t.next=12,this.getStudyData();case 12:return t.next=14,this.getUserInfo();case 14:return this.videoContext=wx.createVideoContext("myVideo"),t.next=17,_storage2.default.get("preSubject");case 17:if(t.t0=t.sent,t.t0){t.next=20;break}t.t0=0;case 20:return i=t.t0,t.next=23,_storage2.default.get("preDay");case 23:if(t.t1=t.sent,t.t1){t.next=26;break}t.t1=0;case 26:if(n=t.t1,this.sid!==parseInt(i)||parseInt(this.days[0])!==parseInt(n)){t.next=34;break}return t.next=30,_storage2.default.get("wrongTopic");case 30:if(t.t2=t.sent,t.t2){t.next=33;break}t.t2=[];case 33:this.wrongTopic=t.t2;case 34:return _storage2.default.set("preSubject",this.sid),_storage2.default.set("preDay",this.days[0]),t.next=38,_storage2.default.get("is_auth");case 38:if(t.t3=t.sent,t.t3){t.next=41;break}t.t3=!1;case 41:return this.isAuth=t.t3,t.next=44,_storage2.default.get("isAuthPhone");case 44:if(t.t4=t.sent,t.t4){t.next=47;break}t.t4=!1;case 47:this.isAuthPhone=t.t4,this.$apply();case 49:case"end":return t.stop()}},t,this)}));return t}()},{key:"getStorageData",value:function(){function t(){return e.apply(this,arguments)}var e=_asyncToGenerator(regeneratorRuntime.mark(function t(){var e,i,n;return regeneratorRuntime.wrap(function(t){for(;;)switch(t.prev=t.next){case 0:return t.prev=0,t.next=3,_storage2.default.get("handTipShowTime");case 3:if(t.t0=t.sent,t.t0){t.next=6;break}t.t0=0;case 6:return this.handTipShowTime=t.t0,t.next=9,_storage2.default.get("needMarkTips");case 9:return this.needMarkTips=t.sent,void 0===this.needMarkTips&&(this.needMarkTips=!0),t.next=13,_storage2.default.get("needLongTips");case 13:return this.needLongTips=t.sent,void 0===this.needLongTips&&(this.needLongTips=!0),t.next=17,_storage2.default.get("learnStorage");case 17:return e=t.sent,i=new Date,i.setTime(i.getTime()-36e5),n=""+i.getFullYear()+i.getMonth()+i.getDay(),e&&e.nowDay===n?1===this.type&&this.sid===e.learn.sid?(this.index=e.learn.index,this.answerList=e.learn.answerList):2===this.type&&e.review["sid"+this.sid].days.sort().toString()===this.days.sort().toString()&&e.review["sid"+this.sid].onlyFalse===this.onlyFalse&&(this.index=e.review["sid"+this.sid].index,this.answerList=e.review["sid"+this.sid].answerList):(e={nowDay:n,learn:{sid:-1,index:0,answerList:[]},review:{sid1:{days:[],index:0,onlyFalse:!1,answerList:[]},sid2:{days:[],index:0,onlyFalse:!1,answerList:[]},sid3:{days:[],index:0,onlyFalse:!1,answerList:[]},sid4:{days:[],index:0,onlyFalse:!1,answerList:[]}}},_storage2.default.set("learnStorage",e)),t.next=24,_storage2.default.get("hasVip");case 24:return this.hasVip=t.sent,t.next=27,_storage2.default.get("isnewuser");case 27:if(t.t1=t.sent,t.t1){t.next=30;break}t.t1=0;case 30:this.isnewuser=t.t1,this.$apply(),t.next=36;break;case 34:t.prev=34,t.t2=t.catch(0);case 36:case"end":return t.stop()}},t,this,[[0,34]])}));return t}()},{key:"getStudyData",value:function(){function t(){return e.apply(this,arguments)}var e=_asyncToGenerator(regeneratorRuntime.mark(function t(){var e,i=this;return regeneratorRuntime.wrap(function(t){for(;;)switch(t.prev=t.next){case 0:return this.loadingHide=!1,this.$apply(),t.next=4,_api2.default.getDayInfo({subjectId:this.sid,stage:this.days.join(","),type:this.type,onlyFalse:this.onlyFalse});case 4:if(e=t.sent,this.topicNum=e.questionNum,this.topicList=e.questions,log.info("学习页请求参数","subjectId:",this.sid,"stage",this.days.join(","),"type",this.type,"onlyFalse",this.onlyFalse),3!==this.type){t.next=24;break}return this.topicList=[],t.prev=10,t.next=13,_storage2.default.get("wrongTopic");case 13:this.wrongTopic=t.sent,t.next=19;break;case 16:t.prev=16,t.t0=t.catch(10),log.info("wrongTopicError",t.t0);case 19:log.info("wrongTopic",this.wrongTopic),this.wrongTopic.forEach(function(t){i.topicList.push(e.questions[t.index]),log.info("错题",e.questions[t.index])}),this.topicNum=this.wrongTopic.length,this.optionStatus=this.wrongTopic[0].optionStatus,log.info("第一题optionStatus状态",this.optionStatus);case 24:this.firstVideoPlay=e.firstFree,this.hasPointDetail=e.hasPointDetail,this.loadingHide=!0,this.$apply();case 28:case"end":return t.stop()}},t,this,[[10,16]])}));return t}()},{key:"unlockVideo",value:function(){function t(t){return e.apply(this,arguments)}var e=_asyncToGenerator(regeneratorRuntime.mark(function t(e){var i;return regeneratorRuntime.wrap(function(t){for(;;)switch(t.prev=t.next){case 0:return t.next=2,_storage2.default.get("token");case 2:if(t.t0=t.sent,t.t0){t.next=5;break}t.t0=0;case 5:i=t.t0,_api2.default.unlockVideo({questionId:e,token:i}),this.videoMaskShow=!1,this.$apply(),this.videoContext.play();case 10:case"end":return t.stop()}},t,this)}));return t}()},{key:"reportLearnTime",value:function(t){this.type}},{key:"onShow",value:function(){this.reportLearnTime(0)}},{key:"onHide",value:function(){this.submitAnswersBehaviour(),this.reportLearnTime(1)}},{key:"onUnload",value:function(){this.submitAnswersBehaviour(),this.reportLearnTime(1)}},{key:"submitAnswersBehaviour",value:function(){function t(){return e.apply(this,arguments)}var e=_asyncToGenerator(regeneratorRuntime.mark(function t(){return regeneratorRuntime.wrap(function(t){for(;;)switch(t.prev=t.next){case 0:if(1!==this.type){t.next=8;break}return t.prev=1,t.next=4,_api2.default.submitAnswersBehaviour({subjectId:this.sid,stage:this.days.join(","),answerNum:2===this.status?this.index+1:this.index});case 4:t.next=8;break;case 6:t.prev=6,t.t0=t.catch(1);case 8:case"end":return t.stop()}},t,this,[[1,6]])}));return t}()},{key:"getUserInfo",value:function(){function t(){return e.apply(this,arguments)}var e=_asyncToGenerator(regeneratorRuntime.mark(function t(){var e;return regeneratorRuntime.wrap(function(t){for(;;)switch(t.prev=t.next){case 0:return t.next=2,_api2.default.getUserInfo();case 2:e=t.sent,this.upValue=e.user.upValue,this.$apply();case 5:case"end":return t.stop()}},t,this)}));return t}()},{key:"onPageScroll",value:function(t){1===this.type&&1===this.sid&&1===this.days[0]&&3===this.index&&2===this.status&&t.scrollTop>0?this.tipsShow||(this.tipsShow=!0,this.$apply()):this.tipsShow&&(this.tipsShow=!1,this.$apply())}},{key:"handleError",value:function(){function t(t,i){return e.apply(this,arguments)}var e=_asyncToGenerator(regeneratorRuntime.mark(function t(e,i){var n=this;return regeneratorRuntime.wrap(function(t){for(;;)switch(t.prev=t.next){case 0:this.loadingHide=!0,this.$apply(),this.$invoke("KcErrorModal","showModal",{err:e,btnMsg:"重新加载",cb:function(){n.getStudyData()}});case 3:case"end":return t.stop()}},t,this)}));return t}()},{key:"wxSilentLogin",value:function(){return new Promise(function(t,e){wx.login({success:function(e){t(e.code)},fail:function(t){e(t)}})})}},{key:"wxGetUserProfile",value:function(){return new Promise(function(t,e){wx.getUserProfile({desc:"小程序需要您的授权才能正常使用",success:function(e){t(e)},fail:function(t){e(t)}})})}}]),e}(_wepy2.default.page),_applyDecoratedDescriptor(_class.prototype,"getStudyData",[_dec],Object.getOwnPropertyDescriptor(_class.prototype,"getStudyData"),_class.prototype),_class);Page(require("./../npm/wepy/lib/wepy.js").default.$createPage(Study,"pages/study")); 
 			}); 	require("pages/study.js");
 		__wxRoute = 'pages/upValueList';__wxRouteBegin = true; 	__wxAppCurrentFile__ = 'pages/upValueList.js';	define("pages/upValueList.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			
"use strict";function _interopRequireDefault(e){return e&&e.__esModule?e:{default:e}}function _asyncToGenerator(e){return function(){var t=e.apply(this,arguments);return new Promise(function(e,r){function n(i,o){try{var a=t[i](o),u=a.value}catch(e){return void r(e)}if(!a.done)return Promise.resolve(u).then(function(e){n("next",e)},function(e){n("throw",e)});e(u)}return n("next")})}}function _classCallCheck(e,t){if(!(e instanceof t))throw new TypeError("Cannot call a class as a function")}function _possibleConstructorReturn(e,t){if(!e)throw new ReferenceError("this hasn't been initialised - super() hasn't been called");return!t||"object"!=typeof t&&"function"!=typeof t?e:t}function _inherits(e,t){if("function"!=typeof t&&null!==t)throw new TypeError("Super expression must either be null or a function, not "+typeof t);e.prototype=Object.create(t&&t.prototype,{constructor:{value:e,enumerable:!1,writable:!0,configurable:!0}}),t&&(Object.setPrototypeOf?Object.setPrototypeOf(e,t):e.__proto__=t)}function _applyDecoratedDescriptor(e,t,r,n,i){var o={};return Object.keys(n).forEach(function(e){o[e]=n[e]}),o.enumerable=!!o.enumerable,o.configurable=!!o.configurable,("value"in o||o.initializer)&&(o.writable=!0),o=r.slice().reverse().reduce(function(r,n){return n(e,t,r)||r},o),i&&void 0!==o.initializer&&(o.value=o.initializer?o.initializer.call(i):void 0,o.initializer=void 0),void 0===o.initializer&&(Object.defineProperty(e,t,o),o=null),o}Object.defineProperty(exports,"__esModule",{value:!0});var _createClass=function(){function e(e,t){for(var r=0;r<t.length;r++){var n=t[r];n.enumerable=n.enumerable||!1,n.configurable=!0,"value"in n&&(n.writable=!0),Object.defineProperty(e,n.key,n)}}return function(t,r,n){return r&&e(t.prototype,r),n&&e(t,n),t}}(),_dec,_desc,_value,_class,_wepy=require("./../npm/wepy/lib/wepy.js"),_wepy2=_interopRequireDefault(_wepy),_decorator=require("./../common/decorator.js"),_api=require("./../common/api.js"),_api2=_interopRequireDefault(_api),upValueList=(_dec=(0,_decorator.trycatch)(),_class=function(e){function t(){var e,r,n,i;_classCallCheck(this,t);for(var o=arguments.length,a=Array(o),u=0;u<o;u++)a[u]=arguments[u];return r=n=_possibleConstructorReturn(this,(e=t.__proto__||Object.getPrototypeOf(t)).call.apply(e,[this].concat(a))),n.config={navigationBarTitleText:"收支明细"},n.config={},n.data={upValueList:[],noData:!1},n.methods={},i=r,_possibleConstructorReturn(n,i)}return _inherits(t,e),_createClass(t,[{key:"onLoad",value:function(){function e(e){return t.apply(this,arguments)}var t=_asyncToGenerator(regeneratorRuntime.mark(function e(t){return regeneratorRuntime.wrap(function(e){for(;;)switch(e.prev=e.next){case 0:return e.next=2,this.getMyUpValue();case 2:case"end":return e.stop()}},e,this)}));return e}()},{key:"getMyUpValue",value:function(){function e(){return t.apply(this,arguments)}var t=_asyncToGenerator(regeneratorRuntime.mark(function e(){return regeneratorRuntime.wrap(function(e){for(;;)switch(e.prev=e.next){case 0:return e.next=2,_api2.default.getMyUpValue();case 2:this.upValueList=e.sent,0===this.upValueList.length&&(this.noData=!0),this.$apply();case 5:case"end":return e.stop()}},e,this)}));return e}()}]),t}(_wepy2.default.page),_applyDecoratedDescriptor(_class.prototype,"getMyUpValue",[_dec],Object.getOwnPropertyDescriptor(_class.prototype,"getMyUpValue"),_class.prototype),_class);Page(require("./../npm/wepy/lib/wepy.js").default.$createPage(upValueList,"pages/upValueList")); 
 			}); 	require("pages/upValueList.js");
 		__wxRoute = 'pages/studyData';__wxRouteBegin = true; 	__wxAppCurrentFile__ = 'pages/studyData.js';	define("pages/studyData.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			
"use strict";function _interopRequireDefault(e){return e&&e.__esModule?e:{default:e}}function _asyncToGenerator(e){return function(){var t=e.apply(this,arguments);return new Promise(function(e,a){function n(r,o){try{var i=t[r](o),s=i.value}catch(e){return void a(e)}if(!i.done)return Promise.resolve(s).then(function(e){n("next",e)},function(e){n("throw",e)});e(s)}return n("next")})}}function _classCallCheck(e,t){if(!(e instanceof t))throw new TypeError("Cannot call a class as a function")}function _possibleConstructorReturn(e,t){if(!e)throw new ReferenceError("this hasn't been initialised - super() hasn't been called");return!t||"object"!=typeof t&&"function"!=typeof t?e:t}function _inherits(e,t){if("function"!=typeof t&&null!==t)throw new TypeError("Super expression must either be null or a function, not "+typeof t);e.prototype=Object.create(t&&t.prototype,{constructor:{value:e,enumerable:!1,writable:!0,configurable:!0}}),t&&(Object.setPrototypeOf?Object.setPrototypeOf(e,t):e.__proto__=t)}function _applyDecoratedDescriptor(e,t,a,n,r){var o={};return Object.keys(n).forEach(function(e){o[e]=n[e]}),o.enumerable=!!o.enumerable,o.configurable=!!o.configurable,("value"in o||o.initializer)&&(o.writable=!0),o=a.slice().reverse().reduce(function(a,n){return n(e,t,a)||a},o),r&&void 0!==o.initializer&&(o.value=o.initializer?o.initializer.call(r):void 0,o.initializer=void 0),void 0===o.initializer&&(Object.defineProperty(e,t,o),o=null),o}Object.defineProperty(exports,"__esModule",{value:!0});var _createClass=function(){function e(e,t){for(var a=0;a<t.length;a++){var n=t[a];n.enumerable=n.enumerable||!1,n.configurable=!0,"value"in n&&(n.writable=!0),Object.defineProperty(e,n.key,n)}}return function(t,a,n){return a&&e(t.prototype,a),n&&e(t,n),t}}(),_dec,_desc,_value,_class,_wepy=require("./../npm/wepy/lib/wepy.js"),_wepy2=_interopRequireDefault(_wepy),_decorator=require("./../common/decorator.js"),_api=require("./../common/api.js"),_api2=_interopRequireDefault(_api),_eChart=require("./../common/e-chart.js"),_eChart2=_interopRequireDefault(_eChart),studyData=(_dec=(0,_decorator.trycatch)(),_class=function(e){function t(){var e,a,n,r;_classCallCheck(this,t);for(var o=arguments.length,i=Array(o),s=0;s<o;s++)i[s]=arguments[s];return a=n=_possibleConstructorReturn(this,(e=t.__proto__||Object.getPrototypeOf(t)).call.apply(e,[this].concat(i))),n.config={navigationBarTitleText:"",navigationBarBackgroundColor:"#7B99FF",navigationBarTextStyle:"white"},n.config={},n.data={subjectIndex:0,subjectData:[],pointData:[],beyondRate:0,heads:[],couresData:[],noData:!1},n.methods={selectCourse:function(e){wx.reportAnalytics("studydata_20_click_subject",{id:e}),this.subjectIndex=parseInt(e),this.couresData[this.subjectIndex]?this.noData=!1:this.noData=!0},toggleLesson:function(e,t){var a=this.couresData[this.subjectIndex].chapters,n=a[t].sections;n[e].toggle=!n[e].toggle,this.couresData[this.subjectIndex].chapters[t].sections[e].toggle=n[e].toggle,this.$apply()},gotoRanking:function(e){var t={rankType:e};this.$navigate("ranking",t)}},n.computed={},r=a,_possibleConstructorReturn(n,r)}return _inherits(t,e),_createClass(t,[{key:"onLoad",value:function(e){this.getData()}},{key:"getData",value:function(){function e(){return t.apply(this,arguments)}var t=_asyncToGenerator(regeneratorRuntime.mark(function e(){var t,a=this;return regeneratorRuntime.wrap(function(e){for(;;)switch(e.prev=e.next){case 0:return e.next=2,_api2.default.userLearnData();case 2:t=e.sent,this.beyondRate=t.beyondRate,this.heads=t.heads,t.subjectList&&t.subjectList.forEach(function(e){a.subjectData.push(e.name),a.pointData.push(parseInt(e.rightRate))}),t.content&&t.content.forEach(function(e){a.couresData[e.subjectId-1]=e}),this.couresData&&this.couresData.forEach(function(e){e.chapters&&e.chapters.forEach(function(e){e.sections.forEach(function(e){e.toggle=!1})})}),this.couresData[this.subjectIndex]?this.noData=!1:this.noData=!0,this.$apply(),this.setChart();case 11:case"end":return e.stop()}},e,this)}));return e}()},{key:"setChart",value:function(){console.log(wx.getSystemInfoSync().windowWidth);var e=wx.getSystemInfoSync().windowWidth*(670/750),t=wx.getSystemInfoSync().windowWidth*(325/750),a={main:{data:this.pointData,categories:this.subjectData}};new _eChart2.default({canvasId:"columnCanvas",type:"column",categories:a.main.categories,series:[{name:"成交量",data:a.main.data,format:function(e,t){return e+"%"},color:"#6787FF"}],yAxis:{format:function(e){return e+"%"},min:0,max:100,disabled:!0},xAxis:{disableGrid:!1,type:"calibration"},extra:{column:{width:30}},width:e,height:t,legend:!1})}}]),t}(_wepy2.default.page),_applyDecoratedDescriptor(_class.prototype,"getData",[_dec],Object.getOwnPropertyDescriptor(_class.prototype,"getData"),_class.prototype),_class);Page(require("./../npm/wepy/lib/wepy.js").default.$createPage(studyData,"pages/studyData")); 
 			}); 	require("pages/studyData.js");
 		__wxRoute = 'pages/wrongTopic';__wxRouteBegin = true; 	__wxAppCurrentFile__ = 'pages/wrongTopic.js';	define("pages/wrongTopic.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			
"use strict";function _interopRequireDefault(t){return t&&t.__esModule?t:{default:t}}function _asyncToGenerator(t){return function(){var e=t.apply(this,arguments);return new Promise(function(t,i){function n(r,o){try{var s=e[r](o),a=s.value}catch(t){return void i(t)}if(!s.done)return Promise.resolve(a).then(function(t){n("next",t)},function(t){n("throw",t)});t(a)}return n("next")})}}function _classCallCheck(t,e){if(!(t instanceof e))throw new TypeError("Cannot call a class as a function")}function _possibleConstructorReturn(t,e){if(!t)throw new ReferenceError("this hasn't been initialised - super() hasn't been called");return!e||"object"!=typeof e&&"function"!=typeof e?t:e}function _inherits(t,e){if("function"!=typeof e&&null!==e)throw new TypeError("Super expression must either be null or a function, not "+typeof e);t.prototype=Object.create(e&&e.prototype,{constructor:{value:t,enumerable:!1,writable:!0,configurable:!0}}),e&&(Object.setPrototypeOf?Object.setPrototypeOf(t,e):t.__proto__=e)}function _applyDecoratedDescriptor(t,e,i,n,r){var o={};return Object.keys(n).forEach(function(t){o[t]=n[t]}),o.enumerable=!!o.enumerable,o.configurable=!!o.configurable,("value"in o||o.initializer)&&(o.writable=!0),o=i.slice().reverse().reduce(function(i,n){return n(t,e,i)||i},o),r&&void 0!==o.initializer&&(o.value=o.initializer?o.initializer.call(r):void 0,o.initializer=void 0),void 0===o.initializer&&(Object.defineProperty(t,e,o),o=null),o}Object.defineProperty(exports,"__esModule",{value:!0});var _createClass=function(){function t(t,e){for(var i=0;i<e.length;i++){var n=e[i];n.enumerable=n.enumerable||!1,n.configurable=!0,"value"in n&&(n.writable=!0),Object.defineProperty(t,n.key,n)}}return function(e,i,n){return i&&t(e.prototype,i),n&&t(e,n),e}}(),_dec,_desc,_value,_class,_wepy=require("./../npm/wepy/lib/wepy.js"),_wepy2=_interopRequireDefault(_wepy),_api=require("./../common/api.js"),_api2=_interopRequireDefault(_api),_common=require("./../common/common.js"),_common2=_interopRequireDefault(_common),_storage=require("./../common/storage.js"),_storage2=_interopRequireDefault(_storage),_decorator=require("./../common/decorator.js"),_KcLoading=require("./../components/KcLoading.js"),_KcLoading2=_interopRequireDefault(_KcLoading),_KcErrorModal=require("./../components/KcErrorModal.js"),_KcErrorModal2=_interopRequireDefault(_KcErrorModal),wrongTopic=(_dec=(0,_decorator.trycatch)(),_class=function(t){function e(){var t,i,n,r;_classCallCheck(this,e);for(var o=arguments.length,s=Array(o),a=0;a<o;a++)s[a]=arguments[a];return i=n=_possibleConstructorReturn(this,(t=e.__proto__||Object.getPrototypeOf(e)).call.apply(t,[this].concat(s))),n.config={navigationBarTitleText:"正在复习错过的题",navigationBarTextStyle:"black",navigationBarBackgroundColor:"#F9FAFC"},n.data={loadingHide:!0,tipsShow:!1,index:0,btn:"下一题",sid:"",days:[],type:"",topicNum:"",status:0,handTipShowTime:0,onlyFalse:!1,handTips:!0,optionStatus:[0,0,0,0],currentAnswerStatus:0,hasPointDetail:0,topicList:[],answerList:[],endAlertShow:!1,accuracyRate:0,changeValue:0,eggShow:!1,markTips:!1,longtips:!1,needMarkTips:!0,needLongTips:!0,maskShow:!1,submitStatus:0,wrongTopic:[]},n.$repeat={},n.$props={KcLoading:{"xmlns:v-bind":"","v-bind:loadingHide.sync":"loadingHide"}},n.$events={},n.components={KcLoading:_KcLoading2.default,KcErrorModal:_KcErrorModal2.default},n.mixins=[],n.computed={percent:function(){return parseInt((this.index+1)/this.topicNum*100)},nowTopic:function(){return this.topicList[this.index]},canClick:function(){if(1===this.status){for(var t=0,e=0,i=this.optionStatus.length;e<i;e++)0!==this.optionStatus[e]&&t++;return 0!==t&&(1!==t||!this.nowTopic.isCheckbox)}return!0},yourAnswer:function(){for(var t="",e=this.optionStatus,i=0;i<4;i++)if(1===e[i]||2===e[i]||3===e[i])switch(i){case 0:t+="A";break;case 1:t+="B";break;case 2:t+="C";break;case 3:t+="D"}return t},rightAnswer:function(){var t="";if(this.nowTopic)for(var e=this.nowTopic.rightOption,i=0;i<e.length;i++)switch(e[i]-1){case 0:t+="A";break;case 1:t+="B";break;case 2:t+="C";break;case 3:t+="D"}return t}},n.methods={hideMask:function(){this.maskShow=!1,this.longtips=!1,this.markTips=!1},formSubmit:function(t){var e=t.detail.formId;_common2.default.collectFormID(e)},markCancel:function(){this.markTips=!1,this.maskShow=!1,this.$apply()},longCancel:function(){this.longtips=!1,this.maskShow=!1,this.$apply()},goReport:function(){wx.redirectTo({url:"report?sid="+this.sid+"&days="+JSON.stringify(this.days)+"&type="+this.type+"&onlyFalse="+this.onlyFalse})},removeWrong:function(){this.answerList[this.index]=3},unremoveWrong:function(){this.answerList[this.index]=this.currentAnswerStatus},mark:function(){1===this.type&&wx.reportAnalytics("study_20_click_mark",{}),this.needMarkTips&&(this.markTips=!0,this.maskShow=!0,_storage2.default.set("needMarkTips",!1),this.needMarkTips=!1),this.answerList[this.index]=2},unmark:function(){this.answerList[this.index]=1},mainTap:function(){function t(){return e.apply(this,arguments)}var e=_asyncToGenerator(regeneratorRuntime.mark(function t(){return regeneratorRuntime.wrap(function(t){for(;;)switch(t.prev=t.next){case 0:this.index===this.topicList.length-1&&wx.redirectTo({url:"report?sid="+this.sid+"&days="+JSON.stringify(this.days)+"&type="+this.type+"&onlyFalse="+this.onlyFalse}),this.index++,this.optionStatus=this.wrongTopic[this.index].optionStatus,this.index===this.topicList.length-1?this.btn="回报告页":this.btn="下一题";case 4:case"end":return t.stop()}},t,this)}));return t}(),tapOption:function(t){1===this.status&&(this.nowTopic.isCheckbox?1===this.optionStatus[t]?this.optionStatus[t]=0:this.optionStatus[t]=1:(this.optionStatus=[0,0,0,0],this.optionStatus[t]=1))},touchEnd:function(t){this.status=1,this.handTips=!1,this.handTipShowTime<10&&this.handTipShowTime++,_storage2.default.set("handTipShowTime",this.handTipShowTime)},longpress:function(){this.eggShow=!0,this.needLongTips&&(this.maskShow=!0,this.longtips=!0,_storage2.default.set("needLongTips",!1),this.needLongTips=!1),wx.reportAnalytics("study_19_longpress",{})}},r=i,_possibleConstructorReturn(n,r)}return _inherits(e,t),_createClass(e,[{key:"checkAnswer",value:function(){for(var t=1,e=0;e<4;e++){var i=this.nowTopic.rightOption.indexOf(e+1)>=0;1===this.optionStatus[e]?i?this.optionStatus[e]=3:(this.optionStatus[e]=2,t=0):i&&(this.nowTopic.isCheckbox?this.optionStatus[e]=4:this.optionStatus[e]=5,t=0)}this.currentAnswerStatus=t,this.answerList[this.index]=t}},{key:"onLoad",value:function(){function t(t){return e.apply(this,arguments)}var e=_asyncToGenerator(regeneratorRuntime.mark(function t(e){return regeneratorRuntime.wrap(function(t){for(;;)switch(t.prev=t.next){case 0:return this.status=2,this.sid=Number(e.sid),this.days=e.days?JSON.parse(e.days):[],this.type=Number(e.type),this.onlyFalse=JSON.parse(e.onlyFalse),t.next=7,this.getStudyData();case 7:this.$apply();case 8:case"end":return t.stop()}},t,this)}));return t}()},{key:"getStudyData",value:function(){function t(){return e.apply(this,arguments)}var e=_asyncToGenerator(regeneratorRuntime.mark(function t(){var e,i=this;return regeneratorRuntime.wrap(function(t){for(;;)switch(t.prev=t.next){case 0:return this.loadingHide=!1,this.$apply(),t.next=4,_api2.default.getDayInfo({subjectId:this.sid,stage:this.days.join(","),type:this.type,onlyFalse:this.onlyFalse});case 4:return e=t.sent,t.next=7,_storage2.default.get("wrongTopic");case 7:this.wrongTopic=t.sent,this.wrongTopic.forEach(function(t){i.topicList.push(e.questions[t.index])}),this.topicNum=this.wrongTopic.length,this.optionStatus=this.wrongTopic[0].optionStatus,this.hasPointDetail=e.hasPointDetail,this.loadingHide=!0,this.$apply();case 14:case"end":return t.stop()}},t,this)}));return t}()},{key:"handleError",value:function(){function t(t,i){return e.apply(this,arguments)}var e=_asyncToGenerator(regeneratorRuntime.mark(function t(e,i){var n=this;return regeneratorRuntime.wrap(function(t){for(;;)switch(t.prev=t.next){case 0:this.loadingHide=!0,this.$apply(),this.$invoke("KcErrorModal","showModal",{err:e,btnMsg:"重新加载",cb:function(){n.getStudyData()}});case 3:case"end":return t.stop()}},t,this)}));return t}()}]),e}(_wepy2.default.page),_applyDecoratedDescriptor(_class.prototype,"getStudyData",[_dec],Object.getOwnPropertyDescriptor(_class.prototype,"getStudyData"),_class.prototype),_class);Page(require("./../npm/wepy/lib/wepy.js").default.$createPage(wrongTopic,"pages/wrongTopic")); 
 			}); 	require("pages/wrongTopic.js");
 		__wxRoute = 'pages/share';__wxRouteBegin = true; 	__wxAppCurrentFile__ = 'pages/share.js';	define("pages/share.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			
"use strict";function _interopRequireDefault(e){return e&&e.__esModule?e:{default:e}}function _asyncToGenerator(e){return function(){var t=e.apply(this,arguments);return new Promise(function(e,r){function n(o,a){try{var i=t[o](a),s=i.value}catch(e){return void r(e)}if(!i.done)return Promise.resolve(s).then(function(e){n("next",e)},function(e){n("throw",e)});e(s)}return n("next")})}}function _classCallCheck(e,t){if(!(e instanceof t))throw new TypeError("Cannot call a class as a function")}function _possibleConstructorReturn(e,t){if(!e)throw new ReferenceError("this hasn't been initialised - super() hasn't been called");return!t||"object"!=typeof t&&"function"!=typeof t?e:t}function _inherits(e,t){if("function"!=typeof t&&null!==t)throw new TypeError("Super expression must either be null or a function, not "+typeof t);e.prototype=Object.create(t&&t.prototype,{constructor:{value:e,enumerable:!1,writable:!0,configurable:!0}}),t&&(Object.setPrototypeOf?Object.setPrototypeOf(e,t):e.__proto__=t)}Object.defineProperty(exports,"__esModule",{value:!0});var _createClass=function(){function e(e,t){for(var r=0;r<t.length;r++){var n=t[r];n.enumerable=n.enumerable||!1,n.configurable=!0,"value"in n&&(n.writable=!0),Object.defineProperty(e,n.key,n)}}return function(t,r,n){return r&&e(t.prototype,r),n&&e(t,n),t}}(),_wepy=require("./../npm/wepy/lib/wepy.js"),_wepy2=_interopRequireDefault(_wepy),_api=require("./../common/api.js"),_api2=_interopRequireDefault(_api),_kcLog=require("./../npm/@kc-base/kc-log/dist/kc-log.js"),_kcLog2=_interopRequireDefault(_kcLog),_storage=require("./../common/storage.js"),_storage2=_interopRequireDefault(_storage),_common=require("./../common/common.js"),_common2=_interopRequireDefault(_common),Share=function(e){function t(){var e,r,n,o;_classCallCheck(this,t);for(var a=arguments.length,i=Array(a),s=0;s<a;s++)i[s]=arguments[s];return r=n=_possibleConstructorReturn(this,(e=t.__proto__||Object.getPrototypeOf(t)).call.apply(e,[this].concat(i))),n.config={navigationBarTitleText:"活动详情"},n.data={num:0,done:3,shareNum:0,successShow:!1,maskShow:!1,errorShow:!1,isFirstShare:!0},n.methods={goBack:function(){_kcLog2.default.send({pagename:"sharePage",name:"backBtnClick",category:"webClick",pt:"mini"}),wx.reLaunch({url:"index"})}},o=r,_possibleConstructorReturn(n,o)}return _inherits(t,e),_createClass(t,[{key:"onLoad",value:function(){function e(e){return t.apply(this,arguments)}var t=_asyncToGenerator(regeneratorRuntime.mark(function e(t){var r;return regeneratorRuntime.wrap(function(e){for(;;)switch(e.prev=e.next){case 0:return e.next=2,_storage2.default.get("isFirstShare");case 2:return this.isFirstShare=e.sent,void 0===this.isFirstShare&&(this.isFirstShare=!0),e.next=6,_api2.default.shareHelp();case 6:r=e.sent,this.num=r.num,this.done=r.done,this.$apply();case 10:case"end":return e.stop()}},e,this)}));return e}()},{key:"onShareAppMessage",value:function(){var e=this;return this.shareNum++,_kcLog2.default.send({pagename:"sharePage",name:"shareBtnClick",category:"webClick",pt:"mini",count:this.shareNum}),this.isFirstShare&&(setTimeout(function(){wx.showToast({title:"请发送至同学群哦~",icon:"none",duration:3e3})},2e3),this.isFirstShare=!1,_storage2.default.set("isFirstShare",!1)),setTimeout(function(){e.postShareHelp()},2e3),_common2.default.shareTxt()}},{key:"postShareHelp",value:function(){function e(){return t.apply(this,arguments)}var t=_asyncToGenerator(regeneratorRuntime.mark(function e(){var t;return regeneratorRuntime.wrap(function(e){for(;;)switch(e.prev=e.next){case 0:return e.prev=0,e.next=3,_api2.default.postShareHelp();case 3:t=e.sent,this.num=t.num,this.done=t.done,this.done>0&&t.num!==t.done&&wx.showToast({title:"发送成功",icon:"success",duration:3e3}),t.num===t.done&&(this.successShow=!0,this.maskShow=!0),this.$apply(),e.next=16;break;case 11:e.prev=11,e.t0=e.catch(0),console.log(e.t0),this.errorShow=!0,this.maskShow=!0;case 16:case"end":return e.stop()}},e,this,[[0,11]])}));return e}()},{key:"close",value:function(){this.errorShow=!1,this.maskShow=!1}}]),t}(_wepy2.default.page);Page(require("./../npm/wepy/lib/wepy.js").default.$createPage(Share,"pages/share")); 
 			}); 	require("pages/share.js");
 	