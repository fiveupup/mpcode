Component({
    data: {
        selected: 0,
        color: "#999999",
        selectedColor: "#f5d220",
        list: [ {
            pagePath: "/pages/newIndex/main",
            iconPath: "//static.yanzhishi.cn/images/wechat/lianxi-hui@2x.png",
            selectedIconPath: "//static.yanzhishi.cn/images/wechat/lianxi@2x.png",
            text: "刷题"
        }, {
            pagePath: "/pages/official/main",
            iconPath: "//static.yanzhishi.cn/images/wechat/official_icon.jpg",
            selectedIconPath: "//static.yanzhishi.cn/images/wechat/official_icon.jpg",
            text: "院校真题"
        }, {
            pagePath: "/pages/my/main",
            iconPath: "//static.yanzhishi.cn/images/wechat/wode-hui.png",
            selectedIconPath: "//static.yanzhishi.cn/images/wechat/wode@2x.png",
            text: "我的"
        } ],
        useSel: !1,
        userNotLogin: !1,
        isDark: wx.getStorageSync("isDark")
    },
    attached: function() {
        this.setData({
            isDark: wx.getStorageSync("isDark")
        });
    },
    methods: {
        viewChange: function(a) {
            a ? this.setData({
                color: "#CECECE",
                isDark: a
            }) : this.setData({
                color: "#999999",
                isDark: a
            });
        },
        switchTabUrl: function(a) {
            var t = a.currentTarget.dataset.path, e = this;
            "/pages/camera/main" === t ? wx.getSetting({
                success: function(a) {
                    wx.authorize({
                        scope: "scope.camera",
                        success: function(a) {
                            e.useSel = !0, wx.navigateTo({
                                url: "/pages/camera/main"
                            });
                        },
                        fail: function() {
                            e.useSel = !0;
                        }
                    });
                },
                complete: function(a) {
                    a.authSetting["scope.camera"] || e.useSel && wx.openSetting();
                }
            }) : wx.switchTab({
                url: t
            });
        }
    }
});