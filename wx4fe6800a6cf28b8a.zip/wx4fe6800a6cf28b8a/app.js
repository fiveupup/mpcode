require("@babel/runtime/helpers/Arrayincludes"), require("./common/manifest.js"), 
require("./common/vendor.js"), global.webpackJsonpMpvue([ 48 ], {
    M93x: function(e, n, o) {
        var t = o("Mw+1"), a = o("ybqe")(t.a, null, function(e) {
            o("s1pp");
        }, null, null);
        n.a = a.exports;
    },
    "Mw+1": function(e, n, o) {
        var t = o("mvHQ"), a = o.n(t), r = (o("VsUZ"), o("8e4C")), s = requirePlugin("live-player-plugin");
        n.a = {
            created: function() {
                var e = void 0;
                "my" === global.mpvuePlatform ? ((e = global.mpvue.getStorageSync({
                    key: "logs"
                }).data || []).unshift(Date.now()), global.mpvue.setStorageSync({
                    key: "logs",
                    data: e
                })) : ((e = global.mpvue.getStorageSync("logs") || []).unshift(Date.now()), global.mpvue.setStorageSync("logs", e)), 
                wx.getSystemInfo({
                    success: function(e) {
                        var n = e.brand + "  -  " + e.model + "  -  " + e.system;
                        console.log(n), e.model.indexOf("iPad") > -1 || e.system.indexOf("Windows") > -1 ? wx.setStorageSync("isNotPhone", !0) : wx.setStorageSync("isNotPhone", !1), 
                        wx.setStorageSync("equi", n);
                    },
                    fail: function(e) {
                        console.log(e);
                    }
                }), wx.getBackgroundFetchData({
                    fetchType: "pre",
                    success: function(e) {
                        try {
                            var n = JSON.parse(e.fetchedData).data, o = n.bannerList, t = n.infoList, a = n.majorCustomList, s = o.sort(function(e, n) {
                                return e.bannerSort - n.bannerSort;
                            }).filter(function(e) {
                                return 0 !== e.bannerType;
                            }), u = o.find(function(e) {
                                return 8 === e.bannerType;
                            });
                            u && (s = [ u ]), wx.setStorageSync("bannerList", s), console.log(t);
                            var l = {
                                addImitateNum: 0,
                                addFastNum: 0
                            }, c = t.map(function(e, n) {
                                return 2 != n && 3 != n || (l.addImitateNum += parseInt(e.completePeopleNumber)), 
                                l.addFastNum += parseInt(e.completePeopleNumber), e.completePeopleNumber = parseInt(e.completePeopleNumber), 
                                e;
                            }).sort(function(e, n) {
                                return e.sort - n.sort;
                            });
                            wx.setStorageSync("infoList", c);
                            var i = 0 === a.length ? r.j : a.map(function(e) {
                                return {
                                    id: e.majorId,
                                    name: e.majorName,
                                    examCategory: e.examCategory
                                };
                            });
                            console.log("preMajor", i), wx.setStorageSync("majorCustomList", i);
                        } catch (e) {
                            console.log(e);
                        }
                    }
                });
            },
            onShow: function(e) {
                if (console.log(e, 1e5), e && [ 1007, 1008 ].includes(e.scene) && (e.path.indexOf("live-player-plugin") > -1 && s.getShareParams().then(function(e) {
                    console.log(e);
                    var n = e.custom_params.userId;
                    n && wx.setStorageSync("userId", n);
                }), "{}" !== a()(e.query) && e.path.indexOf("newIndex") > -1 && e.query.params)) {
                    var n = JSON.parse(e.query.params).userId;
                    n && wx.setStorageSync("userId", n);
                }
            },
            log: function() {
                console.log("log at:" + Date.now());
            }
        };
    },
    NHnr: function(e, n, o) {
        Object.defineProperty(n, "__esModule", {
            value: !0
        });
        var t = o("5nAL"), a = o.n(t), r = o("M93x"), s = o("qe9T");
        o.n(s), a.a.config.productionTip = !1, r.a.mpType = "app", new a.a(r.a).$mount();
    },
    qe9T: function(e, n) {},
    s1pp: function(e, n) {}
}, [ "NHnr" ]);