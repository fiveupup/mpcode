require("../../@babel/runtime/helpers/Arrayincludes"), require("../../common/manifest.js"), 
require("../../common/vendor.js"), global.webpackJsonpMpvue([ 5 ], {
    "49Ra": function(e, t, i) {
        t.a = {
            render: function() {
                var e = this, t = e.$createElement, i = e._self._c || t;
                return i("div", {
                    staticClass: "i-cell",
                    class: e.classObj,
                    attrs: {
                        eventid: "1"
                    },
                    on: {
                        click: e.handleTap
                    }
                }, [ i("div", {
                    staticClass: "i-cell-icon"
                }, [ e._t("icon", null, {
                    mpcomid: "0"
                }) ], 2), e._v(" "), i("div", {
                    staticClass: "i-cell-bd"
                }, [ e.title ? i("p", {
                    staticClass: "i-cell-text"
                }, [ e._v(e._s(e.title)) ]) : e._e(), e._v(" "), e.label ? i("p", {
                    staticClass: "i-cell-desc"
                }, [ e._v(e._s(e.label)) ]) : e._e(), e._v(" "), e._t("default", null, {
                    mpcomid: "1"
                }) ], 2), e._v(" "), i("div", {
                    staticClass: "i-cell-ft",
                    attrs: {
                        eventid: "0"
                    },
                    on: {
                        "!click": function(t) {
                            e.navigateTo(t);
                        }
                    }
                }, [ e.value ? i("div", [ e._v(e._s(e.value)) ]) : i("div", [ e._t("footer", null, {
                    mpcomid: "2"
                }) ], 2) ]) ]);
            },
            staticRenderFns: []
        };
    },
    "7Uy6": function(e, t, i) {
        t.a = {
            render: function() {
                var e = this, t = e.$createElement, i = e._self._c || t;
                return i("div", {
                    class: [ "feedback", e.isDark && "dark" ]
                }, [ i("h2", [ e._v("*错误类型（可多选）") ]), e._v(" "), i("i-panel", {
                    attrs: {
                        title: "group-水果",
                        mpcomid: "1"
                    }
                }, [ i("i-checkbox-group", {
                    attrs: {
                        groups: e.errorList,
                        current: e.current,
                        position: e.position,
                        eventid: "0",
                        mpcomid: "0"
                    },
                    on: {
                        change: e.handleFruitChange
                    }
                }) ], 1), e._v(" "), i("h2", {
                    staticClass: "mt"
                }, [ e._v("*本题错误详情或建议") ]), e._v(" "), i("textarea", {
                    directives: [ {
                        name: "model",
                        rawName: "v-model.lazy",
                        value: e.errorDetail,
                        expression: "errorDetail",
                        modifiers: {
                            lazy: !0
                        }
                    } ],
                    staticClass: "detail",
                    attrs: {
                        cols: "30",
                        rows: "10",
                        placeholder: "输入详细纠错内容",
                        eventid: "1"
                    },
                    domProps: {
                        value: e.errorDetail
                    },
                    on: {
                        change: function(t) {
                            e.errorDetail = t.target.value;
                        }
                    }
                }), e._v(" "), i("h2", {
                    staticClass: "mt"
                }, [ e._v("图片（选填，提供图片截图）") ]), e._v(" "), i("div", {
                    staticClass: "add"
                }, [ i("div", {
                    staticClass: "answer-img"
                }, [ e._l(e.answerImg, function(t, a) {
                    return i("div", {
                        key: a,
                        staticClass: "img-item"
                    }, [ i("span", {
                        staticClass: "close",
                        attrs: {
                            eventid: "2_" + a
                        },
                        on: {
                            click: function(t) {
                                e.deleteImg(a);
                            }
                        }
                    }, [ i("i-icon", {
                        attrs: {
                            type: "delete",
                            size: "22",
                            color: "#AFAFAF",
                            mpcomid: "2_" + a
                        }
                    }) ], 1), e._v(" "), i("img", {
                        attrs: {
                            src: t,
                            alt: "反馈图片",
                            eventid: "3_" + a
                        },
                        on: {
                            click: function(i) {
                                e.preview(t);
                            }
                        }
                    }) ]);
                }), e._v(" "), e.answerImg.length < 4 ? i("div", {
                    staticClass: "add-plus",
                    attrs: {
                        eventid: "4"
                    },
                    on: {
                        click: e.uploadImg
                    }
                }, [ i("i-icon", {
                    attrs: {
                        type: "add",
                        size: "40",
                        color: "#c1c1c1",
                        mpcomid: "3"
                    }
                }) ], 1) : e._e() ], 2) ]), e._v(" "), i("fixed-bottom", {
                    attrs: {
                        text: "提交",
                        clickBtn: e.submitFeedback,
                        mpcomid: "4"
                    }
                }) ], 1);
            },
            staticRenderFns: []
        };
    },
    "9GSd": function(e, t, i) {
        var a = i("h9D8"), n = i("49Ra"), s = i("ybqe")(a.a, n.a, function(e) {
            i("LFWd");
        }, null, null);
        t.a = s.exports;
    },
    AyAg: function(e, t, i) {
        var a = i("VmT9"), n = i("7Uy6"), s = i("ybqe")(a.a, n.a, function(e) {
            i("MyMt");
        }, null, null);
        t.a = s.exports;
    },
    CiOW: function(e, t) {},
    JVu0: function(e, t, i) {
        var a = i("dvC+"), n = i("UNHV"), s = i("ybqe")(a.a, n.a, function(e) {
            i("aqd3");
        }, null, null);
        t.a = s.exports;
    },
    LFWd: function(e, t) {},
    MyMt: function(e, t) {},
    UNHV: function(e, t, i) {
        t.a = {
            render: function() {
                var e = this, t = e.$createElement, i = e._self._c || t;
                return i("div", [ i("checkbox-group", {
                    staticClass: "i-cell-group",
                    attrs: {
                        "i-class": e.iClass,
                        eventid: "0",
                        mpcomid: "0"
                    },
                    on: {
                        change: e.checkboxChange
                    }
                }, e._l(e.lists, function(t, a) {
                    return i("label", {
                        key: a,
                        staticClass: "i-checkbox i-cell i-checkbox-cell"
                    }, [ i("checkbox", {
                        staticClass: "i-checkbox-checkbox",
                        class: [ e.positionCls, e.iItemClass ],
                        attrs: {
                            value: t.value,
                            checked: t.checked,
                            color: e.color,
                            disabled: t.disabled
                        }
                    }), e._v(" "), i("div", {
                        staticClass: "i-checkbox-title"
                    }, [ e._v(e._s(t.value)) ]) ], 1);
                })) ], 1);
            },
            staticRenderFns: []
        };
    },
    VmT9: function(e, t, i) {
        var a = i("VsUZ"), n = i("JVu0"), s = i("b1mz"), c = i("emV0"), o = i("oFuF"), r = i("IcnI");
        t.a = {
            components: {
                "i-checkbox-group": n.a,
                "i-icon": s.a,
                FixedBottom: c.a
            },
            computed: {
                exerciseId: function() {
                    return r.a.state.feedback.feedbackExerciseId;
                },
                majorId: function() {
                    return r.a.state.feedback.feedbackMajorId;
                }
            },
            data: function() {
                return {
                    errorList: [ {
                        id: 1,
                        value: "题干错误"
                    }, {
                        id: 2,
                        value: "答案错误"
                    }, {
                        id: 3,
                        value: "解析错误"
                    }, {
                        id: 4,
                        value: "其他"
                    } ],
                    current: [],
                    position: "left",
                    errorDetail: "",
                    answerImg: [],
                    errorType: "",
                    isDark: wx.getStorageSync("isDark")
                };
            },
            onLoad: function() {
                this.current = [], this.errorDetail = "", this.answerImg = [], this.isDark = Object(o.onChangeDark)();
            },
            methods: {
                handleFruitChange: function(e) {
                    var t = this, i = this.errorList;
                    this.current = e.value, this.errorType = [], i.forEach(function(i) {
                        -1 !== e.value.indexOf(i.value) && t.errorType.push(i.id);
                    });
                },
                submitFeedback: function() {
                    var e = this.errorType, t = this.majorId, i = this.exerciseId, n = this.errorDetail, s = this.answerImg;
                    0 !== e.length ? "" !== n ? a.default.addFeedBack({
                        exerciseId: i,
                        majorId: t,
                        pictureAdd: s.join(","),
                        errorDetail: n,
                        errorType: e.join(",")
                    }, function(e) {
                        e.data && (setTimeout(function() {
                            wx.showToast({
                                title: "感谢反馈，我们会加紧校验修改~",
                                icon: "none"
                            });
                        }, 400), wx.navigateBack({
                            delta: 1
                        }));
                    }) : wx.showToast({
                        title: "请输入详细纠错内容",
                        icon: "none"
                    }) : wx.showToast({
                        title: "请至少选择一种类型",
                        icon: "none"
                    });
                },
                uploadImg: function() {
                    var e = this;
                    wx.chooseImage({
                        count: 4 - this.answerImg.length,
                        sourceType: [ "camera", "album" ],
                        success: function(t) {
                            t.tempFilePaths.forEach(function(t) {
                                e.sendImg(t);
                            });
                        }
                    });
                },
                sendImg: function(e) {
                    var t = this;
                    a.default.upAnswer({
                        filePath: e
                    }, function(e) {
                        if (401 !== e.statusCode) {
                            var i = JSON.parse(e.data);
                            t.answerImg.push(i.data.previewUrl);
                        } else Object(o.repeatLogin)(function() {
                            t.sendImg();
                        });
                    });
                },
                deleteImg: function(e) {
                    this.answerImg.splice(e, 1);
                },
                preview: function(e) {
                    wx.previewImage({
                        current: e,
                        urls: this.answerImg
                    });
                }
            }
        };
    },
    aqd3: function(e, t) {},
    djS1: function(e, t, i) {
        t.a = {
            props: {
                iClass: {
                    type: String,
                    default: ""
                }
            }
        };
    },
    "dvC+": function(e, t, i) {
        var a, n = i("bOdI"), s = i.n(n), c = i("f6jk"), o = i("9GSd");
        t.a = {
            components: {
                "i-cell-group": c.a,
                "i-cell": o.a
            },
            props: (a = {
                iClass: {
                    type: String,
                    default: ""
                },
                groups: {
                    type: Array,
                    default: []
                },
                current: {
                    type: Array,
                    default: []
                },
                position: {
                    type: String,
                    default: "left"
                },
                color: {
                    type: String,
                    default: "#2d8cf0"
                }
            }, s()(a, "iClass", {
                type: String,
                default: ""
            }), s()(a, "iItemClass", {
                type: String,
                default: ""
            }), a),
            computed: {
                lists: function() {
                    var e = this;
                    return this.groups.map(function(t) {
                        return e.current.includes(t.value) ? t.checked = !0 : t.checked = !1, t;
                    });
                }
            },
            data: function() {
                return {
                    positionCls: "i-checkbox-checkbox-left"
                };
            },
            watch: {
                position: function(e, t) {
                    e !== t && this.setPosition();
                }
            },
            methods: {
                setPosition: function() {
                    this.positionCls = "left" === this.position ? "i-checkbox-checkbox-left" : "i-checkbox-checkbox-right";
                },
                checkboxChange: function(e) {
                    this.$emit("change", {
                        value: e.mp.detail.value
                    });
                }
            }
        };
    },
    f6jk: function(e, t, i) {
        var a = i("djS1"), n = i("vCIh"), s = i("ybqe")(a.a, n.a, function(e) {
            i("vPQg");
        }, null, null);
        t.a = s.exports;
    },
    h9D8: function(e, t, i) {
        var a = i("pFYg"), n = i.n(a);
        t.a = {
            props: {
                title: {
                    type: String
                },
                label: {
                    type: String
                },
                value: {
                    type: String
                },
                onlyTapFooter: {
                    type: Boolean
                },
                isLink: {
                    type: Boolean,
                    default: !1
                },
                linkType: {
                    type: String,
                    default: "navigateTo"
                },
                url: {
                    type: String,
                    default: ""
                },
                isLastCell: {
                    type: Boolean,
                    default: !1
                },
                iClass: {
                    type: String,
                    default: ""
                }
            },
            computed: {
                classObj: function() {
                    var e = this.isLastCell ? "i-cell-last" : "", t = this.isLink ? "i-cell-access" : "";
                    return this.iClass + " " + e + " " + t;
                }
            },
            methods: {
                navigateTo: function(e) {
                    var t = this.url, i = n()(this.isLink);
                    this.$emit("click", e), this.isLink && t && "true" !== t && "false" !== t && ("boolean" === i || "string" === i ? [ "navigateTo", "redirectTo", "switchTab", "reLaunch" ].includes(this.linkType) ? global.mpvue[this.linkType].call(global.mpvue, {
                        url: t
                    }) : console.warn("linkType 属性可选值为 navigateTo，redirectTo，switchTab，reLaunch", this.linkType) : console.warn("isLink 属性必须是一个字符串或者布尔值", this.isLink));
                },
                handleTap: function() {
                    this.onlyTapFooter || this.navigateTo();
                }
            }
        };
    },
    vCIh: function(e, t, i) {
        t.a = {
            render: function() {
                var e = this.$createElement;
                return (this._self._c || e)("div", {
                    staticClass: "i-cell-group",
                    class: this.iClass
                }, [ this._t("default", null, {
                    mpcomid: "0"
                }) ], 2);
            },
            staticRenderFns: []
        };
    },
    vPQg: function(e, t) {},
    xq4Q: function(e, t, i) {
        Object.defineProperty(t, "__esModule", {
            value: !0
        });
        var a = i("5nAL"), n = i.n(a), s = i("AyAg"), c = i("cQ+I");
        i.n(c), new n.a(s.a).$mount();
    }
}, [ "xq4Q" ]);