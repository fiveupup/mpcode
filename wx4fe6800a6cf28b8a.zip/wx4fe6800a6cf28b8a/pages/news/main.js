require("../../common/manifest.js"), require("../../common/vendor.js"), global.webpackJsonpMpvue([ 7 ], {
    "+q6g": function(t, e, n) {
        e.a = {
            render: function() {
                var t = this.$createElement, e = this._self._c || t;
                return e("div", {
                    class: [ "news", this.isDark && "dark" ]
                }, [ e("NewsCategory", {
                    attrs: {
                        dataSource: this.newsCategoryList,
                        eventid: "0",
                        mpcomid: "0"
                    },
                    on: {
                        change: this.changeNewsType
                    }
                }), this._v(" "), e("div", {
                    staticClass: "space"
                }), this._v(" "), e("div", {
                    staticClass: "news-list"
                }, [ e("ArticleList", {
                    attrs: {
                        dataSource: this.newsList,
                        mpcomid: "1"
                    }
                }) ], 1) ], 1);
            },
            staticRenderFns: []
        };
    },
    "42M3": function(t, e, n) {
        Object.defineProperty(e, "__esModule", {
            value: !0
        });
        var a = n("5nAL"), i = n.n(a), s = n("Xu7u");
        new i.a(s.a).$mount();
    },
    JYnN: function(t, e, n) {
        e.a = {
            render: function() {
                var t = this, e = t.$createElement, n = t._self._c || e;
                return n("div", {
                    staticClass: "news-category"
                }, t._l(t.dataSource, function(e, a) {
                    return n("div", {
                        key: a,
                        staticClass: "category-item",
                        attrs: {
                            eventid: "0_" + a
                        },
                        on: {
                            click: function(n) {
                                t.$emit("change", e.value);
                            }
                        }
                    }, [ n("img", {
                        staticClass: "item-content",
                        attrs: {
                            src: e.backgroundImage
                        }
                    }), t._v(" "), n("span", [ t._v(t._s(e.title)) ]) ]);
                }));
            },
            staticRenderFns: []
        };
    },
    R2KV: function(t, e, n) {
        var a = n("WI7t"), i = n("VfqU"), s = n("VsUZ"), r = n("IcnI"), c = n("oFuF"), o = n("8e4C");
        e.a = {
            components: {
                NewsCategory: a.a,
                ArticleList: i.a
            },
            data: function() {
                return {
                    newsList: [],
                    newsCategoryList: o.i,
                    isDark: wx.getStorageSync("isDark")
                };
            },
            onShow: function() {
                this.isDark = Object(c.onChangeDark)(), this.$root.$mp.page.getTabBar().viewChange(this.isDark), 
                this.$root.$mp.page.getTabBar().setData({
                    selected: 1
                });
            },
            onLoad: function() {
                this.getData();
            },
            onShareAppMessage: function() {
                return {
                    title: "最新的考研资讯，快来看看呀~",
                    path: "/pages/news/main"
                };
            },
            onShareTimeline: function() {
                return {
                    title: "最新的考研资讯，快来看看呀~",
                    path: "/pages/news/main"
                };
            },
            methods: {
                getData: function() {
                    var t = this;
                    s.default.getArticleList({
                        articleType: ""
                    }, function(e) {
                        t.newsList = e.data.sort(function(t, e) {
                            return t.articleSort - e.articleSort;
                        });
                    }, function(e) {
                        401 === e.status && Object(c.repeatLogin)(function() {
                            t.getData();
                        });
                    });
                },
                viewArticle: function(t) {
                    r.a.commit("setArticleUrl", t.articleUrl), wx.navigateTo({
                        url: "/pages/newsDetail/main"
                    });
                },
                changeNewsType: function(t) {
                    wx.navigateTo({
                        url: "/pages/newsList/main",
                        success: function(e) {
                            e.eventChannel.emit("params", {
                                articleType: t
                            });
                        }
                    });
                }
            }
        };
    },
    WI7t: function(t, e, n) {
        var a = n("c4Sp"), i = n("JYnN"), s = n("ybqe")(a.a, i.a, function(t) {
            n("qVrR");
        }, "data-v-1759041e", null);
        e.a = s.exports;
    },
    Xu7u: function(t, e, n) {
        var a = n("R2KV"), i = n("+q6g"), s = n("ybqe")(a.a, i.a, function(t) {
            n("rVn7");
        }, "data-v-6a8365aa", null);
        e.a = s.exports;
    },
    c4Sp: function(t, e, n) {
        e.a = {
            props: {
                dataSource: {
                    type: Array,
                    default: function() {
                        return [];
                    }
                }
            },
            methods: {
                style: function(t) {
                    return {
                        background: "#fff"
                    };
                }
            }
        };
    },
    qVrR: function(t, e) {},
    rVn7: function(t, e) {}
}, [ "42M3" ]);