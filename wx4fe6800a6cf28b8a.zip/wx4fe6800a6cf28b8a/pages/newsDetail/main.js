require("../../common/manifest.js"), require("../../common/vendor.js"), global.webpackJsonpMpvue([ 27 ], {
    CtCI: function(e, t, r) {
        var a = r("PZEw"), n = r("pCIy"), i = r("ybqe")(a.a, n.a, function(e) {
            r("HKqn");
        }, null, null);
        t.a = i.exports;
    },
    HKqn: function(e, t) {},
    IQA7: function(e, t, r) {
        Object.defineProperty(t, "__esModule", {
            value: !0
        });
        var a = r("5nAL"), n = r.n(a), i = r("CtCI");
        new n.a(i.a).$mount();
    },
    PZEw: function(e, t, r) {
        var a = r("mvHQ"), n = r.n(a), i = r("oFuF"), c = r("IcnI");
        t.a = {
            data: function() {
                return {
                    isDark: wx.getStorageSync("isDark"),
                    articleSrc: ""
                };
            },
            onShareAppMessage: function() {
                var e = n()({
                    articleSrc: this.articleSrc
                });
                return console.log(this.articleSrc), {
                    title: "最新的考研资讯，快来看看呀~",
                    path: "/pages/newsDetail/main?params=" + e
                };
            },
            onShareTimeline: function() {
                return {
                    title: "最新的考研资讯，快来看看呀~",
                    path: "/pages/newsDetail/main?params=" + n()({
                        articleSrc: this.articleSrc
                    })
                };
            },
            onLoad: function(e) {
                if (this.isDark = Object(i.onChangeDark)(), e.params) {
                    var t = JSON.parse(e.params);
                    this.articleSrc = t.articleSrc;
                } else this.articleSrc = c.a.state.articleUrl;
            }
        };
    },
    pCIy: function(e, t, r) {
        t.a = {
            render: function() {
                var e = this.$createElement, t = this._self._c || e;
                return t("div", [ t("web-view", {
                    attrs: {
                        src: this.articleSrc,
                        mpcomid: "0"
                    }
                }) ], 1);
            },
            staticRenderFns: []
        };
    }
}, [ "IQA7" ]);