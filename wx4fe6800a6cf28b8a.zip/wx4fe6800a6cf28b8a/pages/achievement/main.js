require("../../common/manifest.js"), require("../../common/vendor.js"), global.webpackJsonpMpvue([ 9 ], {
    "41+S": function(t, s, e) {
        var a = e("VsUZ").default;
        s.a = {
            data: function() {
                return {
                    inter: 0,
                    isSuccess: !1,
                    years: "----",
                    zql: "--",
                    windowHeight: "",
                    windowWidth: "",
                    schoolNum: 0,
                    schoolText: [],
                    name: ""
                };
            },
            onLoad: function(t) {
                var s = this, e = t.right, n = t.zql, i = t.ans.replace(/!/g, "=");
                console.log(e, n, i), this.$set(this, "years", wx.getStorageSync("zkz").years || "默认年份"), 
                this.$set(this, "name", wx.getStorageSync("zkz").name || "默认名字"), a.achievement({
                    qId: 1,
                    right: e,
                    userId: wx.getStorageSync("userInfo").userId,
                    result: i
                }, function(t) {
                    console.log(t), s.$set(s, "schoolText", t.school), s.$set(s, "schoolNum", t.school.length), 
                    s.$set(s, "inter", t.result), n > 0 ? s.$set(s, "isSuccess", !0) : s.$set(s, "isSuccess", !1), 
                    s.$set(s, "zql", 100 * n + "%");
                });
            },
            methods: {
                checkSet: function() {
                    wx.getSetting({
                        success: function(t) {
                            console.log(t), 0 == t.authSetting["scope.writePhotosAlbum"] && wx.showModal({
                                title: "提示",
                                content: "请打开相册授权权限，并重新保存",
                                success: function(t) {
                                    t.confirm ? wx.openSetting({
                                        success: function(t) {
                                            console.log(t.authSetting);
                                        }
                                    }) : t.cancel;
                                }
                            });
                        }
                    });
                },
                toPlay: function() {
                    wx.showLoading({
                        title: "系统处理中~"
                    }), this.zql > "0%" ? this.ls_drawImg() : (console.log(2), this.ls_draw_fail());
                },
                saveCanvasImage: function(t) {
                    var s = this;
                    wx.saveImageToPhotosAlbum({
                        filePath: t,
                        success: function(t) {
                            wx.hideLoading(), wx.showModal({
                                title: "存图成功",
                                content: "图片成功保存到相册了，可以分享到朋友圈了",
                                showCancel: !1,
                                confirmText: "好的",
                                confirmColor: "#a78845",
                                success: function(t) {
                                    t.confirm && console.log("用户点击确定");
                                }
                            });
                        },
                        fail: function(t) {
                            console.log("fail11"), wx.hideLoading(), s.checkSet();
                        }
                    });
                },
                ls_drawImg: function() {
                    var t = this, s = wx.createCanvasContext("shareCanvas");
                    t.windowWidth = 375, t.windowHeight = (1256 + 50 * t.schoolNum) / 2;
                    var e = t.windowWidth, n = t.windowHeight;
                    wx.getImageInfo({
                        src: a.imgUrl + "/back_achi.png",
                        success: function(i) {
                            s.drawImage(i.path, 0, 0, e, n + 500, 100, 100), s.draw(), wx.getImageInfo({
                                src: t.isSuccess ? a.imgUrl + "/success.png" : a.imgUrl + "/loser.png",
                                success: function(i) {
                                    s.drawImage(i.path, (e - (e - 30)) / 2, 0, e - 30, 199), s.draw(!0), s.setFillStyle("#fff"), 
                                    s.fillRect((e - (e - 30)) / 2, 199, e - 30, 260 + 25 * t.schoolNum), s.font = "25px bold kktt", 
                                    s.setFillStyle("#000"), s.setTextAlign("center"), s.fillText(t.name + "同学", 187.5, 240), 
                                    s.setTextAlign("left"), s.font = "15px bold kktt", s.fillText("正确率", e - (e - 30), n - (n - 340)), 
                                    s.fillText("你打败了                  的竞争对手", e - (e - 30), n - (n - 370)), s.fillText("在                   的中考，你可以进入如下高中:", e - (e - 30), n - (n - 393.5));
                                    var c = 420;
                                    t.schoolText.forEach(function(t, e) {
                                        e % 2 == 0 ? s.setFillStyle("#ed3939") : s.setFillStyle("#3332c7"), s.fillText(t, 30, c), 
                                        c += 25;
                                    }), s.font = "20px bold kktt", s.setFillStyle("#ed3939"), s.fillText(t.zql, 80, 340), 
                                    s.fillText(t.inter, 90, 370), s.fillText(t.years, 50, 395), s.draw(!0), wx.getImageInfo({
                                        src: a.imgUrl + "/footer_achi.png",
                                        success: function(i) {
                                            s.drawImage(i.path, 15, n - 180, 345, 157), s.draw(!0, function() {
                                                wx.getImageInfo({
                                                    src: t.isSuccess ? a.imgUrl + "/success1.png" : a.imgUrl + "/loser1.png",
                                                    success: function(a) {
                                                        s.drawImage(a.path, 60, 250, 258, 53), s.draw(!0, function() {
                                                            wx.canvasToTempFilePath({
                                                                width: e,
                                                                height: n,
                                                                canvasId: "shareCanvas",
                                                                quality: 1,
                                                                success: function(s) {
                                                                    t.saveCanvasImage(s.tempFilePath);
                                                                },
                                                                fail: function() {
                                                                    console.log("canvasToTempFilePath fail");
                                                                }
                                                            });
                                                        });
                                                    }
                                                });
                                            });
                                        }
                                    });
                                }
                            });
                        }
                    });
                },
                ls_draw_fail: function() {
                    var t = this, s = wx.createCanvasContext("shareCanvas");
                    t.windowWidth = 375, t.windowHeight = (1106 + 50 * t.schoolNum) / 2;
                    var e = t.windowWidth, n = t.windowHeight;
                    wx.getImageInfo({
                        src: a.imgUrl + "/back_achi.png",
                        success: function(i) {
                            s.drawImage(i.path, 0, 0, e, n, 100, 100), s.draw(), wx.getImageInfo({
                                src: a.imgUrl + "/loser.png",
                                success: function(i) {
                                    s.drawImage(i.path, 15, 0, e - 30, 199), s.draw(!0), s.setFillStyle("#fff"), s.fillRect(15, 199, e - 30, 260 + 25 * t.schoolNum), 
                                    s.font = "25px bold kktt", s.setFillStyle("#000"), s.setTextAlign("center"), s.fillText(t.name + "同学", 187.5, 240), 
                                    s.setTextAlign("left"), s.font = "15px bold kktt", s.fillText("很遗憾", 30, 330), s.fillText("您的正确率为", 30, 360), 
                                    s.fillText("您的排名低于          的竞争对手", 30, 390), s.fillText("即便在那个年代,您也要努力才能考到好高中啊！！", 30, 420), 
                                    s.font = "20px bold kktt", s.setFillStyle("#ed3939"), s.fillText(" 0", 120, 362), 
                                    s.fillText("50%", 120, 393), s.draw(!0), wx.getImageInfo({
                                        src: a.imgUrl + "/footer_achi.png",
                                        success: function(i) {
                                            s.drawImage(i.path, 15, n - 180, 345, 157), s.draw(!0, function() {
                                                wx.getImageInfo({
                                                    src: a.imgUrl + "/loser1.png",
                                                    success: function(a) {
                                                        s.drawImage(a.path, 60, 230, 258, 63), s.draw(!0, function() {
                                                            wx.canvasToTempFilePath({
                                                                width: e,
                                                                height: n,
                                                                canvasId: "shareCanvas",
                                                                quality: 1,
                                                                success: function(s) {
                                                                    t.saveCanvasImage(s.tempFilePath);
                                                                },
                                                                fail: function() {
                                                                    console.log("canvasToTempFilePath fail");
                                                                }
                                                            });
                                                        });
                                                    }
                                                });
                                            });
                                        }
                                    });
                                }
                            });
                        }
                    });
                }
            }
        };
    },
    FlLt: function(t, s) {},
    KyE9: function(t, s, e) {
        s.a = {
            render: function() {
                var t = this, s = t.$createElement, e = t._self._c || s;
                return e("div", {
                    staticClass: "container"
                }, [ e("img", {
                    staticClass: "backImg",
                    attrs: {
                        src: "/static/images/back_achi.png",
                        alt: ""
                    }
                }), t._v(" "), t.isSuccess ? e("img", {
                    staticClass: "header",
                    attrs: {
                        src: "/static/images/success.png",
                        alt: ""
                    }
                }) : e("img", {
                    staticClass: "header",
                    attrs: {
                        src: "/static/images/loser.png",
                        alt: ""
                    }
                }), t._v(" "), e("div", {
                    staticClass: "erlow"
                }, [ e("div", {
                    staticClass: "name"
                }, [ t._v("\n      " + t._s(t.name) + "同学\n    ") ]), t._v(" "), t.isSuccess ? e("img", {
                    staticClass: "status",
                    attrs: {
                        src: "/static/images/success1.png",
                        alt: ""
                    }
                }) : e("img", {
                    staticClass: "status",
                    attrs: {
                        src: "/static/images/loser1.png",
                        alt: ""
                    }
                }), t._v(" "), e("div", {
                    staticClass: "text"
                }, [ t.zql > "0%" ? e("div", [ e("p", [ t._v("正确率 "), e("span", [ t._v(t._s(t.zql)) ]) ]), t._v(" "), e("p", [ t._v("\n          您打败了\n          "), e("span", [ t._v(t._s(t.inter)) ]), t._v("的竞争对手\n        ") ]), t._v(" "), e("p", [ t._v("在" + t._s(t.years) + "的中考，您可以进入如下高中：") ]) ], 1) : e("div", [ e("p", [ t._v("很遗憾") ]), t._v(" "), e("p", [ t._v("您的正确率为"), e("span", [ t._v("0") ]) ]), t._v(" "), e("p", [ t._v("您的排名低于"), e("span", [ t._v("50%") ]), t._v("的竞争对手") ]), t._v(" "), e("p", [ t._v("即便在那个年代,您也要努力才能考到好高中啊！！") ]) ], 1), t._v(" "), t.zql > "0%" ? e("div", {
                    staticClass: "school"
                }, t._l(t.schoolText, function(s, a) {
                    return e("block", {
                        key: a
                    }, [ e("p", [ t._v(t._s(s)) ]) ], 1);
                })) : t._e() ]), t._v(" "), e("img", {
                    staticClass: "footer",
                    attrs: {
                        src: "/static/images/footer_achi.png",
                        alt: ""
                    }
                }), t._v(" "), e("div", {
                    staticClass: "toPlay",
                    attrs: {
                        eventid: "0"
                    },
                    on: {
                        click: t.toPlay
                    }
                }) ]), t._v(" "), e("div", {
                    staticClass: "canvas"
                }, [ e("canvas", {
                    style: {
                        width: t.windowWidth + "px",
                        height: t.windowHeight + "px"
                    },
                    attrs: {
                        "canvas-id": "shareCanvas"
                    }
                }) ]) ]);
            },
            staticRenderFns: []
        };
    },
    dCFe: function(t, s) {},
    eL47: function(t, s, e) {
        var a = e("41+S"), n = e("KyE9"), i = e("ybqe")(a.a, n.a, function(t) {
            e("dCFe"), e("FlLt");
        }, "data-v-2a4376e4", null);
        s.a = i.exports;
    },
    "kaV/": function(t, s, e) {
        Object.defineProperty(s, "__esModule", {
            value: !0
        });
        var a = e("5nAL"), n = e.n(a), i = e("eL47");
        new n.a(i.a).$mount();
    }
}, [ "kaV/" ]);