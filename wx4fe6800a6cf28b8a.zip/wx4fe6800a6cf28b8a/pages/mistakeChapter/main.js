require("../../common/manifest.js"), require("../../common/vendor.js"), global.webpackJsonpMpvue([ 33 ], {
    "4DP4": function(t, e, n) {
        n("8e4C");
        var a = n("WvcL"), i = n("3waA"), s = (n("VsUZ"), n("oFuF")), r = n("IcnI");
        e.a = {
            components: {
                "i-tabs": a.a,
                "i-tab": i.a
            },
            data: function() {
                return {
                    isDark: !1
                };
            },
            computed: {
                subject: function() {
                    return r.a.state.subjectList;
                },
                mistakeTimeType: function() {
                    return r.a.state.mistakeTimeType;
                },
                current: {
                    get: function() {
                        return r.a.state.mistakeCurrent;
                    },
                    set: function(t) {
                        r.a.commit("setMistakeCurrent", t);
                    }
                },
                chapterList: function() {
                    return r.a.state.countByChapter;
                }
            },
            onLoad: function() {
                this.isDark = Object(s.onChangeDark)(), this.getChapter();
            },
            onUnload: function() {
                r.a.dispatch("getMistakeTimeCount");
            },
            methods: {
                changeCurrent: function(t) {
                    var e = this.subject;
                    this.current = t, r.a.commit("setExamCategory", e[t].examCategory), this.getChapter();
                },
                getChapter: function() {
                    r.a.dispatch("getMistakeCountByTimeAndChapter");
                },
                chooseExercise: function(t) {
                    var e = this.subject, n = this.current;
                    wx.navigateTo({
                        url: "/pages/mistake/main",
                        success: function(a) {
                            a.eventChannel.emit("params", {
                                isDetailBack: !1,
                                majorId: e[n].id,
                                examCategory: e[n].examCategory,
                                chapterId: t.id
                            });
                        }
                    });
                }
            }
        };
    },
    XadT: function(t, e, n) {
        var a = n("4DP4"), i = n("rfEf"), s = n("ybqe")(a.a, i.a, function(t) {
            n("zDwH");
        }, null, null);
        e.a = s.exports;
    },
    rfEf: function(t, e, n) {
        e.a = {
            render: function() {
                var t = this, e = t.$createElement, n = t._self._c || e;
                return n("div", {
                    class: [ "mistake-chapter", t.isDark && "dark" ]
                }, [ n("div", {
                    staticClass: "tab-myself"
                }, [ n("i-tabs", {
                    attrs: {
                        "i-class": "title-content",
                        scroll: "true",
                        eventid: "0",
                        mpcomid: "1"
                    },
                    on: {
                        change: t.changeCurrent
                    },
                    model: {
                        value: t.current,
                        callback: function(e) {
                            t.current = e;
                        },
                        expression: "current"
                    }
                }, t._l(t.subject, function(t, e) {
                    return n("i-tab", {
                        key: e,
                        attrs: {
                            "item-key": e,
                            title: t.name,
                            mpcomid: "0_" + e
                        }
                    });
                })) ], 1), t._v(" "), n("div", {
                    staticClass: "list"
                }, t._l(t.chapterList, function(e, a) {
                    return n("block", {
                        key: a
                    }, [ n("div", {
                        staticClass: "question-list-item list-line",
                        attrs: {
                            eventid: "1_" + a
                        },
                        on: {
                            click: function(n) {
                                t.chooseExercise(e, a);
                            }
                        }
                    }, [ n("p", {
                        staticClass: "exam-title"
                    }, [ t._v(t._s(e.name)) ]), t._v(" "), n("p", {
                        staticClass: "exam-num"
                    }, [ t._v("共" + t._s(e.incorrectChapterNumber) + "道") ]) ], 1) ]);
                })) ]);
            },
            staticRenderFns: []
        };
    },
    wM1h: function(t, e, n) {
        Object.defineProperty(e, "__esModule", {
            value: !0
        });
        var a = n("XadT"), i = n("5nAL"), s = n.n(i), r = n("ltdW"), c = (n.n(r), n("ocgm"));
        n.n(c), new s.a(a.a).$mount();
    },
    zDwH: function(t, e) {}
}, [ "wM1h" ]);