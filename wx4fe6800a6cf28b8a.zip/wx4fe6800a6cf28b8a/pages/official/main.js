require("../../@babel/runtime/helpers/Arrayincludes"), require("../../common/manifest.js"), 
require("../../common/vendor.js"), global.webpackJsonpMpvue([ 25 ], {
    "7knw": function(t, e) {},
    JMLm: function(t, e, n) {
        var a = n("mvHQ"), o = n.n(a), i = n("VsUZ"), s = n("WvcL"), c = n("3waA"), r = n("tXM+"), l = n("oFuF"), u = n("IcnI");
        e.a = {
            components: {
                "i-tabs": s.a,
                "i-tab": c.a,
                TipsPage: r.a
            },
            data: function() {
                return {
                    schoolCollection: [],
                    userCollection: [],
                    parentId: "1000057140649529344",
                    current: "",
                    examList: [],
                    errorCode: "",
                    notCheck: !0,
                    selNumber: 0,
                    selIds: [],
                    isRandom: !1,
                    isDark: wx.getStorageSync("isDark")
                };
            },
            onLoad: function(t) {
                t && "{}" !== o()(t) ? wx.showModal({
                    title: "未做完",
                    content: "是否保存到草稿",
                    confirmText: "保存草稿",
                    confirmColor: "#ffcc00",
                    success: function(e) {
                        e.confirm && i.default.submitExam(t, function(t) {
                            console.log(t);
                        });
                    }
                }) : this.isDark = Object(l.onChangeDark)();
            },
            onShow: function() {
                this.getUserSchool(), this.$root.$mp.page.getTabBar().setData({
                    selected: 1
                });
            },
            onShareAppMessage: function() {
                return {
                    title: "推荐一个超好用的电气考研刷题小程序，海量真题任你刷！"
                };
            },
            onShareTimeline: function() {
                return {
                    title: "推荐一个超好用的电气考研刷题小程序，海量真题任你刷！"
                };
            },
            methods: {
                goSelSchool: function() {
                    var t = this;
                    wx.navigateTo({
                        url: "/pages/selectSchool/main",
                        success: function(e) {
                            e.eventChannel.emit("params", {
                                schoolCollection: t.schoolCollection,
                                selIds: t.selIds,
                                selNumber: t.selNumber
                            });
                        }
                    });
                },
                getSchool: function() {
                    var t = this;
                    i.default.getSchool({
                        parentId: this.parentId
                    }, function(e) {
                        var n = e.data.data.map(function(t) {
                            return t.id;
                        });
                        t.selIds = t.selIds.filter(function(t) {
                            return n.includes(t);
                        }), t.userCollection = e.data.data.filter(function(e) {
                            return t.selIds.includes(e.id);
                        }), t.schoolCollection = e.data.data.map(function(e) {
                            return -1 !== t.selIds.indexOf(e.id) && (e.ext = !0), e;
                        }).sort(function(t, e) {
                            return t.sort - e.sort;
                        }), t.current = t.userCollection[0].id, t.getExamForSchool();
                    }, function(e) {
                        401 === e.status && Object(l.repeatLogin)(function() {
                            t.getSchool();
                        });
                    });
                },
                getUserSchool: function() {
                    var t = this;
                    i.default.getUserSchool({}, function(e) {
                        null === e.data.data ? (t.selIds = [], t.selNumber = 0) : (t.selIds = e.data.data.targetSchoolId.split(","), 
                        t.selNumber = t.selIds.length), t.getSchool();
                    }, function(e) {
                        401 === e.status && Object(l.repeatLogin)(function() {
                            t.getUserSchool();
                        });
                    });
                },
                getExamForSchool: function() {
                    var t = this;
                    i.default.getExamForSchool({
                        schoolId: this.current
                    }, function(e) {
                        t.examList = e.data.data.sort(function(t, e) {
                            return t.examSort - e.examSort;
                        }), e.data.data.length > 0 ? t.notCheck = !0 : (t.notCheck = !1, t.errorCode = 5002);
                    }, function(e) {
                        401 === e.status && Object(l.repeatLogin)(function() {
                            t.getExamForSchool();
                        });
                    });
                },
                handleChangeScroll: function(t) {
                    this.current = t, this.getExamForSchool();
                },
                beginPractice: function(t) {
                    u.a.commit("setExamination", t), wx.setStorageSync("title", t.examinationName), 
                    wx.setStorageSync("isFastType", 2), wx.navigateTo({
                        url: "/pages/fastExercise/main",
                        success: function(e) {
                            e.eventChannel.emit("params", {
                                type: 2,
                                examId: t.id
                            });
                        }
                    });
                }
            }
        };
    },
    sEoK: function(t, e, n) {
        e.a = {
            render: function() {
                var t = this, e = t.$createElement, n = t._self._c || e;
                return n("div", {
                    class: [ "official", t.isDark && "dark" ]
                }, [ t._m(0), t._v(" "), n("block", [ n("div", {
                    staticClass: "tab-title"
                }, [ n("i-tabs", {
                    attrs: {
                        iClass: "title-content",
                        scroll: "true",
                        eventid: "0",
                        mpcomid: "1"
                    },
                    on: {
                        change: t.handleChangeScroll
                    },
                    model: {
                        value: t.current,
                        callback: function(e) {
                            t.current = e;
                        },
                        expression: "current"
                    }
                }, t._l(t.userCollection, function(t, e) {
                    return n("i-tab", {
                        key: e,
                        attrs: {
                            itemKey: t.id,
                            title: t.name,
                            mpcomid: "0_" + e
                        }
                    });
                })), t._v(" "), n("div", {
                    staticClass: "add",
                    attrs: {
                        eventid: "1"
                    },
                    on: {
                        click: t.goSelSchool
                    }
                }, [ n("img", {
                    staticClass: "add-img",
                    attrs: {
                        src: "//static.yanzhishi.cn/images/wechat/tianjianhui@2x.png",
                        mode: "widthFix",
                        alt: "add"
                    }
                }) ]) ], 1), t._v(" "), t.notCheck ? n("div", {
                    staticClass: "exam"
                }, t._l(t.examList, function(e, a) {
                    return n("block", {
                        key: a
                    }, [ n("div", {
                        staticClass: "list",
                        attrs: {
                            id: a,
                            eventid: "2_" + a
                        },
                        on: {
                            click: function(n) {
                                t.beginPractice(e);
                            }
                        }
                    }, [ n("div", {
                        staticClass: "title"
                    }, [ n("img", {
                        staticClass: "dot",
                        attrs: {
                            src: "//static.yanzhishi.cn/images/wechat/list_icon.jpg",
                            alt: "cheese"
                        }
                    }), t._v(" "), n("span", [ t._v(t._s(e.examinationName)) ]) ]), t._v(" "), n("img", {
                        staticClass: "right",
                        attrs: {
                            src: "//static.yanzhishi.cn/images/wechat/jiantou@2x.png",
                            alt: "arrow"
                        }
                    }) ]) ]);
                })) : n("div", {
                    staticClass: "error-box"
                }, [ n("tips-page", {
                    attrs: {
                        error: t.errorCode,
                        mpcomid: "2"
                    }
                }) ], 1) ]) ], 1);
            },
            staticRenderFns: [ function() {
                var t = this.$createElement, e = this._self._c || t;
                return e("div", {
                    staticClass: "banner"
                }, [ e("img", {
                    staticClass: "front",
                    attrs: {
                        src: "//static.yanzhishi.cn/images/elec/zhenti_logo.jpg",
                        mode: "widthFix",
                        alt: ""
                    }
                }) ]);
            } ]
        };
    },
    vAGk: function(t, e, n) {
        Object.defineProperty(e, "__esModule", {
            value: !0
        });
        var a = n("5nAL"), o = n.n(a), i = n("x9sv"), s = n("ltdW"), c = (n.n(s), n("ocgm"));
        n.n(c), new o.a(i.a).$mount();
    },
    x9sv: function(t, e, n) {
        var a = n("JMLm"), o = n("sEoK"), i = n("ybqe")(a.a, o.a, function(t) {
            n("7knw");
        }, null, null);
        e.a = i.exports;
    }
}, [ "vAGk" ]);