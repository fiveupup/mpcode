require("../../common/manifest.js"), require("../../common/vendor.js"), global.webpackJsonpMpvue([ 47 ], {
    JVXQ: function(e, s, r) {
        var t = r("jBiL"), i = r("ZzKf"), a = r("ybqe")(t.a, i.a, function(e) {
            r("pM0c");
        }, null, null);
        s.a = a.exports;
    },
    ZzKf: function(e, s, r) {
        s.a = {
            render: function() {
                var e = this, s = e.$createElement, r = e._self._c || s;
                return r("div", {
                    class: [ "analysis-container", e.isDark && "dark" ]
                }, [ r("div", {
                    staticClass: "title"
                }, [ r("span", [ e._v(e._s(e.title)) ]), e._v(" "), r("div", {
                    staticClass: "feedback-btn",
                    attrs: {
                        eventid: "0"
                    },
                    on: {
                        click: e.handleFeedback
                    }
                }, [ r("i-icon", {
                    attrs: {
                        type: "prompt",
                        size: "16",
                        color: "#999",
                        mpcomid: "0"
                    }
                }), e._v(" "), r("span", [ e._v("错题反馈") ]) ], 1) ]), e._v(" "), r("div", {
                    staticClass: "gray"
                }), e._v(" "), r("div", {
                    staticClass: "tag-content"
                }, [ r("div", {
                    staticClass: "tag"
                }, [ e._v("\n      " + e._s(1 === e.type ? e.errorNum + 1 : e.errorIndex[e.errorNum] + 1) + "/" + e._s(e.exerciseList.length) + "\n    ") ]), e._v(" "), r("button", {
                    staticClass: "tag tag-right",
                    attrs: {
                        eventid: "1"
                    },
                    on: {
                        click: e.showAnswer
                    }
                }, [ e._v("\n      答题卡\n    ") ]), e._v(" "), r("div", [ 1 === e.edit.exerciseType ? r("analysis-choice", {
                    attrs: {
                        exercise: e.edit,
                        userAnswer: e.userAnswer,
                        examCategory: e.examCategory,
                        majorId: e.marjorId,
                        mpcomid: "1"
                    }
                }) : e._e(), e._v(" "), 2 === e.edit.exerciseType ? r("analysis-multiple", {
                    attrs: {
                        exercise: e.edit,
                        userAnswer: e.userAnswer,
                        examCategory: e.examCategory,
                        majorId: e.marjorId,
                        mpcomid: "2"
                    }
                }) : e._e(), e._v(" "), 3 === e.edit.exerciseType ? r("analysis-fill", {
                    attrs: {
                        exercise: e.edit,
                        userAnswer: e.userAnswer,
                        examCategory: e.examCategory,
                        majorId: e.marjorId,
                        mpcomid: "3"
                    }
                }) : e._e(), e._v(" "), 5 === e.edit.exerciseType ? r("analysis-judge", {
                    attrs: {
                        exercise: e.edit,
                        userAnswer: e.userAnswer,
                        examCategory: e.examCategory,
                        majorId: e.marjorId,
                        mpcomid: "4"
                    }
                }) : e._e(), e._v(" "), 4 === e.edit.exerciseType ? r("analysis-short", {
                    attrs: {
                        exercise: e.edit,
                        userAnswer: e.userAnswer,
                        examCategory: e.examCategory,
                        majorId: e.marjorId,
                        mpcomid: "5"
                    }
                }) : e._e(), e._v(" "), 7 === e.edit.exerciseType ? r("analysis-cloze", {
                    attrs: {
                        exercise: e.edit,
                        userAnswer: e.userAnswer,
                        examCategory: e.examCategory,
                        majorId: e.marjorId,
                        mpcomid: "6"
                    }
                }) : e._e() ], 1) ], 1), e._v(" "), r("fixed-button", {
                    attrs: {
                        status: e.status,
                        type: "collect",
                        exerciseId: e.edit.exerciseId,
                        majorId: e.majorId,
                        chapterId: e.chapterId,
                        collectFunc: e.collectExercise,
                        prevFunc: e.prevExercise,
                        nextFunc: e.nextExercise,
                        mpcomid: "7"
                    }
                }), e._v(" "), r("answer-page", {
                    attrs: {
                        show: e.answerPageShow,
                        showButton: !1,
                        analysis: !0,
                        mistake: !0,
                        answers: 1 === e.type ? e.answerParams.answers : e.errorAnswers,
                        close: e.closeCard,
                        changeView: e.changeExercise,
                        submit: e.submitAnswer,
                        mpcomid: "8"
                    }
                }), e._v(" "), r("i-toast", {
                    ref: "toast",
                    attrs: {
                        mpcomid: "9"
                    }
                }), e._v(" "), r("i-modal", {
                    attrs: {
                        title: e.isMember ? "返回试卷列表" : "返回首页",
                        visible: e.backModal,
                        eventid: "2",
                        mpcomid: "10"
                    },
                    on: {
                        ok: e.handleContinue,
                        cancel: e.handleClose
                    }
                }) ], 1);
            },
            staticRenderFns: []
        };
    },
    jBiL: function(e, s, r) {
        var t = r("x0F5"), i = r("eeHf"), a = r("19G0"), n = r("C2pC"), o = r("D04a"), c = r("epAQ"), d = r("LGpd"), l = r("pWcx"), h = r("OAQQ"), m = r("u8j3"), u = (r.n(m), 
        r("4u4q")), x = r("b1mz"), w = r("oFuF"), p = r("IcnI");
        s.a = {
            components: {
                AnalysisChoice: t.a,
                AnalysisMultiple: i.a,
                AnalysisFill: a.a,
                AnalysisJudge: n.a,
                AnalysisShort: o.a,
                AnalysisCloze: c.a,
                FixedButton: d.a,
                iToast: h.a,
                AnswerPage: l.a,
                "i-modal": u.a,
                "i-icon": x.a
            },
            onLoad: function() {
                var e = this;
                this.isDark = Object(w.onChangeDark)(), this.isMember = wx.getStorageSync("isMember"), 
                this.title = wx.getStorageSync("title"), this.errorNum = 0, this.$mp.page.getOpenerEventChannel().on("type", function(s) {
                    e.type = s.type, e.answerParams = s.answerParams, e.errorIndex = [], e.answerParams.answers = e.answerParams.answers.map(function(s, r) {
                        return s.index = r, 2 === s.answerType && e.errorIndex.push(r), s;
                    }), e.errorAnswers = e.answerParams.answers.filter(function(e) {
                        return 2 === e.answerType;
                    }), e.exerciseList = wx.getStorageSync("exerciseList"), 1 === e.type ? (e.edit = e.exerciseList[e.errorNum], 
                    e.userAnswer = e.answerParams.answers[e.errorNum]) : (e.edit = e.exerciseList[e.errorIndex[e.errorNum]], 
                    e.userAnswer = e.answerParams.answers[e.errorIndex[e.errorNum]]), e.chapterId = e.edit.exerciseProperty.knowledgeTags[0].split(",")[1], 
                    e.collectExerciseIds = wx.getStorageSync("collectExerciseIds"), e.majorId = wx.getStorageSync("majorId"), 
                    e.checkExerciseIsCollect();
                });
            },
            onUnload: function() {
                this.isBackHome = !1, this.errorNum = 0;
            },
            data: function() {
                return {
                    title: "全国统考",
                    type: null,
                    answerParams: null,
                    edit: null,
                    errorIndex: [],
                    errorNum: 0,
                    userAnswer: {},
                    exerciseList: [],
                    isBackHome: !1,
                    backModal: !1,
                    answerPageShow: !1,
                    status: 1,
                    collectExerciseIds: [],
                    majorId: null,
                    chapterId: null,
                    errorAnswers: [],
                    isMember: !1,
                    isDark: wx.getStorageSync("isDark")
                };
            },
            computed: {
                examCategory: function() {
                    return console.log(p.a.state.examCategory, "-------------------"), p.a.state.examCategory;
                },
                marjorId: function() {
                    return console.log(p.a.state.majorId, "-------------------"), p.a.state.majorId;
                }
            },
            methods: {
                getUserAnswer: function(e) {
                    return {
                        answer: e.answer,
                        answerType: e.answerType
                    };
                },
                prevExercise: function() {
                    1 === this.type ? (this.errorNum > 0 ? (this.errorNum -= 1, this.edit = this.exerciseList[this.errorNum], 
                    this.userAnswer = this.answerParams.answers[this.errorNum], this.chapterId = this.edit.exerciseProperty.knowledgeTags[0].split(",")[1], 
                    this.checkExerciseIsCollect()) : Object(m.$Toast)(this, {
                        content: "已经是第一题了哦",
                        type: "warning"
                    }), this.isBackHome = !1) : (this.errorNum > 0 ? (this.errorNum -= 1, this.edit = this.exerciseList[this.errorIndex[this.errorNum]], 
                    this.userAnswer = this.answerParams.answers[this.errorIndex[this.errorNum]], this.chapterId = this.edit.exerciseProperty.knowledgeTags[0].split(",")[1]) : Object(m.$Toast)(this, {
                        content: "已经是第一题了哦",
                        type: "warning"
                    }), this.isBackHome = !1), this.checkExerciseIsCollect();
                },
                nextExercise: function() {
                    this.isBackHome ? this.backModal = !0 : (1 === this.type ? (this.errorNum < this.exerciseList.length - 1 && (this.errorNum += 1, 
                    this.edit = this.exerciseList[this.errorNum], this.userAnswer = this.answerParams.answers[this.errorNum], 
                    this.chapterId = this.edit.exerciseProperty.knowledgeTags[0].split(",")[1]), this.errorNum === this.exerciseList.length - 1 && (this.isBackHome = !0)) : (this.errorNum < this.errorIndex.length - 1 && (this.errorNum += 1, 
                    this.edit = this.exerciseList[this.errorIndex[this.errorNum]], this.userAnswer = this.answerParams.answers[this.errorIndex[this.errorNum]], 
                    this.chapterId = this.edit.exerciseProperty.knowledgeTags[0].split(",")[1]), this.errorNum === this.errorIndex.length - 1 && (this.isBackHome = !0)), 
                    this.checkExerciseIsCollect());
                },
                handleClose: function() {
                    this.backModal = !1;
                },
                handleContinue: function() {
                    this.backModal = !1, wx.navigateBack({
                        delta: 2
                    });
                },
                showAnswer: function() {
                    this.answerPageShow = !0;
                },
                closeCard: function() {
                    this.answerPageShow = !1;
                },
                checkExerciseIsCollect: function() {
                    this.collectExerciseIds.indexOf(this.edit.exerciseId) > -1 ? this.status = 0 : this.status = 1;
                },
                collectExercise: function(e) {
                    0 === e ? this.collectExerciseIds.push(this.edit.exerciseId) : this.collectExerciseIds.splice(this.collectExerciseIds.indexOf(this.edit.exerciseId), 1), 
                    this.checkExerciseIsCollect();
                },
                changeExercise: function(e) {
                    this.answerPageShow = !1, this.errorNum = e, this.edit = this.exerciseList[e], this.userAnswer = this.answerParams.answers[e], 
                    this.chapterId = this.edit.exerciseProperty.knowledgeTags[0].split(",")[1], this.checkExerciseIsCollect();
                },
                handleFeedback: function() {
                    p.a.commit("setFeedbackMajorId", this.majorId), p.a.commit("setFeedbackExerciseId", this.edit.exerciseId), 
                    wx.navigateTo({
                        url: "/pages/feedback/main",
                        success: function(e) {
                            console.log(e);
                        }
                    });
                }
            }
        };
    },
    l71O: function(e, s, r) {
        Object.defineProperty(s, "__esModule", {
            value: !0
        });
        var t = r("5nAL"), i = r.n(t), a = r("JVXQ"), n = r("m2WG"), o = (r.n(n), r("cvLP"));
        r.n(o), new i.a(a.a).$mount();
    },
    pM0c: function(e, s) {}
}, [ "l71O" ]);