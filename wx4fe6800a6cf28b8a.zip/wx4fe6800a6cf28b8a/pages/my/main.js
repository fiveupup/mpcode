require("../../common/manifest.js"), require("../../common/vendor.js"), global.webpackJsonpMpvue([ 30 ], {
    "3ube": function(t, a, i) {
        Object.defineProperty(a, "__esModule", {
            value: !0
        });
        var s = i("5nAL"), e = i.n(s), n = i("ULSo"), c = i("+PwL");
        i.n(c), new e.a(n.a).$mount();
    },
    JY6s: function(t, a) {},
    M6pZ: function(t, a, i) {
        a.a = {
            render: function() {
                var t = this, a = t.$createElement, i = t._self._c || a;
                return i("div", {
                    class: [ "my-container", t.isDark && "dark" ]
                }, [ i("div", {
                    staticClass: "header"
                }, [ i("img", {
                    staticClass: "my-img",
                    attrs: {
                        src: t.isDark ? "//static.yanzhishi.cn/images/wechat/me_black2.png" : "//static.yanzhishi.cn/images/wechat/me_normal2.png",
                        mode: "widthFix",
                        alt: "myself"
                    }
                }), t._v(" "), i("div", {
                    staticClass: "container"
                }, [ i("div", {
                    staticClass: "my-content"
                }, [ i("div", {
                    staticClass: "my"
                }, [ i("img", {
                    staticClass: "my-avator",
                    attrs: {
                        src: t.isLogin ? t.userInfo.avatarUrl : "//static.yanzhishi.cn/images/wechat/entry/logo.png",
                        alt: "avator"
                    }
                }), t._v(" "), t.isLogin ? i("block", [ i("p", {
                    staticClass: "info-name"
                }, [ i("span", {
                    staticClass: "new"
                }, [ t._v(t._s(t.userInfo.name)) ]), t._v(" "), i("span", {
                    staticClass: "update",
                    attrs: {
                        eventid: "0"
                    },
                    on: {
                        click: t.getUserProfile
                    }
                }, [ t._v("更新账户 >") ]) ]) ], 1) : t._e(), t._v(" "), i("div", {
                    staticClass: "study"
                }, [ i("div", {
                    staticClass: "middle-line"
                }, [ i("span", [ t._v("累计天数") ]), t._v(" "), i("span", {
                    staticClass: "num"
                }, [ t._v(t._s(t.exerciseDays)) ]) ]), t._v(" "), i("div", [ i("span", [ t._v("刷题数量") ]), t._v(" "), i("span", {
                    staticClass: "num"
                }, [ t._v(t._s(t.answerTotal)) ]) ]) ]) ], 1), t._v(" "), i("div", {
                    staticClass: "horizontal"
                }, [ i("div", {
                    staticClass: "horizontal-item"
                }, [ i("navigator", {
                    staticClass: "jump nav",
                    attrs: {
                        appId: "wx0946522d787f9cbe",
                        openType: "navigate",
                        path: "pages/index/index",
                        target: "miniProgram"
                    }
                }, [ i("img", {
                    staticClass: "left",
                    attrs: {
                        src: t.isDark ? "//static.yanzhishi.cn/images/wechat/shop_dark.png" : "//static.yanzhishi.cn/images/wechat/shop.png",
                        mode: "widthFix"
                    }
                }), t._v(" "), i("span", [ t._v("芝士小店") ]) ]), t._v(" "), i("div", {
                    staticClass: "jump"
                }, [ i("img", {
                    staticClass: "contact",
                    attrs: {
                        src: t.isDark ? "//static.yanzhishi.cn/images/wechat/kefu@2x.png" : "//static.yanzhishi.cn/images/wechat/kefu.png",
                        mode: "widthFix"
                    }
                }), t._v(" "), i("button", {
                    attrs: {
                        "open-type": "contact"
                    }
                }, [ t._v("\n                芝士帮帮\n              ") ]) ], 1), t._v(" "), i("div", {
                    staticClass: "jump",
                    attrs: {
                        eventid: "1"
                    },
                    on: {
                        click: function(a) {
                            t.goToRanking();
                        }
                    }
                }, [ i("img", {
                    attrs: {
                        src: t.isDark ? "//static.yanzhishi.cn/images/wechat/entry/top_icon_black.png" : "//static.yanzhishi.cn/images/wechat/entry/top_icon.png",
                        mode: "widthFix",
                        alt: ""
                    }
                }), t._v(" "), i("span", {
                    staticClass: "top"
                }, [ t._v("排行榜") ]) ]) ], 1), t._v(" "), i("div", {
                    staticClass: "horizontal-item line"
                }, [ i("div", {
                    staticClass: "jump",
                    attrs: {
                        eventid: "2"
                    },
                    on: {
                        click: t.getMemberExam
                    }
                }, [ i("img", {
                    attrs: {
                        src: t.isDark ? "//static.yanzhishi.cn/images/wechat/hundred@2x.png" : "//static.yanzhishi.cn/images/wechat/hundred.png",
                        mode: "widthFix",
                        alt: ""
                    }
                }), t._v(" "), i("span", [ t._v("全程精选") ]) ]), t._v(" "), i("div", {
                    staticClass: "jump",
                    attrs: {
                        eventid: "3"
                    },
                    on: {
                        click: t.getTestSite
                    }
                }, [ i("img", {
                    attrs: {
                        src: t.isDark ? "//static.yanzhishi.cn/images/wechat/lnzt@2x.png" : "//static.yanzhishi.cn/images/wechat/category2.png",
                        mode: "widthFix",
                        alt: ""
                    }
                }), t._v(" "), i("span", [ t._v("练透考点") ]) ]), t._v(" "), i("div", {
                    staticClass: "jump",
                    attrs: {
                        eventid: "4"
                    },
                    on: {
                        click: t.onlineExam
                    }
                }, [ i("img", {
                    attrs: {
                        src: t.isDark ? "//static.yanzhishi.cn/images/wechat/online_exam_dark.png" : "//static.yanzhishi.cn/images/wechat/online_exam.png",
                        mode: "widthFix"
                    }
                }), t._v(" "), i("span", [ t._v("芝士模考") ]) ]) ]) ]), t._v(" "), i("div", {
                    staticClass: "list"
                }, [ i("ul", [ i("li", {
                    attrs: {
                        eventid: "5"
                    },
                    on: {
                        click: t.exerciseRecord
                    }
                }, [ i("img", {
                    attrs: {
                        src: t.isDark ? "//static.yanzhishi.cn/images/wechat/stjl@2x.png" : "//static.yanzhishi.cn/images/wechat/lianxijilu.png",
                        mode: "widthFix",
                        alt: ""
                    }
                }), t._v(" "), i("span", [ t._v("刷题记录") ]), t._v(" "), i("img", {
                    staticClass: "right",
                    attrs: {
                        src: "//static.yanzhishi.cn/images/wechat/jiantouhui@2x.png"
                    }
                }) ]), t._v(" "), i("li", {
                    attrs: {
                        eventid: "6"
                    },
                    on: {
                        click: t.collectRecord
                    }
                }, [ i("img", {
                    attrs: {
                        src: t.isDark ? "//static.yanzhishi.cn/images/wechat/sc@2x.png" : "//static.yanzhishi.cn/images/wechat/collect.png",
                        mode: "widthFix",
                        alt: ""
                    }
                }), t._v(" "), i("span", [ t._v("收藏题目") ]), t._v(" "), i("img", {
                    staticClass: "right",
                    attrs: {
                        src: "//static.yanzhishi.cn/images/wechat/jiantouhui@2x.png"
                    }
                }) ]), t._v(" "), i("li", {
                    attrs: {
                        eventid: "7"
                    },
                    on: {
                        click: t.mistakeRecord
                    }
                }, [ i("img", {
                    attrs: {
                        src: t.isDark ? "//static.yanzhishi.cn/images/wechat/ct@2x.png" : "//static.yanzhishi.cn/images/wechat/category3.png",
                        mode: "widthFix",
                        alt: ""
                    }
                }), t._v(" "), i("span", [ t._v("错题本") ]), t._v(" "), i("img", {
                    staticClass: "right",
                    attrs: {
                        src: "//static.yanzhishi.cn/images/wechat/jiantouhui@2x.png"
                    }
                }) ]), t._v(" "), t.showMyCourse ? i("li", {
                    attrs: {
                        eventid: "8"
                    },
                    on: {
                        click: t.myCourseList
                    }
                }, [ i("img", {
                    attrs: {
                        src: t.isDark ? "//static.yanzhishi.cn/images/wechat/assistant@2x.png" : "//static.yanzhishi.cn/images/wechat/assistant.png",
                        mode: "widthFix",
                        alt: ""
                    }
                }), t._v(" "), i("span", [ t._v("我的课程") ]), t._v(" "), i("img", {
                    staticClass: "right",
                    attrs: {
                        src: "//static.yanzhishi.cn/images/wechat/jiantouhui@2x.png"
                    }
                }) ]) : t._e(), t._v(" "), t.isInstitution ? i("li", {
                    attrs: {
                        eventid: "9"
                    },
                    on: {
                        click: t.viewShareUser
                    }
                }, [ i("img", {
                    attrs: {
                        src: t.isDark ? "//static.yanzhishi.cn/images/wechat/entry/share_user_black.png" : "//static.yanzhishi.cn/images/wechat/entry/share_user.png",
                        mode: "widthFix",
                        alt: ""
                    }
                }), t._v(" "), i("span", [ t._v("邀请人数") ]), t._v(" "), i("img", {
                    staticClass: "right",
                    attrs: {
                        src: "//static.yanzhishi.cn/images/wechat/jiantouhui@2x.png"
                    }
                }) ]) : t._e() ], 1) ], 1), t._v(" "), i("div", {
                    staticClass: "list"
                }, [ i("ul", [ i("li", {
                    staticClass: "between"
                }, [ i("span", [ t._v("夜间模式") ]), t._v(" "), i("p", [ i("i-switch", {
                    attrs: {
                        value: t.isDark,
                        eventid: "10",
                        mpcomid: "0"
                    },
                    on: {
                        change: t.onChangeDark
                    },
                    slot: "footer"
                }) ], 1) ], 1) ], 1) ], 1), t._v(" "), i("div", {
                    staticClass: "remark"
                }, [ i("p", {
                    staticClass: "remark-title"
                }, [ t._v("\n            芝士提醒：\n          ") ]), t._v(" "), i("p", [ t._v("1. 本题库可用于各校自命题的备考") ]), t._v(" "), i("p", [ t._v("\n            2. 动动手指，点击右上角\n            "), i("span", {
                    staticClass: "share"
                }, [ t._v("\n              ·\n              "), i("span", {
                    staticClass: "middle"
                }, [ t._v("·") ]), t._v("·\n            ") ]), t._v("分享给其他小伙伴喔！\n          ") ]) ], 1) ]) ]) ]), t._v(" "), t.showImg ? i("div", {
                    staticClass: "poster"
                }, [ i("img", {
                    staticClass: "pic",
                    attrs: {
                        src: "//static.yanzhishi.cn/images/wechat/poster1.png",
                        mode: "widthFix",
                        alt: "poster",
                        eventid: "11"
                    },
                    on: {
                        longpress: t.saveImg
                    }
                }), t._v(" "), i("img", {
                    staticClass: "close",
                    attrs: {
                        src: "//static.yanzhishi.cn/images/wechat/close.png",
                        mode: "widthFix",
                        alt: "close",
                        eventid: "12"
                    },
                    on: {
                        click: function(a) {
                            t.drawImg(!1);
                        }
                    }
                }) ]) : t._e(), t._v(" "), t.showWeChat ? i("div", {
                    staticClass: "poster back"
                }, [ i("img", {
                    staticClass: "pic",
                    attrs: {
                        src: "//static.yanzhishi.cn/images/wechat/topic1.png",
                        mode: "widthFix",
                        alt: "poster"
                    }
                }), t._v(" "), i("div", {
                    staticClass: "poster-content"
                }, [ i("p", {
                    staticClass: "wechat-title"
                }, [ t._v("\n        『研芝士题库』\n      ") ]), t._v(" "), i("p", {
                    staticClass: "wechat-join"
                }, [ t._v("\n        邀你加入体验升级计划\n      ") ]), t._v(" "), i("p", {
                    staticClass: "wechat-add"
                }, [ t._v("\n        添加助教学姐微信\n      ") ]), t._v(" "), i("p", {
                    staticClass: "wechat-code"
                }, [ t._v("\n        yanzhishi2020\n      ") ]), t._v(" "), i("div", {
                    staticClass: "wechat-copy",
                    attrs: {
                        eventid: "13"
                    },
                    on: {
                        click: function(a) {
                            t.copyWechat("yanzhishi2020");
                        }
                    }
                }, [ t._v("\n        复制微信号\n      ") ]) ], 1), t._v(" "), i("img", {
                    staticClass: "close number",
                    attrs: {
                        src: "//static.yanzhishi.cn/images/wechat/close.png",
                        mode: "widthFix",
                        alt: "close",
                        eventid: "14"
                    },
                    on: {
                        click: function(a) {
                            t.changeShow(!1);
                        }
                    }
                }) ]) : t._e(), t._v(" "), t.cardSelfModal ? i("card-mark", {
                    key: "1",
                    attrs: {
                        eventid: "15",
                        mpcomid: "1"
                    },
                    on: {
                        close: t.closeVip
                    }
                }, [ i("div", {
                    staticClass: "card-body"
                }, [ t._l(t.openModalSel.openText, function(a, s) {
                    return i("p", {
                        key: s
                    }, [ t._v("\n        " + t._s(a) + "\n      ") ]);
                }), t._v(" "), i("button", {
                    staticClass: "wechat-copy",
                    attrs: {
                        "open-type": "contact"
                    }
                }, [ t._v("\n        " + t._s(t.openModalSel.openBtn) + "\n      ") ]) ], 2) ]) : t._e() ], 1);
            },
            staticRenderFns: []
        };
    },
    ULSo: function(t, a, i) {
        var s = i("xRBm"), e = i("M6pZ"), n = i("ybqe")(s.a, e.a, function(t) {
            i("JY6s");
        }, null, null);
        a.a = n.exports;
    },
    xRBm: function(t, a, i) {
        var s = i("oFuF"), e = i("RaUN"), n = i("UCfo"), c = i("IcnI"), o = i("oFuF"), r = i("VsUZ").default;
        i("oFuF").default, a.a = {
            components: {
                CardMark: n.a,
                "i-switch": e.a
            },
            data: function() {
                return {
                    userInfo: wx.getStorageSync("userInfo"),
                    isLogin: !1,
                    notLogin: !1,
                    windowWidth: 600,
                    windowHeight: 551,
                    showImg: !1,
                    showWeChat: !1,
                    wechatCode: "yanzhishi2020",
                    exerciseDays: 0,
                    answerTotal: 0,
                    ranking: 0,
                    cardSelfModal: !1,
                    onlineExamModal: !1,
                    userCode: null,
                    isDark: wx.getStorageSync("isDark") || !1,
                    isClick: !1,
                    cardModal: !1,
                    isInstitution: !1,
                    openModal: {
                        memberExam: {
                            openText: [ "童鞋，这是全程班学员专属通道喔" ],
                            openBtn: "我要开通"
                        },
                        testSite: {
                            openText: [ "童鞋", "这是练透考点2000题学员专属通道呢" ],
                            openBtn: "我要开通"
                        },
                        onlineExam: {
                            openText: [ "模考密押，万人云模考通道" ],
                            openBtn: "我要上岸"
                        }
                    },
                    openModalSel: {},
                    showMyCourse: !0
                };
            },
            onLoad: function() {
                var t = this;
                this.onChangeDark({
                    value: wx.getStorageSync("isDark") || !1
                }), wx.login({
                    success: function(a) {
                        t.userCode = a.code;
                    }
                });
            },
            onShow: function() {
                this.showImg = !1, this.$root.$mp.page.getTabBar().setData({
                    selected: 2
                }), this.judgeLogin(), this.getCourseList();
            },
            methods: {
                getCourseList: function() {
                    var t = this;
                    r.getCourseList({}, function(a) {
                        t.showMyCourse = a.data.length > 0;
                    });
                },
                onlineExam: function() {
                    var t = this;
                    this.openModalSel = this.openModal.onlineExam, r.getOnlineExam({}, function(t) {
                        c.a.commit("setIsFromChannel", !0), wx.navigateTo({
                            url: "/pages/online/main"
                        });
                    }, function(a) {
                        405 === a.status && (t.cardSelfModal = !0);
                    });
                },
                closeOnline: function() {
                    this.onlineExamModal = !1;
                },
                getMemberExam: function(t) {
                    var a = this;
                    this.openModalSel = this.openModal.memberExam, r.getSelfExam({
                        majorId: "701769479767592960"
                    }, function(t) {
                        c.a.commit("setMemberType", 2), c.a.commit("setIsFromChannel", !0), wx.navigateTo({
                            url: "/pages/member/main",
                            success: function(a) {
                                a.eventChannel.emit("params", {
                                    majorId: "701769479767592960",
                                    result: t.data
                                });
                            }
                        });
                    }, function(t) {
                        405 === t.status && (a.cardSelfModal = !0);
                    });
                },
                getTestSite: function() {
                    var t = this;
                    this.openModalSel = this.openModal.testSite, r.getMoocExam({
                        majorId: "701769479767592960"
                    }, function(t) {
                        c.a.commit("setMemberType", 1), c.a.commit("setIsFromChannel", !0), wx.navigateTo({
                            url: "/pages/member/main",
                            success: function(a) {
                                a.eventChannel.emit("params", {
                                    majorId: "701769479767592960",
                                    result: t.data
                                });
                            }
                        });
                    }, function(a) {
                        t.isClick = !1, 405 === a.status && (t.cardSelfModal = !0);
                    });
                },
                getAssistant: function() {
                    wx.navigateTo({
                        url: "/pages/recruit/main"
                    });
                },
                judgeLogin: function() {
                    var t = this;
                    this.userInfo = wx.getStorageSync("userInfo"), Object(o.judgeLogin)({
                        isJump: !1
                    }).then(function() {
                        t.isLogin = !0, t.getStudyDays(), t.getInstitution();
                    }).catch(function() {
                        t.isLogin = !1;
                    });
                },
                getStudyDays: function() {
                    var t = this;
                    r.getExerciseDay({}, function(a) {
                        200 === a.data.code && (t.exerciseDays = a.data.data.exerciseDay, t.answerTotal = a.data.data.answerTotal);
                    }, function(a) {
                        401 === a.status && Object(s.repeatLogin)(function() {
                            t.getStudyDays();
                        });
                    }, !1);
                },
                exerciseRecord: function() {
                    wx.navigateTo({
                        url: "/pages/record/main",
                        success: function(t) {
                            t.eventChannel.emit("params", {
                                isDetailBack: !1
                            });
                        }
                    });
                },
                mistakeRecord: function() {
                    wx.navigateTo({
                        url: "/pages/mistakeTime/main"
                    });
                },
                collectRecord: function() {
                    wx.navigateTo({
                        url: "/pages/collectTime/main"
                    });
                },
                getInfoLogin: function(t) {
                    if ("getUserInfo:ok" === t.mp.detail.errMsg) {
                        var a = t.mp.detail.userInfo, i = this;
                        wx.login({
                            success: function(t) {
                                var s = t.code, e = {
                                    name: a.nickName,
                                    sex: a.gender,
                                    avatarUrl: a.avatarUrl
                                };
                                wx.setStorageSync("userInfo", e), i.isLogin = !0, i.userInfo = e, r.useLogin({
                                    code: s,
                                    userInfo: {
                                        name: e.name,
                                        sex: e.sex,
                                        previewUrl: e.avatarUrl
                                    }
                                }, function(t) {
                                    wx.setStorageSync("token", t), i.getStudyDays();
                                });
                            }
                        });
                    }
                },
                copyWechat: function(t) {
                    t.setClipboardData({
                        data: t,
                        success: function(t) {
                            console.log(t);
                        }
                    });
                },
                drawImg: function(t) {
                    wx.navigateTo({
                        url: "/pages/myDetail/main"
                    });
                },
                changeShow: function(t) {
                    this.showWeChat = t;
                },
                saveImg: function() {
                    var t = function() {
                        wx.saveImageToPhotosAlbum({
                            filePath: "static/tabbar/poster1.png",
                            success: function(t) {
                                wx.showToast({
                                    title: "保存成功"
                                });
                            },
                            fail: function(t) {
                                wx.showToast({
                                    title: "保存失败"
                                });
                            }
                        });
                    };
                    wx.getSetting({
                        success: function(a) {
                            a.authSetting["scope.writePhotosAlbum"] ? t() : wx.authorize({
                                scope: "scope.writePhotosAlbum",
                                success: function() {
                                    t();
                                },
                                fail: function(t) {
                                    wx.showToast({
                                        title: "请在「右上角」-「设置」中打开授权权限哦",
                                        icon: "none",
                                        duration: 3e3
                                    });
                                }
                            });
                        },
                        fail: function(t) {
                            console.log(t);
                        }
                    });
                },
                onChangeDark: function(t) {
                    wx.setStorageSync("isDark", t.value), this.isDark = Object(s.onChangeDark)(), this.$root.$mp.page.getTabBar().viewChange(this.isDark);
                },
                closeVip: function() {
                    this.cardSelfModal = !1;
                },
                viewNews: function() {
                    wx.navigateTo({
                        url: "/pages/news/main"
                    });
                },
                getUserProfile: function() {
                    wx.navigateTo({
                        url: "/pages/userInfo/main"
                    });
                },
                goToPage: function() {
                    c.a.commit("setArticleUrl", "https://mp.weixin.qq.com/s/0q-2HN29vKlAwHxh_jhOEg"), 
                    wx.navigateTo({
                        url: "/pages/newsDetail/main"
                    });
                },
                goToRanking: function() {
                    wx.navigateTo({
                        url: "/pages/topRanking/main"
                    });
                },
                viewShareUser: function() {
                    wx.navigateTo({
                        url: "/pages/shareUser/main"
                    });
                },
                getInstitution: function() {
                    var t = this;
                    r.getUserDetail({}, function(a) {
                        var i = a.data.data, s = i.roleList, e = i.nickName, n = i.phone, c = i.previewUrl;
                        t.isInstitution = !!s.find(function(t) {
                            return "role_institution" === t.roleCode;
                        }), c.indexOf("http://wxfile://") > -1 && (c = c.slice(7, c.length)), t.userInfo = {
                            name: e,
                            phone: n,
                            avatarUrl: c
                        }, wx.setStorageSync("userInfo", {
                            name: e,
                            phone: n,
                            avatarUrl: c
                        });
                    });
                },
                myCourseList: function() {
                    wx.navigateTo({
                        url: "/pages/myCourse/main"
                    });
                }
            }
        };
    }
}, [ "3ube" ]);