require("../../common/manifest.js"), require("../../common/vendor.js"), global.webpackJsonpMpvue([ 10 ], {
    "8Frz": function(t, e) {},
    LW6l: function(t, e, i) {
        var a = i("VsUZ"), s = i("SA64"), n = null;
        e.a = {
            components: {
                DrawerMobile: s.a
            },
            data: function() {
                return {
                    userInfo: wx.getStorageSync("userInfo"),
                    formatPhone: "",
                    drawerVisible: !1,
                    typeKey: "name",
                    editName: "",
                    editPhone: "",
                    showTime: !1,
                    finishSend: !1,
                    time: 60,
                    verify: ""
                };
            },
            computed: {
                title: function() {
                    return "name" === this.typeKey ? "修改昵称" : "修改手机号";
                }
            },
            mounted: function() {
                this.userInfo = wx.getStorageSync("userInfo"), this.userInfo.phone && (this.formatPhone = this.userInfo.phone.replace(/(\d{3})\d{4}(\d{4})/, "$1****$2"));
            },
            onUnload: function() {
                this.time = 60, this.showTime = !1, this.drawerVisible = !1, n && clearInterval(n);
            },
            methods: {
                chooseAvatar: function(t) {
                    var e = this;
                    console.log(t, "头像"), a.default.upAnswer({
                        filePath: t.target.avatarUrl
                    }, function(t) {
                        console.log(JSON.parse(t.data), "结果");
                        var i = JSON.parse(t.data);
                        e.userInfo.avatarUrl = i.data.previewUrl, e.updateAvatar();
                    });
                },
                updateAvatar: function(t) {
                    var e = this, i = this.userInfo, s = this.verify, n = this.editPhone, o = {
                        name: i.name,
                        previewUrl: i.avatarUrl,
                        phone: n || i.phone,
                        smsCode: s
                    };
                    a.default.updateUserInfo(o, function(i) {
                        200 === i.data.code ? (e.drawerVisible = !1, t && t()) : wx.showToast({
                            title: i.data.msg,
                            icon: "none"
                        });
                    });
                },
                onViewEdit: function(t) {
                    "name" === t ? this.editName = this.userInfo.name : (this.editPhone = "", this.verify = "", 
                    this.showTime = !1), this.typeKey = t, this.drawerVisible = !0;
                },
                submitValue: function() {
                    var t = this;
                    if ("name" === this.typeKey) {
                        if (this.editName.trim().length > 9) return void wx.showToast({
                            title: "不能超过9个字符",
                            icon: "none"
                        });
                        this.userInfo.name = this.editName, this.verify = "", this.updateAvatar();
                    } else {
                        if (!/^[0-9]{11}$/.test(this.editPhone.trim())) return void wx.showToast({
                            title: "请输入正确的手机号",
                            icon: "none"
                        });
                        if (!/^[0-9]{6}$/.test(this.verify.trim())) return void wx.showToast({
                            title: "请输入正确的验证码",
                            icon: "none"
                        });
                        this.finishSend ? this.updateAvatar(function() {
                            t.userInfo.phone = t.editPhone, t.formatPhone = t.editPhone.replace(/(\d{3})\d{4}(\d{4})/, "$1****$2"), 
                            t.editPhone = "";
                        }) : wx.showToast({
                            title: "请先获取验证码",
                            icon: "none"
                        });
                    }
                },
                showVerity: function() {
                    var t = this;
                    /^[0-9]{11}$/.test(this.editPhone.trim()) ? a.default.getVerityCode({
                        mobile: this.editPhone.trim(),
                        captcha: ""
                    }, function(e) {
                        200 !== e.data.code ? wx.showToast({
                            title: e.data.msg,
                            icon: "none"
                        }) : (t.finishSend = !0, t.showTime = !0, t.time = 60, n = setInterval(function() {
                            0 === t.time ? (t.showTime = !1, clearInterval(n), n = null) : t.time--;
                        }, 1e3));
                    }) : wx.showToast({
                        title: "请输入正确的手机号",
                        icon: "none"
                    });
                }
            }
        };
    },
    TsVe: function(t, e, i) {
        e.a = {
            render: function() {
                var t = this, e = t.$createElement, i = t._self._c || e;
                return i("div", [ i("div", {
                    staticClass: "user-info"
                }, [ i("button", {
                    staticClass: "list-item",
                    attrs: {
                        "open-type": "chooseAvatar",
                        eventid: "0"
                    },
                    on: {
                        chooseavatar: t.chooseAvatar
                    }
                }, [ i("span", {
                    staticClass: "left"
                }, [ t._v("头像") ]), t._v(" "), i("div", {
                    staticClass: "right"
                }, [ i("img", {
                    staticClass: "avatar",
                    attrs: {
                        src: t.userInfo.avatarUrl
                    }
                }), t._v(" "), i("img", {
                    attrs: {
                        src: "//static.yanzhishi.cn/images/wechat/jiantouhui@2x.png",
                        mode: "widthFix"
                    }
                }) ]) ]), t._v(" "), i("div", {
                    staticClass: "list-item",
                    attrs: {
                        eventid: "1"
                    },
                    on: {
                        click: function(e) {
                            t.onViewEdit("name");
                        }
                    }
                }, [ i("span", {
                    staticClass: "left"
                }, [ t._v("用户昵称") ]), t._v(" "), i("div", {
                    staticClass: "right"
                }, [ i("span", [ t._v(t._s(t.userInfo.name)) ]), t._v(" "), i("img", {
                    attrs: {
                        src: "//static.yanzhishi.cn/images/wechat/jiantouhui@2x.png",
                        mode: "widthFix"
                    }
                }) ]) ]), t._v(" "), i("div", {
                    staticClass: "list-item",
                    attrs: {
                        eventid: "2"
                    },
                    on: {
                        click: function(e) {
                            t.onViewEdit("phone");
                        }
                    }
                }, [ i("span", {
                    staticClass: "left"
                }, [ t._v("换绑手机") ]), t._v(" "), i("div", {
                    staticClass: "right"
                }, [ i("span", [ t._v(t._s(t.formatPhone || "暂无")) ]), t._v(" "), i("img", {
                    attrs: {
                        src: "//static.yanzhishi.cn/images/wechat/jiantouhui@2x.png",
                        mode: "widthFix"
                    }
                }) ]) ]) ], 1), t._v(" "), i("DrawerMobile", {
                    attrs: {
                        title: t.title,
                        visible: t.drawerVisible,
                        eventid: "7",
                        mpcomid: "0"
                    },
                    on: {
                        close: function(e) {
                            t.drawerVisible = !1;
                        },
                        submit: t.submitValue
                    }
                }, [ "name" === t.typeKey ? i("div", {
                    staticClass: "edit-name"
                }, [ i("div", [ i("input", {
                    directives: [ {
                        name: "model",
                        rawName: "v-model",
                        value: t.editName,
                        expression: "editName"
                    } ],
                    attrs: {
                        type: "nickname",
                        eventid: "3"
                    },
                    domProps: {
                        value: t.editName
                    },
                    on: {
                        input: function(e) {
                            e.target.composing || (t.editName = e.target.value);
                        }
                    }
                }) ]), t._v(" "), i("p", [ t._v("最多可设置9个汉字，可设置含有中文、英文、数字、符号组合的昵称") ]) ], 1) : i("div", {
                    staticClass: "edit-phone"
                }, [ i("div", {
                    staticClass: "phone-item"
                }, [ i("span", {
                    staticClass: "left"
                }, [ t._v("+86") ]), t._v(" "), i("input", {
                    directives: [ {
                        name: "model",
                        rawName: "v-model",
                        value: t.editPhone,
                        expression: "editPhone"
                    } ],
                    attrs: {
                        type: "number",
                        placeholder: "请输入手机号",
                        eventid: "4"
                    },
                    domProps: {
                        value: t.editPhone
                    },
                    on: {
                        input: function(e) {
                            e.target.composing || (t.editPhone = e.target.value);
                        }
                    }
                }) ]), t._v(" "), i("div", {
                    staticClass: "phone-item"
                }, [ i("span", {
                    staticClass: "left"
                }, [ t._v("验证码") ]), t._v(" "), i("input", {
                    directives: [ {
                        name: "model",
                        rawName: "v-model",
                        value: t.verify,
                        expression: "verify"
                    } ],
                    attrs: {
                        type: "number",
                        placeholder: "请输入验证码",
                        eventid: "5"
                    },
                    domProps: {
                        value: t.verify
                    },
                    on: {
                        input: function(e) {
                            e.target.composing || (t.verify = e.target.value);
                        }
                    }
                }), t._v(" "), t.showTime ? i("span", {
                    staticClass: "right"
                }, [ t._v(" " + t._s(t.time) + "S ") ]) : i("span", {
                    staticClass: "right",
                    attrs: {
                        eventid: "6"
                    },
                    on: {
                        click: t.showVerity
                    }
                }, [ t._v("获取验证码") ]) ]), t._v(" "), i("div", {
                    staticClass: "tips"
                }, [ i("p", [ t._v("温馨提醒") ]), t._v(" "), i("p", [ t._v("1.一个手机号只能作为一个账号的登录名") ]), t._v(" "), i("p", [ t._v("2.手机号修改成功，原手机号将不支持登录") ]) ], 1) ]) ]) ], 1);
            },
            staticRenderFns: []
        };
    },
    tMdk: function(t, e, i) {
        var a = i("LW6l"), s = i("TsVe"), n = i("ybqe")(a.a, s.a, function(t) {
            i("8Frz");
        }, "data-v-4c9a8470", null);
        e.a = n.exports;
    },
    wYEz: function(t, e, i) {
        Object.defineProperty(e, "__esModule", {
            value: !0
        });
        var a = i("5nAL"), s = i.n(a), n = i("tMdk");
        new s.a(n.a).$mount();
    }
}, [ "wYEz" ]);