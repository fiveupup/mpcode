require("../../common/manifest.js"), require("../../common/vendor.js"), global.webpackJsonpMpvue([ 32 ], {
    RlWx: function(e, t, a) {
        var s = a("diS0"), r = a("hziw"), i = a("ybqe")(s.a, r.a, function(e) {
            a("gcno");
        }, "data-v-7d008ca4", null);
        t.a = i.exports;
    },
    diS0: function(e, t, a) {
        var s = a("VsUZ"), r = a("x0F5"), i = a("eeHf"), n = a("19G0"), o = a("C2pC"), d = a("D04a"), c = a("epAQ"), m = a("LGpd"), u = a("tXM+"), p = a("oFuF"), l = a("OAQQ"), g = a("u8j3");
        a.n(g), t.a = {
            components: {
                AnalysisChoice: r.a,
                AnalysisMultiple: i.a,
                AnalysisFill: n.a,
                AnalysisJudge: o.a,
                AnalysisShort: d.a,
                AnalysisCloze: c.a,
                FixedButton: m.a,
                iToast: l.a,
                TipsPage: u.a
            },
            data: function() {
                return {
                    edit: {
                        exerciseId: ""
                    },
                    userAnswer: void 0,
                    params: null,
                    touchDot: 0,
                    tmpFlag: !0,
                    text: "下一题",
                    time: 0,
                    interval: null,
                    pageNum: 1,
                    pagesTotal: 1,
                    dateFlag: null,
                    chapterId: "",
                    empty: !1,
                    errorCode: 200,
                    examCategory: 1,
                    isDark: wx.getStorageSync("isDark")
                };
            },
            onLoad: function() {
                var e = this;
                this.isDark = Object(p.onChangeDark)(), this.tmpFlag = !0, this.empty = !1, this.$mp.page.getOpenerEventChannel().on("params", function(t) {
                    e.pageNum = t.pageNum, e.pagesTotal = t.pagesTotal, e.majorId = t.majorId, e.dateFlag = t.dateFlag, 
                    e.examCategory = t.examCategory, e.params = {
                        exerciseId: t.exerciseId,
                        examRecordId: t.examRecordId,
                        examCategory: t.examCategory
                    }, e.getDetail();
                });
            },
            methods: {
                getDetail: function() {
                    var e = this;
                    s.default.getRecordDetail(this.params, function(t) {
                        e.edit = t.data.data.exercise, e.chapterId = t.data.data.chapterId, e.userAnswer = {
                            answer: t.data.data.answer,
                            answerType: t.data.data.answerType,
                            score: t.data.data.score
                        };
                    }, function(t) {
                        401 === t.status && Object(p.repeatLogin)(function() {
                            e.getDetail();
                        });
                    });
                },
                getRecord: function() {
                    var e = this, t = this.majorId, a = this.pageNum, r = this.dateFlag, i = this.examCategory;
                    s.default.getMistakenExerciseList({
                        majorId: t,
                        pageNum: a,
                        pageSize: 1,
                        dateFlag: r,
                        examCategory: i
                    }, function(t) {
                        var a = t.data.data.list[0];
                        e.params = {
                            exerciseId: a.exerciseId,
                            examRecordId: ""
                        }, e.getDetail();
                    }, function(t) {
                        401 === t.status && Object(p.repeatLogin)(function() {
                            e.getRecord();
                        });
                    }, !1);
                },
                removeMistake: function() {
                    var e = this, t = getCurrentPages();
                    t[3].onLoad(this.pageNum - 1), t[2].onLoad(), t[1].onLoad(), this.pageNum > 1 && (this.pageNum -= 1), 
                    this.pagesTotal -= 1, 0 === this.pagesTotal && (this.errorCode = 4094, setTimeout(function() {
                        e.empty = !0;
                    }, 200)), this.getRecord();
                },
                nextExercise: function() {
                    this.pageNum < this.pagesTotal ? (this.pageNum += 1, this.getRecord()) : Object(g.$Toast)(this, {
                        content: "已经是最后一题了哦",
                        type: "warning"
                    });
                },
                prevExercise: function() {
                    this.pageNum > 1 ? (this.pageNum -= 1, this.getRecord()) : Object(g.$Toast)(this, {
                        content: "已经是第一题了哦",
                        type: "warning"
                    });
                }
            }
        };
    },
    gcno: function(e, t) {},
    hziw: function(e, t, a) {
        t.a = {
            render: function() {
                var e = this, t = e.$createElement, a = e._self._c || t;
                return a("div", {
                    class: [ "mistakeDetail", e.isDark && "dark" ]
                }, [ e.empty ? a("div", {
                    staticClass: "error"
                }, [ a("tips-page", {
                    attrs: {
                        error: e.errorCode,
                        mpcomid: "0"
                    }
                }) ], 1) : a("block", [ a("div", {
                    staticClass: "tag-content"
                }, [ a("div", {
                    staticClass: "tag"
                }, [ e._v("\n        " + e._s(e.pageNum) + "/" + e._s(e.pagesTotal) + "\n      ") ]) ]), e._v(" "), a("div", {
                    staticClass: "content"
                }, [ 1 === e.edit.exerciseType ? a("analysis-choice", {
                    attrs: {
                        exercise: e.edit,
                        majorId: e.majorId,
                        userAnswer: e.userAnswer,
                        mpcomid: "1"
                    }
                }) : e._e(), e._v(" "), 2 === e.edit.exerciseType ? a("analysis-multiple", {
                    attrs: {
                        exercise: e.edit,
                        majorId: e.majorId,
                        userAnswer: e.userAnswer,
                        mpcomid: "2"
                    }
                }) : e._e(), e._v(" "), 3 === e.edit.exerciseType ? a("analysis-fill", {
                    attrs: {
                        exercise: e.edit,
                        majorId: e.majorId,
                        userAnswer: e.userAnswer,
                        mpcomid: "3"
                    }
                }) : e._e(), e._v(" "), 5 === e.edit.exerciseType ? a("analysis-judge", {
                    attrs: {
                        exercise: e.edit,
                        majorId: e.majorId,
                        userAnswer: e.userAnswer,
                        mpcomid: "4"
                    }
                }) : e._e(), e._v(" "), 4 === e.edit.exerciseType ? a("analysis-short", {
                    attrs: {
                        exercise: e.edit,
                        majorId: e.majorId,
                        userAnswer: e.userAnswer,
                        mpcomid: "5"
                    }
                }) : e._e(), e._v(" "), 7 === e.edit.exerciseType ? a("analysis-cloze", {
                    attrs: {
                        exercise: e.edit,
                        majorId: e.majorId,
                        userAnswer: e.userAnswer,
                        mpcomid: "6"
                    }
                }) : e._e() ], 1), e._v(" "), a("i-toast", {
                    ref: "toast",
                    attrs: {
                        mpcomid: "7"
                    }
                }), e._v(" "), a("fixed-button", {
                    attrs: {
                        type: "mistake",
                        exerciseId: e.edit.exerciseId,
                        majorId: e.majorId,
                        chapterId: e.chapterId,
                        removeFunc: e.removeMistake,
                        prevFunc: e.prevExercise,
                        nextFunc: e.nextExercise,
                        mpcomid: "8"
                    }
                }) ], 1) ], 1);
            },
            staticRenderFns: []
        };
    },
    "zA+N": function(e, t, a) {
        Object.defineProperty(t, "__esModule", {
            value: !0
        });
        var s = a("RlWx"), r = a("5nAL"), i = a.n(r), n = a("m2WG");
        a.n(n), new i.a(s.a).$mount();
    }
}, [ "zA+N" ]);