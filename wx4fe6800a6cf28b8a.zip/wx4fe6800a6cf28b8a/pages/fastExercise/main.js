require("../../@babel/runtime/helpers/Arrayincludes"), require("../../common/manifest.js"), 
require("../../common/vendor.js"), global.webpackJsonpMpvue([ 2 ], {
    "/z2E": function(e, s, t) {
        s.a = {
            render: function() {
                var e = this, s = e.$createElement, t = e._self._c || s;
                return t("div", {
                    staticClass: "fast-judge"
                }, [ t("h2", [ e._v("判断题") ]), e._v(" "), t("div", {
                    staticClass: "info"
                }, [ t("div", {
                    staticClass: "pd"
                }, [ t("parser", {
                    attrs: {
                        html: e.exercise.exerciseStems,
                        mpcomid: "0"
                    }
                }), e._v(" "), e.errorRate ? t("p", [ e._v("错误率："), t("span", {
                    staticClass: "strong"
                }, [ e._v(e._s(e.exercise.tenantCode / 100) + "%") ]) ]) : e._e() ], 1), e._v(" "), t("div", {
                    staticClass: "judge-answer"
                }, e._l(e.exercise.questions, function(s, i) {
                    return t("block", {
                        key: i
                    }, [ t("div", {
                        class: [ "child", s.questionStem === e.selAnswer ? "sel" : "" ],
                        attrs: {
                            eventid: "0_" + i
                        },
                        on: {
                            click: function(t) {
                                e.chooseAnswer(s.questionStem);
                            }
                        }
                    }, [ e._v(e._s(s.questionAnswer)) ]) ]);
                })) ]) ], 1);
            },
            staticRenderFns: []
        };
    },
    "0RoD": function(e, s) {},
    "6Z1K": function(e, s, t) {
        var i = t("DG26"), a = t("mNTj"), r = t("ybqe")(i.a, a.a, function(e) {
            t("8iSA");
        }, null, null);
        s.a = r.exports;
    },
    "8iSA": function(e, s) {},
    "8lO0": function(e, s, t) {
        var i = t("bOdI"), a = t.n(i), r = t("mvHQ"), n = t.n(r), c = t("VsUZ"), o = t("6Z1K"), l = t("XBpb"), u = t("P/bp"), m = t("LNAu"), h = t("H8QF"), d = t("qVMU"), p = t("LGpd"), x = t("5mIU"), w = t("pWcx"), v = t("tXM+"), f = (t("8e4C"), 
        t("oFuF")), g = t("4u4q"), y = t("b1mz"), _ = t("IcnI");
        s.a = {
            components: {
                FastChoice: o.a,
                FastMultiple: l.a,
                FastFill: u.a,
                FastJudge: m.a,
                FastShort: h.a,
                FastCloze: d.a,
                FixedButton: p.a,
                TipsPage: v.a,
                AnswerPage: w.a,
                iModal: g.a,
                TwoButton: x.a,
                "i-icon": y.a
            },
            data: function() {
                return {
                    notCheck: !0,
                    errorCode: 200,
                    loading: !0,
                    title: "快速刷题",
                    time: "00:00",
                    timeInter: null,
                    editExercise: {},
                    exerciseList: [],
                    exerciseNum: 0,
                    exerciseTotal: 0,
                    majorId: null,
                    chapterId: null,
                    examId: null,
                    answerParams: {
                        examinationId: null,
                        startTime: null,
                        endTime: null,
                        score: 0,
                        correctNumber: 0,
                        inCorrectNumber: 0,
                        examType: 1,
                        submitStatus: 1,
                        answers: []
                    },
                    isShare: !1,
                    answerPageShow: !1,
                    submitModal: !1,
                    collectExerciseIds: [],
                    status: 1,
                    isSubmitAnswer: !1,
                    type: 1,
                    isOnlineExam: !1,
                    interval: null,
                    isDark: wx.getStorageSync("isDark")
                };
            },
            computed: {
                fastAnswerList: function() {
                    return _.a.state.fastAnswerList;
                },
                examination: function() {
                    return _.a.state.fast.examination;
                },
                examCategory: function() {
                    return _.a.state.examCategory;
                }
            },
            onLoad: function(e) {
                var s = this;
                if (this.isDark = Object(f.onChangeDark)(), e.params) {
                    var t = JSON.parse(e.params);
                    return this.editExercise = JSON.parse(decodeURIComponent(t.editExercise)), this.exerciseNum = t.exerciseNum, 
                    this.title = t.title, this.loading = !1, this.isShare = !0, this.time = "00:00", 
                    void clearInterval(this.timeInter);
                }
                this.isShare = !1, this.loading = !0, this.errorCode = "", this.notCheck = !0, this.title = wx.getStorageSync("title") || "快速刷题", 
                this.time = "00:00", clearInterval(this.timeInter), this.countTime(), this.$mp.page.getOpenerEventChannel().on("params", function(e) {
                    switch (s.type = e.type, s.type) {
                      case 3:
                        s.answerParams.examType = 4;
                        break;

                      case 2:
                        s.answerParams.examType = 1;
                        break;

                      case 6:
                        s.answerParams.examType = 7;
                        break;

                      default:
                        s.answerParams.examType = 2;
                    }
                    1 === e.type && (s.majorId = e.majorId, s.chapterId = e.chapterId, s.answerParams.examType = Object(f.checkExamType)(1, s.examCategory), 
                    s.getExerciseList("getExerciseList", {
                        majorId: s.majorId,
                        chapterId: s.chapterId,
                        examCategory: s.examCategory,
                        examType: Object(f.checkExamType)(1, s.examCategory),
                        number: ""
                    })), 2 !== e.type && 3 !== e.type && 7 !== e.type || (s.examId = e.examId, s.chapterId = e.type, 
                    s.majorId = 2 === e.type ? null : e.majorId, s.getExerciseList("getExamExercise", {
                        examId: s.examId
                    })), 4 !== e.type && 5 !== e.type || (s.chapterId = e.type, s.getJob(e.type + 1)), 
                    6 === e.type && (s.examId = e.examId, s.chapterId = e.type, s.majorId = e.majorId, 
                    s.getExerciseList("getExamExercise", {
                        examId: s.examId
                    }));
                }), wx.setStorageSync("exerciseNum", 0);
            },
            onUnload: function() {
                clearInterval(this.interval), _.a.commit("setFastAnswerList", []);
                var e = getCurrentPages(), s = e[e.length - 2];
                s && (this.answerParams.endTime = new Date().getTime(), this.answerParams.submitStatus = 2, 
                this.answerParams.answers = this.answerParams.answers.filter(function(e) {
                    return "" !== e.answer;
                }), null !== this.answerParams.answers && this.answerParams.answers.length > 0 && !this.isSubmitAnswer && s.onLoad(this.answerParams));
            },
            onShow: function() {
                this.answerParams.startTime = new Date().getTime(), this.answerPageShow = !1, this.submitModal = !1, 
                this.isSubmitAnswer = !1, this.isShare || (this.exerciseNum = wx.getStorageSync("exerciseNum"), 
                this.editExercise = this.exerciseList[this.exerciseNum || 0]);
            },
            onShareAppMessage: function() {
                return {
                    title: "研蜜，你怎么看这道题嘛",
                    path: "/pages/practice/main?params=" + n()({
                        editExercise: encodeURIComponent(n()(this.editExercise)),
                        exerciseNum: this.exerciseNum,
                        title: this.title
                    })
                };
            },
            methods: {
                checkChapterId: function() {
                    2 === this.type && (this.majorId = this.editExercise.exerciseProperty.knowledgeTags[0].split(",")[0], 
                    this.chapterId = 2), 5 === this.type && (this.majorId = this.editExercise.exerciseProperty.knowledgeTags[0].split(",")[0], 
                    this.chapterId = 5);
                },
                chooseAnswer: function(e) {
                    var s = this.isShare, t = this.exerciseNum, i = this.type, a = this.majorId, r = this.chapterId, n = this.fastAnswerList, c = this.examCategory, o = this.answerParams.answers, l = this.editExercise, u = l.exerciseId, m = l.exerciseType, h = l.exerciseProperty, d = l.exerciseAnswer;
                    if (!s) {
                        if ([ 3, 4 ].includes(m)) {
                            var p = e.precent, x = e.userAnswer;
                            return n[t] = x, _.a.commit("setFastAnswerList", n), void (o[t] = {
                                exerciseId: u,
                                type: m,
                                majorId: a,
                                chapterId: r,
                                score: Math.ceil(h.score * p),
                                startTime: o[t].startTime,
                                endTime: new Date().getTime(),
                                answer: x,
                                answerType: parseFloat(p) > .6 ? 1 : 2,
                                markStatus: 1,
                                answerSource: Object(f.checkAnswerSource)(i, c)
                            });
                        }
                        _.a.commit("setFastAnswerList", e), o[t] = {
                            exerciseId: u,
                            type: m,
                            majorId: 1 === i || 3 === i ? a : h.knowledgeTags[0].split(",")[0],
                            chapterId: r,
                            score: 0,
                            startTime: o[t].startTime,
                            endTime: new Date().getTime(),
                            answer: e[t],
                            answerType: Object(f.checkAnswerType)(m, i, e[t], d),
                            markStatus: 1,
                            answerSource: Object(f.checkAnswerSource)(i, c)
                        }, 4 === m ? o[t].answer = n[t] ? n[t].join(",") : "" : o[t].score = 2 === m ? Object(f.isArrayEqual)(e[t].split(","), d.split(",")) ? 2 : 0 : Object(f.isArrayEqual)(e[t].split("$-$"), d.split("$-$")) ? 2 : 0;
                    }
                },
                nextExercise: function() {
                    this.exerciseNum = this.exerciseNum + 1, this.exerciseNum >= this.exerciseList.length ? (this.exerciseNum = this.exerciseNum - 1, 
                    this.answerPageShow = !0) : (this.editExercise = this.exerciseList[this.exerciseNum], 
                    this.checkChapterId(), this.answerParams.answers[this.exerciseNum - 1].endTime = new Date().getTime(), 
                    this.answerParams.answers[this.exerciseNum].startTime = new Date().getTime(), wx.setStorageSync("exerciseNum", this.exerciseNum)), 
                    this.checkExerciseIsCollect();
                },
                prevExercise: function() {
                    this.exerciseNum > 0 ? (this.exerciseNum -= 1, this.editExercise = this.exerciseList[this.exerciseNum], 
                    this.checkChapterId(), this.checkExerciseIsCollect(), wx.setStorageSync("exerciseNum", this.exerciseNum)) : wx.showToast({
                        title: "已经是第一题了",
                        icon: "none"
                    });
                },
                changeExercise: function(e) {
                    this.answerPageShow = !1, this.exerciseNum = e, this.editExercise = this.exerciseList[this.exerciseNum], 
                    this.checkChapterId(), this.checkExerciseIsCollect(), wx.setStorageSync("exerciseNum", this.exerciseNum);
                },
                getExerciseList: function(e, s) {
                    var t = this;
                    this.loading = !0, this.answerParams.answers = [], c.default[e](s, function(e) {
                        if (t.errorCode = e.data.code, 200 !== e.data.code) return t.notCheck = !1, !1;
                        t.exerciseNum = 0;
                        var s = e.data.data;
                        t.exerciseList = s.exercises.sort(function(e, s) {
                            return e.applicationCode - s.applicationCode;
                        }), t.exerciseTotal = t.exerciseList.length, wx.setStorageSync("exerciseList", s.exercises), 
                        t.collectExerciseIds = null === s.collectExerciseId ? [] : s.collectExerciseId, 
                        t.answerParams.examinationId = s.examId, t.answerParams.answers = t.exerciseList.map(function(e, i) {
                            var r = [];
                            if (s.answers && s.answers.length > 0 && (r = s.answers.filter(function(s) {
                                return s.exerciseId === e.exerciseId;
                            })), r.length > 0) {
                                var n, c = r[0];
                                return 3 === c.type ? t.fastAnswerList[i] = c.answer.split("$-$") : 4 === c.type ? t.fastAnswerList[i] = c.answer.split(",") : t.fastAnswerList[i] = c.answer, 
                                n = {
                                    exerciseId: c.exerciseId,
                                    type: c.type,
                                    majorId: c.majorId,
                                    chapterId: c.chapterId,
                                    startTime: c.startTime,
                                    endTime: c.endTime,
                                    markStatus: c.markStatus,
                                    answerType: c.answerType,
                                    answer: c.answer,
                                    score: c.score
                                }, a()(n, "type", c.type), a()(n, "answerSource", c.answerSource), n;
                            }
                            return {
                                exerciseId: e.exerciseId,
                                type: e.exerciseType,
                                majorId: 1 === t.type || 3 === t.type ? t.majorId : e.exerciseProperty.knowledgeTags[0].split(",")[0],
                                chapterId: t.chapterId,
                                startTime: new Date().getTime(),
                                markStatus: 1,
                                answerType: 3 === e.exerciseType || 4 === e.exerciseType ? 3 : 2,
                                answer: "",
                                score: 0,
                                answerSource: 3 === t.type ? 6 : 2 === t.type ? 1 : 2
                            };
                        }), t.exerciseNum = t.fastAnswerList.length >= t.exerciseTotal ? t.exerciseTotal - 1 : t.fastAnswerList.length, 
                        t.editExercise = t.exerciseList.length > 0 ? t.exerciseList[t.exerciseNum] : {}, 
                        t.checkChapterId(), t.checkExerciseIsCollect(), wx.setStorageSync("exerciseNum", t.exerciseNum), 
                        setTimeout(function() {
                            t.notCheck = !1, t.loading = !1;
                        }, 1e3);
                    }, function(i) {
                        401 === i.status && Object(f.repeatLogin)(function() {
                            t.getExerciseList(e, s);
                        });
                    });
                },
                checkExerciseIsCollect: function() {
                    this.collectExerciseIds.indexOf(this.editExercise.exerciseId) > -1 ? this.status = 0 : this.status = 1;
                },
                countTime: function() {
                    var e = this, s = 0;
                    this.timeInter = setInterval(function() {
                        s += 1;
                        var t = Math.floor(s / 60) < 10 ? "0" + Math.floor(s / 60) : Math.floor(s / 60), i = s % 60 < 10 ? "0" + s % 60 : s % 60;
                        e.$set(e, "time", t + ":" + i);
                    }, 1e3);
                },
                showAnswer: function() {
                    this.answerPageShow = !0;
                },
                submitAnswer: function() {
                    var e = this;
                    if (this.answerParams.examCategory = this.examCategory, this.answerParams.endTime = new Date().getTime(), 
                    this.answerParams.correctNumber = 0, this.answerParams.inCorrectNumber = 0, this.answerParams.score = 0, 
                    this.answerParams.submitStatus = 1, this.answerParams.answers.forEach(function(s) {
                        1 === s.answerType && (e.answerParams.correctNumber += 1, e.answerParams.score += s.score), 
                        2 === s.answerType && (e.answerParams.inCorrectNumber += 1);
                    }), !this.isOnlineExam && this.answerParams.answers.filter(function(e) {
                        return "" === e.answer;
                    }).length > 0) 4 === this.type ? wx.showToast({
                        title: "请作答所有题目",
                        icon: "none"
                    }) : this.submitModal = !0; else {
                        var s = n()(this.answerParams);
                        this.submitRequest(this.answerParams, s);
                    }
                },
                submitRequest: function(e, s) {
                    var t = this;
                    wx.setStorageSync("collectExerciseIds", this.collectExerciseIds), wx.setStorageSync("majorId", this.majorId), 
                    c.default.submitExam(e, function() {
                        t.isSubmitAnswer = !0, 4 !== t.type ? wx.redirectTo({
                            url: "/pages/report/main?params=" + s
                        }) : wx.showToast({
                            title: "已提交成功，2s后自动返回",
                            icon: "none",
                            duration: 2e3,
                            success: function() {
                                setTimeout(function() {
                                    wx.navigateBack();
                                }, 1500);
                            }
                        });
                    }, function(i) {
                        401 === i.status && Object(f.repeatLogin)(function() {
                            t.submitRequest(e, s);
                        });
                    });
                },
                submitContinue: function() {
                    this.answerParams.submitStatus = 1;
                    var e = n()(this.answerParams);
                    this.submitRequest(this.answerParams, e);
                },
                handleClose: function() {
                    this.submitModal = !1;
                },
                closeCard: function() {
                    this.answerPageShow = !1;
                },
                collectExercise: function(e) {
                    0 === e ? this.collectExerciseIds.push(this.editExercise.exerciseId) : this.collectExerciseIds.splice(this.collectExerciseIds.indexOf(this.editExercise.exerciseId), 1), 
                    this.checkExerciseIsCollect();
                },
                getJob: function(e) {
                    var s = this;
                    c.default.getJobExercise({
                        examType: e
                    }, function(t) {
                        if (s.errorCode = t.data.code, 200 !== t.data.code) return s.notCheck = !1, !1;
                        s.exerciseNum = 0;
                        var i = t.data.data;
                        s.exerciseList = i.exercises.sort(function(e, s) {
                            return e.applicationCode - s.applicationCode;
                        }), s.exerciseTotal = s.exerciseList.length, s.answerParams.examType = e, s.answerParams.examinationId = i.examId, 
                        wx.setStorageSync("exerciseList", i.exercises), s.collectExerciseIds = null === i.collectExerciseId ? [] : i.collectExerciseId, 
                        s.answerParams.answers = s.exerciseList.map(function(e, t) {
                            return {
                                exerciseId: e.exerciseId,
                                type: e.exerciseType,
                                majorId: 1 === s.type || 3 === s.type ? s.majorId : e.exerciseProperty.knowledgeTags[0].split(",")[0],
                                chapterId: s.chapterId,
                                startTime: new Date().getTime(),
                                markStatus: 1,
                                answerType: 4 === s.type ? 4 : 2,
                                answer: "",
                                score: 0,
                                answerSource: Object(f.checkAnswerSource)(s.type, s.examCategory)
                            };
                        }), s.editExercise = s.exerciseList[0], s.checkChapterId(), s.checkExerciseIsCollect(), 
                        wx.setStorageSync("exerciseNum", s.exerciseNum), setTimeout(function() {
                            s.notCheck = !1, s.loading = !1;
                        }, 1e3);
                    });
                },
                handleFeedback: function() {
                    var e = this.majorId, s = this.editExercise, t = s.exerciseId, i = s.exerciseProperty;
                    _.a.commit("setFeedbackMajorId", e || i.knowledgeTags[0].split(",")[0]), _.a.commit("setFeedbackExerciseId", t), 
                    wx.navigateTo({
                        url: "/pages/feedback/main"
                    });
                },
                openHelpPage: function() {
                    wx.navigateTo({
                        url: "/pages/seekHelp/main",
                        success: function(e) {
                            console.log(e);
                        }
                    });
                }
            }
        };
    },
    DG26: function(e, s, t) {
        s.a = {
            props: [ "text", "exercise", "exerciseNum", "answerList", "errorRate" ],
            data: function() {
                return {
                    active: -1,
                    exerciseStems: null,
                    questions: [],
                    selAnswer: ""
                };
            },
            onLoad: function() {
                this.selAnswer = void 0 === this.answerList[this.exerciseNum] ? "" : this.answerList[this.exerciseNum];
            },
            watch: {
                exerciseNum: function(e, s) {
                    e !== s && (this.selAnswer = void 0 === this.answerList[e] ? "" : this.answerList[e]);
                }
            },
            methods: {
                chooseAnswer: function(e) {
                    this.selAnswer = e, this.answerList[this.exerciseNum] = e, this.$emit("change", this.answerList);
                }
            }
        };
    },
    H8QF: function(e, s, t) {
        var i = t("du8s"), a = t("wXgb"), r = t("ybqe")(i.a, a.a, function(e) {
            t("ldQh");
        }, "data-v-350d9009", null);
        s.a = r.exports;
    },
    K1Vl: function(e, s) {},
    LNAu: function(e, s, t) {
        var i = t("RCaT"), a = t("/z2E"), r = t("ybqe")(i.a, a.a, function(e) {
            t("0RoD");
        }, "data-v-28d095b8", null);
        s.a = r.exports;
    },
    Mpew: function(e, s, t) {
        s.a = {
            render: function() {
                var e = this, s = e.$createElement, t = e._self._c || s;
                return t("div", {
                    staticClass: "fast-fill"
                }, [ t("h2", [ e._v("填空题") ]), e._v(" "), t("div", {
                    staticClass: "info"
                }, [ t("div", {
                    staticClass: "pd"
                }, [ t("parser", {
                    attrs: {
                        html: e.topic,
                        mpcomid: "0"
                    }
                }) ], 1), e._v(" "), e._m(0), e._v(" "), t("div", {
                    staticClass: "upload"
                }, [ t("div", [ t("div", {
                    staticClass: "upload-btn",
                    attrs: {
                        eventid: "0"
                    },
                    on: {
                        click: e.uploadImg
                    }
                }, [ t("img", {
                    attrs: {
                        src: "//static.yanzhishi.cn/images/elec/icon/camera.png",
                        mode: "widthFix"
                    }
                }), e._v(" "), t("p", [ e._v("请在答题纸上作答"), t("br"), e._v("再拍照上传") ], 1) ], 1) ]), e._v(" "), t("p", {
                    staticClass: "input-tips"
                }, [ e._v("\n        注：请以真实考场的标准进行作答，CheeseGPT大模型将自动阅卷评分。\n      ") ]) ], 1), e._v(" "), e.picUrl ? t("div", {
                    staticClass: "analysis"
                }, [ e._m(1), e._v(" "), t("div", [ t("img", {
                    staticClass: "wd100",
                    attrs: {
                        src: e.picUrl,
                        alt: "答案",
                        mode: "widthFix"
                    }
                }) ]) ]) : e._e() ]) ], 1);
            },
            staticRenderFns: [ function() {
                var e = this.$createElement, s = this._self._c || e;
                return s("div", {
                    staticClass: "analysis"
                }, [ s("div", {
                    staticClass: "analysis-title"
                }, [ s("span", {
                    staticClass: "line"
                }), this._v("上传答案\n      ") ]) ]);
            }, function() {
                var e = this.$createElement, s = this._self._c || e;
                return s("div", {
                    staticClass: "analysis-title"
                }, [ s("span", {
                    staticClass: "line"
                }), this._v("你的答案\n      ") ]);
            } ]
        };
    },
    MzdE: function(e, s, t) {
        s.a = {
            render: function() {
                var e = this, s = e.$createElement, t = e._self._c || s;
                return t("div", {
                    class: [ "fastExercise", e.isDark && "dark" ]
                }, [ e.loading ? t("div", {
                    staticClass: "loading"
                }, [ e.notCheck ? t("img", {
                    attrs: {
                        src: e.isDark ? "//static.yanzhishi.cn/gif/loading3.gif" : "//static.yanzhishi.cn/gif/loading.gif",
                        mode: "widthFix",
                        alt: "loading"
                    }
                }) : t("block", [ t("tips-page", {
                    attrs: {
                        error: e.errorCode,
                        mpcomid: "0"
                    }
                }) ], 1) ], 1) : t("div", [ t("div", {
                    staticClass: "title"
                }, [ t("div", {
                    staticClass: "text-ellipsis"
                }, [ e._v("\n        " + e._s(e.title) + "\n      ") ]), e._v(" "), e.isShare || 4 === e.type ? e._e() : t("div", {
                    staticClass: "time"
                }, [ t("button", {
                    staticClass: "share",
                    attrs: {
                        eventid: "0"
                    },
                    on: {
                        click: e.openHelpPage
                    }
                }, [ t("img", {
                    attrs: {
                        src: "//static.yanzhishi.cn/images/wechat/qiuzhu.png",
                        mode: "widthFix",
                        alt: "help"
                    }
                }) ]), e._v(" "), t("img", {
                    staticClass: "clock",
                    attrs: {
                        src: "//static.yanzhishi.cn/images/wechat/jishi@2x.png",
                        mode: "widthFix",
                        alt: "clock"
                    }
                }), e._v(" "), t("span", [ e._v(e._s(e.time)) ]), e._v(" "), t("div", {
                    attrs: {
                        eventid: "1"
                    },
                    on: {
                        click: e.handleFeedback
                    }
                }, [ t("i-icon", {
                    attrs: {
                        type: "prompt",
                        size: "16",
                        color: "#999",
                        mpcomid: "1"
                    }
                }), e._v(" "), t("span", [ e._v("错题反馈") ]) ], 1) ], 1) ]), e._v(" "), t("div", {
                    staticClass: "gray"
                }), e._v(" "), t("div", {
                    staticClass: "tag-content"
                }, [ e.isShare ? e._e() : t("div", {
                    staticClass: "tag"
                }, [ e._v("\n        " + e._s(e.exerciseNum + 1) + "/" + e._s(e.exerciseTotal) + "\n      ") ]), e._v(" "), e.isShare ? e._e() : t("button", {
                    staticClass: "tag tag-right",
                    attrs: {
                        eventid: "2"
                    },
                    on: {
                        click: e.showAnswer
                    }
                }, [ e._v("\n        答题卡\n      ") ]), e._v(" "), t("div", {
                    staticClass: "exercise"
                }, [ 1 === e.editExercise.exerciseType ? t("fast-choice", {
                    attrs: {
                        exercise: e.editExercise,
                        exerciseNum: e.exerciseNum,
                        answerList: e.fastAnswerList,
                        errorRate: 5 === e.type,
                        examCategory: e.examCategory,
                        eventid: "3",
                        mpcomid: "2"
                    },
                    on: {
                        change: e.chooseAnswer
                    }
                }) : e._e(), e._v(" "), 2 === e.editExercise.exerciseType ? t("fast-multiple", {
                    attrs: {
                        exercise: e.editExercise,
                        exerciseNum: e.exerciseNum,
                        answerList: e.fastAnswerList,
                        errorRate: 5 === e.type,
                        examCategory: e.examCategory,
                        eventid: "4",
                        mpcomid: "3"
                    },
                    on: {
                        change: e.chooseAnswer
                    }
                }) : e._e(), e._v(" "), 3 === e.editExercise.exerciseType ? t("fast-fill", {
                    attrs: {
                        exercise: e.editExercise,
                        exerciseNum: e.exerciseNum,
                        answerList: e.fastAnswerList,
                        errorRate: 5 === e.type,
                        examCategory: e.examCategory,
                        eventid: "5",
                        mpcomid: "4"
                    },
                    on: {
                        change: e.chooseAnswer
                    }
                }) : e._e(), e._v(" "), 5 === e.editExercise.exerciseType ? t("fast-judge", {
                    attrs: {
                        exercise: e.editExercise,
                        exerciseNum: e.exerciseNum,
                        answerList: e.fastAnswerList,
                        errorRate: 5 === e.type,
                        examCategory: e.examCategory,
                        eventid: "6",
                        mpcomid: "5"
                    },
                    on: {
                        change: e.chooseAnswer
                    }
                }) : e._e(), e._v(" "), 4 === e.editExercise.exerciseType ? t("fast-short", {
                    attrs: {
                        exercise: e.editExercise,
                        exerciseNum: e.exerciseNum,
                        answerList: e.fastAnswerList,
                        errorRate: 5 === e.type,
                        examCategory: e.examCategory,
                        eventid: "7",
                        mpcomid: "6"
                    },
                    on: {
                        change: e.chooseAnswer
                    }
                }) : e._e(), e._v(" "), 7 === e.editExercise.exerciseType ? t("fast-cloze", {
                    attrs: {
                        exercise: e.editExercise,
                        exerciseNum: e.exerciseNum,
                        answerList: e.fastAnswerList,
                        errorRate: 5 === e.type,
                        examCategory: e.examCategory,
                        eventid: "8",
                        mpcomid: "7"
                    },
                    on: {
                        change: e.chooseAnswer
                    }
                }) : e._e() ], 1) ], 1), e._v(" "), e.isShare || 4 === e.type ? e._e() : t("fixed-button", {
                    attrs: {
                        status: e.status,
                        type: "collect",
                        exerciseId: e.editExercise.exerciseId,
                        majorId: e.majorId,
                        chapterId: e.chapterId,
                        collectFunc: e.collectExercise,
                        prevFunc: e.prevExercise,
                        nextFunc: e.nextExercise,
                        mpcomid: "8"
                    }
                }), e._v(" "), e.isShare || 4 !== e.type ? e._e() : t("two-button", {
                    attrs: {
                        eventid: "9",
                        mpcomid: "9"
                    },
                    on: {
                        nextFunc: e.nextExercise,
                        prevFunc: e.prevExercise
                    }
                }), e._v(" "), t("answer-page", {
                    attrs: {
                        show: e.answerPageShow,
                        showButton: !0,
                        answers: e.answerParams.answers,
                        close: e.closeCard,
                        changeView: e.changeExercise,
                        submit: e.submitAnswer,
                        mpcomid: "10"
                    }
                }), e._v(" "), t("i-modal", {
                    attrs: {
                        title: "确定提交",
                        visible: e.submitModal,
                        eventid: "10",
                        mpcomid: "11"
                    },
                    on: {
                        ok: e.submitContinue,
                        cancel: e.handleClose
                    }
                }, [ t("div", [ e._v("你还有未作答的题目") ]) ]) ], 1) ]);
            },
            staticRenderFns: []
        };
    },
    NLO5: function(e, s) {},
    "P/bp": function(e, s, t) {
        var i = t("rA5z"), a = t("Mpew"), r = t("ybqe")(i.a, a.a, function(e) {
            t("bqSY");
        }, "data-v-5c55f5f4", null);
        s.a = r.exports;
    },
    RCaT: function(e, s, t) {
        s.a = {
            props: [ "text", "exercise", "exerciseNum", "answerList", "errorRate" ],
            data: function() {
                return {
                    selAnswer: ""
                };
            },
            watch: {
                exerciseNum: function(e, s) {
                    e !== s && (this.selAnswer = void 0 === this.answerList[e] ? "" : this.answerList[e]);
                }
            },
            onLoad: function() {
                this.selAnswer = void 0 === this.answerList[this.exerciseNum] ? "" : this.answerList[this.exerciseNum];
            },
            methods: {
                chooseAnswer: function(e) {
                    this.selAnswer = e, this.answerList[this.exerciseNum] = e, this.$emit("change", this.answerList);
                }
            }
        };
    },
    RNl1: function(e, s) {},
    XBpb: function(e, s, t) {
        var i = t("wKiC"), a = t("YM+o"), r = t("ybqe")(i.a, a.a, function(e) {
            t("NLO5");
        }, "data-v-c5dd0cda", null);
        s.a = r.exports;
    },
    "YM+o": function(e, s, t) {
        s.a = {
            render: function() {
                var e = this, s = e.$createElement, t = e._self._c || s;
                return t("div", {
                    staticClass: "fast-multiple"
                }, [ t("h2", [ e._v("多选题") ]), e._v(" "), t("div", {
                    staticClass: "info"
                }, [ t("div", {
                    staticClass: "pd"
                }, [ t("parser", {
                    attrs: {
                        html: e.exercise.exerciseStems,
                        mpcomid: "0"
                    }
                }), e._v(" "), e.errorRate ? t("p", [ e._v("错误率："), t("span", {
                    staticClass: "strong"
                }, [ e._v(e._s(e.exercise.tenantCode / 100) + "%") ]) ]) : e._e() ], 1), e._v(" "), t("div", {
                    staticClass: "answer"
                }, e._l(e.exercise.questions, function(s, i) {
                    return t("block", {
                        key: i
                    }, [ t("div", {
                        class: [ "child", e.selectList[i] ? " selected" : "" ],
                        attrs: {
                            id: i,
                            eventid: "0_" + i
                        },
                        on: {
                            click: function(t) {
                                e.chooseAnswer(s, i);
                            }
                        }
                    }, [ t("div", {
                        staticClass: "check"
                    }, [ t("span", [ e._v(e._s(s.questionStem)) ]) ]), e._v(" "), t("div", {
                        staticClass: "option"
                    }, [ t("parser", {
                        attrs: {
                            html: s.questionAnswer,
                            mpcomid: "1_" + i
                        }
                    }) ], 1) ]) ]);
                })), e._v(" "), t("div", {
                    staticClass: "analysis"
                }, [ e._m(0), e._v(" "), t("p", [ e._v(e._s(e.selAnswer)) ]) ], 1) ]) ], 1);
            },
            staticRenderFns: [ function() {
                var e = this.$createElement, s = this._self._c || e;
                return s("div", {
                    staticClass: "analysis-title"
                }, [ s("span", {
                    staticClass: "line"
                }), this._v("你的答案") ]);
            } ]
        };
    },
    bqSY: function(e, s) {},
    du8s: function(e, s, t) {
        var i = t("zH01"), a = t("sGGH");
        t.n(a), s.a = {
            components: {},
            mixins: [ i.a ],
            props: {
                exercise: {
                    type: Object,
                    default: function() {}
                },
                exerciseNum: {
                    type: Number,
                    default: 1
                },
                answerList: {
                    type: Array,
                    default: function() {
                        return [];
                    }
                }
            },
            data: function() {
                return {
                    picUrl: ""
                };
            },
            onShow: function() {
                var e = wx.getStorageSync("answerImgOptions");
                wx.removeStorageSync("answerImgOptions"), e && (this.picUrl = e.img, this.sendImg(e.img, this.getFormatAnswer()));
            },
            watch: {
                exerciseNum: {
                    handler: function() {
                        this.init();
                    },
                    immediate: !0
                }
            },
            methods: {
                init: function() {
                    var e = this.answerList, s = this.exerciseNum;
                    void 0 !== e[s] ? this.picUrl = e[s] : this.picUrl = wx.getStorageSync("answerImgOptions") || "";
                }
            }
        };
    },
    k4sd: function(e, s, t) {
        var i = t("8lO0"), a = t("MzdE"), r = t("ybqe")(i.a, a.a, function(e) {
            t("K1Vl");
        }, null, null);
        s.a = r.exports;
    },
    ldQh: function(e, s) {},
    mNTj: function(e, s, t) {
        s.a = {
            render: function() {
                var e = this, s = e.$createElement, t = e._self._c || s;
                return t("div", {
                    staticClass: "fast-choice"
                }, [ t("h2", [ e._v("单选题") ]), e._v(" "), t("div", {
                    staticClass: "info"
                }, [ t("div", {
                    staticClass: "pd"
                }, [ t("parser", {
                    attrs: {
                        html: e.exercise.exerciseStems,
                        mpcomid: "0"
                    }
                }), e._v(" "), e.errorRate ? t("p", [ e._v("错误率："), t("span", {
                    staticClass: "strong"
                }, [ e._v(e._s(e.exercise.tenantCode / 100) + "%") ]) ]) : e._e() ], 1), e._v(" "), t("div", {
                    staticClass: "answer"
                }, e._l(e.exercise.questions, function(s, i) {
                    return t("block", {
                        key: i
                    }, [ t("div", {
                        class: [ "child", s.questionStem === e.selAnswer ? "selected" : "" ],
                        attrs: {
                            id: i,
                            eventid: "0_" + i
                        },
                        on: {
                            click: function(t) {
                                e.chooseAnswer(s.questionStem);
                            }
                        }
                    }, [ t("div", {
                        staticClass: "check"
                    }, [ t("span", [ e._v(e._s(s.questionStem)) ]) ]), e._v(" "), t("div", {
                        staticClass: "option"
                    }, [ t("parser", {
                        attrs: {
                            html: s.questionAnswer,
                            mpcomid: "1_" + i
                        }
                    }) ], 1) ]) ]);
                })) ]) ], 1);
            },
            staticRenderFns: []
        };
    },
    qVMU: function(e, s, t) {
        var i = t("t9im"), a = t("r+bo"), r = t("ybqe")(i.a, a.a, function(e) {
            t("uNOs");
        }, null, null);
        s.a = r.exports;
    },
    "r+bo": function(e, s, t) {
        s.a = {
            render: function() {
                var e = this, s = e.$createElement, t = e._self._c || s;
                return t("div", {
                    class: [ "fast-cloze", e.isDark && "dark" ]
                }, [ t("h2", [ e._v("完形填空") ]), e._v(" "), t("div", {
                    staticClass: "info"
                }, [ t("div", {
                    staticClass: "pd"
                }, [ t("parser", {
                    attrs: {
                        html: e.exercise.exerciseStems,
                        mpcomid: "0"
                    }
                }) ], 1), e._v(" "), t("div", {
                    staticClass: "drag-area"
                }, [ t("div", {
                    staticClass: "drag-title"
                }, [ t("div", {
                    staticClass: "title-left"
                }, [ e._v("\n          本题共" + e._s(e.questionMap.length) + "小题"), t("span", {
                    staticClass: "title-tips"
                }, [ e._v("（可左右滑动切换）") ]) ]), e._v(" "), t("div", [ t("span", {
                    staticClass: "num"
                }, [ e._v(e._s(e.questionNumber)) ]), e._v(" / " + e._s(e.questionMap.length)) ]) ]), e._v(" "), t("swiper", {
                    class: [ "drag-content", e.showAnswer && "grey" ],
                    attrs: {
                        eventid: "1"
                    },
                    on: {
                        change: e.changeSwiper
                    }
                }, e._l(e.questionMap, function(s, i) {
                    return t("swiper-item", {
                        key: i,
                        attrs: {
                            mpcomid: "2_" + i
                        }
                    }, [ t("div", {
                        staticClass: "area-checked"
                    }, e._l(s.child, function(a, r) {
                        return t("block", {
                            key: r
                        }, [ t("div", {
                            class: [ "child", a.questionStem === s.selected ? "selected" : "" ],
                            attrs: {
                                id: r,
                                eventid: "0_" + i + "-" + r
                            },
                            on: {
                                click: function(t) {
                                    e.chooseAnswer(a.questionStem, s);
                                }
                            }
                        }, [ t("div", {
                            staticClass: "check"
                        }, [ t("span", [ e._v(e._s(a.questionStem)) ]) ]), e._v(" "), t("div", {
                            staticClass: "option"
                        }, [ t("parser", {
                            attrs: {
                                html: a.questionAnswer,
                                mpcomid: "1_" + i + "-" + r
                            }
                        }) ], 1) ]) ]);
                    })) ]);
                })) ], 1) ]) ], 1);
            },
            staticRenderFns: []
        };
    },
    rA5z: function(e, s, t) {
        var i = t("zH01");
        s.a = {
            mixins: [ i.a ],
            props: {
                exercise: {
                    type: Object,
                    default: function() {}
                },
                exerciseNum: {
                    type: Number,
                    default: 1
                },
                answerList: {
                    type: Array,
                    default: function() {
                        return [];
                    }
                }
            },
            data: function() {
                return {
                    topic: "",
                    picUrl: ""
                };
            },
            onShow: function() {
                var e = wx.getStorageSync("answerImgOptions");
                wx.removeStorageSync("answerImgOptions"), e && (this.picUrl = e.img, this.sendImg(e.img, this.getFormatAnswer()));
            },
            watch: {
                exerciseNum: {
                    handler: function() {
                        this.init();
                    },
                    immediate: !0
                }
            },
            methods: {
                init: function() {
                    var e = this.answerList, s = this.exerciseNum;
                    this.topic = this.resetFill(this.exercise.exerciseStems), void 0 !== e[s] ? this.picUrl = e[s] : this.picUrl = wx.getStorageSync("answerImgOptions") || "";
                },
                resetFill: function(e) {
                    return e.replace(/\$\*\$([0-9])\$\*\$/g, function(e, s) {
                        return '<span style="text-decoration: underline;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;' + s + "&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span>";
                    });
                }
            }
        };
    },
    t9im: function(e, s, t) {
        t("onkk");
        var i = t("8e4C");
        s.a = {
            props: {
                exercise: {
                    type: Object,
                    default: function() {
                        return {
                            exerciseAnswer: "",
                            questions: [],
                            exerciseFrom: {
                                isOfficialExercise: 1
                            },
                            exerciseProperty: {
                                level: 1
                            }
                        };
                    }
                },
                exerciseNum: {
                    type: Number,
                    default: 0
                },
                answerList: {
                    type: Array,
                    default: function() {
                        return [];
                    }
                },
                errorRate: {
                    type: Boolean,
                    default: !1
                }
            },
            data: function() {
                return {
                    questionNumber: 1,
                    questionMap: [],
                    levelText: i.h,
                    isDark: wx.getStorageSync("isDark")
                };
            },
            onLoad: function() {
                this.transformDataFormat();
            },
            watch: {
                exercise: function(e, s) {
                    e != s && (this.questionNumber = 1, this.questionMap = [], this.transformDataFormat());
                }
            },
            methods: {
                transformDataFormat: function() {
                    var e = this.questionMap, s = this.exercise, t = s.questions, i = s.exerciseAnswer, a = this.answerList, r = this.exerciseNum, n = [], c = i.split(","), o = 0, l = void 0 !== a[r] ? a[r].split(",") : [];
                    t.forEach(function(s, t) {
                        1 == s.questionOrder && 0 !== t && (e.push({
                            answer: c[o],
                            selected: l.length > 0 ? l[o] : "",
                            child: n
                        }), o++, n = []), n.push(s);
                    }), e.push({
                        answer: c[o],
                        selected: l.length > 0 ? l[o] : "",
                        child: n
                    });
                },
                changeSwiper: function(e) {
                    this.questionNumber = e.mp.detail.current + 1;
                },
                chooseAnswer: function(e, s) {
                    var t = this.questionMap, i = this.answerList, a = this.exerciseNum;
                    s.selected = e, i[a] = t.map(function(e) {
                        return e.selected;
                    }).join(","), this.$emit("change", i);
                }
            }
        };
    },
    uNOs: function(e, s) {},
    wKiC: function(e, s, t) {
        s.a = {
            props: [ "text", "exercise", "exerciseNum", "answerList", "errorRate" ],
            data: function() {
                return {
                    active: -1,
                    exerciseStems: null,
                    selAnswer: "",
                    answerCollection: [],
                    selectList: []
                };
            },
            onLoad: function() {
                var e = this;
                this.selAnswer = void 0 === this.answerList[this.exerciseNum] ? "" : this.answerList[this.exerciseNum], 
                this.answerCollection = "" == this.selAnswer ? [] : this.selAnswer.split(","), this.selectList = "" == this.selAnswer ? [] : this.exercise.questions.map(function(s) {
                    return e.answerCollection.indexOf(s.questionStem) > -1;
                });
            },
            watch: {
                exerciseNum: function(e, s) {
                    var t = this;
                    e !== s && (this.selAnswer = void 0 === this.answerList[e] ? "" : this.answerList[e], 
                    this.answerCollection = "" == this.selAnswer ? [] : this.selAnswer.split(","), this.selectList = "" == this.selAnswer ? [] : this.exercise.questions.map(function(e) {
                        return t.answerCollection.indexOf(e.questionStem) > -1;
                    }));
                },
                exercise: function(e, s) {
                    e != s && (this.exercise.questions = e.questions);
                }
            },
            methods: {
                chooseAnswer: function(e, s) {
                    this.selectList[s] ? (this.selectList[s] = !1, this.answerCollection.splice(this.answerCollection.indexOf(e.questionStem), 1)) : (this.selectList[s] = !0, 
                    this.answerCollection.push(e.questionStem)), this.selAnswer = this.answerCollection.join(","), 
                    this.answerList[this.exerciseNum] = this.selAnswer, this.$emit("change", this.answerList);
                }
            }
        };
    },
    wXgb: function(e, s, t) {
        s.a = {
            render: function() {
                var e = this, s = e.$createElement, t = e._self._c || s;
                return t("div", {
                    staticClass: "fast-short"
                }, [ t("h2", [ e._v("简答题") ]), e._v(" "), t("div", {
                    staticClass: "info"
                }, [ t("div", {
                    staticClass: "pd"
                }, [ t("parser", {
                    attrs: {
                        html: e.exercise.exerciseStems,
                        mpcomid: "0"
                    }
                }) ], 1), e._v(" "), e._l(e.exercise.questions, function(s, i) {
                    return t("div", {
                        key: i
                    }, [ t("div", {
                        staticClass: "analysis"
                    }, [ t("div", {
                        staticClass: "analysis-title"
                    }, [ t("span", {
                        staticClass: "line"
                    }), e._v("问题" + e._s(i + 1) + "\n        ") ]), e._v(" "), t("parser", {
                        attrs: {
                            html: s.questionStem,
                            mpcomid: "1_" + i
                        }
                    }) ], 1) ]);
                }), e._v(" "), t("div", {
                    staticClass: "analysis"
                }, [ e._m(0), e._v(" "), t("div", {
                    staticClass: "upload"
                }, [ t("div", [ t("div", {
                    staticClass: "upload-btn",
                    attrs: {
                        eventid: "0"
                    },
                    on: {
                        click: e.uploadImg
                    }
                }, [ t("img", {
                    attrs: {
                        src: "//static.yanzhishi.cn/images/elec/icon/camera.png",
                        mode: "widthFix"
                    }
                }), e._v(" "), t("p", [ e._v("请在答题纸上作答"), t("br"), e._v("再拍照上传") ], 1) ], 1) ]), e._v(" "), t("p", {
                    staticClass: "input-tips"
                }, [ e._v("\n          注：请以真实考场的标准进行作答，CheeseGPT大模型将自动阅卷评分。\n        ") ]) ], 1) ]), e._v(" "), e.picUrl ? t("div", {
                    staticClass: "analysis"
                }, [ e._m(1), e._v(" "), t("div", [ t("img", {
                    staticClass: "wd100",
                    attrs: {
                        src: e.picUrl,
                        alt: "答案",
                        mode: "widthFix"
                    }
                }) ]) ]) : e._e() ], 2) ], 1);
            },
            staticRenderFns: [ function() {
                var e = this.$createElement, s = this._self._c || e;
                return s("div", {
                    staticClass: "analysis-title"
                }, [ s("span", {
                    staticClass: "line"
                }), this._v("上传答案\n      ") ]);
            }, function() {
                var e = this.$createElement, s = this._self._c || e;
                return s("div", {
                    staticClass: "analysis-title"
                }, [ s("span", {
                    staticClass: "line"
                }), this._v("你的答案\n      ") ]);
            } ]
        };
    },
    y08b: function(e, s, t) {
        Object.defineProperty(s, "__esModule", {
            value: !0
        });
        var i = t("5nAL"), a = t.n(i), r = t("k4sd"), n = t("RRmd"), c = (t.n(n), t("cvLP")), o = (t.n(c), 
        t("sGGH"));
        t.n(o), new a.a(r.a).$mount();
    },
    zH01: function(e, s, t) {
        var i = t("oFuF"), a = t("VsUZ");
        s.a = {
            data: function() {},
            methods: {
                getFormatAnswer: function() {
                    return this.exercise.questions.map(function(e) {
                        return e.questionAnswer.replace(/<[^>]+>/g, "").replace(/(^\s*)|(\s*$)/g, "").replace(/&nbsp;/gi, "");
                    }).join("");
                },
                uploadImg: function() {
                    wx.navigateTo({
                        url: "/pages/camera/main",
                        success: function(e) {
                            e.eventChannel.emit("params", {
                                isAnswer: !0
                            });
                        }
                    });
                },
                sendImg: function(e, s) {
                    var t = this;
                    this.exercise.exerciseProperty, a.default.upImage({
                        filePath: e
                    }, function(r) {
                        var n = JSON.parse(r.data).data.previewUrl;
                        a.default.textSimilarity({
                            filePath: e,
                            answer: s
                        }, function(e) {
                            if (401 !== e.statusCode) {
                                var s = JSON.parse(e.data), a = 200 === s.code ? s.data : 0;
                                t.$emit("change", {
                                    precent: a,
                                    userAnswer: n
                                });
                            } else Object(i.repeatLogin)(function() {
                                t.sendImg();
                            });
                        });
                    });
                }
            }
        };
    }
}, [ "y08b" ]);