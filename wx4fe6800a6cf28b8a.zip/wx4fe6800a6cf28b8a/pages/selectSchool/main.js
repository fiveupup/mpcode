require("../../common/manifest.js"), require("../../common/vendor.js"), global.webpackJsonpMpvue([ 16 ], {
    B65T: function(t, e, s) {
        var o = s("emV0"), n = s("VsUZ"), a = s("OAQQ"), i = s("u8j3"), c = (s.n(i), s("oFuF"));
        e.a = {
            components: {
                FixedBottom: o.a,
                "i-toast": a.a
            },
            data: function() {
                return {
                    schoolCollection: [],
                    selIds: [],
                    selNumber: 0,
                    isDark: wx.getStorageSync("isDark")
                };
            },
            onLoad: function() {
                var t = this;
                this.$mp.page.getOpenerEventChannel().on("params", function(e) {
                    t.selNumber = e.selNumber, t.selIds = e.selIds, t.schoolCollection = e.schoolCollection;
                }), this.isDark = Object(c.onChangeDark)();
            },
            methods: {
                chooseSchool: function(t, e) {
                    t.ext ? (this.selNumber -= 1, t.ext = !t.ext, this.selIds.splice(this.selIds.indexOf(t.id), 1)) : (this.selNumber += 1, 
                    t.ext = !t.ext, this.selIds.push(t.id));
                },
                saveSchool: function() {
                    var t = this;
                    0 !== this.selIds.length ? this.selIds.length > 3 ? Object(i.$Toast)(this, {
                        content: "童鞋不要贪多喔，最多选择三个",
                        type: "warning"
                    }) : n.default.saveUserSchool({
                        schoolId: this.selIds.join(",")
                    }, function(t) {
                        t.data.data && (getCurrentPages(), wx.navigateBack({
                            delta: 1
                        }));
                    }, function(e) {
                        401 === e.status && Object(c.repeatLogin)(function() {
                            t.saveSchool();
                        });
                    }) : Object(i.$Toast)(this, {
                        content: "请至少选择一个",
                        type: "warning"
                    });
                }
            }
        };
    },
    "Fd+D": function(t, e, s) {
        Object.defineProperty(e, "__esModule", {
            value: !0
        });
        var o = s("5nAL"), n = s.n(o), a = s("R783"), i = s("m2WG");
        s.n(i), new n.a(a.a).$mount();
    },
    R783: function(t, e, s) {
        var o = s("B65T"), n = s("x1Yn"), a = s("ybqe")(o.a, n.a, function(t) {
            s("lgAL");
        }, "data-v-45aa6627", null);
        e.a = a.exports;
    },
    lgAL: function(t, e) {},
    x1Yn: function(t, e, s) {
        e.a = {
            render: function() {
                var t = this, e = t.$createElement, s = t._self._c || e;
                return s("div", {
                    class: [ "sel-school", t.isDark && "dark" ]
                }, [ s("div", {
                    staticClass: "school-title"
                }, [ s("div", [ t._v("我关注的院校") ]), t._v(" "), s("p", {
                    staticClass: "school-title-info"
                }, [ t._v("\n      （最多可选择三个，更多院校持续发布中...）\n    ") ]) ], 1), t._v(" "), s("div", {
                    staticClass: "school-tag-box"
                }, t._l(t.schoolCollection, function(e, o) {
                    return s("div", {
                        key: o,
                        class: [ "school-tag", !0 === e.ext ? "school-tag-on" : "" ],
                        attrs: {
                            eventid: "0_" + o
                        },
                        on: {
                            click: function(s) {
                                t.chooseSchool(e, o);
                            }
                        }
                    }, [ t._v("\n      " + t._s(e.name) + "\n    ") ]);
                })), t._v(" "), s("i-toast", {
                    ref: "toast",
                    attrs: {
                        mpcomid: "0"
                    }
                }), t._v(" "), s("fixed-bottom", {
                    attrs: {
                        text: "保存",
                        clickBtn: t.saveSchool,
                        mpcomid: "1"
                    }
                }) ], 1);
            },
            staticRenderFns: []
        };
    }
}, [ "Fd+D" ]);