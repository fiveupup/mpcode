require("../../common/manifest.js"), require("../../common/vendor.js"), global.webpackJsonpMpvue([ 41 ], {
    GYqI: function(e, t, a) {
        var s = a("yzH3"), o = a("qyV9"), i = a("ybqe")(s.a, o.a, function(e) {
            a("HSwa");
        }, "data-v-39832b7a", null);
        t.a = i.exports;
    },
    HSwa: function(e, t) {},
    Y1WE: function(e, t, a) {
        Object.defineProperty(t, "__esModule", {
            value: !0
        });
        var s = a("GYqI"), o = a("5nAL"), i = a.n(o), r = a("m2WG");
        a.n(r), new i.a(s.a).$mount();
    },
    qyV9: function(e, t, a) {
        t.a = {
            render: function() {
                var e = this, t = e.$createElement, a = e._self._c || t;
                return a("div", {
                    class: [ "collect-detail", e.isDark && "dark" ]
                }, [ e.empty ? a("div", {
                    staticClass: "error"
                }, [ a("tips-page", {
                    attrs: {
                        error: e.errorCode,
                        mpcomid: "0"
                    }
                }) ], 1) : a("block", [ a("div", {
                    staticClass: "tag-content"
                }, [ a("div", {
                    staticClass: "tag"
                }, [ e._v(e._s(e.pageNum) + "/" + e._s(e.pagesTotal)) ]) ]), e._v(" "), a("div", {
                    staticClass: "content"
                }, [ 1 === e.edit.exerciseType ? a("analysis-choice", {
                    attrs: {
                        exercise: e.edit,
                        showUserAnswer: !1,
                        showNote: !0,
                        majorId: e.majorId,
                        eventid: "0",
                        mpcomid: "1"
                    },
                    on: {
                        refreshData: e.getRecord
                    }
                }) : e._e(), e._v(" "), 2 === e.edit.exerciseType ? a("analysis-multiple", {
                    attrs: {
                        exercise: e.edit,
                        showUserAnswer: !1,
                        showNote: !0,
                        majorId: e.majorId,
                        eventid: "1",
                        mpcomid: "2"
                    },
                    on: {
                        refreshData: e.getRecord
                    }
                }) : e._e(), e._v(" "), 3 === e.edit.exerciseType ? a("analysis-fill", {
                    attrs: {
                        exercise: e.edit,
                        showUserAnswer: !1,
                        showNote: !0,
                        majorId: e.majorId,
                        eventid: "2",
                        mpcomid: "3"
                    },
                    on: {
                        refreshData: e.getRecord
                    }
                }) : e._e(), e._v(" "), 5 === e.edit.exerciseType ? a("analysis-judge", {
                    attrs: {
                        exercise: e.edit,
                        showUserAnswer: !1,
                        showNote: !0,
                        majorId: e.majorId,
                        eventid: "3",
                        mpcomid: "4"
                    },
                    on: {
                        refreshData: e.getRecord
                    }
                }) : e._e(), e._v(" "), 4 === e.edit.exerciseType ? a("analysis-short", {
                    attrs: {
                        exercise: e.edit,
                        showUserAnswer: !1,
                        showNote: !0,
                        majorId: e.majorId,
                        eventid: "4",
                        mpcomid: "5"
                    },
                    on: {
                        refreshData: e.getRecord
                    }
                }) : e._e(), e._v(" "), 7 === e.edit.exerciseType ? a("analysis-cloze", {
                    attrs: {
                        exercise: e.edit,
                        showUserAnswer: !1,
                        showNote: !0,
                        majorId: e.majorId,
                        eventid: "5",
                        mpcomid: "6"
                    },
                    on: {
                        refreshData: e.getRecord
                    }
                }) : e._e() ], 1), e._v(" "), a("i-toast", {
                    ref: "toast",
                    attrs: {
                        mpcomid: "7"
                    }
                }), e._v(" "), a("fixed-button", {
                    attrs: {
                        status: e.status,
                        type: "collect",
                        exerciseId: e.edit.exerciseId,
                        majorId: e.majorId,
                        collectFunc: e.collectExercise,
                        prevFunc: e.prevExercise,
                        nextFunc: e.nextExercise,
                        mpcomid: "8"
                    }
                }) ], 1) ], 1);
            },
            staticRenderFns: []
        };
    },
    yzH3: function(e, t, a) {
        var s = a("VsUZ"), o = a("x0F5"), i = a("eeHf"), r = a("19G0"), n = a("C2pC"), c = a("D04a"), d = a("epAQ"), l = a("LGpd"), m = a("tXM+"), p = a("oFuF"), g = a("OAQQ"), u = a("u8j3"), h = (a.n(u), 
        a("IcnI"));
        t.a = {
            components: {
                AnalysisChoice: o.a,
                AnalysisMultiple: i.a,
                AnalysisFill: r.a,
                AnalysisJudge: n.a,
                AnalysisShort: c.a,
                AnalysisCloze: d.a,
                FixedButton: l.a,
                iToast: g.a,
                TipsPage: m.a
            },
            data: function() {
                return {
                    edit: void 0,
                    userAnswer: void 0,
                    params: null,
                    touchDot: 0,
                    tmpFlag: !0,
                    text: "下一题",
                    time: 0,
                    interval: null,
                    pageNum: 1,
                    pagesTotal: 1,
                    status: 0,
                    majorId: null,
                    dateFlag: null,
                    empty: !1,
                    errorCode: 200,
                    examCategory: 1,
                    isDark: wx.getStorageSync("isDark")
                };
            },
            onLoad: function() {
                var e = this;
                this.tmpFlag = !0, this.empty = !1, this.$mp.page.getOpenerEventChannel().on("params", function(t) {
                    h.a.commit("setExamCategory", t.examCategory), e.edit = JSON.parse(t.exercise), 
                    e.pageNum = t.pageNum, e.pagesTotal = t.pagesTotal, e.majorId = t.majorId, e.dateFlag = t.dateFlag, 
                    e.examCategory = t.examCategory, e.getRecord();
                }), this.isDark = Object(p.onChangeDark)();
            },
            methods: {
                getRecord: function() {
                    var e = this, t = this.majorId, a = this.pageNum, o = this.dateFlag, i = this.examCategory;
                    s.default.getCollectExercise({
                        majorId: t,
                        pageNum: a,
                        pageSize: 1,
                        dateFlag: o,
                        examCategory: i
                    }, function(t) {
                        e.edit = t.data.data.list[0], e.pagesTotal = t.data.data.total, e.collectListIds.indexOf(e.edit.exerciseId) < 0 && e.collectListIds.push(e.edit.exerciseId);
                    }, function(t) {
                        401 === t.status && Object(p.repeatLogin)(function() {
                            e.getRecord();
                        });
                    }, !1);
                },
                collectExercise: function(e) {
                    var t = this, a = getCurrentPages();
                    a[2].onLoad(this.pageNum - 1), a[1].onLoad(), this.pageNum > 1 && (this.pageNum -= 1), 
                    this.pagesTotal -= 1, 0 === this.pagesTotal && (this.errorCode = 4114, setTimeout(function() {
                        t.empty = !0;
                    }, 200)), this.getRecord();
                },
                nextExercise: function() {
                    this.pageNum < this.pagesTotal ? (this.pageNum += 1, this.getRecord()) : Object(u.$Toast)(this, {
                        content: "已经是最后一题了哦",
                        type: "warning"
                    });
                },
                prevExercise: function() {
                    this.pageNum > 1 ? (this.pageNum -= 1, this.getRecord()) : Object(u.$Toast)(this, {
                        content: "已经是第一题了哦",
                        type: "warning"
                    });
                }
            }
        };
    }
}, [ "Y1WE" ]);