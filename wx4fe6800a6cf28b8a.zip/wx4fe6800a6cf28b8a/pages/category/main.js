require("../../common/manifest.js"), require("../../common/vendor.js"), global.webpackJsonpMpvue([ 43 ], {
    AWzI: function(e, t, a) {
        var n = a("IUyo"), o = a("qfup"), c = a("ybqe")(n.a, o.a, function(e) {
            a("FHg3");
        }, "data-v-09920015", null);
        t.a = c.exports;
    },
    FHg3: function(e, t) {},
    IUyo: function(e, t, a) {
        var n = a("8e4C"), o = a("oFuF"), c = a("VsUZ"), i = a("IcnI");
        t.a = {
            data: function() {
                return {
                    category: n.b,
                    isDark: wx.getStorageSync("isDark")
                };
            },
            onShow: function() {
                this.getMajorList(), this.isDark = Object(o.onChangeDark)();
            },
            methods: {
                getMajorList: function() {
                    var e = this;
                    this.categoryNormal, this.categoryExam, c.default.getMajorCustomList({}, function(t) {
                        t.data.data.forEach(function(t) {
                            e.category.forEach(function(e) {
                                e.children.map(function(e) {
                                    t.majorId == e.id && t.examCategory == e.examCategory && (e.isChecked = !0);
                                });
                            });
                        });
                    });
                },
                changeIcon: Object(o.debounce)(function(e) {
                    Object(o.judgeLogin)().then(function() {
                        "" != e.id ? (e.isChecked = !e.isChecked, i.a.commit("setFixedSubjectFlag", !0), 
                        e.isChecked ? c.default.addMajor({
                            majorId: e.id,
                            majorName: e.name,
                            examCategory: e.examCategory
                        }, function(e) {
                            console.log(e);
                        }) : c.default.deleteMajor({
                            majorId: e.id,
                            majorName: e.name,
                            examCategory: e.examCategory
                        }, function(e) {
                            console.log(e);
                        })) : wx.showToast({
                            title: "当前科目尚未开放",
                            icon: "none",
                            duration: 2e3
                        });
                    });
                })
            }
        };
    },
    UTUY: function(e, t, a) {
        Object.defineProperty(t, "__esModule", {
            value: !0
        });
        var n = a("AWzI"), o = a("5nAL");
        new (a.n(o).a)(n.a).$mount();
    },
    qfup: function(e, t, a) {
        t.a = {
            render: function() {
                var e = this, t = e.$createElement, a = e._self._c || t;
                return a("div", {
                    class: [ "category-page", e.isDark && "dark" ]
                }, [ e._l(e.category, function(t, n) {
                    return a("div", {
                        key: n
                    }, [ a("h3", [ e._v(e._s(t.name)) ]), e._v(" "), a("div", {
                        staticClass: "content"
                    }, e._l(t.children, function(t, o) {
                        return a("div", {
                            key: o
                        }, [ a("div", {
                            class: [ "card", t.isChecked && "checked", "" === t.id && "gray" ],
                            attrs: {
                                eventid: "0_" + n + "-" + o
                            },
                            on: {
                                click: function(a) {
                                    e.changeIcon(t);
                                }
                            }
                        }, [ a("div", {
                            staticClass: "icon-box"
                        }, [ a("img", {
                            attrs: {
                                src: t.isChecked ? t.darkIcon : t.whiteIcon,
                                alt: ""
                            }
                        }) ]), e._v(" "), a("div", {
                            staticClass: "card-text"
                        }, [ a("p", [ e._v(e._s(t.name)) ]) ], 1) ]) ]);
                    })) ], 1);
                }), e._v(" "), a("p", {
                    staticClass: "tips"
                }, [ e._v("\n    点击选中即保存，再次点击则取消"), a("br"), e._v("选中顺序就是首页展示顺序\n  ") ], 1) ], 2);
            },
            staticRenderFns: []
        };
    }
}, [ "UTUY" ]);