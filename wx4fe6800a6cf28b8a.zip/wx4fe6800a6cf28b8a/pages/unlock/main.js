require("../../common/manifest.js"), require("../../common/vendor.js"), global.webpackJsonpMpvue([ 11 ], {
    "Cx0/": function(t, e, n) {
        var a = n("gbBJ"), s = n("ELEm"), i = n("ybqe")(a.a, s.a, function(t) {
            n("In8G");
        }, "data-v-2047b1db", null);
        e.a = i.exports;
    },
    ELEm: function(t, e, n) {
        e.a = {
            render: function() {
                var t = this.$createElement, e = this._self._c || t;
                return e("div", {
                    staticClass: "unlock"
                }, [ e("img", {
                    staticClass: "width-full",
                    attrs: {
                        src: "http://static.yanzhishi.cn/images/wechat/personal/unlock.jpeg",
                        alt: "unlock",
                        mode: "widthFix"
                    }
                }), this._v(" "), e("div", {
                    staticClass: "btn"
                }, [ e("button", {
                    attrs: {
                        "open-type": "contact"
                    }
                }, [ this._v("\n      立即解锁\n    ") ]), this._v(" "), e("div", {
                    staticClass: "share-jump",
                    attrs: {
                        eventid: "0"
                    },
                    on: {
                        click: this.jumpShare
                    }
                }, [ this._v("\n      或分享好友免费解锁 >\n    ") ]) ], 1) ]);
            },
            staticRenderFns: []
        };
    },
    In8G: function(t, e) {},
    gbBJ: function(t, e, n) {
        var a = n("VsUZ");
        e.a = {
            methods: {
                getPhoneNumber: function(t) {
                    if ("getPhoneNumber:ok" === t.target.errMsg) {
                        var e = t.mp.detail, n = e.encryptedData, a = e.iv;
                        this.addUserPhone(this.userCode, n, a);
                    }
                },
                addUserPhone: function(t, e, n) {
                    var s = this;
                    a.default.addUserPhone({
                        code: t,
                        encryptedData: e,
                        iv: n
                    }, function(t) {
                        if (t.data.data) ; else {
                            var a = s;
                            wx.login({
                                success: function(t) {
                                    a.addUserPhone(t.code, e, n);
                                }
                            });
                        }
                    }, function(t) {
                        console.log(t);
                    });
                },
                jumpShare: function() {
                    wx.navigateTo({
                        url: "/pages/share/main"
                    });
                }
            }
        };
    },
    z6cF: function(t, e, n) {
        Object.defineProperty(e, "__esModule", {
            value: !0
        });
        var a = n("5nAL"), s = n.n(a), i = n("Cx0/");
        new s.a(i.a).$mount();
    }
}, [ "z6cF" ]);