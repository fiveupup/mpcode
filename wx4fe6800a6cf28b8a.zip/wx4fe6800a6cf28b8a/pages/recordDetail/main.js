require("../../common/manifest.js"), require("../../common/vendor.js"), global.webpackJsonpMpvue([ 20 ], {
    "DQ/K": function(e, s, t) {
        var i = t("oFuF"), r = t("x0F5"), a = t("eeHf"), n = t("19G0"), c = t("epAQ"), o = t("C2pC"), m = t("D04a"), d = t("pWcx"), x = t("LGpd"), u = t("VsUZ"), h = t("OAQQ"), w = t("u8j3"), l = (t.n(w), 
        t("IcnI"));
        s.a = {
            components: {
                AnalysisChoice: r.a,
                AnalysisMultiple: a.a,
                AnalysisFill: n.a,
                AnalysisJudge: o.a,
                AnalysisShort: m.a,
                AnalysisCloze: c.a,
                AnswerPage: d.a,
                FixedButton: x.a,
                iToast: h.a
            },
            data: function() {
                return {
                    examRecordId: null,
                    title: "",
                    exerciseList: [],
                    current: 0,
                    edit: {
                        exerciseId: null
                    },
                    nowListItem: {
                        majorId: null,
                        chapterId: null
                    },
                    userAnswer: void 0,
                    answerPageShow: !1,
                    answers: [],
                    status: 0,
                    examType: 1,
                    examCategory: 1,
                    isDark: wx.getStorageSync("isDark")
                };
            },
            computed: {
                exerciseNumber: function() {
                    return l.a.state.record.exerciseNum;
                }
            },
            onLoad: function() {
                var e = this;
                this.isDark = Object(i.onChangeDark)(), this.answerPageShow = !1, wx.setStorageSync("exerciseNum", 0), 
                this.$mp.page.getOpenerEventChannel().on("params", function(s) {
                    e.examRecordId = s.examRecordId, e.examType = s.examType, e.title = s.examRecordName, 
                    e.getRecord();
                });
            },
            onShow: function() {
                this.exerciseList.length > 0 && this.refreshData();
            },
            methods: {
                refreshData: function() {
                    if (this.edit = this.exerciseList[this.exerciseNumber].exercise, this.nowListItem = this.exerciseList[this.exerciseNumber], 
                    this.userAnswer = {
                        answer: this.exerciseList[this.exerciseNumber].answer,
                        answerType: this.exerciseList[this.exerciseNumber].answerType,
                        score: this.exerciseList[this.exerciseNumber].score
                    }, this.status = 0 === this.nowListItem.isCollectExercise ? 0 : 1, 1 === this.examType || 4 === this.examType) {
                        var e = this.edit.exerciseProperty.knowledgeTags[0].split(",");
                        this.nowListItem.majorId = e[0], this.nowListItem.chapterId = e[1];
                    }
                },
                getRecord: function() {
                    var e = this, s = this.examType, t = {
                        examRecordId: this.examRecordId,
                        examCategory: 1
                    };
                    [ 9, 10 ].indexOf(s) > -1 ? t.examCategory = 2 : [ 11, 12 ].indexOf(s) > -1 ? t.examCategory = 3 : [ 13, 14 ].indexOf(s) > -1 && (t.examCategory = 4), 
                    this.examCategory = t.examCategory, l.a.commit("setExamCategory", t.examCategory), 
                    u.default.getExerciseRecordList(t, function(s) {
                        if (e.exerciseList = s.data.data, e.edit = e.exerciseList[0].exercise, e.nowListItem = e.exerciseList[0], 
                        e.status = 0 === e.nowListItem.isCollectExercise ? 0 : 1, e.userAnswer = {
                            answer: e.exerciseList[0].answer,
                            answerType: e.exerciseList[0].answerType
                        }, 1 === e.examType) {
                            var t = e.edit.exerciseProperty.knowledgeTags[0].split(",");
                            e.nowListItem.majorId = t[0], e.nowListItem.chapterId = t[1];
                        }
                    }, function(s) {
                        401 === s.status && Object(i.repeatLogin)(function() {
                            e.getRecord();
                        });
                    });
                },
                getUserAnswer: function(e) {
                    return {
                        answer: e.answer,
                        answerType: e.answerType
                    };
                },
                changeSwiper: function(e) {
                    this.current = e.mp.detail.current, wx.setStorageSync("exerciseNum", this.current);
                },
                closeCard: function() {
                    this.answerPageShow = !1;
                },
                viewAnswer: function() {
                    this.answerPageShow = !0;
                },
                changeExercise: function(e) {
                    l.a.commit("setExerciseNum", e), this.refreshData(), this.answerPageShow = !1;
                },
                collectExercise: function(e) {
                    this.status = e, this.exerciseList[this.exerciseNumber].isCollectExercise = e;
                },
                nextExercise: function() {
                    this.exerciseNumber < this.exerciseList.length - 1 ? (l.a.commit("setExerciseNum", this.exerciseNumber + 1), 
                    this.refreshData()) : Object(w.$Toast)(this, {
                        content: "已经是最后一题了哦",
                        type: "warning"
                    });
                },
                prevExercise: function() {
                    this.exerciseNumber > 0 ? (l.a.commit("setExerciseNum", this.exerciseNumber - 1), 
                    this.refreshData()) : Object(w.$Toast)(this, {
                        content: "已经是第一题了哦",
                        type: "warning"
                    });
                }
            }
        };
    },
    "G/jq": function(e, s, t) {
        Object.defineProperty(s, "__esModule", {
            value: !0
        });
        var i = t("5nAL"), r = t.n(i), a = t("gqX4"), n = t("m2WG");
        t.n(n), new r.a(a.a).$mount();
    },
    XBp6: function(e, s, t) {
        s.a = {
            render: function() {
                var e = this, s = e.$createElement, t = e._self._c || s;
                return t("div", {
                    class: [ "record-detail", e.isDark && "dark" ]
                }, [ t("div", {
                    staticClass: "title"
                }, [ t("span", [ e._v(e._s(e.title)) ]) ]), e._v(" "), t("div", {
                    staticClass: "tag-content"
                }, [ t("div", {
                    staticClass: "tag"
                }, [ e._v("\n      " + e._s(e.exerciseNumber + 1) + "/" + e._s(e.exerciseList.length) + "\n    ") ]), e._v(" "), t("button", {
                    staticClass: "tag tag-right",
                    attrs: {
                        eventid: "0"
                    },
                    on: {
                        click: e.viewAnswer
                    }
                }, [ e._v("\n      答题卡\n    ") ]) ], 1), e._v(" "), e.edit && 1 === e.edit.exerciseType ? t("analysis-choice", {
                    attrs: {
                        exercise: e.edit,
                        userAnswer: e.userAnswer,
                        majorId: e.nowListItem.majorId,
                        mpcomid: "0"
                    }
                }) : e._e(), e._v(" "), e.edit && 2 === e.edit.exerciseType ? t("analysis-multiple", {
                    attrs: {
                        exercise: e.edit,
                        userAnswer: e.userAnswer,
                        majorId: e.nowListItem.majorId,
                        mpcomid: "1"
                    }
                }) : e._e(), e._v(" "), e.edit && 3 === e.edit.exerciseType ? t("analysis-fill", {
                    attrs: {
                        exercise: e.edit,
                        userAnswer: e.userAnswer,
                        majorId: e.nowListItem.majorId,
                        mpcomid: "2"
                    }
                }) : e._e(), e._v(" "), e.edit && 5 === e.edit.exerciseType ? t("analysis-judge", {
                    attrs: {
                        exercise: e.edit,
                        userAnswer: e.userAnswer,
                        majorId: e.nowListItem.majorId,
                        mpcomid: "3"
                    }
                }) : e._e(), e._v(" "), e.edit && 4 === e.edit.exerciseType ? t("analysis-short", {
                    attrs: {
                        exercise: e.edit,
                        userAnswer: e.userAnswer,
                        majorId: e.nowListItem.majorId,
                        mpcomid: "4"
                    }
                }) : e._e(), e._v(" "), e.edit && 7 === e.edit.exerciseType ? t("analysis-cloze", {
                    attrs: {
                        exercise: e.edit,
                        userAnswer: e.userAnswer,
                        majorId: e.nowListItem.majorId,
                        mpcomid: "5"
                    }
                }) : e._e(), e._v(" "), t("answer-page", {
                    attrs: {
                        show: e.answerPageShow,
                        analysis: !0,
                        answers: e.exerciseList,
                        close: e.closeCard,
                        changeView: e.changeExercise,
                        mpcomid: "6"
                    }
                }), e._v(" "), t("i-toast", {
                    ref: "toast",
                    attrs: {
                        mpcomid: "7"
                    }
                }), e._v(" "), t("fixed-button", {
                    attrs: {
                        exerciseId: e.edit.exerciseId,
                        status: e.status,
                        majorId: e.nowListItem.majorId,
                        chapterId: e.nowListItem.chapterId,
                        collectFunc: e.collectExercise,
                        prevFunc: e.prevExercise,
                        nextFunc: e.nextExercise,
                        mpcomid: "8"
                    }
                }) ], 1);
            },
            staticRenderFns: []
        };
    },
    gqX4: function(e, s, t) {
        var i = t("DQ/K"), r = t("XBp6"), a = t("ybqe")(i.a, r.a, function(e) {
            t("xTDW");
        }, null, null);
        s.a = a.exports;
    },
    xTDW: function(e, s) {}
}, [ "G/jq" ]);