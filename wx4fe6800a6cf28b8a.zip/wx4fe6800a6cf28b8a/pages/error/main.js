require("../../common/manifest.js"), require("../../common/vendor.js"), global.webpackJsonpMpvue([ 37 ], {
    "6RtG": function(n, e, t) {
        e.a = {
            render: function() {
                var n = this.$createElement, e = this._self._c || n;
                return e("div", {
                    class: [ "http-error", this.isDark && "dark" ]
                }, [ e("tips-page", {
                    attrs: {
                        error: 500,
                        mpcomid: "0"
                    }
                }) ], 1);
            },
            staticRenderFns: []
        };
    },
    LSCv: function(n, e, t) {
        var a = t("tXM+"), r = t("oFuF");
        e.a = {
            components: {
                TipsPage: a.a
            },
            data: function() {
                return {
                    isDark: wx.getStorageSync("isDark")
                };
            },
            onLoad: function() {
                this.isDark = Object(r.onChangeDark)();
            },
            onUnload: function() {
                wx.switchTab({
                    url: "/pages/newIndex/main"
                });
            }
        };
    },
    MQKU: function(n, e) {},
    MfLD: function(n, e, t) {
        Object.defineProperty(e, "__esModule", {
            value: !0
        });
        var a = t("5nAL"), r = t.n(a), o = t("XyP8"), i = t("sGGH");
        t.n(i), new r.a(o.a).$mount();
    },
    XyP8: function(n, e, t) {
        var a = t("LSCv"), r = t("6RtG"), o = t("ybqe")(a.a, r.a, function(n) {
            t("MQKU");
        }, "data-v-3526c1b2", null);
        e.a = o.exports;
    }
}, [ "MfLD" ]);