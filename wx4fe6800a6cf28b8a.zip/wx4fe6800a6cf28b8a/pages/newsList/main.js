require("../../common/manifest.js"), require("../../common/vendor.js"), global.webpackJsonpMpvue([ 26 ], {
    "2Efb": function(t, e, n) {
        e.a = {
            render: function() {
                var t = this.$createElement, e = this._self._c || t;
                return e("div", {
                    class: [ "news-list", this.isDark && "dark" ]
                }, [ e("ArticleList", {
                    attrs: {
                        showTop: "",
                        dataSource: this.newsList,
                        mpcomid: "0"
                    }
                }) ], 1);
            },
            staticRenderFns: []
        };
    },
    "87wa": function(t, e, n) {
        var a = n("xmTG"), i = n("2Efb"), r = n("ybqe")(a.a, i.a, function(t) {
            n("cI3j");
        }, "data-v-02f75568", null);
        e.a = r.exports;
    },
    WvER: function(t, e, n) {
        Object.defineProperty(e, "__esModule", {
            value: !0
        });
        var a = n("5nAL"), i = n.n(a), r = n("87wa");
        new i.a(r.a).$mount();
    },
    cI3j: function(t, e) {},
    xmTG: function(t, e, n) {
        var a = n("VfqU"), i = n("VsUZ"), r = n("8e4C"), s = n("oFuF");
        e.a = {
            components: {
                ArticleList: a.a
            },
            data: function() {
                return {
                    newsList: [],
                    isDark: wx.getStorageSync("isDark")
                };
            },
            onLoad: function() {
                var t = this;
                this.isDark = Object(s.onChangeDark)(), this.$mp.page.getOpenerEventChannel().on("params", function(e) {
                    var n = e.articleType;
                    wx.setNavigationBarTitle({
                        title: r.i.find(function(t) {
                            return t.value === n;
                        }).title
                    }), t.getData(n);
                });
            },
            methods: {
                getData: function(t) {
                    var e = this;
                    i.default.getArticleList({
                        articleType: t
                    }, function(t) {
                        e.newsList = t.data.sort(function(t, e) {
                            return t.articleSort - e.articleSort;
                        });
                    });
                }
            }
        };
    }
}, [ "WvER" ]);