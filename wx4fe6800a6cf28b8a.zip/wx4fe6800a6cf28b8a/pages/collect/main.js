require("../../common/manifest.js"), require("../../common/vendor.js"), global.webpackJsonpMpvue([ 42 ], {
    FXDs: function(e, t, a) {
        t.a = {
            render: function() {
                var e = this, t = e.$createElement, a = e._self._c || t;
                return a("div", {
                    class: [ "collect", e.isDark && "dark" ]
                }, [ a("div", {
                    staticClass: "tab-myself"
                }, [ a("i-tabs", {
                    attrs: {
                        "i-class": "title-content",
                        scroll: "true",
                        eventid: "0",
                        mpcomid: "1"
                    },
                    on: {
                        change: e.handleChangeScroll
                    },
                    model: {
                        value: e.current,
                        callback: function(t) {
                            e.current = t;
                        },
                        expression: "current"
                    }
                }, e._l(e.subject, function(e, t) {
                    return a("i-tab", {
                        key: t,
                        attrs: {
                            "item-key": t,
                            title: e.name,
                            mpcomid: "0_" + t
                        }
                    });
                })) ], 1), e._v(" "), e.notCheck ? a("div", {
                    staticClass: "error-box"
                }, [ a("tips-page", {
                    attrs: {
                        error: e.errorCode,
                        mpcomid: "2"
                    }
                }) ], 1) : a("block", [ a("div", {
                    staticClass: "question-list"
                }, e._l(e.collectList, function(t, i) {
                    return a("block", {
                        key: i
                    }, [ a("div", {
                        class: [ "question-list-item", 0 !== i ? "list-line" : "" ],
                        attrs: {
                            eventid: "1_" + i
                        },
                        on: {
                            click: function(a) {
                                e.chooseExercise(t, i);
                            }
                        }
                    }, [ 3 !== t.exerciseType ? a("mistake-choice", {
                        attrs: {
                            exercise: t,
                            showTip: !1,
                            fromSource: e.handleSource(t),
                            mpcomid: "3_" + i
                        }
                    }) : e._e(), e._v(" "), 3 === t.exerciseType ? a("mistake-fill", {
                        attrs: {
                            exercise: t,
                            showTip: !1,
                            fromSource: e.handleSource(t),
                            mpcomid: "4_" + i
                        }
                    }) : e._e() ], 1) ]);
                })), e._v(" "), e.more ? a("p", {
                    staticClass: "more"
                }, [ e._v("加载更多") ]) : e._e(), e._v(" "), a("fixed-bottom", {
                    attrs: {
                        text: "重做",
                        clickBtn: e.goExerciseAgainPage,
                        mpcomid: "5"
                    }
                }) ], 1) ], 1);
            },
            staticRenderFns: []
        };
    },
    "Fc/C": function(e, t, a) {
        var i = a("L2Ia"), s = a("FXDs"), c = a("ybqe")(i.a, s.a, function(e) {
            a("ZNU+");
        }, null, null);
        t.a = c.exports;
    },
    L2Ia: function(e, t, a) {
        var i = a("mvHQ"), s = a.n(i), c = a("WvcL"), o = a("3waA"), r = (a("8e4C"), a("emV0")), n = a("xiLG"), l = a("+7ER"), u = a("VsUZ"), m = a("tXM+"), h = a("oFuF"), g = a("IcnI");
        t.a = {
            components: {
                "i-tabs": c.a,
                "i-tab": o.a,
                FixedBottom: r.a,
                MistakeChoice: n.a,
                MistakeFill: l.a,
                TipsPage: m.a
            },
            data: function() {
                return {
                    collectList: [],
                    pageNum: 0,
                    pagesTotal: 1,
                    more: !1,
                    notCheck: !0,
                    errorCode: "",
                    exerciseTotal: null,
                    isClick: !1,
                    dateFlag: null,
                    chapterList: [],
                    isDark: wx.getStorageSync("isDark")
                };
            },
            computed: {
                subject: function() {
                    return g.a.state.subjectList;
                },
                current: {
                    get: function() {
                        return g.a.state.mistakeCurrent;
                    },
                    set: function(e) {
                        g.a.commit("setMistakeCurrent", e);
                    }
                }
            },
            onLoad: function(e) {
                !isNaN(e) && e < this.collectList.length ? (this.collectList.splice(e, 1), 0 === this.collectList.length && (this.notCheck = !0, 
                this.errorCode = 4114)) : this.collectList = [], this.isDark = Object(h.onChangeDark)();
            },
            onShow: function() {
                var e = this;
                this.$mp.page.getOpenerEventChannel().on("params", function(t) {
                    e.dateFlag = t.dateFlag, e.pageNum = 0, e.pagesTotal = 1, e.recordList = [], e.pageNum < e.pagesTotal && (e.pageNum += 1, 
                    e.getCollectExercise(), e.getChapter());
                });
            },
            onReachBottom: function() {
                this.pageNum < this.pagesTotal ? (this.pageNum += 1, this.getCollectExercise()) : this.more = !1;
            },
            methods: {
                getCollectExercise: function() {
                    var e = this, t = this.subject, a = this.current, i = this.pageNum, s = this.dateFlag;
                    u.default.getCollectExercise({
                        majorId: t[a].id,
                        pageNum: i,
                        pageSize: 10,
                        dateFlag: s,
                        sort: "create_date",
                        examCategory: t[a].examCategory
                    }, function(t) {
                        if (e.errorCode = t.data.code, 200 !== t.data.code) return e.notCheck = !0, !1;
                        e.notCheck = !1, e.pagesTotal = t.data.data.pages, e.exerciseTotal = t.data.data.total, 
                        1 == e.pageNum ? e.collectList = t.data.data.list : e.pageNum <= e.pagesTotal && (e.collectList = e.collectList.concat(t.data.data.list)), 
                        e.pageNum < e.pagesTotal && (e.more = !0);
                    }, function(t) {
                        401 === t.status && Object(h.repeatLogin)(function() {
                            e.getCollectExercise();
                        });
                    });
                },
                handleChangeScroll: function(e) {
                    this.collectList = [], this.current = e, this.pageNum = 1, this.more = !1, this.getCollectExercise(), 
                    this.getChapter();
                },
                chooseExercise: function(e, t) {
                    var a = this, i = this.exerciseTotal, c = this.current, o = this.dateFlag, r = this.subject;
                    this.isClick || (this.isClick = !0, wx.navigateTo({
                        url: "/pages/collectDetail/main",
                        success: function(n) {
                            n.eventChannel.emit("params", {
                                exercise: s()(e),
                                pageNum: t + 1,
                                pagesTotal: i,
                                majorId: r[c].id,
                                dateFlag: o,
                                examCategory: r[c].examCategory
                            }), setTimeout(function() {
                                a.isClick = !1;
                            }, 1e3);
                        }
                    }));
                },
                goExerciseAgainPage: function() {
                    var e = this.dateFlag, t = this.current, a = this.subject;
                    wx.navigateTo({
                        url: "/pages/exerciseAgain/main",
                        success: function(i) {
                            i.eventChannel.emit("params", {
                                dateFlag: e,
                                majorId: a[t].id,
                                answerSource: 5,
                                examCategory: a[t].examCategory
                            });
                        }
                    });
                },
                getChapter: function() {
                    var e = this, t = this.current, a = this.subject;
                    u.default.getKnowledge({
                        majorId: a[t].id,
                        examType: 2
                    }, function(t) {
                        e.chapterList = t.data.data;
                    });
                },
                handleSource: function(e) {
                    if (1 == e.chapterId) return "快速刷题";
                    if (2 == e.chapterId) return "院校真题";
                    var t = this.chapterList.filter(function(t) {
                        return t.id === e.chapterId;
                    });
                    return t.length > 0 ? t[0].name : "未知";
                }
            }
        };
    },
    "ZNU+": function(e, t) {},
    bqWm: function(e, t, a) {
        Object.defineProperty(t, "__esModule", {
            value: !0
        });
        var i = a("5nAL"), s = a.n(i), c = a("Fc/C");
        new s.a(c.a).$mount();
    }
}, [ "bqWm" ]);