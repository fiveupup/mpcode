require("../../@babel/runtime/helpers/Arrayincludes"), require("../../common/manifest.js"), 
require("../../common/vendor.js"), global.webpackJsonpMpvue([ 23 ], {
    "6y0J": function(e, i) {},
    "7Kxx": function(e, i, t) {
        var s = t("ijcZ"), r = t("ADJx"), a = t("ybqe")(s.a, r.a, function(e) {
            t("6y0J");
        }, null, null);
        i.a = a.exports;
    },
    ADJx: function(e, i, t) {
        i.a = {
            render: function() {
                var e = this, i = e.$createElement, t = e._self._c || i;
                return t("div", {
                    class: [ "practice", e.isDark && "dark" ]
                }, [ e.loading ? t("div", [ e.notCheck ? t("div", {
                    staticClass: "loading-img"
                }, [ t("img", {
                    attrs: {
                        src: e.isDark ? "//static.yanzhishi.cn/gif/loading_pull3.gif" : "//static.yanzhishi.cn/gif/loading_pull.gif",
                        mode: "widthFix",
                        alt: "img"
                    }
                }) ]) : t("div", {
                    staticClass: "http-error"
                }, [ t("tips-page", {
                    attrs: {
                        error: e.errorCode,
                        mpcomid: "0"
                    }
                }) ], 1) ]) : t("div", [ t("div", {
                    staticClass: "title"
                }, [ t("div", {
                    staticClass: "text-ellipsis"
                }, [ e._v("\n        " + e._s(e.title) + "\n      ") ]), e._v(" "), t("div", {
                    staticClass: "time"
                }, [ t("div", {
                    attrs: {
                        eventid: "0"
                    },
                    on: {
                        click: e.handleFeedback
                    }
                }, [ t("i-icon", {
                    attrs: {
                        type: "prompt",
                        size: "16",
                        color: "#999",
                        mpcomid: "1"
                    }
                }), e._v(" "), t("span", [ e._v("错题反馈") ]) ], 1), e._v(" "), e.isShare ? e._e() : t("button", {
                    staticClass: "share",
                    attrs: {
                        eventid: "1"
                    },
                    on: {
                        click: e.openHelpPage
                    }
                }, [ t("img", {
                    attrs: {
                        src: "//static.yanzhishi.cn/images/wechat/qiuzhu.png",
                        mode: "widthFix",
                        alt: "help"
                    }
                }) ]) ], 1) ]), e._v(" "), t("div", {
                    staticClass: "gray"
                }), e._v(" "), t("div", {
                    staticClass: "tag-content"
                }, [ e.isShare ? e._e() : t("div", {
                    staticClass: "tag"
                }, [ e._v("\n        " + e._s(e.num) + "/" + e._s(e.exerciseTotal) + "\n      ") ]), e._v(" "), t("div", {
                    staticClass: "exercise"
                }, [ 1 === e.editExercise.exerciseType ? t("practice-choice", {
                    attrs: {
                        exercise: e.editExercise,
                        answer: e.userAnswer,
                        showAnswer: e.isSubmit,
                        majorId: e.majorId,
                        chapterId: e.chapterId,
                        examCategory: e.examCategory,
                        num: e.num,
                        showAddMistake: !e.isShare,
                        eventid: "2",
                        mpcomid: "2"
                    },
                    on: {
                        changeAnswer: e.choosePracticeAnswer
                    }
                }) : e._e(), e._v(" "), 2 === e.editExercise.exerciseType ? t("practice-multiple", {
                    attrs: {
                        exercise: e.editExercise,
                        answer: e.userAnswer,
                        showAnswer: e.isSubmit,
                        majorId: e.majorId,
                        chapterId: e.chapterId,
                        examCategory: e.examCategory,
                        num: e.num,
                        showAddMistake: !e.isShare,
                        eventid: "3",
                        mpcomid: "3"
                    },
                    on: {
                        changeAnswer: e.choosePracticeAnswer
                    }
                }) : e._e(), e._v(" "), 3 === e.editExercise.exerciseType ? t("practice-fill", {
                    attrs: {
                        exercise: e.editExercise,
                        answer: e.userAnswer,
                        showAnswer: e.isSubmit,
                        majorId: e.majorId,
                        chapterId: e.chapterId,
                        examCategory: e.examCategory,
                        num: e.num,
                        showAddMistake: !e.isShare,
                        eventid: "4",
                        mpcomid: "4"
                    },
                    on: {
                        changeAnswer: e.choosePracticeAnswer
                    }
                }) : e._e(), e._v(" "), 5 === e.editExercise.exerciseType ? t("practice-judge", {
                    attrs: {
                        exercise: e.editExercise,
                        answer: e.userAnswer,
                        showAnswer: e.isSubmit,
                        majorId: e.majorId,
                        chapterId: e.chapterId,
                        examCategory: e.examCategory,
                        num: e.num,
                        showAddMistake: !e.isShare,
                        eventid: "5",
                        mpcomid: "5"
                    },
                    on: {
                        changeAnswer: e.choosePracticeAnswer
                    }
                }) : e._e(), e._v(" "), 4 === e.editExercise.exerciseType ? t("practice-short", {
                    attrs: {
                        exercise: e.editExercise,
                        answer: e.userAnswer,
                        showAnswer: e.isSubmit,
                        majorId: e.majorId,
                        chapterId: e.chapterId,
                        examCategory: e.examCategory,
                        num: e.num,
                        showAddMistake: !e.isShare,
                        eventid: "6",
                        mpcomid: "6"
                    },
                    on: {
                        changeAnswer: e.choosePracticeAnswer
                    }
                }) : e._e(), e._v(" "), 7 === e.editExercise.exerciseType ? t("practice-cloze", {
                    attrs: {
                        exercise: e.editExercise,
                        answer: e.userAnswer,
                        showAnswer: e.isSubmit,
                        majorId: e.majorId,
                        chapterId: e.chapterId,
                        examCategory: e.examCategory,
                        showAddMistake: !e.isShare,
                        eventid: "7",
                        mpcomid: "7"
                    },
                    on: {
                        changeAnswer: e.choosePracticeAnswer
                    }
                }) : e._e() ], 1), e._v(" "), e.isShare || e.isSubmit ? e._e() : t("div", {
                    staticClass: "skip",
                    attrs: {
                        eventid: "8"
                    },
                    on: {
                        click: e.skipAnswer
                    }
                }, [ t("img", {
                    attrs: {
                        src: "//static.yanzhishi.cn/images/wechat/skip.jpg",
                        mode: "widthFix"
                    }
                }), e._v("\n        跳过\n      ") ]) ]), e._v(" "), e.isSubmit || 4 === e.editExercise.exerciseType ? e._e() : t("fixed-bottom", {
                    attrs: {
                        text: "确定",
                        clickBtn: e.submitSingleExercise,
                        mpcomid: "8"
                    }
                }), e._v(" "), e.isSubmit && !e.isShare ? t("fixed-button", {
                    attrs: {
                        status: e.status,
                        majorId: e.majorId,
                        chapterId: e.chapterId,
                        exerciseId: e.editExercise.exerciseId,
                        nextFunc: e.nextExercise,
                        prevFunc: e.prevExercise,
                        collectFunc: e.collectExercise,
                        mpcomid: "9"
                    }
                }) : e._e() ], 1) ]);
            },
            staticRenderFns: []
        };
    },
    J6Z3: function(e, i, t) {
        Object.defineProperty(i, "__esModule", {
            value: !0
        });
        var s = t("7Kxx"), r = t("5nAL"), a = t.n(r), c = t("sGGH");
        t.n(c), new a.a(s.a).$mount();
    },
    ijcZ: function(e, i, t) {
        var s = t("mvHQ"), r = t.n(s), a = t("VsUZ"), c = t("oFuF"), n = t("tXM+"), o = t("Oz7p"), d = t("DiM2"), m = t("ErS0"), h = t("SPm4"), u = t("cjSp"), x = t("Quls"), l = t("emV0"), p = t("LGpd"), w = t("b1mz"), g = t("IcnI");
        i.a = {
            components: {
                PracticeChoice: o.a,
                FixedBottom: l.a,
                FixedButton: p.a,
                PracticeFill: m.a,
                PracticeJudge: h.a,
                PracticeMultiple: d.a,
                PracticeShort: u.a,
                PracticeCloze: x.a,
                TipsPage: n.a,
                "i-icon": w.a
            },
            data: function() {
                return {
                    loading: !0,
                    notCheck: !0,
                    isShare: !1,
                    exerciseNum: 0,
                    exerciseTotal: 0,
                    title: "智能练习",
                    exerciseList: [],
                    editExercise: null,
                    isSubmit: !1,
                    num: 1,
                    nowAnswer: null,
                    nowStartTime: "",
                    examId: "",
                    isJump: !1,
                    collectExerciseIds: [],
                    status: 1,
                    majorId: null,
                    chapterId: null,
                    examCategory: null,
                    isDark: wx.getStorageSync("isDark")
                };
            },
            computed: {
                examCategory: function() {
                    return g.a.state.examCategory;
                }
            },
            onLoad: function(e) {
                var i = this;
                if (this.isDark = Object(c.onChangeDark)(), e.params) {
                    var t = JSON.parse(e.params);
                    return this.editExercise = JSON.parse(decodeURIComponent(t.editExercise)), this.exerciseNum = t.exerciseNum, 
                    this.title = t.title, this.loading = !1, void (this.isShare = !0);
                }
                this.title = wx.getStorageSync("title"), this.$mp.page.getOpenerEventChannel().on("params", function(e) {
                    i.majorId = e.majorId, i.chapterId = e.chapterId, i.examCategory = e.examCategory, 
                    i.getExerciseList();
                });
            },
            onUnload: function() {
                this.loading = !0, this.notCheck = !0, this.isSubmit = !1, this.nowAnswer = null, 
                this.num = 1, this.isJump = !1, this.isShare = !1;
            },
            onShareAppMessage: function() {
                return {
                    title: "研蜜，你怎么看这道题嘛",
                    path: "/pages/practice/main?params=" + r()({
                        editExercise: encodeURIComponent(r()(this.editExercise)),
                        exerciseNum: this.exerciseNum,
                        title: this.title
                    })
                };
            },
            methods: {
                getExerciseList: function() {
                    var e = this, i = this.majorId, t = this.chapterId, s = this.examCategory, r = this.num;
                    this.loading = !0, this.notCheck = !0, a.default.getExerciseList({
                        majorId: i,
                        chapterId: t,
                        examType: Object(c.checkExamType)(0, s),
                        examCategory: s,
                        number: r
                    }, function(i) {
                        if (e.errorCode = i.data.code, 200 !== i.data.code) return e.notCheck = !1, !1;
                        e.exerciseNum = 0;
                        var t = i.data.data;
                        e.exerciseList = t.exercises;
                        var s = t.answerTotalNumber + t.skipExerciseIdList.length;
                        if (r <= s ? (t.skipExerciseIdList.includes(t.exercises[0].exerciseId) && (e.userAnswer = Object(c.getSkipUserAnswer)(t.exercises[0])), 
                        (t.answers || []).length > 0 && (e.userAnswer = t.answers[0]), e.isSubmit = !0) : e.userAnswer = void 0, 
                        e.collectExerciseIds = null === t.collectExerciseId ? [] : t.collectExerciseId, 
                        e.editExercise = e.exerciseList.length > 0 ? e.exerciseList[0] : {}, e.nowStartTime = new Date().getTime(), 
                        e.examId = t.examId, e.exerciseTotal = t.exerciseTotalNumber, e.checkExerciseIsCollect(), 
                        s > 0 && !e.isJump) return e.isSubmit = !1, e.isJump = !0, e.num = s + 1, void (e.num > e.exerciseTotal ? (e.errorCode = 4069, 
                        e.notCheck = !1, e.loading = !0) : e.getExerciseList());
                        e.notCheck = !1, e.loading = !1;
                    }, function(i) {
                        401 === i.status && Object(c.repeatLogin)(function() {
                            e.getExerciseList();
                        });
                    });
                },
                checkExerciseIsCollect: function() {
                    this.collectExerciseIds.indexOf(this.editExercise.exerciseId) > -1 ? this.status = 0 : this.status = 1;
                },
                collectExercise: function(e) {
                    0 === e ? this.collectExerciseIds.push(this.editExercise.exerciseId) : this.collectExerciseIds.splice(this.collectExerciseIds.indexOf(this.editExercise.exerciseId), 1), 
                    this.checkExerciseIsCollect();
                },
                choosePracticeAnswer: function(e) {
                    var i = this.editExercise.exerciseType;
                    7 === i ? this.nowAnswer = e.join(",") : (this.nowAnswer = e, [ 3, 4 ].includes(i) && this.submitSingleExercise());
                },
                submitSingleExercise: function() {
                    var e = this.isShare, i = this.nowAnswer, t = this.majorId, s = this.chapterId, r = this.nowStartTime, a = this.examId, n = this.num, o = this.examCategory, d = this.editExercise, m = d.exerciseType, h = d.exerciseAnswer, u = d.exerciseId;
                    if (d.questions, e) this.isSubmit = !0; else {
                        var x = 2;
                        if (console.log(h), x = 2 === m ? Object(c.isArrayEqual)(i.split(","), h.split(",")) ? 1 : 2 : 1 === m || 7 === m ? i == h ? 1 : 2 : 3, 
                        null !== i && "" !== i) {
                            if (7 === m && i.split(",").indexOf("") > -1) return void wx.showToast({
                                title: "你还有其他小问未作答，请在答题区左右滑动作答",
                                icon: "none"
                            });
                            this.isSubmit = !0;
                            var l = 1 === x ? 2 : 0, p = i;
                            if ([ 3, 4 ].includes(m) && i.split("$-$").length > 0) {
                                var w = i.split("$-$");
                                l = parseInt(w[1]), p = w[0], x = parseFloat(w[2]) > .6 ? 1 : 2;
                            }
                            var g = {
                                answers: [ {
                                    answerType: x,
                                    exerciseId: u,
                                    type: m,
                                    majorId: t,
                                    chapterId: s,
                                    score: l,
                                    answer: p,
                                    markStatus: 1,
                                    startTime: r,
                                    endTime: new Date().getTime(),
                                    answerSource: Object(c.checkExamType)(0, o)
                                } ],
                                examinationId: a,
                                examType: Object(c.checkExamType)(0, o),
                                submitStatus: 2,
                                startTime: 1 === n ? r : "",
                                endTime: new Date().getTime(),
                                examCategory: o
                            };
                            this.submitRequest(g);
                        } else wx.showToast({
                            title: "请选择或填写答案",
                            icon: "none"
                        });
                    }
                },
                submitRequest: function(e) {
                    var i = this;
                    a.default.submitExam(e, function(e) {
                        console.log(e);
                    }, function(t) {
                        401 === t.status && Object(c.repeatLogin)(function() {
                            i.submitRequest(e);
                        });
                    }, !1);
                },
                prevExercise: function() {
                    this.num > 1 ? (this.num -= 1, this.getExerciseList()) : wx.showToast({
                        title: "已经是第一题啦",
                        icon: "none"
                    });
                },
                nextExercise: function() {
                    this.num < this.exerciseTotal ? (this.nowAnswer = null, this.isSubmit = !1, this.num += 1, 
                    this.getExerciseList()) : wx.showToast({
                        title: "已经是最后一题啦，更多习题每周更新中",
                        icon: "none"
                    });
                },
                handleFeedback: function() {
                    g.a.commit("setFeedbackMajorId", this.majorId), g.a.commit("setFeedbackExerciseId", this.editExercise.exerciseId), 
                    wx.navigateTo({
                        url: "/pages/feedback/main",
                        success: function(e) {
                            console.log(e);
                        }
                    });
                },
                openHelpPage: function() {
                    wx.navigateTo({
                        url: "/pages/seekHelp/main",
                        success: function(e) {
                            console.log(e);
                        }
                    });
                },
                skipAnswer: function() {
                    this.isShare, this.nowAnswer;
                    var e = this.majorId, i = this.chapterId, t = this.nowStartTime, s = this.examId, r = this.num, a = this.examCategory, n = this.editExercise, o = n.exerciseType, d = (n.exerciseAnswer, 
                    {
                        answers: [ {
                            answerType: 1,
                            exerciseId: n.exerciseId,
                            type: o,
                            majorId: e,
                            chapterId: i,
                            score: 2,
                            answer: "",
                            markStatus: 1,
                            startTime: t,
                            endTime: new Date().getTime(),
                            answerSource: 15
                        } ],
                        examinationId: s,
                        examType: Object(c.checkExamType)(0, a),
                        submitStatus: 2,
                        startTime: 1 === r ? t : "",
                        endTime: new Date().getTime(),
                        examCategory: a,
                        skip: !0
                    });
                    this.submitRequest(d), this.nextExercise();
                }
            }
        };
    }
}, [ "J6Z3" ]);