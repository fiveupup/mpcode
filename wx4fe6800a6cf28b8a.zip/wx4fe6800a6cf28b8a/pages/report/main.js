require("../../common/manifest.js"), require("../../common/vendor.js"), global.webpackJsonpMpvue([ 18 ], {
    "JwE+": function(s, a, t) {
        a.a = {
            render: function() {
                var s = this, a = s.$createElement, t = s._self._c || a;
                return t("div", {
                    class: [ "report-container", s.isDark && "dark" ]
                }, [ s._m(0), s._v(" "), t("div", {
                    staticClass: "statistics"
                }, [ t("div", [ t("p", {
                    staticClass: "num"
                }, [ s._v(s._s(s.answerParams.score)) ]), s._v(" "), t("p", {
                    staticClass: "text"
                }, [ s._v("得分") ]) ], 1), s._v(" "), t("div", {
                    staticClass: "line"
                }, [ t("p", {
                    staticClass: "num"
                }, [ s._v(s._s(s.usedTime)) ]), s._v(" "), t("p", {
                    staticClass: "text"
                }, [ s._v("用时（分钟）") ]) ], 1), s._v(" "), t("div", [ t("p", {
                    staticClass: "num"
                }, [ s._v(s._s(s.answerParams.inCorrectNumber)) ]), s._v(" "), t("p", {
                    staticClass: "text"
                }, [ s._v("错题") ]) ], 1) ]), s._v(" "), t("div", {
                    staticClass: "gray"
                }), s._v(" "), s._m(1), s._v(" "), t("p", {
                    staticClass: "explain"
                }, [ s._v("说明：自查题目需要用户自己去核对答案，不计入得分，也不计入错题，可在查看解析时收藏题目。") ]), s._v(" "), t("div", {
                    staticClass: "answer"
                }, s._l(s.answers, function(a, i) {
                    return t("block", {
                        key: i
                    }, [ t("div", {
                        class: [ "answer-item", "" != a.answer ? 3 == a.answerType ? "answer-item-uncheck" : 1 === a.answerType ? "answer-item-on" : "answer-item-fail" : "" ],
                        attrs: {
                            id: i
                        }
                    }, [ s._v(s._s(i + 1)) ]) ]);
                })), s._v(" "), t("div", {
                    staticClass: "exam-paper"
                }, [ t("img", {
                    attrs: {
                        src: "//static.yanzhishi.cn/images/wechat/taobao.png",
                        mode: "widthFix",
                        alt: "weixin"
                    }
                }), s._v(" "), t("div", {
                    staticClass: "qrcode-right"
                }, [ t("p", {
                    staticClass: "qrcode-title"
                }, [ s._v("淘宝搜索研芝士，立即拥有") ]), s._v(" "), t("p", {
                    staticClass: "qrcode-info"
                }, [ s._v("① 练透考点2000题的摘星题库") ]), s._v(" "), t("p", {
                    staticClass: "qrcode-info"
                }, [ s._v("② 完整版真题独立封装，体验全真考试场景") ]) ], 1) ]), s._v(" "), t("div", {
                    staticClass: "fixed-bottom"
                }, [ t("div", {
                    staticClass: "bg-all",
                    attrs: {
                        eventid: "0"
                    },
                    on: {
                        click: function(a) {
                            s.viewAnalysis(1);
                        }
                    }
                }, [ t("img", {
                    attrs: {
                        src: "//static.yanzhishi.cn/images/wechat/quanbujiexi@2x.png",
                        alt: "all"
                    }
                }), s._v(" "), t("span", [ s._v("全部解析") ]) ]), s._v(" "), t("div", {
                    staticClass: "bg-error",
                    attrs: {
                        eventid: "1"
                    },
                    on: {
                        click: function(a) {
                            s.viewAnalysis(2);
                        }
                    }
                }, [ t("img", {
                    attrs: {
                        src: "//static.yanzhishi.cn/images/wechat/cuotijiexi@2x.png",
                        alt: "error"
                    }
                }), s._v(" "), t("span", [ s._v("错题解析") ]) ]) ]) ], 1);
            },
            staticRenderFns: [ function() {
                var s = this.$createElement, a = this._self._c || s;
                return a("div", {
                    staticClass: "star"
                }, [ a("img", {
                    attrs: {
                        src: "//static.yanzhishi.cn/images/wechat/xunzhang@2x.png",
                        alt: "xunzhang"
                    }
                }) ]);
            }, function() {
                var s = this, a = s.$createElement, t = s._self._c || a;
                return t("div", {
                    staticClass: "head"
                }, [ t("span", {
                    staticClass: "circle unfinish"
                }), s._v(" "), t("span", [ s._v("未答") ]), s._v(" "), t("span", {
                    staticClass: "circle right"
                }), s._v(" "), t("span", [ s._v("正确") ]), s._v(" "), t("span", {
                    staticClass: "circle wrong"
                }), s._v(" "), t("span", [ s._v("错误") ]), s._v(" "), t("span", {
                    staticClass: "circle check"
                }), s._v(" "), t("span", [ s._v("根据答案自查") ]) ]);
            } ]
        };
    },
    LLvI: function(s, a, t) {
        Object.defineProperty(a, "__esModule", {
            value: !0
        });
        var i = t("Pm5a"), e = t("5nAL");
        new (t.n(e).a)(i.a).$mount();
    },
    Pm5a: function(s, a, t) {
        var i = t("Tapc"), e = t("JwE+"), n = t("ybqe")(i.a, e.a, function(s) {
            t("tEW5");
        }, "data-v-ec75086a", null);
        a.a = n.exports;
    },
    Tapc: function(s, a, t) {
        var i = t("oFuF");
        a.a = {
            data: function() {
                return {
                    answerParams: null,
                    answers: [],
                    usedTime: 0,
                    codeText: "完整版真题",
                    codeSrc: "//static.yanzhishi.cn/images/wechat/qrcode1.png",
                    isDark: wx.getStorageSync("isDark")
                };
            },
            onLoad: function(s) {
                this.isDark = Object(i.onChangeDark)(), this.answerParams = JSON.parse(s.params), 
                this.answers = this.answerParams.answers, this.usedTime = Object(i.calculateTime)(this.answerParams.startTime, this.answerParams.endTime);
            },
            onShow: function() {
                2 === wx.getStorageSync("isFastType") ? (this.codeText = "完整版真题", this.codeSrc = "//static.yanzhishi.cn/images/wechat/qrcode1.png") : (this.codeText = "更多习题", 
                this.codeSrc = "//static.yanzhishi.cn/images/wechat/qrcode2.png");
            },
            methods: {
                viewAnalysis: function(s) {
                    var a = this;
                    if (2 === s && 0 == this.answerParams.inCorrectNumber) return wx.showToast({
                        title: "无错题",
                        icon: ""
                    }), !1;
                    wx.navigateTo({
                        url: "/pages/analysis/main",
                        success: function(t) {
                            t.eventChannel.emit("type", {
                                type: s,
                                answerParams: a.answerParams
                            });
                        }
                    });
                }
            }
        };
    },
    tEW5: function(s, a) {}
}, [ "LLvI" ]);