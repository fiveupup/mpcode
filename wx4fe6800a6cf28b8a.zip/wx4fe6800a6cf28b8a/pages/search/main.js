require("../../@babel/runtime/helpers/Arrayincludes"), require("../../common/manifest.js"), 
require("../../common/vendor.js"), global.webpackJsonpMpvue([ 1 ], {
    "+1j2": function(e, s, t) {
        s.a = {
            render: function() {
                var e = this, s = e.$createElement, t = e._self._c || s;
                return t("div", {
                    staticClass: "photo-judge"
                }, [ t("div", {
                    staticClass: "analysis"
                }, [ t("div", {
                    staticClass: "analysis-title"
                }, [ e._m(0), e._v(" "), t("div", {
                    staticClass: "icon-box"
                }, [ t("div", {
                    attrs: {
                        eventid: "0"
                    },
                    on: {
                        click: e.collectExercise
                    }
                }, [ t("i-icon", {
                    attrs: {
                        type: e.collectAll[e.status].type,
                        size: "18",
                        color: e.collectAll[e.status].color,
                        mpcomid: "0"
                    }
                }), e._v(" "), t("span", [ e._v("收藏") ]) ], 1), e._v(" "), t("div", {
                    attrs: {
                        eventid: "1"
                    },
                    on: {
                        click: e.handleFeedback
                    }
                }, [ t("i-icon", {
                    attrs: {
                        type: "prompt",
                        size: "18",
                        color: "#999",
                        mpcomid: "1"
                    }
                }), e._v(" "), t("span", [ e._v("错题反馈") ]) ], 1) ]) ]), e._v(" "), t("parser", {
                    attrs: {
                        html: e.exercise.exerciseStems,
                        mpcomid: "2"
                    }
                }) ], 1), e._v(" "), t("div", {
                    staticClass: "judge-answer"
                }, e._l(e.exercise.questions, function(s, i) {
                    return t("block", {
                        key: i
                    }, [ t("div", {
                        class: [ "child", e.exercise.exerciseAnswer == s.questionStem ? "sel" : "" ]
                    }, [ e._v("\n        " + e._s(s.questionAnswer) + "\n      ") ]) ]);
                })), e._v(" "), t("div", {
                    staticClass: "analysis mt-space"
                }, [ 1 === e.exercise.exerciseFrom.isOfficialExercise ? t("div", [ t("span", {
                    staticClass: "tag",
                    attrs: {
                        name: e.exercise.exerciseFrom.fromSchool
                    }
                }, [ t("i-tag", {
                    attrs: {
                        mpcomid: "3"
                    }
                }, [ e._v(e._s(e.exercise.exerciseFrom.fromSchool)) ]) ], 1), e._v(" "), t("span", {
                    staticClass: "tag",
                    attrs: {
                        name: e.exercise.exerciseFrom.examTime
                    }
                }, [ t("i-tag", {
                    attrs: {
                        mpcomid: "4"
                    }
                }, [ e._v(e._s(e.exercise.exerciseFrom.examTime)) ]) ], 1), e._v(" "), t("span", {
                    staticClass: "tag",
                    attrs: {
                        name: e.exercise.exerciseFrom.examCode
                    }
                }, [ t("i-tag", {
                    attrs: {
                        mpcomid: "5"
                    }
                }, [ e._v(e._s(e.exercise.exerciseFrom.examCode)) ]) ], 1), e._v(" "), t("span", {
                    staticClass: "tag",
                    attrs: {
                        name: e.exercise.exerciseFrom.examFullName
                    }
                }, [ t("i-tag", {
                    attrs: {
                        mpcomid: "6"
                    }
                }, [ e._v(e._s(e.exercise.exerciseFrom.examFullName)) ]) ], 1) ]) : t("div", [ t("span", {
                    staticClass: "tag tag-self"
                }, [ e._v("\n        研芝士题库\n      ") ]) ]) ]), e._v(" "), t("div", {
                    staticClass: "analysis"
                }, [ e._m(1), e._v(" "), t("parser", {
                    attrs: {
                        html: e.exercise.exerciseAnalysis,
                        mpcomid: "7"
                    }
                }) ], 1) ]);
            },
            staticRenderFns: [ function() {
                var e = this.$createElement, s = this._self._c || e;
                return s("div", [ s("span", {
                    staticClass: "line"
                }), this._v("题目"), s("span", {
                    staticClass: "exercise-type"
                }, [ this._v("（判断题）") ]) ]);
            }, function() {
                var e = this.$createElement, s = this._self._c || e;
                return s("div", {
                    staticClass: "analysis-title"
                }, [ s("span", {
                    staticClass: "line"
                }), this._v("解析\n    ") ]);
            } ]
        };
    },
    "/NlU": function(e, s, t) {
        s.a = {
            render: function() {
                var e = this.$createElement, s = this._self._c || e;
                return s("div", {
                    staticClass: "i-spin",
                    class: [ this.iClass, this.fix ? "i-spin-fix" : "", "i-spin-" + this.size, this.custom ? "i-spin-show-text" : "", this.fullscreen ? "i-spin-fullscreen" : "" ]
                }, [ s("div", {
                    staticClass: "i-spin-main"
                }, [ s("div", {
                    staticClass: "i-spin-dot"
                }), this._v(" "), s("div", {
                    staticClass: "i-spin-text"
                }, [ this._t("default", null, {
                    mpcomid: "0"
                }) ], 2) ]) ]);
            },
            staticRenderFns: []
        };
    },
    "0/5e": function(e, s) {},
    "1UlE": function(e, s, t) {
        s.a = {
            render: function() {
                var e = this.$createElement;
                return (this._self._c || e)("div", {
                    staticClass: "i-tag",
                    class: this.classObj,
                    attrs: {
                        eventid: "0"
                    },
                    on: {
                        click: this.tapTag
                    }
                }, [ this._v("\n  " + this._s(this.innerText) + "\n  "), this._t("default", null, {
                    mpcomid: "0"
                }) ], 2);
            },
            staticRenderFns: []
        };
    },
    "1kNa": function(e, s, t) {
        Object.defineProperty(s, "__esModule", {
            value: !0
        });
        var i = t("5nAL"), c = t.n(i), a = t("ar59"), r = t("ltdW"), n = (t.n(r), t("ocgm")), l = (t.n(n), 
        t("Uxel"));
        t.n(l), new c.a(a.a).$mount();
    },
    "26cD": function(e, s) {},
    "3pP7": function(e, s, t) {
        var i = t("ilAw"), c = t("1UlE"), a = t("ybqe")(i.a, c.a, function(e) {
            t("q/k5");
        }, null, null);
        s.a = a.exports;
    },
    "65uf": function(e, s) {},
    "7FsZ": function(e, s, t) {
        s.a = {
            render: function() {
                var e = this, s = e.$createElement, t = e._self._c || s;
                return t("div", {
                    staticClass: "photo-short"
                }, [ t("div", {
                    staticClass: "analysis"
                }, [ t("div", {
                    staticClass: "analysis-title"
                }, [ e._m(0), e._v(" "), t("div", {
                    staticClass: "icon-box"
                }, [ t("div", {
                    attrs: {
                        eventid: "0"
                    },
                    on: {
                        click: e.collectExercise
                    }
                }, [ t("i-icon", {
                    attrs: {
                        type: e.collectAll[e.status].type,
                        size: "18",
                        color: e.collectAll[e.status].color,
                        mpcomid: "0"
                    }
                }), e._v(" "), t("span", [ e._v("收藏") ]) ], 1), e._v(" "), t("div", {
                    attrs: {
                        eventid: "1"
                    },
                    on: {
                        click: e.handleFeedback
                    }
                }, [ t("i-icon", {
                    attrs: {
                        type: "prompt",
                        size: "18",
                        color: "#999",
                        mpcomid: "1"
                    }
                }), e._v(" "), t("span", [ e._v("错题反馈") ]) ], 1) ]) ]), e._v(" "), t("parser", {
                    attrs: {
                        html: e.exercise.exerciseStems,
                        mpcomid: "2"
                    }
                }) ], 1), e._v(" "), 0 !== e.exercise.questions.length ? t("div", {
                    staticClass: "info"
                }, [ t("div", {
                    staticClass: "answer"
                }, e._l(e.exercise.questions, function(s, i) {
                    return t("block", {
                        key: i
                    }, [ t("div", {
                        staticClass: "child"
                    }, [ t("div", {
                        staticClass: "analysis"
                    }, [ t("div", {
                        staticClass: "analysis-title"
                    }, [ t("span", {
                        staticClass: "line"
                    }), e._v("小问：\n            ") ]), e._v(" "), t("parser", {
                        attrs: {
                            html: s.questionStem,
                            mpcomid: "3_" + i
                        }
                    }) ], 1), e._v(" "), t("div", {
                        staticClass: "analysis"
                    }, [ t("div", {
                        staticClass: "analysis-title"
                    }, [ t("span", {
                        staticClass: "line"
                    }), e._v("答案：\n            ") ]), e._v(" "), t("parser", {
                        attrs: {
                            html: s.questionAnswer,
                            mpcomid: "4_" + i
                        }
                    }) ], 1), e._v(" "), t("div", {
                        staticClass: "analysis"
                    }, [ t("div", {
                        staticClass: "analysis-title"
                    }, [ t("span", {
                        staticClass: "line"
                    }), e._v("解析：\n            ") ]), e._v(" "), t("parser", {
                        attrs: {
                            html: s.questionAnalysis,
                            mpcomid: "5_" + i
                        }
                    }) ], 1) ]) ]);
                })) ]) : e._e(), e._v(" "), t("div", {
                    staticClass: "analysis"
                }, [ 1 === e.exercise.exerciseFrom.isOfficialExercise ? t("div", [ t("span", {
                    staticClass: "tag",
                    attrs: {
                        name: e.exercise.exerciseFrom.fromSchool
                    }
                }, [ t("i-tag", {
                    attrs: {
                        mpcomid: "6"
                    }
                }, [ e._v(e._s(e.exercise.exerciseFrom.fromSchool)) ]) ], 1), e._v(" "), t("span", {
                    staticClass: "tag",
                    attrs: {
                        name: e.exercise.exerciseFrom.examTime
                    }
                }, [ t("i-tag", {
                    attrs: {
                        mpcomid: "7"
                    }
                }, [ e._v(e._s(e.exercise.exerciseFrom.examTime)) ]) ], 1), e._v(" "), t("span", {
                    staticClass: "tag",
                    attrs: {
                        name: e.exercise.exerciseFrom.examCode
                    }
                }, [ t("i-tag", {
                    attrs: {
                        mpcomid: "8"
                    }
                }, [ e._v(e._s(e.exercise.exerciseFrom.examCode)) ]) ], 1), e._v(" "), t("span", {
                    staticClass: "tag",
                    attrs: {
                        name: e.exercise.exerciseFrom.examFullName
                    }
                }, [ t("i-tag", {
                    attrs: {
                        mpcomid: "9"
                    }
                }, [ e._v(e._s(e.exercise.exerciseFrom.examFullName)) ]) ], 1) ]) : t("div", [ t("span", {
                    staticClass: "tag tag-self"
                }, [ e._v("\n        研芝士题库\n      ") ]) ]) ]), e._v(" "), 0 === e.exercise.questions.length ? t("block", [ t("div", {
                    staticClass: "analysis"
                }, [ t("div", {
                    staticClass: "analysis-title"
                }, [ t("span", {
                    staticClass: "line"
                }), e._v("答案\n      ") ]), e._v(" "), t("parser", {
                    attrs: {
                        html: e.exercise.exerciseAnswer,
                        mpcomid: "10"
                    }
                }) ], 1), e._v(" "), t("div", {
                    staticClass: "analysis"
                }, [ t("div", {
                    staticClass: "analysis-title"
                }, [ t("span", {
                    staticClass: "line"
                }), e._v("解析\n      ") ]), e._v(" "), t("parser", {
                    attrs: {
                        html: e.exercise.exerciseAnalysis,
                        mpcomid: "11"
                    }
                }) ], 1) ]) : e._e() ], 1);
            },
            staticRenderFns: [ function() {
                var e = this.$createElement, s = this._self._c || e;
                return s("div", [ s("span", {
                    staticClass: "line"
                }), this._v("题目"), s("span", {
                    staticClass: "exercise-type"
                }, [ this._v("（简答题）") ]) ]);
            } ]
        };
    },
    "CP6+": function(e, s) {},
    Gnhm: function(e, s, t) {
        var i = t("opNd"), c = t("kqLQ"), a = t("ybqe")(i.a, c.a, function(e) {
            t("26cD");
        }, "data-v-06df46c0", null);
        s.a = a.exports;
    },
    LdZK: function(e, s) {},
    MqYw: function(e, s, t) {
        var i = t("b1mz"), c = (t("8e4C"), t("3pP7")), a = t("P6QM"), r = (t.n(a), t("VsUZ")), n = t("IcnI");
        s.a = {
            components: {
                "i-tag": c.a,
                "i-icon": i.a
            },
            props: {
                exercise: {
                    type: Object,
                    value: {
                        exerciseStems: null,
                        exerciseAnswer: null,
                        exerciseAnalysis: null
                    }
                }
            },
            onLoad: function() {
                console.log(this.exercise, "题目信息"), this.checkExerciseIsCollect();
            },
            data: function() {
                return {
                    text: "芝士库",
                    collectAll: [ {
                        color: "#ffc525",
                        type: "collection_fill"
                    }, {
                        color: "#999",
                        type: "collection"
                    } ],
                    status: 1,
                    collectExerciseIds: []
                };
            },
            watch: {
                exercise: function(e, s) {
                    if (e !== s) return console.log(e, "题目信息"), e;
                }
            },
            methods: {
                checkExerciseIsCollect: function() {
                    this.collectExerciseIds = wx.getStorageSync("collectExerciseIds") || [], this.status = this.collectExerciseIds.indexOf(this.exercise.exerciseId) > -1 ? 0 : 1;
                },
                collectExercise: function() {
                    var e = this, s = this.exercise, t = s.exerciseProperty.knowledgeTags, i = s.exerciseId, c = 0 === this.status ? 1 : 0;
                    r.default.addCollectExercise({
                        majorId: t.length > 0 ? t[0].split(",")[0] : "759163208064962560",
                        chapterId: 1 === this.status ? 8 : "",
                        exerciseId: i,
                        collectFlag: c,
                        examCategory: 1
                    }, function(s) {
                        s.data.data && 200 === s.data.code && wx.showToast({
                            title: 0 === c ? "已收藏" : "已取消收藏",
                            duration: 1e3
                        }), e.collectFunc(c, i);
                    });
                },
                collectFunc: function(e, s) {
                    this.status = e, 0 === e ? this.collectExerciseIds.push(s) : this.collectExerciseIds.splice(this.collectExerciseIds.indexOf(s), 1), 
                    wx.setStorageSync("collectExerciseIds", this.collectExerciseIds);
                },
                handleFeedback: function() {
                    var e = this.exercise, s = e.exerciseProperty.knowledgeTags, t = e.exerciseId;
                    n.a.commit("setFeedbackMajorId", s.length > 0 ? s[0].split(",")[0] : "759163208064962560"), 
                    n.a.commit("setFeedbackExerciseId", t), wx.navigateTo({
                        url: "/pages/feedback/main"
                    });
                }
            }
        };
    },
    OdGg: function(e, s, t) {
        var i = t("b1mz"), c = (t("8e4C"), t("3pP7")), a = t("P6QM"), r = (t.n(a), t("VsUZ")), n = t("IcnI");
        s.a = {
            components: {
                "i-tag": c.a,
                "i-icon": i.a
            },
            props: {
                exercise: {
                    type: Object,
                    value: {
                        exerciseStems: null,
                        exerciseAnswer: null,
                        exerciseAnalysis: null
                    }
                }
            },
            onLoad: function() {
                console.log(this.exercise, "题目信息"), this.checkExerciseIsCollect();
            },
            data: function() {
                return {
                    text: "芝士库",
                    collectAll: [ {
                        color: "#ffc525",
                        type: "collection_fill"
                    }, {
                        color: "#999",
                        type: "collection"
                    } ],
                    status: 1,
                    collectExerciseIds: []
                };
            },
            watch: {
                exercise: function(e, s) {
                    if (e !== s) return e;
                }
            },
            methods: {
                checkExerciseIsCollect: function() {
                    this.collectExerciseIds = wx.getStorageSync("collectExerciseIds") || [], this.status = this.collectExerciseIds.indexOf(this.exercise.exerciseId) > -1 ? 0 : 1;
                },
                collectExercise: function() {
                    var e = this, s = this.exercise, t = s.exerciseProperty.knowledgeTags, i = s.exerciseId, c = 0 === this.status ? 1 : 0;
                    r.default.addCollectExercise({
                        majorId: t.length > 0 ? t[0].split(",")[0] : "759163208064962560",
                        chapterId: 1 === this.status ? 8 : "",
                        exerciseId: i,
                        collectFlag: c,
                        examCategory: 1
                    }, function(s) {
                        s.data.data && 200 === s.data.code && wx.showToast({
                            title: 0 === c ? "已收藏" : "已取消收藏",
                            duration: 1e3
                        }), e.collectFunc(c, i);
                    });
                },
                collectFunc: function(e, s) {
                    this.status = e, 0 === e ? this.collectExerciseIds.push(s) : this.collectExerciseIds.splice(this.collectExerciseIds.indexOf(s), 1), 
                    wx.setStorageSync("collectExerciseIds", this.collectExerciseIds);
                },
                handleFeedback: function() {
                    var e = this.exercise, s = e.exerciseProperty.knowledgeTags, t = e.exerciseId;
                    n.a.commit("setFeedbackMajorId", s.length > 0 ? s[0].split(",")[0] : "759163208064962560"), 
                    n.a.commit("setFeedbackExerciseId", t), wx.navigateTo({
                        url: "/pages/feedback/main"
                    });
                }
            }
        };
    },
    QDbS: function(e, s) {},
    Rd1j: function(e, s, t) {
        s.a = {
            props: {
                iClass: {
                    type: String,
                    default: ""
                },
                size: {
                    type: String,
                    default: "default"
                },
                fix: {
                    type: Boolean,
                    default: !1
                },
                fullscreen: {
                    type: Boolean,
                    default: !1
                },
                custom: {
                    type: Boolean,
                    default: !1
                }
            }
        };
    },
    SMyR: function(e, s, t) {
        s.a = {
            render: function() {
                var e = this, s = e.$createElement, t = e._self._c || s;
                return t("div", {
                    staticClass: "photo-choice"
                }, [ t("div", {
                    staticClass: "analysis"
                }, [ t("div", {
                    staticClass: "analysis-title"
                }, [ e._m(0), e._v(" "), t("div", {
                    staticClass: "icon-box"
                }, [ t("div", {
                    attrs: {
                        eventid: "0"
                    },
                    on: {
                        click: e.collectExercise
                    }
                }, [ t("i-icon", {
                    attrs: {
                        type: e.collectAll[e.status].type,
                        size: "18",
                        color: e.collectAll[e.status].color,
                        mpcomid: "0"
                    }
                }), e._v(" "), t("span", [ e._v("收藏") ]) ], 1), e._v(" "), t("div", {
                    attrs: {
                        eventid: "1"
                    },
                    on: {
                        click: e.handleFeedback
                    }
                }, [ t("i-icon", {
                    attrs: {
                        type: "prompt",
                        size: "18",
                        color: "#999",
                        mpcomid: "1"
                    }
                }), e._v(" "), t("span", [ e._v("错题反馈") ]) ], 1) ]) ]), e._v(" "), t("parser", {
                    attrs: {
                        html: e.exercise.exerciseStems,
                        mpcomid: "2"
                    }
                }) ], 1), e._v(" "), t("div", {
                    staticClass: "info"
                }, [ t("div", {
                    staticClass: "answer"
                }, e._l(e.exercise.questions, function(s, i) {
                    return t("block", {
                        key: i
                    }, [ t("div", {
                        staticClass: "child"
                    }, [ t("div", {
                        staticClass: "check"
                    }, [ t("span", [ e._v(e._s(s.questionStem)) ]) ]), e._v(" "), t("div", {
                        staticClass: "option"
                    }, [ t("parser", {
                        attrs: {
                            html: s.questionAnswer,
                            mpcomid: "3_" + i
                        }
                    }) ], 1) ]) ]);
                })) ]), e._v(" "), t("div", {
                    staticClass: "analysis"
                }, [ 1 === e.exercise.exerciseFrom.isOfficialExercise ? t("div", [ t("span", {
                    staticClass: "tag",
                    attrs: {
                        name: e.exercise.exerciseFrom.fromSchool
                    }
                }, [ t("i-tag", {
                    attrs: {
                        mpcomid: "4"
                    }
                }, [ e._v(e._s(e.exercise.exerciseFrom.fromSchool)) ]) ], 1), e._v(" "), t("span", {
                    staticClass: "tag",
                    attrs: {
                        name: e.exercise.exerciseFrom.examTime
                    }
                }, [ t("i-tag", {
                    attrs: {
                        mpcomid: "5"
                    }
                }, [ e._v(e._s(e.exercise.exerciseFrom.examTime)) ]) ], 1), e._v(" "), t("span", {
                    staticClass: "tag",
                    attrs: {
                        name: e.exercise.exerciseFrom.examCode
                    }
                }, [ t("i-tag", {
                    attrs: {
                        mpcomid: "6"
                    }
                }, [ e._v(e._s(e.exercise.exerciseFrom.examCode)) ]) ], 1), e._v(" "), t("span", {
                    staticClass: "tag",
                    attrs: {
                        name: e.exercise.exerciseFrom.examFullName
                    }
                }, [ t("i-tag", {
                    attrs: {
                        mpcomid: "7"
                    }
                }, [ e._v(e._s(e.exercise.exerciseFrom.examFullName)) ]) ], 1) ]) : t("div", [ t("span", {
                    staticClass: "tag tag-self"
                }, [ e._v("\n        研芝士题库\n      ") ]) ]) ]), e._v(" "), t("div", {
                    staticClass: "right"
                }, [ t("span", [ e._v("答案") ]), e._v(" "), t("span", {
                    staticClass: "space"
                }, [ e._v(e._s(e.exercise.exerciseAnswer)) ]) ]), e._v(" "), t("div", {
                    staticClass: "analysis"
                }, [ e._m(1), e._v(" "), t("parser", {
                    attrs: {
                        html: e.exercise.exerciseAnalysis,
                        mpcomid: "8"
                    }
                }) ], 1) ]);
            },
            staticRenderFns: [ function() {
                var e = this.$createElement, s = this._self._c || e;
                return s("div", [ s("span", {
                    staticClass: "line"
                }), this._v("题目"), s("span", {
                    staticClass: "exercise-type"
                }, [ this._v("（单选题）") ]) ]);
            }, function() {
                var e = this.$createElement, s = this._self._c || e;
                return s("div", {
                    staticClass: "analysis-title"
                }, [ s("span", {
                    staticClass: "line"
                }), this._v("解析\n    ") ]);
            } ]
        };
    },
    Xh4d: function(e, s, t) {
        var i = t("tKms"), c = t("7FsZ"), a = t("ybqe")(i.a, c.a, function(e) {
            t("65uf");
        }, "data-v-bd68f4e2", null);
        s.a = a.exports;
    },
    ar59: function(e, s, t) {
        var i = t("r/9Q"), c = t("rD1g"), a = t("ybqe")(i.a, c.a, function(e) {
            t("QDbS");
        }, null, null);
        s.a = a.exports;
    },
    dg8T: function(e, s) {},
    fxwN: function(e, s, t) {
        var i = t("MqYw"), c = t("SMyR"), a = t("ybqe")(i.a, c.a, function(e) {
            t("rzTJ");
        }, "data-v-4d59fa9e", null);
        s.a = a.exports;
    },
    ilAw: function(e, s, t) {
        var i = [ "blue", "green", "red", "yellow", "default" ];
        s.a = {
            props: {
                name: {
                    type: String,
                    default: ""
                },
                checkable: {
                    type: Boolean,
                    default: !1
                },
                checked: {
                    type: Boolean,
                    default: !0
                },
                color: {
                    type: String,
                    default: "default"
                },
                type: {
                    type: String,
                    default: "dot"
                },
                iClass: {
                    type: String,
                    default: ""
                },
                innerText: {
                    type: String,
                    default: ""
                }
            },
            computed: {
                classObj: function() {
                    var e = "";
                    i.includes(this.color) && (e = "i-tag-" + this.color), "border" === this.type && (e = "i-tag-" + this.color + "-border"), 
                    this.checkable && "false" !== this.checkable && this.checked && "false" !== this.checked ? e = "i-tag-" + this.color + "-checked" : !this.checkable || "false" === this.checkable || this.checked && "false" !== this.checked || (e = "border" === this.type ? "i-tag-" + this.color + "-border" : "i-tag-none");
                    var s = this.checkable && "false" !== this.checkable ? "i-tag-disable" : "";
                    return this.iClass + " " + s + " " + e;
                }
            },
            methods: {
                tapTag: function() {
                    this.checkable && "false" !== this.checkable && this.$emit("change", {
                        name: this.name || "",
                        checked: !this.checked || "false" === this.checked
                    });
                }
            }
        };
    },
    "kF/J": function(e, s, t) {
        var i = t("OdGg"), c = t("+1j2"), a = t("ybqe")(i.a, c.a, function(e) {
            t("dg8T");
        }, "data-v-57d5aaaa", null);
        s.a = a.exports;
    },
    kqLQ: function(e, s, t) {
        s.a = {
            render: function() {
                var e = this, s = e.$createElement, t = e._self._c || s;
                return t("div", {
                    staticClass: "photo-fill"
                }, [ t("div", {
                    staticClass: "analysis"
                }, [ t("div", {
                    staticClass: "analysis-title"
                }, [ e._m(0), e._v(" "), t("div", {
                    staticClass: "icon-box"
                }, [ t("div", {
                    attrs: {
                        eventid: "0"
                    },
                    on: {
                        click: e.collectExercise
                    }
                }, [ t("i-icon", {
                    attrs: {
                        type: e.collectAll[e.status].type,
                        size: "18",
                        color: e.collectAll[e.status].color,
                        mpcomid: "0"
                    }
                }), e._v(" "), t("span", [ e._v("收藏") ]) ], 1), e._v(" "), t("div", {
                    attrs: {
                        eventid: "1"
                    },
                    on: {
                        click: e.handleFeedback
                    }
                }, [ t("i-icon", {
                    attrs: {
                        type: "prompt",
                        size: "18",
                        color: "#999",
                        mpcomid: "1"
                    }
                }), e._v(" "), t("span", [ e._v("错题反馈") ]) ], 1) ]) ]), e._v(" "), t("parser", {
                    attrs: {
                        html: e.topic,
                        mpcomid: "2"
                    }
                }) ], 1), e._v(" "), t("div", {
                    staticClass: "analysis mt-space"
                }, [ 1 === e.exercise.exerciseFrom.isOfficialExercise ? t("div", [ t("span", {
                    staticClass: "tag",
                    attrs: {
                        name: e.exercise.exerciseFrom.fromSchool
                    }
                }, [ t("i-tag", {
                    attrs: {
                        mpcomid: "3"
                    }
                }, [ e._v(e._s(e.exercise.exerciseFrom.fromSchool)) ]) ], 1), e._v(" "), t("span", {
                    staticClass: "tag",
                    attrs: {
                        name: e.exercise.exerciseFrom.examTime
                    }
                }, [ t("i-tag", {
                    attrs: {
                        mpcomid: "4"
                    }
                }, [ e._v(e._s(e.exercise.exerciseFrom.examTime)) ]) ], 1), e._v(" "), t("span", {
                    staticClass: "tag",
                    attrs: {
                        name: e.exercise.exerciseFrom.examCode
                    }
                }, [ t("i-tag", {
                    attrs: {
                        mpcomid: "5"
                    }
                }, [ e._v(e._s(e.exercise.exerciseFrom.examCode)) ]) ], 1), e._v(" "), t("span", {
                    staticClass: "tag",
                    attrs: {
                        name: e.exercise.exerciseFrom.examFullName
                    }
                }, [ t("i-tag", {
                    attrs: {
                        mpcomid: "6"
                    }
                }, [ e._v(e._s(e.exercise.exerciseFrom.examFullName)) ]) ], 1) ]) : t("div", [ t("span", {
                    staticClass: "tag tag-self"
                }, [ e._v("\n        研芝士题库\n      ") ]) ]) ]), e._v(" "), t("div", {
                    staticClass: "analysis"
                }, [ e._m(1), e._v(" "), t("div", {
                    staticClass: "answer"
                }, e._l(e.exercise.questions, function(s, i) {
                    return t("block", {
                        key: i
                    }, [ t("span", {
                        staticClass: "answer-left"
                    }, [ e._v(e._s(s.questionStem) + ".") ]), e._v(" "), t("parser", {
                        staticClass: "answer-right",
                        attrs: {
                            html: s.questionAnswer,
                            mpcomid: "7_" + i
                        }
                    }) ], 1);
                })) ]), e._v(" "), t("div", {
                    staticClass: "analysis"
                }, [ e._m(2), e._v(" "), t("parser", {
                    attrs: {
                        html: e.exercise.exerciseAnalysis,
                        mpcomid: "8"
                    }
                }) ], 1) ]);
            },
            staticRenderFns: [ function() {
                var e = this.$createElement, s = this._self._c || e;
                return s("div", [ s("span", {
                    staticClass: "line"
                }), this._v("题目"), s("span", {
                    staticClass: "exercise-type"
                }, [ this._v("（填空题）") ]) ]);
            }, function() {
                var e = this.$createElement, s = this._self._c || e;
                return s("div", {
                    staticClass: "analysis-title"
                }, [ s("span", {
                    staticClass: "line"
                }), this._v("答案\n    ") ]);
            }, function() {
                var e = this.$createElement, s = this._self._c || e;
                return s("div", {
                    staticClass: "analysis-title"
                }, [ s("span", {
                    staticClass: "line"
                }), this._v("解析\n    ") ]);
            } ]
        };
    },
    m4OY: function(e, s, t) {
        var i = t("Rd1j"), c = t("/NlU"), a = t("ybqe")(i.a, c.a, function(e) {
            t("LdZK");
        }, null, null);
        s.a = a.exports;
    },
    opNd: function(e, s, t) {
        var i = t("b1mz"), c = (t("8e4C"), t("3pP7")), a = t("P6QM"), r = (t.n(a), t("VsUZ")), n = t("IcnI");
        s.a = {
            components: {
                "i-tag": c.a,
                "i-icon": i.a
            },
            props: {
                exercise: {
                    type: Object,
                    value: {
                        exerciseStems: null,
                        exerciseAnswer: null,
                        exerciseAnalysis: null
                    }
                }
            },
            data: function() {
                return {
                    text: "芝士库",
                    topic: "",
                    collectAll: [ {
                        color: "#ffc525",
                        type: "collection_fill"
                    }, {
                        color: "#999",
                        type: "collection"
                    } ],
                    status: 1,
                    collectExerciseIds: []
                };
            },
            onLoad: function() {
                this.topic = this.resetFill(this.exercise.exerciseStems), console.log(this.exercise, "题目信息"), 
                this.checkExerciseIsCollect();
            },
            watch: {
                exercise: function(e, s) {
                    if (e !== s) return e;
                }
            },
            methods: {
                resetFill: function(e) {
                    return e.replace(/\$\*\$([0-9])\$\*\$/g, function(e, s) {
                        return '<span style="text-decoration: underline;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;' + s + "&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span>";
                    });
                },
                checkExerciseIsCollect: function() {
                    this.collectExerciseIds = wx.getStorageSync("collectExerciseIds") || [], this.status = this.collectExerciseIds.indexOf(this.exercise.exerciseId) > -1 ? 0 : 1;
                },
                collectExercise: function() {
                    var e = this, s = this.exercise, t = s.exerciseProperty.knowledgeTags, i = s.exerciseId, c = 0 === this.status ? 1 : 0;
                    r.default.addCollectExercise({
                        majorId: t.length > 0 ? t[0].split(",")[0] : "759163208064962560",
                        chapterId: 1 === this.status ? 8 : "",
                        exerciseId: i,
                        collectFlag: c,
                        examCategory: 1
                    }, function(s) {
                        s.data.data && 200 === s.data.code && wx.showToast({
                            title: 0 === c ? "已收藏" : "已取消收藏",
                            duration: 1e3
                        }), e.collectFunc(c, i);
                    });
                },
                collectFunc: function(e, s) {
                    this.status = e, 0 === e ? this.collectExerciseIds.push(s) : this.collectExerciseIds.splice(this.collectExerciseIds.indexOf(s), 1), 
                    wx.setStorageSync("collectExerciseIds", this.collectExerciseIds);
                },
                handleFeedback: function() {
                    var e = this.exercise, s = e.exerciseProperty.knowledgeTags, t = e.exerciseId;
                    n.a.commit("setFeedbackMajorId", s.length > 0 ? s[0].split(",")[0] : "759163208064962560"), 
                    n.a.commit("setFeedbackExerciseId", t), wx.navigateTo({
                        url: "/pages/feedback/main"
                    });
                }
            }
        };
    },
    "q/k5": function(e, s) {},
    "r/9Q": function(e, s, t) {
        var i = t("mvHQ"), c = t.n(i), a = t("WvcL"), r = t("3waA"), n = t("m4OY"), l = t("fxwN"), o = t("Xh4d"), d = t("Gnhm"), h = t("kF/J"), m = t("tXM+"), x = t("VsUZ"), p = t("8e4C"), u = t("oFuF");
        s.a = {
            components: {
                "i-tabs": a.a,
                "i-tab": r.a,
                "i-spin": n.a,
                PhotoChoice: l.a,
                PhotoShort: o.a,
                PhotoFill: d.a,
                PhotoJudge: h.a,
                TipsPage: m.a
            },
            data: function() {
                return {
                    src: null,
                    editExercise: void 0,
                    answerTitile: p.a,
                    current: 1,
                    loading: !0,
                    errorCode: "",
                    imgMode: "widthFix",
                    notCheck: !0,
                    responseExercise: [],
                    orientation: 1,
                    isDark: wx.getStorageSync("isDark")
                };
            },
            onLoad: function(e) {
                this.isDark = Object(u.onChangeDark)();
                var s = JSON.parse(e.params);
                console.log(e), s.isShare ? (this.notCheck = !1, this.initData(s), this.responseExercise = JSON.parse(decodeURIComponent(s.responseExercise)), 
                this.errorCode = s.errorCode, this.loading = s.loading, this.handleChangeScroll(this.current)) : (this.loading = !0, 
                this.notCheck = !0, this.errorCode = "", this.initData(s), this.uploadPhoto());
            },
            onShareAppMessage: function(e) {
                return {
                    title: "答案就在这里，还不快来试试~",
                    path: "/pages/search/main?params=" + c()({
                        img: this.src,
                        width: this.width,
                        height: this.height,
                        loading: this.loading,
                        errorCode: this.errorCode,
                        responseExercise: encodeURIComponent(c()(this.responseExercise)),
                        isShare: !0
                    })
                };
            },
            methods: {
                initData: function(e) {
                    this.current = 1, this.src = e.img, this.width = e.width, this.height = e.height, 
                    this.orientation = e.orientation, e.height > 400 ? this.imgMode = "heightFix" : this.imgMode = "widthFix";
                },
                againPhoto: function() {
                    wx.redirectTo({
                        url: "/pages/camera/main"
                    });
                },
                handleChangeScroll: function(e) {
                    this.editExercise = 2 === e ? this.responseExercise.filter(function(e, s) {
                        return s > 0;
                    }) : this.responseExercise.filter(function(e, s) {
                        return 0 === s;
                    });
                },
                uploadPhoto: function() {
                    var e = this;
                    this.loading = !0, x.default.upFiles({
                        filePath: this.src
                    }, function(s) {
                        if (401 !== s.statusCode) {
                            var t = JSON.parse(s.data);
                            if (e.errorCode = t.code, e.notCheck = !1, 200 !== t.code) return !1;
                            e.responseExercise = t.data.exercises, e.editExercise = t.data.exercises.filter(function(e, s) {
                                return 0 === s;
                            }), e.loading = !1;
                        } else Object(u.repeatLogin)(function() {
                            e.uploadPhoto();
                        });
                    });
                },
                imgtap: function(e) {
                    wx.previewImage({
                        current: this.src,
                        urls: [ this.src ]
                    });
                }
            }
        };
    },
    rD1g: function(e, s, t) {
        s.a = {
            render: function() {
                var e = this, s = e.$createElement, t = e._self._c || s;
                return t("div", {
                    class: [ "search", e.isDark && "dark" ]
                }, [ t("div", {
                    class: [ "scan", "widthFix" == e.imgMode ? "photo-img-wf" : "photo-img-hf" ]
                }, [ t("img", {
                    class: [ 2 === e.orientation ? "img-view" : "" ],
                    attrs: {
                        src: e.src,
                        mode: e.imgMode,
                        eventid: "0"
                    },
                    on: {
                        click: e.imgtap
                    }
                }), e._v(" "), e.notCheck ? t("div", {
                    staticClass: "scan-line"
                }, [ t("img", {
                    attrs: {
                        src: "//static.yanzhishi.cn/images/wechat/scan.png",
                        mode: "widthFix",
                        alt: ""
                    }
                }) ]) : e._e() ]), e._v(" "), t("div", [ t("i-tabs", {
                    attrs: {
                        "i-class": "answer-content",
                        scroll: "true",
                        eventid: "1",
                        mpcomid: "1"
                    },
                    on: {
                        change: e.handleChangeScroll
                    },
                    model: {
                        value: e.current,
                        callback: function(s) {
                            e.current = s;
                        },
                        expression: "current"
                    }
                }, e._l(e.answerTitile, function(e, s) {
                    return t("i-tab", {
                        key: s,
                        attrs: {
                            "item-key": e.value,
                            title: e.label,
                            mpcomid: "0_" + s
                        }
                    });
                })), e._v(" "), e.loading ? t("div", {
                    staticClass: "mt-space"
                }, [ e.notCheck ? t("i-spin", {
                    attrs: {
                        "i-class": "spin",
                        size: "large",
                        mpcomid: "7"
                    }
                }) : t("block", [ t("tips-page", {
                    attrs: {
                        error: e.errorCode,
                        mpcomid: "6"
                    }
                }) ], 1) ], 1) : t("block", [ e._l(e.editExercise, function(s, i) {
                    return t("div", {
                        key: i,
                        class: [ 0 !== i ? "space-line" : "" ]
                    }, [ 1 == s.exerciseType || 2 == s.exerciseType ? t("photo-choice", {
                        attrs: {
                            exercise: s,
                            mpcomid: "2_" + i
                        }
                    }) : e._e(), e._v(" "), 4 == s.exerciseType ? t("photo-short", {
                        attrs: {
                            exercise: s,
                            mpcomid: "3_" + i
                        }
                    }) : e._e(), e._v(" "), 3 == s.exerciseType ? t("photo-fill", {
                        attrs: {
                            exercise: s,
                            mpcomid: "4_" + i
                        }
                    }) : e._e(), e._v(" "), 5 == s.exerciseType ? t("photo-judge", {
                        attrs: {
                            exercise: s,
                            mpcomid: "5_" + i
                        }
                    }) : e._e() ], 1);
                }), e._v(" "), t("div", {
                    staticClass: "exam-paper"
                }, [ t("img", {
                    attrs: {
                        src: "//static.yanzhishi.cn/images/wechat/taobao.png",
                        mode: "widthFix",
                        alt: "weixin"
                    }
                }), e._v(" "), t("div", {
                    staticClass: "qrcode-right"
                }, [ t("p", {
                    staticClass: "qrcode-title"
                }, [ e._v("淘宝搜索研芝士，立即拥有") ]), e._v(" "), t("p", {
                    staticClass: "qrcode-info"
                }, [ e._v("① 练透考点2000题的摘星题库") ]), e._v(" "), t("p", {
                    staticClass: "qrcode-info"
                }, [ e._v("② 完整版真题独立封装，体验全真考试场景") ]) ], 1) ]) ], 2) ], 1), e._v(" "), t("div", {
                    staticClass: "fix-bottom"
                }, [ t("div", {
                    attrs: {
                        eventid: "2"
                    },
                    on: {
                        click: e.againPhoto
                    }
                }, [ e._v("再拍一题") ]) ]) ]);
            },
            staticRenderFns: []
        };
    },
    rzTJ: function(e, s) {},
    tKms: function(e, s, t) {
        var i = t("b1mz"), c = (t("8e4C"), t("3pP7")), a = t("P6QM"), r = (t.n(a), t("VsUZ")), n = t("IcnI");
        s.a = {
            components: {
                "i-tag": c.a,
                "i-icon": i.a
            },
            props: {
                exercise: {
                    type: Object,
                    value: {
                        exerciseStems: null,
                        exerciseAnswer: null,
                        exerciseAnalysis: null
                    }
                }
            },
            onLoad: function() {
                console.log(this.exercise, "题目信息"), this.checkExerciseIsCollect();
            },
            data: function() {
                return {
                    text: "芝士库",
                    collectAll: [ {
                        color: "#ffc525",
                        type: "collection_fill"
                    }, {
                        color: "#999",
                        type: "collection"
                    } ],
                    status: 1,
                    collectExerciseIds: []
                };
            },
            watch: {
                exercise: function(e, s) {
                    if (e !== s) return e;
                }
            },
            methods: {
                checkExerciseIsCollect: function() {
                    this.collectExerciseIds = wx.getStorageSync("collectExerciseIds") || [], this.status = this.collectExerciseIds.indexOf(this.exercise.exerciseId) > -1 ? 0 : 1;
                },
                collectExercise: function() {
                    var e = this, s = this.exercise, t = s.exerciseProperty.knowledgeTags, i = s.exerciseId, c = 0 === this.status ? 1 : 0;
                    r.default.addCollectExercise({
                        majorId: t.length > 0 ? t[0].split(",")[0] : "759163208064962560",
                        chapterId: 1 === this.status ? 8 : "",
                        exerciseId: i,
                        collectFlag: c,
                        examCategory: 1
                    }, function(s) {
                        s.data.data && 200 === s.data.code && wx.showToast({
                            title: 0 === c ? "已收藏" : "已取消收藏",
                            duration: 1e3
                        }), e.collectFunc(c, i);
                    });
                },
                collectFunc: function(e, s) {
                    this.status = e, 0 === e ? this.collectExerciseIds.push(s) : this.collectExerciseIds.splice(this.collectExerciseIds.indexOf(s), 1), 
                    wx.setStorageSync("collectExerciseIds", this.collectExerciseIds);
                },
                handleFeedback: function() {
                    var e = this.exercise, s = e.exerciseProperty.knowledgeTags, t = e.exerciseId;
                    n.a.commit("setFeedbackMajorId", s.length > 0 ? s[0].split(",")[0] : "759163208064962560"), 
                    n.a.commit("setFeedbackExerciseId", t), wx.navigateTo({
                        url: "/pages/feedback/main"
                    });
                }
            }
        };
    }
}, [ "1kNa" ]);