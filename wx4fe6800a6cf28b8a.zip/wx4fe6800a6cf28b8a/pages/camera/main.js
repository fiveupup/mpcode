require("../../common/manifest.js"), require("../../common/vendor.js"), global.webpackJsonpMpvue([ 44 ], {
    "+9Uf": function(t, i, e) {
        i.a = {
            render: function() {
                var t = this, i = t.$createElement, e = t._self._c || i;
                return e("div", {
                    staticClass: "camera-view"
                }, [ t.isOk ? e("div", {
                    staticClass: "img-content"
                }, [ e("my-cropper", {
                    attrs: {
                        cutRatio: "0",
                        imageSrc: t.src,
                        cropperWidth: t.picWidth,
                        cropperTips: t.cropperTips,
                        eventid: "0",
                        mpcomid: "0"
                    },
                    on: {
                        close: t.resetPhoto,
                        cutImage: t.finishImg
                    }
                }) ], 1) : e("div", [ e("camera", {
                    attrs: {
                        devicePosition: "back",
                        flash: t.flash,
                        mpcomid: "12"
                    }
                }, [ e("cover-view", {
                    staticClass: "horizontal horizontal-1",
                    attrs: {
                        mpcomid: "1"
                    }
                }), t._v(" "), e("cover-view", {
                    staticClass: "horizontal horizontal-2",
                    attrs: {
                        mpcomid: "2"
                    }
                }), t._v(" "), e("cover-view", {
                    staticClass: "vertical vertical-1",
                    attrs: {
                        mpcomid: "3"
                    }
                }), t._v(" "), e("cover-view", {
                    staticClass: "vertical vertical-2",
                    attrs: {
                        mpcomid: "4"
                    }
                }), t._v(" "), e("cover-view", {
                    staticClass: "text-warn",
                    attrs: {
                        mpcomid: "5"
                    }
                }, [ t._v("\n        文字平行参考线\n      ") ]), t._v(" "), e("cover-view", {
                    class: [ "flashlight", "off" === t.flash ? "" : "flashlight-on" ],
                    attrs: {
                        eventid: "1",
                        mpcomid: "7"
                    },
                    on: {
                        click: t.changeLight
                    }
                }, [ e("cover-image", {
                    staticClass: "img",
                    attrs: {
                        src: "//static.yanzhishi.cn/images/wechat/shoudian@2x.png",
                        alt: "shoudian",
                        mpcomid: "6"
                    }
                }) ], 1), t._v(" "), e("cover-view", {
                    staticClass: "btn-photo",
                    attrs: {
                        mpcomid: "11"
                    }
                }, [ e("cover-view", {
                    staticClass: "outer",
                    attrs: {
                        eventid: "2",
                        mpcomid: "9"
                    },
                    on: {
                        click: t.takePhoto
                    }
                }, [ e("cover-view", {
                    staticClass: "inner",
                    attrs: {
                        mpcomid: "8"
                    }
                }) ], 1), t._v(" "), e("cover-image", {
                    staticClass: "album",
                    attrs: {
                        src: "//static.yanzhishi.cn/images/wechat/xiangce@2x.png",
                        alt: "picture",
                        eventid: "3",
                        mpcomid: "10"
                    },
                    on: {
                        click: t.choosePic
                    }
                }) ], 1) ], 1) ], 1) ]);
            },
            staticRenderFns: []
        };
    },
    A3mu: function(t, i, e) {
        var a = e("mvHQ"), s = e.n(a), o = e("b1mz"), n = e("oFuF");
        i.a = {
            components: {
                "i-icon": o.a
            },
            onLoad: function() {
                var t = this;
                this.cropperTips = "一次只拍一道题更准确 可拖拽边框裁剪", wx.setNavigationBarTitle({
                    title: "拍照搜题"
                }), this.isAnswer = !1, this.isOk = !1;
                var i = wx.getSystemInfoSync();
                this.picWidth = 2 * i.screenWidth + 10, this.isDark = Object(n.onChangeDark)(), 
                this.$mp.page.getOpenerEventChannel().on("params", function(i) {
                    t.isAnswer = i.isAnswer || !1, i.isAnswer && (t.cropperTips = "保持字迹清晰判卷更准确 可拖拽边框裁剪", 
                    wx.setNavigationBarTitle({
                        title: "作答拍照"
                    }));
                });
            },
            onShow: function() {
                console.log(2222), this.calePhone();
            },
            onUnload: function() {
                wx.stopAccelerometer();
            },
            data: function() {
                return {
                    src: null,
                    isOk: !1,
                    picWidth: 0,
                    flash: "off",
                    orientation: 1,
                    isDark: wx.getStorageSync("isDark"),
                    isAnswer: !1,
                    cropperTips: "一次只拍一道题更准确 可拖拽边框裁剪"
                };
            },
            methods: {
                calePhone: function() {
                    var t = this, i = Date.now();
                    wx.startAccelerometer(), wx.onAccelerometerChange(function(e) {
                        var a = Date.now();
                        if (!(a - i < 200)) {
                            i = a;
                            var s = void 0, o = 57.3 * Math.atan2(-e.x, Math.sqrt(e.y * e.y + e.z * e.z)), n = 57.3 * Math.atan2(e.y, e.z);
                            if (o > 50) s = n > -180 && n < -60 || n > 130 ? 1 : 0; else if (o > 0 && o < 30 || o < 0 && o > -30) {
                                var c = Math.abs(n);
                                s = (c > 155 || c < 25) && o > 1 ? 1 : 0;
                            } else s = 0;
                            t.orientation = 1 === s ? 2 : 1;
                        }
                    });
                },
                takePhoto: function() {
                    var t = this;
                    wx.stopAccelerometer();
                    var i = wx.createCameraContext();
                    this.isOk = !1, i.takePhoto({
                        quality: "high",
                        success: function(i) {
                            t.isOk = !0, t.src = i.tempImagePath;
                        }
                    });
                },
                resetPhoto: function() {
                    this.isOk = !1;
                },
                finishImg: function(t) {
                    var i = t.mp.detail, e = s()({
                        img: i.path,
                        width: i.width,
                        height: i.height,
                        orientation: this.orientation,
                        isShare: !1
                    });
                    if (this.isAnswer) {
                        var a = {
                            img: i.path,
                            width: i.width,
                            height: i.height,
                            orientation: this.orientation
                        };
                        wx.setStorageSync("answerImgOptions", a), wx.navigateBack({
                            delta: 1
                        });
                    } else wx.redirectTo({
                        url: "/pages/search/main?params=" + e
                    });
                },
                loadimage: function(t) {
                    this.cropper.imgReset();
                },
                choosePic: function() {
                    var t = this;
                    wx.chooseImage({
                        sourceType: [ "album" ],
                        success: function(i) {
                            t.isOk = !0, t.src = i.tempFilePaths[0];
                        }
                    });
                },
                changeLight: function() {
                    "off" === this.flash ? this.flash = "torch" : this.flash = "off";
                }
            }
        };
    },
    dDCq: function(t, i, e) {
        Object.defineProperty(i, "__esModule", {
            value: !0
        });
        var a = e("5nAL"), s = e.n(a), o = e("psUX"), n = e("sGGH");
        e.n(n), new s.a(o.a).$mount();
    },
    psUX: function(t, i, e) {
        var a = e("A3mu"), s = e("+9Uf"), o = e("ybqe")(a.a, s.a, function(t) {
            e("z4MC");
        }, null, null);
        i.a = o.exports;
    },
    z4MC: function(t, i) {}
}, [ "dDCq" ]);