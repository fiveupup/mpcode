require("../../common/manifest.js"), require("../../common/vendor.js"), global.webpackJsonpMpvue([ 19 ], {
    "6pd+": function(t, e, i) {
        var n = i("Afir"), s = i("WTOT"), o = i("ybqe")(n.a, s.a, function(t) {
            i("zdMc");
        }, "data-v-47485046", null);
        e.a = o.exports;
    },
    Afir: function(t, e, i) {
        var n = i("emV0"), s = i("oFuF"), o = i("VsUZ");
        e.a = {
            components: {
                FixedBottom: n.a
            },
            data: function() {
                return {
                    src: "//static.yanzhishi.cn/images/wechat/recruit.png",
                    text: "立即测试",
                    isClick: !1,
                    isComplete: !1,
                    isDark: wx.getStorageSync("isDark")
                };
            },
            onLoad: function() {
                this.isDark = Object(s.onChangeDark)();
            },
            onShow: function() {
                this.getJob();
            },
            methods: {
                beginTest: function() {
                    var t = this;
                    this.isComplete ? wx.showToast({
                        title: "您已完成提交，最快两个工作日内会联系你",
                        icon: "none",
                        duration: 2e3
                    }) : this.isClick || (this.isClick = !0, wx.setStorageSync("title", "助教招聘"), wx.navigateTo({
                        url: "/pages/fastExercise/main",
                        success: function(e) {
                            e.eventChannel.emit("params", {
                                type: 4
                            }), setTimeout(function() {
                                t.isClick = !1;
                            }, 1e3);
                        }
                    }));
                },
                getJob: function() {
                    var t = this;
                    o.default.getJobExercise({
                        examType: 5
                    }, function(e) {
                        200 === e.data.code ? t.isComplete = !1 : t.isComplete = !0;
                    });
                }
            }
        };
    },
    "UI4/": function(t, e, i) {
        Object.defineProperty(e, "__esModule", {
            value: !0
        });
        var n = i("5nAL"), s = i.n(n), o = i("6pd+");
        new s.a(o.a).$mount();
    },
    WTOT: function(t, e, i) {
        e.a = {
            render: function() {
                var t = this.$createElement, e = this._self._c || t;
                return e("div", {
                    class: [ "recruit", this.isDark && "dark" ]
                }, [ e("img", {
                    attrs: {
                        src: this.src,
                        mode: "widthFix",
                        alt: ""
                    }
                }), this._v(" "), e("fixed-bottom", {
                    attrs: {
                        text: this.text,
                        btnStyle: "background-color: #fa8c16; box-shadow: none;",
                        clickBtn: this.beginTest,
                        mpcomid: "0"
                    }
                }) ], 1);
            },
            staticRenderFns: []
        };
    },
    zdMc: function(t, e) {}
}, [ "UI4/" ]);