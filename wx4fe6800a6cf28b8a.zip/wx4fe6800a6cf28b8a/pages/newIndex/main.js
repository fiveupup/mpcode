require("../../common/manifest.js"), require("../../common/vendor.js"), global.webpackJsonpMpvue([ 4 ], {
    "+JLP": function(t, e, a) {
        var i = a("mvHQ"), n = a.n(i), s = a("PJh5"), o = (a.n(s), a("WvcL")), c = a("3waA"), r = a("8e4C"), l = a("VsUZ"), d = a("oFuF"), u = a("K31e"), h = a("MIgH"), m = a("v2NE"), g = a("K4hA"), v = a("gSTp"), p = a("UCfo"), f = a("WdeT"), w = a("sa8u"), x = a("IcnI"), b = requirePlugin("live-player-plugin");
        e.a = {
            components: {
                Login: u.a,
                shareGuide: h.a,
                update: v.a,
                CardMark: p.a,
                PageLoading: m.a,
                LiveAnimation: g.a,
                PicModal: f.a,
                ShareCard: w.a,
                "i-tabs": o.a,
                "i-tab": c.a
            },
            data: function() {
                return {
                    userStatus: {
                        modeIndex: -1,
                        mark_isShow: !1
                    },
                    tabs: [],
                    entrys: r.e,
                    activeIndex: 0,
                    oldMajorId: "",
                    currentIndex: 0,
                    chapterId: "",
                    chapter: [],
                    notLogin: !1,
                    addImitateNum: 0,
                    addFastNum: 0,
                    isClick: !1,
                    modeType: 0,
                    loading: !0,
                    cardModal: !1,
                    bannerList: [],
                    newsArticle: [],
                    waitingForData: !1,
                    categoryShow: !1,
                    successTips: !1,
                    showAdvertisement: !1,
                    adSrc: null,
                    isNotPhone: wx.getStorageSync("isNotPhone"),
                    isDark: wx.getStorageSync("isDark"),
                    isOpenShare: wx.getStorageSync("isOpenShare"),
                    useSel: !1,
                    roomInfos: [],
                    isLiveActive: wx.getStorageSync("isLiveActive") || !1,
                    liveCourse: {
                        bannerUrl: "",
                        bannerName: ""
                    },
                    isInstitution: !1,
                    userId: null,
                    shareShow: !0,
                    visibleShare: !1,
                    isScroll: !0
                };
            },
            computed: {
                changeFlag: function() {
                    return x.a.state.fixedSubjectFlag;
                }
            },
            onLoad: function(t) {
                var e = this;
                if (this.bannerList = wx.getStorageSync("bannerList") || [], this.chapter = wx.getStorageSync("infoList") || [], 
                this.tabs = wx.getStorageSync("majorCustomList") || [], t && t.answers) wx.showModal({
                    title: "未做完",
                    content: "是否保存到草稿",
                    confirmText: "保存草稿",
                    confirmColor: "#ffcc00",
                    success: function(e) {
                        e.confirm && l.default.submitExam(t, function(t) {
                            console.log(t);
                        });
                    }
                }); else if (t && t.identifier) {
                    var a = this;
                    wx.login({
                        success: function(e) {
                            a.addHelper(t.identifier, e.code);
                        }
                    });
                }
                setTimeout(function() {
                    e.getDomTop();
                }, 5e3);
            },
            onShareAppMessage: function() {
                return this.isInstitution && this.userId ? {
                    title: "推荐一个超好用的电气考研刷题小程序，海量真题任你刷！",
                    path: "/pages/newIndex/main?params=" + n()({
                        userId: this.userId
                    })
                } : {
                    title: "推荐一个超好用的电气考研刷题小程序，海量真题任你刷！"
                };
            },
            onShareTimeline: function() {
                return this.isInstitution && this.userId ? {
                    title: "推荐一个超好用的电气考研刷题小程序，海量真题任你刷！",
                    path: "/pages/newIndex/main?params=" + n()({
                        userId: this.userId
                    })
                } : {
                    title: "推荐一个超好用的电气考研刷题小程序，海量真题任你刷！"
                };
            },
            onShow: function() {
                var t = this;
                this.isDark = Object(d.onChangeDark)(), this.isClick = !1, this.liveCourse = {
                    bannerUrl: "",
                    bannerName: ""
                }, this.isDark ? this.entrys = r.d : this.entrys = r.e, this.$root.$mp.page.getTabBar().viewChange(this.isDark), 
                this.$root.$mp.page.getTabBar().setData({
                    selected: 0
                }), Object(d.silentLogin)().then(function() {
                    t.getBanner(), t.getArticle(), t.getUserDetail(), t.changeFlag && (t.chapter = [], 
                    t.activeIndex = 0, t.oldMajorId = 0, t.getMajorList(), x.a.commit("setFixedSubjectFlag", !1));
                });
            },
            methods: {
                addHelper: function(t, e) {
                    var a = this;
                    l.default.addHelper({
                        identifier: t,
                        code: e
                    }, function(t) {
                        200 == t.data.code && t.data.data ? a.successTips = !0 : wx.showToast({
                            title: t.data.msg,
                            icon: "none"
                        });
                    }, function(i) {
                        401 === i.status && Object(d.repeatLogin)(function() {
                            a.addHelper(t, e);
                        });
                    });
                },
                closeCard: function() {
                    this.successTips = !1;
                },
                checkOpenShare: function() {
                    var t = this;
                    l.default.getUserPermission({
                        roleType: 2
                    }, function(e) {
                        200 === e.data.code && e.data.data && e.data.data.includes("tiku_unlock") ? (wx.setStorageSync("isOpenShare", !0), 
                        t.isOpenShare = !0) : (wx.setStorageSync("isOpenShare", !1), t.isOpenShare = !1);
                    });
                },
                changeNotLogin: function(t) {
                    this.notLogin = t;
                },
                getMajorList: function() {
                    var t = this;
                    l.default.getMajorCustomList({}, function(e) {
                        t.tabs = 0 === e.data.data.length ? r.j : e.data.data.map(function(t) {
                            return {
                                id: t.majorId,
                                name: t.majorName,
                                examCategory: t.examCategory
                            };
                        }), t.activeIndex > t.tabs.length - 1 && (t.activeIndex = 0), wx.setStorageSync("majorCustomList", t.tabs), 
                        t.getChapter(t.tabs[t.activeIndex].id), x.a.commit("setMajorId", t.tabs[t.activeIndex].id), 
                        x.a.commit("setSubjectList", t.tabs), x.a.commit("setExamCategory", t.tabs[t.activeIndex].examCategory);
                    }, function(e) {
                        401 === e.status && (t.tabs = wx.getStorageSync("majorCustomList"), t.getChapter(t.tabs[t.activeIndex].id), 
                        x.a.commit("setSubjectList", t.tabs), Object(d.repeatLogin)(function() {
                            t.getMajorList();
                        }));
                    });
                },
                judgeLogin: function(t) {
                    Object(d.judgeLogin)().then(function(e) {
                        t(e);
                    });
                },
                getChapter: function(t) {
                    var e = this;
                    this.waitingForData = !0, l.default.getKnowledge({
                        majorId: t,
                        examType: Object(d.checkExamType)(this.modeType, this.tabs[this.activeIndex].examCategory)
                    }, function(t) {
                        e.loading = !1, e.waitingForData = !1;
                        var a = {
                            addImitateNum: 0,
                            addFastNum: 0
                        };
                        e.chapter = t.data.data.map(function(t, e) {
                            return 2 != e && 3 != e || (a.addImitateNum += parseInt(t.completePeopleNumber)), 
                            a.addFastNum += parseInt(t.completePeopleNumber), t.completePeopleNumber = parseInt(t.completePeopleNumber), 
                            t;
                        }).sort(function(t, e) {
                            return t.sort - e.sort;
                        }), wx.setStorageSync("infoList", e.chapter), 0 === e.modeType && (a.addImitateNum = parseInt(a.addImitateNum / 50), 
                        a.addFastNum = parseInt(a.addFastNum / 110), setTimeout(function() {
                            var t = setInterval(function() {
                                e.addImitateNum < a.addImitateNum ? e.addImitateNum += 2 : clearInterval(t);
                            }, 1), i = setInterval(function() {
                                e.addFastNum < a.addFastNum ? e.addFastNum += 2 : clearInterval(i);
                            }, 1);
                        }, 4e3));
                    }, function(a) {
                        401 === a.status && Object(d.repeatLogin)(function() {
                            e.getChapter(t);
                        });
                    });
                },
                tabClick: function(t) {
                    var e = this.waitingForData;
                    this.oldMajorId, e || (this.activeIndex = t, this.oldMajorId = t, this.getChapter(this.tabs[t].id), 
                    x.a.commit("setMistakeCurrent", t));
                },
                go: function(t) {
                    var e = this;
                    Object(d.judgeLogin)().then(function() {
                        var a = {
                            0: "practice",
                            1: "camera",
                            2: "official",
                            3: "course"
                        }[t];
                        2 === t && x.a.commit("setExamCategory", 1), 1 !== t ? e.isClick || (e.isClick = !0, 
                        wx.setStorageSync("isMember", !1), wx.setStorageSync("title", "快速刷题"), wx.setStorageSync("isFastType", 1), 
                        wx.navigateTo({
                            url: "/pages/" + a + "/main",
                            success: function(t) {
                                t.eventChannel.emit("params", {
                                    type: 1,
                                    majorId: e.tabs[e.activeIndex].id,
                                    examCategory: e.tabs[e.activeIndex].examCategory,
                                    chapterId: 1,
                                    isDetailBack: !1
                                }), setTimeout(function() {
                                    e.isClick = !1;
                                }, 500);
                            }
                        })) : e.setCameraAuth();
                    });
                },
                changeChapter: function(t, e) {
                    var a = this;
                    this.isOpenShare, this.isClick || (x.a.commit("setExamCategory", this.tabs[this.activeIndex].examCategory), 
                    x.a.commit("setMajorId", this.tabs[this.activeIndex].id), this.isClick = !0, Object(d.judgeLogin)().then(function() {
                        a.chapterId = t.id, wx.setStorageSync("title", t.name), wx.setStorageSync("isFastType", 1);
                        var e = "fastExercise";
                        0 === a.modeType && (e = "practice"), wx.navigateTo({
                            url: "/pages/" + e + "/main",
                            success: function(t) {
                                t.eventChannel.emit("params", {
                                    type: 1,
                                    majorId: a.tabs[a.activeIndex].id,
                                    examCategory: a.tabs[a.activeIndex].examCategory,
                                    chapterId: a.chapterId
                                });
                            }
                        });
                    }));
                },
                changeMode: function() {
                    this.modeType = 1 === this.modeType ? 0 : 1, 1 === this.modeType ? wx.showToast({
                        title: "已进入测评模式",
                        icon: "loading",
                        duration: 300
                    }) : wx.showToast({
                        title: "已经入练习模式",
                        icon: "loading",
                        duration: 300
                    }), this.getChapter(this.tabs[this.activeIndex].id);
                },
                viewDetail: function(t) {
                    var e = this;
                    if (!this.isClick) switch (this.isClick = !0, t.bannerType) {
                      case 1:
                        Object(d.judgeLogin)().then(function() {
                            wx.navigateTo({
                                url: "/pages/video/main",
                                success: function(e) {
                                    e.eventChannel.emit("params", {
                                        type: t.bannerType,
                                        code: t.courseCode
                                    });
                                }
                            });
                        });
                        break;

                      case 2:
                        Object(d.judgeLogin)().then(function() {
                            wx.navigateTo({
                                url: "/pages/courseDetail/main",
                                success: function(e) {
                                    e.eventChannel.emit("params", {
                                        type: t.bannerType,
                                        code: t.courseCode,
                                        detailUrl: t.detailUrl,
                                        buyUrl: t.buyUrl
                                    });
                                }
                            });
                        });
                        break;

                      case 3:
                        wx.navigateTo({
                            url: "/pages/autumnReport/main"
                        });
                        break;

                      case 6:
                        this.viewNewsDetail({
                            articleUrl: t.detailUrl
                        });
                        break;

                      case 7:
                        Object(d.judgeLogin)().then(function() {
                            wx.setStorageSync("title", "极客挑战赛"), wx.navigateTo({
                                url: "/pages/fastExercise/main",
                                success: function(t) {
                                    t.eventChannel.emit("params", {
                                        type: 5
                                    });
                                }
                            });
                        });
                        break;

                      case 8:
                        Object(d.judgeLogin)().then(function() {
                            e.jumpLive();
                        });
                        break;

                      default:
                        console.log("无跳转"), this.isClick = !1;
                    }
                },
                closeVip: function() {
                    this.cardModal = !1;
                },
                copyWechat: function() {
                    wx.setClipboardData({
                        data: "yanzhishi2020",
                        success: function(t) {
                            console.log(t);
                        }
                    });
                },
                getMemberExam: function() {
                    var t = this;
                    this.isClick || (this.isClick = !0, l.default.getMoocExam({
                        majorId: this.tabs[this.activeIndex].id
                    }, function(e) {
                        x.a.commit("setMemberType", 1), x.a.commit("setIsFromChannel", !1), wx.navigateTo({
                            url: "/pages/member/main",
                            success: function(a) {
                                a.eventChannel.emit("params", {
                                    majorId: t.tabs[t.activeIndex].id,
                                    result: e.data
                                });
                            }
                        }), t.isClick = !1;
                    }, function(e) {
                        t.isClick = !1, 405 === e.status && (t.cardModal = !0), 401 === e.status && Object(d.repeatLogin)(function() {
                            t.getMemberExam();
                        });
                    }));
                },
                getBanner: function() {
                    var t = this;
                    l.default.getBannerList({}, function(e) {
                        t.bannerList = e.data.sort(function(t, e) {
                            return t.bannerSort - e.bannerSort;
                        }).filter(function(t) {
                            return 0 !== t.bannerType;
                        });
                        var a = e.data.filter(function(t) {
                            return 0 === t.bannerType;
                        }), i = e.data.find(function(t) {
                            return 8 === t.bannerType;
                        });
                        i ? (t.liveCourse = i, t.bannerList = [ i ], t.roomInfos = [ {
                            roomId: i.courseCode
                        } ], t.getLiveCourse()) : (t.isLiveActive = !1, wx.setStorageSync("isLiveActive", !1));
                        var n = wx.getStorageSync("storageAdUrl");
                        a.length > 0 && n !== a[0].bannerUrl && (t.showAdvertisement = !0, t.adSrc = a[0].bannerUrl), 
                        wx.getStorageSync("token").access_token && t.checkOpenShare();
                    }, function(e) {
                        401 === e.status && Object(d.repeatLogin)(function() {
                            t.getBanner();
                        });
                    });
                },
                viewNews: function() {
                    wx.navigateTo({
                        url: "/pages/news/main"
                    });
                },
                viewNewsDetail: function(t) {
                    x.a.commit("setArticleUrl", t.articleUrl), wx.navigateTo({
                        url: "/pages/newsDetail/main"
                    });
                },
                getArticle: function() {
                    var t = this;
                    l.default.getArticleList({
                        articleType: ""
                    }, function(e) {
                        t.newsArticle = e.data.sort(function(t, e) {
                            return t.articleSort - e.articleSort;
                        });
                    }, function(e) {
                        401 === e.status && Object(d.repeatLogin)(function() {
                            t.getArticle();
                        });
                    });
                },
                showCategory: function() {
                    var t = this;
                    this.isClick || (this.isClick = !0, wx.navigateTo({
                        url: "/pages/category/main",
                        success: function(e) {
                            t.isClick = !1;
                        }
                    }));
                },
                closeAdvertisement: function() {
                    this.showAdvertisement = !1, wx.setStorageSync("storageAdUrl", this.adSrc);
                },
                setCameraAuth: function() {
                    var t = this;
                    wx.getSetting({
                        success: function(e) {
                            wx.authorize({
                                scope: "scope.camera",
                                success: function(e) {
                                    t.useSel = !0, wx.navigateTo({
                                        url: "/pages/camera/main"
                                    });
                                },
                                fail: function() {
                                    t.useSel = !0;
                                }
                            });
                        },
                        complete: function(e) {
                            e.authSetting["scope.camera"] || t.useSel && wx.openSetting();
                        }
                    });
                },
                getLiveCourse: function() {
                    var t = this, e = this.roomInfos;
                    b.getLiveStatus({
                        room_id: e[0].roomId
                    }).then(function(e) {
                        t.isLiveActive = 101 === e.liveStatus, wx.setStorageSync("isLiveActive", t.isLiveActive), 
                        console.log(e);
                    });
                },
                jumpLiveBefore: function() {
                    var t = this;
                    Object(d.judgeLogin)().then(function() {
                        t.jumpLive();
                    });
                },
                jumpLive: Object(d.throttle)(function() {
                    var t = this.roomInfos, e = this.isInstitution, a = this.userId;
                    if (0 !== t.length) {
                        var i = t[0].roomId;
                        b.getOpenid({
                            room_id: i
                        }).then(function(t) {
                            var s = {};
                            e && (s.userId = a);
                            var o = encodeURIComponent(n()(s));
                            wx.navigateTo({
                                url: "plugin-private://wx2b03c6e691cd7370/pages/live-player-plugin?room_id=" + i + "&custom_params=" + o
                            });
                        });
                    }
                }),
                getUserDetail: function() {
                    var t = this;
                    l.default.getUserDetail({}, function(e) {
                        var a = e.data.data, i = a.roleList, n = a.userId, s = a.nickName, o = a.phone, c = a.previewUrl;
                        t.isInstitution = !!i.find(function(t) {
                            return "role_institution" === t.roleCode;
                        }), t.userId = n, c.indexOf("http://wxfile://") > -1 && (c = c.slice(7, c.length)), 
                        wx.setStorageSync("userInfo", {
                            name: s,
                            phone: o,
                            avatarUrl: c
                        });
                    });
                },
                shareOpen: function() {
                    this.shareShow = !1;
                },
                shareJump: function() {
                    this.shareShow ? (this.visibleShare = !0, this.isScroll = !1) : this.shareShow = !0;
                },
                getDomTop: function() {
                    var t = wx.createSelectorQuery();
                    t.select("#newIndex").boundingClientRect(), t.selectViewport().scrollOffset(), t.exec(function(t) {
                        console.log(t);
                    });
                }
            }
        };
    },
    "17/H": function(t, e) {},
    "1eJK": function(t, e, a) {
        e.a = {
            render: function() {
                var t = this, e = t.$createElement, a = t._self._c || e;
                return t.showUpdate ? a("div", {
                    staticClass: "app-update"
                }, [ a("div", {
                    staticClass: "update-card"
                }, [ a("img", {
                    attrs: {
                        src: "//static.yanzhishi.cn/images/wechat/update.png",
                        mode: "widthFix"
                    }
                }), t._v(" "), a("div", {
                    staticClass: "update-content"
                }, [ a("p", [ t._v("【新增】增加了新功能，等你来探索") ]), t._v(" "), a("p", [ t._v("【优化】交互优化、UI优化") ]), t._v(" "), a("p", [ t._v("【修复】修复一些已知bug") ]), t._v(" "), a("div", {
                    staticClass: "submit",
                    attrs: {
                        eventid: "0"
                    },
                    on: {
                        click: t.submit
                    }
                }, [ t._v("立即体验") ]) ], 1) ]) ]) : t._e();
            },
            staticRenderFns: []
        };
    },
    "3oP4": function(t, e) {},
    "4ZfK": function(t, e, a) {
        e.a = {
            render: function() {
                var t = this, e = t.$createElement, a = t._self._c || e;
                return a("div", {
                    staticClass: "share-canvas"
                }, [ a("div", {
                    staticClass: "share-canvas__inner"
                }, [ a("canvas", {
                    style: t.styleCanvas,
                    attrs: {
                        id: "shareCanvas",
                        type: "2d",
                        eventid: "0"
                    },
                    on: {
                        click: t.preview,
                        longpress: t.saveImg
                    }
                }) ]), t._v(" "), t.show ? a("div", {
                    class: [ "loading", t.show && "loading-top" ]
                }, [ a("page-loading", {
                    attrs: {
                        type: "canvas",
                        text: "云端生成中...",
                        mpcomid: "0"
                    }
                }) ], 1) : t._e(), t._v(" "), a("img", {
                    staticClass: "close",
                    attrs: {
                        src: "//static.yanzhishi.cn/images/wechat/close.png",
                        alt: "",
                        eventid: "1"
                    },
                    on: {
                        click: function(e) {
                            t.$emit("close");
                        }
                    }
                }) ]);
            },
            staticRenderFns: []
        };
    },
    "6Yjb": function(t, e) {},
    HSw9: function(t, e, a) {
        e.a = {
            props: {
                src: {
                    type: String,
                    default: "http://static.yanzhishi.cn/images/wechat/share_success.png"
                }
            },
            methods: {
                closeCard: function() {
                    this.$emit("close");
                }
            }
        };
    },
    JiRN: function(t, e, a) {
        e.a = {
            render: function() {
                var t = this.$createElement, e = this._self._c || t;
                return this.showGuide ? e("div", {
                    staticClass: "share-guide",
                    attrs: {
                        eventid: "1"
                    },
                    on: {
                        click: this.hideGuide
                    }
                }, [ e("img", {
                    staticClass: "guide-arrow",
                    attrs: {
                        src: "//static.yanzhishi.cn/images/wechat/share_arrow.png",
                        mode: "widthFix"
                    }
                }), this._v(" "), e("img", {
                    staticClass: "guide-info",
                    attrs: {
                        src: "//static.yanzhishi.cn/images/wechat/share_info.png",
                        mode: "widthFix"
                    }
                }), this._v(" "), e("img", {
                    staticClass: "guide-btn",
                    attrs: {
                        src: "//static.yanzhishi.cn/images/wechat/share_btn.png",
                        mode: "widthFix",
                        eventid: "0"
                    },
                    on: {
                        click: this.hideGuide
                    }
                }) ]) : this._e();
            },
            staticRenderFns: []
        };
    },
    K4hA: function(t, e, a) {
        var i = a("6Yjb"), n = a.n(i), s = a("ygIb"), o = a("ybqe")(n.a, s.a, function(t) {
            a("gpoq");
        }, null, null);
        e.a = o.exports;
    },
    MIgH: function(t, e, a) {
        var i = a("Xt+v"), n = a("JiRN"), s = a("ybqe")(i.a, n.a, function(t) {
            a("17/H");
        }, "data-v-7aac675d", null);
        e.a = s.exports;
    },
    "NZ/L": function(t, e, a) {
        var i = a("+JLP"), n = a("W/Qy"), s = a("ybqe")(i.a, n.a, function(t) {
            a("PA6n");
        }, null, null);
        e.a = s.exports;
    },
    PA6n: function(t, e) {},
    Qfzc: function(t, e, a) {
        e.a = {
            data: function() {
                return {
                    updateManager: null,
                    showUpdate: !1
                };
            },
            onLoad: function() {
                if (wx.canIUse("getUpdateManager")) {
                    var t = this;
                    t.updateManager = wx.getUpdateManager(), t.updateManager.onCheckForUpdate(function(e) {
                        e.hasUpdate ? (t.updateManager.onUpdateReady(function() {
                            t.showUpdate = !0;
                        }), t.updateManager.onUpdateFailed(function() {
                            t.showUpdate = !1, wx.showModal({
                                title: "升级失败",
                                content: "新版本下载失败，请检查网络！",
                                showCancel: !1
                            });
                        })) : console.log("已是最新版本");
                    });
                }
            },
            methods: {
                submit: function() {
                    this.showUpdate = !1, this.updateManager.applyUpdate();
                }
            }
        };
    },
    "W/Qy": function(t, e, a) {
        e.a = {
            render: function() {
                var t = this, e = t.$createElement, a = t._self._c || e;
                return a("scroll-view", {
                    class: [ "new-index", t.isNotPhone && "not-phone", t.isDark && "dark" ],
                    attrs: {
                        id: "newIndex",
                        scrollY: t.isScroll,
                        eventid: "11"
                    },
                    on: {
                        scroll: t.shareOpen
                    }
                }, [ a("div", {
                    staticClass: "header"
                }, [ a("div", {
                    staticClass: "navigation"
                }), t._v(" "), a("div", {
                    staticClass: "tab-myself home-tab"
                }, [ a("i-tabs", {
                    attrs: {
                        iClass: "title-content",
                        scroll: "true",
                        eventid: "0",
                        mpcomid: "1"
                    },
                    on: {
                        change: t.tabClick
                    },
                    model: {
                        value: t.activeIndex,
                        callback: function(e) {
                            t.activeIndex = e;
                        },
                        expression: "activeIndex"
                    }
                }, t._l(t.tabs, function(t, e) {
                    return a("i-tab", {
                        key: e,
                        attrs: {
                            itemKey: e,
                            title: t.name,
                            mpcomid: "0_" + e
                        }
                    });
                })) ], 1), t._v(" "), a("category", {
                    attrs: {
                        show: t.categoryShow,
                        mpcomid: "2"
                    }
                }) ], 1), t._v(" "), a("div", {
                    staticClass: "banner"
                }, [ a("div", {
                    staticClass: "banner-content"
                }, [ a("div", {
                    staticClass: "img"
                }, [ t.isLiveActive && "" !== t.liveCourse.bannerUrl ? a("div", {
                    staticClass: "banner-swiper",
                    attrs: {
                        eventid: "2"
                    },
                    on: {
                        click: t.jumpLiveBefore
                    }
                }, [ a("img", {
                    staticClass: "banner-img",
                    attrs: {
                        src: t.liveCourse.bannerUrl,
                        alt: "banner"
                    }
                }), t._v(" "), a("div", {
                    staticClass: "live-course"
                }, [ a("p", {
                    staticClass: "title"
                }, [ t._v("\n              " + t._s(t.liveCourse.bannerName) + "正在直播\n            ") ]), t._v(" "), a("p", {
                    staticClass: "info"
                }, [ a("LiveAnimation", {
                    attrs: {
                        mpcomid: "3"
                    }
                }), t._v(" "), a("span", [ t._v("进入直播") ]) ], 1) ], 1) ]) : a("swiper", {
                    staticClass: "banner-swiper",
                    attrs: {
                        autoplay: "",
                        circular: ""
                    }
                }, t._l(t.bannerList, function(e, i) {
                    return a("swiper-item", {
                        key: i,
                        attrs: {
                            mpcomid: "4_" + i
                        }
                    }, [ a("img", {
                        staticClass: "banner-img",
                        attrs: {
                            src: e.bannerUrl,
                            alt: "banner",
                            eventid: "1_" + i
                        },
                        on: {
                            click: function(a) {
                                t.viewDetail(e);
                            }
                        }
                    }), t._v(" "), 5 === e.bannerType ? a("div", {
                        staticClass: "add-content"
                    }, [ a("div", {
                        staticClass: "add-week"
                    }, [ a("span", [ t._v("本") ]), t._v(" "), a("span", [ t._v("周") ]), t._v(" "), a("span", [ t._v("新") ]), t._v(" "), a("span", [ t._v("增") ]) ]), t._v(" "), a("div", {
                        staticClass: "add-num"
                    }, [ a("p", [ t._v("\n                  模拟题\n                  "), a("span", {
                        staticClass: "black-num"
                    }, [ t._v(t._s(t.addImitateNum)) ]), t._v("道\n                ") ]), t._v(" "), a("p", {
                        staticClass: "border-line"
                    }, [ t._v("\n                  快速刷题\n                  "), a("span", {
                        staticClass: "black-num"
                    }, [ t._v(t._s(t.addFastNum)) ]), t._v("道\n                ") ]) ], 1) ]) : t._e() ]);
                })), t._v(" "), a("div", {
                    staticClass: "category"
                }, t._l(t.entrys, function(e, i) {
                    return a("block", {
                        key: i
                    }, [ a("div", {
                        staticClass: "entry",
                        attrs: {
                            id: e.id,
                            eventid: "3_" + i
                        },
                        on: {
                            click: function(a) {
                                t.go(e.id);
                            }
                        }
                    }, [ a("div", [ a("img", {
                        attrs: {
                            src: e.img,
                            mode: "heightFix",
                            alt: "img"
                        }
                    }) ]), t._v(" "), a("p", [ t._v(t._s(e.name)) ]) ], 1) ]);
                })) ], 1) ]) ]), t._v(" "), t.loading ? a("div", {
                    staticClass: "chapter"
                }, [ a("page-loading", {
                    attrs: {
                        mpcomid: "5"
                    }
                }) ], 1) : a("div", {
                    staticClass: "chapter"
                }, t._l(t.chapter, function(e, i) {
                    return a("block", {
                        key: i
                    }, [ a("div", {
                        staticClass: "list",
                        attrs: {
                            id: i,
                            eventid: "4_" + i
                        },
                        on: {
                            click: function(a) {
                                t.changeChapter(e, i);
                            }
                        }
                    }, [ a("div", {
                        staticClass: "title"
                    }, [ a("img", {
                        staticClass: "dot",
                        attrs: {
                            src: "//static.yanzhishi.cn/images/elec/icon/elec.png",
                            alt: "cheese"
                        }
                    }), t._v(" "), a("span", [ t._v(t._s(e.name)) ]) ]), t._v(" "), a("div", {
                        staticClass: "num-info"
                    }, [ a("span", {
                        staticClass: "finish"
                    }, [ a("span", {
                        staticClass: "distance"
                    }, [ t._v("已刷" + t._s(e.completeExerciseNumber) + "道") ]) ]), t._v(" "), a("span", {
                        staticClass: "first"
                    }, [ t._v(t._s(e.completePeopleNumber) + "人完成") ]) ]), t._v(" "), a("img", {
                        staticClass: "right",
                        attrs: {
                            src: "//static.yanzhishi.cn/images/wechat/jiantou@2x.png",
                            alt: "arrow"
                        }
                    }) ]) ]);
                })), t._v(" "), a("login", {
                    attrs: {
                        userNotLogin: t.notLogin,
                        eventid: "5",
                        mpcomid: "6"
                    },
                    on: {
                        changeValue: t.changeNotLogin
                    }
                }), t._v(" "), a("share-guide", {
                    attrs: {
                        mpcomid: "7"
                    }
                }), t._v(" "), a("update", {
                    attrs: {
                        mpcomid: "8"
                    }
                }), t._v(" "), t.cardModal ? a("card-mark", {
                    attrs: {
                        eventid: "7",
                        mpcomid: "9"
                    },
                    on: {
                        close: t.closeVip
                    }
                }, [ a("div", {
                    staticClass: "card-body"
                }, [ a("p", [ t._v("童鞋，这是23电气考研《练透考点2000题》全年课程专用通道！") ]), t._v(" "), a("p", [ t._v("\n        如需开通请联系\n        "), a("br"), t._v("「\n        "), a("span", {
                    staticClass: "card-wechat",
                    attrs: {
                        eventid: "6"
                    },
                    on: {
                        click: t.copyWechat
                    }
                }, [ t._v("yanzhishi2020") ]), t._v("」\n      ") ], 1), t._v(" "), a("p", [ t._v("研芝士带你") ]), t._v(" "), a("p", [ t._v("搞定电气考研专业课所有考点！") ]) ], 1) ]) : t._e(), t._v(" "), t.successTips ? a("div", {
                    staticClass: "success-mask"
                }, [ a("div", [ a("img", {
                    staticClass: "img-tips",
                    attrs: {
                        src: "http://static.yanzhishi.cn/images/wechat/share_success.png",
                        mode: "widthFix",
                        alt: "success"
                    }
                }), t._v(" "), a("img", {
                    staticClass: "close",
                    attrs: {
                        src: "//static.yanzhishi.cn/images/wechat/close.png",
                        mode: "widthFix",
                        alt: "close",
                        eventid: "8"
                    },
                    on: {
                        click: t.closeCard
                    }
                }) ]) ]) : t._e(), t._v(" "), t.showAdvertisement ? a("pic-modal", {
                    attrs: {
                        src: t.adSrc,
                        eventid: "9",
                        mpcomid: "10"
                    },
                    on: {
                        close: t.closeAdvertisement
                    }
                }) : t._e(), t._v(" "), t.visibleShare ? a("ShareCard", {
                    attrs: {
                        eventid: "10",
                        mpcomid: "11"
                    },
                    on: {
                        close: function(e) {
                            t.visibleShare = !1, t.isScroll = !0;
                        }
                    }
                }) : t._e() ], 1);
            },
            staticRenderFns: []
        };
    },
    WdeT: function(t, e, a) {
        var i = a("HSw9"), n = a("kbHN"), s = a("ybqe")(i.a, n.a, function(t) {
            a("3oP4");
        }, "data-v-2a33617a", null);
        e.a = s.exports;
    },
    "Xt+v": function(t, e, a) {
        e.a = {
            data: function() {
                return {
                    showGuide: !0
                };
            },
            onLoad: function() {
                this.showGuide = "" === wx.getStorageSync("finishGuide");
            },
            methods: {
                hideGuide: function() {
                    wx.setStorageSync("finishGuide", !0), this.showGuide = !1;
                }
            }
        };
    },
    aImc: function(t, e, a) {
        Object.defineProperty(e, "__esModule", {
            value: !0
        });
        var i = a("NZ/L"), n = a("5nAL"), s = a.n(n), o = a("ltdW"), c = (a.n(o), a("ocgm"));
        a.n(c), new s.a(i.a).$mount();
    },
    f5Wi: function(t, e) {},
    gSTp: function(t, e, a) {
        var i = a("Qfzc"), n = a("1eJK"), s = a("ybqe")(i.a, n.a, function(t) {
            a("ndWo");
        }, "data-v-32802fc9", null);
        e.a = s.exports;
    },
    gpoq: function(t, e) {},
    kbHN: function(t, e, a) {
        e.a = {
            render: function() {
                var t = this.$createElement, e = this._self._c || t;
                return e("div", {
                    staticClass: "pic-modal",
                    attrs: {
                        eventid: "1"
                    },
                    on: {
                        click: this.closeCard
                    }
                }, [ e("img", {
                    staticClass: "img-tips",
                    attrs: {
                        src: this.src,
                        mode: "widthFix",
                        alt: "success"
                    }
                }), this._v(" "), e("span", {
                    staticClass: "close",
                    attrs: {
                        eventid: "0"
                    },
                    on: {
                        click: this.closeCard
                    }
                }) ]);
            },
            staticRenderFns: []
        };
    },
    ndWo: function(t, e) {},
    qKnX: function(t, e, a) {
        a("oFuF");
        var i = a("v2NE"), n = a("VsUZ");
        e.a = {
            components: {
                PageLoading: i.a
            },
            data: function() {
                return {
                    show: !0,
                    imgSrc: "",
                    style: "width: 300px",
                    styleCanvas: "width: 300px; height: 499px; position: fixed; top: -12000px;"
                };
            },
            onLoad: function() {
                var t = this;
                this.$nextTick(function() {
                    t.queryData();
                });
            },
            methods: {
                queryData: function() {
                    var t = this;
                    n.default.getExerciseDay({}, function(e) {
                        if (200 === e.data.code) {
                            var a = e.data.data, i = a.exerciseDay, n = a.answerTotal;
                            t.drawImg(i, n);
                        }
                    }, function(e) {
                        t.drawImg(0, 0);
                    }, !1);
                },
                drawImg: function(t, e) {
                    var a = this, i = this;
                    wx.createSelectorQuery().select("#shareCanvas").fields({
                        node: !0,
                        size: !0
                    }).exec(function(n) {
                        if (console.log(n), n[0]) {
                            var s = n[0].node, o = s.getContext("2d"), c = s.createImage();
                            c.onload = function() {
                                i.show = !1, i.styleCanvas = "width: 300px; height: 559px; border-radius: 6px", 
                                wx.getSystemInfoSync().windowWidth, wx.getSystemInfoSync().windowHeight;
                                var n = c.width, r = c.height;
                                s.width = n, s.height = r, o.drawImage(c, 0, 0), o.fillStyle = "#eea541", o.font = "62px Microsoft YaHei", 
                                o.fillText("我已坚持刷题", 250, 640), o.fillStyle = "#eea541", o.font = "bold 100px Microsoft YaHei", 
                                o.fillText(t, 640, 640), o.fillStyle = "#eea541", o.font = "62px Microsoft YaHei", 
                                o.fillText("天", 640 + 65 * t.toString().length, 640), o.font = "62px Microsoft YaHei", 
                                o.fillText("累计刷题", 280, 790), o.fillStyle = "#eea541", o.font = "bold 100px Microsoft YaHei", 
                                o.fillText(e, 540, 790), o.fillStyle = "#eea541", o.font = "62px Microsoft YaHei", 
                                o.fillText("道", 540 + 65 * e.toString().length, 790), a.circleImgOne(s, o, wx.getStorageSync("userInfo").avatarUrl, 440, 260, 120);
                            }, c.src = "../../static/tabbar/share_card.png";
                        }
                    });
                },
                circleImgOne: function(t, e, a, i, n, s) {
                    var o = this;
                    this.show = !1, this.styleCanvas = "width: 300px; height: 499px;";
                    var c = 2 * s, r = i + s, l = n + s;
                    e.arc(r, l, s, 0, 2 * Math.PI), e.strokeStyle = "#ffcc00", e.lineWidth = 15, e.stroke(), 
                    e.clip();
                    var d = t.createImage();
                    d.onload = function() {
                        e.drawImage(d, i, n, c, c), o.save(t);
                    }, d.src = a || "http://static.yanzhishi.cn/images/wechat/entry/logo.png";
                },
                save: function(t) {
                    var e = this;
                    wx.canvasToTempFilePath({
                        x: 0,
                        y: 0,
                        width: 300,
                        height: 559,
                        destWidth: 1125,
                        destHeight: 2098,
                        canvasId: "shareCanvas",
                        canvas: t,
                        quality: 1,
                        success: function(t) {
                            var a = t.tempFilePath;
                            e.imgSrc = a;
                        },
                        fail: function() {
                            console.log("canvasToTempFilePath fail");
                        }
                    });
                },
                preview: function() {
                    var t = this.imgSrc;
                    wx.previewImage({
                        current: t,
                        urls: [ t ]
                    });
                },
                saveImg: function() {
                    var t = this.imgSrc, e = this, a = function() {
                        wx.saveImageToPhotosAlbum({
                            filePath: t,
                            success: function(t) {
                                wx.showToast({
                                    title: "保存成功"
                                }), e.$emit("close");
                            },
                            fail: function(t) {
                                wx.showToast({
                                    title: "保存失败",
                                    icon: "none"
                                });
                            }
                        });
                    };
                    wx.getSetting({
                        success: function(t) {
                            t.authSetting["scope.writePhotosAlbum"] ? a() : wx.authorize({
                                scope: "scope.writePhotosAlbum",
                                success: function() {
                                    a();
                                },
                                fail: function(t) {
                                    wx.showToast({
                                        title: "请在「右上角」-「设置」中打开授权权限哦",
                                        icon: "none",
                                        duration: 3e3
                                    });
                                }
                            });
                        },
                        fail: function(t) {
                            console.log(t);
                        }
                    });
                }
            }
        };
    },
    sa8u: function(t, e, a) {
        var i = a("qKnX"), n = a("4ZfK"), s = a("ybqe")(i.a, n.a, function(t) {
            a("f5Wi");
        }, null, null);
        e.a = s.exports;
    },
    ygIb: function(t, e, a) {
        e.a = {
            render: function() {
                return this.$createElement, this._self._c, this._m(0);
            },
            staticRenderFns: [ function() {
                var t = this.$createElement, e = this._self._c || t;
                return e("div", {
                    staticClass: "live-animation"
                }, [ e("div", {
                    staticClass: "box move1"
                }), this._v(" "), e("div", {
                    staticClass: "box move2"
                }), this._v(" "), e("div", {
                    staticClass: "box move3"
                }) ]);
            } ]
        };
    }
}, [ "aImc" ]);