require("../../common/manifest.js"), require("../../common/vendor.js"), global.webpackJsonpMpvue([ 12 ], {
    DTFy: function(a, t, n) {
        var s = n("vE68"), e = n("THvY"), i = n("ybqe")(s.a, e.a, function(a) {
            n("MxJU");
        }, "data-v-2baead78", null);
        t.a = i.exports;
    },
    MxJU: function(a, t) {},
    THvY: function(a, t, n) {
        t.a = {
            render: function() {
                var a = this, t = a.$createElement, n = a._self._c || t;
                return n("div", {
                    class: [ "top-ranking", a.isDark && "dark" ]
                }, [ n("img", {
                    staticClass: "banner",
                    attrs: {
                        src: a.isDark ? "//static.yanzhishi.cn/images/wechat/personal/elec_top_banner_black.png" : "//static.yanzhishi.cn/images/wechat/personal/elec_top_banner.png",
                        alt: "top_banner",
                        mode: "widthFix"
                    }
                }), a._v(" "), n("div", {
                    staticClass: "container"
                }, [ n("div", {
                    staticClass: "content"
                }, a._l(a.topData, function(t, s) {
                    return n("div", {
                        key: s,
                        staticClass: "list"
                    }, [ n("div", [ n("span", {
                        staticClass: "icon"
                    }, [ 0 === s ? n("img", {
                        attrs: {
                            src: "http://static.yanzhishi.cn/images/wechat/personal/top1@2x.png",
                            alt: "",
                            mode: "widthFix"
                        }
                    }) : 1 === s ? n("img", {
                        attrs: {
                            src: "http://static.yanzhishi.cn/images/wechat/personal/top2@2x.png",
                            alt: "",
                            mode: "widthFix"
                        }
                    }) : 2 === s ? n("img", {
                        attrs: {
                            src: "http://static.yanzhishi.cn/images/wechat/personal/top3@2x.png",
                            alt: "",
                            mode: "widthFix"
                        }
                    }) : n("span", [ a._v(a._s(s + 1)) ]) ]), a._v(" "), n("img", {
                        staticClass: "avatar",
                        attrs: {
                            src: t.previewUrl,
                            alt: ""
                        }
                    }), a._v(" "), n("span", {
                        staticClass: "username"
                    }, [ a._v(a._s(t.name)) ]) ]), a._v(" "), n("span", {
                        staticClass: "total"
                    }, [ a._v(a._s(t.answerTotal) + " 题") ]) ]);
                })) ]) ]);
            },
            staticRenderFns: []
        };
    },
    mQpX: function(a, t, n) {
        Object.defineProperty(t, "__esModule", {
            value: !0
        });
        var s = n("5nAL"), e = n.n(s), i = n("DTFy");
        new e.a(i.a).$mount();
    },
    vE68: function(a, t, n) {
        var s = n("VsUZ"), e = n("oFuF");
        t.a = {
            name: "TopRanking",
            data: function() {
                return {
                    topData: [],
                    isDark: wx.getStorageSync("isDark")
                };
            },
            onShow: function() {
                this.isDark = Object(e.onChangeDark)(), this.getTopData();
            },
            methods: {
                getTopData: function() {
                    var a = this;
                    s.default.getTopHundred({}, function(t) {
                        a.topData = t.data.data;
                    });
                }
            }
        };
    }
}, [ "mQpX" ]);