require("../../common/manifest.js"), require("../../common/vendor.js"), global.webpackJsonpMpvue([ 13 ], {
    "2o6m": function(t, s, a) {
        Object.defineProperty(s, "__esModule", {
            value: !0
        });
        var i = a("5nAL"), n = a.n(i), e = a("uHk4");
        new n.a(e.a).$mount();
    },
    CTw8: function(t, s, a) {
        var i = a("oFuF"), n = a("K31e");
        s.a = {
            components: {
                Login: n.a
            },
            data: function() {
                return {
                    isLogin: !1,
                    isClick: !1,
                    notLogin: !1,
                    userInfo: wx.getStorageSync("userInfo"),
                    isDark: wx.getStorageSync("isDark")
                };
            },
            onLoad: function() {
                this.isDark = Object(i.onChangeDark)(), this.judgeLogin();
            },
            onShareAppMessage: function() {
                return {
                    title: "您收到一份全国计算机专业考研学生暑期刷题&错题报告"
                };
            },
            onShareTimeline: function() {
                return {
                    title: "您收到一份全国计算机专业考研学生暑期刷题&错题报告"
                };
            },
            methods: {
                beginAnswer: function() {
                    var t = this;
                    this.isLogin ? this.isClick || (this.isClick = !0, wx.setStorageSync("title", "错误率Top20"), 
                    wx.navigateTo({
                        url: "/pages/fastExercise/main",
                        success: function(s) {
                            s.eventChannel.emit("params", {
                                type: 5
                            }), setTimeout(function() {
                                t.isClick = !1;
                            }, 1e3);
                        }
                    })) : this.notLogin = !0;
                },
                changeNotLogin: function(t) {
                    this.notLogin = t, this.judgeLogin();
                },
                judgeLogin: function() {
                    var t = this;
                    Object(i.judgeLogin)().then(function() {
                        t.isLogin = !0;
                    }).catch(function() {
                        t.isLogin = !1;
                    });
                }
            }
        };
    },
    qWMe: function(t, s) {},
    tBtx: function(t, s, a) {
        s.a = {
            render: function() {
                var t = this, s = t.$createElement, a = t._self._c || s;
                return a("div", {
                    class: [ "summer-report", t.isDark && "dark" ]
                }, [ a("swiper", {
                    staticClass: "swiper",
                    attrs: {
                        vertical: !0
                    }
                }, [ a("swiper-item", {
                    staticClass: "swiper-item",
                    staticStyle: {
                        width: "100%"
                    },
                    attrs: {
                        scrollY: "true",
                        bindscroll: "scroll",
                        mpcomid: "0"
                    }
                }, [ a("img", {
                    staticClass: "bg",
                    attrs: {
                        src: "//static.yanzhishi.cn/images/wechat/report_1.png",
                        alt: "report"
                    }
                }), t._v(" "), a("div", {
                    staticClass: "home"
                }, [ a("p", [ a("span", {
                    staticClass: "year"
                }, [ t._v("2021年") ]) ]), t._v(" "), a("p", {
                    staticClass: "subtitle"
                }, [ t._v("\n          全国计算机专业考研学生\n        ") ]), t._v(" "), a("p", {
                    staticClass: "title"
                }, [ t._v("\n          暑期（7.15-9.15）刷题&错题报告\n        ") ]) ], 1), t._v(" "), a("img", {
                    staticClass: "arrow",
                    attrs: {
                        src: "//static.yanzhishi.cn/images/wechat/report_arrow.png",
                        alt: "arrow"
                    }
                }) ]), t._v(" "), a("swiper-item", {
                    staticClass: "swiper-item",
                    staticStyle: {
                        width: "100%"
                    },
                    attrs: {
                        scrollY: "true",
                        bindscroll: "scroll",
                        mpcomid: "1"
                    }
                }, [ a("img", {
                    staticClass: "bg",
                    attrs: {
                        src: "//static.yanzhishi.cn/images/wechat/report_2.png",
                        alt: "report"
                    }
                }), t._v(" "), a("div", {
                    staticClass: "home"
                }, [ a("p", [ t._v("全国学生累计刷题"), a("span", {
                    staticClass: "strong"
                }, [ t._v("325,145") ]), t._v("道，") ]), t._v(" "), a("p", {
                    staticClass: "second-mt"
                }, [ t._v("\n          刷题数量排名前三的同学微信昵称是："), a("br"), a("span", {
                    staticClass: "strong"
                }, [ t._v("梅华(7523道)"), a("br"), t._v("cccc(6832道)"), a("br"), t._v("刘佳(5274道)") ], 1) ], 1) ], 1), t._v(" "), a("p", {
                    staticClass: "slogan"
                }, [ t._v("\n        ——数据来源于研芝士教育大数据平台\n      ") ]), t._v(" "), a("img", {
                    staticClass: "arrow",
                    attrs: {
                        src: "//static.yanzhishi.cn/images/wechat/report_arrow.png",
                        alt: "arrow"
                    }
                }) ], 1), t._v(" "), a("swiper-item", {
                    staticClass: "swiper-item",
                    staticStyle: {
                        width: "100%"
                    },
                    attrs: {
                        scrollY: "true",
                        bindscroll: "scroll",
                        mpcomid: "2"
                    }
                }, [ a("img", {
                    staticClass: "bg",
                    attrs: {
                        src: "//static.yanzhishi.cn/images/wechat/report_3.png",
                        alt: "report"
                    }
                }), t._v(" "), a("div", {
                    staticClass: "home exercise"
                }, [ a("p", [ t._v("暑期累计产生错题"), a("span", {
                    staticClass: "strong"
                }, [ t._v("6474") ]), t._v("道，") ]), t._v(" "), a("p", [ t._v("其中题目") ]), t._v(" "), a("div", {
                    staticClass: "example"
                }, [ a("p", {
                    staticClass: "example-title"
                }, [ t._v("\n            以下与数据的存储结构无关的术语是_____。\n          ") ]), t._v(" "), a("p", {
                    staticClass: "example-mt"
                }, [ t._v("\n            A、循环队列\n          ") ]), t._v(" "), a("p", [ t._v("B、线索树") ]), t._v(" "), a("p", [ t._v("C、栈") ]), t._v(" "), a("p", [ t._v("D、数组") ]), t._v(" "), a("p", [ t._v("参考答案：C") ]) ], 1), t._v(" "), a("p", {
                    staticClass: "last"
                }, [ t._v("\n          正确次数仅为"), a("span", {
                    staticClass: "strong"
                }, [ t._v("626") ]), t._v("次，错误次数达到"), a("span", {
                    staticClass: "strong"
                }, [ t._v("1236") ]), t._v("次，错误率高达"), a("span", {
                    staticClass: "strong"
                }, [ t._v("66.38%。") ]) ]) ], 1), t._v(" "), a("p", {
                    staticClass: "slogan"
                }, [ t._v("\n        ——数据来源于研芝士教育大数据平台\n      ") ]), t._v(" "), a("img", {
                    staticClass: "arrow",
                    attrs: {
                        src: "//static.yanzhishi.cn/images/wechat/report_arrow.png",
                        alt: "arrow"
                    }
                }) ], 1), t._v(" "), a("swiper-item", {
                    staticClass: "swiper-item",
                    staticStyle: {
                        width: "100%"
                    },
                    attrs: {
                        scrollY: "true",
                        bindscroll: "scroll",
                        mpcomid: "3"
                    }
                }, [ a("img", {
                    staticClass: "bg",
                    attrs: {
                        src: "//static.yanzhishi.cn/images/wechat/report_4.png",
                        alt: "report"
                    }
                }), t._v(" "), a("div", {
                    staticClass: "home statistics"
                }, [ a("p", [ t._v("考研er每天在线刷题时间集中在"), a("br"), a("span", {
                    staticClass: "strong"
                }, [ t._v("15：30-19：30，"), a("br"), t._v("22：30-00：30") ], 1) ], 1), t._v(" "), a("p", [ t._v("每道题平均答题时间"), a("span", {
                    staticClass: "strong"
                }, [ t._v("20.59s") ]) ]) ], 1), t._v(" "), a("p", {
                    staticClass: "slogan"
                }, [ t._v("\n        ——数据来源于研芝士教育大数据平台\n      ") ]), t._v(" "), a("img", {
                    staticClass: "arrow",
                    attrs: {
                        src: "//static.yanzhishi.cn/images/wechat/report_arrow.png",
                        alt: "arrow"
                    }
                }) ], 1), t._v(" "), a("swiper-item", {
                    staticClass: "swiper-item",
                    staticStyle: {
                        width: "100%"
                    },
                    attrs: {
                        scrollY: "true",
                        bindscroll: "scroll",
                        mpcomid: "4"
                    }
                }, [ a("img", {
                    staticClass: "bg",
                    attrs: {
                        src: "//static.yanzhishi.cn/images/wechat/report_5.png",
                        alt: "report"
                    }
                }), t._v(" "), a("div", {
                    staticClass: "home statistics"
                }, [ a("p", {
                    staticClass: "answer-subtitle"
                }, [ t._v("\n          点击答题，作答错误率\n        ") ]), t._v(" "), a("p", {
                    staticClass: "answer-title"
                }, [ t._v("\n          最高的前20题\n        ") ]), t._v(" "), a("div", {
                    staticClass: "btn"
                }, [ a("span", {
                    attrs: {
                        eventid: "0"
                    },
                    on: {
                        click: t.beginAnswer
                    }
                }, [ t._v("立即答题") ]) ]) ], 1) ]) ], 1), t._v(" "), a("login", {
                    attrs: {
                        userNotLogin: t.notLogin,
                        eventid: "1",
                        mpcomid: "5"
                    },
                    on: {
                        changeValue: t.changeNotLogin
                    }
                }) ], 1);
            },
            staticRenderFns: []
        };
    },
    uHk4: function(t, s, a) {
        var i = a("CTw8"), n = a("tBtx"), e = a("ybqe")(i.a, n.a, function(t) {
            a("qWMe");
        }, "data-v-296716cc", null);
        s.a = e.exports;
    }
}, [ "2o6m" ]);