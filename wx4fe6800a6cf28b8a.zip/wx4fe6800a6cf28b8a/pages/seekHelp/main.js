require("../../common/manifest.js"), require("../../common/vendor.js"), global.webpackJsonpMpvue([ 17 ], {
    "C+AS": function(e, t, n) {
        var i = n("H1nM"), s = n("omrU"), a = n("ybqe")(i.a, s.a, function(e) {
            n("t93z");
        }, "data-v-63c24330", null);
        t.a = a.exports;
    },
    H1nM: function(e, t, n) {
        t.a = {
            name: "SeekHelp"
        };
    },
    oLF5: function(e, t, n) {
        Object.defineProperty(t, "__esModule", {
            value: !0
        });
        var i = n("5nAL"), s = n.n(i), a = n("C+AS");
        new s.a(a.a).$mount();
    },
    omrU: function(e, t, n) {
        t.a = {
            render: function() {
                return this.$createElement, this._self._c, this._m(0);
            },
            staticRenderFns: [ function() {
                var e = this.$createElement, t = this._self._c || e;
                return t("div", {
                    staticClass: "seek-help"
                }, [ t("div", {
                    staticClass: "help-content"
                }, [ t("img", {
                    attrs: {
                        src: "//static.yanzhishi.cn/images/wechat/help_me.png",
                        mode: "widthFix",
                        alt: "求助"
                    }
                }), this._v(" "), t("div", {
                    staticClass: "help-btn"
                }, [ this._v("\n      截图并扫码 找ta求助\n    ") ]) ]) ]);
            } ]
        };
    },
    t93z: function(e, t) {}
}, [ "oLF5" ]);