require("../../common/manifest.js"), require("../../common/vendor.js"), global.webpackJsonpMpvue([ 34 ], {
    RyIY: function(t, e, a) {
        Object.defineProperty(e, "__esModule", {
            value: !0
        });
        var i = a("iOaD"), s = a("5nAL"), r = a.n(s), o = a("ltdW"), n = (a.n(o), a("ocgm")), c = (a.n(n), 
        a("+PwL"));
        a.n(c), new r.a(i.a).$mount();
    },
    "XQ6+": function(t, e, a) {
        e.a = {
            render: function() {
                var t = this, e = t.$createElement, a = t._self._c || e;
                return a("div", {
                    class: [ "mistake", t.isDark && "dark" ]
                }, [ t.notCheck ? a("div", {
                    staticClass: "error-box"
                }, [ a("tips-page", {
                    attrs: {
                        error: t.errorCode,
                        mpcomid: "0"
                    }
                }) ], 1) : a("block", [ a("div", {
                    staticClass: "question-list"
                }, [ a("div", {
                    staticClass: "sort-setting"
                }, [ a("p", [ t._v("错题次数排序") ]), t._v(" "), a("i-switch", {
                    attrs: {
                        value: t.sort,
                        eventid: "0",
                        mpcomid: "1"
                    },
                    on: {
                        change: t.onChangeSort
                    },
                    slot: "footer"
                }) ], 1), t._v(" "), t._l(t.mistakeList, function(e, i) {
                    return a("block", {
                        key: i
                    }, [ a("div", {
                        staticClass: "question-list-item",
                        attrs: {
                            eventid: "1_" + i
                        },
                        on: {
                            click: function(a) {
                                t.chooseExercise(e, i);
                            }
                        }
                    }, [ 3 !== e.exerciseType ? a("mistake-choice", {
                        attrs: {
                            exercise: e,
                            fromSource: t.handleSource(e),
                            mpcomid: "2_" + i
                        }
                    }) : t._e(), t._v(" "), 3 === e.exerciseType ? a("mistake-fill", {
                        attrs: {
                            exercise: e,
                            fromSource: t.handleSource(e),
                            mpcomid: "3_" + i
                        }
                    }) : t._e() ], 1) ]);
                }) ], 2), t._v(" "), t.more ? a("p", {
                    staticClass: "more"
                }, [ t._v("加载更多") ]) : t._e(), t._v(" "), a("fixed-bottom", {
                    attrs: {
                        text: "错题重做",
                        clickBtn: t.goExerciseAgainPage,
                        mpcomid: "4"
                    }
                }) ], 1) ], 1);
            },
            staticRenderFns: []
        };
    },
    e1vA: function(t, e, a) {
        var i = a("WvcL"), s = a("3waA"), r = a("RaUN"), o = (a("8e4C"), a("emV0")), n = a("xiLG"), c = a("+7ER"), m = a("VsUZ"), h = a("tXM+"), d = a("oFuF"), u = a("IcnI");
        e.a = {
            components: {
                "i-tabs": i.a,
                "i-tab": s.a,
                "i-switch": r.a,
                FixedBottom: o.a,
                MistakeChoice: n.a,
                MistakeFill: c.a,
                TipsPage: h.a
            },
            computed: {
                dateFlag: function() {
                    return u.a.state.mistakeTimeType;
                },
                subject: function() {
                    return u.a.state.subjectList;
                }
            },
            data: function() {
                return {
                    majorId: "701769479767592960",
                    chapterId: "",
                    mistakeList: [],
                    pageNum: 0,
                    pagesTotal: 1,
                    more: !1,
                    notCheck: !1,
                    errorCode: "",
                    exerciseTotal: null,
                    sort: !1,
                    chapterList: [],
                    examCategory: 1,
                    isDark: wx.getStorageSync("isDark")
                };
            },
            onLoad: function(t) {
                !isNaN(t) && t < this.mistakeList.length ? (this.mistakeList.splice(t, 1), this.exerciseTotal -= 1, 
                0 === this.mistakeList.length && (this.notCheck = !0, this.errorCode = 4114)) : this.mistakeList = [], 
                this.isDark = Object(d.onChangeDark)();
            },
            onUnload: function() {
                this.notCheck = !1, u.a.dispatch("getMistakeCountByTimeAndChapter");
            },
            onShow: function() {
                var t = this;
                this.$mp.page.getOpenerEventChannel().on("params", function(e) {
                    t.majorId = e.majorId || "701769479767592960", t.examCategory = e.examCategory, 
                    t.chapterId = e.chapterId, t.pageNum = 0, t.pagesTotal = 1, t.recordList = [], t.pageNum < t.pagesTotal && (t.pageNum += 1, 
                    t.getMistake(), t.getChapter());
                });
            },
            onReachBottom: function() {
                this.pageNum < this.pagesTotal ? (this.pageNum += 1, this.getMistake()) : this.more = !1;
            },
            methods: {
                getMistake: function() {
                    var t = this, e = this.majorId, a = this.pageNum, i = this.chapterId, s = this.dateFlag, r = this.sort, o = this.examCategory;
                    this.more = !1, m.default.getMistakenExerciseList({
                        majorId: e,
                        pageNum: a,
                        chapterId: i,
                        pageSize: 10,
                        dateFlag: s,
                        examCategory: o,
                        sort: r ? "incorrect_number" : "create_date"
                    }, function(e) {
                        if (t.errorCode = e.data.code, 200 !== e.data.code || 0 == e.data.data.list.length) return t.errorCode = 4094, 
                        t.notCheck = !0, !1;
                        t.notCheck = !1, t.pagesTotal = e.data.data.pages, t.exerciseTotal = e.data.data.total, 
                        1 == t.pageNum ? t.mistakeList = e.data.data.list : t.pageNum <= t.pagesTotal && (t.mistakeList = t.mistakeList.concat(e.data.data.list)), 
                        t.pageNum < t.pagesTotal && (t.more = !0);
                    }, function(e) {
                        401 === e.status && Object(d.repeatLogin)(function() {
                            t.getMistake();
                        });
                    }, !1);
                },
                getChapter: function() {
                    var t = this, e = this.majorId;
                    m.default.getKnowledge({
                        majorId: e,
                        examType: 2
                    }, function(e) {
                        t.chapterList = e.data.data;
                    });
                },
                handleChangeScroll: function(t) {
                    var e = this.subject;
                    this.mistakeList = [], this.current = t, this.pageNum = 1, this.more = !1, u.a.commit("setExamCategory", e[t].examCategory), 
                    this.getMistake(), this.getChapter();
                },
                chooseExercise: function(t, e) {
                    var a = this.exerciseTotal, i = this.examCategory, s = this.majorId, r = this.dateFlag;
                    wx.navigateTo({
                        url: "/pages/mistakeDetail/main",
                        success: function(o) {
                            o.eventChannel.emit("params", {
                                pageNum: e + 1,
                                pagesTotal: a,
                                majorId: s,
                                exerciseId: t.exerciseId,
                                examRecordId: "",
                                dateFlag: r,
                                examCategory: i
                            });
                        }
                    });
                },
                onChangeSort: function(t) {
                    this.sort = t.value, this.mistakeList = [], this.more = !1, this.pageNum = 1, this.getMistake();
                },
                goExerciseAgainPage: function() {
                    var t = this.dateFlag, e = this.chapterId, a = this.sort, i = this.majorId, s = this.examCategory;
                    wx.navigateTo({
                        url: "/pages/exerciseAgain/main",
                        success: function(r) {
                            r.eventChannel.emit("params", {
                                dateFlag: t,
                                chapterId: e,
                                sort: a,
                                majorId: i,
                                answerSource: 4,
                                examCategory: s
                            });
                        }
                    });
                },
                handleSource: function(t) {
                    if (1 == t.chapterId) return "快速刷题";
                    if (2 == t.chapterId) return "院校真题";
                    if (3 == t.chapterId) return "百日抢分";
                    var e = this.chapterList.filter(function(e) {
                        return e.id === t.chapterId;
                    });
                    return e.length > 0 ? e[0].name : "未知";
                }
            }
        };
    },
    iOaD: function(t, e, a) {
        var i = a("e1vA"), s = a("XQ6+"), r = a("ybqe")(i.a, s.a, function(t) {
            a("zt+z");
        }, null, null);
        e.a = r.exports;
    },
    "zt+z": function(t, e) {}
}, [ "RyIY" ]);