require("../../common/manifest.js"), require("../../common/vendor.js"), global.webpackJsonpMpvue([ 22 ], {
    "5ZCM": function(t, s, i) {
        var e = i("gRE1"), n = i.n(e), o = i("fZjL"), a = i.n(o), r = i("BO1k"), c = i.n(r), h = i("VsUZ").default;
        i("oFuF"), s.a = {
            data: function() {
                return {
                    nowIndex: 0,
                    optionQuestion: [ "AAAAAAAAAAAAAAAAAAAQAAAAAAAAAAAAAAAAA", "BBBBBBBBBBBBBBBBBBB", "CCCCCCCCCCCCCCCCCCC", "DDDDDDDDDDDDDDDDDDD", "EEEEEEEEEEEEEEEEEEE" ],
                    optionItem: [ "A", "B", "C", "D", "E", "F", "G", "H", "I", "J", "K", "L", "M", "N" ],
                    answerItem: -1,
                    question: [ {
                        title: "加载中~",
                        direction: "加载中~",
                        selectList: [ "加载中~", "加载中~", "加载中~", "加载中~" ]
                    } ],
                    custAnswer: [],
                    sysAnswer: [],
                    isShow_analy: !1,
                    conclusion: {
                        0: {
                            uid: "--",
                            isRight: "--"
                        }
                    },
                    time: "00 : 00",
                    time_inter: "",
                    ishave_page: !1,
                    time_status: "",
                    number: {
                        right: "0",
                        error: "0",
                        count: "0"
                    }
                };
            },
            onShow: function() {
                this.$set(this, "answerItem", this.custAnswer[this.nowIndex]);
            },
            onLoad: function(t) {
                var s = this;
                if (t.index) {
                    var i = t.index;
                    i ? (s.$set(s, "nowIndex", i - 1), s.$set(s, "conclusion", wx.getStorageSync("conclusion"))) : s.$set(s, "nowIndex", 0);
                } else this.$set(this, "nowIndex", 0), this.$set(this, "answerItem", -1), this.$set(this, "custAnswer", []), 
                this.$set(this, "time", "00 : 00"), this.$set(this, "number", {
                    right: "0",
                    error: "0",
                    count: "0"
                }), this.$set(this, "conclusion", {
                    0: {
                        uid: "--",
                        isRight: "--"
                    }
                }), clearInterval(this.time_inter), this.count_time(), h.question({
                    userId: wx.getStorageSync("userInfo").userId,
                    type: 1,
                    periodId: t.grader || 1,
                    subject: t.classIndex || 1,
                    grade: 1
                }, function(t) {
                    var i = {};
                    t.forEach(function(t, s) {
                        t.selectList && t.selectList.reverse();
                    }), s.$set(s, "question", t.reverse()), s.question.forEach(function(t, s) {
                        i[s] = {
                            uid: t.uid,
                            isRight: void 0
                        };
                    }), s.$set(s, "conclusion", i);
                });
            },
            methods: {
                chooseAnswer: function(t, s, i, e) {
                    if (void 0 !== this.conclusion[this.nowIndex].isRight) return !1;
                    var n = i.currentTarget.dataset.isright, o = this;
                    this.$set(this, "answerItem", s), this.$set(this.conclusion[this.nowIndex], "isRight", n || 0), 
                    this.custAnswer[this.nowIndex] = s, this.time_status ? (clearTimeout(this.time_status), 
                    this.$set(this, "time_status", setTimeout(function() {
                        o.nextQuestion(), o.$set(o, "time_status", "");
                    }, 1e3))) : this.$set(this, "time_status", setTimeout(function() {
                        o.nextQuestion(), o.$set(o, "time_status", "");
                    }, 1e3));
                    var r = 0, h = 0, u = 0, l = !0, d = !1, v = void 0;
                    try {
                        for (var w, _ = c()(a()(o.conclusion)); !(l = (w = _.next()).done); l = !0) {
                            var m = w.value;
                            switch (o.conclusion[m].isRight) {
                              case 1:
                                this.$set(this.number, "right", ++r), this.$set(this.number, "count", ++u);
                                break;

                              case 0:
                                this.$set(this.number, "error", ++h), this.$set(this.number, "count", ++u);
                            }
                        }
                    } catch (t) {
                        d = !0, v = t;
                    } finally {
                        try {
                            !l && _.return && _.return();
                        } finally {
                            if (d) throw v;
                        }
                    }
                },
                preQuestion: function() {
                    if (this.nowIndex <= 0) return wx.showToast({
                        title: "已经是第一题了。",
                        icon: "none",
                        duration: 2e3
                    }), !1;
                    this.$set(this, "nowIndex", --this.nowIndex), this.getAnswerItem(), this.$set(this, "isShow_analy", !1);
                },
                nextQuestion: function() {
                    var t = this;
                    if (this.nowIndex >= this.question.length - 1) return wx.showModal({
                        title: "已是最后一题",
                        content: "确认交卷？",
                        cancelText: "检查检查",
                        confirmText: "交卷罗",
                        cancelColor: "#5162e4",
                        confirmColor: "#000000",
                        success: function(s) {
                            if (s.confirm) {
                                var i = "", e = 0, o = 0;
                                n()(t.conclusion).forEach(function(t) {
                                    o++, t.isRight && e++, i += t.uid + "!" + (t.isRight ? "1" : "0") + ",";
                                }), wx.redirectTo({
                                    url: "/pages/achievement/main?right=" + e + "&ans=" + i.slice(0, -1) + "&zql=" + e / o
                                });
                            }
                        },
                        fail: function() {
                            wx.showToast({
                                title: "系统错误，请联系管理员",
                                icon: "none",
                                duration: 2e3
                            });
                        }
                    }), !1;
                    this.$set(this, "nowIndex", ++this.nowIndex), this.getAnswerItem(), this.$set(this, "isShow_analy", !1);
                },
                getAnswerItem: function() {
                    null == this.custAnswer[this.nowIndex] ? this.$set(this, "answerItem", -1) : this.$set(this, "answerItem", this.custAnswer[this.nowIndex]);
                },
                to: function(t) {
                    wx.setStorageSync("conclusion", this.conclusion), this.ishave_page ? wx.redirectTo({
                        url: "/pages/" + t + "/main?length=" + this.question.length
                    }) : (this.$set(this, "ishave_page", !0), wx.navigateTo({
                        url: "/pages/" + t + "/main?length=" + this.question.length
                    }));
                },
                showAnaly: function() {
                    this.$set(this, "isShow_analy", !this.isShow_analy);
                },
                count_time: function() {
                    var t = this, s = 0;
                    this.time_inter = setInterval(function() {
                        s += 1;
                        var i = Math.floor(s / 60) < 10 ? "0" + Math.floor(s / 60) : Math.floor(s / 60), e = s % 60 < 10 ? "0" + s % 60 : s % 60;
                        t.$set(t, "time", i + " : " + e);
                    }, 1e3);
                }
            },
            onShareAppMessage: function(t) {
                return {
                    title: "我是自定义标题",
                    imageUrl: "",
                    path: ""
                };
            }
        };
    },
    "6Inn": function(t, s, i) {
        var e = i("5ZCM"), n = i("P4fL"), o = i("ybqe")(e.a, n.a, function(t) {
            i("wPJP");
        }, "data-v-2d8dfcfd", null);
        s.a = o.exports;
    },
    P4fL: function(t, s, i) {
        s.a = {
            render: function() {
                var t = this, s = t.$createElement, i = t._self._c || s;
                return i("div", {
                    staticClass: "container"
                }, [ i("div", {
                    staticClass: "title"
                }, [ i("div", {
                    staticClass: "right"
                }, [ i("img", {
                    attrs: {
                        src: "/static/images/right.png",
                        alt: ""
                    }
                }), t._v(t._s(t.number.right)) ]), t._v(" "), i("div", {
                    staticClass: "error"
                }, [ i("img", {
                    attrs: {
                        src: "/static/images/error.png",
                        alt: ""
                    }
                }), t._v(t._s(t.number.error)) ]), t._v(" "), i("div", {
                    staticClass: "count"
                }, [ i("img", {
                    attrs: {
                        src: "/static/images/count.png",
                        alt: ""
                    }
                }), t._v(t._s(t.number.count + "/" + t.question.length)) ]), t._v(" "), i("p", {
                    staticClass: "time"
                }, [ t._v("计时：" + t._s(t.time)) ]) ], 1), t._v(" "), i("h6", {
                    staticClass: "question"
                }, [ t._v("\n        " + t._s(t.nowIndex + 1) + "." + t._s(t.question[t.nowIndex].title) + "\n    ") ]), t._v(" "), i("div", {
                    staticClass: "subject"
                }, [ i("p", [ t._v(t._s(t.question[t.nowIndex].direction)) ]) ], 1), t._v(" "), i("div", {
                    staticClass: "answer"
                }, [ t._l(t.question[t.nowIndex].selectList, function(s, e) {
                    return i("block", {
                        key: e
                    }, [ i("div", {
                        staticClass: "item",
                        class: t.conclusion[t.nowIndex].isRight && s.uid == t.answerItem || s.isRight && t.conclusion[t.nowIndex].isRight >= 0 ? "active" : s.uid == t.answerItem ? "error" : "",
                        attrs: {
                            "data-isRight": s.isRight,
                            eventid: "0_" + e
                        },
                        on: {
                            click: function(i) {
                                t.chooseAnswer(e, s.uid, i, t.question[t.nowIndex].uid);
                            }
                        }
                    }, [ i("div", {
                        staticClass: "check"
                    }, [ i("div"), i("b", [ t._v(t._s(t.optionItem[e])) ]) ], 1), t._v(" "), i("div", {
                        staticClass: "option"
                    }, [ t._v(t._s(s.title)) ]) ]) ]);
                }), t._v(" "), i("div", {
                    directives: [ {
                        name: "show",
                        rawName: "v-show",
                        value: t.isShow_analy,
                        expression: "isShow_analy"
                    } ],
                    staticStyle: {
                        height: "180rpx"
                    }
                }), t._v(" "), i("div", {
                    directives: [ {
                        name: "show",
                        rawName: "v-show",
                        value: t.isShow_analy,
                        expression: "isShow_analy"
                    } ],
                    staticClass: "analy",
                    staticStyle: {
                        visibility: "hidden"
                    }
                }, [ t._v("\n            " + t._s(t.question[t.nowIndex].analysis) + "\n        ") ]) ], 2), t._v(" "), i("div", {
                    staticClass: "footer",
                    style: t.isShow_analy ? "box-shadow:0px 0px 10px rgba(0,0,0,0.2);" : ""
                }, [ i("div", {
                    directives: [ {
                        name: "show",
                        rawName: "v-show",
                        value: t.isShow_analy,
                        expression: "isShow_analy"
                    } ],
                    staticClass: "analy"
                }, [ t._v("\n            " + t._s(t.question[t.nowIndex].analysis) + "\n        ") ]), t._v(" "), i("switch", {
                    attrs: {
                        checked: t.isShow_analy,
                        eventid: "1"
                    },
                    on: {
                        click: t.showAnaly
                    }
                }), t._v(" "), i("ul", [ i("li", {
                    attrs: {
                        eventid: "2"
                    },
                    on: {
                        click: t.preQuestion
                    }
                }, [ t._v("上一题") ]), t._v(" "), i("li", [ i("button", {
                    attrs: {
                        "open-type": "share"
                    }
                }, [ t._v("求助") ]) ], 1), t._v(" "), i("li", [ i("img", {
                    attrs: {
                        src: "/static/images/isStar.png",
                        alt: ""
                    }
                }) ]), t._v(" "), i("li", {
                    attrs: {
                        eventid: "3"
                    },
                    on: {
                        click: function(s) {
                            t.to("bank");
                        }
                    }
                }, [ t._v("题库") ]), t._v(" "), i("li", {
                    attrs: {
                        eventid: "4"
                    },
                    on: {
                        click: t.nextQuestion
                    }
                }, [ t._v("下一题") ]) ], 1) ], 1) ], 1);
            },
            staticRenderFns: []
        };
    },
    rpVy: function(t, s, i) {
        Object.defineProperty(s, "__esModule", {
            value: !0
        });
        var e = i("5nAL"), n = i.n(e), o = i("6Inn");
        new n.a(o.a).$mount();
    },
    wPJP: function(t, s) {}
}, [ "rpVy" ]);