require("../../common/manifest.js"), require("../../common/vendor.js"), global.webpackJsonpMpvue([ 6 ], {
    "6+Sz": function(e, n) {},
    "J/ku": function(e, n, t) {
        n.a = {
            props: [ "answers", "viewAnswer" ],
            watch: {
                answers: function(e, n) {
                    e !== n && (this.answers = e);
                }
            }
        };
    },
    Ks4U: function(e, n, t) {
        Object.defineProperty(n, "__esModule", {
            value: !0
        });
        var s = t("5nAL"), a = t.n(s), i = t("u4d3");
        new a.a(i.a).$mount();
    },
    "UJU/": function(e, n, t) {
        var s = t("J/ku"), a = t("zDPB"), i = t("ybqe")(s.a, a.a, function(e) {
            t("6+Sz");
        }, "data-v-9d796f24", null);
        n.a = i.exports;
    },
    kbuP: function(e, n, t) {
        var s = t("UJU/");
        n.a = {
            components: {
                answerCard: s.a
            },
            data: function() {
                return {
                    answers: [],
                    title: ""
                };
            },
            onLoad: function() {
                var e = this;
                this.$mp.page.getOpenerEventChannel().on("params", function(n) {
                    e.answers = n.exerciseList.map(function(e) {
                        return e.isRight = 1 === e.answerType, e;
                    }), e.title = n.title;
                });
            },
            methods: {
                viewAnswerDetail: function(e) {
                    wx.setStorageSync("exerciseNum", e), wx.navigateBack({
                        delta: 1
                    });
                }
            }
        };
    },
    krv3: function(e, n) {},
    u4d3: function(e, n, t) {
        var s = t("kbuP"), a = t("zWi5"), i = t("ybqe")(s.a, a.a, function(e) {
            t("krv3");
        }, "data-v-7641e346", null);
        n.a = i.exports;
    },
    zDPB: function(e, n, t) {
        n.a = {
            render: function() {
                var e = this, n = e.$createElement, t = e._self._c || n;
                return t("div", {
                    staticClass: "answer-card"
                }, e._l(e.answers, function(n, s) {
                    return t("block", {
                        key: s
                    }, [ t("div", {
                        class: [ "answer-item", n.isRight ? "answer-item-on" : "" ],
                        attrs: {
                            id: s,
                            eventid: "0_" + s
                        },
                        on: {
                            click: function(n) {
                                e.viewAnswer(s);
                            }
                        }
                    }, [ e._v(e._s(s + 1)) ]) ]);
                }));
            },
            staticRenderFns: []
        };
    },
    zWi5: function(e, n, t) {
        n.a = {
            render: function() {
                var e = this.$createElement, n = this._self._c || e;
                return n("div", {
                    staticClass: "record-answer"
                }, [ n("div", {
                    staticClass: "title"
                }, [ n("span", [ this._v(this._s(this.title)) ]) ]), this._v(" "), n("answer-card", {
                    attrs: {
                        answers: this.answers,
                        viewAnswer: this.viewAnswerDetail,
                        mpcomid: "0"
                    }
                }) ], 1);
            },
            staticRenderFns: []
        };
    }
}, [ "Ks4U" ]);