require("../../common/manifest.js"), require("../../common/vendor.js"), global.webpackJsonpMpvue([ 35 ], {
    "6K99": function(t, e, i) {
        var a = i("mvHQ"), n = i.n(a), s = i("8e4C"), r = i("WvcL"), o = i("3waA"), c = i("VsUZ"), m = i("tXM+"), d = i("oFuF"), u = i("IcnI");
        e.a = {
            components: {
                "i-tabs": r.a,
                "i-tab": o.a,
                TipsPage: m.a
            },
            data: function() {
                return {
                    currentMajorId: [],
                    subject: [],
                    examList: [],
                    notCheck: !1,
                    errorCode: 200,
                    apiName: "getMoocExam",
                    isDark: wx.getStorageSync("isDark")
                };
            },
            computed: {
                memberType: function() {
                    return u.a.state.member.memberType;
                }
            },
            onLoad: function(t) {
                var e = this, i = this.memberType;
                t && "{}" !== n()(t) ? wx.showModal({
                    title: "未做完",
                    content: "是否保存到草稿",
                    confirmText: "保存草稿",
                    confirmColor: "#ffcc00",
                    success: function(e) {
                        e.confirm && c.default.submitExam(t, function(t) {
                            console.log(t);
                        });
                    }
                }) : (1 === i ? (this.currentMajorId = s.k[0].id, this.subject = s.k, this.apiName = "getMoocExam") : (this.currentMajorId = s.l[0].id, 
                this.subject = s.l, this.apiName = "getSelfExam"), this.$mp.page.getOpenerEventChannel().on("params", function(t) {
                    e.majorId = t.majorId, e.getList();
                }), this.isDark = Object(d.onChangeDark)());
            },
            methods: {
                chooseExercise: function(t) {
                    var e = this, i = (this.currentMajorId, this.memberType);
                    wx.setStorageSync("isMember", !0), wx.setStorageSync("title", t.examinationName), 
                    u.a.commit("setExamination", t), wx.navigateTo({
                        url: "/pages/fastExercise/main",
                        success: function(a) {
                            a.eventChannel.emit("params", {
                                type: 1 === i ? 3 : 6,
                                majorId: e.majorId,
                                examId: t.id,
                                chapterId: 1 === i ? 3 : 6
                            });
                        }
                    });
                },
                getList: function() {
                    var t = this, e = this.apiName;
                    c.default[e]({
                        majorId: this.currentMajorId
                    }, function(e) {
                        return t.errorCode = e.data.code, 200 !== e.data.code ? (t.notCheck = !0, !1) : 0 === e.data.data.length ? (t.errorCode = 4064, 
                        t.notCheck = !0, !1) : (t.notCheck = !1, void (t.examList = e.data.data.map(function(t) {
                            var e = Object(d.timeEffective)(t.startTime, t.endTime), i = e.isStart, a = e.isEnd;
                            return t.showBegin = i && !a, t.endTime = Object(d.formatTime)(new Date(t.endTime)), 
                            t;
                        }).sort(function(t, e) {
                            return t.examSort - e.examSort;
                        })));
                    }, function(e) {
                        401 === e.status && Object(d.repeatLogin)(function() {
                            t.getList();
                        });
                    });
                },
                changeType: function(t) {
                    this.currentMajorId = t, this.pageNum = 1, this.examList = [], this.getList();
                }
            }
        };
    },
    JfbT: function(t, e, i) {
        Object.defineProperty(e, "__esModule", {
            value: !0
        });
        var a = i("SmLt"), n = i("5nAL"), s = i.n(n), r = i("ltdW"), o = (i.n(r), i("ocgm"));
        i.n(o), new s.a(a.a).$mount();
    },
    SmLt: function(t, e, i) {
        var a = i("6K99"), n = i("rx0t"), s = i("ybqe")(a.a, n.a, function(t) {
            i("x6jz");
        }, null, null);
        e.a = s.exports;
    },
    rx0t: function(t, e, i) {
        e.a = {
            render: function() {
                var t = this, e = t.$createElement, i = t._self._c || e;
                return i("div", {
                    class: [ "member", t.isDark && "dark" ]
                }, [ i("div", {
                    staticClass: "title"
                }, [ i("i-tabs", {
                    attrs: {
                        iClass: "title-content",
                        scroll: "true",
                        eventid: "0",
                        mpcomid: "1"
                    },
                    on: {
                        change: t.changeType
                    },
                    model: {
                        value: t.currentMajorId,
                        callback: function(e) {
                            t.currentMajorId = e;
                        },
                        expression: "currentMajorId"
                    }
                }, t._l(t.subject, function(t, e) {
                    return i("i-tab", {
                        key: e,
                        attrs: {
                            itemKey: t.id,
                            title: t.name,
                            mpcomid: "0_" + e
                        }
                    });
                })) ], 1), t._v(" "), t.notCheck ? i("div", {
                    staticClass: "error-box"
                }, [ i("tips-page", {
                    attrs: {
                        error: t.errorCode,
                        mpcomid: "2"
                    }
                }) ], 1) : i("block", [ i("div", {
                    staticClass: "question-list"
                }, t._l(t.examList, function(e, a) {
                    return i("block", {
                        key: a
                    }, [ i("div", {
                        staticClass: "list-line question-list-item",
                        attrs: {
                            eventid: "1_" + a
                        },
                        on: {
                            click: function(i) {
                                t.chooseExercise(e, a);
                            }
                        }
                    }, [ i("p", {
                        staticClass: "exam-title"
                    }, [ t._v("\n            " + t._s(e.examinationName) + "\n          ") ]), t._v(" "), i("p", {
                        staticClass: "exam-info"
                    }, [ i("span", [ t._v("截止日期：" + t._s(e.endTime)) ]), t._v(" "), i("span", [ t._v("已完成" + t._s(e.applicationCode) + "次") ]) ]), t._v(" "), e.applicationCode > 0 ? i("img", {
                        staticClass: "finish",
                        attrs: {
                            src: "//static.yanzhishi.cn/images/wechat/exam_finish_1.png",
                            mode: "widthFix",
                            alt: "finish"
                        }
                    }) : i("img", {
                        staticClass: "begin",
                        attrs: {
                            src: "//static.yanzhishi.cn/images/wechat/begin_exam.png",
                            mode: "widthFix",
                            alt: "begin"
                        }
                    }) ], 1) ]);
                })) ]), t._v(" "), i("img", {
                    staticClass: "vip",
                    attrs: {
                        src: "//static.yanzhishi.cn/images/wechat/vip.png",
                        mode: "widthFix",
                        alt: "vip"
                    }
                }) ], 1);
            },
            staticRenderFns: []
        };
    },
    x6jz: function(t, e) {}
}, [ "JfbT" ]);