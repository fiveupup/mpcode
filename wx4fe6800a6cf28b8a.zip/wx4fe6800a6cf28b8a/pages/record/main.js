require("../../common/manifest.js"), require("../../common/vendor.js"), global.webpackJsonpMpvue([ 21 ], {
    "7wY6": function(e, t, a) {
        Object.defineProperty(t, "__esModule", {
            value: !0
        });
        var o = a("5nAL"), n = a.n(o), i = a("EcJE"), r = a("ltdW"), s = (a.n(r), a("ocgm"));
        a.n(s), new n.a(i.a).$mount();
    },
    EcJE: function(e, t, a) {
        var o = a("jwUY"), n = a("k881"), i = a("ybqe")(o.a, n.a, function(e) {
            a("unpd");
        }, null, null);
        t.a = i.exports;
    },
    jwUY: function(e, t, a) {
        var o = a("WvcL"), n = a("3waA"), i = a("xiLG"), r = a("tXM+"), s = a("VsUZ"), c = a("oFuF"), m = a("IcnI");
        t.a = {
            components: {
                MistakeChoice: i.a,
                TipsPage: r.a,
                "i-tabs": o.a,
                "i-tab": n.a
            },
            data: function() {
                return {
                    recordList: [],
                    pageNum: 0,
                    pagesTotal: 1,
                    more: !1,
                    notCheck: !0,
                    errorCode: "",
                    examType: 3,
                    typeList: [ {
                        label: "考研练习卷",
                        value: 3
                    }, {
                        label: "真题卷",
                        value: 1
                    }, {
                        label: "练透考点",
                        value: 4
                    }, {
                        label: "全程精选",
                        value: 7
                    } ],
                    isDark: wx.getStorageSync("isDark")
                };
            },
            onLoad: function() {
                this.isDark = Object(c.onChangeDark)();
            },
            onShow: function() {
                var e = this;
                this.$mp.page.getOpenerEventChannel().on("params", function(t) {
                    e.pageNum = 0, e.pagesTotal = 1, e.recordList = [], e.pageNum < e.pagesTotal && (e.pageNum += 1, 
                    e.getExamRecord());
                });
            },
            onReachBottom: function() {
                this.pageNum < this.pagesTotal && (this.pageNum += 1, this.getExamRecord());
            },
            methods: {
                getExamRecord: function() {
                    var e = this;
                    s.default.getExaminationRecord({
                        pageNum: this.pageNum,
                        pageSize: 20,
                        examType: this.examType
                    }, function(t) {
                        if (e.errorCode = t.data.code, 200 !== t.data.code) return e.notCheck = !0, !1;
                        e.pagesTotal = t.data.data.pages, e.pageNum <= e.pagesTotal && (e.recordList = e.recordList.concat(t.data.data.list.map(function(e) {
                            return e.endTime = Object(c.formatTime)(new Date(e.endTime)), e;
                        })), e.recordList.length > 0 ? e.notCheck = !1 : e.errorCode = 5001), e.pageNum < e.pagesTotal ? e.more = !0 : e.more = !1;
                    });
                },
                getRecord: function() {
                    var e = this;
                    s.default.getExerciseRecordList({
                        examRecordId: "715978788248358912"
                    }, function(t) {
                        if (e.errorCode = t.data.code, 200 !== t.data.code) return e.notCheck = !0, !1;
                        e.pagesTotal = t.data.data.pages, e.pageNum <= e.pagesTotal && (e.recordList = e.recordList.concat(t.data.data.list), 
                        e.recordList.length > 0 ? e.notCheck = !1 : e.errorCode = 5001), e.pageNum < e.pagesTotal && (e.more = !0);
                    }, function(t) {
                        401 === t.status && Object(c.repeatLogin)(function() {
                            e.getRecord();
                        });
                    });
                },
                chooseExercise: function(e, t) {
                    var a = this;
                    m.a.commit("setExerciseNum", 0), wx.navigateTo({
                        url: "/pages/recordDetail/main",
                        success: function(t) {
                            t.eventChannel.emit("params", {
                                examRecordId: e.id,
                                examRecordName: e.examinationName,
                                examType: a.examType
                            });
                        }
                    });
                },
                changeType: function(e) {
                    this.examType = e, this.recordList = [], this.pageNum = 1, this.more = !1, this.getExamRecord();
                }
            }
        };
    },
    k881: function(e, t, a) {
        t.a = {
            render: function() {
                var e = this, t = e.$createElement, a = e._self._c || t;
                return a("div", {
                    class: [ "record", e.isDark && "dark" ]
                }, [ a("div", {
                    staticClass: "tab-myself"
                }, [ a("i-tabs", {
                    attrs: {
                        iClass: "title-content",
                        scroll: "true",
                        eventid: "0",
                        mpcomid: "1"
                    },
                    on: {
                        change: e.changeType
                    },
                    model: {
                        value: e.examType,
                        callback: function(t) {
                            e.examType = t;
                        },
                        expression: "examType"
                    }
                }, e._l(e.typeList, function(e, t) {
                    return a("i-tab", {
                        key: t,
                        attrs: {
                            itemKey: e.value,
                            title: e.label,
                            mpcomid: "0_" + t
                        }
                    });
                })) ], 1), e._v(" "), e.notCheck ? a("div", {
                    staticClass: "error-box"
                }, [ a("tips-page", {
                    attrs: {
                        error: e.errorCode,
                        mpcomid: "2"
                    }
                }) ], 1) : a("block", [ a("div", {
                    staticClass: "question-list"
                }, e._l(e.recordList, function(t, o) {
                    return a("block", {
                        key: o
                    }, [ a("div", {
                        staticClass: "question-list-item list-line",
                        attrs: {
                            eventid: "1_" + o
                        },
                        on: {
                            click: function(a) {
                                e.chooseExercise(t, o);
                            }
                        }
                    }, [ a("p", {
                        staticClass: "exam-title"
                    }, [ e._v("\n            " + e._s(t.examinationName) + "\n          ") ]), e._v(" "), a("p", {
                        staticClass: "exam-info"
                    }, [ a("span", [ e._v(e._s(t.endTime)) ]), e._v(" "), 2 === e.examType ? a("block", [ a("span", [ e._v("共得" + e._s(t.score) + "分") ]), e._v(" "), a("span", [ e._v("答对" + e._s(t.correctNumber) + "题") ]) ]) : e._e() ], 1) ], 1) ]);
                })), e._v(" "), e.more ? a("p", {
                    staticClass: "more"
                }, [ e._v("\n      加载更多\n    ") ]) : e._e() ], 1) ], 1);
            },
            staticRenderFns: []
        };
    },
    unpd: function(e, t) {}
}, [ "7wY6" ]);