require("../../common/manifest.js"), require("../../common/vendor.js"), global.webpackJsonpMpvue([ 15 ], {
    XB3j: function(e, t, a) {
        var i = a("zDkj"), s = a("kKGr"), n = a("ybqe")(i.a, s.a, function(e) {
            a("YvMP");
        }, "data-v-a4f20784", null);
        t.a = n.exports;
    },
    YvMP: function(e, t) {},
    Zkqx: function(e, t, a) {
        Object.defineProperty(t, "__esModule", {
            value: !0
        });
        var i = a("5nAL"), s = a.n(i), n = a("XB3j");
        new s.a(n.a).$mount();
    },
    kKGr: function(e, t, a) {
        t.a = {
            render: function() {
                var e = this, t = e.$createElement, a = e._self._c || t;
                return a("div", {
                    staticClass: "share"
                }, [ a("h2", [ e._v("邀请6位好友助力"), a("br"), e._v("就可解锁更多题目啦") ], 1), e._v(" "), a("p", [ e._v("解锁后可享受刷题，边刷边学，轻松上岸") ]), e._v(" "), a("div", {
                    staticClass: "content"
                }, [ a("div", {
                    staticClass: "title"
                }, [ a("div", {
                    staticClass: "middle"
                }, [ a("div", {
                    staticClass: "left"
                }), e._v(" "), a("div", {
                    staticClass: "right"
                }), e._v(" "), a("div", {
                    staticClass: "circle-left"
                }), e._v(" "), a("div", {
                    staticClass: "circle-right"
                }), e._v(" "), a("p", [ e._v("分享好友  立即解锁") ]) ], 1) ]), e._v(" "), a("div", {
                    staticClass: "user"
                }, e._l(e.cardList, function(t, i) {
                    return a("div", {
                        key: i
                    }, [ (i + 1) % 3 != 0 ? a("div", {
                        class: [ "line", t.checked && "active" ]
                    }, [ a("span") ]) : e._e(), e._v(" "), a("img", {
                        staticClass: "avatar",
                        attrs: {
                            src: t.imgUrl,
                            alt: "avatar"
                        }
                    }), e._v(" "), a("p", [ e._v(e._s(t.userName)) ]) ], 1);
                })) ]), e._v(" "), a("button", {
                    staticClass: "btn-share",
                    attrs: {
                        "open-type": "share"
                    }
                }, [ e._v("\n    邀请好友\n  ") ]) ], 1);
            },
            staticRenderFns: []
        };
    },
    zDkj: function(e, t, a) {
        var i = a("VsUZ"), s = a("oFuF");
        t.a = {
            data: function() {
                return {
                    cardList: [],
                    userList: [ {
                        imgUrl: "http://static.yanzhishi.cn/images/wechat/avatar_cheese.jpeg",
                        userName: "芝士"
                    }, {
                        imgUrl: "http://static.yanzhishi.cn/images/wechat/avatar_pizza.jpeg",
                        userName: "披萨"
                    }, {
                        imgUrl: "http://static.yanzhishi.cn/images/wechat/avatar_sandwich.jpeg",
                        userName: "吐司"
                    }, {
                        imgUrl: "http://static.yanzhishi.cn/images/wechat/avatar_cheese.jpeg",
                        userName: "芝士"
                    }, {
                        imgUrl: "http://static.yanzhishi.cn/images/wechat/avatar_pizza.jpeg",
                        userName: "披萨"
                    }, {
                        imgUrl: "http://static.yanzhishi.cn/images/wechat/avatar_sandwich.jpeg",
                        userName: "吐司"
                    } ],
                    numberForNotOpen: 1,
                    doIshare: !0,
                    shareIdentifier: ""
                };
            },
            onLoad: function() {
                this.cardList = [ {
                    clicked: !1,
                    imgUrl: "http://static.yanzhishi.cn/images/wechat/share_user_new.png",
                    userName: "待邀请"
                }, {
                    clicked: !1,
                    imgUrl: "http://static.yanzhishi.cn/images/wechat/share_user_new.png",
                    userName: "待邀请"
                }, {
                    clicked: !1,
                    imgUrl: "http://static.yanzhishi.cn/images/wechat/share_user_new.png",
                    userName: "待邀请"
                }, {
                    clicked: !1,
                    imgUrl: "http://static.yanzhishi.cn/images/wechat/share_user_new.png",
                    userName: "待邀请"
                }, {
                    clicked: !1,
                    imgUrl: "http://static.yanzhishi.cn/images/wechat/share_user_new.png",
                    userName: "待邀请"
                }, {
                    clicked: !1,
                    imgUrl: "http://static.yanzhishi.cn/images/wechat/share_user_new.png",
                    userName: "待邀请"
                } ];
                var e = this;
                wx.login({
                    success: function(t) {
                        e.getIdentifier();
                    }
                });
            },
            onShareAppMessage: function() {
                return {
                    title: "还差" + this.numberForNotOpen + "人，快来帮我免费解锁电气考研刷题小程序",
                    imageUrl: "http://static.yanzhishi.cn/images/wechat/share_img.png",
                    path: "/pages/newIndex/main?identifier=" + this.shareIdentifier
                };
            },
            onShareTimeline: function() {
                return {
                    title: "还差" + this.numberForNotOpen + "人，快来帮我免费解锁电气考研刷题小程序",
                    imageUrl: "http://static.yanzhishi.cn/images/wechat/share_img.png",
                    path: "/pages/newIndex/main?identifier=" + this.shareIdentifier
                };
            },
            methods: {
                getIdentifier: function() {
                    var e = this;
                    i.default.loginCodeToOpenId({}, function(t) {
                        e.shareIdentifier = t.data.data, e.getHelperList();
                    }, function(t) {
                        401 === t.status && Object(s.repeatLogin)(function() {
                            e.getIdentifier();
                        });
                    });
                },
                getHelperList: function() {
                    var e = this, t = this.cardList, a = this.userList;
                    i.default.getHelperList({
                        identifier: this.shareIdentifier
                    }, function(i) {
                        i.data.data.forEach(function(e, i) {
                            t[i].userName = e.name ? e.name : a[i].userName, t[i].imgUrl = e.previewUrl ? e.previewUrl : a[i].imgUrl, 
                            t[i].checked = !0;
                        }), e.numberForNotOpen = 6 - i.data.data.length;
                    }, function(t) {
                        401 == t.status && Object(s.repeatLogin)(function() {
                            e.getHelperList();
                        });
                    });
                }
            }
        };
    }
}, [ "Zkqx" ]);