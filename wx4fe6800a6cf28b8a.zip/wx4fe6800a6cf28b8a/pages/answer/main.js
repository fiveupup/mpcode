require("../../common/manifest.js"), require("../../common/vendor.js"), global.webpackJsonpMpvue([ 46 ], {
    "1Opd": function(e, t, s) {
        t.a = {
            render: function() {
                var e = this, t = e.$createElement, s = e._self._c || t;
                return s("div", {
                    staticClass: "answer-container"
                }, [ s("div", {
                    staticClass: "title"
                }, [ s("span", [ e._v(e._s(e.title)) ]) ]), e._v(" "), s("div", {
                    staticClass: "gray"
                }), e._v(" "), s("p", {
                    staticClass: "tips"
                }, [ e._v("点击题号，可跳转至相应题目") ]), e._v(" "), s("div", {
                    staticClass: "answer"
                }, e._l(e.answers, function(t, a) {
                    return s("block", {
                        key: a
                    }, [ s("div", {
                        class: [ "answer-item", t.answer ? "answer-item-on" : "" ],
                        attrs: {
                            id: a,
                            eventid: "0_" + a
                        },
                        on: {
                            click: function(t) {
                                e.viewAnswer(a);
                            }
                        }
                    }, [ e._v(e._s(a + 1)) ]) ]);
                })), e._v(" "), s("fixed-bottom", {
                    attrs: {
                        text: "交卷并查看结果",
                        clickBtn: e.submitExam,
                        mpcomid: "0"
                    }
                }), e._v(" "), s("i-modal", {
                    attrs: {
                        title: "确定提交",
                        visible: e.submitModal,
                        eventid: "1",
                        mpcomid: "1"
                    },
                    on: {
                        ok: e.submitContinue,
                        cancel: e.handleClose
                    }
                }, [ s("div", [ e._v("你还有未作答的题目") ]) ]) ], 1);
            },
            staticRenderFns: []
        };
    },
    "67oF": function(e, t, s) {
        var a = s("mvHQ"), n = s.n(a), i = s("emV0"), r = s("VsUZ"), o = s("oFuF"), c = s("4u4q");
        t.a = {
            components: {
                FixedBottom: i.a,
                "i-modal": c.a
            },
            data: function() {
                return {
                    title: "快速刷题",
                    answerParams: null,
                    answers: [],
                    submitModal: !1
                };
            },
            onLoad: function() {
                var e = this;
                this.submitModal = !1, this.$mp.page.getOpenerEventChannel().on("answers", function(t) {
                    e.answerParams = t, e.answers = t.answers;
                }), this.title = wx.getStorageSync("title");
            },
            methods: {
                submitExam: function() {
                    var e = this;
                    if (this.answerParams.endTime = new Date().getTime(), this.answerParams.correctNumber = 0, 
                    this.answerParams.inCorrectNumber = 0, this.answerParams.score = 0, this.answerParams.answers.forEach(function(t) {
                        1 === t.answerType && (e.answerParams.correctNumber += 1, e.answerParams.score += t.score), 
                        2 === t.answerType && (e.answerParams.inCorrectNumber += 1);
                    }), this.answerParams.answers.filter(function(e) {
                        return "" === e.answer;
                    }).length > 0) this.submitModal = !0; else {
                        var t = n()(this.answerParams);
                        this.submit(this.answerParams, t);
                    }
                },
                submit: function(e, t) {
                    var s = this;
                    r.default.submitExam(e, function() {
                        wx.redirectTo({
                            url: "/pages/report/main?params=" + t
                        });
                    }, function(a) {
                        401 === a.status && Object(o.repeatLogin)(function() {
                            s.submit(e, t);
                        });
                    });
                },
                submitContinue: function() {
                    var e = n()(this.answerParams);
                    this.submit(this.answerParams, e);
                },
                viewAnswer: function(e) {
                    wx.setStorageSync("exerciseNum", e), wx.navigateBack({
                        delta: 1
                    });
                },
                handleClose: function() {
                    this.submitModal = !1;
                }
            }
        };
    },
    Wcjq: function(e, t) {},
    a2wj: function(e, t, s) {
        Object.defineProperty(t, "__esModule", {
            value: !0
        });
        var a = s("5nAL"), n = s.n(a), i = s("e+7h"), r = s("cvLP");
        s.n(r), new n.a(i.a).$mount();
    },
    "e+7h": function(e, t, s) {
        var a = s("67oF"), n = s("1Opd"), i = s("ybqe")(a.a, n.a, function(e) {
            s("Wcjq");
        }, null, null);
        t.a = i.exports;
    }
}, [ "a2wj" ]);