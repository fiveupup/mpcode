require("../../common/manifest.js"), require("../../common/vendor.js"), global.webpackJsonpMpvue([ 3 ], {
    "+/VV": function(e, t) {},
    "0NAv": function(e, t, i) {
        t.a = {
            render: function() {
                var e = this, t = e.$createElement, i = e._self._c || t;
                return i("div", {
                    staticClass: "mobile-course"
                }, [ i("XkVideo", {
                    attrs: {
                        videoContent: e.videoContent,
                        videoConfig: e.videoConfig,
                        eventid: "0",
                        mpcomid: "0"
                    },
                    on: {
                        ended: e.endedVideo,
                        fullscreenchange: e.fullScreen
                    }
                }), e._v(" "), i("div", {
                    staticClass: "catalog"
                }, [ i("i-tabs", {
                    attrs: {
                        iClass: "title-content",
                        scroll: "true",
                        eventid: "1",
                        mpcomid: "2"
                    },
                    on: {
                        change: e.changeCategory
                    },
                    model: {
                        value: e.catalogId,
                        callback: function(t) {
                            e.catalogId = t;
                        },
                        expression: "catalogId"
                    }
                }, e._l(e.category, function(e, t) {
                    return i("i-tab", {
                        key: t,
                        attrs: {
                            itemKey: e.id,
                            title: e.name,
                            mpcomid: "1_" + t
                        }
                    });
                })) ], 1), e._v(" "), i("div", {
                    staticClass: "course-list"
                }, [ 2 == e.catalogId ? i("ListVideo", {
                    attrs: {
                        subCourse: e.subCourse,
                        lessonList: e.lessonList,
                        isBuy: e.isBuy,
                        eventid: "2",
                        mpcomid: "4"
                    },
                    on: {
                        queryLesson: e.getLessonVideo,
                        viewVideo: e.viewVideo,
                        switchCourse: e.switchCourse
                    }
                }) : i("ImgDetail", {
                    attrs: {
                        course: e.course,
                        isBuy: e.isBuy,
                        mpcomid: "3"
                    }
                }) ], 1) ], 1);
            },
            staticRenderFns: []
        };
    },
    "1hDP": function(e, t, i) {
        var n = i("b1mz"), o = i("v2NE");
        t.a = {
            components: {
                "i-icon": n.a,
                PageLoading: o.a
            },
            props: {
                lessonList: {
                    type: Object,
                    default: function() {}
                },
                subCourse: {
                    type: Object,
                    default: function() {}
                },
                isBuy: {
                    type: Boolean,
                    default: !1
                },
                myClass: {
                    type: String,
                    default: ""
                }
            },
            data: function() {
                return {
                    listActive: "0-0"
                };
            },
            methods: {
                switchShowCourseList: function(e) {
                    this.$emit("switchCourse", e), this.lessonList[e.id] || (e.loading = !0, this.$emit("queryLesson", {
                        courseId: e.id
                    }, function() {
                        e.loading = !1;
                    }));
                },
                selectLesson: function(e) {
                    this.$emit("viewVideo", e);
                }
            }
        };
    },
    "2TbQ": function(e, t) {},
    "5p1C": function(e, t, i) {
        t.a = {
            props: {
                course: {
                    type: Object,
                    default: function() {}
                },
                videoContent: {
                    type: Object,
                    default: function() {}
                },
                videoConfig: {
                    type: Object,
                    default: function() {}
                },
                myClass: {
                    type: String,
                    default: ""
                }
            },
            data: function() {
                return {
                    showSpeed: !1,
                    showBtn: !1,
                    speed: [ "0.8", "1.0", "1.25", "1.5", "2.0" ],
                    activeIndex: 1
                };
            },
            watch: {
                videoConfig: {
                    handler: function(e) {
                        var t = this;
                        this.videoContent.seek(e.initialTime), e.autoPlay && setTimeout(function() {
                            t.videoContent.play();
                        }, 100);
                    },
                    deep: !0
                }
            },
            methods: {
                bindcontrolstoggle: function(e) {
                    var t = e.mp.detail.show;
                    this.showBtn = t;
                },
                handlePlay: function() {},
                endedVideo: function() {},
                fullScreen: function() {},
                timeUpdate: function() {},
                bindpause: function() {},
                changeSpeed: function(e) {
                    var t = this.speed;
                    this.activeIndex = e, this.showSpeed = !1, this.videoContent.playbackRate(Number(t[this.activeIndex]));
                }
            }
        };
    },
    BQd4: function(e, t, i) {
        var n = i("mvHQ"), o = i.n(n), s = i("oFuF"), a = i("VsUZ"), c = i("m9zR"), r = i("a7Ge"), u = requirePlugin("xk-video-player");
        t.a = {
            components: {
                MobileView: c.a,
                PcView: r.a
            },
            data: function() {
                return {
                    course: {},
                    videoContent: {},
                    fromMyCourse: !1,
                    courseId: "",
                    isPcEquipment: !0
                };
            },
            onReady: function() {
                this.videoContent = u._createVideoContext();
            },
            onLoad: function(e) {
                var t = this;
                if (this.isDark = Object(s.onChangeDark)(), this.course = {}, this.getSystemInfo(), 
                e.params) {
                    var i = JSON.parse(e.params);
                    Object(s.silentLogin)().then(function() {
                        t._getCourse({
                            id: i.id
                        });
                    });
                } else this.$mp.page.getOpenerEventChannel().on("params", function(e) {
                    t.fromMyCourse = e.fromMyCourse || !1, t.courseId = e.id, t._getCourse({
                        id: e.id
                    });
                });
            },
            onShow: function() {
                var e = this;
                wx.onWindowResize(function() {
                    e.getSystemInfo();
                });
            },
            onShareAppMessage: function() {
                return this.share();
            },
            onShareTimeline: function() {
                return this.share();
            },
            methods: {
                _getCourse: function(e) {
                    var t = this;
                    a.default.getCourseDetail(e, function(e) {
                        t.course = e.data.data;
                    }, function(i) {
                        401 === i.status && Object(s.repeatLogin)(function() {
                            t._getCourse(e);
                        });
                    });
                },
                share: function() {
                    var e = o()({
                        id: this.courseId
                    });
                    return {
                        title: "推荐一个" + this.course.courseName + "课程，即刻点开学习吧！",
                        path: "/pages/video/main?params=" + e
                    };
                },
                getSystemInfo: function() {
                    var e = wx.getSystemInfoSync().windowWidth;
                    this.isPcEquipment = e > 992;
                }
            }
        };
    },
    Cz5A: function(e, t) {},
    HTW1: function(e, t, i) {
        t.a = {
            render: function() {
                var e = this, t = e.$createElement, i = e._self._c || t;
                return i("div", {
                    staticClass: "pc-course"
                }, [ i("div", {
                    staticClass: "pc-course__left"
                }, [ i("XkVideo", {
                    attrs: {
                        myClass: "pc-video",
                        videoContent: e.videoContent,
                        videoConfig: e.videoConfig,
                        eventid: "0",
                        mpcomid: "0"
                    },
                    on: {
                        ended: e.endedVideo,
                        fullscreenchange: e.fullScreen
                    }
                }), e._v(" "), i("div", {
                    staticClass: "tab-name"
                }, [ e._v("\n      课程概述\n    ") ]), e._v(" "), i("div", {
                    staticClass: "img-detail"
                }, [ i("ImgDetail", {
                    attrs: {
                        course: e.course,
                        isBuy: e.isBuy,
                        mpcomid: "1"
                    }
                }) ], 1) ], 1), e._v(" "), i("div", {
                    staticClass: "pc-course__right"
                }, [ i("div", {
                    staticClass: "tab-name shadow"
                }, [ e._v("\n      课时目录\n    ") ]), e._v(" "), i("ListVideo", {
                    attrs: {
                        myClass: "pc-list",
                        subCourse: e.subCourse,
                        lessonList: e.lessonList,
                        isBuy: e.isBuy,
                        eventid: "1",
                        mpcomid: "2"
                    },
                    on: {
                        queryLesson: e.getLessonVideo,
                        viewVideo: e.viewVideo,
                        switchCourse: e.switchCourse
                    }
                }) ], 1) ]);
            },
            staticRenderFns: []
        };
    },
    Lv0b: function(e, t) {},
    MZ83: function(e, t, i) {
        var n = i("1hDP"), o = i("fv49"), s = i("ybqe")(n.a, o.a, function(e) {
            i("+/VV");
        }, "data-v-67e46a69", null);
        t.a = s.exports;
    },
    O8SU: function(e, t, i) {
        t.a = {
            render: function() {
                var e = this, t = e.$createElement, i = e._self._c || t;
                return i("div", {
                    class: [ e.myClass ]
                }, [ i("xk-video-player", {
                    attrs: {
                        id: "my-video",
                        playerId: "my-video",
                        poster: e.videoConfig.poster || "",
                        src: e.videoConfig.src || "",
                        objectFit: e.videoConfig.objectFit || "fill",
                        direction: 90,
                        showScreenLockButton: !0,
                        enablePlayGesture: !0,
                        enableAutoRotation: !0,
                        initialTime: e.videoConfig.initialTime || 0,
                        title: "研芝士课程",
                        width: e.videoConfig.xkVideoWidth || 100,
                        height: e.videoConfig.xkVideoHeight || 100,
                        eventid: "3",
                        mpcomid: "0"
                    },
                    on: {
                        controlstoggle: e.bindcontrolstoggle,
                        ended: function(t) {
                            e.$emit("ended");
                        },
                        fullscreenchange: function(t) {
                            e.$emit("fullscreenchange");
                        },
                        timeupdate: function(t) {
                            e.$emit("timeupdate");
                        },
                        pause: function(t) {
                            e.$emit("pause");
                        }
                    }
                }, [ !e.showSpeed && e.showBtn ? i("div", {
                    staticClass: "speed",
                    attrs: {
                        eventid: "0"
                    },
                    on: {
                        click: function(t) {
                            e.showSpeed = !0;
                        }
                    }
                }, [ e._v("\n      倍速\n    ") ]) : e._e(), e._v(" "), e.showSpeed ? i("div", {
                    staticClass: "speed-mask",
                    attrs: {
                        eventid: "1"
                    },
                    on: {
                        click: function(t) {
                            e.showSpeed = !1;
                        }
                    }
                }) : e._e(), e._v(" "), i("div", {
                    class: [ "speed-sel", e.showSpeed && "show" ]
                }, e._l(e.speed, function(t, n) {
                    return i("div", {
                        key: n,
                        class: [ n === e.activeIndex && "active" ],
                        attrs: {
                            eventid: "2_" + n
                        },
                        on: {
                            click: function(t) {
                                e.changeSpeed(n);
                            }
                        }
                    }, [ e._v("\n        " + e._s(t) + "\n      ") ]);
                })) ]) ], 1);
            },
            staticRenderFns: []
        };
    },
    Po2K: function(e, t, i) {
        t.a = {
            render: function() {
                var e = this.$createElement, t = this._self._c || e;
                return t("div", {
                    staticClass: "list-detail"
                }, [ t("img", {
                    staticClass: "full-width",
                    attrs: {
                        src: this.course.courseDetail,
                        mode: "widthFix",
                        alt: ""
                    }
                }), this._v(" "), this.isBuy ? this._e() : t("shop-button", {
                    attrs: {
                        text: "立即抢购",
                        path: this.course.buyUrl,
                        mpcomid: "0"
                    }
                }) ], 1);
            },
            staticRenderFns: []
        };
    },
    "XA/O": function(e, t) {},
    a2hA: function(e, t, i) {
        var n = i("5p1C"), o = i("O8SU"), s = i("ybqe")(n.a, o.a, function(e) {
            i("fjL2");
        }, null, null);
        t.a = s.exports;
    },
    a7Ge: function(e, t, i) {
        var n = i("nC+E"), o = i("HTW1"), s = i("ybqe")(n.a, o.a, function(e) {
            i("Lv0b");
        }, null, null);
        t.a = s.exports;
    },
    "e/Dn": function(e, t, i) {
        var n = i("hc22"), o = i("Po2K"), s = i("ybqe")(n.a, o.a, function(e) {
            i("Cz5A");
        }, null, null);
        t.a = s.exports;
    },
    fWdb: function(e, t, i) {
        t.a = {
            render: function() {
                var e = this, t = e.$createElement, i = e._self._c || t;
                return i("div", {
                    class: [ "video", e.isDark && "dark" ]
                }, [ e.isPcEquipment ? i("PcView", {
                    attrs: {
                        videoContent: e.videoContent,
                        course: e.course,
                        fromMyCourse: e.fromMyCourse,
                        mpcomid: "1"
                    }
                }) : i("MobileView", {
                    attrs: {
                        videoContent: e.videoContent,
                        course: e.course,
                        fromMyCourse: e.fromMyCourse,
                        mpcomid: "0"
                    }
                }) ], 1);
            },
            staticRenderFns: []
        };
    },
    fjL2: function(e, t) {},
    fv49: function(e, t, i) {
        t.a = {
            render: function() {
                var e = this, t = e.$createElement, i = e._self._c || t;
                return e.subCourse.length > 0 ? i("div", {
                    class: [ "list", e.myClass ]
                }, e._l(e.subCourse, function(t, n) {
                    return i("div", {
                        key: n,
                        staticClass: "course-item"
                    }, [ i("div", {
                        staticClass: "list-title",
                        attrs: {
                            eventid: "0_" + n
                        },
                        on: {
                            click: function(i) {
                                e.switchShowCourseList(t);
                            }
                        }
                    }, [ i("span", [ i("i-icon", {
                        attrs: {
                            type: t.show ? "unfold" : "enter",
                            size: "14",
                            color: "#333",
                            mpcomid: "0_" + n
                        }
                    }) ], 1), e._v(" "), i("span", {
                        staticClass: "course-name"
                    }, [ e._v(e._s(t.courseName)) ]) ]), e._v(" "), t.show ? i("div", {
                        staticClass: "list-content"
                    }, [ t.loading ? i("div", [ i("page-loading", {
                        attrs: {
                            mpcomid: "2_" + n
                        }
                    }) ], 1) : i("div", e._l(e.lessonList[t.id], function(t, o) {
                        return i("div", {
                            key: o,
                            class: [ "list-item", t.active && "active" ],
                            attrs: {
                                eventid: "1_" + n + "-" + o
                            },
                            on: {
                                click: function(i) {
                                    e.selectLesson(t);
                                }
                            }
                        }, [ i("div", {
                            staticClass: "list-item__left"
                        }, [ i("img", {
                            staticClass: "dot",
                            attrs: {
                                src: "//static.yanzhishi.cn/images/wechat/cheese2.png",
                                alt: "cheese"
                            }
                        }), e._v(" "), i("div", {
                            staticClass: "list-name"
                        }, [ e._v("\n              " + e._s(t.lessonName) + "\n            ") ]) ]), e._v(" "), e.isBuy ? e._e() : i("div", {
                            staticClass: "list-item__right"
                        }, [ 2 == t.isFree ? i("span", {
                            staticClass: "free"
                        }, [ e._v("试学") ]) : i("span", {
                            staticClass: "lock"
                        }, [ i("i-icon", {
                            attrs: {
                                type: "lock",
                                size: "24",
                                color: "#80848f",
                                mpcomid: "1_" + n + "-" + o
                            }
                        }) ], 1) ]) ]);
                    })) ]) : e._e() ]);
                })) : e._e();
            },
            staticRenderFns: []
        };
    },
    hc22: function(e, t, i) {
        var n = i("uOcP");
        t.a = {
            components: {
                ShopButton: n.a
            },
            props: {
                course: {
                    type: Object,
                    default: function() {}
                },
                isBuy: {
                    type: Boolean,
                    default: !1
                }
            }
        };
    },
    ivHZ: function(e, t, i) {
        Object.defineProperty(t, "__esModule", {
            value: !0
        });
        var n = i("5nAL"), o = i.n(n), s = i("wswF"), a = i("ltdW"), c = (i.n(a), i("ocgm")), r = (i.n(c), 
        i("sGGH"));
        i.n(r), new o.a(s.a).$mount();
    },
    jBo7: function(e, t, i) {
        var n = i("MZ83"), o = i("a2hA"), s = i("e/Dn"), a = i("WvcL"), c = i("3waA"), r = i("vm46");
        t.a = {
            components: {
                ImgDetail: s.a,
                ListVideo: n.a,
                XkVideo: o.a,
                "i-tabs": a.a,
                "i-tab": c.a
            },
            mixins: [ r.a ],
            props: {
                videoContent: {
                    type: Object,
                    default: function() {}
                },
                course: {
                    type: Object,
                    default: function() {}
                },
                fromMyCourse: {
                    type: Boolean,
                    default: !1
                }
            },
            data: function() {
                return {
                    videoConfig: {
                        autoPlay: !1,
                        src: "",
                        poster: "",
                        objectFit: "fill",
                        initialTime: 0,
                        xkVideoWidth: "100vw",
                        xkVideoHeight: "450rpx"
                    }
                };
            }
        };
    },
    ly1e: function(e, t) {},
    m9zR: function(e, t, i) {
        var n = i("jBo7"), o = i("0NAv"), s = i("ybqe")(n.a, o.a, function(e) {
            i("XA/O"), i("2TbQ");
        }, "data-v-2b59afaa", null);
        t.a = s.exports;
    },
    "nC+E": function(e, t, i) {
        var n = i("MZ83"), o = i("a2hA"), s = i("e/Dn"), a = (i("WvcL"), i("3waA"), i("vm46"));
        t.a = {
            components: {
                XkVideo: o.a,
                ListVideo: n.a,
                ImgDetail: s.a
            },
            mixins: [ a.a ],
            props: {
                videoContent: {
                    type: Object,
                    default: function() {}
                },
                course: {
                    type: Object,
                    default: function() {}
                },
                fromMyCourse: {
                    type: Boolean,
                    default: !1
                }
            },
            data: function() {
                return {
                    videoConfig: {
                        src: "",
                        poster: "",
                        objectFit: "contain",
                        initialTime: 0,
                        xkVideoWidth: "65vw",
                        xkVideoHeight: "100vh"
                    }
                };
            },
            created: function() {
                var e = wx.getSystemInfoSync().windowWidth, t = wx.getSystemInfoSync().windowHeight;
                e > 992 && (this.videoConfig.xkVideoHeight = t / 2 + "px");
            },
            methods: {}
        };
    },
    vm46: function(e, t, i) {
        var n = i("Dd8w"), o = i.n(n), s = i("fZjL"), a = i.n(s), c = i("oFuF"), r = i("VsUZ"), u = [ {
            id: 1,
            name: "课程概述"
        }, {
            id: 2,
            name: "课时目录"
        } ], d = [ {
            id: 2,
            name: "课时目录"
        } ];
        t.a = {
            data: function() {
                return {
                    category: [ {
                        id: 1,
                        name: "课程概述"
                    }, {
                        id: 2,
                        name: "课时目录"
                    } ],
                    catalogId: 1,
                    subCourse: [],
                    lessonList: {},
                    courseId: "",
                    activeIndex: 0,
                    isBuy: !1
                };
            },
            watch: {
                course: {
                    handler: function(e) {
                        var t = this;
                        this.subCourse = [], this.lessonList = {}, this.catalogId = this.fromMyCourse ? 2 : 1, 
                        this.category = this.fromMyCourse ? d : u, 0 !== a()(e).length && (4 == e.courseType ? (this.courseId = e.courses[0].id, 
                        this.subCourse = e.courses.map(function(e) {
                            return o()({}, e, {
                                show: !1,
                                loading: !1
                            });
                        }) || []) : (this.courseId = e.id, this.subCourse = [ o()({}, e, {
                            show: !0,
                            loading: !1
                        }) ]), this.checkIsBuy(), this.getLessonVideo({
                            courseId: this.courseId
                        }, function() {
                            t.lessonList[t.courseId][0].active = !0, t.videoConfig.src = t.lessonList[t.courseId][0].lessonUrl, 
                            t.videoConfig.initialTime = t.lessonList[t.courseId][0].watchHistoryTime, t.videoConfig.poster = t.course.courseCover, 
                            t.videoConfig.autoPlay = !1;
                        }));
                    },
                    immediate: !0
                }
            },
            methods: {
                checkIsBuy: function() {
                    var e = this;
                    r.default.checkCourseAuth({
                        courseCode: this.course.courseCode
                    }, function(t) {
                        e.isBuy = t.data.data;
                    });
                },
                getLessonVideo: function(e, t) {
                    var i = this;
                    r.default.getLessonVideo(o()({
                        pageNum: 1,
                        pageSize: 500,
                        sort: "sort",
                        order: " asc"
                    }, e), function(n) {
                        i.$set(i.lessonList, e.courseId, n.data.data.list.map(function(e) {
                            return o()({}, e, {
                                active: !1
                            });
                        })), t && t();
                    }, function(e) {
                        401 === e.status && Object(c.repeatLogin)(function() {
                            i.getLessonVideo();
                        });
                    });
                },
                switchCourse: function(e) {
                    var t = this.subCourse;
                    e.show ? e.show = !e.show : this.subCourse = t.map(function(t) {
                        return o()({}, t, {
                            show: t.id === e.id
                        });
                    });
                },
                viewVideo: function(e) {
                    var t = this.lessonList, i = this.isBuy;
                    if (2 === e.isFree || i) {
                        for (var n in t) this.lessonList[n] = t[n].map(function(t) {
                            return t.id !== e.id ? t.active = !1 : t.active = !0, t;
                        });
                        this.videoConfig.src = e.lessonUrl, this.videoConfig.initialTime = e.watchHistoryTime, 
                        this.videoConfig.poster = e.courseCover, this.videoConfig.autoPlay = !0;
                    }
                },
                endedVideo: function() {
                    this.videoConfig.initialTime = 0;
                },
                fullScreen: function(e) {
                    e.mp.detail.fullScreen ? this.videoConfig.objectFit = "contain" : this.videoConfig.objectFit = "fill";
                }
            }
        };
    },
    wswF: function(e, t, i) {
        var n = i("BQd4"), o = i("fWdb"), s = i("ybqe")(n.a, o.a, function(e) {
            i("ly1e");
        }, null, null);
        t.a = s.exports;
    }
}, [ "ivHZ" ]);