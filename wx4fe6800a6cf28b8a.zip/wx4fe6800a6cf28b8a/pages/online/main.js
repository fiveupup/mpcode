require("../../common/manifest.js"), require("../../common/vendor.js"), global.webpackJsonpMpvue([ 24 ], {
    "3lcN": function(e, t, i) {
        t.a = {
            render: function() {
                var e = this, t = e.$createElement, i = e._self._c || t;
                return i("div", {
                    class: [ "online", e.isDark && "dark" ]
                }, [ e.notCheck ? i("div", {
                    staticClass: "error-box"
                }, [ i("tips-page", {
                    attrs: {
                        error: e.errorCode,
                        mpcomid: "0"
                    }
                }) ], 1) : i("div", {
                    staticClass: "question-list"
                }, e._l(e.examList, function(t, n) {
                    return i("div", {
                        key: n
                    }, [ i("div", {
                        staticClass: "list-line question-list-item",
                        attrs: {
                            eventid: "0_" + n
                        },
                        on: {
                            click: function(i) {
                                e.chooseExercise(t, n);
                            }
                        }
                    }, [ i("p", {
                        staticClass: "exam-title"
                    }, [ e._v(e._s(t.examinationName)) ]), e._v(" "), i("p", {
                        staticClass: "exam-info"
                    }, [ i("span", [ e._v("截止日期：" + e._s(t.endTime)) ]), e._v(" "), i("span", [ e._v("已完成" + e._s(t.applicationCode) + "次") ]) ]), e._v(" "), t.applicationCode > 0 ? i("img", {
                        staticClass: "finish",
                        attrs: {
                            src: "//static.yanzhishi.cn/images/wechat/exam_finish_1.png",
                            mode: "widthFix"
                        }
                    }) : e._e(), e._v(" "), t.applicationCode <= 0 && t.showBegin ? i("img", {
                        staticClass: "begin",
                        attrs: {
                            src: "//static.yanzhishi.cn/images/wechat/begin_exam.png",
                            mode: "widthFix"
                        }
                    }) : e._e() ], 1) ]);
                })) ]);
            },
            staticRenderFns: []
        };
    },
    "7Mm2": function(e, t, i) {
        var n = i("njfq"), a = i("3lcN"), s = i("ybqe")(n.a, a.a, function(e) {
            i("mv/N");
        }, "data-v-1710422a", null);
        t.a = s.exports;
    },
    FdDO: function(e, t, i) {
        Object.defineProperty(t, "__esModule", {
            value: !0
        });
        var n = i("5nAL"), a = i.n(n), s = i("7Mm2");
        new a.a(s.a).$mount();
    },
    "mv/N": function(e, t) {},
    njfq: function(e, t, i) {
        var n = i("VsUZ"), a = i("oFuF"), s = i("tXM+"), o = i("IcnI");
        t.a = {
            components: {
                TipsPage: s.a
            },
            data: function() {
                return {
                    examList: [],
                    notCheck: !1,
                    errorCode: 200,
                    isDark: wx.getStorageSync("isDark")
                };
            },
            onLoad: function() {
                this.getList(), this.isDark = Object(a.onChangeDark)();
            },
            methods: {
                getList: function() {
                    var e = this;
                    n.default.getOnlineExam({}, function(t) {
                        return e.errorCode = t.data.code, 200 !== t.data.code ? (e.notCheck = !0, !1) : 0 === t.data.data.length ? (e.errorCode = 4064, 
                        e.notCheck = !0, !1) : (e.notCheck = !1, void (e.examList = t.data.data.map(function(e) {
                            var t = Object(a.timeEffective)(e.startTime, e.endTime), i = t.isStart, n = t.isEnd;
                            return e.showBegin = i && !n, e.endTime = Object(a.formatTime)(new Date(e.endTime)), 
                            e;
                        }).sort(function(e, t) {
                            return e.examSort - t.examSort;
                        })));
                    }, function(t) {
                        401 === t.status && Object(a.repeatLogin)(function() {
                            e.getList();
                        });
                    });
                },
                chooseExercise: function(e) {
                    var t = !1, i = Object(a.timeEffective)(e.startTime, Date.parse(e.endTime)), n = i.isStart, s = i.isEnd;
                    n || (t = !0, wx.showToast({
                        title: "在线模考未到开始时间",
                        icon: "none"
                    })), s && (t = !0, wx.showToast({
                        title: "在线模考已结束",
                        icon: "none"
                    })), t || (wx.setStorageSync("isMember", !0), wx.setStorageSync("title", e.examinationName), 
                    o.a.commit("setExamination", e), wx.navigateTo({
                        url: "/pages/fastExercise/main",
                        success: function(t) {
                            t.eventChannel.emit("params", {
                                type: 7,
                                examId: e.id
                            });
                        }
                    }));
                }
            }
        };
    }
}, [ "FdDO" ]);