require("../../common/manifest.js"), require("../../common/vendor.js"), global.webpackJsonpMpvue([ 36 ], {
    Frst: function(e, t) {},
    OYka: function(e, t, s) {
        t.a = {
            render: function() {
                var e = this, t = e.$createElement, s = e._self._c || t;
                return s("div", {
                    class: [ "exercise-again", e.isDark && "dark" ]
                }, [ s("div", {
                    staticClass: "tag-content"
                }, [ s("div", {
                    staticClass: "tag"
                }, [ e._v(e._s(e.num) + "/" + e._s(e.exerciseTotal)) ]), e._v(" "), s("button", {
                    staticClass: "tag tag-right",
                    attrs: {
                        eventid: "0"
                    },
                    on: {
                        click: e.showAnswer
                    }
                }, [ e._v("答题卡") ]), e._v(" "), s("div", {
                    staticClass: "exercise"
                }, [ 1 === e.editExercise.exerciseType ? s("practice-choice", {
                    attrs: {
                        showAddMistake: !1,
                        showRemoveMistake: !1,
                        exercise: e.editExercise,
                        answer: e.userAnswer,
                        showAnswer: e.isSubmit,
                        majorId: e.majorId,
                        chapterId: e.chapterId,
                        eventid: "1",
                        mpcomid: "0"
                    },
                    on: {
                        changeAnswer: e.choosePracticeAnswer
                    }
                }) : e._e(), e._v(" "), 2 === e.editExercise.exerciseType ? s("practice-multiple", {
                    attrs: {
                        showAddMistake: !1,
                        showRemoveMistake: !1,
                        exercise: e.editExercise,
                        answer: e.userAnswer,
                        showAnswer: e.isSubmit,
                        majorId: e.majorId,
                        chapterId: e.chapterId,
                        eventid: "2",
                        mpcomid: "1"
                    },
                    on: {
                        changeAnswer: e.choosePracticeAnswer
                    }
                }) : e._e(), e._v(" "), 3 === e.editExercise.exerciseType ? s("practice-fill", {
                    attrs: {
                        showAddMistake: !1,
                        showRemoveMistake: !1,
                        exercise: e.editExercise,
                        answer: e.userAnswer,
                        showAnswer: e.isSubmit,
                        majorId: e.majorId,
                        chapterId: e.chapterId,
                        eventid: "3",
                        mpcomid: "2"
                    },
                    on: {
                        changeAnswer: e.choosePracticeAnswer
                    }
                }) : e._e(), e._v(" "), 4 === e.editExercise.exerciseType ? s("practice-short", {
                    attrs: {
                        showAddMistake: !1,
                        showRemoveMistake: !1,
                        exercise: e.editExercise,
                        answer: e.userAnswer,
                        showAnswer: e.isSubmit,
                        majorId: e.majorId,
                        chapterId: e.chapterId,
                        eventid: "4",
                        mpcomid: "3"
                    },
                    on: {
                        changeAnswer: e.choosePracticeAnswer
                    }
                }) : e._e(), e._v(" "), 5 === e.editExercise.exerciseType ? s("practice-judge", {
                    attrs: {
                        showAddMistake: !1,
                        showRemoveMistake: !1,
                        exercise: e.editExercise,
                        answer: e.userAnswer,
                        showAnswer: e.isSubmit,
                        majorId: e.majorId,
                        chapterId: e.chapterId,
                        eventid: "5",
                        mpcomid: "4"
                    },
                    on: {
                        changeAnswer: e.choosePracticeAnswer
                    }
                }) : e._e(), e._v(" "), 7 === e.editExercise.exerciseType ? s("practice-cloze", {
                    attrs: {
                        showAddMistake: !1,
                        showRemoveMistake: !1,
                        exercise: e.editExercise,
                        answer: e.userAnswer,
                        showAnswer: e.isSubmit,
                        majorId: e.majorId,
                        chapterId: e.chapterId,
                        eventid: "6",
                        mpcomid: "5"
                    },
                    on: {
                        changeAnswer: e.choosePracticeAnswer
                    }
                }) : e._e() ], 1) ], 1), e._v(" "), e.isSubmit ? s("two-button", {
                    attrs: {
                        eventid: "7",
                        mpcomid: "6"
                    },
                    on: {
                        nextFunc: e.nextExercise,
                        prevFunc: e.prevExercise
                    }
                }) : s("fixed-bottom", {
                    attrs: {
                        text: "确定",
                        clickBtn: e.submitSingleExercise,
                        mpcomid: "7"
                    }
                }), e._v(" "), s("answer-page", {
                    attrs: {
                        show: e.answerPageShow,
                        answers: e.answersList,
                        close: e.closeCard,
                        changeView: e.changeExercise,
                        mpcomid: "8"
                    }
                }) ], 1);
            },
            staticRenderFns: []
        };
    },
    Rvli: function(e, t, s) {
        Object.defineProperty(t, "__esModule", {
            value: !0
        });
        var i = s("zlN/"), a = s("5nAL");
        new (s.n(a).a)(i.a).$mount();
    },
    "zlN/": function(e, t, s) {
        var i = s("zoTd"), a = s("OYka"), r = s("ybqe")(i.a, a.a, function(e) {
            s("Frst");
        }, "data-v-701bb987", null);
        t.a = r.exports;
    },
    zoTd: function(e, t, s) {
        var i = s("VsUZ"), a = s("oFuF"), r = s("tXM+"), n = s("Oz7p"), c = s("DiM2"), o = s("ErS0"), d = s("SPm4"), h = s("cjSp"), w = s("Quls"), u = s("emV0"), m = s("5mIU"), l = s("pWcx"), x = s("IcnI");
        t.a = {
            components: {
                PracticeChoice: n.a,
                FixedBottom: u.a,
                TwoButton: m.a,
                PracticeFill: o.a,
                PracticeJudge: d.a,
                PracticeMultiple: c.a,
                PracticeShort: h.a,
                PracticeCloze: w.a,
                TipsPage: r.a,
                AnswerPage: l.a
            },
            data: function() {
                return {
                    exerciseTotal: 0,
                    editExercise: {
                        exerciseType: 1
                    },
                    isSubmit: !1,
                    num: 1,
                    nowAnswer: null,
                    nowStartTime: null,
                    majorId: null,
                    chapterId: null,
                    dateFlag: "",
                    sort: !1,
                    userAnswer: "",
                    detailParams: null,
                    completed: 0,
                    answerSource: 4,
                    answerPageShow: !1,
                    answersList: [],
                    examCategory: 1,
                    isDark: wx.getStorageSync("isDark")
                };
            },
            computed: {
                nextPageAddFlag: function() {
                    return x.a.state.nextPageAddFlag;
                }
            },
            onLoad: function() {
                var e = this;
                this.isDark = Object(a.onChangeDark)(), this.$mp.page.getOpenerEventChannel().on("params", function(t) {
                    e.majorId = t.majorId, e.chapterId = t.chapterId, e.dateFlag = t.dateFlag, e.sort = t.sort, 
                    e.answerSource = t.answerSource, e.examCategory = t.examCategory, e.getMistake(!0);
                });
            },
            onUnload: function() {
                this.isSubmit = !1, this.userAnswer = "", this.nowAnswer = null, this.completed = 0, 
                this.num = 1;
            },
            methods: {
                getMistake: function(e) {
                    var t = this, s = this.majorId, r = this.chapterId, n = this.num, c = this.dateFlag, o = this.sort, d = this.answerSource, h = this.examCategory, w = "getMistakenExerciseList";
                    5 === d && (w = "getCollectExercise"), i.default[w]({
                        majorId: s,
                        chapterId: r,
                        pageNum: n,
                        pageSize: 1,
                        dateFlag: c,
                        examCategory: h,
                        sort: o ? "incorrect_number" : "create_date"
                    }, function(s) {
                        var i = s.data.data;
                        if (t.exerciseTotal = i.total, e) for (var a = 0; a < i.total; a++) t.answersList[a] = {
                            answer: ""
                        };
                        t.nowStartTime = new Date().getTime(), t.detailParams = {
                            exerciseId: i.list[0].exerciseId,
                            examRecordId: ""
                        };
                        var r = t.num;
                        t.nextPageAddFlag || (r += 1, t.answersList[r - 1].answer), "" !== t.answersList[r - 1].answer ? t.getDetail(i) : t.editExercise = i.list[0], 
                        x.a.commit("setNextPageAddFlag", !0);
                    }, function(e) {
                        401 === e.status && Object(a.repeatLogin)(function() {
                            t.getMistake();
                        });
                    }, !1);
                },
                prevExercise: function() {
                    this.num > 1 ? (this.num -= 1, this.checkIsDone(), this.getMistake()) : wx.showToast({
                        title: "已经是第一题啦",
                        icon: "none"
                    });
                },
                nextExercise: function() {
                    this.num < this.exerciseTotal ? (this.nextPageAddFlag && (this.num += 1), this.checkIsDone(), 
                    this.getMistake()) : wx.showToast({
                        title: "已经是最后一题啦",
                        icon: "none"
                    });
                },
                choosePracticeAnswer: function(e) {
                    3 === this.editExercise.exerciseType ? this.nowAnswer = e.map(function(e) {
                        return e.value;
                    }).join("$-$") : 4 === this.editExercise.exerciseType || 7 === this.editExercise.exerciseType ? this.nowAnswer = e.join(",") : this.nowAnswer = e, 
                    this.answersList[this.num - 1].answer = e;
                },
                submitSingleExercise: function() {
                    var e = this.nowAnswer, t = this.editExercise, s = t.exerciseId, i = t.exerciseType, a = t.majorId, r = t.chapterId, n = t.exerciseAnswer, c = this.nowStartTime, o = this.answerSource, d = this.examCategory;
                    if (null !== e && "" !== e) {
                        this.isSubmit = !0;
                        var h = {
                            exerciseId: s,
                            type: i,
                            majorId: a,
                            chapterId: r,
                            score: e === n ? 2 : 0,
                            answer: e,
                            answerType: 3 === i ? 3 : e === n ? 1 : 2,
                            markStatus: 1,
                            startTime: c,
                            endTime: new Date().getTime(),
                            answerSource: o,
                            examCategory: d
                        };
                        this.submitRequest(h);
                    } else wx.showToast({
                        title: "请选择或填写答案",
                        icon: "none"
                    });
                },
                submitRequest: function(e) {
                    var t = this;
                    this.completed += 1, i.default.redoExercise(e, function(e) {
                        console.log(e);
                    }, function(s) {
                        401 === s.status && Object(a.repeatLogin)(function() {
                            t.submitRequest(e);
                        });
                    });
                },
                getDetail: function(e) {
                    var t = this;
                    i.default.getRecordDetail(this.detailParams, function(s) {
                        t.userAnswer = s.data.data, t.editExercise = e.list[0];
                    }, function(e) {
                        401 === e.status && Object(a.repeatLogin)(function() {
                            t.getDetail();
                        });
                    });
                },
                showAnswer: function() {
                    this.answerPageShow = !0;
                },
                closeCard: function() {
                    this.answerPageShow = !1;
                },
                changeExercise: function(e) {
                    this.num = e + 1, this.checkIsDone(), this.answerPageShow = !1, this.getMistake();
                },
                checkIsDone: function() {
                    var e = this.num;
                    this.nextPageAddFlag || (e += 1, this.answersList[e - 1].answer), "" === this.answersList[e - 1].answer ? (this.userAnswer = "", 
                    this.nowAnswer = null, this.isSubmit = !1) : this.isSubmit = !0;
                }
            }
        };
    }
}, [ "Rvli" ]);