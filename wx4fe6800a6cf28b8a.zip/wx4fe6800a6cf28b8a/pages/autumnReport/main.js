require("../../common/manifest.js"), require("../../common/vendor.js"), global.webpackJsonpMpvue([ 45 ], {
    DqCq: function(t, s, a) {
        var i = a("ZepB"), r = a("TlsN"), e = a("ybqe")(i.a, r.a, function(t) {
            a("aK/G");
        }, "data-v-1a8cd901", null);
        s.a = e.exports;
    },
    NlNa: function(t, s, a) {
        Object.defineProperty(s, "__esModule", {
            value: !0
        });
        var i = a("5nAL"), r = a.n(i), e = a("DqCq");
        new r.a(e.a).$mount();
    },
    TlsN: function(t, s, a) {
        s.a = {
            render: function() {
                var t = this, s = t.$createElement, a = t._self._c || s;
                return a("div", {
                    class: [ "summer-report", t.isDark && "dark" ]
                }, [ a("div", {
                    staticClass: "back",
                    attrs: {
                        eventid: "0"
                    },
                    on: {
                        click: t.backPrePage
                    }
                }, [ a("img", {
                    attrs: {
                        src: "http://static.yanzhishi.cn/images/wechat/back.png",
                        mode: "widthFix",
                        alt: "back"
                    }
                }) ]), t._v(" "), a("swiper", {
                    staticClass: "swiper",
                    attrs: {
                        vertical: !0
                    }
                }, [ a("swiper-item", {
                    staticClass: "swiper-item",
                    staticStyle: {
                        width: "100%"
                    },
                    attrs: {
                        scrollY: "true",
                        bindscroll: "scroll",
                        mpcomid: "0"
                    }
                }, [ a("img", {
                    staticClass: "bg",
                    attrs: {
                        src: "//static.yanzhishi.cn/images/wechat/report/report_all_year1.png",
                        alt: "report"
                    }
                }), t._v(" "), a("div", {
                    staticClass: "home"
                }, [ a("p", [ a("span", {
                    staticClass: "year"
                }, [ t._v("2021年") ]) ]), t._v(" "), a("p", {
                    staticClass: "subtitle"
                }, [ t._v("\n          全国计算机专业考研学生\n        ") ]), t._v(" "), a("p", {
                    staticClass: "title"
                }, [ t._v("\n          刷题数据报告\n        ") ]) ], 1), t._v(" "), a("img", {
                    staticClass: "arrow",
                    attrs: {
                        src: "//static.yanzhishi.cn/images/wechat/report/report_arrow.png",
                        alt: "arrow"
                    }
                }) ]), t._v(" "), a("swiper-item", {
                    staticClass: "swiper-item",
                    staticStyle: {
                        width: "100%"
                    },
                    attrs: {
                        scrollY: "true",
                        bindscroll: "scroll",
                        mpcomid: "1"
                    }
                }, [ a("img", {
                    staticClass: "bg",
                    attrs: {
                        src: "//static.yanzhishi.cn/images/wechat/report/report_all_year2.png",
                        alt: "report"
                    }
                }), t._v(" "), a("div", {
                    staticClass: "home"
                }, [ a("p", {
                    staticClass: "page-second"
                }, [ t._v("\n          21考研已匆匆过去"), a("br"), t._v("7月1日开始，"), a("br"), t._v("不知不觉『研芝士题库』陪伴21考研学生走过了"), a("span", [ t._v(t._s(t.distanceStart)) ]), t._v("天！\n        ") ], 1) ], 1), t._v(" "), a("p", {
                    staticClass: "slogan"
                }, [ t._v("\n        ——数据来源于研芝士教育大数据平台\n      ") ]), t._v(" "), a("img", {
                    staticClass: "arrow",
                    attrs: {
                        src: "//static.yanzhishi.cn/images/wechat/report/report_arrow.png",
                        alt: "arrow"
                    }
                }) ], 1), t._v(" "), a("swiper-item", {
                    staticClass: "swiper-item",
                    staticStyle: {
                        width: "100%"
                    },
                    attrs: {
                        scrollY: "true",
                        bindscroll: "scroll",
                        mpcomid: "2"
                    }
                }, [ a("img", {
                    staticClass: "bg",
                    attrs: {
                        src: "//static.yanzhishi.cn/images/wechat/report/report_all_year3.png",
                        alt: "report"
                    }
                }), t._v(" "), a("div", {
                    staticClass: "home user-increase"
                }, [ a("p", {
                    staticClass: "page-second"
                }, [ t._v("\n          平均每月产生30W+刷题记录\n        ") ]), t._v(" "), a("p", {
                    staticClass: "page-second-subtitle"
                }, [ t._v("\n          紧张的复习阶段"), a("br"), t._v("总有些简单而美好的相遇~\n        ") ], 1), t._v(" "), a("img", {
                    staticClass: "echart-line",
                    attrs: {
                        src: "//static.yanzhishi.cn/images/wechat/line_add_all.png",
                        mode: "widthFix",
                        alt: "report"
                    }
                }), t._v(" "), a("p", {
                    staticClass: "line-title"
                }, [ t._v("\n          用户刷题记录增量趋势图\n        ") ]) ], 1), t._v(" "), a("p", {
                    staticClass: "slogan"
                }, [ t._v("\n        ——数据来源于研芝士教育大数据平台\n      ") ]), t._v(" "), a("img", {
                    staticClass: "arrow",
                    attrs: {
                        src: "//static.yanzhishi.cn/images/wechat/report/report_arrow.png",
                        alt: "arrow"
                    }
                }) ], 1), t._v(" "), a("swiper-item", {
                    staticClass: "swiper-item",
                    staticStyle: {
                        width: "100%"
                    },
                    attrs: {
                        scrollY: "true",
                        bindscroll: "scroll",
                        mpcomid: "3"
                    }
                }, [ a("img", {
                    staticClass: "bg",
                    attrs: {
                        src: "//static.yanzhishi.cn/images/wechat/report/report_all_year4.png",
                        alt: "report"
                    }
                }), t._v(" "), a("div", {
                    staticClass: "home ranking"
                }, [ a("p", {
                    staticClass: "first-line"
                }, [ t._v("\n          全国学生累计刷题量排名前三的用户微信昵称分别为：\n        ") ]), t._v(" "), a("div", {
                    staticClass: "avator"
                }, [ a("div", [ a("p", {
                    staticClass: "wechat-name"
                }, [ t._v("\n              范加索尔拉\n            ") ]), t._v(" "), a("p", {
                    staticClass: "wechat-num"
                }, [ t._v("\n              9944道\n            ") ]) ], 1), t._v(" "), a("div", [ a("p", {
                    staticClass: "wechat-name"
                }, [ t._v("\n              梅花\n            ") ]), t._v(" "), a("p", {
                    staticClass: "wechat-num"
                }, [ t._v("\n              9773道\n            ") ]) ], 1), t._v(" "), a("div", [ a("p", {
                    staticClass: "wechat-name"
                }, [ t._v("\n              糖木\n            ") ]), t._v(" "), a("p", {
                    staticClass: "wechat-num"
                }, [ t._v("\n              8302道\n            ") ]) ], 1) ]) ], 1), t._v(" "), a("p", {
                    staticClass: "slogan"
                }, [ t._v("\n        ——数据来源于研芝士教育大数据平台\n      ") ]), t._v(" "), a("img", {
                    staticClass: "arrow",
                    attrs: {
                        src: "//static.yanzhishi.cn/images/wechat/report/report_arrow.png",
                        alt: "arrow"
                    }
                }) ], 1), t._v(" "), a("swiper-item", {
                    staticClass: "swiper-item",
                    staticStyle: {
                        width: "100%"
                    },
                    attrs: {
                        scrollY: "true",
                        bindscroll: "scroll",
                        mpcomid: "4"
                    }
                }, [ a("img", {
                    staticClass: "bg",
                    attrs: {
                        src: "//static.yanzhishi.cn/images/wechat/report/report_all_year5.png",
                        alt: "report"
                    }
                }), t._v(" "), a("div", {
                    staticClass: "home exercise"
                }, [ a("p", [ t._v("全国累计产生错题"), a("span", {
                    staticClass: "strong"
                }, [ t._v("624962") ]), t._v("道，") ]), t._v(" "), a("p", [ t._v("其中题目") ]), t._v(" "), a("div", {
                    staticClass: "example"
                }, [ a("p", {
                    staticClass: "example-title"
                }, [ t._v("\n            假设包含t个非零元素的稀疏矩阵A含有m行n列，并采用三元组顺序表压缩存储，其快速转置算法的时间复杂度为____。\n          ") ]), t._v(" "), a("p", {
                    staticClass: "example-mt"
                }, [ t._v("\n            A、O(m + t)\n          ") ]), t._v(" "), a("p", [ t._v("B、O(n + t)") ]), t._v(" "), a("p", [ t._v("C、O(m + n)") ]), t._v(" "), a("p", [ t._v("D、O(m * n)") ]), t._v(" "), a("p", [ t._v("参考答案：B") ]) ], 1), t._v(" "), a("p", {
                    staticClass: "last"
                }, [ t._v("\n          正确次数仅为"), a("span", {
                    staticClass: "strong"
                }, [ t._v("347") ]), t._v("次，错误次数达到"), a("span", {
                    staticClass: "strong"
                }, [ t._v("1490") ]), t._v("次，错误率高达"), a("span", {
                    staticClass: "strong"
                }, [ t._v("81.11%。") ]) ]) ], 1), t._v(" "), a("p", {
                    staticClass: "slogan"
                }, [ t._v("\n        ——数据来源于研芝士教育大数据平台\n      ") ]), t._v(" "), a("img", {
                    staticClass: "arrow",
                    attrs: {
                        src: "//static.yanzhishi.cn/images/wechat/report/report_arrow.png",
                        alt: "arrow"
                    }
                }) ], 1), t._v(" "), a("swiper-item", {
                    staticClass: "swiper-item",
                    staticStyle: {
                        width: "100%"
                    },
                    attrs: {
                        scrollY: "true",
                        bindscroll: "scroll",
                        mpcomid: "5"
                    }
                }, [ a("img", {
                    staticClass: "bg",
                    attrs: {
                        src: "//static.yanzhishi.cn/images/wechat/report/report_all_year5.png",
                        alt: "report"
                    }
                }), t._v(" "), a("div", {
                    staticClass: "home exercise"
                }, [ a("p", [ t._v("其中题目") ]), t._v(" "), a("div", {
                    staticClass: "example"
                }, [ a("p", {
                    staticClass: "example-title"
                }, [ t._v("\n            若某链表最常用的操作是在末尾插入结点和删除尾结点，则该链表最节省时间的存储方式是_____。\n          ") ]), t._v(" "), a("p", {
                    staticClass: "example-mt"
                }, [ t._v("\n            A、单链表\n          ") ]), t._v(" "), a("p", [ t._v("B、单循环链表") ]), t._v(" "), a("p", [ t._v("C、带尾指针的单循环链表") ]), t._v(" "), a("p", [ t._v("D、带头结点的双循环链表") ]), t._v(" "), a("p", [ t._v("参考答案：D") ]) ], 1), t._v(" "), a("p", {
                    staticClass: "last"
                }, [ t._v("\n          正确次数为"), a("span", {
                    staticClass: "strong"
                }, [ t._v("723") ]), t._v("次，错误次数达到"), a("span", {
                    staticClass: "strong"
                }, [ t._v("1545") ]), t._v("次，错误率达"), a("span", {
                    staticClass: "strong"
                }, [ t._v("68.12%。") ]) ]) ], 1), t._v(" "), a("p", {
                    staticClass: "slogan"
                }, [ t._v("\n        ——数据来源于研芝士教育大数据平台\n      ") ]), t._v(" "), a("img", {
                    staticClass: "arrow",
                    attrs: {
                        src: "//static.yanzhishi.cn/images/wechat/report/report_arrow.png",
                        alt: "arrow"
                    }
                }) ], 1), t._v(" "), a("swiper-item", {
                    staticClass: "swiper-item",
                    staticStyle: {
                        width: "100%"
                    },
                    attrs: {
                        scrollY: "true",
                        bindscroll: "scroll",
                        mpcomid: "6"
                    }
                }, [ a("img", {
                    staticClass: "bg",
                    attrs: {
                        src: "//static.yanzhishi.cn/images/wechat/report/report_all_year5.png",
                        alt: "report"
                    }
                }), t._v(" "), a("div", {
                    staticClass: "home exercise"
                }, [ a("p", [ t._v("其中题目") ]), t._v(" "), a("div", {
                    staticClass: "example"
                }, [ a("p", {
                    staticClass: "example-title"
                }, [ t._v("\n            数据在计算机存储器内表示时,根据结点关键字直接计算出该结点的存储地址,这种方法称为_____。\n          ") ]), t._v(" "), a("p", {
                    staticClass: "example-mt"
                }, [ t._v("\n            A、索引存储方式\n          ") ]), t._v(" "), a("p", [ t._v("B、顺序存储方式") ]), t._v(" "), a("p", [ t._v("C、链式存储方式") ]), t._v(" "), a("p", [ t._v("D、散列存储方式") ]), t._v(" "), a("p", [ t._v("参考答案：D") ]) ], 1), t._v(" "), a("p", {
                    staticClass: "last"
                }, [ t._v("\n          正确次数为"), a("span", {
                    staticClass: "strong"
                }, [ t._v("744") ]), t._v("次，错误次数达到"), a("span", {
                    staticClass: "strong"
                }, [ t._v("1272") ]), t._v("次，错误率达"), a("span", {
                    staticClass: "strong"
                }, [ t._v("63.10%。") ]) ]) ], 1), t._v(" "), a("p", {
                    staticClass: "slogan"
                }, [ t._v("\n        ——数据来源于研芝士教育大数据平台\n      ") ]), t._v(" "), a("img", {
                    staticClass: "arrow",
                    attrs: {
                        src: "//static.yanzhishi.cn/images/wechat/report/report_arrow.png",
                        alt: "arrow"
                    }
                }) ], 1), t._v(" "), a("swiper-item", {
                    staticClass: "swiper-item",
                    staticStyle: {
                        width: "100%"
                    },
                    attrs: {
                        scrollY: "true",
                        bindscroll: "scroll",
                        mpcomid: "8"
                    }
                }, [ a("img", {
                    staticClass: "bg",
                    attrs: {
                        src: "//static.yanzhishi.cn/images/wechat/report/report_all_year6.png",
                        alt: "report"
                    }
                }), t._v(" "), a("div", {
                    staticClass: "pie-swiper"
                }, [ a("p", [ t._v("各科目数量指标") ]), t._v(" "), a("swiper", {
                    staticClass: "pie",
                    attrs: {
                        indicatorDots: "",
                        autoplay: "",
                        circular: ""
                    }
                }, t._l(t.pieImg, function(s, i) {
                    return a("block", {
                        key: i
                    }, [ a("swiper-item", {
                        attrs: {
                            mpcomid: "7_" + i
                        }
                    }, [ a("img", {
                        attrs: {
                            src: s.url,
                            mode: "widthFix",
                            alt: ""
                        }
                    }), t._v(" "), a("p", [ t._v(t._s(s.title)) ]) ], 1) ], 1);
                })) ], 1), t._v(" "), a("p", {
                    staticClass: "slogan"
                }, [ t._v("\n        ——数据来源于研芝士教育大数据平台\n      ") ]), t._v(" "), a("img", {
                    staticClass: "arrow",
                    attrs: {
                        src: "//static.yanzhishi.cn/images/wechat/report/report_arrow.png",
                        alt: "arrow"
                    }
                }) ], 1), t._v(" "), a("swiper-item", {
                    staticClass: "swiper-item",
                    staticStyle: {
                        width: "100%"
                    },
                    attrs: {
                        scrollY: "true",
                        bindscroll: "scroll",
                        mpcomid: "9"
                    }
                }, [ a("img", {
                    staticClass: "bg",
                    attrs: {
                        src: "//static.yanzhishi.cn/images/wechat/report/report_all_year7.png",
                        alt: "report"
                    }
                }), t._v(" "), a("div", {
                    staticClass: "home statistics"
                }, [ a("p", [ t._v("每天"), a("br"), t._v("上午"), a("span", {
                    staticClass: "strong"
                }, [ t._v("7:00-9:30") ]), a("br"), t._v("晚上"), a("span", {
                    staticClass: "strong"
                }, [ t._v("23:00-00:30") ]), a("br"), t._v("是大家刷题最集中的时间段") ], 1), t._v(" "), a("p", [ t._v("考研复习应该刻苦，但也要注意休息哟~") ]) ], 1), t._v(" "), a("p", {
                    staticClass: "slogan"
                }, [ t._v("\n        ——数据来源于研芝士教育大数据平台\n      ") ]), t._v(" "), a("img", {
                    staticClass: "arrow",
                    attrs: {
                        src: "//static.yanzhishi.cn/images/wechat/report/report_arrow.png",
                        alt: "arrow"
                    }
                }) ], 1), t._v(" "), a("swiper-item", {
                    staticClass: "swiper-item",
                    staticStyle: {
                        width: "100%"
                    },
                    attrs: {
                        scrollY: "true",
                        bindscroll: "scroll",
                        mpcomid: "10"
                    }
                }, [ a("img", {
                    staticClass: "bg",
                    attrs: {
                        src: "//static.yanzhishi.cn/images/wechat/report/report_all_year8.png",
                        alt: "report"
                    }
                }), t._v(" "), a("div", {
                    staticClass: "home statistics"
                }, [ a("p", {
                    staticClass: "answer-subtitle"
                }, [ t._v("\n          点击答题，作答错误率\n        ") ]), t._v(" "), a("p", {
                    staticClass: "answer-title"
                }, [ t._v("\n          最高的前20题\n        ") ]), t._v(" "), a("div", {
                    staticClass: "btn"
                }, [ a("span", {
                    attrs: {
                        eventid: "1"
                    },
                    on: {
                        click: t.beginAnswer
                    }
                }, [ t._v("立即答题") ]) ]) ], 1) ]) ], 1), t._v(" "), a("login", {
                    attrs: {
                        userNotLogin: t.notLogin,
                        eventid: "2",
                        mpcomid: "11"
                    },
                    on: {
                        changeValue: t.changeNotLogin
                    }
                }) ], 1);
            },
            staticRenderFns: []
        };
    },
    ZepB: function(t, s, a) {
        var i = a("oFuF"), r = a("K31e"), e = a("oFuF");
        s.a = {
            components: {
                Login: r.a
            },
            data: function() {
                return {
                    isLogin: !1,
                    isClick: !1,
                    notLogin: !1,
                    userInfo: wx.getStorageSync("userInfo"),
                    isDark: wx.getStorageSync("isDark"),
                    distanceExam: Object(i.dayDistance)("2020-12-26"),
                    distanceStart: "178",
                    pieImg: [ {
                        url: "//static.yanzhishi.cn/images/wechat/report/question_number.png",
                        title: "刷题总数"
                    }, {
                        url: "//static.yanzhishi.cn/images/wechat/report/incorrent_number.png",
                        title: "错题总数"
                    }, {
                        url: "//static.yanzhishi.cn/images/wechat/report/rate_number.png",
                        title: "错误率"
                    } ]
                };
            },
            onLoad: function() {
                this.isDark = Object(i.onChangeDark)(), this.judgeLogin();
            },
            onShareAppMessage: function() {
                return {
                    title: "您收到一份全国计算机专业考研学生秋季刷题行为数据报告"
                };
            },
            onShareTimeline: function() {
                return {
                    title: "您收到一份全国计算机专业考研学生秋季刷题行为数据报告"
                };
            },
            methods: {
                backPrePage: function() {
                    wx.navigateBack();
                },
                beginAnswer: function() {
                    var t = this;
                    this.isLogin ? this.isClick || (this.isClick = !0, wx.setStorageSync("title", "错误率Top20"), 
                    wx.navigateTo({
                        url: "/pages/fastExercise/main",
                        success: function(s) {
                            s.eventChannel.emit("params", {
                                type: 5
                            }), setTimeout(function() {
                                t.isClick = !1;
                            }, 1e3);
                        }
                    })) : this.notLogin = !0;
                },
                changeNotLogin: function(t) {
                    this.notLogin = t, this.judgeLogin();
                },
                judgeLogin: function() {
                    var t = this;
                    Object(e.judgeLogin)().then(function() {
                        t.isLogin = !0;
                    }).catch(function() {
                        t.isLogin = !1;
                    });
                }
            }
        };
    },
    "aK/G": function(t, s) {}
}, [ "NlNa" ]);