var t = require("../../@babel/runtime/helpers/typeof");

require("../../@babel/runtime/helpers/Arrayincludes");

var e = {}, i = require("./libs/MpHtmlParser.js"), r = wx.getFileSystemManager && wx.getFileSystemManager();

Component({
    options: {
        pureDataPattern: /^[acdgtu]|W/
    },
    properties: {
        html: {
            type: null,
            observer: function(t) {
                this._refresh ? this._refresh = !1 : this.setContent(t, !1, !0);
            }
        },
        autopause: {
            type: Boolean,
            value: !0
        },
        autoscroll: Boolean,
        autosetTitle: {
            type: Boolean,
            value: !0
        },
        compress: Number,
        domain: String,
        lazyLoad: Boolean,
        selectable: Boolean,
        tagStyle: Object,
        showWithAnimation: Boolean,
        useAnchor: Boolean,
        useCache: Boolean
    },
    relations: {
        "../parser-group/parser-group": {
            type: "ancestor"
        }
    },
    created: function() {
        this.imgList = [], this.imgList.setItem = function(t, e) {
            var i = this;
            if (t && e) {
                if (0 == e.indexOf("http") && this.includes(e)) {
                    for (var a, n = "", s = 0; (a = e[s]) && ("/" != a || "/" == e[s - 1] || "/" == e[s + 1]); s++) n += Math.random() > .5 ? a.toUpperCase() : a;
                    return n += e.substr(s), this[t] = n;
                }
                if (this[t] = e, e.includes("data:image")) {
                    var o = e.match(/data:image\/(\S+?);(\S+?),(.+)/);
                    if (!o) return;
                    var l = "".concat(wx.env.USER_DATA_PATH, "/").concat(Date.now(), ".").concat(o[1]);
                    r && r.writeFile({
                        filePath: l,
                        data: o[3],
                        encoding: o[2],
                        success: function() {
                            return i[t] = l;
                        }
                    });
                }
            }
        }, this.imgList.each = function(t) {
            for (var e = 0, i = this.length; e < i; e++) this.setItem(e, t(this[e], e, this));
        };
    },
    detached: function() {
        this.imgList.each(function(t) {
            t && t.includes(wx.env.USER_DATA_PATH) && r && r.unlink({
                filePath: t
            });
        }), clearInterval(this._timer);
    },
    methods: {
        navigateTo: function(t) {
            var e = this;
            if (!this.data.useAnchor) return t.fail && t.fail({
                errMsg: "Anchor is disabled"
            });
            this.createSelectorQuery().select(".top" + (t.id ? ">>>#" + t.id : "")).boundingClientRect().selectViewport().scrollOffset().exec(function(i) {
                if (!i[0]) return e.group ? e.group.navigateTo(e.i, t) : t.fail && t.fail({
                    errMsg: "Label not found"
                });
                t.scrollTop = i[1].scrollTop + i[0].top + (t.offset || 0), wx.pageScrollTo(t);
            });
        },
        getText: function() {
            for (var t, e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : this.data.html, i = "", r = 0; t = e[r++]; ) if ("text" == t.type) i += t.text.replace(/&nbsp;/g, " ").replace(/&lt;/g, "<").replace(/&gt;/g, ">").replace(/&amp;/g, "&"); else if ("br" == t.type) i += "\n"; else {
                var a = "p" == t.name || "div" == t.name || "tr" == t.name || "li" == t.name || "h" == t.name[0] && t.name[1] > "0" && t.name[1] < "7";
                a && i && "\n" != i[i.length - 1] && (i += "\n"), t.children && (i += this.getText(t.children)), 
                a && "\n" != i[i.length - 1] ? i += "\n" : "td" != t.name && "th" != t.name || (i += "\t");
            }
            return i;
        },
        getVideoContext: function(t) {
            if (!t) return this.videoContexts;
            for (var e = this.videoContexts.length; e--; ) if (this.videoContexts[e].id == t) return this.videoContexts[e];
        },
        setContent: function(r, a, n) {
            var s = this, o = {};
            if (r) if ("string" == typeof r) {
                var l = new i(r, this.data);
                if (this.data.useCache) {
                    var h = function(t) {
                        for (var e = t.length, i = 5381; e--; ) i += (i << 5) + t.charCodeAt(e);
                        return i;
                    }(r);
                    e[h] ? o.html = e[h] : (o.html = l.parse(), e[h] = o.html);
                } else o.html = l.parse();
                this._refresh = !0, this.triggerEvent("parse", o.html);
            } else if (r.constructor == Array) {
                if (r.length && "Parser" != r[0].PoweredBy) {
                    var c = new i("", this.data);
                    !function t(e) {
                        for (var i, r = 0; i = e[r]; r++) if ("text" != i.type) {
                            for (var a in i.attrs = i.attrs || {}, i.attrs) "string" != typeof i.attrs[a] && (i.attrs[a] = i.attrs[a].toString());
                            c.matchAttr(i), i.children && (c.STACK.push(i), t(i.children), c.popNode(c.STACK.pop()));
                        }
                    }(r), o.html = r;
                }
                n || (o.html = r);
            } else {
                if ("object" != t(r) || !r.nodes) return console.warn("错误的 html 类型：" + t(r));
                o.html = r.nodes, console.warn("错误的 html 类型：object 类型已废弃");
            } else {
                if (n || a) return;
                o.html = "";
            }
            a ? (this._refresh = !0, o.html = (this.data.html || []).concat(o.html)) : this.data.showWithAnimation && (o.showAm = "animation: show .5s"), 
            (o.html || o.showAm) && this.setData(o), this.data.html.length && this.data.html[0].title && this.data.autosetTitle && wx.setNavigationBarTitle({
                title: this.data.html[0].title
            }), this.imgList.length = 0, this.videoContexts = [];
            for (var m, u, d = this.selectAllComponents(".top,.top>>>._node"), f = 0; m = d[f++]; ) {
                m.top = this;
                for (var g, p = 0; g = m.data.nodes[p++]; ) if (!g.c) if ("img" == g.name) this.imgList.setItem(g.attrs.i, g.attrs.src); else if ("video" == g.name || "audio" == g.name) {
                    var v;
                    (v = "video" == g.name ? wx.createVideoContext(g.attrs.id, m) : m.selectComponent("#" + g.attrs.id)) && (v.id = g.attrs.id, 
                    this.videoContexts.push(v));
                }
            }
            (wx.nextTick || setTimeout)(function() {
                return s.triggerEvent("load");
            }, 50), clearInterval(this._timer), this._timer = setInterval(function() {
                s.createSelectorQuery().select(".top").boundingClientRect(function(t) {
                    s.rect = t, t.height == u && (s.triggerEvent("ready", t), clearInterval(s._timer)), 
                    u = t.height;
                }).exec();
            }, 350);
        }
    }
});