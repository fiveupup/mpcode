var t = require("../../../@babel/runtime/helpers/objectSpread2"), e = require("../../../@babel/runtime/helpers/defineProperty");

Component({
    data: {
        canIUse: !!wx.chooseMessageFile,
        placeholder: "data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='300' height='225'/>",
        inlineTags: require("../libs/config.js").inlineTags,
        isDark: wx.getStorageSync("isDark")
    },
    properties: {
        nodes: Array,
        lazyLoad: Boolean
    },
    attached: function() {
        this.setData({
            isDark: wx.getStorageSync("isDark")
        });
    },
    methods: {
        play: function(t) {
            if (this.top.group && this.top.group.pause(this.top.i), this.top.videoContexts.length > 1 && this.top.data.autopause) for (var e = this.top.videoContexts.length; e--; ) this.top.videoContexts[e].id != t.currentTarget.id && this.top.videoContexts[e].pause();
        },
        imgtap: function(t) {
            var e = t.currentTarget.dataset.attrs;
            if (!e.ignore) {
                var a = !0;
                if (this.top.triggerEvent("imgtap", {
                    id: t.currentTarget.id,
                    src: e.src,
                    ignore: function() {
                        return a = !1;
                    }
                }), a) {
                    if (this.top.group) return this.top.group.preview(this.top.i, e.i);
                    var i = this.top.imgList, r = i[e.i] ? i[e.i] : (i = [ e.src ], e.src);
                    wx.previewImage({
                        showmenu: !1,
                        current: r,
                        urls: i
                    });
                }
            }
        },
        loadImg: function(t) {
            var a = t.target.dataset.i;
            this.data.lazyLoad && !this.data.nodes[a].load && this.setData(e({}, "nodes[".concat(a, "].load"), !0));
        },
        linkpress: function(t) {
            var e = !0, a = t.currentTarget.dataset.attrs;
            a.ignore = function() {
                return e = !1;
            }, this.top.triggerEvent("linkpress", a), e && (a["app-id"] ? wx.navigateToMiniProgram({
                appId: a["app-id"],
                path: a.path
            }) : a.href && ("#" == a.href[0] ? this.top.navigateTo({
                id: a.href.substring(1)
            }) : 0 == a.href.indexOf("http") || 0 == a.href.indexOf("//") ? wx.setClipboardData({
                data: a.href,
                success: function() {
                    return wx.showToast({
                        title: "链接已复制"
                    });
                }
            }) : wx.navigateTo({
                url: a.href,
                fail: function() {
                    wx.switchTab({
                        url: a.href
                    });
                }
            })));
        },
        error: function(a) {
            var i, r = this, s = a.target.dataset.source, o = a.target.dataset.i, n = this.data.nodes[o];
            if ("video" == s || "audio" == s) {
                var d = (n.i || 0) + 1;
                if (d < n.attrs.source.length) return this.setData(e({}, "nodes[".concat(o, "].i"), d));
                this.top && (i = this.top.getVideoContext(a.target.id));
            } else "img" == s && (i = {
                setSrc: function(t) {
                    r.setData(e({}, "nodes[".concat(o, "].attrs.src"), t));
                }
            });
            this.top && this.top.triggerEvent("error", t({
                source: s,
                target: a.target,
                context: i
            }, a.detail));
        },
        loadVideo: function(t) {
            var a = t.target.dataset.i;
            this.setData(e(e({}, "nodes[".concat(a, "].lazyLoad"), !1), "nodes[".concat(a, "].attrs.autoplay"), !0));
        }
    }
});