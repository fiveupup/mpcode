Component({
    properties: {
        cropperRatio: {
            type: Number,
            value: .7
        },
        cutRatio: {
            type: Number,
            value: 1
        },
        imageSrc: {
            type: String,
            value: ""
        },
        cropperWidth: {
            type: Number,
            value: 720
        },
        minCropperW: {
            type: Number,
            value: 100
        },
        cropperTips: {
            type: String,
            value: "一次只拍一道题更准确 可拖拽边框裁剪"
        }
    },
    data: {
        showImg: !1,
        cropperW: null,
        cropperH: null,
        scaleP: 0,
        cutL: 0,
        cutT: 0,
        cutB: 0,
        cutR: 0,
        qualityWidth: null,
        innerAspectRadio: null,
        filePath: null
    },
    methods: {
        close: function() {
            wx.hideLoading(), this.triggerEvent("close");
        },
        initStaticData: function() {
            this.drag = {
                CUT_L: null,
                CUT_T: null,
                CUT_R: null,
                CUT_B: null,
                CUT_W: null,
                CUT_H: null,
                IS_TOUCH_CONTENT: !1,
                IS_TOUCH_SIDE: !1,
                IS_NO_DRAG: !1,
                TOUCH_OFFSET_X: null,
                TOUCH_OFFSET_Y: null,
                TOUCH_MAX_MOVE_SECTION_X: null,
                TOUCH_MAX_MOVE_SECTION_Y: null,
                MOVE_PAGE_X: null,
                MOVE_PAGE_Y: null,
                SPACE_TOP_POSITION: null,
                SPACE_LEFT_POSITION: null,
                SPACE_RIGHT_POSITION: null,
                SPACE_BOTTOM_POSITION: null
            }, this.conf = {
                IMG_RATIO: null,
                IMG_REAL_W: null,
                IMG_REAL_H: null,
                CROPPER_HEIGHT: null,
                CROPPER_WIDTH: null,
                CUT_MIN_W: null,
                CUT_MIN_H: null,
                DRAG_MOVE_RATIO: 750 / wx.getSystemInfoSync().windowWidth,
                INIT_DRAG_POSITION: 0,
                DRAW_IMAGE_W: null,
                MAX_QW: 2550,
                MIN_CROPPER_DIS: 100
            };
        },
        getImage: function() {
            var t = this;
            wx.chooseImage({
                success: function(i) {
                    t.setData({
                        isShowImg: !1,
                        filePath: i.tempFilePaths[0]
                    }), t.loadImage(t.data.filePath);
                }
            });
        },
        loadImage: function(t) {
            var i = this;
            wx.showLoading({
                title: "图片加载中..."
            }), wx.getImageInfo({
                src: t || this.properties.imageSrc,
                success: function(t) {
                    i.conf.DRAW_IMAGE_W = i.conf.IMG_REAL_W = t.width, i.conf.IMG_REAL_H = t.height, 
                    i.conf.IMG_RATIO = Number((i.conf.IMG_REAL_W / i.conf.IMG_REAL_H).toFixed(5)), i.conf.CROPPER_HEIGHT = Math.ceil(i.properties.cropperWidth / i.conf.IMG_RATIO);
                    var a = Number((i.conf.IMG_REAL_W / i.properties.cropperWidth).toFixed(5)), e = i.conf.DRAW_IMAGE_W > i.conf.MAX_QW ? i.conf.MAX_QW : i.conf.DRAW_IMAGE_W, r = i.initPosition();
                    i.conf.IMG_RATIO >= 1 ? (i.conf.CROPPER_WIDTH = i.properties.cropperWidth, i.setData({
                        cropperW: i.properties.cropperWidth,
                        cropperH: i.conf.CROPPER_HEIGHT,
                        cutL: r.left,
                        cutT: r.top,
                        cutR: r.right,
                        cutB: r.bottom,
                        scaleP: a,
                        qualityWidth: e,
                        innerAspectRadio: i.conf.IMG_RATIO,
                        filePath: t.path
                    })) : i.setData({
                        cropperW: i.conf.CROPPER_WIDTH,
                        cropperH: i.conf.CROPPER_HEIGHT,
                        cutL: r.left,
                        cutT: r.top,
                        cutR: r.right,
                        cutB: r.bottom,
                        scaleP: a,
                        qualityWidth: e,
                        innerAspectRadio: i.conf.IMG_RATIO,
                        filePath: t.path
                    }), i.setMinCutInfo(), i.setData({
                        showImg: !0
                    }), wx.hideLoading();
                }
            });
        },
        getImageInfo: function() {
            var t = this;
            wx.showLoading({
                title: "图片生成中..."
            }), this.drag.IS_NO_DRAG = !0;
            var i = wx.createCanvasContext("wxCropperCanvas", t), a = this.data.qualityWidth, e = Math.ceil(this.data.qualityWidth / this.data.innerAspectRadio);
            i.drawImage(t.data.filePath, 0, 0, a, e), i.draw(!0, function() {
                var i = Math.ceil((t.data.cropperW - t.data.cutL - t.data.cutR) / t.data.cropperW * a), r = Math.ceil((t.data.cropperH - t.data.cutT - t.data.cutB) / t.data.cropperH * e), s = Math.ceil(t.data.cutL / t.data.cropperW * a), h = Math.ceil(t.data.cutT / t.data.cropperH * e);
                wx.canvasToTempFilePath({
                    x: s,
                    y: h,
                    width: i,
                    height: r,
                    destWidth: i,
                    destHeight: r,
                    quality: .9,
                    canvasId: "wxCropperCanvas",
                    success: function(a) {
                        var e = {
                            path: a.tempFilePath,
                            width: i,
                            height: r
                        };
                        t.triggerEvent("cutImage", e);
                    },
                    complete: function() {
                        wx.hideLoading(), t.drag.IS_NO_DRAG = !1;
                    }
                }, t);
            });
        },
        setMinCutInfo: function() {
            this.conf.CUT_MIN_W = this.properties.minCropperW, this.properties.cutRatio ? this.conf.CUT_MIN_H = this.conf.CUT_MIN_W / this.properties.cutRatio : this.conf.CUT_MIN_H = this.conf.CUT_MIN_W;
        },
        initPosition: function() {
            if (0 === this.properties.cutRatio && this.conf.IMG_RATIO >= 1) return {
                left: 0,
                right: 0,
                top: 0,
                bottom: 0
            };
            if (this.conf.IMG_RATIO >= 1) {
                if (this.conf.IMG_RATIO >= this.properties.cutRatio) {
                    var t = Math.ceil((this.properties.cropperWidth - this.conf.CROPPER_HEIGHT * this.properties.cutRatio) / 2);
                    return {
                        left: t,
                        right: t,
                        top: 0,
                        bottom: 0
                    };
                }
                var i = Math.ceil((this.conf.CROPPER_HEIGHT - this.properties.cropperWidth / this.properties.cutRatio) / 2);
                return {
                    left: 0,
                    right: 0,
                    top: i,
                    bottom: i
                };
            }
            if (this.properties.cropperRatio > this.conf.IMG_RATIO ? (this.conf.CROPPER_WIDTH = this.properties.cropperWidth / this.properties.cropperRatio * this.conf.IMG_RATIO, 
            this.conf.CROPPER_HEIGHT = this.properties.cropperWidth / this.properties.cropperRatio) : (this.conf.CROPPER_WIDTH = this.properties.cropperWidth, 
            this.conf.CROPPER_HEIGHT = this.properties.cropperWidth / this.conf.IMG_RATIO), 
            0 === this.properties.cutRatio) return {
                left: 0,
                right: 0,
                top: 0,
                bottom: 0
            };
            if (this.conf.IMG_RATIO >= this.properties.cutRatio) {
                var a = Math.ceil((this.conf.CROPPER_WIDTH - this.conf.CROPPER_HEIGHT * this.properties.cutRatio) / 2);
                return {
                    left: a,
                    right: a,
                    top: 0,
                    bottom: 0
                };
            }
            var e = Math.ceil((this.conf.CROPPER_HEIGHT - this.conf.CROPPER_WIDTH / this.properties.cutRatio) / 2);
            return {
                left: 0,
                right: 0,
                top: e,
                bottom: e
            };
        },
        contentDragStart: function(t) {
            if (!this.drag.IS_NO_DRAG) {
                this.drag.IS_TOUCH_CONTENT = !0, this.drag.TOUCH_OFFSET_X = t.touches[0].pageX * this.conf.DRAG_MOVE_RATIO - this.data.cutL, 
                this.drag.TOUCH_OFFSET_Y = t.touches[0].pageY * this.conf.DRAG_MOVE_RATIO - this.data.cutT;
                var i = this.cropperCurrentInfo();
                this.drag.TOUCH_MAX_MOVE_SECTION_X = i.x, this.drag.TOUCH_MAX_MOVE_SECTION_Y = i.y;
            }
        },
        cropperCurrentInfo: function() {
            var t = this.data.cutL + this.data.cutR, i = this.data.cutT + this.data.cutB;
            return this.drag.CUT_W = this.data.cropperW - t, this.drag.CUT_H = this.data.cropperH - i, 
            {
                x: t,
                y: i
            };
        },
        contentDragMove: function(t) {
            if (!this.drag.IS_NO_DRAG && this.drag.IS_TOUCH_CONTENT) {
                var i = t.touches[0].pageX * this.conf.DRAG_MOVE_RATIO - this.drag.TOUCH_OFFSET_X, a = t.touches[0].pageY * this.conf.DRAG_MOVE_RATIO - this.drag.TOUCH_OFFSET_Y, e = Math.min(this.drag.TOUCH_MAX_MOVE_SECTION_X, Math.max(0, i)), r = Math.min(this.drag.TOUCH_MAX_MOVE_SECTION_Y, Math.max(0, a));
                this.setData({
                    cutL: Math.ceil(e),
                    cutR: Math.ceil(this.data.cropperW - this.drag.CUT_W - e),
                    cutT: Math.ceil(r),
                    cutB: Math.ceil(this.data.cropperH - this.drag.CUT_H - r)
                }), this.drag.TOUCH_OFFSET_X = t.touches[0].pageX * this.conf.DRAG_MOVE_RATIO - this.data.cutL, 
                this.drag.TOUCH_OFFSET_Y = t.touches[0].pageY * this.conf.DRAG_MOVE_RATIO - this.data.cutT;
            }
        },
        contentTouchEnd: function() {
            this.drag.IS_TOUCH_CONTENT = !1;
        },
        sideDragStart: function(t) {
            this.drag.IS_NO_DRAG || (this.drag.IS_TOUCH_SIDE = !0, this.drag.MOVE_PAGE_X = t.touches[0].pageX, 
            this.drag.MOVE_PAGE_Y = t.touches[0].pageY, this.conf.CUT_T = this.data.cutT, this.conf.CUT_L = this.data.cutL, 
            this.conf.CUT_R = this.data.cutR, this.conf.CUT_B = this.data.cutB, this.drag.SPACE_TOP_POSITION = this.conf.CROPPER_HEIGHT - this.conf.CUT_B - this.conf.CUT_MIN_H, 
            this.drag.SPACE_BOTTOM_POSITION = this.conf.CROPPER_HEIGHT - this.conf.CUT_T - this.conf.CUT_MIN_H, 
            this.drag.SPACE_RIGHT_POSITION = this.conf.CROPPER_WIDTH - this.conf.CUT_L - this.conf.CUT_MIN_W, 
            this.drag.SPACE_LEFT_POSITION = this.conf.CROPPER_WIDTH - this.conf.CUT_R - this.conf.CUT_MIN_W);
        },
        sideDragMove: function(t) {
            if (!this.drag.IS_NO_DRAG && this.drag.IS_TOUCH_SIDE) {
                var i = t.target.dataset.drag;
                0 === this.properties.cutRatio ? this.sideDragMoveDefault(t, i) : this.sideDragMoveConst(t, i);
            }
        },
        sideDragEnd: function() {
            this.drag.IS_TOUCH_SIDE = !1;
        },
        sideDragMoveConst: function(t, i) {
            var a = (t.touches[0].pageX - this.drag.MOVE_PAGE_X) * this.conf.DRAG_MOVE_RATIO, e = (t.touches[0].pageY - this.drag.MOVE_PAGE_Y) * this.conf.DRAG_MOVE_RATIO;
            switch (i) {
              case "top":
                var r = this.conf.CUT_T + e;
                r = Math.ceil(r >= this.drag.SPACE_TOP_POSITION ? this.drag.SPACE_TOP_POSITION : r);
                var s = this.conf.CUT_L + e * this.properties.cutRatio;
                if ((s = Math.ceil(s >= this.drag.SPACE_LEFT_POSITION ? this.drag.SPACE_LEFT_POSITION : s)) < 0) {
                    if (this.data.cutT <= 0) return;
                    if (this.data.cutL >= 0) return;
                    return void this.setData({
                        cutL: 0
                    });
                }
                if (r <= 0) return void this.setData({
                    cutT: 0
                });
                this.setData({
                    cutT: r,
                    cutL: s
                });
                break;

              case "left":
                var h = this.conf.CUT_L + a;
                h = Math.ceil(h >= this.drag.SPACE_LEFT_POSITION ? this.drag.SPACE_LEFT_POSITION : h);
                var c = this.conf.CUT_B + a / this.properties.cutRatio;
                if ((c = Math.ceil(c >= this.drag.SPACE_BOTTOM_POSITION ? this.drag.SPACE_BOTTOM_POSITION : c)) < 0) {
                    if (this.data.cutL <= 0) return;
                    if (this.data.cutB >= 0) return;
                    return void this.setData({
                        cutB: 0
                    });
                }
                if (h <= 0) return void this.setData({
                    cutL: 0
                });
                this.setData({
                    cutL: h,
                    cutB: c
                });
                break;

              case "bottom":
                var o = this.conf.CUT_B - e;
                o = Math.ceil(o >= this.drag.SPACE_BOTTOM_POSITION ? this.drag.SPACE_BOTTOM_POSITION : o);
                var _ = this.conf.CUT_R - e * this.properties.cutRatio;
                if ((_ = Math.ceil(_ >= this.drag.SPACE_RIGHT_POSITION ? this.drag.SPACE_RIGHT_POSITION : _)) < 0) {
                    if (this.data.cutB <= 0) return;
                    if (this.data.cutR >= 0) return;
                    return void this.setData({
                        cutR: 0
                    });
                }
                if (o <= 0) return void this.setData({
                    cutB: 0
                });
                this.setData({
                    cutR: _,
                    cutB: o
                });
                break;

              case "right":
                var n = this.conf.CUT_R - a;
                n = Math.ceil(n >= this.drag.SPACE_RIGHT_POSITION ? this.drag.SPACE_RIGHT_POSITION : n);
                var T = this.conf.CUT_T - a / this.properties.cutRatio;
                if ((T = Math.ceil(T >= this.drag.SPACE_TOP_POSITION ? this.drag.SPACE_TOP_POSITION : T)) < 0) {
                    if (this.data.cutR <= 0) return;
                    if (this.data.cutT >= 0) return;
                    return void this.setData({
                        cutT: 0
                    });
                }
                if (n <= 0) return void this.setData({
                    cutR: 0
                });
                this.setData({
                    cutR: n,
                    cutT: T
                });
            }
        },
        sideDragMoveDefault: function(t, i) {
            var a = (t.touches[0].pageX - this.drag.MOVE_PAGE_X) * this.conf.DRAG_MOVE_RATIO, e = (t.touches[0].pageY - this.drag.MOVE_PAGE_Y) * this.conf.DRAG_MOVE_RATIO;
            switch (i) {
              case "top":
                var r = this.conf.CUT_T + e;
                r = r <= 0 ? 0 : r, r = Math.ceil(r >= this.drag.SPACE_TOP_POSITION ? this.drag.SPACE_TOP_POSITION : r), 
                this.setData({
                    cutT: r
                });
                break;

              case "bottom":
                var s = this.conf.CUT_B - e;
                s = s <= 0 ? 0 : s, s = Math.ceil(s >= this.drag.SPACE_BOTTOM_POSITION ? this.drag.SPACE_BOTTOM_POSITION : s), 
                this.setData({
                    cutB: s
                });
                break;

              case "right":
                var h = this.conf.CUT_R - a;
                h = h <= 0 ? 0 : h, h = Math.ceil(h >= this.drag.SPACE_RIGHT_POSITION ? this.drag.SPACE_RIGHT_POSITION : h), 
                this.setData({
                    cutR: h
                });
                break;

              case "left":
                var c = this.conf.CUT_L + a;
                c = c <= 0 ? 0 : c, c = Math.ceil(c >= this.drag.SPACE_LEFT_POSITION ? this.drag.SPACE_LEFT_POSITION : c), 
                this.setData({
                    cutL: c
                });
                break;

              case "rightBottom":
                var o = this.conf.CUT_R - a;
                o = o <= 0 ? 0 : o, o = Math.ceil(o >= this.drag.SPACE_RIGHT_POSITION ? this.drag.SPACE_RIGHT_POSITION : o);
                var _ = this.conf.CUT_B - e;
                _ = _ <= 0 ? 0 : _, _ = Math.ceil(_ >= this.drag.SPACE_BOTTOM_POSITION ? this.drag.SPACE_BOTTOM_POSITION : _), 
                this.setData({
                    cutB: _,
                    cutR: o
                });
            }
        }
    },
    created: function() {
        this.initStaticData();
    },
    attached: function() {
        this.loadImage();
    },
    ready: function() {},
    moved: function() {},
    detached: function() {}
});