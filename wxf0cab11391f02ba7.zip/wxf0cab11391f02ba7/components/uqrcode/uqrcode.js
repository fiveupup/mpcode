(global.webpackJsonp = global.webpackJsonp || []).push([ [ "components/uqrcode/uqrcode" ], {
    3979: function(e, t, n) {
        n.r(t);
        var o = n("c704"), r = n.n(o);
        for (var c in o) [ "default" ].indexOf(c) < 0 && function(e) {
            n.d(t, e, function() {
                return o[e];
            });
        }(c);
        t.default = r.a;
    },
    5023: function(e, t, n) {
        n.d(t, "b", function() {
            return o;
        }), n.d(t, "c", function() {
            return r;
        }), n.d(t, "a", function() {});
        var o = function() {
            this.$createElement;
            this._self._c;
        }, r = [];
    },
    c704: function(e, t, n) {
        (function(e) {
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = void 0;
            var o = function(e) {
                return e && e.__esModule ? e : {
                    default: e
                };
            }(n("e6cb"));
            function r(e, t) {
                var n = Object.keys(e);
                if (Object.getOwnPropertySymbols) {
                    var o = Object.getOwnPropertySymbols(e);
                    t && (o = o.filter(function(t) {
                        return Object.getOwnPropertyDescriptor(e, t).enumerable;
                    })), n.push.apply(n, o);
                }
                return n;
            }
            function c(e, t, n) {
                return t in e ? Object.defineProperty(e, t, {
                    value: n,
                    enumerable: !0,
                    configurable: !0,
                    writable: !0
                }) : e[t] = n, e;
            }
            var u = {
                name: "uqrcode",
                data: function() {
                    return {
                        options: {
                            canvasId: "",
                            size: 354,
                            margin: 10,
                            text: ""
                        },
                        result: {}
                    };
                },
                created: function() {
                    this.options.canvasId = "qrcode_".concat(this.uuid());
                },
                methods: {
                    make: function(e) {
                        var t = this;
                        return new Promise(function(n, u) {
                            o.default.make(Object.assign(t.options, e), t).then(function(e) {
                                t.result = e, n(function(e) {
                                    for (var t = 1; t < arguments.length; t++) {
                                        var n = null != arguments[t] ? arguments[t] : {};
                                        t % 2 ? r(Object(n), !0).forEach(function(t) {
                                            c(e, t, n[t]);
                                        }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(n)) : r(Object(n)).forEach(function(t) {
                                            Object.defineProperty(e, t, Object.getOwnPropertyDescriptor(n, t));
                                        });
                                    }
                                    return e;
                                }({}, e));
                            }).catch(function(e) {
                                u(e);
                            });
                        });
                    },
                    save: function() {
                        console.log(this.result), e.saveImageToPhotosAlbum({
                            filePath: this.result.tempFilePath,
                            success: function(t) {
                                e.showToast({
                                    icon: "success",
                                    title: "保存成功"
                                });
                            },
                            fail: function(t) {
                                e.showToast({
                                    icon: "none",
                                    title: JSON.stringify(t)
                                });
                            }
                        });
                    },
                    uuid: function() {
                        var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : 32, t = !(arguments.length > 1 && void 0 !== arguments[1]) || arguments[1], n = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : null, o = "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz".split(""), r = [];
                        if (n = n || o.length, e) for (var c = 0; c < e; c++) r[c] = o[0 | Math.random() * n]; else {
                            var u;
                            r[8] = r[13] = r[18] = r[23] = "-", r[14] = "4";
                            for (var i = 0; i < 36; i++) r[i] || (u = 0 | 16 * Math.random(), r[i] = o[19 == i ? 3 & u | 8 : u]);
                        }
                        return t ? (r.shift(), "u" + r.join("")) : r.join("");
                    }
                }
            };
            t.default = u;
        }).call(this, n("543d").default);
    },
    d757: function(e, t, n) {
        n.r(t);
        var o = n("5023"), r = n("3979");
        for (var c in r) [ "default" ].indexOf(c) < 0 && function(e) {
            n.d(t, e, function() {
                return r[e];
            });
        }(c);
        var u = n("f0c5"), i = Object(u.a)(r.default, o.b, o.c, !1, null, null, null, !1, o.a, void 0);
        t.default = i.exports;
    }
} ]), (global.webpackJsonp = global.webpackJsonp || []).push([ "components/uqrcode/uqrcode-create-component", {
    "components/uqrcode/uqrcode-create-component": function(e, t, n) {
        n("543d").createComponent(n("d757"));
    }
}, [ [ "components/uqrcode/uqrcode-create-component" ] ] ]);