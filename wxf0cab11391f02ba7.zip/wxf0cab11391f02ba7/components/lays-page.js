(global.webpackJsonp = global.webpackJsonp || []).push([ [ "components/lays-page" ], {
    "317d": function(t, e, a) {
        a.r(e);
        var n = a("e096"), o = a.n(n);
        for (var r in n) [ "default" ].indexOf(r) < 0 && function(t) {
            a.d(e, t, function() {
                return n[t];
            });
        }(r);
        e.default = o.a;
    },
    6310: function(t, e, a) {
        a.r(e);
        var n = a("f0ee"), o = a("317d");
        for (var r in o) [ "default" ].indexOf(r) < 0 && function(t) {
            a.d(e, t, function() {
                return o[t];
            });
        }(r);
        a("d0d0");
        var c = a("f0c5"), i = Object(c.a)(o.default, n.b, n.c, !1, null, "2a229adc", null, !1, n.a, void 0);
        e.default = i.exports;
    },
    "98d5": function(t, e, a) {},
    d0d0: function(t, e, a) {
        var n = a("98d5");
        a.n(n).a;
    },
    e096: function(t, e, a) {
        (function(t) {
            Object.defineProperty(e, "__esModule", {
                value: !0
            }), e.default = void 0;
            var n = function(t) {
                return t && t.__esModule ? t : {
                    default: t
                };
            }(a("4795")), o = a("f324");
            function r(t, e, a, n, o, r, c) {
                try {
                    var i = t[r](c), u = i.value;
                } catch (t) {
                    return void a(t);
                }
                i.done ? e(u) : Promise.resolve(u).then(n, o);
            }
            var c = {
                name: "LaysPage",
                props: {
                    title: String,
                    navExist: {
                        type: Boolean,
                        default: !0
                    },
                    statusBarExist: {
                        type: Boolean,
                        default: !0
                    },
                    isFixed: {
                        type: Boolean,
                        default: !0
                    },
                    isBack: {
                        type: Boolean,
                        default: !0
                    },
                    customer: {
                        type: Boolean,
                        default: !1
                    },
                    customerBottom: {
                        type: Number,
                        default: 300
                    }
                },
                data: function() {
                    return {
                        background: {
                            background: "url('https://pepsicocampuscrmstgblob.blob.core.chinacloudapi.cn/pepsicocampuscrmstgblob/FAQ_202304261714435683.png') no-repeat",
                            backgroundSize: "100%",
                            backgroundColor: "#010626",
                            backgroundPosition: "bottom"
                        },
                        statusBarHeight: 0,
                        barH: 0,
                        loginData: {}
                    };
                },
                mounted: function() {
                    var e = this, a = t.getStorageSync("loginData2");
                    this.loginData = a ? JSON.parse(a) : {}, t.setNavigationBarColor({
                        frontColor: "#ffffff",
                        animation: {
                            duration: 400,
                            timingFunc: "easeIn"
                        }
                    }), t.showShareMenu({
                        withShareTicket: !0,
                        menus: [ "shareAppMessage", "shareTimeline" ]
                    }), this.statusBarHeight = getApp().globalData.statusBarHeight, t.createSelectorQuery().in(this).select("#barH").boundingClientRect(function(t) {
                        e.barH = t.top;
                    }).exec();
                },
                methods: {
                    initCustomerParams: function() {
                        var t = this;
                        return function(t) {
                            return function() {
                                var e = this, a = arguments;
                                return new Promise(function(n, o) {
                                    var c = t.apply(e, a);
                                    function i(t) {
                                        r(c, n, o, i, u, "next", t);
                                    }
                                    function u(t) {
                                        r(c, n, o, i, u, "throw", t);
                                    }
                                    i(void 0);
                                });
                            };
                        }(n.default.mark(function e() {
                            var a, r, c, i, u, s, l;
                            return n.default.wrap(function(e) {
                                for (;;) switch (e.prev = e.next) {
                                  case 0:
                                    if (r = new Date().getDate(), getApp().globalData.kfExpireDate === r) {
                                        e.next = 8;
                                        break;
                                    }
                                    return e.next = 4, (0, o.token)();

                                  case 4:
                                    c = e.sent, i = c.data, getApp().globalData.kfToken = i.data, getApp().globalData.kfExpireDate = r;

                                  case 8:
                                    return e.next = 10, (0, o.orderLately)();

                                  case 10:
                                    u = e.sent, s = u.data, l = s.data ? {
                                        visible: !0,
                                        actionText: "发送",
                                        title: s.data.title,
                                        sub_title: s.data.orderNo,
                                        other_title_one: "下单时间：" + s.data.createTime,
                                        target: "",
                                        img: "INTEGRAL_ORDER" === s.data.orderType ? null === (a = s.data.img) || void 0 === a ? void 0 : a.split(",")[0] : "https://pepsicocampuscrmstgblob.blob.core.chinacloudapi.cn/pepsicocampuscrmstgblob/FAQ_202310121650237130.png",
                                        price: s.data.price,
                                        attr_one: {
                                            color: "#000000",
                                            content: "x".concat(s.data.amount)
                                        },
                                        attr_two: {
                                            color: "#000000",
                                            content: t.getStatus(s.data.orderType, s.data.status)
                                        }
                                    } : void 0, t.goCustomer(getApp().globalData.kfToken, l);

                                  case 14:
                                  case "end":
                                    return e.stop();
                                }
                            }, e);
                        }))();
                    },
                    getStatus: function(t, e) {
                        if ("INTEGRAL_ORDER" !== t) return e;
                        switch (e) {
                          case "CONFIRM":
                            return "已确认";

                          case "WAIT_SHIP":
                            return "待发货";

                          case "WAIT_ROG":
                            return "待收货";

                          case "COMPLETE":
                            return "已完成";
                        }
                    },
                    goCustomer: function(e, a) {
                        var n = this;
                        t.getNetworkType({
                            success: function(o) {
                                var r = t.getSystemInfoSync(), c = t.getAccountInfoSync(), i = {
                                    "设备品牌": r.brand,
                                    "设备型号": r.model,
                                    "操作系统及版本": r.system,
                                    "客户端平台": r.platform,
                                    "客户端基础库版本": r.SDKVersion,
                                    "微信版本号": r.version,
                                    "小程序版本号": c.miniProgram.version,
                                    "网络类型": o.networkType,
                                    "网络代理": o.hasSystemProxy ? "有" : "无",
                                    token: e
                                }, u = n.loginData, s = u.nickname, l = u.memberNo, d = (s ? s + " | " : "") + l, p = "https://ykf-webchat.7moor.com/wapchat.html?accessId=3df83a90-3273-11ee-b07c-ff56bb195602&urlTitle=微信小程序&language=ZHCN&clientId=".concat(l, "&otherParams=").concat(JSON.stringify({
                                    nickName: d,
                                    peerId: "10060889",
                                    productInfo: a
                                }), "&customField=").concat(JSON.stringify(i));
                                t.navigateTo({
                                    url: "/pages/webview/index?url=".concat(encodeURIComponent(p))
                                });
                            }
                        });
                    },
                    goBack: function() {
                        1 === getCurrentPages().length ? t.switchTab({
                            url: "/pages/index/index"
                        }) : t.navigateBack();
                    }
                }
            };
            e.default = c;
        }).call(this, a("543d").default);
    },
    f0ee: function(t, e, a) {
        a.d(e, "b", function() {
            return o;
        }), a.d(e, "c", function() {
            return r;
        }), a.d(e, "a", function() {
            return n;
        });
        var n = {
            uNavbar: function() {
                return a.e("node-modules/uview-ui/components/u-navbar/u-navbar").then(a.bind(null, "b64b"));
            },
            uIcon: function() {
                return a.e("node-modules/uview-ui/components/u-icon/u-icon").then(a.bind(null, "2925"));
            }
        }, o = function() {
            var t = this;
            t.$createElement;
            t._self._c, "augmented" === t.$scope.data.scopedSlotsCompiler && t.$setScopedSlotsParams("default", {
                barH: t.barH
            });
        }, r = [];
    }
} ]), (global.webpackJsonp = global.webpackJsonp || []).push([ "components/lays-page-create-component", {
    "components/lays-page-create-component": function(t, e, a) {
        a("543d").createComponent(a("6310"));
    }
}, [ [ "components/lays-page-create-component" ] ] ]);