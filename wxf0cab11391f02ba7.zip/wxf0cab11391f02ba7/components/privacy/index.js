(global.webpackJsonp = global.webpackJsonp || []).push([ [ "components/privacy/index" ], {
    "4eb0": function(n, e, t) {
        var o = t("a764f");
        t.n(o).a;
    },
    "57c4": function(n, e, t) {
        t.d(e, "b", function() {
            return o;
        }), t.d(e, "c", function() {
            return a;
        }), t.d(e, "a", function() {});
        var o = function() {
            this.$createElement;
            this._self._c;
        }, a = [];
    },
    "5a22": function(n, e, t) {
        t.r(e);
        var o = t("fbaf"), a = t.n(o);
        for (var c in o) [ "default" ].indexOf(c) < 0 && function(n) {
            t.d(e, n, function() {
                return o[n];
            });
        }(c);
        e.default = a.a;
    },
    a764f: function(n, e, t) {},
    d0ee: function(n, e, t) {
        t.r(e);
        var o = t("57c4"), a = t("5a22");
        for (var c in a) [ "default" ].indexOf(c) < 0 && function(n) {
            t.d(e, n, function() {
                return a[n];
            });
        }(c);
        t("4eb0");
        var i = t("f0c5"), r = Object(i.a)(a.default, o.b, o.c, !1, null, "08f29a45", null, !1, o.a, void 0);
        e.default = r.exports;
    },
    fbaf: function(n, e, t) {
        Object.defineProperty(e, "__esModule", {
            value: !0
        }), e.default = void 0;
        var o = t("403a"), a = {
            name: "privacy-modal",
            data: function() {
                return {
                    privacyContractName: "",
                    showPrivacy: !1
                };
            },
            mounted: function() {
                var n = this;
                (0, o.canIUseVersion)("2.32.3") ? wx.getPrivacySetting({
                    success: function(e) {
                        console.log(e), n.privacyContractName = e.privacyContractName, n.showPrivacy = e.needAuthorization, 
                        e.needAuthorization || n.$emit("agree", "auto");
                    }
                }) : this.$emit("agree", "affirm");
            },
            methods: {
                openPrivacyContract: function() {
                    wx.openPrivacyContract({
                        success: function() {}
                    });
                },
                onShowPrivacy: function() {
                    this.showPrivacy = !0;
                },
                onAgree: function() {
                    this.showPrivacy = !1, this.$emit("agree", "affirm");
                },
                onReject: function() {
                    this.showPrivacy = !1, this.$emit("reject");
                }
            }
        };
        e.default = a;
    }
} ]), (global.webpackJsonp = global.webpackJsonp || []).push([ "components/privacy/index-create-component", {
    "components/privacy/index-create-component": function(n, e, t) {
        t("543d").createComponent(t("d0ee"));
    }
}, [ [ "components/privacy/index-create-component" ] ] ]);