(global.webpackJsonp = global.webpackJsonp || []).push([ [ "components/lays-page-main" ], {
    "0b93": function(n, t, e) {},
    "59d9": function(n, t, e) {
        e.r(t);
        var o = e("c7b5"), a = e("cb35");
        for (var c in a) [ "default" ].indexOf(c) < 0 && function(n) {
            e.d(t, n, function() {
                return a[n];
            });
        }(c);
        e("773f");
        var r = e("f0c5"), u = Object(r.a)(a.default, o.b, o.c, !1, null, "47055022", null, !1, o.a, void 0);
        t.default = u.exports;
    },
    "773f": function(n, t, e) {
        var o = e("0b93");
        e.n(o).a;
    },
    c50e: function(n, t, e) {
        Object.defineProperty(t, "__esModule", {
            value: !0
        }), t.default = void 0;
        var o = {
            name: "LaysPageMain",
            props: {
                topH: {
                    type: String,
                    default: "360rpx"
                },
                padding: {
                    type: String,
                    default: "0"
                },
                bottom: {
                    type: String,
                    default: "0"
                },
                bgColor: {
                    type: String,
                    default: "#000856"
                }
            },
            mounted: function() {
                wx.setBackgroundColor({
                    backgroundColorBottom: this.bgColor
                });
            }
        };
        t.default = o;
    },
    c7b5: function(n, t, e) {
        e.d(t, "b", function() {
            return o;
        }), e.d(t, "c", function() {
            return a;
        }), e.d(t, "a", function() {});
        var o = function() {
            this.$createElement;
            this._self._c;
        }, a = [];
    },
    cb35: function(n, t, e) {
        e.r(t);
        var o = e("c50e"), a = e.n(o);
        for (var c in o) [ "default" ].indexOf(c) < 0 && function(n) {
            e.d(t, n, function() {
                return o[n];
            });
        }(c);
        t.default = a.a;
    }
} ]), (global.webpackJsonp = global.webpackJsonp || []).push([ "components/lays-page-main-create-component", {
    "components/lays-page-main-create-component": function(n, t, e) {
        e("543d").createComponent(e("59d9"));
    }
}, [ [ "components/lays-page-main-create-component" ] ] ]);