(global.webpackJsonp = global.webpackJsonp || []).push([ [ "components/poster/article" ], {
    6563: function(e, t, a) {
        var n = a("eb87");
        a.n(n).a;
    },
    7235: function(e, t, a) {
        a.d(t, "b", function() {
            return n;
        }), a.d(t, "c", function() {
            return r;
        }), a.d(t, "a", function() {});
        var n = function() {
            var e = this, t = (e.$createElement, e._self._c, e.styles.includes(3));
            e._isMounted || (e.e0 = function(t) {
                e.currentIndex = t.detail.current;
            }), e.$mp.data = Object.assign({}, {
                $root: {
                    g0: t
                }
            });
        }, r = [];
    },
    "7f50": function(e, t, a) {
        (function(e) {
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = void 0;
            var n = function(e) {
                return e && e.__esModule ? e : {
                    default: e
                };
            }(a("4795")), r = a("e830");
            function s(e, t, a, n, r, s, i) {
                try {
                    var o = e[s](i), c = o.value;
                } catch (e) {
                    return void a(e);
                }
                o.done ? t(c) : Promise.resolve(c).then(n, r);
            }
            function i(e) {
                return function() {
                    var t = this, a = arguments;
                    return new Promise(function(n, r) {
                        var i = e.apply(t, a);
                        function o(e) {
                            s(i, n, r, o, c, "next", e);
                        }
                        function c(e) {
                            s(i, n, r, o, c, "throw", e);
                        }
                        o(void 0);
                    });
                };
            }
            var o = {
                name: "article-poster",
                props: {
                    articleId: {
                        type: Number,
                        required: !0,
                        default: 0
                    },
                    title: {
                        type: String,
                        required: !0,
                        default: ""
                    },
                    content: {
                        type: String,
                        required: !0,
                        default: ""
                    },
                    coverImg: {
                        type: String,
                        required: !0,
                        default: ""
                    }
                },
                data: function() {
                    return {
                        currentIndex: 0,
                        styles: [],
                        bgList: [],
                        urlList: [],
                        codeUrl: "",
                        bg1: "",
                        bg2: "",
                        bg3: "",
                        bg4: "",
                        qrcode: "",
                        avatar: "",
                        canvasWidth: 622,
                        canvasHeight: 952,
                        btnShow: !1,
                        shareLoading: !1,
                        loginData: {}
                    };
                },
                mounted: function() {
                    var t = this;
                    return i(n.default.mark(function a() {
                        var r;
                        return n.default.wrap(function(a) {
                            for (;;) switch (a.prev = a.next) {
                              case 0:
                                return e.showLoading(), r = e.getStorageSync("loginData2"), t.loginData = r ? JSON.parse(r) : {}, 
                                a.next = 5, t.loadPosterData();

                              case 5:
                                return a.next = 7, t.drawCanvas();

                              case 7:
                                t.btnShow = !0, e.hideLoading();

                              case 9:
                              case "end":
                                return a.stop();
                            }
                        }, a);
                    }))();
                },
                methods: {
                    loadPosterData: function() {
                        var t = this;
                        return i(n.default.mark(function a() {
                            var s, i;
                            return n.default.wrap(function(a) {
                                for (;;) switch (a.prev = a.next) {
                                  case 0:
                                    return a.next = 2, (0, r.poster)(Number(t.articleId));

                                  case 2:
                                    s = a.sent, "00000" === (i = s.data).code ? (t.bgList = i.data.backGroundUrlList || [], 
                                    t.codeUrl = i.data.codeUrl, t.styles = t.bgList.map(function(e) {
                                        return e.style;
                                    })) : (e.hideLoading(), e.showToast({
                                        title: i.message,
                                        icon: "none"
                                    }));

                                  case 5:
                                  case "end":
                                    return a.stop();
                                }
                            }, a);
                        }))();
                    },
                    close: function() {
                        this.$emit("close");
                    },
                    save: function() {
                        var t = this;
                        e.getSetting({
                            success: function(a) {
                                a.authSetting["scope.writePhotosAlbum"] ? t.saveImage() : e.authorize({
                                    scope: "scope.writePhotosAlbum",
                                    success: function() {
                                        t.saveImage();
                                    },
                                    fail: function() {
                                        e.showModal({
                                            title: "提示",
                                            content: "请授权相册权限",
                                            confirmColor: "#37eea8",
                                            success: function(a) {
                                                a.confirm && e.openSetting({
                                                    success: function(e) {
                                                        e.authSetting["scope.writePhotosAlbum"] && t.saveImage();
                                                    }
                                                });
                                            }
                                        });
                                    }
                                });
                            }
                        });
                    },
                    saveImage: function() {
                        var t = this;
                        e.saveImageToPhotosAlbum({
                            filePath: t.urlList[t.currentIndex].url,
                            success: function() {
                                t.$emit("share", t.urlList[t.currentIndex].url), e.showToast({
                                    icon: "none",
                                    title: "图片已下载至相册"
                                });
                            }
                        });
                    },
                    drawCanvasOne: function() {
                        var t = this;
                        return i(n.default.mark(function a() {
                            var r, s, o, c, l, u, f, d, h, g, v, p;
                            return n.default.wrap(function(a) {
                                for (;;) switch (a.prev = a.next) {
                                  case 0:
                                    (r = e.createCanvasContext("shareCanvas1", t)).setFillStyle("#37EEA8"), r.fillRect(0, 0, t.canvasWidth, t.canvasHeight), 
                                    r.draw(!0), s = t.bg1, o = s.path, c = s.width, l = s.height, u = s.x, f = s.y, 
                                    r.drawImage(o, u, f, c, l), r.draw(!0), t.avatar && (r.save(), r.beginPath(), r.arc(67, 828, 23, 0, 2 * Math.PI), 
                                    r.fill(), r.clip(), r.drawImage(t.avatar, 44, 805, 46, 46), r.restore(), r.draw(!0), 
                                    r.setFillStyle("black"), r.setFontSize(36), r.setTextAlign("left"), r.fillText(t.loginData.nickname || "", 105, 840), 
                                    r.draw(!0)), r.setFillStyle("black"), r.setFontSize(24), r.setTextAlign("left"), 
                                    r.fillText("扫码进入空间站，搜集心动物资", 43, 890), r.draw(!0), d = t.bgList.find(function(e) {
                                        return 1 === e.style;
                                    }), h = d.codeLeft, g = d.codeTop, v = d.codeWidth, p = d.codeHeight, r.save(), 
                                    r.beginPath(), r.arc(h + v / 2, g + v / 2, v / 2, 0, 2 * Math.PI), r.setFillStyle("#ffffff"), 
                                    r.fill(), r.clip(), r.drawImage(t.qrcode, h, g, v, p), r.restore(), r.draw(!0, i(n.default.mark(function e() {
                                        return n.default.wrap(function(e) {
                                            for (;;) switch (e.prev = e.next) {
                                              case 0:
                                                return e.next = 2, t.saveImageToPhotosAlbum(1);

                                              case 2:
                                              case "end":
                                                return e.stop();
                                            }
                                        }, e);
                                    })));

                                  case 23:
                                  case "end":
                                    return a.stop();
                                }
                            }, a);
                        }))();
                    },
                    drawCanvasTwo: function() {
                        var t = this;
                        return i(n.default.mark(function a() {
                            var r, s, o, c, l, u, f, d, h, g, v, p;
                            return n.default.wrap(function(a) {
                                for (;;) switch (a.prev = a.next) {
                                  case 0:
                                    (r = e.createCanvasContext("shareCanvas2", t)).setFillStyle("#37EEA8"), r.fillRect(0, 0, t.canvasWidth, t.canvasHeight), 
                                    r.draw(!0), s = t.bg2, o = s.path, c = s.width, l = s.height, u = s.x, f = s.y, 
                                    r.drawImage(o, u, f, c, l), r.draw(!0), r.setFillStyle("black"), r.setFontSize(36), 
                                    r.setTextAlign("left"), r.fillText(t._parseText(t.title, 10), 43, 802), r.draw(!0), 
                                    r.setFillStyle("black"), r.setFontSize(24), r.setTextAlign("left"), r.fillText(t._parseText(t.content, 18), 43, 844), 
                                    r.draw(!0), r.setFillStyle("black"), r.setFontSize(24), r.setTextAlign("left"), 
                                    r.fillText("扫码进入空间站，搜集心动物资", 43, 914), r.draw(!0), d = t.bgList.find(function(e) {
                                        return 2 === e.style;
                                    }), h = d.codeLeft, g = d.codeTop, v = d.codeWidth, p = d.codeHeight, r.save(), 
                                    r.beginPath(), r.arc(h + v / 2, g + v / 2, v / 2, 0, 2 * Math.PI), r.setFillStyle("#ffffff"), 
                                    r.fill(), r.clip(), r.drawImage(t.qrcode, h, g, v, p), r.restore(), r.draw(!0, i(n.default.mark(function e() {
                                        return n.default.wrap(function(e) {
                                            for (;;) switch (e.prev = e.next) {
                                              case 0:
                                                return e.next = 2, t.saveImageToPhotosAlbum(2);

                                              case 2:
                                              case "end":
                                                return e.stop();
                                            }
                                        }, e);
                                    })));

                                  case 32:
                                  case "end":
                                    return a.stop();
                                }
                            }, a);
                        }))();
                    },
                    drawCanvasThree: function() {
                        var t = this;
                        return i(n.default.mark(function a() {
                            var r, s, o, c, l, u, f, d, h, g, v, p;
                            return n.default.wrap(function(a) {
                                for (;;) switch (a.prev = a.next) {
                                  case 0:
                                    (r = e.createCanvasContext("shareCanvas3", t)).setFillStyle("#010626"), r.fillRect(0, 0, t.canvasWidth, 74), 
                                    r.draw(!0), r.setFillStyle("#37EEA8"), r.fillRect(0, 74, t.canvasWidth, t.canvasHeight), 
                                    r.draw(!0), r.setFillStyle("black"), r.setFontSize(36), r.setTextAlign("left"), 
                                    r.fillText(t._parseText(t.title, 16), 20, 204), r.draw(!0), s = t.bg3, o = s.path, 
                                    c = s.width, l = s.height, u = s.x, f = s.y, r.drawImage(o, u + 18, f + 178 + 74, c, l), 
                                    r.draw(!0), r.setFillStyle("black"), r.setFontSize(24), r.setTextAlign("left"), 
                                    r.fillText("扫码进入空间站，搜集心动物资", 20, 946), r.draw(!0), d = t.bgList.find(function(e) {
                                        return 3 === e.style;
                                    }), h = d.codeLeft, g = d.codeTop, v = d.codeWidth, p = d.codeHeight, r.save(), 
                                    r.beginPath(), r.arc(h + v / 2, g + v / 2, v / 2, 0, 2 * Math.PI), r.setFillStyle("#ffffff"), 
                                    r.fill(), r.clip(), r.drawImage(t.qrcode, h, g, v, p), r.restore(), r.draw(!0, i(n.default.mark(function e() {
                                        return n.default.wrap(function(e) {
                                            for (;;) switch (e.prev = e.next) {
                                              case 0:
                                                return e.next = 2, t.saveImageToPhotosAlbum(3);

                                              case 2:
                                              case "end":
                                                return e.stop();
                                            }
                                        }, e);
                                    })));

                                  case 30:
                                  case "end":
                                    return a.stop();
                                }
                            }, a);
                        }))();
                    },
                    drawCanvasFour: function() {
                        var t = this;
                        return i(n.default.mark(function a() {
                            var r, s, o, c, l, u, f, d, h, g, v, p;
                            return n.default.wrap(function(a) {
                                for (;;) switch (a.prev = a.next) {
                                  case 0:
                                    (r = e.createCanvasContext("shareCanvas4", t)).setFillStyle("#37EEA8"), r.fillRect(0, 0, t.canvasWidth, t.canvasHeight), 
                                    r.draw(!0), s = t.bg4, o = s.path, c = s.width, l = s.height, u = s.x, f = s.y, 
                                    r.drawImage(o, u, f, c, l), r.draw(!0), r.setFillStyle("black"), r.setFontSize(36), 
                                    r.setTextAlign("left"), r.fillText(t._parseText(t.title, 16), 43, 802), r.draw(!0), 
                                    r.setFillStyle("black"), r.setFontSize(24), r.setTextAlign("left"), r.fillText(t._parseText(t.content, 20), 43, 844), 
                                    r.draw(!0), r.setFillStyle("black"), r.setFontSize(24), r.setTextAlign("left"), 
                                    r.fillText("扫码进入空间站，搜集心动物资", 43, 914), r.draw(!0), d = t.bgList.find(function(e) {
                                        return 4 === e.style;
                                    }), h = d.codeLeft, g = d.codeTop, v = d.codeWidth, p = d.codeHeight, r.save(), 
                                    r.beginPath(), r.arc(h + v / 2, g + v / 2, v / 2, 0, 2 * Math.PI), r.setFillStyle("#ffffff"), 
                                    r.fill(), r.clip(), r.drawImage(t.qrcode, h, g, v, p), r.restore(), r.draw(!0, i(n.default.mark(function e() {
                                        return n.default.wrap(function(e) {
                                            for (;;) switch (e.prev = e.next) {
                                              case 0:
                                                return e.next = 2, t.saveImageToPhotosAlbum(4);

                                              case 2:
                                              case "end":
                                                return e.stop();
                                            }
                                        }, e);
                                    })));

                                  case 32:
                                  case "end":
                                    return a.stop();
                                }
                            }, a);
                        }))();
                    },
                    drawCanvas: function() {
                        var e = this;
                        return i(n.default.mark(function t() {
                            var a, r, s, i, o, c, l, u;
                            return n.default.wrap(function(t) {
                                for (;;) switch (t.prev = t.next) {
                                  case 0:
                                    a = 0, r = e.bgList.length;

                                  case 1:
                                    if (!(a < r)) {
                                        t.next = 16;
                                        break;
                                    }
                                    return s = e.bgList[a], t.next = 5, e.selectImg(s.imgUrl || e.coverImg, "背景图片不存在");

                                  case 5:
                                    if (i = t.sent) {
                                        t.next = 9;
                                        break;
                                    }
                                    return e.close(), t.abrupt("return");

                                  case 9:
                                    o = 3 === s.style ? 582 : e.canvasWidth - 4, c = 3 === s.style ? 634 : 734, e["bg".concat(s.style)] = {
                                        path: i.path,
                                        width: i.width >= o ? o : i.width,
                                        height: i.height >= c ? c : i.height,
                                        x: i.width >= o ? 2 : (o - i.width) / 2,
                                        y: i.height >= c ? 2 : (c - i.height) / 2
                                    }, console.log("bg".concat(s.style, ": "), e["bg".concat(s.style)]);

                                  case 13:
                                    a++, t.next = 1;
                                    break;

                                  case 16:
                                    return t.next = 18, e.selectImg(e.codeUrl, "小程序码图片不存在");

                                  case 18:
                                    if (l = t.sent) {
                                        t.next = 22;
                                        break;
                                    }
                                    return e.close(), t.abrupt("return");

                                  case 22:
                                    if (e.qrcode = l.path, console.log("qrcode: ", e.qrcode), !e.loginData.imageUrl) {
                                        t.next = 30;
                                        break;
                                    }
                                    return t.next = 27, e.selectImg(e.loginData.imageUrl, "头像不存在", !1);

                                  case 27:
                                    u = t.sent, e.avatar = u.path, console.log("avatar: ", e.avatar);

                                  case 30:
                                    if (!e.styles.includes(1)) {
                                        t.next = 33;
                                        break;
                                    }
                                    return t.next = 33, e.drawCanvasOne();

                                  case 33:
                                    if (!e.styles.includes(2)) {
                                        t.next = 36;
                                        break;
                                    }
                                    return t.next = 36, e.drawCanvasTwo();

                                  case 36:
                                    if (!e.styles.includes(3)) {
                                        t.next = 39;
                                        break;
                                    }
                                    return t.next = 39, e.drawCanvasThree();

                                  case 39:
                                    if (!e.styles.includes(4)) {
                                        t.next = 42;
                                        break;
                                    }
                                    return t.next = 42, e.drawCanvasFour();

                                  case 42:
                                  case "end":
                                    return t.stop();
                                }
                            }, t);
                        }))();
                    },
                    selectImg: function(t, a) {
                        var n = !(arguments.length > 2 && void 0 !== arguments[2]) || arguments[2];
                        return new Promise(function(r, s) {
                            e.getImageInfo({
                                src: t,
                                success: function(e) {
                                    r(e);
                                },
                                fail: function(s) {
                                    console.log(s, "getImageInfo", t), r(!1), e.hideLoading(), n && e.showToast({
                                        title: a || "图片资源不存在",
                                        icon: "none"
                                    });
                                }
                            });
                        });
                    },
                    saveImageToPhotosAlbum: function(t) {
                        var a = this;
                        return new Promise(function(n, r) {
                            var s = a, i = a.canvasHeight + (3 === t ? 74 : 0);
                            e.canvasToTempFilePath({
                                x: 0,
                                y: 0,
                                width: s.canvasWidth,
                                height: i,
                                destWidth: s.canvasWidth,
                                destHeight: i,
                                canvasId: "shareCanvas".concat(t),
                                success: function(e) {
                                    s.urlList.push({
                                        style: t,
                                        url: e.tempFilePath
                                    }), console.log("poster".concat(t, ": "), e), n(e.tempFilePath);
                                },
                                fail: function(t) {
                                    console.log(t), e.showToast({
                                        title: "海报生成失败",
                                        icon: "none"
                                    }), e.hideLoading(), r();
                                }
                            }, s);
                        });
                    },
                    shareImage: function() {
                        console.log(this.urlList, this.currentIndex), this.shareLoading = !0;
                        var e = this;
                        wx.showShareImageMenu({
                            path: e.urlList[e.currentIndex].url,
                            success: function(t) {
                                e.shareLoading = !1, e.$emit("share", e.urlList[e.currentIndex].url), console.log("拉起分享", t);
                            },
                            fail: function() {
                                e.shareLoading = !1;
                            }
                        });
                    },
                    _parseText: function(e, t) {
                        var a = null == e ? void 0 : e.replace(/(<([^>]+)>)/gi, "");
                        return a.length > t ? a.slice(0, t) + "..." : a;
                    }
                }
            };
            t.default = o;
        }).call(this, a("543d").default);
    },
    ccbb: function(e, t, a) {
        a.r(t);
        var n = a("7235"), r = a("cfe2");
        for (var s in r) [ "default" ].indexOf(s) < 0 && function(e) {
            a.d(t, e, function() {
                return r[e];
            });
        }(s);
        a("6563");
        var i = a("f0c5"), o = Object(i.a)(r.default, n.b, n.c, !1, null, null, null, !1, n.a, void 0);
        t.default = o.exports;
    },
    cfe2: function(e, t, a) {
        a.r(t);
        var n = a("7f50"), r = a.n(n);
        for (var s in n) [ "default" ].indexOf(s) < 0 && function(e) {
            a.d(t, e, function() {
                return n[e];
            });
        }(s);
        t.default = r.a;
    },
    eb87: function(e, t, a) {}
} ]), (global.webpackJsonp = global.webpackJsonp || []).push([ "components/poster/article-create-component", {
    "components/poster/article-create-component": function(e, t, a) {
        a("543d").createComponent(a("ccbb"));
    }
}, [ [ "components/poster/article-create-component" ] ] ]);