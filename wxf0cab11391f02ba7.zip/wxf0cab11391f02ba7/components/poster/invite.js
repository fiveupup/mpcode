(global.webpackJsonp = global.webpackJsonp || []).push([ [ "components/poster/invite" ], {
    "321c": function(e, t, n) {
        (function(e) {
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = void 0;
            var a = function(e) {
                return e && e.__esModule ? e : {
                    default: e
                };
            }(n("4795")), r = n("7b12");
            function s(e, t, n, a, r, s, o) {
                try {
                    var c = e[s](o), i = c.value;
                } catch (e) {
                    return void n(e);
                }
                c.done ? t(i) : Promise.resolve(i).then(a, r);
            }
            function o(e) {
                return function() {
                    var t = this, n = arguments;
                    return new Promise(function(a, r) {
                        var o = e.apply(t, n);
                        function c(e) {
                            s(o, a, r, c, i, "next", e);
                        }
                        function i(e) {
                            s(o, a, r, c, i, "throw", e);
                        }
                        c(void 0);
                    });
                };
            }
            var c = {
                name: "invite-poster",
                data: function() {
                    return {
                        currentIndex: 0,
                        styles: [],
                        bgList: [],
                        urlList: [],
                        codeUrl: "",
                        bg1: "",
                        bg2: "",
                        bg3: "",
                        bg4: "",
                        qrcode: "",
                        canvasWidth: 622,
                        canvasHeight: 952,
                        btnShow: !1,
                        shareLoading: !1
                    };
                },
                mounted: function() {
                    var t = this;
                    return o(a.default.mark(function n() {
                        return a.default.wrap(function(n) {
                            for (;;) switch (n.prev = n.next) {
                              case 0:
                                return e.showLoading(), n.next = 3, t.loadPosterData();

                              case 3:
                                return n.next = 5, t.drawCanvas();

                              case 5:
                                t.btnShow = !0, e.hideLoading();

                              case 7:
                              case "end":
                                return n.stop();
                            }
                        }, n);
                    }))();
                },
                methods: {
                    loadPosterData: function() {
                        var t = this;
                        return o(a.default.mark(function n() {
                            var s, o;
                            return a.default.wrap(function(n) {
                                for (;;) switch (n.prev = n.next) {
                                  case 0:
                                    return n.next = 2, (0, r.posterInvite)();

                                  case 2:
                                    if (s = n.sent, "00000" !== (o = s.data).code) {
                                        n.next = 12;
                                        break;
                                    }
                                    if (t.bgList = o.data.backGroundUrlList.length ? o.data.backGroundUrlList.filter(function(e) {
                                        return !!e.imgUrl;
                                    }) : [], 0 !== t.bgList.length) {
                                        n.next = 8;
                                        break;
                                    }
                                    return n.abrupt("return");

                                  case 8:
                                    t.codeUrl = o.data.codeUrl, t.styles = t.bgList.map(function(e) {
                                        return e.style;
                                    }), n.next = 14;
                                    break;

                                  case 12:
                                    e.hideLoading(), e.showToast({
                                        title: o.message,
                                        icon: "none"
                                    });

                                  case 14:
                                  case "end":
                                    return n.stop();
                                }
                            }, n);
                        }))();
                    },
                    close: function() {
                        this.$emit("close");
                    },
                    save: function() {
                        var t = this;
                        e.getSetting({
                            success: function(n) {
                                n.authSetting["scope.writePhotosAlbum"] ? t.saveImage() : e.authorize({
                                    scope: "scope.writePhotosAlbum",
                                    success: function() {
                                        t.saveImage();
                                    },
                                    fail: function() {
                                        e.showModal({
                                            title: "提示",
                                            content: "请授权相册权限",
                                            confirmColor: "#37eea8",
                                            success: function(n) {
                                                n.confirm && e.openSetting({
                                                    success: function(e) {
                                                        e.authSetting["scope.writePhotosAlbum"] && t.saveImage();
                                                    }
                                                });
                                            }
                                        });
                                    }
                                });
                            }
                        });
                    },
                    saveImage: function() {
                        var t = this;
                        e.saveImageToPhotosAlbum({
                            filePath: t.urlList[t.currentIndex].url,
                            success: function() {
                                t.$emit("share", t.urlList[t.currentIndex].url), e.showToast({
                                    icon: "none",
                                    title: "图片已下载至相册"
                                });
                            }
                        });
                    },
                    drawCanvasItem: function(t) {
                        var n = this;
                        return o(a.default.mark(function r() {
                            var s;
                            return a.default.wrap(function(r) {
                                for (;;) switch (r.prev = r.next) {
                                  case 0:
                                    (s = e.createCanvasContext("shareCanvas".concat(t.style), n)).setFillStyle("#37EEA8"), 
                                    s.fillRect(0, 0, t.width, t.height), s.draw(!0), s.drawImage(t.path, 2, 2, t.width - 4, t.height - 4), 
                                    s.draw(!0), s.drawImage(n.qrcode, t.codeLeft, t.codeTop, t.codeWidth, t.codeHeight), 
                                    s.draw(!0, o(a.default.mark(function e() {
                                        return a.default.wrap(function(e) {
                                            for (;;) switch (e.prev = e.next) {
                                              case 0:
                                                return e.next = 2, n.saveImageToPhotosAlbum(t);

                                              case 2:
                                              case "end":
                                                return e.stop();
                                            }
                                        }, e);
                                    })));

                                  case 8:
                                  case "end":
                                    return r.stop();
                                }
                            }, r);
                        }))();
                    },
                    drawCanvasOne: function() {
                        var t = this;
                        return o(a.default.mark(function n() {
                            var r;
                            return a.default.wrap(function(n) {
                                for (;;) switch (n.prev = n.next) {
                                  case 0:
                                    (r = e.createCanvasContext("shareCanvas1", t)).setFillStyle("#37EEA8"), r.fillRect(0, 0, t.canvasWidth, t.canvasHeight), 
                                    r.draw(!0), r.drawImage(t.bg1, 2, 2, t.canvasWidth - 4, t.canvasHeight - 4), r.draw(!0), 
                                    r.save(), r.beginPath(), r.arc(509, 847, 74, 0, 2 * Math.PI), r.setFillStyle("#ffffff"), 
                                    r.fill(), r.clip(), r.drawImage(t.qrcode, 437, 775, 144, 144), r.restore(), r.draw(!0, o(a.default.mark(function e() {
                                        return a.default.wrap(function(e) {
                                            for (;;) switch (e.prev = e.next) {
                                              case 0:
                                                return e.next = 2, t.saveImageToPhotosAlbum(1);

                                              case 2:
                                              case "end":
                                                return e.stop();
                                            }
                                        }, e);
                                    })));

                                  case 15:
                                  case "end":
                                    return n.stop();
                                }
                            }, n);
                        }))();
                    },
                    drawCanvasTwo: function() {
                        var t = this;
                        return o(a.default.mark(function n() {
                            var r;
                            return a.default.wrap(function(n) {
                                for (;;) switch (n.prev = n.next) {
                                  case 0:
                                    (r = e.createCanvasContext("shareCanvas2", t)).setFillStyle("#37EEA8"), r.fillRect(0, 0, t.canvasWidth, t.canvasHeight), 
                                    r.draw(!0), r.drawImage(t.bg2, 2, 2, t.canvasWidth - 4, t.canvasHeight - 4), r.draw(!0), 
                                    r.save(), r.beginPath(), r.arc(311, 847, 74, 0, 2 * Math.PI), r.setFillStyle("#ffffff"), 
                                    r.fill(), r.clip(), r.drawImage(t.qrcode, 239, 775, 144, 144), r.restore(), r.draw(!0, o(a.default.mark(function e() {
                                        return a.default.wrap(function(e) {
                                            for (;;) switch (e.prev = e.next) {
                                              case 0:
                                                return e.next = 2, t.saveImageToPhotosAlbum(2);

                                              case 2:
                                              case "end":
                                                return e.stop();
                                            }
                                        }, e);
                                    })));

                                  case 15:
                                  case "end":
                                    return n.stop();
                                }
                            }, n);
                        }))();
                    },
                    drawCanvasThree: function() {
                        var t = this;
                        return o(a.default.mark(function n() {
                            var r, s;
                            return a.default.wrap(function(n) {
                                for (;;) switch (n.prev = n.next) {
                                  case 0:
                                    (r = e.createCanvasContext("shareCanvas3", t)).setFillStyle("#37EEA8"), r.fillRect(0, 0, t.canvasWidth, t.canvasHeight), 
                                    r.draw(!0), r.drawImage(t.bg3, 2, 2, t.canvasWidth - 4, t.canvasHeight - 4), r.draw(!0), 
                                    r.moveTo(2, 759), r.lineTo(t.canvasWidth / 2, 808), r.lineTo(620, 750), r.lineTo(t.canvasWidth - 2, t.canvasHeight - 2), 
                                    r.lineTo(2, t.canvasHeight - 2), r.lineTo(2, 759), r.setFillStyle("#FFFFFF"), r.fill(), 
                                    r.draw(!0), s = t.bgList.find(function(e) {
                                        return 3 === e.style;
                                    }), r.drawImage(t.qrcode, s.codeLeft, s.codeTop, s.codeWidth, s.codeHeight), r.draw(!0, o(a.default.mark(function e() {
                                        return a.default.wrap(function(e) {
                                            for (;;) switch (e.prev = e.next) {
                                              case 0:
                                                return e.next = 2, t.saveImageToPhotosAlbum(s);

                                              case 2:
                                              case "end":
                                                return e.stop();
                                            }
                                        }, e);
                                    })));

                                  case 18:
                                  case "end":
                                    return n.stop();
                                }
                            }, n);
                        }))();
                    },
                    drawCanvasFour: function() {
                        var t = this;
                        return o(a.default.mark(function n() {
                            var r, s;
                            return a.default.wrap(function(n) {
                                for (;;) switch (n.prev = n.next) {
                                  case 0:
                                    (r = e.createCanvasContext("shareCanvas4", t)).setFillStyle("#010626"), r.fillRect(0, 0, t.canvasWidth, 74), 
                                    r.draw(!0), r.setFillStyle("#37EEA8"), r.fillRect(0, 74, t.canvasWidth, t.canvasHeight), 
                                    r.draw(!0), r.drawImage(t.bg4, 2, 76, t.canvasWidth - 4, t.canvasHeight - 4), r.draw(!0), 
                                    s = t.bgList.find(function(e) {
                                        return 4 === e.style;
                                    }), r.drawImage(t.qrcode, s.codeLeft, s.codeTop, s.codeWidth, s.codeHeight), r.draw(!0, o(a.default.mark(function e() {
                                        return a.default.wrap(function(e) {
                                            for (;;) switch (e.prev = e.next) {
                                              case 0:
                                                return e.next = 2, t.saveImageToPhotosAlbum(s);

                                              case 2:
                                              case "end":
                                                return e.stop();
                                            }
                                        }, e);
                                    })));

                                  case 12:
                                  case "end":
                                    return n.stop();
                                }
                            }, n);
                        }))();
                    },
                    drawCanvas: function() {
                        var e = this;
                        return o(a.default.mark(function t() {
                            var n, r, s, o, c, i, u;
                            return a.default.wrap(function(t) {
                                for (;;) switch (t.prev = t.next) {
                                  case 0:
                                    n = 0, r = e.bgList.length;

                                  case 1:
                                    if (!(n < r)) {
                                        t.next = 15;
                                        break;
                                    }
                                    return s = e.bgList[n], t.next = 5, e.selectImg(s.imgUrl, "背景图片不存在");

                                  case 5:
                                    if (o = t.sent) {
                                        t.next = 9;
                                        break;
                                    }
                                    return e.close(), t.abrupt("return");

                                  case 9:
                                    e["bg".concat(s.style)] = o.path, e.bgList[n].path = o.path, console.log("bg".concat(s.style, ": "), e["bg".concat(s.style)]);

                                  case 12:
                                    n++, t.next = 1;
                                    break;

                                  case 15:
                                    return t.next = 17, e.selectImg(e.codeUrl, "小程序码图片不存在");

                                  case 17:
                                    if (c = t.sent) {
                                        t.next = 21;
                                        break;
                                    }
                                    return e.close(), t.abrupt("return");

                                  case 21:
                                    if (e.qrcode = c.path, console.log("qrcode: ", e.qrcode), !e.styles.includes(1)) {
                                        t.next = 27;
                                        break;
                                    }
                                    return i = e.bgList.find(function(e) {
                                        return 1 === e.style;
                                    }), t.next = 27, e.drawCanvasItem(i);

                                  case 27:
                                    if (!e.styles.includes(2)) {
                                        t.next = 31;
                                        break;
                                    }
                                    return u = e.bgList.find(function(e) {
                                        return 2 === e.style;
                                    }), t.next = 31, e.drawCanvasItem(u);

                                  case 31:
                                    if (!e.styles.includes(3)) {
                                        t.next = 34;
                                        break;
                                    }
                                    return t.next = 34, e.drawCanvasThree();

                                  case 34:
                                    if (!e.styles.includes(4)) {
                                        t.next = 37;
                                        break;
                                    }
                                    return t.next = 37, e.drawCanvasFour();

                                  case 37:
                                  case "end":
                                    return t.stop();
                                }
                            }, t);
                        }))();
                    },
                    selectImg: function(t, n) {
                        return new Promise(function(a, r) {
                            e.getImageInfo({
                                src: t,
                                success: function(e) {
                                    a(e);
                                },
                                fail: function(r) {
                                    console.log(r, "getImageInfo", t), a(!1), e.hideLoading(), e.showToast({
                                        title: n || "图片资源不存在",
                                        icon: "none"
                                    });
                                }
                            });
                        });
                    },
                    saveImageToPhotosAlbum: function(t) {
                        var n = this;
                        return new Promise(function(a, r) {
                            var s = n, o = t.height + (4 === t.style ? 74 : 0);
                            e.canvasToTempFilePath({
                                x: 0,
                                y: 0,
                                width: t.width,
                                height: o,
                                destWidth: t.width,
                                destHeight: o,
                                canvasId: "shareCanvas".concat(t.style),
                                success: function(e) {
                                    s.urlList.push({
                                        style: t.style,
                                        url: e.tempFilePath
                                    }), console.log("poster".concat(t.style, ": "), e), a(e.tempFilePath);
                                },
                                fail: function(t) {
                                    console.log(t), e.showToast({
                                        title: "海报生成失败",
                                        icon: "none"
                                    }), e.hideLoading(), r();
                                }
                            }, s);
                        });
                    },
                    shareImage: function() {
                        console.log(this.urlList, this.currentIndex), this.shareLoading = !0;
                        var e = this;
                        wx.showShareImageMenu({
                            path: e.urlList[e.currentIndex].url,
                            success: function(t) {
                                e.shareLoading = !1, e.$emit("share", e.urlList[e.currentIndex].url), console.log("拉起分享", t);
                            },
                            fail: function() {
                                e.shareLoading = !1;
                            }
                        });
                    }
                }
            };
            t.default = c;
        }).call(this, n("543d").default);
    },
    "4e80": function(e, t, n) {
        n.r(t);
        var a = n("a1a2"), r = n("50b0");
        for (var s in r) [ "default" ].indexOf(s) < 0 && function(e) {
            n.d(t, e, function() {
                return r[e];
            });
        }(s);
        n("9391");
        var o = n("f0c5"), c = Object(o.a)(r.default, a.b, a.c, !1, null, null, null, !1, a.a, void 0);
        t.default = c.exports;
    },
    "50b0": function(e, t, n) {
        n.r(t);
        var a = n("321c"), r = n.n(a);
        for (var s in a) [ "default" ].indexOf(s) < 0 && function(e) {
            n.d(t, e, function() {
                return a[e];
            });
        }(s);
        t.default = r.a;
    },
    9391: function(e, t, n) {
        var a = n("9394");
        n.n(a).a;
    },
    9394: function(e, t, n) {},
    a1a2: function(e, t, n) {
        n.d(t, "b", function() {
            return a;
        }), n.d(t, "c", function() {
            return r;
        }), n.d(t, "a", function() {});
        var a = function() {
            var e = this, t = (e.$createElement, e._self._c, e.styles.includes(4));
            e._isMounted || (e.e0 = function(t) {
                e.currentIndex = t.detail.current;
            }), e.$mp.data = Object.assign({}, {
                $root: {
                    g0: t
                }
            });
        }, r = [];
    }
} ]), (global.webpackJsonp = global.webpackJsonp || []).push([ "components/poster/invite-create-component", {
    "components/poster/invite-create-component": function(e, t, n) {
        n("543d").createComponent(n("4e80"));
    }
}, [ [ "components/poster/invite-create-component" ] ] ]);