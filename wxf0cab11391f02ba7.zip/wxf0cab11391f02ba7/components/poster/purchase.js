(global.webpackJsonp = global.webpackJsonp || []).push([ [ "components/poster/purchase" ], {
    1174: function(e, t, n) {
        n.r(t);
        var a = n("64e8"), r = n.n(a);
        for (var o in a) [ "default" ].indexOf(o) < 0 && function(e) {
            n.d(t, e, function() {
                return a[e];
            });
        }(o);
        t.default = r.a;
    },
    "2f14": function(e, t, n) {
        n.d(t, "b", function() {
            return a;
        }), n.d(t, "c", function() {
            return r;
        }), n.d(t, "a", function() {});
        var a = function() {
            var e = this;
            e.$createElement;
            e._self._c, e._isMounted || (e.e0 = function(t) {
                e.currentIndex = t.detail.current;
            });
        }, r = [];
    },
    "4f61": function(e, t, n) {
        n.r(t);
        var a = n("2f14"), r = n("1174");
        for (var o in r) [ "default" ].indexOf(o) < 0 && function(e) {
            n.d(t, e, function() {
                return r[e];
            });
        }(o);
        n("71c5");
        var s = n("f0c5"), c = Object(s.a)(r.default, a.b, a.c, !1, null, null, null, !1, a.a, void 0);
        t.default = c.exports;
    },
    "64e8": function(e, t, n) {
        (function(e) {
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = void 0;
            var a = function(e) {
                return e && e.__esModule ? e : {
                    default: e
                };
            }(n("4795")), r = n("6d6a");
            function o(e, t, n, a, r, o, s) {
                try {
                    var c = e[o](s), i = c.value;
                } catch (e) {
                    return void n(e);
                }
                c.done ? t(i) : Promise.resolve(i).then(a, r);
            }
            function s(e) {
                return function() {
                    var t = this, n = arguments;
                    return new Promise(function(a, r) {
                        var s = e.apply(t, n);
                        function c(e) {
                            o(s, a, r, c, i, "next", e);
                        }
                        function i(e) {
                            o(s, a, r, c, i, "throw", e);
                        }
                        c(void 0);
                    });
                };
            }
            var c = {
                name: "purchase-poster",
                data: function() {
                    return {
                        currentIndex: 0,
                        maxHeight: "1024rpx",
                        bgList: [],
                        urlList: [],
                        canvasWidth: 620,
                        canvasHeight: 1024,
                        btnShow: !1,
                        shareLoading: !1
                    };
                },
                mounted: function() {
                    var t = this;
                    return s(a.default.mark(function n() {
                        return a.default.wrap(function(n) {
                            for (;;) switch (n.prev = n.next) {
                              case 0:
                                return e.showLoading(), n.next = 3, t.loadPosterData();

                              case 3:
                                return n.next = 5, t.drawCanvas();

                              case 5:
                                t.btnShow = !0, e.hideLoading();

                              case 7:
                              case "end":
                                return n.stop();
                            }
                        }, n);
                    }))();
                },
                methods: {
                    loadPosterData: function() {
                        var t = this;
                        return s(a.default.mark(function n() {
                            var o, s, c;
                            return a.default.wrap(function(n) {
                                for (;;) switch (n.prev = n.next) {
                                  case 0:
                                    return n.next = 2, (0, r.poster)();

                                  case 2:
                                    o = n.sent, "00000" === (s = o.data).code ? t.bgList = (null === (c = s.data) || void 0 === c ? void 0 : c.filter(function(e) {
                                        return !!e.imgUrl;
                                    })) || [] : (e.hideLoading(), e.showToast({
                                        title: s.message,
                                        icon: "none"
                                    }));

                                  case 5:
                                  case "end":
                                    return n.stop();
                                }
                            }, n);
                        }))();
                    },
                    close: function() {
                        this.$emit("close");
                    },
                    save: function() {
                        var t = this;
                        e.getSetting({
                            success: function(n) {
                                n.authSetting["scope.writePhotosAlbum"] ? t.saveImage() : e.authorize({
                                    scope: "scope.writePhotosAlbum",
                                    success: function() {
                                        t.saveImage();
                                    },
                                    fail: function() {
                                        e.showModal({
                                            title: "提示",
                                            content: "请授权相册权限",
                                            confirmColor: "#37eea8",
                                            success: function(n) {
                                                n.confirm && e.openSetting({
                                                    success: function(e) {
                                                        e.authSetting["scope.writePhotosAlbum"] && t.saveImage();
                                                    }
                                                });
                                            }
                                        });
                                    }
                                });
                            }
                        });
                    },
                    saveImage: function() {
                        var t = this;
                        e.saveImageToPhotosAlbum({
                            filePath: t.urlList[t.currentIndex].url,
                            success: function() {
                                t.$emit("share", t.urlList[t.currentIndex].url), e.showToast({
                                    icon: "none",
                                    title: "图片已下载至相册"
                                }), (0, r.downloadTag)(t.urlList[t.currentIndex].shareId);
                            }
                        });
                    },
                    drawCanvasItem: function(t) {
                        var n = this;
                        return s(a.default.mark(function r() {
                            var o;
                            return a.default.wrap(function(r) {
                                for (;;) switch (r.prev = r.next) {
                                  case 0:
                                    (o = e.createCanvasContext("shareCanvas".concat(t.style), n)).drawImage(t.path, 0, 0, t.width, t.height), 
                                    o.draw(!0), o.drawImage(t.qrcode, t.codeLeft, t.codeTop, t.codeWidth, t.codeHeight), 
                                    o.draw(!0, s(a.default.mark(function e() {
                                        return a.default.wrap(function(e) {
                                            for (;;) switch (e.prev = e.next) {
                                              case 0:
                                                return e.next = 2, n.saveImageToPhotosAlbum(t);

                                              case 2:
                                              case "end":
                                                return e.stop();
                                            }
                                        }, e);
                                    })));

                                  case 5:
                                  case "end":
                                    return r.stop();
                                }
                            }, r);
                        }))();
                    },
                    drawCanvas: function() {
                        var e = this;
                        return s(a.default.mark(function t() {
                            var n, r, o, s, c, i, u, l, f, d;
                            return a.default.wrap(function(t) {
                                for (;;) switch (t.prev = t.next) {
                                  case 0:
                                    n = 0, r = 0, o = e.bgList.length;

                                  case 2:
                                    if (!(r < o)) {
                                        t.next = 25;
                                        break;
                                    }
                                    return s = e.bgList[r], c = s.width, i = s.height, u = i / c * 622, n = Math.max(n, u), 
                                    l = e.bgList[r], t.next = 9, e.selectImg(l.imgUrl, "背景图片不存在");

                                  case 9:
                                    if (f = t.sent) {
                                        t.next = 13;
                                        break;
                                    }
                                    return e.close(), t.abrupt("return");

                                  case 13:
                                    return e.bgList[r].path = f.path, t.next = 16, e.selectImg(l.shareLink, "小程序码图片不存在");

                                  case 16:
                                    if (d = t.sent) {
                                        t.next = 20;
                                        break;
                                    }
                                    return e.close(), t.abrupt("return");

                                  case 20:
                                    e.bgList[r].qrcode = d.path, console.log("bg".concat(l.style, ": "), e.bgList[r]);

                                  case 22:
                                    r++, t.next = 2;
                                    break;

                                  case 25:
                                    e.maxHeight = "calc(10vh + ".concat(n, "rpx + 78rpx)"), e.bgList.forEach(function(t) {
                                        e.drawCanvasItem(t);
                                    });

                                  case 27:
                                  case "end":
                                    return t.stop();
                                }
                            }, t);
                        }))();
                    },
                    selectImg: function(t, n) {
                        return new Promise(function(a, r) {
                            e.getImageInfo({
                                src: t,
                                success: function(e) {
                                    a(e);
                                },
                                fail: function(r) {
                                    console.log(r, "getImageInfo", t), a(!1), e.hideLoading(), e.showToast({
                                        title: n || "图片资源不存在",
                                        icon: "none"
                                    });
                                }
                            });
                        });
                    },
                    saveImageToPhotosAlbum: function(t) {
                        var n = this;
                        return new Promise(function(a, r) {
                            var o = n;
                            e.canvasToTempFilePath({
                                x: 0,
                                y: 0,
                                width: t.width,
                                height: t.height,
                                destWidth: t.width,
                                destHeight: t.height,
                                canvasId: "shareCanvas".concat(t.style),
                                success: function(e) {
                                    o.urlList.push({
                                        style: t.style,
                                        url: e.tempFilePath,
                                        shareId: t.shareId
                                    }), console.log("poster".concat(t.style, ": "), e), a(e.tempFilePath);
                                },
                                fail: function(t) {
                                    console.log(t), e.showToast({
                                        title: "海报生成失败",
                                        icon: "none"
                                    }), e.hideLoading(), r();
                                }
                            }, o);
                        });
                    },
                    shareImage: function() {
                        console.log(this.urlList, this.currentIndex), this.shareLoading = !0;
                        var e = this;
                        wx.showShareImageMenu({
                            path: e.urlList[e.currentIndex].url,
                            success: function(t) {
                                e.shareLoading = !1, e.$emit("share", e.urlList[e.currentIndex].url), console.log("拉起分享", t), 
                                (0, r.downloadTag)(e.urlList[e.currentIndex].shareId);
                            },
                            fail: function() {
                                e.shareLoading = !1;
                            }
                        });
                    }
                }
            };
            t.default = c;
        }).call(this, n("543d").default);
    },
    "71c5": function(e, t, n) {
        var a = n("980a");
        n.n(a).a;
    },
    "980a": function(e, t, n) {}
} ]), (global.webpackJsonp = global.webpackJsonp || []).push([ "components/poster/purchase-create-component", {
    "components/poster/purchase-create-component": function(e, t, n) {
        n("543d").createComponent(n("4f61"));
    }
}, [ [ "components/poster/purchase-create-component" ] ] ]);