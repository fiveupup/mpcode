(global.webpackJsonp = global.webpackJsonp || []).push([ [ "components/poster/medal" ], {
    "100c": function(e, t, a) {},
    "1a94": function(e, t, a) {
        a.r(t);
        var n = a("f623"), r = a.n(n);
        for (var i in n) [ "default" ].indexOf(i) < 0 && function(e) {
            a.d(t, e, function() {
                return n[e];
            });
        }(i);
        t.default = r.a;
    },
    "3c65": function(e, t, a) {
        a.d(t, "b", function() {
            return n;
        }), a.d(t, "c", function() {
            return r;
        }), a.d(t, "a", function() {});
        var n = function() {
            var e = this, t = (e.$createElement, e._self._c, e.styles.includes(4));
            e._isMounted || (e.e0 = function(t) {
                e.currentIndex = t.detail.current;
            }), e.$mp.data = Object.assign({}, {
                $root: {
                    g0: t
                }
            });
        }, r = [];
    },
    "465a": function(e, t, a) {
        var n = a("100c");
        a.n(n).a;
    },
    "85ce": function(e, t, a) {
        a.r(t);
        var n = a("3c65"), r = a("1a94");
        for (var i in r) [ "default" ].indexOf(i) < 0 && function(e) {
            a.d(t, e, function() {
                return r[e];
            });
        }(i);
        a("465a");
        var s = a("f0c5"), o = Object(s.a)(r.default, n.b, n.c, !1, null, null, null, !1, n.a, void 0);
        t.default = o.exports;
    },
    f623: function(e, t, a) {
        (function(e) {
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = void 0;
            var n = function(e) {
                return e && e.__esModule ? e : {
                    default: e
                };
            }(a("4795")), r = a("30a7");
            function i(e, t, a, n, r, i, s) {
                try {
                    var o = e[i](s), l = o.value;
                } catch (e) {
                    return void a(e);
                }
                o.done ? t(l) : Promise.resolve(l).then(n, r);
            }
            function s(e) {
                return function() {
                    var t = this, a = arguments;
                    return new Promise(function(n, r) {
                        var s = e.apply(t, a);
                        function o(e) {
                            i(s, n, r, o, l, "next", e);
                        }
                        function l(e) {
                            i(s, n, r, o, l, "throw", e);
                        }
                        o(void 0);
                    });
                };
            }
            var o = {
                name: "medal-poster",
                props: {
                    medalId: {
                        type: Number,
                        required: !0,
                        default: 0
                    },
                    name: {
                        type: String,
                        required: !0,
                        default: ""
                    },
                    bg: {
                        type: String,
                        require: !0,
                        default: ""
                    },
                    remark: {
                        type: String,
                        default: ""
                    }
                },
                data: function() {
                    return {
                        currentIndex: 0,
                        styles: [],
                        bgList: [],
                        urlList: [],
                        logoUrl: "https://pepsicocampuscrmstgblob.blob.core.chinacloudapi.cn/pepsicocampuscrmstgblob/FAQ_202305121004372358.png",
                        codeUrl: "",
                        bgInfo: {
                            path: "",
                            x: 0,
                            y: 0,
                            width: 0,
                            height: 0
                        },
                        logo: "",
                        qrcode: "",
                        avatar: "",
                        canvasWidth: 622,
                        canvasHeight: 952,
                        btnShow: !1,
                        shareLoading: !1,
                        loginData: {}
                    };
                },
                mounted: function() {
                    var t = this;
                    return s(n.default.mark(function a() {
                        var r;
                        return n.default.wrap(function(a) {
                            for (;;) switch (a.prev = a.next) {
                              case 0:
                                return e.showLoading(), r = e.getStorageSync("loginData2"), t.loginData = r ? JSON.parse(r) : {}, 
                                a.next = 5, t.loadPosterData();

                              case 5:
                                return a.next = 7, t.drawCanvas();

                              case 7:
                                t.btnShow = !0, e.hideLoading();

                              case 9:
                              case "end":
                                return a.stop();
                            }
                        }, a);
                    }))();
                },
                methods: {
                    loadPosterData: function() {
                        var t = this;
                        return s(n.default.mark(function a() {
                            var i, s;
                            return n.default.wrap(function(a) {
                                for (;;) switch (a.prev = a.next) {
                                  case 0:
                                    return a.next = 2, (0, r.poster)(Number(t.medalId));

                                  case 2:
                                    if (i = a.sent, "00000" !== (s = i.data).code) {
                                        a.next = 12;
                                        break;
                                    }
                                    if (t.bgList = s.data.backGroundUrlList.length ? s.data.backGroundUrlList.filter(function(e) {
                                        return !!e.imgUrl;
                                    }) : [], 0 !== t.bgList.length) {
                                        a.next = 8;
                                        break;
                                    }
                                    return a.abrupt("return");

                                  case 8:
                                    t.codeUrl = s.data.codeUrl, t.styles = t.bgList.map(function(e) {
                                        return e.style;
                                    }), a.next = 14;
                                    break;

                                  case 12:
                                    e.hideLoading(), e.showToast({
                                        title: s.message,
                                        icon: "none"
                                    });

                                  case 14:
                                  case "end":
                                    return a.stop();
                                }
                            }, a);
                        }))();
                    },
                    close: function() {
                        this.$emit("close");
                    },
                    save: function() {
                        var t = this;
                        e.getSetting({
                            success: function(a) {
                                a.authSetting["scope.writePhotosAlbum"] ? t.saveImage() : e.authorize({
                                    scope: "scope.writePhotosAlbum",
                                    success: function() {
                                        t.saveImage();
                                    },
                                    fail: function() {
                                        e.showModal({
                                            title: "提示",
                                            content: "请授权相册权限",
                                            confirmColor: "#37eea8",
                                            success: function(a) {
                                                a.confirm && e.openSetting({
                                                    success: function(e) {
                                                        e.authSetting["scope.writePhotosAlbum"] && t.saveImage();
                                                    }
                                                });
                                            }
                                        });
                                    }
                                });
                            }
                        });
                    },
                    saveImage: function() {
                        var t = this;
                        e.saveImageToPhotosAlbum({
                            filePath: t.urlList[t.currentIndex].url,
                            success: function() {
                                t.$emit("share", t.urlList[t.currentIndex].url), e.showToast({
                                    icon: "none",
                                    title: "图片已下载至相册"
                                }), (0, r.shareTag)(t.medalId, "SAVE");
                            }
                        });
                    },
                    drawCanvasOne: function() {
                        var t = this;
                        return s(n.default.mark(function a() {
                            var r, i, o, l, c, u, d, f, h, g, w, v;
                            return n.default.wrap(function(a) {
                                for (;;) switch (a.prev = a.next) {
                                  case 0:
                                    (r = e.createCanvasContext("shareCanvas1", t)).setFillStyle("#37EEA8"), r.fillRect(0, 0, t.canvasWidth, t.canvasHeight), 
                                    r.draw(!0), r.setFillStyle("#010626"), r.fillRect(2, 2, 618, 752), r.draw(!0), i = t.bgInfo, 
                                    o = i.path, l = i.width, c = i.height, u = i.x, d = i.y, r.drawImage(o, u, d, l, c), 
                                    r.draw(!0), r.drawImage(t.logo, 214, 82, 195, 35), r.draw(!0), r.setFillStyle("white"), 
                                    r.setFontSize(32), r.setTextAlign("center"), r.fillText(t.name, t.canvasWidth / 2, 580), 
                                    r.draw(!0), t.remark && (r.setFillStyle("white"), r.setFontSize(28), r.setTextAlign("center"), 
                                    t.fillTextLineBreak(r, t.remark, 311, 640, 522, 32), r.draw(!0)), t.avatar && (r.save(), 
                                    r.beginPath(), r.arc(67, 828, 23, 0, 2 * Math.PI), r.fill(), r.clip(), r.drawImage(t.avatar, 44, 805, 46, 46), 
                                    r.restore(), r.draw(!0), r.setFillStyle("black"), r.setFontSize(36), r.setTextAlign("left"), 
                                    r.fillText(t.loginData.nickname || "", 105, 840), r.draw(!0)), r.setFillStyle("black"), 
                                    r.setFontSize(24), r.setTextAlign("left"), r.fillText("扫码进入空间站，搜集心动物资", 43, 890), 
                                    r.draw(!0), f = t.bgList.find(function(e) {
                                        return 1 === e.style;
                                    }), h = f.codeLeft, g = f.codeTop, w = f.codeWidth, v = f.codeHeight, r.save(), 
                                    r.beginPath(), r.arc(h + w / 2, g + w / 2, w / 2, 0, 2 * Math.PI), r.setFillStyle("#ffffff"), 
                                    r.fill(), r.clip(), r.drawImage(t.qrcode, h, g, w, v), r.restore(), r.draw(!0, s(n.default.mark(function e() {
                                        return n.default.wrap(function(e) {
                                            for (;;) switch (e.prev = e.next) {
                                              case 0:
                                                return e.next = 2, t.saveImageToPhotosAlbum(1);

                                              case 2:
                                              case "end":
                                                return e.stop();
                                            }
                                        }, e);
                                    })));

                                  case 34:
                                  case "end":
                                    return a.stop();
                                }
                            }, a);
                        }))();
                    },
                    drawCanvasTwo: function() {
                        var t = this;
                        return s(n.default.mark(function a() {
                            var r, i, o, l, c, u, d, f, h, g, w, v;
                            return n.default.wrap(function(a) {
                                for (;;) switch (a.prev = a.next) {
                                  case 0:
                                    (r = e.createCanvasContext("shareCanvas2", t)).setFillStyle("#37EEA8"), r.fillRect(0, 0, t.canvasWidth, t.canvasHeight), 
                                    r.draw(!0), r.setFillStyle("#010626"), r.fillRect(2, 2, 618, 752), r.draw(!0), i = t.bgInfo, 
                                    o = i.path, l = i.width, c = i.height, u = i.x, d = i.y, r.drawImage(o, u, d, l, c), 
                                    r.draw(!0), r.drawImage(t.logo, 214, 82, 195, 35), r.draw(!0), r.setFillStyle("white"), 
                                    r.setFontSize(32), r.setTextAlign("center"), r.fillText(t.name, t.canvasWidth / 2, 580), 
                                    r.draw(!0), t.remark && (r.setFillStyle("white"), r.setFontSize(28), r.setTextAlign("center"), 
                                    t.fillTextLineBreak(r, t.remark, 311, 640, 522, 32), r.draw(!0)), r.setFillStyle("black"), 
                                    r.setFontSize(24), r.setTextAlign("center"), r.fillText("扫码进入空间站，搜集心动物资", 311, 892), 
                                    r.draw(!0), f = t.bgList.find(function(e) {
                                        return 2 === e.style;
                                    }), h = f.codeLeft, g = f.codeTop, w = f.codeWidth, v = f.codeHeight, r.save(), 
                                    r.beginPath(), r.arc(h + w / 2, g + w / 2, w / 2, 0, 2 * Math.PI), r.setFillStyle("#ffffff"), 
                                    r.fill(), r.clip(), r.drawImage(t.qrcode, h, g, w, v), r.restore(), r.draw(!0, s(n.default.mark(function e() {
                                        return n.default.wrap(function(e) {
                                            for (;;) switch (e.prev = e.next) {
                                              case 0:
                                                return e.next = 2, t.saveImageToPhotosAlbum(2);

                                              case 2:
                                              case "end":
                                                return e.stop();
                                            }
                                        }, e);
                                    })));

                                  case 33:
                                  case "end":
                                    return a.stop();
                                }
                            }, a);
                        }))();
                    },
                    drawCanvasThree: function() {
                        var t = this;
                        return s(n.default.mark(function a() {
                            var r, i, o, l, c, u, d, f, h, g, w, v;
                            return n.default.wrap(function(a) {
                                for (;;) switch (a.prev = a.next) {
                                  case 0:
                                    (r = e.createCanvasContext("shareCanvas3", t)).setFillStyle("#37EEA8"), r.fillRect(0, 0, t.canvasWidth, t.canvasHeight), 
                                    r.draw(!0), r.setFillStyle("#010626"), r.fillRect(2, 2, 618, 752), r.draw(!0), i = t.bgInfo, 
                                    o = i.path, l = i.width, c = i.height, u = i.x, d = i.y, r.drawImage(o, u, d, l, c), 
                                    r.draw(!0), r.drawImage(t.logo, 214, 82, 195, 35), r.draw(!0), r.setFillStyle("white"), 
                                    r.setFontSize(32), r.setTextAlign("center"), r.fillText(t.name, t.canvasWidth / 2, 580), 
                                    r.draw(!0), t.remark && (r.setFillStyle("white"), r.setFontSize(28), r.setTextAlign("center"), 
                                    t.fillTextLineBreak(r, t.remark, 311, 640, 522, 32), r.draw(!0)), t.avatar && (r.save(), 
                                    r.beginPath(), r.arc(67, 828, 23, 0, 2 * Math.PI), r.fill(), r.clip(), r.drawImage(t.avatar, 44, 805, 46, 46), 
                                    r.restore(), r.draw(!0), r.setFillStyle("black"), r.setFontSize(36), r.setTextAlign("left"), 
                                    r.fillText(t.loginData.nickname || "", 105, 840), r.draw(!0)), r.setFillStyle("black"), 
                                    r.setFontSize(24), r.setTextAlign("left"), r.fillText("扫码进入空间站，搜集心动物资", 105, 886), 
                                    r.draw(!0), f = t.bgList.find(function(e) {
                                        return 3 === e.style;
                                    }), h = f.codeLeft, g = f.codeTop, w = f.codeWidth, v = f.codeHeight, r.save(), 
                                    r.beginPath(), r.arc(h + w / 2, g + w / 2, w / 2, 0, 2 * Math.PI), r.setFillStyle("#ffffff"), 
                                    r.fill(), r.clip(), r.drawImage(t.qrcode, h, g, w, v), r.restore(), r.draw(!0, s(n.default.mark(function e() {
                                        return n.default.wrap(function(e) {
                                            for (;;) switch (e.prev = e.next) {
                                              case 0:
                                                return e.next = 2, t.saveImageToPhotosAlbum(3);

                                              case 2:
                                              case "end":
                                                return e.stop();
                                            }
                                        }, e);
                                    })));

                                  case 34:
                                  case "end":
                                    return a.stop();
                                }
                            }, a);
                        }))();
                    },
                    drawCanvasFour: function() {
                        var t = this;
                        return s(n.default.mark(function a() {
                            var r, i, o, l, c, u, d, f, h, g, w, v;
                            return n.default.wrap(function(a) {
                                for (;;) switch (a.prev = a.next) {
                                  case 0:
                                    (r = e.createCanvasContext("shareCanvas4", t)).setFillStyle("#010626"), r.fillRect(0, 0, t.canvasWidth, 74), 
                                    r.draw(!0), r.setFillStyle("#37EEA8"), r.fillRect(0, 74, t.canvasWidth, t.canvasHeight), 
                                    r.draw(!0), r.setFillStyle("#010626"), r.fillRect(2, 76, 618, 752), r.draw(!0), 
                                    i = t.bgInfo, o = i.path, l = i.width, c = i.height, u = i.x, d = i.y, r.drawImage(o, u, d + 74, l, c), 
                                    r.draw(!0), r.drawImage(t.logo, 214, 156, 195, 35), r.draw(!0), r.setFillStyle("white"), 
                                    r.setFontSize(32), r.setTextAlign("center"), r.fillText(t.name, t.canvasWidth / 2, 654), 
                                    r.draw(!0), t.remark && (r.setFillStyle("white"), r.setFontSize(28), r.setTextAlign("center"), 
                                    t.fillTextLineBreak(r, t.remark, 311, 714, 522, 32), r.draw(!0)), r.setFillStyle("black"), 
                                    r.setFontSize(24), r.setTextAlign("center"), r.fillText("扫码进入空间站，搜集心动物资", 311, 937), 
                                    r.draw(!0), f = t.bgList.find(function(e) {
                                        return 4 === e.style;
                                    }), h = f.codeLeft, g = f.codeTop, w = f.codeWidth, v = f.codeHeight, r.save(), 
                                    r.beginPath(), r.arc(h + w / 2, g + w / 2, w / 2, 0, 2 * Math.PI), r.setFillStyle("#ffffff"), 
                                    r.fill(), r.clip(), r.drawImage(t.qrcode, h, g, w, v), r.restore(), r.draw(!0, s(n.default.mark(function e() {
                                        return n.default.wrap(function(e) {
                                            for (;;) switch (e.prev = e.next) {
                                              case 0:
                                                return e.next = 2, t.saveImageToPhotosAlbum(4);

                                              case 2:
                                              case "end":
                                                return e.stop();
                                            }
                                        }, e);
                                    })));

                                  case 36:
                                  case "end":
                                    return a.stop();
                                }
                            }, a);
                        }))();
                    },
                    drawCanvas: function() {
                        var e = this;
                        return s(n.default.mark(function t() {
                            var a, r, i, s, o;
                            return n.default.wrap(function(t) {
                                for (;;) switch (t.prev = t.next) {
                                  case 0:
                                    return t.next = 2, e.selectImg(e.logoUrl, "logo图片不存在");

                                  case 2:
                                    if (a = t.sent) {
                                        t.next = 6;
                                        break;
                                    }
                                    return e.close(), t.abrupt("return");

                                  case 6:
                                    return e.logo = a.path, t.next = 9, e.selectImg(e.bg, "背景图片不存在");

                                  case 9:
                                    if (r = t.sent) {
                                        t.next = 13;
                                        break;
                                    }
                                    return e.close(), t.abrupt("return");

                                  case 13:
                                    return i = e.canvasWidth - 4, e.bgInfo = {
                                        path: r.path,
                                        width: r.width >= i ? i : r.width,
                                        height: r.height >= 752 ? 752 : r.height,
                                        x: r.width >= i ? 2 : (i - r.width) / 2,
                                        y: r.height >= 752 ? 2 : (752 - r.height) / 2
                                    }, console.log("bg: ", r, e.bgInfo), t.next = 18, e.selectImg(e.codeUrl, "小程序码图片不存在");

                                  case 18:
                                    if (s = t.sent) {
                                        t.next = 22;
                                        break;
                                    }
                                    return e.close(), t.abrupt("return");

                                  case 22:
                                    if (e.qrcode = s.path, console.log("qrcode: ", e.qrcode), !e.loginData.imageUrl) {
                                        t.next = 30;
                                        break;
                                    }
                                    return t.next = 27, e.selectImg(e.loginData.imageUrl, "头像不存在", !1);

                                  case 27:
                                    o = t.sent, e.avatar = o.path, console.log("avatar: ", e.avatar);

                                  case 30:
                                    if (!e.styles.includes(1)) {
                                        t.next = 33;
                                        break;
                                    }
                                    return t.next = 33, e.drawCanvasOne();

                                  case 33:
                                    if (!e.styles.includes(2)) {
                                        t.next = 36;
                                        break;
                                    }
                                    return t.next = 36, e.drawCanvasTwo();

                                  case 36:
                                    if (!e.styles.includes(3)) {
                                        t.next = 39;
                                        break;
                                    }
                                    return t.next = 39, e.drawCanvasThree();

                                  case 39:
                                    if (!e.styles.includes(4)) {
                                        t.next = 42;
                                        break;
                                    }
                                    return t.next = 42, e.drawCanvasFour();

                                  case 42:
                                  case "end":
                                    return t.stop();
                                }
                            }, t);
                        }))();
                    },
                    selectImg: function(t, a) {
                        var n = !(arguments.length > 2 && void 0 !== arguments[2]) || arguments[2];
                        return new Promise(function(r, i) {
                            e.getImageInfo({
                                src: t,
                                success: function(e) {
                                    r(e);
                                },
                                fail: function(i) {
                                    console.log(i, "getImageInfo", t), r(!1), e.hideLoading(), n && e.showToast({
                                        title: a || "图片资源不存在",
                                        icon: "none"
                                    });
                                }
                            });
                        });
                    },
                    saveImageToPhotosAlbum: function(t) {
                        var a = this;
                        return new Promise(function(n, r) {
                            var i = a, s = a.canvasHeight + (4 === t ? 74 : 0);
                            e.canvasToTempFilePath({
                                x: 0,
                                y: 0,
                                width: i.canvasWidth,
                                height: s,
                                destWidth: i.canvasWidth,
                                destHeight: s,
                                canvasId: "shareCanvas".concat(t),
                                success: function(e) {
                                    i.urlList.push({
                                        style: t,
                                        url: e.tempFilePath
                                    }), console.log("poster".concat(t, ": "), e), n(e.tempFilePath);
                                },
                                fail: function(t) {
                                    console.log(t), e.showToast({
                                        title: "海报生成失败",
                                        icon: "none"
                                    }), e.hideLoading(), r();
                                }
                            }, a);
                        });
                    },
                    shareImage: function() {
                        console.log(this.urlList, this.currentIndex), this.shareLoading = !0;
                        var e = this;
                        wx.showShareImageMenu({
                            path: e.urlList[e.currentIndex].url,
                            success: function(t) {
                                e.shareLoading = !1, e.$emit("share", e.urlList[e.currentIndex].url), console.log("拉起分享", t), 
                                (0, r.shareTag)(e.medalId, "SHARE");
                            },
                            fail: function() {
                                e.shareLoading = !1;
                            }
                        });
                    },
                    fillTextLineBreak: function(e, t, a, n, r, i) {
                        for (var s = t.split("\n"), o = 0; o < s.length; o++) {
                            var l = s[o];
                            if (e.measureText(l).width > r) {
                                for (var c = 0, u = 0, d = -1; c < l.length; ) {
                                    for (;e.measureText(l.substring(u, c)).width < r && c < l.length; ) c++;
                                    d++, e.fillText(l.substring(u, c), a, n + i * d), u = c;
                                }
                                n += i * (d + 1);
                            } else e.fillText(l, a, n), n += i;
                        }
                    }
                }
            };
            t.default = o;
        }).call(this, a("543d").default);
    }
} ]), (global.webpackJsonp = global.webpackJsonp || []).push([ "components/poster/medal-create-component", {
    "components/poster/medal-create-component": function(e, t, a) {
        a("543d").createComponent(a("85ce"));
    }
}, [ [ "components/poster/medal-create-component" ] ] ]);