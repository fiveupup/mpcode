(global.webpackJsonp = global.webpackJsonp || []).push([ [ "components/article/like-item" ], {
    "05be": function(e, t, i) {
        i.r(t);
        var n = i("a2f2"), c = i("c0ae");
        for (var o in c) [ "default" ].indexOf(o) < 0 && function(e) {
            i.d(t, e, function() {
                return c[e];
            });
        }(o);
        i("b23b");
        var a = i("f0c5"), s = Object(a.a)(c.default, n.b, n.c, !1, null, "2d850b0e", null, !1, n.a, void 0);
        t.default = s.exports;
    },
    a010: function(e, t, i) {
        Object.defineProperty(t, "__esModule", {
            value: !0
        }), t.default = void 0;
        var n = i("365c"), c = {
            props: {
                item: {
                    type: Object,
                    require: !0
                }
            },
            data: function() {
                return {
                    avatar: "https://pepsicocampuscrmstgblob.blob.core.chinacloudapi.cn/pepsicocampuscrmstgblob/FAQ_202305061357534454.png",
                    isLikes: this.item.isLikes,
                    likesNum: this.item.likesNum
                };
            },
            methods: {
                clickLike: function() {
                    var e = this;
                    this.isLikes ? (0, n.cancelLikes)(this.item.id).then(function() {
                        e.isLikes = !1, e.likesNum -= 1, e.$emit("cancel");
                    }) : (0, n.giveALike)(this.item.id).then(function() {
                        e.isLikes = !0, e.likesNum += 1, e.$emit("like");
                    });
                }
            }
        };
        t.default = c;
    },
    a2f2: function(e, t, i) {
        i.d(t, "b", function() {
            return n;
        }), i.d(t, "c", function() {
            return c;
        }), i.d(t, "a", function() {});
        var n = function() {
            this.$createElement;
            this._self._c;
        }, c = [];
    },
    b0b9: function(e, t, i) {},
    b23b: function(e, t, i) {
        var n = i("b0b9");
        i.n(n).a;
    },
    c0ae: function(e, t, i) {
        i.r(t);
        var n = i("a010"), c = i.n(n);
        for (var o in n) [ "default" ].indexOf(o) < 0 && function(e) {
            i.d(t, e, function() {
                return n[e];
            });
        }(o);
        t.default = c.a;
    }
} ]), (global.webpackJsonp = global.webpackJsonp || []).push([ "components/article/like-item-create-component", {
    "components/article/like-item-create-component": function(e, t, i) {
        i("543d").createComponent(i("05be"));
    }
}, [ [ "components/article/like-item-create-component" ] ] ]);