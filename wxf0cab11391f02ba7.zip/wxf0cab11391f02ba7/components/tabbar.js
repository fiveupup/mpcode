(global.webpackJsonp = global.webpackJsonp || []).push([ [ "components/tabbar" ], {
    "26fc": function(e, t, o) {
        o.r(t);
        var n = o("9533"), a = o("af78");
        for (var c in a) [ "default" ].indexOf(c) < 0 && function(e) {
            o.d(t, e, function() {
                return a[e];
            });
        }(c);
        o("c858");
        var i = o("f0c5"), r = Object(i.a)(a.default, n.b, n.c, !1, null, "08a8a18c", null, !1, n.a, void 0);
        t.default = r.exports;
    },
    "42c2": function(e, t, o) {
        (function(e) {
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = void 0;
            var n = {
                components: {
                    uQRCode: function() {
                        Promise.all([ o.e("common/vendor"), o.e("components/uqrcode/uqrcode") ]).then(function() {
                            return resolve(o("d757"));
                        }.bind(null, o)).catch(o.oe);
                    }
                },
                props: {
                    act: {
                        type: String,
                        default: "俱乐部",
                        require: !0
                    },
                    loginData: {
                        type: Object,
                        default: function() {
                            return {};
                        }
                    }
                },
                mounted: function() {
                    console.log(getApp().globalData, "this.globalData.isIphoneX"), this.isIphoneX = getApp().globalData.isIphoneX;
                },
                data: function() {
                    return {
                        share_show: !1,
                        modal_qr: !0,
                        mylist: [ {
                            iconPath: o("e636"),
                            selectedIconPath: o("5e80"),
                            text: "俱乐部",
                            customIcon: !1,
                            url: "/pages/index/index"
                        }, {
                            iconPath: o("c1c4"),
                            selectedIconPath: o("f248"),
                            text: "心动有礼",
                            customIcon: !1,
                            url: "/pages/gift/gift"
                        }, {
                            iconPath: o("72e4"),
                            selectedIconPath: o("72e4"),
                            midButton: !0,
                            customIcon: !1
                        }, {
                            iconPath: o("e836"),
                            selectedIconPath: o("54d5"),
                            text: "社团",
                            customIcon: !1,
                            url: "/pages/team/team"
                        }, {
                            iconPath: o("418e"),
                            selectedIconPath: o("418e"),
                            text: "商城",
                            isDot: !1,
                            jumpMiniApp: !0,
                            appId: "wxef8d617b01946908",
                            url: "pages/common/blank-page/index?weappSharePath=pages%2Fhome%2Fdashboard%2Findex%3Fkdt_id%3D90706668"
                        } ],
                        current: 0,
                        showQrcode: !1,
                        qrurl: "",
                        isIphoneX: !1
                    };
                },
                methods: {
                    hiddenShow: function() {
                        this.share_show = !1;
                    },
                    clickTab: function(t) {
                        var o = this;
                        if (t.midButton) {
                            if (!this.loginData.token) return void e.showModal({
                                title: "提示",
                                content: "请先登录",
                                confirmColor: "#37eea8",
                                success: function(t) {
                                    t.confirm && e.redirectTo({
                                        url: "/pages/login/login"
                                    });
                                }
                            });
                            var n = e.getStorageSync("qrurl");
                            if (n) return e.showLoading({
                                mask: !0
                            }), void setTimeout(function() {
                                o.qrurl = n, o.showQrcode = !0, o.share_show = !0, e.hideLoading();
                            }, 400);
                            e.showLoading({
                                mask: !0
                            }), this.$refs.uqrcode.make({
                                size: 375,
                                text: this.loginData.memberNo + ""
                            }).then(function(t) {
                                console.log(t), o.qrurl = t.tempFilePath, e.setStorageSync("qrurl", t.tempFilePath), 
                                o.showQrcode = !0, o.share_show = !0, e.hideLoading();
                            }).catch(function() {
                                o.showQrcode = !0, o.share_show = !0, e.hideLoading(), e.showToast({
                                    title: "二维码生成失败"
                                });
                            });
                        } else {
                            if (console.log("tab切换", t), t.jumpMiniApp) return void e.navigateToMiniProgram({
                                appId: t.appId,
                                path: t.url,
                                extraData: {},
                                success: function(e) {
                                    console.log("打开成功");
                                }
                            });
                            e.switchTab({
                                url: t.url
                            });
                        }
                    },
                    beforeSwitch: function(e) {
                        console.log("index", e), this.current = e, 1 == e && wx.redirectTo({
                            url: "/pages/gift/gift"
                        }), 3 == e && (console.log("tab切换--去社团"), wx.redirectTo({
                            url: "/pages/team/team",
                            success: function(e) {}
                        }));
                    },
                    quietMake: function() {
                        var t = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : "";
                        return this.$refs.uqrcode.make({
                            size: 375,
                            text: t
                        }).then(function(t) {
                            var o = t.tempFilePath;
                            e.setStorage({
                                key: "qrurl",
                                data: o
                            });
                        });
                    }
                }
            };
            t.default = n;
        }).call(this, o("543d").default);
    },
    9533: function(e, t, o) {
        o.d(t, "b", function() {
            return n;
        }), o.d(t, "c", function() {
            return a;
        }), o.d(t, "a", function() {});
        var n = function() {
            this.$createElement;
            this._self._c;
        }, a = [];
    },
    a438: function(e, t, o) {},
    af78: function(e, t, o) {
        o.r(t);
        var n = o("42c2"), a = o.n(n);
        for (var c in n) [ "default" ].indexOf(c) < 0 && function(e) {
            o.d(t, e, function() {
                return n[e];
            });
        }(c);
        t.default = a.a;
    },
    c858: function(e, t, o) {
        var n = o("a438");
        o.n(n).a;
    }
} ]), (global.webpackJsonp = global.webpackJsonp || []).push([ "components/tabbar-create-component", {
    "components/tabbar-create-component": function(e, t, o) {
        o("543d").createComponent(o("26fc"));
    }
}, [ [ "components/tabbar-create-component" ] ] ]);