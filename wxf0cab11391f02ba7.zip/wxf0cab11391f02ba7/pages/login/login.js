(global.webpackJsonp = global.webpackJsonp || []).push([ [ "pages/login/login" ], {
    "0036": function(e, t, n) {
        (function(e) {
            n("6cdc"), a(n("66fd"));
            var t = a(n("a86a"));
            function a(e) {
                return e && e.__esModule ? e : {
                    default: e
                };
            }
            wx.__webpack_require_UNI_MP_PLUGIN__ = n, e(t.default);
        }).call(this, n("543d").createPage);
    },
    3285: function(e, t, n) {
        n.r(t);
        var a = n("8edd"), o = n.n(a);
        for (var i in a) [ "default" ].indexOf(i) < 0 && function(e) {
            n.d(t, e, function() {
                return a[e];
            });
        }(i);
        t.default = o.a;
    },
    "583e": function(e, t, n) {},
    "61cd": function(e, t, n) {
        n.d(t, "b", function() {
            return o;
        }), n.d(t, "c", function() {
            return i;
        }), n.d(t, "a", function() {
            return a;
        });
        var a = {
            uActionSheet: function() {
                return n.e("node-modules/uview-ui/components/u-action-sheet/u-action-sheet").then(n.bind(null, "b262"));
            }
        }, o = function() {
            var e = this, t = (e.$createElement, e._self._c, e.$hasScopedSlotsParams("35a7246c-1")), n = t ? e.$getScopedSlotsParams("35a7246c-1", "default") : null;
            e._isMounted || (e.e0 = function(t) {
                return t.stopPropagation(), e.toAgreement(1);
            }, e.e1 = function(t) {
                return t.stopPropagation(), e.toAgreement(2);
            }, e.e2 = function(t) {
                e.agreePrivacy = !1;
            }), e.$mp.data = Object.assign({}, {
                $root: {
                    m0: t,
                    m1: n
                }
            });
        }, i = [];
    },
    "8edd": function(e, t, n) {
        (function(e) {
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = void 0;
            var a = function(e) {
                return e && e.__esModule ? e : {
                    default: e
                };
            }(n("4795")), o = n("7b12"), i = n("403a");
            function r(e, t, n, a, o, i, r) {
                try {
                    var c = e[i](r), s = c.value;
                } catch (e) {
                    return void n(e);
                }
                c.done ? t(s) : Promise.resolve(s).then(a, o);
            }
            function c(e) {
                return function() {
                    var t = this, n = arguments;
                    return new Promise(function(a, o) {
                        var i = e.apply(t, n);
                        function c(e) {
                            r(i, a, o, c, s, "next", e);
                        }
                        function s(e) {
                            r(i, a, o, c, s, "throw", e);
                        }
                        c(void 0);
                    });
                };
            }
            var s = {
                components: {
                    PrivacyModal: function() {
                        n.e("components/privacy/index").then(function() {
                            return resolve(n("d0ee"));
                        }.bind(null, n)).catch(n.oe);
                    }
                },
                data: function() {
                    return {
                        checkoutStatus: !1,
                        loginBg: "",
                        code: "",
                        agreePrivacy: !0,
                        phoneList: [],
                        showPhoneSheet: !1,
                        loginStatus: 0,
                        loginData: {},
                        ivData: {}
                    };
                },
                onShow: function() {
                    var t = getCurrentPages();
                    console.log("pages: ", t), t.length > 1 && "pages/login/login" === t[t.length - 2].route ? e.navigateBack({
                        delta: 1
                    }) : (this.getLoginBg(), this.silentLogin());
                },
                methods: {
                    silentLogin: function() {
                        var t = this;
                        return c(a.default.mark(function n() {
                            var i, r, c;
                            return a.default.wrap(function(n) {
                                for (;;) switch (n.prev = n.next) {
                                  case 0:
                                    return n.next = 2, t.getLoginCode();

                                  case 2:
                                    return n.next = 4, (0, o.tologinByCode)({
                                        code: t.code,
                                        miniQrCodeScanData: getApp().globalData.scene ? {
                                            path: getApp().globalData.path,
                                            param: getApp().globalData.scene
                                        } : void 0
                                    });

                                  case 4:
                                    if (i = n.sent, r = i.data, console.log("data: ", r), "00000" !== r.code) {
                                        n.next = 12;
                                        break;
                                    }
                                    t.loginStatus = 1, t.loginData = r.data, n.next = 27;
                                    break;

                                  case 12:
                                    if ("00027" !== r.code) {
                                        n.next = 18;
                                        break;
                                    }
                                    return t.loginStatus = 2, n.next = 16, t.getPhones();

                                  case 16:
                                    n.next = 27;
                                    break;

                                  case 18:
                                    if ("00028" !== r.code) {
                                        n.next = 26;
                                        break;
                                    }
                                    return c = e.getStorageSync("ivData"), t.ivData = c ? JSON.parse(c) : {
                                        time: 0
                                    }, Date.now() - t.ivData.time < 15552e6 ? t.loginStatus = 4 : t.loginStatus = 3, 
                                    n.next = 24, t.getLoginCode();

                                  case 24:
                                    n.next = 27;
                                    break;

                                  case 26:
                                    t.loginStatus = 0;

                                  case 27:
                                  case "end":
                                    return n.stop();
                                }
                            }, n);
                        }))();
                    },
                    onLoginPrev: function() {
                        0 === this.loginStatus ? this.silentLogin() : 1 === this.loginStatus ? this.onLogin() : 2 === this.loginStatus ? this.showPhoneSheet = !0 : 4 === this.loginStatus && this.onPhoneNumberLogin(this.ivData);
                    },
                    onLogin: function() {
                        if (e.removeStorageSync("qrurl"), getApp().globalData.path = void 0, getApp().globalData.scene = void 0, 
                        e.setStorageSync("loginData2", JSON.stringify(this.loginData)), console.log("存储成功", this.loginData), 
                        (0, o.refreshEnter)(), getApp().globalData.hsCodeId) getApp().globalData.hsCodeId = void 0, 
                        e.navigateBack(); else if (this.loginData.updateWechatMiniInfoFlag.value) (0, i.canIUseVersion)("2.27.0") ? e.redirectTo({
                            url: "/pages/mine/mine"
                        }) : e.redirectTo({
                            url: "../confirm/confirm?back=".concat(getApp().globalData.isBack ? 1 : 0)
                        }); else if (getApp().globalData.isBack) {
                            1 === getCurrentPages().length ? e.switchTab({
                                url: "/pages/index/index"
                            }) : e.navigateBack();
                        } else e.reLaunch({
                            url: "/pages/mall/mall"
                        });
                    },
                    getPhones: function() {
                        var e = this;
                        return c(a.default.mark(function t() {
                            var n, i, r;
                            return a.default.wrap(function(t) {
                                for (;;) switch (t.prev = t.next) {
                                  case 0:
                                    return t.next = 2, (0, o.code2Phones)(e.code);

                                  case 2:
                                    i = t.sent, r = i.data, e.phoneList = null === (n = r.data) || void 0 === n ? void 0 : n.map(function(e) {
                                        return {
                                            text: e,
                                            color: "#000856",
                                            fontSize: 32
                                        };
                                    });

                                  case 5:
                                  case "end":
                                    return t.stop();
                                }
                            }, t);
                        }))();
                    },
                    getLoginStatus: function() {
                        return c(a.default.mark(function t() {
                            var n, i, r;
                            return a.default.wrap(function(t) {
                                for (;;) switch (t.prev = t.next) {
                                  case 0:
                                    if (!(n = (n = e.getStorageSync("loginData2")) ? JSON.parse(n) : {}).token || !n.phone) {
                                        t.next = 9;
                                        break;
                                    }
                                    return i = {
                                        memberPhone: n.phone
                                    }, t.next = 6, (0, o.shareStatus)(i);

                                  case 6:
                                    r = t.sent, "00000" === r.data.code && e.switchTab({
                                        url: "/pages/index/index"
                                    });

                                  case 9:
                                  case "end":
                                    return t.stop();
                                }
                            }, t);
                        }))();
                    },
                    getLoginBg: function() {
                        var e = this;
                        return c(a.default.mark(function t() {
                            var n, i;
                            return a.default.wrap(function(t) {
                                for (;;) switch (t.prev = t.next) {
                                  case 0:
                                    return t.next = 2, (0, o.imageResources)("login");

                                  case 2:
                                    n = t.sent, i = n.data, e.loginBg = i.data;

                                  case 5:
                                  case "end":
                                    return t.stop();
                                }
                            }, t);
                        }))();
                    },
                    toAgreement: function(t) {
                        e.navigateTo({
                            url: "/pages/agreement/agreement?ruleType=" + t
                        });
                    },
                    onAgreePrivacy: function(e) {
                        "auto" !== e && (this.checkoutStatus = !0), this.agreePrivacy = !0;
                    },
                    agreementCheck: function() {
                        this.agreePrivacy ? this.checkoutStatus = !this.checkoutStatus : this.$refs.privacy.onShowPrivacy();
                    },
                    getLoginCode: function() {
                        var e = this;
                        return new Promise(function(t, n) {
                            wx.login({
                                success: function(a) {
                                    a.code ? (console.log("登录获取的 code ", a.code), e.code = a.code, t(a.code)) : (console.log("登录失败！" + a.errMsg), 
                                    n(a.errMsg));
                                }
                            });
                        });
                    },
                    onSelectPhone: function(e) {
                        var t = this;
                        return c(a.default.mark(function n() {
                            var i, r;
                            return a.default.wrap(function(n) {
                                for (;;) switch (n.prev = n.next) {
                                  case 0:
                                    return console.log("index: ", e), n.next = 3, (0, o.tologinByPhone)({
                                        code: t.code,
                                        miniQrCodeScanData: getApp().globalData.scene ? {
                                            path: getApp().globalData.path,
                                            param: getApp().globalData.scene
                                        } : void 0,
                                        phone: t.phoneList[e].text
                                    });

                                  case 3:
                                    i = n.sent, "00000" === (r = i.data).code && (t.loginData = r.data, t.onLogin());

                                  case 6:
                                  case "end":
                                    return n.stop();
                                }
                            }, n);
                        }))();
                    },
                    getPhoneNumber: function(t) {
                        this.checkoutStatus ? (console.log("errMsg", t), "getPhoneNumber:ok" === t.detail.errMsg ? (e.setStorageSync("ivData", JSON.stringify({
                            iv: t.detail.iv,
                            encryptedData: t.detail.encryptedData,
                            time: Date.now()
                        })), this.loginStatus = 4, this.onPhoneNumberLogin(t.detail)) : getApp().globalData.hsCodeId && e.navigateBack()) : this.showToast("请勾选协议！", "warning");
                    },
                    onPhoneNumberLogin: function(t) {
                        var n = this;
                        return c(a.default.mark(function i() {
                            var r, c;
                            return a.default.wrap(function(a) {
                                for (;;) switch (a.prev = a.next) {
                                  case 0:
                                    return r = {
                                        iv: t.iv,
                                        code: n.code,
                                        encryptedData: t.encryptedData,
                                        miniQrCodeScanData: getApp().globalData.scene ? {
                                            path: getApp().globalData.path,
                                            param: getApp().globalData.scene
                                        } : void 0
                                    }, e.showLoading({
                                        mask: !0
                                    }), a.prev = 2, a.next = 5, (0, o.tologin)(r);

                                  case 5:
                                    c = a.sent, console.log("登录结果", c), e.hideLoading(), "00000" == c.data.code ? (n.loginData = c.data.data, 
                                    n.onLogin()) : (n.showToast(c.data.message, "error"), n.getLoginCode()), a.next = 16;
                                    break;

                                  case 11:
                                    a.prev = 11, a.t0 = a.catch(2), console.error(a.t0), e.hideLoading(), n.getLoginCode();

                                  case 16:
                                  case "end":
                                    return a.stop();
                                }
                            }, i, null, [ [ 2, 11 ] ]);
                        }))();
                    },
                    showToast: function(t, n) {
                        e.showToast({
                            title: t,
                            icon: "none"
                        });
                    }
                }
            };
            t.default = s;
        }).call(this, n("543d").default);
    },
    a86a: function(e, t, n) {
        n.r(t);
        var a = n("61cd"), o = n("3285");
        for (var i in o) [ "default" ].indexOf(i) < 0 && function(e) {
            n.d(t, e, function() {
                return o[e];
            });
        }(i);
        n("bc24");
        var r = n("f0c5"), c = Object(r.a)(o.default, a.b, a.c, !1, null, null, null, !1, a.a, void 0);
        t.default = c.exports;
    },
    bc24: function(e, t, n) {
        var a = n("583e");
        n.n(a).a;
    }
}, [ [ "0036", "common/runtime", "common/vendor" ] ] ]);