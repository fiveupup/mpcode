(global.webpackJsonp = global.webpackJsonp || []).push([ [ "pages/medal/index" ], {
    "262c": function(n, t, e) {
        var a = e("3a9e");
        e.n(a).a;
    },
    "2e67": function(n, t, e) {
        (function(n) {
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = void 0;
            var a = function(n) {
                return n && n.__esModule ? n : {
                    default: n
                };
            }(e("4795")), r = e("30a7");
            function o(n, t, e, a, r, o, i) {
                try {
                    var u = n[o](i), c = u.value;
                } catch (n) {
                    return void e(n);
                }
                u.done ? t(c) : Promise.resolve(c).then(a, r);
            }
            function i(n) {
                return function() {
                    var t = this, e = arguments;
                    return new Promise(function(a, r) {
                        var i = n.apply(t, e);
                        function u(n) {
                            o(i, a, r, u, c, "next", n);
                        }
                        function c(n) {
                            o(i, a, r, u, c, "throw", n);
                        }
                        u(void 0);
                    });
                };
            }
            var u = {
                data: function() {
                    return {
                        avatar: "https://pepsicocampuscrmstgblob.blob.core.chinacloudapi.cn/pepsicocampuscrmstgblob/FAQ_202305061358136407.jpeg",
                        background: {
                            background: "transparent"
                        },
                        loginData: {},
                        medalNum: 0,
                        medalList: []
                    };
                },
                onLoad: function(t) {
                    var e = n.getStorageSync("loginData2");
                    this.loginData = e ? JSON.parse(e) : {}, wx.setNavigationBarColor({
                        frontColor: "#ffffff",
                        backgroundColor: "#010626",
                        animation: {
                            duration: 400,
                            timingFunc: "easeIn"
                        }
                    });
                },
                onShow: function() {
                    this.loadData();
                },
                methods: {
                    loadData: function() {
                        var t = this;
                        return i(a.default.mark(function e() {
                            var o, i, u, c;
                            return a.default.wrap(function(e) {
                                for (;;) switch (e.prev = e.next) {
                                  case 0:
                                    return n.showLoading(), e.next = 3, (0, r.medalList)();

                                  case 3:
                                    if (o = e.sent, i = o.data, u = 0, c = [], i.data && i.data.length > 0 && (t.medalList = i.data.map(function(n) {
                                        var t;
                                        return n.medalList = null === (t = n.medalList) || void 0 === t ? void 0 : t.map(function(n) {
                                            return "SUCCESS" === n.takeStatus ? (u += 1, n.rate = 100) : "WAITING" === n.takeStatus ? n.rate = 100 : (c.push(n.id), 
                                            n.rate = 0), n;
                                        }), n;
                                    })), t.medalNum = u, n.hideLoading(), !(c.length > 0)) {
                                        e.next = 13;
                                        break;
                                    }
                                    return e.next = 13, t.loadProgress();

                                  case 13:
                                  case "end":
                                    return e.stop();
                                }
                            }, e);
                        }))();
                    },
                    loadProgress: function() {
                        var n = this;
                        return i(a.default.mark(function t() {
                            return a.default.wrap(function(t) {
                                for (;;) switch (t.prev = t.next) {
                                  case 0:
                                    (0, r.medalProgressAll)().then(function(t) {
                                        var e, a = null === (e = t.data.data) || void 0 === e ? void 0 : e.map(function(n) {
                                            var t;
                                            return {
                                                id: n.id,
                                                rate: (null === (t = n.progressList[0]) || void 0 === t ? void 0 : t.rate) || 0
                                            };
                                        });
                                        n.medalList = n.medalList.map(function(n) {
                                            var t;
                                            return n.medalList = null === (t = n.medalList) || void 0 === t ? void 0 : t.map(function(n) {
                                                var t = a.find(function(t) {
                                                    return t.id === n.id;
                                                }) || {};
                                                return t.id && (n.rate = t.rate), n;
                                            }), n;
                                        });
                                    });

                                  case 1:
                                  case "end":
                                    return t.stop();
                                }
                            }, t);
                        }))();
                    },
                    toDetail: function(t) {
                        n.navigateTo({
                            url: "/pages/medal/info?id=".concat(t)
                        });
                    },
                    toAgreement: function() {
                        n.navigateTo({
                            url: "/pages/agreement/agreement?ruleType=6"
                        });
                    },
                    goBack: function() {
                        1 === getCurrentPages().length ? n.switchTab({
                            url: "/pages/index/index"
                        }) : n.navigateBack();
                    }
                }
            };
            t.default = u;
        }).call(this, e("543d").default);
    },
    3796: function(n, t, e) {
        (function(n) {
            e("6cdc"), a(e("66fd"));
            var t = a(e("8b0c"));
            function a(n) {
                return n && n.__esModule ? n : {
                    default: n
                };
            }
            wx.__webpack_require_UNI_MP_PLUGIN__ = e, n(t.default);
        }).call(this, e("543d").createPage);
    },
    "3a9e": function(n, t, e) {},
    "55b1": function(n, t, e) {
        e.r(t);
        var a = e("2e67"), r = e.n(a);
        for (var o in a) [ "default" ].indexOf(o) < 0 && function(n) {
            e.d(t, n, function() {
                return a[n];
            });
        }(o);
        t.default = r.a;
    },
    "8b0c": function(n, t, e) {
        e.r(t);
        var a = e("a8a3"), r = e("55b1");
        for (var o in r) [ "default" ].indexOf(o) < 0 && function(n) {
            e.d(t, n, function() {
                return r[n];
            });
        }(o);
        e("262c");
        var i = e("f0c5"), u = Object(i.a)(r.default, a.b, a.c, !1, null, "c0e0e6ae", null, !1, a.a, void 0);
        t.default = u.exports;
    },
    a8a3: function(n, t, e) {
        e.d(t, "b", function() {
            return r;
        }), e.d(t, "c", function() {
            return o;
        }), e.d(t, "a", function() {
            return a;
        });
        var a = {
            uLineProgress: function() {
                return e.e("node-modules/uview-ui/components/u-line-progress/u-line-progress").then(e.bind(null, "1edd"));
            }
        }, r = function() {
            this.$createElement;
            this._self._c;
        }, o = [];
    }
}, [ [ "3796", "common/runtime", "common/vendor" ] ] ]);