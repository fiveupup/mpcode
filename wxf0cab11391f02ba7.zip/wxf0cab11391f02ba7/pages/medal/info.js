require("../../@babel/runtime/helpers/Arrayincludes"), (global.webpackJsonp = global.webpackJsonp || []).push([ [ "pages/medal/info" ], {
    "05a8": function(e, t, n) {
        (function(e) {
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = void 0;
            var a = function(e) {
                return e && e.__esModule ? e : {
                    default: e
                };
            }(n("4795")), r = n("30a7"), o = n("403a");
            function i(e, t) {
                return function(e) {
                    if (Array.isArray(e)) return e;
                }(e) || function(e, t) {
                    var n = null == e ? null : "undefined" != typeof Symbol && e[Symbol.iterator] || e["@@iterator"];
                    if (null != n) {
                        var a, r, o = [], i = !0, u = !1;
                        try {
                            for (n = n.call(e); !(i = (a = n.next()).done) && (o.push(a.value), !t || o.length !== t); i = !0) ;
                        } catch (e) {
                            u = !0, r = e;
                        } finally {
                            try {
                                i || null == n.return || n.return();
                            } finally {
                                if (u) throw r;
                            }
                        }
                        return o;
                    }
                }(e, t) || function(e, t) {
                    if (e) {
                        if ("string" == typeof e) return u(e, t);
                        var n = Object.prototype.toString.call(e).slice(8, -1);
                        return "Object" === n && e.constructor && (n = e.constructor.name), "Map" === n || "Set" === n ? Array.from(e) : "Arguments" === n || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n) ? u(e, t) : void 0;
                    }
                }(e, t) || function() {
                    throw new TypeError("Invalid attempt to destructure non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.");
                }();
            }
            function u(e, t) {
                (null == t || t > e.length) && (t = e.length);
                for (var n = 0, a = new Array(t); n < t; n++) a[n] = e[n];
                return a;
            }
            function s(e, t, n, a, r, o, i) {
                try {
                    var u = e[o](i), s = u.value;
                } catch (e) {
                    return void n(e);
                }
                u.done ? t(s) : Promise.resolve(s).then(a, r);
            }
            function c(e) {
                return function() {
                    var t = this, n = arguments;
                    return new Promise(function(a, r) {
                        var o = e.apply(t, n);
                        function i(e) {
                            s(o, a, r, i, u, "next", e);
                        }
                        function u(e) {
                            s(o, a, r, i, u, "throw", e);
                        }
                        i(void 0);
                    });
                };
            }
            var l = {
                components: {
                    MedalPoster: function() {
                        n.e("components/poster/medal").then(function() {
                            return resolve(n("85ce"));
                        }.bind(null, n)).catch(n.oe);
                    }
                },
                data: function() {
                    return {
                        showPost: !1,
                        background: {
                            background: "transparent"
                        },
                        loginData: {},
                        medalId: "",
                        medalInfo: {},
                        miniQrCode: "",
                        awardList: [],
                        taskList: []
                    };
                },
                onLoad: function(t) {
                    console.log("medal options: ", t);
                    var n = e.getStorageSync("loginData2");
                    this.loginData = n ? JSON.parse(n) : {}, this.medalId = t.id, t.scene && (this.medalId = this.getSceneId(decodeURIComponent(t.scene))), 
                    wx.setNavigationBarColor({
                        frontColor: "#ffffff",
                        backgroundColor: "#010626",
                        animation: {
                            duration: 400,
                            timingFunc: "easeIn"
                        }
                    });
                },
                onShow: function() {
                    this.loadData();
                },
                methods: {
                    loadData: function() {
                        var e = this;
                        return c(a.default.mark(function t() {
                            var n, o, i, u, s, c, l, d, f, p, m, g;
                            return a.default.wrap(function(t) {
                                for (;;) switch (t.prev = t.next) {
                                  case 0:
                                    return t.next = 2, (0, r.medal)(e.medalId);

                                  case 2:
                                    if (o = t.sent, i = o.data, [ "LOCKED" ].includes(i.data.takeStatus) ? e.loadTaskList() : e.taskList = [], 
                                    e.medalInfo = i.data || {}, u = [], (null === (n = i.data.awardList) || void 0 === n ? void 0 : n.length) > 0) for (s = i.data.awardList, 
                                    c = [], l = [], d = 0, f = s.length; d < f; d++) "POINT" === (p = s[d]).itemType ? (p.description = "可获得 ".concat(p.qty, " 个金土豆"), 
                                    u.push(p)) : "COUPON" === p.itemType ? (c.push(p.itemName), s[d].itemType !== (null === (m = s[d + 1]) || void 0 === m ? void 0 : m.itemType) && (p.description = c.join("、"), 
                                    u.push(p))) : "GOODS" === p.itemType ? (l.push(p.itemName), s[d].itemType !== (null === (g = s[d + 1]) || void 0 === g ? void 0 : g.itemType) && (p.description = l.join("、"), 
                                    u.push(p))) : "OTHER" === p.itemType && (p.itemTypeName = p.title, u.push(p));
                                    e.awardList = u;

                                  case 9:
                                  case "end":
                                    return t.stop();
                                }
                            }, t);
                        }))();
                    },
                    loadTaskList: function() {
                        var e = this;
                        return c(a.default.mark(function t() {
                            var n, o, i;
                            return a.default.wrap(function(t) {
                                for (;;) switch (t.prev = t.next) {
                                  case 0:
                                    return t.next = 2, (0, r.medalProgress)([ e.medalId ]);

                                  case 2:
                                    o = t.sent, i = o.data, e.taskList = (null === (n = i.data[0]) || void 0 === n ? void 0 : n.progressList) || [];

                                  case 5:
                                  case "end":
                                    return t.stop();
                                }
                            }, t);
                        }))();
                    },
                    handleReceiveMedal: function() {
                        var t = this;
                        return c(a.default.mark(function n() {
                            var o, i;
                            return a.default.wrap(function(n) {
                                for (;;) switch (n.prev = n.next) {
                                  case 0:
                                    return e.showLoading(), n.next = 3, (0, r.receiveMedal)(t.medalId);

                                  case 3:
                                    if (o = n.sent, "00000" !== o.data.code) {
                                        n.next = 10;
                                        break;
                                    }
                                    return n.next = 8, t.loadData();

                                  case 8:
                                    e.showToast({
                                        title: "领取成功",
                                        icon: "success"
                                    }), i = setTimeout(function() {
                                        clearTimeout(i), e.hideLoading();
                                    }, 1500);

                                  case 10:
                                  case "end":
                                    return n.stop();
                                }
                            }, n);
                        }))();
                    },
                    sharePoster: function() {
                        this.showPost = !0;
                    },
                    gotoPage: function(e) {
                        wx.navigateTo({
                            url: e
                        });
                    },
                    gotoTaskPage: function(t) {
                        "SIGN" === t ? wx.navigateTo({
                            url: "/pages/task_center/task_center"
                        }) : "INFO" === t ? wx.navigateTo({
                            url: "/pages/mine/mine"
                        }) : "LEVEL" === t ? wx.navigateTo({
                            url: "/pages/member_power/member_power"
                        }) : "INVITE" === t ? wx.navigateTo({
                            url: "/pages/call_recode/call_recode"
                        }) : "COMMUNITY" === t ? wx.switchTab({
                            url: "/pages/team/team"
                        }) : "SHOP" === t ? e.navigateToMiniProgram({
                            appId: "wxef8d617b01946908",
                            path: "pages/common/blank-page/index?weappSharePath=pages%2Fhome%2Fdashboard%2Findex%3Fkdt_id%3D90706668",
                            extraData: {},
                            success: function(e) {
                                console.log("打开成功", e);
                            }
                        }) : "STANDARD" === t ? wx.navigateTo({
                            url: "/pages/growth/growth"
                        }) : "REGISTER" === t ? wx.navigateTo({
                            url: "/pages/login/login"
                        }) : "SCAN" === t && e.showToast({
                            title: "请使用微信扫一扫活动二维码",
                            icon: "none"
                        });
                    },
                    jumpTo: function(e) {
                        this._jump(e);
                    },
                    _jump: function(t) {
                        var n = t.jumpType, a = t.appId, r = t.guideUrl, i = t.articleId;
                        0 === n ? e.navigateTo({
                            url: "/pages/webview/index?url=" + encodeURIComponent(r)
                        }) : 1 === n ? a === o.APPID ? [ "/pages/index/index", "/pages/gift/gift", "/pages/team/team" ].includes(r) ? e.switchTab({
                            url: r
                        }) : e.navigateTo({
                            url: r
                        }) : wx.navigateToMiniProgram({
                            appId: a,
                            path: r,
                            envVersion: "release",
                            success: function(e) {
                                console.log("跳转小程序成功");
                            }
                        }) : 2 === n && e.navigateTo({
                            url: "/pages/team_detail/team_detail?id=" + i
                        });
                    },
                    goBack: function() {
                        1 === getCurrentPages().length ? e.switchTab({
                            url: "/pages/index/index"
                        }) : e.navigateBack();
                    },
                    getSceneId: function(e) {
                        return e.includes("=") ? this.stringToObject(e).ID : e;
                    },
                    stringToObject: function(e) {
                        return e.split("&").reduce(function(e, t) {
                            var n = i(t.split("="), 2), a = n[0], r = n[1];
                            return e[a] = r, e;
                        }, {});
                    }
                }
            };
            t.default = l;
        }).call(this, n("543d").default);
    },
    "05eb": function(e, t, n) {
        n.d(t, "b", function() {
            return r;
        }), n.d(t, "c", function() {
            return o;
        }), n.d(t, "a", function() {
            return a;
        });
        var a = {
            uLineProgress: function() {
                return n.e("node-modules/uview-ui/components/u-line-progress/u-line-progress").then(n.bind(null, "1edd"));
            }
        }, r = function() {
            var e = this, t = (e.$createElement, e._self._c, e.showPost ? Number(e.medalId) : null);
            e._isMounted || (e.e0 = function(t) {
                e.showPost = !1;
            }), e.$mp.data = Object.assign({}, {
                $root: {
                    m0: t
                }
            });
        }, o = [];
    },
    "1b31": function(e, t, n) {
        n.r(t);
        var a = n("05eb"), r = n("c40f");
        for (var o in r) [ "default" ].indexOf(o) < 0 && function(e) {
            n.d(t, e, function() {
                return r[e];
            });
        }(o);
        n("2564");
        var i = n("f0c5"), u = Object(i.a)(r.default, a.b, a.c, !1, null, "7f474c89", null, !1, a.a, void 0);
        t.default = u.exports;
    },
    2564: function(e, t, n) {
        var a = n("51fb");
        n.n(a).a;
    },
    "51fb": function(e, t, n) {},
    "658d": function(e, t, n) {
        (function(e) {
            n("6cdc"), a(n("66fd"));
            var t = a(n("1b31"));
            function a(e) {
                return e && e.__esModule ? e : {
                    default: e
                };
            }
            wx.__webpack_require_UNI_MP_PLUGIN__ = n, e(t.default);
        }).call(this, n("543d").createPage);
    },
    c40f: function(e, t, n) {
        n.r(t);
        var a = n("05a8"), r = n.n(a);
        for (var o in a) [ "default" ].indexOf(o) < 0 && function(e) {
            n.d(t, e, function() {
                return a[e];
            });
        }(o);
        t.default = r.a;
    }
}, [ [ "658d", "common/runtime", "common/vendor" ] ] ]);