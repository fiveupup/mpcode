(global.webpackJsonp = global.webpackJsonp || []).push([ [ "pages/growth/growth" ], {
    "2b7d": function(n, t, e) {
        e.d(t, "b", function() {
            return o;
        }), e.d(t, "c", function() {
            return r;
        }), e.d(t, "a", function() {
            return a;
        });
        var a = {
            uLoadmore: function() {
                return e.e("node-modules/uview-ui/components/u-loadmore/u-loadmore").then(e.bind(null, "bf89"));
            }
        }, o = function() {
            var n = this, t = (n.$createElement, n._self._c, n.__map(n.listArray, function(t, e) {
                return {
                    $orig: n.__get_orig(t),
                    g0: t.pointValue < 0 || 2 == t.type ? Math.abs(t.pointValue) : null,
                    g1: t.pointValue < 0 || 2 == t.type ? null : Math.abs(t.pointValue)
                };
            }));
            n.$mp.data = Object.assign({}, {
                $root: {
                    l0: t
                }
            });
        }, r = [];
    },
    "55b4": function(n, t, e) {
        (function(n) {
            e("6cdc"), a(e("66fd"));
            var t = a(e("d951"));
            function a(n) {
                return n && n.__esModule ? n : {
                    default: n
                };
            }
            wx.__webpack_require_UNI_MP_PLUGIN__ = e, n(t.default);
        }).call(this, e("543d").createPage);
    },
    "64a7": function(n, t, e) {},
    "70ba": function(n, t, e) {
        (function(n) {
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = void 0;
            var a = function(n) {
                return n && n.__esModule ? n : {
                    default: n
                };
            }(e("4795")), o = e("7b12");
            function r(n, t, e, a, o, r, u) {
                try {
                    var i = n[r](u), c = i.value;
                } catch (n) {
                    return void e(n);
                }
                i.done ? t(c) : Promise.resolve(c).then(a, o);
            }
            function u(n) {
                return function() {
                    var t = this, e = arguments;
                    return new Promise(function(a, o) {
                        var u = n.apply(t, e);
                        function i(n) {
                            r(u, a, o, i, c, "next", n);
                        }
                        function c(n) {
                            r(u, a, o, i, c, "throw", n);
                        }
                        i(void 0);
                    });
                };
            }
            var i = {
                data: function() {
                    return {
                        point: "",
                        status: "nomore",
                        listArray: [],
                        loadText: {
                            loadmore: "加载更多",
                            loading: "努力加载中",
                            nomore: "没有更多了"
                        }
                    };
                },
                onShow: function() {
                    var n = this;
                    return u(a.default.mark(function t() {
                        var e;
                        return a.default.wrap(function(t) {
                            for (;;) switch (t.prev = t.next) {
                              case 0:
                                return t.next = 2, (0, o.getGrowthRecord)();

                              case 2:
                                e = t.sent, console.log("引力值列表", e), "00000" == e.data.code && (n.listArray = e.data.data), 
                                n.getOpenerEventChannel().on("acceptDataFromOpenerPage", function() {
                                    var t = u(a.default.mark(function t(e) {
                                        return a.default.wrap(function(t) {
                                            for (;;) switch (t.prev = t.next) {
                                              case 0:
                                                console.log("跳转传参-修改地址:", e.data.point), e.data.point && (n.point = e.data.point);

                                              case 2:
                                              case "end":
                                                return t.stop();
                                            }
                                        }, t);
                                    }));
                                    return function(n) {
                                        return t.apply(this, arguments);
                                    };
                                }());

                              case 7:
                              case "end":
                                return t.stop();
                            }
                        }, t);
                    }))();
                },
                methods: {
                    toAgreement: function(t) {
                        n.navigateTo({
                            url: "/pages/agreement/agreement?ruleType=" + t
                        });
                    }
                }
            };
            t.default = i;
        }).call(this, e("543d").default);
    },
    7386: function(n, t, e) {
        e.r(t);
        var a = e("70ba"), o = e.n(a);
        for (var r in a) [ "default" ].indexOf(r) < 0 && function(n) {
            e.d(t, n, function() {
                return a[n];
            });
        }(r);
        t.default = o.a;
    },
    d951: function(n, t, e) {
        e.r(t);
        var a = e("2b7d"), o = e("7386");
        for (var r in o) [ "default" ].indexOf(r) < 0 && function(n) {
            e.d(t, n, function() {
                return o[n];
            });
        }(r);
        e("e0dd");
        var u = e("f0c5"), i = Object(u.a)(o.default, a.b, a.c, !1, null, "eac09c32", null, !1, a.a, void 0);
        t.default = i.exports;
    },
    e0dd: function(n, t, e) {
        var a = e("64a7");
        e.n(a).a;
    }
}, [ [ "55b4", "common/runtime", "common/vendor" ] ] ]);