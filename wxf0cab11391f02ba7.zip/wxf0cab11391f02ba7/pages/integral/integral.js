(global.webpackJsonp = global.webpackJsonp || []).push([ [ "pages/integral/integral" ], {
    "42f7": function(t, e, n) {
        n.r(e);
        var r = n("69ed"), a = n.n(r);
        for (var o in r) [ "default" ].indexOf(o) < 0 && function(t) {
            n.d(e, t, function() {
                return r[t];
            });
        }(o);
        e.default = a.a;
    },
    "69ed": function(t, e, n) {
        (function(t) {
            Object.defineProperty(e, "__esModule", {
                value: !0
            }), e.default = void 0;
            var r = function(t) {
                return t && t.__esModule ? t : {
                    default: t
                };
            }(n("4795")), a = n("7b12");
            function o(t, e, n, r, a, o, u) {
                try {
                    var i = t[o](u), c = i.value;
                } catch (t) {
                    return void n(t);
                }
                i.done ? e(c) : Promise.resolve(c).then(r, a);
            }
            function u(t) {
                return function() {
                    var e = this, n = arguments;
                    return new Promise(function(r, a) {
                        var u = t.apply(e, n);
                        function i(t) {
                            o(u, r, a, i, c, "next", t);
                        }
                        function c(t) {
                            o(u, r, a, i, c, "throw", t);
                        }
                        i(void 0);
                    });
                };
            }
            var i = {
                data: function() {
                    return {
                        point: "",
                        status: "nomore",
                        listArray: [],
                        listArrayRecord: [],
                        loadText: {
                            loadmore: "加载更多",
                            loading: "努力加载中",
                            nomore: "没有更多了"
                        },
                        thisTab: 1
                    };
                },
                onShow: function() {
                    var t = this;
                    return u(r.default.mark(function e() {
                        return r.default.wrap(function(e) {
                            for (;;) switch (e.prev = e.next) {
                              case 0:
                                return e.next = 2, t.toTab(1);

                              case 2:
                                t.getOpenerEventChannel().on("acceptDataFromOpenerPage", function() {
                                    var e = u(r.default.mark(function e(n) {
                                        return r.default.wrap(function(e) {
                                            for (;;) switch (e.prev = e.next) {
                                              case 0:
                                                console.log("跳转传参-修改地址:", n.data.point), n.data.point && (t.point = n.data.point);

                                              case 2:
                                              case "end":
                                                return e.stop();
                                            }
                                        }, e);
                                    }));
                                    return function(t) {
                                        return e.apply(this, arguments);
                                    };
                                }());

                              case 4:
                              case "end":
                                return e.stop();
                            }
                        }, e);
                    }))();
                },
                methods: {
                    toAgreement: function(e) {
                        t.navigateTo({
                            url: "/pages/agreement/agreement?ruleType=" + e
                        });
                    },
                    toTab: function(t) {
                        this.thisTab = t, 1 == t && this.getPointRecordList(), 2 == t && this.getMemberFrozenPointsList();
                    },
                    getMemberFrozenPointsList: function() {
                        var t = this;
                        return u(r.default.mark(function e() {
                            var n, o, u, i;
                            return r.default.wrap(function(e) {
                                for (;;) switch (e.prev = e.next) {
                                  case 0:
                                    return e.next = 2, (0, a.getMemberFrozenPoints)();

                                  case 2:
                                    n = e.sent, o = n.data, u = o.code, i = o.data, "00000" == u && (t.listArrayRecord = i);

                                  case 7:
                                  case "end":
                                    return e.stop();
                                }
                            }, e);
                        }))();
                    },
                    getPointRecordList: function() {
                        var t = this;
                        return u(r.default.mark(function e() {
                            var n, o, u, i;
                            return r.default.wrap(function(e) {
                                for (;;) switch (e.prev = e.next) {
                                  case 0:
                                    return e.next = 2, (0, a.getPointRecord)();

                                  case 2:
                                    n = e.sent, o = n.data, u = o.code, i = o.data, console.log("积分列表", i), "00000" == u && (t.listArray = i);

                                  case 8:
                                  case "end":
                                    return e.stop();
                                }
                            }, e);
                        }))();
                    }
                }
            };
            e.default = i;
        }).call(this, n("543d").default);
    },
    7078: function(t, e, n) {
        (function(t) {
            n("6cdc"), r(n("66fd"));
            var e = r(n("b204"));
            function r(t) {
                return t && t.__esModule ? t : {
                    default: t
                };
            }
            wx.__webpack_require_UNI_MP_PLUGIN__ = n, t(e.default);
        }).call(this, n("543d").createPage);
    },
    "722a": function(t, e, n) {},
    9129: function(t, e, n) {
        n.d(e, "b", function() {
            return a;
        }), n.d(e, "c", function() {
            return o;
        }), n.d(e, "a", function() {
            return r;
        });
        var r = {
            uLoadmore: function() {
                return n.e("node-modules/uview-ui/components/u-loadmore/u-loadmore").then(n.bind(null, "bf89"));
            }
        }, a = function() {
            var t = this, e = (t.$createElement, t._self._c, 1 == t.thisTab ? t.__map(t.listArray, function(e, n) {
                return {
                    $orig: t.__get_orig(e),
                    g0: e.pointValue < 0 || 0 == e.type || 2 == e.type ? Math.abs(e.pointValue) : null,
                    g1: e.pointValue < 0 || 0 == e.type || 2 == e.type ? null : Math.abs(e.pointValue)
                };
            }) : null);
            t.$mp.data = Object.assign({}, {
                $root: {
                    l0: e
                }
            });
        }, o = [];
    },
    b114: function(t, e, n) {
        var r = n("722a");
        n.n(r).a;
    },
    b204: function(t, e, n) {
        n.r(e);
        var r = n("9129"), a = n("42f7");
        for (var o in a) [ "default" ].indexOf(o) < 0 && function(t) {
            n.d(e, t, function() {
                return a[t];
            });
        }(o);
        n("b114");
        var u = n("f0c5"), i = Object(u.a)(a.default, r.b, r.c, !1, null, "3c70cf76", null, !1, r.a, void 0);
        e.default = i.exports;
    }
}, [ [ "7078", "common/runtime", "common/vendor" ] ] ]);