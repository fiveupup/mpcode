(global.webpackJsonp = global.webpackJsonp || []).push([ [ "pages/activity/rule" ], {
    "0651": function(n, e, t) {
        t.r(e);
        var u = t("f252"), r = t.n(u);
        for (var a in u) [ "default" ].indexOf(a) < 0 && function(n) {
            t.d(e, n, function() {
                return u[n];
            });
        }(a);
        e.default = r.a;
    },
    "1f9d": function(n, e, t) {
        t.r(e);
        var u = t("8243"), r = t("0651");
        for (var a in r) [ "default" ].indexOf(a) < 0 && function(n) {
            t.d(e, n, function() {
                return r[n];
            });
        }(a);
        t("db41");
        var o = t("f0c5"), c = Object(o.a)(r.default, u.b, u.c, !1, null, "223a61ed", null, !1, u.a, void 0);
        e.default = c.exports;
    },
    "4a0e": function(n, e, t) {},
    8243: function(n, e, t) {
        t.d(e, "b", function() {
            return r;
        }), t.d(e, "c", function() {
            return a;
        }), t.d(e, "a", function() {
            return u;
        });
        var u = {
            uParse: function() {
                return Promise.all([ t.e("common/vendor"), t.e("node-modules/uview-ui/components/u-parse/u-parse") ]).then(t.bind(null, "492b"));
            }
        }, r = function() {
            this.$createElement;
            this._self._c;
        }, a = [];
    },
    c7c0: function(n, e, t) {
        (function(n) {
            t("6cdc"), u(t("66fd"));
            var e = u(t("1f9d"));
            function u(n) {
                return n && n.__esModule ? n : {
                    default: n
                };
            }
            wx.__webpack_require_UNI_MP_PLUGIN__ = t, n(e.default);
        }).call(this, t("543d").createPage);
    },
    db41: function(n, e, t) {
        var u = t("4a0e");
        t.n(u).a;
    },
    f252: function(n, e, t) {
        Object.defineProperty(e, "__esModule", {
            value: !0
        }), e.default = void 0;
        var u = {
            data: function() {
                return {
                    content: "",
                    style: {
                        ".ql-align-right": "text-align: right;",
                        ".ql-align-center": "text-align: center;"
                    }
                };
            },
            onLoad: function(n) {
                var e = getCurrentPages(), t = e[e.length - 2];
                this.content = t.data.ruleDescription;
            }
        };
        e.default = u;
    }
}, [ [ "c7c0", "common/runtime", "common/vendor" ] ] ]);