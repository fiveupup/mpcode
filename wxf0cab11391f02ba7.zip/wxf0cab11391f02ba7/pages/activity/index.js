require("../../@babel/runtime/helpers/Arrayincludes"), (global.webpackJsonp = global.webpackJsonp || []).push([ [ "pages/activity/index" ], {
    5215: function(e, t, n) {
        n.r(t);
        var i = n("6282"), a = n.n(i);
        for (var o in i) [ "default" ].indexOf(o) < 0 && function(e) {
            n.d(t, e, function() {
                return i[e];
            });
        }(o);
        t.default = a.a;
    },
    6282: function(e, t, n) {
        (function(e) {
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = void 0;
            var i = function(e) {
                return e && e.__esModule ? e : {
                    default: e
                };
            }(n("4795")), a = n("2132"), o = n("d1f8"), c = n("403a");
            function r(e, t, n, i, a, o, c) {
                try {
                    var r = e[o](c), s = r.value;
                } catch (e) {
                    return void n(e);
                }
                r.done ? t(s) : Promise.resolve(s).then(i, a);
            }
            function s(e) {
                return function() {
                    var t = this, n = arguments;
                    return new Promise(function(i, a) {
                        var o = e.apply(t, n);
                        function c(e) {
                            r(o, i, a, c, s, "next", e);
                        }
                        function s(e) {
                            r(o, i, a, c, s, "throw", e);
                        }
                        c(void 0);
                    });
                };
            }
            var d = {
                data: function() {
                    return {
                        isLoginBack: !1,
                        code_ticket: "",
                        id: "",
                        activityCodeType: 0,
                        activityBackImgTop: "",
                        activityBackImgSign: "",
                        activityBackImgRule: "",
                        scanCount: 0,
                        records: [],
                        ruleDescription: "",
                        dialogVisible: !1,
                        jumpInfo: {
                            jumpType: null,
                            appId: "",
                            activityGuideUrl: "",
                            articleId: "",
                            awardPictureUrl: ""
                        },
                        title: "",
                        msg: "",
                        toAddr: !1,
                        keyCode: "",
                        codeActivityQrcodeId: "",
                        isOpenPrivacy: !1,
                        checked: !1
                    };
                },
                onLoad: function(e) {
                    console.log("扫码参数：", e), this.code_ticket = e.code_ticket, this.code_ticket ? this.scanQrcode() : (this.id = e.id, 
                    this.loadDetailData(!1));
                },
                onShow: function() {
                    this.isLoginBack && this.scanQrcode();
                },
                methods: {
                    handleAgreePrivacy: function() {
                        e.showLoading({
                            title: "加载中..."
                        }), this.isOpenPrivacy = !1, this.scanAction(this.keyCode, this.codeActivityQrcodeId);
                    },
                    scanQrcode: function() {
                        var t = this;
                        return s(i.default.mark(function n() {
                            var o, c, r, s, d, u, l;
                            return i.default.wrap(function(n) {
                                for (;;) switch (n.prev = n.next) {
                                  case 0:
                                    if (!(o = (o = e.getStorageSync("loginData2")) ? JSON.parse(o) : {}).openId) {
                                        n.next = 37;
                                        break;
                                    }
                                    return t.isLoginBack = !1, e.showLoading({
                                        title: "加载中..."
                                    }), n.next = 7, (0, a.ticket2code)(o.openId, t.code_ticket);

                                  case 7:
                                    if (c = n.sent, r = c.data, console.log(r), "00000" === r.code) {
                                        n.next = 17;
                                        break;
                                    }
                                    e.hideLoading(), t.title = "提示", t.msg = r.message, t.dialogVisible = !0, n.next = 35;
                                    break;

                                  case 17:
                                    return t.id = r.data.codeActivityId, s = r.data.keyCode, d = r.data.qrcodeId, n.next = 22, 
                                    (0, a.canJoin)({
                                        keyCode: s,
                                        codeActivityQrcodeId: d
                                    });

                                  case 22:
                                    if (u = n.sent, l = u.data, console.log("canJoin", l), "00000" !== l.code || null !== l.data) {
                                        n.next = 30;
                                        break;
                                    }
                                    return n.next = 28, t.scanAction(s, d);

                                  case 28:
                                    n.next = 35;
                                    break;

                                  case 30:
                                    t.keyCode = s, t.codeActivityQrcodeId = d, t.ruleDescription = l.data, e.hideLoading(), 
                                    t.isOpenPrivacy = !0;

                                  case 35:
                                    n.next = 40;
                                    break;

                                  case 37:
                                    t.$nextTick(function() {
                                        t.isLoginBack = !0;
                                    }), getApp().globalData.isBack = !0, e.navigateTo({
                                        url: "/pages/login/login"
                                    });

                                  case 40:
                                  case "end":
                                    return n.stop();
                                }
                            }, n);
                        }))();
                    },
                    scanAction: function(t, n) {
                        var o = this;
                        return s(i.default.mark(function c() {
                            var r, s;
                            return i.default.wrap(function(i) {
                                for (;;) switch (i.prev = i.next) {
                                  case 0:
                                    return i.next = 2, (0, a.scan)({
                                        keyCode: t,
                                        codeActivityQrcodeId: n
                                    });

                                  case 2:
                                    if (r = i.sent, s = r.data, console.log("scan", s), "00000" !== s.code) {
                                        i.next = 10;
                                        break;
                                    }
                                    return i.next = 8, o.loadDetailData(!0);

                                  case 8:
                                    i.next = 15;
                                    break;

                                  case 10:
                                    "01002" === s.code && (o.toAddr = !0), e.hideLoading(), o.title = "提示", o.msg = s.message, 
                                    o.dialogVisible = !0;

                                  case 15:
                                  case "end":
                                    return i.stop();
                                }
                            }, c);
                        }))();
                    },
                    loadDetailData: function(t) {
                        var n = this;
                        return s(i.default.mark(function c() {
                            var r, s, d, u, l, f;
                            return i.default.wrap(function(i) {
                                for (;;) switch (i.prev = i.next) {
                                  case 0:
                                    return i.next = 2, (0, a.getCodeActivity)(n.id);

                                  case 2:
                                    if (r = i.sent, console.log(r.data.data), s = r.data.data, n.activityBackImgTop = s.activityBackImgTop, 
                                    n.activityBackImgSign = s.activityBackImgSign, n.activityBackImgRule = s.activityBackImgRule, 
                                    n.ruleDescription = s.ruleDescription, n.activityCodeType = s.activityCodeType, 
                                    1 !== s.activityCodeType) {
                                        i.next = 20;
                                        break;
                                    }
                                    return i.next = 13, (0, o.getMemberPoint)();

                                  case 13:
                                    d = i.sent, u = d.data, n.scanCount = u.data.availableQuantity, e.hideLoading(), 
                                    t && (n.title = "扫码成功", n.msg = "积星已发放至您的账号中", n.jumpInfo = {
                                        jumpType: null
                                    }, n.dialogVisible = !0), i.next = 28;
                                    break;

                                  case 20:
                                    s.userCodeActivityRuleList.sort(function(e, t) {
                                        return t.actionCount - e.actionCount;
                                    }), l = s.userCodeActivityRuleList[0].actionCount, n.scanCount = s.codeActivityRecordList.length, 
                                    n.records = Array.from(Array(l).fill(0), function(e, t) {
                                        return {
                                            icon: n.scanCount > t ? "done" : "normal",
                                            msg: ""
                                        };
                                    }), f = [], s.userCodeActivityRuleList.forEach(function(e, t) {
                                        var i = "";
                                        if ("POINT" === e.gift) {
                                            var a = JSON.parse(e.pointJson);
                                            i = "金土豆*".concat(a.quantity);
                                        } else if ("COUPON" === e.gift) {
                                            var o = JSON.parse(e.couponJson);
                                            if (o.couponList.length > 0) {
                                                var c = o.couponList[0];
                                                c.couponName.length > 5 && (c.couponName = c.couponName.slice(0, 4) + "..."), i = "".concat(c.couponName, "*").concat(c.quantity);
                                            } else e.gift = "normal";
                                        } else if ("GOODS" === e.gift) {
                                            var r = JSON.parse(e.goodsJson);
                                            if (r.goodsList.length > 0) {
                                                var s = r.goodsList[0];
                                                s.goodsName.length > 5 && (s.goodsName = s.goodsName.slice(0, 4) + "..."), i = "".concat(s.goodsName, "*").concat(s.quantity);
                                            } else e.gift = "normal";
                                        } else if ("MEDAL" === e.gift) {
                                            var d = JSON.parse(e.medalJson);
                                            if (d.medalList.length > 0) {
                                                var u = d.medalList[0];
                                                u.name.length > 5 && (u.name = u.name.slice(0, 4) + "..."), i = "【勋章】";
                                            } else e.gift = "normal";
                                        }
                                        "normal" !== e.gift && f.push(e.actionCount), n.records[e.actionCount - 1] = {
                                            icon: "done" === n.records[e.actionCount - 1].icon ? "done" : e.gift.toLocaleLowerCase(),
                                            msg: i
                                        };
                                    }), e.hideLoading(), t && (console.log(f, n.scanCount), f.includes(n.scanCount) ? (n.title = "领取成功", 
                                    n.jumpInfo = s.userCodeActivityRuleList && s.userCodeActivityRuleList.find(function(e) {
                                        return e.actionCount === n.scanCount;
                                    }), n.msg = "对应的奖励已发放至您的账号", n.dialogVisible = !0) : (console.log("扫码成功 toast"), 
                                    e.showToast({
                                        title: "扫码成功",
                                        icon: "none"
                                    })));

                                  case 28:
                                  case "end":
                                    return i.stop();
                                }
                            }, c);
                        }))();
                    },
                    jumpToRule: function() {
                        e.navigateTo({
                            url: "/pages/activity/rule"
                        });
                    },
                    disposeJump: function() {
                        console.log("jumpInfo: ", this.jumpInfo);
                        var t = this.jumpInfo, n = t.jumpType, i = t.appId, a = t.activityGuideUrl, o = t.articleId;
                        0 === n ? e.navigateTo({
                            url: "/pages/webview/index?url=" + a
                        }) : 1 === n ? i === c.APPID ? [ "/pages/index/index", "/pages/gift/gift", "/pages/team/team" ].includes(a) ? e.switchTab({
                            url: a
                        }) : e.navigateTo({
                            url: a
                        }) : wx.navigateToMiniProgram({
                            appId: i,
                            path: a,
                            envVersion: "release",
                            success: function(e) {
                                console.log("跳转小程序成功");
                            }
                        }) : 2 === n && e.navigateTo({
                            url: "/pages/team_detail/team_detail?id=" + o
                        }), this.dialogVisible = !1;
                    },
                    goExchange: function() {
                        e.navigateTo({
                            url: "/pages/mall/exchange"
                        });
                    },
                    goAddr: function() {
                        var t = this;
                        this.dialogVisible = !1, this.$nextTick(function() {
                            t.toAddr = !1, t.isLoginBack = !0;
                        }), e.navigateTo({
                            url: "/pages/address_add/address_add",
                            success: function(e) {
                                e.eventChannel.emit("acceptDataFromOpenerPage", {
                                    data: "test"
                                });
                            }
                        });
                    },
                    goHome: function() {
                        this.dialogVisible = !1, e.reLaunch({
                            url: "/pages/index/index"
                        });
                    }
                }
            };
            t.default = d;
        }).call(this, n("543d").default);
    },
    "6e23": function(e, t, n) {
        var i = n("8743");
        n.n(i).a;
    },
    8063: function(e, t, n) {
        n.r(t);
        var i = n("d4e6"), a = n("5215");
        for (var o in a) [ "default" ].indexOf(o) < 0 && function(e) {
            n.d(t, e, function() {
                return a[e];
            });
        }(o);
        n("6e23");
        var c = n("f0c5"), r = Object(c.a)(a.default, i.b, i.c, !1, null, "09f027c5", null, !1, i.a, void 0);
        t.default = r.exports;
    },
    8743: function(e, t, n) {},
    b905: function(e, t, n) {
        (function(e) {
            n("6cdc"), i(n("66fd"));
            var t = i(n("8063"));
            function i(e) {
                return e && e.__esModule ? e : {
                    default: e
                };
            }
            wx.__webpack_require_UNI_MP_PLUGIN__ = n, e(t.default);
        }).call(this, n("543d").createPage);
    },
    d4e6: function(e, t, n) {
        n.d(t, "b", function() {
            return a;
        }), n.d(t, "c", function() {
            return o;
        }), n.d(t, "a", function() {
            return i;
        });
        var i = {
            uMask: function() {
                return n.e("node-modules/uview-ui/components/u-mask/u-mask").then(n.bind(null, "f0fd"));
            }
        }, a = function() {
            var e = this;
            e.$createElement;
            e._self._c, e._isMounted || (e.e0 = function(t) {
                e.checked = !e.checked;
            });
        }, o = [];
    }
}, [ [ "b905", "common/runtime", "common/vendor" ] ] ]);