(global.webpackJsonp = global.webpackJsonp || []).push([ [ "pages/webview/index" ], {
    "6a95": function(n, e, t) {
        t.d(e, "b", function() {
            return u;
        }), t.d(e, "c", function() {
            return c;
        }), t.d(e, "a", function() {});
        var u = function() {
            this.$createElement;
            this._self._c;
        }, c = [];
    },
    "9edb": function(n, e, t) {
        (function(n) {
            t("6cdc"), u(t("66fd"));
            var e = u(t("c18c"));
            function u(n) {
                return n && n.__esModule ? n : {
                    default: n
                };
            }
            wx.__webpack_require_UNI_MP_PLUGIN__ = t, n(e.default);
        }).call(this, t("543d").createPage);
    },
    c18c: function(n, e, t) {
        t.r(e);
        var u = t("6a95"), c = t("c984");
        for (var o in c) [ "default" ].indexOf(o) < 0 && function(n) {
            t.d(e, n, function() {
                return c[n];
            });
        }(o);
        var r = t("f0c5"), a = Object(r.a)(c.default, u.b, u.c, !1, null, null, null, !1, u.a, void 0);
        e.default = a.exports;
    },
    c984: function(n, e, t) {
        t.r(e);
        var u = t("d6b8"), c = t.n(u);
        for (var o in u) [ "default" ].indexOf(o) < 0 && function(n) {
            t.d(e, n, function() {
                return u[n];
            });
        }(o);
        e.default = c.a;
    },
    d6b8: function(n, e, t) {
        Object.defineProperty(e, "__esModule", {
            value: !0
        }), e.default = void 0;
        var u = {
            data: function() {
                return {
                    url: ""
                };
            },
            onLoad: function(n) {
                this.url = decodeURIComponent(n.url), console.log("h5: ", this.url);
            }
        };
        e.default = u;
    }
}, [ [ "9edb", "common/runtime", "common/vendor" ] ] ]);