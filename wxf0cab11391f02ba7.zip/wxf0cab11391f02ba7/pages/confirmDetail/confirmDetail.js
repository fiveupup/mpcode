(global.webpackJsonp = global.webpackJsonp || []).push([ [ "pages/confirmDetail/confirmDetail" ], {
    "00b7": function(t, e, i) {
        i.d(e, "b", function() {
            return o;
        }), i.d(e, "c", function() {
            return s;
        }), i.d(e, "a", function() {
            return a;
        });
        var a = {
            uMask: function() {
                return i.e("node-modules/uview-ui/components/u-mask/u-mask").then(i.bind(null, "f0fd"));
            },
            uToast: function() {
                return i.e("node-modules/uview-ui/components/u-toast/u-toast").then(i.bind(null, "446f"));
            }
        }, o = function() {
            var t = this, e = (t.$createElement, t._self._c, t.__map(t.list, function(e, i) {
                return {
                    $orig: t.__get_orig(e),
                    g0: e.goodsImg.split(",")
                };
            }));
            t._isMounted || (t.e0 = function(e, i) {
                for (var a = [], o = arguments.length - 2; o-- > 0; ) a[o] = arguments[o + 2];
                var s = a[a.length - 1].currentTarget.dataset, n = s.eventParams || s["event-params"];
                return i = n.index, t.inputCount(e, i);
            }, t.e1 = function(e) {
                t.show = !1;
            }, t.e2 = function(e) {
                return e.stopPropagation(), t.addOrder(e);
            }), t.$mp.data = Object.assign({}, {
                $root: {
                    l0: e
                }
            });
        }, s = [];
    },
    "2ce2": function(t, e, i) {
        i.r(e);
        var a = i("a652"), o = i.n(a);
        for (var s in a) [ "default" ].indexOf(s) < 0 && function(t) {
            i.d(e, t, function() {
                return a[t];
            });
        }(s);
        e.default = o.a;
    },
    "83b6": function(t, e, i) {
        (function(t) {
            i("6cdc"), a(i("66fd"));
            var e = a(i("ec67"));
            function a(t) {
                return t && t.__esModule ? t : {
                    default: t
                };
            }
            wx.__webpack_require_UNI_MP_PLUGIN__ = i, t(e.default);
        }).call(this, i("543d").createPage);
    },
    "8b94": function(t, e, i) {},
    a652: function(t, e, i) {
        (function(t) {
            Object.defineProperty(e, "__esModule", {
                value: !0
            }), e.default = void 0;
            var a = i("7b12"), o = i("830d"), s = i("d1f8");
            function n(t, e) {
                var i = Object.keys(t);
                if (Object.getOwnPropertySymbols) {
                    var a = Object.getOwnPropertySymbols(t);
                    e && (a = a.filter(function(e) {
                        return Object.getOwnPropertyDescriptor(t, e).enumerable;
                    })), i.push.apply(i, a);
                }
                return i;
            }
            function r(t, e, i) {
                return e in t ? Object.defineProperty(t, e, {
                    value: i,
                    enumerable: !0,
                    configurable: !0,
                    writable: !0
                }) : t[e] = i, t;
            }
            var d = {
                data: function() {
                    return {
                        type: "point",
                        hasDetail: !1,
                        show: !1,
                        limitMaxBuyQuota: 0,
                        member: {},
                        canDuiHuan: !1,
                        list: [],
                        address: {},
                        integral_point: 0,
                        chooseAddressBack: !1
                    };
                },
                onLoad: function(e) {
                    var i = this;
                    console.log("options", e), this.type = e.type;
                    var o = t.getStorageSync("loginData2");
                    this.member = o ? JSON.parse(o) : {}, (0, a.findDefaultAddress)().then(function(t) {
                        if (t.data.data) {
                            var e = t.data.data;
                            i.address = t.data.data, i.address.deliveryAddress = "".concat(e.provinceName).concat(e.cityName).concat(e.areaName).concat(e.streetName || "").concat(e.deliveryAddress), 
                            i.hasDetail = !0;
                        } else i.$refs.uToast.show({
                            title: "请选择地址！",
                            type: "info"
                        }), i.hasDetail = !1;
                    }), "point" === this.type ? this.loadPointData(e) : this.loadExchangeData(e);
                },
                methods: {
                    loadPointData: function(t) {
                        var e = this;
                        (0, o.getMemberPoint)().then(function(t) {
                            console.log(t.data), e.integral_point = t.data.data;
                        }), "YES" == t.limitBuy && (0, o.getGoodsLimitSales)({
                            goodsId: t.id,
                            memberNo: this.member.memberNo
                        }).then(function(t) {
                            console.log(t.data, 222), e.limitMaxBuyQuota = t.data.data;
                        }), (0, o.getGoodDetail)({
                            id: t.id
                        }).then(function(t) {
                            console.log(t.data.data, "detail");
                            var i = t.data.data;
                            i.count = 1, e.list = [], e.list.push(i);
                        });
                    },
                    loadExchangeData: function(t) {
                        var e = this;
                        (0, s.getMemberPoint)().then(function(t) {
                            var i;
                            console.log(t.data), e.integral_point = (null === (i = t.data.data) || void 0 === i ? void 0 : i.availableQuantity) || 0;
                        }), "YES" == t.limitBuy && (0, s.getGoodsLimitSales)({
                            goodsId: t.id,
                            memberNo: this.member.memberNo
                        }).then(function(t) {
                            console.log(t.data, 222), e.limitMaxBuyQuota = t.data.data;
                        }), (0, s.getGoodDetail)({
                            id: t.id
                        }).then(function(t) {
                            console.log(t.data.data, "detail");
                            var i = t.data.data;
                            i.count = 1, e.list = [], e.list.push(i);
                        });
                    },
                    rase: function(t) {
                        1 != this.list[t].count && this.list[t].count--;
                    },
                    add: function(t) {
                        this.list[t].count != this.list[0].goodsQuantity ? this.list[t].count++ : this.$refs.uToast.show({
                            title: "兑换数量已等于商品库存，无法再添加！",
                            type: "error"
                        });
                    },
                    inputCount: function(t, e) {
                        var i = this;
                        if (t.detail.value) if (Number(t.detail.value) + "" != "NaN") if (t.detail.value - 0 >= this.list[0].goodsQuantity) {
                            this.$refs.uToast.show({
                                title: "兑换数量已等于商品库存，无法再添加！",
                                type: "error"
                            });
                            var a = setTimeout(function(t) {
                                i.list[e].count = i.list[0].goodsQuantity - 0, clearTimeout(a), a = null;
                            }, 100);
                        } else this.list[e].count = t.detail.value, console.log(this.list[e].count, "this.list[index].count"); else {
                            this.$refs.uToast.show({
                                title: "请输入数字",
                                type: "error"
                            });
                            var o = setTimeout(function(t) {
                                i.list[e].count = 1, clearTimeout(o), o = null;
                            }, 100);
                        } else var s = setTimeout(function(t) {
                            i.list[e].count = 1, clearTimeout(s), s = null;
                        }, 100);
                    },
                    showModal: function() {
                        var t;
                        (console.log("确认兑换 click"), this.address.deliveryAddressId) ? this.list[0].count * this.list[0].exchangePoint > this.integral_point ? this.$refs.uToast.show({
                            title: "当前金土豆不足！",
                            type: "error"
                        }) : ("YES" == this.list[0].limitBuy ? (t = this.limitMaxBuyQuota ? this.list[0].limitBuyQuota < this.limitMaxBuyQuota ? this.list[0].limitBuyQuota : this.limitMaxBuyQuota : this.list[0].limitBuyQuota, 
                        console.log(this.list[0].limitBuyQuota, this.limitMaxBuyQuota, t, this.list[0].count), 
                        t < this.list[0].count ? this.$refs.uToast.show({
                            title: "购买数量大于可购数！"
                        }) : this.show = !0) : this.show = !0, console.log("确认兑换 dialog show: ", this.show)) : this.$refs.uToast.show({
                            title: "请选择地址！",
                            type: "info"
                        });
                    },
                    addOrder: function() {
                        var e = this;
                        console.log({
                            addressId: this.address.deliveryAddressId,
                            goodsId: this.list[0].id,
                            memberNo: this.member.memberNo,
                            quantity: this.list[0].count
                        }), t.showLoading({
                            title: "兑换中...",
                            mask: !0
                        });
                        var i = {
                            addressId: this.address.deliveryAddressId,
                            goodsId: this.list[0].id,
                            memberNo: this.member.memberNo,
                            quantity: this.list[0].count
                        };
                        ("point" === this.type ? (0, o.createOrder)(i) : (0, s.createOrder)(i)).then(function(i) {
                            t.hideLoading(), "00000" == i.data.data.code ? (e.show = !1, e.$refs.uToast.show({
                                title: "兑换成功！",
                                type: "success"
                            }), e.gotoPage("/pages/mallOrder/mallOrder?type=".concat(e.type), !0)) : e.$refs.uToast.show({
                                title: i.data.data.message,
                                type: "error"
                            });
                        }).catch(function(e) {
                            t.hideLoading();
                        });
                    },
                    chooseAddress: function() {
                        wx.navigateTo({
                            url: "/pages/address/address?chooseAddr=1"
                        });
                    },
                    onShow: function() {
                        this.chooseAddressBack && (this.chooseAddressBack = !1, this.address = function(t) {
                            for (var e = 1; e < arguments.length; e++) {
                                var i = null != arguments[e] ? arguments[e] : {};
                                e % 2 ? n(Object(i), !0).forEach(function(e) {
                                    r(t, e, i[e]);
                                }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(t, Object.getOwnPropertyDescriptors(i)) : n(Object(i)).forEach(function(e) {
                                    Object.defineProperty(t, e, Object.getOwnPropertyDescriptor(i, e));
                                });
                            }
                            return t;
                        }({}, this.address), this.address.deliveryAddress = "".concat(this.address.provinceName).concat(this.address.cityName).concat(this.address.areaName).concat(this.address.streetName || "").concat(this.address.deliveryAddress), 
                        this.hasDetail = !0, console.log("选择地址后返回这里"));
                    },
                    gotoPage: function(t) {
                        var e = arguments.length > 1 && void 0 !== arguments[1] && arguments[1];
                        console.log("页面跳转"), e ? wx.redirectTo({
                            url: t,
                            success: function(t) {
                                t.eventChannel.emit("acceptDataFromOpenerPage", {
                                    data: "test"
                                });
                            }
                        }) : wx.navigateTo({
                            url: t,
                            success: function(t) {
                                t.eventChannel.emit("acceptDataFromOpenerPage", {
                                    data: "test"
                                });
                            }
                        });
                    }
                }
            };
            e.default = d;
        }).call(this, i("543d").default);
    },
    ec67: function(t, e, i) {
        i.r(e);
        var a = i("00b7"), o = i("2ce2");
        for (var s in o) [ "default" ].indexOf(s) < 0 && function(t) {
            i.d(e, t, function() {
                return o[t];
            });
        }(s);
        i("fe86");
        var n = i("f0c5"), r = Object(n.a)(o.default, a.b, a.c, !1, null, "35bfbe70", null, !1, a.a, void 0);
        e.default = r.exports;
    },
    fe86: function(t, e, i) {
        var a = i("8b94");
        i.n(a).a;
    }
}, [ [ "83b6", "common/runtime", "common/vendor" ] ] ]);