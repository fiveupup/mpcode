(global.webpackJsonp = global.webpackJsonp || []).push([ [ "pages/voting/record" ], {
    3191: function(n, t, e) {
        var r = e("efb7");
        e.n(r).a;
    },
    "46fb": function(n, t, e) {
        e.r(t);
        var r = e("7eee"), o = e("f610");
        for (var a in o) [ "default" ].indexOf(a) < 0 && function(n) {
            e.d(t, n, function() {
                return o[n];
            });
        }(a);
        e("3191");
        var u = e("f0c5"), i = Object(u.a)(o.default, r.b, r.c, !1, null, "1404593f", null, !1, r.a, void 0);
        t.default = i.exports;
    },
    7529: function(n, t, e) {
        (function(n) {
            e("6cdc"), r(e("66fd"));
            var t = r(e("46fb"));
            function r(n) {
                return n && n.__esModule ? n : {
                    default: n
                };
            }
            wx.__webpack_require_UNI_MP_PLUGIN__ = e, n(t.default);
        }).call(this, e("543d").createPage);
    },
    "7eee": function(n, t, e) {
        e.d(t, "b", function() {
            return r;
        }), e.d(t, "c", function() {
            return o;
        }), e.d(t, "a", function() {});
        var r = function() {
            this.$createElement;
            this._self._c;
        }, o = [];
    },
    edf1: function(n, t, e) {
        Object.defineProperty(t, "__esModule", {
            value: !0
        }), t.default = void 0;
        var r = function(n) {
            return n && n.__esModule ? n : {
                default: n
            };
        }(e("4795")), o = e("365c");
        function a(n, t, e, r, o, a, u) {
            try {
                var i = n[a](u), c = i.value;
            } catch (n) {
                return void e(n);
            }
            i.done ? t(c) : Promise.resolve(c).then(r, o);
        }
        var u = {
            name: "voting-record",
            data: function() {
                return {
                    articleId: 0,
                    votingId: 0,
                    recordList: []
                };
            },
            onLoad: function(n) {
                this.articleId = n.articleId, this.votingId = n.votingId, this.loadData();
            },
            methods: {
                loadData: function() {
                    var n = this;
                    return function(n) {
                        return function() {
                            var t = this, e = arguments;
                            return new Promise(function(r, o) {
                                var u = n.apply(t, e);
                                function i(n) {
                                    a(u, r, o, i, c, "next", n);
                                }
                                function c(n) {
                                    a(u, r, o, i, c, "throw", n);
                                }
                                i(void 0);
                            });
                        };
                    }(r.default.mark(function t() {
                        var e, a;
                        return r.default.wrap(function(t) {
                            for (;;) switch (t.prev = t.next) {
                              case 0:
                                return t.next = 2, (0, o.winList)(n.votingId);

                              case 2:
                                e = t.sent, a = e.data, n.recordList = a.data;

                              case 5:
                              case "end":
                                return t.stop();
                            }
                        }, t);
                    }))();
                }
            }
        };
        t.default = u;
    },
    efb7: function(n, t, e) {},
    f610: function(n, t, e) {
        e.r(t);
        var r = e("edf1"), o = e.n(r);
        for (var a in r) [ "default" ].indexOf(a) < 0 && function(n) {
            e.d(t, n, function() {
                return r[n];
            });
        }(a);
        t.default = o.a;
    }
}, [ [ "7529", "common/runtime", "common/vendor" ] ] ]);