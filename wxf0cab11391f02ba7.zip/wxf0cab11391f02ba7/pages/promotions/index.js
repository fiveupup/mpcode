require("../../@babel/runtime/helpers/Arrayincludes"), (global.webpackJsonp = global.webpackJsonp || []).push([ [ "pages/promotions/index" ], {
    1734: function(e, t, n) {},
    1996: function(e, t, n) {
        (function(e) {
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = void 0;
            var a = function(e) {
                return e && e.__esModule ? e : {
                    default: e
                };
            }(n("66fd")), i = n("403a"), o = n("7b12");
            var u = a.default.extend({
                name: "PromotionList",
                data: function() {
                    return {
                        promotions: [],
                        tabList: [ "当前活动", "历史活动" ],
                        activeIndex: 0
                    };
                },
                watch: {
                    activeIndex: {
                        handler: function(e) {
                            this.nextPage = 1, this.promotions = [], this.getPromotions(e);
                        },
                        immediate: !0
                    }
                },
                methods: {
                    selectTab: function(e) {
                        this.activeIndex = e;
                    },
                    getPromotions: function(e) {
                        var t = this;
                        (0, o.activityList)("ACTIVITY", 0 !== e).then(function(e) {
                            var n = e.data;
                            t.promotions = n.data;
                        });
                    },
                    navigateTo: function(e) {
                        var t = e.jumpType, n = e.appId, a = e.activityGuideUrl, i = e.articleId;
                        this._jump({
                            jumpType: t,
                            appId: n,
                            guideUrl: a,
                            articleId: i
                        });
                    },
                    _jump: function(t) {
                        var n = t.jumpType, a = t.appId, o = t.guideUrl, u = t.articleId;
                        0 === n ? e.navigateTo({
                            url: "/pages/webview/index?url=" + encodeURIComponent(o)
                        }) : 1 === n ? a === i.APPID ? [ "/pages/index/index", "/pages/gift/gift", "/pages/team/team" ].includes(o) ? e.switchTab({
                            url: o
                        }) : e.navigateTo({
                            url: o
                        }) : wx.navigateToMiniProgram({
                            appId: a,
                            path: o,
                            envVersion: "release",
                            success: function(e) {
                                console.log("跳转小程序成功");
                            }
                        }) : 2 === n && e.navigateTo({
                            url: "/pages/team_detail/team_detail?id=" + u
                        });
                    }
                }
            });
            t.default = u;
        }).call(this, n("543d").default);
    },
    "2add": function(e, t, n) {
        (function(e) {
            n("6cdc"), a(n("66fd"));
            var t = a(n("a20b"));
            function a(e) {
                return e && e.__esModule ? e : {
                    default: e
                };
            }
            wx.__webpack_require_UNI_MP_PLUGIN__ = n, e(t.default);
        }).call(this, n("543d").createPage);
    },
    a20b: function(e, t, n) {
        n.r(t);
        var a = n("b33a"), i = n("a2f7");
        for (var o in i) [ "default" ].indexOf(o) < 0 && function(e) {
            n.d(t, e, function() {
                return i[e];
            });
        }(o);
        n("a3e6");
        var u = n("f0c5"), r = Object(u.a)(i.default, a.b, a.c, !1, null, "8e8ab300", null, !1, a.a, void 0);
        t.default = r.exports;
    },
    a2f7: function(e, t, n) {
        n.r(t);
        var a = n("1996"), i = n.n(a);
        for (var o in a) [ "default" ].indexOf(o) < 0 && function(e) {
            n.d(t, e, function() {
                return a[e];
            });
        }(o);
        t.default = i.a;
    },
    a3e6: function(e, t, n) {
        var a = n("1734");
        n.n(a).a;
    },
    b33a: function(e, t, n) {
        n.d(t, "b", function() {
            return a;
        }), n.d(t, "c", function() {
            return i;
        }), n.d(t, "a", function() {});
        var a = function() {
            this.$createElement;
            this._self._c;
        }, i = [];
    }
}, [ [ "2add", "common/runtime", "common/vendor" ] ] ]);