(global.webpackJsonp = global.webpackJsonp || []).push([ [ "pages/gift/gift" ], {
    2476: function(n, t, e) {},
    "2a28": function(n, t, e) {
        (function(n) {
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = void 0;
            var a = u(e("4795")), o = u(e("05b9")), i = e("40a4");
            function u(n) {
                return n && n.__esModule ? n : {
                    default: n
                };
            }
            function r(n, t, e, a, o, i, u) {
                try {
                    var r = n[i](u), c = r.value;
                } catch (n) {
                    return void e(n);
                }
                r.done ? t(c) : Promise.resolve(c).then(a, o);
            }
            function c(n) {
                return function() {
                    var t = this, e = arguments;
                    return new Promise(function(a, o) {
                        var i = n.apply(t, e);
                        function u(n) {
                            r(i, a, o, u, c, "next", n);
                        }
                        function c(n) {
                            r(i, a, o, u, c, "throw", n);
                        }
                        u(void 0);
                    });
                };
            }
            var l = {
                components: {
                    tabbar: function() {
                        Promise.all([ e.e("common/vendor"), e.e("components/tabbar") ]).then(function() {
                            return resolve(e("26fc"));
                        }.bind(null, e)).catch(e.oe);
                    }
                },
                data: function() {
                    return {
                        channelOptions: [],
                        activeIndex: 0,
                        loginData: {},
                        loadStatus: "nomore",
                        loadText: {
                            loadmore: "加载更多",
                            loading: "努力加载中",
                            nomore: "没有更多了"
                        },
                        dataList: [],
                        param: {
                            pageNum: 1,
                            pageSize: 10,
                            channelNo: ""
                        }
                    };
                },
                watch: {
                    activeIndex: {
                        handler: function(n) {
                            this.dataList.length = 0, this.param.pageNum = 1;
                            var t = this.channelOptions[n];
                            this.param.channelNo = null == t ? void 0 : t.channelNo, this.getList();
                        },
                        immediate: !0
                    }
                },
                onShow: function() {
                    var t = n.getStorageSync("loginData2");
                    this.loginData = t ? JSON.parse(t) : {}, this.getChannelOptions();
                },
                onReachBottom: function() {
                    "nomore" !== this.loadStatus && (this.param.pageNum += 1, this.getList());
                },
                methods: {
                    selectTab: function(n) {
                        this.activeIndex = n;
                    },
                    getChannelOptions: function() {
                        var n = this;
                        return c(a.default.mark(function t() {
                            var e, o, u;
                            return a.default.wrap(function(t) {
                                for (;;) switch (t.prev = t.next) {
                                  case 0:
                                    return t.next = 2, (0, i.channelList)();

                                  case 2:
                                    e = t.sent, o = e.data, (u = o.data.map(function(n) {
                                        return "YOU_ZAN" === n.channelNo && (n.channelName = "心动商城"), n;
                                    })).unshift({
                                        channelName: "全部",
                                        channelNo: ""
                                    }), n.channelOptions = u;

                                  case 7:
                                  case "end":
                                    return t.stop();
                                }
                            }, t);
                        }))();
                    },
                    getList: function() {
                        var n = this;
                        return c(a.default.mark(function t() {
                            var e, o;
                            return a.default.wrap(function(t) {
                                for (;;) switch (t.prev = t.next) {
                                  case 0:
                                    return n.loadStatus = "loading", t.next = 3, (0, i.couponList)(n.param);

                                  case 3:
                                    e = t.sent, "00000" == (o = e.data).code && (o.data.list.length > 0 ? (o.data.list.length < n.param.pageSize && (n.loadStatus = "nomore"), 
                                    n.dataList = n.dataList.concat(o.data.list)) : n.loadStatus = "nomore");

                                  case 6:
                                  case "end":
                                    return t.stop();
                                }
                            }, t);
                        }))();
                    },
                    getCoupon: function(t) {
                        var e = this;
                        return c(a.default.mark(function o() {
                            var u, r, c;
                            return a.default.wrap(function(a) {
                                for (;;) switch (a.prev = a.next) {
                                  case 0:
                                    return n.showLoading({
                                        title: "领取中..."
                                    }), u = t.channelRelation.channelNo, a.next = 4, (0, i.takeCoupon)({
                                        channelNo: u,
                                        couponNo: t.couponNo,
                                        takeChannel: 3
                                    });

                                  case 4:
                                    r = a.sent, c = r.data, n.hideLoading(), "00000" == c.code ? n.showModal({
                                        content: "领取成功",
                                        confirmText: "去查看",
                                        confirmColor: "#37eea8",
                                        success: function(n) {
                                            n.confirm && e.gotoPage("/pages/coupon/coupon?index=".concat("YOU_ZAN" === u ? 1 : 0));
                                        }
                                    }) : n.showToast({
                                        title: c.message,
                                        icon: "none"
                                    });

                                  case 8:
                                  case "end":
                                    return a.stop();
                                }
                            }, o);
                        }))();
                    },
                    resetTime: function(n) {
                        return (0, o.default)(n).format("YYYY.MM.DD HH:mm:ss");
                    },
                    gotoPage: function(t) {
                        console.log("页面跳转", t), n.navigateTo({
                            url: t
                        });
                    }
                }
            };
            t.default = l;
        }).call(this, e("543d").default);
    },
    "3cec": function(n, t, e) {
        e.d(t, "b", function() {
            return o;
        }), e.d(t, "c", function() {
            return i;
        }), e.d(t, "a", function() {
            return a;
        });
        var a = {
            uIcon: function() {
                return e.e("node-modules/uview-ui/components/u-icon/u-icon").then(e.bind(null, "2925"));
            },
            uTabs: function() {
                return Promise.all([ e.e("common/vendor"), e.e("node-modules/uview-ui/components/u-tabs/u-tabs") ]).then(e.bind(null, "7418"));
            },
            uLoadmore: function() {
                return e.e("node-modules/uview-ui/components/u-loadmore/u-loadmore").then(e.bind(null, "bf89"));
            }
        }, o = function() {
            var n = this, t = (n.$createElement, n._self._c, n.$hasScopedSlotsParams("67fc2280-1")), e = t ? n.$getScopedSlotsParams("67fc2280-1", "default") : null, a = t ? n.__map(n.dataList, function(t, e) {
                return {
                    $orig: n.__get_orig(t),
                    m2: t.validEndTime ? n.resetTime(t.validEndTime) : null
                };
            }) : null;
            n.$mp.data = Object.assign({}, {
                $root: {
                    m0: t,
                    m1: e,
                    l0: a
                }
            });
        }, i = [];
    },
    "4ad9": function(n, t, e) {
        (function(n) {
            e("6cdc"), a(e("66fd"));
            var t = a(e("71d0"));
            function a(n) {
                return n && n.__esModule ? n : {
                    default: n
                };
            }
            wx.__webpack_require_UNI_MP_PLUGIN__ = e, n(t.default);
        }).call(this, e("543d").createPage);
    },
    "6eb7": function(n, t, e) {
        var a = e("2476");
        e.n(a).a;
    },
    "71d0": function(n, t, e) {
        e.r(t);
        var a = e("3cec"), o = e("829c");
        for (var i in o) [ "default" ].indexOf(i) < 0 && function(n) {
            e.d(t, n, function() {
                return o[n];
            });
        }(i);
        e("6eb7");
        var u = e("f0c5"), r = Object(u.a)(o.default, a.b, a.c, !1, null, "72e0e1be", null, !1, a.a, void 0);
        t.default = r.exports;
    },
    "829c": function(n, t, e) {
        e.r(t);
        var a = e("2a28"), o = e.n(a);
        for (var i in a) [ "default" ].indexOf(i) < 0 && function(n) {
            e.d(t, n, function() {
                return a[n];
            });
        }(i);
        t.default = o.a;
    }
}, [ [ "4ad9", "common/runtime", "common/vendor" ] ] ]);