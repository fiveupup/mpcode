require("../../@babel/runtime/helpers/Arrayincludes"), (global.webpackJsonp = global.webpackJsonp || []).push([ [ "pages/message/message" ], {
    "22af": function(e, a, t) {
        t.r(a);
        var r = t("5d48"), n = t("f508");
        for (var s in n) [ "default" ].indexOf(s) < 0 && function(e) {
            t.d(a, e, function() {
                return n[e];
            });
        }(s);
        t("d3de");
        var o = t("f0c5"), i = Object(o.a)(n.default, r.b, r.c, !1, null, "4fabb454", null, !1, r.a, void 0);
        a.default = i.exports;
    },
    2994: function(e, a, t) {
        (function(e) {
            t("6cdc"), r(t("66fd"));
            var a = r(t("22af"));
            function r(e) {
                return e && e.__esModule ? e : {
                    default: e
                };
            }
            wx.__webpack_require_UNI_MP_PLUGIN__ = t, e(a.default);
        }).call(this, t("543d").createPage);
    },
    "5d48": function(e, a, t) {
        t.d(a, "b", function() {
            return r;
        }), t.d(a, "c", function() {
            return n;
        }), t.d(a, "a", function() {});
        var r = function() {
            this.$createElement;
            this._self._c;
        }, n = [];
    },
    "8e51": function(e, a, t) {
        (function(e) {
            Object.defineProperty(a, "__esModule", {
                value: !0
            }), a.default = void 0;
            var r = i(t("4795")), n = t("7b12"), s = t("5bd4"), o = i(t("05b9"));
            function i(e) {
                return e && e.__esModule ? e : {
                    default: e
                };
            }
            function u(e) {
                return function(e) {
                    if (Array.isArray(e)) return c(e);
                }(e) || function(e) {
                    if ("undefined" != typeof Symbol && null != e[Symbol.iterator] || null != e["@@iterator"]) return Array.from(e);
                }(e) || function(e, a) {
                    if (e) {
                        if ("string" == typeof e) return c(e, a);
                        var t = Object.prototype.toString.call(e).slice(8, -1);
                        return "Object" === t && e.constructor && (t = e.constructor.name), "Map" === t || "Set" === t ? Array.from(e) : "Arguments" === t || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(t) ? c(e, a) : void 0;
                    }
                }(e) || function() {
                    throw new TypeError("Invalid attempt to spread non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.");
                }();
            }
            function c(e, a) {
                (null == a || a > e.length) && (a = e.length);
                for (var t = 0, r = new Array(a); t < a; t++) r[t] = e[t];
                return r;
            }
            function l(e, a, t, r, n, s, o) {
                try {
                    var i = e[s](o), u = i.value;
                } catch (e) {
                    return void t(e);
                }
                i.done ? a(u) : Promise.resolve(u).then(r, n);
            }
            function m(e) {
                return function() {
                    var a = this, t = arguments;
                    return new Promise(function(r, n) {
                        var s = e.apply(a, t);
                        function o(e) {
                            l(s, r, n, o, i, "next", e);
                        }
                        function i(e) {
                            l(s, r, n, o, i, "throw", e);
                        }
                        o(void 0);
                    });
                };
            }
            var d = {
                data: function() {
                    return {
                        params: {
                            messageCategory: "",
                            pageNum: 1,
                            pageSize: 20
                        },
                        total: 0,
                        messagelist: []
                    };
                },
                onLoad: function(e) {
                    this.params.messageCategory = e.category, "SYS" === this.params.messageCategory ? this.getMessagesList() : this.loadData();
                },
                onReachBottom: function() {
                    "SYS" !== this.params.messageCategory && this.total > this.messagelist.length && (this.params.pageNum += 1, 
                    this.loadData());
                },
                methods: {
                    loadData: function() {
                        var e = this;
                        return m(r.default.mark(function a() {
                            var t, n;
                            return r.default.wrap(function(a) {
                                for (;;) switch (a.prev = a.next) {
                                  case 0:
                                    return a.next = 2, (0, s.messages)(e.params);

                                  case 2:
                                    t = a.sent, n = t.data, e.messagelist = [].concat(u(e.messagelist), u(n.data.list)), 
                                    e.messagelist = e.messagelist.map(function(e) {
                                        var a = new Date().getFullYear();
                                        if (e.messageCreateTime) {
                                            var t = (0, o.default)(e.messageCreateTime).format("YYYY");
                                            a === Number(t) ? e.messageCreateTime = (0, o.default)(e.messageCreateTime).format("MM/DD HH:mm:ss") : e.messageCreateTime = (0, 
                                            o.default)(e.messageCreateTime).format("YYYY/MM/DD HH:mm:ss");
                                        }
                                        return e;
                                    }), e.total = n.data.total;

                                  case 7:
                                  case "end":
                                    return a.stop();
                                }
                            }, a);
                        }))();
                    },
                    getMessagesList: function() {
                        var e = this;
                        return m(r.default.mark(function a() {
                            var t, s;
                            return r.default.wrap(function(a) {
                                for (;;) switch (a.prev = a.next) {
                                  case 0:
                                    return a.next = 2, (0, n.getMessages)();

                                  case 2:
                                    t = a.sent, console.log("查询消息", t), "00000" == t.data.code && (e.messagelist = null === (s = t.data.data) || void 0 === s ? void 0 : s.map(function(e) {
                                        e.messageContent = e.title;
                                        var a = new Date().getFullYear();
                                        if (e.createTime) {
                                            var t = (0, o.default)(e.createTime).format("YYYY");
                                            a === Number(t) ? e.messageCreateTime = (0, o.default)(e.createTime).format("MM/DD HH:mm") : e.messageCreateTime = (0, 
                                            o.default)(e.createTime).format("YYYY/MM/DD HH:mm");
                                        }
                                        return e.read = 1 === e.isRead, e;
                                    }));

                                  case 5:
                                  case "end":
                                    return a.stop();
                                }
                            }, a);
                        }))();
                    },
                    gotoPage: function(a) {
                        console.log("点击变已读, 页面跳转"), a.read || this.read(a.id);
                        var t = JSON.parse(a.businessInfo || "{}");
                        switch (this.params.messageCategory) {
                          case "SYS":
                            e.navigateTo({
                                url: "/pages/message_detail/message_detail",
                                success: function(e) {
                                    e.eventChannel.emit("acceptDataFromOpenerPage", {
                                        messageId: a.id
                                    });
                                }
                            });
                            break;

                          case "POINT":
                            "EXCHANGE" === a.messageType && null != t && t.orderSn ? this._jumpTo("/pages/orderDetail/orderDetail?orderSn=".concat(null == t ? void 0 : t.orderSn, "&type=point")) : this._jumpTo("/pages/integral/integral");
                            break;

                          case "GROWTH":
                            if ("UPGRADE" === a.messageType) {
                                var r = t.code;
                                this._jumpTo("/pages/member_power/member_power?code=".concat(r));
                            } else "AWARD_POINT" === a.messageType ? this._jumpTo("/pages/integral/integral") : "AWARD_COUPON" === a.messageType ? this._jumpTo("/pages/coupon/coupon") : "UPGRADE" === a.messageType ? this._jumpTo("/pages/mallOrder/mallOrder?type=point") : this._jumpTo("/pages/growth/growth");
                            break;

                          case "COLLECTION":
                            "RARE_REMIND" === a.messageType ? this._jumpTo("/pages/coupon/coupon") : "REMIND" === a.messageType ? this._jumpTo("/pages/task_center/task_center?activeIndex=1") : this._jumpTo("/pages/task_center/task_center");
                            break;

                          case "COUPON":
                            this._jumpTo("/pages/coupon/coupon");
                            break;

                          case "ORIGINAL":
                            var n = t.originalInfoId, s = t.commentId;
                            [ "COMMENT", "REPLY" ].includes(a.messageType) && s ? this._jumpTo("/pages/team_detail/team_detail?id=".concat(n, "&commentId=").concat(s)) : this._jumpTo("/pages/team_detail/team_detail?id=".concat(n));
                            break;

                          case "INVITATION":
                            this._jumpTo("/pages/call_recode/call_recode");
                            break;

                          case "MARKET":
                            null != t && t.orderSn ? this._jumpTo("/pages/orderDetail/orderDetail?orderSn=".concat(null == t ? void 0 : t.orderSn, "&type=point")) : this._jumpTo("/pages/mallOrder/mallOrder?type=point");
                            break;

                          case "CUMULATIVE":
                            null != t && t.orderSn ? this._jumpTo("/pages/orderDetail/orderDetail?orderSn=".concat(null == t ? void 0 : t.orderSn, "&type=exchange")) : this._jumpTo("/pages/mall/exchange");
                            break;

                          case "MEDAL":
                            1 === (null == t ? void 0 : t.length) ? this._jumpTo("/pages/medal/info?id=".concat(t[0].id)) : this._jumpTo("/pages/medal/index");
                        }
                    },
                    _jumpTo: function(a) {
                        e.navigateTo({
                            url: a
                        });
                    },
                    read: function(e) {
                        var a = this;
                        return m(r.default.mark(function t() {
                            var o;
                            return r.default.wrap(function(t) {
                                for (;;) switch (t.prev = t.next) {
                                  case 0:
                                    if ("SYS" !== a.params.messageCategory) {
                                        t.next = 6;
                                        break;
                                    }
                                    return t.next = 3, (0, n.messageRead)(e);

                                  case 3:
                                    o = t.sent, t.next = 9;
                                    break;

                                  case 6:
                                    return t.next = 8, (0, s.readMessage)(e);

                                  case 8:
                                    o = t.sent;

                                  case 9:
                                    "00000" === o.data.code && (a.messagelist = a.messagelist.map(function(a) {
                                        return a.id === e && (a.read = !0), a;
                                    }));

                                  case 10:
                                  case "end":
                                    return t.stop();
                                }
                            }, t);
                        }))();
                    }
                }
            };
            a.default = d;
        }).call(this, t("543d").default);
    },
    b3c1: function(e, a, t) {},
    d3de: function(e, a, t) {
        var r = t("b3c1");
        t.n(r).a;
    },
    f508: function(e, a, t) {
        t.r(a);
        var r = t("8e51"), n = t.n(r);
        for (var s in r) [ "default" ].indexOf(s) < 0 && function(e) {
            t.d(a, e, function() {
                return r[e];
            });
        }(s);
        a.default = n.a;
    }
}, [ [ "2994", "common/runtime", "common/vendor" ] ] ]);