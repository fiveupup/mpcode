(global.webpackJsonp = global.webpackJsonp || []).push([ [ "pages/message/list" ], {
    "284c": function(e, t, a) {
        var n = a("a9b1");
        a.n(n).a;
    },
    "3ae5": function(e, t, a) {
        (function(e) {
            a("6cdc"), n(a("66fd"));
            var t = n(a("9e77"));
            function n(e) {
                return e && e.__esModule ? e : {
                    default: e
                };
            }
            wx.__webpack_require_UNI_MP_PLUGIN__ = a, e(t.default);
        }).call(this, a("543d").createPage);
    },
    "6d08": function(e, t, a) {
        a.r(t);
        var n = a("a0d7"), r = a.n(n);
        for (var u in n) [ "default" ].indexOf(u) < 0 && function(e) {
            a.d(t, e, function() {
                return n[e];
            });
        }(u);
        t.default = r.a;
    },
    "9e77": function(e, t, a) {
        a.r(t);
        var n = a("ed61"), r = a("6d08");
        for (var u in r) [ "default" ].indexOf(u) < 0 && function(e) {
            a.d(t, e, function() {
                return r[e];
            });
        }(u);
        a("284c");
        var o = a("f0c5"), c = Object(o.a)(r.default, n.b, n.c, !1, null, "d85ab398", null, !1, n.a, void 0);
        t.default = c.exports;
    },
    a0d7: function(e, t, a) {
        (function(e) {
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = void 0;
            var n = o(a("4795")), r = a("5bd4"), u = o(a("05b9"));
            function o(e) {
                return e && e.__esModule ? e : {
                    default: e
                };
            }
            function c(e, t, a, n, r, u, o) {
                try {
                    var c = e[u](o), i = c.value;
                } catch (e) {
                    return void a(e);
                }
                c.done ? t(i) : Promise.resolve(i).then(n, r);
            }
            function i(e) {
                return function() {
                    var t = this, a = arguments;
                    return new Promise(function(n, r) {
                        var u = e.apply(t, a);
                        function o(e) {
                            c(u, n, r, o, i, "next", e);
                        }
                        function i(e) {
                            c(u, n, r, o, i, "throw", e);
                        }
                        o(void 0);
                    });
                };
            }
            var s = {
                data: function() {
                    return {
                        messageList: []
                    };
                },
                onShow: function() {
                    this.loadData();
                },
                methods: {
                    loadData: function() {
                        var e = this;
                        return i(n.default.mark(function t() {
                            var a, o, c;
                            return n.default.wrap(function(t) {
                                for (;;) switch (t.prev = t.next) {
                                  case 0:
                                    return t.next = 2, (0, r.messageCategroy)();

                                  case 2:
                                    o = t.sent, c = o.data, e.messageList = null === (a = c.data) || void 0 === a ? void 0 : a.map(function(e) {
                                        var t = new Date().getFullYear();
                                        if (e.messageCreateTime) {
                                            var a = (0, u.default)(e.messageCreateTime).format("YYYY");
                                            t === Number(a) ? e.messageCreateTime = (0, u.default)(e.messageCreateTime).format("MM/DD HH:mm") : e.messageCreateTime = (0, 
                                            u.default)(e.messageCreateTime).format("YYYY/MM/DD HH:mm");
                                        }
                                        return e;
                                    });

                                  case 5:
                                  case "end":
                                    return t.stop();
                                }
                            }, t);
                        }))();
                    },
                    handleToCategory: function(t) {
                        t.messageContent && e.navigateTo({
                            url: "/pages/message/message?category=".concat(t.categoryNo)
                        });
                    },
                    handleClean: function() {
                        var e = this;
                        return i(n.default.mark(function t() {
                            var a;
                            return n.default.wrap(function(t) {
                                for (;;) switch (t.prev = t.next) {
                                  case 0:
                                    return t.next = 2, (0, r.cleanMessage)();

                                  case 2:
                                    if (a = t.sent, "00000" !== a.data.code) {
                                        t.next = 7;
                                        break;
                                    }
                                    return t.next = 7, e.loadData();

                                  case 7:
                                  case "end":
                                    return t.stop();
                                }
                            }, t);
                        }))();
                    }
                }
            };
            t.default = s;
        }).call(this, a("543d").default);
    },
    a9b1: function(e, t, a) {},
    ed61: function(e, t, a) {
        a.d(t, "b", function() {
            return n;
        }), a.d(t, "c", function() {
            return r;
        }), a.d(t, "a", function() {});
        var n = function() {
            this.$createElement;
            this._self._c;
        }, r = [];
    }
}, [ [ "3ae5", "common/runtime", "common/vendor" ] ] ]);