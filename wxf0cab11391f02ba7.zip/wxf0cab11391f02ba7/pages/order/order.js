(global.webpackJsonp = global.webpackJsonp || []).push([ [ "pages/order/order" ], {
    "74c4": function(e, n, t) {
        (function(e) {
            t("6cdc"), r(t("66fd"));
            var n = r(t("ebc4"));
            function r(e) {
                return e && e.__esModule ? e : {
                    default: e
                };
            }
            wx.__webpack_require_UNI_MP_PLUGIN__ = t, e(n.default);
        }).call(this, t("543d").createPage);
    },
    "9d98": function(e, n, t) {
        Object.defineProperty(n, "__esModule", {
            value: !0
        }), n.default = void 0;
        var r = function(e) {
            return e && e.__esModule ? e : {
                default: e
            };
        }(t("4795")), u = t("7b12");
        function o(e, n, t, r, u, o, a) {
            try {
                var i = e[o](a), c = i.value;
            } catch (e) {
                return void t(e);
            }
            i.done ? n(c) : Promise.resolve(c).then(r, u);
        }
        var a = {
            data: function() {
                return {
                    pageNum: 1,
                    pageSize: 10,
                    current: 0,
                    status: "nomore",
                    orderArr: [],
                    tablist: [ {
                        name: "全部",
                        tag: ""
                    }, {
                        name: "线上",
                        tag: "YOUZAN"
                    }, {
                        name: "线下",
                        tag: "ERP"
                    } ]
                };
            },
            onShow: function() {
                this.getOrderList();
            },
            methods: {
                getOrderList: function() {
                    var e = this;
                    return function(e) {
                        return function() {
                            var n = this, t = arguments;
                            return new Promise(function(r, u) {
                                var a = e.apply(n, t);
                                function i(e) {
                                    o(a, r, u, i, c, "next", e);
                                }
                                function c(e) {
                                    o(a, r, u, i, c, "throw", e);
                                }
                                i(void 0);
                            });
                        };
                    }(r.default.mark(function n() {
                        var t, o;
                        return r.default.wrap(function(n) {
                            for (;;) switch (n.prev = n.next) {
                              case 0:
                                return t = {
                                    orderChannel: e.tablist[e.current].tag,
                                    pageNum: e.pageNum,
                                    pageSize: e.pageSize
                                }, n.next = 3, (0, u.orderList)(t);

                              case 3:
                                "00000" == (o = n.sent).data.code && (e.orderArr = o.data.data.list);

                              case 5:
                              case "end":
                                return n.stop();
                            }
                        }, n);
                    }))();
                },
                tabsChange: function(e) {
                    this.current = e, this.getOrderList();
                }
            }
        };
        n.default = a;
    },
    bda5: function(e, n, t) {},
    c555: function(e, n, t) {
        t.d(n, "b", function() {
            return u;
        }), t.d(n, "c", function() {
            return o;
        }), t.d(n, "a", function() {
            return r;
        });
        var r = {
            uTabsSwiper: function() {
                return Promise.all([ t.e("common/vendor"), t.e("node-modules/uview-ui/components/u-tabs-swiper/u-tabs-swiper") ]).then(t.bind(null, "7854"));
            },
            uEmpty: function() {
                return t.e("node-modules/uview-ui/components/u-empty/u-empty").then(t.bind(null, "ab47"));
            },
            uLine: function() {
                return t.e("node-modules/uview-ui/components/u-line/u-line").then(t.bind(null, "10d1"));
            },
            uLoadmore: function() {
                return t.e("node-modules/uview-ui/components/u-loadmore/u-loadmore").then(t.bind(null, "bf89"));
            }
        }, u = function() {
            this.$createElement;
            this._self._c;
        }, o = [];
    },
    d90b: function(e, n, t) {
        var r = t("bda5");
        t.n(r).a;
    },
    e8b3: function(e, n, t) {
        t.r(n);
        var r = t("9d98"), u = t.n(r);
        for (var o in r) [ "default" ].indexOf(o) < 0 && function(e) {
            t.d(n, e, function() {
                return r[e];
            });
        }(o);
        n.default = u.a;
    },
    ebc4: function(e, n, t) {
        t.r(n);
        var r = t("c555"), u = t("e8b3");
        for (var o in u) [ "default" ].indexOf(o) < 0 && function(e) {
            t.d(n, e, function() {
                return u[e];
            });
        }(o);
        t("d90b");
        var a = t("f0c5"), i = Object(a.a)(u.default, r.b, r.c, !1, null, "40d5fadb", null, !1, r.a, void 0);
        n.default = i.exports;
    }
}, [ [ "74c4", "common/runtime", "common/vendor" ] ] ]);