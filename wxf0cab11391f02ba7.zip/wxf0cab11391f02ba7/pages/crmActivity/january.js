(global.webpackJsonp = global.webpackJsonp || []).push([ [ "pages/crmActivity/january" ], {
    "7d84": function(t, i, e) {
        e.r(i);
        var n = e("8691"), a = e("d995");
        for (var s in a) [ "default" ].indexOf(s) < 0 && function(t) {
            e.d(i, t, function() {
                return a[t];
            });
        }(s);
        e("db48");
        var o = e("f0c5"), c = Object(o.a)(a.default, n.b, n.c, !1, null, "30aa08db", null, !1, n.a, void 0);
        i.default = c.exports;
    },
    8691: function(t, i, e) {
        e.d(i, "b", function() {
            return a;
        }), e.d(i, "c", function() {
            return s;
        }), e.d(i, "a", function() {
            return n;
        });
        var n = {
            uParse: function() {
                return Promise.all([ e.e("common/vendor"), e.e("node-modules/uview-ui/components/u-parse/u-parse") ]).then(e.bind(null, "492b"));
            },
            uMask: function() {
                return e.e("node-modules/uview-ui/components/u-mask/u-mask").then(e.bind(null, "f0fd"));
            }
        }, a = function() {
            var t = this, i = (t.$createElement, t._self._c, t.formatN2Br(t.bgConfig.tip)), e = "add" === t.applicationType ? t.formatN2Br(t.taskMessage[t.submitTaskData.taskType]) : null, n = "add" !== t.applicationType ? t.formatN2Br(t.taskMessage.update) : null, a = t.formatN2Br(t.tipsObj.message);
            t._isMounted || (t.e0 = function(t) {
                return this.gotoPage("/pages/coupon/coupon?index=1");
            }, t.e1 = function(i) {
                t.applicationVisible = !1;
            }, t.e2 = function(i) {
                t.tipsVisible = !1;
            }, t.e3 = function(i) {
                t.tipsVisible = !1;
            }, t.e4 = function(i) {
                t.tipsObj.confirm ? t.tipsObj.confirm() : t.onTipsSubmit();
            }, t.e5 = function(i) {
                t.tipsObj.confirm ? t.tipsObj.confirm() : t.onTipsSubmit();
            }), t.$mp.data = Object.assign({}, {
                $root: {
                    m0: i,
                    m1: e,
                    m2: n,
                    m3: a
                }
            });
        }, s = [];
    },
    a06b: function(t, i, e) {
        (function(t) {
            e("6cdc"), n(e("66fd"));
            var i = n(e("7d84"));
            function n(t) {
                return t && t.__esModule ? t : {
                    default: t
                };
            }
            wx.__webpack_require_UNI_MP_PLUGIN__ = e, t(i.default);
        }).call(this, e("543d").createPage);
    },
    bd30: function(t, i, e) {
        (function(t) {
            Object.defineProperty(i, "__esModule", {
                value: !0
            }), i.default = void 0;
            var n = c(e("4795")), a = c(e("05b9")), s = e("f55f"), o = e("7b12");
            function c(t) {
                return t && t.__esModule ? t : {
                    default: t
                };
            }
            function r(t, i) {
                var e = Object.keys(t);
                if (Object.getOwnPropertySymbols) {
                    var n = Object.getOwnPropertySymbols(t);
                    i && (n = n.filter(function(i) {
                        return Object.getOwnPropertyDescriptor(t, i).enumerable;
                    })), e.push.apply(e, n);
                }
                return e;
            }
            function p(t) {
                for (var i = 1; i < arguments.length; i++) {
                    var e = null != arguments[i] ? arguments[i] : {};
                    i % 2 ? r(Object(e), !0).forEach(function(i) {
                        u(t, i, e[i]);
                    }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(t, Object.getOwnPropertyDescriptors(e)) : r(Object(e)).forEach(function(i) {
                        Object.defineProperty(t, i, Object.getOwnPropertyDescriptor(e, i));
                    });
                }
                return t;
            }
            function u(t, i, e) {
                return i in t ? Object.defineProperty(t, i, {
                    value: e,
                    enumerable: !0,
                    configurable: !0,
                    writable: !0
                }) : t[i] = e, t;
            }
            function l(t, i) {
                return function(t) {
                    if (Array.isArray(t)) return t;
                }(t) || function(t, i) {
                    var e = null == t ? null : "undefined" != typeof Symbol && t[Symbol.iterator] || t["@@iterator"];
                    if (null != e) {
                        var n, a, s = [], o = !0, c = !1;
                        try {
                            for (e = e.call(t); !(o = (n = e.next()).done) && (s.push(n.value), !i || s.length !== i); o = !0) ;
                        } catch (t) {
                            c = !0, a = t;
                        } finally {
                            try {
                                o || null == e.return || e.return();
                            } finally {
                                if (c) throw a;
                            }
                        }
                        return s;
                    }
                }(t, i) || function(t, i) {
                    if (t) {
                        if ("string" == typeof t) return d(t, i);
                        var e = Object.prototype.toString.call(t).slice(8, -1);
                        return "Object" === e && t.constructor && (e = t.constructor.name), "Map" === e || "Set" === e ? Array.from(t) : "Arguments" === e || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(e) ? d(t, i) : void 0;
                    }
                }(t, i) || function() {
                    throw new TypeError("Invalid attempt to destructure non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.");
                }();
            }
            function d(t, i) {
                (null == i || i > t.length) && (i = t.length);
                for (var e = 0, n = new Array(i); e < i; e++) n[e] = t[e];
                return n;
            }
            function b(t, i, e, n, a, s, o) {
                try {
                    var c = t[s](o), r = c.value;
                } catch (t) {
                    return void e(t);
                }
                c.done ? i(r) : Promise.resolve(r).then(n, a);
            }
            function f(t) {
                return function() {
                    var i = this, e = arguments;
                    return new Promise(function(n, a) {
                        var s = t.apply(i, e);
                        function o(t) {
                            b(s, n, a, o, c, "next", t);
                        }
                        function c(t) {
                            b(s, n, a, o, c, "throw", t);
                        }
                        o(void 0);
                    });
                };
            }
            var m = {
                data: function() {
                    return {
                        activityId: null,
                        BASE_IMG: "https://pepsicocampuscrmstgblob.blob.core.chinacloudapi.cn/pepsicocampuscrmstgblob/",
                        bgConfig: {
                            bgImgUrl: "https://pepsicocampuscrmstgblob.blob.core.chinacloudapi.cn/pepsicocampuscrmstgblob/FAQ_202312271356533656.jpeg",
                            ruleStyle: {
                                right: "40rpx",
                                top: "780rpx",
                                color: "#fff",
                                fontSize: "24rpx",
                                borderColor: "#fff",
                                backgroundColor: "rgba(239, 135, 158, 0.8)"
                            },
                            invitation: "FAQ_202309271533031875.png",
                            shopping: "FAQ_202309271533176465.png",
                            check_in: "FAQ_202309271533315115.png",
                            tip: "各位会员请注意：\n购物任务无法做修改，部分任务会有修改通道，具体可见页面上方详细【活动规则】",
                            endTip: "别着急！还有限量100个加码福利等你来挑战\n参与邀新挑战任务！还有机会免费获得「复古腋下包」1个\n还能在2款颜色中自选哦～",
                            teamId: "549"
                        },
                        applicationType: "",
                        submitDate: "",
                        currentDate: "",
                        userIcon: "https://pepsicocampuscrmstgblob.blob.core.chinacloudapi.cn/pepsicocampuscrmstgblob/FAQ_202307261459262649.png",
                        inventoryIcon: "https://pepsicocampuscrmstgblob.blob.core.chinacloudapi.cn/pepsicocampuscrmstgblob/FAQ_202307261501157701.png",
                        bottomLogo: "https://pepsicocampuscrmstgblob.blob.core.chinacloudapi.cn/pepsicocampuscrmstgblob/FAQ_202307261542377604.png",
                        applicationIcon: "https://pepsicocampuscrmstgblob.blob.core.chinacloudapi.cn/pepsicocampuscrmstgblob/FAQ_202307261550017387.png",
                        completeIcon: "https://pepsicocampuscrmstgblob.blob.core.chinacloudapi.cn/pepsicocampuscrmstgblob/FAQ_202307261654021856.png",
                        closeIcon: "https://pepsicocampuscrmstgblob.blob.core.chinacloudapi.cn/pepsicocampuscrmstgblob/FAQ_20230726163157385.png",
                        warningIcon: "https://pepsicocampuscrmstgblob.blob.core.chinacloudapi.cn/pepsicocampuscrmstgblob/FAQ_202307261712125500.png",
                        noticeIcon: "https://pepsicocampuscrmstgblob.blob.core.chinacloudapi.cn/pepsicocampuscrmstgblob/FAQ_202308291629358702.png",
                        errorIcon: "https://pepsicocampuscrmstgblob.blob.core.chinacloudapi.cn/pepsicocampuscrmstgblob/FAQ_202307290930527445.png",
                        successIcon: "https://pepsicocampuscrmstgblob.blob.core.chinacloudapi.cn/pepsicocampuscrmstgblob/FAQ_202307290929376504.png",
                        applicationIndex: "",
                        applicationVisible: !1,
                        tipsVisible: !1,
                        loginData: {},
                        hasUndoneTask: !1,
                        applicationTaskData: {},
                        submitTaskData: {},
                        tipsObj: {
                            tipsType: 0
                        },
                        tpmList: [],
                        tipsMessage: [ "本次活动仅限【个人信息】资料填写生日为1月的会员\n可参与本月免费生日礼活动，不同月份都有不同惊喜，社长期待相约你的生日乐事！", "您还未填写「1月生日资料」哦～\n点击前往完善「个人信息-生日」\n社长在这儿等你回来领免费生日礼物！", "您已参与其他活动\n若报名此活动，则其他活动无法继续\n请确定报名参加" ],
                        taskMessage: {
                            check_in: "各位会员请注意：\n                  选择【签到任务】后，1月7日12时前，无法修改为邀新任务\n                  该任务总共发放1,250个生日周边，数量有限先中先得\n                  需报名后，点击【去完成】\n                  并签到获得【乐事到底】稀有卡后，即可获得兑换券\n                  点击前往兑换页即可领取生日周边1个（2款随机发1）",
                            shopping: "各位会员请注意：\n                  选择【购物任务】后，将无法做修改！！！\n                  该任务总共发放1,750个生日周边，数量有限先到先得\n                  需报名后，点击兑换券前往兑换页加入购物，并在购物车和其他商品同时下单，且单笔订单满19.9元\n                  即可领取生日周边1个（可在2款颜色中自选）",
                            invitation: "各位会员请注意：\n                  该任务总共发放6,900个生日周边，数量有限先到先得\n                  需报名后，点击【去完成】\n                  并邀请5个好友注册「乐事心动社会员专区」小程序会员后，即可获得兑换券\n                  点击前往兑换页即可领取生日周边1个（2款随机发1）",
                            update: "各位会员请注意：\n                  选择修改后，该任务流程不可更改！\n                  一旦“确认”修改，在“签到”和“邀新”任务中累计的进度将在本次活动中失效\n                  还请检查各任务通道库存信息~"
                        }
                    };
                },
                onLoad: function(i) {
                    this.activityId = Number(i.id);
                    var e = t.getStorageSync("loginData2");
                    this.loginData = e ? JSON.parse(e) : {}, this.getSystemConfig();
                },
                onShow: function() {
                    this.init(), this.loadIsApplyActivity();
                },
                methods: {
                    loadIsApplyActivity: function() {
                        var t = this;
                        return f(n.default.mark(function i() {
                            var e, a, o;
                            return n.default.wrap(function(i) {
                                for (;;) switch (i.prev = i.next) {
                                  case 0:
                                    return i.next = 2, (0, s.activityApplyList)();

                                  case 2:
                                    a = i.sent, o = a.data, t.hasUndoneTask = (null === (e = o.data) || void 0 === e ? void 0 : e.length) > 0;

                                  case 5:
                                  case "end":
                                    return i.stop();
                                }
                            }, i);
                        }))();
                    },
                    init: function() {
                        var i = this;
                        return f(n.default.mark(function e() {
                            return n.default.wrap(function(e) {
                                for (;;) switch (e.prev = e.next) {
                                  case 0:
                                    t.showLoading({
                                        title: "加载中...",
                                        mask: !0
                                    }), Promise.all([ (0, s.signTemplateList)({
                                        activityId: i.activityId
                                    }), (0, s.taskDetailMemberId)({
                                        activityId: i.activityId
                                    }), (0, s.statistics)({
                                        activityId: i.activityId
                                    }) ]).then(function(e) {
                                        var n = l(e, 3), a = n[0].data, s = n[1].data, o = n[2].data;
                                        i.tpmList = null == a ? void 0 : a.data, i.applicationTaskData = null == s ? void 0 : s.data[0];
                                        for (var c = 0; c < i.tpmList.length; c++) {
                                            var r, p;
                                            i.applicationTaskData && i.applicationTaskData.id && (i.tpmList[c].taskType === (null === (r = i.applicationTaskData) || void 0 === r ? void 0 : r.taskType) ? (i.tpmList[c].isApplication = !0, 
                                            i.tpmList[c].taskStatus = null === (p = i.applicationTaskData) || void 0 === p ? void 0 : p.taskStatus) : i.tpmList[c].disabled = !0);
                                            for (var u = 0; u < (null == o || null === (d = o.data) || void 0 === d ? void 0 : d.length); u++) {
                                                var d;
                                                i.tpmList[c].taskType === o.data[u].taskType && (i.tpmList[c].endTime = o.data[u].endTime, 
                                                i.tpmList[c].surplusStockCount = o.data[u].surplusStockCount, 0 === i.tpmList[c].surplusStockCount && (i.tpmList[c].disabled = !0));
                                            }
                                            i.refreshDate(), t.hideLoading();
                                        }
                                        i.refreshDate(), t.hideLoading();
                                    });

                                  case 2:
                                  case "end":
                                    return e.stop();
                                }
                            }, e);
                        }))();
                    },
                    getSystemConfig: function() {
                        var t = this;
                        Promise.all([ (0, s.getSystemConfig)({
                            key: "activity"
                        }), (0, o.imageResources)("january") ]).then(function(i) {
                            var e = l(i, 2), n = e[0].data, a = e[1].data, s = JSON.parse(n.data);
                            t.bgConfig.bgImgUrl = s.bgImgUrl;
                            var o = JSON.parse(a.data);
                            t.bgConfig = p(p({}, t.bgConfig), o), o.tipsMessage && o.tipsMessage.forEach(function(i, e) {
                                i && (t.tipsMessage[e] = i);
                            }), o.taskMessage && (t.taskMessage = p(p({}, t.taskMessage), o.taskMessage));
                        });
                    },
                    refreshDate: function() {
                        this.currentDate = (0, a.default)().format("YYYY-MM-DD HH:mm:ss");
                    },
                    checkBirthdayDate: function() {
                        return this.loginData.birthday ? "01" === (0, a.default)(this.loginData.birthday).format("MM") || (this.showTips("warning", this.tipsMessage[0]), 
                        !1) : (this.showTips("warning", this.tipsMessage[1], 1), !1);
                    },
                    checkJoinActivity: function(t) {
                        var i = this, e = !(arguments.length > 1 && void 0 !== arguments[1]) || arguments[1];
                        return !e || !this.hasUndoneTask || (this.showTips("notice", this.tipsMessage[2], 4, !0, function() {
                            i.tipsVisible = !1, i.onApplication(t, !1);
                        }), !1);
                    },
                    getCurrentTask: function(i) {
                        var e = this;
                        return f(n.default.mark(function o() {
                            return n.default.wrap(function(n) {
                                for (;;) switch (n.prev = n.next) {
                                  case 0:
                                    t.showLoading({
                                        title: "加载中...",
                                        mask: !0
                                    }), Promise.all([ (0, s.signTemplateList)({
                                        templateId: i.id,
                                        activityId: e.activityId
                                    }), (0, s.statistics)({
                                        id: i.id,
                                        activityId: e.activityId
                                    }) ]).then(function(i) {
                                        var n = l(i, 2), s = n[0].data, o = n[1].data;
                                        if (t.hideLoading(), e.submitTaskData = p(p({}, s.data[0]), o.data[0]), !e.submitTaskData.surplusStockCount) return e.showTips("warning", "报名失败<br/>当前任务库存不足"), 
                                        void e.init();
                                        e.submitDate = (0, a.default)().format("YYYY-MM-DD HH:mm:ss"), e.applicationVisible = !0;
                                    });

                                  case 2:
                                  case "end":
                                    return n.stop();
                                }
                            }, o);
                        }))();
                    },
                    onApplication: function(t) {
                        var i = !(arguments.length > 1 && void 0 !== arguments[1]) || arguments[1];
                        t.disabled || this.checkBirthdayDate() && this.checkJoinActivity(t, i) && (this.applicationType = "add", 
                        this.applicationIndex = t.taskType, this.getCurrentTask(t));
                    },
                    updateApplication: function() {
                        var t = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : "shopping";
                        if (this.checkBirthdayDate()) {
                            this.applicationType = "edit", this.applicationIndex = t;
                            var i = this.tpmList.find(function(i) {
                                return i.taskType === t;
                            });
                            this.getCurrentTask(i);
                        }
                    },
                    onSubmit: function() {
                        var i = this;
                        return f(n.default.mark(function e() {
                            var a, o, c, r;
                            return n.default.wrap(function(e) {
                                for (;;) switch (e.prev = e.next) {
                                  case 0:
                                    if (i.submitTaskData.surplusStockCount) {
                                        e.next = 3;
                                        break;
                                    }
                                    return i.showTips("warning", "报名失败<br/>当前任务库存不足"), e.abrupt("return");

                                  case 3:
                                    if (a = i.tpmList.find(function(t) {
                                        return t.taskType === i.applicationIndex;
                                    }), t.showLoading({
                                        title: "加载中...",
                                        mask: !0
                                    }), "add" !== i.applicationType) {
                                        e.next = 11;
                                        break;
                                    }
                                    return e.next = 8, (0, s.addApplication)({
                                        templateId: a.id,
                                        activityId: i.activityId
                                    });

                                  case 8:
                                    e.t0 = e.sent, e.next = 14;
                                    break;

                                  case 11:
                                    return e.next = 13, (0, s.updateApplication)(i.applicationTaskData.id, {
                                        templateId: a.id,
                                        activityId: i.activityId
                                    });

                                  case 13:
                                    e.t0 = e.sent;

                                  case 14:
                                    if (o = e.t0, c = o.data, i.hasUndoneTask = !1, t.hideLoading(), "8888881" !== c.code) {
                                        e.next = 21;
                                        break;
                                    }
                                    return i.showTips("warning", i.tipsMessage[0]), e.abrupt("return");

                                  case 21:
                                    if ("8888882" !== c.code) {
                                        e.next = 24;
                                        break;
                                    }
                                    return i.showTips("warning", i.tipsMessage[1], 1), e.abrupt("return");

                                  case 24:
                                    if (!c.success) {
                                        e.next = 32;
                                        break;
                                    }
                                    return r = "add" === i.applicationType ? "您已成功报名" : "已成功更改任务为", i.showTips("success", "".concat(r, ' <br/> <view class="task-name">').concat(a.taskName, "</view> "), 2), 
                                    i.applicationVisible = !1, e.next = 30, i.init();

                                  case 30:
                                    e.next = 33;
                                    break;

                                  case 32:
                                    i.showTips("error", c.message);

                                  case 33:
                                  case "end":
                                    return e.stop();
                                }
                            }, e);
                        }))();
                    },
                    onComplete: function(t) {
                        switch (t.taskType) {
                          case "shopping":
                            this.gotoPage("/pages/coupon/coupon?index=1");
                            break;

                          case "check_in":
                            this.gotoPage("/pages/task_center/task_center");
                            break;

                          case "invitation":
                            0 === t.surplusStockCount && t.endTime ? this.showTips("notice", "各位会员请注意：<br/>" + '邀新任务已于<span style="color: #ff2333">'.concat(t.endTime, "</span>结束<br/>") + this.bgConfig.endTip, 3) : this.gotoPage("/pages/call_recode/call_recode");
                        }
                    },
                    showTips: function(t, i) {
                        var e = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : 0, n = arguments.length > 3 && void 0 !== arguments[3] && arguments[3], a = arguments.length > 4 && void 0 !== arguments[4] ? arguments[4] : null;
                        this.tipsObj.type = t, this.tipsObj.tipsType = e, this.tipsObj.message = i, this.tipsObj.cancel = n, 
                        this.tipsObj.confirm = a, this.tipsVisible = !0;
                    },
                    onTipsSubmit: function() {
                        1 === this.tipsObj.tipsType && this.gotoPage("/pages/mine/mine"), 2 === this.tipsObj.tipsType && this.onComplete(this.submitTaskData), 
                        3 === this.tipsObj.tipsType && this.gotoPage("/pages/team_detail/team_detail?id=".concat(this.bgConfig.teamId)), 
                        this.tipsVisible = !1;
                    },
                    formatN2Br: function(t) {
                        return t && t.replace(/\n/g, "<br/>");
                    },
                    gotoPage: function(t, i) {
                        console.log("页面跳转"), wx.navigateTo({
                            url: t
                        });
                    }
                }
            };
            i.default = m;
        }).call(this, e("543d").default);
    },
    c1bf: function(t, i, e) {},
    d995: function(t, i, e) {
        e.r(i);
        var n = e("bd30"), a = e.n(n);
        for (var s in n) [ "default" ].indexOf(s) < 0 && function(t) {
            e.d(i, t, function() {
                return n[t];
            });
        }(s);
        i.default = a.a;
    },
    db48: function(t, i, e) {
        var n = e("c1bf");
        e.n(n).a;
    }
}, [ [ "a06b", "common/runtime", "common/vendor" ] ] ]);