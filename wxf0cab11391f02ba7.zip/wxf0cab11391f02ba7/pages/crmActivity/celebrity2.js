(global.webpackJsonp = global.webpackJsonp || []).push([ [ "pages/crmActivity/celebrity2" ], {
    "317c": function(t, e, n) {
        (function(t) {
            n("6cdc"), i(n("66fd"));
            var e = i(n("851b"));
            function i(t) {
                return t && t.__esModule ? t : {
                    default: t
                };
            }
            wx.__webpack_require_UNI_MP_PLUGIN__ = n, t(e.default);
        }).call(this, n("543d").createPage);
    },
    "3def": function(t, e, n) {
        n.r(e);
        var i = n("84bf"), o = n.n(i);
        for (var a in i) [ "default" ].indexOf(a) < 0 && function(t) {
            n.d(e, t, function() {
                return i[t];
            });
        }(a);
        e.default = o.a;
    },
    4253: function(t, e, n) {},
    "84bf": function(t, e, n) {
        (function(t) {
            Object.defineProperty(e, "__esModule", {
                value: !0
            }), e.default = void 0;
            var i = c(n("4795")), o = c(n("05b9")), a = n("f55f"), r = n("7b12");
            function c(t) {
                return t && t.__esModule ? t : {
                    default: t
                };
            }
            function s(t, e) {
                var n = Object.keys(t);
                if (Object.getOwnPropertySymbols) {
                    var i = Object.getOwnPropertySymbols(t);
                    e && (i = i.filter(function(e) {
                        return Object.getOwnPropertyDescriptor(t, e).enumerable;
                    })), n.push.apply(n, i);
                }
                return n;
            }
            function u(t) {
                for (var e = 1; e < arguments.length; e++) {
                    var n = null != arguments[e] ? arguments[e] : {};
                    e % 2 ? s(Object(n), !0).forEach(function(e) {
                        p(t, e, n[e]);
                    }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(t, Object.getOwnPropertyDescriptors(n)) : s(Object(n)).forEach(function(e) {
                        Object.defineProperty(t, e, Object.getOwnPropertyDescriptor(n, e));
                    });
                }
                return t;
            }
            function p(t, e, n) {
                return e in t ? Object.defineProperty(t, e, {
                    value: n,
                    enumerable: !0,
                    configurable: !0,
                    writable: !0
                }) : t[e] = n, t;
            }
            function l(t, e) {
                return function(t) {
                    if (Array.isArray(t)) return t;
                }(t) || function(t, e) {
                    var n = null == t ? null : "undefined" != typeof Symbol && t[Symbol.iterator] || t["@@iterator"];
                    if (null != n) {
                        var i, o, a = [], r = !0, c = !1;
                        try {
                            for (n = n.call(t); !(r = (i = n.next()).done) && (a.push(i.value), !e || a.length !== e); r = !0) ;
                        } catch (t) {
                            c = !0, o = t;
                        } finally {
                            try {
                                r || null == n.return || n.return();
                            } finally {
                                if (c) throw o;
                            }
                        }
                        return a;
                    }
                }(t, e) || function(t, e) {
                    if (t) {
                        if ("string" == typeof t) return f(t, e);
                        var n = Object.prototype.toString.call(t).slice(8, -1);
                        return "Object" === n && t.constructor && (n = t.constructor.name), "Map" === n || "Set" === n ? Array.from(t) : "Arguments" === n || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n) ? f(t, e) : void 0;
                    }
                }(t, e) || function() {
                    throw new TypeError("Invalid attempt to destructure non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.");
                }();
            }
            function f(t, e) {
                (null == e || e > t.length) && (e = t.length);
                for (var n = 0, i = new Array(e); n < e; n++) i[n] = t[n];
                return i;
            }
            function b(t, e, n, i, o, a, r) {
                try {
                    var c = t[a](r), s = c.value;
                } catch (t) {
                    return void n(t);
                }
                c.done ? e(s) : Promise.resolve(s).then(i, o);
            }
            function d(t) {
                return function() {
                    var e = this, n = arguments;
                    return new Promise(function(i, o) {
                        var a = t.apply(e, n);
                        function r(t) {
                            b(a, i, o, r, c, "next", t);
                        }
                        function c(t) {
                            b(a, i, o, r, c, "throw", t);
                        }
                        r(void 0);
                    });
                };
            }
            var m = {
                data: function() {
                    return {
                        activityId: null,
                        bgConfig: {
                            bgImgUrl: "https://pepsicocampuscrmstgblob.blob.core.chinacloudapi.cn/pepsicocampuscrmstgblob/FAQ_202311201138414882.jpeg",
                            ruleStyle: {
                                right: "40rpx",
                                top: "800rpx",
                                color: "#fff",
                                fontSize: "24rpx",
                                borderColor: "#fff",
                                backgroundColor: "rgba(208, 76, 47, 1)"
                            },
                            teamId: 0,
                            name: "乐事加丞邀新赛",
                            tip: "各位会员请注意：\n邀新仅统计活动期间内的邀新记录，若宝子在当日17点之前完成任务，将于当日24点前派发所获得的对应奖励兑换券，若17点后完成任务将于次日24点前发放对应奖励兑换券，若有疑问，烦请联系客服薯薯子社长~具体可见页面上方详细【活动规则】",
                            applyTips: "注意：报名后，宝子原来参加的生日邀新活动将中止且无法再参与，详情请见该活动页规则"
                        },
                        applicationType: "",
                        currentDate: "",
                        userIcon: "https://pepsicocampuscrmstgblob.blob.core.chinacloudapi.cn/pepsicocampuscrmstgblob/FAQ_202311201131341297.png",
                        inventoryIcon: "https://pepsicocampuscrmstgblob.blob.core.chinacloudapi.cn/pepsicocampuscrmstgblob/FAQ_202307261501157701.png",
                        closeIcon: "https://pepsicocampuscrmstgblob.blob.core.chinacloudapi.cn/pepsicocampuscrmstgblob/FAQ_202311201133322497.png",
                        warningIcon: "https://pepsicocampuscrmstgblob.blob.core.chinacloudapi.cn/pepsicocampuscrmstgblob/FAQ_202307261712125500.png",
                        noticeIcon: "https://pepsicocampuscrmstgblob.blob.core.chinacloudapi.cn/pepsicocampuscrmstgblob/FAQ_202308291629358702.png",
                        errorIcon: "https://pepsicocampuscrmstgblob.blob.core.chinacloudapi.cn/pepsicocampuscrmstgblob/FAQ_202307290930527445.png",
                        successIcon: "https://pepsicocampuscrmstgblob.blob.core.chinacloudapi.cn/pepsicocampuscrmstgblob/FAQ_202307290929376504.png",
                        applicationIndex: "",
                        applicationVisible: !1,
                        tipsVisible: !1,
                        loginData: {},
                        taskData: {
                            signUpCount: 0,
                            inviteNum: 0,
                            taskStatus: -1
                        },
                        applicationTaskData: {},
                        submitTaskData: {},
                        tipsObj: {
                            tipsType: 0
                        },
                        tpmList: [],
                        tipsMessage: [ "", "注意：您已参加其他活动，若宝子报名此活动，其他活动即刻失效，详情请见该活动页规则" ]
                    };
                },
                onLoad: function(e) {
                    this.activityId = Number(e.id);
                    var n = t.getStorageSync("loginData2");
                    this.loginData = n ? JSON.parse(n) : {}, this.getSystemConfig();
                },
                onShow: function() {
                    this.init(), this.loadIsApplyActivity();
                },
                methods: {
                    loadIsApplyActivity: function() {
                        var t = this;
                        return d(i.default.mark(function e() {
                            var n, o, r;
                            return i.default.wrap(function(e) {
                                for (;;) switch (e.prev = e.next) {
                                  case 0:
                                    return e.next = 2, (0, a.activityApplyList)();

                                  case 2:
                                    o = e.sent, r = o.data, t.hasUndoneTask = (null === (n = r.data) || void 0 === n ? void 0 : n.length) > 0;

                                  case 5:
                                  case "end":
                                    return e.stop();
                                }
                            }, e);
                        }))();
                    },
                    init: function() {
                        var e = this;
                        return d(i.default.mark(function n() {
                            return i.default.wrap(function(n) {
                                for (;;) switch (n.prev = n.next) {
                                  case 0:
                                    t.showLoading({
                                        title: "加载中...",
                                        mask: !0
                                    }), Promise.all([ (0, a.signTemplateList)({
                                        activityId: e.activityId
                                    }), (0, a.taskDetailMemberId)({
                                        activityId: e.activityId
                                    }) ]).then(function(n) {
                                        var i, o, a, r = l(n, 2), c = r[0].data, s = r[1].data;
                                        e.taskData = c.data[0], e.taskData.taskStatus = (null === (i = s.data) || void 0 === i ? void 0 : i.length) > 0 ? 0 : -1, 
                                        null !== (o = s.data) && void 0 !== o && o.length && (e.taskData.inviteNum = (null === (a = s.data[0]) || void 0 === a ? void 0 : a.progress) || 0), 
                                        e.refreshDate(), t.hideLoading();
                                    });

                                  case 2:
                                  case "end":
                                    return n.stop();
                                }
                            }, n);
                        }))();
                    },
                    getSystemConfig: function() {
                        var t = this;
                        return d(i.default.mark(function e() {
                            var n, o, a;
                            return i.default.wrap(function(e) {
                                for (;;) switch (e.prev = e.next) {
                                  case 0:
                                    return e.next = 2, (0, r.imageResources)("celebrity");

                                  case 2:
                                    n = e.sent, o = n.data, a = JSON.parse(o.data), t.bgConfig = u(u({}, t.bgConfig), a);

                                  case 6:
                                  case "end":
                                    return e.stop();
                                }
                            }, e);
                        }))();
                    },
                    refreshDate: function() {
                        this.currentDate = (0, o.default)().format("YYYY-MM-DD HH:mm:ss");
                    },
                    checkJoinActivity: function() {
                        var t = this, e = !(arguments.length > 0 && void 0 !== arguments[0]) || arguments[0];
                        return !e || !this.hasUndoneTask || (this.showTips("notice", this.tipsMessage[1], 1, !0, function() {
                            t.tipsVisible = !1, t.onApplication(t.taskData, !1);
                        }), !1);
                    },
                    onApplication: function(t) {
                        var e = !(arguments.length > 1 && void 0 !== arguments[1]) || arguments[1];
                        this.checkJoinActivity(e) && (this.applicationType = "add", this.applicationIndex = t.taskType, 
                        this.applicationVisible = !0);
                    },
                    onSubmit: function() {
                        var e = this;
                        return d(i.default.mark(function n() {
                            var o, r;
                            return i.default.wrap(function(n) {
                                for (;;) switch (n.prev = n.next) {
                                  case 0:
                                    return t.showLoading({
                                        title: "加载中...",
                                        mask: !0
                                    }), n.next = 3, (0, a.addApplication)({
                                        templateId: e.taskData.id,
                                        activityId: e.activityId
                                    });

                                  case 3:
                                    if (o = n.sent, r = o.data, e.hasUndoneTask = !1, t.hideLoading(), !r.success) {
                                        n.next = 14;
                                        break;
                                    }
                                    return e.showTips("success", '您已成功报名 <br/> <view class="task-name">'.concat(e.bgConfig.name, "</view> "), 2), 
                                    e.applicationVisible = !1, n.next = 12, e.init();

                                  case 12:
                                    n.next = 15;
                                    break;

                                  case 14:
                                    e.showTips("error", '报名失败<br/><view class="task-name">'.concat(e.bgConfig.name, "</view><br/>").concat(r.message));

                                  case 15:
                                  case "end":
                                    return n.stop();
                                }
                            }, n);
                        }))();
                    },
                    onComplete: function() {
                        var t = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : "invitation";
                        "invitation" === t ? this.gotoPage("/pages/call_recode/call_recode") : "sort" === t && this.gotoPage("/pages/team_detail/team_detail?id=".concat(this.bgConfig.teamId));
                    },
                    showTips: function(t, e) {
                        var n = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : 0, i = arguments.length > 3 && void 0 !== arguments[3] && arguments[3], o = arguments.length > 4 && void 0 !== arguments[4] ? arguments[4] : null;
                        this.tipsObj.type = t, this.tipsObj.tipsType = n, this.tipsObj.message = e, this.tipsObj.cancel = i, 
                        this.tipsObj.confirm = o, this.refreshDate(), this.tipsVisible = !0;
                    },
                    onTipsSubmit: function() {
                        2 === this.tipsObj.tipsType && this.onComplete(), this.tipsVisible = !1;
                    },
                    formatN2Br: function(t) {
                        return t && t.replace(/\n/g, "<br/>");
                    },
                    gotoPage: function(t, e) {
                        console.log("页面跳转"), wx.navigateTo({
                            url: t
                        });
                    }
                }
            };
            e.default = m;
        }).call(this, n("543d").default);
    },
    "851b": function(t, e, n) {
        n.r(e);
        var i = n("9f44"), o = n("3def");
        for (var a in o) [ "default" ].indexOf(a) < 0 && function(t) {
            n.d(e, t, function() {
                return o[t];
            });
        }(a);
        n("f30d");
        var r = n("f0c5"), c = Object(r.a)(o.default, i.b, i.c, !1, null, "7180017c", null, !1, i.a, void 0);
        e.default = c.exports;
    },
    "9f44": function(t, e, n) {
        n.d(e, "b", function() {
            return o;
        }), n.d(e, "c", function() {
            return a;
        }), n.d(e, "a", function() {
            return i;
        });
        var i = {
            uParse: function() {
                return Promise.all([ n.e("common/vendor"), n.e("node-modules/uview-ui/components/u-parse/u-parse") ]).then(n.bind(null, "492b"));
            },
            uMask: function() {
                return n.e("node-modules/uview-ui/components/u-mask/u-mask").then(n.bind(null, "f0fd"));
            }
        }, o = function() {
            var t = this, e = (t.$createElement, t._self._c, t.formatN2Br(t.bgConfig.tip)), n = t.formatN2Br(t.bgConfig.applyTips), i = t.formatN2Br(t.tipsObj.message);
            t._isMounted || (t.e0 = function(e) {
                t.applicationVisible = !1;
            }, t.e1 = function(e) {
                t.applicationVisible = !1;
            }, t.e2 = function(e) {
                t.tipsVisible = !1;
            }, t.e3 = function(e) {
                t.tipsVisible = !1;
            }, t.e4 = function(e) {
                t.tipsObj.confirm ? t.tipsObj.confirm() : t.onTipsSubmit();
            }, t.e5 = function(e) {
                t.tipsObj.confirm ? t.tipsObj.confirm() : t.onTipsSubmit();
            }), t.$mp.data = Object.assign({}, {
                $root: {
                    m0: e,
                    m1: n,
                    m2: i
                }
            });
        }, a = [];
    },
    f30d: function(t, e, n) {
        var i = n("4253");
        n.n(i).a;
    }
}, [ [ "317c", "common/runtime", "common/vendor" ] ] ]);