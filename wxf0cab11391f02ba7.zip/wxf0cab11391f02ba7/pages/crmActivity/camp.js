(global.webpackJsonp = global.webpackJsonp || []).push([ [ "pages/crmActivity/camp" ], {
    "1f90": function(t, a, e) {},
    2489: function(t, a, e) {
        (function(t) {
            e("6cdc"), n(e("66fd"));
            var a = n(e("eada"));
            function n(t) {
                return t && t.__esModule ? t : {
                    default: t
                };
            }
            wx.__webpack_require_UNI_MP_PLUGIN__ = e, t(a.default);
        }).call(this, e("543d").createPage);
    },
    "5caf": function(t, a, e) {
        (function(t) {
            Object.defineProperty(a, "__esModule", {
                value: !0
            }), a.default = void 0;
            var n = s(e("4795")), i = s(e("05b9")), r = e("f55f"), o = e("7b12");
            function s(t) {
                return t && t.__esModule ? t : {
                    default: t
                };
            }
            function c(t, a) {
                var e = Object.keys(t);
                if (Object.getOwnPropertySymbols) {
                    var n = Object.getOwnPropertySymbols(t);
                    a && (n = n.filter(function(a) {
                        return Object.getOwnPropertyDescriptor(t, a).enumerable;
                    })), e.push.apply(e, n);
                }
                return e;
            }
            function u(t) {
                for (var a = 1; a < arguments.length; a++) {
                    var e = null != arguments[a] ? arguments[a] : {};
                    a % 2 ? c(Object(e), !0).forEach(function(a) {
                        p(t, a, e[a]);
                    }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(t, Object.getOwnPropertyDescriptors(e)) : c(Object(e)).forEach(function(a) {
                        Object.defineProperty(t, a, Object.getOwnPropertyDescriptor(e, a));
                    });
                }
                return t;
            }
            function p(t, a, e) {
                return a in t ? Object.defineProperty(t, a, {
                    value: e,
                    enumerable: !0,
                    configurable: !0,
                    writable: !0
                }) : t[a] = e, t;
            }
            function l(t, a) {
                return function(t) {
                    if (Array.isArray(t)) return t;
                }(t) || function(t, a) {
                    var e = null == t ? null : "undefined" != typeof Symbol && t[Symbol.iterator] || t["@@iterator"];
                    if (null != e) {
                        var n, i, r = [], o = !0, s = !1;
                        try {
                            for (e = e.call(t); !(o = (n = e.next()).done) && (r.push(n.value), !a || r.length !== a); o = !0) ;
                        } catch (t) {
                            s = !0, i = t;
                        } finally {
                            try {
                                o || null == e.return || e.return();
                            } finally {
                                if (s) throw i;
                            }
                        }
                        return r;
                    }
                }(t, a) || function(t, a) {
                    if (t) {
                        if ("string" == typeof t) return d(t, a);
                        var e = Object.prototype.toString.call(t).slice(8, -1);
                        return "Object" === e && t.constructor && (e = t.constructor.name), "Map" === e || "Set" === e ? Array.from(t) : "Arguments" === e || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(e) ? d(t, a) : void 0;
                    }
                }(t, a) || function() {
                    throw new TypeError("Invalid attempt to destructure non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.");
                }();
            }
            function d(t, a) {
                (null == a || a > t.length) && (a = t.length);
                for (var e = 0, n = new Array(a); e < a; e++) n[e] = t[e];
                return n;
            }
            function f(t, a, e, n, i, r, o) {
                try {
                    var s = t[r](o), c = s.value;
                } catch (t) {
                    return void e(t);
                }
                s.done ? a(c) : Promise.resolve(c).then(n, i);
            }
            function b(t) {
                return function() {
                    var a = this, e = arguments;
                    return new Promise(function(n, i) {
                        var r = t.apply(a, e);
                        function o(t) {
                            f(r, n, i, o, s, "next", t);
                        }
                        function s(t) {
                            f(r, n, i, o, s, "throw", t);
                        }
                        o(void 0);
                    });
                };
            }
            var m = {
                data: function() {
                    return {
                        activityId: null,
                        bgConfig: {
                            name: "薯礼邀新站",
                            bgImgUrl: "https://pepsicocampuscrmstgblob.blob.core.chinacloudapi.cn/pepsicocampuscrmstgblob/FAQ_202401151527245567.jpeg",
                            teamId: 0,
                            ruleStyle: {
                                right: "20rpx",
                                top: "800rpx",
                                color: "#fff",
                                fontSize: "24rpx",
                                borderColor: "#fff",
                                backgroundColor: "rgba(65, 122, 191, 0.8)"
                            },
                            bgColor: "#417bbd",
                            tip: "各位会员请注意：\n总共仅可领取1项奖励，领取任一奖励后，将无法领取其他奖励，具体可见页面上方详细【活动规则】",
                            bg1: "https://pepsicocampuscrmstgblob.blob.core.chinacloudapi.cn/pepsicocampuscrmstgblob/FAQ_202401151700253451.jpeg",
                            bg2: "https://pepsicocampuscrmstgblob.blob.core.chinacloudapi.cn/pepsicocampuscrmstgblob/FAQ_202401151704536568.jpeg",
                            bg3: "https://pepsicocampuscrmstgblob.blob.core.chinacloudapi.cn/pepsicocampuscrmstgblob/FAQ_20240115170447626.jpeg"
                        },
                        hasUndoneTask: !1,
                        applicationType: "",
                        currentDate: "",
                        userIcon: "https://pepsicocampuscrmstgblob.blob.core.chinacloudapi.cn/pepsicocampuscrmstgblob/FAQ_202307261459262649.png",
                        inventoryIcon: "https://pepsicocampuscrmstgblob.blob.core.chinacloudapi.cn/pepsicocampuscrmstgblob/FAQ_202307261501157701.png",
                        closeIcon: "https://pepsicocampuscrmstgblob.blob.core.chinacloudapi.cn/pepsicocampuscrmstgblob/FAQ_202401091603365218.png",
                        warningIcon: "https://pepsicocampuscrmstgblob.blob.core.chinacloudapi.cn/pepsicocampuscrmstgblob/FAQ_202307261712125500.png",
                        noticeIcon: "https://pepsicocampuscrmstgblob.blob.core.chinacloudapi.cn/pepsicocampuscrmstgblob/FAQ_202308291629358702.png",
                        errorIcon: "https://pepsicocampuscrmstgblob.blob.core.chinacloudapi.cn/pepsicocampuscrmstgblob/FAQ_202307290930527445.png",
                        successIcon: "https://pepsicocampuscrmstgblob.blob.core.chinacloudapi.cn/pepsicocampuscrmstgblob/FAQ_202307290929376504.png",
                        applicationIndex: "",
                        applicationVisible: !1,
                        tipsVisible: !1,
                        loginData: {},
                        taskData: {
                            signUpCount: 0,
                            surplusStockCount: 0,
                            taskStatus: -1,
                            progress: 0,
                            taskType: "invitation"
                        },
                        awardData1: {},
                        awardData2: {},
                        awardData3: {},
                        receiveId: null,
                        applicationTaskData: {},
                        submitTaskData: {},
                        tipsObj: {
                            tipsType: 0
                        },
                        tipsMessage: [ "宝子的邀新还未完成，快邀请好友助力吧~", "注意：您已参加其他活动，若宝子报名此活动，其他活动即刻失效，详情请见该活动页规则" ],
                        taskMessage: {
                            check_in: "",
                            shopping: "",
                            invitation: "注意：报名后，宝子原来参加的生日邀新活动将中止且无法再参与，详情请见该活动页规则",
                            update: ""
                        }
                    };
                },
                onLoad: function(a) {
                    this.activityId = Number(a.id);
                    var e = t.getStorageSync("loginData2");
                    this.loginData = e ? JSON.parse(e) : {}, this.getSystemConfig();
                },
                onShow: function() {
                    this.init(), this.loadIsApplyActivity();
                },
                methods: {
                    loadIsApplyActivity: function() {
                        var t = this;
                        return b(n.default.mark(function a() {
                            var e, i, o;
                            return n.default.wrap(function(a) {
                                for (;;) switch (a.prev = a.next) {
                                  case 0:
                                    return a.next = 2, (0, r.activityApplyList)();

                                  case 2:
                                    i = a.sent, o = i.data, t.hasUndoneTask = (null === (e = o.data) || void 0 === e ? void 0 : e.length) > 0;

                                  case 5:
                                  case "end":
                                    return a.stop();
                                }
                            }, a);
                        }))();
                    },
                    init: function() {
                        var a = this;
                        return b(n.default.mark(function e() {
                            return n.default.wrap(function(e) {
                                for (;;) switch (e.prev = e.next) {
                                  case 0:
                                    t.showLoading({
                                        title: "加载中...",
                                        mask: !0
                                    }), Promise.all([ (0, r.signTemplateList)({
                                        activityId: a.activityId
                                    }), (0, r.taskDetailMemberId)({
                                        activityId: a.activityId
                                    }), (0, r.statistics)({
                                        activityId: a.activityId
                                    }) ]).then(function(e) {
                                        var n, i, r = l(e, 3), o = r[0].data, s = r[1].data, c = r[2].data, u = null === (n = o.data) || void 0 === n ? void 0 : n.find(function(t) {
                                            return 0 === t.parentId;
                                        });
                                        if (a.taskData.id = u.id, a.taskData.signUpCount = u.signUpCount, null !== (i = s.data) && void 0 !== i && i.length) {
                                            var p, d = null === (p = s.data) || void 0 === p ? void 0 : p.find(function(t) {
                                                return t.templateId === u.id;
                                            });
                                            a.taskData.taskStatus = d.taskStatus, a.taskData.progress = d.progress || 0;
                                        }
                                        if (o.data.length >= 1) {
                                            var f, b, m, g = o.data[1], h = null === (f = c.data) || void 0 === f ? void 0 : f.find(function(t) {
                                                return t.id === g.id;
                                            });
                                            if (console.log("award1", h, g), a.awardData1.id = g.id, a.awardData1.targetNum = g.targetNum, 
                                            a.awardData1.surplusStockCount = h.surplusStockCount, (null === (b = s.data) || void 0 === b ? void 0 : b.length) > 1) (null === (m = s.data) || void 0 === m ? void 0 : m.find(function(t) {
                                                return t.templateId === g.id;
                                            })) && (a.awardData1.taskStatus = 1, a.receiveId = g.id); else a.awardData1.taskStatus = 0;
                                        }
                                        if (o.data.length >= 2) {
                                            var v, w, k, y = o.data[2], D = null === (v = c.data) || void 0 === v ? void 0 : v.find(function(t) {
                                                return t.id === y.id;
                                            });
                                            if (a.awardData2.id = y.id, a.awardData2.targetNum = y.targetNum, a.awardData2.surplusStockCount = D.surplusStockCount, 
                                            (null === (w = s.data) || void 0 === w ? void 0 : w.length) > 1 && 1 !== a.awardData1.taskStatus) (null === (k = s.data) || void 0 === k ? void 0 : k.find(function(t) {
                                                return t.templateId === y.id;
                                            })) && (a.awardData2.taskStatus = 1, a.receiveId = y.id); else a.awardData2.taskStatus = 0;
                                        }
                                        if (o.data.length >= 3) {
                                            var S, I, O, T = o.data[3], j = null === (S = c.data) || void 0 === S ? void 0 : S.find(function(t) {
                                                return t.id === T.id;
                                            });
                                            if (a.awardData3.id = T.id, a.awardData3.targetNum = T.targetNum, a.awardData3.surplusStockCount = j.surplusStockCount, 
                                            (null === (I = s.data) || void 0 === I ? void 0 : I.length) > 1 && 1 !== a.awardData1.taskStatus && 1 !== a.awardData2.taskStatus) (null === (O = s.data) || void 0 === O ? void 0 : O.find(function(t) {
                                                return t.templateId === T.id;
                                            })) && (a.awardData3.taskStatus = 1, a.receiveId = T.id); else a.awardData3.taskStatus = 0;
                                        }
                                        a.taskData.surplusStockCount = (a.awardData1.surplusStockCount || 0) + (a.awardData2.surplusStockCount || 0) + (a.awardData3.surplusStockCount || 0), 
                                        a.refreshDate(), t.hideLoading();
                                    });

                                  case 2:
                                  case "end":
                                    return e.stop();
                                }
                            }, e);
                        }))();
                    },
                    getSystemConfig: function() {
                        var t = this;
                        return b(n.default.mark(function a() {
                            var e, i, r;
                            return n.default.wrap(function(a) {
                                for (;;) switch (a.prev = a.next) {
                                  case 0:
                                    return a.next = 2, (0, o.imageResources)("camp");

                                  case 2:
                                    e = a.sent, i = e.data, r = JSON.parse(i.data), t.bgConfig = u(u({}, t.bgConfig), r);

                                  case 6:
                                  case "end":
                                    return a.stop();
                                }
                            }, a);
                        }))();
                    },
                    refreshDate: function() {
                        this.currentDate = (0, i.default)().format("YYYY-MM-DD HH:mm:ss");
                    },
                    checkJoinActivity: function() {
                        var t = !(arguments.length > 0 && void 0 !== arguments[0]) || arguments[0];
                        return !t || !this.hasUndoneTask || (this.showTips("notice", this.tipsMessage[1], 1, !0), 
                        !1);
                    },
                    getCurrentTask: function(t) {
                        var a = this;
                        return b(n.default.mark(function e() {
                            return n.default.wrap(function(e) {
                                for (;;) switch (e.prev = e.next) {
                                  case 0:
                                    return e.next = 2, a.init();

                                  case 2:
                                    if (a.submitTaskData = u({}, t), a.submitTaskData.surplusStockCount) {
                                        e.next = 6;
                                        break;
                                    }
                                    return a.showTips("warning", "报名失败<br/>当前任务库存不足"), e.abrupt("return");

                                  case 6:
                                    a.applicationVisible = !0;

                                  case 7:
                                  case "end":
                                    return e.stop();
                                }
                            }, e);
                        }))();
                    },
                    onApplication: function(t) {
                        var a = !(arguments.length > 1 && void 0 !== arguments[1]) || arguments[1];
                        t.disabled || this.checkJoinActivity(a) && (this.applicationType = "add", this.applicationIndex = t.taskType, 
                        this.getCurrentTask(t));
                    },
                    onSubmit: function() {
                        var a = this;
                        return b(n.default.mark(function e() {
                            var i, o;
                            return n.default.wrap(function(e) {
                                for (;;) switch (e.prev = e.next) {
                                  case 0:
                                    if (a.submitTaskData.surplusStockCount) {
                                        e.next = 3;
                                        break;
                                    }
                                    return a.showTips("warning", "报名失败<br/>当前任务库存不足"), e.abrupt("return");

                                  case 3:
                                    return t.showLoading({
                                        title: "加载中...",
                                        mask: !0
                                    }), e.next = 6, (0, r.addApplication)({
                                        templateId: a.taskData.id,
                                        activityId: a.activityId
                                    });

                                  case 6:
                                    if (i = e.sent, o = i.data, a.hasUndoneTask = !1, t.hideLoading(), !o.success) {
                                        e.next = 17;
                                        break;
                                    }
                                    return a.showTips("success", '您已成功报名<br/> <view class="task-name">'.concat(a.bgConfig.name, "</view> "), 2), 
                                    a.applicationVisible = !1, e.next = 15, a.init();

                                  case 15:
                                    e.next = 18;
                                    break;

                                  case 17:
                                    a.showTips("error", '报名失败<br/><view class="task-name">'.concat(a.bgConfig.name, "</view><br/>").concat(o.message));

                                  case 18:
                                  case "end":
                                    return e.stop();
                                }
                            }, e);
                        }))();
                    },
                    onReceiveAward: function(a, e) {
                        var i = this;
                        this.showTips("warning", "请确定领取<br/>" + '<view class="task-name">邀新'.concat(e, "人奖励</view><br/> ") + '<view style="color:#FFF609;">注意：点击确认后，将领取宝子的最终奖励，且无法领取其他奖励，并无法继续参加该活动哦，最好选择可领取的最高级福袋哦~</view>', 0, !0, b(n.default.mark(function o() {
                            var s, c;
                            return n.default.wrap(function(n) {
                                for (;;) switch (n.prev = n.next) {
                                  case 0:
                                    return t.showLoading({
                                        title: "加载中...",
                                        mask: !0
                                    }), n.next = 3, (0, r.receiveAward)({
                                        activityId: i.activityId,
                                        templateId: a
                                    });

                                  case 3:
                                    s = n.sent, c = s.data, t.hideLoading(), i.tipsVisible = !1, "00000" === c.code ? (i.showTips("success", "您已领取<br/>" + '<view class="task-name">邀新'.concat(e, "人奖励</view><br/> ") + "请在“我的优惠券”中查看奖励"), 
                                    i.init()) : i.showTips("error", "领取失败<br/>" + c.message);

                                  case 8:
                                  case "end":
                                    return n.stop();
                                }
                            }, o);
                        })));
                    },
                    onComplete: function() {
                        this.gotoPage("/pages/call_recode/call_recode");
                    },
                    onShowRewardTips: function() {
                        this.showTips("warning", this.tipsMessage[0]);
                    },
                    showTips: function(t, a) {
                        var e = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : 0, n = arguments.length > 3 && void 0 !== arguments[3] && arguments[3], i = arguments.length > 4 && void 0 !== arguments[4] ? arguments[4] : null;
                        this.tipsObj.type = t, this.tipsObj.tipsType = e, this.tipsObj.message = a, this.tipsObj.cancel = n, 
                        this.tipsObj.confirm = i, this.refreshDate(), this.tipsVisible = !0;
                    },
                    onTipsSubmit: function() {
                        1 === this.tipsObj.tipsType && this.onApplication(this.taskData, !1), 2 === this.tipsObj.tipsType && this.onComplete(), 
                        3 === this.tipsObj.tipsType && this.gotoPage("/pages/team_detail/team_detail?id=".concat(this.bgConfig.teamId)), 
                        this.tipsVisible = !1;
                    },
                    formatN2Br: function(t) {
                        return t && t.replace(/\n/g, "<br/>");
                    },
                    gotoPage: function(t, a) {
                        console.log("页面跳转"), wx.navigateTo({
                            url: t
                        });
                    }
                }
            };
            a.default = m;
        }).call(this, e("543d").default);
    },
    8935: function(t, a, e) {
        e.d(a, "b", function() {
            return i;
        }), e.d(a, "c", function() {
            return r;
        }), e.d(a, "a", function() {
            return n;
        });
        var n = {
            uLineProgress: function() {
                return e.e("node-modules/uview-ui/components/u-line-progress/u-line-progress").then(e.bind(null, "1edd"));
            },
            uParse: function() {
                return Promise.all([ e.e("common/vendor"), e.e("node-modules/uview-ui/components/u-parse/u-parse") ]).then(e.bind(null, "492b"));
            },
            uMask: function() {
                return e.e("node-modules/uview-ui/components/u-mask/u-mask").then(e.bind(null, "f0fd"));
            }
        }, i = function() {
            var t = this, a = (t.$createElement, t._self._c, t.formatN2Br(t.bgConfig.tip)), e = t.formatN2Br(t.taskMessage.invitation), n = t.formatN2Br(t.tipsObj.message);
            t._isMounted || (t.e0 = function(a) {
                t.applicationVisible = !1;
            }, t.e1 = function(a) {
                t.applicationVisible = !1;
            }, t.e2 = function(a) {
                t.tipsVisible = !1;
            }, t.e3 = function(a) {
                t.tipsVisible = !1;
            }, t.e4 = function(a) {
                t.tipsObj.confirm ? t.tipsObj.confirm() : t.onTipsSubmit();
            }, t.e5 = function(a) {
                t.tipsObj.confirm ? t.tipsObj.confirm() : t.onTipsSubmit();
            }), t.$mp.data = Object.assign({}, {
                $root: {
                    m0: a,
                    m1: e,
                    m2: n
                }
            });
        }, r = [];
    },
    b646: function(t, a, e) {
        e.r(a);
        var n = e("5caf"), i = e.n(n);
        for (var r in n) [ "default" ].indexOf(r) < 0 && function(t) {
            e.d(a, t, function() {
                return n[t];
            });
        }(r);
        a.default = i.a;
    },
    dffa: function(t, a, e) {
        var n = e("1f90");
        e.n(n).a;
    },
    eada: function(t, a, e) {
        e.r(a);
        var n = e("8935"), i = e("b646");
        for (var r in i) [ "default" ].indexOf(r) < 0 && function(t) {
            e.d(a, t, function() {
                return i[t];
            });
        }(r);
        e("dffa");
        var o = e("f0c5"), s = Object(o.a)(i.default, n.b, n.c, !1, null, "6ba1fd32", null, !1, n.a, void 0);
        a.default = s.exports;
    }
}, [ [ "2489", "common/runtime", "common/vendor" ] ] ]);