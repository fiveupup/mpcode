require("../../@babel/runtime/helpers/Arrayincludes"), (global.webpackJsonp = global.webpackJsonp || []).push([ [ "pages/crmActivity/index" ], {
    "083d": function(t, e, n) {
        (function(t) {
            n("6cdc"), a(n("66fd"));
            var e = a(n("20a2"));
            function a(t) {
                return t && t.__esModule ? t : {
                    default: t
                };
            }
            wx.__webpack_require_UNI_MP_PLUGIN__ = n, t(e.default);
        }).call(this, n("543d").createPage);
    },
    1477: function(t, e, n) {
        var a = n("54d1");
        n.n(a).a;
    },
    "20a2": function(t, e, n) {
        n.r(e);
        var a = n("5eb1"), i = n("642a");
        for (var o in i) [ "default" ].indexOf(o) < 0 && function(t) {
            n.d(e, t, function() {
                return i[t];
            });
        }(o);
        n("1477");
        var s = n("f0c5"), r = Object(s.a)(i.default, a.b, a.c, !1, null, "5b89c98c", null, !1, a.a, void 0);
        e.default = r.exports;
    },
    "54d1": function(t, e, n) {},
    "5de1": function(t, e, n) {
        (function(t) {
            Object.defineProperty(e, "__esModule", {
                value: !0
            }), e.default = void 0;
            var a = r(n("4795")), i = r(n("05b9")), o = n("f55f"), s = n("403a");
            function r(t) {
                return t && t.__esModule ? t : {
                    default: t
                };
            }
            function c(t, e) {
                var n = Object.keys(t);
                if (Object.getOwnPropertySymbols) {
                    var a = Object.getOwnPropertySymbols(t);
                    e && (a = a.filter(function(e) {
                        return Object.getOwnPropertyDescriptor(t, e).enumerable;
                    })), n.push.apply(n, a);
                }
                return n;
            }
            function u(t) {
                for (var e = 1; e < arguments.length; e++) {
                    var n = null != arguments[e] ? arguments[e] : {};
                    e % 2 ? c(Object(n), !0).forEach(function(e) {
                        p(t, e, n[e]);
                    }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(t, Object.getOwnPropertyDescriptors(n)) : c(Object(n)).forEach(function(e) {
                        Object.defineProperty(t, e, Object.getOwnPropertyDescriptor(n, e));
                    });
                }
                return t;
            }
            function p(t, e, n) {
                return e in t ? Object.defineProperty(t, e, {
                    value: n,
                    enumerable: !0,
                    configurable: !0,
                    writable: !0
                }) : t[e] = n, t;
            }
            function d(t, e, n, a, i, o, s) {
                try {
                    var r = t[o](s), c = r.value;
                } catch (t) {
                    return void n(t);
                }
                r.done ? e(c) : Promise.resolve(c).then(a, i);
            }
            function l(t) {
                return function() {
                    var e = this, n = arguments;
                    return new Promise(function(a, i) {
                        var o = t.apply(e, n);
                        function s(t) {
                            d(o, a, i, s, r, "next", t);
                        }
                        function r(t) {
                            d(o, a, i, s, r, "throw", t);
                        }
                        s(void 0);
                    });
                };
            }
            var f = {
                data: function() {
                    return {
                        activityId: null,
                        loading: !0,
                        activityEnable: 0,
                        canJoin: !1,
                        canReceive: !0,
                        hasUndoneTask: !1,
                        info: {},
                        ruleDescription: "",
                        jumpRule: !1,
                        taskList: [],
                        invitationCount: 0,
                        endTime: "",
                        tipsVisible: !1,
                        currentTask: {},
                        tipsObj: {
                            confirmType: 0
                        },
                        currentDate: "",
                        loginData: {}
                    };
                },
                onLoad: function(e) {
                    this.activityId = Number(e.id), this.jumpRule = "1" === e.rule;
                    var n = t.getStorageSync("loginData2");
                    this.loginData = n ? JSON.parse(n) : {};
                },
                onShow: function() {
                    this.loadData(), this.loadIsApplyActivity();
                },
                methods: {
                    loadIsApplyActivity: function() {
                        var t = this;
                        return l(a.default.mark(function e() {
                            var n, i;
                            return a.default.wrap(function(e) {
                                for (;;) switch (e.prev = e.next) {
                                  case 0:
                                    return e.next = 2, (0, o.undoTask)();

                                  case 2:
                                    n = e.sent, i = n.data, t.hasUndoneTask = !!i.data;

                                  case 5:
                                  case "end":
                                    return e.stop();
                                }
                            }, e);
                        }))();
                    },
                    loadData: function() {
                        var e = arguments, n = this;
                        return l(a.default.mark(function i() {
                            var s, r, c, u, p, d;
                            return a.default.wrap(function(a) {
                                for (;;) switch (a.prev = a.next) {
                                  case 0:
                                    return (!(e.length > 0 && void 0 !== e[0]) || e[0]) && (t.showLoading({
                                        title: "加载中...",
                                        mask: !0
                                    }), n.loading = !0), a.next = 4, (0, o.activity)(n.activityId);

                                  case 4:
                                    if (r = a.sent, c = r.data, console.log("res: ", c), n.info = {
                                        id: c.data.id,
                                        activityName: c.data.specialActivityName,
                                        bgImgUrl: c.data.activityBackgroundImage,
                                        taskMarginTop: c.data.taskMarginTop,
                                        tipsJson: n._parseJson(c.data.tipsJson),
                                        applyTipsJson: n._parseJson(c.data.applyTipsJson),
                                        limitTipsJson: n._parseJson(c.data.limitTipsJson),
                                        invitationTipsJson: n._parseJson(c.data.invitationTipsJson),
                                        invitationEndTipsJson: n._parseJson(c.data.invitationEndJson),
                                        shoppingTipsJson: n._parseJson(c.data.shoppingTipsJson),
                                        checkinTipsJson: n._parseJson(c.data.checkinTipsJson),
                                        updateTipsJson: n._parseJson(c.data.updateTipsJson),
                                        receiveTipsJson: n._parseJson(c.data.receiveTipsJson),
                                        ruleBtnJson: n._parseJson(c.data.ruleBtnJson),
                                        popupConfig: n._parseJson(c.data.popupConfig)
                                    }, u = {
                                        invitation: {
                                            name: "邀新"
                                        },
                                        shopping: {
                                            name: "购物"
                                        },
                                        check_in: {
                                            name: "签到"
                                        }
                                    }, p = [], n.taskList = null === (s = c.data.activityTaskConfigurationResponseList) || void 0 === s ? void 0 : s.map(function(t) {
                                        var e, a;
                                        return 3 === t.taskRewardClaimWay && ("shopping" !== t.activityTaskType && t.rewardCouponId && p.push(t.rewardCouponId), 
                                        "shopping" === t.activityTaskType && t.goodsId && (d = t.goodsId)), "invitation" === t.activityTaskType && (n.endTime = t.inventoryEndTime), 
                                        {
                                            id: t.id,
                                            taskName: null === (e = u[t.activityTaskType]) || void 0 === e ? void 0 : e.name,
                                            taskType: t.activityTaskType,
                                            taskStatus: -1,
                                            bgImgUrl: t.taskBackgroundImage,
                                            applyNumJson: n._parseJson(t.registrationNumberConfiguration),
                                            applyCount: t.applyCount || 0,
                                            stockJson: n._parseJson(t.rewardInventoryConfiguration),
                                            stockCount: 0,
                                            invitationJson: n._parseJson(t.invitedNewPeopleConfiguration),
                                            applyBtnJson: n._parseJson(t.taskRegistrationButtonConfiguration),
                                            customBtnJson: n._parseJson(t.customButtonNameConfiguration),
                                            changeShopping: t.changeShoppingTaskSwitch,
                                            changeInvitation: t.changeInvitationTaskSwitch,
                                            drawType: t.taskRewardClaimWay,
                                            drawCount: t.drawCount,
                                            couponId: t.rewardCouponId,
                                            couponName: t.rewardCouponName,
                                            rewardList: (null === (a = t.taskTargetRewardResponseList) || void 0 === a ? void 0 : a.map(function(e) {
                                                return 2 === t.taskRewardClaimWay && e.couponId && p.push(e.couponId), {
                                                    id: e.id,
                                                    targetKey: e.targetKey,
                                                    targetValue: e.targetValue || 1,
                                                    couponId: e.couponId,
                                                    couponName: e.couponName,
                                                    bgImgUrl: e.rewardBackgroundImage,
                                                    stockJson: n._parseJson(e.rewardInventoryFieldConfiguration),
                                                    isReceived: e.isReceived || !1,
                                                    stockCount: 0,
                                                    progressJson: n._parseJson(e.progressBarConfiguration),
                                                    progressValue: e.progressValue || 0
                                                };
                                            })) || [],
                                            rewardIcons: n._parseJson(t.taskRewardIcon)
                                        };
                                    }), n.ruleDescription = c.data.ruleDescription, !n.jumpRule) {
                                        a.next = 16;
                                        break;
                                    }
                                    return n.jumpRule = !1, n.gotoPage("/pages/activity/rule"), a.abrupt("return");

                                  case 16:
                                    if (!(p.length > 0)) {
                                        a.next = 19;
                                        break;
                                    }
                                    return a.next = 19, n.loadStockData(p);

                                  case 19:
                                    if (!d) {
                                        a.next = 22;
                                        break;
                                    }
                                    return a.next = 22, n.loadGoodsStock(d);

                                  case 22:
                                    if (1 !== c.data.activityRestrictions) {
                                        a.next = 28;
                                        break;
                                    }
                                    return a.next = 25, n.loadMemberPermission();

                                  case 25:
                                    n.canJoin = a.sent, a.next = 29;
                                    break;

                                  case 28:
                                    n.canJoin = !0;

                                  case 29:
                                    if (!n.canJoin) {
                                        a.next = 32;
                                        break;
                                    }
                                    return a.next = 32, n.loadTaskInfo();

                                  case 32:
                                    n.refreshDate(), n.loading = !1, t.hideLoading();

                                  case 35:
                                  case "end":
                                    return a.stop();
                                }
                            }, i);
                        }))();
                    },
                    loadMemberPermission: function() {
                        var t = this;
                        return l(a.default.mark(function e() {
                            var n, i;
                            return a.default.wrap(function(e) {
                                for (;;) switch (e.prev = e.next) {
                                  case 0:
                                    return e.next = 2, (0, o.memberCanJoin)(t.activityId);

                                  case 2:
                                    return n = e.sent, i = n.data, e.abrupt("return", i.data || !1);

                                  case 5:
                                  case "end":
                                    return e.stop();
                                }
                            }, e);
                        }))();
                    },
                    loadTaskInfo: function() {
                        var t = this;
                        return l(a.default.mark(function e() {
                            var n, i;
                            return a.default.wrap(function(e) {
                                for (;;) switch (e.prev = e.next) {
                                  case 0:
                                    return e.next = 2, (0, o.applyTaskInfo)(t.activityId);

                                  case 2:
                                    n = e.sent, (i = n.data).data && (t.activityEnable = i.data.enable, t.taskList.forEach(function(t) {
                                        t.id === i.data.taskId ? t.taskStatus = i.data.taskStatus : t.taskStatus = -2;
                                    }), t.loadProgressData());

                                  case 5:
                                  case "end":
                                    return e.stop();
                                }
                            }, e);
                        }))();
                    },
                    loadStockData: function(t, e) {
                        var n = this;
                        return l(a.default.mark(function i() {
                            var s, r;
                            return a.default.wrap(function(a) {
                                for (;;) switch (a.prev = a.next) {
                                  case 0:
                                    return a.next = 2, (0, o.stockInfo)(Array.from(new Set(t)));

                                  case 2:
                                    if (s = a.sent, (r = s.data).data) {
                                        a.next = 6;
                                        break;
                                    }
                                    return a.abrupt("return");

                                  case 6:
                                    n.taskList.forEach(function(t) {
                                        if (3 === t.drawType) {
                                            var n = r.data.find(function(e) {
                                                return e.coupeId === t.couponId;
                                            });
                                            !n || e && t.id !== e || (t.stockCount = n.inventory);
                                        }
                                        if (2 === t.drawType) {
                                            var a = 0;
                                            t.rewardList.forEach(function(t) {
                                                var e = r.data.find(function(e) {
                                                    return e.coupeId === t.couponId;
                                                });
                                                e && (t.stockCount = e.inventory, a += e.inventory);
                                            }), e && t.id !== e || (t.stockCount = a);
                                        }
                                    });

                                  case 7:
                                  case "end":
                                    return a.stop();
                                }
                            }, i);
                        }))();
                    },
                    loadGoodsStock: function(t) {
                        var e = this;
                        return l(a.default.mark(function n() {
                            var i, s;
                            return a.default.wrap(function(n) {
                                for (;;) switch (n.prev = n.next) {
                                  case 0:
                                    return n.next = 2, (0, o.goodsStockInfo)(t);

                                  case 2:
                                    i = n.sent, (s = i.data).data && e.taskList.forEach(function(t) {
                                        "shopping" === t.taskType && (t.stockCount = s.data || 0);
                                    });

                                  case 5:
                                  case "end":
                                    return n.stop();
                                }
                            }, n);
                        }))();
                    },
                    loadProgressData: function() {
                        var t = this;
                        return l(a.default.mark(function e() {
                            var n, i;
                            return a.default.wrap(function(e) {
                                for (;;) switch (e.prev = e.next) {
                                  case 0:
                                    return e.next = 2, (0, o.progressInfo)(t.activityId);

                                  case 2:
                                    n = e.sent, (i = n.data).data && (t.invitationCount = i.data.invitationCount || 0, 
                                    t.taskList.forEach(function(e) {
                                        2 === e.drawType && e.rewardList.forEach(function(n) {
                                            var a, o = null === (a = i.data.taskTargetRewardResponseList) || void 0 === a ? void 0 : a.find(function(t) {
                                                return t.id === n.id;
                                            });
                                            o && (n.progressValue = o.progressValue, n.isReceived = o.isReceived, 1 === e.drawCount && o.isReceived && (t.canReceive = !1));
                                        });
                                    }));

                                  case 5:
                                  case "end":
                                    return e.stop();
                                }
                            }, e);
                        }))();
                    },
                    checkLimit: function() {
                        return !!this.canJoin || (this.showTips(this.info.limitTipsJson), !1);
                    },
                    checkJoinActivity: function(t) {
                        var e = this, n = !(arguments.length > 1 && void 0 !== arguments[1]) || arguments[1];
                        return !n || !this.hasUndoneTask || (this.showTips(this.info.applyTipsJson, function() {
                            e.onApplyTask(t, !1);
                        }), !1);
                    },
                    getCurrentTask: function(e) {
                        var n = this;
                        return l(a.default.mark(function i() {
                            var o;
                            return a.default.wrap(function(a) {
                                for (;;) switch (a.prev = a.next) {
                                  case 0:
                                    if (t.showLoading({
                                        title: "加载中...",
                                        mask: !0
                                    }), n.currentTask = e, "edit" === e.type ? o = n.info.updateTipsJson : "invitation" === e.taskType ? o = n.info.invitationTipsJson : "shopping" === e.taskType ? o = n.info.shoppingTipsJson : "check_in" === e.taskType && (o = n.info.checkinTipsJson), 
                                    3 !== e.drawType) {
                                        a.next = 13;
                                        break;
                                    }
                                    if ("shopping" !== e.taskType) {
                                        a.next = 9;
                                        break;
                                    }
                                    return a.next = 7, n.loadGoodsStock(e.goodsId);

                                  case 7:
                                    a.next = 11;
                                    break;

                                  case 9:
                                    return a.next = 11, n.loadStockData([ e.couponId ], e.id);

                                  case 11:
                                    a.next = 16;
                                    break;

                                  case 13:
                                    if (2 !== e.drawType) {
                                        a.next = 16;
                                        break;
                                    }
                                    return a.next = 16, n.loadStockData(e.rewardList.map(function(t) {
                                        return t.couponId;
                                    }), e.id);

                                  case 16:
                                    t.hideLoading(), n.showTips(o, function() {
                                        n.tipsVisible = !1, n.onSubmit();
                                    });

                                  case 18:
                                  case "end":
                                    return a.stop();
                                }
                            }, i);
                        }))();
                    },
                    onApplyTask: function(e) {
                        var n = !(arguments.length > 1 && void 0 !== arguments[1]) || arguments[1];
                        if (-1 === e.taskStatus) (1 === e.drawType || e.stockCount > 0) && this.checkLimit() && this.checkJoinActivity(e, n) && (e.type = "add", 
                        this.getCurrentTask(e)); else if (2 === e.taskStatus) this.gotoPage("/pages/coupon/coupon?index=1"); else if ([ 0, 1 ].includes(e.taskStatus)) {
                            if (1 === this.activityEnable) return void t.showToast({
                                title: "已参与其他活动，该活动已中止。",
                                icon: "none"
                            });
                            this.onComplete(e);
                        }
                    },
                    onChangeTask: function(e) {
                        var n = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : "shopping", a = this.taskList.find(function(t) {
                            return t.taskType === n;
                        });
                        a.stockCount > 0 ? (a.type = "edit", a.originalId = e, this.getCurrentTask(a)) : t.showToast({
                            title: "库存不足",
                            icon: "none"
                        });
                    },
                    onSubmit: function() {
                        var e = this;
                        return l(a.default.mark(function n() {
                            var i, s, r, c, p, d, l, f;
                            return a.default.wrap(function(n) {
                                for (;;) switch (n.prev = n.next) {
                                  case 0:
                                    if (i = e.taskList.length > 1 ? e.currentTask.taskName : e.info.activityName, 1 === e.currentTask.drawType || e.currentTask.stockCount) {
                                        n.next = 4;
                                        break;
                                    }
                                    return e.showTips(u(u({}, e.info.applyTipsJson), {}, {
                                        icon: "error",
                                        text: '报名失败<br/><view class="task-name">'.concat(i, "</view><br/>当前任务库存不足"),
                                        cancel: !1,
                                        confirmType: 0
                                    })), n.abrupt("return");

                                  case 4:
                                    if (s = e.currentTask, r = s.type, c = s.originalId, p = s.id, t.showLoading({
                                        title: "加载中...",
                                        mask: !0
                                    }), "add" !== r) {
                                        n.next = 12;
                                        break;
                                    }
                                    return n.next = 9, (0, o.applyTask)(e.activityId, p);

                                  case 9:
                                    n.t0 = n.sent, n.next = 15;
                                    break;

                                  case 12:
                                    return n.next = 14, (0, o.changeTask)(e.activityId, c, p);

                                  case 14:
                                    n.t0 = n.sent;

                                  case 15:
                                    d = n.t0, l = d.data, e.hasUndoneTask = !1, t.hideLoading(), l.success ? (e.loadData(!1), 
                                    f = "add" === r ? "您已成功报名" : "您已成功更改任务为", e.showTips(u(u({}, e.info.applyTipsJson), {}, {
                                        icon: "success",
                                        text: "".concat(f, ' <br/> <view class="task-name">').concat(i, "</view> "),
                                        cancel: !1,
                                        confirmType: 3
                                    }), function() {
                                        e.tipsVisible = !1, e.onComplete(e.currentTask);
                                    })) : e.showTips(u(u({}, e.info.applyTipsJson), {}, {
                                        icon: "error",
                                        text: l.message,
                                        cancel: !1,
                                        confirmType: 0
                                    }));

                                  case 20:
                                  case "end":
                                    return n.stop();
                                }
                            }, n);
                        }))();
                    },
                    onReceiveAward: function(e, n) {
                        var i, s = this, r = this.info.receiveTipsJson, c = r.color, p = r.fontSize, d = r.text;
                        "INVITATION" === n.targetKey ? i = "邀新".concat(n.targetValue, "人") : "SIGN_TOTAL" === n.targetKey ? i = "累计签到".concat(n.targetValue, "天") : "SIGN_TO" === n.targetKey ? i = "连续签到".concat(n.targetValue, "天") : "COLLECT_CARDS_RARE" === n.targetKey ? i = "获得稀有卡" : "SHOP_TOTAL" === n.targetKey && (i = "累计购物".concat(n.targetValue, "元")), 
                        this.showTips(u(u({}, this.info.applyTipsJson), {}, {
                            icon: "warning",
                            text: "请确定领取<br/>" + '<view class="task-name">'.concat(i, "奖励</view>") + (1 === e.drawCount ? '<br/> <view style="color:'.concat(c, "; font-size:").concat(p, 'rpx;">').concat(d, "</view>") : ""),
                            cancel: !0
                        }), l(a.default.mark(function e() {
                            var r, c;
                            return a.default.wrap(function(e) {
                                for (;;) switch (e.prev = e.next) {
                                  case 0:
                                    return t.showLoading({
                                        title: "加载中...",
                                        mask: !0
                                    }), e.next = 3, (0, o.receiveReward)(n.id);

                                  case 3:
                                    r = e.sent, c = r.data, t.hideLoading(), c.data.result ? (s.loadData(!1), s.showTips(u(u({}, s.info.applyTipsJson), {}, {
                                        icon: "success",
                                        text: "您已领取<br/>" + '<view class="task-name">'.concat(i, "奖励</view><br/> ") + "请在“我的优惠券”中查看奖励",
                                        cancel: !1,
                                        confirmType: 0
                                    }), function() {
                                        return s.gotoPage("/pages/coupon/coupon?index=1");
                                    })) : s.showTips(u(u({}, s.info.applyTipsJson), {}, {
                                        icon: "error",
                                        text: "领取失败<br/>" + c.data.msg,
                                        cancel: !1,
                                        confirmType: 0
                                    }));

                                  case 7:
                                  case "end":
                                    return e.stop();
                                }
                            }, e);
                        })));
                    },
                    onComplete: function(t) {
                        var e = this;
                        switch (t.taskType) {
                          case "shopping":
                            this.gotoPage("/pages/coupon/coupon?index=1");
                            break;

                          case "check_in":
                            this.gotoPage("/pages/task_center/task_center");
                            break;

                          case "invitation":
                            1 !== t.drawType && 0 === t.stockCount && this.endTime ? this.showTips(this.info.invitationEndTipsJson, function() {
                                e.gotoPage("/pages/team_detail/team_detail?id=".concat(e.tipsObj.teamId));
                            }) : this.gotoPage("/pages/call_recode/call_recode");
                        }
                    },
                    onShowRewardTips: function() {
                        this.showTips(u(u({}, this.info.applyTipsJson), {}, {
                            icon: "warning",
                            text: this.canReceive ? "宝子的任务还未完成，请继续努力~" : "您已领取奖励，该任务仅可领取一份奖励，请详阅活动规则~",
                            cancel: !1,
                            confirmType: 0
                        }));
                    },
                    showTips: function(t) {
                        var e = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : null;
                        this.tipsObj = u({}, t), this.tipsObj.confirm = e, this.refreshDate(), this.tipsVisible = !0;
                    },
                    refreshDate: function() {
                        this.currentDate = (0, i.default)().format("YYYY-MM-DD HH:mm:ss");
                    },
                    onCustomJump: function(e) {
                        console.log("自定义跳转", e);
                        var n = e.jumpType, a = e.appId, i = e.activityGuideUrl, o = e.articleId;
                        if (0 === n) t.navigateTo({
                            url: "/pages/webview/index?url=" + encodeURIComponent(i)
                        }); else if (1 === n) if (a === s.APPID) {
                            if ("/pages/crmActivity/index" === i) return void this.gotoPagePower(i);
                            [ "/pages/index/index", "/pages/gift/gift", "/pages/team/team" ].includes(i) ? t.switchTab({
                                url: i
                            }) : t.navigateTo({
                                url: i
                            });
                        } else wx.navigateToMiniProgram({
                            appId: a,
                            path: i,
                            envVersion: "release",
                            success: function(t) {
                                console.log("跳转小程序成功");
                            }
                        }); else 2 === n && t.navigateTo({
                            url: "/pages/team_detail/team_detail?id=" + o
                        });
                    },
                    formatN2Br: function(t) {
                        return t && t.replace(/\n/g, "<br/>").replace("${endTime}", this.endTime || (0, 
                        i.default)(Date.now()).format("YYYY-MM-DD HH:mm:ss"));
                    },
                    _parseJson: function(t) {
                        return t ? JSON.parse(t) : {};
                    },
                    gotoPage: function(t, e) {
                        console.log("页面跳转"), wx.navigateTo({
                            url: t
                        });
                    }
                }
            };
            e.default = f;
        }).call(this, n("543d").default);
    },
    "5eb1": function(t, e, n) {
        n.d(e, "b", function() {
            return i;
        }), n.d(e, "c", function() {
            return o;
        }), n.d(e, "a", function() {
            return a;
        });
        var a = {
            uLineProgress: function() {
                return n.e("node-modules/uview-ui/components/u-line-progress/u-line-progress").then(n.bind(null, "1edd"));
            },
            uParse: function() {
                return Promise.all([ n.e("common/vendor"), n.e("node-modules/uview-ui/components/u-parse/u-parse") ]).then(n.bind(null, "492b"));
            },
            uMask: function() {
                return n.e("node-modules/uview-ui/components/u-mask/u-mask").then(n.bind(null, "f0fd"));
            }
        }, i = function() {
            var t = this, e = (t.$createElement, t._self._c, t.loading ? null : t.__map(t.taskList, function(e, n) {
                return {
                    $orig: t.__get_orig(e),
                    g0: [ 0, 1 ].includes(e.taskStatus),
                    g1: 1 === e.applyBtnJson.exist ? [ 0, 1 ].includes(e.taskStatus) : null,
                    g2: [ -1, -2 ].includes(e.taskStatus)
                };
            })), n = t.loading ? null : t.formatN2Br(t.info.tipsJson.text), a = t.formatN2Br(t.tipsObj.text);
            t._isMounted || (t.e0 = function(e) {
                t.tipsVisible = !1;
            }, t.e1 = function(e) {
                t.tipsVisible = !1;
            }, t.e2 = function(e) {
                t.tipsObj.confirm ? t.tipsObj.confirm() : t.tipsVisible = !1;
            }, t.e3 = function(e) {
                t.tipsObj.confirm ? t.tipsObj.confirm() : t.tipsVisible = !1;
            }), t.$mp.data = Object.assign({}, {
                $root: {
                    l0: e,
                    m0: n,
                    m1: a
                }
            });
        }, o = [];
    },
    "642a": function(t, e, n) {
        n.r(e);
        var a = n("5de1"), i = n.n(a);
        for (var o in a) [ "default" ].indexOf(o) < 0 && function(t) {
            n.d(e, t, function() {
                return a[t];
            });
        }(o);
        e.default = i.a;
    }
}, [ [ "083d", "common/runtime", "common/vendor" ] ] ]);