(global.webpackJsonp = global.webpackJsonp || []).push([ [ "pages/address/address" ], {
    "1ed5": function(e, t, n) {
        var r = n("6374");
        n.n(r).a;
    },
    "22e6": function(e, t, n) {
        n.r(t);
        var r = n("4caf"), a = n("2ce5");
        for (var o in a) [ "default" ].indexOf(o) < 0 && function(e) {
            n.d(t, e, function() {
                return a[e];
            });
        }(o);
        n("1ed5");
        var s = n("f0c5"), d = Object(s.a)(a.default, r.b, r.c, !1, null, "5fbf3bb1", null, !1, r.a, void 0);
        t.default = d.exports;
    },
    "2ce5": function(e, t, n) {
        n.r(t);
        var r = n("b0de"), a = n.n(r);
        for (var o in r) [ "default" ].indexOf(o) < 0 && function(e) {
            n.d(t, e, function() {
                return r[e];
            });
        }(o);
        t.default = a.a;
    },
    "4caf": function(e, t, n) {
        n.d(t, "b", function() {
            return a;
        }), n.d(t, "c", function() {
            return o;
        }), n.d(t, "a", function() {
            return r;
        });
        var r = {
            uSwipeAction: function() {
                return n.e("node-modules/uview-ui/components/u-swipe-action/u-swipe-action").then(n.bind(null, "82c1"));
            },
            uModal: function() {
                return n.e("node-modules/uview-ui/components/u-modal/u-modal").then(n.bind(null, "f29e"));
            },
            uToast: function() {
                return n.e("node-modules/uview-ui/components/u-toast/u-toast").then(n.bind(null, "446f"));
            }
        }, a = function() {
            var e = this;
            e.$createElement;
            e._self._c, e._isMounted || (e.e0 = function(t, n) {
                var r = arguments[arguments.length - 1].currentTarget.dataset, a = r.eventParams || r["event-params"];
                return n = a.index, t.stopPropagation(), e.editEven(n);
            });
        }, o = [];
    },
    6374: function(e, t, n) {},
    b0de: function(e, t, n) {
        (function(e) {
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = void 0;
            var r = function(e) {
                return e && e.__esModule ? e : {
                    default: e
                };
            }(n("4795")), a = n("7b12");
            function o(e, t) {
                var n = Object.keys(e);
                if (Object.getOwnPropertySymbols) {
                    var r = Object.getOwnPropertySymbols(e);
                    t && (r = r.filter(function(t) {
                        return Object.getOwnPropertyDescriptor(e, t).enumerable;
                    })), n.push.apply(n, r);
                }
                return n;
            }
            function s(e) {
                for (var t = 1; t < arguments.length; t++) {
                    var n = null != arguments[t] ? arguments[t] : {};
                    t % 2 ? o(Object(n), !0).forEach(function(t) {
                        d(e, t, n[t]);
                    }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(n)) : o(Object(n)).forEach(function(t) {
                        Object.defineProperty(e, t, Object.getOwnPropertyDescriptor(n, t));
                    });
                }
                return e;
            }
            function d(e, t, n) {
                return t in e ? Object.defineProperty(e, t, {
                    value: n,
                    enumerable: !0,
                    configurable: !0,
                    writable: !0
                }) : e[t] = n, e;
            }
            function c(e, t, n, r, a, o, s) {
                try {
                    var d = e[o](s), c = d.value;
                } catch (e) {
                    return void n(e);
                }
                d.done ? t(c) : Promise.resolve(c).then(r, a);
            }
            function i(e) {
                return function() {
                    var t = this, n = arguments;
                    return new Promise(function(r, a) {
                        var o = e.apply(t, n);
                        function s(e) {
                            c(o, r, a, s, d, "next", e);
                        }
                        function d(e) {
                            c(o, r, a, s, d, "throw", e);
                        }
                        s(void 0);
                    });
                };
            }
            var u = {
                data: function() {
                    return {
                        clearId: "",
                        comfirmShow: !1,
                        content: "确认要删除此地址？",
                        addressList: [],
                        addressArray: [],
                        chooseAddr: "",
                        obj: {},
                        show: !1,
                        options: [ {
                            text: "删除",
                            style: {
                                backgroundColor: "#dd524d"
                            }
                        } ]
                    };
                },
                onShow: function() {
                    this.getAddressList();
                },
                onLoad: function(e) {
                    e.chooseAddr && (this.chooseAddr = e.chooseAddr);
                },
                methods: {
                    confirm: function() {
                        var t = this;
                        return i(r.default.mark(function n() {
                            var o, s;
                            return r.default.wrap(function(n) {
                                for (;;) switch (n.prev = n.next) {
                                  case 0:
                                    return console.log("确定删除"), e.showLoading({
                                        mask: !0
                                    }), o = t.clearId, n.next = 5, (0, a.deleteAddress)(o);

                                  case 5:
                                    s = n.sent, e.hideLoading(), "00000" == s.data.code && (t.addressList = [], t.getAddressList());

                                  case 8:
                                  case "end":
                                    return n.stop();
                                }
                            }, n);
                        }))();
                    },
                    click: function(e) {
                        this.clearId = e.deliveryAddressId, this.comfirmShow = !0;
                    },
                    saveAddress: function() {
                        var t = this;
                        return i(r.default.mark(function n() {
                            var o, s, d, c, i;
                            return r.default.wrap(function(n) {
                                for (;;) switch (n.prev = n.next) {
                                  case 0:
                                    console.log("新增地址", t.obj), o = t.obj, s = "";
                                    try {
                                        (d = (d = e.getStorageSync("loginData2")) ? JSON.parse(d) : {}).memberId && (s = d.memberId);
                                    } catch (e) {}
                                    if (/^[1][3,4,5,6,7,8,9][0-9]{9}$/.test(o.consigneeNumber)) {
                                        n.next = 8;
                                        break;
                                    }
                                    return t.showToast("手机号不正确！", "error"), n.abrupt("return");

                                  case 8:
                                    return c = {
                                        areaId: o.areaId || "",
                                        areaName: o.areaName || "",
                                        cityId: o.cityId || "",
                                        cityName: o.cityName || "",
                                        consigneeName: o.consigneeName,
                                        consigneeNumber: o.consigneeNumber,
                                        deliveryAddress: o.deliveryAddress,
                                        deliveryAddressId: o.deliveryAddressId,
                                        isDefaltAddress: 0,
                                        memberId: s,
                                        provinceId: o.provinceId || "",
                                        provinceName: o.provinceName || "",
                                        streetId: o.streetId || "",
                                        streetName: o.streetName || "",
                                        tag: ""
                                    }, n.next = 11, (0, a.saveAddAddress)(c);

                                  case 11:
                                    i = n.sent, console.log("新增地址结果", i), "00000" == i.data.code && t.getAddressList();

                                  case 14:
                                  case "end":
                                    return n.stop();
                                }
                            }, n);
                        }))();
                    },
                    getByNameFromId: function(e) {
                        var t = this;
                        return i(r.default.mark(function n() {
                            var o, d;
                            return r.default.wrap(function(n) {
                                for (;;) switch (n.prev = n.next) {
                                  case 0:
                                    return o = {
                                        provinceName: e.provinceName,
                                        cityName: e.cityName,
                                        areaName: e.areaName,
                                        deliveryAddress: e.deliveryAddress
                                    }, n.next = 3, (0, a.getByName)(o);

                                  case 3:
                                    d = n.sent, console.log("地址查询id", d), "00000" == d.data.code && (t.obj = s(s({}, t.obj), d.data.data), 
                                    t.saveAddress(), console.log("this.obj", t.obj));

                                  case 6:
                                  case "end":
                                    return n.stop();
                                }
                            }, n);
                        }))();
                    },
                    getWechetAddress: function() {
                        var e = this;
                        wx.chooseAddress({
                            success: function(t) {
                                e.obj = {
                                    provinceName: t.provinceName,
                                    cityName: t.cityName,
                                    areaName: t.countyName,
                                    deliveryAddress: t.detailInfo,
                                    consigneeName: t.userName,
                                    consigneeNumber: t.telNumber
                                }, e.getByNameFromId(e.obj);
                            }
                        });
                    },
                    editEven: function(e) {
                        console.log("编辑地址-选中第几个", e);
                        var t = JSON.stringify(this.addressList[e]);
                        wx.navigateTo({
                            url: "/pages/address_add/address_add",
                            success: function(e) {
                                e.eventChannel.emit("acceptDataFromOpenerPage", {
                                    addressList: t
                                });
                            }
                        });
                    },
                    handleChooseAddress: function(t) {
                        if (this.chooseAddr) {
                            var n = getCurrentPages(), r = n[n.length - 2];
                            r.$vm.chooseAddressBack = !0, r.$vm.address = t, console.log("选择了地址", r), e.navigateBack();
                        }
                    },
                    gotoPage: function(e) {
                        wx.navigateTo({
                            url: e,
                            success: function(e) {
                                e.eventChannel.emit("acceptDataFromOpenerPage", {
                                    data: "test"
                                });
                            }
                        });
                    },
                    getAddressList: function() {
                        var e = this;
                        return i(r.default.mark(function t() {
                            var n;
                            return r.default.wrap(function(t) {
                                for (;;) switch (t.prev = t.next) {
                                  case 0:
                                    return t.next = 2, (0, a.listAddressList)();

                                  case 2:
                                    n = t.sent, console.log("查询地址结果", n), "00000" == n.data.code && (e.addressList = n.data.data, 
                                    e.addressList.forEach(function(e) {
                                        e.address = e.provinceName + e.cityName + e.areaName + (e.streetName || "") + e.deliveryAddress;
                                    }), console.log("查询地址结果--列表", e.addressArray));

                                  case 5:
                                  case "end":
                                    return t.stop();
                                }
                            }, t);
                        }))();
                    },
                    showToast: function(e, t) {
                        this.$refs.uToast.show({
                            title: e,
                            type: t
                        });
                    }
                }
            };
            t.default = u;
        }).call(this, n("543d").default);
    },
    f29c: function(e, t, n) {
        (function(e) {
            n("6cdc"), r(n("66fd"));
            var t = r(n("22e6"));
            function r(e) {
                return e && e.__esModule ? e : {
                    default: e
                };
            }
            wx.__webpack_require_UNI_MP_PLUGIN__ = n, e(t.default);
        }).call(this, n("543d").createPage);
    }
}, [ [ "f29c", "common/runtime", "common/vendor" ] ] ]);