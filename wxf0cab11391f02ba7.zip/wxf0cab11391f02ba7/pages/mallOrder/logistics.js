(global.webpackJsonp = global.webpackJsonp || []).push([ [ "pages/mallOrder/logistics" ], {
    4515: function(e, n, t) {
        var r = t("5a9d");
        t.n(r).a;
    },
    "52f8": function(e, n, t) {
        t.r(n);
        var r = t("ee8f"), o = t.n(r);
        for (var a in r) [ "default" ].indexOf(a) < 0 && function(e) {
            t.d(n, e, function() {
                return r[e];
            });
        }(a);
        n.default = o.a;
    },
    "5a9d": function(e, n, t) {},
    b1a4: function(e, n, t) {
        (function(e) {
            t("6cdc"), r(t("66fd"));
            var n = r(t("b34e"));
            function r(e) {
                return e && e.__esModule ? e : {
                    default: e
                };
            }
            wx.__webpack_require_UNI_MP_PLUGIN__ = t, e(n.default);
        }).call(this, t("543d").createPage);
    },
    b34e: function(e, n, t) {
        t.r(n);
        var r = t("f0fc"), o = t("52f8");
        for (var a in o) [ "default" ].indexOf(a) < 0 && function(e) {
            t.d(n, e, function() {
                return o[e];
            });
        }(a);
        t("4515");
        var u = t("f0c5"), f = Object(u.a)(o.default, r.b, r.c, !1, null, "0ca5a2b2", null, !1, r.a, void 0);
        n.default = f.exports;
    },
    ee8f: function(e, n, t) {
        Object.defineProperty(n, "__esModule", {
            value: !0
        }), n.default = void 0;
        var r = function(e) {
            return e && e.__esModule ? e : {
                default: e
            };
        }(t("4795")), o = t("830d"), a = t("d1f8");
        function u(e, n, t, r, o, a, u) {
            try {
                var f = e[a](u), i = f.value;
            } catch (e) {
                return void t(e);
            }
            f.done ? n(i) : Promise.resolve(i).then(r, o);
        }
        var f = {
            data: function() {
                return {
                    orderSn: "",
                    expressCompanyName: "",
                    expressNo: "",
                    expressInfos: []
                };
            },
            onLoad: function(e) {
                this.orderSn = e.orderSn, this.loadData(e);
            },
            methods: {
                loadData: function(e) {
                    var n = this;
                    return function(e) {
                        return function() {
                            var n = this, t = arguments;
                            return new Promise(function(r, o) {
                                var a = e.apply(n, t);
                                function f(e) {
                                    u(a, r, o, f, i, "next", e);
                                }
                                function i(e) {
                                    u(a, r, o, f, i, "throw", e);
                                }
                                f(void 0);
                            });
                        };
                    }(r.default.mark(function t() {
                        var u, f, i;
                        return r.default.wrap(function(t) {
                            for (;;) switch (t.prev = t.next) {
                              case 0:
                                return t.next = 2, "point" === e.type ? (0, o.getOrderLogistics)(n.orderSn) : (0, 
                                a.getOrderLogistics)(n.orderSn);

                              case 2:
                                u = t.sent, f = u.data, console.log("res: ", f), i = f.data.expressInfo, n.expressInfos = (null == i ? void 0 : i.progressInfos) || [], 
                                n.expressCompanyName = (null == i ? void 0 : i.expressCompanyName) || "", n.expressNo = null == i ? void 0 : i.expressNo;

                              case 9:
                              case "end":
                                return t.stop();
                            }
                        }, t);
                    }))();
                }
            }
        };
        n.default = f;
    },
    f0fc: function(e, n, t) {
        t.d(n, "b", function() {
            return r;
        }), t.d(n, "c", function() {
            return o;
        }), t.d(n, "a", function() {});
        var r = function() {
            this.$createElement;
            this._self._c;
        }, o = [];
    }
}, [ [ "b1a4", "common/runtime", "common/vendor" ] ] ]);