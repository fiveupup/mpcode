(global.webpackJsonp = global.webpackJsonp || []).push([ [ "pages/mallOrder/mallOrder" ], {
    2702: function(t, e, n) {
        n.r(e);
        var o = n("507c"), a = n.n(o);
        for (var r in o) [ "default" ].indexOf(r) < 0 && function(t) {
            n.d(e, t, function() {
                return o[t];
            });
        }(r);
        e.default = a.a;
    },
    "507c": function(t, e, n) {
        (function(t) {
            Object.defineProperty(e, "__esModule", {
                value: !0
            }), e.default = void 0;
            var o = n("830d"), a = n("d1f8"), r = {
                data: function() {
                    return {
                        type: "point",
                        customStyle: {
                            padding: "12rpx 20rpx",
                            minWidth: "100rpx",
                            height: "60rpx",
                            fontSize: "26rpx",
                            marginLeft: "0",
                            marginRight: "10rpx"
                        },
                        customStyle1: {
                            width: "144rpx",
                            height: "60rpx",
                            fontSize: "26rpx",
                            marginLeft: "0",
                            marginRight: "10rpx",
                            padding: "12rpx 20rpx",
                            color: "#FFBC0D"
                        },
                        tabParams: {
                            memberNo: "",
                            pageSize: 10,
                            pageNum: 0
                        },
                        loadText: {
                            loadmore: "点击或上拉加载更多",
                            loading: "努力加载中",
                            nomore: "没有更多了"
                        },
                        curItemId: "",
                        loadStatus: "loadmore",
                        current: 0,
                        show: !1,
                        content: "是否确认已收到商品",
                        tablist: [ {
                            name: "全部"
                        }, {
                            name: "待发货"
                        }, {
                            name: "待收货"
                        } ],
                        member: {},
                        list: []
                    };
                },
                onReachBottom: function() {
                    console.log(11112222), "nomore" != this.loadStatus && (this.loadStatus = "loading", 
                    this.getList());
                },
                onLoad: function(t) {
                    this.type = t.type;
                },
                onShow: function() {
                    var e = t.getStorageSync("loginData2");
                    this.member = e ? JSON.parse(e) : {}, this.tabParams.memberNo = this.member.memberNo, 
                    this.getList();
                },
                methods: {
                    getStatus: function(t) {
                        switch (t) {
                          case "CONFIRM":
                            return "已确认";

                          case "WAIT_SHIP":
                            return "待发货";

                          case "WAIT_ROG":
                            return "待收货";

                          case "COMPLETE":
                            return "已完成";

                          case "CANCEL":
                            return "已取消，详情可询问客服";

                          default:
                            return "";
                        }
                    },
                    gotoPage: function(t, e) {
                        console.log("页面跳转"), e ? wx.reLaunch({
                            url: t
                        }) : wx.navigateTo({
                            url: t,
                            success: function(t) {
                                t.eventChannel.emit("acceptDataFromOpenerPage", {
                                    data: "test"
                                });
                            }
                        });
                    },
                    sign: function(t) {
                        console.log(t), this.show = !0, this.curItemId = t.orderSn;
                    },
                    getList: function() {
                        var t = this;
                        console.log(this.tabParams, "加载更多!"), this.tabParams.pageNum++, ("point" === this.type ? (0, 
                        o.getOrderList)(this.tabParams) : (0, a.getOrderList)(this.tabParams)).then(function(e) {
                            console.log(e.data.data, "orderlist"), e.data.data.list.length > 0 ? (e.data.data.list.length < t.tabParams.pageSize && (t.loadStatus = "nomore"), 
                            e.data.data.list.forEach(function(t) {
                                var e;
                                t.goods = JSON.parse(t.goodsJson || "{}"), t.goods.goodsImg = null === (e = t.goods.goodsImg) || void 0 === e ? void 0 : e.split(",")[0];
                            }), t.list = t.list.concat(e.data.data.list), console.log(t.list)) : t.loadStatus = "nomore";
                        });
                    },
                    change: function(t) {
                        switch (this.current = t, this.tabParams.pageNum = 0, this.list = [], this.loadStatus = "loadmore", 
                        t) {
                          case 0:
                            delete this.tabParams.orderStatus, this.getList();
                            break;

                          case 1:
                            this.tabParams.orderStatus = "WAIT_SHIP", this.getList();
                            break;

                          case 2:
                            this.tabParams.orderStatus = "WAIT_ROG", this.getList();
                        }
                    },
                    signOrder: function() {
                        var t = this;
                        console.log(this.curItemId), ("point" === this.type ? (0, o.orderSign)(this.curItemId) : (0, 
                        a.orderSign)(this.curItemId)).then(function(e) {
                            console.log(e.data.data), t.$refs.uToast.show({
                                title: "订单签收成功！",
                                type: "success"
                            }), t.show = !1, t.change(2);
                        });
                    }
                }
            };
            e.default = r;
        }).call(this, n("543d").default);
    },
    "75c3": function(t, e, n) {},
    "895a": function(t, e, n) {
        (function(t) {
            n("6cdc"), o(n("66fd"));
            var e = o(n("d8e2"));
            function o(t) {
                return t && t.__esModule ? t : {
                    default: t
                };
            }
            wx.__webpack_require_UNI_MP_PLUGIN__ = n, t(e.default);
        }).call(this, n("543d").createPage);
    },
    b38c: function(t, e, n) {
        n.d(e, "b", function() {
            return a;
        }), n.d(e, "c", function() {
            return r;
        }), n.d(e, "a", function() {
            return o;
        });
        var o = {
            uTabs: function() {
                return Promise.all([ n.e("common/vendor"), n.e("node-modules/uview-ui/components/u-tabs/u-tabs") ]).then(n.bind(null, "7418"));
            },
            uLoadmore: function() {
                return n.e("node-modules/uview-ui/components/u-loadmore/u-loadmore").then(n.bind(null, "bf89"));
            },
            uToast: function() {
                return n.e("node-modules/uview-ui/components/u-toast/u-toast").then(n.bind(null, "446f"));
            },
            uMask: function() {
                return n.e("node-modules/uview-ui/components/u-mask/u-mask").then(n.bind(null, "f0fd"));
            }
        }, a = function() {
            var t = this, e = (t.$createElement, t._self._c, t.list.length > 0 ? t.__map(t.list, function(e, n) {
                return {
                    $orig: t.__get_orig(e),
                    m0: t.getStatus(e.orderStatus)
                };
            }) : null);
            t._isMounted || (t.e0 = function(e) {
                t.show = !1;
            }, t.e1 = function(e) {
                t.show = !1;
            }, t.e2 = function(e) {
                return e.stopPropagation(), t.signOrder(e);
            }), t.$mp.data = Object.assign({}, {
                $root: {
                    l0: e
                }
            });
        }, r = [];
    },
    d8e2: function(t, e, n) {
        n.r(e);
        var o = n("b38c"), a = n("2702");
        for (var r in a) [ "default" ].indexOf(r) < 0 && function(t) {
            n.d(e, t, function() {
                return a[t];
            });
        }(r);
        n("e353");
        var i = n("f0c5"), s = Object(i.a)(a.default, o.b, o.c, !1, null, "2c51030d", null, !1, o.a, void 0);
        e.default = s.exports;
    },
    e353: function(t, e, n) {
        var o = n("75c3");
        n.n(o).a;
    }
}, [ [ "895a", "common/runtime", "common/vendor" ] ] ]);