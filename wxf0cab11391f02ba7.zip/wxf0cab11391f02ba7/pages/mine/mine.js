(global.webpackJsonp = global.webpackJsonp || []).push([ [ "pages/mine/mine" ], {
    "4b08": function(e, t, n) {
        var o = n("fc1e");
        n.n(o).a;
    },
    c239: function(e, t, n) {
        n.d(t, "b", function() {
            return a;
        }), n.d(t, "c", function() {
            return r;
        }), n.d(t, "a", function() {
            return o;
        });
        var o = {
            uIcon: function() {
                return n.e("node-modules/uview-ui/components/u-icon/u-icon").then(n.bind(null, "2925"));
            },
            uModal: function() {
                return n.e("node-modules/uview-ui/components/u-modal/u-modal").then(n.bind(null, "f29e"));
            },
            uToast: function() {
                return n.e("node-modules/uview-ui/components/u-toast/u-toast").then(n.bind(null, "446f"));
            },
            uPopup: function() {
                return n.e("node-modules/uview-ui/components/u-popup/u-popup").then(n.bind(null, "97cd"));
            },
            uSearch: function() {
                return n.e("node-modules/uview-ui/components/u-search/u-search").then(n.bind(null, "9586"));
            },
            uEmpty: function() {
                return n.e("node-modules/uview-ui/components/u-empty/u-empty").then(n.bind(null, "ab47"));
            }
        }, a = function() {
            var e = this;
            e.$createElement;
            e._self._c, e._isMounted || (e.e0 = function(t) {
                e.myInfo.nickname = t.target.value;
            });
        }, r = [];
    },
    c52e: function(e, t, n) {
        (function(e) {
            n("6cdc"), o(n("66fd"));
            var t = o(n("e550"));
            function o(e) {
                return e && e.__esModule ? e : {
                    default: e
                };
            }
            wx.__webpack_require_UNI_MP_PLUGIN__ = n, e(t.default);
        }).call(this, n("543d").createPage);
    },
    e018: function(e, t, n) {
        (function(e) {
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = void 0;
            var o = i(n("4795")), a = n("7b12"), r = n("b775"), c = i(n("05b9"));
            function i(e) {
                return e && e.__esModule ? e : {
                    default: e
                };
            }
            function s(e, t) {
                var n = Object.keys(e);
                if (Object.getOwnPropertySymbols) {
                    var o = Object.getOwnPropertySymbols(e);
                    t && (o = o.filter(function(t) {
                        return Object.getOwnPropertyDescriptor(e, t).enumerable;
                    })), n.push.apply(n, o);
                }
                return n;
            }
            function u(e) {
                for (var t = 1; t < arguments.length; t++) {
                    var n = null != arguments[t] ? arguments[t] : {};
                    t % 2 ? s(Object(n), !0).forEach(function(t) {
                        l(e, t, n[t]);
                    }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(n)) : s(Object(n)).forEach(function(t) {
                        Object.defineProperty(e, t, Object.getOwnPropertyDescriptor(n, t));
                    });
                }
                return e;
            }
            function l(e, t, n) {
                return t in e ? Object.defineProperty(e, t, {
                    value: n,
                    enumerable: !0,
                    configurable: !0,
                    writable: !0
                }) : e[t] = n, e;
            }
            function d(e, t, n, o, a, r, c) {
                try {
                    var i = e[r](c), s = i.value;
                } catch (e) {
                    return void n(e);
                }
                i.done ? t(s) : Promise.resolve(s).then(o, a);
            }
            function f(e) {
                return function() {
                    var t = this, n = arguments;
                    return new Promise(function(o, a) {
                        var r = e.apply(t, n);
                        function c(e) {
                            d(r, o, a, c, i, "next", e);
                        }
                        function i(e) {
                            d(r, o, a, c, i, "throw", e);
                        }
                        c(void 0);
                    });
                };
            }
            var h = {
                data: function() {
                    return {
                        outshow: !1,
                        show: !1,
                        content: "是否确定进行账户注销? 账户注销后，您在乐事心动社账号的个人信息将被删除，账号一旦注销完成，将无法恢复，请您谨慎操作!",
                        outContent: "确定要退出登录?",
                        index: 0,
                        addressIndex: 0,
                        schoolIndex: 0,
                        array: [ "未知", "男", "女" ],
                        schoolArray: [],
                        addressArray: [],
                        date: "",
                        dateDefault: "",
                        confirmDate: !1,
                        end: "",
                        myInfo: {
                            imageUrl: "",
                            nickname: ""
                        },
                        schoolList: [],
                        clauses: [],
                        loginData: {},
                        popupShow: !1,
                        schoolSearchValue: "",
                        schoolList_Search: [],
                        mySchoolName: "",
                        timerId: null
                    };
                },
                onLoad: function() {
                    this.getSchoolListEven(), this.getPrivacy(), this.chackMember();
                },
                onShow: function() {
                    var t = e.getStorageSync("loginData2");
                    this.loginData = t ? JSON.parse(t) : {}, this.end = (0, c.default)().format("YYYY-MM-DD"), 
                    console.log("当前日期", this.end), console.log("个人信息页面"), this.chackAddress();
                },
                onUnload: function() {
                    clearTimeout(this.timerId), console.log("销毁定时器, ", this.timerId);
                },
                methods: {
                    getSchoolListEven: function() {
                        var e = this;
                        return f(o.default.mark(function t() {
                            var n, r;
                            return o.default.wrap(function(t) {
                                for (;;) switch (t.prev = t.next) {
                                  case 0:
                                    return n = {
                                        name: ""
                                    }, t.next = 3, (0, a.getSchoolList)(n);

                                  case 3:
                                    r = t.sent, console.log("学校列表", r), "00000" == r.data.code && (r.data.data.forEach(function(t) {
                                        t.name && e.schoolArray.push(t);
                                    }), e.schoolList_Search = e.schoolArray.slice(0, 100));

                                  case 6:
                                  case "end":
                                    return t.stop();
                                }
                            }, t);
                        }))();
                    },
                    getPrivacy: function() {
                        var e = this;
                        return f(o.default.mark(function t() {
                            var n;
                            return o.default.wrap(function(t) {
                                for (;;) switch (t.prev = t.next) {
                                  case 0:
                                    return t.next = 2, (0, a.getClauses)();

                                  case 2:
                                    n = t.sent, console.log("已同意的条款", n), "00000" == n.data.code && (e.clauses = n.data.data || []);

                                  case 5:
                                  case "end":
                                    return t.stop();
                                }
                            }, t);
                        }))();
                    },
                    handleChooseAvatar: function(e) {
                        console.log(e);
                        var t = e.detail.avatarUrl, n = this;
                        wx.uploadFile({
                            url: (0, r.baseUrl)() + "member/blob/upload/blobUploadImg",
                            filePath: t,
                            name: "files",
                            formData: {
                                generateThumbnail: !1
                            },
                            success: function(e) {
                                var t = JSON.parse(e.data);
                                console.log(t, t.data.data[0].fileUrl), n.myInfo.imageUrl = t.data.data[0].fileUrl;
                            }
                        });
                    },
                    outLogin: function() {
                        console.log("退出登录"), this.outshow = !0;
                    },
                    outConfirm: function() {
                        return f(o.default.mark(function t() {
                            return o.default.wrap(function(t) {
                                for (;;) switch (t.prev = t.next) {
                                  case 0:
                                    return console.log("确定退出"), t.next = 3, (0, a.logout)();

                                  case 3:
                                    if ("00000" == t.sent.data.code) {
                                        try {
                                            e.removeStorageSync("loginData2"), e.showToast({
                                                title: "退出成功！",
                                                icon: "success"
                                            });
                                        } catch (e) {}
                                        setTimeout(function(e) {
                                            wx.reLaunch({
                                                url: "/pages/index/index"
                                            });
                                        }, 1e3);
                                    }

                                  case 5:
                                  case "end":
                                    return t.stop();
                                }
                            }, t);
                        }))();
                    },
                    clearInfo: function() {
                        this.show = !0;
                    },
                    confirm: function() {
                        var t = this;
                        return f(o.default.mark(function n() {
                            var r, c, i;
                            return o.default.wrap(function(n) {
                                for (;;) switch (n.prev = n.next) {
                                  case 0:
                                    return console.log("确定注销"), n.next = 3, (0, a.cancel)();

                                  case 3:
                                    if ("00000" == n.sent.data.code) {
                                        try {
                                            r = t.loginData, c = r.memberNo, i = r.phone, wx.reportEvent("unsubscribe", {
                                                member_no: c,
                                                phone: i
                                            }), e.removeStorageSync("loginData2"), e.showToast({
                                                title: "注销成功",
                                                icon: "success"
                                            });
                                        } catch (e) {}
                                        setTimeout(function(e) {
                                            wx.reLaunch({
                                                url: "/pages/index/index"
                                            });
                                        }, 1e3);
                                    }

                                  case 5:
                                  case "end":
                                    return n.stop();
                                }
                            }, n);
                        }))();
                    },
                    cancel: function() {
                        console.log("取消");
                    },
                    toAddressPage: function() {
                        console.log("点击箭头"), wx.navigateTo({
                            url: "/pages/address/address"
                        });
                    },
                    commit: function() {
                        var t = this;
                        return f(o.default.mark(function n() {
                            var r, c, i, s, u;
                            return o.default.wrap(function(n) {
                                for (;;) switch (n.prev = n.next) {
                                  case 0:
                                    r = "";
                                    try {
                                        (c = (c = e.getStorageSync("loginData2")) ? JSON.parse(c) : {}).memberId && (r = c.memberId);
                                    } catch (e) {}
                                    return i = {
                                        birthday: t.date,
                                        gender: t.index,
                                        memberId: r || "",
                                        nickname: t.myInfo.nickname,
                                        imageUrl: t.myInfo.imageUrl,
                                        schoolId: t.mySchoolId || "",
                                        schoolName: t.mySchoolName || ""
                                    }, n.next = 5, (0, a.updateInfo)(i);

                                  case 5:
                                    s = n.sent, console.log("更新会员信息", s), "00000" == s.data.code && (t.showToast("修改成功，修改后的资料将在5分钟后生效", "success"), 
                                    (u = s.data.data).token = t.loginData.token, e.setStorageSync("loginData2", JSON.stringify(u)), 
                                    t.confirmDate = !0, t.chackMember(), t.timerId = setTimeout(function(n) {
                                        console.log("timerId: ", t.timerId), 1 === getCurrentPages().length ? e.switchTab({
                                            url: "/pages/index/index"
                                        }) : e.navigateBack();
                                    }, 2e3));

                                  case 8:
                                  case "end":
                                    return n.stop();
                                }
                            }, n);
                        }))();
                    },
                    chackMember: function() {
                        var t = this;
                        return f(o.default.mark(function n() {
                            var r, i, s;
                            return o.default.wrap(function(n) {
                                for (;;) switch (n.prev = n.next) {
                                  case 0:
                                    return n.next = 2, (0, a.getInfo)();

                                  case 2:
                                    r = n.sent, console.log("获取会员信息", r), "00000" == r.data.code && (t.myInfo = r.data.data, 
                                    t.date = t.myInfo.birthday, t.date || (t.dateDefault = (0, c.default)().subtract(18, "years").format("YYYY") + "-01-01"), 
                                    t.confirmDate = !!t.date, t.index = null === (i = t.myInfo.gender) || void 0 === i ? void 0 : i.value, 
                                    t.mySchoolId = t.myInfo.schoolId, t.mySchoolName = t.myInfo.schoolName, s = JSON.stringify(r.data.data.memberDeliveryAddress), 
                                    e.setStorage({
                                        key: "memberDeliveryAddress",
                                        data: s
                                    }), e.setStorageSync("loginData2", JSON.stringify(u(u(u({}, t.loginData), r.data.data), {}, {
                                        phone: t.loginData.phone
                                    }))));

                                  case 5:
                                  case "end":
                                    return n.stop();
                                }
                            }, n);
                        }))();
                    },
                    chackAddress: function() {
                        var e = this;
                        return f(o.default.mark(function t() {
                            var n, r;
                            return o.default.wrap(function(t) {
                                for (;;) switch (t.prev = t.next) {
                                  case 0:
                                    return n = {
                                        name: ""
                                    }, t.next = 3, (0, a.listAddressList)(n);

                                  case 3:
                                    r = t.sent, console.log("地址列表", r), "00000" == r.data.code && (e.schoolList = r.data.data, 
                                    e.schoolList.forEach(function(t) {
                                        var n = (t.provinceName || "") + (t.cityName || "") + (t.areaName || "") + (t.streetName || "") + (t.deliveryAddress || "");
                                        e.addressArray.push(n), 1 === t.isDefaltAddress && (e.myInfo.memberDeliveryAddress = t);
                                    }));

                                  case 6:
                                  case "end":
                                    return t.stop();
                                }
                            }, t);
                        }))();
                    },
                    pickerChangeDate: function(e) {
                        console.log("picker发送选择改变，生日 携带值为", e.detail.value), this.date = e.detail.value;
                    },
                    bindPickerChangeAddress: function(e) {
                        console.log("地址选择", e), this.addressIndex = e.detail.value;
                    },
                    bindPickerChange: function(e) {
                        console.log("picker发送选择改变，性别携带值为", e.detail.value), this.index = e.detail.value;
                    },
                    showToast: function(e, t) {
                        this.$refs.uToast.show({
                            title: e,
                            type: t
                        });
                    },
                    openPopup: function() {
                        this.popupShow = !0;
                    },
                    openPopupCb: function() {
                        console.log("open");
                    },
                    changeSearch: function() {
                        this.$u.throttle(this.schoolSearchList, 400, !1);
                    },
                    schoolSearchList: function() {
                        var e = this;
                        if (console.log(" 学校搜索--------", this.schoolSearchValue), this.schoolSearchValue) {
                            var t = this.schoolArray.filter(function(t) {
                                return t.name.includes(e.schoolSearchValue);
                            });
                            this.schoolList_Search = t.slice(0, 100);
                        } else this.schoolList_Search = this.schoolArray.slice(0, 100);
                    },
                    clickSearchItem: function(e) {
                        this.mySchoolName = e.name, this.mySchoolId = e.id, this.schoolSearchValue = "", 
                        this.popupShow = !1;
                    },
                    toAgreement: function(t) {
                        e.navigateTo({
                            url: "/pages/agreement/agreement?ruleType=0&id=" + t
                        });
                    }
                }
            };
            t.default = h;
        }).call(this, n("543d").default);
    },
    e550: function(e, t, n) {
        n.r(t);
        var o = n("c239"), a = n("f673");
        for (var r in a) [ "default" ].indexOf(r) < 0 && function(e) {
            n.d(t, e, function() {
                return a[e];
            });
        }(r);
        n("4b08");
        var c = n("f0c5"), i = Object(c.a)(a.default, o.b, o.c, !1, null, "11b39f1c", null, !1, o.a, void 0);
        t.default = i.exports;
    },
    f673: function(e, t, n) {
        n.r(t);
        var o = n("e018"), a = n.n(o);
        for (var r in o) [ "default" ].indexOf(r) < 0 && function(e) {
            n.d(t, e, function() {
                return o[e];
            });
        }(r);
        t.default = a.a;
    },
    fc1e: function(e, t, n) {}
}, [ [ "c52e", "common/runtime", "common/vendor" ] ] ]);