(global.webpackJsonp = global.webpackJsonp || []).push([ [ "pages/task_center/task_center" ], {
    "177d": function(e, t, n) {
        n.r(t);
        var a = n("cd00"), r = n.n(a);
        for (var o in a) [ "default" ].indexOf(o) < 0 && function(e) {
            n.d(t, e, function() {
                return a[e];
            });
        }(o);
        t.default = r.a;
    },
    "4b9f": function(e, t, n) {
        n.r(t);
        var a = n("7fec"), r = n("177d");
        for (var o in r) [ "default" ].indexOf(o) < 0 && function(e) {
            n.d(t, e, function() {
                return r[e];
            });
        }(o);
        n("912c");
        var i = n("f0c5"), c = Object(i.a)(r.default, a.b, a.c, !1, null, "4aa8ab5b", null, !1, a.a, void 0);
        t.default = c.exports;
    },
    "7fec": function(e, t, n) {
        n.d(t, "b", function() {
            return r;
        }), n.d(t, "c", function() {
            return o;
        }), n.d(t, "a", function() {
            return a;
        });
        var a = {
            uLineProgress: function() {
                return n.e("node-modules/uview-ui/components/u-line-progress/u-line-progress").then(n.bind(null, "1edd"));
            },
            uToast: function() {
                return n.e("node-modules/uview-ui/components/u-toast/u-toast").then(n.bind(null, "446f"));
            },
            uMask: function() {
                return n.e("node-modules/uview-ui/components/u-mask/u-mask").then(n.bind(null, "f0fd"));
            }
        }, r = function() {
            var e = this;
            e.$createElement;
            e._self._c, e._isMounted || (e.e0 = function(t) {
                return t.stopPropagation(), e.__HOLDER__(t);
            }, e.e1 = function(t) {
                e.dialogVisible = !1;
            }, e.e2 = function(t) {
                return t.stopPropagation(), e.__HOLDER__(t);
            }, e.e3 = function(t) {
                e.dialogVisible = !1;
            }, e.e4 = function(t) {
                return t.stopPropagation(), e.__HOLDER__(t);
            }, e.e5 = function(t) {
                return t.stopPropagation(), e.__HOLDER__(t);
            }, e.e6 = function(t) {
                e.rotate = !1;
            });
        }, o = [];
    },
    "8dfa": function(e, t, n) {
        (function(e) {
            n("6cdc"), a(n("66fd"));
            var t = a(n("4b9f"));
            function a(e) {
                return e && e.__esModule ? e : {
                    default: e
                };
            }
            wx.__webpack_require_UNI_MP_PLUGIN__ = n, e(t.default);
        }).call(this, n("543d").createPage);
    },
    "912c": function(e, t, n) {
        var a = n("d1c2");
        n.n(a).a;
    },
    cd00: function(e, t, n) {
        (function(e) {
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = void 0;
            var a = function(e) {
                return e && e.__esModule ? e : {
                    default: e
                };
            }(n("4795")), r = n("7b12");
            function o(e, t) {
                var n = Object.keys(e);
                if (Object.getOwnPropertySymbols) {
                    var a = Object.getOwnPropertySymbols(e);
                    t && (a = a.filter(function(t) {
                        return Object.getOwnPropertyDescriptor(e, t).enumerable;
                    })), n.push.apply(n, a);
                }
                return n;
            }
            function i(e) {
                for (var t = 1; t < arguments.length; t++) {
                    var n = null != arguments[t] ? arguments[t] : {};
                    t % 2 ? o(Object(n), !0).forEach(function(t) {
                        c(e, t, n[t]);
                    }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(n)) : o(Object(n)).forEach(function(t) {
                        Object.defineProperty(e, t, Object.getOwnPropertyDescriptor(n, t));
                    });
                }
                return e;
            }
            function c(e, t, n) {
                return t in e ? Object.defineProperty(e, t, {
                    value: n,
                    enumerable: !0,
                    configurable: !0,
                    writable: !0
                }) : e[t] = n, e;
            }
            function s(e, t, n, a, r, o, i) {
                try {
                    var c = e[o](i), s = c.value;
                } catch (e) {
                    return void n(e);
                }
                c.done ? t(s) : Promise.resolve(s).then(a, r);
            }
            function u(e) {
                return function() {
                    var t = this, n = arguments;
                    return new Promise(function(a, r) {
                        var o = e.apply(t, n);
                        function i(e) {
                            s(o, a, r, i, c, "next", e);
                        }
                        function c(e) {
                            s(o, a, r, i, c, "throw", e);
                        }
                        i(void 0);
                    });
                };
            }
            var d = {
                data: function() {
                    return {
                        loading: !1,
                        whetherSignIn: !1,
                        taskList: [],
                        continuityList: [],
                        signInDay: 0,
                        todaySignInGrowth: "",
                        todaySignInPoints: "",
                        noticeStr: "",
                        tabList: [ {
                            title: "签到周期",
                            normalIcon: "../../static/tab_sign-in_normal.png",
                            selectedIcon: "../../static/tab_sign-in_selected.png"
                        }, {
                            title: "卡片收集",
                            normalIcon: "../../static/tab_card_normal.png",
                            selectedIcon: "../../static/tab_card_selected.png"
                        } ],
                        activeIndex: 0,
                        activityId: 0,
                        cardList: [],
                        currentIcon: "",
                        card: {
                            name: "",
                            icon: "",
                            coupon: "",
                            bgFront: "",
                            bgBack: ""
                        },
                        ruleDescription: "",
                        dialogVisible: !1,
                        preview: !1,
                        rotate: !0,
                        showCoupon: !1
                    };
                },
                onLoad: function(e) {
                    e.activeIndex && (this.activeIndex = Number(e.activeIndex)), console.log(this.activeIndex);
                },
                onShow: function() {
                    this.checkWhetherSignIn(), this.loadCatCard(), this.getEventRecordList();
                },
                mounted: function() {
                    wx.createSelectorQuery().select("#scrollview").node().exec(function(e) {
                        try {
                            e[0].node.showScrollbar = !1;
                        } catch (e) {}
                    });
                },
                computed: {
                    dayflag: function() {
                        return "";
                    }
                },
                methods: {
                    toAgreement: function(t) {
                        -1 === t ? e.navigateTo({
                            url: "/pages/activity/rule"
                        }) : e.navigateTo({
                            url: "/pages/agreement/agreement?ruleType=" + t
                        });
                    },
                    selectTab: function(e) {
                        this.activeIndex = e;
                    },
                    getEventRecordList: function() {
                        var e = this;
                        return u(a.default.mark(function t() {
                            var n, o, i;
                            return a.default.wrap(function(t) {
                                for (;;) switch (t.prev = t.next) {
                                  case 0:
                                    return t.next = 2, (0, r.dailyTask)();

                                  case 2:
                                    n = t.sent, o = n.data, console.log("事件结果", o), "00000" == o.code && (e.taskList = (null === (i = o.data) || void 0 === i ? void 0 : i.map(function(e) {
                                        var t;
                                        return e.eventList = (null === (t = e.eventList) || void 0 === t ? void 0 : t.map(function(e) {
                                            return e.progress = e.progress || 0, e.totalProgress = e.totalProgress || 1, e.rate = e.progress / e.totalProgress * 100, 
                                            e;
                                        })) || [], e;
                                    })) || []);

                                  case 6:
                                  case "end":
                                    return t.stop();
                                }
                            }, t);
                        }))();
                    },
                    loadCatCard: function() {
                        var e = this;
                        return u(a.default.mark(function t() {
                            var n, o, i;
                            return a.default.wrap(function(t) {
                                for (;;) switch (t.prev = t.next) {
                                  case 0:
                                    return t.next = 2, (0, r.catCard)();

                                  case 2:
                                    if (n = t.sent, null != (o = n.data).data) {
                                        t.next = 8;
                                        break;
                                    }
                                    e.cardList = [], t.next = 19;
                                    break;

                                  case 8:
                                    if ("00000" !== o.code || null == o.data) {
                                        t.next = 19;
                                        break;
                                    }
                                    return e.activityId = o.data.id, e.cardList = o.data.rewardList, i = o.data.iconUrl.split(","), 
                                    e.tabList = e.tabList.map(function(e, t) {
                                        return 1 === t && (e.normalIcon = i[0], e.selectedIcon = i[1]), e;
                                    }), e.ruleDescription = o.data.activityRule, e.card.bgFront = i[2], e.card.bgBack = i[3], 
                                    e.card.bgReward = 5 === i.length ? i[4] : "", t.next = 19, e.loadMyCatCard();

                                  case 19:
                                  case "end":
                                    return t.stop();
                                }
                            }, t);
                        }))();
                    },
                    loadMyCatCard: function() {
                        var t = this;
                        return u(a.default.mark(function n() {
                            var o, i, c;
                            return a.default.wrap(function(n) {
                                for (;;) switch (n.prev = n.next) {
                                  case 0:
                                    return o = (o = e.getStorageSync("loginData2")) ? JSON.parse(o) : {}, n.next = 4, 
                                    (0, r.myCatCard)(t.activityId, o.memberNo);

                                  case 4:
                                    i = n.sent, "00000" === (c = i.data).code && c.data.length > 0 && (t.cardList = t.cardList.map(function(e) {
                                        var t = c.data.findIndex(function(t) {
                                            return t.rewardId === e.rewardId;
                                        });
                                        return -1 !== t && (e.total = c.data[t].total), e;
                                    }));

                                  case 7:
                                  case "end":
                                    return n.stop();
                                }
                            }, n);
                        }))();
                    },
                    memberSign: function() {
                        var e = this;
                        return u(a.default.mark(function t() {
                            var n, o, c;
                            return a.default.wrap(function(t) {
                                for (;;) switch (t.prev = t.next) {
                                  case 0:
                                    if (!e.loading) {
                                        t.next = 2;
                                        break;
                                    }
                                    return t.abrupt("return");

                                  case 2:
                                    if (e.loading = !0, e.whetherSignIn) {
                                        t.next = 6;
                                        break;
                                    }
                                    return e.showToast("已签到", "warning"), t.abrupt("return");

                                  case 6:
                                    return t.next = 8, (0, r.signIn)();

                                  case 8:
                                    if (n = t.sent, o = n.data, console.log("签到结果", o), null == o.data) {
                                        t.next = 20;
                                        break;
                                    }
                                    return e.preview = !1, c = o.data.couponList || [], e.card = i(i({}, e.card), {}, {
                                        name: o.data.rewardName,
                                        icon: o.data.rewardIcon,
                                        coupon: c.length ? c.map(function(e) {
                                            return e.couponName;
                                        }).join("、") : ""
                                    }), t.next = 17, e.checkWhetherSignIn();

                                  case 17:
                                    e.dialogVisible = !0, t.next = 21;
                                    break;

                                  case 20:
                                    "00000" == o.code ? (e.showToast("签到成功！", "success"), e.checkWhetherSignIn(), e.getEventRecordList()) : (e.showToast(o.message, "error"), 
                                    e.loading = !1);

                                  case 21:
                                    e.getEventRecordList();

                                  case 22:
                                  case "end":
                                    return t.stop();
                                }
                            }, t);
                        }))();
                    },
                    checkWhetherSignIn: function() {
                        var e = this;
                        return u(a.default.mark(function t() {
                            var n, o, i, c, s, u, d, l, f, g, p, h;
                            return a.default.wrap(function(t) {
                                for (;;) switch (t.prev = t.next) {
                                  case 0:
                                    return t.next = 2, (0, r.whetherSignIn)();

                                  case 2:
                                    if (n = t.sent, console.log("查询是否可签到", n), e.loading = !1, "00000" == n.data.code) {
                                        for (o = n.data.data, i = o.signInDay, c = o.whetherSignIn, s = o.todaySignInGrowth, 
                                        u = o.todaySignInPoints, d = o.defaultSignInPoints, l = o.defaultSignInGrowth, e.whetherSignIn = c, 
                                        e.todaySignInGrowth = s || l, e.todaySignInPoints = u || d, f = n.data.data.config.filter(function(e) {
                                            return e.point > 0;
                                        }), g = [ {
                                            showIndex: !1,
                                            type: "none"
                                        } ], p = function(e) {
                                            var t = "default", n = !0, a = d;
                                            c || i !== e ? i >= e ? t = "before" : f.some(function(t) {
                                                return t.day === e;
                                            }) && (t = "award", n = !1, a = f.filter(function(t) {
                                                return t.day === e;
                                            })[0].point) : t = "now", g.push({
                                                showIndex: n,
                                                type: t,
                                                point: a
                                            });
                                        }, h = 1; h < 31; h++) p(h);
                                        e.continuityList = g;
                                    }

                                  case 6:
                                  case "end":
                                    return t.stop();
                                }
                            }, t);
                        }))();
                    },
                    handleTakeCard: function() {
                        var e = this;
                        return u(a.default.mark(function t() {
                            return a.default.wrap(function(t) {
                                for (;;) switch (t.prev = t.next) {
                                  case 0:
                                    if (!e.card.coupon) {
                                        t.next = 4;
                                        break;
                                    }
                                    e.showCoupon = !0, t.next = 8;
                                    break;

                                  case 4:
                                    return t.next = 6, e.loadMyCatCard();

                                  case 6:
                                    e.activeIndex = 1, e.dialogVisible = !1;

                                  case 8:
                                  case "end":
                                    return t.stop();
                                }
                            }, t);
                        }))();
                    },
                    handleToMyCoupon: function() {
                        e.navigateTo({
                            url: "/pages/coupon/coupon"
                        }), this.loadMyCatCard(), this.activeIndex = 1, this.dialogVisible = !1;
                    },
                    handlePreviewCard: function(e) {
                        e.total > 0 && (this.currentIcon = e.rewardIcon, this.preview = !0, this.dialogVisible = !0);
                    },
                    saveImage: function() {
                        var t = this;
                        e.getLocation(), e.getImageInfo({
                            src: t.currentIcon,
                            success: function(n) {
                                e.saveImageToPhotosAlbum({
                                    filePath: n.path,
                                    success: function() {
                                        t.showToast("保存成功", "success"), t.dialogVisible = !0;
                                    }
                                });
                            }
                        });
                    },
                    handleSaveCatCard: function() {
                        var t = this;
                        e.getSetting({
                            success: function(n) {
                                n.authSetting["scope.writePhotosAlbum"] ? t.saveImage() : e.authorize({
                                    scope: "scope.writePhotosAlbum",
                                    success: function() {
                                        t.saveImage();
                                    },
                                    fail: function() {
                                        e.showModal({
                                            title: "提示",
                                            content: "请授权相册权限",
                                            confirmColor: "#37eea8",
                                            success: function(n) {
                                                n.confirm && e.openSetting({
                                                    success: function(e) {
                                                        e.authSetting["scope.writePhotosAlbum"] && t.saveImage();
                                                    }
                                                });
                                            }
                                        });
                                    }
                                });
                            }
                        });
                    },
                    gotoPage: function(t, n) {
                        n || ("SIGN" === t ? e.pageScrollTo({
                            scrollTop: 0,
                            duration: 500
                        }) : "INFO" === t ? wx.navigateTo({
                            url: "/pages/mine/mine"
                        }) : "LEVEL" === t ? wx.navigateTo({
                            url: "/pages/member_power/member_power"
                        }) : "INVITE" === t ? wx.navigateTo({
                            url: "/pages/call_recode/call_recode"
                        }) : "COMMUNITY" === t ? wx.switchTab({
                            url: "/pages/team/team"
                        }) : "SHOP" === t && e.navigateToMiniProgram({
                            appId: "wxef8d617b01946908",
                            path: "pages/common/blank-page/index?weappSharePath=pages%2Fhome%2Fdashboard%2Findex%3Fkdt_id%3D90706668",
                            extraData: {},
                            success: function(e) {
                                console.log("打开成功", e);
                            }
                        }));
                    },
                    gotoTab: function(t) {
                        e.switchTab({
                            url: t
                        });
                    },
                    showToast: function(e, t) {
                        this.$refs.uToast.show({
                            title: e,
                            type: t
                        });
                    },
                    scroll: function() {},
                    text: function(e) {
                        return console.log(e, this.signInDay), e == this.signInDay ? "thisquest_.png" : e > this.signInDay ? "weiquest.png" : "unquest.png";
                    }
                }
            };
            t.default = d;
        }).call(this, n("543d").default);
    },
    d1c2: function(e, t, n) {}
}, [ [ "8dfa", "common/runtime", "common/vendor" ] ] ]);