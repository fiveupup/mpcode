(global.webpackJsonp = global.webpackJsonp || []).push([ [ "pages/confirm/confirm" ], {
    "08d5": function(e, n, t) {
        t.r(n);
        var r = t("e56f"), o = t("68a1");
        for (var c in o) [ "default" ].indexOf(c) < 0 && function(e) {
            t.d(n, e, function() {
                return o[e];
            });
        }(c);
        t("1956");
        var a = t("f0c5"), i = Object(a.a)(o.default, r.b, r.c, !1, null, "6126a712", null, !1, r.a, void 0);
        n.default = i.exports;
    },
    1956: function(e, n, t) {
        var r = t("b9eb");
        t.n(r).a;
    },
    "68a1": function(e, n, t) {
        t.r(n);
        var r = t("d329"), o = t.n(r);
        for (var c in r) [ "default" ].indexOf(c) < 0 && function(e) {
            t.d(n, e, function() {
                return r[e];
            });
        }(c);
        n.default = o.a;
    },
    a094: function(e, n, t) {
        (function(e) {
            t("6cdc"), r(t("66fd"));
            var n = r(t("08d5"));
            function r(e) {
                return e && e.__esModule ? e : {
                    default: e
                };
            }
            wx.__webpack_require_UNI_MP_PLUGIN__ = t, e(n.default);
        }).call(this, t("543d").createPage);
    },
    b9eb: function(e, n, t) {},
    d329: function(e, n, t) {
        (function(e) {
            Object.defineProperty(n, "__esModule", {
                value: !0
            }), n.default = void 0;
            var r = function(e) {
                return e && e.__esModule ? e : {
                    default: e
                };
            }(t("4795")), o = t("7b12");
            function c(e, n) {
                var t = Object.keys(e);
                if (Object.getOwnPropertySymbols) {
                    var r = Object.getOwnPropertySymbols(e);
                    n && (r = r.filter(function(n) {
                        return Object.getOwnPropertyDescriptor(e, n).enumerable;
                    })), t.push.apply(t, r);
                }
                return t;
            }
            function a(e) {
                for (var n = 1; n < arguments.length; n++) {
                    var t = null != arguments[n] ? arguments[n] : {};
                    n % 2 ? c(Object(t), !0).forEach(function(n) {
                        i(e, n, t[n]);
                    }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(t)) : c(Object(t)).forEach(function(n) {
                        Object.defineProperty(e, n, Object.getOwnPropertyDescriptor(t, n));
                    });
                }
                return e;
            }
            function i(e, n, t) {
                return n in e ? Object.defineProperty(e, n, {
                    value: t,
                    enumerable: !0,
                    configurable: !0,
                    writable: !0
                }) : e[n] = t, e;
            }
            function u(e, n, t, r, o, c, a) {
                try {
                    var i = e[c](a), u = i.value;
                } catch (e) {
                    return void t(e);
                }
                i.done ? n(u) : Promise.resolve(u).then(r, o);
            }
            function f(e) {
                return function() {
                    var n = this, t = arguments;
                    return new Promise(function(r, o) {
                        var c = e.apply(n, t);
                        function a(e) {
                            u(c, r, o, a, i, "next", e);
                        }
                        function i(e) {
                            u(c, r, o, a, i, "throw", e);
                        }
                        a(void 0);
                    });
                };
            }
            var s = {
                data: function() {
                    return {
                        userInfo: "",
                        hasUserInfo: !1,
                        code: "",
                        isBack: !1
                    };
                },
                onLoad: function(e) {
                    console.log("options:", e), this.isBack = "1" === e.back;
                },
                onShow: function() {
                    this.getLoginCode();
                },
                methods: {
                    cancelBtn: function() {
                        this.isBack ? e.navigateBack() : e.reLaunch({
                            url: "/pages/index/index"
                        });
                    },
                    getLoginCode: function() {
                        var n = this;
                        e.login({
                            success: function(e) {
                                e.code ? (console.log("登录获取的 code ", e.code), n.code = e.code) : console.log("登录失败！" + e.errMsg);
                            }
                        });
                    },
                    getUserProfile: function() {
                        var n = this;
                        return f(r.default.mark(function t() {
                            return r.default.wrap(function(t) {
                                for (;;) switch (t.prev = t.next) {
                                  case 0:
                                    e.getUserProfile({
                                        desc: "用于完善用户信息(头像、昵称)",
                                        success: function() {
                                            var t = f(r.default.mark(function t(c) {
                                                var i, u, f;
                                                return r.default.wrap(function(t) {
                                                    for (;;) switch (t.prev = t.next) {
                                                      case 0:
                                                        return e.showLoading({
                                                            mask: !0
                                                        }), i = e.getStorageSync("loginData2"), u = i ? JSON.parse(i) : {}, console.log("code", n.code), 
                                                        console.log("encryptedData", c.encryptedData), console.log("iv", c.iv), t.next = 8, 
                                                        (0, o.updateWechatMiniInfo)({
                                                            code: n.code,
                                                            encryptedData: c.encryptedData,
                                                            iv: c.iv
                                                        });

                                                      case 8:
                                                        f = t.sent, e.hideLoading(), "00000" == f.data.code && (e.setStorageSync("loginData2", JSON.stringify(a(a({}, u), f.data.data))), 
                                                        n.isBack ? e.navigateBack() : e.reLaunch({
                                                            url: "/pages/index/index"
                                                        }));

                                                      case 11:
                                                      case "end":
                                                        return t.stop();
                                                    }
                                                }, t);
                                            }));
                                            return function(e) {
                                                return t.apply(this, arguments);
                                            };
                                        }()
                                    });

                                  case 2:
                                  case "end":
                                    return t.stop();
                                }
                            }, t);
                        }))();
                    }
                }
            };
            n.default = s;
        }).call(this, t("543d").default);
    },
    e56f: function(e, n, t) {
        t.d(n, "b", function() {
            return r;
        }), t.d(n, "c", function() {
            return o;
        }), t.d(n, "a", function() {});
        var r = function() {
            this.$createElement;
            this._self._c;
        }, o = [];
    }
}, [ [ "a094", "common/runtime", "common/vendor" ] ] ]);