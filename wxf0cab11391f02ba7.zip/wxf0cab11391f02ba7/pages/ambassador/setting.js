(global.webpackJsonp = global.webpackJsonp || []).push([ [ "pages/ambassador/setting" ], {
    "1fb9": function(n, t, e) {
        e.r(t);
        var o = e("516e"), u = e("6518");
        for (var a in u) [ "default" ].indexOf(a) < 0 && function(n) {
            e.d(t, n, function() {
                return u[n];
            });
        }(a);
        e("4712");
        var r = e("f0c5"), c = Object(r.a)(u.default, o.b, o.c, !1, null, "606ff1cc", null, !1, o.a, void 0);
        t.default = c.exports;
    },
    2597: function(n, t, e) {
        (function(n) {
            e("6cdc"), o(e("66fd"));
            var t = o(e("1fb9"));
            function o(n) {
                return n && n.__esModule ? n : {
                    default: n
                };
            }
            wx.__webpack_require_UNI_MP_PLUGIN__ = e, n(t.default);
        }).call(this, e("543d").createPage);
    },
    "46a9": function(n, t, e) {
        (function(n) {
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = void 0;
            var o = function(n) {
                return n && n.__esModule ? n : {
                    default: n
                };
            }(e("4795")), u = e("6d6a");
            function a(n, t, e, o, u, a, r) {
                try {
                    var c = n[a](r), i = c.value;
                } catch (n) {
                    return void e(n);
                }
                c.done ? t(i) : Promise.resolve(i).then(o, u);
            }
            var r = {
                data: function() {
                    return {
                        id: 0,
                        logoutModal: !1
                    };
                },
                onLoad: function(n) {
                    this.id = n.id;
                },
                methods: {
                    confirmLogout: function() {
                        var t = this;
                        return function(n) {
                            return function() {
                                var t = this, e = arguments;
                                return new Promise(function(o, u) {
                                    var r = n.apply(t, e);
                                    function c(n) {
                                        a(r, o, u, c, i, "next", n);
                                    }
                                    function i(n) {
                                        a(r, o, u, c, i, "throw", n);
                                    }
                                    c(void 0);
                                });
                            };
                        }(o.default.mark(function e() {
                            var a;
                            return o.default.wrap(function(e) {
                                for (;;) switch (e.prev = e.next) {
                                  case 0:
                                    return e.next = 2, (0, u.logoutAmbassador)(t.id);

                                  case 2:
                                    a = e.sent, "00000" == a.data.code && (n.showToast({
                                        title: "注销成功",
                                        icon: "success"
                                    }), setTimeout(function(n) {
                                        wx.reLaunch({
                                            url: "/pages/index/index"
                                        });
                                    }, 1e3));

                                  case 5:
                                  case "end":
                                    return e.stop();
                                }
                            }, e);
                        }))();
                    }
                }
            };
            t.default = r;
        }).call(this, e("543d").default);
    },
    4712: function(n, t, e) {
        var o = e("4c8e");
        e.n(o).a;
    },
    "4c8e": function(n, t, e) {},
    "516e": function(n, t, e) {
        e.d(t, "b", function() {
            return u;
        }), e.d(t, "c", function() {
            return a;
        }), e.d(t, "a", function() {
            return o;
        });
        var o = {
            uModal: function() {
                return e.e("node-modules/uview-ui/components/u-modal/u-modal").then(e.bind(null, "f29e"));
            }
        }, u = function() {
            var n = this;
            n.$createElement;
            n._self._c, n._isMounted || (n.e0 = function(t) {
                n.logoutModal = !0;
            }, n.e1 = function(t) {
                n.logoutModal = !1;
            });
        }, a = [];
    },
    6518: function(n, t, e) {
        e.r(t);
        var o = e("46a9"), u = e.n(o);
        for (var a in o) [ "default" ].indexOf(a) < 0 && function(n) {
            e.d(t, n, function() {
                return o[n];
            });
        }(a);
        t.default = u.a;
    }
}, [ [ "2597", "common/runtime", "common/vendor" ] ] ]);