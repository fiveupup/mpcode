(global.webpackJsonp = global.webpackJsonp || []).push([ [ "pages/ambassador/display" ], {
    "10b6": function(n, t, e) {
        (function(n) {
            e("6cdc"), o(e("66fd"));
            var t = o(e("1d5e"));
            function o(n) {
                return n && n.__esModule ? n : {
                    default: n
                };
            }
            wx.__webpack_require_UNI_MP_PLUGIN__ = e, n(t.default);
        }).call(this, e("543d").createPage);
    },
    "1a77": function(n, t, e) {},
    "1b63": function(n, t, e) {
        e.d(t, "b", function() {
            return o;
        }), e.d(t, "c", function() {
            return a;
        }), e.d(t, "a", function() {});
        var o = function() {
            this.$createElement;
            this._self._c;
        }, a = [];
    },
    "1d5e": function(n, t, e) {
        e.r(t);
        var o = e("1b63"), a = e("3ee5");
        for (var r in a) [ "default" ].indexOf(r) < 0 && function(n) {
            e.d(t, n, function() {
                return a[n];
            });
        }(r);
        e("f6a8");
        var u = e("f0c5"), c = Object(u.a)(a.default, o.b, o.c, !1, null, "34036236", null, !1, o.a, void 0);
        t.default = c.exports;
    },
    "3ee5": function(n, t, e) {
        e.r(t);
        var o = e("b351"), a = e.n(o);
        for (var r in o) [ "default" ].indexOf(r) < 0 && function(n) {
            e.d(t, n, function() {
                return o[n];
            });
        }(r);
        t.default = a.a;
    },
    b351: function(n, t, e) {
        (function(n) {
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = void 0;
            var o = function(n) {
                return n && n.__esModule ? n : {
                    default: n
                };
            }(e("4795")), a = e("6d6a");
            function r(n, t, e, o, a, r, u) {
                try {
                    var c = n[r](u), i = c.value;
                } catch (n) {
                    return void e(n);
                }
                c.done ? t(i) : Promise.resolve(i).then(o, a);
            }
            var u = {
                components: {
                    laysPage: function() {
                        Promise.all([ e.e("common/vendor"), e.e("components/lays-page") ]).then(function() {
                            return resolve(e("6310"));
                        }.bind(null, e)).catch(e.oe);
                    }
                },
                data: function() {
                    return {
                        title: {
                            order: "邀购订单",
                            reward: "邀购奖励"
                        },
                        type: "",
                        bgInfo: {
                            bgImgUrl: "https://pepsicocampuscrmstgblob.blob.core.chinacloudapi.cn/pepsicocampuscrmstgblob/FAQ_202304231736473251.png",
                            height: 81,
                            width: 342,
                            x: 204,
                            y: 1203,
                            jumpTo: ""
                        }
                    };
                },
                onLoad: function(n) {
                    console.log("心动大使邀购：", n), this.type = n.type, this.loadConfigData();
                },
                methods: {
                    loadConfigData: function() {
                        var n = this;
                        return function(n) {
                            return function() {
                                var t = this, e = arguments;
                                return new Promise(function(o, a) {
                                    var u = n.apply(t, e);
                                    function c(n) {
                                        r(u, o, a, c, i, "next", n);
                                    }
                                    function i(n) {
                                        r(u, o, a, c, i, "throw", n);
                                    }
                                    c(void 0);
                                });
                            };
                        }(o.default.mark(function t() {
                            var e, r;
                            return o.default.wrap(function(t) {
                                for (;;) switch (t.prev = t.next) {
                                  case 0:
                                    return t.next = 2, (0, a.ambassadorBgConfig)(n.type.toUpperCase());

                                  case 2:
                                    e = t.sent, "00000" === (r = e.data).code && (n.bgInfo = r.data || {});

                                  case 5:
                                  case "end":
                                    return t.stop();
                                }
                            }, t);
                        }))();
                    },
                    handleJump: function() {
                        this.jumpMiniApp(this.bgInfo.jumpTo);
                    },
                    jumpMiniApp: function(t) {
                        n.navigateToMiniProgram({
                            appId: "wxef8d617b01946908",
                            path: t,
                            extraData: {},
                            success: function(n) {
                                console.log("打开成功", n);
                            },
                            fail: function(n) {
                                console.log("打开失败", n);
                            }
                        });
                    }
                }
            };
            t.default = u;
        }).call(this, e("543d").default);
    },
    f6a8: function(n, t, e) {
        var o = e("1a77");
        e.n(o).a;
    }
}, [ [ "10b6", "common/runtime", "common/vendor" ] ] ]);