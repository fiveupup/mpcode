(global.webpackJsonp = global.webpackJsonp || []).push([ [ "pages/ambassador/transfer" ], {
    "1e60": function(n, t, a) {
        a.r(t);
        var e = a("27c5"), o = a.n(e);
        for (var u in e) [ "default" ].indexOf(u) < 0 && function(n) {
            a.d(t, n, function() {
                return e[n];
            });
        }(u);
        t.default = o.a;
    },
    "27c5": function(n, t, a) {
        (function(n) {
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = void 0;
            var e = function(n) {
                return n && n.__esModule ? n : {
                    default: n
                };
            }(a("4795")), o = a("6d6a");
            function u(n, t, a, e, o, u, i) {
                try {
                    var c = n[u](i), r = c.value;
                } catch (n) {
                    return void a(n);
                }
                c.done ? t(r) : Promise.resolve(r).then(e, o);
            }
            function i(n) {
                return function() {
                    var t = this, a = arguments;
                    return new Promise(function(e, o) {
                        var i = n.apply(t, a);
                        function c(n) {
                            u(i, e, o, c, r, "next", n);
                        }
                        function r(n) {
                            u(i, e, o, c, r, "throw", n);
                        }
                        c(void 0);
                    });
                };
            }
            var c = {
                data: function() {
                    return {
                        loadSuccess: !1,
                        jumpTo: "",
                        bgInfo: {
                            bgImgUrl: "https://pepsicocampuscrmstgblob.blob.core.chinacloudapi.cn/pepsicocampuscrmstgblob/FAQ_202304231736473251.png",
                            height: 81,
                            width: 342,
                            x: 204,
                            y: 1203
                        },
                        loginData: {}
                    };
                },
                onLoad: function(t) {
                    console.log("心动大使邀购：", t), this.loadConfigData();
                    var a = n.getStorageSync("loginData2");
                    this.loginData = a ? JSON.parse(a) : {}, this.loginData.token ? this.loadData() : this.loadNoAuthData();
                },
                onShow: function() {
                    this.jumpTo && this.jumpMiniApp(this.jumpTo);
                },
                methods: {
                    loadConfigData: function() {
                        var n = this;
                        return i(e.default.mark(function t() {
                            var a, u;
                            return e.default.wrap(function(t) {
                                for (;;) switch (t.prev = t.next) {
                                  case 0:
                                    return t.next = 2, (0, o.ambassadorBgConfigPublic)("INVITATION");

                                  case 2:
                                    a = t.sent, "00000" === (u = a.data).code && (n.bgInfo = u.data || {});

                                  case 5:
                                  case "end":
                                    return t.stop();
                                }
                            }, t);
                        }))();
                    },
                    handleJump: function() {
                        this.loginData.token ? this.jumpMiniApp(this.jumpTo) : n.navigateTo({
                            url: "/pages/login/login"
                        });
                    },
                    loadData: function() {
                        var t = this;
                        return i(e.default.mark(function a() {
                            var u, i;
                            return e.default.wrap(function(a) {
                                for (;;) switch (a.prev = a.next) {
                                  case 0:
                                    if (!t.loadSuccess) {
                                        a.next = 4;
                                        break;
                                    }
                                    t.jumpMiniApp(t.jumpTo), a.next = 9;
                                    break;

                                  case 4:
                                    return a.next = 6, (0, o.ambassadorJumpToYouZan)(getApp().globalData.hsCodeId);

                                  case 6:
                                    u = a.sent, "00000" === (i = u.data).code ? (t.loadSuccess = !0, t.jumpTo = i.data.jumpTo) : n.showToast({
                                        title: i.message,
                                        icon: "none"
                                    });

                                  case 9:
                                  case "end":
                                    return a.stop();
                                }
                            }, a);
                        }))();
                    },
                    loadNoAuthData: function() {
                        var t = this;
                        return i(e.default.mark(function a() {
                            var u, i;
                            return e.default.wrap(function(a) {
                                for (;;) switch (a.prev = a.next) {
                                  case 0:
                                    if (!t.loadSuccess) {
                                        a.next = 4;
                                        break;
                                    }
                                    t.jumpMiniApp(t.jumpTo), a.next = 9;
                                    break;

                                  case 4:
                                    return a.next = 6, (0, o.ambassadorJumpToYouZanNoAuth)(getApp().globalData.hsCodeId);

                                  case 6:
                                    u = a.sent, "00000" === (i = u.data).code ? (t.loadSuccess = !0, t.jumpTo = i.data.jumpTo) : n.showToast({
                                        title: i.message,
                                        icon: "none"
                                    });

                                  case 9:
                                  case "end":
                                    return a.stop();
                                }
                            }, a);
                        }))();
                    },
                    jumpMiniApp: function(t) {
                        n.navigateToMiniProgram({
                            appId: "wxef8d617b01946908",
                            path: t,
                            extraData: {},
                            success: function(t) {
                                console.log("打开成功", t), n.switchTab({
                                    url: "/pages/index/index"
                                });
                            },
                            fail: function(n) {
                                console.log("打开失败", n);
                            }
                        });
                    }
                }
            };
            t.default = c;
        }).call(this, a("543d").default);
    },
    4435: function(n, t, a) {
        (function(n) {
            a("6cdc"), e(a("66fd"));
            var t = e(a("f2ad"));
            function e(n) {
                return n && n.__esModule ? n : {
                    default: n
                };
            }
            wx.__webpack_require_UNI_MP_PLUGIN__ = a, n(t.default);
        }).call(this, a("543d").createPage);
    },
    "874c": function(n, t, a) {
        a.d(t, "b", function() {
            return e;
        }), a.d(t, "c", function() {
            return o;
        }), a.d(t, "a", function() {});
        var e = function() {
            this.$createElement;
            this._self._c;
        }, o = [];
    },
    af04: function(n, t, a) {
        var e = a("ceb7");
        a.n(e).a;
    },
    ceb7: function(n, t, a) {},
    f2ad: function(n, t, a) {
        a.r(t);
        var e = a("874c"), o = a("1e60");
        for (var u in o) [ "default" ].indexOf(u) < 0 && function(n) {
            a.d(t, n, function() {
                return o[n];
            });
        }(u);
        a("af04");
        var i = a("f0c5"), c = Object(i.a)(o.default, e.b, e.c, !1, null, "60f0f293", null, !1, e.a, void 0);
        t.default = c.exports;
    }
}, [ [ "4435", "common/runtime", "common/vendor" ] ] ]);