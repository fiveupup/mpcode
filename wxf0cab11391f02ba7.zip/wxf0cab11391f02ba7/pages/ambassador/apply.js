require("../../@babel/runtime/helpers/Arrayincludes"), (global.webpackJsonp = global.webpackJsonp || []).push([ [ "pages/ambassador/apply" ], {
    "10a9": function(e, t, n) {
        var o = n("b833");
        n.n(o).a;
    },
    3333: function(e, t, n) {
        n.r(t);
        var o = n("6fc4"), a = n.n(o);
        for (var s in o) [ "default" ].indexOf(s) < 0 && function(e) {
            n.d(t, e, function() {
                return o[e];
            });
        }(s);
        t.default = a.a;
    },
    "34d5": function(e, t, n) {
        n.d(t, "b", function() {
            return a;
        }), n.d(t, "c", function() {
            return s;
        }), n.d(t, "a", function() {
            return o;
        });
        var o = {
            uIcon: function() {
                return n.e("node-modules/uview-ui/components/u-icon/u-icon").then(n.bind(null, "2925"));
            },
            uLineProgress: function() {
                return n.e("node-modules/uview-ui/components/u-line-progress/u-line-progress").then(n.bind(null, "1edd"));
            },
            uPopup: function() {
                return n.e("node-modules/uview-ui/components/u-popup/u-popup").then(n.bind(null, "97cd"));
            },
            uSearch: function() {
                return n.e("node-modules/uview-ui/components/u-search/u-search").then(n.bind(null, "9586"));
            },
            uEmpty: function() {
                return n.e("node-modules/uview-ui/components/u-empty/u-empty").then(n.bind(null, "ab47"));
            },
            uMask: function() {
                return n.e("node-modules/uview-ui/components/u-mask/u-mask").then(n.bind(null, "f0fd"));
            }
        }, a = function() {
            var e = this, t = (e.$createElement, e._self._c, [ "COMPLETING", "SUCCESS" ].includes(e.baseInfo.status)), n = e.$hasScopedSlotsParams("22ad9cfd-1"), o = n && e.isApply ? e.$getScopedSlotsParams("22ad9cfd-1", "default") : null, a = n && !e.isApply ? [ "COMPLETING", "SUCCESS" ].includes(e.baseInfo.status) : null, s = n && !e.isApply ? [ "NONE", "EXPIRE", "LOGOFF" ].includes(e.baseInfo.status) : null, c = n && !e.isApply ? [ "NONE", "EXPIRE", "LOGOFF" ].includes(e.baseInfo.status) : null, r = !n || e.isApply || c ? null : [ "COMPLETING" ].includes(e.baseInfo.status), i = !n || e.isApply || c ? null : [ "SUCCESS" ].includes(e.baseInfo.status);
            e._isMounted || (e.e0 = function(t) {
                e.isOpenPrivacy = !1;
            }, e.e1 = function(t) {
                e.showPost = !1;
            }), e.$mp.data = Object.assign({}, {
                $root: {
                    g0: t,
                    m0: n,
                    m1: o,
                    g1: a,
                    g2: s,
                    g3: c,
                    g4: r,
                    g5: i
                }
            });
        }, s = [];
    },
    4437: function(e, t, n) {
        (function(e) {
            n("6cdc"), o(n("66fd"));
            var t = o(n("fc1d"));
            function o(e) {
                return e && e.__esModule ? e : {
                    default: e
                };
            }
            wx.__webpack_require_UNI_MP_PLUGIN__ = n, e(t.default);
        }).call(this, n("543d").createPage);
    },
    "6fc4": function(e, t, n) {
        (function(e) {
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = void 0;
            var o = function(e) {
                return e && e.__esModule ? e : {
                    default: e
                };
            }(n("4795")), a = n("6d6a"), s = n("7b12");
            function c(e, t) {
                var n = Object.keys(e);
                if (Object.getOwnPropertySymbols) {
                    var o = Object.getOwnPropertySymbols(e);
                    t && (o = o.filter(function(t) {
                        return Object.getOwnPropertyDescriptor(e, t).enumerable;
                    })), n.push.apply(n, o);
                }
                return n;
            }
            function r(e) {
                for (var t = 1; t < arguments.length; t++) {
                    var n = null != arguments[t] ? arguments[t] : {};
                    t % 2 ? c(Object(n), !0).forEach(function(t) {
                        i(e, t, n[t]);
                    }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(n)) : c(Object(n)).forEach(function(t) {
                        Object.defineProperty(e, t, Object.getOwnPropertyDescriptor(n, t));
                    });
                }
                return e;
            }
            function i(e, t, n) {
                return t in e ? Object.defineProperty(e, t, {
                    value: n,
                    enumerable: !0,
                    configurable: !0,
                    writable: !0
                }) : e[t] = n, e;
            }
            function u(e, t, n, o, a, s, c) {
                try {
                    var r = e[s](c), i = r.value;
                } catch (e) {
                    return void n(e);
                }
                r.done ? t(i) : Promise.resolve(i).then(o, a);
            }
            function l(e) {
                return function() {
                    var t = this, n = arguments;
                    return new Promise(function(o, a) {
                        var s = e.apply(t, n);
                        function c(e) {
                            u(s, o, a, c, r, "next", e);
                        }
                        function r(e) {
                            u(s, o, a, c, r, "throw", e);
                        }
                        c(void 0);
                    });
                };
            }
            var p = {
                components: {
                    PurchasePoster: function() {
                        n.e("components/poster/purchase").then(function() {
                            return resolve(n("4f61"));
                        }.bind(null, n)).catch(n.oe);
                    }
                },
                data: function() {
                    return {
                        isApply: !0,
                        avatar: "https://pepsicocampuscrmstgblob.blob.core.chinacloudapi.cn/pepsicocampuscrmstgblob/FAQ_202305061357534454.png",
                        bgConfig: {},
                        baseInfo: {
                            id: null,
                            phone: "",
                            schoolId: "",
                            schoolName: ""
                        },
                        navList: [ {
                            icon: "https://pepsicocampuscrmstgblob.blob.core.chinacloudapi.cn/pepsicocampuscrmstgblob/FAQ_202304261019112005.png",
                            text: "邀购海报"
                        }, {
                            icon: "https://pepsicocampuscrmstgblob.blob.core.chinacloudapi.cn/pepsicocampuscrmstgblob/FAQ_202304261018047414.png",
                            text: "邀购订单"
                        }, {
                            icon: "https://pepsicocampuscrmstgblob.blob.core.chinacloudapi.cn/pepsicocampuscrmstgblob/FAQ_202305231148504842.png",
                            text: "邀购奖励"
                        }, {
                            icon: "https://pepsicocampuscrmstgblob.blob.core.chinacloudapi.cn/pepsicocampuscrmstgblob/FAQ_20230426101935844.png",
                            text: "心动大使协议"
                        }, {
                            icon: "https://pepsicocampuscrmstgblob.blob.core.chinacloudapi.cn/pepsicocampuscrmstgblob/FAQ_202304261019567466.png",
                            text: "隐私政策"
                        } ],
                        inviteList: [],
                        schoolArray: [],
                        schoolList: [],
                        loginData: {},
                        popupShow: !1,
                        schoolSearchValue: "",
                        schoolList_Search: [],
                        isOpenPrivacy: !1,
                        checkboxGwList: [],
                        showPost: !1,
                        isOverseasPhone: !1
                    };
                },
                computed: {
                    bgInfo: function() {
                        var e, t;
                        return [ "COMPLETING", "SUCCESS" ].includes(this.baseInfo.status) ? null === (e = this.bgConfig) || void 0 === e ? void 0 : e.enter : null === (t = this.bgConfig) || void 0 === t ? void 0 : t.apply;
                    }
                },
                onShow: function(t) {
                    var n = e.getStorageSync("loginData2");
                    this.loginData = n ? JSON.parse(n) : {};
                    var o = this.loginData.phone || this.baseInfo.phone || "";
                    o.includes("+") && !o.includes("+86") && (this.isOverseasPhone = !0), this.loadData();
                },
                methods: {
                    loadBg: function() {
                        var e = this;
                        return l(o.default.mark(function t() {
                            var n, s, c;
                            return o.default.wrap(function(t) {
                                for (;;) switch (t.prev = t.next) {
                                  case 0:
                                    return n = [ "COMPLETING", "SUCCESS" ].includes(e.baseInfo.status) ? "enter" : "apply", 
                                    t.next = 3, (0, a.ambassadorBgConfigPublic)(n.toUpperCase());

                                  case 3:
                                    s = t.sent, c = s.data, e.bgConfig = c.data;

                                  case 6:
                                  case "end":
                                    return t.stop();
                                }
                            }, t);
                        }))();
                    },
                    getSchoolListEven: function() {
                        var e = this;
                        return l(o.default.mark(function t() {
                            var n, a;
                            return o.default.wrap(function(t) {
                                for (;;) switch (t.prev = t.next) {
                                  case 0:
                                    return n = {
                                        name: "",
                                        haveHbQty: !0
                                    }, t.next = 3, (0, s.getSchoolList)(n);

                                  case 3:
                                    a = t.sent, console.log("学校列表", a), "00000" == a.data.code && (a.data.data.forEach(function(t) {
                                        t.name && e.schoolArray.push(t);
                                    }), e.schoolList_Search = e.schoolArray.slice(0, 100));

                                  case 6:
                                  case "end":
                                    return t.stop();
                                }
                            }, t);
                        }))();
                    },
                    loadData: function() {
                        var e = this;
                        return l(o.default.mark(function t() {
                            var n, s;
                            return o.default.wrap(function(t) {
                                for (;;) switch (t.prev = t.next) {
                                  case 0:
                                    return t.next = 2, (0, a.ambassadorInfo)();

                                  case 2:
                                    if (n = t.sent, "00008" !== (s = n.data).code) {
                                        t.next = 8;
                                        break;
                                    }
                                    return e.loginData = {}, e.loadBg(), t.abrupt("return");

                                  case 8:
                                    e.baseInfo = r(r({}, s.data), {}, {
                                        phone: s.data.phone || e.loginData.phone
                                    }), e.loadBg(), [ "NONE", "EXPIRE", "LOGOFF" ].includes(e.baseInfo.status) && e.getSchoolListEven(), 
                                    [ "SUCCESS" ].includes(e.baseInfo.status) && e.loadInviteList();

                                  case 12:
                                  case "end":
                                    return t.stop();
                                }
                            }, t);
                        }))();
                    },
                    loadInviteList: function() {
                        var e = this;
                        return l(o.default.mark(function t() {
                            var n, s, c;
                            return o.default.wrap(function(t) {
                                for (;;) switch (t.prev = t.next) {
                                  case 0:
                                    return t.next = 2, (0, a.inviteForAmbassador)();

                                  case 2:
                                    s = t.sent, c = s.data, e.inviteList = (null === (n = c.data) || void 0 === n ? void 0 : n.recordList) || [];

                                  case 5:
                                  case "end":
                                    return t.stop();
                                }
                            }, t);
                        }))();
                    },
                    handleApplyBefore: function() {
                        this.loginData.token ? [ "COMPLETING", "SUCCESS" ].includes(this.baseInfo.status) ? (this.isApply = !1, 
                        e.pageScrollTo({
                            scrollTop: 0,
                            duration: 0
                        })) : this.isOpenPrivacy = !0 : e.showModal({
                            title: "提示",
                            content: "您还未登录，请先登录后再进行申请。",
                            confirmColor: "#37eea8",
                            success: function(t) {
                                t.confirm && (getApp().globalData.isBack = !0, e.navigateTo({
                                    url: "/pages/login/login"
                                }));
                            }
                        });
                    },
                    handleAgree: function() {
                        this.checkboxGwList = [], this.isApply = !1, this.isOpenPrivacy = !1;
                    },
                    handleApply: function() {
                        var e = this;
                        return l(o.default.mark(function t() {
                            var n, s, c, r;
                            return o.default.wrap(function(t) {
                                for (;;) switch (t.prev = t.next) {
                                  case 0:
                                    if (n = e.baseInfo.schoolId) {
                                        t.next = 4;
                                        break;
                                    }
                                    return e.showToast("请选择学校"), t.abrupt("return");

                                  case 4:
                                    return s = {
                                        haCodeId: getApp().globalData.haCodeId,
                                        schoolId: n
                                    }, t.next = 7, (0, a.applyAmbassador)(s);

                                  case 7:
                                    if (c = t.sent, "00000" !== (r = c.data).code) {
                                        t.next = 16;
                                        break;
                                    }
                                    return getApp().globalData.haCodeId = void 0, e.showToast("申请已提交", "success"), t.next = 14, 
                                    e.loadData();

                                  case 14:
                                    t.next = 17;
                                    break;

                                  case 16:
                                    e.showToast(r.message);

                                  case 17:
                                  case "end":
                                    return t.stop();
                                }
                            }, t);
                        }))();
                    },
                    handleClickNavItem: function(e) {
                        "邀购海报" === e ? this.showPost = !0 : "邀购订单" === e ? this.gotoPage("/pages/ambassador/display?type=order") : "邀购奖励" === e ? this.gotoPage("/pages/ambassador/display?type=reward") : "心动大使协议" === e ? this.toAgreement(7) : "隐私政策" === e && this.toAgreement(8);
                    },
                    openPopup: function() {
                        [ "COMPLETING", "SUCCESS" ].includes(this.baseInfo.status) || (this.popupShow = !0);
                    },
                    changeSearch: function() {
                        this.$u.throttle(this.schoolSearchList, 400, !1);
                    },
                    schoolSearchList: function() {
                        var e = this;
                        if (console.log(" 学校搜索--------", this.schoolSearchValue), this.schoolSearchValue) {
                            var t = this.schoolArray.filter(function(t) {
                                return t.name.includes(e.schoolSearchValue);
                            });
                            this.schoolList_Search = t.slice(0, 100);
                        } else this.schoolList_Search = this.schoolArray.slice(0, 100);
                    },
                    clickSearchItem: function(e) {
                        this.baseInfo.schoolName = e.name, this.baseInfo.schoolId = e.id, this.schoolSearchValue = "", 
                        this.popupShow = !1;
                    },
                    showToast: function(t) {
                        var n = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : "none";
                        e.showToast({
                            title: t,
                            icon: n
                        });
                    },
                    checkboxChange: function(e) {
                        console.log("协议勾选", e), this.checkboxGwList = e.detail.value;
                    },
                    toInvite: function() {
                        "DONE" !== this.baseInfo.inviteStatus && wx.navigateTo({
                            url: "/pages/call_recode/call_recode"
                        });
                    },
                    toAgreement: function(t) {
                        e.navigateTo({
                            url: "/pages/agreement/agreement?ruleType=" + t
                        });
                    },
                    gotoPage: function(e, t) {
                        console.log("页面跳转"), wx.navigateTo({
                            url: e,
                            success: function(e) {
                                e.eventChannel.emit("acceptDataFromOpenerPage", {
                                    data: t
                                });
                            }
                        });
                    }
                }
            };
            t.default = p;
        }).call(this, n("543d").default);
    },
    b833: function(e, t, n) {},
    fc1d: function(e, t, n) {
        n.r(t);
        var o = n("34d5"), a = n("3333");
        for (var s in a) [ "default" ].indexOf(s) < 0 && function(e) {
            n.d(t, e, function() {
                return a[e];
            });
        }(s);
        n("10a9");
        var c = n("f0c5"), r = Object(c.a)(a.default, o.b, o.c, !1, null, "569af19c", null, !1, o.a, void 0);
        t.default = r.exports;
    }
}, [ [ "4437", "common/runtime", "common/vendor" ] ] ]);