(global.webpackJsonp = global.webpackJsonp || []).push([ [ "pages/couponDetail/couponDetail" ], {
    "4d40": function(n, t, e) {
        var o = e("a14c");
        e.n(o).a;
    },
    "54ab": function(n, t, e) {
        e.d(t, "b", function() {
            return o;
        }), e.d(t, "c", function() {
            return a;
        }), e.d(t, "a", function() {});
        var o = function() {
            var n = this, t = (n.$createElement, n._self._c, n.info.couponName && n.info.validStartTime ? n.resetTime(n.info.validStartTime) : null), e = n.info.couponName && n.info.validStartTime ? n.resetTime(n.info.validEndTime) : null, o = n.info.couponName && 1 === n.info.availableItems ? n.info.goodsRelationList.map(function(n) {
                return n.name;
            }).join("、") : null;
            n.$mp.data = Object.assign({}, {
                $root: {
                    m0: t,
                    m1: e,
                    g0: o
                }
            });
        }, a = [];
    },
    "6dc0": function(n, t, e) {
        e.r(t);
        var o = e("54ab"), a = e("7cce");
        for (var u in a) [ "default" ].indexOf(u) < 0 && function(n) {
            e.d(t, n, function() {
                return a[n];
            });
        }(u);
        e("4d40");
        var i = e("f0c5"), r = Object(i.a)(a.default, o.b, o.c, !1, null, "f10042b2", null, !1, o.a, void 0);
        t.default = r.exports;
    },
    "7cce": function(n, t, e) {
        e.r(t);
        var o = e("a152"), a = e.n(o);
        for (var u in o) [ "default" ].indexOf(u) < 0 && function(n) {
            e.d(t, n, function() {
                return o[n];
            });
        }(u);
        t.default = a.a;
    },
    a14c: function(n, t, e) {},
    a152: function(n, t, e) {
        Object.defineProperty(t, "__esModule", {
            value: !0
        }), t.default = void 0;
        var o = i(e("4795")), a = i(e("05b9")), u = e("40a4");
        function i(n) {
            return n && n.__esModule ? n : {
                default: n
            };
        }
        function r(n, t, e, o, a, u, i) {
            try {
                var r = n[u](i), c = r.value;
            } catch (n) {
                return void e(n);
            }
            r.done ? t(c) : Promise.resolve(c).then(o, a);
        }
        var c = {
            data: function() {
                return {
                    couponId: "",
                    type: [ "", "满减券", "满折券", "兑换券" ],
                    info: {}
                };
            },
            onLoad: function(n) {
                this.couponId = Number(n.id), this.loadData();
            },
            methods: {
                loadData: function() {
                    var n = this;
                    return function(n) {
                        return function() {
                            var t = this, e = arguments;
                            return new Promise(function(o, a) {
                                var u = n.apply(t, e);
                                function i(n) {
                                    r(u, o, a, i, c, "next", n);
                                }
                                function c(n) {
                                    r(u, o, a, i, c, "throw", n);
                                }
                                i(void 0);
                            });
                        };
                    }(o.default.mark(function t() {
                        var e, a;
                        return o.default.wrap(function(t) {
                            for (;;) switch (t.prev = t.next) {
                              case 0:
                                return t.next = 2, (0, u.coupon)(n.couponId);

                              case 2:
                                e = t.sent, "00000" == (a = e.data).code && (n.info = a.data);

                              case 5:
                              case "end":
                                return t.stop();
                            }
                        }, t);
                    }))();
                },
                resetTime: function(n) {
                    return (0, a.default)(n).format("YYYY.MM.DD HH:mm:ss");
                }
            }
        };
        t.default = c;
    },
    fe28: function(n, t, e) {
        (function(n) {
            e("6cdc"), o(e("66fd"));
            var t = o(e("6dc0"));
            function o(n) {
                return n && n.__esModule ? n : {
                    default: n
                };
            }
            wx.__webpack_require_UNI_MP_PLUGIN__ = e, n(t.default);
        }).call(this, e("543d").createPage);
    }
}, [ [ "fe28", "common/runtime", "common/vendor" ] ] ]);