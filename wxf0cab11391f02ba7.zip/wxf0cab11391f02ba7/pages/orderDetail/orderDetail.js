(global.webpackJsonp = global.webpackJsonp || []).push([ [ "pages/orderDetail/orderDetail" ], {
    "145d": function(t, o, e) {
        e.r(o);
        var n = e("4444"), d = e.n(n);
        for (var a in n) [ "default" ].indexOf(a) < 0 && function(t) {
            e.d(o, t, function() {
                return n[t];
            });
        }(a);
        o.default = d.a;
    },
    "376d": function(t, o, e) {
        e.d(o, "b", function() {
            return n;
        }), e.d(o, "c", function() {
            return d;
        }), e.d(o, "a", function() {});
        var n = function() {
            this.$createElement;
            this._self._c;
        }, d = [];
    },
    4444: function(t, o, e) {
        (function(t) {
            Object.defineProperty(o, "__esModule", {
                value: !0
            }), o.default = void 0;
            var n = e("830d"), d = e("d1f8"), a = {
                data: function() {
                    return {
                        type: "point",
                        orderDetail: {}
                    };
                },
                onLoad: function(t) {
                    var o = this;
                    console.log(t, "options"), this.type = t.type, ("point" === this.type ? (0, n.getOrderDetail)(t.orderSn) : (0, 
                    d.getOrderDetail)(t.orderSn)).then(function(t) {
                        var e;
                        console.log(t, "orderSn"), o.orderDetail = t.data.data, o.orderDetail.goods = JSON.parse(t.data.data.goodsJson || {}), 
                        o.orderDetail.goods.goodsImg = null === (e = o.orderDetail.goods.goodsImg) || void 0 === e ? void 0 : e.split(",")[0];
                    });
                },
                methods: {
                    copy: function(o) {
                        console.log(o), t.setClipboardData({
                            data: o,
                            success: function(o) {
                                t.getClipboardData({
                                    success: function(o) {
                                        console.log(o), t.showToast({
                                            title: "复制成功"
                                        });
                                    }
                                });
                            }
                        });
                    }
                }
            };
            o.default = a;
        }).call(this, e("543d").default);
    },
    "6dd5": function(t, o, e) {
        var n = e("d3c8");
        e.n(n).a;
    },
    a764: function(t, o, e) {
        (function(t) {
            e("6cdc"), n(e("66fd"));
            var o = n(e("de87"));
            function n(t) {
                return t && t.__esModule ? t : {
                    default: t
                };
            }
            wx.__webpack_require_UNI_MP_PLUGIN__ = e, t(o.default);
        }).call(this, e("543d").createPage);
    },
    d3c8: function(t, o, e) {},
    de87: function(t, o, e) {
        e.r(o);
        var n = e("376d"), d = e("145d");
        for (var a in d) [ "default" ].indexOf(a) < 0 && function(t) {
            e.d(o, t, function() {
                return d[t];
            });
        }(a);
        e("6dd5");
        var r = e("f0c5"), i = Object(r.a)(d.default, n.b, n.c, !1, null, "67e21f0f", null, !1, n.a, void 0);
        o.default = i.exports;
    }
}, [ [ "a764", "common/runtime", "common/vendor" ] ] ]);