wx.createComponent({
    generic: !0,
    props: {
        rightList: {
            type: null
        }
    },
    render: function() {}
});