function(e,s,r,gg){
var z=gz$gwx_84()
var x3OC=_mz(z,'lays-page',['bind:__l',0,'class',1,'scopedSlotsCompiler',1,'title',2,'vueId',3,'vueSlots',4],[],e,s,gg)
var o4OC=_v()
_(x3OC,o4OC)
if(_oz(z,6,e,s,gg)){o4OC.wxVkey=1
var c6OC=_mz(z,'view',['class',7,'style',1],[],e,s,gg)
var h7OC=_mz(z,'u-search',['actionStyle',9,'bgColor',1,'bind:__l',2,'bind:custom',3,'bind:input',4,'bind:search',5,'borderColor',6,'class',7,'color',8,'data-event-opts',9,'focus',10,'maxlength',11,'value',12,'vueId',13],[],e,s,gg)
_(c6OC,h7OC)
_(o4OC,c6OC)
var o8OC=_mz(z,'u-waterfall',['bind:__l',23,'bind:input',1,'class',2,'data-event-opts',3,'data-ref',4,'data-vue-generic',5,'value',8,'vueId',9,'vueSlots',10],['wx-scoped-slots-left',6,'wx-scoped-slots-right',7],e,s,gg)
_(o4OC,o8OC)
var f5OC=_v()
_(o4OC,f5OC)
if(_oz(z,34,e,s,gg)){f5OC.wxVkey=1
var c9OC=_mz(z,'u-loadmore',['bind:__l',35,'class',1,'iconType',2,'loadText',3,'marginBottom',4,'marginTop',5,'status',6,'vueId',7],[],e,s,gg)
_(f5OC,c9OC)
}
var o0OC=_mz(z,'view',['class',43,'style',1],[],e,s,gg)
_(o4OC,o0OC)
f5OC.wxXCkey=1
f5OC.wxXCkey=3
}
o4OC.wxXCkey=1
o4OC.wxXCkey=3
_(r,x3OC)
return r
}