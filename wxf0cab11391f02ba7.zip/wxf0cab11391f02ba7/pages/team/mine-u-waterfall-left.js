wx.createComponent({
    generic: !0,
    props: {
        leftList: {
            type: null
        }
    },
    render: function() {}
});