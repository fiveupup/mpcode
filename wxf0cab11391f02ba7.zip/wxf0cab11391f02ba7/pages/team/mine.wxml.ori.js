function(e,s,r,gg){
var z=gz$gwx_80()
var t9LC=_mz(z,'lays-page',['bind:__l',0,'class',1,'scopedSlotsCompiler',1,'title',2,'vueId',3,'vueSlots',4],[],e,s,gg)
var e0LC=_v()
_(t9LC,e0LC)
if(_oz(z,6,e,s,gg)){e0LC.wxVkey=1
var oBMC=_mz(z,'view',['class',7,'style',1],[],e,s,gg)
var xCMC=_mz(z,'u-tabs',['activeColor',9,'barHeight',1,'barWidth',2,'bgColor',3,'bind:__l',4,'bind:change',5,'class',6,'current',7,'data-event-opts',8,'data-ref',9,'gutter',10,'inactiveColor',11,'isScroll',12,'list',13,'vueId',14],[],e,s,gg)
_(oBMC,xCMC)
_(e0LC,oBMC)
var bAMC=_v()
_(e0LC,bAMC)
if(_oz(z,24,e,s,gg)){bAMC.wxVkey=1
var oDMC=_n('view')
_rz(z,oDMC,'class',25,e,s,gg)
var fEMC=_oz(z,26,e,s,gg)
_(oDMC,fEMC)
var cFMC=_n('text')
_rz(z,cFMC,'class',27,e,s,gg)
var hGMC=_oz(z,28,e,s,gg)
_(cFMC,hGMC)
_(oDMC,cFMC)
var oHMC=_oz(z,29,e,s,gg)
_(oDMC,oHMC)
var cIMC=_n('text')
_rz(z,cIMC,'class',30,e,s,gg)
var oJMC=_oz(z,31,e,s,gg)
_(cIMC,oJMC)
_(oDMC,cIMC)
var lKMC=_oz(z,32,e,s,gg)
_(oDMC,lKMC)
_(bAMC,oDMC)
}
else{bAMC.wxVkey=2
var aLMC=_v()
_(bAMC,aLMC)
if(_oz(z,33,e,s,gg)){aLMC.wxVkey=1
var tMMC=_n('view')
_rz(z,tMMC,'class',34,e,s,gg)
var eNMC=_oz(z,35,e,s,gg)
_(tMMC,eNMC)
var bOMC=_n('text')
_rz(z,bOMC,'class',36,e,s,gg)
var oPMC=_oz(z,37,e,s,gg)
_(bOMC,oPMC)
_(tMMC,bOMC)
var xQMC=_oz(z,38,e,s,gg)
_(tMMC,xQMC)
_(aLMC,tMMC)
}
else{aLMC.wxVkey=2
var oRMC=_v()
_(aLMC,oRMC)
if(_oz(z,39,e,s,gg)){oRMC.wxVkey=1
var fSMC=_n('view')
_rz(z,fSMC,'class',40,e,s,gg)
var cTMC=_oz(z,41,e,s,gg)
_(fSMC,cTMC)
var hUMC=_n('text')
_rz(z,hUMC,'class',42,e,s,gg)
var oVMC=_oz(z,43,e,s,gg)
_(hUMC,oVMC)
_(fSMC,hUMC)
var cWMC=_oz(z,44,e,s,gg)
_(fSMC,cWMC)
_(oRMC,fSMC)
}
oRMC.wxXCkey=1
}
aLMC.wxXCkey=1
}
var oXMC=_mz(z,'u-waterfall',['bind:__l',45,'bind:input',1,'class',2,'data-event-opts',3,'data-ref',4,'data-vue-generic',5,'value',8,'vueId',9,'vueSlots',10],['wx-scoped-slots-left',6,'wx-scoped-slots-right',7],e,s,gg)
_(e0LC,oXMC)
var lYMC=_mz(z,'u-loadmore',['bind:__l',56,'class',1,'iconType',2,'loadText',3,'marginBottom',4,'marginTop',5,'status',6,'vueId',7],[],e,s,gg)
_(e0LC,lYMC)
var aZMC=_mz(z,'view',['class',64,'style',1],[],e,s,gg)
_(e0LC,aZMC)
var t1MC=_mz(z,'u-modal',['bind:__l',66,'bind:cancel',1,'bind:confirm',2,'bind:input',3,'class',4,'confirmColor',5,'content',6,'data-event-opts',7,'id',8,'showCancelButton',9,'title',10,'value',11,'vueId',12],[],e,s,gg)
_(e0LC,t1MC)
bAMC.wxXCkey=1
}
e0LC.wxXCkey=1
e0LC.wxXCkey=3
_(r,t9LC)
return r
}