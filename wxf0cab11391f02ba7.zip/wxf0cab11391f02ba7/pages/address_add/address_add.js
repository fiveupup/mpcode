(global.webpackJsonp = global.webpackJsonp || []).push([ [ "pages/address_add/address_add" ], {
    "29bf": function(e, t, r) {
        r.d(t, "b", function() {
            return a;
        }), r.d(t, "c", function() {
            return s;
        }), r.d(t, "a", function() {
            return n;
        });
        var n = {
            uIcon: function() {
                return r.e("node-modules/uview-ui/components/u-icon/u-icon").then(r.bind(null, "2925"));
            },
            uToast: function() {
                return r.e("node-modules/uview-ui/components/u-toast/u-toast").then(r.bind(null, "446f"));
            }
        }, a = function() {
            this.$createElement;
            this._self._c;
        }, s = [];
    },
    3101: function(e, t, r) {
        r.r(t);
        var n = r("29bf"), a = r("b3c0");
        for (var s in a) [ "default" ].indexOf(s) < 0 && function(e) {
            r.d(t, e, function() {
                return a[e];
            });
        }(s);
        r("a767");
        var i = r("f0c5"), d = Object(i.a)(a.default, n.b, n.c, !1, null, "e39fcaa4", null, !1, n.a, void 0);
        t.default = d.exports;
    },
    "7c04": function(e, t, r) {
        (function(e) {
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = void 0;
            var n = function(e) {
                return e && e.__esModule ? e : {
                    default: e
                };
            }(r("4795")), a = r("7b12");
            function s(e, t, r, n, a, s, i) {
                try {
                    var d = e[s](i), u = d.value;
                } catch (e) {
                    return void r(e);
                }
                d.done ? t(u) : Promise.resolve(u).then(n, a);
            }
            function i(e) {
                return function() {
                    var t = this, r = arguments;
                    return new Promise(function(n, a) {
                        var i = e.apply(t, r);
                        function d(e) {
                            s(i, n, a, d, u, "next", e);
                        }
                        function u(e) {
                            s(i, n, a, d, u, "throw", e);
                        }
                        d(void 0);
                    });
                };
            }
            var d = {
                data: function() {
                    return {
                        title: "新增地址",
                        tipsNum: "",
                        index: 0,
                        addressIndex: 1,
                        date: "",
                        consigneeName: "",
                        consigneeNumber: "",
                        deliveryAddress: "",
                        deliveryAddressId: "",
                        isDefaltAddress: !0,
                        multiArray: [],
                        multiIndex: [ 0, 0, 0, 0 ],
                        alreadyAddress: !1,
                        addressObj: {}
                    };
                },
                onLoad: function(e) {
                    var t = this;
                    this.getOpenerEventChannel().on("acceptDataFromOpenerPage", function() {
                        var e = i(n.default.mark(function e(r) {
                            return n.default.wrap(function(e) {
                                for (;;) switch (e.prev = e.next) {
                                  case 0:
                                    console.log("跳转传参-修改地址:", r), r.addressList ? (t.title = "修改地址", t.addressObj = JSON.parse(r.addressList), 
                                    console.log("地址解包", t.addressObj), t.$set(t, "tipsNum", t.addressObj.tag), t.$set(t, "consigneeName", t.addressObj.consigneeName), 
                                    t.$set(t, "consigneeNumber", t.addressObj.consigneeNumber), t.$set(t, "deliveryAddress", t.addressObj.deliveryAddress), 
                                    t.$set(t, "deliveryAddressId", t.addressObj.deliveryAddressId), t.$set(t, "isDefaltAddress", 0 != t.addressObj.isDefaltAddress), 
                                    t.$set(t, "alreadyAddress", !0), t.getProvinceList(), t.getCityList(t.addressObj.provinceId), 
                                    t.getDistrictList(t.addressObj.cityId), t.getStreetList(t.addressObj.areaId)) : t.getProvinceList().then(function() {
                                        t.getCityList(t.multiArray[0][0].addrId).then(function() {
                                            t.getDistrictList(t.multiArray[1][0].addrId).then(function() {
                                                t.getStreetList(t.multiArray[2][0].addrId);
                                            });
                                        });
                                    });

                                  case 2:
                                  case "end":
                                    return e.stop();
                                }
                            }, e);
                        }));
                        return function(t) {
                            return e.apply(this, arguments);
                        };
                    }());
                },
                methods: {
                    inputChange: function(e) {
                        console.log("地址变更", e.detail.value), this.deliveryAddress = e.detail.value;
                    },
                    consigneeNameChange: function(e) {
                        this.consigneeName = e.detail.value;
                    },
                    consigneeNumberChange: function(e) {
                        this.consigneeNumber = e.detail.value;
                    },
                    comfirm: function() {
                        var t = this;
                        return i(n.default.mark(function r() {
                            var s, i, d, u, o, c, l, f, m;
                            return n.default.wrap(function(r) {
                                for (;;) switch (r.prev = r.next) {
                                  case 0:
                                    s = "", i = "", d = "";
                                    try {
                                        (u = (u = e.getStorageSync("loginData2")) ? JSON.parse(u) : {}).memberId && (s = u.memberId), 
                                        o = e.getStorageSync("memberDeliveryAddress"), (o = JSON.parse(o)).consigneeName && o.consigneeNumber && (i = o.consigneeName, 
                                        d = o.consigneeNumber);
                                    } catch (e) {}
                                    if (i || t.consigneeName) {
                                        r.next = 7;
                                        break;
                                    }
                                    return t.showToast("收件人不能为空！", "error"), r.abrupt("return");

                                  case 7:
                                    if (/^[\u4E00-\u9FA5A-Za-z0-9_]+$/.test(t.consigneeName)) {
                                        r.next = 11;
                                        break;
                                    }
                                    return t.showToast("姓名不能含有特殊符号！", "error"), r.abrupt("return");

                                  case 11:
                                    if (d || t.consigneeNumber) {
                                        r.next = 14;
                                        break;
                                    }
                                    return t.showToast("手机号不能为空！", "error"), r.abrupt("return");

                                  case 14:
                                    if (/^[1][3,4,5,6,7,8,9][0-9]{9}$/.test(t.consigneeNumber)) {
                                        r.next = 18;
                                        break;
                                    }
                                    return t.showToast("手机号不正确！", "error"), r.abrupt("return");

                                  case 18:
                                    if (!(!t.multiArray[0].length > 0 || !t.multiArray[1].length > 0 || !t.multiArray[2].length > 0)) {
                                        r.next = 21;
                                        break;
                                    }
                                    return t.showToast("请补全省市区！", "error"), r.abrupt("return");

                                  case 21:
                                    if (t.deliveryAddress) {
                                        r.next = 24;
                                        break;
                                    }
                                    return t.showToast("详细地址不能为空！", "error"), r.abrupt("return");

                                  case 24:
                                    if (console.log(t.multiArray[3][t.multiIndex[3]]), c = t.multiArray[3].length > 0 ? t.multiArray[3][t.multiIndex[3]].addrId : "", 
                                    l = t.multiArray[3].length > 0 ? t.multiArray[3][t.multiIndex[3]].addrName : "", 
                                    f = {
                                        areaId: t.multiArray[2][t.multiIndex[2]].addrId || "",
                                        areaName: t.multiArray[2][t.multiIndex[2]].addrName || "",
                                        cityId: t.multiArray[1][t.multiIndex[1]].addrId || "",
                                        cityName: t.multiArray[1][t.multiIndex[1]].addrName || "",
                                        consigneeName: t.consigneeName || i,
                                        consigneeNumber: t.consigneeNumber || d,
                                        deliveryAddress: t.deliveryAddress,
                                        deliveryAddressId: t.deliveryAddressId || "",
                                        isDefaltAddress: t.isDefaltAddress ? 1 : 0,
                                        memberId: s,
                                        provinceId: t.multiArray[0][t.multiIndex[0]].addrId || "",
                                        provinceName: t.multiArray[0][t.multiIndex[0]].addrName || "",
                                        streetId: c,
                                        streetName: l,
                                        tag: t.tipsNum
                                    }, !t.alreadyAddress) {
                                        r.next = 35;
                                        break;
                                    }
                                    return r.next = 31, (0, a.updateAddress)(f);

                                  case 31:
                                    "00000" == (m = r.sent).data.code && (t.showToast("修改成功！", "success"), setTimeout(function(t) {
                                        e.navigateBack();
                                    }, 500)), r.next = 39;
                                    break;

                                  case 35:
                                    return r.next = 37, (0, a.saveAddAddress)(f);

                                  case 37:
                                    "00000" == (m = r.sent).data.code && (t.showToast("新增成功！", "success"), setTimeout(function(t) {
                                        e.navigateBack();
                                    }, 500));

                                  case 39:
                                    "00000" != m.data.code && t.showToast(m.data.message, "warning");

                                  case 40:
                                  case "end":
                                    return r.stop();
                                }
                            }, r);
                        }))();
                    },
                    checkTips: function(e) {
                        this.tipsNum = e;
                    },
                    getStreetList: function(e) {
                        var t = this;
                        return i(n.default.mark(function r() {
                            var s, i, d;
                            return n.default.wrap(function(r) {
                                for (;;) switch (r.prev = r.next) {
                                  case 0:
                                    return r.next = 2, (0, a.streetList)(e);

                                  case 2:
                                    if ("00000" == (s = r.sent).data.code) {
                                        if (i = s.data.data.regionAddressVOList, t.$set(t.multiArray, 3, []), t.$set(t.multiArray, 3, i), 
                                        t.alreadyAddress) for (d = 0; d < t.multiArray[3].length; d++) t.multiArray[3][d].addrId == t.addressObj.streetId && t.$set(t.multiIndex, 3, d); else t.$set(t.multiIndex, 3, 0), 
                                        t.multiIndex[3] = 0;
                                        t.multiIndex[3] || (t.multiIndex[3] = 0);
                                    }

                                  case 4:
                                  case "end":
                                    return r.stop();
                                }
                            }, r);
                        }))();
                    },
                    getDistrictList: function(e) {
                        var t = this;
                        return i(n.default.mark(function r() {
                            var s, i, d;
                            return n.default.wrap(function(r) {
                                for (;;) switch (r.prev = r.next) {
                                  case 0:
                                    return r.next = 2, (0, a.districtList)(e);

                                  case 2:
                                    if ("00000" == (s = r.sent).data.code && (i = s.data.data.regionAddressVOList, t.$set(t.multiArray, 2, []), 
                                    t.$set(t.multiArray, 2, i), t.alreadyAddress)) for (d = 0; d < t.multiArray[2].length; d++) t.multiArray[2][d].addrId == t.addressObj.areaId && t.$set(t.multiIndex, 2, d);

                                  case 4:
                                  case "end":
                                    return r.stop();
                                }
                            }, r);
                        }))();
                    },
                    getCityList: function(e) {
                        var t = this;
                        return i(n.default.mark(function r() {
                            var s, i, d;
                            return n.default.wrap(function(r) {
                                for (;;) switch (r.prev = r.next) {
                                  case 0:
                                    return r.next = 2, (0, a.cityList)(e);

                                  case 2:
                                    if ("00000" == (s = r.sent).data.code && (i = s.data.data.regionAddressVOList, t.multiArray[1] = [], 
                                    t.$set(t.multiArray, 1, i), t.alreadyAddress)) for (d = 0; d < t.multiArray[1].length; d++) t.multiArray[1][d].addrId == t.addressObj.cityId && t.$set(t.multiIndex, 1, d);

                                  case 4:
                                  case "end":
                                    return r.stop();
                                }
                            }, r);
                        }))();
                    },
                    getProvinceList: function() {
                        var e = this;
                        return i(n.default.mark(function t() {
                            var r, s, i;
                            return n.default.wrap(function(t) {
                                for (;;) switch (t.prev = t.next) {
                                  case 0:
                                    return t.next = 2, (0, a.provinceList)();

                                  case 2:
                                    if ("00000" == (r = t.sent).data.code && (s = r.data.data.regionAddressVOList, e.$set(e.multiArray, 0, s), 
                                    e.alreadyAddress)) for (i = 0; i < e.multiArray[0].length; i++) e.multiArray[0][i].addrId == e.addressObj.provinceId && e.$set(e.multiIndex, 0, i);

                                  case 4:
                                  case "end":
                                    return t.stop();
                                }
                            }, t);
                        }))();
                    },
                    bindMultiPickerChange: function(e) {
                        console.log("picker发送选择改变，携带值为 multiIndex", e.detail.value), this.$set(this, "multiIndex", e.detail.value), 
                        console.log("地址数组", this.multiArray);
                    },
                    bindMultiPickerColumnChange: function(e) {
                        var t = this;
                        console.log("修改的列为", e.detail.column, "，值为", e.detail.value);
                        var r = e.detail.column, n = e.detail.value;
                        if (this.multiIndex[e.detail.column] = e.detail.value, console.log("最新选中数组", this.multiIndex), 
                        0 == r) {
                            var a = this.multiArray[r][n].addrId;
                            this.getCityList(a).then(function(e) {
                                t.multiIndex[1] = 0, t.getDistrictList(t.multiArray[1][0].addrId).then(function(e) {
                                    console.log("区至零11"), t.multiIndex[2] = 0, t.getStreetList(t.multiArray[2][0].addrId).then(function(e) {
                                        t.multiIndex[3] = 0;
                                    });
                                });
                            });
                        } else if (1 == r) {
                            var s = this.multiArray[r][n].addrId;
                            this.getDistrictList(s).then(function(e) {
                                console.log("区至零22"), t.multiIndex[2] = 0, t.getStreetList(t.multiArray[2][0].addrId).then(function(e) {
                                    t.multiIndex[3] = 0;
                                });
                            });
                        } else if (2 == r) {
                            var i = this.multiArray[r][n].addrId;
                            this.getStreetList(i).then(function(e) {});
                        }
                    },
                    switch1Change: function() {
                        var e = i(n.default.mark(function e(t) {
                            var r;
                            return n.default.wrap(function(e) {
                                for (;;) switch (e.prev = e.next) {
                                  case 0:
                                    if (console.log("switch1 发生 设置默认，携带值为", this.deliveryAddressId), console.log("switch1 发生 设置默认，携带值为", t.target.value), 
                                    this.isDefaltAddress = t.target.value, !t.target.value) {
                                        e.next = 8;
                                        break;
                                    }
                                    return e.next = 6, (0, a.setDefaultAddress)(this.deliveryAddressId);

                                  case 6:
                                    r = e.sent, console.log("默认结果", r);

                                  case 8:
                                  case "end":
                                    return e.stop();
                                }
                            }, e, this);
                        }));
                        return function(t) {
                            return e.apply(this, arguments);
                        };
                    }(),
                    pickerChangeDate: function(e) {
                        console.log("picker发送选择改变，生日 携带值为", e.detail.value), this.date = e.detail.value;
                    },
                    bindPickerChange: function(e) {
                        console.log("picker发送选择改变，携带值为", e.detail.value), this.index = e.detail.value;
                    },
                    showToast: function(e, t) {
                        this.$refs.uToast.show({
                            title: e,
                            type: t
                        });
                    }
                }
            };
            t.default = d;
        }).call(this, r("543d").default);
    },
    a767: function(e, t, r) {
        var n = r("b747");
        r.n(n).a;
    },
    b3c0: function(e, t, r) {
        r.r(t);
        var n = r("7c04"), a = r.n(n);
        for (var s in n) [ "default" ].indexOf(s) < 0 && function(e) {
            r.d(t, e, function() {
                return n[e];
            });
        }(s);
        t.default = a.a;
    },
    b747: function(e, t, r) {},
    bb08: function(e, t, r) {
        (function(e) {
            r("6cdc"), n(r("66fd"));
            var t = n(r("3101"));
            function n(e) {
                return e && e.__esModule ? e : {
                    default: e
                };
            }
            wx.__webpack_require_UNI_MP_PLUGIN__ = r, e(t.default);
        }).call(this, r("543d").createPage);
    }
}, [ [ "bb08", "common/runtime", "common/vendor" ] ] ]);