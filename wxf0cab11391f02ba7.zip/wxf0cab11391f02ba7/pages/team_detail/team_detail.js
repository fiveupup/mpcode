require("../../@babel/runtime/helpers/Arrayincludes"), (global.webpackJsonp = global.webpackJsonp || []).push([ [ "pages/team_detail/team_detail" ], {
    1799: function(t, n, e) {
        e.r(n);
        var o = e("a032"), i = e("319e");
        for (var r in i) [ "default" ].indexOf(r) < 0 && function(t) {
            e.d(n, t, function() {
                return i[t];
            });
        }(r);
        e("bc9d");
        var a = e("f0c5"), s = Object(a.a)(i.default, o.b, o.c, !1, null, "2a8be3d8", null, !1, o.a, void 0);
        n.default = s.exports;
    },
    "319e": function(t, n, e) {
        e.r(n);
        var o = e("8810"), i = e.n(o);
        for (var r in o) [ "default" ].indexOf(r) < 0 && function(t) {
            e.d(n, t, function() {
                return o[t];
            });
        }(r);
        n.default = i.a;
    },
    3926: function(t, n, e) {
        (function(t) {
            e("6cdc"), o(e("66fd"));
            var n = o(e("1799"));
            function o(t) {
                return t && t.__esModule ? t : {
                    default: t
                };
            }
            wx.__webpack_require_UNI_MP_PLUGIN__ = e, t(n.default);
        }).call(this, e("543d").createPage);
    },
    8810: function(t, n, e) {
        (function(t) {
            Object.defineProperty(n, "__esModule", {
                value: !0
            }), n.default = void 0;
            var o = function(t) {
                return t && t.__esModule ? t : {
                    default: t
                };
            }(e("4795")), i = e("365c"), r = e("e830");
            function a(t, n) {
                return function(t) {
                    if (Array.isArray(t)) return t;
                }(t) || function(t, n) {
                    var e = null == t ? null : "undefined" != typeof Symbol && t[Symbol.iterator] || t["@@iterator"];
                    if (null != e) {
                        var o, i, r = [], a = !0, s = !1;
                        try {
                            for (e = e.call(t); !(a = (o = e.next()).done) && (r.push(o.value), !n || r.length !== n); a = !0) ;
                        } catch (t) {
                            s = !0, i = t;
                        } finally {
                            try {
                                a || null == e.return || e.return();
                            } finally {
                                if (s) throw i;
                            }
                        }
                        return r;
                    }
                }(t, n) || function(t, n) {
                    if (t) {
                        if ("string" == typeof t) return s(t, n);
                        var e = Object.prototype.toString.call(t).slice(8, -1);
                        return "Object" === e && t.constructor && (e = t.constructor.name), "Map" === e || "Set" === e ? Array.from(t) : "Arguments" === e || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(e) ? s(t, n) : void 0;
                    }
                }(t, n) || function() {
                    throw new TypeError("Invalid attempt to destructure non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.");
                }();
            }
            function s(t, n) {
                (null == n || n > t.length) && (n = t.length);
                for (var e = 0, o = new Array(n); e < n; e++) o[e] = t[e];
                return o;
            }
            function c(t, n, e, o, i, r, a) {
                try {
                    var s = t[r](a), c = s.value;
                } catch (t) {
                    return void e(t);
                }
                s.done ? n(c) : Promise.resolve(c).then(o, i);
            }
            function u(t) {
                return function() {
                    var n = this, e = arguments;
                    return new Promise(function(o, i) {
                        var r = t.apply(n, e);
                        function a(t) {
                            c(r, o, i, a, s, "next", t);
                        }
                        function s(t) {
                            c(r, o, i, a, s, "throw", t);
                        }
                        a(void 0);
                    });
                };
            }
            var l = {
                components: {
                    ArticlePoster: function() {
                        e.e("components/poster/article").then(function() {
                            return resolve(e("ccbb"));
                        }.bind(null, e)).catch(e.oe);
                    }
                },
                name: "team_detail",
                data: function() {
                    return {
                        avatar: "https://pepsicocampuscrmstgblob.blob.core.chinacloudapi.cn/pepsicocampuscrmstgblob/FAQ_202305061358136407.jpeg",
                        info: {},
                        id: "",
                        loginData: {},
                        imgList: [],
                        style: {
                            ".ql-align-right": "text-align: right;",
                            ".ql-align-center": "text-align: center;"
                        },
                        votingInfo: {
                            id: 0,
                            memberSelectOptionsId: 0,
                            votingName: "",
                            endTime: "",
                            votingReward: 0,
                            rewardType: 1,
                            rewardPoint: 0,
                            couponObj: null,
                            goodsObj: null,
                            lotteryStatus: 0,
                            votingStatus: 0,
                            votingOptionsResponseList: []
                        },
                        currentOptionId: 0,
                        voteCount: 0,
                        replyFocus: !1,
                        modalVisible: !1,
                        currentCommentId: 0,
                        comments: [],
                        commentParams: {
                            pageNum: 1,
                            pageSize: 10,
                            originalInfoId: 0
                        },
                        commentTotal: 0,
                        commentContent: "",
                        sending: !1,
                        commentId: 0,
                        imgLoadCount: 0,
                        isScrollComment: !1,
                        showPost: !1
                    };
                },
                computed: {
                    maxImgHeight: function() {
                        var t = 0;
                        this.imgList.length > 0 && (t = Math.max.apply(Math, this.imgList.map(function(t) {
                            return t.height;
                        })));
                        var n = parseFloat((.6 * this.windowHeight).toFixed());
                        return this.imgList.length > 1 ? Math.min(t, n) + "px" : t + "px";
                    }
                },
                onLoad: function(n) {
                    var e = this;
                    return u(o.default.mark(function i() {
                        var a;
                        return o.default.wrap(function(o) {
                            for (;;) switch (o.prev = o.next) {
                              case 0:
                                a = t.getStorageSync("loginData2"), e.loginData = a ? JSON.parse(a) : {}, e.id = n.id, 
                                n.scene && (e.id = e.getSceneId(decodeURIComponent(n.scene))), e.commentParams.originalInfoId = e.id, 
                                e.commentId = Number(n.commentId || 0), e.init(e.id), e.aspectRatio = getApp().globalData.aspectRatio, 
                                e.windowHeight = getApp().globalData.windowHeight, e.loginData.token && (0, r.pv)(Number(e.id));

                              case 10:
                              case "end":
                                return o.stop();
                            }
                        }, i);
                    }))();
                },
                onShareAppMessage: function(n) {
                    var e = this;
                    console.log(n), t.showLoading(), (0, i.shark)(this.id).then(function(n) {
                        t.hideLoading(), e.info.sharksNum += 1;
                    }).catch(function() {
                        t.hideLoading();
                    });
                },
                onReachBottom: function() {
                    0 !== this.commentTotal && this.commentTotal > this.comments.length && (this.commentParams.pageNum += 1, 
                    this.loadCommentData());
                },
                methods: {
                    loadImg: function(t, n) {
                        var e = t.detail.width / t.detail.height, o = getApp().globalData.windowWidth, i = (o - o / 750 * 60) / e;
                        this.imgList[n].height = n > 0 ? i + o / 750 * 66 : i, console.log("load end ", t, o, e), 
                        this.imgLoadCount += 1, this.imgLoadCount === this.imgList.length && this.scrollToAppointComment();
                    },
                    init: function(n) {
                        var e = this;
                        return u(o.default.mark(function r() {
                            var a, s, c, u, l, m, d;
                            return o.default.wrap(function(o) {
                                for (;;) switch (o.prev = o.next) {
                                  case 0:
                                    return t.showLoading({
                                        mask: !0
                                    }), o.prev = 1, o.next = 4, (0, i.getOriginalInfoById)(n);

                                  case 4:
                                    "00000" === (a = o.sent).data.code && ((u = a.data.data || {}).tags = null === (s = u.tags) || void 0 === s ? void 0 : s.split(",").filter(function(t) {
                                        return t;
                                    }), e.info = u, l = [], (m = null === (c = e.info.imgs) || void 0 === c ? void 0 : c.split(",").filter(function(t) {
                                        return t;
                                    })).length > 0 && (l = m.map(function(t) {
                                        return {
                                            url: t,
                                            height: 0
                                        };
                                    })), e.imgList = l, u.votingId && e.loginData.memberId && e.loadVoting(u.votingId), 
                                    e.loginData.token && e.loadCommentData()), t.hideLoading(), "00000" != a.data.code && (t.showToast({
                                        title: a.data.message,
                                        icon: "none"
                                    }), d = setTimeout(function() {
                                        clearTimeout(d), t.switchTab({
                                            url: "/pages/team/team"
                                        });
                                    }, 1800)), o.next = 13;
                                    break;

                                  case 10:
                                    o.prev = 10, o.t0 = o.catch(1), t.hideLoading();

                                  case 13:
                                  case "end":
                                    return o.stop();
                                }
                            }, r, null, [ [ 1, 10 ] ]);
                        }))();
                    },
                    handleShare: function() {
                        this.showPost || (this.showPost = !0);
                    },
                    onShareCount: function() {
                        var t = this;
                        (0, i.shark)(this.id).then(function() {
                            t.info.sharksNum += 1;
                        });
                    },
                    handlePreviewImg: function(n) {
                        t.previewImage({
                            current: n,
                            urls: this.imgList.map(function(t) {
                                return t.url;
                            }),
                            indicator: "default"
                        });
                    },
                    loadVoting: function(t) {
                        var n = this;
                        return u(o.default.mark(function e() {
                            var r, a;
                            return o.default.wrap(function(e) {
                                for (;;) switch (e.prev = e.next) {
                                  case 0:
                                    return e.next = 2, (0, i.voting)(t);

                                  case 2:
                                    r = e.sent, a = r.data, n.votingInfo = a.data;

                                  case 5:
                                  case "end":
                                    return e.stop();
                                }
                            }, e);
                        }))();
                    },
                    handleConfirmVote: function() {
                        var t = this;
                        return u(o.default.mark(function n() {
                            var e, r;
                            return o.default.wrap(function(n) {
                                for (;;) switch (n.prev = n.next) {
                                  case 0:
                                    if (!t.currentOptionId) {
                                        n.next = 7;
                                        break;
                                    }
                                    return e = t.votingInfo.votingOptionsResponseList.find(function(n) {
                                        return n.id === t.currentOptionId;
                                    }), n.next = 4, (0, i.vote)({
                                        optionId: t.currentOptionId,
                                        optionName: e.optionName,
                                        votingId: t.votingInfo.id,
                                        memberMobile: t.loginData.phone,
                                        memberId: t.loginData.memberId,
                                        memberNo: t.loginData.memberNo
                                    });

                                  case 4:
                                    r = n.sent, "00000" === r.data.code && (t.votingInfo.memberSelectOptionsId = t.currentOptionId, 
                                    t.votingInfo.votingOptionsResponseList = t.votingInfo.votingOptionsResponseList.map(function(n) {
                                        return n.id === t.currentOptionId && (n.votingNum += 1), n;
                                    }));

                                  case 7:
                                  case "end":
                                    return n.stop();
                                }
                            }, n);
                        }))();
                    },
                    loadCommentData: function() {
                        var t = arguments, n = this;
                        return u(o.default.mark(function e() {
                            var i, a, s, c, u, l;
                            return o.default.wrap(function(e) {
                                for (;;) switch (e.prev = e.next) {
                                  case 0:
                                    return a = t.length > 0 && void 0 !== t[0] && t[0], e.next = 3, (0, r.commentList)(n.commentParams);

                                  case 3:
                                    s = e.sent, c = s.data, a && (u = n.comments.length, l = parseInt(u / 10), n.comments.splice(10 * l, u)), 
                                    n.comments = n.comments.concat(null === (i = c.data) || void 0 === i ? void 0 : i.list), 
                                    n.commentTotal = c.data.total, n.isScrollComment || n.imgLoadCount !== n.imgList.length || n.scrollToAppointComment();

                                  case 9:
                                  case "end":
                                    return e.stop();
                                }
                            }, e);
                        }))();
                    },
                    scrollToAppointComment: function() {
                        var n = this;
                        0 !== this.commentId && (this.comments.some(function(t) {
                            return t.id === n.commentId;
                        }) ? this.$nextTick(function() {
                            t.createSelectorQuery().in(n).select("#comment").boundingClientRect(function(e) {
                                console.log("得到布局位置信息" + JSON.stringify(e)), n.$nextTick(function() {
                                    t.pageScrollTo({
                                        scrollTop: e.top,
                                        duration: 500
                                    }), n.isScrollComment = !0;
                                });
                            }).exec();
                        }) : this.commentTotal > this.comments.length && (this.commentParams.pageNum += 1, 
                        this.loadCommentData()));
                    },
                    handleFocus: function() {
                        var t = this;
                        this.replyFocus = !0;
                        var n = setTimeout(function() {
                            clearTimeout(n), t.replyFocus = !0;
                        }, 300);
                    },
                    handleBlur: function() {
                        this.sending || (this.replyFocus = !1);
                    },
                    handleSendComment: function() {
                        var n = this;
                        return u(o.default.mark(function e() {
                            var i;
                            return o.default.wrap(function(e) {
                                for (;;) switch (e.prev = e.next) {
                                  case 0:
                                    if (!n.sending) {
                                        e.next = 2;
                                        break;
                                    }
                                    return e.abrupt("return");

                                  case 2:
                                    if (n.commentContent.trim()) {
                                        e.next = 5;
                                        break;
                                    }
                                    return t.showToast({
                                        title: "请输入内容",
                                        icon: "none"
                                    }), e.abrupt("return");

                                  case 5:
                                    return n.sending = !0, e.next = 8, (0, r.sendComment)(n.id, n.commentContent);

                                  case 8:
                                    i = e.sent, i.data.data && (t.showToast({
                                        title: "评论成功",
                                        icon: "none"
                                    }), n.commentTotal += 1, 0 !== n.comments.length && n.comments.length % 10 == 0 || n.loadCommentData(!0), 
                                    n.commentContent = "", n.sending = !1, n.replyFocus = !1);

                                  case 11:
                                  case "end":
                                    return e.stop();
                                }
                            }, e);
                        }))();
                    },
                    handleRemoveComment: function(t) {
                        this.currentCommentId = t.id, this.modalVisible = !0;
                    },
                    handleConfirmRemoveComment: function() {
                        var n = this;
                        return u(o.default.mark(function e() {
                            var i;
                            return o.default.wrap(function(e) {
                                for (;;) switch (e.prev = e.next) {
                                  case 0:
                                    return e.next = 2, (0, r.removeComment)(n.currentCommentId);

                                  case 2:
                                    i = e.sent, i.data.data && (n.comments = n.comments.filter(function(t) {
                                        return t.id !== n.currentCommentId;
                                    }), n.commentTotal -= 1, n.modalVisible = !1, t.showToast({
                                        title: "删除评论成功",
                                        icon: "none"
                                    }));

                                  case 5:
                                  case "end":
                                    return e.stop();
                                }
                            }, e);
                        }))();
                    },
                    getPercent: function(t) {
                        var n = 0;
                        return this.votingInfo.votingOptionsResponseList.forEach(function(t) {
                            n += t.votingNum;
                        }), parseFloat((t / n * 100).toFixed());
                    },
                    handleToRecords: function() {
                        t.navigateTo({
                            url: "/pages/voting/record?articleId=".concat(this.id, "&votingId=").concat(this.votingInfo.id)
                        });
                    },
                    clickLike: function() {
                        var n = this;
                        return u(o.default.mark(function e() {
                            return o.default.wrap(function(e) {
                                for (;;) switch (e.prev = e.next) {
                                  case 0:
                                    if (n.loginData.token) {
                                        e.next = 3;
                                        break;
                                    }
                                    return n.toLogin(), e.abrupt("return");

                                  case 3:
                                    if (t.showLoading(), !n.info.isLikes) {
                                        e.next = 11;
                                        break;
                                    }
                                    return e.next = 7, (0, i.cancelLikes)(n.id);

                                  case 7:
                                    n.$set(n.info, "likesNum", n.info.likesNum - 1), n.$set(n.info, "isLikes", 0), e.next = 15;
                                    break;

                                  case 11:
                                    return e.next = 13, (0, i.giveALike)(n.id);

                                  case 13:
                                    n.$set(n.info, "likesNum", n.info.likesNum + 1), n.$set(n.info, "isLikes", 1);

                                  case 15:
                                    t.hideLoading();

                                  case 16:
                                  case "end":
                                    return e.stop();
                                }
                            }, e);
                        }))();
                    },
                    toLogin: function() {
                        t.showModal({
                            title: "提示",
                            content: "请先登录",
                            confirmColor: "#37eea8",
                            success: function(n) {
                                n.confirm ? (console.log("用户点击确定"), t.navigateTo({
                                    url: "/pages/login/login"
                                })) : n.cancel && console.log("用户点击取消");
                            }
                        });
                    },
                    getSceneId: function(t) {
                        return t.includes("=") ? this.stringToObject(t).ID : t;
                    },
                    stringToObject: function(t) {
                        return t.split("&").reduce(function(t, n) {
                            var e = a(n.split("="), 2), o = e[0], i = e[1];
                            return t[o] = i, t;
                        }, {});
                    }
                }
            };
            n.default = l;
        }).call(this, e("543d").default);
    },
    a032: function(t, n, e) {
        e.d(n, "b", function() {
            return i;
        }), e.d(n, "c", function() {
            return r;
        }), e.d(n, "a", function() {
            return o;
        });
        var o = {
            uParse: function() {
                return Promise.all([ e.e("common/vendor"), e.e("node-modules/uview-ui/components/u-parse/u-parse") ]).then(e.bind(null, "492b"));
            },
            uLineProgress: function() {
                return e.e("node-modules/uview-ui/components/u-line-progress/u-line-progress").then(e.bind(null, "1edd"));
            },
            uModal: function() {
                return e.e("node-modules/uview-ui/components/u-modal/u-modal").then(e.bind(null, "f29e"));
            }
        }, i = function() {
            var t = this, n = (t.$createElement, t._self._c, (t.info.votingId && t.loginData.memberId || t.comments.length > 0) && t.info.votingId && t.loginData.memberId && t.votingInfo.memberSelectOptionsId ? t.__map(t.votingInfo.votingOptionsResponseList, function(n, e) {
                return {
                    $orig: t.__get_orig(n),
                    m0: t.getPercent(n.votingNum),
                    m1: "RATE" === t.votingInfo.progressDisplay ? t.getPercent(n.votingNum) : null
                };
            }) : null), e = (t.info.votingId && t.loginData.memberId || t.comments.length > 0) && t.info.votingId && t.loginData.memberId && 0 !== t.votingInfo.votingReward && 2 === t.votingInfo.votingReward && t.votingInfo.couponObj ? JSON.parse(t.votingInfo.couponObj).map(function(t) {
                return t.couponName + "*1";
            }).join("、") : null, o = (t.info.votingId && t.loginData.memberId || t.comments.length > 0) && t.info.votingId && t.loginData.memberId && 0 !== t.votingInfo.votingReward && 3 === t.votingInfo.votingReward && t.votingInfo.goodsObj ? JSON.parse(t.votingInfo.goodsObj).map(function(t) {
                return t.goodsName + "*" + t.quantity;
            }).join("、") : null, i = (t.info.votingId && t.loginData.memberId || t.comments.length > 0) && t.info.votingId && t.loginData.memberId ? [ 3, 4 ].includes(t.votingInfo.rewardType) : null, r = t.showPost ? Number(t.id) : null;
            t._isMounted || (t.e0 = function(n, e) {
                for (var o = [], i = arguments.length - 2; i-- > 0; ) o[i] = arguments[i + 2];
                var r = o[o.length - 1].currentTarget.dataset, a = r.eventParams || r["event-params"];
                return e = a.index, t.loadImg(n, e);
            }, t.e1 = function(n) {
                return n.stopPropagation(), t.handleFocus(n);
            }, t.e2 = function(n, e) {
                var o = arguments[arguments.length - 1].currentTarget.dataset, i = o.eventParams || o["event-params"];
                e = i.item, t.currentOptionId = e.id;
            }, t.e3 = function(n) {
                t.commentContent = n.detail.value;
            }, t.e4 = function(n) {
                t.modalVisible = !1;
            }, t.e5 = function(n) {
                t.showPost = !1;
            }), t.$mp.data = Object.assign({}, {
                $root: {
                    l0: n,
                    g0: e,
                    g1: o,
                    g2: i,
                    m2: r
                }
            });
        }, r = [];
    },
    b521: function(t, n, e) {},
    bc9d: function(t, n, e) {
        var o = e("b521");
        e.n(o).a;
    }
}, [ [ "3926", "common/runtime", "common/vendor" ] ] ]);