(global.webpackJsonp = global.webpackJsonp || []).push([ [ "pages/message_detail/message_detail" ], {
    1594: function(e, n, t) {
        t.r(n);
        var a = t("3d0f"), r = t.n(a);
        for (var u in a) [ "default" ].indexOf(u) < 0 && function(e) {
            t.d(n, e, function() {
                return a[e];
            });
        }(u);
        n.default = r.a;
    },
    "3d0f": function(e, n, t) {
        (function(e) {
            Object.defineProperty(n, "__esModule", {
                value: !0
            }), n.default = void 0;
            var a = function(e) {
                return e && e.__esModule ? e : {
                    default: e
                };
            }(t("4795")), r = t("7b12");
            function u(e, n, t, a, r, u, o) {
                try {
                    var c = e[u](o), i = c.value;
                } catch (e) {
                    return void t(e);
                }
                c.done ? n(i) : Promise.resolve(i).then(a, r);
            }
            function o(e) {
                return function() {
                    var n = this, t = arguments;
                    return new Promise(function(a, r) {
                        var o = e.apply(n, t);
                        function c(e) {
                            u(o, a, r, c, i, "next", e);
                        }
                        function i(e) {
                            u(o, a, r, c, i, "throw", e);
                        }
                        c(void 0);
                    });
                };
            }
            var c = {
                data: function() {
                    return {
                        status: "nomore",
                        listArray: [],
                        detailData: {},
                        style: {
                            ".ql-align-right": "text-align: right;",
                            ".ql-align-center": "text-align: center;"
                        }
                    };
                },
                onLoad: function() {
                    var n = this;
                    return o(a.default.mark(function t() {
                        return a.default.wrap(function(t) {
                            for (;;) switch (t.prev = t.next) {
                              case 0:
                                n.getOpenerEventChannel().on("acceptDataFromOpenerPage", function() {
                                    var t = o(a.default.mark(function t(u) {
                                        var o, c, i, f, d;
                                        return a.default.wrap(function(t) {
                                            for (;;) switch (t.prev = t.next) {
                                              case 0:
                                                if (console.log("跳转传参-修改地址:", u), !u.messageId) {
                                                    t.next = 17;
                                                    break;
                                                }
                                                o = "";
                                                try {
                                                    (c = (c = e.getStorageSync("loginData2")) ? JSON.parse(c) : {}).memberId && (o = c.memberId);
                                                } catch (e) {}
                                                return i = {
                                                    memberId: o,
                                                    messageId: u.messageId
                                                }, t.next = 7, (0, r.selectMessageById)(i);

                                              case 7:
                                                if (f = t.sent, d = f.data, console.log("消息详情", d), "00000" !== d.code) {
                                                    t.next = 15;
                                                    break;
                                                }
                                                if (n.detailData = d.data, 0 !== d.data.isRead) {
                                                    t.next = 15;
                                                    break;
                                                }
                                                return t.next = 15, (0, r.messageRead)(i);

                                              case 15:
                                                t.next = 17;
                                                break;

                                              case 17:
                                              case "end":
                                                return t.stop();
                                            }
                                        }, t);
                                    }));
                                    return function(e) {
                                        return t.apply(this, arguments);
                                    };
                                }());

                              case 2:
                              case "end":
                                return t.stop();
                            }
                        }, t);
                    }))();
                }
            };
            n.default = c;
        }).call(this, t("543d").default);
    },
    "4f5d": function(e, n, t) {
        t.d(n, "b", function() {
            return r;
        }), t.d(n, "c", function() {
            return u;
        }), t.d(n, "a", function() {
            return a;
        });
        var a = {
            uParse: function() {
                return Promise.all([ t.e("common/vendor"), t.e("node-modules/uview-ui/components/u-parse/u-parse") ]).then(t.bind(null, "492b"));
            }
        }, r = function() {
            this.$createElement;
            this._self._c;
        }, u = [];
    },
    "64af": function(e, n, t) {},
    "7e03": function(e, n, t) {
        t.r(n);
        var a = t("4f5d"), r = t("1594");
        for (var u in r) [ "default" ].indexOf(u) < 0 && function(e) {
            t.d(n, e, function() {
                return r[e];
            });
        }(u);
        t("8f1c");
        var o = t("f0c5"), c = Object(o.a)(r.default, a.b, a.c, !1, null, "3b15cb2f", null, !1, a.a, void 0);
        n.default = c.exports;
    },
    "8f1c": function(e, n, t) {
        var a = t("64af");
        t.n(a).a;
    },
    f03a: function(e, n, t) {
        (function(e) {
            t("6cdc"), a(t("66fd"));
            var n = a(t("7e03"));
            function a(e) {
                return e && e.__esModule ? e : {
                    default: e
                };
            }
            wx.__webpack_require_UNI_MP_PLUGIN__ = t, e(n.default);
        }).call(this, t("543d").createPage);
    }
}, [ [ "f03a", "common/runtime", "common/vendor" ] ] ]);