require("../../@babel/runtime/helpers/Arrayincludes"), (global.webpackJsonp = global.webpackJsonp || []).push([ [ "pages/index/index" ], {
    "034f": function(e, t, a) {
        var n = a("368d");
        a.n(n).a;
    },
    "23be": function(e, t, a) {
        a.r(t);
        var n = a("e4a4"), o = a.n(n);
        for (var r in n) [ "default" ].indexOf(r) < 0 && function(e) {
            a.d(t, e, function() {
                return n[e];
            });
        }(r);
        t.default = o.a;
    },
    "368d": function(e, t, a) {},
    "3dfd": function(e, t, a) {
        a.r(t);
        var n = a("23be");
        for (var o in n) [ "default" ].indexOf(o) < 0 && function(e) {
            a.d(t, e, function() {
                return n[e];
            });
        }(o);
        a("034f");
        var r = a("f0c5"), i = Object(r.a)(n.default, void 0, void 0, !1, null, null, null, !1, void 0, void 0);
        t.default = i.exports;
    },
    8069: function(e, t, a) {
        a.r(t);
        var n = a("da67"), o = a.n(n);
        for (var r in n) [ "default" ].indexOf(r) < 0 && function(e) {
            a.d(t, e, function() {
                return n[e];
            });
        }(r);
        t.default = o.a;
    },
    a629: function(e, t, a) {
        var n = a("a6b8");
        a.n(n).a;
    },
    a6b8: function(e, t, a) {},
    c0e8: function(e, t, a) {
        a.d(t, "b", function() {
            return o;
        }), a.d(t, "c", function() {
            return r;
        }), a.d(t, "a", function() {
            return n;
        });
        var n = {
            uLine: function() {
                return a.e("node-modules/uview-ui/components/u-line/u-line").then(a.bind(null, "10d1"));
            },
            uSwiper: function() {
                return a.e("node-modules/uview-ui/components/u-swiper/u-swiper").then(a.bind(null, "b332"));
            },
            uMask: function() {
                return a.e("node-modules/uview-ui/components/u-mask/u-mask").then(a.bind(null, "f0fd"));
            },
            uToast: function() {
                return a.e("node-modules/uview-ui/components/u-toast/u-toast").then(a.bind(null, "446f"));
            }
        }, o = function() {
            var e = this, t = (e.$createElement, e._self._c, e.ambassadorVisible && e.loginData.token && void 0 !== e.ambassador.id ? [ "COMPLETING", "SUCCESS" ].includes(e.ambassador.status) : null);
            e._isMounted || (e.e0 = function(t) {
                e.showPost = !0;
            }, e.e1 = function(t) {
                e.dialogVisible = !1;
            }, e.e2 = function(t) {
                e.showPost = !1;
            }), e.$mp.data = Object.assign({}, {
                $root: {
                    g0: t
                }
            });
        }, r = [];
    },
    d537: function(e, t, a) {
        (function(e) {
            a("6cdc"), n(a("66fd"));
            var t = n(a("f75a"));
            function n(e) {
                return e && e.__esModule ? e : {
                    default: e
                };
            }
            wx.__webpack_require_UNI_MP_PLUGIN__ = a, e(t.default);
        }).call(this, a("543d").createPage);
    },
    da67: function(e, t, a) {
        (function(e) {
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = void 0;
            var n = f(a("4795")), o = f(a("3dfd")), r = f(a("05b9")), i = a("7b12"), s = a("6d6a"), c = a("40a4"), u = a("30a7"), l = a("403a"), d = a("26cb");
            function f(e) {
                return e && e.__esModule ? e : {
                    default: e
                };
            }
            function p(e, t, a, n, o, r, i) {
                try {
                    var s = e[r](i), c = s.value;
                } catch (e) {
                    return void a(e);
                }
                s.done ? t(c) : Promise.resolve(c).then(n, o);
            }
            function g(e) {
                return function() {
                    var t = this, a = arguments;
                    return new Promise(function(n, o) {
                        var r = e.apply(t, a);
                        function i(e) {
                            p(r, n, o, i, s, "next", e);
                        }
                        function s(e) {
                            p(r, n, o, i, s, "throw", e);
                        }
                        i(void 0);
                    });
                };
            }
            function h(e, t) {
                var a = Object.keys(e);
                if (Object.getOwnPropertySymbols) {
                    var n = Object.getOwnPropertySymbols(e);
                    t && (n = n.filter(function(t) {
                        return Object.getOwnPropertyDescriptor(e, t).enumerable;
                    })), a.push.apply(a, n);
                }
                return a;
            }
            function v(e) {
                for (var t = 1; t < arguments.length; t++) {
                    var a = null != arguments[t] ? arguments[t] : {};
                    t % 2 ? h(Object(a), !0).forEach(function(t) {
                        m(e, t, a[t]);
                    }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(a)) : h(Object(a)).forEach(function(t) {
                        Object.defineProperty(e, t, Object.getOwnPropertyDescriptor(a, t));
                    });
                }
                return e;
            }
            function m(e, t, a) {
                return t in e ? Object.defineProperty(e, t, {
                    value: a,
                    enumerable: !0,
                    configurable: !0,
                    writable: !0
                }) : e[t] = a, e;
            }
            var b = {
                components: {
                    tabbar: function() {
                        Promise.all([ a.e("common/vendor"), a.e("components/tabbar") ]).then(function() {
                            return resolve(a("26fc"));
                        }.bind(null, a)).catch(a.oe);
                    },
                    InvitePoster: function() {
                        a.e("components/poster/invite").then(function() {
                            return resolve(a("4e80"));
                        }.bind(null, a)).catch(a.oe);
                    },
                    Guide: function() {
                        a.e("components/guide/index").then(function() {
                            return resolve(a("304a"));
                        }.bind(null, a)).catch(a.oe);
                    }
                },
                data: function() {
                    return {
                        showPost: !1,
                        avatar: "https://pepsicocampuscrmstgblob.blob.core.chinacloudapi.cn/pepsicocampuscrmstgblob/FAQ_202305061358136407.jpeg",
                        isShareStatus: "",
                        levelCode: "",
                        levelName: "",
                        nextCode: "",
                        nextLevelName: "",
                        growthValue: "-",
                        awaitBg: "",
                        awaitJumpPath: "",
                        nextLevelGrowthValue: "",
                        levelListResponseList: [],
                        point: "-",
                        share_show: !1,
                        show: !1,
                        current: 0,
                        loginData: {},
                        list: [],
                        bindingList: [],
                        isIphone: !1,
                        isOpenPrivacy: !1,
                        clauses: [],
                        checkboxGwList: [],
                        couponLen: "-",
                        dialogVisible: !1,
                        popup: !1,
                        isFirstShowDialog: !1,
                        dialogInfo: {},
                        ambassador: {},
                        ambassadorVisible: !0,
                        lastAmbassador: !1,
                        medals: [],
                        medalCount: 0,
                        exchangeShow: !1
                    };
                },
                onShow: function() {
                    var t = e.getStorageSync("loginData2");
                    this.loginData = t ? JSON.parse(t) : {}, console.log("个人信息loginData2", this.loginData), 
                    this.loginData.token ? (this.getRedPoint(), this.current = 0, this.memberLevel(), 
                    this.checkPoint(), this.checkShareStatus(), this.getSelfCoupon(), this.getPrivacyConfig(), 
                    this.getActivityAllList(), this.getAmbassadorVisible()) : this.getActivityAllListNoLogin(), 
                    this.getMedalList(), this.getAwaitBoxBg();
                },
                onReady: function() {
                    var t = this;
                    e.getStorage({
                        key: "loginData2"
                    }).then(function(e) {
                        if (console.log("---------------", e), 1 !== e.length) {
                            var a = JSON.parse(e[1].data).memberNo;
                            a && t.$refs.tabbar.quietMake(a);
                        }
                    });
                },
                computed: v({}, (0, d.mapState)({
                    appName: function(e) {
                        return e.user.appName;
                    },
                    redPointCount: function(e) {
                        return e.user.redPointCount;
                    }
                })),
                methods: v({
                    getAwaitBoxBg: function() {
                        var e = this;
                        return g(n.default.mark(function t() {
                            var a, o, r;
                            return n.default.wrap(function(t) {
                                for (;;) switch (t.prev = t.next) {
                                  case 0:
                                    return t.next = 2, (0, i.imageResources)();

                                  case 2:
                                    a = t.sent, o = a.data, r = JSON.parse(o.data || "{}"), e.awaitBg = r.img, e.awaitJumpPath = r.path, 
                                    e.exchangeShow = "1" == r.exchange;

                                  case 8:
                                  case "end":
                                    return t.stop();
                                }
                            }, t);
                        }))();
                    },
                    getAmbassadorVisible: function() {
                        var e = this;
                        return g(n.default.mark(function t() {
                            var a, o;
                            return n.default.wrap(function(t) {
                                for (;;) switch (t.prev = t.next) {
                                  case 0:
                                    return t.next = 2, (0, s.ambassadorConfig)();

                                  case 2:
                                    if (a = t.sent, o = a.data, e.ambassadorVisible = !o.data.closeApply, !o.data.closeApply) {
                                        t.next = 7;
                                        break;
                                    }
                                    return t.abrupt("return");

                                  case 7:
                                    (0, s.ambassadorInfo)().then(function(t) {
                                        var a = t.data;
                                        e.ambassador = a.data;
                                    });

                                  case 8:
                                  case "end":
                                    return t.stop();
                                }
                            }, t);
                        }))();
                    },
                    handleGetUserProfile: function() {
                        this.loginData.imageUrl || this.loginData.nickname || (0, l.canIUseVersion)("2.27.0") ? this.gotoPage("/pages/mine/mine") : this.gotoPage("/pages/confirm/confirm");
                    },
                    toLogin: function() {
                        e.navigateTo({
                            url: "/pages/login/login"
                        });
                    },
                    toActivity: function(e) {
                        var t = this.list[e], a = t.jumpType, n = t.appId, o = t.activityGuideUrl, r = t.articleId;
                        this._jump({
                            jumpType: a,
                            appId: n,
                            guideUrl: o,
                            articleId: r
                        });
                    },
                    toAgreement: function(t) {
                        e.navigateTo({
                            url: "/pages/agreement/agreement?ruleType=0&id=" + t
                        });
                    },
                    handleAgreePrivacy: function() {
                        var e = this;
                        return g(n.default.mark(function t() {
                            var a;
                            return n.default.wrap(function(t) {
                                for (;;) switch (t.prev = t.next) {
                                  case 0:
                                    return t.next = 2, (0, i.agreePrivacy)();

                                  case 2:
                                    a = t.sent, console.log("用户同意授权", a), "00000" == a.data.code && (e.isOpenPrivacy = !1, 
                                    e.getHomeDialog());

                                  case 5:
                                  case "end":
                                    return t.stop();
                                }
                            }, t);
                        }))();
                    },
                    getPrivacyConfig: function() {
                        var e = this;
                        return g(n.default.mark(function t() {
                            var a;
                            return n.default.wrap(function(t) {
                                for (;;) switch (t.prev = t.next) {
                                  case 0:
                                    return t.next = 2, (0, i.getPrivacyConfig)();

                                  case 2:
                                    if (a = t.sent, console.log("是否开启弹窗", a), "00000" != a.data.code) {
                                        t.next = 11;
                                        break;
                                    }
                                    if (!a.data.data) {
                                        t.next = 10;
                                        break;
                                    }
                                    return t.next = 8, e.getPrivacy();

                                  case 8:
                                    t.next = 11;
                                    break;

                                  case 10:
                                    e.getHomeDialog();

                                  case 11:
                                  case "end":
                                    return t.stop();
                                }
                            }, t);
                        }))();
                    },
                    getPrivacy: function() {
                        var e = this;
                        return g(n.default.mark(function t() {
                            var a;
                            return n.default.wrap(function(t) {
                                for (;;) switch (t.prev = t.next) {
                                  case 0:
                                    return t.next = 2, (0, i.getPrivacy)();

                                  case 2:
                                    a = t.sent, console.log("未同意的条款", a), "00000" == a.data.code && (e.clauses = a.data.data || [], 
                                    e.isOpenPrivacy = e.clauses.length > 0, 0 === e.clauses.length && e.getHomeDialog());

                                  case 5:
                                  case "end":
                                    return t.stop();
                                }
                            }, t);
                        }))();
                    },
                    getHomeDialog: function() {
                        var e = this;
                        return g(n.default.mark(function t() {
                            var a;
                            return n.default.wrap(function(t) {
                                for (;;) switch (t.prev = t.next) {
                                  case 0:
                                    if (!e.ambassadorVisible || !getApp().globalData.haCodeId || e.lastAmbassador) {
                                        t.next = 4;
                                        break;
                                    }
                                    return e.lastAmbassador = !0, e._jump({
                                        jumpType: 1,
                                        appId: l.APPID,
                                        guideUrl: "/pages/ambassador/apply",
                                        articleId: ""
                                    }), t.abrupt("return");

                                  case 4:
                                    if (!e.isFirstShowDialog) {
                                        t.next = 6;
                                        break;
                                    }
                                    return t.abrupt("return");

                                  case 6:
                                    return t.next = 8, (0, i.getDialog)();

                                  case 8:
                                    "00000" == (a = t.sent).data.code && (e.dialogInfo = a.data.data.homepagePopupInfoResponse, 
                                    e.popup = a.data.data.popup, e.isOpenPrivacy || (e.dialogVisible = e.popup, e.isFirstShowDialog = e.popup));

                                  case 10:
                                  case "end":
                                    return t.stop();
                                }
                            }, t);
                        }))();
                    },
                    handleDialogTo: function() {
                        this._jump(this.dialogInfo), this.dialogVisible = !1;
                    },
                    _jump: function(t) {
                        var a = t.jumpType, n = t.appId, o = t.guideUrl, r = t.articleId;
                        if (0 === a) e.navigateTo({
                            url: "/pages/webview/index?url=" + encodeURIComponent(o)
                        }); else if (1 === a) if (n === l.APPID) {
                            if ("/pages/crmActivity/index" === o) return void this.gotoPagePower(o);
                            [ "/pages/index/index", "/pages/gift/gift", "/pages/team/team" ].includes(o) ? e.switchTab({
                                url: o
                            }) : e.navigateTo({
                                url: o
                            });
                        } else wx.navigateToMiniProgram({
                            appId: n,
                            path: o,
                            envVersion: "release",
                            success: function(e) {
                                console.log("跳转小程序成功");
                            }
                        }); else 2 === a && e.navigateTo({
                            url: "/pages/team_detail/team_detail?id=" + r
                        });
                    },
                    jumpMiniApp: function() {
                        e.navigateToMiniProgram({
                            appId: "wxef8d617b01946908",
                            path: this.awaitJumpPath || "packages/goods/detail/index?alias=369bd5e85ew3gq3&shopAutoEnter=1",
                            extraData: {},
                            success: function(e) {
                                console.log("打开成功", e);
                            }
                        });
                    },
                    getMedalList: function() {
                        var e = this;
                        (0, u.medalIndex)().then(function(t) {
                            var a = t.data;
                            e.medals = a.data || [];
                        }), (0, u.medalUnreceiveCount)().then(function(t) {
                            var a = t.data;
                            e.medalCount = a.data || 0;
                        });
                    },
                    getActivityAllListNoLogin: function() {
                        var e = this;
                        return g(n.default.mark(function t() {
                            var a;
                            return n.default.wrap(function(t) {
                                for (;;) switch (t.prev = t.next) {
                                  case 0:
                                    return t.next = 2, (0, i.getActivityAllList)();

                                  case 2:
                                    a = t.sent, console.log("活动结果", a), e.list = [], "00000" == a.data.code && a.data.data.forEach(function(t) {
                                        var a = v(v({}, t), {}, {
                                            image: t.activityPictureUrl
                                        });
                                        e.list.push(a);
                                    });

                                  case 6:
                                  case "end":
                                    return t.stop();
                                }
                            }, t);
                        }))();
                    },
                    getActivityAllList: function() {
                        var e = this;
                        return g(n.default.mark(function t() {
                            var a;
                            return n.default.wrap(function(t) {
                                for (;;) switch (t.prev = t.next) {
                                  case 0:
                                    return t.next = 2, (0, i.activityList)();

                                  case 2:
                                    a = t.sent, console.log("活动结果", a), e.list = [], "00000" == a.data.code && a.data.data.forEach(function(t) {
                                        var a = v(v({}, t), {}, {
                                            image: t.activityPictureUrl
                                        });
                                        e.list.push(a);
                                    });

                                  case 6:
                                  case "end":
                                    return t.stop();
                                }
                            }, t);
                        }))();
                    },
                    openSharePaper: function() {
                        var t = this;
                        return g(n.default.mark(function a() {
                            var r, i, s, c;
                            return n.default.wrap(function(a) {
                                for (;;) switch (a.prev = a.next) {
                                  case 0:
                                    console.log(o.default.globalData.isIphoneX, "是否为苹果"), t.isIphone = o.default.globalData.isIphoneX, 
                                    r = "";
                                    try {
                                        (i = (i = e.getStorageSync("loginData2")) ? JSON.parse(i) : {}).phone && (r = i.phone);
                                    } catch (e) {}
                                    return s = {
                                        memberPhone: r,
                                        schoolId: ""
                                    }, e.showLoading(), a.next = 8, sharePoster(s);

                                  case 8:
                                    c = a.sent, e.hideLoading(), "00000" == c.data.code ? (t.$set(t, "codeUrl", c.data.data.codeUrl), 
                                    t.$set(t, "backGroundUrl", c.data.data.backGroundUrl), t.showPost = !0) : e.hideLoading(), 
                                    console.log("海报信息", c, t.codeUrl);

                                  case 12:
                                  case "end":
                                    return a.stop();
                                }
                            }, a);
                        }))();
                    },
                    checkShareStatus: function() {
                        var t = this;
                        return g(n.default.mark(function a() {
                            var o, r, s;
                            return n.default.wrap(function(a) {
                                for (;;) switch (a.prev = a.next) {
                                  case 0:
                                    if (console.log(1111), a.prev = 1, !(o = (o = e.getStorageSync("loginData2")) ? JSON.parse(o) : {}).phone) {
                                        a.next = 12;
                                        break;
                                    }
                                    return r = {
                                        memberPhone: o.phone
                                    }, a.next = 8, (0, i.shareStatus)(r);

                                  case 8:
                                    s = a.sent, e.hideLoading(), console.log("海报功能是否开启", s), "00000" == s.data.code && (t.isShareStatus = s.data.data);

                                  case 12:
                                    a.next = 16;
                                    break;

                                  case 14:
                                    a.prev = 14, a.t0 = a.catch(1);

                                  case 16:
                                  case "end":
                                    return a.stop();
                                }
                            }, a, null, [ [ 1, 14 ] ]);
                        }))();
                    },
                    checkPoint: function() {
                        var e = this;
                        return g(n.default.mark(function t() {
                            var a;
                            return n.default.wrap(function(t) {
                                for (;;) switch (t.prev = t.next) {
                                  case 0:
                                    return t.next = 2, (0, i.getMemberPoint)();

                                  case 2:
                                    a = t.sent, console.log("查积分结果", a), "00000" == a.data.code && (e.point = a.data.data);

                                  case 5:
                                  case "end":
                                    return t.stop();
                                }
                            }, t);
                        }))();
                    },
                    memberLevel: function() {
                        var e = this;
                        return g(n.default.mark(function t() {
                            var a;
                            return n.default.wrap(function(t) {
                                for (;;) switch (t.prev = t.next) {
                                  case 0:
                                    return t.next = 2, (0, i.getMemberLevel)();

                                  case 2:
                                    a = t.sent, console.log("等级查询", a), "00000" == a.data.code && (e.levelCode = a.data.data.code, 
                                    e.levelName = a.data.data.levelName, e.nextCode = a.data.data.nextCode, e.nextLevelName = a.data.data.nextLevelName, 
                                    e.growthValue = a.data.data.growthValue, e.bindingList = a.data.data.bindingList, 
                                    e.nextLevelGrowthValue = a.data.data.nextLevelGrowthValue);

                                  case 5:
                                  case "end":
                                    return t.stop();
                                }
                            }, t);
                        }))();
                    },
                    getSelfCoupon: function() {
                        var e = this;
                        return g(n.default.mark(function t() {
                            var a;
                            return n.default.wrap(function(t) {
                                for (;;) switch (t.prev = t.next) {
                                  case 0:
                                    return t.next = 2, (0, c.couponCount)();

                                  case 2:
                                    "00000" == (a = t.sent).data.code && (e.couponLen = a.data.data || "-");

                                  case 4:
                                  case "end":
                                    return t.stop();
                                }
                            }, t);
                        }))();
                    },
                    resetTime: function(e) {
                        return (0, r.default)(e).format("YYYY-MM-DD");
                    },
                    showToast: function(e, t) {
                        this.$refs.uToast.show({
                            title: e,
                            type: t
                        });
                    },
                    gotoTab: function(t) {
                        e.switchTab({
                            url: t
                        });
                    },
                    gotoPagePower: function(e) {
                        this.loginData.token ? wx.navigateTo({
                            url: e
                        }) : this.toLogin();
                    },
                    gotoPage: function(e, t) {
                        console.log("页面跳转"), wx.navigateTo({
                            url: e,
                            success: function(e) {
                                e.eventChannel.emit("acceptDataFromOpenerPage", {
                                    data: t
                                });
                            }
                        });
                    },
                    beforeSwitch: function(e) {
                        console.log("index", e), 0 == e && e != this.current && wx.redirectTo({
                            url: "/pages/index/index"
                        }), 1 == e && e != this.current && wx.redirectTo({
                            url: "/pages/gift/gift"
                        }), 2 == e && (console.log("出现二维码"), this.show = !0), 3 == e && e != this.current && wx.redirectTo({
                            url: "/pages/team/team"
                        }), 4 == e && e != this.current && wx.redirectTo({
                            url: "/pages/mall/mall"
                        }), this.current = e;
                    },
                    checkboxChange: function(e) {
                        console.log("协议勾选", e), this.checkboxGwList = e.detail.value;
                    }
                }, (0, d.mapActions)("user", {
                    getRedPoint: "getRedPoint"
                }))
            };
            t.default = b;
        }).call(this, a("543d").default);
    },
    e4a4: function(e, t, a) {
        (function(e) {
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = void 0;
            var n = a("7b12");
            function o(e, t) {
                return function(e) {
                    if (Array.isArray(e)) return e;
                }(e) || function(e, t) {
                    var a = null == e ? null : "undefined" != typeof Symbol && e[Symbol.iterator] || e["@@iterator"];
                    if (null != a) {
                        var n, o, r = [], i = !0, s = !1;
                        try {
                            for (a = a.call(e); !(i = (n = a.next()).done) && (r.push(n.value), !t || r.length !== t); i = !0) ;
                        } catch (e) {
                            s = !0, o = e;
                        } finally {
                            try {
                                i || null == a.return || a.return();
                            } finally {
                                if (s) throw o;
                            }
                        }
                        return r;
                    }
                }(e, t) || function(e, t) {
                    if (e) {
                        if ("string" == typeof e) return r(e, t);
                        var a = Object.prototype.toString.call(e).slice(8, -1);
                        return "Object" === a && e.constructor && (a = e.constructor.name), "Map" === a || "Set" === a ? Array.from(e) : "Arguments" === a || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(a) ? r(e, t) : void 0;
                    }
                }(e, t) || function() {
                    throw new TypeError("Invalid attempt to destructure non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.");
                }();
            }
            function r(e, t) {
                (null == t || t > e.length) && (t = e.length);
                for (var a = 0, n = new Array(t); a < t; a++) n[a] = e[a];
                return n;
            }
            var i = {
                globalData: {
                    isIphoneX: !1,
                    aspectRatio: 1,
                    windowWidth: 1,
                    windowHeight: 1,
                    statusBarHeight: 0,
                    scene: void 0,
                    path: void 0,
                    haCodeId: void 0,
                    hsCodeId: void 0,
                    isBack: !1,
                    kfToken: void 0,
                    kfExpireDate: 0
                },
                onLaunch: function(t) {
                    console.log("App Launch", t);
                    var a = e.getSystemInfoSync();
                    if (this.globalData.aspectRatio = a.windowWidth / a.windowHeight, this.globalData.windowWidth = a.windowWidth, 
                    this.globalData.windowHeight = a.windowHeight, this.globalData.statusBarHeight = a.statusBarHeight, 
                    console.log(a, "getSystemInfoSync"), -1 != a.model.indexOf("iPhone X") || -1 != a.model.indexOf("iPhone 11") || -1 != a.model.indexOf("iPhone 12") || -1 != a.model.indexOf("iPhone 13") || -1 != a.model.indexOf("iPhone 8") ? this.globalData.isIphoneX = !0 : this.globalData.isIphoneX = !1, 
                    console.log(this.globalData.isIphoneX, "isIphoneX"), wx.getUpdateManager) {
                        var n = wx.getUpdateManager();
                        n.onUpdateReady(function() {
                            wx.showModal({
                                title: "更新提示",
                                content: "新版本已经准备好，是否重启应用？",
                                success: function(e) {
                                    e.confirm && n.applyUpdate();
                                },
                                fail: function(e) {
                                    console.warn(e);
                                }
                            });
                        });
                    }
                },
                onShow: function(t) {
                    if (console.log("App Show", t), this.globalData.path = t.path, this.globalData.scene = t.query.scene, 
                    t.query.hasOwnProperty("codeId") && (this.globalData.scene = "T=MP&codeId=".concat(t.query.codeId)), 
                    this.globalData.isBack = "1" === t.query.back, t.query.scene) {
                        var a = decodeURIComponent(t.query.scene);
                        (a = this.stringToObject(a)).hasOwnProperty("B") && (this.globalData.isBack = "1" === a.B), 
                        a.hasOwnProperty("T") && ("HA" === a.T ? (this.globalData.haCodeId = a.ID, this.globalData.isBack = !0) : "HS" === a.T && (this.globalData.hsCodeId = a.ID, 
                        this.globalData.isBack = !0));
                    }
                    var o = e.getStorageSync("loginData2");
                    (o ? JSON.parse(o) : {}).token && (0, n.refreshEnter)();
                },
                onHide: function() {
                    console.log("App Hide");
                },
                methods: {
                    stringToObject: function(e) {
                        return e.split("&").reduce(function(e, t) {
                            var a = o(t.split("="), 2), n = a[0], r = a[1];
                            return e[n] = r, e;
                        }, {});
                    }
                }
            };
            t.default = i;
        }).call(this, a("543d").default);
    },
    f75a: function(e, t, a) {
        a.r(t);
        var n = a("c0e8"), o = a("8069");
        for (var r in o) [ "default" ].indexOf(r) < 0 && function(e) {
            a.d(t, e, function() {
                return o[e];
            });
        }(r);
        a("a629");
        var i = a("f0c5"), s = Object(i.a)(o.default, n.b, n.c, !1, null, "4adc2856", null, !1, n.a, void 0);
        t.default = s.exports;
    }
}, [ [ "d537", "common/runtime", "common/vendor" ] ] ]);