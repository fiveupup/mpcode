(global.webpackJsonp = global.webpackJsonp || []).push([ [ "pages/call_recode/call_recode" ], {
    "5fa8": function(t, n, e) {
        e.r(n);
        var o = e("bd94"), a = e.n(o);
        for (var u in o) [ "default" ].indexOf(u) < 0 && function(t) {
            e.d(n, t, function() {
                return o[t];
            });
        }(u);
        n.default = a.a;
    },
    "683f": function(t, n, e) {},
    7564: function(t, n, e) {
        var o = e("683f");
        e.n(o).a;
    },
    8992: function(t, n, e) {
        e.r(n);
        var o = e("996c"), a = e("5fa8");
        for (var u in a) [ "default" ].indexOf(u) < 0 && function(t) {
            e.d(n, t, function() {
                return a[t];
            });
        }(u);
        e("7564");
        var r = e("f0c5"), c = Object(r.a)(a.default, o.b, o.c, !1, null, "e2335286", null, !1, o.a, void 0);
        n.default = c.exports;
    },
    "996c": function(t, n, e) {
        e.d(n, "b", function() {
            return a;
        }), e.d(n, "c", function() {
            return u;
        }), e.d(n, "a", function() {
            return o;
        });
        var o = {
            uLoadmore: function() {
                return e.e("node-modules/uview-ui/components/u-loadmore/u-loadmore").then(e.bind(null, "bf89"));
            },
            uEmpty: function() {
                return e.e("node-modules/uview-ui/components/u-empty/u-empty").then(e.bind(null, "ab47"));
            }
        }, a = function() {
            var t = this;
            t.$createElement;
            t._self._c, t._isMounted || (t.e0 = function(n) {
                t.showPost = !0;
            }, t.e1 = function(n) {
                t.showPost = !1;
            });
        }, u = [];
    },
    bd94: function(t, n, e) {
        Object.defineProperty(n, "__esModule", {
            value: !0
        }), n.default = void 0;
        var o = function(t) {
            return t && t.__esModule ? t : {
                default: t
            };
        }(e("4795")), a = e("7b12");
        function u(t, n, e, o, a, u, r) {
            try {
                var c = t[u](r), i = c.value;
            } catch (t) {
                return void e(t);
            }
            c.done ? n(i) : Promise.resolve(i).then(o, a);
        }
        var r = {
            components: {
                InvitePoster: function() {
                    e.e("components/poster/invite").then(function() {
                        return resolve(e("4e80"));
                    }.bind(null, e)).catch(e.oe);
                }
            },
            data: function() {
                return {
                    avatar: "https://pepsicocampuscrmstgblob.blob.core.chinacloudapi.cn/pepsicocampuscrmstgblob/FAQ_202305061357534454.png",
                    list: [],
                    pageNum: 0,
                    pageSize: 10,
                    total: 0,
                    loadText: {
                        loadmore: "点击或上拉加载更多",
                        loading: "努力加载中",
                        nomore: "没有更多了"
                    },
                    loadStatus: "loadmore",
                    showPost: !1
                };
            },
            onReachBottom: function() {
                "nomore" !== this.loadStatus && (this.loadStatus = "loading", this.loadData());
            },
            onShow: function() {
                this.loadData();
            },
            methods: {
                loadData: function() {
                    var t = this;
                    return function(t) {
                        return function() {
                            var n = this, e = arguments;
                            return new Promise(function(o, a) {
                                var r = t.apply(n, e);
                                function c(t) {
                                    u(r, o, a, c, i, "next", t);
                                }
                                function i(t) {
                                    u(r, o, a, c, i, "throw", t);
                                }
                                c(void 0);
                            });
                        };
                    }(o.default.mark(function n() {
                        var e, u;
                        return o.default.wrap(function(n) {
                            for (;;) switch (n.prev = n.next) {
                              case 0:
                                return t.pageNum += 1, n.next = 3, (0, a.listForWeb)({
                                    pageNum: t.pageNum,
                                    pageSize: t.pageSize
                                });

                              case 3:
                                e = n.sent, "00000" === (u = e.data).code && (u.data.list.length > 0 ? (t.list = t.list.concat(u.data.list), 
                                t.total = u.data.total, t.list.length >= t.total && (t.loadStatus = "nomore")) : t.loadStatus = "nomore");

                              case 6:
                              case "end":
                                return n.stop();
                            }
                        }, n);
                    }))();
                }
            }
        };
        n.default = r;
    },
    d3cf: function(t, n, e) {
        (function(t) {
            e("6cdc"), o(e("66fd"));
            var n = o(e("8992"));
            function o(t) {
                return t && t.__esModule ? t : {
                    default: t
                };
            }
            wx.__webpack_require_UNI_MP_PLUGIN__ = e, t(n.default);
        }).call(this, e("543d").createPage);
    }
}, [ [ "d3cf", "common/runtime", "common/vendor" ] ] ]);