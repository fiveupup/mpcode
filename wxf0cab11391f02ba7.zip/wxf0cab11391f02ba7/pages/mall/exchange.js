require("../../@babel/runtime/helpers/Arrayincludes"), (global.webpackJsonp = global.webpackJsonp || []).push([ [ "pages/mall/exchange" ], {
    "36bf": function(t, e, n) {
        (function(t) {
            Object.defineProperty(e, "__esModule", {
                value: !0
            }), e.default = void 0;
            var a = function(t) {
                return t && t.__esModule ? t : {
                    default: t
                };
            }(n("4795")), o = n("d1f8");
            function r(t, e) {
                return function(t) {
                    if (Array.isArray(t)) return t;
                }(t) || function(t, e) {
                    var n = null == t ? null : "undefined" != typeof Symbol && t[Symbol.iterator] || t["@@iterator"];
                    if (null != n) {
                        var a, o, r = [], i = !0, u = !1;
                        try {
                            for (n = n.call(t); !(i = (a = n.next()).done) && (r.push(a.value), !e || r.length !== e); i = !0) ;
                        } catch (t) {
                            u = !0, o = t;
                        } finally {
                            try {
                                i || null == n.return || n.return();
                            } finally {
                                if (u) throw o;
                            }
                        }
                        return r;
                    }
                }(t, e) || function(t, e) {
                    if (t) {
                        if ("string" == typeof t) return i(t, e);
                        var n = Object.prototype.toString.call(t).slice(8, -1);
                        return "Object" === n && t.constructor && (n = t.constructor.name), "Map" === n || "Set" === n ? Array.from(t) : "Arguments" === n || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n) ? i(t, e) : void 0;
                    }
                }(t, e) || function() {
                    throw new TypeError("Invalid attempt to destructure non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.");
                }();
            }
            function i(t, e) {
                (null == e || e > t.length) && (e = t.length);
                for (var n = 0, a = new Array(e); n < e; n++) a[n] = t[n];
                return a;
            }
            function u(t, e, n, a, o, r, i) {
                try {
                    var u = t[r](i), l = u.value;
                } catch (t) {
                    return void n(t);
                }
                u.done ? e(l) : Promise.resolve(l).then(a, o);
            }
            var l = {
                data: function() {
                    return {
                        loading: !0,
                        pageConfig: {
                            topBg: "",
                            pageBg: "",
                            infoBg: "",
                            productBg: "",
                            defaultUnLight: "",
                            defaultLight: "",
                            progressUnLight: "",
                            progressLight: "",
                            defaultIconSize: 0,
                            progressIconSize: 0,
                            infoStarColor: "",
                            expiresColor: "",
                            ruleRecordBgColor: "",
                            ruleRecordCharColor: "",
                            tabDefaultColor: "",
                            tabSelectColor: "",
                            exchangeBtnBgColor: "",
                            exchangeBtnCharColor: "",
                            goodsNameColor: "",
                            inventoryAccumulateColor: ""
                        },
                        exchangeInfo: {
                            cumulativeQuantity: 0,
                            availableQuantity: 0,
                            usedQuantity: 0,
                            cleanTime: null
                        },
                        progressData: [],
                        currentType: 0,
                        tablist: [ {
                            name: "全部商品"
                        }, {
                            name: "可兑换商品"
                        } ],
                        loadText: {
                            loadmore: "点击或上拉加载更多",
                            loading: "努力加载中",
                            nomore: "没有更多了"
                        },
                        loadStatus: "loadmore",
                        tabParams: {
                            pageSize: 10,
                            pageNum: 0,
                            sort: 0,
                            isShow: "YES",
                            goodsStatus: "ON",
                            status: "ENABLE"
                        },
                        list: [],
                        listTemp: [],
                        listAll: [],
                        loginData: {}
                    };
                },
                onShow: function() {
                    var e = t.getStorageSync("loginData2");
                    this.loginData = e ? JSON.parse(e) : {}, this.loadPageConfigData(), this.getList();
                },
                methods: {
                    toAgreement: function(e) {
                        t.navigateTo({
                            url: "/pages/agreement/agreement?ruleType=" + e
                        });
                    },
                    loadPageConfigData: function() {
                        var t = this;
                        return function(t) {
                            return function() {
                                var e = this, n = arguments;
                                return new Promise(function(a, o) {
                                    var r = t.apply(e, n);
                                    function i(t) {
                                        u(r, a, o, i, l, "next", t);
                                    }
                                    function l(t) {
                                        u(r, a, o, i, l, "throw", t);
                                    }
                                    i(void 0);
                                });
                            };
                        }(a.default.mark(function e() {
                            var n, i, u, l, s, c, f, d, g, h, m;
                            return a.default.wrap(function(e) {
                                for (;;) switch (e.prev = e.next) {
                                  case 0:
                                    return e.next = 2, (0, o.getPageConfig)();

                                  case 2:
                                    n = e.sent, (i = n.data).data && i.data.topBg && (t.pageConfig = i.data, u = i.data, 
                                    l = u.starCoordinateList, s = u.starProgressList, c = u.defaultIconSize, f = u.progressIconSize, 
                                    d = u.defaultUnLight, g = u.defaultLight, h = u.progressUnLight, m = u.progressLight, 
                                    (0, o.getMemberPoint)().then(function(e) {
                                        var n = e.data;
                                        t.exchangeInfo = n.data;
                                        var a = n.data.availableQuantity;
                                        t.progressData = l.map(function(t, e) {
                                            var n = r(t.split(","), 2), o = n[0], i = n[1], u = s.includes(String(e + 1)), l = a >= e + 1;
                                            return {
                                                left: "".concat(o, "rpx"),
                                                top: "".concat(i, "rpx"),
                                                width: "".concat(u ? f : c, "rpx"),
                                                height: "".concat(u ? f : c, "rpx"),
                                                icon: u ? l ? m : h : l ? g : d
                                            };
                                        });
                                    }));

                                  case 5:
                                  case "end":
                                    return e.stop();
                                }
                            }, e);
                        }))();
                    },
                    getList: function() {
                        var t = this;
                        console.log(this.tabParams, "加载更多!"), this.tabParams.pageNum++, this.loadStatus = "loading", 
                        (0, o.getGoodsList)().then(function(e) {
                            var n = e.data;
                            n.data.length > 0 ? (t.list = n.data, t.listAll = JSON.parse(JSON.stringify(n.data)), 
                            t.loadStatus = "nomore") : t.loadStatus = "nomore";
                        });
                    },
                    gotoPage: function(t, e, n) {
                        if (console.log("页面跳转"), e) {
                            if (n.goodsQuantity <= 0) return void this.$refs.uToast.show({
                                title: "当前商品无库存，无法兑换！"
                            });
                            if (console.log(n.exchangeValue, this.exchangeInfo.availableQuantity), n.exchangeValue > this.exchangeInfo.availableQuantity) return void this.$refs.uToast.show({
                                title: "您暂时无法兑换该商品"
                            });
                        }
                        wx.navigateTo({
                            url: t,
                            success: function(t) {
                                t.eventChannel.emit("acceptDataFromOpenerPage", {
                                    data: "test"
                                });
                            }
                        });
                    },
                    handleSort: function() {
                        0 === this.tabParams.sort ? (this.tabParams.sort = 2, this.listTemp = JSON.parse(JSON.stringify(this.list)), 
                        this.list = this.list.sort(function(t, e) {
                            return e.exchangeValue - t.exchangeValue;
                        })) : 1 === this.tabParams.sort ? (this.tabParams.sort = 0, this.list = this.listTemp.map(function(t) {
                            return t;
                        })) : 2 === this.tabParams.sort && (this.tabParams.sort = 1, this.list = this.list.sort(function(t, e) {
                            return t.exchangeValue - e.exchangeValue;
                        }));
                    },
                    change: function(t) {
                        var e = this;
                        this.currentType = t, this.list = 0 == t ? this.listAll.map(function(t) {
                            return t;
                        }) : this.listAll.filter(function(t) {
                            return t.goodsQuantity > 0 && t.exchangeValue <= e.exchangeInfo.availableQuantity;
                        });
                    }
                }
            };
            e.default = l;
        }).call(this, n("543d").default);
    },
    "36e7": function(t, e, n) {
        (function(t) {
            n("6cdc"), a(n("66fd"));
            var e = a(n("f64f"));
            function a(t) {
                return t && t.__esModule ? t : {
                    default: t
                };
            }
            wx.__webpack_require_UNI_MP_PLUGIN__ = n, t(e.default);
        }).call(this, n("543d").createPage);
    },
    4693: function(t, e, n) {
        n.r(e);
        var a = n("36bf"), o = n.n(a);
        for (var r in a) [ "default" ].indexOf(r) < 0 && function(t) {
            n.d(e, t, function() {
                return a[t];
            });
        }(r);
        e.default = o.a;
    },
    8073: function(t, e, n) {},
    d8a6: function(t, e, n) {
        var a = n("8073");
        n.n(a).a;
    },
    ea9c: function(t, e, n) {
        n.d(e, "b", function() {
            return o;
        }), n.d(e, "c", function() {
            return r;
        }), n.d(e, "a", function() {
            return a;
        });
        var a = {
            uIcon: function() {
                return n.e("node-modules/uview-ui/components/u-icon/u-icon").then(n.bind(null, "2925"));
            },
            uTabs: function() {
                return Promise.all([ n.e("common/vendor"), n.e("node-modules/uview-ui/components/u-tabs/u-tabs") ]).then(n.bind(null, "7418"));
            },
            uLoadmore: function() {
                return n.e("node-modules/uview-ui/components/u-loadmore/u-loadmore").then(n.bind(null, "bf89"));
            },
            uToast: function() {
                return n.e("node-modules/uview-ui/components/u-toast/u-toast").then(n.bind(null, "446f"));
            }
        }, o = function() {
            var t = this, e = (t.$createElement, t._self._c, t.__map(t.list, function(e, n) {
                return {
                    $orig: t.__get_orig(e),
                    g0: e.goodsImg.split(",")
                };
            }));
            t._isMounted || (t.e0 = function(e) {
                t.loading = !1;
            }, t.e1 = function(e, n) {
                var a = arguments[arguments.length - 1].currentTarget.dataset, o = a.eventParams || a["event-params"];
                return n = o.item, e.stopPropagation(), t.gotoPage("/pages/confirmDetail/confirmDetail?id=" + n.id + "&limitBuy=" + n.limitBuy + "&type=exchange", !0, n);
            }), t.$mp.data = Object.assign({}, {
                $root: {
                    l0: e
                }
            });
        }, r = [];
    },
    f64f: function(t, e, n) {
        n.r(e);
        var a = n("ea9c"), o = n("4693");
        for (var r in o) [ "default" ].indexOf(r) < 0 && function(t) {
            n.d(e, t, function() {
                return o[t];
            });
        }(r);
        n("d8a6");
        var i = n("f0c5"), u = Object(i.a)(o.default, a.b, a.c, !1, null, "31355afe", null, !1, a.a, void 0);
        e.default = u.exports;
    }
}, [ [ "36e7", "common/runtime", "common/vendor" ] ] ]);