require("../../@babel/runtime/helpers/Arrayincludes"), (global.webpackJsonp = global.webpackJsonp || []).push([ [ "pages/mall/mall" ], {
    "090d": function(t, e, a) {
        var n = a("f906");
        a.n(n).a;
    },
    "738d": function(t, e, a) {
        (function(t) {
            a("6cdc"), n(a("66fd"));
            var e = n(a("bd12"));
            function n(t) {
                return t && t.__esModule ? t : {
                    default: t
                };
            }
            wx.__webpack_require_UNI_MP_PLUGIN__ = a, t(e.default);
        }).call(this, a("543d").createPage);
    },
    9536: function(t, e, a) {
        (function(t) {
            Object.defineProperty(e, "__esModule", {
                value: !0
            }), e.default = void 0;
            var n = function(t) {
                return t && t.__esModule ? t : {
                    default: t
                };
            }(a("4795")), o = a("830d"), i = a("403a");
            function r(t, e, a, n, o, i, r) {
                try {
                    var u = t[i](r), s = u.value;
                } catch (t) {
                    return void a(t);
                }
                u.done ? e(s) : Promise.resolve(s).then(n, o);
            }
            var u = {
                components: {
                    tabbar: function() {
                        Promise.all([ a.e("common/vendor"), a.e("components/tabbar") ]).then(function() {
                            return resolve(a("26fc"));
                        }.bind(null, a)).catch(a.oe);
                    }
                },
                data: function() {
                    return {
                        pageConfig: {
                            pageBg: "",
                            infoBg: "",
                            productBg: "",
                            priceBg: "",
                            productLogo: "",
                            infoLogo: "",
                            infoColor: "",
                            productColor: "",
                            productLineColor: "",
                            tabDefaultColor: "",
                            tabSelectColor: ""
                        },
                        show: !1,
                        banners: [],
                        current: 0,
                        currentType: 0,
                        integral_point: 0,
                        tablist: [ {
                            name: "全部"
                        }, {
                            name: "薯片"
                        }, {
                            name: "饮料"
                        } ],
                        loadText: {
                            loadmore: "点击或上拉加载更多",
                            loading: "努力加载中",
                            nomore: "没有更多了"
                        },
                        loadStatus: "loadmore",
                        tabParams: {
                            pageSize: 10,
                            pageNum: 0,
                            goodsCategoryId: "",
                            isShow: "YES",
                            goodsStatus: "ON",
                            status: "ENABLE"
                        },
                        list: [],
                        loginData: {}
                    };
                },
                onReachBottom: function() {
                    "nomore" != this.loadStatus && this.getList();
                },
                computed: {
                    listHeight: function() {
                        return this.list.length > 2 ? 228 + 396 * (this.list.length % 2 > 0 ? this.list.length + 1 : this.list.length) / 2 : 578.8;
                    }
                },
                onShow: function() {
                    var e = this, a = t.getStorageSync("loginData2");
                    this.loginData = a ? JSON.parse(a) : {}, wx.hideHomeButton(), wx.hideHomeButton(), 
                    this.current = 4, this.loadPageConfigData(), (0, o.getMemberPoint)().then(function(t) {
                        e.integral_point = t.data.data;
                    }), this.getBanner(), (0, o.getGoodsCategory)().then(function(t) {
                        var a = t.data.data;
                        null != a && a.length && (e.tablist = a.map(function(t) {
                            return {
                                name: t.categoryName,
                                id: t.id
                            };
                        }), e.tablist.unshift({
                            name: "全部"
                        }), delete e.tabParams.goodsName), e.getList();
                    });
                },
                methods: {
                    toAgreement: function(e) {
                        t.navigateTo({
                            url: "/pages/agreement/agreement?ruleType=" + e
                        });
                    },
                    jumpTo: function(e) {
                        var a = e.jumpType, n = e.appId, o = e.guideUrl, i = e.articleId;
                        0 === a ? t.navigateTo({
                            url: "/pages/webview/index?url=" + encodeURIComponent(o)
                        }) : this._jump({
                            jumpType: a,
                            appId: n,
                            guideUrl: o,
                            articleId: i
                        });
                    },
                    _jump: function(e) {
                        var a = e.jumpType, n = e.appId, o = e.guideUrl, r = e.articleId;
                        1 === a ? n === i.APPID ? [ "/pages/index/index", "/pages/gift/gift", "/pages/team/team" ].includes(o) ? t.switchTab({
                            url: o
                        }) : t.navigateTo({
                            url: o
                        }) : wx.navigateToMiniProgram({
                            appId: n,
                            path: o,
                            envVersion: "release",
                            success: function(t) {
                                console.log("跳转小程序成功");
                            }
                        }) : 2 === a && t.navigateTo({
                            url: "/pages/team_detail/team_detail?id=" + r
                        });
                    },
                    loadPageConfigData: function() {
                        var t = this;
                        return function(t) {
                            return function() {
                                var e = this, a = arguments;
                                return new Promise(function(n, o) {
                                    var i = t.apply(e, a);
                                    function u(t) {
                                        r(i, n, o, u, s, "next", t);
                                    }
                                    function s(t) {
                                        r(i, n, o, u, s, "throw", t);
                                    }
                                    u(void 0);
                                });
                            };
                        }(n.default.mark(function e() {
                            var a, i;
                            return n.default.wrap(function(e) {
                                for (;;) switch (e.prev = e.next) {
                                  case 0:
                                    return e.next = 2, (0, o.getPageConfig)();

                                  case 2:
                                    a = e.sent, (i = a.data).data && i.data.pageBg && (t.pageConfig = i.data);

                                  case 5:
                                  case "end":
                                    return e.stop();
                                }
                            }, e);
                        }))();
                    },
                    getBanner: function() {
                        var t = this;
                        (0, o.getMallBanner)().then(function(e) {
                            t.banners = e.data.data;
                        });
                    },
                    getList: function() {
                        var t = this;
                        console.log(this.tabParams, "加载更多!"), this.tabParams.pageNum++, this.loadStatus = "loading", 
                        (0, o.getGoodsList)(this.tabParams).then(function(e) {
                            e.data.data.list.length > 0 ? (e.data.data.list.length < t.tabParams.pageSize && (t.loadStatus = "nomore"), 
                            t.list = t.list.concat(e.data.data.list)) : t.loadStatus = "nomore";
                        });
                    },
                    gotoPage: function(t, e, a) {
                        if (console.log("页面跳转"), e) {
                            if (a.goodsQuantity <= 0) return void this.$refs.uToast.show({
                                title: "当前商品无库存，无法兑换！"
                            });
                            if (0 === a.canExchangeGoods) return void this.$refs.uToast.show({
                                title: "您暂时无法兑换该商品"
                            });
                        }
                        wx.navigateTo({
                            url: t,
                            success: function(t) {
                                t.eventChannel.emit("acceptDataFromOpenerPage", {
                                    data: "test"
                                });
                            }
                        });
                    },
                    change: function(t) {
                        this.loadStatus = "loadmore", this.currentType = t, 0 == t ? delete this.tabParams.goodsCategoryId : this.tabParams.goodsCategoryId = this.tablist[t].id, 
                        this.tabParams.pageNum = 0, this.list = [], this.getList();
                    }
                }
            };
            e.default = u;
        }).call(this, a("543d").default);
    },
    "9da8": function(t, e, a) {
        a.d(e, "b", function() {
            return o;
        }), a.d(e, "c", function() {
            return i;
        }), a.d(e, "a", function() {
            return n;
        });
        var n = {
            uTabs: function() {
                return Promise.all([ a.e("common/vendor"), a.e("node-modules/uview-ui/components/u-tabs/u-tabs") ]).then(a.bind(null, "7418"));
            },
            uLoadmore: function() {
                return a.e("node-modules/uview-ui/components/u-loadmore/u-loadmore").then(a.bind(null, "bf89"));
            },
            uToast: function() {
                return a.e("node-modules/uview-ui/components/u-toast/u-toast").then(a.bind(null, "446f"));
            }
        }, o = function() {
            var t = this, e = (t.$createElement, t._self._c, t.__map(t.list, function(e, a) {
                return {
                    $orig: t.__get_orig(e),
                    g0: e.goodsImg.split(",")
                };
            }));
            t._isMounted || (t.e0 = function(e, a) {
                var n = arguments[arguments.length - 1].currentTarget.dataset, o = n.eventParams || n["event-params"];
                return a = o.item, e.stopPropagation(), t.gotoPage("/pages/confirmDetail/confirmDetail?id=" + a.id + "&limitBuy=" + a.limitBuy + "&type=point", !0, a);
            }), t.$mp.data = Object.assign({}, {
                $root: {
                    l0: e
                }
            });
        }, i = [];
    },
    bd12: function(t, e, a) {
        a.r(e);
        var n = a("9da8"), o = a("c86e");
        for (var i in o) [ "default" ].indexOf(i) < 0 && function(t) {
            a.d(e, t, function() {
                return o[t];
            });
        }(i);
        a("090d");
        var r = a("f0c5"), u = Object(r.a)(o.default, n.b, n.c, !1, null, "f02ca07e", null, !1, n.a, void 0);
        e.default = u.exports;
    },
    c86e: function(t, e, a) {
        a.r(e);
        var n = a("9536"), o = a.n(n);
        for (var i in n) [ "default" ].indexOf(i) < 0 && function(t) {
            a.d(e, t, function() {
                return n[t];
            });
        }(i);
        e.default = o.a;
    },
    f906: function(t, e, a) {}
}, [ [ "738d", "common/runtime", "common/vendor" ] ] ]);