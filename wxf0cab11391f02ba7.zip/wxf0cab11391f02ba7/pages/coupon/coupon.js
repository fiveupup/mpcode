(global.webpackJsonp = global.webpackJsonp || []).push([ [ "pages/coupon/coupon" ], {
    "2f06": function(t, e, n) {
        n.r(e);
        var a = n("eeda"), o = n("a61e");
        for (var i in o) [ "default" ].indexOf(i) < 0 && function(t) {
            n.d(e, t, function() {
                return o[t];
            });
        }(i);
        n("449b");
        var r = n("f0c5"), u = Object(r.a)(o.default, a.b, a.c, !1, null, "b6c1f8fc", null, !1, a.a, void 0);
        e.default = u.exports;
    },
    "449b": function(t, e, n) {
        var a = n("7735");
        n.n(a).a;
    },
    "60d3": function(t, e, n) {
        (function(t) {
            n("6cdc"), a(n("66fd"));
            var e = a(n("2f06"));
            function a(t) {
                return t && t.__esModule ? t : {
                    default: t
                };
            }
            wx.__webpack_require_UNI_MP_PLUGIN__ = n, t(e.default);
        }).call(this, n("543d").createPage);
    },
    7735: function(t, e, n) {},
    a61e: function(t, e, n) {
        n.r(e);
        var a = n("d3ec"), o = n.n(a);
        for (var i in a) [ "default" ].indexOf(i) < 0 && function(t) {
            n.d(e, t, function() {
                return a[t];
            });
        }(i);
        e.default = o.a;
    },
    d3ec: function(t, e, n) {
        (function(t) {
            Object.defineProperty(e, "__esModule", {
                value: !0
            }), e.default = void 0;
            var a = u(n("4795")), o = u(n("05b9")), i = n("7b12"), r = n("40a4");
            function u(t) {
                return t && t.__esModule ? t : {
                    default: t
                };
            }
            function c(t, e) {
                var n = Object.keys(t);
                if (Object.getOwnPropertySymbols) {
                    var a = Object.getOwnPropertySymbols(t);
                    e && (a = a.filter(function(e) {
                        return Object.getOwnPropertyDescriptor(t, e).enumerable;
                    })), n.push.apply(n, a);
                }
                return n;
            }
            function s(t) {
                for (var e = 1; e < arguments.length; e++) {
                    var n = null != arguments[e] ? arguments[e] : {};
                    e % 2 ? c(Object(n), !0).forEach(function(e) {
                        d(t, e, n[e]);
                    }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(t, Object.getOwnPropertyDescriptors(n)) : c(Object(n)).forEach(function(e) {
                        Object.defineProperty(t, e, Object.getOwnPropertyDescriptor(n, e));
                    });
                }
                return t;
            }
            function d(t, e, n) {
                return e in t ? Object.defineProperty(t, e, {
                    value: n,
                    enumerable: !0,
                    configurable: !0,
                    writable: !0
                }) : t[e] = n, t;
            }
            function l(t, e, n, a, o, i, r) {
                try {
                    var u = t[i](r), c = u.value;
                } catch (t) {
                    return void n(t);
                }
                u.done ? e(c) : Promise.resolve(c).then(a, o);
            }
            function f(t) {
                return function() {
                    var e = this, n = arguments;
                    return new Promise(function(a, o) {
                        var i = t.apply(e, n);
                        function r(t) {
                            l(i, a, o, r, u, "next", t);
                        }
                        function u(t) {
                            l(i, a, o, r, u, "throw", t);
                        }
                        r(void 0);
                    });
                };
            }
            var p = {
                data: function() {
                    return {
                        tabs: [ "平台券", "心动商城券" ],
                        channelOptions: [],
                        firstIn: !0,
                        tabActiveIndex: -1,
                        activeIndex: 0,
                        loadText: {
                            loadmore: "点击或上拉加载更多",
                            loading: "努力加载中",
                            nomore: "没有更多了"
                        },
                        loadStatus: "loadmore",
                        dataList: [],
                        param: {
                            pageNum: 1,
                            pageSize: 10
                        },
                        show: !1,
                        qrSrc: ""
                    };
                },
                watch: {
                    tabActiveIndex: {
                        handler: function(t) {
                            this.param.pageNum = 1, this.dataList.length = 0, -1 !== t && (1 === t ? this.getYouzanList() : this.getList());
                        },
                        immediate: !0
                    },
                    activeIndex: {
                        handler: function(t) {
                            0 === this.tabActiveIndex && (this.dataList.length = 0, this.param.pageNum = 1, 
                            this.firstIn || this.getList(), this.firstIn = !1);
                        },
                        immediate: !0
                    }
                },
                onLoad: function(t) {
                    console.log("options", t), t.index ? this.tabActiveIndex = Number(t.index) : this.tabActiveIndex = 0;
                },
                onShow: function() {
                    this.getChannelOptions();
                },
                onReachBottom: function() {
                    console.log("触底"), this.loadMore();
                },
                methods: {
                    selectTabs: function(t) {
                        this.tabActiveIndex = t;
                    },
                    selectTab: function(t) {
                        this.activeIndex = t;
                    },
                    getChannelOptions: function() {
                        var t = this;
                        return f(a.default.mark(function e() {
                            var n, o, i, u;
                            return a.default.wrap(function(e) {
                                for (;;) switch (e.prev = e.next) {
                                  case 0:
                                    return e.next = 2, (0, r.channelList)();

                                  case 2:
                                    o = e.sent, i = o.data, (u = null === (n = i.data) || void 0 === n ? void 0 : n.filter(function(t) {
                                        return "YOU_ZAN" !== t.channelNo;
                                    })).unshift({
                                        channelName: "全部",
                                        channelNo: ""
                                    }), t.channelOptions = u;

                                  case 7:
                                  case "end":
                                    return e.stop();
                                }
                            }, e);
                        }))();
                    },
                    loadMore: function() {
                        "nomore" !== this.loadStatus && (this.param.pageNum++, 0 === this.tabActiveIndex ? this.getList() : this.getYouzanList());
                    },
                    getList: function() {
                        var t = this;
                        return f(a.default.mark(function e() {
                            var n, o, i;
                            return a.default.wrap(function(e) {
                                for (;;) switch (e.prev = e.next) {
                                  case 0:
                                    return t.loadStatus = "loading", n = t.channelOptions[t.activeIndex], e.next = 4, 
                                    (0, r.couponListOfPlatform)(s(s({}, t.param), {}, {
                                        allFlag: 0 === t.activeIndex ? 1 : 0,
                                        channelNo: (null == n ? void 0 : n.channelNo) || ""
                                    }));

                                  case 4:
                                    o = e.sent, "00000" == (i = o.data).code ? (t.dataList = t.dataList.concat(i.data.list), 
                                    t.dataList.length >= i.data.total && (t.loadStatus = "nomore")) : t.loadStatus = "nomore";

                                  case 7:
                                  case "end":
                                    return e.stop();
                                }
                            }, e);
                        }))();
                    },
                    getYouzanList: function() {
                        var t = this;
                        return f(a.default.mark(function e() {
                            var n, o;
                            return a.default.wrap(function(e) {
                                for (;;) switch (e.prev = e.next) {
                                  case 0:
                                    return t.loadStatus = "loading", e.next = 3, (0, r.couponListOfYouzanPage)(s({}, t.param));

                                  case 3:
                                    n = e.sent, "00000" == (o = n.data).code ? (t.dataList = t.dataList.concat(o.data.list), 
                                    t.dataList.length >= o.data.total && (t.loadStatus = "nomore")) : t.loadStatus = "nomore";

                                  case 6:
                                  case "end":
                                    return e.stop();
                                }
                            }, e);
                        }))();
                    },
                    useCoupon: function(e) {
                        var n = this;
                        return f(a.default.mark(function o() {
                            var r;
                            return a.default.wrap(function(a) {
                                for (;;) switch (a.prev = a.next) {
                                  case 0:
                                    if (e = JSON.parse(e), console.log(e), 1 != e.usedMode) {
                                        a.next = 12;
                                        break;
                                    }
                                    return n.show = !0, t.showLoading(), a.next = 7, (0, i.getQRCode)({
                                        usedEndpoint: e.usedEndpoint
                                    });

                                  case 7:
                                    r = a.sent, t.hideLoading(), "00000" == r.data.code ? n.qrSrc = r.data.data : (t.showToast({
                                        title: r.data.message,
                                        icon: "none"
                                    }), t.hideLoading()), a.next = 13;
                                    break;

                                  case 12:
                                    2 == e.usedMode && t.showModal({
                                        content: "即将打开小程序",
                                        confirmColor: "#37eea8",
                                        success: function(n) {
                                            n.confirm ? t.navigateToMiniProgram({
                                                appId: "wxef8d617b01946908",
                                                path: e.usedEndpoint || "pages/common/blank-page/index?weappSharePath=pages%2Fhome%2Ffeature%2Findex%3Falias%3Dk31dSF06iP%26kdt_id%3D90706668",
                                                extraData: {
                                                    data1: "test"
                                                },
                                                success: function(t) {}
                                            }) : n.cancel;
                                        }
                                    });

                                  case 13:
                                  case "end":
                                    return a.stop();
                                }
                            }, o);
                        }))();
                    },
                    useYouzanCoupon: function(e) {
                        t.navigateToMiniProgram({
                            appId: "wxef8d617b01946908",
                            path: e.usedEndpoint || "/packages/user/coupon/list/index?type=promocard&title=我的优惠券",
                            extraData: {
                                data1: "test"
                            },
                            success: function(t) {}
                        });
                    },
                    resetTime: function(t) {
                        return (0, o.default)(t).format("YYYY.MM.DD HH:mm:ss");
                    },
                    gotoPage: function(e) {
                        console.log("页面跳转", e), t.navigateTo({
                            url: e
                        });
                    },
                    gotoTab: function(e) {
                        t.switchTab({
                            url: e
                        });
                    }
                }
            };
            e.default = p;
        }).call(this, n("543d").default);
    },
    eeda: function(t, e, n) {
        n.d(e, "b", function() {
            return o;
        }), n.d(e, "c", function() {
            return i;
        }), n.d(e, "a", function() {
            return a;
        });
        var a = {
            uTabs: function() {
                return Promise.all([ n.e("common/vendor"), n.e("node-modules/uview-ui/components/u-tabs/u-tabs") ]).then(n.bind(null, "7418"));
            },
            uIcon: function() {
                return n.e("node-modules/uview-ui/components/u-icon/u-icon").then(n.bind(null, "2925"));
            },
            uLoadmore: function() {
                return n.e("node-modules/uview-ui/components/u-loadmore/u-loadmore").then(n.bind(null, "bf89"));
            },
            uPopup: function() {
                return n.e("node-modules/uview-ui/components/u-popup/u-popup").then(n.bind(null, "97cd"));
            }
        }, o = function() {
            var t = this, e = (t.$createElement, t._self._c, t.__map(t.dataList, function(e, n) {
                return {
                    $orig: t.__get_orig(e),
                    g0: JSON.stringify(e),
                    m0: e.validEndTime ? t.resetTime(e.validEndTime) : null
                };
            }));
            t.$mp.data = Object.assign({}, {
                $root: {
                    l0: e
                }
            });
        }, i = [];
    }
}, [ [ "60d3", "common/runtime", "common/vendor" ] ] ]);