(global.webpackJsonp = global.webpackJsonp || []).push([ [ "pages/coupon/activity" ], {
    "42b3": function(n, t, e) {
        e.r(t);
        var o = e("5e64"), a = e.n(o);
        for (var i in o) [ "default" ].indexOf(i) < 0 && function(n) {
            e.d(t, n, function() {
                return o[n];
            });
        }(i);
        t.default = a.a;
    },
    "45c0": function(n, t, e) {},
    "5d56": function(n, t, e) {
        e.r(t);
        var o = e("cd4a"), a = e("42b3");
        for (var i in a) [ "default" ].indexOf(i) < 0 && function(n) {
            e.d(t, n, function() {
                return a[n];
            });
        }(i);
        e("6850");
        var c = e("f0c5"), r = Object(c.a)(a.default, o.b, o.c, !1, null, "350a3a33", null, !1, o.a, void 0);
        t.default = r.exports;
    },
    "5e64": function(n, t, e) {
        (function(n) {
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = void 0;
            var o = c(e("4795")), a = c(e("05b9")), i = e("40a4");
            function c(n) {
                return n && n.__esModule ? n : {
                    default: n
                };
            }
            function r(n, t, e, o, a, i, c) {
                try {
                    var r = n[i](c), u = r.value;
                } catch (n) {
                    return void e(n);
                }
                r.done ? t(u) : Promise.resolve(u).then(o, a);
            }
            function u(n) {
                return function() {
                    var t = this, e = arguments;
                    return new Promise(function(o, a) {
                        var i = n.apply(t, e);
                        function c(n) {
                            r(i, o, a, c, u, "next", n);
                        }
                        function u(n) {
                            r(i, o, a, c, u, "throw", n);
                        }
                        c(void 0);
                    });
                };
            }
            var f = {
                data: function() {
                    return {
                        activityId: "",
                        activityInfo: {},
                        ruleDescription: ""
                    };
                },
                onLoad: function(t) {
                    if (t.scene) {
                        var e = decodeURIComponent(t.scene);
                        this.activityId = e ? e.split("=")[1] : "", console.log("scene: ", t.scene, this.activityId), 
                        this.loadData();
                    } else n.showToast({
                        title: "二维码无效",
                        icon: "none"
                    });
                },
                onPullDownRefresh: function() {
                    var t = this;
                    return u(o.default.mark(function e() {
                        return o.default.wrap(function(e) {
                            for (;;) switch (e.prev = e.next) {
                              case 0:
                                return e.next = 2, t.loadData();

                              case 2:
                                n.stopPullDownRefresh();

                              case 3:
                              case "end":
                                return e.stop();
                            }
                        }, e);
                    }))();
                },
                methods: {
                    loadData: function() {
                        var t = this;
                        return u(o.default.mark(function e() {
                            var a, c;
                            return o.default.wrap(function(e) {
                                for (;;) switch (e.prev = e.next) {
                                  case 0:
                                    return e.next = 2, (0, i.couponActivity)(t.activityId);

                                  case 2:
                                    if (a = e.sent, "00000" != (c = a.data).code) {
                                        e.next = 11;
                                        break;
                                    }
                                    if (n.setNavigationBarTitle({
                                        title: c.data.activityName
                                    }), 1 !== c.data.expire) {
                                        e.next = 9;
                                        break;
                                    }
                                    return n.showModal({
                                        content: "活动已过期，请移步领券中心。",
                                        confirmText: "确认",
                                        confirmColor: "#37eea8",
                                        showCancel: !1,
                                        success: function(t) {
                                            t.confirm && n.switchTab({
                                                url: "/pages/gift/gift"
                                            });
                                        }
                                    }), e.abrupt("return");

                                  case 9:
                                    t.activityInfo = c.data, t.ruleDescription = c.data.activityRule;

                                  case 11:
                                  case "end":
                                    return e.stop();
                                }
                            }, e);
                        }))();
                    },
                    getCoupon: function(t) {
                        var e = this;
                        return u(o.default.mark(function a() {
                            var c, r, u;
                            return o.default.wrap(function(o) {
                                for (;;) switch (o.prev = o.next) {
                                  case 0:
                                    if (2 !== e.activityInfo.expire) {
                                        o.next = 5;
                                        break;
                                    }
                                    return n.showModal({
                                        content: "活动将于 ".concat(e.activityInfo.startTime, " 开始，请耐心等候。"),
                                        confirmText: "确认",
                                        confirmColor: "#37eea8",
                                        showCancel: !1
                                    }), o.abrupt("return");

                                  case 5:
                                    if (3 !== e.activityInfo.expire) {
                                        o.next = 8;
                                        break;
                                    }
                                    return n.showModal({
                                        content: "抱歉，您不是受邀用户，无法参与该活动。",
                                        confirmText: "确认",
                                        confirmColor: "#37eea8",
                                        showCancel: !1
                                    }), o.abrupt("return");

                                  case 8:
                                    return n.showLoading({
                                        title: "领取中..."
                                    }), c = t.channelRelation.channelNo, o.next = 12, (0, i.takeCoupon)({
                                        activityId: e.activityId,
                                        channelDetail: e.activityInfo.activityName,
                                        channelNo: c,
                                        couponNo: t.couponNo,
                                        takeChannel: 2
                                    });

                                  case 12:
                                    r = o.sent, u = r.data, n.hideLoading(), "00000" == u.code ? n.showModal({
                                        content: "领取成功",
                                        confirmText: "去查看",
                                        confirmColor: "#37eea8",
                                        success: function(n) {
                                            n.confirm && e.gotoPage("/pages/coupon/coupon?index=".concat("YOU_ZAN" === c ? 1 : 0));
                                        }
                                    }) : n.showToast({
                                        title: u.message,
                                        icon: "none"
                                    });

                                  case 16:
                                  case "end":
                                    return o.stop();
                                }
                            }, a);
                        }))();
                    },
                    resetTime: function(n) {
                        return (0, a.default)(n).format("YYYY.MM.DD HH:mm:ss");
                    },
                    gotoPage: function(t) {
                        console.log("页面跳转", t), n.navigateTo({
                            url: t
                        });
                    }
                }
            };
            t.default = f;
        }).call(this, e("543d").default);
    },
    6850: function(n, t, e) {
        var o = e("45c0");
        e.n(o).a;
    },
    a81d: function(n, t, e) {
        (function(n) {
            e("6cdc"), o(e("66fd"));
            var t = o(e("5d56"));
            function o(n) {
                return n && n.__esModule ? n : {
                    default: n
                };
            }
            wx.__webpack_require_UNI_MP_PLUGIN__ = e, n(t.default);
        }).call(this, e("543d").createPage);
    },
    cd4a: function(n, t, e) {
        e.d(t, "b", function() {
            return a;
        }), e.d(t, "c", function() {
            return i;
        }), e.d(t, "a", function() {
            return o;
        });
        var o = {
            uImage: function() {
                return e.e("node-modules/uview-ui/components/u-image/u-image").then(e.bind(null, "f977"));
            },
            uIcon: function() {
                return e.e("node-modules/uview-ui/components/u-icon/u-icon").then(e.bind(null, "2925"));
            }
        }, a = function() {
            var n = this, t = (n.$createElement, n._self._c, n.__map(n.activityInfo.couponList, function(t, e) {
                return {
                    $orig: n.__get_orig(t),
                    m0: t.validEndTime ? n.resetTime(t.validEndTime) : null
                };
            }));
            n.$mp.data = Object.assign({}, {
                $root: {
                    l0: t
                }
            });
        }, i = [];
    }
}, [ [ "a81d", "common/runtime", "common/vendor" ] ] ]);