(global.webpackJsonp = global.webpackJsonp || []).push([ [ "pages/mallDetail/exchange" ], {
    "082e": function(e, t, n) {
        n.r(t);
        var o = n("a98a"), i = n.n(o);
        for (var a in o) [ "default" ].indexOf(a) < 0 && function(e) {
            n.d(t, e, function() {
                return o[e];
            });
        }(a);
        t.default = i.a;
    },
    "32d5": function(e, t, n) {
        var o = n("7e4f");
        n.n(o).a;
    },
    3730: function(e, t, n) {
        (function(e) {
            n("6cdc"), o(n("66fd"));
            var t = o(n("cce9"));
            function o(e) {
                return e && e.__esModule ? e : {
                    default: e
                };
            }
            wx.__webpack_require_UNI_MP_PLUGIN__ = n, e(t.default);
        }).call(this, n("543d").createPage);
    },
    "63e9": function(e, t, n) {
        n.d(t, "b", function() {
            return i;
        }), n.d(t, "c", function() {
            return a;
        }), n.d(t, "a", function() {
            return o;
        });
        var o = {
            uSwiper: function() {
                return n.e("node-modules/uview-ui/components/u-swiper/u-swiper").then(n.bind(null, "b332"));
            },
            uParse: function() {
                return Promise.all([ n.e("common/vendor"), n.e("node-modules/uview-ui/components/u-parse/u-parse") ]).then(n.bind(null, "492b"));
            },
            uToast: function() {
                return n.e("node-modules/uview-ui/components/u-toast/u-toast").then(n.bind(null, "446f"));
            }
        }, i = function() {
            this.$createElement;
            this._self._c;
        }, a = [];
    },
    "7e4f": function(e, t, n) {},
    a98a: function(e, t, n) {
        Object.defineProperty(t, "__esModule", {
            value: !0
        }), t.default = void 0;
        var o = n("d1f8"), i = {
            data: function() {
                return {
                    id: "",
                    detail: {},
                    style: {
                        ".ql-align-right": "text-align: right;",
                        ".ql-align-center": "text-align: center;"
                    },
                    isExchange: !0,
                    rule: "兑换后不可取消"
                };
            },
            onLoad: function(e) {
                this.id = e.id;
            },
            onShow: function() {
                this.loadData();
            },
            methods: {
                loadData: function() {
                    var e = this;
                    (0, o.getGoodDetail)({
                        id: this.id
                    }).then(function(t) {
                        var n;
                        console.log(t), e.detail = t.data.data, e.detail.goodsDetail = null === (n = e.detail.goodsDetail) || void 0 === n ? void 0 : n.replace(/\<img/gi, '<img style="width:100%;height:auto"'), 
                        e.detail.goodsQuantity <= 0 && (e.isExchange = !1), e.detail.goodsImg = e.detail.goodsImg ? e.detail.goodsImg.split(",") : [];
                    });
                },
                gotoPage: function(e, t) {
                    t && this.detail.goodsQuantity <= 0 ? this.$refs.uToast.show({
                        title: "当前商品无库存，无法兑换！"
                    }) : (console.log("页面跳转"), wx.navigateTo({
                        url: e,
                        success: function(e) {
                            e.eventChannel.emit("acceptDataFromOpenerPage", {
                                data: "test"
                            });
                        }
                    }));
                }
            }
        };
        t.default = i;
    },
    cce9: function(e, t, n) {
        n.r(t);
        var o = n("63e9"), i = n("082e");
        for (var a in i) [ "default" ].indexOf(a) < 0 && function(e) {
            n.d(t, e, function() {
                return i[e];
            });
        }(a);
        n("32d5");
        var u = n("f0c5"), d = Object(u.a)(i.default, o.b, o.c, !1, null, "6d6d0366", null, !1, o.a, void 0);
        t.default = d.exports;
    }
}, [ [ "3730", "common/runtime", "common/vendor" ] ] ]);