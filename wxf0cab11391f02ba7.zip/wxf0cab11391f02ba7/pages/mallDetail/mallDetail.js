(global.webpackJsonp = global.webpackJsonp || []).push([ [ "pages/mallDetail/mallDetail" ], {
    "4c5b": function(t, e, n) {
        (function(t) {
            n("6cdc"), i(n("66fd"));
            var e = i(n("7850"));
            function i(t) {
                return t && t.__esModule ? t : {
                    default: t
                };
            }
            wx.__webpack_require_UNI_MP_PLUGIN__ = n, t(e.default);
        }).call(this, n("543d").createPage);
    },
    "4d1f": function(t, e, n) {
        n.r(e);
        var i = n("7cec"), o = n.n(i);
        for (var a in i) [ "default" ].indexOf(a) < 0 && function(t) {
            n.d(e, t, function() {
                return i[t];
            });
        }(a);
        e.default = o.a;
    },
    "74f6": function(t, e, n) {
        n.d(e, "b", function() {
            return o;
        }), n.d(e, "c", function() {
            return a;
        }), n.d(e, "a", function() {
            return i;
        });
        var i = {
            uSwiper: function() {
                return n.e("node-modules/uview-ui/components/u-swiper/u-swiper").then(n.bind(null, "b332"));
            },
            uParse: function() {
                return Promise.all([ n.e("common/vendor"), n.e("node-modules/uview-ui/components/u-parse/u-parse") ]).then(n.bind(null, "492b"));
            },
            uToast: function() {
                return n.e("node-modules/uview-ui/components/u-toast/u-toast").then(n.bind(null, "446f"));
            }
        }, o = function() {
            this.$createElement;
            this._self._c;
        }, a = [];
    },
    7850: function(t, e, n) {
        n.r(e);
        var i = n("74f6"), o = n("4d1f");
        for (var a in o) [ "default" ].indexOf(a) < 0 && function(t) {
            n.d(e, t, function() {
                return o[t];
            });
        }(a);
        n("9898");
        var u = n("f0c5"), d = Object(u.a)(o.default, i.b, i.c, !1, null, "48d7e37c", null, !1, i.a, void 0);
        e.default = d.exports;
    },
    "7cec": function(t, e, n) {
        Object.defineProperty(e, "__esModule", {
            value: !0
        }), e.default = void 0;
        var i = n("830d"), o = {
            data: function() {
                return {
                    id: "",
                    detail: {},
                    style: {
                        ".ql-align-right": "text-align: right;",
                        ".ql-align-center": "text-align: center;"
                    },
                    isExchange: !0,
                    rule: "兑换后不可取消"
                };
            },
            onLoad: function(t) {
                this.id = t.id;
            },
            onShow: function() {
                this.loadData();
            },
            methods: {
                loadData: function() {
                    var t = this;
                    (0, i.getGoodDetail)({
                        id: this.id
                    }).then(function(e) {
                        var n;
                        console.log(e), t.detail = e.data.data, t.detail.goodsDetail = null === (n = t.detail.goodsDetail) || void 0 === n ? void 0 : n.replace(/\<img/gi, '<img style="width:100%;height:auto"'), 
                        (t.detail.goodsQuantity <= 0 || 0 === t.detail.canExchangeGoods) && (t.isExchange = !1), 
                        t.detail.goodsImg = t.detail.goodsImg ? t.detail.goodsImg.split(",") : [];
                    });
                },
                gotoPage: function(t, e) {
                    if (e) {
                        if (this.detail.goodsQuantity <= 0) return void this.$refs.uToast.show({
                            title: "当前商品无库存，无法兑换！"
                        });
                        if (0 === this.detail.canExchangeGoods) return void this.$refs.uToast.show({
                            title: "您暂时无法兑换该商品"
                        });
                    }
                    console.log("页面跳转"), wx.navigateTo({
                        url: t,
                        success: function(t) {
                            t.eventChannel.emit("acceptDataFromOpenerPage", {
                                data: "test"
                            });
                        }
                    });
                }
            }
        };
        e.default = o;
    },
    9898: function(t, e, n) {
        var i = n("c9db");
        n.n(i).a;
    },
    c9db: function(t, e, n) {}
}, [ [ "4c5b", "common/runtime", "common/vendor" ] ] ]);