(global.webpackJsonp = global.webpackJsonp || []).push([ [ "common/main" ], {
    "034f": function(e, t, n) {
        var o = n("368d");
        n.n(o).a;
    },
    "23be": function(e, t, n) {
        n.r(t);
        var o = n("e4a4"), a = n.n(o);
        for (var r in o) [ "default" ].indexOf(r) < 0 && function(e) {
            n.d(t, e, function() {
                return o[e];
            });
        }(r);
        t.default = a.a;
    },
    "368d": function(e, t, n) {},
    "3dfd": function(e, t, n) {
        n.r(t);
        var o = n("23be");
        for (var a in o) [ "default" ].indexOf(a) < 0 && function(e) {
            n.d(t, e, function() {
                return o[e];
            });
        }(a);
        n("034f");
        var r = n("f0c5"), i = Object(r.a)(o.default, void 0, void 0, !1, null, null, null, !1, void 0, void 0);
        t.default = i.exports;
    },
    "56d7": function(e, t, n) {
        (function(e) {
            n("6cdc");
            var t = i(n("3dfd")), o = i(n("66fd")), a = i(n("2fb1")), r = i(n("4360"));
            function i(e) {
                return e && e.__esModule ? e : {
                    default: e
                };
            }
            function l(e, t) {
                var n = Object.keys(e);
                if (Object.getOwnPropertySymbols) {
                    var o = Object.getOwnPropertySymbols(e);
                    t && (o = o.filter(function(t) {
                        return Object.getOwnPropertyDescriptor(e, t).enumerable;
                    })), n.push.apply(n, o);
                }
                return n;
            }
            function c(e) {
                for (var t = 1; t < arguments.length; t++) {
                    var n = null != arguments[t] ? arguments[t] : {};
                    t % 2 ? l(Object(n), !0).forEach(function(t) {
                        u(e, t, n[t]);
                    }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(n)) : l(Object(n)).forEach(function(t) {
                        Object.defineProperty(e, t, Object.getOwnPropertyDescriptor(n, t));
                    });
                }
                return e;
            }
            function u(e, t, n) {
                return t in e ? Object.defineProperty(e, t, {
                    value: n,
                    enumerable: !0,
                    configurable: !0,
                    writable: !0
                }) : e[t] = n, e;
            }
            wx.__webpack_require_UNI_MP_PLUGIN__ = n, o.default.use(a.default);
            o.default.component("LaysPage", function() {
                Promise.all([ n.e("common/vendor"), n.e("components/lays-page") ]).then(function() {
                    return resolve(n("6310"));
                }.bind(null, n)).catch(n.oe);
            }), o.default.component("LaysPageMain", function() {
                n.e("components/lays-page-main").then(function() {
                    return resolve(n("59d9"));
                }.bind(null, n)).catch(n.oe);
            }), o.default.config.productionTip = !1, t.default.mpType = "app", e(new o.default(c(c({}, t.default), {}, {
                store: r.default
            }))).$mount();
        }).call(this, n("543d").createApp);
    },
    e4a4: function(e, t, n) {
        (function(e) {
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = void 0;
            var o = n("7b12");
            function a(e, t) {
                return function(e) {
                    if (Array.isArray(e)) return e;
                }(e) || function(e, t) {
                    var n = null == e ? null : "undefined" != typeof Symbol && e[Symbol.iterator] || e["@@iterator"];
                    if (null != n) {
                        var o, a, r = [], i = !0, l = !1;
                        try {
                            for (n = n.call(e); !(i = (o = n.next()).done) && (r.push(o.value), !t || r.length !== t); i = !0) ;
                        } catch (e) {
                            l = !0, a = e;
                        } finally {
                            try {
                                i || null == n.return || n.return();
                            } finally {
                                if (l) throw a;
                            }
                        }
                        return r;
                    }
                }(e, t) || function(e, t) {
                    if (e) {
                        if ("string" == typeof e) return r(e, t);
                        var n = Object.prototype.toString.call(e).slice(8, -1);
                        return "Object" === n && e.constructor && (n = e.constructor.name), "Map" === n || "Set" === n ? Array.from(e) : "Arguments" === n || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n) ? r(e, t) : void 0;
                    }
                }(e, t) || function() {
                    throw new TypeError("Invalid attempt to destructure non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.");
                }();
            }
            function r(e, t) {
                (null == t || t > e.length) && (t = e.length);
                for (var n = 0, o = new Array(t); n < t; n++) o[n] = e[n];
                return o;
            }
            var i = {
                globalData: {
                    isIphoneX: !1,
                    aspectRatio: 1,
                    windowWidth: 1,
                    windowHeight: 1,
                    statusBarHeight: 0,
                    scene: void 0,
                    path: void 0,
                    haCodeId: void 0,
                    hsCodeId: void 0,
                    isBack: !1,
                    kfToken: void 0,
                    kfExpireDate: 0
                },
                onLaunch: function(t) {
                    console.log("App Launch", t);
                    var n = e.getSystemInfoSync();
                    if (this.globalData.aspectRatio = n.windowWidth / n.windowHeight, this.globalData.windowWidth = n.windowWidth, 
                    this.globalData.windowHeight = n.windowHeight, this.globalData.statusBarHeight = n.statusBarHeight, 
                    console.log(n, "getSystemInfoSync"), -1 != n.model.indexOf("iPhone X") || -1 != n.model.indexOf("iPhone 11") || -1 != n.model.indexOf("iPhone 12") || -1 != n.model.indexOf("iPhone 13") || -1 != n.model.indexOf("iPhone 8") ? this.globalData.isIphoneX = !0 : this.globalData.isIphoneX = !1, 
                    console.log(this.globalData.isIphoneX, "isIphoneX"), wx.getUpdateManager) {
                        var o = wx.getUpdateManager();
                        o.onUpdateReady(function() {
                            wx.showModal({
                                title: "更新提示",
                                content: "新版本已经准备好，是否重启应用？",
                                success: function(e) {
                                    e.confirm && o.applyUpdate();
                                },
                                fail: function(e) {
                                    console.warn(e);
                                }
                            });
                        });
                    }
                },
                onShow: function(t) {
                    if (console.log("App Show", t), this.globalData.path = t.path, this.globalData.scene = t.query.scene, 
                    t.query.hasOwnProperty("codeId") && (this.globalData.scene = "T=MP&codeId=".concat(t.query.codeId)), 
                    this.globalData.isBack = "1" === t.query.back, t.query.scene) {
                        var n = decodeURIComponent(t.query.scene);
                        (n = this.stringToObject(n)).hasOwnProperty("B") && (this.globalData.isBack = "1" === n.B), 
                        n.hasOwnProperty("T") && ("HA" === n.T ? (this.globalData.haCodeId = n.ID, this.globalData.isBack = !0) : "HS" === n.T && (this.globalData.hsCodeId = n.ID, 
                        this.globalData.isBack = !0));
                    }
                    var a = e.getStorageSync("loginData2");
                    (a ? JSON.parse(a) : {}).token && (0, o.refreshEnter)();
                },
                onHide: function() {
                    console.log("App Hide");
                },
                methods: {
                    stringToObject: function(e) {
                        return e.split("&").reduce(function(e, t) {
                            var n = a(t.split("="), 2), o = n[0], r = n[1];
                            return e[o] = r, e;
                        }, {});
                    }
                }
            };
            t.default = i;
        }).call(this, n("543d").default);
    }
}, [ [ "56d7", "common/runtime", "common/vendor" ] ] ]);