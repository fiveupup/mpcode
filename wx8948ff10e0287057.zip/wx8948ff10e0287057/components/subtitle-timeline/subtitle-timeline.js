Component({
  properties: {
    lowValue: {
      type: Number,
      value: 0
    },
    highValue: {
      type: Number,
      value: 0
    },
    min: {
      type: Number,
      value: 0
    },
    max: {
      type: Number,
      value: 100
    },
    _minRange: {
      type: Number,
      value: 0
    },
    text: {
      type: String,
      value: ''
    }
  },

  /**
   * 组件的初始数据
   */
  data: {
    left: 0,
    width: 70,
    _minWidth: 0,
    _totalWidth: 0,
    _thumbStart: {
      x: 0,
      item: 'high'
    },
    _freezeLeft: 0,
    _freezeWidth: 0
  },

  lifetimes: {
    attached: function attached() {
      this.reset();
    }
  },

  observers: {
    'highValue, lowValue': function highValueLowValue(highValue, lowValue) {
      this.reset();
    }
  },

  /**
   * 组件的方法列表
   */
  methods: {
    thumbTouchStart: function thumbTouchStart(e) {
      this.setData({
        '_thumbStart.x': e.touches[0].clientX,
        '_thumbStart.item': e.currentTarget.dataset.thumb,
        _freezeLeft: this.data.left,
        _freezeWidth: this.data.width
      });
    },
    thumbTouchMove: function thumbTouchMove(e) {
      var distance = e.changedTouches[0].clientX - this.data._thumbStart.x;
      var newData = {};
      var eventDetail = {
        highValue: this.data.highValue,
        lowValue: this.data.lowValue
      };
      if (this.data._thumbStart.item == 'high') {
        // 右侧滑动条
        // 不能超过最大值left + width不能超过totalWidth
        // 至少保留最小minRange这么长的长度
        newData['width'] = Math.max(this.data._minWidth, Math.min(this.data._freezeWidth + distance, this.data._totalWidth - this.data.left));
        eventDetail.highValue = this.data.min + (this.data.left + newData.width) / this.data._totalWidth * (this.data.max - this.data.min);
        this.triggerEvent('slidehigh', eventDetail, {});
      } else {
        // 左侧滑动条
        // 不能小于0
        // 不能大于freezeWidth + freezeLeft
        newData['width'] = Math.min(this.data._freezeWidth + this.data._freezeLeft, Math.max(this.data._freezeWidth - distance, this.data._minWidth));
        newData['left'] = this.data._freezeWidth + this.data._freezeLeft - newData['width'];
        eventDetail.lowValue = this.data.min + newData.left / this.data._totalWidth * (this.data.max - this.data.min);
        this.triggerEvent('slidelow', eventDetail, {});
      }
      this.triggerEvent('slide', eventDetail, {});
      this.setData(newData);
    },
    thumbTouchEnd: function thumbTouchEnd(e) {
      this.triggerEvent('slidetouchend', e.detail, {});
    },
    reset: function reset() {
      var _this = this;

      var query = wx.createSelectorQuery().in(this);
      query.select('.slider').boundingClientRect();
      query.exec(function (res) {
        var minWidth = _this.data._minRange / (_this.data.max - _this.data.min) * res[0].width;
        _this.setData({
          _totalWidth: res[0].width,
          _minWidth: minWidth,
          width: Math.max(minWidth, (_this.data.highValue - _this.data.lowValue) / (_this.data.max - _this.data.min) * res[0].width),
          left: _this.data.lowValue / (_this.data.max - _this.data.min) * res[0].width
        });
      });
    }
  }
});