Component({
  /**
   * 组件的属性列表
   */
  properties: {},

  /**
   * 组件的初始数据
   */
  data: {
    show: false,
    visible: false,
    added: false
  },

  /**
   * 组件的方法列表
   */
  methods: {
    open: function open() {
      var _this = this;

      wx.vibrateShort({
        type: 'medium'
      });
      this.setData({
        visible: true
      }, function () {
        setTimeout(function () {
          _this.setData({
            show: true
          });
        }, 0);
      });
      wx.req.get('secret/', {}).then(function (r) {
        _this.setData({
          added: !!r.data.wxid
        });
      });
    },
    close: function close() {
      var _this2 = this;

      wx.vibrateShort({});
      this.setData({
        show: false
      }, function () {
        setTimeout(function () {
          _this2.setData({
            visible: false
          });
        }, 200);
      });
    },
    doneTap: function doneTap() {
      wx.vibrateShort({});
      if (this.data.added) {
        this.close();
        return;
      }
      wx.showLoading({
        title: '获取暗号中'
      });
      wx.req.get('secret/', {}).then(function (r) {
        wx.setClipboardData({
          data: r.data.secret
        });
        wx.hideLoading();
        wx.showModal({
          title: '暗号已复制',
          showCancel: false,
          content: '下一步，长按识别二维码，添加好友！',
          confirmText: '下一步',
          success: function success(res) {
            wx.previewImage({
              urls: ['https://img.newunderstand.com/qr/assistant-qr.jpeg']
            });
          }
        });
      }).catch(function (e) {
        wx.hideLoading();
        wx.showToast({
          title: '获取暗号失败',
          icon: 'none'
        });
      });
    }
  }
});