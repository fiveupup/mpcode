var _wxCountdown = require('../../utils/wxCountdown.js');var _wxCountdown2 = _interopRequireDefault(_wxCountdown);function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }var throttle = require('../../utils/throttle');var app = getApp();Component({
  /**
   * 组件的属性列表
   */
  properties: {},

  /**
   * 组件的初始数据
   */
  data: {
    name: '',
    tip: '',
    count: 0,
    prizes: [],
    users: [],
    countdown: {},
    myTicket: 0,
    spent: 0,
    trickyAd: '',
    loading: true,
    trickyShow: false,
    lid: '-'
  },

  lifetimes: {
    attached: function attached() {
      this.tricky = throttle.throttle(this._tricky.bind(this), 1000);
      this.noTicketModal = this.selectComponent('#no-ticket-modal');
      this.refresh();
    }
  },

  pageLifetimes: {
    show: function show() {
      this.refresh();
    }
  },

  /**
   * 组件的方法列表
   */
  methods: {
    refresh: function refresh() {
      var _this = this;

      app.globalData.loginInfo.then(function (r) {
        return wx.req.get('lottery/current/', {});
      }).then(function (r) {
        _wxCountdown2.default.init(r.data.end_time, 'countdown', _this);
        _this.setData({
          lid: r.data.id,
          users: r.data.joins.joins,
          count: r.data.joins.count,
          prizes: r.data.prizes,
          name: r.data.name,
          tip: r.data.tip,
          spent: r.data.spent,
          myTicket: r.data.my_ticket,
          loading: false
        });
      });
    },
    triggerJoin: function triggerJoin(e) {
      this.triggerEvent('join', e);
    },
    trickyReady: function trickyReady() {
      this.setData({
        trickyAd: app.globalData.ads.index_banner_tricky,
        trickyShow: true
      });
    },
    join: function join(e) {
      var _this2 = this;

      if (!this.data.myTicket) {
        this.noTicketModal.show({
          title: '没有奖券了'
        });
        this.trickyReady();
      } else {
        wx.showModal({
          title: '确认参与抽奖',
          content: '将消耗1张奖券，参与到本期抽奖中增加1份中奖概率。',
          confirmText: '确认',
          success: function success(res) {
            if (res.confirm) {
              wx.showLoading({
                title: '参与中',
                mask: true
              });
              wx.req.post('lottery/join/', {}).then(function (r) {
                wx.hideLoading({});
                _this2.triggerEvent('joinSucceeded');
                _this2.refresh();
              });
            }
          }
        });
      }
    },
    toMake: function toMake(e) {
      this.noTicketModal.close();
      wx.switchTab({
        url: '/pages/index/index'
      });
      wx.pageScrollTo({
        scrollTop: 0
      });
    },
    toPlanet: function toPlanet(e) {
      this.noTicketModal.close();
      wx.switchTab({
        url: '/pages/explore/explore'
      });
    },
    _tricky: function _tricky(e) {
      if (!this.data.trickyShow) {
        this.setData({
          trickyShow: true
        });
      } else {
        this.noTicketModal.close();
      }
    },
    onNoTicketModalClose: function onNoTicketModalClose(e) {
      this.setData({
        trickyAd: '',
        trickyShow: false
      });
    }
  }
});