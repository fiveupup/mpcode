Component({
  /**
   * 组件的属性列表
   */
  properties: {
    imgSrc: String,
    text: String
  },

  /**
   * 组件的初始数据
   */
  data: {
    show: false,
    icon: 'none'
  },

  observers: {
    // 'text': function(text) {
    //   this.setData({
    //     text: text
    //   })
    // }
  },
  /**
   * 组件的方法列表
   */
  methods: {
    catchEvent: function catchEvent(e) {
      return;
    },
    hide: function hide() {
      this.setData({
        show: false
      });
    },
    show: function show(_ref) {
      var _this = this;

      var _ref$text = _ref.text,
          text = _ref$text === undefined ? null : _ref$text,
          _ref$icon = _ref.icon,
          icon = _ref$icon === undefined ? 'none' : _ref$icon,
          _ref$duration = _ref.duration,
          duration = _ref$duration === undefined ? 500 : _ref$duration;

      var data = {
        show: true
      };
      if (text) {
        data.text = text;
      }
      console.log(data);
      this.setData(data);
      var to = setTimeout(function () {
        _this.setData({
          show: false
        });
      }, duration);
      if (!duration) {
        clearTimeout(to);
      }
    },
    setText: function setText(text) {
      this.setData({
        text: text
      });
    }
  }
});