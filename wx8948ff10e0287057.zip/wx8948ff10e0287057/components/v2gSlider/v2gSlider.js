Component({
  /**
   * 组件的属性列表
   */
  properties: {
    value: {
      type: Number,
      value: 0
    },
    min: {
      type: Number,
      value: 0
    },
    max: {
      type: Number,
      value: 100
    }
  },

  /**
   * 组件的初始数据
   */
  data: {
    width: 70,
    totalWidth: 0,
    thumbStart: {
      x: 0
    },
    freezeWidth: 0
  },

  lifetimes: {
    attached: function attached() {
      this.reset();
    }
  },

  observers: {
    'value': function value(_value) {
      this.reset();
    }
  },

  /**
   * 组件的方法列表
   */
  methods: {
    reset: function reset(e) {
      var _this = this;

      var query = wx.createSelectorQuery().in(this);
      query.select('.slider').boundingClientRect();
      query.exec(function (res) {
        _this.setData({
          totalWidth: res[0].width,
          width: Math.min(_this.data.totalWidth, (_this.data.value - _this.data.min) / (_this.data.max - _this.data.min) * _this.data.totalWidth)
        });
      });
    },
    thumbTouchStart: function thumbTouchStart(e) {
      this.setData({
        'thumbStart.x': e.touches[0].clientX,
        freezeWidth: this.data.width
      });
    },
    thumbTouchMove: function thumbTouchMove(e) {
      var distance = e.changedTouches[0].clientX - this.data.thumbStart.x;
      var newData = {};
      var eventDetail = {
        value: this.data.value
      };
      newData['width'] = Math.max(0, Math.min(this.data.freezeWidth + distance, this.data.totalWidth));
      eventDetail.value = this.data.min + newData.width / this.data.totalWidth * (this.data.max - this.data.min);
      this.triggerEvent('slide', eventDetail, {});
      this.setData(newData);
    },
    thumbTouchEnd: function thumbTouchEnd(e) {
      var eventDetail = {
        value: this.data.value
      };
      this.triggerEvent('slidetouchend', eventDetail, {});
    }
  }
});