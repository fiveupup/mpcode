Component({
  /**
   * 组件的属性列表
   */
  properties: {
    gid: {
      type: Number,
      default: 0
    }
  },

  /**
   * 组件的初始数据
   */
  data: {
    show: false,
    commentShow: false,
    comment: '',
    rate: '0'
  },

  /**
   * 组件的方法列表
   */
  methods: {
    toggle: function toggle(e) {
      this.setData({
        show: !this.data.show
      });
    },
    changeRate: function changeRate(e) {
      this.setData({
        rate: e.detail.value,
        commentShow: e.detail.value < 4
      });
    },
    inputComment: function inputComment(e) {
      this.setData({
        comment: e.detail.value
      });
    },
    save: function save(e) {
      var _this = this;

      if (this.data.rate > 0) {
        wx.req.post('rate/' + this.data.gid + '/', { data: { rate: this.data.rate, comment: this.data.comment } }).then(function (r) {
          _this.triggerEvent('save', { rate: _this.data.rate, comment: _this.data.comment }, {});
        });
        this.toggle(e);
      } else {
        wx.showToast({
          title: '请选择评分',
          icon: 'none'
        });
      }
    }
  }
});