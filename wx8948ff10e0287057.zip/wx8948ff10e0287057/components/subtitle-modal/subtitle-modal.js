Component({
  /**
   * 组件的属性列表
   */

  properties: {
    text: {
      type: String,
      value: ''
    },
    size: {
      type: Number,
      value: 20
    },
    index: {
      type: Number,
      value: -1
    }
  },

  /**
   * 组件的初始数据
   */
  data: {
    show: false,
    sizeChoices: [{
      value: 20,
      text: '小'
    }, {
      value: 30,
      text: '中'
    }, {
      value: 40,
      text: '大'
    }, {
      value: 50,
      text: '超大'
    }]
  },

  /**
   * 组件的方法列表
   */
  methods: {
    selectSize: function selectSize(e) {
      this.setData({
        size: e.detail.value
      });
    },
    toggle: function toggle(e) {
      this.setData({
        show: !this.data.show
      });
    },
    inputSubtitle: function inputSubtitle(e) {
      if (e.detail.value.length <= 10) {
        this.setData({
          text: e.detail.value
        });
        return e.detail.value;
      }
    },
    save: function save(e) {
      var eventDetail = {
        text: this.data.text,
        index: this.data.index,
        size: this.data.size
      };
      this.toggle(e);
      this.triggerEvent('save', eventDetail, {});
    }
  }
});