var app = getApp();Component({
  /**
   * 组件的属性列表
   */
  properties: {},

  /**
   * 组件的初始数据
   */
  data: {
    publishing: false,
    works: [],
    loading: false,
    loadingPage: false,
    nextPage: false,
    page: 1,
    selected: null,
    text: '',
    focus: false
  },

  lifetimes: {
    attached: function attached() {
      this.gif = this.selectComponent('#gif');
      this.action = this.selectComponent('#action');
    }
  },

  /**
   * 组件的方法列表
   */
  methods: {
    refreshWork: function refreshWork() {
      var _this = this;

      app.globalData.loginInfo.then(function (res) {
        wx.req.get('works/?page=' + _this.data.page + '&pageSize=3', {}).then(function (r) {
          _this.setData({
            works: _this.data.works.concat(r.data.results),
            loading: false,
            loadingPage: false,
            nextPage: r.data.next
          });
        });
      });
    },
    publishSubscribe: function publishSubscribe(e) {
      var _this2 = this;

      app.globalData.templateLoad().then(function (r) {
        var msgs = [app.globalData.templateMessage['NEW_COMMENT'], app.globalData.templateMessage['COMMENT_LIKE'], app.globalData.templateMessage['NEW_FEED']];
        wx.eventBus.emit('showSubscribeTip');
        wx.requestSubscribeMessage({
          tmplIds: msgs,
          success: function success(res) {
            if (res.errMsg === 'requestSubscribeMessage:ok') {
              var accept = [];
              var _iteratorNormalCompletion = true;
              var _didIteratorError = false;
              var _iteratorError = undefined;

              try {
                for (var _iterator = msgs[Symbol.iterator](), _step; !(_iteratorNormalCompletion = (_step = _iterator.next()).done); _iteratorNormalCompletion = true) {
                  var templateId = _step.value;

                  if (res[templateId] === 'accept') {
                    accept.push(templateId);
                  }
                }
              } catch (err) {
                _didIteratorError = true;
                _iteratorError = err;
              } finally {
                try {
                  if (!_iteratorNormalCompletion && _iterator.return) {
                    _iterator.return();
                  }
                } finally {
                  if (_didIteratorError) {
                    throw _iteratorError;
                  }
                }
              }

              wx.req.post('message/accept/', { data: { accept: accept } });
            }
          },
          complete: function complete(res) {
            _this2.send();
            wx.eventBus.emit('hideSubscribeTip');
          }
        });
      });
    },
    onReachBottom: function onReachBottom(e) {
      if (!this.data.loadingPage && this.data.nextPage) {
        this.setData({
          loadingPage: true,
          page: this.data.page + 1
        });
        this.refreshWork();
      }
    },
    toMake: function toMake(e) {
      this.closePublish();
      wx.switchTab({
        url: '/pages/index/index'
      });
    },
    gifTap: function gifTap(e) {
      var idx = e.currentTarget.dataset.idx;
      if (this.data.selected) {
        if (this.data.selected.id === e.currentTarget.dataset.gif.id) {
          this.setData({
            selected: null
          });
        } else {
          wx.showToast({
            title: '每次暂时只能发一张',
            icon: 'none'
          });
        }
      } else {
        this.setData({
          selected: this.data.works[idx],
          focus: !this.data.text
        });
      }
    },
    onInputText: function onInputText(e) {
      console.log(e);
      this.setData({
        text: e.detail.value
      });
    },
    send: function send(e) {
      var _this3 = this;

      if (this.data.text || this.data.selected) {
        wx.showLoading({
          title: '发布中...',
          mask: true
        });
        var data = {
          text: this.data.text,
          gif: this.data.selected && this.data.selected.id
        };
        wx.req.post('feed/', { data: data }).then(function (r) {
          wx.hideLoading();
          _this3.setData({
            text: '',
            selected: null
          });
          if (r.data.ticket == '1') {
            wx.eventBus.emit('showCoinAlert_explore', { text: '发布成功运气爆棚 - 获得奖券 x 1', tip: '投入奖池就能抽奖领红包 🎉' });
          }
          wx.eventBus.emit('refreshPlanet', {});
          _this3.closePublish();
        }).catch(function (e) {
          wx.hideLoading();
          wx.showToast({
            title: e.data ? e.data.error : '未知错误',
            icon: 'error'
          });
        });
      }
    },
    openPublish: function openPublish(e) {
      this.refreshWork();
      this.setData({
        publishing: true
      });
    },
    closePublish: function closePublish() {
      this.setData({
        publishing: false,
        works: [],
        loading: false,
        loadingPage: false,
        nextPage: false,
        page: 1
      });
    },
    tap: function tap(e) {
      if (this.data.publishing) {
        this.gif.unshow();
        this.action.unshow();
        this.closePublish();
      } else {
        this.triggerEvent('tapped', e);
      }
    },
    transEnd: function transEnd(e) {
      if (this.data.publishing) {
        this.gif.show();
        this.action.show();
      }
      console.log('trans end.');
    }
  }
});