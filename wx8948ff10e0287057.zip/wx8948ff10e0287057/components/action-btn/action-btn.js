Component({
  /**
   * 组件的属性列表
   */
  properties: {
    open: {
      type: String,
      value: ''
    },
    text: {
      type: String,
      value: ''
    },
    icon: {
      type: String,
      value: ''
    },
    shadow: {
      type: Boolean,
      value: false
    },
    disabled: {
      type: Boolean,
      value: false
    }
  },

  /**
   * 组件的初始数据
   */
  data: {},

  /**
   * 组件的方法列表
   */
  methods: {
    onTap: function onTap(e) {
      this.triggerEvent('onTap', e);
    },
    getPhoneNumber: function getPhoneNumber(e) {
      if (e.detail.errMsg == 'getPhoneNumber:ok') {
        this.triggerEvent('onTap', e);
      }
    }
  }
});