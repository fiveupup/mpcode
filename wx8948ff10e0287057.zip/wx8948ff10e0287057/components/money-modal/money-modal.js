var _WxCountUp = require('../../utils/WxCountUp.js');var _WxCountUp2 = _interopRequireDefault(_WxCountUp);function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }Component({
  /**
   * 组件的属性列表
   */
  properties: {},

  /**
   * 组件的初始数据
   */
  data: {
    loading: false,
    money: 0.00,
    show: false,
    open: false,
    current: '0',
    maxMoney: 0.00,
    showConfirm: false,
    pid: 0,
    packetType: 'mission'
  },

  lifetimes: {
    attached: function attached() {
      // 在组件实例进入页面节点树时执行
      this.moneyCountup = new _WxCountUp2.default('current', '9.99', {
        startVal: 0,
        decimalPlaces: 2,
        duration: .5,
        useEasing: false
      }, this);
    },
    detached: function detached() {
      // 在组件实例被从页面节点树移除时执行
    }
  },

  /**
   * 组件的方法列表
   */
  methods: {
    open: function open(maxMoney, pid, packetType) {
      var _this = this;

      this.moneyCountup.update(maxMoney);
      this.moneyCountup.reset();
      this.setData({
        loading: false,
        maxMoney: Number(maxMoney),
        show: true,
        open: false,
        showConfirm: false,
        pid: pid,
        packetType: packetType
      });
      this.interval = setInterval(function () {
        if (_this.data.open) {
          clearInterval(_this.interval);
          _this.moneyCountup.update(_this.data.money);
        } else {
          _this.moneyCountup.reset();
          _this.moneyCountup.start();
        }
      }, 500);
    },
    stop: function stop(e) {
      var _this2 = this;

      this.setData({
        loading: true
      });
      var url = 'mc/';
      if (this.data.packetType === 'mission') {
        url = 'mc/';
      } else if (this.data.packetType === 'judge') {
        url = 'jc/';
      } else if (this.data.packetType === 'play') {
        url = 'pc/';
      }
      wx.req.post(url, {
        data: {
          id: this.data.pid
        }
      }).then(function (r) {
        _this2.setData({
          open: true,
          money: r.data.amount
        });
        setTimeout(function () {
          _this2.setData({
            showConfirm: true
          });
        }, 1000);
      });
    },
    confirm: function confirm(e) {
      this.interval && clearInterval(this.interval);
      this.setData({
        show: false
      });
      this.triggerEvent('confirm', {
        money: Number(this.data.money)
      }, {});
    }
  }
});