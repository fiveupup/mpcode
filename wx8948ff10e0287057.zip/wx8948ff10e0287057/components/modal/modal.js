Component({
  options: {
    multipleSlots: true // 在组件定义时的选项中启用多slot支持
  },

  /**
   * 组件的属性列表
   */
  properties: {
    title: {
      type: String,
      value: ''
    },
    confirmText: {
      type: String,
      value: '保存'
    },
    closeBtn: {
      type: Boolean,
      value: true
    },
    tricky: {
      type: Boolean,
      value: false
    }
  },

  /**
   * 组件的初始数据
   */
  data: {
    show: false,
    title: '',
    content: ''
  },

  /**
   * 组件的方法列表
   */
  methods: {
    toggle: function toggle(e) {
      if (this.data.show) {
        this.close(e);
      } else {
        this.show(e);
      }
    },
    show: function show() {
      var _ref = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {
        title: '默认',
        content: ''
      },
          title = _ref.title,
          content = _ref.content;

      this.setData({
        title: this.data.title || title,
        content: content,
        show: true
      });
    },
    close: function close(e) {
      this.setData({
        show: false
      });
      this.triggerEvent('close', {});
    }
  }
});