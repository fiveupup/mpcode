var app = getApp();Component({
  /**
   * 组件的属性列表
   */
  properties: {},

  /**
   * 组件的初始数据
   */
  data: {
    left: 150,
    show: false
  },

  lifetimes: {
    attached: function attached() {
      if (app.globalData.scene !== 1001) {
        this.setData({
          show: true
        });
        setTimeout(this.close.bind(this), 10000);
      }

      var _wx$getMenuButtonBoun = wx.getMenuButtonBoundingClientRect(),
          left = _wx$getMenuButtonBoun.left;

      this.setData({
        left: left + 10
      });
    }
  },

  /**
   * 组件的方法列表
   */
  methods: {
    close: function close(e) {
      this.setData({
        show: !this.data.show
      });
    }
  }
});