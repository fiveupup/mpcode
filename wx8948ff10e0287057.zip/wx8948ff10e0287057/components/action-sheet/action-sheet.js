Component({
  /**
   * 组件的属性列表
   */
  options: {
    multipleSlots: true // 在组件定义时的选项中启用多slot支持
  },

  properties: {
    unsafe: {
      type: Boolean,
      value: false
    },
    touchmove: {
      type: Boolean,
      value: true
    },
    title: {
      type: String,
      value: '温馨提示'
    },
    dec: {
      type: String,
      value: '您已进入辐射区请尽快撤离'
    },
    open: {
      type: String,
      value: ''
    },
    showCloseHead: {
      type: Boolean,
      value: true
    },
    text: {
      type: String,
      value: ''
    },
    icon: {
      type: String,
      value: ''
    },
    custom: {
      type: Boolean,
      value: false
    },
    sku: {
      type: Object,
      value: {}
    },
    height: {
      type: String,
      value: 'auto'
    },
    disabled: {
      type: Boolean,
      value: false
    }
  },

  data: {
    show: false,
    hidden: true
  },

  lifetimes: {
    ready: function ready() {
      // this.openSheet()
    }
  },

  /**
   * 组件的方法列表
   */
  methods: {
    catch: function _catch() {},
    closeSheet: function closeSheet() {
      var _this = this;

      clearTimeout(this.animationTimeout);
      this.setData({
        show: false
      }, function () {
        _this.animationTimeout = setTimeout(function () {
          this.setData({
            hidden: true
          });
          this.triggerEvent('cancelTap');
        }.bind(_this), 200);
      });
    },
    openSheet: function openSheet() {
      var _this2 = this;

      clearTimeout(this.animationTimeout);
      this.setData({
        hidden: false
      });
      wx.nextTick(function () {
        _this2.setData({
          show: true
        }, function () {
          _this2.triggerEvent('opened');
        });
      });
    },
    doneTap: function doneTap(e) {
      console.log('onTap');
      this.triggerEvent('doneTap');
    },
    contentClick: function contentClick() {}
  }
});