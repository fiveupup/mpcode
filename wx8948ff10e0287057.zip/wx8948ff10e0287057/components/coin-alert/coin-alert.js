Component({
  /**
   * 组件的属性列表
   */
  properties: {},

  /**
   * 组件的初始数据
   */
  data: {
    show: false,
    visible: false,
    text: '',
    tip: ''
  },

  /**
   * 组件的方法列表
   */
  methods: {
    open: function open(text, tip) {
      var _this = this;

      wx.vibrateShort({
        type: 'medium'
      });
      this.setData({
        visible: true,
        text: text,
        tip: tip
      }, function () {
        setTimeout(function () {
          _this.setData({
            show: true
          });
        }, 0);
      });
    },
    close: function close() {
      var _this2 = this;

      wx.vibrateShort({});
      this.setData({
        show: false
      }, function () {
        setTimeout(function () {
          _this2.setData({
            visible: false
          });
        }, 200);
      });
    },
    doneTap: function doneTap() {
      this.triggerEvent('lottery');
      this.close();
    }
  }
});