Component({
  properties: {
    value: {
      type: Number,
      value: 0,
      observer: function observer(newValue) {
        this._refreshValues(newValue);
      }
    },
    placeholder: {
      type: Number,
      value: 0,
      observer: function observer(newValue) {
        this._refreshPlaceholders(newValue);
      }
    },
    allowHalf: {
      type: Boolean,
      value: true
    },
    disabled: {
      type: Boolean,
      value: false
    },
    length: {
      type: Number, // 评选数量
      value: 5
    }
  },
  data: {
    iconClassMap: {
      '0': 'empty',
      '0.5': 'half',
      '1': 'full'
    },
    iconText: 'star',
    values: [],
    placeholders: []
  },
  ready: function ready() {
    if (this.data.value === 0 && this.data.placeholder === 0) {
      this._refreshPlaceholders(0);
    }
  },

  methods: {
    _refreshValues: function _refreshValues(value) {
      this.setData({
        values: this._generateArray(Number(value))
      });
    },
    _refreshPlaceholders: function _refreshPlaceholders(value) {
      this.setData({
        placeholders: this._generateArray(Number(value))
      });
    },
    _generateArray: function _generateArray(value) {
      var arr = [];

      var fullCount = value;
      if (fullCount <= 0) {
        return [0, 0, 0, 0, 0];
      }

      var isAppendHalf = false; // 是否需要加半星
      if (this.data.allowHalf) {
        // 允许半星的向下取整
        if (!isPositiveIntegerNumber(fullCount)) {
          // 非整数
          fullCount = Math.floor(fullCount);
          isAppendHalf = true;
        }
      } else {
        // 不允许半星的向上取整
        fullCount = Math.ceil(fullCount);
      }
      // 循环追加完整分数
      for (var i = 0; i < fullCount; i++) {
        arr.push(1);
      }
      if (isAppendHalf) {
        arr.push(0.5);
      }
      // 循环追加空分
      var emptyCount = this.data.length - arr.length;
      for (var _i = 0; _i < emptyCount; _i++) {
        arr.push(0);
      }

      // console.log(arr)
      return arr;
    },
    choose: function choose(e) {
      if (this.data.disabled) {
        return;
      }

      var index = Number(e.currentTarget.dataset.index);
      var isHalf = Number(e.currentTarget.dataset.half) === 1;
      var value = (index + 1) * 2;
      if (this.data.allowHalf) {
        // 允许半个
        if (isHalf) {
          // 点了左一半
          value = value - 1;
        }
      }
      value = (value / 2).toFixed(1);

      if (value === this.data.value) {
        return;
      }
      this.setData({
        value: value
      });
      this.triggerEvent('change', {
        value: value
      });
    }
  }
});function rpxToPx(rpx) {
  var sysInfo = wx.getSystemInfoSync();
  return rpx * sysInfo.windowWidth / 750;
}function isPositiveIntegerNumber(num) {
  var numStr = num.toString();
  return (/(^[1-9]\d*$)/.test(numStr)
  );
}