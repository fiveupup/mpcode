function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }function _toConsumableArray(arr) { if (Array.isArray(arr)) { for (var i = 0, arr2 = Array(arr.length); i < arr.length; i++) { arr2[i] = arr[i]; } return arr2; } else { return Array.from(arr); } }var app = getApp();var throttle = require('../../utils/throttle');Component({
  /**
   * 组件的属性列表
   */
  properties: {
    unsafe: {
      type: Boolean,
      value: false
    },
    touchmove: {
      type: Boolean,
      value: true
    }
  },

  /**
   * 组件的初始数据
   */
  data: {
    id: -1,
    number: '', // 评论总数量
    bottom: 0, // 键盘上的输入框的动画特效
    duration: 0, // 键盘上的输入框的动画特效
    commentContent: '', // 当前键入的评论的内容
    sending: false, // 评论点击后，发出前的一个标记，暂时没用用showLoading代替了
    replyTo: 0, // 正在回复的评论id
    parent: 0, // 回复所在的层级位置的父评论
    loading: false, // 加载时评论框内全屏loading的标记
    page: 0, // 当前页数
    next: true, // 标记评论是否到底了
    comments: [], // 评论列表
    focus: false, // 是否聚焦输入框
    toUser: '', // 输入框中回复某某人的昵称
    paging: false, // 是否正在翻页（防止重复翻页）
    insertIdx: -1, // 前端插入新评论时的index锚点，-1就是在外层评论
    mask: false, // 键盘弹起时防止点击穿透唤起其他event
    error: false
  },

  lifetimes: {
    attached: function attached() {
      this.onThumb = throttle.throttle(this._thumbup.bind(this), 500);
      this.actionSheet = this.selectComponent('#action-sheet');
    }
  },

  /**
   * 组件的方法列表
   */
  methods: {
    catch: function _catch() {},
    closeSheet: function closeSheet() {
      this.actionSheet.closeSheet();
    },
    onClose: function onClose() {
      wx.showTabBar({
        animation: true
      });
      this.setData({
        replyTo: 0,
        parent: 0,
        id: -1,
        comments: [],
        next: true,
        page: 0,
        toUser: '',
        insertIdx: -1,
        commentContent: ''
      });
    },
    openSheet: function openSheet(_ref) {
      var _this = this;

      var feedId = _ref.feedId;

      wx.hideTabBar({
        animation: true
      });
      this.setData({
        id: feedId,
        loading: true
      }, function () {
        _this.getNextPage();
      });
      this.actionSheet.openSheet();
    },
    getNextPage: function getNextPage(e) {
      var _this2 = this;

      if (this.data.next && !this.data.paging) {
        this.setData({
          paging: true
        });
        wx.req.get('comment/?feed=' + this.data.id + '&page=' + (this.data.page + 1), {}).then(function (r) {
          _this2.setData({
            loading: false,
            comments: [].concat(_toConsumableArray(_this2.data.comments), _toConsumableArray(r.data.results)),
            page: _this2.data.page + 1,
            paging: false,
            error: false,
            next: r.data.next,
            number: r.data.count
          });
        }).catch(function (e) {
          _this2.setData({
            loading: false,
            paging: false,
            error: true
          });
        });
      }
    },
    commentSubscribe: function commentSubscribe(e) {
      var _this3 = this;

      app.globalData.templateLoad().then(function (r) {
        var msgs = [app.globalData.templateMessage['NEW_REPLY'], app.globalData.templateMessage['NEW_FEED']];
        wx.eventBus.emit('showSubscribeTip');
        wx.requestSubscribeMessage({
          tmplIds: msgs,
          success: function success(res) {
            if (res.errMsg === 'requestSubscribeMessage:ok') {
              var accept = [];
              var _iteratorNormalCompletion = true;
              var _didIteratorError = false;
              var _iteratorError = undefined;

              try {
                for (var _iterator = msgs[Symbol.iterator](), _step; !(_iteratorNormalCompletion = (_step = _iterator.next()).done); _iteratorNormalCompletion = true) {
                  var templateId = _step.value;

                  if (res[templateId] === 'accept') {
                    accept.push(templateId);
                  }
                }
              } catch (err) {
                _didIteratorError = true;
                _iteratorError = err;
              } finally {
                try {
                  if (!_iteratorNormalCompletion && _iterator.return) {
                    _iterator.return();
                  }
                } finally {
                  if (_didIteratorError) {
                    throw _iteratorError;
                  }
                }
              }

              wx.req.post('message/accept/', { data: { accept: accept } });
            }
          },
          complete: function complete(res) {
            _this3.doSendComment();
            wx.eventBus.emit('hideSubscribeTip');
          }
        });
      });
    },
    onBlur: function onBlur(e) {
      console.log('onBlur!!!!');
    },
    onFocus: function onFocus(e) {
      console.log('onFocus!!!!');
    },
    commentRefresh: function commentRefresh() {
      // 触发组件外的局部刷新
      wx.eventBus.emit('commentRefresh' + this.data.id);
    },
    calcBottom: function calcBottom(event) {
      this.setData({
        bottom: event.detail.height,
        duration: event.detail.duration,
        mask: !!event.detail.height
      });
    },
    commentInput: function commentInput(e) {
      this.setData({
        commentContent: e.detail.value
      });
    },
    doSendComment: function doSendComment(e) {
      var _this4 = this;

      wx.showLoading({
        title: '发送中...',
        mask: true
      });
      this.setData({
        sending: true
      });
      var data = {
        "reply_to": this.data.replyTo || null,
        "text": this.data.commentContent,
        "feed": this.data.id,
        "parent": this.data.parent || null
      };
      var insertPosition = this.data.insertIdx;
      wx.req.post('comment/', { data: data }).then(function (r) {
        wx.hideLoading();
        wx.showToast({
          title: '评论成功',
          icon: 'none'
        });
        if (r.data.ticket == '1') {
          wx.eventBus.emit('showCoinAlert_explore', { text: '评论成功运气爆棚 - 获得奖券 x 1', tip: '投入奖池就能抽奖领红包 🎉' });
        }
        if (insertPosition === -1) {
          _this4.data.comments.splice(0, 0, r.data);
        } else {
          _this4.data.comments[insertPosition].children.splice(0, 0, r.data);
        }
        _this4.setData({
          number: _this4.data.number + 1
        });
        var newComments = _this4.data.comments;
        _this4.setData({
          focus: false,
          commentContent: '',
          sending: false,
          comments: newComments
        });
        _this4.commentRefresh();
      }).catch(function (e) {
        wx.hideLoading();
        wx.showToast({
          title: e.data && e.data.detail || e.data.error || '评论出错，请稍后重试',
          icon: 'none'
        });
        _this4.setData({
          focus: false,
          sending: false
        });
      });
    },
    sendComment: function sendComment(e) {
      console.log('sending comment');
      if (this.data.commentContent.length <= 0) {
        wx.showToast({
          title: '写点什么吧~',
          icon: 'none'
        });
      } else {
        this.commentSubscribe();
      }
    },
    _thumbup: function _thumbup(e) {
      //不直接使用此函数，对前端用throttle的函数onThumb
      console.log('_thumbup');
      var commentId = e.currentTarget.dataset.id;
      var idx = e.currentTarget.dataset.idx;
      var isReply = e.currentTarget.dataset.reply;
      var replyIdx = e.currentTarget.dataset.replyIdx;
      var likeStatus = e.currentTarget.dataset.liked;
      var toLikeStatus = void 0,
          toLikeCount = void 0;
      if (likeStatus == '1') {
        app.globalData.loginInfo.then(function (res) {
          wx.req.delete('comment/' + commentId + '/like/', {});
        });
        toLikeStatus = '0';
        toLikeCount = isReply ? this.data.comments[idx].children[replyIdx].likes.count - 1 : this.data.comments[idx].likes.count - 1;
      } else {
        app.globalData.loginInfo.then(function (res) {
          wx.req.post('comment/' + commentId + '/like/', {});
        });
        toLikeStatus = '1';
        toLikeCount = isReply ? this.data.comments[idx].children[replyIdx].likes.count + 1 : this.data.comments[idx].likes.count + 1;
      }
      if (isReply) {
        var _setData;

        this.setData((_setData = {}, _defineProperty(_setData, 'comments[' + idx + '].children[' + replyIdx + '].likes.liked', toLikeStatus), _defineProperty(_setData, 'comments[' + idx + '].children[' + replyIdx + '].likes.count', toLikeCount), _setData));
      } else {
        var _setData2;

        this.setData((_setData2 = {}, _defineProperty(_setData2, 'comments[' + idx + '].likes.liked', toLikeStatus), _defineProperty(_setData2, 'comments[' + idx + '].likes.count', toLikeCount), _setData2));
      }
      this.animate('#like-' + commentId, [{
        scaleX: .8,
        scaleY: .8,
        ease: 'cubic-bezier(0.16, 0.88, 0.7, 2.17)'
      }, {
        scaleX: 1,
        scaleY: 1,
        ease: 'cubic-bezier(0.16, 0.88, 0.7, 2.17)'
      }], 300, function () {
        this.clearAnimation('#like-' + commentId, {
          scaleX: true,
          scaleY: true
        });
      }.bind(this));
    },
    clearReply: function clearReply(e) {
      console.log('clear reply.');
      var toUser = '';
      var replyTo = 0;
      var parent = 0;
      var insertIdx = -1;
      this.setData({
        toUser: toUser,
        replyTo: replyTo,
        insertIdx: insertIdx,
        parent: parent
      });
    },
    maskOn: function maskOn(e) {
      this.setData({
        mask: true
      });
    },
    reply: function reply(e) {
      var insertIdx = e.currentTarget.dataset.idx;
      var to = e.currentTarget.dataset.to;
      var parent = e.currentTarget.dataset.parent;
      var replyTo = to.id;
      var toUser = to.v_user.nickname;
      var focus = true;
      console.log('reply ', toUser, insertIdx, replyTo);
      this.setData({
        toUser: toUser,
        replyTo: replyTo,
        parent: parent,
        focus: focus,
        insertIdx: insertIdx
      });
    }
  }
});