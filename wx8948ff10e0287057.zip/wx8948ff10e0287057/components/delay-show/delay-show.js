Component({
  /**
   * 组件的属性列表
   */
  properties: {
    duration: {
      type: Number,
      value: 500
    },
    delay: {
      type: Number,
      value: 50
    }
  },

  /**
   * 组件的初始数据
   */
  data: {
    show: false,
    hidden: true
  },

  /**
   * 组件的方法列表
   */
  methods: {
    show: function show() {
      var _this = this;

      this.setData({
        hidden: false
      }, function () {
        setTimeout(function () {
          _this.setData({
            show: true
          });
        }, _this.data.delay);
      });
    },
    unshow: function unshow() {
      var _this2 = this;

      this.setData({
        show: false
      }, function () {
        setTimeout(function () {
          _this2.setData({
            hidden: true
          });
        }, _this2.data.duration);
      });
    }
  }
});