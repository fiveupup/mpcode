Component({
  /**
   * 组件的属性列表
   */
  properties: {
    ad: {
      type: Object,
      value: null
    }
  },

  /**
   * 组件的初始数据
   */
  data: {
    error: 0,
    currentAd: null
  },

  observers: {
    'ad': function ad(_ad) {
      this.setData({
        currentAd: _ad
      });
    }
  },

  /**
   * 组件的方法列表
   */
  methods: {
    adLoaded: function adLoaded(e) {
      console.log(e);
    },
    loadError: function loadError(e) {
      wx.reportAnalytics('ad_load_error', {
        errmsg: e.detail.errMsg,
        errcode: e.detail.errCode,
        error: this.data.error
      });
      this.setData({
        error: this.data.error + 1,
        currentAd: this.data.currentAd.backup
      });
      console.log(e);
    },
    adClick: function adClick(e) {
      var _this = this;

      wx.navigateToMiniProgram({
        appId: this.data.currentAd.app_id,
        path: this.data.currentAd.link,
        success: function success(res) {
          wx.req.post('ad/' + _this.data.currentAd.id + '/click/', {});
        }
      });
    }
  }
});