Component({
  /**
   * 组件的属性列表
   */
  properties: {
    currentPercent: {
      value: 0,
      type: Number
    },
    hideCursor: {
      value: false,
      type: Boolean
    },
    rangeSlider: {
      type: Boolean,
      value: false
    },
    lowValue: {
      type: Number,
      value: 0
    },
    highValue: {
      type: Number,
      value: 0
    },
    min: {
      type: Number,
      value: 0
    },
    max: {
      type: Number,
      value: 100
    },
    minRange: {
      type: Number,
      value: 0
    }
  },

  /**
   * 组件的初始数据
   */
  data: {
    cursorAnimation: '',
    left: 0,
    width: 70,
    minWidth: 0,
    totalWidth: 0,
    thumbStart: {
      x: 0,
      item: 'high'
    },
    freezeLeft: 0,
    freezeWidth: 0,
    translateX: 0
  },

  lifetimes: {
    attached: function attached() {
      this.reset();
    }
  },

  observers: {
    'currentPercent': function currentPercent(percent) {
      this.setData({
        translateX: percent * this.data.totalWidth
      });
    }
  },

  /**
   * 组件的方法列表
   */
  methods: {
    thumbTouchStart: function thumbTouchStart(e) {
      this.setData({
        'thumbStart.x': e.touches[0].clientX,
        'thumbStart.item': e.currentTarget.dataset.thumb,
        freezeLeft: this.data.left,
        freezeWidth: this.data.width
      });
    },
    setCursorAnimation: function setCursorAnimation(distance, duration) {
      var animation = wx.createAnimation({
        delay: 0,
        duration: duration,
        timingFunction: 'linear'
      });
      animation.translateX(distance).step();
      this.setData({
        cursorAnimation: animation
      });
    },
    setCursorInit: function setCursorInit() {
      var animation = wx.createAnimation({
        delay: 0,
        duration: 0
      });
      animation.translateX(this.data.left).step();
      this.setData({
        cursorAnimation: animation
      });
    },
    thumbTouchMove: function thumbTouchMove(e) {
      var distance = e.changedTouches[0].clientX - this.data.thumbStart.x;
      var newData = {};
      var eventDetail = {
        highValue: this.data.highValue,
        lowValue: this.data.lowValue
      };
      if (this.data.thumbStart.item == 'high') {
        // 右侧滑动条
        // 不能超过最大值left + width不能超过totalWidth
        // 至少保留最小minRange这么长的长度
        newData['width'] = Math.max(this.data.minWidth, Math.min(this.data.freezeWidth + distance, this.data.totalWidth - this.data.left));
        eventDetail.highValue = this.data.min + (this.data.left + newData.width) / this.data.totalWidth * (this.data.max - this.data.min);
        this.triggerEvent('slidehigh', eventDetail, {});
      } else {
        // 左侧滑动条
        // 不能小于0
        // 不能大于freezeWidth + freezeLeft
        newData['width'] = Math.min(this.data.freezeWidth + this.data.freezeLeft, Math.max(this.data.freezeWidth - distance, this.data.minWidth));
        newData['left'] = this.data.freezeWidth + this.data.freezeLeft - newData['width'];
        eventDetail.lowValue = this.data.min + newData.left / this.data.totalWidth * (this.data.max - this.data.min);
        this.triggerEvent('slidelow', eventDetail, {});
      }
      this.triggerEvent('slide', eventDetail, {});
      this.setData(newData);
    },
    thumbTouchEnd: function thumbTouchEnd(e) {
      this.startAni();
      this.triggerEvent('slidetouchend', e.currentTarget.dataset.thumb, {});
    },
    startAni: function startAni(e) {
      console.log(e);
      this.setCursorInit();
      this.setCursorAnimation(this.data.left + this.data.width, (this.data.highValue - this.data.lowValue) * 1000);
    },
    reset: function reset() {
      var _this = this;

      var query = wx.createSelectorQuery().in(this);
      query.select('.slider').boundingClientRect();
      query.exec(function (res) {
        var minWidth = _this.data.minRange / (_this.data.max - _this.data.min) * res[0].width;
        _this.setData({
          totalWidth: res[0].width,
          minWidth: minWidth,
          width: Math.max(minWidth, (_this.data.highValue - _this.data.lowValue) / (_this.data.max - _this.data.min) * res[0].width),
          left: 0
        }, function () {
          _this.startAni();
        });
      });
    }
  }
});