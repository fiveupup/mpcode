Component({
  /**
   * 组件的属性列表
   */
  properties: {},

  lifetimes: {
    attached: function attached() {
      var _this = this;

      var windowWidth = wx.getSystemInfoSync().windowWidth;
      var text = '欢迎来到GIF星球，点击屏幕下方的“+”试试发布动态吧。';
      var length = text.length * this.data.size; //文字长度
      this.setData({
        text: text,
        length: length,
        windowWidth: windowWidth
      }, function () {
        _this.runNotification(); // 水平一行字滚动完了再按照原来的方向滚动
      });
    }
  },
  /**
   * 组件的初始数据
   */
  data: {
    text: '嘎嘎嘎过',
    marqueePace: .5, //滚动速度
    marqueeDistance: 0, //初始滚动距离
    size: 14,
    orientation: 'left', //滚动方向
    interval: 20 // 时间间隔
  },

  /**
   * 组件的方法列表
   */
  methods: {
    runNotification: function runNotification() {
      var vm = this;
      var interval = setInterval(function () {
        if (-vm.data.marqueeDistance < vm.data.length) {
          vm.setData({
            marqueeDistance: vm.data.marqueeDistance - vm.data.marqueePace
          });
        } else {
          clearInterval(interval);
          vm.setData({
            marqueeDistance: vm.data.windowWidth
          });
          vm.runNotification();
        }
      }, vm.data.interval);
    }
  }
});