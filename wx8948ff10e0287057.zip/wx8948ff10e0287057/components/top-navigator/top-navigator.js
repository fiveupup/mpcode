var app = getApp();Component({
  options: {
    multipleSlots: true // 在组件定义时的选项中启用多slot支持
  },

  /**
   * 组件的属性列表
   */
  properties: {
    custom: {
      type: Boolean,
      value: false
    },
    customLeftCorner: {
      type: Boolean,
      value: false
    },
    transparent: {
      type: Boolean,
      value: false
    },
    unique: {
      type: String,
      value: ''
    }
  },

  lifetimes: {
    attached: function attached() {
      this.setData(this.getRect());
      this.bindOnTop();
      this.bindChangeBtn();
      this.bindChangeTitle();
      this.bindChangeTheme();
    }
  },

  /**
   * 组件的初始数据
   */
  data: {
    navBarHeight: 0,
    statusBarHeight: 0,
    onTop: '',
    icons: {
      'history': '/assets/images/top-navigator/history.png',
      'back': '/assets/images/top-navigator/back.png',
      'more': '/assets/images/top-navigator/more.png'
    },
    btnOptions: {
      'path': '',
      'icon': 'hisotry',
      'action': wx.navigateTo
    },
    currentIcon: '',
    currentAction: null,
    title: '',
    currentPath: '',
    theme: 'white'
  },

  /**
   * 组件的方法列表
   */
  methods: {
    getRect: function getRect(e) {
      var systemInfo = wx.getSystemInfoSync();
      var rect = wx.getMenuButtonBoundingClientRect ? wx.getMenuButtonBoundingClientRect() : null; //胶囊按钮位置信息
      try {
        if (rect === null) {
          throw 'getMenuButtonBoundingClientRect error';
        }
        //取值为0的情况
        if (!rect.width) {
          throw 'getMenuButtonBoundingClientRect error';
        }
      } catch (error) {
        var _gap = ''; //胶囊按钮上下间距 使导航内容居中
        var width = 96; //胶囊的宽度，android大部分96，ios为88
        if (systemInfo.platform === 'android') {
          _gap = 8;
          width = 96;
        } else if (systemInfo.platform === 'devtools') {
          if (ios) {
            _gap = 5.5; //开发工具中ios手机
          } else {
            _gap = 7.5; //开发工具中android和其他手机
          }
        } else {
          _gap = 4;
          width = 88;
        }
        if (!systemInfo.statusBarHeight) {
          //开启wifi的情况下修复statusBarHeight值获取不到
          systemInfo.statusBarHeight = systemInfo.screenHeight - systemInfo.windowHeight - 20;
        }
        rect = {
          //获取不到胶囊信息就自定义重置一个
          bottom: systemInfo.statusBarHeight + _gap + 32,
          height: 32,
          left: systemInfo.windowWidth - width - 10,
          right: systemInfo.windowWidth - 10,
          top: systemInfo.statusBarHeight + _gap,
          width: width
        };
      }
      var gap = rect.top - systemInfo.statusBarHeight;
      return {
        statusBarHeight: systemInfo.statusBarHeight,
        navBarHeight: 2 * gap + rect.height
      };
    },
    changeBtn: function changeBtn(options) {
      this.setData({
        currentIcon: this.data.icons[options.icon] || '',
        currentAction: options.action,
        currentPath: options.path || ''
      });
    },
    changeTheme: function changeTheme(theme) {
      this.setData({
        theme: theme
      });
    },
    changeTitle: function changeTitle(title) {
      this.setData({
        title: title
      });
    },
    onTop: function onTop(_onTop) {
      this.setData({
        onTop: _onTop ? 'on-top' : ''
      });
    },
    bindChangeBtn: function bindChangeBtn() {
      wx.eventBus.on('topNavBtn' + this.data.unique, this.changeBtn.bind(this));
    },
    bindChangeTitle: function bindChangeTitle() {
      wx.eventBus.on('topNavTitle' + this.data.unique, this.changeTitle.bind(this));
    },
    bindChangeTheme: function bindChangeTheme() {
      wx.eventBus.on('topNavTheme' + this.data.unique, this.changeTheme.bind(this));
    },
    bindOnTop: function bindOnTop() {
      wx.eventBus.on('topNavOnTop' + this.data.unique, this.onTop.bind(this));
    },
    onBtnTap: function onBtnTap(e) {
      if (this.data.currentAction) {
        if (this.data.currentPath === '/pages/history/history') {
          wx.uma.trackEvent("clickLookBack");
          wx.bo.track("clickLookBack");
        }
        this.data.currentAction({ url: this.data.currentPath, detail: e });
      }
    }
  }
});