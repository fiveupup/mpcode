Component({
  /**
   * 组件的属性列表
   */
  properties: {
    text: {
      type: String,
      value: ''
    },
    size: {
      type: Number,
      value: 20
    },
    startTime: {
      type: Number,
      value: 0
    },
    endTime: {
      type: Number,
      value: 0
    },
    select: {
      type: Boolean,
      value: false
    },
    show: {
      type: Boolean,
      value: false
    },
    currentProgress: {
      type: Number,
      value: 0
    },
    idx: {
      type: Number,
      value: 0
    }
  },

  observers: {
    'currentProgress': function currentProgress(_currentProgress) {
      this.setData({
        blur: _currentProgress > this.data.endTime || _currentProgress < this.data.startTime
      });
    }
  },

  /**
   * 组件的初始数据
   */
  data: {
    blur: false
  },

  /**
   * 组件的方法列表
   */
  methods: {
    edit: function edit(e) {
      this.triggerEvent('edit', { idx: this.data.idx }, {});
    },
    delete: function _delete(e) {
      var _this = this;

      wx.showModal({
        title: '确认',
        content: '删除这条字幕吗？',
        confirmText: '删除',
        confirmColor: '#E3140C',
        success: function success(res) {
          if (res.confirm) {
            _this.triggerEvent('delete', { idx: _this.data.idx }, {});
          }
        }
      });
    }
  }
});