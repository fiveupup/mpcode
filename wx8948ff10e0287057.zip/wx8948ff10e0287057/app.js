var _request = require("/utils/request");var _request2 = _interopRequireDefault(_request);function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }var eventBus = require("./utils/event.js");App({
  onLaunch: function onLaunch(options) {
    console.log(options);
    this.globalData.adFree = !!options.query.adFree;
    wx.reportAnalytics("enter_app", {
      from: options.scene
    });

    this.globalData.scene = options.scene;
    var inviter = options.query.inviter;
    var updateManager = wx.getUpdateManager();

    updateManager.onCheckForUpdate(function (res) {
      // 请求完新版本信息的回调
      console.log(res.hasUpdate);
    });

    updateManager.onUpdateReady(function () {
      wx.showModal({
        title: "更新提示",
        content: "新版本已经准备好，是否重启应用？",
        success: function success(res) {
          if (res.confirm) {
            // 新的版本已经下载好，调用 applyUpdate 应用新版本并重启
            updateManager.applyUpdate();
          }
        }
      });
    });
    wx.req = _request2.default;
    wx.eventBus = eventBus;
    if (inviter) {
      this.globalData.loginInfo.then(function (e) {
        wx.req.post("inviter/", {
          data: {
            uid: inviter
          }
        });
      });
    }
    // wx.setStorageSync('loginInfo', )
    wx.getSetting({
      withSubscriptions: true,
      success: function success(res) {
        console.log(res);
      }
    });
    wx.loadFontFace({
      global: true,
      family: "iconfont",
      source: 'url("https://img.newunderstand.com/assets/iconfont.ttf")',
      success: function success(e) {
        console.log("iconfont loaded.");
      },
      fail: function fail(e) {
        console.log(e);
      }
    });
  },

  globalData: {
    adFree: false,
    loginInfo: new Promise(function (resolve, reject) {
      console.log("trying to login");
      wx.login({
        success: function success(res) {
          if (res.code) {
            var data = {
              code: res.code
            };
            wx.req.post("login/", {
              data: data
            }).then(function (r) {
              // 成功获取用户token并写入storage
              wx.setStorageSync("token", r.data.token);
              resolve(r.data);
            }).catch(function (e) {
              // 从服务器获取用户信息和用户token失败
              wx.showToast({
                title: e.data.error || "很抱歉，服务器出错，登录失败。",
                icon: "none",
                duration: 5000
              });
              reject(e.data.error);
            });
          } else {
            // wx.login成功 但获取的结果中没有code
            reject(res.errMsg);
            console.log("登录失败！" + res.errMsg);
          }
        },
        fail: function fail(res) {
          // wx.login 失败
          reject(res);
        }
      });
    }),
    adsLoad: function adsLoad() {
      var _this = this;

      return this.loginInfo.then(function (r) {
        return wx.req.get("ad/ads/", {});
      }).then(function (r) {
        if (!_this.adFree) {
          _this.ads = r.data;
        }
        return r;
      });
    },
    templateLoad: function templateLoad() {
      var _this2 = this;

      return this.loginInfo.then(function (r) {
        return wx.req.get("message/all/", {});
      }).then(function (r) {
        _this2.templateMessage = r.data;
        return r;
      });
    },
    settingsLoad: function settingsLoad() {
      var _this3 = this;

      return this.loginInfo.then(function (r) {
        return wx.req.get("settings/", {});
      }).then(function (r) {
        _this3.settings = r.data;
        return r;
      });
    },
    settings: {},
    ads: {},
    templateMessage: {},
    scene: 0,
    userInfo: null
  }
});