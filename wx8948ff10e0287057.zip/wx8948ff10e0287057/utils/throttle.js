function throttle(fn, gapTime) {
  var lastTimes = null;
  return function (e) {
    var _nowTime = new Date();
    if (!lastTimes || _nowTime - lastTimes > gapTime) {
      fn(e);
      lastTimes = _nowTime;
    }
  };
}module.exports = {
  throttle: throttle
};