var eventBus = {
  all: new Map(),
  distinctOn: function distinctOn(key, fun) {
    this.all.set(key, [fun]);
  },
  on: function on(key, fun) {
    var funs = this.all.get(key);
    var added = funs && funs.push(fun);
    if (!added) {
      this.all.set(key, [fun]);
    }
  },
  off: function off(key, fun) {
    var funs = this.all.get(key);
    if (funs) {
      funs.splice(funs.indexOf(fun) >>> 0, 1);
    }
  },
  emit: function emit(key, data) {
    (this.all.get(key) || []).map(function (fun) {
      fun(data);
    });
  }
};module.exports = eventBus;