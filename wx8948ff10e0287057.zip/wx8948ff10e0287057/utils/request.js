Object.defineProperty(exports, "__esModule", {
  value: true
});var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }var Request = function () {
  function Request(url, _ref) {
    var method = _ref.method,
        data = _ref.data,
        header = _ref.header,
        dataType = _ref.dataType,
        responseType = _ref.responseType,
        onLoading = _ref.onLoading,
        onComplete = _ref.onComplete;

    _classCallCheck(this, Request);

    this.token = wx.getStorageSync('token');
    this.baseUrl = 'https://v2g.ent.newunderstand.com/api/';
    // this.baseUrl = 'http://192.168.0.100:8000/api/'
    this.url = url;
    this.method = method || 'GET';
    this.data = data || {};
    this.header = Object.assign({
      'content-type': 'application/json',
      'Authorization': 'Token ' + this.token
    }, header);
    console.log(this.header);
    this.dataType = dataType || 'json';
    this.responseType = responseType || 'text';
    this.onLoading = onLoading || function () {};
    this.onComplete = onComplete || function () {};
  }

  _createClass(Request, [{
    key: 'send',
    value: function send() {
      var _this = this;

      this.onLoading();
      return new Promise(function (resolve, reject) {
        wx.request({
          url: _this.baseUrl + _this.url,
          data: _this.data,
          method: _this.method,
          header: _this.header,
          dataType: _this.dataType,
          responseType: _this.responseType,
          success: function success(res) {
            if (res.statusCode > 300) {
              if (res.statusCode === 500) {
                wx.showToast({
                  title: '系统错误，请联系管理员。',
                  icon: 'none',
                  duration: 2000
                });
              } else {
                return reject(res);
              }
            } else {
              console.log(res);
              return resolve(res);
            }
          },
          fail: function fail(err) {
            wx.showToast({
              title: '抱歉，网络错误。',
              icon: 'none',
              duration: 2000
            });
            console.log(err);
            return reject(err);
          },
          complete: function complete(e) {
            _this.onComplete();
          }
        });
      });
    }
  }]);

  return Request;
}();exports.default = {
  get: function get(url, options) {
    options.method = 'GET';
    var session = new Request(url, options);
    return session.send();
  },
  post: function post(url, options) {
    options.method = 'POST';
    var session = new Request(url, options);
    return session.send();
  },
  delete: function _delete(url, options) {
    options.method = 'DELETE';
    var session = new Request(url, options);
    return session.send();
  }
};