Object.defineProperty(exports, "__esModule", {
  value: true
});var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }var Countdown = function () {
  function Countdown() {
    _classCallCheck(this, Countdown);
  }

  _createClass(Countdown, null, [{
    key: "init",
    value: function init(endTime, countdownId, that) {
      var end = new Date(endTime).getTime();

      that.setData(_defineProperty({}, countdownId, {
        countdown: parseInt((end - new Date().getTime()) / 1000),
        day: parseInt((end - new Date().getTime()) / 1000 / 60 / 60 / 24),
        hour: parseInt((end - new Date().getTime()) / 1000 / 60 / 60 % 24),
        minute: parseInt((end - new Date().getTime()) / 1000 / 60 % 60),
        seconds: parseInt((end - new Date().getTime()) / 1000) % 60
      }));

      var interval = setInterval(function () {
        that.setData(_defineProperty({}, countdownId, {
          countdown: parseInt((end - new Date().getTime()) / 1000),
          day: parseInt((end - new Date().getTime()) / 1000 / 60 / 60 / 24),
          hour: parseInt((end - new Date().getTime()) / 1000 / 60 / 60 % 24),
          minute: parseInt((end - new Date().getTime()) / 1000 / 60 % 60),
          seconds: parseInt((end - new Date().getTime()) / 1000) % 60
        }));

        if (that.data[countdownId].countdown <= 0) {
          clearInterval(interval);
          that.setData({ seconds: 0 });
        }
      }, 1000);
    }
  }]);

  return Countdown;
}();exports.default = Countdown;