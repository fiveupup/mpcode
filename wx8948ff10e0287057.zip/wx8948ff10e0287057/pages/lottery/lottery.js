var app = getApp();Page({

  /**
   * 页面的初始数据
   */
  data: {
    previousLottery: []
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function onLoad(options) {
    var _this = this;

    this.userInfo = app.globalData.loginInfo.then(function (r) {
      return wx.req.get('info/', {});
    });
    this.currentLottery = this.selectComponent('#current-lottery');
    this.loginSheet = this.selectComponent('#login-sheet');
    this.groupAdd = this.selectComponent('#group-add');
    wx.eventBus.on('showGroupAdd', function () {
      _this.groupAdd.open();
    });
    wx.eventBus.on('closeGroupAdd', function () {
      _this.groupAdd.close();
    });
    app.globalData.loginInfo.then(function (res) {
      wx.req.get('lottery/history/', {}).then(function (r) {
        _this.setData({
          previousLottery: r.data.result
        });
      }).then(function (r) {
        console.log(options);
        if (options.scene && options.scene.startsWith('lottery')) {
          var lid = options.scene.split('_')[1];
          wx.navigateTo({
            url: '/pages/lottery/detail?id=' + lid
          });
        }
      });
    });
  },

  joinLottery: function joinLottery(e) {
    var _this2 = this;

    this.userInfo.then(function (r) {
      if (r.data.authenticated == '0') {
        _this2.next = function () {
          return _this2.joinLottery(e);
        };
        _this2.loginSheet.openSheet();
      } else {
        _this2.lotterySubscribe();
      }
    });
  },
  joinSucceeded: function joinSucceeded(e) {
    this.groupAdd.open();
  },
  lotterySubscribe: function lotterySubscribe() {
    var _this3 = this;

    app.globalData.templateLoad().then(function (r) {
      var msgs = [app.globalData.templateMessage['LOTTERY_1'], app.globalData.templateMessage['LOTTERY_2']];
      wx.eventBus.emit('showSubscribeTip');
      wx.requestSubscribeMessage({
        tmplIds: msgs,
        success: function success(res) {
          if (res.errMsg === 'requestSubscribeMessage:ok') {
            var accept = [];
            var _iteratorNormalCompletion = true;
            var _didIteratorError = false;
            var _iteratorError = undefined;

            try {
              for (var _iterator = msgs[Symbol.iterator](), _step; !(_iteratorNormalCompletion = (_step = _iterator.next()).done); _iteratorNormalCompletion = true) {
                var templateId = _step.value;

                if (res[templateId] === 'accept') {
                  accept.push(templateId);
                }
              }
            } catch (err) {
              _didIteratorError = true;
              _iteratorError = err;
            } finally {
              try {
                if (!_iteratorNormalCompletion && _iterator.return) {
                  _iterator.return();
                }
              } finally {
                if (_didIteratorError) {
                  throw _iteratorError;
                }
              }
            }

            wx.req.post('message/accept/', {
              data: {
                accept: accept
              }
            });
          }
        },
        complete: function complete(res) {
          _this3.currentLottery.join();
          wx.eventBus.emit('hideSubscribeTip');
        }
      });
    });
  },
  joinGroup: function joinGroup(e) {
    wx.previewImage({
      urls: ['https://img.newunderstand.com/qr/group-qr.jpg?v=' + Math.random()]
    });
  },
  quickLogin: function quickLogin(e) {
    var _this4 = this;

    wx.getUserProfile({
      desc: '用于设置头像和昵称',
      success: function success(res) {
        wx.showLoading({
          title: '登录中',
          icon: 'none',
          mask: true
        });
        var data = {
          avatar: res.userInfo.avatarUrl,
          nickname: res.userInfo.nickName
        };
        _this4.userInfo = wx.req.post('info/', {
          data: data
        }).then(function (r) {
          _this4.loginSheet.closeSheet();
          wx.hideLoading({});
          _this4.next();
          return r;
        });
      },
      fail: function fail(r) {
        wx.showToast({
          title: '未能登录',
          icon: 'none'
        });
      }
    });
  },


  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function onReady() {},

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function onShow(options) {},


  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function onHide() {},

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function onUnload() {},

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function onPullDownRefresh() {},

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function onReachBottom() {},

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function onShareAppMessage() {}
});