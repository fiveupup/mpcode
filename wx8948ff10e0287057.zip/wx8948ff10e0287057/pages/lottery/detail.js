var _extends = Object.assign || function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; };var app = getApp();Page({

  /**
   * 页面的初始数据
   */
  data: {
    id: '-',
    end_time: '',
    pid: '',
    prizes: [{
      "id": 67,
      "name": "🏅 一等奖：50元🧧",
      "number": 1,
      "winners": []
    }],
    "joins": {
      "joins": [],
      "count": 0
    },
    "spent": 1,
    loading: true
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function onLoad(options) {
    var _this = this;

    this.setData({
      id: options.id
    });
    app.globalData.loginInfo.then(function (res) {
      wx.req.get('lottery/' + options.id + '/result/', {}).then(function (r) {
        _this.setData(_extends({}, r.data, { loading: false }));
      });
    });
  },

  toRedPacket: function toRedPacket(e) {
    if (this.data.pid) {
      wx.navigateToMiniProgram({
        appId: 'wxaddaee51ad4aff82',
        path: '/pages/landing/landing?p=' + this.data.pid
      });
    } else {
      wx.showToast({
        title: '本期尚未开奖',
        icon: 'none'
      });
    }
  },


  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function onReady() {},

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function onShow() {},

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function onHide() {},

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function onUnload() {},

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function onPullDownRefresh() {},

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function onReachBottom() {},

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function onShareAppMessage() {}
});