var _data;function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }var app = getApp();Page({

  /**
   * 页面的初始数据
   */
  data: (_data = {
    id: 0,
    loading: true,
    users: []
  }, _defineProperty(_data, 'loading', true), _defineProperty(_data, 'page', 1), _defineProperty(_data, 'nextPage', true), _defineProperty(_data, 'loadingPage', false), _data),

  refresh: function refresh() {
    var _this = this;

    app.globalData.loginInfo.then(function (res) {
      wx.req.get('lottery/' + _this.data.id + '/users/?page=' + _this.data.page + '&pageSize=30', {}).then(function (r) {
        wx.stopPullDownRefresh({});
        _this.setData({
          users: _this.data.users.concat(r.data.results),
          loading: false,
          loadingPage: false,
          nextPage: r.data.next
        });
      });
    });
  },


  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function onLoad(options) {
    this.setData({
      id: options.id
    });
    this.refresh();
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function onReady() {},

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function onShow() {},

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function onHide() {},

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function onUnload() {},

  onPullDownRefresh: function onPullDownRefresh(e) {
    this.setData({
      users: [],
      page: 1
    });
    this.refresh();
  },
  onReachBottom: function onReachBottom(e) {
    if (!this.data.loadingPage && this.data.nextPage) {
      this.setData({
        loadingPage: true,
        page: this.data.page + 1
      });
      this.refresh();
    }
  },


  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function onShareAppMessage() {
    return {
      title: '这个小程序能把视频转成GIF！',
      path: '/pages/index/index',
      imageUrl: '/assets/share.png'
    };
  }
});