function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }var app = getApp();Page({

  /**
   * 页面的初始数据
   */
  data: {
    loading: true,
    albums: [],
    page: 1,
    nextPage: false,
    loadingPage: false
  },

  dissDot: function dissDot(e) {
    this.setData(_defineProperty({}, 'albums[' + e.currentTarget.dataset.idx + '].read', true));
  },
  onPullDownRefresh: function onPullDownRefresh(e) {
    this.setData({
      albums: [],
      page: 1
    });
    this.refresh();
  },
  refresh: function refresh() {
    var _this = this;

    app.globalData.loginInfo.then(function (res) {
      wx.req.get('album/?page=' + _this.data.page + '&pageSize=10', {}).then(function (r) {
        wx.stopPullDownRefresh({});
        _this.setData({
          loading: false,
          loadingPage: false,
          albums: _this.data.albums.concat(r.data.results),
          nextPage: r.data.next
        });
      });
    });
  },


  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function onLoad(options) {
    this.refresh();
  },


  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function onReady() {},

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function onShow() {},

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function onHide() {},

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function onUnload() {},

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function onReachBottom(e) {
    if (!this.data.loadingPage && this.data.nextPage) {
      this.setData({
        loadingPage: true,
        page: this.data.page + 1
      });
      this.refresh();
    }
  },


  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function onShareAppMessage() {}
});