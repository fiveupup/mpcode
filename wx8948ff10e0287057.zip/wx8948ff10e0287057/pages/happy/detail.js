var app = getApp();Page({

  /**
   * 页面的初始数据
   */
  data: {
    subscribeTip: false,
    loading: true,
    resources: [],
    title: '',
    date: '',
    askSubscribe: true
  },

  loadAd: function loadAd() {
    var _this = this;

    // 在页面中定义插屏广告
    this.interstitialAd = null;

    // 在页面onLoad回调事件中创建插屏广告实例
    if (wx.createInterstitialAd) {
      this.interstitialAd = wx.createInterstitialAd({
        adUnitId: 'adunit-ae04e8a117522d44'
      });
      this.interstitialAd.onLoad(function () {});
      this.interstitialAd.onError(function (err) {});
      this.interstitialAd.onClose(function () {
        clearInterval(_this.adInterval);
      });
    }
  },
  refresh: function refresh(id) {
    var _this2 = this;

    app.globalData.loginInfo.then(function (res) {
      wx.req.get('album/' + id + '/', {}).then(function (r) {
        _this2.setData({
          loading: false,
          resources: r.data.resources,
          title: r.data.title,
          date: r.data.date
        });
      });
    });
  },


  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function onLoad(options) {
    var _this3 = this;

    this.subscribeModal = this.selectComponent('#subscribe-modal');
    this.loadAd();
    this.refresh(options.id);
    this.adInterval = setInterval(function () {
      if (_this3.interstitialAd) {
        _this3.interstitialAd.show().catch(function (err) {
          console.error(err);
        });
      }
    }, 10000);
  },

  subscribe: function subscribe(e) {
    var _this4 = this;

    this.subscribeModal.close();
    app.globalData.templateLoad().then(function (r) {
      var msgs = [app.globalData.templateMessage['NEW_HAPPY']];
      _this4.setData({
        subscribeTip: true
      });
      wx.requestSubscribeMessage({
        tmplIds: msgs,
        success: function success(res) {
          if (res.errMsg === 'requestSubscribeMessage:ok') {
            var accept = [];
            var _iteratorNormalCompletion = true;
            var _didIteratorError = false;
            var _iteratorError = undefined;

            try {
              for (var _iterator = msgs[Symbol.iterator](), _step; !(_iteratorNormalCompletion = (_step = _iterator.next()).done); _iteratorNormalCompletion = true) {
                var templateId = _step.value;

                if (res[templateId] === 'accept') {
                  accept.push(templateId);
                }
              }
            } catch (err) {
              _didIteratorError = true;
              _iteratorError = err;
            } finally {
              try {
                if (!_iteratorNormalCompletion && _iterator.return) {
                  _iterator.return();
                }
              } finally {
                if (_didIteratorError) {
                  throw _iteratorError;
                }
              }
            }

            wx.req.post('message/accept/', { data: { accept: accept } });
          }
          wx.showToast({
            title: '快乐已预订！',
            icon: 'none',
            duration: 2000
          });
          _this4.setData({
            askSubscribe: false
          });
        },
        complete: function complete(res) {
          _this4.setData({
            subscribeTip: false
          });
        }
      });
    });
  },
  toIndex: function toIndex(e) {
    wx.switchTab({
      url: '/pages/index/index'
    });
  },


  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function onReady() {},

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function onShow() {
    this.subscribeModal.toggle();
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function onHide() {},

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function onUnload() {
    clearInterval(this.adInterval);
  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function onPullDownRefresh() {},

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function onReachBottom() {
    if (this.data.askSubscribe) {
      this.setData({
        askSubscribe: false
      });
      this.subscribeModal.show();
    }
  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function onShareAppMessage() {}
});