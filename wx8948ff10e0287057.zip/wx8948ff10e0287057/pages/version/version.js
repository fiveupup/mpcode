Page({

  /**
   * 页面的初始数据
   */
  data: {
    version: [],
    loading: true
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function onLoad(options) {
    var _this = this;

    wx.req.get('version/?app=p2g', {}).then(function (r) {
      _this.setData({
        version: r.data.version,
        loading: false
      });
    }).catch(function (e) {
      _this.setData({
        version: [],
        loading: false
      });
    });
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function onReady() {},

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function onShow() {},

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function onHide() {},

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function onUnload() {},

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function onPullDownRefresh() {},

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function onReachBottom() {},

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function onShareAppMessage() {
    return {
      title: '这个小程序能把图片合成GIF！',
      path: '/pages/index/index',
      imageUrl: '/assets/share.jpeg'
    };
  }
});