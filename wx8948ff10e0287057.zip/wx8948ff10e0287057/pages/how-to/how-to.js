var app = getApp();Page({

  /**
   * 页面的初始数据
   */
  data: {
    loading: true,
    howTos: [],
    page: 1,
    nextPage: false,
    loadingPage: false
  },

  onPullDownRefresh: function onPullDownRefresh(e) {
    this.setData({
      howTos: [],
      page: 1
    });
    this.getNextPage();
  },
  getNextPage: function getNextPage() {
    var _this = this;

    app.globalData.loginInfo.then(function (res) {
      wx.req.get("help/?category=p2g&page=" + _this.data.page + "&pageSize=10", {}).then(function (r) {
        wx.stopPullDownRefresh({});
        _this.setData({
          loading: false,
          loadingPage: false,
          howTos: _this.data.howTos.concat(r.data.results),
          nextPage: r.data.next
        });
      }).catch(function (e) {
        console.log(e);
        wx.stopPullDownRefresh({});
      });
    });
  },


  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function onLoad(options) {
    this.getNextPage();
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function onReady() {},

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function onShow() {},

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function onHide() {},

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function onUnload() {},

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function onReachBottom(e) {
    if (!this.data.loadingPage && this.data.nextPage) {
      this.setData({
        loadingPage: true,
        page: this.data.page + 1
      });
      this.getNextPage();
    }
  },


  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function onShareAppMessage() {}
});