var app = getApp();Page({

  /**
   * 页面的初始数据
   */
  data: {
    text: '',
    num: 0,
    subscribeTip: false,
    width: 300,
    height: 150,
    loading: true,
    src: '',
    left: 300,
    fail: false,
    showTime: 0,
    late: false,
    gid: 0,
    feed: false,
    dither: {},
    fpsOptions: [{
      value: 10,
      text: '10 FPS',
      checked: true
    }, {
      value: 20,
      text: '20 FPS',
      checked: false
    }],
    rate: 10,
    selectRate: 10,
    modalAd: null,
    resultBanner: null,
    bannerAd: null
  },

  joinGroup: function joinGroup(e) {
    wx.previewImage({
      urls: ['https://img.newunderstand.com/qr/group-qr.jpg']
    });
  },
  fpsCallback: function fpsCallback(res) {
    if (res && res.isEnded) {
      this.setData({
        rate: this.data.selectRate
      });
      this.doRebuild();
      this.toggleFPS();
    } else {
      wx.showToast({
        title: '看完广告才可以提高流畅度',
        icon: 'none'
      });
    }
  },
  sendFeed: function sendFeed(e) {
    var _this = this;

    if (this.data.feed) {
      wx.switchTab({
        url: '/pages/explore/explore'
      });
    } else {
      this.userInfo.then(function (r) {
        if (r.data.authenticated == '0') {
          _this.next = function () {
            return _this.sendFeed(e);
          };
          _this.loginSheet.openSheet();
        } else {
          _this.publishSubscribe();
        }
      });
    }
  },
  joinLottery: function joinLottery(e) {
    var _this2 = this;

    this.userInfo.then(function (r) {
      if (r.data.authenticated == '0') {
        _this2.next = function () {
          return _this2.joinLottery(e);
        };
        _this2.loginSheet.openSheet();
      } else {
        _this2.lotterySubscribe();
      }
    });
  },
  lotterySubscribe: function lotterySubscribe() {
    var _this3 = this;

    app.globalData.templateLoad().then(function (r) {
      var msgs = [app.globalData.templateMessage['LOTTERY_1'], app.globalData.templateMessage['LOTTERY_2']];
      wx.eventBus.emit('showSubscribeTip');
      wx.requestSubscribeMessage({
        tmplIds: msgs,
        success: function success(res) {
          if (res.errMsg === 'requestSubscribeMessage:ok') {
            var accept = [];
            var _iteratorNormalCompletion = true;
            var _didIteratorError = false;
            var _iteratorError = undefined;

            try {
              for (var _iterator = msgs[Symbol.iterator](), _step; !(_iteratorNormalCompletion = (_step = _iterator.next()).done); _iteratorNormalCompletion = true) {
                var templateId = _step.value;

                if (res[templateId] === 'accept') {
                  accept.push(templateId);
                }
              }
            } catch (err) {
              _didIteratorError = true;
              _iteratorError = err;
            } finally {
              try {
                if (!_iteratorNormalCompletion && _iterator.return) {
                  _iterator.return();
                }
              } finally {
                if (_didIteratorError) {
                  throw _iteratorError;
                }
              }
            }

            wx.req.post('message/accept/', {
              data: {
                accept: accept
              }
            });
          }
        },
        complete: function complete(res) {
          _this3.currentLottery = _this3.selectComponent('#current-lottery');
          _this3.currentLottery.join();
          wx.eventBus.emit('hideSubscribeTip');
        }
      });
    });
  },
  quickLogin: function quickLogin(e) {
    var _this4 = this;

    wx.getUserProfile({
      desc: '用于设置头像和昵称',
      success: function success(res) {
        wx.showLoading({
          title: '登录中',
          icon: 'none',
          mask: true
        });
        var data = {
          avatar: res.userInfo.avatarUrl,
          nickname: res.userInfo.nickName
        };
        _this4.userInfo = wx.req.post('info/', {
          data: data
        }).then(function (r) {
          _this4.loginSheet.closeSheet();
          wx.hideLoading({});
          _this4.next();
          return r;
        });
      },
      fail: function fail(r) {
        wx.showToast({
          title: '未能登录',
          icon: 'none'
        });
      }
    });
  },
  publishSubscribe: function publishSubscribe(e) {
    var _this5 = this;

    app.globalData.templateLoad().then(function (r) {
      var msgs = [app.globalData.templateMessage['NEW_COMMENT'], app.globalData.templateMessage['COMMENT_LIKE'], app.globalData.templateMessage['NEW_FEED']];
      wx.eventBus.emit('showSubscribeTip');
      wx.requestSubscribeMessage({
        tmplIds: msgs,
        success: function success(res) {
          if (res.errMsg === 'requestSubscribeMessage:ok') {
            var accept = [];
            var _iteratorNormalCompletion2 = true;
            var _didIteratorError2 = false;
            var _iteratorError2 = undefined;

            try {
              for (var _iterator2 = msgs[Symbol.iterator](), _step2; !(_iteratorNormalCompletion2 = (_step2 = _iterator2.next()).done); _iteratorNormalCompletion2 = true) {
                var templateId = _step2.value;

                if (res[templateId] === 'accept') {
                  accept.push(templateId);
                }
              }
            } catch (err) {
              _didIteratorError2 = true;
              _iteratorError2 = err;
            } finally {
              try {
                if (!_iteratorNormalCompletion2 && _iterator2.return) {
                  _iterator2.return();
                }
              } finally {
                if (_didIteratorError2) {
                  throw _iteratorError2;
                }
              }
            }

            wx.req.post('message/accept/', {
              data: {
                accept: accept
              }
            });
          }
        },
        complete: function complete(res) {
          _this5.send();
          wx.eventBus.emit('hideSubscribeTip');
        }
      });
    });
  },
  send: function send(e) {
    var _this6 = this;

    wx.showLoading({
      title: '发布中...',
      mask: true
    });
    var data = {
      text: '',
      gif: this.data.gid
    };
    wx.req.post('feed/', {
      data: data
    }).then(function (r) {
      wx.hideLoading();
      _this6.setData({
        feed: true
      });
      wx.showToast({
        title: '发布成功 👌',
        icon: 'none'
      });
    }).catch(function (e) {
      wx.hideLoading();
      wx.showToast({
        title: e.data ? e.data.error : '未知错误',
        icon: 'error'
      });
    });
  },
  share: function share(e) {
    wx.vibrateShort({
      type: 'medium'
    });
    wx.showLoading({
      title: '准备中',
      mask: true,
      success: function success(res) {
        wx.downloadFile({
          url: e.currentTarget.dataset.src.replace('http://', 'https://'),
          success: function success(res) {
            wx.hideLoading();
            wx.showShareImageMenu({
              path: res.tempFilePath
            }).catch(function (e) {
              if (e.errMsg !== 'showShareImageMenu:fail cancel') {
                wx.previewImage({
                  urls: [res.tempFilePath]
                });
              }
            });
          },
          fail: function fail(res) {
            wx.hideLoading();
            wx.showToast({
              title: '下载失败',
              icon: 'none'
            });
          }
        });
      }
    });
  },
  toLobby: function toLobby(e) {
    wx.switchTab({
      url: '/pages/pk/lobby'
    });
  },
  toHappy: function toHappy(e) {
    wx.switchTab({
      url: '/pages/happy/happy'
    });
  },
  copyCallback: function copyCallback(res) {
    if (res && res.isEnded) {
      wx.setClipboardData({
        data: this.data.src
      });
    } else {
      wx.showToast({
        title: '看完广告才可以复制链接',
        icon: 'none'
      });
    }
  },
  loadAd: function loadAd() {
    this.setData({
      resultBanner: app.globalData.ads.result_banner,
      bannerAd: app.globalData.ads.video_ad || app.globalData.ads.banner,
      modalAd: app.globalData.ads.modal_banner
    });

    // 在页面中定义插屏广告
    this.interstitialAd = null;

    // 在页面onLoad回调事件中创建插屏广告实例
    if (wx.createInterstitialAd && app.globalData.ads.interstitial) {
      this.interstitialAd = wx.createInterstitialAd({
        adUnitId: app.globalData.ads.interstitial.unit_id
      });
      this.interstitialAd.onLoad(function () {});
      this.interstitialAd.onError(function (err) {});
      this.interstitialAd.onClose(function () {});
    }

    this.videoAd = null;
    if (wx.createRewardedVideoAd && app.globalData.ads.reward_video_extra) {
      this.videoAd = wx.createRewardedVideoAd({
        adUnitId: app.globalData.ads.reward_video_extra.unit_id
      });
      this.videoAd.onLoad(function () {});
      this.videoAd.onError(function (err) {});
    }
  },
  joinSucceeded: function joinSucceeded(e) {
    this.groupAdd.open();
  },


  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function onLoad(options) {
    var _this7 = this;

    this.groupAdd = this.selectComponent('#group-add');
    this.coinAlert = this.selectComponent('#coin-alert');
    wx.eventBus.on('showCoinAlert_result', function (_ref) {
      var text = _ref.text,
          tip = _ref.tip;

      _this7.coinAlert.open(text, tip);
    });
    wx.reportAnalytics('result', {});
    this.userInfo = app.globalData.loginInfo.then(function (r) {
      return wx.req.get('info/', {});
    });
    this.loginSheet = this.selectComponent('#login-sheet');
    this.ditherInfo = this.selectComponent('#dither-info');
    this.rateModal = this.selectComponent('#rate-modal');
    this.shareModal = this.selectComponent('#share-modal');
    this.rebuildModal = this.selectComponent('#rebuild-modal');
    this.fpsModal = this.selectComponent('#fps-modal');
    this.helpModal = this.selectComponent('#how-to-save-modal');
    this.awardModal = this.selectComponent('#award-modal');
    this.setData({
      gid: options.id,
      lotteryShow: !app.globalData.adFree
    });
    app.globalData.adsLoad().then(function (r) {
      _this7.loadAd();
      _this7.checkGif();
    });
    wx.eventBus.distinctOn('showSubscribeTip', function () {
      _this7.setData({
        subscribeTip: true
      });
    });
    wx.eventBus.distinctOn('hideSubscribeTip', function () {
      _this7.setData({
        subscribeTip: false
      });
    });
  },

  checkGif: function checkGif(e) {
    var _this8 = this;

    var count = 0;
    this.checkInterval = setInterval(function () {
      if (_this8.interstitialAd) {
        _this8.interstitialAd.show().catch(function (err) {
          console.error(err);
        });
      }
      wx.req.get('gif/check/' + _this8.data.gid + '/', {}).then(function (r) {
        if (r.data.status === "1") {
          if (r.data.ticket === '0' && _this8.data.lotteryShow) {
            wx.eventBus.emit('showCoinAlert_result', {
              text: '制作成功 - 获得奖券 x 1',
              tip: '投入奖池就能抽奖领红包 🎉'
            });
          }
          _this8.setData({
            src: r.data.src,
            rate: r.data.rate,
            feed: r.data.feed,
            fpsOptions: [{
              value: 10,
              text: '10 FPS',
              checked: r.data.rate == 10
            }, {
              value: 20,
              text: '20 FPS',
              checked: r.data.rate == 20
            }],
            late: false,
            fail: false
          });
          clearInterval(_this8.checkInterval);
        } else if (r.data.status === "0") {
          _this8.setData({
            num: r.data.num
          });
          count += 1;
          if (count == 10) {
            wx.showModal({
              title: '久等了',
              content: '您的GIF已在后台处理中。\n完成后会有小程序通知给您！\n去“每日快乐源泉GIF”边看边等吗？',
              confirmText: '去看看',
              cancelText: '在此死等',
              success: function success(res) {
                if (res.confirm) {
                  wx.switchTab({
                    url: '/pages/happy/happy',
                    success: function success(res) {
                      clearInterval(_this8.checkInterval);
                    }
                  });
                }
              }
            });
            _this8.setData({
              late: true
            });
          }
        } else if (r.data.status === "-3") {
          clearInterval(_this8.checkInterval);
          _this8.setData({
            loading: false,
            fail: true,
            late: false,
            text: r.data.text,
            src: "https://mmbiz.qpic.cn/mmbiz_gif/51Eu5abWUtUO52cFlmLRdRYd8n1iagVwIJyG6kBU9A19vgMuTZiaeudFblBD9JuX9MEIpoB5dsuTc2f6N4ib3buCw/0?wx_fmt=gif",
            width: 300,
            height: 167
          });
        }
      }).catch(function (e) {
        console.log(e);
        clearInterval(_this8.checkInterval);
        _this8.setData({
          loading: false,
          fail: true,
          late: false,
          src: 'https://mmbiz.qpic.cn/mmbiz_gif/51Eu5abWUtUO52cFlmLRdRYd8n1iagVwIJyG6kBU9A19vgMuTZiaeudFblBD9JuX9MEIpoB5dsuTc2f6N4ib3buCw/0?wx_fmt=gif',
          width: 300,
          height: 167
        });
      });
    }, 2000);
  },
  previewDither: function previewDither(e) {
    wx.previewImage({
      current: e.currentTarget.dataset.src, // 当前显示图片的http链接
      urls: ['https://img.newunderstand.com/v2g/dither/dither_before.gif', 'https://img.newunderstand.com/v2g/dither/dither_after.gif'] // 需要预览的图片http链接列表
    });
  },
  preview: function preview(e) {
    wx.previewImage({
      current: this.data.src, // 当前显示图片的http链接
      urls: [this.data.src] // 需要预览的图片http链接列表
    });
  },
  loadFinished: function loadFinished(e) {
    this.setData({
      loading: false,
      width: e.detail.width,
      height: e.detail.height
    });
  },
  adClick: function adClick(e) {
    var _this9 = this;

    wx.navigateToMiniProgram({
      appId: this.data.ad.app_id,
      path: this.data.ad.link,
      success: function success(res) {
        wx.req.post('ad/' + _this9.data.ad.id + '/click/', {});
      }
    });
  },
  learMore: function learMore(e) {
    this.setData({
      dither: {
        before: 'https://img.newunderstand.com/v2g/dither/dither_before.gif',
        after: 'https://img.newunderstand.com/v2g/dither/dither_after.gif'
      }
    });
    this.ditherInfo.toggle(e);
  },
  toggleRate: function toggleRate(e) {
    this.rateModal.toggle();
    this.setData({
      showTime: 100
    });
  },
  toIndex: function toIndex(e) {
    wx.switchTab({
      url: '/pages/index/index?new=1'
    });
  },
  toggleHelp: function toggleHelp(e) {
    this.helpModal.toggle();
  },
  toggleRebuild: function toggleRebuild(e) {
    this.rebuildModal.toggle();
  },
  toggleFPS: function toggleFPS(e) {
    this.fpsModal.toggle();
  },
  selectFPS: function selectFPS(e) {
    this.setData({
      selectRate: e.detail.value
    });
  },
  submitRate: function submitRate(e) {
    if (e.detail.rate >= 4.5) {
      this.shareModal.toggle();
    } else {
      wx.showToast({
        title: '感谢，我们会尽力改正！',
        icon: 'none'
      });
    }
  },
  changeFPS: function changeFPS(e) {
    var _this10 = this;

    if (this.data.rate == this.data.selectRate) {
      this.toggleFPS();
      return;
    } else {
      // 用户触发广告后，显示激励视频广告
      if (this.videoAd) {
        this.videoAd.offClose(this.fpsCallback);
        this.videoAd.offClose(this.copyCallback);
        this.videoAd.onClose(this.fpsCallback);
        this.videoAd.load().then(function (_) {
          _this10.videoAd.show();
        }).catch(function (_) {
          wx.showModal({
            title: '免广告',
            showCancel: false,
            content: '已为您免除广告，希望您能分享支持我们！',
            confirmText: '好的',
            success: function success(res) {
              if (res.confirm) {
                _this10.setData({
                  rate: _this10.data.selectRate
                });
                _this10.rebuild();
                _this10.toggleFPS();
              }
            }
          });
        });
      } else {
        wx.showModal({
          title: '免广告',
          showCancel: false,
          content: '已为您免除广告，希望您能分享支持我们！',
          confirmText: '好的',
          success: function success(res) {
            if (res.confirm) {
              _this10.setData({
                rate: _this10.data.selectRate
              });
              _this10.rebuild();
              _this10.toggleFPS();
            }
          }
        });
      }
    }
  },
  copyUrl: function copyUrl(e) {
    var _this11 = this;

    wx.showLoading({
      title: '加载中',
      mask: true
    });

    // 用户触发广告后，显示激励视频广告
    if (this.videoAd) {
      this.videoAd.offClose(this.fpsCallback);
      this.videoAd.offClose(this.copyCallback);
      this.videoAd.onClose(this.copyCallback);
      this.videoAd.load().then(function (_) {
        _this11.videoAd.show();
      }).catch(function (_) {
        wx.showModal({
          title: '免广告',
          showCancel: false,
          content: '已为您免除广告，希望您能分享支持我们！',
          confirmText: '好的',
          success: function success(res) {
            if (res.confirm) {
              wx.setClipboardData({
                data: _this11.data.src
              });
            }
          }
        });
      });
    } else {
      wx.showModal({
        title: '免广告',
        showCancel: false,
        content: '已为您免除广告，希望您能分享支持我们！',
        confirmText: '好的',
        success: function success(res) {
          if (res.confirm) {
            wx.setClipboardData({
              data: _this11.data.src
            });
          }
        }
      });
    }
  },
  rebuild: function rebuild(e) {
    var _this12 = this;

    app.globalData.templateLoad().then(function (r) {
      var msgs = [app.globalData.templateMessage['PROCESS_DONE'], app.globalData.templateMessage['NEW_FEATURE'], app.globalData.templateMessage['NEW_HAPPY']];
      _this12.setData({
        subscribeTip: true
      });
      wx.requestSubscribeMessage({
        tmplIds: msgs,
        success: function success(res) {
          if (res.errMsg === 'requestSubscribeMessage:ok') {
            var accept = [];
            var _iteratorNormalCompletion3 = true;
            var _didIteratorError3 = false;
            var _iteratorError3 = undefined;

            try {
              for (var _iterator3 = msgs[Symbol.iterator](), _step3; !(_iteratorNormalCompletion3 = (_step3 = _iterator3.next()).done); _iteratorNormalCompletion3 = true) {
                var templateId = _step3.value;

                if (res[templateId] === 'accept') {
                  accept.push(templateId);
                }
              }
            } catch (err) {
              _didIteratorError3 = true;
              _iteratorError3 = err;
            } finally {
              try {
                if (!_iteratorNormalCompletion3 && _iterator3.return) {
                  _iterator3.return();
                }
              } finally {
                if (_didIteratorError3) {
                  throw _iteratorError3;
                }
              }
            }

            wx.req.post('message/accept/', {
              data: {
                accept: accept
              }
            });
          }
        },
        complete: function complete(res) {
          _this12.setData({
            subscribeTip: false
          });
          _this12.doRebuild();
        }
      });
    });
  },
  doRebuild: function doRebuild(e) {
    var _this13 = this;

    wx.req.post('rebuild/' + this.data.gid + '/', {
      data: {
        rate: this.data.rate
      }
    }).then(function (r) {
      _this13.setData({
        loading: true
      });
      _this13.checkGif();
    });
  },
  goHappy: function goHappy(e) {
    var _this14 = this;

    wx.switchTab({
      url: '/pages/happy/happy',
      success: function success(res) {
        clearInterval(_this14.checkInterval);
      }
    });
  },


  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function onReady() {},

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function onShow() {
    this.setData({
      showTime: this.data.showTime + 1
    });
    if (this.data.showTime == 2) {
      this.rateModal.toggle();
    }
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function onHide() {},

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function onUnload() {
    clearInterval(this.checkInterval);
  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function onPullDownRefresh() {},

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function onReachBottom() {},

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function onShareAppMessage() {
    return {
      title: '这个小程序能把图片合成GIF！',
      path: '/pages/index/index',
      imageUrl: '/assets/share.jpeg'
    };
  }
});