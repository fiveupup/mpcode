function _toConsumableArray(arr) { if (Array.isArray(arr)) { for (var i = 0, arr2 = Array(arr.length); i < arr.length; i++) { arr2[i] = arr[i]; } return arr2; } else { return Array.from(arr); } }function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }var throttle = require('../../utils/throttle');var app = getApp();Page({

  /**
   * 页面的初始数据
   */
  data: {
    feeds: [],
    paging: false,
    page: 0,
    next: true,
    loading: true,
    currentId: -1, // 正要操作的feed
    subscribeTip: false
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function onLoad(options) {
    var _this = this;

    this.coinAlert = this.selectComponent('#coin-alert');
    wx.eventBus.on('showCoinAlert_explore', function (_ref) {
      var text = _ref.text,
          tip = _ref.tip;

      _this.coinAlert.open(text, tip);
    });
    this.onLike = throttle.throttle(this._like.bind(this), 500);
    this.userInfo = this.userProfile();
    this.loginSheet = this.selectComponent('#login-sheet');
    this.commentSheet = this.selectComponent('#comment-sheet');
    this.publish = this.selectComponent('#publish');
    this.moreSheet = this.selectComponent('#more-sheet');
    wx.eventBus.on('showCommentSheet', function (_ref2) {
      var feedId = _ref2.feedId;

      _this.commentSheet.openSheet({
        feedId: feedId
      });
    });
    wx.eventBus.on('refreshPlanet', function () {
      wx.startPullDownRefresh();
    });
    wx.eventBus.distinctOn('showSubscribeTip', function () {
      _this.setData({
        subscribeTip: true
      });
    });
    wx.eventBus.distinctOn('hideSubscribeTip', function () {
      _this.setData({
        subscribeTip: false
      });
    });
    this.refresh();
  },

  refresh: function refresh(e) {
    var _this2 = this;

    this.setData({
      feeds: [],
      paging: false,
      page: 0,
      next: true,
      loading: true
    }, function () {
      _this2.getNext();
    });
  },
  getNext: function getNext() {
    var _this3 = this;

    if (!this.data.paging && this.data.next) {
      this.setData({
        page: this.data.page + 1,
        paging: true
      }, function () {
        app.globalData.loginInfo.then(function (r) {
          wx.req.get('feed/?page=' + _this3.data.page, {}).then(function (r) {
            wx.stopPullDownRefresh();

            // 为每一个feed绑定一个局部刷新事件
            var baseIndex = _this3.data.feeds.length;
            r.data.results.map(function (feed, index) {
              wx.eventBus.distinctOn('commentRefresh' + feed.id, function () {
                wx.req.get('feed/' + feed.id + '/', {}).then(function (r) {
                  var idx = index + baseIndex;
                  console.log(index, idx);
                  _this3.setData(_defineProperty({}, 'feeds[' + idx + ']', r.data));
                });
              });
            });
            _this3.setData({
              paging: false,
              next: r.data.next,
              feeds: [].concat(_toConsumableArray(_this3.data.feeds), _toConsumableArray(r.data.results)),
              loading: false
            });
          });
        });
      });
    }
  },
  _like: function _like(e) {
    var _setData;

    //不直接使用此函数，对前端用throttle的函数onLike
    var feedId = e.currentTarget.dataset.id;
    var idx = e.currentTarget.dataset.idx;
    var likeStatus = e.currentTarget.dataset.liked;
    var toLikeStatus = void 0,
        toLikeCount = void 0;
    if (likeStatus === '1') {
      app.globalData.loginInfo.then(function (res) {
        wx.req.delete('feed/' + feedId + '/like/', {});
      });
      toLikeStatus = '0';
      toLikeCount = this.data.feeds[idx].likes.count - 1;
    } else {
      app.globalData.loginInfo.then(function (res) {
        return wx.req.post('feed/' + feedId + '/like/', {});
      }).then(function (r) {
        if (r.data.ticket == '1') {
          wx.eventBus.emit('showCoinAlert_explore', { text: '点赞成功运气爆棚 - 获得奖券 x 1', tip: '投入奖池就能抽奖领红包 🎉' });
        }
      });
      toLikeStatus = '1';
      toLikeCount = this.data.feeds[idx].likes.count + 1;
    }
    this.setData((_setData = {}, _defineProperty(_setData, 'feeds[' + idx + '].likes.liked', toLikeStatus), _defineProperty(_setData, 'feeds[' + idx + '].likes.count', toLikeCount), _setData));
    this.animate('#like-' + feedId, [{
      scaleX: .8,
      scaleY: .8,
      ease: 'cubic-bezier(0.16, 0.88, 0.7, 2.17)'
    }, {
      scaleX: 1,
      scaleY: 1,
      ease: 'cubic-bezier(0.16, 0.88, 0.7, 2.17)'
    }], 300, function () {
      this.clearAnimation('#like-' + feedId, {
        scaleX: true,
        scaleY: true
      });
    }.bind(this));
  },
  openComment: function openComment(e) {
    var _this4 = this;

    this.userInfo.then(function (r) {
      if (r.data.authenticated == '0') {
        _this4.next = function () {
          return _this4.openComment(e);
        };
        _this4.loginSheet.openSheet();
      } else {
        var feedId = e.currentTarget.dataset.id;
        wx.eventBus.emit('showCommentSheet', {
          feedId: feedId
        });
      }
    });
  },
  userProfile: function userProfile() {
    return app.globalData.loginInfo.then(function (r) {
      return wx.req.get('info/', {});
    });
  },
  new: function _new(e) {
    var _this5 = this;

    this.userInfo.then(function (r) {
      if (r.data.authenticated == '0') {
        _this5.next = function () {
          return _this5.new(e);
        };
        _this5.loginSheet.openSheet();
      } else {
        _this5.showPublish();
      }
    });
  },
  showPublish: function showPublish() {
    this.publish.openPublish();
  },
  quickLogin: function quickLogin(e) {
    var _this6 = this;

    wx.getUserProfile({
      desc: '用于设置头像和昵称',
      success: function success(res) {
        wx.showLoading({
          title: '登录中',
          icon: 'none',
          mask: true
        });
        var data = {
          avatar: res.userInfo.avatarUrl,
          nickname: res.userInfo.nickName
        };
        _this6.userInfo = wx.req.post('info/', {
          data: data
        }).then(function (r) {
          _this6.loginSheet.closeSheet();
          wx.hideLoading({});
          _this6.next();
          return r;
        });
      },
      fail: function fail(r) {
        wx.showToast({
          title: '未能登录',
          icon: 'none'
        });
      }
    });
  },
  moreAction: function moreAction(e) {
    this.setData({
      currentId: e.currentTarget.dataset.id
    });
    this.moreSheet.openSheet();
  },
  deleteFeed: function deleteFeed(e) {
    var _this7 = this;

    wx.showModal({
      title: '确认',
      content: '删除这条动态？',
      success: function success(res) {
        if (res.confirm) {
          wx.showLoading({
            title: '正在删除',
            mask: true
          });
          wx.req.delete('feed/' + _this7.data.currentId + '/', {}).then(function (r) {
            wx.hideLoading({});
            _this7.onPullDownRefresh();
            _this7.moreSheet.closeSheet();
          }).catch(function (e) {
            wx.hideLoading({});
          });
        } else if (res.cancel) {
          console.log('用户点击取消');
        }
      }
    });
  },


  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function onReady() {},

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function onShow() {},

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function onHide() {},

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function onUnload() {},

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function onPullDownRefresh() {
    this.refresh();
  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function onReachBottom() {
    this.getNext();
  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function onShareAppMessage() {}
});