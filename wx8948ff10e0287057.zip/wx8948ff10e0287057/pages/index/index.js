var app = getApp();var throttle = require('../../utils/throttle');Page({
  data: {
    adFree: false,
    tip: false,
    left: 300,
    happyRandom: '',
    loading: true,
    ad: true,
    bannerAd: '',
    subscribeTip: false,
    modalAd: null
  },

  selectVideo: function selectVideo() {
    var _this = this;

    wx.reportAnalytics('make_1', {});
    wx.chooseVideo({
      sourceType: ['album', 'camera'],
      maxDuration: 60,
      camera: 'back',
      success: function success(chooseRes) {
        var videoInfo = chooseRes;
        if (videoInfo.duration >= 30) {
          wx.reportAnalytics('make_2', {});
          wx.showModal({
            title: '视频太长',
            content: '请先把视频剪到30秒以内。',
            showCancel: false,
            confirmText: '知道了',
            success: function success(modalRes) {
              wx.openVideoEditor({
                filePath: chooseRes.tempFilePath,
                success: function success(editRes) {
                  if (editRes.duration >= 30000) {
                    wx.reportAnalytics('make_fail', {});
                    wx.showModal({
                      title: '视频依然太长',
                      content: '请重新选择视频'
                    });
                  } else {
                    videoInfo.duration = editRes.duration / 1000;
                    videoInfo.tempFilePath = editRes.tempFilePath;
                    _this.toCrop(videoInfo);
                  }
                }
              });
            }
          });
        } else {
          _this.toCrop(videoInfo);
        }
      }
    });
  },
  select: function select(e) {
    var text = app.globalData.ads.crop_reward_video ? 'GIF将在您观看视频广告后生成，感谢您的支持！' : '';
    wx.reportAnalytics('make_0', {});
    this.startModal.show({
      title: '完全免费生成GIF',
      content: '更多功能开发中，敬请期待...' + text
    });
  },
  toCrop: function toCrop(videoInfo) {
    this.startModal.close();
    wx.reportAnalytics('make_success', {});
    // wx.compressVideo({
    //   src: videoInfo.tempFilePath,
    //   quality: 'medium',
    //   success: compressRes => {
    //     console.log(compressRes)
    //     videoInfo.tempFilePath = compressRes.tempFilePath
    //     videoInfo.size = compressRes.size
    wx.navigateTo({
      url: '/pages/crop/crop',
      success: function success(res) {
        console.log(videoInfo);
        res.eventChannel.emit('videoInfo', videoInfo);
      }
    });
    //   }
    // })
  },
  v2g: function v2g(e) {
    wx.navigateToMiniProgram({
      appId: 'wx13f97a38efb4ac86',
      path: '/pages/index/index'
    });
  },
  screen: function screen(e) {
    wx.showToast({
      title: '开发中，敬请期待！',
      icon: 'none'
    });
  },
  watermark: function watermark(e) {
    wx.navigateToMiniProgram({
      appId: 'wx7cb0131e79d3c4cf',
      path: '/pages/index/index'
    });
  },
  meituan: function meituan(e) {
    wx.reportAnalytics('food', {
      key: 'meituan1'
    });
    wx.navigateToMiniProgram({
      appId: 'wxde8ac0a21135c07d',
      path: '/index/pages/h5/h5?weburl=https%3A%2F%2Fclick.meituan.com%2Ft%3Ft%3D1%26c%3D1%26p%3DOWMpZ-uzIFOVe6JyOONs3dXuqV0qcAf-r-KCvHdXiNfKvOfRwPhGa-0dURUoMDcktM05nEBz5Is7-Q0-XfYlz4d3tWaNhX8Ihz0HsL3b8NgIgXpOsbi7lUiuFGUgQnO8tGXaC79zALTK-vQnEUJX0cgnRanFPuRWLJKyMYauy1U67rTMSQKvp6DcJ-3g29J2jKUaxVOVZgi1nvDCfQBzojB6s9rgjDpZQ7j8mVlXC_26oXfHyNq0gSPii8G32zasR5d_OZ4TGKpX76fGZ8kPfcZmoVUlVt2dBDGUzr3HZaZXF_I06J7Mjzje0pQ7wzoMyZs7cKDjf93m71UKbVpVKf6e5zRyuJhQdkX0WlzxAVH1V8PO3tgKeWSMREbnEiSXMD4zFUUIe19H78lTpURq0e8jR_PHHteTKRgNM2B0nxf4tiVtBEzROhBlfQ7oi60EUFFCX6XPJ7J5HkIdjSXt4WBOubcSicOUcsYe0X2bFaB-APwrMW9AMpBz6xId8p8p1Yszol8XAZzputHVGpin1-hKYR8KH8gJFXoqe_8sq_DHd4RlW9BD_kmJQML9OGFr8svVDfOxA5cGxjHcLF-n0keocQxAu0UzXj8iF9BbMn1emICGrQc7gij-0QkDInYqdja_rorveqQtfqBQrjnJSSHuFBo9aY4LHFSZ9EBmfEE&lch=cps:waimai:5:5befccecd088d2e0284b5a9f3dbb2bf8:ad&f_token=1&f_userId=1'
    });
  },
  meituan2: function meituan2(e) {
    wx.reportAnalytics('food', {
      key: 'meituan2'
    });
    wx.navigateToMiniProgram({
      appId: 'wx2c348cf579062e56',
      path: 'outer_packages/r2xinvite/coupon/coupon?inviteCode=NnOIp-QOs8SiYF1dcSlL5r8phPrCf6qkH7evMyjIoup2NXxNCLYcBbd3bqpv2X2IhxW95LhZkeGNPmKds31o8eD1X_63d94UmfPSTSDjLsx7g-cTFzuwASO8LpWe4rBcRVjkYzKLMlgv1xejkWHjIT6LxRosvayY54gMXZArjXY'
    });
  },
  eleme: function eleme(e) {
    wx.reportAnalytics('food', {
      key: 'eleme1'
    });
    wx.navigateToMiniProgram({
      appId: 'wxece3a9a4c82f58c9',
      path: 'pages/sharePid/web/index?scene=https://s.click.ele.me/bfsgrnu'
    });
  },
  eleme2: function eleme2(e) {
    wx.reportAnalytics('food', {
      key: 'eleme2'
    });
    wx.navigateToMiniProgram({
      appId: 'wxece3a9a4c82f58c9',
      path: 'ele-recommend-price/pages/guest/index?chInfo=ch_wechat_chsub_Card&_ltracker_f=&inviterId=e7948b'
    });
  },
  loadAd: function loadAd() {
    var _this2 = this;

    this.setData({
      bannerAd: app.globalData.ads.banner,
      modalAd: app.globalData.ads.modal_banner
    });
    // 在页面onLoad回调事件中创建插屏广告实例
    if (wx.createInterstitialAd && app.globalData.ads.index_interstitial) {
      this.interstitialAd = wx.createInterstitialAd({
        adUnitId: app.globalData.ads.index_interstitial
      });
      this.interstitialAd.onLoad(function () {});
      this.interstitialAd.onError(function (err) {});
      this.interstitialAd.onClose(function () {
        _this2.setData({
          ad: false
        });
      });
      setInterval(function () {
        if (_this2.interstitialAd && _this2.data.ad) {
          _this2.interstitialAd.show().catch(function (err) {
            console.error(err);
          });
        }
      }, 1000);
    }
  },
  joinGroup: function joinGroup(e) {
    wx.previewImage({
      urls: ['https://img.newunderstand.com/qr/group-qr.jpg']
    });
  },
  firstLogin: function firstLogin(e) {
    var _this3 = this;

    app.globalData.loginInfo.then(function (r) {
      if (r.first_login && !_this3.data.adFree) {
        wx.eventBus.emit('showCoinAlert_index', { text: '每日首次登录 - 获得奖券 x 1', tip: '投入奖池就能抽奖领红包 🎉' });
      }
    });
  },
  onLoad: function onLoad(options) {
    var _this4 = this;

    app.globalData.loginInfo.then(function (r) {
      return wx.req.get('settings/', {});
    }).then(function (r) {
      _this4.setData({
        settings: r.data
      });
    });
    this.imageChoose = this.selectComponent('#image-choose-sheet');
    this.groupAdd = this.selectComponent('#group-add');
    wx.eventBus.on('showGroupAdd', function () {
      _this4.groupAdd.open();
    });
    wx.eventBus.on('closeGroupAdd', function () {
      _this4.groupAdd.close();
    });
    this.setData({ adFree: !!options.adFree });
    this.coinAlert = this.selectComponent('#coin-alert');
    wx.eventBus.on('showCoinAlert_index', function (_ref) {
      var text = _ref.text,
          tip = _ref.tip;

      _this4.coinAlert.open(text, tip);
    });
    this.firstLogin();
    this.userInfo = app.globalData.loginInfo.then(function (r) {
      return wx.req.get('info/', {});
    });
    this.currentLottery = this.selectComponent('#current-lottery');
    this.loginSheet = this.selectComponent('#login-sheet');
    app.globalData.adsLoad().then(function (r) {
      _this4.loadAd();
    });

    var _wx$getMenuButtonBoun = wx.getMenuButtonBoundingClientRect(),
        left = _wx$getMenuButtonBoun.left;

    this.setData({
      left: left + 10
    });
    this.startModal = this.selectComponent('#start-modal');
  },
  joinLottery: function joinLottery(e) {
    var _this5 = this;

    this.userInfo.then(function (r) {
      if (r.data.authenticated == '0') {
        _this5.next = function () {
          return _this5.joinLottery(e);
        };
        _this5.loginSheet.openSheet();
      } else {
        _this5.lotterySubscribe();
      }
    });
  },
  joinSucceeded: function joinSucceeded(e) {
    this.groupAdd.open();
  },
  lotterySubscribe: function lotterySubscribe() {
    var _this6 = this;

    app.globalData.templateLoad().then(function (r) {
      var msgs = [app.globalData.templateMessage['LOTTERY_1'], app.globalData.templateMessage['LOTTERY_2']];
      wx.eventBus.emit('showSubscribeTip');
      wx.requestSubscribeMessage({
        tmplIds: msgs,
        success: function success(res) {
          if (res.errMsg === 'requestSubscribeMessage:ok') {
            var accept = [];
            var _iteratorNormalCompletion = true;
            var _didIteratorError = false;
            var _iteratorError = undefined;

            try {
              for (var _iterator = msgs[Symbol.iterator](), _step; !(_iteratorNormalCompletion = (_step = _iterator.next()).done); _iteratorNormalCompletion = true) {
                var templateId = _step.value;

                if (res[templateId] === 'accept') {
                  accept.push(templateId);
                }
              }
            } catch (err) {
              _didIteratorError = true;
              _iteratorError = err;
            } finally {
              try {
                if (!_iteratorNormalCompletion && _iterator.return) {
                  _iterator.return();
                }
              } finally {
                if (_didIteratorError) {
                  throw _iteratorError;
                }
              }
            }

            wx.req.post('message/accept/', {
              data: {
                accept: accept
              }
            });
          }
        },
        complete: function complete(res) {
          _this6.currentLottery.join();
          wx.eventBus.emit('hideSubscribeTip');
        }
      });
    });
  },
  quickLogin: function quickLogin(e) {
    var _this7 = this;

    wx.getUserProfile({
      desc: '用于设置头像和昵称',
      success: function success(res) {
        wx.showLoading({
          title: '登录中',
          icon: 'none',
          mask: true
        });
        var data = {
          avatar: res.userInfo.avatarUrl,
          nickname: res.userInfo.nickName
        };
        _this7.userInfo = wx.req.post('info/', {
          data: data
        }).then(function (r) {
          _this7.loginSheet.closeSheet();
          wx.hideLoading({});
          _this7.next();
          return r;
        });
      },
      fail: function fail(r) {
        wx.showToast({
          title: '未能登录',
          icon: 'none'
        });
      }
    });
  },
  onShow: function onShow() {
    var _this8 = this;

    wx.eventBus.distinctOn('showSubscribeTip', function () {
      _this8.setData({
        subscribeTip: true
      });
    });
    wx.eventBus.distinctOn('hideSubscribeTip', function () {
      _this8.setData({
        subscribeTip: false
      });
    });
  },
  onShareAppMessage: function onShareAppMessage(_ref2) {
    var from = _ref2.from,
        target = _ref2.target,
        webViewUrl = _ref2.webViewUrl;

    if (from === 'button' && target.dataset.share === 'food') {
      return {
        title: '饭前领取美团·饿了么外卖红包！【4个红包待领取】',
        path: "/pages/index/index",
        imageUrl: '/assets/food.jpg'
      };
    }
    return {
      title: '图片 → GIF',
      path: "/pages/index/index",
      imageUrl: '/assets/share.jpeg'
    };
  },
  addImage: function addImage(e) {
    this.imageChoose.openSheet();
  },
  chooseFromAlbum: function chooseFromAlbum(e) {
    this.imageChoose.closeSheet();
    wx.chooseImage({
      count: 20,
      sizeType: ['compressed'],
      sourceType: ['album', 'camera']
    }).then(function (r) {
      wx.navigateTo({
        url: '/pages/make/make',
        success: function success(res) {
          res.eventChannel.emit('imageInfo', r);
        }
      });
    });
  },
  chooseFromConversation: function chooseFromConversation(e) {
    this.imageChoose.closeSheet();
    wx.chooseMessageFile({
      count: 20,
      type: 'image'
    }).then(function (r) {
      wx.navigateTo({
        url: '/pages/make/make',
        success: function success(res) {
          res.eventChannel.emit('imageInfo', r);
        }
      });
    });
  },
  linkTap: function linkTap(e) {
    var link = e.currentTarget.dataset.link;
    wx.reportAnalytics('link', {
      title: link.title
    });
    if (link.status == '-1') {
      wx.showToast({
        title: '开发中，敬请期待！',
        icon: 'none'
      });
      return;
    }
    wx.vibrateShort({
      type: 'medium'
    });
    wx.navigateToMiniProgram({
      appId: link.appid,
      path: link.path
    });
  },
  test: function test(e) {
    wx.previewImage({
      urls: ['https://img.newunderstand.com/qr/group-qr.jpg', 'https://img.newunderstand.com/qr/mini-qr-2.jpg', 'https://img.newunderstand.com/qr/mini-qr.jpg', 'https://img.newunderstand.com/qr/namecard.jpeg']
    });
  }
});