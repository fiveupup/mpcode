var app = getApp();Page({

  /**
   * 页面的初始数据
   */
  data: {
    version: '',
    workCount: 0,
    subscribeTip: false
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function onLoad(options) {
    var _this = this;

    app.globalData.templateLoad();
    var info = wx.getAccountInfoSync();
    this.setData({
      version: info.miniProgram.version
    });
    wx.req.get('account/', {}).then(function (res) {
      _this.setData({
        workCount: res.data.cnt
      });
    });
  },

  updateSubscribe: function updateSubscribe(e) {
    var _this2 = this;

    app.globalData.templateLoad().then(function (r) {
      var msgs = [app.globalData.templateMessage['NEW_FEATURE']];
      _this2.setData({
        subscribeTip: true
      });
      wx.requestSubscribeMessage({
        tmplIds: msgs,
        success: function success(res) {
          if (res.errMsg === 'requestSubscribeMessage:ok') {
            var accept = [];
            var _iteratorNormalCompletion = true;
            var _didIteratorError = false;
            var _iteratorError = undefined;

            try {
              for (var _iterator = msgs[Symbol.iterator](), _step; !(_iteratorNormalCompletion = (_step = _iterator.next()).done); _iteratorNormalCompletion = true) {
                var templateId = _step.value;

                if (res[templateId] === 'accept') {
                  accept.push(templateId);
                }
              }
            } catch (err) {
              _didIteratorError = true;
              _iteratorError = err;
            } finally {
              try {
                if (!_iteratorNormalCompletion && _iterator.return) {
                  _iterator.return();
                }
              } finally {
                if (_didIteratorError) {
                  throw _iteratorError;
                }
              }
            }

            wx.req.post('message/accept/', { data: { accept: accept } });
          }
          wx.navigateTo({
            url: '/pages/version/version'
          });
        },
        complete: function complete(res) {
          _this2.setData({
            subscribeTip: false
          });
        }
      });
    });
  },
  onContactBack: function onContactBack(e) {
    wx.navigateTo({
      url: e.detail.path
    });
  },
  reward: function reward(e) {
    wx.previewImage({
      current: '/assets/award.jpeg', // 当前显示图片的http链接
      urls: ['/assets/award.jpeg'] // 需要预览的图片http链接列表
    });
  },


  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function onReady() {},

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function onShow() {},

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function onHide() {},

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function onUnload() {},

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function onPullDownRefresh() {},

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function onReachBottom() {},

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function onShareAppMessage(e) {
    return {
      title: '图片 → GIF',
      path: '/pages/index/index',
      imageUrl: '/assets/share.jpeg'
    };
  }
});