var app = getApp();Page({
  /**
   * 页面的初始数据
   */
  data: {
    formData: {},
    modalAd: null,
    superBanner: {
      ad: null,
      ready: false
    },
    adCountDown: 10,
    queueCountDown: 999,
    ad2make: false // 是否需要看广告才能制作 决定了生成按钮的样式
  },

  countDown: function countDown() {
    var _this = this;

    app.globalData.settingsLoad().then(function (r) {
      _this.setData({
        queueCountDown: app.globalData.settings.queue_time
      });
      _this.queueInterval = setInterval(function () {
        if (_this.data.queueCountDown - 1 <= 0) {
          clearInterval(_this.queueInterval);
          _this.submit();
        }
        _this.setData({
          queueCountDown: _this.data.queueCountDown - 1
        });
      }, 1000);
    });
  },
  submit: function submit() {
    this.toast.show({
      duration: 30000
    });
    wx.req.post("submit/p2g/", {
      data: this.data.formData
    }).then(function (res) {
      wx.redirectTo({
        url: "/pages/result/result?id=" + res.data.id
      });
    });
  },
  onUnload: function onUnload() {
    this.adInterval && clearInterval(this.adInterval);
    this.queueInterval && clearInterval(this.queueInterval);
  },
  loadAd: function loadAd() {
    this.videoAd = null;
    if (wx.createRewardedVideoAd && app.globalData.ads.reward_video) {
      this.setData({
        ad2make: true
      });
      this.videoAd = wx.createRewardedVideoAd({
        adUnitId: app.globalData.ads.reward_video.unit_id
      });
      this.videoAd.onClose(this.adCallback);
      this.videoAd.onLoad(function () {});
      this.videoAd.onError(function (err) {});
    }
    // 在页面onLoad回调事件中创建插屏广告实例
    if (wx.createInterstitialAd && app.globalData.ads.interstitial) {
      this.interstitialAd = wx.createInterstitialAd({
        adUnitId: app.globalData.ads.interstitial.unit_id
      });
      this.interstitialAd.onLoad(function () {});
      this.interstitialAd.onError(function (err) {});
      this.interstitialAd.onClose(function () {});
    }

    // 在适合的场景显示插屏广告
    if (this.interstitialAd) {
      this.interstitialAd.show().catch(function (err) {
        console.error(err);
      });
    }

    if (app.globalData.ads.super_banner) {
      this.setData({
        "superBanner.ad": app.globalData.ads.super_banner
      });
    }

    if (app.globalData.ads.video_ad) {
      this.setData({
        video_ad: app.globalData.ads.video_ad
      });
    }
  },
  adCallback: function adCallback(res) {
    if (res && res.isEnded) {
      wx.hideLoading();
      this.setData({
        queueCountDown: 0
      });
    } else {
      wx.showToast({
        title: "看完广告才可以免除排队~",
        icon: "none"
      });
    }
  },


  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function onLoad(options) {
    var _this2 = this;

    var eventChannel = this.getOpenerEventChannel();
    eventChannel.on("passFormData", function (data) {
      console.log(data);
      _this2.setData({
        formData: data
      });
    });
    this.adModal = this.selectComponent("#ad-modal");
    this.toast = this.selectComponent("#toast");
    this.countDown();
    app.globalData.adsLoad().then(function (r) {
      _this2.loadAd();
    });
  },


  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function onReady() {},

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function onShow() {
    var _this3 = this;

    if (this.data.superBanner.ready) {
      if (this.data.adCountDown > 0) {
        wx.showModal({
          title: "未完成浏览",
          showCancel: false,
          content: "抱歉，跳转浏览时间不足10秒，免费不易，还请支持。",
          confirmText: "再点一次",
          success: function success(res) {
            _this3.resetAdCountDown();
          }
        });
      } else {
        this.adModal.close();
        this.setData({
          queueCountDown: 0
        });
      }
    }
  },
  resetAdCountDown: function resetAdCountDown() {
    var _this4 = this;

    this.adInterval && clearInterval(this.adInterval);
    this.setData({
      adCountDown: 10
    });
    this.adInterval = setInterval(function () {
      if (_this4.data.adCountDown < 0) {
        clearInterval(_this4.adInterval);
      } else {
        _this4.setData({
          adCountDown: _this4.data.adCountDown - 1
        });
      }
    }, 1000);
  },
  showAd: function showAd() {
    var _this5 = this;

    if (this.data.superBanner.ad) {
      // 优先使用banner广告
      this.adModal.show({ title: "免除了视频广告" });
      this.resetAdCountDown();
      this.setData({
        "superBanner.ready": true
      });
    } else if (this.videoAd) {
      this.videoAd.load().then(function (_) {
        _this5.videoAd.show();
      }).catch(function (_) {
        // 如果无法加载广告
        wx.showToast({
          title: "暂无广告，请等待",
          icon: "none"
        });
      });
    } else {
      wx.showToast({
        title: "无广告可播放",
        icon: "none"
      });
    }
  },
  onSuperBannerModalClose: function onSuperBannerModalClose(e) {
    this.setData({
      "superBanner.ready": false
    });
  },


  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function onHide() {},
  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function onPullDownRefresh() {},

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function onReachBottom() {},

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function onShareAppMessage() {}
});