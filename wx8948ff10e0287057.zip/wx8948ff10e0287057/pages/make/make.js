var _extends = Object.assign || function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; };function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }var COS = require("../../utils/cos-wx-sdk-v5");var throttle = require("../../utils/throttle");var app = getApp();Page({
  /**
   * 页面的初始数据
   */
  data: {
    images: [],
    player: {
      duration: 1000,
      current: 0
    },
    currentImageIdx: 0,
    initTime: 0,
    subtitles: [],
    currentSubtitle: {
      index: -1,
      text: "",
      startTime: 0,
      endTime: 0,
      x: 0,
      y: 0,
      size: 20
    },
    trickyAd: "",
    trickyShow: false,
    step: 1,
    currentPercent: 0,
    currentProgress: 0,
    key: "",
    videoSrc: "",
    uploadPercent: 0,
    maxScale: 3,
    maxTime: 20,
    topOffset: 100,
    rightOffset: 100,
    bottomOffset: 100,
    leftOffset: 100,
    maskOpacity: 1,
    startTime: 0,
    endTime: 0,
    table: {
      x: 0,
      y: 0,
      w: 0,
      h: 0,
      maxWidth: 0,
      maxHeight: 0
    },
    changing: "", // 记录哪个角正在被拖动
    subscribeTip: false,
    modalAd: null,
    superBanner: {
      ad: "",
      ready: false
    },
    ad2make: false // 是否需要看广告才能制作 决定了生成按钮的样式
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function onLoad(options) {
    var _this = this;

    this.step1Modal = this.selectComponent("#step-1-modal");
    this.step1Modal.show({ title: "使用说明" });
    this.adModal = this.selectComponent("#ad-modal");
    this.imageChoose = this.selectComponent("#image-choose-sheet");
    this.imageSheet = this.selectComponent("#image-sheet");
    this.submit = throttle.throttle(this._submit.bind(this), 5000);
    this.finalSubmit = throttle.throttle(this._finalSubmit.bind(this), 2000);
    app.globalData.adsLoad().then(function (r) {
      _this.loadAd();
    });
    app.globalData.loginInfo.then(function (res) {
      console.log("got Info");
      _this.setData({
        loading: false
      });
    });
    this.toast = this.selectComponent("#toast");
  },

  imageTap: function imageTap(e) {
    var idx = e.currentTarget.dataset.idx;
    this.setData({
      currentImageIdx: idx
    });
    this.imageSheet.openSheet();
  },
  move: function move(arr, fromIndex, toIndex) {
    //如果当前元素在拖动目标位置的下方，先将当前元素从数组拿出，数组长度-1，我们直接给数组拖动目标位置的地方新增一个和当前元素值一样的元素，
    //我们再把数组之前的那个拖动的元素删除掉，所以要len+1
    if (fromIndex > toIndex) {
      arr.splice(toIndex, 0, arr[fromIndex]);
      arr.splice(fromIndex + 1, 1);
    } else {
      //如果当前元素在拖动目标位置的上方，先将当前元素从数组拿出，数组长度-1，我们直接给数组拖动目标位置+1的地方新增一个和当前元素值一样的元素，
      //这时，数组len不变，我们再把数组之前的那个拖动的元素删除掉，下标还是index
      arr.splice(toIndex + 1, 0, arr[fromIndex]);
      arr.splice(fromIndex, 1);
    }
    return arr;
  },
  moveForwardImage: function moveForwardImage(e) {
    var _this2 = this;

    if (this.data.currentImageIdx === 0) {
      wx.showToast({
        title: "已经是第一张了",
        icon: "none"
      });
      return;
    }
    (function () {
      if (_this2.data.currentImageIdx === 1) {
        return wx.showModal({
          title: "注意",
          content: "将移动这张图到第一张，画板尺寸可能会改变，所有图片将以它的尺寸为准。",
          confirmText: "确认移动"
        });
      } else {
        return Promise.resolve({
          confirm: true
        });
      }
    })().then(function (r) {
      if (r.confirm) {
        var newImages = _this2.move(_this2.data.images, _this2.data.currentImageIdx, _this2.data.currentImageIdx - 1);
        _this2.setData({
          images: newImages
        });
      } else {
        return Promise.reject("cancel");
      }
    }).then(function (r) {
      if (_this2.data.currentImageIdx === 1) {
        var newImages = _this2.data.images;
        _this2.setData({
          images: []
        });
        console.log(newImages);
        _this2.resetCanvas(newImages[0].width, newImages[0].height).then(function (r) {
          return _this2.getInfo(newImages);
        });
      }
      _this2.imageSheet.closeSheet();
    });
  },
  moveBackwardImage: function moveBackwardImage(e) {
    var _this3 = this;

    if (this.data.currentImageIdx === this.data.images.length - 1) {
      wx.showToast({
        title: "已经是最后一张了",
        icon: "none"
      });
      return;
    }
    (function () {
      if (_this3.data.currentImageIdx === 0) {
        return wx.showModal({
          title: "注意",
          content: "将移动第一张图，画板尺寸可能会改变，所有图片将以新的第一张图（画板）的尺寸为准。",
          confirmText: "确认移动"
        });
      } else {
        return Promise.resolve({
          confirm: true
        });
      }
    })().then(function (r) {
      if (r.confirm) {
        var newImages = _this3.move(_this3.data.images, _this3.data.currentImageIdx, _this3.data.currentImageIdx + 1);
        _this3.setData({
          images: newImages
        });
      } else {
        return Promise.reject("cancel");
      }
    }).then(function (r) {
      if (_this3.data.currentImageIdx === 0) {
        var newImages = _this3.data.images;
        _this3.setData({
          images: []
        });
        console.log(newImages);
        _this3.resetCanvas(newImages[0].width, newImages[0].height).then(function (r) {
          return _this3.getInfo(newImages);
        });
      }
      _this3.imageSheet.closeSheet();
    });
  },
  deleteImage: function deleteImage(e) {
    if (this.data.images.length <= 1) {
      wx.showToast({
        title: "至少留一张图",
        icon: "none"
      });
      return;
    }
    this.data.images.splice(this.data.currentImageIdx, 1);
    this.setData({
      images: this.data.images
    });
    this.imageSheet.closeSheet();
  },
  addImage: function addImage(e) {
    this.imageChoose.openSheet();
  },
  chooseFromAlbum: function chooseFromAlbum(e) {
    var _this4 = this;

    this.imageChoose.closeSheet();
    wx.chooseImage({
      count: 20,
      sizeType: ["compressed"],
      sourceType: ["album", "camera"]
    }).then(function (r) {
      _this4.getInfo(r.tempFiles);
    });
  },
  getInfo: function getInfo(tmpFiles) {
    var _this5 = this;

    return tmpFiles.reduce(function (previous, item, index) {
      return previous.then(function (r) {
        if (item.src) {
          return _this5.pushImage(item);
        } else {
          var path = item.path;
          wx.getImageInfo({
            src: path
          }).then(function (infoRes) {
            var width = infoRes.width;
            var height = infoRes.height;
            return _this5.pushImage({ path: path, width: width, height: height });
          });
        }
      });
    }, Promise.resolve(1));
  },
  chooseFromConversation: function chooseFromConversation(e) {
    var _this6 = this;

    this.imageChoose.closeSheet();
    wx.chooseMessageFile({
      count: 20,
      type: "image"
    }).then(function (r) {
      return _this6.getInfo(r.tempFiles);
    });
  },
  upload: function upload(imageInfo) {
    var _this7 = this;

    var Bucket = "ttc-1254401658";
    var Region = "ap-beijing";
    // 初始化实例
    var cos = new COS({
      getAuthorization: function getAuthorization(options, callback) {
        // 异步获取签名
        wx.request({
          url: "https://v2g.ent.newunderstand.com/api/upload/auth/?p=p2g", // 步骤二提供的签名接口
          data: {
            Method: options.Method,
            Key: options.Key
          },
          dataType: "json",
          success: function success(result) {
            var data = result.data;
            var credentials = data && data.credentials;
            if (!data || !credentials) return console.error("credentials invalid");
            callback({
              TmpSecretId: credentials.tmpSecretId,
              TmpSecretKey: credentials.tmpSecretKey,
              XCosSecurityToken: credentials.sessionToken,
              StartTime: data.startTime, // 时间戳，单位秒，如：1580000000，建议返回服务器时间作为签名的开始时间，避免用户浏览器本地时间偏差过大导致签名错误
              ExpiredTime: data.expiredTime // 时间戳，单位秒，如：1580000900
            });
          }
        });
      }
    });
    var path = imageInfo.src;
    var now = new Date();
    var key = "p2g/" + now.getFullYear() + "/" + (now.getMonth() + 1) + "/" + now.getDate() + "/" + this.randomString(16) + path.substr(path.lastIndexOf("."));
    imageInfo.key = key;
    cos.postObject({
      Bucket: Bucket,
      Region: Region,
      Key: key,
      FilePath: path,
      onProgress: function onProgress(info) {
        console.log("info", info);
        _this7.data.images.forEach(function (e, idx) {
          if (e.key === imageInfo.key) {
            _this7.setData(_defineProperty({}, "images[" + idx + "].percent", info.percent * 100));
            return;
          }
        });
      }
    }, function (err, data) {
      if (err) {
        wx.showModal({
          title: "上传失败",
          content: "由于网络原因，视频上传失败，请重新制作。错误信息：" + err,
          success: function success(res) {
            wx.switchTab({
              url: "/pages/index/index"
            });
          }
        });
      }
      console.log(err || data);
    });
    return key;
  },
  pushImage: function pushImage(imageData) {
    var imageInfo = void 0;
    if (imageData.src) {
      imageInfo = _extends({}, imageData, this.calcPosition(imageData.originalWidth, imageData.originalHeight));
    } else {
      imageInfo = _extends({}, this.calcPosition(imageData.width, imageData.height), {
        src: imageData.path,
        scale: 1,
        percent: 0,
        key: ""
      });
      var key = this.upload(imageInfo);
      imageInfo.key = key;
    }
    this.data.images.push(imageInfo);
    this.setData({
      images: this.data.images
    });
  },
  resetCanvas: function resetCanvas(width, height) {
    var imageWidth = void 0,
        imageHeight = void 0,
        x = void 0,
        y = void 0;
    if (width / this.data.table.maxWidth > height / this.data.table.maxHeight) {
      imageWidth = this.data.table.maxWidth;
      imageHeight = this.data.table.maxWidth / width * height;
      x = 30;
      y = Math.round((this.data.table.h - imageHeight) / 2);
    } else {
      imageHeight = this.data.table.maxHeight;
      imageWidth = this.data.table.maxHeight / height * width;
      y = 30;
      x = Math.round((this.data.table.w - imageWidth) / 2);
    }
    this.setData({
      topOffset: y,
      rightOffset: x,
      bottomOffset: y,
      leftOffset: x
    });
    return Promise.resolve(1);
  },
  calcPosition: function calcPosition(width, height) {
    var frameWidth = this.data.table.w - 2 * this.data.leftOffset,
        frameHeight = this.data.table.h - 2 * this.data.topOffset;
    var imageWidth = frameWidth,
        imageHeight = frameHeight;
    var top = 0,
        left = 0;

    if (width / frameWidth > height / frameHeight) {
      imageWidth = frameWidth;
      imageHeight = frameWidth / width * height;
      top = Math.round((frameHeight - imageHeight) / 2);
    } else {
      imageHeight = frameHeight;
      imageWidth = frameHeight / height * width;
      left = Math.round((frameWidth - imageWidth) / 2);
    }
    return {
      originalWidth: width,
      originalHeight: height,
      height: Math.round(imageHeight),
      width: Math.round(imageWidth),
      x: left,
      y: top
    };
  },
  play: function play() {
    var _this8 = this;

    if (this.data.player.interval) clearInterval(this.data.player.interval);
    this.setData({
      "player.current": 0,
      "player.interval": setInterval(function () {
        _this8.setData({
          "player.current": _this8.data.player.current >= _this8.data.images.length - 1 ? 0 : _this8.data.player.current + 1
        });
      }, this.data.player.duration)
    });
  },
  speedTouchEnd: function speedTouchEnd(e) {
    this.setData({
      "player.duration": e.detail.value * 1000
    });
    this.play();
  },
  resetSpeed: function resetSpeed(e) {
    this.setData({
      "player.duration": 1000
    });
    this.play();
  },
  speedTouchMove: function speedTouchMove(e) {
    this.setData({
      "player.duration": e.detail.value * 1000
    });
  },
  adCallback: function adCallback(res) {
    if (res && res.isEnded) {
      wx.hideLoading();
      this.submit();
    } else {
      wx.showToast({
        title: "看完广告才可以制作哦~",
        icon: "none"
      });
    }
  },
  _finalSubmit: function _finalSubmit(e) {
    var _this9 = this;

    wx.reportAnalytics("final_submit", {});
    wx.vibrateShort();
    app.globalData.templateLoad().then(function (r) {
      var msgs = [app.globalData.templateMessage["PROCESS_DONE"], app.globalData.templateMessage["NEW_FEATURE"], app.globalData.templateMessage["NEW_HAPPY"]];
      _this9.setData({
        subscribeTip: true
      });
      wx.requestSubscribeMessage({
        tmplIds: msgs,
        success: function success(res) {
          if (res.errMsg === "requestSubscribeMessage:ok") {
            var accept = [];
            var _iteratorNormalCompletion = true;
            var _didIteratorError = false;
            var _iteratorError = undefined;

            try {
              for (var _iterator = msgs[Symbol.iterator](), _step; !(_iteratorNormalCompletion = (_step = _iterator.next()).done); _iteratorNormalCompletion = true) {
                var templateId = _step.value;

                if (res[templateId] === "accept") {
                  accept.push(templateId);
                }
              }
            } catch (err) {
              _didIteratorError = true;
              _iteratorError = err;
            } finally {
              try {
                if (!_iteratorNormalCompletion && _iterator.return) {
                  _iterator.return();
                }
              } finally {
                if (_didIteratorError) {
                  throw _iteratorError;
                }
              }
            }

            wx.req.post("message/accept/", { data: { accept: accept } });
          }
        },
        complete: function complete(res) {
          _this9.setData({
            subscribeTip: false
          });
          _this9._prepareFormData().then(function (r) {
            wx.navigateTo({
              url: "/pages/wait/wait",
              success: function success(res) {
                res.eventChannel.emit("passFormData", r);
              }
            });
          }).finally(function (r) {
            _this9.toast.hide();
          });
        }
      });
    });
  },
  _prepareFormData: function _prepareFormData() {
    var _this10 = this;

    this.toast.show({
      duration: 0
    });
    return new Promise(function (res, rej) {
      var t = 0;
      var interval = setInterval(function () {
        t += 1;
        if (t >= 60) {
          rej();
        }
        if (_this10.data.images.every(function (item) {
          return item.percent === 100;
        })) {
          clearInterval(interval);
          res({
            images: _this10.data.images,
            duration: _this10.data.player.duration
          });
        }
      }, 500);
    });
  },
  onSuperBannerModalClose: function onSuperBannerModalClose(e) {
    this.setData({
      "superBanner.ready": false
    });
  },
  _submit: function _submit(e) {
    wx.req.post('submit/p2g/', {
      data: {
        images: this.data.images,
        duration: this.data.player.duration
      }
    }).then(function (res) {
      wx.redirectTo({
        url: '/pages/result/result?id=' + res.data.id
      });
    });
  },
  loadAd: function loadAd() {
    this.videoAd = null;
    if (wx.createRewardedVideoAd && app.globalData.ads.reward_video) {
      this.setData({
        ad2make: true
      });
      this.videoAd = wx.createRewardedVideoAd({
        adUnitId: app.globalData.ads.reward_video.unit_id
      });
      this.videoAd.onClose(this.adCallback);
      this.videoAd.onLoad(function () {});
      this.videoAd.onError(function (err) {});
    }
    // 在页面onLoad回调事件中创建插屏广告实例
    if (wx.createInterstitialAd && app.globalData.ads.interstitial) {
      this.interstitialAd = wx.createInterstitialAd({
        adUnitId: app.globalData.ads.interstitial.unit_id
      });
      this.interstitialAd.onLoad(function () {});
      this.interstitialAd.onError(function (err) {});
      this.interstitialAd.onClose(function () {});
    }

    // 在适合的场景显示插屏广告
    if (this.interstitialAd) {
      this.interstitialAd.show().catch(function (err) {
        console.error(err);
      });
    }

    if (app.globalData.ads.super_banner) {
      this.setData({
        "superBanner.ad": app.globalData.ads.super_banner
      });
    }

    if (app.globalData.ads.modal_banner) {
      this.setData({
        modalAd: app.globalData.ads.modal_banner
      });
    }
  },
  closeModals: function closeModals() {
    this.step1Modal.close();
  },
  randomString: function randomString(len) {
    len = len || 32;
    var $chars = "ABCDEFGHJKMNPQRSTWXYZabcdefhijkmnprstwxyz2345678"; /****默认去掉了容易混淆的字符oOLl,9gq,Vv,Uu,I1****/
    var maxPos = $chars.length;
    var pwd = "";
    for (var i = 0; i < len; i++) {
      pwd += $chars.charAt(Math.floor(Math.random() * maxPos));
    }
    return pwd;
  },


  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function onReady() {
    var _this11 = this;

    var query = wx.createSelectorQuery();
    query.select("#mask-wrapper").boundingClientRect();
    query.exec(function (res) {
      console.log(res);
      _this11.setData({
        table: {
          x: res[0].left,
          y: res[0].top,
          w: res[0].width,
          h: res[0].height,
          maxWidth: res[0].width - 60,
          maxHeight: res[0].height - 60
        }
      });
      var eventChannel = _this11.getOpenerEventChannel();
      eventChannel.on("imageInfo", function (data) {
        var canvasImage = data.tempFiles[0];
        wx.getImageInfo({
          src: canvasImage.path
        }).then(function (r) {
          return _this11.resetCanvas(r.width, r.height);
        }).then(function (r) {
          return _this11.getInfo(data.tempFiles);
        }).then(function (r) {
          _this11.play();
        });
      });
    });
  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function onShow() {
    if (this.data.superBanner.ready) {
      this.adModal.close();
      this.submit();
    }
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function onHide() {},

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function onUnload() {},

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function onPullDownRefresh() {},

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function onReachBottom() {},

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function onShareAppMessage() {
    return {
      title: "我正在用这个小程序把图片变成GIF！",
      path: "/pages/index/index",
      imageUrl: "/assets/share.jpeg"
    };
  }
});