var _data;function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }var app = getApp();Page({

  /**
   * 页面的初始数据
   */
  data: (_data = {
    loading: true,
    work: [],
    select: false
  }, _defineProperty(_data, 'loading', true), _defineProperty(_data, 'page', 1), _defineProperty(_data, 'nextPage', false), _defineProperty(_data, 'loadingPage', false), _defineProperty(_data, 'currentId', 0), _data),

  refresh: function refresh() {
    var _this = this;

    app.globalData.loginInfo.then(function (res) {
      wx.req.get('works/?page=' + _this.data.page + '&pageSize=10', {}).then(function (r) {
        wx.stopPullDownRefresh({});
        _this.setData({
          work: _this.data.work.concat(r.data.results),
          loading: false,
          loadingPage: false,
          nextPage: r.data.next
        });
      });
    });
  },
  toIndex: function toIndex(e) {
    wx.switchTab({
      url: '/pages/index/index'
    });
  },
  onPullDownRefresh: function onPullDownRefresh(e) {
    this.setData({
      work: [],
      page: 1
    });
    this.refresh();
  },
  onReachBottom: function onReachBottom(e) {
    if (!this.data.loadingPage && this.data.nextPage) {
      this.setData({
        loadingPage: true,
        page: this.data.page + 1
      });
      this.refresh();
    }
  },
  fight: function fight(e) {
    var _this2 = this;

    wx.showModal({
      title: '确认出战',
      content: '消耗1张参赛卡，派出此GIF出战。',
      confirmText: '确定',
      success: function success(res) {
        if (res.confirm) {
          wx.showLoading({
            title: '出战中...'
          });
          var channel = _this2.getOpenerEventChannel();
          channel.emit('chosen', {
            id: e.currentTarget.dataset.id,
            url: e.currentTarget.dataset.url
          });
          wx.navigateBack({
            delta: 0
          });
        } else if (res.cancel) {
          console.log('用户点击取消');
        }
      }
    });
  },


  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function onLoad(options) {
    this.actionSheet = this.selectComponent('#action-sheet');

    var _wx$getSystemInfoSync = wx.getSystemInfoSync(),
        screenWidth = _wx$getSystemInfoSync.screenWidth;

    this.setData({
      select: options.select === '1',
      width: (screenWidth - 5) / 2
    });
    this.refresh();
  },

  deleteWork: function deleteWork(e) {
    var _this3 = this;

    wx.showModal({
      title: '确认',
      content: '要删除这个作品吗？',
      success: function success(res) {
        if (res.confirm) {
          wx.req.delete('works/' + _this3.data.currentId + '/', {}).then(function (r) {
            _this3.onPullDownRefresh();
            _this3.actionSheet.closeSheet();
          });
        } else if (res.cancel) {
          console.log('用户点击取消');
        }
      }
    });
  },
  moreAction: function moreAction(e) {
    this.setData({
      currentId: e.currentTarget.dataset.id
    });
    this.actionSheet.openSheet();
  },
  delete: function _delete(e) {
    var _this4 = this;

    wx.showModal({
      title: '确认',
      content: '确认删除这个GIF吗？',
      success: function success(res) {
        if (res.confirm) {
          wx.showLoading({
            title: '删除中',
            mask: true
          });
          wx.req.post('work/delete/' + e.currentTarget.dataset.id + '/', {}).then(function (r) {
            wx.hideLoading({});
            _this4.refresh();
          }).catch(function (e) {
            wx.hideLoading({});
          });
        } else if (res.cancel) {
          console.log('用户点击取消');
        }
      }
    });
  },
  tapGif: function tapGif(e) {
    wx.navigateTo({
      url: '/pages/result/result?id=' + e.currentTarget.dataset.id
    });
  },


  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function onReady() {},

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function onShow() {},

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function onHide() {},

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function onUnload() {},

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function onShareAppMessage() {
    return {
      title: '这个小程序能把图片合成GIF！',
      path: '/pages/index/index',
      imageUrl: '/assets/share.jpeg'
    };
  }
});