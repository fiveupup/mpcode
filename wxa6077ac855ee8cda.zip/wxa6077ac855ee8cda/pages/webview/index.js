Page({
    data: {
        webUrl: ""
    },
    onLoad: function(e) {
        var t = decodeURIComponent(e.url);
        this.setData({
            webUrl: t
        });
    }
});