var o = require("../../@babel/runtime/helpers/interopRequireDefault").default, t = require("../../@babel/runtime/helpers/toConsumableArray"), a = (o(require("@vant/weapp/dialog/dialog")), 
require("../../utils/stringutils.js").stringutils), e = require("../../utils/wxutils.js").wxutils, i = getApp();

Page({
    data: {
        app: getApp(),
        recordId: "",
        recordType: "",
        infoActions: null,
        actionSheetdescription: null,
        infoSheetShow: !1,
        radioDialogShow: !1,
        radioDialogActions: null,
        radioDialogTitle: null,
        radioDialogValue: null,
        checkBoxDialogShow: !1,
        checkBoxDialogActions: null,
        checkBoxDialogTitle: null,
        checkBoxDialogValue: null,
        dateDialogShow: !1,
        dateDialogTitle: null,
        dateDialogValue: null,
        dateDialogType: "datetime",
        infoTabList: "",
        formatter: function(o, t) {
            return "year" === o ? "".concat(t, "年") : "month" === o ? "".concat(t, "月") : "day" === o ? "".concat(t, "日") : "hour" === o ? "".concat(t, "时") : "minute" === o ? "".concat(t, "分") : t;
        }
    },
    onLoad: function(o) {
        1 == o.type && wx.setNavigationBarTitle({
            title: "修改信息"
        }), this.setData({
            recordId: o.id,
            recordType: o.type
        }), i.globalData.infoTabList && (this.setData({
            infoTabList: i.globalData.infoTabList,
            roster: i.globalData.roster
        }), i.globalData.infoTabList = null, i.globalData.roster = null);
    },
    onClickSave: function() {
        var o, t = this, a = this.data.infoTabList.some(function(o) {
            return 1 === o.type && (void 0 === o.value || null === o.value || "" === o.value);
        });
        return console.log(a), a ? wx.showModal({
            title: "温馨提示",
            content: "请输入必填信息",
            showCancel: !1
        }) : (o = this.data.infoTabList, this.data.roster && this.data.roster.length > 0 && !this.data.roster.includes(o[0].value) ? wx.showModal({
            title: "温馨提示",
            content: "输入的姓名不在签到人员名单中",
            showCancel: !1
        }) : (0 == this.data.recordType && (i.globalData.infoTabList = o, wx.navigateBack()), 
        void (1 == this.data.recordType && (e.showLoading("修改保存中"), wx.cloud.callFunction({
            name: "quickstartFunctions",
            data: {
                type: "signInManEdit",
                mode: "update",
                infoTabList: o,
                id: this.data.recordId
            }
        }).then(function(a) {
            if (e.hideLoading(), !a.result.success) return wx.showModal({
                title: "温馨提示",
                content: a.result.errMsg,
                showCancel: !1
            });
            i.globalData.infoTabListEdit = o, i.globalData.infoTabListEditId = t.data.recordId, 
            wx.showModal({
                title: "温馨提示",
                content: "签到记录修改成功",
                showCancel: !1,
                complete: function(o) {
                    o.confirm && wx.navigateBack();
                }
            });
        }).catch(function(o) {
            e.hideLoading(), e.showToast("保存失败"), console.error("加载数据失败", o);
        })))));
    },
    onClickfield: function(o) {
        var i = this;
        console.log(o);
        var n = o.currentTarget.dataset.index, l = this.data.infoTabList[n], c = t(this.data.infoTabList), s = [], r = "";
        switch (l.model) {
          case "text":
            break;

          case "radio":
            r = l.title, s = l.chooseList, this.showRadioDialog(s, r).then(function(o) {
                console.log(o), c[n].value = o, setTimeout(function() {
                    i.setData({
                        radioDialogActions: null,
                        radioDialogTitle: null,
                        radioDialogValue: null,
                        infoTabList: c
                    });
                }, 250);
            }).catch(function(o) {});
            break;

          case "checkbox":
            r = l.title, s = l.chooseList, this.showCheckBoxDialog(s, r).then(function(o) {
                c[n].value = o ? o.toString() : "", setTimeout(function() {
                    i.setData({
                        checkBoxDialogActions: null,
                        checkBoxDialogTitle: null,
                        checkBoxDialogValue: null,
                        infoTabList: c
                    });
                }, 250);
            }).catch(function(o) {});
            break;

          case "location":
            e.showLoading("加载中"), e.getLocation().then(function(o) {
                console.log("经纬度信息", o);
                var t = o.latitude, a = o.longitude;
                c[n].value = t + "," + a, i.setData({
                    infoTabList: c
                }), e.hideLoading();
            }).catch(function(o) {
                e.hideLoading(), e.showToast("获取位置信息失败"), console.log("获取位置信息失败", o);
            });
            break;

          case "date":
            r = l.title, this.showDateDialog("date", r).then(function(o) {
                c[n].value = a.formatTimestamp(o).substring(0, 10), i.setData({
                    dateDialogTitle: null,
                    dateDialogValue: Math.floor(Date.now()),
                    infoTabList: c
                });
            }).catch(function(o) {});
            break;

          case "time":
            r = l.title, this.showDateDialog("time", r).then(function(o) {
                console.log(o), c[n].value = o, i.setData({
                    dateDialogTitle: null,
                    dateDialogValue: "12:00",
                    infoTabList: c
                });
            }).catch(function(o) {});
            break;

          case "datetime":
            r = l.title, this.showDateDialog("datetime", r).then(function(o) {
                console.log(o), console.log(a.formatTimestamp(o)), c[n].value = a.formatTimestamp(o), 
                i.setData({
                    dateDialogTitle: null,
                    dateDialogValue: Math.floor(Date.now()),
                    infoTabList: c
                });
            }).catch(function(o) {});
            break;

          case "img":
            wx.chooseMedia({
                count: 1,
                sourceType: [ "album" ],
                mediaType: [ "image" ],
                sizeType: [ "compressed" ],
                success: function(o) {
                    console.log(o);
                    var t = o.tempFiles[0].tempFilePath;
                    console.log("获取图片成功，临时路径为：" + t), wx.previewImage({
                        current: t,
                        urls: [ t ]
                    });
                },
                fail: function(o) {
                    console.error("获取失败", o);
                }
            });
            break;

          case "photo":
            wx.chooseMedia({
                count: 1,
                sourceType: [ "camera" ],
                mediaType: [ "image" ],
                sizeType: [ "compressed" ],
                camera: "back",
                success: function(o) {
                    var t = o.tempFilePaths[0];
                    console.log("拍照成功，临时路径为：" + t), wx.previewImage({
                        current: t,
                        urls: [ t ]
                    });
                },
                fail: function(o) {
                    console.error("拍照失败", o);
                }
            });
        }
        console.log(n, l);
    },
    showDateDialog: function(o, t) {
        var a = this;
        return this.setData({
            dateDialogValue: "time" === o ? "12:00" : Math.floor(Date.now()),
            dateDialogType: o,
            dateDialogTitle: t,
            dateDialogShow: !0
        }), new Promise(function(o, t) {
            a.onDateDialogCancel = function(o) {
                a.setData({
                    dateDialogShow: !1
                }), t("取消按钮被点击或者其他关闭原因");
            }, a.onDateDialogConfirm = function(t) {
                var e = t.detail;
                console.log(e), a.setData({
                    dateDialogShow: !1
                }), o(e);
            };
        });
    },
    showActionSheet: function(o, t) {
        var a = this;
        return this.setData({
            infoActions: o,
            actionSheetdescription: t,
            infoSheetShow: !0
        }), new Promise(function(o, t) {
            a.onActionSheetClose = function(o) {
                a.setData({
                    infoSheetShow: !1
                }), t("取消按钮被点击或者其他关闭原因");
            }, a.onActionSheetSelect = function(t) {
                var e = t.detail;
                a.setData({
                    infoSheetShow: !1
                }), o(e);
            };
        });
    },
    showCheckBoxDialog: function(o, t) {
        var a = this;
        return this.setData({
            checkBoxDialogActions: o,
            checkBoxDialogTitle: t,
            checkBoxDialogShow: !0
        }), new Promise(function(o, t) {
            a.onCheckBoxDialogClose = function(o) {
                a.setData({
                    checkBoxDialogShow: !1
                }), t("取消按钮被点击或者其他关闭原因");
            }, a.onCheckBoxDialogSelect = function(t) {
                var e = a.data.checkBoxDialogValue;
                a.setData({
                    checkBoxDialogShow: !1
                }), o(e);
            }, a.onClickCheckBox = function(o) {
                var t = o.currentTarget.dataset.index;
                console.log(t), a.selectComponent(".checkboxes-".concat(t)).toggle();
            }, a.onCheckBoxDialogChange = function(o) {
                console.log(o), a.setData({
                    checkBoxDialogValue: o.detail
                });
            }, a.noop = function(o) {};
        });
    },
    showRadioDialog: function(o, t) {
        var a = this;
        return this.setData({
            radioDialogActions: o,
            radioDialogTitle: t,
            radioDialogShow: !0
        }), new Promise(function(o, t) {
            a.onRadioDialogClose = function(o) {
                a.setData({
                    radioDialogShow: !1
                }), t("取消按钮被点击或者其他关闭原因");
            }, a.onRadioDialogSelect = function(t) {
                var e = a.data.radioDialogValue;
                a.setData({
                    radioDialogShow: !1
                }), o(e);
            }, a.onClickRadio = function(o) {
                var t = o.currentTarget.dataset.name;
                a.setData({
                    radioDialogValue: t
                });
            };
        });
    },
    handleFieldInput: function(o) {
        var t = o.currentTarget.dataset.index, a = o.detail, e = this.data.infoTabList;
        e[t].value = a, this.setData({
            infoTabList: e
        });
    },
    onReady: function() {},
    onShow: function() {},
    onHide: function() {},
    onUnload: function() {},
    onPullDownRefresh: function() {},
    onReachBottom: function() {},
    onShareAppMessage: function() {}
});