require("../../utils/stringutils.js").stringutils;

var t = require("../../utils/wxutils.js").wxutils;

getApp();

Page({
    data: {
        template: ""
    },
    onLoad: function(e) {
        if (t.showLoading("生成中"), !e.title || !e.sid) return t.showToast("生成失败");
        this.createSignInQrCode(e.sid, e.title);
    },
    preview: function() {
        this.data.img && (wx.reportEvent("poster", {
            type: "preview"
        }), wx.previewImage({
            current: this.data.img,
            urls: [ this.data.img ]
        }));
    },
    shareImg: function() {
        this.data.img && (wx.reportEvent("poster", {
            type: "share"
        }), wx.showShareImageMenu({
            path: this.data.img,
            success: function(t) {
                console.log("分享成功：", t);
            },
            fail: function(t) {
                console.log("分享失败：", t);
            }
        }));
    },
    onImgOK: function(e) {
        t.hideLoading(), console.log(e.detail.path), this.setData({
            img: e.detail.path
        });
    },
    createSignInQrCode: function(e, o) {
        var i = this;
        t.showLoading("生成中"), wx.cloud.callFunction({
            name: "quickstartFunctions",
            data: {
                type: "signInQrcode",
                sid: e
            }
        }).then(function(e) {
            if (console.log(e), e.result.success) {
                var r = {
                    image: "data:image/png;base64," + e.result.data,
                    title: o
                };
                i.setData({
                    template: i.palette(r)
                });
            } else t.hideLoading(), t.showToast("生成失败");
        }).catch(function(e) {
            t.hideLoading(), t.showToast("生成失败"), console.error("加载数据失败", e);
        });
    },
    palette: function(t) {
        var e = t.image;
        return {
            width: "1100px",
            height: "1600px",
            background: "#3AB568",
            views: [ {
                type: "rect",
                css: {
                    width: "1100px",
                    height: "1600px",
                    top: "0",
                    left: "0",
                    rotate: "0",
                    borderRadius: "0",
                    shadow: "",
                    color: "linear-gradient(-1deg, rgba(45, 180, 103, 1) 0%, rgba(45, 180, 103, 1) 60%, rgba(7, 193, 96, 1) 40%)"
                }
            }, {
                type: "rect",
                css: {
                    width: "600px",
                    height: "600px",
                    top: "1364px",
                    left: "2px",
                    rotate: "0",
                    borderRadius: "600px",
                    shadow: "",
                    color: "#5EBA6B"
                }
            }, {
                type: "rect",
                css: {
                    width: "920px",
                    height: "1420px",
                    top: "90px",
                    left: "90px",
                    rotate: "0",
                    borderRadius: "30px",
                    shadow: "4px -4px 10px rgba(0, 0, 0, 0.1)",
                    color: "#FFFFFF"
                }
            }, {
                type: "rect",
                css: {
                    width: "920px",
                    height: "550px",
                    top: "90px",
                    left: "90px",
                    rotate: "0",
                    borderRadius: "30px 30px 0px 0px",
                    color: "#12B363"
                }
            }, {
                type: "rect",
                css: {
                    background: "#FFFFFF",
                    width: "500px",
                    height: "500px",
                    top: "382px",
                    left: "304px",
                    rotate: "0",
                    borderRadius: "50px",
                    borderWidth: "2px",
                    borderColor: "#20B865",
                    shadow: "0 2px 10px rgba(0, 0, 0, 0.1)",
                    color: "#FFFFFF"
                }
            }, {
                type: "text",
                text: "签到二维码",
                css: {
                    color: "#FFFFFF",
                    background: "rgba(0,0,0,0)",
                    width: "680px",
                    height: "160px",
                    top: "224px",
                    left: "220px",
                    rotate: "0",
                    borderRadius: "",
                    borderWidth: "",
                    borderColor: "#000000",
                    shadow: "",
                    padding: "0px",
                    fontSize: "60px",
                    fontWeight: "bold",
                    maxLines: "2",
                    lineHeight: "66.6px",
                    textDecoration: "none",
                    fontFamily: "",
                    textAlign: "center"
                }
            }, {
                type: "text",
                text: "参与此签到",
                css: {
                    color: "#666",
                    background: "rgba(0,0,0,0)",
                    width: "320px",
                    height: "60px",
                    top: "1374px",
                    left: "645px",
                    rotate: "0",
                    borderRadius: "",
                    borderWidth: "",
                    borderColor: "#000000",
                    shadow: "",
                    padding: "0px",
                    fontSize: "52px",
                    fontWeight: "normal",
                    maxLines: "2",
                    lineHeight: "58px",
                    textDecoration: "none",
                    fontFamily: "",
                    textAlign: "center"
                }
            }, {
                type: "text",
                text: "长按识别小程序码",
                css: {
                    color: "#666",
                    background: "rgba(0,0,0,0)",
                    width: "500px",
                    height: "60px",
                    top: "1296px",
                    left: "480px",
                    rotate: "0",
                    borderRadius: "",
                    borderWidth: "",
                    borderColor: "#000000",
                    shadow: "",
                    padding: "0px",
                    fontSize: "52px",
                    fontWeight: "normal",
                    maxLines: "2",
                    lineHeight: "58px",
                    textDecoration: "none",
                    fontFamily: "",
                    textAlign: "center"
                }
            }, {
                type: "text",
                text: t.title,
                css: {
                    color: "#000000",
                    background: "rgba(0,0,0,0)",
                    width: "600px",
                    height: "68px",
                    top: "966px",
                    left: "260px",
                    rotate: "0",
                    borderRadius: "",
                    borderWidth: "",
                    borderColor: "#000000",
                    shadow: "",
                    padding: "0px",
                    fontSize: "60px",
                    fontWeight: "bold",
                    maxLines: "3",
                    lineHeight: "66px",
                    textDecoration: "none",
                    fontFamily: "",
                    textAlign: "center"
                }
            }, {
                type: "image",
                url: e,
                css: {
                    color: "#000000",
                    background: "#ffffff",
                    width: "400px",
                    height: "400px",
                    top: "430px",
                    left: "352px",
                    rotate: "0",
                    borderRadius: ""
                }
            } ]
        };
    }
});