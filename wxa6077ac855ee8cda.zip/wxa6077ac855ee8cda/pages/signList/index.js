var a = getApp(), t = require("../../utils/stringutils.js").stringutils, e = require("../../utils/wxutils.js").wxutils;

Page({
    data: {
        userInfo: null,
        firstShow: !0,
        firstLogin: !0,
        pageSize: 10,
        createCurrentPage: 0,
        createList: null,
        managerCurrentPage: 0,
        managerList: null,
        signCurrentPage: 0,
        signList: null,
        tabsIndex: 0,
        delId: null
    },
    onLoad: function(a) {},
    loadMoreData: function(a) {
        var n = this, s = 0;
        0 == this.data.tabsIndex && (s = this.data.createCurrentPage), 1 == this.data.tabsIndex && (s = this.data.managerCurrentPage), 
        2 == this.data.tabsIndex && (s = this.data.signCurrentPage), e.showLoading(), wx.cloud.callFunction({
            name: "quickstartFunctions",
            data: {
                type: "signInRecord",
                currentPage: s,
                pageSize: this.data.pageSize,
                tabsIndex: this.data.tabsIndex
            }
        }).then(function(s) {
            var i = s.result.list;
            if (console.log(s.result.list), e.hideLoading(), a && (0 == n.data.tabsIndex && n.setData({
                createList: null
            }), 1 == n.data.tabsIndex && n.setData({
                managerList: null
            }), 2 == n.data.tabsIndex && n.setData({
                signList: null
            }), wx.stopPullDownRefresh(), e.showToast("刷新成功")), i.length > 0) {
                if (i.forEach(function(a) {
                    a.startTime = t.formatTimestamp(a.startTime), a.endTime = t.formatTimestamp(a.endTime);
                }), 0 == n.data.tabsIndex) {
                    if (n.data.createList) r = n.data.createList.concat(i); else var r = i;
                    n.setData({
                        createList: r,
                        createCurrentPage: n.data.createCurrentPage + 1
                    });
                }
                if (1 == n.data.tabsIndex) {
                    if (n.data.managerList) r = n.data.managerList.concat(i); else var r = i;
                    n.setData({
                        managerList: r,
                        managerCurrentPage: n.data.createCurrentPage + 1
                    });
                }
                if (2 == n.data.tabsIndex) {
                    if (n.data.signList) r = n.data.signList.concat(i); else r = i;
                    n.setData({
                        signList: r,
                        signCurrentPage: n.data.signCurrentPage + 1
                    });
                }
            } else console.log("数据已加载完毕"), 0 == n.data.tabsIndex && 0 != n.data.createCurrentPage && e.showToast("暂无更多数据"), 
            1 == n.data.tabsIndex && 0 != n.data.managerCurrentPage && e.showToast("暂无更多数据"), 
            2 == n.data.tabsIndex && 0 != n.data.signCurrentPage && e.showToast("暂无更多数据");
        }).catch(function(t) {
            e.hideLoading(), a && (0 == n.data.tabsIndex && n.setData({
                createList: null
            }), 1 == n.data.tabsIndex && n.setData({
                managerList: null
            }), 2 == n.data.tabsIndex && n.setData({
                signList: null
            }), wx.stopPullDownRefresh(), e.showToast("刷新失败")), console.error("加载数据失败", t);
        });
    },
    jumpPoster: function(a) {
        var t = a.currentTarget.dataset.id, e = a.currentTarget.dataset.title;
        wx.navigateTo({
            url: "/pages/poster/index?sid=".concat(t, "&title=").concat(e)
        });
    },
    onReady: function() {},
    onShow: function() {
        var t = wx.getStorageSync("userInfo");
        if (t ? this.setData({
            userInfo: t
        }) : this.setData({
            userInfo: null
        }), this.data.firstLogin && !this.data.userInfo) return this.setData({
            firstLogin: !1
        }), void this.toLogin();
        a.globalData.building && (a.globalData.building = null, this.refresh()), a.globalData.delId && (console.log("上个页面删除了数据"), 
        a.globalData.delId = null, this.refresh()), this.data.firstShow && !this.data.delId && (this.setData({
            firstShow: !1
        }), console.log("加载数据"), this.loadMoreData());
    },
    toLogin: function() {
        e.setCallbackUrl("switchTab").then(function(a) {
            wx.navigateTo({
                url: "/pages/login/index"
            });
        });
    },
    refresh: function() {
        0 == this.data.tabsIndex && this.setData({
            createCurrentPage: 0
        }), 1 == this.data.tabsIndex && this.setData({
            managerCurrentPage: 0
        }), 2 == this.data.tabsIndex && this.setData({
            signCurrentPage: 0
        }), this.loadMoreData(!0);
    },
    jumpPage: function(t) {
        if (!a.globalData.userInfo) return console.log("用户信息不存在", a.globalData.userInfo), 
        e.setCallbackUrl("switchTab").then(function(a) {
            wx.navigateTo({
                url: "/pages/login/index"
            });
        }), void e.showToast("请登录后再操作");
        wx.navigateTo({
            url: "/pages/signInfo/index?id=".concat(t.currentTarget.dataset.id)
        });
    },
    onTabsClick: function(a) {
        this.setData({
            tabsIndex: a.detail.index
        }), 1 == a.detail.index && (this.data.managerList || this.loadMoreData()), 2 == a.detail.index && (this.data.signList || this.loadMoreData());
    },
    onHide: function() {},
    onUnload: function() {},
    onPullDownRefresh: function() {
        this.refresh();
    },
    onReachBottom: function() {
        this.loadMoreData();
    },
    onShareAppMessage: function() {
        return {
            promise: new Promise(function(a) {
                e.showLoading("加载中"), setTimeout(function() {
                    e.hideLoading(), a({
                        title: "推荐给你一个好用的签到助手",
                        path: "/pages/index/index",
                        imageUrl: "/images/share_bg.png"
                    });
                }, 500);
            })
        };
    }
});