var e = (0, require("../../@babel/runtime/helpers/interopRequireDefault").default)(require("@vant/weapp/dialog/dialog")), n = (require("../../utils/stringutils.js").stringutils, 
require("../../utils/wxutils.js").wxutils), t = getApp();

Page({
    data: {
        app: getApp(),
        userInfo: null
    },
    login: function() {
        n.setCallbackUrl("switchTab").then(function(e) {
            wx.navigateTo({
                url: "/pages/login/index"
            });
        });
    },
    onClickLogout: function() {
        var n = this;
        e.default.confirm({
            title: "提示",
            message: "是否退出登录"
        }).then(function() {
            t.globalData.userInfo = null, t.globalData.user_openid = null, n.setData({
                userInfo: null
            }), wx.removeStorageSync("userInfo");
        }).catch(function() {});
    },
    onClickLogin: function() {
        this.data.userInfo || this.login();
    },
    onClickCopy: function() {
        wx.reportEvent("mine", {
            type: "id_copy"
        }), wx.setClipboardData({
            data: this.data.userInfo.uuid,
            success: function(e) {
                n.showToast("复制成功");
            }
        });
    },
    onClickAbout: function() {
        wx.showModal({
            title: "关于我们",
            content: "签到助手，快速方便实现签到需求。统计分析合理安排。",
            showCancel: !1,
            complete: function(e) {
                e.cancel, e.confirm;
            }
        });
    },
    onShare: function() {},
    onLoad: function(e) {
        this.setData({
            userInfo: t.globalData.userInfo
        }), wx.showShareMenu({
            withShareTicket: !0,
            menus: [ "shareAppMessage", "shareTimeline" ]
        });
    },
    share: function() {
        wx.reportEvent("mine", {
            type: "share"
        });
    },
    onReady: function() {},
    onShow: function() {
        var e = wx.getStorageSync("userInfo");
        e ? this.setData({
            userInfo: e
        }) : this.setData({
            userInfo: null
        });
    },
    onShareAppMessage: function() {
        return {
            promise: new Promise(function(e) {
                n.showLoading("加载中"), setTimeout(function() {
                    n.hideLoading(), e({
                        title: "推荐给你一个好用的签到助手",
                        path: "/pages/index/index",
                        imageUrl: "/images/share_bg.png"
                    });
                }, 500);
            })
        };
    }
});