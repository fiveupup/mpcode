var t = require("../../@babel/runtime/helpers/interopRequireDefault").default, e = require("../../@babel/runtime/helpers/toConsumableArray"), a = t(require("@vant/weapp/dialog/dialog")), i = require("../../utils/stringutils.js").stringutils, s = require("../../utils/wxutils.js").wxutils, n = getApp();

Page({
    data: {
        type: 1,
        title: null,
        titleErrMsg: null,
        desc: null,
        descErrMsg: null,
        showStartTime: !1,
        startTimeCurrentDate: null,
        startTime: null,
        startTimeMinDate: null,
        startTimeMinHour: null,
        startTimeMinMinute: null,
        showEndTime: !1,
        endTimeCurrentDate: null,
        endTime: null,
        endTimeMinDate: null,
        endTimeMinHour: null,
        endTimeMinMinute: null,
        timeRangeChecked: !1,
        timeRangeList: [ {
            startTime: "00:00",
            endTime: "23:59"
        } ],
        passwordChecked: !1,
        password: null,
        addressChecked: null,
        address: null,
        minRange: 500,
        minRangeErrMsg: null,
        rosterChecked: null,
        roster: null,
        infoChecked: !1,
        infoSheetShow: !1,
        dateDialogShow: !1,
        dateDialogTitle: null,
        dateDialogValue: null,
        dateDialogMinHour: 0,
        dateDialogMaxHour: 23,
        dateDialogMinMinute: 0,
        dateDialogMaxMinute: 59,
        infoTabList: [ {
            title: "姓名",
            check: !0,
            type: 1,
            model: "text"
        }, {
            title: "手机号",
            check: !1,
            type: 2,
            model: "text"
        }, {
            title: "性别",
            check: !1,
            type: 1,
            model: "radio",
            chooseList: [ "男", "女" ]
        } ],
        infoActions: null,
        actionSheetdescription: null,
        diyInfoDialogShow: !1,
        createIng: !1,
        moreFun: !1,
        formatter: function(t, e) {
            return "year" === t ? "".concat(e, "年") : "month" === t ? "".concat(e, "月") : "day" === t ? "".concat(e, "日") : "hour" === t ? "".concat(e, "时") : "minute" === t ? "".concat(e, "分") : e;
        },
        textareaMinHeight: {
            minHeight: 100
        }
    },
    onLoad: function(t) {
        if (n.globalData.saveData) {
            var e = n.globalData.saveData, a = Date.parse(e.startTime), s = Date.parse(e.endTime), o = a + 6e5;
            this.setData({
                type: e.type,
                title: e.title,
                desc: e.desc,
                startTime: i.formatTimestamp(a),
                endTime: i.formatTimestamp(s),
                passwordChecked: !!e.password,
                password: e.password,
                addressChecked: !!e.address.address,
                address: e.address,
                minRange: 0 != e.minRange ? e.minRange : 500,
                timeRangeChecked: !!(e.timeRangeList && e.timeRangeList.length > 0),
                timeRangeList: e.timeRangeList,
                rosterChecked: !!(e.roster && e.roster.length > 0),
                roster: e.roster,
                infoChecked: !!(e.infoTabList && e.infoTabList.length > 0),
                infoTabList: e.infoTabList && e.infoTabList.length > 0 ? e.infoTabList : this.data.infoTabList,
                startTimeCurrentDate: a,
                endTimeCurrentDate: s,
                endTimeMinDate: o,
                endTimeMinHour: o,
                endTimeMinMinute: o
            }), n.globalData.saveData = null;
        } else {
            var r = new Date();
            r.setHours(0, 0, 0, 0);
            var d = Math.floor(r.getTime());
            1 != t.type && r.setFullYear(r.getFullYear() + 1), r.setHours(23, 59, 59, 999);
            var l = Math.floor(r.getTime()), h = d + 6e5;
            this.setData({
                type: t.type || 1,
                startTime: i.formatTimestamp(d),
                startTimeCurrentDate: d,
                endTime: i.formatTimestamp(l),
                endTimeCurrentDate: l,
                endTimeMinDate: h,
                endTimeMinHour: h,
                endTimeMinMinute: h
            });
        }
        wx.setNavigationBarTitle({
            title: 1 == this.data.type ? "创建临时签到" : 2 == this.data.type ? "创建长期签到" : 3 == this.data.type ? "创建自由签到" : 4 == this.data.type ? "创建考勤签到" : "创建签到"
        });
    },
    onDiyInfoTabClick: function() {
        this.selectComponent("#diy-info-dialog").initialization(), this.setData({
            diyInfoDialogShow: !0
        });
    },
    onDiyInfoChooseOver: function(t) {
        var e = this, a = t.detail.eventData, i = this.data.infoTabList, n = "text";
        if (console.log("自定义数据", a), !a.title) return s.showToast("请输入字段名称"), void setTimeout(function() {
            e.setData({
                diyInfoDialogShow: !0
            });
        }, 50);
        switch (a.type) {
          case 2:
            if (n = "radio", !a.chooseList || a.chooseList.length < 2) return s.showToast("请添加两个以上选项"), 
            void setTimeout(function() {
                e.setData({
                    diyInfoDialogShow: !0
                });
            }, 50);
            break;

          case 3:
            if (n = "checkbox", !a.chooseList || a.chooseList.length < 2) return s.showToast("请添加两个以上选项"), 
            void setTimeout(function() {
                e.setData({
                    diyInfoDialogShow: !0
                });
            }, 50);
            break;

          case 4:
            n = "location";
            break;

          case 5:
            n = "date";
            break;

          case 6:
            n = "time";
            break;

          case 7:
            n = "datetime";
            break;

          case 8:
            n = "img";
            break;

          case 9:
            n = "photo";
        }
        0 == a.ac && (a.chooseList ? i.push({
            title: a.title,
            check: !0,
            type: a.required ? 1 : 2,
            model: n,
            chooseList: a.chooseList
        }) : i.push({
            title: a.title,
            check: !0,
            type: a.required ? 1 : 2,
            model: n
        })), 1 == a.ac && (i[a.index].title = a.title, i[a.index].type = a.required ? 1 : 2, 
        i[a.index].model = n, a.chooseList && (i[a.index].chooseList = a.chooseList)), this.setData({
            infoTabList: i
        });
    },
    onInfoTabClick: function(t) {
        var e = this, i = t.currentTarget.dataset.index, n = this.data.infoTabList, o = n[i];
        if (o.check) n[i].check = !1, this.setData({
            infoTabList: n
        }), s.showToast("取消成功"); else {
            if (0 === i && "姓名" === o.title) var r = [ {
                type: 1,
                name: "设为必填项"
            }, {
                type: 2,
                name: "设为选填项"
            } ]; else r = [ {
                type: 1,
                name: "设为必填项"
            }, {
                type: 2,
                name: "设为选填项"
            }, {
                type: 3,
                name: "修改"
            }, {
                type: 4,
                name: "复制"
            }, {
                type: 0,
                name: "删除",
                color: "#FF0000"
            } ];
            var d = "";
            switch (o.model) {
              case "text":
                d = "文本框";
                break;

              case "radio":
                d = "单选项";
                break;

              case "checkbox":
                d = "多选项";
                break;

              case "location":
                d = "定位";
                break;

              case "date":
                d = "日期";
                break;

              case "time":
                d = "时间";
                break;

              case "datetime":
                d = "日期+时间";
                break;

              case "img":
                d = "图片";
                break;

              case "photo":
                d = "拍照";
                break;

              default:
                d = "未知类型";
            }
            this.showActionSheet(r, d).then(function(t) {
                if (0 != t.type) {
                    if (1 == t.type && (n[i].type = 1, n[i].check = !0, s.showToast("设置成功"), console.log("必填项")), 
                    2 == t.type && (n[i].type = 2, n[i].check = !0, console.log("选填项"), s.showToast("设置成功")), 
                    3 == t.type) {
                        console.log("修改");
                        var r = o;
                        r.index = i, e.selectComponent("#diy-info-dialog").updateData(r), e.setData({
                            diyInfoDialogShow: !0
                        });
                    }
                    4 == t.type && (n.push(n[i]), console.log("复制"), s.showToast("复制成功")), e.setData({
                        infoTabList: n
                    });
                } else a.default.confirm({
                    title: "是否删除【" + o.title + "】"
                }).then(function() {
                    n.splice(i, 1), e.setData({
                        infoTabList: n
                    }), s.showToast("删除成功");
                }).catch(function() {});
            }).catch(function(t) {});
        }
    },
    showDateDialog: function(t, a, i, s) {
        var n = this, o = e(this.data.timeRangeList);
        if ("start" == a) {
            var r = o[i].endTime.split(":"), d = parseInt(r[0], 10);
            0 === (l = parseInt(r[1], 10)) && (d -= 1, l = 59), this.setData({
                dateDialogValue: t,
                dateDialogTitle: s,
                dateDialogMaxHour: d,
                dateDialogMaxMinute: l,
                dateDialogMinHour: 0,
                dateDialogMinMinute: 0,
                dateDialogShow: !0
            });
        }
        if ("end" == a) {
            r = o[i].startTime.split(":"), d = parseInt(r[0], 10);
            var l = parseInt(r[1], 10);
            this.setData({
                dateDialogValue: t,
                dateDialogTitle: s,
                dateDialogMaxHour: 23,
                dateDialogMaxMinute: 59,
                dateDialogMinHour: d,
                dateDialogMinMinute: l,
                dateDialogShow: !0
            });
        }
        return new Promise(function(t, e) {
            n.onDateDialogCancel = function(t) {
                n.setData({
                    dateDialogShow: !1
                }), e("取消按钮被点击或者其他关闭原因");
            }, n.onDateDialogConfirm = function(e) {
                var a = e.detail;
                console.log(a), n.setData({
                    dateDialogShow: !1
                }), t(a);
            };
        });
    },
    showActionSheet: function(t, e) {
        var a = this;
        return this.setData({
            infoActions: t,
            actionSheetdescription: e,
            infoSheetShow: !0
        }), new Promise(function(t, e) {
            a.onActionSheetClose = function(t) {
                a.setData({
                    infoSheetShow: !1
                }), e("取消按钮被点击或者其他关闭原因");
            }, a.onActionSheetSelect = function(e) {
                var i = e.detail;
                a.setData({
                    infoSheetShow: !1
                }), t(i);
            };
        });
    },
    onTimeRangeTimeClick: function(t) {
        var a = this, i = t.currentTarget.dataset.index, s = t.currentTarget.dataset.type;
        this.showDateDialog("00:00", s, i, "请选择 时段".concat(i + 1, " ").concat("start" == s ? "开始时间" : "结束时间")).then(function(t) {
            var n = e(a.data.timeRangeList);
            "start" == s ? n[i].startTime = t : n[i].endTime = t, a.setData({
                timeRangeList: n
            });
        }).catch(function(t) {});
    },
    onTimeRangeDelClick: function(t) {
        var e = t.currentTarget.dataset.index, a = this.data.timeRangeList;
        a.splice(e, 1), this.setData({
            timeRangeList: a
        });
    },
    onClickType: function(t) {
        var e = this;
        switch (t.currentTarget.dataset.type) {
          case "startTime":
            this.setData({
                showStartTime: !0
            });
            break;

          case "endTime":
            this.setData({
                showEndTime: !0
            });
            break;

          case "addressChoose":
            wx.chooseLocation({
                success: function(t) {
                    var a = t.latitude, i = t.longitude, s = t.name, n = t.address;
                    e.setData({
                        address: {
                            latitude: a,
                            longitude: i,
                            name: s,
                            address: n
                        }
                    }), console.log(a, i, s, n);
                },
                fail: function(t) {
                    console.error(t), wx.showToast({
                        title: "位置选择失败",
                        duration: 2e3,
                        icon: "none"
                    });
                }
            });
            break;

          case "createSignIn":
            if (!this.data.title || 0 == this.data.title.length) return this.setData({
                titleErrMsg: "请输入标题"
            }), void s.showToast("请输入标题");
            if (!this.data.minRange || 0 == this.data.minRange.length) return this.setData({
                minRangeErrMsg: "请输入签到范围"
            }), void s.showToast("请输入签到范围");
            if (this.data.addressChecked) {
                if (isNaN(this.data.minRange)) return this.setData({
                    minRangeErrMsg: "签到范围错误,请输入不小于50的阿拉伯数字"
                }), void s.showToast("签到范围错误,请输入不小于50的阿拉伯数字");
                if (this.data.minRange < 50) return this.setData({
                    minRangeErrMsg: "签到范围最小50米"
                }), void s.showToast("签到范围最小50米");
                if (!this.data.address || !this.data.address.address) return s.showToast("请选择地点");
            }
            if (Date.parse(this.data.startTime) > Date.parse(this.data.endTime)) return s.showToast("开始时间不能大于结束时间");
            if (Math.floor(Date.now() / 1e3) >= Math.floor(this.data.endTimeCurrentDate / 1e3)) return s.showToast("结束时间不能小于现在");
            if (2 == this.data.type || 4 == this.data.type) {
                if (!this.data.timeRangeChecked) return wx.showModal({
                    title: "温馨提示",
                    content: "长期签到和考勤签到必须打开时间区间",
                    showCancel: !1
                });
                if (!this.data.timeRangeList || 0 == this.data.timeRangeList.length) return wx.showModal({
                    title: "温馨提示",
                    content: "最少设置一个时间段",
                    showCancel: !1
                });
                if (i.checkTimeRangesOverlap(this.data.timeRangeList)) return s.showToast("时间区间不能有重叠");
            }
            var a = this.data.infoTabList.filter(function(t) {
                return !0 === t.check;
            });
            if (this.data.rosterChecked) {
                if (!this.data.infoChecked || !a || 0 == a.length || "姓名" !== a[0].title || 1 !== a[0].type) return wx.showModal({
                    title: "温馨提示",
                    content: "已设置签到名单，信息填写项第一个必须为姓名，并且为必填项。",
                    showCancel: !1
                });
                if (!this.data.roster || 0 == this.data.roster.length) return wx.showModal({
                    title: "温馨提示",
                    content: "请添加人员名单",
                    showCancel: !1
                });
            }
            var o = {
                title: this.data.title,
                desc: this.data.desc,
                type: this.data.type,
                startTime: this.data.startTimeCurrentDate,
                endTime: this.data.endTimeCurrentDate,
                password: this.data.passwordChecked ? this.data.password : "",
                address: this.data.addressChecked ? this.data.address : "",
                minRange: this.data.addressChecked ? this.data.minRange : 0,
                infoTabList: this.data.infoChecked ? a : [],
                roster: this.data.rosterChecked && this.data.roster && this.data.roster.length > 0 ? this.data.roster : [],
                timeRangeList: 2 == this.data.type || 4 == this.data.type ? this.data.timeRangeList : []
            };
            if (console.log(o), this.data.createIng) return;
            wx.showModal({
                title: "温馨提示",
                content: "签到活动创建后仅可修改部分设置，请确认无误后提交。",
                complete: function(t) {
                    t.cancel, t.confirm && (wx.showLoading({
                        title: "创建中"
                    }), e.setData({
                        createIng: !0
                    }), wx.cloud.callFunction({
                        name: "quickstartFunctions",
                        data: {
                            type: "signInCreate",
                            data: o
                        }
                    }).then(function(t) {
                        s.hideLoading(), t.result.success ? (s.hideLoading(), wx.showModal({
                            title: "温馨提示",
                            content: "签到创建成功，请转发好友进行签到",
                            showCancel: !1,
                            complete: function(t) {
                                t.confirm && (n.globalData.building = !0, wx.switchTab({
                                    url: "/pages/signList/index"
                                }));
                            }
                        })) : s.showToast(t.result.errMsg), e.setData({
                            createIng: !1
                        });
                    }).catch(function(t) {
                        e.setData({
                            createIng: !1
                        }), s.hideLoading(), s.showToast("创建失败"), console.error("加载数据失败", t);
                    }));
                }
            });
            break;

          case "timeRangeAdd":
            var r = this.data.timeRangeList;
            r.push({
                startTime: "00:00",
                endTime: "23:59"
            }), this.setData({
                timeRangeList: r
            });
            break;

          case "rosterChoose":
            n.globalData.saveRosterData = this.data.roster, wx.navigateTo({
                url: "/pages/rosterEdit/index"
            });
        }
    },
    onStartTimeConfirm: function(t) {
        var e = t.detail + 6e5;
        this.setData({
            startTimeCurrentDate: t.detail,
            showStartTime: !1,
            endTimeMinDate: e,
            endTimeMinHour: e,
            endTimeMinMinute: e
        });
        var a = i.formatTimestamp(t.detail);
        this.setData({
            startTime: a
        });
    },
    onStartTimeCancel: function(t) {
        this.setData({
            showStartTime: !1
        });
    },
    onEndTimeConfirm: function(t) {
        this.setData({
            endTimeCurrentDate: t.detail,
            showEndTime: !1
        });
        var e = i.formatTimestamp(t.detail);
        this.setData({
            endTime: e
        });
    },
    onEndTimeCancel: function(t) {
        this.setData({
            showEndTime: !1
        });
    },
    onTimeRangeCheckedChange: function(t) {
        var e = t.detail;
        this.setData({
            timeRangeChecked: e
        });
    },
    onPasswordCheckedChange: function(t) {
        var e = t.detail;
        e ? this.setData({
            passwordChecked: e,
            password: i.generateRandomNumber(6)
        }) : this.setData({
            passwordChecked: e,
            password: null
        });
    },
    onAddressCheckedChange: function(t) {
        var e = t.detail;
        this.setData({
            addressChecked: e
        });
    },
    onInputFocus: function() {
        this.setData({
            titleErrMsg: null,
            descErrMsg: null,
            minRangeErrMsg: null
        });
    },
    onRosterCheckedChange: function(t) {
        var e = t.detail;
        this.setData({
            rosterChecked: e
        });
    },
    onInfoCheckedChange: function(t) {
        var e = t.detail;
        this.setData({
            infoChecked: e
        });
    },
    onReady: function() {},
    onShow: function() {
        n.globalData.saveRosterData && (this.setData({
            roster: n.globalData.saveRosterData
        }), n.globalData.saveRosterData = null);
    },
    onHide: function() {},
    onUnload: function() {},
    onPullDownRefresh: function() {},
    onReachBottom: function() {},
    onShareAppMessage: function() {}
});