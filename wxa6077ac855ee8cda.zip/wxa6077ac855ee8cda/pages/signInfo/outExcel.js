(0, require("../../@babel/runtime/helpers/interopRequireDefault").default)(require("@vant/weapp/dialog/dialog"));

var t = require("../../utils/stringutils.js").stringutils, e = require("../../utils/wxutils.js").wxutils;

getApp();

Page({
    data: {
        type: 0,
        typeTitle: "全部",
        group: 0,
        groupTitle: "不分组",
        infoSheetShow: !1,
        infoActions: null,
        showStartTime: !1,
        startTimeCurrentDate: null,
        startTime: null,
        startTimeMinDate: null,
        startTimeMinHour: null,
        startTimeMinMinute: null,
        showEndTime: !1,
        endTimeCurrentDate: null,
        endTime: null,
        endTimeMinDate: null,
        endTimeMinHour: null,
        endTimeMinMinute: null,
        formatter: function(t, e) {
            return "year" === t ? "".concat(e, "年") : "month" === t ? "".concat(e, "月") : "day" === t ? "".concat(e, "日") : "hour" === t ? "".concat(e, "时") : "minute" === t ? "".concat(e, "分") : e;
        }
    },
    onLoad: function(t) {
        var n = t.id, i = t.startTime, a = t.endTime;
        n && i && a || e.showToast("参数错误");
        var o = Date.parse(i) + 6e5;
        this.setData({
            id: n,
            startTimeCurrentDate: Date.parse(i),
            startTime: i,
            endTimeCurrentDate: Date.parse(a),
            endTime: a,
            endTimeMinDate: o,
            endTimeMinHour: o,
            endTimeMinMinute: o
        });
    },
    btnClick: function() {
        e.showLoading("导出生成中"), wx.cloud.callFunction({
            name: "quickstartFunctions",
            data: {
                type: "signInManToExcel",
                id: this.data.id,
                outType: this.data.type,
                outGroup: this.data.group,
                outStartTime: this.data.startTimeCurrentDate,
                outEndTime: this.data.endTimeCurrentDate
            }
        }).then(function(t) {
            console.log(t.result.fileURL);
            var n = t.result.fileURL;
            n ? (wx.reportEvent("info_sign", {
                type: "sign_excel_out_success"
            }), wx.navigateTo({
                url: "/pages/signInfo/outExcelResult?url=".concat(n)
            })) : e.showToast("导出失败"), e.hideLoading();
        }).catch(function(t) {
            e.hideLoading(), e.showToast("导出失败"), console.error("加载数据失败", t);
        });
    },
    onClickType: function(t) {
        var e = this;
        switch (t.currentTarget.dataset.type) {
          case "type":
            var n = [ {
                type: 0,
                name: "全部"
            }, {
                type: 1,
                name: "按日期筛选"
            } ];
            this.showActionSheet(n).then(function(t) {
                e.setData({
                    type: t.type,
                    typeTitle: t.name
                });
            }).catch(function(t) {});
            break;

          case "group":
            n = [ {
                type: 0,
                name: "不分组"
            }, {
                type: 1,
                name: "按日期分组"
            } ];
            this.showActionSheet(n).then(function(t) {
                e.setData({
                    group: t.type,
                    groupTitle: t.name
                });
            }).catch(function(t) {});
            break;

          case "startTime":
            this.setData({
                showStartTime: !0
            });
            break;

          case "endTime":
            this.setData({
                showEndTime: !0
            });
        }
    },
    onStartTimeConfirm: function(e) {
        var n = e.detail + 6e5;
        this.setData({
            startTimeCurrentDate: e.detail,
            showStartTime: !1,
            endTimeMinDate: n,
            endTimeMinHour: n,
            endTimeMinMinute: n
        });
        var i = t.formatTimestamp(e.detail);
        this.setData({
            startTime: i
        });
    },
    onStartTimeCancel: function(t) {
        this.setData({
            showStartTime: !1
        });
    },
    onEndTimeConfirm: function(e) {
        this.setData({
            endTimeCurrentDate: e.detail,
            showEndTime: !1
        });
        var n = t.formatTimestamp(e.detail);
        this.setData({
            endTime: n
        });
    },
    onEndTimeCancel: function(t) {
        this.setData({
            showEndTime: !1
        });
    },
    showActionSheet: function(t) {
        var e = this;
        return this.setData({
            infoActions: t,
            infoSheetShow: !0
        }), new Promise(function(t, n) {
            e.onActionSheetClose = function(t) {
                e.setData({
                    infoSheetShow: !1
                }), n("取消按钮被点击或者其他关闭原因");
            }, e.onActionSheetSelect = function(n) {
                var i = n.detail;
                e.setData({
                    infoSheetShow: !1
                }), t(i);
            };
        });
    }
});