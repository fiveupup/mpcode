var t = require("../../@babel/runtime/helpers/interopRequireDefault").default;

require("../../@babel/runtime/helpers/Arrayincludes");

var e = t(require("@vant/weapp/dialog/dialog")), a = require("../../utils/stringutils.js").stringutils, n = require("../../utils/wxutils.js").wxutils, i = getApp();

Page({
    data: {
        app: getApp(),
        userInfo: null,
        supperAuth: !1,
        managerAuth: !1,
        id: null,
        sid: null,
        signStatus: !1,
        timeRangeStatus: !1,
        startTime: null,
        endTime: null,
        signInRoster: null,
        signInRosterType: 0,
        signInRosterTimeRange: null,
        signInRosterDate: "今天",
        infoActions: null,
        actionSheetdescription: null,
        infoSheetShow: !1,
        showSetting: !1,
        showShare: !1,
        inputPassword: null,
        inputPasswordShow: !1,
        radioDialogShow: !1,
        radioDialogActions: null,
        radioDialogTitle: null,
        radioDialogValue: null,
        checkBoxDialogShow: !1,
        checkBoxDialogActions: null,
        checkBoxDialogTitle: null,
        checkBoxDialogValue: null,
        dateDialogShow: !1,
        dateDialogTitle: null,
        dateDialogValue: null,
        dateDialogType: "datetime",
        optionsGrid: [ {
            name: "转发签到",
            icon: "/images/grid/share.png",
            type: "share"
        }, {
            name: "签到记录",
            icon: "/images/grid/man.png",
            type: "man"
        }, {
            name: "导出签到",
            icon: "/images/grid/inexcel.png",
            type: "out"
        }, {
            name: "设置",
            icon: "/images/grid/setting.png",
            type: "setting"
        } ],
        optionsGridNoAuth: [ {
            name: "转发签到",
            icon: "/images/grid/share.png",
            type: "share"
        }, {
            name: "我的记录",
            icon: "/images/grid/man.png",
            type: "manWithMe"
        } ],
        optionsSetting: [ {
            name: "修改签到",
            icon: "/images/grid/edit.png"
        }, {
            name: "人员名单",
            icon: "/images/grid/dan.png"
        }, {
            name: "复制签到",
            icon: "/images/grid/copy.png"
        }, {
            name: "设置管理员",
            icon: "/images/grid/manager.png"
        } ],
        optionsShare: [ {
            type: "share",
            name: "转发好友或者群聊",
            openType: "share"
        }, {
            type: "qrcode",
            name: "生成二维码分享图"
        } ],
        formatter: function(t, e) {
            return "year" === t ? "".concat(e, "年") : "month" === t ? "".concat(e, "月") : "day" === t ? "".concat(e, "日") : "hour" === t ? "".concat(e, "时") : "minute" === t ? "".concat(e, "分") : e;
        }
    },
    onLoad: function(t) {
        if (console.log(t), this.setData({
            id: t.id ? t.id : null,
            sid: t.scene ? t.scene : null,
            info: null
        }), !i.globalData.userInfo) return n.showToast("请登录后再操作"), void this.toLogin();
        this.loadData();
    },
    toLogin: function() {
        n.setCallbackUrl("reLaunch").then(function(t) {
            wx.navigateTo({
                url: "/pages/login/index"
            });
        });
    },
    loadData: function(t) {
        var i = this;
        n.showLoading(), wx.cloud.callFunction({
            name: "quickstartFunctions",
            data: {
                type: "signInInfo",
                id: this.data.id,
                sid: this.data.sid
            }
        }).then(function(o) {
            if (console.log(o), o.result.success) {
                var s = o.result.data;
                if (console.log(s), n.hideLoading(), t && (wx.stopPullDownRefresh(), n.showToast("刷新成功")), 
                s) {
                    if (s.createTime = s.createTime ? a.formatTimestamp(s.createTime) : "", s.startTime = s.startTime ? a.formatTimestamp(s.startTime) : "", 
                    s.endTime = s.endTime ? a.formatTimestamp(s.endTime) : "", s.signStatus && (s.infoTabList = s.signInUpsInfo.infoTabList), 
                    s.roster && s.roster.length > 0) {
                        var r = i.processArrays(s.roster, s.signInRoster);
                        i.setData({
                            signInRoster: r
                        });
                    }
                    var c = new Date(), d = c.getHours(), l = c.getMinutes(), g = "";
                    if (d = (d < 10 ? "0" : "") + d, l = (l < 10 ? "0" : "") + l, 2 == s.type || 4 == s.type) {
                        if (s.timeRangeList && s.timeRangeList.length > 0) {
                            i.setData({
                                signInRosterTimeRange: s.timeRangeList[0].startTime + "-" + s.timeRangeList[0].endTime
                            });
                            var u = d + ":" + l;
                            a.isInTimeRanges(u, s.timeRangeList) ? g = s.timeRangeList.map(function(t) {
                                return "".concat(t.startTime, " 到 ").concat(t.endTime);
                            }).join("，") : (g = s.timeRangeList.map(function(t) {
                                return "".concat(t.startTime, " 到 ").concat(t.endTime);
                            }).join("，"), setTimeout(function() {
                                e.default.alert({
                                    title: "当前时间不可签到",
                                    message: "可签到时间段为：".concat(g)
                                }).then(function() {});
                            }, 100));
                        }
                        i.setData({
                            formattedTimeRanges: g
                        });
                    }
                    i.setData({
                        id: s._id,
                        sid: s.sid,
                        info: s,
                        timeRangeStatus: !!s.timeRangeList && a.isInTimeRanges(d + ":" + l, s.timeRangeList),
                        signStatus: s.signStatus,
                        supperAuth: s.supperAuth,
                        managerAuth: s.managerAuth
                    });
                } else n.showToast(o.result.errMsg ? o.result.errMsg : "加载失败");
            } else n.showToast(o.result.errMsg ? o.result.errMsg : "加载失败");
        }).catch(function(e) {
            n.hideLoading(), t && (wx.stopPullDownRefresh(), n.showToast("刷新失败")), console.error("加载数据失败", e);
        });
    },
    withPasswordSignInJoin: function() {
        return this.data.inputPassword ? this.data.inputPassword != this.data.info.password ? (this.setData({
            inputPassword: null
        }), n.showToast("口令错误")) : void this.signInJoin() : (this.setData({
            inputPassword: null
        }), n.showToast("请输入口令"));
    },
    signInJoin: function() {
        if (this.data.info.infoTabList && this.data.info.infoTabList.length > 0) return i.globalData.infoTabList = this.data.info.infoTabList, 
        this.data.info.roster && this.data.info.roster.length > 0 && (i.globalData.roster = this.data.info.roster), 
        void wx.navigateTo({
            url: "/pages/infoEdit/index?type=0"
        });
        this.runSignIn();
    },
    runSignIn: function() {
        var t = this, e = this.data.id, a = i.globalData.infoTabList || [];
        console.log(a), i.globalData.infoTabList = null, n.showLoading("签到中"), wx.cloud.callFunction({
            name: "quickstartFunctions",
            data: {
                type: "signInJoin",
                password: this.data.inputPassword,
                infoTabList: a,
                id: e
            }
        }).then(function(e) {
            e.result.success ? (n.showToast("签到成功"), t.setData({
                signStatus: !0
            }), wx.navigateTo({
                url: "/pages/signInfo/success"
            })) : (n.showToast(e.result.errMsg), e.result.refresh && setTimeout(function() {
                t.refresh();
            }, 1e3)), console.log();
        }).catch(function(t) {
            n.hideLoading(), n.showToast("签到失败"), console.error("加载数据失败", t);
        });
    },
    onClickSignIn: function() {
        var t = this;
        e.default.confirm({
            title: "是否进行签到"
        }).then(function() {
            t.data.info.address.address ? (n.showLoading("加载中"), n.getLocation().then(function(e) {
                console.log("经纬度信息", e);
                var i = e.latitude, o = e.longitude, s = t.data.info.address.latitude, r = t.data.info.address.longitude, c = a.getDistance(i, o, s, r);
                if (console.log("需要校验位置", c), n.hideLoading(), !(c <= t.data.info.minRange + Math.floor(130 * Math.random()) + 20)) return wx.reportEvent("info_sign", {
                    type: "address_faile"
                }), n.showToast("不在签到范围，签到失败");
                t.data.info.password ? t.data.inputPassword || t.setData({
                    inputPasswordShow: !0
                }) : t.signInJoin();
            }).catch(function(t) {
                wx.reportEvent("info_sign", {
                    type: "address_err"
                }), n.hideLoading(), n.showToast("获取位置信息失败"), console.log("获取位置信息失败", t);
            })) : (console.log("无需校验位置"), t.data.info.password ? t.data.inputPassword || t.setData({
                inputPasswordShow: !0
            }) : t.signInJoin());
        }).catch(function() {});
    },
    onClickDel: function() {
        var t = this, a = this.data.id;
        e.default.confirm({
            title: "是否删除签到",
            message: "删除后所有数据将会丢失且不可恢复"
        }).then(function() {
            if (!t.data.info.supperAuth) return n.showToast("仅创建者可删除");
            n.showLoading("删除中"), wx.cloud.callFunction({
                name: "quickstartFunctions",
                data: {
                    type: "signInDel",
                    id: a
                }
            }).then(function(t) {
                t.result.success ? (n.showToast("删除成功"), setTimeout(function() {
                    i.globalData.delId = a, wx.navigateBack();
                }, 500)) : n.showToast(t.result.errMsg), console.log();
            }).catch(function(t) {
                n.hideLoading(), n.showToast("删除失败"), console.error("加载数据失败", t);
            });
        }).catch(function() {});
    },
    qrCodeHide: function() {
        this.setData({
            qrCodeShow: !1
        });
    },
    handleFieldInput: function(t) {
        var e = t.currentTarget.dataset.index, a = t.detail, n = this.data.info.infoTabList;
        n[e].value = a, this.setData({
            infoTabList: n
        });
    },
    onReady: function() {},
    onShow: function() {
        var t = wx.getStorageSync("userInfo");
        t ? this.setData({
            userInfo: t
        }) : this.setData({
            userInfo: null
        }), i.globalData.infoTabList && this.runSignIn();
    },
    showDateDialog: function(t, e) {
        var a = this;
        return this.setData({
            dateDialogValue: "time" === t ? "12:00" : Math.floor(Date.now()),
            dateDialogType: t,
            dateDialogTitle: e,
            dateDialogShow: !0
        }), new Promise(function(t, e) {
            a.onDateDialogCancel = function(t) {
                a.setData({
                    dateDialogShow: !1
                }), e("取消按钮被点击或者其他关闭原因");
            }, a.onDateDialogConfirm = function(e) {
                var n = e.detail;
                console.log(n), a.setData({
                    dateDialogShow: !1
                }), t(n);
            };
        });
    },
    showActionSheet: function(t, e) {
        var a = this;
        return this.setData({
            infoActions: t,
            actionSheetdescription: e,
            infoSheetShow: !0
        }), new Promise(function(t, e) {
            a.onActionSheetClose = function(t) {
                a.setData({
                    infoSheetShow: !1
                }), e("取消按钮被点击或者其他关闭原因");
            }, a.onActionSheetSelect = function(e) {
                var n = e.detail;
                a.setData({
                    infoSheetShow: !1
                }), t(n);
            };
        });
    },
    onClickType: function(t) {
        var e = this;
        switch (t.currentTarget.dataset.type) {
          case "share":
            this.setData({
                showShare: !0
            });
            break;

          case "qrCode":
            wx.navigateTo({
                url: "/pages/poster/index?sid=".concat(this.data.info.sid, "&title=").concat(this.data.info.title)
            });
            break;

          case "out":
            wx.reportEvent("info_sign", {
                type: "sign_excel_out_click"
            }), wx.navigateTo({
                url: "/pages/signInfo/outExcel?id=".concat(this.data.id, "&startTime=").concat(this.data.info.startTime, "&endTime=").concat(this.data.info.endTime)
            });
            break;

          case "qrCodeDown":
          case "qrCodeShareFriends":
            n.base64ImageToTemp(this.data.qrcode).then(function(t) {
                console.log("成功，临时文件路径:", t), wx.showShareImageMenu({
                    path: t,
                    success: function(t) {
                        console.log("分享成功：", t), n.showToast("分享成功");
                    },
                    fail: function(t) {
                        console.log("分享失败：", t), n.showToast("分享取消");
                    }
                });
            }).catch(function(t) {
                console.error("失败，错误信息:", t), n.showToast("分享失败");
            });
            break;

          case "setting":
            this.setData({
                showSetting: !0
            });
            break;

          case "man":
            wx.reportEvent("info_sign", {
                type: "sign_man_list_manager"
            }), wx.navigateTo({
                url: "/pages/signInfo/man?id=" + this.data.id + "&type=0"
            });
            break;

          case "manWithMe":
            wx.reportEvent("info_sign", {
                type: "sign_man_list_me"
            }), wx.navigateTo({
                url: "/pages/signInfo/man?id=" + this.data.id + "&type=1"
            });
            break;

          case "copyPassword":
            wx.reportEvent("info_sign", {
                type: "sign_copy_password"
            }), wx.setClipboardData({
                data: this.data.info.password,
                success: function(t) {
                    n.showToast("复制成功");
                }
            });
            break;

          case "rosterType":
            this.showActionSheet([ {
                type: 0,
                name: "全部"
            }, {
                type: 1,
                name: "已签到"
            }, {
                type: 2,
                name: "未签到"
            } ], "").then(function(t) {
                e.setData({
                    signInRosterType: t.type
                });
            }).catch(function(t) {});
            break;

          case "rosterDate":
            this.showDateDialog("date", "请选择日期").then(function(t) {
                console.log(t), n.showLoading("加载中"), wx.cloud.callFunction({
                    name: "quickstartFunctions",
                    data: {
                        type: "signInRosterRecord",
                        id: e.data.id,
                        timeRange: e.data.signInRosterTimeRange,
                        date: t
                    }
                }).then(function(i) {
                    if (n.hideLoading(), i.result.success) {
                        var o = e.processArrays(e.data.info.roster, i.result.data), s = e.data.info;
                        s.signInRoster = i.result.data, e.setData({
                            signInRosterDate: a.formatTimestamp(t).substring(0, 10),
                            signInRoster: o,
                            info: s
                        });
                    } else n.showToast(i.result.errMsg), i.result.refresh && setTimeout(function() {
                        e.refresh();
                    }, 1e3);
                }).catch(function(t) {
                    n.hideLoading(), n.showToast("加载失败");
                });
            }).catch(function(t) {});
            break;

          case "rosterTimeRange":
            var i = [];
            this.data.info.timeRangeList.forEach(function(t, e) {
                i.push({
                    index: e,
                    name: t.startTime + "-" + t.endTime
                });
            }), this.showActionSheet(i, "请选择签到时段").then(function(t) {
                n.showLoading("加载中"), wx.cloud.callFunction({
                    name: "quickstartFunctions",
                    data: {
                        type: "signInRosterRecord",
                        id: e.data.id,
                        timeRange: t.name,
                        date: "今天" == e.data.signInRosterDate ? "" : new Date(e.data.signInRosterDate).getTime()
                    }
                }).then(function(a) {
                    if (n.hideLoading(), a.result.success) {
                        var i = e.processArrays(e.data.info.roster, a.result.data), o = e.data.info;
                        o.signInRoster = a.result.data, e.setData({
                            signInRosterTimeRange: t.name,
                            signInRoster: i,
                            info: o
                        });
                    } else n.showToast(a.result.errMsg), a.result.refresh && setTimeout(function() {
                        e.refresh();
                    }, 1e3);
                }).catch(function(t) {
                    n.hideLoading(), n.showToast("加载失败");
                });
            }).catch(function(t) {});
        }
    },
    processArrays: function(t, e) {
        var a = new Set(t), n = [];
        return a.forEach(function(t) {
            var a = {
                name: t,
                check: e.includes(t)
            };
            n.push(a);
        }), n;
    },
    showShareCancel: function() {
        this.setData({
            showShare: !1
        });
    },
    showShareClick: function(t) {
        this.showShareCancel(), "qrcode" == t.detail.type ? (wx.reportEvent("info_sign", {
            type: "sign_share_qrcode"
        }), wx.navigateTo({
            url: "/pages/poster/index?sid=".concat(this.data.info.sid, "&title=").concat(this.data.info.title)
        })) : wx.reportEvent("info_sign", {
            type: "sign_share_card"
        });
    },
    showSettingCancel: function() {
        this.setData({
            showSetting: !1
        });
    },
    showSettingClick: function(t) {
        console.log("点击图标", t.detail.index);
        var e = t.detail.index;
        switch (this.setData({
            showSetting: !1
        }), e) {
          case 0:
            wx.reportEvent("info_sign", {
                type: "sign_update"
            }), i.globalData.saveData = this.data.info, wx.navigateTo({
                url: "/pages/updateSign/index"
            });
            break;

          case 1:
            if (wx.reportEvent("info_sign", {
                type: "sign_roster"
            }), !this.data.info.roster || 0 == this.data.info.roster.length) return n.showToast("暂未设置人员名单");
            wx.showModal({
                title: "签到人员名单 共(".concat(this.data.info.roster.length, ")人"),
                content: this.data.info.roster.join(","),
                showCancel: !1
            });
            break;

          case 2:
            wx.reportEvent("info_sign", {
                type: "sign_copy"
            }), console.log(this.data.info), i.globalData.saveData = this.data.info, wx.navigateTo({
                url: "/pages/createSign/index"
            });
            break;

          case 3:
            wx.reportEvent("info_sign", {
                type: "sign_manager"
            }), this.data.info.supperAuth ? wx.navigateTo({
                url: "/pages/managerSetting/index?id=" + this.data.id
            }) : n.showToast("仅创建者可编辑管理员");
        }
    },
    onPullDownRefresh: function() {
        this.refresh();
    },
    refresh: function() {
        if (!i.globalData.userInfo) return n.showToast("请登录后再操作"), void this.toLogin();
        this.loadData(!0);
    },
    onShareAppMessage: function() {
        var t = this;
        return {
            promise: new Promise(function(e) {
                n.showLoading("加载中"), setTimeout(function() {
                    n.hideLoading(), e({
                        title: "".concat(t.data.info.title),
                        path: "/pages/signInfo/index?id=".concat(t.data.id),
                        imageUrl: "/images/zhuan_bg.png"
                    });
                }, 500);
            })
        };
    }
});