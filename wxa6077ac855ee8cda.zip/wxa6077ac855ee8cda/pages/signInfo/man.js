(0, require("../../@babel/runtime/helpers/interopRequireDefault").default)(require("@vant/weapp/dialog/dialog"));

var t = require("../../utils/stringutils.js").stringutils, e = require("../../utils/wxutils.js").wxutils, a = getApp();

Page({
    data: {
        id: null,
        currentPage: 0,
        pageSize: 10,
        list: null,
        sortType: 0,
        count: 0,
        infoActions: null,
        actionSheetdescription: null,
        infoSheetShow: !1,
        option: [ {
            text: "默认排序",
            value: 0
        }, {
            text: "最新签到",
            value: -1
        }, {
            text: "最早签到",
            value: 1
        } ]
    },
    onLoad: function(t) {
        this.setData({
            id: t.id,
            mode: t.type
        }), this.loadMoreData();
    },
    loadMoreData: function(a) {
        var o = this;
        e.showLoading(), wx.cloud.callFunction({
            name: "quickstartFunctions",
            data: {
                type: "signInMan",
                id: this.data.id,
                currentPage: this.data.currentPage,
                pageSize: this.data.pageSize,
                sortType: this.data.sortType,
                mode: this.data.mode
            }
        }).then(function(n) {
            var i = n.result.list;
            if (n.result.allCount && o.setData({
                count: n.result.allCount
            }), console.log(i), e.hideLoading(), a && (o.setData({
                list: null
            }), wx.stopPullDownRefresh(), e.showToast("刷新成功")), i.length > 0) {
                if (i.forEach(function(e) {
                    e.createTime = t.formatTimestamp(e.createTime);
                }), o.data.list) s = o.data.list.concat(i); else var s = i;
                o.setData({
                    list: s,
                    currentPage: o.data.currentPage + 1
                });
            } else console.log("数据已加载完毕"), 0 != o.data.currentPage && e.showToast("暂无更多数据");
        }).catch(function(t) {
            e.hideLoading(), a && (o.setData({
                list: null
            }), wx.stopPullDownRefresh(), e.showToast("刷新失败")), console.error("加载数据失败", t);
        });
    },
    onClickTool: function(t) {
        var o = this, n = t.currentTarget.dataset.type, i = t.currentTarget.dataset.id, s = t.currentTarget.dataset.index, l = this.data.list, r = l[s], u = "";
        0 == n && (u = [ {
            type: 0,
            name: "修改记录"
        }, {
            type: 1,
            name: "删除记录"
        } ]), 1 == n && (u = [ {
            type: 1,
            name: "删除记录"
        } ]), this.showActionSheet(u, "").then(function(t) {
            console.log(t.type), 0 == t.type && (a.globalData.infoTabList = r.infoTabList, wx.navigateTo({
                url: "/pages/infoEdit/index?type=1&id=" + i
            })), 1 == t.type && wx.showModal({
                title: "提示",
                content: "签到记录删除后将不可恢复，确定要删除吗？",
                complete: function(t) {
                    t.confirm && (e.showLoading("删除中"), wx.cloud.callFunction({
                        name: "quickstartFunctions",
                        data: {
                            type: "signInManEdit",
                            mode: "del",
                            id: i
                        }
                    }).then(function(t) {
                        t.result.success ? (e.showToast("删除成功"), l.splice(s, 1), o.setData({
                            list: l,
                            count: o.data.count - 1
                        })) : (e.showToast(t.result.errMsg), t.result.refresh && setTimeout(function() {
                            o.refresh();
                        }, 1e3)), console.log();
                    }).catch(function(t) {
                        e.hideLoading(), e.showToast("签到失败"), console.error("加载数据失败", t);
                    }));
                }
            });
        }).catch(function(t) {});
    },
    onClickExcelOut: function() {
        return e.showToast("此功能维护中");
    },
    onClickCopyUuid: function(t) {
        wx.setClipboardData({
            data: t.currentTarget.dataset.uuid,
            success: function(t) {
                e.showToast("复制成功");
            }
        });
    },
    dropdownChange: function(t) {
        this.refresh();
    },
    showActionSheet: function(t, e) {
        var a = this;
        return this.setData({
            infoActions: t,
            actionSheetdescription: e,
            infoSheetShow: !0
        }), new Promise(function(t, e) {
            a.onActionSheetClose = function(t) {
                a.setData({
                    infoSheetShow: !1
                }), e("取消按钮被点击或者其他关闭原因");
            }, a.onActionSheetSelect = function(e) {
                var o = e.detail;
                a.setData({
                    infoSheetShow: !1
                }), t(o);
            };
        });
    },
    onReady: function() {},
    refresh: function() {
        this.setData({
            currentPage: 0
        }), this.loadMoreData(!0);
    },
    onShow: function() {
        if (a.globalData.infoTabListEdit) {
            var t = a.globalData.infoTabListEdit, e = a.globalData.infoTabListEditId;
            console.log("更新", a.globalData.infoTabListEdit, a.globalData.infoTabListEditId), 
            a.globalData.infoTabListEdit = null, a.globalData.infoTabListEditId = null;
            var o = this.data.list, n = o.find(function(t) {
                return t._id === e;
            });
            n && (console.log(n), n.infoTabList = t, this.setData({
                list: o
            }));
        }
    },
    onHide: function() {},
    onUnload: function() {},
    onPullDownRefresh: function() {
        this.refresh();
    },
    onReachBottom: function() {
        this.loadMoreData();
    },
    onShareAppMessage: function() {}
});