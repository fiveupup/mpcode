require("../../utils/stringutils.js").stringutils;

var t = require("../../utils/wxutils.js").wxutils;

Page({
    data: {
        url: null
    },
    onLoad: function(t) {
        this.setData({
            url: t.url
        });
    },
    copy: function() {
        wx.setClipboardData({
            data: this.data.url,
            success: function(i) {
                t.showToast("复制成功");
            }
        });
    },
    down: function() {
        var i = this;
        t.showLoading("下载中"), this.data.tempFilePath ? wx.shareFileMessage({
            filePath: this.data.tempFilePath,
            success: function() {
                t.hideLoading();
            },
            fail: function() {
                t.hideLoading(), t.showToast("下载失败");
            }
        }) : wx.downloadFile({
            url: this.data.url,
            success: function(s) {
                if (200 === s.statusCode) {
                    var a = s.tempFilePath;
                    i.setData({
                        tempFilePath: a
                    }), wx.shareFileMessage({
                        filePath: a,
                        success: function() {
                            t.hideLoading();
                        },
                        fail: function() {
                            t.hideLoading(), t.showToast("下载失败");
                        }
                    });
                }
            }
        });
    }
});