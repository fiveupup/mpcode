require("../../utils/stringutils.js").stringutils;

var e = require("../../utils/wxutils.js").wxutils, t = getApp();

Page({
    data: {},
    share: function() {
        wx.reportEvent("home_share");
    },
    jumpWebview: function() {
        wx.reportEvent("home_help"), wx.navigateTo({
            url: "/pages/webview/index?url=https://qiner520.com/help/applet-signIn"
        });
    },
    jumpPage: function(a) {
        if (!t.globalData.userInfo) return e.showToast("请登录后再操作"), void e.setCallbackUrl("switchTab").then(function(e) {
            wx.navigateTo({
                url: "/pages/login/index"
            });
        });
        wx.reportEvent("home_type", {
            url: a.currentTarget.dataset.page
        }), wx.navigateTo({
            url: a.currentTarget.dataset.page
        });
    },
    onClickDatabase: function(e) {
        var t = this;
        wx.showLoading({
            title: ""
        }), wx.cloud.callFunction({
            name: "quickstartFunctions",
            config: {
                env: this.data.selectedEnv.envId
            },
            data: {
                type: "createCollection"
            }
        }).then(function(a) {
            a.result.success && t.setData({
                haveCreateCollection: !0
            }), t.setData({
                powerList: e
            }), wx.hideLoading();
        }).catch(function(e) {
            console.log(e), t.setData({
                showUploadTip: !0
            }), wx.hideLoading();
        });
    },
    onShareAppMessage: function() {
        return {
            promise: new Promise(function(t) {
                e.showLoading("加载中"), setTimeout(function() {
                    e.hideLoading(), t({
                        title: "推荐给你一个好用的签到助手",
                        path: "/pages/index/index",
                        imageUrl: "/images/share_bg.png"
                    });
                }, 500);
            })
        };
    }
});