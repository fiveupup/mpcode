var t = (0, require("../../@babel/runtime/helpers/interopRequireDefault").default)(require("@vant/weapp/dialog/dialog")), o = require("../../utils/stringutils.js").stringutils, a = require("../../utils/wxutils.js").wxutils;

getApp();

Page({
    data: {
        id: "",
        inputId: "",
        list: "",
        dialogShow: !1,
        loadEd: !1
    },
    onLoad: function(t) {
        this.setData({
            id: t.id
        }), this.loadMoreData();
    },
    loadMoreData: function(t) {
        var n = this;
        a.showLoading(), wx.cloud.callFunction({
            name: "quickstartFunctions",
            data: {
                type: "signInManager",
                id: this.data.id
            }
        }).then(function(e) {
            var i = e.result.list;
            console.log(i), a.hideLoading(), t && (n.setData({
                list: null
            }), wx.stopPullDownRefresh(), a.showToast("刷新成功")), i.length > 0 ? (i.forEach(function(t) {
                t.createTime = o.formatTimestamp(t.createTime);
            }), n.setData({
                list: i
            })) : console.log("数据已加载完毕"), n.setData({
                loadEd: !0
            });
        }).catch(function(o) {
            a.hideLoading(), t && (n.setData({
                list: null
            }), wx.stopPullDownRefresh(), a.showToast("刷新失败")), console.error("加载数据失败", o);
        });
    },
    toDel: function(o) {
        var n = this, e = o.target.dataset.openid;
        if (!e) return a.showToast("参数错误");
        t.default.confirm({
            title: "提示",
            message: "是否移除管理员"
        }).then(function() {
            a.showLoading("删除中"), wx.cloud.callFunction({
                name: "quickstartFunctions",
                data: {
                    type: "signInManagerDel",
                    id: n.data.id,
                    _openid: e
                }
            }).then(function(t) {
                if (t.result.success) {
                    a.showToast("删除成功");
                    var o = n.data.list;
                    o = o.filter(function(t) {
                        return t._openid !== e;
                    }), n.setData({
                        list: o.length > 0 ? o : null
                    });
                } else a.showToast(t.result.errMsg);
                console.log();
            }).catch(function(t) {
                a.hideLoading(), a.showToast("删除失败"), console.error("加载数据失败", t);
            });
        }).catch(function() {}), console.log(o.target.dataset.openid);
    },
    toAdd: function() {
        this.setData({
            dialogShow: !0
        });
    },
    withManegerAdd: function() {
        var t = this;
        if (!this.data.inputId) return this.setData({
            inputId: null
        }), a.showToast("请输入ID");
        a.showLoading("添加中"), wx.cloud.callFunction({
            name: "quickstartFunctions",
            data: {
                type: "signInManagerAdd",
                id: this.data.id,
                uuid: this.data.inputId
            }
        }).then(function(o) {
            o.result.success ? (a.showToast("添加成功"), t.setData({
                inputId: null
            }), t.refresh()) : a.showToast(o.result.errMsg), console.log();
        }).catch(function(t) {
            a.hideLoading(), a.showToast("添加失败"), console.error("加载数据失败", t);
        });
    },
    refresh: function() {
        this.loadMoreData(!0);
    },
    onReady: function() {},
    onShow: function() {},
    onPullDownRefresh: function() {
        this.refresh();
    },
    onReachBottom: function() {},
    onShareAppMessage: function() {}
});