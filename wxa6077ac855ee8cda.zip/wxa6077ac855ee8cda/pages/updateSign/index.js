var t = require("../../@babel/runtime/helpers/interopRequireDefault").default, e = require("../../@babel/runtime/helpers/defineProperty"), a = require("../../@babel/runtime/helpers/toConsumableArray"), i = (t(require("@vant/weapp/dialog/dialog")), 
require("../../utils/stringutils.js").stringutils), s = require("../../utils/wxutils.js").wxutils, n = getApp();

Page({
    data: {
        id: null,
        type: 1,
        title: null,
        titleErrMsg: null,
        desc: null,
        descErrMsg: null,
        showStartTime: !1,
        startTimeCurrentDate: null,
        startTime: null,
        startTimeMinDate: null,
        startTimeMinHour: null,
        startTimeMinMinute: null,
        showEndTime: !1,
        endTimeCurrentDate: null,
        endTime: null,
        endTimeMinDate: null,
        endTimeMinHour: null,
        endTimeMinMinute: null,
        timeRangeChecked: !1,
        timeRangeList: [ {
            startTime: "00:00",
            endTime: "23:59"
        } ],
        passwordChecked: !1,
        password: null,
        addressChecked: null,
        address: null,
        minRange: 500,
        minRangeErrMsg: null,
        rosterChecked: null,
        roster: null,
        infoChecked: !1,
        infoSheetShow: !1,
        dateDialogShow: !1,
        dateDialogTitle: null,
        dateDialogValue: null,
        dateDialogMinHour: 0,
        dateDialogMaxHour: 23,
        dateDialogMinMinute: 0,
        dateDialogMaxMinute: 59,
        infoTabList: [ {
            title: "姓名",
            check: !0,
            type: 1,
            model: "text"
        }, {
            title: "手机号",
            check: !1,
            type: 2,
            model: "text"
        }, {
            title: "性别",
            check: !1,
            type: 1,
            model: "radio",
            chooseList: [ "男", "女" ]
        } ],
        infoActions: null,
        actionSheetdescription: null,
        diyInfoDialogShow: !1,
        createIng: !1,
        moreFun: !1,
        formatter: function(t, e) {
            return "year" === t ? "".concat(e, "年") : "month" === t ? "".concat(e, "月") : "day" === t ? "".concat(e, "日") : "hour" === t ? "".concat(e, "时") : "minute" === t ? "".concat(e, "分") : e;
        },
        textareaMinHeight: {
            minHeight: 100
        }
    },
    onLoad: function(t) {
        if (n.globalData.saveData) {
            console.log(n.globalData.saveData);
            var e = n.globalData.saveData, a = Date.parse(e.startTime), r = Date.parse(e.endTime), o = a + 6e5;
            this.setData({
                id: e._id,
                type: e.type,
                title: e.title,
                desc: e.desc,
                startTime: i.formatTimestamp(a),
                endTime: i.formatTimestamp(r),
                passwordChecked: !!e.password,
                password: e.password,
                addressChecked: !!e.address.address,
                address: e.address,
                minRange: 0 != e.minRange ? e.minRange : 500,
                timeRangeChecked: !!(e.timeRangeList && e.timeRangeList.length > 0),
                timeRangeList: e.timeRangeList,
                rosterChecked: !!(e.roster && e.roster.length > 0),
                roster: e.roster,
                startTimeCurrentDate: a,
                endTimeCurrentDate: r,
                endTimeMinDate: o,
                endTimeMinHour: o,
                endTimeMinMinute: o
            }), n.globalData.saveData = null, wx.setNavigationBarTitle({
                title: 1 == this.data.type ? "修改临时签到" : 2 == this.data.type ? "修改长期签到" : 3 == this.data.type ? "修改自由签到" : 4 == this.data.type ? "修改考勤签到" : "修改签到"
            });
        } else s.showToast("加载错误");
    },
    onShow: function() {
        n.globalData.saveRosterData && (this.setData({
            roster: n.globalData.saveRosterData
        }), n.globalData.saveRosterData = null);
    },
    showDateDialog: function(t, e, i, s) {
        var n = this, r = a(this.data.timeRangeList);
        if ("start" == e) {
            var o = r[i].endTime.split(":"), d = parseInt(o[0], 10);
            0 === (l = parseInt(o[1], 10)) && (d -= 1, l = 59), this.setData({
                dateDialogValue: t,
                dateDialogTitle: s,
                dateDialogMaxHour: d,
                dateDialogMaxMinute: l,
                dateDialogMinHour: 0,
                dateDialogMinMinute: 0,
                dateDialogShow: !0
            });
        }
        if ("end" == e) {
            o = r[i].startTime.split(":"), d = parseInt(o[0], 10);
            var l = parseInt(o[1], 10);
            this.setData({
                dateDialogValue: t,
                dateDialogTitle: s,
                dateDialogMaxHour: 23,
                dateDialogMaxMinute: 59,
                dateDialogMinHour: d,
                dateDialogMinMinute: l,
                dateDialogShow: !0
            });
        }
        return new Promise(function(t, e) {
            n.onDateDialogCancel = function(t) {
                n.setData({
                    dateDialogShow: !1
                }), e("取消按钮被点击或者其他关闭原因");
            }, n.onDateDialogConfirm = function(e) {
                var a = e.detail;
                console.log(a), n.setData({
                    dateDialogShow: !1
                }), t(a);
            };
        });
    },
    onTimeRangeTimeClick: function(t) {
        var e = this;
        console.log("点击");
        var i = t.currentTarget.dataset.index, s = t.currentTarget.dataset.type;
        this.showDateDialog("00:00", s, i, "请选择 时段".concat(i + 1, " ").concat("start" == s ? "开始时间" : "结束时间")).then(function(t) {
            var n = a(e.data.timeRangeList);
            "start" == s ? n[i].startTime = t : n[i].endTime = t, e.setData({
                timeRangeList: n
            });
        }).catch(function(t) {});
    },
    onTimeRangeDelClick: function(t) {
        var e = t.currentTarget.dataset.index, a = this.data.timeRangeList;
        a.splice(e, 1), this.setData({
            timeRangeList: a
        });
    },
    onClickType: function(t) {
        var e = this;
        switch (t.currentTarget.dataset.type) {
          case "startTime":
            this.setData({
                showStartTime: !0
            });
            break;

          case "endTime":
            this.setData({
                showEndTime: !0
            });
            break;

          case "addressChoose":
            wx.chooseLocation({
                success: function(t) {
                    var a = t.latitude, i = t.longitude, s = t.name, n = t.address;
                    e.setData({
                        address: {
                            latitude: a,
                            longitude: i,
                            name: s,
                            address: n
                        }
                    }), console.log(a, i, s, n);
                },
                fail: function(t) {
                    console.error(t), wx.showToast({
                        title: "位置选择失败",
                        duration: 2e3,
                        icon: "none"
                    });
                }
            });
            break;

          case "saveSignIn":
            if (!this.data.title || 0 == this.data.title.length) return this.setData({
                titleErrMsg: "请输入标题"
            }), void s.showToast("请输入标题");
            if (this.data.addressChecked) {
                if (isNaN(this.data.minRange)) return this.setData({
                    minRangeErrMsg: "签到范围错误,请输入不小于50的阿拉伯数字"
                }), void s.showToast("签到范围错误,请输入不小于50的阿拉伯数字");
                if (this.data.minRange < 50) return this.setData({
                    minRangeErrMsg: "签到范围最小50米"
                }), void s.showToast("签到范围最小50米");
                if (!this.data.address || !this.data.address.address) return s.showToast("请选择地点");
            }
            if (Date.parse(this.data.startTime) > Date.parse(this.data.endTime)) return s.showToast("开始时间不能大于结束时间");
            if (Math.floor(this.data.endTimeCurrentDate / 1e3) <= Math.floor(this.data.startTimeCurrentDate / 1e3) + 600) return s.showToast("结束时间不能小于开始时间");
            if ((2 == this.data.type || 4 == this.data.type) && this.data.timeRangeChecked && i.checkTimeRangesOverlap(this.data.timeRangeList)) return s.showToast("时间区间不能有重叠");
            var a = {
                id: this.data.id,
                title: this.data.title,
                desc: this.data.desc,
                type: this.data.type,
                startTime: this.data.startTimeCurrentDate,
                endTime: this.data.endTimeCurrentDate,
                password: this.data.passwordChecked ? this.data.password : "",
                address: this.data.addressChecked ? this.data.address : "",
                minRange: this.data.addressChecked ? this.data.minRange : 0,
                timeRangeList: 2 == this.data.type || 4 == this.data.type ? this.data.timeRangeList : [],
                roster: this.data.rosterChecked && this.data.roster && this.data.roster.length > 0 ? this.data.roster : []
            };
            if (this.data.createIng) return;
            wx.showLoading({
                title: "保存中"
            }), this.setData({
                createIng: !0
            }), wx.cloud.callFunction({
                name: "quickstartFunctions",
                data: {
                    type: "signInUpdate",
                    data: a
                }
            }).then(function(t) {
                t.result.success ? wx.showModal({
                    title: "温馨提示",
                    content: "签到修改保存成功",
                    showCancel: !1,
                    complete: function(t) {
                        t.confirm && (n.globalData.building = !0, wx.switchTab({
                            url: "/pages/signList/index"
                        }));
                    }
                }) : s.showToast(t.result.errMsg), e.setData({
                    createIng: !1
                }), s.hideLoading();
            }).catch(function(t) {
                e.setData({
                    createIng: !1
                }), s.hideLoading(), s.showToast("保存失败"), console.error("加载数据失败", t);
            });
            break;

          case "timeRangeAdd":
            var r = this.data.timeRangeList;
            r.push({
                startTime: "00:00",
                endTime: "23:59"
            }), this.setData({
                timeRangeList: r
            });
            break;

          case "rosterChoose":
            n.globalData.saveRosterData = this.data.roster, wx.navigateTo({
                url: "/pages/rosterEdit/index"
            });
        }
    },
    onStartTimeConfirm: function(t) {
        var a, s = t.detail + 6e5;
        this.setData((a = {
            startTimeCurrentDate: t.detail,
            showStartTime: !1
        }, e(a, "showStartTime", !1), e(a, "endTimeMinDate", s), e(a, "endTimeMinHour", s), 
        e(a, "endTimeMinMinute", s), a));
        var n = i.formatTimestamp(t.detail);
        this.setData({
            startTime: n
        });
    },
    onStartTimeCancel: function(t) {
        this.setData({
            showStartTime: !1
        });
    },
    onEndTimeConfirm: function(t) {
        this.setData({
            endTimeCurrentDate: t.detail,
            showEndTime: !1
        });
        var e = i.formatTimestamp(t.detail);
        this.setData({
            endTime: e
        });
    },
    onEndTimeCancel: function(t) {
        this.setData({
            showEndTime: !1
        });
    },
    onTimeRangeCheckedChange: function(t) {
        var e = t.detail;
        this.setData({
            timeRangeChecked: e
        });
    },
    onPasswordCheckedChange: function(t) {
        var e = t.detail;
        e ? this.setData({
            passwordChecked: e,
            password: i.generateRandomNumber(6)
        }) : this.setData({
            passwordChecked: e,
            password: null
        });
    },
    onAddressCheckedChange: function(t) {
        var e = t.detail;
        this.setData({
            addressChecked: e
        });
    },
    onInputFocus: function() {
        this.setData({
            titleErrMsg: null,
            descErrMsg: null,
            minRangeErrMsg: null
        });
    },
    onInfoCheckedChange: function(t) {
        var e = t.detail;
        this.setData({
            infoChecked: e
        });
    },
    onRosterCheckedChange: function(t) {
        var e = t.detail;
        this.setData({
            rosterChecked: e
        });
    }
});