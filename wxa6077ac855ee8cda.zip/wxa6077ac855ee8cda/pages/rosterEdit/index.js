require("../../utils/stringutils.js").stringutils, require("../../utils/wxutils.js").wxutils;

var t = getApp();

Page({
    data: {
        app: getApp(),
        rosterTxt: "",
        textareaMinHeight: {
            minHeight: 200
        }
    },
    onLoad: function(e) {
        t.globalData.saveRosterData && this.setData({
            rosterTxt: t.globalData.saveRosterData.join("\n")
        });
    },
    save: function() {
        if (void 0 !== this.data.rosterTxt || null !== this.data.rosterTxt || "" !== this.data.rosterTxt) {
            var e = this.data.rosterTxt.split("\n").filter(function(t) {
                return null != t && "" !== t;
            }), a = function(t) {
                for (var e = {}, a = 0; a < t.length; a++) {
                    if (e[t[a]]) return {
                        duplicate: t[a],
                        index: a
                    };
                    if (e[t[a]] = !0, t[a].length > 10) return {
                        exceedingLength: t[a],
                        index: a
                    };
                }
                return null;
            }(e);
            null !== a ? a.duplicate ? wx.showModal({
                title: "提示",
                content: "".concat(a.duplicate, " 姓名重复，请修改"),
                showCancel: !1
            }) : a.exceedingLength && wx.showModal({
                title: "提示",
                content: "".concat(a.exceedingLength, " 姓名超出长度限制，请修改"),
                showCancel: !1
            }) : wx.showModal({
                title: "提示",
                content: "是否保存当前名单，共(".concat(e.length, ")人"),
                complete: function(a) {
                    a.confirm && (wx.reportEvent("roster", {
                        type: "edit"
                    }), t.globalData.saveRosterData = e, wx.navigateBack());
                }
            });
        }
    }
});