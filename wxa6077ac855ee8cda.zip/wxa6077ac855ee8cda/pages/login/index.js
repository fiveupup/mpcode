require("../../utils/stringutils.js").stringutils;

var a = require("../../utils/wxutils.js").wxutils, t = getApp();

Page({
    data: {
        returnUrl: null,
        avatarUrl: null,
        nickName: null,
        popupShow: !1,
        privacy: !1
    },
    onLoad: function(a) {
        a.returnUrl && this.setData({
            returnUrl: a.returnUrl
        }), this.runPrivacy();
    },
    runPrivacy: function() {
        var a = this;
        wx.requirePrivacyAuthorize({
            success: function() {
                a.data.privacy && a.popupShowLogin();
            },
            fail: function() {
                a.setData({
                    privacy: !0
                });
            },
            complete: function() {}
        });
    },
    getuserinfo: function(t) {
        var o = this;
        a.showLoading("登录中"), wx.cloud.callFunction({
            name: "quickstartFunctions",
            data: {
                type: "userInfo",
                userInfo: t
            }
        }).then(function(n) {
            if (console.log(n), a.hideLoading(), n.result.success) {
                var i = {
                    openid: n.result.data.openid,
                    uuid: n.result.data.uuid,
                    avatarUrl: t.avatarUrl,
                    nickName: t.nickName
                };
                o.login(i);
            } else a.showToast(n.result.errMsg);
        }).catch(function(t) {
            a.hideLoading(), a.showToast("登录失败"), console.error("加载数据失败", t);
        });
    },
    openPrivacyContract: function() {
        wx.openPrivacyContract ? wx.openPrivacyContract({
            success: function(a) {
                console.log("openPrivacyContract success");
            },
            fail: function(a) {
                console.error("openPrivacyContract fail", a);
            }
        }) : wx.navigateTo({
            url: "/pages/webview/index?url=https://mp.weixin.qq.com/wxawap/waprivacyinfo?action=show&appid=wxa6077ac855ee8cda#wechat_redirect"
        });
    },
    chooseavatar: function(t) {
        var o = t.detail.avatarUrl;
        o ? this.setData({
            avatarUrl: o
        }) : a.showToast("选择头像失败");
    },
    onClickAvatar: function() {
        a.showToast('选择下方👇"用微信头像"', 5e3);
    },
    bindNickNameKeyInput: function(a) {
        this.setData({
            nickName: a.detail.value
        });
    },
    popupShowLogin: function() {
        var t = this;
        a.showLoading("登录中"), wx.cloud.callFunction({
            name: "quickstartFunctions",
            data: {
                type: "userInfoCheck"
            }
        }).then(function(o) {
            if (console.log(o), a.hideLoading(), o.result.success) {
                var n = o.result.data;
                if (n) {
                    var i = n.avatarUrl, e = n.nickName, r = n._openid, s = n.uuid;
                    if (i && e) {
                        var c = {
                            openid: r,
                            uuid: s,
                            avatarUrl: i,
                            nickName: e
                        };
                        t.login(c);
                    } else t.setData({
                        popupShow: !0
                    });
                } else t.setData({
                    popupShow: !0
                });
            }
        }).catch(function(t) {
            a.hideLoading(), a.showToast("加载错误"), console.error("加载数据失败", t);
        });
    },
    popupHide: function() {
        this.setData({
            popupShow: !1
        });
    },
    login: function(o) {
        t.globalData.userInfo = o, t.globalData.user_openid = o.openid, t.globalData.uuid = o.uuid, 
        console.log(t.globalData), this.setData({
            userInfo: o
        }), wx.setStorageSync("userInfo", o), a.showToast("登录成功"), a.getCallBackUrl().catch(function() {
            wx.switchTab({
                url: "/pages/mine/index"
            });
        });
    },
    btnClick: function() {
        var t = this;
        return this.data.avatarUrl && null !== this.data.avatarUrl && void 0 !== this.data.avatarUrl && "" !== this.data.avatarUrl ? this.data.nickName && null !== this.data.nickName && void 0 !== this.data.nickName && "" !== this.data.nickName ? (a.showLoading("上传头像中"), 
        void wx.cloud.uploadFile({
            cloudPath: "avatar/" + new Date().getTime() + "_" + Math.floor(1e3 * Math.random()) + ".jpg",
            filePath: this.data.avatarUrl
        }).then(function(o) {
            a.hideLoading(), console.log("上传成功", o), t.getuserinfo({
                avatarUrl: o.fileID,
                nickName: t.data.nickName
            });
        }).catch(function(t) {
            a.hideLoading(), console.log(t), a.showToast("上传头像失败");
        })) : a.showToast("请输入昵称") : a.showToast("请上传头像");
    },
    onReady: function() {},
    onShow: function() {},
    onHide: function() {},
    onUnload: function() {},
    onPullDownRefresh: function() {},
    onReachBottom: function() {},
    onShareAppMessage: function() {}
});