module.exports = {
    envList: [ {
        envId: "applet-signin-7gpgztdf05e03e47",
        alias: "applet-signin"
    } ],
    isMac: !1
};