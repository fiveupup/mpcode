Object.defineProperty(exports, "__esModule", {
    value: !0
}), (0, require("../common/component").VantComponent)({
    classes: [ "header-class", "footer-class" ],
    props: {
        desc: String,
        title: String,
        status: String
    }
});