var e, n = e = {
    showToast: function(e) {
        var n = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : 2e3, t = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : "none";
        wx.showToast({
            title: e,
            duration: n,
            icon: t,
            mask: !1
        });
    },
    showLoading: function() {
        var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : "加载中";
        wx.showLoading({
            title: e,
            mask: !1
        });
    },
    hideLoading: function() {
        wx.hideLoading();
    },
    base64ImageToTemp: function(e) {
        return new Promise(function(n, t) {
            var a = "".concat(wx.env.USER_DATA_PATH, "/").concat(Math.floor(Date.now() / 1e3), ".png");
            wx.getFileSystemManager().writeFile({
                filePath: a,
                data: e.replace(/^data:image\/\w+;base64,/, ""),
                encoding: "base64",
                success: function() {
                    n(a);
                },
                fail: function(e) {
                    t(e);
                }
            });
        });
    },
    base64ImageHandle: function(n) {
        var t = "".concat(wx.env.USER_DATA_PATH, "/").concat(Math.floor(Date.now() / 1e3), ".png");
        wx.getFileSystemManager().writeFile({
            filePath: t,
            data: n.replace(/^data:image\/\w+;base64,/, ""),
            encoding: "base64",
            success: function() {
                wx.showModal({
                    title: "保存图片",
                    content: "保存图片到手机相册？",
                    confirmColor: "#be3a34",
                    success: function(n) {
                        n.confirm && wx.saveImageToPhotosAlbum({
                            filePath: t,
                            success: function() {
                                e.showToast("保存成功", 2e3, "success");
                            }
                        });
                    }
                });
            }
        });
    },
    setCallbackUrl: function(e) {
        return new Promise(function(n, t) {
            var a = getCurrentPages(), o = a[a.length - 1], c = "", i = o.route, r = "", s = o.options;
            for (var l in s) r += l + "=" + s[l] + "&";
            c = r ? i + "?" + (r = r.substring(0, r.length - 1)) : i;
            var u = {
                callbackUrl: "/".concat(c),
                mode: e || "redirectTo"
            };
            wx.setStorageSync("callbackObj", JSON.stringify(u)), n();
        });
    },
    getCallBackUrl: function() {
        return new Promise(function(e, n) {
            var t = wx.getStorageSync("callbackObj");
            if (t) {
                var a = JSON.parse(t), o = a.callbackUrl, c = a.mode;
                "redirectTo" == c && wx.redirectTo({
                    url: o
                }), "switchTab" == c && wx.switchTab({
                    url: o
                }), "reLaunch" == c && wx.reLaunch({
                    url: o
                }), "navigateTo" == c && wx.navigateTo({
                    url: o
                });
            } else n();
        });
    },
    getLocation: function() {
        return new Promise(function(e, n) {
            wx.getLocation({
                type: "gcj02",
                isHighAccuracy: !0,
                success: function(n) {
                    e(n);
                },
                fail: function(e) {
                    n(e);
                }
            });
        });
    }
};

module.exports = {
    wxutils: n
};