var e, t = require("../@babel/runtime/helpers/slicedToArray"), r = require("../@babel/runtime/helpers/createForOfIteratorHelper"), n = e = {
    formatTimestamp: function(e) {
        var t = 10 === String(e).length ? new Date(1e3 * parseInt(e)) : new Date(parseInt(e)), r = t.getFullYear(), n = t.getMonth() + 1;
        n < 10 && (n = "0" + n);
        var a = t.getDate();
        a < 10 && (a = "0" + a);
        var i = t.getHours();
        i < 10 && (i = "0" + i);
        var o = t.getMinutes();
        o < 10 && (o = "0" + o);
        var s = t.getSeconds();
        return s < 10 && (s = "0" + s), r + "-" + n + "-" + a + " " + i + ":" + o + ":" + s;
    },
    generateRandomNumber: function(e) {
        for (var t = "", r = 0; r < e; r++) t += Math.floor(10 * Math.random());
        return t;
    },
    getDistance: function(e, t, r, n) {
        var a = (r - e) * (Math.PI / 180), i = (n - t) * (Math.PI / 180), o = Math.sin(a / 2) * Math.sin(a / 2) + Math.cos(e * (Math.PI / 180)) * Math.cos(r * (Math.PI / 180)) * Math.sin(i / 2) * Math.sin(i / 2);
        return 2 * Math.atan2(Math.sqrt(o), Math.sqrt(1 - o)) * 6371 * 1e3;
    },
    checkTimeRangesOverlap: function(e) {
        for (var t = 0; t < e.length; t++) for (var r = t + 1; r < e.length; r++) {
            var n = e[t], a = e[r], i = new Date("2000-01-01 ".concat(n.startTime)), o = new Date("2000-01-01 ".concat(n.endTime)), s = new Date("2000-01-01 ".concat(a.startTime));
            if (i <= new Date("2000-01-01 ".concat(a.endTime)) && s <= o) return !0;
        }
        return !1;
    },
    isInTimeRanges: function(t, n) {
        var a, i = e.convertToMinutes(t), o = r(n);
        try {
            for (o.s(); !(a = o.n()).done; ) {
                var s = a.value, u = e.convertToMinutes(s.startTime), c = e.convertToMinutes(s.endTime);
                if (i >= u && i <= c) return !0;
            }
        } catch (e) {
            o.e(e);
        } finally {
            o.f();
        }
        return !1;
    },
    convertToMinutes: function(e) {
        var r = e.split(":").map(Number), n = t(r, 2);
        return 60 * n[0] + n[1];
    }
};

module.exports = {
    stringutils: n
};