var n, o = new Set(), t = new Set();

wx.onNeedPrivacyAuthorization && wx.onNeedPrivacyAuthorization(function(o) {
    "function" == typeof n && n(o);
});

var e = function(n) {
    t.forEach(function(o) {
        n !== o && o();
    });
};

Component({
    data: {
        innerShow: !1
    },
    lifetimes: {
        attached: function() {
            var i = this, c = function() {
                i.disPopUp();
            };
            n = function(n) {
                o.add(n), i.popUp(), e(c);
            }, t.add(c), this.closePopUp = c;
        },
        detached: function() {
            t.delete(this.closePopUp);
        }
    },
    pageLifetimes: {
        show: function() {
            this.curPageShow();
        }
    },
    methods: {
        handleAgree: function(n) {
            this.disPopUp(), o.forEach(function(n) {
                n({
                    event: "agree",
                    buttonId: "agree-btn"
                });
            }), o.clear();
        },
        handleDisagree: function(n) {
            this.disPopUp(), o.forEach(function(n) {
                n({
                    event: "disagree"
                });
            }), o.clear();
        },
        popUp: function() {
            !1 === this.data.innerShow && this.setData({
                innerShow: !0
            });
        },
        disPopUp: function() {
            !0 === this.data.innerShow && this.setData({
                innerShow: !1
            });
        },
        openPrivacyContract: function() {
            wx.openPrivacyContract({
                success: function(n) {
                    console.log("openPrivacyContract success");
                },
                fail: function(n) {
                    console.error("openPrivacyContract fail", n);
                }
            });
        },
        curPageShow: function() {
            var t = this;
            this.closePopUp && (n = function(n) {
                o.add(n), t.popUp(), e(t.closePopUp);
            });
        }
    }
});