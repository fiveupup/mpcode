require("../../utils/stringutils.js").stringutils;

var t = require("../../utils/wxutils.js").wxutils;

getApp();

Component({
    properties: {
        diyInfoShowProps: Boolean
    },
    observers: {
        diyInfoShowProps: function(t) {
            this.setData({
                diyInfoShow: t
            });
        }
    },
    data: {
        ac: 0,
        index: 0,
        diyInfoShow: !1,
        typeTitle: "文本",
        typeChoose: 1,
        title: null,
        requiredChecked: !0,
        showSetting: !1,
        chooseList: [ "" ],
        optionsSetting: [ {
            type: 1,
            name: "文本",
            icon: "/images/grid/edit.png"
        }, {
            type: 2,
            name: "单选",
            icon: "/images/grid/edit.png"
        }, {
            type: 3,
            name: "多选",
            icon: "/images/grid/edit.png"
        }, {
            type: 4,
            name: "定位",
            icon: "/images/grid/edit.png"
        }, {
            type: 5,
            name: "日期",
            icon: "/images/grid/edit.png"
        }, {
            type: 6,
            name: "时间",
            icon: "/images/grid/edit.png"
        }, {
            type: 7,
            name: "日期时间",
            icon: "/images/grid/edit.png"
        } ]
    },
    methods: {
        initialization: function() {
            this.setData({
                typeTitle: "文本",
                typeChoose: 1,
                ac: 0,
                title: null,
                requiredChecked: !0,
                chooseList: [ "" ]
            });
        },
        updateData: function(t) {
            console.log("子组件的数据已更新:", t);
            var e = 0;
            switch (t.model) {
              case "text":
                e = 1;
                break;

              case "radio":
                e = 2;
                break;

              case "checkbox":
                e = 3;
                break;

              case "location":
                e = 4;
                break;

              case "date":
                e = 5;
                break;

              case "time":
                e = 6;
                break;

              case "datetime":
                e = 7;
                break;

              case "img":
              case "photo":
                e = 8;
            }
            var i = this.data.optionsSetting.find(function(t) {
                return t.type === e;
            }).name, s = t.chooseList ? t.chooseList.slice() : [];
            s.push(""), this.setData({
                typeTitle: i,
                typeChoose: e,
                title: t.title,
                requiredChecked: 1 == t.type,
                chooseList: s,
                ac: 1,
                index: t.index
            });
        },
        onClose: function() {
            this.setData({
                diyInfoShow: !1
            });
        },
        onConfirm: function() {
            var t = this.data.chooseList.slice();
            t.pop(), console.log(t);
            var e = t.filter(function(t) {
                return null != t && "" !== t;
            });
            console.log(e), this.triggerEvent("chooseover", {
                eventData: {
                    type: this.data.typeChoose,
                    title: this.data.title,
                    chooseList: e,
                    required: this.data.requiredChecked,
                    ac: this.data.ac,
                    index: this.data.index
                }
            });
        },
        handleChooleListFieldInput: function(t) {
            var e = t.currentTarget.dataset.index, i = t.detail, s = this.data.chooseList;
            (null == i || "" === i) && 0 != e && e != s.length - 1 ? s.splice(e, 1) : s[e] = i, 
            this.setData({
                chooseList: s
            });
        },
        onRightIconClick: function(e) {
            var i = e.currentTarget.dataset.index, s = this.data.chooseList.length, a = this.data.chooseList;
            if (i == s - 1) {
                if (void 0 === this.data.chooseList[i] || null === this.data.chooseList[i] || "" === this.data.chooseList[i]) return t.showToast("请输入信息");
                t.showToast("添加成功"), a.push("");
            } else a.splice(i, 1);
            this.setData({
                chooseList: a
            });
        },
        onTypeChooseClick: function() {
            this.setData({
                showSetting: !0
            });
        },
        onRequiredCheckedChange: function(t) {
            var e = t.detail;
            this.setData({
                requiredChecked: e
            });
        },
        showSettingCancel: function() {
            this.setData({
                showSetting: !1
            });
        },
        showSettingClick: function(e) {
            var i = e.detail.index, s = this.data.optionsSetting[i];
            switch (this.setData({
                typeTitle: s.name,
                typeChoose: s.type,
                showSetting: !1
            }), s.type) {
              case 2:
                t.showToast("单选");
                break;

              case 3:
                t.showToast("多选");
                break;

              case 4:
                t.showToast("定位"), this.setData({
                    typeTitle: "定位"
                });
                break;

              case 5:
                this.setData({
                    typeTitle: "日期"
                }), t.showToast("日期");
                break;

              case 6:
                this.setData({
                    typeTitle: "时间"
                }), t.showToast("时间");
                break;

              case 7:
                this.setData({
                    typeTitle: "时间日期"
                }), t.showToast("时间日期");
                break;

              case 8:
                this.setData({
                    typeTitle: "图片"
                }), t.showToast("图片");
                break;

              case 9:
                this.setData({
                    typeTitle: "拍照"
                }), t.showToast("拍照");
            }
        }
    }
});