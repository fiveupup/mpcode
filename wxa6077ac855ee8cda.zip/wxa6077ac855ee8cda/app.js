App({
    onLaunch: function() {
        wx.cloud ? wx.cloud.init({
            traceUser: !0
        }) : console.error("请使用 2.2.3 或以上的基础库以使用云能力");
        var e = wx.getStorageSync("userInfo");
        e && (this.globalData.userInfo = e, this.globalData.user_openid = e.openid);
    },
    globalData: {
        appletName: "签到助手",
        version: "1.0.0",
        user_openid: "",
        uuid: "",
        userInfo: ""
    }
});