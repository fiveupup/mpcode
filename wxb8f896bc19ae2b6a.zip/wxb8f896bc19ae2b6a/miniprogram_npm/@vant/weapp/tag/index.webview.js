$gwx_XC_68=function(_,_v,_n,_p,_s,_wp,_wl,$gwn,$gwl,$gwh,wh,$gstack,$gwrt,gra,grb,TestTest,wfor,_ca,_da,_r,_rz,_o,_oz,_1,_1z,_2,_2z,_m,_mz,nv_getDate,nv_getRegExp,nv_console,nv_parseInt,nv_parseFloat,nv_isNaN,nv_isFinite,nv_decodeURI,nv_decodeURIComponent,nv_encodeURI,nv_encodeURIComponent,$gdc,nv_JSON,_af,_gv,_ai,_grp,_gd,_gapi,$ixc,_ic,_w,_ev,_tsd){return function(path,global){
if(typeof global==='undefined'){if (typeof __GWX_GLOBAL__==='undefined')global={};else global=__GWX_GLOBAL__;}if(typeof __WXML_GLOBAL__ === 'undefined') {__WXML_GLOBAL__={};
}__WXML_GLOBAL__.modules = __WXML_GLOBAL__.modules || {};
var e_={}
if(typeof(global.entrys)==='undefined')global.entrys={};e_=global.entrys;
var d_={}
if(typeof(global.defines)==='undefined')global.defines={};d_=global.defines;
var f_={}
if(typeof(global.modules)==='undefined')global.modules={};f_=global.modules || {};
var p_={}
__WXML_GLOBAL__.ops_cached = __WXML_GLOBAL__.ops_cached || {}
__WXML_GLOBAL__.ops_set = __WXML_GLOBAL__.ops_set || {};
__WXML_GLOBAL__.ops_init = __WXML_GLOBAL__.ops_init || {};
var z=__WXML_GLOBAL__.ops_set.$gwx_XC_68 || [];
function gz$gwx_XC_68_1(){
if( __WXML_GLOBAL__.ops_cached.$gwx_XC_68_1)return __WXML_GLOBAL__.ops_cached.$gwx_XC_68_1
__WXML_GLOBAL__.ops_cached.$gwx_XC_68_1=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
Z([a,[3,'custom-class '],[[12],[[6],[[7],[3,'utils']],[3,'bem']],[[5],[[5],[1,'tag']],[[4],[[5],[[5],[[5],[[7],[3,'type']]],[[7],[3,'size']]],[[9],[[9],[[8],'mark',[[7],[3,'mark']]],[[8],'plain',[[7],[3,'plain']]]],[[8],'round',[[7],[3,'round']]]]]]]]])
Z([[12],[[6],[[7],[3,'computed']],[3,'rootStyle']],[[5],[[9],[[9],[[8],'plain',[[7],[3,'plain']]],[[8],'color',[[7],[3,'color']]]],[[8],'textColor',[[7],[3,'textColor']]]]]])
Z([[7],[3,'closeable']])
Z([3,'onClose'])
Z([3,'van-tag__close'])
Z([3,'cross'])
})(__WXML_GLOBAL__.ops_cached.$gwx_XC_68_1);return __WXML_GLOBAL__.ops_cached.$gwx_XC_68_1
}
__WXML_GLOBAL__.ops_set.$gwx_XC_68=z;
__WXML_GLOBAL__.ops_init.$gwx_XC_68=true;
var x=['./miniprogram_npm/@vant/weapp/tag/index.wxml'];d_[x[0]]={}
var m0=function(e,s,r,gg){
var z=gz$gwx_XC_68_1()
var lOY=_mz(z,'view',['class',0,'style',1],[],e,s,gg)
var tQY=_n('slot')
_(lOY,tQY)
var aPY=_v()
_(lOY,aPY)
if(_oz(z,2,e,s,gg)){aPY.wxVkey=1
var eRY=_mz(z,'van-icon',['bind:click',3,'customClass',1,'name',2],[],e,s,gg)
_(aPY,eRY)
}
aPY.wxXCkey=1
aPY.wxXCkey=3
_(r,lOY)
return r
}
e_[x[0]]={f:m0,j:[],i:[],ti:[],ic:[]}
if(path&&e_[path]){
outerGlobal.__wxml_comp_version__=0.02
return function(env,dd,global){$gwxc=0;var root={"tag":"wx-page"};root.children=[]
;g="$gwx_XC_68";var main=e_[path].f
if (typeof global==="undefined")global={};global.f=$gdc(f_[path],"",1);
if(typeof(outerGlobal.__webview_engine_version__)!='undefined'&&outerGlobal.__webview_engine_version__+1e-6>=0.02+1e-6&&outerGlobal.__mergeData__)
{
env=outerGlobal.__mergeData__(env,dd);
}
try{
main(env,{},root,global);
_tsd(root)
if(typeof(outerGlobal.__webview_engine_version__)=='undefined'|| outerGlobal.__webview_engine_version__+1e-6<0.01+1e-6){return _ev(root);}
}catch(err){
console.log(err)
}
;g="";
return root;
}
}
}
}(__g.a,__g.b,__g.c,__g.d,__g.e,__g.f,__g.g,__g.h,__g.i,__g.j,__g.k,__g.l,__g.m,__g.n,__g.o,__g.p,__g.q,__g.r,__g.s,__g.t,__g.u,__g.v,__g.w,__g.x,__g.y,__g.z,__g.A,__g.B,__g.C,__g.D,__g.E,__g.F,__g.G,__g.H,__g.I,__g.J,__g.K,__g.L,__g.M,__g.N,__g.O,__g.P,__g.Q,__g.R,__g.S,__g.T,__g.U,__g.V,__g.W,__g.X,__g.Y,__g.Z,__g.aa);if(__vd_version_info__.delayedGwx||false)$gwx_XC_68();	if (__vd_version_info__.delayedGwx) __wxAppCode__['miniprogram_npm/@vant/weapp/tag/index.wxml'] = [$gwx_XC_68, './miniprogram_npm/@vant/weapp/tag/index.wxml'];else __wxAppCode__['miniprogram_npm/@vant/weapp/tag/index.wxml'] = $gwx_XC_68( './miniprogram_npm/@vant/weapp/tag/index.wxml' );
	
var noCss=typeof __vd_version_info__!=='undefined'&&__vd_version_info__.noCss===true;if(!noCss){__wxAppCode__['miniprogram_npm/@vant/weapp/tag/index.wxss'] = setCssToHead([[2,"./miniprogram_npm/@vant/weapp/common/index.wxss"],".",[1],"van-tag{-webkit-align-items:center;align-items:center;border-radius:var(--tag-border-radius,2px);color:var(--tag-text-color,#fff);display:-webkit-inline-flex;display:inline-flex;font-size:var(--tag-font-size,12px);line-height:var(--tag-line-height,16px);padding:var(--tag-padding,0 4px);position:relative}\n.",[1],"van-tag--default{background-color:var(--tag-default-color,#969799)}\n.",[1],"van-tag--default.",[1],"van-tag--plain{color:var(--tag-default-color,#969799)}\n.",[1],"van-tag--danger{background-color:var(--tag-danger-color,#ee0a24)}\n.",[1],"van-tag--danger.",[1],"van-tag--plain{color:var(--tag-danger-color,#ee0a24)}\n.",[1],"van-tag--primary{background-color:var(--tag-primary-color,#1989fa)}\n.",[1],"van-tag--primary.",[1],"van-tag--plain{color:var(--tag-primary-color,#1989fa)}\n.",[1],"van-tag--success{background-color:var(--tag-success-color,#07c160)}\n.",[1],"van-tag--success.",[1],"van-tag--plain{color:var(--tag-success-color,#07c160)}\n.",[1],"van-tag--warning{background-color:var(--tag-warning-color,#ff976a)}\n.",[1],"van-tag--warning.",[1],"van-tag--plain{color:var(--tag-warning-color,#ff976a)}\n.",[1],"van-tag--plain{background-color:var(--tag-plain-background-color,#fff)}\n.",[1],"van-tag--plain:before{border:1px solid;border-radius:inherit;bottom:0;content:\x22\x22;left:0;pointer-events:none;position:absolute;right:0;top:0}\n.",[1],"van-tag--medium{padding:var(--tag-medium-padding,2px 6px)}\n.",[1],"van-tag--large{border-radius:var(--tag-large-border-radius,4px);font-size:var(--tag-large-font-size,14px);padding:var(--tag-large-padding,4px 8px)}\n.",[1],"van-tag--mark{border-radius:0 var(--tag-round-border-radius,var(--tag-round-border-radius,999px)) var(--tag-round-border-radius,var(--tag-round-border-radius,999px)) 0}\n.",[1],"van-tag--mark:after{content:\x22\x22;display:block;width:2px}\n.",[1],"van-tag--round{border-radius:var(--tag-round-border-radius,999px)}\n.",[1],"van-tag__close{margin-left:2px;min-width:1em}\n",],undefined,{path:"./miniprogram_npm/@vant/weapp/tag/index.wxss"});
}