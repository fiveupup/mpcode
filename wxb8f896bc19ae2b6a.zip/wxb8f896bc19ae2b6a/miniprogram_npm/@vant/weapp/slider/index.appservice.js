$gwx_XC_57=function(_,_v,_n,_p,_s,_wp,_wl,$gwn,$gwl,$gwh,wh,$gstack,$gwrt,gra,grb,TestTest,wfor,_ca,_da,_r,_rz,_o,_oz,_1,_1z,_2,_2z,_m,_mz,nv_getDate,nv_getRegExp,nv_console,nv_parseInt,nv_parseFloat,nv_isNaN,nv_isFinite,nv_decodeURI,nv_decodeURIComponent,nv_encodeURI,nv_encodeURIComponent,$gdc,nv_JSON,_af,_gv,_ai,_grp,_gd,_gapi,$ixc,_ic,_w,_ev,_tsd){return function(path,global){
if(typeof global==='undefined'){if (typeof __GWX_GLOBAL__==='undefined')global={};else global=__GWX_GLOBAL__;}if(typeof __WXML_GLOBAL__ === 'undefined') {__WXML_GLOBAL__={};
}__WXML_GLOBAL__.modules = __WXML_GLOBAL__.modules || {};
var e_={}
if(typeof(global.entrys)==='undefined')global.entrys={};e_=global.entrys;
var d_={}
if(typeof(global.defines)==='undefined')global.defines={};d_=global.defines;
var f_={}
if(typeof(global.modules)==='undefined')global.modules={};f_=global.modules || {};
var p_={}
__WXML_GLOBAL__.ops_cached = __WXML_GLOBAL__.ops_cached || {}
__WXML_GLOBAL__.ops_set = __WXML_GLOBAL__.ops_set || {};
__WXML_GLOBAL__.ops_init = __WXML_GLOBAL__.ops_init || {};
var z=__WXML_GLOBAL__.ops_set.$gwx_XC_57 || [];
function gz$gwx_XC_57_1(){
if( __WXML_GLOBAL__.ops_cached.$gwx_XC_57_1)return __WXML_GLOBAL__.ops_cached.$gwx_XC_57_1
__WXML_GLOBAL__.ops_cached.$gwx_XC_57_1=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
Z([3,'onClick'])
Z([a,[3,'custom-class '],[[12],[[6],[[7],[3,'utils']],[3,'bem']],[[5],[[5],[1,'slider']],[[9],[[8],'disabled',[[7],[3,'disabled']]],[[8],'vertical',[[7],[3,'vertical']]]]]]])
Z([[7],[3,'wrapperStyle']])
Z([[12],[[6],[[7],[3,'utils']],[3,'bem']],[[5],[1,'slider__bar']]])
Z([a,[[7],[3,'barStyle']],[3,'; '],[[12],[[7],[3,'style']],[[5],[[8],'backgroundColor',[[7],[3,'activeColor']]]]]])
Z([[7],[3,'range']])
Z([3,'onTouchEnd'])
Z(z[6])
Z([3,'onTouchStart'])
Z([3,'onTouchMove'])
Z([[12],[[6],[[7],[3,'utils']],[3,'bem']],[[5],[1,'slider__button-wrapper-left']]])
Z([1,0])
Z([[7],[3,'useButtonSlot']])
Z([3,'left-button'])
Z(z[5])
Z(z[6])
Z(z[6])
Z(z[8])
Z(z[9])
Z([[12],[[6],[[7],[3,'utils']],[3,'bem']],[[5],[1,'slider__button-wrapper-right']]])
Z([1,1])
Z(z[12])
Z([3,'right-button'])
Z([[2,'!'],[[7],[3,'range']]])
Z(z[6])
Z(z[6])
Z(z[8])
Z(z[9])
Z([[12],[[6],[[7],[3,'utils']],[3,'bem']],[[5],[1,'slider__button-wrapper']]])
Z(z[12])
Z([3,'button'])
})(__WXML_GLOBAL__.ops_cached.$gwx_XC_57_1);return __WXML_GLOBAL__.ops_cached.$gwx_XC_57_1
}
__WXML_GLOBAL__.ops_set.$gwx_XC_57=z;
__WXML_GLOBAL__.ops_init.$gwx_XC_57=true;
var x=['./miniprogram_npm/@vant/weapp/slider/index.wxml'];d_[x[0]]={}
var m0=function(e,s,r,gg){
var z=gz$gwx_XC_57_1()
var aTN=_mz(z,'view',['bind:tap',0,'class',1,'style',1],[],e,s,gg)
var tUN=_mz(z,'view',['class',3,'style',1],[],e,s,gg)
var eVN=_v()
_(tUN,eVN)
if(_oz(z,5,e,s,gg)){eVN.wxVkey=1
var xYN=_mz(z,'view',['bind:touchcancel',6,'bind:touchend',1,'bind:touchstart',2,'catch:touchmove',3,'class',4,'data-index',5],[],e,s,gg)
var oZN=_v()
_(xYN,oZN)
if(_oz(z,12,e,s,gg)){oZN.wxVkey=1
var f1N=_n('slot')
_rz(z,f1N,'name',13,e,s,gg)
_(oZN,f1N)
}
else{oZN.wxVkey=2
}
oZN.wxXCkey=1
_(eVN,xYN)
}
var bWN=_v()
_(tUN,bWN)
if(_oz(z,14,e,s,gg)){bWN.wxVkey=1
var c2N=_mz(z,'view',['bind:touchcancel',15,'bind:touchend',1,'bind:touchstart',2,'catch:touchmove',3,'class',4,'data-index',5],[],e,s,gg)
var h3N=_v()
_(c2N,h3N)
if(_oz(z,21,e,s,gg)){h3N.wxVkey=1
var o4N=_n('slot')
_rz(z,o4N,'name',22,e,s,gg)
_(h3N,o4N)
}
else{h3N.wxVkey=2
}
h3N.wxXCkey=1
_(bWN,c2N)
}
var oXN=_v()
_(tUN,oXN)
if(_oz(z,23,e,s,gg)){oXN.wxVkey=1
var c5N=_mz(z,'view',['bind:touchcancel',24,'bind:touchend',1,'bind:touchstart',2,'catch:touchmove',3,'class',4],[],e,s,gg)
var o6N=_v()
_(c5N,o6N)
if(_oz(z,29,e,s,gg)){o6N.wxVkey=1
var l7N=_n('slot')
_rz(z,l7N,'name',30,e,s,gg)
_(o6N,l7N)
}
else{o6N.wxVkey=2
}
o6N.wxXCkey=1
_(oXN,c5N)
}
eVN.wxXCkey=1
bWN.wxXCkey=1
oXN.wxXCkey=1
_(aTN,tUN)
_(r,aTN)
return r
}
e_[x[0]]={f:m0,j:[],i:[],ti:[],ic:[]}
if(path&&e_[path]){
return function(env,dd,global){$gwxc=0;var root={"tag":"wx-page"};root.children=[]
;g="$gwx_XC_57";var main=e_[path].f
if (typeof global==="undefined")global={};global.f=$gdc(f_[path],"",1);
try{
main(env,{},root,global);
_tsd(root)
}catch(err){
console.log(err)
}
;g="";
return root;
}
}
}
}(__g.a,__g.b,__g.c,__g.d,__g.e,__g.f,__g.g,__g.h,__g.i,__g.j,__g.k,__g.l,__g.m,__g.n,__g.o,__g.p,__g.q,__g.r,__g.s,__g.t,__g.u,__g.v,__g.w,__g.x,__g.y,__g.z,__g.A,__g.B,__g.C,__g.D,__g.E,__g.F,__g.G,__g.H,__g.I,__g.J,__g.K,__g.L,__g.M,__g.N,__g.O,__g.P,__g.Q,__g.R,__g.S,__g.T,__g.U,__g.V,__g.W,__g.X,__g.Y,__g.Z,__g.aa);if(__vd_version_info__.delayedGwx||false)$gwx_XC_57();	if (__vd_version_info__.delayedGwx) __wxAppCode__['miniprogram_npm/@vant/weapp/slider/index.wxml'] = [$gwx_XC_57, './miniprogram_npm/@vant/weapp/slider/index.wxml'];else __wxAppCode__['miniprogram_npm/@vant/weapp/slider/index.wxml'] = $gwx_XC_57( './miniprogram_npm/@vant/weapp/slider/index.wxml' );
	;__wxRoute = "miniprogram_npm/@vant/weapp/slider/index";__wxRouteBegin = true;__wxAppCurrentFile__="miniprogram_npm/@vant/weapp/slider/index.js";define("miniprogram_npm/@vant/weapp/slider/index.js",function(require,module,exports,window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){
"use strict";Object.defineProperty(exports,"__esModule",{value:!0});var t=require("../common/component"),a=require("../mixins/touch"),e=require("../common/version"),i=require("../common/utils"),n="start",s="moving",r="end";(0,t.VantComponent)({mixins:[a.touch],props:{range:Boolean,disabled:Boolean,useButtonSlot:Boolean,activeColor:String,inactiveColor:String,max:{type:Number,value:100},min:{type:Number,value:0},step:{type:Number,value:1},value:{type:null,value:0,observer:function(t){t!==this.value&&this.updateValue(t)}},vertical:Boolean,barHeight:null},created:function(){this.updateValue(this.data.value)},methods:{onTouchStart:function(t){var a=this;if(!this.data.disabled){var e=t.currentTarget.dataset.index;"number"==typeof e&&(this.buttonIndex=e),this.touchStart(t),this.startValue=this.format(this.value),this.newValue=this.value,this.isRange(this.newValue)?this.startValue=this.newValue.map((function(t){return a.format(t)})):this.startValue=this.format(this.newValue),this.dragStatus=n}},onTouchMove:function(t){var a=this;this.data.disabled||(this.dragStatus===n&&this.$emit("drag-start"),this.touchMove(t),this.dragStatus=s,(0,i.getRect)(this,".van-slider").then((function(t){var e=a.data.vertical,i=(e?a.deltaY:a.deltaX)/(e?t.height:t.width)*a.getRange();a.isRange(a.startValue)?a.newValue[a.buttonIndex]=a.startValue[a.buttonIndex]+i:a.newValue=a.startValue+i,a.updateValue(a.newValue,!1,!0)})))},onTouchEnd:function(){var t=this;this.data.disabled||this.dragStatus===s&&(this.dragStatus=r,(0,i.nextTick)((function(){t.updateValue(t.newValue,!0),t.$emit("drag-end")})))},onClick:function(t){var a=this;if(!this.data.disabled){var e=this.data.min;(0,i.getRect)(this,".van-slider").then((function(i){var n=a.data.vertical,s=t.touches[0],r=n?s.clientY-i.top:s.clientX-i.left,u=n?i.height:i.width,h=Number(e)+r/u*a.getRange();if(a.isRange(a.value)){var o=a.value,c=o[0],l=o[1];h<=(c+l)/2?a.updateValue([h,l],!0):a.updateValue([c,h],!0)}else a.updateValue(h,!0)}))}},isRange:function(t){return this.data.range&&Array.isArray(t)},handleOverlap:function(t){return t[0]>t[1]?t.slice(0).reverse():t},updateValue:function(t,a,n){var s=this;t=this.isRange(t)?this.handleOverlap(t).map((function(t){return s.format(t)})):this.format(t),this.value=t;var r=this.data.vertical,u=r?"height":"width";this.setData({wrapperStyle:"\n          background: ".concat(this.data.inactiveColor||"",";\n          ").concat(r?"width":"height",": ").concat((0,i.addUnit)(this.data.barHeight)||"",";\n        "),barStyle:"\n          ".concat(u,": ").concat(this.calcMainAxis(),";\n          left: ").concat(r?0:this.calcOffset(),";\n          top: ").concat(r?this.calcOffset():0,";\n          ").concat(n?"transition: none;":"","\n        ")}),n&&this.$emit("drag",{value:t}),a&&this.$emit("change",t),(n||a)&&(0,e.canIUseModel)()&&this.setData({value:t})},getScope:function(){return Number(this.data.max)-Number(this.data.min)},getRange:function(){var t=this.data;return t.max-t.min},getOffsetWidth:function(t,a){var e=this.getScope();return"".concat(Math.max(100*(t-a)/e,0),"%")},calcMainAxis:function(){var t=this.value,a=this.data.min;return this.isRange(t)?this.getOffsetWidth(t[1],t[0]):this.getOffsetWidth(t,Number(a))},calcOffset:function(){var t=this.value,a=this.data.min,e=this.getScope();return this.isRange(t)?"".concat(100*(t[0]-Number(a))/e,"%"):"0%"},format:function(t){var a=+this.data.min,e=+this.data.max,n=+this.data.step;t=(0,i.clamp)(t,a,e);var s=Math.round((t-a)/n)*n;return(0,i.addNumber)(a,s)}}});
},{isPage:false,isComponent:true,currentFile:'miniprogram_npm/@vant/weapp/slider/index.js'});require("miniprogram_npm/@vant/weapp/slider/index.js");