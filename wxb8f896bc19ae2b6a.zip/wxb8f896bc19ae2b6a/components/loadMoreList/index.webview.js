$gwx_XC_0=function(_,_v,_n,_p,_s,_wp,_wl,$gwn,$gwl,$gwh,wh,$gstack,$gwrt,gra,grb,TestTest,wfor,_ca,_da,_r,_rz,_o,_oz,_1,_1z,_2,_2z,_m,_mz,nv_getDate,nv_getRegExp,nv_console,nv_parseInt,nv_parseFloat,nv_isNaN,nv_isFinite,nv_decodeURI,nv_decodeURIComponent,nv_encodeURI,nv_encodeURIComponent,$gdc,nv_JSON,_af,_gv,_ai,_grp,_gd,_gapi,$ixc,_ic,_w,_ev,_tsd){return function(path,global){
if(typeof global==='undefined'){if (typeof __GWX_GLOBAL__==='undefined')global={};else global=__GWX_GLOBAL__;}if(typeof __WXML_GLOBAL__ === 'undefined') {__WXML_GLOBAL__={};
}__WXML_GLOBAL__.modules = __WXML_GLOBAL__.modules || {};
var e_={}
if(typeof(global.entrys)==='undefined')global.entrys={};e_=global.entrys;
var d_={}
if(typeof(global.defines)==='undefined')global.defines={};d_=global.defines;
var f_={}
if(typeof(global.modules)==='undefined')global.modules={};f_=global.modules || {};
var p_={}
__WXML_GLOBAL__.ops_cached = __WXML_GLOBAL__.ops_cached || {}
__WXML_GLOBAL__.ops_set = __WXML_GLOBAL__.ops_set || {};
__WXML_GLOBAL__.ops_init = __WXML_GLOBAL__.ops_init || {};
var z=__WXML_GLOBAL__.ops_set.$gwx_XC_0 || [];
function gz$gwx_XC_0_1(){
if( __WXML_GLOBAL__.ops_cached.$gwx_XC_0_1)return __WXML_GLOBAL__.ops_cached.$gwx_XC_0_1
__WXML_GLOBAL__.ops_cached.$gwx_XC_0_1=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
Z([3,'handleRefresh'])
Z([3,'handleTolower'])
Z([[7],[3,'isRefreshEnable']])
Z([[7],[3,'isRefreshering']])
Z([[7],[3,'scrollTop']])
Z([3,'true'])
Z([3,'height: 100%;'])
Z([3,'scroll-body'])
Z([3,'scroll-list'])
Z([[7],[3,'isLoading']])
Z([3,'scroll-bottom-line'])
Z([3,' 加载中~ '])
Z([[7],[3,'isLastPage']])
Z(z[10])
Z([3,'没有更多了'])
})(__WXML_GLOBAL__.ops_cached.$gwx_XC_0_1);return __WXML_GLOBAL__.ops_cached.$gwx_XC_0_1
}
__WXML_GLOBAL__.ops_set.$gwx_XC_0=z;
__WXML_GLOBAL__.ops_init.$gwx_XC_0=true;
var x=['./components/loadMoreList/index.wxml'];d_[x[0]]={}
var m0=function(e,s,r,gg){
var z=gz$gwx_XC_0_1()
var bGB=_mz(z,'scroll-view',['bindrefresherrefresh',0,'bindscrolltolower',1,'refresherEnabled',1,'refresherTriggered',2,'scrollTop',3,'scrollY',4,'style',5],[],e,s,gg)
var oHB=_n('view')
_rz(z,oHB,'class',7,e,s,gg)
var fKB=_n('view')
_rz(z,fKB,'class',8,e,s,gg)
var cLB=_n('slot')
_(fKB,cLB)
_(oHB,fKB)
var xIB=_v()
_(oHB,xIB)
if(_oz(z,9,e,s,gg)){xIB.wxVkey=1
var hMB=_n('view')
_rz(z,hMB,'class',10,e,s,gg)
var oNB=_oz(z,11,e,s,gg)
_(hMB,oNB)
_(xIB,hMB)
}
var oJB=_v()
_(oHB,oJB)
if(_oz(z,12,e,s,gg)){oJB.wxVkey=1
var cOB=_n('view')
_rz(z,cOB,'class',13,e,s,gg)
var oPB=_oz(z,14,e,s,gg)
_(cOB,oPB)
_(oJB,cOB)
}
xIB.wxXCkey=1
oJB.wxXCkey=1
_(bGB,oHB)
_(r,bGB)
return r
}
e_[x[0]]={f:m0,j:[],i:[],ti:[],ic:[]}
if(path&&e_[path]){
outerGlobal.__wxml_comp_version__=0.02
return function(env,dd,global){$gwxc=0;var root={"tag":"wx-page"};root.children=[]
;g="$gwx_XC_0";var main=e_[path].f
if (typeof global==="undefined")global={};global.f=$gdc(f_[path],"",1);
if(typeof(outerGlobal.__webview_engine_version__)!='undefined'&&outerGlobal.__webview_engine_version__+1e-6>=0.02+1e-6&&outerGlobal.__mergeData__)
{
env=outerGlobal.__mergeData__(env,dd);
}
try{
main(env,{},root,global);
_tsd(root)
if(typeof(outerGlobal.__webview_engine_version__)=='undefined'|| outerGlobal.__webview_engine_version__+1e-6<0.01+1e-6){return _ev(root);}
}catch(err){
console.log(err)
}
;g="";
return root;
}
}
}
}(__g.a,__g.b,__g.c,__g.d,__g.e,__g.f,__g.g,__g.h,__g.i,__g.j,__g.k,__g.l,__g.m,__g.n,__g.o,__g.p,__g.q,__g.r,__g.s,__g.t,__g.u,__g.v,__g.w,__g.x,__g.y,__g.z,__g.A,__g.B,__g.C,__g.D,__g.E,__g.F,__g.G,__g.H,__g.I,__g.J,__g.K,__g.L,__g.M,__g.N,__g.O,__g.P,__g.Q,__g.R,__g.S,__g.T,__g.U,__g.V,__g.W,__g.X,__g.Y,__g.Z,__g.aa);if(__vd_version_info__.delayedGwx||false)$gwx_XC_0();	if (__vd_version_info__.delayedGwx) __wxAppCode__['components/loadMoreList/index.wxml'] = [$gwx_XC_0, './components/loadMoreList/index.wxml'];else __wxAppCode__['components/loadMoreList/index.wxml'] = $gwx_XC_0( './components/loadMoreList/index.wxml' );
	
var noCss=typeof __vd_version_info__!=='undefined'&&__vd_version_info__.noCss===true;if(!noCss){__wxAppCode__['components/loadMoreList/index.wxss'] = setCssToHead([".",[1],"scroll-body{min-height:100%}\n.",[1],"scroll-bottom-line{color:#999;font-size:",[0,28],";padding:",[0,20]," 0;text-align:center}\n.",[1],"icon-loading{display:block;height:",[0,50],";margin:",[0,20]," auto;width:",[0,50],"}\n",],undefined,{path:"./components/loadMoreList/index.wxss"});
}