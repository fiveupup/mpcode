$gwx_XC_74=function(_,_v,_n,_p,_s,_wp,_wl,$gwn,$gwl,$gwh,wh,$gstack,$gwrt,gra,grb,TestTest,wfor,_ca,_da,_r,_rz,_o,_oz,_1,_1z,_2,_2z,_m,_mz,nv_getDate,nv_getRegExp,nv_console,nv_parseInt,nv_parseFloat,nv_isNaN,nv_isFinite,nv_decodeURI,nv_decodeURIComponent,nv_encodeURI,nv_encodeURIComponent,$gdc,nv_JSON,_af,_gv,_ai,_grp,_gd,_gapi,$ixc,_ic,_w,_ev,_tsd){return function(path,global){
if(typeof global==='undefined'){if (typeof __GWX_GLOBAL__==='undefined')global={};else global=__GWX_GLOBAL__;}if(typeof __WXML_GLOBAL__ === 'undefined') {__WXML_GLOBAL__={};
}__WXML_GLOBAL__.modules = __WXML_GLOBAL__.modules || {};
var e_={}
if(typeof(global.entrys)==='undefined')global.entrys={};e_=global.entrys;
var d_={}
if(typeof(global.defines)==='undefined')global.defines={};d_=global.defines;
var f_={}
if(typeof(global.modules)==='undefined')global.modules={};f_=global.modules || {};
var p_={}
__WXML_GLOBAL__.ops_cached = __WXML_GLOBAL__.ops_cached || {}
__WXML_GLOBAL__.ops_set = __WXML_GLOBAL__.ops_set || {};
__WXML_GLOBAL__.ops_init = __WXML_GLOBAL__.ops_init || {};
var z=__WXML_GLOBAL__.ops_set.$gwx_XC_74 || [];
function gz$gwx_XC_74_1(){
if( __WXML_GLOBAL__.ops_cached.$gwx_XC_74_1)return __WXML_GLOBAL__.ops_cached.$gwx_XC_74_1
__WXML_GLOBAL__.ops_cached.$gwx_XC_74_1=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
Z([3,'page'])
Z([a,[3,'height: '],[[7],[3,'pageHeight']],[3,'px;']])
Z([3,'onRefresh'])
Z([3,'onScroll'])
Z([[7],[3,'isRefreshing']])
Z([3,'flex: 1;overflow: auto;'])
Z([a,[3,'position: absolute;margin-top: '],[[7],[3,'topHeight']],[3,'px;top: 0;height: 100%;width: 100%;']])
Z([[2,'!'],[[12],[[6],[[7],[3,'utils']],[3,'isEmptyObj']],[[5],[[7],[3,'mentionModel']]]]])
Z([3,'active-time-view'])
Z([[2,'&&'],[[2,'&&'],[[2,'=='],[[6],[[7],[3,'mentionModel']],[3,'miniProgramViewFlag']],[1,1]],[[2,'=='],[[6],[[7],[3,'mentionModel']],[3,'freeInvitationFlag']],[1,1]]],[[2,'=='],[[6],[[7],[3,'mentionModel']],[3,'freeInvitationCanFlag']],[1,1]]])
Z([[2,'&&'],[[2,'&&'],[[2,'!=='],[[6],[[7],[3,'mentionModel']],[3,'situationType']],[1,'04']],[[2,'!=='],[[6],[[7],[3,'mentionModel']],[3,'situationType']],[1,'05']]],[[2,'!=='],[[6],[[7],[3,'mentionModel']],[3,'situationType']],[1,'03']]])
Z([[2,'=='],[[6],[[7],[3,'mentionModel']],[3,'situationType']],[1,'03']])
Z([[2,'=='],[[6],[[7],[3,'mentionModel']],[3,'situationType']],[1,'04']])
Z([[2,'&&'],[[7],[3,'recomActiveList']],[[2,'>'],[[6],[[7],[3,'recomActiveList']],[3,'length']],[1,0]]])
Z([3,'module-container recommand-container'])
Z([[2,'||'],[[2,'!'],[[7],[3,'currentCityCount']]],[[2,'=='],[[7],[3,'currentCityCount']],[1,0]]])
Z([[7],[3,'recomActiveList']])
Z([3,'index'])
Z([3,'toDetail'])
Z([3,'recommand-item'])
Z([[7],[3,'item']])
Z([[2,'?:'],[[2,'=='],[[7],[3,'index']],[[2,'-'],[[6],[[7],[3,'recomActiveList']],[3,'length']],[1,1]]],[1,'border-bottom: unset;'],[1,'border-bottom: #e1e1e1 solid 1rpx;']])
Z([3,'reco-active-content'])
Z([[6],[[7],[3,'item']],[3,'tagName']])
Z([[6],[[7],[3,'item']],[3,'availableNum']])
Z([[7],[3,'ifCollectShow']])
Z([[7],[3,'collectDialogShow']])
Z([1,false])
Z([[7],[3,'showFilterPop']])
Z([3,'myCatchTouch'])
Z([3,'filter-pop-content'])
Z([3,'filter-pop-content-group fr'])
Z([[7],[3,'items']])
Z(z[17])
Z([3,'onClickNav'])
Z([3,'province-nav-item'])
Z([[7],[3,'index']])
Z([[2,'=='],[[7],[3,'mainActiveIndex']],[[7],[3,'index']]])
Z(z[37])
Z([3,'c'])
Z([[6],[[6],[[7],[3,'items']],[[7],[3,'mainActiveIndex']]],[3,'areaCityList']])
Z([3,'cityCode'])
Z([3,'citySelect'])
Z([[6],[[7],[3,'c']],[3,'cityName']])
Z([3,'display: flex;flex-direction: row;align-items: center;'])
Z([[2,'=='],[[7],[3,'city']],[[6],[[7],[3,'c']],[3,'cityName']]])
Z([3,'agree'])
Z([3,'disagree'])
})(__WXML_GLOBAL__.ops_cached.$gwx_XC_74_1);return __WXML_GLOBAL__.ops_cached.$gwx_XC_74_1
}
__WXML_GLOBAL__.ops_set.$gwx_XC_74=z;
__WXML_GLOBAL__.ops_init.$gwx_XC_74=true;
var x=['./pages/home/index.wxml'];d_[x[0]]={}
var m0=function(e,s,r,gg){
var z=gz$gwx_XC_74_1()
var fUT=_mz(z,'view',['class',0,'style',1],[],e,s,gg)
var oXT=_mz(z,'scroll-view',['refresherEnabled',-1,'scrollY',-1,'bindrefresherrefresh',2,'bindscroll',1,'refresherTriggered',2,'style',3],[],e,s,gg)
var cYT=_n('view')
_rz(z,cYT,'style',6,e,s,gg)
var oZT=_v()
_(cYT,oZT)
if(_oz(z,7,e,s,gg)){oZT.wxVkey=1
var a2T=_n('view')
_rz(z,a2T,'class',8,e,s,gg)
var t3T=_v()
_(a2T,t3T)
if(_oz(z,9,e,s,gg)){t3T.wxVkey=1
}
var e4T=_v()
_(a2T,e4T)
if(_oz(z,10,e,s,gg)){e4T.wxVkey=1
}
var b5T=_v()
_(a2T,b5T)
if(_oz(z,11,e,s,gg)){b5T.wxVkey=1
}
var o6T=_v()
_(a2T,o6T)
if(_oz(z,12,e,s,gg)){o6T.wxVkey=1
}
t3T.wxXCkey=1
e4T.wxXCkey=1
b5T.wxXCkey=1
o6T.wxXCkey=1
_(oZT,a2T)
}
var l1T=_v()
_(cYT,l1T)
if(_oz(z,13,e,s,gg)){l1T.wxVkey=1
var x7T=_n('view')
_rz(z,x7T,'class',14,e,s,gg)
var o8T=_v()
_(x7T,o8T)
if(_oz(z,15,e,s,gg)){o8T.wxVkey=1
}
var f9T=_v()
_(x7T,f9T)
var c0T=function(oBU,hAU,cCU,gg){
var lEU=_mz(z,'view',['bind:tap',18,'class',1,'data-item',2,'style',3],[],oBU,hAU,gg)
var aFU=_n('view')
_rz(z,aFU,'class',22,oBU,hAU,gg)
var tGU=_v()
_(aFU,tGU)
if(_oz(z,23,oBU,hAU,gg)){tGU.wxVkey=1
}
var eHU=_v()
_(aFU,eHU)
if(_oz(z,24,oBU,hAU,gg)){eHU.wxVkey=1
}
tGU.wxXCkey=1
eHU.wxXCkey=1
_(lEU,aFU)
_(cCU,lEU)
return cCU
}
f9T.wxXCkey=2
_2z(z,16,c0T,e,s,gg,f9T,'item','index','index')
o8T.wxXCkey=1
_(l1T,x7T)
}
oZT.wxXCkey=1
l1T.wxXCkey=1
_(oXT,cYT)
_(fUT,oXT)
var cVT=_v()
_(fUT,cVT)
if(_oz(z,25,e,s,gg)){cVT.wxVkey=1
}
var bIU=_mz(z,'van-dialog',['useSlot',-1,'show',26,'showConfirmButton',1],[],e,s,gg)
_(fUT,bIU)
var hWT=_v()
_(fUT,hWT)
if(_oz(z,28,e,s,gg)){hWT.wxVkey=1
var oJU=_mz(z,'view',['catchtouchmove',29,'class',1],[],e,s,gg)
var xKU=_n('view')
_rz(z,xKU,'class',31,e,s,gg)
var oLU=_v()
_(xKU,oLU)
var fMU=function(hOU,cNU,oPU,gg){
var oRU=_mz(z,'view',['bind:tap',34,'class',1,'data-index',2],[],hOU,cNU,gg)
var lSU=_v()
_(oRU,lSU)
if(_oz(z,37,hOU,cNU,gg)){lSU.wxVkey=1
}
var aTU=_v()
_(oRU,aTU)
if(_oz(z,38,hOU,cNU,gg)){aTU.wxVkey=1
}
lSU.wxXCkey=1
aTU.wxXCkey=1
_(oPU,oRU)
return oPU
}
oLU.wxXCkey=2
_2z(z,32,fMU,e,s,gg,oLU,'item','index','index')
var tUU=_v()
_(xKU,tUU)
var eVU=function(oXU,bWU,xYU,gg){
var f1U=_mz(z,'view',['bind:tap',42,'data-name',1,'style',2],[],oXU,bWU,gg)
var c2U=_v()
_(f1U,c2U)
if(_oz(z,45,oXU,bWU,gg)){c2U.wxVkey=1
}
c2U.wxXCkey=1
_(xYU,f1U)
return xYU
}
tUU.wxXCkey=2
_2z(z,40,eVU,e,s,gg,tUU,'c','index','cityCode')
_(oJU,xKU)
_(hWT,oJU)
}
var h3U=_mz(z,'privacy-popup',['bind:agree',46,'bind:disagree',1],[],e,s,gg)
_(fUT,h3U)
cVT.wxXCkey=1
hWT.wxXCkey=1
_(r,fUT)
return r
}
e_[x[0]]={f:m0,j:[],i:[],ti:[],ic:[]}
if(path&&e_[path]){
return function(env,dd,global){$gwxc=0;var root={"tag":"wx-page"};root.children=[]
;g="$gwx_XC_74";var main=e_[path].f
if (typeof global==="undefined")global={};global.f=$gdc(f_[path],"",1);
try{
main(env,{},root,global);
_tsd(root)
}catch(err){
console.log(err)
}
;g="";
return root;
}
}
}
}(__g.a,__g.b,__g.c,__g.d,__g.e,__g.f,__g.g,__g.h,__g.i,__g.j,__g.k,__g.l,__g.m,__g.n,__g.o,__g.p,__g.q,__g.r,__g.s,__g.t,__g.u,__g.v,__g.w,__g.x,__g.y,__g.z,__g.A,__g.B,__g.C,__g.D,__g.E,__g.F,__g.G,__g.H,__g.I,__g.J,__g.K,__g.L,__g.M,__g.N,__g.O,__g.P,__g.Q,__g.R,__g.S,__g.T,__g.U,__g.V,__g.W,__g.X,__g.Y,__g.Z,__g.aa);if(__vd_version_info__.delayedGwx||false)$gwx_XC_74();	if (__vd_version_info__.delayedGwx) __wxAppCode__['pages/home/index.wxml'] = [$gwx_XC_74, './pages/home/index.wxml'];else __wxAppCode__['pages/home/index.wxml'] = $gwx_XC_74( './pages/home/index.wxml' );
	;__wxRoute = "pages/home/index";__wxRouteBegin = true;__wxAppCurrentFile__="pages/home/index.js";define("pages/home/index.js",function(require,module,exports,window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){
"use strict";var t=require("../../utils/config"),e=require("../../utils/jumpUtil"),i=e.toActiveDetail,n=e.toMySignUp,o=e.toOrderDetail,a=e.toMidIndex,s=e.toCommonCardIndex,r=e.toRefundDetail,c=require("../../utils/request/homeData"),u=c.reqeustBanner,g=c.requestRecom,d=c.requestMention,h=(c.transferLatLog,c.getSign),l=require("../../utils/request/garequest").userBuried,m=require("../../utils/util").formatTimeByMention;Page({data:{unionId:"",topOpacity:0,meum:wx.getMenuButtonBoundingClientRect(),topHeight:0,locationArea:"全国",ifLocationAuth:!1,ifCollectShow:!1,collectDialogShow:!1,mentionModel:null,bannerList:[],currentCityCount:null,recomActiveList:[],menus:[{id:"activelobby",icon:"/images/activelobby_home_icon.png",name:"活动",path:""},{id:"findmy",icon:"/images/find_home_icon.png",name:"发现",path:""},{id:"rights",icon:"/images/rights_home_icon.png",name:"权益",path:""},{id:"signup",icon:"/images/signup_home_icon.png",name:"我的报名",path:""}],pageHeight:0,isRefreshing:!1,showFilterPop:!1,items:[],mainActiveIndex:0,city:""},onLoad:function(t){getApp().watch("unionId",this.watchBack),getApp().globalData.unionId&&(this.setData({topHeight:this.data.meum.bottom+2*(this.data.meum.top-wx.getWindowInfo().statusBarHeight),pageHeight:wx.getWindowInfo().windowHeight}),l("800.2.5","小程序进入"),this.initCity(),this.requestData())},watchBack:function(t,e){l("800.2.5","小程序进入"),this.setData({topHeight:this.data.meum.bottom+2*(this.data.meum.top-wx.getWindowInfo().statusBarHeight),pageHeight:wx.getWindowInfo().windowHeight}),this.initCity(),this.requestData()},initCity:function(){var t=wx.getStorageSync("city");this.setData({items:JSON.parse(t)})},requestData:function(){var t=this;u((function(e){t.setData({bannerList:e})}),(function(t){})),this.requestRecommond(),d((function(e){var i=e;i.time=m(e.holdStartDate?e.holdStartDate:e.startDate),t.setData({mentionModel:i})}),(function(t){}))},requestRecommond:function(){var t=this;g(this.data.locationArea,(function(e){t.setData({currentCityCount:e.currentCityCount,recomActiveList:e.list,isRefreshing:!1})}),(function(t){}))},getLocation:function(t){this.data.showFilterPop||l("800.2.5.2","小程序首页点击定位"),this.setData({showFilterPop:!this.data.showFilterPop})},onClickNav:function(t){var e=t.currentTarget.dataset.index;this.setData({mainActiveIndex:e})},citySelect:function(t){var e=t.currentTarget.dataset.name;this.setData({city:e})},reset:function(){this.setData({city:"",locationArea:"全国"}),this.comfirm()},comfirm:function(){var t=this.data.city;t||(t="全国"),this.setData({locationArea:t,showFilterPop:!1}),this.requestRecommond()},closePop:function(){this.setData({showFilterPop:!1})},onBannerClick:function(t){var e=t.currentTarget.dataset.item;console.log(e);var n=e.toPage.split(",");"activityIndex"==n[0]&&(l("800.2.5.1","点击小程序首页banner"),i(n[1],n[2]+"&fromOrigin=02",""))},onButtonClick:function(e){var i=e.currentTarget.dataset.item;if("activelobby"==i.id)l("800.2.5.3","活动大厅-金刚区"),this.switchTab();else if("findmy"==i.id){l("800.2.5.4","明亚发现-金刚区");var o=t.webBase+"#/mingYaFound?userId="+wx.getStorageSync("userId")+"&unionid="+wx.getStorageSync("unionId")+"&fromSource=miniProgram&openId="+wx.getStorageSync("openId");h((function(t){var e=wx.getStorageSync("nickname"),i=wx.getStorageSync("headImgUrl");o=o+"&serialno="+t.serialno+"&checkSign="+t.checkSign+"&nickName="+e+"&headimgurl="+i,wx.navigateTo({url:"/subpage/pages/webpage/index?url="+encodeURIComponent(o)})}),(function(t){}))}else if("rights"==i.id)l("800.2.5.5","权益中心-金刚区"),wx.showToast({title:"敬请期待！",icon:"error"});else{if("Y"!=wx.getStorageSync("wxHasAuth"))return void this.toLogin();l("800.2.5.6","我的报名-金刚区"),n("&changeName=0")}},clickAddFavorite:function(t){l("800.2.5.9","点击收藏小程序");var e=t.currentTarget.dataset.value;this.setData({collectDialogShow:e})},hideAddFavorite:function(){this.setData({ifCollectShow:!1})},switchTab:function(){wx.switchTab({url:"/pages/activelobby/index"})},toSignUp:function(){"Y"==wx.getStorageSync("wxHasAuth")?n("&changeName=0"):this.toLogin()},toDetail:function(t){var e=t.currentTarget.dataset.item;i(e.id,e.situationType+"&fromOrigin=02","")},toMentionActiveDetail:function(){"1"==this.data.mentionModel.miniProgramViewFlag?i(this.data.mentionModel.exerciseId,this.data.mentionModel.situationType+"&fromOrigin=02",""):wx.showModal({title:"",content:"请联系您的经纪人获取活动链接～",showCancel:!1,complete:function(t){t.cancel,t.confirm}})},mentionBtnClickToOrder:function(){var t=this.data.mentionModel;4==t.paymentStatus||6==t.paymentStatus?r(t.signUpId,4==t.paymentStatus?"2":"3"):o("unused="+t.unused+"&status="+t.orderStatus+"&customerSignUpId="+t.signUpId,"navigate")},mentionBtnClickToActive:function(){var t=this.data.mentionModel;if("03"==t.situationType){if(1==t.historyGiftExercise)wx.showToast({title:"活动为限定活动，当前已结束，无法查看详情!",icon:"none"});else if(1==t.giftType){if("20"==t.giftTemplate){var e=t.situationType+"&logId="+(t.logId?t.logId:"")+"&fromOrigin=02&personCode="+t.personCode;a(t.exerciseId,e)}}else if(2==t.giftType){var n=t.situationType+"&logId="+(t.logId?t.logId:"")+"&fromOrigin=02&personCode="+t.personCode;s("",n)}}else if("04"==t.situationType){var o=t.situationType+"&logId="+(t.logId?t.logId:"")+"&fromOrigin=02";i(t.exerciseId,o,"")}else if("05"==t.situationType){var r=t.situationType+"&logId="+(t.logId?t.logId:"")+"&fromOrigin=02&personCode="+t.personCode;i(t.exerciseId,r,"")}},toLogin:function(){wx.navigateTo({url:"/subpage/pages/login/index",events:{loginSuccess:function(t){}}})},agree:function(){},disagree:function(){},onPageScroll:function(t){},onRefresh:function(){this.setData({isRefreshing:!0}),this.requestData(),this.requestRecommond()},onScroll:function(t){var e=t.detail.scrollTop;this.setData({topOpacity:Number(e/300>.95?1:e/300).toFixed(2)})},myCatchTouch:function(){},onReady:function(){},onShow:function(){this.setData({topHeight:this.data.meum.bottom+2*(this.data.meum.top-wx.getWindowInfo().statusBarHeight),pageHeight:wx.getWindowInfo().windowHeight});var t=this;wx.checkIsAddedToMyMiniProgram({success:function(e){t.setData({ifCollectShow:!e.added})}})},onHide:function(){},onUnload:function(){},onPullDownRefresh:function(){},onReachBottom:function(){},onShareAppMessage:function(){return{title:t.shareTitle,path:t.sharePage,imageUrl:t.shareImage}},onShareTimeline:function(){return{title:t.shareTitle,path:t.sharePage,imageUrl:t.shareImage}}});
},{isPage:true,isComponent:true,currentFile:'pages/home/index.js'});require("pages/home/index.js");