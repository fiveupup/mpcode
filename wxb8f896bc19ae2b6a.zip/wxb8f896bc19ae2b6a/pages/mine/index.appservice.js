$gwx_XC_75=function(_,_v,_n,_p,_s,_wp,_wl,$gwn,$gwl,$gwh,wh,$gstack,$gwrt,gra,grb,TestTest,wfor,_ca,_da,_r,_rz,_o,_oz,_1,_1z,_2,_2z,_m,_mz,nv_getDate,nv_getRegExp,nv_console,nv_parseInt,nv_parseFloat,nv_isNaN,nv_isFinite,nv_decodeURI,nv_decodeURIComponent,nv_encodeURI,nv_encodeURIComponent,$gdc,nv_JSON,_af,_gv,_ai,_grp,_gd,_gapi,$ixc,_ic,_w,_ev,_tsd){return function(path,global){
if(typeof global==='undefined'){if (typeof __GWX_GLOBAL__==='undefined')global={};else global=__GWX_GLOBAL__;}if(typeof __WXML_GLOBAL__ === 'undefined') {__WXML_GLOBAL__={};
}__WXML_GLOBAL__.modules = __WXML_GLOBAL__.modules || {};
var e_={}
if(typeof(global.entrys)==='undefined')global.entrys={};e_=global.entrys;
var d_={}
if(typeof(global.defines)==='undefined')global.defines={};d_=global.defines;
var f_={}
if(typeof(global.modules)==='undefined')global.modules={};f_=global.modules || {};
var p_={}
__WXML_GLOBAL__.ops_cached = __WXML_GLOBAL__.ops_cached || {}
__WXML_GLOBAL__.ops_set = __WXML_GLOBAL__.ops_set || {};
__WXML_GLOBAL__.ops_init = __WXML_GLOBAL__.ops_init || {};
var z=__WXML_GLOBAL__.ops_set.$gwx_XC_75 || [];
function gz$gwx_XC_75_1(){
if( __WXML_GLOBAL__.ops_cached.$gwx_XC_75_1)return __WXML_GLOBAL__.ops_cached.$gwx_XC_75_1
__WXML_GLOBAL__.ops_cached.$gwx_XC_75_1=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
Z([3,'user-view'])
Z([[7],[3,'userHasAuth']])
Z([[6],[[7],[3,'userInfo']],[3,'phone']])
})(__WXML_GLOBAL__.ops_cached.$gwx_XC_75_1);return __WXML_GLOBAL__.ops_cached.$gwx_XC_75_1
}
__WXML_GLOBAL__.ops_set.$gwx_XC_75=z;
__WXML_GLOBAL__.ops_init.$gwx_XC_75=true;
var x=['./pages/mine/index.wxml'];d_[x[0]]={}
var m0=function(e,s,r,gg){
var z=gz$gwx_XC_75_1()
var c5U=_n('view')
_rz(z,c5U,'class',0,e,s,gg)
var o6U=_v()
_(c5U,o6U)
if(_oz(z,1,e,s,gg)){o6U.wxVkey=1
var l7U=_v()
_(o6U,l7U)
if(_oz(z,2,e,s,gg)){l7U.wxVkey=1
}
l7U.wxXCkey=1
}
else{o6U.wxVkey=2
}
o6U.wxXCkey=1
_(r,c5U)
return r
}
e_[x[0]]={f:m0,j:[],i:[],ti:[],ic:[]}
if(path&&e_[path]){
return function(env,dd,global){$gwxc=0;var root={"tag":"wx-page"};root.children=[]
;g="$gwx_XC_75";var main=e_[path].f
if (typeof global==="undefined")global={};global.f=$gdc(f_[path],"",1);
try{
main(env,{},root,global);
_tsd(root)
}catch(err){
console.log(err)
}
;g="";
return root;
}
}
}
}(__g.a,__g.b,__g.c,__g.d,__g.e,__g.f,__g.g,__g.h,__g.i,__g.j,__g.k,__g.l,__g.m,__g.n,__g.o,__g.p,__g.q,__g.r,__g.s,__g.t,__g.u,__g.v,__g.w,__g.x,__g.y,__g.z,__g.A,__g.B,__g.C,__g.D,__g.E,__g.F,__g.G,__g.H,__g.I,__g.J,__g.K,__g.L,__g.M,__g.N,__g.O,__g.P,__g.Q,__g.R,__g.S,__g.T,__g.U,__g.V,__g.W,__g.X,__g.Y,__g.Z,__g.aa);if(__vd_version_info__.delayedGwx||false)$gwx_XC_75();	if (__vd_version_info__.delayedGwx) __wxAppCode__['pages/mine/index.wxml'] = [$gwx_XC_75, './pages/mine/index.wxml'];else __wxAppCode__['pages/mine/index.wxml'] = $gwx_XC_75( './pages/mine/index.wxml' );
	;__wxRoute = "pages/mine/index";__wxRouteBegin = true;__wxAppCurrentFile__="pages/mine/index.js";define("pages/mine/index.js",function(require,module,exports,window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){
"use strict";var e=require("../../utils/config"),n=require("../../utils/jumpUtil"),t=n.toOrderList,i=n.toMySignUp,a=require("../../utils/request/garequest").userBuried,o=require("../../utils/request/homeData").getSign,r=require("../../utils/request/mineData"),s=r.requestMine,u=r.requestUserInfo;require("../../utils/stringutils").isNullOrEmptyStr;Page({data:{menus:[{id:"footprint",icon:"/images/footprint_icon.png",name:"我的足迹",path:e.webBase+"#/myfootprint",spm:"800.2.5.8.2",spmName:"个人中心点击我的足迹"},{id:"collect",icon:"/images/collect_icon.png",name:"我的收藏",path:e.webBase+"#/mycollect",spm:"800.2.5.8.3",spmName:"个人中心点击我的收藏"},{id:"members",icon:"/images/member_icon.png",name:"成员管理",path:e.webBase+"#/members",spm:"800.2.5.8.4",spmName:"个人中心点击成员管理"},{id:"signup",icon:"/images/signup_icon.png",name:"我的报名",path:e.webBase+"#/my/registration",spm:"800.2.5.8.5",spmName:"个人中心点击我的报名"},{id:"order",icon:"/images/order_icon.png",name:"我的订单",path:e.webBase+"#/orderList",spm:"800.2.5.8.6",spmName:"个人中心点击我的订单"}],userHasAuth:!1,userInfo:{}},onLoad:function(e){},requestData:function(){var e=wx.getStorageSync("wxHasAuth");this.setData({userHasAuth:"Y"==e});var n=this;u((function(t){var i=t,a=n.data.userInfo;a.name=i.name,a.headImgUrl=i.headImgUrl,a.phone=i.phone,"Y"==e&&s((function(e){a.userExerciseSum=e.userExerciseSum,a.userExerciseInviteSum=e.userExerciseInviteSum,a.userExerciseMonthSum=e.userExerciseMonthSum,n.setData({userInfo:a})}),(function(e){}))}),(function(e){}))},toSign:function(){"Y"==wx.getStorageSync("wxHasAuth")?i("&changeName=0"):this.toLogin()},onItemClick:function(e){if("Y"==wx.getStorageSync("wxHasAuth")){var n=e.currentTarget.dataset.item;if(a(n.spm,n.spmName),"footprint"==n.id||"collect"==n.id){var r=n.path+"?userId="+wx.getStorageSync("userId")+"&unionid="+wx.getStorageSync("unionId")+"&fromSource=miniProgram&openId="+wx.getStorageSync("openId");o((function(e){var n=wx.getStorageSync("nickname"),t=wx.getStorageSync("headImgUrl");r=r+"&serialno="+e.serialno+"&checkSign="+e.checkSign+"&nickname="+n+"&headimgurl="+t,wx.navigateTo({url:"/subpage/pages/webpage/index?url="+encodeURIComponent(r)})}),(function(e){}))}else"order"==n.id?t():"signup"==n.id?i("&changeName=0"):o((function(e){var t=wx.getStorageSync("nickname"),i=wx.getStorageSync("headImgUrl"),a=n.path+"?serialno="+e.serialno+"&checkSign="+e.checkSign+"&nickname="+t+"&headimgurl="+i;wx.navigateTo({url:"/subpage/pages/webpage/index?url="+encodeURIComponent(a)})}),(function(e){}))}else this.toLogin()},toInfoDetail:function(){a("800.2.5.8.1","点击我的页面编辑按钮"),wx.navigateTo({url:"/subpage/pages/mineinfo/index"})},toLogin:function(){wx.navigateTo({url:"/subpage/pages/login/index",events:{loginSuccess:function(e){}}})},onTabItemTap:function(e){a("800.2.5.8","我的-底部菜单")},onReady:function(){},onShow:function(){this.requestData()},onHide:function(){},onUnload:function(){},onPullDownRefresh:function(){},onReachBottom:function(){},onShareAppMessage:function(){return{title:e.shareTitle,path:e.sharePage,imageUrl:e.shareImage}},onShareTimeline:function(){return{title:e.shareTitle,path:e.sharePage,imageUrl:e.shareImage}}});
},{isPage:true,isComponent:true,currentFile:'pages/mine/index.js'});require("pages/mine/index.js");