$gwx_XC_76=function(_,_v,_n,_p,_s,_wp,_wl,$gwn,$gwl,$gwh,wh,$gstack,$gwrt,gra,grb,TestTest,wfor,_ca,_da,_r,_rz,_o,_oz,_1,_1z,_2,_2z,_m,_mz,nv_getDate,nv_getRegExp,nv_console,nv_parseInt,nv_parseFloat,nv_isNaN,nv_isFinite,nv_decodeURI,nv_decodeURIComponent,nv_encodeURI,nv_encodeURIComponent,$gdc,nv_JSON,_af,_gv,_ai,_grp,_gd,_gapi,$ixc,_ic,_w,_ev,_tsd){return function(path,global){
if(typeof global==='undefined'){if (typeof __GWX_GLOBAL__==='undefined')global={};else global=__GWX_GLOBAL__;}if(typeof __WXML_GLOBAL__ === 'undefined') {__WXML_GLOBAL__={};
}__WXML_GLOBAL__.modules = __WXML_GLOBAL__.modules || {};
var e_={}
if(typeof(global.entrys)==='undefined')global.entrys={};e_=global.entrys;
var d_={}
if(typeof(global.defines)==='undefined')global.defines={};d_=global.defines;
var f_={}
if(typeof(global.modules)==='undefined')global.modules={};f_=global.modules || {};
var p_={}
__WXML_GLOBAL__.ops_cached = __WXML_GLOBAL__.ops_cached || {}
__WXML_GLOBAL__.ops_set = __WXML_GLOBAL__.ops_set || {};
__WXML_GLOBAL__.ops_init = __WXML_GLOBAL__.ops_init || {};
var z=__WXML_GLOBAL__.ops_set.$gwx_XC_76 || [];
function gz$gwx_XC_76_1(){
if( __WXML_GLOBAL__.ops_cached.$gwx_XC_76_1)return __WXML_GLOBAL__.ops_cached.$gwx_XC_76_1
__WXML_GLOBAL__.ops_cached.$gwx_XC_76_1=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
Z([3,'page'])
Z([3,'true'])
Z(z[1])
Z([3,'banner-container'])
Z(z[1])
Z([[7],[3,'banner']])
Z([3,'index'])
Z([3,'onBannerClick'])
Z([3,'image-item'])
Z([[7],[3,'item']])
Z([3,'aspectFill'])
Z([[6],[[7],[3,'item']],[3,'picurl']])
Z([3,'module-container content-contain'])
Z([3,'module-head-view'])
Z([3,'module-head-divide'])
Z([3,'module-head-text'])
Z([3,'权益分类'])
Z([3,'right-icon'])
Z([3,'/images/gray_pull_icon.png'])
Z([3,'func-item'])
Z([[7],[3,'types']])
Z(z[6])
Z([3,'func-item-inner right-item-active'])
Z([[7],[3,'index']])
Z([3,'item-text'])
Z([a,[[6],[[7],[3,'item']],[3,'name']]])
Z([1,false])
Z([3,'goods-grid'])
Z([1,2])
Z([1,9])
Z(z[20])
Z(z[6])
Z([3,'goods-item'])
Z([3,'goods-image'])
Z([3,'goods-name'])
Z([3,'啊街坊邻居多了几分拉倒随机发垃圾'])
Z([3,'display: flex;flex-direction: row;align-items: center;justify-content: space-between;'])
Z([3,'goods-price'])
Z([3,'3000积分'])
Z([3,'goods-exhcange'])
Z([3,'已兑换 2000'])
Z([3,'common-bottom-tip'])
Z([3,'·我的保险·我的生活·'])
})(__WXML_GLOBAL__.ops_cached.$gwx_XC_76_1);return __WXML_GLOBAL__.ops_cached.$gwx_XC_76_1
}
__WXML_GLOBAL__.ops_set.$gwx_XC_76=z;
__WXML_GLOBAL__.ops_init.$gwx_XC_76=true;
var x=['./pages/rights/index.wxml'];d_[x[0]]={}
var m0=function(e,s,r,gg){
var z=gz$gwx_XC_76_1()
var h1AB=_n('view')
_rz(z,h1AB,'class',0,e,s,gg)
var o2AB=_mz(z,'swiper',['autoplay',1,'circular',1,'class',2,'indicatorDots',3],[],e,s,gg)
var c3AB=_v()
_(o2AB,c3AB)
var o4AB=function(a6AB,l5AB,t7AB,gg){
var b9AB=_n('swiper-item')
var o0AB=_mz(z,'image',['bindtap',7,'class',1,'data-item',2,'mode',3,'src',4],[],a6AB,l5AB,gg)
_(b9AB,o0AB)
_(t7AB,b9AB)
return t7AB
}
c3AB.wxXCkey=2
_2z(z,5,o4AB,e,s,gg,c3AB,'item','index','index')
_(h1AB,o2AB)
var xABB=_n('view')
_rz(z,xABB,'class',12,e,s,gg)
var oBBB=_n('view')
_rz(z,oBBB,'class',13,e,s,gg)
var fCBB=_n('view')
_rz(z,fCBB,'class',14,e,s,gg)
_(oBBB,fCBB)
var cDBB=_n('view')
_rz(z,cDBB,'class',15,e,s,gg)
var hEBB=_oz(z,16,e,s,gg)
_(cDBB,hEBB)
_(oBBB,cDBB)
var oFBB=_mz(z,'image',['class',17,'src',1],[],e,s,gg)
_(oBBB,oFBB)
_(xABB,oBBB)
var cGBB=_n('view')
_rz(z,cGBB,'class',19,e,s,gg)
var oHBB=_v()
_(cGBB,oHBB)
var lIBB=function(tKBB,aJBB,eLBB,gg){
var oNBB=_mz(z,'view',['class',22,'data-index',1],[],tKBB,aJBB,gg)
var xOBB=_n('text')
_rz(z,xOBB,'class',24,tKBB,aJBB,gg)
var oPBB=_oz(z,25,tKBB,aJBB,gg)
_(xOBB,oPBB)
_(oNBB,xOBB)
_(eLBB,oNBB)
return eLBB
}
oHBB.wxXCkey=2
_2z(z,20,lIBB,e,s,gg,oHBB,'item','index','index')
_(xABB,cGBB)
var fQBB=_mz(z,'van-grid',['border',26,'class',1,'columnNum',2,'gutter',3],[],e,s,gg)
var cRBB=_v()
_(fQBB,cRBB)
var hSBB=function(cUBB,oTBB,oVBB,gg){
var aXBB=_n('van-grid-item')
aXBB.attr['useSlot']=true
var tYBB=_n('view')
_rz(z,tYBB,'class',32,cUBB,oTBB,gg)
var eZBB=_n('image')
_rz(z,eZBB,'class',33,cUBB,oTBB,gg)
_(tYBB,eZBB)
var b1BB=_n('text')
_rz(z,b1BB,'class',34,cUBB,oTBB,gg)
var o2BB=_oz(z,35,cUBB,oTBB,gg)
_(b1BB,o2BB)
_(tYBB,b1BB)
var x3BB=_n('view')
_rz(z,x3BB,'style',36,cUBB,oTBB,gg)
var o4BB=_n('view')
_rz(z,o4BB,'class',37,cUBB,oTBB,gg)
var f5BB=_oz(z,38,cUBB,oTBB,gg)
_(o4BB,f5BB)
_(x3BB,o4BB)
var c6BB=_n('view')
_rz(z,c6BB,'class',39,cUBB,oTBB,gg)
var h7BB=_oz(z,40,cUBB,oTBB,gg)
_(c6BB,h7BB)
_(x3BB,c6BB)
_(tYBB,x3BB)
_(aXBB,tYBB)
_(oVBB,aXBB)
return oVBB
}
cRBB.wxXCkey=4
_2z(z,30,hSBB,e,s,gg,cRBB,'item','index','index')
_(xABB,fQBB)
var o8BB=_n('view')
_rz(z,o8BB,'class',41,e,s,gg)
var c9BB=_oz(z,42,e,s,gg)
_(o8BB,c9BB)
_(xABB,o8BB)
_(h1AB,xABB)
_(r,h1AB)
return r
}
e_[x[0]]={f:m0,j:[],i:[],ti:[],ic:[]}
if(path&&e_[path]){
outerGlobal.__wxml_comp_version__=0.02
return function(env,dd,global){$gwxc=0;var root={"tag":"wx-page"};root.children=[]
;g="$gwx_XC_76";var main=e_[path].f
if (typeof global==="undefined")global={};global.f=$gdc(f_[path],"",1);
if(typeof(outerGlobal.__webview_engine_version__)!='undefined'&&outerGlobal.__webview_engine_version__+1e-6>=0.02+1e-6&&outerGlobal.__mergeData__)
{
env=outerGlobal.__mergeData__(env,dd);
}
try{
main(env,{},root,global);
_tsd(root)
if(typeof(outerGlobal.__webview_engine_version__)=='undefined'|| outerGlobal.__webview_engine_version__+1e-6<0.01+1e-6){return _ev(root);}
}catch(err){
console.log(err)
}
;g="";
return root;
}
}
}
}(__g.a,__g.b,__g.c,__g.d,__g.e,__g.f,__g.g,__g.h,__g.i,__g.j,__g.k,__g.l,__g.m,__g.n,__g.o,__g.p,__g.q,__g.r,__g.s,__g.t,__g.u,__g.v,__g.w,__g.x,__g.y,__g.z,__g.A,__g.B,__g.C,__g.D,__g.E,__g.F,__g.G,__g.H,__g.I,__g.J,__g.K,__g.L,__g.M,__g.N,__g.O,__g.P,__g.Q,__g.R,__g.S,__g.T,__g.U,__g.V,__g.W,__g.X,__g.Y,__g.Z,__g.aa);if(__vd_version_info__.delayedGwx||false)$gwx_XC_76();	if (__vd_version_info__.delayedGwx) __wxAppCode__['pages/rights/index.wxml'] = [$gwx_XC_76, './pages/rights/index.wxml'];else __wxAppCode__['pages/rights/index.wxml'] = $gwx_XC_76( './pages/rights/index.wxml' );
	
var noCss=typeof __vd_version_info__!=='undefined'&&__vd_version_info__.noCss===true;if(!noCss){__wxAppCode__['pages/rights/index.wxss'] = setCssToHead([".",[1],"page{background-color:#f4f4f4;height:100vh}\n.",[1],"banner-container,.",[1],"page{display:-webkit-flex;display:flex;-webkit-flex-direction:column;flex-direction:column}\n.",[1],"banner-container{background-color:#fff;height:",[0,200],";padding-bottom:",[0,20],";padding-top:",[0,10],"}\n.",[1],"banner-container .",[1],"wx-swiper-dot{border-radius:50%;width:",[0,6],"}\n.",[1],"banner-container .",[1],"wx-swiper-dot,.",[1],"banner-container .",[1],"wx-swiper-dot-active{background-color:#fff;display:-webkit-inline-flex;display:inline-flex;height:",[0,6],"}\n.",[1],"banner-container .",[1],"wx-swiper-dot-active{border-radius:",[0,40],";width:",[0,20],"}\n.",[1],"image-item{border-radius:",[0,20],";height:100%;margin-left:",[0,24],";margin-right:",[0,24],";width:100%}\n.",[1],"content-contain{display:-webkit-flex;display:flex;-webkit-flex-direction:column;flex-direction:column;margin:",[0,16]," ",[0,24]," ",[0,24],"}\n.",[1],"right-icon{height:",[0,30],";margin-right:",[0,24],";width:",[0,30],"}\n.",[1],"func-item{grid-row-gap:",[0,16],";grid-column-gap:",[0,18],";display:grid;grid-template-columns:repeat(4,calc((100% - ",[0,54],") / 4));margin:",[0,16]," ",[0,24]," ",[0,24],"}\n.",[1],"func-item-inner{-webkit-align-items:center;align-items:center;display:-webkit-flex;display:flex;height:",[0,57],";-webkit-justify-content:center;justify-content:center}\n.",[1],"item-text{font-size:",[0,24],";line-height:",[0,33],";text-align:center}\n.",[1],"right-item-active{background-color:#fff6e2;border:",[0,2]," solid #ff9810;border-radius:",[0,10],";color:#ff9810;font-weight:600}\n.",[1],"right-item-normal{background-color:#f6f6f6;border-radius:",[0,10],";color:#333;font-weight:400}\n.",[1],"goods-view{grid-row-gap:",[0,24],";grid-column-gap:",[0,18],";display:grid;grid-template-columns:repeat(2,calc((100% - ",[0,114],") / 2));margin:0 ",[0,24]," ",[0,24],"}\n.",[1],"goods-grid{margin:0 ",[0,6]," ",[0,24],"}\n.",[1],"van-grid-item__content{padding:0!important}\n.",[1],"goods-item{background-color:#ffebcd;display:-webkit-flex;display:flex;-webkit-flex-direction:column;flex-direction:column;width:100%}\n.",[1],"goods-image{height:",[0,381],";width:100%}\n.",[1],"goods-name{color:#333;display:block;font-size:",[0,28],";font-weight:700;line-height:",[0,40],";margin-bottom:",[0,8],";margin-top:",[0,16],";overflow:hidden;text-overflow:ellipsis;white-space:nowrap}\n.",[1],"goods-price{color:#fe2727;font-size:",[0,24],";font-weight:600;line-height:",[0,33],"}\n.",[1],"goods-exhcange{color:#888;font-size:",[0,20],";font-weight:400;line-height:",[0,24],"}\n.",[1],"common-bottom-tip{color:#c7cad9;font-size:",[0,20],";font-weight:400;letter-spacing:10px;line-height:",[0,28],";margin-bottom:",[0,24],";margin-top:",[0,24],";text-align:center;width:100%}\n",],undefined,{path:"./pages/rights/index.wxss"});
}