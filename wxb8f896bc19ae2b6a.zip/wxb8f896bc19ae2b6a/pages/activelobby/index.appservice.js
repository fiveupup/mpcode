$gwx_XC_73=function(_,_v,_n,_p,_s,_wp,_wl,$gwn,$gwl,$gwh,wh,$gstack,$gwrt,gra,grb,TestTest,wfor,_ca,_da,_r,_rz,_o,_oz,_1,_1z,_2,_2z,_m,_mz,nv_getDate,nv_getRegExp,nv_console,nv_parseInt,nv_parseFloat,nv_isNaN,nv_isFinite,nv_decodeURI,nv_decodeURIComponent,nv_encodeURI,nv_encodeURIComponent,$gdc,nv_JSON,_af,_gv,_ai,_grp,_gd,_gapi,$ixc,_ic,_w,_ev,_tsd){return function(path,global){
if(typeof global==='undefined'){if (typeof __GWX_GLOBAL__==='undefined')global={};else global=__GWX_GLOBAL__;}if(typeof __WXML_GLOBAL__ === 'undefined') {__WXML_GLOBAL__={};
}__WXML_GLOBAL__.modules = __WXML_GLOBAL__.modules || {};
var e_={}
if(typeof(global.entrys)==='undefined')global.entrys={};e_=global.entrys;
var d_={}
if(typeof(global.defines)==='undefined')global.defines={};d_=global.defines;
var f_={}
if(typeof(global.modules)==='undefined')global.modules={};f_=global.modules || {};
var p_={}
__WXML_GLOBAL__.ops_cached = __WXML_GLOBAL__.ops_cached || {}
__WXML_GLOBAL__.ops_set = __WXML_GLOBAL__.ops_set || {};
__WXML_GLOBAL__.ops_init = __WXML_GLOBAL__.ops_init || {};
var z=__WXML_GLOBAL__.ops_set.$gwx_XC_73 || [];
function gz$gwx_XC_73_1(){
if( __WXML_GLOBAL__.ops_cached.$gwx_XC_73_1)return __WXML_GLOBAL__.ops_cached.$gwx_XC_73_1
__WXML_GLOBAL__.ops_cached.$gwx_XC_73_1=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
Z([3,'page'])
Z([a,[3,'height: '],[[7],[3,'contentHeight']],[3,'px;']])
Z([3,'myCatchTouch'])
Z([3,'lobby-top'])
Z([[7],[3,'filters']])
Z([3,'index'])
Z([[2,'!='],[[7],[3,'index']],[[2,'-'],[[6],[[7],[3,'filters']],[3,'length']],[1,1]]])
Z([[2,'||'],[[2,'=='],[[7],[3,'activeList']],[1,null]],[[2,'=='],[[6],[[7],[3,'activeList']],[3,'length']],[1,0]]])
Z([3,'handleLoadMore'])
Z([3,'handleRefresh'])
Z([3,'list'])
Z([[6],[[7],[3,'listProperty']],[3,'isLastPage']])
Z([[6],[[7],[3,'listProperty']],[3,'isLoading']])
Z([[6],[[7],[3,'listProperty']],[3,'isRefreshering']])
Z([[7],[3,'scrollTop']])
Z([3,'height: 100vh;'])
Z([[7],[3,'activeList']])
Z(z[5])
Z([3,'toDetail'])
Z([3,'module-container recommand-item'])
Z([[7],[3,'item']])
Z([3,'reco-active-content'])
Z([[6],[[7],[3,'item']],[3,'tagName']])
Z([[6],[[7],[3,'item']],[3,'holdStartDate']])
Z([[6],[[7],[3,'item']],[3,'exerciseSignUpNum']])
Z([[7],[3,'showFilterPop']])
Z(z[2])
Z([3,'filter-pop-content'])
Z([[2,'=='],[1,'province'],[[7],[3,'filterType']]])
Z([3,'filter-pop-content-group fr'])
Z([[7],[3,'items']])
Z(z[5])
Z([3,'onClickNav'])
Z([3,'province-nav-item'])
Z([[7],[3,'index']])
Z([[2,'=='],[[7],[3,'mainActiveIndex']],[[7],[3,'index']]])
Z(z[35])
Z([3,'c'])
Z([[6],[[6],[[7],[3,'items']],[[7],[3,'mainActiveIndex']]],[3,'areaCityList']])
Z([3,'cityCode'])
Z([3,'citySelect'])
Z([[6],[[7],[3,'c']],[3,'cityName']])
Z([3,'display: flex;flex-direction: row;align-items: center;'])
Z([[2,'=='],[[7],[3,'city']],[[6],[[7],[3,'c']],[3,'cityName']]])
Z([[2,'=='],[1,'classification'],[[7],[3,'filterType']]])
})(__WXML_GLOBAL__.ops_cached.$gwx_XC_73_1);return __WXML_GLOBAL__.ops_cached.$gwx_XC_73_1
}
__WXML_GLOBAL__.ops_set.$gwx_XC_73=z;
__WXML_GLOBAL__.ops_init.$gwx_XC_73=true;
var x=['./pages/activelobby/index.wxml'];d_[x[0]]={}
var m0=function(e,s,r,gg){
var z=gz$gwx_XC_73_1()
var bKS=_mz(z,'view',['class',0,'style',1],[],e,s,gg)
var oNS=_n('van-sticky')
var fOS=_mz(z,'view',['catchtouchmove',2,'class',1],[],e,s,gg)
var cPS=_v()
_(fOS,cPS)
var hQS=function(cSS,oRS,oTS,gg){
var aVS=_v()
_(oTS,aVS)
if(_oz(z,6,cSS,oRS,gg)){aVS.wxVkey=1
}
aVS.wxXCkey=1
return oTS
}
cPS.wxXCkey=2
_2z(z,4,hQS,e,s,gg,cPS,'item','index','index')
_(oNS,fOS)
_(bKS,oNS)
var oLS=_v()
_(bKS,oLS)
if(_oz(z,7,e,s,gg)){oLS.wxVkey=1
}
else{oLS.wxVkey=2
var tWS=_mz(z,'loadMoreList',['bindloadMore',8,'bindrefresh',1,'class',2,'isLastPage',3,'isLoading',4,'isRefreshering',5,'scrollTop',6,'style',7],[],e,s,gg)
var eXS=_v()
_(tWS,eXS)
var bYS=function(x1S,oZS,o2S,gg){
var c4S=_mz(z,'view',['bind:tap',18,'class',1,'data-item',2],[],x1S,oZS,gg)
var h5S=_n('view')
_rz(z,h5S,'class',21,x1S,oZS,gg)
var o6S=_v()
_(h5S,o6S)
if(_oz(z,22,x1S,oZS,gg)){o6S.wxVkey=1
}
var c7S=_v()
_(h5S,c7S)
if(_oz(z,23,x1S,oZS,gg)){c7S.wxVkey=1
}
var o8S=_v()
_(h5S,o8S)
if(_oz(z,24,x1S,oZS,gg)){o8S.wxVkey=1
}
o6S.wxXCkey=1
c7S.wxXCkey=1
o8S.wxXCkey=1
_(c4S,h5S)
_(o2S,c4S)
return o2S
}
eXS.wxXCkey=2
_2z(z,16,bYS,e,s,gg,eXS,'item','index','index')
_(oLS,tWS)
}
var xMS=_v()
_(bKS,xMS)
if(_oz(z,25,e,s,gg)){xMS.wxVkey=1
var l9S=_mz(z,'view',['catchtouchmove',26,'class',1],[],e,s,gg)
var a0S=_v()
_(l9S,a0S)
if(_oz(z,28,e,s,gg)){a0S.wxVkey=1
var eBT=_n('view')
_rz(z,eBT,'class',29,e,s,gg)
var bCT=_v()
_(eBT,bCT)
var oDT=function(oFT,xET,fGT,gg){
var hIT=_mz(z,'view',['bind:tap',32,'class',1,'data-index',2],[],oFT,xET,gg)
var oJT=_v()
_(hIT,oJT)
if(_oz(z,35,oFT,xET,gg)){oJT.wxVkey=1
}
var cKT=_v()
_(hIT,cKT)
if(_oz(z,36,oFT,xET,gg)){cKT.wxVkey=1
}
oJT.wxXCkey=1
cKT.wxXCkey=1
_(fGT,hIT)
return fGT
}
bCT.wxXCkey=2
_2z(z,30,oDT,e,s,gg,bCT,'item','index','index')
var oLT=_v()
_(eBT,oLT)
var lMT=function(tOT,aNT,ePT,gg){
var oRT=_mz(z,'view',['bind:tap',40,'data-name',1,'style',2],[],tOT,aNT,gg)
var xST=_v()
_(oRT,xST)
if(_oz(z,43,tOT,aNT,gg)){xST.wxVkey=1
}
xST.wxXCkey=1
_(ePT,oRT)
return ePT
}
oLT.wxXCkey=2
_2z(z,38,lMT,e,s,gg,oLT,'c','index','cityCode')
_(a0S,eBT)
}
var tAT=_v()
_(l9S,tAT)
if(_oz(z,44,e,s,gg)){tAT.wxVkey=1
}
a0S.wxXCkey=1
tAT.wxXCkey=1
_(xMS,l9S)
}
oLS.wxXCkey=1
oLS.wxXCkey=3
xMS.wxXCkey=1
_(r,bKS)
return r
}
e_[x[0]]={f:m0,j:[],i:[],ti:[],ic:[]}
if(path&&e_[path]){
return function(env,dd,global){$gwxc=0;var root={"tag":"wx-page"};root.children=[]
;g="$gwx_XC_73";var main=e_[path].f
if (typeof global==="undefined")global={};global.f=$gdc(f_[path],"",1);
try{
main(env,{},root,global);
_tsd(root)
}catch(err){
console.log(err)
}
;g="";
return root;
}
}
}
}(__g.a,__g.b,__g.c,__g.d,__g.e,__g.f,__g.g,__g.h,__g.i,__g.j,__g.k,__g.l,__g.m,__g.n,__g.o,__g.p,__g.q,__g.r,__g.s,__g.t,__g.u,__g.v,__g.w,__g.x,__g.y,__g.z,__g.A,__g.B,__g.C,__g.D,__g.E,__g.F,__g.G,__g.H,__g.I,__g.J,__g.K,__g.L,__g.M,__g.N,__g.O,__g.P,__g.Q,__g.R,__g.S,__g.T,__g.U,__g.V,__g.W,__g.X,__g.Y,__g.Z,__g.aa);if(__vd_version_info__.delayedGwx||false)$gwx_XC_73();	if (__vd_version_info__.delayedGwx) __wxAppCode__['pages/activelobby/index.wxml'] = [$gwx_XC_73, './pages/activelobby/index.wxml'];else __wxAppCode__['pages/activelobby/index.wxml'] = $gwx_XC_73( './pages/activelobby/index.wxml' );
	;__wxRoute = "pages/activelobby/index";__wxRouteBegin = true;__wxAppCurrentFile__="pages/activelobby/index.js";define("pages/activelobby/index.js",function(require,module,exports,window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){
"use strict";var t=require("../../utils/request/activelobby"),e=t.requestTypes,a=t.requestList,i=require("../../utils/config"),s=require("../../utils/jumpUtil").toActiveDetail,r=require("../../utils/request/garequest").userBuried;Page({data:{scrollTop:0,contentHeight:0,searchValue:"",items:[],filters:[{name:"全国",id:"province",code:"",codename:"全国"},{name:"分类选择",id:"classification",code:"",codename:""}],tagList:[],mainActiveIndex:0,activeId:1,showFilterPop:!1,filterType:"",tagId:"",tagName:"",multTags:[],city:"",activeList:[],listProperty:{isRefreshering:!1,isLoading:!1,isLastPage:!1},listReqModel:{city:"",tagId:"",name:"",page:1}},onLoad:function(t){var e=wx.getStorageSync("city");this.setData({items:JSON.parse(e),contentHeight:wx.getStorageSync("winHeight")-wx.getStorageSync("tabHeight")}),this.getType(),this.getList()},getType:function(){var t=this;e((function(e){t.setData({tagList:e})}),(function(t){}))},getList:function(){var t=this;a(this.data.listReqModel,(function(e){var a=t.data.listProperty;a.isLoading=!1,a.isRefreshering=!1,a.isLastPage=e.length<10,t.setData({listProperty:a,activeList:1==t.data.listReqModel.page?e:t.data.activeList.concat(e)})}),(function(e){var a=t.data.listProperty;a.isLoading=!1,a.isRefreshering=!1,a.isLastPage=!1,t.setData({listProperty:a})}))},citySelect:function(t){var e=t.currentTarget.dataset.name;this.setData({city:e})},reset:function(){this.data.filterType;var t=this.data.listReqModel,e=this.data.filters;t.city="",e[0].name="全国",t.tagId="",e[1].name="分类选择",this.setData({city:"",multTags:[],tagId:"",tagName:"",listReqModel:t}),this.comfirm()},comfirm:function(){var t=this.data.listReqModel;t.city=this.data.city,t.tagId=this.data.tagId,t.name=this.data.searchValue,t.page=1;var e=this.data.filters;this.data.city&&(e[0].name=this.data.city),this.data.tagName&&(e[1].name=this.data.tagName),this.setData({filterType:"",showFilterPop:!1,listReqModel:t,filters:e,scrollTop:0}),this.getList()},onSearchInput:function(t){var e=t.detail.value;this.setData({searchValue:e}),this.comfirm()},onFilterClick:function(t){var e=t.currentTarget.dataset.item;e.id==this.data.filterType?this.closePop():this.setData({filterType:e.id,showFilterPop:!0})},onTypeClick:function(t){var e=t.currentTarget.dataset.item,a=t.currentTarget.dataset.parentid,i=this.data.multTags,s=-1;for(var r in i){if(i[r].parentid==""+a){s=r;break}}-1!=s?e.id==i[s].id?i.splice(s,1):(i[s].id=e.id,i[s].name=e.name):i.push({parentid:""+a,id:e.id,name:e.name});var n="",o="";for(var d in i){var l=i[d];n+=l.id,o+=l.name,d!=i.length-1&&(n+=",",o+=",")}this.data.multTags=i,this.setData({tagId:n,tagName:o})},onClickNav:function(t){var e=t.currentTarget.dataset.index;this.setData({mainActiveIndex:e})},onClickItem:function(t){t.currentTarget.dataset.id;var e=this.data.activeId===detail.id?null:detail.id;this.setData({activeId:e})},closePop:function(){this.setData({filterType:"",showFilterPop:!1})},handleRefresh:function(){var t=this.data.listReqModel;t.page=1;var e=this.data.listProperty;e.isRefreshering=!0,e.isLoading=!1,e.isLastPage=!1,this.setData({listProperty:e,listReqModel:t}),this.getList()},handleLoadMore:function(){if(!this.data.listProperty.isLastPage){var t=this.data.listReqModel;t.page=t.page+1;var e=this.data.listProperty;e.isRefreshering=!1,e.isLoading=!0,this.setData({listProperty:e,listReqModel:t}),this.getList()}},toDetail:function(t){var e=t.currentTarget.dataset.item,a=e.exerciseId;s(a,e.situationType+"&fromOrigin=02","")},myCatchTouch:function(){},onTabItemTap:function(t){r("800.2.5.7","活动大厅-底部菜单")},onReady:function(){},onShow:function(){},onHide:function(){},onUnload:function(){},onPullDownRefresh:function(){},onReachBottom:function(){},onShareAppMessage:function(){return{title:i.shareTitle,path:i.sharePage,imageUrl:i.shareImage}},onShareTimeline:function(){return{title:i.shareTitle,path:i.sharePage,imageUrl:i.shareImage}}});
},{isPage:true,isComponent:true,currentFile:'pages/activelobby/index.js'});require("pages/activelobby/index.js");