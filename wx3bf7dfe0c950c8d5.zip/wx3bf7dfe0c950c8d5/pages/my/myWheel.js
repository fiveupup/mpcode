var _regeneratorRuntime2 = require("../../@babel/runtime/helpers/regeneratorRuntime");var _asyncToGenerator2 = require("../../@babel/runtime/helpers/asyncToGenerator");var e = require("../../common/vendor.js"),
  t = require("../../modules/db/useWheelDB.js"),
  a = require("../../store/wheel.js"),
  n = require("../../store/app.js");require("../../modules/db/useCheckMsg.js"), require("../../store/user.js"), require("../../utils/utils.js"), Math || (i + o)();var i = function i() {
    return "../../components/layout/topbar.js";
  },
  o = function o() {
    return "../../components/aSelectPop.js";
  },
  s = e.defineComponent({
    __name: "myWheel",
    setup: function setup(i) {
      e.useCssVars(function (t) {
        return {
          "30b4d435": e.unref(u).seatHeight
        };
      });
      var o = [{
        title: "编辑",
        key: 1
      }, {
        title: "复制",
        key: 2
      }, {
        title: "删除",
        key: 3
      }];
      var s = a.useWheelStore(),
        r = t.useWheelDB(),
        u = n.useAppStore(),
        l = e.ref(),
        c = e.ref(0),
        d = e.ref([]),
        f = e.ref(1);
      function p() {
        return _p.apply(this, arguments);
      }
      function _p() {
        _p = _asyncToGenerator2( /*#__PURE__*/_regeneratorRuntime2().mark(function _callee3() {
          var t,
            _args3 = arguments;
          return _regeneratorRuntime2().wrap(function _callee3$(_context3) {
            while (1) switch (_context3.prev = _context3.next) {
              case 0:
                t = _args3.length > 0 && _args3[0] !== undefined ? _args3[0] : f.value;
                1 == t && (d.value = [], c.value = 0);
                e.index.showLoading();
                f.value = t;
                _context3.next = 6;
                return _asyncToGenerator2( /*#__PURE__*/_regeneratorRuntime2().mark(function _callee2() {
                  var e;
                  return _regeneratorRuntime2().wrap(function _callee2$(_context2) {
                    while (1) switch (_context2.prev = _context2.next) {
                      case 0:
                        _context2.next = 2;
                        return r.getList({
                          curentPage: f.value,
                          source: 2
                        });
                      case 2:
                        e = _context2.sent;
                        d.value = d.value.concat(e.data);
                      case 4:
                      case "end":
                        return _context2.stop();
                    }
                  }, _callee2);
                }))();
              case 6:
                e.index.hideLoading();
              case 7:
              case "end":
                return _context3.stop();
            }
          }, _callee3);
        }));
        return _p.apply(this, arguments);
      }
      function g(_x, _x2) {
        return _g.apply(this, arguments);
      }
      function _g() {
        _g = _asyncToGenerator2( /*#__PURE__*/_regeneratorRuntime2().mark(function _callee4(t, a) {
          return _regeneratorRuntime2().wrap(function _callee4$(_context4) {
            while (1) switch (_context4.prev = _context4.next) {
              case 0:
                if (!(1 === a)) {
                  _context4.next = 4;
                  break;
                }
                e.index.navigateTo({
                  url: "/pages/modifyOption/index?type=modify&id=".concat(t)
                });
                _context4.next = 18;
                break;
              case 4:
                if (!(2 === a)) {
                  _context4.next = 12;
                  break;
                }
                _context4.next = 7;
                return r.copyById(t);
              case 7:
                e.index.showToast({
                  icon: "none",
                  title: "复制转盘成功"
                });
                _context4.next = 10;
                return p(1);
              case 10:
                _context4.next = 18;
                break;
              case 12:
                _context4.t0 = 3 === a;
                if (!_context4.t0) {
                  _context4.next = 18;
                  break;
                }
                r.remove(t);
                e.index.showToast({
                  icon: "none",
                  title: "删除转盘成功"
                });
                _context4.next = 18;
                return p(1);
              case 18:
              case "end":
                return _context4.stop();
            }
          }, _callee4);
        }));
        return _g.apply(this, arguments);
      }
      function v() {
        e.index.navigateTo({
          url: "/pages/modifyOption/index"
        });
      }
      function h() {
        p(f.value + 1);
      }
      return e.onShow(function () {
        1 == f.value && (d.value = [], c.value = 0), p(1);
      }), function (t, a) {
        return {
          a: e.p({
            title: "我的转盘",
            seatStatus: !0,
            isPageIcon: !1,
            backgroundColor: "#fff"
          }),
          b: e.o(v),
          c: e.f(e.unref(d), function (t, a, n) {
            return {
              a: e.t(t.wheelName),
              b: e.o(function (e) {
                return a = t._id, void l.value.open(a);
                var a;
              }, String(a)),
              c: String(a),
              d: e.o(function (a) {
                return function () {
                  var _ref = _asyncToGenerator2( /*#__PURE__*/_regeneratorRuntime2().mark(function _callee(t) {
                    var a;
                    return _regeneratorRuntime2().wrap(function _callee$(_context) {
                      while (1) switch (_context.prev = _context.next) {
                        case 0:
                          _context.next = 2;
                          return r.get(t);
                        case 2:
                          a = _context.sent;
                          _context.next = 5;
                          return s.setActiveWheel(a.data._id);
                        case 5:
                          e.index.switchTab({
                            url: "/pages/index/index"
                          });
                        case 6:
                        case "end":
                          return _context.stop();
                      }
                    }, _callee);
                  }));
                  return function (_x3) {
                    return _ref.apply(this, arguments);
                  };
                }()(t._id);
              }, String(a))
            };
          }),
          d: e.unref(c),
          e: e.o(h),
          f: e.sr(l, "55969f40-1", {
            k: "selectRef"
          }),
          g: e.o(g),
          h: e.p({
            range: e.unref(o)
          }),
          i: e.s(t.__cssVars())
        };
      };
    }
  }),
  r = e._export_sfc(s, [["__scopeId", "data-v-55969f40"]]);wx.createPage(r);