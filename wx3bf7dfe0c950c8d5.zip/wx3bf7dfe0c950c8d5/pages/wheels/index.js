var _regeneratorRuntime2 = require("../../@babel/runtime/helpers/regeneratorRuntime");var _asyncToGenerator2 = require("../../@babel/runtime/helpers/asyncToGenerator");var e = require("../../common/vendor.js"),
  t = require("../../modules/db/useWheelDB.js"),
  a = require("../../store/wheel.js"),
  n = require("../../utils/utils.js");require("../../modules/db/useCheckMsg.js"), require("../../store/user.js"), Math || s();var s = function s() {
    return "../../components/layout/topbar.js";
  },
  i = e.defineComponent({
    __name: "index",
    setup: function setup(s) {
      e.useCssVars(function (t) {
        return {
          c726460e: e.unref(d)
        };
      });
      var i = a.useWheelStore(),
        u = t.useWheelDB(),
        o = e.ref(0),
        r = e.ref([]),
        c = e.ref(1),
        l = e.ref(0),
        d = e.ref(),
        f = e.ref([]),
        v = e.ref(1);
      function g() {
        return _g.apply(this, arguments);
      }
      function _g() {
        _g = _asyncToGenerator2( /*#__PURE__*/_regeneratorRuntime2().mark(function _callee5() {
          var t,
            _args5 = arguments;
          return _regeneratorRuntime2().wrap(function _callee5$(_context5) {
            while (1) switch (_context5.prev = _context5.next) {
              case 0:
                t = _args5.length > 0 && _args5[0] !== undefined ? _args5[0] : v.value;
                1 == t && (f.value = [], o.value = 0);
                e.index.showLoading();
                v.value = t;
                _context5.next = 6;
                return _asyncToGenerator2( /*#__PURE__*/_regeneratorRuntime2().mark(function _callee4() {
                  var e;
                  return _regeneratorRuntime2().wrap(function _callee4$(_context4) {
                    while (1) switch (_context4.prev = _context4.next) {
                      case 0:
                        _context4.next = 2;
                        return u.getList({
                          curentPage: v.value,
                          source: 1,
                          type: c.value
                        });
                      case 2:
                        e = _context4.sent;
                        f.value = f.value.concat(e.data);
                      case 4:
                      case "end":
                        return _context4.stop();
                    }
                  }, _callee4);
                }))();
              case 6:
                e.index.hideLoading();
              case 7:
              case "end":
                return _context5.stop();
            }
          }, _callee5);
        }));
        return _g.apply(this, arguments);
      }
      function h() {
        g(v.value + 1);
      }
      return e.onMounted( /*#__PURE__*/_asyncToGenerator2( /*#__PURE__*/_regeneratorRuntime2().mark(function _callee() {
        var _e$index$getSystemInf, t, a, s, i;
        return _regeneratorRuntime2().wrap(function _callee$(_context) {
          while (1) switch (_context.prev = _context.next) {
            case 0:
              _e$index$getSystemInf = e.index.getSystemInfoSync(), t = _e$index$getSystemInf.safeArea, a = _e$index$getSystemInf.screenHeight, s = _e$index$getSystemInf.windowHeight;
              t && (l.value = a - t.bottom), d.value = s - n.getHeight() - 50 + "px";
              _context.next = 4;
              return u.getClass();
            case 4:
              i = _context.sent;
              r.value = i.data;
            case 6:
            case "end":
              return _context.stop();
          }
        }, _callee);
      }))), e.onShow(function () {
        1 == v.value && (f.value = [], o.value = 0), g(1);
      }), function (t, a) {
        return {
          a: e.p({
            title: "转盘市场",
            seatStatus: !0,
            isPageIcon: !1,
            backgroundColor: "#fff"
          }),
          b: e.f(e.unref(r), function (t, a, n) {
            return {
              a: e.t(t.title),
              b: e.n(e.unref(c) == t.type ? "active_wheel_tab" : ""),
              c: e.o(function (e) {
                return a = t.type, void (c.value != a && (c.value = a, g(1)));
                var a;
              }, t.id),
              d: t.id
            };
          }),
          c: e.f(e.unref(f), function (t, a, n) {
            return {
              a: e.t(t.wheelName),
              b: e.o(function (a) {
                return function () {
                  var _ref2 = _asyncToGenerator2( /*#__PURE__*/_regeneratorRuntime2().mark(function _callee2(t) {
                    return _regeneratorRuntime2().wrap(function _callee2$(_context2) {
                      while (1) switch (_context2.prev = _context2.next) {
                        case 0:
                          _context2.next = 2;
                          return u.copyById(t);
                        case 2:
                          e.index.showToast({
                            icon: "none",
                            title: '添加成功，可前往"我的转盘"查看'
                          });
                        case 3:
                        case "end":
                          return _context2.stop();
                      }
                    }, _callee2);
                  }));
                  return function (_x) {
                    return _ref2.apply(this, arguments);
                  };
                }()(t._id);
              }, String(a)),
              c: String(a),
              d: e.o(function (a) {
                return function () {
                  var _ref3 = _asyncToGenerator2( /*#__PURE__*/_regeneratorRuntime2().mark(function _callee3(t) {
                    var a;
                    return _regeneratorRuntime2().wrap(function _callee3$(_context3) {
                      while (1) switch (_context3.prev = _context3.next) {
                        case 0:
                          _context3.next = 2;
                          return u.get(t);
                        case 2:
                          a = _context3.sent;
                          _context3.next = 5;
                          return i.setActiveWheel(a.data._id);
                        case 5:
                          e.index.switchTab({
                            url: "/pages/index/index"
                          });
                        case 6:
                        case "end":
                          return _context3.stop();
                      }
                    }, _callee3);
                  }));
                  return function (_x2) {
                    return _ref3.apply(this, arguments);
                  };
                }()(t._id);
              }, String(a))
            };
          }),
          d: e.unref(o),
          e: e.o(h),
          f: e.s(t.__cssVars())
        };
      };
    }
  }),
  u = e._export_sfc(i, [["__scopeId", "data-v-16190b32"]]);wx.createPage(u);