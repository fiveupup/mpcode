var _objectSpread2 = require("../../@babel/runtime/helpers/objectSpread2");var _regeneratorRuntime2 = require("../../@babel/runtime/helpers/regeneratorRuntime");var _asyncToGenerator2 = require("../../@babel/runtime/helpers/asyncToGenerator");var e = require("../../common/vendor.js"),
  o = require("./config/colors.js"),
  t = require("../../store/wheel.js"),
  a = require("../../modules/db/useWheelDB.js");require("../../modules/db/useCheckMsg.js"), require("../../store/user.js"), Math || (n + l + i + u)();var n = function n() {
    return "../../components/layout/topbar.js";
  },
  l = function l() {
    return "./components/bgPop.js";
  },
  i = function i() {
    return "./components/batchPop.js";
  },
  u = function u() {
    return "../../components/aSelectPop.js";
  },
  r = e.defineComponent({
    __name: "index",
    setup: function setup(n) {
      var l = [{
        key: 1,
        title: "复制所有选项到粘贴板"
      }];
      var i = t.useWheelStore(),
        u = a.useWheelDB(),
        r = e.ref(),
        s = e.ref(),
        c = e.ref(),
        d = e.ref("add"),
        f = e.ref(""),
        v = e.ref(""),
        p = e.ref([]);
      function h() {
        var e = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : "";
        var t = 0;
        if (0 != p.value.length) {
          var _e = p.value[p.value.length - 1].color,
            _a = o.configColors.findIndex(function (o) {
              return _e == o;
            }),
            _n = Math.floor(_a / 5),
            _l = _a % 5,
            _i = o.configColors.length - 1;
          t = _i == _a ? 0 : _i - _a < 5 ? _l + 1 : 5 * (_n + 1) + _l;
        }
        p.value.push({
          title: e,
          color: o.configColors[t],
          weight: 1
        });
      }
      function g(e, o) {
        p.value[e].color = o;
      }
      function m() {
        s.value.open();
      }
      function w(e) {
        e.forEach(function (e) {
          h(e);
        });
      }
      function b() {
        c.value.open();
      }
      function j(o, t) {
        1 == t && e.index.setClipboardData({
          data: p.value.map(function (e) {
            return e.title;
          }).join("\n"),
          success: function success(e) {}
        });
      }
      function x() {
        return _x.apply(this, arguments);
      }
      function _x() {
        _x = _asyncToGenerator2( /*#__PURE__*/_regeneratorRuntime2().mark(function _callee2() {
          var o, _e2, _e3;
          return _regeneratorRuntime2().wrap(function _callee2$(_context2) {
            while (1) switch (_context2.prev = _context2.next) {
              case 0:
                if (v.value) {
                  _context2.next = 2;
                  break;
                }
                return _context2.abrupt("return", void e.index.showToast({
                  icon: "none",
                  title: "转盘名称不能为空"
                }));
              case 2:
                if (!(-1 != p.value.findIndex(function (e) {
                  return !e.title;
                }))) {
                  _context2.next = 4;
                  break;
                }
                return _context2.abrupt("return", void e.index.showToast({
                  icon: "none",
                  title: "选项不能为空"
                }));
              case 4:
                o = {
                  wheelName: v.value,
                  option: p.value.map(function (e) {
                    return _objectSpread2(_objectSpread2({}, e), {}, {
                      weight: Number(e.weight)
                    });
                  })
                };
                if (!("modify" == d.value)) {
                  _context2.next = 14;
                  break;
                }
                o._id = f.value;
                _context2.next = 9;
                return u.update(o);
              case 9:
                _e2 = _context2.sent;
                _context2.next = 12;
                return i.setActiveWheel(_e2.data._id);
              case 12:
                _context2.next = 19;
                break;
              case 14:
                _context2.next = 16;
                return u.add(o);
              case 16:
                _e3 = _context2.sent;
                _context2.next = 19;
                return i.setActiveWheel(_e3.data._id);
              case 19:
                e.index.navigateBack();
              case 20:
              case "end":
                return _context2.stop();
            }
          }, _callee2);
        }));
        return _x.apply(this, arguments);
      }
      return e.onLoad(function (e) {
        !function () {
          var _ref = _asyncToGenerator2( /*#__PURE__*/_regeneratorRuntime2().mark(function _callee(e) {
            var o, t, _a2;
            return _regeneratorRuntime2().wrap(function _callee$(_context) {
              while (1) switch (_context.prev = _context.next) {
                case 0:
                  if (!("modify" == e.type || "add" == e.type && e.id)) {
                    _context.next = 8;
                    break;
                  }
                  d.value = e.type, f.value = e.id;
                  _context.next = 4;
                  return u.get(e.id);
                case 4:
                  _a2 = _context.sent;
                  p.value = null == (o = _a2.data) ? void 0 : o.option, v.value = null == (t = _a2.data) ? void 0 : t.wheelName;
                  _context.next = 9;
                  break;
                case 8:
                  h(), h();
                case 9:
                case "end":
                  return _context.stop();
              }
            }, _callee);
          }));
          return function (_x2) {
            return _ref.apply(this, arguments);
          };
        }()(e);
      }), function (t, a) {
        return {
          a: e.p({
            title: "选项",
            seatStatus: !0,
            isPageIcon: !1,
            backgroundColor: "#fff"
          }),
          b: e.unref(v),
          c: e.o(function (o) {
            return e.isRef(v) ? v.value = o.detail.value : null;
          }),
          d: e.f(e.unref(p), function (o, t, a) {
            return {
              a: e.o(function (o) {
                return function (o) {
                  p.value.length < 3 ? e.index.showToast({
                    icon: "none",
                    title: "至少需要2个选项呀"
                  }) : p.value.splice(o, 1);
                }(t);
              }, t),
              b: o.title,
              c: e.o(function (e) {
                return o.title = e.detail.value;
              }, t),
              d: e.s("background-color: ".concat(o.color)),
              e: e.o(function (e) {
                return function (e, o) {
                  r.value.open(e, o);
                }(t, o.color);
              }, t),
              f: o.weight,
              g: e.o(function (e) {
                return o.weight = e.detail.value;
              }, t),
              h: t
            };
          }),
          e: e.o(function (e) {
            return h();
          }),
          f: e.o(m),
          g: e.o(b),
          h: e.t(e.unref(p).length),
          i: e.o(x),
          j: e.sr(r, "e3471979-1", {
            k: "colorPopRef"
          }),
          k: e.o(g),
          l: e.p({
            range: e.unref(o.configColors)
          }),
          m: e.sr(s, "e3471979-2", {
            k: "batchPopRef"
          }),
          n: e.o(w),
          o: e.sr(c, "e3471979-3", {
            k: "aSelectPopRef"
          }),
          p: e.o(j),
          q: e.p({
            title: "更多",
            safeArea: !0,
            range: e.unref(l)
          })
        };
      };
    }
  }),
  s = e._export_sfc(r, [["__scopeId", "data-v-e3471979"]]);wx.createPage(s);