var e = require("../../../common/vendor.js");Math || t();var t = function t() {
    return "../../../components/uni-popup/uni-popup.js";
  },
  o = e.defineComponent({
    __name: "bgPop",
    props: {
      title: {
        default: ""
      },
      range: {
        default: function _default() {
          return [];
        }
      }
    },
    emits: ["update:value", "change"],
    setup: function setup(t, _ref) {
      var o = _ref.expose,
        n = _ref.emit;
      var a = e.ref(),
        u = e.ref({}),
        p = e.ref("");
      return o({
        open: function open(e, t) {
          u.value = e, p.value = t, a.value.open();
        },
        close: function close() {
          a.value.close();
        }
      }), function (o, r) {
        return e.e({
          a: t.title
        }, t.title ? {
          b: e.t(t.title)
        } : {}, {
          c: e.f(t.range, function (t, o, r) {
            return {
              a: e.n(e.unref(p) == t ? "active_item" : ""),
              b: e.s("background-color: ".concat(t, ";")),
              c: t.key,
              d: e.o(function (e) {
                return o = t, n("change", u.value, o), void a.value.close();
                var o;
              }, t.key)
            };
          }),
          d: e.sr(a, "5a3d25a2-0", {
            k: "uniPopupRef"
          }),
          e: e.p({
            type: "bottom",
            safeArea: !1
          })
        });
      };
    }
  }),
  n = e._export_sfc(o, [["__scopeId", "data-v-5a3d25a2"]]);wx.createComponent(n);