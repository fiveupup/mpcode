var e = require("../../../common/vendor.js");Math || o();var o = function o() {
    return "../../../components/uni-popup/uni-popup.js";
  },
  n = e.defineComponent({
    __name: "batchPop",
    emits: ["update:value", "change"],
    setup: function setup(o, _ref) {
      var n = _ref.expose,
        t = _ref.emit;
      var u = e.ref(),
        a = e.ref(""),
        p = e.computed(function () {
          return a.value.split("\n").filter(function (e) {
            return e;
          });
        });
      function c() {
        u.value.close();
      }
      function s() {
        t("change", p.value), a.value = "", u.value.close();
      }
      return n({
        open: function open() {
          u.value.open();
        },
        close: c
      }), function (o, n) {
        return {
          a: e.o(c),
          b: e.unref(a),
          c: e.o(function (o) {
            return e.isRef(a) ? a.value = o.detail.value : null;
          }),
          d: e.t(e.unref(p).length),
          e: e.o(s),
          f: e.sr(u, "fab2f3bb-0", {
            k: "uniPopupRef"
          }),
          g: e.p({
            type: "bottom",
            safeArea: !1
          })
        };
      };
    }
  }),
  t = e._export_sfc(n, [["__scopeId", "data-v-fab2f3bb"]]);wx.createComponent(t);