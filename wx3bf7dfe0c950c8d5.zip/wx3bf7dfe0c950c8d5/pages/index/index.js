var _objectSpread2 = require("../../@babel/runtime/helpers/objectSpread2");var _regeneratorRuntime2 = require("../../@babel/runtime/helpers/regeneratorRuntime");var _asyncToGenerator2 = require("../../@babel/runtime/helpers/asyncToGenerator");var e = require("../../common/vendor.js"),
  t = require("../../utils/utils.js"),
  n = require("./canvas.js"),
  a = require("./config.js"),
  s = require("../../store/app.js"),
  o = require("../../modules/db/useRecordDB.js"),
  r = require("./appFun.js"),
  l = require("../../store/wheel.js"),
  c = require("../../store/config.js"),
  i = require("../../modules/hook/useAnimate.js");require("../../modules/db/useWheelDB.js"), require("../../modules/db/useCheckMsg.js"), require("../../store/user.js"), Math || (u + f + d)();var u = function u() {
    return "../../components/layout/topbar.js";
  },
  d = function d() {
    return "./components/operation.js";
  },
  f = function f() {
    return "./components/topTitle.js";
  },
  h = e.defineComponent({
    __name: "index",
    setup: function setup(u) {
      e.useCssVars(function (t) {
        return {
          "6d687852": e.unref(h).seatHeight
        };
      });
      var d = o.useRecordDB(),
        f = l.useWheelStore(),
        h = s.useAppStore(),
        g = c.useConfigStore();
      var _i$useAnimate = i.useAnimate({
          drawCallback: X,
          duration: 1e3 * g.duration,
          cycle: g.cycle,
          callback: function callback() {}
        }),
        v = _i$useAnimate.start,
        p = _i$useAnimate.setCanvas,
        x = _i$useAnimate.anInit,
        w = [],
        A = 0;
      var m,
        y = 0,
        b = 0,
        k = 187.5,
        j = 187.5,
        I = 187.5;
      var S,
        C = [],
        q = [],
        P = [],
        _ = e.ref(-1),
        W = e.ref("");
      var T = e.ref("");
      function R() {
        return _R.apply(this, arguments);
      }
      function _R() {
        _R = _asyncToGenerator2( /*#__PURE__*/_regeneratorRuntime2().mark(function _callee7() {
          var _i$useAnimate2, e, t, s;
          return _regeneratorRuntime2().wrap(function _callee7$(_context7) {
            while (1) switch (_context7.prev = _context7.next) {
              case 0:
                _i$useAnimate2 = i.useAnimate({
                  drawCallback: X,
                  duration: 1e3 * g.duration,
                  cycle: g.cycle,
                  callback: function callback() {}
                }), e = _i$useAnimate2.start, t = _i$useAnimate2.setCanvas, s = _i$useAnimate2.anInit;
                v = e, p = t, x = s, p(m.canvas), _asyncToGenerator2( /*#__PURE__*/_regeneratorRuntime2().mark(function _callee6() {
                  var e, t;
                  return _regeneratorRuntime2().wrap(function _callee6$(_context6) {
                    while (1) switch (_context6.prev = _context6.next) {
                      case 0:
                        w = r.optionToWheel(null == (e = f.activeWheel) ? void 0 : e.option);
                        A = w.reduce(function (e, t) {
                          return e + t.weight;
                        }, 0);
                        y = 360 / A;
                        b = a.blocks.reduce(function (e, t) {
                          return e + t.padding;
                        }, 0);
                        _context6.next = 6;
                        return _asyncToGenerator2( /*#__PURE__*/_regeneratorRuntime2().mark(function _callee5() {
                          return _regeneratorRuntime2().wrap(function _callee5$(_context5) {
                            while (1) switch (_context5.prev = _context5.next) {
                              case 0:
                                _context5.next = 2;
                                return _asyncToGenerator2( /*#__PURE__*/_regeneratorRuntime2().mark(function _callee4() {
                                  return _regeneratorRuntime2().wrap(function _callee4$(_context4) {
                                    while (1) switch (_context4.prev = _context4.next) {
                                      case 0:
                                        (function () {
                                          var e = 0,
                                            t = [];
                                          for (var _s = 0; _s < a.blocks.length; _s++) {
                                            var _o = n.createSectorPath(m.canvas, {
                                              x: 0,
                                              y: 0,
                                              radius: I - e,
                                              startAngle: 0,
                                              endAngle: 360
                                            });
                                            e += a.blocks[_s].padding, t.push(_o);
                                          }
                                          q = t;
                                        })();
                                        (function () {
                                          var e = 0,
                                            t = [];
                                          for (var _a = 0; _a < w.length; _a++) {
                                            var _s2 = y * w[_a].weight,
                                              _o2 = n.createSectorPath(m.canvas, {
                                                x: 0,
                                                y: 0,
                                                radius: I - b,
                                                startAngle: e,
                                                endAngle: e + _s2
                                              });
                                            t.push({
                                              startAngle: e,
                                              endAngle: e + _s2,
                                              sectorPath: _o2,
                                              id: String(w[_a].id),
                                              text: w[_a].font.text,
                                              weight: w[_a].weight
                                            }), e += _s2;
                                          }
                                          C = t;
                                        })();
                                        (function () {
                                          var e = [],
                                            t = 0;
                                          var s = Math.PI / 2;
                                          var _loop = function _loop() {
                                            var l = w[_o3].font,
                                              c = r.mergeObjects(l, a.fontConfig),
                                              i = y * w[_o3].weight,
                                              u = I - b - c.top - c.fontSize,
                                              d = i / 2;
                                            var f = c.text.split(""),
                                              h = "",
                                              g = 0;
                                            f.forEach(function (a, o) {
                                              if (g > c.line - 1) return;
                                              h += a;
                                              var _n$calculateTextPosit = n.calculateTextPositionAndRotation({
                                                  centerX: 0,
                                                  centerY: 0,
                                                  startAngle: t,
                                                  offsetFromCenter: u - c.fontSize * g,
                                                  halfAngle: d,
                                                  rotateOffset: s
                                                }),
                                                r = _n$calculateTextPosit.offsetX,
                                                l = _n$calculateTextPosit.offsetY,
                                                v = _n$calculateTextPosit.rotateAngle,
                                                p = !f[o + 1] || h + f[o + 1],
                                                x = n.calculateSectorWidth({
                                                  centerX: 0,
                                                  centerY: 0,
                                                  radius: I - b,
                                                  distanceToCenter: u - c.fontSize * (g + 3),
                                                  startAngle: t,
                                                  endAngle: t + i
                                                }),
                                                w = !1;
                                              1 != p && (w = n.ctxWidth(m.ctx, p)), (w && w > x || 1 == p) && (e.push({
                                                font: _objectSpread2(_objectSpread2({}, c), {}, {
                                                  text: h
                                                }),
                                                offsetX: r,
                                                offsetY: l,
                                                rotateAngle: v
                                              }), h = "", g += 1);
                                            }), t += i;
                                          };
                                          for (var _o3 = 0; _o3 < w.length; _o3++) {
                                            _loop();
                                          }
                                          P = e;
                                        })();
                                        _context4.next = 5;
                                        return _asyncToGenerator2( /*#__PURE__*/_regeneratorRuntime2().mark(function _callee3() {
                                          var e;
                                          return _regeneratorRuntime2().wrap(function _callee3$(_context3) {
                                            while (1) switch (_context3.prev = _context3.next) {
                                              case 0:
                                                _context3.next = 2;
                                                return n.getImage(m.canvas, "/static/image/pointer.png");
                                              case 2:
                                                e = _context3.sent;
                                                S = e;
                                              case 4:
                                              case "end":
                                                return _context3.stop();
                                            }
                                          }, _callee3);
                                        }))();
                                      case 5:
                                      case "end":
                                        return _context4.stop();
                                    }
                                  }, _callee4);
                                }))();
                              case 2:
                                M(m.ctx, {
                                  x: k,
                                  y: j
                                }, 0);
                              case 3:
                              case "end":
                                return _context5.stop();
                            }
                          }, _callee5);
                        }))();
                      case 6:
                        Y(-1);
                        _context6.next = 9;
                        return n.exportImage({
                          canvas: m.canvas,
                          width: 375,
                          height: 375
                        });
                      case 9:
                        t = _context6.sent;
                        T.value = t;
                      case 11:
                      case "end":
                        return _context6.stop();
                    }
                  }, _callee6);
                }))();
              case 2:
              case "end":
                return _context7.stop();
            }
          }, _callee7);
        }));
        return _R.apply(this, arguments);
      }
      function B(e) {
        var n = e.changedTouches[0],
          a = k - 30,
          s = j - 45;
        -1 != [a <= n.x, a + 60 >= n.x, s <= n.y, s + 76 >= n.y].findIndex(function (e) {
          return !e;
        }) || function () {
          var e = t.getRandomInt(1, A),
            n = 0,
            a = C.findIndex(function (t) {
              return n += t.weight, n >= e;
            });
          var s = C[a],
            o = (s.startAngle + s.endAngle) / 2;
          d.addRecord(f.wheelId, s.text), v(270 - o > 0 ? 270 - o : 630 - o);
        }();
      }
      function M(e, _ref, o) {
        var t = _ref.x,
          s = _ref.y;
        var r = n.degreesToRadians(o);
        e.clearRect(0, 0, m.width, m.height), e.save(), e.translate(t, s), function () {
          var e = m.ctx;
          for (var _t = 0; _t < a.blocks.length; _t++) e.save(), e.fillStyle = a.blocks[_t].background, e.shadowBlur = a.blocks[_t].shadowBlur, e.shadowColor = a.blocks[_t].shadowColor, e.fill(q[_t]), e.restore();
        }(), e.restore(), e.save(), e.translate(t, s), e.rotate(r), function () {
          var e = m.ctx;
          for (var _t2 = 0; _t2 < w.length; _t2++) e.save(), e.fillStyle = w[_t2].background, e.fill(C[_t2].sectorPath), e.fill(C[_t2].sectorPath), e.strokeStyle = "#fff", e.stroke(C[_t2].sectorPath), e.stroke(C[_t2].sectorPath), e.restore();
        }(), function () {
          var e = m.ctx;
          for (var _t3 = 0; _t3 < P.length; _t3++) n.drawText(e, P[_t3]);
        }(), e.restore(), e.save(), e.translate(t, s), function () {
          var e = m.ctx;
          e.save(), e.translate(-30, -45), e.drawImage(S, 0, 0, 60, 76), e.restore();
        }(), e.restore();
      }
      function X(e) {
        var t = e % 360,
          n = C.findIndex(function (e) {
            var n = t + e.startAngle > 360 ? (t + e.startAngle) % 360 : t + e.startAngle,
              a = t + e.startAngle > 360 ? (t + e.endAngle) % 360 : t + e.endAngle;
            return n <= 270 && a >= 270;
          });
        console.log(C, n, C[n], t, "sectorPaths"), _.value != n && (Y(n), g.vibrateShort()), M(m.ctx, {
          x: k,
          y: j
        }, e);
      }
      function Y(e) {
        _.value = e, -1 != _.value ? W.value = C[_.value].text : W.value = "？？";
      }
      return e.onLoad( /*#__PURE__*/function () {
        var _ref2 = _asyncToGenerator2( /*#__PURE__*/_regeneratorRuntime2().mark(function _callee2(e) {
          return _regeneratorRuntime2().wrap(function _callee2$(_context2) {
            while (1) switch (_context2.prev = _context2.next) {
              case 0:
                e.wheelId && f.setActiveWheel(e.wheelId);
                _context2.next = 3;
                return _asyncToGenerator2( /*#__PURE__*/_regeneratorRuntime2().mark(function _callee() {
                  var e;
                  return _regeneratorRuntime2().wrap(function _callee$(_context) {
                    while (1) switch (_context.prev = _context.next) {
                      case 0:
                        _context.next = 2;
                        return n.getContext("#firstCanvas");
                      case 2:
                        e = _context.sent;
                        m = e, k = m.width / 2, j = m.height / 2, I = Math.min(k, j), p(m.canvas);
                      case 4:
                      case "end":
                        return _context.stop();
                    }
                  }, _callee);
                }))();
              case 3:
                R();
              case 4:
              case "end":
                return _context2.stop();
            }
          }, _callee2);
        }));
        return function (_x) {
          return _ref2.apply(this, arguments);
        };
      }()), e.watch(function () {
        return [g.duration, g.cycle, f.activeWheel];
      }, function () {
        R();
      }), e.onShareAppMessage(function () {
        var e;
        return {
          title: null == (e = f.activeWheel) ? void 0 : e.wheelName,
          imageUrl: T.value,
          path: "/pages/index/index?wheelId=".concat(f.wheelId)
        };
      }), function (t, n) {
        return {
          a: e.p({
            seatStatus: !0,
            isPageIcon: !1
          }),
          b: e.p({
            selectText: e.unref(W)
          }),
          c: e.o(B),
          d: e.s(t.__cssVars())
        };
      };
    }
  });h.__runtimeHooks = 2;var g = e._export_sfc(h, [["__scopeId", "data-v-e138a679"]]);wx.createPage(g);