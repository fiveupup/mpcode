exports.blocks = [{
  padding: 10,
  background: "transparent",
  shadowBlur: 0
}, {
  padding: 5,
  background: "#fff",
  shadowBlur: 10,
  shadowColor: "rgba(0,0,0,0.3)"
}], exports.fontConfig = {
  top: 12,
  text: "",
  fontSize: 14,
  fontColor: "#fff",
  fontStyle: "Roboto",
  fontWeight: "bold",
  line: 2,
  shadowBlur: 7,
  shadowColor: "rgba(0,0,0,0.3)"
};