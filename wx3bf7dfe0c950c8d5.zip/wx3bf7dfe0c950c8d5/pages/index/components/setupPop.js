var e = require("../../../common/vendor.js"),
  o = require("../../../store/config.js");Math || t();var t = function t() {
    return "../../../components/uni-popup/uni-popup.js";
  },
  n = e.defineComponent({
    __name: "setupPop",
    setup: function setup(t, _ref) {
      var n = _ref.expose;
      var u = o.useConfigStore(),
        c = e.ref();
      function i() {
        u.vibrateShortStatus = !u.vibrateShortStatus;
      }
      function r() {
        (!u.duration || u.duration < 1 || u.duration > 20) && (e.index.showToast({
          icon: "none",
          title: "旋转时长最小为1s，最大为20s哦~"
        }), u.duration = 1);
      }
      function s() {
        (!u.cycle || u.cycle < 1 || u.cycle > 20) && (e.index.showToast({
          icon: "none",
          title: "旋转圈数最小为1圈，最大为20圈哦~"
        }), u.cycle = 1);
      }
      function a() {
        c.value.close();
      }
      return n({
        open: function open() {
          c.value.open();
        },
        close: a
      }), function (o, t) {
        return {
          a: e.o(a),
          b: e.unref(u).vibrateShortStatus,
          c: e.o(i),
          d: e.o(r),
          e: e.unref(u).duration,
          f: e.o(function (o) {
            return e.unref(u).duration = o.detail.value;
          }),
          g: e.o(s),
          h: e.unref(u).cycle,
          i: e.o(function (o) {
            return e.unref(u).cycle = o.detail.value;
          }),
          j: e.sr(c, "582ee75e-0", {
            k: "uniPopupRef"
          }),
          k: e.p({
            type: "bottom",
            safeArea: !1
          })
        };
      };
    }
  }),
  u = e._export_sfc(n, [["__scopeId", "data-v-582ee75e"]]);wx.createComponent(u);