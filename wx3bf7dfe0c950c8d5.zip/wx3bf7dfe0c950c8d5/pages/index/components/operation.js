var e = require("../../../common/vendor.js"),
  o = require("../../../store/wheel.js"),
  r = require("../../../store/user.js");require("../../../modules/db/useWheelDB.js"), require("../../../modules/db/useCheckMsg.js"), Math || (s + n)();var s = function s() {
    return "./setupPop.js";
  },
  n = function n() {
    return "./recordPop.js";
  },
  t = e.defineComponent({
    __name: "operation",
    setup: function setup(s) {
      var n = o.useWheelStore(),
        t = r.useUserStore(),
        i = e.ref(),
        u = e.ref();
      function d() {
        i.value.open();
      }
      function p() {
        var e;
        u.value.open(null == (e = n.activeWheel) ? void 0 : e._id);
      }
      function a() {
        var o, r;
        var s = (null == (o = n.activeWheel) ? void 0 : o._openid) == t.openId ? "modify" : "add";
        e.index.navigateTo({
          url: "/pages/modifyOption/index?type=".concat(s, "&id=").concat(null == (r = n.activeWheel) ? void 0 : r._id)
        });
      }
      return function (o, r) {
        return {
          a: e.o(d),
          b: e.o(p),
          c: e.o(a),
          d: e.sr(i, "f1758ee4-0", {
            k: "setupPopRef"
          }),
          e: e.sr(u, "f1758ee4-1", {
            k: "recordPopRef"
          })
        };
      };
    }
  }),
  i = e._export_sfc(t, [["__scopeId", "data-v-f1758ee4"]]);wx.createComponent(i);