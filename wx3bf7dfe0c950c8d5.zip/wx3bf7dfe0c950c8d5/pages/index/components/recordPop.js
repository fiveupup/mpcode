var e = require("../../../common/vendor.js"),
  o = require("../../../modules/db/useRecordDB.js");Math || n();var n = function n() {
    return "../../../components/uni-popup/uni-popup.js";
  },
  u = e.defineComponent({
    __name: "recordPop",
    setup: function setup(n, _ref) {
      var u = _ref.expose;
      var r = e.ref(),
        t = o.useRecordDB(),
        a = e.ref(""),
        c = e.ref([]);
      function p() {
        r.value.close();
      }
      return u({
        open: function open(e) {
          r.value.open(), c.value = t.getRecord(e), a.value = e;
        },
        close: p
      }), function (o, n) {
        return {
          a: e.o(p),
          b: e.f(e.unref(c), function (o, n, u) {
            return {
              a: e.t(o),
              b: e.o(function (e) {
                return function (e) {
                  t.removeRecord(a.value, e), c.value = t.getRecord(a.value);
                }(n);
              }, o),
              c: o
            };
          }),
          c: e.sr(r, "daa384af-0", {
            k: "uniPopupRef"
          }),
          d: e.p({
            type: "bottom",
            safeArea: !1
          })
        };
      };
    }
  }),
  r = e._export_sfc(u, [["__scopeId", "data-v-daa384af"]]);wx.createComponent(r);