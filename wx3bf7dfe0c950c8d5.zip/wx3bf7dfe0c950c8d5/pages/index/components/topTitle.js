var e = require("../../../common/vendor.js"),
  s = require("../../../store/wheel.js");require("../../../modules/db/useWheelDB.js"), require("../../../modules/db/useCheckMsg.js"), require("../../../store/user.js"), Math || t();var t = function t() {
    return "../../../components/shareBtn.js";
  },
  r = e.defineComponent({
    __name: "topTitle",
    props: {
      selectText: null
    },
    setup: function setup(t) {
      var r = s.useWheelStore();
      return function (s, o) {
        var n;
        return {
          a: e.t(null == (n = e.unref(r).activeWheel) ? void 0 : n.wheelName),
          b: e.t(t.selectText)
        };
      };
    }
  }),
  o = e._export_sfc(r, [["__scopeId", "data-v-60461a7d"]]);wx.createComponent(o);