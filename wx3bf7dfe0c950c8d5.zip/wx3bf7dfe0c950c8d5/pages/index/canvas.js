var _objectSpread2 = require("../../@babel/runtime/helpers/objectSpread2");var t = require("../../common/vendor.js");function e(t) {
  return t * Math.PI / 180;
}exports.calculateSectorWidth = function (_ref) {
  var t = _ref.centerX,
    n = _ref.centerY,
    o = _ref.radius,
    r = _ref.startAngle,
    s = _ref.endAngle,
    a = _ref.distanceToCenter;
  return r = e(r), s = e(s), function (t, e, n, o, r, s, a, i) {
    var c = (t - n) * (s - o) - (e - o) * (r - n),
      h = (t - r) * (i - s) - (e - s) * (a - r),
      d = (t - a) * (o - i) - (e - i) * (n - a),
      l = c > 0 || h > 0 || d > 0;
    return !((c < 0 || h < 0 || d < 0) && l);
  }(t + a * Math.cos((r + s) / 2), n + a * Math.sin((r + s) / 2), t, n, t + o * Math.cos(r), n + o * Math.sin(r), t + o * Math.cos(s), n + o * Math.sin(s)) ? function (_ref2) {
    var t = _ref2.centerX,
      e = _ref2.centerY,
      n = _ref2.radius,
      o = _ref2.startAngle,
      r = _ref2.endAngle;
    var s = t + n * Math.cos(o),
      a = e + n * Math.sin(o),
      i = t + n * Math.cos(r),
      c = e + n * Math.sin(r),
      h = Math.sqrt(Math.pow(i - s, 2) + Math.pow(c - a, 2));
    return h;
  }({
    centerX: t,
    centerY: n,
    radius: a,
    startAngle: r,
    endAngle: s
  }) - 5 : function (_ref3) {
    var t = _ref3.centerX,
      e = _ref3.centerY,
      n = _ref3.radius,
      o = _ref3.startAngle,
      r = _ref3.endAngle,
      s = _ref3.distanceToCenter;
    var a = t + s * Math.cos((o + r) / 2),
      i = e + s * Math.sin((o + r) / 2),
      c = Math.abs(r - o);
    if (c < .1) return n;
    var h = Math.abs((a - t) * Math.sin(r) - (i - e) * Math.cos(r)),
      d = Math.sqrt(Math.pow(a - (t + n * Math.cos(o)), 2) + Math.pow(i - (e + n * Math.sin(o)), 2)),
      l = Math.sqrt(Math.pow(a - (t + n * Math.cos(r)), 2) + Math.pow(i - (e + n * Math.sin(r)), 2));
    return Math.min(d, l, h);
  }({
    centerX: t,
    centerY: n,
    radius: o,
    startAngle: r,
    endAngle: s,
    distanceToCenter: a
  }) - 5;
}, exports.calculateTextPositionAndRotation = function (_ref4) {
  var t = _ref4.centerX,
    n = _ref4.centerY,
    o = _ref4.startAngle,
    r = _ref4.offsetFromCenter,
    s = _ref4.halfAngle,
    a = _ref4.rotateOffset;
  return o = e(o), s = e(s), {
    offsetX: t + Math.cos(o + s) * r,
    offsetY: Math.floor(n + Math.sin(o + s) * r),
    rotateAngle: o + s + a
  };
}, exports.createSectorPath = function (t, _ref5) {
  var n = _ref5.x,
    o = _ref5.y,
    r = _ref5.radius,
    s = _ref5.startAngle,
    a = _ref5.endAngle;
  var i = t.createPath2D();
  return i.moveTo(n, o), s = e(s), a = e(a), i.arc(n, o, r, s, a), i.closePath(), i;
}, exports.ctxWidth = function (t, e) {
  return t.measureText(e).width;
}, exports.degreesToRadians = e, exports.drawText = function (t, _ref6) {
  var e = _ref6.offsetX,
    n = _ref6.offsetY,
    o = _ref6.rotateAngle,
    r = _ref6.font;
  var s = r.text,
    a = r.fontColor,
    i = r.fontSize,
    c = r.fontStyle,
    h = r.fontWeight,
    d = r.shadowBlur,
    l = r.shadowColor;
  t.save(), t.translate(e, n), t.rotate(o), t.fillStyle = a, t.font = "".concat(h, " ").concat(i, "px ").concat(c), t.textAlign = "center", t.textBaseline = "middle", t.shadowBlur = d, t.shadowColor = l, t.fillText(s, 0, 0), t.restore();
}, exports.exportImage = function (e) {
  return new Promise(function (n, o) {
    var r = {};
    r.x = e.x ? e.x : 0, r.y = e.y ? e.y : 0, r.width = e.width ? e.width : 100, r.height = e.height ? e.height : 100, r.destWidth = e.destWidth ? e.destWidth : r.width, r.destHeight = e.destHeight ? e.destHeight : r.height, r.canvas = e.canvas ? e.canvas : "", t.index.canvasToTempFilePath(_objectSpread2(_objectSpread2({}, r), {}, {
      success: function success(t) {
        n(t.tempFilePath);
      },
      fail: function fail(t) {
        console.log(t, "err");
      }
    }));
  });
}, exports.getContext = function (e) {
  return new Promise(function (n) {
    var o = t.getCurrentInstance();
    t.index.createSelectorQuery().in(o.ctx).select(e).fields({
      node: !0,
      size: !0
    }).exec(function (e) {
      var o = e[0].node,
        r = o.getContext("2d"),
        s = t.index.getWindowInfo().pixelRatio,
        a = e[0].width * s,
        i = e[0].height * s;
      o.width = a, o.height = i, r.scale(s, s), n({
        canvas: o,
        ctx: r,
        width: e[0].width,
        height: e[0].height
      });
    });
  });
}, exports.getImage = function (e, n) {
  return new Promise(function (o, r) {
    t.nextTick$1(function () {
      if (!e) return;
      var t = e.createImage();
      t.src = n, t.onload = function () {
        o(t);
      };
    });
  });
};