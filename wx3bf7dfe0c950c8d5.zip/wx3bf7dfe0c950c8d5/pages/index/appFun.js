exports.mergeObjects = function (t, e) {
  var o = Object.assign({}, e);
  for (var n in t) null !== t[n] && "" !== t[n] && void 0 !== t[n] && (o[n] = t[n]);
  return o;
}, exports.optionToWheel = function (t) {
  return t.map(function (t) {
    return {
      font: {
        text: t.title
      },
      weight: t.weight,
      background: t.color
    };
  });
};