var e = require("../common/vendor.js"),
  r = e.defineStore("useUserStore", function () {
    var r = e.ref("");
    return {
      userInfo: e.ref({
        nickname: "",
        avatar: ""
      }),
      openId: r
    };
  }, {
    persist: {
      storage: {
        setItem: function setItem(r, t) {
          e.index.setStorageSync(r, t);
        },
        getItem: function getItem(r) {
          return e.index.getStorageSync(r);
        }
      }
    }
  });exports.useUserStore = r;