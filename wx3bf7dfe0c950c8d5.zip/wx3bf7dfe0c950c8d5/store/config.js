var e = require("../common/vendor.js"),
  t = e.defineStore("useConfigStore", function () {
    var t = e.ref(!0),
      r = e.ref(5),
      o = e.ref(10);
    return {
      vibrateShortStatus: t,
      vibrateShort: function vibrateShort() {
        t.value && e.index.vibrateShort({
          type: "light"
        });
      },
      duration: r,
      cycle: o
    };
  }, {
    persist: {
      storage: {
        setItem: function setItem(t, r) {
          e.index.setStorageSync(t, r);
        },
        getItem: function getItem(t) {
          return e.index.getStorageSync(t);
        }
      }
    }
  });exports.useConfigStore = t;