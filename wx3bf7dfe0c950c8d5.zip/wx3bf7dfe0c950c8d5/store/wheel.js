var _regeneratorRuntime2 = require("../@babel/runtime/helpers/regeneratorRuntime");var _asyncToGenerator2 = require("../@babel/runtime/helpers/asyncToGenerator");var e = require("../common/vendor.js"),
  t = require("../modules/db/useWheelDB.js"),
  o = e.defineStore("useWheelStore", function () {
    var o = e.ref("71fb15f9663775f8004bf1846e827f18"),
      i = e.ref({
        _id: "71fb15f9663775f8004bf1846e827f18",
        source: 1,
        type: 1,
        wheelName: "吃啥转盘",
        option: [{
          title: "火锅🍲",
          color: "#ffe066",
          weight: 1
        }, {
          title: "水饺🥟",
          color: "#ffc078",
          weight: 1
        }, {
          title: "🍜面条",
          color: "#ff8787",
          weight: 1
        }, {
          title: "酸辣粉",
          color: "#f783ac",
          weight: 1
        }, {
          title: "重庆小面",
          color: "#da77f2",
          weight: 1
        }, {
          title: "🍗 🍔 炸鸡汉堡",
          color: "#9775fa",
          weight: 1
        }, {
          title: "麻辣烫",
          color: "#748ffc",
          weight: 1
        }, {
          title: "川菜 🌶️",
          color: "#4dabf7",
          weight: 1
        }]
      });
    function l() {
      return _l.apply(this, arguments);
    }
    function _l() {
      _l = _asyncToGenerator2( /*#__PURE__*/_regeneratorRuntime2().mark(function _callee2() {
        var e, l;
        return _regeneratorRuntime2().wrap(function _callee2$(_context2) {
          while (1) switch (_context2.prev = _context2.next) {
            case 0:
              e = t.useWheelDB();
              _context2.next = 3;
              return e.get(o.value);
            case 3:
              l = _context2.sent;
              i.value = l.data;
            case 5:
            case "end":
              return _context2.stop();
          }
        }, _callee2);
      }));
      return _l.apply(this, arguments);
    }
    return {
      wheelId: o,
      activeWheel: i,
      setActiveWheel: function () {
        var _setActiveWheel = _asyncToGenerator2( /*#__PURE__*/_regeneratorRuntime2().mark(function _callee(e) {
          return _regeneratorRuntime2().wrap(function _callee$(_context) {
            while (1) switch (_context.prev = _context.next) {
              case 0:
                o.value = e;
                _context.next = 3;
                return l();
              case 3:
              case "end":
                return _context.stop();
            }
          }, _callee);
        }));
        function setActiveWheel(_x) {
          return _setActiveWheel.apply(this, arguments);
        }
        return setActiveWheel;
      }(),
      getActiveWheel: l
    };
  }, {
    persist: {
      storage: {
        setItem: function setItem(t, o) {
          e.index.setStorageSync(t, o);
        },
        getItem: function getItem(t) {
          return e.index.getStorageSync(t);
        }
      }
    }
  });exports.useWheelStore = o;