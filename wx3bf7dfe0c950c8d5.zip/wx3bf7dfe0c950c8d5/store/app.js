var e = require("../common/vendor.js"),
  t = require("../utils/utils.js"),
  r = e.defineStore("useAppStore", function () {
    var r = e.ref("62px"),
      s = e.ref(!1);
    return {
      getPageHeader: function getPageHeader() {
        r.value = "".concat(t.getHeight(), "px");
      },
      seatHeight: r,
      isComment: s
    };
  }, {
    persist: {
      storage: {
        setItem: function setItem(t, r) {
          e.index.setStorageSync(t, r);
        },
        getItem: function getItem(t) {
          return e.index.getStorageSync(t);
        }
      }
    }
  });exports.useAppStore = r;