var e = {};var n = require("../common/vendor.js")._export_sfc(e, [["render", function (e, n) {
  return {};
}], ["__scopeId", "data-v-ec82f981"]]);wx.createComponent(n);