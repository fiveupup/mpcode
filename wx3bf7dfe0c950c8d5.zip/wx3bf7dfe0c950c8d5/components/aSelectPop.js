var e = require("../common/vendor.js");Math || o();var o = function o() {
    return "./uni-popup/uni-popup.js";
  },
  n = e.defineComponent({
    __name: "aSelectPop",
    props: {
      range: {
        default: function _default() {
          return [];
        }
      },
      backgroundColor: {
        default: "#fff"
      }
    },
    emits: ["update:value", "change"],
    setup: function setup(o, _ref) {
      var n = _ref.expose,
        t = _ref.emit;
      var a = e.ref(),
        r = e.ref({}),
        u = e.ref(0);
      function c(e) {
        r.value = e, a.value.open();
      }
      function p() {
        a.value.close();
      }
      return e.onMounted(function () {
        var _e$index$getSystemInf = e.index.getSystemInfoSync(),
          o = _e$index$getSystemInf.safeArea,
          n = _e$index$getSystemInf.screenHeight,
          t = _e$index$getSystemInf.windowHeight;
        o && (u.value = n - o.bottom);
      }), n({
        open: c,
        cancel: p
      }), function (n, s) {
        return {
          a: e.f(o.range, function (o, n, u) {
            return {
              a: e.t(o.title),
              b: o.key,
              c: e.o(function (e) {
                return n = o.key, t("change", r.value, n), void a.value.close();
                var n;
              }, o.key)
            };
          }),
          b: e.o(p),
          c: e.s("border-bottom: ".concat(e.unref(u), "px solid ").concat(o.backgroundColor, ";")),
          d: e.sr(a, "53053d60-0", {
            k: "uniPopupRef"
          }),
          e: e.p({
            type: "bottom",
            safeArea: !1
          }),
          f: e.o(c)
        };
      };
    }
  }),
  t = e._export_sfc(n, [["__scopeId", "data-v-53053d60"]]);wx.createComponent(t);