require("../../@babel/runtime/helpers/Arrayincludes");var e = require("../../common/vendor.js"),
  t = e.defineComponent({
    __name: "topbar",
    props: {
      title: {
        default: ""
      },
      color: {
        default: "#000"
      },
      backgroundColor: {
        default: "transparent"
      },
      seatStatus: {
        type: Boolean,
        default: !1
      }
    },
    setup: function setup(t) {
      var a = t;
      e.useCssVars(function (e) {
        return {
          "7564b34d": o.value.seatHeight,
          "4d826026": t.backgroundColor,
          "53e00977": o.value.stateHeight,
          "1106c8b4": o.value.top,
          "4f6d5968": o.value.height,
          a3164c18: t.color
        };
      });
      var o = e.ref({
          top: "24px",
          height: "32px",
          stateHeight: "62px",
          seatHeight: "62px"
        }),
        n = e.ref("");
      function s() {
        "back" === n.value ? e.index.navigateBack() : e.index.reLaunch({
          url: "/pages/index/index"
        });
      }
      return e.onMounted(function () {
        var t = getCurrentPages();
        t.length > 1 ? n.value = "back" : 1 == t.length && ["pages/index/index", "pages/wheels/index", "pages/my/index", "pages/my/myWheel"].includes(t[0].route) || (n.value = "home"), function () {
          var t = e.index.getMenuButtonBoundingClientRect();
          t && (o.value = {
            top: "".concat(t.top, "px"),
            height: "".concat(t.height, "px"),
            stateHeight: "".concat(t.height + t.top + 6, "px"),
            seatHeight: "".concat(a.seatStatus ? t.height + t.top + 6 : 0, "px")
          });
        }();
      }), function (a, o) {
        return e.e({
          a: n.value
        }, n.value ? e.e({
          b: "back" == n.value
        }, "back" == n.value ? {
          c: e.o(s)
        } : "home" == n.value ? {
          e: e.o(s)
        } : {}, {
          d: "home" == n.value
        }) : {}, {
          f: e.t(t.title),
          g: t.title,
          h: e.s(a.__cssVars())
        });
      };
    }
  }),
  a = e._export_sfc(t, [["__scopeId", "data-v-885e1978"]]);wx.createComponent(a);