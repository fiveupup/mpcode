Object.defineProperty(exports, Symbol.toStringTag, {
  value: "Module"
});var e = require("./common/vendor.js"),
  r = require("./modules/db/useUserDB.js"),
  s = require("./utils/app.js"),
  t = require("./store/wheel.js"),
  o = require("./store/app.js");require("./store/user.js"), require("./modules/db/useWheelDB.js"), require("./modules/db/useCheckMsg.js"), require("./utils/utils.js"), Math;var u = e.defineComponent({
    __name: "App",
    setup: function setup(u) {
      var p = r.useUserDB(),
        n = t.useWheelStore(),
        i = o.useAppStore();
      return e.onLaunch(function (e) {
        p.register(), n.getActiveWheel(), s.openComment(), i.getPageHeader();
      }), e.onShow(function () {
        s.checkUpdate();
      }), e.onHide(function () {
        console.log("App Hide");
      }), function () {};
    }
  }),
  p = e.createPinia();function n() {
  var r = e.createSSRApp(u);
  return r.use(p), {
    app: r
  };
}p.use(e.src_default), n().app.mount("#app"), exports.createApp = n;