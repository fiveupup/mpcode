var e = require("../common/vendor.js"),
  o = require("../store/app.js");exports.checkUpdate = function () {
  var o = e.index.getUpdateManager();
  o.onCheckForUpdate(function (e) {}), o.onUpdateReady(function () {
    e.index.showModal({
      title: "更新提示",
      content: "新版本已经准备好，是否重启应用？",
      success: function success(e) {
        e.confirm && o.applyUpdate();
      }
    });
  }), o.onUpdateFailed(function () {
    console.log("新版本下载失败了!");
  });
}, exports.openComment = function () {
  var n = o.useAppStore();
  n.isComment || setTimeout(function () {
    e.index.showModal({
      title: "感谢您的支持！",
      content: "如果您对我们的服务感到满意，请给我们5星好评！🙏",
      cancelText: "下次再吧",
      confirmText: "必须五星",
      success: function success(e) {
        (n.isComment = !0, e.confirm) ? requirePlugin("wxacommentplugin").openComment({
          success: function success(e) {
            console.log("plugin.openComment success", e);
          },
          fail: function fail(e) {
            console.log("plugin.openComment fail", e);
          }
        }) : e.cancel && console.log("用户点击取消");
      }
    });
  }, 1e5);
};