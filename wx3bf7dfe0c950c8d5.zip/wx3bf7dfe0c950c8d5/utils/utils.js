var t = require("../common/vendor.js");exports.getHeight = function () {
  var e = t.index.getMenuButtonBoundingClientRect();
  return e.height + e.top + 6;
}, exports.getRandomInt = function (t, e) {
  return Math.floor(Math.random() * (e - t + 1) + t);
};