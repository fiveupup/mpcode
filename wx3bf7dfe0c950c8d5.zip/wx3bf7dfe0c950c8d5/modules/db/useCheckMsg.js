var _regeneratorRuntime2 = require("../../@babel/runtime/helpers/regeneratorRuntime");var _asyncToGenerator2 = require("../../@babel/runtime/helpers/asyncToGenerator");var e = require("../../common/vendor.js");exports.checkmsg = /*#__PURE__*/function () {
  var _ref = _asyncToGenerator2( /*#__PURE__*/_regeneratorRuntime2().mark(function _callee(t) {
    var s, n, r, l, _t, o;
    return _regeneratorRuntime2().wrap(function _callee$(_context) {
      while (1) switch (_context.prev = _context.next) {
        case 0:
          s = !0, n = "", r = function (e, t) {
            var s = [],
              n = 0;
            for (; n < e.length;) s.push(e.slice(n, n + t)), n += t;
            return s;
          }(t, 2500);
          _context.t0 = _regeneratorRuntime2().keys(r);
        case 2:
          if ((_context.t1 = _context.t0()).done) {
            _context.next = 10;
            break;
          }
          l = _context.t1.value;
          _context.next = 6;
          return e.wx$1.cloud.callFunction({
            name: "cloudbase_module",
            data: {
              name: "wx_security_msg_sec_check",
              data: {
                scene: 1,
                version: 2,
                content: r[l]
              }
            }
          });
        case 6:
          _t = _context.sent;
          if (console.log(_t.result, "res.result"), "pass" != _t.result.result.suggest) {
            n = _t.result.detail.find(function (e) {
              return "pass" != e.suggest;
            }).keyword, s = !1;
          }
          _context.next = 2;
          break;
        case 10:
          o = {
            status: s,
            errText: n
          };
          if (o.status) {
            _context.next = 13;
            break;
          }
          throw e.index.showModal({
            title: "信息违规",
            content: "您输入的信息，存在违规信息请重新输入",
            showCancel: !1
          }), Error("存在违规信息");
        case 13:
          return _context.abrupt("return", o);
        case 14:
        case "end":
          return _context.stop();
      }
    }, _callee);
  }));
  return function (_x) {
    return _ref.apply(this, arguments);
  };
}();