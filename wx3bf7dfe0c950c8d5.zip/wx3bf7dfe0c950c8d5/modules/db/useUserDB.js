var _regeneratorRuntime2 = require("../../@babel/runtime/helpers/regeneratorRuntime");var _asyncToGenerator2 = require("../../@babel/runtime/helpers/asyncToGenerator");var e = require("../../common/vendor.js"),
  t = require("../../store/user.js");exports.useUserDB = function () {
  var a = t.useUserStore();
  e.wx$1.cloud.init({
    env: "lucky-server-0ggadgdz78ec29bd",
    traceUser: !1
  });
  var r = e.wx$1.cloud.database(),
    n = r.collection("lucky_user");
  return {
    register: function () {
      var _register = _asyncToGenerator2( /*#__PURE__*/_regeneratorRuntime2().mark(function _callee2() {
        var t, s;
        return _regeneratorRuntime2().wrap(function _callee2$(_context2) {
          while (1) switch (_context2.prev = _context2.next) {
            case 0:
              _context2.next = 2;
              return e.wx$1.cloud.callFunction({
                name: "cloudbase_module",
                data: {
                  name: "wx_user_get_open_id"
                }
              });
            case 2:
              _context2.t0 = t = _context2.sent.result;
              if (!(null == _context2.t0)) {
                _context2.next = 7;
                break;
              }
              _context2.t1 = void 0;
              _context2.next = 8;
              break;
            case 7:
              _context2.t1 = t.openId;
            case 8:
              s = _context2.t1;
              _context2.next = 11;
              return function () {
                var _ref = _asyncToGenerator2( /*#__PURE__*/_regeneratorRuntime2().mark(function _callee(e) {
                  var t;
                  return _regeneratorRuntime2().wrap(function _callee$(_context) {
                    while (1) switch (_context.prev = _context.next) {
                      case 0:
                        _context.next = 2;
                        return n.where({
                          _openid: e
                        }).get();
                      case 2:
                        t = _context.sent;
                        return _context.abrupt("return", {
                          data: t.data[0],
                          status: 1
                        });
                      case 4:
                      case "end":
                        return _context.stop();
                    }
                  }, _callee);
                }));
                return function (_x) {
                  return _ref.apply(this, arguments);
                };
              }()(s);
            case 11:
              _context2.t2 = _context2.sent.data;
              if (_context2.t2) {
                _context2.next = 14;
                break;
              }
              n.add({
                data: {
                  avatar: "",
                  nickname: "",
                  createTime: r.serverDate()
                }
              });
            case 14:
              a.openId = s;
              return _context2.abrupt("return", {
                status: 1,
                openId: s
              });
            case 16:
            case "end":
              return _context2.stop();
          }
        }, _callee2);
      }));
      function register() {
        return _register.apply(this, arguments);
      }
      return register;
    }()
  };
};