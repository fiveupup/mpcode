var _toConsumableArray2 = require("../../@babel/runtime/helpers/toConsumableArray");var e = require("../../common/vendor.js");exports.useRecordDB = function () {
  return {
    addRecord: function addRecord(r, d) {
      var t = e.index.getStorageSync("record");
      t || (t = []);
      var c = t.findIndex(function (e) {
        return e.wheelId == r;
      });
      if (-1 == c) {
        var _e = {
          wheelId: r,
          record: [d]
        };
        t.push(_e);
      } else {
        var _e2 = t[c],
          n = {
            wheelId: r,
            record: [].concat(_toConsumableArray2(_e2.record), [d])
          };
        t.splice(c, 1, n);
      }
      e.index.setStorageSync("record", t);
    },
    getRecord: function getRecord(r) {
      var d = e.index.getStorageSync("record");
      if (!d) return [];
      var t = d.find(function (e) {
        return e.wheelId == r;
      });
      return t ? t.record : [];
    },
    removeRecord: function removeRecord(r, d) {
      var t = e.index.getStorageSync("record"),
        c = t.findIndex(function (e) {
          return e.wheelId == r;
        }),
        n = t[c],
        o = JSON.parse(JSON.stringify(n.record));
      o.splice(d, 1);
      var i = {
        wheelId: r,
        record: o
      };
      t.splice(c, 1, i), e.index.setStorageSync("record", t);
    }
  };
};