var _regeneratorRuntime2 = require("../../@babel/runtime/helpers/regeneratorRuntime");var _objectSpread2 = require("../../@babel/runtime/helpers/objectSpread2");var _toConsumableArray2 = require("../../@babel/runtime/helpers/toConsumableArray");var _asyncToGenerator2 = require("../../@babel/runtime/helpers/asyncToGenerator");var e = require("../../common/vendor.js"),
  t = require("./useCheckMsg.js"),
  a = require("../../store/user.js");exports.useWheelDB = function () {
  var i = a.useUserStore();
  e.wx$1.cloud.init({
    env: "lucky-server-0ggadgdz78ec29bd",
    traceUser: !1
  });
  var r = e.wx$1.cloud.database(),
    c = r.collection("lucky_wheel"),
    o = r.collection("lucky_class");
  function n(_x) {
    return _n.apply(this, arguments);
  }
  function _n() {
    _n = _asyncToGenerator2( /*#__PURE__*/_regeneratorRuntime2().mark(function _callee7(e) {
      return _regeneratorRuntime2().wrap(function _callee7$(_context7) {
        while (1) switch (_context7.prev = _context7.next) {
          case 0:
            _context7.next = 2;
            return c.doc(e).get();
          case 2:
            return _context7.abrupt("return", _context7.sent);
          case 3:
          case "end":
            return _context7.stop();
        }
      }, _callee7);
    }));
    return _n.apply(this, arguments);
  }
  return {
    add: function () {
      var _add = _asyncToGenerator2( /*#__PURE__*/_regeneratorRuntime2().mark(function _callee(e) {
        var a, i, o;
        return _regeneratorRuntime2().wrap(function _callee$(_context) {
          while (1) switch (_context.prev = _context.next) {
            case 0:
              a = e.option.map(function (e) {
                return e.title;
              }), i = [e.wheelName].concat(_toConsumableArray2(a)).join("");
              _context.next = 3;
              return t.checkmsg(i);
            case 3:
              _context.next = 5;
              return c.add({
                data: _objectSpread2(_objectSpread2({}, e), {}, {
                  source: 2,
                  createTime: r.serverDate(),
                  updateTime: r.serverDate()
                })
              });
            case 5:
              o = _context.sent;
              _context.next = 8;
              return n(o._id);
            case 8:
              return _context.abrupt("return", _context.sent);
            case 9:
            case "end":
              return _context.stop();
          }
        }, _callee);
      }));
      function add(_x2) {
        return _add.apply(this, arguments);
      }
      return add;
    }(),
    update: function () {
      var _update = _asyncToGenerator2( /*#__PURE__*/_regeneratorRuntime2().mark(function _callee2(e) {
        var a, i, o;
        return _regeneratorRuntime2().wrap(function _callee2$(_context2) {
          while (1) switch (_context2.prev = _context2.next) {
            case 0:
              a = e.option.map(function (e) {
                return e.title;
              }), i = [e.wheelName].concat(_toConsumableArray2(a)).join("");
              _context2.next = 3;
              return t.checkmsg(i);
            case 3:
              o = {
                wheelName: e.wheelName,
                option: e.option,
                source: 2,
                updateTime: r.serverDate()
              };
              _context2.next = 6;
              return c.doc(e._id).update({
                data: o
              });
            case 6:
              _context2.next = 8;
              return n(e._id);
            case 8:
              return _context2.abrupt("return", _context2.sent);
            case 9:
            case "end":
              return _context2.stop();
          }
        }, _callee2);
      }));
      function update(_x3) {
        return _update.apply(this, arguments);
      }
      return update;
    }(),
    getClass: function () {
      var _getClass = _asyncToGenerator2( /*#__PURE__*/_regeneratorRuntime2().mark(function _callee3() {
        return _regeneratorRuntime2().wrap(function _callee3$(_context3) {
          while (1) switch (_context3.prev = _context3.next) {
            case 0:
              _context3.next = 2;
              return o.get();
            case 2:
              return _context3.abrupt("return", _context3.sent);
            case 3:
            case "end":
              return _context3.stop();
          }
        }, _callee3);
      }));
      function getClass() {
        return _getClass.apply(this, arguments);
      }
      return getClass;
    }(),
    get: n,
    getList: function () {
      var _getList = _asyncToGenerator2( /*#__PURE__*/_regeneratorRuntime2().mark(function _callee4(_ref) {
        var e, _ref$pageSize, t, _ref$source, a, _ref$type, r, o, n, s;
        return _regeneratorRuntime2().wrap(function _callee4$(_context4) {
          while (1) switch (_context4.prev = _context4.next) {
            case 0:
              e = _ref.curentPage, _ref$pageSize = _ref.pageSize, t = _ref$pageSize === void 0 ? 15 : _ref$pageSize, _ref$source = _ref.source, a = _ref$source === void 0 ? 1 : _ref$source, _ref$type = _ref.type, r = _ref$type === void 0 ? 1 : _ref$type;
              o = 1 == a ? void 0 : i.openId;
              n = 2 == a ? void 0 : r;
              _context4.next = 5;
              return c.where({
                _openid: o,
                source: a,
                type: n
              }).count();
            case 5:
              s = _context4.sent.total;
              if (!(Math.ceil(s / t) < e)) {
                _context4.next = 10;
                break;
              }
              _context4.t0 = {
                curentPage: e,
                data: [],
                pageSize: t,
                total: s
              };
              _context4.next = 17;
              break;
            case 10:
              _context4.t1 = e;
              _context4.next = 13;
              return c.where({
                _openid: o,
                source: a,
                type: n
              }).orderBy("updateTime", "desc").skip(t * (e - 1)).limit(t).get();
            case 13:
              _context4.t2 = _context4.sent.data;
              _context4.t3 = t;
              _context4.t4 = s;
              _context4.t0 = {
                curentPage: _context4.t1,
                data: _context4.t2,
                pageSize: _context4.t3,
                total: _context4.t4
              };
            case 17:
              return _context4.abrupt("return", _context4.t0);
            case 18:
            case "end":
              return _context4.stop();
          }
        }, _callee4);
      }));
      function getList(_x4) {
        return _getList.apply(this, arguments);
      }
      return getList;
    }(),
    copyById: function () {
      var _copyById = _asyncToGenerator2( /*#__PURE__*/_regeneratorRuntime2().mark(function _callee5(e) {
        var t;
        return _regeneratorRuntime2().wrap(function _callee5$(_context5) {
          while (1) switch (_context5.prev = _context5.next) {
            case 0:
              _context5.next = 2;
              return n(e);
            case 2:
              t = _context5.sent.data;
              delete t._id;
              t.createTime && delete t.createTime;
              t._openid && delete t._openid;
              _context5.next = 8;
              return c.add({
                data: _objectSpread2(_objectSpread2({}, t), {}, {
                  source: 2,
                  createTime: r.serverDate(),
                  updateTime: r.serverDate()
                })
              });
            case 8:
              return _context5.abrupt("return", _context5.sent);
            case 9:
            case "end":
              return _context5.stop();
          }
        }, _callee5);
      }));
      function copyById(_x5) {
        return _copyById.apply(this, arguments);
      }
      return copyById;
    }(),
    remove: function () {
      var _remove = _asyncToGenerator2( /*#__PURE__*/_regeneratorRuntime2().mark(function _callee6(e) {
        return _regeneratorRuntime2().wrap(function _callee6$(_context6) {
          while (1) switch (_context6.prev = _context6.next) {
            case 0:
              _context6.next = 2;
              return c.doc(e).remove();
            case 2:
              return _context6.abrupt("return", _context6.sent);
            case 3:
            case "end":
              return _context6.stop();
          }
        }, _callee6);
      }));
      function remove(_x6) {
        return _remove.apply(this, arguments);
      }
      return remove;
    }()
  };
};