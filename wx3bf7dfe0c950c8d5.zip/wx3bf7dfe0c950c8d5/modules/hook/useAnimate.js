var n = {
  easeInOutQuart: function easeInOutQuart(n) {
    return n < .5 ? 8 * n * n * n * n : 1 - Math.pow(-2 * n + 2, 4) / 2;
  }
};exports.useAnimate = function (_ref) {
  var t = _ref.drawCallback,
    _ref$duration = _ref.duration,
    a = _ref$duration === void 0 ? 5e3 : _ref$duration,
    _ref$easingName = _ref.easingName,
    e = _ref$easingName === void 0 ? "easeInOutQuart" : _ref$easingName,
    _ref$cycle = _ref.cycle,
    u = _ref$cycle === void 0 ? 10 : _ref$cycle,
    i = _ref.callback;
  var r,
    c = null,
    o = null,
    l = !1,
    s = 0,
    f = 0,
    m = 0,
    A = 0,
    h = n[e];
  function p(n) {
    c || (c = n);
    var e = n - c,
      u = Math.min(e / a, 1),
      w = h(u);
    m = s + A * w, t(m), e <= a ? o = r.requestAnimationFrame(p) : o && (r.cancelAnimationFrame(o), o = null, c = null, l = !1, m = f % 360, s = f % 360, t(m), "function" == typeof i && i());
  }
  return {
    setCanvas: function setCanvas(n) {
      r = n;
    },
    anInit: function anInit() {
      s = 0, f = 0, m = 0, A = 0;
    },
    start: function start(n) {
      if (!r) throw Error("未发现canvas实例");
      l || (f = 360 * u + n, A = f - s, l = !0, o = r.requestAnimationFrame(p));
    }
  };
};